# READ THIS FIRST

**Warning.** The reviewers wrote this package from their records. **The reviewers do not know the pod's current state.** The owner has reorganized the pod, and stage 0 ran on the reorganized code. Every path, folder name, file name, trainer location and config location in this package may be out of date.

Copilot, before you run or change anything:
1. **Find the real thing.** For every path, file or command this package names, find the actual one on the laptop and the pod. Do not assume ours is right.
2. **Adapt.** Where ours is wrong, change the command or the path, never the model, training or scoring logic, and list each change in your report.
3. **Stop and ask the owner** if something this package needs cannot be found, or two different candidates exist.
4. **Keep the rules as written.** The runs, learning rates, epoch counts, seeds, populations and decision rules are the plan. Paths are yours to fix; the experiment is not.

## Where things stand (3 November)

- **Stage 0, the learning-rate check, has run** on the reorganized code. The owner reported its runs done on 3 November and is running the morning report (`tuning_run_1/morning.py`). Its report sets stage 2's learning rate and the stage 0b gate (`PLAN.md`, section 4). Do not change it. Install nothing that changes the trainer's source hash until its runs and resumes have finished, or the resumes will refuse.
- **The reorganization is done.** `tuning_run_1/README.md` was written before it. Its last section ("After this run") is out of date: the reorganization came first. Copilot's adapted stage 0 commands should be in `handoff/TUNING_RUN_1.md` on the pod (the earlier prompt asked Copilot to write them there).
- **`tuning_run_1/REORG_CORRECTIONS.md` line 3 ("Apply them now") is out of date.** Check the four corrections only. Apply a missing one only after stage 0's runs and resumes have finished: corrections 2 and 4 can change files the trainer's source hash covers (correction 4 edits `pyproject.toml`; correction 2 moves `.py` files). The file is kept as it was sent.
- **The stage 0 files keep the pod's own folder paths on purpose.** `start.sh`, `lr_screen.sh`, `locate.py`, `morning.py` and the commands in `tuning_run_1/README.md` are the ones running on the pod, kept as sent (the README has two naming fixes only). Copilot adapts them.
- **Stage 1, the reproduction, is paused.** Its reviewed design is in `11_01_2026/stage1_spec/`, for Copilot to build later. Its seed-42 retrain is the control that must exist before any feature fit is read.
- **Stage 2, the features and testing package, is released separately as `features_testing_package_REVIEWERS_SUGGESTIONS.zip`** (public commit `6f39030`, verified).
- **Part 2, the tuning code for stage 3, comes later.**
- **The owner's open questions were decided by the reviewers** under his delegation of 2 November, and on 3 November both reviewers agreed every item, with the second reviewer's amendments: among them the corrected three-seed statistics (D2) and the decisions N1 (the temporary second GPU), N2 (which training files) and N3 (dropping some non-fraud while keeping all fraud) (`DECISIONS_JOINT.md`; `PLAN.md`, section 5). He can override any of them before stage 2. Still open, each with its default in `PLAN.md` section 5: the final feature list, the bank's answers and stage 0's report. Decided but not built yet: the coordinated two-workbench workers and the paired tuner (N1), stage 4's checkpoint choice and the files report's reuse rule (N2), and the conditional sampling arm (N3).
- **Two workbenches, one queue, until the coordinated workers are delivered (N1).** The owner's two workbenches share one project folder. Until the workers are delivered, run one GPU job at a time from one queue on one workbench; a second workbench runs only work that writes to other folders. After that: one job per workbench, both arms of a seed pair on the same workbench, host and GPU UUID recorded for every fit, and one worker stays the normal mode. Two workbenches do not halve the wall time: serial steps, unequal job lengths and shared storage remain.

## What is in this package

| Item | What it is | Status |
|---|---|---|
| `PLAN.md` | The reviewers' joint plan: answers to the owner's questions, every tuning method and where it goes, which data does what, the stages in the owner's order with their decision rules, the budget, the reviewers' decisions on the questions the owner delegated, and what is still open for him | Current: the owner's decisions of 2 November and the reviewers' joint decisions, revised 3 November with the amendments both reviewers agreed that day and the decisions N1 to N3 |
| `DECISIONS_JOINT.md` | The reviewers' joint decision record of 2 November: decisions D1 to D10 on the owner's delegated questions, amended on 3 November with the second reviewer's dispositions, which the first reviewer accepted, and decisions N1 to N3; with reasons and evidence, the PLAN.md edits, the changes for the other packages and the facts still needed | New; applied in `PLAN.md`, whose section 5 gives each decision in one line |
| `tuning_run_1/` | Stage 0: the light learning-rate check of the three contenders, as specified (`README.md`; `COPILOT.md` says how to adapt it to the pod) | Its runs are done (owner, 3 November); the morning report and any kept runs' resumes come next |
| `tuning_run_1/REORG_CORRECTIONS.md` | Four corrections to the reorganization plan | Check only; apply a missing one after stage 0 (above) |
| `COPILOT_PROMPT.md` | What to paste into Copilot | As sent on 2 November, unchanged. Its opening paragraph says stage 0 is running; its steps still apply, and step 2 is due now that the 5-epoch runs have ended |

## Not in this package

| Item | What it is | Status |
|---|---|---|
| `11_01_2026/stage1_spec/` | Stage 1: the reviewed design (`DESIGN.md`) and its review corrections (`DESIGN_REVIEW_CORRECTIONS.md`) | Paused; Copilot builds it later |
| Features and testing package | Stage 2: field checks, the CPU screen, engineered features, the steps and the reader, importance, the downstream check, the feature workbook | Released separately as `features_testing_package_REVIEWERS_SUGGESTIONS.zip` (public commit `6f39030`, verified) |
| Part 2 | Code for every stage 3 method in the plan, each off by default with CPU tests: loss options, EMA, schedules and optimizer groups, PLR numerical embeddings, the hierarchical tuner, CPU analysis tools | Later |

## Order on the pod

1. Done: stage 0's runs (`tuning_run_1`; the owner's report of 3 November). Its morning report sets stage 2's rate and the stage 0b gate. Now, on the CPU: the features package's CPU part, which changes no hashed file.
2. After stage 0's runs and resumes: stage 0b, only if its gate fires (`PLAN.md`, stage 0b), once the RANK check is done; then stage 1, built by Copilot from `stage1_spec/`.
3. Then stage 2's GPU steps, once the owner confirms the feature list and the stage 1 control exists: first the base refits at seeds 43 and 44, then A1, A2 and month out (`PLAN.md`, stage 2).
4. Then stage 3 (tuning), with part 2's code. Install part 2 only after stage 2 ends. Stage 3 ends with the 10-file reference refit, then the focal-loss check only if its conditions hold (`PLAN.md`, stage 3).
5. Then stages 4 and 5 (`PLAN.md`, section 4).
