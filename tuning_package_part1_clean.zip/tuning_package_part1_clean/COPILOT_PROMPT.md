# Paste into Copilot

```
Read tuning_package_part1_clean/README_FIRST.md first. This package was written by reviewers who do not know the pod's current state, so every path in it may be out of date: find the real ones and adapt commands and paths only, never the experiment. Stage 0 is running on the reorganized code: change nothing it uses, and install nothing that changes the trainer's source hash until its runs and resumes have finished. Then:
1. Check that the four corrections in tuning_package_part1_clean/tuning_run_1/REORG_CORRECTIONS.md are in the reorganization. List each as applied or missing in handoff/REORG_CHECK.md. Do not apply a missing one until stage 0's runs and resumes have finished.
2. When stage 0's 5-epoch runs end, apply the decision rule in tuning_package_part1_clean/tuning_run_1/README.md, add the exact resume and rerun lines for the kept runs on the reorganized trainer to handoff/TUNING_RUN_1.md, and give me those lines to paste on the pod.
3. Read tuning_package_part1_clean/PLAN.md. List anything in it that does not match the code or the pod (file, function, config key, population, path), without changing the plan, in handoff/PLAN_CHECK.md, at most 40 lines.
Do not build stage 1 now. Its design is in 11_01_2026/stage1_spec/ and is built later. The features and testing package comes as its own zip, with its own prompt.
```
