# Read this first: the features and testing package

## The pod's state is not known to us

The reviewers do not know the pod's current state. The pod has been reorganized, but not exactly how it turned out.
Copilot adapts paths and commands to the pod as it is now. Every tool finds project code through one resolver,
`fraud/experiments/features/new_fields/nf_layout.py`. It tries the reorganized names first, falls back to the old
names, and prints which layout it found. If the names are a mix of both, it stops (exit 4) and lists them. Run it
first: `$PY fraud/experiments/features/new_fields/nf_layout.py`.

## What this is

This package is the reviewers' suggestion for stage 2 of the plan (`PLAN.md`, stage 2): adding new input fields to
the chosen model, checking them, and measuring which ones help. It is not final. The owner decides.

## What Copilot may change

- Copilot adapts paths and commands to the pod, and writes the feature list into the field map.
- Copilot never changes the logic: not the steps, seeds, files, rules, thresholds or decisions.
- If something cannot be found, or two candidates exist, Copilot stops and asks the owner.

## Two parts

- **Part A is CPU only.** It is safe to run while the GPU trains: intake of the pod's columns, the field map, the CPU
  field checks, the CPU screen, the rank check and the feature workbook. Every part A command starts with
  `CUDA_VISIBLE_DEVICES=`.
- **Part B uses the GPU.** It starts only after stage 0, its resumes and stage 1's GPU work have finished: timing,
  fits, scoring, reads, importance and the downstream check.
- The stage 1 seed-42 retrain must exist before any feature fit is read, because it is the control. Without it,
  every read is blocked. Our own control fit runs only with the owner's written yes.

## One queue, on one workbench

The project folder is shared by the owner's workbenches: each is its own pod with its own hostname, and all of them
mount the same folder at the same paths. Run part B's queue on one workbench only. A lock that names another
workbench is never replaced: the queue refuses with exit 4 and names that workbench. Remove such a lock by hand only
after checking on that workbench that nothing runs there. One-off work on another workbench that writes to its own
folders is fine. The lock needs a POSIX file system: the workbenches' shared volume is one, an S3 or object-store
mount is not. Details: `POD.md` step 21.

Two workbenches: while the temporary second workbench is there, part B can use both. One planner, on one
workbench, runs the configs, reads and checks and takes the decisions as the one-slot queue does; one worker on each
workbench runs the GPU jobs the planner publishes, one job at a time. One worker is the normal mode. Commands and
rules: `POD.md` section 4b.

## Defaults the owner can change

- Decided by the reviewers under the owner's delegation of 2 November (D1 to D10): UDR at the 0.6% outsort,
  counted in transactions, decides; the bar is +1 point UDR; T_1 = t x sqrt(sd_pair^2 + 2 x sd_run^2), with t at
  the Welch-Satterthwaite degrees of freedom and the larger measured spread, with no fixed floor. The reviewers
  corrected D2 on 3 November: nothing subtracts the pair term sd_null (the spread step prints it as information
  only); at three seeds the bound uses the comparison's own seed differences, LB_3 = gain - t x sqrt(v_acct +
  s_d^2 / k), with t at k - 1 degrees of freedom; a UDR spread of zero is reported, not a stop, and a one-seed gain
  above zero then goes to seeds 43 and 44. The SELECT check's limit is -k x sqrt(SE^2 + 2 x s_m^2 / n) (k 2.5, 3.5
  when SELECT decides). These k values are working rules for development; how often they give a wrong answer when
  the candidate and the control vary by different amounts is not known.
- Controls between steps: every later step reads against a seed-42 refit of the kept recipe at the candidate's
  micro-batch (`STEPS.yaml` `refit_kept_control: true`, 10 epochs per later step). The base is refit at seeds 43 and
  44 before the first read. The kept checkpoints are never controls.
- Month out (step B) runs by default, the last stage 2 fitting step; the owner may set it off with the bars.
- Permutation importance runs once, on the final kept fit after month out, only when an adding step was adopted.
  Running it after every step is the owner's option (`STEPS.yaml` `importance: every_step`).
- TensorBoard is on: every fit logs its curves to `checkpoints/new_fields/tb/<run>/seed<NN>/` through the queue's
  wrapper. It changes nothing in training (tested). `SETTINGS.yaml` `tensorboard: false` turns it off. It needs the
  `tensorboard` package in the pod's Python; without it a fit runs without logs and says so.
- If RANK-B fails its rank check, the plan's fallback files get the same checks. If they pass, the owner decides
  how they are used; if they fail too, June SELECT decides.
- Optional steps, all off: A3 (until the confirmed list holds a3 rows), pruning (the preflight refuses it until
  its three-seed compression step is built, D4b), and the cyclical calendar (step C).
- Every read says that `external_1_scr` is assumed available at the decision, not certified, until the owner
  records who certified it and when in `SETTINGS.yaml` `external_1_scr_certified` (D3c, the bank's OQ-14).
- The default stage 2 maximum is 170 epochs (180 with a new seed-42 base control).
- Stride is not available for the chosen chunk model (its sequence builder refuses stride with all-position chunks);
  class imbalance stays with the loss options of stage 3.

## Nothing under the trainer's hash changes

The trainer's source hash covers the `.py` files under `fraud/`, except `fraud/experiments/` and `tests/`, plus
`pyproject.toml` and `requirements.txt` (the reorganized rule). Every new `.py` file in this package is under
`fraud/experiments/` or `tests/`. Every other new file is yaml, csv, sh, md or the workbook. No existing file is
edited. The guard proves it on the pod: `$PY fraud/experiments/features/new_fields/nf_guard.py --before <hash>`
prints `unchanged`. Install the package only after the reorganization: under the old rule the new files would
change the hash, and the guard stops.

## What is in the package

- `fraud/experiments/features/new_fields/`: the tools, settings, field map template, decisions table, the feature
  workbook and its builder, and the run sheet (`POD.md`).
- `tests/experiments/features/new_fields/`: the tests, on synthetic data only.
- `fraud/experiments/features/field_screen/` and `tests/experiments/features/field_screen/`: the CPU screen,
  re-delivered, with its run sheet (`field_screen/POD.md`) and its tests. It runs after the field checks:
  `CUDA_VISIBLE_DEVICES= $PY fraud/experiments/features/field_screen/fsc_run.py --dry-run` first, then the full
  command in its run sheet. It writes `checkpoints/new_fields/screen/`: the one-screen `summary.txt`,
  `feature_rank.csv` (one row per field, with a `note` of its flags), `cluster_rank.csv` and `screen.json`. It is
  XGBoost's view, not the transformer's, and decides nothing.
- `FEATURES_AND_TESTING.md`: the owner's step-by-step.
- `COPILOT_PROMPT.md`: the prompt to give Copilot.
- With the zip: `TEST_RESULTS.md`, `changes.diff` and the revised `DESIGN.md`.

## Owner rules the tools follow

- No data suppression, redaction or masking in any output. No privacy or credential checks.
- Checks that refuse wrong inputs, wrong runs, overwrites or a busy GPU are kept.
- Every screen fits one photograph: at most 40 lines of 90 characters. Full tables go to files.
- The feature list is an input file. No tool hard-codes it.
