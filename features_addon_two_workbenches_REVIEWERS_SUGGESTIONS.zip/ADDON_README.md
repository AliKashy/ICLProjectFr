# Two-workbench add-on (reviewers' suggestions)

This add-on is for the features and testing package released on 3 November
(`features_testing_package_REVIEWERS_SUGGESTIONS.zip`). It lets the stage 2 queue run fits on two workbenches at once,
one job per workbench, from one planner. With one workbench, everything works exactly as before.

## What it changes

15 files, at the same paths as in the package:

- Changed: `fraud/experiments/features/new_fields/nf_plan.py`, `nf_report.py`, `nf_start.sh`, `POD.md` (new section
  4b), `README_FIRST.md`, `FEATURES_AND_TESTING.md` (step 14).
- New: `fraud/experiments/features/new_fields/nf_queue.py`, `nf_worker.py`, `nf_worker.sh`, and six test files in
  `tests/experiments/features/new_fields/` (`new_fields_n1_driver.py`, `test_new_fields_n1_planner.py`,
  `test_new_fields_n1_worker.py`, `test_new_fields_n1_together.py`, `test_new_fields_n1_restart.py`,
  `test_new_fields_n1_switch_race.py`).

`changes_addon.diff` holds every changed line. Nothing under the trainer's source hash changes.

## How to apply

1. Copy the 15 files over the installed package, at the same paths.
2. Run the install check, POD.md step 6. Expected: 1158 passed, 4 skipped.

## How it works

- One planner, on one workbench, walks the same plan as the one-slot queue, runs every read itself, and writes the
  decisions in the same order.
- One worker per workbench takes the published GPU jobs, one at a time.
- A candidate and its control at the same seed run on the same workbench. Independent pairs and jobs spread across
  the workbenches.
- A pair is never split. If the workbench of a pair's first arm goes away, the other arm is held for it: it waits
  for that workbench and never runs on the other one. The other jobs go on. The report shows each held arm, the
  workbench it waits for and why. A pair with neither arm started yet goes whole to the workbench that is there.
- Each worker writes a heartbeat every minute. After 15 minutes without one, its job's status is unknown: it is
  never started a second time, and a late finish is counted once.
- Before the second workbench goes away, stop its worker, but only when the report says it may stop: no unfinished
  pair depends on it. Until then `nf_worker.py stop` refuses (exit 4) and names the open pairs. Every finished
  output stays.
- If a workbench goes away while a pair is open, nothing is refitted on its own, no output is thrown away and no arm
  is compared with one trained on the other workbench. The owner chooses: bring the workbench back (start its worker
  again; the held arm runs there), or, only when the report shows the arm on the gone workbench as `UNKNOWN`, rename
  that arm's outputs to `_crashed` and run `nf_plan.py release` on it, so that both arms run again together on the
  remaining workbench. `release` refuses an arm that finished: then only bringing the workbench back is possible.

## Commands

POD.md section 4b has the full table. In short, with `NF=fraud/experiments/features/new_fields`:

- On the planner's workbench: `PY=$PY bash $NF/nf_start.sh --workers`, then `PY=$PY bash $NF/nf_worker.sh`.
- On the second workbench: `PY=$PY bash $NF/nf_worker.sh`.
- On either: `$PY $NF/nf_report.py`.
- Remove the second worker when the report says `safe now`: `$PY $NF/nf_worker.py stop` (refused while a pair is
  open).
- Stop at a job boundary: `$PY $NF/nf_plan.py stop`.
- One workbench only, as before: `PY=$PY bash $NF/nf_start.sh`.

## Notes

A planner can be restarted while its own workbench's worker is training: `nf_start.sh --workers` skips only the
GPU-busy check for the planner, which uses no GPU. Every other check stays.

Only fits are held for their pair's workbench. A score of a finished fit is inference only; if the fit's workbench is
gone, the score runs on the other workbench, and the job record says so (`split_from`).

`safe now` covers the pairs the planner knows at that moment. A control fit that ran on a workbench becomes the first
arm of a pair only when a later read decides to run that seed; if that workbench is gone by then, the candidate is
held until it is back.
