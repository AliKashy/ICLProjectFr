"""The two-workbench planner's test driver (tests only; POD.md section 4b). It runs inside a synthetic world
(new_fields_spine_world), one subprocess per trace: the world's new-fields folder first on sys.path, C.utc_now
frozen to one time, and nf_plan.RUNNER replaced by an in-process runner that runs the world's fake tools,
nf_fit.py and nf_make_configs.py with runpy (argv set, stdout to the job's log, SystemExit as the exit code).
Any other tool (nf_report.py, nf_check_artifact.py) runs as a subprocess, as on the pod.

Two traces:
  one_slot   the real queue loop (nf_plan.py queue --skip-preflight)
  planner    the real planner (nf_plan.py queue --workers --skip-preflight) with stub workers on hosts such as
             wb-one and wb-two, driven between the planner's ticks (nf_plan._pause) on a discrete clock. A stub
             claims the lowest claimable job through the real files (nf_queue.create_once), writes at its claim
             what a starting tool writes (a fit folder with resolved_train_v2.yaml only, a score's .exposure.json
             only), runs the job at its completion time, writes a fresh heartbeat and the done record. Policy fifo
             completes the earliest end first, lifo the latest claim first.

  usage: python new_fields_n1_driver.py <world> <spec.json> <out.json>
  spec:  {"mode": "one_slot" | "planner", "hosts": ["wb-one", "wb-two"], "policy": "fifo", "frozen": "<utc>"}

Tests may also import it inside a world subprocess and drive the pieces themselves (setup, Stubs, collect).
"""
import contextlib
import datetime as dt
import hashlib
import json
import os
import runpy
import subprocess
import sys
import traceback
from pathlib import Path

NF_REL = "fraud/experiments/features/new_fields"
DURATION = {"fit": 10, "score": 1, "timing": 2, "attention": 2, "importance": 5, "downstream": 3}
INPROC = {"nf_read.py", "nf_importance.py", "nf_downstream.py", "nf_time_width.py", "nf_make_configs.py", "nf_fit.py"}
HOST_UUID = {"wb-one": "GPU-11111111-aaaa", "wb-two": "GPU-22222222-bbbb", "wb-three": "GPU-33333333-cccc"}

M = {}           # the world's modules: C (nf_common), Q (nf_queue), P (nf_plan)
WORLD = {}       # root, frozen time
RAN = []         # (job id, command) of every job run, in order
EVENTS = []      # (seq, clock, "start" | "end", job id, host)
CLOCK = [0.0]    # the discrete clock (seconds after the frozen time)


def utc_at(t):
    base = dt.datetime.strptime(WORLD["frozen"], "%Y-%m-%dT%H:%M:%SZ")
    return (base + dt.timedelta(seconds=int(round(t)))).strftime("%Y-%m-%dT%H:%M:%SZ")


def setup(world, frozen):
    """The world's modules, imported from its new-fields folder, with the clock frozen."""
    world = Path(world).resolve()
    os.chdir(world)
    sys.path.insert(0, str(world / NF_REL))
    sys.path.insert(1, str(world))
    import nf_common as C
    import nf_queue as Q
    import nf_plan as P
    C.utc_now = lambda: frozen
    _speed_up(C)
    WORLD.update(root=world, frozen=frozen)
    M.update(C=C, Q=Q, P=P)
    P.RUNNER = runner
    base = dt.datetime.strptime(frozen, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=dt.timezone.utc).timestamp()
    P._now = lambda: base + CLOCK[0]     # the planner's clock is the stubs' discrete clock
    return C, Q, P


def _memo_yaml(load):
    """C.load_yaml, remembered by the file's bytes (the same bytes always parse to the same object; a copy is
    returned). The pure-Python YAML parser is most of a trace's time: the planner walks several times a tick."""
    import pickle
    seen = {}

    def load_yaml(path):
        try:
            raw = Path(path).read_bytes()
        except OSError:
            return load(path)
        key = hashlib.sha256(raw).hexdigest()
        if key not in seen:
            seen[key] = pickle.dumps(load(path))
        return pickle.loads(seen[key])
    return load_yaml


def _speed_up(C):
    """Pure helpers remembered for the length of a trace (the planner walks several times a tick, and a walk
    resolves the same few hundred paths each time): YAML by the file's bytes, C.c2 by NF_OUT, C.rel by the path
    (no link in a world changes during a trace), the layout (fixed in a world). The same for every trace."""
    import nf_layout
    C.load_yaml = _memo_yaml(C.load_yaml)
    c2_orig, rel_orig, detect_orig = C.c2, C.rel, nf_layout.detect
    c2_seen, rel_seen, det = {}, {}, []

    def c2():
        key = os.environ.get("NF_OUT")
        if key not in c2_seen:
            c2_seen[key] = c2_orig()
        return c2_seen[key]

    def rel(path):
        key = str(path)
        if key not in rel_seen:
            rel_seen[key] = rel_orig(path)
        return rel_seen[key]

    def detect(*a, **k):
        if a or k:
            return detect_orig(*a, **k)
        if not det:
            det.append(detect_orig())
        return det[0]
    C.c2, C.rel, nf_layout.detect = c2, rel, detect


def norm(cmd):
    root, py = str(WORLD["root"]), sys.executable
    return [str(x).replace(root, "<W>").replace(py, "<PY>") for x in cmd]


def _event(kind, jid, host, t=None):
    EVENTS.append((len(EVENTS), CLOCK[0] if t is None else t, kind, jid, host))


def inproc(cmd, cwd, log_file, env):
    saved = (dict(os.environ), sys.argv[:], os.getcwd(), sys.path[:])
    os.environ.clear()
    os.environ.update({k: str(v) for k, v in env.items()})
    os.chdir(cwd)
    rc = 0
    try:
        with contextlib.redirect_stdout(log_file), contextlib.redirect_stderr(log_file):
            if cmd[1] == "-m":
                sys.argv = [cmd[2], *cmd[3:]]
                sys.modules.pop(cmd[2], None)
                runpy.run_module(cmd[2], run_name="__main__", alter_sys=True)
            else:
                sys.argv = [cmd[1], *cmd[2:]]
                runpy.run_path(cmd[1], run_name="__main__")
    except SystemExit as e:
        rc = e.code if isinstance(e.code, int) else (0 if e.code is None else 1)
    except Exception:  # noqa: BLE001
        traceback.print_exc(file=log_file)
        rc = 1
    finally:
        os.environ.clear()
        os.environ.update(saved[0])
        sys.argv = saved[1]
        os.chdir(saved[2])
        sys.path[:] = saved[3]
        log_file.flush()
    return rc


def run_cmd(cmd, cwd, log_file, env):
    cmd = [str(x) for x in cmd]
    if cmd[1] == "-m" or Path(cmd[1]).name in INPROC:
        return inproc(cmd, cwd, log_file, env)
    log_file.flush()
    return subprocess.call(cmd, cwd=cwd, stdout=log_file, stderr=subprocess.STDOUT, env=env)


STOP_AFTER = [0]      # a test's stop request (nf_plan.py stop) after this many jobs; 0: none


def _maybe_stop():
    if STOP_AFTER[0] and len(RAN) == STOP_AFTER[0]:
        M["P"].request_stop()


def runner(cmd, cwd, log_file, env):
    """nf_plan.RUNNER: every job the queue or the planner runs itself (on the planner's workbench)."""
    jid = Path(log_file.name).stem
    RAN.append((jid, norm(cmd)))
    _event("start", jid, "planner")
    rc = run_cmd(cmd, cwd, log_file, env)
    _event("end", jid, "planner")
    _maybe_stop()
    return rc


class Deadlock(RuntimeError):
    pass


class Stubs:
    """Stub workers, one per host, on the discrete clock."""

    def __init__(self, hosts, policy="fifo", durations=None):
        C, Q = M["C"], M["Q"]
        self.hosts = list(hosts)
        self.policy = policy
        self.dur = dict(DURATION, **(durations or {}))
        self.busy = {h: None for h in self.hosts}
        self.attempts = []          # finished attempts: {id, attempt, host, start, end, rc}
        self.violations = []
        self.job_sha = {}           # job file name -> sha256 of its bytes when first seen
        self.locks = []             # QUEUE.lock.json records seen
        self.claim_seq = 0
        self.silent = set()         # hosts that write no heartbeat and complete nothing
        self.stopped = set()
        self.pid = os.getpid()
        self.hold_done = set()      # "<job>.a<n>" a test completes by hand (not by the clock)
        self.deadlock = ""
        for h in self.hosts:
            self.record(h, "idle")
        self.C, self.Q = C, Q

    # ---------------------------------------------------------------- files
    def record(self, h, state, job=None):
        C, Q = M["C"], M["Q"]
        Q.write_whole(Q.worker_path(h), {"schema": 1, "host": h, "gpu_uuid": HOST_UUID.get(h, "GPU-0"),
                                         "pid": self.pid, "py": sys.executable, "started_utc": C.utc_now(),
                                         "heartbeat_utc": utc_at(CLOCK[0]), "state": state, "job": job,
                                         "problem": ""})

    def session(self):
        Q, P = M["Q"], M["P"]
        lock = Q.read(P.c2(P.LOCK))
        if lock and lock not in self.locks:
            self.locks.append(lock)
        return lock.get("session") if lock and lock.get("mode") == "planner" else None

    def claimable(self, h, session):
        Q = M["Q"]
        claims = Q.listing("claims")
        out = []
        for (jid, n), p in Q.listing("jobs").items():
            raw = p.read_bytes()
            self.job_sha.setdefault(p.name, hashlib.sha256(raw).hexdigest())
            if (jid, n) in claims:
                continue
            rec = json.loads(raw)
            if rec.get("session") != session or rec.get("host") not in (None, h):
                continue
            out.append((rec["order"], jid, n, p, rec))
        return sorted(out, key=lambda x: (x[0], x[1]))

    def in_flight_makes(self, but):
        """makes of every other attempt that is published or claimed and not done."""
        Q = M["Q"]
        claims, done = Q.listing("claims"), Q.listing("done")
        out = []
        for key, p in Q.listing("jobs").items():
            if key == but or key in done:
                continue
            c = Q.read(claims[key]) if key in claims else None
            if c and c.get("withdrawn"):
                continue
            out += [(key[0], m) for m in (Q.read(p) or {}).get("makes") or []]
        return out

    def claim(self, h, jid, n, path, rec):
        C, Q, P = M["C"], M["Q"], M["P"]
        raw = path.read_bytes()
        for need in rec.get("needs") or []:
            if not (C.ROOT / need).exists():
                self.violations.append(f"{jid}.a{n} claimed while its need {need} does not exist")
            for other, m in self.in_flight_makes((jid, n)):
                if P.covers(m, need):
                    self.violations.append(f"{jid}.a{n} claimed while {other} (in flight) makes its need {need}")
        won = Q.create_once(Q.claim_path(jid, n), {
            "schema": 1, "id": jid, "attempt": n, "by": "worker", "host": h, "gpu_uuid": HOST_UUID.get(h, "GPU-0"),
            "worker_pid": self.pid, "claimed_utc": utc_at(CLOCK[0]), "job_sha256": hashlib.sha256(raw).hexdigest()})
        if not won:
            return False
        j = rec["job"]
        if j["kind"] == "fit":
            d = C.ROOT / rec["makes"][0]
            d.mkdir(parents=True, exist_ok=True)
            cfg = P._arg(j["cmd"], "--config")
            (d / "resolved_train_v2.yaml").write_text((C.ROOT / cfg).read_text())
        elif j["kind"] == "score":
            out = C.ROOT / P._arg(j["cmd"], "--out")
            out.parent.mkdir(parents=True, exist_ok=True)
            Path(str(out) + ".exposure.json").write_text("{}")
        self.claim_seq += 1
        dur = self.dur.get(j["kind"], 1)
        self.busy[h] = {"id": jid, "attempt": n, "rec": rec, "start": CLOCK[0], "end": CLOCK[0] + dur,
                        "seq": self.claim_seq}
        _event("start", jid, h)
        self.record(h, "running", f"{jid}.a{n}")
        return True

    def complete(self, h):
        C, Q = M["C"], M["Q"]
        b = self.busy[h]
        CLOCK[0] = max(CLOCK[0], b["end"])
        j = b["rec"]["job"]
        RAN.append((j["id"], norm(j["cmd"])))
        env = dict(os.environ, CUDA_VISIBLE_DEVICES=HOST_UUID.get(h, "GPU-0"), NF_PY=sys.executable)
        Path(j["log"]).parent.mkdir(parents=True, exist_ok=True)
        with open(j["log"], "a", encoding="utf-8") as lf:
            lf.write(f"# {C.utc_now()} {' '.join(j['cmd'])}\n# worker {h} gpu {HOST_UUID.get(h)} attempt "
                     f"{b['attempt']}\n")
            lf.flush()
            rc = run_cmd(j["cmd"], C.ROOT, lf, env)
        Q.write_whole(Q.done_path(j["id"], b["attempt"]), {
            "schema": 1, "id": j["id"], "attempt": b["attempt"], "host": h, "gpu_uuid": HOST_UUID.get(h, "GPU-0"),
            "worker_pid": self.pid, "child_pid": 0, "started_utc": utc_at(b["start"]), "ended_utc": utc_at(b["end"]),
            "rc": rc, "ran": True, "note": ""})
        _event("end", j["id"], h, b["end"])
        self.attempts.append({"id": j["id"], "attempt": b["attempt"], "host": h, "start": b["start"],
                              "end": b["end"], "rc": rc, "kind": j["kind"]})
        self.busy[h] = None
        self.record(h, "idle")
        _maybe_stop()
        return rc

    # ---------------------------------------------------------------- one step between two planner ticks
    def step(self):
        session = self.session()
        claimed = False
        for h in self.hosts:
            if self.busy[h] is None and h not in self.silent and h not in self.stopped:
                for _, jid, n, path, rec in self.claimable(h, session):
                    if self.claim(h, jid, n, path, rec):
                        claimed = True
                        break
        if claimed:
            return "claimed"
        running = [h for h in self.hosts if self.busy[h] is not None and h not in self.silent
                   and f"{self.busy[h]['id']}.a{self.busy[h]['attempt']}" not in self.hold_done]
        if not running:
            self.deadlock = "the planner waits, and no stub worker has anything to claim or finish"
            raise Deadlock("the planner waits, and no stub worker has anything to claim or finish")
        if self.policy == "lifo":
            h = max(running, key=lambda x: self.busy[x]["seq"])
        else:
            h = min(running, key=lambda x: (self.busy[x]["end"], self.busy[x]["seq"]))
        self.complete(h)
        return "completed"


class Planner:
    """The planner's pieces, driven by a test: a start (or restart) as queue --workers makes it, then ticks with the
    stubs acting between them."""

    def __init__(self, hosts=("wb-one", "wb-two"), policy="fifo", stubs=None):
        self.stubs = stubs or Stubs(hosts, policy)
        self.final = None
        self.start()

    def start(self):
        P, Q = M["P"], M["Q"]
        self.sess = P.Session()
        P.acquire_lock(os.getpid(), {"mode": "planner", "session": self.sess.id})
        self.open_claims = P.settle_old_jobs(self.sess.id)
        if Q.stop_path().exists():
            Q.stop_path().unlink()
        return self.sess

    def tick(self):
        r = M["P"].planner_tick(self.sess)
        if r in M["P"].FINAL:
            self.final = r
        return r

    def run(self, until=None, limit=5000):
        """Ticks (the stubs act on every wait) until the planner ends, or until(self) holds. Returns the last tick's
        result."""
        r = None
        for _ in range(limit):
            if until is not None and until(self):
                return r
            r = self.tick()
            if r in M["P"].FINAL:
                return r
            if until is not None and until(self):
                return r
            if r == "wait":
                self.stubs.step()
        raise RuntimeError("the planner did not end")

    def rc(self):
        C = M["C"]
        s = self.sess
        return {"done": C.OK if s.done_rc is None else s.done_rc, "stop": C.STOP, "failed": s.failed_rc or C.CRASH,
                "stopped": C.OK}[self.final]

    def status(self):
        return M["P"].queue_status()


def lines(prefix):
    """queue.log lines that start with prefix."""
    p = M["P"].c2("queue.log")
    return [ln for ln in (p.read_text().splitlines() if p.is_file() else []) if ln.startswith(prefix)]


def collect(world, rc, stubs=None, extra=None):
    """What a trace records."""
    world = Path(world)
    c2 = world / "checkpoints" / "new_fields"

    def j(p):
        try:
            return json.loads(p.read_text())
        except (OSError, ValueError):
            return None
    reads = {p.name: j(p) for p in sorted((c2 / "reads").glob("*.json")) if p.name != "preflight.json"} \
        if (c2 / "reads").is_dir() else {}
    dec = (c2 / "DECISIONS.log").read_text() if (c2 / "DECISIONS.log").is_file() else ""
    kd = world / NF_REL / "KEEP_DECISIONS.csv"
    qd = c2 / "queue"
    job_recs = []
    if qd.is_dir() and (qd / "jobs").is_dir():
        for p in sorted((qd / "jobs").glob("*.json")):
            r = j(p) or {}
            job_recs.append({k: r.get(k) for k in ("id", "attempt", "host", "pair", "needs", "makes", "session",
                                                   "order")} | {"kind": (r.get("job") or {}).get("kind"),
                                                                 "file": p.name,
                                                                 "sha256": hashlib.sha256(p.read_bytes()).hexdigest()})
    folder = lambda f: {p.name: j(p) for p in sorted((qd / f).glob("*.json"))} if (qd / f).is_dir() else {}  # noqa
    out = {
        "rc": rc,
        "jobs": [[a, b] for a, b in RAN],
        "reads": reads,
        "decisions": [ln.split(" ", 1)[1] if " " in ln else ln for ln in dec.splitlines()],
        "kept": j(c2 / "KEPT.json"),
        "keep_decisions": kd.read_text() if kd.is_file() else None,
        "queue_state": j(c2 / "queue_state.json"),
        "queue_log": (c2 / "queue.log").read_text().splitlines() if (c2 / "queue.log").is_file() else [],
        "events": EVENTS,
        "job_records": job_recs,
        "claims": folder("claims"),
        "done": folder("done"),
        "queue_exists": qd.exists(),
    }
    if stubs is not None:
        out.update(deadlock=stubs.deadlock, attempts=stubs.attempts, violations=stubs.violations, locks=stubs.locks,
                   job_sha_first=stubs.job_sha,
                   makespan=max([a["end"] for a in stubs.attempts], default=0),
                   gpu_sum=sum(stubs.dur.get(a["kind"], 1) for a in stubs.attempts))
    out.update(extra or {})
    return out


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    world, spec_path, out_path = Path(argv[0]), Path(argv[1]), Path(argv[2])
    spec = json.loads(spec_path.read_text())
    C, Q, P = setup(world, spec["frozen"])
    stubs = None
    err = ""
    STOP_AFTER[0] = int(spec.get("stop_after") or 0)
    if spec["mode"] == "one_slot":
        args = ["queue", "--skip-preflight", "--queue-pid", str(os.getpid())]
    else:
        Q.UNKNOWN_AFTER_SECONDS = 1e9       # the frozen clock: heartbeats never age in a trace
        stubs = Stubs(spec.get("hosts") or ["wb-one"], spec.get("policy", "fifo"), spec.get("durations"))
        P._pause = stubs.step
        args = ["queue", "--workers", "--skip-preflight", "--queue-pid", str(os.getpid())]
    try:
        rc = P.main(args)
    except Deadlock as e:
        rc, err = "deadlock", str(e)
    res = collect(world, rc, stubs, {"error": err, "spec": spec})
    out_path.write_text(json.dumps(res, indent=1, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
