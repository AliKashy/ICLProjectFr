"""Mode switches must notice a worker winning an old job during withdrawal."""
from test_new_fields_n1_planner import scenario, world


RACE = '''
from types import SimpleNamespace
import os
j = {"id": "fit_demo_seed42", "kind": "fit", "gpu": True,
     "cmd": ["python", "nf_fit.py", "--config", "c.yaml",
             "output.checkpoint_dir=checkpoints/new_fields/runs/demo/seed42"],
     "log": "checkpoints/new_fields/logs/demo.log"}
Q.write_whole(Q.job_path(j["id"], 1), {
    "id": j["id"], "attempt": 1, "session": "old", "job": j,
    "needs": [], "makes": ["checkpoints/new_fields/runs/demo/seed42"]})
original = P.withdraw
def racing_withdraw(jid, attempt, reason):
    # The worker wins the actual exclusive claim between the planner's snapshot and withdrawal.
    Q.create_once(Q.claim_path(jid, attempt), {
        "id": jid, "attempt": attempt, "by": "worker", "host": "wb-two", "worker_pid": 123})
    return original(jid, attempt, reason)
P.withdraw = racing_withdraw
'''


def test_losing_withdrawal_returns_the_new_worker_claim(tmp_path):
    w = world(tmp_path / "race", {})
    out = scenario(w, RACE + '''
OUT["open"] = P.settle_old_jobs(None)
OUT["actual"] = P.queue_status()["attempts"][j["id"]]["state"]
''')
    assert out["actual"] == "unknown"
    assert out["open"] == [{"id": "fit_demo_seed42", "attempt": 1,
                             "host": "wb-two", "state": "unknown"}]


def test_one_slot_switch_refuses_the_racing_claim_before_preflight(tmp_path):
    w = world(tmp_path / "switch", {})
    out = scenario(w, RACE + '''
calls = []
def preflight():
    calls.append("preflight")
    return C.OK
P.preflight = preflight
P.next_job = lambda ctx: {"kind": "done", "notes": []}
OUT["rc"] = P.queue(SimpleNamespace(queue_pid=os.getpid(), workers=False,
                                   skip_preflight=False, max_jobs=0))
OUT["calls"] = calls
OUT["claim"] = Q.read(Q.claim_path(j["id"], 1))
''')
    assert out["rc"] == 4
    assert out["calls"] == []
    assert out["claim"]["by"] == "worker"


def test_successful_withdrawal_remains_available_for_one_slot(tmp_path):
    w = world(tmp_path / "unclaimed", {})
    out = scenario(w, RACE + '''
P.withdraw = original
OUT["open"] = P.settle_old_jobs(None)
OUT["actual"] = P.queue_status()["attempts"][j["id"]]["state"]
''')
    assert out == {"open": [], "actual": "withdrawn"}
