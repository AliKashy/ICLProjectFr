"""The two-workbench planner (POD.md section 4b): nf_plan.py queue --workers publishes GPU jobs as files under
checkpoints/new_fields/queue/, one worker per workbench runs them, and the decisions stay those of the one-slot
queue. Synthetic world and stub workers on a discrete clock (new_fields_n1_driver.py); CPU only, no bank data.

T2 (P1) compares, path by path, the planner with one worker (fifo) and with two workers (fifo and lifo) against the
one-slot queue. The default set covers every outcome of every step: the 36 (A1, A2) pairs on RANK-B with month out
B's outcome taken in turn for each kept state it meets, the 16 pairs on SELECT the same way, and 6 paths with a new
seed-42 base control. NF_T2_ALL=1 runs every path (216 on RANK-B and 64 on SELECT, with both control cases)."""
import ast
import concurrent.futures as cf
import datetime as dt
import hashlib
import itertools
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import threading
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from new_fields_checks_helpers import load  # noqa: E402
from new_fields_spine_world import NF_REL, NF_SRC, default_map, env, make_world, run  # noqa: E402

DRIVER = HERE / "new_fields_n1_driver.py"
STATUS = {"f_code": "PASS", "f_cnt24": "FLAG", "f_amt": "PASS"}
P1_PATCH = {"learning_rate": 0.001, "control_p1_owner_yes": {"by": "the reviewers (test)", "on": "2026-11-04"}}
FROZEN = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
C2_REL = "checkpoints/new_fields"


# ------------------------------------------------------------------ worlds and traces

def world(tmp, decisions=None, p1=False, sel=False, **kw):
    """A synthetic world with nf_queue.py and nf_worker.py copied in (the shared helpers' file list predates them;
    the report reads the open seed pairs with nf_worker.open_pairs)."""
    tmp = Path(tmp)
    tmp.mkdir(parents=True, exist_ok=True)
    w = make_world(tmp, map_rows=default_map(), field_status=STATUS, settings_patch=(P1_PATCH if p1 else None),
                   rank_check=("FAIL" if sel else "PASS"), **kw)
    for f in ("nf_queue.py", "nf_worker.py"):
        shutil.copy(NF_SRC / f, w / NF_REL / f)
    (tmp / "decisions.json").write_text(json.dumps(decisions or {}))
    return w


def c2(w):
    return w / "checkpoints" / "new_fields"


def qlog(w):
    p = c2(w) / "queue.log"
    return p.read_text() if p.is_file() else ""


def drive(w, mode="planner", hosts=("wb-one", "wb-two"), policy="fifo", timeout=900, **extra):
    """One trace through new_fields_n1_driver.py, in its own process; returns what it recorded."""
    tmp = w.parent
    n = len(list(tmp.glob("spec*.json")))
    spec = {"mode": mode, "hosts": list(hosts), "policy": policy, "frozen": FROZEN}
    spec.update({k: v for k, v in extra.items() if k in ("stop_after", "durations")})
    sp, op = tmp / f"spec{n}.json", tmp / f"out{n}.json"
    sp.write_text(json.dumps(spec))
    envx = {k: v for k, v in extra.items() if k.isupper()}
    r = subprocess.run([sys.executable, str(DRIVER), str(w), str(sp), str(op)], cwd=w, capture_output=True,
                       text=True, env=env(w, tmp, FAKE_DECISIONS=tmp / "decisions.json", **envx), timeout=timeout)
    assert r.returncode == 0 and op.is_file(), r.stdout[-2000:] + r.stderr[-4000:]
    return json.loads(op.read_text())


PRELUDE = '''
import json, os, sys
sys.path.insert(0, {tests!r})
import new_fields_n1_driver as D
C, Q, P = D.setup({world!r}, {frozen!r})
OUT = {{}}
'''


def scenario(w, code, timeout=600, **envx):
    """Runs test code inside the world, with the driver's pieces (D.Planner, D.Stubs) and the world's modules
    (C, Q, P); the code fills OUT, which is returned."""
    tmp = w.parent
    n = len(list(tmp.glob("scenario*.py")))
    sp, op = tmp / f"scenario{n}.py", tmp / f"scenario{n}.json"
    now = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")    # fresh heartbeats
    sp.write_text(PRELUDE.format(tests=str(HERE), world=str(w), frozen=now) + code +
                  f"\njson.dump(OUT, open({str(op)!r}, 'w'), default=str)\n")
    r = subprocess.run([sys.executable, str(sp)], cwd=w, capture_output=True, text=True,
                       env=env(w, tmp, FAKE_DECISIONS=tmp / "decisions.json", **envx), timeout=timeout)
    assert r.returncode == 0 and op.is_file(), r.stdout[-3000:] + r.stderr[-5000:]
    return json.loads(op.read_text())


# ------------------------------------------------------------------ the paths (T2)

STEPS = ("A1", "A2", "B")
RB = ("K1", "A1p", "A1f", "K3", "A3p", "A3f")       # RANK-B outcomes of one step
SEL = ("K1", "A1", "K3", "A3")                      # SELECT outcomes (the rank check failed)


def outcome(step, o):
    """The fake reader's decisions for one step's outcome."""
    keep = "KEEP MONTH" if step == "B" else "KEEP THE CONTROL"
    adopt = "MONTH OUT" if step == "B" else "ADOPT"
    pend = f"{adopt} (pending the SELECT check)"
    seeds = "RUN SEEDS 43 AND 44"
    return {
        "K1": {f"{step}_1seed": keep},
        "A1p": {f"{step}_1seed": pend, f"{step}_select": "PASS"},
        "A1f": {f"{step}_1seed": pend, f"{step}_select": "FAIL"},
        "K3": {f"{step}_1seed": seeds, f"{step}_3seed": keep},
        "A3p": {f"{step}_1seed": seeds, f"{step}_3seed": pend, f"{step}_select": "PASS"},
        "A3f": {f"{step}_1seed": seeds, f"{step}_3seed": pend, f"{step}_select": "FAIL"},
        "A1": {f"{step}_1seed": adopt},
        "A3": {f"{step}_1seed": seeds, f"{step}_3seed": adopt},
    }[o]


def kept_after(state, o):
    """The kept state month out B meets: (base or adopted, one or three seeds)."""
    return {"A1p": "one_seed", "A1": "one_seed", "A3p": "three_seed", "A3": "three_seed"}.get(o, state)


def path_name(sel, p1, outs):
    return ("sel_" if sel else "rb_") + "_".join(outs) + ("__p1" if p1 else "")


def make_path(sel, p1, outs):
    d = {}
    for s, o in zip(STEPS, outs):
        d.update(outcome(s, o))
    return {"name": path_name(sel, p1, outs), "sel": sel, "p1": p1, "outs": list(outs), "decisions": d}


def default_paths():
    out = []
    for sel, oset in ((False, RB), (True, SEL)):
        turn = {}
        for a1, a2 in itertools.product(oset, oset):
            state = kept_after(kept_after("base", a1), a2)
            i = turn.get(state, 0)
            turn[state] = i + 1
            out.append(make_path(sel, False, (a1, a2, oset[i % len(oset)])))
    for outs in (("K1", "K1", "K1"), ("A1p", "K1", "A1p"), ("A3p", "A3p", "A3p"), ("K3", "A1f", "K3"),
                 ("A1f", "A3p", "A3f"), ("A3f", "K3", "A1p")):
        out.append(make_path(False, True, outs))
    return out


def all_paths():
    out = []
    for p1 in (False, True):
        for sel, oset in ((False, RB), (True, SEL)):
            for outs in itertools.product(oset, repeat=3):
                out.append(make_path(sel, p1, outs))
    return out


PATHS = all_paths() if os.environ.get("NF_T2_ALL") == "1" else default_paths()
MODES = (("one", "one_slot", ("wb-one",), "fifo"), ("w1", "planner", ("wb-one",), "fifo"),
         ("w2", "planner", ("wb-one", "wb-two"), "fifo"), ("w2lifo", "planner", ("wb-one", "wb-two"), "lifo"))
_TRACES = {}
_LOCK = threading.Lock()


def _one_trace(base, path, mode):
    key, m, hosts, policy = mode
    w = world(base / path["name"] / key, path["decisions"], p1=path["p1"], sel=path["sel"])
    return drive(w, m, hosts, policy)


@pytest.fixture(scope="module")
def traces(tmp_path_factory):
    """Every trace of every path, run in parallel once per module (one process each)."""
    with _LOCK:
        if not _TRACES:
            base = tmp_path_factory.mktemp("t2")
            jobs = [(p, m) for p in PATHS for m in MODES]
            with cf.ThreadPoolExecutor(max_workers=2 * (os.cpu_count() or 2)) as ex:    # they wait on files
                futs = {ex.submit(_one_trace, base, p, m): (p["name"], m[0]) for p, m in jobs}
                for f in cf.as_completed(futs):
                    name, key = futs[f]
                    _TRACES.setdefault(name, {})[key] = f.result()
    return _TRACES


# ------------------------------------------------------------------ P0: the walk is frozen

FROZEN_SHA = {
    "walk": "de01de97df20957b", "read_decide": "a4aab72a4f02c7ce", "special_steps": "9e815a34d2877122",
    "control_refit": "7aa48968003d7cc1", "confirm_controls": "b7b577ef0e997da9", "membership": "647c7548ad01e048",
    "group_names": "7d5accd9a7b0f720", "classify": "943033761c91a243", "decision": "4377a447fdb9afd1",
    "read_job": "3d4bddbe5653eefb", "read_path": "2cb90311f9f3ecab", "read_rows": "019806a59db6601d",
    "run_table": "7de6dbd18b0c34ae", "lift_table": "e3370367361a54e9", "inputs_record": "b959327e4edaf082",
    "settings_sha_for_reads": "bf09c03142090018", "score_state": "f02b52a4e85505f1",
    "fit_state": "7ff640a442e9f13d", "config_job": "315cbb9ea27d977b", "timing_job": "5a7ce01748bef179",
    "scoring_timing_job": "4bc9e102932102f4", "attention_job": "46daab44a088e0f4",
    "importance_job": "266ee7fd97679eb6", "downstream_job": "9ca7b1e48be9e20f",
    "check_config_inputs": "58d3fb8131fea886", "base_control": "f1e829d6133532f2",
    "stage1_training_check": "0f72727729a09ed6", "kept_controls_valid": "a998b66403fe42e3",
    "artifact_state": "ef628f7f56ba08ab", "artifact_recheck": "3cbb9aa176f43ea7",
    "_memory_rule_base": "ee3238209e487716", "refit_kept_control": "981592ba617c4b15",
    "refit_base_controls": "ca7c9e7293d632fd", "prune_list": "900135b83cf8da82",
    "month_out_decision_row": "5f5fbf70b1e50f33", "_write_kept": "16e32c97fb226b76", "log_once": "126981185c8abbee",
    "importance_timing": "c47662c6479ef664", "importance_wait": "b304bb8e8c94bb8d",
    "importance_args": "92bc073abb451154", "adding_steps": "92e515b21b4c38d2", "first_step_run": "7491f0444e162df8",
    "fit_entry": "2649faea1a7f0e09", "kept_seed_entry": "935a650ba00be770", "score_out": "f79d4e8f9cfd0cbb",
    "receipt_of": "39d071167c020c85", "next_job": "d28963c26370ede5", "job": "98fc1a3e0aaf7fa2",
    "owner_alive": "97a5a55e3bdca4aa", "other_host": "a50e03cd685ebffc", "trainer_alive": "dd04e7466c866dac",
    "trainer_host": "627a280f3f294663", "queue_alive": "66a594cc174e70ae", "_create_exclusive": "3f34c417cf229863",
    "_lock_snapshot": "ebc8ae9b1346e781", "microbatch_entry": "f3a1b35ed13f1474", "fit_micro": "a9626377ac819a8d",
    "config_micro": "b9e0c74f523a1c6e", "microbatch_source": "abbab9f93097bc8e",
    "microbatch_config_problems": "52ac531cf78514ff", "stage1_control": "435b1b951a651d3d",
    "control_lr": "a9aa6a1fb8c6f5ac", "_seed": "91b16d7137f11de3",
}


def function_sha(src, name):
    """SHA-256 of a top-level function's source text, from its def line to its last line, as ast gives them."""
    lines = src.splitlines(keepends=True)
    node = next(n for n in ast.parse(src).body if isinstance(n, ast.FunctionDef) and n.name == name)
    return hashlib.sha256("".join(lines[node.lineno - 1:node.end_lineno]).encode()).hexdigest()


def test_p0_the_walk_and_its_helpers_are_unchanged():
    """Rule: the decision logic does not change. Each of these functions is byte for byte as at 8a440a2; only
    fit_job, score_job and _memory_rule changed among the walk's helpers."""
    src = (NF_SRC / "nf_plan.py").read_text(encoding="utf-8")
    changed = [n for n, h in FROZEN_SHA.items() if function_sha(src, n)[:16] != h]
    assert not changed, changed
    assert len(FROZEN_SHA) == 63
    mr = next(n for n in ast.parse(src).body if isinstance(n, ast.FunctionDef) and n.name == "_memory_rule")
    first = mr.body[1]       # after the docstring: the one added line
    assert ast.unparse(first) == "_record_pair(run, ctl, seed)"


# ------------------------------------------------------------------ P1: T2, the planner decides as the one slot does

def _jobs(t):
    return sorted(tuple([a, tuple(b)]) for a, b in t["jobs"])


def same_as_one_slot(one, t):
    """(a) and (b) of T2: the differences between a planner trace and the one-slot trace."""
    diff = []
    if _jobs(one) != _jobs(t):
        a, b = set(_jobs(one)), set(_jobs(t))
        diff.append(f"jobs: only one slot {sorted(a - b)[:3]}, only planner {sorted(b - a)[:3]}")
    if len(t["jobs"]) != len({j[0] for j in t["jobs"]}):
        diff.append("a job ran twice")
    for k in ("reads", "decisions", "kept", "keep_decisions", "queue_state", "rc"):
        if one[k] != t[k]:
            if isinstance(one[k], dict) and isinstance(t[k], dict):
                ks = sorted(x for x in set(one[k]) | set(t[k]) if one[k].get(x) != t[k].get(x))
                diff.append(f"{k} differ: {ks[:4]}")
            else:
                diff.append(f"{k} differ: {str(one[k])[:300]} != {str(t[k])[:300]}")
    return diff


def _home_of_score(rec):
    for n in rec.get("needs") or []:
        m = re.match(rf"^{C2_REL}/runs/([^/]+)/(seed\d+)/best\.ckpt$", n)
        if m:
            return f"fit_{m.group(1)}_{m.group(2)}"
    return None


def planner_checks(t):
    """(c) to (f) of T2 on one planner trace."""
    bad = []
    if t.get("deadlock"):
        bad.append(t["deadlock"])
    by_host = {}
    for a in t["attempts"]:
        by_host.setdefault(a["host"], []).append(a)
    for h, xs in by_host.items():
        xs.sort(key=lambda a: (a["start"], a["end"]))
        for x, y in zip(xs, xs[1:]):
            if y["start"] < x["end"]:
                bad.append(f"(c) {x['id']} and {y['id']} overlap on {h}")
    bad += [f"(d) {v}" for v in t["violations"]]
    # (e) a step's config jobs start after the previous step's last read
    ev = t["events"]
    for prev, cur in (("A1", "nf_a2"), ("A2", "nf_b"), ("A1", "nf_ka2"), ("A2", "nf_kb")):
        reads = [e[0] for e in ev if e[2] == "end" and e[3].startswith(f"read_{prev}_")]
        starts = [e[0] for e in ev if e[2] == "start" and e[3] == f"config_{cur}"]
        if starts and reads and min(starts) < max(reads):
            bad.append(f"(e) config_{cur} started before read_{prev}'s last read")
    # (f) both arms of a seed pair on one host, each score on its fit's host, no split
    host = {a["id"]: a["host"] for a in t["attempts"]}
    for r in t["job_records"]:
        partner = (r.get("pair") or {}).get("partner")
        if r["kind"] == "fit" and partner in host and r["id"] in host and host[partner] != host[r["id"]]:
            bad.append(f"(f) {r['id']} on {host[r['id']]}, its pair {partner} on {host[partner]}")
        home = _home_of_score(r) if r["kind"] != "fit" else None
        if home in host and r["id"] in host and host[home] != host[r["id"]]:
            bad.append(f"(f) {r['id']} on {host[r['id']]}, its fit {home} on {host[home]}")
    bad += [f"(f) {ln}" for ln in t["queue_log"] if ln.startswith("split ")]
    # in flight at once: never two jobs whose makes overlap
    makes = {r["id"]: r["makes"] or [] for r in t["job_records"]}
    for x, y in itertools.combinations(t["attempts"], 2):
        if x["start"] < y["end"] and y["start"] < x["end"]:
            if any(a == b or b.startswith(a + "/") or a.startswith(b + "/")
                   for a in makes.get(x["id"], []) for b in makes.get(y["id"], [])):
                bad.append(f"{x['id']} and {y['id']} ran at once and make the same files")
    return bad


@pytest.mark.parametrize("path", [p["name"] for p in PATHS])
def test_p1_t2_planner_equals_one_slot(traces, path):
    """T2: per path, the planner with one worker (fifo) and with two workers (fifo, lifo) runs the same jobs with
    the same commands and writes the same reads, run tables, inputs records, DECISIONS.log lines in order,
    KEPT.json, KEEP_DECISIONS.csv and queue_state.json, with the same exit code, as the one-slot queue; no two
    jobs overlap on one host; every need exists at a claim; configs wait for the previous step's reads; pairs and
    scores stay on one host; two workers finish sooner than one, and one worker takes the sum of the GPU times."""
    tr = traces[path]
    one = tr["one"]
    assert one["rc"] in (0, 5), (one["rc"], one["queue_log"][-5:])
    assert not one["queue_exists"]          # P9: a one-slot run writes nothing under C2/queue/
    problems = []
    for key in ("w1", "w2", "w2lifo"):
        problems += [f"{key}: {d}" for d in same_as_one_slot(one, tr[key]) + planner_checks(tr[key])]
    assert tr["w1"]["makespan"] == tr["w1"]["gpu_sum"], (tr["w1"]["makespan"], tr["w1"]["gpu_sum"])
    assert tr["w2"]["makespan"] < tr["w1"]["makespan"], (tr["w2"]["makespan"], tr["w1"]["makespan"])
    assert not problems, problems


def test_p1_the_default_set_covers_every_outcome_of_every_step():
    """The default paths hold every outcome of A1 and A2 in every pair, and every outcome of month out B after
    every kept state it can meet (the base, one adopted seed, three adopted seeds), on RANK-B and on SELECT."""
    if os.environ.get("NF_T2_ALL") == "1":
        assert len(PATHS) == 2 * (6 ** 3 + 4 ** 3)
        return
    for sel, oset in ((False, RB), (True, SEL)):
        ps = [p for p in PATHS if p["sel"] == sel and not p["p1"]]
        assert {tuple(p["outs"][:2]) for p in ps} == set(itertools.product(oset, oset))
        seen = {(kept_after(kept_after("base", p["outs"][0]), p["outs"][1]), p["outs"][2]) for p in ps}
        assert seen == set(itertools.product(("base", "one_seed", "three_seed"), oset)), sorted(seen)
    assert sum(1 for p in PATHS if p["p1"]) == 6


# ------------------------------------------------------------------ P2: rule 1, one writer of the decisions

DEAD = 999999999


def test_p2_rule1_the_planner_alone_writes_decisions(traces, tmp_path):
    """No GPU job makes reads/, DECISIONS.log, queue_state.json or KEPT.json; the planner's lock record has its
    mode and a session; a second planner and a one-slot start are refused while a planner holds the lock, and so
    is a start while another workbench holds it."""
    forbidden = (f"{C2_REL}/DECISIONS.log", f"{C2_REL}/queue_state.json", f"{C2_REL}/KEPT.json")
    for name, tr in traces.items():
        for key in ("w1", "w2", "w2lifo"):
            t = tr[key]
            for r in t["job_records"]:
                bad = [m for m in r["makes"] if m.startswith(f"{C2_REL}/reads/") or m in forbidden]
                assert not bad, (name, key, r["id"], bad)
            assert any(lk.get("mode") == "planner" and re.fullmatch(r"[0-9a-f]{12}", str(lk.get("session")))
                       and lk.get("hostname") == socket.gethostname() for lk in t["locks"]), (name, t["locks"])
    w = world(tmp_path / "x")
    lock = c2(w) / "QUEUE.lock.json"
    held = {"pid": os.getpid(), "hostname": socket.gethostname(), "utc": FROZEN, "mode": "planner",
            "session": "a" * 12}
    lock.write_text(json.dumps(held))
    for extra in (["--workers"], []):
        r = run(w, tmp_path / "x", "nf_plan.py", "queue", "--skip-preflight", "--queue-pid", str(DEAD), *extra)
        assert r.returncode == 4 and "another queue holds" in " ".join(r.stderr.split()), (extra, r.stderr)
    assert json.loads(lock.read_text()) == held
    lock.write_text(json.dumps({"pid": 4242, "hostname": "workbench-two", "utc": FROZEN}))
    r = run(w, tmp_path / "x", "nf_plan.py", "queue", "--workers", "--skip-preflight", "--queue-pid", str(DEAD))
    assert r.returncode == 4 and "workbench-two" in r.stderr and "one workbench only" in " ".join(r.stderr.split())
    assert not (c2(w) / "queue").exists()


# ------------------------------------------------------------------ P3: rule 3, a claim is made once

def _job_rec(P, jid, kind="score", session="s" * 12, host=None, order=1, cmd=None):
    j = P.job(jid, "S.2", kind, cmd or [sys.executable, "-c", "pass"], gpu=True)
    return {"schema": 1, "id": jid, "attempt": 1, "session": session, "order": order, "published_utc": FROZEN,
            "job": j, "needs": [], "makes": [], "host": host, "pair": None}


def test_p3_rule3_one_claim_wins_and_job_files_never_change(traces, tmp_path, monkeypatch):
    """Two workers racing for one attempt: one wins. A withdrawal racing a claim: one wins, and a withdrawn
    attempt is never claimed or counted as in flight (the next attempt is published instead). A job file's bytes
    never change after publication (every P1 trace)."""
    monkeypatch.setenv("NF_OUT", str(tmp_path / "c2"))
    P = load("nf_plan")
    Q = P.Q
    for i in range(25):
        path = Q.claim_path(f"fit_x_seed{i}", 1)
        gate, wins = threading.Barrier(2), []

        def go(h, path=path, gate=gate, wins=wins):
            gate.wait()
            wins.append((h, Q.create_once(path, {"host": h})))
        ts = [threading.Thread(target=go, args=(h,)) for h in ("wb-one", "wb-two")]
        [t.start() for t in ts]
        [t.join() for t in ts]
        assert sorted(w for _, w in wins) == [False, True]
        assert json.loads(path.read_text())["host"] == next(h for h, w in wins if w)
    withdrawn = claimed = 0
    for i in range(25):
        jid = f"score_y{i}__rank_b"
        Q.write_whole(Q.job_path(jid, 1), _job_rec(P, jid))
        gate, res = threading.Barrier(2), {}

        def wd(jid=jid, gate=gate, res=res):
            gate.wait()
            res["planner"] = P.withdraw(jid, 1, "a test")

        def cl(jid=jid, gate=gate, res=res):
            gate.wait()
            res["worker"] = Q.create_once(Q.claim_path(jid, 1), {"schema": 1, "id": jid, "attempt": 1,
                                                                "by": "worker", "host": "wb-one", "worker_pid": 7})
        ts = [threading.Thread(target=wd), threading.Thread(target=cl)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        assert sorted(res.values()) == [False, True], res
        st = P.queue_status()["attempts"][jid]
        if res["planner"]:
            withdrawn += 1
            assert st["state"] == "withdrawn" and P.next_attempt(jid) == 2
            assert jid not in P._inflight(P.queue_status())
            assert f"withdraw {jid}.a1: a test" in (tmp_path / "c2" / "queue.log").read_text()
        else:
            claimed += 1
            assert st["state"] == "unknown"        # a worker's claim, and no live record of that worker here
    assert withdrawn + claimed == 25
    for name, tr in traces.items():
        for key in ("w1", "w2", "w2lifo"):
            for r in tr[key]["job_records"]:
                first = tr[key]["job_sha_first"].get(r["file"])
                assert first in (None, r["sha256"]), (name, key, r["file"])


# ------------------------------------------------------------------ P4: rule 4, needs and makes

def expected_io(j, root_rel=lambda p: p):
    """The table of needs and makes (POD.md section 4b), written out again for the test from a job's command."""
    cmd = j["cmd"]

    def a(f):
        return cmd[cmd.index(f) + 1] if f in cmd else None

    def ov(k):
        return next((x.split("=", 1)[1] for x in cmd if x.startswith(k + "=")), None)
    k = j["kind"]
    if k == "fit":
        needs, makes = [a("--config")], [ov("output.checkpoint_dir"),
                                         f"{C2_REL}/tb/{a('--run')}/seed{ov('training.seed')}"]
    elif k == "score":
        needs, makes = [a("--config"), a("--checkpoint")], [a("--out"), a("--out") + ".json",
                                                            a("--out") + ".exposure.json"]
    elif k == "timing" and cmd[2] == "real":
        needs = [a("--config")]
        makes = [f"{C2_REL}/timing/{a('--run')}.json", f"{C2_REL}/timing/{a('--run')}.txt",
                 f"{NF_REL}/SETTINGS.yaml"]
    elif k == "timing":
        needs = [a("--config"), a("--checkpoint")]
        out = root_rel(j["out"])
        makes = [out, out[:-len(".json")] + ".txt"]
    elif k in ("attention", "importance"):
        needs = [x for x in (a("--config"), a("--checkpoint"), a("--field-map"), a("--clusters"), a("--timing")) if x]
        makes = [a("--output")]
    elif k == "downstream":
        needs, makes = [a("--run-dir"), a("--config"), a("--checkpoint")], [f"{C2_REL}/downstream/{a('--name')}"]
    else:
        raise AssertionError(k)
    return needs, makes + [root_rel(j["log"])]


def test_p4_rule4_needs_and_makes_and_waiting(traces, tmp_path, monkeypatch):
    """io_of gives the table for every job kind (the GPU kinds of the P1 traces, and the CPU kinds the planner
    runs itself). A score is never published while its fit is in flight (so a held candidate's score waits too),
    and a CPU job (a read, a config) starts only when no worker job is in flight."""
    kinds = set()
    for name, tr in traces.items():
        for key in ("w1", "w2", "w2lifo"):
            t = tr[key]
            recs = {r["file"]: r for r in t["job_records"]}
            for r in recs.values():
                kinds.add(r["kind"])
            log = t["queue_log"]
            ran_at = {ln.split()[1].rsplit(".a", 1)[0]: i for i, ln in enumerate(log) if ln.startswith("ran ")}
            flying = set()
            for i, ln in enumerate(log):
                parts = ln.split()
                if parts[0] == "publish":
                    flying.add(parts[1])
                    home = _home_of_score(recs.get(parts[1] + ".json") or {})
                    if home and home in ran_at:
                        assert ran_at[home] < i, (name, key, ln, "published before its fit ended")
                elif parts[0] in ("ran", "late") or (parts[0] == "withdraw" and parts[1].endswith(":")):
                    flying.discard(parts[1].rstrip(":"))
                elif parts[0] == "start" and parts[1].startswith(("read_", "config_", "result", "artifact_")):
                    assert not flying, (name, key, ln, sorted(flying))
    assert {"fit", "score", "timing", "attention", "downstream", "importance"} <= kinds, kinds
    # the CPU kinds the planner runs itself, and each GPU kind, through io_of
    monkeypatch.setenv("NF_OUT", str(tmp_path / "c2"))
    P = load("nf_plan")
    C = P.C
    rel = C.rel

    def jb(jid, kind, cmd, out=None):
        return P.job(jid, "S", kind, cmd, gpu=kind not in ("config", "read", "cpu"), out=out)
    tb = tmp_path / "c2"
    cfg, ck = f"{NF_REL}/configs/nf_a1.yaml", f"{C2_REL}/runs/nf_a1/seed42/best.ckpt"
    table = tb / "reads" / "A1_1seed.runs.json"
    table.parent.mkdir(parents=True)
    table.write_text(json.dumps({"runs": [{"checkpoint": ck, "predictions": "p/a.parquet", "downstream": ""},
                                          {"checkpoint": "", "predictions": "p/b.parquet", "downstream": "d/x"}]}))
    cases = [
        (jb("config_nf_a2", "config", ["py", "nf_make_configs.py", "write", "--run", "nf_a2", "--steps", "A2",
                                       "--drop", f"{C2_REL}/reads/P_drop.txt"]),
         [f"{C2_REL}/reads/P_drop.txt"], [f"{NF_REL}/configs/nf_a2.yaml"]),
        (jb("config_nf_a1", "config", ["py", "nf_make_configs.py", "write", "--run", "nf_a1", "--steps", "A1"]),
         [], [f"{NF_REL}/configs/nf_a1.yaml"]),
        (jb("read_A1_1seed", "read", ["py", "nf_read.py", "read", "--step", "A1", "--run-table", rel(table),
                                      "--out", rel(tb / "reads" / "A1_1seed.json")]),
         [rel(table), ck, "p/a.parquet", "p/b.parquet", "d/x"],
         [rel(tb / "reads" / "A1_1seed.json"), rel(tb / "reads" / "A1_1seed.txt")]),
        (jb("artifact_recheck", "cpu", ["py", "nf_check_artifact.py", "--checkpoints", "a/best.ckpt", ck],
            out=tb / "artifact" / "artifact_check.json"),
         ["a/best.ckpt", ck], [rel(tb / "artifact" / "artifact_check.json")]),
        (jb("result", "cpu", ["py", "nf_report.py", "--result"], out=tb / "reads" / "RESULT.txt"),
         [], [rel(tb / "reads" / "RESULT.txt")]),
    ]
    for j, needs, makes in cases:
        assert P.io_of(j) == (needs, makes + [rel(j["log"])]), j["id"]
    gpu = [
        jb("fit_nf_a1_seed43", "fit", ["py", "nf_fit.py", "--run", "nf_a1", "--config", cfg, "training.seed=43",
                                       f"output.checkpoint_dir={C2_REL}/runs/nf_a1/seed43"]),
        jb("score_nf_a1_seed42__rank_b", "score", ["py", "-m", "s", "--config", cfg, "--checkpoint", ck, "--out",
                                                   f"{C2_REL}/scores/nf_a1_seed42__rank_b.parquet"]),
        jb("timing_nf_a2", "timing", ["py", "nf_time_width.py", "real", "--config", cfg, "--run", "nf_a2",
                                      "--write-settings"]),
        jb("scoring_timing_nf_a1", "timing", ["py", "nf_time_width.py", "score", "--config", cfg, "--checkpoint", ck,
                                              "--run", "nf_a1"], out=f"{C2_REL}/timing/nf_a1_scoring.json"),
        jb("importance_x", "importance", ["py", "nf_importance.py", "run", "--config", cfg, "--checkpoint", ck,
                                          "--output", f"{C2_REL}/importance/x", "--field-map", "F.csv",
                                          "--clusters", "cl.csv", "--timing", "t.json"]),
        jb("attention_x", "attention", ["py", "nf_importance.py", "run", "--attention-only", "--config", cfg,
                                        "--checkpoint", ck, "--output", f"{C2_REL}/importance/x_attention",
                                        "--field-map", "F.csv", "--seconds-per-row", "0.1"]),
        jb("downstream_x", "downstream", ["py", "nf_downstream.py", "run", "--name", "x", "--run-dir",
                                          f"{C2_REL}/runs/nf_a1/seed42", "--config", cfg, "--checkpoint", ck]),
    ]
    for j in gpu:
        exp = expected_io(j, rel)
        got = P.io_of(j)
        if j["kind"] in ("fit", "downstream", "timing"):    # these name folders under C2 by the queue's own rule
            got = (got[0], [g.replace(rel(tb), C2_REL) for g in got[1]])
            exp = (exp[0], [e.replace(rel(tb), C2_REL) for e in exp[1]])
        assert got == exp, (j["id"], got, exp)
    assert P.covers("a/b", "a/b/c") and P.covers("a/b", "a/b") and not P.covers("a/b", "a/bc")


# ------------------------------------------------------------------ P5: rule 5, placement

def test_p5_rule5_pairs_and_scores_stay_on_one_workbench(tmp_path):
    """On the longest path with two workers: the seed 43 and 44 pairs each run on one workbench, the two pairs on
    different workbenches; a pair's second arm is published only once the first is claimed, for that workbench;
    a fit's scores run where it was trained; host and GPU UUID are in every claim, done record and ran line."""
    p = make_path(False, False, ("A3p", "A3p", "A3p"))
    w = world(tmp_path / "x", p["decisions"])
    t = drive(w, "planner", ("wb-one", "wb-two"))
    assert t["rc"] in (0, 5) and not t["deadlock"], t["queue_log"][-5:]
    assert not planner_checks(t), planner_checks(t)
    host = {a["id"]: a["host"] for a in t["attempts"]}
    recs = {r["id"]: r for r in t["job_records"]}
    for step, ctl in (("nf_a2", "nf_ka2"), ("nf_b", "nf_kb")):
        h43, h44 = host[f"fit_{step}_seed43"], host[f"fit_{step}_seed44"]
        assert host[f"fit_{ctl}_seed43"] == h43 and host[f"fit_{ctl}_seed44"] == h44, (step, host)
        assert h43 != h44, (step, h43, h44)
        for sd in (43, 44):
            cand, first = recs[f"fit_{step}_seed{sd}"], recs[f"fit_{ctl}_seed{sd}"]
            assert first["host"] is None and cand["host"] == host[first["id"]], (cand, first)
            assert cand["order"] > first["order"] and cand["pair"]["partner"] == first["id"]
    assert host["fit_nf_a1_seed43"] == host["fit_nf_control_seed43"]          # A1's controls are the base refits
    assert host["fit_nf_a1_seed44"] == host["fit_nf_control_seed44"]
    for r in t["job_records"]:
        home = _home_of_score(r)
        if r["kind"] != "fit" and home in host:
            assert host[r["id"]] == host[home], (r["id"], home)
    for c in t["claims"].values():
        assert c.get("withdrawn") or (c["host"] in ("wb-one", "wb-two") and c["gpu_uuid"].startswith("GPU-"))
    for d in t["done"].values():
        assert d["host"] in ("wb-one", "wb-two") and d["gpu_uuid"].startswith("GPU-")
    ran = [ln for ln in t["queue_log"] if ln.startswith("ran ")]
    assert len(ran) == len(t["attempts"])
    assert all(re.search(r" host=wb-(one|two) gpu=GPU-\S+ started=\S+ ended=\S+ rc=0 with=\S+$", ln) for ln in ran)


# ------------------------------------------------------------------ P6: T3, rule 6, restarts and silence

def test_p6_t3_a_planner_restart_adopts_claimed_jobs(tmp_path):
    """A planner restart while two fits are claimed: they are not published again, they are adopted as running,
    and each is reconciled once when done; the old session's unclaimed jobs are withdrawn and published again by
    the new session."""
    d = {}
    for s, o in zip(STEPS, ("A1p", "K3", "K1")):
        d.update(outcome(s, o))
    w = world(tmp_path / "x", d)
    out = scenario(w, '''
pl = D.Planner(["wb-one", "wb-two"])
def cond(pl):
    st = pl.status()["attempts"]
    fits = [j for j, a in st.items() if a["state"] == "running" and j.startswith("fit_")]
    return len(fits) >= 2 and any(a["state"] == "published" for a in st.values())
pl.run(until=cond)
st = pl.status()["attempts"]
OUT["running"] = sorted(j for j, a in st.items() if a["state"] == "running")
OUT["published"] = sorted(j for j, a in st.items() if a["state"] == "published")
OUT["old"] = pl.sess.id
pl.start()
OUT["new"] = pl.sess.id
OUT["open_claims"] = pl.open_claims
pl.run()
OUT["rc"] = pl.rc()
st = pl.status()["attempts"]
OUT["attempts"] = {j: [a["attempt"]] + [h["attempt"] for h in a["history"]] for j, a in st.items()}
OUT["session"] = {j: (a["job"] or {}).get("session") for j, a in st.items()}
OUT["ran"] = D.lines("ran ")
OUT["withdraw"] = D.lines("withdraw ")
''')
    assert out["rc"] == 0 and out["old"] != out["new"]
    assert len(out["running"]) == 2 and all(j.startswith("fit_nf_ka2_seed4") for j in out["running"]), out
    assert {(o["id"], o["state"]) for o in out["open_claims"]} == {(j, "running") for j in out["running"]}
    for j in out["running"]:
        assert out["attempts"][j] == [1], (j, out["attempts"][j])
        assert sum(1 for ln in out["ran"] if ln.startswith(f"ran {j}.a1 ")) == 1
    assert out["published"]
    for j in out["published"]:
        assert any(ln.startswith(f"withdraw {j}.a1: published by an earlier queue start") for ln in out["withdraw"])
        assert out["attempts"][j][0] == 2 and out["session"][j] == out["new"], (j, out["attempts"][j])
    assert len(out["ran"]) == len({ln.split()[1] for ln in out["ran"]})


SILENT = '''
import subprocess
def silence(pl, h):
    """h's worker stops writing its heartbeat (its last one is older than UNKNOWN_AFTER_SECONDS)."""
    pl.stubs.silent.add(h)
    rec = Q.read(Q.worker_path(h))
    rec["heartbeat_utc"] = "2000-01-01T00:00:00Z"
    Q.write_whole(Q.worker_path(h), rec)
def running_on(pl, h, kind=None):
    b = pl.stubs.busy.get(h)
    return b is not None and (kind is None or b["rec"]["job"]["kind"] == kind)
def finish_by_hand(b):
    """The job's command runs to its end on the silent workbench: outputs, no done record."""
    j = b["rec"]["job"]
    with open(j["log"], "a") as lf:
        return D.run_cmd(j["cmd"], C.ROOT, lf, dict(os.environ, CUDA_VISIBLE_DEVICES="GPU-x"))
def done_by_hand(b, rc=0):
    j = b["rec"]["job"]
    Q.write_whole(Q.done_path(j["id"], b["attempt"]), {"schema": 1, "id": j["id"], "attempt": b["attempt"],
                  "host": "wb-two", "gpu_uuid": "GPU-22222222-bbbb", "worker_pid": 1, "child_pid": 2,
                  "started_utc": D.utc_at(b["start"]), "ended_utc": D.utc_at(b["end"]), "rc": rc, "ran": True,
                  "note": "late"})
def report():
    r = subprocess.run([sys.executable, str(C.NF / "nf_report.py")], capture_output=True, text=True)
    return r.stdout
'''


def test_p6_t3_a_silent_workbench_unknown_late_completion_and_release(tmp_path):
    """A worker silent past UNKNOWN_AFTER_SECONDS: its attempt is unknown, never published again, and the report
    says UNKNOWN; its outputs completing later without a done record settle it; a late done record gives its lines
    once, across three ticks and a restart."""
    w = world(tmp_path / "x", {})
    out = scenario(w, SILENT + '''
pl = D.Planner(["wb-one", "wb-two"])
pl.run(until=lambda pl: running_on(pl, "wb-one", "fit") and running_on(pl, "wb-two", "fit"))
b = dict(pl.stubs.busy["wb-two"])
jid = b["id"]
OUT["jid"] = jid
OUT["release_running"] = P.release(jid)
silence(pl, "wb-two")
try:
    pl.run()
except D.Deadlock:
    pass
st = pl.status()
OUT["state"] = st["attempts"][jid]["state"]
OUT["report"] = report()
OUT["release_partial"] = P.release(jid)
finish_by_hand(b)
pl.run(until=lambda pl: len(D.lines("ran ")) >= 6)
OUT["split"] = D.lines("split ")
done_by_hand(b)
for _ in range(3):
    pl.tick()
pl.start()
for _ in range(2):
    pl.tick()
pl.run()
OUT["rc"] = pl.rc()
st = pl.status()["attempts"]
OUT["attempts"] = [st[jid]["attempt"]] + [h["attempt"] for h in st[jid]["history"]]
OUT["ran"] = [ln for ln in D.lines("ran ") if ln.startswith(f"ran {jid}.")]
OUT["start"] = D.lines(f"start {jid} ")
OUT["unknown"] = D.lines("unknown ")
OUT["hosts"] = sorted({a["host"] for a in pl.stubs.attempts})
''')
    jid = out["jid"]
    assert out["release_running"] == 4 and out["release_partial"] == 4
    assert out["state"] == "unknown"
    assert f"UNKNOWN {jid}.a1 on wb-two, last heartbeat 2000-01-01T00:00:00Z: not started again" in \
        " ".join(out["report"].split())
    assert f"nf_plan.py release {jid}" in " ".join(out["report"].split())
    assert out["attempts"] == [1]                    # never published again
    assert len(out["ran"]) == 1 and len(out["start"]) == 1, out
    assert out["split"], "jobs that belonged on wb-two are placed on any workbench and say so"
    assert out["rc"] == 0 and out["hosts"] == ["wb-one"]       # wb-two stayed silent: wb-one ran the rest


def test_p6_t3_release_after_the_rename_and_a_late_done(tmp_path):
    """release is refused while the attempt runs and while it has partial outputs, allowed after the owner renamed
    them: attempt 2 is published and run; a late done record of attempt 1 after that gives one late line only."""
    w = world(tmp_path / "x", {})
    out = scenario(w, SILENT + '''
pl = D.Planner(["wb-one", "wb-two"])
pl.run(until=lambda pl: running_on(pl, "wb-one", "fit") and running_on(pl, "wb-two", "fit"))
b = dict(pl.stubs.busy["wb-two"])
jid = b["id"]
OUT["jid"] = jid
OUT["r_running"] = P.release(jid)
silence(pl, "wb-two")
pl.tick()
OUT["state"] = pl.status()["attempts"][jid]["state"]
OUT["r_partial"] = P.release(jid)
d = C.ROOT / b["rec"]["makes"][0]
d.rename(d.with_name(d.name + "_crashed"))
OUT["r_ok"] = P.release(jid)
OUT["r_again"] = P.release(jid)
pl.run(until=lambda pl: (pl.status()["attempts"][jid]["state"] == "done"))
st = pl.status()["attempts"][jid]
OUT["after"] = [st["attempt"], st["state"], st["done"]["host"], [(h["attempt"], h["state"]) for h in st["history"]]]
done_by_hand(b)
for _ in range(3):
    pl.tick()
OUT["late"] = D.lines(f"late {jid}.a1 ")
OUT["ran1"] = D.lines(f"ran {jid}.a1 ")
OUT["release"] = D.lines(f"release {jid}.a1: ")
pl.run()
OUT["rc"] = pl.rc()
''')
    assert out["r_running"] == 4 and out["state"] == "unknown" and out["r_partial"] == 4
    assert out["r_ok"] == 0 and out["r_again"] == 4 and len(out["release"]) == 1
    assert out["after"] == [2, "done", "wb-one", [[1, "released"]]], out["after"]
    assert len(out["late"]) == 1 and not out["ran1"], out
    assert out["rc"] == 0


# ------------------------------------------------------------------ P7: T5, rule 7, a worker leaves

def _outputs(w):
    out = {}
    for p in sorted(c2(w).glob("runs/*/seed*/*")) + sorted(c2(w).glob("scores/*")):
        if p.is_file():
            out[str(p.relative_to(w))] = hashlib.sha256(p.read_bytes()).hexdigest()
    return out


STOPPED = '''
import hashlib
import subprocess
def outputs():
    return {str(p.relative_to(C.ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(P.c2("runs").glob("*/seed*/*")) + sorted(P.c2("scores").glob("*")) if p.is_file()}
def report():
    return " ".join(subprocess.run([sys.executable, str(C.NF / "nf_report.py")], capture_output=True,
                                   text=True).stdout.split())
def worker_stop(h):
    r = subprocess.run([sys.executable, str(C.NF / "nf_worker.py"), "stop"], capture_output=True, text=True,
                       env=dict(os.environ, NF_TEST_HOSTNAME=h))
    return [r.returncode, " ".join((r.stdout + r.stderr).split()), Q.worker_stop_path(h).exists()]
def attempts(jid):
    a = pl.status()["attempts"].get(jid)
    return [] if a is None else [(a["attempt"], a["state"])] + [(h["attempt"], h["state"]) for h in a["history"]]
pl = D.Planner(["wb-one", "wb-two"])
def cond(pl):
    st = pl.status()["attempts"]
    return pl.stubs.busy["wb-two"] is None and any(
        a["state"] == "published" and (a["job"] or {}).get("host") == "wb-two" and a["job"]["job"]["kind"] == "fit"
        for a in st.values())
pl.run(until=cond)
st = pl.status()["attempts"]
arm = next(j for j, a in st.items() if a["state"] == "published" and (a["job"] or {}).get("host") == "wb-two")
first = st[arm]["job"]["pair"]["partner"]
OUT["arm"], OUT["first"] = arm, first
OUT["first_host"] = st[first]["done"]["host"]
def stop_wb_two():
    rec = Q.read(Q.worker_path("wb-two"))
    rec["state"] = "stopped"
    Q.write_whole(Q.worker_path("wb-two"), rec)
    pl.stubs.stopped.add("wb-two")
def start_wb_two():
    pl.stubs.stopped.discard("wb-two")
    pl.stubs.record("wb-two", "idle")
'''


def _k3_world(tmp_path):
    d = {}
    for s, o in zip(STEPS, ("K3", "K1", "K1")):
        d.update(outcome(s, o))
    return world(tmp_path / "x", d)


def test_p7_t5_a_stopped_worker_holds_its_pinned_arm_until_it_returns(tmp_path):
    """N1-a: wb-two stops while idle with the second arm of a seed pair published for it. The arm is withdrawn and
    held for wb-two: it is not published for any other workbench, wb-one never runs it, no split line; the report
    shows it held, waiting for wb-two, and why. When wb-two's worker is back, the arm is published for wb-two again
    and runs there, the run ends as usual, and every output that was complete before is byte-identical after.
    On 964b2c5 the arm was published for any workbench with split_from and wb-one ran it."""
    out = scenario(_k3_world(tmp_path), STOPPED + '''
OUT["before"] = outputs()
stop_wb_two()
try:
    pl.run()
    OUT["ended_while_stopped"] = True
except D.Deadlock:
    OUT["ended_while_stopped"] = False
OUT["held_attempts"] = attempts(arm)
OUT["held_by_wb_one"] = [a["id"] for a in pl.stubs.attempts if a["id"] == arm]
OUT["report"] = report()
OUT["split"] = D.lines("split ")
start_wb_two()
pl.stubs.deadlock = ""
pl.run()
OUT["rc"] = pl.rc()
st = pl.status()["attempts"][arm]
OUT["arm_state"] = [st["attempt"], st["state"], st["job"]["host"], st["job"]["pair"], st["done"]["host"],
                    [(h["attempt"], h["state"]) for h in st["history"]]]
OUT["withdraw"] = D.lines(f"withdraw {arm}.a1: ")
OUT["split_after"] = D.lines("split ")
OUT["after"] = outputs()
OUT["ran_on"] = sorted({a["host"] for a in pl.stubs.attempts if a["id"] in (arm, first)})
''')
    arm, first = out["arm"], out["first"]
    assert arm.startswith("fit_nf_a1_seed4") and first.startswith("fit_nf_control_seed4"), (arm, first)
    assert out["first_host"] == "wb-two"
    # while wb-two is stopped: held, never published elsewhere, never run by wb-one
    assert out["ended_while_stopped"] is False                    # the queue waits for the held arm
    assert out["held_attempts"] == [[1, "withdrawn"]], out["held_attempts"]
    assert not out["held_by_wb_one"] and not out["split"], out
    assert len(out["withdraw"]) == 1 and "wb-two has no live worker (stopped); held for wb-two" in out["withdraw"][0]
    assert (f"HELD {arm} waits for wb-two: {first} (its pair's first arm) ran on wb-two, whose worker is "
            "stopped. It runs only on wb-two") in out["report"], out["report"]
    # wb-two is back: the arm runs there
    n, state, host, pair, ran_on, hist = out["arm_state"]
    assert (n, state, host, ran_on, hist) == (2, "done", "wb-two", "wb-two", [[1, "withdrawn"]]), out["arm_state"]
    assert pair == {"partner": first, "split_from": None}, pair
    assert out["ran_on"] == ["wb-two"] and not out["split_after"]
    for k, v in out["before"].items():
        assert out["after"].get(k) == v, k
    assert out["rc"] == 0


def test_p7_t5_a_held_arm_does_not_block_an_independent_job(tmp_path):
    """While an arm is held for the stopped wb-two, wb-one goes on with the work that does not need it: the other
    seed's candidate and a score that the planner publishes after the hold, with the held arm still unpublished
    (on 964b2c5 the held arm was published again for any workbench first)."""
    out = scenario(_k3_world(tmp_path), STOPPED + '''
mark = len(P.c2("queue.log").read_text().splitlines())
t0 = D.CLOCK[0]
stop_wb_two()
try:
    pl.run()
except D.Deadlock:
    pass
OUT["log"] = P.c2("queue.log").read_text().splitlines()[mark:]
OUT["after"] = [a["id"] for a in pl.stubs.attempts if a["host"] == "wb-one" and a["start"] >= t0]
OUT["held_attempts"] = attempts(arm)
''')
    arm, log = out["arm"], out["log"]
    held_at = next(i for i, ln in enumerate(log) if ln.startswith(f"withdraw {arm}.a1: "))
    later = [ln.split()[1] for ln in log[held_at:] if ln.startswith("publish ")]
    assert later and all(not x.startswith(arm + ".") for x in later), log
    assert any(x.startswith("score_") for x in later), later              # published after the hold
    other = "fit_nf_a1_seed43" if arm.endswith("44") else "fit_nf_a1_seed44"
    assert other in out["after"] and any(x.startswith("score_") for x in out["after"]), out["after"]
    assert out["held_attempts"] == [[1, "withdrawn"]]


def test_p7_t5_may_stop_is_false_while_a_pair_is_open_and_stop_refuses(tmp_path):
    """A worker may be removed only when no unfinished seed pair depends on it. With a pair's first arm done on
    wb-two and its second arm not finished, the report says not yet and names the pair, and nf_worker.py stop on
    wb-two refuses (exit 4), names the pair and writes no stop file. Once the pair has finished, the report says safe now and stop on wb-two is accepted (exit 0, the stop file).
    On 964b2c5 the report did not name the pair and stop was always accepted."""
    out = scenario(_k3_world(tmp_path), STOPPED + '''
OUT["report_open"] = report()
OUT["stop_open"] = worker_stop("wb-two")
pl.run(until=lambda pl: (pl.status()["attempts"][arm]["state"] == "done" and pl.stubs.busy["wb-two"] is None
                         and not any((a["job"] or {}).get("host") == "wb-two" and a["state"] == "published"
                                     for a in pl.status()["attempts"].values())))
OUT["report_done"] = report()
OUT["stop_done"] = worker_stop("wb-two")
''')
    arm, first = out["arm"], out["first"]
    want = (f"stop the worker on wb-two: not yet: an unfinished seed pair depends on it: {first} ran on wb-two and "
            f"{arm} is published")
    assert want in out["report_open"], out["report_open"]
    rc, text, made = out["stop_open"]
    assert rc == 4 and not made, out["stop_open"]
    assert f"{first} ran on wb-two and {arm} is published" in text and "unfinished seed pair" in text, text
    assert "stop the worker on wb-two: safe now" in out["report_done"], out["report_done"]
    assert out["stop_done"][0] == 0 and out["stop_done"][2] and "ends after its current job" in out["stop_done"][1]


SILENT_PAIR = '''
pl = D.Planner(["wb-one", "wb-two"])
def pinned(pl):
    """wb-two runs the first arm of a pair, and the second arm is published for wb-two."""
    st = pl.status()["attempts"]
    b = pl.stubs.busy.get("wb-two")
    if b is None or b["rec"]["job"]["kind"] != "fit":
        return False
    return any(a["state"] == "published" and (a["job"] or {}).get("host") == "wb-two"
               and ((a["job"] or {}).get("pair") or {}).get("partner") == b["id"] for a in st.values())
pl.run(until=pinned)
b = dict(pl.stubs.busy["wb-two"])
first = b["id"]
st = pl.status()["attempts"]
arm = next(j for j, a in st.items() if a["state"] == "published" and (a["job"] or {}).get("host") == "wb-two")
OUT["first"], OUT["arm"] = first, arm
def attempts(jid):
    a = pl.status()["attempts"].get(jid)
    return [] if a is None else [(a["attempt"], a["state"])] + [(h["attempt"], h["state"]) for h in a["history"]]
def worker_stop(h):
    r = subprocess.run([sys.executable, str(C.NF / "nf_worker.py"), "stop"], capture_output=True, text=True,
                       env=dict(os.environ, NF_TEST_HOSTNAME=h))
    return [r.returncode, " ".join((r.stdout + r.stderr).split()), Q.worker_stop_path(h).exists()]
'''


def test_p7_t5_a_silent_worker_leaves_its_pairs_other_arm_held(tmp_path):
    """wb-two goes silent (no heartbeat past UNKNOWN_AFTER_SECONDS) while it runs a pair's first arm, with the
    second arm published for it. The first arm is unknown and never started again; the second arm is withdrawn and
    held, never published for wb-one (no split line); the report shows it held for wb-two, which is silent, and
    nf_worker.py stop on wb-two refuses (exit 4), naming the open pair. When wb-two's heartbeat is back, its fit ends, the held arm runs on wb-two and
    the run ends as usual. On 964b2c5 the second arm was published for any workbench and wb-one ran it."""
    p = make_path(False, False, ("A3p", "A3p", "A3p"))
    w = world(tmp_path / "x", p["decisions"])
    out = scenario(w, SILENT + SILENT_PAIR + '''
silence(pl, "wb-two")
try:
    pl.run()
    OUT["ended"] = True
except D.Deadlock:
    OUT["ended"] = False
OUT["first_state"] = attempts(first)
OUT["arm_held"] = attempts(arm)
OUT["by_wb_one"] = [a["id"] for a in pl.stubs.attempts if a["id"] in (first, arm)]
OUT["split"] = D.lines("split ")
OUT["report"] = " ".join(report().split())
OUT["stop"] = worker_stop("wb-two")
pl.stubs.silent.discard("wb-two")              # wb-two's worker writes its heartbeat again
pl.stubs.record("wb-two", "running", f"{first}.a1")
pl.stubs.deadlock = ""
pl.run()
OUT["rc"] = pl.rc()
OUT["arm_after"] = attempts(arm)
OUT["hosts"] = {a["id"]: a["host"] for a in pl.stubs.attempts if a["id"] in (first, arm)}
OUT["split_after"] = D.lines("split ")
''')
    first, arm = out["first"], out["arm"]
    assert out["ended"] is False
    assert out["first_state"] == [[1, "unknown"]] and out["arm_held"] == [[1, "withdrawn"]], out
    assert not out["by_wb_one"] and not out["split"], out
    rep = out["report"]
    assert (f"HELD {arm} waits for wb-two: {first} (its pair's first arm) was claimed on wb-two, whose worker is "
            "silent") in rep, rep
    rc, text, made = out["stop"]
    assert rc == 4 and not made and f"{first} was claimed on wb-two and {arm} is held" in text, out["stop"]
    assert out["rc"] == 0 and out["hosts"] == {first: "wb-two", arm: "wb-two"}, out
    assert out["arm_after"] == [[2, "done"], [1, "withdrawn"]] and not out["split_after"]


def test_p7_t5_a_pair_with_neither_arm_claimed_moves_whole(tmp_path):
    """A pair with neither arm claimed is not a split. wb-two goes silent while it runs a pair's first arm: the
    second arm is held. The owner gives the first arm up (renames its outputs to _crashed, then nf_plan.py release):
    now neither arm is claimed, so the first arm's next attempt goes to wb-one and the second arm follows it there,
    published for wb-one only once the first is claimed, with no split. On 964b2c5 the second arm had already run
    on wb-one, split from its first arm."""
    p = make_path(False, False, ("A3p", "A3p", "A3p"))
    w = world(tmp_path / "x", p["decisions"])
    out = scenario(w, SILENT + SILENT_PAIR + '''
silence(pl, "wb-two")
pl.tick()
pl.tick()
OUT["arm_held"] = attempts(arm)
d = C.ROOT / b["rec"]["makes"][0]
d.rename(d.with_name(d.name + "_crashed"))
OUT["release"] = P.release(first)
pl.stubs.deadlock = ""
pl.run(until=lambda pl: all(pl.status()["attempts"][j]["state"] == "done" for j in (first, arm)))
st = pl.status()["attempts"]
OUT["first_after"] = [st[first]["attempt"], st[first]["done"]["host"]]
OUT["arm_after"] = [st[arm]["attempt"], st[arm]["job"]["host"], st[arm]["job"]["pair"], st[arm]["done"]["host"]]
OUT["orders"] = [st[first]["job"]["order"], st[arm]["job"]["order"]]
OUT["split"] = D.lines("split ")
OUT["by_wb_one"] = [a["id"] for a in pl.stubs.attempts if a["host"] == "wb-one" and a["id"] in (first, arm)]
pl.run()
OUT["rc"] = pl.rc()
''')
    first, arm = out["first"], out["arm"]
    assert out["arm_held"] == [[1, "withdrawn"]] and out["release"] == 0, out
    assert out["first_after"] == [2, "wb-one"], out
    assert out["arm_after"] == [2, "wb-one", {"partner": first, "split_from": None}, "wb-one"], out
    assert out["orders"][0] < out["orders"][1], out
    assert not out["split"] and sorted(out["by_wb_one"]) == sorted([first, arm]), out
    assert out["rc"] == 0


def test_p7_t5_a_worker_silent_mid_job_is_never_relaunched(tmp_path):
    """wb-two goes silent while it runs a job: the job is unknown and never started again; wb-one goes on with
    the jobs that do not need it."""
    w = world(tmp_path / "x", {})
    out = scenario(w, SILENT + '''
pl = D.Planner(["wb-one", "wb-two"])
pl.run(until=lambda pl: running_on(pl, "wb-two", "score") and running_on(pl, "wb-one", "score"))
jid = pl.stubs.busy["wb-two"]["id"]
t0 = D.CLOCK[0]
silence(pl, "wb-two")
try:
    pl.run()
    OUT["ended"] = True
except D.Deadlock:
    OUT["ended"] = False
st = pl.status()["attempts"]
OUT["jid"] = jid
OUT["state"] = [st[jid]["attempt"], st[jid]["state"], len(st[jid]["history"])]
OUT["after"] = [a["id"] for a in pl.stubs.attempts if a["host"] == "wb-one" and a["start"] >= t0]
OUT["claims"] = sorted(p.name for p in Q.qdir("claims").glob(jid + ".a*.json"))
''')
    assert out["ended"] is False                       # the read that needs it waits for it
    assert out["state"] == [1, "unknown", 0] and out["claims"] == [f"{out['jid']}.a1.json"]
    assert len(out["after"]) >= 2, out["after"]


def test_p7_claims_and_done_records_that_land_during_a_walk_start_a_new_walk(tmp_path):
    """Integration fix: the workers claim and finish jobs while the planner is still walking (fast jobs, or a long
    walk). The next tick must compare against the state the walk saw, not the state after it; otherwise those
    changes count as seen, the held second arms are never published, and the planner waits for ever."""
    p = make_path(False, False, ("A3p", "A3p", "A3p"))
    w = world(tmp_path / "x", p["decisions"])
    out = scenario(w, '''
Q.UNKNOWN_AFTER_SECONDS = 1e9
pl = D.Planner(["wb-one", "wb-two"])
real = P.walk_ahead
WALKS = [0]
def walk(st, sess=None):
    r = real(st, sess)
    WALKS[0] += sess is not None
    if sess is not None and r["published"]:
        for _ in range(6):                  # the workers act before the walk returns
            try:
                pl.stubs.step()
            except D.Deadlock:
                pl.stubs.deadlock = ""
                break
    return r
P.walk_ahead = walk
OUT["final"], idle = "no end", 0
for _ in range(5000):                       # pl.run(), except that a tick may wait with nothing left to do once
    seen = WALKS[0]                         # its walk let the workers take and finish everything published
    r = pl.tick()
    if WALKS[0] != seen:
        idle = 0
    if r in P.FINAL:
        OUT["final"] = r
        break
    if r == "wait":
        try:
            pl.stubs.step()
            idle = 0
        except D.Deadlock:
            pl.stubs.deadlock = ""
            idle += 1
            if idle > 2:
                OUT["final"] = "deadlock: the planner waits and no worker has anything to claim or finish"
                break
OUT["held_published"] = D.lines("publish fit_nf_a2_seed43.") + D.lines("publish fit_nf_a2_seed44.")
OUT["tail"] = (P.c2("queue.log").read_text().splitlines())[-12:]
''')
    assert out["final"] in ("done", "stop"), (out["final"], out["tail"])
    assert len(out["held_published"]) == 2, out["held_published"]          # the second arms, once each,
    assert all(" host=wb-" in ln for ln in out["held_published"]), out["held_published"]  # on their pair's host


# ------------------------------------------------------------------ P8: rule 8, contention on shared storage

def test_p8_rule8_ran_lines_name_the_jobs_that_ran_at_once(traces, tmp_path, monkeypatch):
    """Two overlapping attempts list each other in with=; a lone one says none."""
    t = traces["rb_K1_K1_K1"]["w2"]
    ran = {ln.split()[1]: ln.split("with=", 1)[1] for ln in t["queue_log"] if ln.startswith("ran ")}
    pairs = [(a, b) for a, w_ in ran.items() for b in w_.split(",") if b != "none"]
    assert pairs
    for a, b in pairs:
        other = b.split("@")[0]
        mine = a.rsplit(".a", 1)[0]
        assert any(x.split("@")[0] == mine for x in ran[next(k for k in ran if k.startswith(other + ".a"))].split(","))
    assert any(v == "none" for v in ran.values())
    one = traces["rb_K1_K1_K1"]["w1"]
    assert all(ln.endswith("with=none") for ln in one["queue_log"] if ln.startswith("ran "))


# ------------------------------------------------------------------ P9: T4, rule 9, the one slot stays valid

EXISTING = ["test_new_fields_spine_queue.py", "test_new_fields_two_workbenches.py",
            "test_new_fields_integration_planner.py", "test_new_fields_decisions_planner.py",
            "test_new_fields_reader_planner.py", "test_new_fields_integration_checked.py",
            "test_new_fields_integration_busy.py"]


def test_p9_t4_the_existing_planner_and_queue_tests_pass_unchanged():
    """The planner's and the queue's existing tests are unchanged since 8a440a2, and pass as they are. Running them
    takes about 8 minutes, and the whole folder's run (which holds them) is the hand-in check, so here they run
    only with NF_N1_EXISTING=1; that they are unchanged is checked on every run."""
    known = subprocess.run(["git", "-C", str(HERE), "rev-parse", "--verify", "-q", "8a440a2^{commit}"],
                           capture_output=True, text=True).returncode == 0       # not in an unzipped package
    if known:
        r = subprocess.run(["git", "-C", str(HERE), "diff", "--stat", "8a440a2", "--", *EXISTING],
                           capture_output=True, text=True)
        assert r.returncode == 0 and not r.stdout.strip(), r.stdout + r.stderr
    if os.environ.get("NF_N1_EXISTING") != "1":
        return
    r = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "-x",
                        *[str(HERE / f) for f in EXISTING]], capture_output=True, text=True, cwd=HERE.parents[3],
                       env=dict(os.environ, PYTHONPATH="src:."), timeout=1800)
    assert r.returncode == 0, r.stdout[-4000:]


def _worker_files(w, jid, host="wb-one", pid=None, session="o" * 12, claimed=True):
    """A published attempt, and (claimed) a live worker's claim of it, written as a worker writes them."""
    q = c2(w) / "queue"
    for f in ("jobs", "claims", "workers"):
        (q / f).mkdir(parents=True, exist_ok=True)
    rec = {"schema": 1, "id": jid, "attempt": 1, "session": session, "order": 1, "published_utc": FROZEN,
           "job": {"id": jid, "phase": "P1", "kind": "fit", "cmd": ["py"], "gpu": True, "optional": False,
                   "log": str(c2(w) / "logs" / f"{jid}.log"), "out": None},
           "needs": [], "makes": [f"{C2_REL}/runs/nf_control/seed43"], "host": None, "pair": None}
    (q / "jobs" / f"{jid}.a1.json").write_text(json.dumps(rec))
    if claimed:
        now = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        (q / "claims" / f"{jid}.a1.json").write_text(json.dumps({
            "schema": 1, "id": jid, "attempt": 1, "by": "worker", "host": host, "gpu_uuid": "GPU-1",
            "worker_pid": pid or os.getpid(), "claimed_utc": now, "job_sha256": "x"}))
        (q / "workers" / f"{host}.json").write_text(json.dumps({
            "schema": 1, "host": host, "gpu_uuid": "GPU-1", "pid": pid or os.getpid(), "started_utc": now,
            "heartbeat_utc": now, "state": "running", "job": f"{jid}.a1", "problem": ""}))


def test_p9_a_one_slot_start_refuses_open_claims_and_withdraws_old_jobs(tmp_path):
    """With a worker's open claim, a one-slot start refuses (exit 4) and names it. A published attempt nobody
    claimed is withdrawn at a one-slot start, which then runs as today."""
    w = world(tmp_path / "x")
    _worker_files(w, "fit_nf_control_seed43")
    r = run(w, tmp_path / "x", "nf_plan.py", "queue", "--skip-preflight", "--queue-pid", str(DEAD))
    assert r.returncode == 4, r.stderr
    err = " ".join(r.stderr.split())
    assert "fit_nf_control_seed43.a1 on wb-one (running)" in err and "nf_start.sh --workers" in err, err
    assert max(len(x) for x in r.stderr.splitlines()) <= 90
    log = qlog(w)
    assert "refused a one-slot start: a worker still holds fit_nf_control_seed43.a1 on wb-one (running)" in log
    assert "queue end rc=4" in log and not (c2(w) / "QUEUE.lock.json").exists()
    w2 = world(tmp_path / "y")
    _worker_files(w2, "fit_nf_control_seed43", claimed=False)
    t = drive(w2, "one_slot")
    assert t["rc"] == 0, t["queue_log"][-5:]
    claim = t["claims"]["fit_nf_control_seed43.a1.json"]
    assert claim["withdrawn"] is True and claim["by"] == "planner"
    assert any(ln.startswith("withdraw fit_nf_control_seed43.a1: a one-slot queue starts") for ln in t["queue_log"])
    assert "fit_nf_control_seed43" in [j for j, _ in t["jobs"]]


def test_p9_stop_ends_a_one_slot_run_drains_a_planner_and_a_switch_keeps_the_trace(tmp_path):
    """nf_plan.py stop ends a one-slot run at the next job boundary (exit 0, the line) and drains a planner
    (published jobs withdrawn, running ones finish, exit 0). A run switched one slot, stop, planner gives the
    one-slot trace: the same jobs and commands, the same reads, DECISIONS.log, KEPT.json and exit code."""
    p = make_path(False, False, ("A1p", "K3", "A1p"))
    full = drive(world(tmp_path / "full", p["decisions"]), "one_slot")
    w = world(tmp_path / "sw", p["decisions"])
    a = drive(w, "one_slot", stop_after=9)
    assert a["rc"] == 0 and len(a["jobs"]) == 9
    assert a["queue_log"][-2].startswith("stopped at a job boundary on request (nf_plan.py stop)"), a["queue_log"][-3:]
    b = drive(w, "planner", ("wb-one", "wb-two"))
    assert any(ln.startswith("an earlier stop request was cleared") for ln in b["queue_log"])
    both = dict(b, jobs=a["jobs"] + b["jobs"])
    assert not same_as_one_slot(full, both), same_as_one_slot(full, both)
    # a planner drained by a stop request
    w3 = world(tmp_path / "dr", p["decisions"])
    t = drive(w3, "planner", ("wb-one", "wb-two"), stop_after=4)
    assert t["rc"] == 0, t["queue_log"][-6:]
    log = t["queue_log"]
    i = next(k for k, ln in enumerate(log) if ln.startswith("stopped at a job boundary on request"))
    assert i >= len(log) - 3
    claims = {k: v for k, v in t["claims"].items() if not v.get("withdrawn")}
    assert set(claims) <= set(t["done"]), "every claimed job finished"
    assert any(v.get("withdrawn") and "nf_plan.py stop" in v["reason"] for v in t["claims"].values()) or \
        not any(ln.startswith("publish") for ln in log)
    assert len(t["jobs"]) < len(full["jobs"])


# ------------------------------------------------------------------ P10: rule 6, a required job fails

@pytest.mark.parametrize("hosts", [("wb-one",), ("wb-one", "wb-two")], ids=["one-worker", "two-workers"])
def test_p10_a_required_failure_stops_new_jobs_and_lets_running_ones_finish(tmp_path, hosts):
    """FAKE_FAIL_FIT on one fit: once it is reconciled no job is published, published ones are withdrawn, a job the
    other worker runs finishes and is reconciled, and the exit code and DECISIONS.log equal the one-slot run's."""
    fail = "nf_control/seed43"
    one = drive(world(tmp_path / "one", {}), "one_slot", FAKE_FAIL_FIT=fail)
    t = drive(world(tmp_path / "pl", {}), "planner", hosts, FAKE_FAIL_FIT=fail)
    assert one["rc"] == 1 and t["rc"] == one["rc"], (one["rc"], t["rc"])
    assert t["decisions"] == one["decisions"]
    log = t["queue_log"]
    i = next(k for k, ln in enumerate(log) if ln.startswith("failed fit_nf_control_seed43 rc=1"))
    assert not [ln for ln in log[i:] if ln.startswith("publish ")]
    if len(hosts) == 2:
        assert any(ln.startswith("ran fit_nf_control_seed44.a1 ") for ln in log[i:]), log[i:]
    else:
        assert any(ln.startswith("withdraw fit_nf_control_seed44.a1: a job failed") for ln in log[i:]), log[i:]
    assert log[-1].startswith("queue end rc=1")


# ------------------------------------------------------------------ P11: the report

def test_p11_the_report_shows_workers_unknown_split_and_contention(tmp_path):
    """With workers, an unknown job, a split pair and a timing job beside another: one screen (at most 40 lines of
    90 characters) with the report's two-workbench lines, and nothing written but REPORT.txt."""
    w = world(tmp_path / "x")
    q = c2(w) / "queue"
    now = dt.datetime.now(dt.timezone.utc)
    utc = lambda s: (now - dt.timedelta(seconds=s)).strftime("%Y-%m-%dT%H:%M:%SZ")  # noqa: E731
    for f in ("jobs", "claims", "done", "workers"):
        (q / f).mkdir(parents=True, exist_ok=True)

    def job(jid, kind, host=None, pair=None, cmd=None):
        (q / "jobs" / f"{jid}.a1.json").write_text(json.dumps({
            "schema": 1, "id": jid, "attempt": 1, "session": "s" * 12, "order": 1, "published_utc": utc(100),
            "job": {"id": jid, "phase": "S", "kind": kind, "cmd": cmd or ["py", "x"], "gpu": True, "optional": False,
                    "log": f"{C2_REL}/logs/{jid}.log", "out": None},
            "needs": [], "makes": [f"{C2_REL}/x/{jid}"], "host": host, "pair": pair}))

    def claim(jid, host, pid):
        (q / "claims" / f"{jid}.a1.json").write_text(json.dumps({
            "schema": 1, "id": jid, "attempt": 1, "by": "worker", "host": host, "gpu_uuid": "GPU-1a2b3c4d-99",
            "worker_pid": pid, "claimed_utc": utc(50), "job_sha256": "x"}))

    def worker(host, pid, hb, state, jobname):
        (q / "workers" / f"{host}.json").write_text(json.dumps({
            "schema": 1, "host": host, "gpu_uuid": "GPU-1a2b3c4d-99", "pid": pid, "started_utc": utc(3000),
            "heartbeat_utc": hb, "state": state, "job": jobname, "problem": ""}))

    def done(jid, host, s, e):
        claim(jid, host, 1)
        (q / "done" / f"{jid}.a1.json").write_text(json.dumps({
            "schema": 1, "id": jid, "attempt": 1, "host": host, "gpu_uuid": "GPU-1", "worker_pid": 1, "child_pid": 2,
            "started_utc": utc(s), "ended_utc": utc(e), "rc": 0, "ran": True, "note": ""}))
    job("fit_nf_a2_seed43", "fit")
    claim("fit_nf_a2_seed43", "wb-two", 22)
    worker("wb-two", 22, utc(12), "running", "fit_nf_a2_seed43.a1")
    job("fit_nf_a2_seed44", "fit")
    claim("fit_nf_a2_seed44", "wb-three", 33)
    worker("wb-three", 33, "2026-11-02T03:10:00Z", "running", "fit_nf_a2_seed44.a1")
    worker("wb-one", 11, utc(12), "idle", None)
    job("score_kept_seed44__rank_b", "score", host=None, pair={"partner": "fit_x", "split_from": "wb-three"})
    job("timing_nf_a2", "timing", cmd=["py", "nf_time_width.py", "real", "--run", "nf_a2"])
    done("timing_nf_a2", "wb-one", 900, 800)
    job("score_nf_ka2_seed42__rank_b", "score")
    done("score_nf_ka2_seed42__rank_b", "wb-two", 850, 820)
    before = sorted((p.relative_to(w), p.stat().st_mtime_ns) for p in c2(w).rglob("*"))
    r = run(w, tmp_path / "x", "nf_report.py")
    assert r.returncode == 0, r.stderr
    lines = r.stdout.splitlines()
    assert len(lines) <= 40 and max(len(x) for x in lines) <= 90, r.stdout
    text = r.stdout
    flat = " ".join(text.split())
    assert re.search(r"workers: wb-one alive idle gpu GPU-1a2b3c4d hb 1\d s;", flat), text
    assert "wb-two alive running fit_nf_a2_seed43.a1" in flat and "wb-three silent running" in flat
    assert ("in flight: fit_nf_a2_seed43 running on wb-two; fit_nf_a2_seed44 unknown on wb-three; "
            "score_kept_seed44__rank_b published (any)") in flat
    assert ("UNKNOWN fit_nf_a2_seed44.a1 on wb-three, last heartbeat 2026-11-02T03:10:00Z: not started again. If "
            "wb-three is gone or its trainer has stopped: rename its outputs (_crashed), then nf_plan.py release "
            "fit_nf_a2_seed44") in flat
    assert "stop the worker on wb-one: safe now" in text
    assert "stop the worker on wb-two: not yet: it runs fit_nf_a2_seed43.a1" in text
    assert "split pairs: score_kept_seed44__rank_b (its pair ran on wb-three)" in flat
    assert "contention: timing_nf_a2 ran beside score_nf_ka2_seed42__rank_b (shared storage)" in flat
    assert re.search(r"next: .*\(in flight: fit_nf_a2_seed43, fit_nf_a2_seed44, score_kept_seed44__rank_b\)",
                     flat), text
    after = sorted((p.relative_to(w), p.stat().st_mtime_ns) for p in c2(w).rglob("*") if p.name != "REPORT.txt")
    assert before == after
    # a published job for wb-one: not safe to stop it
    job("score_nf_a1_seed42__rank_b", "score", host="wb-one")
    r = run(w, tmp_path / "x", "nf_report.py")
    assert "stop the worker on wb-one: not yet: score_nf_a1_seed42__rank_b waits for it" in r.stdout
    # and the planner's own ran lines name the same overlap
    out = scenario(w, '''
s = P.Session()
P.reconcile(s, P.queue_status())
OUT["ran"] = D.lines("ran ")
''')
    ran = {ln.split()[1]: ln.split("with=")[1] for ln in out["ran"]}
    assert ran["timing_nf_a2.a1"].startswith("score_nf_ka2_seed42__rank_b@wb-two"), ran
    assert "timing_nf_a2@wb-one" in ran["score_nf_ka2_seed42__rank_b.a1"], ran


def test_cli_stop_and_release_and_plan(tmp_path):
    """nf_plan.py stop writes the stop request (exit 0); release refuses an unknown job id (exit 4); plan shows
    the jobs in flight and writes nothing."""
    w = world(tmp_path / "x")
    r = run(w, tmp_path / "x", "nf_plan.py", "stop")
    assert r.returncode == 0 and "stops at the next job boundary; running jobs finish" in r.stdout
    rec = json.loads((c2(w) / "queue" / "STOP.json").read_text())
    assert rec["by"] == "nf_plan.py stop" and rec["schema"] == 1
    r = run(w, tmp_path / "x", "nf_plan.py", "release", "fit_nf_a2_seed44")
    assert r.returncode == 4 and "no published attempt" in r.stderr
    _worker_files(w, "fit_nf_control_seed43")
    before = sorted(p.relative_to(w) for p in c2(w).rglob("*"))
    r = run(w, tmp_path / "x", "nf_plan.py", "plan")
    assert r.returncode == 0 and "in flight: fit_nf_control_seed43 running (wb-one)" in r.stdout, r.stdout
    assert sorted(p.relative_to(w) for p in c2(w).rglob("*")) == before
    for sub in ("stop", "release", "queue"):
        assert run(w, tmp_path / "x", "nf_plan.py", sub, "--help").returncode == 0
