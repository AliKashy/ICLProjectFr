"""End to end (N1, POD.md section 4b): the real planner (nf_plan.py queue --workers) and two real workers (nf_worker.py
run, workbench names wb-one and wb-two through NF_TEST_HOSTNAME, one GPU UUID each from a fake nvidia-smi) against
today's one-slot queue on the same synthetic world. Run by the integrator after the planner and the worker are
merged: before that, the planner has no --workers and every test here fails.

T2: the same job ids, commands and DECISIONS.log lines, and the same exit code, as the one-slot run. T8: one claim
per job id; a worker stopped (SIGSTOP) past NF_TEST_UNKNOWN_AFTER_SECONDS leaves its job UNKNOWN in the report and
the job is not started again; after the job's outputs land and the worker continues (SIGCONT), the late completion
is reconciled once and the run ends with the one-slot run's exit code. Paths (the decision maps of the earlier
simulation driver): keep_all, longest, a2_adopt1_b_out1. CPU only, synthetic files only."""
import collections
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from new_fields_spine_world import NF_REL, NF_SRC, default_map, env, make_world  # noqa: E402

STATUS = {"f_code": "PASS", "f_cnt24": "FLAG", "f_amt": "PASS"}
UUID_A, UUID_B = "GPU-aaaa1111-test", "GPU-bbbb2222-test"
HOSTS = {"wb-one": UUID_A, "wb-two": UUID_B}
UNKNOWN_AFTER = 3.0
FAST = {"NF_TEST_POLL_SECONDS": "0.2", "NF_TEST_HEARTBEAT_SECONDS": "0.5",
        "NF_TEST_UNKNOWN_AFTER_SECONDS": str(UNKNOWN_AFTER)}

PATHS = {
    "keep_all": {"A1_1seed": "KEEP THE CONTROL", "A2_1seed": "KEEP THE CONTROL", "B_1seed": "KEEP MONTH"},
    "longest": {"A1_1seed": "RUN SEEDS 43 AND 44", "A1_3seed": "ADOPT (pending the SELECT check)",
                "A1_select": "PASS",
                "A2_1seed": "RUN SEEDS 43 AND 44", "A2_3seed": "ADOPT (pending the SELECT check)",
                "A2_select": "PASS",
                "B_1seed": "RUN SEEDS 43 AND 44", "B_3seed": "MONTH OUT (pending the SELECT check)",
                "B_select": "PASS"},
    "a2_adopt1_b_out1": {"A1_1seed": "KEEP THE CONTROL",
                         "A2_1seed": "ADOPT (pending the SELECT check)", "A2_select": "PASS",
                         "B_1seed": "MONTH OUT (pending the SELECT check)", "B_select": "PASS"},
}

FAKE_SMI = """#!/bin/sh
case "$1" in
  --query-compute-apps*) printf '%s' "";;
  --query-gpu=memory*) echo 0;;
  --query-gpu=uuid*) echo GPU-aaaa1111-test; echo GPU-bbbb2222-test;;
  --query-gpu=name*) echo 'Fake GPU';;
esac
"""

# The fake trainer of the world, held at its start while FAKE_HOLD_FILE exists and its GPU is FAKE_HOLD_UUID: so the
# test can stop that workbench's worker while its job runs. The first held fit writes FAKE_HOLD_FILE + ".id".
HOLD = '''
def _hold():
    import os, sys, time
    f, u = os.environ.get("FAKE_HOLD_FILE"), os.environ.get("FAKE_HOLD_UUID")
    if not f or os.environ.get("CUDA_VISIBLE_DEVICES") != u or not os.path.exists(f):
        return
    out = [a for a in sys.argv if a.startswith("output.checkpoint_dir=")]
    try:
        fd = os.open(f + ".id", os.O_WRONLY | os.O_CREAT | os.O_EXCL)
    except FileExistsError:
        return
    os.write(fd, (out[0].split("=", 1)[1] if out else "?").encode())
    os.close(fd)
    end = time.time() + 300
    while os.path.exists(f) and time.time() < end:
        time.sleep(0.05)


'''


def _world(tmp, name, decisions):
    base = Path(tmp) / name
    w = make_world(base, map_rows=default_map(), field_status=STATUS)
    for f in ("nf_queue.py", "nf_worker.py", "nf_worker.sh"):
        shutil.copy2(NF_SRC / f, w / NF_REL / f)
    smi = base / "bin" / "nvidia-smi"
    smi.write_text(FAKE_SMI)
    smi.chmod(0o755)
    tr = w / "fraud" / "scripts" / "train_sequential_hier.py"
    s = tr.read_text()
    assert s.count('if __name__ == "__main__":\n') == 1
    tr.write_text(s.replace('if __name__ == "__main__":\n', HOLD + 'if __name__ == "__main__":\n    _hold()\n'))
    dp = base / "decisions.json"
    dp.write_text(json.dumps(decisions))
    return base, w, dp


def _trace(base, w, rc):
    """The jobs started (queue.log start lines), each job's command (its log's first line), DECISIONS.log without
    times, and the exit code."""
    c2 = w / "checkpoints" / "new_fields"
    qlog = (c2 / "queue.log").read_text() if (c2 / "queue.log").is_file() else ""
    ids = [m.group(1) for m in re.finditer(r"^start (\S+) ", qlog, re.M) if m.group(1) != "preflight"]
    cmds = {}
    for jid in set(ids):
        lg = c2 / "logs" / f"{jid}.log"
        first = lg.read_text().splitlines()[0] if lg.is_file() else ""
        cmds[jid] = (first.split(" ", 2)[2] if first.startswith("# ") else first).replace(str(w), "<W>")
    dec = (c2 / "DECISIONS.log").read_text() if (c2 / "DECISIONS.log").is_file() else ""
    return {"ids": collections.Counter(ids), "cmds": cmds,
            "decisions": [ln.split(" ", 1)[1] for ln in dec.splitlines() if " " in ln], "rc": rc, "qlog": qlog}


def one_slot(tmp, path):
    base, w, dp = _world(tmp, "one", PATHS[path])
    r = subprocess.run([sys.executable, str(w / NF_REL / "nf_plan.py"), "queue", "--skip-preflight"], cwd=w,
                       capture_output=True, text=True, env=env(w, base, FAKE_DECISIONS=dp), timeout=600)
    return _trace(base, w, r.returncode)


def read(p):
    try:
        return json.loads(Path(p).read_text())
    except (OSError, ValueError):
        return None


def wait_for(cond, timeout, what, procs=()):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        v = cond()
        if v:
            return v
        for p in procs:
            if p.poll() is not None:
                raise AssertionError(f"{what}: a process ended early (rc {p.returncode}): {p.args}")
        time.sleep(0.05)
    raise AssertionError(f"timed out waiting for {what}")


def with_workers(tmp, path, sigstop=False):
    base, w, dp = _world(tmp, "two", PATHS[path])
    c2 = w / "checkpoints" / "new_fields"
    hold = base / "hold"
    e = env(w, base, FAKE_DECISIONS=dp, FAKE_HOLD_FILE=hold, FAKE_HOLD_UUID=UUID_B, **FAST)
    if sigstop:
        hold.write_text("hold")
    procs = []
    outs = []

    def start(args, name, **extra):
        out = open(base / f"{name}.out", "w")
        outs.append(base / f"{name}.out")
        p = subprocess.Popen([sys.executable, *map(str, args)], cwd=w, env=dict(e, **extra), stdout=out,
                             stderr=subprocess.STDOUT)
        out.close()
        procs.append(p)
        return p

    notes = {}
    try:
        planner = start([w / NF_REL / "nf_plan.py", "queue", "--workers", "--skip-preflight"], "planner")
        wait_for(lambda: (read(c2 / "QUEUE.lock.json") or {}).get("mode") == "planner", 60, "the planner's lock",
                 [planner])
        workers = {h: start([w / NF_REL / "nf_worker.py", "run", "--gpu", u], f"worker_{h}", NF_TEST_HOSTNAME=h)
                   for h, u in HOSTS.items()}
        if sigstop:
            held = wait_for(lambda: (Path(str(hold) + ".id").is_file() and Path(str(hold) + ".id").read_text()),
                            300, "a fit on wb-two", [planner])
            run, seed = Path(held).parent.name, Path(held).name
            jid = f"fit_{run}_{seed}"
            wait_for(lambda: (read(c2 / "queue" / "workers" / "wb-two.json") or {}).get("job", "") or "",
                     30, "wb-two running")
            assert (read(c2 / "queue" / "workers" / "wb-two.json") or {})["job"].startswith(jid + ".a")
            os.kill(workers["wb-two"].pid, signal.SIGSTOP)
            time.sleep(UNKNOWN_AFTER + 2.0)
            rep = subprocess.run([sys.executable, str(w / NF_REL / "nf_report.py")], cwd=w, capture_output=True,
                                 text=True, env=e, timeout=120)
            notes["report"] = rep.stdout
            assert rep.returncode == 0, rep.stderr
            unknown = [ln for ln in rep.stdout.splitlines() if ln.startswith("UNKNOWN")]
            assert any(jid in ln and "wb-two" in ln for ln in unknown), rep.stdout
            hold.unlink()               # the job ends while its worker is stopped: its outputs land late
            wait_for(lambda: (Path(held) / "run_manifest_v2.json").is_file()
                     if Path(held).is_absolute() else (w / held / "run_manifest_v2.json").is_file(),
                     60, "the held fit's outputs")
            time.sleep(1.0)
            assert not [p for p in (c2 / "queue" / "jobs").iterdir() if p.name.startswith(jid + ".a2")]
            os.kill(workers["wb-two"].pid, signal.SIGCONT)
            notes["held"] = jid
        rc = planner.wait(timeout=900)
    finally:
        for h in HOSTS:
            subprocess.run([sys.executable, str(w / NF_REL / "nf_worker.py"), "stop"], cwd=w, env=dict(
                e, NF_TEST_HOSTNAME=h), capture_output=True, timeout=60)
        for p in procs:
            try:
                p.send_signal(signal.SIGCONT)
                p.wait(timeout=60)
            except subprocess.TimeoutExpired:
                p.kill()
                p.wait()
    t = _trace(base, w, rc)
    t.update(notes, c2=c2, w=w, outs=outs, worker_rcs={h: p.returncode for h, p in workers.items()})
    return t


def _why(t):
    return "\n".join([t["qlog"][-3000:]] + [Path(o).read_text()[-2000:] for o in t.get("outs", [])])


@pytest.mark.parametrize("path", list(PATHS))
def test_t2_t8_planner_and_two_workers_against_the_one_slot_queue(tmp_path, path):
    one = one_slot(tmp_path, path)
    assert one["rc"] in (0, 5) and one["ids"], one["qlog"][-2000:]
    two = with_workers(tmp_path, path, sigstop=(path == "longest"))
    why = _why(two)
    # T2: the same jobs, commands, decisions and exit code
    assert two["rc"] == one["rc"], why
    assert two["ids"] == one["ids"], (sorted((two["ids"] - one["ids"]).items()),
                                      sorted((one["ids"] - two["ids"]).items()), why)
    assert two["cmds"] == one["cmds"], why
    assert two["decisions"] == one["decisions"], why
    assert two["worker_rcs"] == {"wb-one": 0, "wb-two": 0}, why
    # T8: one worker claim per job id, one run per job, each on its worker's GPU
    q = two["c2"] / "queue"
    claims = collections.Counter()
    for p in (q / "claims").iterdir():
        c = read(p)
        if c and c.get("by") == "worker":
            claims[c["id"]] += 1
            d = read(q / "done" / p.name)
            assert d is not None and d["host"] == c["host"] and d["gpu_uuid"] == HOSTS[c["host"]], (p.name, d)
            log = (two["c2"] / "logs" / f"{c['id']}.log").read_text()
            assert log.count("\n# worker ") == 1, (c["id"], log)
    assert claims and set(claims.values()) == {1}, claims
    gpu_ids = {j for j in two["ids"] if j.split("_", 1)[0] in ("fit", "score", "timing", "scoring", "attention",
                                                               "importance", "downstream")}
    assert set(claims) == gpu_ids, (sorted(set(claims) ^ gpu_ids), why)
    ran = [ln for ln in two["qlog"].splitlines() if ln.startswith(("ran ", "late "))]
    assert len(ran) == len(claims) and all(re.search(r" host=wb-(one|two) ", ln) for ln in ran), ran
    if path == "longest":
        jid = two["held"]
        assert claims[jid] == 1 and not (q / "jobs" / f"{jid}.a2.json").exists()
        assert "UNKNOWN" in two["report"]
        assert sum(1 for ln in two["qlog"].splitlines() if ln.startswith(("ran ", "late ")) and
                   ln.split()[1].startswith(jid + ".a")) == 1, two["qlog"]
        assert sum(1 for ln in two["qlog"].splitlines() if ln.startswith(f"start {jid} ")) == 1


def test_the_planners_commands_in_the_documents_are_accepted(tmp_path):
    """POD.md section 4b gives nf_start.sh --workers, nf_plan.py stop and nf_plan.py release <job id>."""
    base, w, _ = _world(tmp_path, "help", {})
    for args, want in ((["queue", "--help"], "--workers"), (["stop", "--help"], "usage:"),
                       (["release", "--help"], "usage:")):
        r = subprocess.run([sys.executable, str(w / NF_REL / "nf_plan.py"), *args], cwd=w, capture_output=True,
                           text=True, env=env(w, base), timeout=60)
        assert r.returncode == 0 and want in r.stdout, (args, r.stdout, r.stderr)
