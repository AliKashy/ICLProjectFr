"""The worker of the two-workbench queue (N1, POD.md section 4b), against a stub planner: the test writes
QUEUE.lock.json with mode planner and a session, and the job files of the spec's section 3, then runs real workers
(nf_worker.py run, one process per workbench name given by NF_TEST_HOSTNAME) in the synthetic world. A fake GPU tool
counts its starts and writes out the CUDA_VISIBLE_DEVICES it was given; a fake nvidia-smi lists the GPU UUIDs. CPU
only, synthetic files only.

W1 (T1) busy and pin, W2 one worker per workbench, W3 (T8) one claim per job, W4 needs, W5 hosts and order,
W6 (T3) heartbeat and a killed worker, W7 (T5) stop, W8 sessions, W9 the job's program, W10 the start script,
W11 the documents."""
import json
import os
import re
import shutil
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from new_fields_checks_helpers import load  # noqa: E402
from new_fields_spine_world import NF_REL, NF_SRC, env, make_world, write  # noqa: E402

ROOT = HERE.parents[3]
DEAD = 999999999                # above any pid the system gives: never a live process
FAKE_PID = 4999999              # above the largest Linux pid: a process only in a fake table
UUID_A, UUID_B = "GPU-aaaa1111-test", "GPU-bbbb2222-test"
TRAINER = ["python3", "-m", "fraud.scripts.train_sequential_hier", "--config",
           "fraud/configs/sequential_hier_allpos.yaml"]
DONE_KEYS = {"schema", "id", "attempt", "host", "gpu_uuid", "worker_pid", "child_pid", "started_utc", "ended_utc",
             "rc", "ran", "note"}
FAST = {"NF_TEST_POLL_SECONDS": "0.1", "NF_TEST_HEARTBEAT_SECONDS": "0.5"}

FAKE_SMI = """#!/bin/sh
case "$1" in
  --query-compute-apps*) printf '%s' "${FAKE_SMI_APPS:-}";;
  --query-gpu=memory*) echo "${FAKE_SMI_USED:-0}";;
  --query-gpu=uuid*) for u in ${FAKE_SMI_UUIDS-GPU-aaaa1111-test}; do echo "$u"; done;;
  --query-gpu=name*) echo 'Fake GPU';;
esac
"""

# A GPU job: appends "<name> <CUDA_VISIBLE_DEVICES> <NF_PY>" to FAKE_STARTS when it starts, sleeps, then writes its
# output file (C2/out/<name>.txt) and exits with its rc.
FAKE_GPU = """import os, sys, time
name, secs, rc = sys.argv[1], float(sys.argv[2]), int(sys.argv[3])
with open(os.environ["FAKE_STARTS"], "a") as f:
    f.write(f"{name} {os.environ.get('CUDA_VISIBLE_DEVICES', '<unset>')} {os.environ.get('NF_PY', '<unset>')}\\n")
print("fake gpu job", name, flush=True)
time.sleep(secs)
out = os.path.join(os.environ["NF_OUT"], "out", name + ".txt")
os.makedirs(os.path.dirname(out), exist_ok=True)
open(out, "w").write(os.environ.get("CUDA_VISIBLE_DEVICES", "<unset>"))
sys.exit(rc)
"""


# ------------------------------------------------------------------ the world and the stub planner

class World:
    def __init__(self, tmp):
        self.tmp = Path(tmp)
        self.w = make_world(self.tmp)
        self.nf = self.w / NF_REL
        for f in ("nf_queue.py", "nf_worker.py", "nf_worker.sh"):
            shutil.copy2(NF_SRC / f, self.nf / f)
        smi = self.tmp / "bin" / "nvidia-smi"
        smi.write_text(FAKE_SMI)
        smi.chmod(0o755)
        self.tool = write(self.w / "tools" / "fake_gpu.py", FAKE_GPU)
        self.c2 = self.w / "checkpoints" / "new_fields"
        self.q = self.c2 / "queue"
        self.starts = self.tmp / "starts.txt"
        self.procs = []

    def env(self, host="wb-one", **extra):
        e = dict(FAST, NF_TEST_HOSTNAME=host, FAKE_STARTS=str(self.starts))
        e.update(extra)
        return env(self.w, self.tmp, **e)

    # the stub planner
    def lock(self, session="s1", mode="planner", pid=None, hostname=None):
        rec = {"pid": os.getpid() if pid is None else pid, "hostname": hostname or socket.gethostname(),
               "utc": "2026-11-04T01:00:00Z"}
        if mode:
            rec.update(mode=mode, session=session)
        p = self.c2 / "QUEUE.lock.json"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(rec))
        return rec

    def publish(self, name, order=1, host=None, session="s1", needs=(), secs=0.0, rc=0, attempt=1, cmd=None):
        jid = f"fit_{name}_seed42"
        log = self.c2 / "logs" / f"{jid}.log"
        cmd = cmd or [sys.executable, str(self.tool), name, str(secs), str(rc)]
        rec = {"schema": 1, "id": jid, "attempt": attempt, "session": session, "order": order,
               "published_utc": "2026-11-04T01:02:03Z",
               "job": {"id": jid, "phase": "S.1", "kind": "fit", "cmd": [str(x) for x in cmd], "gpu": True,
                       "optional": False, "log": str(log), "out": None},
               "needs": list(needs), "makes": [f"checkpoints/new_fields/out/{name}.txt"], "host": host,
               "pair": None}
        p = self.q / "jobs" / f"{jid}.a{attempt}.json"
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_name(f".{p.name}.tmp")
        tmp.write_text(json.dumps(rec, indent=2, sort_keys=True) + "\n")
        os.replace(tmp, p)
        return jid

    # the workers
    def start(self, host="wb-one", *args, **extra):
        out = open(self.tmp / f"worker_{host}_{len(self.procs)}.out", "w")
        p = subprocess.Popen([sys.executable, str(self.nf / "nf_worker.py"), "run", *args], cwd=self.w,
                             env=self.env(host, **extra), stdout=out, stderr=subprocess.STDOUT)
        out.close()
        self.procs.append(p)
        return p

    def tool_run(self, *args, host="wb-one", timeout=60, **extra):
        return subprocess.run([sys.executable, str(self.nf / args[0]), *args[1:]], cwd=self.w, capture_output=True,
                              text=True, env=self.env(host, **extra), timeout=timeout)

    def stop(self, proc, host="wb-one", timeout=30):
        r = self.tool_run("nf_worker.py", "stop", host=host)
        assert r.returncode == 0 and f"the worker on {host} ends after its current job" in r.stdout, r
        return proc.wait(timeout=timeout)

    def record(self, host="wb-one"):
        return read(self.q / "workers" / f"{host}.json")

    def done(self, jid, attempt=1):
        return read(self.q / "done" / f"{jid}.a{attempt}.json")

    def claim(self, jid, attempt=1):
        return read(self.q / "claims" / f"{jid}.a{attempt}.json")

    def started(self):
        return [ln.split() for ln in self.starts.read_text().splitlines()] if self.starts.is_file() else []

    def cleanup(self):
        for p in self.procs:
            if p.poll() is None:
                p.kill()
                p.wait(timeout=30)


def read(p):
    try:
        return json.loads(Path(p).read_text())
    except (OSError, ValueError):
        return None


def wait_for(cond, timeout=30.0, what="condition"):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        v = cond()
        if v:
            return v
        time.sleep(0.02)
    raise AssertionError(f"timed out waiting for {what}")


def fake_table(root, procs):
    """A folder laid out as /proc: one folder per process id with its command line and its parent."""
    for pid, (ppid, argv) in procs.items():
        d = Path(root) / str(pid)
        d.mkdir(parents=True)
        (d / "cmdline").write_bytes(b"\0".join(a.encode() for a in argv) + b"\0")
        (d / "stat").write_text(f"{pid} ({Path(argv[0]).name}) S {ppid} 0 0\n")
    return Path(root)


@pytest.fixture
def world(tmp_path):
    w = World(tmp_path)
    yield w
    w.cleanup()


# ------------------------------------------------------------------ W1 (T1): busy and pin

def test_w1_the_planners_own_lines_are_not_busy_and_the_job_is_pinned_to_the_uuid(world, tmp_path):
    shell = subprocess.Popen(["sleep", "120"])      # a live pid for the planner's queue shell
    try:
        planner = ["bash", str(world.nf / "nf_run_all.sh"), "--workers"]
        table = fake_table(tmp_path / "proc_planner", {shell.pid: (1, planner)})
        world.lock(pid=shell.pid)
        # the busy check alone reports the planner's shell and its lock, so the worker's filter is needed
        b = world.tool_run("nf_plan.py", "busy", NF_PROC_ROOT=table)
        assert b.returncode == 4, b.stdout + b.stderr
        assert f"process {shell.pid}: bash" in b.stdout and "nf_run_all.sh --workers" in b.stdout, b.stdout
        assert f"lock checkpoints/new_fields/QUEUE.lock.json: pid {shell.pid} alive" in b.stdout, b.stdout
        jid = world.publish("a1")
        p = world.start("wb-one", NF_PROC_ROOT=table, FAKE_SMI_UUIDS=UUID_A)
        d = wait_for(lambda: world.done(jid), what="the done record")
        assert d["ran"] is True and d["rc"] == 0 and d["host"] == "wb-one" and d["gpu_uuid"] == UUID_A, d
        assert set(d) == DONE_KEYS and d["worker_pid"] == p.pid and d["child_pid"] not in (None, p.pid), d
        # the job saw the worker's UUID, and NF_PY
        assert world.started() == [["a1", UUID_A, sys.executable]], world.started()
        assert (world.c2 / "out" / "a1.txt").read_text() == UUID_A
        log = (world.c2 / "logs" / f"{jid}.log").read_text().splitlines()
        cmd = " ".join(read(world.q / "jobs" / f"{jid}.a1.json")["job"]["cmd"])
        assert re.fullmatch(r"# \d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ " + re.escape(cmd), log[0]), log
        assert log[1] == f"# worker wb-one gpu {UUID_A} attempt 1", log
        c = world.claim(jid)
        assert c["by"] == "worker" and c["host"] == "wb-one" and c["gpu_uuid"] == UUID_A and c["worker_pid"] == p.pid
        assert world.stop(p) == 0
    finally:
        shell.kill()
        shell.wait()


@pytest.mark.parametrize("cause", ["trainer", "gpu_app"])
def test_w1_a_foreign_trainer_or_gpu_app_makes_the_worker_busy(world, tmp_path, cause):
    shell = subprocess.Popen(["sleep", "120"])
    try:
        procs = {shell.pid: (1, ["bash", str(world.nf / "nf_run_all.sh"), "--workers"])}
        extra = {}
        if cause == "trainer":
            procs[FAKE_PID] = (1, TRAINER)
            want = f"GPU busy: process {FAKE_PID}: {' '.join(TRAINER)}"
        else:
            extra["FAKE_SMI_APPS"] = "999, python, 30000"
            want = "GPU busy: gpu compute process: 999, python, 30000"
        table = fake_table(tmp_path / "proc_busy", procs)
        world.lock(pid=shell.pid)
        jid = world.publish("a1")
        p = world.start("wb-one", NF_PROC_ROOT=table, **extra)
        rec = wait_for(lambda: (world.record() or {}).get("problem", "").startswith("GPU busy") and world.record(),
                       what="the busy problem")
        assert rec["problem"] == want and rec["state"] == "idle" and rec["job"] is None, rec
        time.sleep(0.5)
        assert world.claim(jid) is None and world.done(jid) is None and world.started() == []
        assert not (world.q / "claims").exists() or not list((world.q / "claims").iterdir())
        assert world.stop(p) == 0
    finally:
        shell.kill()
        shell.wait()


# ------------------------------------------------------------------ W2: one worker per workbench

def test_w2_a_second_worker_on_the_same_workbench_is_refused(world):
    a = world.start("wb-one")
    lock = world.q / "workers" / "wb-one.lock.json"
    wait_for(lambda: (read(lock) or {}).get("pid") == a.pid, what="the first worker's lock")
    held = lock.read_text()
    r = world.tool_run("nf_worker.py", "run", host="wb-one")
    assert r.returncode == 4 and "a worker already runs on wb-one" in " ".join(r.stderr.split()), r.stderr
    c = world.tool_run("nf_worker.py", "check", host="wb-one")
    assert c.returncode == 4 and "already runs" in c.stderr and c.stdout == "", c
    assert lock.read_text() == held and a.poll() is None
    # another workbench holds its own lock beside it
    b = world.start("wb-two")
    lock2 = world.q / "workers" / "wb-two.lock.json"
    wait_for(lambda: (read(lock2) or {}).get("pid") == b.pid, what="the second workbench's lock")
    assert read(lock2)["hostname"] == "wb-two" and read(lock)["pid"] == a.pid
    ok = world.tool_run("nf_worker.py", "check", host="wb-three")
    assert ok.returncode == 0 and ok.stdout.strip() == "checkpoints/new_fields/logs/worker_wb-three.out", ok
    assert world.stop(a) == 0 and world.stop(b, host="wb-two") == 0
    assert not lock.exists() and not lock2.exists()


@pytest.mark.parametrize("pid", [DEAD, "12x", -3], ids=["dead", "not-a-number", "negative"])
def test_w2_a_lock_with_a_dead_or_bad_pid_is_replaced(world, pid):
    lock = world.q / "workers" / "wb-one.lock.json"
    lock.parent.mkdir(parents=True)
    lock.write_text(json.dumps({"pid": pid, "hostname": "wb-one", "utc": "2026-11-04T00:00:00Z"}))
    a = world.start("wb-one")
    wait_for(lambda: (read(lock) or {}).get("pid") == a.pid, what="the replaced lock")
    assert read(lock)["hostname"] == "wb-one"
    assert not list(lock.parent.glob(".wb-one.lock.json.takeover-*"))
    assert world.stop(a) == 0 and not lock.exists()


# ------------------------------------------------------------------ W3 (T8): one claim per job

def test_w3_two_workers_released_together_run_each_job_once(world):
    jids = [world.publish(f"j{i}", order=i, secs=0.1) for i in range(8)]
    before = {p.name: p.read_bytes() for p in (world.q / "jobs").iterdir()}
    reads_before = sorted((p.relative_to(world.c2), p.read_bytes()) for p in (world.c2 / "reads").rglob("*"))
    a = world.start("wb-one")
    b = world.start("wb-two", FAKE_SMI_UUIDS=UUID_B)
    for h in ("wb-one", "wb-two"):
        wait_for(lambda h=h: (world.record(h) or {}).get("problem") == "no planner holds QUEUE.lock.json",
                 what=f"{h} idle")
    world.lock()                # both workers see the jobs at the same moment
    wait_for(lambda: all(world.done(j) for j in jids), what="every done record")
    time.sleep(0.5)
    names = [s[0] for s in world.started()]
    assert sorted(names) == sorted(f"j{i}" for i in range(8)), names        # each job started once
    for j in jids:
        d, c = world.done(j), world.claim(j)
        assert set(d) == DONE_KEYS and d["ran"] is True and d["rc"] == 0, d
        assert c["by"] == "worker" and c["host"] == d["host"] and c["gpu_uuid"] == d["gpu_uuid"], (c, d)
        assert {"wb-one": UUID_A, "wb-two": UUID_B}[d["host"]] == d["gpu_uuid"]
    assert sorted(p.name for p in (world.q / "claims").iterdir()) == sorted(f"{j}.a1.json" for j in jids)
    # the workers wrote nothing that belongs to the planner
    assert {p.name: p.read_bytes() for p in (world.q / "jobs").iterdir()} == before
    assert sorted((p.relative_to(world.c2), p.read_bytes()) for p in (world.c2 / "reads").rglob("*")) == reads_before
    for n in ("DECISIONS.log", "queue_state.json", "queue.log", "KEPT.json"):
        assert not (world.c2 / n).exists(), n
    assert world.stop(a) == 0 and world.stop(b, host="wb-two") == 0


def test_w3_a_claim_is_made_once_against_another_claim_or_a_withdrawal(world, monkeypatch):
    monkeypatch.setenv("NF_OUT", str(world.c2))
    W = load("nf_worker")
    jid = world.publish("x")
    path = world.q / "jobs" / f"{jid}.a1.json"
    rec = read(path)
    assert W.claim(rec, path, "wb-one", UUID_A, 11) is True
    assert W.claim(rec, path, "wb-two", UUID_B, 22) is False
    assert world.claim(jid)["host"] == "wb-one"
    jid2 = world.publish("y")
    W.Q.create_once(W.Q.claim_path(jid2, 1), {"schema": 1, "id": jid2, "attempt": 1, "by": "planner",
                                              "withdrawn": True, "reason": "test", "host": "planner", "pid": 1,
                                              "claimed_utc": "t"})
    path2 = world.q / "jobs" / f"{jid2}.a1.json"
    assert W.claim(read(path2), path2, "wb-one", UUID_A, 11) is False
    assert W.claimable("wb-one", "s1") == []


# ------------------------------------------------------------------ W4: needs

def test_w4_a_job_whose_need_is_missing_is_never_started(world):
    world.lock()
    need = "checkpoints/new_fields/runs/nf_a1/seed42/best.ckpt"
    jid = world.publish("missing", order=1, needs=[need, "fraud/configs/sequential_hier_allpos.yaml"])
    ok = world.publish("present", order=2, needs=["fraud/configs/sequential_hier_allpos.yaml"])
    p = world.start("wb-one")
    wait_for(lambda: world.done(jid) and world.done(ok), what="both done records")
    d = world.done(jid)
    assert d["ran"] is False and d["rc"] == 4 and d["child_pid"] is None and d["started_utc"] is None, d
    assert "a need is missing" in d["note"] and need in d["note"], d
    assert world.done(ok)["ran"] is True and world.done(ok)["rc"] == 0
    assert [s[0] for s in world.started()] == ["present"]
    assert not (world.c2 / "logs" / f"{jid}.log").exists()
    assert world.stop(p) == 0


# ------------------------------------------------------------------ W5: hosts and order

def test_w5_a_job_for_another_workbench_is_never_claimed_and_the_lowest_order_goes_first(world, monkeypatch):
    world.lock()
    other1 = world.publish("other1", order=0, host="wb-two")
    late = world.publish("late", order=5, host=None)
    mine = world.publish("mine", order=2, host="wb-one")
    other2 = world.publish("other2", order=1, host="wb-two")
    first = world.publish("first", order=1, host=None)
    monkeypatch.setenv("NF_OUT", str(world.c2))
    W = load("nf_worker")
    assert [t[1] for t in W.claimable("wb-one", "s1")] == [first, mine, late]
    assert [t[1] for t in W.claimable("wb-two", "s1")] == [other1, first, other2, late]
    p = world.start("wb-one")
    wait_for(lambda: world.done(late), what="the last job")
    time.sleep(0.5)
    assert [s[0] for s in world.started()] == ["first", "mine", "late"]
    assert world.claim(other1) is None and world.claim(other2) is None
    assert world.stop(p) == 0
    assert [t[1] for t in W.claimable("wb-two", "s1")] == [other1, other2]


# ------------------------------------------------------------------ W6 (T3): heartbeat and a killed worker

def test_w6_heartbeats_while_running_and_a_killed_workers_claim_is_never_run_again(world):
    world.lock()
    fast = {"NF_TEST_HEARTBEAT_SECONDS": "0.2"}
    jid = world.publish("beat", order=1, secs=1.5)
    p = world.start("wb-one", **fast)
    rp = world.q / "workers" / "wb-one.json"
    beats = set()
    end = time.monotonic() + 30
    while not world.done(jid) and time.monotonic() < end:
        try:
            st = rp.stat()
            r = read(rp)
        except OSError:
            continue
        if r and r["state"] == "running" and r["job"] == f"{jid}.a1":
            beats.add((st.st_ino, st.st_mtime_ns))
        time.sleep(0.01)
    assert world.done(jid)["rc"] == 0
    assert len(beats) >= 3, beats
    # SIGKILL of the worker mid-job: the job finishes its outputs, and no done record is written
    killed = world.publish("killed", order=2, secs=2.0)
    wait_for(lambda: (world.record() or {}).get("job") == f"{killed}.a1", what="the second job running")
    os.kill(p.pid, signal.SIGKILL)
    p.wait(timeout=30)
    wait_for(lambda: (world.c2 / "out" / "killed.txt").is_file(), what="the orphaned job's output")
    assert world.done(killed) is None
    # a new worker on that workbench neither reruns it nor writes its done record, and goes on with the next job
    nxt = world.publish("next", order=3)
    p2 = world.start("wb-one", **fast)
    wait_for(lambda: world.done(nxt), what="the next job")
    time.sleep(0.5)
    assert [s[0] for s in world.started()] == ["beat", "killed", "next"]
    assert world.done(killed) is None and world.claim(killed)["worker_pid"] == p.pid
    assert world.stop(p2) == 0
    out = (world.tmp / "worker_wb-one_1.out").read_text()
    assert f"claims of this workbench with no done record (never run again here): {killed}.a1" in out, out


# ------------------------------------------------------------------ W7 (T5): stop

def test_w7_stop_while_idle_ends_the_worker_within_one_poll(world):
    world.lock()
    p = world.start("wb-one", NF_TEST_POLL_SECONDS="1")
    wait_for(lambda: (world.record() or {}).get("state") == "idle", what="idle")
    t0 = time.monotonic()
    assert world.stop(p, timeout=10) == 0
    assert time.monotonic() - t0 < 1.0 + 3.0
    rec = world.record()
    assert rec["state"] == "stopped" and rec["job"] is None and rec["pid"] == p.pid, rec
    assert not (world.q / "workers" / "wb-one.lock.json").exists()
    jid = world.publish("after")
    time.sleep(0.5)
    assert world.claim(jid) is None


@pytest.mark.parametrize("how", ["stop", "sigterm"])
def test_w7_stop_while_running_finishes_the_job_then_stops(world, how):
    world.lock()
    jid = world.publish("long", order=1, secs=1.5)
    jid2 = world.publish("never", order=2)
    p = world.start("wb-one", NF_TEST_HEARTBEAT_SECONDS="0.2")
    wait_for(lambda: (world.record() or {}).get("state") == "running", what="running")
    if how == "stop":
        r = world.tool_run("nf_worker.py", "stop")
        assert r.returncode == 0
    else:
        p.send_signal(signal.SIGTERM)
    seen = wait_for(lambda: (world.record() or {}).get("state") in ("stopping", "stopped") and world.record(),
                    what="stopping")
    assert seen["state"] == "stopping" or world.done(jid), seen
    assert p.wait(timeout=30) == 0
    d = world.done(jid)
    assert d["ran"] is True and d["rc"] == 0 and (world.c2 / "out" / "long.txt").is_file(), d
    assert world.record()["state"] == "stopped"
    assert world.claim(jid2) is None and not (world.q / "workers" / "wb-one.lock.json").exists()


# ------------------------------------------------------------------ W8: sessions

def test_w8_jobs_of_another_session_or_without_a_planner_are_never_claimed(world):
    jid = world.publish("s1job", order=1, session="s1")
    old = world.publish("s0job", order=0, session="s0")
    p = world.start("wb-one")
    # no queue lock at all
    rec = wait_for(lambda: world.record(), what="the record")
    wait_for(lambda: (world.record() or {}).get("problem") == "no planner holds QUEUE.lock.json", what="no planner")
    # the one-slot queue's lock (no mode)
    world.lock(mode=None)
    time.sleep(0.5)
    assert world.record()["problem"] == "no planner holds QUEUE.lock.json"
    # a planner of another session
    world.lock(session="s9")
    time.sleep(0.5)
    assert world.record()["problem"] == "" and world.started() == []
    assert world.claim(jid) is None and world.claim(old) is None and rec["state"] == "idle"
    # its own session's job only
    world.lock(session="s1")
    wait_for(lambda: world.done(jid), what="the session's job")
    time.sleep(0.3)
    assert world.claim(old) is None and [s[0] for s in world.started()] == ["s1job"]
    assert world.stop(p) == 0


# ------------------------------------------------------------------ W9: the job's program

def test_w9_a_job_whose_program_does_not_exist_here_is_left_for_another_worker(world):
    world.lock()
    bad = world.publish("bad", order=0, cmd=["/nonexistent/bin/python3", "x.py"])
    good = world.publish("good", order=1)
    p = world.start("wb-one")
    wait_for(lambda: world.done(good), what="the good job")
    rec = wait_for(lambda: (world.record() or {}).get("problem") and world.record(), what="the problem")
    assert rec["problem"] == "the job's program /nonexistent/bin/python3 does not exist on this workbench", rec
    assert world.claim(bad) is None and [s[0] for s in world.started()] == ["good"]
    assert world.stop(p) == 0


# ------------------------------------------------------------------ W10: the start script

def _sh(world, *args, **extra):
    return subprocess.run(["bash", str(world.nf / "nf_worker.sh"), *args], cwd=world.w, capture_output=True,
                          text=True, env=world.env("wb-one", NF_NO_TAIL="1", **extra), timeout=60)


def test_w10_the_start_script(world):
    r = _sh(world)
    assert r.returncode == 2 and "set PY" in r.stderr, r
    r = _sh(world, PY=sys.executable, FAKE_SMI_UUIDS=f"{UUID_A} {UUID_B}")      # two GPUs, no --gpu
    assert r.returncode == 4 and "lists 2 GPUs" in " ".join(r.stderr.split()), r
    r = _sh(world, "--gpu", UUID_B, PY=sys.executable, FAKE_SMI_UUIDS=f"{UUID_A} {UUID_B}")
    assert r.returncode == 0, r
    m = re.search(r"^worker started, pid (\d+)$", r.stdout, re.M)
    assert m and "report: " in r.stdout and "nf_report.py" in r.stdout, r.stdout
    pid = int(m.group(1))
    try:
        lock = world.q / "workers" / "wb-one.lock.json"
        wait_for(lambda: (read(lock) or {}).get("pid") == pid, what="the started worker's lock")
        wait_for(lambda: (world.record() or {}).get("gpu_uuid") == UUID_B, what="the worker's record")
        r2 = _sh(world, "--gpu", UUID_B, PY=sys.executable, FAKE_SMI_UUIDS=f"{UUID_A} {UUID_B}")
        assert r2.returncode == 4 and "already runs" in r2.stderr and "worker started" not in r2.stdout, r2
        out = world.c2 / "logs" / "worker_wb-one.out"
        assert "=== nf_worker " in out.read_text()
        assert world.tool_run("nf_worker.py", "stop").returncode == 0
        wait_for(lambda: not lock.exists(), what="the worker's end")
        assert "stopped (stop file)" in out.read_text()
    finally:
        try:
            os.kill(pid, signal.SIGKILL)
        except OSError:
            pass


def test_w10_gpu_uuid_rules(world, monkeypatch):
    W = load("nf_worker")
    smi = str(world.tmp / "bin" / "nvidia-smi")
    monkeypatch.setenv("FAKE_SMI_UUIDS", UUID_A)
    assert W.gpu_uuid(None, smi) == UUID_A and W.gpu_uuid(UUID_A, smi) == UUID_A
    with pytest.raises(W.Refused, match="not listed"):
        W.gpu_uuid(UUID_B, smi)
    monkeypatch.setenv("FAKE_SMI_UUIDS", "")
    with pytest.raises(W.Refused, match="lists 0 GPUs"):
        W.gpu_uuid(None, smi)
    with pytest.raises(W.Refused, match="could not list"):
        W.gpu_uuid(None, str(world.tmp / "no-nvidia-smi"))


# ------------------------------------------------------------------ W11: the documents

DOC_COMMANDS = re.compile(r"(nf_worker\.py|nf_plan\.py|nf_worker\.sh|nf_start\.sh)((?:\s+(?:--?[a-z][a-z-]*|"
                          r"[a-z]+|<[^>]+>))*)")


# The root documents are in the package and the tree, not in the project on the pod: POD.md step 3 copies only the
# four package folders. There, only POD.md is checked.
ROOT_DOCS = all((ROOT / n).is_file() for n in ("README_FIRST.md", "FEATURES_AND_TESTING.md"))


def _new_text():
    pod = (NF_SRC / "POD.md").read_text()
    i, j = pod.index("## 4b. Two workbenches: one planner, one worker on each"), pod.index("## 5. ")
    assert i < j and pod.index("## 4. ") < i
    if not ROOT_DOCS:
        return {"POD.md 4b": pod[i:j]}
    readme = (ROOT / "README_FIRST.md").read_text()
    k = readme.index("## One queue, on one workbench")
    sec = readme[k:readme.index("\n## ", k + 5)]
    para = sec[sec.index("Two workbenches:"):]
    ft = (ROOT / "FEATURES_AND_TESTING.md").read_text()
    s14 = ft[ft.index("14. **Preflight and start.**"):ft.index("15. **Each morning.**")]
    s15 = ft[ft.index("15. **Each morning.**"):ft.index("16. **After the fits.**")]
    return {"POD.md 4b": pod[i:j], "README_FIRST.md": para,
            "FEATURES_AND_TESTING.md 14": s14[s14.index("Two workbenches (temporary)"):],
            "FEATURES_AND_TESTING.md 15": s15[s15.index("With workers"):s15.index("Watch the curves")]}


def test_w11_the_documents(world):
    texts = _new_text()
    pod = texts["POD.md 4b"]
    for want in ("One worker is the normal mode", "one-slot queue", "job boundary", "nf_start.sh --workers",
                 "nf_worker.sh", "nf_worker.py stop", "nf_plan.py stop", "nf_plan.py release <job id>",
                 "nf_report.py", "seed pair", "where it was trained", "`ran` line", "GPU UUID", "with=",
                 "contention", "every 60 seconds", "15 minutes", "UNKNOWN", "not proof", "never starts that job "
                 "again", "_crashed", "safe now", "same Python path", "same `NF_OUT`", "No 2x speed",
                 "exit codes are those of section 4", "0 also ends a requested stop"):
        assert want in " ".join(pod.split()), want
    if ROOT_DOCS:
        assert "POD.md` section 4b" in texts["README_FIRST.md"] and "planner" in texts["README_FIRST.md"]
        s14, s15 = texts["FEATURES_AND_TESTING.md 14"], texts["FEATURES_AND_TESTING.md 15"]
        assert "nf_start.sh --workers" in s14 and "nf_worker.sh" in s14 and "section 4b" in s14
        assert len(s14.strip().splitlines()) == 2 and "UNKNOWN" in s15 and "worker" in s15
    # every command they give is one the tools accept
    plan_subs = set()
    for name, text in texts.items():
        for m in DOC_COMMANDS.finditer(" ".join(text.split())):
            tool, rest = m.group(1), re.sub(r"<[^>]+>", "<x>", m.group(2)).split()
            if tool == "nf_worker.py":
                assert rest and rest[0] in ("run", "stop", "check"), (name, m.group(0))
                h = world.tool_run("nf_worker.py", rest[0], "--help")
                assert h.returncode == 0 and "usage:" in h.stdout, (m.group(0), h.stderr)
                for flag in [x for x in rest[1:] if x.startswith("--")]:
                    assert flag in h.stdout, (m.group(0), flag)
            elif tool == "nf_worker.sh":
                assert all(x in ("--gpu", "<x>") for x in rest), (name, m.group(0))
            elif tool == "nf_start.sh":
                assert all(x == "--workers" for x in rest), (name, m.group(0))
            else:
                plan_subs.add(" ".join(x for x in rest if not x.startswith("<")))
    # the planner's commands are the spec's (their --help is checked after the merge, in the together test)
    assert plan_subs <= {"stop", "release", ""}, plan_subs
    for flag in ("--gpu",):
        assert flag in world.tool_run("nf_worker.py", "run", "--help").stdout
        assert flag in world.tool_run("nf_worker.py", "check", "--help").stdout
    # no em dash, no absolute machine path, no forbidden name
    mine = [NF_SRC / "nf_worker.py", NF_SRC / "nf_worker.sh", NF_SRC / "nf_queue.py", Path(__file__),
            HERE / "test_new_fields_n1_together.py"]
    for name, text in list(texts.items()) + [(p.name, p.read_text()) for p in mine]:
        assert chr(0x2014) not in text, name
        assert not re.search(r"(?<![\w.$}])/(home|Users|root|mnt|workspace)/|[A-Z]:\\\\", text), name
    docs = [ROOT / "README_FIRST.md", ROOT / "FEATURES_AND_TESTING.md"] if ROOT_DOCS else []
    r = subprocess.run([sys.executable, str(NF_SRC / "nf_naming_check.py"), str(NF_SRC / "POD.md"),
                        *map(str, docs), *map(str, mine)],
                       capture_output=True, text=True, timeout=120)
    assert r.returncode == 0, r.stdout
