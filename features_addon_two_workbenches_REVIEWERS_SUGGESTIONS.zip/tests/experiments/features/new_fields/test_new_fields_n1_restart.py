"""A CPU planner may restart while a worker uses its GPU; the one-slot queue may not.

Exercise the public shell entry point, the real preflight, and queue-to-preflight routing.
The project fixtures and GPU/process observations are synthetic; no training is launched.
"""
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from new_fields_spine_world import NF_REL, NF_SRC, env, make_world  # noqa: E402


def world(tmp_path):
    w = make_world(tmp_path, fake_smi_apps="123, python, 4000")
    shutil.copy2(NF_SRC / "nf_queue.py", w / NF_REL / "nf_queue.py")
    return w


def python_in(w, tmp_path, body):
    source = "import sys\nsys.path.insert(0, " + repr(str(w / NF_REL)) + ")\n" + body
    return subprocess.run([sys.executable, "-c", source], cwd=w, env=env(w, tmp_path),
                          capture_output=True, text=True, timeout=45)


@pytest.mark.parametrize("workers", [False, True])
def test_shell_starts_only_cpu_planner_while_gpu_is_busy(tmp_path, workers):
    w = world(tmp_path)
    marker = w / "checkpoints/new_fields/shell_started"
    # Observe forwarding without invoking a real queue or a trainer from the background shell.
    (w / NF_REL / "nf_run_all.sh").write_text(
        '#!/bin/bash\nprintf "%s\\n" "$@" > "$NF_OUT/shell_started"\n')
    args = ["bash", str(w / NF_REL / "nf_start.sh")]
    if workers:
        args.append("--workers")
    r = subprocess.run(args, cwd=w, env=env(w, tmp_path, PY=sys.executable, NF_NO_TAIL="1"),
                       capture_output=True, text=True, timeout=45)
    if not workers:
        assert r.returncode == 4, (r.stdout, r.stderr)
        assert not marker.exists()
        return
    assert r.returncode == 0, (r.stdout, r.stderr)
    end = time.monotonic() + 5
    while not marker.exists() and time.monotonic() < end:
        time.sleep(0.02)
    assert marker.is_file(), (r.stdout, r.stderr)
    assert marker.read_text().splitlines() == ["--workers"]


def test_planner_preflight_retains_every_non_gpu_check(tmp_path):
    w = world(tmp_path)
    r = python_in(w, tmp_path, '''
import json
import nf_plan as P
P.preflight()
normal = P.C.read_json(P.c2("reads", "preflight.json"))
P.preflight(workers=True)
planner = P.C.read_json(P.c2("reads", "preflight.json"))
print("CHECKS=" + json.dumps({"normal": normal["checks"], "planner": planner["checks"]}))
''')
    assert r.returncode == 0, (r.stdout, r.stderr)
    result = json.loads(next(x[7:] for x in r.stdout.splitlines() if x.startswith("CHECKS=")))
    normal = {x["check"]: x for x in result["normal"]}
    planner = {x["check"]: x for x in result["planner"]}
    assert normal.pop("gpu_free")["ok"] is False
    assert planner.pop("gpu_free")["ok"] is True
    assert planner == normal
    assert not planner["stage1_checks"]["ok"]  # fixture lacks stage 1 result proofs
    assert "configs" in planner and "artifact_check" in planner and "control" in planner


@pytest.mark.parametrize("workers", [False, True])
def test_queue_selects_preflight_for_its_execution_mode(tmp_path, workers):
    w = world(tmp_path)
    r = python_in(w, tmp_path, '''
from types import SimpleNamespace
import os
import nf_plan as P
seen = []
WORKERS = ''' + repr(workers) + '''
if WORKERS:
    def check(*, workers=False):
        seen.append(workers)
        return P.C.OK if workers else P.C.STOP
    P.preflight = check
    P.planner_loop = lambda session: P.C.OK
else:
    # Existing no-argument preflight callers and test replacements keep working.
    def check():
        seen.append(False)
        return P.C.OK
    P.preflight = check
    P.next_job = lambda ctx: {"kind": "done", "notes": []}
rc = P.queue(SimpleNamespace(queue_pid=os.getpid(), workers=WORKERS, skip_preflight=False, max_jobs=0))
assert rc == P.C.OK, (rc, seen)
assert seen == [WORKERS], seen
''')
    assert r.returncode == 0, (r.stdout, r.stderr)
