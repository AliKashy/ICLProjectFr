"""The worker of one workbench (N1: one planner, one worker on each workbench; POD.md section 4b).

  PY=$PY bash $NF/nf_worker.sh        # starts `nf_worker.py run` in the background (never run `run` by hand)
  $PY $NF/nf_worker.py stop           # this workbench's worker ends after its current job; refused (exit 4)
                                     # while an unfinished seed pair depends on this workbench
  $PY $NF/nf_worker.py check          # exit 4 when a worker already runs here or the GPU cannot be read

The planner (nf_plan.py queue --workers) publishes GPU jobs under C2/queue/jobs/. This worker takes the published
job with the lowest order that it may take (the planner's session, its own workbench or any), by making the job's
claim file only if no such file exists, so two workers never take the same job. It runs the job's command with
CUDA_VISIBLE_DEVICES set to its GPU's UUID, writes its record (the heartbeat) at least every Q.HEARTBEAT_SECONDS,
and writes a done record when the command has ended. It never kills its job and never runs a job twice: a claim
without a done record (a worker of this workbench that was killed) is never run again by a later worker.

It writes only its own files: workers/<host>.json, workers/<host>.lock.json, the claims it makes, their done
records, and the job's log. It never writes jobs/, reads/, DECISIONS.log, queue_state.json, queue.log or KEPT.json.
Exit codes: 0 stopped on request; 1 a crash; 2 bad arguments; 4 refused.
"""
import argparse
import hashlib
import json
import os
import shutil
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nf_common as C  # noqa: E402
import nf_queue as Q  # noqa: E402

LOCK_WAIT_SECONDS = 2.0     # a lock file another start has just made holds its record within this time
QUEUE_LOCK = "QUEUE.lock.json"
STOP = {"why": None}        # set by SIGTERM or SIGINT: finish the running job, take nothing more, stop


class Refused(Exception):
    """The worker refuses to start or to go on (exit 4), with the reason for the owner."""


# ------------------------------------------------------------------ the GPU, the lock, the record

def gpu_uuid(choice=None, nvidia_smi="nvidia-smi"):
    """This workbench's GPU UUID from nvidia-smi. With choice, it must be listed; without, there must be one GPU."""
    lines = C._nvidia(["--query-gpu=uuid", "--format=csv,noheader"], nvidia_smi)
    if lines is None:
        raise Refused(f"{nvidia_smi} could not list the GPUs (nvidia-smi --query-gpu=uuid): the worker needs the "
                      "GPU's UUID")
    found = [ln.strip() for ln in lines if ln.strip()]
    if choice:
        if choice not in found:
            raise Refused(f"--gpu {choice} is not listed by nvidia-smi on this workbench (found: "
                          f"{', '.join(found) or 'none'})")
        return choice
    if len(found) != 1:
        raise Refused(f"nvidia-smi lists {len(found)} GPUs on this workbench ({', '.join(found) or 'none'}): give "
                      "the worker's GPU with --gpu <uuid>")
    return found[0]


def _alive(pid):
    """A process of this machine with that id exists (a process of another user counts as alive)."""
    try:
        os.kill(pid, 0)
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def _snapshot(path):
    """(identity, record) of a lock file as it is now, read through one open file; record None while it is empty or
    unreadable (read again for up to LOCK_WAIT_SECONDS). None when there is no file."""
    deadline = time.monotonic() + LOCK_WAIT_SECONDS
    while True:
        try:
            fd = os.open(str(path), os.O_RDONLY)
        except FileNotFoundError:
            return None
        try:
            st = os.fstat(fd)
            chunks = []
            while True:
                b = os.read(fd, 1 << 16)
                if not b:
                    break
                chunks.append(b)
        finally:
            os.close(fd)
        raw = b"".join(chunks)
        try:
            rec = json.loads(raw.decode("utf-8"))
        except ValueError:
            rec = None
        if not (isinstance(rec, dict) and "pid" in rec):
            rec = None
        if rec is not None or time.monotonic() >= deadline:
            return (st.st_dev, st.st_ino, raw), rec
        time.sleep(0.05)


def held_by(h):
    """The pid of a live worker that holds this workbench's lock, else None."""
    rec = Q.read(Q.worker_lock_path(h))
    pid = C.lock_pid(rec) if rec else None
    return pid if pid is not None and _alive(pid) else None


def take_lock(h, pid):
    """workers/<h>.lock.json: one worker per workbench. Made only if absent. A lock whose pid is alive on this
    machine refuses (exit 4). A lock with a dead or bad pid is replaced as the queue's lock is: a takeover file named
    after the stale lock's bytes, made only if absent; the lock still the same stale one; a fresh record renamed
    over it."""
    p = Q.worker_lock_path(h)
    mine = {"pid": pid, "hostname": h, "utc": C.utc_now()}
    for _ in range(5):
        if Q.create_once(p, mine):
            return p
        snap = _snapshot(p)
        if snap is None:
            continue            # its owner removed it between the two steps: try again
        ident, held = snap
        held_pid = C.lock_pid(held) if held else None
        if held_pid is not None and held_pid != pid and _alive(held_pid):
            raise Refused(f"a worker already runs on {h}: {C.rel(p)} names pid {held_pid} since "
                          f"{held.get('utc')}; stop it first ({C.rel(Path(__file__))} stop)")
        tag = hashlib.sha256(f"{ident[0]}:{ident[1]}:".encode() + ident[2]).hexdigest()[:16]
        claim = p.with_name(f".{p.name}.takeover-{tag}")
        if not Q.create_once(claim, mine):
            now = _snapshot(p)
            if now is None or now[0] != ident:
                continue        # another start replaced it first: look again
            raise Refused(f"another worker start is replacing {C.rel(p)}; if none runs, remove {C.rel(claim)} and "
                          "start again")
        try:
            now = _snapshot(p)
            if now is None or now[0] != ident:
                continue        # the lock changed meanwhile: look again
            Q.write_whole(p, mine)      # a fresh record renamed over the stale one
        finally:
            try:
                claim.unlink()
            except OSError:
                pass
        return p
    raise Refused(f"{C.rel(p)} kept changing while this worker started: start it again")


def drop_lock(h, pid):
    """Removes this worker's own lock (only while it still names this worker)."""
    p = Q.worker_lock_path(h)
    rec = Q.read(p)
    if rec is not None and C.lock_pid(rec) == pid:
        try:
            p.unlink()
        except OSError:
            pass


def write_record(rec, state, job=None, problem=""):
    """workers/<host>.json, written whole, with a fresh heartbeat."""
    out = dict(rec, schema=Q.SCHEMA, heartbeat_utc=C.utc_now(), state=state, job=job, problem=problem or "")
    Q.write_whole(Q.worker_path(rec["host"]), out)
    return out


# ------------------------------------------------------------------ what may be taken

def planner_session():
    """The session of the planner that holds QUEUE.lock.json, or None (no lock, or the one-slot queue's lock)."""
    rec = Q.read(C.c2() / QUEUE_LOCK)
    if rec and rec.get("mode") == "planner" and rec.get("session"):
        return str(rec["session"])
    return None


def busy_here():
    """The busy check of this workbench (C.busy), without the lines of this workbench's own planner: its queue shell
    (the pid of QUEUE.lock.json) and its lock. The planner runs only CPU jobs itself."""
    up = C.upstream() if (C._settings_dir() / "UPSTREAM.yaml").is_file() else {}
    found = C.busy(extra_scripts=[((up or {}).get("stage0") or {}).get("queue_script") or "lr_screen.sh"])
    rec = Q.read(C.c2() / QUEUE_LOCK)
    if not (rec and rec.get("mode") == "planner" and rec.get("hostname") == socket.gethostname()):
        return found
    lp = C.lock_pid(rec)
    mine = (f"process {lp}: ", f"lock {C.rel(C.c2() / QUEUE_LOCK)}: ")
    return [x for x in found if not x.startswith(mine)]


def claimable(h, session):
    """[(order, job id, attempt, path, record)], lowest order first: published jobs of this session with no claim
    file, for this workbench or for any."""
    claims = Q.listing("claims")
    out = []
    for (jid, n), p in Q.listing("jobs").items():
        if (jid, n) in claims:
            continue
        rec = Q.read(p)
        if rec is None or rec.get("session") != session or rec.get("host") not in (None, h):
            continue
        if rec.get("id") != jid or rec.get("attempt") != n or not isinstance(rec.get("job"), dict):
            continue
        try:
            order = int(rec.get("order"))
        except (TypeError, ValueError):
            continue
        out.append((order, jid, n, p, rec))
    return sorted(out, key=lambda t: (t[0], t[1], t[2]))


def program_problem(cmd):
    """None when the job's program (cmd[0]) is an executable file here, else the problem line."""
    prog = str(cmd[0]) if cmd else ""
    if not prog:
        return "the job has no command"
    if "/" in prog:
        p = Path(prog) if Path(prog).is_absolute() else C.ROOT / prog
        ok = p.is_file() and os.access(p, os.X_OK)
    else:
        ok = shutil.which(prog) is not None
    return None if ok else f"the job's program {prog} does not exist on this workbench"


def claim(rec, path, h, uuid, pid):
    """The claim file, made only if absent. True when this worker won; False when another worker or the planner's
    withdrawal was first."""
    raw = Path(path).read_bytes()
    c = {"schema": Q.SCHEMA, "id": rec["id"], "attempt": rec["attempt"], "by": "worker", "host": h,
         "gpu_uuid": uuid, "worker_pid": pid, "claimed_utc": C.utc_now(), "job_sha256": C.sha256_bytes(raw)}
    return Q.create_once(Q.claim_path(rec["id"], rec["attempt"]), c)


# ------------------------------------------------------------------ one job

def stop_requested(h):
    return STOP["why"] is not None or Q.worker_stop_path(h).exists()


def _not_started(rec, h):
    """Why a claimed job must not start, or None."""
    jid, n = rec["id"], rec["attempt"]
    mine = Q.read(Q.claim_path(jid, n)) or {}
    try:
        raw = Q.job_path(jid, n).read_bytes()
    except OSError:
        return "the job file is gone since it was claimed: not started"
    try:
        now = json.loads(raw.decode("utf-8"))
    except ValueError:
        now = None
    if C.sha256_bytes(raw) != mine.get("job_sha256") or now != rec:
        return "the job file changed after it was claimed: not started"
    missing = [x for x in rec.get("needs") or [] if not (C.ROOT / str(x)).exists()]
    if missing:
        return f"a need is missing on this workbench: {', '.join(str(x) for x in missing)}: not started"
    return program_problem(rec["job"].get("cmd") or [])


def run_job(rec, h, uuid, wrec):
    """Runs a claimed job and returns its done record, which is written whatever happens. The worker never kills
    its job: when anything fails after the start, it still waits for the job's end before writing the record."""
    jid, n = rec["id"], rec["attempt"]
    j = rec["job"]
    tag = f"{jid}.a{n}"
    done = {"schema": Q.SCHEMA, "id": jid, "attempt": n, "host": h, "gpu_uuid": uuid, "worker_pid": os.getpid(),
            "child_pid": None, "started_utc": None, "ended_utc": None, "rc": C.REFUSED, "ran": False, "note": ""}
    child = None
    try:
        why = _not_started(rec, h)
        if why:
            done["note"] = why
            return done
        log = Path(j["log"]) if Path(j["log"]).is_absolute() else C.ROOT / j["log"]
        log.parent.mkdir(parents=True, exist_ok=True)
        env = dict(os.environ)
        env["CUDA_VISIBLE_DEVICES"] = uuid
        env["NF_PY"] = os.environ.get("NF_PY") or sys.executable
        with open(log, "a", encoding="utf-8") as lf:
            lf.write(f"# {C.utc_now()} {' '.join(j['cmd'])}\n")
            lf.write(f"# worker {h} gpu {uuid} attempt {n}\n")
            lf.flush()
            done["started_utc"] = C.utc_now()
            child = subprocess.Popen(j["cmd"], cwd=C.ROOT, stdout=lf, stderr=subprocess.STDOUT, env=env,
                                     start_new_session=True)
            done["child_pid"] = child.pid
            done["ran"] = True
            write_record(wrec, "running", tag)
            while True:
                try:
                    done["rc"] = child.wait(timeout=Q.HEARTBEAT_SECONDS)
                    break
                except subprocess.TimeoutExpired:
                    write_record(wrec, "stopping" if stop_requested(h) else "running", tag)
    except Exception as e:  # noqa: BLE001
        done["note"] = f"worker error: {type(e).__name__}: {e}"     # rc stays 4 when nothing started
    finally:
        if child is not None and child.returncode is None:
            while True:             # the job still runs: wait for it, never kill it
                try:
                    done["rc"] = child.wait()
                    break
                except Exception:  # noqa: BLE001
                    time.sleep(1)
        done["ended_utc"] = C.utc_now()
        Q.write_whole(Q.done_path(jid, n), done)
    return done


# ------------------------------------------------------------------ the loop

def _wait(h, wrec, problem):
    """Sleeps Q.POLL_SECONDS (or less, when a stop is asked), heartbeating at least every Q.HEARTBEAT_SECONDS."""
    end = time.monotonic() + Q.POLL_SECONDS
    beat = time.monotonic()
    while time.monotonic() < end and not stop_requested(h):
        time.sleep(max(0.01, min(0.2, Q.POLL_SECONDS, end - time.monotonic())))
        if time.monotonic() - beat >= Q.HEARTBEAT_SECONDS:
            write_record(wrec, "idle", None, problem)
            beat = time.monotonic()


def _on_signal(signum, frame):
    STOP["why"] = signal.Signals(signum).name


def loop(h, uuid, once=False):
    """Takes this workbench's lock, then claims and runs jobs until a stop is asked (exit 0). once: one round only
    (tests)."""
    pid = os.getpid()
    take_lock(h, pid)
    STOP["why"] = None
    old = {}
    for s in (signal.SIGTERM, signal.SIGINT):
        try:
            old[s] = signal.signal(s, _on_signal)
        except ValueError:      # not the main thread (tests): the stop file still works
            pass
    try:
        Q.worker_stop_path(h).unlink()
    except FileNotFoundError:
        pass
    wrec = {"host": h, "gpu_uuid": uuid, "pid": pid, "py": os.environ.get("NF_PY") or sys.executable,
            "started_utc": C.utc_now()}
    state, problem = "stopped", ""
    print(f"worker on {h}, gpu {uuid}, pid {pid}, started {wrec['started_utc']}", flush=True)
    done_keys = set(Q.listing("done"))
    orphans = []
    for key, p in sorted(Q.listing("claims").items()):
        c = Q.read(p) or {}
        if c.get("by") == "worker" and c.get("host") == h and key not in done_keys:
            orphans.append(Q.name(*key)[:-5])
    if orphans:
        print(f"claims of this workbench with no done record (never run again here): {', '.join(orphans)}",
              flush=True)
    try:
        write_record(wrec, "idle")
        while True:
            if stop_requested(h):
                break
            problem = ""
            session = planner_session()
            cands = claimable(h, session) if session else []
            took = None
            if session is None:
                problem = "no planner holds QUEUE.lock.json"
            elif cands:
                found = busy_here()
                if found:
                    problem = f"GPU busy: {found[0]}"
                else:
                    for _order, _jid, _n, path, rec in cands:
                        why = program_problem(rec["job"].get("cmd") or [])
                        if why:
                            problem = why       # left for another worker
                            continue
                        if stop_requested(h):
                            break
                        if claim(rec, path, h, uuid, pid):
                            took = rec
                            break
            if took is not None:
                print(f"{C.utc_now()} claimed {took['id']}.a{took['attempt']}", flush=True)
                d = run_job(took, h, uuid, wrec)
                print(f"{C.utc_now()} done {took['id']}.a{took['attempt']} rc={d['rc']} ran={d['ran']}"
                      + (f" ({d['note']})" if d["note"] else ""), flush=True)
                write_record(wrec, "idle")
            else:
                write_record(wrec, "idle", None, problem)
            if once:
                break
            if took is None:
                _wait(h, wrec, problem)
        why = STOP["why"] or ("stop file" if Q.worker_stop_path(h).exists() else "one round")
        problem = ""
        print(f"{C.utc_now()} stopped ({why})", flush=True)
        return C.OK
    except Exception as e:
        problem = f"crash: {type(e).__name__}: {e}"
        raise
    finally:
        try:
            write_record(wrec, state, None, problem)
        finally:
            drop_lock(h, pid)
            for s, f in old.items():
                signal.signal(s, f)


# ------------------------------------------------------------------ stop

def stop_refusal(h):
    """(why nf_worker.py stop refuses on h or None, a note for the owner or None). Both arms of a seed pair run on one
    workbench (N1-a), so the worker is not stopped while an unfinished pair depends on h: one of its arms was claimed
    or ran here and the other has not finished. The rule is the report's (nf_report.open_pairs, the one its "stop
    the worker" line applies), read only. Only this owner command reads it: the run loop never imports the planner.
    When the planner's look ahead cannot be read, the pairs in the job records are still checked, and the note
    says so."""
    if not Q.qdir().is_dir():
        return None, None
    note = None
    try:
        import nf_report
        try:
            view = nf_report.plan_view()
        except (Exception, SystemExit) as e:  # noqa: BLE001
            view = {"held": [], "ready": [], "placed": {}}
            note = (f"note: the planner's look ahead cannot be read ({type(e).__name__}: {e}); only the seed pairs in "
                    f"the job records were checked. Check nf_report.py before this workbench goes away")
        held = nf_report.open_pairs(h, view=view)
    except (Exception, SystemExit) as e:  # noqa: BLE001
        return (f"the open seed pairs cannot be read ({type(e).__name__}: {e}), so the worker on {h} is not "
                f"stopped; run nf_report.py to see why"), None
    if not held:
        return None, note
    return (f"the worker on {h} is not stopped: {len(held)} unfinished seed pair(s) depend on it: "
            f"{'; '.join(held)}. Both arms of a pair run on one workbench, so the other arm can run only here. Run "
            f"stop again when nf_report.py says 'stop the worker on {h}: safe now' (POD.md section 4b)"), None


# ------------------------------------------------------------------ main

def main(argv=None):
    ap = argparse.ArgumentParser(description="the worker of one workbench (POD.md section 4b)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="claim and run published GPU jobs (started by nf_worker.sh, not by hand)")
    r.add_argument("--gpu", help="the GPU's UUID (needed when nvidia-smi lists more than one)")
    sub.add_parser("stop", help="this workbench's worker ends after its current job; refused (exit 4) "
                                "while an unfinished seed pair depends on this workbench")
    c = sub.add_parser("check", help="exit 4 when a worker runs here or the GPU UUID cannot be read; else print "
                                     "the worker's log path")
    c.add_argument("--gpu", help="the GPU's UUID (needed when nvidia-smi lists more than one)")
    args = ap.parse_args(argv)
    h = Q.host()
    try:
        if args.cmd == "stop":
            why, note = stop_refusal(h)
            if why:
                raise Refused(why)
            if note:
                C.say(note)
            Q.worker_stop_path(h).parent.mkdir(parents=True, exist_ok=True)
            Q.worker_stop_path(h).write_text(f"{C.utc_now()} nf_worker.py stop\n", encoding="utf-8")
            print(f"the worker on {h} ends after its current job")
            return C.OK
        if args.cmd == "check":
            pid = held_by(h)
            if pid is not None:
                raise Refused(f"a worker already runs on {h} (pid {pid}, {C.rel(Q.worker_lock_path(h))})")
            gpu_uuid(args.gpu)
            print(C.rel(C.c2() / "logs" / f"worker_{h}.out"))
            return C.OK
        if args.cmd == "run":
            return loop(h, gpu_uuid(args.gpu))
    except Refused as e:
        C.say(f"refused: {e} (exit 4)")
        return C.REFUSED
    except Exception:  # noqa: BLE001
        import traceback
        traceback.print_exc()
        return C.CRASH
    return C.ARGS


if __name__ == "__main__":
    sys.exit(main())
