"""The files of the two-workbench queue (N1). The planner (nf_plan.py queue --workers) publishes GPU jobs; one worker
per workbench (nf_worker.py run) claims and runs them. Everything is under C2/queue/, and every file has one writer:

  jobs/<job>.a<n>.json      the planner: attempt n of a job, written whole and renamed into place, never changed
  claims/<job>.a<n>.json    made once, only if absent: by the worker that runs attempt n, or by the planner (or a
                            one-slot queue start) when it withdraws an attempt no worker has claimed ("withdrawn")
  done/<job>.a<n>.json      the worker that claimed attempt n, once its process has ended, written whole
  released/<job>.a<n>.json  nf_plan.py release: the owner gave up attempt n after its workbench went silent
  workers/<host>.json       that workbench's worker: its record and heartbeat, written whole
  workers/<host>.lock.json  that workbench's worker, made only if absent: one worker per workbench
  workers/<host>.stop       nf_worker.py stop on that workbench: its worker ends after its current job
  STOP.json                 nf_plan.py stop: the queue (one slot or planner) stops at the next job boundary

Both sides import this module and read the three times below at call time (Q.HEARTBEAT_SECONDS, not a copy).
"""
import datetime as dt
import json
import os
import re
import socket
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nf_common as C  # noqa: E402

SCHEMA = 1


def _seconds(name, default):
    """A time in seconds. Tests only may shorten it with NF_TEST_<name>; the pod never sets these."""
    v = os.environ.get(f"NF_TEST_{name}")
    return float(v) if v else float(default)


HEARTBEAT_SECONDS = _seconds("HEARTBEAT_SECONDS", 60)          # a worker writes its record at least this often
UNKNOWN_AFTER_SECONDS = _seconds("UNKNOWN_AFTER_SECONDS", 900)  # older: its job's execution status is unknown
POLL_SECONDS = _seconds("POLL_SECONDS", 10)                     # how often an idle worker and the planner look


def host():
    """This workbench's name: its hostname. Tests only give two workers two names with NF_TEST_HOSTNAME."""
    return os.environ.get("NF_TEST_HOSTNAME") or socket.gethostname()


def qdir(*parts):
    return C.c2().joinpath("queue", *[str(p) for p in parts])


NAME = re.compile(r"^(?P<jid>[A-Za-z0-9_-][A-Za-z0-9_.-]*?)\.a(?P<attempt>[1-9][0-9]*)\.json$")


def name(jid, attempt):
    return f"{jid}.a{int(attempt)}.json"


def parse(filename):
    """(job id, attempt) of a jobs/, claims/, done/ or released/ file name, else None (temporary files too)."""
    m = NAME.match(str(filename))
    return (m.group("jid"), int(m.group("attempt"))) if m else None


def job_path(jid, attempt):
    return qdir("jobs", name(jid, attempt))


def claim_path(jid, attempt):
    return qdir("claims", name(jid, attempt))


def done_path(jid, attempt):
    return qdir("done", name(jid, attempt))


def released_path(jid, attempt):
    return qdir("released", name(jid, attempt))


def worker_path(h):
    return qdir("workers", f"{h}.json")


def worker_lock_path(h):
    return qdir("workers", f"{h}.lock.json")


def worker_stop_path(h):
    return qdir("workers", f"{h}.stop")


def stop_path():
    return qdir("STOP.json")


def listing(folder):
    """{(job id, attempt): path} of one of jobs, claims, done, released."""
    d = qdir(folder)
    out = {}
    if d.is_dir():
        for p in d.iterdir():
            key = parse(p.name)
            if key is not None:
                out[key] = p
    return out


def read(path):
    """The JSON object in a file, or None (missing, empty, unreadable or not an object)."""
    try:
        obj = C.read_json(path)
    except (OSError, ValueError):
        return None
    return obj if isinstance(obj, dict) else None


def write_whole(path, obj):
    """Written to a temporary file in the same folder, then renamed into place (nf_common.write_json)."""
    C.write_json(path, obj)


def create_once(path, obj):
    """Makes the file only if no file of that name exists (O_CREAT | O_EXCL, one atomic step), with the record in it.
    True when this call made it, False when it existed."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = (json.dumps(obj, indent=2, sort_keys=True, default=str) + "\n").encode("utf-8")
    try:
        fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    except FileExistsError:
        return False
    try:
        view = memoryview(data)
        while view:
            view = view[os.write(fd, view):]
        os.fsync(fd)
    finally:
        os.close(fd)
    return True


def age_seconds(utc_text, now=None):
    """Seconds since a C.utc_now() time (now: a POSIX time, default the clock), or None when it cannot be read."""
    try:
        t = dt.datetime.strptime(str(utc_text), "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=dt.timezone.utc)
    except ValueError:
        return None
    now = dt.datetime.now(dt.timezone.utc).timestamp() if now is None else float(now)
    return now - t.timestamp()
