"""Morning report: one screen (at most 40 lines of 90 characters), also written to checkpoints/new_fields/REPORT.txt.
It works at any time, during or after the queue. It never starts a job.

  $PY $NF/nf_report.py            # the morning report
  $PY $NF/nf_report.py --result   # also writes checkpoints/new_fields/reads/RESULT.txt (phase E3)

With two workbenches (POD.md section 4b) it also shows the workers, the jobs in flight, any job whose workbench went
silent (UNKNOWN), each held arm of a seed pair with the workbench it waits for and why, whether a worker may be
stopped now (not while an unfinished seed pair depends on it), split scores and jobs that ran beside a timing job.
"""
import argparse
import csv
import datetime as dt
import re
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nf_common as C  # noqa: E402


def c2(*p):
    return C.c2().joinpath(*[str(x) for x in p])


def _j(p):
    try:
        return C.read_json(p)
    except (OSError, ValueError):
        return None


def gpu_name():
    try:
        r = subprocess.run(["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"], capture_output=True,
                           text=True, timeout=20)
        return r.stdout.strip().splitlines()[0] if r.returncode == 0 and r.stdout.strip() else "none"
    except (OSError, subprocess.TimeoutExpired, IndexError):
        return "none"


STARTED = "started"     # a start line with no end line yet: running only while its process runs (job_running)


def queue_jobs():
    """{job: (status, rc)} from queue.log: the last start or end line of each job."""
    p = c2("queue.log")
    jobs, last_end = {}, ""
    if not p.is_file():
        return jobs, last_end
    for ln in p.read_text(encoding="utf-8").splitlines():
        m = re.match(r"^start (\S+) ", ln)
        if m:
            jobs[m.group(1)] = (STARTED, None)
        m = re.match(r"^end (\S+) rc=(-?\d+) ", ln)
        if m:
            rc = int(m.group(2))
            jobs[m.group(1)] = ("done" if rc == 0 else f"FAILED rc={rc}", rc)
        if ln.startswith("queue end") or ln.startswith("stop:") or ln.startswith("refused"):
            last_end = ln
    return jobs, last_end


def _utc(s):
    try:
        return dt.datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ")
    except (TypeError, ValueError):
        return None


def best_metrics(d):
    """(best epoch, best valid_ap) from a metrics csv in the run folder, if any."""
    for f in sorted(Path(d).rglob("*.csv")):
        try:
            with open(f, encoding="utf-8") as fh:
                rows = [r for r in csv.DictReader(fh) if r.get("valid_ap") not in (None, "")]
        except (OSError, csv.Error, UnicodeDecodeError):
            continue
        if rows:
            best = max(rows, key=lambda r: float(r["valid_ap"]))
            return best.get("epoch", ""), float(best["valid_ap"])
    return "", None


def job_running(jid):
    """Whether a job with a start line and no end line still runs. A fit runs while the planner's fit state says
    RUNNING (its trainer's lock names a live process on this host, or names another workbench), and while its
    queue runs before the trainer has made its folder; any other job while the queue that started it runs
    (QUEUE.lock.json, the same owner rule: a queue lock of another workbench counts as running). Otherwise a crash
    or a restart interrupted it. A job a worker runs (two workbenches) is running while its attempt is."""
    import nf_plan
    if _queue_dir() is not None:
        a = nf_plan.queue_status()["attempts"].get(jid)
        if a and a["state"] == "running":
            return True
    m = re.match(r"^fit_(.+)_seed(\d+)$", jid)
    if m:
        state = nf_plan.fit_state(nf_plan.run_dir(m.group(1), m.group(2)))
        if state == "RUNNING":
            return True
        if state != "MISSING":
            return False            # its folder holds no live trainer: a crash or a restart stopped it
    return nf_plan.queue_alive()


def run_rows(jobs):
    import nf_plan      # the planner's fit state rule (nf_plan.fit_state), so the report and the queue always agree
    rows = []
    roots = [c2("runs")]
    for root in roots:
        if not root.is_dir():
            continue
        for d in sorted(root.glob("*/seed*")):
            m = _j(d / "run_manifest_v2.json") or {}
            jid = f"fit_{d.parent.name}_{d.name}"
            state = nf_plan.fit_state(d)
            logged = jobs.get(jid, ("",))[0]
            if state == "complete":
                status = m.get("status")
            elif state == "RUNNING":
                host = nf_plan.trainer_host(d)          # a trainer on another workbench sharing the folder
                status = f"RUNNING on {host}" if host else "RUNNING"
            elif logged.startswith("FAILED"):
                status = logged             # incomplete, and its fit job ended with this exit code
            else:
                status = state              # INCOMPLETE (a crash or restart left it: rename it) or MISSING (empty)
            ep = m.get("epochs_run", "")
            be, ap = best_metrics(d)
            t0, t1 = _utc((m.get("start") or {}).get("utc")), _utc(m.get("ended_utc"))
            hpe = f"{(t1 - t0).total_seconds() / 3600 / int(ep):.2f}" if t0 and t1 and ep else ""
            rows.append(f"{d.parent.name:<22}  {d.name[4:]:<4} {status:<15} {str(ep):<6} {str(be):<4} "
                        f"{'' if ap is None else f'{ap:.4f}':<9} {hpe}")
    return rows


def read_lines():
    out = []
    rd = c2("reads")
    if not rd.is_dir():
        return out
    for p in sorted(rd.glob("*_*seed.json")) + sorted(rd.glob("*_select.json")) + sorted(rd.glob("*_lift.json")):
        if p.name.endswith((".runs.json", ".inputs.json")):
            continue
        d = _j(p) or {}
        step, kind = p.stem.split("_", 1)
        extra = []
        for k in ("gain", "t1", "lb", "reason"):
            if k in d and d[k] is not None:
                v = d[k]
                extra.append(f"{k} {v:+.4f}" if isinstance(v, float) and k != "reason" else f"{k}: {v}")
        flag = " FLAG" if d.get("flag") else ""
        out.append(f"reads {step} {kind}: {d.get('decision', '?')}{flag}  " + "  ".join(extra))
    return out


def build():
    s = C.settings()
    st = C.steps()
    h = C.settings_hashes()
    lines = []
    g = c2("guard", "guard.jsonl")
    src, ctl_eq, layout = "?", "unknown", "?"
    if g.is_file():
        ls = [x for x in g.read_text(encoding="utf-8").splitlines() if x.strip()]
        if ls:
            import json
            last = json.loads(ls[-1])
            src = str(last.get("source_sha256", "?"))[:12]
            layout = last.get("layout", "?")
            c = last.get("control") or {}
            ctl_eq = "yes" if c and c.get("source_sha256") == last.get("source_sha256") else \
                ("no control yet" if not c else "NO")
    title = f"NEW FIELDS {C.utc_now()}  layout={layout}  source={src} = control: {ctl_eq}  GPU {gpu_name()}"
    rk = _j(c2("reads", "rank_check.json")) or {}
    decide = {"rank_b": "RANK-B", "select_june": "SELECT June", "owner": "owner to decide (plan fallback)"}.get(
        rk.get("decide_on"), "unknown (rank check)")
    if str(s.get("decide_on") or "") == "select_june":
        decide = "SELECT June (SETTINGS.yaml)"
    lines.append(f"settings lr={s.get('learning_rate')} ({s.get('learning_rate_source') or 'source blank'})  "
                 f"decide={decide}  bar=+{float(s.get('bar_udr', 0)):.4f}  rules={str(h.get('SETTINGS.yaml'))[:12]}"
                 f"  steps={str(h.get('STEPS.yaml'))[:12]}")
    parts = [f"{x['name']} {'on' if C.step_on(x) else 'off'}" for x in st.get("steps", [])]
    lines.append("steps: " + ", ".join(parts) + f", one_step_all {'on' if st.get('one_step_all') else 'off'}"
                 + f", refit_kept_control {'on' if st.get('refit_kept_control') else 'off'}")
    kept = _j(c2("KEPT.json")) or {}
    art = _j(c2("artifact", "artifact_check.json")) or {}
    art_txt = f"artifact {s.get('extended_artifact_version')} " + (
        f"base {art.get('base_identical', '?')}" if art else "not checked yet")
    lines.append(f"inputs: kept={kept.get('input_set', 'base')}; {art_txt}")
    view = None
    if _queue_dir() is not None:      # two workbenches: near the top, so a long run table never cuts these lines
        try:
            view = plan_view()              # one dry walk: its held arms here, its next jobs below
        except (Exception, SystemExit):  # noqa: BLE001
            view = None                     # the next: line below says why
        try:
            lines += worker_lines(view or {"held": [], "ready": [], "placed": {}, "unread": True})
        except Exception as e:  # noqa: BLE001
            lines.append(f"workers: cannot be read: {type(e).__name__}: {e}")
    tdir = c2("timing")
    if tdir.is_dir():
        for t in sorted(tdir.glob("*.json"))[:3]:
            d = _j(t) or {}
            keys = [k for k in ("C_c", "C_f", "C_v", "C_v,f", "C_vf", "peak_gb", "microbatch") if k in d]
            lines.append(f"timing {t.stem}: " + "  ".join(f"{k} {d[k]}" for k in keys))
    jobs, last_end = queue_jobs()
    lines.append("run                     seed status          epochs best valid_ap  h/epoch")
    lines += run_rows(jobs)
    sc = c2("scores")
    done = len(list(sc.glob("*.parquet.json"))) if sc.is_dir() else 0
    failed = sum(1 for k, v in jobs.items() if k.startswith("score_") and v[0].startswith("FAILED"))
    lines.append(f"scores done {done}  failed {failed}")
    lines += read_lines()
    imp = c2("importance")
    n_imp = len(list(imp.glob("*/importance.csv"))) if imp.is_dir() else 0
    n_att = len(list(imp.glob("*/attention.csv"))) if imp.is_dir() else 0
    lines.append(f"importance: {n_imp} runs measured ({st.get('importance', 'final')}); attention passes {n_att}")
    started = [k for k, v in jobs.items() if v[0] == STARTED]
    running = [k for k in started if job_running(k)]
    interrupted = [k for k in started if k not in running]
    two = _queue_dir() is not None
    try:
        import nf_plan
        if two:
            v = view if view is not None else nf_plan.plan_view()
            nxt = ", ".join(v["ready"]) or v["end"] or "nothing ready"
            fly = [x["id"] for x in v["in_flight"]]
            nxt += f" (in flight: {', '.join(fly) or 'none'})"
        else:
            nj = nf_plan.next_job(dry=True)
            nxt = nj.get("reason") if nj["kind"] == "stop" else nj["id"]
            nxt = ("STOP: " if nj["kind"] == "stop" else "") + str(nxt)
    except SystemExit as e:
        nxt = f"planner refused: {getattr(e, 'message', e.code)}"
    except Exception as e:  # noqa: BLE001
        nxt = f"planner error: {type(e).__name__}: {e}"
    nline = f"next: {nxt}" + (f"  (running: {', '.join(running)})" if running else "")
    lines += _wrapped(nline) if two else [nline]

    if interrupted:
        lines.append(f"interrupted by a crash or a restart, not running: {', '.join(interrupted)}")
    nfail = sum(1 for v in jobs.values() if v[0].startswith("FAILED"))
    lines.append(f"queue: failed jobs {nfail}; {last_end or 'no queue end line yet'}")
    return title, lines


def _queue_dir():
    """C2/queue/ when the two-workbench files exist (and nf_queue.py is here), else None."""
    import nf_plan
    if nf_plan.Q is None or not nf_plan.Q.qdir().is_dir():
        return None
    return nf_plan.Q.qdir()


def _wrapped(text):
    return C.wrap(text).splitlines()


def plan_view():
    """nf_plan.plan_view(), with what place() answered for each arm of a seed pair on the way (nf_plan.PLACED):
    view["placed"]. Dry: it writes, publishes and runs nothing."""
    import nf_plan
    nf_plan.PLACED.clear()
    try:
        v = nf_plan.plan_view()
        v["placed"] = dict(nf_plan.PLACED)
    finally:
        nf_plan.PLACED.clear()
    return v


def _arm_host(st, jid):
    """The workbench an arm's latest attempt was claimed or ran on (running, unknown or done), else None."""
    import nf_plan
    a = st["attempts"].get(jid)
    return nf_plan._claim_host(a) if a and a["state"] in ("running", "unknown", "done") else None


def held_arms(st, view):
    """[(arm, the workbench it waits for or None, why)]: the arms the planner holds (N1-a: a pair is never split).
    An arm waits for its pair's first arm to be claimed (normal, for a moment), or for the workbench that first arm
    was claimed or ran on, whose worker is not alive (it is never published for another workbench)."""
    import nf_plan
    placed = view.get("placed") or {}
    ids = list(view.get("held") or [])
    for jid, n, host in nf_plan._published(st):        # pinned to a workbench whose worker is gone: the planner
        kind = (((st["attempts"].get(jid) or {}).get("job") or {}).get("job") or {}).get("kind")
        if host and kind == "fit" and nf_plan._wstate(st, host) != "alive" and jid not in ids:
            ids.append(jid)                             # withdraws it at its next tick and holds it there
    out = []
    for jid in ids:
        p = placed.get(jid) or {}
        first = p.get("partner") or (((st["attempts"].get(jid) or {}).get("job") or {}).get("pair") or {}).get(
            "partner") or "its pair's first arm"
        h = p.get("partner_host") or _arm_host(st, first) or \
            ((st["attempts"].get(jid) or {}).get("job") or {}).get("host")
        if not h:
            out.append((jid, None, f"{first} (its pair's first arm) is not claimed yet; it then runs on the same "
                                   "workbench"))
            continue
        a = st["attempts"].get(first) or {}
        did = {"running": "runs", "done": "ran"}.get(a.get("state"), "was claimed")
        out.append((jid, h, f"{first} (its pair's first arm) {did} on {h}, whose worker is {nf_plan._wstate(st, h)}"))
    return out


def open_pairs(h, st=None, view=None):
    """The unfinished seed pairs that depend on workbench h, in words; empty when the worker on h may be removed.
    A pair depends on h when one of its arms was claimed or ran on h (its latest attempt) and the other arm, or that
    arm itself, has not finished (no done record and its outputs not complete; an arm with no attempt yet counts
    when the planner would place or hold it now). Pairs are those the planner knows now: in the job records and in
    its look ahead. The same rule refuses nf_worker.py stop. Read only."""
    import nf_plan
    st = nf_plan.queue_status() if st is None else st
    view = plan_view() if view is None else view
    pairs = set()
    for jid, top in st["attempts"].items():
        for a in [top] + top.get("history", []):
            rec = a.get("job") or {}
            partner = (rec.get("pair") or {}).get("partner")
            if partner and (rec.get("job") or {}).get("kind") == "fit":
                pairs.add(tuple(sorted((jid, partner))))
    for jid, p in (view.get("placed") or {}).items():
        if p.get("partner"):
            pairs.add(tuple(sorted((jid, p["partner"]))))
    coming = set(view.get("held") or []) | set(view.get("ready") or [])

    def finished(jid):
        a = st["attempts"].get(jid)
        if a is None:
            return jid not in coming        # no attempt: it ran before the workers or outside, unless it comes now
        if a["state"] == "done":
            return True
        try:
            return nf_plan.outputs_complete(a.get("job"))
        except OSError:
            return False                    # cannot be read: counted as not finished

    def state(jid):
        a = st["attempts"].get(jid)
        if a is None:
            return "held" if jid in (view.get("held") or []) else "not published yet"
        return {"withdrawn": "held"}.get(a["state"], a["state"])

    out = []
    for a, b in sorted(pairs):
        for mine, other in ((a, b), (b, a)):
            if _arm_host(st, mine) == h and not (finished(a) and finished(b)):
                did = "ran" if (st["attempts"].get(mine) or {}).get("state") == "done" else "was claimed"
                if finished(other):
                    out.append(f"{mine} {did} on {h} and is not finished")
                else:
                    out.append(f"{mine} {did} on {h} and {other} is {state(other)}")
                break
    return out


def worker_lines(view=None):
    """The two-workbench lines of the report (POD.md section 4b): workers, jobs in flight, UNKNOWN jobs, held arms,
    whether a worker may be stopped now, split scores, contention beside a timing job. Read only. view: a
    nf_plan.plan_view() result (its held arms), made here when not given."""
    import nf_plan
    st = nf_plan.queue_status()
    out = []
    ws = []
    for h, w in sorted(st["workers"].items()):
        rec = w.get("rec") or {}
        age = w.get("age")
        txt = f"{h} {w['state']} {rec.get('state', '?')}"
        if rec.get("job"):
            txt += f" {rec['job']}"
        txt += f" gpu {str(rec.get('gpu_uuid') or '?')[:12]} hb {'?' if age is None else f'{max(0, age):.0f}'} s"
        if rec.get("problem"):
            txt += f" ({rec['problem']})"
        ws.append(txt)
    out += _wrapped("workers: " + ("; ".join(ws) or "none has started (nf_worker.sh on each workbench)"))
    fly = []
    for jid, a in sorted(st["attempts"].items()):
        if a["state"] not in nf_plan.INFLIGHT_STATES or nf_plan.outputs_complete(a.get("job")):
            continue
        if a["state"] == "published":
            fly.append(f"{jid} published ({(a.get('job') or {}).get('host') or 'any'})")
        else:
            fly.append(f"{jid} {a['state']} on {nf_plan._claim_host(a)}")
    out += _wrapped("in flight: " + ("; ".join(fly) or "none"))
    for jid, a in sorted(st["attempts"].items()):
        if a["state"] == "unknown" and not nf_plan.outputs_complete(a.get("job")):
            h = nf_plan._claim_host(a)
            hb = ((st["workers"].get(h) or {}).get("rec") or {}).get("heartbeat_utc") or "none"
            out += _wrapped(f"UNKNOWN {jid}.a{a['attempt']} on {h}, last heartbeat {hb}: not started again. If {h} "
                            f"is gone or its trainer has stopped: rename its outputs (_crashed), then nf_plan.py "
                            f"release {jid}")
    if view is None:
        try:
            view = plan_view()
        except (Exception, SystemExit):  # noqa: BLE001
            view = {"held": [], "ready": [], "placed": {}, "unread": True}
    for jid, h, why in held_arms(st, view)[:6]:
        if h is None:
            out += _wrapped(f"held {jid}: {why}")
        else:
            out += _wrapped(f"HELD {jid} waits for {h}: {why}. It runs only on {h} (both arms of a pair on one "
                            f"workbench): start the worker on {h} again (POD.md section 4b)")
    for h, w in sorted(st["workers"].items()):
        if w["state"] in ("stopped", "missing"):
            continue
        rec = w.get("rec") or {}
        waits = [jid for jid, a in sorted(st["attempts"].items())
                 if a["state"] == "published" and (a.get("job") or {}).get("host") == h]
        pairs = open_pairs(h, st, view)
        if rec.get("state") == "running" and rec.get("job"):
            say = f"not yet: it runs {rec['job']}"
        elif view.get("unread"):
            say = "cannot tell: the plan cannot be read now (see the next: line), so its seed pairs are not known"
        elif pairs:
            say = f"not yet: an unfinished seed pair depends on it: {pairs[0]}" + \
                  (f" (and {len(pairs) - 1} more)" if len(pairs) > 1 else "")
        elif waits:
            say = f"not yet: {waits[0]} waits for it"
        elif rec.get("state") == "idle":
            say = "safe now"
        else:
            say = f"not yet: it is {rec.get('state', w['state'])}"
        out += _wrapped(f"stop the worker on {h}: {say}")
    split = []
    for jid, a in sorted(st["attempts"].items()):
        pair = (a.get("job") or {}).get("pair") or {}
        if pair.get("split_from"):
            split.append(f"{jid} (its pair ran on {pair['split_from']})")
    if split:
        out += _wrapped("split pairs: " + "; ".join(split))        # scores and checks only: arms are held
    import time as _time
    runs = nf_plan._runs(st, _time.time())
    beside = []
    for r in runs:
        if r[5] != "timing":
            continue
        for o in nf_plan.overlapping(r[0], runs):
            beside.append(f"{r[1]} ran beside {o[1]}")
    if beside:
        out += _wrapped("contention: " + "; ".join(sorted(set(beside))[-6:]) + " (shared storage)")
    return out


def result_text():
    kept = _j(c2("KEPT.json")) or {}
    lines = [f"kept inputs: {kept.get('input_set', 'base')}"]
    lines += [f"  {x}" for x in kept.get("history", [])]
    lines += read_lines()
    lines.append("Test 1 is reported only; it never decides. This package does not score Test 2 (BENCH): it")
    lines.append("  needs the BENCH path, the row-alignment check and the LoB exclusions first (plan section 3).")
    lines.append("RANK-B and SELECT are development reads; adopted gains are somewhat optimistic.")
    return C.screen("NEW FIELDS RESULT  " + C.utc_now(), lines)


def main(argv=None):
    ap = argparse.ArgumentParser(description="morning report")
    ap.add_argument("--result", action="store_true")
    args = ap.parse_args(argv)
    title, lines = build()
    text = C.screen(title, lines, footer="report: " + C.rel(c2("REPORT.txt")))
    c2().mkdir(parents=True, exist_ok=True)
    c2("REPORT.txt").write_text(text + "\n", encoding="utf-8")
    print(text)
    if args.result:
        r = result_text()
        C.out("reads", "RESULT.txt").write_text(r + "\n", encoding="utf-8")
        print(r)
    return C.OK


if __name__ == "__main__":
    sys.exit(main())
