#!/usr/bin/env bash
# Start the new-fields queue in the background. The owner runs this (or tells Copilot to); nothing starts on its own.
#   PY=<the pod's python> bash fraud/experiments/features/new_fields/nf_start.sh
# The one-slot queue refuses (exit 4) if anything runs on the GPU. With --workers the CPU planner can
# restart while workers finish their jobs; each worker checks its own GPU before starting a job.
# Closing the tail does not stop the queue.
set -u
NF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$NF/../../../.." && pwd)"
PY="${PY:-}"
if [ -z "$PY" ] || ! "$PY" -c "import omegaconf, torch" > /dev/null 2>&1; then
  echo "refused: set PY to the project's Python, exported, for example:" >&2
  echo "  PY=<the pod's python> bash fraud/experiments/features/new_fields/nf_start.sh (exit 2)" >&2
  exit 2
fi
cd "$ROOT"
OUT="${NF_OUT:-checkpoints/new_fields}"
WORKERS=0
for arg in "$@"; do
  [ "$arg" = "--workers" ] && WORKERS=1
done
if [ "$WORKERS" = "0" ]; then
  "$PY" "$NF/nf_plan.py" busy || { echo "refused: something is running (exit 4)"; exit 4; }
fi
mkdir -p "$OUT/logs"
echo "=== nf_start $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$OUT/queue.out"
PY="$PY" nohup bash "$NF/nf_run_all.sh" "$@" >> "$OUT/queue.out" 2>&1 &
echo "queue started, pid $!"
echo "report: $PY $NF/nf_report.py"
[ "${NF_NO_TAIL:-}" = "1" ] && exit 0
touch "$OUT/queue.log"
tail -n 20 -f "$OUT/queue.log"
