# New fields: run sheet for Copilot

The reviewers do not know the pod's current state. Copilot adapts paths and commands to the pod as it is now.
Copilot never changes the experiment: the steps, seeds, files, rules and thresholds are the plan. If something
cannot be found, or two candidates exist, stop and ask the owner.

Set these once in the shell, at the project root, before any command below (Copilot puts the pod's Python in `PY`):

```
PY=<the pod's Python for this project>      # the virtual environment the trainer uses
NF=fraud/experiments/features/new_fields
FS=fraud/experiments/features/field_screen
C2="${NF_OUT:-checkpoints/new_fields}"      # every output (the tools write under NF_OUT when it is set)
```

- In the text, `NF/`, `FS/` and `C2/` name files in those three folders; the commands write them `$NF/`, `$FS/`
  and `$C2/`. A word in angle brackets, such as `<run>`, is filled in; its step says with what.
- Run every command from the project root. Run every tool by path. CPU commands start with `CUDA_VISIBLE_DEVICES=`.

Every tool prints one screen of at most 40 lines of 90 characters. Photograph the screens named in section 5.

## 1. Before installing

1. Note the trainer's source hash:
   `$PY -c "import sys; sys.path[:0]=['.','src']; from fraud.scripts.train_sequential_hier import source_sha256; print(source_sha256())"`
2. Check that `fraud/source_files.py` lists `"fraud/experiments/"` among its excluded prefixes. If not, stop: the
   reorganization's hash rule was not applied, and installing would change the hash. Do not edit that file.

## 2. Install and check

3. Unzip the package into a new folder outside the project. Copy only `NF`, `FS`, `tests/experiments/features/new_fields`
   and `tests/experiments/features/field_screen` into the project. Add no `__init__.py`, unless pytest reports an
   import mismatch, and then only in a test folder.
4. Guard: `$PY $NF/nf_guard.py --before <hash from step 1>`. It must print `unchanged`, and the stage 0 lines must say
   `equal`. If not, remove the copied folders and stop.
   Its first line is `pandas <version>`: the tools need 2.0 or later. With an older pandas it stops in one line; ask the owner.
5. Layout: `$PY $NF/nf_layout.py`. The first line says `layout: reorganized`. If it says `MIXED`, adapt the names in
   `TABLE` of `nf_layout.py` (names only) and run it again.
6. Tests: `CUDA_VISIBLE_DEVICES= PYTHONPATH=src:. nice -n 19 $PY -m pytest -q -p no:cacheprovider tests/experiments/features/new_fields tests/experiments/features/field_screen`
   The last line must show `passed` and `skipped` only, never `failed` or `error`. The skipped tests need records
   the pod does not hold. `TEST_RESULTS.md` in the zip gives the counts to expect. Photograph that line.
   The tests that run the queue set `NF_PROC_ROOT` to an empty folder of their own, so stage 0's trainer or another
   test run on the pod does not make them fail as busy. `NF_PROC_ROOT` is for tests only: never set it in the pod's
   shell. While it is set, the busy check reads that folder instead of `/proc` and cannot see a running trainer;
   `nf_plan.py busy` prints a line saying so, and the preflight stops at `process_table`.

## 3. Part A: CPU only, safe while the GPU is busy

Use `CUDA_VISIBLE_DEVICES=` and `nice -n 19` on every command. Heavy S3 reads may slow stage 0's data loading a little.

7. Pod columns: `$PY $NF/nf_intake.py schema`. It reads parquet footers only, for every file range stage 2 reads,
   and prints the column count it found. It writes `C2/intake/pod_columns.csv`.
8. Field map: write `NF/FIELD_MAP.csv` from the owner's list, one row per feature, in the columns of the template.
   `$PY $NF/nf_intake.py draft` reads `NF/DRAFT_FEATURE_ATTRIBUTES_UNCONFIRMED.csv` and writes it in map form (one
   row per name, its recipe and source columns as written there, UNCONFIRMED) to
   `C2/intake/FIELD_MAP_DRAFT_UNCONFIRMED.csv`; start from it. Rules:
   - A raw field keeps the pod column name exactly. An engineered name is lowercase letters, digits and underscores.
   - Dates enter only as `days_before(c)` (a past event date: days before the transaction) or `days_until(c)` (a
     known future date, such as card expiry: days until it, a signed difference, below zero once it has passed).
     Never as a raw date.
   - The recipes follow one grammar, `nf_recipes.py` (the intake calls its parser).
   - A feature with no definition yet gets a blank recipe and `next_definition_needed`. It waits; it is not left out.
   - `code(c)` (15298's le1 and le3 outputs) is a proposed alternative, not proven equal to the original encoder:
     check-map FLAGs it `encoding_alternative`, and the decisions table keeps the row unresolved.
   - `geohash(postal; country)` is TFM's postal-code geohash, by TFM's own rule (its V22 pipeline). The two V22B
     postal codes use it; the raw postal code is the proposed alternative. Its table is `SETTINGS.yaml`
     `geohash_table`, TFM's S3 path by default; if the pod cannot read it, copy the CSV to the pod and set the key
     to the copy. If the files hold TFM's own `merchant_geohash` or `cprsrvc__pisinfo_cardholder_geohash`, the
     field checks compare them with the recipe (FLAG `tfm_geohash_match` below 99.9% of rows).
   - `donor_unit`: account for a profile field, event for an event field. Blank takes the default from the business
     category (`account and customer profile` is account).
   - Never cast a whole multi-output field (`cprsrvc__pisinfo`, `cprsrvc__pisinfo2`); name the subfield column.
   - Leave `list_status`, `list_source` and the check columns alone. Only `adopt` and the checks write them.
   - Spellings to try for a missing name: `pinwfatmcurrdttm` and `pinwfatmcurdttm`; `ddatellerlastdepatttm` and
     `ddatellerlastdepattm`; `moble_amt_curr` and `MOBILE_CURR`; `edrlogonctcurr` and `edrlogonctcoun`. The intake
     prints close pod names as suggestions only.
9. Check the map: `$PY $NF/nf_intake.py check-map --in-place`. It fills `window`, `lag`, `as_of_rule` and
   `status_rule`, and writes `C2/intake/FIELD_MAP_CHECKED.csv`. Status rules are data in `NF/STATUS_RULES.csv`.
   Copilot cannot clear a status match; only the data owner's written answer, or the owner's row in
   `NF/KEEP_DECISIONS.csv` with a reason starting "status match cleared", clears it.
10. Field checks: `$PY $NF/nf_field_checks.py --map $NF/FIELD_MAP.csv`. `CHECK_THRESHOLDS.yaml` is approved in
    `SETTINGS.yaml` approvals (by the reviewers under the owner's delegation, D10) and its SHA-256 is in
    `check_thresholds_sha256`; a later change to the file stops the preflight until it is approved again and the
    SHA-256 updated. Progress lines go to the error stream; the summary screen comes last.
11. CPU screen (`$FS/POD.md` is its run sheet). Dry run first: `CUDA_VISIBLE_DEVICES= $PY $FS/fsc_run.py --dry-run`.
    It prints `layout:` and the one-screen summary. Then, after the field checks:
    ```
    CUDA_VISIBLE_DEVICES= nice -n 19 $PY $FS/fsc_run.py \
      --map $NF/FIELD_MAP.csv --status $C2/checks/field_status.csv --clusters $C2/checks/clusters.csv \
      --base s3://mrmcd-analytics-mrm-mmr-dsai/tfm_raw_data --start 1 --end 10 --cred-path <credentials file> \
      --extract-start 2024-10-01 --train-neg-rate 0.1 --temporal-split 2025-04-01 \
      --k 5 --n-boot 500 --seed 42 --extra-seeds 43 44 \
      --drift-base s3://mrmcd-analytics-mrm-mmr-dsai/tfm_EVAL_raw_data --drift-start 8228 --drift-end 8243 \
      --drift-extract-start 2025-05-01 --drift-month 2025-06 --out $C2/screen
    ```
    It writes `C2/screen/`: `summary.txt` (at most 40 lines; photograph it), `feature_rank.csv` (one row per map
    field; `note` holds its flags and the per-feature summary turns any note into `review`), `cluster_rank.csv` and
    `screen.json`. It is XGBoost's view, not the transformer's, and decides nothing. June drift reads RANK-A
    without labels. It refuses (exit 2) a map with two rows of one name or a row named like a base input (also a
    row the field checks STOP): show the owner the rows; the owner renames or removes them, and after a rename
    the field checks run again. It leaves out a field that reads a column the field checks STOP or WAIT
    (`source_stop`). Exit 4: no field status, the memory guard or the cost guard (`--max-hours`, default 6).
12. Rank check: `$PY $NF/nf_rank_check.py`. If RANK-A or RANK-B fails, it checks the plan's fallback files
    (`SETTINGS.yaml` `rank_fallback_files`: 8201-8205 with 8278-8300) the same way. RANK-B and the fallback both
    fail: June SELECT decides. RANK-B fails and the fallback passes: the owner decides how the fallback files are
    used; Copilot then sets `SETTINGS.yaml` `populations` `rank_a` and `rank_b` as the owner says and runs the check
    again, or the owner sets `decide_on: select_june`. Until then the queue and the reader wait. RANK-A failed:
    importance and attention wait for the owner. A missing S3 credential is a refusal (exit 4). The seed spread is
    read by the queue (`nf_plan.py` scores the kept seeds and writes the run table). By hand it needs that table:
    `$PY $NF/nf_read.py spread --population select_june --run-table "$C2/reads/spread_select_june.runs.json"`.
13. Workbook: `$PY $NF/build_feature_workbook.py`, after editing the lists. It reads `fraud/configs/predictors.csv`,
    the `NF/DRAFT_*_UNCONFIRMED.csv` lists, `NF/KEEP_DECISIONS.csv` and, where it has rows, `NF/FIELD_MAP.csv` (its
    values win; `in_owner_list` comes from `list_status` and `list_source`). It reads no intake output.
14. After the owner confirms the list:
    - `$PY $NF/nf_intake.py adopt --list <owner file> --confirmed-by "<name, date>"`. Rows not in the owner's file
      stay in the map as `NOT_IN_OWNER_LIST` with a reason.
    - The field checks again, if the adopted list differs from the one checked.
    - `$PY $NF/nf_intake.py definitions` (the feature definitions for a future feature store).
    - `$PY $NF/nf_build_enriched.py`, `$PY $NF/nf_build_artifact.py`, `$PY $NF/nf_check_artifact.py`.
    - Every group the owner wants (V22B, 15298 and, if on, A3) must be in the map, CONFIRMED, before the first
      artifact build. The builder fits every new field once. A later build would make a new version whose earlier
      fields are fit again, and nothing checks them against the files the kept fits were trained on.

## 4. Part B: GPU, only after stage 0, its resumes and stage 1's GPU work have finished

15. Fill `NF/UPSTREAM.yaml` with paths only, from the stage 0 and stage 1 reports. The guard reads the files and
    records their hashes. Look for the kept runs' SELECT predictions in `models/<name>/seed<NN>/scores/` first, then
    `archive/results/`, then the old project. Verify them by `predictions_sha256`, never by the paths inside receipts.
16. In `NF/SETTINGS.yaml`: `learning_rate` and `learning_rate_source` from stage 0's report. The approvals of the
    main measure, the bar, the check thresholds and the cluster threshold are filled (the reviewers, under the
    owner's delegation of 2 November). The stage 1 seed-42 retrain must exist before any feature fit is read: it is
    the control. P1, our own seed-42 base control, replaces it when the stage 1 rule says so (stage 0's best rate is
    not 3e-4, the memory rule changed A1's micro-batch, the base inputs' hashes or the code path changed); then the
    reviewers fill `control_p1_owner_yes` with stage 1's report name and the date, and P1 is read only after it
    passes stage 1's training checks (2,103 updates per epoch).
17. In `NF/STEPS.yaml`: the steps the owner chose. Defaults (the reviewers' decisions of 2 November): every later
    step reads against a seed-42 refit of the kept recipe at the candidate's micro-batch (`refit_kept_control:
    true`, D5a), with new seed 43 and 44 fits for a recipe adopted at three seeds; the base is refit at seeds 43 and
    44 before the first read (`refit_base_controls_43_44: true`, D5b); the kept checkpoints are never controls.
    Month out (step B) is on, the last fitting step (D4c); A3 is off unless the confirmed list holds a3 rows (the
    preflight checks it, D4a); pruning is off, and the preflight refuses step P on until its three-seed
    compression step is built (D4b). Permutation importance runs once, on the final kept fit after
    month out, only when an adding step was adopted (`importance: final`, D6; `every_step` is the owner's option).
    The cyclical calendar step C is off.
18. Configs: `$PY $NF/nf_make_configs.py` (the control and the first step; the queue writes later steps' configs
    when it reaches them, on the inputs the earlier decisions kept), then `$PY $NF/nf_make_configs.py --verify`. A config may differ from
    `fraud/configs/sequential_hier_allpos.yaml` only in the allowed keys; anything else is refused.
19. Timing for the first step's width, before the preflight (`<run>` is the step's run name, its config's name in
    `$NF/configs/`, such as `nf_a1`): `$PY $NF/nf_time_width.py width --config $NF/configs/<run>.yaml`, then
    `$PY $NF/nf_time_width.py real --config $NF/configs/<run>.yaml --run <run> --write-settings`, which writes
    `C2/timing/<run>.json`; the queue times every later step itself. The width counts the missing-flag columns the
    preprocessing adds for continuous fields. If the memory rule fires, its micro-batch goes into `SETTINGS.yaml`
    `microbatch`, and the control runs at the same micro-batch (the reviewers' decision D10;
    `microbatch_confound_accepted_by` stays blank).
20. Preflight: `$PY $NF/nf_plan.py preflight`. Every line must say `ok`.
21. Start: the owner runs `PY=$PY bash $NF/nf_start.sh`, or tells Copilot to. The queue refuses (exit 2) if `PY` is
    not given or is not the project's Python, so the trainer never runs on the system Python. Copilot never starts it on its own. It refuses
    (exit 4) when anything runs on the GPU. Closing the tail does not stop the queue. Running it again continues
    at the first job whose output is missing.
    After a crash or a pod restart, start it again the same way, on the same workbench. A `QUEUE.lock.json` left by
    a queue of this workbench that no longer runs is replaced (the queue log says so); a `RUNNING.lock.json` left
    by a trainer of this workbench that no longer runs leaves its fit folder incomplete. A fit folder or score file
    the crash left incomplete stops the queue with a line that says to rename it: rename it (add `_crashed`), then
    start again. The queue never resumes a fit.
    One queue at a time: two starts at the same moment cannot both take `C2/QUEUE.lock.json`; the second is refused
    (exit 4).
    The project folder is shared by the owner's workbenches: each is its own pod with its own hostname (a restart
    keeps it), and all of them mount the same folder at the same paths. Run the queue on one workbench only. A
    lock that names another workbench (the queue's lock, a takeover claim file next to it, or a trainer's lock) is
    never replaced: the queue refuses with exit 4 and names that workbench, its pid and its time. Remove such a
    lock by hand only after checking on that workbench that nothing runs there. One-off work on another workbench
    that writes to its own folders is fine.
    The lock needs a POSIX file system for the checkpoints folder (`C2`): the workbenches' shared volume is one, an
    S3 or other object-store mount is not. On a POSIX file system, making the lock only if it is absent, and
    replacing a stale one by a rename, are each one atomic step.
22. Each morning: `tail -n 40 "$C2/queue.log"` and `$PY $NF/nf_report.py`. The report shows each fit as the queue
    sees it: RUNNING only while its trainer runs, INCOMPLETE when a crash or a restart stopped it (rename it, as in
    step 21). A fit whose trainer runs on another workbench shows as RUNNING with that workbench's hostname: this
    pod cannot see that trainer, so leave its folder alone. After each read (`<step>_<n>seed` is the step and its
    seed count, such as `A1_1seed`):
    `cat "$C2/reads/<step>_<n>seed.txt"`. Curves: `tensorboard --logdir "$C2/tb"`, or
    `$PY fraud/scripts/show_progress.py --source tensorboard --granularity epoch --logdir "$C2/tb/<run>/seed42"`
    (one row per epoch). TensorBoard needs the `tensorboard` package in the pod's Python, and the workbook builder
    needs `openpyxl`. If one is missing, ask the owner before installing it: an install into the trainer's
    environment can change packages that stage 0 relies on. Without tensorboard a fit runs without logs and says so.
    Never edit `requirements.txt` for them: it is under the trainer's source hash.

What the queue does, one job at a time: the control's and the kept seeds' scores on the decision population, the
UDR seed spread, then for each step that is on: its config, its fit at seed 42 (through `nf_fit.py`, which adds the
TensorBoard logger), its score, an attention pass (`nf_importance.py run --attention-only`), the read; seeds 43 and
44 when the read says so; the SELECT check before every decision that changes the kept inputs; the downstream check
of a kept fit and its lift read; before each later step, the seed-42 refit of the kept recipe at the candidate's
micro-batch (its width timing first); then pruning (seed 42 only, with importance before it) if on, month out (on) and
the cyclical calendar if on; the scoring timing of the final kept fit (`nf_time_width.py score`: single windows and
the scoring batch, median and 99th percentile, the input count, figures only); permutation importance of the final
kept fit after month out; Test 1 scores and the result summary at the end. The package does not score
Test 2 (BENCH): it needs the BENCH path, the row-alignment check and the LoB exclusions first (plan section 3), and
is reported once those exist. The importance tool's
timing comes from the width timing record when it holds the rate, else from the queue log's wall time of the latest
scoring job on the decision population. If importance is missing or failed, pruning waits with a line saying why.

How the queue calls the importance tool:
- attention pass: `nf_importance.py run --attention-only --config <config> --checkpoint <checkpoint> --output
  C2/importance/<fit>_attention`;
- permutation importance: the same without `--attention-only`, and `--output C2/importance/<fit>`;
- both add `--field-map NF/FIELD_MAP.csv`, `--clusters C2/checks/clusters.csv` when the field checks wrote it (so
  pruning goes cluster first), the `SETTINGS.yaml` `importance` options (`account_share`, `repeats`, `seed`,
  `max_gpu_hours`, `units` both and `fallback_units` groups: when both does not fit the cap, by the estimate or by
  the cost measured on the baseline pass, the run takes groups, D6) and one timing input. That is `--timing
  C2/timing/<run>.json` when the fit's width timing record
  holds the rate and `rank_a_rows`. Otherwise it is `--seconds-per-row`, the wall time of the latest scoring job on
  the decision population divided by its rows, with `--rank-a-rows`, those rows times RANK-A's file count over the
  population's. With neither, the pass waits and the queue log says why.

Exit codes: 0 done; 1 a crash; 2 bad arguments; 3 STOP (a check failed); 4 refused (busy GPU, an output exists, a
wrong input or layout, a missing pod path or record); 5 every decision read but a reported step failed (an attention
pass, a downstream fit, Test 1) or a step waits (pruning without its importance file).

Nothing is overwritten. A complete fit is skipped. A folder that exists but is incomplete stops the queue with
"rename it". A saved read is reused only while the checkpoints, predictions and settings it read are unchanged;
otherwise the queue stops with "inputs changed: rename the old read".

Commands the queue builds (Copilot adapts paths only):
```
$PY $NF/nf_fit.py --run nf_a1 --config $NF/configs/nf_a1.yaml training.seed=42 \
  output.checkpoint_dir=$C2/runs/nf_a1/seed42
  # the trainer's own main (fraud.scripts.train_sequential_hier), with the TensorBoard logger when it is on
$PY -m fraud.scripts.score_sequential_hier --config $C2/runs/nf_a1/seed42/resolved_train_v2.yaml \
  --checkpoint $C2/runs/nf_a1/seed42/best.ckpt --out $C2/scores/nf_a1_seed42__rank_b.parquet --population OTHER \
  --purpose new_fields_rank_b_decision eval.file_start=8244 eval.file_end=8259
$PY fraud/experiments/embedding/export_embeddings.py --config <cfg> --checkpoint <ckpt> --out <folder> ...
```

## 4b. Two workbenches: one planner, one worker on each

Use this only while the temporary second workbench is there. One worker is the normal mode, and the one-slot queue
of step 21 stays valid. Switch between the modes only at a job boundary (below). The plan and the decisions do not
change: the planner walks the same plan as the one-slot queue, runs every read itself and writes the decisions in the
same order.

Both workbenches must use the same Python path in `PY` and the same `NF_OUT` (or neither sets it): the published jobs
name the Python and the folders.

| Where | Command | What it does |
|---|---|---|
| planner's workbench | `PY=$PY bash $NF/nf_start.sh --workers` | preflight, then the planner (refuses while a one-slot queue or another workbench's lock holds the queue) |
| planner's workbench | `PY=$PY bash $NF/nf_worker.sh` | this workbench's worker (after the planner has started) |
| second workbench | `PY=$PY bash $NF/nf_worker.sh` | that workbench's worker |
| either | `$PY $NF/nf_report.py` | one screen: workers, jobs in flight, unknown jobs, whether a worker may stop |
| second workbench | `$PY $NF/nf_worker.py stop` | removes that worker after its current job; outputs stay. Refused (exit 4) while an unfinished seed pair needs that workbench |
| planner's workbench | `$PY $NF/nf_plan.py stop` | the queue (planner or one slot) stops at the next job boundary; running jobs finish |
| planner's workbench | `$PY $NF/nf_plan.py release <job id>` | gives up an unknown job after its outputs were renamed; the planner runs it again |
| planner's workbench | `PY=$PY bash $NF/nf_start.sh` | the one-slot queue, as today (refuses while a worker's job is open) |

A workbench with more than one GPU gives the worker its GPU: `PY=$PY bash $NF/nf_worker.sh --gpu <uuid>` (the UUIDs:
`nvidia-smi --query-gpu=uuid --format=csv,noheader`). The worker's own log is `C2/logs/worker_<host>.out`.

What runs where:
- The planner holds `C2/QUEUE.lock.json` and is the only writer of the reads, `DECISIONS.log`, `queue_state.json`,
  `KEPT.json` and `queue.log`. It runs the configs, the reads and the checks itself, and only while no GPU job is in
  flight.
- It publishes GPU jobs (fits, scores, timings, attention, importance, downstream) as files under `C2/queue/jobs/`. A
  worker takes a job by making its claim file, which can be made only once, so two workers never take the same job.
  Each workbench runs one job at a time. A worker takes nothing while its GPU is busy; the report shows why.
- Both arms of a seed pair (the control and the candidate at one seed) run on one workbench, and a fit's scores and
  checks run on the workbench where it was trained. The first arm of a pair goes to whichever worker takes it; the
  second arm then runs only on that workbench.
- A pair is never split. If the workbench of the first arm has no live worker (stopped, silent or gone), the second
  arm is held: it waits for that workbench and is never sent to the other one. The other jobs go on. The report
  shows each held arm, the workbench it waits for and why (a `HELD` line). A pair with neither arm started yet is
  not split: both arms go together to a worker that is there.
- Only a score or a check of a fit whose workbench has no live worker runs on the other workbench; `queue.log` then
  says `split` and the report lists it under `split pairs`.
- Each job runs with `CUDA_VISIBLE_DEVICES` set to its workbench's GPU UUID. The host and the GPU UUID of every job
  are in its `ran` line in `queue.log` (and in `C2/queue/claims/` and `C2/queue/done/`); the job's log names them on
  its second line.
- A timing (`nf_time_width.py`) runs with no other job on its own workbench. The other workbench may run a job at the
  same time on the same shared storage: the `with=` list of the timing's `ran` line, and the report's `contention`
  line, name that job. Read such a timing with that in mind.
- No 2x speed is promised: the steps are serial (a read waits for its fits and scores, the next step waits for the
  read), the jobs have unequal lengths, and both workbenches read the same shared storage.

The heartbeat:
- Each worker writes its record, `C2/queue/workers/<host>.json`, every 60 seconds, also while its job runs.
- After 15 minutes without it, the report says `UNKNOWN` for that worker's job. That is not proof that the trainer
  stopped: the workbench may only be cut off from the shared folder. The queue never starts that job again. If it
  finishes late, its outputs are taken once, when they land.
- If that workbench is gone or its trainer has stopped (check on that workbench), give the job up: rename its outputs
  (add `_crashed`, as in step 21), then `$PY $NF/nf_plan.py release <job id>`. The planner then runs the job again.
  `release` refuses while the job runs or while its outputs are still there.

Removing the second worker: only when the report says `stop the worker on <host>: safe now`, run
`$PY $NF/nf_worker.py stop` on that workbench. The worker ends after its current job, and every output stays. A worker
is safe to remove only when no unfinished seed pair depends on it: no pair whose first arm was claimed or ran on that
workbench while its other arm has not finished. Until then the report says `not yet` and names the pair, and
`nf_worker.py stop` refuses (exit 4), names the open pairs and changes nothing; run it again once the pair has
finished. `safe now` covers the pairs the planner knows now. A control fit that ran on a workbench becomes the first
arm of a pair only when a later read decides to run that seed; if that workbench is gone by then, the candidate is
held until it is back (below).

When a workbench goes away while a pair is open, nothing is refitted on its own, no output is thrown away, and no
arm is compared with an arm trained on the other workbench. The held arm stays held until that workbench is back or
the owner acts. The owner's choices:
- Bring the workbench back: start its worker again (`PY=$PY bash $NF/nf_worker.sh` on it). The held arm then runs
  there. This is the normal way, and the only one when the arm on that workbench has finished.
- Run the whole pair again on the remaining workbench, by the owner's explicit choice. This is possible only when the
  arm on the gone workbench shows as `UNKNOWN` in the report: rename its outputs (add `_crashed`), then
  `$PY $NF/nf_plan.py release <job id>` for it. Neither arm is then claimed, so both arms run together on the
  remaining workbench. `release` gives up only an `UNKNOWN` job: it refuses an arm that finished, so a finished arm
  cannot be run again this way, and its pair waits for its workbench to come back.

Switching modes: run `$PY $NF/nf_plan.py stop` on the planner's workbench, wait for the line `stopped at a job
boundary on request (nf_plan.py stop)` in `queue.log` (running jobs finish first), then start the other mode. A
one-slot start refuses (exit 4) while a worker's job is still open, and names it.

The exit codes are those of section 4 and do not change. 0 also ends a requested stop; `queue.log` says which. The
worker's own: 0 stopped on request; 1 a crash; 2 bad arguments; 4 refused (a worker already runs on this workbench,
or the GPU's UUID cannot be read, or, for `nf_worker.py stop`, an unfinished seed pair depends on this workbench).

## 5. What the owner photographs

1. The guard (`unchanged`, with the hashes) and the pytest line.
2. The `check-map` screen.
3. The field checks summary.
4. The CPU screen's summary.
5. The rank check screen and the SELECT spread line.
6. After adoption: the enriched build's identity summary and the artifact check.
7. The config writer's screen and the timing screen.
8. The preflight screen.
9. Each morning: the queue log tail and the morning report.
10. Each read's decision screen, the SELECT checks, the lift reads, the importance summary, the Test 1 report and
    `C2/reads/RESULT.txt`.

## 6. Notes the reads and the report state

- Pairing by seed shares only the file partition when `num_workers` is above 0: a wider model draws more random
  numbers before the loader starts, so the window order differs. The config writer prints the as-run `num_workers`.
- With one seed, the bootstrap covers rows, not seed-to-seed variation.
- The kept seeds 43 and 44 are never controls (the reviewers' decision D5b): the base is refit at seeds 43 and 44
  (`nf_control`) before the first read. The seed spread pools the kept trio and the current-pod base trio (4
  degrees of freedom; `SETTINGS.yaml` `spread_pool: [kept, current]`, another value is refused), each trio's SD
  printed; the same-seed kept-minus-current differences are information (cross-pod and old tree). If their
  learning rates differ, the read says so.
- `external_1_scr` (D3c): every read says its availability at the decision is assumed, not certified, until
  `SETTINGS.yaml` `external_1_scr_certified` records who and when (the bank's OQ-14 answer, the owner's to confirm).
- A later step's control is a seed-42 refit of the kept recipe (D5a). The read prints the refit beside the kept fit,
  and the gap, as information; the decision does not change.
- DS_SELECT is read once per kept fit, as the plan says; the decision log states each read. The lift flag reads
  the UDR lift; the AP lift is reported.
- Stride is not available for the chosen chunk model (its sequence builder refuses stride with all-position chunks).
  Imbalance handling stays with the loss options in stage 3.
- T_1 for UDR (D2, corrected 3 November): t(0.95, nu) x sqrt(sd_pair^2 + 2 sd_run^2), nu by Welch-Satterthwaite;
  sd_run is the larger measured UDR spread (RANK-B and SELECT June when RANK-B decides); no fixed floor. The
  2 sd_run^2 term assumes the candidate and the control vary from seed to seed by the same amount (one fit of each
  gives no other estimate). No null subtraction: the pair term sd_null (the RMS of the kept-seed pairs' bootstrap
  SDs) is printed by the spread step as information only (`SETTINGS.yaml` `null_correction: false`, the only
  accepted value). The screen prints each term and its source. With 2 df sd_run is rough; T_1 carries that with
  its t value.
- A UDR spread of zero (possible for a count in the top 0.6%, even with different valid fits) is reported, not a
  stop. T_1 is then undefined: a one-seed gain above zero goes to seeds 43 and 44 and the three-seed read decides.
  The same checkpoint or prediction file twice, or a value that is not a number, still stops (exit 3).
- At three seeds: LB_3 = gain - t x sqrt(v_acct + s_d^2 / k), s_d the SD of the k paired seed differences, t at
  k - 1 degrees of freedom (`three_seed_bound: paired`, the only accepted value). The SELECT check's limit is
  -k x sqrt(SE^2 + 2 s_m^2/n), k 2.5 (3.5 when SELECT decides). The k values of the SELECT check and the conflict
  line are working rules for development; their error rates when the two arms vary by different amounts are not
  known.
- The conflict line (D1): a decision that changes the kept inputs and drops AP or VDR below its limit (k 2.5) prints
  a conflict line, also in `C2/DECISIONS.log`; the decision stands. FP/TP@0.6 is false alerts per caught fraud (the
  bank's FPR), not FP/(FP+TN). Fraud accounts with a caught fraud transaction are information, not an account DR.
- Budget (maxima before early stopping): the default steps A1, A2 and month out at most 170 epochs (A1 and A2 110
  with the refit controls and the new seed 43 and 44 fits after a three-seed adoption; month out 60), plus 10 (180)
  with a new seed-42 base control.
