#!/usr/bin/env bash
# Start this workbench's worker in the background (POD.md section 4b). The owner runs this on each workbench, after
# the planner has started (PY=<the pod's python> bash fraud/experiments/features/new_fields/nf_start.sh --workers):
#   PY=<the pod's python> bash fraud/experiments/features/new_fields/nf_worker.sh [--gpu <uuid>]
# It refuses (exit 4) while a worker already runs on this workbench or the GPU's UUID cannot be read.
# Closing the tail does not stop the worker; `$PY $NF/nf_worker.py stop` ends it after its current job.
set -u
NF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$NF/../../../.." && pwd)"
PY="${PY:-}"
if [ -z "$PY" ] || ! "$PY" -c "import omegaconf, torch" > /dev/null 2>&1; then
  echo "refused: set PY to the project's Python, exported, for example:" >&2
  echo "  PY=<the pod's python> bash fraud/experiments/features/new_fields/nf_worker.sh (exit 2)" >&2
  exit 2
fi
cd "$ROOT"
OUT="${NF_OUT:-checkpoints/new_fields}"
mkdir -p "$OUT/logs"
LOG=$("$PY" "$NF/nf_worker.py" check "$@") || exit $?
echo "=== nf_worker $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$LOG"
NF_PY="$PY" nohup "$PY" "$NF/nf_worker.py" run "$@" >> "$LOG" 2>&1 &
echo "worker started, pid $!"
echo "report: $PY $NF/nf_report.py"
[ "${NF_NO_TAIL:-}" = "1" ] && exit 0
tail -n 20 -f "$LOG"
