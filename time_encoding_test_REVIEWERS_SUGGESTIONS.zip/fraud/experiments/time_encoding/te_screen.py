"""Optional: the paper's one-epoch screen of lambda (gain) and f_base (base), run on our data.

The paper picked its setting this way: one epoch per pair, f_base in {1, 10, 1e3, 1e4, 1e5, 1e6, 1e7, 1e8} x
lambda in {0.01, 0.1}, judged on validation. It kept lambda 0.01, f_base 1e7, which is the main arm. Our gaps
(seconds to weeks between card transactions) differ from the paper's events, so the best f_base here may differ.
This screen finds it on our validation files. It never touches Test 1 or SELECT.

Where it runs: on the pod, from the project root, on a workbench whose GPU is free. The full grid is 16 runs of
one epoch, one after another.

Usage:

    $PY fraud/experiments/time_encoding/te_screen.py run [--root runs/time_encoding/screen] [--unit ms] \
        [--bases 1 10 1e3 1e4 1e5 1e6 1e7 1e8] [--gains 0.01 0.1] [--epochs 1] [--dry-run] -- \
        <the exact trainer arguments of the seed-42 control run>

    $PY fraud/experiments/time_encoding/te_screen.py collect [--root runs/time_encoding/screen] \
        [--control-metrics <control run folder>/training_metrics.csv]

ADAPT: `<the exact trainer arguments ...>` are the same as for train_time_encoding.py (the seed-42 control's
--config and overrides). Any output.checkpoint_dir= or training.max_epochs= among them is replaced: each run gets
its own folder <root>/base<B>_gain<G>_<unit> and training.max_epochs=<epochs>. --control-metrics is the control
run's training_metrics.csv; its epoch 0 row is the plain model after one epoch, for reference.

run: one train_time_encoding.py process per pair. A pair whose folder already holds best.ckpt is skipped, so
the same command continues after an interruption. --dry-run prints the commands only.
collect: reads the epoch 0 row of each run's training_metrics.csv (valid_ap is the trainer's monitor) and ranks
the pairs by it; writes <root>/screen_summary.json.

Exit 0 done; 4 refused (bad arguments, no finished run); 5 some runs failed (the others are kept).
"""
import argparse
import csv
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import te_patch  # noqa: E402

PAPER_BASES = (1.0, 10.0, 1e3, 1e4, 1e5, 1e6, 1e7, 1e8)
PAPER_GAINS = (0.01, 0.1)
REPLACED = ("output.checkpoint_dir=", "training.max_epochs=")


def run_dir(root, base, gain, unit):
    return Path(root) / f"base{base:g}_gain{gain:g}_{unit}"


def commands(rest, root, bases, gains, unit, epochs):
    """[(folder, argv)] for every pair, in grid order (bases outer, gains inner)."""
    kept = [x for x in rest if not x.startswith(REPLACED)]
    out = []
    for base in bases:
        for gain in gains:
            te_patch.settings_from(gain, base, True, unit)  # refuses a bad pair before anything runs
            folder = run_dir(root, base, gain, unit)
            argv = [sys.executable, str(HERE / "train_time_encoding.py"), "--gain", f"{gain:g}", "--base",
                    f"{base:g}", "--unit", unit, "--", *kept, f"training.max_epochs={int(epochs)}",
                    f"output.checkpoint_dir={folder}"]
            out.append((folder, argv))
    return out


def first_epoch(metrics_csv):
    """The epoch 0 row of a trainer metrics CSV, as floats where possible; None when there is none."""
    with open(metrics_csv, newline="") as f:
        for row in csv.DictReader(f):
            if int(float(row["epoch"])) == 0:
                out = {}
                for k, v in row.items():
                    try:
                        out[k] = float(v)
                    except (TypeError, ValueError):
                        out[k] = v
                return out
    return None


def collect(root, control_metrics=None, monitor="valid_ap"):
    import torch

    rows = []
    for ckpt in sorted(Path(root).glob("*/best.ckpt")):
        metrics = ckpt.parent / "training_metrics.csv"
        first = first_epoch(metrics) if metrics.is_file() else None
        if first is None or monitor not in first:
            continue
        settings = torch.load(ckpt, map_location="cpu", weights_only=False).get(te_patch.CHECKPOINT_KEY)
        if not settings:
            continue
        rows.append({"run": str(ckpt.parent), "base": settings["base"], "gain": settings["gain"],
                     "unit": settings["unit"], "layernorm": settings["layernorm"], monitor: first[monitor],
                     "valid_auroc": first.get("valid_auroc"), "valid_loss": first.get("valid_loss")})
    rows.sort(key=lambda r: -r[monitor])
    control = None
    if control_metrics:
        first = first_epoch(control_metrics)
        control = None if first is None else {monitor: first.get(monitor), "valid_auroc": first.get("valid_auroc"),
                                               "valid_loss": first.get("valid_loss"), "file": str(control_metrics)}
    return {"monitor": monitor, "epoch": 0, "runs": rows, "best": rows[0] if rows else None,
            "control_epoch0": control,
            "paper_setting": {"base": te_patch.DEFAULTS["base"], "gain": te_patch.DEFAULTS["gain"],
                              "unit": te_patch.DEFAULTS["unit"]}}


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    rest = []
    if "--" in argv:
        i = argv.index("--")
        argv, rest = argv[:i], argv[i + 1:]
    ap = argparse.ArgumentParser(description="the paper's one-epoch screen of gain and base")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    r.add_argument("--root", default="runs/time_encoding/screen")
    r.add_argument("--unit", choices=sorted(te_patch.UNITS), default=te_patch.DEFAULTS["unit"])
    r.add_argument("--bases", type=float, nargs="+", default=list(PAPER_BASES))
    r.add_argument("--gains", type=float, nargs="+", default=list(PAPER_GAINS))
    r.add_argument("--epochs", type=int, default=1)
    r.add_argument("--dry-run", action="store_true")
    c = sub.add_parser("collect")
    c.add_argument("--root", default="runs/time_encoding/screen")
    c.add_argument("--control-metrics", default=None)
    a = ap.parse_args(argv)

    if a.cmd == "run":
        if not rest or "--config" not in rest:
            print("REFUSED: give the control's trainer arguments (--config ... and its overrides) after --",
                  file=sys.stderr)
            return 4
        dropped = [x for x in rest if x.startswith(REPLACED)]
        if dropped:
            print(f"note: replaced by the screen's own values: {dropped}", flush=True)
        try:
            todo = commands(rest, a.root, a.bases, a.gains, a.unit, a.epochs)
        except ValueError as exc:
            print(f"REFUSED: {exc}", file=sys.stderr)
            return 4
        failed = []
        for n, (folder, cmd) in enumerate(todo, 1):
            if (folder / "best.ckpt").is_file():
                print(f"[{n}/{len(todo)}] {folder}: done already, skipped", flush=True)
                continue
            print(f"[{n}/{len(todo)}] {' '.join(cmd)}", flush=True)
            if a.dry_run:
                continue
            rc = subprocess.run(cmd).returncode
            if rc != 0:
                failed.append({"run": str(folder), "exit": rc})
                print(f"[{n}/{len(todo)}] {folder}: FAILED (exit {rc}); continuing with the next pair", flush=True)
        if failed:
            print(f"{len(failed)} run(s) failed: {failed}", file=sys.stderr)
            return 5
        return 0

    rep = collect(a.root, a.control_metrics)
    if not rep["runs"]:
        print(f"REFUSED: no finished run with an epoch 0 row under {a.root}", file=sys.stderr)
        return 4
    out = Path(a.root) / "screen_summary.json"
    out.write_text(json.dumps(rep, indent=2))
    m = rep["monitor"]
    print(f"{'rank':<6}{'base':>10}{'gain':>8}{'unit':>6}{m:>12}{'valid_auroc':>13}   run")
    for i, row in enumerate(rep["runs"], 1):
        auroc = row["valid_auroc"]
        print(f"{i:<6}{row['base']:>10g}{row['gain']:>8g}{row['unit']:>6}{row[m]:>12.6f}"
              f"{(f'{auroc:.6f}' if isinstance(auroc, float) else '-'):>13}   {row['run']}")
    if rep["control_epoch0"] and isinstance(rep["control_epoch0"].get(m), float):
        print(f"plain model after one epoch (control): {m} {rep['control_epoch0'][m]:.6f}")
    print(f"summary: {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
