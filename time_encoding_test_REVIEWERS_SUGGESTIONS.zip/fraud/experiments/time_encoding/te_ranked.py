"""The reader's engine: ranked scores, the bank's outsort measures, AP, and the account bootstrap.

Pure numpy. Importing this module does no work. It holds no project import, so the reader can run it on any
layout, and its tests can compare it with the analysis module's ``outsort_metrics`` by path.

Ranking: descending score, ties broken by the ascending identity key ``json.dumps([str(account), str(id)])``.
The key is replaced by its rank among the rows (the same order in far less memory).

Outsort at a share p = a/b: the top floor(W x a / b) rows, W the total weight (the row count at the point), in
integer arithmetic. The boundary row's copies (a bootstrap weight above one) count only up to the budget.

- UDR = frauds in the outsort / all frauds (counts).
- VDR = fraud amount in the outsort / all fraud amount. Null with a reason if an amount is missing, not finite
  or negative.
- FPR, as the bank uses it = false positives / true positives in the outsort. Lower is better.
- AP and AUROC treat equal scores as one threshold (as scikit-learn). KS is read only after a whole tied group.
  AP is defined whenever there is a fraud (all frauds gives 1.0); AUROC and KS need frauds and non-frauds.

The account bootstrap resamples whole accounts with replacement. Units are the distinct accounts in ascending
string order. Draw b uses ``numpy.random.default_rng(seed)``: ``bincount(integers(0, n, n))``, one draw at a time.
The sequence depends only on the seed and the number of accounts, so every fit compared gets the same draws.
"""
from __future__ import annotations

from fractions import Fraction
import json

import numpy as np

SHARE_06 = Fraction(3, 500)  # 0.6% is exactly 6 per mille
METRICS = ("udr", "ap", "vdr", "fpr", "auroc", "ks")
LOWER_IS_BETTER = ("fpr",)


# ------------------------------------------------------------------------------------------------------------ #
# Keys, units and draws
# ------------------------------------------------------------------------------------------------------------ #
def identity_keys(accounts, ids):
    """The identity key for ties: JSON of [account, transaction id], both as strings."""
    return np.asarray([json.dumps([str(a), str(i)]) for a, i in zip(accounts, ids)], dtype=object)


def key_ranks(keys):
    """Ordinal rank of each key in ascending string order. Keys must be unique."""
    text = np.asarray([str(k) for k in keys], dtype=object)
    order = np.argsort(text, kind="stable")
    if len(text) > 1 and (text[order][1:] == text[order][:-1]).any():
        raise ValueError("identity keys must be unique")
    ranks = np.empty(len(text), dtype=np.int64)
    ranks[order] = np.arange(len(text))
    return ranks


def compact_keys(ranks):
    """Zero-padded rank strings. They sort exactly as the original keys."""
    width = len(str(max(len(ranks) - 1, 0)))
    return np.asarray([f"{int(r):0{width}d}" for r in ranks])


def account_units(accounts):
    """Account code per row and the units (distinct accounts as strings, ascending)."""
    text = np.asarray([str(a) for a in accounts], dtype=object)
    units, codes = np.unique(text, return_inverse=True)
    return codes.astype(np.int64).reshape(-1), units


def multiplicity_draws(n_units, draws, seed):
    """Account multiplicities, one draw at a time (memory stays flat)."""
    rng = np.random.default_rng(seed)
    for _ in range(int(draws)):
        yield np.bincount(rng.integers(0, n_units, n_units), minlength=n_units)


def draw_matrix(n_units, draws, seed):
    """The same draws as a full matrix (for tests on small cases)."""
    return np.vstack(list(multiplicity_draws(n_units, draws, seed))) if draws else np.empty((0, n_units), int)


def amount_reason(amounts):
    """None if the amounts can give VDR, else the reason VDR is null."""
    if amounts is None:
        return "amount not supplied"
    values = np.asarray(amounts, dtype=float)
    if not np.isfinite(values).all():
        return "an amount is missing or not finite"
    if (values < 0).any():
        return "a negative amount; no sign convention is assumed"
    if not np.isfinite(values.sum()):
        return "the total amount is not finite"
    return None


# ------------------------------------------------------------------------------------------------------------ #
# One fit, ranked once
# ------------------------------------------------------------------------------------------------------------ #
class RankedScore:
    """One fit's scores on the read's rows, sorted once.

    ``evaluate(multiplicity)`` takes one account multiplicity vector (all ones for the point) and returns every
    measure from three cumulative sums.
    """

    def __init__(self, scores, y, codes, key_rank, amounts=None, share=SHARE_06):
        scores = np.asarray(scores, dtype=float)
        y = np.asarray(y)
        if scores.ndim != 1 or len(scores) != len(y) or len(y) != len(codes) or len(y) != len(key_rank):
            raise ValueError("scores, labels, account codes and keys must have one value per row")
        if not len(y):
            raise ValueError("no rows")
        if not np.isfinite(scores).all():
            raise ValueError("scores must be finite")
        if not np.isin(y, [0, 1]).all():
            raise ValueError("labels must be 0 or 1")
        self.share = Fraction(share)
        self.order = order = np.lexsort((np.asarray(key_rank), -scores))
        s = scores[order]
        self.y = y.astype(np.int64)[order]
        self.codes = np.asarray(codes, dtype=np.int64)[order]
        self.amount_reason = amount_reason(amounts)
        self.values = None if self.amount_reason else (np.asarray(amounts, dtype=float) * y)[order]
        self.ends = np.flatnonzero(np.r_[s[1:] != s[:-1], True])

    def evaluate(self, multiplicity=None):
        if multiplicity is None:
            w = np.ones(len(self.y), dtype=np.int64)
        else:
            w = np.asarray(multiplicity, dtype=np.int64)[self.codes]
        cw = np.cumsum(w)
        cwy = np.cumsum(w * self.y)
        total, positives = int(cw[-1]), int(cwy[-1])
        negatives = total - positives
        out = {"rows": total, "frauds": positives, "ap": np.nan, "auroc": np.nan, "ks": np.nan}
        # AP needs a fraud (all frauds gives 1.0, as scikit-learn and average_precision); AUROC and KS need both
        # classes. Undefined values stay NaN.
        if positives > 0:
            tp = cwy[self.ends]
            fp = cw[self.ends] - tp
            dtp = np.diff(tp, prepend=0)
            out["ap"] = float(np.dot(dtp, tp / np.maximum(cw[self.ends], 1)) / positives)  # 0 weight: dtp 0
            if negatives > 0:
                dfp = np.diff(fp, prepend=0)
                out["auroc"] = float(np.dot(dtp, (negatives - fp) + 0.5 * dfp) / (positives * negatives))
                out["ks"] = float(np.abs(tp / positives - fp / negatives).max())
        count = total * self.share.numerator // self.share.denominator
        cv = None if self.values is None else np.cumsum(w * self.values)
        if count == 0:
            caught, amount = 0, 0.0
        else:
            k = int(np.searchsorted(cw, count, side="left"))
            partial = count - (int(cw[k - 1]) if k else 0)
            caught = (int(cwy[k - 1]) if k else 0) + partial * int(self.y[k])
            amount = None if cv is None else (float(cv[k - 1]) if k else 0.0) + partial * float(self.values[k])
        fraud_amount = None if cv is None else float(cv[-1])
        out["outsorted"] = int(count)
        out["frauds_outsorted"] = int(caught)
        out["false_positives"] = int(count - caught)
        out["udr"] = caught / positives if positives else np.nan
        out["vdr"] = amount / fraud_amount if (cv is not None and fraud_amount) else np.nan
        out["fpr"] = (count - caught) / caught if caught else np.nan
        return out


    def fraud_accounts_caught(self):
        """(fraud accounts with at least one fraud transaction in the top floor(N x 3/500) rows, all fraud accounts),
        at the point. Information only, not an account-level DR (the reviewers' decision D1): no bootstrap."""
        count = len(self.y) * self.share.numerator // self.share.denominator
        top = self.y[:count] == 1
        caught = len(np.unique(self.codes[:count][top])) if count else 0
        return int(caught), int(len(np.unique(self.codes[self.y == 1])))


def vector(result, metrics=METRICS):
    return np.asarray([result[m] for m in metrics], dtype=float)


# ------------------------------------------------------------------------------------------------------------ #
# Paired comparison on the same draws
# ------------------------------------------------------------------------------------------------------------ #
def _summary(values, interval):
    finite = values[np.isfinite(values)]
    low_q = (100.0 - interval) / 2.0
    if len(finite) < 2:
        return {"sd": None, "var": None, "lo": None, "hi": None, "valid_draws": int(len(finite)),
                "undefined_draws": int(len(values) - len(finite))}
    return {"sd": float(np.std(finite, ddof=1)), "var": float(np.var(finite, ddof=1)),
            "lo": float(np.percentile(finite, low_q)), "hi": float(np.percentile(finite, 100.0 - low_q)),
            "valid_draws": int(len(finite)), "undefined_draws": int(len(values) - len(finite))}


def paired(candidates, controls, n_units, draws, seed, interval=90, metrics=METRICS, keep_draws=0):
    """Candidate minus control, per seed and as the mean over seeds, with the account bootstrap.

    ``candidates`` and ``controls`` are lists of RankedScore, one per seed, in the same seed order. Every fit is
    evaluated on the same draws. Returns per metric: the per-seed points and differences, the gain g (mean of the
    differences), and the bootstrap sd, variance and percentile interval of g_b.
    """
    if len(candidates) != len(controls) or not candidates:
        raise ValueError("one candidate and one control per seed")
    fits = list(candidates) + list(controls)
    k = len(candidates)
    points = np.vstack([vector(f.evaluate(None), metrics) for f in fits])
    raw_points = [f.evaluate(None) for f in fits]
    gains = np.full((len(metrics), int(draws)), np.nan)
    kept = []
    for b, mult in enumerate(multiplicity_draws(n_units, draws, seed)):
        values = np.vstack([vector(f.evaluate(mult), metrics) for f in fits])
        gains[:, b] = (values[:k] - values[k:]).mean(axis=0)
        if b < keep_draws:
            kept.append(mult)
    result = {}
    for m, name in enumerate(metrics):
        d = points[:k, m] - points[k:, m]
        result[name] = {"candidate": points[:k, m].tolist(), "control": points[k:, m].tolist(),
                        "differences": d.tolist(), "gain": float(np.mean(d)),
                        "candidate_mean": float(np.mean(points[:k, m])), "control_mean": float(np.mean(points[k:, m])),
                        **_summary(gains[m], interval)}
    return {"metrics": result, "points": raw_points, "gain_draws": gains, "first_draws": kept}


def pair_variances(fits, pairs, n_units, draws, seed, metrics=METRICS):
    """The account bootstrap variance (ddof 1, finite draws) of each pair's difference, fit i minus fit j, with
    every fit evaluated once per draw on the same draws. Returns {(i, j): {metric: variance or None}}. The spread's
    same-recipe pair term sd_null is the root mean square of these over the pairs (the reviewers' decision D2)."""
    diffs = {p: np.full((len(metrics), int(draws)), np.nan) for p in pairs}
    for b, mult in enumerate(multiplicity_draws(n_units, draws, seed)):
        vals = [vector(f.evaluate(mult), metrics) for f in fits]
        for (i, j) in pairs:
            diffs[(i, j)][:, b] = vals[i] - vals[j]
    return {p: {m: _summary(diffs[p][k], 90)["var"] for k, m in enumerate(metrics)} for p in pairs}


def lift_paired(fit_raw, fit_emb, ctrl_raw, ctrl_emb, n_units, draws, seed, interval=90, metrics=("udr", "ap")):
    """Lift = metric(raw + embedding) minus metric(raw), for a fit and its control; their difference with the
    paired account bootstrap (the same draws for all four arms). Its sd is the paired SE."""
    arms = [fit_raw, fit_emb, ctrl_raw, ctrl_emb]
    pts = np.vstack([vector(a.evaluate(None), metrics) for a in arms])
    diffs = np.full((len(metrics), int(draws)), np.nan)
    for b, mult in enumerate(multiplicity_draws(n_units, draws, seed)):
        v = np.vstack([vector(a.evaluate(mult), metrics) for a in arms])
        diffs[:, b] = (v[1] - v[0]) - (v[3] - v[2])
    out = {}
    for m, name in enumerate(metrics):
        lift_fit, lift_ctrl = pts[1, m] - pts[0, m], pts[3, m] - pts[2, m]
        out[name] = {"fit_raw": pts[0, m], "fit_embedding": pts[1, m], "control_raw": pts[2, m],
                     "control_embedding": pts[3, m], "lift_fit": float(lift_fit), "lift_control": float(lift_ctrl),
                     "difference": float(lift_fit - lift_ctrl), **_summary(diffs[m], interval)}
    return out


# ------------------------------------------------------------------------------------------------------------ #
# Convenience functions on plain arrays (for other tools, for example the importance tool)
# ------------------------------------------------------------------------------------------------------------ #
def _prepare(y, accounts, ids):
    keys = identity_keys(accounts, ids)
    codes, units = account_units(accounts)
    return key_ranks(keys), codes, len(units)


def outsort(y, scores, accounts, ids, amounts=None, per_mille=6):
    """UDR, VDR and the bank's FPR (false positives / true positives) at an outsort of ``per_mille`` / 1000.

    The top floor(N x per_mille / 1000) rows by descending score, ties broken by the ascending identity key
    ``json.dumps([str(account), str(id)])``. Equal to the analysis module's ``outsort_metrics`` on the same inputs.
    Returns the dict of ``RankedScore.evaluate`` (rows, frauds, outsorted, frauds_outsorted, false_positives, udr,
    vdr, fpr, ap, auroc, ks); undefined values are NaN.
    """
    key_rank, codes, _ = _prepare(y, accounts, ids)
    return RankedScore(scores, y, codes, key_rank, amounts, Fraction(int(per_mille), 1000)).evaluate(None)


def average_precision(y, scores, weights=None):
    """AP with equal scores as one threshold, as scikit-learn's ``average_precision_score`` (with sample_weight)."""
    y = np.asarray(y, dtype=np.int64)
    s = np.asarray(scores, dtype=float)
    w = np.ones(len(y), dtype=np.int64) if weights is None else np.asarray(weights, dtype=np.int64)
    order = np.argsort(-s, kind="stable")
    s, y, w = s[order], y[order], w[order]
    ends = np.flatnonzero(np.r_[s[1:] != s[:-1], True])
    cw, cwy = np.cumsum(w)[ends], np.cumsum(w * y)[ends]
    positives = cwy[-1] if len(cwy) else 0
    if positives == 0:
        return float("nan")
    return float(np.dot(np.diff(cwy, prepend=0), cwy / np.maximum(cw, 1)) / positives)


def paired_bootstrap(score_list, y, accounts, ids, amounts=None, draws=2000, seed=20261102, per_mille=6,
                     metrics=METRICS):
    """Every fit's measures on the same account draws.

    ``score_list``: one score array per fit, all aligned with ``y``, ``accounts``, ``ids`` and ``amounts``.
    Units are the distinct accounts in ascending string order; draw b uses ``numpy.random.default_rng(seed)`` and
    ``bincount(integers(0, n, n))``, so every fit compared sees the same accounts in every draw. Returns
    ``points`` [fits x metrics] and ``draws`` [fits x metrics x draws] (NaN where undefined), with ``metrics``.
    """
    key_rank, codes, n_units = _prepare(y, accounts, ids)
    share = Fraction(int(per_mille), 1000)
    fits = [RankedScore(s, y, codes, key_rank, amounts, share) for s in score_list]
    points = np.vstack([vector(f.evaluate(None), metrics) for f in fits])
    values = np.full((len(fits), len(metrics), int(draws)), np.nan)
    for b, mult in enumerate(multiplicity_draws(n_units, draws, seed)):
        for i, f in enumerate(fits):
            values[i, :, b] = vector(f.evaluate(mult), metrics)
    return {"metrics": list(metrics), "points": points, "draws": values, "accounts": n_units}
