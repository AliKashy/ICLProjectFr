"""Finds the chosen model's code: the organized tree first, then the old tree. The two are never mixed.

Runs on the pod, from the project root. Nothing here needs adapting: the project root is the folder that holds
fraud/experiments/time_encoding/ (or REPRO_PROJECT_ROOT when set, as in the stage 1 checks).
"""
import importlib
import os
import sys
from pathlib import Path

ROOT = Path(os.environ.get("REPRO_PROJECT_ROOT") or Path(__file__).resolve().parents[3]).resolve()

# Module names after the reorganization (REORGANIZATION.md 5.1) and before it, as the features package's
# nf_layout.py has them. raw_join gives load_raw and target_mask (the June target rows, as the reader reads them);
# s3_files gives build_file_list and s3_fs thin_read_filesystem.
NAMES = {
    "organized": {
        "base_model": "fraud.sequential_hier_model",
        "target_ending_model": "fraud.sequential_hier_target_ending_model",
        "trainer": "fraud.scripts.train_sequential_hier",
        "scorer": "fraud.scripts.score_sequential_hier",
        "raw_join": "fraud.scripts.compare_models",
        "s3_files": "fraud.data.s3_utils",
        "s3_fs": "fraud.data.s3_utils",
    },
    "old": {
        "base_model": "waqas.phase4b.sequential_hier",
        "target_ending_model": "waqas.v2.models",
        "trainer": "waqas.v2.scripts.train_v2",
        "scorer": "waqas.v2.scripts.score_v2",
        "raw_join": "waqas.v2.analysis.paired_v2",
        "s3_files": "fraud.data.s3_utils",
        "s3_fs": "waqas.v2.storage",
    },
}


class LayoutError(RuntimeError):
    pass


def _put_root_first(root):
    for p in (str(root / "src"), str(root)):
        if p in sys.path:
            sys.path.remove(p)
        sys.path.insert(0, p)


def resolve(root=None, roles=("base_model", "target_ending_model", "trainer", "scorer")):
    """(layout, {role: module}) for the first layout whose base model module exists under root."""
    root = Path(root or ROOT).resolve()
    _put_root_first(root)
    for layout in ("organized", "old"):
        names = NAMES[layout]
        try:
            importlib.import_module(names["base_model"])
        except ModuleNotFoundError as exc:
            if exc.name and names["base_model"].startswith(exc.name):
                continue  # this layout is not here; try the other one
            raise
        mods = {role: importlib.import_module(names[role]) for role in roles}
        for role, mod in mods.items():
            f = Path(mod.__file__).resolve()
            if root not in f.parents:
                raise LayoutError(f"{role} module {mod.__name__} is outside the project root {root}: {f}")
        if not hasattr(mods["base_model"], "FTTransformerHierModel"):
            raise LayoutError(f"{names['base_model']} has no FTTransformerHierModel")
        return layout, mods
    raise LayoutError(f"neither the organized nor the old layout of the chosen model was found under {root}")
