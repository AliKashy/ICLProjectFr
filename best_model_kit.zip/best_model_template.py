"""A stand-in for the strongest model, in which every choice that is being decided is one entry of a configuration.

What this file does
-------------------
It is a template for fitting the new pieces of this package into a model that this file cannot see, as
interleaved_wiring_template.py is one for the field re-reads. It holds:

    Config               every choice the owner is deciding, one entry each, each with a docstring of its own.
                         The defaults are the model in use, so an entry that is left out changes nothing
    TODAY                the model in use: Config() itself
    WIDE_JOINED          tokens twice as wide, the summary outputs still joined: the control for width
    CANDIDATE            tokens twice as wide, six summary outputs kept apart as latent channels through four
                         interleaved pairs of a within-transaction block and a through-time block
    CANDIDATE_LPM        the candidate in the form closest to the Large Payments Model (JPMorgan, arXiv
                         2611.15814): a pooler in place of stage 1, its numeric encoder, its order of blocks and
                         its readout. A docstring next to each of the four says why each entry is set so
    ARMS                 every arm by name: its Config, the arm it is compared with and the one question that
                         comparison answers. The four above are among them; every other arm changes one entry of
                         the arm it is compared with. arm_table (python best_model_template.py --list) prints them
    BestModel            one small complete model shaped like the model in use, built from a Config: the
                         tokenizer, stage 1 (or a pooler in its place), the history (joined, or in channels), the
                         time inputs and the head. forward(batch) gives two logits for every row, export(batch)
                         the vector the head reads
    the edits            the places where the new pieces go in, each marked "EDIT n of 7" in BestModel
    the placeholders     every name that belongs to the model in use, marked "PLACEHOLDER Wn" in the code
    seven checks         later_rows_change_nothing, padding_stays_out, prefix_agrees, every_weight_learns,
                         time_unit_fits, one_model_two_batches, order_inside_a_second: each takes a batch (and,
                         but for the time unit, a model) and the caller's own functions for what differs from one
                         model to another (alter, fill, pad, rebuild, loss), so they run on the model in use.
                         run_checks runs all seven with the time unit the caller names, never the model's own
    channels_stay_apart  whether a hand-off keeps the summary outputs apart, each in one channel of its own; it
                         reads the hand-off alone, so it is run once on the model's own, beside the seven checks
    param_groups         the parameter groups of AdamW: the learned centres at a tenth of the rate, no decay on
                         norms, biases and tables, decay on every map
    cost, compare        the weights and the time of a forward pass and of a training step; one table for any
                         arms by name, with the ratio to TODAY on the same batch
    main                 builds the four named configurations (or any arms), runs every check on each and prints
                         the table, on a made-up batch of 16 sequences of 121 rows

Why it exists
-------------
The owner wants a wider model, the summary tokens kept apart as latent channels the way the Large Payments
Model keeps them, and other encodings of numbers and of time. Each of these is a switch here, so that each can
be tested by itself against the model in use, and one code builds every arm, so that two arms differ only in
the entries in which their configurations differ. A run is long and a GPU hour is dear. Before any run the
checks say whether a configuration keeps the time rule (a row does not change when only rows it may not read
change, its own answer among them, in scoring and in training mode, while the rows after it do change when the
rows they read change; padding reaches no real row in either mode; the first rows of a window score as the
window cut after them, which grouped scoring needs; neither the order of the rows inside a second nor the other
rows of a row's own second, their values or how many there are, move its score; and a sequence scores alone as
in its batch), whether every weight is wired to the loss, whether the times of the batch fit the unit the caller
names, and whether one model scores a second batch, other rows a month later, as a new instance does; `compare`
says what it costs against today's model on the same batch.

The pieces live in their own files: NumericEncoder in numeric_encoders.py, GapEncoder and CalendarEncoder in
time_encoders.py, AttentionBias in attention_bias.py, the re-reads and the bank in interleaved_reread.py, the
channel stage and the pooler in latent_channels.py. This file adds no piece of its own. It writes out, as small
stand-ins, only the parts the model in use already has: the code tables, the grouping step, stage 1, the joined
history, the re-read after stage 2 and the head.

Where it goes
-------------
Nowhere in the pipeline. It is read next to the model in use; the edits of the entries to be tested are copied
into that model's own file, and the seven checks and `cost` are then run on that model with one of its own
batches. CONFIGURATIONS.md, one of the two notes of the kit, lists every entry with its evidence, the cost of
every arm and the order of the runs by the names of ARMS.

What to change for the pod
--------------------------
The kit is twelve files, side by side in one folder: ten modules, best_model_template.py, latent_channels.py,
interleaved_reread.py, masks.py, attention_bias.py, numeric_frontend.py, numeric_encoders.py, time_encoders.py,
interleaved_wiring_template.py and scoring_speed.py, and two notes, CONFIGURATIONS.md (every entry, its
evidence, the cost of every arm and the order of the runs) and INTERLEAVED_REREAD.md (the re-reads of the
joined history). The modules need torch and numpy and nothing else: pandas, scipy and sklearn are read only
inside helpers that no model calls, and settings.py (package only) has a stand-in when it is not there.
tests/test_kit_runs_flat.py (package only) copies exactly these twelve files into an empty folder and runs this
file there with those three blocked. Every other file named in this docstring is marked (package only).

The PLACEHOLDER values below. In the model in use, every "PLACEHOLDER Wn" of the code names what has to be
found there. W1 to W15 mean what they mean in interleaved_wiring_template.py; these are W1 to W8:

    W1   the predictor tokens: one token per predictor, before they are grouped, [B, T, P, d]
    W2   the output sequence of stage 1 for the same transactions (summary outputs and field outputs, in any
         order), [B, T, L, d]
    W3   the times of the rows, [B, T], the tensor the mask of stage 2 is built from, as the builder writes them
         (int64; times in 32-bit or 16-bit floats stop with a plain error, since they cannot hold a second)
    W4   the mask of real rows, and which of its two values means "real". True on real rows here; a mask that is
         True on padding is handed to every new piece as ~mask, and to the checks as real="~is_pad" (a function in
         its place only for a mask that is not one entry, with `pad` beside it)
    W5   the time unit: how many units of W3 make one second, as an int (1_000_000_000 for the nanoseconds of the
         builder). The same `unit` goes to every piece that reads the times and to run_checks
    W6   the stack of history layers of stage 2, and the one call that runs it
    W7   what goes into that stack, and the mask it takes: zero where reading is allowed, minus infinity where it
         is not, one copy per head
    W8   positions in front of the rows that are not transactions (a sequence summary, an account profile). The
         joined history keeps them, with its mask widened as masks.with_prefix widens it. The channel stage has
         no such position, and they are dropped when it takes the place of stage 2: kept as a made-up row, a
         prefix would count as an earlier row of every row, change the gap of the first row and enter the memory
         of the first rows

These are new:

    W16  the numbers of the batch, their scale and the bin edges of the model in use. A column the builder works
         out from other rows (its gap, W21) leaves them once an encoder of its own takes its place
    W17  the codes of the batch, and the table and the bias of every code field
    W18  the predictors kept alone and the groups of the others: the grouping step before stage 1
    W19  the summary tokens of stage 1 and the line that joins their outputs
    W20  the position table of stage 2 and the count it is read by, the real rows of strictly earlier seconds;
         a position the builder writes into the batch is counted by that rule too, and `rebuild` writes it again
    W21  the time-gap input of the model in use and the place where it enters; a gap column the builder writes
         leaves the numbers of W16 when GapEncoder takes its place (EDIT 5), and `rebuild` writes it again while
         the model reads it
    W22  the re-read after stage 2 and the field outputs it reads
    W23  the head, and the vector it reads, which is the exported vector
    W24  OPTIONAL: the is-missing mark of the numbers, for a builder that writes a number in place of a
         missing one
    W25  the training loss, which every_weight_learns and cost take

The edits, one for each part of the forward pass, marked "EDIT n of 7" in BestModel. Only the edits of the
entries under test are made; an entry at its default changes nothing. Every snippet names the unit of W5:

    unit = 1_000_000_000                                       # W5: time units per second of the batch, an int

1. The tokenizer (token_dim, numeric_encoder, n_bins, n_frequencies, learn_centres, missing). The numeric half of
   the field tokenizer (W16) becomes a NumericEncoder; the codes keep their tables (W17):

       numbers = NumericEncoder(C, d, kind=kind, n_bins=n_bins, n_centres=n_bins + 1, n_frequencies=f,
                                learn_centres=learn, missing="zero", unscaled="raise")
       absent = is_missing | (~valid).unsqueeze(-1).expand_as(x)          # W24 and W4: padded slots count as missing
       tokens = torch.cat([numbers(x, missing=absent), code_tokens], dim=-2)                 # W1

   missing="zero" is the behaviour of today and the default of the encoder: a missing number gives its field
   identity alone, and no learned vector waits for missing values. The numbers of a padded slot count as missing
   (a model without an is-missing mark hands the padded slots alone), so that whatever a padded slot holds reaches
   no weight of the encoder, and its look at the first training batches judges the numbers of real rows only.
   "ple" given the model's own edges (`edges=`), with its trained W and b put in by
   load_piecewise_weight(numbers, W, bin_counts, b=b), scores as the trained model. "ple" at a bin count other
   than the model's own (32 in CANDIDATE) has no trained edges: it reads numbers on the [0, 1] scale of
   UnitQuantileScaler fitted on training rows, or it is given edges=fit_edges(scaled_train_rows, n_bins) on that
   scale. Raw numbers handed to bins on [0, 1] all read as 0 or 1: with unscaled="raise" the look stops a training
   step on numbers that lie mostly outside [0, 1] with a plain error, where the default, "warn", gives one warning
   for the fields it names in a batch.
   Numbers that skipped the quantile scaler but lie on [0, 1] (min-max scaled, say) pass the look and crowd into
   the first bins: interval_use(numbers, scaled_train_rows)["held"] gives, per field, how many of the bins hold
   rows, which should be most of them. Every other kind reads
   the [0, 1] scale as well; "learned_ple" and "hybrid" take centres=fit_centres(scaled_train_rows, n_bins + 1)
   for fields with heaps of equal values. Cast to 16 bits, the encoder keeps its frequencies, centres and edges in
   32 bits. A new width trains the tokenizer again.
2. Stage 1 (stage1, stage1_fields, num_summary, stage1_layers, stage1_heads). The summary tokens, the layers and
   the heads are sizes of the encoder the model has. "all" hands it every predictor token in place of the
   grouped inputs (W18). "pooler" takes its place:

       summary = ChannelPooler(d, M, heads)(tokens)                                       # [B, T, M, d]

3. The hand-off (history). The line that joins the summary outputs (W19) stays for "joined" and goes for
   "channels":

       vectors = out[:, :M].reshape(B, T, M * d)                 # joined, as today
       channels = out[:, :M].reshape(B, T, M, d)                 # kept apart

   A joined vector [B, T, M * d] may be split with .view(B, T, M, d) only when it is the M summary outputs side
   by side in channel-major order (the d numbers of output 0, then those of output 1, ...) with nothing applied
   after the join: no norm, no linear layer, no other order. Otherwise the summary outputs are handed over from
   before the join. BestModel.hand_off holds these lines. The seven checks cannot see a hand-off that mixes the
   outputs, since such a model still keeps the time rule, so channels_stay_apart is run once on the model's own
   hand-off, from the summary outputs to the channels the stage takes, with a sample of those outputs; a module or
   a method of one runs with its weights moved a little, so that a mixing part that starts at zero shows too. When
   stage 1 returns the joined vector itself, the code handed over starts at the summary outputs inside stage 1 and
   holds stage 1's own joining line and everything after it, or stage 1 returns its outputs before the join and
   the join moves into the hand-off: a lambda that joins the outputs so that a hand-off of the joined vector can be
   called leaves a mixing join inside stage 1 unseen, and runs as a plain function whose weights are not moved:

       result = channels_stay_apart(hand_off, summary)          # summary [B, T, M, d]; result["apart"] must be True
4. The bank (bank), once per batch and only when something reads it: the predictor tokens of W1 as they are,
   PredictorBank on them and the output of stage 1 (W2), or the field outputs of stage 1.
5. The time inputs and the bias (gap_encoder, gap_ticks_per_second, calendar, time_bias), once per batch before
   the history, at the width of what they join:

       gaps = gap_seconds(times, valid, units_per_second=unit)                    # W3, W4, W5
       extra = GapEncoder(width, kind, ticks_per_second=ticks)(gaps, valid)
       extra = extra + CalendarEncoder(width, units_per_second=unit)(times, valid)
       bias = AttentionBias(0, num_heads=heads, units_per_second=unit)(no_codes, times, valid)   # joined only

   The gap encoder takes the place of the time-gap input of the model in use (W21). `no_codes` is an empty
   [B, T, 0] tensor of codes, so only the time-gap part of the bias is built. The channel stage builds that bias
   itself (time_bias=True below) from the times of every call; a bias made outside and handed to a stage must
   be built from the same batch in the same call.
6. The history. Joined: the stack (W6) stays. Its mask (W7) takes the bias as a choice, minus infinity on closed
   pairs and the bias on open ones, and a layer with a bias runs through `run_layer`, which adds the mask in
   scoring as well (the quick route of nn.TransformerEncoder reads a float mask as yes or no). The re-reads go
   after the layers as INTERLEAVED_REREAD.md says. Channels: the stage takes the place of the
   joining line, the position table (W20), the stack, the gap input and every position in front of the rows
   (W8):

       stage = LatentChannelStage(channel_dim=d, num_channels=M, num_heads=heads, num_pairs=pairs, num_back=5,
                                  num_fields=F, final_intra=True, ties="whole_seconds", intra_order="cross_first",
                                  time_bias=True, units_per_second=unit)
       rows = stage(channels, bank, times, valid, row_extra=extra)        # [B, T, stage.out_dim]

7. After the history (last_reread, head). Joined: the re-read after stage 2 stays (W22). Channels: final_intra
   takes the place of the model's re-read after stage 2; keep only one of the two. The head is built again at
   the width of the vector it reads (W23), nn.Linear(out_dim, 2), and that vector is the export.

Then the seven checks and `cost` run on the model with one of its own batches, with its own `alter`, `fill` and
`loss` (the stand-in's are alter_rows, fill_rows and row_loss), with the unit of W5, and with what the checks
cannot know of the model in use:

    result = run_checks(model, batch, units_per_second=unit, alter=alter, fill=fill, loss=loss, real="mask",
                        labels=("target_seq",), rebuild=rebuild, build=lambda: Model(config))

`real` names the mask of real rows ("~is_pad" for one that is True on padding); `labels` names the entries that
hold each row's answer, which the checks redraw on rows that no compared row may read, the compared row's own
among them (an entry that tells an answer by its presence, no finite number or a value below 0 where there is none,
has that presence turned over in a second pass; `absent` names an ordinary number that says so, 9999 days for a
chargeback that never came); `rebuild` writes again what the builder works out from other rows,
from the slots or from the whole window (a gap column, a slot index, a window's length), so that the checks see a
model read it; `build` gives a new instance never called, so that check 6 sees what the model fixed on an earlier
call and the other checks run on an instance that holds nothing from calls made before them; `pad` makes slots
padding where the mask is a function; `pads` names the side on which the builder pads, which a batch of full
windows does not show. Without `rebuild`, run_checks names every entry not laid out per row, which no check writes
again.

Every call of the checks hands the model a batch of its own (a new dict, the tensors cloned, plain lists, tuples
and dicts copied; an object or a large array is shared and named in a line), so an entry a model keeps in its
batch is worked out afresh in each call, and run_checks names what the model writes there. Check 2 fills the padded
slots with values that are not a number, with 1e30 and with an ordinary number. Checks 1, 2, 6 and 7 run in
training mode as well, with the same dropout masks in both calls of a
comparison, and checks 3 and 7 also cut, shuffle and take rows out in training mode on a copy whose dropout is off,
so that a part that reads the whole batch in training (a batch norm) shows. Check 1 places its probes across the
window, and once more at the second-to-last real row of every sequence; it scores its kept rows under
torch.inference_mode() and in evaluation mode with gradients on as well, the other ways a scorer may score; it also
needs the later rows to move when the earlier rows change: a mask True on padding fails it, with a line that says
so. Check 3 puts the real rows in time order among their own slots and cuts inside a shared second and near the
first slot, every eighth and the last slot (cut=range(1, T) cuts after every slot); it writes a cut window as the
builder does, padded on the left when the batch pads there (pads="left" for a batch of full windows from such a
builder), and at the full width when the model takes no narrower batch; and it scores the model as handed over, in
its own number type and in each of the three ways of scoring, on the window whose slots from the cut on are made
padding in place, where a kept row may move only by the rounding of a model that works over other shapes then (one
that trims its batch, packs its real rows or groups them: the 64-bit copy tells that rounding from a read, with a
line). Where the checks make padding they write it as a builder
does: the mask, a time in no second of a real row, and on every other entry the value the padded slots of the batch
hold. Check 6 makes its own second batch from other rows a month later, calls a third time, scores after a training
call and under torch.inference_mode(), scores every sequence alone and changes half the sequences in training mode;
check 7 also takes the other rows of a shared second away from one row that must not move (the first or the last
slot of its second), in up to ORDER_PASSES shared seconds of every sequence, spread from its first to its last.
Checks 3 and 7 and the lone sequences of check 6 run on a copy in 64-bit numbers with autocast off, in which every
narrower float that a torch function takes or hands back is widened (a mask or a tensor the model builds in
float32, a cast it makes inside); there rounding is about 1e-14 of a score and a wide history does not fail on it.
A model that does not run in 64 bits as it does in 32 is compared in 32-bit numbers at full precision, with a line:
there rounding alone reaches the tolerance from about 300 numbers of joined width. A model in 16 bits is compared
the same way. A batch laid out as the builder of the model in use writes one, real rows in time order by whole
second with right padding, keeps that layout in every check; only the shuffle of check 7 changes the order of the
rows inside a second, and a model that stops on that is shuffled only among the rows that share their time to the
last unit, with a line. A check that cannot make a batch it needs (padding, with a function `real` and no `pad`; a
window the model stops on, on either side) gives not a number, which fails it. Each check prints one line through
`say` when it sees something to explain, and the docstring of each says what it returns; run_checks also names what
the code of the model reads outside its instances (a class attribute, a module variable, a function's default or
closure, a store every copy shares) that changes while the checks run.

The optimiser takes param_groups(model, lr, weight_decay). On the GPU, `compare` gives the time of every arm
before any run is scheduled; the ratios on a CPU are not those of a GPU.

How to try it
-------------
    model = BestModel(CANDIDATE)                     # or TODAY, WIDE_JOINED, CANDIDATE_LPM, ARMS["WIDTH_48"].config
    result = run_checks(model, batch, units_per_second=1_000_000_000, build=lambda: BestModel(CANDIDATE))
    print(result["passes"])                          # the seven checks; the unit is required
    logits = model(batch)                            # [B, T, 2] for every row
    vectors = model.export(batch)                    # [B, T, 576]: what the head reads
    print(describe(model))                           # every entry, the entries without effect, weights by part
    channels_stay_apart(model.hand_off, torch.randn(2, 5, 6, 96))["apart"]   # True: each output one channel
    optimiser = torch.optim.AdamW(param_groups(model, lr=3e-4, weight_decay=0.01))
    compare(["CANDIDATE", "WIDTH_48", "WIDTH_144"], make_batch())     # any arms by name, with the ratio to TODAY
    python best_model_template.py                    # every check of every named configuration, and the table
    python best_model_template.py --list             # every arm: its change, its question, what it is set against
    python best_model_template.py --arms WIDTH_48 MEMORY_0             # the checks and the table for any arms
    python -m pytest -q additions/tests/test_model_best_model_template.py                         # package only
"""
import argparse
import collections
import contextlib
import copy
import dataclasses
import datetime
import dis
import itertools
import math
import random
import sys
import sysconfig
import types
import weakref
from dataclasses import dataclass, replace
from pathlib import Path
from time import perf_counter
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

try:                                    # inside the package
    from ..encoding.numeric_encoders import KINDS as NUMERIC_ENCODERS
    from ..encoding.numeric_encoders import CENTRE_LR_FACTOR, MISSING_KINDS, N_FREQUENCIES, NumericEncoder
    from ..encoding.numeric_encoders import centre_parameters
    from ..encoding.time_encoders import KINDS as GAP_ENCODERS
    from ..encoding.time_encoders import SINUSOID_TICKS_PER_SECOND, CalendarEncoder, GapEncoder, gap_seconds
    from .attention_bias import AttentionBias
    from .interleaved_reread import TIES, InterleavedReread, PredictorBank, RecentFieldMemory, eligible_rows
    from .latent_channels import INTRA_ORDERS, LAYOUTS, READOUTS, ChannelPooler, LatentChannelStage
    from .masks import _unit, whole_seconds
except ImportError:
    _HERE = Path(__file__).resolve().parent
    if (_HERE.parent / "encoding" / "numeric_encoders.py").is_file() and str(_HERE.parents[1]) not in sys.path:
        # Run as a script from additions/model/: the encoders sit in the sibling folder, so the package is reached
        # from the folder that holds it, as reference_model.py (package only) reaches it.
        sys.path.insert(0, str(_HERE.parents[1]))
    try:                                # the package on the import path
        from additions.encoding.numeric_encoders import KINDS as NUMERIC_ENCODERS
        from additions.encoding.numeric_encoders import CENTRE_LR_FACTOR, MISSING_KINDS, N_FREQUENCIES
        from additions.encoding.numeric_encoders import NumericEncoder, centre_parameters
        from additions.encoding.time_encoders import KINDS as GAP_ENCODERS
        from additions.encoding.time_encoders import SINUSOID_TICKS_PER_SECOND, CalendarEncoder, GapEncoder
        from additions.encoding.time_encoders import gap_seconds
        from additions.model.attention_bias import AttentionBias
        from additions.model.interleaved_reread import TIES, InterleavedReread, PredictorBank, RecentFieldMemory
        from additions.model.interleaved_reread import eligible_rows
        from additions.model.latent_channels import INTRA_ORDERS, LAYOUTS, READOUTS, ChannelPooler
        from additions.model.latent_channels import LatentChannelStage
        from additions.model.masks import _unit, whole_seconds
    except ImportError:                 # the files side by side in one folder
        from numeric_encoders import KINDS as NUMERIC_ENCODERS
        from numeric_encoders import CENTRE_LR_FACTOR, MISSING_KINDS, N_FREQUENCIES, NumericEncoder
        from numeric_encoders import centre_parameters
        from time_encoders import KINDS as GAP_ENCODERS
        from time_encoders import SINUSOID_TICKS_PER_SECOND, CalendarEncoder, GapEncoder, gap_seconds
        from attention_bias import AttentionBias
        from interleaved_reread import TIES, InterleavedReread, PredictorBank, RecentFieldMemory, eligible_rows
        from latent_channels import INTRA_ORDERS, LAYOUTS, READOUTS, ChannelPooler, LatentChannelStage
        from masks import _unit, whole_seconds

# PLACEHOLDER: the number of predictors per transaction in the model in use (W14), one token each.
N_PREDICTORS = 64

# PLACEHOLDER: how many of the predictors are numbers, the rest being codes; the stand-in puts the numbers first.
N_NUMERIC = 40

# PLACEHOLDER: the table size of every code predictor; the model in use has a size of its own per field, and its
# larger tables hold most of the weights it has beyond the stand-in.
CODE_SIZE = 12

# PLACEHOLDER: how many predictors go into stage 1 as a token of their own (W18); the stand-in takes the first ones.
N_PRIORITY = 4

# PLACEHOLDER: the number of groups in which the other predictors are averaged before stage 1 (W18).
N_GROUPS = 3

# PLACEHOLDER: how many units of the batch's times make one second (W5): 1 for whole seconds, 1_000_000_000 for
# nanoseconds; it must be the unit the mask of stage 2 is built with. The stand-in's batch carries nanoseconds.
TIME_UNITS_PER_SECOND = 1_000_000_000

# PLACEHOLDER: the width of a field token of the model in use (W10), the default of Config.token_dim.
TOKEN_DIM = 48

# PLACEHOLDER: the bins of the piecewise-linear encoding of the numbers of the model in use.
N_BINS = 16

# PLACEHOLDER: the summary tokens of stage 1 of the model in use.
NUM_SUMMARY = 3

# PLACEHOLDER: the layers of stage 1 of the model in use.
STAGE1_LAYERS = 2

# PLACEHOLDER: the attention heads of stage 1 of the model in use.
STAGE1_HEADS = 8

# PLACEHOLDER: the history layers of stage 2 of the model in use (W10).
HISTORY_LAYERS = 4

# PLACEHOLDER: the attention heads of stage 2 of the model in use (W10).
HISTORY_HEADS = 8

# PLACEHOLDER: the largest count of earlier rows the position table tells apart (120 for windows of up to 121
# transactions); the table has HISTORY_LEN + 1 entries.
HISTORY_LEN = 120

# PLACEHOLDER: the dropout of the layers of the model in use (W14).
DROPOUT = 0.1

# PLACEHOLDER: how many earlier rows the memory of the re-read designs M and AM holds (W13), 5 in the wiring template.
REREAD_BACK = 5

# PLACEHOLDER: the number of weights of the model in use, which the weights of TODAY are set against.
WEIGHTS_IN_USE = 1_544_422

# PLACEHOLDER: the peak learning rate of the training script of the model in use (3e-4 in the current recipe, as
# RECIPE.md (package only) reads it); param_groups takes it when no rate is given.
LEARNING_RATE = 3e-4

# PLACEHOLDER: the weight decay of AdamW in the training script of the model in use; 0.01 is the default of
# torch.optim.AdamW and the value of the bundled arm of RECIPE.md (package only); param_groups takes it when none is
# given.
WEIGHT_DECAY = 0.01

# PLACEHOLDER: the last part of the name of every learned table or vector that is added or looked up as it is rather
# than multiplied with an input (the field identities, the missing vectors, the summary tokens, the channel
# identities, the queries, the look-back and field vectors of a memory, the four tables of AttentionBias, and the
# Fourier frequencies, which set the scale of the features); a model in use that names its tables otherwise adds
# those names here, so that param_groups keeps them out of the decay.
NO_DECAY_NAMES = ("identity", "missing", "summary", "queries", "read_query", "back_key", "back_value", "field_key",
                  "field_value", "same_weight", "count_weight", "gap_weight", "self_weight", "frequencies")

# The code predictors follow the numbers in the stand-in's order of predictors.
N_CODES = N_PREDICTORS - N_NUMERIC

# The values the entries that take a name accept. The encoders and the channel stage define their own.
STAGE1_KINDS = ("summary", "pooler")
STAGE1_FIELDS = ("grouped", "all")
HISTORIES = ("joined", "channels")
BANKS = ("predictor", "predictor_bank", "stage1")
REREADS = (None, "A", "M", "AM")
HEAD_KINDS = ("linear",)

# The re-read designs of the joined history, as in interleaved_wiring_template.py: (a re-read after every layer,
# earlier rows in the memory). "M" has one re-read, after the last layer.
REREAD_DESIGNS = {"A": (True, 0), "M": (False, REREAD_BACK), "AM": (True, REREAD_BACK)}

# The entries that belong to the channel stage; the joined history has none of them.
CHANNEL_ENTRIES = ("layout", "channel_identity", "channel_projections", "share_temporal", "intra_self_attention",
                   "intra_cross_attention", "intra_order", "num_back", "final_intra", "readout")


# ----------------------------------------------------------------------------------------------
# the configuration
# ----------------------------------------------------------------------------------------------

@dataclass(frozen=True)
class Config:
    """Every choice that is being decided, one entry each; the defaults are the model in use (TODAY).

    The configuration is frozen, so that a named configuration cannot change by accident;
    replace(config, entry=value) makes one that differs in that entry alone. An entry that has no
    effect in a configuration (a channel entry when the history is joined, say) is listed with the
    reason by `describe`, so that a run with that entry is not taken for a test of it.
    """

    token_dim: int = TOKEN_DIM
    """Width d of a field token, of every stage-1 token and of a latent channel; the joined history is
    num_summary x d wide."""

    numeric_encoder: str = "ple"
    """How a number becomes a token, the `kind` of NumericEncoder (numeric_encoders.py): "ple", W_c PLE(x) + b_c
    with fixed bins, the encoder of the model in use; "learned_ple", centres that move, started evenly on [0, 1];
    "periodic", the value and the sines and cosines of learned frequencies; "hybrid", raw, Fourier and piecewise
    branches side by side, the encoder of the Large Payments Model."""

    n_bins: int = N_BINS
    """The bins of "ple". "learned_ple" and "hybrid" start with n_bins + 1 centres evenly spaced on [0, 1], which
    are the same intervals, and each of their branches is as wide as there are intervals, so 32 intervals keep 32
    directions. They still differ from "ple" in two ways, not one: their centres move, and their parametrization
    is another; learn_centres=False keeps the second and drops the first. No effect on "periodic"."""

    n_frequencies: int = N_FREQUENCIES
    """The learned frequencies of "periodic" and "hybrid"; no effect on the other two."""

    learn_centres: bool = True
    """"learned_ple" and "hybrid": True, the centres move in training; False, they stay where they start. The frozen
    arm differs from "ple" only in the parametrization and from the moving arm only in that its centres stay, so
    run beside both it says which of the two carried a gain. No effect on "ple" and "periodic"."""

    missing: str = "zero"
    """The value part of a missing number: "zero", a fixed zero, so that a missing number gives its field identity
    alone, as the tokenizer of the model in use does (it has no vector for a missing number); "learned", a learned
    vector per numeric field in its place, the field identity kept (the Large Payments Model keeps a field's
    identifier when its value is masked). A number counts as missing where it is not a finite number, or where the
    OPTIONAL batch entry "missing" says so. Whether the real numbers are ever missing is not known here."""

    stage1: str = "summary"
    """What makes the summary outputs of a transaction: "summary", stage 1 as today (summary tokens in front of the
    field inputs, through standard layers); "pooler", no stage 1 and ChannelPooler of latent_channels.py in its
    place: num_summary learned queries read every predictor token once, the attention pooler (Pool_in) of the
    Large Payments Model."""

    stage1_fields: str = "grouped"
    """What stage 1 reads besides its summary tokens: "grouped", the N_PRIORITY predictor tokens kept alone and the
    others averaged in N_GROUPS groups, as today; "all", every predictor token. No effect with the pooler, which
    reads every predictor token."""

    num_summary: int = NUM_SUMMARY
    """The summary tokens of stage 1, or the queries of the pooler: the number M of summary outputs per
    transaction, joined into one vector of M x d numbers or kept apart as M channels."""

    stage1_layers: int = STAGE1_LAYERS
    """The standard layers of stage 1 (pre-norm, GELU, a feed-forward layer four times as wide); no effect with the
    pooler."""

    stage1_heads: int = STAGE1_HEADS
    """The attention heads of every attention at the token width: stage 1, the pooler, PredictorBank, the re-reads
    and the re-read after stage 2. token_dim must be a multiple of it."""

    history: str = "joined"
    """What reads the history of the account: "joined", the summary outputs joined into one vector per row and
    standard causal layers over those vectors, as today; "channels", LatentChannelStage of latent_channels.py
    over the summary outputs kept apart as channels, which takes the place of the joining line, the position
    table, the history layers and the gap input."""

    history_layers: int = HISTORY_LAYERS
    """The layers of the joined history, or the pairs (num_pairs) of the channel stage: through-time blocks, each
    with a within-transaction block before it in the layout "interleaved"."""

    history_heads: int = HISTORY_HEADS
    """The attention heads of the history: of every layer of the joined history, of every block of the channel
    stage, and of the attention bias. The joined width (num_summary x d) or the channel width d must be a
    multiple of it."""

    history_len: int = HISTORY_LEN
    """The largest count of strictly earlier rows the position table tells apart; the table has history_len + 1
    entries, and rows with more earlier rows share the last one."""

    interleaved_reread: Optional[str] = None
    """Joined history only: the gated re-reads of interleaved_reread.py between the history layers, as in
    interleaved_wiring_template.py. None, off as today; "A", a re-read of the row's own fields after every layer;
    "M", one re-read after the last layer, with a memory of the REREAD_BACK latest earlier rows; "AM", a re-read
    after every layer, each with that memory. They read the bank."""

    last_reread: bool = True
    """Joined history only: the re-read of the row's own field outputs after the history layers that the model in
    use has (the field outputs of stage 1, or the predictor tokens when the pooler takes the place of stage 1).
    In the channel stage final_intra takes its place."""

    layout: str = "interleaved"
    """Channel stage: "interleaved", every pair a within-transaction block and then a through-time block (Eq. 8 of
    the Large Payments Model); "staged", every through-time block first and one within-transaction block at the
    end; "temporal_only", no within-transaction block."""

    channel_identity: bool = True
    """Channel stage: a learned vector per channel added at the start, so that shared through-time weights can
    tell the channels apart."""

    channel_projections: bool = False
    """Channel stage: a learned map per channel at the start, started as the identity."""

    share_temporal: bool = True
    """Channel stage: one through-time layer per pair serves every channel (True), or one per channel and pair."""

    intra_self_attention: bool = True
    """Channel stage: the channels of one transaction attend to one another in every within-transaction block."""

    intra_cross_attention: bool = True
    """Channel stage: the channels read the bank in every within-transaction block."""

    intra_order: str = "cross_first"
    """Channel stage: the order of the two attention parts inside every within-transaction block. "cross_first",
    the channels read the fields and then one another, the order Figure 4 of the Large Payments Model draws;
    "self_first", one another first, the order of the first version of latent_channels.py. The weights are made
    in the same order either way."""

    num_back: int = 0
    """Channel stage: the bank also holds the fields of the row's latest num_back eligible earlier rows (the memory
    of interleaved_reread.py); 0 keeps the row's own fields only."""

    memory_ties: str = "whole_seconds"
    """How a memory of earlier rows takes the rows of an earlier second, in the channel stage (num_back) and in the
    re-reads M and AM of the joined history: "whole_seconds", the latest earlier seconds, every row of a second or
    none while the total stays at or below the size of the memory, so that the order of the rows inside a second,
    which the time does not fix and the scorer may not have, moves no score; "slot", the rows taken by their
    slots, the rule the re-read trained on 24 November was trained with, kept only to reproduce that model."""

    final_intra: bool = False
    """Channel stage: one more within-transaction block after the last through-time block, so that the channels
    read the fields once more at the end, as the re-read after stage 2 does today."""

    readout: str = "concat"
    """Channel stage: how the final channels of a row become the vector the head reads: "concat", side by side with
    a layer norm (M x d numbers); "attention", a learned task query reads the channels (d numbers); "mean", their
    average (d numbers)."""

    bank: str = "predictor_bank"
    """What the reads of the fields read, built once per batch: "predictor", the predictor tokens as they are, one
    per predictor (the field embeddings the Large Payments Model reads); "predictor_bank", PredictorBank of
    interleaved_reread.py on them, every predictor token having read the output of stage 1 once (the bank of the
    re-read designs); "stage1", the field outputs of stage 1. The channel stage and the re-reads of the joined
    history read it; with neither it has no effect."""

    gap_encoder: str = "scalar"
    """How the time gap to the latest strictly earlier row enters, GapEncoder of time_encoders.py at the width of
    what it is added to: "scalar", a learned vector times log(1 + gap) plus a bias, as today; "ple", the soft log
    of the gap through fixed bins; "sinusoid", the sines and cosines of FraudTransformer."""

    gap_ticks_per_second: Optional[float] = None
    """"sinusoid" only: the unit the gap is counted in before its sines, the `ticks_per_second` of GapEncoder. None
    reads the paper's milliseconds (1,000 ticks a second), the paper-faithful arm; 1 counts whole seconds, which
    spreads the periods from 6.3 seconds to a year and more, the arm to run beside it."""

    calendar: bool = False
    """CalendarEncoder of time_encoders.py: the hour of the day and the day of the week as sines and cosines of
    their fixed periods, through two small linear layers, added to the row. Off, as today."""

    time_bias: bool = False
    """The time-gap part of AttentionBias (attention_bias.py, built without match fields): one learned number per
    head and time-gap bucket, and one per head for a row reading itself, added to the attention logits of every
    history layer or through-time block. The joined history builds it from the times of the batch; the channel
    stage builds it itself (LatentChannelStage(time_bias=True)) from the times of every call, with its own heads
    and unit. Off, as today."""

    dropout: float = DROPOUT
    """The dropout of every part: on the attention weights, the residual branches and the feed-forward layers."""

    head: str = "linear"
    """The head on the vector the history hands back: "linear", one linear layer to two logits, as today."""


TODAY = Config()
"""The model in use: 64 predictors as tokens of 48 (numbers through 16 fixed bins with a map and a bias per field,
codes through a table and a bias per field, a missing number giving its field identity alone); stage 1 of 2 layers
and 8 heads over 3 summary tokens, 4 predictors kept alone and 3 groups of the other 60; the 3 summary outputs
joined into 144 numbers; 4 causal history layers of 8 heads over up to 121 rows under the strict time rule, with a
position table by the count of strictly earlier rows and log(1 + gap) to the latest strictly earlier row as an
input; the re-read of the row's field outputs after the history; a head 144 -> 2. Every entry is at its default,
which is what keeps every other configuration honest: an entry left out is today's."""

WIDE_JOINED = replace(TODAY, token_dim=96, stage1_heads=4, history_heads=4)
"""Today's model at twice the token width: three summary outputs of 96 joined into 288, stage 1 with 4 heads of 24,
the history with 4 heads of 72, everything else as today.

It is the control for width: does a wider joined model give what the channels of CANDIDATE give? read: in
TransactionGPT a transaction width of 128 in place of 64 gave substantial gains, and squeezing a joined vector
through a small network was worse (arXiv 2511.08939, Sec. 6); width is the axis along which the Large Payments
Model grew its sequence model, +27.6, +49.1 and +55.7 percent fraud AP at widths 384, 768 and 1,024 (arXiv
2611.15814, Fig. 8). read: a head narrower than the sequence it reads cannot form every attention pattern (arXiv
2002.07028, Theorem 1); here 24 numbers over 10 tokens in stage 1. judgement: 4 heads of 72 in the history; the
token width of CANDIDATE, so that the two do not differ in the width of a token. They differ in what is handed to
the history and in what reads it, and in three encodings CANDIDATE adds that act on a joined history as well (32
bins, the gap in bins, the time bias): the head-to-head tests the candidate as a whole.
replace(WIDE_JOINED, n_bins=32, gap_encoder="ple", time_bias=True) takes those three from CANDIDATE too (4,538,158
weights). What still differs is the channel stage as a whole: six summary outputs kept apart against three joined,
and its reads of the 64 predictor tokens in every pair, of the fields of the 5 latest earlier rows and of the fields
once more at the end (final_intra), so a gain of CANDIDATE over that run may come from those reads. With
interleaved_reread="AM" and bank="predictor" as well (5,349,554 weights), the joined history also re-reads, after
every layer, the predictor tokens of the row and those of its REREAD_BACK latest earlier rows, which leaves the
outputs kept apart, and the shape of those reads, as the difference; with num_summary=6 too, it reads the same six
outputs at 576 wide (18,593,522 weights; 16,786,798 without the re-reads).
It has about four times the weights of TODAY, nearly all in the history layers, whose weights grow with the square
of their width."""

CANDIDATE = replace(TODAY, token_dim=96, n_bins=32, missing="zero", num_summary=6, stage1_heads=4, history="channels",
                    history_heads=4, layout="interleaved", intra_self_attention=True, intra_cross_attention=True,
                    intra_order="cross_first", share_temporal=True, channel_identity=True, channel_projections=False,
                    num_back=5, memory_ties="whole_seconds", final_intra=True, readout="concat", bank="predictor",
                    gap_encoder="ple", time_bias=True)
"""The candidate for the strongest model: tokens of 96, six summary outputs kept apart as channels of 96 through four
interleaved pairs that read the 64 predictor tokens and those of the 5 latest earlier rows, the gap encoded like a
number, a learned bias by time gap that the stage builds itself, and the six channels joined only at the end (576
numbers, also the export).

Every entry with its evidence (read: a source says it, with the source and the table or section; judgement: no
source does). The research run that read the sources is summed up in CONFIGURATIONS.md.

    token_dim 96            read: a head narrower than the sequence it reads cannot form every attention pattern
                            (arXiv 2002.07028, Theorem 1), and today a stage-1 head is 6 numbers over 10 tokens;
                            in the Large Payments Model the sequence model beat the single-transaction model on
                            fraud only once it was wide, +27.6 against +26.8 percent AP at width 384 and +49.1
                            against +36.0 at 768 (arXiv 2611.15814, Fig. 8); in TransactionGPT a width of 128 in place
                            of 64 gave substantial gains (arXiv 2511.08939, Sec. 6). judgement: 96 as a first
                            step, below every width those papers use
    n_bins 32               read: at millions of rows the numeric encoder moves results little (36.67 million
                            rows, an attention model: piecewise-linear 0.8108 AUC, linear 0.8088, periodic
                            0.8086; arXiv 2611.01090, Table 2), and the gain from more bins levels off at about
                            15 to 35 (arXiv 2604.05635, Sec. 5). judgement: 32 inside that range. There are no
                            trained edges at 32 bins, so the numbers are read on the [0, 1] scale of
                            UnitQuantileScaler fitted on training rows
    missing zero            judgement: whether the numbers of the model in use are ever missing is not known
                            here; "zero" is the tokenizer of today, a missing number giving its field identity
                            alone, and the learned vector is an arm of its own (MISSING_LEARNED). A learned vector
                            that no batch uses would get no gradient
    num_summary 6           read: the Large Payments Model sets its channels to about a fifth of the fields
                            (Sec. 5.1), about 13 for 64 predictors; at equal compute more and narrower latents
                            helped until they stopped (Perceiver IO, arXiv 2107.14795, Table 15: 128 of 1,920
                            wide 75.84, 256 of 1,280 80.95, 512 of 896 80.92). judgement: 6, between today's 3
                            and 13
    stage1_heads 4          read: arXiv 2002.07028 (Table 2: head sizes from 32 to 256 gave SQuAD F1 from 88.53
                            to 90.33, with more weights as well). judgement: 4 heads of 24 over 13 tokens
    stage1_fields grouped   judgement: every predictor reaches the channels through the bank in every pair, so
                            the grouped inputs are kept for the cost of stage 1; the paper keeps every field a
                            token (Sec. 3.3), and "all" is that arm (STAGE1_ALL)
    history channels        read: in TransactionGPT the best variant kept several virtual tokens per
                            transaction inside the history (+19.2 against +14.6 and +7.3 percent, Table 4); the
                            layout is Eq. 7 and 8 of the Large Payments Model. No study compares channels kept
                            apart with one joined vector at equal compute: WIDE_JOINED is that comparison
    layout interleaved,     read: the Large Payments Model interleaves and argues for it without a test (Sec.
    history_layers 4        3.3); reads of the input spread through depth gave 78.0 against 73.7 when all came
                            first (Perceiver, arXiv 2103.03206, Table 6); Latte's interleaved variant was best
                            (arXiv 2401.03048, Fig. 5f, a figure only). Against it: ViViT's staged encoder beat
                            its interleaved variant, 78.8 against 77.4 and 43.7 against 39.1 (arXiv 2103.15691,
                            Table 2), and its depth through time stopped mattering after 1 to 4 layers (Table
                            3). In this model the re-read after every history layer gained about 2 AP points
    history_heads 4         read: arXiv 2002.07028. judgement: 4 heads of 24, a multiple of 8, which the 16-bit
                            attention kernels of a GPU ask for
    bank predictor,         read: the channels of the Large Payments Model read the original field embeddings,
    num_back 5              the same in every block (Sec. 3.3). judgement: the memory of the fields of the 5
                            latest earlier rows goes beyond the paper; it is the memory of the re-read designs M
                            and AM of 23 November (INTERLEAVED_REREAD.md), kept on
    memory_ties             judgement: the memory takes the rows of an earlier second all or none, so that the
    whole_seconds           order of the rows inside a second, which the time does not fix and the scorer may not
                            have, moves no score beyond rounding (the order check of run_checks holds it there);
                            "slot" reproduces the re-read of 24 November and is an arm (MEMORY_SLOT)
    intra_self_attention    read: the Large Payments Model has it (Sec. 3.3); with few channels, mixing them
                            gained little in forecasting (iTransformer, arXiv 2310.06625, Table 3). judgement:
                            on, and tested off
    intra_order             read: Figure 4 of the Large Payments Model draws the read of the fields before the
    cross_first             channels read one another (its text fixes no order); the order of the first version
                            of latent_channels.py is an arm (INTRA_SELF_FIRST)
    share_temporal          read: channels kept apart with shared weights beat mixing them (PatchTST, arXiv
                            2211.14730, Table 7: Traffic 0.367 against 0.595 MSE), and shared weights curbed
                            overfitting (Perceiver, Table 7: 78.0 against 72.9); the paper writes one
                            CausalInter per layer with no channel index (Eq. 8), which reads as shared weights
    channel_identity on     judgement: shared weights cannot tell the channels apart without it; the paper does
                            not say
    channel_projections off read: a projection per row type raised F1 from 0.526 to 0.536 (UniTTab, arXiv
                            2302.06375, Table 11). judgement: off, an arm of its own
    final_intra on          judgement: this model gained from its re-read of the fields after the history
                            layers, and in the layout "interleaved" nothing else lets the last through-time
                            block meet the fields again; it takes the place of that re-read, and only one of the
                            two is kept. The paper ends with a through-time block (Eq. 8), and CANDIDATE_LPM keeps
                            that order
    readout concat          judgement: six channels side by side lose nothing. read: an attention decoder beat
                            averaging and projecting by 0.4 to 5.1 points (Perceiver IO, Table 7), but joining
                            side by side was not among its baselines
    gap_encoder ple         read: in FraudTransformer the sines of the time between events, added to learned
                            positions, raised PR-AUC from 0.94689 to 0.95816, and absolute time gave 0.94713
                            (arXiv 2509.23712, Table 4); the soft log 8 ln(1 + t / 8) is PRAGMA's (arXiv
                            2604.08649, Sec. 2.2). judgement: the gap encoded like the other numbers first; the
                            sines as the paper runs them (GAP_SINUSOID) and counted in seconds
                            (GAP_SINUSOID_SECONDS) are arms
    time_bias on            read: removing the relative position and time bias of HSTU cost 0.0043 in
                            normalised entropy, where 0.001 counts as significant (arXiv 2402.17152, Table 5).
                            The stage builds the bias itself from the times of every call, with its own heads
                            and unit, so no bias can come from another batch or another unit
    calendar off            judgement: whether the hour and the weekday are among the 64 predictors of the model
                            in use is not known here; an arm of its own (CALENDAR)
    as today                the position table by the count of earlier rows (read: FraudTransformer, Table 4,
                            learned positions 0.94689 against 0.92038 without), stage 1 of two layers, the
                            dropout and the linear head
"""

CANDIDATE_LPM = replace(CANDIDATE, stage1="pooler", numeric_encoder="hybrid", final_intra=False, readout="attention")
"""The candidate in the form closest to the Large Payments Model (arXiv 2611.15814); four entries differ from it.

    stage1 pooler           read: an attention pooler compresses each transaction into M latent channels, Pool_in
                            of Eq. 7 (Sec. 3.3), after the compact latents of Perceiver. judgement: the form of
                            its queries is not given; learned queries over every predictor token are the reading
                            of ChannelPooler
    numeric_encoder hybrid  read: raw, Fourier and piecewise-linear branches joined and projected per field (Sec.
                            3.1, Eq. 2 and 3); the paper reports no ablation of it, and at millions of rows the
                            encoders differ little (CANDIDATE). judgement: its 33 centres start evenly spaced on
                            [0, 1], which are the quantiles of a field without ties on the scale of
                            UnitQuantileScaler (fit_centres gives a field with heaps its distinct quantiles); each
                            of its three branches is 32 wide, so its 32 intervals keep the 32 directions of 32
                            fixed bins; its 16 frequencies start log-spaced (numeric_encoders.py). Its centres
                            learn, at CENTRE_LR_FACTOR of the rate in param_groups
    final_intra off         read: every pair ends with its through-time block, then Pool_out (Eq. 8)
    readout attention       read: the output pooler gives a generic vector and one per task at every step (Sec.
                            3.3). judgement: its mechanism is not given; a learned task query over the channels
                            is the reading of latent_channels.py. The exported vector is then 96 wide

What it keeps from CANDIDATE goes beyond the paper, which describes no position, time-gap or calendar encoding for
its sequence model (Sec. 3.3) and reads the row's own fields only: the position table, the gap encoder, the time
bias, the memory of 5 earlier rows and the channel identity. judgement: they are kept, so that the four entries
above are what this arm tests against CANDIDATE. Inside a within-transaction block the channels read the fields
and then one another, the order Figure 4 of the paper draws (intra_order "cross_first", as in CANDIDATE).
"""

# The four named configurations, in the order main and compare list them.
CONFIGURATIONS = {"TODAY": TODAY, "WIDE_JOINED": WIDE_JOINED, "CANDIDATE": CANDIDATE, "CANDIDATE_LPM": CANDIDATE_LPM}


# ----------------------------------------------------------------------------------------------
# the arms: every configuration that is run, the arm it is set against, and the question
# ----------------------------------------------------------------------------------------------

@dataclass(frozen=True)
class Arm:
    """One arm of the runs: a configuration, the arm it is compared with, and the question that comparison answers.

    config     the Config the arm builds
    against    the name of the arm in ARMS it is compared with; None for TODAY, the control of every arm
    question   one sentence: what the comparison with `against` answers
    """

    config: Config
    against: Optional[str]
    question: str


def _arms():
    """ARMS in the order of the runs: the four named configurations, then every arm that changes one entry."""
    arms = {
        "TODAY": Arm(TODAY, None, "What does the model in use give at this scale, and how far apart do its seeds lie, "
                                  "the spread every other arm is read against?"),
        "WIDE_JOINED": Arm(WIDE_JOINED, "TODAY", "Do tokens twice as wide, with the summary outputs still joined (288 "
                                                 "numbers into the history), beat the model in use?"),
        "CANDIDATE": Arm(CANDIDATE, "WIDE_JOINED", "Does the candidate as a whole (six channels of 96 kept apart "
                                                   "through four interleaved pairs, with 32 bins, the gap in bins and "
                                                   "the time bias) beat the joined model of the same token width, by "
                                                   "enough to pay for its cost?"),
        "CANDIDATE_LPM": Arm(CANDIDATE_LPM, "CANDIDATE", "Does the form closest to the Large Payments Model (a pooler "
                                                         "in place of stage 1, its numeric encoder, no last read of "
                                                         "the fields, its attention readout) beat the candidate?"),
    }

    def one(name, against, question, **change):
        """An arm that differs from the arm `against` in the entries of `change`, one entry in every arm here."""
        arms[name] = Arm(replace(arms[against].config, **change), against, question)

    # The tokens and the numbers. ple with 32 bins is CANDIDATE itself, and the gap in bins is CANDIDATE's gap.
    one("WIDTH_48", "CANDIDATE", "With the channels kept apart, does the candidate need tokens wider than today's 48?",
        token_dim=48)
    one("WIDTH_144", "CANDIDATE", "Do tokens of 144 gain over 96 in the candidate?", token_dim=144)
    one("NUMBERS_PLE16", "CANDIDATE", "Does the candidate lose anything with today's 16 bins in place of 32?",
        n_bins=16)
    one("NUMBERS_LEARNED_PLE", "CANDIDATE", "Do 33 learned centres (32 intervals, a branch of 32) beat 32 fixed "
                                            "bins?", numeric_encoder="learned_ple")
    one("NUMBERS_FROZEN_CENTRES", "NUMBERS_LEARNED_PLE", "Held where they start, do the centres of learned_ple keep "
                                                         "its gain over ple, which would put that gain on its "
                                                         "parametrization and not on moving centres?",
        learn_centres=False)
    one("NUMBERS_PERIODIC", "CANDIDATE", "Do the value and the sines and cosines of 16 learned frequencies beat 32 "
                                         "fixed bins?", numeric_encoder="periodic")
    one("NUMBERS_HYBRID", "CANDIDATE", "Does the numeric encoder of the Large Payments Model (raw, Fourier and "
                                       "piecewise branches side by side) beat 32 fixed bins?",
        numeric_encoder="hybrid")
    one("MISSING_LEARNED", "CANDIDATE", "Does a learned vector for a missing number beat the field identity alone, "
                                        "a question only when the real numbers are ever missing?", missing="learned")
    # Stage 1.
    one("STAGE1_ALL", "CANDIDATE", "Does stage 1 gain from reading all 64 predictor tokens instead of 4 kept alone "
                                   "and 3 averaged groups?", stage1_fields="all")
    one("STAGE1_POOLER", "CANDIDATE", "Does a pooler of six learned queries over the 64 predictor tokens, in place "
                                      "of stage 1, do as well at less cost?", stage1="pooler")
    one("STAGE1_LAYERS_3", "CANDIDATE", "Does a third layer in stage 1 gain?", stage1_layers=3)
    one("STAGE1_HEADS_8", "CANDIDATE", "Do eight heads of 12 in stage 1 beat four of 24?", stage1_heads=8)
    # The channels and the history.
    one("CHANNELS_3", "CANDIDATE", "Are three channels, today's number of summary outputs, enough once they are kept "
                                   "apart?", num_summary=3)
    one("CHANNELS_12", "CANDIDATE", "Do twelve channels, near the fifth of the fields the Large Payments Model uses, "
                                    "gain over six?", num_summary=12)
    one("PAIRS_6", "CANDIDATE", "Do six interleaved pairs gain over four?", history_layers=6)
    one("HISTORY_HEADS_3", "CANDIDATE", "Do three heads of 32 in the stage beat four of 24?", history_heads=3)
    one("LAYOUT_STAGED", "CANDIDATE", "Does reading the fields only after the through-time blocks (the staged order of "
                                      "ViViT) do as well as reading them between them?", layout="staged")
    one("LAYOUT_TEMPORAL_ONLY", "CANDIDATE", "With final_intra kept, so that the fields are read once at the end, do "
                                             "the within-transaction blocks between the through-time blocks earn "
                                             "their cost?", layout="temporal_only")
    one("MEMORY_0", "CANDIDATE", "Does the memory of the fields of the 5 latest earlier rows gain over the row's own "
                                 "fields alone?", num_back=0)
    one("MEMORY_10", "CANDIDATE", "Does a memory of 10 earlier rows gain over 5?", num_back=10)
    one("MEMORY_SLOT", "CANDIDATE", "Does taking the rows of an earlier second by their slots, the rule of the "
                                    "re-read of 24 November that the order inside a second can move, score "
                                    "otherwise than taking whole seconds?", memory_ties="slot")
    one("BANK_PREDICTOR_BANK", "CANDIDATE", "Do predictor tokens that have read stage 1 once (PredictorBank) make a "
                                            "better bank than the predictor tokens as they are?",
        bank="predictor_bank")
    one("INTRA_SELF_OFF", "CANDIDATE", "Do the channels of a transaction gain from reading one another?",
        intra_self_attention=False)
    one("INTRA_CROSS_OFF", "CANDIDATE", "Does reading the fields and the memory in every pair gain over channels "
                                        "that never read them again after stage 1?", intra_cross_attention=False)
    one("INTRA_SELF_FIRST", "CANDIDATE", "Does it matter that the channels read one another before the fields, the "
                                         "order of the first version, rather than after them?",
        intra_order="self_first")
    one("SHARE_TEMPORAL_OFF", "CANDIDATE", "Does a through-time layer per channel beat one layer shared by every "
                                           "channel?", share_temporal=False)
    one("CHANNEL_IDENTITY_OFF", "CANDIDATE", "Do the shared through-time layers need a learned vector that tells the "
                                             "channels apart?", channel_identity=False)
    one("CHANNEL_PROJECTIONS_ON", "CANDIDATE", "Does a learned map per channel at the start of the stage gain?",
        channel_projections=True)
    one("FINAL_INTRA_OFF", "CANDIDATE", "Does the last read of the fields after the last through-time block gain, "
                                        "as the re-read after stage 2 gained today?", final_intra=False)
    one("READOUT_ATTENTION", "CANDIDATE", "Does a learned task query over the six channels (96 numbers to the head) "
                                          "do as well as the channels side by side (576)?", readout="attention")
    one("READOUT_MEAN", "CANDIDATE", "Does the plain average of the six channels do as well as the channels side by "
                                     "side?", readout="mean")
    # The time inputs.
    one("GAP_SCALAR", "CANDIDATE", "Does the gap through bins on its soft log beat today's single number "
                                   "log(1 + gap)?", gap_encoder="scalar")
    one("GAP_SINUSOID", "CANDIDATE", "Do the sines of FraudTransformer as the paper runs them (milliseconds, base "
                                     "1e7) beat the gap in bins?", gap_encoder="sinusoid")
    one("GAP_SINUSOID_SECONDS", "GAP_SINUSOID", "Do the same sines counted in whole seconds (periods of 6.3 seconds "
                                                "to a year) beat the paper's milliseconds on gaps of seconds to "
                                                "months?", gap_ticks_per_second=1.0)
    one("TIME_BIAS_OFF", "CANDIDATE", "Does the learned bias by time gap on every through-time block gain?",
        time_bias=False)
    one("CALENDAR", "CANDIDATE", "Do the hour of the day and the day of the week as sines and cosines add anything, a "
                                 "question only when they are not among the 64 predictors?", calendar=True)
    return arms


ARMS = _arms()
"""Every arm, by name, in the order of the runs: Arm(config, against, question).

The four named configurations come first (TODAY, then WIDE_JOINED against it, CANDIDATE against WIDE_JOINED, which
is the head-to-head, and CANDIDATE_LPM against CANDIDATE). Every other arm changes one entry of the arm it is set
against, CANDIDATE in most of them, so that the comparison answers its question and nothing else: 32 bins, the gap
in bins and a memory of 5 are CANDIDATE itself. NUMBERS_FROZEN_CENTRES is set against NUMBERS_LEARNED_PLE and read
beside CANDIDATE too, and GAP_SINUSOID_SECONDS against GAP_SINUSOID. The re-read designs of the joined history
(interleaved_reread "A", "M", "AM") are arms of the sweep of their own (package only); memory_ties="slot" with
"M" or "AM" builds the re-read of 24 November. arm_table prints every arm with its change and its weights, and
compare takes any of the names.
"""


def arm_change(name):
    """The entries in which arm `name` differs from the arm it is set against, as "entry: old -> new" in one line."""
    arm = ARMS[name]
    if arm.against is None:
        return "the model in use"
    base = ARMS[arm.against].config
    changed = [f"{entry.name}: {_shown(entry.name, getattr(base, entry.name))} -> "
               f"{_shown(entry.name, getattr(arm.config, entry.name))}"
               for entry in dataclasses.fields(Config) if getattr(base, entry.name) != getattr(arm.config, entry.name)]
    return ", ".join(changed)


def _shown(name, value):
    """An entry's value as `describe` and the table of arms print it; None reads as what it stands for."""
    if value is None and name == "gap_ticks_per_second":
        return f"paper ({SINUSOID_TICKS_PER_SECOND:,} a second)"
    return "off" if value is None else value


def reads_bank(config):
    """True when something in `config` reads the bank: the within-transaction blocks of the channel stage, or the
    re-reads of the joined history."""
    if config.history == "joined":
        return config.interleaved_reread is not None
    # The channel stage reads it in its within-transaction blocks; "temporal_only" has none unless final_intra adds one.
    return bool(config.intra_cross_attention) and (config.layout != "temporal_only" or bool(config.final_intra))


def reads_memory(config):
    """True when a memory of earlier rows is read in `config`: the re-reads M and AM of the joined history, or the
    bank of the channel stage with num_back above zero. memory_ties has an effect only then."""
    if config.history == "joined":
        return config.interleaved_reread is not None and REREAD_DESIGNS[config.interleaved_reread][1] > 0
    return reads_bank(config) and int(config.num_back) > 0


def bank_fields(config):
    """The number F of field tokens per row in the bank of `config`."""
    if config.bank == "stage1" and config.stage1_fields == "grouped":
        # The field outputs of stage 1 are as many as its field inputs: the predictors kept alone and the groups.
        return N_PRIORITY + N_GROUPS
    return N_PREDICTORS


def check_config(config):
    """A plain error for an entry whose value cannot be built, saying what to change; nothing else is checked.

    An entry that has no effect in the configuration is not an error: `inactive` lists it.
    """
    allowed = {"numeric_encoder": NUMERIC_ENCODERS, "missing": MISSING_KINDS, "stage1": STAGE1_KINDS,
               "stage1_fields": STAGE1_FIELDS, "history": HISTORIES, "interleaved_reread": REREADS,
               "layout": LAYOUTS, "intra_order": INTRA_ORDERS, "memory_ties": TIES, "readout": READOUTS,
               "bank": BANKS, "gap_encoder": GAP_ENCODERS, "head": HEAD_KINDS}
    for name, values in allowed.items():
        value = getattr(config, name)
        if value not in values:
            raise ValueError(f"{name} must be one of {values}; got {value!r}")
    # Sizes that count something must count at least one; num_back may be 0, which keeps the row's own fields only.
    for name in ("token_dim", "n_bins", "n_frequencies", "num_summary", "stage1_layers", "stage1_heads",
                 "history_layers", "history_heads", "history_len"):
        if int(getattr(config, name)) < 1:
            raise ValueError(f"{name} must be 1 or more; got {getattr(config, name)}")
    if int(config.num_back) < 0:
        raise ValueError(f"num_back counts earlier rows and cannot be negative; got {config.num_back}")
    if config.gap_ticks_per_second is not None and not float(config.gap_ticks_per_second) > 0:
        raise ValueError(f"gap_ticks_per_second counts ticks in one second and must be above zero (1 for seconds, "
                         f"1000 for milliseconds), or None for the paper's milliseconds; got "
                         f"{config.gap_ticks_per_second}")
    d = config.token_dim
    if d % config.stage1_heads:
        raise ValueError(f"token_dim ({d}) must be a multiple of stage1_heads ({config.stage1_heads}), which every "
                         f"attention at the token width uses; change one of the two")
    width = config.num_summary * d if config.history == "joined" else d
    if width % config.history_heads:
        what = "the joined width num_summary x token_dim" if config.history == "joined" else "token_dim"
        raise ValueError(f"{what} ({width}) must be a multiple of history_heads ({config.history_heads}); change "
                         f"one of them")
    if config.bank == "stage1" and config.stage1 == "pooler" and reads_bank(config):
        raise ValueError("bank 'stage1' reads the field outputs of stage 1, and the pooler leaves no stage 1; use "
                         "bank 'predictor' or 'predictor_bank' with the pooler, or stage1 'summary'")


def inactive(config):
    """The entries that have no effect in `config`, each with the reason, as {entry: reason}."""
    notes = {}
    if config.history == "joined":
        for name in CHANNEL_ENTRIES:
            notes[name] = "the joined history has no channel stage"
    else:
        notes["interleaved_reread"] = "the channel stage reads the fields in its own within-transaction blocks"
        notes["last_reread"] = "the channel stage ends with its readout; final_intra is its last read of the fields"
        # The within-transaction blocks of the stage: those of the layout and the one final_intra adds.
        n_within = {"interleaved": config.history_layers, "staged": 1, "temporal_only": 0}[config.layout]
        if n_within + int(bool(config.final_intra)) == 0:
            for name in ("intra_self_attention", "intra_cross_attention", "intra_order", "num_back"):
                notes[name] = "the layout has no within-transaction block and final_intra is off"
        else:
            if not config.intra_cross_attention:
                notes["num_back"] = "nothing reads the fields: intra_cross_attention is off"
            if not (config.intra_self_attention and config.intra_cross_attention):
                # With one attention part, or none, a block has no order of parts to change.
                notes["intra_order"] = "a within-transaction block has one attention part or none"
    if not reads_memory(config):
        # Said so that a run with these settings is not listed as a test of the rule for rows of one second.
        notes["memory_ties"] = ("no memory of earlier rows is read (num_back 0, nothing reading the fields, or a "
                                "joined history without the re-read M or AM)")
    if not reads_bank(config):
        notes["bank"] = "nothing reads the bank in this configuration"
    if config.stage1 == "pooler":
        notes["stage1_layers"] = "the pooler takes the place of stage 1"
        notes["stage1_fields"] = "the pooler reads every predictor token"
    if config.numeric_encoder in ("ple", "learned_ple"):
        notes["n_frequencies"] = "only periodic and hybrid have frequencies"
    if config.numeric_encoder in ("ple", "periodic"):
        notes["learn_centres"] = "only learned_ple and hybrid have learned centres"
    if config.numeric_encoder == "periodic":
        notes["n_bins"] = "periodic has neither bins nor centres"
    if config.gap_encoder != "sinusoid":
        notes["gap_ticks_per_second"] = "only the sinusoid counts the gap in ticks"
    return notes


# ----------------------------------------------------------------------------------------------
# the parts the model in use has, as small stand-ins
# ----------------------------------------------------------------------------------------------

def _stack(width, heads, layers, dropout):
    """Standard pre-norm transformer layers with GELU, as both stages of the model in use are built (W6, W10)."""
    layer = nn.TransformerEncoderLayer(d_model=width, nhead=heads, dim_feedforward=4 * width, dropout=dropout,
                                       activation="gelu", batch_first=True, norm_first=True)
    # The nested-tensor shortcut pays only for padding masks, which no stage here passes.
    return nn.TransformerEncoder(layer, num_layers=layers, enable_nested_tensor=False)


def run_layer(layer, x, mask):
    """One standard layer with `mask` ADDED to its attention logits, in training and in scoring alike.

    layer   an nn.TransformerEncoderLayer built with norm_first=True and batch_first=True
    x       float [B, T, W]
    mask    float [B, heads or 1, T, T]: minus infinity where row i may not read row j, the bias where it may

    Returns float [B, T, W], the arithmetic of layer(x, src_mask=...) on its ordinary route. In scoring the
    layer's own quick route reads a float mask as yes or no (every entry that is not zero hides its key), so a
    learned bias would hide keys there instead of weighting them; this is the route of `run_blocks` in
    _shared.py (package only), which history_stage.py (package only) takes for the same reason.
    """
    B, T, W = x.shape
    attention = layer.self_attn
    H = attention.num_heads
    # One linear layer gives query, key and value side by side, in the order nn.MultiheadAttention packs them.
    qkv = F.linear(layer.norm1(x), attention.in_proj_weight, attention.in_proj_bias)
    q, k, v = qkv.view(B, T, 3, H, W // H).permute(2, 0, 3, 1, 4).unbind(0)
    # Dropout on the attention weights only in training, as the layer itself does it.
    drop = attention.dropout if layer.training else 0.0
    read = F.scaled_dot_product_attention(q, k, v, attn_mask=mask.to(q.dtype), dropout_p=drop)
    x = x + layer.dropout1(attention.out_proj(read.transpose(1, 2).reshape(B, T, W)))
    # The second half works on every row by itself: the feed-forward layer of the standard layer.
    return x + layer.dropout2(layer.linear2(layer.dropout(layer.activation(layer.linear1(layer.norm2(x))))))


def _grouped(tokens):
    """The field inputs of stage 1 as the model in use makes them (W18): [N, P, d] -> [N, N_PRIORITY + N_GROUPS, d].

    The first N_PRIORITY predictor tokens are kept alone and the others averaged in N_GROUPS groups of
    consecutive predictors. After this step the single predictors of a group can no longer be told apart.
    """
    n_rest = tokens.shape[1] - N_PRIORITY
    if n_rest % N_GROUPS:
        raise ValueError(f"the {n_rest} predictors after the {N_PRIORITY} kept alone do not split into {N_GROUPS} "
                         f"equal groups; change N_PRIORITY or N_GROUPS to the grouping of the model in use")
    rest = tokens[:, N_PRIORITY:].reshape(tokens.shape[0], N_GROUPS, n_rest // N_GROUPS, tokens.shape[-1])
    return torch.cat([tokens[:, :N_PRIORITY], rest.mean(dim=2)], dim=1)


class LastReread(nn.Module):
    """The re-read the model in use has after stage 2: the row reads its own field outputs once (PLACEHOLDER W22).

    width       width W of the history vector; a multiple of field_dim
    field_dim   width d of a field output
    num_heads   attention heads; field_dim must be a multiple of it
    dropout     dropout on the attention weights

    The vector is cut into W / d segments, every segment asks the row's field outputs, and what the segments
    find goes back into the vector through a linear layer. It is the stand-in of interleaved_wiring_template.py
    at any width. No other row is read.
    """

    def __init__(self, width, field_dim, num_heads, dropout):
        super().__init__()
        self.width, self.field_dim = int(width), int(field_dim)
        self.norm_query, self.norm_fields = nn.LayerNorm(self.field_dim), nn.LayerNorm(self.field_dim)
        self.attend = nn.MultiheadAttention(self.field_dim, num_heads, dropout=dropout, batch_first=True)
        self.write_back = nn.Linear(self.width, self.width)

    def forward(self, history, fields):
        """history [B, T, W] and fields [B, T, F, d] to [B, T, W]."""
        lead = history.shape[:-1]
        # The history vector is the summary outputs side by side, so it is cut, not projected, into segments.
        segments = history.reshape(-1, self.width // self.field_dim, self.field_dim)
        own = self.norm_fields(fields.reshape(-1, fields.shape[-2], self.field_dim))
        read, _ = self.attend(self.norm_query(segments), own, own, need_weights=False)
        return history + self.write_back((segments + read).reshape(*lead, self.width))


# ----------------------------------------------------------------------------------------------
# the model
# ----------------------------------------------------------------------------------------------

class BestModel(nn.Module):
    """A small two-stage model shaped like the model in use, with every entry of `config` switched as it says.

    config   a Config; None builds TODAY

    forward(batch) takes a dict with
        continuous    float [B, T, N_NUMERIC]: the numbers, on the [0, 1] scale of UnitQuantileScaler; a value
                      that is not a finite number counts as missing, and so does every number of a padded slot.
                      In training, numbers that lie mostly outside [0, 1] stop a training step with a plain error
                      while the encoder still looks at the scale of its first training batches (NumericEncoder)
        categorical   int64 [B, T, N_CODES]: one code per code field, below CODE_SIZE
        mask          bool [B, T], True on real rows
        time_seq      int64 [B, T], in the unit of TIME_UNITS_PER_SECOND
        missing       OPTIONAL, bool [B, T, N_NUMERIC]: True where a number is missing (PLACEHOLDER W24)
    and returns two logits for every row, [B, T, 2]: every real row predicts its own label (all-position).
    export(batch) returns the vector the head reads, [B, T, out_dim], and forward is the head on it.
    hand_off(summary) takes the summary outputs of stage 1 to the history, as export does.

    `out_dim` is num_summary x token_dim for the joined history and the readout width of the channel stage
    otherwise; `config` is the configuration the model was built from. A row's logits depend on the row itself
    and on the real rows of its sequence in strictly earlier whole seconds only, which the checks test.
    """

    def __init__(self, config=None):
        super().__init__()
        c = self.config = TODAY if config is None else config
        check_config(c)
        d, M = c.token_dim, c.num_summary
        # The unit is fixed when the model is built and handed to every piece that reads the times, so that the mask,
        # the gap, the calendar, the bias and the memory always read one unit (PLACEHOLDER W5). The rule of masks.py
        # keeps a whole number as an integer, which divides nanosecond times exactly in every piece.
        self.units_per_second = _unit(TIME_UNITS_PER_SECOND)
        self.reads_bank = reads_bank(c)
        n_bank = bank_fields(c)

        # The constructor builds the parts in the order of the forward pass, except the parts that start as no-ops,
        # which come last; each block names the edit it belongs to.
        # >>> EDIT 1 of 7 (constructor): the numeric encoder of the configuration, and the code tables.
        # n_centres is one more than the bins, so that learned centres start at the same intervals as the fixed bins;
        # missing "zero" is the tokenizer of today, which has no vector for a missing number. unscaled="raise" makes
        # the look of the encoder at its first training batches stop with a plain error when more than half the
        # numbers of a field lie outside [0, 1], numbers that skipped the scaler, where the default only warns. It acts
        # only in an encoder that reads the [0, 1] scale, which every kind here does: no edges or centres are given.
        self.numbers = NumericEncoder(N_NUMERIC, d, kind=c.numeric_encoder, n_bins=c.n_bins, n_centres=c.n_bins + 1,
                                      n_frequencies=c.n_frequencies, learn_centres=c.learn_centres, missing=c.missing,
                                      unscaled="raise")
        # A table per code field and a bias per field, as the model in use has them (PLACEHOLDER W17).
        self.code_tables = nn.ModuleList([nn.Embedding(CODE_SIZE, d) for _ in range(N_CODES)])
        self.code_bias = nn.Parameter(torch.zeros(N_CODES, d))
        # <<< end of EDIT 1

        # >>> EDIT 2 of 7 (constructor): stage 1 with its summary tokens, or the pooler in its place.
        self.summary = self.stage1 = self.pooler = None
        if c.stage1 == "summary":
            # The summary tokens are learned vectors, each from its own small random start (PLACEHOLDER W19).
            self.summary = nn.Parameter(torch.randn(1, M, d) * 0.02)
            self.stage1 = _stack(d, c.stage1_heads, c.stage1_layers, c.dropout)
        else:
            self.pooler = ChannelPooler(channel_dim=d, num_channels=M, num_heads=c.stage1_heads, dropout=c.dropout)
        # <<< end of EDIT 2

        # >>> EDIT 6 of 7 (constructor): the history at the width of what is handed to it (edit 3 decides that width).
        self.position = self.history_layers = self.last_reread = self.stage = None
        if c.history == "joined":
            width = M * d
            # The position of a row is the count of its strictly earlier rows (PLACEHOLDER W20).
            self.position = nn.Embedding(c.history_len + 1, width)
            self.history_layers = _stack(width, c.history_heads, c.history_layers, c.dropout)
            if c.last_reread:
                self.last_reread = LastReread(width, d, c.stage1_heads, c.dropout)
            self.out_dim = width
        else:
            # The stage holds its own position table, takes the gap as `row_extra` and, with time_bias, builds the
            # time-gap bias itself from the times of every call; its unit is the model's.
            width = d
            self.stage = LatentChannelStage(channel_dim=d, num_channels=M, num_heads=c.history_heads,
                                            num_pairs=c.history_layers, layout=c.layout,
                                            channel_identity=c.channel_identity,
                                            channel_projections=c.channel_projections, share_temporal=c.share_temporal,
                                            intra_self_attention=c.intra_self_attention,
                                            intra_cross_attention=c.intra_cross_attention, num_back=c.num_back,
                                            num_fields=n_bank, readout=c.readout, history_len=c.history_len,
                                            dropout=c.dropout, units_per_second=self.units_per_second,
                                            final_intra=c.final_intra, ties=c.memory_ties, time_bias=c.time_bias,
                                            intra_order=c.intra_order)
            self.out_dim = self.stage.out_dim
        # <<< end of EDIT 6

        # >>> EDIT 5 of 7 (constructor): the gap at the width of what it is added to (PLACEHOLDER W21). The sinusoid
        # counts the gap in the ticks of the configuration; None is the paper's milliseconds.
        self.gap = GapEncoder(width, kind=c.gap_encoder, ticks_per_second=c.gap_ticks_per_second)
        # <<< end of EDIT 5 (the bias and the calendar start as no-ops and are made last, below)

        # >>> EDIT 7 of 7 (constructor): the head at the width of the vector it reads (PLACEHOLDER W23).
        self.head = nn.Linear(self.out_dim, 2)
        # <<< end of EDIT 7

        # The parts below start as no-ops or feed only such parts, so they are made after every other weight: a model
        # built with the same seed then has the same other weights with them on or off, and scores as the model
        # without them until training moves them (the re-reads write back through zero, the calendar's second layer
        # starts at zero, the bias starts at zero). The bank of the channel stage is made here too: it works from the
        # first step, and its place in the order changes nothing else.
        # >>> EDIT 4 of 7 (constructor): PredictorBank, when the bank is made from the predictor tokens.
        self.predictor_bank = None
        if self.reads_bank and c.bank == "predictor_bank":
            self.predictor_bank = PredictorBank(field_dim=d, num_heads=c.stage1_heads, dropout=c.dropout)
        # <<< end of EDIT 4
        # >>> EDIT 6 of 7 (constructor, the joined history): the re-reads between the history layers, built as edit 1
        # of INTERLEAVED_REREAD.md, with the rule of the memory for the rows of an earlier second
        # (PLACEHOLDER W13: the design).
        self.interleaved = None
        if c.history == "joined" and c.interleaved_reread is not None:
            every, back = REREAD_DESIGNS[c.interleaved_reread]
            self.interleaved = InterleavedReread(width=width, history_layers=c.history_layers,
                                                 after_layers=None if every else (c.history_layers,), field_dim=d,
                                                 num_heads=c.stage1_heads, num_back=back, dropout=c.dropout,
                                                 units_per_second=self.units_per_second, num_fields=n_bank,
                                                 ties=c.memory_ties)
        # <<< end of EDIT 6
        # >>> EDIT 5 of 7 (constructor): the time-gap part of the attention bias of the joined history, with no match
        # field, the heads of the history and the unit of the model (the channel stage holds its own); and the
        # calendar at the width of the gap.
        self.time_bias = None
        if c.time_bias and c.history == "joined":
            self.time_bias = AttentionBias(num_fields=0, num_heads=c.history_heads,
                                           units_per_second=self.units_per_second)
        self.calendar = CalendarEncoder(width, units_per_second=self.units_per_second) if c.calendar else None
        # <<< end of EDIT 5

    def export(self, batch):
        """The vector the head reads for every row, [B, T, out_dim]: the exported sequence embedding.

        It is worked out in the mode the model is in; an export for another model is made in evaluation mode
        and under torch.no_grad(), as scoring is. The vector of a padded slot means nothing.
        """
        c = self.config
        # PLACEHOLDER W4: the mask of real rows; here True means a real row. A model whose mask says True on padding
        # hands `~mask` to every new piece.
        valid = batch["mask"].bool()
        # PLACEHOLDER W3: the times of the rows, [B, T], the tensor the mask of stage 2 is built from.
        times = batch["time_seq"]
        B, T = valid.shape
        d, M = c.token_dim, c.num_summary

        # >>> EDIT 1 of 7: the tokenizer. The numbers go through the numeric encoder of the configuration, the codes
        # through their tables. PLACEHOLDER W16: the numbers of the batch, [B, T, N_NUMERIC]; OPTIONAL W24: the
        # is-missing mark, which the encoder adds to the values that are not a finite number.
        continuous = batch["continuous"]
        # The numbers of a padded slot count as missing (W4), so that whatever the slot holds reaches no weight of
        # the encoder, and its look at the first training batches judges the numbers of real rows only: padding
        # that holds zeros would hide unscaled numbers from it, and padding that holds anything else would stop it.
        absent = (~valid).unsqueeze(-1).expand_as(continuous)
        if batch.get("missing") is not None:
            absent = absent | batch["missing"].bool()
        numbers = self.numbers(continuous, missing=absent)                                 # [B, T, N_NUMERIC, d]
        # PLACEHOLDER W17: the codes of the batch, [B, T, N_CODES].
        categorical = batch["categorical"]
        codes = torch.stack([table(categorical[..., k]) for k, table in enumerate(self.code_tables)], dim=-2)
        # PLACEHOLDER W1: the predictor tokens as the tokenizer returns them, before they are grouped: [B, T, 64, d].
        # The bias per code field takes the number type of the tables, so that mixed precision stays mixed.
        predictor_tokens = torch.cat([numbers, codes + self.code_bias.to(codes.dtype)], dim=-2)
        # <<< end of EDIT 1

        # >>> EDIT 2 of 7: stage 1, every transaction by itself, or the pooler in its place.
        if self.stage1 is not None:
            flat = predictor_tokens.reshape(B * T, N_PREDICTORS, d)
            # PLACEHOLDER W18: the grouping step of the model in use; "all" hands stage 1 every predictor token.
            inputs = _grouped(flat) if c.stage1_fields == "grouped" else flat
            # Summary tokens first, field inputs after them; they all read each other, as they share one transaction.
            out = self.stage1(torch.cat([self.summary.expand(B * T, -1, -1).to(flat.dtype), inputs], dim=1))
            summary = out[:, :M].reshape(B, T, M, d)
            field_outputs = out[:, M:].reshape(B, T, -1, d)                   # what the re-read after stage 2 reads
            # PLACEHOLDER W2: the whole output sequence of stage 1 (summary and field outputs), [B, T, L, d].
            stage1_tokens = out.reshape(B, T, -1, d)
        else:
            # The pooler reads every predictor token, as the pooler of the Large Payments Model reads every field
            # token; its cost grows with the number of tokens and not with its square, so nothing is grouped.
            summary = self.pooler(predictor_tokens)                             # [B, T, M, d]
            # With no stage 1, the fields the pooler read take the place of its field outputs and its output sequence.
            field_outputs, stage1_tokens = predictor_tokens, summary
        # <<< end of EDIT 2

        # >>> EDIT 3 of 7: the hand-off, in a method of its own so that channels_stay_apart can be run on it.
        handed = self.hand_off(summary)
        # <<< end of EDIT 3

        # >>> EDIT 4 of 7: the bank of field tokens, once per batch and only when something reads it.
        bank = None
        if self.reads_bank:
            if c.bank == "predictor":
                bank = predictor_tokens
            elif c.bank == "predictor_bank":
                # Every predictor token reads the output of stage 1 of its own transaction once (PLACEHOLDER W1, W2).
                bank = self.predictor_bank(predictor_tokens, stage1_tokens)
            else:
                bank = field_outputs
        # <<< end of EDIT 4

        # >>> EDIT 5 of 7: the time inputs and the bias, once per batch. PLACEHOLDER W21: the gap takes the place of
        # the time-gap input of the model in use. The gap is counted in whole seconds to the latest real row of a
        # strictly earlier second, by the one rule of the package (W3, W4, W5).
        gaps = gap_seconds(times, valid, units_per_second=self.units_per_second)    # float64 [B, T]
        extra = self.gap(gaps, valid)                                           # [B, T, width], zero on padding
        if self.calendar is not None:
            extra = extra + self.calendar(times, valid)
        bias = None
        if self.time_bias is not None:
            # The joined history only: no match field, so an empty tensor of codes leaves the time-gap part alone.
            no_codes = torch.zeros(B, T, 0, dtype=torch.long, device=times.device)
            bias = self.time_bias(no_codes, times, valid)                       # [B, heads, T, T]
        # <<< end of EDIT 5

        # >>> EDIT 6 of 7: the history. The joined history keeps today's layers (and, after them, the re-read of
        # edit 7); the stage takes the place of the joining line, the position table, the layers, the gap input and
        # any position in front of the rows (W8). The stage makes its own time-gap bias when it was built with one.
        if self.stage is None:
            rows = self._joined(handed, times, valid, extra, bias, bank, field_outputs)
        else:
            rows = self.stage(handed, bank, times, valid, row_extra=extra)
        # <<< end of EDIT 6
        return rows

    def hand_off(self, summary):
        """The summary outputs of every row as the history takes them (EDIT 3 of 7, PLACEHOLDER W19).

        summary   [B, T, M, d]: the M summary outputs of stage 1, or of the pooler, of every row

        Returns [B, T, M * d] for the joined history: the M outputs side by side in channel-major order (the d
        numbers of output 0, then those of output 1, ...), as today. Returns [B, T, M, d] for the channel stage: the
        outputs kept apart, each one channel, and the joining line goes. Nothing is applied on the way, so every
        output reaches one channel of its own; channels_stay_apart(model.hand_off, summary) says so for the stage.
        """
        B, T, M, d = summary.shape
        if self.config.history == "joined":
            return summary.reshape(B, T, M * d)
        # The outputs come in before any join, so each channel is one summary output as stage 1 gave it.
        return summary

    def _joined(self, vectors, times, valid, extra, bias, bank, field_outputs):
        """The joined history of today, with its re-reads, its bias and the re-read after it: [B, T, W]."""
        c = self.config
        B, T, W = vectors.shape
        # The strict time rule of stage 2: a row reads itself and the real rows of strictly earlier whole seconds.
        eligible = eligible_rows(times, valid, self.units_per_second)                   # [B, T, T], without itself
        allowed = eligible | torch.eye(T, dtype=torch.bool, device=valid.device)
        # PLACEHOLDER W20: the position by the count of strictly earlier rows; rows of one second share it, and rows
        # with more earlier rows than the table has entries share its last entry.
        n_earlier = eligible.sum(dim=-1).clamp(max=self.position.num_embeddings - 1)
        # Padded slots are set to zero first: no row reads them, but a weight of zero times a value that is not a
        # number is still not a number.
        x = vectors.masked_fill(~valid.unsqueeze(-1), 0.0) + self.position(n_earlier) + extra.to(vectors.dtype)
        # PLACEHOLDER W8: no position sits in front of the rows here; a model with one widens the mask as
        # masks.with_prefix does. PLACEHOLDER W7: what goes into the layers (x) and the mask they take.
        if bias is None:
            # Zero where reading is allowed and minus infinity where it is not, one copy per head, as today.
            mask = torch.zeros(B, T, T, dtype=x.dtype, device=x.device).masked_fill(~allowed, float("-inf"))
            mask = mask.repeat_interleave(c.history_heads, dim=0)                       # [B * heads, T, T]
        else:
            # A choice, not a sum: a closed pair stays closed whatever the bias holds there, so the bias changes how
            # much a row reads of what it may read and never what it may read.
            mask = torch.where(allowed.unsqueeze(1), bias.to(x.dtype), float("-inf"))   # [B, heads, T, T]
        # The memory of the re-reads, once per batch, from the bank, the times and the mask of real rows.
        memory = None if self.interleaved is None else self.interleaved.prepare(bank, times, valid)
        # PLACEHOLDER W6: the history layers, run one by one so that a re-read can follow each.
        layers = self.history_layers.layers
        for number, layer in enumerate(layers, start=1):
            # Without a bias the layer's own call keeps today's arithmetic and today's quick route in scoring; with
            # one, the mask must be added in scoring too.
            x = layer(x, src_mask=mask) if bias is None else run_layer(layer, x, mask)
            if memory is not None:
                x = self.interleaved.after_layer(number, x, memory, last_layer=len(layers))
        # >>> EDIT 7 of 7: after the history. PLACEHOLDER W22: the re-read after stage 2 stays as it is.
        if self.last_reread is not None:
            x = self.last_reread(x, field_outputs)
        return x

    def forward(self, batch):
        """Two logits for every row, [B, T, 2]: the head on the vector of `export`."""
        # >>> EDIT 7 of 7: PLACEHOLDER W23, the head reads the exported vector at the width that vector has.
        return self.head(self.export(batch))


# ----------------------------------------------------------------------------------------------
# counting and describing
# ----------------------------------------------------------------------------------------------

def count_weights(module):
    """The number of weights of `module`: every number in its parameters, a shared parameter counted once."""
    return sum(weight.numel() for weight in module.parameters())


# The parts of BestModel by the first parts of a weight's name, in the order of the forward pass. The longest name
# that fits decides, so the time bias that the channel stage holds counts as the time bias, not as the history.
_PARTS = (("numbers", ("numbers",)), ("codes", ("code_tables", "code_bias")), ("stage 1", ("summary", "stage1")),
          ("pooler", ("pooler",)), ("bank", ("predictor_bank",)), ("history", ("position", "history_layers", "stage")),
          ("re-reads", ("interleaved",)), ("re-read after stage 2", ("last_reread",)), ("gap", ("gap",)),
          ("calendar", ("calendar",)), ("time bias", ("time_bias", "stage.time_bias")), ("head", ("head",)))


def weights_by_part(model):
    """The weights of a BestModel by part, as {part: count}, in the order of the forward pass; parts it lacks are
    left out. The counts add up to count_weights(model)."""
    counts = {}
    for name, weight in model.named_parameters():
        fits = [(len(owner), label) for label, owners in _PARTS for owner in owners
                if name == owner or name.startswith(owner + ".")]
        part = max(fits)[1] if fits else "other"
        counts[part] = counts.get(part, 0) + weight.numel()
    order = [label for label, _ in _PARTS] + ["other"]
    return {label: counts[label] for label in order if label in counts}


def describe(item):
    """One line per entry of a configuration with its value, as one string; for a model, its weights by part too.

    item   a Config or a BestModel

    An entry without effect in the configuration says so, with the reason, so that a run listed with that
    entry is not taken for a test of it.
    """
    model = item if isinstance(item, BestModel) else None
    config = model.config if model is not None else item
    notes = inactive(config)
    if config.history == "joined":
        shape = (f"{config.num_summary} summary outputs of {config.token_dim} joined into "
                 f"{config.num_summary * config.token_dim}, {config.history_layers} history layers")
    else:
        shape = (f"{config.num_summary} channels of {config.token_dim}, {config.history_layers} pairs, layout "
                 f"{config.layout}")
    lines = [f"Config: {shape}, numbers {config.numeric_encoder}"]
    for entry in dataclasses.fields(Config):
        value = getattr(config, entry.name)
        note = f"   (no effect: {notes[entry.name]})" if entry.name in notes else ""
        lines.append(f"  {entry.name:<22} {_shown(entry.name, value)}{note}")
    if model is not None:
        lines.append(f"  {'weights':<22} {count_weights(model):,}")
        lines += [f"    {part:<20} {count:,}" for part, count in weights_by_part(model).items()]
    return "\n".join(lines)


def arm_table(names=None, say=print, seed=0):
    """One row per arm: its name, its weights, the arm it is set against, its change and its question.

    names   arm names of ARMS; None lists every arm
    say     where the lines go; print by default
    seed    the seed every model is built with, to count its weights

    Returns [{"name", "weights", "against", "change", "question"}], in the order of `names`. Every model is
    built once, so a long list takes some seconds.
    """
    names = list(ARMS) if names is None else [names] if isinstance(names, str) else list(names)
    rows = []
    say(f"{'arm':<23} {'weights':>11}  {'compared with':<20} change")
    say(f"{'':<23} {'':>11}  {'':<20} question")
    for name in names:
        if name not in ARMS:
            raise ValueError(f"no arm is named {name!r}; the arms are {', '.join(ARMS)}")
        arm = ARMS[name]
        torch.manual_seed(seed)
        weights = count_weights(BestModel(arm.config))
        rows.append({"name": name, "weights": weights, "against": arm.against, "change": arm_change(name),
                     "question": arm.question})
        say(f"{name:<23} {weights:>11,}  {arm.against or '-':<20} {rows[-1]['change']}")
        say(f"{'':<23} {'':>11}  {'':<20} {arm.question}")
    return rows


# ----------------------------------------------------------------------------------------------
# made-up rows
# ----------------------------------------------------------------------------------------------

def make_batch(seed=0, sequences=16, rows=None):
    """A padded batch of made-up rows in the layout BestModel takes.

    seed        seed of the made-up values
    sequences   B, the windows of the batch
    rows        T, the slots per window; None reads HISTORY_LEN + 1 (121)

    Returns {"continuous", "categorical", "mask", "time_seq", "target_seq"}. Real rows come first in every
    window; the first window is full and the last half full, so that a cost is taken at the full width and
    padding is always there to check. A quarter of the rows share the second of the row before, and the second
    row of the first window always does, so that the order check has a second with two rows at any size; the
    other gaps run from one second to about four days, so that every encoder of the gap and every bucket of the
    bias is used. Times are nanoseconds with a part inside the second, so that a wrong time unit would put rows
    of one second in an order. About one number in twenty of a real row is missing (not a number).
    """
    rows = HISTORY_LEN + 1 if rows is None else int(rows)
    g = torch.Generator().manual_seed(seed)
    lengths = torch.randint(max(1, rows // 2), rows + 1, (sequences,), generator=g)
    if sequences > 1:
        # One full window, so that a cost is taken at the full width, and one half full, so that padding is there.
        lengths[0], lengths[-1] = rows, max(1, rows // 2)
    valid = torch.arange(rows).unsqueeze(0) < lengths.unsqueeze(1)
    # The step to the row before: zero (one second shared) a quarter of the time, else 1 s to 10^5.5 s on a log scale.
    same = torch.rand(sequences, rows, generator=g) < 0.25
    if rows > 1:
        # The first two rows of the first window share their second, so that a shuffle inside a second has rows to move.
        same[0, 1] = True
    steps = torch.floor(10.0 ** (torch.rand(sequences, rows, generator=g) * 5.5)).long().masked_fill(same, 0)
    seconds = 1_767_225_600 + torch.cumsum(steps, dim=1)                       # from 1 January 2026
    # A part inside the second, in no order: rows of one second differ in their units, so that a time unit taken
    # for another would put them in an order that the rule must not give them.
    inside = torch.randint(0, TIME_UNITS_PER_SECOND, (sequences, rows), generator=g)
    times = (seconds * TIME_UNITS_PER_SECOND + inside).masked_fill(~valid, 0)
    # Numbers on [0, 1], the scale of UnitQuantileScaler; padded slots hold 0, as the builder of the model in use
    # writes there.
    continuous = torch.rand(sequences, rows, N_NUMERIC, generator=g)
    absent = (torch.rand(sequences, rows, N_NUMERIC, generator=g) < 0.05) & valid.unsqueeze(-1)
    continuous = continuous.masked_fill(absent, float("nan")).masked_fill(~valid.unsqueeze(-1), 0.0)
    categorical = torch.randint(0, CODE_SIZE, (sequences, rows, N_CODES), generator=g)
    categorical = categorical.masked_fill(~valid.unsqueeze(-1), 0)
    # A label that depends on single predictors, so that the made-up task has something to learn.
    signal = torch.nan_to_num(continuous[..., 7], nan=0.0) + 0.6 * (categorical[..., 3] > CODE_SIZE // 2).float()
    target = torch.where(valid, (signal > 1.0).long(), torch.full_like(lengths.unsqueeze(1), -100))
    return {"continuous": continuous, "categorical": categorical, "mask": valid, "time_seq": times,
            "target_seq": target}


def _copied(batch):
    """A copy of a batch whose tensors can be written without touching the batch itself."""
    return {name: value.clone() if torch.is_tensor(value) else value for name, value in batch.items()}


def alter_rows(batch, rows, seed=3):
    """A copy of a made-up batch with every input of the slots in `rows` (bool [B, T]) replaced by other values.

    The times, the mask of real rows and the labels stay as they are, which is what the checks ask of `alter`: check
    1 moves the times itself, and the checks redraw the entries named by `labels` themselves (see `_redrawn`).
    """
    g = torch.Generator().manual_seed(seed)
    out = _copied(batch)
    n = int(rows.sum())
    out["continuous"][rows] = torch.rand(n, out["continuous"].shape[-1], generator=g).to(out["continuous"])
    out["categorical"][rows] = torch.randint(0, CODE_SIZE, (n, out["categorical"].shape[-1]),
                                             generator=g).to(out["categorical"])
    if torch.is_tensor(out.get("missing")):
        out["missing"][rows] = (torch.rand(n, out["missing"].shape[-1], generator=g) < 0.5).to(out["missing"].device)
    return out


def fill_rows(batch, rows, value, seed=4):
    """A copy of a made-up batch with every number of the slots in `rows` set to `value` and their codes redrawn."""
    g = torch.Generator().manual_seed(seed)
    out = _copied(batch)
    n = int(rows.sum())
    out["continuous"][rows] = value
    # Codes cannot hold a value that is not a number; other codes are what padding can hold instead.
    out["categorical"][rows] = torch.randint(0, CODE_SIZE, (n, out["categorical"].shape[-1]),
                                             generator=g).to(out["categorical"])
    if torch.is_tensor(out.get("missing")):
        out["missing"][rows] = (torch.rand(n, out["missing"].shape[-1], generator=g) < 0.5).to(out["missing"].device)
    return out


def row_loss(model, batch, real="mask", label="target_seq"):
    """Cross-entropy over the real rows, one prediction per row (all-position); PLACEHOLDER W25 in the model in use.

    real    the mask of real rows, as the checks take it ("mask", "~is_pad" or a function)
    label   the batch entry of the answer, read as whole classes (a yes-or-no or 0.0/1.0 label becomes 0 or 1)
    """
    valid, answers = _real(batch, real), batch[label]     # read before the call: a model may take an entry out
    return F.cross_entropy(_as_scores(model(batch), "training")[valid], answers[valid].long())


# ----------------------------------------------------------------------------------------------
# seven checks; each takes a model and a batch, and the caller's own functions for what differs from
# one model to another, so that they run on the model in use; and channels_stay_apart, which takes
# the model's own hand-off
# ----------------------------------------------------------------------------------------------

# How far every weight is moved before a check, as after some training. A fresh model has parts that start at zero
# (the write-back of a re-read, the second layer of the calendar encoder, the bias, a missing vector): a leak through
# such a part, or a weight behind it that is not wired to the loss, would not show while the part is zero.
MOVE_STD = 0.05

# The largest difference check 3 allows, as a share of the score that moves (or of 1 when that score is smaller): the
# cut window runs on tensors of another length, or with its rows in other slots, which may sum in another order, so
# the two agree to rounding and not bit for bit. Check 3 scores a copy of the model in 64-bit numbers, with autocast
# off, whenever the model runs there and scores the whole batch there as in 32 bits (see `_exact_copies`); its
# rounding is then about 1e-14 of a score. Otherwise the copy is in 32-bit numbers with float32 products at full
# precision (see `_full_precision`), whose rounding grows with the width of the history and the size of the scores
# and reaches this tolerance from about 300 numbers of joined width (on some batches at WIDE_JOINED's 288, on most
# at 384).
PREFIX_TOLERANCE = 1e-5

# How far the 64-bit copy may move on a window whose later slots were made padding in place for a move of the model in
# its own number type to count as rounding over other shapes: far above the rounding of 64 bits (about 1e-14), far
# below the rounding of 32 bits (about 1e-7).
IN_PLACE_ROUNDING = 1e-10

# The largest move allowed, as a share of the score that moves (or of 1), where rows change slots or a batch changes
# size: in check 7 when the rows of a second are shuffled among their slots or leave the window, and in check 6 when a
# sequence is scored alone. Rows in other slots, or in a batch of another size, are summed in another order, which
# rounds otherwise; the scores come from a copy in 64 or 32 bits as in check 3. The passes of check 7 that keep every
# slot allow no move at all.
ORDER_TOLERANCE = 1e-5

# How far the scores of the 64-bit copy of checks 3, 6 and 7 may lie from those of the 32-bit copy on the whole batch,
# as a share of each score (or of 1), for their comparisons to run in 64 bits (see `_exact_copies`). The rounding of 32
# bits lies far below it; a model that scores otherwise in 64 bits (a branch it takes on the number type of its
# numbers) lies far above it, and its comparisons run in 32 bits.
AGREEMENT_64 = 1e-3

# The years in which check 5 requires the times of the real rows to lie, read with the unit the caller names: a unit
# that does not fit the times puts them in 1970 (seconds read as nanoseconds) or in a year in the billions
# (nanoseconds read as seconds), far outside these.
EARLIEST_SECOND = 946_684_800                   # 2000-01-01 00:00:00 UTC
LATEST_SECOND = 4_102_444_800                   # 2100-01-01 00:00:00 UTC

# How far check 1 pushes the rows of later seconds beyond doubling their distance from the probe's second: an hour,
# in whole seconds, so that each row keeps its part inside the second and a batch in time order stays in time order.
# It moves every gap from the kept rows to a later row and every hour of the day of a later row. When check 1 changes
# the kept rows instead, the rows of seconds before the probe's move this far earlier, every second kept apart.
PUSH_SECONDS = 3_600

# The most passes of check 7 around a witness. Each pass changes one shared second of every sequence; a sequence with
# more shared seconds than this has its passes spread over them, its first and its last among them, so that the time
# of the check does not grow with the number of shared seconds.
ORDER_PASSES = 8

# How far check 6 moves every real row of its own second batch later in time: 30 days, 5 hours and 7 seconds, so that
# the day, the hour and the second of every row differ from those of the first batch, and whatever a model fixes on
# its first call from the times it saw (an origin of time, say) reads the second batch otherwise than a fresh copy.
OTHER_SHIFT_SECONDS = 2_610_007

# The seed of the dropout in the training-mode passes of the checks. Both calls of one comparison draw from it, so
# they draw the same masks, and only what their batches hold can tell their outputs apart.
DROPOUT_SEED = 9

# The mean length of a year of the calendar in seconds, to give the year of a time that no date can hold.
SECONDS_PER_YEAR = 31_556_952

# The entries that every module holds for torch itself; whatever else a module holds is its own (see
# `_instance_state`).
_TORCH_ENTRIES = frozenset(vars(nn.Module()))


def _copy(model):
    """A deep copy of `model`. A tensor that a module keeps from a call made with gradients on (an output kept for
    later, as the model in use keeps its first position) is no leaf of the graph, and copy.deepcopy stops on it. The
    copy holds a detached clone of it in its place wherever a deep copy reaches it (an attribute, a list, a tuple, a
    set, a dict, a deque, an object with or without __slots__, a module held in a plain list, at any depth), so that
    a model handed over after a training step is checked as it is. For the length of the copy torch.Tensor's own
    __deepcopy__ is stood in for; it is put back after, also when the copy stops. A hook keeps its own function, so
    a hook that writes into a store it holds outside the model (a dict it closes over) writes into that one store
    from every copy."""
    original = torch.Tensor.__deepcopy__

    def detached(tensor, memo):
        if not tensor.is_leaf:
            return tensor.detach().clone()
        if tensor.layout not in (torch.strided, torch.sparse_coo) and type(tensor) is torch.Tensor:
            return tensor.clone()                 # a sparse layout torch's own deep copy stops on (CSR)
        return original(tensor, memo)

    torch.Tensor.__deepcopy__ = detached
    try:
        twin = copy.deepcopy(model)
    finally:
        torch.Tensor.__deepcopy__ = original
    if isinstance(twin, nn.Module):
        for weight in twin.parameters():
            # A torch script module hands its weights back as clones inside the graph of the model they came from:
            # no leaf, so a training step leaves them without a gradient and puts it on the model handed over.
            if not weight.is_leaf:
                weight.detach_().requires_grad_(True)
    return twin


def moved(model, std=MOVE_STD, seed=1):
    """A copy of `model` in evaluation mode with every weight shifted by a little noise of spread `std`."""
    work = _copy(model)
    own = {id(tensor) for tensor in [*model.parameters(), *model.buffers()]}
    shared = [name for name, tensor in [*work.named_parameters(), *work.named_buffers()] if id(tensor) in own]
    if shared:
        raise ValueError(f"a copy of the model shares {', '.join(shared[:6])}{' ...' if len(shared) > 6 else ''} "
                         "with the model itself (a part whose deep copy is itself): the checks move the weights of "
                         "their copies and change their number type, which would change the model handed over. "
                         "Hand over a model whose parts are copied by copy.deepcopy")
    g = torch.Generator().manual_seed(seed)
    with torch.no_grad():
        for weight in work.parameters():
            # The noise is drawn on the CPU from a seed of its own, so that the copy is the same on every machine.
            weight.add_(torch.randn(weight.shape, generator=g).to(weight) * std)
    return work.eval()


def _as_scores(out, mode):
    """The scores in a model's output, [B, T, ...]: the output when it is a tensor, its first part when it is a tuple
    or a list that starts with one (the scores and an auxiliary loss, say); anything else, or a first part with fewer
    than two dimensions (a loss handed back first), stops with a plain error that names it. `mode` is "scoring" or
    "training", for that error."""
    if torch.is_tensor(out):
        first, what = out, "a tensor"
    elif isinstance(out, (tuple, list)) and out and torch.is_tensor(out[0]):
        first, what = out[0], f"a {type(out).__name__} whose first part is a tensor"
    else:
        raise TypeError(f"in {mode} mode the model returned {type(out).__name__}; the checks compare one score per "
                        f"row, [B, T, ...], so they need the scores as a tensor, or as the first part of a tuple")
    if first.dim() < 2:
        raise TypeError(f"in {mode} mode the model returned {what} of shape {tuple(first.shape)}; the checks compare "
                        f"one score per row, [B, T, ...], so the scores come first (a loss handed back with them, as "
                        f"a model given its labels may hand it back, comes after)")
    return first


def _apart(value, depth=0):
    """(a copy of `value` that shares nothing a model can write into with it, whether all of it was copied). A tensor
    is cloned, a plain value kept, a plain dict, list or tuple copied item by item (four levels deep) and a numpy
    array of at most `_LARGE` bytes copied. Anything else (an object, a table of another library, a large array, an
    open file) is handed on as it is: copying it at every call costs more than the checks themselves, and many such
    things cannot be copied at all."""
    if torch.is_tensor(value):
        return value.clone(), True
    if value is None or isinstance(value, (bool, int, float, complex, str, bytes)):
        return value, True
    if depth < 4 and type(value) in (list, tuple):
        parts = [_apart(item, depth + 1) for item in value]
        return type(value)(part for part, _ in parts), all(whole for _, whole in parts)
    if depth < 4 and type(value) is dict:
        parts = {key: _apart(item, depth + 1) for key, item in value.items()}
        return {key: part for key, (part, _) in parts.items()}, all(whole for _, whole in parts.values())
    if type(value).__module__ == "numpy" and hasattr(value, "nbytes") and hasattr(value, "copy"):
        if value.nbytes <= _LARGE and getattr(value, "dtype", None) is not None and value.dtype != object:
            return value.copy(), True
    return value, False


def _handed(batch):
    """What every call of the checks hands the model: a new dict, every tensor cloned and every plain container
    copied (see `_apart`). A model may write an entry into the batch it is handed and read it again (a length, a
    statistic of the window kept for later); handed the checks' own dict, it would find in every changed, cut or
    relaid window the entry it worked out on the whole one, and a read of later rows through that entry would move
    nothing. A model that writes into a tensor of its batch in place (a clamp, a fill of missing values) writes into
    the clone. An entry that is an object, a table of another library or a large array is handed over as it is in
    every call (see `_shared_entries`)."""
    return {name: _apart(value)[0] for name, value in batch.items()}


def _shared_entries(batch):
    """The names of the entries of `batch` that every call of the checks hands the model as they are (see
    `_apart`): what a model writes into one is found again in every later call, and in the caller's own batch."""
    return [name for name, value in batch.items() if not _apart(value)[1]]


def _written(model, batch):
    """What a scoring call of a copy of `model` does to the batch it is handed, as (added, replaced, written in
    place, taken out): the names of the entries it adds, of those it puts another object under, of the tensors it
    writes into in place (by torch's count of in-place writes; a write made around that count, through .data or a
    numpy view, is not seen) and of the entries it takes out."""
    given = _handed(batch)
    before = dict(given)
    probe = _copy(model)
    probe.eval()
    with torch.no_grad():
        probe(given)
    added = [name for name in given if name not in before]
    replaced = [name for name, value in before.items() if name in given and given[name] is not value]
    in_place = [name for name, value in before.items()
                if torch.is_tensor(value) and not value.is_inference() and value._version != 0]
    taken_out = [name for name in before if name not in given]
    return added, replaced, in_place, taken_out


def _scores(model, batch, inference=False):
    """Scoring-mode scores of a model: evaluation mode, no gradients (see `_as_scores`); under torch.inference_mode()
    in place of torch.no_grad() when `inference`, the other way a scorer may score. The batch is copied before that
    mode is entered, so that its tensors are ordinary ones, as those a scorer builds outside it."""
    model.eval()
    handed = _handed(batch)
    with torch.inference_mode() if inference else torch.no_grad():
        return _as_scores(model(handed), "scoring")


def _eval_grad_scores(model, batch):
    """Evaluation-mode scores with gradients on, as a scorer written without torch.no_grad() makes them; handed back
    detached."""
    model.eval()
    with torch.enable_grad():
        return _as_scores(model(_handed(batch)), "scoring").detach()


def _inference_scores(work, batch):
    """Scores of a fresh copy of `work` under torch.inference_mode(); the copy is made outside it, so that its
    weights are ordinary tensors, as a scorer's are."""
    instance = _copy(work)
    return _scores(instance, batch, inference=True).clone()


def _eval_grad_copy_scores(work, batch):
    """Scores of a fresh copy of `work` in evaluation mode with gradients on."""
    return _eval_grad_scores(_copy(work), batch)


_OTHER_WAYS = (("under torch.inference_mode()", _inference_scores),
               ("in evaluation mode with gradients on", _eval_grad_copy_scores))


def _other_ways(work, batch, say, check):
    """The other ways of scoring that run on `batch` as it is. A model may stop in one of them (a .numpy() call on a
    tensor that then carries a gradient, a gradient it takes itself under torch.inference_mode()): that way is left
    out of the comparisons, with one printed line, since a scorer that scores that way stops as well."""
    ways = []
    for name, score in _OTHER_WAYS:
        try:
            score(work, batch)
        except Exception as error:  # noqa: BLE001
            say(f"{check}: {name} the model stops on the batch as handed over ({type(error).__name__}: {error}); "
                f"that way of scoring is not compared, and a scorer that scores that way stops as well")
        else:
            ways.append(score)
    return tuple(ways)


def _once(say, mark="that way of scoring is not compared"):
    """`say`, with a line that holds `mark` passed on once whichever check gives it: every check that scores the
    other ways finds the same way the model stops in, and names itself in front of the same words."""
    told = set()

    def said(line):
        if mark in line:
            key = line.split(": ", 1)[-1]
            if key in told:
                return
            told.add(key)
        say(line)

    return said


def _other_scoring(work, batch, ways=None):
    """The scores of fresh copies of `work` on `batch` in the other ways a scorer may score (see `_other_ways`):
    under torch.inference_mode(), and in evaluation mode with gradients on."""
    return tuple(score(work, batch) for score in (tuple(s for _, s in _OTHER_WAYS) if ways is None else ways))


def _fresh_scores(work, batch):
    """Scoring-mode output of a fresh copy of `work`, so that nothing a model keeps between calls reaches a check
    that is not about it; one_model_two_batches is the check that is."""
    return _scores(_copy(work), batch)


def _devices(model):
    """The CUDA devices that hold a weight or a buffer of `model`, as torch.random.fork_rng takes them; [] on a CPU."""
    return sorted({tensor.device.index for tensor in [*model.parameters(), *model.buffers()]
                   if tensor.device.type == "cuda"})


def _seed(seed, devices):
    """Seed the CPU and the CUDA devices `devices`, the ones torch.random.fork_rng forks and puts back.
    torch.manual_seed would seed every device torch knows, and leave those that were not forked moved."""
    torch.default_generator.manual_seed(seed)
    for index in devices:
        with torch.cuda.device(index):
            torch.cuda.manual_seed(seed)


def _numpy_random():
    """numpy's random module, or None on a machine without numpy."""
    try:
        import numpy
    except ImportError:
        return None
    return numpy.random


@contextlib.contextmanager
def _same_draws(seed, devices):
    """Every random draw inside it from `seed`, and every generator it seeds put back after.

    torch's generators on the CPU and on the CUDA devices `devices` are forked (torch.random.fork_rng) and seeded with
    `_seed`; Python's random module and numpy's global generator are seeded as well and given their state back after.
    Two calls under one seed then draw the same dropout, whichever of these a model draws from. A generator that the
    model holds itself (a torch.Generator or a numpy Generator of its own) is not reached.
    """
    numpy_random = _numpy_random()
    python_state = random.getstate()
    numpy_state = None if numpy_random is None else numpy_random.get_state()
    with torch.random.fork_rng(devices=devices):
        _seed(seed, devices)
        random.seed(seed)
        if numpy_random is not None:
            numpy_random.seed(seed % 2 ** 32)
        try:
            yield
        finally:
            random.setstate(python_state)
            if numpy_random is not None:
                numpy_random.set_state(numpy_state)


def _training_scores(work, batch, seed=DROPOUT_SEED):
    """Training-mode scores of a fresh copy of `work`, with its dropout drawn from `seed` (see `_training_call`).

    Two calls with one seed draw the same dropout masks, so only what their batches hold can tell their outputs
    apart, and the random state of the caller is left as it was. A part that reads the whole batch in training mode
    only, as a batch norm does with the statistics of the batch, shows when two such calls are set side by side, and
    so does a part that reads otherwise while gradients are on. So does a norm that the training loop holds still
    from outside the model, by calling eval() on it after train(), since train() here sets every part to training
    mode; a norm held still inside the model's own train() does not.
    """
    return _training_call(_copy(work), batch, seed)


def _training_call(instance, batch, seed=DROPOUT_SEED):
    """One training-mode call of `instance` itself on `batch`, as a training step makes it: train(), gradients on,
    every random draw from `seed` inside `_same_draws`; the scores are handed back detached (see `_as_scores`)."""
    instance.train()
    with _same_draws(seed, _devices(instance)), torch.enable_grad():
        return _as_scores(instance(_handed(batch)), "training").detach()


def _largest(gap):
    """The largest absolute value of `gap` as a float. A value that is not a finite number counts as the largest
    change there is, infinity, since max() would pass over a value that is not a number."""
    gap = gap.abs()
    if gap.numel() == 0:
        return 0.0
    return float(gap.max()) if bool(torch.isfinite(gap).all()) else float("inf")


def _worst(*changes):
    """The largest of some changes, infinity when one of them is not a finite number."""
    return max(change if math.isfinite(change) else float("inf") for change in changes)


def _share(base, other):
    """The largest difference of `other` from `base`, each as a share of the score it differs from in `base` (or of 1
    when that score is smaller than 1): 0.0 for no scores, infinity when a difference is not a finite number. A share
    per score, so that a large score in one channel (an amount in cents beside the logits) does not widen what the
    others may move."""
    gap = (base - other).abs()
    if gap.numel() == 0:
        return 0.0
    if not bool(torch.isfinite(gap).all()):
        return float("inf")
    return float((gap / base.abs().clamp(min=1.0)).max())


def _full_matmul_precision():
    """Set float32 matrix products to their full precision, without TF32 or 16-bit parts, and give back the function
    that puts every setting back as it was.

    The precision of every backend that holds one (torch.backends, its cuda.matmul and its mkldnn.matmul, on a torch
    that has them) is read first, and so is the summary torch.get_float32_matmul_precision when it can be read. When
    it can, it is set to "highest" and put back after with torch.set_float32_matmul_precision; then every backend
    whose precision still differs from the one read is set back on its own. When the summary cannot be read (a
    setting made per backend, on torch 2.9 and later), each backend is set to "ieee" and put back on its own. A
    setting already at full precision everywhere is left alone.
    """
    holders = [holder for holder in (torch.backends, getattr(torch.backends, "cuda", None),
                                     getattr(torch.backends, "mkldnn", None))
               if holder is not None]
    holders = [getattr(holder, "matmul", holder) if holder is not torch.backends else holder for holder in holders]
    saved = [(holder, holder.fp32_precision) for holder in holders if hasattr(holder, "fp32_precision")]
    try:
        summary = torch.get_float32_matmul_precision()
    except RuntimeError:
        summary = None
    if summary == "highest" and all(value in ("ieee", "none") for _, value in saved):
        return lambda: None
    if summary is not None:
        torch.set_float32_matmul_precision("highest")
    else:
        for holder, _ in saved:
            if holder is not torch.backends:
                holder.fp32_precision = "ieee"

    def put_back():
        if summary is not None:
            torch.set_float32_matmul_precision(summary)
        for holder, value in saved:
            if holder.fp32_precision != value:
                holder.fp32_precision = value

    return put_back


# The writes that land in their first argument: an operator with an assignment (x[i] = v, x += v); a method whose
# name ends in one underscore (add_, copy_) is one as well.
_IN_PLACE = frozenset({"__setitem__", "__iadd__", "__isub__", "__imul__", "__itruediv__", "__ifloordiv__", "__imod__",
                       "__ipow__", "__iand__", "__ior__", "__ixor__", "__ilshift__", "__irshift__", "__imatmul__"})
# Functions that take numbers out of a tensor, or lay it out otherwise, and work nothing out: on the narrow tensor
# they hand back what they would on the wide one, which `_Widen` then widens.
_SELECTING = frozenset({"__getitem__", "index_select", "gather", "take", "take_along_dim", "masked_select", "narrow",
                        "select", "view", "reshape", "flatten", "squeeze", "unsqueeze", "permute", "transpose", "t",
                        "contiguous", "expand", "expand_as", "chunk", "split", "unbind", "embedding"})


class _Widen(torch.overrides.TorchFunctionMode):
    """Inside it, every floating tensor narrower than `dtype` that a torch function takes or hands back is taken in
    `dtype`, and so is a dtype argument of a narrower floating type.

    A copy of a model in 64-bit numbers has its weights and buffers there, and nothing else: a mask the model builds
    in float32, a plain float32 tensor it holds, a cast it makes inside (.float(), .half(), .to(torch.bfloat16))
    stay narrow. Mixed with the wide weights they stop a product, or they are misread (the model in use builds its
    attention mask in float32, which torch on the CPU reads otherwise beside float64 weights in training mode), and
    the copy fell back to 32 bits, where a wide model fails on rounding alone. Widened here, such a model runs in 64
    bits throughout. The same holds one step down for a model in 16 bits scored on its 32-bit copy.

    Only tensors, dtypes and plain lists, tuples and dicts of them are widened: any other object (a torch.Size, a
    named tuple) is handed on as it is, with its type and its methods. The target of a write in place keeps its own
    type and is handed back as it is, so that the write lands in the tensor the model holds."""

    def __init__(self, dtype):
        super().__init__()
        self.dtype, self.bits = dtype, torch.finfo(dtype).bits

    def _narrow(self, value):
        return isinstance(value, torch.dtype) and value.is_floating_point and torch.finfo(value).bits < self.bits

    def _wide(self, value):
        if isinstance(value, torch.Tensor) and value.is_floating_point() and self._narrow(value.dtype):
            return value.to(self.dtype)
        if self._narrow(value):
            return self.dtype
        return value

    def _map(self, value, large=False):
        if type(value) in (list, tuple):
            return type(value)(self._map(item, large) for item in value)
        if type(value) is dict:
            return {key: self._map(item, large) for key, item in value.items()}
        if large and isinstance(value, torch.Tensor) and value.numel() * value.element_size() > _LARGE:
            return value                    # a large table a function only selects from stays as it is
        return self._wide(value)

    def __torch_function__(self, func, types, args=(), kwargs=None):
        kwargs = kwargs or {}
        name = getattr(func, "__name__", "")
        inplace = (name.endswith("_") and not name.endswith("__")) or name in _IN_PLACE
        selecting = name in _SELECTING and kwargs.get("max_norm") is None
        if inplace and args:
            args = (args[0],) + tuple(self._map(item) for item in args[1:])
        else:
            args = tuple(self._map(item, selecting) for item in args)
        kwargs = {key: self._map(item, selecting) for key, item in kwargs.items()}
        out = func(*args, **kwargs)
        if inplace:
            return out
        if isinstance(out, torch.Tensor):
            return self._wide(out)
        if type(out) in (list, tuple):
            return type(out)(self._wide(item) if isinstance(item, torch.Tensor) else item for item in out)
        return out


@contextlib.contextmanager
def _full_precision(dtype=None):
    """Autocast off on the CPU and on CUDA, and float32 matrix products at their full precision (see
    `_full_matmul_precision`), every setting put back after. The comparisons that allow rounding allow that of
    32-bit arithmetic, which a model in 16 bits, or products in TF32, would exceed a hundred times over. With
    `dtype`, every narrower float is widened to it inside (see `_Widen`): the number type of the copy that is
    scored."""
    with contextlib.ExitStack() as stack:
        stack.enter_context(torch.autocast("cpu", enabled=False))
        if dtype is not None:
            stack.enter_context(_Widen(dtype))
        if torch.cuda.is_available():
            stack.enter_context(torch.autocast("cuda", enabled=False))
        put_back = _full_matmul_precision()
        try:
            yield
        finally:
            put_back()


# The modules whose `p` is the probability of a dropout, on this torch.
_DROPOUTS = tuple(kind for kind in (getattr(nn, name, None) for name in (
    "Dropout", "Dropout1d", "Dropout2d", "Dropout3d", "AlphaDropout", "FeatureAlphaDropout")) if kind is not None)


# The functions of torch.nn.functional and of torch that draw a dropout, which the training-mode calls of a copy
# without dropout run as the identity (see `_dropout_functions_off`).
_DROPOUT_FUNCTIONS = ((F, ("dropout", "dropout1d", "dropout2d", "dropout3d", "alpha_dropout", "feature_alpha_dropout")),
                      (torch, ("dropout", "alpha_dropout", "feature_dropout", "feature_alpha_dropout")))


@contextlib.contextmanager
def _dropout_functions_off():
    """Inside it, the dropout functions of torch.nn.functional and of torch (torch.dropout and its kin) hand back their
    input as it is, and torch.nn.functional.scaled_dot_product_attention runs with dropout_p 0; every function is put
    back after. nn.Dropout and its kin, nn.MultiheadAttention and the layers of nn.Transformer draw their dropout
    through these, and so does a model that calls F.dropout(x, self.rate) or passes dropout_p itself, so that a copy
    without dropout draws no mask there whatever rate it holds. A function taken by its own name before (from
    torch.nn.functional import dropout) is not reached."""
    saved = []

    def as_it_is(input, *args, **kwargs):
        return input

    for holder, names in _DROPOUT_FUNCTIONS:
        for name in names:
            if hasattr(holder, name):
                saved.append((holder, name, getattr(holder, name)))
                setattr(holder, name, as_it_is)
    attention = getattr(F, "scaled_dot_product_attention", None)
    if attention is not None:
        def attention_without_dropout(query, key, value, attn_mask=None, dropout_p=0.0, *args, **kwargs):
            return attention(query, key, value, attn_mask, 0.0, *args, **kwargs)

        saved.append((F, "scaled_dot_product_attention", attention))
        F.scaled_dot_product_attention = attention_without_dropout
    try:
        yield
    finally:
        for holder, name, function in reversed(saved):
            setattr(holder, name, function)


def _without_dropout(work):
    """A copy of `work` with its dropout off: p = 0 in every dropout module (nn.Dropout and its kin), and 0.0 in every
    float attribute of a module whose name holds "dropout" but not "keep" (the probability an attention call or a
    recurrent layer reads, which nn.MultiheadAttention and nn.LSTM keep in `dropout` and the blocks of this package in
    `attn_dropout`; a keep probability is left as it is). Its training-mode calls run inside `_dropout_functions_off`,
    so that a dropout drawn through torch's functions at a rate the model holds elsewhere (F.dropout(x, self.rate),
    dropout_p of an attention call) draws nothing either.

    A training-mode call of the copy reads what a training step reads (the statistics of its batch, a part that reads
    otherwise while gradients are on) with no random mask, so two batches that differ in which slots are real or in
    where their rows lie can be set side by side whatever the dropout is laid out over: the slots, or the real rows
    packed together. A random draw made otherwise (a mask from torch.rand, noise, a generator of the model's own) stays
    on, and `_training_draws` finds it. A part that runs only while a rate is above zero is turned off with it.
    """
    quiet = _copy(work)
    for module in quiet.modules():
        if isinstance(module, _DROPOUTS):
            module.p = 0.0
        names = [key for key, value in vars(module).items()
                 if "dropout" in key.lower() and "keep" not in key.lower() and isinstance(value, float)]
        for key in names:
            setattr(module, key, 0.0)
    return quiet


def _plain_tensors_as(twin, widen):
    """`twin` with every tensor that a module of it holds as a plain attribute (no weight, no buffer: a workspace, a
    table) put through `widen`, so that a write the model makes into one in place (ws[:n].copy_(x), an out=
    argument) lands in a tensor of the copy's own number type."""
    for module in twin.modules():
        for key, value in list(vars(module).items()):
            if key not in _TORCH_ENTRIES and torch.is_tensor(value) and value.layout == torch.strided:
                wide = widen(value)
                if wide is not value:
                    object.__setattr__(module, key, wide)
    return twin


def _in_32_bits(work):
    """A copy of `work` with every 16-bit floating weight, buffer and plain tensor in float32; one in 32 or 64 bits
    stays as it is."""
    def widen(tensor):
        return tensor.float() if tensor.dtype in (torch.float16, torch.bfloat16) else tensor

    return _plain_tensors_as(_copy(work)._apply(widen), widen)


def _in_64_bits(work):
    """A copy of `work` with every floating weight, buffer and plain tensor in float64."""
    def widen(tensor):
        return tensor.double() if tensor.is_floating_point() and tensor.dtype != torch.float64 else tensor

    return _plain_tensors_as(_copy(work)._apply(widen), widen)


def _float_type(model):
    """The number type of the first floating weight or buffer of `model`; float32 when it holds none."""
    return next((tensor.dtype for tensor in [*model.parameters(), *model.buffers()] if tensor.is_floating_point()),
                torch.float32)


def _batch_as(batch, dtype):
    """The batch with every floating entry narrower than `dtype` in `dtype`; every other entry, the integer times among
    them, as it is."""
    bits = torch.finfo(dtype).bits
    return {name: value.to(dtype) if torch.is_tensor(value) and value.is_floating_point()
            and torch.finfo(value.dtype).bits < bits else value for name, value in batch.items()}


# For every copy in wider numbers (by its id): the model in its own number type, and the shapes of the batches it has
# scored for that copy (see `_warm`).
_WARMED = {}


def _warmed_by(twin, own):
    """Note that `twin`, a copy in wider numbers, stands for `own`, the model in its own number type."""
    _WARMED[id(twin)] = (own, set())
    weakref.finalize(twin, _WARMED.pop, id(twin), None)
    return twin


def _warm(work, batch):
    """Score `batch` once with the model in its own number type before `work`, its copy in wider numbers, scores a
    batch of that shape for the first time.

    A model may keep, outside its instances, a tensor it builds once per shape of the window: a causal mask behind
    functools.lru_cache, a table in a module-level dict keyed by the window's length. Built for the first time
    inside the wider copy, where every float is widened, it would stay wide in that store, and the model as handed
    over would stop on it after the checks (float32 weights beside a float64 mask). Built here first, it is in the
    model's own type, and the wider copy widens it as it reads it. A model that stops on the batch says so in the
    call that follows."""
    entry = _WARMED.get(id(work))
    if entry is None:
        return
    own, seen = entry
    shape = tuple(sorted((str(name), tuple(value.shape)) for name, value in batch.items() if torch.is_tensor(value)))
    if shape in seen:
        return
    seen.add(shape)
    try:
        _scores(_copy(own), batch)
    except Exception:  # noqa: BLE001
        pass


def _exact_scores(work, batch):
    """Scoring-mode scores of a fresh copy of `work` (a copy from `_exact_copies`) on `batch`, its floating entries in
    the number type of `work` (see `_batch_as`), at full precision (see `_full_precision`)."""
    _warm(work, batch)
    instance = _copy(work)
    with _full_precision(_float_type(work)):
        return _scores(instance, _batch_as(batch, _float_type(work)))


def _exact_training_scores(quiet, batch, seed=DROPOUT_SEED):
    """Training-mode scores of a fresh copy of `quiet` (a copy from `_exact_copies` and `_without_dropout`) on `batch`
    as in `_exact_scores`, with gradients on (see `_training_scores`) and the dropout functions of torch off (see
    `_dropout_functions_off`)."""
    _warm(quiet, batch)
    instance = _copy(quiet)
    with _full_precision(_float_type(quiet)), _dropout_functions_off():
        return _training_call(instance, _batch_as(batch, _float_type(quiet)), seed)


def _reseeded(work, seed):
    """A copy of `work` in which every torch.Generator and every numpy Generator that a module holds as an attribute
    draws from a seed of its own, counted up from `seed`."""
    other = _copy(work)
    numpy_random = _numpy_random()
    count = 0
    for module in other.modules():
        for key, value in list(vars(module).items()):
            if isinstance(value, torch.Generator):
                value.manual_seed(seed + count)
                count += 1
            elif numpy_random is not None and isinstance(value, getattr(numpy_random, "Generator", ())):
                setattr(module, key, numpy_random.default_rng(seed + count))
                count += 1
    return other


def _training_draws(quiet, batch, valid, exact):
    """The training-mode scores of `quiet` (a copy from `_without_dropout`) on `batch` (see `_exact_training_scores`),
    and why the comparisons in training mode cannot run on that copy, or None when they can:

    - its scores still hold a random draw: they change when every generator draws from another seed, torch's, numpy's
      and Python's own (see `_same_draws`) and every torch.Generator or numpy Generator that a module holds (see
      `_reseeded`). A mask drawn by hand (from torch.rand), noise, or a draw from a generator of the model's own stays
      on in that copy, and it follows the slots or the real rows, so a comparison of two batches with other slots or
      other real rows would set other draws side by side;
    - its scores on the real rows (`valid`) are not finite numbers where those of `exact`, the same copy with its
      dropout on, are: a float named for dropout that is not the probability of a drop (a scale, a temperature) broke
      its forward when it was set to zero;
    - its forward stops once its dropout is set to zero (a model that takes the logarithm of its rate, as concrete
      dropout does); the scores are then None.
    """
    try:
        scores = _exact_training_scores(quiet, batch)
    except Exception as error:  # noqa: BLE001
        return None, f"stops once its dropout is set to zero ({type(error).__name__}: {error})"
    if not bool(torch.isfinite(scores[valid]).all()):
        instance = _copy(exact)
        with _full_precision(_float_type(exact)):
            own = _training_call(instance, _batch_as(batch, _float_type(exact)))
        if bool(torch.isfinite(own[valid]).all()):
            return scores, ("gives scores that are not finite numbers once its dropout is set to zero (a float named "
                            "for dropout that is not the probability of a drop)")
    again = _exact_training_scores(_reseeded(quiet, DROPOUT_SEED + 1), batch, seed=DROPOUT_SEED + 1)
    if not _same_values(scores, again):
        return scores, ("draws random numbers that no dropout of it holds (a mask drawn by hand, noise, a generator of "
                        "its own)")
    return scores, None


def _exact_copies(work, batch, valid, say, check, training=True, wide=True):
    """The copies of `work` (a moved model) that the comparisons allowing rounding run on, and their scores on the
    whole `batch`, as a namespace: exact, quiet, whole, whole_training, why and wide.

    exact is a copy of the module `work` holds (the plain module of a model compiled with torch.compile) in 64-bit
    numbers when `wide` asks for it, the model runs there and its scores of the real rows (`valid`) lie within
    AGREEMENT_64 of those of a copy in 32-bit numbers (see `_in_32_bits`), in scoring mode and, with `training`, in
    training mode without dropout; else the 32-bit copy, with one printed line through `say` that names `check` and
    the reason when 64 bits were asked for. Rounding in 64 bits is about 1e-14 of a score, so a model whose history
    is several hundred numbers wide, whose 32-bit rounding reaches the tolerances, keeps them. Every call of a copy
    runs with each narrower float widened to the copy's number type (see `_Widen`), so a mask or a tensor the model
    builds in float32, or a cast it makes inside, does not send it back to 32 bits: the model in use, whose float32
    attention mask torch on the CPU reads otherwise beside float64 weights in training mode, is compared in 64
    bits. A model that stops in 64 bits, with whatever error, or that scores otherwise there (a branch it takes on
    the number type of its numbers), keeps 32 bits. quiet is exact with its dropout off (see `_without_dropout`), whole
    the scoring-mode scores of exact and whole_training those of quiet, why says why the training-mode comparisons
    cannot run on quiet (see `_training_draws`), or None, and wide whether exact is the 64-bit copy of a model that
    is not in 64 bits itself. Without `training`, quiet, whole_training and why are None.
    """
    work = getattr(work, "_orig_mod", work)
    exact = _warmed_by(_in_32_bits(work), work)
    whole = _exact_scores(exact, batch)
    quiet, whole_training, why = None, None, None
    if training:
        quiet = _warmed_by(_without_dropout(exact), work)
        whole_training, why = _training_draws(quiet, batch, valid, exact)
    narrow = types.SimpleNamespace(exact=exact, quiet=quiet, whole=whole, whole_training=whole_training, why=why,
                                   wide=False)
    if not wide or _float_type(exact) == torch.float64:
        return narrow
    try:
        wide = _warmed_by(_in_64_bits(work), work)
        wide_whole = _exact_scores(wide, batch)
        gap = _share(whole[valid], wide_whole[valid])
        wide_quiet, wide_training = None, None
        if training:
            wide_quiet = _warmed_by(_without_dropout(wide), work)
            if why is None:
                wide_training = _exact_training_scores(wide_quiet, batch)
                gap = _worst(gap, _share(whole_training[valid], wide_training[valid]))
    except Exception as error:  # noqa: BLE001
        reason = f"stops ({type(error).__name__}: {error})"
    else:
        if gap <= AGREEMENT_64:
            return types.SimpleNamespace(exact=wide, quiet=wide_quiet, whole=wide_whole, whole_training=wide_training,
                                         why=why, wide=True)
        reason = f"scores the whole batch otherwise than in 32-bit numbers, by {gap:.3g} of a score"
    say(f"{check}: in 64-bit numbers the model {reason}, so the comparisons that allow rounding run in 32-bit numbers, "
        f"whose rounding alone can reach the tolerance in a history several hundred numbers wide")
    return narrow


def _per_window(value, B):
    """Whether `value` holds one entry per window of a batch of B windows: a tensor or a numpy array whose first
    dimension is B, or a list or a tuple of B items. An entry laid out per row is one too."""
    if torch.is_tensor(value) and value.layout != torch.strided:
        return False                      # a sparse tensor is not rolled or cut; a printed line names it
    if torch.is_tensor(value) or (type(value).__module__ == "numpy" and hasattr(value, "shape")):
        return len(value.shape) >= 1 and value.shape[0] == B
    return isinstance(value, (list, tuple)) and len(value) == B


def _per_row(value, B, T):
    """Whether `value` is an ordinary tensor laid out as [B, T, ...], one entry per slot (a sparse one is not)."""
    return (torch.is_tensor(value) and value.layout == torch.strided and value.dim() >= 2
            and tuple(value.shape[:2]) == (B, T))


def _taken(batch, order):
    """The batch with every entry laid out as [B, T, ...] taken in the slot order `order`, int64 [B, T] (order[b, i]
    is the slot whose row goes to slot i); every other entry as it is."""
    B, T = order.shape
    rows = torch.arange(B, device=order.device).unsqueeze(1)
    return {name: value[rows, order] if _per_row(value, B, T) else value for name, value in batch.items()}


def _real(batch, real):
    """bool [B, T], True on real rows: batch[real] when `real` names an entry that is True on real rows, the opposite
    of batch[name] when it is "~name", an entry that is True on padding (real="~is_pad"), and real(batch) when it is
    a function."""
    if callable(real):
        mask = real(batch)
    elif real.startswith("~"):
        mask = ~batch[real[1:]].bool()
    else:
        mask = batch[real]
    return mask.bool()


def _padding_value(value, padded):
    """What every padded slot (`padded`, bool [B, T]) of an entry laid out as [B, T, ...] holds when they all hold one
    value, values that are not a number counted alike; else 0 in the entry's type."""
    held = value[padded]
    if held.shape[0] > 0:
        first = held[0]
        alike = held == first
        if held.is_floating_point() or held.is_complex():
            alike = alike | (torch.isnan(held) & torch.isnan(first))
        if bool(alike.all()):
            return first
    return torch.zeros((), dtype=value.dtype, device=value.device)


def _padding_time(times, valid, units):
    """The time written on a slot the checks make padding: the time every padded slot of the batch holds when they all
    hold one, else 0, as builders write on padding; when the unit `units` is known and a real row (`valid`) lies in
    the second of that time, the other of the two, and when both are taken, two seconds before the earliest real row.
    So no real row's second holds it, and a row that groups the slots of its second by their times alone, without the
    mask, finds no row taken out of the window among them."""
    choices = []
    padded = times[~valid]
    if padded.numel() and bool((padded == padded[0]).all()):
        choices.append(padded[0])
    choices.append(torch.zeros((), dtype=times.dtype, device=times.device))
    if units is None or not bool(valid.any()):
        return choices[0]
    taken = whole_seconds(times[valid], units)
    for choice in choices:
        if not bool((whole_seconds(choice.reshape(1), units) == taken).any()):
            return choice
    earliest = times[valid].min().reshape(1)
    return _later_times(earliest, torch.ones(1, dtype=torch.bool, device=times.device), units, -2)[0]


def _padder(real, pad, time=None, units=None):
    """The function (batch, rows) -> batch that makes the slots in `rows` (bool [B, T]) padding: `pad` when the caller
    hands one; None for a function `real` without `pad`; else one that writes a copy of the batch as a builder writes
    padding: the entry `real` names False on those slots (or True for an entry "~name" that is True on padding), the
    times (the entry `time`) a time in no second of a real row (see `_padding_time`, with the unit `units`), and every
    other entry laid out as [B, T, ...] the value every padded slot of the batch holds when they all hold one, else 0
    (see `_padding_value`).

    The contents matter where rows leave a window (check 3's cut windows at the full width, check 7's rows taken out
    of a second): with the mask alone their inputs and times stay in the padded slots, where a row that groups the
    slots of its second by their times, without the mask, would still find them."""
    if pad is not None:
        return pad
    if callable(real):
        return None
    name, on_padding = (real[1:], True) if real.startswith("~") else (real, False)

    def write(batch, rows):
        out = dict(batch)
        mask = batch[name]
        padded = mask.bool() if on_padding else ~mask.bool()
        B, T = padded.shape
        for key, value in batch.items():
            if key == name or not _per_row(value, B, T):
                continue
            new = value.clone()
            new[rows] = (_padding_time(value, ~padded, units) if key == time
                         else _padding_value(value, padded))
            out[key] = new
        mask = mask.clone()
        mask[rows] = on_padding
        out[name] = mask
        return out

    return write


def _side(pads, check):
    """`pads` as the checks take it, "left", "right" or None; anything else stops with a plain error."""
    if pads not in (None, "left", "right"):
        raise ValueError(f"{check} takes pads=\"left\", pads=\"right\" or None (the side read from the batch), not "
                         f"{pads!r}")
    return pads


def _cut_list(cut):
    """The cuts that `cut` names, as a list of whole numbers: one slot, or several (a list, a range, a tensor or an
    array of them)."""
    if torch.is_tensor(cut) or type(cut).__module__ == "numpy":
        cut = cut.tolist()
    try:
        return [int(k) for k in cut]
    except TypeError:
        return [int(cut)]


def _rebuilt(batch, rebuild):
    """`batch` handed to the caller's `rebuild` (see run_checks), or as it is without one."""
    return batch if rebuild is None else dict(rebuild(batch))


# A whole-number answer entry that holds at most this many distinct values on the real rows is a class or a code: a
# redraw moves each row among the values the entry holds, so that no code is written that the batch does not hold
# (a model may read the codes of earlier rows through a table of its own size). With more it is a quantity.
CLASS_VALUES = 64


def _absent_rows(value, name, absent):
    """Which slots of an answer entry say that the row has no answer, as bool like `value`: where it holds the value
    the caller names for the entry in `absent`; else where a whole-number entry holds a value below 0. A float entry
    says so wherever it holds no finite number (not a number, or infinity for "never"), whatever is named. A
    yes-or-no entry has an answer on every row."""
    if value.dtype == torch.bool:
        return torch.zeros_like(value)
    if absent and name in absent:
        code = absent[name]
        if not value.is_floating_point():
            return value == code
        # a float entry: the named value, and what is no finite number in any case (it cannot be moved)
        if isinstance(code, float) and math.isnan(code):
            return ~torch.isfinite(value)
        return (value == code) | ~torch.isfinite(value)
    if value.is_floating_point():
        return ~torch.isfinite(value)
    return value < 0


def _most_common(values):
    """The most common value of a 1-D tensor, as a 0-d tensor of its type; not a number counts as one value."""
    if values.is_floating_point():
        missing = torch.isnan(values)
        rest = values[~missing]
        if rest.numel():
            codes, counts = torch.unique(rest, return_counts=True)
            if int(counts.max()) > int(missing.sum()):
                return codes[counts.argmax()]
        return torch.tensor(float("nan"), dtype=values.dtype, device=values.device)
    codes, counts = torch.unique(values, return_counts=True)
    return codes[counts.argmax()]


def _next_held(values, pool):
    """Each of `values` moved to the next distinct value of `pool` (the last to the first); a value `pool` does not
    hold moves to the smallest held value above it. With one distinct value in `pool`, that value moves to the one
    below it, or to 1 when it is 0, so that a yes-or-no answer that is the same on every row still turns over."""
    distinct = torch.unique(pool)
    if distinct.numel() == 1:
        only = int(distinct[0])
        return torch.where(values == only, torch.full_like(values, only - 1 if only > 0 else 1),
                           torch.full_like(values, only))
    return distinct[torch.searchsorted(distinct, values, right=True) % distinct.numel()]


def _presence_coded(batch, labels, valid, absent=None):
    """Whether an entry named in `labels` tells an answer by its presence as well as by its value: on a real row
    (`valid`) it holds what says "no answer" (see `_absent_rows`). An outcome is often kept that way: the amount of
    a chargeback that is not a number where there was none, the days to it that are -1, infinite or 9999 where
    there was none. A row that reads only whether its own outcome is there reads its answer."""
    B, T = valid.shape
    for name in (labels,) if isinstance(labels, str) else tuple(labels or ()):
        value = batch.get(name)
        if _per_row(value, B, T) and bool(_absent_rows(value, name, absent)[valid].any()):
            return True
    return False


def _likely_sentinels(batch, labels, valid, absent=None):
    """The lines run_checks prints about an answer entry that looks as if one of its values stood for "no answer"
    without the checks being told: a quantity (a float entry with a value outside [0, 1], or a whole-number entry
    with more than CLASS_VALUES distinct values) in which one value sits on more than half of the real rows that
    have an answer and lies above or below every other. The redraw moves such a value with the others, so a row
    that reads whether its own answer is there may not move; named in `absent`, it is turned over."""
    B, T = valid.shape
    lines = []
    for name in (labels,) if isinstance(labels, str) else tuple(labels or ()):
        value = batch.get(name)
        if not _per_row(value, B, T) or value.dtype == torch.bool or (absent and name in absent):
            continue
        held = value[valid]
        held = held[~_absent_rows(held, name, absent)]
        if held.numel() < 4:
            continue
        codes, counts = torch.unique(held, return_counts=True)
        if codes.numel() < 3 or int(counts.max()) * 2 <= held.numel():
            continue
        quantity = (bool((held < 0).any() or (held > 1).any()) if value.is_floating_point()
                    else codes.numel() > CLASS_VALUES)
        place = int(counts.argmax())
        if quantity and place in (0, codes.numel() - 1):
            code = codes[place].item()
            lines.append(f"run_checks: {name} holds {code:g} on {int(counts.max()):,} of the {held.numel():,} real "
                         f"rows that have an answer, {'below' if place == 0 else 'above'} every other value. If it "
                         f"stands for no answer, name it (absent={{'{name}': {code:g}}}): the checks then turn over "
                         f"whether a row has an answer; as it is, a row that reads only that may not move")
    return lines


def _redrawn(batch, rows, labels, valid=None, presence=False, absent=None):
    """A copy of `batch` in which every entry named in `labels` takes another value on the slots in `rows` (bool
    [B, T]), so that a row that reads its own answer moves.

    A yes-or-no entry is turned over. A whole-number entry that holds at most CLASS_VALUES distinct values on the
    real rows (`valid`; the slots in `rows` without it) is a class or a code: each row moves to the next value the
    entry holds there (the last to the first; see `_next_held`), worked out in int64 and written back in the entry's
    own type, so that no code is written that the batch does not hold. Any other entry is a quantity (a time, an
    amount, a count): it moves by the spread of its values and one more, so that every row lands away from every
    value it held; a float entry whose values lie on [0, 1] becomes 1 minus itself; a whole-number quantity that
    would leave the range of its own type (uint8, int16) moves among the held values as a code does. A slot that
    says "no answer" (see `_absent_rows`: not a finite number, a value below 0 such as -100 on a padded slot, or
    the value named in `absent`) is kept as it is: this redraw moves the value of an answer and keeps whether there
    is one. A name the batch does not hold, or an entry not laid out as [B, T, ...], is passed over.

    With `presence` (and `valid`, the real rows), an entry that tells an answer by its presence (see
    `_presence_coded`) has that presence turned over on those rows instead: where there was none, the row gets one
    (the smallest answer the entry holds on the real rows, so that a loss that reads it finds a value it knows), and
    where there was one, the row loses it (the most common "no answer" of the real rows). Checks 1 and 7 run their
    comparisons once more with it when the batch holds such an entry. The two redraws are kept apart because a
    class entry (0 and 1, with -100 on rows that have no answer) must keep its -100 in the first: a loss that reads
    it as a class stops on any other value below 0.
    """
    out = dict(batch)
    B, T = rows.shape
    if not bool(rows.any()):
        return out
    for name in (labels,) if isinstance(labels, str) else tuple(labels or ()):
        value = batch.get(name)
        if not _per_row(value, B, T):
            continue
        new = value.clone()
        these = value[rows]
        if value.dtype == torch.bool:
            new[rows] = ~these
            out[name] = new
            continue
        none = _absent_rows(these, name, absent)
        pool = value[valid] if valid is not None else these
        gone = _absent_rows(pool, name, absent)
        there = pool[~gone]
        code = absent.get(name) if absent else None
        if presence and valid is not None and bool(gone.any()):
            # An entry that tells an answer by its presence has that presence turned over on the redrawn rows.
            if there.numel():
                present = there.min()
            else:
                present = torch.tensor(1 if code == 0 else (1.0 if value.is_floating_point() else 0),
                                       dtype=value.dtype, device=value.device)
            new[rows] = torch.where(none, present.to(value.dtype), _most_common(pool[gone]).to(value.dtype))
            out[name] = new
            continue
        if not there.numel():
            continue
        if value.is_floating_point():
            if float(there.min()) >= 0.0 and float(there.max()) <= 1.0:
                turned = 1 - these
            else:
                turned = these + (there.max() - there.min() + 1)
            if code is not None and not (isinstance(code, float) and math.isnan(code)):
                turned = torch.where(turned == code, turned + 1, turned)
            new[rows] = torch.where(none, these, turned)
        else:
            wide, held = these.long(), there.long()
            turned = None
            if torch.unique(held).numel() > CLASS_VALUES:
                turned = wide + (int(held.max()) - int(held.min()) + 1)
                if code is not None:
                    turned = torch.where(turned == int(code), turned + 1, turned)
                if bool((turned.to(value.dtype).long() != turned)[~none].any()):
                    turned = None                    # past what the entry's own type can hold
            if turned is None:
                turned = _next_held(wide, held)
            new[rows] = torch.where(none, wide, turned).to(value.dtype)
        out[name] = new
    return out


def _given_unit(units_per_second, check):
    """The unit the caller names, by the rule of masks.py (an int when whole); a plain error when it is left out."""
    if units_per_second is None:
        raise ValueError(f"{check} needs units_per_second: how many units of the batch's times make one second, from "
                         f"the caller (1 for whole seconds, 1_000_000_000 for nanoseconds). The checks never read the "
                         f"unit of the model, so that a wrong unit there cannot pass on the strength of the same "
                         f"wrong unit here")
    return _unit(units_per_second)


def _date(second):
    """A whole second since 1970 as a date in UTC, or its year when no date can hold it."""
    try:
        return datetime.datetime.fromtimestamp(int(second), tz=datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    except (OverflowError, OSError, ValueError):
        # Past the years a date can hold (1 to 9999): the year alone says how far off the unit is.
        return f"year {1970 + float(second) / SECONDS_PER_YEAR:,.0f}"


def _later_times(times, rows, units, seconds):
    """The times of a batch with the rows `rows` moved later by `seconds`, in the unit `units`.

    times     integer or 64-bit float [B, T]
    rows      bool [B, T], True on the rows that move; the other slots keep their times
    seconds   how far, in whole seconds: one number for every row, or a tensor [B, T] that gives each row its own;
              below zero moves the rows earlier

    A row keeps its part inside the second. Float times move in 64-bit floats and keep their number type. Integer
    times move by a whole number of units: seconds * units when the unit is whole, else the nearest whole number of
    units and one at least in the direction of the move (43,500 units of a minute for OTHER_SHIFT_SECONDS, which is
    2,610,000 seconds), so that the move is exact.
    """
    seconds = torch.as_tensor(seconds, device=times.device)
    if times.is_floating_point():
        new = (times.to(torch.float64) + seconds.to(torch.float64) * float(units)).to(times.dtype)
    elif isinstance(units, int):
        new = times + (seconds.to(torch.int64) * units).to(times.dtype)
    else:
        wide = seconds.to(torch.float64)
        step = torch.round(wide * float(units))
        new = times + torch.where(step == 0, torch.sign(wide), step).to(times.dtype)
    return torch.where(rows, new, times)


def _probe_share(b):
    """How far through its real rows the probe of sequence b of check 1 aims, as a share: 1/2 for the first sequence,
    then 1/4, 3/4, 1/8, 5/8, 3/8, 7/8, 1/16 and so on (the binary radical inverse of b + 1), so that the probes of a
    batch spread over the whole window, the more finely the more sequences it holds."""
    share, unit, n = 0.0, 0.5, b + 1
    while n:
        share += unit * (n & 1)
        n >>= 1
        unit /= 2
    return share


def _probes(valid, seconds, late=False):
    """The probe of every sequence for check 1, bool [B, T]: one real row in every sequence that has one.

    valid     bool [B, T], True on real rows
    seconds   their whole seconds, by masks.whole_seconds
    late      True: every probe is the second-to-last real row of its sequence, so that only the rows of its last
              seconds change and every earlier row of the window is compared

    Without `late`, sequence b aims at the rank `_probe_share(b)` of the way through its real rows (count - 2 at
    most, so that a later row is left): the first sequence at the middle, the next ones at the quarters, the eighths
    and so on. When real rows within count // 8 ranks of that aim (one at least) share their whole second with
    another real row, the probe is the one of them nearest the aim, the lower rank on a tie: the other rows of its
    second are then among the changed rows, so that a row that reads a row of its own second moves. Otherwise the
    probe is the row at the aim, wherever the padding lies.
    """
    B = valid.shape[0]
    count = valid.sum(dim=1, keepdim=True)
    rank = valid.long().cumsum(dim=1) - 1
    if late:
        return valid & (rank == (count - 2).clamp(min=0))
    share = torch.tensor([_probe_share(b) for b in range(B)], dtype=torch.float64, device=valid.device).unsqueeze(1)
    target = torch.minimum(torch.floor(share * count).long(), (count - 2).clamp(min=0))
    at = valid & (rank == target)
    # same[b, i, j]: real rows i and j of sequence b share their whole second; the diagonal counts the row itself.
    same = (seconds.unsqueeze(1) == seconds.unsqueeze(2)) & valid.unsqueeze(1) & valid.unsqueeze(2)
    near = (rank - target).abs() <= (count // 8).clamp(min=1)
    shares = valid & near & (same.sum(dim=-1) > 1)
    # Twice the distance from the aim, one more above it: every rank gets a key of its own, and of two ranks at one
    # distance the lower gets the smaller key. A row that shares no second gets a key larger than any other.
    key = (2 * (rank - target).abs() + (rank > target).long()).masked_fill(~shares, 4 * valid.shape[1] + 1)
    nearest = shares & (key == key.min(dim=1, keepdim=True).values)
    return torch.where(shares.any(dim=1, keepdim=True), nearest, at)


def _shared_seconds(valid, seconds):
    """The slots of every second that holds two real rows or more: shared[b] lists, in time order, one int64 tensor of
    slots (in slot order) for each such second of sequence b. Handed the times themselves in place of their seconds,
    it gives the rows that share their time to the last unit."""
    shared = [[] for _ in range(valid.shape[0])]
    for b in range(valid.shape[0]):
        slots = torch.nonzero(valid[b]).flatten()
        their = seconds[b, slots]
        for second in torch.unique(their):
            members = slots[their == second]
            if len(members) > 1:
                shared[b].append(members)
    return shared


def _turned(shared, B, T, g, device):
    """The slot order of check 7's shuffle, int64 [B, T]: order[b, i] is the slot whose row goes to slot i; the rows
    of every group of `shared` (see `_shared_seconds`) change places among their own slots, every row of a group
    moving, and every other slot keeps its row."""
    order = torch.arange(T, device=device).repeat(B, 1)
    for b in range(B):
        for members in shared[b]:
            # A turn by one place moves every row of the group; a random turn first, so that pairs and longer runs
            # are both met, then the turn by one wherever the random one left a row in place.
            turn = torch.randperm(len(members), generator=g).to(members.device)
            if bool((turn == torch.arange(len(members), device=members.device)).any()):
                turn = torch.arange(len(members), device=members.device).roll(1)
            order[b, members] = members[turn]
    return order


def later_rows_change_nothing(model, batch, alter=None, real="mask", time="time_seq", units_per_second=None,
                              move_times=True, labels=("target_seq",), rebuild=None, say=print, absent=None):
    """Check 1: a row does not change when only rows it may not read change, in scoring and in training mode, and
    the later rows do change when the rows they may read change. The first must hold bit for bit.

    model             any model that takes the batch and gives one score per row, [B, T, ...]; it is run as a
                      copy whose weights were moved a little (see `moved`)
    alter             a function (batch, rows) -> batch that returns a copy of the batch in which the inputs of
                      the slots in `rows` (bool [B, T]) are replaced by other values, the times, the mask of
                      real rows and the labels kept; None takes `alter_rows`, which fits `make_batch`
    real              the mask of real rows (PLACEHOLDER W4): the name of an entry that is True on real rows
                      ("mask"), "~" and the name of one that is True on padding ("~is_pad"), or a function
                      batch -> bool [B, T] that is True on real rows
    time              the batch entry of the times (W3)
    units_per_second  the unit of the times (W5), from the caller; it is never read from the model
    move_times        True: the rows of later seconds also move later in time (below); False keeps every time
    labels            the batch entries that hold each row's answer, its label or an outcome code; they are redrawn
                      on the rows of the probe's own second and of later seconds, the probe's own among them (see
                      `_redrawn`). An entry that tells an answer by its presence (no finite number, a value
                      below 0 in a whole-number entry, or the value named in `absent`, where there is none) has
                      that presence turned over in one more pass of the comparison. An entry the batch does not
                      hold is passed over
    absent            a dict {entry: value}: the value by which an entry named in `labels` says that a row has no
                      answer, where that is an ordinary number (see `run_checks`)
    rebuild           a function batch -> batch that writes again every entry the builder works out from other
                      rows, from the slots or from the whole window (a gap column, a slot index, a count, the
                      window's length, the time of its last row); the batch handed over and every batch the check
                      makes go through it. None hands every batch over as the check made it
    say               where a line goes when the check sees nothing or sees a change in training mode only

    Every sequence has one probe (see `_probes`), at a place of its window that changes from sequence to sequence
    (the middle of the first, then the quarters, the eighths and so on): among the real rows near that place that
    share their whole second with another real row, when there are any, the one nearest the place; otherwise the row
    there. What changes is every other real row of the probe's own second or of a later second: the later rows, and
    the rows of the probe's second, which the rule keeps out as well. The comparison then runs once more with every
    probe at the second-to-last real row of its sequence, so that every row but those of the last seconds is kept and
    a leak from the last seconds into any earlier row shows; a leak between two rows elsewhere in the window shows
    where a probe, or a cut of check 3, falls between them (cut=range(1, T) cuts after every slot). Their inputs are
    replaced by `alter`, and the answers of those rows and of the probe are redrawn, so that a row that reads its
    own answer moves. The rows of later
    seconds also move further out in time by whole seconds, their distance from the probe's second doubled and an
    hour added, each keeping its part inside the second: a leak through the times of later rows (a gap, a calendar,
    a bias) then moves a kept row, while every kept row keeps its own time, which the rule lets it read to any
    precision, and a batch in time order by slot stays in time order, so that a model that takes only such batches
    takes this one. Padded slots keep their times; check 2 is about them. The comparison runs in scoring mode and
    again in training mode, each call of the second pass on a fresh copy whose dropout draws the same masks, with
    gradients on (see `_training_scores`), since a part that reads the whole batch in training only, a batch norm
    for instance, leaks there alone. In scoring mode the kept rows are compared three ways (see `_other_scoring`):
    under torch.no_grad(), under torch.inference_mode() and in evaluation mode with gradients on, since a model may
    take a path in one of them alone; a way the model stops in on the batch as handed over is left out, with one
    printed line (see `_other_ways`). Last, the kept rows (the earlier rows and the probe) change and the changed
    rows must move: their inputs are replaced by `alter`, their answers redrawn, and the rows of seconds before the
    probe's move PUSH_SECONDS earlier, so that a history read of inputs, of times (a count of the last hour, a gap)
    or of answers alone moves. The rows the check calls real then read each other, which they do not when the mask
    handed over is True on padding. Training mode here means a training step, with gradients on.

    Returns (kept, changed, read): the largest change of a kept row in either mode, which must be exactly 0.0; the
    largest change of a changed row, which must be above zero, or the check could not have seen a leak; and the
    largest change of a changed row when the kept rows change, which must be above zero as well. A value that is not
    a finite number counts as the largest change. One printed line says so when the kept rows moved in training mode
    only, when neither the kept nor the changed rows moved, and when read is 0.0 (the mask of real rows may be True
    on padding, or the model reads no history; or no changed row has a row of an earlier second among the rows
    `real` names, which padded slots that share one time also give). When no sequence holds rows on both sides of
    its probe, one printed line says why and the answer is (not a number, 0.0, 0.0).
    """
    alter = alter_rows if alter is None else alter
    units = _given_unit(units_per_second, "later_rows_change_nothing")
    batch = _rebuilt(batch, rebuild)
    work = moved(model)
    valid, times = _real(batch, real), batch[time]
    seconds = whole_seconds(times, units)
    # The second of a sequence without a probe is the largest number, so that nothing of it changes.
    biggest = torch.iinfo(seconds.dtype).max if not seconds.is_floating_point() else float("inf")

    def split(probe):
        """The second of each probe, the rows it may not read (the real rows of its own second and of later seconds,
        itself aside), which change, and the rows that may not move (the earlier rows and the probe), which may not
        read a changed row either."""
        probe_second = seconds.masked_fill(~probe, biggest).amin(dim=1, keepdim=True)
        changed = valid & (seconds >= probe_second) & ~probe
        return probe_second, changed, valid & ~changed

    probe = _probes(valid, seconds)
    probe_second, changed, kept = split(probe)
    if not changed.any() or not kept.any():
        say("later_rows_change_nothing: no sequence holds a row on both sides of its probe; check the time unit "
            "and that `real` is True on real rows")
        return float("nan"), 0.0, 0.0
    # Copies of one moved model, so that nothing the model keeps from one call reaches the next; in training mode
    # each on a fresh copy whose dropout draws the same masks.
    before, before_training = _fresh_scores(work, batch), _training_scores(work, batch)
    ways = _other_ways(work, batch, say, "later_rows_change_nothing")
    before_other = _other_scoring(work, batch, ways)

    coded = _presence_coded(batch, labels, valid, absent)

    def changes(probe, presence=False):
        """The largest change of a kept row in scoring and in training mode, and of a changed row in scoring mode,
        when what the probes may not read changes: the inputs of the changed rows, the answers of the changed rows
        and of the probe (no kept row may read any of them, the probe its own answer included), and the times of
        the rows of later seconds."""
        probe_second, changed, kept = split(probe)
        altered = _redrawn(dict(alter(batch, changed)), changed | probe, labels, valid, presence, absent)
        if move_times:
            later = changed & (seconds > probe_second)
            # Only the rows that move are told their distance; the other slots get zero, which also keeps the
            # subtraction away from the largest number that stands for the second of a sequence without a probe.
            away = torch.where(later, seconds - torch.where(later, probe_second, seconds), torch.zeros_like(seconds))
            altered[time] = _later_times(times, later, units, away + PUSH_SECONDS)
        altered = _rebuilt(altered, rebuild)
        after = _fresh_scores(work, altered)
        after_other = _other_scoring(work, altered, ways)
        other_change = _worst(*[_largest(one[kept] - two[kept]) for one, two in zip(before_other, after_other)])
        return (_worst(_largest(before[kept] - after[kept]), other_change),
                _largest(before_training[kept] - _training_scores(work, altered)[kept]),
                _largest(before[changed] - after[changed]))

    scoring, training, changed_change = changes(probe)
    # Once more with every probe at the second-to-last real row of its sequence: only the rows of the last seconds
    # change, so that a leak from them into any earlier row shows.
    late_scoring, late_training, _ = changes(_probes(valid, seconds, late=True))
    scoring, training = _worst(scoring, late_scoring), _worst(training, late_training)
    if coded:
        # Once more with the presence of every answer told by its presence turned over (see `_redrawn`).
        for again in (probe, _probes(valid, seconds, late=True)):
            more_scoring, more_training, _ = changes(again, presence=True)
            scoring, training = _worst(scoring, more_scoring), _worst(training, more_training)
    kept_change = _worst(scoring, training)
    # The other way round, in scoring mode: the kept rows change, and the changed rows must move. Their inputs are
    # replaced, their answers redrawn, and the rows of seconds before the probe's move an hour earlier, every second
    # kept apart and in time order, so that a history read of times or answers alone moves as well.
    reread = _redrawn(dict(alter(batch, kept)), kept, labels, valid, absent=absent)
    if move_times:
        reread[time] = _later_times(times, kept & (seconds < probe_second), units, -PUSH_SECONDS)
    read = _largest(before[changed] - _fresh_scores(work, _rebuilt(reread, rebuild))[changed])
    # Whether any changed row has a real row of an earlier second at all, which the read needs.
    history = changed & ((seconds.unsqueeze(1) < seconds.unsqueeze(2)) & valid.unsqueeze(1)).any(dim=-1)
    if scoring == 0.0 and training != 0.0:
        say(f"later_rows_change_nothing: the kept rows moved by {training:.3g} in training mode only. The usual cause "
            f"is a part that reads the whole batch in training, a batch norm for instance, which lets later rows "
            f"reach earlier ones, or randomness drawn from a generator the model holds itself, which the check "
            f"cannot seed")
    if kept_change == 0.0 and changed_change == 0.0:
        say("later_rows_change_nothing: neither the kept rows nor the changed rows moved. The mask of real rows may be "
            "True on padding (hand the checks real=\"~is_pad\" for such a mask), or `alter` changed nothing")
    if read == 0.0 and not bool(history.any()):
        say("later_rows_change_nothing: no changed row has a real row of an earlier second, so whether the later rows "
            "read the earlier ones cannot be seen on this batch. The rows `real` names may all lie in one second, as "
            "padded slots that share one time do when the mask of real rows is True on padding (hand the checks "
            "real=\"~is_pad\" for such a mask); otherwise hand it a batch whose rows span more than one second")
    elif read == 0.0:
        say("later_rows_change_nothing: the later rows did not move when the earlier rows changed, so the mask of real "
            "rows may be True on padding (hand the checks real=\"~is_pad\" for such a mask) or the model reads no "
            "history")
    return kept_change, changed_change, read


def padding_stays_out(model, batch, fill=None, real="mask", time="time_seq", pad=None, rebuild=None, pads=None,
                      say=print):
    """Check 2: whatever a padded slot holds never reaches a real row, in scoring and in training mode.

    fill         a function (batch, rows, value) -> batch that returns a copy of the batch with every number of
                 the slots in `rows` set to `value` (and their codes changed); None takes `fill_rows`
    real, time   as in `later_rows_change_nothing`
    pad          a function (batch, rows) -> batch that returns a copy of the batch with the slots in `rows` (bool
                 [B, T]) made padding, as the builder writes padding; None writes padding as a builder does (see
                 `_padder`). Read only when the batch has no padded slot (below)
    rebuild      as in `later_rows_change_nothing`; read only for the batch made when there is no padded slot
    pads         as in `prefix_agrees`: the side on which the builder pads, "left", "right" or None; read only when
                 there is no padded slot
    say          where a line goes when the check cannot run, makes a padded slot, or sees a change in training
                 mode only

    The padded slots get values that are not a number, then values of 1e30 (the largest number a floating entry of
    the batch can hold, when that is smaller: 65504 in float16), then an ordinary number (0.5: a model whose
    tokenizer counts a number off its scale as missing reads the first two alike, and a window whose later rows
    were masked out and not cleared holds ordinary numbers), each time with times anywhere at all;
    the model runs as a moved copy, in scoring mode and again in training mode, each call of the second pass on a
    fresh copy whose dropout draws the same masks (see `_training_scores`). Returns (largest change of a real row's
    score in either mode, whether every real row's score stayed finite in both): the change must be exactly 0.0 and
    the scores finite. A value that is not a finite number counts as the largest change. One printed line says so
    when the real rows moved in training mode only; the usual cause is a part that reads the whole batch in
    training, a batch norm for instance. A model that stops with a ValueError in training mode on a batch whose
    padded slots hold such values gives the largest change too, with one printed line that names the error: a
    numeric encoder built with unscaled="raise" stops so when the numbers it reads lie mostly outside [0, 1], which
    they do when the padded slots reach it and are most of the batch, or when `real` is True on padding. A batch
    without a padded slot (full windows) is checked on a copy in which the last real row of its fullest sequence is
    made padding by `pad` (its first real row when `pads` is "left", or when the model stops on that copy, as a
    model that takes only windows padded on the left does), with one printed line that says so. A batch without a
    real row, or without a padded slot when none can be made, shows nothing: one printed line says so and the answer
    is (not a number, True).
    """
    fill = fill_rows if fill is None else fill
    pads = _side(pads, "padding_stays_out")
    work = moved(model)
    valid = _real(batch, real)
    if not valid.any():
        say("padding_stays_out: the batch has no real row; check that `real` is True on real rows")
        return float("nan"), True
    if not (~valid).any():
        padder = _padder(real, pad, time)
        if padder is None or int(valid.sum()) < 2:
            say("padding_stays_out: the batch has no padded slot, and none can be made in a copy (a function `real` "
                "without `pad`, or one real row in all); hand it a batch with padded slots")
            return float("nan"), True
        fullest = int(valid.sum(dim=1).argmax())
        slots = torch.nonzero(valid[fullest]).flatten()
        # The last real row first, as a builder that pads on the right leaves a shorter window; the first when the
        # builder pads on the left, or when the model stops on that copy.
        tries = ((int(slots.max()), "last"), (int(slots.min()), "first"))
        for slot, which in (tries[::-1] if pads == "left" else tries):
            mark = torch.zeros_like(valid)
            mark[fullest, slot] = True
            made = _rebuilt(padder(batch, mark), rebuild)
            try:
                _fresh_scores(work, made)
            except (ValueError, RuntimeError, AssertionError, IndexError) as error:
                stopped_on = error
                continue
            break
        else:
            say(f"padding_stays_out: the batch has no padded slot, and the model stopped on both copies made with one "
                f"({stopped_on}); hand it a batch with padded slots")
            return float("nan"), True
        batch = made
        say(f"padding_stays_out: the batch has no padded slot; in a copy, the {which} real row of sequence {fullest} "
            f"was made padding, and the check ran on that copy")
        valid = _real(batch, real)
    padded = ~valid
    clean, clean_training = _fresh_scores(work, batch), _training_scores(work, batch)
    g = torch.Generator().manual_seed(5)
    scoring, training, finite, stopped = 0.0, 0.0, True, False
    # 1e30, or the largest number a floating entry of the batch can hold when that is smaller (65504 in float16).
    largest = min([1e30] + [torch.finfo(value.dtype).max for value in batch.values()
                            if torch.is_tensor(value) and value.is_floating_point()])
    for value in (float("nan"), largest, 0.5):
        dirty = fill(batch, padded, value)
        # Any time at all, before 1970 or far after today: a padded time must count as no time.
        wild = torch.randint(-10 ** 18, 10 ** 18, (int(padded.sum()),), generator=g).to(device=batch[time].device,
                                                                                        dtype=batch[time].dtype)
        dirty[time] = batch[time].clone()
        dirty[time][padded] = wild
        out = _fresh_scores(work, dirty)
        finite = finite and bool(torch.isfinite(out[valid]).all())
        scoring = _worst(scoring, _largest(out[valid] - clean[valid]))
        try:
            out = _training_scores(work, dirty)
        except ValueError as error:
            # A training step that stops on what the padded slots hold has read them: the worst change, and a line.
            say(f"padding_stays_out: in training mode the model stopped on the batch whose padded slots hold {value}: "
                f"{error}. Padded slots that reach the numeric encoder stop it so; counting them as missing numbers "
                f"before it, as EDIT 1 of BestModel does, keeps them out")
            training, stopped = float("inf"), True
            continue
        finite = finite and bool(torch.isfinite(out[valid]).all())
        training = _worst(training, _largest(out[valid] - clean_training[valid]))
    if scoring == 0.0 and training != 0.0 and not stopped:
        say(f"padding_stays_out: the real rows moved by {training:.3g} in training mode only. The usual cause is a "
            f"part that reads the whole batch in training, a batch norm for instance, which lets padded slots reach "
            f"real rows")
    return _worst(scoring, training), finite


def _time_ordered(valid, seconds):
    """The slot order that puts the real rows of every sequence in time order among their own slots.

    valid     bool [B, T], True on real rows
    seconds   their whole seconds, by masks.whole_seconds

    Returns (order, moved_any): order int64 [B, T], where order[b, i] is the slot whose row goes to slot i, and
    whether any row moves. The real slots of a sequence take its real rows sorted by whole second, a stable sort,
    so the rows of one second keep their slot order and a sequence already in time order keeps every row where it
    is; a padded slot keeps its own row.
    """
    B, T = valid.shape
    order = torch.arange(T, device=valid.device).repeat(B, 1)
    for b in range(B):
        slots = torch.nonzero(valid[b]).flatten()
        order[b, slots] = slots[torch.argsort(seconds[b, slots], stable=True)]
    return order, bool((order != torch.arange(T, device=valid.device)).any())


def _pad_side(valid):
    """The side on which the batch pads, read from its padded slots: "right" when some sequence has a padded slot after
    its last real row, "left" when none has and some sequence has one before its first real row, and None when no
    sequence with a real row has a padded slot before or after its real rows (full windows), so that the side cannot
    be read."""
    B, T = valid.shape
    slots = torch.arange(T, device=valid.device).expand(B, T)
    has = valid.any(dim=1)
    first = torch.where(valid, slots, torch.full_like(slots, T)).amin(dim=1)
    last = torch.where(valid, slots, torch.full_like(slots, -1)).amax(dim=1)
    if bool((has & (last < T - 1)).any()):
        return "right"
    if bool((has & (first > 0)).any()):
        return "left"
    return None


def _relaid(batch, keep, left, padder):
    """The window a builder writes from the rows `keep` (bool [B, T]) alone.

    Returns (a copy of `batch`, where). In the copy every sequence holds the rows of `keep` in their slot order, side
    by side from its first slot, or up to its last slot when `left`, and every other slot is padding, made so by
    `padder` (see `_padder`); every entry laid out as [B, T, ...] moves with its row (see `_taken`). where[b, i] is
    the slot of the copy that holds the row of slot i, -1 for a row left out.
    """
    B, T = keep.shape
    order = torch.empty(B, T, dtype=torch.long, device=keep.device)
    where = torch.full((B, T), -1, dtype=torch.long, device=keep.device)
    held = torch.zeros(B, T, dtype=torch.bool, device=keep.device)
    for b in range(B):
        kept, rest = torch.nonzero(keep[b]).flatten(), torch.nonzero(~keep[b]).flatten()
        start = T - len(kept) if left else 0
        order[b] = torch.cat([rest, kept]) if left else torch.cat([kept, rest])
        where[b, kept] = torch.arange(start, start + len(kept), device=keep.device)
        held[b, start:start + len(kept)] = True
    return padder(_taken(batch, order), ~held), where


def _cut_in_a_second(valid, seconds):
    """A cut of check 3 that splits a second shared by two real rows; None when no second of the batch holds two.

    valid     bool [B, T], True on real rows, in time order among their own slots
    seconds   their whole seconds, by masks.whole_seconds

    A cut after k slots splits a second of a sequence when that second holds a real row before slot k and another
    at slot k or after it. Returns the k, 1 to T - 1, that splits a second in the most sequences, of those the one
    nearest T // 2 (the lower on a tie).
    """
    B, T = valid.shape
    middle = max(1, T // 2)
    valid, seconds = valid.cpu(), seconds.cpu()
    splits = torch.zeros(B, T + 1, dtype=torch.bool)
    for b in range(B):
        slots = torch.nonzero(valid[b]).flatten()
        their = seconds[b, slots]
        for second in torch.unique(their):
            members = slots[their == second]
            if len(members) > 1:
                # Every cut after the first of these slots and up to the last of them splits the second.
                splits[b, int(members.min()) + 1:int(members.max()) + 1] = True
    count = splits.sum(dim=0)
    if int(count.max()) == 0:
        return None
    k = torch.arange(T + 1)
    # Twice the distance from the middle, one more above it, among the cuts that split the most sequences.
    key = (2 * (k - middle).abs() + (k > middle).long()).masked_fill(count < count.max(), 4 * (T + 1))
    return int(torch.argmin(key))


def _cut_near(valid, target):
    """The cut of check 3 nearest `target` that leaves a real row before it and another at it or after it in some
    sequence (the lower cut on a tie); `target` itself, between 1 and T - 1, when no sequence holds two real rows. A
    window that holds its rows at its end (padded on the left) is then still cut among its rows, and a late cut still
    cuts the longest windows of a batch whose other windows end earlier."""
    B, T = valid.shape
    target = min(max(1, int(target)), max(1, T - 1))
    if T < 2:
        return target
    k = torch.arange(1, T, device=valid.device)
    # before[:, k - 1]: the real rows in the slots before cut k.
    before = valid.long().cumsum(dim=1)[:, :-1]
    after = valid.sum(dim=1, keepdim=True) - before
    both = ((before > 0) & (after > 0)).any(dim=0)
    if not bool(both.any()):
        return target
    key = (2 * (k - target).abs() + (k > target).long()).masked_fill(~both, 4 * (T + 1))
    return int(k[torch.argmin(key)])


def _middle_cut(valid):
    """The cut of check 3 near the middle (see `_cut_near`)."""
    return _cut_near(valid, valid.shape[1] // 2)


def _spread_cuts(valid):
    """The cuts of check 3 spread over the window: near the first slot, near every eighth of the width and near the
    last slot (see `_cut_near`), so that a leak that shows only early, in the middle or late in a window is
    compared."""
    T = valid.shape[1]
    targets = [1] + [eighth * T // 8 for eighth in range(1, 8)] + [T - 1]
    return sorted({_cut_near(valid, target) for target in targets})


def prefix_agrees(model, batch, cut=None, real="mask", time="time_seq", units_per_second=None, pad=None, rebuild=None,
                  pads=None, say=print):
    """Check 3: the first k rows of every sequence score as the window cut after row k.

    cut               k, the slot after which the batch is cut, or several such slots (a list, a range, a tensor or
                      an array; range(1, T) cuts after every slot, which finds a leak confined to a few slots anywhere
                      in the window, at T times the cost); None takes the cuts below
    real, time        as in `later_rows_change_nothing`
    units_per_second  the unit of the times (W5), from the caller, to put the real rows in time order
    pad               a function (batch, rows) -> batch that returns a copy of the batch with the slots in `rows`
                      (bool [B, T]) made padding, as the builder writes padding, its times and inputs included; None
                      writes padding as a builder does (see `_padder`). Read to write a cut window on the side the
                      builder pads or at the full width, and to make the slots from a cut on padding in place (below).
                      A `pad` that writes the mask alone leaves the times and inputs of the rows it makes padding in
                      their slots, where a row that reads them without the mask (the rows of its second by their
                      times) still finds them
    rebuild           as in `later_rows_change_nothing`; every cut window goes through it, so that what the builder
                      works out from the whole window (its length, the time of its last row, a count) is written for
                      the cut window
    pads              the side on which the builder pads, "left" or "right"; None reads it from the padded slots of
                      the batch (see `_pad_side`); anything else stops with a plain error
    say               where a line goes when the check cannot run, puts the rows in time order, cannot read the side
                      on which the batch pads, or scores the cut window at the full width because the model stops on
                      a narrower batch

    Grouped scoring scores a window at a time and keeps the scores of its rows; it gives the scores of training
    only when a row's score does not depend on the rows after it in the window. The cut is by slot, so the real
    rows of every sequence are first put in time order among their own slots: a stable sort of the real slots by
    whole second, every entry laid out as [B, T, ...] taken in that order as check 7 takes it, the padded slots left
    where they are. The rows of one second keep their slot order, and a batch already in time order is not changed;
    when the sort moved a row, one printed line says so. Without a cut named, the batch is cut inside a second
    shared by two real rows, in as many sequences as one cut can (see `_cut_in_a_second`), so that a row that reads
    how many rows share its second (a position counted with <= in place of <, the size of a burst) sees fewer of them
    and moves; and near the first slot, near every eighth of the width and near the last slot, each cut leaving real
    rows on both sides of it in some sequence (see `_spread_cuts`), so that a leak that shows only early, in the
    middle or late in a window is compared.

    The cut window is the window a builder writes from the kept rows alone: every entry laid out as [B, T, ...]
    sliced to its first k slots, the other entries kept; and, when the builder pads on the left, also the window at
    the full width T with the kept rows at its end and every other slot made padding by `pad` (see `_relaid`), so
    that a row that reads how much padding lies in front of it, which holds the length of the whole window, moves
    too. A window with real rows but none before the cut (padded on the left) keeps its earliest real row, which is
    not compared, so that no cut window is empty. A batch of full windows does not say on which side its builder pads:
    unless `pads` says so, its cut windows are compared as slices, with one printed line. When the model stops with an
    error on a narrower batch, every cut window is written at the full width as the builder pads (on the right, then
    on the left, for a batch of full windows), and the check cannot run when the model stops there too, or when that
    window needs `pad` and there is none; it then gives not a number, with one printed line.

    The cut windows are scored by a moved copy in 64-bit numbers with autocast off, where rounding is about 1e-14 of a
    score, when the model runs there and scores the whole batch there as in 32-bit numbers; else by a copy in 32-bit
    numbers with float32 products at full precision, with one printed line (see `_exact_copies`). In either copy a
    narrower float the model builds or casts to inside is widened (see `_Widen`), so the rounding of a model in 16
    bits does not count. They are scored in scoring mode, and again in training mode with gradients on, on a copy
    whose dropout is off (see `_without_dropout`), so that a part that reads the whole window in training mode alone
    (its share of the window, a batch norm) moves too. When that copy still draws random numbers in training mode,
    gives scores that are not finite numbers once its dropout is set to zero, or stops there (see `_training_draws`),
    the cut windows are compared in scoring mode alone, with one printed line. When the windows move beyond the
    tolerance in 64 bits and not in 32, the 32-bit comparison stands, with one printed line: the model reads its
    numbers otherwise in 64 bits there.

    Last, the pass in place: the moved model as handed over, in its own number type, scores the window whose slots
    from every cut on are made padding in place, whichever side the batch pads on. It is scored the three ways a
    scorer may score (under torch.no_grad(), under torch.inference_mode(), in evaluation mode with gradients on; see
    `_other_scoring`; a way the model stops in is left out, with a line). Same slots and shapes, so a model whose
    arithmetic follows the slots keeps a row before the cut bit for bit. A model that trims its batch to the longest
    window, packs its real rows or groups them by second works over other shapes once the later slots are padding,
    and its own rounding moves the row (TODAY behind a trim by 2e-6 of a score). The two are told apart on the
    64-bit copy, which scores the same window: a move of at most IN_PLACE_ROUNDING there is rounding, and the move
    counts as it is, with one printed line; a larger one is a read of the later rows and fails the check, as does
    any move of PREFIX_TOLERANCE or more. Where no 64-bit copy runs, a move under PREFIX_TOLERANCE counts as
    rounding, with the line. A read under PREFIX_TOLERANCE that the model takes in its own number type alone
    cannot be told from rounding and passes with that line. Where two scorings of the unchanged batch already
    differ (kernels that are not deterministic), the tolerance holds. The pass needs padding written in place: with
    a function `real` and no `pad` it does not run, and one printed line says so.

    Returns the largest difference over the real rows among the first k slots, over every cut, both modes and the
    model in its own number type, as a share of the score it differs from (or of 1 when that score is smaller than 1);
    it must be below PREFIX_TOLERANCE (a read found by the pass in place counts as PREFIX_TOLERANCE at least). Without a
    real row before any cut, one printed line says so and the answer is not a number. The cut window agrees to
    rounding and not bit for bit, since its arithmetic runs over another length or other slots.
    """
    units = _given_unit(units_per_second, "prefix_agrees")
    pads = _side(pads, "prefix_agrees")
    batch = _rebuilt(batch, rebuild)
    valid = _real(batch, real)
    order, moved_any = _time_ordered(valid, whole_seconds(batch[time], units))
    if moved_any:
        say("prefix_agrees: the real rows were not in time order by slot; they were put in time order among their own "
            "slots before the cut")
        batch = _rebuilt(_taken(batch, order), rebuild)
        valid = _real(batch, real)
    B, T = valid.shape
    if cut is None:
        split = _cut_in_a_second(valid, whole_seconds(batch[time], units))
        cuts = sorted({k for k in [split, *_spread_cuts(valid)] if k is not None})
    else:
        cuts = sorted(set(_cut_list(cut)))
    side, padder = pads or _pad_side(valid), _padder(real, pad, time, units)
    if side == "left" and padder is None:
        say("prefix_agrees: the batch pads on the left, and its cut window as the builder writes it (the kept rows at "
            "the end, padding in front) needs `pad`, a function (batch, rows) -> batch that makes the slots in rows "
            "padding, since `real` is a function; the check cannot run without it")
        return float("nan")
    if side is None and not bool((~valid).any()):
        say("prefix_agrees: the batch holds no padded slot, so the side on which its builder pads cannot be read; the "
            "cut windows are compared as slices. Hand the checks pads=\"left\" for a builder that pads on the left, "
            "so that a row that reads the padding in front of it is checked")
    slots = torch.arange(T, device=valid.device)
    first_real = torch.where(valid, slots, torch.full_like(slots, T)).amin(dim=1)
    if not any(bool((valid & (slots < k)).any()) for k in cuts):
        say("prefix_agrees: no real row lies before the cut in any sequence; hand it a batch with real rows, and check "
            "that `real` is True on real rows")
        return float("nan")

    def kept(k):
        """The real rows before cut k, and the rows the cut window holds: those, and the earliest real row of a window
        that holds none of them, which is not compared, so that no cut window is empty (a model may stop on a window
        without a real row)."""
        rows = valid & (slots < k)
        empty = valid.any(dim=1) & ~rows.any(dim=1)
        return rows, rows | (empty.unsqueeze(1) & (slots == first_real.unsqueeze(1)))

    def compared(copies, tell):
        """The largest share over every cut window scored by `copies` (see `_exact_copies`), lines through `tell`; not
        a number when a window cannot be written or scored."""
        worst, stopped = 0.0, None
        for k in cuts:
            rows, keep = kept(k)
            if not rows.any():
                continue
            b, i = torch.nonzero(rows, as_tuple=True)
            if stopped is None:
                if bool((keep & ~rows).any()) and padder is not None:
                    # The window written from the kept rows on the side the builder pads, then cut to its k slots
                    # there.
                    laid, where = _relaid(batch, keep, side == "left", padder)
                    start = T - k if side == "left" else 0
                    short = {name: value[:, start:start + k] if _per_row(value, B, T) else value
                             for name, value in laid.items()}
                    at = where[b, i] - start
                else:
                    short = {name: value[:, :k] if _per_row(value, B, T) else value for name, value in batch.items()}
                    at = i
                short = _rebuilt(short, rebuild)
                try:
                    part = _exact_scores(copies.exact, short)
                except (ValueError, RuntimeError, AssertionError, IndexError) as error:
                    stopped = error
                    tell(f"prefix_agrees: the model stopped on the window cut to {k} of {T} slots ({error}); every cut "
                         f"window is scored at the full width instead, its other slots made padding")
                else:
                    worst = _worst(worst, _share(copies.whole[b, i], part[b, at]))
                    if copies.why is None:
                        worst = _worst(worst, _share(copies.whole_training[b, i],
                                                     _exact_training_scores(copies.quiet, short)[b, at]))
            if side != "left" and stopped is None:
                continue
            if padder is None:
                tell("prefix_agrees: a cut window at the full width needs `pad`, a function (batch, rows) -> batch "
                     "that makes the slots in rows padding, since `real` is a function; the check cannot run without "
                     "it")
                return float("nan")
            # The window at the full width as the builder writes it: on the side it pads, and for a batch of full
            # windows on the right, then on the left when the model stops there.
            written = None
            for left in ([side == "left"] if side is not None else [False, True]):
                long, where = _relaid(batch, keep, left, padder)
                long = _rebuilt(long, rebuild)
                try:
                    out = _exact_scores(copies.exact, long)
                except (ValueError, RuntimeError, AssertionError, IndexError) as error:
                    failure = error
                    continue
                written = (long, where, out)
                break
            if written is None:
                tell(f"prefix_agrees: the model stopped on the cut window at the full width as well ({failure}); the "
                     f"check cannot run")
                return float("nan")
            long, where, out = written
            worst = _worst(worst, _share(copies.whole[b, i], out[b, where[b, i]]))
            if copies.why is None:
                worst = _worst(worst, _share(copies.whole_training[b, i],
                                             _exact_training_scores(copies.quiet, long)[b, where[b, i]]))
        return worst

    work = moved(model)
    copies = _exact_copies(work, batch, valid, say, "prefix_agrees")
    if copies.why is not None:
        say(f"prefix_agrees: in training mode the copy whose dropout is off {copies.why}, so the cut windows are "
            f"compared in scoring mode alone, and a part that reads the window in training mode alone (its share of "
            f"the window, a batch norm) is not seen")
    worst = compared(copies, say)
    if copies.wide and not worst < PREFIX_TOLERANCE:
        # The whole batch agreed in 64 and 32 bits, but a model may read its numbers otherwise in 64 bits on a window
        # of another length; the same windows in 32 bits decide when they keep the tolerance there.
        first, second = worst, compared(_exact_copies(work, batch, valid, say, "prefix_agrees", wide=False),
                                        lambda line: None)
        if second < PREFIX_TOLERANCE:
            say(f"prefix_agrees: the cut windows moved by {first:.3g} in 64-bit numbers and by {second:.3g} in 32-bit "
                f"numbers; the model reads its numbers otherwise in 64 bits there, so the 32-bit comparison stands")
            worst = second
    # The model as handed over, in its own number type, on the window whose slots from the cut on are made padding in
    # place, whichever side the batch is padded on: a part that reads the window only in that type (a path taken in
    # 16 bits alone) moves there as well. It is scored the three ways a scorer may score (no gradients, under
    # torch.inference_mode(), evaluation mode with gradients on), so that a read of later rows taken in one of them
    # alone moves too. Same slots, same shapes, so the scores of a model whose arithmetic follows the slots agree
    # bit for bit.
    if padder is None:
        say("prefix_agrees: the model in its own number type is not scored on its slots made padding in place, "
            "which needs `pad` when `real` is a function")
    else:
        ways = _other_ways(work, batch, say, "prefix_agrees")
        own, own_other = _fresh_scores(work, batch), _other_scoring(work, batch, ways)
        # Bit for bit, unless two scorings of the same batch already differ (kernels that are not deterministic).
        exact = _same_values(own, _fresh_scores(work, batch))
        told = False
        for k in cuts:
            rows, keep = kept(k)
            if not rows.any():
                continue
            try:
                window = _rebuilt(padder(batch, (slots >= k) & ~keep), rebuild)
                out, out_other = _fresh_scores(work, window), _other_scoring(work, window, ways)
            except (ValueError, RuntimeError, AssertionError, IndexError) as error:
                say(f"prefix_agrees: the model stopped on the window whose slots from the cut on were made padding in "
                    f"place ({error}); the model in its own number type is not compared")
                break
            b, i = torch.nonzero(rows, as_tuple=True)
            moved_by = _worst(_share(own[b, i].double(), out[b, i].double()),
                              *[_share(one[b, i].double(), two[b, i].double())
                                for one, two in zip(own_other, out_other)])
            if exact and moved_by > 0.0:
                # A model that trims the window to its real rows, packs them or groups them by second runs over
                # other shapes once the later slots are padding, and its own rounding moves the kept rows. The same
                # window on the 64-bit copy tells the two apart: rounding shrinks to about 1e-14 there, a read of
                # the later rows does not. Where no 64-bit copy runs, a move under the tolerance counts as rounding.
                wide_move = None
                if copies.wide and moved_by < PREFIX_TOLERANCE:
                    try:
                        wide_move = _share(copies.whole[b, i], _exact_scores(copies.exact, window)[b, i])
                    except (ValueError, RuntimeError, AssertionError, IndexError):
                        pass
                if moved_by >= PREFIX_TOLERANCE or (wide_move is not None and wide_move > IN_PLACE_ROUNDING):
                    say(f"prefix_agrees: in its own number type the rows before the cut after slot {k} moved by "
                        f"{moved_by:.3g} when the slots from the cut on were made padding in place"
                        + ("" if wide_move is None else f", and by {wide_move:.3g} in 64-bit numbers")
                        + "; they must not move")
                    moved_by = max(moved_by, PREFIX_TOLERANCE)
                elif not told:
                    say(f"prefix_agrees: in its own number type the rows before the cut after slot {k} moved by "
                        f"{moved_by:.3g} when the slots from the cut on were made padding in place"
                        + (", which no copy in 64-bit numbers could be set against" if wide_move is None
                           else f", and by {wide_move:.3g} in 64-bit numbers")
                        + ": rounding over other shapes (a model that trims the window to its real rows, packs them "
                          "or groups them works over other shapes then), not a read of the later rows")
                    told = True
            worst = _worst(worst, moved_by)
    return worst


def every_weight_learns(model, batch, loss=None, seed=1):
    """Check 4: one training step gives every trainable weight of the model a gradient.

    loss   a function (model, batch) -> scalar, the training loss of the model in use (PLACEHOLDER W25); None
           takes `row_loss`
    seed   the seed of the moved copy and of the dropout of the step

    The step runs on a moved copy in training mode: a fresh part that starts at zero would keep the weights
    behind it from their first gradient, and that says nothing about the wiring. Returns the names of the
    weights that got no gradient, one that is not finite, or one that is zero everywhere; the list must be
    empty. Weights held still on purpose (requires_grad False, the frozen centres of learn_centres=False) are
    not listed. Two weights of a RecentFieldMemory may have a zero gradient by design and are not listed: the
    constant term of its keys, and its look-back vector when it holds the row's own fields only. Each shifts
    every key of a row alike, which attention cannot see (a softmax does not change when all its inputs move
    together), so their gradient is zero in exact arithmetic. A weight without numbers is not listed either
    (AttentionBias without match fields holds two).
    """
    loss = row_loss if loss is None else loss
    work = moved(model, seed=seed).train()
    # The dropout of the step draws from a stream of its own, so that the answer is the same in every run and the
    # random state of the caller (torch on the CPU and on every CUDA device of the weights, Python's random module
    # and numpy) is left as it was.
    with _same_draws(seed, _devices(work)), torch.enable_grad():
        work.zero_grad(set_to_none=True)
        loss(work, _handed(batch)).backward()
    # The two weights of every memory whose gradient is zero in exact arithmetic (see above), found by their module,
    # so that the memory of the re-reads and the bank of the channel stage are both covered wherever they sit.
    by_design = set()
    for name, module in work.named_modules():
        if isinstance(module, RecentFieldMemory):
            prefix = f"{name}." if name else ""
            by_design.add(f"{prefix}key.bias")
            if module.num_back == 0:
                by_design.add(f"{prefix}back_key")
    unlearned = []
    for name, weight in work.named_parameters():
        if not weight.requires_grad or weight.numel() == 0:
            continue
        grad = weight.grad
        if grad is None or not bool(torch.isfinite(grad).all()):
            unlearned.append(name)
        elif not bool(grad.abs().sum() > 0) and name not in by_design:
            unlearned.append(name)
    return unlearned


def time_unit_fits(batch, units_per_second=None, real="mask", time="time_seq", say=print):
    """Check 5: the times of the real rows, read with the unit the caller names, lie between 2000 and 2100.

    units_per_second  how many units of the batch's times make one second (PLACEHOLDER W5), from the caller and
                      never from the model, so that a model and its checks cannot share one wrong unit unseen
    real, time        as in `later_rows_change_nothing`
    say               where the line with the two dates goes; print by default

    Returns (first, last, fits): the earliest and the latest real row as dates in UTC (or as their year, when no
    date can hold it), and whether both lie from 2000-01-01 up to 2100-01-01. Nanoseconds read as seconds give
    a year in the billions and seconds read as nanoseconds the year 1970, so either fails here; the other checks
    measure seconds with the same unit, and a wrong one would blind them. Without a real row the answer is
    (None, None, False) and the printed line says so.
    """
    units = _given_unit(units_per_second, "time_unit_fits")
    valid = _real(batch, real)
    if not valid.any():
        say("time unit: the batch has no real row; check that `real` is True on real rows")
        return None, None, False
    seconds = whole_seconds(batch[time], units)[valid]
    low, high = seconds.min().item(), seconds.max().item()
    # A comparison with a value that is not a number is False, so times that are not numbers fail as well.
    fits = bool(EARLIEST_SECOND <= low and high < LATEST_SECOND)
    first, last = _date(low), _date(high)
    say(f"time unit: the real rows run from {first} to {last} at {units:,} units per second, "
        f"{'inside' if fits else 'OUTSIDE'} 2000-01-01 to 2100-01-01")
    return first, last, fits


def _other_batch(batch, sequences, alter, real, time, units):
    """The second batch of check 6 when the caller hands none, built from `batch`.

    Its sequences are those of `batch` rolled by one place (every entry with one item per window: a tensor or a
    numpy array whose first dimension is the batch size, or a list or a tuple of that length; a batch of one sequence
    is not rolled), every input of every real row is replaced by `alter`, and every real row moves later by
    OTHER_SHIFT_SECONDS in the unit `units` (see `_later_times`); padded slots keep their times.
    """
    def roll(value):
        if torch.is_tensor(value):
            return value.roll(1, dims=0)
        if isinstance(value, (list, tuple)):
            return value[-1:] + value[:-1]
        return value[[-1, *range(len(value) - 1)]]

    rolled = batch if sequences < 2 else {name: roll(value) if _per_window(value, sequences) else value
                                          for name, value in batch.items()}
    valid = _real(rolled, real)
    other = dict(alter(rolled, valid))
    other[time] = _later_times(rolled[time], valid, units, OTHER_SHIFT_SECONDS)
    return other


# The instances `build` has handed back (see `_new_instance`).
_BUILT = weakref.WeakSet()


def _new_instance(work, build, source=None):
    """An instance that has never been called, with the weights and buffers of `source` (`work` when None): build()
    with a copy of that state put in its place (load_state_dict with assign=True, so that every tensor keeps the
    number type and the device it had); a deep copy of `work` with that state loaded when there is no `build`, or a
    deep copy of `work` alone when there is no `source` either. A model compiled with torch.compile is read and
    written through the module it wraps (`_orig_mod`), and that module is handed back, so that `build` may give the
    compiled model or the plain one."""
    if build is None and source is None:
        return _copy(work)
    instance = build() if build is not None else _copy(work)
    if build is not None:
        plain = getattr(instance, "_orig_mod", instance)
        if any(plain is getattr(known, "_orig_mod", known) for known in (work, source) if known is not None) or (
                plain in _BUILT):
            raise ValueError("`build` handed back the model itself, or an instance it handed back before: the checks "
                             "put moved weights into what it returns, so it has to return a new instance at every "
                             "call (build=lambda: Model(config))")
        _BUILT.add(plain)
    held = work if source is None else source
    state = {name: value.detach().clone() if torch.is_tensor(value) else copy.deepcopy(value)
             for name, value in getattr(held, "_orig_mod", held).state_dict().items()}
    target = getattr(instance, "_orig_mod", instance)

    def load(**how):
        try:
            target.load_state_dict(state, **how)
        except RuntimeError as error:
            # A buffer the model registers on a call is state of that call: an instance never called has none, and
            # makes its own on its first call.
            text = str(error)
            if "Unexpected key(s)" not in text or "Missing key(s)" in text or "size mismatch" in text:
                raise
            target.load_state_dict(state, strict=False, **how)

    try:
        load(assign=True)
    except TypeError:
        # A torch before 2.1 has no assign: the values are copied in, and the instance goes to the device of work.
        load()
        reference = next(iter([*work.parameters(), *work.buffers()]), None)
        if reference is not None:
            instance = instance.to(reference.device)
    # A weight held still on the model handed over (requires_grad False, set on the instance after it was built) is
    # held still on the new instance too: check 4 leaves it out there as it does on the model itself.
    flags = {name: weight.requires_grad for name, weight in getattr(held, "_orig_mod", held).named_parameters()}
    for name, weight in target.named_parameters():
        if name in flags and weight.is_leaf:
            weight.requires_grad_(flags[name])
    return getattr(instance, "_orig_mod", instance)


def _tensor_snapshot(value):
    """A tensor in a form `_same_snapshot` compares: a copy; a sparse one as its shape, its indices and its values;
    one of a layout that gives neither, by its identity."""
    value = value.detach()
    if value.layout == torch.strided:
        return ("tensor", value.clone())
    try:
        held = (value if value.layout == torch.sparse_coo else value.to_sparse()).coalesce()
        return ("sequence", [("plain", ("sparse", tuple(held.shape), str(held.dtype))),
                             ("tensor", held.indices().clone()), ("tensor", held.values().clone())])
    except Exception:  # noqa: BLE001
        return ("plain", ("id", id(value)))


def _snapshot(value, identity, depth=0):
    """What `value` holds, in a form `_same_snapshot` can set against a later one: a tensor is copied, a numpy array
    kept as its shape, type and bytes, a plain value kept, a list, a tuple or a dict read through (two levels deep), a
    set kept by its size, and anything else known by its identity when `identity`, else by the name of its type."""
    if torch.is_tensor(value):
        return _tensor_snapshot(value)
    if type(value).__module__ == "numpy" and hasattr(value, "tobytes") and hasattr(value, "dtype"):
        return ("plain", (getattr(value, "shape", ()), str(value.dtype), value.tobytes()))
    if value is None or isinstance(value, (bool, int, float, complex, str, bytes)):
        return ("plain", value)
    if depth < 2 and isinstance(value, (list, tuple)):
        return ("sequence", [_snapshot(item, identity, depth + 1) for item in value])
    if depth < 2 and isinstance(value, dict):
        return ("dict", [(repr(key), _snapshot(item, identity, depth + 1)) for key, item in value.items()])
    if isinstance(value, (set, frozenset)):
        return ("set", len(value))
    return ("object", id(value) if identity else type(value).__qualname__)


def _same_snapshot(first, second):
    """Whether two results of `_snapshot` hold the same thing; values that are not a number count as the same."""
    if first[0] != second[0]:
        return False
    kind, a, b = first[0], first[1], second[1]
    if kind == "tensor":
        if a.shape != b.shape or a.dtype != b.dtype or a.device != b.device:
            return False
        if a.is_floating_point() or a.is_complex():
            return bool(((a == b) | (torch.isnan(a) & torch.isnan(b))).all())
        return bool(torch.equal(a, b))
    if kind == "sequence":
        return len(a) == len(b) and all(_same_snapshot(x, y) for x, y in zip(a, b))
    if kind == "dict":
        return len(a) == len(b) and all(ka == kb and _same_snapshot(x, y) for (ka, x), (kb, y) in zip(a, b))
    return a == b or (a != a and b != b)


def _instance_state(model):
    """Everything an instance holds besides its weights, by name (see `_snapshot`): every buffer and every attribute
    of every module that is not one of torch's own. An object is known by its type, so that two copies of one model
    hold the same."""
    held = {f"buffer {name}": _snapshot(buffer, False) for name, buffer in model.named_buffers()}
    for name, module in model.named_modules():
        prefix = f"{name}." if name else ""
        for key, value in vars(module).items():
            if key not in _TORCH_ENTRIES:
                held[prefix + key] = _snapshot(value, False)
    return held


def _class_values(model):
    """Every attribute of the class of every module of `model`, and of every base class of it that is code of the
    model (see `_model_code`), that is not a method, a property or a name of Python's own, by name: what every
    instance of the class shares. A store defined on a base class and used as self.memo is one."""
    held, classes, packages = {}, set(), _model_packages(model)
    for module in model.modules():
        for kind in (type(module),) + tuple(base for base in type(module).__mro__[1:]
                                            if base is not object and _model_code(base.__module__, packages)):
            if kind in classes:
                continue
            classes.add(kind)
            for key, value in vars(kind).items():
                if key.startswith("__") or callable(value) or isinstance(value, (property, staticmethod,
                                                                                 classmethod)):
                    continue
                held[f"{kind.__name__}.{key}"] = value
    return held


def _class_state(model):
    """The values of `_class_values`, each as `_snapshot` keeps it (an object is known by its identity)."""
    return {name: _snapshot(value, True) for name, value in _class_values(model).items()}


_OUTSIDE_DEPTH = 8
_LARGE = 2 ** 20  # bytes: a tensor or an array above this size is known by a mark and a sample, not by a copy
_MANY = 100_000   # items: a longer list, dict or set is known by its count and (a set aside) a sample of its items
_SKIPPED_ROOTS = {"torch", "numpy", "builtins"} | set(getattr(sys, "stdlib_module_names", ()))


def _own_code(module):
    """Whether a module is the caller's own code: the script or the notebook itself (`__main__`), or a file that lies
    neither among the installed packages (site-packages, dist-packages) nor in Python's own library."""
    if module is None:
        return False
    if getattr(module, "__name__", "") == "__main__":
        return True
    path = getattr(module, "__file__", None) or ""
    stdlib = sysconfig.get_paths().get("stdlib", "")
    return bool(path) and "site-packages" not in path and "dist-packages" not in path and not (
        stdlib and path.startswith(stdlib))


def _model_packages(model):
    """The top-level packages that hold the classes of the modules of `model`, torch's, numpy's and Python's own
    aside: where the code of the model lies (`__main__` for a class defined in a script or a notebook)."""
    return frozenset(type(module).__module__.split(".")[0] for module in model.modules()) - _SKIPPED_ROOTS


def _model_code(name, packages):
    """Whether the module called `name` is code of the model: it lies in one of `packages` (see `_model_packages`)
    or is the caller's own code (see `_own_code`). The code of a library the model builds on (a base class of a
    training framework, a logger) is not: what such code keeps for itself changes without the model reading it."""
    name = name or ""
    return name.split(".")[0] in packages or _own_code(sys.modules.get(name))


def _written_in(function):
    """The name of the module a function's code was written in, from its globals. Its __module__ is not asked:
    functools.wraps gives a wrapper the name of the module of what it wraps, and the wrapper of a library around a
    method of the model would pass for code of the model."""
    return function.__globals__.get("__name__", "")


def _own_class(kind, packages=frozenset()):
    """Whether objects of a class are read through their attributes: a class of the code of the model (see
    `_model_code`) or types.SimpleNamespace. An object of a library (a logger, a lock, a client) is known by its
    identity."""
    return kind is types.SimpleNamespace or _model_code(getattr(kind, "__module__", None), packages)


def _is_cache(value):
    """Whether `value` is a function behind functools.lru_cache or functools.cache, told by its type: no attribute
    is asked of an object that may answer any name, or stop on one it does not hold."""
    kind = type(value)
    if kind.__name__ == "_lru_cache_wrapper" and kind.__module__ == "functools":
        return True
    return isinstance(value, types.FunctionType) and all(callable(vars(value).get(name))
                                                         for name in ("cache_info", "cache_clear"))


def _cache_snapshot(value):
    """How many answers a functools cache holds, in the form `_same_snapshot` compares."""
    try:
        return ("plain", ("cached answers", int(value.cache_info().currsize)))
    except Exception:  # noqa: BLE001
        return ("plain", ("id", id(value)))


def _large_mark(value):
    """A tensor or a numpy array above `_LARGE` bytes, in a form that shows a write without a copy of it: which
    object it is, where its numbers lie, its shape and type, the count of its in-place writes (a tensor's) and
    about 4,096 of its numbers taken at even steps. A write that misses every sampled number and is made around
    torch's count (through .data, through a numpy view) is not seen. None for anything else."""
    try:
        if torch.is_tensor(value):
            if value.numel() * value.element_size() <= _LARGE:
                return None
            flat = value.detach().reshape(-1)
            sample = flat[:: max(1, flat.numel() // 4096)].clone()
            try:
                version = value._version
            except RuntimeError:  # an inference tensor counts no writes
                version = None
            return ("sequence", [("plain", ("large", id(value), value.data_ptr(), tuple(value.shape), str(value.dtype),
                                            version)), ("tensor", sample)])
        if type(value).__module__ == "numpy" and hasattr(value, "tobytes") and hasattr(value, "dtype"):
            if getattr(value, "nbytes", 0) <= _LARGE:
                return None
            flat = value.reshape(-1)
            return ("plain", ("large", id(value), value.__array_interface__["data"][0], tuple(value.shape),
                              str(value.dtype), flat[:: max(1, flat.size // 4096)].tobytes()))
    except Exception:  # noqa: BLE001 - a tensor with no plain storage (sparse, meta) is known by its identity
        return ("plain", ("id", id(value)))
    return None


def _deep_snapshot(value, path=(), packages=frozenset()):
    """What `value` holds, in a form `_same_snapshot` can set against a later one, read through dicts, lists, tuples,
    deques, sets (by the reprs of their items), objects of the classes of the model's code (their __dict__ and
    __slots__, see `_own_class`) and functions (their defaults and the cells of their closure), up to
    `_OUTSIDE_DEPTH` levels and never twice along one path. A tensor or an array is copied, or marked when it is
    large (see `_large_mark`); a plain value is kept; anything else is known by its identity. A list, a dict or a
    deque of more than `_MANY` items is known by its count and by about 4,096 of its items taken at even steps, a
    set that long by its count alone: an item rewritten between the sampled ones is not seen."""
    large = _large_mark(value)
    if large is not None:
        return large
    if torch.is_tensor(value):
        return _tensor_snapshot(value)
    if type(value).__module__ == "numpy" and hasattr(value, "tobytes") and hasattr(value, "dtype"):
        return ("plain", (getattr(value, "shape", ()), str(value.dtype), value.tobytes()))
    if value is None or isinstance(value, (bool, int, float, complex, str, bytes)):
        return ("plain", value)
    if id(value) in path or len(path) >= _OUTSIDE_DEPTH or isinstance(value, (type, types.ModuleType, nn.Module)):
        return ("plain", ("id", id(value)))
    path = path + (id(value),)

    def inner(item):
        return _deep_snapshot(item, path, packages)

    def sampled(items, count):
        if count <= _MANY:
            return [], list(items)
        return [("plain", ("items", count))], list(itertools.islice(items, 0, None, count // 4096))

    if isinstance(value, dict):
        count, items = sampled(value.items(), len(value))
        return ("dict", [("items", mark) for mark in count] + [(repr(key), inner(item)) for key, item in items])
    if isinstance(value, (list, tuple, collections.deque)):
        count, items = sampled(value, len(value))
        return ("sequence", count + [inner(item) for item in items])
    if isinstance(value, (set, frozenset)):
        if len(value) > _MANY:
            return ("plain", ("items", len(value)))
        return ("plain", tuple(sorted(repr(item) for item in value)))
    if isinstance(value, types.FunctionType):
        cells = []
        for cell in value.__closure__ or ():
            try:
                cells.append(cell.cell_contents)
            except ValueError:  # a cell not filled yet
                cells.append(None)
        return ("sequence", [inner(value.__defaults__), inner(value.__kwdefaults__), inner(tuple(cells))])
    if callable(value) or not _own_class(type(value), packages):
        return ("plain", ("id", id(value)))
    held = dict(getattr(value, "__dict__", None) or {})
    for kind in type(value).__mro__:
        slots = vars(kind).get("__slots__", ())
        for name in (slots,) if isinstance(slots, str) else tuple(slots):
            if name in ("__dict__", "__weakref__"):
                continue
            try:
                held.setdefault(name, getattr(value, name))
            except Exception:  # noqa: BLE001 - a slot not filled, whatever the object's __getattr__ raises for it
                continue
        if kind is object or not _own_class(kind, packages):
            continue
        # what the object's class holds for every object of it (a table kept on the class)
        for name, item in vars(kind).items():
            if name.startswith("__") or callable(item) or isinstance(item, (property, staticmethod, classmethod)):
                continue
            held.setdefault(f"{kind.__name__}.{name}", item)
    return ("dict", [(repr(key), inner(item)) for key, item in held.items()])


def _code_reads(model, packages):
    """What the code of the model reads outside its instances, found in the code itself and not by running it:
    (the values it reads as module variables, by name; every attribute name it uses; its own functions).

    The code is that of every method and property of the classes of the modules of `model` and of their base
    classes, where these are code of the model (see `_model_code`: torch's own classes and those of a framework the
    model builds on are not), and of every function of the model's code that this code names as a module variable
    or closes over, and so on from function to function. A module variable is read by the instructions LOAD_GLOBAL
    and LOAD_NAME; a module brought in inside a function (IMPORT_NAME) counts as read when it is loaded. What the
    code reaches another way (globals()[...], getattr with a made-up name, a store behind an object of a library)
    is not found."""
    reads, attributes, functions, seen, followed, todo = {}, set(), [], set(), set(), []

    def follow(function, own=True):
        """Read the code of a function of the model's code; of a wrapper written elsewhere (a decorator of a library
        around a method of the model) only what it wraps: the library's own records are not the model's."""
        if id(function) in followed:
            return
        followed.add(id(function))
        if own:
            todo.append((function.__code__, function.__globals__))
        inside = [getattr(function, "__wrapped__", None)]
        for cell in function.__closure__ or ():
            try:
                inside.append(cell.cell_contents)
            except ValueError:  # a cell not filled yet
                continue
        for held in inside:
            if isinstance(held, types.FunctionType) and _model_code(_written_in(held), packages):
                follow(held)

    def met(name, value):
        """Note a value the code names, and read on from it: a function of the model's code, a function behind a
        functools cache, a module of the model's code (see `through`)."""
        reads.setdefault(name, value)
        if isinstance(value, types.FunctionType):
            if _model_code(_written_in(value), packages):
                follow(value)
        elif _is_cache(value):
            wrapped = getattr(value, "__wrapped__", None)
            if isinstance(wrapped, types.FunctionType) and _model_code(_written_in(wrapped), packages):
                follow(wrapped)

    def through(module, names):
        """What the code reaches through a module of the model's code that it names: module.function(...),
        module.Class, module.cached(...), for every name the code uses."""
        if module.__name__.split(".")[0] in _SKIPPED_ROOTS or not _model_code(module.__name__, packages):
            return
        for key in names:
            item = vars(module).get(key)
            if isinstance(item, (types.FunctionType, type)) or _is_cache(item):
                met(f"{module.__name__}.{key}", item)

    for module in model.modules():
        for kind in type(module).__mro__:
            if kind is object or not _model_code(kind.__module__, packages):
                continue
            for name, value in vars(kind).items():
                for item in (value.fget, value.fset, value.fdel) if isinstance(value, property) else (value,):
                    if isinstance(item, (staticmethod, classmethod)):
                        item = item.__func__
                    if _is_cache(item):
                        met(f"{kind.__name__}.{name}", item)
                    elif isinstance(item, types.FunctionType):
                        own = _model_code(_written_in(item), packages)
                        follow(item, own)
                        if own and all(item is not known for _, known in functions):
                            functions.append((f"{kind.__name__}.{name}()", item))
        # a function the instance holds (a callback, a closure over a store): a copy of the model holds the same one
        for name, value in vars(module).items():
            if name not in _TORCH_ENTRIES and isinstance(value, types.FunctionType) and _model_code(
                    _written_in(value), packages):
                follow(value)
                if all(value is not known for _, known in functions):
                    functions.append((f"{type(module).__name__}.{name} (a function the instance holds)", value))
    while todo:
        code, scope = todo.pop()
        if id(code) in seen:
            continue
        seen.add(id(code))
        attributes.update(code.co_names)
        todo += [(const, scope) for const in code.co_consts if isinstance(const, types.CodeType)]
        for step in dis.get_instructions(code):
            if step.opname == "IMPORT_NAME":
                loaded = sys.modules.get(step.argval)
                if loaded is not None:
                    reads.setdefault(f"{step.argval} (module)", loaded)
                    through(loaded, code.co_names)
            if step.opname not in ("LOAD_GLOBAL", "LOAD_NAME") or step.argval not in scope:
                continue
            value = scope[step.argval]
            met(f"{scope.get('__name__', '?')}.{step.argval}", value)
            if isinstance(value, types.ModuleType):
                through(value, code.co_names)
    return reads, attributes, functions


def _outside_state(model):
    """What the model holds outside its instances, by name, each value read as `_deep_snapshot` reads it:

    - every attribute of the class of every module of `model` (see `_class_values`);
    - every module variable the code of the model reads (see `_code_reads`), in whichever module it lies: a plain
      value, a container, an object, the defaults and the closure of a function of the model's code, the attributes
      of a class of the model's code that are not methods, and of a module of the model's code the variables whose
      names that code uses;
    - the defaults and the closure of every method of the model's own classes;
    - every attribute of a module of `model` that one copy of the model shares with it (a store whose deep copy is
      itself).

    A value kept in any of these is shared by every copy and every new instance of the model, so no check sets one
    call against another through it. A variable the code of the model never names is not read: the data a script
    or a notebook holds beside the model's class stays out, and nothing of it is copied."""
    packages = _model_packages(model)

    def read(value):
        return _deep_snapshot(value, (), packages)

    held = {name: read(value) for name, value in _class_values(model).items()}
    reads, attributes, functions = _code_reads(model, packages)
    for name, value in reads.items():
        if isinstance(value, types.ModuleType):
            if value.__name__.split(".")[0] in _SKIPPED_ROOTS or not _model_code(value.__name__, packages):
                continue
            for key, item in list(vars(value).items()):
                if key.startswith("__") or key not in attributes or isinstance(item, (types.ModuleType, type)):
                    continue
                if _is_cache(item):
                    held[f"{value.__name__}.{key}() (its cache)"] = _cache_snapshot(item)
                    continue
                if callable(item) and not isinstance(item, types.FunctionType):
                    continue
                held[f"{value.__name__}.{key}"] = read(item)
        elif isinstance(value, type):
            if issubclass(value, nn.Module) or not _own_class(value, packages):
                continue
            for key, item in list(vars(value).items()):
                if key.startswith("__") or isinstance(item, (property, staticmethod, classmethod)):
                    continue
                if callable(item) and not isinstance(item, types.FunctionType):
                    continue
                held[f"{name}.{key}"] = read(item)
        elif isinstance(value, types.FunctionType):
            if _model_code(_written_in(value), packages):
                held[f"{name}()"] = read(value)
        elif _is_cache(value):
            held[f"{name}() (its cache)"] = _cache_snapshot(value)
        elif not callable(value):
            held[name] = read(value)
    for name, function in functions:
        if function.__defaults__ or function.__kwdefaults__ or function.__closure__:
            held[name] = read(function)
    # A store that a deep copy hands back as itself is shared by every copy the checks make.
    twin = _copy(model)
    for (prefix, module), (_, other) in zip(model.named_modules(), twin.named_modules()):
        for key, value in vars(module).items():
            if key in _TORCH_ENTRIES or torch.is_tensor(value):
                continue
            if value is None or isinstance(value, (bool, int, float, complex, str, bytes, types.FunctionType,
                                                   nn.Module, type, types.ModuleType)):
                continue
            if vars(other).get(key) is value:
                held[f"instance {prefix + '.' if prefix else ''}{key}"] = read(value)
    return held


def _outside_or_line(model, say):
    """`_outside_state(model)`; None, with one printed line, when the scan stops on something the model holds (an
    object that answers no question about itself): the line about state outside the instances is then not given,
    and the checks run."""
    try:
        return _outside_state(model)
    except Exception as error:  # noqa: BLE001
        say(f"run_checks: what the model holds outside its instances could not be read ({type(error).__name__}: "
            f"{error}); a value kept there is shared by every copy and every new instance, and no line names it")
        return None


def _changed_state(before, after):
    """The names whose snapshots differ between two results of `_instance_state` or `_class_state`, or that only one
    of them holds."""
    return sorted(name for name in set(before) | set(after)
                  if name not in before or name not in after or not _same_snapshot(before[name], after[name]))


def _alone(work, batch, valid, rebuild, say):
    """The largest change of a real row's score when its sequence is scored alone, a batch of one, against its score
    in the whole batch, as a share of that score (or of 1), on a copy of `work` in 64 or 32 bits (see
    `_exact_copies`); every entry with one item per window is cut to the sequence."""
    B = valid.shape[0]

    def compared(copies):
        worst = 0.0
        for b in range(B):
            if not bool(valid[b].any()):
                continue
            single = {name: value[b:b + 1] if _per_window(value, B) else value for name, value in batch.items()}
            out = _exact_scores(copies.exact, _rebuilt(single, rebuild))
            worst = _worst(worst, _share(copies.whole[b][valid[b]], out[0][valid[b]]))
        return worst

    copies = _exact_copies(work, batch, valid, say, "one_model_two_batches", training=False)
    worst = compared(copies)
    if copies.wide and not worst <= ORDER_TOLERANCE:
        # As in check 3: the same sequences in 32 bits decide when they keep the tolerance there.
        first, second = worst, compared(_exact_copies(work, batch, valid, say, "one_model_two_batches",
                                                      training=False, wide=False))
        if second <= ORDER_TOLERANCE:
            say(f"one_model_two_batches: the sequences scored alone moved by {first:.3g} in 64-bit numbers and by "
                f"{second:.3g} in 32-bit numbers; the model reads its numbers otherwise in 64 bits there, so the "
                f"32-bit comparison stands")
            worst = second
    return worst


def _swapped_in_training(work, batch, valid, alter, real, time, units_per_second, rebuild):
    """The largest change of a real row's training-mode score when every other sequence of the batch is another one,
    exactly: half the sequences keep their rows, and the other half get new inputs from `alter` (and every real row
    moves OTHER_SHIFT_SECONDS later when the unit is known), every row real where it was, so that the dropout masks
    and the slots are those of the batch; then the halves change places. A part that reads other sequences in
    training mode alone (a batch norm across them) moves a row that kept its rows. 0.0 for a batch of one sequence."""
    B = valid.shape[0]
    if B < 2:
        return 0.0
    other = dict(alter(batch, valid))
    if units_per_second is not None:
        other[time] = _later_times(batch[time], valid, _unit(units_per_second), OTHER_SHIFT_SECONDS)
    plain = _training_scores(work, batch)
    worst = 0.0
    for parity in (0, 1):
        keep = torch.arange(B, device=valid.device) % 2 == parity
        mixed = {}
        for name, value in batch.items():
            changed = other.get(name)
            if (torch.is_tensor(value) and _per_window(value, B) and torch.is_tensor(changed)
                    and changed.shape == value.shape and changed.dtype == value.dtype):
                mixed[name] = torch.where(keep.view(-1, *([1] * (value.dim() - 1))), value, changed)
            else:
                mixed[name] = value
        out = _training_scores(work, _rebuilt(mixed, rebuild))
        rows = valid & keep.unsqueeze(1)
        worst = _worst(worst, _largest(plain[rows] - out[rows]))
    return worst


def one_model_two_batches(model, batch, other=None, alter=None, real="mask", time="time_seq", units_per_second=None,
                          build=None, rebuild=None, say=print):
    """Check 6: one instance scores a second batch as a new instance does, after it has scored a first batch, in
    either order and in scoring and training mode; and every sequence scores alone as it does in its batch.

    other             the second batch, laid out as `batch`; None builds one from `batch` (below)
    alter             as in `later_rows_change_nothing`; None takes `alter_rows`. Read only to build `other`
    real, time        as in `later_rows_change_nothing`
    units_per_second  the unit of the times (W5), from the caller. Needed only to build `other`, and a plain error
                      when it is missing then
    build             a function that returns a new instance of the model, never called (lambda: Model(config));
                      the new instance of each comparison is build() with the moved weights of the model (see
                      `_new_instance`). None takes a copy of the model as handed over
    rebuild           as in `later_rows_change_nothing`; `other`, when built here, and every batch of one sequence go
                      through it
    say               where a line goes when the check cannot run or sees the model write state while it scores

    Without `other`, the second batch is `batch` with its sequences rolled by one place (every entry whose first
    dimension is the batch size), every input of every real row replaced by `alter`, and every real row moved later
    by OTHER_SHIFT_SECONDS (30 days, 5 hours and 7 seconds) in the unit the caller names (integer times in a unit
    that is not a whole number move by the nearest whole number of units, see `_later_times`); padded slots keep
    their times. Its rows are other rows at other times, so that what a model fixes on its first call from the rows
    it saw (an origin of time, the range of a statistic) differs between the two batches; a batch of the same rows
    in other places would not show it. A batch of one sequence is not rolled.

    The model runs as a moved copy. One instance scores `batch` and then `other`, and its scores of `other` are set
    against those of a new instance; another scores `other` and then `batch`, against a new instance as well. In
    training mode an instance takes a training call on the first batch and then one on the second, against a new
    instance that took its own first training call on the second batch and then one more, the two second calls
    drawing the same dropout (see `_training_call`): a memory a model keeps of one training batch for the next shows,
    while what every training call moves alike, a generator the model holds or the power iteration of a spectral
    norm, moves both alike. An instance that took a training call then scores the second batch as a new instance
    holding the weights and buffers that call left, so that what a training call keeps outside them for scoring
    shows; and an instance that scored the batch, the second batch and the batch again scores it as a new instance
    does, so that what is fixed on a second call and read from the third shows. A new instance is a copy of the model
    as handed over unless `build` gives one that was never called: a model that fixed something on a call before the
    checks (an origin of time fixed lazily in a plain attribute, which a checkpoint does not hold) carries it into
    every copy, and only `build` shows it. The scoring comparisons run once more under torch.inference_mode(), the
    other way a scorer may score, so that a memory kept and read only there shows too. A model compiled with
    torch.compile is checked through the module it wraps (`_orig_mod`), which holds whatever the model keeps, so that
    the compiled code and the plain one never stand side by side here.

    Last, every sequence is scored alone, a batch of one, on a copy of the model in 64 or 32 bits (see
    `_exact_copies`): a row that reads anything of the other sequences of its batch (their earliest time, their
    number) moves, since grouped scoring builds other batches than training does. A list, a tuple or an array with one
    item per window is rolled with the windows and cut with them, with one printed line that names it. In training
    mode half the sequences keep their rows while the other half change, and then the other way round (see
    `_swapped_in_training`), so that a part that reads other sequences in training mode alone moves as well.

    Returns (two, alone): the largest difference of a real row's score between an instance that scored or took
    other calls first and a new one, which must be exactly 0.0, and the largest change of a real row's score when its
    sequence is scored alone, as a share of that score (or of 1), or in training mode beside other sequences, which
    must be at most ORDER_TOLERANCE. A value that is not a finite number counts as the largest. Anything a model
    keeps from one call and reads in a later one shows in two: a bias built for the first batch and kept, a memory of
    the latest batch, a running statistic, an origin of time fixed once. The other checks score every batch on a
    copy of its own, so they cannot see it; with `build`, run_checks hands them an instance never called, so that
    what the model kept from calls made before the checks does not answer their changed windows. When an instance
    that scored another batch first holds a buffer or an attribute otherwise than a copy that scored only the latest
    batch, while a copy that scored the latest batch
    twice holds it as one that scored it once (so not a counter of calls or a time taken; see `_instance_state`), or
    an attribute of a class changes while the model scores (see `_class_state`), one printed line names it, since a
    state shared by every copy (a cache on the class) cannot show as a difference between copies. A batch without a
    real row gives one printed line and the answer (not a number, not a number). A state kept outside the instances
    (on a class before the first call of the check, in a variable of a module) is shared by every copy and every new
    instance, so it cannot show as a difference here; run_checks names what of it changes while the checks run.
    """
    batch = _rebuilt(batch, rebuild)
    sequences = _real(batch, real).shape[0]
    listed = [name for name, value in batch.items()
              if sequences > 1 and not torch.is_tensor(value) and _per_window(value, sequences)]
    if listed:
        one = len(listed) == 1
        say(f"one_model_two_batches: {', '.join(listed)} {'holds' if one else 'hold'} one item per window "
            f"({sequences} items, as a list, a tuple or an array), so {'it moves' if one else 'they move'} with the "
            f"windows when the second batch rolls them and {'is' if one else 'are'} cut to one window when a sequence "
            f"is scored alone; a setting for the whole batch that happens to hold {sequences} items is to be handed "
            f"over in another form")
    if other is None:
        units = _given_unit(units_per_second, "one_model_two_batches")
        other = _rebuilt(_other_batch(batch, sequences, alter_rows if alter is None else alter, real, time, units),
                         rebuild)
    valid, valid_other = _real(batch, real), _real(other, real)
    if not valid.any() or not valid_other.any():
        say("one_model_two_batches: each of the two batches needs a real row")
        return float("nan"), float("nan")
    # A model compiled with torch.compile is checked through the module it wraps, which holds what the model keeps:
    # the compiled code rounds otherwise than the plain one, and two must be exactly 0.0.
    work = moved(model)
    work = getattr(work, "_orig_mod", work)
    gaps, kept = [], []
    for first, second, rows in ((batch, other, valid_other), (other, batch, valid)):
        used, new = _copy(work), _new_instance(work, build)
        classes = _class_state(work)
        # The first batch is scored only for what the instance may keep from it.
        _scores(used, first)
        gaps.append(_largest(_scores(used, second)[rows] - _scores(new, second)[rows]))
        # What the instance holds after both calls, against copies of the model that scored only the second batch,
        # once and twice: an attribute named is one that a second call on the same batch leaves as the first left it
        # (not a counter, not a time taken) and that another batch before it changes (an origin fixed once).
        once, twice = _copy(work), _copy(work)
        _scores(once, second)
        _scores(twice, second)
        _scores(twice, second)
        held_once, held_twice = _instance_state(once), _instance_state(twice)
        kept += [name for name in _changed_state(held_once, _instance_state(used))
                 if name not in kept and name in held_twice and name in held_once
                 and _same_snapshot(held_once[name], held_twice[name])]
        kept += [name for name in _changed_state(classes, _class_state(work)) if name not in kept]
        # In training mode: one instance takes a training call on the first batch and then one on the second, set
        # against a new instance that took its own first training call on the second batch and then one more, with
        # the same dropout in both second calls. What every training call moves alike (a generator the model holds, a
        # power iteration) moves both alike; what one call keeps of its batch for the next does not.
        trained, twin = _copy(work), _new_instance(work, build)
        _training_call(trained, first, DROPOUT_SEED + 1)
        _training_call(twin, second, DROPOUT_SEED + 1)
        gaps.append(_largest(_training_call(trained, second)[rows] - _training_call(twin, second)[rows]))
        # A training call, then scoring: an instance that took a training call on the first batch scores the second
        # as a new instance does that holds the weights and buffers the call left (a batch norm's statistics, kept
        # with the weights); a centre or a scale the call kept outside them shows.
        taught = _copy(work)
        _training_call(taught, first, DROPOUT_SEED + 1)
        gaps.append(_largest(_scores(taught, second)[rows]
                             - _scores(_new_instance(work, build, source=taught), second)[rows]))
    # A third call: an instance that scored the batch, the second batch and the batch again, against a new instance
    # that scores the batch once, so that something fixed on a second call and read from the third shows.
    third = _copy(work)
    _scores(third, batch)
    _scores(third, other)
    gaps.append(_largest(_scores(third, batch)[valid] - _scores(_new_instance(work, build), batch)[valid]))
    # The scoring comparisons once more under torch.inference_mode(), the other way a scorer may score, each on copies
    # of their own, so that a memory kept and read only there shows as well. A model that stops there (one that takes
    # a gradient inside its forward) is not compared that way, with a line.
    try:
        _inference_scores(work, batch)
    except Exception as error:  # noqa: BLE001
        say(f"one_model_two_batches: under torch.inference_mode() the model stops on the batch as handed over "
            f"({type(error).__name__}: {error}); that way of scoring is not compared, and a scorer that scores that "
            f"way stops as well")
    else:
        for first, second, rows in ((batch, other, valid_other), (other, batch, valid)):
            used = _copy(work)
            _scores(used, first, inference=True)
            gaps.append(_largest(_scores(used, second, inference=True)[rows]
                                 - _scores(_new_instance(work, build), second, inference=True)[rows]))
        third = _copy(work)
        _scores(third, batch, inference=True)
        _scores(third, other, inference=True)
        gaps.append(_largest(_scores(third, batch, inference=True)[valid]
                             - _scores(_new_instance(work, build), batch, inference=True)[valid]))
    if kept:
        shown = ", ".join(kept[:8]) + (f" and {len(kept) - 8} more" if len(kept) > 8 else "")
        say(f"one_model_two_batches: in scoring mode the model keeps {shown} from one call to the next: after another "
            f"batch an instance holds otherwise there than one that scored only the latest batch, or the attribute "
            f"sits on a class, which every instance shares. A score that reads it depends on the batches scored "
            f"before; what a model reads is built again from every batch, or kept with the weights")
    swapped = _swapped_in_training(work, batch, valid, alter_rows if alter is None else alter, real, time,
                                   units_per_second, rebuild)
    return _worst(*gaps), _worst(_alone(work, batch, valid, rebuild, say), swapped)


def _pass_second(count, step, steps):
    """Which shared second of a sequence with `count` of them the pass `step` of `steps` changes, or None: every one in
    turn when there are no more than `steps`, else `steps` of them spread from the first to the last."""
    if count <= steps:
        return step if step < count else None
    return round(step * (count - 1) / max(1, steps - 1))


def _layer(shared, step, steps, place, valid):
    """The second that pass `step` of `steps` changes, in every sequence that has one (see `_pass_second`):
    (witness, rows, chosen), bool [B, T] for the first two. rows holds every real row of that second, the witness
    among them; the witness is its slot at `place` (0 the first, -1 the last); chosen[b] is that second's slots in
    sequence b, or None."""
    witness, rows = torch.zeros_like(valid), torch.zeros_like(valid)
    chosen = []
    for b, seconds_of in enumerate(shared):
        index = _pass_second(len(seconds_of), step, steps)
        members = None if index is None else seconds_of[index]
        chosen.append(members)
        if members is not None:
            rows[b, members] = True
            witness[b, members[place]] = True
    return witness, rows, chosen


def _with_a_shared_second(batch, valid, seconds, time):
    """A copy of `batch` in which, in every sequence with two real rows or more, the second earliest real row takes the
    time of the earliest, so that the two share a second and a batch in time order stays so; None when no sequence
    holds two real rows."""
    times = batch[time].clone()
    made = False
    for b in range(valid.shape[0]):
        slots = torch.nonzero(valid[b]).flatten()
        if len(slots) < 2:
            continue
        earliest = slots[torch.argsort(seconds[b, slots], stable=True)[:2]]
        times[b, earliest[1]] = times[b, earliest[0]]
        made = True
    if not made:
        return None
    out = dict(batch)
    out[time] = times
    return out


def order_inside_a_second(model, batch, units_per_second=None, real="mask", time="time_seq", seed=7, alter=None,
                          labels=("target_seq",), pad=None, rebuild=None, pads=None, say=print, absent=None):
    """Check 7: the order of the rows inside a second moves no score beyond rounding, and no row reads the other
    rows of its own second.

    units_per_second, real, time, labels, rebuild   as in `later_rows_change_nothing`
    seed     the seed of the shuffle
    alter    as in `later_rows_change_nothing`; None takes `alter_rows`
    pad      as in `prefix_agrees`: a function (batch, rows) -> batch that makes the slots in rows padding, its times
             and inputs included; None writes padding as a builder does (see `_padder`)
    pads     as in `prefix_agrees`: the side on which the builder pads, "left" or "right"; None reads it from the
             batch; anything else stops with a plain error
    say      where a line goes when the check cannot run, makes a shared second, or leaves a pass out

    In every sequence the slots of the real rows that share a whole second are shuffled among themselves: every
    entry laid out as [B, T, ...] is taken in the new slot order, the times and the labels included, so each row
    keeps its own inputs and time and only its place among the rows of its second changes. Every row of such a
    second moves. Every real row's score is set against its score before the shuffle. The time does not order the
    rows of one second, and the scorer may not write them in the order of the builder, so a model whose score
    depends on that order (a memory that takes the rows of an earlier second by their slots, say) scores otherwise
    in use than in training. A model that stops with an error on rows of a second out of the order of their times
    (the model in use takes its real rows only in time order) is shuffled only among the rows that share their time
    to the last unit, the order its builder cannot fix either, with one printed line that says so.

    A shuffle cannot show a row that reads the rows of its own second alike, whatever their order (their mean, or
    how many there are), so passes around one row of every such second follow, the witness, which may not move. A
    witness reads the rows of earlier seconds, which must stay as they are, so each pass takes the seconds of a
    sequence one at a time: each call changes one such second of every sequence and nothing else, every one in turn
    when a sequence holds no more than ORDER_PASSES of them, else ORDER_PASSES of them spread from its first to its
    last (see `_pass_second`). In the first pass the witness is the first slot of its second; every other row of the
    second gets new inputs from `alter` and leaves the second for the next second of its sequence, taking the time
    of the earliest row there, so that the batch keeps its time order and the window gains no second of its own. In
    the last second of a sequence, which no later row can take in, the other rows stay where they are, real, with
    their new inputs. That pass keeps every row real and in its slot, so it runs in scoring and in training mode
    alike, the same dropout drawn for every slot, and allows no move at all; in scoring mode it is scored the three
    ways a scorer may score (under torch.no_grad(), under torch.inference_mode(), in evaluation mode with gradients
    on; see `_other_scoring`). In the second pass the witness is the last slot of its second, and the other rows of
    the second are taken out of the window: the window is written again from the rows that are left, as a builder
    writes it (see `_relaid`), the witness then in another slot, and the slots the other rows leave hold padding as
    `pad` writes it, a time in no real second among it. In both passes the answers of every row of the second, the
    witness's own among them, are redrawn (`labels`), and the first pass runs once more with the presence of an
    answer turned over where an entry tells it by its presence (see `_redrawn`). A row that reads the other rows of
    its own second then moves, whether it reads their values, their order, their times inside the second or only how
    many there are, and so does a row that reads its own answer. The witnesses are the first and the last slot of a
    second: a read confined to a row that has rows of its second on both sides of it is left to check 3, whose cut
    inside a second finds it (cut=range(1, T) on a batch with few shared seconds).

    The shuffle and the second pass run on a moved copy in 64-bit numbers, or in 32-bit numbers at full precision
    when the model does not run in 64 bits as it does in 32 (see `_exact_copies`; when they move beyond the tolerance
    in 64 bits and not in 32, the 32-bit comparison stands, with a line), in scoring mode and again in training mode
    with gradients on, on a copy whose dropout is off (see `_without_dropout`), so that a part that reads the order or
    the number of the rows of a second in training mode alone moves too, unless that copy still draws random numbers
    in training mode, gives scores that are not finite numbers there or stops there (see `_training_draws`), which
    one printed line says. The first pass runs on the moved copy as it is, in its own number type; a part that reads
    the rows of its second only in a number type of 16 bits is not compared in the shuffle or the second pass. A
    batch without a second that holds two real rows is checked on a copy in which the second earliest real row of
    every sequence takes the time of the earliest, with one printed line that says so. The second pass writes the
    window on the side the builder pads (`pads`, else read from the batch; for a batch of full windows on the right,
    then on the left when the model stops there). It needs `pad` when `real` is a function, and without it, or when
    the model stops on both sides, one printed line says so and order is not a number.

    Returns (order, same_second): the largest move of a row in the shuffle or of a witness in the second pass, each
    as a share of the score it moves from (or of 1 when that score is smaller; see `_share`), which must be at most
    ORDER_TOLERANCE; and the largest change of a witness in the first pass, in any mode, which must be exactly 0.0. A
    value that is not a finite number counts as the largest. Without a sequence that holds two real rows, one printed
    line says so and the answer is (not a number, not a number).
    """
    alter = alter_rows if alter is None else alter
    units = _given_unit(units_per_second, "order_inside_a_second")
    pads = _side(pads, "order_inside_a_second")
    batch = _rebuilt(batch, rebuild)
    valid = _real(batch, real)
    B, T = valid.shape
    seconds = whole_seconds(batch[time], units)
    shared = _shared_seconds(valid, seconds)
    if not any(shared):
        made = _with_a_shared_second(batch, valid, seconds, time)
        if made is None:
            say("order_inside_a_second: no sequence holds two real rows; hand it a batch with longer sequences, and "
                "check that `real` is True on real rows")
            return float("nan"), float("nan")
        say("order_inside_a_second: no second holds two real rows of one sequence; in a copy, the second earliest real "
            "row of every sequence took the time of the earliest, and the check ran on that copy")
        batch = _rebuilt(made, rebuild)
        valid = _real(batch, real)
        seconds = whole_seconds(batch[time], units)
        shared = _shared_seconds(valid, seconds)
    rows = torch.arange(B, device=valid.device).unsqueeze(1)
    steps = min(ORDER_PASSES, max(len(seconds_of) for seconds_of in shared))
    side, padder = pads or _pad_side(valid), _padder(real, pad, time, units)

    def compared(copies, tell):
        """The largest share over the shuffle and the rows taken out of a second, scored by `copies` (see
        `_exact_copies`), lines through `tell`; not a number when a window cannot be written or scored."""
        # The rows of every shared second change places; a model that takes the rows of a second only in the order of
        # their times (it stops on any other order) is shuffled only among the rows that share their time to the last
        # unit, the order its builder cannot fix either.
        g = torch.Generator().manual_seed(seed)
        order_change = 0.0
        for groups in (shared, _shared_seconds(valid, batch[time])):
            if not any(groups):
                tell("order_inside_a_second: the model stopped on the rows of a second in another order than that of "
                     "their times, and no two rows share their time to the last unit, so the shuffle is left out; the "
                     "passes around a witness run alone")
                break
            order = _turned(groups, B, T, g, valid.device)
            turned = _rebuilt(_taken(batch, order), rebuild)
            try:
                shuffled = _exact_scores(copies.exact, turned)
            except (ValueError, RuntimeError, AssertionError, IndexError) as error:
                if groups is not shared:
                    raise
                tell(f"order_inside_a_second: the model stopped on the rows of every shared second shuffled among "
                     f"their slots ({error}); they are shuffled only among the rows that share their time to the last "
                     f"unit")
                continue
            # The score each row had before the shuffle, laid out in the new order, so that slot i holds the same row
            # twice; in scoring mode and in training mode.
            order_change = _share(copies.whole[rows, order][valid], shuffled[valid])
            if copies.why is None:
                order_change = _worst(order_change, _share(copies.whole_training[rows, order][valid],
                                                           _exact_training_scores(copies.quiet, turned)[valid]))
            break
        # The second pass: the last slot of a second is its witness, and the other rows of the second leave the
        # window, which is written again on the side the builder pads: for a batch of full windows on the right, then
        # on the left when the model stops there.
        sides = [side == "left"] if side is not None else [False, True]
        if padder is None:
            tell("order_inside_a_second: taking the other rows of a second out of the window needs `pad`, a function "
                 "(batch, rows) -> batch that makes the slots in rows padding, since `real` is a function; without it "
                 "that pass cannot run, and order is not a number")
            return float("nan")
        for step in range(steps):
            witness, second_rows, _ = _layer(shared, step, steps, -1, valid)
            redrawn = _redrawn(batch, second_rows, labels, valid, absent=absent)
            written = None
            for left in sides:
                relaid, where = _relaid(redrawn, valid & ~(second_rows & ~witness), left, padder)
                relaid = _rebuilt(relaid, rebuild)
                try:
                    out = _exact_scores(copies.exact, relaid)
                except (ValueError, RuntimeError, AssertionError, IndexError) as error:
                    failure = error
                    continue
                written = (relaid, where, out)
                break
            if written is None:
                tell(f"order_inside_a_second: the model stopped on the window written again without the other rows of "
                     f"a second ({failure}); that pass cannot run, and order is not a number")
                return float("nan")
            relaid, where, out = written
            # Once a side works it is the one the model takes; the next passes write the window there alone.
            sides = [left]
            b, i = torch.nonzero(witness, as_tuple=True)
            order_change = _worst(order_change, _share(copies.whole[b, i], out[b, where[b, i]]))
            if copies.why is None:
                order_change = _worst(order_change, _share(copies.whole_training[b, i],
                                                           _exact_training_scores(copies.quiet, relaid)[b,
                                                                                                        where[b, i]]))
        return order_change

    work = moved(model)
    copies = _exact_copies(work, batch, valid, say, "order_inside_a_second")
    if copies.why is not None:
        say(f"order_inside_a_second: in training mode the copy whose dropout is off {copies.why}, so the shuffle and "
            f"the rows taken out of a second are compared in scoring mode alone, and a part that reads the order or "
            f"the number of the rows of a second in training mode alone is not seen")
    order_change = compared(copies, say)
    if copies.wide and not order_change <= ORDER_TOLERANCE:
        # As in check 3: the same windows in 32 bits decide when they keep the tolerance there.
        first, second = order_change, compared(_exact_copies(work, batch, valid, say, "order_inside_a_second",
                                                             wide=False), lambda line: None)
        if second <= ORDER_TOLERANCE:
            say(f"order_inside_a_second: the shuffled rows and the witnesses moved by {first:.3g} in 64-bit numbers "
                f"and by {second:.3g} in 32-bit numbers; the model reads its numbers otherwise in 64 bits there, so "
                f"the 32-bit comparison stands")
            order_change = second
    # The first pass: the first slot of a second is its witness, and every slot is kept.
    plain, plain_training = _fresh_scores(work, batch), _training_scores(work, batch)
    ways = _other_ways(work, batch, say, "order_inside_a_second")
    plain_other = _other_scoring(work, batch, ways)
    times = batch[time]
    same_second = 0.0
    coded = _presence_coded(batch, labels, valid, absent)
    for step in range(steps):
        witness, second_rows, chosen = _layer(shared, step, steps, 0, valid)
        for presence in ((False, True) if coded else (False,)):
            changed = _redrawn(dict(alter(batch, second_rows & ~witness)), second_rows, labels, valid, presence,
                               absent)
            new_times = times.clone()
            for b, members in enumerate(chosen):
                if members is None:
                    continue
                after = valid[b] & (seconds[b] > seconds[b, members[0]])
                if bool(after.any()):
                    # The next second of the sequence, at the time of its earliest row.
                    nearest = after & (seconds[b] == seconds[b][after].min())
                    new_times[b, members[1:]] = times[b][nearest].min()
                # In the last second of a sequence the other rows stay where they are, real, with new inputs and
                # answers.
            changed[time] = new_times
            changed = _rebuilt(changed, rebuild)
            same_second = _worst(same_second, _largest(plain[witness] - _fresh_scores(work, changed)[witness]),
                                 _largest(plain_training[witness] - _training_scores(work, changed)[witness]),
                                 *[_largest(one[witness] - two[witness])
                                   for one, two in zip(plain_other, _other_scoring(work, changed, ways))])
    return order_change, same_second


def _same_values(first, second):
    """Whether two batch entries hold the same values (see `_snapshot`), values that are not a number counted as the
    same."""
    return _same_snapshot(_snapshot(first, False), _snapshot(second, False))


def _unchecked(batch, alter, real, time, labels, rebuild):
    """The lines run_checks prints about entries of the batch that no check changes, so that a read of them is not
    checked: a name in `labels` that the batch does not hold laid out per row; an entry laid out per row, [B, T, ...],
    other than the mask, the times and the answers, that `alter` leaves as it is on every real row (an answer belongs
    in `labels`, a column the builder works out from other rows in `rebuild`); and any entry laid out otherwise (per
    window, one per slot [T], or one value for the batch of any type: a number, a string, a dict, a tensor) that no
    `rebuild` writes again, or that `rebuild` leaves as it is on the window cut after half its slots. With a function
    `real`, a yes-or-no entry per row that holds the mask it gives, or its opposite, is the mask, which `pad` writes,
    and is not named."""
    valid = _real(batch, real)
    B, T = valid.shape
    lines = []
    missing = [name for name in labels if not _per_row(batch.get(name), B, T)]
    if missing:
        lines.append(f"run_checks: labels names {', '.join(missing)}, which the batch does not hold laid out per row; "
                     f"a row that reads its own answer is checked only through the answers the batch holds under the "
                     f"names in labels")
    mask_name = None if callable(real) else real.lstrip("~")
    own = {time, mask_name, *labels}
    if callable(real):
        own |= {name for name, value in batch.items() if _per_row(value, B, T) and value.dtype == torch.bool
                and value.dim() == 2 and (bool(torch.equal(value, valid)) or bool(torch.equal(value, ~valid)))}
    altered = alter(batch, valid)
    kept = [name for name, value in batch.items() if name not in own and _per_row(value, B, T)
            and name in altered and _same_values(value, altered[name])]
    if kept:
        lines.append(f"run_checks: `alter` leaves {', '.join(kept)} as {'it is' if len(kept) == 1 else 'they are'} on "
                     f"every real row, and no check changes {'it' if len(kept) == 1 else 'them'} otherwise: an answer "
                     f"belongs in `labels`, and a column the builder works out from other rows in `rebuild`")
    whole = [name for name, value in batch.items() if name not in own and not _per_row(value, B, T)]
    if whole and rebuild is None:
        lines.append(f"run_checks: {', '.join(whole)} {'is' if len(whole) == 1 else 'are'} not laid out per row "
                     f"(per window, or one value for the batch: a number, a string, a dict, a tensor); no check writes "
                     f"such an entry again unless `rebuild` does, so what a model reads from it (the window's length, "
                     f"the time of its last row, the latest time of the batch) is not checked")
    elif whole:
        k = max(1, T // 2)
        cut = _rebuilt({name: value[:, :k] if _per_row(value, B, T) else value for name, value in batch.items()},
                       rebuild)
        same = [name for name in whole if name in cut and _same_values(batch[name], cut[name])]
        if same:
            one = len(same) == 1
            lines.append(f"run_checks: `rebuild` leaves {', '.join(same)} as {'it is' if one else 'they are'} on the "
                         f"window cut after {k} of {T} slots; if {'it holds' if one else 'they hold'} anything of the "
                         f"rows after the cut, a model that reads it is not checked")
    return lines


def run_checks(model, batch, alter=None, fill=None, loss=None, real="mask", time="time_seq", units_per_second=None,
               other=None, labels=("target_seq",), pad=None, rebuild=None, build=None, pads=None, cut=None,
               say=print, absent=None):
    """The seven checks on one model and one batch, with the verdict of each.

    units_per_second  how many units of the batch's times make one second (PLACEHOLDER W5). Required, from the
                      caller and never from the model, so that a wrong unit in the model cannot pass the checks
                      on the strength of the same wrong unit
    alter, fill, other   as in the checks
    loss              as in `every_weight_learns`; None takes `row_loss` on the mask `real` names and the first name
                      in `labels`
    real              the mask of real rows: "mask" for an entry True on real rows, "~is_pad" for one True on
                      padding, or a function batch -> bool [B, T]
    time              the batch entry of the times
    labels            the batch entries that hold each row's answer (its label, an outcome code); checks 1 and 7
                      redraw them on rows that no compared row may read, the compared row's own among them, and
                      once more with the presence of an answer turned over where an entry tells it by its presence
                      (no finite number in a float entry, a value below 0 in a whole-number entry, or the value
                      named in `absent`, where there is none)
    absent            a dict {entry: value}: the value by which an entry named in `labels` says that a row has no
                      answer, where that is an ordinary number (9999 for the days to a chargeback that never came,
                      255 for a label not known yet). Without it such a value moves with the others, and a row that
                      reads only whether its own answer is there may not move; one printed line names an entry
                      that looks like it (see `_likely_sentinels`)
    pad               a function (batch, rows) -> batch that makes the slots in rows padding, as the builder writes
                      padding, its times and inputs included; None writes padding as a builder does: the mask, a time
                      in no second of a real row, and on every other entry laid out per row the value the padded slots
                      of the batch hold (see `_padder`). Checks 2, 3 and 7 use it to make padding where a batch has
                      none, to write a cut window, to make slots padding in place and to take rows out of a window; a
                      function `real` needs it
    rebuild           a function batch -> batch that writes again what the builder works out from other rows, from
                      the slots or from the whole window (a gap column, a slot index, a count, the window's length,
                      the time of its last row); every batch checks 1, 3, 6 and 7 make goes through it. Without it
                      such an entry moves with its row and is never written again, so a model that reads one is not
                      checked through it. Printed lines name what no check changes (see `_unchecked`): a name in
                      `labels` the batch does not hold, an entry per row that `alter` leaves as it is, and an entry
                      not laid out per row that no `rebuild` writes again
    build             a function that returns a new instance of the model, never called and set up as the model
                      is (its weights and buffers are put in; anything else it holds, fitted edges say, comes from
                      `build`); check 6 sets the model against it (see `one_model_two_batches`), and checks 1, 2,
                      3, 4 and 7 run on such an instance. Without it a model handed over after a call carries what
                      it fixed on that call into every copy, and what it keeps on its instance for a window (a memo
                      by transaction) answers the windows the checks change
    pads              the side on which the builder pads, "left" or "right"; None reads it from the padded slots of
                      the batch. Checks 2, 3 and 7 make padding on that side. A batch of full windows does not say
                      which side it is, and a builder that pads on the left needs pads="left" there, or a row that
                      reads the padding in front of it is not checked. Anything else stops with a plain error
    cut               as in `prefix_agrees`: the slots after which check 3 cuts; range(1, T) cuts after every slot,
                      which finds a leak confined to a few slots between two rows, at T times the cost of check 3.
                      None takes the cuts of check 3
    say               where the lines of the checks go: the dates of check 5, and any line a check prints when it
                      cannot run or sees something to explain

    Returns {"weights", "kept", "later", "read", "padding", "finite", "prefix", "unlearned", "first", "last",
    "two_batches", "alone", "order", "same_second", "passes"}; "passes" holds {"later rows", "padding", "prefix",
    "gradient", "time unit", "two batches", "order in a second"}, each True or False by the rule its check states:
    "later rows" when kept is 0.0 and later and read are above zero, "two batches" when two_batches is 0.0 and
    alone is at most ORDER_TOLERANCE, "order in a second" when order is at most ORDER_TOLERANCE and same_second is
    0.0. channels_stay_apart is not among them: it reads a hand-off, not a model, and is run once on the model's own
    hand-off.

    Training mode means a training step, with gradients on, so a part that leaks only in training mode under
    torch.no_grad() (a validation loop that forgot eval()) is not run that way. The training-mode passes that change
    which slots are real or where a row lies (checks 3 and 7) run on a copy whose dropout is off (see
    `_without_dropout`); when that copy still draws random numbers (a mask drawn by hand, noise, a generator of the
    model's own), they compare in scoring mode alone, with a line, and a part that reads its share of the window, or
    the order of the rows of its second, in training mode alone is not seen there. Nor is a part that runs only while
    a dropout drops something or a rate is above zero: the passes with dropout on keep the window as it is. The copies
    in 64 or 32 bits of checks 3, 6 and 7 score inside a torch function mode with every narrower float widened: a
    path the model takes only in its own number type, or only outside such a mode (torch's quick route through
    nn.TransformerEncoderLayer and nn.MultiheadAttention is one), is not run there. Outside the copies, in the
    model's own type, the checks compare the values of later rows (check 1), the window's length in scoring mode
    (the pass in place of check 3; with a function `real` and no `pad` it cannot run, and says so) and what padded
    slots hold (check 2). A read taken only in the model's own type of how many rows share a second, of another
    sequence of the batch, of the window's length in training mode, or of the slot index on a batch padded on the
    left, is not compared. Nor is a read of the number of sequences of the batch taken in training mode alone
    (check 6 scores a sequence alone in scoring mode), or a path an instance takes only from a later call on than
    check 6 makes (three scoring calls, two training calls).

    Scoring mode is evaluation mode under torch.no_grad(). The kept rows of check 1, the pass in place of check 3 and
    the first pass of check 7 are also scored under torch.inference_mode() and in evaluation mode with gradients on
    (a model that stops in one of these ways is not compared that way, with a line); check 2, the cut windows that
    check 3 writes anew and the shuffle and second pass of check 7 are not. Every call hands the model a batch of
    its own (a new dict, the tensors cloned, plain lists, tuples and dicts copied), so what a model writes into its
    batch is worked out afresh in each call, and one printed line names what it writes; an entry that is an object,
    a table of another library or a large array is shared by every call, and a line names it. A model that reads
    how its batch is stored (a view, a tensor its builder wrote in place, the same dict handed twice) meets no
    such batch here. The checks score in the context they are called in: a scorer that scores under torch.autocast
    calls run_checks under it, or a path the model takes only there is not run (the copies in 64 or 32 bits turn
    autocast off in any case). It is not called under torch.no_grad() or torch.inference_mode(): the checks set
    those themselves, and under the second run_checks stops with a plain error.

    A state kept outside the instances is shared by every copy and every new instance, so no check fails on it. One
    printed line names what of it changes while the checks run, read where the code of the model reads it (see
    `_outside_state`): an attribute of a class of the model, a module variable its code names, the defaults and the
    closure of a function it calls or holds, a function behind functools.lru_cache (by how many answers its cache
    holds: a cache of a function that depends on its arguments alone fills without harm), what it reaches through a
    module of its own code (module.function(...), module.Class), a store that a deep copy hands back as itself.
    What the code reaches another way (globals()[...], a name made up at run time, a store behind an object of a
    library, an attribute of a class set through setattr with a made-up name) is not named. A model compiled with
    torch.compile is compared through the module it wraps in checks 3, 6 and 7, and the checks' copies run the
    model's own hooks, so a hook that writes into a store it holds outside the model writes there from every copy.
    A part that reaches its parent through weakref.ref points at the model handed over in every copy, and fails
    checks 4 and 6 for that reason alone.
    """
    units = _given_unit(units_per_second, "run_checks")
    pads = _side(pads, "run_checks")
    say = _once(say)
    if torch.is_inference_mode_enabled():
        raise RuntimeError("run_checks is called under torch.inference_mode(): the checks take training steps and "
                           "set the ways of scoring themselves. Call it outside (under torch.autocast when the "
                           "scorer scores under it)")
    if absent is not None and not isinstance(absent, dict):
        raise TypeError("absent takes a dict {entry: value}, the value by which each entry says that a row has no "
                        f"answer; it was given {type(absent).__name__}")
    lazy = getattr(nn.parameter, "UninitializedParameter", ()), getattr(nn.parameter, "UninitializedBuffer", ())
    unshaped = [name for name, tensor in [*model.named_parameters(), *model.named_buffers()]
                if isinstance(tensor, tuple(kind for kind in lazy if kind != ()))]
    if unshaped:
        raise ValueError(f"run_checks: {', '.join(unshaped[:6])}{' ...' if len(unshaped) > 6 else ''} of the model "
                         "has no shape yet (a lazy layer such as nn.LazyLinear before its first call). Call the "
                         "model once on a batch, then hand it over")
    # A batch built under torch.inference_mode(), as a scoring pipeline builds one, holds tensors that no training call
    # can read; they are cloned outside it.
    with torch.inference_mode(False):
        batch, other = [entries if entries is None else
                        {name: value.clone() if torch.is_tensor(value) and value.is_inference() else value
                         for name, value in entries.items()} for entries in (batch, other)]
    outside = _outside_or_line(model, say)
    names = (labels,) if isinstance(labels, str) else tuple(labels or ())
    if loss is None:
        # The loss of the stand-in, on the mask and the answer the caller names.
        label = names[0] if names else "target_seq"

        def loss(model, batch):
            return row_loss(model, batch, real=real, label=label)

    for line in _unchecked(batch, alter_rows if alter is None else alter, real, time, names, rebuild):
        say(line)
    for line in _likely_sentinels(batch, names, _real(batch, real), absent):
        say(line)
    shared = _shared_entries(batch)
    if shared:
        one = len(shared) == 1
        say(f"run_checks: {', '.join(shared)} {'is' if one else 'are'} handed to the model as "
            f"{'it is' if one else 'they are'} in every call (an object, a table of another library, a large array, "
            f"which are not copied): what a "
            f"model writes there is found again in every later call and in the caller's own batch, and no check "
            f"sees it")
    added, replaced, in_place, taken_out = _written(model, batch)
    if added or replaced or in_place or taken_out:
        parts = [f"{what} {', '.join(found)}" for what, found in (
            ("adds", added), ("replaces", replaced), ("writes in place into", in_place), ("takes out", taken_out))
            if found]
        say(f"run_checks: the model {'; '.join(parts)} in the batch it is handed. Every call of the checks hands it "
            f"a batch of its own (a new dict, the tensors cloned), so what it keeps there is worked out afresh in "
            f"each call. A scorer that hands the model one dict twice hands it what the first call left there")
    # With `build`, checks 1, 2, 3, 4 and 7 run on an instance that was never called and holds the model's weights
    # and buffers. A model that keeps what it worked out for a window on its instance (a memo by transaction), and
    # that was called on this batch before the checks, would otherwise answer every changed, cut or relaid window
    # from that memo, and nothing would move. Check 6 keeps the model as handed over: it is the check of what an
    # instance keeps.
    checked = model if build is None else _new_instance(model, build)
    kept, later, read = later_rows_change_nothing(checked, batch, alter, real, time, units, labels=labels,
                                                  rebuild=rebuild, say=say, absent=absent)
    change, finite = padding_stays_out(checked, batch, fill, real, time, pad=pad, rebuild=rebuild, pads=pads, say=say)
    prefix = prefix_agrees(checked, batch, cut=cut, real=real, time=time, units_per_second=units, pad=pad,
                           rebuild=rebuild, pads=pads, say=say)
    unlearned = every_weight_learns(checked, batch, loss)
    missing = [name for name in unlearned if name.rsplit(".", 1)[-1] == "missing"]
    if missing:
        say(f"run_checks: check 4 lists {', '.join(missing)}: a learned vector for missing numbers gets a gradient "
            f"only from a batch whose real rows hold a missing number, so on a batch without one it fails check 4, as "
            f"it would stay as it was in training on such data")
    first, last, fits = time_unit_fits(batch, units, real, time, say=say)
    two, alone = one_model_two_batches(model, batch, other, alter=alter, real=real, time=time, units_per_second=units,
                                       build=build, rebuild=rebuild, say=say)
    order, same_second = order_inside_a_second(checked, batch, units, real, time, alter=alter, labels=labels, pad=pad,
                                               rebuild=rebuild, pads=pads, say=say, absent=absent)
    after = None if outside is None else _outside_or_line(model, say)
    changed = [] if after is None else _changed_state(outside, after)
    if changed:
        shown = ", ".join(changed[:8]) + (f" and {len(changed) - 8} more" if len(changed) > 8 else "")
        say(f"run_checks: {shown} changed while the checks ran. The model's code reads "
            f"{'it' if len(changed) == 1 else 'them'} outside its instances (on a class, in a module, in a "
            f"function's defaults or closure, or in a store every copy shares), so every copy and every new instance "
            f"shares {'it' if len(changed) == 1 else 'them'} and no check can set one call against another through "
            f"{'it' if len(changed) == 1 else 'them'}; a score that reads such a value depends on the batches scored "
            f"before")
    # A check that could not run gives not a number, which fails every comparison below.
    passes = {"later rows": kept == 0.0 and later > 0.0 and read > 0.0, "padding": change == 0.0 and finite,
              "prefix": prefix < PREFIX_TOLERANCE, "gradient": not unlearned, "time unit": fits,
              "two batches": two == 0.0 and alone <= ORDER_TOLERANCE,
              "order in a second": order <= ORDER_TOLERANCE and same_second == 0.0}
    return {"weights": count_weights(model), "kept": kept, "later": later, "read": read, "padding": change,
            "finite": finite, "prefix": prefix, "unlearned": unlearned, "first": first, "last": last,
            "two_batches": two, "alone": alone, "order": order, "same_second": same_second, "passes": passes}


def channels_stay_apart(hand_off, summary, axis=-2, seed=0, say=print):
    """Whether a hand-off keeps the summary outputs of stage 1 apart: each reaches one channel, no two the same one.

    hand_off   the model's own code from the summary outputs of stage 1 to the channels the stage takes, a module, a
               method of a module (model.hand_off) or a function: summary -> [B, T, C, D], the channels on the
               second axis from the end (EDIT 3 of 7)
    summary    a sample of its input, with the C summary outputs on `axis`: [B, T, M, d] in BestModel
    axis       the axis of `summary` that holds the summary outputs
    seed       the seed of the values drawn in place of an output, and of any random part of the hand-off
    say        where a line goes when the hand-off is a plain function, whose weights cannot be moved

    A module, or the module of a method, runs as a copy with every weight moved a little (see `moved`), as the
    checks run a model: a mixing part that starts at zero (a gate at 0, a low-rank factor at 0, a mean over the
    channels times a scale at 0) mixes nothing until it has learned, and would read as apart when fresh. A plain
    function (a lambda, a functools.partial of a method) runs as it is, its weights not moved, and one printed line
    says so; a hand-off that holds weights is handed over as a module or as a method of one. For every output c, a
    copy of `summary` with output c drawn again (random values from `seed`, of the same shape and number type) goes
    through `hand_off`, and every channel of what comes out is set against the same channel from `summary` itself.
    Each call runs under torch.no_grad() inside `_same_draws`, every random draw from `seed` (torch on the CPU and on
    the CUDA device of `summary`, Python's random module and numpy), so that a random part of the hand-off (dropout
    in training mode) draws the same in every call.

    Returns {"moved": bool [C, C'], "apart": bool}: moved[c, m] is True when channel m changed at all with output c,
    and apart is True when every output moves exactly one channel and no two outputs move the same one. A
    relabelling of the channels that is fixed before training is harmless: each channel's identity and weights are
    learned for the place it lands in. A hand-off that mixes the outputs (a linear layer or a layer norm over the
    joined [B, T, M * d] vector before .view, or the d numbers of every output joined d-major and then split) is not
    apart, and still keeps the time rule: the seven checks score a whole model and cannot see it. So this is run
    once, beside them, on the model's own hand-off; for BestModel that is channels_stay_apart(model.hand_off,
    summary). When stage 1 of the model in use returns the joined vector itself, the code handed over starts at the
    summary outputs inside stage 1 and holds stage 1's own joining line and everything applied after it; or stage 1
    is changed to return its summary outputs before the join, and the join moves into the hand-off. A lambda that
    joins the outputs so that a hand-off taking the joined vector can be called would leave a mixing join inside
    stage 1 unseen. A hand-off whose result has not as many axes as its input (a joined vector) has no channels to
    keep apart: a plain error says so.
    """
    axis = axis % summary.dim()
    devices = [summary.device.index] if summary.device.type == "cuda" else []
    owner = getattr(hand_off, "__self__", None)
    if isinstance(hand_off, nn.Module):
        hand_off = moved(hand_off)
    elif isinstance(owner, nn.Module):
        hand_off = getattr(moved(owner), hand_off.__name__)
    else:
        say("channels_stay_apart: the hand-off is a plain function (a lambda or a functools.partial, say), which runs "
            "as it is: no weight it reads is moved, so a mixing part behind it that starts at zero reads as apart. "
            "Hand over the module, or the method of the module, that holds the hand-off")

    def through(values):
        # The same random state before every call, so that only the values handed over can change the channels.
        with _same_draws(seed, devices), torch.no_grad():
            return hand_off(values)

    base = through(summary)
    if base.dim() != summary.dim():
        raise ValueError(f"channels_stay_apart reads a hand-off to channels, [B, T, C, D] as the stage takes them; "
                         f"this one gives shape {tuple(base.shape)} from {tuple(summary.shape)}, which has no channels "
                         f"to keep apart (a joined vector, for one)")
    g = torch.Generator().manual_seed(seed)
    reached = torch.zeros(summary.shape[axis], base.shape[-2], dtype=torch.bool)
    for c in range(summary.shape[axis]):
        redrawn = summary.clone()
        place = (slice(None),) * axis + (c,)
        # New values for output c alone, drawn on the CPU from the seed and brought to the type and device of the rest.
        redrawn[place] = torch.randn(redrawn[place].shape, generator=g).to(redrawn)
        changed = through(redrawn) != base
        # Channel m changed when any of its numbers changed, in any row of the sample.
        reached[c] = changed.movedim(-2, 0).reshape(base.shape[-2], -1).any(dim=1).cpu()
    apart = bool((reached.sum(dim=1) == 1).all() and (reached.sum(dim=0) <= 1).all())
    return {"moved": reached, "apart": apart}


# ----------------------------------------------------------------------------------------------
# the optimiser
# ----------------------------------------------------------------------------------------------

# The modules whose every weight is a norm's scale or shift.
_NORMS = (nn.LayerNorm, nn.GroupNorm, nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d) + (
    (nn.RMSNorm,) if hasattr(nn, "RMSNorm") else ())


def param_groups(model, lr=None, weight_decay=None):
    """The parameter groups of torch.optim.AdamW for `model`, every weight in exactly one group.

    model          any torch module: a BestModel or the model in use
    lr             the peak learning rate; None reads LEARNING_RATE
    weight_decay   the decay of the weights that are decayed; None reads WEIGHT_DECAY

    Returns a list of dicts with "name", "params", "lr" and "weight_decay", one per group that holds a weight:

        "decayed"       every map (the weights of linear layers and attention projections, the bin weights of the
                        numbers, the projections per field or channel) at `lr`, decayed
        "not decayed"   norms, biases, embedding tables and the learned vectors of NO_DECAY_NAMES at `lr`, not
                        decayed: decay would pull a bias, a row of a table or a field identity toward zero, which
                        changes what it says rather than how large a map may grow, and a norm's scale with it
        "centres"       the weights that place the learned centres (centre_parameters of numeric_encoders.py) at
                        lr * CENTRE_LR_FACTOR, not decayed: at the global rate a few steps can carry a centre off
                        the data, and decay would pull the first centre and every gap toward the values that a raw
                        weight of zero gives

        optimiser = torch.optim.AdamW(param_groups(model, lr=3e-4, weight_decay=0.01))

    A weight that does not learn (requires_grad False, the frozen centres) is listed too; it gets no gradient,
    so the optimiser leaves it.
    """
    lr = LEARNING_RATE if lr is None else float(lr)
    weight_decay = WEIGHT_DECAY if weight_decay is None else float(weight_decay)
    centres = {id(weight) for weight in centre_parameters(model)}
    groups = {"decayed": [], "not decayed": [], "centres": []}
    seen = set()
    for module in model.modules():
        for name, weight in module.named_parameters(recurse=False):
            # A weight shared by two modules goes into one group, once.
            if id(weight) in seen:
                continue
            seen.add(id(weight))
            if id(weight) in centres:
                groups["centres"].append(weight)
            elif (isinstance(module, _NORMS) or isinstance(module, nn.Embedding) or name.endswith("bias")
                  or weight.dim() < 2 or name in NO_DECAY_NAMES):
                groups["not decayed"].append(weight)
            else:
                groups["decayed"].append(weight)
    settings = {"decayed": (lr, weight_decay), "not decayed": (lr, 0.0), "centres": (lr * CENTRE_LR_FACTOR, 0.0)}
    # AdamW takes extra keys such as "name" and keeps them with the group; an empty group is left out.
    return [{"name": name, "params": weights, "lr": settings[name][0], "weight_decay": settings[name][1]}
            for name, weights in groups.items() if weights]


# ----------------------------------------------------------------------------------------------
# what a configuration costs
# ----------------------------------------------------------------------------------------------

def _settled():
    """Wait until the work queued on every CUDA device is done, so that a clock reads the time of the work and not
    that of queueing it; nothing on a machine where CUDA has not started."""
    if torch.cuda.is_available() and torch.cuda.is_initialized():
        torch.cuda.synchronize()


def _timed(call, repeats):
    """The times of `repeats` calls after one call that warms up, in seconds, in the order they ran; on a GPU each
    call is timed from an idle device until its work is done (see `_settled`)."""
    call()
    spans = []
    for _ in range(max(1, int(repeats))):
        _settled()
        start = perf_counter()
        call()
        _settled()
        spans.append(perf_counter() - start)
    return spans


def cost(model, batch, loss=None, repeats=3):
    """The weights of a model, and the time of a forward pass and of a training step on one batch.

    loss      as in `every_weight_learns`; None takes `row_loss`
    repeats   timed calls per measurement, after one that warms up; the shortest is kept, and every one is
              returned, so that the spread can be read

    Returns {"weights", "forward_seconds", "step_seconds", "forward_spans", "step_spans"}: the forward pass in
    evaluation mode without gradients, as scoring runs it, and the training step as a forward and a backward
    pass in training mode (the optimiser's step is left out). It runs on a copy, so the model itself keeps no
    gradient.
    """
    loss = row_loss if loss is None else loss
    work = _copy(model)
    # Scoring: evaluation mode and no gradients, which is also where the standard layers take their quick route.
    work.eval()

    def score():
        with torch.no_grad():
            work(batch)

    forward_spans = _timed(score, repeats)
    # Training: dropout on and every activation kept for the backward pass, which is most of the memory and the time.
    work.train()

    def step():
        work.zero_grad(set_to_none=True)
        loss(work, batch).backward()

    step_spans = _timed(step, repeats)
    return {"weights": count_weights(model), "forward_seconds": min(forward_spans), "step_seconds": min(step_spans),
            "forward_spans": forward_spans, "step_spans": step_spans}


def _named(configs):
    """(name, Config) pairs from arm names of ARMS, a {name: Config} dict, or (name, Config) pairs; None gives the
    four named configurations."""
    if configs is None:
        return list(CONFIGURATIONS.items())
    if isinstance(configs, str):
        configs = [configs]
    if isinstance(configs, dict):
        return list(configs.items())
    pairs = []
    for item in configs:
        if isinstance(item, str):
            if item not in ARMS:
                raise ValueError(f"no arm is named {item!r}; the arms are {', '.join(ARMS)}")
            pairs.append((item, ARMS[item].config))
        else:
            name, config = item
            pairs.append((name, config))
    return pairs


def compare(configs=None, batch=None, loss=None, repeats=3, seed=0, say=print):
    """One table: the weights of every configuration, its time for a forward pass and a training step on `batch`,
    and the ratio of both times to TODAY's on the same batch.

    configs   names of arms in ARMS (one name, or a list), {name: Config}, or (name, Config) pairs; None takes the
              four named configurations. TODAY is measured first when it is not among them
    batch     the batch every model runs on; None makes make_batch(seed)
    loss, repeats   as in `cost`
    seed      the seed every model is built with
    say       where the lines go; print by default

    Returns one row per configuration, {"name", "weights", "forward_seconds", "step_seconds", "forward_spans",
    "step_spans", "forward_ratio", "step_ratio"}. A shared machine gives other times from run to run, so a table
    is read from more than one; the slowest of the timed calls is printed beside the shortest.
    """
    items = _named(configs)
    batch = make_batch(seed=seed) if batch is None else batch
    # The ratios need TODAY measured in the same call, on the same batch and in the same state of the machine.
    if not any(config == TODAY for _, config in items):
        items = [("TODAY", TODAY)] + items
    table = []
    for name, config in items:
        # Every model starts from the same seed, so that a configuration named twice is the same model twice.
        torch.manual_seed(seed)
        table.append({"name": name, **cost(BestModel(config), batch, loss, repeats)})
    today = next(row for row, (_, config) in zip(table, items) if config == TODAY)
    for row in table:
        row["forward_ratio"] = row["forward_seconds"] / today["forward_seconds"]
        row["step_ratio"] = row["step_seconds"] / today["step_seconds"]
    B, T = batch["mask"].shape
    say(f"cost on {B} sequences of up to {T} rows, {torch.get_num_threads()} CPU threads, the shortest of "
        f"{max(1, int(repeats))} calls after one to warm up (the slowest in brackets)")
    say(f"{'configuration':<23} {'weights':>11} {'forward s':>17} {'x TODAY':>8} {'training step s':>19} "
        f"{'x TODAY':>8}")
    for row in table:
        forward = f"{row['forward_seconds']:.3f} ({max(row['forward_spans']):.3f})"
        step = f"{row['step_seconds']:.3f} ({max(row['step_spans']):.3f})"
        say(f"{row['name']:<23} {row['weights']:>11,} {forward:>17} {row['forward_ratio']:>8.2f} {step:>19} "
            f"{row['step_ratio']:>8.2f}")
    return table


# ----------------------------------------------------------------------------------------------
# the run of everything
# ----------------------------------------------------------------------------------------------

def _yes(ok):
    """The answer of a check in one word."""
    return "yes" if ok else "NO"


# What each answer of a line of `main` says, in the order of the line.
_ANSWERS = (("later rows", "later rows change no earlier row, in training mode too, and earlier rows reach later "
                           "ones"),
            ("padding", "padding reaches no real row, in training mode too"),
            ("prefix", "the first rows score as the cut window"), ("gradient", "every weight gets a gradient"),
            ("time unit", "the times fit the unit"),
            ("two batches", "one model scores a second batch as a new one, and a sequence alone as in its batch"),
            ("order in a second", "neither the order of the rows of a second nor the other rows of it move a score"))


def main(sequences=16, rows=None, repeats=3, seed=0, say=print, names=None):
    """Build the named configurations (or any arms), run every check on each and print one line each, then the
    cost table.

    sequences, rows   the made-up batch: `sequences` windows of up to `rows` rows (HISTORY_LEN + 1 by default)
    repeats           timed calls per measurement of `compare`
    seed              the seed of the batch and of every model
    names             arm names of ARMS; None takes the four named configurations

    Returns ({name: result of run_checks}, the rows of `compare`). Every answer printed must be "yes".
    """
    items = _named(names)
    batch = make_batch(seed=seed, sequences=sequences, rows=rows)
    B, T = batch["mask"].shape
    say(f"made-up batch: {B} sequences of up to {T} rows, {int(batch['mask'].sum())} real rows, times in units of "
        f"1 / {TIME_UNITS_PER_SECOND} second")
    # The dates once for the batch; the check of every configuration reads the same times with the same unit.
    time_unit_fits(batch, TIME_UNITS_PER_SECOND, say=say)
    say("checks: " + "; ".join(f"{short}: {words}" for short, words in _ANSWERS))

    def quiet(line):
        # The dates were printed above; every other line of a check (one that could not run, or that says why a
        # check failed) is printed.
        if not line.startswith("time unit:"):
            say(line)

    results = {}
    for name, config in items:
        torch.manual_seed(seed)
        # The made-up batch is written in TIME_UNITS_PER_SECOND units, so that is the unit its caller names.
        # build gives check 6 a new instance of the same configuration, never called, for every comparison.
        result = results[name] = run_checks(BestModel(config), batch, units_per_second=TIME_UNITS_PER_SECOND,
                                            build=lambda config=config: BestModel(config), say=quiet)
        p = result["passes"]
        say(f"{name:<22} {result['weights']:>10,} weights | "
            + " | ".join(f"{short}: {_yes(p[short])}" for short, _ in _ANSWERS))
    table = compare(items, batch, repeats=repeats, seed=seed, say=say)
    return results, table


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Every check of every named configuration, and what each costs.")
    parser.add_argument("--sequences", type=int, default=16, help="sequences in the made-up batch")
    parser.add_argument("--rows", type=int, default=HISTORY_LEN + 1, help="rows per sequence")
    parser.add_argument("--repeats", type=int, default=3, help="timed calls per measurement, after one to warm up")
    parser.add_argument("--seed", type=int, default=0, help="seed of the batch and of every model")
    parser.add_argument("--list", action="store_true", help="print every arm with its change, question and weights")
    parser.add_argument("--arms", nargs="+", default=None, help="run the checks and the table on these arms")
    arguments = parser.parse_args()
    if arguments.list:
        arm_table(seed=arguments.seed)
    else:
        main(sequences=arguments.sequences, rows=arguments.rows, repeats=arguments.repeats, seed=arguments.seed,
             names=arguments.arms)
