Paste this into Copilot.

---

I unzipped program_package.zip at the project root. It adds PROGRAM.md, program/ and
tests/experiments/program/. Please:

1. Read PROGRAM.md fully. It is the one path we follow, in five steps. Do not reorder the steps or change the
   decision rules, populations, seeds or settings it gives.
2. Run the tests on the pod CPU: `$PY -m pytest -q tests/experiments/program`. Report the counts. On our organized
   code layout some tests skip because they need the old module names; report any failure with its full output.
3. Adapt names and paths only, never the logic: the project's Python, the config the chosen model's seed-42 rerun used,
   the training and evaluation raw bases, the S3 credentials file, the scorer's module name in our layout, and the
   run folder. List every change you make.
4. Check that `program/pg_layout.py` finds our code (organized names first, then the old ones) by
   running `$PY -c "import sys; sys.path.insert(0, 'program'); import pg_layout; print(pg_layout.resolve()[0])"`.
   If a module name differs in our layout, fix the name in `pg_layout.NAMES` only.
5. Step 2 (features): the feature list is ours. Whatever features we settle on as final, follow PROGRAM.md step 2 with
   the features package we already have: group them, run the CPU checks, build the enriched data and artifact, fit one
   seed-42 run per group plus one combined run against the step 1 control, and read each with pg_read.py. Do not add
   feature code to program/.
6. Before any GPU run, show me the exact command you will run and the folder it writes to. GPU work runs on the
   OpenShift AI workbench with the GPU. Never run two jobs that write to the same run folder.
7. After each read, show me the screen it prints (the .txt beside the .json).
