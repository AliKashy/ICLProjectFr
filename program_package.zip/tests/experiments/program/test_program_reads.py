"""The measures, the decision rules, the paired read, the benchmark and the file lists, on synthetic numbers.

Run: $PY -m pytest -q tests/experiments/program/test_program_reads.py
"""
import json
from fractions import Fraction

import numpy as np
import pandas as pd
import pytest
from sklearn.metrics import average_precision_score, roc_auc_score

import pg_bench
import pg_files
import pg_ranked as R
import pg_read
import pg_rules


def test_outsort_counts_ties_and_the_bank_measures():
    y = np.array([1, 0, 1, 0, 0, 1, 0, 0, 0, 0])
    s = np.array([0.9, 0.8, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1])
    acc = np.arange(10).astype(str)
    ids = np.arange(10).astype(str)
    amt = np.arange(1, 11).astype(float)
    key, codes, _ = R.prepare(acc, ids)
    f = R.RankedScore(s, y, codes, key, amt, Fraction(3, 10))  # 30%: floor 3 rows
    p = f.evaluate()
    assert p["outsorted"] == 3 and p["frauds_outsorted"] == 2  # rows 0, 1 and 2 (the tie is broken by the key)
    assert p["udr"] == pytest.approx(2 / 3)
    assert p["vdr"] == pytest.approx((1 + 3) / (1 + 3 + 6))
    assert p["fpr"] == pytest.approx(1 / 2)
    assert p["ap"] == pytest.approx(average_precision_score(y, s))
    assert p["auroc"] == pytest.approx(roc_auc_score(y, s))
    ceil = R.RankedScore(s, y, codes, key, amt, Fraction(1, 4), "ceil").evaluate()
    assert ceil["outsorted"] == 3  # ceil(2.5)
    assert R.outsort_count(952905, Fraction(6, 1000), "ceil") == 5718  # the bank's rank-based table selects 5,718
    assert R.outsort_count(952905, Fraction(6, 1000), "floor") == 5717


def test_rules_by_hand():
    t = pg_rules.t1_terms(0.01, 0.015, 2)
    a, b = 0.01 ** 2, 2 * 0.015 ** 2
    nu = (a + b) ** 2 / (b * b / 2)
    assert t["t1"] == pytest.approx(pg_rules.t_quantile(0.95, nu) * np.sqrt(a + b))
    assert pg_rules.decide_costly(1, -0.001, t["t1"], 0.01, 0.0)[0] == "KEEP THE CONTROL"
    assert pg_rules.decide_costly(1, 0.05, 0.04, 0.01, 0.002)[0] == "ADOPT"
    assert pg_rules.decide_costly(1, 0.02, 0.04, 0.01, 0.002)[0] == "RUN SEEDS 43 AND 44"
    assert pg_rules.decide_costly(1, 0.02, float("nan"), 0.01, 0.002, t1_undefined="zero")[0] == "RUN SEEDS 43 AND 44"
    lb3, s_d, tq, df = pg_rules.lb_three(0.02, [0.018, 0.022, 0.020], 1e-5)
    assert lb3 == pytest.approx(0.02 - pg_rules.t_quantile(0.95, 2) * np.sqrt(1e-5 + 0.002 ** 2 / 3))
    assert pg_rules.decide_costly(3, 0.02, None, 0.01, None, lb3)[0] == "ADOPT"
    assert pg_rules.decide_free(0.0001)[0] == "ADOPT" and pg_rules.decide_free(0.0)[0] == "KEEP THE CONTROL"
    u = pg_rules.unpaired_rule(-0.02, [0.50, 0.51, 0.49], [0.52, 0.53, 0.51], 1e-6)
    assert u["decision"] == "KEEP THE REFERENCE"
    assert pg_rules.unpaired_rule(-0.005, [0.5, 0.51, 0.49], [0.505, 0.515, 0.495], 1e-6)["decision"] == \
        "KEEP THE LARGER DATA"
    one = pg_rules.unpaired_rule(-0.012, [0.538], [0.56, 0.54, 0.55], 0.003 ** 2)
    assert one["seed_spread_note"] and one["decision"] == "KEEP THE LARGER DATA"  # the single fit's noise counts
    sa2 = np.var([0.56, 0.54, 0.55], ddof=1)
    assert one["se"] == pytest.approx(np.sqrt(sa2 / 1 + sa2 / 3 + 0.003 ** 2))
    assert pg_rules.unpaired_rule(-0.05, [0.5], [0.55], 1e-6)["decision"] == "NO DECISION"
    assert pg_rules.decide_not_worse(0.0)[0] == "ADOPT" and pg_rules.decide_not_worse(-0.001)[0] == "KEEP THE CONTROL"


def fits(tmp_path, n=4000, accounts=600, seed=3, gain=0.6):
    rng = np.random.default_rng(seed)
    acc = rng.integers(0, accounts, n).astype(str)
    ids = np.array([f"t{i}" for i in range(n)])
    y = (rng.random(n) < 0.05).astype(int)
    amt = rng.gamma(2, 50, n)
    files = {}
    for seed_ in (42, 43, 44):
        base = rng.normal(size=n)
        for name, g in (("control", 1.0), ("arm", 1.0 + gain)):
            s = base + g * y + rng.normal(scale=0.3, size=n)
            f = tmp_path / f"{name}_{seed_}.parquet"
            pd.DataFrame({"Nmap_account_reference_xid": acc, "fi_transaction_id": ids, "frd_tag": y, "score": s,
                          "transaction_amt": amt, "window_rows": rng.integers(1, 33, n)}).to_parquet(f, index=False)
            files[(name, seed_)] = str(f)
    return files


def test_read_one_seed_three_seeds_select_check_unpaired_and_slices(tmp_path):
    f = fits(tmp_path)
    spread = ["--spread-fits", f[("control", 42)], f[("control", 43)], f[("control", 44)]]
    one = tmp_path / "one.json"
    assert pg_read.main(["--role", "decide", "--control", f[("control", 42)], "--arm", f[("arm", 42)],
                         "--all-rows", *spread, "--draws", "200", "--slices", "window", "amount",
                         "--out", str(one)]) == 0
    rec = json.loads(one.read_text())
    assert rec["metrics"]["udr"]["gain"] > 0 and rec["final"] in ("ADOPT", "RUN SEEDS 43 AND 44")
    assert any(r.get("slice") == "window" for r in rec["slices"])
    three = tmp_path / "three.json"
    args = []
    for s in (42, 43, 44):
        args += ["--control", f[("control", s)], "--arm", f[("arm", s)]]
    assert pg_read.main(["--role", "decide", *args, "--all-rows", "--draws", "200", "--out", str(three)]) == 0
    assert json.loads(three.read_text())["lb_three_seed"] is not None
    sel = tmp_path / "sel.json"
    assert pg_read.main(["--role", "select-check", "--control", f[("control", 42)], "--arm", f[("arm", 42)],
                         "--all-rows", *spread, "--draws", "200", "--out", str(sel)]) == 0
    assert "pass" in json.loads(sel.read_text())["select_check"]
    un = tmp_path / "un.json"
    assert pg_read.main(["--role", "unpaired", "--arm", f[("arm", 42)], "--arm", f[("arm", 43)],
                         "--control", f[("control", 42)], "--control", f[("control", 43)], "--control",
                         f[("control", 44)], "--all-rows", "--draws", "100", "--out", str(un)]) == 0
    assert json.loads(un.read_text())["decision"] == "KEEP THE LARGER DATA"
    assert pg_read.main(["--role", "decide", "--control", f[("control", 42)], "--arm", f[("arm", 42)],
                         "--all-rows", "--out", str(tmp_path / "x.json")]) == 4  # no seed spread for one seed
    assert pg_read.main(["--role", "report", "--control", f[("control", 42)], "--arm", f[("arm", 42)],
                         "--all-rows", "--out", str(one)]) == 4  # output exists


def test_read_on_raw_files_with_june_targets_and_exclusions(tmp_path, world):
    """The raw-file path: June targets of the evaluation file, declines and advice dropped."""
    raw = world["frames"][8]
    june = raw[(raw["transaction_dttm"] >= "2025-06-01") & (raw["transaction_dttm"] < "2025-07-01")]
    assert len(june) and june["frd_tag"].sum()
    rng = np.random.default_rng(0)
    paths = []
    for name in ("control", "arm"):
        p = tmp_path / f"{name}.parquet"
        raw.assign(score=rng.normal(size=len(raw)) + raw["frd_tag"]).to_parquet(p, index=False)
        paths.append(str(p))
    out = tmp_path / "raw.json"
    assert pg_read.main(["--role", "report", "--control", paths[0], "--arm", paths[1], "--raw-base",
                         str(world["data"]), "--files", "8", "8", "--exclude", "declines", "advice",
                         "--slices", "card_present", "same_second", "history", "--draws", "50",
                         "--out", str(out)]) == 0
    rec = json.loads(out.read_text())
    kept = june[(june["predecline"] != 1) & (june["transaction_advice_xcd"] != "A")]
    assert rec["rows"] == len(kept)


def test_bench_common_rows_both_roundings_and_pairs(tmp_path):
    rng = np.random.default_rng(1)
    n = 3000
    ids = np.array([f"t{i}" for i in range(n)])
    y = (rng.random(n) < 0.03).astype(int)
    acc = rng.integers(0, 500, n).astype(str)
    rows = pd.DataFrame({"fi_transaction_id": ids, "frd_tag": y, "transaction_amt": rng.gamma(2, 40, n),
                         "Nmap_account_reference_xid": acc})
    rows = pd.concat([rows, rows.iloc[:5]])  # duplicate ids are kept once
    rows.to_parquet(tmp_path / "rows.parquet", index=False)
    for name, g in (("ours", 1.5), ("inc", 1.0), ("pfm", 1.2)):
        pd.DataFrame({"fi_transaction_id": ids[:-10] if name == "pfm" else ids,
                      "prob": (rng.normal(size=n) + g * y)[:-10] if name == "pfm" else rng.normal(size=n) + g * y}
                     ).to_csv(tmp_path / f"{name}.csv", index=False)
    out = tmp_path / "bench.json"
    assert pg_bench.main(["--rows", str(tmp_path / "rows.parquet"), "--model", f"ours={tmp_path / 'ours.csv'}:prob",
                          "--model", f"15298={tmp_path / 'inc.csv'}:prob", "--model", f"PFM={tmp_path / 'pfm.csv'}:prob",
                          "--pair", "ours-15298", "--pair", "ours-PFM", "--draws", "100", "--out", str(out)]) == 0
    rec = json.loads(out.read_text())
    assert rec["rows"] == n - 10
    assert {r["rounding"] for r in rec["table"]} == {"floor", "ceil"}
    assert len(rec["pairs"]) == 2 and rec["bootstrap"]["unit"] == "account"


def test_nested_file_lists_keep_the_reserved_files_out(tmp_path):
    lists = pg_files.nested_lists([10, 35, 100, 500])
    assert lists[10] == list(range(1, 11))
    for small, big in ((10, 35), (35, 100), (100, 500)):
        assert lists[big][:small] == lists[small]
    assert not set(lists[500]) & pg_files.RESERVED and len(set(lists[500])) == 500
    assert pg_files.main(["--out", str(tmp_path / "f"), "--sizes", "10", "35"]) == 0
    assert (tmp_path / "f" / "files_35.txt").read_text().split()[:10] == [str(i) for i in range(1, 11)]


def test_flags_read_numbers_and_text_alike():
    import pg_rows
    assert pg_rows.flag(pd.Series([1, 1.0, "1", "0", None, 0]), ("1",)).tolist() == [True, True, True, False, False,
                                                                                      False]
    assert pg_rows.present(pd.Series(["A", "", None, " ", "X"])).tolist() == [True, False, False, False, True]


def test_bench_stops_when_no_id_matches_and_on_conflicting_labels(tmp_path):
    pd.DataFrame({"fi_transaction_id": ["1", "2"], "frd_tag": [0, 1]}).to_csv(tmp_path / "rows.csv", index=False)
    pd.DataFrame({"fi_transaction_id": ["9"], "score": [0.5]}).to_csv(tmp_path / "m.csv", index=False)
    with pytest.raises(SystemExit, match="no transaction id"):
        pg_bench.main(["--rows", str(tmp_path / "rows.csv"), "--model", f"a={tmp_path / 'm.csv'}",
                       "--out", str(tmp_path / "o.json")])
    pd.DataFrame({"fi_transaction_id": ["1", "1"], "frd_tag": [0, 1]}).to_csv(tmp_path / "bad.csv", index=False)
    with pytest.raises(SystemExit, match="different labels"):
        pg_bench.main(["--rows", str(tmp_path / "bad.csv"), "--model", f"a={tmp_path / 'm.csv'}",
                       "--out", str(tmp_path / "o2.json")])
