"""Shared synthetic data for the program tests: small account files in the project's raw format, artifacts and a
chosen-model config sized for the CPU."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import torch

ROOT = Path(__file__).resolve().parents[3]
PROGRAM = ROOT / "program"
for p in (str(PROGRAM), str(ROOT)):
    if p not in sys.path:
        sys.path.insert(0, p)

ACCOUNT, ID, TIME, LABEL = "Nmap_account_reference_xid", "fi_transaction_id", "transaction_dttm", "frd_tag"


def frame(seed, accounts=40, start="2025-05-20", fraud_rate=0.25):
    """One raw file: accounts with 4 to 30 rows each, some same-second rows, a decline and an advice column."""
    rng = np.random.default_rng(seed)
    rows = []
    for a in range(accounts):
        t = pd.Timestamp(start) + pd.Timedelta(days=int(rng.integers(0, 3)))
        for k in range(int(rng.integers(4, 30))):
            t = t + pd.Timedelta(seconds=int(rng.choice([0, 1, 30, 600, 7200, 86400 * 2])))
            rows.append({TIME: t, ACCOUNT: f"s{seed}a{a}", ID: f"s{seed}a{a}r{k:03}"})
    df = pd.DataFrame(rows)
    n = len(df)
    df["f1"], df["f2"] = rng.normal(size=n), rng.normal(size=n)
    df["c1"], df["c2"] = rng.choice(["A", "B"], size=n), rng.choice(["X", "Y"], size=n)
    df[LABEL] = (rng.random(n) < fraud_rate).astype(int)
    df["transaction_amt"] = np.abs(rng.normal(50, 20, size=n))
    df["predecline"] = np.where((rng.random(n) < 0.1) & (df[LABEL] == 0), 1, 0)
    df["transaction_advice_xcd"] = np.where((rng.random(n) < 0.08) & (df[LABEL] == 0), "A", "")
    df["cardholder_present_xflg"] = rng.choice(["Y", "N"], size=n)
    return df


@pytest.fixture
def world(tmp_path):
    """Files 1-3 (training 1-2, validation 3) and 8 (an evaluation file with June rows), artifacts and a config."""
    torch.set_num_threads(1)
    conftest = pytest.importorskip("waqas.v2.tests.conftest")  # noqa: F841 (the old layout's own fixtures)
    helpers = pytest.importorskip("waqas.tests.test_sequence_builder")
    from omegaconf import OmegaConf
    from fraud.data.datetime_features import DatetimeConfig
    from fraud.data.feature_list import load_feature_list

    frames = {i: frame(i) for i in (1, 2, 3)}
    frames[8] = frame(8, accounts=60, start="2025-05-25")
    predictors = helpers._write_predictors(tmp_path)
    features = load_feature_list(predictors, version=1)
    dt = DatetimeConfig(order_col=TIME, fields=helpers.DATETIME_FIELDS, encoding="categorical", is_weekend=False)
    helpers._fit_artifacts(pd.concat(frames.values()), features, dt).save(str(tmp_path / "artifacts/1"))
    data = tmp_path / "data"
    data.mkdir()
    for i, f in frames.items():
        f.to_parquet(data / f"part_{i}.parquet", index=False)
    c = OmegaConf.load(ROOT / "waqas/phase4b/configs/sequential_hier_allposition.yaml")
    c.s3.cred_path = None
    c.predictors.csv_path, c.predictors.version = predictors, 1
    c.artifacts.base, c.artifacts.version = str(tmp_path / "artifacts"), 1
    c.data.train_base = c.data.val_base = str(data)
    c.data.train_start, c.data.train_end, c.data.val_start, c.data.val_end = 1, 2, 3, 3
    c.sequence.history_len = 3
    c.sequence.max_chunk_rows = 64
    c.sequence.max_window_rows = 64
    c.training.update(dict(batch_size=16, buffer_windows=64, max_epochs=1, accelerator="cpu", precision="32-true",
                           num_workers=0, seed=42, log_every_n_steps=1, early_stopping_patience=5,
                           eval_batch_size=7, deterministic=False))
    c.model.update(dict(input_embed_dim=8, num_heads=2, num_txn_blocks=1, num_seq_blocks=1))
    cfg_path = tmp_path / "cfg.yaml"
    OmegaConf.save(c, cfg_path)
    return {"tmp": tmp_path, "data": data, "cfg": cfg_path, "frames": frames, "features": features, "dt": dt}


def score_args(w, start=3, end=3, population="EPOCH_VAL"):
    return ["--population", population, "--purpose", "test", "--config", str(w["cfg"]),
            f"eval.base={w['data']}", f"eval.file_start={start}", f"eval.file_end={end}"]
