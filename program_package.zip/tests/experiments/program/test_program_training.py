"""Training variants on the old layout, CPU only: the builder, the loss, the banded mask and full training runs.

Run: $PY -m pytest -q tests/experiments/program/test_program_training.py
"""
import json

import numpy as np
import pandas as pd
import pytest
import torch

from conftest import ACCOUNT, ID, LABEL, TIME, score_args

pg_layout = pytest.importorskip("pg_layout")
import pg_patch  # noqa: E402


@pytest.fixture
def mods():
    layout, m = pg_layout.resolve(roles=("base_model", "target_ending_model", "trainer", "scorer", "chunk_builder",
                                        "target_ending_data"))
    if layout != "old":
        pytest.skip("these tests run on the old code layout")
    return m


def builder(w, mods, s, files=(1,), shuffle=False, batch_size=8):
    from fraud.data.preprocessing import PreprocessingArtifacts
    arts = PreprocessingArtifacts.load(str(w["tmp"] / "artifacts/1"))
    cls = pg_patch.builder_class(mods["chunk_builder"].SequenceBuilder, s) if s is not None else \
        mods["chunk_builder"].SequenceBuilder
    return cls(file_list=[str(w["data"] / f"part_{i}.parquet") for i in files], artifacts=arts,
               features=w["features"], datetime_config=w["dt"], target_col=LABEL, account_col=ACCOUNT,
               order_col=TIME, history_len=3, stride=1, batch_size=batch_size, shuffle=shuffle,
               tie_break_col=ID, history_time_order="strict", emit_target_seq=True,
               all_position_layout="nonoverlapping_chunks", time_delta_reference="previous_transaction",
               max_chunk_rows=64)


def batches(ds):
    return list(iter(ds))


def test_rebuilt_chunks_equal_the_project_builder(world, mods):
    """With the data side on but changing nothing (share 1), the program builder's chunks are the project's."""
    s = pg_patch.settings_from(clean_account_share=1.0)
    ours, theirs = batches(builder(world, mods, s)), batches(builder(world, mods, None))
    assert len(ours) == len(theirs)
    for a, b in zip(ours, theirs):
        for k in ("continuous", "categorical", "mask", "target_seq", "time_seq"):
            assert torch.equal(a[k], b[k]), k
        assert torch.equal(a["loss_weight"], b["mask"].float())


def test_loss_mask_sampling_and_inverse_weights(world, mods):
    df = world["frames"][1]
    s = pg_patch.settings_from(loss_mask=["declines", "advice"], clean_account_share=0.5,
                               negative_weight="inverse")
    target = df[LABEL].to_numpy()
    w, kept = pg_patch.row_weights(df, target, s, ACCOUNT, TIME, ID)
    declined = df["predecline"].to_numpy() == 1
    advice = df["transaction_advice_xcd"].to_numpy() == "A"
    assert (w[declined | advice] == 0).all()
    fraud_accounts = set(df.loc[df[LABEL] == 1, ACCOUNT])
    assert fraud_accounts <= kept
    assert (w[target == 1] == 1).all()  # frauds always count, with weight 1
    counted_negatives = w[(target == 0) & (w > 0)]
    assert np.allclose(counted_negatives, 2.0)  # 1 / share
    # the batches carry the weights and leave out the clean accounts that were not drawn
    got = batches(builder(world, mods, s))
    assert all("loss_weight" in b for b in got)
    assert sum(int(b["mask"].sum()) for b in got) == int(df[ACCOUNT].isin(kept).sum())


def test_recency_weights_halve_per_half_life():
    df = pd.DataFrame({ACCOUNT: ["a"] * 3, TIME: pd.to_datetime(["2025-05-03", "2025-04-03", "2025-03-03"]),
                       LABEL: [0, 0, 0]})
    s = pg_patch.settings_from(recency_half_life_months=1.0)
    w, _ = pg_patch.row_weights(df, df[LABEL].to_numpy(), s, ACCOUNT, TIME)
    assert np.allclose(w, [1.0, 0.5, 0.25])


def test_prefix_rows_are_context_and_the_band_is_the_scoring_window(world, mods):
    s = pg_patch.settings_from(prefix_seconds=3, prefix_max_rows=31)
    got = batches(builder(world, mods, s, batch_size=4))
    plain = batches(builder(world, mods, None, batch_size=4))
    assert sum(int((b["loss_weight"] > 0).sum()) for b in got) == sum(int(b["mask"].sum()) for b in plain)
    assert any(int(b["mask"].sum()) > int((b["loss_weight"] > 0).sum()) for b in got)  # some context rows
    assert all("context_prefix" in b for b in got)
    # band visibility equals the target-ending window rule (3 earlier seconds here, the history length)
    window_bounds = mods["target_ending_data"].window_bounds
    for b in got:
        vis = pg_patch.band_visible(b["time_seq"], b["mask"], 3, 31)
        for r in range(b["mask"].shape[0]):
            n = int(b["mask"][r].sum())
            t = b["time_seq"][r, :n].numpy()
            lo, gs = window_bounds(t // 10 ** 9, t, 3, 32)
            for i in range(n):
                expected = np.zeros(n, bool)
                expected[lo[i]:gs[i]] = True
                assert np.array_equal(vis[r, i, :n].numpy(), expected)


def model(mods, seed=0):
    torch.manual_seed(seed)
    return mods["base_model"].FTTransformerHierModel(
        continuous_dim=3, categorical_cardinality=[4, 4], history_len=3, embed_dim=8, num_heads=2, num_txn_blocks=1,
        num_seq_blocks=1, attn_dropout=0.0, ff_dropout=0.0, attention_mask="causal", learning_rate=1e-3,
        weight_decay=0.0, pos_weight=1.0, predict_every_transaction=True, history_time_order="strict",
        all_position_layout="nonoverlapping_chunks",
        time_delta_reference="previous_transaction")


def toy_batch(width=6, rows=(6, 4), seed=0):
    g = torch.Generator().manual_seed(seed)
    B = len(rows)
    mask = torch.zeros(B, width, dtype=torch.bool)
    for b, n in enumerate(rows):
        mask[b, :n] = True
    secs = torch.cumsum(torch.randint(0, 3, (B, width), generator=g), 1) + 1_700_000_000
    return {"continuous": torch.randn(B, width, 3, generator=g),
            "categorical": torch.randint(0, 4, (B, width, 2), generator=g), "mask": mask,
            "target_seq": torch.where(mask, torch.randint(0, 2, (B, width), generator=g), torch.full_like(secs, -100)),
            "time_seq": torch.where(mask, secs * 10 ** 9, torch.zeros_like(secs))}


def test_weighted_and_focal_losses(mods):
    try:
        m = model(mods)
    except TypeError:
        pytest.skip("the base model's constructor differs here")
    batch = toy_batch()
    _, _, plain = m._step(batch, "train")
    s = pg_patch.settings_from()
    pg_patch.apply_model(s, type(m))
    try:
        ones = dict(batch, loss_weight=batch["mask"].float())
        _, _, weighted = m._step(ones, "train")
        assert torch.allclose(plain, weighted, atol=1e-6)
        half = batch["mask"].float()
        half[0, :3] = 0.0
        _, _, part = m._step(dict(batch, loss_weight=half), "train")
        logits = m(batch)
        ce = torch.nn.functional.cross_entropy(logits[batch["mask"]], batch["target_seq"][batch["mask"]],
                                               reduction="none")
        keep = half[batch["mask"]] > 0
        assert torch.allclose(part, ce[keep].mean(), atol=1e-6)
    finally:
        pg_patch.remove_model(type(m))
    pg_patch.apply_model(pg_patch.settings_from(loss="focal", focal_gamma=0.0), type(m))
    try:
        _, _, focal0 = m._step(batch, "train")
        assert torch.allclose(plain, focal0, atol=1e-6)  # gamma 0 is the plain loss
    finally:
        pg_patch.remove_model(type(m))


def run_train(w, mods, out, *options, extra=()):
    import pg_train
    try:
        return pg_train.main([*options, "--", "--config", str(w["cfg"]), *extra, f"output.checkpoint_dir={out}"])
    finally:
        pg_train.uninstall(mods)


def test_variants_train_and_score_with_the_normal_scorer(world, mods):
    out = world["tmp"] / "variant"
    rc = run_train(world, mods, out, "--loss-mask", "declines", "advice", "--clean-account-share", "0.6",
                   "--prefix-seconds", "2", "--ema-decay", "0.9", "--val-every-updates", "2", "--keep-near-update",
                   "3", "--grad-clip", "1.0", "--loss", "focal", "--plateau-monitor", "valid_ap",
                   "--profile-steps", "0", extra=["training.max_epochs=2"])
    assert rc == 0
    for name in ("best.ckpt", "last.ckpt", "best_ema.ckpt", "near_update.ckpt", "profile.json",
                 "program_settings.json", "ema_metrics.csv"):
        assert (out / name).is_file(), name
    ckpt = torch.load(out / "best.ckpt", map_location="cpu", weights_only=False)
    assert ckpt["program_settings"]["prefix_seconds"] == 2
    for name in ("best.ckpt", "best_ema.ckpt", "near_update.ckpt"):
        pred = world["tmp"] / f"{name}.parquet"
        mods["scorer"].main(score_args(world) + ["--checkpoint", str(out / name), "--out", str(pred)])
        assert len(pd.read_parquet(pred)) > 0


def test_files_list_local_dir_resume_after_scoring_and_warm_start(world, mods):
    lst = world["tmp"] / "files.txt"
    lst.write_text("2\n")
    out = world["tmp"] / "listed"
    assert run_train(world, mods, out, "--files-list", str(lst), "--local-dir", str(world["data"])) == 0
    settings = json.loads((out / "program_settings.json").read_text())
    assert settings["settings"]["files"] == [2]
    pred = world["tmp"] / "listed.parquet"
    mods["scorer"].main(score_args(world) + ["--checkpoint", str(out / "best.ckpt"), "--out", str(pred)])
    # the run was scored; a resume to a larger epoch budget still continues it
    assert run_train(world, mods, out, extra=["--resume", "training.max_epochs=2"]) == 0
    manifest = json.loads((out / "run_manifest_v2.json").read_text())
    assert manifest["epochs_run"] == 2 and manifest.get("scored_before_resume")
    warm = world["tmp"] / "warm"
    assert run_train(world, mods, warm, "--init-from", str(out / "best.ckpt")) == 0


def test_no_options_is_the_trainer_unchanged(world, mods):
    a, b = world["tmp"] / "plain_a", world["tmp"] / "plain_b"
    assert run_train(world, mods, a) == 0
    mods["trainer"].main(["--config", str(world["cfg"]), f"output.checkpoint_dir={b}"])
    sa = torch.load(a / "last.ckpt", map_location="cpu", weights_only=False)["state_dict"]
    sb = torch.load(b / "last.ckpt", map_location="cpu", weights_only=False)["state_dict"]
    assert sa.keys() == sb.keys()
    for k in sa:
        assert torch.allclose(sa[k], sb[k], atol=1e-6), k


def test_inverse_weight_only_for_rows_sampled_at_the_share():
    df = pd.DataFrame({ACCOUNT: ["f"] * 4 + ["c"] * 4, ID: [f"r{i}" for i in range(8)], TIME: pd.Timestamp("2025-05-01"),
                       LABEL: [1, 0, 0, 0, 0, 0, 0, 0]})
    keep = pg_patch.settings_from(clean_account_share=0.5, mask_fraud_account_negatives=False,
                                  negative_weight="inverse")
    w, kept = pg_patch.row_weights(df, df[LABEL].to_numpy(), keep, ACCOUNT, TIME, ID)
    assert np.allclose(w[:4], 1.0)  # the fraud account's rows are always counted: weight 1
    if "c" in kept:
        assert np.allclose(w[4:], 2.0)  # the clean account was drawn at 0.5: weight 2


def test_plateau_steps_once_per_validation():
    import pg_callbacks
    from types import SimpleNamespace
    p = torch.nn.Parameter(torch.zeros(1))
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(torch.optim.SGD([p], lr=1.0), patience=0, factor=0.5, mode="max")
    tr = SimpleNamespace(sanity_checking=False, callback_metrics={"valid_ap": torch.tensor(0.5)},
                         lr_scheduler_configs=[SimpleNamespace(scheduler=sched, monitor="valid_ap")])
    cb = pg_callbacks.PlateauEveryValidation()
    for _ in range(3):
        cb.on_validation_end(tr, None)
    assert sched.last_epoch == 3 and sched.optimizer.param_groups[0]["lr"] == 0.25  # no gain after the first


def test_resume_from_the_latest_whole_epoch_and_with_the_runs_own_options(world, mods, monkeypatch):
    import pg_callbacks
    import pg_train
    lst = world["tmp"] / "files.txt"
    lst.write_text("1\n2\n")
    plain = world["tmp"] / "plain"
    assert run_train(world, mods, plain, "--files-list", str(lst), "--val-every-updates", "2",
                     extra=["training.early_stopping_patience=100"]) == 0
    per_epoch = json.loads((plain / "run_manifest_v2.json").read_text())["optimizer_steps"]
    out = world["tmp"] / "cut"
    original = pg_callbacks.PlateauEveryValidation.on_validation_end

    def crash(self, trainer, pl_module):
        original(self, trainer, pl_module)
        if trainer.global_step >= per_epoch + 4:
            raise RuntimeError("the workbench stopped")  # inside epoch 1, after last.ckpt was written at +2

    monkeypatch.setattr(pg_callbacks.PlateauEveryValidation, "on_validation_end", crash)
    with pytest.raises(RuntimeError, match="workbench stopped"):
        run_train(world, mods, out, "--files-list", str(lst), "--val-every-updates", "2",
                  extra=["training.max_epochs=2", "training.early_stopping_patience=100"])
    monkeypatch.setattr(pg_callbacks.PlateauEveryValidation, "on_validation_end", original)
    assert (out / "epoch_end.ckpt").is_file()
    reused = pg_train.resume_options(pg_train.parser().parse_args([]), str(out))
    assert reused.files_list == str(lst) and reused.val_every_updates == 2  # the run's own options
    assert run_train(world, mods, out, extra=["--resume", "training.max_epochs=2",
                                              "training.early_stopping_patience=100"]) == 0
    assert (out / "last_mid_epoch.ckpt").is_file()
    m = json.loads((out / "run_manifest_v2.json").read_text())
    assert m["optimizer_steps"] == 2 * per_epoch  # the cut epoch was trained once, from its start
    assert (out / "program_settings.resume1.json").is_file()


def test_options_that_cannot_apply_stop_with_a_message(world, mods):
    out = world["tmp"] / "bad"
    assert run_train(world, mods, out, "--limit-val-batches", "0") == 2
    assert run_train(world, mods, out, "--loss-mask", "declines", extra=["sequence.train_target_ending=true"]) == 2
