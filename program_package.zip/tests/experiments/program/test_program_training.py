"""Training variants on the old layout, CPU only: the builder, the loss, the banded mask and full training runs.

Run: $PY -m pytest -q tests/experiments/program/test_program_training.py
"""
import json

import numpy as np
import pandas as pd
import pytest
import torch

from conftest import ACCOUNT, ID, LABEL, TIME, score_args

pg_layout = pytest.importorskip("pg_layout")
import pg_patch  # noqa: E402


@pytest.fixture
def mods():
    layout, m = pg_layout.resolve(roles=("base_model", "target_ending_model", "trainer", "scorer", "chunk_builder",
                                        "target_ending_data"))
    if layout != "old":
        pytest.skip("these tests run on the old code layout")
    return m


def builder(w, mods, s, files=(1,), shuffle=False, batch_size=8):
    from fraud.data.preprocessing import PreprocessingArtifacts
    arts = PreprocessingArtifacts.load(str(w["tmp"] / "artifacts/1"))
    cls = pg_patch.builder_class(mods["chunk_builder"].SequenceBuilder, s) if s is not None else \
        mods["chunk_builder"].SequenceBuilder
    return cls(file_list=[str(w["data"] / f"part_{i}.parquet") for i in files], artifacts=arts,
               features=w["features"], datetime_config=w["dt"], target_col=LABEL, account_col=ACCOUNT,
               order_col=TIME, history_len=3, stride=1, batch_size=batch_size, shuffle=shuffle,
               tie_break_col=ID, history_time_order="strict", emit_target_seq=True,
               all_position_layout="nonoverlapping_chunks", time_delta_reference="previous_transaction",
               max_chunk_rows=64)


def batches(ds):
    return list(iter(ds))


def test_rebuilt_chunks_equal_the_project_builder(world, mods):
    """With the data side on but changing nothing (share 1), the program builder's chunks are the project's."""
    s = pg_patch.settings_from(clean_account_share=1.0)
    ours, theirs = batches(builder(world, mods, s)), batches(builder(world, mods, None))
    assert len(ours) == len(theirs)
    for a, b in zip(ours, theirs):
        for k in ("continuous", "categorical", "mask", "target_seq", "time_seq"):
            assert torch.equal(a[k], b[k]), k
        assert torch.equal(a["loss_weight"], b["mask"].float())


def test_loss_mask_sampling_and_inverse_weights(world, mods):
    df = world["frames"][1]
    s = pg_patch.settings_from(loss_mask=["declines", "advice"], clean_account_share=0.5,
                               negative_weight="inverse")
    target = df[LABEL].to_numpy()
    w, kept = pg_patch.row_weights(df, target, s, ACCOUNT, TIME, ID)
    declined = df["predecline"].to_numpy() == 1
    advice = df["transaction_advice_xcd"].to_numpy() == "A"
    assert (w[declined | advice] == 0).all()
    fraud_accounts = set(df.loc[df[LABEL] == 1, ACCOUNT])
    assert fraud_accounts <= kept
    assert (w[target == 1] == 1).all()  # frauds always count, with weight 1
    counted_negatives = w[(target == 0) & (w > 0)]
    assert np.allclose(counted_negatives, 2.0)  # 1 / share
    # the batches carry the weights and leave out the clean accounts that were not drawn
    got = batches(builder(world, mods, s))
    assert all("loss_weight" in b for b in got)
    assert sum(int(b["mask"].sum()) for b in got) == int(df[ACCOUNT].isin(kept).sum())


def test_recency_weights_halve_per_half_life():
    df = pd.DataFrame({ACCOUNT: ["a"] * 3, TIME: pd.to_datetime(["2025-05-03", "2025-04-03", "2025-03-03"]),
                       LABEL: [0, 0, 0]})
    s = pg_patch.settings_from(recency_half_life_months=1.0)
    w, _ = pg_patch.row_weights(df, df[LABEL].to_numpy(), s, ACCOUNT, TIME)
    assert np.allclose(w, [1.0, 0.5, 0.25])


def test_prefix_rows_are_context_and_the_band_is_the_scoring_window(world, mods):
    s = pg_patch.settings_from(prefix_seconds=3, prefix_max_rows=31)
    got = batches(builder(world, mods, s, batch_size=4))
    plain = batches(builder(world, mods, None, batch_size=4))
    assert sum(int((b["loss_weight"] > 0).sum()) for b in got) == sum(int(b["mask"].sum()) for b in plain)
    assert any(int(b["mask"].sum()) > int((b["loss_weight"] > 0).sum()) for b in got)  # some context rows
    assert all("context_prefix" in b for b in got)
    # band visibility equals the target-ending window rule (3 earlier seconds here, the history length)
    window_bounds = mods["target_ending_data"].window_bounds
    for b in got:
        vis = pg_patch.band_visible(b["time_seq"], b["mask"], 3, 31)
        for r in range(b["mask"].shape[0]):
            n = int(b["mask"][r].sum())
            t = b["time_seq"][r, :n].numpy()
            lo, gs = window_bounds(t // 10 ** 9, t, 3, 32)
            for i in range(n):
                expected = np.zeros(n, bool)
                expected[lo[i]:gs[i]] = True
                assert np.array_equal(vis[r, i, :n].numpy(), expected)


def model(mods, seed=0):
    torch.manual_seed(seed)
    return mods["base_model"].FTTransformerHierModel(
        continuous_dim=3, categorical_cardinality=[4, 4], history_len=3, embed_dim=8, num_heads=2, num_txn_blocks=1,
        num_seq_blocks=1, attn_dropout=0.0, ff_dropout=0.0, attention_mask="causal", learning_rate=1e-3,
        weight_decay=0.0, pos_weight=1.0, predict_every_transaction=True, history_time_order="strict",
        all_position_layout="nonoverlapping_chunks",
        time_delta_reference="previous_transaction")


def toy_batch(width=6, rows=(6, 4), seed=0):
    g = torch.Generator().manual_seed(seed)
    B = len(rows)
    mask = torch.zeros(B, width, dtype=torch.bool)
    for b, n in enumerate(rows):
        mask[b, :n] = True
    secs = torch.cumsum(torch.randint(0, 3, (B, width), generator=g), 1) + 1_700_000_000
    return {"continuous": torch.randn(B, width, 3, generator=g),
            "categorical": torch.randint(0, 4, (B, width, 2), generator=g), "mask": mask,
            "target_seq": torch.where(mask, torch.randint(0, 2, (B, width), generator=g), torch.full_like(secs, -100)),
            "time_seq": torch.where(mask, secs * 10 ** 9, torch.zeros_like(secs))}


def test_weighted_and_focal_losses(mods):
    try:
        m = model(mods)
    except TypeError:
        pytest.skip("the base model's constructor differs here")
    batch = toy_batch()
    _, _, plain = m._step(batch, "train")
    s = pg_patch.settings_from()
    pg_patch.apply_model(s, type(m))
    try:
        ones = dict(batch, loss_weight=batch["mask"].float())
        _, _, weighted = m._step(ones, "train")
        assert torch.allclose(plain, weighted, atol=1e-6)
        half = batch["mask"].float()
        half[0, :3] = 0.0
        _, _, part = m._step(dict(batch, loss_weight=half), "train")
        logits = m(batch)
        ce = torch.nn.functional.cross_entropy(logits[batch["mask"]], batch["target_seq"][batch["mask"]],
                                               reduction="none")
        keep = half[batch["mask"]] > 0
        assert torch.allclose(part, ce[keep].mean(), atol=1e-6)
    finally:
        pg_patch.remove_model(type(m))
    pg_patch.apply_model(pg_patch.settings_from(loss="focal", focal_gamma=0.0), type(m))
    try:
        _, _, focal0 = m._step(batch, "train")
        assert torch.allclose(plain, focal0, atol=1e-6)  # gamma 0 is the plain loss
    finally:
        pg_patch.remove_model(type(m))


def run_train(w, mods, out, *options, extra=()):
    import pg_train
    try:
        return pg_train.main([*options, "--", "--config", str(w["cfg"]), *extra, f"output.checkpoint_dir={out}"])
    finally:
        pg_train.uninstall(mods)


def test_variants_train_and_score_with_the_normal_scorer(world, mods):
    out = world["tmp"] / "variant"
    rc = run_train(world, mods, out, "--loss-mask", "declines", "advice", "--clean-account-share", "0.6",
                   "--prefix-seconds", "2", "--ema-decay", "0.9", "--val-every-updates", "2", "--keep-near-update",
                   "3", "--grad-clip", "1.0", "--loss", "focal", "--plateau-monitor", "valid_ap",
                   "--profile-steps", "0", extra=["training.max_epochs=2"])
    assert rc == 0
    for name in ("best.ckpt", "last.ckpt", "best_ema.ckpt", "near_update.ckpt", "profile.json",
                 "program_settings.json", "ema_metrics.csv"):
        assert (out / name).is_file(), name
    ckpt = torch.load(out / "best.ckpt", map_location="cpu", weights_only=False)
    assert ckpt["program_settings"]["prefix_seconds"] == 2
    for name in ("best.ckpt", "best_ema.ckpt", "near_update.ckpt"):
        pred = world["tmp"] / f"{name}.parquet"
        mods["scorer"].main(score_args(world) + ["--checkpoint", str(out / name), "--out", str(pred)])
        assert len(pd.read_parquet(pred)) > 0


def test_files_list_local_dir_resume_after_scoring_and_warm_start(world, mods):
    lst = world["tmp"] / "files.txt"
    lst.write_text("2\n")
    out = world["tmp"] / "listed"
    assert run_train(world, mods, out, "--files-list", str(lst), "--local-dir", str(world["data"])) == 0
    settings = json.loads((out / "program_settings.json").read_text())
    assert settings["settings"]["files"] == [2]
    pred = world["tmp"] / "listed.parquet"
    mods["scorer"].main(score_args(world) + ["--checkpoint", str(out / "best.ckpt"), "--out", str(pred)])
    # the run was scored; a resume to a larger epoch budget still continues it
    assert run_train(world, mods, out, extra=["--resume", "training.max_epochs=2"]) == 0
    manifest = json.loads((out / "run_manifest_v2.json").read_text())
    assert manifest["epochs_run"] == 2 and manifest.get("scored_before_resume")
    warm = world["tmp"] / "warm"
    assert run_train(world, mods, warm, "--init-from", str(out / "best.ckpt")) == 0


def test_no_options_is_the_trainer_unchanged(world, mods):
    a, b = world["tmp"] / "plain_a", world["tmp"] / "plain_b"
    assert run_train(world, mods, a) == 0
    mods["trainer"].main(["--config", str(world["cfg"]), f"output.checkpoint_dir={b}"])
    sa = torch.load(a / "last.ckpt", map_location="cpu", weights_only=False)["state_dict"]
    sb = torch.load(b / "last.ckpt", map_location="cpu", weights_only=False)["state_dict"]
    assert sa.keys() == sb.keys()
    for k in sa:
        assert torch.allclose(sa[k], sb[k], atol=1e-6), k


def test_inverse_weight_only_for_rows_sampled_at_the_share():
    df = pd.DataFrame({ACCOUNT: ["f"] * 4 + ["c"] * 4, ID: [f"r{i}" for i in range(8)], TIME: pd.Timestamp("2025-05-01"),
                       LABEL: [1, 0, 0, 0, 0, 0, 0, 0]})
    keep = pg_patch.settings_from(clean_account_share=0.5, mask_fraud_account_negatives=False,
                                  negative_weight="inverse")
    w, kept = pg_patch.row_weights(df, df[LABEL].to_numpy(), keep, ACCOUNT, TIME, ID)
    assert np.allclose(w[:4], 1.0)  # the fraud account's rows are always counted: weight 1
    if "c" in kept:
        assert np.allclose(w[4:], 2.0)  # the clean account was drawn at 0.5: weight 2


def test_plateau_steps_once_per_validation():
    import pg_callbacks
    from types import SimpleNamespace
    p = torch.nn.Parameter(torch.zeros(1))
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(torch.optim.SGD([p], lr=1.0), patience=0, factor=0.5, mode="max")
    tr = SimpleNamespace(sanity_checking=False, callback_metrics={"valid_ap": torch.tensor(0.5)},
                         lr_scheduler_configs=[SimpleNamespace(scheduler=sched, monitor="valid_ap")])
    cb = pg_callbacks.PlateauEveryValidation()
    for _ in range(3):
        cb.on_validation_end(tr, None)
    assert sched.last_epoch == 3 and sched.optimizer.param_groups[0]["lr"] == 0.25  # no gain after the first


def test_resume_from_the_latest_whole_epoch_and_with_the_runs_own_options(world, mods, monkeypatch):
    import pg_callbacks
    import pg_train
    lst = world["tmp"] / "files.txt"
    lst.write_text("1\n2\n")
    plain = world["tmp"] / "plain"
    assert run_train(world, mods, plain, "--files-list", str(lst), "--val-every-updates", "2",
                     extra=["training.early_stopping_patience=100"]) == 0
    per_epoch = json.loads((plain / "run_manifest_v2.json").read_text())["optimizer_steps"]
    out = world["tmp"] / "cut"
    original = pg_callbacks.PlateauEveryValidation.on_validation_end

    def crash(self, trainer, pl_module):
        original(self, trainer, pl_module)
        if trainer.global_step >= per_epoch + 4:
            raise RuntimeError("the workbench stopped")  # inside epoch 1, after last.ckpt was written at +2

    monkeypatch.setattr(pg_callbacks.PlateauEveryValidation, "on_validation_end", crash)
    with pytest.raises(RuntimeError, match="workbench stopped"):
        run_train(world, mods, out, "--files-list", str(lst), "--val-every-updates", "2",
                  extra=["training.max_epochs=2", "training.early_stopping_patience=100"])
    monkeypatch.setattr(pg_callbacks.PlateauEveryValidation, "on_validation_end", original)
    assert (out / "epoch_end.ckpt").is_file()
    reused = pg_train.resume_options(pg_train.parser().parse_args([]), str(out))
    assert reused.files_list == str(lst) and reused.val_every_updates == 2  # the run's own options
    assert run_train(world, mods, out, extra=["--resume", "training.max_epochs=2",
                                              "training.early_stopping_patience=100"]) == 0
    assert (out / "last_mid_epoch.ckpt").is_file()
    m = json.loads((out / "run_manifest_v2.json").read_text())
    assert m["optimizer_steps"] == 2 * per_epoch  # the cut epoch was trained once, from its start
    assert (out / "program_settings.resume1.json").is_file()


def test_options_that_cannot_apply_stop_with_a_message(world, mods):
    out = world["tmp"] / "bad"
    assert run_train(world, mods, out, "--limit-val-batches", "0") == 2
    assert run_train(world, mods, out, "--loss-mask", "declines", extra=["sequence.train_target_ending=true"]) == 2


def test_no_window_cap_means_no_row_limit_in_band_and_prefix(world, mods):
    from types import SimpleNamespace
    import pg_train
    cfg = SimpleNamespace(sequence={"history_len": 3, "max_window_rows": None})
    cfg.sequence = type("Seq", (dict,), {"__getattr__": dict.__getitem__})(cfg.sequence)
    s = pg_train.window_caps(cfg, pg_patch.settings_from(prefix_seconds=3), None)
    assert s["band_seconds"] == 3 and s["band_rows"] is None and s["prefix_max_rows"] is None
    cfg.sequence["max_window_rows"] = 137
    assert pg_train.window_caps(cfg, dict(s), None)["band_rows"] == 136
    assert pg_train.window_caps(cfg, dict(s), None)["prefix_max_rows"] == 136
    assert pg_train.window_caps(cfg, dict(s), 50)["prefix_max_rows"] == 50
    # with no row limit, the band equals the uncapped target-ending window, and a 1-row cap would differ
    got = batches(builder(world, mods, s, batch_size=4))
    window_bounds = mods["target_ending_data"].window_bounds
    differs = False
    for b in got:
        vis = pg_patch.band_visible(b["time_seq"], b["mask"], 3, None)
        tight = pg_patch.band_visible(b["time_seq"], b["mask"], 3, 1)
        differs |= bool((vis != tight).any())
        for r in range(b["mask"].shape[0]):
            n = int(b["mask"][r].sum())
            t = b["time_seq"][r, :n].numpy()
            lo, gs = window_bounds(t // 10 ** 9, t, 3, None)
            for i in range(n):
                expected = np.zeros(n, bool)
                expected[lo[i]:gs[i]] = True
                assert np.array_equal(vis[r, i, :n].numpy(), expected)
    assert differs


def wide_batch(rows, width=8, seed=0):
    """Windows of up to `width` rows, two rows per second (so at most width / 2 distinct seconds)."""
    b = toy_batch(width=width, rows=rows, seed=seed)
    secs = (1_700_000_000 + torch.arange(width) // 2) * 10 ** 9
    b["time_seq"] = torch.where(b["mask"], secs.expand(len(rows), width), torch.zeros(len(rows), width,
                                                                                       dtype=torch.long))
    return b


def test_wide_batches_run_in_parts_with_the_same_scores_and_gradients(mods, monkeypatch):
    try:
        m = model(mods)
    except TypeError:
        pytest.skip("the base model's constructor differs here")
    b = wide_batch((8, 4, 5, 3, 7, 2, 6, 1))
    real = b["mask"]
    m.eval()
    with torch.no_grad():
        ref = m(b)
    cls_ref = m._cls.clone()
    m.train()
    m.zero_grad()
    loss_ref = m._step(b, "train")[2]
    loss_ref.backward()
    grads_ref = {k: p.grad.clone() for k, p in m.named_parameters() if p.grad is not None}
    pg_patch.install_wide_batches(type(m))
    try:
        monkeypatch.setattr(pg_patch, "LAUNCH_ROWS", 1)  # every batch runs in parts
        monkeypatch.setattr(pg_patch, "PART_ROWS", 13)
        parts = pg_patch.batch_parts(real.sum(1), 8, m.T, 2, True)
        assert len(parts) > 1 and sorted(torch.cat([i for i, _ in parts]).tolist()) == list(range(8))
        assert all(w <= 8 for _, w in parts) and parts[-1][1] == m.T  # narrow windows run in narrow parts
        seen = []
        hook = m.head.register_forward_pre_hook(lambda module, inputs: seen.append(tuple(inputs[0].shape)))
        m.eval()
        with torch.no_grad():
            got = m(b)
        hook.remove()
        assert got.shape == ref.shape and torch.allclose(got[real], ref[real], atol=1e-5)
        assert torch.allclose(m._cls, cls_ref, atol=1e-5)
        assert seen[-1] == (8, 8, 8)  # the head's last call (the exporter's capture) holds the whole batch
        m.train()
        m.zero_grad()
        loss = m._step(b, "train")[2]
        loss.backward()
        assert torch.allclose(loss, loss_ref, atol=1e-6)
        params = dict(m.named_parameters())
        for k, g in grads_ref.items():
            assert torch.allclose(params[k].grad, g, atol=1e-5), k
    finally:
        pg_patch.remove_wide_batches(type(m))


def test_no_cap_trains_scores_and_exports_with_no_row_limits(world, mods, monkeypatch):
    import pg_export
    import pg_score
    monkeypatch.setattr(pg_patch, "LAUNCH_ROWS", 1)  # every batch runs in parts: the no-limit path end to end
    monkeypatch.setattr(pg_patch, "PART_ROWS", 20)
    nocap = ["sequence.max_window_rows=null", "sequence.max_chunk_rows=4"]  # a chunk limit the trainer would stop on
    with pytest.raises(ValueError):
        mods["trainer"].main(["--config", str(world["cfg"]), *nocap, f"output.checkpoint_dir={world['tmp'] / 'x'}"])
    out = world["tmp"] / "nocap"
    assert run_train(world, mods, out, "--prefix-seconds", "2", extra=nocap) == 0
    ckpt = out / "best.ckpt"
    assert torch.load(ckpt, map_location="cpu", weights_only=False)["validation_policy"]["max_window_rows"] is None
    parts = world["tmp"] / "nocap_parts.parquet"
    assert pg_score.main(score_args(world) + ["sequence.max_window_rows=null", "--checkpoint", str(ckpt),
                                              "--out", str(parts)]) == 0
    assert mods["base_model"].FTTransformerHierModel not in pg_patch._WIDE  # put back after scoring
    one = world["tmp"] / "nocap_one.parquet"
    mods["scorer"].main(score_args(world) + ["sequence.max_window_rows=null", "--checkpoint", str(ckpt),
                                             "--out", str(one)])
    a, b = pd.read_parquet(parts), pd.read_parquet(one)
    m = a.merge(b[[ID, "score"]], on=ID, suffixes=("", "_one"))
    assert len(m) == len(a) == len(b) > 0 and np.allclose(m["score"], m["score_one"], atol=1e-6)
    exp = world["tmp"] / "nocap_export.parquet"
    assert pg_export.main(["--checkpoint", str(ckpt), "--out", str(exp), "--", "--config", str(world["cfg"]),
                           f"eval.base={world['data']}", "eval.file_start=3", "eval.file_end=3",
                           "sequence.max_window_rows=null"]) == 0
    e = pd.read_parquet(exp).merge(b[[ID, "score"]], on=ID, suffixes=("", "_one"))
    assert len(e) == len(b) and np.allclose(e["score"], e["score_one"], atol=1e-6)
    assert np.allclose(e["score"], e["score_check"], atol=1e-5)
    assert e["window_rows"].max() > 4  # windows wider than the dropped chunk limit were scored


def test_the_config_cap_decides_at_scoring(world, mods):
    """A checkpoint validated with a cap is scored with no cap when the config says null, and the other way round."""
    import pg_score
    capped = world["tmp"] / "capped"
    assert run_train(world, mods, capped, extra=["sequence.max_window_rows=5"]) == 0
    ckpt = capped / "best.ckpt"
    assert torch.load(ckpt, map_location="cpu", weights_only=False)["validation_policy"]["max_window_rows"] == 5
    for cap, name in (("null", "free"), ("5", "five")):
        pred = world["tmp"] / f"{name}.parquet"
        assert pg_score.main(score_args(world) + [f"sequence.max_window_rows={cap}", "--checkpoint", str(ckpt),
                                                  "--out", str(pred)]) == 0
        receipt = json.loads((world["tmp"] / f"{name}.parquet.json").read_text())
        assert receipt["max_window_rows"] == (None if cap == "null" else 5)
    assert mods["scorer"].checkpoint_policy.__name__ == "checkpoint_policy" and \
        mods["scorer"].checkpoint_policy.__module__ == mods["scorer"].__name__  # put back after scoring


def test_learning_rate_plan_factor():
    """Warm-up in equal rises, the peak until the cooldown starts, then 1 - sqrt(progress) down to 0 at the last update."""
    f = pg_patch.plan_factor
    warm = [f(s, 1000, 100, 0.2) for s in range(100)]
    rises = np.diff(warm)
    assert np.allclose(rises, rises[0]) and rises[0] > 0 and 0 < warm[0] < 0.02
    assert f(100, 1000, 100, 0.2) == 1.0 and f(799, 1000, 100, 0.2) == 1.0     # the peak until update 800
    assert f(800, 1000, 100, 0.2) == 1.0 and f(850, 1000, 100, 0.2) == pytest.approx(0.5)
    assert f(900, 1000, 100, 0.2) == pytest.approx(1 - np.sqrt(0.5))
    fall = [f(s, 1000, 100, 0.2) for s in range(800, 1001)]
    assert all(b <= a for a, b in zip(fall, fall[1:])) and fall[-1] == 0.0      # it never rises again
    assert f(1000, 1000, 100, 0.2) == 0.0 and f(10 ** 9, 1000, 100, 0.2) == 0.0  # a longer run stays at 0
    # a share of 1 starts the fall right after the warm-up: the cooldown of a model that is already trained
    assert f(49, 400, 50, 1.0) == pytest.approx(50 / 51) and f(50, 400, 50, 1.0) == 1.0
    assert f(51, 400, 50, 1.0) < 1.0 and f(225, 400, 50, 1.0) == pytest.approx(1 - np.sqrt(0.5))
    assert f(0, 10, 0, 0.5) == 1.0 and f(5, 10, 0, 0.5) == 1.0 and f(10, 10, 0, 0.5) == 0.0


def test_learning_rate_plan_runs_and_ends_at_zero(world, mods, capsys):
    """A run with the plan: the rate changes at every update, the plateau rule is gone, and the last checkpoint holds
    the weights of the last update with the rate at 0."""
    out = world["tmp"] / "planned"
    rc = run_train(world, mods, out, "--max-steps", "8", "--lr-warmup-updates", "2", "--lr-cooldown-share", "0.5",
                   "--val-every-updates", "2", "--limit-val-batches", "2",
                   extra=["training.max_epochs=50", "training.early_stopping_patience=100000"])
    assert rc == 0
    printed = capsys.readouterr().out
    assert "learning rate at update 0:" in printed and "learning rate at update 8: 0.000e+00" in printed
    settings = json.loads((out / "program_settings.json").read_text())
    assert settings["settings"]["lr_plan"] == {"max_steps": 8, "warmup": 2, "cooldown_share": 0.5}
    last = torch.load(out / "last.ckpt", map_location="cpu", weights_only=False)
    assert last["global_step"] == 8
    assert last["optimizer_states"][0]["param_groups"][0]["lr"] == 0.0
    scheduler = last["lr_schedulers"][0]
    assert scheduler["last_epoch"] == 8 and "best" not in scheduler            # a planned schedule, not the plateau rule
    peak = scheduler["base_lrs"][0]
    assert peak > 0
    assert last["program_settings"]["lr_plan"]["max_steps"] == 8


def test_learning_rate_plan_needs_the_length_of_the_run(world, mods):
    """The plan cannot be laid out without --max-steps, and its two numbers have to make sense."""
    out = world["tmp"] / "bad_plan"
    assert run_train(world, mods, out, "--lr-warmup-updates", "5") == 2
    assert run_train(world, mods, out, "--lr-cooldown-share", "0.2") == 2
    assert run_train(world, mods, out, "--max-steps", "10", "--lr-cooldown-share", "1.5") == 2
    assert run_train(world, mods, out, "--max-steps", "10", "--lr-cooldown-share", "0") == 2
    assert run_train(world, mods, out, "--max-steps", "10", "--lr-warmup-updates", "10") == 2


def test_cooldown_of_a_trained_model_starts_from_its_weights(world, mods, capsys):
    """--init-from with a cooldown share of 1: the trained weights are loaded and the rate falls from the first update
    after the warm-up."""
    first = world["tmp"] / "trained"
    assert run_train(world, mods, first) == 0
    out = world["tmp"] / "cooled"
    rc = run_train(world, mods, out, "--init-from", str(first / "best.ckpt"), "--max-steps", "6",
                   "--lr-warmup-updates", "1", "--lr-cooldown-share", "1.0", "--val-every-updates", "3",
                   "--limit-val-batches", "2", extra=["training.max_epochs=50", "training.early_stopping_patience=100000"])
    assert rc == 0
    printed = capsys.readouterr().out
    assert "warm start from" in printed and "learning rate at update 6: 0.000e+00" in printed
    cooled = torch.load(out / "last.ckpt", map_location="cpu", weights_only=False)
    trained = torch.load(first / "best.ckpt", map_location="cpu", weights_only=False)
    assert cooled["global_step"] == 6 and set(cooled["state_dict"]) == set(trained["state_dict"])
    moved = sum(float((cooled["state_dict"][k].float() - trained["state_dict"][k].float()).abs().sum())
                for k in trained["state_dict"])
    assert moved > 0                                                            # training went on from those weights



def test_data_options_say_what_they_did_to_the_first_file(world, mods, capsys):
    """One printed line per worker: rows read, rows with a loss, frauds kept, and a mask whose column is missing."""
    s = pg_patch.settings_from(loss_mask=["declines"], clean_account_share=0.5)
    ds = builder(world, mods, s)
    list(batches(ds))
    line = [x for x in capsys.readouterr().out.splitlines() if x.startswith("program data options")]
    assert len(line) == 1                                                    # once, not once per file or batch
    assert "declines rows without a loss" in line[0] and "accounts kept" in line[0] and "at share 0.5" in line[0]
    frauds = line[0].split("frauds with a loss ")[1].split(";")[0]
    kept, total = frauds.split(" of ")
    assert kept == total and int(total) > 0                                   # every fraud still carries a loss
    df = pd.DataFrame({ACCOUNT: ["a", "a", "b"], "x": [1, 2, 3]})
    report = pg_patch.data_report(df, np.array([0, 1, 0]), np.array([1.0, 1.0, 0.0]), {"a"},
                                  pg_patch.settings_from(loss_mask=["declines"], clean_account_share=0.5), ACCOUNT)
    assert "NO column 'predecline' in the data, so the declines mask did nothing" in report
    assert "rows the model reads 2 (66.7%)" in report and "frauds with a loss 1 of 1" in report


def test_card_prints_what_a_run_is(world, mods, capsys):
    """pg_card.py reads only what the trainer left in the run folder and says the run's length, rate, size and files."""
    import pg_card
    out = world["tmp"] / "carded"
    assert run_train(world, mods, out, "--loss-mask", "declines", "--max-steps", "4", "--lr-warmup-updates", "1",
                     "--lr-cooldown-share", "0.5", "--val-every-updates", "2", "--limit-val-batches", "2",
                     extra=["training.max_epochs=50", "training.early_stopping_patience=100000"]) == 0
    capsys.readouterr()
    assert pg_card.main([str(out)]) == 0
    printed = capsys.readouterr().out
    lines = {line.split(" ", 1)[0]: line for line in printed.splitlines() if line and not line.startswith(" ")}
    assert "updates 4" in lines["length"] and "status finished" in lines["length"]
    assert "at the end 0.000e+00" in lines["rate"] and "so it reached 0" in lines["rate"] and "fixed plan" in printed
    assert "loss_mask = ['declines']" in lines["options"] and "lr_plan" in lines["options"]
    state = torch.load(out / "last.ckpt", map_location="cpu", weights_only=False)["state_dict"]
    total = sum(int(v.numel()) for v in state.values())
    assert f"total {total:,}" in lines["weights"]
    assert "codes" in lines["fields"] and "token_encoder" in lines["blocks"] and "seq_encoder" in lines["blocks"]
    assert "validations" in lines["valid"] and "training:" in lines["files"] and "batch_size" in printed
    assert max(len(line) for line in printed.splitlines()) <= pg_card.WIDTH
    assert pg_card.main([str(out), "--checkpoint", "missing.ckpt"]) == 2
    assert pg_card.main([str(out), "--features"]) == 0
    assert "listed:" in capsys.readouterr().out



def test_clock_plan_factor():
    """The plan on the clock: the warm-up counts updates, the cooldown follows the seconds, and the end is 0."""
    import pg_callbacks
    f = pg_callbacks.clock_factor
    assert [f(u, 0.0, 100.0, 4, 0.2) for u in (0, 1, 3, 4, 9)] == [0.2, 0.4, 0.8, 1.0, 1.0]
    assert f(50, 79.9, 100.0, 4, 0.2) == 1.0 and f(50, 80.0, 100.0, 4, 0.2) == 1.0     # the cooldown starts at 80 s
    assert f(50, 85.0, 100.0, 4, 0.2) == pytest.approx(0.5)                             # a quarter in: 1 - sqrt(1/4)
    assert f(50, 95.0, 100.0, 4, 0.2) == pytest.approx(1 - np.sqrt(0.75))
    assert f(50, 100.0, 100.0, 4, 0.2) == 0.0 and f(50, 1e9, 100.0, 4, 0.2) == 0.0      # over: 0 and it stays 0
    assert f(10, 25.0, 100.0, 0, 1.0) == pytest.approx(0.5)                             # share 1: the fall starts at once
    assert f(1, 90.0, 100.0, 4, 0.2) == pytest.approx(0.4 * (1 - np.sqrt(0.5)))         # both at once: multiplied
    falling = [f(99, e, 100.0, 0, 0.2) for e in np.linspace(80, 100, 41)]
    assert all(b <= a for a, b in zip(falling, falling[1:])) and min(falling) == 0.0


class _ClockTrainer:
    """What ClockPlan uses of a trainer: the optimizers' parameter groups, the update count, the stop flag and
    save_checkpoint (which only notes the file name here)."""

    def __init__(self, rates=(3e-4, 1e-4)):
        from types import SimpleNamespace
        self.optimizers = [SimpleNamespace(param_groups=[{"lr": r} for r in rates])]
        self.global_step, self.should_stop, self.sanity_checking, self.saved = 0, False, False, []

    def save_checkpoint(self, path):
        self.saved.append(str(path).rsplit("/", 1)[-1])

    def rates(self):
        return [g["lr"] for g in self.optimizers[0].param_groups]


def test_clock_plan_sets_the_rate_saves_on_time_and_continues_after_a_resume(tmp_path, monkeypatch, capsys):
    """With a clock the test moves: every parameter group follows its own peak, clock.ckpt is written every
    `save_minutes`, the fit is asked to stop when the hours are over with the rate at 0, final.ckpt is written at
    the end, and a plan loaded from a checkpoint continues at the checkpoint's time with the same peaks."""
    import pg_callbacks
    now = {"t": 1000.0}
    monkeypatch.setattr(pg_callbacks.ClockPlan, "clock", staticmethod(lambda: now["t"]))
    plan = pg_callbacks.ClockPlan(str(tmp_path), hours=1.0, warmup=2, cooldown_share=0.5, save_minutes=10)
    tr = _ClockTrainer()
    plan.on_train_start(tr, None)
    assert tr.rates() == pytest.approx([3e-4 / 3, 1e-4 / 3])                    # update 0 of a warm-up of 2

    def batch(seconds, update):
        now["t"] = 1000.0 + seconds
        tr.global_step = update
        plan.on_train_batch_start(tr, None, None, 0)
        rates = tr.rates()
        plan.on_train_batch_end(tr, None, None, None, 0)
        return rates

    assert batch(1, 1) == pytest.approx([2e-4, 1e-4 * 2 / 3])
    assert batch(300, 2) == pytest.approx([3e-4, 1e-4]) and tr.saved == []      # the peak; no save before 10 minutes
    assert batch(601, 3) == pytest.approx([3e-4, 1e-4]) and tr.saved == ["clock.ckpt"]
    assert batch(900, 4) == pytest.approx([3e-4, 1e-4]) and tr.saved == ["clock.ckpt"]
    assert batch(1800, 5) == pytest.approx([3e-4, 1e-4])                        # the cooldown starts at half an hour
    assert tr.saved == ["clock.ckpt", "clock.ckpt"]
    saved_state = plan.state_dict()                                             # what a checkpoint written now holds
    assert saved_state["elapsed"] == pytest.approx(1800.0) and saved_state["ended"] is False
    assert batch(2250, 6) == pytest.approx([1.5e-4, 0.5e-4])                    # a quarter of the cooldown: half
    assert not tr.should_stop
    last = batch(3600, 7)                                                       # the hour is over during this batch
    assert last == [0.0, 0.0] and tr.should_stop and tr.rates() == [0.0, 0.0]
    plan.on_validation_end(tr, None)
    plan.on_train_end(tr, None)
    assert tr.saved[-1] == "final.ckpt" and plan.state_dict()["ended"] is True
    printed = capsys.readouterr().out
    assert "the 1 hours are over at update 7" in printed and "the plan ran to its end" in printed
    assert "1.00 of 1 hours, learning rate 0.000e+00" in printed

    # a stop by hand leaves the weights of that moment
    plan.on_exception(tr, None, KeyboardInterrupt())
    assert tr.saved[-1] == "clock.ckpt" and "KeyboardInterrupt" in capsys.readouterr().out

    # a resume from the checkpoint written at half an hour: the optimizer holds a lowered rate, the plan its peaks
    now["t"] = 50_000.0
    again = pg_callbacks.ClockPlan(str(tmp_path), hours=1.0, warmup=2, cooldown_share=0.5, save_minutes=10)
    again.load_state_dict(saved_state)
    tr2 = _ClockTrainer(rates=(1.2e-4, 0.4e-4))
    tr2.global_step = 5
    again.on_train_start(tr2, None)
    assert again.elapsed() == pytest.approx(1800.0) and tr2.rates() == pytest.approx([3e-4, 1e-4])
    now["t"] = 50_000.0 + 450.0
    again.on_train_batch_start(tr2, None, None, 0)
    assert tr2.rates() == pytest.approx([1.5e-4, 0.5e-4])                       # 2,250 seconds of the plan
    # a fit that ends before the hours says so
    again.on_train_end(tr2, None)
    assert "before the plan's end" in capsys.readouterr().out and tr2.saved == ["final.ckpt"]


def test_run_by_the_clock_ends_with_the_rate_at_zero(world, mods, capsys):
    """A real run of a few seconds planned by the clock: it passes over the files as often as the time allows, stops
    when the time is over, and every checkpoint written at the end holds the last update with the rate at 0."""
    import pg_card
    out = world["tmp"] / "clocked"
    rc = run_train(world, mods, out, "--train-hours", "0.0008", "--lr-warmup-updates", "2", "--lr-cooldown-share",
                   "0.5", "--val-every-updates", "4", "--limit-val-batches", "2", "--grad-clip", "1.0",
                   "--ema-decay", "0.9")
    assert rc == 0
    printed = capsys.readouterr().out
    assert "training.max_epochs=1000 added" in printed and "training.early_stopping_patience=100000 added" in printed
    assert "clock plan: 0.0008 hours from now" in printed and "hours are over at update" in printed
    assert "the plan ran to its end" in printed
    settings = json.loads((out / "program_settings.json").read_text())
    assert settings["settings"]["lr_plan"] == {"hours": 0.0008, "warmup": 2, "cooldown_share": 0.5}
    assert "training.max_epochs=1000" in settings["trainer_args"]
    final = torch.load(out / "final.ckpt", map_location="cpu", weights_only=False)
    last = torch.load(out / "last.ckpt", map_location="cpu", weights_only=False)
    assert final["global_step"] > 2 and final["global_step"] == last["global_step"]   # a validation followed the stop
    assert final["epoch"] >= 1                                                         # more than one pass in the time
    for ckpt in (final, last):
        assert ckpt["optimizer_states"][0]["param_groups"][0]["lr"] == 0.0
        assert ckpt["lr_schedulers"] == []                                             # no scheduler: the clock sets the rate
    for name in final["state_dict"]:
        assert torch.equal(final["state_dict"][name], last["state_dict"][name]), name
    state = [v for k, v in final["callbacks"].items() if "ClockPlan" in str(k)][0]
    assert state["ended"] is True and state["elapsed"] >= 0.0008 * 3600 and state["peaks"][0][0] > 0
    assert final["program_settings"]["lr_plan"]["hours"] == 0.0008
    assert (out / "best_ema.ckpt").is_file()
    # the checkpoint scores in the normal scorer, and the card says what the run was
    pred = world["tmp"] / "clocked.parquet"
    mods["scorer"].main(score_args(world) + ["--checkpoint", str(out / "final.ckpt"), "--out", str(pred)])
    assert len(pd.read_parquet(pred)) > 0
    assert pg_card.card(str(out), "final.ckpt") == 0
    card = capsys.readouterr().out
    assert "planned by the clock" in card and "the plan ran to its end" in card and "so it reached 0" in card


def test_the_clock_and_a_number_of_updates_do_not_go_together(world, mods):
    """--train-hours ends the run by the clock; with --max-steps, or with numbers that make no plan, nothing starts."""
    out = world["tmp"] / "bad_clock"
    assert run_train(world, mods, out, "--train-hours", "1", "--max-steps", "10") == 2
    assert run_train(world, mods, out, "--train-hours", "0") == 2
    assert run_train(world, mods, out, "--train-hours", "1", "--lr-cooldown-share", "1.5") == 2
    assert run_train(world, mods, out, "--train-hours", "1", "--lr-warmup-updates", "-1") == 2


def test_the_best_run_command_and_a_run_through_it(world, mods, capsys):
    """pg_best.py gives pg_train.py the options of the best run; an option given by hand takes the place of its
    value; --print starts nothing and lists the whole pool; a short real run through it ends by the clock."""
    import pg_best
    import pg_train
    out = world["tmp"] / "best"
    tail = ["--config", str(world["cfg"]), f"output.checkpoint_dir={out}"]
    assert pg_best.main(["--hours", "22.5", "--print", "--"] + tail) == 0
    printed = capsys.readouterr().out
    pool = [int(x) for x in (out / "files_pool.txt").read_text().split()]
    assert len(pool) == 4985 and pool[0] == 1 and pool[-1] == 5000
    assert not set(pool) & (set(range(4001, 4011)) | set(range(4950, 4955)))
    for piece in ("--train-hours 22.5", "--no-month", "--clean-account-share 0.25", "--loss-mask declines",
                  "--grad-clip 1.0",
                  "--ema-decay 0.9995", "--lr-warmup-updates 2000", "--lr-cooldown-share 0.2",
                  "--val-every-updates 10000", "--limit-val-batches 200", "4,985 files"):
        assert piece in printed, piece
    assert not (out / "program_settings.json").exists()                          # --print started nothing
    full, _ = pg_best.command(["--hours", "3", "--clean-account-share", "0.5", "--local-dir", "/x"], tail)
    assert full[full.index("--clean-account-share") + 1] == "0.5" and full.count("--clean-account-share") == 1
    assert full[full.index("--local-dir") + 1] == "/x" and full[full.index("--") + 1:] == tail
    full, _ = pg_best.command(["--hours", "3", "--ema-decay=0.999", "--loss-mask", "declines", "advice",
                               "--profile-steps", "5"], tail)
    assert "--ema-decay=0.999" in full and "--ema-decay" not in full               # the form name=value counts too
    assert full[full.index("--loss-mask") + 1:full.index("--loss-mask") + 3] == ["declines", "advice"]
    assert full.count("--loss-mask") == 1 and full[full.index("--profile-steps") + 1] == "5"
    full, _ = pg_best.command(["--hours", "3", "--keep-month"], tail)
    assert "--no-month" not in full and "--keep-month" in full                     # the month stays as the config has it
    with pytest.raises(SystemExit):
        pg_best.command(["--hours", "3"], ["--config", str(world["cfg"])])        # no run folder

    listed = world["tmp"] / "two_files.txt"
    listed.write_text("1\n2\n")
    try:
        rc = pg_best.main(["--hours", "0.0008", "--files-list", str(listed), "--lr-warmup-updates", "2",
                           "--val-every-updates", "4", "--limit-val-batches", "2", "--"] + tail)
    finally:
        pg_train.uninstall(mods)
    assert rc == 0
    settings = json.loads((out / "program_settings.json").read_text())["settings"]
    assert settings["clean_account_share"] == 0.25 and settings["loss_mask"] == ["declines"]
    assert settings["month_map"] == {str(m): 1 for m in range(1, 13)}             # the month is off in the best run
    assert settings["lr_plan"] == {"hours": 0.0008, "warmup": 2, "cooldown_share": 0.2}
    final = torch.load(out / "final.ckpt", map_location="cpu", weights_only=False)
    assert final["optimizer_states"][0]["param_groups"][0]["lr"] == 0.0 and final["global_step"] > 0


def test_month_map_reads_june_rows_as_may_and_changes_nothing_else(world, mods, capsys):
    """--month-map 6=5 at scoring: the month input of June rows is May's, every other calendar input and every row
    without a June row at or before it scores exactly as before; the option is taken out of the scorer's arguments
    and the date step is put back afterwards."""
    import pg_score
    from fraud.data import datetime_features as dtf

    assert pg_patch.parse_month_map(["6=5", "7=5"]) == {6: 5, 7: 5}
    for bad in (["6"], ["6=13"], ["0=5"], ["june=may"]):
        with pytest.raises(ValueError):
            pg_patch.parse_month_map(bad)
    args, months = pg_score.take_month_map(["--config", "c.yaml", "--month-map", "6=5", "7=5", "eval.file_start=8"])
    assert args == ["--config", "c.yaml", "eval.file_start=8"] and months == {6: 5, 7: 5}
    assert pg_score.take_month_map(["--config", "c.yaml"]) == (["--config", "c.yaml"], {})
    with pytest.raises(SystemExit):
        pg_score.take_month_map(["--month-map", "--config", "c.yaml"])

    # the date step itself
    times = pd.Series(pd.to_datetime(["2025-05-31 23:59:59", "2025-06-01 00:00:00", "2025-06-30 12:00:00", None]))
    original = dtf._extract_field
    assert pg_patch.install_month_map({6: 5}) is True
    try:
        assert dtf._extract_field(times, "month").tolist()[:3] == [5, 5, 5]
        assert np.isnan(dtf._extract_field(times, "month").iloc[3])
        assert dtf._extract_field(times, "day").tolist()[:3] == [31, 1, 30]
        assert dtf._extract_field(times, "hour").tolist()[:3] == [23, 0, 12]
    finally:
        pg_patch.remove_month_map()
    assert dtf._extract_field is original and dtf._extract_field(times, "month").tolist()[:3] == [5, 6, 6]
    capsys.readouterr()

    # a real scoring of a file with May and June rows, with and without the map
    out = world["tmp"] / "for_month"
    assert run_train(world, mods, out, extra=["training.max_epochs=1"]) == 0
    raw = world["frames"][8]
    assert (raw[TIME].dt.month == 6).any() and (raw[TIME].dt.month == 5).any()
    plain, mapped = world["tmp"] / "plain.parquet", world["tmp"] / "mapped.parquet"
    base = score_args(world, start=8, end=8, population="OTHER") + ["--checkpoint", str(out / "best.ckpt")]
    assert pg_score.main(base + ["--out", str(plain)]) == 0
    capsys.readouterr()
    assert pg_score.main(base + ["--month-map", "6=5", "--out", str(mapped)]) == 0
    printed = capsys.readouterr().out
    assert "rows of month 6 are read as month 5" in printed and "rows read with another month (6 as 5)" in printed
    assert dtf._extract_field is original                                         # put back after scoring
    a, b = pd.read_parquet(plain), pd.read_parquet(mapped)
    score = "score"
    both = a[[ID, score]].merge(b[[ID, score]], on=ID, suffixes=("_plain", "_mapped")).merge(raw[[ID, ACCOUNT, TIME]], on=ID)
    assert len(both) == len(a) == len(b)
    first_june = raw[raw[TIME].dt.month == 6].groupby(ACCOUNT)[TIME].min()
    before = both[both[TIME] < both[ACCOUNT].map(first_june).fillna(pd.Timestamp.max)]
    after = both[both[TIME] >= both[ACCOUNT].map(first_june).fillna(pd.Timestamp.max)]
    assert len(before) > 0 and len(after) > 0
    assert (before[f"{score}_plain"] == before[f"{score}_mapped"]).all()          # no June row in sight: unchanged
    assert (after[f"{score}_plain"] != after[f"{score}_mapped"]).any()            # June rows are read differently


def test_no_month_switches_the_month_off_in_training_scoring_and_export(world, mods, capsys):
    """--no-month: every row of training is read with the same month; the setting is saved in the checkpoint; the
    program's scorer and export read it there and do the same with no option; the project's own scorer, which does
    not, gives other scores; the date step is put back after each tool."""
    import pg_card
    import pg_export
    import pg_score
    from fraud.data import datetime_features as dtf
    from fraud.data.datetime_features import DatetimeConfig, derive_datetime_features

    off = pg_patch.no_month_map()
    assert off == {m: 1 for m in range(1, 13)} and pg_patch.month_is_off(off)
    assert not pg_patch.month_is_off({6: 5}) and not pg_patch.month_is_off({})
    assert pg_patch.month_is_off({str(m): 7 for m in range(1, 13)})               # as read back from a JSON file
    original = dtf._extract_field
    frame = pd.DataFrame({TIME: pd.to_datetime(["2024-10-03 01:00:00", "2025-01-31 12:00:00", "2025-05-20 23:00:00",
                                                "2025-06-30 08:00:00"])})
    cfg = DatetimeConfig(order_col=TIME, fields=["month", "day", "hour", "day_of_week"], encoding="categorical")
    assert pg_patch.install_month_map(off)
    try:
        derived, _, _ = derive_datetime_features(frame, cfg)
        assert derived["month"].tolist() == [1, 1, 1, 1]                           # the same for every row
        assert derived["day"].tolist() == [3, 31, 20, 30] and derived["hour"].tolist() == [1, 12, 23, 8]
    finally:
        pg_patch.remove_month_map()
    capsys.readouterr()

    out = world["tmp"] / "no_month"
    assert run_train(world, mods, out, "--no-month", extra=["training.max_epochs=1"]) == 0
    printed = capsys.readouterr().out
    assert "month: switched off for this run" in printed
    assert "every month as 1: the month is switched off" in printed               # the data path said what it did
    assert "month: switched off and checked:" in printed                          # training rows did pass there
    assert dtf._extract_field is original                                         # put back when the run is over
    ckpt = torch.load(out / "best.ckpt", map_location="cpu", weights_only=False)
    assert ckpt["program_settings"]["month_map"] == off
    assert pg_score.checkpoint_month_map(str(out / "best.ckpt")) == off
    assert pg_score.checkpoint_month_map(str(out / "missing.ckpt")) == {}
    assert pg_score.months_for(None, {6: 5}) == {6: 5}
    assert pg_score.checkpoint_argument(["--config", "c", "--checkpoint", "a/b.ckpt", "x=1"]) == "a/b.ckpt"
    assert pg_score.checkpoint_argument(["--checkpoint=a/b.ckpt", "--config", "c"]) == "a/b.ckpt"
    assert pg_score.checkpoint_argument(["--config", "c", "--check", "a/b.ckpt"]) == "a/b.ckpt"   # a shortened name
    assert pg_score.checkpoint_argument(["--checkp=a/b.ckpt", "x=1"]) == "a/b.ckpt"
    assert pg_score.checkpoint_argument(["--config", "c", "--checkpoint"]) is None
    assert pg_score.checkpoint_argument(["--config", "c"]) is None
    assert pg_score.scorer_argument(["--checkpoint", "a", "--out", "o.parquet", "x=1"], "--out") == "o.parquet"

    base = score_args(world, start=8, end=8, population="OTHER") + ["--checkpoint", str(out / "best.ckpt")]
    auto, asked, plain = (world["tmp"] / f"nm_{n}.parquet" for n in ("auto", "asked", "plain"))
    assert pg_score.main(base + ["--out", str(auto)]) == 0                         # no option: read from the checkpoint
    printed = capsys.readouterr().out
    assert "trained with the month switched off" in printed
    joined = score_args(world, start=8, end=8, population="OTHER") + [f"--checkp={out / 'best.ckpt'}"]
    assert pg_score.main(joined + ["--month-map", "6=5", "--out", str(asked)]) == 0  # an asked map is left out
    assert "--month-map is left out" in capsys.readouterr().out
    assert dtf._extract_field is original
    mods["scorer"].main(base + ["--out", str(plain)])                              # the project's own scorer: real months
    a, b, c = (pd.read_parquet(x).sort_values(ID).reset_index(drop=True) for x in (auto, asked, plain))
    assert (a["score"] == b["score"]).all()
    assert (a["score"] != c["score"]).any()                                        # a model that never saw real months

    exported = world["tmp"] / "nm_export.parquet"
    assert pg_export.main(["--checkpoint", str(out / "best.ckpt"), "--out", str(exported), "--", "--config",
                           str(world["cfg"]), f"eval.base={world['data']}", "eval.file_start=8",
                           "eval.file_end=8"]) == 0
    assert "trained with the month switched off" in capsys.readouterr().out
    e = pd.read_parquet(exported).sort_values(ID).reset_index(drop=True)
    assert len(e) == len(a) and np.allclose(e["score"].to_numpy(), a["score"].to_numpy(), atol=1e-6)
    assert dtf._extract_field is original

    assert pg_card.card(str(out), "best.ckpt") == 0
    assert "month = switched off" in capsys.readouterr().out


def test_warm_start_takes_the_tensors_that_fit(world, mods, capsys, tmp_path):
    """--init-from-matching: a model of another shape starts from the weights of a trained one wherever name and
    shape are the same; the rest keeps its initial values; a line says both. With a learning rate of 0 nothing moves,
    so the checkpoint of the new run shows exactly what was taken."""
    import pg_train
    first = world["tmp"] / "first"
    assert run_train(world, mods, first, extra=["training.max_epochs=1"]) == 0
    capsys.readouterr()
    second = world["tmp"] / "second"
    rc = run_train(world, mods, second, "--init-from-matching", str(first / "last.ckpt"),
                   extra=["training.max_epochs=1", "model.num_seq_blocks=2", "training.learning_rate=0.0"])
    assert rc == 0
    printed = capsys.readouterr().out
    line = [x for x in printed.splitlines() if x.startswith("warm start from")][0]
    old = torch.load(first / "last.ckpt", map_location="cpu", weights_only=False)["state_dict"]
    new = torch.load(second / "last.ckpt", map_location="cpu", weights_only=False)["state_dict"]
    added = [k for k in new if k not in old]
    assert added and all(k.startswith("seq_encoder.layers.1.") for k in added)    # the second sequence block is new
    assert f"{len(old)} of {len(new)} tensors taken" in line and "read the same fields" in line
    per_part = [x for x in printed.splitlines() if x.startswith("warm start, weights taken per part:")][0]
    assert "seq_encoder" in per_part and "NOTHING" not in printed
    taken_all = sum(int(v.numel()) for v in old.values())
    assert f"{taken_all:,} of {sum(int(v.numel()) for v in new.values()):,} weights" in line
    for name, tensor in old.items():
        assert torch.equal(new[name], tensor), name                               # taken as they were, and not moved
    assert run_train(world, mods, world["tmp"] / "both", "--init-from", str(first / "last.ckpt"),
                     "--init-from-matching", str(first / "last.ckpt")) == 2

    # a checkpoint with nothing in common: said plainly, and the model is left as it was built
    other = torch.nn.Linear(3, 2)
    before = {k: v.clone() for k, v in other.state_dict().items()}
    torch.save({"state_dict": {"weight": torch.zeros(5, 5), "elsewhere.bias": torch.zeros(2)}}, tmp_path / "x.ckpt")
    text = pg_train.warm_start_matching(other, str(tmp_path / "x.ckpt"))
    assert "0 of 2 tensors taken" in text and "NOTHING MATCHED" in text
    assert all(torch.equal(v, before[k]) for k, v in other.state_dict().items())
    torch.save({"state_dict": {"weight": torch.ones(2, 3), "bias": torch.zeros(7)}}, tmp_path / "y.ckpt")
    text = pg_train.warm_start_matching(other, str(tmp_path / "y.ckpt"))
    assert "1 of 2 tensors taken, 6 of 8 weights" in text and "weight 6 of 6; bias 0 of 2" in text
    assert "could not be compared" in text
    assert torch.equal(other.weight.data, torch.ones(2, 3)) and torch.equal(other.bias.data, before["bias"])

    # the loss's own weights are never taken, and a model that reads other fields is refused
    class WithLoss(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.body = torch.nn.Linear(2, 2)
            self.loss_fn = torch.nn.CrossEntropyLoss(weight=torch.tensor([1.0, 3.0]))

    net = WithLoss()
    net.hparams = {"input_contract": {"continuous_columns": ["a", "b"], "categorical_columns": ["c"],
                                      "categorical_cardinality": [4], "artifacts_sha256": "x"}}
    same = dict(net.hparams["input_contract"])
    torch.save({"state_dict": {"body.weight": torch.zeros(2, 2), "body.bias": torch.zeros(2),
                               "loss_fn.weight": torch.tensor([1.0, 9.0])},
                "hyper_parameters": {"input_contract": same}}, tmp_path / "z.ckpt")
    text = pg_train.warm_start_matching(net, str(tmp_path / "z.ckpt"))
    assert "2 of 3 tensors taken" in text and "read the same fields" in text
    assert net.loss_fn.weight.tolist() == [1.0, 3.0] and float(net.body.weight.abs().sum()) == 0.0
    torch.save({"state_dict": {"body.weight": torch.ones(2, 2)},
                "hyper_parameters": {"input_contract": dict(same, categorical_columns=["d"])}}, tmp_path / "w.ckpt")
    with pytest.raises(SystemExit) as stop:
        pg_train.warm_start_matching(net, str(tmp_path / "w.ckpt"))
    assert "does not read the same inputs" in str(stop.value) and "categorical_columns" in str(stop.value)
    assert float(net.body.weight.abs().sum()) == 0.0                              # nothing was taken


def test_a_month_switch_that_reaches_no_training_row_stops_the_run(world, mods, capsys, monkeypatch):
    """Training data that never passes through the date step (a prepared copy that already holds the month) would
    train with real months while scoring gives every row the same one. The run stops at its first batch and says
    so; a config that derives no month has nothing to switch off and runs."""
    import pg_callbacks
    from omegaconf import OmegaConf

    # the count starts again when the validation check before training is over, so its rows do not count
    seen = {"value": 7, "resets": 0}

    def rows_seen(reset=False):
        value = seen["value"]
        if reset:
            seen["value"], seen["resets"] = 0, seen["resets"] + 1
        return value

    check = pg_callbacks.MonthOffCheck(rows_seen)
    check.setup(None, None, "fit")
    seen["value"] = 9                                                             # rows of the validation check
    check.on_sanity_check_end(None, None)
    assert seen == {"value": 0, "resets": 2}
    with pytest.raises(SystemExit) as stop:
        check.on_train_batch_end(None, None, None, None, 0)
    assert "no training row had its month derived" in str(stop.value)
    check = pg_callbacks.MonthOffCheck(rows_seen)
    check.on_sanity_check_end(None, None)
    seen["value"] = 500
    check.on_train_batch_end(None, None, None, None, 0)
    check.on_train_batch_end(None, None, None, None, 1)                           # checked once
    assert "500 training rows had their month replaced" in capsys.readouterr().out

    # the real count: rows of this process and of what it derives
    assert pg_patch.month_rows_seen() == 0                                        # no map installed
    from fraud.data import datetime_features as dtf
    assert pg_patch.install_month_map(pg_patch.no_month_map())
    try:
        times = pd.Series(pd.to_datetime(["2025-05-31", "2025-06-01", "2025-06-02"]))
        dtf._extract_field(times, "month")
        dtf._extract_field(times, "day")                                          # other fields do not count
        assert pg_patch.month_rows_seen() == 3 and pg_patch.month_rows_seen(reset=True) == 3
        assert pg_patch.month_rows_seen() == 0
    finally:
        pg_patch.remove_month_map()

    # a real run in which the switch reaches nothing: it stops at the first batch, before any checkpoint
    monkeypatch.setattr(pg_patch, "month_rows_seen", lambda reset=False: 0)
    out = world["tmp"] / "no_effect"
    with pytest.raises(SystemExit) as stop:
        run_train(world, mods, out, "--no-month", extra=["training.max_epochs=1"])
    assert "Stopped, because training would use real months" in str(stop.value)
    assert not (out / "last.ckpt").exists()
    monkeypatch.undo()

    # a config that derives no month: nothing is installed and nothing is checked
    import pg_train
    c = OmegaConf.load(world["cfg"])
    cfg = OmegaConf.merge(c, OmegaConf.create({"datetime": {"fields": ["day", "hour"]}}))
    s = pg_patch.settings_from()
    s["month_map"] = pg_patch.no_month_map()
    fields = list((cfg.get("datetime") or {}).get("fields") or [])
    assert fields and "month" not in fields                                       # what pg_train.install reads


def test_a_model_trained_without_month_is_continued_and_scored_without_it(world, mods, capsys, monkeypatch):
    """The month setting follows the model: a run that starts from, or resumes, a model trained with the month
    switched off switches it off too when the option is not given again; --keep-month says otherwise; and a
    scoring in which the setting reached no row does not leave its output behind as if it were right."""
    import pg_callbacks
    import pg_export
    import pg_score
    off = pg_patch.no_month_map()
    first = world["tmp"] / "nm_first"
    assert run_train(world, mods, first, "--no-month", extra=["training.max_epochs=1"]) == 0
    capsys.readouterr()

    # a new run from its weights, the option not given again
    second = world["tmp"] / "nm_second"
    assert run_train(world, mods, second, "--init-from", str(first / "last.ckpt"),
                     extra=["training.max_epochs=1"]) == 0
    printed = capsys.readouterr().out
    assert "was trained with the month switched off, so this run switches it off too" in printed
    assert pg_patch.checkpoint_month_map(str(second / "last.ckpt")) == off
    settings = json.loads((second / "program_settings.json").read_text())
    assert settings["options"]["no_month"] is True

    # --keep-month: real months, said in a note; the two options together make no run
    third = world["tmp"] / "nm_third"
    assert run_train(world, mods, third, "--init-from-matching", str(first / "last.ckpt"), "--keep-month",
                     extra=["training.max_epochs=1"]) == 0
    assert "--keep-month trains this run on real months all the same" in capsys.readouterr().out
    assert pg_patch.checkpoint_month_map(str(third / "last.ckpt")) == {}
    assert run_train(world, mods, world["tmp"] / "nm_both", "--no-month", "--keep-month") == 2

    # a cut run resumed with other options given and --no-month forgotten
    cut = world["tmp"] / "nm_cut"
    original = pg_callbacks.PlateauEveryValidation.on_validation_end

    def crash(self, trainer, pl_module):
        original(self, trainer, pl_module)
        if trainer.global_step >= 4:
            raise RuntimeError("the workbench stopped")

    monkeypatch.setattr(pg_callbacks.PlateauEveryValidation, "on_validation_end", crash)
    with pytest.raises(RuntimeError, match="workbench stopped"):
        run_train(world, mods, cut, "--no-month", "--val-every-updates", "2",
                  extra=["training.max_epochs=3", "training.early_stopping_patience=100"])
    monkeypatch.setattr(pg_callbacks.PlateauEveryValidation, "on_validation_end", original)
    capsys.readouterr()
    assert run_train(world, mods, cut, "--val-every-updates", "2", "--grad-clip", "1.0",
                     extra=["--resume", "training.max_epochs=3", "training.early_stopping_patience=100"]) == 0
    assert "so this run switches it off too" in capsys.readouterr().out
    assert pg_patch.checkpoint_month_map(str(cut / "last.ckpt")) == off

    # a scoring in which the setting reaches no row: exit code 3, and the output is renamed
    base = score_args(world, start=8, end=8, population="OTHER") + ["--checkpoint", str(first / "best.ckpt")]
    good, bad = world["tmp"] / "nm_good.parquet", world["tmp"] / "nm_bad.parquet"
    assert pg_score.main(base + ["--out", str(good)]) == 0 and good.is_file()
    export_args = ["--checkpoint", str(first / "best.ckpt"), "--out", None, "--", "--config", str(world["cfg"]),
                   f"eval.base={world['data']}", "eval.file_start=8", "eval.file_end=8"]
    monkeypatch.setattr(pg_patch, "month_rows_seen", lambda reset=False: 0)
    capsys.readouterr()
    assert pg_score.main(base + ["--out", str(bad)]) == 3
    assert "reached no row of this scoring" in capsys.readouterr().err
    assert not bad.exists() and (world["tmp"] / "nm_bad.parquet.real_months").is_file()
    bad_export = world["tmp"] / "nm_bad_export.parquet"
    export_args[3] = str(bad_export)
    assert pg_export.main(export_args) == 3
    assert not bad_export.exists() and (world["tmp"] / "nm_bad_export.parquet.real_months").is_file()
    monkeypatch.undo()
    # a model with its month and no map asked: nothing to check
    assert pg_score.month_reached_the_rows({}, str(good)) is True and good.is_file()
