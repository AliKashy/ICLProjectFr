"""Training variants on the old layout, CPU only: the builder, the loss, the banded mask and full training runs.

Run: $PY -m pytest -q tests/experiments/program/test_program_training.py
"""
import json

import numpy as np
import pandas as pd
import pytest
import torch

from conftest import ACCOUNT, ID, LABEL, TIME, score_args

pg_layout = pytest.importorskip("pg_layout")
import pg_patch  # noqa: E402


@pytest.fixture
def mods():
    layout, m = pg_layout.resolve(roles=("base_model", "target_ending_model", "trainer", "scorer", "chunk_builder",
                                        "target_ending_data"))
    if layout != "old":
        pytest.skip("these tests run on the old code layout")
    return m


def builder(w, mods, s, files=(1,), shuffle=False, batch_size=8):
    from fraud.data.preprocessing import PreprocessingArtifacts
    arts = PreprocessingArtifacts.load(str(w["tmp"] / "artifacts/1"))
    cls = pg_patch.builder_class(mods["chunk_builder"].SequenceBuilder, s) if s is not None else \
        mods["chunk_builder"].SequenceBuilder
    return cls(file_list=[str(w["data"] / f"part_{i}.parquet") for i in files], artifacts=arts,
               features=w["features"], datetime_config=w["dt"], target_col=LABEL, account_col=ACCOUNT,
               order_col=TIME, history_len=3, stride=1, batch_size=batch_size, shuffle=shuffle,
               tie_break_col=ID, history_time_order="strict", emit_target_seq=True,
               all_position_layout="nonoverlapping_chunks", time_delta_reference="previous_transaction",
               max_chunk_rows=64)


def batches(ds):
    return list(iter(ds))


def test_rebuilt_chunks_equal_the_project_builder(world, mods):
    """With the data side on but changing nothing (share 1), the program builder's chunks are the project's."""
    s = pg_patch.settings_from(clean_account_share=1.0)
    ours, theirs = batches(builder(world, mods, s)), batches(builder(world, mods, None))
    assert len(ours) == len(theirs)
    for a, b in zip(ours, theirs):
        for k in ("continuous", "categorical", "mask", "target_seq", "time_seq"):
            assert torch.equal(a[k], b[k]), k
        assert torch.equal(a["loss_weight"], b["mask"].float())


def test_loss_mask_sampling_and_inverse_weights(world, mods):
    df = world["frames"][1]
    s = pg_patch.settings_from(loss_mask=["declines", "advice"], clean_account_share=0.5,
                               negative_weight="inverse")
    target = df[LABEL].to_numpy()
    w, kept = pg_patch.row_weights(df, target, s, ACCOUNT, TIME, ID)
    declined = df["predecline"].to_numpy() == 1
    advice = df["transaction_advice_xcd"].to_numpy() == "A"
    assert (w[declined | advice] == 0).all()
    fraud_accounts = set(df.loc[df[LABEL] == 1, ACCOUNT])
    assert fraud_accounts <= kept
    assert (w[target == 1] == 1).all()  # frauds always count, with weight 1
    counted_negatives = w[(target == 0) & (w > 0)]
    assert np.allclose(counted_negatives, 2.0)  # 1 / share
    # the batches carry the weights and leave out the clean accounts that were not drawn
    got = batches(builder(world, mods, s))
    assert all("loss_weight" in b for b in got)
    assert sum(int(b["mask"].sum()) for b in got) == int(df[ACCOUNT].isin(kept).sum())


def test_recency_weights_halve_per_half_life():
    df = pd.DataFrame({ACCOUNT: ["a"] * 3, TIME: pd.to_datetime(["2025-05-03", "2025-04-03", "2025-03-03"]),
                       LABEL: [0, 0, 0]})
    s = pg_patch.settings_from(recency_half_life_months=1.0)
    w, _ = pg_patch.row_weights(df, df[LABEL].to_numpy(), s, ACCOUNT, TIME)
    assert np.allclose(w, [1.0, 0.5, 0.25])


def test_prefix_rows_are_context_and_the_band_is_the_scoring_window(world, mods):
    s = pg_patch.settings_from(prefix_seconds=3, prefix_max_rows=31)
    got = batches(builder(world, mods, s, batch_size=4))
    plain = batches(builder(world, mods, None, batch_size=4))
    assert sum(int((b["loss_weight"] > 0).sum()) for b in got) == sum(int(b["mask"].sum()) for b in plain)
    assert any(int(b["mask"].sum()) > int((b["loss_weight"] > 0).sum()) for b in got)  # some context rows
    assert all("context_prefix" in b for b in got)
    # band visibility equals the target-ending window rule (3 earlier seconds here, the history length)
    window_bounds = mods["target_ending_data"].window_bounds
    for b in got:
        vis = pg_patch.band_visible(b["time_seq"], b["mask"], 3, 31)
        for r in range(b["mask"].shape[0]):
            n = int(b["mask"][r].sum())
            t = b["time_seq"][r, :n].numpy()
            lo, gs = window_bounds(t // 10 ** 9, t, 3, 32)
            for i in range(n):
                expected = np.zeros(n, bool)
                expected[lo[i]:gs[i]] = True
                assert np.array_equal(vis[r, i, :n].numpy(), expected)


def model(mods, seed=0):
    torch.manual_seed(seed)
    return mods["base_model"].FTTransformerHierModel(
        continuous_dim=3, categorical_cardinality=[4, 4], history_len=3, embed_dim=8, num_heads=2, num_txn_blocks=1,
        num_seq_blocks=1, attn_dropout=0.0, ff_dropout=0.0, attention_mask="causal", learning_rate=1e-3,
        weight_decay=0.0, pos_weight=1.0, predict_every_transaction=True, history_time_order="strict",
        all_position_layout="nonoverlapping_chunks",
        time_delta_reference="previous_transaction")


def toy_batch(width=6, rows=(6, 4), seed=0):
    g = torch.Generator().manual_seed(seed)
    B = len(rows)
    mask = torch.zeros(B, width, dtype=torch.bool)
    for b, n in enumerate(rows):
        mask[b, :n] = True
    secs = torch.cumsum(torch.randint(0, 3, (B, width), generator=g), 1) + 1_700_000_000
    return {"continuous": torch.randn(B, width, 3, generator=g),
            "categorical": torch.randint(0, 4, (B, width, 2), generator=g), "mask": mask,
            "target_seq": torch.where(mask, torch.randint(0, 2, (B, width), generator=g), torch.full_like(secs, -100)),
            "time_seq": torch.where(mask, secs * 10 ** 9, torch.zeros_like(secs))}


def test_weighted_and_focal_losses(mods):
    try:
        m = model(mods)
    except TypeError:
        pytest.skip("the base model's constructor differs here")
    batch = toy_batch()
    _, _, plain = m._step(batch, "train")
    s = pg_patch.settings_from()
    pg_patch.apply_model(s, type(m))
    try:
        ones = dict(batch, loss_weight=batch["mask"].float())
        _, _, weighted = m._step(ones, "train")
        assert torch.allclose(plain, weighted, atol=1e-6)
        half = batch["mask"].float()
        half[0, :3] = 0.0
        _, _, part = m._step(dict(batch, loss_weight=half), "train")
        logits = m(batch)
        ce = torch.nn.functional.cross_entropy(logits[batch["mask"]], batch["target_seq"][batch["mask"]],
                                               reduction="none")
        keep = half[batch["mask"]] > 0
        assert torch.allclose(part, ce[keep].mean(), atol=1e-6)
    finally:
        pg_patch.remove_model(type(m))
    pg_patch.apply_model(pg_patch.settings_from(loss="focal", focal_gamma=0.0), type(m))
    try:
        _, _, focal0 = m._step(batch, "train")
        assert torch.allclose(plain, focal0, atol=1e-6)  # gamma 0 is the plain loss
    finally:
        pg_patch.remove_model(type(m))


def run_train(w, mods, out, *options, extra=()):
    import pg_train
    try:
        return pg_train.main([*options, "--", "--config", str(w["cfg"]), *extra, f"output.checkpoint_dir={out}"])
    finally:
        pg_train.uninstall(mods)


def test_variants_train_and_score_with_the_normal_scorer(world, mods):
    out = world["tmp"] / "variant"
    rc = run_train(world, mods, out, "--loss-mask", "declines", "advice", "--clean-account-share", "0.6",
                   "--prefix-seconds", "2", "--ema-decay", "0.9", "--val-every-updates", "2", "--keep-near-update",
                   "3", "--grad-clip", "1.0", "--loss", "focal", "--plateau-monitor", "valid_ap",
                   "--profile-steps", "0", extra=["training.max_epochs=2"])
    assert rc == 0
    for name in ("best.ckpt", "last.ckpt", "best_ema.ckpt", "near_update.ckpt", "profile.json",
                 "program_settings.json", "ema_metrics.csv"):
        assert (out / name).is_file(), name
    ckpt = torch.load(out / "best.ckpt", map_location="cpu", weights_only=False)
    assert ckpt["program_settings"]["prefix_seconds"] == 2
    for name in ("best.ckpt", "best_ema.ckpt", "near_update.ckpt"):
        pred = world["tmp"] / f"{name}.parquet"
        mods["scorer"].main(score_args(world) + ["--checkpoint", str(out / name), "--out", str(pred)])
        assert len(pd.read_parquet(pred)) > 0


def test_files_list_local_dir_resume_after_scoring_and_warm_start(world, mods):
    lst = world["tmp"] / "files.txt"
    lst.write_text("2\n")
    out = world["tmp"] / "listed"
    assert run_train(world, mods, out, "--files-list", str(lst), "--local-dir", str(world["data"])) == 0
    settings = json.loads((out / "program_settings.json").read_text())
    assert settings["settings"]["files"] == [2]
    pred = world["tmp"] / "listed.parquet"
    mods["scorer"].main(score_args(world) + ["--checkpoint", str(out / "best.ckpt"), "--out", str(pred)])
    # the run was scored; a resume to a larger epoch budget still continues it
    assert run_train(world, mods, out, extra=["--resume", "training.max_epochs=2"]) == 0
    manifest = json.loads((out / "run_manifest_v2.json").read_text())
    assert manifest["epochs_run"] == 2 and manifest.get("scored_before_resume")
    warm = world["tmp"] / "warm"
    assert run_train(world, mods, warm, "--init-from", str(out / "best.ckpt")) == 0


def test_no_options_is_the_trainer_unchanged(world, mods):
    a, b = world["tmp"] / "plain_a", world["tmp"] / "plain_b"
    assert run_train(world, mods, a) == 0
    mods["trainer"].main(["--config", str(world["cfg"]), f"output.checkpoint_dir={b}"])
    sa = torch.load(a / "last.ckpt", map_location="cpu", weights_only=False)["state_dict"]
    sb = torch.load(b / "last.ckpt", map_location="cpu", weights_only=False)["state_dict"]
    assert sa.keys() == sb.keys()
    for k in sa:
        assert torch.allclose(sa[k], sb[k], atol=1e-6), k


def test_inverse_weight_only_for_rows_sampled_at_the_share():
    df = pd.DataFrame({ACCOUNT: ["f"] * 4 + ["c"] * 4, ID: [f"r{i}" for i in range(8)], TIME: pd.Timestamp("2025-05-01"),
                       LABEL: [1, 0, 0, 0, 0, 0, 0, 0]})
    keep = pg_patch.settings_from(clean_account_share=0.5, mask_fraud_account_negatives=False,
                                  negative_weight="inverse")
    w, kept = pg_patch.row_weights(df, df[LABEL].to_numpy(), keep, ACCOUNT, TIME, ID)
    assert np.allclose(w[:4], 1.0)  # the fraud account's rows are always counted: weight 1
    if "c" in kept:
        assert np.allclose(w[4:], 2.0)  # the clean account was drawn at 0.5: weight 2


def test_plateau_steps_once_per_validation():
    import pg_callbacks
    from types import SimpleNamespace
    p = torch.nn.Parameter(torch.zeros(1))
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(torch.optim.SGD([p], lr=1.0), patience=0, factor=0.5, mode="max")
    tr = SimpleNamespace(sanity_checking=False, callback_metrics={"valid_ap": torch.tensor(0.5)},
                         lr_scheduler_configs=[SimpleNamespace(scheduler=sched, monitor="valid_ap")])
    cb = pg_callbacks.PlateauEveryValidation()
    for _ in range(3):
        cb.on_validation_end(tr, None)
    assert sched.last_epoch == 3 and sched.optimizer.param_groups[0]["lr"] == 0.25  # no gain after the first


def test_resume_from_the_latest_whole_epoch_and_with_the_runs_own_options(world, mods, monkeypatch):
    import pg_callbacks
    import pg_train
    lst = world["tmp"] / "files.txt"
    lst.write_text("1\n2\n")
    plain = world["tmp"] / "plain"
    assert run_train(world, mods, plain, "--files-list", str(lst), "--val-every-updates", "2",
                     extra=["training.early_stopping_patience=100"]) == 0
    per_epoch = json.loads((plain / "run_manifest_v2.json").read_text())["optimizer_steps"]
    out = world["tmp"] / "cut"
    original = pg_callbacks.PlateauEveryValidation.on_validation_end

    def crash(self, trainer, pl_module):
        original(self, trainer, pl_module)
        if trainer.global_step >= per_epoch + 4:
            raise RuntimeError("the workbench stopped")  # inside epoch 1, after last.ckpt was written at +2

    monkeypatch.setattr(pg_callbacks.PlateauEveryValidation, "on_validation_end", crash)
    with pytest.raises(RuntimeError, match="workbench stopped"):
        run_train(world, mods, out, "--files-list", str(lst), "--val-every-updates", "2",
                  extra=["training.max_epochs=2", "training.early_stopping_patience=100"])
    monkeypatch.setattr(pg_callbacks.PlateauEveryValidation, "on_validation_end", original)
    assert (out / "epoch_end.ckpt").is_file()
    reused = pg_train.resume_options(pg_train.parser().parse_args([]), str(out))
    assert reused.files_list == str(lst) and reused.val_every_updates == 2  # the run's own options
    assert run_train(world, mods, out, extra=["--resume", "training.max_epochs=2",
                                              "training.early_stopping_patience=100"]) == 0
    assert (out / "last_mid_epoch.ckpt").is_file()
    m = json.loads((out / "run_manifest_v2.json").read_text())
    assert m["optimizer_steps"] == 2 * per_epoch  # the cut epoch was trained once, from its start
    assert (out / "program_settings.resume1.json").is_file()


def test_options_that_cannot_apply_stop_with_a_message(world, mods):
    out = world["tmp"] / "bad"
    assert run_train(world, mods, out, "--limit-val-batches", "0") == 2
    assert run_train(world, mods, out, "--loss-mask", "declines", extra=["sequence.train_target_ending=true"]) == 2


def test_no_window_cap_means_no_row_limit_in_band_and_prefix(world, mods):
    from types import SimpleNamespace
    import pg_train
    cfg = SimpleNamespace(sequence={"history_len": 3, "max_window_rows": None})
    cfg.sequence = type("Seq", (dict,), {"__getattr__": dict.__getitem__})(cfg.sequence)
    s = pg_train.window_caps(cfg, pg_patch.settings_from(prefix_seconds=3), None)
    assert s["band_seconds"] == 3 and s["band_rows"] is None and s["prefix_max_rows"] is None
    cfg.sequence["max_window_rows"] = 137
    assert pg_train.window_caps(cfg, dict(s), None)["band_rows"] == 136
    assert pg_train.window_caps(cfg, dict(s), None)["prefix_max_rows"] == 136
    assert pg_train.window_caps(cfg, dict(s), 50)["prefix_max_rows"] == 50
    # with no row limit, the band equals the uncapped target-ending window, and a 1-row cap would differ
    got = batches(builder(world, mods, s, batch_size=4))
    window_bounds = mods["target_ending_data"].window_bounds
    differs = False
    for b in got:
        vis = pg_patch.band_visible(b["time_seq"], b["mask"], 3, None)
        tight = pg_patch.band_visible(b["time_seq"], b["mask"], 3, 1)
        differs |= bool((vis != tight).any())
        for r in range(b["mask"].shape[0]):
            n = int(b["mask"][r].sum())
            t = b["time_seq"][r, :n].numpy()
            lo, gs = window_bounds(t // 10 ** 9, t, 3, None)
            for i in range(n):
                expected = np.zeros(n, bool)
                expected[lo[i]:gs[i]] = True
                assert np.array_equal(vis[r, i, :n].numpy(), expected)
    assert differs


def wide_batch(rows, width=8, seed=0):
    """Windows of up to `width` rows, two rows per second (so at most width / 2 distinct seconds)."""
    b = toy_batch(width=width, rows=rows, seed=seed)
    secs = (1_700_000_000 + torch.arange(width) // 2) * 10 ** 9
    b["time_seq"] = torch.where(b["mask"], secs.expand(len(rows), width), torch.zeros(len(rows), width,
                                                                                       dtype=torch.long))
    return b


def test_wide_batches_run_in_parts_with_the_same_scores_and_gradients(mods, monkeypatch):
    try:
        m = model(mods)
    except TypeError:
        pytest.skip("the base model's constructor differs here")
    b = wide_batch((8, 4, 5, 3, 7, 2, 6, 1))
    real = b["mask"]
    m.eval()
    with torch.no_grad():
        ref = m(b)
    cls_ref = m._cls.clone()
    m.train()
    m.zero_grad()
    loss_ref = m._step(b, "train")[2]
    loss_ref.backward()
    grads_ref = {k: p.grad.clone() for k, p in m.named_parameters() if p.grad is not None}
    pg_patch.install_wide_batches(type(m))
    try:
        monkeypatch.setattr(pg_patch, "LAUNCH_ROWS", 1)  # every batch runs in parts
        monkeypatch.setattr(pg_patch, "PART_ROWS", 13)
        parts = pg_patch.batch_parts(real.sum(1), 8, m.T, 2, True)
        assert len(parts) > 1 and sorted(torch.cat([i for i, _ in parts]).tolist()) == list(range(8))
        assert all(w <= 8 for _, w in parts) and parts[-1][1] == m.T  # narrow windows run in narrow parts
        seen = []
        hook = m.head.register_forward_pre_hook(lambda module, inputs: seen.append(tuple(inputs[0].shape)))
        m.eval()
        with torch.no_grad():
            got = m(b)
        hook.remove()
        assert got.shape == ref.shape and torch.allclose(got[real], ref[real], atol=1e-5)
        assert torch.allclose(m._cls, cls_ref, atol=1e-5)
        assert seen[-1] == (8, 8, 8)  # the head's last call (the exporter's capture) holds the whole batch
        m.train()
        m.zero_grad()
        loss = m._step(b, "train")[2]
        loss.backward()
        assert torch.allclose(loss, loss_ref, atol=1e-6)
        params = dict(m.named_parameters())
        for k, g in grads_ref.items():
            assert torch.allclose(params[k].grad, g, atol=1e-5), k
    finally:
        pg_patch.remove_wide_batches(type(m))


def test_no_cap_trains_scores_and_exports_with_no_row_limits(world, mods, monkeypatch):
    import pg_export
    import pg_score
    monkeypatch.setattr(pg_patch, "LAUNCH_ROWS", 1)  # every batch runs in parts: the no-limit path end to end
    monkeypatch.setattr(pg_patch, "PART_ROWS", 20)
    nocap = ["sequence.max_window_rows=null", "sequence.max_chunk_rows=4"]  # a chunk limit the trainer would stop on
    with pytest.raises(ValueError):
        mods["trainer"].main(["--config", str(world["cfg"]), *nocap, f"output.checkpoint_dir={world['tmp'] / 'x'}"])
    out = world["tmp"] / "nocap"
    assert run_train(world, mods, out, "--prefix-seconds", "2", extra=nocap) == 0
    ckpt = out / "best.ckpt"
    assert torch.load(ckpt, map_location="cpu", weights_only=False)["validation_policy"]["max_window_rows"] is None
    parts = world["tmp"] / "nocap_parts.parquet"
    assert pg_score.main(score_args(world) + ["sequence.max_window_rows=null", "--checkpoint", str(ckpt),
                                              "--out", str(parts)]) == 0
    assert mods["base_model"].FTTransformerHierModel not in pg_patch._WIDE  # put back after scoring
    one = world["tmp"] / "nocap_one.parquet"
    mods["scorer"].main(score_args(world) + ["sequence.max_window_rows=null", "--checkpoint", str(ckpt),
                                             "--out", str(one)])
    a, b = pd.read_parquet(parts), pd.read_parquet(one)
    m = a.merge(b[[ID, "score"]], on=ID, suffixes=("", "_one"))
    assert len(m) == len(a) == len(b) > 0 and np.allclose(m["score"], m["score_one"], atol=1e-6)
    exp = world["tmp"] / "nocap_export.parquet"
    assert pg_export.main(["--checkpoint", str(ckpt), "--out", str(exp), "--", "--config", str(world["cfg"]),
                           f"eval.base={world['data']}", "eval.file_start=3", "eval.file_end=3",
                           "sequence.max_window_rows=null"]) == 0
    e = pd.read_parquet(exp).merge(b[[ID, "score"]], on=ID, suffixes=("", "_one"))
    assert len(e) == len(b) and np.allclose(e["score"], e["score_one"], atol=1e-6)
    assert np.allclose(e["score"], e["score_check"], atol=1e-5)
    assert e["window_rows"].max() > 4  # windows wider than the dropped chunk limit were scored


def test_the_config_cap_decides_at_scoring(world, mods):
    """A checkpoint validated with a cap is scored with no cap when the config says null, and the other way round."""
    import pg_score
    capped = world["tmp"] / "capped"
    assert run_train(world, mods, capped, extra=["sequence.max_window_rows=5"]) == 0
    ckpt = capped / "best.ckpt"
    assert torch.load(ckpt, map_location="cpu", weights_only=False)["validation_policy"]["max_window_rows"] == 5
    for cap, name in (("null", "free"), ("5", "five")):
        pred = world["tmp"] / f"{name}.parquet"
        assert pg_score.main(score_args(world) + [f"sequence.max_window_rows={cap}", "--checkpoint", str(ckpt),
                                                  "--out", str(pred)]) == 0
        receipt = json.loads((world["tmp"] / f"{name}.parquet.json").read_text())
        assert receipt["max_window_rows"] == (None if cap == "null" else 5)
    assert mods["scorer"].checkpoint_policy.__name__ == "checkpoint_policy" and \
        mods["scorer"].checkpoint_policy.__module__ == mods["scorer"].__name__  # put back after scoring


def test_learning_rate_plan_factor():
    """Warm-up in equal rises, the peak until the cooldown starts, then 1 - sqrt(progress) down to 0 at the last update."""
    f = pg_patch.plan_factor
    warm = [f(s, 1000, 100, 0.2) for s in range(100)]
    rises = np.diff(warm)
    assert np.allclose(rises, rises[0]) and rises[0] > 0 and 0 < warm[0] < 0.02
    assert f(100, 1000, 100, 0.2) == 1.0 and f(799, 1000, 100, 0.2) == 1.0     # the peak until update 800
    assert f(800, 1000, 100, 0.2) == 1.0 and f(850, 1000, 100, 0.2) == pytest.approx(0.5)
    assert f(900, 1000, 100, 0.2) == pytest.approx(1 - np.sqrt(0.5))
    fall = [f(s, 1000, 100, 0.2) for s in range(800, 1001)]
    assert all(b <= a for a, b in zip(fall, fall[1:])) and fall[-1] == 0.0      # it never rises again
    assert f(1000, 1000, 100, 0.2) == 0.0 and f(10 ** 9, 1000, 100, 0.2) == 0.0  # a longer run stays at 0
    # a share of 1 starts the fall right after the warm-up: the cooldown of a model that is already trained
    assert f(49, 400, 50, 1.0) == pytest.approx(50 / 51) and f(50, 400, 50, 1.0) == 1.0
    assert f(51, 400, 50, 1.0) < 1.0 and f(225, 400, 50, 1.0) == pytest.approx(1 - np.sqrt(0.5))
    assert f(0, 10, 0, 0.5) == 1.0 and f(5, 10, 0, 0.5) == 1.0 and f(10, 10, 0, 0.5) == 0.0


def test_learning_rate_plan_runs_and_ends_at_zero(world, mods, capsys):
    """A run with the plan: the rate changes at every update, the plateau rule is gone, and the last checkpoint holds
    the weights of the last update with the rate at 0."""
    out = world["tmp"] / "planned"
    rc = run_train(world, mods, out, "--max-steps", "8", "--lr-warmup-updates", "2", "--lr-cooldown-share", "0.5",
                   "--val-every-updates", "2", "--limit-val-batches", "2",
                   extra=["training.max_epochs=50", "training.early_stopping_patience=100000"])
    assert rc == 0
    printed = capsys.readouterr().out
    assert "learning rate at update 0:" in printed and "learning rate at update 8: 0.000e+00" in printed
    settings = json.loads((out / "program_settings.json").read_text())
    assert settings["settings"]["lr_plan"] == {"max_steps": 8, "warmup": 2, "cooldown_share": 0.5}
    last = torch.load(out / "last.ckpt", map_location="cpu", weights_only=False)
    assert last["global_step"] == 8
    assert last["optimizer_states"][0]["param_groups"][0]["lr"] == 0.0
    scheduler = last["lr_schedulers"][0]
    assert scheduler["last_epoch"] == 8 and "best" not in scheduler            # a planned schedule, not the plateau rule
    peak = scheduler["base_lrs"][0]
    assert peak > 0
    assert last["program_settings"]["lr_plan"]["max_steps"] == 8


def test_learning_rate_plan_needs_the_length_of_the_run(world, mods):
    """The plan cannot be laid out without --max-steps, and its two numbers have to make sense."""
    out = world["tmp"] / "bad_plan"
    assert run_train(world, mods, out, "--lr-warmup-updates", "5") == 2
    assert run_train(world, mods, out, "--lr-cooldown-share", "0.2") == 2
    assert run_train(world, mods, out, "--max-steps", "10", "--lr-cooldown-share", "1.5") == 2
    assert run_train(world, mods, out, "--max-steps", "10", "--lr-cooldown-share", "0") == 2
    assert run_train(world, mods, out, "--max-steps", "10", "--lr-warmup-updates", "10") == 2


def test_cooldown_of_a_trained_model_starts_from_its_weights(world, mods, capsys):
    """--init-from with a cooldown share of 1: the trained weights are loaded and the rate falls from the first update
    after the warm-up."""
    first = world["tmp"] / "trained"
    assert run_train(world, mods, first) == 0
    out = world["tmp"] / "cooled"
    rc = run_train(world, mods, out, "--init-from", str(first / "best.ckpt"), "--max-steps", "6",
                   "--lr-warmup-updates", "1", "--lr-cooldown-share", "1.0", "--val-every-updates", "3",
                   "--limit-val-batches", "2", extra=["training.max_epochs=50", "training.early_stopping_patience=100000"])
    assert rc == 0
    printed = capsys.readouterr().out
    assert "warm start from" in printed and "learning rate at update 6: 0.000e+00" in printed
    cooled = torch.load(out / "last.ckpt", map_location="cpu", weights_only=False)
    trained = torch.load(first / "best.ckpt", map_location="cpu", weights_only=False)
    assert cooled["global_step"] == 6 and set(cooled["state_dict"]) == set(trained["state_dict"])
    moved = sum(float((cooled["state_dict"][k].float() - trained["state_dict"][k].float()).abs().sum())
                for k in trained["state_dict"])
    assert moved > 0                                                            # training went on from those weights



def test_data_options_say_what_they_did_to_the_first_file(world, mods, capsys):
    """One printed line per worker: rows read, rows with a loss, frauds kept, and a mask whose column is missing."""
    s = pg_patch.settings_from(loss_mask=["declines"], clean_account_share=0.5)
    ds = builder(world, mods, s)
    list(batches(ds))
    line = [x for x in capsys.readouterr().out.splitlines() if x.startswith("program data options")]
    assert len(line) == 1                                                    # once, not once per file or batch
    assert "declines rows without a loss" in line[0] and "accounts kept" in line[0] and "at share 0.5" in line[0]
    frauds = line[0].split("frauds with a loss ")[1].split(";")[0]
    kept, total = frauds.split(" of ")
    assert kept == total and int(total) > 0                                   # every fraud still carries a loss
    df = pd.DataFrame({ACCOUNT: ["a", "a", "b"], "x": [1, 2, 3]})
    report = pg_patch.data_report(df, np.array([0, 1, 0]), np.array([1.0, 1.0, 0.0]), {"a"},
                                  pg_patch.settings_from(loss_mask=["declines"], clean_account_share=0.5), ACCOUNT)
    assert "NO column 'predecline' in the data, so the declines mask did nothing" in report
    assert "rows the model reads 2 (66.7%)" in report and "frauds with a loss 1 of 1" in report


def test_card_prints_what_a_run_is(world, mods, capsys):
    """pg_card.py reads only what the trainer left in the run folder and says the run's length, rate, size and files."""
    import pg_card
    out = world["tmp"] / "carded"
    assert run_train(world, mods, out, "--loss-mask", "declines", "--max-steps", "4", "--lr-warmup-updates", "1",
                     "--lr-cooldown-share", "0.5", "--val-every-updates", "2", "--limit-val-batches", "2",
                     extra=["training.max_epochs=50", "training.early_stopping_patience=100000"]) == 0
    capsys.readouterr()
    assert pg_card.main([str(out)]) == 0
    printed = capsys.readouterr().out
    lines = {line.split(" ", 1)[0]: line for line in printed.splitlines() if line and not line.startswith(" ")}
    assert "updates 4" in lines["length"] and "status finished" in lines["length"]
    assert "at the end 0.000e+00" in lines["rate"] and "so it reached 0" in lines["rate"] and "fixed plan" in printed
    assert "loss_mask = ['declines']" in lines["options"] and "lr_plan" in lines["options"]
    state = torch.load(out / "last.ckpt", map_location="cpu", weights_only=False)["state_dict"]
    total = sum(int(v.numel()) for v in state.values())
    assert f"total {total:,}" in lines["weights"]
    assert "codes" in lines["fields"] and "token_encoder" in lines["blocks"] and "seq_encoder" in lines["blocks"]
    assert "validations" in lines["valid"] and "training:" in lines["files"] and "batch_size" in printed
    assert max(len(line) for line in printed.splitlines()) <= pg_card.WIDTH
    assert pg_card.main([str(out), "--checkpoint", "missing.ckpt"]) == 2
    assert pg_card.main([str(out), "--features"]) == 0
    assert "listed:" in capsys.readouterr().out

