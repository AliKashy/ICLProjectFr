"""Export, derived columns, the embedding table, the downstream arms and the tuning search, on synthetic data.

Run: $PY -m pytest -q tests/experiments/program/test_program_embedding.py
"""
import json
import sys

import numpy as np
import pandas as pd
import pytest
import torch

from conftest import ACCOUNT, ID, LABEL, TIME

pg_layout = pytest.importorskip("pg_layout")
import pg_derive  # noqa: E402
import pg_store  # noqa: E402
import pg_sweep  # noqa: E402


@pytest.fixture
def trained(world):
    layout, mods = pg_layout.resolve(roles=("base_model", "trainer", "scorer"))
    if layout != "old":
        pytest.skip("runs on the old code layout")
    out = world["tmp"] / "run"
    mods["trainer"].main(["--config", str(world["cfg"]), f"output.checkpoint_dir={out}"])
    return world, mods, out / "best.ckpt"


def export_file(world, mods, ckpt, files, name):
    import pg_export
    out = world["tmp"] / f"{name}.parquet"
    rc = pg_export.main(["--checkpoint", str(ckpt), "--out", str(out), "--", "--config", str(world["cfg"]),
                         f"eval.base={world['data']}", f"eval.file_start={files[0]}", f"eval.file_end={files[1]}"])
    assert rc == 0
    return out


def test_export_matches_the_scorer_and_reproduces_the_score(trained):
    world, mods, ckpt = trained
    exp = pd.read_parquet(export_file(world, mods, ckpt, (3, 3), "exp3"))
    pred = world["tmp"] / "scored.parquet"
    mods["scorer"].main(["--population", "EPOCH_VAL", "--purpose", "test", "--config", str(world["cfg"]),
                         f"eval.base={world['data']}", "eval.file_start=3", "eval.file_end=3", "--checkpoint",
                         str(ckpt), "--out", str(pred)])
    sc = pd.read_parquet(pred)
    m = exp.merge(sc[[ID, "score"]], on=ID, suffixes=("", "_scorer"))
    assert len(m) == len(sc) == len(exp)
    assert np.allclose(m["score"], m["score_scorer"], atol=1e-6)
    assert np.allclose(exp["score"], exp["score_check"], atol=1e-5)
    vec = [c for c in exp.columns if c.startswith("e_")]
    assert len(vec) == 8 and exp[LABEL].isin([0, 1]).all() and TIME in exp
    assert pd.api.types.is_float_dtype(exp["transaction_amt"])  # the amount stays a number in the export


def brute_window(df, cols, days):
    out = np.full((len(df), len(cols)), np.nan)
    t = pd.to_datetime(df[TIME]).dt.floor("s")
    for i in range(len(df)):
        same = (df[ACCOUNT] == df[ACCOUNT].iloc[i]) & (t < t.iloc[i]) & (t >= t.iloc[i] - pd.Timedelta(days=days))
        if same.any():
            out[i] = df.loc[same, cols].to_numpy().mean(axis=0)
    return out


def test_windows_are_strictly_earlier_and_householder_hides_the_head(trained):
    world, mods, ckpt = trained
    exp_path = export_file(world, mods, ckpt, (8, 8), "exp8")
    pca = world["tmp"] / "pca.npz"
    assert pg_derive.main(["fit-pca", "--export", str(exp_path), "--out", str(pca)]) == 0
    der = world["tmp"] / "der.parquet"
    pg_derive.derive(str(exp_path), str(der), str(ckpt), str(pca), (1, 7), "vector")
    d = pd.read_parquet(der)
    exp = pd.read_parquet(exp_path)
    vec = [c for c in exp.columns if c.startswith("e_")]
    got = d[[f"w1d_{c}" for c in vec]].to_numpy()
    want = brute_window(exp, vec, 1)
    assert np.allclose(np.nan_to_num(got, nan=-9), np.nan_to_num(want, nan=-9), atol=1e-4)
    # the 47 (here 7) orthogonal coordinates carry nothing the head reads
    w = pg_derive.head_direction(str(ckpt))
    h = pg_derive.householder_basis(w)
    assert np.allclose(h @ h.T, np.eye(len(w)), atol=1e-10)
    o = d[[c for c in d.columns if c.startswith("o_")]].to_numpy(np.float64)
    recon = np.hstack([d[["head_coord"]].to_numpy(np.float64), o]) @ h
    assert np.allclose(recon, exp[vec].to_numpy(np.float64), atol=1e-4)
    assert np.allclose(recon @ (w / np.linalg.norm(w)), d["head_coord"], atol=1e-4)


def test_store_write_ids_and_point_in_time(tmp_path):
    t0 = pd.Timestamp("2025-06-01 10:00:00")
    exp = pd.DataFrame({ID: ["a1", "a2", "a3", "b1"], ACCOUNT: ["a", "a", "a", "b"],
                        TIME: [t0, t0 + pd.Timedelta(seconds=5), t0 + pd.Timedelta(seconds=5), t0],
                        "score": [0.1, 0.2, 0.3, 0.9], "e_0": [1.0, 2.0, 3.0, 4.0]})
    p = tmp_path / "exp.parquet"
    exp.to_parquet(p, index=False)
    pg_store.write(tmp_path / "store", "m", "v1", str(p))
    assert len(pg_store.by_ids(tmp_path / "store", "m", "v1", ["a2", "b1"])) == 2
    q = pd.DataFrame({ACCOUNT: ["a", "a", "b", "c"], TIME: [t0 + pd.Timedelta(seconds=5), t0 + pd.Timedelta(seconds=6),
                                                           t0, t0]})
    got = pg_store.as_of(tmp_path / "store", "m", "v1", q)
    assert got["e_0"].iloc[0] == 1.0  # the same second is never read: a1 is the latest strictly earlier row
    assert got["e_0"].iloc[1] in (2.0, 3.0)
    assert np.isnan(got["e_0"].iloc[2]) and np.isnan(got["e_0"].iloc[3])


def test_downstream_arms_and_offset(tmp_path):
    pytest.importorskip("xgboost")
    import pg_downstream
    rng = np.random.default_rng(5)

    def make(n, start):
        acc = rng.integers(0, 300, n).astype(str)
        y = (rng.random(n) < 0.05).astype(int)
        df = pd.DataFrame({ID: [f"{start}{i}" for i in range(n)], ACCOUNT: acc, LABEL: y,
                           TIME: pd.Timestamp(start) + pd.to_timedelta(rng.integers(0, 86400 * 20, n), "s"),
                           "transaction_amt": rng.gamma(2, 50, n), "score": 1 / (1 + np.exp(-(rng.normal(size=n) + 2 * y)))})
        for j in range(4):
            df[f"e_{j}"] = rng.normal(size=n) + (1.0 if j == 0 else 0.0) * y
        df["segment"] = rng.choice(["A", "B"], n)
        inc = pd.DataFrame({ID: df[ID], "score": 1 / (1 + np.exp(-(rng.normal(size=n) + 1.5 * y)))})
        return df, inc

    tr, tr_inc = make(4000, "2025-03-01")
    rd, rd_inc = make(3000, "2025-06-01")
    paths = {}
    for name, d in (("tr", tr), ("rd", rd), ("tr_inc", tr_inc), ("rd_inc", rd_inc)):
        paths[name] = tmp_path / f"{name}.parquet"
        d.to_parquet(paths[name], index=False)
    out = tmp_path / "down.json"
    rc = pg_downstream.main(["--train-export", str(paths["tr"]), "--read-export", str(paths["rd"]),
                             "--raw-cols", "segment", "transaction_amt", "--incumbent-train",
                             f"{paths['tr_inc']}:score", "--incumbent-read", f"{paths['rd_inc']}:score",
                             "--arms", "raw", "raw+score", "raw+score+vector", "offset", "offset_raw",
                             "--draws", "50", "--out", str(out)])
    assert rc == 0
    rec = json.loads(out.read_text())
    assert {"raw", "raw+score", "raw+score+vector", "offset", "offset_raw", "15298", "ours"} <= set(rec["points"])
    assert any(p["pair"] == "offset vs 15298" for p in rec["pairs"])


def test_sweep_drop_rule_pilot_replay_and_resume(tmp_path, monkeypatch):
    """The search with a stand-in trainer: each run writes training_metrics.csv from its learning rate."""
    calls = []

    def runner(cmd):
        calls.append(cmd)
        out = [c.split("=", 1)[1] for c in cmd if c.startswith("output.checkpoint_dir=")][0]
        lr = float([c.split("=", 1)[1] for c in cmd if c.startswith("training.learning_rate=")][0])
        epochs = int([c.split("=", 1)[1] for c in cmd if c.startswith("training.max_epochs=")][0])
        import os
        os.makedirs(out, exist_ok=True)
        good = 0.10 - 30 * abs(np.log10(lr) - np.log10(3e-4)) ** 2 * 0.01
        with open(os.path.join(out, "training_metrics.csv"), "w") as f:
            f.write("epoch,step,valid_ap\n")
            for e in range(epochs):
                f.write(f"{e},{e * 10},{good - 0.01 / (e + 1):.6f}\n")
        open(os.path.join(out, "last.ckpt"), "w").close()
        return 0

    class A:
        study_dir, trials, current_lr, train_options, seed = str(tmp_path / "sweep"), 12, 3e-4, "", 42
    assert pg_sweep.run(A, ["--config", "cfg.yaml"], runner) == 0
    st = json.loads((tmp_path / "sweep" / "trials.json").read_text())
    assert len(st["trials"]) == 12 and st["pilot_replay"] is not None
    assert st["trials"][0]["params"]["learning_rate"] == pytest.approx(3e-4)
    assert all(t["status"] in ("done", "pruned") for t in st["trials"])
    resumed = [c for c in calls if "--resume" in c]
    assert resumed and all("training.max_epochs=10" in c for c in resumed)
    n = len(calls)
    assert pg_sweep.run(A, ["--config", "cfg.yaml"], runner) == 0  # nothing left to do
    assert len(calls) == n


def test_sweep_without_optuna_draws_at_random(tmp_path, monkeypatch):
    import builtins
    real_import = builtins.__import__

    def no_optuna(name, *args, **kwargs):
        if name == "optuna":
            raise ImportError("no optuna")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", no_optuna)

    def runner(cmd):
        import os
        out = [c.split("=", 1)[1] for c in cmd if c.startswith("output.checkpoint_dir=")][0]
        epochs = int([c.split("=", 1)[1] for c in cmd if c.startswith("training.max_epochs=")][0])
        os.makedirs(out, exist_ok=True)
        with open(os.path.join(out, "training_metrics.csv"), "w") as f:
            f.write("epoch,step,valid_ap\n" + "".join(f"{e},{e},{0.05 + 0.001 * e}\n" for e in range(epochs)))
        return 0

    class A:
        study_dir, trials, current_lr, train_options, seed = str(tmp_path / "s"), 5, 3e-4, "", 1
    assert pg_sweep.run(A, ["--config", "c.yaml"], runner) == 0
    st = json.loads((tmp_path / "s" / "trials.json").read_text())
    assert len({t["params"]["learning_rate"] for t in st["trials"]}) == 5


def test_diagnostics_rank_cka_align_and_probe(tmp_path):
    import pg_diagnostics as D
    rng = np.random.default_rng(2)
    n, accounts = 3000, 200
    acc = rng.integers(0, accounts, n).astype(str)
    t = pd.Timestamp("2025-05-20") + pd.to_timedelta(rng.integers(0, 86400 * 40, n), "s")
    y = (rng.random(n) < 0.03).astype(int)
    x = rng.normal(size=(n, 6))
    a = pd.DataFrame({ID: [f"t{i}" for i in range(n)], ACCOUNT: acc, TIME: t, LABEL: y, "score": rng.random(n)})
    for j in range(6):
        a[f"e_{j}"] = x[:, j]
    rot = np.linalg.qr(rng.normal(size=(6, 6)))[0]
    b = a.copy()
    for j in range(6):
        b[f"e_{j}"] = (x @ rot)[:, j]
    pa_, pb = tmp_path / "a.parquet", tmp_path / "b.parquet"
    a.to_parquet(pa_, index=False)
    b.to_parquet(pb, index=False)
    r = D.rank_readings(a, [f"e_{j}" for j in range(6)], draws=10)
    assert 5.0 < r["all rows"]["rank"] <= 6.0
    c = D.cka(str(pa_), str(pb), draws=10)
    assert c["cka"] == pytest.approx(1.0, abs=1e-6) and c["shuffled_rows_mean"] < 0.1  # a rotation keeps CKA at 1
    al = D.align(str(pa_), str(pb), str(tmp_path / "aligned.parquet"))
    assert al["held_out_r2"] > 0.999
    got = pd.read_parquet(tmp_path / "aligned.parquet")
    assert np.allclose(got[[f"e_{j}" for j in range(6)]].to_numpy(), x, atol=1e-4)
    out = D.probe(str(pa_), draws=10)
    assert all("ap" in v for v in out.values())


def test_sweep_restart_proposes_like_an_uninterrupted_search_and_replays_pilots_after_a_failure(tmp_path):
    pytest.importorskip("optuna")

    def runner_for(fail=()):
        def runner(cmd):
            import os
            out = [c.split("=", 1)[1] for c in cmd if c.startswith("output.checkpoint_dir=")][0]
            if any(out.endswith(f"trial_{k}") for k in fail):
                return 1
            epochs = int([c.split("=", 1)[1] for c in cmd if c.startswith("training.max_epochs=")][0])
            os.makedirs(out, exist_ok=True)
            with open(os.path.join(out, "training_metrics.csv"), "w") as f:
                f.write("epoch,step,valid_ap\n" + "".join(f"{e},{e},{0.05 + 0.001 * e}\n" for e in range(epochs)))
            return 0
        return runner

    class A:
        study_dir, trials, current_lr, train_options, seed = str(tmp_path / "straight"), 6, 3e-4, "", 7
    pg_sweep.run(A, ["--config", "c.yaml"], runner_for())
    straight = [t["params"] for t in json.loads((tmp_path / "straight" / "trials.json").read_text())["trials"]]

    class B(A):
        study_dir, trials = str(tmp_path / "cut"), 3
    pg_sweep.run(B, ["--config", "c.yaml"], runner_for())
    B.trials = 6
    pg_sweep.run(B, ["--config", "c.yaml"], runner_for())
    cut = [t["params"] for t in json.loads((tmp_path / "cut" / "trials.json").read_text())["trials"]]
    assert cut == straight  # a restart proposes exactly what an uninterrupted search proposes

    class C(A):
        study_dir, trials = str(tmp_path / "fail3"), 5
    pg_sweep.run(C, ["--config", "c.yaml"], runner_for(fail=(3,)))
    st = json.loads((tmp_path / "fail3" / "trials.json").read_text())
    assert st["trials"][3]["status"] == "failed" and st["pilot_replay"] is not None


def test_long_windows_stay_inside_their_account():
    t = pd.to_datetime(["2025-03-01", "2025-05-30", "2025-01-01"])
    means, counts = pg_derive.window_means(np.array(["a", "a", "b"]), t, np.array([[100.0], [5.0], [200.0]]),
                                           days=(30, 60, 90))
    assert counts[2].tolist() == [0, 0, 0]  # b's only row sees nothing, however long the window
    assert counts[1].tolist() == [0, 0, 1] and means[1, 2, 0] == 100.0  # a's earlier row is 90 days back


def test_store_keys_times_and_no_label(tmp_path, capsys):
    t0 = pd.Timestamp("2025-06-01 10:00:00")
    exp = pd.DataFrame({ID: ["a1", "a2"], ACCOUNT: [37389549.0, 37389549.0], LABEL: [1, 0],
                        TIME: [t0, t0 + pd.Timedelta(seconds=5)], "score": [0.9, 0.1], "e_0": [1.0, 2.0]})
    p = tmp_path / "exp.parquet"
    exp.to_parquet(p, index=False)
    pg_store.write(tmp_path / "store", "m", "v1", str(p), checkpoint="run_a/best.ckpt")
    pg_store.write(tmp_path / "store", "m", "v1", str(p), checkpoint="run_b/best.ckpt")
    assert "different space" in capsys.readouterr().out
    asked = pd.to_datetime(["2025-06-01T10:00:09Z", "2025-06-01T10:00:05Z"])
    if int(pd.__version__.split(".")[0]) >= 2:  # pandas 1.x holds nanoseconds only; from 2.0 on, other units too
        asked = asked.astype("datetime64[us, UTC]")
    q = pd.DataFrame({ACCOUNT: ["37389549", 37389549], TIME: asked})
    got = pg_store.as_of(tmp_path / "store", "m", "v1", q)
    assert got["e_0"].tolist() == [2.0, 1.0] and LABEL not in got  # strictly earlier, never the label
    with pytest.raises(SystemExit):
        pg_store.write("s3://bucket/store", "m", "v1", str(p))


def test_downstream_with_partial_15298_coverage_typed_amounts_and_the_right_files(tmp_path):
    pytest.importorskip("xgboost")
    import pg_downstream
    rng = np.random.default_rng(9)

    def make(n, start, files_dir, number):
        acc = rng.integers(0, 300, n).astype(str)
        y = (rng.random(n) < 0.05).astype(int)
        ids = [f"{start}{i}" for i in range(n)]
        df = pd.DataFrame({ID: ids, ACCOUNT: acc, LABEL: y, "score": 1 / (1 + np.exp(-(rng.normal(size=n) + 2 * y))),
                           TIME: pd.Timestamp(start) + pd.to_timedelta(rng.integers(0, 86400 * 20, n), "s"),
                           "transaction_amt": [str(round(v, 2)) for v in rng.gamma(2, 50, n)]})  # text, as metadata
        for j in range(4):
            df[f"e_{j}"] = rng.normal(size=n) + (1.0 if j == 0 else 0.0) * y
        files_dir.mkdir(exist_ok=True)
        pd.DataFrame({ID: ids, "transaction_amt": df["transaction_amt"].astype(float),
                      "segment": rng.choice(["A", "B"], n)}).to_parquet(files_dir / f"part_{number}.parquet", index=False)
        inc = pd.DataFrame({ID: ids, "score": 1 / (1 + np.exp(-(rng.normal(size=n) + 1.5 * y)))}).iloc[: int(n * 0.7)]
        return df, inc

    raw = tmp_path / "raw"
    tr, tr_inc = make(4000, "2025-03-01", raw, 1)
    rd, rd_inc = make(3000, "2025-06-01", raw, 2)
    paths = {}
    for name, d in (("tr", tr), ("rd", rd), ("tr_inc", tr_inc), ("rd_inc", rd_inc)):
        paths[name] = tmp_path / f"{name}.parquet"
        d.to_parquet(paths[name], index=False)
    base = ["--train-export", str(paths["tr"]), "--read-export", str(paths["rd"]), "--train-raw-base", str(raw),
            "--read-raw-base", str(raw), "--raw-cols", "segment", "transaction_amt", "--draws", "30"]
    out = tmp_path / "down.json"
    assert pg_downstream.main(base + ["--train-files", "1", "1", "--read-files", "2", "2", "--incumbent-train",
                                      f"{paths['tr_inc']}:score", "--incumbent-read", f"{paths['rd_inc']}:score",
                                      "--arms", "raw", "raw+score", "offset", "offset_raw", "offset_open", "flipped",
                                      "two_weights", "joined", "--out", str(out)]) == 0
    rec = json.loads(out.read_text())
    assert rec["fits"]["offset"]["best_iteration"] > 0  # the covered rows train real trees
    pair = [p for p in rec["pairs"] if p["pair"] == "offset vs 15298"][0]
    assert pair["rows"] == rec["points"]["15298"]["rows_read"] < rec["read_rows"]
    # every arm that joins the two models is fitted and read on the rows that have both scores, flipped too (its
    # start is our score, which every row has)
    covered_fit, covered_read = len(tr_inc), int(rd[ID].isin(rd_inc[ID]).sum())
    for arm in ("offset", "offset_raw", "offset_open", "flipped", "joined"):
        assert rec["fits"][arm]["fit_rows"] == covered_fit and rec["points"][arm]["rows_read"] == covered_read
    assert rec["points"]["two_weights"]["rows_read"] == covered_read
    assert rec["points"]["raw"]["rows_read"] == rec["points"]["ours"]["rows_read"] == rec["read_rows"]
    pairs = {p["pair"]: p["rows"] for p in rec["pairs"]}
    assert pairs["flipped vs ours"] == pairs["joined vs ours"] == pairs["two_weights vs ours"] == covered_read
    table = out.with_suffix(".txt").read_text()
    assert "rows" in table.split("arm", 1)[1].splitlines()[0] and f"{covered_read:,}" in table
    with pytest.raises(SystemExit, match="not in the raw files"):
        pg_downstream.main(base + ["--train-files", "1", "1", "--read-files", "1", "1", "--arms", "raw",
                                   "--out", str(tmp_path / "x.json")])


def test_probe_reads_the_other_file(tmp_path):
    import pg_diagnostics as D
    rng = np.random.default_rng(4)
    n = 2000
    a = pd.DataFrame({ID: [f"t{i}" for i in range(n)], ACCOUNT: rng.integers(0, 100, n).astype(str),
                      TIME: pd.Timestamp("2025-06-01") + pd.to_timedelta(rng.integers(0, 86400 * 29, n), "s"),
                      LABEL: (rng.random(n) < 0.05).astype(int), "score": rng.random(n)})
    for j in range(3):
        a[f"e_{j}"] = rng.normal(size=n)
    other = pd.DataFrame({ID: a[ID], "emb_0": rng.normal(size=n), "emb_1": rng.normal(size=n)})
    a.to_parquet(tmp_path / "a.parquet", index=False)
    other.to_parquet(tmp_path / "o.parquet", index=False)
    out = D.probe(str(tmp_path / "a.parquet"), other=str(tmp_path / "o.parquet"), other_prefix="emb_", draws=5)
    assert any(k.startswith("other |") for k in out) and not any("47 hidden" in k for k in out)


def _calibrated(x, y):
    """(a, b) with a + b * x a calibrated log-odds of y: Newton steps on the log loss."""
    a, b = float(np.log(y.mean() / (1 - y.mean()))), 0.0
    for _ in range(50):
        p = 1 / (1 + np.exp(-(a + b * x)))
        g = np.array([(p - y).sum(), ((p - y) * x).sum()])
        h = p * (1 - p)
        hess = np.array([[h.sum(), (h * x).sum()], [(h * x).sum(), (h * x * x).sum()]])
        a, b = np.array([a, b]) - np.linalg.solve(hess, g)
    return a, b


def _two_model_rows(rng, n, start, cal=None):
    """Rows scored by two models that share most of what they know. Ours sees the shared evidence and its own;
    15298's stand-in sees the shared evidence only, so it adds little beside ours. Both scores are calibrated."""
    shared, own, unseen = rng.normal(size=n) * 2.0, rng.normal(size=n) * 1.2, rng.normal(size=n)
    y = (rng.random(n) < 1 / (1 + np.exp(-(shared + own + unseen - 7.5)))).astype(int)
    ours_raw, theirs_raw = shared + own, shared + rng.normal(size=n) * 0.3
    cal = cal or (_calibrated(ours_raw, y), _calibrated(theirs_raw, y))
    ours, theirs = cal[0][0] + cal[0][1] * ours_raw, cal[1][0] + cal[1][1] * theirs_raw
    ids = [f"{start}-{i}" for i in range(n)]
    df = pd.DataFrame({ID: ids, ACCOUNT: rng.integers(0, n // 8, n).astype(str), LABEL: y,
                       TIME: pd.Timestamp(start) + pd.to_timedelta(rng.integers(0, 86400 * 20, n), "s"),
                       "transaction_amt": rng.gamma(2, 50, n), "score": 1 / (1 + np.exp(-ours))})
    df["e_0"], df["e_1"] = shared + rng.normal(size=n) * 0.1, own + rng.normal(size=n) * 0.1
    df["e_2"], df["e_3"] = rng.normal(size=n), rng.normal(size=n)
    inc = pd.DataFrame({ID: ids, "score": 1 / (1 + np.exp(-theirs))})
    feats = pd.DataFrame({ID: ids, "f_0": theirs_raw + rng.normal(size=n) * 0.05, "f_1": rng.normal(size=n),
                          "f_text": rng.choice(["a", "b"], n)})
    return df, inc, feats, cal


def _two_model_files(tmp_path, n, seed):
    rng = np.random.default_rng(seed)
    tr, tr_inc, tr_f, cal = _two_model_rows(rng, n, "2025-03-01")
    rd, rd_inc, rd_f, _ = _two_model_rows(rng, n, "2025-06-01", cal)
    paths = {}
    for name, d in (("tr", tr), ("rd", rd), ("tr_inc", tr_inc), ("rd_inc", rd_inc), ("tr_f", tr_f), ("rd_f", rd_f)):
        paths[name] = tmp_path / f"{name}.parquet"
        d.to_parquet(paths[name], index=False)
    return paths, ["--train-export", str(paths["tr"]), "--read-export", str(paths["rd"]), "--raw-cols",
                   "transaction_amt", "--incumbent-train", f"{paths['tr_inc']}:score", "--incumbent-read",
                   f"{paths['rd_inc']}:score", "--draws", "20"]


def test_joining_two_scores_keeps_the_stronger_one(tmp_path):
    """Where 15298 adds little beside our score, the offset arm, which holds 15298's margin at full weight, reads
    below our score alone. The two weights say why (15298's is near zero), and the arms that start from our score
    or from the weighted sum keep what our score knows."""
    pytest.importorskip("xgboost")
    import pg_downstream
    paths, base = _two_model_files(tmp_path, 150_000, 1)
    out = tmp_path / "down.json"
    assert pg_downstream.main(base + ["--arms", "offset", "offset_open", "flipped", "two_weights", "joined",
                                      "--out", str(out)]) == 0
    rec = json.loads(out.read_text())
    ap = {k: v["ap"] for k, v in rec["points"].items()}
    assert ap["ours"] > ap["15298"] + 0.05
    assert ap["offset"] < ap["ours"] - 0.008                     # the old arm loses part of our score's lead
    assert abs(ap["two_weights"] - ap["ours"]) < 0.004           # the weighted sum keeps it
    assert min(ap["flipped"], ap["joined"]) > ap["ours"] - 0.008 and ap["flipped"] > ap["offset"]
    fit = rec["fits"]["two_weights"]
    assert abs(fit["weight_15298"]) < 0.15 and 0.8 < fit["weight_ours"] < 1.2
    assert rec["fits"]["offset"]["start"] == "15298" and rec["fits"]["flipped"]["start"] == "ours"
    # offset_open: our logit, 15298's margin, the raw field and the four vector numbers
    assert rec["fits"]["joined"]["start"] == "two_weights" and rec["fits"]["offset_open"]["columns"] == 7
    pairs = {p["pair"]: p for p in rec["pairs"]}
    assert {"ours vs 15298", "offset vs ours", "flipped vs ours", "joined vs ours", "joined vs 15298",
            "two_weights vs ours", "joined vs two_weights"} <= set(pairs)
    assert pairs["offset vs ours"]["ap"]["gain"] < 0 < pairs["ours vs 15298"]["udr"]["gain"]
    text = out.with_suffix(".txt").read_text()
    assert "two weights, fitted on" in text and "VDR" in text.split("offset vs ours")[1].splitlines()[0]


def test_two_weights_finds_the_weights_the_rows_were_drawn_with():
    import pg_downstream
    rng = np.random.default_rng(3)
    theirs, ours = rng.normal(size=200_000) * 2 - 3, rng.normal(size=200_000) * 2 - 3
    y = (rng.random(200_000) < 1 / (1 + np.exp(-(0.4 + 0.25 * theirs + 0.9 * ours)))).astype(float)
    w = pg_downstream.two_weights(y, theirs, ours)
    assert np.allclose(w, [0.4, 0.25, 0.9], atol=0.06)
    # rows that one score splits cleanly do not send the weights to infinity or to not-a-number
    clean = pg_downstream.two_weights((ours > 0).astype(float), theirs, ours)
    assert np.isfinite(clean).all() and clean[2] > 1


def test_an_arm_scores_each_row_from_its_own_start(tmp_path):
    """The starting margin is part of the score at reading time too: the same row from a start three higher scores
    exactly three higher, and an arm without a start scores from the trees alone."""
    pytest.importorskip("xgboost")
    import pg_downstream
    rng = np.random.default_rng(4)
    n = 6000
    df = pd.DataFrame({ACCOUNT: rng.integers(0, 500, n).astype(str), LABEL: (rng.random(n) < 0.1).astype(int),
                       "x": rng.normal(size=n)})
    df["x"] += df[LABEL]
    start = rng.normal(size=n)
    booster, info = pg_downstream.fit_arm(df, ["x"], {}, start, dict(pg_downstream.FIXED), rounds=30, early=10,
                                          max_bin=64)
    assert info["max_bin"] == 64 and 0.0 <= info["inner_aucpr"] <= 1.0
    low = pg_downstream.predict(booster, df, ["x"], {}, start)
    high = pg_downstream.predict(booster, df, ["x"], {}, start + 3.0)
    assert np.allclose(high - low, 3.0, atol=1e-4)
    trees_only = low - start
    assert np.unique(np.round(trees_only, 5)).size < n / 5       # what is left is a step function of x: the trees
    plain, _ = pg_downstream.fit_arm(df, ["x"], {}, None, dict(pg_downstream.FIXED), rounds=30, early=10)
    assert np.isfinite(pg_downstream.predict(plain, df, ["x"], {}, None)).all()


def test_downstream_bins_amount_weights_15298_inputs_and_a_second_run(tmp_path):
    pytest.importorskip("xgboost")
    import pg_downstream
    paths, base = _two_model_files(tmp_path, 20_000, 2)
    out = tmp_path / "down.json"
    args = base + ["--incumbent-features-train", str(paths["tr_f"]), "--incumbent-features-read", str(paths["rd_f"]),
                   "--arms", "flipped", "joined", "raw+score", "--max-bin", "64", "--amount-power", "0.5",
                   "--out", str(out)]
    assert pg_downstream.main(args) == 0
    rec = json.loads(out.read_text())
    for arm in ("flipped", "joined", "raw+score"):
        assert rec["fits"][arm]["max_bin"] == 64 and 0.0 <= rec["fits"][arm]["inner_aucpr"] <= 1.0
    # flipped: 15298's margin, the raw field and the two numeric inputs; joined: both margins, the raw field, the
    # four vector numbers and the two numeric inputs. The text column is left out and named
    assert rec["fits"]["flipped"]["columns"] == 4 and rec["fits"]["joined"]["columns"] == 9
    assert any("15298's own inputs (2 columns)" in n and "f_text" in n for n in rec["notes"])
    assert pg_downstream.main(args) == 0                         # a second run writes the same --out again
    assert json.loads(out.read_text())["points"].keys() == rec["points"].keys()
    # without 15298's scores the arms that need them are skipped with a line, and the others still run
    out2 = tmp_path / "down2.json"
    assert pg_downstream.main(["--train-export", str(paths["tr"]), "--read-export", str(paths["rd"]), "--raw-cols",
                               "transaction_amt", "--draws", "5", "--arms", "raw+score", "flipped", "two_weights",
                               "--out", str(out2)]) == 0
    rec2 = json.loads(out2.read_text())
    assert "flipped" not in rec2["points"] and "two_weights" not in rec2["points"] and "raw+score" in rec2["points"]
    assert sum("skipped (no 15298 scores given for the training rows and the read rows)" in n
               for n in rec2["notes"]) == 2


def test_a_15298_score_held_for_some_rows_only_is_not_read_as_what_15298_adds(tmp_path):
    """15298's scores are noise and exist only for one kind of row, the kind with more fraud, which our score does
    not know. An arm fitted on every row would learn from which rows have a score, and `flipped vs ours` would read
    that as what 15298 adds; fitted and read on the rows that have both scores, it adds nothing."""
    pytest.importorskip("xgboost")
    import pg_downstream
    rng = np.random.default_rng(11)

    def make(n, start):
        kind = rng.random(n) < 0.4
        evidence = rng.normal(size=n) * 1.5
        y = (rng.random(n) < 1 / (1 + np.exp(-(evidence + 2.5 * kind - 5.0)))).astype(int)
        ids = [f"{start}-{i}" for i in range(n)]
        df = pd.DataFrame({ID: ids, ACCOUNT: rng.integers(0, n // 8, n).astype(str), LABEL: y,
                           TIME: pd.Timestamp(start) + pd.to_timedelta(rng.integers(0, 86400 * 20, n), "s"),
                           "transaction_amt": rng.gamma(2, 50, n), "score": 1 / (1 + np.exp(-(evidence - 4.0)))})
        inc = pd.DataFrame({ID: ids, "score": 1 / (1 + np.exp(-rng.normal(size=n)))})[kind]
        return df, inc

    tr, tr_inc = make(60_000, "2025-03-01")
    rd, rd_inc = make(60_000, "2025-06-01")
    for name, d in (("tr", tr), ("rd", rd), ("tr_inc", tr_inc), ("rd_inc", rd_inc)):
        d.to_parquet(tmp_path / f"{name}.parquet", index=False)
    out = tmp_path / "down.json"
    assert pg_downstream.main(["--train-export", str(tmp_path / "tr.parquet"), "--read-export",
                               str(tmp_path / "rd.parquet"), "--raw-cols", "transaction_amt", "--incumbent-train",
                               f"{tmp_path / 'tr_inc.parquet'}:score", "--incumbent-read",
                               f"{tmp_path / 'rd_inc.parquet'}:score", "--arms", "flipped", "two_weights",
                               "--draws", "20", "--out", str(out)]) == 0
    rec = json.loads(out.read_text())
    assert rec["fits"]["flipped"]["fit_rows"] == len(tr_inc) and rec["points"]["flipped"]["rows_read"] == len(rd_inc)
    gain = {p["pair"]: p for p in rec["pairs"]}["flipped vs ours"]
    assert gain["rows"] == len(rd_inc) and abs(gain["ap"]["gain"]) < 0.01
    assert abs(rec["fits"]["two_weights"]["per_spread_15298"]) < 0.1 < rec["fits"]["two_weights"]["per_spread_ours"]


def test_the_15298_inputs_file_gives_inputs_only(tmp_path):
    """A file of 15298's inputs that also holds the label, the account and the time gives the trees its inputs
    only, and says so; an id held twice gives one row; a column held for one side only is left out with a line;
    an infinite value is a missing one."""
    pytest.importorskip("xgboost")
    import pg_downstream
    paths, base = _two_model_files(tmp_path, 20_000, 3)
    tr, rd = pd.read_parquet(paths["tr"]), pd.read_parquet(paths["rd"])
    tr_f, rd_f = pd.read_parquet(paths["tr_f"]), pd.read_parquet(paths["rd_f"])
    for frame, feats in ((tr, tr_f), (rd, rd_f)):
        for key in (LABEL, ACCOUNT, TIME):
            feats[key] = frame[key].to_numpy()
    tr_f["only_here"] = 1.0
    tr_f.loc[0, "f_1"] = np.inf
    pd.concat([tr_f, tr_f.iloc[:500]]).to_parquet(paths["tr_f"], index=False)      # 500 ids held twice
    rd_f.to_csv(tmp_path / "rd_f.csv", index=False)                                # the read side as a CSV file
    out = tmp_path / "down.json"
    assert pg_downstream.main(base + ["--incumbent-features-train", str(paths["tr_f"]), "--incumbent-features-read",
                                      str(tmp_path / "rd_f.csv"), "--arms", "flipped", "joined", "--out",
                                      str(out)]) == 0
    rec = json.loads(out.read_text())
    assert rec["train_rows"] == len(tr) and rec["read_rows"] == len(rd)
    # flipped: 15298's margin, the raw field, f_0 and f_1; the label, the keys, the text column and the column of
    # one side are not among them
    assert rec["fits"]["flipped"]["columns"] == 4 and rec["fits"]["joined"]["columns"] == 9
    notes = " | ".join(rec["notes"])
    assert "the export's own keys or label" in notes and LABEL in notes
    one_side = [n for n in rec["notes"] if "held for the training rows or for the read rows only" in n]
    assert len(one_side) == 1 and "only_here" in one_side[0]
    assert rec["incumbent_inputs"]["one_side_only"] == ["only_here"]
    assert "f_0, f_1" in notes and "f_text" in notes
    assert rec["points"]["flipped"]["ap"] < rec["points"]["ours"]["ap"] + 0.05       # no label among the columns
    assert rec["fits"]["flipped"]["column_names"] == ["incumbent_margin", "transaction_amt", "inc_f_0", "inc_f_1"]
    # the infinite value is a missing one in the trees' matrix, at its own row
    held, _ = pg_downstream.frame(str(paths["tr"]), None, None, None, None, ["transaction_amt"],
                                  incumbent_features=str(paths["tr_f"]))
    matrix = pg_downstream.to_matrix(held, ["inc_f_1", "inc_f_0"], {})
    assert np.isnan(matrix["inc_f_1"].iloc[0]) and np.isfinite(matrix["inc_f_1"].iloc[1:]).all()
    assert np.allclose(matrix["inc_f_0"], tr_f["f_0"].to_numpy()[: len(tr)], rtol=1e-6)
    assert held["_inputs_row"].all()


def test_bins_and_amount_weights_reach_the_trees(tmp_path, monkeypatch):
    """--max-bin changes what the trees can split on, --amount-power weighs the rows the trees are fitted on and
    not the held-out ones, and only the arms offset and offset_raw keep max_delta_step 1."""
    pytest.importorskip("xgboost")
    import xgboost
    import pg_downstream
    assert np.allclose(pg_downstream.amount_weights([50.0, 200.0, 0.0, -5.0, None, "abc", " 12.50 "], 0.5),
                       [1.0, 2.0, 1.0, 1.0, 1.0, 1.0, 0.5])
    # a power that sends a weight past what a number can hold: kept between a millionth and a million
    assert np.allclose(pg_downstream.amount_weights([1e-200, 1.0, 1.0, 1e200], -2.0), [1e6, 1.0, 1.0, 1e-6])
    paths, base = _two_model_files(tmp_path, 20_000, 4)
    scored = pd.read_parquet(paths["tr_inc"]).iloc[::-1].iloc[:14_000]             # 15298 scores for 7 rows in 10
    scored.to_parquet(paths["tr_inc"], index=False)
    given, settings = [], []
    real_matrix, real_train = xgboost.DMatrix, xgboost.train
    monkeypatch.setattr(xgboost, "DMatrix", lambda *a, **k: (given.append(k.get("weight")), real_matrix(*a, **k))[1])
    monkeypatch.setattr(xgboost, "train", lambda p, *a, **k: (settings.append(dict(p)), real_train(p, *a, **k))[1])
    out = tmp_path / "coarse.json"
    arms = ["raw+score", "offset", "offset_raw", "offset_open", "flipped", "joined"]
    assert pg_downstream.main(base + ["--arms"] + arms + ["--max-bin", "2", "--amount-power", "0.5", "--out",
                                                          str(out)]) == 0
    coarse = json.loads(out.read_text())
    assert [p["max_bin"] for p in settings] == [2] * 6
    assert [p.get("max_delta_step") for p in settings] == [None, 1.0, 1.0, None, None, None]
    # per arm: the fit rows weighted, the held-out rows not, the read rows not; each fit row carries the weight of
    # its own amount, among the rows of its arm
    train = pd.read_parquet(paths["tr"])
    assert len(given) == 18 and all(w is None for w in given[1::3] + given[2::3])
    has_score = train[ID].isin(scored[ID]).to_numpy()
    for k, arm in enumerate(arms):
        rows = train if arm == "raw+score" else train[has_score]
        fitted, _ = pg_downstream.inner_split(rows[ACCOUNT].to_numpy())
        want = pg_downstream.amount_weights(rows["transaction_amt"].to_numpy(), 0.5)[fitted]
        assert given[3 * k] is not None and np.allclose(given[3 * k], want), arm
    assert float(np.min(given[0])) > 0 and float(np.std(given[0])) > 0.1
    fine_out = tmp_path / "fine.json"
    assert pg_downstream.main(base + ["--arms", "raw+score", "--out", str(fine_out)]) == 0
    fine = json.loads(fine_out.read_text())
    assert settings[-1]["max_bin"] == 256 and given[-3] is None
    # with one cut per column the trees cannot follow our score; with 256 they can
    assert fine["points"]["raw+score"]["ap"] > coarse["points"]["raw+score"]["ap"] + 0.02


def test_two_weights_where_15298_adds_much(tmp_path):
    """Two scores that each hold evidence the other lacks: both weights are well above zero, the weighted sum reads
    above either score, and the weights are those of a separate fit on the training rows."""
    pytest.importorskip("xgboost")
    import pg_downstream
    rng = np.random.default_rng(12)

    def make(n, start, cal=None):
        shared, mine, theirs_own = rng.normal(size=n) * 1.5, rng.normal(size=n) * 1.3, rng.normal(size=n) * 1.3
        y = (rng.random(n) < 1 / (1 + np.exp(-(shared + mine + theirs_own - 6.5)))).astype(int)
        ours_raw, theirs_raw = shared + mine, shared + theirs_own
        cal = cal or (_calibrated(ours_raw, y), _calibrated(theirs_raw, y))
        ours, theirs = cal[0][0] + cal[0][1] * ours_raw, cal[1][0] + cal[1][1] * theirs_raw
        ids = [f"{start}-{i}" for i in range(n)]
        df = pd.DataFrame({ID: ids, ACCOUNT: rng.integers(0, n // 8, n).astype(str), LABEL: y,
                           TIME: pd.Timestamp(start) + pd.to_timedelta(rng.integers(0, 86400 * 20, n), "s"),
                           "transaction_amt": rng.gamma(2, 50, n), "score": 1 / (1 + np.exp(-ours))})
        return df, pd.DataFrame({ID: ids, "score": 1 / (1 + np.exp(-theirs))}), cal, (ours, theirs)

    tr, tr_inc, cal, margins = make(80_000, "2025-03-01")
    rd, rd_inc, _, _ = make(80_000, "2025-06-01", cal)
    for name, d in (("tr", tr), ("rd", rd), ("tr_inc", tr_inc), ("rd_inc", rd_inc)):
        d.to_parquet(tmp_path / f"{name}.parquet", index=False)
    out = tmp_path / "down.json"
    args = ["--train-export", str(tmp_path / "tr.parquet"), "--read-export", str(tmp_path / "rd.parquet"), "--raw-cols",
            "transaction_amt", "--incumbent-train", f"{tmp_path / 'tr_inc.parquet'}:score", "--incumbent-read",
            f"{tmp_path / 'rd_inc.parquet'}:score", "--arms", "two_weights", "joined", "--draws", "20"]
    assert pg_downstream.main(args + ["--out", str(out)]) == 0
    rec = json.loads(out.read_text())
    fit, ap = rec["fits"]["two_weights"], {k: v["ap"] for k, v in rec["points"].items()}
    assert fit["weight_15298"] > 0.3 and fit["weight_ours"] > 0.3
    best_alone = max(ap["ours"], ap["15298"])
    assert ap["two_weights"] > best_alone + 0.03 and ap["joined"] > best_alone + 0.02
    # the same weights from a separate fit on the training rows: Newton steps on the two margins as the tool reads
    # them (the logits of the exported shares)
    y = tr[LABEL].to_numpy(float)
    x = np.stack([np.ones(len(y)), pg_downstream.logit(tr_inc["score"].to_numpy()),
                  pg_downstream.logit(tr["score"].to_numpy(), 1e-7)], 1)
    w = np.array([np.log(y.mean() / (1 - y.mean())), 0.0, 0.0])
    for _ in range(60):
        prob = 1 / (1 + np.exp(-(x @ w)))
        w = w - np.linalg.solve((x * (prob * (1 - prob))[:, None]).T @ x, x.T @ (prob - y))
    assert np.allclose([fit["constant"], fit["weight_15298"], fit["weight_ours"]], w, atol=2e-3)
    # 15298's scores handed over as points on a scale: a line says they look like no margin
    (tr_inc.assign(score=tr_inc["score"] * 999)).to_parquet(tmp_path / "tr_pts.parquet", index=False)
    (rd_inc.assign(score=rd_inc["score"] * 999)).to_parquet(tmp_path / "rd_pts.parquet", index=False)
    out2 = tmp_path / "points.json"
    args2 = [a.replace("tr_inc.parquet", "tr_pts.parquet").replace("rd_inc.parquet", "rd_pts.parquet") for a in args]
    assert pg_downstream.main(args2[:-5] + ["--arms", "two_weights", "--draws", "5", "--out", str(out2)]) == 0
    rec2 = json.loads(out2.read_text())
    assert any("looks like points on a scale" in n for n in rec2["notes"])
    assert rec2["fits"]["two_weights"]["weight_15298"] < 0.05 < rec2["fits"]["two_weights"]["per_spread_15298"]


def test_arms_with_no_read_row_to_score_are_left_out_with_a_line(tmp_path):
    pytest.importorskip("xgboost")
    import pg_downstream
    paths, base = _two_model_files(tmp_path, 8_000, 6)
    other = pd.read_parquet(paths["rd_inc"])
    other[ID] = "other-" + other[ID]                       # 15298's scores of the read rows are those of other rows
    other.to_parquet(paths["rd_inc"], index=False)
    out = tmp_path / "down.json"
    assert pg_downstream.main(base + ["--arms", "raw+score", "offset", "flipped", "two_weights", "--out",
                                      str(out)]) == 0
    rec = json.loads(out.read_text())
    assert set(rec["points"]) == {"raw+score", "ours"}
    assert sum("no read row has the scores it needs" in n for n in rec["notes"]) >= 3


def test_the_label_and_the_keys_stay_out_of_the_trees_however_they_are_written(tmp_path):
    """15298's inputs file with the label in upper case and with a blank in front, the account as a number under a
    lower-case name, the time as seconds, and the label once more under a name of its own: none reaches the trees
    and each is named. With more than eight inputs every column name is in the record. A column that alone tells
    fraud from the rest is named and kept."""
    pytest.importorskip("xgboost")
    import pg_downstream
    paths, base = _two_model_files(tmp_path, 20_000, 21)
    rng = np.random.default_rng(1021)                    # not the world's seed: its first draws would be the world's
    for side in ("tr", "rd"):
        rows, feats = pd.read_parquet(paths[side]), pd.read_parquet(paths[f"{side}_f"]).drop(columns=["f_text"])
        for k in range(12):
            feats[f"v{k:02d}"] = rng.normal(size=len(rows))
        feats[LABEL.upper()], feats[" " + LABEL] = rows[LABEL].to_numpy(), rows[LABEL].to_numpy()
        feats[ACCOUNT.lower()] = rows[ACCOUNT].astype(np.int64).to_numpy()
        feats[TIME.upper()] = (rows[TIME] - pd.Timestamp("2025-01-01")).dt.total_seconds().to_numpy()
        feats["v_outcome"] = rows[LABEL].to_numpy().astype(float)
        feats.to_parquet(paths[f"{side}_f"], index=False)
    out = tmp_path / "down.json"
    assert pg_downstream.main(base + ["--incumbent-features-train", str(paths["tr_f"]), "--incumbent-features-read",
                                      str(paths["rd_f"]), "--arms", "flipped", "--out", str(out)]) == 0
    rec = json.loads(out.read_text())
    used = ["f_0", "f_1"] + [f"v{k:02d}" for k in range(12)]
    assert rec["fits"]["flipped"]["column_names"] == ["incumbent_margin", "transaction_amt"] + [
        f"inc_{c}" for c in used]
    for side in ("training rows", "read rows"):
        held = rec["incumbent_inputs"][side]
        assert set(held["keys_or_label"]) == {LABEL.upper(), " " + LABEL, ACCOUNT.lower(), TIME.upper()}
        assert held["equal_to_the_label"] == ["v_outcome"] and held["used"] == used and held["rows"] == 20_000
    notes = " | ".join(rec["notes"])
    assert "equal to the label on every row" in notes and "v_outcome" in notes
    assert "14 in all, every name is in the record" in notes
    assert rec["points"]["flipped"]["ap"] < rec["points"]["ours"]["ap"] + 0.05       # no label among the columns
    # a column that all but gives the label is named, and stays: the tool cannot know that it is no honest input
    rows, feats = pd.read_parquet(paths["tr"]), pd.read_parquet(paths["tr_f"])
    feats["v_late"] = 3.0 * rows[LABEL].to_numpy() + rng.normal(size=len(rows)) * 0.2
    feats.to_parquet(tmp_path / "late.parquet", index=False)
    record = {}
    held, said = pg_downstream.frame(str(paths["tr"]), None, None, None, None, ["transaction_amt"],
                                     name="training rows", incumbent_features=str(tmp_path / "late.parquet"),
                                     record=record)
    assert "inc_v_late" in held and "inc_v_outcome" not in held
    assert [name.split(" ")[0] for name in record["separates_the_label_alone"]] == ["v_late"]
    assert sum("alone tells fraud from the rest" in line and "v_late" in line for line in said) == 1
    # alone, a column of noise reads one half, and one that follows the label reads near one
    y = rows[LABEL].to_numpy(float)
    assert abs(pg_downstream.lone_auroc(rng.normal(size=len(y)), y) - 0.5) < 0.05
    assert pg_downstream.lone_auroc(y + rng.normal(size=len(y)) * 0.01, y) > 0.9999
    assert pg_downstream.lone_auroc(np.ones(len(y)), np.zeros(len(y))) is None


def test_an_inputs_file_held_for_some_rows_only_is_not_read_as_what_15298_adds(tmp_path):
    """15298's score is noise and every row has it; its one input is noise too and the inputs file holds only one
    kind of row, the kind with more fraud, which our score does not know. With the other rows left in, the trees
    would read which rows the file holds, and `flipped vs ours` would show that as what 15298 adds. The arms that
    read the inputs are fitted and read on the rows the file holds, and add nothing."""
    pytest.importorskip("xgboost")
    import pg_downstream
    rng = np.random.default_rng(13)

    def make(n, start):
        kind = rng.random(n) < 0.4
        evidence = rng.normal(size=n) * 1.5
        y = (rng.random(n) < 1 / (1 + np.exp(-(evidence + 2.5 * kind - 5.0)))).astype(int)
        ids = [f"{start}-{i}" for i in range(n)]
        df = pd.DataFrame({ID: ids, ACCOUNT: rng.integers(0, n // 8, n).astype(str), LABEL: y,
                           TIME: pd.Timestamp(start) + pd.to_timedelta(rng.integers(0, 86400 * 20, n), "s"),
                           "transaction_amt": rng.gamma(2, 50, n), "score": 1 / (1 + np.exp(-(evidence - 4.0)))})
        inc = pd.DataFrame({ID: ids, "score": 1 / (1 + np.exp(-rng.normal(size=n)))})
        return df, inc, pd.DataFrame({ID: ids, "f_noise": rng.normal(size=n)})[kind]

    tr, tr_inc, tr_f = make(60_000, "2025-03-01")
    rd, rd_inc, rd_f = make(60_000, "2025-06-01")
    for name, d in (("tr", tr), ("rd", rd), ("tr_inc", tr_inc), ("rd_inc", rd_inc), ("tr_f", tr_f), ("rd_f", rd_f)):
        d.to_parquet(tmp_path / f"{name}.parquet", index=False)
    out = tmp_path / "down.json"
    assert pg_downstream.main(["--train-export", str(tmp_path / "tr.parquet"), "--read-export",
                               str(tmp_path / "rd.parquet"), "--raw-cols", "transaction_amt", "--incumbent-train",
                               f"{tmp_path / 'tr_inc.parquet'}:score", "--incumbent-read",
                               f"{tmp_path / 'rd_inc.parquet'}:score", "--incumbent-features-train",
                               str(tmp_path / "tr_f.parquet"), "--incumbent-features-read",
                               str(tmp_path / "rd_f.parquet"), "--arms", "flipped", "offset", "--draws", "20",
                               "--out", str(out)]) == 0
    rec = json.loads(out.read_text())
    assert rec["fits"]["flipped"]["fit_rows"] == len(tr_f) and rec["points"]["flipped"]["rows_read"] == len(rd_f)
    assert rec["fits"]["offset"]["fit_rows"] == len(tr) and rec["points"]["offset"]["rows_read"] == len(rd)
    gain = {p["pair"]: p for p in rec["pairs"]}["flipped vs ours"]
    assert gain["rows"] == len(rd_f) and abs(gain["ap"]["gain"]) < 0.01
    said = [n for n in rec["notes"] if n.startswith("flipped: 15298's inputs file holds")]
    assert len(said) == 1 and f"{len(tr_f):,} of the {len(tr):,} training rows" in said[0]


def test_under_partial_coverage_every_row_gets_its_own_columns_and_the_two_weights_their_own_rows(tmp_path):
    """15298's scores and inputs exist for six rows in ten, in files laid out in another order than the exports,
    and a tenth of the rows have no score of ours. One input holds evidence that neither score has, so an arm that
    took the inputs of other rows would gain nothing. The joining arms are fitted and read on the rows that have
    both scores, the two weights are those of a separate fit on those rows, and the note counts them."""
    pytest.importorskip("xgboost")
    import pg_downstream
    paths, base = _two_model_files(tmp_path, 30_000, 22)
    rng = np.random.default_rng(1022)                    # not the world's seed: its first draws would be the world's
    both, kept = {}, {}
    for side in ("tr", "rd"):
        rows = pd.read_parquet(paths[side])
        rows.loc[rng.random(len(rows)) < 0.1, "score"] = np.nan
        rows.to_parquet(paths[side], index=False)
        inc, feats = pd.read_parquet(paths[f"{side}_inc"]), pd.read_parquet(paths[f"{side}_f"])[[ID, "f_0"]]
        feats["f_1"] = 1.5 * rows[LABEL].to_numpy() + rng.normal(size=len(rows))
        keep = rng.random(len(rows)) < 0.6
        order = rng.permutation(int(keep.sum()))
        inc[keep].iloc[order].to_parquet(paths[f"{side}_inc"], index=False)
        feats[keep].iloc[order[::-1]].to_parquet(paths[f"{side}_f"], index=False)
        both[side], kept[side] = keep & rows["score"].notna().to_numpy(), keep
    out = tmp_path / "down.json"
    assert pg_downstream.main(base + ["--incumbent-features-train", str(paths["tr_f"]), "--incumbent-features-read",
                                      str(paths["rd_f"]), "--arms", "offset", "offset_raw", "offset_open", "flipped",
                                      "two_weights", "joined", "--out", str(out)]) == 0
    rec = json.loads(out.read_text())
    for arm in ("offset", "offset_open", "flipped", "joined"):
        assert rec["fits"][arm]["fit_rows"] == int(both["tr"].sum()), arm
        assert rec["points"][arm]["rows_read"] == int(both["rd"].sum()), arm
    # offset_raw reads nothing of ours: every row with a 15298 score
    assert rec["fits"]["offset_raw"]["fit_rows"] == int(kept["tr"].sum())
    assert rec["points"]["offset_raw"]["rows_read"] == int(kept["rd"].sum())
    pairs = {p["pair"]: p for p in rec["pairs"]}
    assert set(pairs) == {"offset vs 15298", "offset vs offset_raw", "ours vs 15298", "offset vs ours",
                          "offset_open vs 15298", "offset_open vs ours", "flipped vs 15298", "flipped vs ours",
                          "two_weights vs 15298", "two_weights vs ours", "joined vs 15298", "joined vs ours",
                          "joined vs two_weights"}
    # with the inputs of other rows the gain is zero or below; with each row's own it is 0.15 to 0.2 at this size
    assert pairs["flipped vs ours"]["ap"]["gain"] > 0.08 and pairs["joined vs ours"]["ap"]["gain"] > 0.08
    assert pairs["flipped vs ours"]["rows"] == int(both["rd"].sum())
    # the table gives each arm's rows
    text = out.with_suffix(".txt").read_text()
    for arm in ("flipped", "offset_raw"):
        line = [row for row in text.splitlines() if row.startswith(f"{arm:<20}")]
        assert len(line) == 1 and line[0].endswith(f"{rec['points'][arm]['rows_read']:>12,}")
    # the two weights: fitted on the training rows with both scores, and equal to a separate fit on those rows
    fit = rec["fits"]["two_weights"]
    assert fit["fit_rows"] == int(both["tr"].sum())
    assert f"two weights, fitted on {int(both['tr'].sum()):,} training rows" in text
    rows = pd.read_parquet(paths["tr"]).merge(pd.read_parquet(paths["tr_inc"]).rename(columns={"score": "theirs"}),
                                              on=ID)
    rows = rows[rows["score"].notna()]
    assert len(rows) == int(both["tr"].sum())
    y = rows[LABEL].to_numpy(float)
    x = np.stack([np.ones(len(y)), pg_downstream.logit(rows["theirs"].to_numpy()),
                  pg_downstream.logit(rows["score"].to_numpy(), 1e-7)], 1)
    w = np.array([np.log(y.mean() / (1 - y.mean())), 0.0, 0.0])
    for _ in range(60):
        prob = 1 / (1 + np.exp(-(x @ w)))
        w = w - np.linalg.solve((x * (prob * (1 - prob))[:, None]).T @ x, x.T @ (prob - y))
    assert np.allclose([fit["constant"], fit["weight_15298"], fit["weight_ours"]], w, atol=2e-3)


def test_the_start_of_joined_is_the_two_weight_sum_of_each_row(tmp_path, monkeypatch):
    pytest.importorskip("xgboost")
    import xgboost
    import pg_downstream
    paths, base = _two_model_files(tmp_path, 8_000, 23)
    starts = []
    real_matrix = xgboost.DMatrix
    monkeypatch.setattr(xgboost, "DMatrix",
                        lambda *a, **k: (starts.append(k.get("base_margin")), real_matrix(*a, **k))[1])
    out = tmp_path / "down.json"
    assert pg_downstream.main(base + ["--arms", "two_weights", "joined", "--out", str(out)]) == 0
    fit = json.loads(out.read_text())["fits"]["two_weights"]
    rd, rd_inc = pd.read_parquet(paths["rd"]), pd.read_parquet(paths["rd_inc"])
    want = (fit["constant"] + fit["weight_15298"] * pg_downstream.logit(rd_inc["score"].to_numpy())
            + fit["weight_ours"] * pg_downstream.logit(rd["score"].to_numpy(), 1e-7))
    assert len(starts) == 3 and np.allclose(starts[2], want)          # the fit, the held-out tenth, the read


def test_15298_scores_are_read_as_probabilities_by_their_bulk(tmp_path):
    """One score written as -1 or as 1.0000001 does not turn every probability into a margin: it is no score, and
    the note counts it. Real margins are used as they are, without the line about points; a scale with a code
    below zero gets that line; --incumbent-scale says which where the tool would read it wrong."""
    pytest.importorskip("xgboost")
    import pg_downstream
    paths, base = _two_model_files(tmp_path, 20_000, 24)
    tr_inc, rd_inc = pd.read_parquet(paths["tr_inc"]), pd.read_parquet(paths["rd_inc"])

    def run(name, change, *more):
        for side, scores in (("tr", tr_inc), ("rd", rd_inc)):
            change(scores.copy()).to_parquet(tmp_path / f"{side}_{name}.parquet", index=False)
        args = [a.replace("tr_inc.parquet", f"tr_{name}.parquet").replace("rd_inc.parquet", f"rd_{name}.parquet")
                for a in base]
        out = tmp_path / f"{name}.json"
        assert pg_downstream.main(args + ["--arms", "offset", "two_weights", "--out", str(out), *more]) == 0
        return json.loads(out.read_text())

    def stray(scores):
        scores.loc[5, "score"], scores.loc[7, "score"] = -1.0, 1.0000001
        return scores

    clean, odd = run("clean", lambda scores: scores), run("odd", stray)
    assert clean["incumbent_scale"] == odd["incumbent_scale"] == "logit"
    assert odd["fits"]["offset"]["fit_rows"] == 20_000 - 2 and odd["points"]["offset"]["rows_read"] == 20_000 - 2
    # the fit without trees says it most plainly: two rows fewer, the same weights and the same read
    for key in ("weight_15298", "weight_ours", "constant"):
        assert abs(odd["fits"]["two_weights"][key] - clean["fits"]["two_weights"][key]) < 0.01, key
    assert abs(odd["points"]["two_weights"]["ap"] - clean["points"]["two_weights"]["ap"]) < 0.005
    assert abs(odd["points"]["15298"]["ap"] - clean["points"]["15298"]["ap"]) < 0.005
    assert abs(odd["points"]["offset"]["ap"] - clean["points"]["offset"]["ap"]) < 0.06
    assert sum("4 of 40,000 lie outside 0 to 1" in n for n in odd["notes"]) == 1
    assert not any("outside 0 to 1" in n or "as they are" in n for n in clean["notes"])

    def coded(scores):                                   # a fifth of the rows hold -1 for "no score"
        scores.loc[scores.index % 5 == 0, "score"] = -1.0
        return scores

    auto, share = run("coded", coded), run("coded", coded, "--incumbent-scale", "share")
    assert auto["incumbent_scale"] == "raw" and any("say --incumbent-scale share" in n for n in auto["notes"])
    assert share["incumbent_scale"] == "logit" and share["points"]["offset"]["rows_read"] == 16_000
    assert abs(share["fits"]["two_weights"]["weight_ours"] - clean["fits"]["two_weights"]["weight_ours"]) < 0.1
    assert auto["fits"]["two_weights"]["fit_rows"] == 20_000 and share["fits"]["two_weights"]["fit_rows"] == 16_000

    def margins(scores):
        return scores.assign(score=pg_downstream.logit(scores["score"].to_numpy()))

    real = run("margins", margins)
    assert real["incumbent_scale"] == "raw" and not any("points on a scale" in n for n in real["notes"])
    assert abs(real["points"]["offset"]["ap"] - clean["points"]["offset"]["ap"]) < 1e-6
    forced = run("clean", lambda scores: scores, "--incumbent-scale", "margin")
    assert forced["incumbent_scale"] == "raw" and any("--incumbent-scale margin" in n for n in forced["notes"])

    def points(scores):                                  # points from 0 to 999, with -1 for "no score"
        scores = scores.assign(score=np.round(scores["score"] * 999))
        scores.loc[scores.index % 100 == 0, "score"] = -1.0
        return scores

    assert any("points on a scale" in n for n in run("points", points)["notes"])
    # a short scale, 0 to 10: whole numbers are no margins either
    short = run("short", lambda scores: scores.assign(score=np.round(scores["score"] ** 0.2 * 10)))
    assert short["incumbent_scale"] == "raw" and any("points on a scale" in n for n in short["notes"])


def test_a_coded_field_is_the_same_code_whichever_number_type_its_column_came_in(tmp_path):
    """A coded raw field held as whole numbers is int64 where no value is missing and float64 where one is. As
    text those were 1 and 1.0, so that every code of the read rows was one the training rows never held, and the
    field was a missing value to the trees on the whole read."""
    pytest.importorskip("xgboost")
    import decimal
    import pg_downstream
    same = [pg_downstream.code_text(v) for v in (3, 3.0, np.int64(3), np.float32(3.0), decimal.Decimal("3"),
                                                 decimal.Decimal("3.0"), "3")]
    assert same == ["3"] * 7
    missing = (None, float("nan"), pd.NA, pd.NaT, decimal.Decimal("NaN"))
    assert [pg_downstream.code_text(v) for v in missing] == [None] * 5
    assert [pg_downstream.code_text(v) for v in (2.5, "03", "A", True, -7.0)] == ["2.5", "03", "A", "True", "-7"]
    texts = pg_downstream.code_texts(pd.Series([1.0, np.nan, 2.0, 1.0]))
    assert list(texts) == ["1", None, "2", "1"]
    rng = np.random.default_rng(25)

    def make(n, start):
        code = rng.integers(1, 5, n)
        y = (rng.random(n) < np.where(code == 3, 0.25, 0.01)).astype(int)
        return pd.DataFrame({ID: [f"{start}-{i}" for i in range(n)], ACCOUNT: rng.integers(0, n // 8, n).astype(str),
                             LABEL: y, TIME: pd.Timestamp(start) + pd.to_timedelta(rng.integers(0, 86400 * 20, n), "s"),
                             "transaction_amt": rng.gamma(2, 50, n), "score": rng.random(n),
                             "transaction_type_xcd": code})

    tr, rd = make(20_000, "2025-03-01"), make(15_000, "2025-06-01")
    tr.to_parquet(tmp_path / "tr.parquet", index=False)
    aps = {}
    for name in ("whole", "with_a_gap", "unseen"):
        read = rd.copy()
        if name == "with_a_gap":
            read["transaction_type_xcd"] = read["transaction_type_xcd"].astype(float)
            read.loc[0, "transaction_type_xcd"] = np.nan
            assert read["transaction_type_xcd"].dtype == np.float64 and tr["transaction_type_xcd"].dtype == np.int64
        if name == "unseen":
            read.loc[read.index % 10 == 0, "transaction_type_xcd"] = 9
        read.to_parquet(tmp_path / f"{name}.parquet", index=False)
        out = tmp_path / f"{name}.json"
        assert pg_downstream.main(["--train-export", str(tmp_path / "tr.parquet"), "--read-export",
                                   str(tmp_path / f"{name}.parquet"), "--raw-cols", "transaction_type_xcd",
                                   "--arms", "raw", "--draws", "5", "--out", str(out)]) == 0
        rec = json.loads(out.read_text())
        aps[name] = rec["points"]["raw"]["ap"]
        unseen = [n for n in rec["notes"] if "the training rows never held" in n]
        assert len(unseen) == (1 if name == "unseen" else 0)
        if unseen:
            assert unseen[0].startswith("transaction_type_xcd: 1,500 of the 15,000 read rows")
    assert aps["whole"] > 0.1 and abs(aps["with_a_gap"] - aps["whole"]) < 0.01


def test_a_score_that_is_one_value_on_every_training_row_gets_no_weight(tmp_path):
    """numpy's standard deviation of equal numbers is often 1e-16 and not 0; told by its range, the margin has no
    spread, no weights are fitted and the two arms that need them are left out with a line."""
    pytest.importorskip("xgboost")
    import pg_downstream
    paths, base = _two_model_files(tmp_path, 8_000, 26)
    for value in (0.001, 0.3, None):
        flat = pd.read_parquet(paths["tr_inc"]).assign(score=value or 0.25)
        if value is None:                                # one value up to its last digit
            flat["score"] = flat["score"] + np.where(flat.index % 2 == 0, 0.0, 5e-17)
        assert np.std(pg_downstream.logit(flat["score"].to_numpy())) != 0.0 or value != 0.001
        flat.to_parquet(tmp_path / "flat.parquet", index=False)
        args = [a.replace("tr_inc.parquet", "flat.parquet") for a in base]
        out = tmp_path / "down.json"
        assert pg_downstream.main(args + ["--arms", "two_weights", "joined", "offset", "--out", str(out)]) == 0
        rec = json.loads(out.read_text())
        assert "two_weights" not in rec["points"] and "joined" not in rec["points"] and "offset" in rec["points"]
        assert sum("no weight can be fitted" in n for n in rec["notes"]) == 1
        assert sum("skipped (the two weights could not be fitted)" in n for n in rec["notes"]) == 2
    w = pg_downstream.two_weights(np.r_[np.zeros(900), np.ones(100)], np.full(1000, pg_downstream.logit(0.3)),
                                  np.r_[np.linspace(-3, 1, 900), np.linspace(-1, 3, 100)])
    assert w[1] == 0.0 and np.isfinite(w).all() and w[2] > 0.5


def test_a_run_ends_with_its_record_in_the_smaller_cases_too(tmp_path):
    """A field named twice, fewer than two draws, an empty amount, an arm whose held-out tenth has no fraud, files
    whose ids look like numbers, numbers held as text or as decimals, a file without the id, an export with no
    June row."""
    pytest.importorskip("xgboost")
    import decimal
    import pg_downstream
    rng = np.random.default_rng(27)
    tr, tr_inc, tr_f, cal = _two_model_rows(rng, 8_000, "2025-03-01")
    rd, rd_inc, rd_f, _ = _two_model_rows(rng, 8_000, "2025-06-01", cal)
    padded = {}
    for name, rows in (("tr", tr), ("rd", rd)):
        padded[name] = [f"{i:07d}" for i in range(len(rows))]                      # ids such as 0000123
        rows[ID] = padded[name]
    rd.loc[rd.index[:40], TIME] = pd.Timestamp("2025-05-20")                       # forty rows of May
    rd["transaction_amt"] = rd["transaction_amt"].round(2).astype(str)
    rd.loc[rd.index[100], "transaction_amt"] = ""                                  # one empty amount
    for name, rows, inc, feats in (("tr", tr, tr_inc, tr_f), ("rd", rd, rd_inc, rd_f)):
        rows.to_parquet(tmp_path / f"{name}.parquet", index=False)
        inc.assign(**{ID: padded[name]}).to_csv(tmp_path / f"{name}_inc.csv", index=False)
        feats = feats.assign(**{ID: padded[name]}).drop(columns=["f_text"])
        feats["f_as_text"] = feats["f_1"].round(4).astype(str)
        feats["f_decimal"] = [decimal.Decimal(str(round(v, 3))) for v in feats["f_1"]]
        feats["f_day"] = pd.Timestamp("2025-01-01")
        feats.to_parquet(tmp_path / "tr_f.parquet", index=False) if name == "tr" else feats.to_csv(
            tmp_path / "rd_f.csv", index=False)                                    # the read side as a CSV file
        pd.DataFrame({ID: padded[name], "emb_0": rng.normal(size=len(rows))}).to_csv(tmp_path / f"{name}_pfm.csv",
                                                                                       index=False)
    base = ["--train-export", str(tmp_path / "tr.parquet"), "--read-export", str(tmp_path / "rd.parquet"),
            "--incumbent-train", f"{tmp_path / 'tr_inc.csv'}:score", "--incumbent-read",
            f"{tmp_path / 'rd_inc.csv'}:score"]
    out = tmp_path / "down.json"
    assert pg_downstream.main(base + ["--raw-cols", "transaction_amt", "transaction_amt", "--incumbent-features-train",
                                      str(tmp_path / "tr_f.parquet"), "--incumbent-features-read",
                                      str(tmp_path / "rd_f.csv"), "--pfm-train", str(tmp_path / "tr_pfm.csv"),
                                      "--pfm-read", str(tmp_path / "rd_pfm.csv"), "--arms", "raw+score", "flipped",
                                      "raw+pfm", "--draws", "1", "--out", str(out)]) == 0
    rec = json.loads(out.read_text())
    text = out.with_suffix(".txt").read_text()
    assert rec["read_rows"] == 8_000 - 40 and rec["fits"]["raw+score"]["column_names"] == ["transaction_amt", "score"]
    notes = " | ".join(rec["notes"])
    for said in ("training rows: 15298 scores for 8,000 of 8,000 rows",
                 "read rows: 15298 scores for 7,960 of 7,960 rows", "read rows: PFM embeddings for 7,960 of 7,960 rows",
                 "for 7,960 of 7,960 rows: f_0, f_1, f_as_text, f_decimal; left out, not numbers: f_day",
                 "VDR: read rows with no amount: 1; with a negative amount: 0."):
        assert said in notes, said
    assert rec["fits"]["flipped"]["columns"] == 6 and "[n/a]" in text and "flipped vs ours" in text
    # an arm whose held-out tenth holds no fraud cannot choose its number of trees: it is left out with a line
    _, held = pg_downstream.inner_split(tr[ACCOUNT].to_numpy())
    accounts = tr[ACCOUNT].to_numpy()
    assert not set(accounts[held]) & set(accounts[~held])                        # whole accounts are held out
    tr.loc[held, LABEL] = 0
    tr.to_parquet(tmp_path / "tr.parquet", index=False)
    assert pg_downstream.main(base + ["--raw-cols", "transaction_amt", "--arms", "raw+score", "two_weights", "--draws",
                                      "5", "--out", str(out)]) == 0
    rec = json.loads(out.read_text())
    assert "raw+score" not in rec["points"] and "two_weights" in rec["points"]
    assert sum("raw+score: skipped (the held-out tenth of its accounts" in n and "hold no fraud" in n
               for n in rec["notes"]) == 1
    # 15298's scores for one side only: the line names the side; weights by amount without an amount: a line
    tr.drop(columns=["transaction_amt"]).to_parquet(tmp_path / "bare.parquet", index=False)
    assert pg_downstream.main(["--train-export", str(tmp_path / "bare.parquet"), "--read-export",
                               str(tmp_path / "rd.parquet"), "--incumbent-train", f"{tmp_path / 'tr_inc.csv'}:score",
                               "--arms", "offset", "two_weights", "--amount-power", "0.5", "--draws", "2", "--out",
                               str(out)]) == 0
    rec = json.loads(out.read_text())
    assert sum("skipped (no 15298 scores given for the read rows)" in n for n in rec["notes"]) == 2
    assert sum("--amount-power: the training rows hold no transaction_amt" in n for n in rec["notes"]) == 1
    assert set(rec["points"]) == {"ours"}
    # the first score of an id held twice; a file without the id stops with a line of its own
    pd.DataFrame({ID: ["a", "a", "b"], "score": [0.2, 0.9, 0.5]}).to_parquet(tmp_path / "twice.parquet", index=False)
    assert pg_downstream.read_scores(f"{tmp_path / 'twice.parquet'}:score").to_dict() == {"a": 0.2, "b": 0.5}
    pd.DataFrame({"score": [0.2]}, index=pd.Index(["a"], name=ID)).reset_index(drop=True).to_parquet(
        tmp_path / "no_id.parquet", index=False)
    with pytest.raises(SystemExit, match=f"has no column {ID}"):
        pg_downstream.read_scores(f"{tmp_path / 'no_id.parquet'}:score")
    # an export with no June row stops before anything is fitted
    rd.assign(**{TIME: pd.Timestamp("2025-05-20")}).to_parquet(tmp_path / "may.parquet", index=False)
    with pytest.raises(SystemExit, match="holds no row from 2025-06-01 to 2025-07-01"):
        pg_downstream.main(["--train-export", str(tmp_path / "tr.parquet"), "--read-export",
                            str(tmp_path / "may.parquet"), "--raw-cols", "transaction_amt", "--arms", "raw+score",
                            "--out", str(out)])
