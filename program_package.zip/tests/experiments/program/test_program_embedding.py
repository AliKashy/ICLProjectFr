"""Export, derived columns, the embedding table, the downstream arms and the tuning search, on synthetic data.

Run: $PY -m pytest -q tests/experiments/program/test_program_embedding.py
"""
import json
import sys

import numpy as np
import pandas as pd
import pytest
import torch

from conftest import ACCOUNT, ID, LABEL, TIME

pg_layout = pytest.importorskip("pg_layout")
import pg_derive  # noqa: E402
import pg_store  # noqa: E402
import pg_sweep  # noqa: E402


@pytest.fixture
def trained(world):
    layout, mods = pg_layout.resolve(roles=("base_model", "trainer", "scorer"))
    if layout != "old":
        pytest.skip("runs on the old code layout")
    out = world["tmp"] / "run"
    mods["trainer"].main(["--config", str(world["cfg"]), f"output.checkpoint_dir={out}"])
    return world, mods, out / "best.ckpt"


def export_file(world, mods, ckpt, files, name):
    import pg_export
    out = world["tmp"] / f"{name}.parquet"
    rc = pg_export.main(["--checkpoint", str(ckpt), "--out", str(out), "--", "--config", str(world["cfg"]),
                         f"eval.base={world['data']}", f"eval.file_start={files[0]}", f"eval.file_end={files[1]}"])
    assert rc == 0
    return out


def test_export_matches_the_scorer_and_reproduces_the_score(trained):
    world, mods, ckpt = trained
    exp = pd.read_parquet(export_file(world, mods, ckpt, (3, 3), "exp3"))
    pred = world["tmp"] / "scored.parquet"
    mods["scorer"].main(["--population", "EPOCH_VAL", "--purpose", "test", "--config", str(world["cfg"]),
                         f"eval.base={world['data']}", "eval.file_start=3", "eval.file_end=3", "--checkpoint",
                         str(ckpt), "--out", str(pred)])
    sc = pd.read_parquet(pred)
    m = exp.merge(sc[[ID, "score"]], on=ID, suffixes=("", "_scorer"))
    assert len(m) == len(sc) == len(exp)
    assert np.allclose(m["score"], m["score_scorer"], atol=1e-6)
    assert np.allclose(exp["score"], exp["score_check"], atol=1e-5)
    vec = [c for c in exp.columns if c.startswith("e_")]
    assert len(vec) == 8 and exp[LABEL].isin([0, 1]).all() and TIME in exp
    assert pd.api.types.is_float_dtype(exp["transaction_amt"])  # the amount stays a number in the export


def brute_window(df, cols, days):
    out = np.full((len(df), len(cols)), np.nan)
    t = pd.to_datetime(df[TIME]).dt.floor("s")
    for i in range(len(df)):
        same = (df[ACCOUNT] == df[ACCOUNT].iloc[i]) & (t < t.iloc[i]) & (t >= t.iloc[i] - pd.Timedelta(days=days))
        if same.any():
            out[i] = df.loc[same, cols].to_numpy().mean(axis=0)
    return out


def test_windows_are_strictly_earlier_and_householder_hides_the_head(trained):
    world, mods, ckpt = trained
    exp_path = export_file(world, mods, ckpt, (8, 8), "exp8")
    pca = world["tmp"] / "pca.npz"
    assert pg_derive.main(["fit-pca", "--export", str(exp_path), "--out", str(pca)]) == 0
    der = world["tmp"] / "der.parquet"
    pg_derive.derive(str(exp_path), str(der), str(ckpt), str(pca), (1, 7), "vector")
    d = pd.read_parquet(der)
    exp = pd.read_parquet(exp_path)
    vec = [c for c in exp.columns if c.startswith("e_")]
    got = d[[f"w1d_{c}" for c in vec]].to_numpy()
    want = brute_window(exp, vec, 1)
    assert np.allclose(np.nan_to_num(got, nan=-9), np.nan_to_num(want, nan=-9), atol=1e-4)
    # the 47 (here 7) orthogonal coordinates carry nothing the head reads
    w = pg_derive.head_direction(str(ckpt))
    h = pg_derive.householder_basis(w)
    assert np.allclose(h @ h.T, np.eye(len(w)), atol=1e-10)
    o = d[[c for c in d.columns if c.startswith("o_")]].to_numpy(np.float64)
    recon = np.hstack([d[["head_coord"]].to_numpy(np.float64), o]) @ h
    assert np.allclose(recon, exp[vec].to_numpy(np.float64), atol=1e-4)
    assert np.allclose(recon @ (w / np.linalg.norm(w)), d["head_coord"], atol=1e-4)


def test_store_write_ids_and_point_in_time(tmp_path):
    t0 = pd.Timestamp("2025-06-01 10:00:00")
    exp = pd.DataFrame({ID: ["a1", "a2", "a3", "b1"], ACCOUNT: ["a", "a", "a", "b"],
                        TIME: [t0, t0 + pd.Timedelta(seconds=5), t0 + pd.Timedelta(seconds=5), t0],
                        "score": [0.1, 0.2, 0.3, 0.9], "e_0": [1.0, 2.0, 3.0, 4.0]})
    p = tmp_path / "exp.parquet"
    exp.to_parquet(p, index=False)
    pg_store.write(tmp_path / "store", "m", "v1", str(p))
    assert len(pg_store.by_ids(tmp_path / "store", "m", "v1", ["a2", "b1"])) == 2
    q = pd.DataFrame({ACCOUNT: ["a", "a", "b", "c"], TIME: [t0 + pd.Timedelta(seconds=5), t0 + pd.Timedelta(seconds=6),
                                                           t0, t0]})
    got = pg_store.as_of(tmp_path / "store", "m", "v1", q)
    assert got["e_0"].iloc[0] == 1.0  # the same second is never read: a1 is the latest strictly earlier row
    assert got["e_0"].iloc[1] in (2.0, 3.0)
    assert np.isnan(got["e_0"].iloc[2]) and np.isnan(got["e_0"].iloc[3])


def test_downstream_arms_and_offset(tmp_path):
    pytest.importorskip("xgboost")
    import pg_downstream
    rng = np.random.default_rng(5)

    def make(n, start):
        acc = rng.integers(0, 300, n).astype(str)
        y = (rng.random(n) < 0.05).astype(int)
        df = pd.DataFrame({ID: [f"{start}{i}" for i in range(n)], ACCOUNT: acc, LABEL: y,
                           TIME: pd.Timestamp(start) + pd.to_timedelta(rng.integers(0, 86400 * 20, n), "s"),
                           "transaction_amt": rng.gamma(2, 50, n), "score": 1 / (1 + np.exp(-(rng.normal(size=n) + 2 * y)))})
        for j in range(4):
            df[f"e_{j}"] = rng.normal(size=n) + (1.0 if j == 0 else 0.0) * y
        df["segment"] = rng.choice(["A", "B"], n)
        inc = pd.DataFrame({ID: df[ID], "score": 1 / (1 + np.exp(-(rng.normal(size=n) + 1.5 * y)))})
        return df, inc

    tr, tr_inc = make(4000, "2025-03-01")
    rd, rd_inc = make(3000, "2025-06-01")
    paths = {}
    for name, d in (("tr", tr), ("rd", rd), ("tr_inc", tr_inc), ("rd_inc", rd_inc)):
        paths[name] = tmp_path / f"{name}.parquet"
        d.to_parquet(paths[name], index=False)
    out = tmp_path / "down.json"
    rc = pg_downstream.main(["--train-export", str(paths["tr"]), "--read-export", str(paths["rd"]),
                             "--raw-cols", "segment", "transaction_amt", "--incumbent-train",
                             f"{paths['tr_inc']}:score", "--incumbent-read", f"{paths['rd_inc']}:score",
                             "--arms", "raw", "raw+score", "raw+score+vector", "offset", "offset_raw",
                             "--draws", "50", "--out", str(out)])
    assert rc == 0
    rec = json.loads(out.read_text())
    assert {"raw", "raw+score", "raw+score+vector", "offset", "offset_raw", "15298", "ours"} <= set(rec["points"])
    assert any(p["pair"] == "offset vs 15298" for p in rec["pairs"])


def test_sweep_drop_rule_pilot_replay_and_resume(tmp_path, monkeypatch):
    """The search with a stand-in trainer: each run writes training_metrics.csv from its learning rate."""
    calls = []

    def runner(cmd):
        calls.append(cmd)
        out = [c.split("=", 1)[1] for c in cmd if c.startswith("output.checkpoint_dir=")][0]
        lr = float([c.split("=", 1)[1] for c in cmd if c.startswith("training.learning_rate=")][0])
        epochs = int([c.split("=", 1)[1] for c in cmd if c.startswith("training.max_epochs=")][0])
        import os
        os.makedirs(out, exist_ok=True)
        good = 0.10 - 30 * abs(np.log10(lr) - np.log10(3e-4)) ** 2 * 0.01
        with open(os.path.join(out, "training_metrics.csv"), "w") as f:
            f.write("epoch,step,valid_ap\n")
            for e in range(epochs):
                f.write(f"{e},{e * 10},{good - 0.01 / (e + 1):.6f}\n")
        open(os.path.join(out, "last.ckpt"), "w").close()
        return 0

    class A:
        study_dir, trials, current_lr, train_options, seed = str(tmp_path / "sweep"), 12, 3e-4, "", 42
    assert pg_sweep.run(A, ["--config", "cfg.yaml"], runner) == 0
    st = json.loads((tmp_path / "sweep" / "trials.json").read_text())
    assert len(st["trials"]) == 12 and st["pilot_replay"] is not None
    assert st["trials"][0]["params"]["learning_rate"] == pytest.approx(3e-4)
    assert all(t["status"] in ("done", "pruned") for t in st["trials"])
    resumed = [c for c in calls if "--resume" in c]
    assert resumed and all("training.max_epochs=10" in c for c in resumed)
    n = len(calls)
    assert pg_sweep.run(A, ["--config", "cfg.yaml"], runner) == 0  # nothing left to do
    assert len(calls) == n


def test_sweep_without_optuna_draws_at_random(tmp_path, monkeypatch):
    import builtins
    real_import = builtins.__import__

    def no_optuna(name, *args, **kwargs):
        if name == "optuna":
            raise ImportError("no optuna")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", no_optuna)

    def runner(cmd):
        import os
        out = [c.split("=", 1)[1] for c in cmd if c.startswith("output.checkpoint_dir=")][0]
        epochs = int([c.split("=", 1)[1] for c in cmd if c.startswith("training.max_epochs=")][0])
        os.makedirs(out, exist_ok=True)
        with open(os.path.join(out, "training_metrics.csv"), "w") as f:
            f.write("epoch,step,valid_ap\n" + "".join(f"{e},{e},{0.05 + 0.001 * e}\n" for e in range(epochs)))
        return 0

    class A:
        study_dir, trials, current_lr, train_options, seed = str(tmp_path / "s"), 5, 3e-4, "", 1
    assert pg_sweep.run(A, ["--config", "c.yaml"], runner) == 0
    st = json.loads((tmp_path / "s" / "trials.json").read_text())
    assert len({t["params"]["learning_rate"] for t in st["trials"]}) == 5


def test_diagnostics_rank_cka_align_and_probe(tmp_path):
    import pg_diagnostics as D
    rng = np.random.default_rng(2)
    n, accounts = 3000, 200
    acc = rng.integers(0, accounts, n).astype(str)
    t = pd.Timestamp("2025-05-20") + pd.to_timedelta(rng.integers(0, 86400 * 40, n), "s")
    y = (rng.random(n) < 0.03).astype(int)
    x = rng.normal(size=(n, 6))
    a = pd.DataFrame({ID: [f"t{i}" for i in range(n)], ACCOUNT: acc, TIME: t, LABEL: y, "score": rng.random(n)})
    for j in range(6):
        a[f"e_{j}"] = x[:, j]
    rot = np.linalg.qr(rng.normal(size=(6, 6)))[0]
    b = a.copy()
    for j in range(6):
        b[f"e_{j}"] = (x @ rot)[:, j]
    pa_, pb = tmp_path / "a.parquet", tmp_path / "b.parquet"
    a.to_parquet(pa_, index=False)
    b.to_parquet(pb, index=False)
    r = D.rank_readings(a, [f"e_{j}" for j in range(6)], draws=10)
    assert 5.0 < r["all rows"]["rank"] <= 6.0
    c = D.cka(str(pa_), str(pb), draws=10)
    assert c["cka"] == pytest.approx(1.0, abs=1e-6) and c["shuffled_rows_mean"] < 0.1  # a rotation keeps CKA at 1
    al = D.align(str(pa_), str(pb), str(tmp_path / "aligned.parquet"))
    assert al["held_out_r2"] > 0.999
    got = pd.read_parquet(tmp_path / "aligned.parquet")
    assert np.allclose(got[[f"e_{j}" for j in range(6)]].to_numpy(), x, atol=1e-4)
    out = D.probe(str(pa_), draws=10)
    assert all("ap" in v for v in out.values())


def test_sweep_restart_proposes_like_an_uninterrupted_search_and_replays_pilots_after_a_failure(tmp_path):
    pytest.importorskip("optuna")

    def runner_for(fail=()):
        def runner(cmd):
            import os
            out = [c.split("=", 1)[1] for c in cmd if c.startswith("output.checkpoint_dir=")][0]
            if any(out.endswith(f"trial_{k}") for k in fail):
                return 1
            epochs = int([c.split("=", 1)[1] for c in cmd if c.startswith("training.max_epochs=")][0])
            os.makedirs(out, exist_ok=True)
            with open(os.path.join(out, "training_metrics.csv"), "w") as f:
                f.write("epoch,step,valid_ap\n" + "".join(f"{e},{e},{0.05 + 0.001 * e}\n" for e in range(epochs)))
            return 0
        return runner

    class A:
        study_dir, trials, current_lr, train_options, seed = str(tmp_path / "straight"), 6, 3e-4, "", 7
    pg_sweep.run(A, ["--config", "c.yaml"], runner_for())
    straight = [t["params"] for t in json.loads((tmp_path / "straight" / "trials.json").read_text())["trials"]]

    class B(A):
        study_dir, trials = str(tmp_path / "cut"), 3
    pg_sweep.run(B, ["--config", "c.yaml"], runner_for())
    B.trials = 6
    pg_sweep.run(B, ["--config", "c.yaml"], runner_for())
    cut = [t["params"] for t in json.loads((tmp_path / "cut" / "trials.json").read_text())["trials"]]
    assert cut == straight  # a restart proposes exactly what an uninterrupted search proposes

    class C(A):
        study_dir, trials = str(tmp_path / "fail3"), 5
    pg_sweep.run(C, ["--config", "c.yaml"], runner_for(fail=(3,)))
    st = json.loads((tmp_path / "fail3" / "trials.json").read_text())
    assert st["trials"][3]["status"] == "failed" and st["pilot_replay"] is not None


def test_long_windows_stay_inside_their_account():
    t = pd.to_datetime(["2025-03-01", "2025-05-30", "2025-01-01"])
    means, counts = pg_derive.window_means(np.array(["a", "a", "b"]), t, np.array([[100.0], [5.0], [200.0]]),
                                           days=(30, 60, 90))
    assert counts[2].tolist() == [0, 0, 0]  # b's only row sees nothing, however long the window
    assert counts[1].tolist() == [0, 0, 1] and means[1, 2, 0] == 100.0  # a's earlier row is 90 days back


def test_store_keys_times_and_no_label(tmp_path, capsys):
    t0 = pd.Timestamp("2025-06-01 10:00:00")
    exp = pd.DataFrame({ID: ["a1", "a2"], ACCOUNT: [37389549.0, 37389549.0], LABEL: [1, 0],
                        TIME: [t0, t0 + pd.Timedelta(seconds=5)], "score": [0.9, 0.1], "e_0": [1.0, 2.0]})
    p = tmp_path / "exp.parquet"
    exp.to_parquet(p, index=False)
    pg_store.write(tmp_path / "store", "m", "v1", str(p), checkpoint="run_a/best.ckpt")
    pg_store.write(tmp_path / "store", "m", "v1", str(p), checkpoint="run_b/best.ckpt")
    assert "different space" in capsys.readouterr().out
    q = pd.DataFrame({ACCOUNT: ["37389549", 37389549],
                      TIME: pd.to_datetime(["2025-06-01T10:00:09Z", "2025-06-01T10:00:05Z"]).astype("datetime64[us, UTC]")})
    got = pg_store.as_of(tmp_path / "store", "m", "v1", q)
    assert got["e_0"].tolist() == [2.0, 1.0] and LABEL not in got  # strictly earlier, never the label
    with pytest.raises(SystemExit):
        pg_store.write("s3://bucket/store", "m", "v1", str(p))


def test_downstream_with_partial_15298_coverage_typed_amounts_and_the_right_files(tmp_path):
    pytest.importorskip("xgboost")
    import pg_downstream
    rng = np.random.default_rng(9)

    def make(n, start, files_dir, number):
        acc = rng.integers(0, 300, n).astype(str)
        y = (rng.random(n) < 0.05).astype(int)
        ids = [f"{start}{i}" for i in range(n)]
        df = pd.DataFrame({ID: ids, ACCOUNT: acc, LABEL: y, "score": 1 / (1 + np.exp(-(rng.normal(size=n) + 2 * y))),
                           TIME: pd.Timestamp(start) + pd.to_timedelta(rng.integers(0, 86400 * 20, n), "s"),
                           "transaction_amt": [str(round(v, 2)) for v in rng.gamma(2, 50, n)]})  # text, as metadata
        for j in range(4):
            df[f"e_{j}"] = rng.normal(size=n) + (1.0 if j == 0 else 0.0) * y
        files_dir.mkdir(exist_ok=True)
        pd.DataFrame({ID: ids, "transaction_amt": df["transaction_amt"].astype(float),
                      "segment": rng.choice(["A", "B"], n)}).to_parquet(files_dir / f"part_{number}.parquet", index=False)
        inc = pd.DataFrame({ID: ids, "score": 1 / (1 + np.exp(-(rng.normal(size=n) + 1.5 * y)))}).iloc[: int(n * 0.7)]
        return df, inc

    raw = tmp_path / "raw"
    tr, tr_inc = make(4000, "2025-03-01", raw, 1)
    rd, rd_inc = make(3000, "2025-06-01", raw, 2)
    paths = {}
    for name, d in (("tr", tr), ("rd", rd), ("tr_inc", tr_inc), ("rd_inc", rd_inc)):
        paths[name] = tmp_path / f"{name}.parquet"
        d.to_parquet(paths[name], index=False)
    base = ["--train-export", str(paths["tr"]), "--read-export", str(paths["rd"]), "--train-raw-base", str(raw),
            "--read-raw-base", str(raw), "--raw-cols", "segment", "transaction_amt", "--draws", "30"]
    out = tmp_path / "down.json"
    assert pg_downstream.main(base + ["--train-files", "1", "1", "--read-files", "2", "2", "--incumbent-train",
                                      f"{paths['tr_inc']}:score", "--incumbent-read", f"{paths['rd_inc']}:score",
                                      "--arms", "raw", "raw+score", "offset", "offset_raw", "--out", str(out)]) == 0
    rec = json.loads(out.read_text())
    assert rec["fits"]["offset"]["best_iteration"] > 0  # the covered rows train real trees
    pair = [p for p in rec["pairs"] if p["pair"] == "offset vs 15298"][0]
    assert pair["rows"] == rec["points"]["15298"]["rows_read"] < rec["read_rows"]
    with pytest.raises(SystemExit, match="not in the raw files"):
        pg_downstream.main(base + ["--train-files", "1", "1", "--read-files", "1", "1", "--arms", "raw",
                                   "--out", str(tmp_path / "x.json")])


def test_probe_reads_the_other_file(tmp_path):
    import pg_diagnostics as D
    rng = np.random.default_rng(4)
    n = 2000
    a = pd.DataFrame({ID: [f"t{i}" for i in range(n)], ACCOUNT: rng.integers(0, 100, n).astype(str),
                      TIME: pd.Timestamp("2025-06-01") + pd.to_timedelta(rng.integers(0, 86400 * 29, n), "s"),
                      LABEL: (rng.random(n) < 0.05).astype(int), "score": rng.random(n)})
    for j in range(3):
        a[f"e_{j}"] = rng.normal(size=n)
    other = pd.DataFrame({ID: a[ID], "emb_0": rng.normal(size=n), "emb_1": rng.normal(size=n)})
    a.to_parquet(tmp_path / "a.parquet", index=False)
    other.to_parquet(tmp_path / "o.parquet", index=False)
    out = D.probe(str(tmp_path / "a.parquet"), other=str(tmp_path / "o.parquet"), other_prefix="emb_", draws=5)
    assert any(k.startswith("other |") for k in out) and not any("47 hidden" in k for k in out)
