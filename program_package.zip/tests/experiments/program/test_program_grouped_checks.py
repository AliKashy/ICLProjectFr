"""The safeguards of grouped windows (pg_score.py --group-windows and --mark-scored-rows), on the old layout, CPU
only. Each safeguard works by behaviour: rows are scored and their scores compared.

- The built-in comparison: a scorer whose selecting function, window rule or gap rule is not the checkout's, or
  that keeps its own reference to the function that hands inputs to the model, ends with the scorer's own scores
  and one line.
- The mark: its calls are counted, and a mark that does not reach the model is said in one line.
- The check of the output: it joins on ids, so an output in another order passes, and an output with a row
  missing, with scores on the wrong rows or without a column it needs is renamed and the exit code is 4.
- The grouped selection keeps the logits' number type; the grouped builder refuses a window wider than
  max_chunk_rows as the project's builder does.

Run: $PY -m pytest -q tests/experiments/program/test_program_grouped_checks.py
"""
import json
import sys
import types
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import torch

from conftest import ACCOUNT, ID, LABEL, TIME

pg_layout = pytest.importorskip("pg_layout")
import pg_score  # noqa: E402
from test_program_grouped import mods, same_output, score, setup, shapes  # noqa: E402,F401 (fixtures)

FALLBACK_LINE = "the built-in comparison did not pass"


def scorer_copy(monkeypatch, mods, name, replacements=(), extra=""):
    """A copy of the project's scorer, with text replaced and code added, registered under its own module name and
    put in the layout's place of the scorer for this test: a scorer that is not exactly the checkout's."""
    path = Path(mods["scorer"].__file__)
    text = path.read_text()
    for old, new in replacements:
        assert old in text, old  # the copy must really differ, or the test would prove nothing
        text = text.replace(old, new)
    text = text.replace('if __name__ == "__main__":', extra + '\nif __name__ == "__main__":')
    module = types.ModuleType(name)
    module.__file__ = str(path)
    monkeypatch.setitem(sys.modules, name, module)
    exec(compile(text, f"<{name}>", "exec"), module.__dict__)
    monkeypatch.setitem(pg_layout.NAMES["old"], "scorer", name)
    return module


def receipt(path):
    return json.loads(Path(f"{path}.json").read_text())


# a scorer whose window leaves out the earlier rows of the row's own second
OTHER_WINDOW_RULE = '''
from waqas.v2.target_ending import window_bounds as _bounds


class OtherRuleBuilder(TargetEndingBuilder):
    def window_rows(self, seconds, order_key):
        lo, _ = _bounds(seconds, order_key, self.history_len, self.max_window_rows)
        n = len(seconds)
        second_start = np.maximum.accumulate(np.where(np.r_[True, seconds[1:] != seconds[:-1]], np.arange(n), 0))
        return [np.r_[np.arange(lo[p], second_start[p]), p] for p in range(n)]


TargetEndingBuilder = OtherRuleBuilder
'''

# a scorer whose gap input is half the project's
OTHER_GAP_RULE = '''
class OtherGapBuilder(TargetEndingBuilder):
    def _chunks_for_file(self, *args):
        for item in super()._chunks_for_file(*args):
            item[0][:, -1] *= 0.5
            yield item


TargetEndingBuilder = OtherGapBuilder
'''

OTHER_SCORERS = {
    "select": ([("return target_slot_predictions(logits, batch) if chunk",
                 "return target_slot_predictions(logits / 2.0, batch) if chunk")], ""),
    "window_rule": ([], OTHER_WINDOW_RULE),
    "gap_rule": ([], OTHER_GAP_RULE),
}


@pytest.mark.parametrize("kind", list(OTHER_SCORERS))
def test_another_scorer_ends_with_its_own_scores(shapes, mods, monkeypatch, capsys, kind):
    """A scorer whose selecting function, window rule or gap rule is not the checkout's: the grouped run would write
    other scores, so the built-in comparison does not pass, one line says so, and the output is the scorer's own,
    bit for bit, with exit code 0 and the reason in the receipt."""
    replacements, extra = OTHER_SCORERS[kind]
    scorer_copy(monkeypatch, mods, f"other_scorer_{kind}", replacements, extra)
    cfg_path, ckpt = setup(shapes, mods, 5, None)
    plain, grouped = shapes["tmp"] / f"{kind}_plain.parquet", shapes["tmp"] / f"{kind}_grouped.parquet"
    assert score(shapes, cfg_path, ckpt, plain) == 0
    capsys.readouterr()
    assert score(shapes, cfg_path, ckpt, grouped, (20, 20), "--group-windows") == 0
    assert FALLBACK_LINE in capsys.readouterr().out
    assert same_output(plain, grouped) == 0.0  # the scorer's own scores
    entry = receipt(grouped)["grouped_windows"]
    assert entry["grouped"] is False and "built-in comparison" in entry["not_grouped_because"]
    comparison = entry["built_in_comparison"]
    assert comparison["passed"] is False and comparison["rows"] > 0
    if kind == "window_rule":
        # the ids agree; the scores or the window sizes do not
        assert "differs" in comparison["reason"] or "window_rows" in comparison["reason"]
    else:
        assert comparison["max_score_difference"] > pg_score.COMPARE_LIMIT  # the change was big enough to matter


def garbage_unless_marked(original, seen):
    """A model with an added step: real rows that are not marked get garbage logits, and with no mark it takes the
    last real row of every window as the marked one."""

    def forward(self, batch):
        out = original(self, batch).clone()
        mask = batch["mask"].to(torch.bool)
        seen.append(pg_score.SCORED in batch)
        marked = batch[pg_score.SCORED].to(torch.bool) if pg_score.SCORED in batch else pg_score.last_real_row(mask)
        junk = mask & ~marked
        out[..., 1] = torch.where(junk, torch.full_like(out[..., 1], 37.0), out[..., 1])
        out[..., 0] = torch.where(junk, torch.full_like(out[..., 0], -37.0), out[..., 0])
        return out

    return forward


def test_a_scorer_with_its_own_input_function(shapes, mods, monkeypatch, capsys):
    """A scorer that keeps its own reference to the function that hands inputs to the model, with a model that
    returns garbage on unmarked rows: no mark reaches the model. The grouped run ends with the scorer's own scores
    and the comparison's line; --mark-scored-rows alone says in one line that the mark did not reach the model and
    writes both counts into the receipt."""
    scorer_copy(monkeypatch, mods, "own_inputs_scorer", [
        ("def _score(args, cfg, run, metrics_path, exposure):",
         "def _score(args, cfg, run, metrics_path, exposure, _model_inputs=_model_inputs):")])
    model_cls = mods["base_model"].FTTransformerHierModel
    seen = []
    monkeypatch.setattr(model_cls, "forward", garbage_unless_marked(model_cls.forward, seen))
    cfg_path, ckpt = setup(shapes, mods, 5, None)
    t = shapes["tmp"]
    plain, grouped, marked = t / "own_plain.parquet", t / "own_grouped.parquet", t / "own_marked.parquet"
    assert score(shapes, cfg_path, ckpt, plain) == 0
    capsys.readouterr()
    assert score(shapes, cfg_path, ckpt, grouped, (20, 20), "--group-windows") == 0
    text = capsys.readouterr().out
    assert FALLBACK_LINE in text
    assert same_output(plain, grouped) == 0.0
    entry = receipt(grouped)["grouped_windows"]
    assert entry["grouped"] is False
    assert entry["built_in_comparison"]["sample_calls_with_mark"] == 0  # the grouped sample never got the mark
    assert entry["built_in_comparison"]["max_score_difference"] > 0.1
    seen.clear()
    assert score(shapes, cfg_path, ckpt, marked, (20, 20), "--mark-scored-rows") == 0
    assert "the mark reached 0 of" in capsys.readouterr().out
    counts = receipt(marked)["scored_mark"]
    assert counts["meant"] and counts["model_calls"] == len(seen) > 0 and counts["calls_with_mark"] == 0
    assert same_output(plain, marked) == 0.0  # the model takes the last real row: the scores are right


def test_the_checkout_scorer_counts_every_mark(shapes, mods):
    """With the checkout's scorer the mark reaches every call, grouped and with --mark-scored-rows, and no line is
    printed about it."""
    cfg_path, ckpt = setup(shapes, mods, 5, None)
    t = shapes["tmp"]
    for name, option in (("count_grouped", "--group-windows"), ("count_marked", "--mark-scored-rows")):
        assert score(shapes, cfg_path, ckpt, t / f"{name}.parquet", (20, 20), option) == 0
        counts = receipt(t / f"{name}.parquet")["scored_mark"]
        assert counts["meant"] and counts["model_calls"] == counts["calls_with_mark"] > 0
    entry = receipt(t / "count_grouped.parquet")["grouped_windows"]
    assert entry["grouped"] and entry["output_checked"] and entry["built_in_comparison"]["passed"]
    assert entry["built_in_comparison"]["max_score_difference"] <= 1e-6


def test_an_output_in_another_order_passes(shapes, mods, monkeypatch):
    """A scorer that writes each batch's rows in reverse (every column together): the rows are right, only their
    order differs, so the comparison and the check both pass, joined on the ids."""
    sel = "        prob, y, m = select(logits, batch, chunk)\n"
    width = '        widths.append(batch["mask"].sum(1).numpy())\n'
    natural = "        naturals.append(natural_rows(batch, chunk))\n"
    scorer_copy(monkeypatch, mods, "reversed_scorer", [
        (sel, sel + "        prob, y, m = prob[::-1].copy(), y[::-1].copy(), "
                    "{k: np.asarray(v)[::-1] for k, v in m.items()}\n"),
        (width, '        widths.append(batch["mask"].sum(1).numpy()[::-1].copy())\n'),
        (natural, "        naturals.append(natural_rows(batch, chunk)[::-1].copy())\n")])
    cfg_path, ckpt = setup(shapes, mods, 5, None)
    plain, grouped = shapes["tmp"] / "rev_plain.parquet", shapes["tmp"] / "rev_grouped.parquet"
    assert score(shapes, cfg_path, ckpt, plain) == 0
    assert score(shapes, cfg_path, ckpt, grouped, (20, 20), "--group-windows") == 0
    entry = receipt(grouped)["grouped_windows"]
    assert entry["grouped"] and entry["output_checked"]
    a = pd.read_parquet(plain).sort_values(ID, ignore_index=True)
    b = pd.read_parquet(grouped).sort_values(ID, ignore_index=True)
    pd.testing.assert_frame_equal(a.drop(columns="score"), b.drop(columns="score"))
    assert np.abs(a["score"] - b["score"]).max() <= 1e-6
    assert not pd.read_parquet(plain)[ID].equals(pd.read_parquet(grouped)[ID])  # the order did differ


def test_an_output_with_a_row_missing_is_not_used(shapes, mods, monkeypatch, capsys):
    """The grouped builder leaves out one window of the second file (the sample comes from the first, so the
    comparison passes): the check counts the rows the builder read, finds rows missing, renames the output and the
    exit code is 4."""
    real = pg_score.grouped_builder_class

    def skipping(base, bounds):
        cls = real(base, bounds)

        class Skipping(cls):
            def _chunks_for_file(self, *args):
                skipped = False
                for item in cls._chunks_for_file(self, *args):
                    ids = item[4][ID]
                    if not skipped and str(ids[0]).startswith("g21"):
                        skipped = True  # one window of the second file is never scored
                        continue
                    yield item

        return Skipping

    monkeypatch.setattr(pg_score, "grouped_builder_class", skipping)
    cfg_path, ckpt = setup(shapes, mods, 5, None)
    out = shapes["tmp"] / "miss.parquet"
    capsys.readouterr()
    assert score(shapes, cfg_path, ckpt, out, (20, 21), "--group-windows") == 4
    assert "output failed its check" in capsys.readouterr().err
    assert not out.exists() and Path(f"{out}.not_checked").exists()
    entry = receipt(out)["grouped_windows"]
    assert entry["built_in_comparison"]["passed"] and entry["output_checked"] is False
    assert "rows" in entry["check_failed_because"]


def test_an_output_with_scores_on_the_wrong_rows_is_not_used(shapes, mods, monkeypatch):
    """The full run (not the sample) puts each batch's scores on the wrong rows: the scores of the sample's rows no
    longer match the scorer's own scores of them, so the output is renamed and the exit code is 4."""
    real = pg_score.grouped_select
    made = []

    def swapping(original):
        select = real(original)
        made.append(1)
        if len(made) == 1:
            return select  # the sample's grouped run is left alone, so the comparison passes

        def wrong(logits, batch, chunk):
            prob, y, meta = select(logits, batch, chunk)
            return prob[::-1].copy(), y, meta  # the scores only, so they sit on other rows

        return wrong

    monkeypatch.setattr(pg_score, "grouped_select", swapping)
    cfg_path, ckpt = setup(shapes, mods, 5, None)
    out = shapes["tmp"] / "swap.parquet"
    assert score(shapes, cfg_path, ckpt, out, (20, 20), "--group-windows") == 4
    assert Path(f"{out}.not_checked").exists()
    entry = receipt(out)["grouped_windows"]
    assert entry["built_in_comparison"]["passed"] and "scores" in entry["check_failed_because"]


def test_an_output_without_a_column_is_a_failed_check(shapes, mods, monkeypatch):
    """A scorer that writes window_rows under another name: the check cannot be made, which is a failed check with
    its reason in the receipt, not a traceback."""
    scorer_copy(monkeypatch, mods, "renamed_column_scorer",
                [('out["window_rows"] = window_rows', 'out["rows_in_window"] = window_rows')])
    cfg_path, ckpt = setup(shapes, mods, 5, None)
    out = shapes["tmp"] / "nocol.parquet"
    assert score(shapes, cfg_path, ckpt, out, (20, 20), "--group-windows") == 4
    assert not out.exists() and Path(f"{out}.not_checked").exists()
    assert "no column window_rows" in receipt(out)["grouped_windows"]["check_failed_because"]


def test_the_check_joins_on_ids(tmp_path):
    """check_output on its own: another order passes; a row missing, a row twice, a wrong window size, scores on
    the wrong rows and a missing column each fail with their reason."""
    import pyarrow as pa
    import pyarrow.parquet as pq
    read = pd.DataFrame({ID: ["a", "b", "c", "d"], "_own": [1, 2, 3, 1], "_natural": [1, 2, 3, 1]})
    good = pd.DataFrame({ID: ["a", "b", "c", "d"], "window_rows": [1, 2, 3, 1], "score": [0.1, 0.2, 0.3, 0.4]})
    reference = good[[ID, "score"]].iloc[:3]

    def check(frame):
        path = tmp_path / f"o{len(list(tmp_path.iterdir()))}.parquet"
        pq.write_table(pa.Table.from_pandas(frame, preserve_index=False), path)
        return pg_score.check_output(str(path), read, [ID], reference)

    assert check(good) == (True, None)
    assert check(good.iloc[::-1]) == (True, None)  # another order
    ok, why = check(good.iloc[:3])
    assert not ok and "3 rows" in why  # a row missing
    ok, why = check(pd.concat([good.iloc[:3], good.iloc[[0]]]))
    assert not ok and "more than once" in why
    ok, why = check(good.assign(window_rows=[1, 2, 2, 1]))
    assert not ok and "window_rows" in why
    ok, why = check(good.assign(score=[0.2, 0.1, 0.3, 0.4]))
    assert not ok and "scores" in why  # scores on the wrong rows
    ok, why = check(good.drop(columns="window_rows"))
    assert not ok and why == "the output has no column window_rows"
    ok, why = pg_score.check_output(str(tmp_path / "none.parquet"), read, [ID])
    assert not ok and "not written" in why


def test_own_window_sizes_follow_the_project_rule(shapes, mods):
    """The check's own working-out of each row's window size equals the project's window_bounds on the shaped
    accounts, in any row order, with and without a cap."""
    window_bounds = mods["target_ending_data"].window_bounds
    df = shapes["shaped"][20]
    times = pd.to_datetime(df[TIME], utc=True)
    key = times.to_numpy(dtype="datetime64[ns]").astype("int64")
    second = times.to_numpy(dtype="datetime64[s]").astype("int64")
    shuffled = np.random.default_rng(0).permutation(len(df))
    for history, cap in ((5, None), (120, None), (5, 4), (0, None), (1, 2)):
        expected = np.zeros(len(df), np.int64)
        d = pd.DataFrame({"a": df[ACCOUNT], "k": key, "s": second, "i": df[ID]}).sort_values(["a", "k", "i"])
        for _, g in d.groupby("a", sort=False):
            lo, gs = window_bounds(g["s"].to_numpy(), g["k"].to_numpy(), history, cap)
            expected[g.index.to_numpy()] = gs - lo + 1
        got = pg_score.own_window_sizes(df[ACCOUNT].to_numpy()[shuffled], key[shuffled], second[shuffled], history,
                                        cap)
        assert np.array_equal(got, expected[shuffled]), (history, cap)


def test_the_sample_takes_busy_accounts_and_accounts_with_history():
    """The sample: the busiest accounts that fit in their share, then accounts with two rows or more from the start
    of the file, then one-row accounts, until it holds about the budget."""
    accounts = ["a", "b", "c", "d", "e", "f", "g"]
    rows = [1, 3, 400, 900, 2, 50, 1]
    chosen, total, busy = pg_score.sample_accounts(accounts, rows, budget=1000, busy=2, busy_share=0.5)
    assert chosen[:2] == ["c", "f"] and busy == 2  # d (900) does not fit in half the budget
    # then rows with history in file order (d would pass the budget and is passed over), then one-row accounts
    assert chosen[2:] == ["b", "e", "a", "g"] and total == 457
    chosen, total, busy = pg_score.sample_accounts(accounts, rows, budget=470, busy=1, busy_share=0.9)
    assert chosen == ["c", "b", "e", "f", "a", "g"] and total == 457 and busy == 1
    chosen, total, _ = pg_score.sample_accounts(["x", "y"], [1, 1], budget=10)
    assert chosen == ["x", "y"] and total == 2  # one-row accounts when nothing else is there


def test_the_sample_arguments():
    """The sample's scorer arguments: every form of --out and --metrics is replaced, the overrides stay one group."""
    argv = ["--config", "c.yaml", "--out=o.parquet", "--metr", "m.json", "--purpose", "p", "x=1", "y=2"]
    got = pg_score.with_options(argv, {"--out": "s.parquet", "--metrics": "s.json"})
    assert got == ["--out", "s.parquet", "--metrics", "s.json", "--config", "c.yaml", "--purpose", "p", "x=1", "y=2"]
    assert pg_score.with_override(got, "eval.base=z")[-3:] == ["x=1", "y=2", "eval.base=z"]


def test_the_grouped_selection_keeps_the_number_type():
    """The grouped selection takes the softmax in the logits' own number type, as the scorer's own selection does,
    so a float64 model writes float64 scores both ways."""
    scored = torch.tensor([[False, True, True], [True, False, False]])
    mask = torch.tensor([[True, True, True], [True, False, False]])
    labels = torch.where(scored, torch.tensor(0), torch.tensor(-100))
    batch = {pg_score.SCORED: scored, "mask": mask, "target_seq": labels,
             pg_score.OWN_ROWS: torch.where(scored, torch.tensor(2), torch.tensor(0)),
             pg_score.OWN_NATURAL: torch.where(scored, torch.tensor(2), torch.tensor(0)),
             "meta_seq": {ID: np.array([["a", "b", "c"], ["d", None, None]], dtype=object)}}
    logits = torch.randn(2, 3, 2, dtype=torch.float64)
    pg_score.counts_start()
    prob, y, meta = pg_score.grouped_select(lambda *a: None)(logits, batch, True)
    assert prob.dtype == np.float64
    assert np.allclose(prob, torch.softmax(logits[scored], dim=-1)[:, 1].numpy(), rtol=0, atol=0)
    assert list(meta[ID]) == ["b", "c", "d"]


def test_the_grouped_builder_refuses_a_window_wider_than_max_chunk_rows(shapes, mods):
    """The grouped builder's copy of the project's max_chunk_rows rule: pg_score always lifts the limit, so it is
    shown here on the builder itself. With no cap and max_chunk_rows of 6, the crowded account's windows are wider,
    and both builders refuse the file the same way; with a wide enough limit both read it."""
    from fraud.data.preprocessing import PreprocessingArtifacts
    scorer = mods["scorer"]
    base, bounds = pg_score.grouping_pieces("old", scorer)
    grouped = pg_score.grouped_builder_class(base, bounds)
    arts = PreprocessingArtifacts.load(str(shapes["tmp"] / "artifacts/1"))

    def build(cls, limit):
        return cls(max_window_rows=None, file_list=[str(shapes["data"] / "part_20.parquet")], artifacts=arts,
                   features=shapes["features"], datetime_config=shapes["dt"], target_col=LABEL, account_col=ACCOUNT,
                   order_col=TIME, history_len=5, stride=1, batch_size=16, tie_break_col=ID, id_cols=[ID, ACCOUNT],
                   emit_target_seq=True, all_position_layout="nonoverlapping_chunks",
                   time_delta_reference="previous_transaction", history_time_order="strict", max_chunk_rows=limit)

    for cls in (base, grouped):
        with pytest.raises(ValueError, match="max_chunk_rows=6"):
            list(build(cls, 6))
        assert sum(int(b["mask"].shape[0]) for b in build(cls, 100_000)) > 0
