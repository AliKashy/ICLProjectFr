"""Grouped windows at scoring (pg_score.py --group-windows) on the old layout, CPU only: the grouped run's output
equals the ungrouped run's, no row is scored behind another first row, and the scored mark reaches the model.

Run: $PY -m pytest -q tests/experiments/program/test_program_grouped.py
"""
import json

import numpy as np
import pandas as pd
import pytest
import torch

from conftest import ACCOUNT, ID, LABEL, TIME

pg_layout = pytest.importorskip("pg_layout")
import pg_patch  # noqa: E402
import pg_score  # noqa: E402


@pytest.fixture
def mods():
    layout, m = pg_layout.resolve(roles=("base_model", "target_ending_model", "scorer", "factory",
                                        "target_ending_data"))
    if layout != "old":
        pytest.skip("these tests run on the old code layout")
    return m


def shaped(seed, start="2025-05-26", crowded=1200):
    """One raw file with accounts of every shape the grouping has to get right: a few rows over days; hundreds of
    rows over far more than 121 distinct seconds; several rows in one second (the same timestamp, and different
    milliseconds of one second); a crowded account with `crowded` rows in under 121 seconds; one-row accounts; an
    account that ends with ties and one that starts with them."""
    rng = np.random.default_rng(seed)
    t0 = pd.Timestamp(start)
    rows = []

    def account(name, offsets_ms):
        for k, ms in enumerate(sorted(offsets_ms)):
            rows.append({TIME: t0 + pd.Timedelta(milliseconds=int(ms)), ACCOUNT: f"g{seed}{name}",
                         ID: f"g{seed}{name}r{k:05}"})

    day = 86_400_000
    for a in range(4):  # a few rows over days
        account(f"few{a}", rng.integers(0, 3 * day, int(rng.integers(2, 7))))
    for a in range(2):  # hundreds of rows over far more than 121 distinct seconds
        account(f"long{a}", np.cumsum(rng.choice([1000, 3000, 60_000, 600_000], size=300)))
    for a in range(3):  # several rows in one second: the same timestamp, and milliseconds of one second
        base = np.cumsum(rng.choice([0, 0, 1000, 5000], size=40)) * 1
        account(f"tie{a}", base + rng.choice([0, 0, 250], size=40))
    # a crowded account: many rows in under 121 seconds, so its windows hold hundreds of rows
    account("crowd", rng.integers(0, 100_000, crowded) // 500 * 500)
    for a in range(5):  # one-row accounts
        account(f"one{a}", [int(rng.integers(0, day))])
    account("endtie", [0, 5000, 9000, 20_000, 20_000, 20_000, 20_000])  # ends with ties
    account("starttie", [0, 0, 0, 1000, 1000, 4000, 4000, 9000])  # starts with ties
    df = pd.DataFrame(rows)
    n = len(df)
    df["f1"], df["f2"] = rng.normal(size=n), rng.normal(size=n)
    df["c1"], df["c2"] = rng.choice(["A", "B"], size=n), rng.choice(["X", "Y"], size=n)
    df[LABEL] = (rng.random(n) < 0.2).astype(int)
    df["transaction_amt"] = np.abs(rng.normal(50, 20, size=n))
    df["predecline"] = 0
    df["transaction_advice_xcd"] = ""
    df["cardholder_present_xflg"] = rng.choice(["Y", "N"], size=n)
    return df


@pytest.fixture
def shapes(world):
    """Files 20 and 21 of the shaped accounts beside the world's files (the same columns and artifacts)."""
    frames = {20: shaped(20), 21: shaped(21, start="2025-05-28", crowded=300)}
    for i, f in frames.items():
        f.to_parquet(world["data"] / f"part_{i}.parquet", index=False)
    world["shaped"] = frames
    return world


SMALL = dict(input_embed_dim=16, num_heads=2, num_txn_blocks=1, num_seq_blocks=2)


def setup(w, mods, history, cap, seed=0, name=None, sizes=None, eval_batch=None):
    """(config path, checkpoint path) of a real model with random weights in strict all-position mode (small unless
    sizes are given), recorded as validated on target-ending windows with the given cap, so the project's scorer
    takes it."""
    from omegaconf import OmegaConf
    from fraud.data.preprocessing import PreprocessingArtifacts
    cfg = OmegaConf.load(w["cfg"])
    cfg.sequence.history_len = history
    cfg.sequence.max_window_rows = cap
    cfg.sequence.max_chunk_rows = None
    cfg.model.update(dict(sizes or SMALL, attn_dropout=0.0, ff_dropout=0.0))
    if eval_batch:
        cfg.training.eval_batch_size = int(eval_batch)
    name = name or f"h{history}_c{cap}_s{seed}"
    cfg_path = w["tmp"] / f"{name}.yaml"
    OmegaConf.save(cfg, cfg_path)
    factory = mods["factory"]
    arts = PreprocessingArtifacts.load(f"{cfg.artifacts.base}/{cfg.artifacts.version}")
    ds = mods["target_ending_data"].TargetEndingBuilder(
        max_window_rows=cap, file_list=[str(w["data"] / "part_3.parquet")], artifacts=arts, features=w["features"],
        datetime_config=w["dt"], target_col=LABEL, account_col=ACCOUNT, order_col=TIME, history_len=history,
        stride=1, add_missing_flag=cfg.preprocess.add_missing_flag, time_delta=True, batch_size=4,
        tie_break_col=ID, id_cols=list(cfg.data.id_cols), amount_col=cfg.data.amount_col,
        **factory.sequence_dataset_options(cfg))
    torch.manual_seed(seed)
    model = factory.build_sequential_model(cfg, ds)
    ckpt_path = w["tmp"] / f"{name}.ckpt"
    torch.save({"state_dict": model.state_dict(), "sequence_contract": model.sequence_contract,
                "validation_policy": {"name": mods["target_ending_model"].TARGET_ENDING_POLICY,
                                      "max_window_rows": cap}}, ckpt_path)
    return cfg_path, ckpt_path


def score(w, cfg_path, ckpt, out, files=(20, 20), *options):
    args = ["--config", str(cfg_path), "--checkpoint", str(ckpt), "--out", str(out), "--population", "OTHER",
            "--purpose", "test", f"eval.base={w['data']}", f"eval.file_start={files[0]}",
            f"eval.file_end={files[1]}", *options]
    rc = pg_score.main(args)
    return rc


def same_output(plain, grouped):
    """The largest score difference after checking that both files hold the same rows in the same order with every
    other column equal."""
    a, b = pd.read_parquet(plain), pd.read_parquet(grouped)
    assert list(a.columns) == list(b.columns)
    pd.testing.assert_frame_equal(a.drop(columns="score"), b.drop(columns="score"))
    return float(np.abs(a["score"].to_numpy() - b["score"].to_numpy()).max())


def first_rows(frames, history, cap, window_bounds):
    """{transaction id: (account, id of its window's first row, rows strictly earlier than it in its window)} from
    the raw files, the way the project's builder orders an account's rows."""
    out = {}
    for df in frames:
        d = df.assign(**{TIME: pd.to_datetime(df[TIME], utc=True)}).sort_values([ACCOUNT, TIME, ID], kind="stable")
        for acct, g in d.groupby(ACCOUNT, sort=False):
            key = g[TIME].to_numpy(dtype="datetime64[ns]").astype("int64")
            secs = g[TIME].to_numpy(dtype="datetime64[s]").astype("int64")
            lo, gs = window_bounds(secs, key, history, cap)
            ids = g[ID].to_numpy()
            for p in range(len(g)):
                out[ids[p]] = (acct, ids[lo[p]], int(gs[p] - lo[p]))
    return out


CASES = [  # (history, cap, files, force the wide-batch splitter to cut)
    (120, None, (20, 20), False),
    (120, 40, (20, 21), True),
    (5, None, (20, 21), True),
    (5, 4, (20, 20), False),
]


@pytest.mark.parametrize("history,cap,files,split", CASES)
def test_grouped_output_equals_ungrouped(shapes, mods, monkeypatch, capsys, history, cap, files, split):
    """The grouped run writes the ungrouped run's file: the same rows in the same order, every column equal, scores
    within 1e-6. Its receipt says how many windows went through the model, and that number is the count of
    distinct (account, first row) pairs worked out from the raw files."""
    if split:
        monkeypatch.setattr(pg_patch, "LAUNCH_ROWS", 1)  # every batch runs through the model in parts
        monkeypatch.setattr(pg_patch, "PART_ROWS", 300)
    cfg_path, ckpt = setup(shapes, mods, history, cap)
    plain, grouped = shapes["tmp"] / "plain.parquet", shapes["tmp"] / "grouped.parquet"
    assert score(shapes, cfg_path, ckpt, plain, files) == 0
    assert score(shapes, cfg_path, ckpt, grouped, files, "--group-windows") == 0
    diff = same_output(plain, grouped)
    with capsys.disabled():  # the largest difference is shown with -s
        print(f"history {history} cap {cap} files {files} split {split}: largest score difference {diff:.3e}")
    assert diff <= 1e-6
    assert pd.read_parquet(plain)["score"].std() > 1e-3  # the random model tells rows apart: the check has teeth
    receipt = json.loads((shapes["tmp"] / "grouped.parquet.json").read_text())["grouped_windows"]
    assert "grouped_windows" not in json.loads((shapes["tmp"] / "plain.parquet.json").read_text())
    frames = [shapes["shaped"][i] for i in range(files[0], files[1] + 1)]
    firsts = first_rows(frames, history, cap, mods["target_ending_data"].window_bounds)
    assert receipt["grouped"] and receipt["output_checked"]
    assert receipt["rows_scored"] == receipt["ungrouped_windows"] == len(pd.read_parquet(plain)) == len(firsts)
    assert receipt["windows_through_model"] == len({(a, f) for a, f, _ in firsts.values()})
    assert receipt["windows_through_model"] < receipt["ungrouped_windows"]
    assert receipt["window_slots"] < receipt["ungrouped_window_slots"]
    if history == 120 and cap is None:  # the crowded account is one window, not one per row
        crowd = [f for a, f, _ in firsts.values() if a == "g20crowd"]
        assert len(set(crowd)) == 1 and len(crowd) == 1200
    assert "group windows:" in capsys.readouterr().out


def counting_forward(self, batch):
    """A stand-in for the model: each slot's fraud logit is 0.01 x the number of real rows of its window with a
    strictly earlier timestamp, the count the real model's position input reads. A row placed in a window that
    opens at another row than its own window's first row sees another count and gets another score."""
    mask, times = batch["mask"], batch["time_seq"]
    earlier = (times.unsqueeze(1) < times.unsqueeze(2)) & mask.unsqueeze(1) & mask.unsqueeze(2)
    count = earlier.sum(-1).float()
    return torch.stack([torch.zeros_like(count), 0.01 * count], -1)


def test_a_row_is_never_scored_behind_another_first_row(shapes, mods, monkeypatch):
    """With a model whose output is the count of earlier rows a row can see, every grouped score equals the count of
    the row's own window; and a grouping that puts rows behind another first row (one window per account) is caught
    by the same comparison."""
    history = 5
    model_cls = mods["base_model"].FTTransformerHierModel
    monkeypatch.setattr(model_cls, "forward", counting_forward)
    cfg_path, ckpt = setup(shapes, mods, history, None)
    window_bounds = mods["target_ending_data"].window_bounds
    firsts = first_rows([shapes["shaped"][20]], history, None, window_bounds)
    expected = {i: 1 / (1 + np.exp(-0.01 * n)) for i, (_, _, n) in firsts.items()}

    def off_by(path):
        got = pd.read_parquet(path)
        return float(np.abs(got["score"].to_numpy() - got[ID].map(expected).to_numpy()).max())

    plain, grouped = shapes["tmp"] / "count_plain.parquet", shapes["tmp"] / "count_grouped.parquet"
    assert score(shapes, cfg_path, ckpt, plain) == 0
    assert score(shapes, cfg_path, ckpt, grouped, (20, 20), "--group-windows") == 0
    assert off_by(plain) < 1e-6 and off_by(grouped) < 1e-6
    assert same_output(plain, grouped) < 1e-6

    def whole_account(seconds, order_key, history_len, max_window_rows=None):
        lo, gs = window_bounds(seconds, order_key, history_len, max_window_rows)
        return np.zeros_like(lo), gs  # every row behind the account's first row: the grouping this test must catch

    monkeypatch.setattr(mods["target_ending_data"], "window_bounds", whole_account)
    wrong = shapes["tmp"] / "count_wrong.parquet"
    # the scorer's own builder takes the same changed function, so the built-in comparison agrees with it; the
    # check of the output works the window sizes out from the times on its own, and refuses the output
    assert score(shapes, cfg_path, ckpt, wrong, (20, 20), "--group-windows") == 4
    renamed = shapes["tmp"] / "count_wrong.parquet.not_checked"
    assert not wrong.exists() and renamed.is_file() and off_by(renamed) > 1e-3  # caught
    entry = json.loads((shapes["tmp"] / "count_wrong.parquet.json").read_text())["grouped_windows"]
    assert entry["output_checked"] is False and "window_rows" in entry["check_failed_because"]


def test_the_mark_reaches_the_model(shapes, mods, monkeypatch):
    """Grouped: the model gets "scored", True on exactly the rows whose window opens at the window's first row (the
    scored rows), False on history and padding. Ungrouped with --mark-scored-rows: True on the last real row of
    every window. Ungrouped without it: no mark at all."""
    model_cls = mods["base_model"].FTTransformerHierModel
    original = model_cls.forward
    seen = []

    def recording(self, batch):
        seen.append({k: batch[k].clone() for k in ("mask", "time_seq", pg_score.SCORED) if k in batch})
        return original(self, batch)

    monkeypatch.setattr(model_cls, "forward", recording)
    # the built-in comparison calls the model too, once the scorer's own way (no mark); only the full run is read
    compare = pg_score.compare_on_sample

    def compare_then_forget(*args, **kwargs):
        result = compare(*args, **kwargs)
        seen.clear()
        return result

    monkeypatch.setattr(pg_score, "compare_on_sample", compare_then_forget)
    cfg_path, ckpt = setup(shapes, mods, 5, None)

    out = shapes["tmp"] / "mark_grouped.parquet"
    assert score(shapes, cfg_path, ckpt, out, (20, 20), "--group-windows") == 0
    rows = len(pd.read_parquet(out))
    assert seen and all(pg_score.SCORED in b for b in seen)
    total = 0
    for b in seen:
        mask, mark = b["mask"], b[pg_score.SCORED]
        assert mark.dtype == torch.bool and mark.shape == mask.shape
        assert not bool((mark & ~mask).any())  # never on padding
        for r in range(mask.shape[0]):
            n = int(mask[r].sum())
            on = mark[r, :n].nonzero().flatten()
            # the scored rows are the window's last rows, up to its last real row; the rows before are history
            assert len(on) >= 1 and int(on[-1]) == n - 1 and len(on) == int(on[-1] - on[0]) + 1
        total += int(mark.sum())
    assert total == rows

    # the exact rows: built by the grouped builder itself, compared with the first rows from the raw file
    from fraud.data.preprocessing import PreprocessingArtifacts
    scorer = mods["scorer"]
    base, bounds = pg_score.grouping_pieces("old", scorer)
    cls = pg_score.grouped_builder_class(base, bounds)
    arts = PreprocessingArtifacts.load(str(shapes["tmp"] / "artifacts/1"))
    ds = cls(max_window_rows=None, file_list=[str(shapes["data"] / "part_20.parquet")], artifacts=arts,
             features=shapes["features"], datetime_config=shapes["dt"], target_col=LABEL, account_col=ACCOUNT,
             order_col=TIME, history_len=5, stride=1, batch_size=16, tie_break_col=ID, id_cols=[ID, ACCOUNT],
             emit_target_seq=True, all_position_layout="nonoverlapping_chunks",
             time_delta_reference="previous_transaction", history_time_order="strict")
    firsts = first_rows([shapes["shaped"][20]], 5, None, bounds)
    scored_ids = []
    for b in ds:
        ids = b["meta_seq"][ID]
        for r in range(b["mask"].shape[0]):
            n = int(b["mask"][r].sum())
            for s in range(n):
                assert bool(b[pg_score.SCORED][r, s]) == (firsts[ids[r, s]][1] == ids[r, 0])
                if bool(b[pg_score.SCORED][r, s]):
                    scored_ids.append(ids[r, s])
                    assert int(b[pg_score.OWN_ROWS][r, s]) == firsts[ids[r, s]][2] + 1
            assert not bool(b[pg_score.SCORED][r, n:].any())
    assert sorted(scored_ids) == sorted(firsts)  # every row is scored exactly once

    seen.clear()
    marked = shapes["tmp"] / "mark_plain.parquet"
    assert score(shapes, cfg_path, ckpt, marked, (20, 20), "--mark-scored-rows") == 0
    for b in seen:
        assert torch.equal(b[pg_score.SCORED], pg_score.last_real_row(b["mask"]))
        assert torch.equal(b[pg_score.SCORED].sum(1), torch.ones(b["mask"].shape[0], dtype=torch.long))
    seen.clear()
    plain = shapes["tmp"] / "nomark_plain.parquet"
    assert score(shapes, cfg_path, ckpt, plain, (20, 20)) == 0
    assert seen and all(pg_score.SCORED not in b for b in seen)
    assert same_output(plain, marked) == 0.0  # the base model does not read the mark


def test_grouping_with_the_month_map(shapes, mods, capsys):
    """--group-windows with --month-map 6=5 writes what the ungrouped run with the same map writes."""
    cfg_path, ckpt = setup(shapes, mods, 5, None)
    plain, grouped = shapes["tmp"] / "m_plain.parquet", shapes["tmp"] / "m_grouped.parquet"
    assert score(shapes, cfg_path, ckpt, plain, (8, 8), "--month-map", "6=5") == 0
    assert score(shapes, cfg_path, ckpt, grouped, (8, 8), "--month-map", "6=5", "--group-windows") == 0
    assert same_output(plain, grouped) <= 1e-6
    assert "rows of month 6 are read as month 5" in capsys.readouterr().out


def test_a_missing_piece_scores_the_ungrouped_way(shapes, mods, monkeypatch, capsys):
    """When the layout lacks a piece grouping needs, one line says so, the rows are scored the ungrouped way and
    the receipt says why nothing was grouped."""
    monkeypatch.setitem(pg_layout.NAMES["old"], "target_ending_data", "no_such_package.target_ending")
    cfg_path, ckpt = setup(shapes, mods, 5, None)
    plain, asked = shapes["tmp"] / "x_plain.parquet", shapes["tmp"] / "x_asked.parquet"
    assert score(shapes, cfg_path, ckpt, plain) == 0
    capsys.readouterr()
    assert score(shapes, cfg_path, ckpt, asked, (20, 20), "--group-windows") == 0
    assert "scored the ungrouped way" in capsys.readouterr().out
    assert same_output(plain, asked) == 0.0
    entry = json.loads((shapes["tmp"] / "x_asked.parquet.json").read_text())["grouped_windows"]
    assert entry["grouped"] is False and "target-ending data module" in entry["not_grouped_because"]


def test_options_off_change_nothing_and_are_put_back(shapes, mods):
    """The options are taken out of the scorer's arguments; after a grouped run the scorer's own functions are
    back; the mark of a left-padded single-target window is its last slot."""
    assert pg_score.take_flag(["--config", "c", "--group-windows", "x=1"], "--group-windows") == \
        (["--config", "c", "x=1"], True)
    assert pg_score.take_flag(["--config", "c"], "--group-windows") == (["--config", "c"], False)
    scorer = mods["scorer"]
    before = {k: getattr(scorer, k) for k in ("TargetEndingBuilder", "select", "natural_rows", "_model_inputs")}
    cfg_path, ckpt = setup(shapes, mods, 5, None)
    assert score(shapes, cfg_path, ckpt, shapes["tmp"] / "o.parquet", (20, 20), "--group-windows") == 0
    assert {k: getattr(scorer, k) for k in before} == before
    left = torch.tensor([[False, False, True, True], [True, True, True, False], [True, True, True, True]])
    assert pg_score.last_real_row(left).nonzero().tolist() == [[0, 3], [1, 2], [2, 3]]


def test_an_output_that_fails_its_check_is_not_used(tmp_path, capsys):
    """If the written window sizes are not the ones worked out from the rows read, the output is renamed, the tool
    says so and the receipt gives the reason."""
    import pyarrow as pa
    import pyarrow.parquet as pq
    out = tmp_path / "o.parquet"
    pq.write_table(pa.table({ID: ["a", "b", "c"], "window_rows": np.array([1, 5, 1])}), out)
    (tmp_path / "o.parquet.json").write_text("{}")
    folder = tmp_path / "read"
    folder.mkdir()
    # the rows read: three rows of one account at 0, 1 and 2 s, so their own windows hold 1, 2 and 3 rows
    seconds = np.array([0, 1, 2], dtype=np.int64)
    pq.write_table(pa.table({"id0": ["a", "b", "c"], "account": ["x", "x", "x"], "key": seconds * 10 ** 9,
                             "second": seconds}), folder / "rows.parquet")
    pg_score.counts_start()
    pg_score._GROUPED.update(grouped_batches=1, scored=3, read_dir=str(folder), id_cols=[ID], history_len=5,
                             cap=None, T=6)
    assert pg_score.grouped_receipt(True, True, None, True, str(out), str(tmp_path / "o.parquet.json")) is False
    assert not out.exists() and (tmp_path / "o.parquet.not_checked").exists()
    assert "Score again without --group-windows" in capsys.readouterr().err
    receipt = json.loads((tmp_path / "o.parquet.json").read_text())
    assert receipt["grouped_windows"]["output_checked"] is False
    assert "window_rows" in receipt["grouped_windows"]["check_failed_because"]
    assert receipt["grouped_windows"]["ungrouped_windows"] == 3
    assert receipt["grouped_windows"]["ungrouped_window_slots"] == 18  # three windows padded to history_len + 1


def test_loader_workers_give_the_same_rows(shapes, mods):
    """With loader workers each worker reads its own files and the loader takes their batches in turn, so with
    several files the rows of a grouped run (fewer batches) interleave differently from an ungrouped run; every row
    and every value is the same once both are put in id order, and with one file the order is the same too."""
    cfg_path, ckpt = setup(shapes, mods, 5, None)
    two = ["training.num_workers=2"]
    for files in ((20, 21), (20, 20)):
        plain, grouped = shapes["tmp"] / f"w{files[1]}_plain.parquet", shapes["tmp"] / f"w{files[1]}_grouped.parquet"
        assert score(shapes, cfg_path, ckpt, plain, files, *two) == 0
        assert score(shapes, cfg_path, ckpt, grouped, files, *two, "--group-windows") == 0
        a, b = pd.read_parquet(plain), pd.read_parquet(grouped)
        if files[0] == files[1]:
            assert same_output(plain, grouped) <= 1e-6
        a, b = a.sort_values(ID, ignore_index=True), b.sort_values(ID, ignore_index=True)
        pd.testing.assert_frame_equal(a.drop(columns="score"), b.drop(columns="score"))
        assert np.abs(a["score"] - b["score"]).max() <= 1e-6
