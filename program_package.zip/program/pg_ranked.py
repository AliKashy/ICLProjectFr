"""Ranked scores, the bank's outsort measures, AP, AUROC, KS and the account bootstrap. Pure numpy.

Ranking: descending score, ties broken by the ascending identity key json.dumps([str(account), str(id)]). The key
is replaced by its rank among the rows (the same order in far less memory).

Outsort at a share p = a/b of the rows: the top floor(W x a / b) rows (rounding "floor", the default) or the top
ceil(W x a / b) rows (rounding "ceil", the count the bank's rank-based table selects), W the total weight (the row
count at the point). With bootstrap weights above one, the boundary row's copies count only up to the budget.

- UDR = frauds in the outsort / all frauds.
- VDR = fraud amount in the outsort / all fraud amount. NaN with a reason when an amount is missing, not finite or
  negative.
- FPR, as the bank uses it = false positives / true positives in the outsort. Lower is better.
- AP and AUROC treat equal scores as one threshold (as scikit-learn). KS is read only after a whole tied group.

The account bootstrap resamples whole accounts with replacement. Units are the distinct accounts in ascending
string order. Draw b uses numpy.random.default_rng(seed): bincount(integers(0, n, n)), one draw at a time, so every
fit compared sees the same accounts in every draw.
"""
from __future__ import annotations

from fractions import Fraction
import json

import numpy as np

SHARE_06 = Fraction(3, 500)  # 0.6% is exactly 6 per mille
METRICS = ("udr", "ap", "vdr", "fpr", "auroc", "ks")


def identity_keys(accounts, ids):
    return np.asarray([json.dumps([str(a), str(i)]) for a, i in zip(accounts, ids)], dtype=object)


def key_ranks(keys):
    """Ordinal rank of each key in ascending string order. Keys must be unique."""
    text = np.asarray([str(k) for k in keys], dtype=object)
    order = np.argsort(text, kind="stable")
    if len(text) > 1 and (text[order][1:] == text[order][:-1]).any():
        raise ValueError("identity keys must be unique: a (account, id) pair appears twice")
    ranks = np.empty(len(text), dtype=np.int64)
    ranks[order] = np.arange(len(text))
    return ranks


def account_units(accounts):
    """Account code per row and the units (distinct accounts as strings, ascending)."""
    text = np.asarray([str(a) for a in accounts], dtype=object)
    units, codes = np.unique(text, return_inverse=True)
    return codes.astype(np.int64).reshape(-1), units


def multiplicity_draws(n_units, draws, seed):
    rng = np.random.default_rng(seed)
    for _ in range(int(draws)):
        yield np.bincount(rng.integers(0, n_units, n_units), minlength=n_units)


def amount_reason(amounts):
    if amounts is None:
        return "amount not supplied"
    values = np.asarray(amounts, dtype=float)
    if not np.isfinite(values).all():
        return "an amount is missing or not finite"
    if (values < 0).any():
        return "a negative amount; no sign convention is assumed"
    return None


def share_of(per_mille):
    return Fraction(per_mille).limit_denominator(100000) / 1000


def outsort_count(total, share, rounding="floor"):
    total = int(total)
    if rounding == "ceil":
        return -((-total * share.numerator) // share.denominator)
    return total * share.numerator // share.denominator


class RankedScore:
    """One fit's scores on the read's rows, sorted once. evaluate(multiplicity) gives every measure."""

    def __init__(self, scores, y, codes, key_rank, amounts=None, share=SHARE_06, rounding="floor"):
        scores = np.asarray(scores, dtype=float)
        y = np.asarray(y)
        if scores.ndim != 1 or len(scores) != len(y) or len(y) != len(codes) or len(y) != len(key_rank):
            raise ValueError("scores, labels, account codes and keys must have one value per row")
        if not len(y):
            raise ValueError("no rows")
        if not np.isfinite(scores).all():
            raise ValueError("scores must be finite")
        if not np.isin(y, [0, 1]).all():
            raise ValueError("labels must be 0 or 1")
        self.share, self.rounding = Fraction(share), rounding
        order = np.lexsort((np.asarray(key_rank), -scores))
        s = scores[order]
        self.y = y.astype(np.int64)[order]
        self.codes = np.asarray(codes, dtype=np.int64)[order]
        self.amount_reason = amount_reason(amounts)
        self.values = None if self.amount_reason else (np.asarray(amounts, dtype=float) * y)[order]
        self.ends = np.flatnonzero(np.r_[s[1:] != s[:-1], True])

    def evaluate(self, multiplicity=None, share=None):
        share = self.share if share is None else Fraction(share)
        w = np.ones(len(self.y), np.int64) if multiplicity is None else np.asarray(multiplicity, np.int64)[self.codes]
        cw = np.cumsum(w)
        cwy = np.cumsum(w * self.y)
        total, positives = int(cw[-1]), int(cwy[-1])
        negatives = total - positives
        out = {"rows": total, "frauds": positives, "ap": np.nan, "auroc": np.nan, "ks": np.nan}
        if positives > 0:
            tp = cwy[self.ends]
            fp = cw[self.ends] - tp
            dtp = np.diff(tp, prepend=0)
            out["ap"] = float(np.dot(dtp, tp / np.maximum(cw[self.ends], 1)) / positives)
            if negatives > 0:
                dfp = np.diff(fp, prepend=0)
                out["auroc"] = float(np.dot(dtp, (negatives - fp) + 0.5 * dfp) / (positives * negatives))
                out["ks"] = float(np.abs(tp / positives - fp / negatives).max())
        count = outsort_count(total, share, self.rounding)
        cv = None if self.values is None else np.cumsum(w * self.values)
        if count == 0:
            caught, amount = 0, 0.0
        else:
            k = int(np.searchsorted(cw, count, side="left"))
            k = min(k, len(cw) - 1)
            partial = count - (int(cw[k - 1]) if k else 0)
            caught = (int(cwy[k - 1]) if k else 0) + partial * int(self.y[k])
            amount = None if cv is None else (float(cv[k - 1]) if k else 0.0) + partial * float(self.values[k])
        fraud_amount = None if cv is None else float(cv[-1])
        out.update(outsorted=int(count), frauds_outsorted=int(caught), false_positives=int(count - caught))
        out["udr"] = caught / positives if positives else np.nan
        out["vdr"] = amount / fraud_amount if (cv is not None and fraud_amount) else np.nan
        out["fpr"] = (count - caught) / caught if caught else np.nan
        return out

    def fraud_accounts_caught(self, share=None):
        """(fraud accounts with a fraud row in the outsort, all fraud accounts), at the point. Information only."""
        share = self.share if share is None else Fraction(share)
        count = outsort_count(len(self.y), share, self.rounding)
        top = self.y[:count] == 1
        caught = len(np.unique(self.codes[:count][top])) if count else 0
        return int(caught), int(len(np.unique(self.codes[self.y == 1])))


def vector(result, metrics=METRICS):
    return np.asarray([result[m] for m in metrics], dtype=float)


def summary(values, interval=90.0):
    finite = values[np.isfinite(values)]
    low_q = (100.0 - interval) / 2.0
    if len(finite) < 2:
        return {"sd": None, "var": None, "lo": None, "hi": None, "valid_draws": int(len(finite))}
    return {"sd": float(np.std(finite, ddof=1)), "var": float(np.var(finite, ddof=1)),
            "lo": float(np.percentile(finite, low_q)), "hi": float(np.percentile(finite, 100.0 - low_q)),
            "valid_draws": int(len(finite))}


def paired(candidates, controls, n_units, draws, seed, interval=90.0, metrics=METRICS):
    """Candidate minus control, per seed and as the mean over seeds, with the account bootstrap.

    candidates and controls are lists of RankedScore, one per seed, in the same seed order; every fit is evaluated on
    the same draws. Per metric: per-seed points and differences, the gain (mean of the differences) and the
    bootstrap sd, variance and percentile interval of the gain."""
    if len(candidates) != len(controls) or not candidates:
        raise ValueError("one candidate and one control per seed")
    fits = list(candidates) + list(controls)
    k = len(candidates)
    points = np.vstack([vector(f.evaluate(None), metrics) for f in fits])
    gains = np.full((len(metrics), int(draws)), np.nan)
    for b, mult in enumerate(multiplicity_draws(n_units, draws, seed)):
        values = np.vstack([vector(f.evaluate(mult), metrics) for f in fits])
        gains[:, b] = (values[:k] - values[k:]).mean(axis=0)
    result = {}
    for m, name in enumerate(metrics):
        d = points[:k, m] - points[k:, m]
        result[name] = {"candidate": points[:k, m].tolist(), "control": points[k:, m].tolist(),
                        "differences": d.tolist(), "gain": float(np.mean(d)),
                        "candidate_mean": float(np.mean(points[:k, m])), "control_mean": float(np.mean(points[k:, m])),
                        **summary(gains[m], interval)}
    return result


def unpaired(group_a, group_b, n_units, draws, seed, interval=90.0, metrics=METRICS):
    """Mean of group A minus mean of group B (independent fits, possibly different counts), with the account
    bootstrap variance of that difference; every fit is evaluated on the same draws."""
    fits = list(group_a) + list(group_b)
    ka = len(group_a)
    points = np.vstack([vector(f.evaluate(None), metrics) for f in fits])
    diffs = np.full((len(metrics), int(draws)), np.nan)
    for b, mult in enumerate(multiplicity_draws(n_units, draws, seed)):
        v = np.vstack([vector(f.evaluate(mult), metrics) for f in fits])
        diffs[:, b] = v[:ka].mean(axis=0) - v[ka:].mean(axis=0)
    out = {}
    for m, name in enumerate(metrics):
        a, b = points[:ka, m], points[ka:, m]
        out[name] = {"a": a.tolist(), "b": b.tolist(), "difference": float(a.mean() - b.mean()),
                     **summary(diffs[m], interval)}
    return out


def score_table(fits, n_units, draws, seed, metrics=METRICS, interval=90.0):
    """Each fit's point and bootstrap interval, and every fit's draws (for differences between any two)."""
    points = np.vstack([vector(f.evaluate(None), metrics) for f in fits])
    values = np.full((len(fits), len(metrics), int(draws)), np.nan)
    for b, mult in enumerate(multiplicity_draws(n_units, draws, seed)):
        for i, f in enumerate(fits):
            values[i, :, b] = vector(f.evaluate(mult), metrics)
    return points, values


def prepare(accounts, ids):
    """(key ranks, account codes, number of accounts) for arrays of accounts and ids."""
    codes, units = account_units(accounts)
    return key_ranks(identity_keys(accounts, ids)), codes, len(units)


def outsort(y, scores, accounts, ids, amounts=None, per_mille=6, rounding="floor"):
    """Every measure of one score array at an outsort of per_mille / 1000 of the rows."""
    key_rank, codes, _ = prepare(accounts, ids)
    return RankedScore(scores, y, codes, key_rank, amounts, share_of(per_mille), rounding).evaluate(None)


def average_precision(y, scores, weights=None):
    """AP with equal scores as one threshold, as scikit-learn's average_precision_score (with sample_weight)."""
    y = np.asarray(y, dtype=np.int64)
    s = np.asarray(scores, dtype=float)
    w = np.ones(len(y), dtype=np.int64) if weights is None else np.asarray(weights, dtype=np.int64)
    order = np.argsort(-s, kind="stable")
    s, y, w = s[order], y[order], w[order]
    ends = np.flatnonzero(np.r_[s[1:] != s[:-1], True])
    cw, cwy = np.cumsum(w)[ends], np.cumsum(w * y)[ends]
    positives = cwy[-1] if len(cwy) else 0
    if positives == 0:
        return float("nan")
    return float(np.dot(np.diff(cwy, prepend=0), cwy / np.maximum(cw, 1)) / positives)
