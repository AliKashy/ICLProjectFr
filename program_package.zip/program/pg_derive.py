"""Columns derived from an export: PCA of the vector, the part of the vector the fraud head does not read, and
each account's averages over strictly earlier transactions.

Where it runs: on the pod, CPU only, from the project root.

- pca: a PCA basis (8 and 16 components by default) fitted once on the downstream training export (DS_TRAIN) and
  applied to every export: pca8_0.., pca16_0...
- orth: the head reads the vector through one direction, w = head weight of class 1 minus class 0. A Householder
  reflection maps w to the first axis; the other 47 coordinates (o_0 .. o_46) are an orthonormal basis of everything
  the head cannot see. head_coord is the coordinate along w.
- windows: for each transaction, the mean of the chosen columns over the same account's transactions in the previous
  1, 7 and 30 days, using only strictly earlier seconds (never the transaction itself or another transaction in the
  same second, and never a label), the counts behind each mean, and the deviation of the transaction from its 1-day
  and 30-day means. Rows with no earlier transaction in a window get no mean (null).

Usage:
    $PY program/pg_derive.py fit-pca --export runs/program/export/ds_train.parquet \
        --out runs/program/export/pca.npz
    $PY program/pg_derive.py derive --export runs/program/export/ds_select.parquet \
        --checkpoint runs/program/final_s42/best.ckpt --pca runs/program/export/pca.npz \
        --out runs/program/export/ds_select_derived.parquet [--windows 1 7 30] [--window-of pca16]
The derived file holds the export's keys plus the new columns; join it to the export on the transaction id.
"""
import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

ACCOUNT, ID, TIME = "Nmap_account_reference_xid", "fi_transaction_id", "transaction_dttm"
DAY = 86400


def vector_columns(columns, prefix="e_"):
    cols = [c for c in columns if c.startswith(prefix) and c[len(prefix):].isdigit()]
    return sorted(cols, key=lambda c: int(c[len(prefix):]))


def read_vectors(path, sample=None, seed=0):
    df = pq.read_table(path).to_pandas()
    if sample and len(df) > sample:
        df = df.sample(n=sample, random_state=seed)
    cols = vector_columns(df.columns)
    return df, df[cols].to_numpy(np.float64), cols


def fit_pca(x, sizes=(8, 16)):
    mean = x.mean(axis=0)
    _, s, vt = np.linalg.svd(x - mean, full_matrices=False)
    var = s ** 2 / max(len(x) - 1, 1)
    out = {"mean": mean, "components": vt, "explained": var / var.sum()}
    for k in sizes:
        out[f"share_{k}"] = float(out["explained"][:k].sum())
    return out


def head_direction(checkpoint):
    import torch
    sd = torch.load(checkpoint, map_location="cpu", weights_only=False)["state_dict"]
    w = sd["head.weight"].float().numpy()
    return (w[1] - w[0]).astype(np.float64)


def householder_basis(w):
    """An orthonormal matrix H (d x d) with H @ (w / |w|) = e_1; rows 1.. span the directions the head ignores."""
    u = w / np.linalg.norm(w)
    e1 = np.zeros_like(u)
    e1[0] = 1.0
    v = u - e1
    if np.linalg.norm(v) < 1e-12:
        return np.eye(len(u))
    v /= np.linalg.norm(v)
    return np.eye(len(u)) - 2.0 * np.outer(v, v)


def window_means(accounts, times, values, days=(1, 7, 30)):
    """Per row: (means [n, len(days), k], counts [n, len(days)]) over the same account's strictly earlier seconds
    within each window. accounts and times are per row (times as datetime64); values [n, k]."""
    n = len(values)
    acct_codes = pd.factorize(pd.Series(accounts).astype(str))[0].astype(np.int64)
    sec = pd.to_datetime(pd.Series(times)).to_numpy().astype("datetime64[s]").astype(np.int64)
    if any(int(d) <= 0 for d in days):
        raise ValueError("window lengths are whole days, 1 or more")
    sec = sec - sec.min() + 1  # small positive seconds
    span = int(sec.max()) + (int(max(days)) + 1) * DAY  # an account's window never reaches the account before it
    key = acct_codes * span + sec
    order = np.argsort(key, kind="stable")
    ks = key[order]
    xs = values[order].astype(np.float64)
    cs = np.vstack([np.zeros((1, xs.shape[1])), np.cumsum(xs, axis=0)])
    end = np.searchsorted(ks, ks, side="left")  # first row of the same account and second: strictly earlier before it
    means = np.full((n, len(days), xs.shape[1]), np.nan, dtype=np.float32)
    counts = np.zeros((n, len(days)), dtype=np.int64)
    for j, d in enumerate(days):
        start = np.searchsorted(ks, ks - int(d) * DAY, side="left")
        cnt = end - start
        with np.errstate(invalid="ignore", divide="ignore"):
            m = (cs[end] - cs[start]) / cnt[:, None]
        m[cnt == 0] = np.nan
        means[order, j] = m.astype(np.float32)
        counts[order, j] = cnt
    return means, counts


def derive(export_path, out_path, checkpoint=None, pca_path=None, windows=(1, 7, 30), window_of="pca16",
           id_col=ID, account_col=ACCOUNT, time_col=TIME):
    df = pq.read_table(export_path).to_pandas()
    cols = vector_columns(df.columns)
    x = df[cols].to_numpy(np.float64)
    out = pd.DataFrame({id_col: df[id_col].to_numpy(), account_col: df[account_col].to_numpy(),
                        time_col: df[time_col].to_numpy()})
    if pca_path:
        p = np.load(pca_path)
        z = (x - p["mean"]) @ p["components"].T
        for k in (8, 16):
            for j in range(min(k, z.shape[1])):
                out[f"pca{k}_{j}"] = z[:, j].astype(np.float32)
    if checkpoint:
        h = householder_basis(head_direction(checkpoint))
        z = x @ h.T
        out["head_coord"] = z[:, 0].astype(np.float32)
        for j in range(1, z.shape[1]):
            out[f"o_{j - 1}"] = z[:, j].astype(np.float32)
    if windows:
        if window_of == "vector":
            base_cols, base = cols, x
        elif window_of == "score":
            base_cols, base = ["score"], df[["score"]].to_numpy(np.float64)
        else:
            k = int(window_of.replace("pca", ""))
            base_cols = [f"pca{k}_{j}" for j in range(k)]
            missing = [c for c in base_cols if c not in out]
            if missing:
                raise SystemExit(f"--window-of {window_of} needs --pca")
            base = out[base_cols].to_numpy(np.float64)
        if "score" in df and "score" not in base_cols:
            base_cols = base_cols + ["score"]
            base = np.hstack([base, df[["score"]].to_numpy(np.float64)])
        means, counts = window_means(df[account_col].to_numpy(), df[time_col].to_numpy(), base, windows)
        for j, d in enumerate(windows):
            out[f"n{d}d"] = counts[:, j]
            for c, col in enumerate(base_cols):
                out[f"w{d}d_{col}"] = means[:, j, c]
        for d in (windows[0], windows[-1]):
            j = list(windows).index(d)
            for c, col in enumerate(base_cols):
                out[f"dev{d}d_{col}"] = (base[:, c] - means[:, j, c]).astype(np.float32)
    out.to_parquet(out_path, index=False)
    print(f"derived {out.shape[1] - 3} columns for {len(out):,} rows -> {out_path}", flush=True)
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description="derived columns of an export")
    ap.add_argument("command", choices=("fit-pca", "derive"))
    ap.add_argument("--export", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--checkpoint", default=None)
    ap.add_argument("--pca", default=None)
    ap.add_argument("--windows", type=int, nargs="*", default=[1, 7, 30])
    ap.add_argument("--window-of", default="pca16", help="vector, score, pca8 or pca16 (score is always added)")
    ap.add_argument("--sample", type=int, default=2_000_000, help="fit-pca: rows used for the fit")
    a = ap.parse_args(argv)
    if Path(a.out).exists():
        raise SystemExit(f"{a.out} exists; choose a new --out")
    if a.command == "fit-pca":
        _, x, _ = read_vectors(a.export, a.sample)
        p = fit_pca(x)
        np.savez(a.out, **{k: v for k, v in p.items()})
        print(f"PCA on {len(x):,} rows: 8 components keep {p['share_8']:.3f} of the variance, 16 keep "
              f"{p['share_16']:.3f} -> {a.out}")
        return 0
    derive(a.export, a.out, a.checkpoint, a.pca, tuple(a.windows), a.window_of)
    return 0


if __name__ == "__main__":
    sys.exit(main())
