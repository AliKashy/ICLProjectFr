"""Our model against the real 15298 and the real PFM on the same transactions (Test 2, the bank's 952,905 June rows;
FINAL at the freeze).

Where it runs: on the pod or the laptop, CPU only.

Inputs: one score file per model, each with the transaction id and a score column (parquet or CSV), and the
benchmark rows: a file with the transaction id, the label and the amount (the account id too if it has it), for
example the reconstructed scoring parquet. Every model is read on the rows that all files cover (the common rows);
how many rows each file covers is printed. Duplicate ids are kept once.

Measures per model, at 0.6%, 1% and 5% of the rows: UDR (the bank's DR: frauds caught over all frauds), VDR (fraud
amount caught), FPR (false positives per caught fraud), plus AP, AUROC and KS. The outsort count is floor(share x N)
(our rule) or ceil(share x N) (the count the bank's rank-based table selects); --rounding both prints both. Paired
differences between models use the account bootstrap (2000 draws, the same accounts for every model; by row when no
account id is available, with a note), 90% interval.

Usage:
    $PY program/pg_bench.py --rows test2_rows.parquet \
        --model ours=runs/program/final_s42/test2.parquet:score \
        --model 15298=scores_15298.parquet:score --model PFM=scores_pfm.parquet:probability \
        --pair ours-15298 --pair ours-PFM --pair PFM-15298 --out runs/program/reads/test2.json

ADAPT: column names (--id-col, --label-col, --amount-col, --account-col) to the owner's files. Files on S3
(s3:// paths) are read with --cred, the project's credentials file.
"""
import argparse
import json
import sys
from fractions import Fraction
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pg_ranked as R  # noqa: E402

FS = {"cred": None, "fs": None}

SHARES = (6, 10, 50)  # per mille: 0.6%, 1%, 5%


def read_any(path, columns=None):
    """A parquet or CSV file, local or on S3 (s3:// paths use --cred, the project's credentials file)."""
    path = str(path)
    if path.startswith(("s3://", "s3a://")):
        import pg_layout
        import pg_rows
        if FS["fs"] is None:
            FS["fs"] = pg_layout.s3_filesystem(FS["cred"])
        if path.endswith(".parquet"):
            return pg_rows.read_columns(path, columns or [], FS["fs"]) if columns else \
                pq_read(pg_rows.strip_scheme(path), FS["fs"])
        with FS["fs"].open(pg_rows.strip_scheme(path), "rb") as f:
            return pd.read_csv(f, dtype=str)
    if path.endswith(".parquet"):
        import pyarrow.parquet as pq
        have = set(pq.ParquetFile(path).schema_arrow.names)
        cols = None if columns is None else [c for c in columns if c in have]
        return pq.read_table(path, columns=cols).to_pandas()
    return pd.read_csv(path, dtype=str)


def pq_read(path, fs):
    import pyarrow.parquet as pq
    return pq.ParquetDataset(path, filesystem=fs).read().to_pandas()


def parse_model(spec):
    """NAME=PATH[:COLUMN]; the column defaults to score. PATH may be an s3:// path."""
    name, rest = spec.split("=", 1)
    if ":" in rest:
        path, col = rest.rsplit(":", 1)
        if path and "/" not in col and not col.endswith((".parquet", ".csv")):
            return name, path, col
    return name, rest, "score"


def build(a):
    rows = read_any(a.rows)
    for c in (a.id_col, a.label_col):
        if c not in rows:
            raise SystemExit(f"{a.rows} has no column {c}")
    rows = rows.assign(_id=rows[a.id_col].map(str))
    n_dup = int(rows.duplicated("_id").sum())
    conflicts = int(rows.groupby("_id")[a.label_col].nunique().gt(1).sum())
    if conflicts:
        raise SystemExit(f"{a.rows}: {conflicts} transaction ids appear with different labels")
    rows = rows.drop_duplicates("_id").reset_index(drop=True)
    notes = [f"benchmark rows: {len(rows):,} unique ids" + (f" ({n_dup:,} repeated rows kept once)" if n_dup else "")]
    scores, coverage = {}, {}
    common = set(rows["_id"])
    for spec in a.model:
        name, path, col = parse_model(spec)
        df = read_any(path)
        if a.id_col not in df or col not in df:
            raise SystemExit(f"{path} needs columns {a.id_col} and {col}")
        s = pd.DataFrame({"_id": df[a.id_col].map(str), "_s": pd.to_numeric(df[col], errors="coerce")})
        s = s.dropna()
        dup = int(s.duplicated("_id").sum())
        differ = int(s.groupby("_id")["_s"].nunique().gt(1).sum())
        if dup:
            notes.append(f"{name}: {dup:,} repeated ids kept once" +
                         (f"; {differ:,} of them with different scores (the first is used)" if differ else ""))
        s = s.drop_duplicates("_id")
        scores[name] = s.set_index("_id")["_s"]
        coverage[name] = int(rows["_id"].isin(s["_id"]).sum())
        common &= set(s["_id"])
        if a.account_col in df and a.account_col not in rows:
            rows = rows.merge(df[[a.id_col, a.account_col]].assign(_id=df[a.id_col].map(str))[["_id", a.account_col]]
                              .drop_duplicates("_id"), on="_id", how="left")
    rows = rows[rows["_id"].isin(common)].reset_index(drop=True)
    for name, c in coverage.items():
        notes.append(f"{name}: covers {c:,} benchmark rows")
    notes.append(f"common rows read: {len(rows):,}")
    if rows.empty:
        raise SystemExit("no transaction id is in every file:\n" + "\n".join(notes) +
                         "\ncheck that the id columns hold the same text in every file (for example no '.0' or "
                         "leading zeros lost)")
    y = pd.to_numeric(rows[a.label_col], errors="coerce").to_numpy(float)
    if not np.isin(y, [0, 1]).all():
        raise SystemExit("labels must be 0 or 1 on the common rows")
    amounts = pd.to_numeric(rows[a.amount_col], errors="coerce").to_numpy(float) if a.amount_col in rows else None
    if a.account_col in rows and rows[a.account_col].notna().all():
        accounts = rows[a.account_col].map(str).to_numpy()
        unit = "account"
    else:
        accounts = rows["_id"].to_numpy()
        unit = "transaction"
        notes.append("no account id for every row: the bootstrap resamples transactions, so intervals are too narrow")
    arrays = {n: s.reindex(rows["_id"]).to_numpy(float) for n, s in scores.items()}
    return rows, y.astype(np.int64), amounts, accounts, arrays, notes, unit


def run(a):
    rows, y, amounts, accounts, arrays, notes, unit = build(a)
    key_rank, codes, n_units = R.prepare(accounts, rows["_id"].to_numpy())
    roundings = ("floor", "ceil") if a.rounding == "both" else (a.rounding,)
    table = []
    fits = {}
    for rnd in roundings:
        for name, s in arrays.items():
            f = R.RankedScore(s, y, codes, key_rank, amounts, R.SHARE_06, rnd)
            fits[(name, rnd)] = f
            for pm in SHARES:
                p = f.evaluate(None, share=Fraction(pm, 1000))
                table.append({"model": name, "rounding": rnd, "share": pm / 10, "outsorted": p["outsorted"],
                              "caught": p["frauds_outsorted"], "udr": p["udr"], "vdr": p["vdr"], "fpr": p["fpr"],
                              "ap": p["ap"], "auroc": p["auroc"], "ks": p["ks"]})
    pairs = []
    for spec in a.pair or []:
        left, right = spec.split("-", 1)
        if left not in arrays or right not in arrays:
            raise SystemExit(f"--pair {spec}: both models must be given with --model")
        met = R.paired([fits[(left, roundings[0])]], [fits[(right, roundings[0])]], n_units, a.draws, a.seed,
                       a.interval, metrics=("udr", "vdr", "fpr", "ap", "auroc"))
        pairs.append({"pair": spec, "rounding": roundings[0], "unit": unit,
                      **{m: {k: met[m][k] for k in ("gain", "sd", "lo", "hi")} for m in met}})
    return {"rows": int(len(y)), "frauds": int(y.sum()), "notes": notes, "table": table, "pairs": pairs,
            "bootstrap": {"draws": a.draws, "seed": a.seed, "interval": a.interval, "unit": unit}}


def screen(rec):
    lines = rec["notes"] + [f"rows {rec['rows']:,}  frauds {rec['frauds']:,}",
                            f"{'model':<12}{'round':>6}{'share':>7}{'caught':>8}{'UDR':>8}{'VDR':>8}{'FPR':>7}"
                            f"{'AP':>8}{'AUROC':>8}{'KS':>7}"]
    for r in rec["table"]:
        def f(v, d=4):
            return "n/a" if v is None or not np.isfinite(v) else f"{v:.{d}f}"
        lines.append(f"{r['model']:<12}{r['rounding']:>6}{r['share']:>6.1f}%{r['caught']:>8}{f(r['udr']):>8}"
                     f"{f(r['vdr']):>8}{f(r['fpr'], 2):>7}{f(r['ap']):>8}{f(r['auroc']):>8}{f(r['ks']):>7}")
    for p in rec["pairs"]:
        u = p["udr"]
        lines.append(f"{p['pair']}: UDR at 0.6% {u['gain']:+.4f} (90% [{u['lo']:+.4f}, {u['hi']:+.4f}]), "
                     f"VDR {p['vdr']['gain']:+.4f}, AP {p['ap']['gain']:+.4f} (by {p['unit']})")
    return "\n".join(lines)


def main(argv=None):
    ap = argparse.ArgumentParser(description="our model against 15298 and the PFM on the same rows")
    ap.add_argument("--rows", required=True)
    ap.add_argument("--model", action="append", required=True, help="NAME=PATH[:SCORE_COLUMN]")
    ap.add_argument("--pair", action="append", default=None, help="A-B: paired difference A minus B")
    ap.add_argument("--out", required=True)
    ap.add_argument("--rounding", choices=("floor", "ceil", "both"), default="both")
    ap.add_argument("--draws", type=int, default=2000)
    ap.add_argument("--seed", type=int, default=20261102)
    ap.add_argument("--interval", type=float, default=90.0)
    ap.add_argument("--id-col", default="fi_transaction_id")
    ap.add_argument("--label-col", default="frd_tag")
    ap.add_argument("--amount-col", default="transaction_amt")
    ap.add_argument("--account-col", default="Nmap_account_reference_xid")
    ap.add_argument("--cred", default=None, help="S3 credentials yaml, for s3:// paths")
    a = ap.parse_args(argv)
    FS["cred"] = a.cred
    out = Path(a.out)
    if out.exists():
        raise SystemExit(f"{out} exists; choose a new --out")
    rec = run(a)
    text = screen(rec)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(rec, indent=1, default=float))
    out.with_suffix(".txt").write_text(text + "\n")
    print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
