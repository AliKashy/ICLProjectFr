"""Paired read of an arm against its control on the same rows: per seed, arm minus control.

Where it runs: on the pod, CPU only, from the project root. On RANK-B (about 6.7 million June rows) a one-seed read
takes about half an hour and a three-seed read about an hour and a half (2000 account draws per fit); --draws 200
gives a quick look first.

Measures: UDR at the 0.6% outsort decides (frauds among the top floor(6 N / 1000) rows by score, ties broken by
[account, id], over all frauds). AP, VDR, FPR (false positives per caught fraud), AUROC and KS are reported. Account
bootstrap: 2000 draws, seed 20261102, whole accounts, the same draws for every fit, 90% interval.

Roles:
- decide: a costly change (feature group, training variant, EMA, loss option) by the one-seed or three-seed rule,
  a free setting (--kind free: learning rate, weight decay, dropout, clipping) by the mean-gain rule, or a preferred
  option that stays unless it is worse (--kind not-worse: the calendar inputs).
- select-check: the SELECT check of an ADOPT (AP, AUROC, KS and UDR must not fall below -k x SE).
- unpaired: independently fitted arms (for example 100 files against the 10-file reference), by the Welch rule.
- report: numbers only (Test 1, Test 2, slices).

Rows: the raw files of --files (all rows read, so history months count as history), then the target window
(June 2025 by default). --exclude declines advice drops those rows from the read; --slices adds a table by card
present, same second, history depth, window rows or amount. Without raw files, --keep-ids or --all-rows say which
rows to read.

Example, one seed on RANK-B:

    $PY program/pg_read.py --role decide \
        --control runs/program/control_s42/rank_b.parquet --arm runs/program/declines_out_s42/rank_b.parquet \
        --raw-base <eval raw base> --cred <S3 credentials yaml> --files 8244 8259 \
        --spread-fits <control seed 42, 43, 44 predictions on RANK-B> --out runs/program/reads/declines_rank_b.json

Seeds 43 and 44: repeat --control and --arm once per seed, in the same order. Exit codes: 0 done, 2 bad arguments,
3 the files do not hold the read's rows or labels, 4 a needed input is missing or the output exists.
"""
import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pg_ranked as R  # noqa: E402
import pg_rows  # noqa: E402
import pg_rules  # noqa: E402

DEFAULTS = {"draws": 2000, "seed": 20261102, "interval": 90.0, "bar_udr": 0.01, "k_select": 2.5,
            "k_select_when_select_decides": 3.5, "k_conflict": 2.5, "margin": 0.01}
SLICES = ("card_present", "same_second", "history", "window", "amount")


class Missing(Exception):
    """A needed input is missing (exit 4)."""


def fmt(x, digits=4, sign=True):
    if not pg_rules.finite(x):
        return "n/a"
    return f"{float(x):+.{digits}f}" if sign else f"{float(x):.{digits}f}"


def load_rows(a, c, paths):
    notes = []
    if a.config and not a.raw_base:
        from omegaconf import OmegaConf
        cfg = OmegaConf.load(a.config)
        a.raw_base = OmegaConf.select(cfg, "eval.base") or OmegaConf.select(cfg, "data.val_base")
        a.cred = a.cred or OmegaConf.select(cfg, "s3.cred_path")
    if a.raw_base:
        if not a.files:
            raise Missing("reading raw files needs --files START END")
        numbers = list(range(a.files[0], a.files[1] + 1))
        raw = pg_rows.raw_rows(a.raw_base, numbers, c, a.cred)
        rows = pg_rows.keep_targets(raw, a.targets)
        scope = f"targets {a.targets[0]} to {a.targets[1]} of files {a.files[0]}-{a.files[1]}"
    elif a.keep_ids:
        rows = pg_rows.rows_from_ids(paths, a.keep_ids, c)
        scope = f"the rows listed in {a.keep_ids}"
    elif a.all_rows:
        rows = pg_rows.rows_from_first(paths, c)
        scope = "every row of the first prediction file"
    else:
        raise Missing("say which rows to read: --raw-base (or --config) with --files, --keep-ids, or --all-rows")
    rows, filter_notes = pg_rows.apply_filters(rows, a.exclude, c)
    notes += filter_notes
    if a.exclude:
        scope += ", without " + " and ".join(a.exclude)
    if rows.empty:
        raise pg_rows.DataError("the read has no rows")
    return rows, scope, notes


def spread_from_fits(data, scores, groups):
    """Seed spread per measure from the control model's kept seed fits: SD across fits within each group (ddof 1),
    pooled over groups."""
    for i in range(len(scores)):
        for j in range(i + 1, len(scores)):
            if np.array_equal(scores[i], scores[j]):
                print(f"note: spread fits {i + 1} and {j + 1} give the same scores; check that they are different "
                      "seeds", flush=True)
    points = [f.evaluate(None) for f in pg_rows.ranked(data, scores)]
    out, start = {}, 0
    bounds = []
    for g in groups:
        bounds.append((start, start + g))
        start += g
    for m in R.METRICS:
        ss, df, values = 0.0, 0, []
        for lo, hi in bounds:
            v = np.asarray([points[k][m] for k in range(lo, hi) if pg_rules.finite(points[k][m])], float)
            values.append([float(points[k][m]) for k in range(lo, hi)])
            if len(v) > 1:
                ss += float(((v - v.mean()) ** 2).sum())
                df += len(v) - 1
        out[m] = {"sd_run": math.sqrt(ss / df) if df else None, "df": int(df), "values": values}
    return {"metrics": out}


def slice_table(data, arm_scores, control_scores, names):
    table = []
    for name in names:
        labels = pg_rows.slice_labels(data, name)
        if labels is None:
            table.append({"slice": name, "note": "the column this slice needs is not in the files"})
            continue
        for value in sorted(set(labels.tolist())):
            idx = np.flatnonzero(labels == value)
            frauds = int(data.y[idx].sum())
            row = {"slice": name, "value": value, "rows": int(len(idx)), "frauds": frauds}
            if frauds and len(idx) * 3 // 500:
                arm = [f.evaluate(None) for f in pg_rows.ranked(data, arm_scores, index=idx)]
                ctl = [f.evaluate(None) for f in pg_rows.ranked(data, control_scores, index=idx)]
                for m in ("udr", "ap"):
                    row[f"control_{m}"] = float(np.mean([p[m] for p in ctl]))
                    row[f"arm_{m}"] = float(np.mean([p[m] for p in arm]))
                    row[f"gain_{m}"] = row[f"arm_{m}"] - row[f"control_{m}"]
            table.append(row)
    return table


def run_read(a, c):
    if not a.arm or not a.control:
        raise Missing("give --arm and --control")
    if a.role != "unpaired" and len(a.arm) != len(a.control):
        raise Missing("give one --control and one --arm per seed, in the same seed order")
    paths = list(a.arm) + list(a.control)
    rows, scope, notes = load_rows(a, c, paths)
    groups = [len(g) for g in (a.spread_fits or [])]
    spread_paths = [p for g in (a.spread_fits or []) for p in g]
    data, scores = pg_rows.align(paths + spread_paths, rows, c)
    if int(data.y.sum()) == 0:
        raise pg_rows.DataError("no fraud row in the read's rows")
    na = len(a.arm)
    arm_scores, ctl_scores = scores[:na], scores[na:len(paths)]
    spread_scores = scores[len(paths):]
    arm_fits, ctl_fits = pg_rows.ranked(data, arm_scores), pg_rows.ranked(data, ctl_scores)

    spreads = {}
    for p in a.spread_json or []:
        loaded = json.loads(Path(p).read_text())
        spreads[f"json:{p}"] = loaded.get("spread") or loaded
    if spread_scores:
        spreads["fits"] = spread_from_fits(data, spread_scores, groups)

    rec = {"role": a.role, "kind": a.kind, "rows_read": scope, "notes": notes, "rows": data.rows,
           "frauds": int(data.y.sum()), "accounts": data.n_units,
           "arm_files": [str(Path(p).resolve()) for p in a.arm],
           "control_files": [str(Path(p).resolve()) for p in a.control],
           "bootstrap": {"draws": a.draws, "seed": a.seed, "interval": a.interval},
           "bar_udr": a.bar_udr, "vdr_null_reason": data.amount_reason}
    caught = [f.fraud_accounts_caught() for f in arm_fits + ctl_fits]
    rec["fraud_accounts_caught"] = {"arm": caught[:na], "control": caught[na:]}

    if a.role == "unpaired":
        met = R.unpaired(arm_fits, ctl_fits, data.n_units, a.draws, a.seed, a.interval)
        u = met["udr"]
        rec["metrics"] = met
        rec["rule"] = pg_rules.unpaired_rule(u["difference"], u["a"], u["b"], u["var"], a.margin)
        rec["decision"] = rec["rule"]["decision"]
        rec["reason"] = rec["rule"]["reason"]
        return rec

    met = R.paired(arm_fits, ctl_fits, data.n_units, a.draws, a.seed, a.interval)
    rec["metrics"] = met
    used = {m: dict(zip(("sd_run", "df", "source"), pg_rules.seed_spread(spreads, m))) for m in R.METRICS}
    rec["spread"] = {"metrics": used} if any(v["sd_run"] is not None for v in used.values()) else None
    gain = met["udr"]["gain"]
    n = na
    if a.role == "decide":
        if a.kind == "free":
            decision, reason, changes = pg_rules.decide_free(gain, n)
        elif a.kind == "not-worse":
            decision, reason, changes = pg_rules.decide_not_worse(gain)
        else:
            sd_run, df_run, src = pg_rules.seed_spread(spreads, "udr")
            terms = None
            if n == 1:
                if sd_run is None:
                    raise Missing("a one-seed read needs the control model's UDR seed spread: give --spread-fits "
                                  "(its seed 42, 43 and 44 predictions on the same files) or --spread-json")
                terms = pg_rules.t1_terms(met["udr"]["sd"], sd_run, df_run)
            lb3 = s_d = None
            if n > 1:
                lb3, s_d, t3, df3 = pg_rules.lb_three(gain, met["udr"]["differences"], met["udr"]["var"])
                rec.update(t_three=t3, df_three=df3)
            decision, reason, changes = pg_rules.decide_costly(n, gain, terms["t1"] if terms else None, a.bar_udr,
                                                               met["udr"]["lo"], lb3,
                                                               terms["undefined"] if terms else None)
            rec.update(t1=terms, lb_three_seed=lb3, s_d=s_d,
                       udr_seed_spread={"sd_run": sd_run, "df": df_run, "source": src})
        final, sel = decision, None
        if changes and a.select_decides:
            if any(pg_rules.seed_spread(spreads, m)[0] is None for m in pg_rules.SELECT_METRICS):
                raise Missing("--select-decides runs the SELECT check, which needs each measure's seed spread: give "
                              "--spread-fits (the control's seed fits on these rows) or --spread-json")
            sel = pg_rules.select_check(met, a.k_select_when_select_decides, spreads, n)
            final, why = pg_rules.finalize(decision, sel)
            reason = f"{reason}; {why}"
        rec.update(decision=decision, final=final, reason=reason, select_check=sel,
                   pending_select_check=bool(changes and not a.select_decides),
                   conflict=pg_rules.conflict_line(met, a.k_conflict, spreads, n, data.amount_reason)
                   if changes else None)
    elif a.role == "select-check":
        sel = pg_rules.select_check(met, a.k_select, spreads, n)
        if any(r["s_m"] is None for r in sel["rows"]):
            raise Missing("the SELECT check needs each measure's seed spread: give --spread-fits on SELECT and "
                          "--spread-json with the deciding read's record")
        rec["select_check"] = sel
    if a.slices:
        rec["slices"] = slice_table(data, arm_scores, ctl_scores, a.slices)
    return rec


def screen(rec):
    lines = [f"{rec['role']}: {rec['rows_read']}",
             f"rows {rec['rows']:,}  frauds {rec['frauds']:,}  accounts {rec['accounts']:,}"]
    lines += rec.get("notes") or []
    met = rec["metrics"]
    if rec["role"] == "unpaired":
        lines.append(f"{'measure':<7}{'arm mean':>11}{'ref mean':>11}{'difference':>12}{'boot sd':>10}")
        for m in R.METRICS:
            r = met[m]
            lines.append(f"{m:<7}{fmt(np.mean(r['a']), 6, False):>11}{fmt(np.mean(r['b']), 6, False):>11}"
                         f"{fmt(r['difference'], 6):>12}{fmt(r['sd'], 6, False):>10}")
        lines.append(f"DECISION: {rec['decision']} ({rec['reason']})")
        return "\n".join(lines)
    lines.append(f"{'measure':<7}{'control':>11}{'arm':>11}{'arm-control':>13}{'boot sd':>10}   "
                 f"{int(rec['bootstrap']['interval'])}% interval")
    for m in R.METRICS:
        r = met[m]
        lines.append(f"{m:<7}{fmt(r['control_mean'], 6, False):>11}{fmt(r['candidate_mean'], 6, False):>11}"
                     f"{fmt(r['gain'], 6):>13}{fmt(r['sd'], 6, False):>10}   [{fmt(r['lo'], 6)}, {fmt(r['hi'], 6)}]")
    if len(met["udr"]["differences"]) > 1:
        lines.append("per-seed UDR differences: " + ", ".join(f"{d:+.4f}" for d in met["udr"]["differences"]))
    if rec.get("vdr_null_reason"):
        lines.append(f"VDR is not defined: {rec['vdr_null_reason']}")
    if rec["role"] == "decide":
        if rec.get("t1"):
            t = rec["t1"]
            lines.append(f"T1 {fmt(t['t1'], 4, False)} = t {fmt(t['t'], 3, False)} x sqrt(sd_pair^2 + 2 sd_run^2); "
                         f"seed spread {fmt(rec['udr_seed_spread']['sd_run'], 4, False)}")
        if rec.get("lb_three_seed") is not None:
            lines.append(f"LB_3 {rec['lb_three_seed']:+.4f} (s_d {rec['s_d']:.4f})")
        lines.append(f"DECISION: {rec['final']}  ({rec['reason']})")
        if rec.get("pending_select_check"):
            lines.append("next: the SELECT check (--role select-check on files 8206-8216) makes it final")
        if rec.get("conflict"):
            lines.append(rec["conflict"])
    if rec.get("select_check"):
        sc = rec["select_check"]
        for r in sc["rows"]:
            lines.append(f"  {r['metric']:<6} difference {fmt(r['difference'])}  limit {fmt(r['limit'])}  "
                         f"{'pass' if r['pass'] else 'FAIL'}")
        lines.append(f"SELECT CHECK: {'PASS' if sc['pass'] else 'FAIL'}")
    for row in rec.get("slices") or []:
        if "note" in row:
            lines.append(f"slice {row['slice']}: {row['note']}")
        elif "gain_udr" in row:
            lines.append(f"slice {row['slice']}={row['value']}: rows {row['rows']:,} frauds {row['frauds']}  "
                         f"UDR {row['control_udr']:.4f} -> {row['arm_udr']:.4f} ({row['gain_udr']:+.4f})  "
                         f"AP {row['control_ap']:.4f} -> {row['arm_ap']:.4f}")
        else:
            lines.append(f"slice {row['slice']}={row['value']}: rows {row['rows']:,} frauds {row['frauds']} "
                         "(too few for the outsort)")
    return "\n".join(lines)


def parser():
    ap = argparse.ArgumentParser(description="paired read of an arm against its control")
    ap.add_argument("--role", choices=("decide", "select-check", "unpaired", "report"), required=True)
    ap.add_argument("--kind", choices=("costly", "free", "not-worse"), default="costly",
                    help="costly: the bar and the interval; free: mean gain above zero; not-worse: mean gain zero "
                         "or above (the calendar inputs)")
    ap.add_argument("--control", action="append", default=None, help="control predictions, one per seed")
    ap.add_argument("--arm", action="append", default=None, help="arm predictions, one per seed, same order")
    ap.add_argument("--out", required=True, help="JSON record; refused if it exists (a .txt screen goes beside it)")
    ap.add_argument("--config", default=None, help="a training config: its eval.base and s3.cred_path are used")
    ap.add_argument("--raw-base", default=None)
    ap.add_argument("--cred", default=None, help="S3 credentials yaml for an s3:// raw base")
    ap.add_argument("--files", type=int, nargs=2, default=None, metavar=("START", "END"))
    ap.add_argument("--targets", nargs=2, default=list(pg_rows.TARGETS), metavar=("FROM", "BEFORE"))
    ap.add_argument("--exclude", nargs="+", choices=("declines", "advice"), default=None)
    ap.add_argument("--keep-ids", default=None)
    ap.add_argument("--all-rows", action="store_true")
    ap.add_argument("--spread-fits", action="append", nargs="+", default=None,
                    help="the control model's seed fits on the same files (a group of 2 or more; repeat to pool)")
    ap.add_argument("--spread-json", action="append", default=None, help="an earlier read's JSON (its spread)")
    ap.add_argument("--select-decides", action="store_true")
    ap.add_argument("--slices", nargs="+", choices=SLICES, default=None)
    ap.add_argument("--bar-udr", type=float, default=DEFAULTS["bar_udr"])
    ap.add_argument("--margin", type=float, default=DEFAULTS["margin"], help="unpaired role: tolerated UDR loss")
    ap.add_argument("--k-select", type=float, default=DEFAULTS["k_select"])
    ap.add_argument("--k-select-when-select-decides", type=float, default=DEFAULTS["k_select_when_select_decides"])
    ap.add_argument("--k-conflict", type=float, default=DEFAULTS["k_conflict"])
    ap.add_argument("--draws", type=int, default=DEFAULTS["draws"])
    ap.add_argument("--seed", type=int, default=DEFAULTS["seed"])
    ap.add_argument("--interval", type=float, default=DEFAULTS["interval"])
    for name, default in vars(pg_rows.COLUMNS).items():
        if isinstance(default, str):
            ap.add_argument(f"--{name.replace('_', '-')}-col", dest=f"col_{name}", default=default)
    return ap


def columns_from(a):
    c = pg_rows.COLUMNS
    out = type(c)(**vars(c))
    for name in vars(c):
        v = getattr(a, f"col_{name}", None)
        if v is not None:
            setattr(out, name, v)
    return out


def main(argv=None):
    a = parser().parse_args(argv)
    c = columns_from(a)
    out = Path(a.out)
    try:
        if out.exists():
            raise Missing(f"{out} exists; choose a new --out")
        rec = run_read(a, c)
    except Missing as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 4
    except pg_rows.DataError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 3
    text = screen(rec)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(rec, indent=2, default=float))
    out.with_suffix(".txt").write_text(text + "\n")
    print(text)
    print(f"record: {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
