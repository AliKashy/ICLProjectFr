"""The one run: the best configuration, trained for a number of hours. It starts pg_train.py with every training
option of the best run (program/BEST_RUN.md), so that only the hours, the config and the model settings are given.

Where it runs: on the pod (the GPU), from the project root.

Usage, everything after `--` going to the project's trainer unchanged:

    $PY program/pg_best.py --hours H -- --config $CFG <model settings> output.checkpoint_dir=runs/program/best_seed42

What it gives pg_train.py:
  --files-list            every file of the pool: 1 to 5000 without 4001-4010 and 4950-4954, written to
                          files_pool.txt in the run folder (--files-list FILE here gives another list)
  --train-hours H         the run ends after H hours; the learning rate follows the clock
  --lr-warmup-updates 2000 --lr-cooldown-share 0.2     the config's rate is the peak; the last fifth of the hours
                          falls to 0
  --clean-account-share 0.25     every fraud counts; a non-fraud row counts with probability 0.25
  --loss-mask declines    declined rows stay as history, without loss
  --no-month              the month is switched off (the scored month is never in training); --keep-month here
                          leaves the month as the config has it
  --grad-clip 1.0 --ema-decay 0.9995
  --val-every-updates 10000 --limit-val-batches 200

Any option of pg_train.py given before `--` is passed on and takes the place of the value above (for example
--local-dir DIR, --val-every-updates 5000, --clean-account-share 0.5). --print shows the command and starts
nothing. The model settings (the number of summary tokens, the width of stage 2) are config overrides after `--`,
under the names the project's config uses.
"""
import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pg_files  # noqa: E402
import pg_train  # noqa: E402

POOL_MAX = 5000  # the training files are numbered 1 to 5000
BEST = (("--no-month", []), ("--loss-mask", ["declines"]), ("--clean-account-share", ["0.25"]),
        ("--grad-clip", ["1.0"]), ("--ema-decay", ["0.9995"]), ("--lr-warmup-updates", ["2000"]),
        ("--lr-cooldown-share", ["0.2"]), ("--val-every-updates", ["10000"]), ("--limit-val-batches", ["200"]))


def pool_files(pool_max=POOL_MAX):
    """Every training file that may be trained on: the reserved files (downstream training, epoch validation) are
    left out."""
    return [n for n in range(1, pool_max + 1) if n not in pg_files.RESERVED]


def command(ours, rest):
    """(the arguments for pg_train.main, the parsed options of this tool). Options of pg_train.py among `ours`
    are passed on and take the place of the best run's value of the same name."""
    ap = argparse.ArgumentParser(description="the one run: the best configuration, trained for a number of hours",
                                 allow_abbrev=False)  # a shortened name is never taken for one of this tool's options
    ap.add_argument("--hours", type=float, required=True, help="the run ends after this many hours")
    ap.add_argument("--files-list", default=None, help="a list of training files instead of the whole pool")
    ap.add_argument("--keep-month", action="store_true", help="leave the month input as the config has it")
    ap.add_argument("--print", action="store_true", dest="show", help="show the command and start nothing")
    a, passed = ap.parse_known_args(ours)
    outs = [x for x in rest if x.startswith(pg_train.OUT_PREFIX)]
    if len(outs) != 1 or "--config" not in rest:
        raise SystemExit("give --config and exactly one output.checkpoint_dir=... after --")
    files = a.files_list
    if not files:
        out_dir = outs[0][len(pg_train.OUT_PREFIX):].strip()
        os.makedirs(out_dir, exist_ok=True)
        files = os.path.join(out_dir, "files_pool.txt")
        numbers = pool_files()
        Path(files).write_text("\n".join(str(n) for n in numbers) + "\n")
        print(f"training files: the whole pool, {len(numbers):,} files ({numbers[0]} to {numbers[-1]} without the "
              f"reserved ones), listed in {files}", flush=True)
    options = ["--train-hours", f"{a.hours:g}", "--files-list", files]
    for name, value in BEST:
        if name == "--no-month" and a.keep_month:
            continue
        if not any(x == name or x.startswith(name + "=") for x in passed):  # given by hand: that value is used
            options += [name, *value]
    return options + passed + ["--"] + list(rest), a


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    ours, rest = pg_train.split_argv(argv)
    full, a = command(ours, rest)
    print("the command:\n    $PY program/pg_train.py " + " ".join(full), flush=True)
    if a.show:
        return 0
    return pg_train.main(full)


if __name__ == "__main__":
    sys.exit(main())
