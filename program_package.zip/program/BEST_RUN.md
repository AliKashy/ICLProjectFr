# The best configuration, and the two runs that get it

This file says what the model should be, why (with the source of every choice), and the exact commands for a
weekend with one deadline. It uses `pg_train.py` with two new options, `--lr-warmup-updates` and
`--lr-cooldown-share`. `$PY`, `$CFG` and the paths are the ones of `PROGRAM.md`.

## The configuration

What changes from the current network (about 129 fields at width 48, 3 summary tokens, stage 2 at 144, the
re-read block) is marked NEW.

| Part | Setting | Why |
|---|---|---|
| Field embedding width | 48 (unchanged) | Engineered fields need small embeddings; one payment model searched 4 to 128 (arXiv 2511.08939, sec. 3.1). In a click-prediction sweep the gains flatten at 64 (2208.08489, Fig. 9). Here width 96 costs 3.20 times the arithmetic for 1.32 times the weights (modelled). |
| Summary tokens per transaction | NEW: 6 (was 3), so one transaction hands 288 numbers to history instead of 144 | Several tokens per transaction: +19.2% against +7.3% for one vector (2511.08939, Table 4). One embedding made 10 times wider lowered test AUC, the same capacity split into several raised it (2310.04400, Table 1). No source compares 3 with 6; 6 is the largest step that keeps the arithmetic near 1.3 times. |
| Stage 2 | NEW: width 288; 4 blocks, 8 heads | It runs at the width of the hand-off. This is the cheapest capacity in the model: 1.28 times the arithmetic (modelled). |
| Stage 1 | 2 blocks, 8 heads (unchanged) | One more block costs 1.43 times the arithmetic for 1.02 times the weights (modelled). |
| Re-read block | on (unchanged) | Reading the scored row's fields again after history: +14.6% against +7.3% without it (2511.08939, Table 4). |
| Head, history | linear head; 20 rows; every position trained (unchanged) | No evidence for a larger head. One target per window was worse in the project's own runs. |
| Size | NEW: about 4.2 million weights (was about 1.15 million, both modelled) | For models trained on the label alone, the evidence supports a few million weights; larger published models were pretrained first. |
| Learning rate | NEW: warm-up, the config's rate, then a fall to 0 over the last 20% of the updates | A constant rate with a 20% cooldown matches the best cosine schedule of the same length (2405.18392, Figs. 3 to 5). The plateau rule cannot act in a run of one pass, so such a run ends at the rate it started with. |
| Gradient clipping | NEW: 1.0 | The standard setting of a recent benchmark of optimizers on tabular data (2604.15297, sec. 3.1). |
| Weight decay, dropout, batch, precision | unchanged | No evidence that a change helps, and each is a risk without a trial. |
| Length | NEW: one pass, a fixed number of updates, no early stopping | Repeated passes overfit in the small runs, and validation on the training months says little about a later month. |
| Clean accounts | NEW: every fraud counts; a non-fraud row counts with probability 0.25 (accounts without fraud are kept at that share) | Information grows with the number of frauds, not of rows, and nothing is lost while the kept non-frauds far outnumber the frauds (2006.00683). The ranking needs no correction; where probabilities are used, add log(0.25) to the logit. |
| Declined rows | NEW: no loss, kept as history | The comparison leaves them out, so a loss on them teaches the wrong boundary. |
| Month | unchanged in training; decided at scoring | The scored month was never trained. Whether to set it to the last trained month is chosen on rows outside the final comparison. |

Best setting, but not for a run that cannot be repeated: numbers as a signed log plus quantile bins (2203.05556,
Table 6), a trained "unknown" value for code fields, 32-bit training. Each needs new preprocessing or a trial.

## Before either run (15 minutes)

1. What the earlier long run ended on. Its rate and its options are in its checkpoint:

       $PY -c "import torch; c = torch.load('<long run>/last.ckpt', map_location='cpu', weights_only=False); print(c['global_step'], c['optimizer_states'][0]['param_groups'][0]['lr'], c.get('program_settings'))"

2. A list of files that run has not seen (one number per line), leaving out 4001-4010 and 4950-4954.
3. Time per update. Add `--profile-steps 200` to the command of the run; `profile.json` then holds
   `mean_wait_seconds` and `mean_step_seconds`.

       updates that fit = 0.85 x hours x 3600 / (mean_wait_seconds + mean_step_seconds) / accumulate_grad_batches

   The 0.85 leaves room for validation. Round down to a multiple of `--val-every-updates`: the last validation and
   `last.ckpt` then fall on the last update, when the rate is 0.
4. The first lines of the profile run print what the data options did ("program data options, first training
   file ..."). Every fraud must still carry a loss, and a mask whose column is missing says so.

## Run A: cool down the model that exists (the safe run)

The same model, the same data options and the same overrides as the earlier long run; started from its weights;
on files it has not seen; the rate falls from the rate that run ended on to 0.

    $PY program/pg_train.py --init-from <long run>/last.ckpt --files-list <unseen files> \
        <the data options of the long run, unchanged> --grad-clip 1.0 --ema-decay 0.9995 \
        --max-steps <N> --lr-warmup-updates 500 --lr-cooldown-share 1.0 \
        --val-every-updates <N / 5> --limit-val-batches 200 \
        -- --config $CFG <the overrides of the long run> training.learning_rate=<the rate it ended on> \
        training.max_epochs=1000 training.early_stopping_patience=100000 \
        output.checkpoint_dir=runs/program/cooldown_seed42

- N: 5% to 10% of the long run's updates, and no more than fits in the hours given to it.
- `--lr-cooldown-share 1.0` starts the fall right after the 500 warm-up updates. The warm-up is there because the
  optimizer starts without its running averages.
- `training.max_epochs=1000` lets `--max-steps` end the run. With 1, the run would stop at the end of the file
  list, possibly before the rate reaches 0.
- What the evidence covers: cooling a run that trained at a constant rate. What it does not cover: a run whose
  rate had already fallen (step 1 shows it; then the gain is smaller), and a change of data options during the
  cooldown (so they stay as they were).

## Run B: the configuration above, from scratch

    $PY program/pg_train.py --files-list <all files of the pool> --clean-account-share 0.25 --loss-mask declines \
        --grad-clip 1.0 --ema-decay 0.9995 --max-steps <N> --lr-warmup-updates 2000 --lr-cooldown-share 0.2 \
        --val-every-updates 10000 --limit-val-batches 200 \
        -- --config $CFG <the two model settings: 6 summary tokens, stage 2 at width 288> \
        training.max_epochs=1000 training.early_stopping_patience=100000 \
        output.checkpoint_dir=runs/program/best_seed42

- The two model settings are whatever the config calls the number of summary tokens and the width of stage 2.
- The profile run of step 3, with these settings, is also the test that the new shape runs at all.
- A run cut short still leaves `last.ckpt` at its latest validation and `best_ema.ckpt`, but its rate has not
  come down; it cannot be continued from inside a pass.

## What to score

`last.ckpt` of each run: the weights of the last update. `best_ema.ckpt` is chosen by validation and is the
fallback for a run that was cut short. Score whole files, never sampled rows, and decide between runs on many
frauds of the scored month before the final comparison is read once.

## What is and is not shown

Shown by the sources: the direction of each choice above. Not shown: that Run B, trained on part of a pass,
beats Run A. Run B has the larger capacity and the full recipe; Run A has seen more frauds. Both are scored.
