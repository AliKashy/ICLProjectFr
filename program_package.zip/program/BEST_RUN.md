# The best run: one configuration, one command

This file says what the one model should be, why (with the source of every choice), and the command that trains
it for a number of hours. `$PY`, `$CFG` and the paths are the ones of `PROGRAM.md`.

## The configuration

The current model: about 129 fields at width 48, 2 transaction blocks, 3 summary tokens, stage 2 at width 144 with
4 blocks, 8 heads, feed-forward multiplier 4, the re-read block, numbers in 16 bins, amount power 0.15, history
120, every position a target, learning rate 3e-4, 2,500 training files, seed 42. CHANGE marks what the best run
changes.

| Setting | Best run | Why |
|---|---|---|
| Field embedding width | 48 (kept) | Engineered fields need small embeddings; one payment model searched 4 to 128 (arXiv 2511.08939, sec. 3.1). In a click-prediction sweep the gains flatten at 64 (2208.08489, Fig. 9). Here width 96 costs 3.20 times the arithmetic for 1.32 times the weights (modelled). |
| Summary tokens per transaction | CHANGE: 6 (was 3), so one transaction hands 288 numbers to history instead of 144 | Several tokens per transaction: +19.2% against +7.3% for one vector (2511.08939, Table 4). One embedding made 10 times wider lowered test AUC, the same capacity split into several raised it (2310.04400, Table 1). No source compares 3 with 6: this is the least proven change. It is the largest step that keeps the arithmetic near 1.3 times. |
| Stage 2 | CHANGE: width 288; 4 blocks, 8 heads (kept) | It runs at the width of the hand-off. This is the cheapest capacity in the model. |
| Transaction blocks | 2, 8 heads, multiplier 4 (kept) | One more block costs 1.43 times the arithmetic for 1.02 times the weights (modelled). |
| Re-read block | on (kept) | Reading the scored row's fields again after history: +14.6% against +7.3% without it (2511.08939, Table 4). |
| Number encoding | 16 bins, amount power 0.15 (kept) | Bins are the better way to feed numbers to a transformer (average rank 5.9 with one weight per number, 4.4 with quantile bins; 2203.05556, Table 6). The model already has them; a change of the bins or the power needs a trial. |
| History, targets, seed | 120 rows, every position a target, seed 42 (kept) | A scored June row has about 40 to 78 earlier rows, inside what training shows. One target per window was worse in the project's own runs. |
| Size | CHANGE: about 3.07 million weights more than today (modelled at history 120: 1,164,002 becomes 4,237,682), for 1.29 times the arithmetic per row | For models trained on the label alone, the evidence supports a few million weights; larger published models were pretrained first. |
| Learning rate | CHANGE: 3e-4 as the peak; warm-up 2,000 updates; the last 20% of the hours fall to 0 | A constant rate with a 20% cooldown matches the best cosine schedule of the same length (2405.18392, Figs. 3 to 5). The plateau rule cannot act in a run of one pass, so such a run ends at the rate it started with, and its last checkpoint is a noisy one. |
| Gradient clipping | CHANGE: 1.0 | The standard setting of a recent benchmark of optimizers on tabular data (2604.15297, sec. 3.1). |
| Weight decay, dropout, batch, precision | kept | No evidence that a change helps, and each is a risk without a trial. |
| Training files | CHANGE: the whole pool, 4,985 files (1 to 5000 without 4001-4010 and 4950-4954) | Each fraud is seen once, and a full pass holds about twice the frauds of 2,500 files. With a quarter of the non-fraud rows a file costs the GPU about a third of what it did, so the same hours reach more frauds. When the hours end before the pass, the run stops where it is, with the rate at 0. |
| Non-fraud rows | CHANGE: every fraud counts; a non-fraud row counts with probability 0.25 (accounts without fraud are kept at that share) | Information grows with the number of frauds, not of rows, and nothing is lost while the kept non-frauds far outnumber the frauds (2006.00683). The ranking needs no correction; where probabilities are used, add log(0.25) to the logit. |
| Declined rows | CHANGE: no loss, kept as history | The comparison leaves them out, so a loss on them teaches the wrong boundary. |
| Length and stopping | CHANGE: a number of hours on the clock; no early stopping; the weights of the last update are scored | Validation on the training months says little about a later month, so it should not end the run or choose the checkpoint. |
| Month | kept in training; CHANGE at scoring: June rows are read with May as their month (`--month-map 6=5`) | The scored month was never trained: without the map, a June row's month enters as a value no training row had. |

## The command

    $PY program/pg_best.py --hours <H> -- --config $CFG <the model settings> \
        output.checkpoint_dir=runs/program/best_seed42

- `<H>`: the hours until the run must end. Scoring comes after it and takes its own time.
- `<the model settings>`: 6 summary tokens and stage 2 at width 288, as config overrides under the names the
  project's config uses. Where stage 2 takes its width from the number of summary tokens, the first is enough.
- Everything else of the table is set by `pg_best.py`; it prints the full `pg_train.py` command it starts.
  `--print` shows that command and starts nothing. Any `pg_train.py` option placed before `--` is passed on and
  replaces the value of the same name (for example `--local-dir DIR`, `--val-every-updates 5000`).

First a try of five minutes, in another folder. It shows that the new shape runs and what the data options did:

    $PY program/pg_best.py --hours 0.1 --profile-steps 200 -- --config $CFG <the model settings> \
        output.checkpoint_dir=runs/program/best_try

It must print three things: the line "program data options, first training file ..." with every fraud carrying a
loss ("frauds with a loss a of a") and no "NO column" note; the line "clock plan: 0.1 hours from now ..."; and
the line "profile: ..." with `rows_per_second`. When the profile's `reading` says that the GPU waits for data, the
long run gets more loader workers (`training.num_workers=<more>` after `--`) or a local copy of the files
(`pg_cache.py`, then `--local-dir`): with a quarter of the non-fraud rows the GPU finishes a file about three times
sooner than before, so the loader has to deliver files that much faster.

## What the run prints and leaves

- At the start: `clock plan: H hours from now; peak learning rate ...`.
- At every validation: `clock plan: update N, x of H hours, learning rate ...`.
- When the hours are over: `clock plan: the H hours are over at update N; the learning rate is 0`, one more
  validation, then `clock plan: final.ckpt holds the weights of the last update (N); the plan ran to its end`.
- In the run folder: `final.ckpt` (the weights of the last update: the checkpoint to score), `last.ckpt` (the
  latest validation; the same weights when the run ended by the clock), `clock.ckpt` (the latest weights, written
  every 30 minutes and when the run is stopped by hand), `best.ckpt` and `best_ema.ckpt` (chosen by validation).
- When the file list ends before the hours, the next pass over the same files starts; the clock still ends the run.

## Scoring

    $PY program/pg_score.py --config $CFG <the model settings> --checkpoint runs/program/best_seed42/final.ckpt \
        --out runs/program/best_seed42/<population>.parquet --population OTHER --purpose program \
        --month-map 6=5 eval.base=$EVAL_RAW eval.file_start=<first> eval.file_end=<last>

`--month-map 6=5` belongs to every scoring and every export of this model on June rows (`pg_export.py` takes the
same option). The same checkpoint scored without it is the comparison that shows what the map does; that
comparison is read on rows outside the final one.

## If the run is cut

- Stopped by hand or by the workbench: `clock.ckpt` holds weights at most 30 minutes old, at a rate that had not
  come down. `best_ema.ckpt`, the averaged weights at the best validation, is the better one to score then.
- To train on from a cut run: the same command in a new folder with `--init-from <cut run>/clock.ckpt`, the
  hours that remain, `--lr-warmup-updates 500` and `training.seed=43` after `--` (the files then come in another
  order). The optimizer starts fresh; the plan starts again for the new hours.
- `$PY program/pg_card.py <run folder> --checkpoint final.ckpt` shows on one screen what a run was: the updates,
  the hours of the plan, the rate at the end, the weights by part, the validation figures.

## With a second GPU: cool down the model that exists

The same model, the same data options and the same overrides as the earlier long run; started from its weights; on
files it has not seen; the rate falls from the rate that run ended on to 0 over the hours given.

    $PY program/pg_train.py --init-from <long run>/last.ckpt --files-list <unseen files> \
        <the data options of the long run, unchanged> --grad-clip 1.0 --ema-decay 0.9995 \
        --train-hours <H> --lr-warmup-updates 500 --lr-cooldown-share 1.0 \
        --val-every-updates 10000 --limit-val-batches 200 \
        -- --config $CFG <the overrides of the long run> training.learning_rate=<the rate it ended on> \
        output.checkpoint_dir=runs/program/cooldown_seed42

- `--lr-cooldown-share 1.0` starts the fall right after the 500 warm-up updates. The warm-up is there because the
  optimizer starts without its running averages.
- 5% to 10% of the long run's hours are enough.
- What the evidence covers: cooling a run that trained at a constant rate. What it does not cover: a run whose
  rate had already fallen (`pg_card.py` shows it; then the gain is smaller), and a change of data options during
  the cooldown (so they stay as they were).

## What is and is not shown

Shown by the sources: the direction of each choice above. Not shown: the size of the gain on this data, and that
6 summary tokens beat 3. The run is scored on whole files, never on sampled rows, and the final comparison is read
once.
