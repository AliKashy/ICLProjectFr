"""Optional diagnostics of the exported vector. None of them decides anything; the downstream arms decide whether the
vector is useful.

Where it runs: on the pod, CPU only.

- rank: effective rank (exp of the entropy of the normalized singular values of the centered vectors) on all rows,
  non-fraud rows, fraud rows, account means (between accounts) and deviations from the account mean (within
  accounts), for the full vector and for the 47 coordinates the head ignores (o_ columns from pg_derive). An account
  bootstrap gives a 90% interval.
- cka: linear CKA between two exports joined on the transaction id (seed 42 against seed 43, or ours against the
  PFM's embedding), with a shuffled-rows baseline (what CKA gives with no correspondence) and an account bootstrap.
- align: orthogonal Procrustes from one export's vectors to another's (fit on half the accounts, R^2 on the other
  half); writes the aligned vectors, so a downstream model fitted on one seed can be read with another (swap test).
- probe: the 7-day probe. On non-fraud rows from 1 to 23 June, does the vector say whether the same account has a
  fraud in the next 7 days? Cohort A: the account has had no fraud yet; cohort B: after its first fraud. Inputs:
  score only, score + the 47 coordinates, the full vector (and --other columns if given). Logistic regression,
  cross-fitted on two halves of the accounts; AP with an account bootstrap and a shuffled-label baseline.

Usage:
    $PY program/pg_diagnostics.py rank --export ds_select.parquet [--derived ds_select_derived.parquet]
    $PY program/pg_diagnostics.py cka --export seed42.parquet --other seed43.parquet [--other-prefix e_]
    $PY program/pg_diagnostics.py align --export seed42.parquet --other seed43.parquet --out aligned.parquet
    $PY program/pg_diagnostics.py probe --export ds_select.parquet --derived ds_select_derived.parquet
"""
import argparse
import json
import sys

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

ID, ACCOUNT, TIME, LABEL = "fi_transaction_id", "Nmap_account_reference_xid", "transaction_dttm", "frd_tag"


def cols_with(df, prefix):
    c = [x for x in df.columns if x.startswith(prefix) and x[len(prefix):].isdigit()]
    return sorted(c, key=lambda x: int(x[len(prefix):]))


def effective_rank(x):
    x = np.asarray(x, np.float64)
    if len(x) < 2:
        return float("nan")
    s = np.linalg.svd(x - x.mean(axis=0), compute_uv=False)
    p = s / s.sum()
    p = p[p > 0]
    return float(np.exp(-(p * np.log(p)).sum()))


def account_draws(accounts, draws, seed):
    codes, units = pd.factorize(pd.Series(accounts).astype(str))
    rng = np.random.default_rng(seed)
    for _ in range(draws):
        pick = rng.integers(0, len(units), len(units))
        mult = np.bincount(pick, minlength=len(units))
        yield np.repeat(np.arange(len(codes)), mult[codes])


def rank_readings(df, cols, draws=100, seed=7, sample=200_000):
    if len(df) > sample:
        df = df.sample(n=sample, random_state=seed)
    x = df[cols].to_numpy(np.float64)
    y = df[LABEL].to_numpy() if LABEL in df else np.zeros(len(df))
    acct = df[ACCOUNT].astype(str).to_numpy()
    means = pd.DataFrame(x).groupby(acct).transform("mean").to_numpy()
    readings = {"all rows": x, "non-fraud rows": x[y == 0], "fraud rows": x[y == 1],
                "between accounts": pd.DataFrame(x).groupby(acct).mean().to_numpy(), "within accounts": x - means}
    out = {k: {"rank": effective_rank(v), "rows": int(len(v))} for k, v in readings.items()}
    boots = [effective_rank(x[idx]) for idx in account_draws(acct, draws, seed)]
    out["all rows"]["interval_90"] = [float(np.percentile(boots, 5)), float(np.percentile(boots, 95))]
    out["dimensions"] = len(cols)
    return out


def linear_cka(x, y):
    x = x - x.mean(axis=0)
    y = y - y.mean(axis=0)
    num = np.linalg.norm(y.T @ x) ** 2
    return float(num / (np.linalg.norm(x.T @ x) * np.linalg.norm(y.T @ y)))


def joined(a_path, b_path, b_prefix="e_", sample=200_000, seed=7):
    a = pq.read_table(a_path).to_pandas()
    b = pq.read_table(b_path).to_pandas()
    a["_id"], b["_id"] = a[ID].map(str), b[ID].map(str)
    bc = cols_with(b, b_prefix)
    m = a.merge(b[["_id"] + bc].rename(columns={c: f"other_{c}" for c in bc}), on="_id")
    if len(m) > sample:
        m = m.sample(n=sample, random_state=seed)
    return m, cols_with(a, "e_"), [f"other_{c}" for c in bc]


def cka(a_path, b_path, b_prefix="e_", draws=100, seed=7):
    m, ac, bc = joined(a_path, b_path, b_prefix, seed=seed)
    x, y = m[ac].to_numpy(np.float64), m[bc].to_numpy(np.float64)
    point = linear_cka(x, y)
    rng = np.random.default_rng(seed)
    shuffled = [linear_cka(x, y[rng.permutation(len(y))]) for _ in range(20)]
    boots = [linear_cka(x[i], y[i]) for i in account_draws(m[ACCOUNT].to_numpy(), draws, seed)]
    return {"rows": int(len(m)), "cka": point, "interval_90": [float(np.percentile(boots, 5)),
                                                              float(np.percentile(boots, 95))],
            "shuffled_rows_mean": float(np.mean(shuffled))}


def procrustes(src, dst):
    """The orthogonal R minimizing |src_c R - dst_c| on centered data, with the means."""
    ms, md = src.mean(axis=0), dst.mean(axis=0)
    u, _, vt = np.linalg.svd((src - ms).T @ (dst - md))
    return u @ vt, ms, md


def align(a_path, b_path, out_path, seed=7):
    """Map export B's vectors into export A's space; R^2 on held-out accounts."""
    m, ac, bc = joined(a_path, b_path, sample=10 ** 9, seed=seed)
    acct = m[ACCOUNT].astype(str).to_numpy()
    half = pd.util.hash_pandas_object(pd.Series(acct), index=False).to_numpy() % 2 == 0
    x, y = m[bc].to_numpy(np.float64), m[ac].to_numpy(np.float64)
    r, ms, md = procrustes(x[half], y[half])
    pred = (x[~half] - ms) @ r + md
    r2 = 1 - ((pred - y[~half]) ** 2).sum() / ((y[~half] - y[~half].mean(axis=0)) ** 2).sum()
    b = pq.read_table(b_path).to_pandas()
    vec = cols_with(b, "e_")
    b[vec] = ((b[vec].to_numpy(np.float64) - ms) @ r + md).astype(np.float32)
    b.to_parquet(out_path, index=False)
    return {"rows_fitted": int(half.sum()), "rows_held_out": int((~half).sum()), "held_out_r2": float(r2)}


def probe(export, derived=None, other=None, other_prefix="e_", start="2025-06-01", end="2025-06-24",
          horizon_days=7, draws=200, seed=7):
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler
    df = pq.read_table(export).to_pandas()
    if derived:
        d = pq.read_table(derived).to_pandas()
        df = df.merge(d.drop(columns=[c for c in (ACCOUNT, TIME) if c in d]), on=ID, how="left")
    if other:
        o = pq.read_table(other).to_pandas()
        oc = cols_with(o, other_prefix)
        o = o[[ID] + oc].rename(columns={c: f"other_{c}" for c in oc})
        df = df.assign(_k=df[ID].map(str)).merge(o.assign(_k=o[ID].map(str)).drop(columns=[ID]), on="_k",
                                                 how="left").drop(columns=["_k"])
    df[TIME] = pd.to_datetime(df[TIME])
    df = df.sort_values([ACCOUNT, TIME]).reset_index(drop=True)
    acct = df[ACCOUNT].astype(str).to_numpy()
    t = df[TIME].to_numpy().astype("datetime64[s]").astype(np.int64)
    fraud_t = df.loc[df[LABEL] == 1].groupby(df[ACCOUNT].astype(str))[TIME].apply(
        lambda s: np.sort(s.to_numpy().astype("datetime64[s]").astype(np.int64)))
    nxt = np.full(len(df), np.iinfo(np.int64).max)
    first = np.full(len(df), np.iinfo(np.int64).max)
    for a_, times in fraud_t.items():
        idx = np.flatnonzero(acct == a_)
        k = np.searchsorted(times, t[idx], side="right")  # next fraud strictly after
        nxt[idx] = np.where(k < len(times), times[np.minimum(k, len(times) - 1)], np.iinfo(np.int64).max)
        first[idx] = times[0]
    in_window = (df[TIME] >= pd.Timestamp(start)) & (df[TIME] < pd.Timestamp(end))
    rows = in_window.to_numpy() & (df[LABEL].to_numpy() == 0)
    label = (nxt - t <= horizon_days * 86400).astype(int)
    cohort = np.where(t < first, "A: before the first fraud", "B: after the first fraud")
    inputs = {"score only": ["score"], "full vector": cols_with(df, "e_")}
    if cols_with(df, "o_"):
        inputs["score + 47 hidden"] = ["score"] + cols_with(df, "o_")
    else:
        print("note: no o_ columns (give --derived): the 'score + 47 hidden' input is left out", flush=True)
    if other:
        inputs["other"] = [c for c in df.columns if c.startswith("other_")]
    half = (pd.util.hash_pandas_object(pd.Series(acct), index=False).to_numpy() % 2 == 0)
    out = {}
    for name, cols in inputs.items():
        if not cols or any(c not in df for c in cols):
            continue
        x = df[cols].to_numpy(np.float64)
        pred = np.full(len(df), np.nan)
        for fit_half in (True, False):
            fit = rows & (half == fit_half) & np.isfinite(x).all(axis=1)
            app = rows & (half != fit_half) & np.isfinite(x).all(axis=1)
            if label[fit].sum() == 0 or fit.sum() < 10:
                continue
            sc = StandardScaler().fit(x[fit])
            lr = LogisticRegression(max_iter=1000).fit(sc.transform(x[fit]), label[fit])
            pred[app] = lr.predict_proba(sc.transform(x[app]))[:, 1]
        for c in np.unique(cohort[rows]):
            sel = rows & (cohort == c) & np.isfinite(pred)
            if label[sel].sum() == 0:
                continue
            out[f"{name} | {c}"] = probe_ap(label[sel], pred[sel], acct[sel], draws, seed)
    return out


def probe_ap(y, p, accounts, draws, seed):
    from sklearn.metrics import average_precision_score
    point = float(average_precision_score(y, p))
    boots = [float(average_precision_score(y[i], p[i])) for i in account_draws(accounts, draws, seed)
             if y[i].sum() > 0]
    rng = np.random.default_rng(seed)
    shuffled = float(np.mean([average_precision_score(rng.permutation(y), p) for _ in range(20)]))
    return {"rows": int(len(y)), "positives": int(y.sum()), "ap": point,
            "interval_90": [float(np.percentile(boots, 5)), float(np.percentile(boots, 95))] if boots else None,
            "shuffled_label_ap": shuffled}


def main(argv=None):
    ap = argparse.ArgumentParser(description="optional diagnostics of the exported vector")
    ap.add_argument("command", choices=("rank", "cka", "align", "probe"))
    ap.add_argument("--export", required=True)
    ap.add_argument("--derived", default=None)
    ap.add_argument("--other", default=None)
    ap.add_argument("--other-prefix", default="e_")
    ap.add_argument("--out", default=None)
    ap.add_argument("--draws", type=int, default=100)
    a = ap.parse_args(argv)
    if a.command == "rank":
        df = pq.read_table(a.export).to_pandas()
        if a.derived:
            d = pq.read_table(a.derived).to_pandas()
            df = df.merge(d.drop(columns=[c for c in (ACCOUNT, TIME) if c in d]), on=ID, how="left")
        rec = {"full vector": rank_readings(df, cols_with(df, "e_"), a.draws)}
        if cols_with(df, "o_"):
            rec["47 hidden"] = rank_readings(df, cols_with(df, "o_"), a.draws)
    elif a.command == "cka":
        rec = cka(a.export, a.other, a.other_prefix, a.draws)
    elif a.command == "align":
        rec = align(a.export, a.other, a.out)
    else:
        rec = probe(a.export, a.derived, a.other, a.other_prefix, draws=a.draws)
    print(json.dumps(rec, indent=1, default=float))
    if a.out and a.command != "align":
        with open(a.out, "w") as f:
            json.dump(rec, f, indent=1, default=float)
    return 0


if __name__ == "__main__":
    sys.exit(main())
