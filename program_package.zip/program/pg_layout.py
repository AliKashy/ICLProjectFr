"""Finds the chosen model's code: the organized module names first, then the old ones. The two are never mixed.

Runs from the project root: the folder that holds program/ and fraud/ (or PROGRAM_PROJECT_ROOT when set).
The layout is chosen by the base model module alone. fraud.data.sequence_builder exists in both layouts but is a
different builder in each, so it is never used to tell them apart.
"""
import importlib
import os
import sys
from pathlib import Path

ROOT = Path(os.environ.get("PROGRAM_PROJECT_ROOT") or Path(__file__).resolve().parents[1]).resolve()

NAMES = {
    "organized": {
        "base_model": "fraud.sequential_hier_model",
        "target_ending_model": "fraud.sequential_hier_target_ending_model",
        "trainer": "fraud.scripts.train_sequential_hier",
        "scorer": "fraud.scripts.score_sequential_hier",
        "factory": "fraud.sequential_hier_factory",
        "chunk_builder": "fraud.data.sequence_builder",
        "target_ending_data": "fraud.data.target_ending",
        "s3_files": "fraud.data.s3_utils",
    },
    "old": {
        "base_model": "waqas.phase4b.sequential_hier",
        "target_ending_model": "waqas.v2.models",
        "trainer": "waqas.v2.scripts.train_v2",
        "scorer": "waqas.v2.scripts.score_v2",
        "factory": "waqas.phase4b.factory",
        "chunk_builder": "waqas.phase4b.sequence_builder",
        "target_ending_data": "waqas.v2.target_ending",
        "s3_files": "fraud.data.s3_utils",
    },
}


class LayoutError(RuntimeError):
    pass


def put_root_first(root=None):
    root = Path(root or ROOT).resolve()
    for p in (str(root / "src"), str(root)):
        if p in sys.path:
            sys.path.remove(p)
        sys.path.insert(0, p)
    return root


def resolve(roles=("base_model", "target_ending_model", "trainer", "scorer"), root=None):
    """(layout, {role: module}) for the first layout whose base model module exists under the project root."""
    put_root_first(root)
    for layout in ("organized", "old"):
        names = NAMES[layout]
        try:
            base = importlib.import_module(names["base_model"])
        except ModuleNotFoundError as exc:
            if exc.name and names["base_model"].startswith(exc.name):
                continue  # this layout is not here; try the other one
            raise
        if not hasattr(base, "FTTransformerHierModel"):
            raise LayoutError(f"{names['base_model']} has no FTTransformerHierModel")
        return layout, {role: importlib.import_module(names[role]) for role in roles}
    raise LayoutError("neither the organized nor the old layout of the chosen model was found under the project root")


def s3_filesystem(cred_path):
    """The project's S3 filesystem for a credentials file, or None for local files."""
    if not cred_path:
        return None
    _, mods = resolve(roles=("base_model", "s3_files"))
    return mods["s3_files"].make_s3_filesystem(str(cred_path))


def file_paths(base, numbers):
    """part_<n>.parquet paths under base, in the given order, as the project names them."""
    base = str(base).rstrip("/")
    return [f"{base}/part_{int(n)}.parquet" for n in numbers]
