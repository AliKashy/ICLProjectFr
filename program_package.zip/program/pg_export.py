"""Export the score and the 48-number vector of every scored transaction in one pass of the normal scorer.

Where it runs: on the pod, from the project root, on a workbench with a GPU (CPU works, slowly).

The vector is exactly what the fraud head reads: the output of the last sequence block at the transaction's own slot
of its scoring window (the window that ends at the transaction: 20 earlier seconds, at most 32 rows). It is captured
with a forward hook on the head, so the scores are the scorer's own. Each row also gets its account, transaction id,
time, label, amount, the window's row count and score_check: the head re-applied to the stored vector, which equals
the score up to float rounding.

Usage, everything after `--` going to the scorer's config handling unchanged (the same --config and overrides as a
normal scoring run; --checkpoint and --out are this tool's):

    $PY program/pg_export.py --checkpoint runs/program/final_s42/best.ckpt \
        --out runs/program/export/ds_train.parquet -- --config <the run's config> \
        eval.base=<training raw base> eval.file_start=4001 eval.file_end=4010

Populations: DS_TRAIN 4001-4010 (training raw base), DS_SELECT 8217-8227, RANK-B 8244-8259, Test 2's files 8000-8200
(only the benchmark rows are used later) and FINAL 8260-8277 once at the freeze (evaluation raw base). Every row of
the files is exported, history months included; the reading tools keep the June targets.
"""
import argparse
import sys
from pathlib import Path

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pg_layout  # noqa: E402

FLUSH_ROWS = 500_000


def head_input_rows(head_input, batch):
    """The head input at each window's target slot (its last real row)."""
    slot = batch["mask"].sum(1) - 1
    return head_input[torch.arange(head_input.shape[0], device=head_input.device), slot.to(head_input.device)]


def model_inputs(batch, device):
    out = {k: batch[k].to(device) for k in ("continuous", "categorical", "mask")}
    if "time_seq" in batch:
        out["time_seq"] = batch["time_seq"].to(device)
    return out


def export(cfg, checkpoint, out_path, scorer, time_col=None, label_free=False, limit_batches=None):
    time_col = time_col or cfg.data.order_col
    ids = list(cfg.data.get("id_cols", []))
    for c in (cfg.data.account_col, cfg.data.get("tie_break_col", None), time_col):
        if c and c not in ids:
            ids.append(c)
    cfg.data.id_cols = ids
    run = scorer.load_for_scoring(cfg, checkpoint, label_free=label_free) if label_free else \
        scorer.load_for_scoring(cfg, checkpoint)
    model, loader, device = run["model"], run["loader"], run["device"]
    if not run.get("chunk", True):
        raise SystemExit("this exporter serves the chosen (all-position) model")
    keep = list(run["id_cols"]) + ([run["amount_col"]] if run.get("amount_col") else [])
    captured = {}
    handle = model.head.register_forward_pre_hook(lambda m, inp: captured.__setitem__("x", inp[0]))
    writer, buf, total, worst = None, [], 0, 0.0
    width = int(model.hparams.embed_dim)

    def flush():
        nonlocal writer, buf
        if not buf:
            return
        cols = {}
        for key in buf[0]:
            cols[key] = np.concatenate([b[key] for b in buf])
        table = {k: v for k, v in cols.items() if k != "_vec"}
        vec = cols["_vec"]
        for j in range(vec.shape[1]):
            table[f"e_{j}"] = vec[:, j]
        t = _arrow_table(table, time_col)
        if writer is None:
            writer = pq.ParquetWriter(out_path, t.schema)
        writer.write_table(t)
        buf = []

    try:
        for b, batch in enumerate(loader):
            if limit_batches is not None and b >= limit_batches:
                break
            with torch.no_grad():
                logits = model(model_inputs(batch, device))
                e = head_input_rows(captured["x"], batch)
                again = torch.softmax(model.head(e).float(), dim=-1)[:, 1].cpu().numpy()
            slot = (batch["mask"].sum(1) - 1).numpy()
            rows = np.arange(len(slot))
            prob = torch.softmax(logits[torch.arange(len(slot)), torch.as_tensor(slot)].float().cpu(), dim=-1)[:, 1]
            prob = prob.numpy()
            worst = max(worst, float(np.max(np.abs(again - prob))))
            rec = {"score": prob.astype(np.float64), "score_check": again.astype(np.float64),
                   "window_rows": batch["mask"].sum(1).numpy().astype(np.int64),
                   "_vec": e.float().cpu().numpy().astype(np.float32)}
            if not label_free:
                rec[cfg.data.target_col] = batch["target_seq"][torch.as_tensor(rows), torch.as_tensor(slot)].numpy()
            meta = batch.get("meta_seq", {})
            for c in keep:
                rec[c] = np.asarray(meta[c])[rows, slot]
            buf.append(rec)
            total += len(slot)
            if sum(len(x["score"]) for x in buf) >= FLUSH_ROWS:
                flush()
        flush()
    finally:
        handle.remove()
        if writer is not None:
            writer.close()
    print(f"exported {total:,} rows x {width} numbers to {out_path}; largest |head(vector) - score| {worst:.2e}",
          flush=True)
    return {"rows": total, "width": width, "max_score_difference": worst}


def _arrow_table(table, time_col):
    out = {}
    for k, v in table.items():
        if k == time_col:
            import pandas as pd
            out[k] = pa.array(pd.to_datetime(pd.Series(v), utc=True).dt.tz_localize(None))
        elif v.dtype == object:
            # ids and amounts keep their own type (a float amount stays a number); mixed values become text
            try:
                out[k] = pa.array(list(v), from_pandas=True)
            except (pa.ArrowInvalid, pa.ArrowTypeError):
                out[k] = pa.array([None if x is None else str(x) for x in v])
        else:
            out[k] = pa.array(v)
    return pa.table(out)


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if "--" not in argv:
        raise SystemExit("usage: pg_export.py --checkpoint CKPT --out OUT.parquet -- --config CFG [overrides]")
    i = argv.index("--")
    ap = argparse.ArgumentParser(description="export the score and the vector of every scored transaction")
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--label-free", action="store_true", help="do not read the label column")
    ap.add_argument("--limit-batches", type=int, default=None, help="for a quick trial on a few batches")
    a = ap.parse_args(argv[:i])
    rest = argv[i + 1:]
    from omegaconf import OmegaConf
    if "--config" not in rest:
        raise SystemExit("give --config after --")
    cfg = OmegaConf.load(rest[rest.index("--config") + 1])
    dots = [x for x in rest if "=" in x and not x.startswith("-")]
    if dots:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(dots))
    out = Path(a.out)
    if out.exists():
        raise SystemExit(f"{out} exists; choose a new --out")
    out.parent.mkdir(parents=True, exist_ok=True)
    layout, mods = pg_layout.resolve(roles=("base_model", "scorer"))
    export(cfg, a.checkpoint, str(out), mods["scorer"], label_free=a.label_free, limit_batches=a.limit_batches)
    return 0


if __name__ == "__main__":
    sys.exit(main())
