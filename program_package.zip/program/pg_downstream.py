"""Does the vector add anything a downstream tree model cannot get from the score? One learner (XGBoost), fitted on
DS_TRAIN and read on DS_SELECT June targets, with different input sets, compared in pairs on the same rows.

Where it runs: on the pod, CPU (7 cores are enough; minutes to an hour per arm on 8.7 million rows).

Input sets (arms), each a list of column groups:
  raw                      the raw input fields (today's 19 raw inputs by default; --raw-cols to change)
  raw+score                plus our score
  raw+score+vector         plus the 48 numbers           raw+vector          the vector without the score
  raw+score+pca16          plus PCA 16 (from pg_derive)  raw+score+orth      plus the 47 numbers the head ignores
  raw+score+windows        plus the strictly earlier 1/7/30-day account means and deviations (pg_derive)
  offset                   15298's score as the fixed starting point (its logit as XGBoost's base margin); the
                           trees learn only the correction from our score and vector (max_delta_step 1)
  offset_raw               the same starting point, correction from the raw fields (the control for offset)
  raw+pfm, raw+pfm+vector  the PFM's exported embedding columns, without and with our vector
Default pairs: raw+score vs raw, raw+score+vector vs raw+score, raw+vector vs raw+score, offset vs 15298 alone,
offset vs offset_raw, raw+pfm+vector vs raw+pfm (each when both arms ran). Measures and the account bootstrap are
the reads' own (UDR at 0.6% decides; AP, VDR, FPR, AUROC, KS reported).

Rows: the read is on the export's June target rows. Every export row must be found in the derived file and in the
raw files of its own file range (--train-files, --read-files); if not, the tool stops and says how many are missing.
Where 15298 or the PFM covers only part of the rows, the coverage is printed, the offset arms are fitted on the
covered training rows, and every pair is read on the rows both of its arms cover (the row count is printed).

Learner: XGBoost hist, a fixed budget (learning rate 0.05, depth 6, up to 2000 trees, early stopping at 50 on aucpr
over a held-out tenth of DS_TRAIN's accounts), seed 42. --tune N runs N random settings per arm on that split first
(--tune-share: the share of DS_TRAIN accounts used for the search).

Usage:
    $PY program/pg_downstream.py \
        --train-export runs/program/export/ds_train.parquet --train-derived runs/program/export/ds_train_derived.parquet \
        --read-export runs/program/export/ds_select.parquet --read-derived runs/program/export/ds_select_derived.parquet \
        --train-raw-base <training raw base> --train-files 4001 4010 --read-raw-base <eval raw base> \
        --read-files 8217 8227 --cred <S3 credentials yaml> \
        [--incumbent-train 15298_ds_train.parquet:score --incumbent-read 15298_ds_select.parquet:score] \
        [--pfm-train pfm_ds_train.parquet --pfm-read pfm_ds_select.parquet --pfm-prefix emb_] \
        --arms raw raw+score raw+score+vector --out runs/program/reads/downstream_ds_select.json
"""
import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pg_layout  # noqa: E402
import pg_ranked as R  # noqa: E402
import pg_rows  # noqa: E402

ID, ACCOUNT, TIME, LABEL, AMOUNT = "fi_transaction_id", "Nmap_account_reference_xid", "transaction_dttm", "frd_tag", \
    "transaction_amt"
RAW_CONTINUOUS = ["transaction_amt", "external_1_scr", "avlble_merch_day_cash_lmt_amt", "available_daily_cash_limit_amt",
                  "remain_day_merchandise_lmt_amt", "total_available_balance_amt"]
RAW_CATEGORICAL = ["transaction_type_xcd", "segment", "transaction_category_xcd", "transaction_pos_condition_xcd",
                   "avs_request_xcd", "pos_security_xflg", "transaction_pin_verify_xcd", "cardholder_present_xflg",
                   "pos_card_capture_xflg", "cvv_verify_xcd", "authzn_rqst_crypto_valid_xflg", "pos_off_premises_xflg",
                   "pos_terminal_attend_xflg"]
ARMS = ("raw", "raw+score", "raw+score+vector", "raw+vector", "raw+score+pca16", "raw+score+orth",
        "raw+score+windows", "offset", "offset_raw", "raw+pfm", "raw+pfm+vector")
PAIRS = (("raw+score", "raw"), ("raw+score+vector", "raw+score"), ("raw+vector", "raw+score"),
         ("raw+score+pca16", "raw+score"), ("raw+score+orth", "raw+score"), ("raw+score+windows", "raw+score"),
         ("offset", "15298"), ("offset", "offset_raw"), ("raw+pfm+vector", "raw+pfm"))
FIXED = {"learning_rate": 0.05, "max_depth": 6, "min_child_weight": 1.0, "subsample": 0.8, "colsample_bytree": 0.8,
         "reg_lambda": 1.0, "reg_alpha": 0.0}


def read_scores(spec, id_col=ID):
    path, col = (spec.rsplit(":", 1) + ["score"])[:2] if ":" in spec.split("/")[-1] else (spec, "score")
    df = pd.read_parquet(path) if path.endswith(".parquet") else pd.read_csv(path, dtype=str)
    return pd.Series(pd.to_numeric(df[col], errors="coerce").to_numpy(float), index=df[id_col].map(str)).groupby(
        level=0).first()


def frame(export, derived, raw_base, files, cred, raw_cols, incumbent=None, pfm=None, pfm_prefix="emb_",
          june=False, name="export"):
    """The export's rows with the derived columns, the raw fields (typed, from the raw files), 15298's score and the
    PFM's embedding joined on the transaction id. Returns (frame, notes)."""
    notes = []
    df = pq.read_table(export).to_pandas()
    df["_id"] = df[ID].map(str)
    n = len(df)
    if derived:
        d = pq.read_table(derived).to_pandas().drop(columns=[c for c in (ACCOUNT, TIME) if c], errors="ignore")
        df = df.merge(d.assign(_id=d[ID].map(str)).drop(columns=[ID]), on="_id", how="left", indicator=True)
        missing = int((df.pop("_merge") == "left_only").sum())
        if missing:
            raise SystemExit(f"{name}: {missing:,} of {n:,} export rows have no row in the derived file {derived}; "
                             "derive it from the same export")
    if raw_base:
        if not files:
            raise SystemExit(f"{name}: reading raw fields needs the export's own file range (--train-files or "
                             "--read-files)")
        numbers = list(range(files[0], files[1] + 1))
        fs = pg_layout.s3_filesystem(cred) if str(raw_base).startswith(("s3://", "s3a://")) else None
        parts = [pg_rows.read_columns(p, [ID] + list(raw_cols), fs) for p in pg_layout.file_paths(raw_base, numbers)]
        raw = pd.concat(parts, ignore_index=True)
        raw["_id"] = raw[ID].map(str)
        raw = raw.drop(columns=[ID]).drop_duplicates("_id")
        # the raw files' typed columns replace the export's text copies (the export keeps ids and keys only)
        df = df.drop(columns=[c for c in raw.columns if c in df.columns and c not in ("_id", ID, ACCOUNT, TIME, LABEL)])
        df = df.merge(raw, on="_id", how="left", indicator=True)
        missing = int((df.pop("_merge") == "left_only").sum())
        if missing:
            raise SystemExit(f"{name}: {missing:,} of {n:,} export rows are not in the raw files {files[0]}-{files[1]}; "
                             "give the file range the export was made from")
    if incumbent:
        df["incumbent_score"] = read_scores(incumbent).reindex(df["_id"]).to_numpy()
        have = int(np.isfinite(df["incumbent_score"].to_numpy(float)).sum())
        notes.append(f"{name}: 15298 scores for {have:,} of {n:,} rows")
    if pfm:
        p = pd.read_parquet(pfm) if pfm.endswith(".parquet") else pd.read_csv(pfm)
        p = p.assign(_id=p[ID].map(str))
        cols = [c for c in p.columns if c.startswith(pfm_prefix)]
        df = df.merge(p[["_id"] + cols].drop_duplicates("_id").rename(columns={c: f"pfm_{c}" for c in cols}),
                      on="_id", how="left", indicator=True)
        have = int((df.pop("_merge") == "both").sum())
        notes.append(f"{name}: PFM embeddings for {have:,} of {n:,} rows (the others are missing values to the trees)")
    if june:
        t = pd.to_datetime(df[TIME])
        df = df[(t >= pd.Timestamp(pg_rows.TARGETS[0])) & (t < pd.Timestamp(pg_rows.TARGETS[1]))]
    return df.reset_index(drop=True), notes


def groups(df, raw_cols):
    vec = [c for c in df.columns if c.startswith("e_") and c[2:].isdigit()]
    return {"raw": [c for c in raw_cols if c in df.columns], "score": ["score"], "vector": vec,
            "pca16": [c for c in df.columns if c.startswith("pca16_")],
            "orth": [c for c in df.columns if c.startswith("o_") and c[2:].isdigit()],
            "windows": [c for c in df.columns if c.startswith(("w1d_", "w7d_", "w30d_", "dev", "n1d", "n7d", "n30d"))],
            "pfm": [c for c in df.columns if c.startswith("pfm_")]}


def arm_columns(arm, g):
    if arm == "offset":
        return g["score"] + g["vector"]
    if arm == "offset_raw":
        return g["raw"]
    cols = []
    for part in arm.split("+"):
        cols += g[part]
    return cols


def to_matrix(df, cols, categories):
    x = pd.DataFrame(index=df.index)
    for c in cols:
        if c in categories:
            x[c] = pd.Categorical(df[c].map(lambda v: None if v is None or (isinstance(v, float) and math.isnan(v))
                                            else str(v)), categories=categories[c])
        else:
            x[c] = pd.to_numeric(df[c], errors="coerce").astype(np.float32)
    return x


def logit(p):
    p = np.clip(np.asarray(p, float), 1e-6, 1 - 1e-6)
    return np.log(p / (1 - p))


MARGIN = {"kind": "logit"}


def margin_of(scores):
    """XGBoost's starting margin from 15298's score: its logit when the scores are probabilities, else the score."""
    s = np.asarray(scores, float)
    return logit(s) if MARGIN["kind"] == "logit" else s


def uniform_hash(values, seed):
    """A fixed number in [0, 1) per value (the same in every run for the same seed)."""
    key = f"{int(seed) % 10 ** 16:016d}"
    h = pd.util.hash_pandas_object(pd.Series(values, dtype=object).map(str), index=False, hash_key=key)
    return h.to_numpy(np.uint64).astype(np.float64) / float(2 ** 64)


def inner_split(accounts, share=0.1, seed=42):
    """(fit rows, held-out rows): a share of the accounts, whole, is held out for early stopping."""
    u = uniform_hash(pd.Series(accounts).map(str).to_numpy(), seed)
    return u >= share, u < share


def fit_arm(train, cols, categories, offset, params, seed=42, rounds=2000, early=50, tune=0, tune_share=1.0):
    import xgboost as xgb
    y = train[LABEL].to_numpy(np.int64)
    fit_rows, val_rows = inner_split(train[ACCOUNT].to_numpy())
    x = to_matrix(train, cols, categories)
    margin = margin_of(train["incumbent_score"].to_numpy()) if offset else None

    def dm(mask):
        return xgb.DMatrix(x[mask], label=y[mask], base_margin=None if margin is None else margin[mask],
                           enable_categorical=True)

    def train_once(p, fit_mask):
        booster = xgb.train({"objective": "binary:logistic", "eval_metric": "aucpr", "tree_method": "hist",
                             "seed": seed, "nthread": -1, **({"max_delta_step": 1.0} if offset else {}), **p},
                            dm(fit_mask), num_boost_round=rounds, evals=[(dm(val_rows), "valid")],
                            early_stopping_rounds=early, verbose_eval=False)
        return booster, float(booster.best_score)

    best_p, trials = dict(params), []
    if tune:
        rng = np.random.default_rng(seed)
        sub = fit_rows & (inner_split(train[ACCOUNT].to_numpy(), 1.0 - tune_share, seed + 7)[0] | (tune_share >= 1))
        best = -1.0
        for _ in range(int(tune)):
            p = {"learning_rate": float(np.exp(rng.uniform(np.log(0.01), np.log(0.3)))),
                 "max_depth": int(rng.integers(3, 11)), "min_child_weight": float(np.exp(rng.uniform(0, np.log(100)))),
                 "subsample": float(rng.uniform(0.5, 1.0)), "colsample_bytree": float(rng.uniform(0.3, 1.0)),
                 "reg_lambda": float(np.exp(rng.uniform(np.log(1e-3), np.log(10)))),
                 "reg_alpha": float(np.exp(rng.uniform(np.log(1e-3), np.log(10))))}
            _, score = train_once(p, sub)
            trials.append({"params": p, "aucpr": score})
            if score > best:
                best, best_p = score, p
    booster, score = train_once(best_p, fit_rows)
    return booster, {"params": best_p, "inner_aucpr": score, "best_iteration": int(booster.best_iteration),
                     "tuning_trials": len(trials)}


def predict(booster, df, cols, categories, offset):
    import xgboost as xgb
    margin = margin_of(df["incumbent_score"].to_numpy()) if offset else None
    d = xgb.DMatrix(to_matrix(df, cols, categories), base_margin=margin, enable_categorical=True)
    return booster.predict(d, iteration_range=(0, booster.best_iteration + 1))


def run(a):
    raw_cols = a.raw_cols or (RAW_CONTINUOUS + RAW_CATEGORICAL)
    train, n1 = frame(a.train_export, a.train_derived, a.train_raw_base, a.train_files, a.cred, raw_cols,
                      a.incumbent_train, a.pfm_train, a.pfm_prefix, name="training rows")
    read, n2 = frame(a.read_export, a.read_derived, a.read_raw_base, a.read_files, a.cred, raw_cols, a.incumbent_read,
                     a.pfm_read, a.pfm_prefix, june=not a.all_read_rows, name="read rows")
    notes = n1 + n2
    g = groups(train, raw_cols)
    # continuous raw fields stay numbers; the coded fields (and any other text field) are categories
    categories = {c: sorted(set(train[c].dropna().map(str))) for c in raw_cols
                  if c in train and c not in RAW_CONTINUOUS and (c in RAW_CATEGORICAL or train[c].dtype == object)}
    if "incumbent_score" in train:
        vals = pd.concat([train["incumbent_score"], read.get("incumbent_score", pd.Series(dtype=float))])
        vals = vals[np.isfinite(vals.to_numpy(float))]
        MARGIN["kind"] = "logit" if len(vals) and vals.between(0, 1).all() else "raw"
        if MARGIN["kind"] == "raw":
            notes.append("15298's scores are not all between 0 and 1: they are used as the starting margin as they are")
    scores, fits, valid = {}, {}, {}
    all_rows = np.ones(len(read), bool)
    for arm in a.arms:
        offset = arm.startswith("offset")
        if offset and "incumbent_score" not in train:
            notes.append(f"{arm}: skipped (no 15298 scores given)")
            continue
        cols = arm_columns(arm, g)
        if not cols or (("pfm" in arm) and not g["pfm"]):
            notes.append(f"{arm}: skipped (its columns are not in the files)")
            continue
        fit_rows = train
        if offset:
            ok = np.isfinite(train["incumbent_score"].to_numpy(float))
            if not ok.any():
                notes.append(f"{arm}: skipped (no training row has a 15298 score)")
                continue
            fit_rows = train[ok].reset_index(drop=True)
        booster, info = fit_arm(fit_rows, cols, categories, offset, dict(FIXED), tune=a.tune, tune_share=a.tune_share)
        pred = np.full(len(read), np.nan)
        rows = np.isfinite(read["incumbent_score"].to_numpy(float)) if offset and "incumbent_score" in read else all_rows
        if rows.any():
            pred[rows] = predict(booster, read[rows].reset_index(drop=True), cols, categories, offset)
        scores[arm], valid[arm] = pred, rows & np.isfinite(pred)
        fits[arm] = {"columns": len(cols), "fit_rows": int(len(fit_rows)), **info}
        print(f"{arm}: {len(cols)} columns, {info['best_iteration'] + 1} trees, inner aucpr {info['inner_aucpr']:.4f}",
              flush=True)
    if "incumbent_score" in read:
        inc = read["incumbent_score"].to_numpy(float)
        if np.isfinite(inc).any():
            scores["15298"], valid["15298"] = inc, np.isfinite(inc)
    if "score" in read:
        scores["ours"], valid["ours"] = read["score"].to_numpy(float), np.isfinite(read["score"].to_numpy(float))
    y = read[LABEL].to_numpy(np.int64)
    amounts = read[AMOUNT].to_numpy(float) if AMOUNT in read else None
    key_rank, codes, n_units = R.prepare(read[ACCOUNT].to_numpy(), read[ID].to_numpy())

    def ranked_on(name, idx):
        am = None if amounts is None else amounts[idx]
        return R.RankedScore(scores[name][idx], y[idx], codes[idx], key_rank[idx], am)

    points = {}
    for k in scores:
        idx = np.flatnonzero(valid[k])
        points[k] = dict(ranked_on(k, idx).evaluate(None), rows_read=int(len(idx)))
    pairs = []
    for left, right in PAIRS:
        if left in scores and right in scores:
            idx = np.flatnonzero(valid[left] & valid[right])
            if not len(idx) or not y[idx].sum():
                notes.append(f"{left} vs {right}: no common rows with a fraud")
                continue
            met = R.paired([ranked_on(left, idx)], [ranked_on(right, idx)], n_units, a.draws, a.seed, 90.0)
            pairs.append({"pair": f"{left} vs {right}", "rows": int(len(idx)),
                          **{m: {k: met[m][k] for k in ("gain", "sd", "lo", "hi")} for m in ("udr", "ap", "vdr")}})
    return {"read_rows": int(len(y)), "read_frauds": int(y.sum()), "train_rows": int(len(train)), "fits": fits,
            "points": {k: {**{m: p[m] for m in R.METRICS}, "rows_read": p["rows_read"]} for k, p in points.items()},
            "pairs": pairs, "notes": notes}


def screen(rec):
    lines = [f"downstream: trained on {rec['train_rows']:,} rows, read on {rec['read_rows']:,} rows "
             f"({rec['read_frauds']:,} frauds)"] + rec["notes"]
    lines.append(f"{'arm':<20}{'UDR':>8}{'AP':>8}{'VDR':>8}{'FPR':>7}{'AUROC':>8}")
    for k, p in rec["points"].items():
        lines.append(f"{k:<20}{p['udr']:>8.4f}{p['ap']:>8.4f}{p['vdr']:>8.4f}{p['fpr']:>7.2f}{p['auroc']:>8.4f}")
    for p in rec["pairs"]:
        u = p["udr"]
        lines.append(f"{p['pair']} ({p['rows']:,} rows): UDR {u['gain']:+.4f} [{u['lo']:+.4f}, {u['hi']:+.4f}]  "
                     f"AP {p['ap']['gain']:+.4f}")
    return "\n".join(lines)


def main(argv=None):
    ap = argparse.ArgumentParser(description="downstream arms: does the vector add beyond the score")
    ap.add_argument("--train-export", required=True)
    ap.add_argument("--train-derived", default=None)
    ap.add_argument("--read-export", required=True)
    ap.add_argument("--read-derived", default=None)
    ap.add_argument("--train-raw-base", default=None)
    ap.add_argument("--train-files", type=int, nargs=2, default=None, metavar=("START", "END"),
                    help="the file range the training export was made from (DS_TRAIN: 4001 4010)")
    ap.add_argument("--read-raw-base", default=None)
    ap.add_argument("--read-files", type=int, nargs=2, default=None, metavar=("START", "END"),
                    help="the file range the read export was made from (DS_SELECT: 8217 8227; FINAL: 8260 8277)")
    ap.add_argument("--cred", default=None)
    ap.add_argument("--raw-cols", nargs="+", default=None)
    ap.add_argument("--incumbent-train", default=None, help="15298 scores on the training rows: PATH[:COLUMN]")
    ap.add_argument("--incumbent-read", default=None, help="15298 scores on the read rows: PATH[:COLUMN]")
    ap.add_argument("--pfm-train", default=None)
    ap.add_argument("--pfm-read", default=None)
    ap.add_argument("--pfm-prefix", default="emb_")
    ap.add_argument("--arms", nargs="+", default=["raw", "raw+score", "raw+score+vector", "raw+vector"],
                    choices=ARMS)
    ap.add_argument("--all-read-rows", action="store_true", help="read every exported row, not only June targets")
    ap.add_argument("--tune", type=int, default=0)
    ap.add_argument("--tune-share", type=float, default=0.25)
    ap.add_argument("--draws", type=int, default=2000)
    ap.add_argument("--seed", type=int, default=20261102)
    ap.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    out = Path(a.out)
    if out.exists():
        raise SystemExit(f"{out} exists; choose a new --out")
    rec = run(a)
    text = screen(rec)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(rec, indent=1, default=float))
    out.with_suffix(".txt").write_text(text + "\n")
    print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
