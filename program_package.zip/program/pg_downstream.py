"""Does the vector add anything a downstream tree model cannot get from the score? One learner (XGBoost), fitted on
DS_TRAIN and read on DS_SELECT June targets, with different input sets, compared in pairs on the same rows.

Where it runs: on the pod, CPU (7 cores are enough; minutes to an hour per arm on 8.7 million rows).

Input sets (arms), each a list of column groups:
  raw                      the raw input fields (today's 19 raw inputs by default; --raw-cols to change)
  raw+score                plus our score
  raw+score+vector         plus the 48 numbers           raw+vector          the vector without the score
  raw+score+pca16          plus PCA 16 (from pg_derive)  raw+score+orth      plus the 47 numbers the head ignores
  raw+score+windows        plus the strictly earlier 1/7/30-day account means and deviations (pg_derive)
  offset                   15298's score as the fixed starting point (its logit as XGBoost's base margin); the
                           trees learn only the correction from our score and vector (max_delta_step 1)
  offset_raw               the same starting point, correction from the raw fields (the control for offset)
  offset_open              the same starting point, with 15298's margin also among the trees' columns, so the trees
                           can turn it down where our model disagrees; with it our logit, the vector, the raw
                           fields and 15298's own inputs; no max_delta_step
  flipped                  our logit as the fixed starting point; the trees get 15298's margin, the raw fields and
                           15298's own inputs (--incumbent-features-*) and learn what 15298's side adds to our model
  two_weights              a constant and one weight for each of the two margins, fitted on the training rows, no
                           trees: how much each model counts beside the other
  joined                   the two-weight sum as the starting point; the trees get both margins, the raw fields, the
                           vector and 15298's own inputs
  raw+pfm, raw+pfm+vector  the PFM's exported embedding columns, without and with our vector
Default pairs: raw+score vs raw, raw+score+vector vs raw+score, raw+vector vs raw+score, offset vs 15298 alone,
offset vs offset_raw, raw+pfm+vector vs raw+pfm, our score against 15298 (ours vs 15298), every arm that joins the
two models against 15298 alone and against our score alone, and joined vs two_weights (each when both arms ran).
Measures and the account bootstrap are the reads' own (UDR at 0.6% decides; AP, VDR, FPR, AUROC, KS reported). An
arm that joins the two models is fitted and read on the rows that have both scores (offset_raw, which reads
nothing of ours, on the rows that have 15298's), and an arm that reads 15298's own inputs on the rows its inputs
file holds; the table gives each arm's rows.

When the offset arm reads below our own score. Its start is 15298's margin at full weight, and that margin is
not among the trees' columns: the trees can add to it and cannot turn it down. Where the two scores share most of
what they know, the sum counts the shared evidence twice, and the rows 15298 ranks high stay high whatever our score
says. The arm then ranks between the two, well below our score (near 15298 when it gets our score without the
vector). Read `two_weights` first: a weight near zero for 15298 over one standard deviation of its margin (the
number the note prints) says it adds little beside our score on these rows, and that is the case in which the
offset arm loses points. Then read `flipped` (our score kept whole, 15298's side as the correction) and `joined`.

Measured on synthetic rows (3 million to fit, 5 million to read, 0.16 percent fraud; the share of frauds, then
of fraud value, in the top 0.6 percent of rows):
- 15298 adding almost nothing beside ours (fitted weights 0.05 and 0.96). 15298 alone 49.1 and 52.6; ours alone
  55.7 and 61.9; offset 52.6 and 57.4 (50.0 and 53.7 with our score and no vector, at 256 bins); offset_open 55.3
  and 61.3 (with our logit, 15298's margin and the vector as its columns); flipped 55.7 and 61.9; two_weights 56.0
  and 62.1; joined 56.0 and 62.1. The bank team's layout (15298's margin as the start, its inputs and our score as
  the columns) read 50.4 and 54.4 at 256 bins, and 55.5 and 62.0 once 15298's margin and our logit were among the
  columns.
- 15298 adding much (weights 0.61 and 0.68). 15298 alone 54.4 and 54.6; ours alone 58.6 and 63.3; two_weights 70.8
  and 74.0; offset 75.1 and 79.5; offset_open 75.1 and 79.1; flipped 75.2 and 79.4. There every arm reads far above
  both scores, the offset arm too.
The arms above were measured with 4,096 bins per column (--max-bin 4096) where not said. XGBoost's own 256 puts
the top 0.39 percent of the rows of a score column into one bin, which hides the order of that column inside the
0.6 percent outsort; yet more bins alone did not repair the offset arm (50.2 against 50.0 with our score alone,
52.6 against 52.5 with the vector) and moved flipped by less than 0.1 point of the share of frauds and less than
0.2 of the share of fraud value, so --max-bin keeps XGBoost's 256 unless given (offset_open and joined were
measured at 4,096 bins only). Weights by amount on the fit rows (to the power 0.5, tried where 15298 adds almost
nothing, on the trees of flipped and of the two-weight start) moved the share of fraud value by less than 0.2
point either way; --amount-power is off unless given.

Rows: the read is on the export's June target rows, and every count printed for the read is a count of those
rows. Every such row must be found in the derived file and in the raw files of its own file range (--train-files,
--read-files); if not, the tool stops and says how many are missing. Where 15298 or the PFM covers only part of
the rows, the coverage is printed, the arms that need 15298 are fitted on the covered training rows, and every
pair is read on the rows both of its arms cover (the row count is printed).

15298's scores (--incumbent-train, --incumbent-read) are read as probabilities when at least 99 percent of them
lie between 0 and 1, and a value outside is then no score; otherwise they are used as margins (log-odds) as they
are. --incumbent-scale share or margin says which, where the tool would read it wrong.

15298's own inputs (--incumbent-features-train, --incumbent-features-read): every column of the file that holds
numbers (numbers held as text or as decimals count) goes to the trees of offset_open, flipped and joined. Left
out, and named in a note: the transaction id, the account, the time and the label however their names are
written, a column equal to the label on every row, a column that holds no numbers, and a column held for the
training rows or for the read rows only. A column that alone tells fraud from the rest is named in a note and
kept: it may be an honest input, or the label under another name. Every column name is in the record
(incumbent_inputs, and column_names of each arm).

Learner: XGBoost hist with --max-bin bins (256), a fixed budget (learning rate 0.05, depth 6, up to 2000 trees, early
stopping at 50 on aucpr over a held-out tenth of DS_TRAIN's accounts), seed 42. --tune N runs N random settings per
arm on that split first (--tune-share: the share of DS_TRAIN accounts used for the search).

Usage:
    $PY program/pg_downstream.py \
        --train-export runs/program/export/ds_train.parquet --train-derived runs/program/export/ds_train_derived.parquet \
        --read-export runs/program/export/ds_select.parquet --read-derived runs/program/export/ds_select_derived.parquet \
        --train-raw-base <training raw base> --train-files 4001 4010 --read-raw-base <eval raw base> \
        --read-files 8217 8227 --cred <S3 credentials yaml> \
        [--incumbent-train 15298_ds_train.parquet:score --incumbent-read 15298_ds_select.parquet:score] \
        [--incumbent-features-train 15298_inputs_ds_train.parquet \
         --incumbent-features-read 15298_inputs_ds_select.parquet] \
        [--pfm-train pfm_ds_train.parquet --pfm-read pfm_ds_select.parquet --pfm-prefix emb_] \
        --arms raw raw+score raw+score+vector --out runs/program/reads/downstream_ds_select.json
"""
import argparse
import decimal
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pg_layout  # noqa: E402
import pg_ranked as R  # noqa: E402
import pg_rows  # noqa: E402

ID, ACCOUNT, TIME, LABEL, AMOUNT = "fi_transaction_id", "Nmap_account_reference_xid", "transaction_dttm", "frd_tag", \
    "transaction_amt"
RAW_CONTINUOUS = ["transaction_amt", "external_1_scr", "avlble_merch_day_cash_lmt_amt", "available_daily_cash_limit_amt",
                  "remain_day_merchandise_lmt_amt", "total_available_balance_amt"]
RAW_CATEGORICAL = ["transaction_type_xcd", "segment", "transaction_category_xcd", "transaction_pos_condition_xcd",
                   "avs_request_xcd", "pos_security_xflg", "transaction_pin_verify_xcd", "cardholder_present_xflg",
                   "pos_card_capture_xflg", "cvv_verify_xcd", "authzn_rqst_crypto_valid_xflg", "pos_off_premises_xflg",
                   "pos_terminal_attend_xflg"]
ARMS = ("raw", "raw+score", "raw+score+vector", "raw+vector", "raw+score+pca16", "raw+score+orth",
        "raw+score+windows", "offset", "offset_raw", "offset_open", "flipped", "two_weights", "joined", "raw+pfm",
        "raw+pfm+vector")
# the arms that start from a margin (15298's, ours or the two-weight sum), each with its max_delta_step
JOINS = {"offset": ("15298", 1.0), "offset_raw": ("15298", 1.0), "offset_open": ("15298", None),
         "flipped": ("ours", None), "two_weights": ("two_weights", None), "joined": ("two_weights", None)}
PAIRS = (("raw+score", "raw"), ("raw+score+vector", "raw+score"), ("raw+vector", "raw+score"),
         ("raw+score+pca16", "raw+score"), ("raw+score+orth", "raw+score"), ("raw+score+windows", "raw+score"),
         ("offset", "15298"), ("offset", "offset_raw"), ("raw+pfm+vector", "raw+pfm"),
         # what joining the two models gives over each of them alone; a join below "ours" has lost what ours knows
         ("ours", "15298"), ("offset", "ours"), ("offset_open", "15298"), ("offset_open", "ours"),
         ("flipped", "15298"), ("flipped", "ours"), ("two_weights", "15298"), ("two_weights", "ours"),
         ("joined", "15298"), ("joined", "ours"), ("joined", "two_weights"))
FIXED = {"learning_rate": 0.05, "max_depth": 6, "min_child_weight": 1.0, "subsample": 0.8, "colsample_bytree": 0.8,
         "reg_lambda": 1.0, "reg_alpha": 0.0}


def read_scores(spec, id_col=ID):
    """15298's scores by transaction id (as text), from PATH[:COLUMN]. A score that is not a finite number is no
    score."""
    path, col = (spec.rsplit(":", 1) + ["score"])[:2] if ":" in spec.split("/")[-1] else (spec, "score")
    df = pd.read_parquet(path) if path.endswith(".parquet") else pd.read_csv(path, dtype=str)
    lacks = [c for c in (id_col, col) if c not in df.columns]
    if lacks:
        raise SystemExit(f"{path} has no column {' and no column '.join(lacks)}; it holds "
                         + ", ".join(map(str, df.columns[:12])) + (" ..." if len(df.columns) > 12 else ""))
    values = pd.to_numeric(df[col], errors="coerce").to_numpy(float)
    values = np.where(np.isfinite(values), values, np.nan)
    return pd.Series(values, index=df[id_col].map(str)).groupby(level=0).first()


def shown(names, limit=8):
    """Up to `limit` names for a printed note; the record holds every name."""
    names = [str(c) for c in names]
    return ", ".join(names[:limit]) + (f" ... ({len(names)} in all, every name is in the record)"
                                       if len(names) > limit else "")


def lone_auroc(values, y, cap=500_000):
    """AUROC of one column alone against the label, on the rows that hold both: every fraud, and of the other rows
    every k-th when there are more than `cap`. None where one class is missing."""
    ok = np.isfinite(values) & np.isfinite(y)
    values, y = values[ok], y[ok]
    hit = np.flatnonzero(y > 0)
    rest = np.flatnonzero(y <= 0)
    if not len(hit) or not len(rest):
        return None
    rest = rest[:: max(1, len(rest) // cap)]
    ranks = pd.Series(np.r_[values[hit], values[rest]]).rank().to_numpy()
    return float((ranks[: len(hit)].sum() - len(hit) * (len(hit) + 1) / 2) / (len(hit) * len(rest)))


def code_text(value):
    """One text form for a code, whichever number type its column came in: 3, 3.0 and Decimal("3") are all "3"
    (pandas holds a whole-number column as floats as soon as one of its values is missing, so the same field can
    arrive as 3 for one file range and as 3.0 for another). None for a missing value."""
    if value is None:
        return None
    if isinstance(value, (bool, np.bool_)):
        return str(bool(value))
    if isinstance(value, (int, np.integer)):
        return str(int(value))
    if isinstance(value, (float, np.floating)):
        if math.isnan(value):
            return None
        return str(int(value)) if math.isfinite(value) and float(value).is_integer() else str(float(value))
    if isinstance(value, decimal.Decimal):
        if value.is_nan():
            return None
        return str(int(value)) if value.is_finite() and value == value.to_integral_value() else str(value)
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    return str(value)


def code_texts(values):
    """`code_text` of every value of a column, worked out once per distinct value. An object array."""
    codes, distinct = pd.factorize(pd.Series(values))
    texts = np.array([code_text(v) for v in distinct] + [None], dtype=object)    # a missing value has the code -1
    return texts[codes]


def frame(export, derived, raw_base, files, cred, raw_cols, incumbent=None, pfm=None, pfm_prefix="emb_",
          june=False, name="export", incumbent_features=None, record=None):
    """The export's rows (its June target rows when `june`) with the derived columns, the raw fields (typed, from
    the raw files), 15298's score, its own inputs (as inc_<name>, with `_inputs_row` saying which rows the inputs
    file holds) and the PFM's embedding joined on the transaction id. Returns (frame, notes); `record`, a dict,
    receives the names of the input columns used and left out, every one of them."""
    notes = []
    df = pq.read_table(export).to_pandas()
    if june:
        # first of all, so that every count below is a count of the rows that are read
        t = pd.to_datetime(df[TIME])
        df = df[(t >= pd.Timestamp(pg_rows.TARGETS[0])) & (t < pd.Timestamp(pg_rows.TARGETS[1]))].reset_index(
            drop=True)
        if not len(df):
            raise SystemExit(f"{name}: {export} holds no row from {pg_rows.TARGETS[0]} to {pg_rows.TARGETS[1]}; "
                             "--all-read-rows reads every exported row")
    df["_id"] = df[ID].map(str)
    n = len(df)
    if derived:
        d = pq.read_table(derived).to_pandas().drop(columns=[c for c in (ACCOUNT, TIME) if c], errors="ignore")
        df = df.merge(d.assign(_id=d[ID].map(str)).drop(columns=[ID]), on="_id", how="left", indicator=True)
        missing = int((df.pop("_merge") == "left_only").sum())
        if missing:
            raise SystemExit(f"{name}: {missing:,} of {n:,} export rows have no row in the derived file {derived}; "
                             "derive it from the same export")
    if raw_base:
        if not files:
            raise SystemExit(f"{name}: reading raw fields needs the export's own file range (--train-files or "
                             "--read-files)")
        numbers = list(range(files[0], files[1] + 1))
        fs = pg_layout.s3_filesystem(cred) if str(raw_base).startswith(("s3://", "s3a://")) else None
        parts = [pg_rows.read_columns(p, [ID] + list(raw_cols), fs) for p in pg_layout.file_paths(raw_base, numbers)]
        raw = pd.concat(parts, ignore_index=True)
        raw["_id"] = raw[ID].map(str)
        raw = raw.drop(columns=[ID]).drop_duplicates("_id")
        # the raw files' typed columns replace the export's text copies (the export keeps ids and keys only)
        df = df.drop(columns=[c for c in raw.columns if c in df.columns and c not in ("_id", ID, ACCOUNT, TIME, LABEL)])
        df = df.merge(raw, on="_id", how="left", indicator=True)
        missing = int((df.pop("_merge") == "left_only").sum())
        if missing:
            raise SystemExit(f"{name}: {missing:,} of {n:,} export rows are not in the raw files {files[0]}-{files[1]}; "
                             "give the file range the export was made from")
    if incumbent:
        df["incumbent_score"] = read_scores(incumbent).reindex(df["_id"]).to_numpy()
        have = int(np.isfinite(df["incumbent_score"].to_numpy(float)).sum())
        notes.append(f"{name}: 15298 scores for {have:,} of {n:,} rows")
    if incumbent_features:
        f = pd.read_parquet(incumbent_features) if incumbent_features.endswith(".parquet") else pd.read_csv(
            incumbent_features, dtype={ID: str})
        if ID not in f.columns:
            raise SystemExit(f"{name}: {incumbent_features} has no column {ID}")
        ids = f[ID].map(str).to_numpy()
        first = ~pd.Series(ids).duplicated().to_numpy()                   # an id held twice gives its first row
        # never inputs, whatever the file holds and however the name is written (FRD_TAG, " frd_tag"): the
        # export's keys and its label
        own = {key.strip().lower() for key in (ID, ACCOUNT, TIME, LABEL)}
        held = [c for c in f.columns if c != ID and str(c).strip().lower() in own]
        block, left, partly = {}, [], []
        for c in f.columns:
            if c in (ID, "_id") or c in held:
                continue
            values = f[c]
            if values.isna().all():
                numbers = pd.Series(np.nan, index=f.index)                # no value at all: a number, all missing
            elif pd.api.types.is_numeric_dtype(values):
                numbers = values
            elif values.dtype == object or isinstance(values.dtype, pd.StringDtype):
                # numbers held as text or as decimals are numbers; a column of anything else is left out and named
                numbers = pd.to_numeric(values, errors="coerce")
                filled = values.notna() & (values.map(lambda v: str(v).strip()) != "")
                lost = int((filled & numbers.isna()).sum())
                if lost > 0.01 * int(filled.sum()):
                    left.append(c)
                    continue
                if lost:
                    partly.append(f"{c} ({lost:,})")
            else:
                left.append(c)                                            # a date, a category
                continue
            with np.errstate(over="ignore", invalid="ignore"):
                block[f"inc_{c}"] = numbers.to_numpy(dtype=np.float32, na_value=np.nan)[first]
        table = pd.DataFrame(block, index=ids[first])
        present = df["_id"].isin(table.index).to_numpy()
        placed = table.reindex(df["_id"].to_numpy())
        placed.index = df.index
        # a copy of the label under any name is the label; a column that alone tells fraud from the rest is named.
        # Both are judged where at least 20 rows of each kind hold the column, so that chance cannot do it
        same, alone = [], []
        y = pd.to_numeric(df[LABEL], errors="coerce").to_numpy(float) if LABEL in df else None
        for c in list(placed.columns) if y is not None else ():
            v = placed[c].to_numpy(float)
            both = np.isfinite(v) & np.isfinite(y)
            if not 20 <= y[both].sum() <= both.sum() - 20:
                continue
            if np.array_equal(v[both], y[both]):
                same.append(c)
                continue
            area = lone_auroc(v, y)
            if area is not None and (area >= 0.999 or area <= 0.001):
                alone.append(f"{c[4:]} ({area:.4f})")
        placed = placed.drop(columns=same)
        df = pd.concat([df.drop(columns=[c for c in placed.columns if c in df.columns]), placed], axis=1)
        df["_inputs_row"] = present
        cols = [c[4:] for c in placed.columns]
        if record is not None:
            record.update(used=cols, not_numbers=[str(c) for c in left], keys_or_label=[str(c) for c in held],
                          equal_to_the_label=[c[4:] for c in same], separates_the_label_alone=alone,
                          values_not_numbers=partly, rows=int(present.sum()), of_rows=int(n))
        notes.append(f"{name}: 15298's own inputs ({len(cols)} columns) for {int(present.sum()):,} of {n:,} rows: "
                     + shown(cols)
                     + (f"; left out, not numbers: {shown(left)}" if left else "")
                     + (f"; values that are not numbers read as missing: {shown(partly)}" if partly else "")
                     + (f"; left out, the export's own keys or label: {shown(held)}" if held else "")
                     + (f"; left out, equal to the label on every row that holds it: {shown(c[4:] for c in same)}"
                        if same else ""))
        if alone:
            notes.append(f"{name}: of 15298's own inputs, each of these alone tells fraud from the rest (its AUROC "
                         f"alone in brackets): {shown(alone)}. An input that is the label, or is made from it, gives "
                         "the label to every arm that reads these inputs (offset_open, flipped, joined); take it "
                         "out of the file unless 15298 itself reads it at scoring time")
    if pfm:
        p = pd.read_parquet(pfm) if pfm.endswith(".parquet") else pd.read_csv(pfm, dtype={ID: str})
        p = p.assign(_id=p[ID].map(str))
        cols = [c for c in p.columns if c.startswith(pfm_prefix)]
        df = df.merge(p[["_id"] + cols].drop_duplicates("_id").rename(columns={c: f"pfm_{c}" for c in cols}),
                      on="_id", how="left", indicator=True)
        have = int((df.pop("_merge") == "both").sum())
        notes.append(f"{name}: PFM embeddings for {have:,} of {n:,} rows (the others are missing values to the trees)")
    return df.reset_index(drop=True), notes


def groups(df, raw_cols):
    vec = [c for c in df.columns if c.startswith("e_") and c[2:].isdigit()]
    return {"raw": [c for c in raw_cols if c in df.columns], "score": ["score"], "vector": vec,
            "pca16": [c for c in df.columns if c.startswith("pca16_")],
            "orth": [c for c in df.columns if c.startswith("o_") and c[2:].isdigit()],
            "windows": [c for c in df.columns if c.startswith(("w1d_", "w7d_", "w30d_", "dev", "n1d", "n7d", "n30d"))],
            "pfm": [c for c in df.columns if c.startswith("pfm_")],
            # for the arms that join the two models: our logit, 15298's margin as a column, 15298's own inputs
            "logit": [c for c in ("score_logit",) if c in df.columns],
            "margin": [c for c in ("incumbent_margin",) if c in df.columns],
            "incumbent": [c for c in df.columns if c.startswith("inc_")]}


def arm_columns(arm, g):
    """The trees' columns of an arm, each once (a field named twice in --raw-cols, or one that is also a derived
    column, counts once)."""
    if arm == "offset":
        cols = g["score"] + g["vector"]
    elif arm == "offset_raw":
        cols = g["raw"]
    elif arm == "offset_open":     # 15298's margin is the start and also a column, so the trees can turn it down
        cols = g["logit"] + g["margin"] + g["raw"] + g["vector"] + g["incumbent"]
    elif arm == "flipped":         # our logit is the start; the trees get 15298's side
        cols = g["margin"] + g["raw"] + g["incumbent"]
    elif arm == "joined":          # the two-weight sum is the start; the trees get everything
        cols = g["logit"] + g["margin"] + g["raw"] + g["vector"] + g["incumbent"]
    elif arm == "two_weights":     # no trees
        cols = []
    else:
        cols = []
        for part in arm.split("+"):
            cols += g[part]
    return list(dict.fromkeys(cols))


def to_matrix(df, cols, categories):
    """The trees' columns: a coded field as a category, any other as a float32 number, with a value that is not a
    finite number (text, an overflow, an infinity) as a missing one."""
    held = {}
    cols = list(dict.fromkeys(cols))
    for c in cols:
        if c in categories:
            held[c] = pd.Categorical(code_texts(df[c]), categories=categories[c])
        else:
            with np.errstate(over="ignore"):
                held[c] = pd.to_numeric(df[c], errors="coerce").astype(np.float32).replace([np.inf, -np.inf], np.nan)
    return pd.DataFrame(held, index=df.index, columns=cols)


def logit(p, floor=1e-6):
    p = np.clip(np.asarray(p, float), floor, 1 - floor)
    return np.log(p / (1 - p))


def flat_margin(values):
    """Whether a margin is one value on every row: its range is no more than a billionth of its size. The standard
    deviation does not tell it (numpy's of equal numbers is often 1e-16, not 0), and a score that differs in its
    last digit only has no spread to fit a weight on either."""
    values = np.asarray(values, float)
    return not len(values) or float(np.ptp(values)) <= 1e-9 * max(1.0, float(np.abs(values).max()))


def two_weights(y, theirs, ours, steps=200):
    """(constant, weight of 15298's margin, weight of our logit) of the logistic fit y ~ constant + a * theirs +
    b * ours. A weight near zero (times the spread of its margin) says that model adds little beside the other; the
    offset arm holds 15298's weight at one whatever the rows say.

    Newton steps on the log likelihood, each shortened until the likelihood rises, so that the fit cannot overshoot
    and settle where the rows are scored 0 or 1 outright (a plain Newton step does on a score with a long tail, or
    on one handed over on another scale, points from 0 to 999). The two margins are centred and scaled to a spread
    of one first, for the arithmetic only, and the weights are handed back for the margins as given; a margin that
    is one value on every row keeps a weight of zero. Points stay a poorer column than the margin they were made
    from. Rows that one score splits cleanly have no largest likelihood: the weights then grow until the steps run
    out and stay finite."""
    y = np.asarray(y, float)
    given = [np.asarray(theirs, float), np.asarray(ours, float)]
    # a margin that is one value on every row (see `flat_margin`): its column is zero, and so is its weight
    flat = [flat_margin(c) for c in given]
    centre = [float(c.mean()) for c in given]
    spread = [1.0 if level else (float(c.std()) or 1.0) for c, level in zip(given, flat)]
    x = np.stack([np.ones(len(y))] + [np.zeros(len(y)) if level else (c - m) / sd
                                      for c, m, sd, level in zip(given, centre, spread, flat)], 1)

    def likelihood(w):
        z = x @ w
        return float(np.sum(y * z - np.logaddexp(0.0, z)))

    rate = min(max(float(y.mean()), 1e-9), 1 - 1e-9)
    w = np.array([math.log(rate / (1 - rate)), 0.0, 0.0])
    value = likelihood(w)
    for _ in range(steps):
        p = np.exp(-np.logaddexp(0.0, -(x @ w)))
        grad = x.T @ (y - p)
        hess = (x * (p * (1 - p))[:, None]).T @ x + 1e-8 * np.eye(3)
        step = np.linalg.solve(hess, grad)
        share = 1.0
        while share > 1e-10:
            new = w + share * step
            risen = likelihood(new)
            if risen >= value + 1e-4 * share * float(grad @ step):
                break
            share /= 2
        else:
            break
        moved = float(np.abs(new - w).max())
        w, value = new, risen
        if moved < 1e-10:
            break
    a, b = w[1] / spread[0], w[2] / spread[1]
    return np.array([w[0] - a * centre[0] - b * centre[1], a, b])


MARGIN = {"kind": "logit"}


def margin_of(scores):
    """XGBoost's starting margin from 15298's score: its logit when the scores are probabilities, else the score."""
    s = np.asarray(scores, float)
    return logit(s) if MARGIN["kind"] == "logit" else s


def amount_weights(amounts, power):
    """--amount-power: each row weighs (its amount over the median amount) to that power, kept between a millionth
    and a million. A row whose amount is missing, not a number, zero or negative weighs 1; the median is that of
    the other rows."""
    amt = pd.to_numeric(pd.Series(np.asarray(amounts, dtype=object)), errors="coerce").to_numpy(float)
    ok = np.isfinite(amt) & (amt > 0)
    mid = float(np.median(amt[ok])) if ok.any() else 1.0
    with np.errstate(over="ignore", under="ignore"):
        raised = (np.where(ok, amt, mid) / mid) ** float(power)
    return np.where(ok, np.clip(raised, 1e-6, 1e6), 1.0)


def uniform_hash(values, seed):
    """A fixed number in [0, 1) per value (the same in every run for the same seed)."""
    key = f"{int(seed) % 10 ** 16:016d}"
    h = pd.util.hash_pandas_object(pd.Series(values, dtype=object).map(str), index=False, hash_key=key)
    return h.to_numpy(np.uint64).astype(np.float64) / float(2 ** 64)


def inner_split(accounts, share=0.1, seed=42):
    """(fit rows, held-out rows): a share of the accounts, whole, is held out for early stopping."""
    u = uniform_hash(pd.Series(accounts).map(str).to_numpy(), seed)
    return u >= share, u < share


class Unfit(Exception):
    """An arm that cannot be fitted on the rows it has; the message says why."""


def fit_arm(train, cols, categories, start, params, seed=42, rounds=2000, early=50, tune=0, tune_share=1.0,
            delta=None, max_bin=256, weight=None):
    """One arm's trees. `start` is the fixed starting margin of each training row (None: XGBoost's own start),
    `delta` a max_delta_step, `weight` a weight per training row (the fit rows' only). Trees stop being added when
    aucpr on a held-out tenth of the accounts has not improved for `early` rounds. Stopping on that tenth's share of
    frauds in its top 0.6 percent was tried on synthetic rows: where the trees had much to add it stopped at 41
    trees and read 74.0 percent, against 118 trees and 75.2 on aucpr; where they had nothing to add both read the
    same. Raises Unfit when the rows the trees are fitted on, or the held-out tenth, hold no fraud or nothing else:
    aucpr is then not a number on every round, the fit stops at one tree, and the arm would be read as its start."""
    import xgboost as xgb
    y = train[LABEL].to_numpy(np.int64)
    fit_rows, val_rows = inner_split(train[ACCOUNT].to_numpy())
    for part, rows in (("the rows its trees are fitted on", fit_rows),
                       ("the held-out tenth of its accounts", val_rows)):
        frauds, count = int(y[rows].sum()), int(rows.sum())
        if not 0 < frauds < count:
            raise Unfit(f"{part} ({count:,} of its {len(y):,} rows) hold "
                        f"{'no fraud' if not frauds else 'frauds only'}, so the number of trees cannot be chosen")
    x = to_matrix(train, cols, categories)
    margin = None if start is None else np.asarray(start, float)
    weight = None if weight is None else np.asarray(weight, float)

    def dm(mask, weighted=False):
        return xgb.DMatrix(x[mask], label=y[mask], base_margin=None if margin is None else margin[mask],
                           weight=weight[mask] if weighted and weight is not None else None, enable_categorical=True)

    def train_once(p, fit_mask):
        settings = {"objective": "binary:logistic", "eval_metric": "aucpr", "tree_method": "hist",
                    "max_bin": int(max_bin), "seed": seed, "nthread": -1,
                    **({"max_delta_step": float(delta)} if delta else {}), **p}
        # the weights count in the fit; the held-out tenth is read unweighted, so that aucpr means the same with
        # and without them
        booster = xgb.train(settings, dm(fit_mask, True), num_boost_round=rounds, evals=[(dm(val_rows), "valid")],
                            early_stopping_rounds=early, verbose_eval=False)
        return booster, float(booster.best_score)

    best_p, trials = dict(params), []
    if tune:
        rng = np.random.default_rng(seed)
        sub = fit_rows & (inner_split(train[ACCOUNT].to_numpy(), 1.0 - tune_share, seed + 7)[0] | (tune_share >= 1))
        best = -1.0
        for _ in range(int(tune)):
            p = {"learning_rate": float(np.exp(rng.uniform(np.log(0.01), np.log(0.3)))),
                 "max_depth": int(rng.integers(3, 11)), "min_child_weight": float(np.exp(rng.uniform(0, np.log(100)))),
                 "subsample": float(rng.uniform(0.5, 1.0)), "colsample_bytree": float(rng.uniform(0.3, 1.0)),
                 "reg_lambda": float(np.exp(rng.uniform(np.log(1e-3), np.log(10)))),
                 "reg_alpha": float(np.exp(rng.uniform(np.log(1e-3), np.log(10))))}
            _, score = train_once(p, sub)
            trials.append({"params": p, "aucpr": score})
            if score > best:
                best, best_p = score, p
    booster, score = train_once(best_p, fit_rows)
    return booster, {"params": best_p, "inner_aucpr": score, "max_bin": int(max_bin),
                     "best_iteration": int(booster.best_iteration), "tuning_trials": len(trials)}


def predict(booster, df, cols, categories, start):
    """The arm's margin for each row: the row's own starting margin (when the arm has one) plus the trees."""
    import xgboost as xgb
    d = xgb.DMatrix(to_matrix(df, cols, categories), base_margin=None if start is None else np.asarray(start, float),
                    enable_categorical=True)
    return booster.predict(d, iteration_range=(0, booster.best_iteration + 1), output_margin=True)


def run(a):
    raw_cols = a.raw_cols or (RAW_CONTINUOUS + RAW_CATEGORICAL)
    inputs_record = {"training rows": {}, "read rows": {}}
    train, n1 = frame(a.train_export, a.train_derived, a.train_raw_base, a.train_files, a.cred, raw_cols,
                      a.incumbent_train, a.pfm_train, a.pfm_prefix, name="training rows",
                      incumbent_features=a.incumbent_features_train, record=inputs_record["training rows"])
    read, n2 = frame(a.read_export, a.read_derived, a.read_raw_base, a.read_files, a.cred, raw_cols, a.incumbent_read,
                     a.pfm_read, a.pfm_prefix, june=not a.all_read_rows, name="read rows",
                     incumbent_features=a.incumbent_features_read, record=inputs_record["read rows"])
    notes = n1 + n2
    # 15298's own inputs are used where the training rows and the read rows both hold them
    inputs = [[c for c in d.columns if c.startswith("inc_")] for d in (train, read)]
    one_side = sorted(set(inputs[0]) ^ set(inputs[1]))
    inputs_record["one_side_only"] = [c[4:] for c in one_side]
    if one_side:
        for d in (train, read):
            d.drop(columns=[c for c in one_side if c in d.columns], inplace=True)
        notes.append("15298's own inputs held for the training rows or for the read rows only are left out: "
                     + shown(c[4:] for c in one_side))
    if a.amount_power and AMOUNT not in train:
        notes.append(f"--amount-power: the training rows hold no {AMOUNT}; no weights are used")
    # continuous raw fields stay numbers; the coded fields (and any other text field) are categories, each code in
    # one text form on both sides
    categories = {c: sorted({t for t in code_texts(train[c]) if t is not None}) for c in raw_cols
                  if c in train and c not in RAW_CONTINUOUS and (c in RAW_CATEGORICAL or train[c].dtype == object)}
    for c, known in categories.items():
        if c not in read:
            continue
        texts = pd.Series(code_texts(read[c]), dtype=object)
        there = texts.notna().to_numpy()
        unseen = there & ~texts.isin(known).to_numpy()
        if unseen.sum() > 0.01 * max(1, int(there.sum())):
            notes.append(f"{c}: {int(unseen.sum()):,} of the {int(there.sum()):,} read rows that hold a code hold one "
                         "the training rows never held; it is a missing value to the trees there")
    if "incumbent_score" in train:
        vals = pd.concat([train["incumbent_score"], read.get("incumbent_score", pd.Series(dtype=float))])
        vals = vals[np.isfinite(vals.to_numpy(float))]
        inside = int(vals.between(0, 1).sum())
        low, high = (float(vals.min()), float(vals.max())) if len(vals) else (0.0, 0.0)
        scale = getattr(a, "incumbent_scale", "auto")
        # by the bulk of the scores and not by all of them: one value written as -1 for "no score", or as
        # 1.0000001, does not turn every probability into a margin
        as_share = scale == "share" or (scale == "auto" and len(vals) > 0 and inside >= 0.99 * len(vals))
        MARGIN["kind"] = "logit" if as_share else "raw"
        # no log-odds is as large as 50, and real margins are never all whole numbers: either says points
        points = len(vals) > 0 and (max(abs(low), abs(high)) > 50 or bool((vals == vals.round()).all()))
        if as_share and inside < len(vals):
            for d in (train, read):
                if "incumbent_score" in d:
                    held = d["incumbent_score"].to_numpy(float)
                    with np.errstate(invalid="ignore"):
                        d["incumbent_score"] = np.where((held >= 0) & (held <= 1), held, np.nan)
            notes.append(f"15298's scores: {len(vals) - inside:,} of {len(vals):,} lie outside 0 to 1 (they run from "
                         f"{low:g} to {high:g}). The others are read as probabilities; a row with a score outside "
                         "has no 15298 score")
        elif not len(vals):
            notes.append("15298's scores: no row has one that is a finite number")
        elif not as_share:
            notes.append(f"15298's scores are used as the starting margin as they are (--incumbent-scale {scale}): "
                         f"{inside:,} of {len(vals):,} lie between 0 and 1, and they run from {low:g} to {high:g}"
                         + (". That looks like points on a scale and not like margins (log-odds): every arm that "
                            "starts from 15298 then starts from a wrong margin. Hand over 15298's probabilities, or "
                            "its margins (predict with output_margin=True)" if points else "")
                         + (". If they are probabilities with a code for no score among them, say --incumbent-scale "
                            "share" if scale == "auto" and inside >= 0.5 * len(vals) > 0 else ""))
    # the two margins as columns: 15298's (also the start of the offset arms) and ours (the start of `flipped`).
    # Ours is the logit of the exported score, or the score itself where the export already holds margins
    ours_all = pd.concat([d["score"] for d in (train, read) if "score" in d] or [pd.Series(dtype=float)])
    ours_all = ours_all[np.isfinite(ours_all.to_numpy(float))]
    ours_is_share = bool(len(ours_all)) and bool(ours_all.between(0, 1).all())
    for d in (train, read):
        if "score" in d:
            mine = d["score"].to_numpy(float)
            d["score_logit"] = logit(mine, 1e-7) if ours_is_share else mine
        if "incumbent_score" in d:
            d["incumbent_margin"] = margin_of(d["incumbent_score"].to_numpy(float))
    g = groups(train, raw_cols)

    def needed(arm):
        """The scores a row must hold for an arm that joins the two models: both, since every such arm starts
        from one and reads the other; offset_raw, which reads no score of ours, needs 15298's only."""
        return ("incumbent_margin",) if arm == "offset_raw" else ("incumbent_margin", "score_logit")

    weights, fitted_on = None, 0
    if any(JOINS.get(arm, ("",))[0] == "two_weights" for arm in a.arms) and all(
            c in d for c in needed("two_weights") for d in (train, read)):
        theirs, mine = train["incumbent_margin"].to_numpy(float), train["score_logit"].to_numpy(float)
        both = np.isfinite(theirs) & np.isfinite(mine)
        flat = not both.any() or flat_margin(theirs[both]) or flat_margin(mine[both])
        spread = (0.0, 0.0) if flat else (float(np.std(theirs[both])), float(np.std(mine[both])))
        fitted_on = int(both.sum())
        if both.any() and 0 < train.loc[both, LABEL].sum() < both.sum() and min(spread) > 0:
            weights = two_weights(train.loc[both, LABEL].to_numpy(float), theirs[both], mine[both])
            # a weight counts per unit of its margin; times the margin's spread, the two can be set side by side
            # whatever scale each score was handed over on
            per_spread = (float(weights[1] * spread[0]), float(weights[2] * spread[1]))
            notes.append(f"two weights, fitted on {int(both.sum()):,} training rows: constant {weights[0]:+.3f}, "
                         f"15298's margin {weights[1]:.3f}, our logit {weights[2]:.3f}. Over one standard deviation "
                         f"of its margin that is {per_spread[0]:.2f} for 15298 and {per_spread[1]:.2f} for ours: "
                         "the model whose number is near zero adds little beside the other on these rows")
        elif both.any() and min(spread) == 0:
            notes.append("two weights: one of the two margins is the same on every training row, so no weight can "
                         "be fitted for it")

    def start_of(kind, d):
        """The starting margin of each row of `d` for one kind of start (not finite where a score is missing)."""
        if kind == "15298":
            return d["incumbent_margin"].to_numpy(float)
        if kind == "ours":
            return d["score_logit"].to_numpy(float)
        return (weights[0] + weights[1] * d["incumbent_margin"].to_numpy(float)
                + weights[2] * d["score_logit"].to_numpy(float))

    def covered(arm, d, inputs=False):
        """The rows of `d` that have every score the arm needs and, for an arm that reads 15298's own inputs, a
        row in the inputs file: with the other rows left in, the trees could read which rows the file holds."""
        ok = np.ones(len(d), bool)
        for c in needed(arm):
            ok &= np.isfinite(d[c].to_numpy(float))
        if inputs and "_inputs_row" in d:
            ok &= d["_inputs_row"].to_numpy(bool)
        return ok

    def row_weights(d):
        return amount_weights(d[AMOUNT], a.amount_power) if a.amount_power and AMOUNT in d else None

    scores, fits, valid = {}, {}, {}
    all_rows = np.ones(len(read), bool)
    for arm in a.arms:
        kind, delta = JOINS.get(arm, (None, None))
        if kind:
            lacks = [c for c in needed(arm) for d in (train, read) if c not in d]
            if lacks or (kind == "two_weights" and weights is None):
                sides = [side for side, d in (("the training rows", train), ("the read rows", read))
                         if "incumbent_margin" not in d]
                why = (f"no 15298 scores given for {' and '.join(sides)}" if sides else "the export holds no score"
                       if lacks else "the two weights could not be fitted")
                notes.append(f"{arm}: skipped ({why})")
                continue
        if arm == "two_weights":
            start = start_of(kind, read)
            scores[arm], valid[arm] = start, np.isfinite(start)
            fits[arm] = {"columns": 0, "column_names": [], "fit_rows": fitted_on, "start": "none",
                         "constant": float(weights[0]), "weight_15298": float(weights[1]),
                         "weight_ours": float(weights[2]), "per_spread_15298": per_spread[0],
                         "per_spread_ours": per_spread[1]}
            print(f"{arm}: constant {weights[0]:+.3f}, 15298's margin {weights[1]:.3f}, our logit {weights[2]:.3f}",
                  flush=True)
            continue
        cols = arm_columns(arm, g)
        if not cols or (("pfm" in arm) and not g["pfm"]):
            notes.append(f"{arm}: skipped (its columns are not in the files)")
            continue
        fit_rows, start = train, None
        start_read = start_of(kind, read) if kind else None
        rows = all_rows
        if kind:
            start = start_of(kind, train)
            reads_inputs = any(c.startswith("inc_") for c in cols)
            ok = np.isfinite(start) & covered(arm, train, reads_inputs)
            rows = np.isfinite(start_read) & covered(arm, read, reads_inputs)
            if reads_inputs:
                scored = [int((np.isfinite(m) & covered(arm, d)).sum())
                          for m, d in ((start, train), (start_read, read))]
                if int(ok.sum()) < scored[0] or int(rows.sum()) < scored[1]:
                    notes.append(f"{arm}: 15298's inputs file holds {int(ok.sum()):,} of the {scored[0]:,} training "
                                 f"rows that have the scores and {int(rows.sum()):,} of the {scored[1]:,} read rows; "
                                 "the arm is fitted and read on those rows alone, so that its trees cannot read "
                                 "which rows the file holds")
            if not ok.any():
                notes.append(f"{arm}: skipped (no training row has its starting score"
                             + (" and a row in 15298's inputs file)" if reads_inputs else ")"))
                continue
            fit_rows, start = train[ok].reset_index(drop=True), start[ok]
        try:
            booster, info = fit_arm(fit_rows, cols, categories, start, dict(FIXED), tune=a.tune,
                                    tune_share=a.tune_share, delta=delta, max_bin=a.max_bin,
                                    weight=row_weights(fit_rows))
        except Unfit as why:
            notes.append(f"{arm}: skipped ({why})")
            continue
        pred = np.full(len(read), np.nan)
        if rows.any():
            pred[rows] = predict(booster, read[rows].reset_index(drop=True), cols, categories,
                                 None if start_read is None else start_read[rows])
        scores[arm], valid[arm] = pred, rows & np.isfinite(pred)
        fits[arm] = {"columns": len(cols), "column_names": list(cols), "fit_rows": int(len(fit_rows)),
                     "start": kind or "none", **info}
        print(f"{arm}: {len(cols)} columns, {info['best_iteration'] + 1} trees, inner aucpr {info['inner_aucpr']:.4f}",
              flush=True)
    if "incumbent_score" in read:
        inc = read["incumbent_score"].to_numpy(float)
        if np.isfinite(inc).any():
            scores["15298"], valid["15298"] = inc, np.isfinite(inc)
    if "score" in read:
        scores["ours"], valid["ours"] = read["score"].to_numpy(float), np.isfinite(read["score"].to_numpy(float))
    y = read[LABEL].to_numpy(np.int64)
    amounts = pd.to_numeric(read[AMOUNT], errors="coerce").to_numpy(float) if AMOUNT in read else None
    if amounts is not None and R.amount_reason(amounts):
        with np.errstate(invalid="ignore"):
            empty, negative = int((~np.isfinite(amounts)).sum()), int((amounts < 0).sum())
        notes.append(f"VDR: read rows with no amount: {empty:,}; with a negative amount: {negative:,}. The share of "
                     "fraud value is not given for an arm whose rows hold such a row (it needs an amount on every "
                     "row it is read on)")
    key_rank, codes, n_units = R.prepare(read[ACCOUNT].to_numpy(), read[ID].to_numpy())

    def ranked_on(name, idx):
        am = None if amounts is None else amounts[idx]
        return R.RankedScore(scores[name][idx], y[idx], codes[idx], key_rank[idx], am)

    points = {}
    for k in list(scores):
        idx = np.flatnonzero(valid[k])
        if not len(idx):
            notes.append(f"{k}: no read row has the scores it needs; it is not read")
            del scores[k]
            continue
        points[k] = dict(ranked_on(k, idx).evaluate(None), rows_read=int(len(idx)))
    pairs = []
    for left, right in PAIRS:
        if left in scores and right in scores:
            idx = np.flatnonzero(valid[left] & valid[right])
            if not len(idx) or not y[idx].sum():
                notes.append(f"{left} vs {right}: no common rows with a fraud")
                continue
            met = R.paired([ranked_on(left, idx)], [ranked_on(right, idx)], n_units, a.draws, a.seed, 90.0)
            pairs.append({"pair": f"{left} vs {right}", "rows": int(len(idx)),
                          **{m: {k: met[m][k] for k in ("gain", "sd", "lo", "hi")} for m in ("udr", "ap", "vdr")}})
    return {"read_rows": int(len(y)), "read_frauds": int(y.sum()), "train_rows": int(len(train)), "fits": fits,
            "points": {k: {**{m: p[m] for m in R.METRICS}, "rows_read": p["rows_read"]} for k, p in points.items()},
            "pairs": pairs, "notes": notes, "incumbent_scale": MARGIN["kind"] if "incumbent_score" in train else None,
            "incumbent_inputs": inputs_record}


def screen(rec):
    lines = [f"downstream: trained on {rec['train_rows']:,} rows, read on {rec['read_rows']:,} rows "
             f"({rec['read_frauds']:,} frauds)"] + rec["notes"]
    lines.append(f"{'arm':<20}{'UDR':>8}{'AP':>8}{'VDR':>8}{'FPR':>7}{'AUROC':>8}{'rows':>12}")
    for k, p in rec["points"].items():
        lines.append(f"{k:<20}{p['udr']:>8.4f}{p['ap']:>8.4f}{p['vdr']:>8.4f}{p['fpr']:>7.2f}{p['auroc']:>8.4f}"
                     f"{p['rows_read']:>12,}")

    def gain(m):
        """A gain with its interval; the interval is n/a with fewer than two draws (--draws 0 or 1)."""
        if m["gain"] is None or not np.isfinite(m["gain"]):
            return None
        ends = "n/a" if m["lo"] is None or m["hi"] is None else f"{m['lo']:+.4f}, {m['hi']:+.4f}"
        return f"{m['gain']:+.4f} [{ends}]"

    for p in rec["pairs"]:
        parts = [f"{label} {text}" for label, text in (("UDR", gain(p["udr"])), ("VDR", gain(p["vdr"]))) if text]
        ap = p["ap"]["gain"]
        if ap is not None and np.isfinite(ap):
            parts.append(f"AP {ap:+.4f}")
        lines.append(f"{p['pair']} ({p['rows']:,} rows): " + "  ".join(parts))
    return "\n".join(lines)


def main(argv=None):
    ap = argparse.ArgumentParser(description="downstream arms: does the vector add beyond the score")
    ap.add_argument("--train-export", required=True)
    ap.add_argument("--train-derived", default=None)
    ap.add_argument("--read-export", required=True)
    ap.add_argument("--read-derived", default=None)
    ap.add_argument("--train-raw-base", default=None)
    ap.add_argument("--train-files", type=int, nargs=2, default=None, metavar=("START", "END"),
                    help="the file range the training export was made from (DS_TRAIN: 4001 4010)")
    ap.add_argument("--read-raw-base", default=None)
    ap.add_argument("--read-files", type=int, nargs=2, default=None, metavar=("START", "END"),
                    help="the file range the read export was made from (DS_SELECT: 8217 8227; FINAL: 8260 8277)")
    ap.add_argument("--cred", default=None)
    ap.add_argument("--raw-cols", nargs="+", default=None)
    ap.add_argument("--incumbent-train", default=None, help="15298 scores on the training rows: PATH[:COLUMN]")
    ap.add_argument("--incumbent-read", default=None, help="15298 scores on the read rows: PATH[:COLUMN]")
    ap.add_argument("--incumbent-scale", choices=("auto", "share", "margin"), default="auto",
                    help="what 15298's scores are: share (probabilities; a value outside 0 to 1 is no score), "
                         "margin (log-odds, used as they are), or auto (probabilities when at least 99 percent "
                         "of them lie between 0 and 1, else margins)")
    ap.add_argument("--incumbent-features-train", default=None,
                    help="15298's own input columns on the training rows (Parquet or CSV with the transaction id); "
                         "used by the arms flipped, joined and offset_open")
    ap.add_argument("--incumbent-features-read", default=None, help="the same on the read rows")
    ap.add_argument("--pfm-train", default=None)
    ap.add_argument("--pfm-read", default=None)
    ap.add_argument("--pfm-prefix", default="emb_")
    ap.add_argument("--arms", nargs="+", default=["raw", "raw+score", "raw+score+vector", "raw+vector"],
                    choices=ARMS)
    ap.add_argument("--all-read-rows", action="store_true", help="read every exported row, not only June targets")
    ap.add_argument("--max-bin", type=int, default=256,
                    help="bins per column for the trees (XGBoost's own 256). 256 puts the top 0.39 percent of the "
                         "rows of a score column into one bin; 4096 puts about 25 cut points inside the top 0.6 "
                         "percent and takes two to three times as long for an arm with the vector (less with more "
                         "rows), no longer for an arm with a few columns")
    ap.add_argument("--amount-power", type=float, default=0.0,
                    help="weigh each row the trees are fitted on by (its amount over the median amount) to this "
                         "power; 0 is off. A row with no amount, or one that is zero or negative, weighs 1; the "
                         "held-out rows and the two weights are not weighted")
    ap.add_argument("--tune", type=int, default=0)
    ap.add_argument("--tune-share", type=float, default=0.25)
    ap.add_argument("--draws", type=int, default=2000)
    ap.add_argument("--seed", type=int, default=20261102)
    ap.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    out = Path(a.out)
    rec = run(a)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(rec, indent=1, default=float))     # the record first: the fits are in it
    text = screen(rec)
    out.with_suffix(".txt").write_text(text + "\n")
    print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
