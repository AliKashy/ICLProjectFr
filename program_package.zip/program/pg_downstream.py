"""Does the vector add anything a downstream tree model cannot get from the score? One learner (XGBoost), fitted on
DS_TRAIN and read on DS_SELECT June targets, with different input sets, compared in pairs on the same rows.

Where it runs: on the pod, CPU (7 cores are enough; minutes to an hour per arm on 8.7 million rows).

Input sets (arms), each a list of column groups:
  raw                      the raw input fields (today's 19 raw inputs by default; --raw-cols to change)
  raw+score                plus our score
  raw+score+vector         plus the 48 numbers           raw+vector          the vector without the score
  raw+score+pca16          plus PCA 16 (from pg_derive)  raw+score+orth      plus the 47 numbers the head ignores
  raw+score+windows        plus the strictly earlier 1/7/30-day account means and deviations (pg_derive)
  offset                   15298's score as the fixed starting point (its logit as XGBoost's base margin); the
                           trees learn only the correction from our score and vector (max_delta_step 1)
  offset_raw               the same starting point, correction from the raw fields (the control for offset)
  offset_open              the same starting point, with 15298's margin also among the trees' columns, so the trees
                           can turn it down where our model disagrees; with it our logit, the vector, the raw
                           fields and 15298's own inputs; no max_delta_step
  flipped                  our logit as the fixed starting point; the trees get 15298's margin, the raw fields and
                           15298's own inputs (--incumbent-features-*) and learn what 15298's side adds to our model
  two_weights              a constant and one weight for each of the two margins, fitted on the training rows, no
                           trees: how much each model counts beside the other
  joined                   the two-weight sum as the starting point; the trees get both margins, the raw fields, the
                           vector and 15298's own inputs
  raw+pfm, raw+pfm+vector  the PFM's exported embedding columns, without and with our vector
Default pairs: raw+score vs raw, raw+score+vector vs raw+score, raw+vector vs raw+score, offset vs 15298 alone,
offset vs offset_raw, raw+pfm+vector vs raw+pfm, our score against 15298 (ours vs 15298), every arm that joins the
two models against 15298 alone and against our score alone, and joined vs two_weights (each when both arms ran).
Measures and the account bootstrap are the reads' own (UDR at 0.6% decides; AP, VDR, FPR, AUROC, KS reported). An
arm that joins the two models is fitted and read on the rows that have both scores; the table gives each arm's
rows.

When the offset arm reads below our own score. Its start is 15298's margin at full weight, and that margin is
not among the trees' columns: the trees can add to it and cannot turn it down. Where the two scores share most of
what they know, the sum counts the shared evidence twice, and the rows 15298 ranks high stay high whatever our score
says. The arm then ranks near 15298 and below our score. Read `two_weights` first: a weight near zero for 15298
says it adds little beside our score on these rows, and that is the case in which the offset arm loses points.
Then read `flipped` (our score kept whole, 15298's side as the correction) and `joined`.

Measured on synthetic rows (3 million to fit, 5 million to read, 0.16 percent fraud; the share of frauds, then
of fraud value, in the top 0.6 percent of rows):
- 15298 adding almost nothing beside ours (fitted weights 0.05 and 0.96). 15298 alone 49.1 and 52.6; ours alone
  55.7 and 61.9; offset 52.6 and 57.4 (50.0 and 53.7 with our score and no vector, at 256 bins); offset_open 55.3
  and 61.3 (with our logit, 15298's margin and the vector as its columns); flipped 55.7 and 61.9; two_weights 56.0
  and 62.1; joined 56.0 and 62.1. The bank team's layout (15298's margin as the start, its inputs and our score as
  the columns) read 50.4 and 54.4 at 256 bins, and 55.5 and 62.0 once 15298's margin and our logit were among the
  columns.
- 15298 adding much (weights 0.61 and 0.68). 15298 alone 54.4 and 54.6; ours alone 58.6 and 63.3; two_weights 70.8
  and 74.0; offset 75.1 and 79.5; offset_open 75.1 and 79.1; flipped 75.2 and 79.4. There every arm reads far above
  both scores, the offset arm too.
The arms above were measured with 4,096 bins per column (--max-bin 4096) where not said. XGBoost's own 256 puts
the top 0.39 percent of the rows of a score column into one bin, which hides the order of that column inside the
0.6 percent outsort; yet more bins alone did not repair the offset arm (50.2 against 50.0 with our score alone,
52.6 against 52.5 with the vector) and moved flipped by less than 0.1 point, so --max-bin keeps XGBoost's 256
unless given. Weights by amount on the fit rows (to the power 0.5, tried where 15298 adds almost nothing, on the
trees of flipped and of the two-weight start) moved the share of fraud value by less than 0.2 point either way;
--amount-power is off unless given.

Rows: the read is on the export's June target rows. Every export row must be found in the derived file and in the
raw files of its own file range (--train-files, --read-files); if not, the tool stops and says how many are missing.
Where 15298 or the PFM covers only part of the rows, the coverage is printed, the offset arms are fitted on the
covered training rows, and every pair is read on the rows both of its arms cover (the row count is printed).

Learner: XGBoost hist with --max-bin bins (256), a fixed budget (learning rate 0.05, depth 6, up to 2000 trees, early
stopping at 50 on aucpr over a held-out tenth of DS_TRAIN's accounts), seed 42. --tune N runs N random settings per
arm on that split first (--tune-share: the share of DS_TRAIN accounts used for the search).

Usage:
    $PY program/pg_downstream.py \
        --train-export runs/program/export/ds_train.parquet --train-derived runs/program/export/ds_train_derived.parquet \
        --read-export runs/program/export/ds_select.parquet --read-derived runs/program/export/ds_select_derived.parquet \
        --train-raw-base <training raw base> --train-files 4001 4010 --read-raw-base <eval raw base> \
        --read-files 8217 8227 --cred <S3 credentials yaml> \
        [--incumbent-train 15298_ds_train.parquet:score --incumbent-read 15298_ds_select.parquet:score] \
        [--incumbent-features-train 15298_inputs_ds_train.parquet \
         --incumbent-features-read 15298_inputs_ds_select.parquet] \
        [--pfm-train pfm_ds_train.parquet --pfm-read pfm_ds_select.parquet --pfm-prefix emb_] \
        --arms raw raw+score raw+score+vector --out runs/program/reads/downstream_ds_select.json
"""
import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pg_layout  # noqa: E402
import pg_ranked as R  # noqa: E402
import pg_rows  # noqa: E402

ID, ACCOUNT, TIME, LABEL, AMOUNT = "fi_transaction_id", "Nmap_account_reference_xid", "transaction_dttm", "frd_tag", \
    "transaction_amt"
RAW_CONTINUOUS = ["transaction_amt", "external_1_scr", "avlble_merch_day_cash_lmt_amt", "available_daily_cash_limit_amt",
                  "remain_day_merchandise_lmt_amt", "total_available_balance_amt"]
RAW_CATEGORICAL = ["transaction_type_xcd", "segment", "transaction_category_xcd", "transaction_pos_condition_xcd",
                   "avs_request_xcd", "pos_security_xflg", "transaction_pin_verify_xcd", "cardholder_present_xflg",
                   "pos_card_capture_xflg", "cvv_verify_xcd", "authzn_rqst_crypto_valid_xflg", "pos_off_premises_xflg",
                   "pos_terminal_attend_xflg"]
ARMS = ("raw", "raw+score", "raw+score+vector", "raw+vector", "raw+score+pca16", "raw+score+orth",
        "raw+score+windows", "offset", "offset_raw", "offset_open", "flipped", "two_weights", "joined", "raw+pfm",
        "raw+pfm+vector")
# the arms that start from a margin (15298's, ours or the two-weight sum), each with its max_delta_step
JOINS = {"offset": ("15298", 1.0), "offset_raw": ("15298", 1.0), "offset_open": ("15298", None),
         "flipped": ("ours", None), "two_weights": ("two_weights", None), "joined": ("two_weights", None)}
PAIRS = (("raw+score", "raw"), ("raw+score+vector", "raw+score"), ("raw+vector", "raw+score"),
         ("raw+score+pca16", "raw+score"), ("raw+score+orth", "raw+score"), ("raw+score+windows", "raw+score"),
         ("offset", "15298"), ("offset", "offset_raw"), ("raw+pfm+vector", "raw+pfm"),
         # what joining the two models gives over each of them alone; a join below "ours" has lost what ours knows
         ("ours", "15298"), ("offset", "ours"), ("offset_open", "15298"), ("offset_open", "ours"),
         ("flipped", "15298"), ("flipped", "ours"), ("two_weights", "15298"), ("two_weights", "ours"),
         ("joined", "15298"), ("joined", "ours"), ("joined", "two_weights"))
FIXED = {"learning_rate": 0.05, "max_depth": 6, "min_child_weight": 1.0, "subsample": 0.8, "colsample_bytree": 0.8,
         "reg_lambda": 1.0, "reg_alpha": 0.0}


def read_scores(spec, id_col=ID):
    path, col = (spec.rsplit(":", 1) + ["score"])[:2] if ":" in spec.split("/")[-1] else (spec, "score")
    df = pd.read_parquet(path) if path.endswith(".parquet") else pd.read_csv(path, dtype=str)
    return pd.Series(pd.to_numeric(df[col], errors="coerce").to_numpy(float), index=df[id_col].map(str)).groupby(
        level=0).first()


def frame(export, derived, raw_base, files, cred, raw_cols, incumbent=None, pfm=None, pfm_prefix="emb_",
          june=False, name="export", incumbent_features=None):
    """The export's rows with the derived columns, the raw fields (typed, from the raw files), 15298's score, its
    own inputs (as inc_<name>) and the PFM's embedding joined on the transaction id. Returns (frame, notes)."""
    notes = []
    df = pq.read_table(export).to_pandas()
    df["_id"] = df[ID].map(str)
    n = len(df)
    if derived:
        d = pq.read_table(derived).to_pandas().drop(columns=[c for c in (ACCOUNT, TIME) if c], errors="ignore")
        df = df.merge(d.assign(_id=d[ID].map(str)).drop(columns=[ID]), on="_id", how="left", indicator=True)
        missing = int((df.pop("_merge") == "left_only").sum())
        if missing:
            raise SystemExit(f"{name}: {missing:,} of {n:,} export rows have no row in the derived file {derived}; "
                             "derive it from the same export")
    if raw_base:
        if not files:
            raise SystemExit(f"{name}: reading raw fields needs the export's own file range (--train-files or "
                             "--read-files)")
        numbers = list(range(files[0], files[1] + 1))
        fs = pg_layout.s3_filesystem(cred) if str(raw_base).startswith(("s3://", "s3a://")) else None
        parts = [pg_rows.read_columns(p, [ID] + list(raw_cols), fs) for p in pg_layout.file_paths(raw_base, numbers)]
        raw = pd.concat(parts, ignore_index=True)
        raw["_id"] = raw[ID].map(str)
        raw = raw.drop(columns=[ID]).drop_duplicates("_id")
        # the raw files' typed columns replace the export's text copies (the export keeps ids and keys only)
        df = df.drop(columns=[c for c in raw.columns if c in df.columns and c not in ("_id", ID, ACCOUNT, TIME, LABEL)])
        df = df.merge(raw, on="_id", how="left", indicator=True)
        missing = int((df.pop("_merge") == "left_only").sum())
        if missing:
            raise SystemExit(f"{name}: {missing:,} of {n:,} export rows are not in the raw files {files[0]}-{files[1]}; "
                             "give the file range the export was made from")
    if incumbent:
        df["incumbent_score"] = read_scores(incumbent).reindex(df["_id"]).to_numpy()
        have = int(np.isfinite(df["incumbent_score"].to_numpy(float)).sum())
        notes.append(f"{name}: 15298 scores for {have:,} of {n:,} rows")
    if incumbent_features:
        f = pd.read_parquet(incumbent_features) if incumbent_features.endswith(".parquet") else pd.read_csv(
            incumbent_features, dtype={ID: str})
        if ID not in f.columns:
            raise SystemExit(f"{name}: {incumbent_features} has no column {ID}")
        f = f.assign(_id=f[ID].map(str)).drop(columns=[ID]).drop_duplicates("_id")
        held = [c for c in f.columns if c in (ACCOUNT, TIME, LABEL)]     # never inputs, whatever the file holds
        f = f.drop(columns=held)
        for c in f.columns:
            if c != "_id" and f[c].isna().all():
                f[c] = np.nan                                             # no value at all: a number, all missing
        # the tree model's inputs are numbers; a column that is not is left out and named
        cols = [c for c in f.columns if c != "_id" and pd.api.types.is_numeric_dtype(f[c])]
        left = [c for c in f.columns if c != "_id" and c not in cols]
        df = df.merge(f[["_id"] + cols].rename(columns={c: f"inc_{c}" for c in cols}), on="_id", how="left",
                      indicator=True)
        have = int((df.pop("_merge") == "both").sum())
        notes.append(f"{name}: 15298's own inputs ({len(cols)} columns) for {have:,} of {n:,} rows: "
                     + ", ".join(cols[:8]) + (" ..." if len(cols) > 8 else "")
                     + (f"; left out, not numbers: {', '.join(left[:8])}" + (" ..." if len(left) > 8 else "")
                        if left else "")
                     + (f"; left out, the export's own keys or label: {', '.join(held)}" if held else ""))
    if pfm:
        p = pd.read_parquet(pfm) if pfm.endswith(".parquet") else pd.read_csv(pfm)
        p = p.assign(_id=p[ID].map(str))
        cols = [c for c in p.columns if c.startswith(pfm_prefix)]
        df = df.merge(p[["_id"] + cols].drop_duplicates("_id").rename(columns={c: f"pfm_{c}" for c in cols}),
                      on="_id", how="left", indicator=True)
        have = int((df.pop("_merge") == "both").sum())
        notes.append(f"{name}: PFM embeddings for {have:,} of {n:,} rows (the others are missing values to the trees)")
    if june:
        t = pd.to_datetime(df[TIME])
        df = df[(t >= pd.Timestamp(pg_rows.TARGETS[0])) & (t < pd.Timestamp(pg_rows.TARGETS[1]))]
    return df.reset_index(drop=True), notes


def groups(df, raw_cols):
    vec = [c for c in df.columns if c.startswith("e_") and c[2:].isdigit()]
    return {"raw": [c for c in raw_cols if c in df.columns], "score": ["score"], "vector": vec,
            "pca16": [c for c in df.columns if c.startswith("pca16_")],
            "orth": [c for c in df.columns if c.startswith("o_") and c[2:].isdigit()],
            "windows": [c for c in df.columns if c.startswith(("w1d_", "w7d_", "w30d_", "dev", "n1d", "n7d", "n30d"))],
            "pfm": [c for c in df.columns if c.startswith("pfm_")],
            # for the arms that join the two models: our logit, 15298's margin as a column, 15298's own inputs
            "logit": [c for c in ("score_logit",) if c in df.columns],
            "margin": [c for c in ("incumbent_margin",) if c in df.columns],
            "incumbent": [c for c in df.columns if c.startswith("inc_")]}


def arm_columns(arm, g):
    if arm == "offset":
        return g["score"] + g["vector"]
    if arm == "offset_raw":
        return g["raw"]
    if arm == "offset_open":       # 15298's margin is the start and also a column, so the trees can turn it down
        return g["logit"] + g["margin"] + g["raw"] + g["vector"] + g["incumbent"]
    if arm == "flipped":           # our logit is the start; the trees get 15298's side
        return g["margin"] + g["raw"] + g["incumbent"]
    if arm == "joined":            # the two-weight sum is the start; the trees get everything
        return g["logit"] + g["margin"] + g["raw"] + g["vector"] + g["incumbent"]
    if arm == "two_weights":       # no trees
        return []
    cols = []
    for part in arm.split("+"):
        cols += g[part]
    return cols


def to_matrix(df, cols, categories):
    """The trees' columns: a coded field as a category, any other as a float32 number, with a value that is not a
    finite number (text, an overflow, an infinity) as a missing one."""
    held = {}
    for c in cols:
        if c in categories:
            held[c] = pd.Categorical(df[c].map(lambda v: None if v is None or (isinstance(v, float) and math.isnan(v))
                                               else str(v)), categories=categories[c])
        else:
            with np.errstate(over="ignore"):
                held[c] = pd.to_numeric(df[c], errors="coerce").astype(np.float32).replace([np.inf, -np.inf], np.nan)
    return pd.DataFrame(held, index=df.index, columns=list(cols))


def logit(p, floor=1e-6):
    p = np.clip(np.asarray(p, float), floor, 1 - floor)
    return np.log(p / (1 - p))


def two_weights(y, theirs, ours, steps=200):
    """(constant, weight of 15298's margin, weight of our logit) of the logistic fit y ~ constant + a * theirs +
    b * ours. A weight near zero (times the spread of its margin) says that model adds little beside the other; the
    offset arm holds 15298's weight at one whatever the rows say.

    Newton steps on the log likelihood, each shortened until the likelihood rises, so that the fit cannot overshoot
    and settle where the rows are scored 0 or 1 outright (a plain Newton step does on a score with a long tail). It
    is made on the two margins centred and scaled to a spread of one, and the weights are handed back for the
    margins as given, so that a score handed over on another scale (points from 0 to 999) is fitted as well as a
    margin. Rows that one score splits cleanly have no largest likelihood: the weights then grow until the steps
    run out and stay finite."""
    y = np.asarray(y, float)
    given = [np.asarray(theirs, float), np.asarray(ours, float)]
    centre = [float(c.mean()) for c in given]
    spread = [float(c.std()) or 1.0 for c in given]
    x = np.stack([np.ones(len(y))] + [(c - m) / sd for c, m, sd in zip(given, centre, spread)], 1)

    def likelihood(w):
        z = x @ w
        return float(np.sum(y * z - np.logaddexp(0.0, z)))

    rate = min(max(float(y.mean()), 1e-9), 1 - 1e-9)
    w = np.array([math.log(rate / (1 - rate)), 0.0, 0.0])
    value = likelihood(w)
    for _ in range(steps):
        p = np.exp(-np.logaddexp(0.0, -(x @ w)))
        grad = x.T @ (y - p)
        hess = (x * (p * (1 - p))[:, None]).T @ x + 1e-8 * np.eye(3)
        step = np.linalg.solve(hess, grad)
        share = 1.0
        while share > 1e-10:
            new = w + share * step
            risen = likelihood(new)
            if risen >= value + 1e-4 * share * float(grad @ step):
                break
            share /= 2
        else:
            break
        moved = float(np.abs(new - w).max())
        w, value = new, risen
        if moved < 1e-10:
            break
    a, b = w[1] / spread[0], w[2] / spread[1]
    return np.array([w[0] - a * centre[0] - b * centre[1], a, b])


MARGIN = {"kind": "logit"}


def margin_of(scores):
    """XGBoost's starting margin from 15298's score: its logit when the scores are probabilities, else the score."""
    s = np.asarray(scores, float)
    return logit(s) if MARGIN["kind"] == "logit" else s


def amount_weights(amounts, power):
    """--amount-power: each row weighs (its amount over the median amount) to that power, kept between a millionth
    and a million. A row whose amount is missing, not a number, zero or negative weighs 1; the median is that of
    the other rows."""
    amt = pd.to_numeric(pd.Series(np.asarray(amounts, dtype=object)), errors="coerce").to_numpy(float)
    ok = np.isfinite(amt) & (amt > 0)
    mid = float(np.median(amt[ok])) if ok.any() else 1.0
    with np.errstate(over="ignore", under="ignore"):
        raised = (np.where(ok, amt, mid) / mid) ** float(power)
    return np.where(ok, np.clip(raised, 1e-6, 1e6), 1.0)


def uniform_hash(values, seed):
    """A fixed number in [0, 1) per value (the same in every run for the same seed)."""
    key = f"{int(seed) % 10 ** 16:016d}"
    h = pd.util.hash_pandas_object(pd.Series(values, dtype=object).map(str), index=False, hash_key=key)
    return h.to_numpy(np.uint64).astype(np.float64) / float(2 ** 64)


def inner_split(accounts, share=0.1, seed=42):
    """(fit rows, held-out rows): a share of the accounts, whole, is held out for early stopping."""
    u = uniform_hash(pd.Series(accounts).map(str).to_numpy(), seed)
    return u >= share, u < share


def fit_arm(train, cols, categories, start, params, seed=42, rounds=2000, early=50, tune=0, tune_share=1.0,
            delta=None, max_bin=256, weight=None):
    """One arm's trees. `start` is the fixed starting margin of each training row (None: XGBoost's own start),
    `delta` a max_delta_step, `weight` a weight per training row (the fit rows' only). Trees stop being added when
    aucpr on a held-out tenth of the accounts has not improved for `early` rounds. Stopping on that tenth's share of
    frauds in its top 0.6 percent was tried on synthetic rows: where the trees had much to add it stopped at 41
    trees and read 74.0 percent, against 118 trees and 75.2 on aucpr; where they had nothing to add both read the
    same."""
    import xgboost as xgb
    y = train[LABEL].to_numpy(np.int64)
    fit_rows, val_rows = inner_split(train[ACCOUNT].to_numpy())
    x = to_matrix(train, cols, categories)
    margin = None if start is None else np.asarray(start, float)
    weight = None if weight is None else np.asarray(weight, float)

    def dm(mask, weighted=False):
        return xgb.DMatrix(x[mask], label=y[mask], base_margin=None if margin is None else margin[mask],
                           weight=weight[mask] if weighted and weight is not None else None, enable_categorical=True)

    def train_once(p, fit_mask):
        settings = {"objective": "binary:logistic", "eval_metric": "aucpr", "tree_method": "hist",
                    "max_bin": int(max_bin), "seed": seed, "nthread": -1,
                    **({"max_delta_step": float(delta)} if delta else {}), **p}
        # the weights count in the fit; the held-out tenth is read unweighted, so that aucpr means the same with
        # and without them
        booster = xgb.train(settings, dm(fit_mask, True), num_boost_round=rounds, evals=[(dm(val_rows), "valid")],
                            early_stopping_rounds=early, verbose_eval=False)
        return booster, float(booster.best_score)

    best_p, trials = dict(params), []
    if tune:
        rng = np.random.default_rng(seed)
        sub = fit_rows & (inner_split(train[ACCOUNT].to_numpy(), 1.0 - tune_share, seed + 7)[0] | (tune_share >= 1))
        best = -1.0
        for _ in range(int(tune)):
            p = {"learning_rate": float(np.exp(rng.uniform(np.log(0.01), np.log(0.3)))),
                 "max_depth": int(rng.integers(3, 11)), "min_child_weight": float(np.exp(rng.uniform(0, np.log(100)))),
                 "subsample": float(rng.uniform(0.5, 1.0)), "colsample_bytree": float(rng.uniform(0.3, 1.0)),
                 "reg_lambda": float(np.exp(rng.uniform(np.log(1e-3), np.log(10)))),
                 "reg_alpha": float(np.exp(rng.uniform(np.log(1e-3), np.log(10))))}
            _, score = train_once(p, sub)
            trials.append({"params": p, "aucpr": score})
            if score > best:
                best, best_p = score, p
    booster, score = train_once(best_p, fit_rows)
    return booster, {"params": best_p, "inner_aucpr": score, "max_bin": int(max_bin),
                     "best_iteration": int(booster.best_iteration), "tuning_trials": len(trials)}


def predict(booster, df, cols, categories, start):
    """The arm's margin for each row: the row's own starting margin (when the arm has one) plus the trees."""
    import xgboost as xgb
    d = xgb.DMatrix(to_matrix(df, cols, categories), base_margin=None if start is None else np.asarray(start, float),
                    enable_categorical=True)
    return booster.predict(d, iteration_range=(0, booster.best_iteration + 1), output_margin=True)


def run(a):
    raw_cols = a.raw_cols or (RAW_CONTINUOUS + RAW_CATEGORICAL)
    train, n1 = frame(a.train_export, a.train_derived, a.train_raw_base, a.train_files, a.cred, raw_cols,
                      a.incumbent_train, a.pfm_train, a.pfm_prefix, name="training rows",
                      incumbent_features=a.incumbent_features_train)
    read, n2 = frame(a.read_export, a.read_derived, a.read_raw_base, a.read_files, a.cred, raw_cols, a.incumbent_read,
                     a.pfm_read, a.pfm_prefix, june=not a.all_read_rows, name="read rows",
                     incumbent_features=a.incumbent_features_read)
    notes = n1 + n2
    # 15298's own inputs are used where the training rows and the read rows both hold them
    inputs = [[c for c in d.columns if c.startswith("inc_")] for d in (train, read)]
    one_side = sorted(set(inputs[0]) ^ set(inputs[1]))
    if one_side:
        for d in (train, read):
            d.drop(columns=[c for c in one_side if c in d.columns], inplace=True)
        notes.append("15298's own inputs held for the training rows or for the read rows only are left out: "
                     + ", ".join(c[4:] for c in one_side[:8]) + (" ..." if len(one_side) > 8 else ""))
    if a.amount_power and AMOUNT not in train:
        notes.append(f"--amount-power: the training rows hold no {AMOUNT}; no weights are used")
    # continuous raw fields stay numbers; the coded fields (and any other text field) are categories
    categories = {c: sorted(set(train[c].dropna().map(str))) for c in raw_cols
                  if c in train and c not in RAW_CONTINUOUS and (c in RAW_CATEGORICAL or train[c].dtype == object)}
    if "incumbent_score" in train:
        vals = pd.concat([train["incumbent_score"], read.get("incumbent_score", pd.Series(dtype=float))])
        vals = vals[np.isfinite(vals.to_numpy(float))]
        MARGIN["kind"] = "logit" if len(vals) and vals.between(0, 1).all() else "raw"
        if MARGIN["kind"] == "raw":
            low, high = float(vals.min()), float(vals.max())
            notes.append("15298's scores are not all between 0 and 1: they are used as the starting margin as they are"
                         + (f". They run from {low:g} to {high:g}, which looks like points on a scale and not like "
                            "margins (log-odds): every arm that starts from 15298 then starts from a wrong margin. "
                            "Hand over 15298's probabilities, or its margins (predict with output_margin=True)"
                            if low >= 0 and high > 50 else ""))
    # the two margins as columns: 15298's (also the start of the offset arms) and ours (the start of `flipped`).
    # Ours is the logit of the exported score, or the score itself where the export already holds margins
    ours_all = pd.concat([d["score"] for d in (train, read) if "score" in d] or [pd.Series(dtype=float)])
    ours_all = ours_all[np.isfinite(ours_all.to_numpy(float))]
    ours_is_share = bool(len(ours_all)) and bool(ours_all.between(0, 1).all())
    for d in (train, read):
        if "score" in d:
            mine = d["score"].to_numpy(float)
            d["score_logit"] = logit(mine, 1e-7) if ours_is_share else mine
        if "incumbent_score" in d:
            d["incumbent_margin"] = margin_of(d["incumbent_score"].to_numpy(float))
    g = groups(train, raw_cols)
    # every arm that joins the two models needs 15298's scores; the ones that read or start from ours need ours too
    needs = {"15298": ("incumbent_margin",), "ours": ("incumbent_margin", "score_logit"),
             "two_weights": ("incumbent_margin", "score_logit")}
    weights = None
    if any(JOINS.get(arm, ("",))[0] == "two_weights" for arm in a.arms) and all(
            c in d for c in needs["two_weights"] for d in (train, read)):
        theirs, mine = train["incumbent_margin"].to_numpy(float), train["score_logit"].to_numpy(float)
        both = np.isfinite(theirs) & np.isfinite(mine)
        spread = (float(np.std(theirs[both])), float(np.std(mine[both]))) if both.any() else (0.0, 0.0)
        if both.any() and 0 < train.loc[both, LABEL].sum() < both.sum() and min(spread) > 0:
            weights = two_weights(train.loc[both, LABEL].to_numpy(float), theirs[both], mine[both])
            # a weight counts per unit of its margin; times the margin's spread, the two can be set side by side
            # whatever scale each score was handed over on
            per_spread = (float(weights[1] * spread[0]), float(weights[2] * spread[1]))
            notes.append(f"two weights, fitted on {int(both.sum()):,} training rows: constant {weights[0]:+.3f}, "
                         f"15298's margin {weights[1]:.3f}, our logit {weights[2]:.3f}. Over one standard deviation "
                         f"of its margin that is {per_spread[0]:.2f} for 15298 and {per_spread[1]:.2f} for ours: "
                         "the model whose number is near zero adds little beside the other on these rows")
        elif both.any() and min(spread) == 0:
            notes.append("two weights: one of the two margins is the same on every training row, so no weight can "
                         "be fitted for it")

    def start_of(kind, d):
        """The starting margin of each row of `d` for one kind of start (not finite where a score is missing)."""
        if kind == "15298":
            return d["incumbent_margin"].to_numpy(float)
        if kind == "ours":
            return d["score_logit"].to_numpy(float)
        return (weights[0] + weights[1] * d["incumbent_margin"].to_numpy(float)
                + weights[2] * d["score_logit"].to_numpy(float))

    def covered(kind, d):
        """The rows of `d` that have every score an arm of this kind needs."""
        ok = np.ones(len(d), bool)
        for c in needs[kind]:
            ok &= np.isfinite(d[c].to_numpy(float))
        return ok

    def row_weights(d):
        return amount_weights(d[AMOUNT], a.amount_power) if a.amount_power and AMOUNT in d else None

    scores, fits, valid = {}, {}, {}
    all_rows = np.ones(len(read), bool)
    for arm in a.arms:
        kind, delta = JOINS.get(arm, (None, None))
        if kind:
            lacks = [c for c in needs[kind] for d in (train, read) if c not in d]
            if lacks or (kind == "two_weights" and weights is None):
                why = ("no 15298 scores given" if "incumbent_margin" in lacks else "the export holds no score"
                       if lacks else "the two weights could not be fitted")
                notes.append(f"{arm}: skipped ({why})")
                continue
        if arm == "two_weights":
            start = start_of(kind, read)
            scores[arm], valid[arm] = start, np.isfinite(start)
            fits[arm] = {"columns": 0, "constant": float(weights[0]), "weight_15298": float(weights[1]),
                         "weight_ours": float(weights[2]), "per_spread_15298": per_spread[0],
                         "per_spread_ours": per_spread[1]}
            print(f"{arm}: constant {weights[0]:+.3f}, 15298's margin {weights[1]:.3f}, our logit {weights[2]:.3f}",
                  flush=True)
            continue
        cols = arm_columns(arm, g)
        if not cols or (("pfm" in arm) and not g["pfm"]):
            notes.append(f"{arm}: skipped (its columns are not in the files)")
            continue
        fit_rows, start = train, None
        if kind:
            start = start_of(kind, train)
            ok = np.isfinite(start) & covered(kind, train)
            if not ok.any():
                notes.append(f"{arm}: skipped (no training row has its starting score)")
                continue
            fit_rows, start = train[ok].reset_index(drop=True), start[ok]
        booster, info = fit_arm(fit_rows, cols, categories, start, dict(FIXED), tune=a.tune, tune_share=a.tune_share,
                                delta=delta, max_bin=a.max_bin, weight=row_weights(fit_rows))
        pred = np.full(len(read), np.nan)
        start_read = start_of(kind, read) if kind else None
        rows = (np.isfinite(start_read) & covered(kind, read)) if kind else all_rows
        if rows.any():
            pred[rows] = predict(booster, read[rows].reset_index(drop=True), cols, categories,
                                 None if start_read is None else start_read[rows])
        scores[arm], valid[arm] = pred, rows & np.isfinite(pred)
        fits[arm] = {"columns": len(cols), "fit_rows": int(len(fit_rows)), "start": kind or "none", **info}
        print(f"{arm}: {len(cols)} columns, {info['best_iteration'] + 1} trees, inner aucpr {info['inner_aucpr']:.4f}",
              flush=True)
    if "incumbent_score" in read:
        inc = read["incumbent_score"].to_numpy(float)
        if np.isfinite(inc).any():
            scores["15298"], valid["15298"] = inc, np.isfinite(inc)
    if "score" in read:
        scores["ours"], valid["ours"] = read["score"].to_numpy(float), np.isfinite(read["score"].to_numpy(float))
    y = read[LABEL].to_numpy(np.int64)
    amounts = pd.to_numeric(read[AMOUNT], errors="coerce").to_numpy(float) if AMOUNT in read else None
    key_rank, codes, n_units = R.prepare(read[ACCOUNT].to_numpy(), read[ID].to_numpy())

    def ranked_on(name, idx):
        am = None if amounts is None else amounts[idx]
        return R.RankedScore(scores[name][idx], y[idx], codes[idx], key_rank[idx], am)

    points = {}
    for k in list(scores):
        idx = np.flatnonzero(valid[k])
        if not len(idx):
            notes.append(f"{k}: no read row has the scores it needs; it is not read")
            del scores[k]
            continue
        points[k] = dict(ranked_on(k, idx).evaluate(None), rows_read=int(len(idx)))
    pairs = []
    for left, right in PAIRS:
        if left in scores and right in scores:
            idx = np.flatnonzero(valid[left] & valid[right])
            if not len(idx) or not y[idx].sum():
                notes.append(f"{left} vs {right}: no common rows with a fraud")
                continue
            met = R.paired([ranked_on(left, idx)], [ranked_on(right, idx)], n_units, a.draws, a.seed, 90.0)
            pairs.append({"pair": f"{left} vs {right}", "rows": int(len(idx)),
                          **{m: {k: met[m][k] for k in ("gain", "sd", "lo", "hi")} for m in ("udr", "ap", "vdr")}})
    return {"read_rows": int(len(y)), "read_frauds": int(y.sum()), "train_rows": int(len(train)), "fits": fits,
            "points": {k: {**{m: p[m] for m in R.METRICS}, "rows_read": p["rows_read"]} for k, p in points.items()},
            "pairs": pairs, "notes": notes}


def screen(rec):
    lines = [f"downstream: trained on {rec['train_rows']:,} rows, read on {rec['read_rows']:,} rows "
             f"({rec['read_frauds']:,} frauds)"] + rec["notes"]
    lines.append(f"{'arm':<20}{'UDR':>8}{'AP':>8}{'VDR':>8}{'FPR':>7}{'AUROC':>8}{'rows':>12}")
    for k, p in rec["points"].items():
        lines.append(f"{k:<20}{p['udr']:>8.4f}{p['ap']:>8.4f}{p['vdr']:>8.4f}{p['fpr']:>7.2f}{p['auroc']:>8.4f}"
                     f"{p['rows_read']:>12,}")
    for p in rec["pairs"]:
        u, v = p["udr"], p["vdr"]
        value = "" if v["gain"] is None or not np.isfinite(v["gain"]) else (
            f"  VDR {v['gain']:+.4f} [{v['lo']:+.4f}, {v['hi']:+.4f}]")
        lines.append(f"{p['pair']} ({p['rows']:,} rows): UDR {u['gain']:+.4f} [{u['lo']:+.4f}, {u['hi']:+.4f}]"
                     f"{value}  AP {p['ap']['gain']:+.4f}")
    return "\n".join(lines)


def main(argv=None):
    ap = argparse.ArgumentParser(description="downstream arms: does the vector add beyond the score")
    ap.add_argument("--train-export", required=True)
    ap.add_argument("--train-derived", default=None)
    ap.add_argument("--read-export", required=True)
    ap.add_argument("--read-derived", default=None)
    ap.add_argument("--train-raw-base", default=None)
    ap.add_argument("--train-files", type=int, nargs=2, default=None, metavar=("START", "END"),
                    help="the file range the training export was made from (DS_TRAIN: 4001 4010)")
    ap.add_argument("--read-raw-base", default=None)
    ap.add_argument("--read-files", type=int, nargs=2, default=None, metavar=("START", "END"),
                    help="the file range the read export was made from (DS_SELECT: 8217 8227; FINAL: 8260 8277)")
    ap.add_argument("--cred", default=None)
    ap.add_argument("--raw-cols", nargs="+", default=None)
    ap.add_argument("--incumbent-train", default=None, help="15298 scores on the training rows: PATH[:COLUMN]")
    ap.add_argument("--incumbent-read", default=None, help="15298 scores on the read rows: PATH[:COLUMN]")
    ap.add_argument("--incumbent-features-train", default=None,
                    help="15298's own input columns on the training rows (Parquet or CSV with the transaction id); "
                         "used by the arms flipped, joined and offset_open")
    ap.add_argument("--incumbent-features-read", default=None, help="the same on the read rows")
    ap.add_argument("--pfm-train", default=None)
    ap.add_argument("--pfm-read", default=None)
    ap.add_argument("--pfm-prefix", default="emb_")
    ap.add_argument("--arms", nargs="+", default=["raw", "raw+score", "raw+score+vector", "raw+vector"],
                    choices=ARMS)
    ap.add_argument("--all-read-rows", action="store_true", help="read every exported row, not only June targets")
    ap.add_argument("--max-bin", type=int, default=256,
                    help="bins per column for the trees (XGBoost's own 256). 256 puts the top 0.39 percent of the "
                         "rows of a score column into one bin; 4096 puts about 25 cut points inside the top 0.6 "
                         "percent and takes about three times as long")
    ap.add_argument("--amount-power", type=float, default=0.0,
                    help="weigh each row the trees are fitted on by (its amount over the median amount) to this "
                         "power; 0 is off. A row with no amount, or one that is zero or negative, weighs 1; the "
                         "held-out rows and the two weights are not weighted")
    ap.add_argument("--tune", type=int, default=0)
    ap.add_argument("--tune-share", type=float, default=0.25)
    ap.add_argument("--draws", type=int, default=2000)
    ap.add_argument("--seed", type=int, default=20261102)
    ap.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    out = Path(a.out)
    rec = run(a)
    text = screen(rec)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(rec, indent=1, default=float))
    out.with_suffix(".txt").write_text(text + "\n")
    print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
