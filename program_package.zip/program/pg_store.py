"""A versioned, keyed table of exported vectors with two lookups: by transaction id, and point in time by account.

Where it runs: the pod CPU. The table is a folder on the workbench (copy it to S3 afterwards if needed).

Layout of a store folder:
    <store>/<model>/<version>/part-<k>.parquet    the export's rows (and derived columns if given)
    <store>/<model>/<version>/manifest.json        model, version, checkpoint, source files, columns, rows, time range
A new checkpoint is a new version: vectors from different checkpoints live in different spaces and are never mixed.

Lookups:
- by_ids(ids): the rows of those transactions.
- as_of(accounts, times): for each (account, time), the latest row of that account strictly before the time (never
  the same second), with its vector, score and time, never its label. This is the point-in-time read a downstream
  model uses. Account ids and times are read the same way on both sides (a float id 37389549.0 matches 37389549;
  times in any unit or time zone).

Usage:
    $PY program/pg_store.py write --store runs/program/store --model allpos_h20 --version v1 \
        --export runs/program/export/ds_select.parquet [--derived runs/program/export/ds_select_derived.parquet] \
        --checkpoint runs/program/final_s42/best.ckpt
    $PY program/pg_store.py as-of --store runs/program/store --model allpos_h20 --version v1 \
        --queries queries.csv --out answers.parquet       (queries: account and time columns)
"""
import argparse
import datetime as dt
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

ACCOUNT, ID, TIME, LABEL = "Nmap_account_reference_xid", "fi_transaction_id", "transaction_dttm", "frd_tag"


def account_key(values):
    """Account ids as one text form on both sides: a whole number stored as a float (37389549.0) reads 37389549."""
    def one(v):
        if v is None or (isinstance(v, float) and np.isnan(v)):
            return ""
        try:
            f = float(v)
            if np.isfinite(f) and f == int(f):
                return str(int(f))
        except (TypeError, ValueError):
            pass
        return str(v).strip()
    return pd.Series(values).map(one).to_numpy()


def second_times(values):
    """Times as naive UTC whole seconds in nanosecond precision, whatever unit or time zone they came in."""
    t = pd.to_datetime(pd.Series(values), utc=True).dt.tz_localize(None)
    return t.astype("datetime64[ns]").dt.floor("s")


def version_dir(store, model, version):
    if "://" in str(store):
        raise SystemExit(f"--store is a folder on this workbench (got {store}); copy the folder to S3 afterwards if "
                         "needed")
    return Path(store) / model / version


def write(store, model, version, export, derived=None, checkpoint=None, id_col=ID, account_col=ACCOUNT,
          time_col=TIME):
    d = version_dir(store, model, version)
    d.mkdir(parents=True, exist_ok=True)
    existing = sorted(d.glob("part-*.parquet"))
    df = pq.read_table(export).to_pandas()
    if derived:
        extra = pq.read_table(derived).to_pandas()
        extra = extra.drop(columns=[c for c in (account_col, time_col) if c in extra])
        df = df.merge(extra, on=id_col, how="left", validate="one_to_one")
    df[time_col] = second_times(df[time_col]).to_numpy()
    part = d / f"part-{len(existing):05d}.parquet"
    man_path = d / "manifest.json"
    if man_path.is_file():
        earlier = {p.get("checkpoint") for p in json.loads(man_path.read_text())["parts"]} - {None}
        if checkpoint and earlier and str(checkpoint) not in earlier:
            print(f"note: {model}/{version} already holds vectors from {sorted(earlier)}; vectors of another "
                  f"checkpoint ({checkpoint}) live in a different space: write them under a new --version", flush=True)
    df.to_parquet(part, index=False)
    man = json.loads(man_path.read_text()) if man_path.is_file() else {
        "model": model, "version": version, "checkpoint": str(checkpoint) if checkpoint else None, "parts": [],
        "keys": {"id": id_col, "account": account_col, "time": time_col},
        "created_utc": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")}
    man["parts"].append({"file": part.name, "source": str(export), "derived": str(derived) if derived else None,
                         "checkpoint": str(checkpoint) if checkpoint else None,
                         "rows": int(len(df)), "from": str(df[time_col].min()), "to": str(df[time_col].max())})
    man["columns"] = list(df.columns)
    man["rows"] = int(sum(p["rows"] for p in man["parts"]))
    man_path.write_text(json.dumps(man, indent=1))
    print(f"{model}/{version}: wrote {part.name} ({len(df):,} rows); store holds {man['rows']:,} rows")
    return man


def load(store, model, version, columns=None):
    d = version_dir(store, model, version)
    man = json.loads((d / "manifest.json").read_text())
    frames = [pq.read_table(d / p["file"], columns=columns).to_pandas() for p in man["parts"]]
    return pd.concat(frames, ignore_index=True), man


def by_ids(store, model, version, ids):
    df, man = load(store, model, version)
    return df[df[man["keys"]["id"]].astype(str).isin(set(map(str, ids)))].reset_index(drop=True)


def as_of(store, model, version, queries, columns=None):
    """queries: a frame with the account and time columns. Returns the queries with the latest strictly earlier row
    of each account joined on (null when the account has no earlier row). The label is never returned: at a
    decision it is not known yet."""
    df, man = load(store, model, version)
    acct, t = man["keys"]["account"], man["keys"]["time"]
    keep = columns or [c for c in df.columns if c not in (acct, LABEL, "label")]
    right = df[[c for c in keep if c != acct]].copy()
    right = right.rename(columns={t: "_row_time"}) if t in right else right.assign(_row_time=df[t].to_numpy())
    right["_acct"] = account_key(df[acct].to_numpy())
    right["_row_time"] = second_times(right["_row_time"]).to_numpy()
    left = queries.copy()
    left["_acct"] = account_key(left[acct].to_numpy())
    left["_query_time"] = second_times(left[t]).to_numpy()
    left["_order"] = np.arange(len(left))
    left = left.sort_values("_query_time")
    right = right.sort_values("_row_time")
    got = pd.merge_asof(left, right, left_on="_query_time", right_on="_row_time", by="_acct",
                        allow_exact_matches=False, direction="backward")
    known = set(right["_acct"])
    no_account = int((~left["_acct"].isin(known)).sum())
    no_earlier = int(got["_row_time"].isna().sum()) - no_account
    print(f"as-of: {len(left):,} queries; {no_account:,} accounts not in the table; {no_earlier:,} with no earlier "
          "row", flush=True)
    return got.sort_values("_order").drop(columns=["_order", "_acct"]).reset_index(drop=True)


def main(argv=None):
    ap = argparse.ArgumentParser(description="the embedding table")
    ap.add_argument("command", choices=("write", "as-of", "ids"))
    ap.add_argument("--store", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--version", required=True)
    ap.add_argument("--export", default=None)
    ap.add_argument("--derived", default=None)
    ap.add_argument("--checkpoint", default=None)
    ap.add_argument("--queries", default=None, help="CSV or parquet with the account and time (as-of) or id (ids)")
    ap.add_argument("--out", default=None)
    a = ap.parse_args(argv)
    if a.command == "write":
        write(a.store, a.model, a.version, a.export, a.derived, a.checkpoint)
        return 0
    q = pd.read_parquet(a.queries) if a.queries.endswith(".parquet") else pd.read_csv(a.queries, dtype=str)
    if a.command == "as-of":
        got = as_of(a.store, a.model, a.version, q)
    else:
        got = by_ids(a.store, a.model, a.version, q[ID].tolist())
    if a.out:
        got.to_parquet(a.out, index=False)
    print(got.head(10).to_string())
    print(f"{len(got):,} rows")
    return 0


if __name__ == "__main__":
    sys.exit(main())
