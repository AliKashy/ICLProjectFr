"""The rows a read is made on, and the prediction files aligned to them.

Rows come from the raw files of a file range: every row is read (history months included), then the target window
(June 2025 by default) is kept. Optional filters drop declined rows and advice rows; optional slice columns are kept
for the slice table. Predictions are joined on (account, id); every prediction file must hold every read row with
the same label.
"""
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

import pg_layout
import pg_ranked as R

COLUMNS = SimpleNamespace(id="fi_transaction_id", account="Nmap_account_reference_xid", label="frd_tag",
                          time="transaction_dttm", score="score", amount="transaction_amt",
                          decline="predecline", decline_values=("1", "Y", "True", "true"),
                          advice="transaction_advice_xcd",
                          card_present="cardholder_present_xflg")
TARGETS = ("2025-06-01", "2025-07-01")


class DataError(Exception):
    """The files do not hold what the read needs (exit 3)."""


def strip_scheme(path):
    for scheme in ("s3://", "s3a://"):
        if str(path).startswith(scheme):
            return str(path)[len(scheme):]
    return str(path)


def read_columns(path, wanted, fs=None):
    """The wanted columns that exist in one parquet file (local or S3)."""
    if fs is None:
        names = set(pq.ParquetFile(path).schema_arrow.names)
        cols = [c for c in dict.fromkeys(wanted) if c in names]
        return pq.read_table(path, columns=cols).to_pandas()
    ds = pq.ParquetDataset(strip_scheme(path), filesystem=fs)
    names = set(ds.schema.names)
    cols = [c for c in dict.fromkeys(wanted) if c in names]
    return ds.read(columns=cols).to_pandas()


def as_text(values):
    return pd.Series(values).map(lambda v: "" if v is None or (isinstance(v, float) and np.isnan(v)) else str(v))


def raw_rows(base, numbers, c=COLUMNS, cred=None, extra=()):
    """Every row of the raw files part_<n>.parquet (n in numbers) with the id, account, label, time and any extra
    columns that exist, plus _same_second (another row of the account has the same whole second) and _earlier
    (rows of the account strictly earlier in its file)."""
    fs = pg_layout.s3_filesystem(cred) if str(base).startswith(("s3://", "s3a://")) else None
    wanted = [c.id, c.account, c.label, c.time, c.amount, c.decline, c.advice, c.card_present, *extra]
    frames = []
    for n, path in zip(numbers, pg_layout.file_paths(base, numbers)):
        df = read_columns(path, wanted, fs)
        missing = [x for x in (c.id, c.account, c.label, c.time) if x not in df]
        if missing:
            raise DataError(f"{path} has no column(s) {missing}")
        df["_file"] = int(n)
        frames.append(df)
    raw = pd.concat(frames, ignore_index=True)
    out = pd.DataFrame({"_acct": raw[c.account].map(str).to_numpy(), "_id": raw[c.id].map(str).to_numpy(),
                        "_label": pd.to_numeric(raw[c.label], errors="coerce").to_numpy(float),
                        "_time": pd.to_datetime(raw[c.time], utc=True).dt.tz_localize(None).to_numpy(),
                        "_file": raw["_file"].to_numpy()})
    if not np.isin(out["_label"].to_numpy(), [0.0, 1.0]).all():
        raise DataError("raw labels must be 0 or 1")
    out["_label"] = out["_label"].astype(np.int64)
    for col in (c.amount, c.decline, c.advice, c.card_present, *extra):
        if col in raw:
            out[col] = raw[col].to_numpy()
    sec = out["_time"].to_numpy().astype("datetime64[s]").astype(np.int64)
    out["_sec"] = sec
    counts = out.groupby(["_acct", "_sec"])["_id"].transform("size").to_numpy()
    out["_same_second"] = counts > 1
    # rows of the account strictly earlier: rank of the second within the account, counting rows
    order = np.lexsort((sec, out["_acct"].to_numpy()))
    acct_sorted = out["_acct"].to_numpy()[order]
    sec_sorted = sec[order]
    new_acct = np.r_[True, acct_sorted[1:] != acct_sorted[:-1]]
    start = np.maximum.accumulate(np.where(new_acct, np.arange(len(order)), 0))
    new_sec = np.r_[True, (sec_sorted[1:] != sec_sorted[:-1]) | new_acct[1:]]
    first_of_sec = np.maximum.accumulate(np.where(new_sec, np.arange(len(order)), 0))
    earlier = np.empty(len(order), np.int64)
    earlier[order] = first_of_sec - start
    out["_earlier"] = earlier
    return out


def keep_targets(raw, targets=TARGETS):
    t = pd.to_datetime(raw["_time"])
    mask = (t >= pd.Timestamp(targets[0])) & (t < pd.Timestamp(targets[1]))
    return raw.loc[mask.to_numpy()].reset_index(drop=True)


def flag(values, accepted):
    """True where the value is one of the accepted values (as text; 1, 1.0 and "1" all match "1")."""
    text = as_text(values).str.strip()
    hit = text.isin([str(v) for v in accepted]).to_numpy()
    numeric = pd.to_numeric(text, errors="coerce")
    for v in accepted:
        try:
            hit |= (numeric == float(v)).to_numpy()
        except (TypeError, ValueError):
            pass
    return hit


def present(values):
    """True where the field holds any non-blank value."""
    return as_text(values).str.strip().ne("").to_numpy()


def apply_filters(rows, exclude, c=COLUMNS):
    """Drop declined rows (the decline field holds 1) and/or advice rows (the advice field holds any value).
    Returns (rows, notes)."""
    notes = []
    for what in exclude or ():
        col = {"declines": c.decline, "advice": c.advice}[what]
        if col not in rows:
            raise DataError(f"--exclude {what} needs column {col} in the raw files")
        drop = flag(rows[col], c.decline_values) if what == "declines" else present(rows[col])
        notes.append(f"{what}: {int(drop.sum()):,} rows dropped ({int(rows['_label'].to_numpy()[drop].sum())} frauds)")
        rows = rows.loc[~drop].reset_index(drop=True)
    return rows, notes


def prediction_frame(path, c=COLUMNS):
    have = set(pq.ParquetFile(path).schema_arrow.names)
    need = [c.account, c.id, c.label, c.score]
    missing = [x for x in need if x not in have]
    if missing:
        raise DataError(f"{path}: the prediction file lacks {missing}")
    cols = need + [x for x in (c.amount, "window_rows") if x in have]
    pred = pq.read_table(path, columns=cols).to_pandas()
    frame = pd.DataFrame({"_acct": pred[c.account].map(str).to_numpy(), "_id": pred[c.id].map(str).to_numpy(),
                          "_plabel": pd.to_numeric(pred[c.label], errors="coerce").to_numpy(float),
                          "_score": pd.to_numeric(pred[c.score], errors="coerce").to_numpy(float)})
    if c.amount in pred:
        frame["_pamount"] = pd.to_numeric(pred[c.amount], errors="coerce").to_numpy(float)
    if "window_rows" in pred:
        frame["_window_rows"] = pd.to_numeric(pred["window_rows"], errors="coerce").to_numpy(float)
    dup = frame.duplicated(["_acct", "_id"])
    if dup.any():
        raise DataError(f"{path}: {int(dup.sum())} duplicate (account, id) rows")
    return frame


def rows_from_first(paths, c=COLUMNS):
    """The read's rows when no raw files are given: every row of the first prediction file."""
    first = prediction_frame(paths[0], c)
    rows = first[["_acct", "_id"]].assign(_label=first["_plabel"].to_numpy())
    if not np.isin(rows["_label"].to_numpy(), [0, 1]).all():
        raise DataError(f"{paths[0]}: labels must be 0 or 1")
    rows["_label"] = rows["_label"].astype(np.int64)
    if "_pamount" in first:
        rows[c.amount] = first["_pamount"].to_numpy()
    return rows.reset_index(drop=True)


def rows_from_ids(paths, keep_path, c=COLUMNS):
    """The rows whose ids (and accounts, if given) a CSV or parquet lists, taken from the first prediction file."""
    p = Path(keep_path)
    df = pd.read_parquet(p) if p.suffix == ".parquet" else pd.read_csv(p, dtype=str)
    if c.id not in df:
        raise DataError(f"{keep_path} has no column {c.id}")
    keep = pd.DataFrame({"_id": df[c.id].map(str)})
    if c.account in df:
        keep["_acct"] = df[c.account].map(str)
    keep = keep.drop_duplicates()
    rows = rows_from_first(paths, c)
    on = ["_acct", "_id"] if "_acct" in keep else ["_id"]
    out = rows.merge(keep, on=on, how="inner")
    if len(out) != len(keep):
        raise DataError(f"{len(keep) - len(out)} listed rows are not in {paths[0]}")
    return out.reset_index(drop=True)


def align(paths, rows, c=COLUMNS):
    """Scores of every prediction file on the read's rows, in the rows' order, and the shared arrays.

    Every file must hold every read row with the read's label (extra rows in a file are ignored)."""
    scores, windows = [], None
    amount = rows[c.amount].to_numpy(float) if c.amount in rows else None
    for path in paths:
        pred = prediction_frame(path, c)
        merged = rows[["_acct", "_id", "_label"]].merge(pred, on=["_acct", "_id"], how="left",
                                                       validate="one_to_one")
        n_missing = int(merged["_score"].isna().sum())
        if n_missing:
            raise DataError(f"{path}: {n_missing:,} of {len(rows):,} read rows are missing or have no score")
        bad = merged["_plabel"].to_numpy(float) != merged["_label"].to_numpy(float)
        if bad.any():
            raise DataError(f"{path}: {int(bad.sum())} labels differ from the read's labels")
        scores.append(merged["_score"].to_numpy(float))
        if amount is None and "_pamount" in merged:
            amount = merged["_pamount"].to_numpy(float)
        if windows is None and "_window_rows" in merged:
            windows = merged["_window_rows"].to_numpy(float)
    key_rank, codes, n_units = R.prepare(rows["_acct"].to_numpy(), rows["_id"].to_numpy())
    data = SimpleNamespace(y=rows["_label"].to_numpy(np.int64), amounts=amount, key_rank=key_rank, codes=codes,
                           n_units=n_units, rows=len(rows), windows=windows, frame=rows)
    data.amount_reason = R.amount_reason(amount)
    return data, scores


def ranked(data, scores, per_mille=6, rounding="floor", index=None):
    """RankedScore objects of each score array on the read's rows (or on a subset given by index)."""
    share = R.share_of(per_mille)
    if index is None:
        return [R.RankedScore(s, data.y, data.codes, data.key_rank, data.amounts, share, rounding) for s in scores]
    amounts = None if data.amounts is None else data.amounts[index]
    return [R.RankedScore(s[index], data.y[index], data.codes[index], data.key_rank[index], amounts, share, rounding)
            for s in scores]


def slice_labels(data, name, c=COLUMNS):
    """A label per read row for one slice of the slice table, or None when the needed column is absent."""
    f = data.frame
    if name == "card_present":
        return None if c.card_present not in f else as_text(f[c.card_present]).str.strip().replace("", "missing").to_numpy()
    if name == "same_second":
        return None if "_same_second" not in f else np.where(f["_same_second"].to_numpy(), "shares a second",
                                                             "alone in its second")
    if name == "history":
        if "_earlier" not in f:
            return None
        e = f["_earlier"].to_numpy()
        return np.select([e == 0, e < 5, e < 20], ["0 earlier rows", "1-4", "5-19"], "20 or more")
    if name == "window":
        if data.windows is None:
            return None
        w = data.windows
        return np.select([w <= 1, w <= 5, w <= 20], ["1 row", "2-5 rows", "6-20 rows"], "21-32 rows")
    if name == "amount":
        if data.amounts is None:
            return None
        a = data.amounts
        return np.select([a < 10, a < 100, a < 1000], ["under 10", "10-100", "100-1000"], "1000 or more")
    raise ValueError(f"unknown slice {name}")
