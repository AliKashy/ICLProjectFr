"""One screen that says what a trained run is: how long it ran, the learning rate it ended on, its model and its
size, its inputs, its validation figures, its files and its options.

Where it runs: anywhere with Python and torch (a CPU is enough), from the project root.

Usage:
    $PY program/pg_card.py <run folder> [--checkpoint last.ckpt] [--features]

It reads the checkpoint and the files the trainer left in the run folder (the resolved config, the manifest, the
metrics, the program settings). It loads no model code, so it works for any model the trainer saved. Nothing is
written. --features also lists the names of the input fields, read from the predictor list the config names.
"""
import argparse
import csv
import glob
import json
import math
import os
import re
import sys
from collections import Counter

WIDTH = 118  # printed lines are wrapped at this many characters


def say(label, text):
    """Print one labelled entry, wrapped so that no line is wider than WIDTH; continuation lines are indented."""
    words, line, first = str(text).split(" "), "", True
    for word in words:
        if line and len(line) + 1 + len(word) > WIDTH - 10:
            print(f"{label if first else '':<9} {line}", flush=True)
            first, line = False, word
        else:
            line = word if not line else line + " " + word
    print(f"{label if first else '':<9} {line}", flush=True)


def short(value, limit=60):
    """A value as short text: a long path keeps its end, a float keeps 6 significant digits."""
    if isinstance(value, float):
        return f"{value:.6g}"
    text = str(value)
    return text if len(text) <= limit else "..." + text[-(limit - 3):]


def pairs(mapping, skip=()):
    """'key value' entries of a flat mapping, separated by ' | '; nested values are left out."""
    out = []
    for key, value in mapping.items():
        if key in skip or isinstance(value, (dict, list, tuple)) or value is None:
            continue
        out.append(f"{key} {short(value)}")
    return " | ".join(out)


def first_file(run, patterns):
    for pattern in patterns:
        found = sorted(glob.glob(os.path.join(run, pattern)))
        if found:
            return found[0]
    return None


def numbers_range(values):
    """A list of file numbers as text: how many, and from where to where."""
    values = sorted(int(v) for v in values)
    if not values:
        return "none"
    whole = values == list(range(values[0], values[-1] + 1))
    return f"{len(values)} files, {values[0]} to {values[-1]}" + ("" if whole else " (a list, not every number)")


def card(run, checkpoint="last.ckpt", features=False):
    import torch
    path = os.path.join(run, checkpoint)
    ck = torch.load(path, map_location="cpu", weights_only=False)
    say("run", f"{os.path.basename(os.path.normpath(run))} | checkpoint {checkpoint} | "
               f"{os.path.getsize(path) / 1e6:.1f} MB")

    # ---- how long it ran
    manifest_path = first_file(run, ("run_manifest*.json",))
    manifest = json.load(open(manifest_path)) if manifest_path else {}
    length = [f"updates {int(ck.get('global_step', 0)):,}", f"epochs finished {ck.get('epoch')}"]
    if manifest:
        length.append(f"status {manifest.get('status')}")
        created, ended = manifest.get("created_utc"), manifest.get("ended_utc")
        if created and ended:
            import datetime as dt
            parse = lambda t: dt.datetime.strptime(t.replace("Z", ""), "%Y-%m-%dT%H:%M:%S")
            length.append(f"{(parse(ended) - parse(created)).total_seconds() / 3600:.1f} hours from start to end")
        if manifest.get("resume_events"):
            length.append(f"resumed {len(manifest['resume_events'])} time(s)")
    say("length", " | ".join(length))

    # ---- the learning rate
    hp = dict(ck.get("hyper_parameters") or {})
    rates = [g["lr"] for state in ck.get("optimizer_states", []) for g in state.get("param_groups", [])]
    rate = [f"at the end {rates[0]:.3e}" if rates else "no optimizer state"]
    start = hp.get("learning_rate")
    if rates and start:
        rate.append(f"config {float(start):.3e}")
        if rates[0] > 0 and abs(float(start) / rates[0] - 1) > 1e-6:
            rate.append(f"so it fell by a factor of {float(start) / rates[0]:.3g} "
                        f"({math.log2(float(start) / rates[0]):.2f} halvings)")
        else:
            rate.append("so it never fell" if rates[0] > 0 else "so it reached 0")
    for state in ck.get("lr_schedulers", []):
        kind = "plateau rule" if "num_bad_epochs" in state else "fixed plan"
        rate.append(f"{kind}, stepped {state.get('last_epoch')} times")
    for key, saved_state in (ck.get("callbacks") or {}).items():
        if "ClockPlan" in str(key) and isinstance(saved_state, dict):  # a run planned by the clock (--train-hours)
            rate.append(f"planned by the clock: {float(saved_state.get('elapsed') or 0) / 3600:.2f} of "
                        f"{float(saved_state.get('hours') or 0):g} hours trained, "
                        + ("the plan ran to its end" if saved_state.get("ended") else "the plan had not ended"))
    say("rate", " | ".join(rate))

    # ---- the program's options and the model's own settings
    settings = dict(ck.get("program_settings") or {})
    on = {k: v for k, v in settings.items() if v not in (None, [], False, 0)
          and k not in ("decline_col", "decline_values", "advice_col", "focal_gamma", "sample_seed", "band_seconds",
                        "band_rows", "prefix_max_rows", "mask_fraud_account_negatives", "negative_weight", "loss",
                        "plateau_monitor")}
    for key in ("loss", "plateau_monitor", "negative_weight"):
        if settings.get(key) not in (None, "ce", "valid_loss", "none"):
            on[key] = settings[key]
    months = on.pop("month_map", None)
    if months:  # a full map to one value means the month was switched off (pg_train.py --no-month)
        values = {int(v) for v in months.values()}
        on["month"] = ("switched off" if len(months) == 12 and len(values) == 1 else
                       ", ".join(f"{a} read as {b}" for a, b in sorted((int(k), int(v)) for k, v in months.items())))
    say("options", "; ".join(f"{k} = {short(v)}" for k, v in on.items()) or "none (the trainer's own run)")

    # ---- inputs and size, from the weights themselves
    state = ck["state_dict"]
    sizes, blocks, tables, others = Counter(), {}, [], []
    for name, tensor in state.items():
        if not hasattr(tensor, "numel"):
            continue
        top = name.split(".")[0]
        sizes[top] += int(tensor.numel())
        found = re.search(r"^(.*?)\.layers\.(\d+)\.", name)
        if found:
            blocks[found.group(1)] = max(blocks.get(found.group(1), 0), int(found.group(2)) + 1)
        elif re.search(r"cat_embeddings\.\d+\.weight$|tables\.\d+\.weight$", name):
            tables.append(tuple(tensor.shape))
        else:
            others.append(f"{name} {tuple(tensor.shape)}")
    total = sum(sizes.values())
    numbers = hp.get("continuous_dim")
    fields = [f"numbers {numbers}" if numbers is not None else "numbers: see the shapes below",
              f"codes {len(tables)}", f"code values in all {sum(t[0] for t in tables):,}",
              f"width of a field {sorted({t[1] for t in tables}) or '?'}"]
    say("fields", " | ".join(fields))
    say("weights", f"total {total:,} | without the code tables {total - sum(t[0] * t[1] for t in tables):,} | "
                   + " | ".join(f"{name} {count:,}" for name, count in sizes.most_common()))
    say("blocks", " | ".join(f"{name} {count}" for name, count in blocks.items()) or "none found")
    say("shapes", "; ".join(others) or "none")

    # ---- validation
    metrics_path = first_file(run, ("training_metrics.csv", "*metrics*.csv"))
    if metrics_path and "ema" not in os.path.basename(metrics_path):
        rows = [r for r in csv.DictReader(open(metrics_path)) if r.get("valid_ap") not in (None, "")]
        if rows:
            best = max(rows, key=lambda r: float(r["valid_ap"]))
            last = rows[-1]
            show = lambda r: (f"valid_ap {float(r['valid_ap']):.4f} at update {int(float(r.get('step', 0))):,} "
                              f"(epoch {r.get('epoch')}, valid_loss {short(float(r['valid_loss'])) if r.get('valid_loss') else '?'}, "
                              f"train_loss {short(float(r['train_loss'])) if r.get('train_loss') else '?'})")
            say("valid", f"{len(rows)} validations | best: {show(best)} | last: {show(last)}")
    ema_path = first_file(run, ("ema_metrics.csv",))
    if ema_path:
        rows = list(csv.DictReader(open(ema_path)))
        if rows:
            best = max(rows, key=lambda r: float(r["valid_ap_ema"]))
            say("valid ema", f"best valid_ap_ema {float(best['valid_ap_ema']):.4f} at update {int(float(best['step'])):,} | "
                             f"last {float(rows[-1]['valid_ap_ema']):.4f}")

    # ---- what was scored with this run's checkpoints
    scored = [e for e in (manifest.get("scored") or []) if isinstance(e, dict) and e.get("completed")]
    for entry in scored[-8:]:
        files = entry.get("files") or {}
        ap = entry.get("average_precision")
        say("scored", f"{os.path.basename(str(entry.get('checkpoint')))} on {entry.get('population')}, files "
                      f"{files.get('start')} to {files.get('end')}: {int(entry.get('n_predictions') or 0):,} rows, "
                      f"{int(entry.get('n_positives') or 0):,} frauds"
                      + (f", average precision over all scored rows {float(ap):.4f}" if ap is not None else ""))

    # ---- files and config
    saved_path = os.path.join(run, "program_settings.json")
    saved = json.load(open(saved_path)) if os.path.isfile(saved_path) else {}
    files = (saved.get("settings") or {}).get("files")
    config_path = first_file(run, ("resolved*.yaml", "*.yaml"))
    config = {}
    if config_path:
        try:
            import yaml
            config = yaml.safe_load(open(config_path)) or {}
        except Exception as exc:  # the card is still useful without the config
            say("config", f"could not read {os.path.basename(config_path)}: {exc}")
    data = config.get("data") or {}
    training_files = (numbers_range(files) if files else
                      f"{data.get('train_start')} to {data.get('train_end')} (the config's range)")
    say("files", f"training: {training_files} | validation: {data.get('val_start')} to {data.get('val_end')} | "
                 f"evaluation in the config: {(config.get('eval') or {}).get('file_start')} to "
                 f"{(config.get('eval') or {}).get('file_end')}")
    in_config = set()
    for section in ("sequence", "model", "training", "datetime", "preprocess"):
        if isinstance(config.get(section), dict):
            in_config.update(config[section])
            body = pairs(config[section], skip=("accelerator", "log_every_n_steps", "num_workers", "deterministic"))
            lists = {k: v for k, v in config[section].items() if isinstance(v, list)}
            say(section, body + "".join(f" | {k} {v}" for k, v in lists.items()))
    # what the checkpoint saved about the model and the config sections above do not already say
    extra = {k: v for k, v in hp.items() if k not in in_config}
    if extra:
        say("saved", pairs(extra) or "nothing more")
    for section in ("predictors", "artifacts"):
        if isinstance(config.get(section), dict):
            say(section, pairs(config[section]))
    if saved.get("trainer_args"):
        say("overrides", " ".join(x for x in saved["trainer_args"] if "=" in x and not x.startswith("output.")))

    # ---- the names of the inputs
    if features:
        listed = (config.get("predictors") or {}).get("csv_path")
        if listed and os.path.isfile(listed):
            rows = list(csv.DictReader(open(listed)))
            for column in (rows[0].keys() if rows else ()):
                values = [r[column] for r in rows]
                if 1 < len(set(values)) <= 8 and len(set(values)) < len(values):  # kinds, not names
                    say("kinds", f"{column}: " + ", ".join(f"{k} {v}" for k, v in Counter(values).most_common()))
            name_column = next(iter(rows[0].keys())) if rows else None
            say("features", f"{len(rows)} listed: " + ", ".join(r[name_column] for r in rows))
        else:
            say("features", f"the predictor list {short(listed)} is not on this machine")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description="one screen that says what a trained run is")
    ap.add_argument("run", help="the run folder (the trainer's output.checkpoint_dir)")
    ap.add_argument("--checkpoint", default="last.ckpt", help="the checkpoint file inside the run folder")
    ap.add_argument("--features", action="store_true", help="also list the names of the input fields")
    a = ap.parse_args(argv)
    if not os.path.isfile(os.path.join(a.run, a.checkpoint)):
        present = sorted(os.path.basename(p) for p in glob.glob(os.path.join(a.run, "*.ckpt")))
        print(f"error: no {a.checkpoint} in {a.run}; checkpoints there: {present or 'none'}", file=sys.stderr)
        return 2
    return card(a.run, a.checkpoint, a.features)


if __name__ == "__main__":
    sys.exit(main())
