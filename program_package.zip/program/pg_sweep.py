"""The tuning search: 12 trials of the chosen recipe, one at a time, each a normal training run.

Where it runs: on the pod, from the project root, on the GPU workbench. It starts pg_train.py once per trial phase.

The plan:
- Space: learning rate 5e-5 to 1e-3 (log), weight decay 1e-6 to 0.5 (log), attention dropout 0 to 0.5, feed-forward
  dropout 0 to 0.5, gradient clipping off or 1.0. Trial 0 is the current settings; trials 1-5 are random; trials
  6-11 are guided (Optuna's TPE). Without Optuna installed, every trial after 0 is random (a note says so).
- Each trial trains 5 epochs first. Trials 0-3 then always go on to 10 epochs (the pilots). From trial 4 on, a trial
  stops at 5 epochs if its best valid_ap over epochs 0-4 is more than 0.03 below the median of the three best 5-epoch
  scores so far; it keeps that score, marked pruned. A kept trial resumes the same run to 10 epochs (patience 5).
- Pilot replay: after trial 3 the rule is replayed on trials 0-3. A pilot the rule would have cut that ends within
  0.01 AP of the pilots' best on epoch validation is a missed winner: one widens the margin to 0.05, two or more turn
  the drop rule off for trials 4-11.
- The search value is the best valid_ap over the epochs run; a pruned trial counts below every full trial.
- The study (study.db, trials.json) lives in --study-dir; run the same command again to continue after a stop.

Usage:
    $PY program/pg_sweep.py run --study-dir runs/program/sweep [--current-lr 3e-4] \
        [--train-options "--files-list runs/program/files/files_10.txt"] -- <the recipe's trainer args, without
        output.checkpoint_dir>
    $PY program/pg_sweep.py status --study-dir runs/program/sweep
    $PY program/pg_sweep.py choose --study-dir runs/program/sweep --raw-base <eval raw base> \
        --cred <S3 credentials yaml> --files 8228 8243   (after scoring every full trial on RANK-A as
        trial_<k>/rank_a.parquet; picks the top 2 settings other than trial 0 by UDR at 0.6%)
"""
import argparse
import csv
import json
import math
import os
import shlex
import subprocess
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
TRAIN = HERE / "pg_train.py"
SPACE = {"learning_rate": (5e-5, 1e-3), "weight_decay": (1e-6, 0.5), "attn_dropout": (0.0, 0.5),
         "ff_dropout": (0.0, 0.5), "grad_clip": (0.0, 1.0)}
CURRENT = {"learning_rate": 3e-4, "weight_decay": 1e-5, "attn_dropout": 0.1, "ff_dropout": 0.1, "grad_clip": 0.0}
RULES = {"trials": 12, "pilots": 4, "first_epochs": 5, "full_epochs": 10, "margin": 0.03, "wide_margin": 0.05,
         "missed_within": 0.01}


def overrides(p):
    return [f"training.learning_rate={p['learning_rate']:.6g}", f"training.weight_decay={p['weight_decay']:.6g}",
            f"model.attn_dropout={p['attn_dropout']:.4f}", f"model.ff_dropout={p['ff_dropout']:.4f}"]


def best_ap(run_dir, max_epoch=None):
    path = Path(run_dir) / "training_metrics.csv"
    if not path.is_file():
        return None
    best = None
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            try:
                e, ap = int(float(row["epoch"])), float(row["valid_ap"])
            except (KeyError, TypeError, ValueError):
                continue
            if max_epoch is not None and e > max_epoch:
                continue
            if math.isfinite(ap) and (best is None or ap > best):
                best = ap
    return best


def drop_threshold(earlier_best5, margin):
    """The median of the three best earlier 5-epoch scores (all of them if fewer than three) minus the margin."""
    vals = sorted([v for v in earlier_best5 if v is not None], reverse=True)[:3]
    if not vals:
        return None
    return float(np.median(vals)) - margin


class Study:
    """The search state in study_dir: trials.json (always) and Optuna's study.db (when Optuna is installed)."""

    def __init__(self, study_dir, seed=42):
        self.dir = Path(study_dir)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.path = self.dir / "trials.json"
        self.state = json.loads(self.path.read_text()) if self.path.is_file() else \
            {"trials": [], "margin": RULES["margin"], "drop_rule": True, "pilot_replay": None}
        self.seed = seed
        self.rng = np.random.default_rng(seed + len(self.state["trials"]))
        try:
            import optuna
            optuna.logging.set_verbosity(optuna.logging.WARNING)
            sampler = optuna.samplers.TPESampler(seed=seed, n_startup_trials=6)
            self.study = optuna.create_study(direction="maximize", sampler=sampler, study_name="program_sweep",
                                             storage=f"sqlite:///{self.dir / 'study.db'}", load_if_exists=True)
            self.optuna = optuna
        except ImportError:
            self.study = self.optuna = None
            print("note: Optuna is not installed; trials after trial 0 are drawn at random", flush=True)

    def save(self):
        self.path.write_text(json.dumps(self.state, indent=1))

    def distributions(self):
        o = self.optuna
        return {"learning_rate": o.distributions.FloatDistribution(*SPACE["learning_rate"], log=True),
                "weight_decay": o.distributions.FloatDistribution(*SPACE["weight_decay"], log=True),
                "attn_dropout": o.distributions.FloatDistribution(*SPACE["attn_dropout"]),
                "ff_dropout": o.distributions.FloatDistribution(*SPACE["ff_dropout"]),
                "grad_clip": o.distributions.CategoricalDistribution([0.0, 1.0])}

    def propose(self, k, current):
        if self.study is not None:
            # the sampler's seed follows the trial number: a stopped and restarted search proposes exactly what an
            # uninterrupted one would
            self.study.sampler = self.optuna.samplers.TPESampler(seed=self.seed + k, n_startup_trials=6)
            if k == 0:
                self.study.enqueue_trial(current)
            t = self.study.ask(self.distributions())
            return dict(t.params), t.number
        if k == 0:
            return dict(current), None
        lo, hi = SPACE["learning_rate"]
        wlo, whi = SPACE["weight_decay"]
        return {"learning_rate": float(math.exp(self.rng.uniform(math.log(lo), math.log(hi)))),
                "weight_decay": float(math.exp(self.rng.uniform(math.log(wlo), math.log(whi)))),
                "attn_dropout": float(self.rng.uniform(0, 0.5)), "ff_dropout": float(self.rng.uniform(0, 0.5)),
                "grad_clip": float(self.rng.choice([0.0, 1.0]))}, None

    def tell(self, trial, value=None, failed=False):
        self.save()
        if self.study is None or trial.get("optuna_number") is None:
            return
        state = self.optuna.trial.TrialState.FAIL if failed else None
        try:
            self.study.tell(trial["optuna_number"], None if failed else value, state=state, skip_if_finished=True)
        except TypeError:  # an Optuna without skip_if_finished
            if self.study.trials[trial["optuna_number"]].state.is_finished():
                return
            self.study.tell(trial["optuna_number"], None if failed else value, state=state)


def train(trial, study_dir, train_options, trainer_args, epochs, resume, runner=None):
    run_dir = Path(study_dir) / f"trial_{trial['number']}"
    p = trial["params"]
    opts = list(train_options) + (["--grad-clip", "1.0"] if p["grad_clip"] else [])
    cmd = [sys.executable, str(TRAIN), *opts, "--", *trainer_args, *overrides(p), f"training.max_epochs={epochs}",
           f"output.checkpoint_dir={run_dir}"] + (["--resume"] if resume else [])
    print(f"trial {trial['number']}: {' '.join(shlex.quote(c) for c in cmd)}", flush=True)
    rc = (runner or subprocess.call)(cmd)
    return rc, run_dir


def pilot_replay(trials, margin, within):
    """Would the drop rule have cut each pilot, and was a cut pilot a missed winner on epoch validation?"""
    best_full = max((t["best"] for t in trials if t.get("best") is not None), default=None)
    rows, missed = [], 0
    for i, t in enumerate(trials):
        thr = drop_threshold([x["best5"] for x in trials[:i]], margin)
        cut = thr is not None and t["best5"] is not None and t["best5"] < thr
        miss = bool(cut and best_full is not None and t.get("best") is not None and t["best"] >= best_full - within)
        missed += miss
        rows.append({"trial": t["number"], "best5": t["best5"], "best": t.get("best"), "threshold": thr,
                     "would_cut": bool(cut), "missed_winner": miss})
    return rows, missed


def phase_done(run_dir, epochs):
    """True when the run folder already finished this phase (a stop can fall between the end of training and the
    search's own record)."""
    for path in sorted(Path(run_dir).glob("run_manifest*.json")):
        try:
            m = json.loads(path.read_text())
        except (OSError, ValueError):
            continue
        if m.get("status") == "finished" or (m.get("status") == "budget_reached" and
                                              int(m.get("epochs_run") or 0) >= epochs):
            return True
    return False


def maybe_pilot_replay(st):
    """Once trials 0-3 have all ended (done, pruned or failed), replay the drop rule on the finished ones."""
    if st["pilot_replay"] is not None:
        return
    pilots = [t for t in st["trials"] if t["number"] < RULES["pilots"]]
    if len(pilots) < RULES["pilots"] or any(t["status"] not in ("done", "pruned", "failed") for t in pilots):
        return
    rows, missed = pilot_replay([t for t in pilots if t["status"] == "done"], RULES["margin"], RULES["missed_within"])
    st["pilot_replay"] = {"rows": rows, "missed_winners": missed}
    if missed == 1:
        st["margin"] = RULES["wide_margin"]
    elif missed >= 2:
        st["drop_rule"] = False
    print(f"pilot replay: {missed} missed winner(s); margin {st['margin']}, drop rule "
          f"{'on' if st['drop_rule'] else 'off'}", flush=True)


def run(a, trainer_args, runner=None):
    study = Study(a.study_dir, a.seed)
    st = study.state
    current = dict(CURRENT, learning_rate=a.current_lr)
    train_options = shlex.split(a.train_options or "")
    while True:
        maybe_pilot_replay(st)
        study.save()
        if len([t for t in st["trials"] if t["status"] in ("done", "pruned", "failed")]) >= a.trials:
            break
        open_trials = [t for t in st["trials"] if t["status"] not in ("done", "pruned", "failed")]
        if open_trials:
            trial = open_trials[0]
        else:
            k = len(st["trials"])
            params, number = study.propose(k, current)
            trial = {"number": k, "params": params, "optuna_number": number, "status": "first", "best5": None,
                     "best": None}
            st["trials"].append(trial)
            study.save()
        run_dir = Path(a.study_dir) / f"trial_{trial['number']}"
        if trial["status"] == "first":
            if not phase_done(run_dir, RULES["first_epochs"]):
                resume = (run_dir / "last.ckpt").is_file()
                rc, _ = train(trial, a.study_dir, train_options, trainer_args, RULES["first_epochs"], resume, runner)
                if rc:
                    trial["status"] = "failed"
                    study.tell(trial, failed=True)
                    continue
            trial["best5"] = best_ap(run_dir, RULES["first_epochs"] - 1)
            k = trial["number"]
            if k >= RULES["pilots"] and st["drop_rule"]:
                earlier = [t["best5"] for t in st["trials"] if t["number"] < k and t["status"] != "failed"]
                thr = drop_threshold(earlier, st["margin"])
                if thr is not None and trial["best5"] is not None and trial["best5"] < thr:
                    trial.update(status="pruned", threshold=thr)
                    study.tell(trial, trial["best5"] - 1.0)
                    print(f"trial {k}: pruned at 5 epochs (best {trial['best5']:.5f} < {thr:.5f})", flush=True)
                    continue
            trial["status"] = "full"
            study.save()
        if trial["status"] == "full":
            if not phase_done(run_dir, RULES["full_epochs"]):
                rc, _ = train(trial, a.study_dir, train_options, trainer_args, RULES["full_epochs"], True, runner)
                if rc:
                    trial["status"] = "failed"
                    study.tell(trial, failed=True)
                    continue
            trial["best"] = best_ap(run_dir)
            trial["status"] = "done"
            study.tell(trial, trial["best"] if trial["best"] is not None else -1.0)
            print(f"trial {trial['number']}: done, best valid_ap {trial['best']}", flush=True)
    return status(a)


def status(a):
    st = json.loads((Path(a.study_dir) / "trials.json").read_text())
    print(f"{'trial':>5} {'status':>7} {'lr':>9} {'wd':>9} {'attn':>5} {'ff':>5} {'clip':>4} {'best5':>8} {'best':>8}")
    for t in st["trials"]:
        p = t["params"]
        b5 = f"{t['best5']:.5f}" if t.get("best5") is not None else "-"
        b = f"{t['best']:.5f}" if t.get("best") is not None else "-"
        print(f"{t['number']:>5} {t['status']:>7} {p['learning_rate']:>9.2e} {p['weight_decay']:>9.2e} "
              f"{p['attn_dropout']:>5.2f} {p['ff_dropout']:>5.2f} {p['grad_clip']:>4.1f} {b5:>8} {b:>8}")
    edge = [t["number"] for t in st["trials"] if t["status"] == "done" and
            (abs(math.log(t["params"]["learning_rate"] / SPACE["learning_rate"][0])) < 0.05 or
             abs(math.log(t["params"]["learning_rate"] / SPACE["learning_rate"][1])) < 0.05)]
    if edge:
        print(f"note: trials {edge} sit at an edge of the learning-rate range")
    return 0


def choose(a):
    sys.path.insert(0, str(HERE))
    import pg_rows
    st = json.loads((Path(a.study_dir) / "trials.json").read_text())
    full = [t for t in st["trials"] if t["status"] == "done"]
    paths, have = [], []
    for t in full:
        p = Path(a.study_dir) / f"trial_{t['number']}" / a.prediction_name
        if p.is_file():
            paths.append(str(p))
            have.append(t)
        else:
            print(f"note: trial {t['number']} has no {a.prediction_name}; score it on RANK-A first")
    if not paths:
        print("error: no trial predictions on RANK-A", file=sys.stderr)
        return 4
    numbers = list(range(a.files[0], a.files[1] + 1))
    raw = pg_rows.keep_targets(pg_rows.raw_rows(a.raw_base, numbers, cred=a.cred))
    data, scores = pg_rows.align(paths, raw)
    points = [f.evaluate(None) for f in pg_rows.ranked(data, scores)]
    table = sorted(zip(have, points), key=lambda x: (-x[1]["udr"], -x[1]["ap"], -(x[0]["best"] or 0)))
    for t, p in table:
        print(f"trial {t['number']:>2}: RANK-A UDR {p['udr']:.4f}  AP {p['ap']:.4f}  epoch-validation best "
              f"{t['best']:.5f}  {t['params']}")
    top = []
    for t, p in table:
        if t["number"] == 0 or any(t["params"] == x["params"] for x in top):
            continue
        top.append(t)
        if len(top) == 2:
            break
    replay = st.get("pilot_replay") or {}
    cut_in_top = [r["trial"] for r in replay.get("rows", []) if r["would_cut"] and
                  r["trial"] in [t["number"] for t, _ in table[:2]]]
    rec = {"top2": [t["number"] for t in top], "rank_a": [{"trial": t["number"], **p} for t, p in table],
           "pilot_cut_in_rank_a_top2": cut_in_top}
    (Path(a.study_dir) / "choice.json").write_text(json.dumps(rec, indent=1, default=float))
    print(f"top 2 settings for the confirmation (3 new seeds each, with the current settings): trials {rec['top2']}")
    if cut_in_top:
        print(f"note: the drop rule would have cut pilot(s) {cut_in_top}, which rank in RANK-A's top 2")
    return 0


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    trainer_args = []
    if "--" in argv:
        i = argv.index("--")
        argv, trainer_args = argv[:i], argv[i + 1:]
    ap = argparse.ArgumentParser(description="the tuning search")
    ap.add_argument("command", choices=("run", "status", "choose"))
    ap.add_argument("--study-dir", required=True)
    ap.add_argument("--trials", type=int, default=RULES["trials"])
    ap.add_argument("--current-lr", type=float, default=CURRENT["learning_rate"])
    ap.add_argument("--train-options", default="")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--raw-base", default=None)
    ap.add_argument("--cred", default=None)
    ap.add_argument("--files", type=int, nargs=2, default=[8228, 8243])
    ap.add_argument("--prediction-name", default="rank_a.parquet")
    a = ap.parse_args(argv)
    if a.command == "run":
        if not trainer_args or any(x.startswith("output.checkpoint_dir=") for x in trainer_args):
            print("error: give the recipe's trainer args after --, without output.checkpoint_dir", file=sys.stderr)
            return 2
        return run(a, trainer_args)
    if a.command == "status":
        return status(a)
    return choose(a)


if __name__ == "__main__":
    sys.exit(main())
