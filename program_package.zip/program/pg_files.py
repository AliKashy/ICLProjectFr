"""Which training files to use: nested lists of 10, 35, 100, 250 and 500 files from the 5,000 training files.

Where it runs: anywhere with Python (no data is read unless --stats is given).

Each training file is a bucket of whole accounts covering the same eight months (October 2024 to May 2025), so
choosing files chooses accounts, not months. The lists are nested: the 10-file list is files 1-10 (today's control)
and each larger list adds files drawn at random (fixed seed) from the rest of the pool, so a larger run always
contains the smaller one. Picking files by fraud count would change the fraud rate the model learns from; a random
draw keeps it. Reserved files never enter: 4001-4010 (downstream training) and 4950-4954 (epoch validation).

Usage:
    $PY program/pg_files.py --out runs/program/files [--sizes 10 35 100 250 500] [--seed 20261106]
        [--stats per_file_counts.csv]

--stats is optional: a CSV with one row per file (columns file, rows, frauds; accounts optional), for example from
the owner's own file analysis. With it, each list's rows, frauds and fraud rate are printed beside the pool's.
Writes files_<n>.txt (one file number per line) for pg_train.py --files-list, and lists.json.
"""
import argparse
import json
import sys
from pathlib import Path

import numpy as np

RESERVED = set(range(4001, 4011)) | set(range(4950, 4955))
FIRST = list(range(1, 11))


def nested_lists(sizes, seed=20261106, pool_max=5000, reserved=RESERVED, first=FIRST):
    pool = [n for n in range(1, pool_max + 1) if n not in reserved and n not in first]
    order = list(np.random.default_rng(seed).permutation(pool))
    sizes = sorted(set(int(s) for s in sizes))
    out = {}
    for s in sizes:
        if s <= len(first):
            out[s] = first[:s]
        else:
            out[s] = first + [int(x) for x in order[:s - len(first)]]
    return out


def summarize(lists, stats_path):
    import pandas as pd
    st = pd.read_csv(stats_path)
    st = st.set_index(st["file"].astype(int))
    pool = st.drop(index=[n for n in RESERVED if n in st.index])
    lines = [f"pool: {len(pool)} files, {int(pool['rows'].sum()):,} rows, {int(pool['frauds'].sum()):,} frauds, "
             f"{1e4 * pool['frauds'].sum() / pool['rows'].sum():.2f} per 10,000"]
    for size, files in lists.items():
        sub = st.loc[[f for f in files if f in st.index]]
        lines.append(f"{size:>4} files: {int(sub['rows'].sum()):>12,} rows {int(sub['frauds'].sum()):>9,} frauds "
                     f"{1e4 * sub['frauds'].sum() / max(sub['rows'].sum(), 1):6.2f} per 10,000")
    return lines


def main(argv=None):
    ap = argparse.ArgumentParser(description="nested training-file lists")
    ap.add_argument("--out", required=True)
    ap.add_argument("--sizes", type=int, nargs="+", default=[10, 35, 100, 250, 500])
    ap.add_argument("--seed", type=int, default=20261106)
    ap.add_argument("--stats", default=None)
    a = ap.parse_args(argv)
    lists = nested_lists(a.sizes, a.seed)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    for size, files in lists.items():
        (out / f"files_{size}.txt").write_text("\n".join(str(f) for f in files) + "\n")
    (out / "lists.json").write_text(json.dumps({"seed": a.seed, "reserved": sorted(RESERVED),
                                                "lists": {str(k): v for k, v in lists.items()}}, indent=1))
    for size, files in lists.items():
        print(f"files_{size}.txt: {len(files)} files")
    if a.stats:
        print("\n".join(summarize(lists, a.stats)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
