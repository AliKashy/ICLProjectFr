"""Score with the project's scorer, with no row limits. The scores are the scorer's own: only how a batch reaches the
GPU changes (a batch too wide for one call runs through the model in parts), never what a row sees.

Where it runs: on the pod (the GPU), from the project root.

Usage, the scorer's own arguments unchanged:

    $PY program/pg_score.py --config $CFG --checkpoint <run>/best.ckpt --out <run>/<population>.parquet \
        --population OTHER --purpose program eval.base=$EVAL_RAW eval.file_start=<first> eval.file_end=<last>

A checkpoint trained with no window cap (sequence.max_window_rows=null) is scored with no cap: every window holds
all the rows of its history. A checkpoint trained with a cap is scored with that cap, as the scorer always does.
"""
import contextlib
import inspect
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pg_layout  # noqa: E402
import pg_patch  # noqa: E402
from pg_train import NO_CHUNK_LIMIT, with_override  # noqa: E402

NO_LIMIT = 10 ** 12


@contextlib.contextmanager
def no_row_limits(mods):
    """While open, the model takes batches of any width (in parts when needed), so the scorer's check of eval batch x
    window width against the 65,535-row limit no longer applies. Everything is put back on exit."""
    model_cls = mods["base_model"].FTTransformerHierModel
    scorer = mods["scorer"]
    had = hasattr(scorer, "MAX_STAGE1_ROWS")
    before = getattr(scorer, "MAX_STAGE1_ROWS", None)
    ours = model_cls not in pg_patch._WIDE
    pg_patch.install_wide_batches(model_cls)
    if had:
        scorer.MAX_STAGE1_ROWS = NO_LIMIT
    try:
        yield
    finally:
        if had:
            scorer.MAX_STAGE1_ROWS = before
        if ours:
            pg_patch.remove_wide_batches(model_cls)


def main(argv=None):
    argv = with_override(list(sys.argv[1:] if argv is None else argv), NO_CHUNK_LIMIT)
    layout, mods = pg_layout.resolve(roles=("base_model", "scorer"))
    scorer = mods["scorer"]
    with no_row_limits(mods):
        if inspect.signature(scorer.main).parameters:
            return int(scorer.main(argv) or 0)
        sys.argv = [scorer.__file__] + argv
        return int(scorer.main() or 0)


if __name__ == "__main__":
    sys.exit(main())
