"""Score with the project's scorer, with no row limits. The scores are the scorer's own: only how a batch reaches the
GPU changes (a batch too wide for one call runs through the model in parts), never what a row sees.

Where it runs: on the pod (the GPU), from the project root.

Usage, the scorer's own arguments unchanged:

    $PY program/pg_score.py --config $CFG --checkpoint <run>/best.ckpt --out <run>/<population>.parquet \
        --population OTHER --purpose program eval.base=$EVAL_RAW eval.file_start=<first> eval.file_end=<last>

The window cap is the config's: with sequence.max_window_rows=null every window holds all the rows of its history,
whatever cap the checkpoint was validated with (a note is printed when the two differ).

The month. A checkpoint trained with `pg_train.py --no-month` (the month switched off) is scored the same way
with no option: this tool reads the setting from the checkpoint and gives every row the same month, as in
training. If the setting reaches no row (loader workers that were not started by fork), the output is renamed to
<out>.real_months and the exit code is 3. For a model trained with the month, one option of this tool, given
anywhere among the arguments:

    --month-map 6=5     rows of month 6 are read with month 5 as their month input (day, hour and day of week stay
                        the rows' own). For a model trained on October to May and scored on June: without it, a
                        June row's month is a value no training row had. Several entries may follow (6=5 7=5).
"""
import contextlib
import inspect
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pg_layout  # noqa: E402
import pg_patch  # noqa: E402
from pg_train import NO_CHUNK_LIMIT, with_override  # noqa: E402

NO_LIMIT = 10 ** 12


@contextlib.contextmanager
def no_row_limits(mods):
    """While open, the model takes batches of any width (in parts when needed), so the scorer's check of eval batch x
    window width against the 65,535-row limit no longer applies, and the window cap is the config's (the scorer
    otherwise keeps the cap the checkpoint was validated with). Everything is put back on exit."""
    model_cls = mods["base_model"].FTTransformerHierModel
    scorer = mods["scorer"]
    had = hasattr(scorer, "MAX_STAGE1_ROWS")
    before = getattr(scorer, "MAX_STAGE1_ROWS", None)
    original_policy = getattr(scorer, "checkpoint_policy", None)
    ours = model_cls not in pg_patch._WIDE
    pg_patch.install_wide_batches(model_cls)
    if had:
        scorer.MAX_STAGE1_ROWS = NO_LIMIT
    if original_policy is not None:
        def checkpoint_policy(ckpt, cfg):
            if not bool(cfg.sequence.get("predict_every_transaction", False)):
                return original_policy(ckpt, cfg)
            asked = cfg.sequence.get("max_window_rows", None)
            cap = None if asked is None else int(asked)
            validated = (ckpt.get("validation_policy") or {}).get("max_window_rows")
            if validated != cap:
                print(f"note: scoring with window cap {cap} (None: no cap); the checkpoint was validated with "
                      f"{validated}", flush=True)
            return cap

        scorer.checkpoint_policy = checkpoint_policy
    try:
        yield
    finally:
        if had:
            scorer.MAX_STAGE1_ROWS = before
        if original_policy is not None:
            scorer.checkpoint_policy = original_policy
        if ours:
            pg_patch.remove_wide_batches(model_cls)


def take_month_map(argv):
    """(argv without --month-map and its entries, the map). The entries are the tokens of the form 6=5 that follow
    the option; everything else is the scorer's own."""
    if "--month-map" not in argv:
        return list(argv), {}
    i = argv.index("--month-map")
    j = i + 1
    while j < len(argv) and argv[j].replace("=", "").isdigit() and argv[j].count("=") == 1:
        j += 1
    if j == i + 1:
        raise SystemExit("--month-map needs at least one entry such as 6=5")
    return list(argv[:i]) + list(argv[j:]), pg_patch.parse_month_map(argv[i + 1:j])


checkpoint_month_map = pg_patch.checkpoint_month_map  # the month setting a checkpoint was trained with


def scorer_argument(argv, name):
    """The value the scorer will read for one of its options (--checkpoint, --out), found the way its own parser
    finds it: as two arguments, as --name=VALUE, or under a shortened name. None when it is not given."""
    import argparse
    finder = argparse.ArgumentParser(add_help=False)
    finder.add_argument(name, default=None)
    try:
        known, _ = finder.parse_known_args(list(argv))
    except SystemExit:  # the option without its value: the scorer reports that itself
        return None
    return getattr(known, name.lstrip("-").replace("-", "_"))


def checkpoint_argument(argv):
    """The checkpoint the scorer will load, or None."""
    return scorer_argument(argv, "--checkpoint")


def months_for(checkpoint, asked):
    """The month map to score with: the one the checkpoint was trained with when it has one (an asked map is then
    left out, with a note), else the asked one."""
    trained = checkpoint_month_map(checkpoint) if checkpoint else {}
    if not trained:
        return dict(asked or {})
    if asked and dict(asked) != trained:
        print("note: this checkpoint was trained with its own month setting; --month-map is left out", flush=True)
    return trained


@contextlib.contextmanager
def month_read_as(mapping):
    """While open, rows of the given months are read with another month (pg_patch.install_month_map)."""
    on = pg_patch.install_month_map(mapping) if mapping else False
    if mapping and not on:
        raise SystemExit("the month setting: the project's date step (fraud.data.datetime_features) has no "
                         "_extract_field, so the month cannot be changed here; nothing was scored")
    if on and pg_patch.month_is_off(mapping):
        print("month option: the checkpoint was trained with the month switched off; every row is read with the "
              "same month here too", flush=True)
    elif on:
        print("month option: " + ", ".join(f"rows of month {a} are read as month {b}"
                                           for a, b in sorted(mapping.items()))
              + " (the month input only; day, hour and day of week are the rows' own)", flush=True)
    try:
        yield
    finally:
        if on:
            pg_patch.remove_month_map()


def month_reached_the_rows(mapping, out_path):
    """After a scoring or an export with a month map: True when rows had their month replaced. When none had (the
    rows never passed through the project's date step in a process that carries the map, for example loader workers
    that were not started by fork), the output holds scores made with real months: it is renamed so that it is not
    used, and False is returned. Call it before the map is removed."""
    if not mapping or pg_patch.month_rows_seen() > 0:
        return True
    moved = None
    if out_path and os.path.isfile(out_path):
        moved = str(out_path) + ".real_months"
        os.replace(out_path, moved)
    print("error: the month setting reached no row of this scoring, so the scores were made with the rows' real "
          "months" + (f"; the output was renamed to {moved} so that it is not used" if moved else "")
          + ". The loader workers must be started by fork (the default on Linux up to Python 3.13), or the scoring "
          "run without loader workers (training.num_workers=0)", file=sys.stderr, flush=True)
    return False


def main(argv=None):
    argv, months = take_month_map(list(sys.argv[1:] if argv is None else argv))
    months = months_for(checkpoint_argument(argv), months)
    argv = with_override(argv, NO_CHUNK_LIMIT)
    layout, mods = pg_layout.resolve(roles=("base_model", "scorer"))
    scorer = mods["scorer"]
    with no_row_limits(mods), month_read_as(months):
        if inspect.signature(scorer.main).parameters:
            rc = int(scorer.main(argv) or 0)
        else:
            sys.argv = [scorer.__file__] + argv
            rc = int(scorer.main() or 0)
        if rc == 0 and not month_reached_the_rows(months, scorer_argument(argv, "--out")):
            return 3
        return rc


if __name__ == "__main__":
    sys.exit(main())
