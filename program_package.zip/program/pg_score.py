"""Score with the project's scorer, with no row limits. The scores are the scorer's own: only how a batch reaches the
GPU changes (a batch too wide for one call runs through the model in parts), never what a row sees.

Where it runs: on the pod (the GPU), from the project root.

Usage, the scorer's own arguments unchanged:

    $PY program/pg_score.py --config $CFG --checkpoint <run>/best.ckpt --out <run>/<population>.parquet \
        --population OTHER --purpose program eval.base=$EVAL_RAW eval.file_start=<first> eval.file_end=<last>

The window cap is the config's: with sequence.max_window_rows=null every window holds all the rows of its history,
whatever cap the checkpoint was validated with (a note is printed when the two differ).

One option of this tool, given anywhere among the arguments:

    --month-map 6=5     rows of month 6 are read with month 5 as their month input (day, hour and day of week stay
                        the rows' own). For a model trained on October to May and scored on June: without it, a
                        June row's month is a value no training row had. Several entries may follow (6=5 7=5).
"""
import contextlib
import inspect
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pg_layout  # noqa: E402
import pg_patch  # noqa: E402
from pg_train import NO_CHUNK_LIMIT, with_override  # noqa: E402

NO_LIMIT = 10 ** 12


@contextlib.contextmanager
def no_row_limits(mods):
    """While open, the model takes batches of any width (in parts when needed), so the scorer's check of eval batch x
    window width against the 65,535-row limit no longer applies, and the window cap is the config's (the scorer
    otherwise keeps the cap the checkpoint was validated with). Everything is put back on exit."""
    model_cls = mods["base_model"].FTTransformerHierModel
    scorer = mods["scorer"]
    had = hasattr(scorer, "MAX_STAGE1_ROWS")
    before = getattr(scorer, "MAX_STAGE1_ROWS", None)
    original_policy = getattr(scorer, "checkpoint_policy", None)
    ours = model_cls not in pg_patch._WIDE
    pg_patch.install_wide_batches(model_cls)
    if had:
        scorer.MAX_STAGE1_ROWS = NO_LIMIT
    if original_policy is not None:
        def checkpoint_policy(ckpt, cfg):
            if not bool(cfg.sequence.get("predict_every_transaction", False)):
                return original_policy(ckpt, cfg)
            asked = cfg.sequence.get("max_window_rows", None)
            cap = None if asked is None else int(asked)
            validated = (ckpt.get("validation_policy") or {}).get("max_window_rows")
            if validated != cap:
                print(f"note: scoring with window cap {cap} (None: no cap); the checkpoint was validated with "
                      f"{validated}", flush=True)
            return cap

        scorer.checkpoint_policy = checkpoint_policy
    try:
        yield
    finally:
        if had:
            scorer.MAX_STAGE1_ROWS = before
        if original_policy is not None:
            scorer.checkpoint_policy = original_policy
        if ours:
            pg_patch.remove_wide_batches(model_cls)


def take_month_map(argv):
    """(argv without --month-map and its entries, the map). The entries are the tokens of the form 6=5 that follow
    the option; everything else is the scorer's own."""
    if "--month-map" not in argv:
        return list(argv), {}
    i = argv.index("--month-map")
    j = i + 1
    while j < len(argv) and argv[j].replace("=", "").isdigit() and argv[j].count("=") == 1:
        j += 1
    if j == i + 1:
        raise SystemExit("--month-map needs at least one entry such as 6=5")
    return list(argv[:i]) + list(argv[j:]), pg_patch.parse_month_map(argv[i + 1:j])


@contextlib.contextmanager
def month_read_as(mapping):
    """While open, rows of the given months are read with another month (pg_patch.install_month_map)."""
    on = pg_patch.install_month_map(mapping) if mapping else False
    if mapping and not on:
        raise SystemExit("--month-map: the project's date step (fraud.data.datetime_features) has no _extract_field, "
                         "so the month cannot be changed here; nothing was scored")
    if on:
        print("month option: " + ", ".join(f"rows of month {a} are read as month {b}"
                                           for a, b in sorted(mapping.items()))
              + " (the month input only; day, hour and day of week are the rows' own)", flush=True)
    try:
        yield
    finally:
        if on:
            pg_patch.remove_month_map()


def main(argv=None):
    argv, months = take_month_map(list(sys.argv[1:] if argv is None else argv))
    argv = with_override(argv, NO_CHUNK_LIMIT)
    layout, mods = pg_layout.resolve(roles=("base_model", "scorer"))
    scorer = mods["scorer"]
    with no_row_limits(mods), month_read_as(months):
        if inspect.signature(scorer.main).parameters:
            return int(scorer.main(argv) or 0)
        sys.argv = [scorer.__file__] + argv
        return int(scorer.main() or 0)


if __name__ == "__main__":
    sys.exit(main())
