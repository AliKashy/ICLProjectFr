"""Score with the project's scorer, with no row limits. The scores are the scorer's own: only how a batch reaches the
GPU changes (a batch too wide for one call runs through the model in parts), never what a row sees.

Where it runs: on the pod (the GPU), from the project root.

Usage, the scorer's own arguments unchanged:

    $PY program/pg_score.py --config $CFG --checkpoint <run>/best.ckpt --out <run>/<population>.parquet \
        --population OTHER --purpose program eval.base=$EVAL_RAW eval.file_start=<first> eval.file_end=<last>

The window cap is the config's: with sequence.max_window_rows=null every window holds all the rows of its history,
whatever cap the checkpoint was validated with (a note is printed when the two differ).

The month. A checkpoint trained with `pg_train.py --no-month` (the month switched off) is scored the same way
with no option: this tool reads the setting from the checkpoint and gives every row the same month, as in
training. If the setting reaches no row (loader workers that were not started by fork), the output is renamed to
<out>.real_months and the exit code is 3. For a model trained with the month, one option of this tool, given
anywhere among the arguments:

    --month-map 6=5     rows of month 6 are read with month 5 as their month input (day, hour and day of week stay
                        the rows' own). For a model trained on October to May and scored on June: without it, a
                        June row's month is a value no training row had. Several entries may follow (6=5 7=5).

Grouped windows, two options, both off by default (with neither, nothing here changes the scorer):

    --group-windows     one window per (account, first row) instead of one window per row. The scorer builds a
                        target-ending window for every row: the rows of its history_len (sequence.history_len)
                        earlier distinct seconds, the strictly earlier rows of its own second, and the row itself.
                        All windows of one account that start at the same row are prefixes of the longest of them,
                        and under the strict time rule a row's output depends only on itself and on strictly earlier
                        rows of its window, so the longest window gives every such row exactly the score of its own
                        window. With this option the builder emits that one window, with every row from the first
                        row to the last row that has it as its first row; the rows that have it as their first row
                        are scored, the others are history.

                        What it replaces while it runs, all put back at the end: the scorer's TargetEndingBuilder (by
                        a subclass whose window step builds grouped windows with the project's window_bounds and gap
                        rule), its select and its natural_rows. Its _model_inputs is wrapped to hand on the mark, and
                        the model's forward is wrapped to count its calls. A local change in a replaced piece is not
                        used by the grouped run; the built-in comparison is what notices it.

                        The built-in comparison. Before the range is scored, a sample of accounts of the range's first
                        file (about SAMPLE_ROWS rows, placeholders below) is scored twice by the scorer's own main: the
                        scorer's own way, none of its pieces replaced, and the grouped way. The outputs are joined on
                        the id columns. If the ids differ, a score differs by more than COMPARE_LIMIT, or the grouped
                        run of the sample raises, one line says "group windows: the built-in comparison did not pass
                        (<reason>), so the whole range is scored the scorer's own way (one window per row)", the range
                        is scored that way and the receipt says why (grouped_windows.not_grouped_because).

                        The check of the output. After a grouped run, the output is checked against the id columns of
                        every row the builder read (before any selecting), as a set and as a count, each row's
                        window_rows against its own window worked out from the raw times, and the sample rows' scores
                        against the scorer's own scores of them, all joined on the ids. A failed check (a missing
                        column included) renames the output to <out>.not_checked and the exit code is 4; score again
                        without the option to a new --out (the scorer refuses an --out whose <out>.json or
                        <out>.exposure.json exists, and both stay after the rename).

                        First use: score one file with and without the option to two new --out paths, join on the id
                        columns, and require identical ids, identical window_rows and window_natural_rows, and scores
                        within 1e-6; then the same on a second file with the machine's own number of loader workers.

                        The output file is the ungrouped one: the same rows, the same columns (window_rows and
                        window_natural_rows are the sizes of each row's OWN window), the scores equal up to float32
                        rounding. The order of the rows is the same too, except with two or more loader workers and
                        two or more files, where files interleave in another order: join on the ids.

                        The receipt (<out>.json, or --metrics) gets grouped_windows: compare window_slots with
                        ungrouped_window_slots (each window at its own width), and windows_through_model with
                        ungrouped_windows. slots_through_model is padded to the batch and is not comparable.
                        built_in_comparison holds the sample's numbers. If a piece the option needs is missing by name
                        in this layout, one line says so and the rows are scored the ungrouped way.

                        The mark: the batch carries a bool entry "scored" [B, W], True on the scored rows, handed to
                        the model with the other inputs (a model that does not read it ignores it). One rule for a
                        model that reads it: it may use the mark only to choose which rows' outputs it works out,
                        never to decide what a row may read, because in a grouped window earlier scored rows are also
                        history for later ones.
    --mark-scored-rows  in ungrouped scoring, hand the model the same "scored" entry too: True on the last real
                        row of every window, the one row whose score is kept. Without this option an ungrouped
                        run hands the model exactly what it handed before.

With either option the model calls that got the mark are counted; when the mark was meant to reach the model and did
not reach every call, one line says so ("mark scored rows: the mark reached m of n model calls ...") and the receipt
gets both counts under scored_mark. With --group-windows the scores are still covered by the built-in comparison.
"""
import contextlib
import functools
import importlib
import inspect
import json
import os
import shutil
import sys
import tempfile
import time
import uuid
from pathlib import Path

import numpy as np
import pandas as pd
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pg_layout  # noqa: E402
import pg_patch  # noqa: E402
from pg_train import NO_CHUNK_LIMIT, with_override  # noqa: E402

NO_LIMIT = 10 ** 12


@contextlib.contextmanager
def no_row_limits(mods):
    """While open, the model takes batches of any width (in parts when needed), so the scorer's check of eval batch x
    window width against the 65,535-row limit no longer applies, and the window cap is the config's (the scorer
    otherwise keeps the cap the checkpoint was validated with). Everything is put back on exit."""
    model_cls = mods["base_model"].FTTransformerHierModel
    scorer = mods["scorer"]
    had = hasattr(scorer, "MAX_STAGE1_ROWS")
    before = getattr(scorer, "MAX_STAGE1_ROWS", None)
    original_policy = getattr(scorer, "checkpoint_policy", None)
    ours = model_cls not in pg_patch._WIDE
    pg_patch.install_wide_batches(model_cls)
    if had:
        scorer.MAX_STAGE1_ROWS = NO_LIMIT
    if original_policy is not None:
        def checkpoint_policy(ckpt, cfg):
            if not bool(cfg.sequence.get("predict_every_transaction", False)):
                return original_policy(ckpt, cfg)
            asked = cfg.sequence.get("max_window_rows", None)
            cap = None if asked is None else int(asked)
            validated = (ckpt.get("validation_policy") or {}).get("max_window_rows")
            if validated != cap:
                print(f"note: scoring with window cap {cap} (None: no cap); the checkpoint was validated with "
                      f"{validated}", flush=True)
            return cap

        scorer.checkpoint_policy = checkpoint_policy
    try:
        yield
    finally:
        if had:
            scorer.MAX_STAGE1_ROWS = before
        if original_policy is not None:
            scorer.checkpoint_policy = original_policy
        if ours:
            pg_patch.remove_wide_batches(model_cls)


def take_month_map(argv):
    """(argv without --month-map and its entries, the map). The entries are the tokens of the form 6=5 that follow
    the option; everything else is the scorer's own."""
    if "--month-map" not in argv:
        return list(argv), {}
    i = argv.index("--month-map")
    j = i + 1
    while j < len(argv) and argv[j].replace("=", "").isdigit() and argv[j].count("=") == 1:
        j += 1
    if j == i + 1:
        raise SystemExit("--month-map needs at least one entry such as 6=5")
    return list(argv[:i]) + list(argv[j:]), pg_patch.parse_month_map(argv[i + 1:j])


checkpoint_month_map = pg_patch.checkpoint_month_map  # the month setting a checkpoint was trained with


def scorer_argument(argv, name):
    """The value the scorer will read for one of its options (--checkpoint, --out), found the way its own parser
    finds it: as two arguments, as --name=VALUE, or under a shortened name. None when it is not given."""
    import argparse
    finder = argparse.ArgumentParser(add_help=False)
    finder.add_argument(name, default=None)
    try:
        known, _ = finder.parse_known_args(list(argv))
    except SystemExit:  # the option without its value: the scorer reports that itself
        return None
    return getattr(known, name.lstrip("-").replace("-", "_"))


def checkpoint_argument(argv):
    """The checkpoint the scorer will load, or None."""
    return scorer_argument(argv, "--checkpoint")


def months_for(checkpoint, asked):
    """The month map to score with: the one the checkpoint was trained with when it has one (an asked map is then
    left out, with a note), else the asked one."""
    trained = checkpoint_month_map(checkpoint) if checkpoint else {}
    if not trained:
        return dict(asked or {})
    if asked and dict(asked) != trained:
        print("note: this checkpoint was trained with its own month setting; --month-map is left out", flush=True)
    return trained


@contextlib.contextmanager
def month_read_as(mapping):
    """While open, rows of the given months are read with another month (pg_patch.install_month_map)."""
    on = pg_patch.install_month_map(mapping) if mapping else False
    if mapping and not on:
        raise SystemExit("the month setting: the project's date step (fraud.data.datetime_features) has no "
                         "_extract_field, so the month cannot be changed here; nothing was scored")
    if on and pg_patch.month_is_off(mapping):
        print("month option: the checkpoint was trained with the month switched off; every row is read with the "
              "same month here too", flush=True)
    elif on:
        print("month option: " + ", ".join(f"rows of month {a} are read as month {b}"
                                           for a, b in sorted(mapping.items()))
              + " (the month input only; day, hour and day of week are the rows' own)", flush=True)
    try:
        yield
    finally:
        if on:
            pg_patch.remove_month_map()


def month_reached_the_rows(mapping, out_path):
    """After a scoring or an export with a month map: True when rows had their month replaced. When none had (the
    rows never passed through the project's date step in a process that carries the map, for example loader workers
    that were not started by fork), the output holds scores made with real months: it is renamed so that it is not
    used, and False is returned. Call it before the map is removed."""
    if not mapping or pg_patch.month_rows_seen() > 0:
        return True
    moved = None
    if out_path and os.path.isfile(out_path):
        moved = str(out_path) + ".real_months"
        os.replace(out_path, moved)
    print("error: the month setting reached no row of this scoring, so the scores were made with the rows' real "
          "months" + (f"; the output was renamed to {moved} so that it is not used" if moved else "")
          + ". The loader workers must be started by fork (the default on Linux up to Python 3.13), or the scoring "
          "run without loader workers (training.num_workers=0)", file=sys.stderr, flush=True)
    return False


GROUP_OPTION = "--group-windows"
MARK_OPTION = "--mark-scored-rows"
SCORED = "scored"  # the batch entry [B, W], True on the rows whose score is kept, handed to the model
OWN_ROWS = "own_window_rows"  # grouped batches: [B, W], each scored row's own window size (0 elsewhere)
OWN_NATURAL = "own_natural_rows"  # grouped batches: [B, W], the same without the window cap
_SCORED_META = "_grouped_scored"  # meta keys that carry the three per-slot values from the builder to the batch
_OWN_META = "_grouped_own_rows"
_NATURAL_META = "_grouped_natural_rows"
_PICKED_NATURAL = "_grouped_picked_natural"  # set by the selection: natural sizes of the rows it just selected

# The built-in comparison. These four values are placeholders: the owner sets them once the option has been run on
# real files. They are kept here, at module level, so that a test or a run can change them in one place.
SAMPLE_ROWS = 5_000  # placeholder: the comparison scores accounts of the range's first file holding about this many rows
SAMPLE_BUSY_ACCOUNTS = 3  # placeholder: this many of the busiest accounts that fit are always in the sample
SAMPLE_BUSY_SHARE = 0.5  # placeholder: the busiest accounts take at most this share of the sample's rows
COMPARE_LIMIT = 1e-5  # placeholder: the largest score difference between the two ways that still passes

# The options of the scorer's own command line, used to tell a shortened option apart from another one.
SCORER_OPTIONS = ("--config", "--checkpoint", "--out", "--metrics", "--population", "--purpose")


def take_flag(argv, name):
    """(argv without the option, True when it was given). The option takes no value."""
    argv = list(argv)
    if name not in argv:
        return argv, False
    return [a for a in argv if a != name], True


def grouped_builder_class(base_cls, window_bounds):
    """A subclass of the project's target-ending builder that emits one window per (account, first row).

    window_bounds is the project's function that gives, per row of one account, the first row of its window (lo)
    and the start of its own timestamp group (group_start); the row's window is rows lo .. group_start - 1 plus
    the row itself. lo never decreases along an account (both of its terms only grow), so the rows that share one
    first row are consecutive: rows a .. b - 1. Their one window is rows lo .. b - 1. Every scored row keeps its
    own window's slot inputs there: the window opens at the same row (so the opening second's gaps are 0 as in its
    own window), the rows before it are the rows of its own window, and the rows between its group start and
    itself are same-time peers, which the strict rule hides from it and which do not count in its position.

    The builder also keeps, for the check of the finished output, the id columns and the times of every row it
    reads (keep_read_rows), before any window is made."""

    class GroupedTargetEndingBuilder(base_cls):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            # the scored mark and the own window sizes travel as per-slot metadata, so metadata is always emitted
            self._emit_meta = True
            # the receipt needs the narrowest window width; the builder object lives in the scoring process
            _GROUPED["T"] = int(self.T)
            # the check of the output works out each row's window from its times with the builder's own settings
            _GROUPED["history_len"] = int(self.history_len)
            _GROUPED["cap"] = self.max_window_rows
            _GROUPED["id_cols"] = list(self.id_cols)
            # the folder for the rows read; an attribute of the object, so loader workers carry it with them
            self._read_dir = _GROUPED.get("read_dir")

        def _encode_file(self, df):
            # the project's own reading of one file comes first, unchanged
            encoded = super()._encode_file(df)
            # the rows it read are kept before any window is made or any row is selected
            keep_read_rows(self, encoded[4])
            return encoded

        def _chunks_for_file(self, cont, cat, target, times, df, meta):
            n_cont, K = cont.shape[1], cat.shape[1]
            C = n_cont + int(self.time_delta)
            # the parsed timestamp at its stored precision decides "same time", as in the project's builder
            order_key = df[self.order_col].to_numpy(dtype="datetime64[ns]").astype("int64")
            for rows in self._account_groups(df).values():
                rows = np.asarray(rows)
                secs, keys = times[rows], order_key[rows]
                lo, group_start = window_bounds(secs, keys, self.history_len, self.max_window_rows)
                # the window each row would have without a cap, for the window_natural_rows column
                lo_free, start_free = window_bounds(secs, keys, self.history_len)
                own = group_start - lo + 1
                natural = start_free - lo_free + 1
                if len(lo) > 1 and (np.diff(lo) < 0).any():
                    # grouping rests on consecutive rows sharing a first row; a builder that breaks it is refused
                    raise ValueError("grouped windows: the first rows of an account's windows go backwards; score "
                                     "without --group-windows")
                if self.max_window_rows is None and self.max_chunk_rows is not None and (own > self.max_chunk_rows).any():
                    # the project's builder refuses such a window; the grouped one refuses the same row. pg_score
                    # always lifts max_chunk_rows, so this runs only when the builder is used on its own (a test
                    # builds it directly with a small max_chunk_rows to show that it refuses the same file)
                    p = int(np.argmax(own > self.max_chunk_rows))
                    raise ValueError(
                        f"target-ending window of account {df[self.account_col].iloc[rows[p]]!r} holds {int(own[p])} "
                        f"rows > max_chunk_rows={self.max_chunk_rows}; no row is dropped, raise the cap or measure "
                        f"the data")
                # the runs of rows that share a first row: starts[i] .. ends[i] - 1
                starts = np.flatnonzero(np.r_[True, lo[1:] != lo[:-1]])
                ends = np.r_[starts[1:], len(rows)]
                for a, b in zip(starts.tolist(), ends.tolist()):
                    first = int(lo[a])
                    window = rows[first:b]
                    n = len(window)
                    scored_from = a - first  # slots before this are history, from here to the end are scored
                    width = max(self.T, n)  # the model refuses windows narrower than T: padding as in the project
                    w_cont = np.zeros((width, C), dtype=np.float32)
                    w_cat = np.zeros((width, K), dtype=np.int64)
                    w_mask = np.zeros(width, dtype=bool)
                    labels = np.full(width, -100, dtype=np.int64)
                    w_cont[:n, :n_cont] = cont[window]
                    w_cat[:n] = cat[window]
                    w_mask[:n] = True
                    labels[scored_from:n] = target[window[scored_from:]]  # history and padding carry no label
                    w_time = np.zeros(width, dtype=np.int64)
                    w_time[:n] = order_key[window]
                    if self.time_delta and n > 1:
                        # the project's gap rule on the window: to the latest strictly earlier time, 0 when none
                        w_cont[1:n, n_cont] = np.log1p(self._chunk_gaps(times[window], w_time[:n]))
                    seq_meta = {key: np.full(width, None, dtype=object) for key in (meta or {})}
                    for key in seq_meta:
                        seq_meta[key][:n] = meta[key][window]
                    mark = np.zeros(width, dtype=object)
                    mark[:] = False
                    mark[scored_from:n] = True
                    sizes = np.zeros(width, dtype=object)
                    sizes[:] = 0
                    sizes[scored_from:n] = own[a:b]
                    free = np.zeros(width, dtype=object)
                    free[:] = 0
                    free[scored_from:n] = natural[a:b]
                    seq_meta[_SCORED_META], seq_meta[_OWN_META], seq_meta[_NATURAL_META] = mark, sizes, free
                    yield w_cont, w_cat, w_mask, None, seq_meta, labels, w_time

        def _emit_batches(self, buffer):
            for out in super()._emit_batches(buffer):
                meta = out["meta_seq"]
                # the project pads metadata with None; None reads as False and 0 here
                out[SCORED] = torch.from_numpy(meta.pop(_SCORED_META).astype(bool))
                for key, name in ((_OWN_META, OWN_ROWS), (_NATURAL_META, OWN_NATURAL)):
                    values = meta.pop(key)
                    out[name] = torch.from_numpy(np.where(values == None, 0, values).astype(np.int64))  # noqa: E711
                yield out

    GroupedTargetEndingBuilder.__name__ = GroupedTargetEndingBuilder.__qualname__ = "GroupedTargetEndingBuilder"
    return GroupedTargetEndingBuilder


def keep_read_rows(builder, df):
    """Write the id columns, the account and the times of every row of one file the builder read into the run's
    folder of rows read, one small parquet file per file read. A file on disk, not a list in memory, because loader
    workers are other processes: what they keep in memory never reaches the process that checks the output."""
    folder = getattr(builder, "_read_dir", None)
    if not folder:
        return  # the builder was made outside a grouped run (a test that builds it directly)
    import pyarrow as pa
    import pyarrow.parquet as pq
    # the id columns are stored under their place in the list, so that an id column that is also the account
    # column does not collide with it
    columns = {f"id{k}": df[c].to_numpy() for k, c in enumerate(builder.id_cols)}
    columns["account"] = df[builder.account_col].to_numpy()
    # the stored precision decides "same time" and the whole second decides the history, as in the builder
    columns["key"] = df[builder.order_col].to_numpy(dtype="datetime64[ns]").astype("int64")
    columns["second"] = df[builder.order_col].to_numpy(dtype="datetime64[s]").astype("int64")
    # the process id and a random name keep the files of several workers apart
    name = os.path.join(folder, f"{os.getpid()}_{uuid.uuid4().hex}.parquet")
    pq.write_table(pa.table(columns), name)


def own_window_sizes(account, key, second, history_len, cap=None):
    """Each row's own window size worked out from its times alone, the way the docstring above states the rule:
    the rows of its account (in its file) in the history_len distinct seconds before its own second, the rows of
    its own second with a strictly earlier time, and the row itself; with a cap, at most cap rows. The rows may
    come in any order: the sizes are returned in the order given. This is written here on its own, without the
    project's window_bounds, so that the check of the output does not lean on the function the option uses."""
    n = len(key)
    if n == 0:
        return np.zeros(0, np.int64)
    codes = pd.factorize(pd.Series(account), sort=False)[0]
    # by account, then time: the order in which the rule counts earlier rows
    order = np.lexsort((key, codes))
    a, k, s = codes[order], np.asarray(key)[order], np.asarray(second)[order]
    new_account = np.r_[True, a[1:] != a[:-1]]
    # the first row of each row's account, so that a history never reaches into another account
    account_start = np.maximum.accumulate(np.where(new_account, np.arange(n), 0))
    # a running count of distinct seconds, restarted in effect at each account by account_start below
    new_second = new_account | np.r_[True, s[1:] != s[:-1]]
    second_index = np.cumsum(new_second) - 1
    # the first row with the same time: rows from there on are same-time peers, which the row does not see
    new_key = new_account | np.r_[True, k[1:] != k[:-1]]
    group_start = np.maximum.accumulate(np.where(new_key, np.arange(n), 0))
    # the first row whose second is among the history_len seconds before the row's own
    lo = np.maximum(np.searchsorted(second_index, second_index - int(history_len), side="left"), account_start)
    sizes = group_start - lo + 1
    if cap is not None:
        sizes = np.minimum(sizes, int(cap))  # the cap keeps the row and its latest cap - 1 earlier rows
    out = np.empty(n, np.int64)
    out[order] = sizes
    return out


def rows_read(folder, id_cols, history_len, cap):
    """One frame of every row the builder read in this run: its id columns, its own window size and its window
    size without a cap, worked out from its times file by file (a window never crosses a file)."""
    import pyarrow.parquet as pq
    frames = []
    for name in sorted(os.listdir(folder)) if folder and os.path.isdir(folder) else []:
        part = pq.read_table(os.path.join(folder, name)).to_pandas()
        out = pd.DataFrame({c: part[f"id{k}"] for k, c in enumerate(id_cols)})
        out["_own"] = own_window_sizes(part["account"], part["key"].to_numpy(), part["second"].to_numpy(),
                                       history_len, cap)
        out["_natural"] = own_window_sizes(part["account"], part["key"].to_numpy(), part["second"].to_numpy(),
                                           history_len, None)
        frames.append(out)
    if not frames:
        return pd.DataFrame({**{c: [] for c in id_cols}, "_own": [], "_natural": []})
    return pd.concat(frames, ignore_index=True)


def check_output(out_path, read, id_cols, reference=None, limit=None):
    """Check a finished grouped output against facts the option did not produce: the rows the builder read (their
    ids and their window sizes worked out from their times) and, when given, the scores the scorer's own run gave
    the sample's rows. Rows are matched by their id columns, never by position, so an output in another order
    passes. Returns (True, None) or (False, the reason)."""
    import pyarrow.parquet as pq
    limit = COMPARE_LIMIT if limit is None else float(limit)
    if not out_path or not os.path.isfile(out_path):
        return False, "the output file was not written"
    present = set(pq.read_schema(out_path).names)
    # a column the check needs that is not there is a failed check with its reason, not a traceback
    needed = list(id_cols) + ["window_rows"] + (["score"] if reference is not None else [])
    missing = [c for c in needed if c not in present]
    if not id_cols:
        return False, "the scorer has no id columns to match the rows by"
    if missing:
        return False, "the output has no column " + ", ".join(missing)
    extra = ["window_natural_rows"] if "window_natural_rows" in present else []
    out = pq.read_table(out_path, columns=needed + extra).to_pandas()
    # first as a count: as many rows written as read
    if len(out) != len(read):
        return False, f"the output holds {len(out):,} rows and the builder read {len(read):,}"
    if out.duplicated(id_cols).any():
        return False, f"{int(out.duplicated(id_cols).sum()):,} ids appear more than once in the output"
    # then as sets: every row read is in the output and nothing else is
    both = read.merge(out, on=list(id_cols), how="outer", indicator=True)
    only_read, only_out = int((both["_merge"] == "left_only").sum()), int((both["_merge"] == "right_only").sum())
    if only_read or only_out:
        return False, (f"{only_read:,} rows read are not in the output and {only_out:,} rows of the output were not "
                       f"read")
    # each row's window_rows against its own window worked out from its times
    wrong = int((both["window_rows"].astype(np.int64) != both["_own"]).sum())
    if wrong:
        return False, f"{wrong:,} rows have another window_rows than the window worked out from their times"
    if extra:
        wrong = int((both["window_natural_rows"].astype(np.int64) != both["_natural"]).sum())
        if wrong:
            return False, (f"{wrong:,} rows have another window_natural_rows than the window worked out from their "
                           f"times")
    if reference is not None and len(reference):
        # the sample's rows lie in the range's first file with all their account's rows, so the full run builds them
        # the same windows as the sample run: their scores must match the scorer's own scores
        joined = reference.merge(out, on=list(id_cols), how="left", suffixes=("_own", ""))
        if joined["score"].isna().any():
            return False, "rows of the built-in comparison's sample are missing from the output"
        gap = float(np.abs(joined["score_own"].to_numpy(np.float64) - joined["score"].to_numpy(np.float64)).max())
        if not gap <= limit:
            return False, (f"the sample's rows have scores in the output that differ by {gap:.3g} from the scorer's "
                           f"own scores of them (limit {limit:g})")
    return True, None


def last_real_row(mask):
    """[B, W] bool, True on the last real slot of each window (right-padded windows and left-padded single-target
    windows alike: the last True of the mask)."""
    mask = mask.to(torch.bool)
    W = mask.shape[1]
    last = W - 1 - torch.flip(mask, dims=[1]).to(torch.uint8).argmax(1)
    out = torch.zeros_like(mask)
    has = mask.any(1)
    out[torch.arange(mask.shape[0])[has], last[has]] = True
    return out


_GROUPED = {}  # counts of the run in progress, read by the receipt


def counts_start():
    _GROUPED.clear()
    _GROUPED.update(windows=0, slots=0, real_rows=0, scored=0, own_slots=0, grouped_batches=0, own_rows=[],
                    window_slots=0, model_calls=0, calls_with_mark=0)


def counting_forward(original):
    """The model's forward, counting what reaches it: the calls, the calls that carry the "scored" entry, and the
    windows and slots handed over. It is counted at the model, not where the inputs are made, because a scorer may
    keep its own reference to the function that makes the inputs, and then a wrapper there is never called."""
    depth = [0]  # the wide-batch path may call the model again inside one call; only the outer call is counted

    @functools.wraps(original)
    def forward(self, batch):
        if depth[0] == 0 and isinstance(batch, dict) and torch.is_tensor(batch.get("mask")):
            mask = batch["mask"]
            _GROUPED["model_calls"] = _GROUPED.get("model_calls", 0) + 1
            if SCORED in batch:
                _GROUPED["calls_with_mark"] = _GROUPED.get("calls_with_mark", 0) + 1
            # what went through the model: windows, and slots as handed over (windows x the batch width)
            _GROUPED["windows"] = _GROUPED.get("windows", 0) + int(mask.shape[0])
            _GROUPED["slots"] = _GROUPED.get("slots", 0) + int(mask.shape[0] * mask.shape[1])
            _GROUPED["window_slots"] = _GROUPED.get("window_slots", 0) + int(
                mask.sum(1).clamp(min=int(_GROUPED.get("T", 1))).sum())
        depth[0] += 1
        try:
            return original(self, batch)
        finally:
            depth[0] -= 1

    return forward


def inputs_with_mark(original, mark_last):
    """The scorer's function that hands inputs to the model, handing on the "scored" entry when the batch has it.
    With mark_last, a batch without it (ungrouped scoring) gets the last real row of every window as its mark."""

    def _model_inputs(batch, device):
        inputs = original(batch, device)
        if SCORED in batch:
            inputs[SCORED] = batch[SCORED].to(device)
        elif mark_last:
            inputs[SCORED] = last_real_row(batch["mask"]).to(device)
        return inputs

    _model_inputs.__wrapped__ = original
    return _model_inputs


def grouped_select(original):
    """The scorer's selecting function for grouped batches: (probability, label, metadata) per scored row, in batch
    order then slot order, which is the order of the ungrouped run. A batch without the mark goes to the scorer's
    own selection.

    The scorer then takes each row's window_rows as the batch mask's row sums, one per window. A grouped window
    scores several rows, so after selecting, the batch's mask is replaced by one row per scored row whose sum is
    that row's own window size (the model has already run on the real mask, which stays under "window_mask"), and
    the natural sizes are left for natural_rows."""

    def select(logits, batch, chunk):
        if not isinstance(batch, dict) or SCORED not in batch or OWN_ROWS not in batch:
            return original(logits, batch, chunk)
        scored, mask, labels = batch[SCORED].to(torch.bool), batch["mask"].to(torch.bool), batch["target_seq"]
        if tuple(logits.shape[:2]) != tuple(mask.shape):
            raise ValueError("grouped windows: the model's output does not have one slot per window slot")
        if bool((scored & ~mask).any()) or not torch.equal(labels != -100, scored):
            raise ValueError("grouped windows: the scored mark must be on real, labelled rows and only there")
        # boolean indexing runs window by window, slot by slot: the rows come out in the ungrouped order. The
        # softmax runs in the logits' own number type, as the scorer's own selection does, so the score column
        # has the same type both ways
        prob = torch.softmax(logits[scored], dim=-1)[:, 1].detach().cpu().numpy()
        y = labels[scored].cpu().numpy()
        picked = scored.cpu().numpy()
        meta = {key: np.asarray(values)[picked] for key, values in batch.get("meta_seq", {}).items()}
        own = batch[OWN_ROWS][scored].cpu().numpy().astype(np.int64)
        natural = batch[OWN_NATURAL][scored].cpu().numpy().astype(np.int64)
        if (own < 1).any():
            raise ValueError("grouped windows: a scored row has no own window size")
        width = int(own.max()) if len(own) else 1
        batch["window_mask"] = batch["mask"]
        batch["mask"] = torch.arange(width).unsqueeze(0) < torch.from_numpy(own).unsqueeze(1)
        batch[_PICKED_NATURAL] = natural
        _GROUPED["grouped_batches"] = _GROUPED.get("grouped_batches", 0) + 1
        _GROUPED["scored"] = _GROUPED.get("scored", 0) + int(len(own))
        return prob, y, meta

    select.__wrapped__ = original
    return select


def grouped_natural_rows(original):
    """The scorer's natural_rows, giving the natural sizes the grouped selection left for the rows it selected."""

    def natural_rows(batch, chunk):
        if isinstance(batch, dict) and _PICKED_NATURAL in batch:
            return batch[_PICKED_NATURAL]
        return original(batch, chunk)

    natural_rows.__wrapped__ = original
    return natural_rows


def grouping_pieces(layout, scorer):
    """(target-ending builder class, window_bounds) when every piece grouped windows need is in this layout, else
    (None, the name of the first missing piece)."""
    for name in ("TargetEndingBuilder", "select", "natural_rows", "_model_inputs"):
        if not hasattr(scorer, name):
            return None, f"the scorer's {name}"
    try:
        data = importlib.import_module(pg_layout.NAMES[layout]["target_ending_data"])
    except ImportError:
        return None, "the target-ending data module"
    if not hasattr(data, "window_bounds"):
        return None, "window_bounds in the target-ending data module"
    base = scorer.TargetEndingBuilder
    # the builder steps the grouped one reuses, and the reading step whose rows the output check counts
    for name in ("_account_groups", "_chunk_gaps", "_emit_batches", "_encode_file"):
        if not hasattr(base, name):
            return None, f"{name} in the target-ending builder"
    return base, data.window_bounds


@contextlib.contextmanager
def grouped_scoring(layout, scorer, group, mark, model_cls=None, pieces=None):
    """While open, the scorer builds grouped windows (group) and/or hands the model the scored mark (mark, or
    group), and the model's calls are counted. Yields True when grouping is on. Everything is put back on exit,
    and the folder of rows read is removed."""
    if not group and not mark:
        yield False
        return
    counts_start()
    saved = {}
    on = False
    folder = None
    if group:
        base, bounds = pieces if pieces is not None else grouping_pieces(layout, scorer)
        if base is None:
            print(f"group windows: {bounds} was not found in this layout, so the rows are scored the ungrouped way "
                  f"(one window per row)", flush=True)
            _GROUPED["missing"] = bounds
        else:
            on = True
            # the rows the builder reads are written here, for the check of the output
            folder = tempfile.mkdtemp(prefix="pg_rows_read_")
            _GROUPED["read_dir"] = folder
            saved.update(TargetEndingBuilder=scorer.TargetEndingBuilder, select=scorer.select,
                         natural_rows=scorer.natural_rows)
            scorer.TargetEndingBuilder = grouped_builder_class(base, bounds)
            scorer.select = grouped_select(saved["select"])
            scorer.natural_rows = grouped_natural_rows(saved["natural_rows"])
    if hasattr(scorer, "_model_inputs"):
        saved["_model_inputs"] = scorer._model_inputs
        scorer._model_inputs = inputs_with_mark(saved["_model_inputs"], mark)
    elif mark:
        print("mark scored rows: the scorer's _model_inputs was not found in this layout, so no mark reaches the "
              "model", flush=True)
    counted = None
    if model_cls is not None:
        # counted at the model, on top of whatever else wraps its forward (the wide-batch path)
        counted = model_cls.forward
        model_cls.forward = counting_forward(counted)
    try:
        yield on
    finally:
        if counted is not None:
            model_cls.forward = counted
        for name, value in saved.items():
            setattr(scorer, name, value)
        if folder:
            # a builder made after the run (by a test, for one) must not write into the removed folder
            if _GROUPED.get("read_dir") == folder:
                _GROUPED.pop("read_dir")
            shutil.rmtree(folder, ignore_errors=True)


def run_scorer(scorer, argv):
    """The scorer's own main on these arguments; its exit code."""
    if inspect.signature(scorer.main).parameters:
        return int(scorer.main(argv) or 0)
    sys.argv = [scorer.__file__] + list(argv)
    return int(scorer.main() or 0)


def scorer_config(argv):
    """The config the scorer will score with: its file and the dotlist overrides, merged as the scorer merges them."""
    from omegaconf import OmegaConf
    cfg = OmegaConf.load(scorer_argument(argv, "--config"))
    overrides = [x for x in argv if "=" in x and not x.startswith("-")]
    return OmegaConf.merge(cfg, OmegaConf.from_dotlist(overrides)) if overrides else cfg


def with_options(argv, values):
    """argv with each named option of the scorer set to a new value: every earlier form of it (two arguments,
    --name=VALUE, or a shortened name that only it starts with) is taken out, and the new ones go first, before the
    overrides, which the scorer reads as one group."""
    out, i = [], 0
    while i < len(argv):
        token = argv[i]
        head = token.split("=", 1)[0]
        hit = False
        for name in values:
            others = [o for o in SCORER_OPTIONS if o != name]
            if head == name or (head.startswith("--") and len(head) > 2 and name.startswith(head)
                                and not any(o.startswith(head) for o in others)):
                hit = True
        if hit:
            i += 1 if "=" in token else 2  # the option and its value
            continue
        out.append(token)
        i += 1
    front = [x for name, value in values.items() for x in (name, str(value))]
    return front + out


def sample_accounts(first_seen, rows, budget=None, busy=None, busy_share=None):
    """The accounts of the comparison's sample: first the busiest accounts that fit in busy_share of the budget (at
    most `busy` of them, each with at least two rows), then accounts with at least two rows in the order they first
    appear in the file, then one-row accounts, until the sample holds about `budget` rows.

    first_seen: the accounts in the order of their first row in the file; rows: the row count of each, in the same
    order. Returns (the chosen accounts, the rows they hold, how many busy accounts were taken)."""
    budget = SAMPLE_ROWS if budget is None else int(budget)
    busy = SAMPLE_BUSY_ACCOUNTS if busy is None else int(busy)
    busy_share = SAMPLE_BUSY_SHARE if busy_share is None else float(busy_share)
    first_seen, rows = list(first_seen), np.asarray(rows, dtype=np.int64)
    chosen, taken, total = [], set(), 0
    # the busiest first: their windows are the widest and the grouped way changes them most
    for i in np.argsort(-rows, kind="stable"):
        if len(chosen) >= busy or rows[i] < 2:
            break
        if total + rows[i] <= busy_share * budget:
            chosen.append(first_seen[i])
            taken.add(i)
            total += int(rows[i])
    n_busy = len(chosen)
    # then accounts with at least two rows, where grouping has something to group, from the start of the file; an
    # account that would take the sample past its budget is passed over, so one huge account cannot make it costly
    for at_least in (2, 1):
        for i, n in enumerate(rows):
            if total >= budget:
                break
            if i in taken or n < at_least or total + n > budget:
                continue
            chosen.append(first_seen[i])
            taken.add(i)
            total += int(n)
    return chosen, total, n_busy


def write_sample(cfg, layout, folder):
    """Write the comparison's sample into folder: the rows of the chosen accounts of the range's first file, every
    column, under the name the scorer will look for there. Returns (the overrides that point the scorer at it, the
    rows, the accounts, the busy accounts)."""
    import pyarrow.compute as pc
    import pyarrow.parquet as pq
    files = importlib.import_module(pg_layout.NAMES[layout]["s3_files"])
    start = int(cfg.eval.file_start)
    first = files.build_file_list(str(cfg.eval.base), start, start)[0]
    s3 = cfg.get("s3") or {}
    fs = files.make_s3_filesystem(s3.get("cred_path")) if s3.get("cred_path") else None
    path = files.strip_scheme(first) if fs is not None else first
    account_col = str(cfg.data.account_col)
    # the account column alone first, to choose the accounts without holding the whole file
    accounts = pq.ParquetDataset(path, filesystem=fs).read(columns=[account_col]).column(0).to_pandas()
    sizes = accounts.groupby(accounts, sort=False).size()  # in the order of each account's first row
    chosen, total, n_busy = sample_accounts(sizes.index.tolist(), sizes.to_numpy())
    table = pq.ParquetDataset(path, filesystem=fs, filters=pc.field(account_col).isin(chosen)).read()
    data = os.path.join(folder, "data")
    os.makedirs(data)
    local = files.build_file_list(data, start, start)[0]
    if os.path.dirname(os.path.abspath(local)) != os.path.abspath(data):
        raise ValueError("the scorer's file names cannot be placed in a local folder")
    pq.write_table(table, local)
    overrides = [f"eval.base={data}", f"eval.file_start={start}", f"eval.file_end={start}"]
    return overrides, int(table.num_rows), len(chosen), n_busy


def compare_on_sample(layout, scorer, argv, mark, model_cls, pieces):
    """The built-in comparison: score a sample of the range's first file the scorer's own way and the grouped way,
    and compare the two by the id columns. Returns (the receipt entry, the scorer's own scores of the sample as a
    frame of the id columns and the score, or None).

    Why this way. Each way runs the scorer's own main, end to end, on a small file written from the range's first
    file: the scorer's own builder, selecting function, input function, model, checks and writing for the one, and
    the very code path of the grouped run for the other. Nothing here copies or predicts what the scorer does, so a
    scorer that is not the one in this checkout (another selecting function, another window or gap rule, its own
    reference to the input function, a model that reads the mark) is measured by what it writes, not by what its
    pieces are called. The sample's scoring is recorded by the scorer like any other scoring (its exposure file and
    the run's manifest), with predictions in a temporary folder that is removed afterwards."""
    started = time.time()
    entry = {"limit": COMPARE_LIMIT, "passed": False}
    folder = tempfile.mkdtemp(prefix="pg_compare_")
    reference = None
    try:
        try:
            cfg = scorer_config(argv)
            id_cols = [str(c) for c in (cfg.data.get("id_cols") or [])]
            if not id_cols:
                raise ValueError("the config has no data.id_cols to match the rows by")
            overrides, rows, accounts, n_busy = write_sample(cfg, layout, folder)
        except Exception as error:  # noqa: BLE001 (any failure to prepare the sample means it cannot pass)
            entry["reason"] = f"the sample could not be prepared ({type(error).__name__}: {error})"
            return entry, None
        entry.update(rows=rows, accounts=accounts, busy_accounts=n_busy)
        outs = {}
        for way in ("own", "grouped"):
            out = os.path.join(folder, f"{way}.parquet")
            sample_argv = with_options(argv, {"--out": out, "--metrics": out + ".json"})
            for item in overrides:
                sample_argv = with_override(sample_argv, item)  # the later override wins in the scorer's merge
            began = time.time()
            try:
                if way == "own":
                    # the scorer's own way: none of its pieces replaced
                    rc = run_scorer(scorer, sample_argv)
                else:
                    with grouped_scoring(layout, scorer, True, mark, model_cls, pieces):
                        rc = run_scorer(scorer, sample_argv)
                        entry["sample_model_calls"] = int(_GROUPED.get("model_calls", 0))
                        entry["sample_calls_with_mark"] = int(_GROUPED.get("calls_with_mark", 0))
            except (Exception, SystemExit) as error:  # noqa: BLE001 (anything raised means the way cannot be trusted)
                text = "the scorer's own run" if way == "own" else "the grouped run"
                entry["reason"] = f"{text} of the sample raised {type(error).__name__}: {str(error)[:200]}"
                return entry, None
            entry[f"seconds_{way}"] = round(time.time() - began, 2)
            if rc != 0:
                entry["reason"] = f"the {way} run of the sample ended with exit code {rc}"
                return entry, None
            outs[way] = out
        own, grouped = pd.read_parquet(outs["own"]), pd.read_parquet(outs["grouped"])
        missing = [c for c in id_cols + ["score"] if c not in own.columns or c not in grouped.columns]
        if missing:
            entry["reason"] = "a sample output has no column " + ", ".join(missing)
            return entry, None
        if own.duplicated(id_cols).any() or grouped.duplicated(id_cols).any():
            entry["reason"] = "an id appears more than once in a sample output"
            return entry, None
        both = own.merge(grouped, on=id_cols, how="outer", suffixes=("_own", "_grouped"), indicator=True)
        only_own, only_grouped = int((both["_merge"] == "left_only").sum()), int((both["_merge"] == "right_only").sum())
        if only_own or only_grouped or len(own) != len(grouped):
            entry["reason"] = (f"the ids differ: {only_own:,} rows only in the scorer's own run and {only_grouped:,} "
                               f"only in the grouped run")
            return entry, None
        gap = float(np.abs(both["score_own"].to_numpy(np.float64) - both["score_grouped"].to_numpy(np.float64)).max())
        entry["max_score_difference"] = gap
        if not gap <= COMPARE_LIMIT:  # also fails on a score that is not a number
            entry["reason"] = f"a score differs by {gap:.3g} (limit {COMPARE_LIMIT:g})"
            return entry, None
        if "window_rows_own" in both and "window_rows_grouped" in both:
            wrong = int((both["window_rows_own"] != both["window_rows_grouped"]).sum())
            if wrong:
                entry["reason"] = f"{wrong:,} rows have another window_rows"
                return entry, None
        entry["passed"] = True
        reference = own[id_cols + ["score"]].copy()
        return entry, reference
    finally:
        entry["seconds"] = round(time.time() - started, 2)
        shutil.rmtree(folder, ignore_errors=True)


def mark_report(meant):
    """The receipt entry of the mark and, when it did not reach every model call, one plain line."""
    calls, marked = int(_GROUPED.get("model_calls", 0)), int(_GROUPED.get("calls_with_mark", 0))
    entry = {"meant": bool(meant), "model_calls": calls, "calls_with_mark": marked}
    if meant and marked < calls:
        print(f"mark scored rows: the mark reached {marked:,} of {calls:,} model calls; the scorer hands the model its "
              f"inputs another way than the tool expects, so a model that reads the mark did not get it", flush=True)
    elif meant and calls == 0:
        print("mark scored rows: no call of the model was seen, so whether the mark reached it is not known",
              flush=True)
    return entry


def grouped_receipt(group, on, comparison, mark_meant, out_path, metrics_path, reference=None):
    """After a run with --group-windows or --mark-scored-rows: check a grouped output (check_output), and write the
    grouped_windows and scored_mark entries into the receipt. Returns False, after renaming the output to
    <out>.not_checked, when a grouped output fails its check."""
    ok = True
    receipt_entries = {"scored_mark": mark_report(mark_meant)}
    if group:
        entry = {"grouped": bool(on and _GROUPED.get("grouped_batches", 0) > 0)}
        if comparison is not None:
            entry["built_in_comparison"] = comparison
        if _GROUPED.get("missing"):
            entry["not_grouped_because"] = f"{_GROUPED['missing']} was not found in this layout"
        elif comparison is not None and not comparison.get("passed"):
            entry["not_grouped_because"] = f"the built-in comparison: {comparison.get('reason')}"
        elif on and not entry["grouped"]:
            # the option was on but the scorer built no target-ending window (a single-target model)
            entry["not_grouped_because"] = "the scorer built no target-ending window (a single-target model)"
            print("group windows: the scorer built no target-ending window for this model, so nothing was grouped",
                  flush=True)
        if entry["grouped"]:
            id_cols = list(_GROUPED.get("id_cols") or [])
            read = rows_read(_GROUPED.get("read_dir"), id_cols, _GROUPED.get("history_len", 0), _GROUPED.get("cap"))
            ok, why = check_output(out_path, read, id_cols, reference)
            if not ok:
                moved = None
                if out_path and os.path.isfile(out_path):
                    moved = str(out_path) + ".not_checked"
                    os.replace(out_path, moved)
                entry["check_failed_because"] = why
                print(f"error: the grouped run's output failed its check: {why}"
                      + (f"; the output was renamed to {moved}" if moved else "")
                      + ". Score again without --group-windows, to a new --out", file=sys.stderr, flush=True)
            T = int(_GROUPED.get("T", 1))
            entry.update(
                windows_through_model=int(_GROUPED["windows"]), slots_through_model=int(_GROUPED["slots"]),
                window_slots=int(_GROUPED["window_slots"]), rows_scored=int(_GROUPED["scored"]),
                # what an ungrouped run uses, from the rows read and their own windows, not from the grouped run
                ungrouped_windows=int(len(read)), ungrouped_window_slots=int(np.maximum(read["_own"], T).sum()),
                note="compare window_slots with ungrouped_window_slots (each window at its own width, at least "
                     "history_len + 1). slots_through_model is windows x the batch width as handed to the model, "
                     "padded to the batch, and is not comparable")
            entry["output_checked"] = ok
        receipt_entries["grouped_windows"] = entry
    if metrics_path and os.path.isfile(metrics_path):
        with open(metrics_path, encoding="utf-8") as f:
            receipt = json.load(f)
        receipt.update(receipt_entries)
        tmp = f"{metrics_path}.grouped.tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(receipt, f, indent=2, sort_keys=True, default=str)
        os.replace(tmp, metrics_path)
    entry = receipt_entries.get("grouped_windows") or {}
    if entry.get("grouped") and ok:
        print(f"group windows: {entry['windows_through_model']:,} windows and {entry['window_slots']:,} window slots "
              f"through the model for {entry['rows_scored']:,} rows; an ungrouped run uses "
              f"{entry['ungrouped_windows']:,} windows and {entry['ungrouped_window_slots']:,} window slots",
              flush=True)
    return ok


def main(argv=None):
    argv, months = take_month_map(list(sys.argv[1:] if argv is None else argv))
    argv, group = take_flag(argv, GROUP_OPTION)
    argv, mark = take_flag(argv, MARK_OPTION)
    months = months_for(checkpoint_argument(argv), months)
    argv = with_override(argv, NO_CHUNK_LIMIT)
    layout, mods = pg_layout.resolve(roles=("base_model", "scorer"))
    scorer = mods["scorer"]
    model_cls = mods["base_model"].FTTransformerHierModel
    with no_row_limits(mods), month_read_as(months):
        comparison, reference, pieces, group_now = None, None, None, group
        if group:
            pieces = grouping_pieces(layout, scorer)
            # with a piece missing by name, grouped_scoring prints the line and the rows are scored the ungrouped
            # way; with every piece there, the built-in comparison decides
            if pieces[0] is not None:
                comparison, reference = compare_on_sample(layout, scorer, argv, mark, model_cls, pieces)
                if comparison["passed"]:
                    print(f"group windows: the built-in comparison scored {comparison['rows']:,} rows of "
                          f"{comparison['accounts']:,} accounts both ways in {comparison['seconds']:.1f} s; largest "
                          f"score difference {comparison['max_score_difference']:.2g} (limit {COMPARE_LIMIT:g})",
                          flush=True)
                else:
                    print(f"group windows: the built-in comparison did not pass ({comparison['reason']}), so the "
                          f"whole range is scored the scorer's own way (one window per row)", flush=True)
                    group_now = False
                if months:
                    pg_patch.month_rows_seen(reset=True)  # the full run must show on its own that the map reached it
        counts_start()  # the counts of the full run start here, whatever the sample counted
        with grouped_scoring(layout, scorer, group_now, mark, model_cls, pieces) as grouped:
            rc = run_scorer(scorer, argv)
            out_path = scorer_argument(argv, "--out")
            if rc == 0 and (group or mark):
                metrics_path = scorer_argument(argv, "--metrics") or (f"{out_path}.json" if out_path else None)
                if not grouped_receipt(group, grouped, comparison, bool(mark or grouped), out_path, metrics_path,
                                       reference):
                    return 4
            if rc == 0 and not month_reached_the_rows(months, out_path):
                return 3
            return rc


if __name__ == "__main__":
    sys.exit(main())
