"""Train the chosen model with any of the program's training variants. Every option is off by default; with none
set, this runs the project's trainer with no row limits: no window cap is required, no chunk width stops a run
(sequence.max_chunk_rows is dropped), and a batch too wide for one GPU call runs through the model in parts
(pg_patch.install_wide_batches; batches under the limit take the model's own forward).

Where it runs: on the pod (Red Hat OpenShift AI workbench with the GPU), from the project root.

Usage, everything after `--` going to the project's trainer unchanged:

    $PY program/pg_train.py [options] -- --config <the control's config> [overrides] \
        output.checkpoint_dir=runs/program/<arm>_seed42

Data options:
  --files-list FILE           train on the file numbers listed in FILE (one per line; pg_files.py writes them)
  --local-dir DIR             read the training files from DIR/part_<n>.parquet (pg_cache.py makes the copy)
  --loss-mask declines advice declined rows and/or advice rows stay as history, without loss
  --recency-half-life H       loss weight 0.5 ** (months before the latest training month / H)
  --clean-account-share S     keep every fraud account and a share S of the other accounts
  --keep-fraud-account-negatives   with sampling: do not mask non-fraud rows of fraud accounts (default masks them
                              at the same share, so every non-fraud row counts with the same probability)
  --inverse-negative-weight   with sampling: weight the counted non-fraud rows 1/S (the debiased arm)
  --prefix-seconds P          give each chunk the P distinct seconds before it as context (no loss on them), with
                              a banded mask limiting each row to its scoring window's rows (the history length and
                              the window cap from the config; no row limit when the config has no cap); closer to
                              scoring, not identical. --prefix-max-rows R  limit the prefix to R rows
No window cap: sequence.max_window_rows=null in the config. Validation windows then hold every row of their history.
Model and loss options:
  --loss focal --focal-gamma 2     focal loss; --plateau-monitor valid_ap   plateau scheduler on valid_ap, mode max
  --grad-clip 1.0             gradient clipping by norm
  --ema-decay 0.999           keep EMA weights too: validated at every validation, best kept as best_ema.ckpt
  --init-from CKPT            start from another checkpoint's weights (warm start; optimizer starts fresh)
  --init-from-matching CKPT   start from another checkpoint's weights wherever a tensor's name and shape match, and
                              leave the rest at its initial values (a model of another shape: more summary tokens,
                              a wider stage 2). A line says how much was taken and what was left
  --no-month                  switch the month off: every row of training and validation is read with the same
                              month, so the model cannot use it. For a model scored on a month that training never
                              had. No new predictor list or artifact is needed. The setting is saved in the
                              checkpoints; pg_score.py and pg_export.py apply it by themselves, and another scorer
                              would feed such a model real months it never saw. A run that continues a model
                              trained this way (--resume, --init-from, --init-from-matching) switches the month
                              off too, by itself; --keep-month trains it on real months all the same
Validation and length (for the large runs):
  --val-every-updates N       validate every N optimizer updates instead of once per epoch (patience and the
                              plateau scheduler then count validations; a resume continues from the end of the
                              latest whole epoch); --limit-val-batches B  validate on the first B batches only
  --max-steps N               stop after N optimizer updates; --keep-near-update U  also keep near_update.ckpt, the
                              checkpoint at the validation nearest U updates
  --lr-warmup-updates W --lr-cooldown-share C   a fixed learning-rate plan over the N updates of --max-steps, in
                              place of the plateau rule: W updates of warm-up, the config's rate until the last
                              share C of the updates (default 0.2), then down to 0 at update N. C = 1 starts the
                              fall right after the warm-up (a cooldown of a model given with --init-from). The
                              rate is printed at every validation. Make N a multiple of --val-every-updates, so
                              that the last validation and last.ckpt fall on the last update.
  --train-hours H             the run trains for H hours and then stops, with the learning rate planned on the
                              clock: W updates of warm-up (--lr-warmup-updates), the config's rate, then down to 0
                              over the last share C of the hours (--lr-cooldown-share, default 0.2). No number of
                              updates is needed. When the hours are over the trainer validates once more and
                              final.ckpt is written: the weights of the last update. clock.ckpt holds the latest
                              weights, written every 30 minutes and when the run is stopped by hand. Not together
                              with --max-steps. Unless given after `--`, training.max_epochs=1000 and
                              training.early_stopping_patience=100000 are added, so that only the clock ends the
                              run: when the file list ends before the hours, the next pass starts.
  --profile-steps N           time N training steps (data wait against step time, GPU use) and stop; profile.json

Every setting is written to program_settings.json in the run folder and into each checkpoint (program_settings).
Checkpoints load in the normal scorer: no option changes the model's weights or their names.
"""
import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pg_layout  # noqa: E402
import pg_patch  # noqa: E402

OUT_PREFIX = "output.checkpoint_dir="
NO_CHUNK_LIMIT = "sequence.max_chunk_rows=null"  # the builders then never stop on a wide chunk or window


def split_argv(argv):
    if "--" not in argv:
        raise SystemExit("usage: pg_train.py [options] -- <trainer args>")
    i = argv.index("--")
    return argv[:i], argv[i + 1:]


def parser():
    ap = argparse.ArgumentParser(description="train the chosen model with the program's variants")
    ap.add_argument("--files-list", default=None)
    ap.add_argument("--local-dir", default=None)
    ap.add_argument("--loss-mask", nargs="+", choices=("declines", "advice"), default=None)
    ap.add_argument("--decline-col", default=None)
    ap.add_argument("--advice-col", default=None)
    ap.add_argument("--recency-half-life", type=float, default=None)
    ap.add_argument("--clean-account-share", type=float, default=None)
    ap.add_argument("--keep-fraud-account-negatives", action="store_true")
    ap.add_argument("--inverse-negative-weight", action="store_true")
    ap.add_argument("--sample-seed", type=int, default=None)
    ap.add_argument("--prefix-seconds", type=int, default=None)
    ap.add_argument("--prefix-max-rows", type=int, default=None)
    ap.add_argument("--loss", choices=("ce", "focal"), default=None)
    ap.add_argument("--focal-gamma", type=float, default=None)
    ap.add_argument("--plateau-monitor", choices=("valid_loss", "valid_ap"), default=None)
    ap.add_argument("--grad-clip", type=float, default=None)
    ap.add_argument("--ema-decay", type=float, default=None)
    ap.add_argument("--init-from", default=None)
    ap.add_argument("--init-from-matching", default=None)
    ap.add_argument("--no-month", action="store_true")
    ap.add_argument("--keep-month", action="store_true")
    ap.add_argument("--val-every-updates", type=int, default=None)
    ap.add_argument("--limit-val-batches", type=int, default=None)
    ap.add_argument("--max-steps", type=int, default=None)
    ap.add_argument("--lr-warmup-updates", type=int, default=None)
    ap.add_argument("--lr-cooldown-share", type=float, default=None)
    ap.add_argument("--train-hours", type=float, default=None)
    ap.add_argument("--keep-near-update", type=int, default=None)
    ap.add_argument("--profile-steps", type=int, default=None)
    return ap


def read_files_list(path):
    numbers = []
    for line in Path(path).read_text().splitlines():
        line = line.split("#")[0].strip()
        if line:
            numbers.extend(int(x) for x in line.replace(",", " ").split())
    if not numbers:
        raise SystemExit(f"{path} lists no file numbers")
    return numbers


def with_override(args, item):
    """args with a config override added next to the other overrides (the trainer reads them as one group)."""
    last = max((i for i, x in enumerate(args) if "=" in x and not x.startswith("-")), default=None)
    return args + [item] if last is None else args[:last + 1] + [item] + args[last + 1:]


def trainer_config(rest):
    from omegaconf import OmegaConf
    i = rest.index("--config")
    cfg = OmegaConf.load(rest[i + 1])
    overrides = [x for x in rest if "=" in x and not x.startswith("-")]
    if overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(overrides))
    return cfg


def window_caps(cfg, s, prefix_max_rows=None):
    """The band and the context prefix follow the config's scoring window: the history length in distinct seconds,
    and the row cap (sequence.max_window_rows) minus the row itself. With no row cap in the config (None), the band
    and the prefix have no row limit either. --prefix-max-rows, when given, sets the prefix limit on its own."""
    s["band_seconds"] = int(cfg.sequence.history_len)
    cap = cfg.sequence.get("max_window_rows", None)
    s["band_rows"] = None if cap is None else int(cap) - 1
    s["prefix_max_rows"] = s["band_rows"] if prefix_max_rows is None else int(prefix_max_rows)
    return s


class _TrainerArgs:
    """Stands in for the trainer module's `pytorch_lightning` while it builds its Trainer, adding our arguments
    and callbacks; every other attribute is the real module's."""

    def __init__(self, real, extra, callbacks):
        self._real, self._extra, self._callbacks = real, extra, callbacks

    def __getattr__(self, name):
        return getattr(self._real, name)

    def Trainer(self, *args, **kwargs):  # noqa: N802 (the name Lightning uses)
        kwargs.update(self._extra)
        kwargs["callbacks"] = list(kwargs.get("callbacks") or []) + list(self._callbacks)
        return self._real.Trainer(*args, **kwargs)


_ORIGINALS = {}


def _replace(module, name, value):
    _ORIGINALS.setdefault((module, name), getattr(module, name))
    setattr(module, name, value)


def uninstall(mods):
    """Undo install(): the trainer's functions and the model class as they were (used by the tests)."""
    for (module, name), value in list(_ORIGINALS.items()):
        setattr(module, name, value)
    _ORIGINALS.clear()
    model_cls = mods["base_model"].FTTransformerHierModel
    pg_patch.remove_wide_batches(model_cls)
    pg_patch.remove_model(model_cls)
    pg_patch.remove_month_map()


def warm_start_matching(model, path):
    """Copy into `model` every tensor of the checkpoint at `path` whose name and shape are the model's own, and
    leave the rest of the model at its initial values. Returns the lines that say what happened: per part of the
    model, how many of its weights were taken, and what of the checkpoint found no place.

    The two models must read the same fields in the same order with the same fitted preprocessing: the tables of
    the code fields are found by position, so another field list would put a table under another field without any
    sign. Where both models record their inputs (input_contract), the column lists, the code counts and the fitted
    preprocessing are compared, and a difference stops the run. The loss's own weights are never taken: they
    belong to this run's settings."""
    import torch
    ckpt = torch.load(path, map_location="cpu", weights_only=False)
    theirs = (ckpt.get("hyper_parameters") or {}).get("input_contract")
    ours = dict(getattr(model, "hparams", {}) or {}).get("input_contract")
    compared = "the two models' inputs could not be compared (no input record in one of them)"
    if theirs and ours:
        text = lambda v: json.dumps(v, sort_keys=True, default=str)
        different = [k for k in ("continuous_columns", "categorical_columns", "categorical_cardinality",
                                 "artifacts_sha256") if text(dict(theirs).get(k)) != text(dict(ours).get(k))]
        if different:
            raise SystemExit(f"--init-from-matching: {path} does not read the same inputs as this model "
                             f"(different: {different}); its field tables would land under other fields. Nothing was "
                             "started. Leave the option out to start from nothing")
        compared = "the two models read the same fields with the same fitted preprocessing"
    state = ckpt["state_dict"]
    own = model.state_dict()
    taken = {k: v for k, v in state.items()
             if k in own and tuple(v.shape) == tuple(own[k].shape) and not k.startswith("loss_fn.")}
    model.load_state_dict(taken, strict=False)
    part = lambda name: name.split(".")[0]  # the model's top-level part a tensor belongs to
    parts = {}
    for name, tensor in own.items():
        got, total = parts.get(part(name), (0, 0))
        parts[part(name)] = (got + (int(tensor.numel()) if name in taken else 0), total + int(tensor.numel()))
    unused = sorted({part(k) for k in state if k not in taken})
    weights, total = sum(g for g, _ in parts.values()), sum(t for _, t in parts.values())
    lines = [f"warm start from {path}: {len(taken)} of {len(own)} tensors taken, {weights:,} of {total:,} weights; "
             + compared,
             "warm start, weights taken per part: "
             + "; ".join(f"{name} {got:,} of {all_:,}" for name, (got, all_) in parts.items())
             + (f" | parts of the checkpoint with tensors that found no place: {unused}" if unused else "")]
    if not taken:
        lines.append("warm start: NOTHING MATCHED: this run starts from scratch")
    return "\n".join(lines)


def _local_subclass(builder_cls):
    """The given builder reading local files: no S3 filesystem."""
    return type(builder_cls.__name__, (builder_cls,), {"_ensure_fs": lambda self: None})


def install(a, s, mods, out_dir, rest, cfg):
    trainer = mods["trainer"]
    base_builder = mods["chunk_builder"].SequenceBuilder
    numbers = read_files_list(a.files_list) if a.files_list else None
    s["files"] = numbers
    use_builder = pg_patch.data_side_on(s) or numbers or a.local_dir

    if use_builder:
        cls = pg_patch.builder_class(base_builder, s)
        original_make = trainer.make_dataset

        def make_dataset(cfg_, files, artifacts, features, dt_config, shuffle, stride, builder_cls=None,
                         batch_size=None, **extra):
            if shuffle:  # the training set (validation is built with shuffle off)
                if numbers:
                    files = pg_layout.file_paths(a.local_dir or cfg_.data.train_base, numbers)
                elif a.local_dir:
                    files = [os.path.join(a.local_dir, os.path.basename(f)) for f in files]
                if builder_cls is None:
                    builder_cls = cls
                elif a.local_dir:
                    builder_cls = _local_subclass(builder_cls)  # training on target-ending windows, local files
                print(f"training files: {len(files)} ({files[0]} ... {files[-1]})", flush=True)
            kw = dict(extra)
            if builder_cls is not None:
                kw["builder_cls"] = builder_cls
            if batch_size is not None:
                kw["batch_size"] = batch_size
            return original_make(cfg_, files, artifacts, features, dt_config, shuffle, stride, **kw)

        _replace(trainer, "make_dataset", make_dataset)

    model_cls = mods["base_model"].FTTransformerHierModel
    pg_patch.apply_model(s, model_cls)
    pg_patch.install_wide_batches(model_cls)  # after apply_model: the parts are cut before the program's forward

    # No row limits: the trainer's batch plan no longer demands a window cap or checks batch x width against the
    # 65,535-row limit (wide batches run in parts); it is still recorded in the manifest.
    if hasattr(trainer, "check_batch_plan"):
        original_plan = trainer.check_batch_plan

        def check_batch_plan(cfg_):
            if not bool(cfg_.sequence.get("predict_every_transaction", False)):
                return original_plan(cfg_)
            cap = cfg_.sequence.get("max_window_rows", None)
            return {"batch_chunks": int(cfg_.training.batch_size),
                    "max_window_rows": None if cap is None else int(cap),
                    "eval_batch_windows": int(cfg_.training.get("eval_batch_size", None) or cfg_.training.batch_size),
                    "accumulate_grad_batches": int(cfg_.training.get("accumulate_grad_batches", 1)),
                    "wide_batches": f"run in parts of at most {pg_patch.PART_ROWS} transactions"}

        _replace(trainer, "check_batch_plan", check_batch_plan)

    month_fields = list((cfg.get("datetime") or {}).get("fields") or [])
    if s.get("month_map") and month_fields and "month" not in month_fields:
        s["month_map"] = None
        print("month: the config derives no month (datetime.fields has none), so there is nothing to switch off",
              flush=True)
    if s.get("month_map"):
        # before any data set is built: the loader workers start from this process and carry the change with them
        if not pg_patch.install_month_map(s["month_map"]):
            raise SystemExit("--no-month: the project's date step (fraud.data.datetime_features) has no "
                             "_extract_field, so the month cannot be switched off here; nothing was started")
        print("month: switched off for this run (every row is read with the same month, so the model cannot use "
              "it); the setting is saved in the checkpoints, and pg_score.py and pg_export.py apply it by "
              "themselves", flush=True)

    if a.init_from or a.init_from_matching:
        import torch
        original_build = trainer.build_sequential_model

        def build_sequential_model(cfg_, dataset):
            model = original_build(cfg_, dataset)
            if "--resume" in rest:
                return model
            if a.init_from:
                state = torch.load(a.init_from, map_location="cpu", weights_only=False)["state_dict"]
                model.load_state_dict(state)
                print(f"warm start from {a.init_from}", flush=True)
            else:
                print(warm_start_matching(model, a.init_from_matching), flush=True)
            return model

        _replace(trainer, "build_sequential_model", build_sequential_model)

    import pg_callbacks
    callbacks, extra = [], {}
    if s.get("month_map"):
        callbacks.append(pg_callbacks.MonthOffCheck(pg_patch.month_rows_seen))
    if a.profile_steps is not None:
        callbacks.append(pg_callbacks.StepProfile(out_dir, a.profile_steps))
    if a.ema_decay:
        callbacks.append(pg_callbacks.EmaWeights(out_dir, a.ema_decay))
    if a.keep_near_update:
        callbacks.append(pg_callbacks.NearUpdateCheckpoint(out_dir, a.keep_near_update))
    plan = s.get("lr_plan") or {}
    if plan.get("hours"):
        callbacks.append(pg_callbacks.ClockPlan(out_dir, plan["hours"], plan["warmup"], plan["cooldown_share"]))
    elif plan:
        callbacks.append(pg_callbacks.LearningRateReport())
    if a.grad_clip:
        extra["gradient_clip_val"] = float(a.grad_clip)
    if a.val_every_updates:
        accumulate = int(cfg.training.get("accumulate_grad_batches", 1))
        for x in rest:
            if x.startswith("training.accumulate_grad_batches="):
                accumulate = int(x.split("=", 1)[1])
        extra["val_check_interval"] = int(a.val_every_updates) * accumulate
        extra["check_val_every_n_epoch"] = None
        callbacks.append(pg_callbacks.PlateauEveryValidation())
        # last.ckpt is then written at validations, inside an epoch; epoch_end.ckpt is the state at the end of the
        # latest whole epoch, the one a resume continues from (the training stream restarts at an epoch's start)
        callbacks.append(pg_callbacks.EpochEndCheckpoint(out_dir))
    if a.limit_val_batches is not None:
        extra["limit_val_batches"] = int(a.limit_val_batches)
    if a.max_steps:
        extra["max_steps"] = int(a.max_steps)
    if callbacks or extra:
        original_build_trainer = trainer.build_trainer

        def build_trainer(cfg_, cbs):
            real = trainer.pl
            trainer.pl = _TrainerArgs(real, extra, callbacks)
            try:
                return original_build_trainer(cfg_, cbs)
            finally:
                trainer.pl = real

        _replace(trainer, "build_trainer", build_trainer)

    # A resume continues the run even when project files were added or changed since it started. What differs from
    # the start is printed instead of stopping the run.
    if hasattr(trainer, "check_resume_config"):
        original_config_check = trainer.check_resume_config

        def check_resume_config(cfg_, start_config_path):
            try:
                original_config_check(cfg_, start_config_path)
            except ValueError as exc:
                print(f"note: the configuration differs from the run's start: {exc}", flush=True)

        _replace(trainer, "check_resume_config", check_resume_config)
    if hasattr(trainer, "check_resume_identity"):
        def check_resume_identity(identity, manifest, last, expected_policy):
            started = (manifest.get("start") or {}).get("identity", {})
            changed = sorted(k for k in identity if started.get(k) != identity[k])
            if changed:
                print(f"note: since the run started these changed: {changed} (the run continues)", flush=True)
            import torch
            saved = torch.load(last, map_location="cpu", weights_only=False).get("validation_policy")
            if saved != expected_policy:
                print(f"note: the validation policy differs from the checkpoint's: {saved} -> {expected_policy}",
                      flush=True)

        _replace(trainer, "check_resume_identity", check_resume_identity)

    # A resumed run's metrics file keeps the rows up to the checkpoint's update count (a run that validates inside
    # epochs has rows from the epoch it resumes in).
    csv_cls = getattr(trainer, "ResumableCSVMetrics", None)
    if csv_cls is not None:
        def on_train_start(self, trainer_, pl_module):
            import csv as _csv
            if not os.path.isfile(self.path):
                return
            with open(self.path, newline="") as f:
                reader = _csv.DictReader(f)
                self.fieldnames = reader.fieldnames
                kept = [row for row in reader if int(float(row["step"])) <= int(trainer_.global_step)]
            with open(self.path, "w", newline="") as f:
                writer = _csv.DictWriter(f, fieldnames=self.fieldnames)
                writer.writeheader()
                writer.writerows(kept)

        _replace(csv_cls, "on_train_start", on_train_start)

    # With the plateau scheduler on valid_ap, the step a resume replays uses valid_ap too.
    plateau_cls = getattr(trainer, "PlateauResumeCallback", None)
    if plateau_cls is not None and s["plateau_monitor"] == "valid_ap":
        def state_dict(self):
            metrics = self._trainer.callback_metrics if self._trainer is not None else {}
            value = metrics.get("valid_ap")
            return {"plateau_metric": None if value is None else float(value)}

        _replace(plateau_cls, "state_dict", state_dict)


SAVED = "program_settings.json"
NOT_CARRIED = ("profile_steps", "init_from", "init_from_matching")  # options of one start, never of a resume


def resume_options(a, out_dir):
    """On a resume: with no option given, the run's own options from its start; with options given, those, and the
    differences from the start are printed."""
    path = os.path.join(out_dir, SAVED)
    if not os.path.isfile(path):
        return a
    saved = json.load(open(path)).get("options") or {}
    given = {k: v for k, v in vars(a).items() if v not in (None, False)}
    if not given:
        merged = dict(vars(a))
        merged.update({k: v for k, v in saved.items() if k in merged and k not in NOT_CARRIED})
        print(f"resume: using the run's own options from its start: "
              f"{ {k: v for k, v in merged.items() if v not in (None, False)} or 'none'}", flush=True)
        return argparse.Namespace(**merged)
    diff = {k: (saved.get(k), v) for k, v in vars(a).items()
            if k not in NOT_CARRIED and saved.get(k) != v}
    if diff:
        print(f"note: options differ from the run's start (start, now): {diff}", flush=True)
    return a


def resume_from_whole_epoch(out_dir):
    """A run that validates inside epochs: resume from the end of its latest whole epoch."""
    import shutil
    import torch
    last, end = os.path.join(out_dir, "last.ckpt"), os.path.join(out_dir, "epoch_end.ckpt")
    if not os.path.isfile(last):
        return
    if not os.path.isfile(end):
        print("note: no whole epoch has finished yet; the resume repeats the batches of the current epoch that "
              "were already trained", flush=True)
        return
    step_last = torch.load(last, map_location="cpu", weights_only=False).get("global_step")
    step_end = torch.load(end, map_location="cpu", weights_only=False).get("global_step")
    if step_last != step_end:
        shutil.move(last, os.path.join(out_dir, "last_mid_epoch.ckpt"))
        shutil.copyfile(end, last)
        print(f"resume: from the end of the latest whole epoch (update {step_end}); the checkpoint at update "
              f"{step_last} is kept as last_mid_epoch.ckpt", flush=True)


def move_scoring_records(out_dir, trainer, back=False):
    """A scored or exported run can be resumed: its records move under *_before_resume (and back if the trainer
    does not accept the resume)."""
    manifest = os.path.join(out_dir, getattr(trainer, "MANIFEST", "run_manifest_v2.json"))
    if not os.path.isfile(manifest):
        return []
    with open(manifest, encoding="utf-8") as f:
        m = json.load(f)
    moved = []
    for k in ("scored", "exported"):
        if back and m.get(f"{k}_before_resume") and not m.get(k):
            m[k] = m.pop(f"{k}_before_resume")
            moved.append(k)
        elif not back and m.get(k):
            m[f"{k}_before_resume"] = m.get(f"{k}_before_resume", []) + list(m.pop(k))
            moved.append(k)
    if moved:
        with open(manifest, "w", encoding="utf-8") as f:
            json.dump(m, f, indent=2, sort_keys=True, default=str)
    return moved


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    ours, rest = split_argv(argv)
    a = parser().parse_args(ours)
    outs = [x for x in rest if x.startswith(OUT_PREFIX)]
    if len(outs) != 1 or "--config" not in rest:
        print("error: give --config and exactly one output.checkpoint_dir=... after --", file=sys.stderr)
        return 2
    out_dir = outs[0][len(OUT_PREFIX):].strip()
    resuming = "--resume" in rest
    if resuming:
        a = resume_options(a, out_dir)
    if a.limit_val_batches is not None and a.limit_val_batches < 1:
        print("error: --limit-val-batches is a number of validation batches, 1 or more", file=sys.stderr)
        return 2
    lr_plan = None
    if a.train_hours is not None:
        warmup = int(a.lr_warmup_updates or 0)
        share = 0.2 if a.lr_cooldown_share is None else float(a.lr_cooldown_share)
        if a.max_steps:
            print("error: --train-hours ends the run by the clock and --max-steps by a number of updates: give one "
                  "of the two", file=sys.stderr)
            return 2
        if not a.train_hours > 0 or not 0 < share <= 1 or warmup < 0:
            print("error: --train-hours is above 0, --lr-cooldown-share is above 0 and at most 1, and "
                  "--lr-warmup-updates is 0 or more", file=sys.stderr)
            return 2
        lr_plan = {"hours": float(a.train_hours), "warmup": warmup, "cooldown_share": share}
        # only the clock ends such a run: no early stopping, and a new pass when the file list ends first
        for key, value in (("training.max_epochs", 1000), ("training.early_stopping_patience", 100000)):
            if not any(x.startswith(key + "=") for x in rest):
                rest = with_override(rest, f"{key}={value}")
                print(f"clock plan: {key}={value} added, so that only the clock ends the run", flush=True)
    elif a.lr_warmup_updates is not None or a.lr_cooldown_share is not None:
        warmup = int(a.lr_warmup_updates or 0)
        share = 0.2 if a.lr_cooldown_share is None else float(a.lr_cooldown_share)
        if not a.max_steps:
            print("error: the learning-rate plan needs the length of the run: give --max-steps or --train-hours",
                  file=sys.stderr)
            return 2
        if not 0 < share <= 1 or warmup < 0 or warmup >= int(a.max_steps):
            print("error: --lr-cooldown-share is above 0 and at most 1, and --lr-warmup-updates is 0 or more and "
                  "below --max-steps", file=sys.stderr)
            return 2
        lr_plan = {"max_steps": int(a.max_steps), "warmup": warmup, "cooldown_share": share}
    kw = dict(local_dir=a.local_dir, loss_mask=a.loss_mask, decline_col=a.decline_col, advice_col=a.advice_col,
              recency_half_life_months=a.recency_half_life, clean_account_share=a.clean_account_share,
              sample_seed=a.sample_seed, prefix_seconds=a.prefix_seconds, prefix_max_rows=a.prefix_max_rows,
              loss=a.loss, focal_gamma=a.focal_gamma, plateau_monitor=a.plateau_monitor)
    if a.keep_fraud_account_negatives:
        kw["mask_fraud_account_negatives"] = False
    if a.inverse_negative_weight:
        kw["negative_weight"] = "inverse"
    s = pg_patch.settings_from(**kw)
    if a.val_every_updates:
        s["scheduler_every_updates"] = int(a.val_every_updates)
    s["lr_plan"] = lr_plan
    if a.no_month and a.keep_month:
        print("error: --no-month switches the month off and --keep-month keeps it: give one of the two", file=sys.stderr)
        return 2
    # a model trained with the month switched off is continued the same way: on real months, only January's value
    # of its month input was ever trained
    source = os.path.join(out_dir, "last.ckpt") if resuming else (a.init_from or a.init_from_matching)
    inherited = pg_patch.checkpoint_month_map(source) if source and os.path.isfile(source) else {}
    if inherited and not a.no_month:
        if a.keep_month:
            print(f"note: {source} was trained with the month switched off; --keep-month trains this run on real "
                  "months all the same", flush=True)
        else:
            a.no_month = True
            print(f"month: {source} was trained with the month switched off, so this run switches it off too "
                  "(--keep-month would train it on real months)", flush=True)
    s["month_map"] = pg_patch.no_month_map() if a.no_month else None
    if a.init_from and a.init_from_matching:
        print("error: give --init-from (every weight, the same shape) or --init-from-matching (what fits), not both",
              file=sys.stderr)
        return 2
    layout, mods = pg_layout.resolve(roles=("base_model", "target_ending_model", "trainer", "chunk_builder"))
    cfg = trainer_config(rest)
    if bool(cfg.sequence.get("train_target_ending", False)) and (pg_patch.data_side_on(s) or s["loss"] != "ce"):
        print("error: loss masks, sampling, recency weights, the context prefix and focal loss apply to chunk "
              "training; this config trains on target-ending windows (sequence.train_target_ending)", file=sys.stderr)
        return 2
    window_caps(cfg, s, a.prefix_max_rows)
    rest = with_override(rest, NO_CHUNK_LIMIT)
    os.makedirs(out_dir, exist_ok=True)
    if resuming and a.val_every_updates:
        resume_from_whole_epoch(out_dir)
    install(a, s, mods, out_dir, rest, cfg)
    record = {"layout": layout, "settings": s, "options": vars(a), "trainer_args": rest}
    name = SAVED
    if resuming and os.path.isfile(os.path.join(out_dir, SAVED)):
        k = 1
        while os.path.isfile(os.path.join(out_dir, f"program_settings.resume{k}.json")):
            k += 1
        name = f"program_settings.resume{k}.json"
    with open(os.path.join(out_dir, name), "w") as f:
        json.dump(record, f, indent=2, default=str)
    on = {k: v for k, v in vars(a).items() if v not in (None, False)}
    print(f"program training: layout {layout}; options {on or 'none (the trainer unchanged)'}; {outs[0]}",
          flush=True)
    moved = move_scoring_records(out_dir, mods["trainer"]) if resuming else []
    if moved:
        print(f"note: kept the run's earlier {' and '.join(moved)} records under *_before_resume", flush=True)
    try:
        rc = mods["trainer"].main(rest)
    except BaseException:
        if moved:
            move_scoring_records(out_dir, mods["trainer"], back=True)
        raise
    return int(rc or 0)


if __name__ == "__main__":
    sys.exit(main())
