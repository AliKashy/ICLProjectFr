"""Optional: a local copy of training files holding only the columns training reads, to cut reading time when the
step profile (pg_train.py --profile-steps) shows the GPU waiting for data most of the time.

Where it runs: on the pod, CPU only, writing to the workbench disk. Check free space first (df -h <out folder>);
--dry-run copies one file and prints the size of the full copy.

Columns kept: the inputs the predictors CSV lists (their raw sources), the label, account, time, transaction id and
amount, and --extra columns (for example predecline and transaction_advice_xcd for the loss masks). With
--clean-account-share S only every fraud account and a share S of the other accounts are copied, with the same
fixed draw pg_train.py uses (same --sample-seed), so a run on the copy sees exactly the accounts it would sample.

Usage:
    $PY program/pg_cache.py --config <the run's config> --files-list runs/program/files/files_100.txt \
        --out /path/on/workbench/disk/train_cache [--extra predecline transaction_advice_xcd] [--dry-run]
Then train with pg_train.py --files-list <the same list> --local-dir <out>.
"""
import argparse
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pg_layout  # noqa: E402
import pg_rows  # noqa: E402


def needed_columns(cfg, extra=()):
    from fraud.data.feature_list import load_feature_list
    fs = pg_layout.s3_filesystem(cfg.s3.get("cred_path")) if str(cfg.predictors.csv_path).startswith("s3") else None
    features = load_feature_list(cfg.predictors.csv_path, version=cfg.predictors.version, filesystem=fs)
    cols = list(features.raw_source_columns())
    for c in (cfg.data.target_col, cfg.data.account_col, cfg.data.order_col, cfg.data.get("tie_break_col", None),
              cfg.data.get("amount_col", None), *extra):
        if c and c not in cols:
            cols.append(c)
    return cols


def sample_accounts(df, account_col, target_col, share, seed):
    import pg_patch
    acct = df[account_col].map(str).to_numpy()
    fraud = set(acct[pd.to_numeric(df[target_col], errors="coerce").to_numpy() == 1].tolist())
    uniq = np.unique(acct)
    keep = fraud | set(uniq[pg_patch.uniform_hash(uniq, seed) < share].tolist())
    return df[np.isin(acct, list(keep))]


def main(argv=None):
    ap = argparse.ArgumentParser(description="local copy of training files with the needed columns")
    ap.add_argument("--config", required=True)
    ap.add_argument("--files-list", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--extra", nargs="*", default=[])
    ap.add_argument("--clean-account-share", type=float, default=None)
    ap.add_argument("--sample-seed", type=int, default=20261106)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args(argv)
    from omegaconf import OmegaConf
    cfg = OmegaConf.load(a.config)
    import pg_train
    numbers = pg_train.read_files_list(a.files_list)
    cols = needed_columns(cfg, a.extra)
    fs = pg_layout.s3_filesystem(cfg.s3.get("cred_path")) if str(cfg.data.train_base).startswith("s3") else None
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    total, t0 = 0, time.time()
    for k, (n, path) in enumerate(zip(numbers, pg_layout.file_paths(cfg.data.train_base, numbers))):
        target = out / f"part_{n}.parquet"
        if target.is_file():
            total += target.stat().st_size
            continue
        df = pg_rows.read_columns(path, cols, fs)
        if a.clean_account_share is not None:
            df = sample_accounts(df, cfg.data.account_col, cfg.data.target_col, a.clean_account_share, a.sample_seed)
        tmp = out / f".part_{n}.parquet.tmp"
        df.to_parquet(tmp, index=False, compression="zstd")
        os.replace(tmp, target)
        total += target.stat().st_size
        if a.dry_run:
            print(f"one file: {target.stat().st_size / 1e6:.1f} MB, {len(df):,} rows; all {len(numbers)} files: about "
                  f"{target.stat().st_size * len(numbers) / 1e9:.1f} GB")
            return 0
        if k % 10 == 0:
            print(f"{k + 1}/{len(numbers)} files, {total / 1e9:.2f} GB, {time.time() - t0:.0f} s", flush=True)
    print(f"done: {len(numbers)} files, {total / 1e9:.2f} GB in {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
