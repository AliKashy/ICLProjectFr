"""Training variants for the chosen model, applied in memory by pg_train.py. No project file is edited.

Everything here is off by default; with every option off, training is exactly the trainer's own.

Data side (a subclass of the project's chunk builder, used for the training set only; validation and scoring keep
the project's target-ending windows):
- files: train on a given list of file numbers instead of the config's range; local_dir: read them from a local
  folder (part_<n>.parquet) instead of the config's base.
- loss_mask: declined rows and/or advice rows stay in every chunk as history but get no loss.
- recency_half_life_months H: each row's loss weight is 0.5 ** (months before the latest training month / H).
- clean_account_share s: every account with a fraud row in its file is kept, and a share s of the other accounts
  (a fixed draw per account). Inside the kept fraud accounts, non-fraud rows keep their loss with probability s too
  (mask_fraud_account_negatives, on by default with sampling), so every non-fraud row counts with the same
  probability. negative_weight "inverse" also gives the counted non-fraud rows weight 1/s, which restores the
  full-data balance of the loss (the debiased arm).
- prefix_seconds P: each chunk gets the account's rows of the P distinct seconds before it (at most prefix_max_rows
  rows; no limit when it is None) as read-only context: no loss on them. A banded mask then lets every row attend
  directly only to the rows its scoring window would hold: the history-length distinct earlier seconds and at most
  window-cap - 1 rows (band_seconds, band_rows; the training wrapper takes both from the config, and with no window
  cap in the config, band_rows and the prefix row limit are None: no row limit). This brings training closer to scoring
  but does not reproduce it exactly: a history row's position is its own count of visible rows, not its place in the
  target's window, and deeper layers carry context from before the window.

Wide batches: with no window cap, a batch can hold more transactions than stage 1 runs in one GPU call (65,535).
install_wide_batches runs such a batch in parts (widest windows together, each part cut to its widest window) and
puts the outputs back in batch order; every real row gets what one call would give it. Batches under the limit take
the model's own forward.

Loss side (the model's training step):
- per-row weights from the data side: loss = sum(w x CE) / sum(w) over the real rows of the batch. With all
  weights 1 this is the trainer's own sum(CE) / rows.
- loss "focal": CE x (1 - p_true) ** gamma, summed over the real rows and divided by their number (or by sum(w)
  with weights). gamma 0 gives the plain loss.
- plateau_monitor "valid_ap": the learning-rate plateau scheduler follows valid_ap (mode max) instead of valid_loss.
- lr_plan {max_steps, warmup, cooldown_share}: the learning rate follows a fixed plan over the run's updates instead
  of waiting for validation: a straight warm-up over `warmup` updates, the config's rate (the peak) until the
  cooldown starts, then peak x (1 - sqrt(progress)) over the last `cooldown_share` of `max_steps`, reaching 0 at the
  last update. It changes once per optimizer update. A run of one pass has too few epoch ends for the plateau rule
  to act, so without a plan such a run ends at the rate it started with.
- month_map {month: month to read it as}: with every month mapped to one value (no_month_map) the month is switched
  off: every row of training, validation, scoring and export is read with the same month. The map is saved in the
  checkpoints; pg_score.py and pg_export.py apply it by themselves.
- lr_plan {hours, warmup, cooldown_share}: the same plan laid out on the clock instead of on a number of updates.
  The run trains for `hours`; the cooldown is the last `cooldown_share` of the hours; the optimizer gets no
  scheduler, and pg_callbacks.ClockPlan sets the rate before every batch and stops the fit when the hours are over.
"""
import functools
import math

import numpy as np
import pandas as pd
import torch
from torch import nn

DEFAULTS = {
    "files": None, "local_dir": None,
    "loss_mask": [], "decline_col": "predecline", "decline_values": ["1", "1.0", "Y", "True", "true"],
    "advice_col": "transaction_advice_xcd",
    "recency_half_life_months": None,
    "clean_account_share": None, "mask_fraud_account_negatives": True, "negative_weight": "none",
    "sample_seed": 20261106,
    "prefix_seconds": 0, "prefix_max_rows": 31, "band_seconds": 20, "band_rows": 31,
    "loss": "ce", "focal_gamma": 2.0, "plateau_monitor": "valid_loss", "scheduler_every_updates": None,
    "lr_plan": None, "month_map": None,
}
CHECKPOINT_KEY = "program_settings"


def settings_from(**kw):
    s = dict(DEFAULTS)
    unknown = sorted(set(kw) - set(DEFAULTS))
    if unknown:
        raise ValueError(f"unknown training settings {unknown}")
    s.update({k: v for k, v in kw.items() if v is not None})
    s["loss_mask"] = sorted(set(s["loss_mask"] or []))
    for m in s["loss_mask"]:
        if m not in ("declines", "advice"):
            raise ValueError(f"loss_mask takes declines and advice, got {m}")
    share = s["clean_account_share"]
    if share is not None and not (0 < float(share) <= 1):
        raise ValueError(f"clean_account_share must be in (0, 1], got {share}")
    if s["negative_weight"] not in ("none", "inverse"):
        raise ValueError("negative_weight is none or inverse")
    if s["loss"] not in ("ce", "focal"):
        raise ValueError("loss is ce or focal")
    if s["plateau_monitor"] not in ("valid_loss", "valid_ap"):
        raise ValueError("plateau_monitor is valid_loss or valid_ap")
    s["prefix_seconds"] = int(s["prefix_seconds"] or 0)
    return s


def data_side_on(s):
    return bool(s["loss_mask"] or s["recency_half_life_months"] or s["clean_account_share"] is not None
                or s["prefix_seconds"] > 0)


def uniform_hash(values, seed):
    """A fixed number in [0, 1) per value (the same in every run and process for the same seed)."""
    key = f"{int(seed) % 10 ** 16:016d}"
    h = pd.util.hash_pandas_object(pd.Series(values, dtype=object).map(str), index=False, hash_key=key)
    return h.to_numpy(np.uint64).astype(np.float64) / float(2 ** 64)


def as_text(series):
    return series.map(lambda v: "" if v is None or (isinstance(v, float) and math.isnan(v)) else str(v).strip())


def flags(series, accepted):
    """True where the value is one of the accepted values (compared as text: 1, 1.0 and "1" all match "1")."""
    text = as_text(series)
    numeric = pd.to_numeric(text, errors="coerce")
    hit = text.isin([str(v) for v in accepted]).to_numpy()
    for v in accepted:
        try:
            hit |= (numeric == float(v)).to_numpy()
        except (TypeError, ValueError):
            pass
    return hit


def present(series):
    """True where the field holds any non-blank value (an advice row has a value in the advice field)."""
    return as_text(series).ne("").to_numpy()


def month_index(times):
    t = pd.to_datetime(pd.Series(times), utc=True)
    return (t.dt.year * 12 + t.dt.month - 1).to_numpy(np.int64)


def row_weights(df, target, s, account_col, order_col, id_col=None, latest_month=None):
    """(weights per row as float32, kept accounts as a set or None). Positions follow df's rows."""
    n = len(df)
    w = np.ones(n, dtype=np.float64)
    if "declines" in s["loss_mask"] and s["decline_col"] in df:
        w[flags(df[s["decline_col"]], s["decline_values"])] = 0.0
    if "advice" in s["loss_mask"] and s["advice_col"] in df:
        w[present(df[s["advice_col"]])] = 0.0
    if s["recency_half_life_months"]:
        months = month_index(df[order_col])
        ref = latest_month if latest_month is not None else int(months.max())
        w *= np.power(0.5, np.maximum(ref - months, 0) / float(s["recency_half_life_months"]))
    kept = None
    share = s["clean_account_share"]
    if share is not None and float(share) < 1:
        share = float(share)
        acct = df[account_col].map(str).to_numpy()
        fraud = np.asarray(target) == 1
        fraud_accounts = set(acct[fraud].tolist())
        uniq = np.unique(acct)
        u = uniform_hash(uniq, s["sample_seed"])
        kept = fraud_accounts | set(uniq[u < share].tolist())
        negative = ~fraud
        in_fraud_acct = np.isin(acct, list(fraud_accounts))
        if s["mask_fraud_account_negatives"]:
            if id_col and id_col in df:
                ident = df[id_col].map(str).to_numpy()
            else:
                ident = (pd.Series(acct) + ":" + pd.Series(np.arange(n)).map(str)).to_numpy()
            ur = uniform_hash(ident, s["sample_seed"] + 1)
            w[in_fraud_acct & negative & (ur >= share)] = 0.0
        if s["negative_weight"] == "inverse":
            # rows counted with probability `share` get 1/share: the clean accounts' rows, and the fraud accounts'
            # non-fraud rows when those are masked at the same share; rows always counted keep weight 1
            sampled = ~in_fraud_acct | bool(s["mask_fraud_account_negatives"])
            w[negative & (w > 0) & sampled] /= share
    return w.astype(np.float32), kept


def data_report(df, target, weights, kept, s, account_col):
    """One line on what the data options did to one training file: how many rows the model reads, how many carry a
    loss, whether every fraud still does, and what each mask removed. A mask whose column is not in the data says so,
    because such a mask does nothing and nothing else would show it."""
    n = len(df)
    fraud = np.asarray(target) == 1
    acct = df[account_col].map(str).to_numpy()
    read = np.ones(n, dtype=bool) if kept is None else np.isin(acct, list(kept))
    counted = read & (np.asarray(weights) > 0)
    share = lambda mask: f"{int(mask.sum())} ({mask.sum() / max(n, 1):.1%})"
    parts = [f"{n} rows, {int(fraud.sum())} frauds", f"rows the model reads {share(read)}",
             f"rows with a loss {share(counted)}", f"frauds with a loss {int((counted & fraud).sum())} of {int(fraud.sum())}"]
    for name, col, hit in (("declines", s["decline_col"], lambda c: flags(c, s["decline_values"])),
                           ("advice", s["advice_col"], present)):
        if name in s["loss_mask"]:
            parts.append(f"{name} rows without a loss {share(hit(df[col]))}" if col in df else
                         f"NO column '{col}' in the data, so the {name} mask did nothing")
    if kept is not None:
        accounts = len(np.unique(acct))
        parts.append(f"accounts kept {len(kept)} of {accounts} at share {s['clean_account_share']}")
    return "program data options, first training file of this worker: " + "; ".join(parts)


# ---------------------------------------------------------------------------------------------- data side
def builder_class(base_cls, s):
    """A subclass of the project's chunk builder carrying the data-side settings."""

    class ProgramChunkBuilder(base_cls):
        program_settings = s
        _reported = False  # the data options are reported once, for the first training file a worker reads

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            extra = []
            if "declines" in s["loss_mask"]:
                extra.append(s["decline_col"])
            if "advice" in s["loss_mask"]:
                extra.append(s["advice_col"])
            self._read_cols = self._read_cols + [c for c in extra if c not in self._read_cols]
            self._pg_on = data_side_on(s)

        def _ensure_fs(self):
            if s["local_dir"]:
                return None
            return super()._ensure_fs()

        def _chunks_for_file(self, cont, cat, target, times, df, meta):
            if not self._pg_on:
                yield from super()._chunks_for_file(cont, cat, target, times, df, meta)
                return
            weights, kept = row_weights(df, target, s, self.account_col, self.order_col, self.tie_break_col)
            if not self._reported:
                self._reported = True
                print(data_report(df, target, weights, kept, s, self.account_col), flush=True)
            n_cont, K = cont.shape[1], cat.shape[1]
            C = n_cont + int(self.time_delta)
            order_key = df[self.order_col].to_numpy(dtype="datetime64[ns]").astype("int64")
            prefix = int(s["prefix_seconds"])
            prefix_rows = None if s["prefix_max_rows"] is None else int(s["prefix_max_rows"])
            for acct, rows in self._account_groups(df).items():
                if kept is not None and str(acct) not in kept:
                    continue
                rows = np.asarray(rows, dtype=np.int64)
                secs = times[rows]
                second_index = np.cumsum(np.r_[True, secs[1:] != secs[:-1]]) - 1 if len(rows) else secs
                for start, end in self._chunk_spans(secs):
                    n_own = end - start
                    if self.max_chunk_rows is not None and n_own > self.max_chunk_rows:
                        raise ValueError(f"strict chunk of account {acct!r} holds {n_own} rows > max_chunk_rows="
                                         f"{self.max_chunk_rows}; raise the cap or measure the data")
                    lo = start
                    if prefix > 0 and start > 0:
                        first_second = max(int(second_index[start]) - prefix, 0)
                        lo = int(np.searchsorted(second_index, first_second, side="left"))
                        if prefix_rows is not None:
                            lo = max(lo, start - prefix_rows)
                    chunk_rows = rows[lo:end]
                    n = len(chunk_rows)
                    width = max(self.T, n)
                    w_cont = np.zeros((width, C), dtype=np.float32)
                    w_cat = np.zeros((width, K), dtype=np.int64)
                    w_mask = np.zeros(width, dtype=bool)
                    labels = np.full(width, -100, dtype=np.int64)
                    w_cont[:n, :n_cont] = cont[chunk_rows]
                    w_cat[:n] = cat[chunk_rows]
                    w_mask[:n] = True
                    labels[:n] = target[chunk_rows]
                    w_time = np.zeros(width, dtype=np.int64)
                    w_time[:n] = order_key[chunk_rows]
                    if n > 1 and (np.diff(w_time[:n]) < 0).any():
                        raise ValueError("Chunk timestamps are not chronological")
                    if self.time_delta and n > 1:
                        w_cont[1:n, n_cont] = np.log1p(self._chunk_gaps(times[chunk_rows], w_time[:n]))
                    w_weight = np.zeros(width, dtype=np.float32)
                    w_weight[:n] = weights[chunk_rows]
                    w_weight[:start - lo] = 0.0  # context rows: history only, no loss
                    seq_meta = None
                    if meta is not None:
                        seq_meta = {key: np.full(width, None, dtype=object) for key in meta}
                        for key in seq_meta:
                            seq_meta[key][:n] = meta[key][chunk_rows]
                    yield w_cont, w_cat, w_mask, None, seq_meta, labels, w_time, w_weight

        @staticmethod
        def _pad_chunks(chunk):
            if chunk and len(chunk[0]) == 8:
                padded = base_cls._pad_chunks([w[:7] for w in chunk])
                return [p + (w[7],) for p, w in zip(padded, chunk)]
            return base_cls._pad_chunks(chunk)

        def _emit_batches(self, buffer):
            eight = bool(buffer) and len(buffer[0]) == 8
            bs = self.batch_size
            for k, out in enumerate(super()._emit_batches(buffer)):
                if eight:
                    part = buffer[k * bs:(k + 1) * bs]  # the parent shuffled buffer in place before its first batch
                    width = out["mask"].shape[1]
                    out["loss_weight"] = torch.from_numpy(
                        np.stack([np.pad(w[7], (0, width - len(w[7]))) for w in part]))
                    if s["prefix_seconds"] > 0:
                        out["context_prefix"] = torch.ones(len(part), dtype=torch.bool)
                yield out

    ProgramChunkBuilder.__name__ = ProgramChunkBuilder.__qualname__ = "ProgramChunkBuilder"
    return ProgramChunkBuilder


# ---------------------------------------------------------------------------------------------- model side
def band_visible(times, mask, band_seconds, band_rows):
    """[batch, row i, row j] True when row j is in row i's scoring window: real, strictly earlier, among the
    band_seconds distinct seconds before i's second, and among the band_rows rows before i's second (no row limit
    when band_rows is None)."""
    mask = mask.to(torch.bool)
    times = times.to(device=mask.device, dtype=torch.long)
    sec = torch.div(times, 10 ** 9, rounding_mode="floor")
    B, W = mask.shape
    new_sec = torch.ones_like(mask)
    new_sec[:, 1:] = sec[:, 1:] != sec[:, :-1]
    new_sec &= mask
    ordinal = torch.cumsum(new_sec.long(), dim=1) - 1
    idx = torch.arange(W, device=mask.device).unsqueeze(0).expand(B, W)
    group_start = torch.cummax(torch.where(new_sec, idx, torch.zeros_like(idx)), dim=1).values
    earlier = (times.unsqueeze(1) < times.unsqueeze(2)) & mask.unsqueeze(1) & mask.unsqueeze(2)
    within = (ordinal.unsqueeze(2) - ordinal.unsqueeze(1)) <= int(band_seconds)
    if band_rows is None:  # no window cap in the config: every row of those seconds is visible
        return earlier & within
    capped = idx.unsqueeze(1) >= (group_start.unsqueeze(2) - int(band_rows))
    return earlier & within & capped


def focal_terms(logits, y, gamma, weight=None):
    ce = nn.functional.cross_entropy(logits.float(), y, weight=weight, reduction="none")
    if gamma:
        p_true = torch.softmax(logits.float(), dim=-1).gather(1, y.unsqueeze(1)).squeeze(1)
        ce = ce * torch.pow((1.0 - p_true).clamp(min=0.0), float(gamma))
    return ce


_PATCHED = {}


def parse_month_map(items):
    """["6=5"] -> {6: 5}: rows of month 6 are read as month 5. Months are 1 to 12."""
    out = {}
    for item in items or []:
        parts = str(item).split("=")
        if len(parts) != 2 or not all(x.strip().isdigit() for x in parts):
            raise ValueError(f"a month map entry is <month>=<month to read it as>, for example 6=5; got {item!r}")
        a, b = int(parts[0]), int(parts[1])
        if not (1 <= a <= 12 and 1 <= b <= 12):
            raise ValueError(f"months are 1 to 12, got {item!r}")
        out[a] = b
    return out


NO_MONTH_VALUE = 1  # the month every row is read with when the month is switched off (January: a trained value)


def no_month_map():
    """The map that switches the month off: every month is read as the same one, so the month input is the same
    for every row and the model cannot use it."""
    return {m: NO_MONTH_VALUE for m in range(1, 13)}


def month_is_off(mapping):
    """True when the map gives every month of the year the same value."""
    mapping = {int(k): int(v) for k, v in (mapping or {}).items()}
    return set(mapping) == set(range(1, 13)) and len(set(mapping.values())) == 1


def month_map_text(mapping):
    mapping = {int(k): int(v) for k, v in (mapping or {}).items()}
    if month_is_off(mapping):
        return f"every month as {next(iter(mapping.values()))}: the month is switched off"
    return ", ".join(f"{a} as {b}" for a, b in sorted(mapping.items()))


_MONTH = {}


def install_month_map(mapping):
    """From here on, the month input of rows of the given months is another month.

    Two uses. At scoring and export of a model trained with the month: {6: 5} reads June rows as May. In training,
    scoring and export alike with no_month_map(): every row is read with the same month, which switches the month
    off without a new predictor list or a new preprocessing artifact (the month field stays in the model as one
    token that is the same for every row).

    Why: a model trained on October to May has never seen the month of a June row; that row's month then enters as
    the value kept for unknown codes, which no training row ever used. With {6: 5} a June row is read with the last
    month the model was trained on. Only the month changes: day, hour and day of week stay the row's own, and so do
    the row's time and its place in its account's history.

    How: the project derives the calendar inputs in fraud.data.datetime_features, which takes each field from the
    timestamp in _extract_field; that one function is wrapped, so every builder that derives the calendar inputs
    is covered, with the categorical and with the cyclical encoding. Returns False when the project's date step has
    no such function (nothing is changed then). remove_month_map puts the original back."""
    import importlib
    if not mapping:
        return False
    module = importlib.import_module("fraud.data.datetime_features")
    original = _MONTH.get("original") or getattr(module, "_extract_field", None)
    if original is None:
        return False
    mapping = {int(k): int(v) for k, v in mapping.items()}
    told = {"done": False}
    # rows whose month was derived under the map, counted across this process and the loader workers it starts
    # (shared memory): a run whose data never passes through the date step can then be told from one that does
    import multiprocessing
    seen = _MONTH.get("seen") or multiprocessing.Value("q", 0)

    def _extract_field(dt, field_name):
        values = original(dt, field_name)
        if field_name != "month":
            return values
        with seen.get_lock():
            seen.value += len(values)
        changed = values.isin(list(mapping))
        if not told["done"]:  # once per process: what the option did to the first file it saw
            told["done"] = True
            print(f"month option, first file of this process: {int(changed.sum()):,} of {len(values):,} rows read "
                  f"with another month ({month_map_text(mapping)})", flush=True)
        return values.replace(mapping) if bool(changed.any()) else values

    _MONTH.update(original=original, module=module, seen=seen)
    module._extract_field = _extract_field
    return True


def month_rows_seen(reset=False):
    """How many rows had their month derived under the installed map so far, in this process and its loader
    workers; 0 when no map is installed. With reset=True the count starts again from 0."""
    seen = _MONTH.get("seen")
    if seen is None:
        return 0
    with seen.get_lock():
        value = int(seen.value)
        if reset:
            seen.value = 0
    return value


def remove_month_map():
    """Undo install_month_map."""
    if _MONTH:
        _MONTH["module"]._extract_field = _MONTH["original"]
        _MONTH.clear()


def plan_factor(step, max_steps, warmup=0, cooldown_share=0.2):
    """The share of the peak learning rate at one optimizer update (the first update is update 0).

    Warm-up: equal rises over `warmup` updates, reaching 1 on the first update after them. Then 1 until the cooldown
    starts, at update max_steps x (1 - cooldown_share) (never before the end of the warm-up). In the cooldown the
    factor is 1 - sqrt(progress), with progress going from 0 to 1 at `max_steps`; from there on it stays 0. A share
    of 1 starts the cooldown right after the warm-up."""
    step, total, warm = int(step), int(max_steps), max(0, int(warmup))
    if step < warm:
        return (step + 1) / (warm + 1)
    if step >= total:
        return 0.0
    start = max(warm, int(round(total * (1.0 - float(cooldown_share)))))
    if step < start:
        return 1.0
    return 1.0 - math.sqrt((step - start) / (total - start))


def apply_model(s, model_cls):
    """Patch the base model class in memory (training step, mask, positions, plateau). Idempotent for equal
    settings; the target-ending subclass inherits it."""
    done = _PATCHED.get(model_cls)
    if done is not None:
        if done["settings"] != s:
            raise RuntimeError("the model class is already patched with other settings")
        return
    orig = {name: getattr(model_cls, name) for name in
            ("_step", "forward", "_build_causal_mask", "_checked_times", "configure_optimizers",
             "on_save_checkpoint")}
    gamma = float(s["focal_gamma"]) if s["loss"] == "focal" else 0.0
    prefix = int(s["prefix_seconds"])

    @functools.wraps(orig["_step"])
    def _step(self, batch, tag):
        weights = batch.get("loss_weight") if isinstance(batch, dict) else None
        if not self.hparams.predict_every_transaction or (weights is None and gamma == 0.0):
            return orig["_step"](self, batch, tag)
        logits = self(batch)
        labels, valid = batch["target_seq"], batch["mask"]
        if labels.shape != valid.shape or not torch.equal(labels != -100, valid):
            raise ValueError("Every real transaction must own exactly one target; padding must use -100")
        lg, y = logits[valid], labels[valid]
        if not y.numel():
            raise ValueError("An all-padding chunk cannot contribute a training/evaluation batch")
        terms = focal_terms(lg, y, gamma, self.loss_fn.weight)
        if weights is not None:
            wv = weights.to(device=terms.device, dtype=terms.dtype)[valid]
            total = wv.sum()
            loss = (terms * wv).sum() / total if float(total) > 0 else (terms * 0.0).sum()
        else:
            loss = terms.sum() / y.numel()
        self.log(f"{tag}_loss", loss, on_epoch=True, on_step=(tag == "train"), prog_bar=True, sync_dist=True,
                 batch_size=int(y.numel()))
        return lg, y, loss

    def _position_hook(module, inputs):
        idx = getattr(module, "program_index", None)
        if idx is None:
            return None
        module.program_index = None
        return (idx,)

    @functools.wraps(orig["forward"])
    def forward(self, batch):
        if prefix > 0 and isinstance(batch, dict) and "context_prefix" in batch:
            if not getattr(self, "_program_hook", None):
                self._program_hook = self.txn_position.register_forward_pre_hook(_position_hook)
            vis = band_visible(batch["time_seq"], batch["mask"], s["band_seconds"], s["band_rows"])
            self._program_visible = vis
            self.txn_position.program_index = vis.sum(-1).clamp(max=self.T - 1)
            try:
                return orig["forward"](self, batch)
            finally:
                self._program_visible = None
                self.txn_position.program_index = None
        return orig["forward"](self, batch)

    @functools.wraps(orig["_build_causal_mask"])
    def _build_causal_mask(self, device, key_padding=None, times=None):
        m = orig["_build_causal_mask"](self, device, key_padding, times)
        vis = getattr(self, "_program_visible", None)
        if vis is None or times is None or key_padding is None:
            return m
        B, W = vis.shape[0], vis.shape[1]
        L, heads = W + 1, int(self.hparams.num_heads)
        extra = torch.zeros(B, L, L, dtype=torch.bool, device=device)
        extra[:, 1:, 1:] = ~(vis.to(device) | torch.eye(W, dtype=torch.bool, device=device).unsqueeze(0))
        return m.view(B, heads, L, L).masked_fill(extra.unsqueeze(1), float("-inf")).view(B * heads, L, L)

    @functools.wraps(orig["_checked_times"])
    def _checked_times(self, batch, mask):
        if not (prefix > 0 and "context_prefix" in batch):
            return orig["_checked_times"](self, batch, mask)
        times = batch.get("time_seq")
        if times is None or times.shape != mask.shape:
            raise ValueError("Strict all-position mode needs batch['time_seq'] shaped like mask")
        times = times.to(device=mask.device, dtype=torch.long)
        both_real = mask[:, 1:] & mask[:, :-1]
        if bool((both_real & (times[:, 1:] < times[:, :-1])).any()):
            raise ValueError("time_seq is not chronological over the real positions of a chunk")
        sec = torch.div(times, 10 ** 9, rounding_mode="floor")
        seconds = mask[:, 0].long() + ((sec[:, 1:] != sec[:, :-1]) & both_real).sum(1)
        if bool((seconds > self.T + prefix).any()):
            raise ValueError("A chunk with its context holds more than history_len + 1 + prefix_seconds seconds")
        return times

    @functools.wraps(orig["configure_optimizers"])
    def configure_optimizers(self):
        out = orig["configure_optimizers"](self)
        if s.get("lr_plan"):
            # a fixed plan replaces the plateau rule: it needs no validation figure and changes at every update
            plan = s["lr_plan"]
            optimizer = out["optimizer"] if isinstance(out, dict) else out
            if plan.get("hours"):
                # planned by the clock: no scheduler; a callback of the training wrapper sets the rate before
                # every batch from the hours trained so far (pg_callbacks.ClockPlan)
                return {"optimizer": optimizer}
            sched = torch.optim.lr_scheduler.LambdaLR(
                optimizer, lambda step: plan_factor(step, plan["max_steps"], plan["warmup"], plan["cooldown_share"]))
            return {"optimizer": optimizer, "lr_scheduler": {"scheduler": sched, "interval": "step", "frequency": 1}}
        if not isinstance(out, dict) or "lr_scheduler" not in out:
            return out
        if s["plateau_monitor"] == "valid_ap":
            sched = torch.optim.lr_scheduler.ReduceLROnPlateau(out["optimizer"], patience=3, factor=0.5, mode="max")
            out["lr_scheduler"] = {"scheduler": sched, "monitor": "valid_ap", "strict": False}
        if s.get("scheduler_every_updates"):
            # validation every N updates: Lightning itself never steps the plateau scheduler (its step interval counts
            # batches within an epoch, not validations); a callback the training wrapper adds steps it once after
            # each validation, with the monitored value
            out["lr_scheduler"] = dict(out["lr_scheduler"], interval="epoch", frequency=10 ** 9, strict=False)
        return out

    @functools.wraps(orig["on_save_checkpoint"])
    def on_save_checkpoint(self, checkpoint):
        result = orig["on_save_checkpoint"](self, checkpoint)
        checkpoint[CHECKPOINT_KEY] = {k: v for k, v in s.items() if k not in ("files",)}
        checkpoint[CHECKPOINT_KEY]["training_files"] = len(s["files"]) if s["files"] else None
        return result

    model_cls._step, model_cls.forward = _step, forward
    model_cls._build_causal_mask, model_cls._checked_times = _build_causal_mask, _checked_times
    model_cls.configure_optimizers, model_cls.on_save_checkpoint = configure_optimizers, on_save_checkpoint
    _PATCHED[model_cls] = {"orig": orig, "settings": s}


def remove_model(model_cls):
    """Undo apply_model (used by the tests)."""
    done = _PATCHED.pop(model_cls, None)
    if done is not None:
        for name, fn in done["orig"].items():
            setattr(model_cls, name, fn)


# ------------------------------------------------------------------------------------------------ wide batches
LAUNCH_ROWS = 65535  # stage 1 cannot run this many transactions in one GPU call
PART_ROWS = 32768  # a wide batch runs in parts of at most this many transactions
PART_MASK_BYTES = 2 ** 30  # and of at most about 1 GB of stage 2 attention mask
_WIDE = {}


def batch_parts(lengths, width, floor, heads, trim, rows=None, mask_bytes=None):
    """[(window indexes, part width)] for one batch. With trim (all-position windows: real rows first, padding
    after) the windows go widest first and each part is cut to its widest window, at least `floor` rows; otherwise
    every part keeps the batch width. A part holds at most `rows` transactions and `mask_bytes` of stage 2 mask."""
    rows = PART_ROWS if rows is None else int(rows)
    mask_bytes = PART_MASK_BYTES if mask_bytes is None else int(mask_bytes)
    lengths = lengths.detach().cpu()
    B = int(lengths.shape[0])
    order = torch.sort(lengths, descending=True, stable=True).indices if trim else torch.arange(B)
    parts, i = [], 0
    while i < B:
        w = min(int(width), max(int(lengths[order[i]]), int(floor))) if trim else int(width)
        k = max(1, min(rows // w, mask_bytes // (heads * (w + 1) ** 2 * 4)))
        parts.append((order[i:i + k], w))
        i += k
    return parts


def install_wide_batches(model_cls):
    """Let the model take a batch of any width. A batch of LAUNCH_ROWS transactions or more, or with more stage 2
    mask than PART_MASK_BYTES, runs through the model in parts, and the outputs go back together in batch order
    before the head. Padding never reaches a real row, so each real row gets what one call would give it; in training
    the gradients flow through every part. Smaller batches take the model's own forward unchanged."""
    if model_cls in _WIDE:
        return
    orig = model_cls.forward

    @functools.wraps(orig)
    def forward(self, batch):
        mask = batch.get("mask") if isinstance(batch, dict) else None
        if mask is None or mask.dim() != 2:
            return orig(self, batch)
        B, W = mask.shape
        heads = int(self.hparams.num_heads)
        if B * W < LAUNCH_ROWS and B * heads * (W + 1) ** 2 * 4 <= PART_MASK_BYTES:
            return orig(self, batch)
        trim = bool(self.hparams.predict_every_transaction) and bool(getattr(self, "_strict_time_mask", False))
        parts = batch_parts(mask.sum(1), W, int(self.T), heads, trim)
        outs, cls = [], []
        # each part returns the head's input; the head then runs once on the whole batch
        hook = self.head.register_forward_hook(lambda module, inputs, output: inputs[0])
        try:
            for idx, w in parts:
                sub = {}
                for key, v in batch.items():
                    if torch.is_tensor(v) and v.dim() >= 1 and v.shape[0] == B:
                        v = v.index_select(0, idx.to(v.device))
                        if v.dim() >= 2 and v.shape[1] == W:
                            v = v[:, :w]
                    sub[key] = v
                outs.append(orig(self, sub))
                cls.append(getattr(self, "_cls", None))
        finally:
            hook.remove()
        back = torch.argsort(torch.cat([idx for idx, _ in parts]))
        if outs[0].dim() == 3:
            outs = [nn.functional.pad(o, (0, 0, 0, W - o.shape[1])) for o in outs]
        x = torch.cat(outs, 0).index_select(0, back.to(outs[0].device))
        if all(c is not None for c in cls):
            self._cls = torch.cat(cls, 0).index_select(0, back.to(cls[0].device))
        return self.head(x)

    model_cls.forward = forward
    _WIDE[model_cls] = {"orig": orig, "wrapper": forward}


def remove_wide_batches(model_cls):
    """Undo install_wide_batches (used by the tests)."""
    done = _WIDE.pop(model_cls, None)
    if done is not None and model_cls.forward is done["wrapper"]:
        model_cls.forward = done["orig"]
