# Program tools

The steps, the commands and the decision rules are in `PROGRAM.md` at the project root. Tests:
`$PY -m pytest -q tests/experiments/program` (CPU, about six minutes).

| Tool | Job | Runs on |
|---|---|---|
| `pg_train.py` | The trainer with the program's options (training files, loss masks, sampling, context prefix, focal loss, clipping, EMA, validation every N updates, kept checkpoint, warm start from all or from the matching weights of another model, the month switched off, step profile, a learning-rate plan over a number of updates or over a number of hours: `--train-hours`). No option set: the trainer with no row limits (no cap needed, wide batches run in parts) | GPU |
| `BEST_RUN.md` | The best configuration with the source of every choice, the one command that trains it, what the run leaves, how it is scored, and what to do when a run is cut | read first for the long run |
| `pg_best.py` | The one run: starts `pg_train.py` with every option of the best run for a number of hours (`--hours H`), the month switched off; `--init-from-matching CKPT` starts it from the current model's matching weights; `--print` shows the command | GPU |
| `pg_card.py` | One screen that says what a trained run is: updates, hours, the learning rate it ended on, fields, weights by part, blocks, validation, what was scored, files and config (`--features` lists the input names) | CPU |
| `pg_score.py` | The project's scorer with no row limits: the same arguments and scores, wide batches run in parts, the window cap is the config's. A checkpoint trained with the month switched off is scored the same way by itself; `--month-map 6=5` reads June rows with May as their month for a model that kept its month (both also in `pg_export.py`) | GPU |
| `pg_sweep.py` | The 12-trial tuning search with the 5-epoch drop rule, then the top 2 on RANK-A | GPU (runs), CPU (choose) |
| `pg_files.py` | Nested training-file lists (10, 35, 100, 250, 500) | anywhere |
| `pg_read.py` | Paired reads and the decision rules (one seed, three seeds, free settings, SELECT check, unpaired) | CPU |
| `pg_export.py` | Score and 48-number vector of every scored transaction, one scorer pass | GPU |
| `pg_derive.py` | PCA, the 47 coordinates the head ignores, strictly earlier 1/7/30-day account means | CPU |
| `pg_downstream.py` | One learner with different inputs (raw, score, vector, PFM embedding) and the ways of joining our score with 15298's (offset, flipped, two weights, joined) | CPU |
| `pg_store.py` | The embedding table and its point-in-time lookup | CPU |
| `pg_bench.py` | Our model against the real 15298 and PFM scores on the same transactions | CPU |
| `pg_diagnostics.py` | Optional: effective rank, CKA, Procrustes alignment, the 7-day probe | CPU |
| `pg_cache.py` | Optional: a local copy of training files with only the needed columns | CPU |
| `pg_patch.py`, `pg_callbacks.py` | The training options themselves (used by `pg_train.py`) | |
| `pg_layout.py`, `pg_ranked.py`, `pg_rules.py`, `pg_rows.py` | Finding the model code, the measures, the rules, the read's rows | |
