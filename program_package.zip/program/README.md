# Program tools

The steps, the commands and the decision rules are in `PROGRAM.md` at the project root. Tests:
`$PY -m pytest -q tests/experiments/program` (CPU, about a minute).

| Tool | Job | Runs on |
|---|---|---|
| `pg_train.py` | The trainer with the program's options (training files, loss masks, sampling, context prefix, focal loss, clipping, EMA, validation every N updates, kept checkpoint, warm start, step profile). No option set: the trainer unchanged | GPU |
| `pg_sweep.py` | The 12-trial tuning search with the 5-epoch drop rule, then the top 2 on RANK-A | GPU (runs), CPU (choose) |
| `pg_files.py` | Nested training-file lists (10, 35, 100, 250, 500) | anywhere |
| `pg_read.py` | Paired reads and the decision rules (one seed, three seeds, free settings, SELECT check, unpaired) | CPU |
| `pg_export.py` | Score and 48-number vector of every scored transaction, one scorer pass | GPU |
| `pg_derive.py` | PCA, the 47 coordinates the head ignores, strictly earlier 1/7/30-day account means | CPU |
| `pg_downstream.py` | One learner with different inputs (raw, score, vector, 15298 offset, PFM embedding) | CPU |
| `pg_store.py` | The embedding table and its point-in-time lookup | CPU |
| `pg_bench.py` | Our model against the real 15298 and PFM scores on the same transactions | CPU |
| `pg_diagnostics.py` | Optional: effective rank, CKA, Procrustes alignment, the 7-day probe | CPU |
| `pg_cache.py` | Optional: a local copy of training files with only the needed columns | CPU |
| `pg_patch.py`, `pg_callbacks.py` | The training options themselves (used by `pg_train.py`) | |
| `pg_layout.py`, `pg_ranked.py`, `pg_rules.py`, `pg_rows.py` | Finding the model code, the measures, the rules, the read's rows | |
