"""Callbacks pg_train.py adds to the trainer: the step profile, EMA weights, and the checkpoint kept nearest a given
update count.
"""
import csv
import json
import os
import shutil
import subprocess
import time
from contextlib import nullcontext

import numpy as np
import pytorch_lightning as pl
import torch


def _sync():
    if torch.cuda.is_available():
        torch.cuda.synchronize()


class StepProfile(pl.Callback):
    """Times every training step: the wait for the next batch (data loading and copy) and the step itself
    (forward, backward, optimizer). Samples GPU use with nvidia-smi once a second when it is installed. Stops the
    fit after `steps` steps (0: the whole fit) and writes profile.json in the run folder."""

    def __init__(self, out_dir, steps=0):
        self.out_dir, self.steps = out_dir, int(steps)
        self.waits, self.computes, self.rows, self.targets = [], [], [], []
        self._end = self._start = None
        self._smi = self._smi_file = None
        self._t0 = self._t_stop = None

    def on_train_start(self, trainer, pl_module):
        self._t0 = self._end = time.perf_counter()
        if shutil.which("nvidia-smi"):
            self._smi_file = open(os.path.join(self.out_dir, "gpu_samples.csv"), "w")
            self._smi = subprocess.Popen(["nvidia-smi", "--query-gpu=utilization.gpu,memory.used",
                                          "--format=csv,noheader,nounits", "-lms", "1000"],
                                         stdout=self._smi_file, stderr=subprocess.DEVNULL)

    def on_train_batch_start(self, trainer, pl_module, batch, batch_idx):
        _sync()
        self._start = time.perf_counter()
        if self._end is not None:
            self.waits.append(self._start - self._end)
        self.rows.append(int(batch["mask"].sum()))
        w = batch.get("loss_weight")
        self.targets.append(int((w > 0).sum()) if w is not None else int(batch["mask"].sum()))

    def on_train_batch_end(self, trainer, pl_module, outputs, batch, batch_idx):
        _sync()
        self._end = time.perf_counter()
        self.computes.append(self._end - self._start)
        if self.steps and len(self.computes) >= self.steps and self._t_stop is None:
            self._t_stop = time.perf_counter()  # the validation the stop triggers is not part of the profile
            self._stop_sampler()
            trainer.should_stop = True

    def on_train_end(self, trainer, pl_module):
        self.write()

    def _stop_sampler(self):
        if self._smi is not None:
            self._smi.terminate()
            self._smi.wait()
            self._smi_file.close()
            self._smi = None

    def write(self):
        self._stop_sampler()
        util, mem = [], []
        path = os.path.join(self.out_dir, "gpu_samples.csv")
        if os.path.isfile(path):
            for line in open(path):
                parts = [p.strip() for p in line.split(",")]
                if len(parts) >= 2 and parts[0].replace(".", "").isdigit():
                    util.append(float(parts[0]))
                    mem.append(float(parts[1]))
        wall = (self._t_stop or time.perf_counter()) - (self._t0 or time.perf_counter())
        # the first step (loader start-up, first CUDA work) is left out of every rate
        w, c = np.asarray(self.waits[1:] or [0.0]), np.asarray(self.computes[1:] or [0.0])
        timed = float(w.sum() + c.sum()) or 1e-9  # waits and steps only: validation passes are left out
        rec = {"steps": len(self.computes), "wall_seconds": wall,
               "mean_wait_seconds": float(w.mean()), "mean_step_seconds": float(c.mean()),
               "wait_share": float(w.sum() / max(w.sum() + c.sum(), 1e-9)),
               "rows_per_second": float(sum(self.rows[1:]) / timed),
               "targets_per_second": float(sum(self.targets[1:]) / timed),
               "gpu_util_mean": float(np.mean(util)) if util else None,
               "gpu_util_p10_p50_p90": [float(np.percentile(util, q)) for q in (10, 50, 90)] if util else None,
               "gpu_memory_mib_max": float(max(mem)) if mem else None}
        rec["reading"] = ("the GPU waits for data most of the time: a local copy of the training files "
                          "(pg_cache.py) or more loader workers should help" if rec["wait_share"] > 0.5 else
                          "the step itself dominates: the data loader keeps up")
        with open(os.path.join(self.out_dir, "profile.json"), "w") as f:
            json.dump(rec, f, indent=2)
        print("profile: " + json.dumps({k: (round(v, 4) if isinstance(v, float) else v) for k, v in rec.items()}),
              flush=True)


def target_slot_scores(logits, batch):
    """(probability, label) of the one target slot of each target-ending window."""
    labels = batch["target_seq"]
    selected = labels != -100
    slot = selected.float().argmax(1)
    rows = torch.arange(labels.shape[0], device=labels.device)
    prob = torch.softmax(logits[rows, slot].float(), dim=-1)[:, 1]
    return prob.detach().cpu().numpy(), labels[rows, slot].detach().cpu().numpy()


def validation_ap(trainer, pl_module):
    """AP of the module's current weights on the validation windows (the target slot of each window)."""
    from sklearn.metrics import average_precision_score
    loaders = trainer.val_dataloaders
    loader = loaders[0] if isinstance(loaders, (list, tuple)) else loaders
    ctx = getattr(trainer.precision_plugin, "forward_context", None)
    limit = trainer.limit_val_batches if isinstance(trainer.limit_val_batches, int) else None
    scores, ys = [], []
    was_training = pl_module.training
    pl_module.eval()
    with torch.no_grad():
        for b, batch in enumerate(loader):
            if limit is not None and b >= limit:
                break
            batch = {k: (v.to(pl_module.device) if torch.is_tensor(v) else v) for k, v in batch.items()}
            with (ctx() if ctx else nullcontext()):
                logits = pl_module(batch)
            p, y = target_slot_scores(logits, batch)
            scores.append(p)
            ys.append(y)
    if was_training:
        pl_module.train()
    y, s = np.concatenate(ys), np.concatenate(scores)
    return float(average_precision_score(y, s)) if 0 < y.sum() < len(y) else float("nan")


class EmaWeights(pl.Callback):
    """An exponential moving average of the weights, updated after every optimizer step (decay per update).

    At every validation the EMA weights are also validated (one more pass over the validation windows); their AP is
    written to ema_metrics.csv, and the best EMA weights are kept as best_ema.ckpt. Training, stopping, the schedule
    and best.ckpt stay on the raw weights. The EMA state is saved with each checkpoint, so a resume continues it."""

    def __init__(self, out_dir, decay=0.999):
        self.out_dir, self.decay = out_dir, float(decay)
        self.shadow = None
        self.best = -1.0
        self.updates = 0
        self._last_step = -1

    def _params(self, pl_module):
        return [p for p in pl_module.parameters() if p.requires_grad]

    def on_train_start(self, trainer, pl_module):
        if self.shadow is None:
            self.shadow = [p.detach().float().clone() for p in self._params(pl_module)]
        else:
            self.shadow = [s.to(p.device) for s, p in zip(self.shadow, self._params(pl_module))]

    def on_train_batch_end(self, trainer, pl_module, outputs, batch, batch_idx):
        if trainer.global_step == self._last_step:
            return  # gradient accumulation: no optimizer step yet
        self._last_step = trainer.global_step
        with torch.no_grad():
            for s, p in zip(self.shadow, self._params(pl_module)):
                s.mul_(self.decay).add_(p.detach().float(), alpha=1.0 - self.decay)
        self.updates += 1

    def _swap(self, pl_module):
        with torch.no_grad():
            for s, p in zip(self.shadow, self._params(pl_module)):
                tmp = p.detach().clone()
                p.copy_(s.to(p.dtype))
                s.copy_(tmp.float())

    def on_validation_end(self, trainer, pl_module):
        if trainer.sanity_checking or self.shadow is None:
            return
        self._swap(pl_module)  # EMA weights in, raw weights kept in the shadow
        try:
            ap = validation_ap(trainer, pl_module)
            path = os.path.join(self.out_dir, "ema_metrics.csv")
            new = not os.path.isfile(path)
            with open(path, "a", newline="") as f:
                w = csv.writer(f)
                if new:
                    w.writerow(["epoch", "step", "valid_ap_ema"])
                w.writerow([trainer.current_epoch, trainer.global_step, round(ap, 6)])
            if np.isfinite(ap) and ap > self.best:
                self.best = ap
                trainer.save_checkpoint(os.path.join(self.out_dir, "best_ema.ckpt"))
            print(f"ema: step {trainer.global_step} valid_ap_ema {ap:.6f} (best {self.best:.6f})", flush=True)
        finally:
            self._swap(pl_module)  # raw weights back

    def state_dict(self):
        return {"shadow": [s.cpu() for s in self.shadow] if self.shadow else None, "best": self.best,
                "updates": self.updates, "decay": self.decay}

    def load_state_dict(self, state):
        self.shadow = state.get("shadow")
        self.best = float(state.get("best", -1.0))
        self.updates = int(state.get("updates", 0))


class NearUpdateCheckpoint(pl.Callback):
    """Keeps near_update.ckpt: the checkpoint at the validation whose optimizer-update count is nearest `target`."""

    def __init__(self, out_dir, target):
        self.out_dir, self.target = out_dir, int(target)
        self.best_distance = None

    def on_validation_end(self, trainer, pl_module):
        if trainer.sanity_checking:
            return
        d = abs(int(trainer.global_step) - self.target)
        if self.best_distance is None or d < self.best_distance:
            self.best_distance = d
            trainer.save_checkpoint(os.path.join(self.out_dir, "near_update.ckpt"))
            with open(os.path.join(self.out_dir, "near_update.json"), "w") as f:
                json.dump({"target_updates": self.target, "saved_at_updates": int(trainer.global_step),
                           "epoch": int(trainer.current_epoch)}, f)

    def state_dict(self):
        return {"best_distance": self.best_distance}

    def load_state_dict(self, state):
        self.best_distance = state.get("best_distance")


class PlateauEveryValidation(pl.Callback):
    """Steps every plateau scheduler once after each validation, with the value it monitors (used when the run
    validates every N updates; the scheduler's patience then counts validations)."""

    def on_validation_end(self, trainer, pl_module):
        if trainer.sanity_checking:
            return
        for config in trainer.lr_scheduler_configs:
            sched = config.scheduler
            if isinstance(sched, torch.optim.lr_scheduler.ReduceLROnPlateau):
                value = trainer.callback_metrics.get(config.monitor)
                if value is not None:
                    sched.step(float(value))


try:
    from pytorch_lightning.callbacks import ModelCheckpoint as _ModelCheckpoint

    class EpochEndCheckpoint(_ModelCheckpoint):
        """epoch_end.ckpt: the state at the end of the latest whole epoch (its own key in the checkpoint, beside the
        trainer's best and last checkpoints)."""

        def __init__(self, dirpath):
            super().__init__(dirpath=dirpath, filename="epoch_end", monitor=None, save_top_k=1,
                             save_on_train_epoch_end=True, enable_version_counter=False)

        @property
        def state_key(self):
            return "EpochEndCheckpoint"
except ImportError:  # pragma: no cover
    EpochEndCheckpoint = None
