"""The decision formulas the reads use. UDR at the 0.6% outsort decides; the bar is +0.01 UDR.

Costly changes (a feature group, a training variant, EMA, a loss option, more data or a new model):
- one seed: T_1 = t x sqrt(sd_pair^2 + 2 x sd_run^2), t the one-sided 95% t value at the Welch-Satterthwaite
  degrees of freedom; sd_pair is the account bootstrap SD of the gain, sd_run the control model's seed spread.
  Gain at or below 0: KEEP THE CONTROL. Gain >= T_1, >= the bar and the bootstrap's lower end above 0: ADOPT, pending
  the SELECT check. Any other gain above 0: RUN SEEDS 43 AND 44. A seed spread of 0 leaves T_1 undefined, so a gain
  above 0 goes to seeds 43 and 44.
- three seeds: ADOPT if the gain >= the bar and LB_3 = gain - t x sqrt(v_acct + s_d^2 / k) > 0 (t at k - 1 degrees
  of freedom, s_d the SD of the k per-seed differences, v_acct the bootstrap variance of the mean gain); else KEEP
  THE CONTROL (unresolved if the gain is above 0).
Free settings (learning rate, weight decay, dropout, clipping): adopted if the mean UDR gain is above 0 and the
SELECT check passes.
SELECT check: each of AP, AUROC, KS and UDR must not fall below -k x sqrt(SE_acct^2 + 2 x s_m^2 / n), k 2.5 (3.5 when
SELECT also decides). An ADOPT that fails it becomes KEEP THE CONTROL.
Unpaired arms (more training files against the 10-file reference, fitted independently): the larger-data arm stays
unless its mean UDR is more than the margin (0.01) below the reference and the upper end of the one-sided 80%
interval, difference + t(0.80, df) x sqrt(s_a^2/k_a + s_b^2/k_b + v_acct), is below 0 (Welch-Satterthwaite df).
"""
import math

import numpy as np

SELECT_METRICS = ("ap", "auroc", "ks", "udr")
ZERO_SPREAD = ("the UDR seed spread is zero (possible for a top-k count): T_1 is undefined, so there is no "
               "one-seed adoption; seeds 43 and 44 decide")


def finite(x):
    try:
        return x is not None and math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


def t_quantile(level, df):
    from scipy.stats import t as student_t
    return float(student_t.ppf(level, df))


def t1_terms(sd_pair, sd_run, df_run=2):
    a = float(sd_pair) ** 2 if finite(sd_pair) else float("nan")
    b = 2.0 * float(sd_run) ** 2 if finite(sd_run) else float("nan")
    undefined = ZERO_SPREAD if b == 0.0 and math.isfinite(a) else None
    if finite(b) and b > 0 and math.isfinite(a):
        nu = (a + b) ** 2 / (b * b / float(df_run))
        tq = t_quantile(0.95, nu)
        value = tq * math.sqrt(a + b)
    else:
        nu = tq = value = float("nan")
    return {"t1": float(value), "a": a, "b": b, "nu": nu, "t": tq, "df_run": df_run, "sd_pair": sd_pair,
            "sd_run": sd_run, "undefined": undefined}


def lb_three(gain, diffs, v_acct):
    """LB_3 = gain - t(k - 1) x sqrt(v_acct + s_d^2 / k). Returns (LB_3, s_d, t, df)."""
    k = len(diffs)
    if k < 2:
        raise ValueError(f"the several-seed bound needs at least two paired seed differences, got {k}")
    s_d = float(np.std(np.asarray(diffs, float), ddof=1))
    tq = t_quantile(0.95, k - 1)
    return float(gain - tq * math.sqrt(float(v_acct or 0.0) + s_d ** 2 / k)), s_d, tq, k - 1


def decide_costly(seeds, gain, t1, bar, lb, lb3=None, t1_undefined=None):
    """(decision, reason, changes the model) for a costly change."""
    if not finite(gain):
        return "NO DECISION", f"the gain is not a number ({gain})", False
    if seeds == 1:
        if gain <= 0:
            return "KEEP THE CONTROL", f"gain {gain:+.4f} is zero or below", False
        if t1_undefined:
            return "RUN SEEDS 43 AND 44", f"gain {gain:+.4f} is above zero and {t1_undefined}", False
        if not finite(t1):
            return "RUN SEEDS 43 AND 44", f"gain {gain:+.4f} is above zero; T_1 could not be computed", False
        if gain >= t1 and gain >= bar and lb is not None and lb > 0:
            return ("ADOPT", f"gain {gain:+.4f} >= T_1 {t1:.4f}, >= bar {bar:+.4f}, bootstrap lower end {lb:+.4f} > 0",
                    True)
        why = []
        if gain < t1:
            why.append(f"gain {gain:+.4f} is above zero but below T_1 {t1:.4f}")
        if gain < bar:
            why.append(f"below the bar {bar:+.4f}")
        if lb is None or lb <= 0:
            why.append("the bootstrap lower end is not above zero")
        return "RUN SEEDS 43 AND 44", "; ".join(why), False
    if gain >= bar and lb3 is not None and lb3 > 0:
        return "ADOPT", f"gain {gain:+.4f} >= bar {bar:+.4f} and LB_3 {lb3:+.4f} > 0", True
    return ("KEEP THE CONTROL", ("unresolved: " if gain > 0 else "") +
            f"gain {gain:+.4f}, bar {bar:+.4f}, LB_3 {lb3 if lb3 is None else round(lb3, 4)}", False)


def decide_free(gain, pairs=3):
    """A free setting: adopted if the mean UDR gain over three seed pairs is above zero (pending the SELECT check)."""
    if not finite(gain):
        return "NO DECISION", f"the gain is not a number ({gain})", False
    note = "" if pairs >= 3 else f" (read on {pairs} seed pair(s); the rule is the mean over three)"
    if gain > 0:
        return "ADOPT", f"mean gain {gain:+.4f} is above zero{note}", True
    return "KEEP THE CONTROL", f"mean gain {gain:+.4f} is zero or below{note}", False


def decide_not_worse(gain):
    """The preferred option replaces the current one unless it is worse: adopted if the mean UDR gain is zero or
    above (pending the SELECT check). Used for the calendar inputs."""
    if not finite(gain):
        return "NO DECISION", f"the gain is not a number ({gain})", False
    if gain >= 0:
        return "ADOPT", f"mean gain {gain:+.4f} is zero or above", True
    return "KEEP THE CONTROL", f"mean gain {gain:+.4f} is below zero", False


def seed_spread(spreads, m):
    """(s_m, df, source): the larger of the given seed spreads for measure m."""
    best = None
    for name, data in (spreads or {}).items():
        r = ((data.get("metrics") or {}).get(m)) or {}
        v = r.get("sd_run")
        if not finite(v):
            continue
        cand = (float(v), -int(r.get("df") or 2), name)
        if best is None or cand > best:
            best = cand
    if best is None:
        return None, None, None
    return best[0], -best[1], best[2]


def select_check(metrics, k_se, spreads, n_seeds, names=SELECT_METRICS):
    rows, ok = [], True
    for m in names:
        d, sd = metrics[m]["gain"], metrics[m]["sd"]
        s_m, _, src = seed_spread(spreads, m)
        se = math.sqrt(float(sd) ** 2 + 2.0 * s_m ** 2 / n_seeds) if (finite(sd) and s_m is not None) else None
        limit = None if se is None else -k_se * se
        passed = limit is not None and finite(d) and d >= limit
        ok &= bool(passed)
        rows.append({"metric": m, "difference": d, "sd": sd, "s_m": s_m, "s_m_source": src, "se": se,
                     "limit": limit, "pass": bool(passed)})
    return {"pass": bool(ok), "k_se": k_se, "n_seeds": n_seeds, "rows": rows}


def conflict_line(metrics, k_se, spreads, n_seeds, vdr_reason=None, names=("ap", "vdr")):
    """A note when AP or VDR falls clearly while UDR decides. Information only."""
    hits = []
    for m in names:
        if m == "vdr" and vdr_reason:
            continue
        d, sd = metrics[m]["gain"], metrics[m]["sd"]
        s_m, _, _ = seed_spread(spreads, m)
        if not finite(sd) or s_m is None or not finite(d):
            continue
        limit = -k_se * math.sqrt(float(sd) ** 2 + 2.0 * s_m ** 2 / n_seeds)
        if d < limit:
            hits.append(f"{m.upper()} {d:+.4f} below {limit:+.4f}")
    return ("conflict: " + "; ".join(hits) + " (UDR decides; the decision stands)") if hits else None


def unpaired_rule(diff, values_a, values_b, v_acct, margin=0.01, level=0.80):
    """The larger-data arm (A) against the reference (B), fitted independently.

    Seed term s_a^2/k_a + s_b^2/k_b. A side with a single fit has no seed spread of its own, so it takes the other
    side's (the only estimate there is). Degrees of freedom by Welch-Satterthwaite, with the account variance in the
    numerator as a known term. Neither side with two fits: no decision."""
    a, b = np.asarray(values_a, float), np.asarray(values_b, float)
    ka, kb = len(a), len(b)
    if ka < 2 and kb < 2:
        return {"difference": float(diff), "decision": "NO DECISION",
                "reason": "neither side has two or more fits, so there is no seed spread to judge the difference"}
    sa2 = float(np.var(a, ddof=1)) if ka > 1 else None
    sb2 = float(np.var(b, ddof=1)) if kb > 1 else None
    borrowed = None
    if sa2 is None:
        sa2, borrowed = sb2, "the arm has one fit, so it uses the reference's seed spread"
    if sb2 is None:
        sb2, borrowed = sa2, "the reference has one fit, so it uses the arm's seed spread"
    va, vb = sa2 / ka, sb2 / kb
    v_acct = float(v_acct or 0.0)
    if borrowed:  # one estimate of the seed variance, with its own degrees of freedom
        dof = (ka - 1) if kb < 2 else (kb - 1)
        denom = (va + vb) ** 2 / dof
    else:
        denom = va ** 2 / (ka - 1) + vb ** 2 / (kb - 1)
    total = va + vb + v_acct
    df = total ** 2 / denom if denom > 0 else float("inf")
    se = math.sqrt(total)
    tq = t_quantile(level, df) if math.isfinite(df) else 0.8416212335729143
    upper = diff + tq * se
    worse = diff < -margin and upper < 0
    return {"difference": float(diff), "se": se, "df": df, "t": tq, "upper": float(upper), "margin": margin,
            "seed_spread_note": borrowed,
            "decision": "KEEP THE REFERENCE" if worse else "KEEP THE LARGER DATA",
            "reason": (f"mean UDR {diff:+.4f} is more than {margin} below the reference and the upper end "
                       f"{upper:+.4f} is below 0") if worse else
                      (f"mean UDR {diff:+.4f}; upper end {upper:+.4f}: not shown worse by more than {margin}")}


def finalize(decision, check):
    if decision != "ADOPT" or check is None:
        return decision, None
    if check["pass"]:
        return decision, "the SELECT check passed"
    return "KEEP THE CONTROL", "the SELECT check failed, so ADOPT becomes KEEP THE CONTROL"
