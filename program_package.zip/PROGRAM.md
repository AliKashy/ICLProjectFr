# Program: from today's model to the final comparison with 15298 and the PFM

Read this first. It is one path in five steps. Each step says what to run, what it decides and what it hands to the
next step. The tools are in `program/` at the project root, one tool per job. That folder is outside `fraud/` and
`waqas/`, so installing it changes no file the trainer records in its run manifests: runs already going are
unaffected and can still be resumed. Optional research tools are listed at the end; none of them blocks the path.

1. Settle the setup once: the control recipe, how declined and advice rows are treated, and the calendar inputs.
2. Choose the features: the owner's final candidates, tested in groups on the chosen model.
3. Tune, then scale: one 12-trial search, a confirmation, then 100 files and, if worth it, 500 files.
4. Show whether the embedding is useful: export, derived columns, downstream models, the embedding table.
5. Freeze and finish: FINAL once, and the comparison with the real 15298 and the real PFM on the same transactions.

## How this relates to the earlier zips

- The features package (the features testing zip, with its two add-ons) is the tool for
  step 2: its CPU checks, enriched data, extended artifact, queue and grouped importance.
- The stage 1 checks add-on is done; its results stay where the features package reads them.
- The tuning package's plan is where the decision rules here come from. Its stage 3 and 4 code, announced there as
  "part 2", is this package (`pg_sweep.py`, the `pg_train.py` options).
- `time_encoding_test.zip` is optional research (listed at the end).

## Where things run

| Where | What |
|---|---|
| Laptop (Copilot) | Unzip, adapt paths and names, read the result screens |
| Pod, CPU (Red Hat OpenShift AI workbench) | Tests, reads (`pg_read.py`), the benchmark (`pg_bench.py`), derived columns, downstream models, the table |
| Pod, GPU (OpenShift AI workbench with the GPU) | Training (`pg_train.py`, `pg_sweep.py`), scoring (the project's scorer), export (`pg_export.py`) |

With two GPU workbenches, independent fits (for example two seeds, or two feature groups) can run at the same time,
one per workbench, each writing to its own run folder.

## Before you start (Copilot)

1. Unzip at the project root (the folder that holds `fraud/`). Nothing in the project is overwritten; every file is
   new.
2. Check that the trainer's source record does not cover `program/` (in the old code it covers the Python files under
   `fraud/` and `waqas/`; on the reorganized pod, `fraud/` except `fraud/experiments/`). If it also covers top-level
   folders, tell the owner before installing, because a running job's resume would then see a change.
3. Run the tests on the CPU: `$PY -m pytest -q tests/experiments/program`. On the organized code layout the tests that
   need the old module names skip; every other test runs.
4. Adapt only names and paths, never the logic:
   - `$PY`: the project's Python. `CFG`: the config the chosen model's seed-42 rerun used.
   - `TRAIN_RAW`: the training raw base (files 1-5000). `EVAL_RAW`: the evaluation raw base (files 8000-8300).
   - `CRED`: the S3 credentials file the configs already name (`s3.cred_path`).
   - `RUNS=runs/program`: where all new runs and reads go.
   - The scorer command: in the old layout `$PY -m waqas.v2.scripts.score_v2`; in the organized layout
     `$PY -m fraud.scripts.score_sequential_hier`. The same for the trainer, which `pg_train.py` finds by itself.
   - Column names of the owner's 15298 and PFM score files (`pg_bench.py --model NAME=PATH:COLUMN`).

Scoring command used below (the project's scorer, unchanged), `SCORE`:

```
$PY -m <scorer> --config $CFG --checkpoint <run>/best.ckpt --out <run>/<population>.parquet \
    --population OTHER --purpose program eval.base=$EVAL_RAW eval.file_start=<first> eval.file_end=<last>
```

## The rules every decision uses

| Population | Files | Used for |
|---|---|---|
| Training | 1-10 now; the lists from `pg_files.py` later | fitting only |
| EPOCH_VAL | 4950-4954 | each run's epoch and checkpoint choice |
| RANK-A | 8228-8243 | choosing (the search's top 2; a large run's checkpoint) |
| RANK-B | 8244-8259 | deciding every adopt-or-keep |
| SELECT | 8206-8216 | one check per adopt |
| DS_TRAIN, DS_SELECT | 4001-4010 (training raw base), 8217-8227 | the downstream models (fit, read) |
| Test 1, Test 2 | 8000-8010; the bank's 952,905 June rows from 8000-8200 | reporting only |
| FINAL | 8260-8277 | read once, at the end |

- The measure: UDR at the 0.6% outsort, fraud transactions caught in the top 0.6% of the June target rows by score,
  over all fraud transactions. AP, VDR, FPR (false positives per caught fraud), AUROC and KS are reported beside it.
  Every read is paired: the same rows, an account bootstrap with the same accounts in every draw (2000 draws).
- A costly change (an input group, a loss option, EMA, a training variant) is adopted only if it gains at least
  +0.01 UDR with its interval above zero: at one seed through the threshold T_1, at three seeds through LB_3. A gain
  above zero that is not yet clear runs seeds 43 and 44. An adopt then needs the SELECT check.
- A free setting (learning rate, weight decay, dropout, clipping) is adopted if its mean gain over three seeds is
  above zero and it passes the SELECT check.
- More training data (100 files against 10) is kept unless it is more than 1 point worse with the upper end of its
  80% interval below zero (the fits are independent, so the unpaired form is used).
- The seed spread every one-seed read needs comes from the control's own seed 42, 43 and 44 predictions on the same
  rows (`--spread-fits`).

`pg_read.py` applies these rules and prints the decision line. Its record (`.json`) and a short screen (`.txt`) go
to `$RUNS/reads/`.

## Step 1. Settle the setup once

**1.1 The control.** The chosen model (all-position, history 20, chunk training, target-ending scoring) at seeds 42,
43 and 44 on files 1-10, today's inputs. Reuse the existing seed-42 rerun and the kept seed 43 and 44 fits. Score all
three on RANK-B (8244-8259), SELECT (8206-8216) and RANK-A (8228-8243) with `SCORE`. These give the seed spread.

**1.2 The loading profile.** 300 training steps of the control, timed:

```
$PY program/pg_train.py --profile-steps 300 -- --config $CFG output.checkpoint_dir=$RUNS/profile
```

`$RUNS/profile/profile.json` gives the share of time the GPU waits for data (`wait_share`), rows per second and GPU
use. Above 0.5, a local copy of the training files (`pg_cache.py`, optional, below) should help the large runs.

**1.3 Declined and advice rows.** Declined rows are never fraud, and today they are trained as non-fraud. One seed-42
fit keeps them as history but takes them out of the loss:

```
$PY program/pg_train.py --loss-mask declines advice -- --config $CFG training.seed=42 \
    output.checkpoint_dir=$RUNS/no_decline_loss_s42
```

Score it on RANK-B and SELECT, then read on the rows without declines and advice:

```
$PY program/pg_read.py --role decide --control <control s42>/rank_b.parquet \
    --arm $RUNS/no_decline_loss_s42/rank_b.parquet --raw-base $EVAL_RAW --cred $CRED --files 8244 8259 \
    --exclude declines advice --spread-fits <control s42, s43, s44 rank_b.parquet> --out $RUNS/reads/declines_rank_b.json
```

On ADOPT, the SELECT check (`--role select-check --files 8206 8216`, spread fits on SELECT, `--spread-json` with
the RANK-B record). On RUN SEEDS 43 AND 44, fit seeds 43 and 44 and read again with three pairs.

**1.4 Calendar inputs.** June never occurs in training (October to May), so a June row's month is a value the model
never saw. Three versions, all read on June rows only: month as today (the control), the cyclical calendar (month,
day, hour and day of week as sine and cosine; step C of the features package, off by default), and no month (the
owner's existing no-month run). The cyclical version replaces today's month if its mean UDR gain over the control on
RANK-B is zero or above (`pg_read.py --role decide --kind not-worse`) and it passes the SELECT check: the simpler or
preferred encoding stays unless it is shown worse, the same form as the month rule.

**1.5 What step 1 hands on.** One control recipe (inputs, loss treatment, calendar) and its predictions at seeds 42,
43 and 44 on RANK-B, SELECT and RANK-A. If 1.3 or 1.4 changed the recipe, fit the new recipe at seeds 42, 43 and 44
and use those as the control from here on.

## Step 2. Choose the features

The owner chooses the final candidate features. No feature list is fixed in this package. Copilot: whatever features
you and the owner settle on as final, test them this way.

1. **Group them.** Three to six groups by source (for example the PFM's V22B fields, the 15298 features, each family
   of engineered fields). Do not test single fields: one fit per field costs too much and a single field rarely
   clears the bar.
2. **CPU checks first**, with the features package's field checks and CPU screen on files 1-10: missing shares, the
   June unseen-category rate, constant fields, and a check that nothing is computed from the transaction's own
   future or its label. Drop a field only for a broken check; a screen score alone never drops a field.
3. **Leakage rules for engineered fields.** Only strictly earlier seconds of the same account. Windows of 30 days or
   less (evaluation history is about two months). Profile and status dates only when strictly before the
   transaction's day. Bank decision fields (predecline, processor reason, fraud-system decline) only from earlier
   transactions. Never the label.
4. **Build** the enriched data and the extended preprocessing artifact with the features package (its field map and
   recipes hold each definition).
5. **Fit**, all on files 1-10 with the control's settings, at seed 42: one fit per group (control plus that group) and
   one combined fit (control plus every group). Use the features package's queue, or `pg_train.py` with the enriched
   config and `training.seed=42`.
6. **Read** each fit against the control on RANK-B with `pg_read.py --role decide` (the costly-change rule, bar
   +0.01). Seeds 43 and 44 when the read says so; the SELECT check for an adopt.
7. **If the combined fit is best**, fit it minus one group at a time to see which groups carry the gain.
8. **Shortlisting only:** the features package's grouped permutation importance on the kept fit (RANK-A rows). A
   group is never adopted or dropped on importance alone; a refit and a read decide.
9. **What step 2 hands on:** the selected inputs (or the control's, if no group clears the bar), fitted at seeds 42, 43
   and 44 and scored on RANK-B, SELECT and RANK-A.

## Step 3. Tune, then scale

**3.1 The search** (12 trials, files 1-10, the step 2 recipe; one trial at a time; run it again to continue after a
stop):

```
$PY program/pg_sweep.py run --study-dir $RUNS/sweep -- --config <step 2 config> training.seed=42
```

Trial 0 is the current settings; trials 1-5 are random, 6-11 guided. After 5 epochs a trial from number 4 on stops if
it is more than 0.03 AP below the median of the three best so far (the first four always run to 10 epochs; their
replay can widen the margin or turn the rule off). Then score every full trial's `best.ckpt` on RANK-A as
`$RUNS/sweep/trial_<k>/rank_a.parquet`, and:

```
$PY program/pg_sweep.py choose --study-dir $RUNS/sweep --raw-base $EVAL_RAW --cred $CRED --files 8228 8243
```

**3.2 The confirmation.** The top 2 settings and the current settings, each on three new seeds (45, 46, 47), with EMA
weights kept beside the raw ones (`--ema-decay 0.999` saves `best_ema.ckpt`): 9 fits. Score `best.ckpt` and
`best_ema.ckpt` on RANK-B. Each of the top 2 against the current settings: `pg_read.py --role decide --kind free`
with three pairs, then the SELECT check. Then EMA on the adopted settings: `--kind costly`, arm = the EMA
predictions, control = the raw predictions of the same three fits.

**3.3 The 10-file reference.** The adopted recipe on three more new seeds (48, 49, 50), files 1-10. For each fit, the
best checkpoint's update count is the `step` of the row with the highest `valid_ap` in its `training_metrics.csv`; their
mean is the update count 3.5 keeps a checkpoint near.

**3.4 File lists.** `$PY program/pg_files.py --out $RUNS/files` writes nested lists of 10, 35,
100, 250 and 500 files (files 1-10 first, then a fixed random draw; the reserved files never enter). Add
`--stats <per-file counts csv>` to print each list's fraud rate beside the pool's.

**3.5 100 files**, seeds 42, 43 and 44, at most 3 epochs, validation every 4,200 updates, patience 5 validations:

```
$PY program/pg_train.py --files-list $RUNS/files/files_100.txt --val-every-updates 4200 \
    --keep-near-update <the reference's mean best update count> -- --config <recipe config> training.seed=42 \
    training.max_epochs=3 output.checkpoint_dir=$RUNS/files100_s42
```

Score `best.ckpt` and `near_update.ckpt` of each fit on RANK-A and keep the one with the higher UDR. Score the kept
checkpoints on RANK-B and read: `pg_read.py --role unpaired --arm <the three 100-file fits> --control <the three
reference fits> --raw-base $EVAL_RAW --cred $CRED --files 8244 8259`.

**3.6 500 files**, only if 100 files stayed and the GPU time allows. One full epoch of 500 files takes about ten GPU
hours at today's speed. Keep every fraud account and a tenth of the others (`--clean-account-share 0.1`; non-fraud
rows of fraud accounts are kept at the same share, so every non-fraud row counts with the same chance). Profile first
(`--profile-steps 300` with the same options). If the GPU waits for data more than half the time, make a local copy
with `pg_cache.py` (same list, same share) and train with `--local-dir`. Read against the 100-file fits with
`--role unpaired`, the same rule.

**3.7 What step 3 hands on:** the final recipe (inputs, settings, training files) and its seed-42 checkpoint.

## Step 4. Show whether the embedding is useful

**4.1 Export** the score and the 48 numbers the fraud head reads, in one pass of the normal scorer:

```
$PY program/pg_export.py --checkpoint <final s42>/best.ckpt --out $RUNS/export/ds_train.parquet \
    -- --config <recipe config> eval.base=$TRAIN_RAW eval.file_start=4001 eval.file_end=4010
```

The same for DS_SELECT (8217-8227) and the Test 2 files (8000-8200), with `eval.base=$EVAL_RAW`.

**4.2 Derived columns** (CPU):

```
$PY program/pg_derive.py fit-pca --export $RUNS/export/ds_train.parquet --out $RUNS/export/pca.npz
$PY program/pg_derive.py derive --export $RUNS/export/ds_select.parquet --checkpoint <final s42>/best.ckpt \
    --pca $RUNS/export/pca.npz --out $RUNS/export/ds_select_derived.parquet
```

(and the same `derive` for DS_TRAIN). They add PCA 8 and 16, the 47 coordinates the head ignores, and each account's
means over its strictly earlier 1, 7 and 30 days with the deviations from them.

**4.3 Downstream models** (CPU): one learner fitted on DS_TRAIN and read on DS_SELECT June rows, with different
inputs, compared in pairs.

```
$PY program/pg_downstream.py --train-export $RUNS/export/ds_train.parquet \
    --train-derived $RUNS/export/ds_train_derived.parquet --read-export $RUNS/export/ds_select.parquet \
    --read-derived $RUNS/export/ds_select_derived.parquet --train-raw-base $TRAIN_RAW --train-files 4001 4010 \
    --read-raw-base $EVAL_RAW --read-files 8217 8227 --cred $CRED --arms raw raw+score raw+score+vector raw+vector \
    --out $RUNS/reads/downstream_ds_select.json
```

- The vector is useful beyond the score if `raw+score+vector vs raw+score` gains with its interval above zero.
- With the owner's 15298 scores for the DS_TRAIN and DS_SELECT transactions (`--incumbent-train`, `--incumbent-read`),
  add the arms `offset offset_raw`: 15298 as the fixed starting point, trees learn only the correction from our score
  and vector. `offset vs 15298` is the lift over 15298 alone; `offset vs offset_raw` checks it is our vector, not the
  raw fields, that adds it.
- With the PFM's exported embeddings for the same transactions (`--pfm-train`, `--pfm-read`, `--pfm-prefix`), add
  `raw+pfm raw+pfm+vector`: does our vector add anything the PFM's embedding does not already have?

**4.4 The embedding table** with a point-in-time lookup:

```
$PY program/pg_store.py write --store $RUNS/store --model allpos_h20 --version v1 \
    --export $RUNS/export/ds_select.parquet --derived $RUNS/export/ds_select_derived.parquet --checkpoint <final s42>/best.ckpt
$PY program/pg_store.py as-of --store $RUNS/store --model allpos_h20 --version v1 --queries <account, time csv>
```

A new checkpoint is a new version; vectors from different checkpoints are never mixed.

## Step 5. Freeze and finish

1. **Freeze.** Write down the recipe: config, inputs, training files, settings, seed 42 and the checkpoint path.
   Nothing changes after this.
2. **FINAL, once.** Score FINAL (8260-8277) with the frozen checkpoint and with the 10-file control (seed 42).
   `pg_read.py --role report` on FINAL's June rows, once as is and once with `--exclude declines advice`. Then the
   downstream arms on FINAL, once: export FINAL (`pg_export.py`, `eval.file_start=8260 eval.file_end=8277`), derive
   its columns (`pg_derive.py derive` with the DS_TRAIN PCA), and run the 4.3 command with
   `--read-export <FINAL export> --read-derived <FINAL derived> --read-files 8260 8277`.
3. **Against the real 15298 and the real PFM, on the same transactions.** Score the Test 2 files (8000-8200) with the
   frozen checkpoint. Then, with the benchmark rows (the reconstructed scoring parquet: ids, label, amount) and the
   owner's score files:

```
$PY program/pg_bench.py --rows <test2 rows parquet> --model ours=<our test2 scores>:score \
    --model 15298=<15298 scores>:<column> --model PFM=<PFM scores>:<column> \
    --pair ours-15298 --pair ours-PFM --pair PFM-15298 --out $RUNS/reads/test2_bench.json
```

It reads every model on the rows all files cover (and prints how many each covers), at 0.6%, 1% and 5%, with the
outsort count rounded down (our rule) and up (the count the bank's rank-based table uses), and paired intervals.
The bank's published figures at 0.6% for reference: 15298 DR 0.5486, VDR 0.5631, FPR 6.34; PFM DR 0.5664,
VDR 0.6877, FPR 6.16 (the PFM rerun's rank-based table: 56.56%, 68.37%, 6.13).

4. **Send back** the `.txt` screens of the reads.

## Optional research (none blocks the path)

| Tool or option | What it tries |
|---|---|
| `pg_train.py --prefix-seconds 4` (or 20) | Each chunk gets earlier seconds as read-only context, with a banded mask that limits each row to the rows of its scoring window, so early chunk rows see history closer to how they do at scoring (an approximation: positions and deeper layers still differ). Test 0, 4 and 20 seconds; read by window size with `pg_read.py --slices window` |
| `pg_train.py --recency-half-life 3` | Recent months weigh more in the loss |
| `pg_train.py --clean-account-share 0.1 --inverse-negative-weight` | The sampled run with the full-data balance restored in the loss |
| `pg_train.py --loss focal --plateau-monitor valid_ap` | Focal loss (gamma 2) |
| `pg_diagnostics.py rank / cka / align / probe` | Effective rank of the vector; CKA against another seed or the PFM's embedding; Procrustes alignment between seeds (fit a downstream model on one seed, read it with another); the 7-day probe (does the vector tell which accounts get a fraud next week) |
| `pg_cache.py` | A local copy of the training files with only the needed columns |
| `pg_train.py --init-from <checkpoint>` | Warm start for a later refresh: start from the frozen model, train on new months plus a sample of older ones, read on the newest labelled month |
| The time-encoding test (its own zip) | The sinusoidal time-gap encoding from the FraudTransformer paper |

## Rough GPU time (measure; these come from today's speed: about 17 minutes per 10-file epoch with validation)

| Work | Fits | Rough GPU hours |
|---|---|---|
| Step 1: profile, declines fit, calendar fits | 1 to 3 seed-42 fits (more if a read asks for seeds 43, 44) | 3 to 10 |
| Step 2: groups plus combined | one fit per group plus one, at seed 42, wider inputs | 3 to 4 each; measure the first |
| Step 3: search, confirmation, reference | 12 + 9 + 3 fits | 25 to 35, 20 to 25, 7 |
| Step 3: 100 files | 3 fits of at most 3 epochs | about 25 |
| Step 3: 500 files, a tenth of clean accounts | 1 to 3 fits | measure with the profile first |
| Scoring and export | a few minutes per population and checkpoint | small |
