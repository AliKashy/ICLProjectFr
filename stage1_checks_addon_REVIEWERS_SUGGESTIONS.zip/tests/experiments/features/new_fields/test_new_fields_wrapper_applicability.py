"""A plain control needs no timing-wrapper check; other Stage 1 evidence still applies."""
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / "fraud/experiments/features/new_fields"))
import nf_guard as guard  # noqa: E402


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value))


def evidence(root):
    """Use real result files, with the control and timing output in the design's sibling layout."""
    control = root / "checkpoints/reproduce/retrain_seed42"
    write_json(control / guard.MANIFEST, {
        "status": "finished", "start": {"utc": "2026-11-02T00:00:00Z", "source_sha256": "s" * 64},
    })
    (control / "best.ckpt").write_bytes(b"synthetic checkpoint")
    stage1 = {
        "control_dir": control.relative_to(root).as_posix(),
        "rescore_summary": "checkpoints/reproduce/rescore/summary.json",
        "route_result": "checkpoints/reproduce/route.json",
        "wrapper_check": "checkpoints/reproduce/wrapper_check.json",
        "same_batch_results": "checkpoints/reproduce/same_batch",
    }
    for key in ("rescore_summary", "route_result"):
        write_json(root / stage1[key], {"passed": True})
    for device in ("cpu", "cuda"):
        write_json(root / stage1["same_batch_results"] / device / "result.json", {"passed": True})
    return {"stage1": stage1}, control


def wrapper_record(control):
    path = control.with_name(control.name + "_timing") / "wrapper.json"
    write_json(path, {
        "argv": ["train_timed.py", "retrain", "--run", str(control)],
        "source_sha256": "s" * 64, "start_utc": "2026-11-02T00:00:00Z",
    })
    return path


def test_plain_control_passes_without_fabricated_wrapper_pass(tmp_path):
    up, _ = evidence(tmp_path)
    results = guard.stage1_results(up, tmp_path)
    assert guard.stage1_ok(results)
    wrapper = results["wrapper_check"]
    assert wrapper["applicable"] is False
    assert wrapper["passed"] is not True
    assert "not applicable" in guard._word(wrapper).lower()


@pytest.mark.parametrize("wrapper_verdict,expected", [(None, False), (False, False), (True, True)])
def test_wrapped_control_requires_its_result(tmp_path, wrapper_verdict, expected):
    up, control = evidence(tmp_path)
    wrapper_record(control)
    if wrapper_verdict is not None:
        write_json(tmp_path / up["stage1"]["wrapper_check"], {"passed": wrapper_verdict})
    results = guard.stage1_results(up, tmp_path)
    assert results["wrapper_check"].get("applicable") is not False
    assert guard.stage1_ok(results) is expected


@pytest.mark.parametrize("device", ["cpu", "cuda"])
def test_wrapped_control_cannot_pass_with_one_same_batch_device_missing(tmp_path, device):
    up, control = evidence(tmp_path)
    wrapper_record(control)
    write_json(tmp_path / up["stage1"]["wrapper_check"], {"passed": True})
    (tmp_path / up["stage1"]["same_batch_results"] / device / "result.json").unlink()
    results = guard.stage1_results(up, tmp_path)
    assert not guard.stage1_ok(results)


@pytest.mark.parametrize("bad_record", ["{broken", "null", "[]"])
def test_malformed_sidecar_is_not_an_absent_wrapper(tmp_path, bad_record):
    up, control = evidence(tmp_path)
    wrapper_record(control).write_text(bad_record)
    write_json(tmp_path / up["stage1"]["wrapper_check"], {"passed": True})
    results = guard.stage1_results(up, tmp_path)
    assert results["wrapper_check"].get("applicable") is not False
    assert not guard.stage1_ok(results)


@pytest.mark.parametrize("kind", ["rescore_summary", "route_result", "same_batch_cpu", "same_batch_cuda"])
@pytest.mark.parametrize("missing", [True, False])
def test_plain_control_still_requires_other_results(tmp_path, kind, missing):
    up, _ = evidence(tmp_path)
    if kind.startswith("same_batch_"):
        path = tmp_path / up["stage1"]["same_batch_results"] / kind.removeprefix("same_batch_") / "result.json"
    else:
        path = tmp_path / up["stage1"][kind]
    if missing:
        path.unlink()
    else:
        write_json(path, {"passed": False})
    results = guard.stage1_results(up, tmp_path)
    assert not guard.stage1_ok(results)


@pytest.mark.parametrize("missing", ["control_dir", "manifest", "folder"])
def test_missing_control_is_not_evidence_of_plain_training(tmp_path, missing):
    up, control = evidence(tmp_path)
    if missing == "control_dir":
        up["stage1"].pop("control_dir")
    elif missing == "manifest":
        (control / guard.MANIFEST).unlink()
    else:
        (control / guard.MANIFEST).unlink()
        (control / "best.ckpt").unlink()
        control.rmdir()
    results = guard.stage1_results(up, tmp_path)
    assert results["wrapper_check"].get("applicable") is not False
    assert not guard.stage1_ok(results)


def test_guard_records_na_instead_of_a_wrapper_pass(tmp_path):
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from new_fields_spine_world import make_world, run

    world = make_world(tmp_path)
    evidence(world)
    write_json(world / "runs/tuning/lr3e-4" / guard.MANIFEST, {
        "status": "finished", "start": {"source_sha256": "s" * 64},
    })
    output = run(world, tmp_path, "nf_guard.py", "--cpu-only")
    assert output.returncode == 0, output.stdout + output.stderr
    records = (world / "checkpoints/new_fields/guard/guard.jsonl").read_text().splitlines()
    record = json.loads(records[-1])
    assert record["stage1_ok"] is True
    assert record["stage1_results"]["wrapper_check"]["applicable"] is False
    assert record["stage1_results"]["wrapper_check"]["passed"] is not True
    assert "not applicable" in output.stdout.lower()
