"""An owner may accept an explained S1-S3 gap without changing its measured verdict."""
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / "fraud/experiments/features/new_fields"))
from test_new_fields_wrapper_applicability import evidence, write_json
import nf_guard as guard
import nf_read


def accepted():
    return {"passed": False, "verdict": "STOP", "stage1_rescore_exact": False,
            "accepted_gap": True, "acceptance_eligible": True,
            "accept_rescore_gap_reason": "Reviewed the aligned scores; accept the numeric gap."}


def test_owner_acceptance_is_operational_and_preserves_failed_measurement(tmp_path):
    up, _ = evidence(tmp_path)
    report = accepted()
    write_json(tmp_path / up["stage1"]["rescore_summary"], report)
    results = guard.stage1_results(up, tmp_path)
    assert guard.stage1_ok(results)
    value = results["rescore_summary"]
    assert value["passed"] is False and value["stage1_rescore_exact"] is False
    assert "owner-accepted" in guard._word(value)
    assert report["accept_rescore_gap_reason"] in guard._word(value)
    lines = nf_read.environment_lines({"kept_controls_guard": {
        "stage1_ok": True, "stage1_results": results, "guard_utc": "test"}})
    assert any("owner-accepted rescore gap" in line for line in lines)
    assert not any("all applicable stage 1 checks passed" in line for line in lines)


@pytest.mark.parametrize("key,value", [
    ("accepted_gap", False), ("accepted_gap", "true"),
    ("acceptance_eligible", False), ("acceptance_eligible", "true"),
    ("accept_rescore_gap_reason", ""), ("accept_rescore_gap_reason", " "),
    ("accept_rescore_gap_reason", None), ("passed", None),
])
def test_incomplete_or_ineligible_acceptance_does_not_pass(tmp_path, key, value):
    up, _ = evidence(tmp_path)
    report = accepted()
    report[key] = value
    write_json(tmp_path / up["stage1"]["rescore_summary"], report)
    assert not guard.stage1_ok(guard.stage1_results(up, tmp_path))


@pytest.mark.parametrize("kind", ["route_result", "cpu", "cuda"])
def test_rescore_acceptance_cannot_waive_other_checks(tmp_path, kind):
    up, _ = evidence(tmp_path)
    write_json(tmp_path / up["stage1"]["rescore_summary"], accepted())
    path = (tmp_path / up["stage1"]["route_result"] if kind == "route_result" else
            tmp_path / up["stage1"]["same_batch_results"] / kind / "result.json")
    write_json(path, accepted())
    results = guard.stage1_results(up, tmp_path)
    assert not guard.stage1_ok(results)
    bad = results[kind] if kind == "route_result" else results["same_batch"][kind]
    assert not bad.get("accepted_gap")


def test_missing_same_batch_cannot_be_waived(tmp_path):
    up, _ = evidence(tmp_path)
    write_json(tmp_path / up["stage1"]["rescore_summary"], accepted())
    (tmp_path / up["stage1"]["same_batch_results"] / "cuda/result.json").unlink()
    assert not guard.stage1_ok(guard.stage1_results(up, tmp_path))
