"""Resolve one complete runtime layout and show the source files it imports."""
import ast
import importlib
import inspect
from pathlib import Path
import sys
import textwrap


class LayoutError(Exception):
    """The requested project cannot supply a complete, unmixed runtime layout."""


NAMES = {
    "trainer": ("fraud.scripts.train_sequential_hier", "waqas.v2.scripts.train_v2"),
    "scorer": ("fraud.scripts.score_sequential_hier", "waqas.v2.scripts.score_v2"),
    "target_ending_model": ("fraud.sequential_hier_target_ending_model", "waqas.v2.models"),
    "base_model": ("fraud.sequential_hier_model", "waqas.phase4b.sequential_hier"),
    "factory": ("fraud.sequential_hier_factory", "waqas.phase4b.factory"),
    "chunk_builder": ("fraud.data.sequence_builder", "waqas.phase4b.sequence_builder"),
    "target_ending_data": ("fraud.data.target_ending", "waqas.v2.target_ending"),
    "source_list": ("fraud.source_files", "waqas.source_identity"),
    "comparison": ("fraud.scripts.compare_models", "waqas.v2.analysis.paired_v2"),
}
REQUIRED = {
    "trainer": ("main", "build_trainer", "make_dataset", "check_batch_plan", "source_files",
                "source_sha256", "run_identity", "is_chunk_model", "eval_batch_size", "pl"),
    "scorer": ("main", "load_for_scoring"),
    "target_ending_model": ("FTTransformerHierTargetEnding", "target_slot_outputs", "TARGET_ENDING_POLICY"),
    "base_model": ("FTTransformerHierModel",),
}


class Layout:
    def __init__(self, layout, modules, names, files):
        self.layout, self.mod, self.name, self.file = layout, modules, names, files

    def describe(self):
        return [f"layout {self.layout}: {role} {self.name[role]} ({self.file[role]})" for role in self.mod]


def _inside(path, root):
    return Path(path).resolve().is_relative_to(root)


def _check_loaded_packages(root):
    for name, module in tuple(sys.modules.items()):
        if name.split(".", 1)[0] not in ("fraud", "waqas") or module is None:
            continue
        file = getattr(module, "__file__", None)
        if file is not None and not _inside(file, root):
            raise LayoutError(f"{name} is already imported from outside {root}: {file}; use a fresh process")
        for path in getattr(module, "__path__", ()):
            if not _inside(path, root):
                raise LayoutError(f"{name} package path is outside {root}: {path}; use a fresh process")


def _import(name):
    try:
        return importlib.import_module(name)
    except Exception as exc:
        raise LayoutError(f"cannot import {name}: {type(exc).__name__}: {exc}") from exc


def _contains_node(source, expression, expression_only=False):
    target = ast.parse(expression).body[0]
    if expression_only:
        target = target.value
    expected = ast.dump(target, include_attributes=False)
    return any(ast.dump(node, include_attributes=False) == expected
               for node in ast.walk(ast.parse(textwrap.dedent(source))))


def _patch_markers(modules, files):
    trainer = files["trainer"].read_text(encoding="utf-8")
    model = modules["target_ending_model"].FTTransformerHierTargetEnding
    try:
        step = inspect.getsource(model.training_step)
    except (AttributeError, TypeError, OSError) as exc:
        raise LayoutError(f"cannot inspect target-ending training_step: {exc}") from exc
    requirements = (
        ("trainer train_target_ending", trainer,
         'train_target_ending = bool(cfg.sequence.get("train_target_ending", False))', False),
        ("target-ending chunk training route", step,
         'torch.equal(batch["target_seq"] != -100, batch["mask"])', True),
    )
    missing = []
    for label, source, marker, expression_only in requirements:
        try:
            present = _contains_node(source, marker, expression_only)
        except SyntaxError as exc:
            raise LayoutError(f"cannot parse {label} source: {exc}") from exc
        if not present:
            missing.append(label)
    if missing:
        from repro_common import ReproduceStop
        raise ReproduceStop("required runtime patch missing: " + ", ".join(missing))


def resolve(root, expect=None):
    """Load the organized layout first, falling back only when its trainer is absent."""
    root = Path(root).resolve()
    if not root.is_dir():
        raise LayoutError(f"project root is not a directory: {root}")
    if expect not in (None, "old", "organized"):
        raise LayoutError(f"unknown expected layout: {expect!r}")
    _check_loaded_packages(root)
    sys.path[:0] = [str(root), str(root / "src")]
    importlib.invalidate_caches()
    organized_trainer = NAMES["trainer"][0]
    try:
        trainer = importlib.import_module(organized_trainer)
        layout, index = "organized", 0
    except ModuleNotFoundError as exc:
        # An absent trainer/package permits fallback. An absent dependency inside
        # an existing trainer is an import failure, never a reason to use old code.
        prefixes = {".".join(organized_trainer.split(".")[:n])
                    for n in range(1, len(organized_trainer.split(".")) + 1)}
        if exc.name not in prefixes:
            raise LayoutError(f"organized trainer import failed: {exc}") from exc
        layout, index = "old", 1
        trainer = _import(NAMES["trainer"][1])
    except Exception as exc:
        raise LayoutError(f"organized trainer import failed: {type(exc).__name__}: {exc}") from exc
    if expect is not None and layout != expect:
        raise LayoutError(f"expected {expect} layout under {root}, found {layout}")
    names = {role: pair[index] for role, pair in NAMES.items()}
    modules = {"trainer": trainer}
    modules.update({role: _import(name) for role, name in names.items() if role != "trainer"})
    files = {}
    for role, module in modules.items():
        file = getattr(module, "__file__", None)
        if file is None or not _inside(file, root):
            raise LayoutError(f"{role} module is outside {root}: {file}")
        files[role] = Path(file).resolve()
        missing = [name for name in REQUIRED.get(role, ()) if not hasattr(module, name)]
        if missing:
            raise LayoutError(f"{names[role]} is missing required attributes: {missing}")
    if not hasattr(modules["base_model"].FTTransformerHierModel, "_step"):
        raise LayoutError("base model FTTransformerHierModel is missing _step")
    actual_root = getattr(trainer, "ROOT", None)
    if actual_root is None or Path(actual_root).resolve() != root:
        raise LayoutError(f"trainer ROOT is {actual_root!r}, expected {root}")
    _check_loaded_packages(root)
    _patch_markers(modules, files)
    return Layout(layout, modules, names, files)
