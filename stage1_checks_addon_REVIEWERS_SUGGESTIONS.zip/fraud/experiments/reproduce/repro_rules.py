"""Declared comparison rules, separate from editable project locations."""
import json
import os
from pathlib import Path


RECORDED_TEST1_AP = {42: "0.102004", 43: "0.091165", 44: "0.101348"}
RECORDED_N_PREDICTIONS = 2466461
RECORDED_N_POSITIVES = 3818
TEST1_FILES = (8000, 8010)
SELECT_FILES = (8206, 8216)
SEED42_BEST_EPOCH = 3
SEED42_BEST_VALID_AP = "0.137146"
STEPS_PER_EPOCH = 2103
HISTORY = 20
WINDOW_CAP = 32
VALIDATION_POLICY = "target_ending_v1"
TOLERANCE = {
    "cpu": {"batches": 0, "init": 0, "loss": 0.0, "grad_norm": 0.0,
            "weights": 0.0, "logits": 0.0, "scores": 0.0},
    "cuda": {"batches": 0, "init": 0, "loss": 1e-6, "grad_norm": 1e-5,
             "weights": 1e-6, "logits": 1e-5, "scores": 1e-6},
}
SAME_BATCH = {"cpu": {"steps": 8, "val": 4, "chunk_cut": 32},
              "cuda": {"steps": 16, "val": 4, "chunk_cut": None}}
MIN_FREE_GB = 20
BUSY_GPU_MIB = 1024


def _override():
    path = os.environ.get("REPRO_RULES_OVERRIDE")
    if not path:
        return
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("REPRO_RULES_OVERRIDE must contain a JSON object")
    permitted = {name for name in globals() if name.isupper()}
    for name, setting in value.items():
        if name not in permitted:
            raise ValueError(f"unknown reproduction rule: {name}")
        if name == "RECORDED_TEST1_AP":
            setting = {int(seed): ap for seed, ap in setting.items()}
        elif name in ("TEST1_FILES", "SELECT_FILES"):
            setting = tuple(setting)
        globals()[name] = setting


_override()
