#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="${REPRO_PROJECT_ROOT:-$(cd -- "$SCRIPT_DIR/../../.." && pwd)}"
export REPRO_PROJECT_ROOT="$PROJECT_ROOT"
cd -- "$PROJECT_ROOT"
"${PY:-python}" "$SCRIPT_DIR/report.py" --run-queue "$@"
