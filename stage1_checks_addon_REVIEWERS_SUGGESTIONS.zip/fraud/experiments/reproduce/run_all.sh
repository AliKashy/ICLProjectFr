#!/usr/bin/env bash
# Runs on the pod, from the current project root (the folder containing the installed fraud/), on a workbench whose GPU is free.
# start.sh starts it in the background; to run it in the foreground: PY=<project python> bash fraud/experiments/reproduce/run_all.sh
# ADAPT: set PY to the project's Python on the pod, for example PY=/home/jovyan/YOUR_ID/<venv folder>/bin/python.
# Options pass through to the queue: --cpu-only (preflight, route test, CPU same-batch and report only) and
# --accept-rescore-gap "<reason>" (the owner's decision only, for S1 to S3).
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="${REPRO_PROJECT_ROOT:-$(cd -- "$SCRIPT_DIR/../../.." && pwd)}"
export REPRO_PROJECT_ROOT="$PROJECT_ROOT"
cd -- "$PROJECT_ROOT"
"${PY:-python}" "$SCRIPT_DIR/report.py" --run-queue "$@"
