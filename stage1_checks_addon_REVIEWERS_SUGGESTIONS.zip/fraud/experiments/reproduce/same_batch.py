"""Compare two project layouts on batches captured through each trainer's entry point."""
import argparse
from contextlib import nullcontext
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys


class CaptureComplete(Exception):
    """Stop the trainer after it has constructed its actual model and loaders."""


def _shared():
    import repro_common
    import repro_paths
    import repro_rules
    import repro_layout
    return repro_common, repro_paths, repro_rules, repro_layout


def _cpu(value):
    import torch
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().clone()
    if isinstance(value, dict):
        return {k: _cpu(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return type(value)(_cpu(v) for v in value)
    return value


def _plain(value):
    from omegaconf import OmegaConf
    if OmegaConf.is_config(value):
        return OmegaConf.to_container(value, resolve=True)
    if isinstance(value, dict):
        return {str(k): _plain(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [_plain(v) for v in value]
    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    return str(value)


def _batches(loader, count, chunk_cut):
    result = []
    for batch in loader:
        batch = _cpu(batch)
        if chunk_cut is not None:
            batch = {key: value[:chunk_cut] for key, value in batch.items()}
        result.append(batch)
        if len(result) == count:
            break
    if len(result) != count:
        raise ValueError(f"requested {count} batches, loader supplied {len(result)}")
    return result


def capture_from_main(layout, config_path, run_dir, steps=8, validation_batches=4, chunk_cut=32):
    """Run the real entry point up to fit; do not reimplement its data/model construction."""
    trainer = layout.mod["trainer"]
    captured = {}

    class CaptureTrainer:
        def fit(self, model, train_loader, val_loader, ckpt_path=None):
            if ckpt_path is not None:
                raise ValueError("same-batch capture must start a fresh diagnostic model")
            captured["model"] = model
            captured["snapshot"] = {
                "initial_state": _cpu(model.state_dict()),
                "hyperparameters": _plain(dict(model.hparams)),
                "sequence_contract": _plain(model.sequence_contract),
                "validation_policy": _plain(model.validation_policy()),
                "train_batches": _batches(train_loader, steps, chunk_cut),
                "validation_batches": _batches(val_loader, validation_batches, None),
            }
            raise CaptureComplete()

    original = trainer.build_trainer
    trainer.build_trainer = lambda *args, **kwargs: CaptureTrainer()
    try:
        trainer.main(["--config", str(config_path), f"output.checkpoint_dir={Path(run_dir).resolve()}"])
    except CaptureComplete:
        pass
    finally:
        trainer.build_trainer = original
    if "model" not in captured:
        raise RuntimeError("trainer main returned without reaching the capture fit")
    return captured["model"], captured["snapshot"]


def _exact(a, b):
    import torch
    if isinstance(a, torch.Tensor) or isinstance(b, torch.Tensor):
        return (isinstance(a, torch.Tensor) and isinstance(b, torch.Tensor)
                and a.dtype == b.dtype and a.shape == b.shape
                and torch.equal(a.detach().cpu().contiguous().reshape(-1).view(torch.uint8),
                                b.detach().cpu().contiguous().reshape(-1).view(torch.uint8)))
    if isinstance(a, dict) and isinstance(b, dict):
        return a.keys() == b.keys() and all(_exact(a[k], b[k]) for k in a)
    if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        return len(a) == len(b) and all(_exact(x, y) for x, y in zip(a, b))
    return type(a) is type(b) and a == b


def _maximum(a, b):
    import torch
    if isinstance(a, torch.Tensor) and isinstance(b, torch.Tensor):
        if a.shape != b.shape or a.dtype != b.dtype:
            return math.inf
        if not a.numel():
            return 0.0
        x, y = a.double(), b.double()
        if not torch.isfinite(x).all() or not torch.isfinite(y).all():
            return math.inf
        return float((x - y).abs().max())
    if isinstance(a, dict) and isinstance(b, dict):
        if a.keys() != b.keys():
            return math.inf
        return max((_maximum(a[k], b[k]) for k in a), default=0.0)
    if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        if len(a) != len(b):
            return math.inf
        return max((_maximum(x, y) for x, y in zip(a, b)), default=0.0)
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return abs(a - b) if math.isfinite(a) and math.isfinite(b) else math.inf
    return 0.0 if _exact(a, b) else math.inf


def compare_snapshots(left, right, tolerances, forward_only=False):
    """Compare capture identity and numerical results at the predeclared tolerances."""
    result = {
        "batches_equal": all(_exact(left.get(k), right.get(k)) for k in ("train_batches", "validation_batches")),
        "initial_equal": _exact(left.get("initial_state"), right.get("initial_state")),
        "metadata_equal": all(_exact(left.get(k), right.get(k)) for k in ("hyperparameters", "sequence_contract", "validation_policy")),
        "maxima": {key: 0.0 for key in ("loss", "grad_norm", "weights", "logits", "scores")},
        "reasons": [], "forward_only": bool(forward_only),
    }
    for key in ("batches_equal", "initial_equal", "metadata_equal"):
        if not result[key]:
            result["reasons"].append(key + " is false")
    maxima = result["maxima"]

    def probes(a, b):
        if not a or not b or a.keys() != b.keys():
            result["reasons"].append("probe precision sets are absent or differ")
            return
        for precision in a:
            if len(a[precision]) != len(b[precision]) or not a[precision]:
                result["reasons"].append(f"{precision} probe count differs or is empty")
                continue
            for x, y in zip(a[precision], b[precision]):
                for key in ("loss", "logits", "scores"):
                    maxima[key] = max(maxima[key], _maximum(x.get(key), y.get(key)))

    if forward_only:
        probes(left.get("forward_probes", {}), right.get("forward_probes", {}))
    else:
        ls, rs = left.get("steps", []), right.get("steps", [])
        if not ls or len(ls) != len(rs):
            result["reasons"].append("training step count differs or is empty")
        for x, y in zip(ls, rs):
            for key in ("loss", "grad_norm"):
                maxima[key] = max(maxima[key], _maximum(x.get(key), y.get(key)))
            maxima["weights"] = max(maxima["weights"], _maximum(x.get("state"), y.get("state")))
            if not _exact(x.get("route"), y.get("route")):
                result["reasons"].append("training routes differ")
            probes(x.get("probes", {}), y.get("probes", {}))
        for name, snapshot in (("left", left), ("right", right)):
            if snapshot.get("determinism_refusal"):
                result["reasons"].append(f"{name}: {snapshot['determinism_refusal']}")
    for key, value in maxima.items():
        if not math.isfinite(value) or value > tolerances[key]:
            result["reasons"].append(f"{key} maximum {value!r} exceeds {tolerances[key]!r}")
        if not math.isfinite(value):
            maxima[key] = None
    result["passed"] = not result["reasons"]
    return result


def _state_hash(state):
    import torch
    h = hashlib.sha256()
    for key, tensor in state.items():
        h.update(key.encode())
        h.update(str(tensor.dtype).encode())
        h.update(str(tuple(tensor.shape)).encode())
        h.update(tensor.contiguous().reshape(-1).view(torch.uint8).numpy().tobytes())
    return h.hexdigest()


def _to_device(batch, device):
    return {key: value.to(device) for key, value in batch.items()}


def _probe(model, batches, device):
    import torch
    model.eval()
    result = {}
    logged = {}
    original_log = model.log
    model.log = lambda name, value, **kwargs: logged.update({name: value})
    try:
        for precision in ("float32", "bf16"):
            observations = []
            for i, batch in enumerate(batches):
                batch = _to_device(batch, device)
                logged.clear()
                context = torch.autocast(device_type=device, dtype=torch.bfloat16) if precision == "bf16" else nullcontext()
                with torch.no_grad(), context:
                    logits, labels = model.validation_step(batch, i)
                    loss = logged.get("valid_loss")
                    if loss is None:
                        raise RuntimeError("validation_step did not expose valid_loss")
                    scores = torch.softmax(logits.float(), dim=-1)[..., 1]
                observations.append({"loss": float(loss.detach().cpu()), "logits": _cpu(logits), "scores": _cpu(scores)})
            result[precision] = observations
    finally:
        model.log = original_log
    return result


def replay(model, captured, reference, layout, device, forward_only=False):
    import torch
    model.load_state_dict(reference["initial_state"], strict=True)
    model.to(device)
    result = dict(captured, steps=[])
    result["forward_probes"] = _probe(model, reference["validation_batches"], device)
    if forward_only:
        return result
    optimizer_spec = model.configure_optimizers()
    optimizer = optimizer_spec["optimizer"]
    base_cls = layout.mod["base_model"].FTTransformerHierModel
    target_module = layout.mod["target_ending_model"]
    original_step, original_target = base_cls._step, target_module.target_slot_outputs
    calls = {"base_step": 0, "target_slot": 0}
    def counted_step(*args, **kwargs):
        calls["base_step"] += 1
        return original_step(*args, **kwargs)
    def counted_target(*args, **kwargs):
        calls["target_slot"] += 1
        return original_target(*args, **kwargs)
    base_cls._step, target_module.target_slot_outputs = counted_step, counted_target
    original_log = model.log
    model.log = lambda *args, **kwargs: None
    try:
        for i, batch in enumerate(reference["train_batches"]):
            before = _cpu(model.state_dict())
            batch = _to_device(batch, device)
            torch.manual_seed(1000 + i)
            model.train()
            optimizer.zero_grad(set_to_none=True)
            calls.update(base_step=0, target_slot=0)
            context = torch.autocast(device_type="cuda", dtype=torch.bfloat16) if device == "cuda" else nullcontext()
            with context:
                loss = model.training_step(batch, i)
            loss.backward()
            norms = [p.grad.detach().double().norm(2) for p in model.parameters() if p.grad is not None]
            grad_norm = float(torch.stack(norms).norm(2).cpu()) if norms else 0.0
            route = dict(calls)
            optimizer.step()
            optimizer.zero_grad(set_to_none=True)
            state = _cpu(model.state_dict())
            probes = _probe(model, reference["validation_batches"], device)
            result["steps"].append({"loss": float(loss.detach().cpu()), "grad_norm": grad_norm,
                "state": state, "route": route, "weight_sha256": _state_hash(state),
                "max_abs_update": _maximum(before, state), "probes": probes})
    except RuntimeError as exc:
        if device != "cuda" or "determin" not in str(exc).lower():
            raise
        result["determinism_refusal"] = str(exc)
    finally:
        base_cls._step, target_module.target_slot_outputs = original_step, original_target
        model.log = original_log
    return result


def _module_inventory(root):
    root = Path(root).resolve()
    result = []
    for name, module in sorted(sys.modules.items()):
        file = getattr(module, "__file__", None)
        if file is None:
            continue
        path = Path(file).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            continue
        result.append({"name": name, "file": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    return result


def _worker(args):
    if args.device == "cpu":
        os.environ["CUDA_VISIBLE_DEVICES"] = ""
    import torch
    root = Path(args.root).resolve()
    sys.path[:0] = [str(root), str(root / "src")]
    os.chdir(root)
    common, paths, rules, layouts = _shared()
    torch.set_num_threads(4)
    torch.use_deterministic_algorithms(not args.forward_only)
    layout = layouts.resolve(root, expect=args.expect_layout)
    for role in ("trainer", "base_model", "target_ending_model"):
        if not Path(layout.file[role]).resolve().is_relative_to(root):
            raise ValueError(f"{role} imported outside requested root")
    fraud = sys.modules.get("fraud")
    if fraud and getattr(fraud, "__file__", None) and not Path(fraud.__file__).resolve().is_relative_to(root):
        raise ValueError("fraud imported outside requested root")
    out = Path(args.out).resolve()
    if not out.is_relative_to(Path(common.OUT).resolve() / "same_batch"):
        raise common.Refused(f"worker output must be under {Path(common.OUT) / 'same_batch'}: {out}")
    out.mkdir(parents=True, exist_ok=False)
    model, captured = capture_from_main(layout, args.config, out / "run", args.steps,
        args.validation_batches, args.chunk_cut)
    torch.save(captured, out / "captured.pt")
    reference = torch.load(args.reference, map_location="cpu", weights_only=False) if args.reference else captured
    try:
        result = replay(model, captured, reference, layout, args.device, args.forward_only)
    except RuntimeError as exc:
        if args.device != "cuda" or "determin" not in str(exc).lower():
            raise
        result = dict(captured, steps=[], determinism_refusal=str(exc))
    common.write_json(out / "modules.json", _module_inventory(root))
    torch.save(result, out / "result.pt")
    return 0


def _run_worker(label, root, expect, config, out, device, steps, validation_batches,
                chunk_cut, reference=None, forward_only=False):
    import torch
    common, paths, rules, layouts = _shared()
    destination = Path(out) / label
    command = [str(paths.PY), str(Path(__file__).resolve()), "worker", "--root", str(root),
        "--expect-layout", expect, "--config", str(config), "--out", str(destination),
        "--device", device, "--steps", str(steps), "--validation-batches", str(validation_batches)]
    if chunk_cut is not None:
        command += ["--chunk-cut", str(chunk_cut)]
    if reference is not None:
        command += ["--reference", str(reference)]
    if forward_only:
        command.append("--forward-only")
    env = os.environ.copy()
    env.pop("PYTHONPATH", None)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    if device == "cpu":
        env["CUDA_VISIBLE_DEVICES"] = ""
    log = Path(out) / (label + ".log")
    with log.open("w", encoding="utf-8") as stream:
        completed = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT)
    if completed.returncode:
        raise RuntimeError(f"{label} worker exited {completed.returncode}; see {log}")
    return torch.load(destination / "result.pt", map_location="cpu", weights_only=False)


def _module_differences(out, left="old", right="organized"):
    # Map only documented renamed modules; retain all unmatched helpers as evidence.
    replacements = {
        "waqas.v2.scripts.train_v2": "fraud.scripts.train_sequential_hier",
        "waqas.v2.scripts.score_v2": "fraud.scripts.score_sequential_hier",
        "waqas.v2.models": "fraud.sequential_hier_target_ending_model",
        "waqas.phase4b.sequential_hier": "fraud.sequential_hier_model",
        "waqas.phase4b.factory": "fraud.sequential_hier_factory",
        "waqas.phase4b.sequence_builder": "fraud.data.sequence_builder",
        "waqas.v2.target_ending": "fraud.data.target_ending",
        "waqas.phase4b.callbacks": "fraud.callbacks",
        "waqas.phase4b.tokenizer": "fraud.tokenizer",
        "waqas.phase4b.numerical_embeddings": "fraud.numerical_embeddings",
        "waqas.phase4b.optim": "fraud.optim",
        "waqas.base.data.parquet_loader": "fraud.data.parquet_loader",
        "waqas.base.data.input_contracts": "fraud.data.input_checks",
        "waqas.base.data.contracts": "fraud.data.input_contract",
        "waqas.base.data.checkpoint_contracts": "fraud.data.checkpoint_contract",
        "waqas.v2.storage": "fraud.data.s3_utils",
        "waqas.source_identity": "fraud.source_files",
        "waqas.scoring._prediction_utils": "fraud.data.prediction_files",
        "waqas.v2.analysis.paired_v2": "fraud.scripts.compare_models",
        "waqas.v2.analysis.business_metrics": "fraud.scripts.business_metrics",
    }
    inventories = []
    for name in (left, right):
        path = Path(out) / name / "modules.json"
        rows = json.loads(path.read_text()) if path.is_file() else []
        inventories.append(rows)
    a, b_rows = inventories
    b = {row["name"]: row for row in b_rows}
    differences, seen = [], set()
    for old in a:
        key = replacements.get(old["name"], old["name"])
        new = b.get(key)
        seen.add(key)
        if new is None or old["sha256"] != new["sha256"]:
            differences.append({"module": key, "old": old, "organized": new})
    differences.extend({"module": key, "old": None, "organized": b[key]}
                       for key in sorted(b.keys() - seen))
    return differences


def _resolved_config(path, root, out):
    from omegaconf import OmegaConf
    cfg = OmegaConf.load(path)
    for dotted in ("predictors.csv_path", "artifacts.base", "data.train_base", "data.val_base", "s3.cred_path"):
        value = OmegaConf.select(cfg, dotted)
        if value and isinstance(value, str) and "://" not in value and not Path(value).is_absolute():
            OmegaConf.update(cfg, dotted, str((Path(root) / value).resolve()))
    OmegaConf.update(cfg, "training.seed", 42)
    output = Path(out) / "config.yaml"
    OmegaConf.save(cfg, output, resolve=True)
    return output


def run_check(device="cpu", config=None, old_root=None, steps=None, validation_batches=None, chunk_cut=None):
    common, paths, rules, layouts = _shared()
    if device not in ("cpu", "cuda"):
        raise ValueError("device must be cpu or cuda")
    out = Path(common.OUT) / "same_batch" / device
    result_path = out / "result.json"
    if result_path.exists():
        return common.read_verdict(result_path)
    if out.exists() and any(out.iterdir()):
        raise common.Refused(f"partial same-batch output: {out}; use a new output folder")
    if device == "cuda":
        busy = common.busy_report()
        if busy:
            raise common.Refused(f"GPU is busy: {busy}")
    out.mkdir(parents=True, exist_ok=True)
    settings = rules.SAME_BATCH[device]
    steps = settings["steps"] if steps is None else steps
    validation_batches = settings["val"] if validation_batches is None else validation_batches
    chunk_cut = settings["chunk_cut"] if chunk_cut is None else chunk_cut
    if steps < 1 or validation_batches < 1 or (chunk_cut is not None and chunk_cut < 1):
        raise ValueError("batch and step counts must be positive")
    config = _resolved_config(config or Path(common.ROOT) / paths.BASE_CONFIG, common.ROOT, out)
    old_root = Path(old_root or paths.OLD_ROOT).resolve()
    tolerances = rules.TOLERANCE[device]
    forward_only = False
    self_result = None
    refusals = []
    def worker(label, root, expect, reference=None, forward=False):
        snapshot = _run_worker(label, root, expect, config, out, device, steps, validation_batches,
                               chunk_cut, reference=reference, forward_only=forward)
        if snapshot.get("determinism_refusal"):
            refusals.append(f"{label}: {snapshot['determinism_refusal']}")
        return snapshot
    if device == "cuda":
        first = worker("self_a", common.ROOT, "organized")
        second = worker("self_b", common.ROOT, "organized", out / "self_a" / "captured.pt")
        self_result = compare_snapshots(first, second, {key: 0.0 for key in tolerances})
        self_result["bitwise_equal"] = _exact(first, second)
        forward_only = not self_result["passed"] or not self_result["bitwise_equal"]
    left = worker("old", old_root, "old", forward=forward_only)
    right = worker("organized", common.ROOT, "organized", out / "old" / "captured.pt", forward_only)
    if device == "cuda" and not forward_only and (left.get("determinism_refusal") or right.get("determinism_refusal")):
        forward_only = True
        left = worker("old_forward", old_root, "old", forward=True)
        right = worker("organized_forward", common.ROOT, "organized", out / "old_forward" / "captured.pt", True)
    compared = compare_snapshots(left, right, tolerances, forward_only)
    left_name, right_name = ("old_forward", "organized_forward") if (out / "old_forward").exists() else ("old", "organized")
    differing = _module_differences(out, left_name, right_name)
    status = "GPU not deterministic; forward-only comparison" if forward_only else "training and forward comparison"
    result = common.write_verdict(result_path, compared["passed"], layout="organized", device=device,
        comparison=compared, tolerance=tolerances, mode=status, self_pair=self_result,
        module_differences=differing, determinism_refusals=refusals)
    print(result["verdict"] + ": " + status)
    if not result["passed"]:
        for difference in differing:
            print("differing module:", difference["module"], difference["old"], difference["organized"])
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command")
    worker = sub.add_parser("worker")
    for name in ("root", "expect-layout", "config", "out", "device"):
        worker.add_argument("--" + name, required=True)
    worker.add_argument("--steps", type=int, required=True)
    worker.add_argument("--validation-batches", type=int, required=True)
    worker.add_argument("--chunk-cut", type=int)
    worker.add_argument("--reference")
    worker.add_argument("--forward-only", action="store_true")
    for p in (parser, sub.add_parser("run")):
        p.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
        p.add_argument("--config")
        p.add_argument("--old-root")
        p.add_argument("--steps", type=int)
        p.add_argument("--validation-batches", type=int)
        p.add_argument("--chunk-cut", type=int)
    args = parser.parse_args(argv)
    try:
        if args.command == "worker":
            return _worker(args)
        result = run_check(args.device, args.config, args.old_root, args.steps, args.validation_batches, args.chunk_cut)
        return 0 if result["passed"] else 3
    except Exception as exc:
        common, _, _, _ = _shared()
        if isinstance(exc, common.Refused):
            print(f"REFUSED: {exc}", file=sys.stderr)
            return 4
        if isinstance(exc, (ValueError, common.ReproduceStop)):
            print(f"STOP: {exc}", file=sys.stderr)
            return 3
        raise


if __name__ == "__main__":
    raise SystemExit(main())
