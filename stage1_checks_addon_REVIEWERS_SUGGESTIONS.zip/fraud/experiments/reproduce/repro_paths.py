"""Locations for the stage 1 checks. This is the only file Copilot adapts for the pod.

ADAPT FOR THE POD (Copilot): the reviewers do not know the pod's exact folders. Before the first run, check every
value marked ADAPT against the pod and change only the value, never the logic, the rules or the other files. Replace
YOUR_ID with the pod user id. List each change for the owner. Every value can also be set for one run from the
environment, with the prefix REPRO_ (for example REPRO_OLD_ROOT=/path/to/tabular_fraud_old).

Where things run: every script in fraud/experiments/reproduce/ runs on the pod, from the current project folder
containing fraud/, with the project's Python (PY). ROOT is derived from the installed script location, or from
REPRO_PROJECT_ROOT when set. POD_PROJECT_ROOT below is the original prefix inside saved records, not the ROOT override. preflight.py --cpu-only runs on any workbench, with
CUDA_VISIBLE_DEVICES= set. start.sh runs the whole queue on a workbench whose GPU is free. Nothing runs on the work
laptop; there, Copilot only adapts the values below.
"""
import os
import sys


def _value(name, default):
    return os.environ.get("REPRO_" + name, default)


def _paths(name, defaults):
    value = os.environ.get("REPRO_" + name)
    return tuple(value.split(os.pathsep)) if value else tuple(defaults)


# ADAPT: the project's Python on the pod, the virtual environment the trainer runs in, for example
# /home/jovyan/YOUR_ID/<venv folder>/bin/python. The queue scripts take it from $PY.
PY = _value("PY", os.environ.get("PY") or sys.executable)
# ADAPT: the original project prefix stored in saved configs and receipts. A recorded path starting here is
# resolved under OLD_ROOT. This can equal the current project path, but changing it does not relocate current ROOT.
POD_PROJECT_ROOT = _value("POD_PROJECT_ROOT", "/home/jovyan/YOUR_ID/tabular_fraud")
# ADAPT: the old project folder kept after the reorganization (REORGANIZATION.md step 13 renamed it to
# tabular_fraud_old). The same-batch test runs the old code from here, and receipts that name the old project are
# looked up here.
OLD_ROOT = _value("OLD_ROOT", "/home/jovyan/YOUR_ID/tabular_fraud_old")
# ADAPT: folders searched for the kept seeds' original manifests, receipts and prediction files. Add a folder if
# they were moved somewhere else.
ARCHIVE_ROOTS = _paths("ARCHIVE_ROOTS", (OLD_ROOT,))
# ADAPT: where stage 0's runs wrote their run_manifest_v2.json files, relative to current ROOT (or absolute).
STAGE0_ROOTS = _paths("STAGE0_ROOTS", ("runs/tuning", "checkpoints"))
# ADAPT: the file name of stage 0's queue script as it is on the pod. The busy check looks for it.
STAGE0_QUEUE_NAME = _value("STAGE0_QUEUE_NAME", "lr_screen.sh")
# ADAPT: the folder with the kept seed42, seed43 and seed44 checkpoints of the chosen model, relative to the root.
KEPT_MODEL_DIR = _value("KEPT_MODEL_DIR", "models/sequential_hier_allpos_h20_chunk")
# ADAPT: the chosen model's base config in the organized tree, relative to the root.
BASE_CONFIG = _value("BASE_CONFIG", "fraud/configs/sequential_hier_allpos.yaml")
# Not a location: the scorer's population name for Test 1. Do not change it.
SCORE_POPULATION = _value("SCORE_POPULATION", "DEV_OOT")
