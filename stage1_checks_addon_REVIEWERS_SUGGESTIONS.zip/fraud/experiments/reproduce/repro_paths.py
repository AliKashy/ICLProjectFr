"""Locations for the reproduction checks; environment overrides use REPRO_."""
import os
import sys


def _value(name, default):
    return os.environ.get("REPRO_" + name, default)


def _paths(name, defaults):
    value = os.environ.get("REPRO_" + name)
    return tuple(value.split(os.pathsep)) if value else tuple(defaults)


PY = _value("PY", os.environ.get("PY") or sys.executable)
POD_PROJECT_ROOT = _value("POD_PROJECT_ROOT", "/home/jovyan/k194855/tabular_fraud")
OLD_ROOT = _value("OLD_ROOT", "/home/jovyan/k194855/tabular_fraud_old")
ARCHIVE_ROOTS = _paths("ARCHIVE_ROOTS", (OLD_ROOT,))
STAGE0_ROOTS = _paths("STAGE0_ROOTS", ("runs/tuning", "checkpoints"))
STAGE0_QUEUE_NAME = _value("STAGE0_QUEUE_NAME", "lr_screen.sh")
KEPT_MODEL_DIR = _value("KEPT_MODEL_DIR", "models/sequential_hier_allpos_h20_chunk")
BASE_CONFIG = _value("BASE_CONFIG", "fraud/configs/sequential_hier_allpos.yaml")
SCORE_POPULATION = _value("SCORE_POPULATION", "DEV_OOT")
