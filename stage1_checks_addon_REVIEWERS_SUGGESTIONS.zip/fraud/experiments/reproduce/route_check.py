"""Check chunk and target-ending loss routes on a tiny model and a kept checkpoint."""
import argparse
import hashlib
import math
import os
from pathlib import Path
import sys


def _shared():
    import repro_common
    import repro_paths
    import repro_layout
    return repro_common, repro_paths, repro_layout


def synthetic_batch(model, kind):
    """Build left-aligned, chronological examples at this model's actual widths."""
    import torch
    width = int(model.hparams.history_len) + 1
    if width < 3:
        raise ValueError("route diagnostics need history_len >= 2")
    n, continuous = 2, int(model.hparams.continuous_dim)
    categorical = len(model.hparams.categorical_cardinality)
    real = 1 if kind == 'single' else 3 if kind == 'two_labels' else min(width, 4)
    if kind == 'padded_label':
        real = min(width - 1, 2)
    mask = torch.arange(width).expand(n, -1) < real
    labels = torch.full((n, width), -100, dtype=torch.long)
    if kind in ('chunk', 'single'):
        labels[mask] = torch.arange(int(mask.sum())) % 2
    elif kind == 'two_labels':
        labels[:, :2] = torch.tensor([0, 1])
    elif kind == 'padded_label':
        labels[:, real] = torch.tensor([0, 1])
    elif kind == 'target':
        labels[:, real - 1] = torch.tensor([0, 1])
    else:
        raise ValueError(f"unknown route example {kind}")
    return {
        'continuous': torch.linspace(-0.5, 0.5, n * width * continuous).reshape(n, width, continuous),
        'categorical': torch.zeros(n, width, categorical, dtype=torch.long),
        'mask': mask, 'target_seq': labels,
        'time_seq': torch.arange(width).expand(n, -1) * 10**9,
    }


def _target_loss(model, batch):
    import torch
    selected = batch['target_seq'] != -100
    logits = model(batch)[selected]
    labels = batch['target_seq'][selected]
    return torch.nn.functional.cross_entropy(logits, labels, weight=model.loss_fn.weight, reduction='sum') / labels.numel()


def run_case(model, base_class, target_module, case_id, kind, expected_route, expect_error=False):
    """Count actual route calls independently of the loss-value comparison."""
    import torch
    batch = synthetic_batch(model, kind)
    counts = {'base_step': 0, 'target_slot': 0}
    original_step = base_class._step
    original_target = target_module.target_slot_outputs
    original_log = model.log
    model.log = lambda *args, **kwargs: None
    model.eval()
    error = None
    actual = expected = None
    def step(*args, **kwargs):
        counts['base_step'] += 1
        return original_step(*args, **kwargs)
    def target(*args, **kwargs):
        counts['target_slot'] += 1
        return original_target(*args, **kwargs)
    try:
        if not expect_error:
            with torch.no_grad():
                expected = float((original_step(model, batch, 'train')[2] if kind == 'chunk'
                                  else _target_loss(model, batch)).cpu())
        base_class._step, target_module.target_slot_outputs = step, target
        try:
            with torch.no_grad():
                actual = float(model.training_step(batch, 0).cpu())
        except ValueError as exc:
            error = str(exc)
    finally:
        base_class._step, target_module.target_slot_outputs = original_step, original_target
        model.log = original_log
    desired = {'base_step': 1, 'target_slot': 0} if expected_route == 'base' else {'base_step': 0, 'target_slot': 1}
    if expect_error:
        passed = error is not None and counts == desired
    else:
        passed = (error is None and counts == desired and actual is not None and expected is not None
                  and math.isfinite(actual) and math.isfinite(expected) and actual == expected)
    return {'case': case_id, 'passed': bool(passed), 'kind': kind, 'calls': counts,
            'expected_calls': desired, 'loss': actual, 'expected_loss': expected, 'error': error}


def _padded_observation(model):
    import torch
    original_log = model.log
    model.log = lambda *args, **kwargs: None
    try:
        with torch.no_grad():
            value = float(model.training_step(synthetic_batch(model, 'padded_label'), 0).cpu())
        return {'case': 'padded_slot', 'gating': False, 'outcome': 'returned_loss',
                'loss': value if math.isfinite(value) else None, 'finite': math.isfinite(value)}
    except Exception as exc:
        return {'case': 'padded_slot', 'gating': False, 'outcome': type(exc).__name__, 'error': str(exc)}
    finally:
        model.log = original_log


def check_routes(layout, checkpoint):
    """Use this layout's actual model classes; never fit or modify a checkpoint."""
    import torch
    base = layout.mod['base_model'].FTTransformerHierModel
    target_module = layout.mod['target_ending_model']
    target = target_module.FTTransformerHierTargetEnding
    torch.manual_seed(42)
    tiny = base(continuous_dim=2, categorical_cardinality=[3, 4], history_len=3, embed_dim=8,
                num_heads=2, num_txn_blocks=1, num_seq_blocks=1, ff_multiplier=2,
                attn_dropout=0.0, ff_dropout=0.0, attention_mask='causal',
                predict_every_transaction=True, all_position_layout='nonoverlapping_chunks',
                time_delta_reference='previous_transaction', history_time_order='strict')
    tiny.__class__ = target
    cases = []
    for case_id, kind, route, error in (
        ('A1', 'chunk', 'base', False), ('A2', 'target', 'target', False),
        ('A3', 'single', 'base', False), ('A4', 'two_labels', 'target', True),
    ):
        try:
            cases.append(run_case(tiny, base, target_module, case_id, kind, route, error))
        except Exception as exc:
            cases.append({'case': case_id, 'passed': False, 'error': f'{type(exc).__name__}: {exc}'})
    observation = _padded_observation(tiny)
    checkpoint = Path(checkpoint)
    before = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
    try:
        kept = base.load_from_checkpoint(str(checkpoint), map_location='cpu', weights_only=False)
        if not bool(kept.hparams.predict_every_transaction):
            raise ValueError('kept checkpoint is not an all-position model')
        if int(kept.hparams.history_len) != 20:
            raise ValueError('kept checkpoint must have history_len=20')
        kept.__class__ = target
        for case_id, kind, route in (('B1', 'chunk', 'base'), ('B2', 'target', 'target')):
            cases.append(run_case(kept, base, target_module, case_id, kind, route))
    except Exception as exc:
        cases.append({'case': 'B_load_or_route', 'passed': False, 'error': f'{type(exc).__name__}: {exc}'})
    after = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
    unchanged = before == after
    return {'passed': all(case['passed'] for case in cases) and unchanged, 'cases': cases,
            'observations': [observation], 'checkpoint': str(checkpoint),
            'checkpoint_sha256': before, 'checkpoint_unchanged': unchanged}


def run_check(checkpoint=None):
    # CPU checks do not inspect or initialize a GPU.
    os.environ['CUDA_VISIBLE_DEVICES'] = ''
    common, paths, layouts = _shared()
    output = Path(common.OUT) / 'route.json'
    if output.exists():
        return common.read_verdict(output)
    checkpoint = Path(checkpoint or Path(common.ROOT) / paths.KEPT_MODEL_DIR / 'seed42/best.ckpt')
    if not checkpoint.is_file():
        raise common.Refused(f'kept seed42 checkpoint not found: {checkpoint}')
    layout = layouts.resolve(common.ROOT)
    result = check_routes(layout, checkpoint)
    passed = result.pop('passed')
    written = common.write_verdict(output, passed, layout=layout.layout, **result)
    print(written['verdict'] + ': chunk and target-ending loss routes')
    return written


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkpoint')
    args = parser.parse_args(argv)
    try:
        return 0 if run_check(args.checkpoint)['passed'] else 3
    except Exception as exc:
        common, _, layouts = _shared()
        if isinstance(exc, (common.Refused, layouts.LayoutError)):
            print(f'REFUSED: {exc}', file=sys.stderr)
            return 4
        if isinstance(exc, common.ReproduceStop):
            print(f'STOP: {exc}', file=sys.stderr)
            return 3
        raise


if __name__ == '__main__':
    raise SystemExit(main())
