#!/usr/bin/env bash
# Runs on the pod, from the current project root (the folder containing the installed fraud/), on a workbench whose GPU is free.
# Usage: PY=<project python> bash fraud/experiments/reproduce/start.sh
# ADAPT: set PY to the project's Python on the pod, for example PY=/home/jovyan/YOUR_ID/<venv folder>/bin/python.
# It refuses (exit 4) while a trainer, scorer or queue runs. Logs: checkpoints/reproduce/logs/; progress at any
# time: $PY fraud/experiments/reproduce/report.py
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REAL_ROOT="$(cd -- "$SCRIPT_DIR/../../.." && pwd)"
PROJECT_ROOT="${REPRO_PROJECT_ROOT:-$REAL_ROOT}"
if [[ -n "${PYTEST_CURRENT_TEST:-}" && "$(cd -- "$PROJECT_ROOT" && pwd)" == "$REAL_ROOT" ]]; then
  echo "REFUSED: start.sh cannot launch against the real project during tests" >&2
  exit 4
fi
export REPRO_PROJECT_ROOT="$PROJECT_ROOT"
cd -- "$PROJECT_ROOT"
"${PY:-python}" "$SCRIPT_DIR/report.py" --busy-check "$@"
LOGS="$PROJECT_ROOT/checkpoints/reproduce/logs"
mkdir -p -- "$LOGS"
touch -- "$LOGS/queue.log"
date -u '+queue launch %Y-%m-%dT%H:%M:%SZ' >> "$LOGS/queue.out"
nohup bash "$SCRIPT_DIR/run_all.sh" "$@" >> "$LOGS/queue.out" 2>&1 &
QUEUE_PID=$!
echo "queue PID=$QUEUE_PID"
echo "report: ${PY:-python} $SCRIPT_DIR/report.py"
tail -n 20 -f -- "$LOGS/queue.log"
