#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REAL_ROOT="$(cd -- "$SCRIPT_DIR/../../.." && pwd)"
PROJECT_ROOT="${REPRO_PROJECT_ROOT:-$REAL_ROOT}"
if [[ -n "${PYTEST_CURRENT_TEST:-}" && "$(cd -- "$PROJECT_ROOT" && pwd)" == "$REAL_ROOT" ]]; then
  echo "REFUSED: start.sh cannot launch against the real project during tests" >&2
  exit 4
fi
export REPRO_PROJECT_ROOT="$PROJECT_ROOT"
cd -- "$PROJECT_ROOT"
"${PY:-python}" "$SCRIPT_DIR/report.py" --busy-check "$@"
LOGS="$PROJECT_ROOT/checkpoints/reproduce/logs"
mkdir -p -- "$LOGS"
touch -- "$LOGS/queue.log"
date -u '+queue launch %Y-%m-%dT%H:%M:%SZ' >> "$LOGS/queue.out"
nohup bash "$SCRIPT_DIR/run_all.sh" "$@" >> "$LOGS/queue.out" 2>&1 &
QUEUE_PID=$!
echo "queue PID=$QUEUE_PID"
echo "report: ${PY:-python} $SCRIPT_DIR/report.py"
tail -n 20 -f -- "$LOGS/queue.log"
