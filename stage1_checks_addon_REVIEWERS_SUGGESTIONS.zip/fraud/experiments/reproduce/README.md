Run `bash fraud/experiments/reproduce/run_all.sh` from the project root; add `--cpu-only` for the CPU checks.
This package checks retained models without retraining; results are written to `checkpoints/reproduce/REPORT.txt`.
