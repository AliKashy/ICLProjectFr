"""Shared filesystem, process and result helpers for reproduction checks."""
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import socket
import subprocess
import tempfile
import textwrap

try:
    from . import repro_paths as paths, repro_rules as rules
except ImportError:
    import repro_paths as paths
    import repro_rules as rules


ROOT = Path(os.environ.get("REPRO_PROJECT_ROOT") or Path(__file__).resolve().parents[3]).resolve()
OUT = ROOT / "checkpoints" / "reproduce"
OK, CRASH, BADARGS, STOP, REFUSED = 0, 1, 2, 3, 4


class ReproduceStop(Exception):
    """A reproduction comparison did not meet its declared rule."""


class Refused(Exception):
    """Inputs, existing outputs or running work prevent this check."""


def utc_now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    def invalid(value):
        raise ValueError(f"non-finite JSON number: {value}")

    def number(value):
        parsed = float(value)
        return parsed if math.isfinite(parsed) else invalid(value)

    with Path(path).open(encoding="utf-8") as stream:
        return json.load(stream, parse_constant=invalid, parse_float=number)


def write_json(path, obj):
    """Publish one complete JSON file with a same-directory atomic replacement."""
    payload = json.dumps(obj, indent=2, allow_nan=False) + "\n"
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
                                         prefix="." + path.name + ".", delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def write_verdict(path, passed, **fields):
    if type(passed) is not bool:
        raise TypeError("passed must be a boolean")
    result = {**fields, "passed": passed, "verdict": "PASS" if passed else "STOP", "utc": utc_now()}
    write_json(path, result)
    return result


def read_verdict(path):
    result = read_json(path)
    if not isinstance(result, dict) or type(result.get("passed")) is not bool:
        raise Refused(f"incomplete result, no verdict: {path}")
    return result


def rel(path):
    path = Path(path).resolve()
    return str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)


def flatten(obj, prefix=""):
    result = {}
    if isinstance(obj, dict):
        for key, value in obj.items():
            name = f"{prefix}.{key}" if prefix else str(key)
            if isinstance(value, dict) and value:
                result.update(flatten(value, name))
            else:
                result[name] = value
    elif prefix:
        result[prefix] = obj
    return result


def diff_configs(a, b, ignore=()):
    left, right = flatten(a), flatten(b)
    return [(key, left.get(key), right.get(key)) for key in sorted(left.keys() | right.keys())
            if not any(key.startswith(prefix) for prefix in ignore)
            and (key not in left or key not in right or left[key] != right[key])]


def map_old_path(path):
    value, prefix = str(path), str(paths.POD_PROJECT_ROOT).rstrip("/")
    if value == prefix or value.startswith(prefix + "/"):
        return str(paths.OLD_ROOT).rstrip("/") + value[len(prefix):]
    return value


def _hostname():
    return socket.gethostname()


def _alive(pid):
    try:
        os.kill(int(pid), 0)
        return True
    except PermissionError:
        return True
    except (OSError, ValueError, TypeError):
        return False


def _proc_rows():
    for folder in Path("/proc").iterdir():
        if not folder.name.isdigit():
            continue
        try:
            argv = (folder / "cmdline").read_bytes().decode(errors="replace").strip("\0").split("\0")
            status = (folder / "status").read_text()
            ppid = int(re.search(r"^PPid:\s+(\d+)", status, re.MULTILINE).group(1))
            yield {"pid": int(folder.name), "ppid": ppid, "cmdline": " ".join(argv)}
        except (OSError, ValueError, AttributeError):
            continue


def _ancestors(pid=None):
    pid = os.getpid() if pid is None else int(pid)
    seen = set()
    while pid > 0 and pid not in seen:
        seen.add(pid)
        try:
            status = Path(f"/proc/{pid}/status").read_text()
            pid = int(re.search(r"^PPid:\s+(\d+)", status, re.MULTILINE).group(1))
        except (OSError, ValueError, AttributeError):
            break
    return seen


def _is_workload(command):
    python = r"(?:\S*/)?python(?:3(?:\.\d+)?)?(?:\s+-\S+)*\s+"
    module = r"(?:fraud\.scripts\.(?:train|score)_\S*|waqas\.\S*\.(?:train|score)\S*)"
    script = r"(?:\S*/)?(?:train_v2|score_v2|train_sequential[^\s/]*|score_sequential[^\s/]*|train_timed|width_timing|same_batch)\.py"
    if re.match(r"^" + python + "(?:" + module + "|" + script + r")(?:\s|$)", command):
        return True
    # A shell command string is not a launched queue script.
    if re.match(r"^(?:\S*/)?bash\s+(?:-\S+\s+)*-c(?:\s|$)", command):
        return False
    queue = re.escape(Path(paths.STAGE0_QUEUE_NAME).name)
    return bool(re.match(r"^(?:\S*/)?bash(?:\s+-\S+)*\s+(?:\S*/)?(?:" + queue
                         + r"|run_all\.sh)(?:\s|$)", command))


def _nvidia(query, kind="gpu"):
    try:
        result = subprocess.run(["nvidia-smi", f"--query-{kind}={query}", "--format=csv,noheader,nounits"],
                                capture_output=True, text=True, timeout=5, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return []
    if result.returncode:
        return []
    return [[item.strip() for item in row] for row in csv.reader(io.StringIO(result.stdout)) if row]


def gpu_info():
    rows = _nvidia("index,uuid,name,driver_version,memory.total,memory.used")
    gpus = [dict(zip(("index", "uuid", "name", "driver_version", "memory_total_mib", "memory_used_mib"), row))
            for row in rows if len(row) == 6]
    return {**gpus[0], "gpus": gpus} if gpus else {}


def busy_report(exclude_pids=()):
    excluded = _ancestors() | {int(pid) for pid in exclude_pids}
    found = []
    for row in _proc_rows():
        if row["pid"] not in excluded and _is_workload(row["cmdline"]):
            found.append({"kind": "process", "pid": row["pid"], "cmdline": row["cmdline"],
                          "path": None, "detail": "trainer, scorer or queue is running"})
    own_gpu = set()
    for row in _nvidia("pid,gpu_uuid,used_gpu_memory", "compute-apps"):
        if len(row) < 3:
            continue
        try:
            pid = int(row[0])
        except ValueError:
            continue
        if pid in excluded:
            own_gpu.add(row[1])
        else:
            found.append({"kind": "gpu", "pid": pid, "cmdline": None, "path": None,
                          "detail": f"GPU {row[1]} compute process uses {row[2]} MiB"})
    for gpu in gpu_info().get("gpus", []):
        try:
            used = float(gpu["memory_used_mib"])
        except (ValueError, TypeError):
            continue
        if used > rules.BUSY_GPU_MIB and gpu["uuid"] not in own_gpu:
            found.append({"kind": "gpu", "pid": None, "cmdline": None, "path": None,
                          "detail": f"GPU {gpu['uuid']} has {used} MiB used with no process of ours"})
    roots = [ROOT / value for value in paths.STAGE0_ROOTS] + [ROOT / "checkpoints"]
    seen = set()
    for root in roots:
        if not root.is_dir():
            continue
        for lock in root.rglob("RUNNING.lock.json"):
            if lock.resolve() in seen:
                continue
            seen.add(lock.resolve())
            try:
                record = read_json(lock)
                pid = record.get("pid")
                host = record.get("hostname", record.get("host", _hostname()))
                if (type(pid) is int and pid > 0 and pid not in excluded and host == _hostname() and _alive(pid)):
                    found.append({"kind": "lock", "pid": pid, "cmdline": None, "path": str(lock),
                                  "detail": f"live lock on {host}"})
            except (OSError, ValueError, AttributeError):
                continue
    return found


def print_lines(lines, path=None):
    rendered = []
    for value in lines:
        for line in str(value).splitlines() or [""]:
            rendered.extend(textwrap.wrap(line, width=90, subsequent_indent="  ",
                                          replace_whitespace=False, drop_whitespace=False,
                                          break_long_words=True, break_on_hyphens=False) or [""])
    text = "\n".join(rendered) + "\n"
    print(text, end="", flush=True)
    if path is not None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")


def run_logged(name, argv, env=None):
    if Path(name).name != name or name in ("", ".", ".."):
        raise Refused(f"invalid log name: {name}")
    logs = OUT / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    environment = dict(os.environ)
    if env is not None:
        environment.update(env)
    with (logs / (name + ".log")).open("ab") as stream:
        stream.write((f"start {name} {utc_now()}\n").encode())
        stream.flush()
        result = subprocess.run([str(value) for value in argv], cwd=ROOT, env=environment,
                                stdout=stream, stderr=subprocess.STDOUT, check=False)
        stream.write((f"end {name} rc={result.returncode} {utc_now()}\n").encode())
    return result.returncode
