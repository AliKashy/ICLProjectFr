"""Check the layout, retained checkpoints and source continuity before scoring."""
import argparse
import csv
import importlib
import importlib.metadata
import math
from pathlib import Path
import shutil
import sys


MANIFEST = "run_manifest_v2.json"


def _dependencies():
    folder = str(Path(__file__).resolve().parent)
    if folder not in sys.path:
        sys.path.insert(0, folder)
    return tuple(importlib.import_module(n) for n in
                 ("repro_common", "repro_paths", "repro_rules", "repro_layout"))


def _inside(path, folder):
    try:
        Path(path).resolve().relative_to(Path(folder).resolve())
        return True
    except ValueError:
        return False


def _at(root, path):
    path = Path(path)
    return path if path.is_absolute() else Path(root) / path


def latest_identity(manifest):
    events = [manifest.get("start", {})] + list(manifest.get("resume_events", []))
    event = events[-1]
    return event.get("identity", {}) if isinstance(event, dict) else {}


def stage0_manifests(root, roots, out):
    found = set()
    for name in roots:
        folder = _at(root, name)
        for path in folder.rglob(MANIFEST) if folder.is_dir() else ():
            if path.is_file() and not _inside(path, out):
                found.add(path.resolve())
    return sorted(found)


def check_source(common, paths, layout, roots):
    trainer = layout.mod["trainer"]
    files = trainer.source_files()
    file_names = list(files) if isinstance(files, dict) else files
    included = [str(p) for p in file_names
                if _inside(_at(common.ROOT, p), common.ROOT / "fraud/experiments/reproduce")]
    if included:
        raise ValueError("reproduction files are in the trainer source hash: " + ", ".join(included))
    prefixes = getattr(layout.mod["source_list"], "EXCLUDED_SOURCE_PREFIXES", ())
    if "fraud/experiments/" not in prefixes:
        raise ValueError("EXCLUDED_SOURCE_PREFIXES does not include fraud/experiments/")
    current = trainer.source_sha256()
    found = stage0_manifests(common.ROOT, roots, common.OUT)
    if not found:
        raise ValueError("no stage 0 manifest under " + ", ".join(str(_at(common.ROOT, p)) for p in roots)
                         + "; pass --stage0-root <dir>")
    records, problems = [], []
    for path in found:
        obj = common.read_json(path)
        identity = latest_identity(obj)
        old = identity.get("source_sha256")
        rec = {"path": str(path), "status": obj.get("status"), "source_sha256": old}
        records.append(rec)
        common.print_lines([f"P1b {path} status={obj.get('status')} source_sha256={old}"])
        if old != current:
            problems.append(f"{path}: recorded source {old!r} differs from current {current!r}")
    if problems:
        raise ValueError("; ".join(problems))
    return {"source_sha256": current, "stage0": records}


def _original_records(common, paths, seed_dir, digest):
    manifests, receipts, seen = [], [], set()
    for root in [seed_dir / "scores"] + [_at(common.ROOT, p) for p in paths.ARCHIVE_ROOTS]:
        for path in sorted(root.rglob("*.json")) if root.is_dir() else ():
            real = path.resolve()
            if real in seen or not path.is_file() or path.stat().st_size >= 1_000_000:
                continue
            seen.add(real)
            try:
                obj = common.read_json(path)
            except (OSError, ValueError):
                continue
            if not isinstance(obj, dict):
                continue
            checkpoints = obj.get("checkpoints") or {}
            best = checkpoints.get("best.ckpt") if isinstance(checkpoints, dict) else None
            if isinstance(best, dict) and best.get("sha256") == digest:
                manifests.append(str(path))
            files = obj.get("files") or {}
            if (obj.get("checkpoint_sha256") == digest and isinstance(files, dict)
                    and (files.get("start"), files.get("end")) in ((8000, 8010), (8206, 8216))
                    and all(k in obj for k in ("average_precision", "n_predictions", "predictions_sha256", "scoring"))
                    and "operation" not in obj and "attempt_id" not in obj):
                receipts.append(str(path))
    return manifests, receipts


def _load_checkpoint(path):
    import torch
    return torch.load(path, map_location="cpu", weights_only=False)


def check_checkpoints(common, paths, rules, checkpoint_loader=None):
    load = checkpoint_loader or _load_checkpoint
    records = {}
    for seed in (42, 43, 44):
        folder = _at(common.ROOT, paths.KEPT_MODEL_DIR) / f"seed{seed}"
        if (folder / MANIFEST).exists():
            raise ValueError(f"retained model contains {MANIFEST}; scorer would append to it: {folder}")
        checkpoint = folder / "best.ckpt"
        if not checkpoint.is_file():
            raise ValueError(f"checkpoint missing: {checkpoint}")
        digest = common.sha256_file(checkpoint)
        manifests, receipts = _original_records(common, paths, folder, digest)
        if not manifests:
            raise ValueError(f"no original manifest matches checkpoint sha256 {digest}: {checkpoint}")
        obj = load(checkpoint)
        policy = obj.get("validation_policy") or {}
        if (not isinstance(policy, dict) or policy.get("name") != rules.VALIDATION_POLICY
                or policy.get("max_window_rows") != rules.WINDOW_CAP):
            raise ValueError(f"wrong validation policy in {checkpoint}: {policy!r}")
        metrics = folder / "training_metrics.csv"
        if not metrics.is_file():
            raise ValueError(f"training metrics missing: {metrics}")
        valid = []
        with metrics.open(newline="", encoding="utf-8") as stream:
            for row in csv.DictReader(stream):
                if not row.get("valid_ap", "").strip():
                    continue
                ap = float(row["valid_ap"])
                epoch = int(row["epoch"])
                if not math.isfinite(ap):
                    raise ValueError(f"non-finite valid_ap in {metrics}")
                valid.append((epoch, ap))
        if not valid:
            raise ValueError(f"no validation AP rows in {metrics}")
        best_ap = max(ap for _, ap in valid)
        best_epochs = {epoch for epoch, ap in valid if ap == best_ap}
        if obj.get("epoch") not in best_epochs:
            raise ValueError(f"checkpoint epoch {obj.get('epoch')!r} is not a highest-valid_ap epoch "
                             f"{sorted(best_epochs)} in {metrics}")
        rec = {"checkpoint": str(checkpoint), "sha256": digest, "epoch": obj["epoch"],
               "best_valid_ap": best_ap, "validation_policy": policy,
               "original_manifests": manifests, "original_receipts": receipts}
        if not receipts:
            rec["receipt_note"] = "receipt not found: rescore uses the recorded six-decimal fallback"
        records[str(seed)] = rec
        common.print_lines([f"P4 seed {seed} {checkpoint} sha256={digest}",
                            f"P4 epoch={obj['epoch']} best_valid_ap={best_ap!r} manifests={manifests} receipts={receipts}"])
    return records


def environment(common):
    result = {"python": sys.version, "gpu": common.gpu_info(),
              "cuda": getattr(getattr(sys.modules.get("torch"), "version", None), "cuda", None)}
    for name in ("torch", "pytorch-lightning"):
        try:
            result[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            result[name] = "not installed"
    # Version metadata does not initialize CUDA; GPU and driver come from nvidia-smi.
    return result


def run_checks(common, paths, rules, resolver, *, cpu_only=False, stage0_roots=None,
               checkpoint_loader=None, disk_usage=None):
    checks, problems, layout_name = {}, [], "unresolved"
    layout = None
    try:
        layout = resolver.resolve(common.ROOT)
        layout_name = layout.layout
        common.print_lines(layout.describe())
        checks["P1a"] = {"passed": True, "layout": layout_name}
    except Exception as exc:
        checks["P1a"] = {"passed": False, "reason": str(exc)}
        problems.append(f"P1a: {exc}")
    if layout is not None:
        try:
            checks["P1b"] = dict(check_source(common, paths, layout, stage0_roots or paths.STAGE0_ROOTS), passed=True)
        except Exception as exc:
            checks["P1b"] = {"passed": False, "reason": str(exc)}
            problems.append(f"P1b: {exc}")
    try:
        checks["P4"] = {"passed": True, "seeds": check_checkpoints(common, paths, rules, checkpoint_loader)}
    except Exception as exc:
        checks["P4"] = {"passed": False, "reason": str(exc)}
        problems.append(f"P4: {exc}")
    busy = [] if cpu_only else common.busy_report()
    checks["P6"] = {"passed": not busy, "cpu_only": cpu_only, "busy": busy}
    free_gb = (disk_usage or shutil.disk_usage)(common.ROOT).free / (1024 ** 3)
    disk_ok = free_gb >= rules.MIN_FREE_GB
    checks["P7"] = {"passed": disk_ok, "free_gb": free_gb, "minimum_gb": rules.MIN_FREE_GB}
    common.print_lines([f"P7 free disk {free_gb!r} GiB; minimum {rules.MIN_FREE_GB} GiB"])
    if not disk_ok:
        problems.append(f"P7: free disk {free_gb!r} GiB is below {rules.MIN_FREE_GB} GiB")
    checks["P8"] = {"passed": True, "environment": environment(common)}
    common.print_lines([f"P8 {checks['P8']['environment']!r}"])
    if busy:
        common.print_lines([f"P6 busy: {item!r}" for item in busy])
    passed = not problems and not busy
    result = common.write_verdict(common.OUT / "preflight.json", passed, layout=layout_name,
                                  checks=checks, problems=problems, busy=busy)
    common.print_lines([f"preflight {'PASS' if passed else 'STOP'}"] + problems)
    return common.STOP if problems else common.REFUSED if busy else common.OK


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cpu-only", action="store_true")
    parser.add_argument("--stage0-root", action="append", help="additional stage 0 manifest root")
    args = parser.parse_args(argv)
    common, paths, rules, resolver = _dependencies()
    roots = tuple(paths.STAGE0_ROOTS) + tuple(args.stage0_root or ())
    return run_checks(common, paths, rules, resolver, cpu_only=args.cpu_only, stage0_roots=roots)


if __name__ == "__main__":
    raise SystemExit(main())
