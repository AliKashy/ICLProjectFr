"""Rescore retained checkpoints, then compare their saved Test 1 outputs.

This driver never trains. Original records are identified by checkpoint and
population content, rather than by the current location of an old run.
"""
import argparse
from datetime import datetime
import importlib
import json
import os
from pathlib import Path
import sys
import time


def _dependencies():
    folder = str(Path(__file__).resolve().parent)
    if folder not in sys.path:
        sys.path.insert(0, folder)
    return tuple(importlib.import_module(name) for name in
                 ("repro_common", "repro_paths", "repro_rules", "repro_layout"))


def _comparator():
    folder = str(Path(__file__).resolve().parent)
    if folder not in sys.path:
        sys.path.insert(0, folder)
    return importlib.import_module("compare_predictions").compare_outputs


def _json_files(roots):
    seen = set()
    for root in roots:
        root = Path(root)
        if not root.is_dir():
            continue
        for path in sorted(root.rglob("*.json")):
            resolved = path.resolve()
            if resolved in seen or not path.is_file():
                continue
            seen.add(resolved)
            try:
                with path.open(encoding="utf-8") as stream:
                    obj = json.load(stream)
            except (OSError, ValueError):
                continue
            if isinstance(obj, dict):
                yield path, obj


def discover_originals(common, paths, seed_dir, checkpoint_sha, seed, file_start, file_end):
    """Find receipts, completed exposures and manifests using their contents."""
    roots = [Path(seed_dir) / "scores"] + [Path(p) for p in paths.ARCHIVE_ROOTS]
    receipts, exposures, manifests = [], [], []
    for path, obj in _json_files(roots):
        checkpoints = obj.get("checkpoints", {})
        best = checkpoints.get("best.ckpt", {}) if isinstance(checkpoints, dict) else {}
        if isinstance(best, dict) and best.get("sha256") == checkpoint_sha:
            manifests.append((path, obj))
        files = obj.get("files", {})
        if (obj.get("checkpoint_sha256") != checkpoint_sha or not isinstance(files, dict)
                or (files.get("start"), files.get("end")) != (file_start, file_end)):
            continue
        if obj.get("operation") == "score_v2" and obj.get("status") == "completed":
            exposures.append((path, obj))
        if (all(k in obj for k in ("average_precision", "n_predictions", "predictions_sha256", "scoring"))
                and "attempt_id" not in obj and "operation" not in obj):
            receipts.append((path, obj))
    common.print_lines([f"original receipt match: {path} AP={obj['average_precision']!r}"
                        for path, obj in receipts])
    selected = None
    if receipts:
        signatures = {(obj.get("average_precision"), obj.get("n_predictions"), obj.get("n_positives"),
                       obj.get("predictions_sha256")) for _, obj in receipts}
        preferred = [(p, r) for p, r in receipts if
                     (seed == 42 and "runs/v2/L3/scores_slide/" in p.as_posix()) or
                     (seed in (43, 44) and p.name == "score_DEV_OOT.parquet.json")]
        choices = preferred or receipts
        if len(signatures) > 1 and len(preferred) != 1:
            raise common.Refused(f"ambiguous original receipts for seed {seed}: {[str(p) for p, _ in receipts]}")
        selected = choices[0]
    receipt_path, receipt = selected if selected else (None, None)
    matched_exposures = [(p, obj) for p, obj in exposures
                        if receipt is None or obj.get("predictions") == receipt.get("predictions")]
    common.print_lines([f"original completed exposure match: {p}" for p, _ in matched_exposures])
    exposure = matched_exposures[0][1] if matched_exposures else None
    prediction = None
    if receipt is not None:
        raw = receipt.get("predictions")
        candidates = []
        if isinstance(raw, str) and raw:
            candidates = [Path(common.map_old_path(raw)), Path(raw), receipt_path.parent / Path(raw).name]
            if not Path(raw).is_absolute():
                candidates.insert(0, receipt_path.parent / raw)
        for candidate in dict.fromkeys(candidates):
            if candidate.is_file() and common.sha256_file(candidate) == receipt["predictions_sha256"]:
                prediction = candidate
                break
        if prediction is None and any(p.is_file() for p in candidates):
            raise common.Refused(f"original prediction hash does not match receipt {receipt_path}")
    return {"receipt_path": receipt_path, "receipt": receipt, "predictions": prediction,
            "exposure": exposure, "manifest": manifests[0][1] if manifests else None,
            "receipt_matches": [str(p) for p, _ in receipts],
            "exposure_matches": [str(p) for p, _ in matched_exposures],
            "manifest_matches": [str(p) for p, _ in manifests]}


def _tree_hashes(folder, common):
    return {str(path.relative_to(folder)): common.sha256_file(path)
            for path in sorted(Path(folder).rglob("*")) if path.is_file()}


def _config(path):
    from omegaconf import OmegaConf
    cfg = OmegaConf.to_container(OmegaConf.load(path), resolve=True)
    if not isinstance(cfg, dict):
        raise ValueError(f"config must be a mapping: {path}")
    return cfg


def _settings(cfg, original, common, rules):
    training, sequence = cfg.get("training", {}), cfg.get("sequence", {})
    batch = training.get("eval_batch_size") or training.get("batch_size")
    cap = sequence.get("max_window_rows")
    if cap is None:
        cap = rules.WINDOW_CAP
    if type(batch) is not int or batch <= 0 or type(cap) is not int or cap <= 0:
        raise common.Refused("eval_batch_size and max_window_rows must be positive integers")
    receipt = original["receipt"]
    if receipt:
        for key, value in (("eval_batch_size", batch), ("max_window_rows", cap)):
            if receipt.get(key) != value:
                raise common.Refused(f"{key} differs before scoring: config={value!r}, original={receipt.get(key)!r}")
        score_config = original["receipt_path"].parent / "resolved_score.yaml"
        if score_config.is_file():
            old = _config(score_config)
            for key, current, previous in (
                    ("num_workers", training.get("num_workers", 0), old.get("training", {}).get("num_workers", 0)),
                    ("eval.base", cfg.get("eval", {}).get("base"), old.get("eval", {}).get("base"))):
                if current != previous:
                    raise common.Refused(f"{key} differs before scoring: config={current!r}, original={previous!r}")
    return batch, cap


def _runtime(common):
    try:
        import torch
        return {"torch": torch.__version__, "cuda": torch.version.cuda, "gpu": common.gpu_info()}
    except ImportError:
        return {"torch": None, "cuda": None, "gpu": common.gpu_info()}


def _record_override_eligible(record):
    if record.get("passed") or record.get("result") != "STOP" or record.get("model_tree_changed"):
        return False
    rows = record.get("rows", {})
    if not rows.get("available") or any(rows.get(key, 0) for key in (
            "only_current", "only_original", "label_differences", "window_rows_differences",
            "window_truncated_differences")):
        return False
    receipts = record.get("receipts", {})
    for name in ("current", "original"):
        receipt, computed = receipts.get(name), receipts.get(name + "_recomputed")
        if not receipt or not computed or any(receipt.get(key) != computed.get(key) for key in
                                               ("average_precision", "n_predictions", "n_positives")):
            return False
    return True


def _override_allowed(summary):
    if not summary.get("seeds") or set(summary["seeds"]) != {"42", "43", "44"}:
        return False
    for record in summary["seeds"].values():
        if record.get("passed"):
            continue
        if not _record_override_eligible(record):
            return False
    return True


def _apply_override(summary, reason, common):
    if reason is not None and not reason.strip():
        raise common.Refused("--accept-rescore-gap requires a nonempty owner reason")
    summary["acceptance_eligible"] = bool(not summary["passed"] and _override_allowed(summary))
    summary["accepted_gap"] = bool(reason and summary["acceptance_eligible"])
    summary["accept_rescore_gap_reason"] = reason
    summary["accept_rescore_gap"] = reason
    for record in summary.get("seeds", {}).values():
        record["acceptance_eligible"] = _record_override_eligible(record)
        record["accepted_gap"] = bool(summary["accepted_gap"] and record["acceptance_eligible"])
        record["accept_rescore_gap_reason"] = reason if record["accepted_gap"] else None
    if reason and not summary["passed"] and not summary["accepted_gap"]:
        summary.setdefault("reasons", []).append("rescore gap not accepted: missing row evidence or non-metric failure")
    failure_code = summary.get("exit_code") if summary.get("exit_code") in (1, 4) else 3
    summary["exit_code"] = 0 if summary["passed"] or summary["accepted_gap"] else failure_code
    return summary


def _write(common, path, report):
    fields = {key: value for key, value in report.items() if key not in ("passed", "verdict", "utc")}
    return common.write_verdict(path, bool(report["passed"]), **fields)


def _exposure_seconds(exposure):
    if not isinstance(exposure, dict):
        return None
    try:
        started = datetime.fromisoformat(exposure["utc"].replace("Z", "+00:00"))
        ended = datetime.fromisoformat(exposure["ended_utc"].replace("Z", "+00:00"))
        elapsed = (ended - started).total_seconds()
        return elapsed if elapsed >= 0 else None
    except (KeyError, ValueError, TypeError, AttributeError):
        return None


def run_rescore(common, paths, rules, layout_module, *, purpose=None, accept_rescore_gap=None,
                out=None, config=None):
    """Score all three retained seeds before applying their metric stop rules."""
    root, allowed = Path(common.ROOT).resolve(), Path(common.OUT).resolve()
    destination = Path(out).resolve() if out else allowed / "rescore"
    if not destination.is_relative_to(allowed) or destination == allowed:
        raise common.Refused(f"--out must be a subdirectory of {allowed}")
    summary_path = destination / "summary.json"
    if summary_path.exists():
        saved = common.read_verdict(summary_path)
        for seed in (42, 43, 44):
            checkpoint = root / paths.KEPT_MODEL_DIR / f"seed{seed}" / "best.ckpt"
            record = saved.get("seeds", {}).get(str(seed), {})
            if not checkpoint.is_file() or record.get("checkpoint_sha256") != common.sha256_file(checkpoint):
                raise common.Refused(f"cached comparison checkpoint differs or is missing: {checkpoint}")
            folder = destination / f"seed{seed}"
            prediction = folder / "test1.parquet"
            receipt_path = Path(str(prediction) + ".json")
            if not all(p.is_file() for p in (prediction, receipt_path, folder / "compare.json")):
                raise common.Refused(f"partial outputs; rename {folder}")
            comparison = common.read_verdict(folder / "compare.json")
            receipt = common.read_json(receipt_path)
            if (receipt.get("checkpoint_sha256") != record["checkpoint_sha256"] or
                    receipt.get("predictions_sha256") != common.sha256_file(prediction) or
                    comparison.get("passed") != record.get("passed")):
                raise common.Refused(f"cached output hash or verdict differs: {folder}")
        if saved["passed"] != all(r.get("passed") is True for r in saved["seeds"].values()):
            raise common.Refused(f"cached summary verdict contradicts its seeds: {summary_path}")
        saved["exit_code"] = 0 if saved["passed"] else 3
        common.print_lines([f"skip rescore, exists; rename {destination} to run it again"])
        saved = _apply_override(saved, accept_rescore_gap, common)
        for seed, record in saved["seeds"].items():
            saved["seeds"][seed] = _write(common, destination / f"seed{seed}" / "compare.json", record)
        return _write(common, summary_path, saved)
    if accept_rescore_gap is not None and not accept_rescore_gap.strip():
        raise common.Refused("--accept-rescore-gap requires a nonempty owner reason")
    busy = common.busy_report()
    if busy:
        raise common.Refused(f"busy: {busy}")
    layout = layout_module.resolve(root)
    common.print_lines(layout.describe())
    seeds, plans = {}, []
    start, end = rules.TEST1_FILES
    for seed in (42, 43, 44):
        model_dir = root / paths.KEPT_MODEL_DIR / f"seed{seed}"
        checkpoint = model_dir / "best.ckpt"
        if not checkpoint.is_file():
            raise common.Refused(f"kept checkpoint missing: {checkpoint}")
        if (model_dir / "run_manifest_v2.json").exists():
            raise common.Refused(f"kept model folder contains run_manifest_v2.json: {model_dir}")
        checkpoint_sha = common.sha256_file(checkpoint)
        original = discover_originals(common, paths, model_dir, checkpoint_sha, seed, start, end)
        config_path = Path(config) if config else model_dir / "config.yaml"
        if not config_path.is_absolute():
            config_path = root / config_path
        if config is None and not config_path.is_file():
            config_path = root / paths.BASE_CONFIG
        cfg = _config(config_path)
        batch, cap = _settings(cfg, original, common, rules)
        label, ids = cfg.get("data", {}).get("target_col"), cfg.get("data", {}).get("id_cols")
        if not label or not isinstance(ids, list) or not ids:
            raise common.Refused(f"config needs data.target_col and data.id_cols: {config_path}")
        exposure = original["exposure"]
        selected_purpose = purpose or (exposure or {}).get("purpose")
        if not isinstance(selected_purpose, str) or not selected_purpose.strip():
            raise common.Refused("purpose label not found; pass --purpose <label> after checking the archive")
        folder = destination / f"seed{seed}"
        if not folder.resolve().is_relative_to(destination):
            raise common.Refused(f"seed output resolves outside its rescore directory: {folder}")
        prediction = folder / "test1.parquet"
        receipt = Path(str(prediction) + ".json")
        comparison = folder / "compare.json"
        has_outputs = folder.exists() and any(folder.iterdir())
        if has_outputs and not (prediction.is_file() and receipt.is_file() and comparison.is_file()):
            raise common.Refused(f"partial outputs; rename {folder}")
        if has_outputs:
            saved = common.read_verdict(comparison)
            if saved.get("checkpoint_sha256") != checkpoint_sha:
                raise common.Refused(f"cached comparison checkpoint differs: {comparison}")
            cached_receipt = common.read_json(receipt)
            if (cached_receipt.get("checkpoint_sha256") != checkpoint_sha or
                    cached_receipt.get("predictions_sha256") != common.sha256_file(prediction)):
                raise common.Refused(f"cached output hash differs: {folder}")
        plans.append(dict(seed=seed, model_dir=model_dir, checkpoint=checkpoint, checkpoint_sha=checkpoint_sha,
                          original=original, config_path=config_path, batch=batch, cap=cap, label=label, ids=ids,
                          purpose=selected_purpose, folder=folder, prediction=prediction, receipt=receipt,
                          comparison=comparison, cached=has_outputs))
    runtime = _runtime(common)
    compare = _comparator()
    for plan in plans:
        seed, folder = plan["seed"], plan["folder"]
        if plan["cached"]:
            record = common.read_verdict(plan["comparison"])
            common.print_lines([f"skip seed{seed}, exists; rename {folder} to run it again"])
            seeds[str(seed)] = record
            continue
        before = _tree_hashes(plan["model_dir"], common)
        folder.mkdir(parents=True, exist_ok=True)
        argv = [str(paths.PY), "-m", layout.name["scorer"], "--config", str(plan["config_path"]),
                "--checkpoint", str(plan["checkpoint"]), "--out", str(plan["prediction"]),
                "--population", str(paths.SCORE_POPULATION), "--purpose", plan["purpose"],
                f"eval.file_start={start}", f"eval.file_end={end}", f"training.seed={seed}",
                f"training.eval_batch_size={plan['batch']}", f"sequence.max_window_rows={plan['cap']}"]
        started = time.perf_counter()
        rc = common.run_logged(f"rescore_seed{seed}", argv, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
        elapsed = time.perf_counter() - started
        after = _tree_hashes(plan["model_dir"], common)
        changed = before != after
        if rc != 0 or not plan["receipt"].is_file() or not plan["prediction"].is_file():
            record = {"passed": False, "result": "REFUSED", "exit_code": 1 if rc else 4,
                      "stage1_rescore_exact": False, "rows": {"available": False},
                      "reasons": [f"scorer rc={rc}; incomplete outputs; rename {folder}"]}
        else:
            original = plan["original"]
            record = compare(plan["receipt"], original["receipt_path"],
                             expected_checkpoint_sha256=plan["checkpoint_sha"], id_cols=plan["ids"],
                             label_col=plan["label"], current_predictions=plan["prediction"],
                             original_predictions=original["predictions"],
                             expected_ap=float(rules.RECORDED_TEST1_AP[seed]), file_start=start, file_end=end)
        if changed:
            record.update(passed=False, result="REFUSED", exit_code=4, stage1_rescore_exact=False)
            record["reasons"].append("kept model folder changed during scoring")
        exposure_path = Path(str(plan["prediction"]) + ".exposure.json")
        exposure = common.read_json(exposure_path) if exposure_path.is_file() else None
        record.update(layout=layout.layout, seed=seed, checkpoint_sha256=plan["checkpoint_sha"],
                      model_tree_changed=changed, model_hashes_before=before, model_hashes_after=after,
                      scoring_wall_seconds=elapsed, scorer_exit_code=rc, command=argv,
                      scoring_in_loop_seconds=_exposure_seconds(exposure),
                      scoring_in_loop_note="exposure interval excludes model loading",
                      exposure=exposure, runtime=runtime,
                      original_manifest=plan["original"]["manifest"],
                      original_receipt_matches=plan["original"]["receipt_matches"])
        seeds[str(seed)] = _write(common, plan["comparison"], record)
    passed = all(record["passed"] for record in seeds.values())
    exit_code = (4 if any(r.get("exit_code") == 4 for r in seeds.values()) else
                 1 if any(r.get("exit_code") == 1 for r in seeds.values()) else 0 if passed else 3)
    summary = {"passed": passed, "layout": layout.layout, "seeds": seeds, "exit_code": exit_code,
               "stage1_rescore_exact": all(r.get("stage1_rescore_exact", False) for r in seeds.values()),
               "reasons": [f"seed{seed}: {reason}" for seed, record in seeds.items() for reason in record.get("reasons", [])]}
    summary = _apply_override(summary, accept_rescore_gap, common)
    for seed, record in seeds.items():
        seeds[seed] = _write(common, destination / f"seed{seed}" / "compare.json", record)
    return _write(common, summary_path, summary)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--purpose")
    parser.add_argument("--accept-rescore-gap")
    parser.add_argument("--out", help="output directory under checkpoints/reproduce")
    parser.add_argument("--config", help="explicit scoring config; otherwise use each kept seed config")
    args = parser.parse_args(argv)
    common, paths, rules, layout = _dependencies()
    try:
        summary = run_rescore(common, paths, rules, layout, purpose=args.purpose,
                              accept_rescore_gap=args.accept_rescore_gap, out=args.out, config=args.config)
        common.print_lines([json.dumps(summary, indent=2, allow_nan=False)])
        return summary["exit_code"]
    except common.Refused as exc:
        common.print_lines([f"REFUSED: {exc}"])
        return 4
    except common.ReproduceStop as exc:
        common.print_lines([f"STOP: {exc}"])
        return 3
    except (OSError, ValueError, TypeError, KeyError) as exc:
        common.print_lines([f"REFUSED: {exc}"])
        return 4


if __name__ == "__main__":
    raise SystemExit(main())
