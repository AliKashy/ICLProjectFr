"""Compare saved scores of the same checkpoint before and after reorganization.

This CPU-only utility reads explicit receipts/parquets; it never trains or scores.
Stage1 DESIGN section 7 and review correction 2 define the exact-receipt rule and
the labelled six-decimal fallback when the original receipt is unavailable.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re


class InputError(ValueError):
    """An input cannot establish the requested same-checkpoint comparison."""


def _sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _number(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise InputError(f"{name} must be a finite number")
    return float(value)


def _hash_text(value, name):
    if not isinstance(value, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", value):
        raise InputError(f"{name} must be a SHA256 hex string")
    return value.lower()


def _receipt(path, checkpoint, start, end, name):
    def invalid_constant(value):
        raise InputError(f"{name} receipt contains non-finite JSON value {value}")

    def finite_float(value):
        parsed = float(value)
        if not math.isfinite(parsed):
            invalid_constant(value)
        return parsed

    with Path(path).open(encoding="utf-8") as stream:
        receipt = json.load(stream, parse_constant=invalid_constant, parse_float=finite_float)
    if not isinstance(receipt, dict):
        raise InputError(f"{name} receipt must be a JSON object")
    if _hash_text(receipt.get("checkpoint_sha256"), f"{name} checkpoint_sha256") != checkpoint:
        raise InputError(f"{name} receipt names a different checkpoint")
    files = receipt.get("files")
    if (not isinstance(files, dict) or type(files.get("start")) is not int
            or type(files.get("end")) is not int or (files["start"], files["end"]) != (start, end)):
        raise InputError(f"{name} receipt does not cover files {start}..{end}")
    ap = _number(receipt.get("average_precision"), f"{name} average_precision")
    if not 0 <= ap <= 1:
        raise InputError(f"{name} average_precision must be in [0, 1]")
    for key in ("n_predictions", "n_positives"):
        if type(receipt.get(key)) is not int:
            raise InputError(f"{name} {key} must be an integer")
    if receipt["n_predictions"] <= 0 or not 0 <= receipt["n_positives"] <= receipt["n_predictions"]:
        raise InputError(f"{name} receipt has invalid row/positive counts")
    return receipt


def _prediction_path(explicit, receipt, receipt_path, name, required):
    value = explicit if explicit is not None else receipt.get("predictions")
    if value is None or value == "":
        if required or explicit is not None:
            raise InputError(f"{name} predictions path is missing")
        return None
    path = Path(value)
    if not path.is_absolute() and explicit is None:
        path = Path(receipt_path).resolve().parent / path
    if not path.is_file():
        if required or explicit is not None:
            raise InputError(f"{name} predictions not found: {path}")
        return None
    return path


def _prediction_frame(path, receipt, ids, label, name, reasons):
    import numpy as np
    import pandas as pd
    import pyarrow.parquet as pq
    from sklearn.metrics import average_precision_score

    expected_hash = _hash_text(receipt.get("predictions_sha256"), f"{name} predictions_sha256")
    actual_hash = _sha256(path)
    if actual_hash != expected_hash:
        raise InputError(f"{name} predictions hash differs from its receipt: {path}")
    columns = list(pq.read_schema(path).names)
    required = ids + [label, "score"]
    missing = [key for key in required if key not in columns]
    if missing:
        raise InputError(f"{name} predictions missing columns: {missing}")
    selected = required + [key for key in ("window_rows", "window_truncated") if key in columns]
    frame = pd.read_parquet(path, columns=selected)
    if frame.empty:
        raise InputError(f"{name} predictions contain no rows")
    if frame[ids].isna().any().any() or frame.duplicated(ids).any():
        raise InputError(f"{name} prediction IDs must be non-null and unique")
    for key in ids:
        kind = pd.api.types.infer_dtype(frame[key], skipna=False)
        if kind.startswith("mixed") or kind in ("unknown-array", "empty"):
            raise InputError(f"{name} ID column {key} has heterogeneous types")
    for key in (label, "score"):
        if not (pd.api.types.is_numeric_dtype(frame[key]) or pd.api.types.is_bool_dtype(frame[key])):
            raise InputError(f"{name} {key} must be numeric")
        if frame[key].isna().any():
            raise InputError(f"{name} {key} contains missing values")
    scores = frame["score"].to_numpy(dtype=float)
    labels = frame[label].to_numpy(dtype=float)
    if not np.isfinite(scores).all() or ((scores < 0) | (scores > 1)).any():
        raise InputError(f"{name} scores must be finite probabilities in [0, 1]")
    if not np.isfinite(labels).all() or not np.isin(labels, [0, 1]).all():
        raise InputError(f"{name} labels must be 0 or 1")
    if np.unique(labels).size != 2:
        raise InputError(f"{name} predictions cannot reproduce a finite two-class scorer AP")
    for key in ("window_rows", "window_truncated"):
        if key not in frame:
            continue
        values = frame[key]
        if values.isna().any() or not (pd.api.types.is_numeric_dtype(values)
                                       or pd.api.types.is_bool_dtype(values)):
            raise InputError(f"{name} {key} contains invalid values")
        array = values.to_numpy(dtype=float)
        valid = np.isfinite(array).all()
        valid = valid and (bool(np.isin(array, [0, 1]).all()) if key == "window_truncated"
                           else bool(((array >= 1) & (array == np.floor(array))).all()))
        if not valid:
            raise InputError(f"{name} {key} contains invalid values")
    computed = {"average_precision": float(average_precision_score(labels, scores)),
                "n_predictions": int(len(frame)), "n_positives": int(labels.sum()),
                "path": str(path), "sha256": actual_hash}
    for key in ("average_precision", "n_predictions", "n_positives"):
        if computed[key] != receipt[key]:
            reasons.append(f"{name} parquet {key}={computed[key]!r} differs from receipt {receipt[key]!r}")
    return frame, computed


def _compare_rows(current, original, ids, label, current_metrics, original_metrics, reasons):
    import numpy as np
    import pandas as pd

    for key in ids:
        if pd.api.types.infer_dtype(current[key]) != pd.api.types.infer_dtype(original[key]):
            raise InputError(f"ID column {key} has different types; IDs were not coerced")
    for name, frame in (("current", current), ("original", original)):
        missing = [key for key in ("window_rows", "window_truncated") if key not in frame]
        if missing:
            raise InputError(f"{name} predictions missing window-comparison columns: {missing}")
    pairs = current.merge(original, on=ids, how="outer", suffixes=("_current", "_original"),
                          indicator=True, validate="one_to_one")
    rows = {"available": True, "only_current": int((pairs["_merge"] == "left_only").sum()),
            "only_original": int((pairs["_merge"] == "right_only").sum()),
            "current_ap": current_metrics["average_precision"], "original_ap": original_metrics["average_precision"],
            "top_overlap_k": None, "top_shared": None, "top_overlap_fraction": None}
    common = pairs.loc[pairs["_merge"] == "both"]
    for key, output in ((label, "label_differences"), ("window_rows", "window_rows_differences"),
                        ("window_truncated", "window_truncated_differences")):
        rows[output] = int((common[key + "_current"] != common[key + "_original"]).sum())
        if rows[output]:
            reasons.append(f"row comparison: {rows[output]} {output}")
    if rows["only_current"] or rows["only_original"]:
        reasons.append(f"row IDs differ: current-only={rows['only_current']}, original-only={rows['only_original']}")
    diff = np.abs(common["score_current"].to_numpy(dtype=float) - common["score_original"].to_numpy(dtype=float))
    rows.update(max_abs_score_diff=float(diff.max()) if len(diff) else None,
                score_differences=int((diff != 0).sum()), score_differences_gt_1e6=int((diff > 1e-6).sum()),
                scores_equal=bool(len(diff) == len(current) == len(original) and (diff == 0).all()))
    if not rows["only_current"] and not rows["only_original"]:
        k = math.ceil(0.006 * len(current))
        def top_ids(frame):
            top = frame.sort_values(["score"] + ids, ascending=[False] + [True] * len(ids), kind="mergesort").head(k)
            return set(top[ids].itertuples(index=False, name=None))
        shared = len(top_ids(current) & top_ids(original))
        rows.update(top_overlap_k=k, top_shared=shared, top_overlap_fraction=shared / k)
    return rows


def compare_outputs(current_receipt, original_receipt=None, *, expected_checkpoint_sha256,
                    id_cols, label_col, current_predictions=None, original_predictions=None,
                    expected_ap=None, file_start=8000, file_end=8010):
    """Return a structured verdict for explicit saved outputs; never run a model.

    ``stage1_rescore_exact`` refers to the exact receipt AP/count comparison with
    valid available evidence. It does not claim binary identity of score files.
    Missing original parquet is recorded; missing current parquet is a refusal.
    """
    report = {"passed": False, "result": "REFUSED", "exit_code": 4, "stage1_rescore_exact": False,
              "mode": "receipt_exact" if original_receipt is not None else "recorded_6dp",
              "reasons": [], "receipts": {}, "rows": {"available": False}}
    try:
        ids = list(id_cols) if not isinstance(id_cols, str) else []
        if not ids or not all(isinstance(key, str) and key for key in ids) or len(ids) != len(set(ids)):
            raise InputError("id_cols must be a nonempty list of distinct column names")
        if not isinstance(label_col, str) or not label_col or label_col in ids or "score" in ids or label_col == "score":
            raise InputError("label_col and score must be distinct from ID columns")
        if type(file_start) is not int or type(file_end) is not int or file_start > file_end:
            raise InputError("file_start/file_end must be an ordered integer range")
        checkpoint = _hash_text(expected_checkpoint_sha256, "expected_checkpoint_sha256")
        cur = _receipt(current_receipt, checkpoint, file_start, file_end, "current")
        orig = (_receipt(original_receipt, checkpoint, file_start, file_end, "original")
                if original_receipt is not None else None)
        if orig is None and original_predictions is not None:
            raise InputError("original predictions require their original receipt")
        report["receipts"] = {"current": cur, "original": orig}
        cp = _prediction_path(current_predictions, cur, current_receipt, "current", True)
        op = (_prediction_path(original_predictions, orig, original_receipt, "original", False)
              if orig is not None else None)
        current, cm = _prediction_frame(cp, cur, ids, label_col, "current", report["reasons"])
        report["receipts"]["current_recomputed"] = cm
        if op is not None:
            original, om = _prediction_frame(op, orig, ids, label_col, "original", report["reasons"])
            report["receipts"]["original_recomputed"] = om
            report["rows"] = _compare_rows(current, original, ids, label_col, cm, om, report["reasons"])
        else:
            report["rows"]["reason"] = "original predictions unavailable; no per-row comparison was performed"
            report["rows"]["current_ap"] = cm["average_precision"]
        if orig is not None:
            comparison = {}
            for key in ("average_precision", "n_predictions", "n_positives"):
                comparison[key + "_equal"] = cur[key] == orig[key]
                if not comparison[key + "_equal"]:
                    report["reasons"].append(f"receipt {key} differs: current={cur[key]!r}, original={orig[key]!r}")
            comparison["auroc_equal"] = cur.get("auroc") == orig.get("auroc")
            comparison["metadata"] = {
                key: {"current": cur.get(key), "original": orig.get(key), "equal": cur.get(key) == orig.get(key)}
                for key in ("max_window_rows", "eval_batch_size", "scoring_precision", "window_rows")}
            report["receipts"]["comparison"] = comparison
        else:
            reference = _number(expected_ap, "expected_ap for receipt-not-found fallback")
            if not 0 <= reference <= 1:
                raise InputError("expected_ap must be in [0, 1]")
            equal = f"{cur['average_precision']:.6f}" == f"{reference:.6f}"
            report["receipts"]["comparison"] = {"expected_ap": reference, "six_decimal_equal": equal,
                "note": "receipt not found: 6-decimal check only"}
            if not equal:
                report["reasons"].append(f"6-decimal AP differs: current={cur['average_precision']:.6f}, expected={reference:.6f}")
        report["passed"] = not report["reasons"]
        report["result"] = "PASS" if report["passed"] else "STOP"
        report["exit_code"] = 0 if report["passed"] else 3
        report["stage1_rescore_exact"] = bool(orig is not None and report["passed"])
    except (OSError, ValueError, TypeError, KeyError, OverflowError) as exc:
        report["reasons"].append(str(exc))
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--current-receipt", required=True)
    parser.add_argument("--original-receipt")
    parser.add_argument("--checkpoint-sha256", required=True)
    parser.add_argument("--id-cols", nargs="+", required=True)
    parser.add_argument("--label-col", required=True)
    parser.add_argument("--current-predictions")
    parser.add_argument("--original-predictions")
    parser.add_argument("--expected-ap", type=float)
    parser.add_argument("--file-start", type=int, default=8000)
    parser.add_argument("--file-end", type=int, default=8010)
    parser.add_argument("--out")
    args = parser.parse_args(argv)
    output = Path(args.out) if args.out else None
    if output is not None and (output.exists() or output.is_symlink()):
        report = {"passed": False, "result": "REFUSED", "exit_code": 4,
                  "stage1_rescore_exact": False, "reasons": [f"output already exists: {output}"],
                  "mode": "receipt_exact" if args.original_receipt else "recorded_6dp", "receipts": {}, "rows": {"available": False}}
    else:
        report = compare_outputs(args.current_receipt, args.original_receipt,
            expected_checkpoint_sha256=args.checkpoint_sha256, id_cols=args.id_cols, label_col=args.label_col,
            current_predictions=args.current_predictions, original_predictions=args.original_predictions,
            expected_ap=args.expected_ap, file_start=args.file_start, file_end=args.file_end)
        if output is not None:
            try:
                output.parent.mkdir(parents=True, exist_ok=True)
                with output.open("x", encoding="utf-8") as stream:
                    json.dump(report, stream, indent=2, allow_nan=False)
                    stream.write("\n")
            except OSError as exc:
                report.update(passed=False, result="REFUSED", exit_code=4, stage1_rescore_exact=False)
                report["reasons"].append(f"could not write output: {exc}")
    print(json.dumps(report, indent=2, allow_nan=False))
    return report["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
