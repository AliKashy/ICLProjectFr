"""Show saved reproduction checks, or run their sequential checks-only queue."""
import argparse
import importlib
import json
import os
from pathlib import Path
import sys
import tempfile
import textwrap
import traceback


def _shared():
    folder = str(Path(__file__).resolve().parent)
    if folder not in sys.path:
        sys.path.insert(0, folder)
    return importlib.import_module("repro_common"), importlib.import_module("repro_paths")


def _accepted(record):
    return (record.get("passed") is False and record.get("accepted_gap") is True
            and record.get("acceptance_eligible") is True
            and isinstance(record.get("accept_rescore_gap_reason"), str)
            and bool(record["accept_rescore_gap_reason"].strip()))


def _load(path):
    if not path.is_file():
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(value, dict) or type(value.get("passed")) is not bool:
            return {"incomplete": True, "reasons": ["incomplete result, no boolean passed verdict"]}
        return value
    except (OSError, ValueError) as exc:
        return {"incomplete": True, "reasons": [str(exc)]}


def _status(record):
    if record is None:
        return "NOT RUN"
    if record.get("incomplete"):
        return "INCOMPLETE"
    if record.get("passed") is True:
        return "PASS"
    return "OWNER ACCEPTED GAP" if _accepted(record) else "STOP"


def _detail(lines, record, path):
    if record is None:
        return
    reasons = record.get("reasons", [])
    if isinstance(reasons, str):
        reasons = [reasons]
    lines.extend("  " + str(reason) for reason in reasons)
    if _accepted(record):
        lines.append("  owner reason: " + record["accept_rescore_gap_reason"])
    lines.append("  detail: " + str(path))


def report_lines(out, utc, layout="not recorded"):
    """Read existing results only; missing steps remain visibly not run."""
    out = Path(out)
    preflight = _load(out / "preflight.json")
    route = _load(out / "route.json")
    summary = _load(out / "rescore/summary.json")
    if preflight:
        layout = preflight.get("layout", layout)
    elif summary:
        layout = summary.get("layout", layout)
    lines = [f"REPRODUCTION CHECKS  {utc}  layout {layout}",
             "P0 preflight  " + _status(preflight)]
    _detail(lines, preflight, out / "preflight.json")
    for index, seed in enumerate((42, 43, 44), 1):
        record = (summary.get("seeds", {}).get(str(seed)) if summary else None)
        if record is not None and type(record.get("passed")) is not bool:
            record = dict(record, incomplete=True)
        label = f"S{index} rescore seed{seed} Test 1  {_status(record)}"
        if record:
            receipt = record.get("receipts", {}).get("current", {})
            if receipt:
                label += (f" AP={receipt.get('average_precision')!r}"
                          f" rows={receipt.get('n_predictions')!r} positives={receipt.get('n_positives')!r}")
            label += f" receipt_exact={record.get('stage1_rescore_exact', False)!r}"
            if record.get("scoring_wall_seconds") is not None:
                label += f" whole_scorer_seconds={record['scoring_wall_seconds']!r}"
        lines.append(label)
        _detail(lines, record, out / f"rescore/seed{seed}/compare.json")
    if summary and summary.get("incomplete"):
        lines.append("rescore summary INCOMPLETE")
        _detail(lines, summary, out / "rescore/summary.json")
    lines.append("S4 route test  " + _status(route))
    _detail(lines, route, out / "route.json")
    for index, device in ((5, "cpu"), (6, "cuda")):
        path = out / "same_batch" / device / "result.json"
        result = _load(path)
        lines.append(f"S{index} same batch {device.upper()}  {_status(result)}")
        if result:
            if result.get("mode"):
                lines.append("  " + result["mode"])
            comparison = result.get("comparison", {})
            if comparison.get("maxima") is not None:
                lines.append("  maximum absolute differences: " + json.dumps(comparison["maxima"], sort_keys=True))
            if result.get("tolerance") is not None:
                lines.append("  tolerances: " + json.dumps(result["tolerance"], sort_keys=True))
            for reason in result.get("determinism_refusals", []):
                lines.append("  determinism refusal: " + str(reason))
        _detail(lines, result, path)
    lines += ["control: the owner's seed-42 retrain, not run by this package",
              "R4 wrapper check: not applicable, no timing wrapper ran"]
    return lines


def write_report(common):
    lines = report_lines(common.OUT, common.utc_now())
    rendered = []
    for line in lines:
        rendered.extend(textwrap.wrap(str(line), width=90, subsequent_indent="  ",
                                      replace_whitespace=False, drop_whitespace=False) or [""])
    body = "\n".join(rendered) + "\n"
    path = Path(common.OUT) / "REPORT.txt"
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as stream:
        stream.write(body)
        temporary = Path(stream.name)
    os.replace(temporary, path)
    print(body, end="")
    return path


def busy_check(common):
    busy = common.busy_report()
    if busy:
        common.print_lines(["REFUSED: a workload is active", json.dumps(busy, indent=2)])
        return 4
    return 0


def _saved_code(common, path, allow_gap=False):
    try:
        record = common.read_verdict(path)
    except (common.Refused, OSError, ValueError) as exc:
        common.print_lines([f"REFUSED: {exc}"])
        return 4
    return 0 if record["passed"] or (allow_gap and _accepted(record)) else 3


def run_queue(common, paths, *, cpu_only=False, accept_rescore_gap=None, purpose=None):
    """Run CPU checks and then GPU checks serially; always render the current report."""
    if accept_rescore_gap is not None and not accept_rescore_gap.strip():
        common.print_lines(["REFUSED: --accept-rescore-gap needs a nonempty owner reason"])
        return 4
    out = Path(common.OUT)
    logs = out / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    log = logs / "queue.log"
    folder = Path(__file__).resolve().parent
    python = str(paths.PY)
    cpu = dict(os.environ, CUDA_VISIBLE_DEVICES="")
    normal = dict(os.environ)
    def event(text):
        line = f"{common.utc_now()} {text}"
        with log.open("a", encoding="utf-8") as stream:
            stream.write(line + "\n")
        print(line, flush=True)
    steps = [
        ("preflight", [python, str(folder / "preflight.py")] + (["--cpu-only"] if cpu_only else []),
         out / "preflight.json", cpu, False),
        ("route", [python, str(folder / "route_check.py")], out / "route.json", cpu, False),
        ("same_batch_cpu", [python, str(folder / "same_batch.py"), "--device", "cpu"],
         out / "same_batch/cpu/result.json", cpu, False),
    ]
    if not cpu_only:
        score_args = [python, str(folder / "rescore.py")]
        if accept_rescore_gap is not None:
            score_args += ["--accept-rescore-gap", accept_rescore_gap]
        if purpose is not None:
            score_args += ["--purpose", purpose]
        steps += [
            ("same_batch_cuda", [python, str(folder / "same_batch.py"), "--device", "cuda"],
             out / "same_batch/cuda/result.json", normal, True),
            ("rescore", score_args, out / "rescore/summary.json", normal, True),
        ]
    rc = 0
    event("queue start checks-only" + (" CPU only" if cpu_only else ""))
    try:
        if not cpu_only:
            rc = busy_check(common)
        for name, argv, result, env, gpu in steps:
            if rc:
                break
            if gpu:
                rc = busy_check(common)
                if rc:
                    break
            event(f"start {name}")
            rc = common.run_logged(name, argv, env=env)
            if rc == 0:
                rc = _saved_code(common, result, allow_gap=(name == "rescore" and accept_rescore_gap is not None))
            event(f"end {name} rc={rc}")
    except Exception:
        rc = 1
        traceback.print_exc()
    finally:
        report_path = write_report(common)
        event(f"queue end rc={rc}; report: {report_path}")
    return rc


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--run-queue", action="store_true")
    mode.add_argument("--busy-check", action="store_true")
    parser.add_argument("--cpu-only", action="store_true")
    parser.add_argument("--accept-rescore-gap")
    parser.add_argument("--purpose")
    args = parser.parse_args(argv)
    common, paths = _shared()
    if args.busy_check:
        return 0 if args.cpu_only else busy_check(common)
    if args.run_queue:
        return run_queue(common, paths, cpu_only=args.cpu_only,
                         accept_rescore_gap=args.accept_rescore_gap, purpose=args.purpose)
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
    write_report(common)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
