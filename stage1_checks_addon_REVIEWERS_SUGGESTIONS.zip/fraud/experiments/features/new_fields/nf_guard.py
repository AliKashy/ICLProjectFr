"""Source guard. Proves the trainer is the code the control and stage 0 ran on.

  $PY fraud/experiments/features/new_fields/nf_guard.py --before <hash>     # right after installing the package
  $PY fraud/experiments/features/new_fields/nf_guard.py                     # preflight, before every fit

It computes the trainer's own source_sha256() (through the resolver) and compares it with:
  - the hash noted before the install (--before), which must be equal: "unchanged";
  - the latest start or resume identity of every stage 0 run manifest under runs/tuning/ and checkpoints/ (it stops
    if none is found, and names the roots it searched);
  - the stage 1 control's recorded source_sha256 (when stage 1 has run).
It also reads stage 1's own result files (paths in UPSTREAM.yaml; design review item 21), records their hashes and
results, and compares the control's torch, Lightning, CUDA and GPU with this machine (design review item 15).
Every run appends one line to checkpoints/new_fields/guard/guard.jsonl. Exit 3 on any difference.
It prints the pandas version first. The new-fields tools need pandas 2.0 or later (requirements.txt allows older,
and it is under the trainer's hash, so it stays): with an older pandas it stops there with exit 3, in one line.
"""
import argparse
import json
import re
import socket
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nf_common as C  # noqa: E402
import nf_layout  # noqa: E402

MANIFEST = "run_manifest_v2.json"
STAGE1_KEYS = ("rescore_summary", "route_result", "wrapper_check")
PASS_WORDS = {"pass", "passed", "ok", "exact", "equal", "true", "yes"}
PANDAS_MIN = (2, 0)


def pandas_version():
    """The installed pandas version text, or None when pandas does not import."""
    try:
        import pandas
    except Exception:  # noqa: BLE001
        return None
    return str(pandas.__version__)


def pandas_problem(version):
    """None when `version` is pandas 2.0 or later; else the one line that stops the guard."""
    m = re.match(r"\s*(\d+)\.(\d+)", str(version or ""))
    if m and (int(m.group(1)), int(m.group(2))) >= PANDAS_MIN:
        return None
    have = "is not installed" if version is None else f"{version} is installed"
    return (f"STOP: pandas {have}; the new-fields tools need pandas 2.0 or later. "
            "Ask the owner before installing another version.")


def latest_identity(manifest):
    """The source hash and environment of a manifest's latest start or resume event."""
    events = [manifest.get("start") or {}] + list(manifest.get("resume_events") or [])
    ev = events[-1] if events else {}
    src = ev.get("source_sha256") or (ev.get("identity") or {}).get("source_sha256")
    return {"source_sha256": src, "torch": ev.get("torch"), "lightning": ev.get("lightning"),
            "cuda": ev.get("cuda"), "gpu": ev.get("gpu"), "utc": ev.get("utc"), "status": manifest.get("status")}


def find_manifests(roots, skip=()):
    found = []
    for r in roots:
        r = Path(r)
        if not r.is_dir():
            continue
        for p in sorted(r.rglob(MANIFEST)):
            if any(Path(s).resolve() in p.resolve().parents for s in skip):
                continue
            found.append(p)
    return found


def result_passed(obj):
    """Reads a stage 1 result file's verdict. Looks at passed / result / status / verdict / ok keys."""
    if isinstance(obj, dict):
        for k in ("passed", "pass", "ok", "result", "status", "verdict", "exact", "equal"):
            if k in obj:
                v = obj[k]
                if isinstance(v, bool):
                    return v
                return str(v).strip().lower() in PASS_WORDS
    return None


def stage1_results(up, root):
    """Each stage 1 result file named in UPSTREAM.yaml: path, sha256, passed (None if unreadable or missing)."""
    s1 = (up or {}).get("stage1") or {}
    out = {}
    for k in STAGE1_KEYS:
        p = s1.get(k)
        out[k] = _read_result(root, p, accept_rescore=(k == "rescore_summary"))
    out["wrapper_check"] = wrapper_result(s1, root, out["wrapper_check"])
    sb = s1.get("same_batch_results")
    devs = {}
    if sb and (root / sb).is_dir():
        for f in sorted((root / sb).glob("*/result.json")):
            devs[f.parent.name] = _read_result(root, f.relative_to(root).as_posix())
    # S5 and S6 require both devices; discovering only one file is not completion.
    for device in ("cpu", "cuda"):
        devs.setdefault(device, {"path": str(Path(sb) / device / "result.json") if sb else "",
                                 "sha256": None, "passed": None, "note": "not found"})
    out["same_batch"] = devs
    return out


def wrapper_result(s1, root, result):
    """R4 applies to a recorded timing-wrapper run, not an ordinary completed control.

    DESIGN 9.8 puts wrapper.json in <control_dir>_timing, beside the run. Absence
    is recorded as absence, not a passing wrapper test or proof of past execution.
    """
    result = dict(result, applicable=None)
    try:
        control = control_state({"stage1": s1}, root)
    except (OSError, ValueError, AttributeError, TypeError) as e:
        return dict(result, passed=None, note=f"control identity unreadable: {e}")
    if not control or not control["complete"]:
        return dict(result, passed=None, note="wrapper applicability unknown: no completed control")
    run = root / s1["control_dir"]
    sidecar = run.with_name(run.name + "_timing") / "wrapper.json"
    result["wrapper_record"] = {"path": str(sidecar), "sha256": None}
    try:
        sidecar.lstat()
    except FileNotFoundError:
        return dict(result, applicable=False, passed=None,
                    note="no timing-wrapper record beside the completed control")
    except OSError as e:
        return dict(result, applicable=None, passed=None, note=f"wrapper record unreadable: {e}")
    result["applicable"] = True
    try:
        result["wrapper_record"]["sha256"] = C.sha256_file(sidecar)
        record = C.read_json(sidecar)
        if not isinstance(record, dict):
            raise ValueError("wrapper record must be a JSON object")
    except (OSError, ValueError) as e:
        return dict(result, passed=None, note=f"wrapper record unreadable: {e}")
    return result


def _read_result(root, p, accept_rescore=False):
    if not p:
        return {"path": "", "sha256": None, "passed": None, "note": "no path in UPSTREAM.yaml"}
    f = root / p
    if not f.is_file():
        return {"path": p, "sha256": None, "passed": None, "note": "not found"}
    try:
        obj = C.read_json(f)
    except (OSError, ValueError) as e:
        return {"path": p, "sha256": C.sha256_file(f), "passed": None, "note": f"unreadable: {e}"}
    result = {"path": p, "sha256": C.sha256_file(f), "passed": result_passed(obj)}
    # DESIGN section 1 permits an explicit owner acceptance for S1-S3 only.
    # Keep the measured failure visible; acceptance is an operational exception.
    if accept_rescore and isinstance(obj, dict):
        reason = obj.get("accept_rescore_gap_reason")
        if (obj.get("passed") is False and obj.get("accepted_gap") is True
                and obj.get("acceptance_eligible") is True
                and isinstance(reason, str) and reason.strip()):
            result.update(accepted_gap=True, accept_rescore_gap_reason=reason,
                          stage1_rescore_exact=False)
    return result


def stage1_ok(results):
    """Require applicable checks, allowing only the explicit S1-S3 owner exception."""
    flat = [v for k, v in results.items() if k != "same_batch"
            and not (k == "wrapper_check" and v.get("applicable") is False)
            and not (k == "rescore_summary" and v.get("accepted_gap") is True
                     and v.get("passed") is False
                     and isinstance(v.get("accept_rescore_gap_reason"), str)
                     and v["accept_rescore_gap_reason"].strip())]
    flat += list(results["same_batch"].values())
    return bool(flat) and all(v.get("passed") is True for v in flat)


def control_state(up, root):
    """The stage 1 control's manifest: status, best.ckpt, identity. None when it does not exist."""
    d = ((up or {}).get("stage1") or {}).get("control_dir")
    if not d or not (root / d / MANIFEST).is_file():
        return None
    m = C.read_json(root / d / MANIFEST)
    ident = latest_identity(m)
    ident["dir"] = d
    ident["best_ckpt"] = (root / d / "best.ckpt").is_file()
    ident["complete"] = m.get("status") in ("finished", "budget_reached") and ident["best_ckpt"]
    ident["manifest_sha256"] = C.sha256_file(root / d / MANIFEST)
    return ident


def environment():
    env = {"hostname": socket.gethostname()}
    try:
        import torch
        env["torch"] = torch.__version__
        env["cuda"] = torch.version.cuda
        env["gpu"] = torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
    except Exception:  # noqa: BLE001
        env.update(torch=None, cuda=None, gpu=None)
    try:
        import pytorch_lightning as pl
        env["lightning"] = pl.__version__
    except Exception:  # noqa: BLE001
        env["lightning"] = None
    return env


def env_differences(control, env):
    """torch, Lightning, CUDA and GPU of the control against this machine. A value the control's manifest does not
    record is listed as unrecorded, not as a difference."""
    diffs, unrecorded = [], []
    for k in ("torch", "lightning", "cuda", "gpu"):
        if control.get(k) is None:
            unrecorded.append(k)
        elif env.get(k) is not None and str(control[k]) != str(env[k]):
            diffs.append(f"{k}: control {control[k]} here {env[k]}")
    return diffs, unrecorded


def run(args):
    root = C.ROOT
    lines, problems = [], []
    lay = nf_layout.resolve(["trainer"])
    lines.append(f"layout: {lay.layout}")
    now = nf_layout.attr("trainer", "source_sha256")()
    lines.append(f"source_sha256 now      {now[:12]} (full value in guard.jsonl)")
    record = {"utc": C.utc_now(), "layout": lay.layout, "source_sha256": now, "pandas": pandas_version()}
    if args.before:
        same = args.before.strip() == now
        lines.append(f"before install         {args.before.strip()[:12]}  -> {'unchanged' if same else 'CHANGED'}")
        record["before"] = args.before.strip()
        if not same:
            problems.append("the source hash changed with the install: remove the copied folders and stop")
    up = C.upstream() if (C._settings_dir() / "UPSTREAM.yaml").is_file() else {}
    s0 = (up.get("stage0") or {})
    roots = [root / r for r in (s0.get("manifest_roots") or ["runs/tuning", "checkpoints"])]
    skip = [C.c2()]
    mans = find_manifests(roots, skip=skip)
    ctl_dir = ((up.get("stage1") or {}).get("control_dir"))
    s0_mans = [m for m in mans if not (ctl_dir and (root / ctl_dir).resolve() in m.resolve().parents)]
    record["stage0"] = []
    if not s0_mans and not args.no_stage0:
        problems.append("no stage 0 manifest found; roots searched: " + ", ".join(C.rel(r) for r in roots))
    for m in s0_mans:
        try:
            ident = latest_identity(C.read_json(m))
        except (OSError, ValueError) as e:
            problems.append(f"stage 0 manifest unreadable: {C.rel(m)} ({e})")
            continue
        ok = ident["source_sha256"] == now
        record["stage0"].append({"manifest": C.rel(m), "source_sha256": ident["source_sha256"], "equal": ok})
        lines.append(f"stage 0 {'equal  ' if ok else 'DIFFERS'} {C.rel(m)}")
        if not ok:
            problems.append(f"stage 0 manifest {C.rel(m)} ran on {str(ident['source_sha256'])[:12]}, now {now[:12]}")
    ctl = control_state(up, root)
    record["control"] = ctl
    if ctl is None:
        lines.append("stage 1 control: not found (every read is blocked until it exists)")
    else:
        ok = ctl["source_sha256"] == now
        lines.append(f"stage 1 control {'equal  ' if ok else 'DIFFERS'} {ctl['dir']} status={ctl['status']} "
                     f"best.ckpt={'yes' if ctl['best_ckpt'] else 'no'}")
        if not ok:
            problems.append(f"the stage 1 control ran on {str(ctl['source_sha256'])[:12]}, now {now[:12]}")
        env = environment()
        record["environment"] = env
        diffs, unrec = env_differences(ctl, env)
        for d in diffs:
            lines.append(f"environment DIFFERS {d}")
        if unrec:
            lines.append(f"environment: control manifest does not record {', '.join(unrec)}")
        if diffs and not args.cpu_only:
            problems.append("the control ran on another torch, Lightning, CUDA or GPU: " + "; ".join(diffs))
    s1 = stage1_results(up, root)
    record["stage1_results"] = s1
    record["stage1_ok"] = stage1_ok(s1)
    for k, v in s1.items():
        if k == "same_batch":
            for dev, r in v.items():
                lines.append(f"stage 1 same_batch {dev or '-'}: {_word(r)}")
        else:
            lines.append(f"stage 1 {k}: {_word(v)}")
    record["problems"] = problems
    record["result"] = "unchanged" if not problems else "STOP"
    C.append_jsonl(C.out("guard", "guard.jsonl"), record)
    title = f"SOURCE GUARD  {record['utc']}  result={'unchanged' if not problems else 'STOP'}"
    body = lines + [f"STOP: {p}" for p in problems]
    C.print_screen(title, body, footer="log: " + C.rel(C.c2() / "guard" / "guard.jsonl"))
    return C.OK if not problems else C.STOP


def _word(r):
    if r.get("applicable") is False:
        return f"not applicable ({r.get('note', '')})"
    if r.get("accepted_gap") is True and r.get("passed") is False:
        return f"owner-accepted rescore gap: {r['accept_rescore_gap_reason']} ({r['path']})"
    if r.get("passed") is True:
        return f"passed ({r['path']}, {str(r['sha256'])[:12]})"
    if r.get("passed") is False:
        return f"FAILED ({r['path']}, {str(r['sha256'])[:12]})"
    return f"unknown ({r.get('note', '')}: {r.get('path', '')})"


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--before", help="source_sha256 noted before the install")
    ap.add_argument("--no-stage0", action="store_true",
                    help="do not stop when no stage 0 manifest exists (only after stage 0 is archived; say why)")
    ap.add_argument("--cpu-only", action="store_true",
                    help="CPU check: report environment differences without stopping")
    args = ap.parse_args(argv)
    version = pandas_version()
    print(f"pandas {version or 'not installed'}")
    problem = pandas_problem(version)
    if problem:
        print(problem)
        return C.STOP
    try:
        return run(args)
    except SystemExit as e:
        return e.code if isinstance(e.code, int) else C.CRASH


if __name__ == "__main__":
    sys.exit(main())
