"""The reader: a paired comparison of a candidate against a control on the same rows (DESIGN.md section 8).

It reads prediction files, their receipts and five raw columns. It never trains or scores. Commands:

  spread        the seed spread on a decision population: the kept seeds 42, 43 and 44, pooled with the current-pod
                base trio (the seed-42 base control and the base refits at 43 and 44) when the run table holds it,
                and each measure's same-recipe pair term sd_null, printed as information only (the reviewers'
                decisions D2 and D5b)
  read          one step's decision at the seeds available (1, or 3 after confirmation)
  select-check  the SELECT June check that makes a pending decision final
  lift          the downstream lift of the step's kept fit against its control's (section 8.7)
  report        one screen of every saved read, one step's saved screens, or a report-only population
                (``--population test1``: Test 1 is reported only and never decides)

Run table (``--run-table``, the planner's JSON ``{"runs": [...]}`` or a CSV), one row per fit:
  role         candidate or control (read, select-check, lift); kept and current (spread); report (report);
               kept_fit (read, information only: the kept fit a refit control refits, D5a)
  seed         the training seed
  predictions  the scorer's prediction parquet (the run name is its name before "__")
  receipt      the scorer's receipt (blank: <predictions>.json)
  checkpoint   the fit's best.ckpt (blank: <run_dir>/best.ckpt)
  run_dir      the fit's folder (its run manifest and config: environment and num_workers)
  run, label   optional: a run name and words for the screen, for example "base + 78"
  downstream   optional (lift): the downstream predictions.parquet; else the one file under
               checkpoints/new_fields/downstream/<run>/
  downstream_sha256  optional (lift): that file's sha256 as the downstream job recorded it; a change stops
  control_kind, previous_decision  optional (read): base, refit or kept, and how the kept recipe was decided
The planner's JSON table may also hold ``membership`` and ``a1_adopted`` (the step's group membership, D3a).
Relative paths are read from the project root. ``--out`` names the JSON to write; a .txt screen goes beside it.

The decision rules are the reviewers' joint decisions of 2 November (D1, D2), with the D2 correction of 3 November:
UDR at 0.6% in fraud transactions decides; T_1 = t x sqrt(sd_pair^2 + 2 x sd_run^2) with t one-sided 95% at the
Welch-Satterthwaite degrees of freedom, an operational one-seed rule that assumes equal candidate and control seed
variance (one fit per arm gives no other estimate); the three-seed bound uses the contrast's own paired differences,
LB_3 = gain - t x sqrt(v_acct + s_d^2 / k), t one-sided 95% at k - 1 degrees of freedom; no null subtraction anywhere
(sd_null is information only); no fixed floor; the SELECT check's limit is -k x sqrt(SE_acct^2 + 2 x s_m^2/n); a
conflict line when AP or VDR falls clearly. The k values of the SELECT check and the conflict line are operational
development rules: their error rates under unequal candidate and control variances are not established. A UDR seed
spread of zero (possible for a top-k count even with different valid fits) is reported, not a stop: T_1 is then
undefined, so a one-seed gain above zero goes to seeds 43 and 44 and the three-seed read decides.

Exit codes: 0 done; 2 bad arguments; 3 STOP (a check failed: receipts, rows, labels, inputs changed, the engine
check); 4 refused (a missing prerequisite, a blank approval, a population that may not decide).

Run by path: $PY fraud/experiments/features/new_fields/nf_read.py <command> ...
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import textwrap
from pathlib import Path
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
ROOT = Path(__file__).resolve().parents[4]
for _p in (str(HERE), str(ROOT / "src"), str(ROOT)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

import nf_common as C  # noqa: E402
import nf_ranked as R  # noqa: E402

ID, ACCT, TIME, LABEL, AMOUNT, SCORE = ("fi_transaction_id", "Nmap_account_reference_xid", "transaction_dttm",
                                        "frd_tag", "transaction_amt", "score")
WINDOW_CAP = 32
# The populations that may decide, and the settings key and scorer population each one reads.
DECIDING = {"rank_b": {"key": "rank_b", "name": "RANK-B", "scorer_population": "OTHER"},
            "select_june": {"key": "select", "name": "SELECT", "scorer_population": "SELECT"}}
KINDS = ("add", "month_out", "prune", "calendar")
# Decisions that change the kept inputs, and what each becomes when its SELECT check fails.
CHANGES = {"ADOPT": "KEEP THE CONTROL", "MONTH OUT": "KEEP MONTH", "KEEP THE SMALLER LIST": "KEEP THE UNPRUNED LIST",
           "CALENDAR CYCLICAL": "KEEP THE CALENDAR"}
DECISION_KEYS = ("main_measure", "udr_unit", "bar_udr", "t1_multiplier", "null_correction", "three_seed_bound",
                 "spread_pool", "conflict_line", "bootstrap", "select_check", "decide_on", "populations")
SPREAD_METRICS = ("udr", "ap", "vdr", "fpr", "auroc", "ks")
SAME_SEED_NOTE = "cross-pod and old tree; not an estimate of same-pod correlation"
LEARNING_RATE_OF_KEPT = 3.0e-4
TFM_NOTE = "TFM keeps ties in input order and uses floats; small UDR gaps vs TFM are expected"


class ReadError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def stop(message):
    raise ReadError(C.STOP, f"STOP: {message}")


def refuse(message):
    raise ReadError(C.REFUSED, f"REFUSED: {message}")


# ------------------------------------------------------------------------------------------------------------ #
# Settings, the lock and the populations
# ------------------------------------------------------------------------------------------------------------ #
def _canonical(obj):
    return json.dumps(obj, sort_keys=True, default=str, separators=(",", ":"))


def decision_hash(cfg):
    return C.sha256_bytes(_canonical({k: cfg.get(k) for k in DECISION_KEYS}).encode())


def settings_sha():
    return C.settings_hashes().get("SETTINGS.yaml")


def check_lock(cfg):
    """The first read records the decision section's SHA-256; a later read refuses a changed section."""
    lock = C.out("reads", "settings_lock.json")
    now = decision_hash(cfg)
    if lock.is_file():
        held = C.read_json(lock)
        if held.get("decision_sha256") != now:
            stop(f"the decision section of SETTINGS.yaml changed after the first read ({held.get('utc')}); "
                 f"recorded {held.get('decision_sha256', '')[:12]}, now {now[:12]}")
    else:
        C.write_json(lock, {"decision_sha256": now, "settings_sha256": settings_sha(), "utc": C.utc_now(),
                            "keys": list(DECISION_KEYS)})
    return now


def check_approvals(cfg):
    missing = C.blank_approvals(cfg.get("approvals") or {}, ["main_measure", "bar"])
    if missing:
        refuse(f"approval blank in SETTINGS.yaml for: {', '.join(missing)} (approved_by and approved_on)")


def check_rules(cfg):
    """The decision section as the reviewers decided it on 2 November (D1, D2) and corrected on 3 November (D2): no
    fixed floor, the transaction unit, T_1 at the Welch-Satterthwaite degrees of freedom, the paired three-seed bound
    and no null subtraction."""
    if "sd_run_udr_floor" in cfg:
        refuse("SETTINGS.yaml still sets sd_run_udr_floor: no fixed floor is used (reviewers' decision of 2026-11-02); "
               "remove the key")
    unit = str(cfg.get("udr_unit") or "transaction")
    if unit == "account":
        refuse("udr_unit account: the account measure is not defined yet (unit, how alerts count against the 0.6% "
               "capacity, de-duplication, the bootstrap); reads stay on transactions until it is (D1)")
    if unit != "transaction":
        refuse(f"udr_unit {unit!r} is not transaction (the reviewers' decision D1)")
    if str(cfg.get("t1_multiplier") or "welch_satterthwaite") != "welch_satterthwaite":
        refuse(f"t1_multiplier {cfg.get('t1_multiplier')!r}: T_1 uses the t value at the Welch-Satterthwaite degrees "
               "of freedom (D2)")
    if str(cfg.get("three_seed_bound") or "paired") != "paired":
        refuse(f"three_seed_bound {cfg.get('three_seed_bound')!r}: the three-seed bound is paired, the only accepted "
               "value (D2, corrected 3 November). It uses the contrast's own paired seed differences. The pooled form "
               "treated the paired differences' variance and twice the baseline per-fit variance as one quantity; "
               "that needs equal candidate and control variances and covariance, which are not shown, and a more "
               "variable candidate then gets a bound that is too high")
    for where, value in (("null_correction", cfg.get("null_correction", False)),
                         ("select_check null_correction", (cfg.get("select_check") or {}).get("null_correction",
                                                                                               False))):
        if _flag(value):
            refuse(f"{where} {value!r}: no null subtraction is used (D2, corrected 3 November); the baseline pair "
                   "term sd_null is not shown to carry over to a candidate's contrast. Set it to false; the spread "
                   "step still prints sd_null as information")
    pool = [str(x) for x in (cfg.get("spread_pool") or ["kept", "current"])]
    if pool != ["kept", "current"]:
        refuse(f"spread_pool {pool}: the seed spread pools the kept trio and the current-pod base trio "
               "([kept, current], the reviewers' decision D5b)")


def external_score_line(cfg):
    """The reviewers' decision D3c: until a certification (who and when) is recorded in SETTINGS.yaml
    external_1_scr_certified, every read says the score's availability at the decision is assumed (OQ-14)."""
    cert = cfg.get("external_1_scr_certified") or {}
    if isinstance(cert, dict):
        on = cert.get("on", cert.get(True))           # YAML 1.1 reads a bare key `on` as True: both are accepted
        if str(cert.get("by") or "").strip() and str(on or "").strip():
            return None
    return "external_1_scr: availability at the decision assumed, not certified (OQ-14)"


def _flag(v):
    """A settings switch: false, no, off, 0 and a blank are off; anything else is on."""
    return not (v is None or v is False or str(v).strip().lower() in ("", "false", "no", "off", "0"))


def population_spec(cfg, pop):
    if pop not in DECIDING:
        refuse(f"population {pop!r} may not decide. Decisions read rank_b or select_june only. "
               "Test 1 never decides (seed 42 was picked on it); it is reported only")
    spec = (cfg.get("populations") or {}).get(DECIDING[pop]["key"])
    if not spec or "files" not in spec or "targets" not in spec:
        refuse(f"SETTINGS.yaml populations.{DECIDING[pop]['key']} needs files and targets")
    start, end = (int(x) for x in spec["files"])
    test1 = ((cfg.get("populations") or {}).get("test1") or {}).get("files")
    if test1:
        a, b = (int(x) for x in test1)
        if start <= b and a <= end:
            refuse(f"populations.{DECIDING[pop]['key']} files {start}-{end} overlap Test 1 ({a}-{b}); "
                   "Test 1 never decides")
    t0, t1 = (str(x) for x in spec["targets"])
    return SimpleNamespace(pop=pop, name=DECIDING[pop]["name"], start=start, end=end, t0=t0, t1=t1,
                           scorer_population=DECIDING[pop]["scorer_population"])


def decision_population(cfg):
    """rank_b unless settings say select_june, or rank_check.json says FAIL. A missing rank check refuses."""
    want = str(cfg.get("decide_on") or "rank_b")
    if want == "select_june":
        return "select_june", "settings decide_on select_june"
    if want != "rank_b":
        refuse(f"decide_on {want!r} is not rank_b or select_june")
    path = C.out("reads", "rank_check.json")
    if not path.is_file():
        refuse(f"{C.rel(path)} is missing: run nf_rank_check.py first; its result sets the decision population")
    data = C.read_json(path)
    if data.get("decide_on") in ("rank_b", "select_june"):
        return data["decide_on"], ("rank check PASS" if data["decide_on"] == "rank_b" else "rank check FAIL")
    if data.get("decide_on") == "owner":
        refuse("RANK-B failed its rank check and the plan's fallback files passed the same checks, so they take its "
               "place (plan section 3): the owner decides how they are used, or sets SETTINGS.yaml decide_on: "
               "select_june")
    pops = data.get("populations") if isinstance(data.get("populations"), dict) else {}
    rb = pops.get("rank_b") if isinstance(pops.get("rank_b"), dict) else (
        data.get("rank_b") if isinstance(data.get("rank_b"), dict) else {})
    result = str(rb.get("result") or data.get("result") or data.get("status") or "").upper()
    if result.startswith("PASS"):
        return "rank_b", "rank check PASS"
    if result.startswith("FAIL"):
        return "select_june", "rank check FAIL"
    refuse(f"{C.rel(path)} has no PASS or FAIL result")


# ------------------------------------------------------------------------------------------------------------ #
# The run table, receipts and rows
# ------------------------------------------------------------------------------------------------------------ #
def _path(value):
    p = Path(str(value))
    return p if p.is_absolute() else ROOT / p


def _recorded(value):
    """A recorded text value; None, 'None', 'null', 'nan' and blanks are missing ("")."""
    text = "" if value is None else str(value).strip()
    return "" if text.lower() in ("", "none", "null", "nan") else text


def read_runs(path, need_predictions=True):
    """The planner's run table: a JSON file {"runs": [...]} or a CSV, one row per fit."""
    p = _path(path)
    if not p.is_file():
        refuse(f"run table missing: {C.rel(p)}")
    if p.suffix.lower() == ".json":
        records = [{k: "" if v is None else str(v) for k, v in r.items()} for r in (C.read_json(p).get("runs") or [])]
    else:
        records = pd.read_csv(p, dtype=str, keep_default_na=False).to_dict("records")
    need = {"role", "seed"} | ({"predictions"} if need_predictions else set())
    if not records or not need <= set(records[0]):
        refuse(f"run table needs columns {sorted(need)} and at least one row")
    fits = []
    for row in records:
        row.setdefault("predictions", "")
        try:
            seed = int(str(row["seed"]).strip())
        except ValueError:
            refuse(f"seed {row['seed']!r} is not an integer")
        pred = _path(row["predictions"])
        run_dir = _path(row["run_dir"]) if str(row.get("run_dir", "")).strip() else None
        ckpt = row.get("checkpoint", "").strip()
        fits.append(SimpleNamespace(
            role=str(row["role"]).strip().lower(), seed=seed,
            control_kind=str(row.get("control_kind") or "").strip().lower(),
            previous_decision=str(row.get("previous_decision") or "").strip().lower(),
            run=str(row.get("run") or pred.stem.split("__")[0]).strip(),
            downstream=str(row.get("downstream", "")).strip(),
            downstream_sha256=_recorded(row.get("downstream_sha256")),
            # the planner's lift table says the downstream job must have recorded the sha256 (review item 18)
            downstream_sha256_required=_recorded(row.get("downstream_sha256_required")).lower() in ("yes", "true", "1"),
            label=str(row.get("label", "")).strip(), predictions=pred,
            receipt=_path(row["receipt"]) if str(row.get("receipt", "")).strip() else Path(f"{pred}.json"),
            checkpoint=_path(ckpt) if ckpt else (run_dir / "best.ckpt" if run_dir else None), run_dir=run_dir))
    return fits


def run_table_meta(path):
    """The planner's notes beside the runs (membership, a1_adopted); {} for a CSV table."""
    p = _path(path)
    if p.suffix.lower() != ".json":
        return {}
    d = C.read_json(p)
    return {k: d[k] for k in ("membership", "a1_adopted") if k in d}


def check_receipt(fit, spec):
    """predictions_sha256, checkpoint_sha256, file range and validation policy, else STOP (DESIGN.md 8.1)."""
    name = f"{fit.run} seed {fit.seed}"
    if not fit.predictions.is_file():
        stop(f"{name}: prediction file missing: {C.rel(fit.predictions)}")
    if not fit.receipt.is_file():
        stop(f"{name}: receipt missing: {C.rel(fit.receipt)}")
    receipt = C.read_json(fit.receipt)
    pred_sha = C.sha256_file(fit.predictions)
    if receipt.get("predictions_sha256") != pred_sha:
        stop(f"{name}: predictions_sha256 does not match the receipt {C.rel(fit.receipt)}")
    if fit.checkpoint is None or not fit.checkpoint.is_file():
        stop(f"{name}: checkpoint missing ({'not given' if fit.checkpoint is None else C.rel(fit.checkpoint)})")
    ckpt_sha = C.sha256_file(fit.checkpoint)
    if receipt.get("checkpoint_sha256") != ckpt_sha:
        stop(f"{name}: checkpoint_sha256 in the receipt does not match {C.rel(fit.checkpoint)}")
    files = receipt.get("files") or {}
    try:
        got = (int(files.get("start")), int(files.get("end")))
    except (TypeError, ValueError):
        got = None
    if got != (spec.start, spec.end):
        stop(f"{name}: receipt files {got} are not the {spec.name} range ({spec.start}, {spec.end})")
    policy = receipt.get("validation_policy") or {}
    policy_name = str(policy.get("name", "")) if isinstance(policy, dict) else str(policy)
    if (receipt.get("scoring") != "target-ending" or receipt.get("max_window_rows") != WINDOW_CAP
            or "target_ending" not in policy_name
            or (isinstance(policy, dict) and policy.get("max_window_rows") not in (None, WINDOW_CAP))):
        stop(f"{name}: receipt is not target-ending scoring with window cap {WINDOW_CAP} "
             f"(scoring={receipt.get('scoring')}, max_window_rows={receipt.get('max_window_rows')}, "
             f"validation_policy={policy_name or None})")
    exposure = Path(f"{fit.predictions}.exposure.json")
    if exposure.is_file():
        recorded = C.read_json(exposure).get("population")
        if recorded is not None and recorded != spec.scorer_population:
            stop(f"{name}: scored as population {recorded}, not {spec.scorer_population} ({spec.name})")
    return {"role": fit.role, "seed": fit.seed, "run": fit.run, "predictions": C.rel(fit.predictions),
            "predictions_sha256": pred_sha, "checkpoint_sha256": ckpt_sha, "receipt": C.rel(fit.receipt)}


def num_workers(fit):
    if fit.run_dir is None:
        return None
    for name in ("resolved_train_v2.yaml", "config.yaml", "resolved_config.yaml"):
        p = fit.run_dir / name
        if p.is_file():
            try:
                value = ((C.load_yaml(p) or {}).get("training") or {}).get("num_workers")
                return None if value is None else int(value)
            except Exception:  # noqa: BLE001 - a config we cannot read only hides the note's number
                return None
    return None


def _layout():
    import nf_layout as L
    return L


def load_raw_rows(spec, raw_base, cred=None):
    """The five raw columns of every file of the range (full-file history), then the target window."""
    L = _layout()
    lay = L.resolve(["raw_join", "s3", "business_metrics"])
    build_file_list = L.attr("s3", "build_file_list")
    fs = None
    if str(raw_base).startswith("s3://"):
        fs = L.attr("s3", "thin_read_filesystem")(cred)
    else:
        raw_base = str(_path(raw_base))
    files = build_file_list(str(raw_base), spec.start, spec.end)
    args = SimpleNamespace(id=ID, account=ACCT, order_col=TIME, target=LABEL, positive_label=1,
                           amount_col=AMOUNT, exclude_col=None)
    try:
        raw = L.attr("raw_join", "load_raw")(files, fs, args)
        mask = np.asarray(L.attr("raw_join", "target_mask")(raw, spec.t0, spec.t1), dtype=bool)
    except (ValueError, FileNotFoundError, OSError) as e:
        stop(f"the raw join of {spec.name} files {spec.start}-{spec.end} failed: {e}")
    frame = pd.DataFrame({"_acct": raw["_acct"].map(str).to_numpy(), "_id": raw["_id"].map(str).to_numpy(),
                          "_label": np.asarray(raw["_label"], dtype=np.int64),
                          "_amount": pd.to_numeric(raw["_amount"], errors="coerce").to_numpy(float)
                          if "_amount" in raw else np.full(len(raw), np.nan)})
    return frame, mask, lay.layout


def _prediction_frame(fit, columns=(ACCT, ID, LABEL, SCORE)):
    import pyarrow.parquet as pq
    have = set(pq.ParquetFile(fit.predictions).schema_arrow.names)
    missing = [c for c in columns if c not in have]
    if missing:
        stop(f"{fit.run} seed {fit.seed}: prediction file lacks {missing}")
    cols = list(columns) + ([AMOUNT] if AMOUNT in have else [])
    pred = pq.read_table(fit.predictions, columns=cols).to_pandas()
    frame = pd.DataFrame({"_acct": pred[ACCT].map(str).to_numpy(), "_id": pred[ID].map(str).to_numpy(),
                          "_plabel": pd.to_numeric(pred[LABEL], errors="coerce").to_numpy(float),
                          "_score": pd.to_numeric(pred[SCORE], errors="coerce").to_numpy(float)})
    if AMOUNT in pred:
        frame["_pamount"] = pd.to_numeric(pred[AMOUNT], errors="coerce").to_numpy(float)
    if frame.duplicated(["_acct", "_id"]).any():
        stop(f"{fit.run} seed {fit.seed}: duplicate (account, id) rows in the prediction file")
    return frame


def align(fits, raw, mask):
    """Every fit holds exactly the read's rows R with the raw labels. Returns the rows and one score per fit."""
    rows = raw.loc[mask, ["_acct", "_id", "_label", "_amount"]].reset_index(drop=True)
    all_keys = raw[["_acct", "_id"]]
    scores, amounts = [], []
    for fit in fits:
        name = f"{fit.run} seed {fit.seed}"
        pred = _prediction_frame(fit)
        extra = pred.merge(all_keys, on=["_acct", "_id"], how="left", indicator=True)
        n_extra = int((extra["_merge"] == "left_only").sum())
        if n_extra:
            stop(f"{name}: {n_extra} predicted rows are not in the raw files of the range")
        merged = rows.merge(pred, on=["_acct", "_id"], how="left", validate="one_to_one")
        n_missing = int(merged["_score"].isna().sum())
        if n_missing:
            stop(f"{name}: does not hold the read's rows ({n_missing} of {len(rows)} missing); every fit must "
                 "hold exactly the same (account, id) set")
        if not np.array_equal(merged["_plabel"].to_numpy(float), rows["_label"].to_numpy(float)):
            stop(f"{name}: labels differ from the raw labels")
        if not np.isfinite(merged["_score"].to_numpy(float)).all():
            stop(f"{name}: scores are not finite")
        scores.append(merged["_score"].to_numpy(float))
        amounts.append(merged["_pamount"].to_numpy(float) if "_pamount" in merged else None)
    if all(a is not None for a in amounts):
        for a, fit in zip(amounts[1:], fits[1:]):
            if not np.array_equal(a, amounts[0], equal_nan=True):
                stop(f"{fit.run} seed {fit.seed}: transaction_amt differs from the first fit's")
        raw_amount = rows["_amount"].to_numpy(float)
        if np.isfinite(raw_amount).any() and not np.allclose(amounts[0], raw_amount, rtol=1e-6, atol=1e-6,
                                                             equal_nan=True):
            stop("transaction_amt in the prediction files differs from the raw files")
        amount, amount_source = amounts[0], "prediction file"
    elif any(a is not None for a in amounts):
        amount, amount_source = rows["_amount"].to_numpy(float), "raw join (only some prediction files had it)"
    else:
        amount, amount_source = rows["_amount"].to_numpy(float), "raw join"
    keys = R.identity_keys(rows["_acct"], rows["_id"])
    codes, units = R.account_units(rows["_acct"])
    data = SimpleNamespace(y=rows["_label"].to_numpy(np.int64), amounts=amount, amount_source=amount_source,
                           key_rank=R.key_ranks(keys), codes=codes, n_units=len(units), rows=len(rows))
    data.amount_reason = R.amount_reason(amount)
    return data, scores


def ranked(data, score):
    return R.RankedScore(score, data.y, data.codes, data.key_rank, data.amounts)


def engine_check(data, scores, rankeds, first_draws):
    """The point and the first draws recomputed with the project's _alert at 6 per mille and _ranking."""
    L = _layout()
    alert, ranking = L.attr("business_metrics", "_alert"), L.attr("business_metrics", "_ranking")
    keys = R.compact_keys(data.key_rank)
    amounts = None if data.amount_reason else data.amounts
    for score, rk in zip(scores, rankeds):
        order, _ = ranking(np.asarray(score, float), keys)
        for mult in [None] + list(first_draws):
            weights = None if mult is None else np.asarray(mult, dtype=np.int64)[data.codes]
            a = alert(data.y, amounts, data.amount_reason, order, 6, weights)
            e = rk.evaluate(mult)
            same = (a["alerts"] == e["outsorted"] and a["true_frauds_caught"] == e["frauds_outsorted"]
                    and _same(a["detection_rate"], e["udr"]) and _same(a["value_detection_rate"], e["vdr"], 1e-9))
            if not same:
                stop("engine differs from _alert at 6 per mille; the read is not trusted")
    return "equal"


def _same(a, b, rtol=0.0):
    a_nan = a is None or (isinstance(a, float) and math.isnan(a))
    b_nan = b is None or (isinstance(b, float) and math.isnan(b))
    if a_nan or b_nan:
        return a_nan and b_nan
    return a == b if rtol == 0 else math.isclose(a, b, rel_tol=rtol, abs_tol=1e-12)


# ------------------------------------------------------------------------------------------------------------ #
# Thresholds and decisions (DESIGN.md 8.5, 8.6)
# ------------------------------------------------------------------------------------------------------------ #
def t_one_sided(df, level=0.95):
    """The one-sided t quantile at df degrees of freedom (scipy, a declared dependency)."""
    from scipy.stats import t as student_t
    return float(student_t.ppf(level, df))


ZERO_SPREAD = ("the UDR seed spread sd_run is zero (possible for a top-k count even with different valid fits): "
               "T_1's seed term has no estimate, so the one-seed noise threshold is undefined; no one-seed adoption")


def t1_terms(sd_pair, sd_run, df_run=2):
    """T_1 (the reviewers' decision D2, corrected 3 November): A = sd_pair^2, B = 2 x sd_run^2,
    nu = (A + B)^2 / (B^2 / df_run) (Welch-Satterthwaite), T_1 = t(0.95, nu) x sqrt(A + B). sd_pair is the read's own
    account bootstrap SD of the one-seed difference and sd_run the per-fit seed spread with df_run degrees of
    freedom. No null subtraction. B = 2 x sd_run^2 is an operational one-seed rule: it assumes the candidate's and
    the control's seed variances are equal, because one fit per arm gives no other estimate.
    A spread that is not finite or below zero stops (exit 3). A spread of zero is reported, not a stop: T_1 is
    undefined and ``undefined`` holds the reason, so the read routes a one-seed gain above zero to the seed path."""
    if not (_finite(sd_run) and float(sd_run) >= 0):
        stop(f"the seed spread sd_run is {sd_run}: T_1 needs a finite measured spread")
    a = float(sd_pair) ** 2 if _finite(sd_pair) else float("nan")
    b = 2.0 * float(sd_run) ** 2
    undefined = ZERO_SPREAD if b == 0.0 and math.isfinite(a) else None
    if b > 0 and math.isfinite(a):
        nu = (a + b) ** 2 / (b * b / float(df_run))
        tq = t_one_sided(nu)
        value = tq * math.sqrt(a + b)
    else:
        nu = tq = value = float("nan")
    return {"t1": float(value), "a": a, "b": b, "nu": nu, "t": tq, "df_run": df_run, "sd_pair": sd_pair,
            "sd_run": sd_run, "undefined": undefined,
            "assumes": "equal candidate and control seed variance (one fit per arm gives no other estimate)"}


def t1(sd_pair, sd_run, df_run=2):
    return t1_terms(sd_pair, sd_run, df_run)["t1"]


def lb_three(gain, diffs, v_acct):
    """The paired three-seed bound (the reviewers' decision D2, corrected 3 November): k = len(diffs) (at least 2),
    s_d = std(diffs, ddof 1), the SD of the k paired seed differences, t one-sided 95% at k - 1 degrees of freedom and
    LB_3 = gain - t x sqrt(v_acct + s_d^2 / k). It uses the contrast's own paired variability only: no pooling with
    the baseline spread and no sd_null subtraction. Returns (LB_3, s_d, t, k - 1)."""
    k = len(diffs)
    if k < 2:
        raise ValueError(f"the three-seed bound needs at least two paired seed differences, got {k}")
    s_d = float(np.std(np.asarray(diffs, float), ddof=1))
    tq = t_one_sided(k - 1)
    return float(gain - tq * math.sqrt(float(v_acct) + s_d ** 2 / k)), s_d, tq, k - 1


def _finite(x):
    try:
        return x is not None and math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


def decide(kind, seeds, gain, t1_udr, bar, lb, lb3=None, hi=None, t1_undefined=None):
    """The decision for one read. Returns decision, reason, and whether it would change the kept inputs.
    An undefined gain, required T1 or pruning upper bound stops the read (exit 3). ``t1_undefined`` (a reason) says
    T1 is undefined because the seed spread is zero (D2-floor): that is not a stop; the one-seed noise-based
    decision is skipped and a gain above zero goes to seeds 43 and 44, where the three-seed read decides."""
    if not _finite(gain):
        stop(f"the gain is not a number ({gain}): no decision is made on an undefined gain")
    zero_spread = seeds == 1 and kind in ("add", "month_out", "calendar") and bool(t1_undefined)
    if seeds == 1 and kind in ("add", "month_out", "calendar") and not _finite(t1_udr) and not zero_spread:
        stop(f"T1 is not a number ({t1_udr}): no one-seed decision is made without the noise threshold")
    if zero_spread:
        if gain <= 0:
            words = {"add": "KEEP THE CONTROL", "month_out": "KEEP MONTH", "calendar": "KEEP THE CALENDAR"}
            return words[kind], f"gain {gain:+.4f} is zero or below (T1 undefined: {t1_undefined})", False
        return ("RUN SEEDS 43 AND 44", f"gain {gain:+.4f} is above zero and T1 is undefined ({t1_undefined}); the "
                "three-seed read decides", False)
    if kind == "add":
        if seeds == 1:
            # the plan's one-fit rule: at one seed the lower end LB is the account bootstrap's alone, because T1
            # already carries the seed term. A gain at or above T1 that meets the step's rule is adopted; any other
            # gain above zero runs seeds 43 and 44, so a larger gain never gets a worse outcome than a smaller one.
            if gain <= 0:
                return "KEEP THE CONTROL", f"gain {gain:+.4f} is zero or below", False
            if gain >= t1_udr and gain >= bar and lb is not None and lb > 0:
                return ("ADOPT", f"gain {gain:+.4f} >= T1 {t1_udr:.4f}, >= bar {bar:+.4f}, account bootstrap LB "
                        f"{lb:+.4f} > 0", True)
            if gain < t1_udr:
                return ("RUN SEEDS 43 AND 44", f"gain {gain:+.4f} is above zero but below T1 {t1_udr:.4f}", False)
            why = []
            if gain < bar:
                why.append(f"gain {gain:+.4f} is at or above T1 {t1_udr:.4f} but below the bar {bar:+.4f}")
            if lb is None or lb <= 0:
                why.append(f"account bootstrap LB {_f(lb)} is not above zero")
            return "RUN SEEDS 43 AND 44", "; ".join(why) + "; seeds 43 and 44 decide", False
        if gain >= bar and lb3 is not None and lb3 > 0:
            return "ADOPT", f"gain {gain:+.4f} >= bar {bar:+.4f} and LB_3 {lb3:+.4f} > 0", True
        why = f"gain {gain:+.4f}, bar {bar:+.4f}, LB_3 {_f(lb3)}"
        return ("KEEP THE CONTROL", ("unresolved: " if gain > 0 else "") + why, False)
    if kind == "month_out":
        h = gain  # UDR(month out) minus UDR(month in)
        if seeds == 1:
            # the one-fit rule first (the gain of month out is h), then the month rule
            if h <= 0:
                return "KEEP MONTH", f"h {h:+.4f} is zero or below: removing month gains nothing", False
            if h < t1_udr:
                return ("RUN SEEDS 43 AND 44", f"h {h:+.4f} is above zero but below T1 {t1_udr:.4f}; one seed cannot "
                        "show that removing month does not lose", False)
            return "MONTH OUT", f"h {h:+.4f} >= T1 {t1_udr:.4f}, if month out passes its check", True
        if h >= 0:
            return "MONTH OUT", f"mean h {h:+.4f} >= 0, if month out passes its check", True
        return "KEEP MONTH", f"mean h {h:+.4f} is below zero", False
    if kind == "calendar":
        # the optional cyclical calendar step is read under the month rule against the kept fit: one-fit rule first
        # (h = UDR(cyclical) minus UDR(kept)), then the month rule (no loss at three seeds) and its SELECT check
        d, why, ch = decide("month_out", seeds, gain, t1_udr, bar, lb, lb3, hi)
        words = {"MONTH OUT": "CALENDAR CYCLICAL", "KEEP MONTH": "KEEP THE CALENDAR"}
        return words.get(d, d), why.replace("removing month", "the cyclical calendar"), ch
    if kind == "prune":
        # read at seed 42 only, by the pruning rule alone (the plan): the account bootstrap's lower end
        if seeds != 1:
            raise ValueError("pruning is read at seed 42 only")
        if not _finite(hi):     # D4b: an undefined interval never falls through to KEEP THE SMALLER LIST
            stop(f"the pruning upper bound is not finite ({hi}): the interval's upper end is not a number, so no "
                 "pruning decision is made")
        u = -gain  # unpruned minus pruned
        lb_u = -hi
        if u >= bar and lb_u > 0:
            return ("KEEP THE UNPRUNED LIST", f"unpruned beats pruned by {u:+.4f} >= bar {bar:+.4f}, "
                    f"LB {lb_u:+.4f} > 0", False)
        return ("KEEP THE SMALLER LIST", f"unpruned minus pruned {u:+.4f}, LB {_f(lb_u)}: not at the bar with "
                "LB > 0", True)
    raise ValueError(f"unknown kind {kind}")


def seed_spread(spreads, m):
    """(s_m, df, source) for one measure: the larger of the spread files' sd_run (the reviewers' decision D2: RANK-B
    and SELECT June when RANK-B decides, SELECT June alone when SELECT decides); a tie takes the smaller df."""
    best = None
    for name, data in spreads.items():
        r = ((data.get("metrics") or {}).get(m)) or {}
        v = r.get("sd_run")
        if not _finite(v):
            continue
        cand = (float(v), -int(r.get("df") or 2), name)
        if best is None or cand > best:
            best = cand
    if best is None:
        return None, None, None
    return best[0], -best[1], best[2]


def pair_term(spread, m):
    """sd_null of one measure in one spread file (the same-recipe pair term), 0 when the file has none."""
    v = (((spread or {}).get("metrics") or {}).get(m) or {}).get("sd_null")
    return float(v) if _finite(v) else 0.0


RULE_K_NOTE = ("k is an operational development rule; its error rates under unequal candidate and control "
               "variances are not established")


def select_check(metrics, k_se, spreads, n_seeds, names=("ap", "auroc", "ks", "udr")):
    """The SELECT check (the reviewers' decision D2, corrected 3 November): each paired difference (candidate minus
    control, mean over the n seeds) must not fall below -k x sqrt(SE_acct^2 + 2 x s_m^2 / n). SE_acct is the account
    bootstrap SD of that difference on SELECT June and s_m the larger of its spreads (seed_spread). No null
    subtraction. k (2.5, 3.5 when SELECT decides) is an operational development rule (RULE_K_NOTE). A measure with no
    spread or no SD fails."""
    rows, ok = [], True
    for m in names:
        d, sd = metrics[m]["gain"], metrics[m]["sd"]
        s_m, df_m, src = seed_spread(spreads, m)
        se = None
        if sd is not None and _finite(sd) and s_m is not None:
            se = math.sqrt(float(sd) ** 2 + 2.0 * s_m ** 2 / n_seeds)
        limit = None if se is None else -k_se * se
        passed = limit is not None and _finite(d) and d >= limit
        ok &= bool(passed)
        rows.append({"metric": m, "difference": d, "sd": sd, "s_m": s_m, "s_m_source": src,
                     "se": se, "limit": limit, "pass": bool(passed)})
    return {"pass": bool(ok), "k_se": k_se, "n_seeds": n_seeds, "rows": rows, "k_note": RULE_K_NOTE}


def conflict_check(metrics, k_se, spreads, n_seeds, vdr_null_reason, names=("ap", "vdr")):
    """The conflict line (the reviewers' decision D1, with the D2 correction of 3 November): when a read would change
    the kept inputs and its AP difference, or its VDR difference where VDR is defined, is below
    -k x sqrt(sd^2 + 2 x s_m^2 / n), the read says so. No null subtraction; k is an operational development rule
    (RULE_K_NOTE). UDR still decides; the decision does not change."""
    rows = []
    for m in names:
        if m == "vdr" and vdr_null_reason:
            continue
        d, sd = metrics[m]["gain"], metrics[m]["sd"]
        s_m, _, _ = seed_spread(spreads, m)
        if sd is None or not _finite(sd) or s_m is None or not _finite(d):
            continue
        se = math.sqrt(float(sd) ** 2 + 2.0 * s_m ** 2 / n_seeds)
        rows.append({"metric": m, "difference": float(d), "se": se, "limit": -k_se * se,
                     "conflict": bool(d < -k_se * se)})
    hits = [r for r in rows if r["conflict"]]
    line = None
    if hits:
        line = "conflict: " + "; ".join(f"{r['metric'].upper()} {r['difference']:+.4f} below {r['limit']:+.4f}"
                                        for r in hits) + " (UDR decides; the decision stands)"
    return {"k_se": k_se, "rows": rows, "line": line}


def finalize(decision, check):
    if decision not in CHANGES:
        return decision, None
    if check["pass"]:
        return decision, "the SELECT check passed"
    return CHANGES[decision], f"the SELECT check failed, so {decision} becomes {CHANGES[decision]}"


def _f(x, digits=4, sign=True):
    if x is None or (isinstance(x, float) and not math.isfinite(x)):
        return "n/a"
    return f"{x:+.{digits}f}" if sign else f"{x:.{digits}f}"


# ------------------------------------------------------------------------------------------------------------ #
# Shared pieces of the commands
# ------------------------------------------------------------------------------------------------------------ #
def step_kind(step, given=None):
    given = {"month": "month_out"}.get(given, given)
    if given:
        if given not in KINDS:
            refuse(f"--kind must be one of {KINDS}")
        return given
    try:
        for s in (C.steps().get("steps") or []):
            if str(s.get("name")) == step and s.get("kind") in ("month_out", "prune", "calendar_cyclical"):
                return {"calendar_cyclical": "calendar"}.get(s["kind"], s["kind"])
    except FileNotFoundError:
        pass
    return {"B": "month_out", "P": "prune", "C": "calendar"}.get(step, "add")


def pair_fits(fits):
    cands = sorted([f for f in fits if f.role == "candidate"], key=lambda f: f.seed)
    ctrls = sorted([f for f in fits if f.role == "control"], key=lambda f: f.seed)
    if not cands or not ctrls:
        refuse("the run table needs candidate and control rows; every read is blocked until the control exists")
    if [f.seed for f in cands] != [f.seed for f in ctrls] or len({f.seed for f in cands}) != len(cands):
        refuse(f"candidate seeds {[f.seed for f in cands]} and control seeds {[f.seed for f in ctrls]} must be "
               "the same distinct seeds")
    if len(cands) not in (1, 3):
        refuse(f"a read uses 1 seed or 3 seeds, not {len(cands)}")
    allowed = planned_seeds()
    want = allowed[:1] if len(cands) == 1 else sorted(allowed)
    if [f.seed for f in cands] != want:
        refuse(f"a {len(cands)}-seed read uses seeds {want}, not {[f.seed for f in cands]}")
    return cands, ctrls


def planned_seeds():
    seeds = C.settings().get("seeds") or {}
    return [int(seeds.get("main", 42))] + [int(x) for x in seeds.get("confirm", [43, 44])]


def saved_or_stale(path, inputs):
    """A saved read with the same inputs is returned; one with other inputs stops (review item 18)."""
    if not path.is_file():
        return None
    saved = C.read_json(path)
    if saved.get("inputs") != inputs:
        stop(f"inputs changed since {C.rel(path)} was saved: rename the old read to read again")
    return saved


def _out_path(args, default_name):
    if getattr(args, "out", None):
        p = _path(args.out)
        p.parent.mkdir(parents=True, exist_ok=True)
        return p
    return C.out("reads", default_name)


ENV_KEYS = ("torch", "lightning", "cuda", "gpu")


def _upstream():
    try:
        return C.upstream() or {}
    except FileNotFoundError:
        return {}


def is_kept(fit):
    """A kept run (under UPSTREAM.yaml kept.dir, models/ by default): it has no run manifest of its own."""
    kept = ROOT / str((_upstream().get("kept") or {}).get("dir") or "models/sequential_hier_allpos_h20_chunk")
    where = fit.run_dir or (fit.checkpoint.parent if fit.checkpoint else None)
    return where is not None and kept.resolve() in [where.resolve(), *where.resolve().parents]


def environment(fit):
    """torch, Lightning, CUDA and GPU of a fit: its run manifest's latest start or resume event, else the kept
    runs' recorded environment (UPSTREAM.yaml kept.environment). Unknown values are None."""
    if fit.run_dir is not None and (fit.run_dir / "run_manifest_v2.json").is_file():
        man = C.read_json(fit.run_dir / "run_manifest_v2.json")
        events = [man.get("start") or {}] + list(man.get("resume_events") or [])
        ev = events[-1] or {}
        return {k: ev.get(k) for k in ENV_KEYS}, "run manifest"
    if is_kept(fit):
        env = (_upstream().get("kept") or {}).get("environment") or {}
        return {k: env.get(k) for k in ENV_KEYS}, "UPSTREAM.yaml kept.environment"
    return {k: None for k in ENV_KEYS}, "not recorded"


def check_environments(cands, ctrls):
    """Design review item 15: a control that ran on another torch, Lightning, CUDA or GPU than its candidate is not
    a valid control (refit it). Values one side does not record are listed as unknown."""
    pairs, unknown = [], set()
    for c, k in zip(cands, ctrls):
        (ec, sc), (ek, sk) = environment(c), environment(k)
        for key in ENV_KEYS:
            if ec[key] and ek[key] and str(ec[key]) != str(ek[key]):
                stop(f"seed {c.seed}: the control ran on {key} {ek[key]}, the candidate on {ec[key]}; it is not a "
                     "valid control: refit it on this machine")
            if not (ec[key] and ek[key]):
                unknown.add(key)
        pairs.append({"seed": c.seed, "candidate": ec, "candidate_source": sc, "control": ek, "control_source": sk})
    return {"pairs": pairs, "unknown": sorted(unknown, key=ENV_KEYS.index)}


def guard_record():
    g = C.out("guard", "guard.jsonl")
    if not g.is_file():
        return None
    lines = [ln for ln in g.read_text(encoding="utf-8").splitlines() if ln.strip()]
    return json.loads(lines[-1]) if lines else None


def check_kept_controls(ctrls):
    """Design review item 21: a kept checkpoint serves as a control only when the guard read stage 1's own result
    files and every one passed (guard.jsonl stage1_ok), never on a hand-typed flag."""
    kept = [k for k in ctrls if is_kept(k)]
    if not kept:
        return None
    rec = guard_record()
    if not (rec and rec.get("stage1_ok") is True):
        stop(f"kept seed {', '.join(str(k.seed) for k in kept)} control(s): valid only when the guard found stage "
             "1's own result files all passed (guard.jsonl stage1_ok); refit the controls")
    return {"stage1_ok": True, "guard_utc": rec.get("utc"), "stage1_results": rec.get("stage1_results")}


def environment_lines(rec):
    env = rec.get("environment") or {}
    unknown = env.get("unknown") or []
    line = "environment: torch, Lightning, CUDA, GPU equal where recorded"
    if unknown:
        line += f"; not recorded: {', '.join(unknown)}"
    out = [line]
    if rec.get("kept_controls_guard"):
        kept = rec["kept_controls_guard"]
        gap = (kept.get("stage1_results") or {}).get("rescore_summary", {})
        wording = ("other applicable checks passed; owner-accepted rescore gap: "
                   + gap["accept_rescore_gap_reason"] if gap.get("accepted_gap") is True
                   else "all applicable stage 1 checks passed")
        out.append(f"kept controls: {wording} (guard {kept.get('guard_utc')})")
    return out


def _bootstrap(cfg):
    b = cfg.get("bootstrap") or {}
    return int(b.get("draws", 2000)), int(b.get("seed", 20261102)), float(b.get("interval", 90))


def _write(path_json, record, text):
    C.write_json(path_json, _clean(record))
    path_json.with_suffix(".txt").write_text(text + "\n", encoding="utf-8")


def _clean(obj):
    if isinstance(obj, dict):
        return {str(k): _clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_clean(v) for v in obj]
    if isinstance(obj, (np.floating, float)):
        return None if not math.isfinite(float(obj)) else float(obj)
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, np.ndarray):
        return _clean(obj.tolist())
    return obj


def _log_read(step, spec, fits, decision):
    runs = ",".join(f"{f.role}:{f.run}:{f.seed}" for f in fits)
    C.append_line(C.out("READS.log"), f"{C.utc_now()} {step} {spec.name} files={spec.start}-{spec.end} "
                                       f"runs={runs} settings={(settings_sha() or 'none')[:12]} decision={decision}")


def _log_decision(step, decision, reason):
    C.append_line(C.out("DECISIONS.log"), f"{C.utc_now()} {step} {decision} | {reason}")


def _raw_base(args, receipts_dir_fit):
    if args.raw_base:
        return args.raw_base
    receipt = C.read_json(receipts_dir_fit.receipt)
    base = (receipt.get("files") or {}).get("base")
    if not base:
        refuse("give --raw-base: the control's receipt names no files base")
    return base


def _metric_rows(metrics):
    lines = [f"{'metric':<10}{'cand':>9}{'control':>9}{'diff':>9}{'boot_sd':>9}{'lo5':>9}{'hi95':>9}"]
    for m, label in (("udr", "UDR@0.6"), ("ap", "AP"), ("vdr", "VDR@0.6"), ("fpr", "FP/TP@0.6")):
        r = metrics[m]
        digits = 2 if m == "fpr" else 4
        lines.append(f"{label:<10}{_f(r['candidate_mean'], digits, False):>9}{_f(r['control_mean'], digits, False):>9}"
                     f"{_f(r['gain'], digits):>9}{_f(r['sd'], digits, False):>9}{_f(r['lo'], digits):>9}"
                     f"{_f(r['hi'], digits):>9}")
    lines.append("FP/TP@0.6: false alerts per caught fraud (the bank's FPR; lower better)")
    return lines


# ------------------------------------------------------------------------------------------------------------ #
# spread
# ------------------------------------------------------------------------------------------------------------ #
def _sd(values):
    v = np.asarray([x for x in values if _finite(x)], float)
    return float(np.std(v, ddof=1)) if len(v) > 1 else None


def account_count_line(counts):
    return ("fraud accounts with a caught fraud transaction (information; not an account-level DR): "
            + ", ".join(f"{k} {a} of {b}" for k, (a, b) in counts.items()))


def cmd_spread(args):
    """The seed spread (the reviewers' decisions D2 and D5b). Rows with role kept (seeds 42, 43, 44) are the kept
    trio; rows with role current (the seed-42 base control and the base refits at 43 and 44) the current-pod trio.
    Per measure: each trio's SD, the SD pooled within the trios (sum of squared deviations from each trio's mean over
    the pooled degrees of freedom, 4 with two trios), and sd_null, the account bootstrap SD of the paired difference
    of two fits of one recipe (root mean square over every within-trio pair, the settings' draws and seed), printed
    as information only: no decision subtracts it (D2, corrected 3 November). Two fits of one checkpoint or one
    prediction file, or a UDR spread that is not finite, stop (exit 3). A UDR spread of zero is reported and is not
    a stop: a top-k count can give it even with different valid fits; the reads then have no one-seed T_1 and send a
    gain above zero to seeds 43 and 44 (D2-floor)."""
    cfg = C.settings()
    spec = population_spec(cfg, args.population)
    fits = read_runs(args.run_table)
    trios = {}
    for f in fits:
        if f.role not in ("kept", "current"):
            refuse(f"the spread reads roles kept and current, not {f.role!r}")
        trios.setdefault(f.role, []).append(f)
    if "kept" not in trios:
        refuse(f"the spread reads the kept seeds {sorted(planned_seeds())}, one each; the run table has none")
    for role, fs in trios.items():
        seeds_ = sorted(f.seed for f in fs)
        if seeds_ != sorted(planned_seeds()):
            refuse(f"the spread reads the {role} seeds {sorted(planned_seeds())}, one each; got {seeds_}")
    order = [f for role in ("kept", "current") for f in sorted(trios.get(role, []), key=lambda f: f.seed)]
    seeds = [f.seed for f in order if f.role == "kept"]
    inputs = [check_receipt(f, spec) for f in order]
    for key in ("checkpoint_sha256", "predictions_sha256"):
        seen = {}
        for f, inp in zip(order, inputs):
            if inp[key] in seen:
                stop(f"{seen[inp[key]]} and {f.role} {f.run} seed {f.seed} share one {key.split('_')[0]} "
                     f"({inp[key][:12]}): the spread needs distinct fits; find the cause before any read")
            seen[inp[key]] = f"{f.role} {f.run} seed {f.seed}"
    path = _out_path(args, f"spread_{spec.pop}.json")
    saved = saved_or_stale(path, inputs)
    if saved is not None:
        print(path.with_suffix(".txt").read_text(encoding="utf-8").rstrip())
        return C.OK
    raw, mask, layout = load_raw_rows(spec, _raw_base(args, order[0]), args.cred)
    data, scores = align(order, raw, mask)
    rk = [ranked(data, sc) for sc in scores]
    points = [r.evaluate(None) for r in rk]
    idx = {role: [i for i, f in enumerate(order) if f.role == role] for role in ("kept", "current") if role in trios}
    pairs = [(a, b) for ix in idx.values() for k_, a in enumerate(ix) for b in ix[k_ + 1:]]
    draws, bseed, interval = _bootstrap(cfg)
    pvar = R.pair_variances(rk, pairs, data.n_units, draws, bseed, SPREAD_METRICS)
    per_metric = {}
    for m in SPREAD_METRICS:
        vals = {role: [float(points[i][m]) for i in ix] for role, ix in idx.items()}
        ss, df = 0.0, 0
        for v in vals.values():
            fv = np.asarray([x for x in v if _finite(x)], float)
            if len(fv) > 1:
                ss += float(((fv - fv.mean()) ** 2).sum())
                df += len(fv) - 1
        null = {}
        for role, ix in idx.items():
            vs = [pvar[(a, b)][m] for (a, b) in pairs if a in ix and b in ix and pvar[(a, b)][m] is not None]
            null[role] = math.sqrt(float(np.mean(vs))) if vs else None
        allv = [pvar[p][m] for p in pairs if pvar[p][m] is not None]
        kept_f = [x for x in vals["kept"] if _finite(x)]
        per_metric[m] = {"values": vals["kept"], "values_current": vals.get("current"),
                         "mean": float(np.mean(kept_f)) if kept_f else None,
                         "sd_run": math.sqrt(ss / df) if df else None, "df": int(df),
                         "sd_kept": _sd(vals["kept"]), "sd_current": _sd(vals["current"]) if "current" in vals else None,
                         "sd_null": math.sqrt(float(np.mean(allv))) if allv else None,
                         "sd_null_kept": null.get("kept"), "sd_null_current": null.get("current"),
                         "pairs": len(allv)}
    sd_udr = per_metric["udr"]["sd_run"]
    if not (_finite(sd_udr) and sd_udr >= 0):
        stop(f"the UDR seed spread is {sd_udr}: not finite; find the cause before any read (D2)")
    zero_udr = float(sd_udr) == 0.0
    same_seed = {}
    if "current" in idx:
        for i in idx["kept"]:
            for j in idx["current"]:
                if order[i].seed == order[j].seed:
                    same_seed[str(order[i].seed)] = {m: float(points[i][m]) - float(points[j][m]) for m in ("ap", "udr")}
    counts = {f"{f.role} {f.seed}": rk[i].fraud_accounts_caught() for i, f in enumerate(order)}
    record = {"kind": "spread", "population": spec.pop, "files": [spec.start, spec.end],
              "targets": [spec.t0, spec.t1], "seeds": seeds, "trios": sorted(idx), "rows": data.rows,
              "frauds": int(data.y.sum()), "accounts": data.n_units, "metrics": per_metric,
              "udr_spread_zero": zero_udr, "sd_null_use": "information only (D2)",
              "same_seed_information": {"note": SAME_SEED_NOTE, "kept_minus_current": same_seed} if same_seed else None,
              "account_counts": {k: list(v) for k, v in counts.items()},
              "bootstrap": {"draws": draws, "seed": bseed}, "inputs": inputs, "utc": C.utc_now(),
              "layout": layout, "amount_source": data.amount_source, "vdr_null_reason": data.amount_reason}
    trio_names = " and ".join(f"{r} {'/'.join(str(order[i].seed) for i in ix)}" for r, ix in idx.items())
    lines = [f"layout={layout}",
             f"rows {data.rows:,}  frauds {int(data.y.sum()):,}  accounts {data.n_units:,}  trios: {trio_names}",
             f"{'metric':<10}{'kept 42/43/44':>24}{'sd kept':>9}{'sd curr':>9}{'pooled':>9}{'df':>4}{'sd_null':>9}"]
    for m, label in (("udr", "UDR@0.6"), ("ap", "AP"), ("vdr", "VDR@0.6"), ("fpr", "FP/TP@0.6"), ("auroc", "AUROC"),
                     ("ks", "KS")):
        r = per_metric[m]
        lines.append(f"{label:<10}" + "".join(f"{_f(v, 4, False):>8}" for v in r["values"])
                     + f"{_f(r['sd_kept'], 4, False):>9}{_f(r['sd_current'], 4, False):>9}"
                     f"{_f(r['sd_run'], 4, False):>9}{r['df']:>4}{_f(r['sd_null'], 4, False):>9}")
    if "current" in idx:
        lines.append("current-pod trio " + "/".join(str(order[i].seed) for i in idx["current"]) + ": UDR "
                     + " ".join(_f(per_metric["udr"]["values_current"][k], 4, False) for k in range(len(idx["current"]))))
    lines.append(f"sd_run(UDR) {_f(sd_udr, 4, False)} pooled within the trios ({per_metric['udr']['df']} df); "
                 f"sd_null(UDR) {_f(per_metric['udr']['sd_null'], 4, False)} over {per_metric['udr']['pairs']} pairs")
    if zero_udr:
        lines += wrap("", "UDR spread zero: reported, not a stop (a top-k count can give it with different valid "
                          "fits); one-seed reads have no T_1 and send a gain above zero to seeds 43 and 44 (D2-floor)")
    lines += wrap("", "with few df sd_run is rough; T_1 carries that with its t value; the three-seed bound uses the "
                      "read's own paired differences; sd_null is information only; no fixed floor")
    if same_seed:
        lines += wrap("same seed, kept minus current (information; " + SAME_SEED_NOTE + "): ", "; ".join(
            f"{sd_} AP {_f(v['ap'])} UDR {_f(v['udr'])}" for sd_, v in same_seed.items()))
    lines += wrap("", account_count_line(counts))
    lines.append("FP/TP@0.6: false alerts per caught fraud (the bank's FPR; lower better)")
    if data.amount_reason:
        lines.append(f"VDR null: {data.amount_reason}")
    lines.append(f"note: {TFM_NOTE}")
    title = f"NEW FIELDS SPREAD  {spec.name} June {spec.start}-{spec.end}"
    text = C.screen(title, lines, f"saved: {C.rel(path)}")
    _write(path, record, text)
    _log_read("spread", spec, order, f"sd_run_udr={_f(sd_udr, 4, False)} df={per_metric['udr']['df']}")
    print(text)
    return C.OK


def load_spread(pop):
    path = C.out("reads", f"spread_{pop}.json")
    if not path.is_file():
        refuse(f"{C.rel(path)} is missing: run nf_read.py spread --population {pop} first")
    data = C.read_json(path)
    sd = (data.get("metrics") or {}).get("udr", {}).get("sd_run")
    if sd is None:
        refuse(f"{C.rel(path)} has no UDR seed spread")
    if sorted(data.get("seeds") or []) != sorted(planned_seeds()):
        refuse(f"{C.rel(path)} holds seeds {data.get('seeds')}, not the kept {sorted(planned_seeds())}")
    return data, float(sd), C.sha256_file(path)


def deciding_spreads(pop):
    """The spread files a read needs (the reviewers' decision D2): RANK-B's and SELECT June's when RANK-B decides,
    SELECT June's alone when SELECT decides. Returns ({name: record}, {name: sha256})."""
    names = ("rank_b", "select_june") if pop == "rank_b" else ("select_june",)
    out, shas = {}, {}
    for n in names:
        out[n], _, shas[n] = load_spread(n)
    return out, shas


# ------------------------------------------------------------------------------------------------------------ #
# read
# ------------------------------------------------------------------------------------------------------------ #
def refit_information(fits, data, scores, ctrls):
    """D5a: when the seed-42 control is a refit of the kept recipe, the kept fit's and the refit's RANK-B AP and UDR
    and their gap (a same-seed pair on this pod), and what the refit leaves by the previous decision. No decision
    rule reads it. None when the control is not a refit."""
    ctl42 = next((k for k in ctrls if k.seed == min(f.seed for f in ctrls)), None)
    kept = [i for i, f in enumerate(fits) if f.role == "kept_fit"]
    if ctl42 is None or ctl42.control_kind != "refit" or not kept:
        return None
    i_ctl = fits.index(ctl42)
    pk = ranked(data, scores[kept[0]]).evaluate(None)
    pr = ranked(data, scores[i_ctl]).evaluate(None)
    prev = ctl42.previous_decision
    leaves = {"one_seed": "the kept recipe's own luck on RANK-B from its one-seed adoption; it favours the control",
              "three_seed": "the kept recipe's own luck on RANK-B from its three-seed adoption; it can favour either "
                            "side",
              "base": "the base's own luck on RANK-B, kept by the previous decision; after a three-seed refusal the "
                      "base's seed 43 and 44 fits carry about +0.0007 AP of fit luck each"}.get(
        prev, "the kept recipe's own luck on RANK-B (previous decision not recorded)")
    return {"kept_fit": fits[kept[0]].run, "refit": ctl42.run, "kept_ap": pk["ap"], "kept_udr": pk["udr"],
            "refit_ap": pr["ap"], "refit_udr": pr["udr"], "gap_ap": pk["ap"] - pr["ap"],
            "gap_udr": pk["udr"] - pr["udr"], "previous_decision": prev, "leaves": leaves}


def cmd_read(args):
    cfg = C.settings()
    check_approvals(cfg)
    check_rules(cfg)
    pop, why_pop = decision_population(cfg)
    if args.population and args.population != pop:
        refuse(f"--population {args.population} is not the decision population {pop} ({why_pop})")
    spec = population_spec(cfg, pop)
    kind = step_kind(args.step, args.rule)
    fits = read_runs(args.run_table)
    meta = run_table_meta(args.run_table)
    cands, ctrls = pair_fits(fits)
    n = len(cands)
    if kind == "prune" and n != 1:
        refuse(f"pruning is read at seed 42 only, by its own rule; the run table holds {n} seeds per side")
    kept_ctl = [k for k in ctrls if is_kept(k)]
    if kept_ctl:
        refuse(f"control seed {', '.join(str(k.seed) for k in kept_ctl)} is a kept checkpoint: the kept seed 43 and "
               "44 checkpoints are never controls (the reviewers' decision D5b); the base is refit on this pod")
    info_fits = [f for f in fits if f.role == "kept_fit"][:1]
    spreads, spread_sha = deciding_spreads(pop)
    lock = check_lock(cfg)
    inputs = {"fits": [check_receipt(f, spec) for f in cands + ctrls + info_fits], "settings_sha256": settings_sha(),
              "decision_sha256": lock, "spread_sha256": spread_sha, "kind": kind, "population": pop,
              "raw_base": str(_raw_base(args, ctrls[0])), "files": [spec.start, spec.end]}
    envs = check_environments(cands, ctrls)
    guard = check_kept_controls(ctrls)
    path = _out_path(args, f"{args.step}_{n}seed.json")
    saved = saved_or_stale(path, inputs)
    if saved is not None:
        print(path.with_suffix(".txt").read_text(encoding="utf-8").rstrip())
        return C.OK

    raw, mask, layout = load_raw_rows(spec, _raw_base(args, ctrls[0]), args.cred)
    order = cands + ctrls + info_fits
    data, scores = align(order, raw, mask)
    if data.rows * 3 // 500 == 0:
        stop(f"{data.rows} rows give an empty 0.6% outsort; UDR cannot decide")
    rk = [ranked(data, sc) for sc in scores[:2 * n]]
    draws, seed, interval = _bootstrap(cfg)
    comp = R.paired(rk[:n], rk[n:], data.n_units, draws, seed, interval, keep_draws=10)
    engine = engine_check(data, scores[:2 * n], rk, comp["first_draws"])
    met = comp["metrics"]

    bar = float(cfg.get("bar_udr", 0.01))
    deciding = spreads[pop]
    # sd_null: the deciding spread file's pair term, recorded and printed as information only (D2, 3 November)
    nulls = {m: pair_term(deciding, m) for m in SPREAD_METRICS}
    sd_run, df_run, run_src = seed_spread(spreads, "udr")
    sd_pair_udr = met["udr"]["sd"] if met["udr"]["sd"] is not None else float("nan")
    terms = t1_terms(sd_pair_udr, sd_run, df_run)
    t1_udr = terms["t1"]
    s_ap, df_ap, _ = seed_spread(spreads, "ap")
    t1_ap = (t1_terms(met["ap"]["sd"], s_ap, df_ap)["t1"]
             if met["ap"]["sd"] is not None and s_ap else None)
    g, lb, hi = met["udr"]["gain"], met["udr"]["lo"], met["udr"]["hi"]
    lb3 = s_d = t3 = df3 = None
    if n > 1:
        lb3, s_d, t3, df3 = lb_three(g, met["udr"]["differences"], met["udr"]["var"] or 0.0)
    decision, reason, changes = decide(kind, n, g, t1_udr, bar, lb, lb3, hi, t1_undefined=terms["undefined"])

    sel = None
    pending = False
    final = decision
    sc_cfg = cfg.get("select_check") or {}
    if changes:
        if pop == "select_june":
            k_se = float(sc_cfg.get("k_se_when_select_decides", 3.5))
            sel = select_check(met, k_se, {"select_june": spreads["select_june"]}, n)
            final, sel_reason = finalize(decision, sel)
            reason = f"{reason}; {sel_reason} (same read, not independent)"
        else:
            pending = True
    conflict = None
    if changes:
        cl = cfg.get("conflict_line") or {}
        conflict = conflict_check(met, float(cl.get("k_se", 2.5)), spreads, n, data.amount_reason,
                                  tuple(cl.get("metrics") or ("ap", "vdr")))
    counts = {f"{f.role} {f.seed}": ranked(data, scores[i]).fraud_accounts_caught() for i, f in
              enumerate(cands + ctrls)}
    refit = refit_information(order, data, scores, ctrls)

    record = {"kind": "read", "step": args.step, "rule": kind, "seeds": [f.seed for f in cands],
              "population": pop, "population_reason": why_pop, "files": [spec.start, spec.end],
              "targets": [spec.t0, spec.t1], "rows": data.rows, "frauds": int(data.y.sum()), "accounts": data.n_units,
              "outsorted": int(data.rows * 3 // 500), "layout": layout, "engine": engine, "udr_unit": "transaction",
              "bootstrap": {"draws": draws, "seed": seed, "interval": interval, "unit": ACCT},
              "metrics": met, "sd_run_udr_used": sd_run, "sd_run_udr_df": df_run, "sd_run_udr_source": run_src,
              "sd_null": nulls, "sd_null_use": "information only (D2)", "t1_terms": terms, "t1_udr": t1_udr,
              "t1_undefined": terms["undefined"], "t1_ap": t1_ap,
              "bar_udr": bar, "gain_udr": g, "lb_bootstrap": lb, "lb_three_seed_plan": lb3,
              "three_seed_bound": "paired",
              "three_seed_spread_of_differences": s_d, "three_seed_t": t3, "three_seed_df": df3,
              "decision": f"{decision} (pending the SELECT check)" if pending else final, "rule_decision": decision,
              "final_decision": None if pending else final, "pending_select_check": pending,
              "environment": envs, "kept_controls_guard": guard, "conflict": conflict,
              "account_counts": {k: list(v) for k, v in counts.items()}, "refit_control": refit,
              "membership": meta.get("membership"), "a1_adopted": meta.get("a1_adopted"),
              "control_kind": ctrls[0].control_kind or None,
              "external_score_line": external_score_line(cfg),
              "changes_kept_inputs": changes, "reason": reason, "select_check_same_read": sel,
              "num_workers": {f"{f.role}_{f.seed}": num_workers(f) for f in cands + ctrls},
              "amount_source": data.amount_source, "vdr_null_reason": data.amount_reason,
              "inputs": inputs, "utc": C.utc_now()}
    text = read_screen(record, spec, cands, ctrls, cfg, path)
    _write(path, record, text)
    shown = record["decision"]
    _log_read(args.step, spec, cands + ctrls, shown)
    _log_decision(args.step, shown, reason)
    if conflict and conflict["line"]:
        _log_decision(args.step, "conflict", conflict["line"])
    if refit:
        _log_decision(args.step, "refit control", (
            f"kept fit {refit['kept_fit']} AP {_f(refit['kept_ap'], 4, False)} UDR {_f(refit['kept_udr'], 4, False)}; "
            f"refit {refit['refit']} AP {_f(refit['refit_ap'], 4, False)} UDR {_f(refit['refit_udr'], 4, False)}; "
            f"gap AP {_f(refit['gap_ap'])} UDR {_f(refit['gap_udr'])}"))
    print(text)
    return C.OK


def wrap(prefix, text, width=C.SCREEN_WIDTH):
    """One screen item over as many lines as it needs, so nothing is cut."""
    return textwrap.wrap(f"{prefix}{text}", width=width, subsequent_indent="  ") or [prefix]


def read_screen(rec, spec, cands, ctrls, cfg, path):
    n = len(cands)
    met = rec["metrics"]
    seeds = "/".join(str(s) for s in rec["seeds"])
    what = f" ({rec['membership'].split(';')[0]})" if rec.get("membership") and rec["step"] == "A2" else ""
    title = f"NEW FIELDS READ  step={rec['step']}{what}  seeds={seeds}  {spec.name} June {spec.start}-{spec.end}"
    cand_label = f" ({cands[0].label})" if cands[0].label else ""
    ctrl_label = f" ({ctrls[0].label})" if ctrls[0].label else ""
    lines = [f"rules={rec['inputs']['decision_sha256'][:12]}  layout={rec['layout']}  rule={rec['rule']}  "
             f"unit=transaction",
             f"rows {rec['rows']:,}  frauds {rec['frauds']:,}  accounts {rec['accounts']:,}  outsort "
             f"{rec['outsorted']:,} (0.6% = floor(N x 3/500))",
             f"draws {rec['bootstrap']['draws']} seed {rec['bootstrap']['seed']}, whole accounts, the same draws "
             "for every fit", f"engine = _alert at 6 per mille: {rec['engine']}"]
    kind_word = {"refit": "a seed-42 refit of the kept recipe", "base": "the base control",
                 "kept": "the kept fit as it is"}.get(ctrls[0].control_kind, "")
    lines += wrap("", f"candidate {cands[0].run}{cand_label}  control {ctrls[0].run}{ctrl_label}"
                      + (f" ({kind_word})" if kind_word else ""))
    if rec.get("membership"):
        lines += wrap("membership: ", rec["membership"])
    lines += environment_lines(rec)
    lines += _metric_rows(met)
    if n > 1:
        for m in ("udr", "ap"):
            lines += wrap(f"per seed {m.upper()} diff: ", "  ".join(f"{s} {_f(d)}" for s, d in
                                                                   zip(rec["seeds"], met[m]["differences"])))
    t = rec["t1_terms"]
    shown_t1 = "undefined" if t.get("undefined") else _f(rec["t1_udr"], 4, False)
    lines += wrap("", f"T1(UDR) = t {_f(t['t'], 3, False)} (nu {_f(t['nu'], 2, False)}) x sqrt("
                      f"{_f(t['sd_pair'], 4, False)}^2 + 2 x {_f(t['sd_run'], 4, False)}^2) = {shown_t1}   "
                      f"bar {rec['bar_udr']:+.4f}" + ("" if n == 1 else "  (T1 decides at one seed only)"))
    lines += wrap("", f"  sd_pair: this read's bootstrap; sd_run: {rec['sd_run_udr_source']} "
                      f"({rec['sd_run_udr_df']} df), the larger spread; 2 x sd_run^2 assumes equal candidate and "
                      f"control seed variance (one fit per arm gives no other estimate); no null subtraction "
                      f"(sd_null(UDR) {_f(rec['sd_null'].get('udr'), 4, False)}, information); no fixed floor; "
                      f"T1(AP) {_f(rec['t1_ap'], 4, False)} (information)")
    if t.get("undefined"):
        lines += wrap("T1 undefined: ", t["undefined"])
    if n > 1:
        s_d = _f(rec["three_seed_spread_of_differences"], 4, False)
        lines += wrap("", f"LB_3 (paired: gain - t x sqrt(v_acct + s_d^2/{n}), s_d {s_d}, t "
                          f"{_f(rec['three_seed_t'], 3, False)} at {rec['three_seed_df']} df, it governs at 3 seeds) "
                          f"{_f(rec['lb_three_seed_plan'])}; bootstrap LB {_f(rec['lb_bootstrap'])}")
    else:
        lines.append(f"LB at one seed: the account bootstrap's alone {_f(rec['lb_bootstrap'])} (T1 carries the "
                     "seed term)")
    shown = rec["decision"]
    if rec["final_decision"] and rec["final_decision"] != rec["rule_decision"]:
        shown = f"{rec['final_decision']} (was {rec['rule_decision']})"
    lines.append(f"DECISION: {shown}")
    lines += wrap("reason: ", rec["reason"])
    if rec.get("conflict") and rec["conflict"].get("line"):
        lines += wrap("", rec["conflict"]["line"])
    if rec["select_check_same_read"]:
        sc = rec["select_check_same_read"]
        lines += wrap("SELECT check (same read, not independent): ", "  ".join(
            f"{r['metric']} {_f(r['difference'])} {'ok' if r['pass'] else 'FAIL'}" for r in sc["rows"]))
    rf = rec.get("refit_control")
    if rf:
        lines += wrap("refit control (information): ", (
            f"kept fit {rf['kept_fit']} AP {_f(rf['kept_ap'], 4, False)} UDR {_f(rf['kept_udr'], 4, False)}; refit "
            f"{rf['refit']} AP {_f(rf['refit_ap'], 4, False)} UDR {_f(rf['refit_udr'], 4, False)}; gap AP "
            f"{_f(rf['gap_ap'])} UDR {_f(rf['gap_udr'])} (a same-seed pair on this pod)"))
        lines += wrap("  the refit leaves ", rf["leaves"])
    if rec["rule"] == "prune":
        lines += wrap("", "pruning: unpruned minus pruned " + _f(-rec["gain_udr"]) + " UDR, interval "
                          f"[{_f(_neg(met['udr']['hi']))}, {_f(_neg(met['udr']['lo']))}]; control: {kind_word or 'the kept fit'}"
                          + ("; no loss detected at one seed; this read cannot show no loss"
                             if rec["rule_decision"].startswith("KEEP THE SMALLER") else ""))
    if rec["rule"] == "month_out":
        lines += wrap("", "month rule: an operational simplification, not proof that removing month loses "
                          "nothing; an inconclusive result keeps month")
        lines += wrap("", f"control: {kind_word or 'the kept fit'}; the kept recipe's RANK-B luck, from when it "
                          "was kept with month in, favours month in")
        lines += wrap("", "June is a month the month-in fit never saw in training, so h says nothing about "
                          "October to May of a later year")
    lines += wrap("", account_count_line(rec["account_counts"]))
    if n == 1:
        lines.append("note: one seed; the bootstrap covers rows, not seed-to-seed variation")
    workers = sorted({w for w in rec["num_workers"].values() if w is not None})
    lines.append(f"note: a shared seed shares the file partition only when num_workers > 0 (as run: "
                 f"{','.join(map(str, workers)) if workers else 'unknown'})")
    lines.append("note: seed 42 was picked on Test 1, which never decides; the bias favours the control")
    if rec["step"] not in ("A1", "ALL") and ctrls[0].control_kind not in ("refit", "base"):
        lines.append("note: the control won its own step on this population; its luck favours it")
    if rec["population"] == "select_june":
        lines.append(f"note: SELECT decides ({rec['population_reason']}); no independent check remains")
    lines.append("note: RANK-B and SELECT are development data; adopted gains are somewhat optimistic")
    if rec.get("external_score_line"):
        lines.append(rec["external_score_line"])
    lr = cfg.get("learning_rate")
    if lr not in (None, "") and float(lr) != LEARNING_RATE_OF_KEPT:
        lines.append(f"note: lr {lr}; the kept seeds' spread was measured at {LEARNING_RATE_OF_KEPT:g}")
    if rec["vdr_null_reason"]:
        lines += wrap("VDR null: ", rec["vdr_null_reason"])
    lines += wrap("next: ", next_step(rec))
    return C.screen(title, lines, f"saved: {C.rel(path)}")


def _neg(x):
    return None if x is None else -x


def next_step(rec):
    d = rec["final_decision"] or rec["rule_decision"]
    if d == "RUN SEEDS 43 AND 44":
        return ("S.5 fit candidate seeds 43 and 44; controls: the base refits nf_control at seeds 43 and 44, or new "
                "fits of the refit control's recipe (D5a, D5b); then read at 3 seeds")
    if rec["pending_select_check"]:
        return "S.6 score candidate and control on SELECT; nf_read.py select-check"
    if d in CHANGES:
        return "the kept inputs change; the next step builds on them"
    return "the kept inputs stay; the next step builds on them"


# ------------------------------------------------------------------------------------------------------------ #
# select-check
# ------------------------------------------------------------------------------------------------------------ #
def saved_step_read(step):
    for n in (3, 1):
        p = C.out("reads", f"{step}_{n}seed.json")
        if p.is_file():
            return p, C.read_json(p)
    return None, None


def cmd_select_check(args):
    cfg = C.settings()
    check_approvals(cfg)
    check_rules(cfg)
    spec = population_spec(cfg, "select_june")
    read_path, step_read = saved_step_read(args.step)
    if step_read is None:
        refuse(f"no saved read for step {args.step}; run nf_read.py read first")
    if not step_read.get("pending_select_check"):
        refuse(f"the read of step {args.step} ({step_read.get('decision')}) is not pending a SELECT check")
    envs = None
    if args.population and args.population != "select_june":
        refuse(f"the SELECT check reads select_june, not {args.population}")
    fits = read_runs(args.run_table)
    cands, ctrls = pair_fits(fits)
    if [f.seed for f in cands] != step_read.get("seeds"):
        refuse(f"the SELECT check uses the read's seeds {step_read.get('seeds')}, not {[f.seed for f in cands]}")
    if any(is_kept(k) for k in ctrls):
        refuse("a kept checkpoint is offered as a control: the kept seed 43 and 44 checkpoints are never controls "
               "(the reviewers' decision D5b)")
    # RANK-B decided (a SELECT check is pending only then): the larger of the SELECT June and RANK-B spreads (D2)
    spreads, spread_sha = deciding_spreads("rank_b")
    lock = check_lock(cfg)
    inputs = {"fits": [check_receipt(f, spec) for f in cands + ctrls], "settings_sha256": settings_sha(),
              "decision_sha256": lock, "read_sha256": C.sha256_file(read_path),
              "spread_sha256": spread_sha}
    # SELECT scores different rows, but it must check the checkpoint pair that earned the pending decision.
    pending_fits = (step_read.get("inputs") or {}).get("fits") or []
    for fit in inputs["fits"]:
        prior = [f for f in pending_fits if (f.get("role"), f.get("seed")) == (fit["role"], fit["seed"])]
        name = f"{fit['role']} seed {fit['seed']}"
        if len(prior) != 1 or not prior[0].get("checkpoint_sha256"):
            stop(f"the pending read does not record one checkpoint for {name}; repeat the decision read")
        if fit["checkpoint_sha256"] != prior[0]["checkpoint_sha256"]:
            stop(f"SELECT {name}: checkpoint differs from the pending read; score the original checkpoint")
    path = _out_path(args, f"{args.step}_select.json")
    saved = saved_or_stale(path, inputs)
    if saved is not None:
        print(path.with_suffix(".txt").read_text(encoding="utf-8").rstrip())
        return C.OK
    raw, mask, layout = load_raw_rows(spec, _raw_base(args, ctrls[0]), args.cred)
    data, scores = align(cands + ctrls, raw, mask)
    rk = [ranked(data, s) for s in scores]
    draws, seed, interval = _bootstrap(cfg)
    n = len(cands)
    comp = R.paired(rk[:n], rk[n:], data.n_units, draws, seed, interval, keep_draws=10)
    engine = engine_check(data, scores, rk, comp["first_draws"])
    k_se = float((cfg.get("select_check") or {}).get("k_se", 2.5))
    sel = select_check(comp["metrics"], k_se, spreads, n)
    rule_decision = step_read.get("rule_decision") or step_read["decision"]
    final, why = finalize(rule_decision, sel)
    record = {"kind": "select_check", "step": args.step, "seeds": [f.seed for f in cands], "population": "select_june",
              "files": [spec.start, spec.end], "rows": data.rows, "frauds": int(data.y.sum()),
              "accounts": data.n_units, "engine": engine, "layout": layout, "check": sel,
              "metrics": comp["metrics"], "read_decision": rule_decision, "final_decision": final,
              "decision": f"{'PASS' if sel['pass'] else 'FAIL'}: {final}",
              "reason": why, "inputs": inputs, "utc": C.utc_now()}
    lines = [f"rows {data.rows:,}  frauds {int(data.y.sum()):,}  accounts {data.n_units:,}  draws {draws} seed {seed}",
             f"engine = _alert at 6 per mille: {engine}",
             f"read decision on {step_read.get('population')}: {rule_decision} (pending the SELECT check)",
             f"{'metric':<10}{'diff':>10}{'boot_sd':>10}{'s_m':>9}{'limit':>10}  result"]
    for r in sel["rows"]:
        lines.append(f"{r['metric']:<10}{_f(r['difference']):>10}{_f(r['sd'], 4, False):>10}"
                     f"{_f(r['s_m'], 4, False):>9}{_f(r['limit']):>10}  "
                     f"{'pass' if r['pass'] else 'FAIL'}")
    lines += wrap("", f"limit = -{k_se} x sqrt(boot_sd^2 + 2 x s_m^2/{n}); s_m the larger of the SELECT June and "
                      f"RANK-B seed spreads; no null subtraction (D2); {RULE_K_NOTE}")
    lines += [f"SELECT check: {'PASS' if sel['pass'] else 'FAIL'}", f"DECISION: {final}"]
    lines += wrap("reason: ", why)
    lines.append("note: SELECT June is read once per decision that would change the kept inputs")
    if n == 1:
        lines.append("note: one seed; the bootstrap covers rows, not seed-to-seed variation")
    title = (f"NEW FIELDS SELECT CHECK  step={args.step}  seeds={'/'.join(str(f.seed) for f in cands)}  "
             f"SELECT June {spec.start}-{spec.end}")
    lines.insert(0, f"rules={lock[:12]}  layout={layout}")
    text = C.screen(title, lines, f"saved: {C.rel(path)}")
    _write(path, record, text)
    _log_read(f"{args.step}_select", spec, cands + ctrls, final)
    _log_decision(args.step, final, why)
    print(text)
    return C.OK


# ------------------------------------------------------------------------------------------------------------ #
# lift
# ------------------------------------------------------------------------------------------------------------ #
def _downstream_frame(path, arms, key, account, label):
    import pyarrow.parquet as pq
    p = _path(path)
    if not p.is_file():
        refuse(f"downstream predictions missing: {C.rel(p)}")
    have = set(pq.ParquetFile(p).schema_arrow.names)
    missing = [c for c in [key, account, label, *arms] if c not in have]
    if missing:
        stop(f"{C.rel(p)} lacks {missing}")
    t = pq.read_table(p, columns=[key, account, label, *arms]).to_pandas()
    frame = pd.DataFrame({"_acct": t[account].map(str).to_numpy(), "_id": t[key].map(str).to_numpy(),
                          "_label": pd.to_numeric(t[label], errors="coerce").to_numpy(float)})
    for a in arms:
        frame[a] = pd.to_numeric(t[a], errors="coerce").to_numpy(float)
    if frame.duplicated(["_acct", "_id"]).any():
        stop(f"{C.rel(p)}: duplicate (account, id) rows")
    return frame.sort_values(["_acct", "_id"], kind="stable").reset_index(drop=True), C.sha256_file(p)


def fraud_rule_status(step, given):
    if given in ("pass", "fail"):
        return given, "given on the command line"
    p = C.out("reads", f"{step}_select.json")
    if p.is_file():
        d = C.read_json(p)
        return ("pass" if d.get("final_decision") in CHANGES else "fail"), f"{C.rel(p)}: {d.get('final_decision')}"
    rp, r = saved_step_read(step)
    if r is None:
        return "unknown", "no saved read for this step"
    if r.get("pending_select_check"):
        return "pending", f"{C.rel(rp)}: {r.get('decision')} pending the SELECT check"
    final = r.get("final_decision") or r.get("decision")
    return ("pass" if final in CHANGES else "fail"), f"{C.rel(rp)}: {final}"


def downstream_predictions(fit):
    """The downstream predictions.parquet of one fit: the run table's ``downstream`` path, else the one file under
    checkpoints/new_fields/downstream/<run tag>/ (the downstream check's output folder)."""
    if fit.downstream:
        return _path(fit.downstream)
    folder = C.out("downstream", fit.run, "x").parent
    found = sorted(folder.rglob("predictions.parquet")) if folder.is_dir() else []
    if len(found) > 1:
        # nf_downstream.py run writes base_raw/fit/ (the arm the flag reads) and, for a step, own_raw/fit/
        found = ([f for f in found if "/base_raw/fit/" in f.as_posix()]
                 or [f for f in found if "select" in f.as_posix().lower()] or found)
    if len(found) != 1:
        refuse(f"{fit.run}: expected one downstream predictions.parquet under {C.rel(folder)}, found {len(found)}")
    return found[0]


def lift_flag(status, falls):
    """DESIGN.md 8.7 and the plan: on when the step passed the fraud rule and the UDR lift (the main measure) fell
    by more than one paired SE. The AP lift is reported beside it and does not set the flag."""
    return status == "pass" and bool(falls.get("udr"))


def cmd_lift(args):
    cfg = C.settings()
    lock = check_lock(cfg)
    if args.population and args.population != "ds_select":
        refuse(f"the lift reads ds_select, not {args.population}")
    want_sha = {}
    if args.run_table:
        fits = read_runs(args.run_table, need_predictions=False)
        cands = [f for f in fits if f.role == "candidate"]
        ctrls = [f for f in fits if f.role == "control"]
        if len(cands) != 1 or len(ctrls) != 1:
            refuse("the lift needs one candidate (the step's kept fit) and one control in the run table")
        args.fit, args.control = str(downstream_predictions(cands[0])), str(downstream_predictions(ctrls[0]))
        # the DS_SELECT predictions' sha256 the downstream job recorded (review item 18): the read covers them
        want_sha = {"fit": cands[0].downstream_sha256, "control": ctrls[0].downstream_sha256}
        for name, f in (("fit", cands[0]), ("control", ctrls[0])):
            if f.downstream_sha256_required and not want_sha[name]:
                refuse(f"the downstream job recorded no sha256 for the {name} ({f.run}): its summary.json has no "
                       "predictions_sha256, so the read could not show its inputs; run the downstream job again")
    if not (args.fit and args.control):
        refuse("give --run-table, or --fit and --control")
    raw_arm, emb_arm = args.arms.split(",")
    fit, fit_sha = _downstream_frame(args.fit, [raw_arm, emb_arm], args.key, args.account, args.label)
    ctl, ctl_sha = _downstream_frame(args.control, [raw_arm, emb_arm], args.key, args.account, args.label)
    own = own_sha = None
    if args.fit_own_raw:
        own, own_sha = _downstream_frame(args.fit_own_raw, [args.own_raw_arm], args.key, args.account, args.label)
    for name, got in (("fit", fit_sha), ("control", ctl_sha)):
        if want_sha.get(name) and want_sha[name] != got:
            stop(f"the {name}'s downstream predictions changed since the downstream job recorded them "
                 f"(sha256 {got[:12]} != {want_sha[name][:12]})")
    for name, other in (("control", ctl), ("own raw", own)):
        if other is None:
            continue
        if not (fit[["_acct", "_id"]].equals(other[["_acct", "_id"]])):
            stop(f"the {name} downstream predictions do not hold the same DS_SELECT rows as the fit's")
        if not np.array_equal(fit["_label"].to_numpy(), other["_label"].to_numpy()):
            stop(f"the {name} downstream labels differ from the fit's")
    if not np.isin(fit["_label"].to_numpy(), [0, 1]).all():
        stop("downstream labels must be 0 or 1")
    status, status_source = fraud_rule_status(args.step, args.fraud_rule)
    inputs = {"fit_sha256": fit_sha, "control_sha256": ctl_sha, "own_raw_sha256": own_sha,
              "decision_sha256": lock, "arms": [raw_arm, emb_arm], "fraud_rule": status}
    path = _out_path(args, f"{args.step}_lift.json")
    saved = saved_or_stale(path, inputs)
    if saved is not None:
        print(path.with_suffix(".txt").read_text(encoding="utf-8").rstrip())
        return C.OK
    y = fit["_label"].to_numpy(np.int64)
    keys = R.identity_keys(fit["_acct"], fit["_id"])
    key_rank = R.key_ranks(keys)
    codes, units = R.account_units(fit["_acct"])

    def rs(scores):
        if not np.isfinite(scores).all():
            stop("downstream scores must be finite")
        return R.RankedScore(scores, y, codes, key_rank)

    draws, seed, interval = _bootstrap(cfg)
    arms = [rs(fit[raw_arm].to_numpy()), rs(fit[emb_arm].to_numpy()), rs(ctl[raw_arm].to_numpy()),
            rs(ctl[emb_arm].to_numpy())]
    lift = R.lift_paired(*arms, len(units), draws, seed, interval)
    own_lift = None
    if own is not None:
        own_lift = R.lift_paired(rs(own[args.own_raw_arm].to_numpy()), arms[1], arms[2], arms[3], len(units),
                                 draws, seed, interval)
    falls = {m: (lift[m]["sd"] is not None and lift[m]["difference"] < -lift[m]["sd"]) for m in ("udr", "ap")}
    flag = lift_flag(status, falls)
    record = {"kind": "lift", "step": args.step, "rows": int(len(y)), "frauds": int(y.sum()),
              "accounts": int(len(units)), "lift": lift, "lift_against_own_raw": own_lift, "falls_by_more_than_se": falls,
              "fraud_rule": status, "fraud_rule_source": status_source, "flag": bool(flag),
              "bootstrap": {"draws": draws, "seed": seed, "interval": interval}, "inputs": inputs, "utc": C.utc_now()}
    lines = [f"DS_SELECT rows {len(y):,}  frauds {int(y.sum()):,}  accounts {len(units):,}  draws {draws} seed {seed}",
             f"lift = metric({emb_arm}) minus metric({raw_arm}); paired SE = SD of the lift difference",
             f"{'metric':<8}{'lift fit':>10}{'lift ctl':>10}{'diff':>10}{'paired SE':>11}{'lo':>10}{'hi':>10}  fall>1SE"]
    for m, label in (("udr", "UDR@0.6"), ("ap", "AP")):
        r = lift[m]
        lines.append(f"{label:<8}{_f(r['lift_fit']):>10}{_f(r['lift_control']):>10}{_f(r['difference']):>10}"
                     f"{_f(r['sd'], 4, False):>11}{_f(r['lo']):>10}{_f(r['hi']):>10}  "
                     f"{'yes' if falls[m] else 'no'}")
    if own_lift is not None:
        lines += wrap("", "against the fit's own raw arm (review item 24, information): UDR lift "
                          f"{_f(own_lift['udr']['lift_fit'])}, AP lift {_f(own_lift['ap']['lift_fit'])}")
    lines.append(f"fraud rule: {status} ({status_source})")
    if flag:
        lines.append("FLAG: the embedding's downstream lift fell by more than one paired SE")
        lines.append(f"  lifts: fit UDR {_f(lift['udr']['lift_fit'])} vs control {_f(lift['udr']['lift_control'])}; "
                     f"fit AP {_f(lift['ap']['lift_fit'])} vs control {_f(lift['ap']['lift_control'])}")
    else:
        lines.append("flag: no" + ("" if status == "pass" else " (the flag needs a step that passed the fraud rule)"))
    lines += wrap("", "note: the flag is for the owner; it changes no decision. DS_SELECT is read once per kept fit")
    title = f"NEW FIELDS LIFT  step={args.step}  population=DS_SELECT  rules={lock[:12]}"
    text = C.screen(title, lines, f"saved: {C.rel(path)}")
    _write(path, record, text)
    C.append_line(C.out("READS.log"), f"{C.utc_now()} {args.step}_lift DS_SELECT fit={C.rel(_path(args.fit))} "
                                       f"control={C.rel(_path(args.control))} "
                                       f"settings={(settings_sha() or 'none')[:12]} flag={'yes' if flag else 'no'}")
    print(text)
    return C.OK


# ------------------------------------------------------------------------------------------------------------ #
# report
# ------------------------------------------------------------------------------------------------------------ #
def cmd_population_report(args):
    """Every fit's measures on a population, reported only. Test 1 is read here and never decides."""
    cfg = C.settings()
    spec_cfg = (cfg.get("populations") or {}).get(args.population)
    if not spec_cfg or "files" not in spec_cfg:
        refuse(f"SETTINGS.yaml populations.{args.population} needs files")
    start, end = (int(x) for x in spec_cfg["files"])
    t0, t1_ = (str(x) for x in spec_cfg.get("targets") or ["2025-06-01", "2025-07-01"])
    name = {"test1": "Test 1"}.get(args.population, args.population)
    spec = SimpleNamespace(pop=args.population, name=name, start=start, end=end, t0=t0, t1=t1_,
                           scorer_population={"test1": "DEV_OOT"}.get(args.population, None))
    fits = sorted(read_runs(args.run_table), key=lambda f: (f.run, f.seed))
    if not fits:
        refuse("the run table holds no fits")
    inputs = [check_receipt(f, spec) for f in fits]
    path = _out_path(args, f"{args.population}_report.txt")
    raw, mask, layout = load_raw_rows(spec, _raw_base(args, fits[0]), args.cred)
    data, scores = align(fits, raw, mask)
    rows = []
    for f, sc in zip(fits, scores):
        r = ranked(data, sc).evaluate(None)
        rows.append({"run": f.run, "seed": f.seed, **{m: r[m] for m in ("ap", "udr", "vdr", "fpr", "auroc")}})
    lines = [f"rows {data.rows:,}  frauds {int(data.y.sum()):,}  targets {t0} to {t1_} (end excluded)  "
             f"layout={layout}",
             f"{'run':<28}{'seed':>5}{'AP':>9}{'UDR@0.6':>9}{'VDR@0.6':>9}{'FP/TP@0.6':>10}{'AUROC':>9}"]
    for r in rows:
        lines.append(f"{r['run'][:28]:<28}{r['seed']:>5}{_f(r['ap'], 4, False):>9}{_f(r['udr'], 4, False):>9}"
                     f"{_f(r['vdr'], 4, False):>9}{_f(r['fpr'], 2, False):>10}{_f(r['auroc'], 4, False):>9}")
    lines.append(f"{name} is reported only. It never decides: seed 42 was picked as best on it.")
    lines.append("FP/TP@0.6: false alerts per caught fraud (the bank's FPR; lower better)")
    text = C.screen(f"NEW FIELDS REPORT  {name} {start}-{end}  (report only)", lines, f"saved: {C.rel(path)}")
    path.write_text(text + "\n", encoding="utf-8")
    C.write_json(path.with_suffix(".json"), _clean({"kind": "report", "population": args.population,
                                                    "files": [start, end], "targets": [t0, t1_], "rows": data.rows,
                                                    "frauds": int(data.y.sum()), "fits": rows, "inputs": inputs,
                                                    "decides": False, "utc": C.utc_now()}))
    C.append_line(C.out("READS.log"), f"{C.utc_now()} report {name} files={start}-{end} fits={len(fits)} "
                                       f"settings={(settings_sha() or 'none')[:12]} decision=none (report only)")
    print(text)
    return C.OK


def cmd_report(args):
    if args.population:
        if not args.run_table:
            refuse("a population report needs --run-table")
        return cmd_population_report(args)
    reads = C.out("reads", "x").parent
    if args.step:
        texts = [p for p in sorted(reads.glob(f"{args.step}_*.txt"))]
        if not texts:
            refuse(f"no saved reads for step {args.step}")
        for p in texts:
            print(p.read_text(encoding="utf-8").rstrip())
            print()
        return C.OK
    lines = []
    for p in sorted(reads.glob("spread_*.json")):
        d = C.read_json(p)
        lines.append(f"spread {d['population']}: sd_run(UDR) {_f(d['metrics']['udr']['sd_run'], 4, False)} "
                     f"seeds {'/'.join(map(str, d.get('seeds', [])))}  rows {d.get('rows', 0):,}")
    for p in sorted(reads.glob("*seed.json")):
        d = C.read_json(p)
        shown = d.get("final_decision") or f"{d['decision']} (pending the SELECT check)"
        lines.append(f"{d['step']} {len(d['seeds'])} seed  {d['population']}: {shown}  gain {_f(d['gain_udr'])} "
                     f"T1 {_f(d['t1_udr'], 4, False)}")
    for p in sorted(reads.glob("*_select.json")):
        d = C.read_json(p)
        lines.append(f"{d['step']} SELECT check {'PASS' if d['check']['pass'] else 'FAIL'}: {d['final_decision']}")
    for p in sorted(reads.glob("*_lift.json")):
        d = C.read_json(p)
        lines.append(f"{d['step']} lift UDR {_f(d['lift']['udr']['lift_fit'])} (control "
                     f"{_f(d['lift']['udr']['lift_control'])}); flag: {'YES' if d['flag'] else 'no'}")
    if not lines:
        lines = ["no reads saved yet"]
    text = C.screen(f"NEW FIELDS READS  {C.utc_now()}  reads={C.rel(reads)}", lines,
                    "each read: nf_read.py report --step <step>")
    print(text)
    return C.OK


# ------------------------------------------------------------------------------------------------------------ #
def parser():
    p = argparse.ArgumentParser(description="The reader: paired comparison, decisions and the lift flag.")
    sub = p.add_subparsers(dest="command", required=True)

    def common(sp, required=True):
        sp.add_argument("--run-table", "--runs", dest="run_table", required=required,
                        help="the planner's run table (JSON with a runs list, or CSV); see the module text")
        sp.add_argument("--out", default=None, help="the JSON to write (default: checkpoints/new_fields/reads/...)")
        sp.add_argument("--raw-base", default=None, help="raw files base (default: the control's receipt files.base)")
        sp.add_argument("--cred", default=None, help="S3 credentials YAML for an s3:// raw base")

    s = sub.add_parser("spread", help="seed spread of the kept seeds on a decision population")
    s.add_argument("--population", required=True)
    s.add_argument("--step", default="spread")
    common(s)
    r = sub.add_parser("read", help="one step's decision")
    r.add_argument("--step", required=True)
    r.add_argument("--rule", "--kind", dest="rule", default=None, choices=("add", "month", "month_out", "prune", "calendar"))
    r.add_argument("--population", default=None)
    common(r)
    c = sub.add_parser("select-check", help="the SELECT June check of a pending decision")
    c.add_argument("--step", required=True)
    c.add_argument("--population", default=None)
    common(c)
    lf = sub.add_parser("lift", help="the downstream lift and its flag")
    lf.add_argument("--step", required=True)
    lf.add_argument("--population", default=None)
    common(lf, required=False)
    lf.add_argument("--fit", default=None, help="the step's kept fit's downstream predictions.parquet")
    lf.add_argument("--control", default=None, help="its control's downstream predictions.parquet")
    lf.add_argument("--fit-own-raw", default=None, help="predictions with a raw arm on the step's own raw inputs")
    lf.add_argument("--own-raw-arm", default="raw")
    lf.add_argument("--arms", default="raw,raw_embedding", help="raw arm, raw plus embedding arm")
    lf.add_argument("--fraud-rule", default="auto", choices=("auto", "pass", "fail"))
    lf.add_argument("--key", default=ID)
    lf.add_argument("--account", default=ACCT)
    lf.add_argument("--label", default=LABEL)
    rp = sub.add_parser("report", help="one screen of the saved reads, or a report-only population (Test 1)")
    rp.add_argument("--step", default=None)
    rp.add_argument("--population", default=None, help="report only, for example test1; it never decides")
    common(rp, required=False)
    return p


def main(argv=None):
    args = parser().parse_args(argv)
    handler = {"spread": cmd_spread, "read": cmd_read, "select-check": cmd_select_check, "lift": cmd_lift,
               "report": cmd_report}[args.command]
    try:
        return handler(args)
    except ReadError as e:
        print(str(e))      # one line: the reader's tests and the planner's log match its phrases
        return e.code
    except ValueError as e:  # a data check inside a project function: a STOP, not a crash
        print(f"STOP: {e}")
        return C.STOP
    except SystemExit as e:  # the resolver's refusals (exit 4) keep their code and text
        if e.code not in (None, 0) and not isinstance(e.code, int):
            print(e.code)
            return C.REFUSED
        raise


if __name__ == "__main__":
    sys.exit(main())
