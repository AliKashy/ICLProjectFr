# Stage 1 checks add-on (reviewers' suggestions)

This add-on lets stage 2 start from the owner's seed-42 rerun of the chosen model. It runs stage 1's checks without
any retrain, and it fixes the features package's guard so the timing-wrapper check is not applicable to a plain
rerun.

Apply it after the features package (`features_testing_package_REVIEWERS_SUGGESTIONS.zip`) and the two-workbench
add-on (`features_addon_two_workbenches_REVIEWERS_SUGGESTIONS.zip`). Its `nf_plan.py` includes the two-workbench
changes and needs that add-on's `nf_queue.py`. With one workbench, everything still runs as before.

## What it holds

18 files, at the same paths as in the project:

- **Changed in the features package**, in `fraud/experiments/features/new_fields/`:
  - `nf_guard.py`:
    - the wrapper check (R4) applies only when a timing-wrapper record sits beside the control (`<control_dir>_timing/wrapper.json`);
    - same-batch needs both the `cpu` and the `cuda` result;
    - an owner-accepted rescore gap is shown as such.
  - `nf_plan.py` and `nf_read.py`: their messages say "all applicable stage 1 checks".
  - Two new tests: `test_new_fields_wrapper_applicability.py` and `test_new_fields_rescore_acceptance.py`.
- **New**, in `fraud/experiments/reproduce/`:
  - `repro_paths.py`: the only file Copilot may adapt;
  - `repro_rules.py`, `repro_common.py`, `repro_layout.py`;
  - `preflight.py`, `route_check.py`, `rescore.py`, `compare_predictions.py`, `same_batch.py`;
  - `report.py`, `run_all.sh`, `start.sh`, `README.md`.

`changes_addon.diff` holds every changed line. Nothing under the trainer's source hash changes.

The reviewers tested the checks package in their own repository, which keeps the old layout and its test fixtures.
Those tests are not shipped, because they need the old layout's fixtures:
- 259 passed (the other reviewer: the package plus the affected feature tests);
- 208 passed (the coordinating reviewer).

Real tiny CPU training and scoring ran in those tests. The CUDA parts ran only with mocks, never on a GPU.

## What the checks prove

| Check | What | Result file the guard reads |
|---|---|---|
| S1, S2, S3 | The kept seed 42, 43 and 44 checkpoints, rescored on Test 1 (files 8000 to 8010) with the organized scorer, equal their original receipts (AP 0.102004, 0.091165, 0.101348) | `checkpoints/reproduce/rescore/summary.json` |
| S4 | The route test: a fully labelled chunk batch takes the all-position step, a target-ending batch takes the target-slot step | `checkpoints/reproduce/route.json` |
| S5, S6 | The same-batch test: the old tree (`tabular_fraud_old`) and the organized tree compute the same batches, weights, losses and scores, on CPU float32 and on GPU | `checkpoints/reproduce/same_batch/cpu/result.json`, `.../cuda/result.json` |

The queue also runs a preflight first: layout and patch markers, the source hash against stage 0's runs, the kept
checkpoints' hashes against their original receipts and manifests, the busy check, free disk and the environment.

## How to apply

With `PY` set to the project's interpreter:

1. Note the trainer's source hash, as in features POD.md step 1.
2. Copy the 18 files over the project, at the same paths.
3. Run the guard with that hash, as in features POD.md. It must print `unchanged`.
4. Run the features install check (POD.md step 6). Expected: 1192 passed, 4 skipped.
5. Adapt only `fraud/experiments/reproduce/repro_paths.py`, where the pod differs:
   - the interpreter;
   - `OLD_ROOT` (the old project folder);
   - `ARCHIVE_ROOTS`;
   - `STAGE0_QUEUE_NAME`;
   - `KEPT_MODEL_DIR`;
   - `BASE_CONFIG`.

   List each change for the owner.
6. Run `CUDA_VISIBLE_DEVICES= $PY fraud/experiments/reproduce/preflight.py --cpu-only` and show the owner the screen.
7. When the GPU is free, the owner starts the queue: `PY=$PY bash fraud/experiments/reproduce/start.sh`.
   - `$PY fraud/experiments/reproduce/report.py` shows progress at any time.
   - The checks need 3 scoring runs and a short GPU same-batch run.
8. In `fraud/experiments/features/new_fields/UPSTREAM.yaml`:
   - set `stage1.control_dir` to the owner's seed-42 rerun folder;
   - leave the other `stage1` paths at their defaults, which are where the queue writes.

   When the guard says all applicable stage 1 checks passed, stage 2 starts as features POD.md says.

## Notes

- **Wrapper check.** For the owner's plain rerun, the guard reports the wrapper check as not applicable. That is
  expected, not a failure.
- **Rescore gap.** `--accept-rescore-gap "<reason>"` is the owner's decision only, for S1 to S3.
  - It is passed only after the per-row evidence explains the gap.
  - Copilot never passes it on its own.
  - The guard then shows the accepted gap; it never shows a pass.
- **Reuse.** A result that already exists and is compatible is reused. Its saved verdict is read again, so a STOP
  stays a STOP. To run a step again, rename its folder.
- **Exit codes.** 0 done, 3 STOP, 4 refused (busy GPU, wrong input, an output already exists). Report a 3 or a 4 to
  the owner; do not work around it.
- **Outputs.** Nothing is suppressed or masked. Full paths and numbers are printed.
