# Start here: the reviewers' delivery of 3 November, for Copilot

Paste this file into Copilot on the work laptop before opening any zip. It explains what each zip is, the order to
use them in, and the rules that hold for all of them. Each zip also has its own read-first file; this guide does not
replace them, it ties them together.

## The zips

| Zip | Files | What it is | Read first |
|---|---|---|---|
| `tuning_package_part1_clean.zip` | 12 | The plan for stages 0 to 5, with every decision the reviewers agreed on 2 and 3 November, the joint decision record, and the stage 0 folder (already run) | `tuning_package_part1_clean/README_FIRST.md`, then `PLAN.md` |
| `features_testing_package_REVIEWERS_SUGGESTIONS.zip` | 147 | Stage 2 of the plan: the CPU field checks, the CPU screen, the feature workbook, the stage 2 queue and its decision reader, their tests and documents | `README_FIRST.md`, then `fraud/experiments/features/new_fields/POD.md` |
| `features_addon_two_workbenches_REVIEWERS_SUGGESTIONS.zip` | 17 | An add-on to the features package: the stage 2 queue runs fits on two workbenches at once, one job per workbench, from one planner | `ADDON_README.md` |

`tuning_package_part1.zip` in the same place is the older version of the tuning package. The clean zip replaces it.

## Order

1. Read the tuning package: `README_FIRST.md`, then `PLAN.md`. It is the map of the whole programme: what each
   stage does, what it decides, and its budget. `DECISIONS_JOINT.md` holds the reasons for each decision.
2. Install the features package as its `README_FIRST.md` and `POD.md` say, in POD.md's order. Before installing,
   note the trainer's source hash (POD.md step 1); after installing, run the guard with it. Its install check
   (POD.md step 6) is expected to give 1044 passed, 4 skipped.
3. Only if the owner wants two workbenches: copy the add-on's 15 files over the installed package at the same
   paths, then run the install check again. Expected: 1158 passed, 4 skipped. With one workbench, the add-on changes
   nothing about how the queue runs.
4. Part A of the features package is CPU only and may run while the GPU trains. Part B uses the GPU and starts only
   when POD.md says, after stage 0's runs and stage 1's GPU work. The stage 1 seed-42 retrain is part B's control.
5. Stage 1 is done: the owner ran the seed-42 rerun of the chosen model on 2 November and reports it good. That
   rerun is part B's control. In `fraud/experiments/features/new_fields/UPSTREAM.yaml`, set `stage1.control_dir` to
   that run's checkpoint folder on the pod; the queue reads the control from there. Where the plan or a read-first
   file still calls stage 1 paused or pending, it is out of date.

## Rules for every zip

1. The reviewers do not know the pod's or the laptop's current state. Adapt paths and commands to what exists now.
   Never change the logic: no step, seed, file range, population, rule, threshold or decision changes.
2. Never edit a file under the trainer's source hash: everything under `fraud/` except `fraud/experiments/`, plus
   `pyproject.toml` and `requirements.txt`. If the guard does not print `unchanged` after an install, remove the
   copied folders and stop.
3. If something cannot be found, or two candidates exist, stop and ask the owner, showing what you found.
4. After each command, show the owner its whole output.
5. If a tool stops with exit 3 (a check failed) or 4 (refused), report its reason to the owner. Do not work around
   it, rename outputs, or rerun with other settings unless the owner says so.
6. Outputs are never suppressed, redacted or masked.
7. Never start a GPU job on your own. The owner starts the queue, or tells you to.
8. Each zip's own prompt and read-first file hold its detailed rules (the features package's `COPILOT_PROMPT.md`
   has 13). Where one of them still says stage 0 is running, it is out of date: stage 0's runs are done.

## Two workbenches (only with the add-on)

For the stage 2 worker queue, the add-on supersedes the older single-workbench instructions, and the text saying the
two-workbench workers are not built, in the features package's and the tuning package's read-first files and plan.
The stage 3 paired tuner is still future work.

With `NF=fraud/experiments/features/new_fields`:

- On the planner's workbench: `PY=$PY bash $NF/nf_start.sh --workers`, then `PY=$PY bash $NF/nf_worker.sh`.
- On the second workbench: `PY=$PY bash $NF/nf_worker.sh`.
- On either: `$PY $NF/nf_report.py`.
- Before the second workbench goes away: `$PY $NF/nf_worker.py stop`, once the report says `safe now`. It refuses
  while a candidate and control pair it started is still open, so a pair is never split across workbenches.
- Back to one workbench: `PY=$PY bash $NF/nf_start.sh`, as POD.md section 4b says (switch only at a job boundary).

## Decided but not built yet

These are agreed by both reviewers and come in a later delivery. Nothing in the zips pretends they exist:

- in the features package: the external-score check, the SELECT check's rate printout, stage 0b's cross-model
  reader mode (built only if stage 0b's gate fires), per-step bars, the three-seed pruning read (pruning stays off),
  the widest-list timings, and the same-day keep gate;
- in the plan: stage 4's two kept checkpoints, the training-files report before the first fit outside files 1 to
  10, and the one broader-coverage arm with negative sampling;
- tuning part 2 (stage 3's search and its code).

PLAN.md section 5 lists the plan's items under "Decided, not built yet", and `DECISIONS_JOINT.md` gives each
decision. The features items above are listed together only here.
