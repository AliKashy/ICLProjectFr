"""Field intake: the pod's columns, the field map's checks, adoption of the owner's list, and feature definitions.

  CUDA_VISIBLE_DEVICES= $PY $NF/nf_intake.py schema       # parquet footers only, every file range stage 2 reads
  $PY $NF/nf_intake.py draft                               # the attributes file in map form (UNCONFIRMED)
  CUDA_VISIBLE_DEVICES= $PY $NF/nf_intake.py check-map     # one screen; --in-place writes the derived columns back
  $PY $NF/nf_intake.py adopt --list <owner file> --confirmed-by "<name, date>"
  $PY $NF/nf_intake.py definitions                         # feature definitions for a feature store

The feature list is an input file. Nothing here hard-codes a field name or the column count; status rules are data
in STATUS_RULES.csv. Only `adopt` writes list_status.
"""
import argparse
import csv
import difflib
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nf_common as C  # noqa: E402

# Reasons on a source column that reach every recipe reading it (design review item 28). A raw same-transaction
# decision does not propagate: prev(c) of it is the allowed form, with its own wait.
PROPAGATE = {"left_out_26oct", "status", "uses_outcome", "excluded_by_sumegha", "not_feasible", "hold",
             "same_txn_prev"}
RESULT_ORDER = {"PASS": 0, "FLAG": 1, "WAIT": 2, "STOP": 3}
CALENDAR = ("month", "day", "hour", "day_of_week", "time_delta")
ID_COLUMNS = ("Nmap_account_reference_xid", "fi_transaction_id")
TIME_COLUMN = "transaction_dttm"
LABEL_PATTERNS = (r"^frd_tag$", r"^label$", r"^target$", r"^is_fraud$", r"^fraud_flag$", r"(^|_)frd_tag($|_)")
EXTERNAL_PATTERNS = (r"^external_\d+_scr$", r"^vaa$", r"(^|_)vaa($|_)", r"_scr$")
# Spellings to try (scout B). Suggestions only; never applied.
SPELLINGS = [("pinwfatmcurrdttm", "pinwfatmcurdttm"), ("ddatellerlastdepatttm", "ddatellerlastdepattm"),
             ("moble_amt_curr", "mobile_curr"), ("edrlogonctcurr", "edrlogonctcoun")]
RANGE_BASE = {"train": "train", "epoch_val": "val", "ds_train": "train"}   # every other range reads eval.base


# ------------------------------------------------------------------ recipe grammar (DESIGN.md 2.2, review 3, 5, 12)
# One grammar (integration decision 4): the data lane's nf_recipes.parse. The intake keeps a small view of it.

HISTORY = {"count", "sum", "mean", "min", "max", "distinct", "since_last", "since_first", "prev"}


def _recipes():
    import nf_recipes
    return nf_recipes


class RecipeError(ValueError):
    pass


def window_seconds(w):
    R = _recipes()
    try:
        return R.window_seconds(w or "")
    except R.RecipeError as e:
        raise RecipeError(str(e))


def parse_recipe(text):
    """Parse one recipe with nf_recipes.parse, the one grammar. Returns {func, opts, columns (sources read),
    window, lag, within, lookback_seconds, as_of, recipe}. Raises RecipeError on anything the grammar refuses."""
    R = _recipes()
    try:
        r = R.parse(text)
    except R.RecipeError as e:
        raise RecipeError(str(e))
    d = r.describe()
    opts = {k: v for k, v in (("same", r.same), ("key", r.key)) if v}
    cols = [] if r.op in ("raw", "a3") else list(r.sources)
    within = "all" if r.unlimited else R.window_label(r.within)
    return {"func": r.op, "args": [], "opts": opts, "columns": cols, "window": d["window"], "lag": d["lag"],
            "within": within if r.op in ("since_last", "since_first", "prev") else "",
            "lookback_seconds": r.lookback_seconds, "as_of": d["as_of_rule"], "recipe": r}


def as_of_rule(p):
    if p.get("as_of"):
        return p["as_of"]          # nf_recipes' own description of the recipe (one grammar, one text)
    f = p["func"]
    if f == "raw" or f == "code":
        return "value stored on the row at the transaction time"
    if f == "days_before":   # the reviewers' decision D3b (nf_recipes' own text is used when it loads)
        return ("ln(1 + whole seconds from the event date to the transaction time); a date with no time part in "
                "whole calendar days x 86,400; missing, with its reason, when after the transaction")
    if f == "days_until":
        return "sign(u) x ln(1 + |u|), u the calendar days from the transaction's day to a known future date"
    if f == "ratio":
        return "ratio of two values stored on the row at the transaction time"
    if f == "geohash":
        return "TFM's geohash of the postal code with the country on the row (SETTINGS.yaml geohash_table)"
    if f == "a3":
        return "26 October builder, strictly earlier rows (strict_window precision)"
    lagtxt = f", lagged {p['lag']}" if p["lag"] else ""
    return ("strictly earlier rows of the same account, whole seconds, window "
            f"{p['window']}{lagtxt}, censored before the extract start (missing, never zero)")


def is_history(p):
    return p["func"] in HISTORY


# ------------------------------------------------------------------ settings helpers

def base_predictors(path=None):
    p = C.ROOT / (path or C.settings().get("base_predictors", "fraud/configs/predictors.csv"))
    with open(p, encoding="utf-8") as f:
        return [r["feature"] for r in csv.DictReader(f)]


def status_rules(path=None):
    p = Path(path) if path else C._settings_dir() / "STATUS_RULES.csv"
    with open(p, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _tokens(s):
    return [t for t in re.split(r"[^a-z0-9]+", s.lower()) if t]


def rule_matches(rule, value):
    v, pat = value.strip(), rule["pattern"].strip()
    if not v:
        return False
    if rule["match"] == "exact_ci":
        return v.lower() == pat.lower()
    if rule["match"] == "token_ci":
        pt, vt = _tokens(pat), _tokens(v)
        return any(vt[i:i + len(pt)] == pt for i in range(len(vt) - len(pt) + 1)) if pt else False
    if rule["match"] == "substring_ci":
        return pat.lower() in v.lower()
    raise ValueError(f"STATUS_RULES.csv: unknown match {rule['match']!r}")


def status_of(row, rules, sources):
    """(rule, pattern, field it matched, reason), or None. Each value (the name, tfm_name, f15298_name and every source
    column) is judged on its own: within a value, left_out_26oct > rank52 > same_txn_decision > status_like, and an
    allow row clears status_like for that value only. Across values the worst wins (a STOP rule, then status_like,
    then rank52), so a rank52 source never hides a status source read by the same recipe (design review items 7, 10,
    28)."""
    values = [("name", row.get("name", "")), ("tfm_name", row.get("tfm_name", "")),
              ("f15298_name", row.get("f15298_name", ""))] + [("source_columns", c) for c in sources]
    within = ("left_out_26oct", "rank52", "same_txn_decision", "status_like")
    across = {"left_out_26oct": 0, "same_txn_decision": 1, "status_like": 2, "rank52": 3}
    best = None
    for where, v in values:
        hits, allowed = {}, False
        for r in rules:
            if where not in [x.strip() for x in r["applies_to"].split(";")] or not rule_matches(r, v):
                continue
            if r["rule"] == "allow":
                allowed = True
            else:
                hits.setdefault(r["rule"], (r["rule"], r["pattern"], f"{where}={v}", r["reason"]))
        for name in within:
            if name in hits and not (name == "status_like" and allowed):
                if best is None or across[name] < across[best[0]]:
                    best = hits[name]
                break
    return best


def cleared_status(name):
    """The owner's written clearing of a false status match (design review item 7): a row of NF/KEEP_DECISIONS.csv
    for this name, decided by a person (not 'proposed'), whose reason starts with 'status match cleared'."""
    d = C.person_decisions().get(name)
    return bool(d and d.get("reason", "").lower().startswith("status match cleared"))


# ------------------------------------------------------------------ schema

def _ranges():
    pops = C.settings().get("populations", {})
    order = ["train", "epoch_val", "rank_a", "rank_b", "select", "test1", "ds_train", "ds_select"]
    return [(k, int(pops[k]["files"][0]), int(pops[k]["files"][1])) for k in order if k in pops]


def _bases(args):
    cfg = {}
    p = C.ROOT / C.settings().get("base_config", "fraud/configs/sequential_hier_allpos.yaml")
    if p.is_file():
        cfg = C.flatten(C.load_yaml(p))
    return {"train": args.train_base or cfg.get("data.train_base"),
            "val": args.val_base or cfg.get("data.val_base") or args.train_base or cfg.get("data.train_base"),
            "eval": args.eval_base or cfg.get("eval.base"),
            "cred": args.cred_path if args.cred_path is not None else cfg.get("s3.cred_path")}


def _filesystem(bases):
    if not any(str(b or "").startswith(("s3://", "s3a://")) for b in bases.values()):
        return None, lambda x: x
    import nf_layout
    nf_layout.bootstrap()
    try:
        fs = nf_layout.attr("s3", "thin_read_filesystem")(bases["cred"])
    except SystemExit:
        fs = nf_layout.attr("s3", "make_s3_filesystem")(bases["cred"])
    strip = nf_layout.attr("s3", "strip_scheme")
    return fs, strip


def cmd_schema(args):
    import pyarrow.parquet as pq
    try:
        bases = _bases(args)
    except (OSError, ValueError, SystemExit) as e:
        C.say(f"refused: the base config cannot be read ({e}); Copilot adapts SETTINGS.yaml base_config")
        return C.REFUSED
    for name, a, b in _ranges():
        if not bases[RANGE_BASE.get(name, "eval")]:
            C.say(f"refused: no data folder for range {name} (files {a}-{b}); the base config has none. Pass "
                  "--train-base, --val-base and --eval-base, or adapt SETTINGS.yaml base_config")
            return C.REFUSED
    try:
        fs, strip = _filesystem(bases)
    except (OSError, ValueError, SystemExit) as e:
        C.say(f"refused: the S3 file system cannot be opened ({type(e).__name__}: {e}); check s3.cred_path",
              file=sys.stderr)
        return C.REFUSED
    cols, per_range, missing_files, files_read = {}, {}, [], 0
    for name, a, b in _ranges():
        base = bases[RANGE_BASE.get(name, "eval")]
        per_range[name] = {"files": 0}
        for n in range(a, b + 1):
            path = f"{str(base).rstrip('/')}/part_{n}.parquet"
            try:
                sch = pq.read_schema(strip(path), filesystem=fs) if fs else pq.read_schema(path)
            except (OSError, FileNotFoundError) as e:
                missing_files.append(f"{name}:{n}")
                per_range[name].setdefault("missing", []).append(n)
                print(f"missing or unreadable: {path} ({type(e).__name__})", file=sys.stderr)
                continue
            files_read += 1
            per_range[name]["files"] += 1
            for f in sch:
                d = cols.setdefault(f.name, {})
                d.setdefault(name, {}).setdefault(str(f.type), []).append(n)
    if files_read == 0:
        C.say(f"refused: no parquet file could be read in any range ({len(missing_files)} missing or unreadable); "
              "check the data folders and credentials. Nothing was written", file=sys.stderr)
        return C.REFUSED
    rows = []
    rnames = [r[0] for r in _ranges()]
    for c in sorted(cols):
        d = cols[c]
        types = sorted({t for r in d.values() for t in r})
        absent = []
        for rname, a, b in _ranges():
            have = {n for ns in d.get(rname, {}).values() for n in ns}
            want = set(range(a, b + 1)) - set(per_range[rname].get("missing", []))
            absent += [f"{rname}:{n}" for n in sorted(want - have)]
        rows.append({"column": c, "ranges_present": ";".join(r for r in rnames if r in d),
                     "ranges_missing": ";".join(r for r in rnames if r not in d),
                     "files_missing": ";".join(absent), "types": ";".join(types),
                     "type_differs": "yes" if len(types) > 1 else "no",
                     "types_by_range": ";".join(f"{r}={'|'.join(sorted(d[r]))}" for r in rnames if r in d)})
    outp = C.out("intake", "pod_columns.csv")
    with open(outp, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]) if rows else ["column"])
        w.writeheader()
        w.writerows(rows)
    everywhere = sum(1 for r in rows if not r["files_missing"] and not r["ranges_missing"])
    lines = [f"files read {files_read} (footers only, no rows); missing or unreadable files {len(missing_files)}",
             f"pod raw columns: {len(rows)} distinct; {everywhere} present in every file read"]
    for rname, a, b in _ranges():
        lines.append(f"  {rname:<10} files {a}-{b}: read {per_range[rname]['files']}")
    differ = [r for r in rows if r["type_differs"] == "yes"]
    lines.append(f"columns whose type differs between files: {len(differ)}")
    lines += [f"  {r['column']}: {r['types']}" for r in differ[:8]]
    part = [r for r in rows if r["files_missing"] or r["ranges_missing"]]
    lines.append(f"columns missing from some files: {len(part)}")
    lines += [f"  {r['column']}: missing in {r['ranges_missing'] or r['files_missing'][:60]}" for r in part[:8]]
    C.print_screen("INTAKE SCHEMA  " + C.utc_now(), lines, footer="table: " + C.rel(outp))
    return C.OK if not missing_files else C.PARTIAL


def read_pod_columns():
    p = C.c2() / "intake" / "pod_columns.csv"
    if not p.is_file():
        return None
    with open(p, encoding="utf-8") as f:
        return {r["column"]: r for r in csv.DictReader(f)}


# ------------------------------------------------------------------ draft

def _date_like(name, dtype=""):
    n = name.lower()
    return ("date" in str(dtype).lower() or "timestamp" in str(dtype).lower()
            or n.endswith(("_dt", "dt", "dttm", "_date", "date")))


def _model_type(dtype):
    d = str(dtype).lower()
    return "continuous" if any(k in d for k in ("float", "double", "int", "decimal", "number", "numeric")) \
        else "categorical"


# The workbook lane's attributes file names every feature once (integration decision 2). Its words map to the
# field map's allowed values here.
ORIGIN_WORDS = (("tfm v22b and 15298", "both"), ("tfm v22b", "v22b"), ("15298", "f15298"), ("proposed", "proposed"))
YAQUN_WORDS = (("continuous", "continuous"), ("categorical", "categorical"), ("datetime", "datetime_derived"),
               ("deliberately excluded", "excluded"))
MAPPING_WORDS = {"recorded": "mapped", "mapped": "mapped", "open": "open", "name_only": "open",
                 "guessed_from_name": "open", "to map on the pod": "open"}
LE_REASON = ("original encoder unverified; raw code proposed as an alternative (reviewer feature review)")


def _word(text, table, default=""):
    t = str(text or "").strip().lower()
    for k, v in table:
        if t.startswith(k):
            return v
    return default


def draft_rows(attrs, pod=None):
    """Field-map rows from the attributes file: names, recipes and source columns as written there. An LE1/LE3
    output with its raw code recorded (mapping_status open, raw_alternative set, no recipe) gets the recipe
    code(<raw code>) as a proposed alternative: check-map FLAGs it encoding_alternative, never a STOP."""
    rows = []
    for _, r in attrs.iterrows():
        recipe, src, mtype = r["recipe"].strip(), r["source_columns"].strip(), r["model_type"].strip()
        alt = r.get("raw_alternative", "").strip()
        le = not recipe and bool(alt) and r.get("mapping_status", "").strip() == "open"
        if le:
            recipe, src, mtype = f"code({alt})", alt, "categorical"
        unmapped = recipe == "raw" and not src     # the name is not a pod column yet: check-map waits for it
        if recipe == "raw" and not mtype and pod and (src or r["name"]) in pod:
            types = pod[src or r["name"]].get("types", "")
            mtype = _model_type(types) if not _date_like(src or r["name"], types) else ""
        kind = "raw" if recipe == "raw" else ("engineered" if recipe else (r["kind"].strip() or "engineered"))
        wt = r.get("proposed_work_type", "").strip()
        row = {c: "" for c in C.FIELD_MAP_COLUMNS}
        row.update(
            name=r["name"].strip(), group=r["group"].strip(), kind=kind, recipe=recipe, source_columns=src,
            model_type=mtype, definition_version=r.get("definition_version", "") or "1",
            tfm_name=r.get("tfm_name", ""), f15298_name=r.get("f15298_name", ""), v22b_rank=r.get("v22b_rank", ""),
            f15298_rank=r.get("f15298_rank", ""), excluded_by_sumegha=r.get("excluded_by_sumegha", ""),
            sumegha_reason=r.get("sumegha_reason", ""),
            feasible_in_production=r.get("feasible_in_production", "") or "unknown",
            left_out_reason=r.get("left_out_reason", ""), list_status="UNCONFIRMED",
            kept_once_as=r.get("kept_once_as", ""), notes=r.get("flags", ""),
            output_name=r.get("tfm_name", "") or r.get("f15298_name", "") or r["name"],
            origin=_word(r.get("origin", ""), ORIGIN_WORDS), description=r.get("description", ""),
            yaqun_category=_word(r.get("yaqun_category", ""), YAQUN_WORDS),
            business_category=r.get("business_category", ""), date_meaning=r.get("date_meaning", ""),
            mapping_status=MAPPING_WORDS.get(r.get("mapping_status", "").strip(), ""),
            equivalence="unverified" if le else r.get("equivalence", ""),
            proposed_work_type=wt if wt in C.ALLOWED["proposed_work_type"] else "",
            next_definition_needed=r.get("next_definition_needed", ""))
        if unmapped:
            row["next_definition_needed"] = row["next_definition_needed"] or "map the pod column (recipe raw)"
        if le:
            # a proposed alternative, not a left-out row: the reason moves to the notes
            row["notes"] = "; ".join(x for x in (row["notes"], LE_REASON, row["left_out_reason"]) if x)
            row["left_out_reason"] = ""
        row["donor_unit"] = C.default_donor_unit(row)
        rows.append(row)
    return rows


def cmd_draft(args):
    attrs_path = Path(args.attributes) if args.attributes else C.NF / "DRAFT_FEATURE_ATTRIBUTES_UNCONFIRMED.csv"
    if not attrs_path.is_file():
        C.say(f"refused: the attributes file is missing: {C.rel(attrs_path)}")
        return C.REFUSED
    import pandas as pd
    attrs = pd.read_csv(attrs_path, dtype=str, keep_default_na=False)
    need = {"name", "group", "kind", "recipe", "source_columns", "model_type"}
    if not need <= set(attrs.columns):
        C.say(f"refused: {C.rel(attrs_path)} lacks {sorted(need - set(attrs.columns))}", file=sys.stderr)
        return C.REFUSED
    dup = sorted(set(attrs.loc[attrs["name"].duplicated(), "name"]))
    if dup:
        C.say(f"refused: names repeat in {C.rel(attrs_path)}: {', '.join(dup[:8])}")
        return C.REFUSED
    rows = draft_rows(attrs, read_pod_columns())
    outp = C.out("intake", "FIELD_MAP_DRAFT_UNCONFIRMED.csv")
    C.write_field_map(pd.DataFrame(rows), outp)
    n_le = sum(1 for r in rows if LE_REASON in r["notes"])
    C.print_screen("INTAKE DRAFT (UNCONFIRMED, for comparison only)",
                   [f"rows written {len(rows)}, one per name of {attrs_path.name} (names, recipes and source "
                    "columns as written there)",
                    f"LE1/LE3 outputs given code(<raw code>) as a proposed alternative: {n_le} (FLAG, not STOP)",
                    "every row says list_status=UNCONFIRMED; no tool builds copies, an artifact or a fit from it",
                    "rows with no recipe wait as definition_needed; they are not left out"],
                   footer="draft map: " + C.rel(outp))
    return C.OK


# ------------------------------------------------------------------ check-map

def _worst(a, b):
    return a if RESULT_ORDER[a] >= RESULT_ORDER[b] else b


# a3 outputs today's call of the 26 October builders cannot produce (the reviewers' decision D4a)
A3_UNBUILDABLE = {
    "cp_cnt_5m_log1p": "needs the card-present and card-absent code values",
    "cnp_cnt_24h_log1p": "needs the card-present and card-absent code values",
    "dist_prev_km_log1p": "needs the card-present and card-absent code values and a postal-centroid table",
    "speed_kmh_log1p": "needs the card-present and card-absent code values and a postal-centroid table",
    "dist_home_km_log1p": "needs the card-present and card-absent code values and a postal-centroid table",
}


def output_definition(r, p):
    """A row's output definition (the reviewers' decision D3a): source column, op, group key, window, lag and
    encoding; code(c) and raw c on a code count as the same output."""
    if p is None or p["func"] == "a3":
        return None
    rec = p["recipe"]
    op = p["func"]
    srcs = tuple(sorted(p["columns"])) if p["columns"] else (r["name"],)
    if op == "raw" and r["model_type"] == "categorical":
        op = "code"
    if op == "raw" and r["source_columns"]:
        srcs = tuple(sorted(s.strip() for s in r["source_columns"].split(";") if s.strip()))
    return (op, srcs, getattr(rec, "key", None) or "", getattr(rec, "window", None) or 0,
            getattr(rec, "lag", 0) or 0, getattr(rec, "within", None) or 0, r["model_type"])


def check_map(df, pod=None, base=None, rules=None, thr=None):
    """Returns (df with derived columns filled, results list of dicts name/result/reasons/suggestions)."""
    base = base if base is not None else base_predictors()
    rules = rules if rules is not None else status_rules()
    thr = thr if thr is not None else C.thresholds()
    generic = {g.lower() for g in thr.get("generic_source_columns", [])}
    max_days = float((thr.get("flag") or {}).get("history_parity_max_days", 30))
    df = df.copy()
    results = []
    names_seen = {}
    parsed = {}
    pod_lower = {c.lower(): c for c in (pod or {})}
    geohash_table = None   # SETTINGS.yaml geohash_table, read once when a geohash recipe is met
    for i, r in df.iterrows():
        name = r["name"]
        reasons, sugg = [], []
        res = "PASS"

        def fire(level, rule, detail=""):
            nonlocal res
            res = _worst(res, level)
            reasons.append(f"{level} {rule}" + (f": {detail}" if detail else ""))

        if "donor_unit" in df.columns and not r["donor_unit"]:
            df.at[i, "donor_unit"] = C.default_donor_unit(r)
        for col, allowed in C.ALLOWED.items():
            if col in df.columns and r[col] not in allowed:
                fire("STOP", "bad_value", f"{col}={r[col]!r} not in {allowed}")
        if not name:
            fire("STOP", "bad_value", "blank name")
        if name in names_seen:
            fire("STOP", "duplicate_name", f"same name as row {names_seen[name] + 2}")
        names_seen.setdefault(name, i)
        sources = [s.strip() for s in r["source_columns"].split(";") if s.strip()]
        p = None
        if not r["recipe"]:
            fire("WAIT", "definition_needed", r["next_definition_needed"] or "no recipe yet")
        else:
            try:
                p = parse_recipe(r["recipe"])
            except RecipeError as e:
                msg = str(e)   # the grammar's own refusal, named by its rule where it has one
                rule = ("generic_source" if "generic_source" in msg else
                        "uses_outcome" if "label or label-like" in msg else "recipe_parse")
                fire("STOP", rule, msg)
        if p and not r["model_type"]:
            if p["func"] == "raw":
                fire("WAIT", "model_type_from_pod", "the type comes from the pod's columns: run schema, then draft")
            else:
                fire("STOP", "bad_value", "model_type is blank")
        if p:
            parsed[name] = p
            used = set(p["columns"])
            if p["func"] == "raw" and not sources:
                # a raw row whose pod column is not named yet (the attributes file leaves it blank): it waits
                fire("WAIT", "pod_column_needed", r["next_definition_needed"] or "map the pod column")
                used = set()
            elif p["func"] == "raw":
                used = set(sources) or {name}
                if len(sources) > 1:
                    fire("STOP", "recipe_parse", "a raw field reads one column")
                if sources and sources[0] != name:
                    fire("STOP", "raw_name", f"a raw field keeps the pod name exactly ({sources[0]})")
            missing_src = sorted(used - set(sources) - {TIME_COLUMN})
            if missing_src and p["func"] != "a3":
                fire("STOP", "source_columns", f"recipe reads {', '.join(missing_src)} not listed in source_columns")
            df.at[i, "window"] = p["window"]
            df.at[i, "lag"] = p["lag"]
            df.at[i, "as_of_rule"] = as_of_rule(p)
            if p["func"] == "a3" and r["group"] != "a3":
                fire("STOP", "bad_value", "a3(col) belongs to group a3")
            if p["func"] in ("days_before", "days_until"):
                want = "event_date" if p["func"] == "days_before" else "known_future_date"
                if not r["date_meaning"]:
                    df.at[i, "date_meaning"] = want
                elif r["date_meaning"] != want:
                    fire("STOP", "date_meaning", f"{p['func']} needs date_meaning={want}")
                if r["model_type"] != "continuous":
                    fire("STOP", "bad_value", "a date recipe gives a number: model_type continuous")
            if p["func"] in ("days_before", "days_until", "code", "geohash") and \
                    any(s.lower() in generic for s in p["columns"]):
                fire("STOP", "generic_source", "a multi-output field: name the subfield column; never cast the "
                     "whole value")
            if p["func"] == "geohash":
                if r["model_type"] != "categorical":
                    fire("STOP", "bad_value", "geohash(postal; country) gives a category: model_type categorical")
                if geohash_table is None:
                    try:
                        geohash_table = str((C.settings() or {}).get("geohash_table") or "").strip()
                    except (OSError, ValueError):
                        geohash_table = ""
                if not geohash_table:
                    fire("STOP", "geohash_table", "SETTINGS.yaml geohash_table is blank; give TFM's table (its S3 "
                         "path or a local copy)")
            if p["func"] == "code":
                if not r["mapping_status"]:
                    df.at[i, "mapping_status"] = "open"
                if not r["equivalence"]:
                    df.at[i, "equivalence"] = "unverified"
                if r["model_type"] != "categorical":
                    fire("STOP", "bad_value", "code(c) is a category: model_type categorical")
                if r["kept_once_as"] and (r["equivalence"] or "unverified") != "unverified" and \
                        r["equivalence"] != "documented":
                    fire("STOP", "bad_value", "kept_once_as on a code needs equivalence")
                fire("FLAG", "encoding_alternative", "raw categorical is a proposed alternative, not proven "
                     "equivalent to the original encoder")
            if is_history(p):
                lb = p.get("lookback_seconds")
                horizon = float("inf") if lb is None else lb / 86400.0
                if horizon > max_days:
                    fire("FLAG", "history_parity", (f"looks back {horizon:g} days" if horizon != float("inf")
                                                     else "looks back since the extract start")
                         + f"; June rows can look back at most about {max_days:g}")
            if r["kind"] == "raw" and p["func"] != "raw":
                fire("STOP", "bad_value", "kind raw needs recipe raw")
            if p["func"] == "raw" and r["kind"] != "raw":
                fire("STOP", "bad_value", "recipe raw needs kind raw")
            if pod is not None and p["func"] == "raw" and sources:
                info = pod.get(sources[0])
                if info and _date_like(sources[0], info.get("types", "")) and \
                        any(k in info.get("types", "").lower() for k in ("date", "timestamp")):
                    fire("STOP", "raw_date", "a date enters only as days_before or days_until")
        # name clashes
        low = name.lower()
        if name in base or low in CALENDAR or low.endswith("_isna") or name in ID_COLUMNS or name == TIME_COLUMN:
            fire("STOP", "name_clash", "a base predictor, calendar field, time gap, id or *_isna name")
        if pod is not None and r["kind"] == "engineered" and (name in pod or low in pod_lower):
            fire("STOP", "name_clash", "an engineered name equal to a pod column")
        if r["kind"] == "engineered" and not re.match(r"^[a-z][a-z0-9_]*$", name or ""):
            fire("STOP", "bad_value", "an engineered name is lowercase letters, digits and underscores")
        # outcomes, sources
        allsrc = sources + ([] if not p else p["columns"])
        for s in set(allsrc):
            if any(re.search(pt, s.lower()) for pt in LABEL_PATTERNS):
                fire("STOP", "uses_outcome", f"source {s} is the label or label-like")
        if pod is not None:
            for s in sorted(set(allsrc)):
                info = pod.get(s)
                if info is None:
                    close = difflib.get_close_matches(s, list(pod), n=3, cutoff=0.75)
                    for a, b in SPELLINGS:
                        for x, y in ((a, b), (b, a)):
                            if x in s.lower():
                                cand = s.lower().replace(x, y)
                                close += [pod_lower[cand]] if cand in pod_lower else []
                    fire("STOP", "missing_from_files", f"{s} is not a pod column")
                    if close:
                        sugg.append(f"{s}: try {', '.join(dict.fromkeys(close))} (suggestion only)")
                elif info.get("ranges_missing") or info.get("files_missing"):
                    fire("STOP", "missing_from_files", f"{s} missing in {info.get('ranges_missing') or 'some files'}")
        else:
            reasons.append("note: pod columns not read yet (run schema)")
        if p and p.get("opts", {}).get("same") and p["opts"]["same"] not in ID_COLUMNS[:1]:
            fire("FLAG", "group_key_check", f"same={p['opts']['same']} is checked by the field checks (one file "
                 "per value)")
        # status rules (precedence), Sumegha, feasibility, external scores, holds, left out
        st = status_of(r, rules, allsrc)
        df.at[i, "status_rule"] = st[0] if st else ("hold" if r["status_rule"] == "hold" else "none")
        if st:
            kind, pat, where, why = st
            fixed = r["data_owner_fixed"] == "yes"
            if kind == "left_out_26oct":
                fire("STOP", "left_out_26oct", f"{where}")
            elif kind == "same_txn_decision":
                if p and p["func"] == "prev":
                    if not fixed:
                        fire("WAIT", "same_txn_prev", "prev(c) of a bank decision: the data owner confirms it is "
                             "written at authorisation and never revised")
                else:
                    fire("STOP", "same_txn_decision", f"{where}: only prev(c) may enter")
            elif kind == "status_like" and not fixed and not cleared_status(name):
                fire("WAIT", "status", f"{where} matches {pat!r}; the data owner's written answer clears it")
        if r["status_rule"] == "hold":
            fire("WAIT", "hold", "the list's hold")
        if r["excluded_by_sumegha"] == "yes" and r["group"] in ("both", "f15298"):
            # the reviewers' decision D3a: Sumegha's exclusion follows the feature; a row in both lists leaves A1
            # (regrouped to f15298) and enters at A2 only with a person's keep row recording Sumegha's or the
            # owner's confirmation
            if r["group"] == "both":
                df.at[i, "group"] = "f15298"
                df.at[i, "notes"] = (r["notes"] + "; " if r["notes"] else "") + \
                    "regrouped from both to f15298: excluded by Sumegha for V22B (decision D3a)"
            if not C.person_decisions().get(name, {}).get("verdict", "") == "keep":
                fire("WAIT", "sumegha_15298", f"excluded by Sumegha ({r['sumegha_reason'] or 'no reason given'}); "
                     "enters at A2 only with a person's keep row recording Sumegha's or the owner's confirmation")
        elif r["excluded_by_sumegha"] == "yes":
            fire("STOP", "excluded_by_sumegha", r["sumegha_reason"])
        elif r["excluded_by_sumegha"] == "":
            fire("FLAG", "sumegha_blank", "Sumegha's answer not recorded; blank is not a yes")
        if r["feasible_in_production"] == "no":
            fire("WAIT", "not_feasible", r["feasibility_note"])
        elif r["feasible_in_production"] == "unknown":
            fire("FLAG", "feasibility_unknown")
        ext = r["external_score"] == "yes" or any(re.search(pt, x.lower()) for pt in EXTERNAL_PATTERNS
                                                  for x in [name, r["tfm_name"], r["f15298_name"]] + allsrc if x)
        if ext:
            if r["external_score"] == "":
                df.at[i, "notes"] = (r["notes"] + "; " if r["notes"] else "") + "intake proposes external_score=yes"
            fire("FLAG", "external_score", "production availability is for the owner and Sumegha")
        if r["left_out_reason"]:
            fire("STOP", "left_out_recipe", r["left_out_reason"])
        a3_col = getattr(p["recipe"], "column", None) if p and p["func"] == "a3" else None
        a3_why = A3_UNBUILDABLE.get(a3_col or "") or (A3_UNBUILDABLE.get(name) if r["group"] == "a3" else None)
        if a3_why and r["list_status"] in ("CONFIRMED", "UNCONFIRMED"):
            fire("FLAG", "a3_unbuildable", f"today's builder call cannot produce it: {a3_why} (decision D4a)")
        results.append({"name": name, "row": i, "result": res, "reasons": reasons, "suggestions": sugg,
                        "group": r["group"], "sources": allsrc})
    # propagation (design review item 28): a STOP or WAIT on a source column reaches every recipe that reads it
    by_name = {x["name"]: x for x in results}
    for x in results:
        for s in x["sources"]:
            src = by_name.get(s)
            if src and src is not x:
                hits = [rr for rr in src["reasons"] if rr.split()[0] in ("STOP", "WAIT")
                        and rr.split()[1].rstrip(":") in PROPAGATE]
                if not hits:
                    continue
                lvl = "STOP" if any(h.startswith("STOP") for h in hits) else "WAIT"
                first = next(h for h in hits if h.startswith(lvl))
                x["result"] = _worst(x["result"], lvl)
                x["reasons"].append(f"{lvl} source_{lvl.lower()}: source {s}: {first}")
    # the same output defined twice with different text (the reviewers' decision D3a): one row with group both
    prec = {"v22b": 0, "both": 0, "f15298": 1, "a3": 2}
    first_def = {}
    for x in sorted(results, key=lambda z: (prec.get(z["group"], 9), z["row"])):
        r = df.loc[x["row"]]
        d = output_definition(r, parsed.get(x["name"]))
        if d is None:
            continue
        if d in first_def and first_def[d][0] != x["name"]:
            other, other_text = first_def[d]
            if (r["recipe"].replace(" ", ""), r["source_columns"].replace(" ", "")) != other_text:
                x["result"] = _worst(x["result"], "FLAG")
                x["reasons"].append(f"FLAG same_feature_two_rows: the same output as {other}; write one row with "
                                    "group both")
        else:
            first_def.setdefault(d, (x["name"], (r["recipe"].replace(" ", ""), r["source_columns"].replace(" ", ""))))
    # same definition twice (2.6): the later one is kept once as the earlier, by group precedence then map order
    seen = {}
    for x in sorted(results, key=lambda z: (prec.get(z["group"], 9), z["row"])):
        r = df.loc[x["row"]]
        key = (r["recipe"].replace(" ", ""), r["source_columns"].replace(" ", ""))
        if not r["recipe"] or r["recipe"] == "raw" and not r["source_columns"]:
            continue
        if key in seen and seen[key] != x["name"]:
            x["result"] = "STOP"
            x["reasons"].append(f"STOP duplicate_definition: kept once as {seen[key]}")
            df.at[x["row"], "kept_once_as"] = seen[key]
        else:
            seen.setdefault(key, x["name"])
    return df, results


def cmd_check_map(args):
    mp = Path(args.map) if args.map else C.NF / "FIELD_MAP.csv"
    df = C.read_field_map(mp)
    pod = read_pod_columns()
    df2, results = check_map(df, pod=pod)
    outp = C.out("intake", "FIELD_MAP_CHECKED.csv")
    df3 = df2.copy()
    df3["intake_result"] = [x["result"] for x in results]
    df3["intake_reasons"] = [" | ".join(x["reasons"]) for x in results]
    C.write_field_map(df3, outp)
    if args.in_place:
        C.write_field_map(df2, mp)
    counts = {k: sum(1 for x in results if x["result"] == k) for k in RESULT_ORDER}
    status = "UNCONFIRMED" if (df["list_status"] != "CONFIRMED").any() else "CONFIRMED"
    lines = [f"rows {len(df)} (v22b {sum(df.group == 'v22b')}, f15298 {sum(df.group == 'f15298')}, "
             f"both {sum(df.group == 'both')}, a3 {sum(df.group == 'a3')}) | " +
             " ".join(f"{k} {v}" for k, v in counts.items()),
             f"pod columns: {'not read yet (run schema)' if pod is None else len(pod)}"]
    by_rule = {}
    for x in results:
        for rr in x["reasons"]:
            if rr.startswith(("STOP", "WAIT", "FLAG")):
                lvl, rule = rr.split()[0], rr.split()[1].rstrip(":")
                by_rule.setdefault((lvl, rule), []).append(x["name"])
    for lvl in ("STOP", "WAIT", "FLAG"):
        for (lv, rule), ns in sorted(by_rule.items()):
            if lv == lvl:
                more = f" (+{len(ns) - 4} more)" if len(ns) > 4 else ""
                lines.append(f"{lvl} {rule} {len(ns)}: {', '.join(ns[:4])}{more}")
    sug = [s for x in results for s in x["suggestions"]]
    if sug:
        lines.append("spelling suggestions (never applied):")
        lines += [f"  {s}" for s in sug[:6]]
    C.print_screen(f"CHECK-MAP  list={mp.name} {status}  {C.utc_now()}", lines,
                   footer="full table: " + C.rel(outp))
    return C.OK if counts["STOP"] == 0 else C.STOP


# ------------------------------------------------------------------ adopt

def cmd_adopt(args):
    if not args.confirmed_by or not args.confirmed_by.strip():
        print("adopt needs --confirmed-by \"<name, date>\"", file=sys.stderr)
        return C.ARGS
    lst = Path(args.list)
    if not lst.is_file():
        print(f"owner list not found: {lst}", file=sys.stderr)
        return C.ARGS
    import pandas as pd
    owner = pd.read_csv(lst, dtype=str, keep_default_na=False)
    col = next((c for c in ("name", "feature", "model_input") if c in owner.columns), None)
    if col is None:
        print("the owner list needs a column name (or feature)", file=sys.stderr)
        return C.REFUSED
    names = [n.strip() for n in owner[col] if n.strip()]
    dup = sorted({n for n in names if names.count(n) > 1})
    if dup:
        print(f"the owner list names a feature twice: {', '.join(dup)}", file=sys.stderr)
        return C.REFUSED
    mp = Path(args.map) if args.map else C.NF / "FIELD_MAP.csv"
    df = C.read_field_map(mp)
    unknown = sorted(set(names) - set(df["name"]))
    if unknown:
        print("the owner list holds names the map does not: " + ", ".join(unknown) +
              "; add their rows to the map first (exit 4)", file=sys.stderr)
        return C.REFUSED
    sha = C.sha256_file(lst)
    src = f"{lst.name} sha256={sha} confirmed by {args.confirmed_by.strip()}"
    keep = set(names)
    for i, r in df.iterrows():
        if r["name"] in keep:
            df.at[i, "list_status"] = "CONFIRMED"
        else:
            df.at[i, "list_status"] = "NOT_IN_OWNER_LIST"
            note = f"not in the owner's list {lst.name}"
            if note not in r["notes"]:
                df.at[i, "notes"] = (r["notes"] + "; " if r["notes"] else "") + note
        df.at[i, "list_source"] = src
    C.write_field_map(df, mp)
    C.append_jsonl(C.out("intake", "adopt.jsonl"), {"utc": C.utc_now(), "list": lst.name, "sha256": sha,
                                                     "confirmed_by": args.confirmed_by.strip(),
                                                     "confirmed": len(keep), "not_in_list": len(df) - len(keep)})
    blank = int((df.loc[df.list_status == "CONFIRMED", "excluded_by_sumegha"] == "").sum())
    C.print_screen(f"ADOPT  {lst.name}  sha256 {sha[:12]}",
                   [f"CONFIRMED {len(keep)}; NOT_IN_OWNER_LIST {len(df) - len(keep)} (kept in the map with a reason)",
                    f"confirmed by: {args.confirmed_by.strip()}",
                    f"confirmed rows with Sumegha's column blank: {blank}",
                    "next: the field checks again if the list changed, then definitions"],
                   footer="map: " + C.rel(mp))
    return C.OK


# ------------------------------------------------------------------ definitions (2.7)

DEF_COLUMNS = ["name", "definition_version", "kind", "recipe", "source_columns", "window", "lag", "as_of_rule",
               "group_key", "time_key", "censoring_rule", "missing_rule", "model_type", "group", "origin",
               "output_name", "description", "business_category", "date_meaning", "feasible_in_production",
               "excluded_by_sumegha", "list_status", "list_sha256", "check_result"]


def cmd_definitions(args):
    mp = Path(args.map) if args.map else C.NF / "FIELD_MAP.csv"
    df = C.read_field_map(mp)
    status = {}
    fs = C.c2() / "checks" / "field_status.csv"
    if fs.is_file():
        with open(fs, encoding="utf-8") as f:
            status = {r["field"]: r["result"] for r in csv.DictReader(f)}
    rows = []
    for _, r in df.iterrows():
        res = status.get(r["name"], r["check_result"])
        if res not in ("PASS", "FLAG") or r["list_status"] == "NOT_IN_OWNER_LIST":
            continue
        if r["list_status"] != "CONFIRMED" and not args.draft:
            print(f"{r['name']} is {r['list_status']}; adopt the owner's list first, or pass --draft",
                  file=sys.stderr)
            return C.REFUSED
        p = parse_recipe(r["recipe"]) if r["recipe"] else None
        hist = bool(p and is_history(p))
        sha = re.search(r"sha256=([0-9a-f]{64})", r["list_source"] or "")
        rows.append({
            "name": r["name"], "definition_version": r["definition_version"], "kind": r["kind"],
            "recipe": r["recipe"], "source_columns": r["source_columns"], "window": r["window"], "lag": r["lag"],
            "as_of_rule": r["as_of_rule"] or (as_of_rule(p) if p else ""),
            "group_key": "Nmap_account_reference_xid",
            "time_key": "transaction_dttm, whole seconds, strictly earlier" if hist else "transaction_dttm",
            "censoring_rule": "a window reaching before the extract start is missing, never zero" if hist else "",
            "missing_rule": "missing when no earlier row or a missing source; missing never counts" if hist
            else "missing as stored",
            "model_type": r["model_type"], "group": r["group"], "origin": r["origin"],
            "output_name": r["output_name"], "description": r["description"],
            "business_category": r["business_category"], "date_meaning": r["date_meaning"],
            "feasible_in_production": r["feasible_in_production"], "excluded_by_sumegha": r["excluded_by_sumegha"],
            "list_status": r["list_status"], "list_sha256": sha.group(1) if sha else "", "check_result": res})
    outc = C.out("intake", "FEATURE_DEFINITIONS.csv")
    with open(outc, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=DEF_COLUMNS)
        w.writeheader()
        w.writerows(rows)
    C.write_json(C.out("intake", "FEATURE_DEFINITIONS.json"),
                 {"utc": C.utc_now(), "map": mp.name, "map_sha256": C.sha256_file(mp),
                  "embedding_width": 48, "features": rows})
    label = "UNCONFIRMED draft" if args.draft else "CONFIRMED"
    C.print_screen(f"FEATURE DEFINITIONS  {label}", [f"features written {len(rows)} (PASS or FLAG only)",
                                                     "one point-in-time contract per feature (DESIGN.md 2.7)"],
                   footer="files: " + C.rel(outc) + " and .json")
    return C.OK


# ------------------------------------------------------------------ main

def main(argv=None):
    ap = argparse.ArgumentParser(description="field intake")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("schema")
    s.add_argument("--train-base")
    s.add_argument("--val-base")
    s.add_argument("--eval-base")
    s.add_argument("--cred-path")
    d = sub.add_parser("draft")
    d.add_argument("--attributes", help="default NF/DRAFT_FEATURE_ATTRIBUTES_UNCONFIRMED.csv (one row per name)")
    c = sub.add_parser("check-map")
    c.add_argument("--map")
    c.add_argument("--in-place", action="store_true", help="write window, lag, as_of_rule, status_rule and the "
                   "code and date columns back into the map (never list_status)")
    a = sub.add_parser("adopt")
    a.add_argument("--list", required=True)
    a.add_argument("--confirmed-by", required=True)
    a.add_argument("--map")
    f = sub.add_parser("definitions")
    f.add_argument("--map")
    f.add_argument("--draft", action="store_true", help="allow UNCONFIRMED rows, labelled as such")
    args = ap.parse_args(argv)
    fn = {"schema": cmd_schema, "draft": cmd_draft, "check-map": cmd_check_map, "adopt": cmd_adopt,
          "definitions": cmd_definitions}[args.cmd]
    try:
        return fn(args)
    except SystemExit as e:
        return e.code if isinstance(e.code, int) else C.CRASH


if __name__ == "__main__":
    sys.exit(main())
