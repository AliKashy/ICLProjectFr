"""Target-transaction feature attention, read without changing model weights.

This describes feature pooling inside a transaction. It does not measure the
importance of a feature to prediction or the attention paid to history.
"""

from collections.abc import Mapping, Sequence
from math import sqrt

import torch
from torch import nn
from torch.nn import functional as F


CAVEATS = (
    "Attention is not importance; compare it with the permutation ranking.",
    "It describes feature pooling within the target, not attention to history.",
)


def cls_attention(layer: nn.TransformerEncoderLayer, src: torch.Tensor) -> torch.Tensor:
    """Return CLS-to-token probabilities [rows, heads, tokens], including CLS.

    The model's first-stage encoder uses unmasked self-attention. This function
    recomputes only the CLS query and all keys with the layer's actual weights.
    Dropout must be disabled by evaluation mode. No forward state is changed.
    """
    if layer.training or layer.self_attn.training:
        raise ValueError("Attention capture requires evaluation mode")
    attn = layer.self_attn
    if not attn.batch_first or src.ndim != 3:
        raise ValueError("Expected batch-first transaction tokens [rows, tokens, width]")
    if not attn._qkv_same_embed_dim or attn.in_proj_weight is None:
        raise ValueError("Expected the shared Q/K/V projection of the token encoder")
    if attn.bias_k is not None or attn.bias_v is not None or attn.add_zero_attn:
        raise ValueError("Additional attention tokens are not in the feature contract")
    if src.shape[-1] != attn.embed_dim:
        raise ValueError("Token width differs from the token encoder")
    with torch.no_grad():
        z = layer.norm1(src) if layer.norm_first else src
        d, h = attn.embed_dim, attn.num_heads
        bias = attn.in_proj_bias
        q = F.linear(z[:, :1], attn.in_proj_weight[:d], None if bias is None else bias[:d])
        k = F.linear(z, attn.in_proj_weight[d:2*d], None if bias is None else bias[d:2*d])
        q = q.reshape(len(z), 1, h, d // h).transpose(1, 2)
        k = k.reshape(len(z), z.shape[1], h, d // h).transpose(1, 2)
        return ((q / sqrt(d // h)) @ k.transpose(-2, -1)).softmax(-1).squeeze(-2)


def default_feature_groups(token_names: Sequence[str]) -> dict[str, list[str]]:
    """Combine a value token with its corresponding categorical missing flag."""
    names = list(token_names)
    if len(names) != len(set(names)):
        raise ValueError("Token names must be unique and in checkpoint order")
    groups: dict[str, list[str]] = {}
    for name in names:
        parent = name[:-5] if name.endswith("_isna") and name[:-5] in names else name
        groups.setdefault(parent, []).append(name)
    return groups


class AttentionCapture:
    """Collect per-layer attention to the last real slot of selected windows.

    ``token_names`` excludes CLS and follows the checkpoint's continuous then
    categorical order. By default a value and its ``_isna`` token are summed.
    The time-gap token remains a separate entry. Before every model call, pass
    a [windows, slots] boolean ``padding_mask`` to ``set_targets``. True means
    padding. ``target_rows`` optionally selects which scored targets to report,
    for example only June targets. Histories are never added to the averages.

    The caller's plain-versus-captured scoring identity check remains necessary
    on the actual runtime: backend kernels can differ across torch versions.
    """

    def __init__(self, model: nn.Module, token_names: Sequence[str],
                 feature_groups: Mapping[str, Sequence[str]] | None = None):
        self.model = model
        self.token_names = list(token_names)
        if not self.token_names or len(set(self.token_names)) != len(self.token_names):
            raise ValueError("Supply unique feature token names from the checkpoint")
        if feature_groups is None:
            groups = default_feature_groups(self.token_names)
        else:
            groups = {str(name): list(members) for name, members in feature_groups.items()}
        covered = [token for members in groups.values() for token in members]
        if any(not members for members in groups.values()) or sorted(covered) != sorted(self.token_names):
            raise ValueError("Feature groups must partition all feature tokens exactly once")
        self.groups = groups
        candidates = [m for name, m in model.named_modules()
                      if name == "token_encoder" or name.endswith(".token_encoder")]
        if len(candidates) != 1 or not isinstance(candidates[0], nn.TransformerEncoder):
            raise ValueError("Expected one hierarchical token_encoder")
        self.encoder = candidates[0]
        self.layers = list(self.encoder.layers)
        if not self.layers:
            raise ValueError("The token encoder has no layers")
        self._handles = []
        self._flat_targets = None
        self._flat_size = None
        self._sums = [torch.zeros(len(self.token_names) + 1, dtype=torch.float64)
                      for _ in self.layers]
        self._counts = [0 for _ in self.layers]
        self._calls = [0 for _ in self.layers]

    def set_targets(self, padding_mask: torch.Tensor,
                    target_rows: torch.Tensor | None = None) -> None:
        if padding_mask.ndim != 2 or padding_mask.dtype != torch.bool:
            raise ValueError("padding_mask must be boolean [windows, slots], True for padding")
        if padding_mask.shape[1] == 0 or (~padding_mask).sum(1).eq(0).any():
            raise ValueError("Every scored window must have a real target")
        if len(set(self._calls)) != 1:
            raise RuntimeError("The preceding forward did not visit every token layer")
        n, width = padding_mask.shape
        valid = ~padding_mask
        slots = torch.arange(width, device=padding_mask.device).expand(n, -1)
        last = slots.masked_fill(~valid, -1).max(1).values
        indices = torch.arange(n, device=padding_mask.device) * width + last
        if target_rows is not None:
            target_rows = torch.as_tensor(target_rows, device=padding_mask.device)
            if target_rows.shape != (n,) or target_rows.dtype != torch.bool:
                raise ValueError("target_rows must be boolean [windows]")
            indices = indices[target_rows]
        self._flat_targets = indices
        self._flat_size = n * width

    def _capture(self, index, layer, args, kwargs):
        if self._flat_targets is None:
            raise RuntimeError("Call set_targets before every model forward")
        src = args[0] if args else kwargs.get("src")
        if src is None or src.ndim != 3 or src.shape[0] != self._flat_size:
            raise ValueError("Token rows do not match the window shape supplied to set_targets")
        if src.shape[1] != len(self.token_names) + 1:
            raise ValueError("Feature token count differs from checkpoint order")
        src_mask = args[1] if len(args) > 1 else kwargs.get("src_mask")
        key_mask = args[2] if len(args) > 2 else kwargs.get("src_key_padding_mask")
        causal = args[3] if len(args) > 3 else kwargs.get("is_causal", False)
        if src_mask is not None or key_mask is not None or causal:
            raise ValueError("The feature pooling stage must use unmasked attention")
        indices = self._flat_targets.to(src.device)
        if len(indices):
            weights = cls_attention(layer, src.index_select(0, indices))
            self._sums[index] += weights.mean(1).sum(0, dtype=torch.float64).cpu()
            self._counts[index] += len(indices)
        self._calls[index] += 1
        if index == len(self.layers) - 1:
            self._flat_targets = None
            self._flat_size = None

    def __enter__(self):
        if self._handles:
            raise RuntimeError("AttentionCapture is already active")
        if self.model.training or any(layer.training for layer in self.layers):
            raise ValueError("Set the model to evaluation mode before attention capture")
        for index, layer in enumerate(self.layers):
            self._handles.append(layer.register_forward_pre_hook(
                lambda module, args, kwargs, i=index: self._capture(i, module, args, kwargs),
                with_kwargs=True,
            ))
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        for handle in self._handles:
            handle.remove()
        self._handles.clear()

    def result(self) -> dict:
        if not self._counts[0] or len(set(self._counts)) != 1 or len(set(self._calls)) != 1:
            raise ValueError("No complete, selected target observations across all layers")
        means = torch.stack([s / n for s, n in zip(self._sums, self._counts)]).mean(0)
        token_weights = dict(zip(self.token_names, means[1:].tolist()))
        return {
            "features": {name: sum(token_weights[token] for token in members)
                         for name, members in self.groups.items()},
            "cls_self": float(means[0]),
            "target_rows": self._counts[0],
            "layers": len(self.layers),
            "token_attention": token_weights,
            "caveats": list(CAVEATS),
        }
