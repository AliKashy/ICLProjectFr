"""Naming check (owner's rule; design review item 1). Scans every file of the package, every file and folder name,
and the text inside each .xlsx (its XML parts) for the forbidden author names: case-insensitive for the five names,
and case-sensitive whole words for the two two-letter tags. The word list is stored encoded so this file passes its
own scan. Any hit fails (exit 3).

  $PY fraud/experiments/features/new_fields/nf_naming_check.py [paths ...]
  (default: NF, FS, TNF, TFS and the package documents and workbooks at the root; give the unzipped package
  folder to scan every file of the package)
"""
import codecs
import re
import sys
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nf_common as C  # noqa: E402

_NAMES = [codecs.decode(w, "rot13") for w in ("pynhqr", "pungtcg", "pbqrk", "bcranv", "naguebcvp")]
_TAGS = [codecs.decode(w, "rot13") for w in ("PY", "PU")]
NAMES_RE = re.compile("|".join(_NAMES), re.IGNORECASE)
TAGS_RE = re.compile(r"\b(" + "|".join(_TAGS) + r")\b")
SKIP_DIRS = {"__pycache__", ".git", ".pytest_cache"}


def scan_text(text):
    hits = []
    for i, line in enumerate(text.splitlines(), 1):
        if NAMES_RE.search(line) or TAGS_RE.search(line):
            hits.append((i, line.strip()[:120]))
    return hits


def scan_name(name):
    return bool(NAMES_RE.search(name) or TAGS_RE.search(name))


def scan_file(path):
    p = Path(path)
    if p.suffix.lower() in (".xlsx", ".xlsm", ".docx", ".pptx"):
        hits = []
        with zipfile.ZipFile(p) as z:
            for n in z.namelist():
                if n.endswith((".xml", ".rels")):
                    for i, ln in scan_text(z.read(n).decode("utf-8", "replace")):
                        hits.append((f"{n}:{i}", ln))
        return hits
    try:
        text = p.read_bytes().decode("utf-8")
    except UnicodeDecodeError:
        text = p.read_bytes().decode("latin-1")
    return scan_text(text)


def scan(paths):
    hits = []
    for root in paths:
        root = Path(root)
        items = [root] if root.is_file() else sorted(root.rglob("*")) if root.is_dir() else []
        for p in items:
            if any(part in SKIP_DIRS for part in p.parts):
                continue
            if scan_name(p.name):
                hits.append(f"{C.rel(p)}: name")
            if p.is_file():
                for where, line in scan_file(p):
                    hits.append(f"{C.rel(p)}:{where}: {line}")
    return hits


def main(argv=None):
    docs = [C.ROOT / n for n in ("README_FIRST.md", "FEATURES_AND_TESTING.md", "COPILOT_PROMPT.md",
                                 "TEST_RESULTS.md", "DESIGN.md", "changes.diff")]
    default = [str(C.NF), str(C.FS), str(C.TNF), str(C.TFS)] + [str(p) for p in docs if p.is_file()] + \
        [str(p) for p in sorted(C.ROOT.glob("*.xlsx"))]
    paths = (argv if argv is not None else sys.argv[1:]) or default
    hits = scan(paths)
    C.print_screen(f"NAMING CHECK  {'PASS' if not hits else 'FAIL'}  {len(hits)} hit(s)",
                   hits or ["no forbidden name in any file, file name, folder name or workbook text"])
    return C.OK if not hits else C.STOP


if __name__ == "__main__":
    sys.exit(main())
