"""Measurements for the CPU field checks (DESIGN.md 3.2). Pure functions on pandas and numpy.

Nothing here reads files, decides a result or writes output. The checks script
(nf_field_checks.py) feeds one file's rows at a time and pools the counts these
functions return. Every count is a plain number, so per-file partial counts can
be saved as JSON and added up after a restart.

Conventions:
- `values` is a field as it would enter the model: numbers as float (missing is NaN),
  codes as objects (missing is None or NaN).
- `meta` is a frame with columns acct, t (datetime64[ns]), y (0/1, may be absent), month ("YYYY-MM").
- Missing is its own value wherever values are compared ("missing never matches" applies to
  recipes, not to these checks, which describe the column as stored).
"""

from __future__ import annotations

import hashlib
import math
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

MISSING_KEY = "<missing>"


# ---------------------------------------------------------------------------
# Basic helpers
# ---------------------------------------------------------------------------
def is_missing(values) -> np.ndarray:
    return pd.isna(pd.Series(values, copy=False)).to_numpy()


def as_number(values: pd.Series) -> Tuple[pd.Series, int]:
    """A column as a float series, and the count of non-null values that are not numbers.

    Datetime columns become int64 nanoseconds, as a date loaded as a number would be,
    so the scale rule sees them.
    """
    s = pd.Series(values, copy=False)
    if pd.api.types.is_datetime64_any_dtype(s):
        out = pd.Series(s.to_numpy(dtype="datetime64[ns]").astype(np.int64).astype(float), index=s.index)
        out[s.isna().to_numpy()] = np.nan
        return out, 0
    if pd.api.types.is_bool_dtype(s):
        return s.astype(float), 0
    if pd.api.types.is_numeric_dtype(s):
        return s.astype(float), 0
    num = pd.to_numeric(s, errors="coerce")
    fail = int((num.isna() & s.notna()).sum())
    return num.astype(float), fail


def code_keys(values) -> pd.Series:
    """Codes as the text keys the unchanged vocabulary uses (str of the stored value), missing as MISSING_KEY."""
    s = pd.Series(values, copy=False)
    miss = s.isna().to_numpy()
    keys = s.astype(object).map(str)
    keys[miss] = MISSING_KEY
    return keys


def factor_codes(values) -> np.ndarray:
    """Integer codes in order of first appearance, missing as its own code."""
    codes, _ = pd.factorize(pd.Series(values, copy=False), use_na_sentinel=False)
    return codes.astype(np.int64)


def month_of(t) -> pd.Series:
    t = pd.to_datetime(pd.Series(t, copy=False), errors="coerce")
    out = t.dt.strftime("%Y-%m")
    return out.fillna(MISSING_KEY)


# ---------------------------------------------------------------------------
# Missing values: overall, by month, by label
# ---------------------------------------------------------------------------
def missing_counts(values, meta: pd.DataFrame, censored: Optional[np.ndarray] = None) -> Dict:
    """Rows, missing and censored counts overall, by month and by label.

    For an engineered field, a censored value (the window reaches before the extract
    start) is missing in the data but counted apart from other missing values.
    """
    miss = is_missing(values)
    cens = np.zeros(len(miss), dtype=bool) if censored is None else np.asarray(censored, dtype=bool)
    other = miss & ~cens
    out = {"rows": int(len(miss)), "missing": int(other.sum()), "censored": int(cens.sum()),
           "by_month": {}, "by_label": {}}
    months = meta["month"].to_numpy()
    for m in pd.unique(months):
        sel = months == m
        out["by_month"][str(m)] = [int(sel.sum()), int(other[sel].sum()), int(cens[sel].sum())]
    if "y" in meta.columns:
        y = meta["y"].to_numpy()
        for lab, name in ((1, "fraud"), (0, "nonfraud")):
            sel = y == lab
            out["by_label"][name] = [int(sel.sum()), int(other[sel].sum()), int(cens[sel].sum())]
    return out


def add_missing(a: Optional[Dict], b: Dict) -> Dict:
    if not a:
        return {k: (dict(v) if isinstance(v, dict) else v) for k, v in b.items()}
    out = {"rows": a["rows"] + b["rows"], "missing": a["missing"] + b["missing"],
           "censored": a["censored"] + b["censored"], "by_month": dict(a["by_month"]), "by_label": dict(a["by_label"])}
    for key in ("by_month", "by_label"):
        for k, v in b[key].items():
            old = out[key].get(k, [0, 0, 0])
            out[key][k] = [old[0] + v[0], old[1] + v[1], old[2] + v[2]]
    return out


# ---------------------------------------------------------------------------
# Availability at the moment of the transaction
# ---------------------------------------------------------------------------
class FileEvents:
    """Per-file structures shared by every field: rows sorted by account and time, the first
    fraud row of each fraud account, and one pseudo-event row per non-fraud account.

    The pseudo-event is drawn with a fixed seed among rows that have an earlier row of the
    same account. Accounts sit inside one file, so per-file counts pool exactly.
    """

    def __init__(self, meta: pd.DataFrame, seed: int = 0, after_days: float = 30.0, reissue_days: float = 30.0):
        n = len(meta)
        acct = meta["acct"].astype(str).to_numpy()
        t = pd.to_datetime(meta["t"]).to_numpy(dtype="datetime64[ns]").astype(np.int64)
        y = meta["y"].to_numpy().astype(int) if "y" in meta.columns else np.zeros(n, dtype=int)
        order = np.lexsort((np.arange(n), t, acct))
        self.order = order
        a_sorted = acct[order]
        self.ac, _ = pd.factorize(a_sorted)
        self.ac = self.ac.astype(np.int64)
        self.t = t[order]
        self.y = y[order]
        n_acct = int(self.ac.max()) + 1 if n else 0
        self.n_acct = n_acct
        start = np.r_[0, np.flatnonzero(np.diff(self.ac)) + 1] if n else np.array([], dtype=np.int64)
        self.pos = np.arange(n) - np.repeat(start, np.diff(np.r_[start, n])) if n else np.array([], dtype=np.int64)
        self.size = np.bincount(self.ac, minlength=n_acct) if n else np.array([], dtype=np.int64)
        # first fraud row per account (sorted positions)
        big = np.iinfo(np.int64).max
        first = np.full(n_acct, big, dtype=np.int64)
        fr = np.flatnonzero(self.y == 1)
        if len(fr):
            np.minimum.at(first, self.ac[fr], fr)
        self.fraud_acct = first < big
        self.event = np.where(self.fraud_acct, first, -1)
        # pseudo-event rows in accounts with no fraud: a row with an earlier row
        rng = np.random.default_rng(seed)
        self.pseudo = np.full(n_acct, -1, dtype=np.int64)
        cand = np.flatnonzero((self.pos >= 1) & ~self.fraud_acct[self.ac]) if n else np.array([], dtype=np.int64)
        if len(cand):
            keys = rng.random(len(cand))
            # pick the candidate with the smallest random key in each account
            o = np.lexsort((keys, self.ac[cand]))
            c_sorted = cand[o]
            a_c = self.ac[c_sorted]
            firsts = np.r_[True, a_c[1:] != a_c[:-1]]
            self.pseudo[a_c[firsts]] = c_sorted[firsts]
        self.after_ns = int(after_days * 86400 * 1_000_000_000)
        self.reissue_ns = int(reissue_days * 86400 * 1_000_000_000)
        self.day = self.t // (86400 * 1_000_000_000)
        # first sorted position of each (account, day), for the same-day refresh rule
        if n:
            newday = np.r_[True, (self.ac[1:] != self.ac[:-1]) | (self.day[1:] != self.day[:-1])]
            self.day_start = np.maximum.accumulate(np.where(newday, np.arange(n), 0))
        else:
            self.day_start = np.array([], dtype=np.int64)

    def sorted_values(self, values) -> pd.Series:
        return pd.Series(values, copy=False).iloc[self.order].reset_index(drop=True)

    def _side(self, ev: np.ndarray):
        """Masks for rows of accounts with an event: before it, at or after it."""
        e_row = ev[self.ac]
        has = e_row >= 0
        idx = np.arange(len(self.ac))
        before = has & (idx < e_row)
        after = has & (idx >= e_row)
        return has, before, after, e_row

    def stats(self, values, keys: Optional[pd.Series] = None, change_values=None) -> Dict:
        """Counts for the availability rules, pooled over files later.

        values: the field as it enters the model (fill shares).
        change_values: the values whose changes count (default: values; for a date recipe, the
        source date, since a days-before value moves with time on every row).
        keys: bin keys of the values; when given, value counts on rows before the event
        (pre-event proxy test) are returned too.
        """
        v = self.sorted_values(values)
        nonmiss = v.notna().to_numpy()
        codes = factor_codes(v if change_values is None else self.sorted_values(change_values))
        n = len(codes)
        out: Dict = {}
        idx = np.arange(n)
        for name, ev in (("f", self.event), ("p", self.pseudo)):
            has, before, after, e_row = self._side(ev)
            out[f"{name}_before_n"] = int(before.sum())
            out[f"{name}_before_fill"] = int((nonmiss & before).sum())
            out[f"{name}_after_n"] = int(after.sum())
            out[f"{name}_after_fill"] = int((nonmiss & after).sum())
            # change at the event row against the account's previous row
            rows = ev[ev >= 0]
            rows = rows[self.pos[rows] >= 1] if len(rows) else rows
            out[f"{name}_at_n"] = int(len(rows))
            out[f"{name}_at_changed"] = int((codes[rows] != codes[rows - 1]).sum()) if len(rows) else 0
            for k in ("after_acc_n", "after_acc_changed", "refresh_n", "refresh_changed", "reissue_n",
                      "reissue_changed"):
                out[f"{name}_{k}"] = 0
            if not n:
                continue
            safe = np.where(e_row >= 0, e_row, 0)
            # change within the window after the event
            win = has & (idx > e_row) & (self.t <= self.t[safe] + self.after_ns)
            acc_win = np.bincount(self.ac[win], minlength=self.n_acct)
            acc_diff = np.bincount(self.ac[win & (codes != codes[safe])], minlength=self.n_acct)
            out[f"{name}_after_acc_n"] = int((acc_win > 0).sum())
            out[f"{name}_after_acc_changed"] = int((acc_diff > 0).sum())
            # same-day refresh: rows earlier on the event day than the event row already differ from
            # the previous day's last row (a profile value refreshed by day, after the event)
            s0 = self.day_start[safe]
            prev_last = s0 - 1
            valid_prev = (prev_last >= 0) & (self.ac[np.maximum(prev_last, 0)] == self.ac)
            early = has & (self.day == self.day[safe]) & (idx < e_row) & valid_prev
            acc_early = np.bincount(self.ac[early], minlength=self.n_acct)
            ch = early & (codes != codes[np.maximum(prev_last, 0)])
            acc_ch = np.bincount(self.ac[ch], minlength=self.n_acct)
            out[f"{name}_refresh_n"] = int((acc_early > 0).sum())
            out[f"{name}_refresh_changed"] = int((acc_ch > 0).sum())
            # reissue: constant before the event, then a change at or within the window after it
            last_before = np.maximum(safe - 1, 0)
            first_row = idx - self.pos
            b_diff = np.bincount(self.ac[before & (codes != codes[first_row])], minlength=self.n_acct)
            n_before = np.bincount(self.ac[before], minlength=self.n_acct)
            at_win = has & (idx >= e_row) & (self.t <= self.t[safe] + self.reissue_ns)
            n_atwin = np.bincount(self.ac[at_win], minlength=self.n_acct)
            r_ch = np.bincount(self.ac[at_win & (codes != codes[last_before]) & (self.pos[safe] >= 1)],
                               minlength=self.n_acct)
            elig = (n_before > 0) & (n_atwin > 0) & (b_diff == 0)
            out[f"{name}_reissue_n"] = int(((n_before > 0) & (n_atwin > 0)).sum())
            out[f"{name}_reissue_changed"] = int((elig & (r_ch > 0)).sum())
        if keys is not None and n:
            ks = keys.iloc[self.order].reset_index(drop=True)
            _, bf, _, _ = self._side(self.event)
            _, bp, _, _ = self._side(self.pseudo)
            # two halves of the accounts: rates fit on one half are scored on the other, so a value
            # that is constant within an account cannot memorise which accounts turn fraud
            half = (self.ac % 2).astype(bool)
            for nm, hm in (("pre_counts_a", ~half), ("pre_counts_b", half)):
                sel = (bf | bp) & hm
                out[nm] = value_label_counts(ks[sel].reset_index(drop=True), bf[sel].astype(int))
            fa = np.bincount(self.ac, weights=bf.astype(float), minlength=self.n_acct) > 0
            pa = np.bincount(self.ac, weights=bp.astype(float), minlength=self.n_acct) > 0
            nonm_acc = np.bincount(self.ac, weights=(nonmiss & (bf | bp)).astype(float), minlength=self.n_acct) > 0
            out["pre_acc_f"], out["pre_acc_f_fill"] = int(fa.sum()), int((fa & nonm_acc).sum())
            out["pre_acc_p"], out["pre_acc_p_fill"] = int(pa.sum()), int((pa & nonm_acc).sum())
        # constant within the account (accounts with two or more rows)
        if n:
            multi = self.size >= 2
            first_code = np.zeros(self.n_acct, dtype=np.int64)
            starts = np.flatnonzero(self.pos == 0)
            first_code[self.ac[starts]] = codes[starts]
            differs = np.bincount(self.ac, weights=(codes != first_code[self.ac]).astype(float), minlength=self.n_acct)
            out["acc_multi"] = int(multi.sum())
            out["acc_constant"] = int((multi & (differs == 0)).sum())
        else:
            out["acc_multi"] = 0
            out["acc_constant"] = 0
        return out


def add_counts(a: Optional[Dict], b: Dict) -> Dict:
    """Adds numeric counts; value-count tables (dicts) are pooled with add_value_label."""
    out = dict(a or {})
    for k, v in b.items():
        if isinstance(v, dict):
            out[k] = add_value_label(out.get(k), v)
        else:
            out[k] = out.get(k, 0) + v
    return out


def share(num, den) -> float:
    return float(num) / float(den) if den else float("nan")


def event_measures(c: Dict) -> Dict:
    """Shares and excesses (in points, 0-100) from pooled event counts."""
    def jump(p):
        return 100.0 * (share(c.get(f"{p}_after_fill", 0), c.get(f"{p}_after_n", 0))
                        - share(c.get(f"{p}_before_fill", 0), c.get(f"{p}_before_n", 0)))
    jf, jp = jump("f"), jump("p")
    at_f = 100.0 * share(c.get("f_at_changed", 0), c.get("f_at_n", 0))
    at_p = 100.0 * share(c.get("p_at_changed", 0), c.get("p_at_n", 0))
    af = 100.0 * share(c.get("f_after_acc_changed", 0), c.get("f_after_acc_n", 0))
    ap = 100.0 * share(c.get("p_after_acc_changed", 0), c.get("p_after_acc_n", 0))
    return {
        "fill_jump_fraud": jf, "fill_jump_pseudo": jp, "fill_jump_excess": jf - jp,
        "change_at_event": at_f, "change_at_pseudo": at_p,
        "change_after_event": af, "change_after_pseudo": ap,
        "constant_in_account": 100.0 * share(c.get("acc_constant", 0), c.get("acc_multi", 0)),
        "refresh_event": 100.0 * share(c.get("f_refresh_changed", 0), c.get("f_refresh_n", 0)),
        "refresh_pseudo": 100.0 * share(c.get("p_refresh_changed", 0), c.get("p_refresh_n", 0)),
        "reissue_event": 100.0 * share(c.get("f_reissue_changed", 0), c.get("f_reissue_n", 0)),
        "reissue_pseudo": 100.0 * share(c.get("p_reissue_changed", 0), c.get("p_reissue_n", 0)),
        # accounts (not rows) with the field filled before the event: fraud accounts against matched
        # non-fraud accounts before their pseudo-event
        "pre_fill_fraud": share(c.get("pre_acc_f_fill", 0), c.get("pre_acc_f", 0)),
        "pre_fill_pseudo": share(c.get("pre_acc_p_fill", 0), c.get("pre_acc_p", 0)),
        "pre_fraud_accounts": int(c.get("pre_acc_f", 0)),
        "fraud_accounts_with_history": int(c.get("f_at_n", 0)),
    }


def date_after_counts(days_before, y: Optional[np.ndarray]) -> Dict:
    """Own date later than the transaction: a days-before value below zero."""
    d = pd.to_numeric(pd.Series(days_before, copy=False), errors="coerce").to_numpy(dtype=float)
    ok = np.isfinite(d)
    after = ok & (d < 0)
    out = {"date_nonnull": int(ok.sum()), "date_after": int(after.sum())}
    if y is not None:
        yy = np.asarray(y).astype(int)
        for lab, name in ((1, "fraud"), (0, "nonfraud")):
            sel = yy == lab
            out[f"date_nonnull_{name}"] = int((ok & sel).sum())
            out[f"date_after_{name}"] = int((after & sel).sum())
    return out


def parse_dates(values) -> pd.Series:
    """A date source as datetime64[ns]: datetime columns as stored; yyyymmdd numbers; epoch
    milliseconds or seconds; text through pandas. Unparseable values become NaT."""
    s = pd.Series(values, copy=False)
    if pd.api.types.is_datetime64_any_dtype(s):
        return pd.to_datetime(s)
    num = pd.to_numeric(s, errors="coerce")
    if num.notna().sum() and num.notna().sum() >= 0.99 * s.notna().sum():
        v = num.dropna()
        if v.between(19000101, 21001231).all() and (v == v.round()).all():
            return pd.to_datetime(num.astype("Int64").astype(str), format="%Y%m%d", errors="coerce")
        if (v.abs() > 1e11).all():
            return pd.to_datetime(num, unit="ms", errors="coerce")
        return pd.to_datetime(num, unit="s", errors="coerce")
    text = s.astype(object).where(s.notna(), None)
    try:
        return pd.to_datetime(text, errors="coerce", format="mixed")
    except (TypeError, ValueError):  # an older pandas without format="mixed"
        return pd.to_datetime(text, errors="coerce")


def same_day_counts(src, meta: pd.DataFrame, ev: "FileEvents") -> Dict:
    """Rows whose source date falls on the transaction's calendar day: frauds against non-frauds,
    and first-fraud rows against pseudo-event rows."""
    d = parse_dates(src)
    t = pd.to_datetime(meta["t"])
    ok = d.notna().to_numpy()
    # only date-only values (no time part): a timed value earlier the same day is strictly earlier and is
    # judged by the days-before value itself (review item 6 concerns dates with no time part)
    date_only = ok & (d.to_numpy() == d.dt.normalize().to_numpy())
    same = date_only & (d.dt.normalize().to_numpy() == t.dt.normalize().to_numpy())
    y = meta["y"].to_numpy().astype(int) if "y" in meta.columns else np.zeros(len(t), dtype=int)
    out = {"sd_fraud_n": int((ok & (y == 1)).sum()), "sd_fraud": int((same & (y == 1)).sum()),
           "sd_nonfraud_n": int((ok & (y == 0)).sum()), "sd_nonfraud": int((same & (y == 0)).sum())}
    same_s = same[ev.order]
    ok_s = ok[ev.order]
    for name, e in (("f", ev.event), ("p", ev.pseudo)):
        rows = e[e >= 0]
        out[f"sd_{name}_event_n"] = int(ok_s[rows].sum()) if len(rows) else 0
        out[f"sd_{name}_event"] = int(same_s[rows].sum()) if len(rows) else 0
    return out


# ---------------------------------------------------------------------------
# Numbers: sums for mean and sd, calendar shape, a sample for the time correlation
# ---------------------------------------------------------------------------
def number_counts(num: pd.Series) -> Dict:
    v = num.to_numpy(dtype=float)
    f = np.isfinite(v)
    vf = v[f]
    out = {"n_num": int(f.sum()), "sum": float(vf.sum()) if len(vf) else 0.0,
           "sumsq": float(np.square(vf).sum()) if len(vf) else 0.0,
           "min": float(vf.min()) if len(vf) else None, "max": float(vf.max()) if len(vf) else None,
           "n_nonint": int((vf != np.round(vf)).sum()) if len(vf) else 0}
    ints = np.unique(vf[(vf == np.round(vf))])[:64] if len(vf) else np.array([])
    out["small_ints"] = [float(x) for x in ints] if len(ints) < 64 else None
    return out


def add_number(a: Optional[Dict], b: Dict) -> Dict:
    if not a:
        return dict(b)
    out = dict(a)
    out["n_num"] += b["n_num"]
    out["sum"] += b["sum"]
    out["sumsq"] += b["sumsq"]
    out["n_nonint"] += b["n_nonint"]
    for k, f in (("min", min), ("max", max)):
        vals = [x for x in (a[k], b[k]) if x is not None]
        out[k] = f(vals) if vals else None
    if a.get("small_ints") is None or b.get("small_ints") is None:
        out["small_ints"] = None
    else:
        u = sorted(set(a["small_ints"]) | set(b["small_ints"]))
        out["small_ints"] = u if len(u) < 64 else None
    return out


def mean_sd(c: Dict) -> Tuple[float, float]:
    n = c.get("n_num", 0)
    if not n:
        return float("nan"), float("nan")
    m = c["sum"] / n
    var = max(c["sumsq"] / n - m * m, 0.0)
    return m, math.sqrt(var)


def calendar_shape(c: Dict, min_distinct: int, ranges: Optional[Dict[str, Tuple[float, float]]] = None) -> Optional[str]:
    """'month', 'yyyymm' or 'yyyymmdd' when every non-null value is an integer in that range (a month
    code also needs `min_distinct` distinct values)."""
    if not c or not c.get("n_num") or c.get("n_nonint", 1) or c.get("min") is None:
        return None
    r = ranges or {"month": (1, 12), "yyyymm": (190001, 210012), "yyyymmdd": (19000101, 21001231)}
    lo, hi = c["min"], c["max"]
    ints = c.get("small_ints")
    m = r.get("month", (1, 12))
    if lo >= m[0] and hi <= m[1] and ints is not None and len(ints) >= min_distinct:
        return "month"
    for name in ("yyyymm", "yyyymmdd"):
        a, b = r.get(name, (None, None))
        if a is not None and lo >= a and hi <= b:
            return name
    return None


def time_sample(t: pd.Series, num: pd.Series, size: int, seed: int) -> Tuple[np.ndarray, np.ndarray]:
    """A fixed-seed sample of (time as int64 ns, value) over rows where the value is a number."""
    v = num.to_numpy(dtype=float)
    tt = pd.to_datetime(t).to_numpy(dtype="datetime64[ns]").astype(np.int64)
    ok = np.flatnonzero(np.isfinite(v))
    if len(ok) > size:
        ok = np.sort(np.random.default_rng(seed).choice(ok, size=size, replace=False))
    return tt[ok], v[ok]


def spearman(a: np.ndarray, b: np.ndarray) -> float:
    if len(a) < 3:
        return float("nan")
    ra = pd.Series(a).rank().to_numpy()
    rb = pd.Series(b).rank().to_numpy()
    if ra.std() == 0 or rb.std() == 0:
        return float("nan")
    return float(np.corrcoef(ra, rb)[0, 1])


# ---------------------------------------------------------------------------
# Bins for month overlap and drift
# ---------------------------------------------------------------------------
def decile_edges(num: pd.Series, bins: int = 10) -> List[float]:
    v = num.to_numpy(dtype=float)
    v = v[np.isfinite(v)]
    if not len(v):
        return []
    return [float(x) for x in np.unique(np.quantile(v, np.linspace(0, 1, int(bins) + 1)[1:-1]))]


def conditional_entropy(a: np.ndarray, b: np.ndarray) -> float:
    """H(A | B) in nats from two code arrays."""
    a = np.asarray(a, dtype=np.int64)
    b = np.asarray(b, dtype=np.int64)
    if not len(a):
        return float("nan")
    _, ib = np.unique(b, return_inverse=True)
    _, ia = np.unique(a, return_inverse=True)
    pair = ib.astype(np.int64) * (int(ia.max()) + 1) + ia
    up, cnt = np.unique(pair, return_counts=True)
    nb = np.bincount(ib).astype(float)
    p_ab = cnt / len(a)
    p_b = nb[up // (int(ia.max()) + 1)] / len(a)
    return float(-np.sum(p_ab * np.log(p_ab / p_b)))


def bin_keys(values, model_type: str, edges: Optional[List[float]]) -> pd.Series:
    """Values as they enter the model, as bin keys: codes by value, numbers by training decile,
    missing as its own bin."""
    if model_type == "continuous":
        num, _ = as_number(values)
        v = num.to_numpy(dtype=float)
        f = np.isfinite(v)
        b = np.searchsorted(np.asarray(edges or [], dtype=float), v, side="right")
        keys = pd.Series(np.char.add("d", b.astype(str)), index=num.index).astype(object)
        keys[~f] = MISSING_KEY
        return keys
    return code_keys(values)


def contingency(keys: pd.Series, months: pd.Series, cap: int):
    """{bin: {month: count}}, or the text "over" when there are more than `cap` bins."""
    ct = pd.crosstab(keys.to_numpy(), months.to_numpy())
    if ct.shape[0] > cap:
        return "over"
    return {str(r): {str(c): int(x) for c, x in row.items() if x} for r, row in ct.iterrows()}


def add_contingency(a, b, cap: int):
    """Pool two tables; "over" stays "over"; None is the empty start."""
    if a is None:
        return b
    if b is None:
        return a
    if a == "over" or b == "over":
        return "over"
    out = {k: dict(v) for k, v in a.items()}
    for r, row in b.items():
        d = out.setdefault(r, {})
        for c, x in row.items():
            d[c] = d.get(c, 0) + x
    return "over" if len(out) > cap else out


def overlap_measures(table: Dict[str, Dict[str, int]]) -> Dict[str, float]:
    """NMI = I(X;M) / sqrt(H(X) H(M)) and Cramer's V = sqrt(chi2 / (n (min(r, c) - 1)))."""
    rows = sorted(table)
    cols = sorted({c for r in rows for c in table[r]})
    if not rows or not cols:
        return {"nmi": float("nan"), "cramers_v": float("nan"), "n": 0}
    m = np.array([[table[r].get(c, 0) for c in cols] for r in rows], dtype=float)
    return overlap_from_matrix(m)


def overlap_from_matrix(m: np.ndarray) -> Dict[str, float]:
    m = m[m.sum(axis=1) > 0][:, m.sum(axis=0) > 0] if m.size else m
    n = m.sum()
    if n == 0 or m.shape[0] < 2 or m.shape[1] < 2:
        return {"nmi": 0.0, "cramers_v": 0.0, "n": int(n)}
    p = m / n
    px, pm = p.sum(axis=1), p.sum(axis=0)
    nz = p > 0
    mi = float(np.sum(p[nz] * np.log(p[nz] / np.outer(px, pm)[nz])))
    hx = float(-np.sum(px[px > 0] * np.log(px[px > 0])))
    hm = float(-np.sum(pm[pm > 0] * np.log(pm[pm > 0])))
    nmi = mi / math.sqrt(hx * hm) if hx > 0 and hm > 0 else 0.0
    exp = np.outer(m.sum(axis=1), m.sum(axis=0)) / n
    chi2 = float(np.sum((m - exp) ** 2 / exp))
    v = math.sqrt(chi2 / (n * (min(m.shape) - 1)))
    return {"nmi": max(0.0, min(1.0, nmi)), "cramers_v": min(1.0, v), "n": int(n)}


def overlap_adjusted(table: Dict[str, Dict[str, int]]) -> Dict[str, float]:
    """Cramer's V and NMI with the chance part removed (the reviewers' decision D3d), for the present-values table:
    under independence E[chi2] = (r - 1)(c - 1) and E[I] is about (r - 1)(c - 1) / (2 n) nats, so
    V_adj = sqrt(max(0, chi2 - (r - 1)(c - 1)) / (n (min(r, c) - 1))) and
    NMI_adj = max(0, I - (r - 1)(c - 1) / (2 n)) / sqrt(H(X) H(M))."""
    rows = sorted(table or {})
    cols = sorted({c for r in rows for c in table[r]})
    if not rows or not cols:
        return {"v_adj": float("nan"), "nmi_adj": float("nan"), "n": 0}
    m = np.array([[table[r].get(c, 0) for c in cols] for r in rows], dtype=float)
    m = m[m.sum(axis=1) > 0][:, m.sum(axis=0) > 0]
    n = m.sum()
    if n == 0 or m.shape[0] < 2 or m.shape[1] < 2:
        return {"v_adj": 0.0, "nmi_adj": 0.0, "n": int(n)}
    r, c = m.shape
    exp = np.outer(m.sum(axis=1), m.sum(axis=0)) / n
    chi2 = float(np.sum((m - exp) ** 2 / exp))
    p = m / n
    px, pm = p.sum(axis=1), p.sum(axis=0)
    nz = p > 0
    mi = float(np.sum(p[nz] * np.log(p[nz] / np.outer(px, pm)[nz])))
    hx = float(-np.sum(px[px > 0] * np.log(px[px > 0])))
    hm = float(-np.sum(pm[pm > 0] * np.log(pm[pm > 0])))
    df = (r - 1) * (c - 1)
    v_adj = math.sqrt(max(0.0, chi2 - df) / (n * (min(r, c) - 1)))
    nmi_adj = max(0.0, mi - df / (2 * n)) / math.sqrt(hx * hm) if hx > 0 and hm > 0 else 0.0
    return {"v_adj": min(1.0, v_adj), "nmi_adj": max(0.0, min(1.0, nmi_adj)), "n": int(n)}


def clock_ceiling(month_shares: List[float], bins: int) -> Dict[str, float]:
    """The largest Cramer's V and NMI a pure clock reaches in the month table, in closed form (the reviewers'
    decision D3d): bin i holds the time quantiles [i/B, (i+1)/B), month j its share of the rows, and the joint
    table is the overlap of the two partitions of [0, 1]. 8 equal months and 10 bins give V 0.845154."""
    shares = [float(x) for x in month_shares if x and x > 0]
    total = sum(shares)
    if not shares or bins < 2 or total <= 0:
        return {"v": float("nan"), "nmi": float("nan")}
    shares = [x / total for x in shares]
    eb = [i / bins for i in range(bins + 1)]
    em = [0.0]
    for x in shares:
        em.append(em[-1] + x)
    em[-1] = 1.0
    p = np.array([[max(0.0, min(eb[i + 1], em[j + 1]) - max(eb[i], em[j])) for j in range(len(shares))]
                  for i in range(bins)])
    pi, pj = p.sum(axis=1), p.sum(axis=0)
    nz = p > 0
    chi2n = float(np.sum(p[nz] ** 2 / np.outer(pi, pj)[nz])) - 1
    v = math.sqrt(chi2n / (min(p.shape) - 1)) if min(p.shape) > 1 else float("nan")
    mi = float(np.sum(p[nz] * np.log(p[nz] / np.outer(pi, pj)[nz])))
    hx = float(-np.sum(pi[pi > 0] * np.log(pi[pi > 0])))
    hm = float(-np.sum(pj[pj > 0] * np.log(pj[pj > 0])))
    return {"v": v, "nmi": mi / math.sqrt(hx * hm) if hx > 0 and hm > 0 else float("nan")}


def reason_counts(reasons, y: Optional[np.ndarray]) -> Dict[str, List[int]]:
    """{reason: [fraud rows, non-fraud rows]} for a date field's per-row reason codes, with "__rows__" holding
    the rows of each label (the reviewers' decision D3b)."""
    r = np.asarray(reasons, dtype=object)
    yy = np.zeros(len(r), dtype=int) if y is None else np.asarray(y).astype(int)
    out = {"__rows__": [int((yy == 1).sum()), int((yy == 0).sum())]}
    for code in sorted({x for x in r if x}):
        sel = r == code
        out[str(code)] = [int((sel & (yy == 1)).sum()), int((sel & (yy == 0)).sum())]
    return out


def add_reason_counts(a: Optional[Dict], b: Dict) -> Dict:
    out = {k: list(v) for k, v in (a or {}).items()}
    for k, v in b.items():
        cur = out.setdefault(k, [0, 0])
        out[k] = [cur[0] + v[0], cur[1] + v[1]]
    return out


def top_days(day: np.ndarray, keep: int = 50) -> Dict[str, int]:
    """The most frequent dates of a date field (day numbers since 1970 as text) with their counts; "__n__" holds
    the rows with a date."""
    d = np.asarray(day, dtype=np.int64)
    d = d[d >= 0]
    out = {"__n__": int(len(d))}
    if len(d):
        vals, counts = np.unique(d, return_counts=True)
        order = np.argsort(-counts, kind="stable")[:keep]
        out.update({str(int(vals[i])): int(counts[i]) for i in order})
    return out


def add_top_days(a: Optional[Dict], b: Dict, keep: int = 200) -> Dict:
    out = dict(a or {})
    for k, v in b.items():
        out[k] = out.get(k, 0) + v
    n = out.pop("__n__", 0)
    kept = dict(sorted(out.items(), key=lambda kv: -kv[1])[:keep])
    kept["__n__"] = n
    return kept


def hour_histogram(signed_days, timed) -> Dict[str, int]:
    """(t - d) in whole hours within 24 hours either side, for dates with a time of day: a fixed zone offset shows
    as a peak away from zero (the reviewers' decision D3b)."""
    sd = np.asarray(signed_days, dtype=float)
    ok = np.asarray(timed, dtype=bool) & np.isfinite(sd) & (np.abs(sd) <= 1.0)
    h = np.floor(sd[ok] * 24).astype(int)
    vals, counts = np.unique(h, return_counts=True)
    return {str(int(v)): int(c) for v, c in zip(vals, counts)}


def account_folds(accounts) -> np.ndarray:
    """Two folds by account: even and odd account id when the ids are whole numbers, else a stable hash of the
    text (the reviewers' decision D3d)."""
    a = pd.Series(accounts, copy=False).astype(str)
    num = pd.to_numeric(a, errors="coerce")
    if num.notna().all() and (num == np.floor(num)).all():
        return (num.to_numpy(dtype=np.int64) % 2).astype(int)
    return (pd.util.hash_pandas_object(a, index=False).to_numpy() % 2).astype(int)


def joint_time_fit(X: np.ndarray, t_days: np.ndarray, fold: np.ndarray, names: List[str]) -> Dict:
    """Ordinary least squares of transaction time (days) on the fields together (the reviewers' decision D3d):
    each field median-imputed with its missing flag when it has missing values, all z-scored; fitted on one fold
    of accounts and scored on the other, both ways. Returns the out-of-fold Spearman rho, R^2 and the ten largest
    standardized coefficients of the fit on all rows."""
    t = np.asarray(t_days, dtype=float)
    cols, labels = [], []
    for j, name in enumerate(names):
        x = np.asarray(X[:, j], dtype=float)
        miss = ~np.isfinite(x)
        if miss.all():
            continue
        cols.append(np.where(miss, np.nanmedian(np.where(miss, np.nan, x)), x))
        labels.append(name)
        if miss.any():
            cols.append(miss.astype(float))
            labels.append(f"{name}_isna")
    if not cols or len(t) < 4:
        return {"rho": float("nan"), "r2": float("nan"), "rows": int(len(t)), "fields": list(names), "top": []}
    Z = np.column_stack(cols)
    sd = Z.std(axis=0)
    keep = sd > 0
    Z = (Z[:, keep] - Z[:, keep].mean(axis=0)) / sd[keep]
    labels = [lab for lab, k in zip(labels, keep) if k]
    X1 = np.column_stack([np.ones(len(t)), Z])
    fit = np.full(len(t), np.nan)
    for f in (0, 1):
        tr, te = fold != f, fold == f
        if tr.sum() < 2 or te.sum() == 0:
            continue
        beta, *_ = np.linalg.lstsq(X1[tr], t[tr], rcond=None)
        fit[te] = X1[te] @ beta
    ok = np.isfinite(fit)
    rho = spearman(fit[ok], t[ok])
    r2 = float(1 - np.sum((t[ok] - fit[ok]) ** 2) / np.sum((t[ok] - t[ok].mean()) ** 2)) if ok.sum() > 1 else float("nan")
    beta, *_ = np.linalg.lstsq(X1, t, rcond=None)
    st = beta[1:] / (t.std() if t.std() > 0 else 1.0)
    order = np.argsort(-np.abs(st))[:10]
    return {"rho": rho, "r2": r2, "rows": int(len(t)), "fields": list(names),
            "top": [{"input": labels[i], "coefficient": float(st[i])} for i in order]}


def psi_counts(ref: Dict[str, int], other: Dict[str, int], eps: float = 1e-6) -> float:
    """PSI of `other` against `ref` over the reference bins plus one bin for unseen keys
    (missing is its own bin). Same formula as the screen's stability.psi."""
    keys = sorted(ref)
    r = np.array([ref[k] for k in keys] + [0], dtype=float)
    o = np.array([other.get(k, 0) for k in keys] + [sum(v for k, v in other.items() if k not in ref)], dtype=float)
    if r.sum() == 0 or o.sum() == 0:
        return float("nan")
    pr, po = r / r.sum() + eps, o / o.sum() + eps
    return float(np.sum((po - pr) * np.log(po / pr)))


# ---------------------------------------------------------------------------
# Single-field AP (exact, from grouped counts; ties count as one threshold, as scikit-learn)
# ---------------------------------------------------------------------------
def ap_from_groups(scores: np.ndarray, n: np.ndarray, pos: np.ndarray) -> float:
    scores = np.asarray(scores, dtype=float)
    n = np.asarray(n, dtype=float)
    pos = np.asarray(pos, dtype=float)
    total_pos = pos.sum()
    if total_pos == 0 or n.sum() == 0:
        return float("nan")
    u, inv = np.unique(-scores, return_inverse=True)  # ascending -score = descending score
    gn = np.bincount(inv, weights=n, minlength=len(u))
    gp = np.bincount(inv, weights=pos, minlength=len(u))
    ctp = np.cumsum(gp)
    cn = np.cumsum(gn)
    prec = np.divide(ctp, cn, out=np.zeros_like(ctp), where=cn > 0)
    return float(np.sum(gp / total_pos * prec))


def value_label_counts(keys: pd.Series, y: np.ndarray) -> Dict[str, List[int]]:
    """{key: [rows, frauds]}."""
    df = pd.DataFrame({"k": keys.to_numpy(), "y": np.asarray(y).astype(int)})
    g = df.groupby("k", sort=False)["y"].agg(["size", "sum"])
    return {str(k): [int(r["size"]), int(r["sum"])] for k, r in g.iterrows()}


def add_value_label(a, b):
    if not a:
        return {k: list(v) for k, v in b.items()}
    out = {k: list(v) for k, v in a.items()}
    for k, v in b.items():
        o = out.setdefault(k, [0, 0])
        o[0] += v[0]
        o[1] += v[1]
    return out


def number_ap(val_counts: Dict[str, List[int]]) -> float:
    """Numbers: the better of the value and its negative, missing placed first or last."""
    keys = [k for k in val_counts if k != MISSING_KEY]
    v = np.array([float(k) for k in keys], dtype=float)
    n = np.array([val_counts[k][0] for k in keys], dtype=float)
    p = np.array([val_counts[k][1] for k in keys], dtype=float)
    mn, mp = val_counts.get(MISSING_KEY, [0, 0])
    best = float("nan")
    for sign in (1.0, -1.0):
        for miss_score in (np.inf, -np.inf):
            s = np.r_[sign * v, miss_score] if mn else sign * v
            nn = np.r_[n, mn] if mn else n
            pp = np.r_[p, mp] if mn else p
            if not len(s):
                continue
            a = ap_from_groups(s, nn, pp)
            if not np.isnan(a) and (np.isnan(best) or a > best):
                best = a
    return best


def code_ap(train_counts: Dict[str, List[int]], val_counts: Dict[str, List[int]], weight: float = 100.0) -> float:
    """Codes: the training fraud rate per value, smoothed toward the overall rate with `weight`;
    unseen values get the overall rate. Missing is its own value."""
    tn = sum(v[0] for v in train_counts.values())
    tp = sum(v[1] for v in train_counts.values())
    if tn == 0:
        return float("nan")
    base = tp / tn
    keys = list(val_counts)
    s = np.array([(train_counts[k][1] + weight * base) / (train_counts[k][0] + weight) if k in train_counts else base
                  for k in keys], dtype=float)
    n = np.array([val_counts[k][0] for k in keys], dtype=float)
    p = np.array([val_counts[k][1] for k in keys], dtype=float)
    return ap_from_groups(s, n, p)


def fine_bin_keys(num: pd.Series, edges: Optional[List[float]]) -> pd.Series:
    """A number as the midpoint-free bin it falls in (keys are the bin's lower edge as text, ordered like
    the values), missing as MISSING_KEY. With no edges the exact values are used."""
    if edges is None:
        return number_keys(num)
    e = np.asarray(edges, dtype=float)
    v = num.to_numpy(dtype=float)
    f = np.isfinite(v)
    b = np.searchsorted(e, v, side="right")
    lower = np.where(b > 0, e[np.maximum(b - 1, 0)], -np.inf)
    keys = pd.Series([repr(float(x)) for x in lower], index=num.index, dtype=object)
    keys[~f] = MISSING_KEY
    return keys


def number_keys(num: pd.Series) -> pd.Series:
    v = num.to_numpy(dtype=float)
    keys = pd.Series([repr(float(x)) for x in v], index=num.index, dtype=object)
    keys[~np.isfinite(v)] = MISSING_KEY
    return keys


# ---------------------------------------------------------------------------
# Duplicates, recodes, near duplicates and clusters
# ---------------------------------------------------------------------------
def recode_fingerprint(values) -> Tuple[str, int]:
    """SHA-256 of the factorized codes (row order, missing as a value), and the number of values.
    Two columns have equal fingerprints exactly when one is a one-to-one recode of the other."""
    c = factor_codes(values)
    return hashlib.sha256(c.astype(np.int64).tobytes()).hexdigest(), int(c.max()) + 1 if len(c) else 0


def text_fingerprint(values) -> str:
    """SHA-256 of the values as text (missing as <missing>): equal means identical."""
    keys = code_keys(values)
    h = hashlib.sha256()
    for chunk in range(0, len(keys), 200_000):
        h.update("\x1f".join(keys.iloc[chunk:chunk + 200_000].tolist()).encode())
        h.update(b"\x1e")
    return h.hexdigest()


def cramers_v_codes(a: np.ndarray, b: np.ndarray) -> Tuple[float, int]:
    """Cramer's V between two factorized code arrays, and the number of distinct pairs."""
    a = np.asarray(a, dtype=np.int64)
    b = np.asarray(b, dtype=np.int64)
    if len(a) == 0:
        return float("nan"), 0
    ka, ia = np.unique(a, return_inverse=True)
    kb, ib = np.unique(b, return_inverse=True)
    pair = ia * len(kb) + ib
    up, cnt = np.unique(pair, return_counts=True)
    r, c = len(ka), len(kb)
    if r < 2 or c < 2:
        return 0.0, int(len(up))
    n = float(len(a))
    ra = np.bincount(ia, minlength=r).astype(float)
    cb = np.bincount(ib, minlength=c).astype(float)
    # chi2 = n * (sum over observed cells of O^2 / (ra cb) - 1)
    o = cnt.astype(float)
    ri, ci = up // c, up % c
    chi2 = n * (np.sum(o * o / (ra[ri] * cb[ci])) - 1.0)
    v = math.sqrt(max(chi2, 0.0) / (n * (min(r, c) - 1)))
    return min(1.0, v), int(len(up))


def correlation_ratio(codes: np.ndarray, num: np.ndarray) -> float:
    codes = np.asarray(codes, dtype=np.int64)
    num = np.asarray(num, dtype=float)
    if len(num) < 2 or np.nanstd(num) == 0:
        return 0.0
    k, inv = np.unique(codes, return_inverse=True)
    cnt = np.bincount(inv).astype(float)
    sums = np.bincount(inv, weights=num)
    mean = num.mean()
    between = np.sum(cnt * (sums / cnt - mean) ** 2)
    total = np.sum((num - mean) ** 2)
    return float(math.sqrt(between / total)) if total > 0 else 0.0


def impute_median(num: np.ndarray) -> np.ndarray:
    v = np.asarray(num, dtype=float).copy()
    f = np.isfinite(v)
    v[~f] = np.median(v[f]) if f.any() else 0.0
    return v


def pearson_pairwise(a: np.ndarray, b: np.ndarray) -> float:
    f = np.isfinite(a) & np.isfinite(b)
    if f.sum() < 3:
        return float("nan")
    x, z = a[f], b[f]
    if x.std() == 0 or z.std() == 0:
        return float("nan")
    return float(np.corrcoef(x, z)[0, 1])


def single_linkage(names: List[str], edges: Iterable[Tuple[str, str]]) -> List[List[str]]:
    """Connected components with two or more members, each in `names` order, ordered by first member."""
    parent = {n: n for n in names}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for a, b in edges:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra
    groups: Dict[str, List[str]] = {}
    for n in names:
        groups.setdefault(find(n), []).append(n)
    out = [g for g in groups.values() if len(g) >= 2]
    rank = {n: i for i, n in enumerate(names)}
    out.sort(key=lambda g: rank[g[0]])
    return out


# ---------------------------------------------------------------------------
# Strictly-earlier probes for engineered fields (builder-agnostic)
# ---------------------------------------------------------------------------
def _same(a: pd.Series, b: pd.Series) -> np.ndarray:
    x, z = a.to_numpy(), b.to_numpy()
    try:
        xf, zf = x.astype(float), z.astype(float)
        return np.isclose(xf, zf, rtol=1e-9, atol=1e-12, equal_nan=True)
    except (TypeError, ValueError):
        xs, zs = pd.Series(x, dtype=object), pd.Series(z, dtype=object)
        xn, zn = xs.isna().to_numpy(), zs.isna().to_numpy()
        eq = xs.astype(str).to_numpy() == zs.astype(str).to_numpy()
        return (xn & zn) | (~xn & ~zn & eq)


def _cutoffs(frame, account, time, seed):
    rng = np.random.default_rng(seed)
    t = pd.to_datetime(frame[time])
    g = frame[account].astype(str)
    lo, hi = t.groupby(g).transform("min"), t.groupby(g).transform("max")
    u = pd.Series(rng.random(g.nunique()), index=sorted(g.unique()))
    cut = lo + (hi - lo) * g.map(u).to_numpy()
    return t, (t > cut).to_numpy(), rng


def probe_future_invariance(frame: pd.DataFrame, build, sources: List[str], account: str, time: str,
                            seed: int = 0, drop_frac: float = 0.3) -> Dict:
    """Rows strictly after a random per-account cutoff have their source values rescaled (numbers)
    or permuted (codes) and some are deleted; no value at or before the cutoff may change."""
    t, later, rng = _cutoffs(frame, account, time, seed)
    pert = frame.copy()
    for c in sources:
        if c not in pert.columns or c in (account, time) or not later.any():
            continue
        col = pert[c]
        if pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pert.loc[later, c] = col[later].astype(float) * rng.uniform(0.1, 10.0, int(later.sum()))
        else:
            pert.loc[later, c] = rng.permutation(col[later].to_numpy())
    drop = later & (rng.random(len(frame)) < drop_frac)
    pert = pert.loc[~drop]
    keep = frame.index[~later]
    a = build(frame).loc[keep]
    b = build(pert).loc[keep]
    bad = ~_same(a, b)
    return {"ok": bool(not bad.any()), "rows_checked": int(len(keep)), "rows_changed": int(bad.sum()),
            "rows_perturbed": int(later.sum()), "rows_deleted": int(drop.sum())}


def probe_future_deletion(frame: pd.DataFrame, build, account: str, time: str, seed: int = 1) -> Dict:
    """Every row strictly after a random per-account cutoff is deleted; no earlier value may change."""
    t, later, _ = _cutoffs(frame, account, time, seed)
    keep = frame.index[~later]
    a = build(frame).loc[keep]
    b = build(frame.loc[keep]).loc[keep]
    bad = ~_same(a, b)
    return {"ok": bool(not bad.any()), "rows_checked": int(len(keep)), "rows_changed": int(bad.sum()),
            "rows_deleted": int(later.sum())}


UNIT_SECONDS = {"s": 1, "m": 60, "h": 3600, "d": 86400}


def recipe_reach_seconds(recipe: str) -> Optional[int]:
    """How far back a recipe reads: the sum of its window tokens (window, lag, within), or None."""
    import re
    inner = recipe[recipe.find("(") + 1:recipe.rfind(")")] if "(" in recipe else ""
    toks = re.findall(r"(?:^|[;=\s,])(\d+)(s|m|h|d)(?=$|[;\s,)])", inner)
    if not toks:
        return None
    return sum(int(n) * UNIT_SECONDS[u] for n, u in toks)


def probe_history_deletion(frame: pd.DataFrame, build_at, time: str, seed: int = 4,
                           reach_seconds: Optional[int] = None) -> Dict:
    """Earlier history is deleted: every row before a cutoff day goes, and the cutoff becomes the
    declared extract start. A later row's value may stay the same or become missing (censored); it
    may never become a different value, such as a zero where the history is censored. When the
    recipe declares how far back it reads, a row whose window reaches before the cutoff must be
    missing, and every other row must keep its value.

    build_at(frame, extract_start) -> values aligned to the frame.
    """
    t = pd.to_datetime(frame[time])
    if not len(frame):
        return {"ok": True, "rows_checked": 0, "rows_changed": 0}
    rng = np.random.default_rng(seed)
    lo, hi = t.min().normalize(), t.max().normalize()
    span = max(int((hi - lo).days), 1)
    cut = lo + pd.Timedelta(int(rng.integers(max(span // 3, 1), max(2 * span // 3, 2))), unit="D")
    keep_mask = (t >= cut).to_numpy()
    keep = frame.index[keep_mask]
    a = build_at(frame, None).loc[keep]
    b = build_at(frame.loc[keep], str(cut.date())).loc[keep]
    same = _same(a, b)
    b_missing = pd.isna(b).to_numpy()
    bad = ~same & ~b_missing
    zone = np.zeros(len(keep), dtype=bool)
    if reach_seconds:
        tk = pd.to_datetime(frame.loc[keep, time]).dt.floor("s")
        zone = ((tk - pd.Timedelta(int(reach_seconds), unit="s")) < cut).to_numpy()
        bad = (zone & ~b_missing) | (~zone & ~same)
    return {"ok": bool(not bad.any()), "rows_checked": int(len(keep)), "rows_changed": int(bad.sum()),
            "rows_censored": int((~same & b_missing).sum()), "rows_in_censor_zone": int(zone.sum()),
            "cutoff": str(cut.date())}


def probe_one_row(frame: pd.DataFrame, build, account: str, n_rows: int = 200, seed: int = 5) -> Dict:
    """Accounts with a single row: a recipe that needs earlier rows (since_last, since_first, prev,
    mean, min, max) must give missing, never a measured value."""
    rng = np.random.default_rng(seed)
    if not len(frame):
        return {"ok": True, "rows_checked": 0, "rows_changed": 0}
    pick = rng.choice(len(frame), size=min(n_rows, len(frame)), replace=False)
    one = frame.iloc[pick].copy()
    one[account] = [f"probe_single_{i}" for i in range(len(one))]
    v = build(one)
    bad = ~pd.isna(v).to_numpy()
    return {"ok": bool(not bad.any()), "rows_checked": int(len(one)), "rows_changed": int(bad.sum())}


def sibling_ids(ids: pd.Series, n: int) -> list:
    """New transaction ids for n added rows, of the stored ids' own kind: numbers above the largest stored id when
    every stored id is a number, else text. The recipe engine orders rows inside one second by the id; a text id
    among numbers would make it order every id as text (10 before 9) and so change which earlier row is latest."""
    num = pd.to_numeric(ids, errors="coerce")
    if len(ids) and num.notna().any() and (num.notna() | ids.isna()).all():
        top = int(np.floor(num.max()))
        return [top + 1 + i for i in range(n)]
    return [f"probe_sibling_{i}" for i in range(n)]


def probe_same_second(frame: pd.DataFrame, build, sources: List[str], account: str, time: str,
                      id_col: Optional[str], seed: int = 2, n_rows: int = 200, whole_seconds: bool = False) -> Dict:
    """A sibling row is added in the same second as row i (its other values taken from another
    row); row i's value must not change. One row per account is checked, so no other added
    sibling sits in that account. The sibling's time is the second plus a few milliseconds, or the
    whole second itself with whole_seconds (a builder that reads the stored precision and refuses
    sub-second parts, as the 26 October builders do: design review item 31)."""
    rng = np.random.default_rng(seed)
    if not len(frame):
        return {"ok": True, "rows_checked": 0, "rows_changed": 0}
    acct = frame[account].astype(str).to_numpy()
    order = rng.permutation(len(frame))
    _, first = np.unique(acct[order], return_index=True)
    pick = order[first]
    if len(pick) > n_rows:
        pick = rng.choice(pick, size=n_rows, replace=False)
    donors = rng.choice(len(frame), size=len(pick), replace=True)
    sib = frame.iloc[pick].copy()
    donor = frame.iloc[donors]
    for c in sources:
        if c in sib.columns and c not in (account, time):
            sib[c] = donor[c].to_numpy()
    t = pd.to_datetime(sib[time])
    ms = rng.integers(0, 1000, len(sib))
    sib[time] = t.dt.floor("s") + (pd.Timedelta(0) if whole_seconds else pd.to_timedelta(ms, unit="ms"))
    if id_col and id_col in sib.columns:
        sib[id_col] = sibling_ids(frame[id_col], len(sib))
    if pd.api.types.is_integer_dtype(frame.index):
        start = int(frame.index.max()) + 1
        sib.index = pd.RangeIndex(start, start + len(sib))
    else:
        sib.index = [f"__sib{i}" for i in range(len(sib))]
    both = pd.concat([frame, sib])
    keep = frame.index[pick]
    a = build(frame).loc[keep]
    b = build(both).loc[keep]
    bad = ~_same(a, b)
    return {"ok": bool(not bad.any()), "rows_checked": int(len(keep)), "rows_changed": int(bad.sum())}


def probe_label_permutation(frame: pd.DataFrame, build, label_cols: List[str], seed: int = 3) -> Dict:
    """Label columns permuted across rows; no built value may change."""
    rng = np.random.default_rng(seed)
    pert = frame.copy()
    present = [c for c in label_cols if c in pert.columns]
    for c in present:
        pert[c] = rng.permutation(pert[c].to_numpy())
    a = build(frame)
    b = build(pert).loc[a.index]
    bad = ~_same(a, b)
    return {"ok": bool(not bad.any()), "rows_checked": int(len(a)), "rows_changed": int(bad.sum()),
            "label_columns": present}
