"""Build the feature workbook (Excel) from the feature CSVs. REVIEWERS' SUGGESTIONS, NOT FINAL.

One command rebuilds it after the lists are edited:
    python fraud/experiments/features/new_fields/build_feature_workbook.py

Inputs (defaults; each can be given as an option). NF is fraud/experiments/features/new_fields/.
    fraud/configs/predictors.csv                      the 23 current predictors
    docs/fraud_detection_plan_detailed.md             Yaqun's "Deliberately excluded" list (optional)
    NF/DRAFT_TFM_FIELDS_UNCONFIRMED.csv               TFM V22B chart rows, then the other TFM raw columns
    NF/DRAFT_15298_RECIPES_UNCONFIRMED.csv            the 94 ranked model 15298 outputs
    NF/DRAFT_OTHER_PROPOSED_UNCONFIRMED.csv           features built on 26 October and meeting ideas
    NF/DRAFT_FEATURE_ATTRIBUTES_UNCONFIRMED.csv       one row per new feature name (type, categories, recipe)
    NF/KEEP_DECISIONS.csv                             the ONE decisions table
    NF/FIELD_MAP.csv                                  optional: where it has rows, its values win
Output:
    NF/FEATURE_WORKBOOK_REVIEWERS_SUGGESTIONS.xlsx    eight sheets

The Final list, Excluded and Decisions sheets all come from KEEP_DECISIONS.csv (the Final list also
carries the 23 current predictors, which are the baseline). A row decided by "proposed" (a reviewer's
or a tool's suggestion) is shown as unresolved on the Final list until a person decides it.
``--export-predictors FILE`` writes the Final list as a predictor list (feature, type, source,
version, description) with model output names and types: the 23 current rows plus the keep rows a
person decided (``--include-proposed`` adds the proposed keep rows, for a draft only).
The same inputs give the same bytes.

Exit codes: 0 done; 2 an input is wrong (every problem is listed).
"""

import argparse
import csv
import io
import re
import sys
import zipfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
NF_DIR = Path(__file__).resolve().parent
for _p in (str(ROOT / "src"), str(ROOT)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from openpyxl import Workbook  # noqa: E402
from openpyxl.styles import Alignment, Font, PatternFill  # noqa: E402
from openpyxl.utils import get_column_letter  # noqa: E402

OK, ARGS = 0, 2
TITLE = "REVIEWERS' SUGGESTIONS, NOT FINAL"
FIXED_TIME = datetime(2026, 11, 2, 0, 0, 0)
FIXED_ZIP_TIME = (2026, 11, 2, 0, 0, 0)

SHEETS = ["README", "Current features", "Model 15298 features", "TFM V22B features",
          "Other proposed features", "Final list (draft)", "Excluded", "Decisions"]

KEEP_COLUMNS = ["name", "group", "verdict", "reason", "evidence", "decided_by", "date", "definition_version"]
VERDICTS = ("keep", "drop", "hold", "unresolved")
GROUPS = ("v22b", "f15298", "both", "a3")


def month_out_row(keep):
    """The planner's row for an adopted month-out step (the reviewers' decision D4c): name month, group base,
    verdict drop, decided by the reviewers' decision D4c and the month rule. The only row a current predictor may
    have."""
    for d in keep:
        if d["name"] == "month" and d["verdict"] == "drop" and "D4c" in d.get("decided_by", ""):
            return d
    return None


def month_text(keep):
    d = month_out_row(keep)
    if d is not None:
        return (f"Month leaves: the month-out step was adopted under the month rule ({d.get('evidence', '')}, "
                f"{d.get('date', '')}).")
    return ("Month stays in until the month-out step reads (the reviewers' decision D4c, the last stage 2 fitting "
            "step); the month rule decides.")


def entered_at(d, a1_adopted=None):
    """The step a kept row enters at (the reviewers' decision D3a): v22b at A1; f15298 at A2; a row in both lists
    at A1, or at A2 when A1 kept its control; none for a row that does not enter."""
    if d.get("verdict") != "keep":
        return "none"
    g = d.get("group", "")
    if g == "v22b":
        return "A1"
    if g == "f15298":
        return "A2"
    if g == "both":
        return "A2" if a1_adopted is False else "A1"
    return "none"
PROPOSED = "proposed"
FILLS = {"keep": "C6EFCE", "drop": "F4CCCC", "hold": "FFEB9C", "unresolved": "DDEBF7"}
HEADER_FILL = "D9D9D9"
PREDICTOR_COLUMNS = ["feature", "type", "source", "version", "description"]
ATTR_SHOWN = ["origin", "kind", "recipe", "proposed_alternative", "source_columns", "model_type", "yaqun_category",
              "business_category",
              "date_meaning", "mapping_status", "excluded_by_sumegha", "sumegha_reason", "in_owner_list"]
JOINED = ["verdict", "decided_by", "reason", "evidence", "group", "yaqun_category", "business_category"]

TFM_FIRST = ["name", "v22b_importance_rank", "tfm_name", "pod_column", "importance_pct", "dtype",
             "raw_or_engineered", "is_status_field_or_status_date", "in_26oct_list", "already_a_current_input",
             "draft_include", "draft_reason", "scope"]
F15298_FIRST = ["name", "rank_15298", "feature_15298", "kind", "model_type", "recipe", "proposed_alternative",
                "recipe_support",
                "source_columns", "date_meaning", "mapping_status", "equivalence", "left_out_reason",
                "account_level_alternative", "raw_alternative", "same_output_as", "draft_note",
                "proposed_work_type", "next_definition_needed"]
OTHER_FIRST = ["name", "item", "status"]

YAQUN_CATEGORIES = [
    ("Continuous", "A number. Missing values get the median and an _isna flag (Yaqun's plan). Dates enter "
                   "here as days before (or until) the transaction, never as calendar parts."),
    ("Categorical, low cardinality", "A code with few values (flags, indicators). The model learns a vector per value."),
    ("Categorical, high cardinality", "A code with many values (merchant, postal, state, country, network, device). "
                                      "Yaqun's plan excluded these; check the unique counts before adding."),
    ("Categorical, cardinality to check", "A code whose number of values is not known yet."),
    ("Datetime-derived", "Month, day, hour and day of week, derived from transaction_dttm (categorical)."),
    ("Deliberately excluded", "Left out on purpose, with the reason (Yaqun's plan: identifiers, the order key, "
                              "high-cardinality fields, prior_action_db_expiration_dt, transaction_advice_xcd)."),
    ("To check", "The type is not known from the records; Copilot fills it on the pod."),
]
BUSINESS_CATEGORIES = [
    "amount and balance", "limits", "card and authentication", "point of sale and terminal", "merchant",
    "transaction type and channel", "tokens, devices and logins", "account and customer profile", "time",
    "velocity and recency", "location", "merchant risk and claims", "bank decisions (lagged)",
    "external scores", "other bank-system codes",
]
COLUMN_MEANINGS = [
    ("name", "The model input name (the field map's name). It joins every sheet. A shared raw dependency does "
             "not make two outputs the same feature."),
    ("group", "Step group: v22b, f15298, both (in the V22B and 15298 lists; it stays in the V22B step) or a3 "
              "(built 26 October). The current predictors are the baseline."),
    ("verdict", "keep, drop, hold or unresolved. Only keep rows reach the Final list."),
    ("reason", "Plain text. It starts with a short type: status, identifier, same_txn_decision, duplicate, "
               "definition_needed, open_mapping, owner_list_needed, excluded_by_sumegha and others."),
    ("evidence", "Where the reason comes from, for example reviewer records: FEATURE_REVIEW.md, or "
                 "checks:STOP date_after_txn."),
    ("decided_by", "A person's name, or proposed for a reviewer's or a tool's suggestion. Proposed rows are "
                   "shown as unresolved on the Final list. A new field that repeats month or tracks time is "
                   "decided by the reviewers under the owner's delegation: their keep or drop row, with its "
                   "reason, ends the checks' hold. The owner is asked only for a missing source fact or a "
                   "preference."),
    ("date / definition_version", "When it was decided (yyyy-mm-dd); the recipe version (raised when it changes)."),
    ("origin", "current, TFM V22B, 15298, both lists, or proposed (built 26 October)."),
    ("kind / recipe / source_columns", "raw or engineered; the recipe in the recipe grammar; the raw columns it "
                                       "reads (its raw dependencies)."),
    ("model_type", "continuous or categorical, as the model takes it."),
    ("yaqun_category / business_category", "Yaqun-style role and what the feature is about (lists below)."),
    ("date_meaning", "event_date (days before the transaction) or known_future_date (days until, for an expiry)."),
    ("mapping_status", "recorded (source column in the records), name_only (taken from the feature's name), "
                       "open (an LE1/LE3 encoding; equivalence with the raw code unverified), definition_needed."),
    ("excluded_by_sumegha / sumegha_reason", "Blank for Copilot: yes or no, with the reason. A yes row never enters."),
    ("in_owner_list", "From the field map's list_status and list_source: yes when adopt confirmed the row from "
                      "the owner's list, no for NOT_IN_OWNER_LIST, blank until the owner's list is adopted."),
    ("proposed_alternative", "For an LE1/LE3 output: code(<raw code>), the raw code proposed as an alternative "
                             "(reviewer feature review). The original encoder is unverified, so the row stays "
                             "unresolved; the field map carries this recipe with the FLAG encoding_alternative. "
                             "For a postal code TFM feeds as a geohash (recipe geohash(postal; country)): the raw "
                             "postal code, as a raw field of that name."),
]


class InputError(Exception):
    pass


# ---------------------------------------------------------------------------------------------
def read_csv(path, required=(), optional=False):
    path = Path(path)
    if not path.is_file():
        if optional:
            return [], []
        raise InputError(f"missing input file: {path.name}")
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        header = list(reader.fieldnames or [])
        rows = [{k: (v if v is not None else "") for k, v in r.items()} for r in reader]
    missing = [c for c in required if c not in header]
    if missing:
        raise InputError(f"{path.name}: missing columns {missing}")
    return header, rows


def plan_exclusions(path):
    """Yaqun's 'Deliberately excluded' bullets: (name or '', the bullet text)."""
    p = Path(path)
    if not p.is_file():
        return []
    m = re.search(r"### Deliberately excluded\n(.*?)(\n## |\n### |\Z)", p.read_text(encoding="utf-8"), re.S)
    if not m:
        return []
    out = []
    for line in m.group(1).splitlines():
        if not line.startswith("- ") or line.startswith("- Prune"):
            continue
        text = line[2:].strip()
        names = re.findall(r"`([^`]+)`", text)
        if names:
            out.extend((n, text) for n in names)
        else:
            out.append(("", text))
    return out


def ordered(header, first):
    return [c for c in first if c in header] + [c for c in header if c not in first]


def load(args):
    data = {"a1_adopted": {"yes": True, "no": False}.get(getattr(args, "a1_adopted", "unknown"))}
    data["pred"] = read_csv(args.predictors, PREDICTOR_COLUMNS)
    data["tfm"] = read_csv(args.tfm, ["name", "tfm_name", "pod_column", "draft_include", "scope"])
    data["f15298"] = read_csv(args.f15298, ["name", "rank_15298", "feature_15298"])
    data["other"] = read_csv(args.other, ["name", "item", "status"])
    data["attr"] = read_csv(args.attributes, ["name", "model_type"])
    keep_h, keep = read_csv(args.decisions, KEEP_COLUMNS)
    if keep_h != KEEP_COLUMNS:
        raise InputError(f"KEEP_DECISIONS.csv: columns must be exactly {KEEP_COLUMNS}, got {keep_h}")
    data["keep"] = (keep_h, keep)
    fm_path = Path(args.field_map) if args.field_map else NF_DIR / "FIELD_MAP.csv"
    data["field_map"] = read_csv(fm_path, ["name"], optional=True)
    data["plan"] = plan_exclusions(args.plan)
    return data


def owner_list_mark(list_status, list_source):
    """in_owner_list, derived from the field map (integration decision 8): no new map column."""
    if list_status == "CONFIRMED" and list_source.strip():
        return "yes"
    if list_status == "NOT_IN_OWNER_LIST":
        return "no"
    return ""


def proposed_alternative(a):
    """code(<raw code>) for an LE1/LE3 output whose raw code is recorded (integration decision 3); the raw postal
    code, as a raw field, for TFM's postal-code geohash (part B, item 9)."""
    recipe = a.get("recipe", "")
    if recipe.startswith("code(") and a.get("mapping_status", "") == "open":
        return recipe
    alt = a.get("raw_alternative", "").strip()
    if not recipe and alt and a.get("mapping_status", "") == "open":
        return f"code({alt})"
    if recipe.startswith("geohash(") and alt:
        return f"{alt} (raw)"
    return ""


def attributes(data):
    """One attribute record per name: the draft table, overridden by the field map where it has values."""
    _, rows = data["attr"]
    attrs = {r["name"]: dict(r) for r in rows}
    fm_h, fm = data["field_map"]
    for r in fm:
        a = attrs.setdefault(r["name"], {"name": r["name"]})
        for c in fm_h:
            if r.get(c, "") != "":
                a[c] = r[c]
        mark = owner_list_mark(r.get("list_status", ""), r.get("list_source", ""))
        if mark:
            a["in_owner_list"] = mark
    for a in attrs.values():
        a["proposed_alternative"] = proposed_alternative(a)
    return attrs


def validate(data):
    problems = []
    _, keep = data["keep"]
    _, pred = data["pred"]
    base = {p["feature"] for p in pred} | {"time_delta"}
    attrs = attributes(data)
    names = {}
    for i, d in enumerate(keep, 2):
        where = f"KEEP_DECISIONS.csv line {i} ({d['name']})"
        if d["verdict"] not in VERDICTS:
            problems.append(f"{where}: verdict '{d['verdict']}' is not one of {VERDICTS}")
        month_out = d is month_out_row(keep) and d["group"] == "base"
        if d["group"] not in GROUPS and not month_out:
            problems.append(f"{where}: group '{d['group']}' is not one of {GROUPS}")
        if not d["decided_by"].strip():
            problems.append(f"{where}: decided_by is blank (a person's name, or proposed)")
        if d["date"] and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", d["date"]):
            problems.append(f"{where}: date '{d['date']}' is not yyyy-mm-dd")
        if d["name"] in names:
            problems.append(f"{where}: name repeats (first on line {names[d['name']]})")
        names.setdefault(d["name"], i)
        if d["name"] in base and not month_out:
            problems.append(f"{where}: a current predictor is the baseline, not a decision row")
        if month_out:
            continue
        a = attrs.get(d["name"])
        if a is None:
            problems.append(f"{where}: no attributes row (DRAFT_FEATURE_ATTRIBUTES_UNCONFIRMED.csv or FIELD_MAP.csv)")
            continue
        if a.get("excluded_by_sumegha", "").strip().lower() == "yes" and d["verdict"] == "keep":
            problems.append(f"{where}: excluded_by_sumegha is yes but the verdict is keep (a yes row never enters)")
        if d["verdict"] == "keep":
            if a.get("model_type") not in ("continuous", "categorical"):
                problems.append(f"{where}: a keep row needs model_type continuous or categorical, "
                                f"got '{a.get('model_type', '')}'")
            if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", d["name"]):
                problems.append(f"{where}: a keep row's name must be letters, digits and underscores")
    for key, label in (("tfm", "TFM list"), ("f15298", "15298 list"), ("other", "other proposed list")):
        _, rows = data[key]
        for i, r in enumerate(rows, 2):
            if r["name"] in base or r["name"] in names:
                continue
            if key == "other" and r.get("status", "").startswith("idea"):
                continue
            problems.append(f"{label} line {i}: name '{r['name']}' has no KEEP_DECISIONS.csv row")
    return problems


# ---------------------------------------------------------------------------------------------
NUMERIC_COLUMNS = re.compile(r"(^|_)rank(_|$)|importance_pct|^rank_15298$")


def _cell_value(v, column=""):
    """Text stays text (a leading '=' never becomes a formula); ranks and importances become numbers."""
    s = "" if v is None else str(v)
    if NUMERIC_COLUMNS.search(column) and re.fullmatch(r"-?\d+(\.\d+)?", s):
        return int(s) if re.fullmatch(r"-?\d+", s) else float(s)
    if s.startswith("="):
        s = "'" + s
    return s


def write_table(ws, columns, rows, colour_col):
    bold = Font(bold=True)
    head_fill = PatternFill("solid", fgColor=HEADER_FILL)
    wrap = Alignment(wrap_text=True, vertical="top")
    ws.append(columns)
    for c in range(1, len(columns) + 1):
        cell = ws.cell(row=1, column=c)
        cell.font, cell.fill, cell.alignment = bold, head_fill, wrap
    fills = {k: PatternFill("solid", fgColor=v) for k, v in FILLS.items()}
    for r in rows:
        ws.append([_cell_value(r.get(c, ""), c) for c in columns])
        rr = ws.max_row
        fill = fills.get(r.get(colour_col, ""))
        for c in range(1, len(columns) + 1):
            cell = ws.cell(row=rr, column=c)
            cell.alignment = wrap
            if fill is not None:
                cell.fill = fill
    for i, col in enumerate(columns, 1):
        longest = max([len(str(col))] + [len(str(r.get(col, ""))) for r in rows])
        ws.column_dimensions[get_column_letter(i)].width = max(10, min(60, longest + 2))
    ws.freeze_panes = "B2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(columns))}{len(rows) + 1}"


def shown_state(verdict, decided_by):
    """What the Final list shows: a proposed row stays unresolved until a person decides it."""
    return "unresolved" if decided_by.strip().lower() == PROPOSED else verdict


def source_sheet(rows, header, first, keep_by, attrs, base, extra=()):
    cols = ordered(header, first) + [c for c in JOINED + list(extra) if c not in header]
    if "proposed_alternative" in first and "proposed_alternative" not in cols and "recipe" in cols:
        cols.insert(cols.index("recipe") + 1, "proposed_alternative")
    out = []
    for r in rows:
        row = dict(r)
        n = r["name"]
        d, a = keep_by.get(n), attrs.get(n, {})
        if n in base:
            vals = {"verdict": "keep", "decided_by": "baseline", "group": "current",
                    "reason": "current input: already one of today's predictors (kept once there)."}
        elif d is not None:
            vals = {k: d[k] for k in ("verdict", "decided_by", "reason", "evidence", "group")}
        else:
            vals = {"verdict": "unresolved", "decided_by": "", "reason": "idea, not built: no decision row yet."}
        for c in JOINED + list(extra):
            if c in header:
                continue
            row[c] = vals.get(c, a.get(c, ""))
        if "proposed_alternative" in cols and "proposed_alternative" not in header:
            row["proposed_alternative"] = a.get("proposed_alternative", "") or proposed_alternative(r)
        out.append(row)
    return cols, out


def current_sheet(pred, keep_by, plan):
    cols = PREDICTOR_COLUMNS + ["yaqun_category", "business_category", "row_kind", "verdict", "reason"]
    rows = []
    month = month_text(list(keep_by.values()))
    for p in pred:
        cat = ("Datetime-derived" if p["source"].startswith("derived:transaction_dttm") else
               "Continuous" if p["type"] == "continuous" else "Categorical, low cardinality")
        gone = p["feature"] == "month" and month_out_row(list(keep_by.values())) is not None
        rows.append({**p, "yaqun_category": cat, "business_category": _business(p["feature"]),
                     "row_kind": "predictor", "verdict": "drop" if gone else "keep",
                     "reason": f"Baseline: one of the 23 predictors. {month}" if p["feature"] == "month" else
                     "Baseline: one of the 23 predictors."})
    rows.append({"feature": "time_delta", "type": "continuous", "source": "model setting (sequence.time_delta)",
                 "version": "", "description": "Time gap to the previous transaction in the window, log seconds. "
                 "A separate channel of the model, not a predictor row.", "yaqun_category": "Continuous",
                 "business_category": "time", "row_kind": "model metadata (not a predictor row)",
                 "verdict": "", "reason": "Part of the chosen model's settings."})
    for name, text in plan:
        d = keep_by.get(name) or next((keep_by[n] for n in keep_by if name and n.endswith("__" + name)), None)
        rows.append({"feature": name, "type": "", "source": "", "version": "", "description": text,
                     "yaqun_category": "Deliberately excluded", "business_category": _business(name) if name else "",
                     "row_kind": "deliberately excluded (Yaqun's plan)",
                     "verdict": d["verdict"] if d else "excluded in Yaqun's plan",
                     "reason": (f"Yaqun's plan: {text}" +
                                (f" Its decision row ({d['name']}): {d['verdict']}." if d else ""))})
    return cols, rows


_BUSINESS = [("time", r"^(month|day|hour|day_of_week)$"), ("external scores", r"external_1_scr"),
             ("limits", r"lmt|limit"), ("amount and balance", r"amt|bal"),
             ("card and authentication", r"cvv|avs|pin|crypto|security"),
             ("point of sale and terminal", r"pos_|terminal|cardholder_present|capture|premises|attend"),
             ("transaction type and channel", r"transaction_type|segment|category")]


def _business(name):
    for cat, pat in _BUSINESS:
        if re.search(pat, name or ""):
            return cat
    return "other bank-system codes"


def final_sheet(pred, keep, attrs, a1_adopted=None):
    cols = PREDICTOR_COLUMNS + ["origin", "group", "entered_at", "yaqun_category", "business_category", "kind",
                                "recipe", "source_columns", "date_meaning", "mapping_status", "flags", "verdict",
                                "shown_as", "decided_by", "reason", "evidence"]
    rows = []
    month_gone = month_out_row(keep) is not None
    for p in pred:
        if month_gone and p["feature"] == "month":   # D4c: an adopted month-out step drops month here and in
            continue                                  # the predictor export
        cat = ("Datetime-derived" if p["source"].startswith("derived:transaction_dttm") else
               "Continuous" if p["type"] == "continuous" else "Categorical, low cardinality")
        rows.append({**p, "origin": "current", "group": "current", "entered_at": "base", "yaqun_category": cat,
                     "business_category": _business(p["feature"]), "kind": "raw" if p["source"] == "raw" else
                     "engineered", "recipe": "raw" if p["source"] == "raw" else p["source"],
                     "source_columns": p["feature"] if p["source"] == "raw" else p["source"].split(":", 1)[1],
                     "verdict": "keep", "shown_as": "keep", "decided_by": "baseline",
                     "reason": "Baseline predictor.", "evidence": "fraud/configs/predictors.csv"})
    for d in keep:
        if d["verdict"] != "keep":
            continue
        a = attrs.get(d["name"], {})
        rows.append({
            "feature": d["name"], "type": a.get("model_type", ""), "source": "raw",
            "version": "2", "description": a.get("description", ""), "origin": a.get("origin", ""),
            "group": d["group"], "entered_at": entered_at(d, a1_adopted),
            **{c: a.get(c, "") for c in ("yaqun_category", "business_category", "kind",
                                                               "recipe", "source_columns", "date_meaning",
                                                               "mapping_status", "flags")},
            "verdict": d["verdict"], "shown_as": shown_state(d["verdict"], d["decided_by"]),
            "decided_by": d["decided_by"], "reason": d["reason"], "evidence": d["evidence"],
        })
    return cols, rows


def excluded_sheet(keep, attrs):
    cols = ["feature", "group", "origin", "reason_type", "reason", "evidence", "decided_by", "date",
            "kept_once_as", "excluded_by_sumegha", "sumegha_reason", "source_columns", "verdict"]
    rows = []
    for d in keep:
        if d["verdict"] != "drop":
            continue
        a = attrs.get(d["name"], {})
        m = re.match(r"([a-z_0-9]+):", d["reason"])
        rows.append({"feature": d["name"], "group": d["group"], "origin": a.get("origin", ""),
                     "reason_type": m.group(1) if m else "", "reason": d["reason"], "evidence": d["evidence"],
                     "decided_by": d["decided_by"], "date": d["date"], "kept_once_as": a.get("kept_once_as", ""),
                     "excluded_by_sumegha": a.get("excluded_by_sumegha", ""),
                     "sumegha_reason": a.get("sumegha_reason", ""), "source_columns": a.get("source_columns", ""),
                     "verdict": d["verdict"]})
    return cols, rows


def decisions_sheet(keep, attrs):
    cols = KEEP_COLUMNS + ["origin", "decided"]
    rows = [{**d, "origin": attrs.get(d["name"], {}).get("origin", ""),
             "decided": "no (proposed)" if d["decided_by"].strip().lower() == PROPOSED else "yes"} for d in keep]
    return cols, rows


def readme_rows(data, sheet_counts):
    _, keep = data["keep"]
    lines = [
        ("What this is", "The reviewers' draft of every candidate feature: today's inputs, model 15298's outputs, "
                         "the TFM V22B fields and other proposed features, with one draft verdict each. Every row "
                         "is UNCONFIRMED. The owner and Copilot decide the final list. Where this workbook and the "
                         "pod disagree, the pod is right."),
        ("How to regenerate", "Edit the CSVs, then run: python fraud/experiments/features/new_fields/"
                              "build_feature_workbook.py. Add --export-predictors <file> to write the current predictors "
                              "plus the keep rows a person decided as a predictor list; --include-proposed adds the "
                              "proposed keep rows (a draft only)."),
        ("The one decisions table", "KEEP_DECISIONS.csv (name, group, verdict, reason, evidence, decided_by, date, "
                                    "definition_version). The Final list, Excluded and Decisions sheets all come "
                                    "from it. Hold and unresolved rows stay visible on Decisions and on their source "
                                    "sheet; they never reach the Final list. A proposed row is shown as unresolved "
                                    "on the Final list until a person decides it."),
        ("Feature attributes", "DRAFT_FEATURE_ATTRIBUTES_UNCONFIRMED.csv holds each name's type, categories, recipe "
                               "and raw dependencies, in field-map column names. Where FIELD_MAP.csv has a value "
                               "for a name, the field map wins."),
        ("Draft lists", "nf_workbook_drafts.py rewrites the DRAFT_*_UNCONFIRMED.csv lists from the records. It "
                        "leaves KEEP_DECISIONS.csv alone unless given --force."),
        ("Predictor export", "Model output names and types only, never source timestamps or raw dependencies. The "
                             "23 current rows keep their source and version. New rows say source raw and version "
                             "2: an engineered output is a precomputed column in the enriched copies."),
        ("Sources", "Current: fraud/configs/predictors.csv and docs/fraud_detection_plan_detailed.md (Yaqun). "
                    "15298: waqas/feature_work/all_features_master.csv (after the reorganization: "
                    "fraud/experiments/features/reference/all_features_master.csv) and reviewer records: "
                    "15298_RECIPE_CROSSWALK.csv. TFM V22B: reviewer records: CANDIDATE_FIELDS_UNCONFIRMED.csv. "
                    "Other proposed: reviewer records: WEEKLY_2026-10-26.md (Appendix C), reviewer records: "
                    "README.md (features work), waqas/docs/meeting_notes.md sections 2 and 7. Corrections: "
                    "reviewer records: FEATURE_REVIEW.md."),
        ("TFM V22B sheet", "The 120 importance-chart rows come first, then the other TFM raw columns. The chart is "
                           "not exhaustive. Mark in_owner_list from the owner's supplied included list, and add a "
                           "row (with an attributes row and a decision row) for any listed field not shown here."),
        ("Time gap", "time_delta, the time gap to the previous transaction, is a model setting, not a predictor "
                     "row. It is shown on Current features as model metadata."),
        ("Month", month_text(data["keep"][1]) + " The checks measure whether a new date field repeats it. A new "
                  "field that repeats month or tracks time waits until the reviewers record keep or drop and the "
                  "reason in KEEP_DECISIONS.csv, under the owner's delegation; no owner signature is needed. Exact "
                  "month duplicates stay represented once; month stays. A warning never shortens a declared "
                  "history window."),
        ("Rules", "Status fields and status dates stay out unless the data owner confirms them. Bank decisions on "
                  "the same transaction enter only as the previous transaction's value. Dates enter as days before "
                  "the transaction; a known future date (an expiry) as days until, or a signed difference. LE1/LE3 "
                  "encodings stay unresolved: the original encoder is unverified, and the raw code, code(c) in the "
                  "proposed_alternative column, is a proposed alternative, not proven equivalent. The two V22B "
                  "postal codes enter as TFM feeds them, geohash(postal; country) from TFM's table; the raw postal "
                  "code is their proposed_alternative. A recipe with no "
                  "definition is on hold, "
                  "not dropped. A Sumegha exclusion never enters."),
    ]
    for name, n in sheet_counts:
        lines.append((f"Rows: {name}", str(n)))
    _, tfm = data["tfm"]
    chart = [r for r in tfm if r.get("scope") == "v22b_chart"]
    lines.append(("V22B chart draft verdicts", f"{len(chart)} chart rows: " + ", ".join(
        f"{k} {sum(1 for r in chart if r['draft_include'] == k)}" for k in ("yes", "hold", "no")) +
        " (the TFM list's draft_include; the decision is in KEEP_DECISIONS.csv)"))
    _, f15298 = data["f15298"]
    work = {}
    for r in f15298:
        work[r.get("proposed_work_type", "")] = work.get(r.get("proposed_work_type", ""), 0) + 1
    lines.append(("15298 work types", f"{len(f15298)} outputs: " + ", ".join(f"{k} {v}" for k, v in work.items())))
    by_group = {}
    for d in keep:
        by_group.setdefault(d["group"], {k: 0 for k in VERDICTS})[d["verdict"]] += 1
    for g in GROUPS:
        if g in by_group:
            lines.append((f"Verdicts: {g}", ", ".join(f"{k} {v}" for k, v in by_group[g].items())))
    total = {k: sum(1 for d in keep if d["verdict"] == k) for k in VERDICTS}
    lines.append(("Verdicts: all", ", ".join(f"{k} {v}" for k, v in total.items())))
    proposed = sum(1 for d in keep if d["decided_by"].strip().lower() == PROPOSED)
    lines.append(("Decided by a person", f"{len(keep) - proposed} of {len(keep)} rows ({proposed} proposed)"))
    for k in VERDICTS:
        lines.append((f"Colour: {k}", f"Rows shown as {k} are filled #{FILLS[k]}."))
    for k, v in YAQUN_CATEGORIES:
        lines.append((f"Category: {k}", v))
    lines.append(("Business categories", "; ".join(BUSINESS_CATEGORIES)))
    for k, v in COLUMN_MEANINGS:
        lines.append((f"Column: {k}", v))
    return lines


def write_readme(ws, lines):
    ws.append([TITLE, ""])
    ws.cell(row=1, column=1).font = Font(bold=True, size=14, color="9C0006")
    ws.cell(row=1, column=1).fill = PatternFill("solid", fgColor="FFC7CE")
    ws.append(["Item", "Text"])
    for c in (1, 2):
        ws.cell(row=2, column=c).font = Font(bold=True)
        ws.cell(row=2, column=c).fill = PatternFill("solid", fgColor=HEADER_FILL)
    wrap = Alignment(wrap_text=True, vertical="top")
    for k, v in lines:
        ws.append([k, v])
        for c in (1, 2):
            ws.cell(row=ws.max_row, column=c).alignment = wrap
    ws.column_dimensions["A"].width = 38
    ws.column_dimensions["B"].width = 110
    ws.freeze_panes = "A3"


def tables_of(data):
    pred_h, pred = data["pred"]
    tfm_h, tfm = data["tfm"]
    f_h, f15298 = data["f15298"]
    o_h, other = data["other"]
    _, keep = data["keep"]
    keep_by = {d["name"]: d for d in keep}
    attrs = attributes(data)
    base = {p["feature"] for p in pred} | {"time_delta"}
    return [
        ("Current features", "verdict") + current_sheet(pred, keep_by, data["plan"]),
        ("Model 15298 features", "verdict") + source_sheet(f15298, f_h, F15298_FIRST, keep_by, attrs, base),
        ("TFM V22B features", "verdict") + source_sheet(tfm, tfm_h, TFM_FIRST, keep_by, attrs, base,
                                                        extra=("recipe", "proposed_alternative",
                                                               "excluded_by_sumegha", "sumegha_reason",
                                                               "in_owner_list")),
        ("Other proposed features", "verdict") + source_sheet(other, o_h, OTHER_FIRST, keep_by, attrs, base),
        ("Final list (draft)", "shown_as") + final_sheet(pred, keep, attrs, data.get("a1_adopted")),
        ("Excluded", "verdict") + excluded_sheet(keep, attrs),
        ("Decisions", "verdict") + decisions_sheet(keep, attrs),
    ]


def build_workbook(data):
    tables = tables_of(data)
    wb = Workbook()
    ws = wb.active
    ws.title = "README"
    write_readme(ws, readme_rows(data, [(n, len(r)) for n, _, _, r in tables]))
    for name, colour_col, cols, rows in tables:
        write_table(wb.create_sheet(name), cols, rows, colour_col)
    wb.properties.creator = "reviewers"
    wb.properties.lastModifiedBy = "reviewers"
    wb.properties.title = TITLE
    wb.properties.created = FIXED_TIME
    wb.properties.modified = FIXED_TIME
    return wb, {n: (c, r) for n, _, c, r in tables}


def stable_bytes(wb):
    """Workbook bytes with fixed timestamps, so the same inputs give the same file.

    Entries are stored uncompressed, so a plain text search of the .xlsx file sees the sheet text as it
    is (compressed bytes can contain chance letter pairs that a word scan would report).
    """
    raw = io.BytesIO()
    wb.save(raw)
    src = zipfile.ZipFile(io.BytesIO(raw.getvalue()))
    out = io.BytesIO()
    stamp = FIXED_TIME.strftime("%Y-%m-%dT%H:%M:%SZ")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_STORED) as dst:
        for info in src.infolist():
            data = src.read(info.filename)
            if info.filename == "docProps/core.xml":
                text = data.decode("utf-8")
                text = re.sub(r"(<dcterms:(created|modified)[^>]*>)[^<]*(</dcterms:\2>)",
                              lambda m: m.group(1) + stamp + m.group(3), text)
                data = text.encode("utf-8")
            zi = zipfile.ZipInfo(info.filename, date_time=FIXED_ZIP_TIME)
            zi.compress_type = zipfile.ZIP_STORED
            zi.external_attr = 0o600 << 16
            dst.writestr(zi, data)
    return out.getvalue()


def export_predictors(path, final_rows, include_proposed=False):
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=PREDICTOR_COLUMNS, lineterminator="\n", extrasaction="ignore")
    w.writeheader()
    n = 0
    for r in final_rows:
        if not include_proposed and r["shown_as"] != "keep":
            continue
        w.writerow(r)
        n += 1
    Path(path).write_text(buf.getvalue(), encoding="utf-8")
    return n


def parse(argv=None):
    ap = argparse.ArgumentParser(description="Build the feature workbook from the feature CSVs.")
    ap.add_argument("--predictors", default=str(ROOT / "fraud" / "configs" / "predictors.csv"))
    ap.add_argument("--plan", default=str(ROOT / "docs" / "fraud_detection_plan_detailed.md"))
    ap.add_argument("--tfm", default=str(NF_DIR / "DRAFT_TFM_FIELDS_UNCONFIRMED.csv"))
    ap.add_argument("--f15298", default=str(NF_DIR / "DRAFT_15298_RECIPES_UNCONFIRMED.csv"))
    ap.add_argument("--other", default=str(NF_DIR / "DRAFT_OTHER_PROPOSED_UNCONFIRMED.csv"))
    ap.add_argument("--attributes", default=str(NF_DIR / "DRAFT_FEATURE_ATTRIBUTES_UNCONFIRMED.csv"))
    ap.add_argument("--decisions", default=str(NF_DIR / "KEEP_DECISIONS.csv"))
    ap.add_argument("--field-map", default="", help="default NF/FIELD_MAP.csv if it exists")
    ap.add_argument("--out", default=str(NF_DIR / "FEATURE_WORKBOOK_REVIEWERS_SUGGESTIONS.xlsx"))
    ap.add_argument("--export-predictors", default="", help="also write the Final list as a predictor list")
    ap.add_argument("--a1-adopted", choices=["yes", "no", "unknown"], default="unknown",
                    help="whether A1 was adopted (the A1 read): a row in both lists enters at A2 when it was not")
    ap.add_argument("--include-proposed", action="store_true",
                    help="also export keep rows still proposed (not decided by a person); a draft only")
    return ap.parse_args(argv)


def main(argv=None):
    args = parse(argv)
    try:
        data = load(args)
    except InputError as e:
        print(f"refused: {e}")
        return ARGS
    problems = validate(data)
    if problems:
        print(f"refused: {len(problems)} problem(s) in the inputs")
        for p in problems:
            print(f"  {p}")
        return ARGS
    wb, tables = build_workbook(data)
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_bytes(stable_bytes(wb))
    print(TITLE)
    print(f"workbook: {Path(args.out).name}")
    for name in SHEETS[1:]:
        print(f"  {name}: {len(tables[name][1])} rows")
    _, keep = data["keep"]
    print("  verdicts: " + ", ".join(f"{k} {sum(1 for d in keep if d['verdict'] == k)}" for k in VERDICTS))
    if args.export_predictors:
        n = export_predictors(args.export_predictors, tables["Final list (draft)"][1], args.include_proposed)
        print(f"predictor list: {Path(args.export_predictors).name} ({n} rows)")
    return OK


if __name__ == "__main__":
    sys.exit(main())
