"""Module resolver for the new-fields tools.

The pod has been reorganized, but we do not know exactly how it turned out. Every tool imports project code
through this file. It tries the reorganized names first and falls back to the pre-reorganization names. It prints
which layout it found and each module's file. If some names exist only in one layout and others only in the
other, it stops with exit 4 and lists them. Importing this file does no work.

Usage from a tool in this folder:

    import nf_layout
    nf_layout.bootstrap()
    lay = nf_layout.resolve(["scorer", "business_metrics"])
    nf_layout.print_layout(lay)
    alert = nf_layout.attr("business_metrics", "_alert")
"""
import importlib
import importlib.util
import sys
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]

REORGANIZED = "reorganized"
FALLBACK = "pre-reorganization (fallback)"
EXIT_REFUSED = 4

# key -> (reorganized names, fallback names). A name is a dotted module, or "path:<relative file>" for a module
# loaded by path. A key with two fallback names is split across two modules there.
TABLE = {
    "trainer": (["fraud.scripts.train_sequential_hier"], ["waqas.v2.scripts.train_v2"]),
    "scorer": (["fraud.scripts.score_sequential_hier"], ["waqas.v2.scripts.score_v2"]),
    "te_model": (["fraud.sequential_hier_target_ending_model"], ["waqas.v2.models"]),
    "base_model": (["fraud.sequential_hier_model"], ["waqas.phase4b.sequential_hier"]),
    "factory": (["fraud.sequential_hier_factory"], ["waqas.phase4b.factory"]),
    "sequence_builder": (["fraud.data.sequence_builder"], ["waqas.phase4b.sequence_builder"]),
    "target_ending": (["fraud.data.target_ending"], ["waqas.v2.target_ending"]),
    "business_metrics": (["fraud.scripts.business_metrics"], ["waqas.v2.analysis.business_metrics"]),
    "raw_join": (["fraud.scripts.compare_models"], ["waqas.v2.analysis.paired_v2"]),
    "input_contract": (["fraud.data.input_contract"], ["waqas.base.data.contracts"]),
    "input_checks": (["fraud.data.input_checks"], ["waqas.base.data.input_contracts"]),
    "s3": (["fraud.data.s3_utils"], ["fraud.data.s3_utils", "waqas.v2.storage"]),
    "prediction_files": (["fraud.data.prediction_files"], ["waqas.scoring._prediction_utils", "waqas.v2.benchmark_v2"]),
    "preprocessing": (["fraud.data.preprocessing"], ["fraud.data.preprocessing"]),
    "feature_list": (["fraud.data.feature_list"], ["fraud.data.feature_list"]),
    "datetime_features": (["fraud.data.datetime_features"], ["fraud.data.datetime_features"]),
    "source_files": (["fraud.source_files"], ["waqas.source_identity"]),
    "strict_window": (["fraud.experiments.features.strict_window"], ["waqas.v2.features.strict_window"]),
    "groups": (["fraud.experiments.features.groups"], ["waqas.v2.features.groups"]),
    "features_new": (["path:fraud/experiments/features/screen/features_new.py"], ["path:waqas/v2/screen/features_new.py"]),
    "export_embeddings": (["fraud.experiments.embedding.export_embeddings"], ["waqas.v2.export_v2"]),
    "check_export": (["fraud.experiments.embedding.check_export"], ["waqas.v2.scripts.l4_check"]),
    "export_records": (["fraud.experiments.embedding.export_records"], ["waqas.v2.scripts.make_v2_contracts"]),
    "downstream_xgb": (["fraud.experiments.embedding.downstream_xgb"], ["waqas.v2.downstream_xgb"]),
}
KEYS = tuple(TABLE)

# Attributes the tools use (DESIGN.md section 1). check_attributes() names any that are missing.
# token_encoder is an attribute of a built model instance, not of the module, so it is checked by the tool that
# builds the model (the attention tool), not here.
REQUIRED_ATTRS = {
    "trainer": ["source_sha256", "source_files", "run_identity", "check_batch_plan", "eval_batch_size",
                "MAX_STAGE1_ROWS"],
    "scorer": ["load_for_scoring", "select", "_model_inputs", "POPULATIONS"],
    "business_metrics": ["_alert", "_ranking"],
    "raw_join": ["load_raw", "target_mask"],
}


@dataclass
class Layout:
    layout: str
    root: Path
    modules: dict = field(default_factory=dict)   # key -> module, or list of modules for a split key
    paths: dict = field(default_factory=dict)     # key -> Path, or list of Paths
    names: dict = field(default_factory=dict)     # key -> dotted name(s) used
    missing: list = field(default_factory=list)   # keys found in neither layout (not requested)


class LayoutError(SystemExit):
    """Exit 4 with a message. A SystemExit, so a tool that does not catch it stops with code 4."""

    def __init__(self, message):
        print(message, file=sys.stderr)
        super().__init__(EXIT_REFUSED)
        self.message = message


def bootstrap(root=None):
    """Put the root and root/src first on sys.path. Idempotent."""
    root = Path(root) if root else ROOT
    for p in (str(root / "src"), str(root)):
        while p in sys.path:
            sys.path.remove(p)
    sys.path[:0] = [str(root), str(root / "src")]


def _file_of(name, root):
    """The file a module name would load from under root, or None. No import happens."""
    if name.startswith("path:"):
        p = root / name[5:]
        return p if p.is_file() else None
    rel = Path(*name.split("."))
    for cand in (root / rel.with_suffix(".py"), root / rel / "__init__.py",
                 root / "src" / rel.with_suffix(".py"), root / "src" / rel / "__init__.py"):
        if cand.is_file():
            return cand
    return None


def _found(names, root):
    files = [_file_of(n, root) for n in names]
    return files if all(files) else None


def _discriminating(key):
    reo, fb = TABLE[key]
    return set(reo) != set(fb) and not set(reo) <= set(fb)


def detect(root=None):
    """Decide the layout from files on disk. Returns (layout, report) where report maps each key to
    (reorganized_found, fallback_found). Raises LayoutError (exit 4) on a mix."""
    root = Path(root) if root else ROOT
    report = {k: (_found(TABLE[k][0], root) is not None, _found(TABLE[k][1], root) is not None) for k in KEYS}
    only_reo = [k for k in KEYS if _discriminating(k) and report[k][0] and not report[k][1]]
    only_fb = [k for k in KEYS if _discriminating(k) and report[k][1] and not report[k][0]]
    if only_reo and only_fb:
        lines = ["layout: MIXED, refused (exit 4). Names found only in one layout:"]
        lines += [f"  reorganized only: {k} = {', '.join(TABLE[k][0])}" for k in only_reo]
        lines += [f"  fallback only:    {k} = {', '.join(TABLE[k][1])}" for k in only_fb]
        lines.append("Copilot: adapt the names in TABLE of nf_layout.py to the pod, or finish the reorganization.")
        raise LayoutError("\n".join(lines))
    # Some reorganized names also exist before the reorganization with another meaning (fraud/data/sequence_builder.py
    # is the first model's builder there). So a name found in both layouts does not decide; names found in one only do.
    if only_fb:
        return FALLBACK, report
    if only_reo or any(report[k][0] for k in KEYS if _discriminating(k)):
        return REORGANIZED, report
    return FALLBACK, report


def _load(name, root):
    if name.startswith("path:"):
        p = root / name[5:]
        modname = "nf_bypath_" + p.stem
        if modname in sys.modules and getattr(sys.modules[modname], "__file__", None) == str(p):
            return sys.modules[modname]
        spec = importlib.util.spec_from_file_location(modname, p)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[modname] = mod
        spec.loader.exec_module(mod)
        return mod
    return importlib.import_module(name)


def resolve(keys=None, root=None):
    """Import the modules for keys (all keys if None) in the detected layout. Exit 4 on a mix, on a requested
    key found in neither layout, or on a module file outside the project root."""
    root = Path(root).resolve() if root else ROOT
    bootstrap(root)
    layout, report = detect(root)
    wanted = list(KEYS) if keys is None else [keys] if isinstance(keys, str) else list(keys)
    unknown = [k for k in wanted if k not in TABLE]
    if unknown:
        raise LayoutError(f"layout: unknown key(s) {', '.join(unknown)}; known: {', '.join(KEYS)}")
    lay = Layout(layout=layout, root=root)
    side = 0 if layout == REORGANIZED else 1
    for k in KEYS:
        names = TABLE[k][side]
        files = _found(names, root)
        if files is None:
            if k in wanted and keys is not None:
                raise LayoutError(f"layout: {layout}; {k} not found: {', '.join(names)} (exit 4)")
            lay.missing.append(k)
            continue
        if k not in wanted:
            continue
        mods = []
        for n in names:
            try:
                mods.append(_load(n, root))
            except ImportError as e:
                raise LayoutError(f"layout: {layout}; {k} = {n} failed to import: {e} (exit 4)")
        for n, m in zip(names, mods):
            mf = getattr(m, "__file__", None)
            if not mf or root not in Path(mf).resolve().parents:
                raise LayoutError(f"layout: {k} = {n} loads from {mf}, outside the project root {root} (exit 4)")
        lay.modules[k] = mods[0] if len(mods) == 1 else mods
        ps = [Path(m.__file__).resolve() for m in mods]
        lay.paths[k] = ps[0] if len(ps) == 1 else ps
        lay.names[k] = names[0] if len(names) == 1 else list(names)
    _CACHE.update(lay.modules)
    _CACHE["__layout__"] = lay
    return lay


_CACHE = {}


def get(key):
    """The module for one key (a list for a split key). Resolves it on first use."""
    if key not in _CACHE:
        resolve([key])
    return _CACHE[key]


def attr(key, name):
    """An attribute of a key's module, searched across a split key's modules in order. Exit 4 if missing."""
    mods = get(key)
    for m in mods if isinstance(mods, list) else [mods]:
        if hasattr(m, name):
            return getattr(m, name)
    raise LayoutError(f"layout: attribute {name} missing from {key} "
                      f"({', '.join(m.__name__ for m in (mods if isinstance(mods, list) else [mods]))}) (exit 4)")


def check_attributes(keys=None):
    """Check REQUIRED_ATTRS for keys (default: every key that has a list). Exit 4 naming the first missing one.
    POPULATIONS must hold OTHER."""
    for k in REQUIRED_ATTRS if keys is None else keys:
        for a in REQUIRED_ATTRS.get(k, []):
            attr(k, a)
    if keys is None or "scorer" in keys:
        if "OTHER" not in tuple(attr("scorer", "POPULATIONS")):
            raise LayoutError("layout: scorer POPULATIONS has no OTHER; RANK-A and RANK-B cannot be scored (exit 4)")
    return True


def layout_lines(lay):
    lines = [f"layout: {lay.layout}"]
    for k, p in lay.paths.items():
        ps = p if isinstance(p, list) else [p]
        rel = ", ".join(str(q.relative_to(lay.root)) if lay.root in q.parents else str(q) for q in ps)
        lines.append(f"  {k:<18} {rel}")
    if lay.missing:
        lines.append(f"  not found (not needed by this tool): {', '.join(lay.missing)}")
    return lines


def print_layout(lay):
    print("\n".join(layout_lines(lay)))


if __name__ == "__main__":
    try:
        lay = resolve()
    except LayoutError as e:
        sys.exit(e.code)
    print_layout(lay)
