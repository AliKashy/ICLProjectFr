"""Shared helpers for the new-fields tools: paths, exit codes, settings, hashes, JSON, config diff, the busy check,
the one-screen printer and the field map reader. Importing this file does no work."""
import hashlib
import json
import os
import re
import socket
import subprocess
import uuid
from pathlib import Path

NF = Path(__file__).resolve().parent
ROOT = NF.parents[3]
FS = ROOT / "fraud" / "experiments" / "features" / "field_screen"
TNF = ROOT / "tests" / "experiments" / "features" / "new_fields"
TFS = ROOT / "tests" / "experiments" / "features" / "field_screen"
C2 = Path(os.environ["NF_OUT"]).resolve() if os.environ.get("NF_OUT") else ROOT / "checkpoints" / "new_fields"

# Exit codes (stage 1's).
OK = 0
CRASH = 1
ARGS = 2
STOP = 3
REFUSED = 4
PARTIAL = 5

SCREEN_LINES = 40
SCREEN_WIDTH = 90


def c2():
    """C2, read again from the environment (tests set NF_OUT after import)."""
    return Path(os.environ["NF_OUT"]).resolve() if os.environ.get("NF_OUT") else ROOT / "checkpoints" / "new_fields"


def out(*parts):
    """A path under C2; its parent folders are made."""
    p = c2().joinpath(*[str(x) for x in parts])
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def rel(path):
    """A path relative to the project root when it lies under it, so screens never show an absolute path."""
    p = Path(path)
    try:
        return p.resolve().relative_to(ROOT).as_posix()
    except ValueError:
        return p.as_posix()


# ---------------------------------------------------------------- settings

SETTINGS_FILES = ("SETTINGS.yaml", "STEPS.yaml", "CHECK_THRESHOLDS.yaml", "STATUS_RULES.csv", "UPSTREAM.yaml")


def load_yaml(path):
    import yaml
    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f)
    return {} if data is None else data


def _settings_dir():
    return Path(os.environ["NF_SETTINGS_DIR"]) if os.environ.get("NF_SETTINGS_DIR") else NF


def settings():
    return load_yaml(_settings_dir() / "SETTINGS.yaml")


def steps():
    return load_yaml(_settings_dir() / "STEPS.yaml")


def thresholds():
    return load_yaml(_settings_dir() / "CHECK_THRESHOLDS.yaml")


def step_on(step):
    """A step's on switch. YAML 1.1 reads a bare key `on` as the boolean True, so both spellings are accepted."""
    v = step.get("on", step.get(True, False))
    return v is True or str(v).lower() in ("true", "yes", "on")


def upstream():
    return load_yaml(_settings_dir() / "UPSTREAM.yaml")


def settings_hashes():
    """Each settings file's SHA-256 (None if missing)."""
    d = _settings_dir()
    return {n: (sha256_file(d / n) if (d / n).is_file() else None) for n in SETTINGS_FILES}


def blank_approvals(cfg, sections):
    """Names of sections whose approved_by or approved_on is blank (design review item 20)."""
    missing = []
    for s in sections:
        node = cfg.get(s) if isinstance(cfg.get(s), dict) else {}
        if not str(node.get("approved_by") or "").strip() or not str(node.get("approved_on") or "").strip():
            missing.append(s)
    return missing


KEEP_DECISIONS_COLUMNS = ["name", "group", "verdict", "reason", "evidence", "decided_by", "date",
                          "definition_version"]


def person_decisions(path=None):
    """Rows of NF/KEEP_DECISIONS.csv that a person decided (decided_by not blank and not 'proposed'), by name. The
    last such row for a name wins. Tool proposals are ignored."""
    import csv
    p = Path(path) if path else NF / "KEEP_DECISIONS.csv"
    out = {}
    if not p.is_file():
        return out
    with open(p, encoding="utf-8") as f:
        for r in csv.DictReader(f):
            who = (r.get("decided_by") or "").strip()
            if who and who.lower() != "proposed" and (r.get("name") or "").strip():
                out[r["name"].strip()] = {k: (v or "").strip() for k, v in r.items() if k}
    return out


# ---------------------------------------------------------------- hashes and JSON

def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()


def sha256_file(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path, obj):
    """Atomic: written to a temporary file in the same folder, then renamed."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=True, default=str)
        f.write("\n")
    os.replace(tmp, path)
    return path


def append_jsonl(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(obj, sort_keys=True, default=str) + "\n")
    return path


def append_line(path, line):
    """Logs are appended, never truncated."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(line.rstrip("\n") + "\n")
    return path


def read_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def utc_now():
    import datetime as _dt
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ---------------------------------------------------------------- configs

ABSENT = "<absent>"


def _plain(cfg):
    try:
        from omegaconf import DictConfig, ListConfig, OmegaConf
        if isinstance(cfg, (DictConfig, ListConfig)):
            return OmegaConf.to_container(cfg, resolve=False)
    except ImportError:
        pass
    return cfg


def flatten(cfg, prefix=""):
    """Nested mappings to dotted keys. Lists are values."""
    cfg = _plain(cfg)
    flat = {}
    if isinstance(cfg, dict):
        for k, v in cfg.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            v = _plain(v)
            if isinstance(v, dict) and v:
                flat.update(flatten(v, key))
            else:
                flat[key] = v
    elif prefix:
        flat[prefix] = cfg
    return flat


def diff_configs(a, b):
    """Sorted (key, a_value, b_value) for every dotted key whose value differs; a missing key shows ABSENT."""
    fa, fb = flatten(a), flatten(b)
    return [(k, fa.get(k, ABSENT), fb.get(k, ABSENT)) for k in sorted(set(fa) | set(fb))
            if fa.get(k, ABSENT) != fb.get(k, ABSENT)]


# ---------------------------------------------------------------- busy check (DESIGN.md 6.6, stage 1 rules 15.3
# with review item 23, design review item 19)

INTERP = r"(\S*/)?python(3(\.\d+)?)?(\s+-[WX]\s+\S+|\s+-[WX]\S+|\s+-[^\sWXm]\S*|\s+-m(?=\s))*\s+(-m\s+)?"
_PY_TARGETS = [
    r"fraud\.scripts\.(train|score)_\S*",
    r"waqas\.\S*\.(train|score)\S*",
    r"(\S*/)?(train_v2|score_v2|train_sequential\S*|score_sequential\S*)\.py",
    r"(\S*/)?(train_timed|width_timing|same_batch)\.py",                    # stage 1's GPU tools
    # this package's GPU tools, by their GPU subcommands only: width, chunks, encode, estimate, summary, lift and
    # use2 run on the CPU and never hold the GPU
    r"(\S*/)?nf_time_width\.py\s+(real|_attempt)",
    r"(\S*/)?nf_importance\.py\s+run",
    r"(\S*/)?nf_downstream\.py(?!\s+(lift|use2|-h|--help)(\s|$))",
    r"(\S*/)?nf_fit\.py",
    r"(\S*/)?fraud/experiments/embedding/export_embeddings\.py",
    r"fraud\.experiments\.embedding\.export_embeddings",
]
SHELL = r"(\S*/)?(ba)?sh(\s+-\S+)*\s+"
STAGE0_QUEUE_SCRIPTS = ["lr_screen.sh"]          # stage 0's queue; UPSTREAM.yaml stage0.queue_script adds its name
SHELL_SCRIPTS = ["run_all.sh", "nf_run_all.sh"]  # stage 1's queue and this queue
LOCK_NAMES = ("RUNNING.lock.json", "QUEUE.lock.json")
GPU_MIB_LIMIT = 1024
REAL_PROC = Path("/proc")
PROC_ROOT_ENV = "NF_PROC_ROOT"  # tests only: the process table busy() reads instead of /proc


def default_proc_root():
    """The process table busy() reads by default: /proc, or the folder named by NF_PROC_ROOT. Only tests set it (to an
    empty folder of their own), so that a trainer or another test run on the same machine does not make their queue
    busy. Never set it on the pod: there the check must see every process of the machine."""
    return Path(os.environ.get(PROC_ROOT_ENV) or REAL_PROC)


def _is_real_proc(root):
    """True when root is this machine's /proc, however it is written (/proc/, //proc, /proc/../proc, a link to it).
    A path that cannot be read (missing, a link loop) is not /proc."""
    root = Path(root)
    if root == REAL_PROC:
        return True
    try:
        return os.path.samefile(root, REAL_PROC)
    except (OSError, ValueError):
        return False


def proc_root_note():
    """One line while NF_PROC_ROOT names another table than /proc (tests only), else an empty string."""
    root = default_proc_root()
    return "" if _is_real_proc(root) else f"{PROC_ROOT_ENV} is set (tests only): the busy check reads {root}, not /proc"


def stage0_queue_script():
    """UPSTREAM.yaml stage0.queue_script, the stage 0 queue as Copilot adapted it, so every caller of busy() (the
    queue and the GPU tools started by hand) sees it. None when not given."""
    try:
        q = ((upstream() or {}).get("stage0") or {}).get("queue_script")
    except Exception:  # no UPSTREAM.yaml or no yaml module: the default list
        return None
    return Path(str(q)).name if q else None


def busy_patterns(extra_scripts=()):
    py = re.compile(r"^" + INTERP + r"(" + "|".join(_PY_TARGETS) + r")(\s|$)")
    q = stage0_queue_script()
    names = [re.escape(s) for s in list(STAGE0_QUEUE_SCRIPTS) + ([q] if q else []) + list(SHELL_SCRIPTS)
             + list(extra_scripts)]
    sh = re.compile(r"^" + SHELL + r"(\S*/)?(" + "|".join(names) + r")(\s|$)")
    return py, sh


def _proc_table(proc_root):
    table = {}
    for d in Path(proc_root).iterdir() if Path(proc_root).is_dir() else []:
        if not d.name.isdigit():
            continue
        try:
            raw = (d / "cmdline").read_bytes()
            stat = (d / "stat").read_text()
            ppid = int(stat.rsplit(")", 1)[1].split()[1])
        except (OSError, IndexError, ValueError):
            continue
        cmd = raw.replace(b"\0", b" ").decode("utf-8", "replace").strip()
        table[int(d.name)] = (ppid, cmd)
    return table


def _ours(table, my_pid):
    """Our PID, every parent and every descendant."""
    ours = {my_pid}
    p = my_pid
    while p in table:
        p = table[p][0]
        if p <= 0 or p in ours:
            break
        ours.add(p)
    ours.update(pid for pid in table if _descends(table, pid, my_pid))
    return ours


def _descends(table, pid, anc):
    seen = set()
    while pid in table and pid not in seen:
        seen.add(pid)
        pid = table[pid][0]
        if pid == anc:
            return True
    return False


PID_LIMIT = 2 ** 31     # a process id is a signed 32-bit number: a larger one names no process (os.kill refuses it)


def lock_pid(held):
    """The process id a lock record names, or None when it names no process: not a whole number, zero or less,
    or too large to be a process id. The one rule for every lock: the queue's lock (nf_plan), the trainer's lock
    and the busy check all read a lock's pid through it."""
    try:
        pid = int(held.get("pid"))
    except (AttributeError, TypeError, ValueError, OverflowError):
        return None
    return pid if 0 < pid < PID_LIMIT else None


def _pid_alive(pid):
    """Whether this host has the process and may signal it (pid already checked by lock_pid)."""
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def _nvidia(args, nvidia_smi):
    try:
        r = subprocess.run([nvidia_smi] + args, capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.TimeoutExpired):
        return None
    if r.returncode != 0:
        return None
    return [ln.strip() for ln in r.stdout.splitlines() if ln.strip()]


def busy(proc_root=None, nvidia_smi="nvidia-smi", lock_roots=None, my_pid=None, extra_scripts=()):
    """What makes the GPU busy, one line each; empty when free. Never matches its own command line.
    The process table is proc_root when given, else default_proc_root() (/proc unless a test sets NF_PROC_ROOT)."""
    me = my_pid is None
    my_pid = os.getpid() if my_pid is None else my_pid
    root = Path(proc_root) if proc_root is not None else default_proc_root()
    real = _is_real_proc(root)
    found = []
    if not real and not root.is_dir():
        found.append(f"process table {root} not found: nothing can be checked")
    table = _proc_table(root)
    ours = _ours(table, my_pid)
    py, sh = busy_patterns(extra_scripts)
    for pid in sorted(table):
        if pid in ours:
            continue
        cmd = table[pid][1]
        if py.match(cmd) or sh.match(cmd):
            found.append(f"process {pid}: {cmd}")
    if me and not real:
        # A test's own table: the GPU and lock checks below still see this process's real parents and children
        # (the queue's lock is held by its parent shell). No other process of the machine is read as busy from it.
        ours |= _ours(_proc_table(REAL_PROC), my_pid)
    apps = _nvidia(["--query-compute-apps=pid,process_name,used_memory", "--format=csv,noheader,nounits"], nvidia_smi)
    if apps is not None:
        foreign = [a for a in apps if a.split(",")[0].strip().isdigit() and int(a.split(",")[0]) not in ours]
        for a in foreign:
            found.append(f"gpu compute process: {a}")
        if not foreign:
            used = _nvidia(["--query-gpu=memory.used", "--format=csv,noheader,nounits"], nvidia_smi) or []
            ours_on_gpu = any(a.split(",")[0].strip().isdigit() and int(a.split(",")[0]) in ours for a in apps)
            for i, u in enumerate(used):
                try:
                    mib = float(u.split()[0])
                except (ValueError, IndexError):
                    continue
                if mib > GPU_MIB_LIMIT and not ours_on_gpu:
                    found.append(f"gpu {i}: {mib:.0f} MiB used with no process of ours listed")
    roots = lock_roots if lock_roots is not None else [ROOT / "runs" / "tuning", ROOT / "checkpoints", c2()]
    host = socket.gethostname()
    seen = set()
    for r in roots:
        r = Path(r)
        if not r.is_dir():
            continue
        for dirpath, dirnames, filenames in os.walk(r):
            for n in LOCK_NAMES:
                if n in filenames:
                    lp = Path(dirpath) / n
                    if lp in seen:
                        continue
                    seen.add(lp)
                    try:
                        held = read_json(lp)
                    except (OSError, ValueError):
                        held = None
                    if not isinstance(held, dict):
                        found.append(f"lock {rel(lp)}: unreadable")
                        continue
                    # The project folder is shared by the owner's workbenches (each its own pod and hostname). A
                    # lock that names another workbench is skipped here: its process uses that pod's GPU and CPU,
                    # not this pod's. The queue never replaces such a lock (nf_plan.owner_alive).
                    if held.get("hostname", host) != host:
                        continue
                    pid = lock_pid(held)    # the same rule as the queue's lock: a bad pid is never a crash here
                    if pid is None:
                        found.append(f"lock {rel(lp)}: names no process (pid {held.get('pid')!r}); if nothing "
                                     "runs, remove it")
                    elif _pid_alive(pid) and pid not in ours:
                        found.append(f"lock {rel(lp)}: pid {pid} alive since {held.get('utc')}")
    return found


# ---------------------------------------------------------------- one screen

def screen(title, lines, footer=None):
    """At most 40 lines of 90 characters. Long lines are cut with '...'; extra lines are replaced by an explicit
    '... N more lines' note. The title and the footer are always shown."""
    def cut(s):
        s = str(s).rstrip()
        return s if len(s) <= SCREEN_WIDTH else s[:SCREEN_WIDTH - 3] + "..."
    head = [cut(x) for x in str(title).splitlines()] or [""]
    foot = [] if footer is None else [cut(x) for x in (footer if isinstance(footer, (list, tuple)) else
                                                       str(footer).splitlines())]
    body = []
    for x in lines:
        body.extend(str(x).splitlines() or [""])
    room = SCREEN_LINES - len(head) - len(foot)
    if len(body) > room:
        keep = room - 1
        body = [cut(x) for x in body[:keep]] + [f"... {len(body) - keep} more lines"]
    else:
        body = [cut(x) for x in body]
    return "\n".join(head + body + foot)


def print_screen(title, lines, footer=None):
    text = screen(title, lines, footer)
    print(text)
    return text


def wrap(text, width=SCREEN_WIDTH, indent="  "):
    """A refusal or note in lines of at most 90 characters (continuation lines indented), so a photograph of it
    holds every word. A single word longer than the width (a long path) stays whole."""
    import textwrap
    out = []
    for line in str(text).splitlines() or [""]:
        out += textwrap.wrap(line, width=width, subsequent_indent=indent, break_long_words=False,
                             break_on_hyphens=False) or [""]
    return "\n".join(out)


def say(text, file=None):
    """Print a refusal or note wrapped at 90 characters (to the error stream by default)."""
    import sys
    print(wrap(text), file=sys.stderr if file is None else file)


# ---------------------------------------------------------------- free memory and CPUs (cgroup limits)
# One rule for the field checks and the CPU screen. The screen carries an identical copy and uses this one
# when it is present. Units: GiB (2**30 bytes), the field checks' unit.

GIB = 1 << 30
_NO_LIMIT = 1 << 60  # cgroup v1 writes a huge number for "no limit"


def _read_file(path):
    try:
        return Path(path).read_text()
    except (OSError, UnicodeDecodeError):
        return None


def _int(text):
    try:
        return int(str(text).strip().split()[0])
    except (ValueError, IndexError, TypeError):
        return None


def _stat(read, path, keys):
    have = {}
    for line in (read(path) or "").splitlines():
        k, _, v = line.partition(" ")
        have[k] = v
    for k in keys:
        if k in have:
            return _int(have[k])
    return None


def _cgroup_dirs(read, controller):
    """This process's cgroup folders for one controller (None: the cgroup v2 line '0::/path'), the most
    specific first, then each parent up to the mount root."""
    out = []
    for line in (read("/proc/self/cgroup") or "").splitlines():
        parts = line.strip().split(":", 2)
        if len(parts) != 3:
            continue
        ctrls, path = parts[1], parts[2].strip() or "/"
        if controller is None:
            if parts[0] != "0" or ctrls:
                continue
            roots = ["/sys/fs/cgroup", "/sys/fs/cgroup/unified"]
        else:
            if controller not in ctrls.split(","):
                continue
            roots = [f"/sys/fs/cgroup/{ctrls}", f"/sys/fs/cgroup/{controller}"]
        for root in dict.fromkeys(roots):
            p = path
            while True:
                out.append(root + ("" if p == "/" else p))
                if p == "/":
                    break
                p = p.rsplit("/", 1)[0] or "/"
    return list(dict.fromkeys(out))


def resource_limits(read=None, affinity=None):
    """Free memory and usable CPUs as this process's container sees them (design review item 27).

    free_gib, in GiB (2**30 bytes, the field checks' unit): the smaller of the host's MemAvailable and the
    cgroup headroom. The headroom is the memory limit minus the working set (usage minus inactive file cache,
    as the container runtime counts it), the smallest over this process's cgroup and its parents: cgroup v2
    (memory.max, memory.current, memory.stat) or v1 (memory.limit_in_bytes, memory.usage_in_bytes).
    cpus: the smaller of the CPUs this process may run on (sched_getaffinity) and the cgroup CPU quota (v2
    cpu.max, v1 cpu.cfs_quota_us over cpu.cfs_period_us), at least 1.
    `read(path) -> text or None` and `affinity` (a CPU count) are injectable for tests."""
    read = read or _read_file
    host = None
    for line in (read("/proc/meminfo") or "").splitlines():
        if line.startswith("MemAvailable:"):
            kb = _int(line.split(":", 1)[1])
            host = None if kb is None else kb * 1024 / GIB
    head = limit = None
    kind = "none"
    for ctl, lim_f, use_f, inact in ((None, "memory.max", "memory.current", ("inactive_file",)),
                                     ("memory", "memory.limit_in_bytes", "memory.usage_in_bytes",
                                      ("total_inactive_file", "inactive_file"))):
        for d in _cgroup_dirs(read, ctl):
            lim, use = _int(read(f"{d}/{lim_f}")), _int(read(f"{d}/{use_f}"))
            if lim is None or lim >= _NO_LIMIT or use is None:
                continue
            ws = max(0, use - (_stat(read, f"{d}/memory.stat", inact) or 0))
            h = max(0, lim - ws) / GIB
            if head is None or h < head:
                head, limit, kind = h, lim / GIB, ("v2" if ctl is None else "v1")
    quota = None
    for d in _cgroup_dirs(read, None):
        q = (read(f"{d}/cpu.max") or "").split()
        if len(q) == 2 and q[0] != "max" and _int(q[0]) and _int(q[1]):
            quota = min(quota or float("inf"), _int(q[0]) / _int(q[1]))
    for d in _cgroup_dirs(read, "cpu"):
        q, p = _int(read(f"{d}/cpu.cfs_quota_us")), _int(read(f"{d}/cpu.cfs_period_us"))
        if q and q > 0 and p:
            quota = min(quota or float("inf"), q / p)
    if affinity is None:
        try:
            affinity = len(os.sched_getaffinity(0))
        except (AttributeError, OSError):
            affinity = os.cpu_count() or 1
    cpus = int(affinity) if quota is None else min(int(affinity), max(1, int(quota)))
    free = host if head is None else (head if host is None else min(host, head))
    rnd = (lambda x: None if x is None else round(float(x), 2))
    return {"free_gib": rnd(free), "host_available_gib": rnd(host), "cgroup": kind, "cgroup_limit_gib": rnd(limit),
            "cgroup_headroom_gib": rnd(head), "cpus": max(1, cpus), "cpus_affinity": int(affinity),
            "cpu_quota": None if quota is None else round(quota, 3)}


# ---------------------------------------------------------------- field map (DESIGN.md 2.1 with the review columns)

FIELD_MAP_CORE = [
    "name", "group", "kind", "recipe", "source_columns", "model_type", "window", "lag", "as_of_rule",
    "definition_version", "tfm_name", "f15298_name", "v22b_rank", "f15298_rank", "excluded_by_sumegha",
    "sumegha_reason", "feasible_in_production", "feasibility_note", "external_score", "status_rule",
    "data_owner_fixed", "left_out_reason", "list_status", "list_source", "check_result", "check_reasons",
    "cluster_id", "kept_once_as", "notes",
]
# Design review items 2, 4 and 5 and the feature review: the workbook's columns, kept in the one map.
FIELD_MAP_REVIEW = [
    "output_name", "origin", "description", "yaqun_category", "business_category", "date_meaning",
    "mapping_status", "equivalence", "proposed_work_type", "next_definition_needed",
    # the permutation importance's donor (FEATURE_REVIEW.md): account for a profile field, event for an event field.
    # Blank takes the default from the kind of field (business_category "account and customer profile": account).
    "donor_unit",
]
PROFILE_CATEGORY = "account and customer profile"


def default_donor_unit(row):
    """account for a profile field, event for an event field (integration decision 7)."""
    get = (lambda k: "") if row is None else (lambda k: row.get(k, ""))
    given = str(get("donor_unit") or "").strip()
    if given:
        return given
    return "account" if str(get("business_category") or "").strip() == PROFILE_CATEGORY else "event"
FIELD_MAP_COLUMNS = FIELD_MAP_CORE + FIELD_MAP_REVIEW

YES_NO = ["yes", "no"]
ALLOWED = {
    "group": ["v22b", "f15298", "both", "a3"],
    "kind": ["raw", "engineered"],
    "model_type": ["", "continuous", "categorical"],   # blank only while the recipe is blank
    "check_result": ["", "PASS", "FLAG", "WAIT", "STOP"],
    "status_rule": ["", "none", "left_out_26oct", "rank52", "same_txn_decision", "status_like", "hold"],
    "list_status": ["UNCONFIRMED", "CONFIRMED", "NOT_IN_OWNER_LIST"],
    "excluded_by_sumegha": ["", "yes", "no"],     # blank: Sumegha's answer not recorded yet (never read as "no")
    "feasible_in_production": ["yes", "no", "unknown"],
    "external_score": ["", "yes", "no"],
    "data_owner_fixed": ["", "yes"],
    "origin": ["", "v22b", "f15298", "both", "a3", "proposed"],
    "yaqun_category": ["", "continuous", "categorical", "datetime_derived", "excluded"],
    "date_meaning": ["", "event_date", "known_future_date"],
    "mapping_status": ["", "open", "mapped"],
    "equivalence": ["", "unverified", "documented"],
    "donor_unit": ["", "event", "account"],
    "proposed_work_type": ["", "encoding_definition", "date_derivation", "transaction_history_definition",
                           "claim_history_definition", "event_history_definition", "recipe_definition",
                           "recorded_raw_mapping"],
}
YES_NO_COLUMNS = ["excluded_by_sumegha", "feasible_in_production", "external_score", "data_owner_fixed"]


class FieldMapError(SystemExit):
    def __init__(self, message):
        import sys
        print(wrap(message), file=sys.stderr)
        super().__init__(REFUSED)
        self.message = message


def read_field_map(path):
    """The map as strings, blanks as "". Refuses (exit 4) a missing core column of DESIGN.md 2.1. A missing review
    column is added blank and named in df.attrs['added_columns']. Extra columns are kept after the known ones."""
    import pandas as pd
    df = pd.read_csv(path, dtype=str, keep_default_na=False, na_filter=False)
    df.columns = [c.strip() for c in df.columns]
    missing = [c for c in FIELD_MAP_CORE if c not in df.columns]
    if missing:
        raise FieldMapError(f"field map {rel(path)}: missing column(s) {', '.join(missing)} (exit 4)")
    added = [c for c in FIELD_MAP_REVIEW if c not in df.columns]
    for c in added:
        df[c] = ""
    extra = [c for c in df.columns if c not in FIELD_MAP_COLUMNS]
    df = df[FIELD_MAP_COLUMNS + extra].copy()
    for c in df.columns:
        df[c] = df[c].astype(str).str.strip()
    df.attrs["added_columns"] = added
    return df


def write_field_map(df, path):
    """Writes the map with the known columns first, as strings."""
    extra = [c for c in df.columns if c not in FIELD_MAP_COLUMNS]
    d = df.copy()
    for c in FIELD_MAP_COLUMNS:
        if c not in d.columns:
            d[c] = ""
    d[FIELD_MAP_COLUMNS + extra].to_csv(path, index=False)
    return path
