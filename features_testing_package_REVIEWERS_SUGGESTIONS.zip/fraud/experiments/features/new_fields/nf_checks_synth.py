"""A small synthetic world for the field checks' dry run and tests. No bank data.

make_world(folder) writes training, validation and June-like parquet files in the raw
layout (account, transaction id, time, label, the base predictors of predictors.csv), a
field map with planted cases, a thresholds file, a status rules file and a config. Every
planted field has a known expected result (EXPECTED below), so a test can compare.

The base predictors come from the project's predictors.csv (names and types are read,
never typed here). The planted fields have synthetic names that start with `syn_`.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Callable, Dict, List, Optional

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[4]
ACC, TID, TIME, LAB = "Nmap_account_reference_xid", "fi_transaction_id", "transaction_dttm", "frd_tag"
TRAIN_FILES, VAL_FILES, JUNE_FILES = [1, 2, 3, 4], [4950, 4951], [8000, 8001]

# field -> (expected result, a rule that must fire, or "" for none)
EXPECTED = {
    "syn_clean_num": ("PASS", ""),
    "syn_clean_code": ("PASS", ""),
    "syn_clean_days": ("PASS", ""),
    "syn_count_24h": ("PASS", ""),
    "syn_date_after": ("STOP", "date_after_txn"),
    "syn_fill_only_fraud": ("STOP", "fill_only_fraud"),
    "syn_fill_after_fraud": ("STOP", "fill_after_fraud"),
    "syn_label_noisy": ("STOP", "too_good"),
    "syn_lookahead": ("STOP", "not_strictly_earlier"),
    "syn_change_at_event": ("FLAG", "change_at_event"),
    "syn_base_copy": ("STOP", "duplicate"),
    "syn_base_recode": ("STOP", "duplicate"),
    "syn_le_recode": ("STOP", "duplicate"),
    "syn_label_recode": ("STOP", "label_copy"),
    "syn_affine_num": ("STOP", "duplicate"),
    "syn_near_dup": ("FLAG", "near_duplicate"),
    # the reviewers' decision D3d: a month code repeats month on its present values (held), and a raw epoch
    # timestamp is a date entered as is (raw_date) that also tracks time
    "syn_month_code": ("WAIT", "repeats_month"),
    "syn_epoch": ("STOP", "raw_date"),
    "syn_june_shift": ("FLAG", "drift_june"),
    # a new code field is capped in the extended artifact (the reviewers' decisions D9-Y20 and D10): its unknown
    # shares are reported (capped_fields.txt), not stops
    "syn_int_nulls": ("FLAG", "drift_june"),
    "syn_text_num": ("STOP", "type_number_text"),
    "syn_date_as_num": ("STOP", "raw_date"),
    "syn_count_90d": ("STOP", "empty_june"),
    "syn_status_dt": ("WAIT", "status"),
    "syn_inactv_dt": ("STOP", "left_out_26oct"),
    "syn_vaa": ("FLAG", "external_score"),
    "syn_falcondecline": ("STOP", "same_txn_decision"),
    "syn_prev_falcondecline": ("WAIT", "lagged_decision"),
    "syn_excluded": ("STOP", "excluded_by_sumegha"),
    "syn_left_out": ("STOP", "left_out_recipe"),
    "syn_hold": ("WAIT", "hold"),
    "syn_expiry": ("FLAG", "date_future_by_meaning"),
    "syn_missing_col": ("STOP", "missing_from_files"),
    # design review items 5, 6, 9, 11, 13 and 28
    "syn_same_day": ("STOP", "same_day_date"),
    "cprsyn_refresh": ("STOP", "same_day_refresh"),
    "syn_reissue": ("STOP", "reissue_change"),
    "syn_proxy": ("STOP", "pre_event_proxy"),
    "syn_coarse": ("STOP", "function_of"),
    "syn_fine": ("FLAG", "refines"),
    "syn_count_zero": ("STOP", "not_strictly_earlier"),
    "syn_prev_fill_only": ("STOP", "inherited"),
}


def base_table() -> pd.DataFrame:
    p = ROOT / "fraud/configs/predictors.csv"
    return pd.read_csv(p, dtype=str, keep_default_na=False)


def _accounts(rng, n_acct: int, start: str, end: str, prefix: str, fraud_share: float):
    """Rows for n_acct accounts between start and end; fraud accounts turn fraud from a random row on."""
    t0, t1 = pd.Timestamp(start).value // 10**9, pd.Timestamp(end).value // 10**9
    rows = []
    for a in range(n_acct):
        k = int(rng.integers(6, 30))
        ts = np.sort(rng.integers(t0, t1, k))
        # some same-second siblings
        dup = rng.random(k) < 0.08
        for i in np.flatnonzero(dup):
            if i > 0:
                ts[i] = ts[i - 1]
        ts = np.sort(ts)
        fraud = np.zeros(k, dtype=int)
        if rng.random() < fraud_share:
            f0 = int(rng.integers(1, k))
            fraud[f0:f0 + int(rng.integers(1, 4))] = 1
            # an earlier row on the first fraud's day (for the same-day refresh rule)
            lo = ts[f0 - 2] if f0 >= 2 else ts[f0] - 3600
            ts[f0 - 1] = max(lo, ts[f0] - 600)
        for i in range(k):
            rows.append((f"{prefix}{a:05d}", ts[i], fraud[i]))
    df = pd.DataFrame(rows, columns=[ACC, "_ts", LAB])
    df[TIME] = pd.to_datetime(df["_ts"], unit="s")
    return df.drop(columns="_ts")


def _base_values(df, rng, bt):
    for _, r in bt.iterrows():
        if str(r["source"]) != "raw":
            continue
        if r["type"] == "continuous":
            df[r["feature"]] = np.round(rng.gamma(2.0, 50.0, len(df)), 2)
        else:
            k = 3 + sum(map(ord, r["feature"])) % 5   # a fixed vocabulary size per column
            df[r["feature"]] = rng.choice([f"v{i}" for i in range(k)], len(df))
    return df


def _planted(df, rng, bt, june: bool = False):
    n = len(df)
    y = df[LAB].to_numpy()
    t = df[TIME]
    cont = [r["feature"] for _, r in bt.iterrows() if r["type"] == "continuous" and r["source"] == "raw"]
    cats = [r["feature"] for _, r in bt.iterrows() if r["type"] == "categorical" and r["source"] == "raw"]
    ext = [c for c in cont if c.startswith("external_")] or cont[1:2]
    amt = cont[0]
    df["syn_clean_num"] = np.where(rng.random(n) < 0.1, np.nan, rng.normal(0, 1, n))
    df["syn_clean_code"] = rng.choice(["a", "b", "c", "d", "e"], n)
    df["syn_clean_date_src"] = t - pd.to_timedelta(rng.integers(1, 500, n), unit="D")
    df["syn_date_after_src"] = t - pd.to_timedelta(rng.integers(1, 300, n), unit="D")
    late = (y == 1) & (rng.random(n) < 0.7)
    df.loc[late, "syn_date_after_src"] = t[late] + pd.to_timedelta(rng.integers(1, 20, int(late.sum())), unit="D")
    df["syn_fill_only_fraud"] = np.where(y == 1, rng.normal(0, 1, n), np.nan)
    # filled from the first fraud on in fraud accounts; mostly empty before
    first = df.assign(_f=np.where(y == 1, df[TIME].astype("int64"), np.iinfo(np.int64).max)) \
        .groupby(ACC)["_f"].transform("min").to_numpy()
    after = df[TIME].astype("int64").to_numpy() >= first
    base_fill = rng.random(n) < 0.3
    df["syn_fill_after_fraud"] = np.where(after | base_fill, rng.normal(0, 1, n), np.nan)
    df["syn_label_noisy"] = y + rng.normal(0, 0.3, n)
    # a new code at the first fraud row (a new device, for example); the code is otherwise stable per account
    acct_code = df[ACC].map({a: f"dev{i % 7}" for i, a in enumerate(sorted(df[ACC].unique()))})
    at_first = df[TIME].astype("int64").to_numpy() == first
    other_new = rng.random(n) < 0.05
    df["syn_change_at_event"] = np.where(at_first | other_new, "devnew", acct_code)
    df["syn_base_copy"] = df[cats[0]]
    df["syn_base_recode"] = df[cats[1]].map(lambda v: f"R{v}")
    df["syn_le_recode"] = df["syn_clean_code"].map({"a": 0, "b": 1, "c": 2, "d": 3, "e": 4}).astype(int)
    df["syn_label_recode"] = np.where(y == 1, "Y", "N")
    df["syn_affine_num"] = 2.0 * df[amt] + 5.0
    df["syn_near_dup"] = df[amt] + rng.normal(0, 2.0, n)
    mon = t.dt.month.to_numpy()
    shift = rng.random(n) < 0.1
    df["syn_month_code"] = np.where(shift, (mon % 12) + 1, mon)
    df["syn_epoch"] = t.to_numpy(dtype="datetime64[s]").astype(np.int64) + rng.integers(0, 3600, n)
    df["syn_june_shift"] = rng.normal(5.0 if june else 0.0, 1.0, n)
    df["syn_text_num"] = np.where(rng.random(n) < 0.05, "n/a", np.round(rng.normal(0, 1, n), 3).astype(str))
    df["syn_date_as_num"] = t - pd.to_timedelta(rng.integers(1, 100, n), unit="D")
    df["syn_status_dt"] = rng.normal(0, 1, n)
    df["syn_inactv_dt"] = rng.normal(0, 1, n)
    df["syn_vaa"] = df[ext[0]] + rng.normal(0, 30.0, n)
    df["syn_falcondecline"] = rng.choice(["0", "1"], n, p=[0.9, 0.1])
    df["syn_excluded"] = rng.normal(0, 1, n)
    df["syn_left_out"] = rng.normal(0, 1, n)
    df["syn_hold"] = rng.normal(0, 1, n)
    df["syn_expiry_src"] = t + pd.to_timedelta(rng.integers(30, 1500, n), unit="D")
    # a date-only source set on the fraud day for frauds (a block or reset date), else long before
    past = (t - pd.to_timedelta(rng.integers(5, 400, n), unit="D")).dt.normalize()
    df["syn_same_day_src"] = np.where(y == 1, t.dt.normalize(), past).astype("datetime64[ns]")
    # a profile value refreshed by day: every row of the first fraud's day shows the new value
    tday = t.dt.normalize().astype("int64").to_numpy()
    fday = df.assign(_d=np.where(t.astype("int64").to_numpy() == first, tday, np.iinfo(np.int64).max)) \
        .groupby(ACC)["_d"].transform("min").to_numpy()
    prof = df[ACC].map({a: f"p{i % 5}" for i, a in enumerate(sorted(df[ACC].unique()))}).to_numpy()
    df["cprsyn_refresh"] = np.where(tday >= fday, "pnew", prof)
    # an expiry that is constant per account and changes at the first fraud (a reissued card)
    exp0 = pd.Series(t.min() + pd.Timedelta(900, unit="D"), index=df.index)
    acct_shift = df[ACC].map({a: i % 300 for i, a in enumerate(sorted(df[ACC].unique()))})
    exp0 = exp0 + pd.to_timedelta(acct_shift, unit="D")
    reissued = df[TIME].astype("int64").to_numpy() >= first
    df["syn_reissue_src"] = np.where(reissued, exp0 + pd.Timedelta(1095, unit="D"), exp0).astype("datetime64[ns]")
    # a mark on every row of accounts that later turn fraud (a fraud-proxy snapshot)
    fraud_acct = (first < np.iinfo(np.int64).max)
    df["syn_proxy"] = np.where(fraud_acct, "Y", "N")
    cats2 = df[cats[2]].astype(str)
    vals = sorted(cats2.unique())
    df["syn_coarse"] = cats2.map({v: ("g1" if i < max(1, len(vals) // 2) else "g2") for i, v in enumerate(vals)})
    df["syn_fine"] = df[cats[3]].astype(str) + "_" + rng.choice(["x", "y"], n)
    return df


def _write(df: pd.DataFrame, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(path, index=False)


MAP_ROWS = [
    # name, group, kind, recipe, source_columns, model_type, extra
    ("syn_clean_num", "v22b", "raw", "raw", "syn_clean_num", "continuous", {}),
    ("syn_clean_code", "v22b", "raw", "raw", "syn_clean_code", "categorical", {}),
    ("syn_clean_days", "v22b", "engineered", "days_before(syn_clean_date_src)", "syn_clean_date_src", "continuous", {}),
    ("syn_count_24h", "f15298", "engineered", "count(24h)", "transaction_dttm", "continuous", {}),
    ("syn_date_after", "v22b", "engineered", "days_before(syn_date_after_src)", "syn_date_after_src", "continuous", {}),
    ("syn_fill_only_fraud", "v22b", "raw", "raw", "syn_fill_only_fraud", "continuous", {}),
    ("syn_fill_after_fraud", "v22b", "raw", "raw", "syn_fill_after_fraud", "continuous", {}),
    ("syn_label_noisy", "v22b", "raw", "raw", "syn_label_noisy", "continuous", {}),
    ("syn_lookahead", "f15298", "engineered", "dryrun_next_value(transaction_amt)", "transaction_amt", "continuous", {}),
    ("syn_change_at_event", "v22b", "raw", "raw", "syn_change_at_event", "categorical", {}),
    ("syn_base_copy", "v22b", "raw", "raw", "syn_base_copy", "categorical", {}),
    ("syn_base_recode", "v22b", "raw", "raw", "syn_base_recode", "categorical", {}),
    ("syn_le_recode", "f15298", "raw", "raw", "syn_le_recode", "categorical", {}),
    ("syn_label_recode", "v22b", "raw", "raw", "syn_label_recode", "categorical", {}),
    ("syn_affine_num", "v22b", "raw", "raw", "syn_affine_num", "continuous", {}),
    ("syn_near_dup", "v22b", "raw", "raw", "syn_near_dup", "continuous", {}),
    ("syn_month_code", "v22b", "raw", "raw", "syn_month_code", "categorical", {}),
    ("syn_epoch", "v22b", "raw", "raw", "syn_epoch", "continuous", {}),
    ("syn_june_shift", "v22b", "raw", "raw", "syn_june_shift", "continuous", {}),
    ("syn_int_nulls", "v22b", "raw", "raw", "syn_int_nulls", "categorical", {}),
    ("syn_text_num", "v22b", "raw", "raw", "syn_text_num", "continuous", {}),
    ("syn_date_as_num", "v22b", "raw", "raw", "syn_date_as_num", "continuous", {}),
    ("syn_count_90d", "f15298", "engineered", "count(90d)", "transaction_dttm", "continuous", {}),
    ("syn_status_dt", "v22b", "raw", "raw", "syn_status_dt", "continuous", {}),
    ("syn_inactv_dt", "v22b", "raw", "raw", "syn_inactv_dt", "continuous", {}),
    ("syn_vaa", "v22b", "raw", "raw", "syn_vaa", "continuous", {"external_score": "yes"}),
    ("syn_falcondecline", "v22b", "raw", "raw", "syn_falcondecline", "categorical", {}),
    ("syn_prev_falcondecline", "v22b", "engineered", "prev(syn_falcondecline)", "syn_falcondecline", "categorical", {}),
    ("syn_excluded", "v22b", "raw", "raw", "syn_excluded", "continuous",
     {"excluded_by_sumegha": "yes", "sumegha_reason": "not feasible in production"}),
    ("syn_left_out", "f15298", "raw", "raw", "syn_left_out", "continuous",
     {"left_out_reason": "reads an outcome with no known-at date"}),
    ("syn_hold", "v22b", "raw", "raw", "syn_hold", "continuous", {"status_rule": "hold"}),
    ("syn_expiry", "v22b", "engineered", "days_until(syn_expiry_src)", "syn_expiry_src", "continuous",
     {"date_meaning": "known_future_date"}),
    ("syn_missing_col", "v22b", "raw", "raw", "syn_missing_col", "continuous", {}),
    ("syn_same_day", "v22b", "engineered", "days_before(syn_same_day_src)", "syn_same_day_src", "continuous", {}),
    ("cprsyn_refresh", "v22b", "raw", "raw", "cprsyn_refresh", "categorical", {}),
    ("syn_reissue", "v22b", "engineered", "days_until(syn_reissue_src)", "syn_reissue_src", "continuous",
     {"date_meaning": "known_future_date"}),
    ("syn_proxy", "v22b", "raw", "raw", "syn_proxy", "categorical", {}),
    ("syn_coarse", "f15298", "raw", "raw", "syn_coarse", "categorical", {}),
    ("syn_fine", "f15298", "raw", "raw", "syn_fine", "categorical", {}),
    ("syn_count_zero", "f15298", "engineered", "dryrun_count_zero(48h)", "transaction_dttm", "continuous", {}),
    ("syn_prev_fill_only", "f15298", "engineered", "prev(syn_fill_only_fraud)", "syn_fill_only_fraud", "continuous",
     {}),
]

MAP_COLUMNS = ["name", "group", "kind", "recipe", "source_columns", "model_type", "window", "lag", "as_of_rule",
               "definition_version", "tfm_name", "f15298_name", "v22b_rank", "f15298_rank", "excluded_by_sumegha",
               "sumegha_reason", "feasible_in_production", "feasibility_note", "external_score", "status_rule",
               "data_owner_fixed", "left_out_reason", "list_status", "list_source", "check_result", "check_reasons",
               "cluster_id", "kept_once_as", "notes", "date_meaning"]


def map_columns() -> List[str]:
    """The settings lane's field-map columns when its module is present, else the list above."""
    try:
        import importlib.util
        import sys
        here = Path(__file__).resolve().parent
        mod = sys.modules.get("nf_common")
        if mod is None:
            spec = importlib.util.spec_from_file_location("nf_common", here / "nf_common.py")
            mod = importlib.util.module_from_spec(spec)
            sys.modules["nf_common"] = mod
            spec.loader.exec_module(mod)
        cols = list(mod.FIELD_MAP_COLUMNS)
        return cols + [c for c in MAP_COLUMNS if c not in cols]
    except Exception:
        return list(MAP_COLUMNS)


def field_map(rows=None, columns: Optional[List[str]] = None) -> pd.DataFrame:
    cols = columns or map_columns()
    out = []
    for name, group, kind, recipe, src, mt, extra in (rows or MAP_ROWS):
        r = {c: "" for c in cols}
        r.update({"name": name, "group": group, "kind": kind, "recipe": recipe, "source_columns": src,
                  "model_type": mt, "definition_version": "1", "excluded_by_sumegha": "no",
                  "feasible_in_production": "yes", "external_score": "no", "list_status": "UNCONFIRMED"})
        r.update(extra)
        out.append(r)
    return pd.DataFrame(out, columns=cols)


THRESHOLDS_TEXT = """# Synthetic thresholds for the dry run (the same values as the design's defaults)
min_free_gb: 0
stop:
  control_val_ap: 0.137146
  date_after_txn_rows: 0.001
  date_after_txn_fraud: 0.01
flag:
  cluster_threshold: 0.8
"""


def make_world(folder: Path, seed: int = 7, n_acct: int = 400) -> Dict:
    folder = Path(folder)
    rng = np.random.default_rng(seed)
    bt = base_table()
    train_base, june_base = folder / "raw", folder / "raw_eval"
    tid = 0
    for i, n in enumerate(TRAIN_FILES + VAL_FILES):
        df = _accounts(rng, n_acct, "2024-10-01", "2025-05-31", f"A{n}_", 0.12)
        df = _base_values(df, rng, bt)
        df = _planted(df, rng, bt)
        df[TID] = [f"t{tid + k}" for k in range(len(df))]
        tid += len(df)
        # an integer code with nulls in the first fit file only (stored as float there)
        codes = rng.integers(1, 5, len(df)).astype(float)
        if n == TRAIN_FILES[0]:
            codes[rng.random(len(df)) < 0.05] = np.nan
            df["syn_int_nulls"] = codes
        else:
            df["syn_int_nulls"] = codes.astype(np.int64)
        df["syn_missing_col"] = rng.normal(0, 1, len(df))
        _write(df, train_base / f"part_{n}.parquet")
    for n in JUNE_FILES:
        df = _accounts(rng, n_acct, "2025-05-01", "2025-06-30", f"J{n}_", 0.12)
        df = _base_values(df, rng, bt)
        june = (df[TIME] >= "2025-06-01").to_numpy()
        df = _planted(df, rng, bt, june=False)
        df.loc[june, "syn_june_shift"] = rng.normal(5.0, 1.0, int(june.sum()))
        df[TID] = [f"t{tid + k}" for k in range(len(df))]
        tid += len(df)
        df["syn_int_nulls"] = rng.integers(1, 5, len(df)).astype(np.int64)
        # syn_missing_col is absent from the evaluation files
        _write(df, june_base / f"part_{n}.parquet")
    fm = field_map()
    fm.to_csv(folder / "FIELD_MAP.csv", index=False)
    (folder / "CHECK_THRESHOLDS.yaml").write_text(THRESHOLDS_TEXT)
    apps = "name;tfm_name;f15298_name;source_columns"
    pd.DataFrame([{"rule": "left_out_26oct", "pattern": "SYN_INACTV_DT", "match": "exact_ci", "applies_to": apps,
                   "result": "STOP", "reason": "planted"},
                  {"rule": "status_like", "pattern": "status", "match": "substring_ci", "applies_to": apps,
                   "result": "WAIT", "reason": "planted"},
                  {"rule": "same_txn_decision", "pattern": "falcondecline", "match": "token_ci", "applies_to": apps,
                   "result": "STOP", "reason": "planted"}]).to_csv(folder / "STATUS_RULES.csv", index=False)
    bt.to_csv(folder / "predictors.csv", index=False)
    cfg = {"predictors": {"csv_path": str(folder / "predictors.csv")},
           "data": {"target_col": LAB, "order_col": TIME, "account_col": ACC, "tie_break_col": TID,
                    "train_base": str(train_base), "train_start": TRAIN_FILES[0], "train_end": TRAIN_FILES[-1],
                    "val_base": str(train_base), "val_start": VAL_FILES[0], "val_end": VAL_FILES[-1]},
           "eval": {"base": str(june_base)}}
    import yaml
    (folder / "config.yaml").write_text(yaml.safe_dump(cfg))
    return {"folder": folder, "map": folder / "FIELD_MAP.csv", "thresholds": folder / "CHECK_THRESHOLDS.yaml",
            "status_rules": folder / "STATUS_RULES.csv", "predictors": folder / "predictors.csv",
            "config": folder / "config.yaml", "train_base": str(train_base), "val_base": str(train_base),
            "june_base": str(june_base), "train_files": f"{TRAIN_FILES[0]}-{TRAIN_FILES[-1]}",
            "val_files": f"{VAL_FILES[0]}-{VAL_FILES[-1]}", "june_files": f"{JUNE_FILES[0]}-{JUNE_FILES[-1]}",
            "fit_files": f"{TRAIN_FILES[0]}-{TRAIN_FILES[1]}", "dup_files": f"{TRAIN_FILES[0]},{TRAIN_FILES[1]}",
            "confirm_file": str(TRAIN_FILES[2])}


# ---------------------------------------------------------------------------
# Small builders for the dry run and tests. The real recipes live in nf_recipes.py (the data
# step); these follow the same rules (same account, strictly earlier whole seconds, censored
# windows are missing) for the few recipes the synthetic map uses, plus one planted look-ahead.
# ---------------------------------------------------------------------------
WINDOWS = {"5m": 300, "1h": 3600, "24h": 86400, "48h": 172800, "7d": 604800, "14d": 1209600,
           "30d": 2592000, "90d": 7776000}


def _arg(recipe: str) -> str:
    return recipe[recipe.index("(") + 1:recipe.rindex(")")].split(";")[0].strip()


def _sorted_keys(frame):
    acct, _ = pd.factorize(frame[ACC].astype(str))
    sec = pd.to_datetime(frame[TIME]).to_numpy(dtype="datetime64[s]").astype(np.int64)
    return acct.astype(np.int64), sec


def build_days_before(spec, frame, extract_start):
    c = _arg(spec["recipe"])
    d = pd.to_datetime(frame[c], errors="coerce")
    t = pd.to_datetime(frame[TIME])
    return (t - d).dt.total_seconds() / 86400.0, None


def build_days_until(spec, frame, extract_start):
    v, c = build_days_before(spec, frame, extract_start)
    return -v, c


def build_count_zero(spec, frame, extract_start):
    """Planted fault: a count with no censoring, so a window before the extract start reads zero."""
    v, _ = build_count(spec, frame, extract_start)
    w = WINDOWS[_arg(spec["recipe"])]
    acct, sec = _sorted_keys(frame)
    key = acct * 10**10 + sec
    ks = np.sort(key)
    lo = np.searchsorted(ks, key - w, side="left")
    hi = np.searchsorted(ks, key, side="left")
    return pd.Series((hi - lo).astype(float), index=frame.index), None


def build_count(spec, frame, extract_start):
    w = WINDOWS[_arg(spec["recipe"])]
    acct, sec = _sorted_keys(frame)
    key = acct * 10**10 + sec
    order = np.argsort(key, kind="stable")
    ks = key[order]
    lo = np.searchsorted(ks, key - w, side="left")
    hi = np.searchsorted(ks, key, side="left")
    val = (hi - lo).astype(float)
    start = pd.Timestamp(extract_start).value // 10**9
    cens = (sec - w) < start
    val[cens] = np.nan
    return pd.Series(val, index=frame.index), pd.Series(cens, index=frame.index)


def build_prev(spec, frame, extract_start):
    c = _arg(spec["recipe"])
    acct, sec = _sorted_keys(frame)
    order = np.lexsort((np.arange(len(frame)), sec, acct))
    a_s, s_s = acct[order], sec[order]
    v = frame[c].to_numpy(dtype=object)[order]
    out = np.full(len(frame), None, dtype=object)
    # latest strictly earlier second: the last row of the previous distinct second in the account
    last_val, last_sec, cur_acct = None, None, None
    pend_val, pend_sec = None, None
    res = np.full(len(frame), None, dtype=object)
    for i in range(len(order)):
        if a_s[i] != cur_acct:
            cur_acct, last_val, pend_val, pend_sec = a_s[i], None, None, None
        if pend_sec is not None and s_s[i] > pend_sec:
            last_val, pend_sec = pend_val, None
        res[i] = last_val
        pend_val, pend_sec = v[i], s_s[i]
    out[order] = res
    return pd.Series(out, index=frame.index, dtype=object), None


def build_next_value(spec, frame, extract_start):
    """Planted look-ahead: the value on the account's next row (never valid)."""
    c = _arg(spec["recipe"])
    acct, sec = _sorted_keys(frame)
    order = np.lexsort((np.arange(len(frame)), sec, acct))
    v = pd.to_numeric(frame[c], errors="coerce").to_numpy(dtype=float)[order]
    a_s = acct[order]
    nxt = np.r_[v[1:], np.nan]
    nxt[np.r_[a_s[1:] != a_s[:-1], True]] = np.nan
    out = np.empty(len(frame))
    out[order] = nxt
    return pd.Series(out, index=frame.index), None


def dry_run_builders(world: Dict, have_recipes: bool) -> Dict[str, Callable]:
    b = {"dryrun_next_value": build_next_value, "dryrun_count_zero": build_count_zero}
    if not have_recipes:
        b.update({"days_before": build_days_before, "days_until": build_days_until, "count": build_count,
                  "prev": build_prev})
    return b


def expected_json() -> str:
    return json.dumps(EXPECTED, indent=1, sort_keys=True)
