#!/usr/bin/env python3
"""Per-feature summary: the field checks joined with the CPU screen's ranking and the decisions table.

    $PY fraud/experiments/features/new_fields/nf_feature_summary.py            # page 1
    $PY fraud/experiments/features/new_fields/nf_feature_summary.py --page 2
    $PY fraud/experiments/features/new_fields/nf_feature_summary.py --all
    $PY fraud/experiments/features/new_fields/nf_feature_summary.py --propose [--append]

Inputs (defaults under checkpoints/new_fields/):
- checks/field_status.csv and checks/FIELD_MAP_checked.csv (nf_field_checks.py);
- screen/feature_rank.csv (the CPU screen; optional): XGBoost's view, not the transformer's. It is read
  by these column names: feature, shap_mean_abs, shap_rank_new, perm_ap_drop_mean, perm_rank_new and note
  (the ranks among new fields only; note holds the screen's flags, blank when none);
- KEEP_DECISIONS.csv next to this script: the one decisions table (name, group, verdict,
  reason, evidence, decided_by, date, definition_version).

Outputs: checks/feature_summary.csv (one row per feature, every column),
checks/feature_summary.txt (every page) and checks/feature_missing.txt: per new continuous field its missing rows
in the training files (built values, censored dates included) and the frauds among them, the count of missing
flags of confirmed fields missing on fewer than 10 rows (the reviewers' decision D9-Y16; the line is also the
pages' last line; a count below 10 rows is sparse information, not proof that the flag has no value), and per prior-action (prev) field the share of rows whose previous row carries a value (an
advice code; decision D10). Each printed page fits one photographed screen
(at most 40 lines of 90 characters).

The draft verdict is the reviewers' suggestion from the checks, never a decision:
- drop: the checks stop the field (the first stop rule is the reason);
- hold: the checks wait for an answer: a data-owner answer about the source, or, for a field
  that repeats month or tracks time, the reviewers' recorded keep or drop and its reason in
  KEEP_DECISIONS.csv (decided under the owner's delegation; the owner is asked only for a
  missing source fact or preference);
- review: the field enters but carries a flag about availability, leakage, month or an
  external score, or the CPU screen flags it (any text in its note column: a leak, a field
  too good alone, June drift, a stored column that differs from its recipe), so a person
  should look before keeping it (proposed as unresolved);
- keep: no such flag.
Only a row a person decided (decided_by a name, not "proposed") is final; every other
feature shows as unresolved. --propose writes the draft verdicts as proposed rows to
checks/KEEP_DECISIONS_proposed.csv; with --append it also adds them to KEEP_DECISIONS.csv
for names that have no row there yet. It never changes or removes an existing row.
Nothing is removed, hidden or masked.
Exit codes: 0 done, 2 bad arguments or a bad decisions file, 4 refused (no checks output).
"""

from __future__ import annotations

import argparse
import importlib.util
import math
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
for _p in (str(HERE), str(ROOT / "src"), str(ROOT)):
    if _p in sys.path:
        sys.path.remove(_p)
    sys.path.insert(0, _p)

import pandas as pd  # noqa: E402

DECISIONS_COLUMNS = ["name", "group", "verdict", "reason", "evidence", "decided_by", "date", "definition_version"]
DECISION_VALUES = ("keep", "drop", "hold", "unresolved")
REVIEW_RULES = ("fill_ratio", "fill_jump", "change_at_event", "change_after_event", "strong_alone", "date_after_any",
                "date_future_by_meaning", "external_score", "lagged_decision", "feasibility_unknown", "calendar_code",
                "absolute_time", "overlaps_month", "near_duplicate", "drift_june", "missing_drift", "censored_june",
                "unk_june_high", "tracks_time", "repeats_month", "joint_clock", "refreshed_by_transaction",
                "sumegha_15298", "raw_date")
PAGE_ROWS = 35
# The screen's feature_rank.csv, by explicit column name (agreed with the screen): summary column -> rank column.
RANK_CONTRACT = {"feature": "feature", "shap": "shap_mean_abs", "shap_rank": "shap_rank_new",
                 "perm": "perm_ap_drop_mean", "perm_rank": "perm_rank_new", "screen_note": "note"}
SUMMARY_COLUMNS = ["feature", "group", "kind", "definition_version", "result", "rules", "cluster_id", "kept_once_as",
                   "shap_rank", "shap", "perm_rank", "perm", "screen_note", "draft_verdict", "draft_reason",
                   "evidence", "decision", "decision_reason", "decided_by", "date", "decision_rows", "status",
                   "model_type", "missing_rows", "missing_frauds"]
RARE_MISSING_ROWS = 10     # D9-Y16: fewer rows than this is sparse information, not proof of no value


def _load(name: str):
    if name in sys.modules:
        return sys.modules[name]
    spec = importlib.util.spec_from_file_location(name, HERE / f"{name}.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


_RULE = re.compile(r"(STOP|WAIT|FLAG) ([A-Za-z0-9_]+)(?: \((.*?)\))?(?=; (?:STOP|WAIT|FLAG) |$)")


def parse_rules(reasons: str) -> List[tuple]:
    """'STOP duplicate (x); FLAG near_duplicate (y)' -> [(STOP, duplicate, x), (FLAG, near_duplicate, y)]."""
    return [(m.group(1), m.group(2), m.group(3) or "") for m in _RULE.finditer(str(reasons or ""))]


def draft_verdict(result: str, rules: List[tuple], kept_once_as: str, screen_note: str = "") -> tuple:
    if result == "STOP":
        r = next((x for x in rules if x[0] == "STOP"), ("STOP", "stop", ""))
        if r[1] in ("duplicate", "duplicate_number") and kept_once_as:
            return "drop", f"kept once as {kept_once_as}"
        return "drop", r[1] + (f" ({r[2]})" if r[2] else "")
    if result == "WAIT":
        r = next((x for x in rules if x[0] == "WAIT"), ("WAIT", "wait", ""))
        return "hold", r[1]
    flagged = [x[1] for x in rules if x[0] == "FLAG" and x[1] in REVIEW_RULES]
    note = _text(screen_note)
    if flagged or note:
        why = ", ".join(dict.fromkeys(flagged))
        if note:
            why = (why + "; " if why else "") + "screen: " + note
        return "review", why
    return "keep", "no stop, wait or review flag"


def read_rank(path: Optional[Path]) -> pd.DataFrame:
    """The screen's feature_rank.csv. When it holds the agreed columns (RANK_CONTRACT) they are read by
    name: the ranks among new fields and the screen's note. Any other ranking file is read by column
    meaning: a name column, SHAP and permutation columns and their ranks. Rows for clusters (a kind
    column saying cluster) are left out."""
    cols = ["feature", "shap", "shap_rank", "perm", "perm_rank", "screen_note"]
    if not path or not Path(path).exists():
        return pd.DataFrame(columns=cols)
    df = pd.read_csv(path, keep_default_na=False)
    if set(RANK_CONTRACT.values()) <= set(df.columns):
        out = pd.DataFrame({k: df[v] for k, v in RANK_CONTRACT.items()})
        out["feature"] = out["feature"].astype(str)
        for c in ("shap", "shap_rank", "perm", "perm_rank"):
            out[c] = pd.to_numeric(out[c], errors="coerce")
        out["screen_note"] = out["screen_note"].map(_text)
        return out[cols].drop_duplicates("feature", keep="first")
    low = {c.lower(): c for c in df.columns}
    name = next((low[c] for c in ("feature", "field", "name", "unit", "member") if c in low), None)
    if name is None:
        raise SystemExit(f"{path}: no feature column")
    kind = next((low[c] for c in low if c in ("kind", "unit_kind", "unit_type", "level", "type")), None)
    if kind:
        df = df[~df[kind].astype(str).str.lower().str.contains("cluster")]
    shap = next((low[c] for c in low if "shap" in c and "rank" not in c), None)
    perm = next((low[c] for c in low if "perm" in c and "rank" not in c and "sd" not in c and "se" != c[-2:]
                 and "ci" not in c), None)
    shap_rank = next((low[c] for c in low if "shap" in c and "rank" in c), None)
    perm_rank = next((low[c] for c in low if "perm" in c and "rank" in c), None)
    note = next((low[c] for c in low if c in ("note", "notes", "flag", "flags", "leaky", "label")), None)
    out = pd.DataFrame({"feature": df[name].astype(str)})
    out["shap"] = pd.to_numeric(df[shap], errors="coerce") if shap else float("nan")
    out["perm"] = pd.to_numeric(df[perm], errors="coerce") if perm else float("nan")
    if shap_rank:
        out["shap_rank"] = pd.to_numeric(df[shap_rank], errors="coerce")
    else:
        out["shap_rank"] = out["shap"].rank(ascending=False, method="min")
    if perm_rank:
        out["perm_rank"] = pd.to_numeric(df[perm_rank], errors="coerce")
    else:
        out["perm_rank"] = out["perm"].rank(ascending=False, method="min")
    out["screen_note"] = df[note].astype(str) if note else ""
    return out.drop_duplicates("feature", keep="first")


def read_decisions(path: Optional[Path]) -> Dict[str, dict]:
    """The latest row a person decided, per name (rows with decided_by "proposed" or blank are
    suggestions and never final). Refuses missing columns or unknown verdicts."""
    if not path or not Path(path).exists():
        return {}
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    miss = [c for c in DECISIONS_COLUMNS if c not in df.columns]
    if miss:
        raise BadDecisions(f"{path}: missing columns {miss}")
    out: Dict[str, dict] = {}
    for i, r in df.iterrows():
        f = r["name"].strip().lower()
        if not f:
            continue
        v = r["verdict"].strip().lower()
        if v not in DECISION_VALUES:
            raise BadDecisions(f"{path} row {i + 2}: verdict {r['verdict']!r} is not keep, drop, hold or unresolved")
        who = r["decided_by"].strip()
        if not who or who.lower() == "proposed":
            continue
        prev = out.get(f, {}).get("decision_rows", 0)
        out[f] = {"decision": v, "decision_reason": r["reason"], "decided_by": who, "date": r["date"],
                  "decision_rows": prev + 1}
    return out


def evidence_text(row: dict) -> str:
    bits = []
    if row["result"] != "PASS":
        first = next((x for x in parse_rules(row.get("_reasons", "")) if x[0] == row["result"]), None)
        bits.append(f"checks:{row['result']} {first[1]}" if first else f"checks:{row['result']}")
    else:
        bits.append("checks:PASS")
    if not _isnan(row.get("shap_rank")):
        bits.append(f"screen:shap rank {_num(row['shap_rank'])}")
    note = _text(row.get("screen_note"))
    if note:
        bits.append(f"screen:{note}")
    return "; ".join(bits)


def _isnan(x) -> bool:
    try:
        return x is None or x == "" or math.isnan(float(x))
    except (TypeError, ValueError):
        return True


def _text(x) -> str:
    """A text cell: blank for a missing value (None, NaN, "nan"), else the stripped text."""
    if x is None or (isinstance(x, float) and math.isnan(x)):
        return ""
    t = str(x).strip()
    return "" if t.lower() == "nan" else t


class BadDecisions(Exception):
    pass


def _num(x, nd=0) -> str:
    try:
        v = float(x)
    except (TypeError, ValueError):
        return "-"
    if math.isnan(v):
        return "-"
    return f"{v:.{nd}f}" if nd else str(int(round(v)))


def build(checks_dir: Path, rank_path: Optional[Path], decisions_path: Optional[Path]) -> pd.DataFrame:
    st = pd.read_csv(checks_dir / "field_status.csv", dtype=str, keep_default_na=False)
    versions = {}
    mp = checks_dir / "FIELD_MAP_checked.csv"
    if mp.exists():
        fm = pd.read_csv(mp, dtype=str, keep_default_na=False)
        if "definition_version" in fm.columns:
            versions = dict(zip(fm["name"].str.strip(), fm["definition_version"]))
    rank = read_rank(rank_path).set_index("feature")
    dec = read_decisions(decisions_path)
    miss = missing_counts(checks_dir)
    rows = []
    for _, r in st.iterrows():
        f = r["field"]
        rules = parse_rules(r["reasons"])
        row = {"feature": f, "group": r.get("group", ""), "kind": r.get("kind", ""),
               "definition_version": versions.get(f, ""), "result": r["result"],
               "rules": ",".join(dict.fromkeys(x[1] for x in rules)), "cluster_id": r.get("cluster_id", ""),
               "kept_once_as": r.get("kept_once_as", ""), "_reasons": r["reasons"],
               **miss.get(f, {})}
        if f in rank.index:
            rr = rank.loc[f]
            row.update({"shap_rank": rr["shap_rank"], "shap": rr["shap"], "perm_rank": rr["perm_rank"],
                        "perm": rr["perm"], "screen_note": rr["screen_note"]})
        dv, why = draft_verdict(r["result"], rules, r.get("kept_once_as", ""), row.get("screen_note", ""))
        row.update({"draft_verdict": dv, "draft_reason": why})
        row["evidence"] = evidence_text(row)
        d = dec.get(f.lower())
        if d:
            row.update(d)
            row["status"] = "decided"
        else:
            row.update({"decision": "", "decision_reason": "", "decided_by": "", "date": "", "decision_rows": 0,
                        "status": "unresolved"})
        rows.append(row)
    out = pd.DataFrame(rows, columns=SUMMARY_COLUMNS + ["_nonnull", "_rows"])
    order = {"STOP": 3, "WAIT": 2, "FLAG": 1, "PASS": 0}
    out["_o"] = out["result"].map(order).fillna(4)
    out["_r"] = pd.to_numeric(out["shap_rank"], errors="coerce").fillna(1e9)
    out = out.sort_values(["_o", "_r", "feature"], kind="stable").drop(columns=["_o", "_r"]).reset_index(drop=True)
    out.attrs["decisions_unknown"] = sorted(set(dec) - set(out["feature"].str.lower()))
    return out


def proposals(df: pd.DataFrame, today: str) -> pd.DataFrame:
    """Proposed rows for every feature no person has decided: the draft verdict (review becomes
    unresolved), its reason and evidence, decided_by "proposed"."""
    rows = []
    for _, r in df.iterrows():
        if r["status"] == "decided":
            continue
        verdict = {"review": "unresolved"}.get(r["draft_verdict"], r["draft_verdict"])
        rows.append({"name": r["feature"], "group": r["group"], "verdict": verdict, "reason": r["draft_reason"],
                     "evidence": r["evidence"], "decided_by": "proposed", "date": today,
                     "definition_version": r["definition_version"]})
    return pd.DataFrame(rows, columns=DECISIONS_COLUMNS)


def append_proposals(path: Path, prop: pd.DataFrame) -> int:
    """Adds proposed rows for names with no row at all in the table; never edits a row."""
    if path.exists():
        cur = pd.read_csv(path, dtype=str, keep_default_na=False)
        miss = [c for c in DECISIONS_COLUMNS if c not in cur.columns]
        if miss:
            raise BadDecisions(f"{path}: missing columns {miss}")
        have = set(cur["name"].str.strip())
    else:
        cur, have = pd.DataFrame(columns=DECISIONS_COLUMNS), set()
    new = prop[~prop["name"].str.lower().isin({h.lower() for h in have})]
    if len(new):
        header = not path.exists() or path.stat().st_size == 0
        with open(path, "a", newline="") as f:
            if not header and not path.read_text().endswith("\n"):
                f.write("\n")
            new[DECISIONS_COLUMNS].to_csv(f, index=False, header=header)
    return int(len(new))


def _short(name: str, width: int) -> str:
    """The name, or its start and end around "~" when it is longer than width (twins differ at the end)."""
    name = str(name)
    if len(name) <= width:
        return name
    head = (width - 1) // 2
    return name[:head] + "~" + name[-(width - 1 - head):]


def missing_counts(checks_dir: Path) -> Dict[str, dict]:
    """Per field, from field_checks.csv's training row: the model type, the missing rows (censored included) and
    the frauds among them (the reviewers' decision D9-Y16), and the rows with a value."""
    p = checks_dir / "field_checks.csv"
    if not p.exists():
        return {}
    fc = pd.read_csv(p, dtype=str, keep_default_na=False)
    fc = fc[fc.get("range", pd.Series([""] * len(fc))) == "train"] if "range" in fc.columns else fc
    out = {}
    for _, r in fc.iterrows():
        out[r["field"]] = {"model_type": r.get("model_type", ""), "missing_rows": r.get("train_missing_rows", ""),
                           "missing_frauds": r.get("train_missing_frauds", ""),
                           "_nonnull": r.get("train_nonnull", ""), "_rows": r.get("train_rows", "")}
    return out


def _int(x) -> Optional[int]:
    try:
        return int(float(x))
    except (TypeError, ValueError):
        return None


def missing_report(df: pd.DataFrame, checks_dir: Path) -> tuple:
    """(lines of feature_missing.txt, the flags line): the reviewers' decisions D9-Y16 and D10."""
    confirmed = None
    mp = checks_dir / "FIELD_MAP_checked.csv"
    if mp.exists():
        fm = pd.read_csv(mp, dtype=str, keep_default_na=False)
        if "list_status" in fm.columns:
            confirmed = set(fm.loc[fm["list_status"] == "CONFIRMED", "name"].str.strip())
        prev = set(fm.loc[fm["recipe"].str.strip().str.startswith("prev("), "name"].str.strip()) \
            if "recipe" in fm.columns else set()
    else:
        prev = set()
    lines = ["Missing rows of the new continuous fields in the training files (built values, censored included), "
             "and the frauds among them (decision D9-Y16). A count below "
             f"{RARE_MISSING_ROWS} rows is sparse information, not proof that the flag has no value."]
    cont = df[df["model_type"] == "continuous"]
    rare = []
    for _, r in cont.iterrows():
        n, fr = _int(r["missing_rows"]), _int(r["missing_frauds"])
        lines.append(f"  {r['feature']}: missing {n if n is not None else 'na'} rows, frauds among them "
                     f"{fr if fr is not None else 'na'}")
        if (confirmed is None or r["feature"] in confirmed) and n is not None and n < RARE_MISSING_ROWS:
            rare.append(r["feature"])
    pool = [f for f in cont["feature"] if confirmed is None or f in confirmed]
    share = len(rare) / len(pool) if pool else 0.0
    flags = (f"flags of new fields missing on fewer than {RARE_MISSING_ROWS} rows: {len(rare)} of {len(pool)} "
             f"tokens ({100 * share:.1f}%)")
    lines += ["", flags]
    if prev:
        lines += ["", "Prior bank actions (prev fields): the share of rows whose previous row carries a value (an "
                      "advice code), decision D10; the value is assumed recorded at that row's time."]
        for f in sorted(prev):
            row = df[df["feature"] == f]
            if row.empty:
                continue
            nn, rows = _int(row.iloc[0].get("_nonnull")), _int(row.iloc[0].get("_rows"))
            lines.append(f"  {f}: {100 * nn / rows:.2f}% of rows" if nn is not None and rows else f"  {f}: na")
    return lines, flags


def pages(df: pd.DataFrame, title_bits: str, extra_foot: str = "") -> List[str]:
    nc = _load("nf_common")
    head = f"{'feature':<44} {'res':<4} {'shap':>4} {'perm':>4} {'draft':<6} {'owner':<5} rules"
    lines = []
    for _, r in df.iterrows():
        owner = r["decision"] or "-"
        rules = r["rules"] if r["result"] != "PASS" else ""
        if r["kept_once_as"]:
            rules = f"={r['kept_once_as']} " + rules
        line = f"{_short(r['feature'], 44):<44} {r['result']:<4} {_num(r['shap_rank']):>4} {_num(r['perm_rank']):>4} " \
               f"{r['draft_verdict']:<6} {owner:<5} {rules}"
        lines.append(line[:90])
    n = max(1, math.ceil(len(lines) / PAGE_ROWS))
    counts = df["draft_verdict"].value_counts().to_dict()
    unresolved = int((df["status"] == "unresolved").sum())
    out = []
    for p in range(n):
        body = [head] + lines[p * PAGE_ROWS:(p + 1) * PAGE_ROWS]
        foot = (f"page {p + 1}/{n} | draft keep {counts.get('keep', 0)} review {counts.get('review', 0)} "
                f"hold {counts.get('hold', 0)} drop {counts.get('drop', 0)} | unresolved {unresolved}")
        out.append(nc.screen(f"FEATURE SUMMARY  {title_bits}"[:90], body,
                             [foot[:90]] + ([extra_foot[:90]] if extra_foot else [])))
    return out


def main(argv=None) -> int:
    nc = _load("nf_common")
    p = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    p.add_argument("--checks", help="the checks folder (default: checkpoints/new_fields/checks)")
    p.add_argument("--rank", help="the screen's feature_rank.csv (default: checkpoints/new_fields/screen/)")
    p.add_argument("--decisions", help="KEEP_DECISIONS.csv (default: next to this script)")
    p.add_argument("--out", help="output folder (default: the checks folder)")
    p.add_argument("--page", type=int, default=1)
    p.add_argument("--propose", action="store_true", help="write proposed rows to checks/KEEP_DECISIONS_proposed.csv")
    p.add_argument("--append", action="store_true",
                   help="with --propose: also add them to KEEP_DECISIONS.csv for names with no row yet")
    p.add_argument("--all", action="store_true", help="print every page")
    a = p.parse_args(argv)
    c2 = nc.c2() if hasattr(nc, "c2") else Path(nc.C2)
    checks = Path(a.checks) if a.checks else Path(c2) / "checks"
    if not (checks / "field_status.csv").exists():
        print(f"refused: {checks / 'field_status.csv'} not found; run nf_field_checks.py first")
        return nc.REFUSED
    rank = Path(a.rank) if a.rank else Path(c2) / "screen" / "feature_rank.csv"
    decisions = Path(a.decisions) if a.decisions else HERE / "KEEP_DECISIONS.csv"
    try:
        df = build(checks, rank if rank.exists() else None, decisions if decisions.exists() else None)
    except BadDecisions as e:
        print(f"bad decisions file: {e}")
        return nc.ARGS
    out = Path(a.out) if a.out else checks
    out.mkdir(parents=True, exist_ok=True)
    mlines, flags = missing_report(df, checks)
    (out / "feature_missing.txt").write_text("\n".join(mlines) + "\n")
    df = df.drop(columns=["_nonnull", "_rows"])
    df.to_csv(out / "feature_summary.csv", index=False)
    if a.propose:
        import datetime as _dt
        prop = proposals(df, _dt.date.today().isoformat())
        prop.to_csv(out / "KEEP_DECISIONS_proposed.csv", index=False)
        if a.append:
            try:
                append_proposals(decisions, prop)
            except BadDecisions as e:
                print(f"bad decisions file: {e}")
                return nc.ARGS
    unknown = df.attrs.get("decisions_unknown") or []
    bits = (f"screen={'yes' if rank.exists() else 'not found'} (XGBoost's view) "
            f"decisions={'yes' if decisions.exists() else 'none'}"
            + (f" unknown={len(unknown)}" if unknown else ""))
    if unknown:
        (out / "feature_summary_unknown_decisions.txt").write_text(
            "decisions that name features not in the checks:\n" + "\n".join(unknown) + "\n")
    pg = pages(df, bits, flags)
    (out / "feature_summary.txt").write_text("\n\n".join(pg) + "\n")
    if a.all:
        print("\n\n".join(pg))
    else:
        if not 1 <= a.page <= len(pg):
            print(f"page {a.page} does not exist; there are {len(pg)}")
            return nc.ARGS
        print(pg[a.page - 1])
    return nc.OK


if __name__ == "__main__":
    sys.exit(main())
