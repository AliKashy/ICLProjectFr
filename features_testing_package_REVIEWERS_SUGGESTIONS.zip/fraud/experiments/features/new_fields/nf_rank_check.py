"""Rank check: may RANK-A (8228-8243) and RANK-B (8244-8259) be read? CPU only, no labels read.

  CUDA_VISIBLE_DEVICES= $PY $NF/nf_rank_check.py

For each of RANK-A and RANK-B it checks:
  1. every file exists under eval.base (parquet footer read only);
  2. splits/file_inventory.json shows June targets in each file, and gives the June fraud count;
  3. no population in splits/populations.yaml (or a role in splits/population_roles.yaml) uses any of its files,
     except a RANK_A or RANK_B line the owner added;
  4. no exposure record or scoring receipt it can find names an overlapping file range (every root searched is
     printed);
  5. no BENCH overlap.
RANK-B decides only if its check passes. If RANK-A or RANK-B fails, the plan's fallback files (PLAN.md section 3:
"8201-8205 with 8278-8300 take its place after the same checks"; SETTINGS.yaml rank_fallback_files) get the same
checks. If RANK-B fails and the fallback fails too, June SELECT decides, as a single logged read, and every read
screen says so. If RANK-B fails and the fallback passes, the owner decides how the fallback files are used
(decide_on "owner"): the queue and the reader wait until SETTINGS.yaml names them or says decide_on select_june.
Writes checkpoints/new_fields/reads/rank_check.json and prints one screen. Exit 0 when both pass, 3 when either
fails, 4 when the S3 file system cannot be opened.
"""
import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nf_common as C  # noqa: E402

JUNE = "2025-06"
PLAN_FALLBACK = [[8201, 8205], [8278, 8300]]   # PLAN.md section 3; SETTINGS.yaml rank_fallback_files overrides


class Refused(Exception):
    """Exit 4 with the reason (a missing pod path or credential), never a traceback."""
SEARCH_ROOTS = ["checkpoints", "runs", "models", "archive", "../tabular_fraud_old/runs", "../tabular_fraud_old/models"]
OWN_PURPOSE_PREFIX = "new_fields_"
MAX_JSON_BYTES = 1 << 20


def _range_of(obj):
    """(start, end) from a receipt's or exposure's files entry, or None."""
    f = obj.get("files") if isinstance(obj, dict) else None
    if isinstance(f, dict) and "start" in f and "end" in f:
        try:
            return int(f["start"]), int(f["end"])
        except (TypeError, ValueError):
            return None
    if isinstance(f, list) and f:
        nums = []
        for x in f:
            s = str(x).rsplit("part_", 1)[-1].split(".")[0]
            if s.isdigit():
                nums.append(int(s))
        return (min(nums), max(nums)) if nums else None
    return None


def overlaps(a, b):
    return a[0] <= b[1] and b[0] <= a[1]


def search_exposures(roots, rng, skip_own=True):
    hits, searched = [], []
    for r in roots:
        p = (C.ROOT / r).resolve()
        if not p.is_dir():
            continue
        searched.append(C.rel(p))
        for dirpath, _, files in os.walk(p):
            for n in files:
                if not n.endswith(".json"):
                    continue
                f = Path(dirpath) / n
                try:
                    if f.stat().st_size > MAX_JSON_BYTES:
                        continue
                    obj = json.loads(f.read_text(encoding="utf-8"))
                except (OSError, ValueError, UnicodeDecodeError):
                    continue
                if not isinstance(obj, dict) or not ("checkpoint_sha256" in obj or "purpose" in obj
                                                     or "population" in obj):
                    continue
                fr = _range_of(obj)
                if fr is None or not overlaps(fr, rng):
                    continue
                if skip_own and str(obj.get("purpose", "")).startswith(OWN_PURPOSE_PREFIX):
                    continue
                hits.append(f"{C.rel(f)} files {fr[0]}-{fr[1]} purpose {obj.get('purpose', '-')}")
    return hits, searched


def inventory_june(inv, a, b):
    """{file number: (june rows, june frauds)} for eval files a..b; None for a file not in the inventory."""
    by_num = {}
    for row in inv.get("files", []):
        if str(row.get("source", "eval")) != "eval":
            continue
        try:
            n = int(row.get("number"))
        except (TypeError, ValueError):
            continue
        m = (row.get("months") or {}).get(JUNE) or {}
        by_num[n] = (int(m.get("rows", 0)), int(m.get("frauds", 0)))
    return {n: by_num.get(n) for n in range(a, b + 1)}


def populations_using(pops, a, b, allow=("RANK_A", "RANK_B", "RANK-A", "RANK-B")):
    used = []
    for name, p in ((pops or {}).get("populations") or {}).items():
        if str(name).upper() in allow:
            continue
        try:
            if str(p.get("source", "eval")) != "eval":
                continue
            s, e = int(p["file_start"]), int(p["file_end"])
        except (KeyError, TypeError, ValueError, AttributeError):
            continue
        if overlaps((s, e), (a, b)):
            used.append(f"{name} {s}-{e}")
    return used


def files_present(base, cred, a, b):
    if not base:
        return None, "eval.base unknown"
    import pyarrow.parquet as pq
    fs, strip = None, (lambda x: x)
    if str(base).startswith(("s3://", "s3a://")):
        import nf_layout
        nf_layout.bootstrap()
        make, strip = nf_layout.attr("s3", "make_s3_filesystem"), nf_layout.attr("s3", "strip_scheme")
        try:
            fs = make(cred)
        except Exception as e:  # a missing or unreadable credentials file: a refusal, not a crash
            raise Refused(f"the S3 file system cannot be opened ({type(e).__name__}: {e}); check s3.cred_path in "
                          "the base config, or give --cred-path (exit 4)")
    missing = []
    for n in range(a, b + 1):
        path = f"{str(base).rstrip('/')}/part_{n}.parquet"
        try:
            pq.read_schema(strip(path), filesystem=fs) if fs else pq.read_schema(path)
        except (OSError, FileNotFoundError):
            missing.append(n)
        except Exception as e:  # access refused, no credentials: not a missing file
            raise Refused(f"part_{n}.parquet under eval.base cannot be read ({type(e).__name__}: {e}); check the "
                          "S3 access (exit 4)")
    return missing, None


def _ranges_label(ranges):
    return " + ".join(f"{a}-{b}" for a, b in ranges)


def check_ranges(key, ranges, ctx, args):
    """The five checks on one population, given as one or more file ranges."""
    fails, notes, hits, searched = [], [], [], []
    june_frauds = None if ctx["inv"] is None else 0
    for a, b in ranges:
        if args.skip_files:
            notes.append("file presence not checked (--skip-files)")
        else:
            missing, why = files_present(ctx["base"], ctx["cred"], a, b)
            if why:
                fails.append(why)
            elif missing:
                fails.append(f"files missing under eval.base: {missing}")
        if ctx["inv"] is None:
            fails.append(f"{C.rel(ctx['inv_p'])} not found")
        else:
            j = inventory_june(ctx["inv"], a, b)
            absent = [n for n, v in j.items() if v is None]
            empty = [n for n, v in j.items() if v is not None and v[0] == 0]
            if absent:
                fails.append(f"not in the inventory: {absent}")
            if empty:
                fails.append(f"files with no June targets: {empty}")
            june_frauds += sum(v[1] for v in j.values() if v)
        if ctx["popy"] is None:
            notes.append(f"{C.rel(ctx['pop_p'])} not found")
        else:
            used = populations_using(ctx["popy"], a, b)
            if used:
                fails.append("used by populations: " + ", ".join(used))
        if ctx["bench"]:
            try:
                if overlaps((int(ctx["bench"]["file_start"]), int(ctx["bench"]["file_end"])), (a, b)):
                    fails.append(f"BENCH files {ctx['bench']['file_start']}-{ctx['bench']['file_end']} overlap")
            except (KeyError, TypeError, ValueError):
                notes.append("BENCH range unreadable")
        h, sr = search_exposures(SEARCH_ROOTS if args.roots is None else args.roots, (a, b))
        hits += h
        searched += [x for x in sr if x not in searched]
    if ctx["roles"] is not None and key in ("rank_a", "rank_b"):
        extra = [r for r in ((ctx["roles"].get("populations") or {}).keys())
                 if str(r).upper() in (key.upper(), key.upper().replace("_", "-"))]
        if extra:
            notes.append(f"role line present in population_roles.yaml: {extra} (owner's yes)")
    if hits:
        fails.append(f"{len(hits)} exposure record(s) or receipt(s) name these files")
    dedupe = lambda xs: [x for i, x in enumerate(xs) if x not in xs[:i]]  # noqa: E731
    return {"files": ranges[0] if len(ranges) == 1 else ranges, "result": "PASS" if not fails else "FAIL",
            "fails": dedupe(fails), "notes": dedupe(notes), "june_frauds": june_frauds, "exposures": hits,
            "roots_searched": searched}


def _lines(label, res):
    jf = res["june_frauds"]
    out = [f"{label}: {res['result']}   June frauds {jf if jf is not None else 'unknown'}"]
    out += [f"  FAIL {x}" for x in res["fails"]] + [f"  note {x}" for x in res["notes"]]
    out += [f"  exposure {h}" for h in res["exposures"][:5]]
    out.append(f"  roots searched: {', '.join(res['roots_searched']) or 'none found'}")
    return out


def check(args):
    s = C.settings()
    pops = s.get("populations", {})
    cfgp = C.ROOT / s.get("base_config", "fraud/configs/sequential_hier_allpos.yaml")
    flat = C.flatten(C.load_yaml(cfgp)) if cfgp.is_file() else {}
    splits = C.ROOT / args.splits
    inv_p, pop_p, role_p = splits / "file_inventory.json", splits / "populations.yaml", splits / "population_roles.yaml"
    ctx = {"base": args.eval_base or flat.get("eval.base"),
           "cred": args.cred_path if args.cred_path is not None else flat.get("s3.cred_path"),
           "inv_p": inv_p, "pop_p": pop_p,
           "inv": C.read_json(inv_p) if inv_p.is_file() else None,
           "popy": C.load_yaml(pop_p) if pop_p.is_file() else None,
           "roles": C.load_yaml(role_p) if role_p.is_file() else None}
    ctx["bench"] = ((ctx["popy"] or {}).get("populations") or {}).get("BENCH") or {}
    result = {"utc": C.utc_now(), "inventory_sha256": C.sha256_file(inv_p) if ctx["inv"] else None, "populations": {}}
    lines = []
    for key in ("rank_a", "rank_b"):
        a, b = (int(x) for x in pops[key]["files"])
        res = check_ranges(key, [(a, b)], ctx, args)
        result["populations"][key] = res
        lines += _lines(f"{key.upper().replace('_', '-')} {a}-{b}", res)
    ra, rb = (result["populations"][k]["result"] for k in ("rank_a", "rank_b"))
    fb = None
    if "FAIL" in (ra, rb):
        # PLAN.md section 3: if RANK fails, 8201-8205 with 8278-8300 take its place after the same checks
        ranges = [tuple(int(x) for x in r) for r in (s.get("rank_fallback_files") or PLAN_FALLBACK)]
        fb = check_ranges("fallback", ranges, ctx, args)
        fb["checked_because"] = " and ".join(n for n, r in (("RANK-A", ra), ("RANK-B", rb)) if r == "FAIL") + " failed"
        result["fallback"] = fb
        lines += _lines(f"fallback {_ranges_label(ranges)} (plan section 3)", fb)
    if rb == "PASS":
        result["decide_on"] = "rank_b"
        lines.append("decision population: RANK-B")
    elif fb["result"] == "FAIL":
        result["decide_on"] = "select_june"
        lines += ["decision population: June SELECT. RANK-B and the plan's fallback failed: a single",
                  "  logged read; no independent check remains"]
    else:
        result["decide_on"] = "owner"
        lines += ["decision population: the owner decides. RANK-B failed and the plan's fallback files",
                  "  passed the same checks, so they take its place (plan section 3). Copilot sets",
                  "  SETTINGS.yaml populations rank_a and rank_b to them as the owner says, then runs",
                  "  this check again; or the owner sets decide_on: select_june. The queue waits."]
    lines.append("importance population: " + ("RANK-A" if ra == "PASS" else
                                              "RANK-A failed: importance and attention wait for the owner"))
    result["result"] = "PASS" if ra == rb == "PASS" else "FAIL"
    out = C.out("reads", "rank_check.json")
    C.write_json(out, result)
    C.print_screen(f"RANK CHECK  {result['utc']}", lines, footer="saved: " + C.rel(out))
    return C.OK if result["result"] == "PASS" else C.STOP


def main(argv=None):
    ap = argparse.ArgumentParser(description="rank check")
    ap.add_argument("--eval-base")
    ap.add_argument("--cred-path")
    ap.add_argument("--splits", default="splits")
    ap.add_argument("--roots", nargs="*", help="exposure search roots relative to the project root")
    ap.add_argument("--skip-files", action="store_true", help="do not read footers (tests only)")
    args = ap.parse_args(argv)
    try:
        return check(args)
    except Refused as e:
        C.say(f"refused: {e}")
        return C.REFUSED
    except SystemExit as e:
        return e.code if isinstance(e.code, int) else C.CRASH


if __name__ == "__main__":
    sys.exit(main())
