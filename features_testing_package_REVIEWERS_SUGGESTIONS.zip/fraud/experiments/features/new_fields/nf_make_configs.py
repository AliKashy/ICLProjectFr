"""Config writer: predictor lists and run configs for each step, from the chosen model's as-run config.

  $PY $NF/nf_make_configs.py                     # the control and the first step that is on (the queue writes later ones)
  $PY $NF/nf_make_configs.py write --run nf_a2 --steps A2          # A1 was dropped: A2 builds on base
  $PY $NF/nf_make_configs.py write --run nf_p --steps A1 A2 --drop <file of names>
  $PY $NF/nf_make_configs.py write --run nf_b --steps A1 --month-out
  $PY $NF/nf_make_configs.py write --run nf_c --steps A1 --calendar-cyclical [--is-weekend]   # optional step C
  $PY $NF/nf_make_configs.py write --run nf_ka2 --steps A1 --microbatch-of nf_a2   # A2's control: the kept recipe
  $PY $NF/nf_make_configs.py --verify             # every NF/configs/*.yaml differs from the base only in allowed keys

A generated config differs from fraud/configs/sequential_hier_allpos.yaml only in these keys: predictors.csv_path,
artifacts.version, data.train_base, data.val_base and eval.base (enriched copies only), training.learning_rate, the
micro-batch pair and eval batch (memory rule only), output.checkpoint_dir and experiment.run_name, and, for the
optional cyclical calendar step only, datetime.encoding and datetime.is_weekend. Any other difference is refused
(exit 3). The learning rate comes only from SETTINGS.yaml. The month-in and month-out lists are the data lane's own
rule (nf_data_artifact.month_in_list and month_out_list), so the artifact check verifies them.

Micro-batch (the memory rule, D5a, D5b, D10): a control always runs at its candidate's micro-batch. A candidate's
config takes SETTINGS.yaml microbatch[<run>]; nf_control (the base control P1 and the base refits at seeds 43 and 44)
takes the first step's entry; a refit control takes its candidate's (--microbatch-of; the queue passes it). An entry
under a control's own name that differs from its candidate's is refused (exit 3).

Group membership (D3a): A2 adds f15298 and both. A feature in both lists counts as V22B, enters at A1 and is counted
once. When an input set holds f15298 but not v22b (A1 kept its control), each v22b row that a 15298 row names in
kept_once_as (its twin) joins, if that row is CONFIRMED, passed the checks (PASS or FLAG) and no person dropped it.
"""
import argparse
import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nf_common as C  # noqa: E402

ALLOWED_KEYS = ("predictors.csv_path", "artifacts.version", "data.train_base", "data.val_base", "eval.base",
                "training.learning_rate", "training.batch_size", "training.accumulate_grad_batches",
                "training.eval_batch_size", "output.checkpoint_dir", "experiment.run_name",
                "datetime.encoding", "datetime.is_weekend")
CALENDAR_KEYS = ("datetime.encoding", "datetime.is_weekend")   # the optional cyclical calendar step only
COPY_KEYS = ("data.train_base", "data.val_base", "eval.base")
MICRO_KEYS = ("training.batch_size", "training.accumulate_grad_batches", "training.eval_batch_size")


def configs_dir():
    return C.NF / "configs"


def predictors_dir():
    return C.NF / "predictors"


def input_set_id(steps, drop=False, ):
    sid = "".join(s.lower() for s in steps) or "base"
    return sid + ("p" if drop else "")


def step_groups(names):
    st = {s["name"]: s for s in C.steps().get("steps", [])}
    groups = []
    for n in names:
        if n not in st:
            raise SystemExit(f"unknown step {n}; STEPS.yaml has {', '.join(st)}")
        groups += list(st[n].get("adds") or [])
    return groups


def field_results():
    p = C.c2() / "checks" / "field_status.csv"
    if not p.is_file():
        return None
    with open(p, encoding="utf-8") as f:
        return {r["field"]: r["result"] for r in csv.DictReader(f)}


def field_kept_once():
    """kept_once_as per field from the field checks (field_status.csv): the row a duplicate is kept once as."""
    p = C.c2() / "checks" / "field_status.csv"
    if not p.is_file():
        return {}
    with open(p, encoding="utf-8") as f:
        return {r["field"]: (r.get("kept_once_as") or "").strip() for r in csv.DictReader(f)}


def fields_for(groups, df, drop=()):
    """CONFIRMED rows of the groups that passed the checks (PASS or FLAG), in map order, each once. Refuses an
    UNCONFIRMED map and a map newer than field_status.csv. D3a: when the groups hold f15298 but not v22b, each v22b
    row that a 15298 row names in kept_once_as joins, if it is CONFIRMED, PASS or FLAG and no person dropped it."""
    if not groups:
        return []
    if (df["list_status"] == "UNCONFIRMED").any():
        raise SystemExit("the map holds UNCONFIRMED rows; adopt the owner's list first (exit 4)")
    res = field_results()
    if res is None:
        raise SystemExit("checkpoints/new_fields/checks/field_status.csv is missing; run the field checks (exit 4)")
    fs = C.c2() / "checks" / "field_status.csv"
    mp = C.NF / "FIELD_MAP.csv"
    if mp.is_file() and fs.stat().st_mtime < mp.stat().st_mtime:
        raise SystemExit("the map is newer than field_status.csv; run the field checks again (exit 4)")
    dropped = {n for n, d in C.person_decisions().items() if d.get("verdict") == "drop"}
    drop = set(drop)

    def ok(r):
        return (r["list_status"] == "CONFIRMED" and res.get(r["name"]) in ("PASS", "FLAG") and r["name"] not in drop
                and r["name"] not in dropped)
    want = set(groups)
    if "f15298" in want and "v22b" not in want:
        kept_once = field_kept_once()
        by = {r["name"]: r for _, r in df.iterrows()}
        twins = set()
        for _, r in df.iterrows():
            k = by.get(kept_once.get(r["name"], "") or str(r.get("kept_once_as", "") or "").strip())
            if r["group"] == "f15298" and k is not None and k["group"] == "v22b" and ok(k):
                twins.add(k["name"])
    else:
        twins = set()
    out = [r for _, r in df.iterrows() if (r["group"] in want or r["name"] in twins) and ok(r)]
    return out


def base_lines():
    p = C.ROOT / C.settings().get("base_predictors", "fraud/configs/predictors.csv")
    text = p.read_bytes().decode("utf-8")
    return text, list(csv.DictReader(text.splitlines()))


def write_predictors(sid, fields):
    """predictors_<sid>_month_in.csv: the base file byte for byte, then one line per new field; month_out: the same
    minus exactly the month line. Both come from the data lane's nf_data_artifact.month_in_list and month_out_list,
    the rule the artifact check verifies."""
    import nf_data_artifact as A
    text, _ = base_lines()
    base_csv = text.encode("utf-8")
    rows = [(r["name"], r["model_type"], (r["description"] or f"{r['kind']} {r['recipe']}").replace("\n", " "))
            for r in fields]
    try:
        month_in = A.month_in_list(base_csv, rows)
        month_out = A.month_out_list(month_in)
    except A.ArtifactError as e:
        raise SystemExit(f"{e} (exit 3)")
    d = predictors_dir()
    d.mkdir(parents=True, exist_ok=True)
    pin, pout = d / f"predictors_{sid}_month_in.csv", d / f"predictors_{sid}_month_out.csv"
    for p, t in ((pin, month_in), (pout, month_out)):
        if p.exists() and p.read_bytes() != t:
            raise SystemExit(f"{C.rel(p)} exists with other content; rename it first (exit 4)")
        p.write_bytes(t)
    return pin, pout


CALENDAR_FIELDS = ("month", "day", "hour", "day_of_week")


def calendar_rows(fields, is_weekend):
    """The cyclical calendar's predictor rows: a sin and a cos number per calendar field (fraud/data/
    datetime_features.py), and is_weekend as a code when asked. They come from transaction_dttm."""
    rows = []
    for f in fields:
        rows += [(f"{f}_sin", "continuous"), (f"{f}_cos", "continuous")]
    if is_weekend:
        rows.append(("is_weekend", "categorical"))
    return rows


def write_calendar_list(source, is_weekend):
    """The source list with its calendar codes (month, day, hour, day_of_week, derived from transaction_dttm) replaced
    by the cyclical rows. A calendar field already left out (month out) stays out."""
    data = Path(source).read_bytes()
    nl = b"\r\n" if b"\r\n" in data else b"\n"
    lines = data.splitlines(keepends=True)
    head, body = lines[0], lines[1:]
    present, keep = [], []
    for ln in body:
        cells = ln.decode("utf-8").rstrip("\r\n").split(",")
        if cells[0] in CALENDAR_FIELDS and len(cells) > 2 and cells[2].startswith("derived:"):
            present.append(cells[0])
            continue
        keep.append(ln)
    if not present:
        raise SystemExit(f"{C.rel(source)} holds no calendar field derived from the transaction time (exit 3)")
    version = next(iter(csv.DictReader(data.decode("utf-8").splitlines())))["version"]
    extra = "".join(f"{n},{t},derived:transaction_dttm,{version},cyclical calendar ({'sin' if n.endswith('_sin') else 'cos' if n.endswith('_cos') else 'weekend'})"
                    + nl.decode() for n, t in calendar_rows(present, is_weekend))
    out = Path(source).with_name(Path(source).stem + ("_cyclical_weekend" if is_weekend else "_cyclical") + ".csv")
    text = head + b"".join(keep) + extra.encode("utf-8")
    if out.exists() and out.read_bytes() != text:
        raise SystemExit(f"{C.rel(out)} exists with other content; rename it first (exit 4)")
    out.write_bytes(text)
    return out, present


def base_config():
    s = C.settings()
    p = C.ROOT / s.get("base_config", "fraud/configs/sequential_hier_allpos.yaml")
    if not p.is_file():
        raise SystemExit(f"base config {C.rel(p)} not found; Copilot adapts base_config in SETTINGS.yaml (exit 4)")
    return p, C.load_yaml(p)


def _set(cfg, dotted, value):
    node = cfg
    parts = dotted.split(".")
    for k in parts[:-1]:
        node = node.setdefault(k, {})
    node[parts[-1]] = value


def _copy_base(original, root):
    return f"{root.rstrip('/')}/{str(original).rstrip('/').rsplit('/', 1)[-1]}"


def first_step_run():
    """The first adding step's run (nf_a1, or nf_all with one_step_all), or None."""
    on = [st for st in C.steps().get("steps", []) if C.step_on(st) and not st.get("kind")]
    if not on:
        return None
    return "nf_all" if C.steps().get("one_step_all") else f"nf_{on[0]['name'].lower()}"


def microbatch_for(run, microbatch_of=None):
    """(the candidate whose micro-batch this config carries, its SETTINGS.yaml microbatch entry or None)."""
    mb = C.settings().get("microbatch") or {}
    src = microbatch_of or (first_step_run() if run == "nf_control" else run)
    entry = mb.get(src) if src else None
    own = mb.get(run)
    if src and src != run and own and own != entry:
        raise SystemExit(f"SETTINGS.yaml microbatch names {run} ({own}) and its candidate {src} ({entry}); a control "
                         "always runs at its candidate's micro-batch: remove the control's own entry (exit 3)")
    return src, entry


def make_config(run, sid, fields, month_out=False, calendar=None, microbatch_of=None):
    s = C.settings()
    if not str(s.get("learning_rate_source") or "").strip():
        raise SystemExit("SETTINGS.yaml learning_rate_source is blank; stage 0's report names the rate (exit 4)")
    bpath, cfg = base_config()
    flat = C.flatten(cfg)
    pin, pout = write_predictors(sid, fields)
    _set(cfg, "predictors.csv_path", C.rel(pout if month_out else pin))
    if fields:
        _set(cfg, "artifacts.version", s["extended_artifact_version"])
    if calendar:
        # the optional cyclical calendar step: config only (datetime.encoding), its list, the extended artifact
        weekend = calendar == "cyclical_weekend"
        pcal, _ = write_calendar_list(pout if month_out else pin, weekend)
        _set(cfg, "predictors.csv_path", C.rel(pcal))
        _set(cfg, "artifacts.version", s["extended_artifact_version"])
        _set(cfg, "datetime.encoding", "cyclical")
        _set(cfg, "datetime.is_weekend", weekend)
    if any(r["kind"] == "engineered" for r in fields):
        for k in COPY_KEYS:
            _set(cfg, k, _copy_base(flat[k], s["enriched_root"]))
    _set(cfg, "training.learning_rate", float(s["learning_rate"]))
    _, mb = microbatch_for(run, microbatch_of)
    if mb:
        b0, a0 = int(flat["training.batch_size"]), int(flat["training.accumulate_grad_batches"])
        b1 = int(mb.get("batch_size", b0))
        a1 = int(mb.get("accumulate_grad_batches", a0))
        if b1 * a1 != b0 * a0:
            raise SystemExit(f"microbatch for {run}: {b1} x {a1} != as-run {b0} x {a0}; targets per update must "
                             "stay the same (exit 3)")
        _set(cfg, "training.batch_size", b1)
        _set(cfg, "training.accumulate_grad_batches", a1)
        if "eval_batch_size" in mb:
            _set(cfg, "training.eval_batch_size", int(mb["eval_batch_size"]))
    _set(cfg, "output.checkpoint_dir", f"checkpoints/new_fields/runs/{run}")
    _set(cfg, "experiment.run_name", run)
    d = configs_dir()
    d.mkdir(parents=True, exist_ok=True)
    out = d / f"{run}.yaml"
    import yaml
    head = (f"# run {run}; input set {sid}; month {'out' if month_out else 'in'}; "
            f"calendar {'cyclical' + (' with is_weekend' if calendar == 'cyclical_weekend' else '') if calendar else 'categorical'}; "
            f"new fields {len(fields)}\n"
            f"# generated by nf_make_configs.py from {C.rel(bpath)} (sha256 {C.sha256_file(bpath)[:12]}); "
            "do not edit by hand\n")
    text = head + yaml.safe_dump(cfg, sort_keys=False, default_flow_style=False)
    if out.exists() and out.read_text(encoding="utf-8") != text:
        raise SystemExit(f"{C.rel(out)} exists with other content; rename it first (exit 4)")
    out.write_text(text, encoding="utf-8")
    problems = verify_one(out, cfg=C.load_yaml(bpath))
    if problems:
        raise SystemExit("; ".join(problems) + " (exit 3)")
    return out, diff_lines(C.load_yaml(bpath), C.load_yaml(out)), flat


def diff_lines(a, b):
    return [f"  {k}: {va} -> {vb}" for k, va, vb in C.diff_configs(a, b)]


def verify_one(path, cfg=None):
    s = C.settings()
    if cfg is None:
        cfg = base_config()[1]
    new = C.load_yaml(path)
    problems = []
    fb = C.flatten(cfg)
    first = Path(path).read_text(encoding="utf-8").splitlines()[0] if Path(path).is_file() else ""
    for k, va, vb in C.diff_configs(cfg, new):
        if k not in ALLOWED_KEYS:
            problems.append(f"{Path(path).name}: {k} differs ({va} -> {vb}) and may not")
        elif k in CALENDAR_KEYS and "calendar cyclical" not in first:
            problems.append(f"{Path(path).name}: {k} may differ only in the cyclical calendar step's config")
        elif k == "datetime.encoding" and vb != "cyclical":
            problems.append(f"{Path(path).name}: datetime.encoding may only become cyclical")
        elif k in COPY_KEYS and not str(vb).startswith(str(s["enriched_root"]).rstrip("/")):
            problems.append(f"{Path(path).name}: {k} may point only at the enriched copies")
        elif k == "training.learning_rate" and float(vb) != float(s["learning_rate"]):
            problems.append(f"{Path(path).name}: learning rate {vb} is not SETTINGS.yaml's {s['learning_rate']}")
    fn = C.flatten(new)
    if "training.batch_size" in fn and fb.get("training.batch_size") not in (None, "???"):
        try:
            if int(fn["training.batch_size"]) * int(fn["training.accumulate_grad_batches"]) != \
                    int(fb["training.batch_size"]) * int(fb["training.accumulate_grad_batches"]):
                problems.append(f"{Path(path).name}: micro-batch x accumulation differs from the as-run plan")
        except (TypeError, ValueError):
            pass
    return problems


def default_chain():
    """The control and the first adding step (or ALL). Later steps' configs depend on earlier decisions, so the queue
    writes them when it reaches them (A2 builds on base if A1 kept the control, on a1 if A1 was adopted)."""
    on = [s for s in C.steps().get("steps", []) if C.step_on(s) and not s.get("kind")]
    chain = [("nf_control", [], False)]
    if C.steps().get("one_step_all"):
        return chain + [("nf_all", [s["name"] for s in on], False)] if on else chain
    return chain + ([(f"nf_{on[0]['name'].lower()}", [on[0]["name"]], False)] if on else [])


def screen_for(run, sid, fields, month_out, diff, flat):
    tokens = None
    try:
        _, base = base_lines()
        c0 = sum(1 for r in base if r["type"] == "continuous")
        k0 = len(base) - c0
        c1 = c0 + sum(1 for r in fields if r["model_type"] == "continuous")
        k1 = k0 + sum(1 for r in fields if r["model_type"] == "categorical") - (1 if month_out else 0)
        tokens = (2 * c0 + k0 + 1, 2 * c1 + k1 + 1)
    except Exception:  # noqa: BLE001
        pass
    nw = flat.get("training.num_workers")
    lines = [f"run {run}  input set {sid}  month {'out' if month_out else 'in'}  new fields {len(fields)}"]
    if tokens:
        lines.append(f"tokens per transaction {tokens[0]} -> {tokens[1]} (plus CLS)")
    lines.append(f"num_workers (as run) {nw}: " + ("pairing by seed shares only the file partition; the window "
                 "order differs once widths differ" if nw not in (0, "0", None) else "same window order"))
    lines.append("differences from the base config:")
    lines += diff
    return lines


def main(argv=None):
    ap = argparse.ArgumentParser(description="config writer")
    ap.add_argument("--verify", action="store_true")
    sub = ap.add_subparsers(dest="cmd")
    w = sub.add_parser("write")
    w.add_argument("--run", required=True)
    w.add_argument("--steps", nargs="*", default=[])
    w.add_argument("--drop", help="file of field or cluster member names to drop (pruning)")
    w.add_argument("--month-out", action="store_true")
    w.add_argument("--calendar-cyclical", action="store_true", help="the optional step C: datetime.encoding cyclical")
    w.add_argument("--is-weekend", action="store_true", help="with --calendar-cyclical: add is_weekend")
    w.add_argument("--microbatch-of", default=None, help="a control's candidate run: the config takes its micro-batch")
    args = ap.parse_args(argv)
    try:
        if args.verify:
            problems = []
            files = sorted(configs_dir().glob("*.yaml")) if configs_dir().is_dir() else []
            for p in files:
                problems += verify_one(p)
            C.print_screen(f"CONFIG VERIFY  {len(files)} configs", problems or ["every config differs only in "
                                                                                  "allowed keys"])
            return C.STOP if problems else C.OK
        df = C.read_field_map(C.NF / "FIELD_MAP.csv")
        jobs = default_chain() if args.cmd is None else [(args.run, args.steps, args.month_out)]
        cal = None
        if args.cmd == "write" and args.calendar_cyclical:
            cal = "cyclical_weekend" if args.is_weekend else "cyclical"
        lines = []
        for run, steps_, mo in jobs:
            drop = []
            if args.cmd == "write" and args.drop:
                drop = [x.strip() for x in Path(args.drop).read_text().split() if x.strip()]
            fields = fields_for(step_groups(steps_), df, drop)
            sid = input_set_id(steps_, drop=bool(drop))
            mbo = args.microbatch_of if args.cmd == "write" else None
            out, diff, flat = make_config(run, sid, fields, month_out=mo, calendar=cal, microbatch_of=mbo)
            lines += screen_for(run, sid, fields, mo, diff, flat)
        mb = C.settings().get("microbatch") or {}
        if mb:
            lines.append("memory rule fired for " + ", ".join(sorted(mb)) + ": every control runs at its candidate's "
                         "micro-batch (nf_control at the first step's; a refit at its candidate's)")
        C.print_screen("CONFIG WRITER  " + C.utc_now(), lines, footer="configs: " + C.rel(configs_dir()))
        return C.OK
    except SystemExit as e:
        if isinstance(e.code, str):
            print(e.code, file=sys.stderr)
            return C.STOP if "exit 3" in e.code else C.REFUSED
        return e.code


if __name__ == "__main__":
    sys.exit(main())
