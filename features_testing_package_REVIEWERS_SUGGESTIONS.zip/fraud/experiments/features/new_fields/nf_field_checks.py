#!/usr/bin/env python3
"""CPU field checks (DESIGN.md section 3, component 9).

    CUDA_VISIBLE_DEVICES= nice -n 19 $PY fraud/experiments/features/new_fields/nf_field_checks.py \
        --map fraud/experiments/features/new_fields/FIELD_MAP.csv
    $PY fraud/experiments/features/new_fields/nf_field_checks.py --dry-run

CPU only. It reads one file at a time and, inside a file, one batch of columns at a time.
Per-file partial counts go to <out>/partial/, so a stopped run restarts at the next file.
A changed thresholds file makes it refuse to reuse partial counts.

What it checks, per field of the map: presence in every file range (footers only);
availability at the moment of the transaction (own date after the transaction, filled only
for frauds, filled only after a fraud, changes at and after the event, too good on its own);
strictly-earlier probes for engineered fields (future invariance, history deletion,
same-second siblings, label permutation); missing values overall, by month and by label;
type, vocabulary and unknown share; duplicates, one-to-one recodes, near duplicates and
correlation clusters; month-like fields and month overlap; status, hold, feasibility,
same-transaction bank decision and external score flags.

Outputs (under --out, default checkpoints/new_fields/checks/): field_checks.csv,
field_status.csv, clusters.csv, month_overlap.csv, missing_by_month.csv, duplicates.csv,
FIELD_MAP_checked.csv (a copy of the map with the check columns filled; the input map is
never changed) and summary.txt (one screen, also printed).

A field that repeats month or tracks time waits (WAIT) until the reviewers record keep or drop and
the reason in KEEP_DECISIONS.csv, under the owner's delegation; the owner is asked only for a
missing source fact or preference. Exact month duplicates stay represented once; month stays.
A warning (history_parity) never shortens a declared history window.

Nothing is suppressed, redacted or masked. Nothing is removed: results are listed for the owner.
Exit codes: 0 done, 1 crash, 2 bad arguments, 4 refused (memory, thresholds changed under
partial counts, a missing or unreadable map). Progress lines go to the error stream; the
summary screen is printed last, on the output.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import math
import os
import re
import sys
import tempfile
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
for _p in (str(HERE), str(ROOT / "src"), str(ROOT)):
    if _p in sys.path:
        sys.path.remove(_p)
    sys.path.insert(0, _p)

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402


def _load(name: str):
    """A sibling module, loaded by path (cached)."""
    if name in sys.modules:
        return sys.modules[name]
    path = HERE / f"{name}.py"
    if not path.exists():
        return None
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


M = _load("nf_checks_measure")
R = _load("nf_checks_rules")

CALENDAR_FIELDS = ("month", "day", "hour", "day_of_week")
TIME_GAP = "time_delta"
DATE_RECIPES = ("days_before", "days_until", "days_to")
GROUP_ORDER = {"v22b": 1, "both": 1, "f15298": 2, "a3": 3}
ONE_ROW_MISSING = ("since_last", "since_first", "prev", "mean", "min", "max")
# recipes with no history window (every other recipe with a window token is censored before the extract start)
AP_BINS = 2000   # single-field AP of a number is read over this many training quantile bins (memory bound)
HISTORY_NO_WINDOW = ("prev", "since_last", "since_first", "distinct")
NO_WINDOW = ("raw", "prev", "code", "ratio", "a3", "geohash") + ("days_before", "days_until", "days_to")
# recipes of the row's own stored values: the stored-value availability rules apply to them as to a raw field
ROW_LEVEL = ("raw", "code", "ratio", "geohash")
GEOHASH_NOT_CATEGORICAL = "geohash(...) gives a category; model_type must be categorical"


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------
def recipe_function(recipe: str) -> str:
    r = (recipe or "").strip()
    if not r or r == "raw":
        return "raw"
    m = re.match(r"\s*([A-Za-z_][A-Za-z0-9_]*)\s*\(", r)
    return m.group(1) if m else r


def recipe_key(recipe: str) -> Optional[str]:
    m = re.search(r"(?:^|[;(,\s])(?:key|group_key|by)\s*=\s*([A-Za-z0-9_]+)", recipe or "")
    return m.group(1) if m else None


def parse_range(text: str) -> List[int]:
    a, _, b = str(text).partition("-")
    return list(range(int(a), int(b or a) + 1))


def free_gb() -> Optional[float]:
    """Free memory in GiB. With nf_common.resource_limits (the shared helper): the smaller of the host's
    MemAvailable and the container's cgroup headroom, the rule the CPU screen uses. Else MemAvailable."""
    fn = getattr(_load("nf_common"), "resource_limits", None)
    if callable(fn):
        return fn()["free_gib"]
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) / 1024 / 1024
    except OSError:
        return None
    return None


def fmt(x, nd=3) -> str:
    if x is None:
        return ""
    if isinstance(x, (bool, np.bool_)):
        return "yes" if x else "no"
    if isinstance(x, (float, np.floating)):
        if math.isnan(x):
            return ""
        return f"{x:.{nd}g}" if abs(x) >= 1e5 or (x != 0 and abs(x) < 1e-3) else f"{round(float(x), nd)}"
    return str(x)


# ---------------------------------------------------------------------------
# Data access: local folders or S3 through the project's own filesystem helper
# ---------------------------------------------------------------------------
class Files:
    def __init__(self, cred_path: Optional[str]):
        self.fs = None
        if cred_path:
            nf_layout = _load("nf_layout")
            make = nf_layout.attr("s3", "make_s3_filesystem")
            self.fs = make(cred_path)

    def _p(self, path: str) -> str:
        if self.fs is not None:
            for s in ("s3://", "s3a://"):
                if path.startswith(s):
                    return path[len(s):]
        return path

    def exists(self, path: str) -> bool:
        return self.fs.exists(self._p(path)) if self.fs is not None else os.path.exists(path)

    def columns(self, path: str) -> List[str]:
        import pyarrow.parquet as pq
        return list(pq.read_schema(self._p(path), filesystem=self.fs).names)

    def read(self, path: str, cols: List[str]) -> pd.DataFrame:
        import pyarrow.parquet as pq
        have = set(self.columns(path))
        use = [c for c in dict.fromkeys(cols) if c in have]
        return pq.read_table(self._p(path), columns=use, filesystem=self.fs).to_pandas()


def file_path(base: str, n: int) -> str:
    return f"{base.rstrip('/')}/part_{n}.parquet"


# ---------------------------------------------------------------------------
# Engineered columns: the recipes module of the data lane, through a small adapter
# ---------------------------------------------------------------------------
class Builder:
    """Builds one field's values on one file's rows, as `(values, censored)` aligned to the frame.

    Raw fields are the column as stored. Every other recipe goes to the recipes module
    (nf_recipes.py, the same code the enriched copies use). Extra builders (test or dry-run
    only) may be registered by recipe function name.
    """

    def __init__(self, recipes=None, extra: Optional[Dict[str, Callable]] = None, account="", time=""):
        self.recipes = recipes
        self.extra = dict(extra or {})
        self.account, self.time = account, time
        self.geohash_table = None   # TFM's geohash table as run() read it once; every file's build uses it
        self.last_built = None

    def can_build(self, spec: Dict) -> bool:
        fn = spec["fn"]
        return fn == "raw" or fn in self.extra or self.recipes is not None

    def refused(self, spec: Dict) -> str:
        """The recipes module's own parse error for this recipe, or "" (one grammar: nf_recipes.parse). A geohash
        whose row is not categorical is refused too, as nf_recipes.build_columns refuses it: its value is a
        category, and the number cast would make every row missing."""
        fn = spec["fn"]
        if fn == "raw" or fn in self.extra or self.recipes is None or not hasattr(self.recipes, "parse"):
            return ""
        try:
            rec = self.recipes.parse(spec["recipe"])
        except ValueError as e:  # nf_recipes.RecipeError is a ValueError
            return str(e)
        if getattr(rec, "op", None) == "geohash" and self.cast_type(spec) != "categorical":
            return GEOHASH_NOT_CATEGORICAL
        return ""

    @staticmethod
    def cast_type(spec: Dict) -> str:
        """The model_type a built value is cast to (the map row's; blank casts as a number)."""
        return str(dict(spec.get("row") or {}).get("model_type") or "continuous")

    def build(self, spec: Dict, frame: pd.DataFrame, extract_start: str) -> Tuple[pd.Series, Optional[pd.Series]]:
        fn = spec["fn"]
        self.last_built = None   # the recipe engine's Built of this call (date reasons, signed difference)
        if fn == "raw":
            col = spec["column"]
            return (frame[col] if col in frame.columns else pd.Series(np.nan, index=frame.index)), None
        if fn in self.extra:
            res = self.extra[fn](spec, frame, extract_start)
        else:
            res = self._call_recipes(spec, frame, extract_start)
        return self._normalise(res, spec["name"], frame.index)

    def _engine(self):
        if getattr(self, "_engine_cache", None) is None:
            self._engine_cache = self.recipes.load_engine()
        return self._engine_cache

    def _call_recipes(self, spec, frame, extract_start):
        r = self.recipes
        row = dict(spec["row"])
        if all(hasattr(r, n) for n in ("FileContext", "parse", "cast_output", "load_engine")):
            # the data lane's engine, the same path as nf_recipes.build_columns, keeping the per-row censored mask
            name = spec["name"]
            if name in frame.columns:
                raise r.RecipeError(f"{name} is already a column of the file; an engineered name must be new")
            model_type = self.cast_type(spec)
            rec = r.parse(spec["recipe"])
            if rec.op == "geohash" and model_type != "categorical":
                raise r.RecipeError(f"{name}: {GEOHASH_NOT_CATEGORICAL}")
            sw_mod, a3 = self._engine()
            ctx = r.FileContext(frame, extract_start, sw_mod, self.account or r.ACCOUNT, self.time or r.TIME,
                                r.TIE)
            ctx.a3_builders = a3
            if self.geohash_table is not None:
                ctx.geohash_table = self.geohash_table
            b = ctx.build(rec)
            self.last_built = b
            return r.cast_output(b.values, model_type), b.censored
        tries = []
        if hasattr(r, "build_field"):
            tries.append(lambda: r.build_field(row, frame, extract_start=extract_start))
        if hasattr(r, "build_feature"):
            tries.append(lambda: r.build_feature(row, frame, extract_start=extract_start))
        if hasattr(r, "build"):
            tries.append(lambda: r.build(spec["recipe"], frame, extract_start=extract_start))
        if hasattr(r, "build_columns"):
            tries.append(lambda: r.build_columns(pd.DataFrame([row]), frame, extract_start=extract_start))
        errors = []
        for t in tries:
            try:
                return t()
            except TypeError as e:  # a different signature; try the next form
                errors.append(str(e))
        raise RuntimeError(f"recipes module has no usable build function for {spec['name']}: {errors}")

    @staticmethod
    def _normalise(res, name, index):
        cens = None
        if isinstance(res, tuple):
            res, cens = res[0], (res[1] if len(res) > 1 else None)
        if isinstance(res, dict):
            cens = res.get("censored", cens)
            res = res.get("values", res.get(name))
        if isinstance(res, pd.DataFrame):
            for c in (f"{name}__censored", f"{name}_censored", "censored"):
                if c in res.columns:
                    cens = res[c]
                    break
            res = res[name] if name in res.columns else res.iloc[:, 0]
        vals = pd.Series(res, index=index) if not isinstance(res, pd.Series) else res.reindex(index)
        if cens is not None:
            cens = pd.Series(np.asarray(cens, dtype=bool), index=index) if not isinstance(cens, pd.Series) \
                else cens.reindex(index).fillna(False).astype(bool)
        return vals, cens


def load_recipes(path: Optional[str]):
    p = Path(path) if path else HERE / "nf_recipes.py"
    if not p.exists():
        return None
    spec = importlib.util.spec_from_file_location("nf_recipes", p)
    mod = importlib.util.module_from_spec(spec)
    sys.modules.setdefault("nf_recipes", mod)
    spec.loader.exec_module(mod)
    return mod


# ---------------------------------------------------------------------------
# Field specs from the map
# ---------------------------------------------------------------------------
TEXT_FIELDS = ("name", "tfm_name", "f15298_name", "source_columns")


def read_status_rules(path: Optional[Path]) -> List[Dict]:
    """STATUS_RULES.csv as a list of rules {rule, pattern, match, applies_to, reason}.

    The settings file's columns are rule, pattern, match (exact_ci, token_ci, substring_ci),
    applies_to (name;tfm_name;f15298_name;source_columns), result and reason. A file with a name
    column instead of a pattern, or with no match column, is read too: a name matches exactly, a
    pattern of four letters or fewer as a whole token, a longer one anywhere. Rules understood:
    left_out_26oct, rank52, allow, status_like, hold and same_txn_decision."""
    if not path or not Path(path).exists():
        return []
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    cols = {c.lower().strip(): c for c in df.columns}
    rule_col = next((cols[c] for c in cols if c == "rule" or c in ("kind", "class")), None)
    pat_col = cols.get("pattern")
    name_col = next((cols[c] for c in cols if c in ("name", "field", "feature", "column")), None)
    match_col = next((cols[c] for c in cols if c in ("match", "mode", "match_type")), None)
    app_col = cols.get("applies_to")
    reason_col = next((cols[c] for c in cols if "reason" in c), None)
    out = []
    for _, r in df.iterrows():
        rule = (r[rule_col] if rule_col else "status_like").strip().lower() or "status_like"
        pat = r[pat_col].strip().lower() if pat_col else ""
        match = (r[match_col].strip().lower() if match_col else "")
        if not pat and name_col and r[name_col].strip():
            pat, match = r[name_col].strip().lower(), match or "exact_ci"
        if not pat:
            continue
        if not match:
            match = "token_ci" if len(pat) <= 4 else "substring_ci"
        apps = {x.strip() for x in (r[app_col] if app_col else "").split(";") if x.strip()} or set(TEXT_FIELDS)
        out.append({"rule": rule, "pattern": pat, "match": match.replace("_ci", ""), "applies_to": apps,
                    "reason": r[reason_col].strip() if reason_col else ""})
    return out


def _tokens(text: str) -> List[str]:
    return [t for t in re.split(r"_+", (text or "").lower()) if t]


def rule_hits(rule: Dict, texts: Dict[str, List[str]]) -> bool:
    """Whether a rule matches any text it applies to (case-insensitive)."""
    pat, mode = rule["pattern"], rule["match"]
    ptoks = _tokens(pat)
    for field, values in texts.items():
        if field not in rule["applies_to"]:
            continue
        for t in values:
            t = (t or "").lower().strip()
            if not t:
                continue
            if mode == "exact" and t == pat:
                return True
            if mode == "substring" and pat in t:
                return True
            if mode == "token":
                tt = _tokens(t)
                k = len(ptoks)
                if k and any(tt[i:i + k] == ptoks for i in range(len(tt) - k + 1)):
                    return True
    return False


def read_decisions(path: Optional[Path]) -> Dict[str, Dict]:
    """The latest row a person decided (decided_by not blank and not "proposed") per name."""
    if not path or not Path(path).exists():
        return {}
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    if "name" not in df.columns:
        return {}
    out = {}
    for _, r in df.iterrows():
        who = r.get("decided_by", "").strip()
        if who and who.lower() != "proposed":
            out[r["name"].strip().lower()] = {k: r.get(k, "") for k in df.columns}
    return out


def lookback(recipe: str, fn: str, recipes=None) -> Tuple[Optional[int], bool]:
    """(how far back the recipe reads in seconds, None for no limit; whether it reads history). The recipe
    engine's own rule when it parses the recipe (nf_recipes: since_last and prev read 30 days unless within= says
    otherwise, within=all has no limit); else the window tokens written in the recipe."""
    if recipes is not None and hasattr(recipes, "parse"):
        try:
            r = recipes.parse(recipe)
        except ValueError:   # nf_recipes.RecipeError: not this grammar (a test builder); the tokens below
            r = None
        if r is not None:
            return (r.lookback_seconds if r.is_history else 0), bool(r.is_history)
    history = fn not in NO_WINDOW or fn in HISTORY_NO_WINDOW
    return (M.recipe_reach_seconds(recipe) if history else None), history


SIBLING = object()   # field_specs' default recipes module: nf_recipes.py next to this script


def field_specs(fmap: pd.DataFrame, base_names: List[str], th, rules: List[Dict], account: str,
                decisions: Optional[Dict[str, Dict]] = None, recipes=SIBLING) -> List[Dict]:
    decisions = decisions or {}
    recipes = _load("nf_recipes") if recipes is SIBLING else recipes
    rules = list(rules or [])
    if not any(r["rule"] == "status_like" for r in rules):   # no status patterns in the file: the defaults
        rules += [{"rule": "status_like", "pattern": p, "match": "substring", "applies_to": set(TEXT_FIELDS),
                   "reason": "default"} for p in th("status_substring_patterns")]
        rules += [{"rule": "status_like", "pattern": p, "match": "token", "applies_to": set(TEXT_FIELDS),
                   "reason": "default"} for p in th("status_token_patterns")]
    has_dec_rules = any(r["rule"] == "same_txn_decision" for r in rules)
    specs = []
    for i, r in fmap.reset_index(drop=True).iterrows():
        row = {k: str(v) for k, v in r.items()}
        name = row["name"].strip()
        recipe = row.get("recipe", "").strip() or "raw"
        fn = recipe_function(recipe)
        sources = [s.strip() for s in row.get("source_columns", "").split(";") if s.strip()]
        if fn == "raw" and not sources:
            sources = [name]
        tx = {"name": [name], "tfm_name": [row.get("tfm_name", "")], "f15298_name": [row.get("f15298_name", "")],
              "source_columns": sources}
        texts = [x for v in tx.values() for x in v if x]
        text = " ".join(texts).lower()
        s: Dict = {"name": name, "row": row, "index": i, "recipe": recipe, "fn": fn, "sources": sources,
                   "column": name if fn == "raw" else None, "group": row.get("group", "").strip(),
                   "kind": row.get("kind", "").strip(), "model_type": row.get("model_type", "").strip() or "categorical",
                   "is_date": fn in DATE_RECIPES, "flags": {}}
        fl = s["flags"]
        clash = []
        if name in base_names:
            clash.append("base input")
        if name in CALENDAR_FIELDS:
            clash.append("calendar field")
        if name == TIME_GAP:
            clash.append("time gap")
        if name.endswith("_isna"):
            clash.append("_isna name")
        if clash:
            fl["name_clash"] = ", ".join(clash)
        if row.get("excluded_by_sumegha", "").strip().lower() == "yes":
            if s["group"] in ("f15298", "both"):
                # the reviewers' decision D3a: Sumegha's exclusion follows the feature; a 15298 row enters at A2
                # only with a person's keep row (WAIT sumegha_15298), never at A1
                fl["sumegha_15298"] = (f"excluded by Sumegha ({row.get('sumegha_reason', '') or 'no reason given'}); "
                                       "enters at A2 only with a person's keep row recording Sumegha's or the "
                                       "owner's confirmation")
            else:
                fl["excluded_by_sumegha"] = True
            fl["sumegha_reason"] = row.get("sumegha_reason", "")
        hits = [r_ for r_ in rules if rule_hits(r_, tx)]
        kinds = {h["rule"] for h in hits}
        # left_out_26oct > rank52 > allow > status_like, whatever the map's status_rule says (review items 7 and
        # 10); a hold rule or the map's own hold or status_like applies otherwise
        rule = row.get("status_rule", "").strip().lower()
        how = "map"
        if "left_out_26oct" in kinds:
            rule, how = "left_out_26oct", "status rules"
        elif "rank52" in kinds:
            rule, how = "rank52", "status rules"
        elif "allow" in kinds and rule in ("", "none", "status_like"):
            rule, how = "none", "allow list"
        elif not rule or rule == "none":
            if "hold" in kinds:
                rule, how = "hold", "status rules"
            elif "status_like" in kinds:
                pats = [h["pattern"] for h in hits if h["rule"] == "status_like"]
                rule, how = "status_like", "name scan: " + ",".join(pats[:3])
        s["status_rule"] = rule or "none"
        fixed = row.get("data_owner_fixed", "").strip().lower().startswith("yes")
        cleared = decisions.get(name.lower())
        if cleared and cleared.get("verdict", "").strip().lower() == "keep" and \
                str(cleared.get("decided_by", "")).strip().lower() not in ("", "proposed"):
            fl["keep_written"] = f"{cleared.get('decided_by')} {cleared.get('date')}"
        # the month-like hold (the reviewers' decision D3d, amended): the reviewers' recorded keep or drop, with its
        # reason, in the decisions table resolves it; a row without a reason leaves the field held
        if cleared and cleared.get("verdict", "").strip().lower() in ("keep", "drop") and \
                str(cleared.get("reason", "")).strip():
            fl["month_decision"] = cleared["verdict"].strip().lower()
            fl["month_decided_by"] = f"{str(cleared.get('decided_by', '')).strip()} {cleared.get('date', '')}".strip()
        if rule == "left_out_26oct":
            fl["left_out_26oct"] = True
        elif rule == "status_like" and not fixed:
            if cleared and cleared.get("verdict", "").strip().lower() == "keep":
                fl["status_cleared"] = f"status mark cleared in writing by {cleared.get('decided_by')} " \
                                       f"{cleared.get('date')}"
            else:
                fl["status"] = f"status-like ({how}), needs the data owner's written answer"
        elif rule == "hold":
            fl["hold"] = "held in the list until the owner answers"
        is_dec = ("same_txn_decision" in kinds) if has_dec_rules else \
            any(R.matches(x, th("decision_patterns")) for x in texts)
        if row.get("left_out_reason", "").strip():
            fl["left_out_reason"] = row["left_out_reason"].strip()
        label_cols = [c.lower() for c in th("label_columns")]
        outcome = [x for x in sources if x.lower() in label_cols or R.matches(x, th("outcome_patterns"))]
        if outcome:
            fl["uses_outcome"] = ";".join(outcome)
        feas = row.get("feasible_in_production", "").strip().lower()
        if feas == "no":
            fl["not_feasible"] = True
            fl["feasibility_note"] = row.get("feasibility_note", "")
        elif feas != "yes":
            fl["feasibility_unknown"] = True
        ext = row.get("external_score", "").strip().lower() == "yes" or \
            any(R.matches(x, th("external_score_patterns")) for x in texts)
        if ext:
            fl["external_score"] = "another model's score, production availability is for the owner"
            s["is_external"] = True
        if is_dec:
            if fn == "prev":
                if fixed:
                    fl["lagged_decision"] = "previous transaction's decision, confirmed by the data owner"
                else:
                    fl["lagged_decision_wait"] = ("previous transaction's decision, the data owner confirms it is "
                                                  "written at authorisation and never revised")
            else:   # the raw form, and any other recipe that reads the current row's decision
                fl["same_txn_decision"] = "the bank's decision on this transaction, only prev(...) may enter"
        if any(R.matches(x, th("calendar_patterns")) for x in [name] + sources):
            fl["calendar_name"] = "name suggests a calendar period"
        meaning = row.get("date_meaning", "").strip().lower()
        if meaning == "known_future_date":
            s["future_by_meaning"] = True
        elif meaning == "event_date":
            s["future_by_meaning"] = False
        else:
            s["future_by_meaning"] = fn in ("days_until", "days_to") or bool(R.matches(text, th("future_date_patterns")))
        s["is_profile"] = any(R.matches(x, th("profile_patterns")) for x in [name] + sources) or \
            "profile" in row.get("business_category", "").lower()
        reach, history = lookback(recipe, fn, recipes)
        max_days = th.num("history_parity_max_days")
        # a warning only: the declared history window stays as written (the reviewers' decision D3d); the checks
        # never shorten it
        if history and reach is not None and reach > max_days * 86400:
            fl["history_parity"] = (f"reads {reach / 86400:g} days back; June rows have at most about "
                                    f"{max_days:g} days of history; the declared window stays")
        elif history and reach is None:
            fl["history_parity"] = (f"reads all history since the extract start (within=all, or no window); "
                                    f"training rows can look back months, June rows about {max_days:g} days; "
                                    "the declared window stays")
        key = recipe_key(recipe)
        s["group_key"] = key if key and key != account else None
        specs.append(s)
    return specs


try:   # the extended artifact's cap of new code fields (the reviewers' decision D9-Y20; an engineering default)
    from nf_data_artifact import CAP_MIN_ACCOUNTS
except ImportError:   # noqa: the checks run without the data lane's module in a few tests
    CAP_MIN_ACCOUNTS = 10


def _num_ok(x) -> bool:
    return isinstance(x, (int, float)) and not (isinstance(x, float) and math.isnan(x))


def precedence(spec: Dict) -> Tuple[int, int]:
    return (GROUP_ORDER.get(spec["group"], 4), spec["index"])


# ---------------------------------------------------------------------------
# The run
# ---------------------------------------------------------------------------
class Checks:
    def __init__(self, a, th, th_sha: str, map_sha: str, specs: List[Dict], base: pd.DataFrame,
                 builder: Builder, files: Files, out: Path, log=print):
        self.a, self.th, self.th_sha, self.map_sha = a, th, th_sha, map_sha
        self.specs, self.base, self.builder, self.files, self.out = specs, base, builder, files, out
        self.log = log
        self.partial = out / "partial"
        self.partial.mkdir(parents=True, exist_ok=True)
        self.acc, self.tcol, self.idc, self.ycol = a.account_col, a.time_col, a.id_col, a.label_col
        self.m: Dict[str, Dict] = {s["name"]: {} for s in specs}
        # fields the recipe engine refused while building them on a file: name -> "<stage> file <name>: <reason>"
        self.refused_fields: Dict[str, str] = {}
        self.stage, self._path = "", ""
        self.cap = int(th.num("vocab_size_stop"))
        # everything else a partial count depends on: data bases and file lists, the extract starts, sample
        # sizes, seeds, the predictors list and the tools' and recipes' source (flags are recomputed each run)
        ident = {k: str(getattr(a, k, "")) for k in (
            "train_base", "val_base", "june_base", "train_files", "val_files", "june_files", "fit_files_used",
            "dup_files", "confirm_file", "train_extract_start", "eval_extract_start", "june_month", "sample_rows",
            "time_sample", "probe_accounts", "seed", "batch_fields", "account_col", "time_col", "id_col",
            "label_col", "use_project_fit")}
        srcs = [HERE / f"{n}.py" for n in ("nf_field_checks", "nf_checks_measure", "nf_checks_rules")]
        for extra in (getattr(a, "recipes", None) or HERE / "nf_recipes.py", getattr(a, "predictors_path", None)):
            if extra:
                srcs.append(Path(extra))
        for pth in srcs:
            ident[str(pth.name)] = _sha_or_none(pth)
        if builder.extra:
            ident["extra_builders"] = ",".join(sorted(builder.extra))
        if getattr(a, "geohash_table_sha256", None):   # TFM's geohash table shapes every geohash field's counts
            ident["geohash_table_sha256"] = a.geohash_table_sha256
        self.run_sha = __import__("hashlib").sha256(json.dumps(ident, sort_keys=True).encode()).hexdigest()

    # ---- partial counts
    def _ppath(self, key: str) -> Path:
        return self.partial / f"{key}.json"

    def _pget(self, key: str):
        p = self._ppath(key)
        if not p.exists():
            return None
        d = json.loads(p.read_text())
        if d.get("thresholds_sha256") != self.th_sha:
            raise Refused(f"partial counts in {self.partial} were made with another thresholds file; "
                          "move that folder away to start again")
        if d.get("map_sha256") != self.map_sha or d.get("run_sha256") != self.run_sha:
            self.log(f"partial {key}: made from another map, data, recipes or settings, recomputed")
            return None
        return d["data"]

    def _pput(self, key: str, data):
        p = self._ppath(key)
        tmp = p.with_suffix(".tmp")
        tmp.write_text(json.dumps({"thresholds_sha256": self.th_sha, "map_sha256": self.map_sha,
                                   "run_sha256": self.run_sha, "data": data},
                                  default=_json_default))
        os.replace(tmp, p)

    # ---- reading one file's rows for a batch of fields
    def frame(self, path: str, specs: List[Dict], with_label: bool = True, extra: List[str] = ()) -> pd.DataFrame:
        cols = [self.acc, self.tcol, self.idc] + ([self.ycol] if with_label else []) + list(extra)
        for s in specs:
            cols += s["sources"] + self.needed_columns(s)
        self._path = path   # the file a build refusal names
        df = self.files.read(path, cols)
        df.index = pd.RangeIndex(len(df))
        return df

    def meta(self, df: pd.DataFrame, with_label=True) -> pd.DataFrame:
        t = pd.to_datetime(df[self.tcol], errors="coerce")
        out = pd.DataFrame({"acct": df[self.acc].astype(str).to_numpy(), "t": t.to_numpy(),
                            "month": M.month_of(t).to_numpy()}, index=df.index)
        if with_label and self.ycol in df.columns:
            out["y"] = (pd.to_numeric(df[self.ycol], errors="coerce") == 1).astype(int).to_numpy()
        return out

    def values(self, s: Dict, df: pd.DataFrame, extract_start: str):
        """One field's values on one file. A recipe the engine refuses while building it here (nf_recipes
        RecipeError, for example an a3 field on times with sub-second parts) is recorded for that field, which
        ends as a STOP row (build_refused); its values are all missing for the rest of the stage, its counts are
        dropped and no later stage builds it, so every other field's checks finish."""
        if s["name"] in self.refused_fields:
            return pd.Series(np.nan, index=df.index, dtype=float), None
        try:
            vals, cens = self.builder.build(s, df, extract_start)
        except self.refusal_errors() as e:
            self.refuse(s, e)
            return pd.Series(np.nan, index=df.index, dtype=float), None
        if cens is not None:
            cens = cens.to_numpy(dtype=bool) & vals.isna().to_numpy()
        return vals, cens

    def refusal_errors(self) -> tuple:
        """The recipe engine's refusal (nf_recipes.RecipeError). Any other error still ends the run."""
        err = getattr(self.builder.recipes, "RecipeError", None)
        return (err,) if isinstance(err, type) and issubclass(err, Exception) else ()

    def refuse(self, s: Dict, e: Exception, where: Optional[str] = None):
        name = s["name"]
        where = where or f"{self.stage} file {Path(str(self._path)).name}"
        self.refused_fields[name] = f"{where}: {e}"
        self.log(f"refused while building: field {name}, {where}: {e}; this field ends as STOP build_refused, "
                 "the other fields' checks go on")
        self._pput("refused", self.refused_fields)   # kept with the partial counts, so a restart keeps the STOP

    def load_refused(self):
        """The build refusals of an earlier run on these partial counts (the files they came from are not
        rebuilt on a restart, so the refusal would not come again)."""
        got = self._pget("refused") or {}
        self.refused_fields.update(got)
        if got:
            self.log(f"refused while building, from the partial counts: {', '.join(sorted(got))}")

    def _keep(self, part: Dict) -> Dict:
        """A stage's per-field counts without the fields the engine refused."""
        return {k: v for k, v in part.items() if k not in self.refused_fields}

    def batches(self, specs: List[Dict]):
        n = max(1, int(self.a.batch_fields))
        for i in range(0, len(specs), n):
            yield specs[i:i + n]

    def buildable(self) -> List[Dict]:
        """The fields the stages build: not those the recipes module cannot build (not_built, WAIT), nor an
        engineered field that reads a column some file lacks (presence: STOP missing_from_files), nor a field the
        engine refused while building it (STOP build_refused)."""
        return [s for s in self.specs if not s["flags"].get("not_built") and not s.get("missing_source")
                and s["name"] not in self.refused_fields]

    def needed_columns(self, s: Dict) -> List[str]:
        """The file columns a field is built from: a raw field its own column; an engineered field the map's
        source_columns and every column its recipe reads (nf_recipes.parse(recipe).sources, the columns the recipe
        engine requires), so a map row that leaves one out still has it read and checked for presence."""
        if "needs" not in s:
            need = [s["column"]] if s["fn"] == "raw" else list(s["sources"])
            r = self.builder.recipes
            if s["fn"] != "raw" and s["fn"] not in self.builder.extra and r is not None and hasattr(r, "parse"):
                try:
                    need += [c for c in r.parse(s["recipe"]).sources if c not in need]
                except ValueError:   # nf_recipes.RecipeError: flagged not_built before the first stage
                    pass
            s["needs"] = need
        return s["needs"]

    # ---- stage: presence from footers
    def presence(self, ranges: Dict[str, Tuple[str, List[int]]]):
        self.log(f"presence: footers of {sum(len(v[1]) for v in ranges.values())} files")
        cols_seen: Dict[str, set] = {}
        missing_files = []
        lacking: Dict[str, set] = {}
        for rname, (base, nums) in ranges.items():
            for n in nums:
                p = file_path(base, n)
                try:
                    cols = set(self.files.columns(p))
                except Exception as e:  # an absent or unreadable file is reported, not hidden
                    missing_files.append(f"{rname}:{n} ({type(e).__name__})")
                    cols = None
                for s in self.specs:
                    lack = [c for c in self.needed_columns(s) if cols is None or c not in cols]
                    if lack:
                        self.m[s["name"]].setdefault("missing_from_files", []).append(
                            f"{rname}:{n}:{','.join(lack)}")
                        if cols is not None and s["fn"] != "raw":
                            lacking.setdefault(s["name"], set()).update(lack)
                if cols is not None:
                    cols_seen[f"{rname}:{n}"] = cols
        self.files_unreadable = missing_files
        all_cols = set().union(*cols_seen.values()) if cols_seen else set()
        self.pod_columns = len(all_cols)
        # A field missing from any file of a range does not enter; keep the first five for the reason.
        for s in self.specs:
            mm = self.m[s["name"]].get("missing_from_files")
            if mm:
                self.m[s["name"]]["missing_from_files"] = mm[:5] + ([f"... {len(mm) - 5} more"] if len(mm) > 5 else [])
        # An engineered field that reads a column a file lacks cannot be built there (the recipe engine refuses
        # it): no stage builds it, so it ends as a STOP row (missing_from_files) and every other field's results
        # stay as they are. The partial counts are kept apart from a run that built it.
        for s in self.specs:
            if s["name"] in lacking:
                s["missing_source"] = ",".join(sorted(lacking[s["name"]]))
        if lacking:
            names = sorted(lacking)
            self.log(f"presence: not built, a column is missing from a file: {', '.join(names)}")
            self.run_sha = __import__("hashlib").sha256(
                json.dumps([self.run_sha, names], sort_keys=True).encode()).hexdigest()

    # ---- stage: training files, all rows
    def train(self, base: str, nums: List[int]):
        self.stage = "train"
        specs = self.buildable()
        edges_key = "edges"
        edges = self._pget(edges_key)
        if edges is None:
            edges = {}
            df = None
            for batch in self.batches([s for s in specs if s["model_type"] == "continuous"]):
                df = self.frame(file_path(base, nums[0]), batch)
                for s in batch:
                    vals, _ = self.values(s, df, self.a.train_extract_start)
                    num, _ = M.as_number(vals)
                    edges[s["name"]] = M.decile_edges(num, int(self.th.num("psi_bins")))
                    edges["__fine__" + s["name"]] = M.decile_edges(num, AP_BINS)
            self._pput(edges_key, edges)
        self.fine_edges = {k[len("__fine__"):]: v for k, v in edges.items() if k.startswith("__fine__")}
        self.edges = {k: v for k, v in edges.items() if not k.startswith("__fine__")}
        pooled: Dict[str, Dict] = {s["name"]: {} for s in specs}
        samples: Dict[str, List] = {s["name"]: [[], []] for s in specs if s["model_type"] == "continuous"}
        for n in nums:
            key = f"train_{n}"
            part = self._pget(key)
            if part is None:
                self.log(f"train file {n}: reading")
                part = self._train_file(file_path(base, n), specs, seed=self.a.seed + n)
                self._pput(key, part)
            else:
                self.log(f"train file {n}: partial counts reused")
            for name, d in part.items():
                if name not in pooled:   # refused while building (on this file or an earlier run's)
                    continue
                self._pool_train(pooled[name], d)
                if name in samples and d.get("tsample"):
                    samples[name][0].extend(d["tsample"][0])
                    samples[name][1].extend(d["tsample"][1])
        for s in specs:
            if s["name"] in self.refused_fields:
                continue
            self._finish_train(s, pooled[s["name"]], samples.get(s["name"]))
        # the clock ceiling (the reviewers' decision D3d): the largest V and NMI a pure clock reaches in the month
        # table, from the pooled training month shares and psi_bins
        months = next((pooled[s["name"]]["missing"]["by_month"] for s in specs
                       if pooled[s["name"]].get("missing")), None) or {}
        rows = [v[0] for _, v in sorted(months.items())]
        self.clock = M.clock_ceiling(rows, int(self.th.num("psi_bins")))
        self.train_window_days = len(rows) and sum(
            pd.Period(k, "M").days_in_month for k in months) or 0

    def _train_file(self, path: str, specs: List[Dict], seed: int) -> Dict:
        out: Dict[str, Dict] = {}
        ev = None
        meta = None
        try:   # the file's columns, for a CURR timestamp's PREV column (the reviewers' decision D3b)
            self.columns_seen = getattr(self, "columns_seen", set()) | set(self.files.columns(path))
        except Exception:   # noqa: BLE001 - a test file reader without a schema
            pass
        for batch in self.batches(specs):
            # TFM's precomputed geohash columns, read when a file holds them (Files.read skips absent columns)
            df = self.frame(path, batch, extra=[s["tfm_geohash_column"] for s in batch if s.get("tfm_geohash_column")])
            if meta is None:
                meta = self.meta(df)
                ps = self.th("pseudo_event_seed")
                ev = M.FileEvents(meta, seed=int(ps) + seed - self.a.seed if ps is not None else seed,
                                  after_days=self.th.num("change_after_event_days"),
                                  reissue_days=self.th.num("reissue_window_days"))
            for s in batch:
                vals, cens = self.values(s, df, self.a.train_extract_start)
                d: Dict = {"missing": M.missing_counts(vals, meta, cens)}
                src = s["sources"][0] if s["is_date"] and s["sources"] and s["sources"][0] in df.columns else None
                pre_keys = M.bin_keys(vals, s["model_type"], self.edges.get(s["name"]))
                d["events"] = ev.stats(vals, keys=pre_keys,
                                       change_values=df[src] if src else None)
                for k in ("pre_counts_a", "pre_counts_b"):
                    if d["events"].get(k) is not None and len(d["events"][k]) > self.cap:
                        d["events"][k] = {}
                        d["pre_over"] = True
                if src:
                    d["same_day"] = M.same_day_counts(df[src], meta, ev)
                if s["fn"] == "raw" and pd.api.types.is_datetime64_any_dtype(vals):
                    d["raw_date"] = True
                if s["model_type"] == "continuous":
                    num, fail = M.as_number(vals)
                    d["num_fail"] = fail
                    d["number"] = M.number_counts(num)
                    keys = M.bin_keys(vals, "continuous", self.edges.get(s["name"]))
                    tt, vv = M.time_sample(meta["t"], num, self.a.time_sample, seed)
                    d["tsample"] = [tt.tolist(), vv.tolist()]
                else:
                    keys = M.code_keys(vals)
                    num, _ = M.as_number(vals)
                    nn = M.number_counts(num)
                    d["number"] = nn if nn["n_num"] == int(vals.notna().sum()) else None
                    vl = M.value_label_counts(keys, meta["y"].to_numpy())
                    d["train_rates"] = vl if len(vl) <= self.cap else "over"
                d["month_table"] = M.contingency(keys, meta["month"], self.cap)
                # the reviewers' decision D3d (and the notes' item 10.7.5): the table on rows the extract start
                # does not censor, genuine missing as its own bin, and the table of present values only
                unc = ~(cens if cens is not None else np.zeros(len(vals), dtype=bool))
                present = unc & ~M.is_missing(vals)
                d["month_table_unc"] = M.contingency(keys[unc], meta["month"][unc], self.cap)
                d["month_table_present"] = M.contingency(keys[present], meta["month"][present], self.cap)
                built = self.builder.last_built
                if s["is_date"]:
                    y = meta["y"].to_numpy()
                    if built is not None and built.signed is not None:
                        # D3b: the after-transaction rows are missing in the value; count them from the reasons
                        # and the signed difference, so the existing stops keep their counts
                        d.update(self._date_measures(s, df, built, y))
                    else:
                        signed = -vals if s["fn"] in ("days_until", "days_to") else vals  # as days before
                        d["date"] = M.date_after_counts(signed, y)
                    src = s["sources"][0] if s["sources"] else None
                    if src and src in df.columns and "date_parse" not in d:
                        d["date_parse"] = self._date_parse(s, df[src], vals, cens)
                if s["is_date"] or s["fn"] in ("since_last", "since_first"):
                    d["event_days"] = self._event_days(s, built, vals, meta, seed)
                if s["fn"] == "raw" and s.get("column") in df.columns and \
                        not pd.api.types.is_datetime64_any_dtype(df[s["column"]]):
                    d["date_like"] = self._date_like(df[s["column"]], seed)
                if s["group_key"] and s["group_key"] in df.columns:
                    d["key_values"] = sorted(set(df[s["group_key"]].dropna().astype(str)))[:2_000_000]
                col = s.get("tfm_geohash_column")
                if col and col in df.columns:
                    d["tfm_geohash"] = self.builder.recipes.precomputed_geohash_match(
                        df, s["recipe"], col, table=self.builder.geohash_table)
                out[s["name"]] = d
        return self._keep(out)

    def _date_measures(self, s: Dict, df: pd.DataFrame, b, y: np.ndarray) -> Dict:
        """A date recipe's counts from its per-row reasons (the reviewers' decision D3b): the after-transaction
        counts by label, each reason by label, the most frequent dates, the hours of (t - d) within a day either
        side, the rows dated in the transaction's own second, and a CURR/PREV pair's counts."""
        out: Dict = {"date": M.date_after_counts(b.signed, y), "date_reasons": M.reason_counts(b.reasons, y)}
        rep = (b.report or {}).get("parse", {})
        out["date_parse"] = [int(rep.get("non_null", 0)), int(rep.get("failed", 0))]
        day, timed = b.detail.get("day"), b.detail.get("timed")
        if day is not None:
            out["date_days"] = M.top_days(day)
        if timed is not None:
            out["date_hours"] = M.hour_histogram(b.signed, timed)
            same = timed & (np.asarray(b.signed) == 0)
            out["date_refresh"] = [int((np.asarray(day) >= 0).sum()) if day is not None else 0, int(same.sum()),
                                   int(timed.sum())]
        if "prev_rows" in rep:
            out["pair"] = [int(rep.get("prev_rows", 0)), int(rep.get("pair_both_present", 0)),
                           int(rep.get("prev_not_earlier", 0))]
        return out

    def _event_days(self, s: Dict, b, vals: pd.Series, meta: pd.DataFrame, seed: int) -> List[float]:
        """A sample of the field's event dates (day numbers): t less the date's distance for a date field, t less
        the interval for since_last and since_first (the reviewers' decision D3d)."""
        tday = meta["t"].to_numpy(dtype="datetime64[ns]").astype(np.int64) / (86_400 * 1e9)
        if b is not None and b.signed is not None:
            back = np.asarray(b.signed, dtype=float)      # days before the transaction (negative: after it)
        else:
            num, _ = M.as_number(vals)
            back = np.expm1(num.to_numpy(dtype=float)) / 86_400   # ln(1 + seconds) back to days
        ev = tday - back
        ok = np.flatnonzero(np.isfinite(ev))
        if len(ok) > self.a.time_sample:
            ok = np.random.default_rng(seed).choice(ok, self.a.time_sample, replace=False)
        return [float(x) for x in ev[ok]]

    def _date_like(self, source: pd.Series, seed: int) -> Dict:
        """How many of a raw field's non-null values parse as dates under the date rules (yyyymmdd, epoch
        seconds, epoch milliseconds, ISO text), on a fixed sample of 100,000 (the reviewers' decision D3d)."""
        r = self.builder.recipes
        nn = source.dropna()
        if r is None or not hasattr(r, "parse_dates_detail") or not len(nn):
            return {"n": int(len(nn)), "dates": 0, "rules": {}}
        if len(nn) > 100_000:
            nn = nn.sample(100_000, random_state=seed)
        try:
            _, rep, _, why = r.parse_dates_detail(nn.reset_index(drop=True))
        except ValueError:
            return {"n": int(len(nn)), "dates": 0, "rules": {}}
        return {"n": int(len(nn)), "dates": int((why == "").sum() + (why == "sentinel").sum()),
                "rules": {k: int(v) for k, v in (rep.get("rules") or {}).items()}}

    def _prev_name(self, s: Dict) -> str:
        """The PREV column of a CURR timestamp: the recipe's prev=, else a column named like it with prev for
        curr, if the file holds one; blank otherwise."""
        r = self.builder.recipes
        try:
            rec = r.parse(s["recipe"]) if r is not None else None
        except ValueError:
            rec = None
        if rec is not None and getattr(rec, "prev_column", None):
            return rec.prev_column
        src = s["sources"][0] if s["sources"] else ""
        if "curr" in src.lower():
            cand = re.sub("curr", "prev", src, flags=re.IGNORECASE)
            return cand if cand in getattr(self, "columns_seen", set()) else ""
        return ""

    def _date_parse(self, s: Dict, source: pd.Series, vals: pd.Series, cens) -> List[int]:
        """[non-null source values, values that fail to parse], counted by the date parser itself
        (nf_recipes.parse_dates). Not every missing output: days_before leaves a date with no time part on the
        transaction's own day missing by design (same_day=missing), and that is not a parse failure."""
        r = self.builder.recipes
        if r is not None and s["fn"] not in self.builder.extra and hasattr(r, "parse") and hasattr(r, "parse_dates"):
            try:
                _, rep, _ = r.parse_dates(source, r.parse(s["recipe"]).date_format)
                return [int(rep["non_null"]), int(rep["failed"])]
            except ValueError:   # nf_recipes.RecipeError; the build itself reports it
                pass
        # another builder (tests, or no recipes module): a missing output that is not censored
        src_nn = source.notna().to_numpy()
        cz = cens if cens is not None else np.zeros(len(source), dtype=bool)
        return [int(src_nn.sum()), int((src_nn & vals.isna().to_numpy() & ~cz).sum())]

    def _pool_train(self, acc: Dict, d: Dict):
        acc["missing"] = M.add_missing(acc.get("missing"), d["missing"])
        acc["events"] = M.add_counts(acc.get("events"), d["events"])
        if "same_day" in d:
            acc["same_day"] = M.add_counts(acc.get("same_day"), d["same_day"])
        acc["pre_over"] = acc.get("pre_over", False) or d.get("pre_over", False)
        acc["raw_date"] = acc.get("raw_date", False) or d.get("raw_date", False)
        acc["num_fail"] = acc.get("num_fail", 0) + d.get("num_fail", 0)
        if "number" in d:
            if d["number"] is None or acc.get("number", {}) is None:
                acc["number"] = None
            else:
                acc["number"] = M.add_number(acc.get("number"), d["number"])
        if "train_rates" in d:
            if d["train_rates"] == "over" or acc.get("train_rates") == "over":
                acc["train_rates"] = "over"
            else:
                acc["train_rates"] = M.add_value_label(acc.get("train_rates"), d["train_rates"])
        acc["month_table"] = M.add_contingency(acc.get("month_table"), d["month_table"], self.cap)
        for k in ("month_table_unc", "month_table_present"):
            if k in d:
                acc[k] = M.add_contingency(acc.get(k), d[k], self.cap)
        if "date_reasons" in d:
            acc["date_reasons"] = M.add_reason_counts(acc.get("date_reasons"), d["date_reasons"])
        if "date_days" in d:
            acc["date_days"] = M.add_top_days(acc.get("date_days"), d["date_days"])
        if "date_hours" in d:
            acc["date_hours"] = M.add_counts(acc.get("date_hours"), d["date_hours"])
        for k in ("date_refresh", "pair"):
            if k in d:
                old = acc.get(k) or [0] * len(d[k])
                acc[k] = [a + b for a, b in zip(old, d[k])]
        if "event_days" in d:
            acc.setdefault("event_days", []).extend(d["event_days"])
        if "date_like" in d:
            dl = acc.setdefault("date_like", {"n": 0, "dates": 0, "rules": {}})
            dl["n"] += d["date_like"]["n"]
            dl["dates"] += d["date_like"]["dates"]
            for k, v in d["date_like"]["rules"].items():
                dl["rules"][k] = dl["rules"].get(k, 0) + v
        if "date" in d:
            acc["date"] = M.add_counts(acc.get("date"), d["date"])
        if "date_parse" in d:
            old = acc.get("date_parse", [0, 0])
            acc["date_parse"] = [old[0] + d["date_parse"][0], old[1] + d["date_parse"][1]]
        if "key_values" in d:
            acc.setdefault("key_files", []).append(set(d["key_values"]))
        if "tfm_geohash" in d:
            tg = acc.setdefault("tfm_geohash", {"column": d["tfm_geohash"]["column"]})
            for k in ("rows", "match", "tfm_only", "ours_only", "differ"):
                tg[k] = tg.get(k, 0) + int(d["tfm_geohash"][k])
            tg["files"] = tg.get("files", 0) + 1

    def _finish_train(self, s: Dict, acc: Dict, sample):
        m = self.m[s["name"]]
        m["measured"] = True
        m["model_type"] = s["model_type"]
        mc = acc["missing"]
        rows = mc["rows"]
        m["train_rows"] = rows
        m["train_missing_n"] = mc["missing"]
        m["train_censored_n"] = mc["censored"]
        m["train_nonnull"] = rows - mc["missing"] - mc["censored"]
        m["missing_train"] = (mc["missing"] + mc["censored"]) / rows if rows else float("nan")
        m["by_month"] = mc["by_month"]
        lab = mc["by_label"]
        fr, nf = lab.get("fraud", [0, 0, 0]), lab.get("nonfraud", [0, 0, 0])
        m["fill_fraud"] = (fr[0] - fr[1] - fr[2]) / fr[0] if fr[0] else float("nan")
        m["fill_nonfraud"] = (nf[0] - nf[1] - nf[2]) / nf[0] if nf[0] else float("nan")
        m["missing_fraud"] = 1 - m["fill_fraud"] if fr[0] else float("nan")
        m["missing_nonfraud"] = 1 - m["fill_nonfraud"] if nf[0] else float("nan")
        # D9-Y16: missing rows (censored included) and the frauds among them, for the summary's flag count
        m["train_frauds"] = fr[0]
        m["train_missing_rows"] = mc["missing"] + mc["censored"]
        m["train_missing_frauds"] = fr[1] + fr[2]
        m.update(M.event_measures(acc["events"]))
        if s["fn"] not in ROW_LEVEL and not s["is_date"]:
            # a history recipe changes whenever history changes; the strictly-earlier probes check it,
            # and its source fields carry the stored-value rules (inherited, review item 28)
            for k in ("change_at_event", "change_at_pseudo", "change_after_event", "change_after_pseudo",
                      "refresh_event", "refresh_pseudo", "reissue_event", "reissue_pseudo"):
                m[k] = float("nan")
        m["is_profile"] = s["is_profile"]
        if acc.get("raw_date"):
            m["raw_date"] = "a stored date entered as is; dates enter only as days before the transaction"
        pa, pb = acc["events"].get("pre_counts_a"), acc["events"].get("pre_counts_b")
        if pa and pb and not acc.get("pre_over"):
            n_all = sum(v[0] for v in list(pa.values()) + list(pb.values()))
            p_all = sum(v[1] for v in list(pa.values()) + list(pb.values()))
            aps = [x for x in (M.code_ap(pa, pb), M.code_ap(pb, pa)) if not math.isnan(x)]
            m["pre_event_ap"] = float(np.mean(aps)) if aps else float("nan")
            m["pre_event_base"] = p_all / n_all if n_all else float("nan")
        sd = acc.get("same_day")
        if sd:
            m["same_day_fraud"] = sd["sd_fraud"] / sd["sd_fraud_n"] if sd["sd_fraud_n"] else float("nan")
            m["same_day_nonfraud"] = sd["sd_nonfraud"] / sd["sd_nonfraud_n"] if sd["sd_nonfraud_n"] else float("nan")
            m["same_day_event"] = sd["sd_f_event"] / sd["sd_f_event_n"] if sd["sd_f_event_n"] else float("nan")
            m["same_day_pseudo"] = sd["sd_p_event"] / sd["sd_p_event_n"] if sd["sd_p_event_n"] else float("nan")
        m["num_fail"] = acc.get("num_fail", 0)
        num = acc.get("number")
        if num:
            m["mean"], m["sd"] = M.mean_sd(num)
            m["calendar_shape"] = M.calendar_shape(num, int(self.th.num("calendar_min_distinct")),
                                                   self.th.calendar_ranges())
        if s["model_type"] == "continuous" and sample and sample[0]:
            m["time_rho"] = M.spearman(np.asarray(sample[0], dtype=float), np.asarray(sample[1], dtype=float))
        self.train_rates = getattr(self, "train_rates", {})
        if "train_rates" in acc:
            self.train_rates[s["name"]] = acc["train_rates"]
        tab = acc.get("month_table")
        if isinstance(tab, dict):
            train_months = sorted({c for row in tab.values() for c in row})
            m["train_months"] = train_months
            ov = M.overlap_measures(tab)
            m["month_v"], m["month_nmi"] = ov["cramers_v"], ov["nmi"]
            self.bins = getattr(self, "bins", {})
            # the June PSI's reference bins leave out the censored rows (notes item 10.7.5)
            ref = acc.get("month_table_unc") if isinstance(acc.get("month_table_unc"), dict) else tab
            self.bins[s["name"]] = {k: int(sum(v.values())) for k, v in ref.items()}
        else:
            m["month_v"] = m["month_nmi"] = float("nan")
            m["month_note"] = "more bins than the vocabulary stop level"
        # the reviewers' decision D3d: V and NMI on the rows the extract start does not censor, and with the
        # chance part removed on the present values (the hold rule reads these)
        unc, pres = acc.get("month_table_unc"), acc.get("month_table_present")
        if isinstance(unc, dict):
            ov = M.overlap_measures(unc)
            m["month_v_uncensored"], m["month_nmi_uncensored"] = ov["cramers_v"], ov["nmi"]
        if isinstance(pres, dict):
            adj = M.overlap_adjusted(pres)
            m["month_v_present_adj"], m["month_nmi_present_adj"] = adj["v_adj"], adj["nmi_adj"]
        if num:
            m["train_min"], m["train_max"] = num.get("min"), num.get("max")
        ev = acc.get("event_days")
        if ev:
            q10, q90 = np.percentile(np.asarray(ev, dtype=float), [10, 90])
            m["event_spread_days"] = float(q90 - q10)
        dr = acc.get("date_reasons")
        if dr:
            fr_rows, nf_rows = dr.get("__rows__", [0, 0])
            m["date_reasons"] = {k: {"fraud": v[0] / fr_rows if fr_rows else float("nan"),
                                     "nonfraud": v[1] / nf_rows if nf_rows else float("nan")}
                                 for k, v in dr.items() if k != "__rows__"}
        if _num_ok(m.get("missing_fraud")) and _num_ok(m.get("missing_nonfraud")) and m["missing_nonfraud"] > 0:
            m["missing_lift"] = m["missing_fraud"] / m["missing_nonfraud"]
        dd = acc.get("date_days")
        if dd and dd.get("__n__"):
            n_days = dd["__n__"]
            top = sorted(((k, v) for k, v in dd.items() if k != "__n__"), key=lambda kv: -kv[1])[:5]
            m["date_top"] = {str(pd.Timestamp(int(k) * 86_400 * 10 ** 9).date()): v / n_days for k, v in top}
            m["date_default"] = [d for d, sh in m["date_top"].items() if sh >= 0.01]
        if acc.get("date_hours"):
            m["date_hours"] = {k: int(v) for k, v in sorted(acc["date_hours"].items(), key=lambda kv: int(kv[0]))}
        rf = acc.get("date_refresh")
        if rf and rf[2] and rf[0]:      # a timestamp field: the rows dated in the transaction's own second
            m["same_second_share"] = rf[1] / rf[0]
            m["same_second_prev"] = self._prev_name(s)
        pr = acc.get("pair")
        if pr:
            m["prev_rows"], m["pair_both_present"] = pr[0], pr[1]
            m["prev_not_earlier_share"] = pr[2] / pr[1] if pr[1] else 0.0
        dl = acc.get("date_like")
        if dl and dl["n"]:
            m["date_like_share"] = dl["dates"] / dl["n"]
            m["date_like_rule"] = max(dl["rules"], key=dl["rules"].get) if dl["rules"] else ""
        if "date" in acc:
            d = acc["date"]
            m.update({k: d.get(k, 0) for k in ("date_nonnull", "date_after", "date_nonnull_fraud", "date_after_fraud",
                                               "date_nonnull_nonfraud", "date_after_nonfraud")})
            m["future_by_meaning"] = s["future_by_meaning"]
        if "date_parse" in acc and acc["date_parse"][0]:
            m["date_parse_share"] = acc["date_parse"][1] / acc["date_parse"][0]
        if "key_files" in acc:
            sets = acc["key_files"]
            seen, spans = set(), 0
            for st in sets:
                spans += len(seen & st)
                seen |= st
            if spans:
                m["group_key_spans_files"] = f"{s['group_key']}: {spans} values in more than one file"
        tg = acc.get("tfm_geohash")
        if tg:   # TFM's precomputed column against the recipe, over every training file that holds it
            m["tfm_geohash_match"] = dict(tg, share=(tg["match"] / tg["rows"]) if tg["rows"] else None)
        # missing by month: the largest distance from the training-wide share
        self._drift(m)

    def _drift(self, m: Dict):
        """Missing by month against the training share, both among the rows whose value can be known. A censored
        row (its window reaches before the extract start) is missing by design, so it never counts as drift; the
        censored rows per month stay apart in missing_by_month.csv."""
        known = (m.get("train_rows") or 0) - (m.get("train_censored_n") or 0)
        share = (m.get("train_missing_n") or 0) / known if known > 0 else float("nan")
        worst, wm = 0.0, ""
        for mon, (r, mi, ce) in (m.get("by_month") or {}).items():
            if r - ce > 0 and not math.isnan(share):
                d = abs(mi / (r - ce) - share) * 100.0
                if d > worst:
                    worst, wm = d, mon
        m["missing_drift_points"], m["missing_drift_month"] = worst, wm

    # ---- stage: vocabulary on the fit files (codes)
    def fit(self, base: str, nums: List[int]):
        self.stage = "fit"
        specs = [s for s in self.buildable() if s["model_type"] != "continuous"]
        part = self._pget("fit")
        if part is None:
            part = {}
            fit_stats = _load("nf_layout").attr("preprocessing", "fit_categorical_stats") if self.a.use_project_fit \
                else None
            for batch in self.batches(specs):
                per_file = {s["name"]: [] for s in batch}
                accounts = {s["name"]: {} for s in batch}
                for n in nums:
                    df = self.frame(file_path(base, n), batch, with_label=False)
                    for s in batch:
                        vals, _ = self.values(s, df, self.a.train_extract_start)
                        per_file[s["name"]].append((n, vals))
                        # distinct accounts per value (the fit files hold whole accounts, so they add up)
                        ok = vals.notna().to_numpy()
                        if ok.any():
                            g = pd.DataFrame({"v": M.code_keys(vals[ok]).to_numpy(),
                                              "a": df[self.acc].to_numpy()[ok]}).groupby("v")["a"].agg(
                                ["nunique", "size"])
                            acc = accounts[s["name"]]
                            for v, (na, nr) in g.iterrows():
                                cur = acc.setdefault(str(v), [0, 0])
                                cur[0] += int(na)
                                cur[1] += int(nr)
                for s in batch:
                    allv = pd.concat([v for _, v in per_file[s["name"]]], ignore_index=True)
                    if fit_stats is not None:
                        vocab = fit_stats(allv)["vocab"]
                    else:
                        vocab = {k: i for i, k in enumerate(allv.dropna().astype(str).value_counts().index, start=2)}
                    if len(vocab) > self.cap * 10:
                        part[s["name"]] = {"vocab_size": len(vocab), "vocab": None, "unk": {}}
                        continue
                    unk = {}
                    for n, v in per_file[s["name"]]:
                        unk[str(n)] = unknown_share(v, vocab)
                    # the cap of the extended artifact (the reviewers' decision D9-Y20): values seen in at least
                    # CAP_MIN_ACCOUNTS accounts over the fit files; the rest encode to the unknown index
                    acc = accounts[s["name"]]
                    kept = sorted(v for v, (na, _) in acc.items() if na >= CAP_MIN_ACCOUNTS)
                    kept_set = set(kept)
                    unk_capped = {str(n): [int(v.notna().sum()), int(unknown_count(v, kept_set))]
                                  for n, v in per_file[s["name"]]}
                    rare = sum(nr for v, (_, nr) in acc.items() if v not in kept_set)
                    rows = sum(nr for _, nr in acc.values())
                    part[s["name"]] = {"vocab_size": len(vocab), "vocab": sorted(vocab), "unk": unk,
                                       "capped": {"kept": kept, "unk": unk_capped, "rare_rows": [rare, rows]}}
            part = self._keep(part)
            self._pput("fit", part)
        self.vocab = {}
        self.vocab_capped = {}
        for name, d in self._keep(part).items():
            m = self.m[name]
            m["vocab_size"] = d["vocab_size"]
            self.vocab[name] = set(d["vocab"]) if d["vocab"] is not None else None
            if d["unk"]:
                f, u = max(d["unk"].items(), key=lambda kv: kv[1])
                m["unk_fit_max"], m["unk_fit_file"] = u, f
                m["unk_fit"] = d["unk"]
            cp = d.get("capped")
            if cp:   # every new code field is capped in the extended artifact (D9-Y20)
                m["capped"] = True
                self.vocab_capped[name] = set(cp["kept"])
                m["capped_kept"] = len(cp["kept"])
                rare, rows = cp["rare_rows"]
                m["capped_rare_row_share"] = rare / rows if rows else float("nan")
                lo = [cp["unk"][k] for k in cp["unk"] if int(k) <= 5]
                hi = [cp["unk"][k] for k in cp["unk"] if int(k) > 5]
                for key, part_ in (("unk_capped_files_1_5", lo), ("unk_capped_files_6_10", hi)):
                    n_, u_ = sum(x[0] for x in part_), sum(x[1] for x in part_)
                    m[key] = u_ / n_ if n_ else float("nan")

    # ---- stage: EPOCH_VAL (single-field AP, unknown share)
    def val(self, base: str, nums: List[int]):
        self.stage = "val"
        specs = self.buildable()
        pooled: Dict[str, Dict] = {}
        for n in nums:
            key = f"val_{n}"
            part = self._pget(key)
            if part is None:
                self.log(f"validation file {n}: reading")
                part = {}
                for batch in self.batches(specs):
                    df = self.frame(file_path(base, n), batch)
                    y = (pd.to_numeric(df[self.ycol], errors="coerce") == 1).astype(int).to_numpy()
                    for s in batch:
                        vals, _ = self.values(s, df, self.a.train_extract_start)
                        d = {}
                        if s["model_type"] == "continuous":
                            num, _ = M.as_number(vals)
                            d["vl"] = M.value_label_counts(M.fine_bin_keys(num, self.fine_edges.get(s["name"])), y)
                        else:
                            keys = M.code_keys(vals)
                            d["vl"] = M.value_label_counts(keys, y)
                            voc = self.vocab.get(s["name"])
                            if voc is not None:
                                d["unk"] = [int(len(vals)), int(unknown_count(vals, voc))]
                            cap = getattr(self, "vocab_capped", {}).get(s["name"])
                            if cap is not None:   # D9-Y20: fraud among the rows the cap sends to unknown
                                kk = M.code_keys(vals)
                                unk_rows = ~(kk.isin(cap).to_numpy() | (kk == M.MISSING_KEY).to_numpy())
                                d["unk_capped_fraud"] = [int(unk_rows.sum()), int(y[unk_rows].sum()),
                                                         int((~unk_rows).sum()), int(y[~unk_rows].sum())]
                        part[s["name"]] = d
                part = self._keep(part)
                self._pput(key, part)
            for name, d in self._keep(part).items():
                p = pooled.setdefault(name, {})
                p["vl"] = M.add_value_label(p.get("vl"), d["vl"])
                if "unk" in d:
                    old = p.get("unk", [0, 0])
                    p["unk"] = [old[0] + d["unk"][0], old[1] + d["unk"][1]]
                if "unk_capped_fraud" in d:
                    old = p.get("unk_capped_fraud", [0, 0, 0, 0])
                    p["unk_capped_fraud"] = [a + b for a, b in zip(old, d["unk_capped_fraud"])]
        for s in specs:
            if s["name"] in self.refused_fields:
                continue
            p = pooled.get(s["name"], {})
            m = self.m[s["name"]]
            if "vl" in p:
                if s["model_type"] == "continuous":
                    m["single_ap"] = M.number_ap(p["vl"])
                else:
                    tr = getattr(self, "train_rates", {}).get(s["name"])
                    m["single_ap"] = M.code_ap(tr, p["vl"]) if isinstance(tr, dict) else float("nan")
                tot = sum(v[0] for v in p["vl"].values())
                pos = sum(v[1] for v in p["vl"].values())
                m["val_rows"], m["val_frauds"] = tot, pos
            if "unk" in p and p["unk"][0]:
                m["unk_val"] = p["unk"][1] / p["unk"][0]
            cf = p.get("unk_capped_fraud")
            if cf:
                m["capped_unknown_fraud_rate"] = cf[1] / cf[0] if cf[0] else float("nan")
                m["capped_other_fraud_rate"] = cf[3] / cf[2] if cf[2] else float("nan")

    # ---- stage: Test 1 June rows, no label read
    def june(self, base: str, nums: List[int]):
        self.stage = "june"
        specs = self.buildable()
        pooled: Dict[str, Dict] = {}
        for n in nums:
            key = f"june_{n}"
            part = self._pget(key)
            if part is None:
                self.log(f"June file {n}: reading (no label)")
                part = {}
                for batch in self.batches(specs):
                    df = self.frame(file_path(base, n), batch, with_label=False)
                    t = pd.to_datetime(df[self.tcol], errors="coerce")
                    sel = (M.month_of(t) == self.a.june_month).to_numpy()
                    for s in batch:
                        vals, cens = self.values(s, df, self.a.eval_extract_start)
                        v = vals[sel]
                        c = cens[sel] if cens is not None else np.zeros(int(sel.sum()), dtype=bool)
                        miss = v.isna().to_numpy()
                        d = {"rows": int(sel.sum()), "missing": int((miss & ~c).sum()), "censored": int(c.sum())}
                        # the PSI bins leave out the censored rows (notes item 10.7.5)
                        keys = M.bin_keys(v[~c], s["model_type"], self.edges.get(s["name"]))
                        lo, hi = self.m[s["name"]].get("train_min"), self.m[s["name"]].get("train_max")
                        if s["model_type"] == "continuous" and lo is not None and hi is not None:
                            num, _ = M.as_number(v[~c])
                            x = num.to_numpy(dtype=float)
                            fin = np.isfinite(x)
                            d["outside"] = [int(fin.sum()), int((fin & ((x < lo) | (x > hi))).sum())]
                        vc = keys.value_counts()
                        d["bins"] = {str(k): int(x) for k, x in vc.items()} if len(vc) <= self.cap else "over"
                        voc = self.vocab.get(s["name"]) if s["model_type"] != "continuous" else None
                        if voc is not None:
                            d["unk"] = int(unknown_count(v, voc))
                        cap = getattr(self, "vocab_capped", {}).get(s["name"])
                        if cap is not None:
                            d["unk_capped"] = int(unknown_count(v, cap))
                        part[s["name"]] = d
                part = self._keep(part)
                self._pput(key, part)
            for name, d in self._keep(part).items():
                p = pooled.setdefault(name, {"rows": 0, "missing": 0, "censored": 0, "unk": 0, "bins": {}})
                for k in ("rows", "missing", "censored"):
                    p[k] += d[k]
                p["unk"] += d.get("unk", 0)
                p["has_unk"] = p.get("has_unk", False) or "unk" in d
                if "unk_capped" in d:
                    p["unk_capped"] = p.get("unk_capped", 0) + d["unk_capped"]
                if "outside" in d:
                    o = p.get("outside", [0, 0])
                    p["outside"] = [o[0] + d["outside"][0], o[1] + d["outside"][1]]
                if d["bins"] == "over" or p["bins"] == "over":
                    p["bins"] = "over"
                else:
                    for k, x in d["bins"].items():
                        p["bins"][k] = p["bins"].get(k, 0) + x
        for s in specs:
            if s["name"] in self.refused_fields:
                continue
            p = pooled.get(s["name"])
            m = self.m[s["name"]]
            if not p or not p["rows"]:
                m["june_rows"] = 0
                continue
            m["june_rows"] = p["rows"]
            m["missing_june"] = (p["missing"] + p["censored"]) / p["rows"]
            m["censored_june"] = p["censored"] / p["rows"]
            m.setdefault("by_month", {})[self.a.june_month] = [p["rows"], p["missing"], p["censored"]]
            if p.get("has_unk"):
                m["unk_june"] = p["unk"] / p["rows"]
            if "unk_capped" in p:
                m["unk_june_capped"] = p["unk_capped"] / p["rows"]
            ref = getattr(self, "bins", {}).get(s["name"])
            if ref and isinstance(p["bins"], dict):
                m["psi_june"] = M.psi_counts(ref, p["bins"])
            if p.get("outside") and p["outside"][0]:   # D3d: June values outside the training range
                m["june_outside_train_range"] = p["outside"][1] / p["outside"][0]
            self._drift(m)

    # ---- stage: duplicates, recodes, near duplicates, clusters
    def duplicates(self, base_dir: str, dup_files: List[int], confirm_file: Optional[int]):
        self.stage = "duplicates"
        part = self._pget("dups")
        if part is None:
            self.log(f"duplicates: files {dup_files} (confirm on {confirm_file})")
            part = self._dup_stage(base_dir, dup_files, confirm_file)
            self._pput("dups", part)
        self._apply_dups(part)

    def _units_frame(self, path: str, specs: List[Dict]) -> pd.DataFrame:
        """Base inputs as they enter the model, the id columns, the label, and the batch's fields."""
        cols = list(self.base["raw"]) + [self.acc, self.idc, self.ycol, self.tcol]
        df = self.frame(path, specs, extra=cols)
        return df

    def base_units(self, df: pd.DataFrame) -> Dict[str, Tuple[str, pd.Series]]:
        out = {}
        t = pd.to_datetime(df[self.tcol], errors="coerce")
        for _, r in self.base["table"].iterrows():
            name, typ, src = r["feature"], r["type"], str(r["source"])
            if src.startswith("derived:"):
                f = name
                vals = {"month": t.dt.month, "day": t.dt.day, "hour": t.dt.hour, "day_of_week": t.dt.dayofweek}.get(f)
                if vals is None:
                    continue
                out[name] = (typ, vals.fillna(-1).astype(int))
            elif name in df.columns:
                out[name] = (typ, df[name])
        # the time gap to the previous row of the account (seconds), as the sequence builder adds it
        tt = t.to_numpy(dtype="datetime64[ns]").astype(np.int64)
        order = np.lexsort((np.arange(len(df)), tt, df[self.acc].astype(str).to_numpy()))
        a_sorted = df[self.acc].astype(str).to_numpy()[order]
        gap = np.full(len(df), np.nan)
        same = np.r_[False, a_sorted[1:] == a_sorted[:-1]]
        ts = tt[order]
        g = np.r_[np.nan, (ts[1:] - ts[:-1]) / 1e9]
        gap[order] = np.where(same, g, np.nan)
        out[TIME_GAP] = ("continuous", pd.Series(gap, index=df.index))
        out[self.acc] = ("id", df[self.acc])
        out[self.idc] = ("id", df[self.idc])
        out[self.ycol] = ("label", df[self.ycol])
        return out

    def _dup_stage(self, base_dir: str, dup_files: List[int], confirm_file: Optional[int]) -> Dict:
        specs = self.buildable()
        rng = np.random.default_rng(self.a.seed)
        sizes = []
        for n in dup_files:
            sizes.append(len(self.files.read(file_path(base_dir, n), [self.acc])))
        total = sum(sizes)
        take = np.sort(rng.choice(total, size=min(self.a.sample_rows, total), replace=False)) if total else np.array([], int)
        fps: Dict[str, Dict] = {}
        sample: Dict[str, Tuple[str, np.ndarray]] = {}
        kinds: Dict[str, str] = {}

        scodes: Dict[str, np.ndarray] = {}

        def record(name, typ, series, n_confirm=None):
            scodes[name] = M.factor_codes(series)[take]
            fp, card = M.recode_fingerprint(series)
            fps[name] = {"recode": fp, "text": M.text_fingerprint(series), "card": card}
            kinds[name] = typ
            if typ == "continuous":
                num, _ = M.as_number(series)
                sample[name] = ("num", num.to_numpy(dtype=float)[take])
            else:
                sample[name] = ("code", M.factor_codes(series)[take])

        # base units once (on the first batch's frames), then each batch of fields
        first = True
        for batch in list(self.batches(specs)) or [[]]:
            frames = [self._units_frame(file_path(base_dir, n), batch) for n in dup_files]
            if first:
                bases = [self.base_units(f) for f in frames]
                for name in bases[0]:
                    typ = bases[0][name][0]
                    record(name, typ, pd.concat([b[name][1] for b in bases], ignore_index=True))
                first = False
            for s in batch:
                parts = []
                for f in frames:
                    v, _ = self.values(s, f, self.a.train_extract_start)
                    parts.append(v.reset_index(drop=True))
                typ = "continuous" if s["model_type"] == "continuous" else "categorical"
                record(s["name"], typ, pd.concat(parts, ignore_index=True))
        # confirm exact pairs on another file
        confirm = {}
        if confirm_file is not None:
            groups = _groups(fps, self.th.num("recode_max_unique_share") * max(total, 1)) + _text_groups(fps)
            names = sorted({n for g in groups for n in g})
            if names:
                cspecs = [s for s in specs if s["name"] in names]
                f = self._units_frame(file_path(base_dir, confirm_file), cspecs)
                bu = self.base_units(f)
                for n in names:
                    if n in bu:
                        confirm[n] = M.recode_fingerprint(bu[n][1])[0]
                for s in cspecs:
                    v, _ = self.values(s, f, self.a.train_extract_start)
                    confirm[s["name"]] = M.recode_fingerprint(v)[0]
        # pairwise association on the sample
        names = list(sample)
        pairs = []
        field_names = {s["name"] for s in specs}
        for i, a in enumerate(names):
            for b in names[i + 1:]:
                if a not in field_names and b not in field_names:
                    continue
                if kinds.get(a) in ("id", "label") or kinds.get(b) in ("id", "label"):
                    continue
                pairs.append(_pair_measures(a, b, sample[a], sample[b], fps))
        # many-to-one recodes: H(field | other) = 0 on the sample, confirmed on the confirm file
        funcs = self._function_of(scodes, fps, kinds, field_names, base_dir, confirm_file, specs)
        gone = set(self.refused_fields)   # a field refused while building takes no part in any pair
        if gone:
            fps, confirm, kinds = self._keep(fps), self._keep(confirm), self._keep(kinds)
            pairs = [p for p in pairs if p["a"] not in gone and p["b"] not in gone]
            funcs = [c for c in funcs if not gone & set(c)]
        return {"fps": fps, "confirm": confirm, "kinds": kinds, "pairs": pairs, "function_of": funcs,
                "rows": int(total), "sample": int(len(take))}

    def _function_of(self, scodes, fps, kinds, field_names, base_dir, confirm_file, specs) -> List[List[str]]:
        n_s = len(next(iter(scodes.values()))) if scodes else 0
        if not n_s:
            return []
        max_card = self.th.num("recode_max_unique_share") * n_s
        min_rows = self.th.num("function_of_min_rows_per_value")
        cards = {k: len(np.unique(v)) for k, v in scodes.items()}
        fields = [n for n in scodes if cards[n] >= 2 and kinds.get(n) not in ("id", "label") and n != TIME_GAP]
        if not fields:
            return []
        fr = pd.DataFrame({n: scodes[n] for n in fields})
        cands = []
        for b, cb in cards.items():
            if kinds.get(b) in ("id", "label") or cb < 2 or cb > max_card or n_s / cb < min_rows:
                continue
            ent_lim = self.th.num("function_of_entropy")
            nun = fr.groupby(scodes[b], sort=False).nunique().max() if ent_lim <= 0 else None
            for a in fields:
                if a == b or cards[a] >= cb or fps[a]["recode"] == fps[b]["recode"]:
                    continue
                if (nun is not None and int(nun[a]) == 1) or \
                        (nun is None and M.conditional_entropy(scodes[a], scodes[b]) <= ent_lim + 1e-12):
                    cands.append([a, b])
        if not cands or confirm_file is None:
            return cands
        need = sorted({x for c in cands for x in c})
        cspecs = [sp for sp in specs if sp["name"] in need]
        f = self._units_frame(file_path(base_dir, confirm_file), cspecs)
        units = {k: v[1] for k, v in self.base_units(f).items() if k in need}
        for sp in cspecs:
            units[sp["name"]], _ = self.values(sp, f, self.a.train_extract_start)
        codes = {k: M.factor_codes(v) for k, v in units.items()}
        out = []
        for a, b in cands:
            if a not in codes or b not in codes:
                continue
            ca = len(np.unique(codes[a]))
            if ca < 2:
                continue
            if self.th.num("function_of_entropy") <= 0:
                ok = int(pd.Series(codes[a]).groupby(codes[b], sort=False).nunique().max()) == 1
            else:
                ok = M.conditional_entropy(codes[a], codes[b]) <= self.th.num("function_of_entropy") + 1e-12
            if ok:
                out.append([a, b])
        return out

    def _apply_dups(self, part: Dict):
        fps, confirm, kinds = part["fps"], part["confirm"], part["kinds"]
        self.dup_rows = part["rows"]
        self.pairs = part["pairs"]
        self.function_pairs = part.get("function_of", [])
        spec_by = {s["name"]: s for s in self.specs}
        base_order = list(self.base["table"]["feature"]) + [TIME_GAP]
        self.dup_list = []

        def prec(n):
            if n in spec_by:
                return (1,) + precedence(spec_by[n])
            if n in base_order:
                return (0, 0, base_order.index(n))
            return (0, 0, 10_000)

        for s in self.specs:
            if s["name"] in fps:
                self.m[s["name"]]["distinct_train"] = fps[s["name"]]["card"]
        max_card = self.th.num("recode_max_unique_share") * max(self.dup_rows, 1)
        seen_groups = set()
        for g in _groups(fps, max_card) + _text_groups(fps):
            key = tuple(sorted(g))
            if key in seen_groups:
                continue
            seen_groups.add(key)
            if confirm:
                g = [n for n in g if confirm.get(n) is not None]
                sub: Dict[str, List[str]] = {}
                for n in g:
                    sub.setdefault(confirm[n], []).append(n)
                gs = [x for x in sub.values() if len(x) >= 2]
            else:
                gs = [g]
            for grp in gs:
                label = [n for n in grp if kinds.get(n) == "label"]
                ids = [n for n in grp if kinds.get(n) == "id"]
                fields = sorted([n for n in grp if n in spec_by], key=prec)
                others = sorted([n for n in grp if n not in spec_by and kinds.get(n) not in ("id", "label")], key=prec)
                if label:
                    for n in fields:
                        if not self.m[n].get("label_copy"):
                            self.m[n]["label_copy"] = f"one-to-one recode of {label[0]}"
                            self.dup_list.append((n, label[0], "label_copy"))
                    continue
                keeper = ids[0] if ids else (others[0] if others else (fields[0] if fields else None))
                excluded = keeper in spec_by and bool(spec_by[keeper]["flags"].get("excluded_by_sumegha"))
                for n in fields:
                    if n == keeper or self.m[n].get("duplicate_of"):
                        continue
                    if excluded and spec_by[n]["group"] == "f15298":
                        # the reviewers' decision D3a: the keeper is excluded by Sumegha, so its 15298 twin is not
                        # its duplicate; it enters at A2 only with a person's keep row
                        self.m[n]["sumegha_15298"] = (f"the 15298 twin of {keeper}, which Sumegha excluded; it "
                                                      "enters at A2 only with a person's keep row recording "
                                                      "Sumegha's or the owner's confirmation")
                        continue
                    kind = "identical" if fps[n]["text"] == fps[keeper]["text"] else "one-to-one recode"
                    self.m[n]["duplicate_of"] = keeper
                    self.m[n]["duplicate_kind"] = kind
                    self.m[n]["kept_once_as"] = keeper
                    self.dup_list.append((n, keeper, kind))
        # duplicate numbers first, then near duplicates (so a kept twin is not flagged by its own copy)
        lim = self.th.num("duplicate_number_r")

        def _v(x):
            return x is not None and not math.isnan(x)

        for p in sorted(self.pairs, key=lambda p: (prec(p["a"]), prec(p["b"]))):
            for x, y in ((p["a"], p["b"]), (p["b"], p["a"])):
                if x not in spec_by or not prec(y) < prec(x):
                    continue
                mx = self.m[x]
                if mx.get("duplicate_of") or mx.get("label_copy") or mx.get("duplicate_number_of"):
                    continue
                if self.m.get(y, {}).get("duplicate_number_of", "").split(" ")[0] == x:
                    continue
                r, rho_ = p.get("r"), p.get("rho")
                hit = ([f"r {r:.5f}"] if _v(r) and abs(r) >= lim else []) + \
                      ([f"rho {rho_:.5f}"] if _v(rho_) and abs(rho_) >= lim else [])
                if hit:
                    mx["duplicate_number_of"] = f"{y} ({', '.join(hit)})"
                    mx.setdefault("kept_once_as", y)
                    self.dup_list.append((x, y, "duplicate number " + ", ".join(hit)))

        def twin(x, y):
            mx, my = self.m.get(x, {}), self.m.get(y, {})
            for a_, b_ in ((mx, y), (my, x)):
                if a_.get("duplicate_of") == b_ or a_.get("duplicate_number_of", "").split(" ")[0] == b_:
                    return True
            return False

        for p in self.pairs:
            for x, y in ((p["a"], p["b"]), (p["b"], p["a"])):
                if x not in spec_by or twin(x, y):
                    continue
                mx = self.m[x]
                if mx.get("duplicate_of") or mx.get("label_copy") or mx.get("duplicate_number_of"):
                    continue
                near = []
                r, rho_, v = p.get("r"), p.get("rho"), p.get("v")
                if _v(r) and abs(r) >= self.th.num("near_duplicate_r"):
                    near.append(f"r {r:.3f}")
                if _v(rho_) and abs(rho_) >= self.th.num("near_duplicate_rho"):
                    near.append(f"rho {rho_:.4f}")
                if _v(v) and v >= self.th.num("near_duplicate_v"):
                    near.append(f"V {v:.3f}")
                if p.get("pairs_ratio") is not None and p["pairs_ratio"] <= self.th.num("near_duplicate_pairs"):
                    near.append(f"pairs {p['pairs_ratio']:.3f}x")
                if near and not mx.get("near_duplicate_of"):
                    mx["near_duplicate_of"] = f"{y} ({', '.join(near)})"
                    self.dup_list.append((x, y, "near duplicate: " + ", ".join(near)))
        # VAA against the current external score
        base_ext = [n for n in base_order if R.matches(n, self.th("external_score_patterns"))]
        for s in self.specs:
            if not s.get("is_external"):
                continue
            notes = []
            for p in self.pairs:
                if {p["a"], p["b"]} & {s["name"]} and ({p["a"], p["b"]} & set(base_ext)):
                    other = p["b"] if p["a"] == s["name"] else p["a"]
                    notes.append(f"vs {other}: r {fmt(p.get('r'))} rho {fmt(p.get('rho'))} assoc {fmt(p.get('assoc'))}")
            d = self.m[s["name"]].get("duplicate_of")
            if d in base_ext:
                notes.insert(0, f"{self.m[s['name']].get('duplicate_kind')} of {d}")
            self.m[s["name"]]["external_vs_current"] = "; ".join(notes) or "no current external score to compare"

    def clusters(self):
        """Single-linkage clusters over base inputs and fields that do not stop."""
        thr = self.th.num("cluster_threshold")
        spec_by = {s["name"]: s for s in self.specs}
        keep_fields = [s["name"] for s in self.specs if self.m[s["name"]].get("result") != "STOP"]
        base_names = list(self.base["table"]["feature"])
        names = base_names + keep_fields
        allowed = set(names)
        edges, link = [], {}
        for p in getattr(self, "pairs", []):
            a, b = p["a"], p["b"]
            if a in allowed and b in allowed and p.get("assoc") is not None and not math.isnan(p["assoc"]) \
                    and p["assoc"] >= thr:
                edges.append((a, b))
                link[(a, b)] = p["assoc"]
        groups = M.single_linkage(names, edges)
        self.cluster_rows = []
        for i, g in enumerate(groups, start=1):
            if not any(n in spec_by for n in g):
                cid = f"B{i:03d}"
            else:
                cid = f"C{i:03d}"
            for n in g:
                lk = max([v for (a, b), v in link.items() if n in (a, b) and a in g and b in g] or [float("nan")])
                self.cluster_rows.append({"cluster_id": cid, "member": n,
                                          "member_kind": "new" if n in spec_by else "base",
                                          "size": len(g), "max_link": lk,
                                          "result": self.m[n].get("result", "base input") if n in spec_by else "base input"})
                if n in spec_by:
                    self.m[n]["cluster_id"] = cid

    # ---- stage: strictly-earlier probes on engineered fields
    def history_key(self, s: Dict) -> str:
        """The column a field's history is grouped by, as the recipe engine groups it: the recipe's own key
        (nf_recipes.parse(recipe).key, a customer or card column written key=...), else the account. A recipe the
        engine does not build (a test or dry-run builder) takes the key its text names, else the account."""
        r = self.builder.recipes
        if s["fn"] not in self.builder.extra and r is not None and hasattr(r, "parse"):
            try:
                return getattr(r.parse(s["recipe"]), "key", None) or self.acc
            except ValueError:   # nf_recipes.RecipeError: not this grammar
                pass
        return s.get("group_key") or self.acc

    def _probe_rows(self, df: pd.DataFrame, key: str) -> pd.DataFrame:
        """Up to --probe-accounts values of the history key (accounts, or the recipe's customer or card key), each
        with every row it has in the file, so every history the probes read is whole. For the account key these
        are the same rows as before keys were read from the recipe."""
        units = df[key].astype(str)
        u = np.array(sorted(units.unique()))
        rng = np.random.default_rng(self.a.seed)
        pick = set(rng.choice(u, size=min(self.a.probe_accounts, len(u)), replace=False)) if len(u) else set()
        fr = df[units.isin(pick).to_numpy()].copy()
        fr.index = pd.RangeIndex(len(fr))
        return fr

    def probes(self, base: str, n: int):
        self.stage = "probes"
        specs = [s for s in self.buildable() if s["fn"] != "raw"]
        if not specs:
            return
        part = self._pget("probes")
        if part is None:
            part = {}
            # every probe groups by the recipe's own history key, as the recipe engine does: a customer- or
            # card-keyed field reads earlier rows of other accounts of that customer or card, so cutoffs, deleted
            # rows, same-second siblings and single rows are per key, and the key is never perturbed (the probes'
            # account argument is that key)
            keys = {s["name"]: self.history_key(s) for s in specs}
            other = sorted(set(keys.values()) - {self.acc})
            self.log(f"probes: {len(specs)} engineered fields on train file {n}"
                     + (f"; history keys besides the account: {', '.join(other)}" if other else ""))
            df_all = self.frame(file_path(base, n), specs, extra=other)
            frames: Dict[str, pd.DataFrame] = {}
            labels = [c for c in self.th("label_columns")]
            for s in specs:
                key = keys[s["name"]]
                if key not in frames:
                    frames[key] = self._probe_rows(df_all, key)
                fr = frames[key]
                try:
                    part[s["name"]] = self._probe_field(s, fr, key, labels)
                except self.refusal_errors() as e:
                    self.refuse(s, e, where=f"probes on train file {Path(file_path(base, n)).name}")
            self._pput("probes", part)
        for name, res in self._keep(part).items():
            self.m[name]["probes"] = res

    def _probe_field(self, s: Dict, fr: pd.DataFrame, key: str, labels: List[str]) -> Dict:
        """Every strictly-earlier probe of one field on its probe rows."""
        def build(frame, s=s):
            v, _ = self.builder.build(s, frame, self.a.train_extract_start)
            return v
        res = {}
        res["future_invariance"] = M.probe_future_invariance(fr, build, s["sources"], key, self.tcol,
                                                             seed=self.a.seed)["ok"]
        res["future_deletion"] = M.probe_future_deletion(fr, build, key, self.tcol,
                                                         seed=self.a.seed + 1)["ok"]

        def build_at(frame, start, s=s):
            v, _ = self.builder.build(s, frame, start or self.a.train_extract_start)
            return v
        res["history_deletion"] = M.probe_history_deletion(
            fr, build_at, self.tcol, seed=self.a.seed + 4,
            reach_seconds=M.recipe_reach_seconds(s["recipe"]) if s["fn"] not in NO_WINDOW else None)["ok"]
        # the 26 October builders read the stored precision and refuse sub-second parts (design review
        # item 31): an a3 field's sibling sits at the row's own whole second
        res["same_second"] = M.probe_same_second(fr, build, s["sources"], key, self.tcol, self.idc,
                                                 seed=self.a.seed + 2, whole_seconds=s["fn"] == "a3")["ok"]
        res["label_permutation"] = M.probe_label_permutation(fr, build, labels, seed=self.a.seed + 3)["ok"]
        if s["fn"] in ONE_ROW_MISSING:
            res["one_row_account"] = M.probe_one_row(fr, build, key, seed=self.a.seed + 5)["ok"]
        res["history_key"] = key    # the unit the probes used (not a probe: only False values stop)
        return res

    # ---- the joint time fit (the reviewers' decision D3d)
    def joint_time(self, base: str, nums: List[int]):
        """Ordinary least squares of transaction time on the PASS or FLAG new numeric fields together, base inputs
        and calendar fields left out, on a fixed-seed sample of training rows (--joint-rows), two folds by account;
        for the A1 set and for the A1 and A2 set. Writes joint_time_fit.json; FLAG joint_clock on every listed
        field when the out-of-fold rho reaches joint_clock_rho. A set's fit leaves out the rows the extract start
        censors for any of its fields: a censored value is unknown, not missing, and its missing flag would only
        say how close the row is to the extract start (integration item j). The fit measures joint time
        predictability on that uncensored subset only; it does not establish that the model inputs, including
        censored-row missingness, carry no time information (the reviewers' item Q2)."""
        sets = {"A1": ("v22b", "both"), "A1 and A2": ("v22b", "both", "f15298")}
        ok = [s for s in self.buildable() if s["model_type"] == "continuous"
              and self.m[s["name"]].get("result") in ("PASS", "FLAG")
              and not s["flags"].get("calendar_name") and not self.m[s["name"]].get("calendar_shape")]
        rows = int(getattr(self.a, "joint_rows", 500_000) or 0)
        record: Dict = {"rows_asked": rows, "scope": JOINT_TIME_SCOPE, "sets": {}}
        if ok and rows > 0 and nums:
            per_file = max(1, rows // len(nums))
            cols: Dict[str, List[np.ndarray]] = {s["name"]: [] for s in ok}
            cens_cols: Dict[str, List[np.ndarray]] = {s["name"]: [] for s in ok}
            tt, folds = [], []
            for n in nums:
                path = file_path(base, n)
                idx = None
                self.log(f"joint time fit: training file {n}")
                for batch in self.batches(ok):
                    df = self.frame(path, batch)
                    if idx is None:
                        rng = np.random.default_rng(self.a.seed + 7_000 + n)
                        idx = np.sort(rng.choice(len(df), size=min(per_file, len(df)), replace=False))
                        meta = self.meta(df, with_label=False)
                        tt.append(meta["t"].to_numpy(dtype="datetime64[ns]").astype(np.int64)[idx] / 86_400e9)
                        folds.append(M.account_folds(meta["acct"].to_numpy()[idx]))
                    for s in batch:
                        vals, cens = self.values(s, df, self.a.train_extract_start)
                        num, _ = M.as_number(vals)
                        cols[s["name"]].append(num.to_numpy(dtype=float)[idx])
                        cens_cols[s["name"]].append(np.zeros(len(idx), dtype=bool) if cens is None
                                                    else np.asarray(cens, dtype=bool)[idx])
            t = np.concatenate(tt)
            fold = np.concatenate(folds)
            for label, groups in sets.items():
                names = [s["name"] for s in ok if s["group"] in groups]
                if not names:
                    record["sets"][label] = {"fields": [], "note": "no PASS or FLAG numeric field"}
                    continue
                X = np.column_stack([np.concatenate(cols[nm]) for nm in names])
                known = ~np.column_stack([np.concatenate(cens_cols[nm]) for nm in names]).any(axis=1)
                res = M.joint_time_fit(X[known], t[known], fold[known], names)
                res["rows_censored_left_out"] = int((~known).sum())
                res["scope"] = JOINT_TIME_SCOPE
                record["sets"][label] = res
                rho = res["rho"]
                flag = isinstance(rho, float) and not math.isnan(rho) and rho >= self.th.num("joint_clock_rho")
                for nm in names:
                    self.m[nm]["joint_time"] = (f"rho {rho:.2f} for the {label} set" + (" (FLAG joint_clock)"
                                                                                         if flag else "")
                                                + f", {JOINT_TIME_SHORT}")
                    if flag:
                        self.m[nm]["joint_clock"] = (f"{label} set: out-of-fold rho {rho:.3f}, R^2 {res['r2']:.3f} "
                                                     f"over {len(names)} fields (joint_time_fit.json)")
            for s in ok:     # the joint flag joins each field's rules
                m = self.m[s["name"]]
                if m.get("joint_clock"):
                    m["rules"] = R.evaluate(m, self.th)
                    m["result"] = R.worst(m["rules"])
                    m["reasons"] = R.reasons_text(m["rules"])
        else:
            record["note"] = "not run: no PASS or FLAG numeric field, or --joint-rows 0"
        self.out.mkdir(parents=True, exist_ok=True)
        (self.out / "joint_time_fit.json").write_text(json.dumps(record, indent=1, default=_json_default) + "\n")

    # ---- results
    def decide(self):
        spec_by = {s["name"]: s for s in self.specs}
        base_names = set(self.base["table"]["feature"])

        def evaluate():
            for s in self.specs:
                m = self.m[s["name"]]
                rules = R.evaluate(m, self.th)
                if s["name"] in self.refused_fields:   # the recipe engine refused it while building (item f)
                    m["build_refused"] = self.refused_fields[s["name"]]
                    rules = [("STOP", "build_refused", m["build_refused"][:300])] + rules
                m["rules"] = rules
                m["result"] = R.worst(rules)
                m["reasons"] = R.reasons_text(rules)

        for s in self.specs:
            self.m[s["name"]].update({k: v for k, v in s["flags"].items()})
        evaluate()
        # a coarser copy (many-to-one recode) is kept out when the finer field enters (review item 13)
        changed = False
        for a, b in getattr(self, "function_pairs", []):
            if a not in spec_by:
                if b in spec_by and a in base_names:   # a base input is a coarser copy of the field
                    old = self.m[b].get("refines", "")
                    self.m[b]["refines"] = (old + ", " if old else "") + f"finer than base input {a}"
                    self.dup_list.append((b, a, "refines (finer than the base input)"))
                    changed = True
                continue
            ma = self.m[a]
            if ma.get("duplicate_of") or ma.get("function_of") or ma.get("duplicate_number_of") or ma.get("label_copy"):
                continue
            if b in base_names or (b in spec_by and self.m[b]["result"] != "STOP"):
                self.m[a]["function_of"] = f"a many-to-one recode of {b}"
                self.m[a].setdefault("kept_once_as", b)
                self.dup_list.append((a, b, "function of (many-to-one)"))
                if b in spec_by:
                    old = self.m[b].get("refines", "")
                    self.m[b]["refines"] = (old + ", " if old else "") + f"finer than {a}"
                changed = True
        if changed:
            evaluate()
        # a recipe inherits availability and leakage results from its source fields (review item 28)
        changed = False
        for s in self.specs:
            if s["fn"] == "raw":
                continue
            inh = []
            for src in s["sources"]:
                if src == s["name"] or src not in spec_by:
                    continue
                for res, rule, _ in self.m[src].get("rules", []):
                    if res in ("STOP", "WAIT") and rule in R.INHERITED_RULES:
                        if rule == "same_txn_decision" and s["fn"] == "prev":
                            continue
                        inh.append((res, rule, src))
            if inh:
                self.m[s["name"]]["inherited"] = inh
                changed = True
        if changed:
            evaluate()


def _sha_or_none(p) -> Optional[str]:
    import hashlib
    p = Path(p)
    return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None


class Refused(Exception):
    pass


def _json_default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, set):
        return sorted(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    return str(o)


def unknown_count(values: pd.Series, vocab) -> int:
    keys = M.code_keys(values)
    known = keys.isin(vocab).to_numpy() | (keys == M.MISSING_KEY).to_numpy()
    return int((~known).sum())


def unknown_share(values: pd.Series, vocab) -> float:
    n = len(values)
    return unknown_count(values, vocab) / n if n else float("nan")


def _groups(fps: Dict[str, Dict], max_card: Optional[float] = None) -> List[List[str]]:
    """Columns with equal factorized codes (one-to-one recodes), leaving out constant columns and
    columns with more distinct values than max_card (those are matched by text or correlation)."""
    by: Dict[str, List[str]] = {}
    for n, d in fps.items():
        if d["card"] <= 1 or (max_card is not None and d["card"] > max_card):
            continue
        by.setdefault(d["recode"], []).append(n)
    return [g for g in by.values() if len(g) >= 2]


def _text_groups(fps: Dict[str, Dict]) -> List[List[str]]:
    """Columns with identical text (any number of distinct values)."""
    by: Dict[str, List[str]] = {}
    for n, d in fps.items():
        if d["card"] <= 1:
            continue
        by.setdefault(d["text"], []).append(n)
    return [g for g in by.values() if len(g) >= 2]


def _pair_measures(a, b, sa, sb, fps) -> Dict:
    ka, va = sa
    kb, vb = sb
    out = {"a": a, "b": b}
    if ka == "num" and kb == "num":
        out["r"] = M.pearson_pairwise(va, vb)
        ia, ib = M.impute_median(va), M.impute_median(vb)
        out["rho"] = M.spearman(ia, ib)
        out["assoc"] = abs(out["rho"]) if out["rho"] is not None and not math.isnan(out["rho"]) else float("nan")
    elif ka == "code" and kb == "code":
        v, npairs = M.cramers_v_codes(va, vb)
        out["v"] = v
        big = max(len(np.unique(va)), len(np.unique(vb)))
        out["pairs_ratio"] = npairs / big if big > 1 else None
        out["assoc"] = v
    else:
        codes, num = (va, vb) if ka == "code" else (vb, va)
        out["eta"] = M.correlation_ratio(codes, M.impute_median(num))
        out["assoc"] = out["eta"]
    return out


# ---------------------------------------------------------------------------
# Outputs
# ---------------------------------------------------------------------------
TRAIN_COLS = ["train_rows", "train_nonnull", "missing_train", "train_censored_n", "missing_fraud", "missing_nonfraud",
              "fill_fraud", "fill_nonfraud", "fill_jump_fraud", "fill_jump_pseudo", "fill_jump_excess",
              "change_at_event", "change_at_pseudo", "change_after_event", "change_after_pseudo",
              "constant_in_account", "fraud_accounts_with_history", "num_fail", "mean", "sd",
              "date_nonnull", "date_after", "date_nonnull_fraud", "date_after_fraud", "date_parse_share",
              "calendar_shape", "time_rho", "month_v", "month_nmi", "missing_drift_points", "missing_drift_month",
              "probes", "tfm_geohash_match",
              # the reviewers' decisions D3b and D3d of 2 November
              "date_nonnull_nonfraud", "date_after_nonfraud", "date_reasons", "missing_lift", "date_top",
              "date_default", "same_second_share", "prev_rows", "pair_both_present", "prev_not_earlier_share",
              "date_like_share", "date_like_rule", "month_v_uncensored", "month_nmi_uncensored",
              "month_v_present_adj", "month_nmi_present_adj", "event_spread_days", "joint_clock",
              "train_frauds", "train_missing_rows", "train_missing_frauds"]
FIT_COLS = ["vocab_size", "unk_fit_max", "unk_fit_file", "unk_fit", "capped_kept", "capped_rare_row_share",
            "unk_capped_files_1_5", "unk_capped_files_6_10"]
VAL_COLS = ["val_rows", "val_frauds", "single_ap", "unk_val", "capped_unknown_fraud_rate", "capped_other_fraud_rate"]
JUNE_COLS = ["june_rows", "missing_june", "censored_june", "unk_june", "psi_june", "june_outside_train_range",
             "unk_june_capped"]
DUP_COLS = ["duplicate_of", "duplicate_kind", "duplicate_number_of", "near_duplicate_of", "label_copy",
            "kept_once_as", "cluster_id", "distinct_train", "function_of", "refines", "external_vs_current"]
ALL_COLS = TRAIN_COLS + FIT_COLS + VAL_COLS + JUNE_COLS + DUP_COLS


def _cell(v):
    if isinstance(v, dict):
        return json.dumps(v, sort_keys=True, default=_json_default)
    if isinstance(v, (list, tuple)):
        return ";".join(str(x) for x in v)
    if isinstance(v, float) and math.isnan(v):
        return ""
    return v


def write_outputs(ck: Checks, out: Path, a, fmap: pd.DataFrame, th_sha: str, list_label: str, layout_line: str,
                  month_adds_nothing: Optional[bool]) -> str:
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    for s in ck.specs:
        m = ck.m[s["name"]]
        common = {"field": s["name"], "group": s["group"], "kind": s["kind"], "recipe": s["recipe"],
                  "model_type": s["model_type"], "result": m["result"], "reasons": m["reasons"]}
        for rng, cols in (("train", TRAIN_COLS), ("fit", FIT_COLS), ("val", VAL_COLS), ("june", JUNE_COLS),
                          ("duplicates", DUP_COLS)):
            r = dict(common, range=rng)
            for c in ALL_COLS:
                r[c] = _cell(m.get(c)) if c in cols else ""
            if rng == "train":
                r["missing_from_files"] = _cell(m.get("missing_from_files", []))
            rows.append(r)
    fc = pd.DataFrame(rows, columns=["field", "range", "group", "kind", "recipe", "model_type", "result", "reasons",
                                     "missing_from_files"] + ALL_COLS)
    fc.to_csv(out / "field_checks.csv", index=False)

    st = pd.DataFrame([{"field": s["name"], "group": s["group"], "kind": s["kind"], "result": ck.m[s["name"]]["result"],
                        "reasons": ck.m[s["name"]]["reasons"], "cluster_id": ck.m[s["name"]].get("cluster_id", ""),
                        "kept_once_as": ck.m[s["name"]].get("kept_once_as", "")} for s in ck.specs],
                      columns=["field", "group", "kind", "result", "reasons", "cluster_id", "kept_once_as"])
    st.to_csv(out / "field_status.csv", index=False)

    pd.DataFrame(getattr(ck, "cluster_rows", []),
                 columns=["cluster_id", "member", "member_kind", "size", "max_link", "result"]).to_csv(
        out / "clusters.csv", index=False)

    mb = []
    for s in ck.specs:
        for mon, (r, mi, ce) in sorted((ck.m[s["name"]].get("by_month") or {}).items()):
            mb.append({"field": s["name"], "month": mon, "rows": r, "missing": mi, "censored": ce,
                       "missing_share": (mi + ce) / r if r else "",
                       # the drift rule's share: missing among the rows that are not censored
                       "missing_share_not_censored": mi / (r - ce) if r - ce > 0 else ""})
    pd.DataFrame(mb, columns=["field", "month", "rows", "missing", "censored", "missing_share",
                              "missing_share_not_censored"]).to_csv(out / "missing_by_month.csv", index=False)

    pd.DataFrame(getattr(ck, "dup_list", []), columns=["field", "other", "relation"]).to_csv(
        out / "duplicates.csv", index=False)

    mo = []
    for s in ck.specs:
        m = ck.m[s["name"]]
        carries = bool(s["is_date"] or m.get("calendar_shape") or s["flags"].get("calendar_name")
                       or (m.get("time_rho") is not None and not _nan(m.get("time_rho"))
                           and abs(m["time_rho"]) >= ck.th.num("absolute_time_rho")))
        fired = any(rule in ("overlaps_month", "calendar_code", "tracks_time", "repeats_month", "joint_clock",
                             "drift_june") for _, rule, _ in m["rules"])
        clock = getattr(ck, "clock", None)
        st_text = R.month_statement(s["name"], m, ck.th, month_adds_nothing, clock, m.get("joint_time"))
        m["month_statement"] = st_text
        mo.append({"field": s["name"], "carries_date": "yes" if carries else "no",
                   "flagged": "yes" if fired else "no", "month_v": _cell(m.get("month_v")),
                   "month_nmi": _cell(m.get("month_nmi")), "psi_june": _cell(m.get("psi_june")),
                   "calendar_shape": m.get("calendar_shape") or "", "time_rho": _cell(m.get("time_rho")),
                   "month_v_uncensored": _cell(m.get("month_v_uncensored")),
                   "month_nmi_uncensored": _cell(m.get("month_nmi_uncensored")),
                   "month_v_present_adj": _cell(m.get("month_v_present_adj")),
                   "month_nmi_present_adj": _cell(m.get("month_nmi_present_adj")),
                   "clock_ceiling_v": _cell((clock or {}).get("v")), "clock_ceiling_nmi": _cell((clock or {}).get("nmi")),
                   "event_spread_days": _cell(m.get("event_spread_days")),
                   "train_window_days": getattr(ck, "train_window_days", ""),
                   "june_outside_train_range": _cell(m.get("june_outside_train_range")),
                   "statement": st_text})
    pd.DataFrame(mo, columns=["field", "carries_date", "flagged", "month_v", "month_nmi", "psi_june",
                              "calendar_shape", "time_rho", "month_v_uncensored", "month_nmi_uncensored",
                              "month_v_present_adj", "month_nmi_present_adj", "clock_ceiling_v", "clock_ceiling_nmi",
                              "event_spread_days", "train_window_days", "june_outside_train_range",
                              "statement"]).to_csv(out / "month_overlap.csv", index=False)
    (out / "date_fields.txt").write_text("\n".join(date_report(ck)) + "\n")
    (out / "capped_fields.txt").write_text("\n".join(capped_report(ck)) + "\n")

    checked = fmap.copy()
    res = {s["name"]: ck.m[s["name"]] for s in ck.specs}
    checked["check_result"] = [res[n]["result"] for n in checked["name"].str.strip()]
    checked["check_reasons"] = [res[n]["reasons"] for n in checked["name"].str.strip()]
    checked["cluster_id"] = [res[n].get("cluster_id", "") for n in checked["name"].str.strip()]
    checked["kept_once_as"] = [res[n].get("kept_once_as", "") for n in checked["name"].str.strip()]
    checked.to_csv(out / "FIELD_MAP_checked.csv", index=False)

    used = {k: ck.th(k) for k in sorted(R.DEFAULTS)}
    (out / "thresholds_used.json").write_text(json.dumps(
        {"thresholds_sha256": th_sha, "defaulted": sorted(ck.th.defaulted), "values": used}, indent=1,
        default=_json_default) + "\n")
    text = summary_screen(ck, a, th_sha, list_label, layout_line, out)
    (out / "summary.txt").write_text(text + "\n")
    return text


def capped_report(ck: Checks) -> List[str]:
    """Per new code field, capped in the extended artifact at CAP_MIN_ACCOUNTS accounts (the reviewers' decision
    D9-Y20): the unknown share under the cap in files 1-5, files 6-10 and June, the kept count, the rare-row share
    and the fraud rate among the rows the cap sends to unknown against the other rows (EPOCH_VAL). Ten accounts is
    an engineering default, not a discovered optimum."""
    out = [f"New code fields capped at {CAP_MIN_ACCOUNTS} accounts (the reviewers' decision D9-Y20): unknown "
           "shares are reported, not stops.",
           f"{CAP_MIN_ACCOUNTS} accounts is an engineering default, not a discovered optimum.", ""]
    for s in ck.specs:
        m = ck.m[s["name"]]
        if not m.get("capped"):
            continue

        def pct(k):
            v = m.get(k)
            return f"{100 * v:.2f}%" if _num_ok(v) else "na"
        out.append(f"{s['name']}: kept {m.get('capped_kept')} of {m.get('vocab_size')} values; rare rows "
                   f"{pct('capped_rare_row_share')}; unknown files 1-5 {pct('unk_capped_files_1_5')}, files 6-10 "
                   f"{pct('unk_capped_files_6_10')}, June {pct('unk_june_capped')}; fraud rate unknown "
                   f"{pct('capped_unknown_fraud_rate')} vs other {pct('capped_other_fraud_rate')}")
    return out


# What the joint time fit measures and what it does not (the reviewers' item Q2), for joint_time_fit.json and the
# printed per-field line.
JOINT_TIME_SCOPE = ("This measures joint time predictability on the uncensored subset (rows the extract start "
                    "censors for any field of the set are left out). It does not establish that the model inputs, "
                    "including censored-row missingness, carry no time information.")
JOINT_TIME_SHORT = ("uncensored subset only, not proof that the model inputs, censored-row missingness included, "
                    "carry no time information")


# The date screen's limit (the reviewers' decision D3b): a source-definition condition, not a request for more runs.
DATE_SCREEN_LIMIT = ("Missingness can itself carry information from a post-transaction update, and passing a rarity "
                     "threshold does not establish point-in-time availability: that is a source-definition condition.")


def date_report(ck: Checks) -> List[str]:
    """Per date field (the reviewers' decision D3b): each reason's share among frauds and non-frauds, the missing
    shares and their ratio (the flag's lift), the five most frequent dates (1% or more: a probable default), the
    hours of (t - d) within a day either side when a date falls after the transaction, the PREV counts, and the
    event-date spread (D3d). Missingness can itself carry information from a post-transaction update, and passing
    a rarity threshold does not establish point-in-time availability: that is a source-definition condition."""
    out = ["Date fields (the reviewers' decisions D3b and D3d). Shares among frauds / non-frauds.",
           DATE_SCREEN_LIMIT, ""]
    for s in ck.specs:
        m = ck.m[s["name"]]
        if not s["is_date"] and s["fn"] not in ("since_last", "since_first"):
            continue
        out.append(f"{s['name']}  ({s['recipe']})")
        dr = m.get("date_reasons") or {}
        if dr:
            out.append("  reasons: " + ", ".join(f"{k} {100 * v['fraud']:.3f}% / {100 * v['nonfraud']:.3f}%"
                                                 for k, v in sorted(dr.items())))
        if _num_ok(m.get("missing_fraud")):
            lift = m.get("missing_lift")
            out.append(f"  missing: frauds {m['missing_fraud']:.4f}, non-frauds {m.get('missing_nonfraud', 0):.4f}"
                       + (f", ratio {lift:.3f} (the flag's lift)" if _num_ok(lift) else ""))
        if m.get("date_top"):
            out.append("  top dates: " + ", ".join(
                f"{d} {100 * sh:.2f}%" + (" (probable default)" if sh >= 0.01 else "")
                for d, sh in m["date_top"].items()))
        if m.get("date_after") and m.get("date_hours"):
            out.append("  (t - d) in hours within a day either side: " + ", ".join(
                f"{h}:{n}" for h, n in m["date_hours"].items()))
        if m.get("pair_both_present") is not None:
            out.append(f"  PREV read on {m.get('prev_rows', 0)} rows; PREV not earlier than CURR on "
                       f"{100 * (m.get('prev_not_earlier_share') or 0):.3f}% of the {m['pair_both_present']} rows "
                       "with both")
        if _num_ok(m.get("same_second_share")):
            out.append(f"  in the transaction's own second: {100 * m['same_second_share']:.2f}% of rows")
        if _num_ok(m.get("event_spread_days")):
            out.append(f"  event dates: 10th to 90th percentile spread {m['event_spread_days']:.0f} days (training "
                       f"window {getattr(ck, 'train_window_days', 0)} days)"
                       + (f"; June values outside the training range {100 * m['june_outside_train_range']:.2f}%"
                          if _num_ok(m.get("june_outside_train_range")) else ""))
    return out


def _nan(x) -> bool:
    return isinstance(x, float) and math.isnan(x)


def summary_screen(ck: Checks, a, th_sha: str, list_label: str, layout_line: str, out: Path) -> str:
    nc = _load("nf_common")
    specs, m = ck.specs, ck.m
    res = {s["name"]: m[s["name"]]["result"] for s in specs}
    counts = {k: sum(1 for v in res.values() if v == k) for k in ("PASS", "FLAG", "WAIT", "STOP")}
    groups = {}
    for s in specs:
        groups[s["group"] or "none"] = groups.get(s["group"] or "none", 0) + 1
    by_rule: Dict[Tuple[str, str], int] = {}
    for s in specs:
        for r, rule, _ in m[s["name"]]["rules"]:
            by_rule[(r, rule)] = by_rule.get((r, rule), 0) + 1
    lines = []
    lines.append(f"pod raw columns {getattr(ck, 'pod_columns', 'na')} | read: train {a.train_files}, "
                 f"val {a.val_files}, Test1 {a.june_files} June rows, no labels")
    lines.append("fields {} ({}) | PASS {} FLAG {} WAIT {} STOP {}".format(
        len(specs), ", ".join(f"{k} {v}" for k, v in sorted(groups.items())), counts["PASS"], counts["FLAG"],
        counts["WAIT"], counts["STOP"]))
    lines.append("June: Test 1 June rows only; the label column is never read (a label-free use, not a read)")
    lines.extend(geohash_lines(ck))
    wait_rules = sorted(((n, rule) for (r, rule), n in by_rule.items() if r == "WAIT"), key=lambda x: (-x[0], x[1]))
    lines.extend(_wrap("WAIT: " + (", ".join(f"{rule} {n}" for n, rule in wait_rules) or "none"), 90))
    dups = [s["name"] for s in specs if m[s["name"]].get("kept_once_as")]
    over = [s["name"] for s in specs if s["group"] in ("f15298", "a3") and m[s["name"]].get("kept_once_as")]
    lines.append(f"overlap kept once: {len(dups)} fields ({len(over)} from f15298 or a3); list in duplicates.csv")
    rep = [s["name"] for s in specs if any(rule in ("repeats_month", "tracks_time")
                                            for _, rule, _ in m[s["name"]]["rules"])]
    ov = sorted([(m[s["name"]].get("month_v_uncensored") or m[s["name"]].get("month_v") or 0, s["name"])
                 for s in specs if any(rule == "overlaps_month" for _, rule, _ in m[s["name"]]["rules"])],
                reverse=True)
    held = [n for n in rep if any(r == "WAIT" and rule in ("repeats_month", "tracks_time")
                                  for r, rule, _ in m[n]["rules"])]
    mtxt = (f"month: repeated or time tracked by {len(rep)} field(s), {len(held)} held for the reviewers' "
            "decision" + (f" ({', '.join(rep[:2])})" if rep else ""))
    if ov:
        mtxt += "; overlaps month: " + ", ".join(f"{n} V {v:.2f}" for v, n in ov[:2])
        if len(ov) > 2:
            mtxt += f" (+{len(ov) - 2})"
    if a.month_adds_nothing is None:
        mtxt += "; screen month result not given"
    lines.extend(_wrap(mtxt, 90))
    clock = getattr(ck, "clock", None) or {}
    n_dates = sum(1 for s in specs if s["is_date"])
    lines.append(f"dates: {n_dates} field(s), reasons and top dates in date_fields.txt; a pure clock reaches V "
                 f"{R._fmt(clock.get('v'), 2)} NMI {R._fmt(clock.get('nmi'), 2)} (month_overlap.csv)")
    ext = [s["name"] for s in specs if s.get("is_external")]
    for n in ext[:2]:
        lines.append(f"external score {n}: {m[n].get('external_vs_current', '')}")
    leaky = [s["name"] for s in specs if any(rule == "not_strictly_earlier" for _, rule, _ in m[s["name"]]["rules"])]
    if leaky:
        lines.append("not strictly earlier: " + ", ".join(leaky))
    body = []
    for kind in ("STOP", "WAIT", "FLAG"):
        per: Dict[str, List[str]] = {}
        for sp in specs:
            for r, rule, _ in m[sp["name"]]["rules"]:
                if r == kind and sp["name"] not in per.setdefault(rule, []):
                    per[rule].append(sp["name"])
        for rule, names in sorted(per.items(), key=lambda kv: (-len(kv[1]), kv[0])):
            body.append(_names_line(f"{kind} {rule} {len(names)}: ", names))
    ncl = len({r['cluster_id'] for r in getattr(ck, 'cluster_rows', [])})
    big = max([r["size"] for r in getattr(ck, "cluster_rows", [])] or [0])
    tail = [f"clusters: {ncl} (largest {big} fields); threshold {ck.th.num('cluster_threshold')}"]
    add = sum(2 if s["model_type"] == "continuous" else 1 for s in specs if res[s["name"]] in ("PASS", "FLAG"))
    tail.append(f"width if PASS and FLAG enter: {ck.base_tokens} -> {ck.base_tokens + add} tokens per transaction "
                f"(month in)")
    if ck.th.defaulted:
        tail.append(f"{len(ck.th.defaulted)} threshold keys not in the file took defaults: thresholds_used.json")
    full = _rel(out / "field_checks.csv")
    tail.append("full table: " + (full if len(full) <= 78 else "..." + full[-75:]))
    room = 40 - 1 - len(lines) - len(tail)
    if len(body) > room:
        body = body[:room - 1] + [f"... {len(body) - room + 1} more rules: field_status.csv and field_checks.csv"]
    title = f"FIELD CHECKS  list={a.map_name} {list_label}  thresholds={th_sha[:12]}  layout={layout_line}"
    return nc.screen(title[:90], lines + body + tail)


def geohash_lines(ck: Checks) -> List[str]:
    """TFM's geohash table (file name, SHA-256, precision and cell size) and, per geohash field built, how TFM's
    precomputed column compares with the recipe. Nothing when no geohash field is built (a refused one shows as
    WAIT not_built)."""
    geo = [s for s in ck.specs if s.get("fn") == "geohash" and not s["flags"].get("not_built")]
    if not geo:
        return []
    out = []
    t = getattr(ck, "geohash_table", None)
    if t is not None:
        sm = t.summary()
        out += _wrap(f"geohash table {str(sm['source']).rsplit('/', 1)[-1]} sha256 {sm['sha256'][:12]}: "
                     f"{sm['keys']} keys, {sm['repeated_rows']} repeated rows ({sm['conflicting_keys']} with another "
                     "geohash)", 90)
        cells = ", ".join(f"p{p} cells about {w:g} x {h:g} km" for p, (w, h) in sm["cell_km"].items())
        out.append(f"  precision: {cells or 'no geohash values'} (a cell centre as a location is coarse)")
    parts = []
    for s in geo:
        tg = ck.m.get(s["name"], {}).get("tfm_geohash_match")
        col = s.get("tfm_geohash_column")
        if isinstance(tg, dict) and tg.get("rows"):
            parts.append(f"{s['name']} vs {col} {100 * tg['match'] / tg['rows']:.3f}% of {tg['rows']} rows")
        elif col:
            parts.append(f"{s['name']}: {col} is not in the training files")
        else:
            parts.append(f"{s['name']}: no TFM column to compare")
    return out + _wrap("TFM's precomputed geohash: " + "; ".join(parts), 90)


def _names_line(head: str, names: List[str], width: int = 90) -> str:
    """head plus as many names as fit, then "+n more"."""
    out = head
    for i, n in enumerate(names):
        rest = len(names) - i - 1
        tail = f" +{rest} more" if rest else ""
        piece = (", " if i else "") + n
        if len(out) + len(piece) + len(f" +{rest + 1} more") > width and i:
            return out + f" +{len(names) - i} more"
        out += piece
        if len(out) > width:
            return out[:width - 8] + f" +{rest + 1} more" if rest else out[:width]
    return out


def _wrap(text: str, width: int) -> List[str]:
    out, cur = [], ""
    for w in text.split(" "):
        if len(cur) + len(w) + 1 > width and cur:
            out.append(cur)
            cur = "  " + w
        else:
            cur = (cur + " " + w) if cur else w
    if cur:
        out.append(cur)
    return out


def _rel(p: Path) -> str:
    try:
        return str(Path(p).resolve().relative_to(ROOT))
    except ValueError:
        return str(p)


# ---------------------------------------------------------------------------
# Command line
# ---------------------------------------------------------------------------
def read_config(path: Optional[str]) -> Dict:
    import yaml
    cands = [Path(path)] if path else [ROOT / "fraud/configs/sequential_hier_allpos.yaml",
                                       ROOT / "waqas/phase4b/configs/sequential_hier_allposition.yaml"]
    for c in cands:
        if c.exists():
            with open(c) as f:
                d = yaml.safe_load(f) or {}
            d["_path"] = str(c)
            return d
    return {}


def base_table(cfg: Dict, root: Path, override: Optional[str]) -> pd.DataFrame:
    p = Path(override) if override else root / ((cfg.get("predictors") or {}).get("csv_path")
                                               or "fraud/configs/predictors.csv")
    df = pd.read_csv(p, dtype=str, keep_default_na=False)
    return df


def build_args(argv=None):
    p = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    p.add_argument("--map", help="the field map (NF/FIELD_MAP.csv)")
    p.add_argument("--thresholds", help="CHECK_THRESHOLDS.yaml (default: the one next to this script)")
    p.add_argument("--status-rules", help="STATUS_RULES.csv (default: next to this script)")
    p.add_argument("--config", help="the chosen model's config, for data bases and columns")
    p.add_argument("--decisions", help="KEEP_DECISIONS.csv, for written clearances of a status name match "
                                       "(default: next to this script)")
    p.add_argument("--predictors", help="the base predictors.csv (default: the config's predictors.csv_path)")
    p.add_argument("--recipes", help="the recipes module (default: nf_recipes.py next to this script)")
    p.add_argument("--train-base")
    p.add_argument("--train-files", default=None, help="for example 1-10")
    p.add_argument("--val-base")
    p.add_argument("--val-files", default=None, help="for example 4950-4954")
    p.add_argument("--june-base")
    p.add_argument("--june-files", default=None, help="Test 1 files, for example 8000-8010")
    p.add_argument("--june-month", default="2025-06")
    p.add_argument("--fit-files", default=None, help="vocabulary fit files (default: version 1's manifest)")
    p.add_argument("--artifact-manifest", help="version 1's manifest.json (default: the config's artifact)")
    p.add_argument("--presence", action="append", default=[],
                   help="extra range for the presence check, NAME=BASE:START-END (repeatable)")
    p.add_argument("--no-settings-ranges", action="store_true",
                   help="do not add SETTINGS.yaml populations to the presence check")
    p.add_argument("--dup-files", default="1,2")
    p.add_argument("--confirm-file", default=None, help="default: the thresholds file's cluster_confirm_file, else 3")
    p.add_argument("--cred-path")
    p.add_argument("--out", help="output folder (default: checkpoints/new_fields/checks)")
    p.add_argument("--train-extract-start", default=None)
    p.add_argument("--eval-extract-start", default=None)
    p.add_argument("--account-col", default=None)
    p.add_argument("--time-col", default=None)
    p.add_argument("--id-col", default=None)
    p.add_argument("--label-col", default=None)
    p.add_argument("--batch-fields", type=int, default=40)
    p.add_argument("--sample-rows", type=int, default=200_000)
    p.add_argument("--time-sample", type=int, default=20_000)
    p.add_argument("--joint-rows", type=int, default=500_000,
                   help="training rows sampled for the joint time fit (the reviewers' decision D3d); 0 skips it")
    p.add_argument("--probe-accounts", type=int, default=500)
    p.add_argument("--seed", type=int, default=20261102)
    p.add_argument("--month-screen", help="the CPU screen's screen.json, for the month statement")
    p.add_argument("--month-adds-nothing", choices=["yes", "no"], default=None,
                   help="the screen's time-split month result, if read by hand")
    p.add_argument("--min-free-gb", type=float, default=None)
    p.add_argument("--no-project-fit", action="store_true",
                   help="use the copy of the vocabulary rule, not the project's fit_categorical_stats")
    p.add_argument("--dry-run", action="store_true", help="build a small synthetic world and run every check on it")
    p.add_argument("--keep", action="store_true", help="dry run: keep the temporary folder and print its path")
    return p.parse_args(argv)


def month_result_from_screen(path: Optional[str]) -> Optional[bool]:
    """Reads the screen's month on-top result on the time split, if the file holds one.

    It looks for a block named like month_on_top (or month) with a time-split part that holds a
    difference with its interval. Month adds nothing when the interval's lower end is at or below zero.
    """
    if not path or not Path(path).exists():
        return None
    d = json.loads(Path(path).read_text())

    def find(obj, keys):
        if isinstance(obj, dict):
            for k, v in obj.items():
                if any(x in k.lower() for x in keys):
                    return v
            for v in obj.values():
                r = find(v, keys)
                if r is not None:
                    return r
        return None

    blk = find(d, ["month_on_top", "month_ontop", "month_top", "month_arms"])
    if blk is None:
        return None
    ts = find(blk, ["time_split", "temporal", "time"]) if isinstance(blk, dict) else None
    ts = ts if isinstance(ts, dict) else blk
    for k in ("month_adds_nothing", "adds_nothing"):
        if isinstance(ts, dict) and k in ts:
            return bool(ts[k])
    lo = None
    for k in ("ci_low", "lo", "lower", "delta_ci_low", "lb"):
        if isinstance(ts, dict) and k in ts:
            lo = ts[k]
            break
    if lo is None and isinstance(ts, dict):
        ci = find(ts, ["ci95", "ci"])
        if isinstance(ci, (list, tuple)) and ci:
            lo = ci[0]
    if lo is None:
        return None
    return float(lo) <= 0.0


def run(a, extra_builders: Optional[Dict[str, Callable]] = None, log=print, show=None) -> int:
    """Every check. Progress lines and refusals go to `log`; the one-screen summary goes to `show` (default
    `log`), last, so a photograph of the last 40 lines holds the whole screen with its title."""
    nc = _load("nf_common")
    if not a.map:
        log("give --map (or --dry-run)")
        return nc.ARGS
    if not Path(a.map).is_file():
        log(f"refused: no field map at {a.map}; give its path, for example $NF/FIELD_MAP.csv (exit 4)")
        return nc.REFUSED
    th_path = Path(a.thresholds) if a.thresholds else HERE / "CHECK_THRESHOLDS.yaml"
    if th_path.exists():
        th_data, th_sha = nc.load_yaml(th_path), nc.sha256_file(th_path)
    else:
        th_data, th_sha = {}, "no-thresholds-file"
    th = R.Thresholds(th_data)
    log(f"thresholds {_rel(th_path)} sha256 {th_sha[:12]}")   # the full SHA-256: thresholds_used.json
    min_gb = a.min_free_gb if a.min_free_gb is not None else th.num("min_free_gb")
    fg = free_gb()
    if fg is not None and fg < min_gb:
        log(f"refused: free host memory {fg:.1f} GiB (the host's or the container's, whichever is smaller) "
            f"is below {min_gb} GiB")
        return nc.REFUSED
    try:
        fmap = nc.read_field_map(a.map)
    except (SystemExit, OSError, ValueError) as e:   # a missing column, an unreadable or malformed file
        log(f"refused: the field map cannot be read ({type(e).__name__}: {e}) (exit 4)")
        return nc.REFUSED
    if fmap["name"].str.strip().duplicated().any():
        log("refused: two rows share one name: " + ", ".join(fmap["name"][fmap["name"].duplicated()].tolist()))
        return nc.REFUSED
    map_sha = nc.sha256_file(a.map)
    a.map_name = Path(a.map).name
    ls = set(fmap.get("list_status", pd.Series(dtype=str)).str.strip().str.upper())
    list_label = "CONFIRMED" if ls == {"CONFIRMED"} else "UNCONFIRMED"

    cfg = read_config(a.config)
    data = cfg.get("data") or {}
    ev = cfg.get("eval") or {}
    a.account_col = a.account_col or data.get("account_col", "Nmap_account_reference_xid")
    a.time_col = a.time_col or data.get("order_col", "transaction_dttm")
    a.id_col = a.id_col or data.get("tie_break_col", "fi_transaction_id")
    a.label_col = a.label_col or data.get("target_col", "frd_tag")
    a.train_base = a.train_base or data.get("train_base")
    a.val_base = a.val_base or data.get("val_base") or a.train_base
    a.june_base = a.june_base or ev.get("base")
    a.train_files = a.train_files or f"{data.get('train_start', 1)}-{data.get('train_end', 10)}"
    a.val_files = a.val_files or f"{data.get('val_start', 4950)}-{data.get('val_end', 4954)}"
    a.cred_path = a.cred_path or (cfg.get("s3") or {}).get("cred_path") if not a.dry_run else a.cred_path
    try:
        sw_start = _load("nf_layout").attr("strict_window", "EXTRACT_START")
    except (SystemExit, Exception):
        sw_start = {"train": "2024-10-01", "evaluation": "2025-05-01"}
    a.train_extract_start = a.train_extract_start or sw_start.get("train", "2024-10-01")
    a.eval_extract_start = a.eval_extract_start or sw_start.get("evaluation", "2025-05-01")
    try:
        sett = nc.settings() if not a.no_settings_ranges else {}
    except Exception:
        sett = {}
    pops = (sett or {}).get("populations") or {}
    t1 = (pops.get("test1") or {}).get("files")
    a.june_files = a.june_files or (f"{t1[0]}-{t1[1]}" if t1 else "8000-8010")
    if not a.train_base or not a.june_base:
        log("give --train-base and --june-base (or a config that holds data.train_base and eval.base)")
        return nc.ARGS
    a.use_project_fit = not a.no_project_fit
    if a.month_adds_nothing is not None:
        a.month_adds_nothing = a.month_adds_nothing == "yes"
    else:
        a.month_adds_nothing = month_result_from_screen(a.month_screen)

    files = Files(a.cred_path)
    # vocabulary fit files: version 1's manifest
    fit_nums = parse_range(a.fit_files) if a.fit_files else None
    if fit_nums is None:
        man = a.artifact_manifest
        if not man and cfg.get("artifacts"):
            man = f"{str(cfg['artifacts'].get('base', '')).rstrip('/')}/{cfg['artifacts'].get('version', 1)}/manifest.json"
        try:
            import fsspec  # noqa: F401
            if man and (files.fs is not None or os.path.exists(man)):
                opener = files.fs.open(files._p(man)) if files.fs is not None else open(man)
                with opener as f:
                    fit_names = json.load(f).get("fit_files", [])
                fit_nums = sorted(int(re.search(r"(\d+)", Path(x).stem).group(1)) for x in fit_names)
        except Exception as e:
            log(f"manifest not read ({type(e).__name__}); vocabulary fit on training files 1-5")
        if not fit_nums:
            fit_nums = list(range(1, 6))
    a.fit_files_used = ",".join(str(x) for x in fit_nums)
    ranges = {"train": (a.train_base, parse_range(a.train_files)), "val": (a.val_base, parse_range(a.val_files)),
              "test1": (a.june_base, parse_range(a.june_files))}
    for name, pr in pops.items():
        if name in ranges or not isinstance(pr, dict) or not pr.get("files"):
            continue
        lo, hi = pr["files"][0], pr["files"][1]
        ranges[name] = (a.june_base if int(lo) >= 8000 else a.train_base, list(range(int(lo), int(hi) + 1)))
    for spec in a.presence:
        name, _, rest = spec.partition("=")
        b, _, rr = rest.rpartition(":")
        ranges[name] = (b, parse_range(rr))
    # the other training files the stages read (the vocabulary fit files, the duplicate and confirm files) get the
    # same footer check, so no stage builds a field on a file that lacks one of its columns
    dup = [int(x) for x in str(a.dup_files).split(",") if x.strip()]
    cf = a.confirm_file if a.confirm_file is not None else th("cluster_confirm_file")
    conf = int(cf) if str(cf).strip() not in ("", "none", "None") else None
    covered = {n for b, nums in ranges.values() if b == a.train_base for n in nums}
    for name, nums in (("fit_files", fit_nums), ("dup_files", dup + ([conf] if conf is not None else []))):
        more = sorted(set(nums) - covered)
        if more and name not in ranges:
            ranges[name] = (a.train_base, more)
            covered |= set(more)

    bt = base_table(cfg, ROOT, a.predictors)
    base = {"table": bt, "raw": [r["feature"] for _, r in bt.iterrows() if str(r["source"]) == "raw"]}
    status_path = Path(a.status_rules) if a.status_rules else HERE / "STATUS_RULES.csv"
    rules = read_status_rules(status_path)
    a.status_path = status_path
    a.predictors_path = a.predictors or ROOT / ((cfg.get("predictors") or {}).get("csv_path")
                                                or "fraud/configs/predictors.csv")
    dec_path = Path(a.decisions) if a.decisions else HERE / "KEEP_DECISIONS.csv"
    a.decisions_path = dec_path
    recipes = load_recipes(a.recipes)
    specs = field_specs(fmap, list(bt["feature"]), th, rules, a.account_col, read_decisions(dec_path), recipes)
    builder = Builder(recipes, extra_builders, a.account_col, a.time_col)
    for s in specs:
        if not builder.can_build(s):
            s["flags"]["not_built"] = "recipes module not found, so the value cannot be built"
        elif refused := builder.refused(s):
            s["flags"]["not_built"] = f"the recipes module refuses this recipe: {refused}"
    # TFM's postal-code geohash: its table is read once, before any file (an unreadable table refuses, exit 4); its
    # SHA-256 joins the run identity, and each field's TFM precomputed column is named for the comparison
    geo = [s for s in specs if s["fn"] == "geohash" and not s["flags"].get("not_built") and "geohash" not in
           builder.extra]
    a.geohash_table_sha256, geo_table = None, None
    if geo:
        try:   # an S3 table is read with the data's credentials (--cred-path, else the config's)
            geo_table = recipes.load_geohash_table(cred_path=a.cred_path or None)
        except ValueError as e:   # nf_recipes.RecipeError
            log(f"refused: geohash field(s) {', '.join(s['name'] for s in geo)}: {e}")
            return nc.REFUSED
        a.geohash_table_sha256 = geo_table.sha256
        builder.geohash_table = geo_table
        for s in geo:
            s["tfm_geohash_column"] = recipes.tfm_geohash_column(recipes.parse(s["recipe"]))
    out = Path(a.out) if a.out else nc.out("checks", "summary.txt").parent
    try:
        layout_line = _load("nf_layout").resolve(["s3", "preprocessing", "strict_window"]).layout \
            if not a.dry_run else "dry run"
    except (SystemExit, Exception):
        layout_line = "not resolved"
    ck = Checks(a, th, th_sha, map_sha, specs, base, builder, files, out, log)
    ck.geohash_table = geo_table
    n_cont = sum(1 for _, r in bt.iterrows() if r["type"] == "continuous")
    n_cat = sum(1 for _, r in bt.iterrows() if r["type"] == "categorical")
    ck.base_tokens = 2 * n_cont + n_cat + 1   # value and missing flag per number, one per code, the time gap
    try:
        ck.presence(ranges)
        ck.load_refused()
        tn = parse_range(a.train_files)
        ck.train(a.train_base, tn)
        ck.fit(a.train_base, fit_nums)
        ck.val(a.val_base, parse_range(a.val_files))
        ck.june(a.june_base, parse_range(a.june_files))
        ck.probes(a.train_base, tn[0])
        ck.duplicates(a.train_base, dup, conf)
    except Refused as e:
        log(f"refused: {e}")
        return nc.REFUSED
    ck.decide()
    ck.joint_time(a.train_base, parse_range(a.train_files))
    ck.clusters()
    text = write_outputs(ck, out, a, fmap, th_sha, list_label, layout_line, a.month_adds_nothing)
    (show or log)(text)
    return nc.OK


def dry_run(a, folder: Optional[Path] = None, log=print, show=None) -> int:
    """The synthetic world in a temporary folder (or `folder`, kept), then every check on it."""
    synth = _load("nf_checks_synth")
    tmp = Path(folder) if folder else Path(tempfile.mkdtemp(prefix="nf_checks_dry_"))
    world = synth.make_world(tmp)
    a.map = str(world["map"])
    a.thresholds = a.thresholds or str(world["thresholds"])
    a.status_rules = a.status_rules or str(world["status_rules"])
    a.decisions = a.decisions or str(tmp / "KEEP_DECISIONS.csv")
    a.predictors = str(world["predictors"])
    a.train_base, a.val_base, a.june_base = world["train_base"], world["val_base"], world["june_base"]
    a.train_files, a.val_files, a.june_files = world["train_files"], world["val_files"], world["june_files"]
    a.fit_files = world["fit_files"]
    a.dup_files, a.confirm_file = world["dup_files"], world["confirm_file"]
    a.no_settings_ranges = True
    a.config = str(world["config"])
    a.out = a.out or str(tmp / "out")
    a.min_free_gb = 0.0
    a.cred_path = None
    a.sample_rows = min(a.sample_rows, 50_000)
    a.probe_accounts = min(a.probe_accounts, 80)
    held: List[str] = []
    rc = run(a, extra_builders=synth.dry_run_builders(world, load_recipes(a.recipes) is not None), log=log,
             show=held.append)
    if folder is None:
        log(f"dry run folder: {tmp}" if a.keep else "dry run done (temporary folder removed)")
        if not a.keep:
            import shutil
            shutil.rmtree(tmp, ignore_errors=True)
    for text in held:      # the screen comes last
        (show or log)(text)
    return rc


def _progress(*parts) -> None:
    """Progress lines and refusals go to the error stream; the summary screen alone goes to the output. A refusal
    is wrapped at 90 characters (a path stays whole)."""
    text = " ".join(str(x) for x in parts)
    if text.startswith("refused"):
        text = _load("nf_common").wrap(text)
    print(text, file=sys.stderr, flush=True)


def main(argv=None) -> int:
    a = build_args(argv)
    if a.dry_run:
        return dry_run(a, log=_progress, show=print)
    return run(a, log=_progress, show=print)


if __name__ == "__main__":
    sys.exit(main())
