"""Feature, cluster and source-family plans for transformer sensitivity scoring.

Profiles are declared in the field map or the caller's profile list. A name is
not evidence that a field is a static account profile. Source-family plans are
explicit, and include every declared descendant of their changed source fields.
"""
from __future__ import annotations

from dataclasses import asdict
import importlib
import json
from pathlib import Path
from typing import Callable

import pandas as pd

from nf_permutation import Unit


_CALENDAR = {"month", "day", "day_of_month", "day_of_week", "dayofweek", "weekday",
             "hour", "minute", "second", "hour_sin", "hour_cos", "dow_sin", "dow_cos",
             "month_sin", "month_cos", "day_sin", "day_cos"}
_FIXED = {"transaction_dttm", "Nmap_account_reference_xid", "fi_transaction_id", "frd_tag"}


def _table(value):
    if value is None:
        return pd.DataFrame()
    if isinstance(value, (str, Path)):
        return pd.read_csv(value, dtype=str, keep_default_na=False)
    return value.copy(deep=True) if isinstance(value, pd.DataFrame) else pd.DataFrame(value)


def _names(value):
    if isinstance(value, (list, tuple)):
        return [str(x).strip() for x in value if str(x).strip()]
    if value is None or (not isinstance(value, str) and pd.isna(value)):
        return []
    text = str(value).strip()
    if not text:
        return []
    if text.startswith("["):
        parsed = json.loads(text)
        if not isinstance(parsed, list):
            raise ValueError("Column-name JSON must be a list")
        return _names(parsed)
    return [x.strip() for x in text.split(";") if x.strip()]


def _map_rows(field_map):
    table = _table(field_map)
    if table.empty:
        return {}
    if "name" not in table:
        raise ValueError("Field map needs a name column")
    if table.name.isna().any() or (table.name.astype(str).str.strip() == "").any():
        raise ValueError("Field map has an empty feature name")
    if table.name.duplicated().any():
        raise ValueError("Field map repeats a feature name")
    return {str(row["name"]): row for row in table.fillna("").to_dict("records")}


def dependency_order(rows):
    """Return recipe outputs in dependency order; reject ambiguous cycles."""
    ordered, visiting, done = [], set(), set()

    def visit(name):
        if name in done:
            return
        if name in visiting:
            raise ValueError(f"Recipe dependency cycle at {name}")
        visiting.add(name)
        row = rows[name]
        raw = str(row.get("recipe", "raw")).strip() in {"", "raw"}
        for source in _names(row.get("source_columns")):
            if source == name and raw:
                continue
            if source in rows:
                visit(source)
        visiting.remove(name)
        done.add(name)
        ordered.append(name)

    for name in rows:
        visit(name)
    return ordered


def _descendants(sources, rows):
    affected, outputs = set(sources), []
    for name in dependency_order(rows):
        row = rows[name]
        recipe = str(row.get("recipe", "raw")).strip()
        if recipe in {"", "raw"} and name in sources:
            continue
        if affected.intersection(_names(row.get("source_columns"))):
            if not recipe or recipe == "raw":
                raise ValueError(f"Dependent output {name} needs a recipe")
            affected.add(name)
            outputs.append(name)
    return outputs


def _policy(members, rows, profiles):
    declared = set()
    for name in members:
        policy = str(rows.get(name, {}).get("donor_unit", "")).strip()
        if not policy and str(rows.get(name, {}).get("business_category", "")).strip() == \
                "account and customer profile":
            policy = "account"   # the field map's default from the kind of field (integration decision 7)
        if policy and policy not in {"event", "account"}:
            raise ValueError(f"Invalid donor_unit for {name}: {policy}")
        if name in profiles:
            if policy == "event":
                raise ValueError(f"Conflicting donor policy for profile {name}")
            policy = "account"
        declared.add(policy or "event")
    if len(declared) != 1:
        raise ValueError("A joint unit mixes event and account donors; specify separate units")
    return declared.pop()


def _clusters(table):
    if table.empty:
        return []
    if "cluster_id" not in table:
        raise ValueError("Clusters need cluster_id and name or members columns")
    # the checks lane's clusters.csv has one row per member: cluster_id, member, member_kind, ...
    name_col = ("name" if "name" in table else "feature" if "feature" in table else
                "member" if "member" in table else None)
    if name_col is None and "members" not in table:
        raise ValueError("Clusters need a name, feature, member or members column")
    grouped = {}
    for row in table.to_dict("records"):
        cluster = str(row["cluster_id"]).strip()
        if not cluster or cluster.lower() == "nan":
            continue
        members = _names(row[name_col] if name_col else row["members"])
        group = grouped.setdefault(cluster, [])
        group.extend(name for name in members if name not in group)
    return list(grouped.items())


UNIT_CHOICES = ("singles", "clusters", "both", "groups")


def build_units(feature_names, field_map=None, clusters=None, units="both",
                profile_fields=(), unit_specs=None):
    """Build model-input sensitivities and optional explicit family experiments.

    ``unit_specs`` is a list of Unit dictionaries, or a JSON file containing that
    list. A specification replaces a generated same-name unit or appends a new
    one. Family specifications need source_columns; their model members and all
    recipe descendants are computed from the field map, not a caller's shortlist.
    Calendar outputs are artificial sensitivity checks while time stays fixed.
    """
    features = list(feature_names)
    if not features or len(set(features)) != len(features):
        raise ValueError("Predictors must be a nonempty unique list")
    if units not in UNIT_CHOICES:
        raise ValueError("units must be singles, clusters, both or groups")
    rows, profiles = _map_rows(field_map), set(profile_fields)
    raw_names = {name for row in rows.values() for name in _names(row.get("source_columns"))}
    unknown_profiles = profiles - set(features) - set(rows) - raw_names
    if unknown_profiles:
        raise ValueError(f"Unknown profile fields: {sorted(unknown_profiles)}")
    grouped = []
    if units in {"clusters", "both", "groups"}:
        for cluster, members in _clusters(_table(clusters)):
            # The checks cover more candidates than this particular fitted model.
            active = [name for name in members if name in features]
            if len(active) >= 2:
                grouped.append((cluster, active))
    # groups (the reviewers' decision D6, the fallback when both does not fit the GPU cap): every cluster with two
    # or more active members, and singles only for the inputs in no such cluster
    in_cluster = {name for _, active in grouped for name in active} if units == "groups" else set()
    planned = {}
    if units in {"singles", "both", "groups"}:
        for name in features:
            if name in in_cluster:
                continue
            planned[name] = Unit(name, [name], donor_unit=_policy([name], rows, profiles),
                                 artificial_time_fixed=name in _CALENDAR)
    for cluster, active in grouped:
        name = f"cluster:{cluster}"
        planned[name] = Unit(name, active, kind="cluster",
                             donor_unit=_policy(active, rows, profiles),
                             artificial_time_fixed=bool(set(active) & _CALENDAR))
    if isinstance(unit_specs, (str, Path)):
        with open(unit_specs, encoding="utf-8") as stream:
            unit_specs = json.load(stream)
    if unit_specs is not None and not isinstance(unit_specs, (list, tuple)):
        raise ValueError("Unit specifications must be a list")
    explicit_names = set()
    for item in unit_specs or []:
        spec = asdict(item) if isinstance(item, Unit) else dict(item)
        name = spec.get("name")
        if not isinstance(name, str) or not name or name in explicit_names:
            raise ValueError("Unit specifications need unique nonempty names")
        explicit_names.add(name)
        method = spec.get("method", "single_output_possibly_inconsistent")
        if method == "family":
            if not rows:
                raise ValueError("Source-family importance needs the recipe field map")
            sources = _names(spec.get("source_columns"))
            if not sources or set(sources) & (_FIXED | _CALENDAR):
                raise ValueError("Family sources must be supplied and cannot change time or identities")
            descendants = _descendants(sources, rows)
            if not descendants:
                raise ValueError("Family has no declared dependent recipes; use method source")
            supplied = _names(spec.get("dependent_outputs"))
            if set(supplied) - set(descendants):
                raise ValueError("Family declares outputs not dependent on its source columns")
            members = [feature for feature in features if feature in set(sources + descendants)]
            if not members:
                raise ValueError("Family affects no predictor of this fitted model")
            if set(_names(spec.get("members"))) - set(members):
                raise ValueError("Family member is not an affected predictor")
            spec.update(kind="family", members=members, source_columns=sources,
                        dependent_outputs=descendants)
            policy = _policy(sources, rows, profiles)
        else:
            members = _names(spec.get("members"))
            if not members or set(members) - set(features):
                raise ValueError("Unit members must be predictors of this fitted model")
            spec["members"] = members
            policy = _policy(members, rows, profiles)
            if method == "source":
                sources = _names(spec.get("source_columns")) or members
                if set(sources) != set(members):
                    raise ValueError("Source-only units use their own modeled raw columns; use family for recipes")
                for member in members:
                    if str(rows.get(member, {}).get("recipe", "raw")).strip() not in {"", "raw"}:
                        raise ValueError("An engineered output needs family or single-output sensitivity")
        if policy == "account" and spec.get("donor_unit", "account") != "account":
            raise ValueError("Explicit donor policy conflicts with the declared account profile")
        spec.setdefault("donor_unit", policy)
        if "source_columns" in spec:
            spec["source_columns"] = _names(spec["source_columns"])
        if "dependent_outputs" in spec:
            spec["dependent_outputs"] = _names(spec["dependent_outputs"])
        spec["artificial_time_fixed"] = bool(spec.get("artificial_time_fixed", False)
                                             or set(spec["members"]) & _CALENDAR)
        planned[name] = Unit(**spec)
    if not planned:
        raise ValueError("No active importance units for this fitted model")
    return list(planned.values())


def shared_closure(module, rows, sources):
    """The recipe engine's own dependency rule (nf_recipes.dependency_closure) for these sources: the engineered
    outputs whose recipes read any of them. A source that is not a map row is added as a raw row for the walk."""
    table = [{"name": n, "recipe": str(r.get("recipe", "raw") or "raw"),
              "model_type": str(r.get("model_type", "") or "continuous")} for n, r in rows.items()]
    table += [{"name": s, "recipe": "raw", "model_type": "continuous"} for s in sources if s not in rows]
    return set(module.dependency_closure(pd.DataFrame(table), list(sources))["outputs"])


def non_account_keys(field_map, units, account_col="Nmap_account_reference_xid"):
    """{family unit name: [history keys]} for families whose rebuilt recipes group by a key other than the account
    (key=customer, card). A sample of whole accounts would rebuild them from partial histories (decision 12)."""
    rows = _map_rows(field_map)
    if not rows:
        return {}
    module = importlib.import_module("nf_recipes")
    out = {}
    for unit in units:
        if unit.method != "family":
            continue
        keys = set()
        for name in unit.dependent_outputs:
            recipe = str(rows.get(name, {}).get("recipe", "") or "raw").strip()
            try:
                key = module.parse(recipe).key
            except ValueError:
                continue
            if key and key != account_col:
                keys.add(key)
        if keys:
            out[unit.name] = sorted(keys)
    return out


def make_recompute(field_map, account_col, time_col, extract_start, *, recipe_builder: Callable | None = None):
    """Recompute declared family descendants with the shared recipe engine.

    The engine receives the whole retained-account stream. The injected callable
    uses the required integration interface: (frame, field_map,
    account_col=..., time_col=..., extract_start=...) -> dataframe. Nothing here
    implements an alternate recipe or silently leaves a dependent output stale.
    """
    rows = _map_rows(field_map)
    order = dependency_order(rows)

    def requirements(unit):
        needed, leaves = set(unit.dependent_outputs), set(unit.source_columns)

        def visit(name):
            row = rows.get(name)
            if row is None or str(row.get("recipe", "raw")).strip() in {"", "raw"}:
                leaves.add(name)
                return
            needed.add(name)
            for source in _names(row.get("source_columns")):
                visit(source)

        for name in unit.dependent_outputs:
            visit(name)
        return [name for name in order if name in needed], sorted(leaves | {account_col, time_col})

    def recompute(frame, unit):
        if unit.method != "family":
            raise ValueError("Recipe recomputation needs a family unit")
        expected = _descendants(unit.source_columns, rows)
        if set(expected) != set(unit.dependent_outputs):
            raise ValueError("Family dependent outputs do not match the field map")
        needed, _ = requirements(unit)
        selected = pd.DataFrame([rows[name] for name in needed])
        builder = recipe_builder
        if builder is None:
            try:
                module = importlib.import_module("nf_recipes")
            except ImportError as error:
                raise RuntimeError("Family importance needs the package's nf_recipes module") from error
            builder = getattr(module, "build_fields", None)
            if builder is None:
                raise RuntimeError("Recipe engine lacks the required build_fields interface")
            # one dependency rule: the engine's dependency_closure must give the outputs the map declares
            closure = shared_closure(module, rows, unit.source_columns)
            if closure != set(expected):
                raise ValueError(f"the recipe engine's dependency_closure gives {sorted(closure)} for "
                                 f"{unit.source_columns}, the map's source_columns give {sorted(expected)}: "
                                 "correct source_columns (the engine builds every output from raw columns)")
        # Enriched scoring inputs already contain these outputs. The recipe
        # builder creates columns, so rebuild them from their raw prerequisites
        # while retaining the original frame for the unchanged result columns.
        recipe_input = frame.drop(columns=[name for name in needed if name in frame]).copy(deep=True)
        changed = builder(recipe_input, selected, account_col=account_col,
                          time_col=time_col, extract_start=extract_start)
        if not isinstance(changed, pd.DataFrame):
            raise ValueError("Recipe engine must return a dataframe")
        if not changed.index.equals(frame.index) or len(changed) != len(frame):
            raise ValueError("Recipe engine changed the event order or membership")
        missing = set(expected) - set(changed.columns)
        if missing:
            raise ValueError(f"Recipe engine omitted dependent outputs: {sorted(missing)}")
        result = frame.copy(deep=True)
        for name in expected:
            result[name] = changed[name]
        return result

    def required(unit):
        cols = requirements(unit)[1]
        if recipe_builder is None:
            try:
                module = importlib.import_module("nf_recipes")
                needed = requirements(unit)[0]
                table = pd.DataFrame([rows[n] for n in needed]) if needed else None
                if table is not None:
                    # the engine's own list: account, time, the tie id, then every source
                    cols = sorted(set(cols) | set(module.required_columns(table, needed, account_col=account_col,
                                                                          time_col=time_col)))
            except (ImportError, ValueError):
                pass
        return cols

    recompute.required_columns = required
    return recompute
