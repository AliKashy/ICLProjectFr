"""One fit as the queue runs it: the chosen trainer's own ``main``, with an optional TensorBoard logger.

  $PY $NF/nf_fit.py --run nf_a1 --config $NF/configs/nf_a1.yaml training.seed=42 \
      output.checkpoint_dir=checkpoints/new_fields/runs/nf_a1/seed42

The chosen trainer builds its Lightning Trainer with ``logger=False``. When SETTINGS.yaml says ``tensorboard: true``
(the default), this wrapper replaces the trainer's ``build_trainer`` in memory for this one process: it calls the
original, then gives the Trainer a ``pytorch_lightning.loggers.TensorBoardLogger`` that writes to
``checkpoints/new_fields/tb/<run>/seed<NN>/``. No file is edited. The logger only records what the model already
logs, so the weights, the checkpoints, ``training_metrics.csv`` and the run manifest are the same with and without
it (tested). With ``tensorboard: false``, or when the tensorboard package is not installed (a line says so), the
trainer runs exactly as ``$PY -m <trainer> ...`` would.

View the curves: ``tensorboard --logdir checkpoints/new_fields/tb``, or
``python fraud/scripts/show_progress.py --source tensorboard --logdir checkpoints/new_fields/tb/<run>/seed<NN>``.

Exit codes: the trainer's own; 2 bad arguments.
"""
import argparse
import importlib
import runpy
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path(__file__).resolve().parents[4]
for _p in (str(HERE), str(ROOT / "src"), str(ROOT)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import nf_common as C  # noqa: E402
import nf_layout  # noqa: E402


def trainer_module_name():
    lay, _ = nf_layout.detect()
    return nf_layout.TABLE["trainer"][0 if lay == nf_layout.REORGANIZED else 1][0]


def tensorboard_on(settings=None):
    s = C.settings() if settings is None else settings
    return bool(s.get("tensorboard", True))


def tb_dir(run, overrides):
    seed = next((o.split("=", 1)[1] for o in overrides if o.startswith("training.seed=")), "")
    return C.c2() / "tb" / run / (f"seed{seed}" if seed else "")


def with_tensorboard(tm, log_dir):
    """Wrap ``tm.build_trainer`` so the Trainer it returns logs to TensorBoard. Returns the original, to put back."""
    from pytorch_lightning.loggers import TensorBoardLogger
    original = tm.build_trainer

    def build_trainer(cfg, callbacks):
        trainer = original(cfg, callbacks)
        Path(log_dir).mkdir(parents=True, exist_ok=True)
        trainer.loggers = [TensorBoardLogger(save_dir=str(log_dir), name="", version="")]
        return trainer

    tm.build_trainer = build_trainer
    return original


def tensorboard_installed():
    try:
        importlib.import_module("tensorboard")
        return True
    except ImportError:
        try:
            importlib.import_module("tensorboardX")
            return True
        except ImportError:
            return False


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    ap = argparse.ArgumentParser(description="one fit with an optional TensorBoard logger")
    ap.add_argument("--run", required=True, help="the run name, for the TensorBoard folder")
    ap.add_argument("--no-tensorboard", action="store_true", help="run without the logger, whatever the settings")
    args, rest = ap.parse_known_args(argv)
    if "--config" not in rest:
        C.say("refused: --config is needed", file=sys.stderr)
        return C.ARGS
    name = trainer_module_name()
    tm = importlib.import_module(name)
    overrides = [a for a in rest if "=" in a and not a.startswith("-")]
    use_tb = tensorboard_on() and not args.no_tensorboard
    original = None
    if use_tb and not tensorboard_installed():
        print("tensorboard: the tensorboard package is not installed; this fit runs without TensorBoard logs")
        use_tb = False
    if use_tb and not hasattr(tm, "build_trainer"):
        print(f"tensorboard: {name} has no build_trainer; this fit runs without TensorBoard logs")
        use_tb = False
    if use_tb:
        log_dir = tb_dir(args.run, overrides)
        original = with_tensorboard(tm, log_dir)
        print(f"tensorboard: {C.rel(log_dir)}")
    try:
        if hasattr(tm, "main"):
            sys.argv = [str(getattr(tm, "__file__", name)), *rest]
            rc = tm.main(rest)
            return int(rc or 0)
        sys.argv = [str(getattr(tm, "__file__", name)), *rest]
        sys.modules.pop(name, None)     # run it fresh as __main__, as python -m does
        runpy.run_module(name, run_name="__main__", alter_sys=True)
        return 0
    except SystemExit as e:
        return e.code if isinstance(e.code, int) else (0 if e.code is None else 1)
    finally:
        if original is not None:
            tm.build_trainer = original


if __name__ == "__main__":
    sys.exit(main())
