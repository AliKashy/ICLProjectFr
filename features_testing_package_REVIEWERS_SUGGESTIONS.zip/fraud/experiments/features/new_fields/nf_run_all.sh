#!/usr/bin/env bash
# The new-fields queue. Started by nf_start.sh with nohup; never run two at once (QUEUE.lock.json).
# Jobs run one at a time; GPU jobs only after the busy check. Logs are appended under checkpoints/new_fields/.
# Exit codes: 0 done; 1 a crash; 2 bad arguments; 3 STOP (a check failed); 4 refused; 5 a reported step failed.
set -u
NF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$NF/../../../.." && pwd)"
PY="${PY:-}"
if [ -z "$PY" ] || ! "$PY" -c "import omegaconf, torch" > /dev/null 2>&1; then
  echo "refused: set PY to the project's Python, exported, for example: PY=<the pod's python> bash $0 (exit 2)" >&2
  exit 2
fi
cd "$ROOT"
OUT="${NF_OUT:-checkpoints/new_fields}"
mkdir -p "$OUT/logs"
echo "queue start $(date -u +%Y-%m-%dT%H:%M:%SZ) pid $$" >> "$OUT/queue.log"
NF_PY="$PY" "$PY" "$NF/nf_plan.py" queue --queue-pid $$ "$@"
rc=$?
"$PY" "$NF/nf_report.py" > /dev/null 2>&1 || true
exit $rc
