"""Planner and queue for the new-fields steps (DESIGN.md section 6, with the design review's corrections).

  $PY $NF/nf_plan.py preflight     # phase P0 checks; checkpoints/new_fields/reads/preflight.json
  $PY $NF/nf_plan.py next          # the next job, as JSON (what the queue would run now)
  $PY $NF/nf_plan.py plan          # every known job and its state, one screen
  $PY $NF/nf_plan.py busy          # the busy check; exit 4 when anything runs
  $PY $NF/nf_plan.py queue         # run jobs one at a time (started by nf_run_all.sh, never by hand)

The plan is rebuilt from the files every time: STEPS.yaml, SETTINGS.yaml, UPSTREAM.yaml, rank_check.json, the run
folders, the score receipts and the saved reads. So a restart continues at the first job whose output is missing.
Nothing is overwritten: a complete fit or score is skipped; an incomplete one stops the queue with "rename it".
A saved read is reused only while the checkpoints, predictions and settings it read are unchanged.
"""
import argparse
import hashlib
import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nf_common as C  # noqa: E402
import nf_layout  # noqa: E402

COMPLETE = ("finished", "budget_reached")
MANIFEST = "run_manifest_v2.json"
LOCK = "QUEUE.lock.json"
POP_ARGS = {
    "rank_b": ("OTHER", "new_fields_rank_b_decision"),
    "rank_a": ("OTHER", "new_fields_rank_a_importance"),
    "select": ("SELECT", "new_fields_select_check"),
    "test1": ("DEV_OOT", "new_fields_report"),
}


DRY = False     # True for the report and `plan`: the walk then writes nothing
REUSE = {}      # (tag, population) -> (predictions, receipt) of existing SELECT scores (DESIGN.md 7.3, 7.5)


def _write(path, obj):
    if not DRY:
        C.write_json(path, obj)


class Stop(Exception):
    """The queue stops here (exit 3), with a reason for the owner."""


# ------------------------------------------------------------------ small helpers

def c2(*parts):
    return C.c2().joinpath(*[str(p) for p in parts])


def run_dir(run, seed):
    return c2("runs", run, f"seed{seed}")


PID_LIMIT = C.PID_LIMIT     # the one pid rule, shared with the busy check (nf_common.lock_pid)
lock_pid = C.lock_pid


def other_host(held):
    """The host a lock record names when that is not this host, else None (also for a record with no host).
    The project folder is shared by the owner's workbenches: each is its own pod with its own hostname, which a
    restart keeps, and all of them mount the same folder at the same paths."""
    if not isinstance(held, dict):
        return None
    h = held.get("hostname")
    return str(h) if h not in (None, "") and h != socket.gethostname() else None


def owner_alive(held):
    """Whether the owner of a lock record may still run. The one rule for QUEUE.lock.json, a takeover claim file
    and a trainer's RUNNING.lock.json (acquire_lock, trainer_alive, queue_alive, fit_state, nf_report).
    A record that names another host is never stale: that host is another of the owner's workbenches on the same
    project folder, and this pod cannot see its processes, so such a lock is never replaced (POD.md step 21).
    A record that names this host is alive while this host has the process it names; a process of another user
    counts as alive (the system refuses the signal but has the process), so such a lock is never taken over."""
    if not isinstance(held, dict):
        return False
    if other_host(held) is not None:
        return True
    pid = lock_pid(held)
    if pid is None:
        return False
    try:
        os.kill(pid, 0)
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def _trainer_lock(d):
    lock = Path(d) / "RUNNING.lock.json"
    if not lock.is_file():
        return None
    try:
        return C.read_json(lock)
    except (OSError, ValueError):
        return None


def trainer_alive(d):
    """The trainer's lock in this run folder names a live process on this host, or names another workbench."""
    held = _trainer_lock(d)
    return held is not None and owner_alive(held)


def trainer_host(d):
    """The other workbench a trainer's lock in this run folder names, else None."""
    return other_host(_trainer_lock(d))


def queue_alive():
    """QUEUE.lock.json names a queue that still runs (the owner rule of the lock itself)."""
    p = c2(LOCK)
    if not p.is_file():
        return False
    try:
        return owner_alive(C.read_json(p))
    except (OSError, ValueError):
        return False


def fit_state(d):
    """complete, RUNNING, INCOMPLETE or MISSING. The queue and the morning report both use this rule, so they
    always agree. RUNNING while the trainer's lock names a live process on this host (from the moment the trainer
    starts, before its manifest says running), and always when it names another workbench (trainer_host): this
    pod cannot see that trainer, so its folder is never called incomplete. A lock of this host whose process is
    dead (a crash or a restart) is an incomplete folder (rename it)."""
    d = Path(d)
    if not d.exists() or not any(d.iterdir()):
        return "MISSING"
    m = d / MANIFEST
    st = None
    if m.is_file():
        try:
            st = C.read_json(m).get("status")
        except (OSError, ValueError):
            st = None
    if st in COMPLETE and (d / "best.ckpt").is_file():
        return "complete"
    if trainer_alive(d):
        return "RUNNING"
    return "INCOMPLETE"


def score_state(out):
    out = Path(out)
    rec = Path(str(out) + ".json")
    exp = Path(str(out) + ".exposure.json")
    if rec.is_file() and out.is_file():
        try:
            r = C.read_json(rec)
        except (OSError, ValueError):
            return "BAD"
        if r.get("predictions_sha256") and r["predictions_sha256"] != C.sha256_file(out):
            return "BAD"
        return "complete"
    if out.exists() or exp.exists() or rec.exists():
        return "PARTIAL"
    return "MISSING"


def trainer_module():
    lay, _ = nf_layout.detect()
    return nf_layout.TABLE["trainer"][0 if lay == nf_layout.REORGANIZED else 1][0]


def scorer_module():
    lay, _ = nf_layout.detect()
    return nf_layout.TABLE["scorer"][0 if lay == nf_layout.REORGANIZED else 1][0]


def py():
    return os.environ.get("NF_PY") or sys.executable


def tool(name):
    return str(C.NF / name)


# ------------------------------------------------------------------ plan context

class Ctx:
    def __init__(self):
        self.settings = C.settings()
        self.steps = C.steps()
        self.up = C.upstream() if (C._settings_dir() / "UPSTREAM.yaml").is_file() else {}
        rc = c2("reads", "rank_check.json")
        self.rank = C.read_json(rc) if rc.is_file() else None
        self.state = C.read_json(c2("queue_state.json")) if c2("queue_state.json").is_file() else {}
        self.failed_optional = set(self.state.get("failed_optional", []))
        self.notes = []
        REUSE.clear()
        REUSE.update(existing_select_scores(self.up))

    @property
    def decide_on(self):
        if self.rank is None:
            raise Stop("rank_check.json is missing: run nf_rank_check.py (part A)")
        if str(self.settings.get("decide_on") or "rank_b") == "select_june":
            return "select"      # the owner's choice in SETTINGS.yaml; the reader reads the same
        d = self.rank.get("decide_on")
        if d == "owner":
            raise Stop("RANK-B failed its rank check and the plan's fallback files passed the same checks, so they "
                       "take its place (plan section 3): the owner decides how they are used (Copilot sets "
                       "SETTINGS.yaml populations rank_a and rank_b and runs nf_rank_check.py again), or sets "
                       "SETTINGS.yaml decide_on: select_june")
        return "rank_b" if d == "rank_b" else "select"

    def pop_label(self):
        return "rank_b" if self.decide_on == "rank_b" else "select_june"


def existing_select_scores(up):
    """Kept seeds' and stage 1's SELECT prediction files from UPSTREAM.yaml, used instead of scoring again when the
    file's SHA-256 equals its receipt's predictions_sha256 and the receipt's checkpoint_sha256 equals best.ckpt.
    A path that does not verify is not used; the queue then scores it once."""
    found = {}
    kept = (up or {}).get("kept") or {}
    kdir = C.ROOT / (kept.get("dir") or "models/sequential_hier_allpos_h20_chunk")
    cands = [(f"kept_seed{k[4:]}", (kept.get("select_predictions") or {}).get(k),
              (kept.get("select_receipts") or {}).get(k), kdir / f"seed{k[4:]}" / "best.ckpt")
             for k in (kept.get("select_predictions") or {})]
    s1 = (up or {}).get("stage1") or {}
    if s1.get("select_predictions"):
        cands.append(("control_seed42", s1["select_predictions"], s1.get("select_receipt"),
                      C.ROOT / (s1.get("control_dir") or "") / "best.ckpt"))
    for tag, pred, rec, ckpt in cands:
        if not pred or not rec:
            continue
        p, r = C.ROOT / pred, C.ROOT / rec
        if not (p.is_file() and r.is_file() and ckpt.is_file()):
            continue
        try:
            obj = C.read_json(r)
        except (OSError, ValueError):
            continue
        if obj.get("predictions_sha256") != C.sha256_file(p):
            continue
        if obj.get("checkpoint_sha256") and obj["checkpoint_sha256"] != C.sha256_file(ckpt):
            continue
        found[(tag, "select")] = (p, r)
    return found


def stage1_control(ctx):
    """(run label, folder, complete) of stage 1's seed-42 retrain."""
    d = ((ctx.up.get("stage1") or {}).get("control_dir")) or ""
    if not d:
        return None
    p = C.ROOT / d
    return ("control_stage1", p, fit_state(p) == "complete")


def control_lr(folder):
    for name in ("resolved_train_v2.yaml", "config.yaml"):
        p = Path(folder) / name
        if p.is_file():
            v = C.flatten(C.load_yaml(p)).get("training.learning_rate")
            if v is not None:
                return float(v)
    return None


UPDATES_PER_EPOCH = 2103   # stage 1 rule S7: every epoch of the chosen run has 2,103 optimizer updates


def adding_steps(ctx):
    """The adding steps that are on, in order; with one_step_all, one step ALL that adds every group at once."""
    on = [s for s in ctx.steps.get("steps", []) if C.step_on(s) and not s.get("kind")]
    if ctx.steps.get("one_step_all") and on:
        on = [{"name": "ALL", "adds": [g for s in on for g in s.get("adds", [])], "members": [s["name"] for s in on]}]
    return on


def first_step_run(ctx):
    """The first adding step's run name (nf_a1, or nf_all with one_step_all), or None."""
    on = adding_steps(ctx)
    return f"nf_{on[0]['name'].lower()}" if on else None


def microbatch_entry(ctx, run):
    """SETTINGS.yaml microbatch for one candidate run (the width timing's memory rule), or None."""
    return ((ctx.settings.get("microbatch") or {}).get(run)) or None


def _int(v, default=None):
    try:
        return int(v)
    except (TypeError, ValueError):
        return default


def config_micro(path):
    """(batch_size, accumulate_grad_batches, eval_batch_size) of a config file; eval batch None when not set."""
    f = C.flatten(C.load_yaml(path))
    return (_int(f.get("training.batch_size")), _int(f.get("training.accumulate_grad_batches"), 1),
            _int(f.get("training.eval_batch_size")))


def fit_micro(entry):
    """The micro-batch a fit ran at (its resolved config when the fit is complete), else its config file's."""
    d = Path(entry["dir"])
    rp = d / "resolved_train_v2.yaml"
    if fit_state(d) == "complete" and rp.is_file():
        return config_micro(rp), rp
    p = Path(entry.get("config_file") or entry["config"])
    return config_micro(p), p


def _mb_text(m):
    return f"batch {m[0]} x accumulation {m[1]}"


def base_control(ctx):
    """The seed-42 base control for the first step (the stage 1 rule, D5b). Stage 1's retrain is the control only if
    it is complete, ran at stage 0's best rate (SETTINGS.yaml learning_rate; 3e-4 for the kept recipe), and ran at the
    first step's micro-batch (no memory-rule entry for that step, or one equal to the retrain's as-run batch and
    accumulation). The base inputs' per-field hashes are the artifact check's, and the code path is the guard's;
    both are checked before any fit. Otherwise our own control fit (P1, nf_control at stage 0's rate and the first
    step's micro-batch) replaces it, once SETTINGS.yaml control_p1_owner_yes holds the reviewers' record."""
    s1 = stage1_control(ctx)
    lr = float(ctx.settings["learning_rate"])
    first = first_step_run(ctx)
    want = microbatch_entry(ctx, first) if first else None
    why = []
    if not (s1 and s1[2]):
        why.append("stage 1's seed-42 retrain does not exist")
    else:
        if control_lr(s1[1]) != lr:
            why.append(f"stage 1's control ran at another learning rate ({control_lr(s1[1])} vs {lr})")
        rp = s1[1] / "resolved_train_v2.yaml"
        if want and rp.is_file():
            got = config_micro(rp)[:2]
            if got != (_int(want.get("batch_size")), _int(want.get("accumulate_grad_batches"), 1)):
                why.append(f"the memory rule changed {first}'s micro-batch ({_mb_text((want.get('batch_size'), want.get('accumulate_grad_batches')))}) "
                           f"and stage 1's retrain ran at {_mb_text(got)}")
    if not why:
        return {"label": "control_stage1", "dir": s1[1], "run": None, "config": s1[1] / "resolved_train_v2.yaml"}
    yes = ctx.settings.get("control_p1_owner_yes") or {}
    if not str(yes.get("by") or "").strip():
        raise Stop(f"{'; '.join(why)}; every read is blocked until the control exists. Our own seed-42 base control "
                   "(P1, nf_control, at stage 0's rate and the first step's micro-batch) replaces the retrain only "
                   "after stage 1 passed (guard stage1_ok), with SETTINGS.yaml control_p1_owner_yes filled by the "
                   "reviewers under the owner's delegation of 2 November (who, date and stage 1's report name)")
    return {"label": "nf_control", "dir": run_dir("nf_control", 42), "run": "nf_control",
            "config": C.NF / "configs" / "nf_control.yaml"}


def microbatch_source(ctx, run):
    """The candidate whose micro-batch a run's config carries: nf_control takes the first step's, a refit control
    nf_k<step> takes nf_<step>'s, a candidate its own (D5a, D5b)."""
    if run == "nf_control":
        return first_step_run(ctx)
    if run.startswith("nf_k"):
        return "nf_" + run[len("nf_k"):]
    return run


def microbatch_config_problems(ctx):
    """Configs whose training micro-batch differs from SETTINGS.yaml microbatch of their candidate (written before
    the width timing changed it): each must be renamed and written again."""
    out = []
    folder = C.NF / "configs"
    for p in sorted(folder.glob("*.yaml")) if folder.is_dir() else []:
        src = microbatch_source(ctx, p.stem)
        want = microbatch_entry(ctx, src) if src else None
        if not want:
            continue
        got = config_micro(p)[:2]
        if got != (_int(want.get("batch_size")), _int(want.get("accumulate_grad_batches"), 1)):
            out.append(f"{C.rel(p)} runs at {_mb_text(got)}, SETTINGS.yaml microbatch for {src} is "
                       f"{_mb_text((want.get('batch_size'), want.get('accumulate_grad_batches')))}: rename it and "
                       "write it again")
    return out


def stage1_training_check(entry):
    """Stage 1's training check on one of our base control fits (P1 and the base refits): 2,103 optimizer updates
    per epoch, from its run manifest (the trainer records epochs_run and optimizer_steps). None when it holds."""
    m = Path(entry["dir"]) / MANIFEST
    try:
        man = C.read_json(m)
    except (OSError, ValueError):
        return f"{C.rel(m)} cannot be read"
    steps, epochs = _int(man.get("optimizer_steps")), _int(man.get("epochs_run"))
    if steps is None or not epochs:
        return f"{C.rel(m)} records no optimizer_steps or epochs_run, so 2,103 updates per epoch cannot be checked"
    if steps != UPDATES_PER_EPOCH * epochs:
        return (f"{C.rel(m)}: {steps:,} optimizer updates in {epochs} epochs, not {UPDATES_PER_EPOCH:,} per epoch "
                "(stage 1 rule S7)")
    return None


def job(jid, phase, kind, cmd, gpu, optional=False, log=None, out=None):
    return {"id": jid, "phase": phase, "kind": kind, "cmd": [str(x) for x in cmd], "gpu": gpu, "optional": optional,
            "log": str(log or c2("logs", f"{jid}.log")), "out": str(out) if out else None}


def config_job(run, steps, month_out=False, drop_file=None, calendar=None, microbatch_of=None):
    """The config writer for one run. microbatch_of names the candidate whose micro-batch a control takes (D5a)."""
    cfg = C.NF / "configs" / f"{run}.yaml"
    if cfg.is_file():
        return None
    cmd = [py(), tool("nf_make_configs.py"), "write", "--run", run, "--steps", *steps]
    if month_out:
        cmd.append("--month-out")
    if drop_file:
        cmd += ["--drop", drop_file]
    if calendar and calendar != "categorical":
        cmd += ["--calendar-cyclical"] + (["--is-weekend"] if calendar == "cyclical_weekend" else [])
    if microbatch_of:
        cmd += ["--microbatch-of", microbatch_of]
    return job(f"config_{run}", "S.0", "config", cmd, gpu=False)


def scoring_timing_job(e, ctx):
    """nf_time_width.py score on the final kept fit (the reviewers' decision D4b): single windows and the scoring
    batch, median and 99th percentile, the input count, peak memory; figures only, no threshold. Optional: a
    failure is listed and the queue goes on."""
    run = Path(e["dir"]).parent.name
    out = c2("timing", f"{run}_scoring.json")
    jid = f"scoring_timing_{run}"
    if out.is_file() or jid in ctx.failed_optional:
        return None
    return job(jid, "T", "timing", [py(), tool("nf_time_width.py"), "score", "--config", C.rel(e["config"]),
                                    "--checkpoint", C.rel(e["ckpt"]), "--run", run], gpu=True, optional=True,
               out=out)


def timing_job(run, phase):
    """The candidate's width timing (nf_time_width.py real) when C2/timing/<run>.json is missing (D5a). It writes
    the memory rule's micro-batch into SETTINGS.yaml microbatch (not a decision key of the reader)."""
    tj = c2("timing", f"{run}.json")
    if tj.is_file():
        try:
            verdict = C.read_json(tj).get("verdict")
        except (OSError, ValueError):
            verdict = None
        if verdict != "OK":
            raise Stop(f"{C.rel(tj)} says {verdict!r}: the width timing of {run} did not pass; see its screen "
                       f"{C.rel(tj.with_suffix('.txt'))}")
        return None
    cfg = C.NF / "configs" / f"{run}.yaml"
    return job(f"timing_{run}", phase, "timing", [py(), tool("nf_time_width.py"), "real", "--config", C.rel(cfg),
                                                  "--run", run, "--write-settings"], gpu=True, out=tj)


def check_config_inputs(run, steps, drop=False):
    cfg = C.NF / "configs" / f"{run}.yaml"
    if not cfg.is_file():
        return
    head = cfg.read_text(encoding="utf-8").splitlines()[0]
    want = "".join(s.lower() for s in steps) or "base"
    want += "p" if drop else ""
    if f"input set {want};" not in head:
        raise Stop(f"{C.rel(cfg)} was written for another input set ({head}); the chain needs {want}: rename it")


def fit_job(run, seed, cfg, phase):
    d = run_dir(run, seed)
    st = fit_state(d)
    if st == "complete":
        return None
    if st == "INCOMPLETE":
        raise Stop(f"{C.rel(d)} exists but incomplete: rename it to run it again")
    if st == "RUNNING":
        host = trainer_host(d)
        raise Stop(f"{C.rel(d)} has a trainer running" + (
            f" on {host}, another workbench: leave it, and run the queue on one workbench only" if host else ""))
    # the trainer's own main through nf_fit.py, which adds the TensorBoard logger when SETTINGS.yaml says so
    cmd = [py(), tool("nf_fit.py"), "--run", run, "--config", C.rel(cfg), f"training.seed={seed}",
           f"output.checkpoint_dir={C.rel(d)}"]
    return job(f"fit_{run}_seed{seed}", phase, "fit", cmd, gpu=True)


def score_out(tag, pop):
    if (tag, pop) in REUSE:
        return REUSE[(tag, pop)][0]
    return c2("scores", f"{tag}__{pop}.parquet")


def receipt_of(tag, pop):
    if (tag, pop) in REUSE:
        return REUSE[(tag, pop)][1]
    return Path(str(score_out(tag, pop)) + ".json")


def score_job(tag, cfg, ckpt, pop, phase, optional=False, ctx=None):
    if (tag, pop) in REUSE:
        return None
    out = score_out(tag, pop)
    st = score_state(out)
    if st == "complete":
        return None
    if st == "PARTIAL":
        raise Stop(f"partial outputs for {C.rel(out)}: rename them")
    if st == "BAD":
        raise Stop(f"{C.rel(out)} does not match its receipt's predictions_sha256: rename it")
    if optional and ctx and f"score_{tag}__{pop}" in ctx.failed_optional:
        return None
    population, purpose = POP_ARGS[pop]
    a, b = C.settings()["populations"][pop]["files"]
    cmd = [py(), "-m", scorer_module(), "--config", C.rel(cfg), "--checkpoint", C.rel(ckpt), "--out", C.rel(out),
           "--population", population, "--purpose", purpose, f"eval.file_start={a}", f"eval.file_end={b}"]
    return job(f"score_{tag}__{pop}", phase, "score", cmd, gpu=True, optional=optional)


# ------------------------------------------------------------------ fits, as (tag, folder, config, ckpt)

def fit_entry(tag, folder, config=None):
    folder = Path(folder)
    cfg = config or (folder / "resolved_train_v2.yaml")
    return {"tag": tag, "dir": folder, "config": Path(cfg), "ckpt": folder / "best.ckpt"}


def kept_seed_entry(ctx, seed):
    d = C.ROOT / ((ctx.up.get("kept") or {}).get("dir") or "models/sequential_hier_allpos_h20_chunk") / f"seed{seed}"
    return fit_entry(f"kept_seed{seed}", d, d / "config.yaml")


def kept_controls_valid(ctx):
    """Kept seed 43 and 44 checkpoints as controls (DESIGN.md 6.4, design review item 15). (valid, reasons)."""
    reasons = []
    g = c2("guard", "guard.jsonl")
    last = None
    if g.is_file():
        lines = [ln for ln in g.read_text(encoding="utf-8").splitlines() if ln.strip()]
        last = json.loads(lines[-1]) if lines else None
    if not (last and last.get("stage1_ok")):
        reasons.append("stage 1's rescore, route, wrapper and same-batch results did not all pass")
    ac = c2("artifact", "artifact_check.json")
    if not (ac.is_file() and _passed(C.read_json(ac))):
        reasons.append("artifact_check.json has not passed")
    if float(ctx.settings["learning_rate"]) != 3.0e-4:
        reasons.append("the learning rate is not the kept runs' 3e-4")
    bpath = C.ROOT / ctx.settings.get("base_config", "fraud/configs/sequential_hier_allpos.yaml")
    for seed in (43, 44):
        e = kept_seed_entry(ctx, seed)
        if not e["config"].is_file() or not e["ckpt"].is_file():
            reasons.append(f"kept seed {seed}: config.yaml or best.ckpt missing")
            continue
        if bpath.is_file():
            diffs = [k for k, _, _ in C.diff_configs(C.load_yaml(bpath), C.load_yaml(e["config"]))
                     if k != "training.seed" and not k.startswith(("output.", "experiment.", "eval."))]
            if diffs:
                reasons.append(f"kept seed {seed} config differs in {', '.join(diffs[:4])}")
    env = (last or {}).get("environment") or {}
    kenv = (ctx.up.get("kept") or {}).get("environment") or {}
    for k in ("torch", "lightning", "cuda", "gpu"):
        if not kenv.get(k):
            reasons.append(f"kept runs' {k} not recorded in UPSTREAM.yaml kept.environment")
        elif env.get(k) and str(kenv[k]) != str(env[k]):
            reasons.append(f"kept runs' {k} {kenv[k]} differs from here {env[k]}")
    return (not reasons), reasons


def artifact_state(obj):
    """(ok, detail) of artifact_check.json. A WAIT only for checkpoints not on disk yet (the data lane's rule: the
    control may not exist before P1) lets the queue start; the check runs again before the first candidate fit."""
    if obj is None:
        return False, "missing: run nf_check_artifact.py"
    if _passed(obj):
        return True, "PASS"
    lines = obj.get("lines") or {}
    waits = sorted(k for k, v in lines.items() if (v or {}).get("result") == "WAIT")
    if str(obj.get("result", "")).upper() == "WAIT" and waits and all(k.startswith("ckpt_") for k in waits):
        return True, ("WAIT for checkpoints not on disk yet (" + ", ".join(waits) + "); the queue runs the check "
                      "again before the first candidate fit")
    return False, f"{obj.get('result', 'not PASS')}: " + ", ".join(
        k for k, v in lines.items() if (v or {}).get("result") in ("FAIL", "WAIT"))[:200]


def artifact_recheck(ctx, control):
    """Before the first candidate fit, the artifact check must PASS with every checkpoint read. After a WAIT for
    checkpoints that did not exist yet (the control before P1), it runs again here, with the control's own."""
    ac = c2("artifact", "artifact_check.json")
    if not ac.is_file():
        return None
    obj = C.read_json(ac)
    if _passed(obj):
        return None
    ok, why = artifact_state(obj)
    if not ok:
        raise Stop(f"the artifact check does not pass ({why}); every fit waits for it")
    kdir = C.ROOT / ((ctx.up.get("kept") or {}).get("dir") or "models/sequential_hier_allpos_h20_chunk")
    ckpts = [kdir / f"seed{sd}" / "best.ckpt" for sd in (42, 43, 44)] + [control["ckpt"]]
    return job("artifact_recheck", "S.0", "cpu", [py(), tool("nf_check_artifact.py"), "--checkpoints",
                                                  *[C.rel(c) for c in ckpts]], gpu=False, out=ac)


def _passed(obj):
    if not isinstance(obj, dict):
        return False
    if obj.get("passed") is True:
        return True
    return str(obj.get("result", "")).upper() in ("PASS", "PASSED")


# ------------------------------------------------------------------ reads

def read_path(step, kind):
    return c2("reads", f"{step}_{kind}.json")


ROW_EXTRA = ("control_kind", "previous_decision")   # a control row's kind (base, refit, kept) for the reader's lines


def run_table(entries, roles, pop):
    rows = []
    for e, (role, seed) in zip(entries, roles):
        out = score_out(e["tag"], pop)
        row = {"role": role, "seed": seed, "run_dir": C.rel(e["dir"]), "checkpoint": C.rel(e["ckpt"]),
               "predictions": C.rel(out), "receipt": C.rel(receipt_of(e["tag"], pop)),
               "checkpoint_sha256": C.sha256_file(e["ckpt"]) if e["ckpt"].is_file() else None,
               "predictions_sha256": C.sha256_file(out) if out.is_file() else None}
        if role == "control":
            row.update({k: e[k] for k in ROW_EXTRA if e.get(k)})
        rows.append(row)
    return rows


def settings_sha_for_reads():
    """SETTINGS.yaml's SHA-256 without its microbatch key. The width timing writes that key while the queue runs (the
    memory rule, D5a); it changes no read, so it must not make saved reads stale."""
    def plain(x):     # YAML reads a bare key `on` as True: every key becomes text, so the dump can be sorted
        if isinstance(x, dict):
            return {str(k): plain(v) for k, v in x.items()}
        if isinstance(x, (list, tuple)):
            return [plain(v) for v in x]
        return x
    s = plain(C.settings())
    s.pop("microbatch", None)
    return C.sha256_bytes(json.dumps(s, sort_keys=True, default=str).encode())


def inputs_record(rows):
    return {"runs": [{k: r[k] for k in ("role", "seed", "checkpoint_sha256", "predictions_sha256")} for r in rows],
            "settings_sha256": settings_sha_for_reads()}


def read_job(step, kind, sub, rows, pop, phase, extra=(), optional=False, ctx=None, with_step=True, meta=None):
    """A read whose JSON exists is reused only while the checkpoints, predictions and settings it read are unchanged
    (design review item 18). The planner writes that record before the read runs; a read with no record stops.
    ``meta`` goes into the run table beside the runs (for example the step's membership note, D3a)."""
    out = read_path(step, kind)
    inp = Path(str(out)[:-len(".json")] + ".inputs.json")
    rec = inputs_record(rows)
    if out.is_file():
        if not inp.is_file():
            raise Stop(f"{C.rel(out)} has no inputs record, so it cannot be shown to be current: rename the old read")
        if C.read_json(inp) != rec:
            raise Stop(f"inputs changed since {C.rel(out)} was read: rename the old read")
        return None
    if optional and ctx and f"read_{step}_{kind}" in ctx.failed_optional:
        return None
    table = c2("reads", f"{step}_{kind}.runs.json")
    _write(table, {"step": step, "population": pop, "runs": rows, **(meta or {})})
    _write(inp, rec)
    cmd = [py(), tool("nf_read.py"), sub] + (["--step", step] if with_step else []) + \
        ["--population", pop, "--run-table", C.rel(table), "--out", C.rel(out), *extra]
    return job(f"read_{step}_{kind}", phase, "read", cmd, gpu=False, optional=optional)


def decision(step, kind):
    p = read_path(step, kind)
    if not p.is_file():
        return None
    d = C.read_json(p)
    return str(d.get("decision", "")).upper()


def classify(dec):
    if dec is None:
        return None
    if "RUN SEEDS" in dec:
        return "confirm"
    if dec.startswith(("ADOPT", "MONTH OUT", "KEEP THE SMALLER", "CALENDAR CYCLICAL")):
        return "adopt_pending" if "PENDING" in dec else "adopt"
    if dec.startswith("PASS"):
        return "pass"
    if dec.startswith("FAIL"):
        return "fail"
    return "keep"


# ------------------------------------------------------------------ the walk

def walk(ctx):
    """Yields jobs in order; the first one yielded is the next job. Raises Stop when the queue must stop."""
    pop = ctx.decide_on
    plabel = ctx.pop_label()
    seeds = [int(ctx.settings["seeds"]["main"])] + [int(s) for s in ctx.settings["seeds"]["confirm"]]
    s42 = seeds[0]
    if not refit_base_controls(ctx):
        raise Stop("STEPS.yaml refit_base_controls_43_44 is false, but the kept seed 43 and 44 checkpoints are never "
                   "controls (the reviewers' decision D5b): the base is refit at seeds 43 and 44 before the first "
                   "read; set it to true")
    ctl = base_control(ctx)
    if ctl["run"]:
        j = config_job("nf_control", [])
        if j:
            yield j
            return
        j = fit_job("nf_control", s42, ctl["config"], "P1")
        if j:
            yield j
            return
    control = fit_entry("control_seed42" if ctl["label"] == "control_stage1" else f"nf_control_seed{s42}",
                        ctl["dir"], ctl["config"] if ctl["run"] else None)
    control["control_kind"] = "base"
    # D5b: the base refits at seeds 43 and 44 on this pod and code, at stage 0's rate and the first step's
    # micro-batch: the queue's first GPU jobs after its start checks, before any read
    base_refits = []
    for sd in seeds[1:]:
        j = config_job("nf_control", [])
        if j:
            yield j
            return
        j = fit_job("nf_control", sd, C.NF / "configs" / "nf_control.yaml", "P1")
        if j:
            yield j
            return
        e = fit_entry(f"nf_control_seed{sd}", run_dir("nf_control", sd))
        e["control_kind"] = "base"
        base_refits.append(e)
    for e in ([control] if ctl["run"] else []) + base_refits:
        why = stage1_training_check(e)
        if why:
            raise Stop(f"{e['tag']} does not pass stage 1's training check ({why}); it is not read and no read "
                       "uses it")
    _memory_rule_base(ctx, control, base_refits)
    current = [control] + base_refits
    # P2: the decision population scores of the current-pod base trio and of the kept seeds, then the seed spread
    # pooled within the two trios (D5b)
    for e in current:
        j = score_job(e["tag"], e["config"], e["ckpt"], pop, "P2")
        if j:
            yield j
            return
    kept_seeds = [kept_seed_entry(ctx, s) for s in seeds]
    for e in kept_seeds:     # RANK-B: three passes; SELECT: only seeds whose existing files do not verify
        j = score_job(e["tag"], e["config"], e["ckpt"], pop, "P2")
        if j:
            yield j
            return
    spop = pop if pop == "rank_b" else "select"
    rows = run_table(kept_seeds, [("kept", s) for s in seeds], spop) + \
        run_table(current, [("current", s) for s in seeds], spop)
    j = read_job("spread", plabel, "spread", rows, plabel, "P2", with_step=False)
    if j:
        yield j
        return
    if pop == "rank_b":
        # D2: T_1 and the SELECT check take the larger of the kept seeds' spreads on RANK-B and on SELECT June, so the
        # SELECT June spread is read too (existing SELECT files that verify are not scored again)
        for e in kept_seeds:
            j = score_job(e["tag"], e["config"], e["ckpt"], "select", "P2")
            if j:
                yield j
                return
        rows = run_table(kept_seeds, [("kept", s) for s in seeds], "select")
        j = read_job("spread", "select_june", "spread", rows, "select_june", "P2", with_step=False)
        if j:
            yield j
            return
    ok, reasons = kept_controls_valid(ctx)
    log_once("kept seed 43 and 44 checkpoints: never controls (D5b); their RANK-B reads feed the pooled seed spread. "
             "As information, their validity as controls: " + ("all checks hold" if ok else "; ".join(reasons[:3])))
    # the chain of adding steps
    on = adding_steps(ctx)
    kept = {"inputs": [], "runs": {s42: control}, "is_base": True, "drop_file": None, "month_out": False,
            "calendar": None, "decided": "base", "run": None}
    history = []
    if on:
        j = artifact_recheck(ctx, control)
        if j:
            yield j
            return
    for idx, st in enumerate(on):
        name = st["name"]
        members = st.get("members", [name])
        run = f"nf_{name.lower()}"
        cand_inputs = kept["inputs"] + members
        check_config_inputs(run, cand_inputs)
        j = config_job(run, cand_inputs)
        if j:
            yield j
            return
        # the step's seed-42 control: the base control for the first step; a seed-42 refit of the kept recipe, the
        # base included, before every later step (D5a)
        if idx == 0:
            ctl42 = kept["runs"][s42]
        else:
            ctl42 = yield from control_refit(ctx, name, run, kept, s42, "S.0")
            if ctl42 is None:
                return
        _memory_rule(ctx, run, ctl42, s42)
        j = fit_job(run, s42, C.NF / "configs" / f"{run}.yaml", "S.1")
        if j:
            yield j
            return
        cand42 = fit_entry(f"{run}_seed{s42}", run_dir(run, s42))
        for e in (cand42, ctl42):
            j = score_job(e["tag"], e["config"], e["ckpt"], pop, "S.2")
            if j:
                yield j
                return
        if ctx.steps.get("attention", "every_candidate") == "every_candidate":
            j = attention_job(cand42, ctx)
            if j:
                yield j
                return
        meta = membership(ctx, name, idx, history)
        cls, cands = yield from read_decide(ctx, name, run, cand42, ctl42, kept, pop, plabel, seeds, "add", history,
                                            ("S.4", "S.5", "S.6"), meta=meta)
        if cls is None:
            return
        if cls == "adopt":
            kept = {"inputs": cand_inputs, "runs": {_seed(e): e for e in cands}, "is_base": False, "run": run,
                    "drop_file": None, "month_out": False, "calendar": None,
                    "decided": "three_seed" if len(cands) == 3 else "one_seed"}
            history.append(f"{name}: ADOPT; kept inputs {''.join(x.lower() for x in cand_inputs)}")
        else:
            history.append(f"{name}: KEEP THE CONTROL; the next step builds on the previous kept inputs")
        _write_kept(kept, history)
        if ctx.steps.get("downstream", "every_kept") == "every_kept" and cls == "adopt":
            for e in (ctl42, cand42):
                j = downstream_job(e, ctx)
                if j:
                    yield j
                    return
            rows = lift_table([cand42, ctl42], [("candidate", s42), ("control", s42)])
            j = read_job(name, "lift", "lift", rows, "ds_select", "S.7", optional=True, ctx=ctx)
            if j:
                log_once(f"{name}: DS_SELECT read once for {cand42['tag']}'s lift and once for its control "
                         f"{ctl42['tag']} (one read per kept fit and per refit control of an adopting later step)")
                yield j
                return
        if ctx.steps.get("importance") == "every_step":
            j = importance_job(cand42, ctx, "S.8")
            if j:
                yield j
                return
    adopted_any = not kept["is_base"]     # an adding step was adopted (D6: adoption decides, not is_base later)
    prune_on = C.step_on({s.get("kind"): s for s in ctx.steps.get("steps", []) if s.get("kind")}.get("prune", {}))
    if ctx.steps.get("importance") == "final" and adopted_any and prune_on:
        # D6: with pruning on, the one importance run stays before pruning, which needs it
        j = importance_job(kept["runs"][s42], ctx, "I")
        if j:
            yield j
            return
    waiting, kept = yield from special_steps(ctx, kept, pop, plabel, seeds, history)
    if waiting:
        return      # a step waits (WAIT line in the notes); the steps after it and the end reports wait with it
    # D4b: the scoring latency of the final kept fit, once, after the last stage 2 fitting step (figures only)
    j = scoring_timing_job(kept["runs"][s42], ctx)
    if j:
        yield j
        return
    if ctx.steps.get("importance") == "final" and adopted_any and not prune_on:
        # D6: one permutation importance run, on the final kept stage 2 fit (after month out), so it describes the
        # fit whose inputs stage 3 tunes; none when no adding step was adopted
        j = importance_job(kept["runs"][s42], ctx, "I")
        if j:
            yield j
            return
    # end: Test 1 report for every stage 2 fit and the control; result summary
    fits = [control]
    if c2("runs").is_dir():
        for d in sorted(c2("runs").glob("*/seed*")):
            if fit_state(d) == "complete" and d.resolve() != Path(control["dir"]).resolve():
                fits.append(fit_entry(f"{d.parent.name}_{d.name}", d))
    for e in fits:
        j = score_job(e["tag"], e["config"], e["ckpt"], "test1", "E1", optional=True, ctx=ctx)
        if j:
            yield j
            return
    t1 = c2("reads", "test1_report.txt")
    if not t1.is_file() and "read_test1_report" not in ctx.failed_optional:
        rows = run_table(fits, [("report", int(e["tag"].rsplit("seed", 1)[-1])) for e in fits], "test1")
        table = c2("reads", "test1_report.runs.json")
        _write(table, {"step": "test1", "population": "test1", "runs": rows})
        yield job("read_test1_report", "E1", "read", [py(), tool("nf_read.py"), "report", "--population", "test1",
                                                     "--run-table", C.rel(table), "--out", C.rel(t1)],
                  gpu=False, optional=True)
        return
    ctx.notes.append("E2 Test 2 (BENCH): not scored by this package; it needs the BENCH path, the row-alignment "
                     "check and the LoB exclusions (plan section 3); it blocks nothing")
    res = c2("reads", "RESULT.txt")
    if not res.is_file():
        yield job("result", "E3", "cpu", [py(), tool("nf_report.py"), "--result"], gpu=False, out=res)
        return


def membership(ctx, name, idx, history):
    """The run table's membership note for an adding step's reads (D3a): A1 is base plus the V22B group, the rows in
    both lists included; A2 is the 15298 features beyond the inputs kept after A1, and says whether A1 was adopted."""
    if name == "ALL":
        return {"membership": "every group at once (one_step_all), against the base control"}
    if name == "A1" or idx == 0:
        return {"membership": f"{name}: base plus its groups ({', '.join(group_names(ctx, name))}); the rows in both "
                              "lists count as V22B and enter here"}
    if name == "A2":
        a1 = next((h for h in history if h.startswith("A1:")), "")
        adopted = a1.startswith("A1: ADOPT")
        return {"membership": "15298 beyond the kept inputs; " + (
            "A1 was adopted, so the rows in both lists are already in the inputs" if adopted else
            "A1 kept its control, so the rows in both lists join A2"), "a1_adopted": adopted}
    return {"membership": f"{name}: its groups ({', '.join(group_names(ctx, name))}) beyond the kept inputs"}


def group_names(ctx, name):
    for s in ctx.steps.get("steps", []):
        if s.get("name") == name:
            return [str(g) for g in s.get("adds") or []]
    return []


def refit_kept_control(ctx):
    """STEPS.yaml refit_kept_control (D5a). True by default: every later step's seed-42 control is a refit of the
    kept recipe. False only with a recorded reviewers' or owner's decision to drop the refits."""
    v = ctx.steps.get("refit_kept_control", True)
    on = v is None or v is True or str(v).strip().lower() in ("", "true", "yes", "on")
    if not on and not str(ctx.steps.get("refit_kept_control_chosen_by") or "").strip():
        raise Stop("STEPS.yaml refit_kept_control is false without a recorded decision: false needs the reviewers' "
                   "or the owner's decision to drop the refits in refit_kept_control_chosen_by (D5a)")
    return on


def control_refit(ctx, name, run, kept, s42, phase):
    """D5a: before every later step (A2; A3, pruning, month out and the calendar step when they are on) the kept
    recipe, the base included, is fit again at seed 42 with the same code and settings and at the candidate's
    micro-batch; that fit is the step's seed-42 control. The kept fit stays the adopted candidate's own fit
    (importance, the export and the reports use it). Job order: the candidate's config (the caller's), the
    candidate's width timing, the refit's config, the memory rule comparing the two configs before either fit,
    the refit fit. A generator: returns the control's entry, or None after yielding a job."""
    kept42 = kept["runs"][s42]
    if not refit_kept_control(ctx):
        log_once(f"{name}: control is {kept42['tag']}, the kept fit as it is (STEPS.yaml refit_kept_control: false, "
                 f"chosen by {_chosen_by(ctx, 'refit_kept_control')}); its luck on RANK-B, where it won, favours it")
        e = dict(kept42, control_kind="kept", previous_decision=kept.get("decided", ""))
        return e
    j = timing_job(run, phase)
    if j:
        yield j
        return None
    krun = f"nf_k{name.lower()}"
    check_config_inputs(krun, kept["inputs"], drop=bool(kept.get("drop_file")))
    j = config_job(krun, kept["inputs"], month_out=bool(kept.get("month_out")), drop_file=kept.get("drop_file"),
                   calendar=kept.get("calendar"), microbatch_of=run)
    if j:
        yield j
        return None
    e = fit_entry(f"{krun}_seed{s42}", run_dir(krun, s42))
    e.update(config_file=C.NF / "configs" / f"{krun}.yaml", control_kind="refit",
             previous_decision=kept.get("decided", ""), refit_of=kept42, refit_run=krun)
    _memory_rule(ctx, run, e, s42)      # before either fit
    j = fit_job(krun, s42, C.NF / "configs" / f"{krun}.yaml", phase)
    if j:
        yield j
        return None
    log_once(f"{name}: control is {krun} seed {s42}, a refit at seed 42 of the kept recipe ({kept42['tag']}) at the "
             f"candidate's micro-batch (STEPS.yaml refit_kept_control: true, chosen by "
             f"{_chosen_by(ctx, 'refit_kept_control')}); the kept fit stays {kept42['tag']}")
    return e


def _seed(e):
    return int(e["tag"].rsplit("seed", 1)[-1])


def read_rows(cands, ctls, pop, ctl42):
    """The read's run table: candidates and controls, and, when the seed-42 control is a refit, the kept fit it
    refits (role kept_fit, information only: the reader prints the kept fit's and the refit's reads and their gap)."""
    rows = run_table(cands + ctls, [("candidate", _seed(e)) for e in cands] + [("control", _seed(e)) for e in ctls],
                     pop)
    ref = ctl42.get("refit_of")
    if ref is not None:
        rows += run_table([ref], [("kept_fit", _seed(ref))], pop)
    return rows


def read_decide(ctx, name, run, cand42, ctl42, kept, pop, plabel, seeds, rule, history, phases, one_seed=False,
                meta=None):
    """One read at seed 42; seeds 43 and 44 when it says RUN SEEDS 43 AND 44 (candidate and control fits, scores, a
    read at three seeds); then, when RANK-B decides and the decision would change the kept inputs, the SELECT check.
    A generator: the queue takes the first job it yields. Returns ('adopt' or 'keep', candidate fits)."""
    s42 = seeds[0]
    p1, p3, psel = phases
    ref = ctl42.get("refit_of")
    if ref is not None:      # the kept fit's own score on the decision population (scored when it was read)
        j = score_job(ref["tag"], ref["config"], ref["ckpt"], pop, p1)
        if j:
            yield j
            return None, None
    rows = read_rows([cand42], [ctl42], pop, ctl42)
    j = read_job(name, "1seed", "read", rows, plabel, p1, extra=["--rule", rule], meta=meta)
    if j:
        yield j
        return None, None
    cls = classify(decision(name, "1seed"))
    cands, ctls = [cand42], [ctl42]
    if cls == "confirm" and one_seed:
        raise Stop(f"step {name} is read at seed 42 only, by its own rule; its read asked for more seeds")
    if cls == "confirm":
        ctls_more, why = confirm_controls(ctx, kept, ctl42, seeds[1:])
        history.append(f"{name}: {why}")
        log_once(f"{name}: {why}")
        for sd, ce in zip(seeds[1:], ctls_more):
            _memory_rule(ctx, run, ce, sd)      # every control runs at its candidate's micro-batch
            if ce.get("fit"):
                j = fit_job(ce["fit"][0], sd, ce["fit"][1], p3)
                if j:
                    yield j
                    return None, None
            j = fit_job(run, sd, C.NF / "configs" / f"{run}.yaml", p3)
            if j:
                yield j
                return None, None
        cands = [cand42] + [fit_entry(f"{run}_seed{sd}", run_dir(run, sd)) for sd in seeds[1:]]
        ctls = [ctl42] + ctls_more
        for e in cands + ctls:
            j = score_job(e["tag"], e["config"], e["ckpt"], pop, p3)
            if j:
                yield j
                return None, None
        rows = read_rows(cands, ctls, pop, ctl42)
        j = read_job(name, "3seed", "read", rows, plabel, p3, extra=["--rule", rule], meta=meta)
        if j:
            yield j
            return None, None
        cls = classify(decision(name, "3seed"))
        if cls == "confirm":
            raise Stop(f"step {name}: the three-seed read asks for more seeds; no further seeds run after three")
    if cls in ("adopt", "adopt_pending") and pop == "rank_b":
        for e in cands + ctls:
            j = score_job(e["tag"], e["config"], e["ckpt"], "select", psel)
            if j:
                yield j
                return None, None
        rows = run_table(cands + ctls, [("candidate", _seed(e)) for e in cands] + [("control", _seed(e)) for e in ctls],
                         "select")
        j = read_job(name, "select", "select-check", rows, "select_june", psel)
        if j:
            yield j
            return None, None
        sel = classify(decision(name, "select"))
        if sel not in ("pass", "fail"):
            raise Stop(f"step {name}: the SELECT check's decision is not PASS or FAIL")
        cls = "adopt" if sel == "pass" else "keep"
    elif cls == "adopt_pending":
        cls = "adopt"
    return ("adopt" if cls == "adopt" else "keep"), cands


def special_steps(ctx, kept, pop, plabel, seeds, history):
    """Pruning (P), month out (B) and the cyclical calendar (C), all off by default. Each reads against a seed-42
    refit of the kept recipe (nf_kp, nf_kb, nf_kc; D5a) with the adding steps' job order. P is read at seed 42 only,
    by the pruning rule alone. B and C use the one-fit rule, then the month rule; their seed 43 and 44 controls are new
    fits of the refit's recipe (the base's refits when the kept recipe is the base). Every decision that keeps the
    change gets its SELECT check and moves the kept inputs. Returns True when a step waits (the steps after it wait
    too)."""
    s42 = seeds[0]
    st = {s.get("kind"): s for s in ctx.steps.get("steps", []) if s.get("kind")}
    if C.step_on(st.get("prune", {})) and not kept["is_base"]:
        ke = kept["runs"][s42]
        imp = c2("importance", ke["tag"], "importance.csv")
        if not imp.is_file():
            j = importance_job(ke, ctx, "I")
            if j:
                yield j
                return None, None
            failed = f"importance_{ke['tag']}" in ctx.failed_optional
            _, why = importance_timing(ke, ctx)
            why = importance_wait(ctx) or why
            line = (f"P WAITS: pruning needs {C.rel(imp)}; "
                    + (f"the importance run failed (log {C.rel(c2('logs', 'importance_' + ke['tag'] + '.log'))})"
                       if failed else why)
                    + ". Fix it and start the queue again; nothing after P runs until then")
            ctx.notes.append(line)
            log_once(line)
            history.append("P: WAIT (no importance file)")
            _write_kept(kept, history)
            return True, kept
        drop = prune_list(imp, ctx)
        dfile = c2("reads", "P_drop.txt")
        if dfile.is_file():
            saved = [x for x in dfile.read_text(encoding="utf-8").split() if x]
            if saved != drop:
                raise Stop(f"{C.rel(dfile)} differs from the list the importance file gives now: rename it")
        elif not DRY:
            dfile.parent.mkdir(parents=True, exist_ok=True)
            dfile.write_text("\n".join(drop) + "\n", encoding="utf-8")
        if drop:
            check_config_inputs("nf_p", kept["inputs"], drop=True)
            j = config_job("nf_p", kept["inputs"], drop_file=C.rel(dfile))
            if j:
                yield j
                return None, None
            ctl = yield from control_refit(ctx, "P", "nf_p", kept, s42, "P")
            if ctl is None:
                return None, None
            _memory_rule(ctx, "nf_p", ctl, s42)
            j = fit_job("nf_p", s42, C.NF / "configs" / "nf_p.yaml", "P")
            if j:
                yield j
                return None, None
            cand = fit_entry(f"nf_p_seed{s42}", run_dir("nf_p", s42))
            for e in (cand, ctl):
                j = score_job(e["tag"], e["config"], e["ckpt"], pop, "P")
                if j:
                    yield j
                    return None, None
            cls, cands = yield from read_decide(ctx, "P", "nf_p", cand, ctl, kept, pop, plabel, seeds, "prune",
                                                history, ("P", "P", "P"), one_seed=True)
            if cls is None:
                return None, None
            if cls == "adopt":
                kept = dict(kept, runs={_seed(e): e for e in cands}, run="nf_p", drop_file=C.rel(dfile),
                            decided="one_seed")
                history.append("P: KEEP THE SMALLER LIST; dropped " + ", ".join(drop))
            else:
                history.append("P: KEEP THE UNPRUNED LIST")
        else:
            history.append("P: nothing to prune (no cluster or field interval at or below zero)")
        _write_kept(kept, history)
    if C.step_on(st.get("month_out", {})):
        check_config_inputs("nf_b", kept["inputs"], drop=bool(kept.get("drop_file")))
        j = config_job("nf_b", kept["inputs"], month_out=True, drop_file=kept.get("drop_file"),
                       calendar=kept.get("calendar"))
        if j:
            yield j
            return None, None
        ctl = yield from control_refit(ctx, "B", "nf_b", kept, s42, "B")
        if ctl is None:
            return None, None
        _memory_rule(ctx, "nf_b", ctl, s42)
        j = fit_job("nf_b", s42, C.NF / "configs" / "nf_b.yaml", "B")
        if j:
            yield j
            return None, None
        cand = fit_entry(f"nf_b_seed{s42}", run_dir("nf_b", s42))
        for e in (cand, ctl):
            j = score_job(e["tag"], e["config"], e["ckpt"], pop, "B")
            if j:
                yield j
                return None, None
        cls, cands = yield from read_decide(ctx, "B", "nf_b", cand, ctl, kept, pop, plabel, seeds, "month", history,
                                            ("B", "B", "B"))
        if cls is None:
            return None, None
        if cls == "adopt":
            kept = dict(kept, runs={_seed(e): e for e in cands}, run="nf_b", month_out=True, is_base=False,
                        decided="three_seed" if len(cands) == 3 else "one_seed")
            history.append("B: MONTH OUT")
            month_out_decision_row(read_path("B", "3seed" if len(cands) == 3 else "1seed"))
            # D4c: an adopted month out gets the downstream check and one DS_SELECT lift read, as an adding step
            if ctx.steps.get("downstream", "every_kept") == "every_kept":
                cand42 = cands[0]
                for e in (ctl, cand42):
                    j = downstream_job(e, ctx)
                    if j:
                        yield j
                        return None, None
                rows = lift_table([cand42, ctl], [("candidate", s42), ("control", s42)])
                j = read_job("B", "lift", "lift", rows, "ds_select", "B", optional=True, ctx=ctx)
                if j:
                    yield j
                    return None, None
        else:
            history.append("B: KEEP MONTH")
    cs = st.get("calendar_cyclical", {})
    if C.step_on(cs):
        cal = "cyclical_weekend" if cs.get("is_weekend") else "cyclical"
        check_config_inputs("nf_c", kept["inputs"], drop=bool(kept.get("drop_file")))
        j = config_job("nf_c", kept["inputs"], month_out=bool(kept.get("month_out")), drop_file=kept.get("drop_file"),
                       calendar=cal)
        if j:
            yield j
            return None, None
        ctl = yield from control_refit(ctx, "C", "nf_c", kept, s42, "C")
        if ctl is None:
            return None, None
        _memory_rule(ctx, "nf_c", ctl, s42)
        j = fit_job("nf_c", s42, C.NF / "configs" / "nf_c.yaml", "C")
        if j:
            yield j
            return None, None
        cand = fit_entry(f"nf_c_seed{s42}", run_dir("nf_c", s42))
        for e in (cand, ctl):
            j = score_job(e["tag"], e["config"], e["ckpt"], pop, "C")
            if j:
                yield j
                return None, None
        cls, cands = yield from read_decide(ctx, "C", "nf_c", cand, ctl, kept, pop, plabel, seeds, "calendar",
                                            history, ("C", "C", "C"))
        if cls is None:
            return None, None
        if cls == "adopt":
            kept = dict(kept, runs={_seed(e): e for e in cands}, run="nf_c", calendar=cal, is_base=False,
                        decided="three_seed" if len(cands) == 3 else "one_seed")
            history.append(f"C: CALENDAR CYCLICAL ({cal})")
        else:
            history.append("C: KEEP THE CALENDAR")
    _write_kept(kept, history)
    return False, kept


def month_out_decision_row(read):
    """D4c: when month out is adopted, NF/KEEP_DECISIONS.csv records month as dropped (written once), so the workbook's
    final list and its predictor export drop month too."""
    if DRY:
        return
    import csv as _csv
    p = C.NF / "KEEP_DECISIONS.csv"
    if p.is_file():
        with open(p, encoding="utf-8") as f:
            if any((r.get("name") or "").strip() == "month" and (r.get("verdict") or "").strip() == "drop"
                   for r in _csv.DictReader(f)):
                return
    new = not p.is_file() or not p.read_text(encoding="utf-8").strip()
    with open(p, "a", encoding="utf-8", newline="") as f:
        w = _csv.DictWriter(f, fieldnames=C.KEEP_DECISIONS_COLUMNS)
        if new:
            w.writeheader()
        w.writerow({"name": "month", "group": "base", "verdict": "drop",
                    "reason": "month out adopted by the month rule and its SELECT check",
                    "evidence": f"read:{C.rel(read)}", "decided_by": "reviewers (decision D4c and the month rule)",
                    "date": C.utc_now()[:10], "definition_version": "1"})


def prune_list(imp, ctx):
    """Reading B (the reviewers' decision D4b): a unit qualifies only when the upper ends of both its UDR-drop and
    AP-drop intervals (nf_importance.py's drop_<m>_ci_high, the account bootstrap's upper percentile; older name
    <m>_drop_hi) are at or below zero, so permuting it never helped on either measure. A row without upper ends
    never qualifies. Clusters first (design review item 26): a qualifying cluster drops its new-field members; a
    single drops only if its cluster qualifies too. Base inputs never drop, and neither does a field a person
    decided to keep in NF/KEEP_DECISIONS.csv (tool proposals there are ignored). A qualifying unit is only
    nominated: the pruning refit decides."""
    import csv as _csv
    import nf_intake
    base = set(nf_intake.base_predictors())
    with open(imp, encoding="utf-8") as f:
        rows = list(_csv.DictReader(f))

    def hi(r, m):
        v = r.get(f"drop_{m}_ci_high")
        if v in (None, ""):
            v = r.get(f"{m}_drop_hi")
        return float(v) if v not in (None, "") else float("nan")

    def weak(r):
        try:
            u, a = hi(r, "udr"), hi(r, "ap")
        except ValueError:
            return False
        return u == u and a == a and u <= 0 and a <= 0     # NaN (no upper end) never qualifies
    clusters = [r for r in rows if r.get("kind", "").startswith("cluster")]
    # a family unit names no single field, so only single rows drop alone
    singles = [r for r in rows if r.get("kind", "") in ("", "single")]
    member_of = {}
    for c in clusters:
        for m in str(c.get("members", "")).split(";"):
            member_of[m.strip()] = c
    drop = []
    for c in clusters:
        if weak(c):
            drop += [m.strip() for m in str(c.get("members", "")).split(";") if m.strip()]
    for s in singles:
        name = s.get("unit") or s.get("members", "")
        c = member_of.get(name)
        if weak(s) and (c is None or weak(c)):
            drop.append(name)
    kept_by_person = {n for n, d in C.person_decisions().items() if d.get("verdict") == "keep"}
    return sorted({d for d in drop if d and d not in base and d not in kept_by_person})


def refit_base_controls(ctx):
    """STEPS.yaml refit_base_controls_43_44 (D5b), one meaning: the base is refit at seeds 43 and 44 on this pod
    and code before the first read. The kept seed 43 and 44 checkpoints are never controls, so false is refused."""
    v = ctx.steps.get("refit_base_controls_43_44", True)
    return v is None or v is True or str(v).strip().lower() in ("", "true", "yes", "on")


def confirm_controls(ctx, kept, ctl42, more_seeds):
    """Seed 43 and 44 controls (D5a, D5b). The kept seed 43 and 44 checkpoints are never controls.
    - the first step (its control is the base control): the base refits nf_control at seeds 43 and 44;
    - a refit control of a kept recipe that is not the base: new fits of the refit's recipe at seeds 43 and 44,
      so a recipe adopted at three seeds never has its own seed 43 and 44 fits reused;
    - a refit of the base: the base refits nf_control at seeds 43 and 44, unless their micro-batch differs from the
      candidate's; then the base is refit at the candidate's micro-batch under the refit's run name.
    Returns (entries, a line for DECISIONS.log)."""
    out = []
    kind = ctl42.get("control_kind")
    if kind == "refit":
        krun = ctl42["refit_run"]
        if kept["is_base"]:
            base = [fit_entry(f"nf_control_seed{sd}", run_dir("nf_control", sd)) for sd in more_seeds]
            if all(fit_state(b["dir"]) == "complete" and fit_micro(b)[0][:2] == fit_micro(ctl42)[0][:2]
                   for b in base):
                for b in base:
                    b["control_kind"] = "base"
                return base, (f"controls at 43 and 44: the base refits nf_control (D5b); {krun} is the seed-42 "
                              "refit of the base")
        for sd in more_seeds:
            e = fit_entry(f"{krun}_seed{sd}", run_dir(krun, sd))
            e.update(fit=(krun, C.NF / "configs" / f"{krun}.yaml"), config_file=C.NF / "configs" / f"{krun}.yaml",
                     control_kind="refit")
            out.append(e)
        why = ("the base refit at the candidate's micro-batch, as the base refits nf_control ran at another one"
               if kept["is_base"] else "new fits of the kept recipe; its own seed 43 and 44 fits are never reused")
        return out, f"controls at 43 and 44: {krun} ({why}; D5a)"
    if kind == "base" or kept["is_base"]:
        cfg = C.NF / "configs" / "nf_control.yaml"
        for sd in more_seeds:
            e = fit_entry(f"nf_control_seed{sd}", run_dir("nf_control", sd))
            e.update(fit=("nf_control", cfg), config_file=cfg, control_kind="base")
            out.append(e)
        return out, "controls at 43 and 44: the base refits nf_control (D5b)"
    # STEPS.yaml refit_kept_control: false (a recorded decision to drop the refits): the kept recipe's own fits
    run = Path(ctl42["dir"]).parent.name
    for sd in more_seeds:
        e = fit_entry(f"{run}_seed{sd}", run_dir(run, sd))
        e.update(fit=(run, C.NF / "configs" / f"{run}.yaml"), config_file=C.NF / "configs" / f"{run}.yaml",
                 control_kind="kept")
        out.append(e)
    return out, f"controls at 43 and 44: {run}'s own fits (refit_kept_control: false)"


def _chosen_by(ctx, key):
    return str(ctx.steps.get(f"{key}_chosen_by") or "").strip() or "not recorded (the default)"


def _memory_rule(ctx, run, ctl, seed):
    """D5a and D10: a control always runs at its candidate's micro-batch (batch and accumulation; an eval batch
    changes no training and needs no refit). Read from the two configs, or from the fits' resolved configs once they
    ran, before either fit. A candidate config written before its width timing changed the micro-batch stops too."""
    cand = fit_entry(f"{run}_seed{seed}", run_dir(run, seed))
    cand["config_file"] = C.NF / "configs" / f"{run}.yaml"
    (cm, cpath), (km, kpath) = fit_micro(cand), fit_micro(ctl)
    want = microbatch_entry(ctx, run)
    if want and cm[:2] != (_int(want.get("batch_size")), _int(want.get("accumulate_grad_batches"), 1)):
        raise Stop(f"{C.rel(cpath)} runs at {_mb_text(cm)}, but SETTINGS.yaml microbatch for {run} is "
                   f"{_mb_text((want.get('batch_size'), want.get('accumulate_grad_batches')))} (the memory rule fired "
                   "after it was written): rename it, and its fit folder if it ran, so the queue writes it again")
    if cm[:2] != km[:2]:
        who = str(ctx.settings.get("microbatch_confound_accepted_by") or "").strip()
        if who:
            log_once(f"{run} seed {seed}: the control {ctl['tag']} runs at {_mb_text(km)} and the candidate at "
                     f"{_mb_text(cm)}; a declared confound accepted by {who} (SETTINGS.yaml)")
            return
        raise Stop(f"the memory rule changed {run}'s micro-batch: the candidate runs at {_mb_text(cm)} and its control "
                   f"{ctl['tag']} at {_mb_text(km)} ({C.rel(kpath)}). Every control runs at its candidate's "
                   "micro-batch (D5a, D10): rename the control's config, and its fit folder if it ran, so the queue "
                   "fits it at the candidate's micro-batch, or the owner records the declared confound in "
                   "SETTINGS.yaml microbatch_confound_accepted_by")


def _memory_rule_base(ctx, control, base_refits):
    """D5b: the three base controls (seed 42, and the refits at 43 and 44) run at one micro-batch, the first step's
    (its memory-rule entry, else the as-run batch)."""
    first = first_step_run(ctx)
    want = microbatch_entry(ctx, first) if first else None
    m0, p0 = fit_micro(control)
    for e in base_refits:
        m, p = fit_micro(e)
        if m[:2] != m0[:2]:
            raise Stop(f"the base controls run at two micro-batches: {control['tag']} at {_mb_text(m0)} "
                       f"({C.rel(p0)}) and {e['tag']} at {_mb_text(m)} ({C.rel(p)}); every base control runs at the "
                       f"first step's micro-batch: rename NF/configs/nf_control.yaml and the nf_control fit folders "
                       "that ran at the other one")
    if want and m0[:2] != (_int(want.get("batch_size")), _int(want.get("accumulate_grad_batches"), 1)):
        raise Stop(f"the base controls run at {_mb_text(m0)} ({C.rel(p0)}), but SETTINGS.yaml microbatch for {first} "
                   f"is {_mb_text((want.get('batch_size'), want.get('accumulate_grad_batches')))}: the memory rule "
                   "fired after NF/configs/nf_control.yaml was written; rename it and the nf_control fit folders so "
                   "the queue fits them at the first step's micro-batch")


def queue_log_jobs():
    """(job id, start utc, end utc, rc) of every finished job in C2/queue.log, oldest first."""
    p = c2("queue.log")
    if not p.is_file():
        return []
    starts, out = {}, []
    for ln in p.read_text(encoding="utf-8").splitlines():
        parts = ln.split()
        if len(parts) == 3 and parts[0] == "start":
            starts[parts[1]] = parts[2]
        elif len(parts) == 4 and parts[0] == "end" and parts[2].startswith("rc="):
            out.append((parts[1], starts.get(parts[1]), parts[3], parts[2][3:]))
    return out


def _utc(text):
    from datetime import datetime
    return datetime.fromisoformat(str(text).replace("Z", "+00:00"))


def importance_timing(e, ctx):
    """The importance tool's timing input, and a line saying where it came from.

    1. The width timing JSON of the fit's run (C2/timing/<run>.json), when it holds what the tool reads
       (seconds_per_row, or started_utc, ended_utc and rows; and rank_a_rows): --timing.
    2. Else the queue's own logged wall time of the latest scoring job on the decision population, divided by its
       rows (the receipt's n_predictions, every scored row of the range): --seconds-per-row, with --rank-a-rows
       estimated as those rows scaled by RANK-A's file count over that population's.
    Returns (None, reason) when neither exists."""
    run = Path(e["dir"]).parent.name
    tj = c2("timing", f"{run}.json")
    if tj.is_file():
        try:
            d = C.read_json(tj)
        except (OSError, ValueError):
            d = {}
        rate = d.get("seconds_per_row") is not None or (d.get("started_utc") and d.get("ended_utc")
                                                        and (d.get("n_predictions") or d.get("rows")))
        if rate and d.get("rank_a_rows"):
            return ["--timing", C.rel(tj)], f"timing from {C.rel(tj)}"
    pop = ctx.decide_on
    pops = ctx.settings.get("populations") or {}
    for jid, t0, t1, rc in reversed(queue_log_jobs()):
        if rc != "0" or not t0 or not jid.startswith("score_") or not jid.endswith(f"__{pop}"):
            continue
        tag = jid[len("score_"):-len(f"__{pop}")]
        rec = receipt_of(tag, pop)
        try:
            rows = int(C.read_json(rec).get("n_predictions") or 0) if rec.is_file() else 0
            secs = (_utc(t1) - _utc(t0)).total_seconds()
        except (OSError, ValueError, TypeError):
            continue
        if rows <= 0:
            continue
        secs = max(secs, 1.0)   # queue.log has whole seconds; a pass shorter than that counts as one second
        a, b = (pops.get("rank_a") or {}).get("files", [8228, 8243])
        pa, pb = (pops.get(pop) or {}).get("files", [a, b])
        rank_a_rows = max(1, int(round(rows * (int(b) - int(a) + 1) / (int(pb) - int(pa) + 1))))
        return (["--seconds-per-row", f"{secs / rows:.6g}", "--rank-a-rows", str(rank_a_rows)],
                f"seconds per row {secs / rows:.3g} from {jid} in queue.log ({secs:.0f} s / {rows} rows); "
                f"RANK-A rows estimated at {rank_a_rows}")
    return None, (f"no timing input: no {C.rel(tj)} with seconds_per_row and rank_a_rows, and no finished scoring "
                  f"job on {pop} in queue.log")


def importance_wait(ctx):
    """Why importance and attention cannot run on RANK-A now, or None: RANK-A failed its rank check (the owner
    decides, plan section 3). The importance tool reads RANK-A's files from SETTINGS.yaml populations.rank_a itself
    (it refuses targets other than June), so a range the owner sets there is the range it scores; the tool does not
    read the rank check, so the planner keeps this wait."""
    rank_a = ((ctx.rank or {}).get("populations") or {}).get("rank_a") or {}
    if rank_a and rank_a.get("result") != "PASS":
        return "RANK-A failed its rank check; the owner decides the importance population (plan section 3)"
    return None


def importance_args(ctx):
    """The field map (families and donor units), the checks' clusters (cluster-first pruning, review item 26) and
    SETTINGS.yaml importance options."""
    out = ["--field-map", C.rel(C.NF / "FIELD_MAP.csv")]
    cl = c2("checks", "clusters.csv")
    if cl.is_file():
        out += ["--clusters", C.rel(cl)]
    imp = ctx.settings.get("importance") or {}
    for key, opt in (("account_share", "--account-share"), ("repeats", "--repeats"), ("seed", "--seed"),
                     ("max_gpu_hours", "--max-gpu-hours"), ("units", "--units"),
                     ("fallback_units", "--fallback-units")):
        if imp.get(key) is not None:
            out += [opt, str(imp[key])]
    return out


def attention_job(e, ctx):
    """The attention cross-check: one RANK-A pass of the importance tool with --attention-only."""
    folder = c2("importance", f"{e['tag']}_attention")
    if (folder / "attention.csv").is_file() or f"attention_{e['tag']}" in ctx.failed_optional:
        return None
    rank_why = importance_wait(ctx)
    if rank_why:
        ctx.notes.append(f"attention {e['tag']}: waits, {rank_why}")
        return None
    timing, why = importance_timing(e, ctx)
    if timing is None:
        ctx.notes.append(f"attention {e['tag']}: waits, {why}")
        return None
    return job(f"attention_{e['tag']}", "S.3", "attention",
               [py(), tool("nf_importance.py"), "run", "--attention-only", "--config", C.rel(e["config"]),
                "--checkpoint", C.rel(e["ckpt"]), "--output", C.rel(folder), *importance_args(ctx), *timing],
               gpu=True, optional=True, out=folder / "attention.csv")


def importance_job(e, ctx, phase):
    folder = c2("importance", e["tag"])
    if (folder / "importance.csv").is_file() or f"importance_{e['tag']}" in ctx.failed_optional:
        return None
    rank_why = importance_wait(ctx)
    if rank_why:
        ctx.notes.append(f"importance {e['tag']}: waits, {rank_why}")
        return None
    timing, why = importance_timing(e, ctx)
    if timing is None:
        ctx.notes.append(f"importance {e['tag']}: waits, {why}")
        return None
    return job(f"importance_{e['tag']}", phase, "importance",
               [py(), tool("nf_importance.py"), "run", "--config", C.rel(e["config"]), "--checkpoint",
                C.rel(e["ckpt"]), "--output", C.rel(folder), *importance_args(ctx), *timing],
               gpu=True, optional=True, out=folder / "importance.csv")


def lift_table(entries, roles):
    """The lift's run table: each fit's DS_SELECT downstream predictions (the base raw arm, the one the flag reads)
    with the job-recorded expected hash and the current file hash for reuse (review item 18)."""
    rows = []
    for e, (role, seed) in zip(entries, roles):
        summ = c2("downstream", e["tag"], "summary.json")
        rec = C.read_json(summ) if summ.is_file() else {}
        pred = (rec.get("predictions") or {}).get("base_raw") or \
            C.rel(c2("downstream", e["tag"], "base_raw", "fit", "predictions.parquet"))
        sha = (rec.get("predictions_sha256") or {}).get("base_raw")
        current = C.ROOT / pred
        rows.append({"role": role, "seed": seed, "run": e["tag"], "run_dir": C.rel(e["dir"]),
                     "checkpoint": C.rel(e["ckpt"]), "predictions": pred, "receipt": "", "downstream": pred,
                     "downstream_sha256": sha, "downstream_sha256_required": "yes",   # a missing sha refuses
                     "checkpoint_sha256": C.sha256_file(e["ckpt"]) if e["ckpt"].is_file() else None,
                     "predictions_sha256": C.sha256_file(current) if current.is_file() else None})
    return rows


def downstream_job(e, ctx):
    # nf_downstream.py run writes C2/downstream/<name>/summary.json when every arm is fitted
    out = c2("downstream", e["tag"], "summary.json")
    if out.is_file() or f"downstream_{e['tag']}" in ctx.failed_optional:
        return None
    return job(f"downstream_{e['tag']}", "S.7", "downstream",
               [py(), tool("nf_downstream.py"), "run", "--name", e["tag"], "--run-dir", C.rel(e["dir"]),
                "--config", C.rel(e["config"]), "--checkpoint", C.rel(e["ckpt"])], gpu=True, optional=True)


def log_once(text):
    """DECISIONS.log is appended, never truncated; a planner note is written once."""
    if DRY:
        return
    p = c2("DECISIONS.log")
    if p.is_file() and any(ln.endswith(text) for ln in p.read_text(encoding="utf-8").splitlines()):
        return
    C.append_line(p, f"{C.utc_now()} {text}")


def _write_kept(kept, history):
    sid = ("".join(x.lower() for x in kept["inputs"]) or "base") + ("p" if kept.get("drop_file") else "")
    obj = {"inputs": kept["inputs"], "input_set": sid, "pruned_by": kept.get("drop_file"),
           "month": "out" if kept.get("month_out") else "in", "calendar": kept.get("calendar") or "categorical",
           "runs": {str(k): C.rel(v["dir"]) for k, v in kept["runs"].items()},
           "decided": kept.get("decided", "base"), "history": history}
    p = c2("KEPT.json")
    if not DRY and (not p.is_file() or C.read_json(p) != obj):
        C.write_json(p, obj)


def next_job(ctx=None, dry=False):
    """The next job. With dry=True (the report and `plan`) the walk writes nothing."""
    global DRY
    DRY = dry
    ctx = ctx or Ctx()
    try:
        for j in walk(ctx):
            return j
    except Stop as e:
        return {"id": "stop", "kind": "stop", "reason": str(e)}
    finally:
        DRY = False
    return {"id": "done", "kind": "done", "notes": ctx.notes}


# ------------------------------------------------------------------ preflight (P0)

def a3_switch_state(ctx, df):
    """D4a: STEPS.yaml's A3 switch agrees with the field map: A3 on if and only if FIELD_MAP.csv holds a CONFIRMED
    row of group a3. (ok, detail)."""
    rows = int(((df["group"] == "a3") & (df["list_status"] == "CONFIRMED")).sum())
    on = any(C.step_on(s) for s in ctx.steps.get("steps", []) if s.get("name") == "A3")
    if rows and not on:
        return False, (f"decision D4a: the confirmed list holds {rows} a3 row(s), so set A3 on in STEPS.yaml, or leave "
                       "those rows out of the list")
    if on and not rows:
        return False, "decision D4a: A3 is on in STEPS.yaml, but the confirmed list holds no a3 row: set A3 off"
    return True, (f"A3 on with {rows} confirmed a3 row(s)" if on else "A3 off and no confirmed a3 row")


def preflight():
    ctx = Ctx()
    checks = []

    def add(name, ok, detail=""):
        checks.append({"check": name, "ok": bool(ok), "detail": detail})
    try:
        lay, _ = nf_layout.detect()
        add("layout", True, lay)
    except SystemExit as e:
        add("layout", False, getattr(e, "message", "mixed layout"))
    try:
        import nf_guard
        rc = nf_guard.main([])
        add("guard", rc == C.OK, "source hash equal to stage 0 and the control" if rc == C.OK else f"rc {rc}")
    except Exception as e:  # noqa: BLE001
        add("guard", False, f"{type(e).__name__}: {e}")
    g = c2("guard", "guard.jsonl")
    last = json.loads([x for x in g.read_text(encoding="utf-8").splitlines() if x.strip()][-1]) \
        if g.is_file() and g.read_text(encoding="utf-8").strip() else {}
    # stage 1 must have passed before anything in stage 2 is fit or read, on the retrain path and on the P1 path (D5b)
    add("stage1_checks", last.get("stage1_ok") is True,
        "stage 1's rescore, route, wrapper and same-batch results all passed" if last.get("stage1_ok")
        else "stage 1's result files are missing or did not all pass (see the guard screen)")
    first = first_step_run(ctx)
    if first:
        tj = c2("timing", f"{first}.json")
        verdict = None
        if tj.is_file():
            try:
                verdict = C.read_json(tj).get("verdict")
            except (OSError, ValueError):
                verdict = "unreadable"
        add("first_step_timing", verdict == "OK",
            f"{C.rel(tj)} {'verdict OK' if verdict == 'OK' else 'missing' if verdict is None else repr(verdict)}"
            " (POD.md step 19: the first step's width timing comes before the preflight)")
    probs = microbatch_config_problems(ctx)
    add("microbatch_configs", not probs, "; ".join(probs[:2]) or "every config carries its candidate's micro-batch")
    try:
        ctl = base_control(ctx)
        add("control", True, f"{ctl['label']} {C.rel(ctl['dir'])}")
    except Stop as e:
        add("control", False, str(e))
    # nf_control fits the base refits at seeds 43 and 44 on every path (D5b), and P1 when it runs
    cfgp = C.NF / "configs" / "nf_control.yaml"
    if not cfgp.is_file():
        add("control_batch_plan", False, "nf_control.yaml is missing: run nf_make_configs.py first")
    else:
        try:
            from omegaconf import OmegaConf
            nf_layout.resolve(["trainer"])
            nf_layout.attr("trainer", "check_batch_plan")(OmegaConf.load(cfgp))
            add("control_batch_plan", True, "the trainer's batch plan check passed for nf_control")
        except Exception as e:  # noqa: BLE001
            add("control_batch_plan", False, f"{type(e).__name__}: {e}")
    add("learning_rate_source", str(ctx.settings.get("learning_rate_source") or "").strip(),
        "SETTINGS.yaml learning_rate_source")
    appr = C.blank_approvals(ctx.settings.get("approvals") or {}, ["main_measure", "bar", "check_thresholds",
                                                                   "cluster_threshold"])
    add("approvals", not appr, "blank: " + ", ".join(appr) if appr else "all recorded")
    th = C.settings_hashes().get("CHECK_THRESHOLDS.yaml")
    add("thresholds_unchanged", str(ctx.settings.get("check_thresholds_sha256") or "") == th,
        "SETTINGS.yaml check_thresholds_sha256 equals CHECK_THRESHOLDS.yaml")
    ac = c2("artifact", "artifact_check.json")
    ok_ac, why_ac = artifact_state(C.read_json(ac) if ac.is_file() else None)
    add("artifact_check", ok_ac, f"{C.rel(ac)}: {why_ac}")
    df = C.read_field_map(C.NF / "FIELD_MAP.csv")
    add("map_confirmed", not (df["list_status"] == "UNCONFIRMED").any(), "no UNCONFIRMED row")
    ok_a3, why_a3 = a3_switch_state(ctx, df)
    add("a3_switch", ok_a3, why_a3)
    # D4b: pruning reopens only as the three-seed compression step with a stated reason and allowable loss, which
    # this package does not build yet; the old one-seed prune read is not run on the pod
    p_on = any(C.step_on(st) for st in ctx.steps.get("steps", []) if st.get("kind") == "prune")
    add("prune_step", not p_on, "set step P off: pruning is D4b's compression step, not built" if p_on else
        "pruning off (the reviewers' decision D4b)")
    eng = (df["kind"] == "engineered") & (df["list_status"] == "CONFIRMED")
    if eng.any():
        proofs = sorted(c2("enriched", "identity").rglob("*.json")) if c2("enriched", "identity").is_dir() else []
        bad = [p for p in proofs if not _passed(C.read_json(p))]
        add("enriched_identity", proofs and not bad, f"{len(proofs)} proofs, {len(bad)} failed")
    import nf_make_configs as M
    probs = []
    for p in sorted((C.NF / "configs").glob("*.yaml")) if (C.NF / "configs").is_dir() else []:
        try:
            probs += M.verify_one(p)
        except SystemExit as e:
            probs.append(str(e.code))
    add("configs", not probs, "; ".join(probs[:3]) or "allowed keys only")
    s1 = stage1_control(ctx)
    if s1 and s1[2] and control_lr(s1[1]) == float(ctx.settings["learning_rate"]):
        bp = C.ROOT / ctx.settings.get("base_config", "fraud/configs/sequential_hier_allpos.yaml")
        rp = s1[1] / "resolved_train_v2.yaml"
        if bp.is_file() and rp.is_file():
            d = [k for k, _, _ in C.diff_configs(C.load_yaml(bp), C.load_yaml(rp))
                 if not k.startswith(("output.", "experiment.", "eval.checkpoint"))]
            add("control_config", not d, "differs in " + ", ".join(d[:4]) if d else "equal except output keys")
    found = C.busy(extra_scripts=[(ctx.up.get("stage0") or {}).get("queue_script") or "lr_screen.sh"])
    add("gpu_free", not found, "; ".join(found[:2]) or "nothing running")
    add("process_table", not C.proc_root_note(), C.proc_root_note() or "/proc: every process of the machine")
    try:
        add("rank_check", ctx.rank is not None, "decide on " + (ctx.pop_label() if ctx.rank else "unknown"))
    except Stop as e:       # RANK-B failed and the plan's fallback passed: the owner decides first
        add("rank_check", False, str(e))
    ok = all(c["ok"] for c in checks)
    C.write_json(c2("reads", "preflight.json"), {"utc": C.utc_now(), "ok": ok, "checks": checks,
                                                 "settings": C.settings_hashes()})
    C.print_screen(f"PREFLIGHT  {'PASS' if ok else 'STOP'}  {C.utc_now()}",
                   [f"{'ok  ' if c['ok'] else 'STOP'} {c['check']:<22} {c['detail']}" for c in checks],
                   footer="saved: " + C.rel(c2("reads", "preflight.json")))
    return C.OK if ok else C.STOP


# ------------------------------------------------------------------ queue

LOCK_WAIT_SECONDS = 2.0    # a lock file another start has just made holds its record within this time


def _create_exclusive(path, record):
    """Make the file only if no file of that name exists (O_CREAT | O_EXCL, one atomic step), with the record in
    it. False when it exists."""
    data = (json.dumps(record, indent=2, sort_keys=True, default=str) + "\n").encode("utf-8")
    try:
        fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    except FileExistsError:
        return False
    try:
        view = memoryview(data)
        while view:
            view = view[os.write(fd, view):]
        os.fsync(fd)
    finally:
        os.close(fd)
    return True


def _lock_snapshot(path):
    """(identity, record) of a lock file as it is now: identity is its device, inode and bytes, read through one
    open file; record is the JSON object, or None while it is empty or unreadable. None when there is no file. A
    file another start has just made is empty for a moment, so an unreadable one is read again for up to
    LOCK_WAIT_SECONDS."""
    deadline = time.monotonic() + LOCK_WAIT_SECONDS
    while True:
        try:
            fd = os.open(str(path), os.O_RDONLY)
        except FileNotFoundError:
            return None
        try:
            st = os.fstat(fd)
            chunks = []
            while True:
                b = os.read(fd, 1 << 16)
                if not b:
                    break
                chunks.append(b)
        finally:
            os.close(fd)
        raw = b"".join(chunks)
        try:
            rec = json.loads(raw.decode("utf-8"))
        except ValueError:
            rec = None
        if not (isinstance(rec, dict) and "pid" in rec and "hostname" in rec):
            rec = None
        if rec is not None or time.monotonic() >= deadline:
            return (st.st_dev, st.st_ino, raw), rec
        time.sleep(0.05)


def acquire_lock(pid):
    """The queue's lock, QUEUE.lock.json: {pid, hostname, utc}. One owner at a time, also when two queues start at
    the same moment. The lock is made only if it does not exist (O_CREAT | O_EXCL). A lock whose owner runs on this
    host refuses the start. The project folder is shared by the owner's workbenches: a lock or a takeover claim
    that names another workbench is never replaced, and the start refuses (exit 4) naming that workbench; remove
    it by hand only after checking on that workbench that no queue runs there. A lock of this host whose process
    is dead is replaced by renaming a fresh record over it, by one starter only: each starter first makes a claim
    file named after that exact stale lock, again only if absent, then checks the lock is still that stale one.
    This needs a POSIX file system for the checkpoints folder: the workbenches' shared volume is one, an S3 or
    object-store mount is not (POD.md step 21)."""
    p = c2(LOCK)
    host = socket.gethostname()
    mine = {"pid": pid, "hostname": host, "utc": C.utc_now()}
    p.parent.mkdir(parents=True, exist_ok=True)
    for _ in range(5):
        if _create_exclusive(p, mine):
            return p
        snap = _lock_snapshot(p)
        if snap is None:
            continue            # its owner removed it between the two steps: try to make it again
        ident, held = snap
        if held is None:
            raise Stop(f"{C.rel(p)} cannot be read (empty or not a lock record): if no queue runs, remove it and "
                       "start again")
        h = other_host(held)
        if h is not None:
            raise Stop(f"{C.rel(p)} names another workbench, {h} (pid {held.get('pid')} since {held.get('utc')}): "
                       f"run the queue on one workbench only; if no queue runs on {h}, remove {C.rel(p)} and start "
                       "again")
        held_pid = lock_pid(held)       # zero, below zero, too large or not a number: no process to wait for
        if held_pid is None:
            raise Stop(f"{C.rel(p)} names no process (pid {held.get('pid')!r}): if no queue runs, remove it and "
                       "start again")
        ours = held.get("hostname") == host and held_pid == pid
        if owner_alive(held) and not ours:
            raise Stop(f"another queue holds {C.rel(p)} (pid {held.get('pid')} since {held.get('utc')})")
        # its owner does not run (or it is this queue's own record): replace it, one starter only
        tag = hashlib.sha256(f"{ident[0]}:{ident[1]}:".encode() + ident[2]).hexdigest()[:16]
        claim = p.with_name(f".{p.name}.takeover-{tag}")
        if not _create_exclusive(claim, mine):
            snap_c = _lock_snapshot(claim)
            now = _lock_snapshot(p)
            if snap_c is None or now is None or now[0] != ident:
                continue        # the other start has replaced it, or the lock changed: look again
            other = snap_c[1]
            h = other_host(other)
            if h is not None:
                raise Stop(f"{C.rel(claim)} names another workbench, {h} (pid {other.get('pid')} since "
                           f"{other.get('utc')}), replacing {C.rel(p)}: run the queue on one workbench only; if no "
                           f"queue runs on {h}, remove {C.rel(claim)} and start again")
            if other is not None and owner_alive(other):
                raise Stop(f"another queue is starting (pid {other.get('pid')}): it is replacing {C.rel(p)} left by "
                           f"pid {held.get('pid')}")
            raise Stop(f"a start that was replacing {C.rel(p)} (left by pid {held.get('pid')}) did not finish: if "
                       f"no queue runs, remove {C.rel(p)} and {C.rel(claim)} and start again")
        try:
            now = _lock_snapshot(p)
            if now is None or now[0] != ident:
                continue        # another start replaced it first: look again
            C.write_json(p, mine)       # a fresh record renamed over the stale one (atomic)
        finally:
            try:
                claim.unlink()
            except OSError:
                pass
        if not ours:
            C.append_line(c2("queue.log"), f"lock: replaced {C.rel(p)} left by pid {held.get('pid')} on "
                                           f"{held.get('hostname')} since {held.get('utc')}, which no longer runs "
                                           f"{C.utc_now()}")
        return p
    raise Stop(f"{C.rel(p)} kept changing while this start read it: start again")


def queue(args):
    qlog = c2("queue.log")
    C.out("logs", "x").parent.mkdir(parents=True, exist_ok=True)
    pid = args.queue_pid or os.getppid()
    try:
        lock = acquire_lock(pid)
    except Stop as e:
        C.append_line(qlog, f"refused {e} {C.utc_now()}")
        C.say(str(e))                   # wrapped at 90 characters, to the error stream
        return C.REFUSED
    rc, phase, partial, done_jobs, last_ok = C.OK, "P0", False, 0, None
    try:
        if not args.skip_preflight:
            C.append_line(qlog, f"start preflight {C.utc_now()}")
            prc = preflight()
            C.append_line(qlog, f"end preflight rc={prc} {C.utc_now()}")
            if prc != C.OK:
                rc = C.STOP
                return rc
        while True:
            ctx = Ctx()
            j = next_job(ctx)
            if j["kind"] == "done":
                for n in j.get("notes") or []:
                    C.append_line(qlog, f"note: {n} {C.utc_now()}")
                waits = any(" WAITS:" in n or n.startswith(("P WAITS", "WAIT")) for n in j.get("notes") or [])
                rc = C.PARTIAL if partial or ctx.failed_optional or waits else C.OK
                break
            if j["kind"] == "stop":
                C.append_line(qlog, f"stop: {j['reason']} {C.utc_now()}")
                C.append_line(c2("DECISIONS.log"), f"{C.utc_now()} STOP {j['reason']}")
                rc = C.STOP
                break
            phase = j["phase"]
            if j["id"] == last_ok:
                # the job exited 0 but did not write the output the plan looks for: never run it again in a loop
                why = f"{j['id']} exited 0 but did not write its expected output"
                C.append_line(qlog, f"no output: {why} {C.utc_now()}")
                if j["optional"]:
                    st = C.read_json(c2("queue_state.json")) if c2("queue_state.json").is_file() else {}
                    st.setdefault("failed_optional", []).append(j["id"])
                    C.write_json(c2("queue_state.json"), st)
                    partial = True
                    last_ok = None
                    continue
                C.append_line(c2("DECISIONS.log"), f"{C.utc_now()} STOP {why}")
                rc = C.STOP
                break
            if j["gpu"]:
                found = C.busy(extra_scripts=[(ctx.up.get("stage0") or {}).get("queue_script") or "lr_screen.sh"])
                if found:
                    C.append_line(qlog, f"refused {j['id']}: busy: {'; '.join(found)} {C.utc_now()}")
                    rc = C.REFUSED
                    break
            C.append_line(qlog, f"start {j['id']} {C.utc_now()}")
            env = dict(os.environ)
            if not j["gpu"]:
                env["CUDA_VISIBLE_DEVICES"] = ""
            Path(j["log"]).parent.mkdir(parents=True, exist_ok=True)
            with open(j["log"], "a", encoding="utf-8") as lf:
                lf.write(f"# {C.utc_now()} {' '.join(j['cmd'])}\n")
                lf.flush()
                jrc = subprocess.call(j["cmd"], cwd=C.ROOT, stdout=lf, stderr=subprocess.STDOUT, env=env)
            C.append_line(qlog, f"end {j['id']} rc={jrc} {C.utc_now()}")
            if j["kind"] == "read" and jrc == 0:
                p = Path(j["cmd"][j["cmd"].index("--out") + 1])
                p = p if p.is_absolute() else C.ROOT / p
                if p.suffix == ".json" and p.is_file():
                    C.append_line(c2("DECISIONS.log"),
                                  f"{C.utc_now()} {j['id']} {C.read_json(p).get('decision', '')}")
            last_ok = j["id"] if jrc == 0 else None
            if jrc != 0:
                if j["optional"]:
                    st = C.read_json(c2("queue_state.json")) if c2("queue_state.json").is_file() else {}
                    st.setdefault("failed_optional", []).append(j["id"])
                    C.write_json(c2("queue_state.json"), st)
                    partial = True
                    continue
                rc = jrc if jrc in (C.ARGS, C.STOP, C.REFUSED) else C.CRASH
                break
            done_jobs += 1
            if args.max_jobs and done_jobs >= args.max_jobs:
                break
    except Stop as e:
        C.append_line(qlog, f"stop: {e} {C.utc_now()}")
        rc = C.STOP
    except Exception as e:  # noqa: BLE001
        C.append_line(qlog, f"crash: {type(e).__name__}: {e} {C.utc_now()}")
        import traceback
        traceback.print_exc()
        rc = C.CRASH
    finally:
        C.append_line(qlog, f"queue end rc={rc} at {phase}; report: checkpoints/new_fields/REPORT.txt")
        try:
            if C.read_json(lock).get("pid") == pid:
                lock.unlink()
        except (OSError, ValueError):
            pass
    return rc


# ------------------------------------------------------------------ main

def main(argv=None):
    ap = argparse.ArgumentParser(description="planner and queue")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("preflight")
    sub.add_parser("next")
    sub.add_parser("plan")
    sub.add_parser("busy")
    q = sub.add_parser("queue")
    q.add_argument("--queue-pid", type=int, help="the queue shell's pid, recorded in QUEUE.lock.json")
    q.add_argument("--skip-preflight", action="store_true", help="tests only")
    q.add_argument("--max-jobs", type=int, default=0)
    args = ap.parse_args(argv)
    try:
        if args.cmd == "preflight":
            return preflight()
        if args.cmd == "next":
            j = next_job()
            print(json.dumps(j))
            return C.STOP if j["kind"] == "stop" else C.OK
        if args.cmd == "plan":
            j = next_job(dry=True)
            lines = [f"next: {j['id']} ({j.get('phase', '')})", *(j.get("notes") or []),
                     j.get("reason", "") or " ".join(j.get("cmd", []))[:200]]
            kp = c2("KEPT.json")
            if kp.is_file():
                k = C.read_json(kp)
                lines.append(f"kept inputs: {k['input_set']}")
                lines += [f"  {h}" for h in k.get("history", [])]
            C.print_screen("PLAN  " + C.utc_now(), lines)
            return C.OK
        if args.cmd == "busy":
            up = C.upstream() if (C._settings_dir() / "UPSTREAM.yaml").is_file() else {}
            found = C.busy(extra_scripts=[(up.get("stage0") or {}).get("queue_script") or "lr_screen.sh"])
            print("\n".join(found) if found else "free")
            if C.proc_root_note():
                print(C.proc_root_note())
            return C.REFUSED if found else C.OK
        if args.cmd == "queue":
            return queue(args)
    except SystemExit as e:
        if isinstance(e.code, str):
            print(e.code, file=sys.stderr)
            return C.REFUSED
        return e.code
    return C.ARGS


if __name__ == "__main__":
    sys.exit(main())
