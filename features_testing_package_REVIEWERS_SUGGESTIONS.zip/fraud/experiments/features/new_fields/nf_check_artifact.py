"""Check of the extended artifact (design 4.5). One screen; C2/artifact/artifact_check.json; exit 3 unless every
line passes.

Lines:
- every file of version 1 has a file of the same name and SHA-256 in the extended version
  ("base fields byte-identical: 23/23", and the count of all version 1 files);
- every new field's file equals its scratch file byte for byte, or, for a capped code field (the reviewers'
  decision D9-Y20), the recorded capped file, with contiguous codes from 2 and a cardinality of kept values + 2;
  optional cyclical-calendar fields equal their files in the calendar scratch version;
- the extended manifest lists exactly version 1's features plus the new and optional calendar ones, and version
  1's fit files;
- the extended version loads with the unchanged PreprocessingArtifacts.load;
- the base predictors' payload digest in the extended version equals the digest stored in the kept seed 42, 43
  and 44 checkpoints and in the control checkpoint (read on CPU). A checkpoint not on disk yet is listed as
  WAIT, and the check must run again once it exists: the planner's preflight requires a PASS with every
  checkpoint read;
- the first 10,000 rows of training file 1 encode to identical arrays for every base field under both versions;
- each month-out list equals its month-in list minus exactly the month line (C2/artifact and NF/predictors);
- each new code field's vocabulary size before the cap equals the one the CPU checks measured
  (field_checks.csv), when they wrote one.
An information line (no pass or fail) gives version 1's month vocabulary (months and indexes), whether any of the
first 10,000 rows of training file 1 encodes month to the unknown index 0, and the index a June value encodes to
(the reviewers' decision D4c).

Options, information only and used by no run: --diagnostic-refit refits every field into a diagnostic version and
lists the base fields whose bytes differ from version 1; --time-encoding times the encoding of one full training
file at the full new width and reports the peak memory (design review item 17).
"""

from __future__ import annotations

import argparse
import json
import resource
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path(__file__).resolve().parents[4]
for _p in (str(HERE), str(ROOT / "src"), str(ROOT)):
    if _p in sys.path:
        sys.path.remove(_p)
    sys.path.insert(0, _p)

ENCODE_ROWS = 10_000


def _parser():
    p = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    p.add_argument("--hashes", default=None, help="artifact_hashes.json (default C2/artifact/artifact_hashes.json)")
    p.add_argument("--predictors-dir", default=None, help="step lists (default NF/predictors)")
    p.add_argument("--field-checks", default=None, help="field_checks.csv (default C2/checks/field_checks.csv)")
    p.add_argument("--checkpoints", nargs="*", default=None,
                   help="checkpoints whose digest must match (default the kept seeds and the control, UPSTREAM.yaml)")
    p.add_argument("--train-file", default=None, help="training file 1 (default the chosen config's train base)")
    p.add_argument("--cred-path", default=None)
    p.add_argument("--diagnostic-refit", action="store_true")
    p.add_argument("--time-encoding", action="store_true")
    return p


def _default_checkpoints(C):
    up = C.upstream() or {}
    kept = Path((up.get("kept") or {}).get("dir") or "models/sequential_hier_allpos_h20_chunk")
    out = [(f"kept seed {s}", C.ROOT / kept / f"seed{s}" / "best.ckpt") for s in (42, 43, 44)]
    ctrl = (up.get("stage1") or {}).get("control_dir")
    if ctrl:
        out.append(("control", C.ROOT / ctrl / "best.ckpt"))
    return out


def encode_all(art, df, names, dtf, dcfg):
    """Every base field encoded as the sequence builder encodes it (median fill and standardise; vocabulary)."""
    import numpy as np
    d = df.copy()
    if any(art.features[n].get("type") == "categorical" and n not in d.columns for n in names):
        d, _, _ = dtf.derive_datetime_features(d, dcfg)
    out = {}
    for n in names:
        if art.features[n]["type"] == "continuous":
            out[n] = art.standardize_continuous(n, d[n])
        else:
            out[n] = art.encode_categorical(n, d[n])
    return {k: np.asarray(v) for k, v in out.items()}


def month_vocabulary(a1, encoded, dtf, dcfg):
    """Version 1's month vocabulary, whether a training row encodes month to the unknown index 0, and the index a
    June value encodes to (the reviewers' decision D4c; information, no pass or fail)."""
    import pandas as pd
    if "month" not in a1.features or "month" not in encoded:
        return None
    vocab = a1.features["month"]["vocab"]
    probe = pd.DataFrame({dcfg.order_col: pd.to_datetime(["2025-06-15 12:00:00"])})
    derived, _, _ = dtf.derive_datetime_features(probe, dcfg)
    june = int(a1.encode_categorical("month", derived["month"])[0]) if "month" in derived else None
    zero = int((encoded["month"] == 0).sum())
    pairs = ", ".join(f"{k}:{v}" for k, v in sorted(vocab.items(), key=lambda kv: kv[1]))
    return {"vocab": vocab, "train_rows_at_0": zero, "june_index": june,
            "line": f"INFO  month vocabulary of version 1: {pairs}; training rows at index 0: {zero}; a June "
                    f"value encodes to {june}"}


def diagnostic_refit(C, A, io, store, rec, cred):
    """Refit every field (base and new) with the unchanged builder into <extended>_diag; list the base fields
    whose file bytes differ from version 1. Information only: no run reads this version."""
    import yaml
    import nf_build_artifact as B
    version = f"{rec['extended']}_diag"
    root = A.version_root(rec["art"], version)
    if store.listdir(root):
        return {"version": version, "error": f"{version} already exists; not refit"}
    m1 = A.read_manifest(store, A.version_root(rec["art"], rec["version1"]))
    start, end = A.fit_range(m1["fit_files"])
    pre = C.load_yaml(C.ROOT / "fraud/configs/preprocessing.yaml")
    fit_base = next(iter(rec["fit"].values()))["base"]
    cfg = {"predictors": {"csv_path": str(C.out("artifact", "predictors_all_month_in.csv")), "version": None},
           "data": {"base": fit_base, "file_start": start, "file_end": end,
                    "order_col": (pre.get("data") or {}).get("order_col", "transaction_dttm")},
           "datetime": pre.get("datetime"),
           "build": {"features_per_batch": int((pre.get("build") or {}).get("features_per_batch", 5)),
                     "artifact_version": version, "output_base": rec["art"]},
           "s3": {"cred_path": cred}}
    path = C.out("artifact", "preprocessing_diagnostic.yaml")
    path.write_text(yaml.safe_dump(cfg, sort_keys=False))
    rc = B.run_builder(path)
    if rc != 0:
        return {"version": version, "error": f"builder exited {rc}"}
    hd = A.file_hashes(store, root)
    h1 = rec["files"]["version1"]
    differ = [n for n in rec["base_predictors"] if hd.get(f"feature__{n}.json") != h1.get(f"feature__{n}.json")]
    return {"version": version, "differ": differ, "note": "information only; used by no run"}


def main(argv=None) -> int:
    args = _parser().parse_args(argv)
    import nf_layout
    nf_layout.bootstrap()
    import numpy as np
    import nf_common as C
    import nf_data_artifact as A
    import nf_data_io as io

    hashes_path = Path(args.hashes) if args.hashes else C.out("artifact", "artifact_hashes.json")
    if not hashes_path.exists():
        C.say(f"refused: {C.rel(hashes_path)} is missing; run nf_build_artifact.py first (exit 4)", file=sys.stderr)
        return C.REFUSED
    rec = json.loads(hashes_path.read_text())
    settings = C.settings()
    cfg = C.load_yaml(C.ROOT / settings.get("base_config", "fraud/configs/sequential_hier_allpos.yaml")) \
        if args.train_file is None or args.cred_path is None else {}
    cred = args.cred_path or (cfg.get("s3") or {}).get("cred_path")
    store = io.Store(cred)
    art, v1, scratch, target = rec["art"], rec["version1"], rec["scratch"], rec["extended"]
    v1_root, scr_root, ext_root = (A.version_root(art, v) for v in (v1, scratch, target))
    base = rec["base_predictors"]
    new = rec["new_fields"]
    calendar = (rec.get("calendar_cyclical") or {}).get("fields") or []
    added = new + calendar
    lines, result, info_lines = [], {}, []
    month_info = None

    def line(key, ok, text):
        status = "PASS" if ok is True else ("WAIT" if ok is None else "FAIL")
        result[key] = {"result": status, "text": text}
        lines.append(f"{status:4s}  {text}")

    # 1. version 1 files byte-identical
    h1 = A.file_hashes(store, v1_root)
    he = A.file_hashes(store, ext_root)
    same = [n for n in h1 if n != A.MANIFEST and he.get(n) == h1[n]]
    base_same = [n for n in base if he.get(f"feature__{n}.json") == h1.get(f"feature__{n}.json") is not None]
    n_v1 = len([n for n in h1 if n != A.MANIFEST])
    line("base_identical", len(base_same) == len(base) and len(same) == n_v1,
         f"base fields byte-identical: {len(base_same)}/{len(base)} (all version 1 files {len(same)}/{n_v1})")
    # 2. new files equal scratch
    hs = A.file_hashes(store, scr_root)
    capped = rec.get("capped") or {}

    def new_ok(n):
        name = f"feature__{n}.json"
        if n not in capped:
            return he.get(name) == hs.get(name) is not None
        c = capped[n]
        if he.get(name) != c.get("capped_sha256") or hs.get(name) != c.get("as_fit_sha256"):
            return False
        e = json.loads(store.read_bytes(io.join(ext_root, name)))
        codes = sorted(e["vocab"].values())
        return codes == list(range(2, 2 + len(codes))) and e["cardinality"] == len(codes) + 2 == c["kept"] + 2
    new_same = [n for n in new if new_ok(n)]
    line("new_equal_scratch", len(new_same) == len(new), f"new fields equal their scratch files (capped code "
         f"fields their recorded capped file, {len(capped)}): {len(new_same)}/{len(new)}")
    if calendar:
        hc = A.file_hashes(store, A.version_root(art, f"{scratch}_calendar"))
        cal_same = [n for n in calendar if he.get(f"feature__{n}.json") == hc.get(f"feature__{n}.json") is not None]
        line("calendar_equal_scratch", len(cal_same) == len(calendar),
             f"calendar fields equal their calendar scratch files: {len(cal_same)}/{len(calendar)}")
    # 3. manifest
    m1, me = A.read_manifest(store, v1_root), A.read_manifest(store, ext_root)
    want = sorted(set(m1["features"]) | set(added))
    ok_man = me["features"] == want and list(me["fit_files"]) == list(m1["fit_files"]) and \
        not (set(m1["features"]) & set(added)) and not (set(new) & set(calendar))
    line("manifest", ok_man, f"manifest: {len(m1['features'])} + {len(added)} features; fit files as version 1 "
         f"({len(m1['fit_files'])})")
    extra_files = sorted(set(he) - set(h1) - {f"feature__{n}.json" for n in added})
    line("no_extra_files", not extra_files, f"no other file in the extended version: {extra_files[:3] or 'none'}")
    # 4. loads unchanged
    pre_mod = nf_layout.get("preprocessing")
    try:
        ext = pre_mod.PreprocessingArtifacts.load(ext_root, filesystem=store.fs(ext_root))
        a1 = pre_mod.PreprocessingArtifacts.load(v1_root, filesystem=store.fs(v1_root))
        line("loads", True, f"loads with the unchanged PreprocessingArtifacts.load ({len(ext.features)} features)")
    except Exception as e:  # noqa: BLE001 (any load failure is the finding)
        line("loads", False, f"load failed: {type(e).__name__}: {e}")
        ext = a1 = None
    # 5. payload digests
    if ext is not None:
        d_ext = A.payload_digest(ext, base)
        d_v1 = A.payload_digest(a1, base)
        line("digest_v1", d_ext == d_v1 == rec["payload_sha256"]["base"],
             f"base payload digest equal in version 1 and extended: {d_ext[:16]}")
        cks = [(f"{Path(p).parent.name}/{Path(p).name}", Path(p)) for p in args.checkpoints] \
            if args.checkpoints is not None \
            else _default_checkpoints(C)
        for label, p in cks:
            if not p.exists():
                line(f"ckpt_{label}", None, f"{label}: no checkpoint at {C.rel(p)} yet; run this check again")
                continue
            d = A.checkpoint_digest(p)
            line(f"ckpt_{label}", d == d_ext, f"{label}: stored digest {str(d)[:16]} "
                 f"{'equals' if d == d_ext else 'DIFFERS FROM'} the extended base digest")
    # 6. encoding of training file 1
    dtf = nf_layout.get("datetime_features")
    if ext is not None:
        tf = args.train_file or io.join(cfg["data"]["train_base"], "part_1.parquet")
        pre_cfg = C.load_yaml(C.ROOT / "fraud/configs/preprocessing.yaml")
        dt = pre_cfg.get("datetime") or {}
        dcfg = dtf.DatetimeConfig(order_col=(pre_cfg.get("data") or {}).get("order_col", "transaction_dttm"),
                                  fields=list(dt.get("fields", [])), encoding=dt.get("encoding", "categorical"),
                                  is_weekend=bool(dt.get("is_weekend", False)))
        raw_cols = []
        for n in base:
            if n in dcfg.fields:
                if dcfg.order_col not in raw_cols:
                    raw_cols.append(dcfg.order_col)
            elif n not in raw_cols:
                raw_cols.append(n)
        tbl = store.read_table(tf, raw_cols).slice(0, ENCODE_ROWS)
        df = tbl.to_pandas()
        e1, e2 = encode_all(a1, df, base, dtf, dcfg), encode_all(ext, df, base, dtf, dcfg)
        diff = [n for n in base if not np.array_equal(e1[n], e2[n])]
        line("encode", not diff, f"first {len(df)} rows of training file 1 encode identically: "
             f"{len(base) - len(diff)}/{len(base)}{' differ: ' + ', '.join(diff[:5]) if diff else ''}")
        month_info = month_vocabulary(a1, e1, dtf, dcfg)
        if month_info:
            info_lines.append(month_info["line"])
    # 7. month switch lists
    pairs = [(C.out("artifact", "predictors_all_month_in.csv"), C.out("artifact", "predictors_all_month_out.csv"))]
    pdir = Path(args.predictors_dir) if args.predictors_dir else C.NF / "predictors"
    if pdir.is_dir():
        for p in sorted(pdir.glob("*_month_in.csv")):
            pairs.append((p, p.with_name(p.name.replace("_month_in.csv", "_month_out.csv"))))
    bad = [C.rel(a) for a, b in pairs if not (a.exists() and b.exists() and A.month_out_ok(a.read_bytes(),
                                                                                             b.read_bytes()))]
    line("month_switch", not bad, f"month-out lists equal month-in minus the month line: "
         f"{len(pairs) - len(bad)}/{len(pairs)}{' bad: ' + ', '.join(bad[:3]) if bad else ''}")
    # 8. vocabulary sizes against the CPU checks
    fc = Path(args.field_checks) if args.field_checks else C.out("checks", "field_checks.csv")
    cats = [n for n in new if ext is not None and ext.features[n]["type"] == "categorical"]
    if fc.exists() and cats:
        import pandas as pd
        t = pd.read_csv(fc, dtype=str, keep_default_na=False)
        col = next((c for c in ("vocab_size", "vocab_fit", "vocabulary_size") if c in t.columns), None)
        name_col = next((c for c in ("field", "name") if c in t.columns), None)
        if col and name_col:
            measured = {}
            for _, r in t.iterrows():
                if r[col] not in ("", "nan"):
                    measured.setdefault(r[name_col], set()).add(int(float(r[col])))
            size = {n: (capped[n]["as_fit"] if n in capped else ext.features[n]["n_categories"]) for n in cats}
            off = [n for n in cats if n in measured and size[n] not in measured[n]]
            seen = [n for n in cats if n in measured]
            line("vocab", not off and len(seen) == len(cats),
                 f"new code fields' vocabulary sizes equal the checks': {len(seen) - len(off)}/{len(cats)}"
                 f"{' differ: ' + ', '.join(off[:5]) if off else ''}")
        else:
            line("vocab", None, f"{C.rel(fc)} holds no vocabulary size column; not compared")
    elif cats:
        line("vocab", None, f"{C.rel(fc)} not found; vocabulary sizes not compared")
    # options
    info = {}
    if month_info:
        info["month_vocabulary"] = {k: v for k, v in month_info.items() if k != "line"}
    if args.time_encoding and ext is not None:
        tf = args.train_file or io.join(cfg["data"]["train_base"], "part_1.parquet")
        full = list(dict.fromkeys(raw_cols + new))
        t0 = time.time()
        d = store.read_table(tf, [c for c in full if c in store.schema(tf).names]).to_pandas()
        t1 = time.time()
        encode_all(ext, d, base + [n for n in new if n in d.columns], dtf, dcfg)
        t2 = time.time()
        info["time_encoding"] = {"rows": len(d), "read_s": round(t1 - t0, 2), "encode_s": round(t2 - t1, 2),
                                 "peak_rss_mb": round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024, 1),
                                 "fields": len(base) + len(new)}
        lines.append(f"INFO  encoding one training file at {len(base) + len(new)} fields: "
                     f"{info['time_encoding']['encode_s']} s, peak {info['time_encoding']['peak_rss_mb']} MB")
    if args.diagnostic_refit:
        info["diagnostic_refit"] = diagnostic_refit(C, A, io, store, rec, cred)
        d = info["diagnostic_refit"]
        lines.append(f"INFO  diagnostic refit {d.get('version')}: base fields whose bytes differ from version 1: "
                     f"{len(d.get('differ', []))}/{len(base)} {', '.join(d.get('differ', [])[:4])}"
                     if "differ" in d else f"INFO  diagnostic refit: {d.get('error')}")
    lines.extend(info_lines)
    fails = [k for k, v in result.items() if v["result"] == "FAIL"]
    waits = [k for k, v in result.items() if v["result"] == "WAIT"]
    overall = "FAIL" if fails else ("WAIT" if waits else "PASS")
    C.write_json(C.out("artifact", "artifact_check.json"), {
        "result": overall, "lines": result, "info": info, "extended": target, "version1": v1,
        "hashes_sha256": C.sha256_file(hashes_path), "utc": C.utc_now()})
    C.print_screen(f"ARTIFACT CHECK  {overall}  {target} against version {v1}", lines,
                   f"full record: {C.rel(C.out('artifact', 'artifact_check.json'))}")
    return C.OK if overall == "PASS" else C.STOP


if __name__ == "__main__":
    sys.exit(main())
