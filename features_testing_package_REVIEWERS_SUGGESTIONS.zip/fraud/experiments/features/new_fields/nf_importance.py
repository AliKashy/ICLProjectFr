"""Measure fixed-model sensitivity on RANK-A; never select a model or drop a field."""
from __future__ import annotations

import argparse
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import textwrap
import time

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]

import numpy as np
import pandas as pd
from omegaconf import OmegaConf

from nf_importance_metrics import summarize_unit
from nf_importance_units import UNIT_CHOICES, build_units, make_recompute, non_account_keys


def _shared():
    import nf_common
    import nf_layout
    nf_layout.bootstrap()
    return nf_common, nf_layout


def _utc():
    return datetime.now(timezone.utc).isoformat()


def _plain(value):
    """JSON null for an undefined statistic, with reasons in the adjacent fields."""
    if isinstance(value, dict):
        return {str(k): _plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, np.ndarray)):
        return [_plain(v) for v in value]
    if isinstance(value, (np.integer, np.bool_)):
        return value.item()
    if isinstance(value, (float, np.floating)):
        return float(value) if math.isfinite(value) else None
    if isinstance(value, Path):
        return str(value)
    return value


def estimate_cost(rows, unit_count, repeats, seconds_per_row, account_share=1.0):
    """The share estimates rows, not an exact row fraction for unequal-size accounts."""
    if rows < 1 or unit_count < 0 or repeats < 1:
        raise ValueError("rows and repeats must be positive; unit count must be nonnegative")
    if not math.isfinite(seconds_per_row) or seconds_per_row <= 0:
        raise ValueError("seconds per row must be a positive measured value")
    if not math.isfinite(account_share) or not 0 < account_share <= 1:
        raise ValueError("account share must be in (0, 1]")
    passes = 1 + unit_count * repeats
    seconds = passes * rows * account_share * seconds_per_row
    return dict(scoring_passes=passes, full_rank_a_rows=rows,
                estimated_selected_rows=rows * account_share,
                seconds_per_row=seconds_per_row, gpu_hours=seconds / 3600,
                null_check_extra_passes=2,
                note="Estimate excludes two one-file null checks and CPU statistics. "
                     "Account sampling gives a variable row count; measured cost is also recorded.")


def _rank_a_files(settings):
    """Read the designated range; the existing importance scorer measures June."""
    if settings.get("importance", {}).get("population", "rank_a") != "rank_a":
        raise ValueError("importance uses the designated RANK-A population only")
    try:
        population = settings["populations"]["rank_a"]
        files = population["files"]
        if len(files) != 2:
            raise ValueError
        start, end = (int(x) for x in files)
        if start < 1 or end < start or any(float(x) != int(x) for x in files):
            raise ValueError
        targets = tuple(pd.Timestamp(x) for x in population["targets"])
    except (KeyError, TypeError, ValueError, OverflowError) as error:
        raise ValueError("RANK-A needs an ordered file range and target interval in SETTINGS.yaml") from error
    if targets != (pd.Timestamp("2025-06-01"), pd.Timestamp("2025-07-01")):
        raise ValueError("importance measures June targets: RANK-A targets must be 2025-06-01 to 2025-07-01")
    return start, end


def enforce_rank_a(cfg, settings=None):
    if settings is None:
        import nf_common
        settings = nf_common.settings()
    expected = _rank_a_files(settings)
    start, end = int(cfg.eval.file_start), int(cfg.eval.file_end)
    if (start, end) != expected:
        raise ValueError(f"importance uses designated RANK-A files {expected[0]}-{expected[1]} only")


def assert_same_scores(plain, identity):
    """The null check compares all rows, including history months, in their exact order."""
    if plain.empty or identity.empty:
        raise ValueError("null check has no scored rows")
    fields = [c for c in plain.columns if c != "score"]
    if list(plain.columns) != list(identity.columns):
        raise ValueError("identity pass columns changed")
    pd.testing.assert_frame_equal(plain[fields], identity[fields], check_exact=True)
    a, b = plain.score.to_numpy(), identity.score.to_numpy()
    if a.dtype != b.dtype or a.tobytes() != b.tobytes():
        raise ValueError("identity permutation did not give bitwise-equal scores")


def align_pass(reference, candidate):
    """Align by transaction identity, then verify immutable evaluation data."""
    keys = ["account", "id"]
    for frame in (reference, candidate):
        if frame[keys].isna().any().any() or frame.duplicated(keys).any():
            raise ValueError("scored identities must be complete and unique")
    ref = reference.set_index(keys)
    got = candidate.set_index(keys)
    if len(ref) != len(got) or not ref.index.isin(got.index).all():
        raise ValueError("permutation changed the scored target population")
    got = got.reindex(ref.index)
    fixed = [c for c in ref.columns if c != "score"]
    pd.testing.assert_frame_equal(ref[fixed], got[fixed], check_exact=True)
    if not np.isfinite(got.score.to_numpy()).all():
        raise ValueError("non-finite scores")
    return got.score.to_numpy()


def _order_hash(frame):
    encoded = "\n".join(json.dumps([str(a), str(i)]) for a, i in
                        frame[["account", "id"]].itertuples(index=False, name=None))
    return hashlib.sha256(encoded.encode()).hexdigest()


def _slug(text):
    return re.sub(r"[^a-zA-Z0-9_.-]+", "_", str(text))[:70] + "_" + hashlib.sha256(str(text).encode()).hexdigest()[:8]


def _timing(args):
    data = {}
    if args.timing:
        data = json.loads(Path(args.timing).read_text())
    seconds = args.seconds_per_row or data.get("seconds_per_row")
    if seconds is None and all(k in data for k in ("started_utc", "ended_utc")):
        duration = (datetime.fromisoformat(data["ended_utc"].replace("Z", "+00:00")) -
                    datetime.fromisoformat(data["started_utc"].replace("Z", "+00:00"))).total_seconds()
        measured_rows = data.get("n_predictions", data.get("rows"))
        if measured_rows:
            seconds = duration / int(measured_rows)
    rows = args.rank_a_rows or data.get("rank_a_rows")
    if seconds is None or rows is None:
        raise ValueError("supply measured --seconds-per-row and full-file --rank-a-rows, "
                         "or a --timing JSON with seconds_per_row and rank_a_rows")
    return int(rows), float(seconds)


def _plan(cfg, args, layout, units=None):
    fs = None
    if cfg.s3.get("cred_path"):
        fs = layout.attr("s3", "make_s3_filesystem")(cfg.s3.cred_path)
    features = layout.attr("feature_list", "load_feature_list")(
        cfg.predictors.csv_path, version=cfg.predictors.version, filesystem=fs)
    names = list(features.continuous) + list(features.categorical)
    field_map = pd.read_csv(args.field_map, dtype=str).fillna("") if args.field_map else None
    clusters = pd.read_csv(args.clusters, dtype=str).fillna("") if args.clusters else None
    specs = json.loads(Path(args.unit_spec).read_text()) if args.unit_spec else None
    units = build_units(names, field_map=field_map, clusters=clusters, units=units or args.units,
                        profile_fields=args.profile_fields, unit_specs=specs)
    if not args.attention_only and not units:
        raise ValueError("no importance units selected")
    return ([] if args.attention_only else units), field_map


def _pass(runner, out, name, common, checkpoint_hash, args, *, unit=None,
          repeat=0, identity=False, attention=False, file_limit=None):
    exposure_path = out / (name + ".exposure.json")
    file_start, file_end = int(runner.cfg.eval.file_start), int(runner.cfg.eval.file_end)
    if file_limit is not None:
        file_end = min(file_end, file_start + int(file_limit) - 1)
    record = dict(population="RANK-A", purpose="fixed_model_importance",
                  checkpoint_sha256=checkpoint_hash, files=dict(base=str(runner.cfg.eval.base),
                  start=file_start, end=file_end),
                  unit=None if unit is None else asdict(unit), repeat=repeat,
                  identity=identity, attention=attention, account_share=runner.account_share,
                  seed=args.seed, started_utc=_utc(), status="started", labels_read=True)
    common.write_json(exposure_path, _plain(record))
    common.append_jsonl(common.C2 / "READS.log", _plain(record))
    start = time.perf_counter()
    try:
        result = runner.score(unit=unit, repeat=repeat, identity=identity,
                              attention=attention, file_limit=file_limit)
        record.update(status="completed", ended_utc=_utc(),
                      elapsed_seconds=time.perf_counter()-start, coverage=result.coverage,
                      perturbation_audit=getattr(result, "audit", []),
                      score_order_sha256=_order_hash(result.data),
                      configured_workers=runner.configured_workers, used_workers=runner.used_workers)
        np.save(out / (name + ".scores.npy"), result.data.score.to_numpy(), allow_pickle=False)
        common.write_json(out / (name + ".score_order.json"),
                          dict(rows=len(result.data), sha256=record["score_order_sha256"]))
    except BaseException as error:
        record.update(status="failed", ended_utc=_utc(), elapsed_seconds=time.perf_counter()-start,
                      error_type=type(error).__name__, error=str(error))
        common.write_json(exposure_path, _plain(record))
        common.append_jsonl(common.C2 / "READS.log", _plain(record))
        raise
    common.write_json(exposure_path, _plain(record))
    common.append_jsonl(common.C2 / "READS.log", _plain(record))
    return result


def account_share_for(keyed, share):
    """Integration decision 12: a family whose recipes group by another key (customer, card) runs at a 100% share,
    because a sample of whole accounts would rebuild it from partial customer or card histories."""
    if not math.isfinite(share) or not 0 < share <= 1:
        raise ValueError("account share must be in (0, 1]")
    return 1.0 if keyed and share < 1 else share


def engine_check(frame):
    """The importance metrics against the reader's engine (nf_ranked) on the baseline pass: UDR, VDR, FPR and AP
    equal to 1e-12, else a stop (the three engines are kept, with this agreement; integration decision 6)."""
    import nf_ranked
    from nf_importance_metrics import point_metrics
    scores = frame.score.to_numpy(dtype=float)
    mine = point_metrics(frame, scores, outsort="0.006")
    amounts = pd.to_numeric(frame["amount"], errors="coerce").to_numpy(dtype=float) if "amount" in frame else None
    if amounts is not None and not np.isfinite(amounts).all():
        amounts = None
    ref = nf_ranked.outsort(frame["label"].to_numpy(dtype=np.int64), scores, frame["account"].astype(str).to_numpy(),
                            frame["id"].astype(str).to_numpy(), amounts)
    rows = {}
    for k in ("udr", "vdr", "fpr", "ap"):
        a, b = float(mine[k]), float(ref[k])
        same = (math.isnan(a) and math.isnan(b)) or abs(a - b) < 1e-12
        if not same:
            raise ValueError(f"importance metrics differ from the reader's engine on {k}: {a} vs {b}")
        rows[k] = {"importance": _plain(a), "reader": _plain(b)}
    return {"engine": "nf_ranked (the reader's): equal", "metrics": rows, "rows": int(len(frame))}


def _reading_b(frame):
    """Units whose whole interval is at or below zero on UDR and AP (both upper ends <= 0): the pruning rule's
    reading B (the reviewers' decision D4b). A unit without upper ends never qualifies."""
    keep = pd.Series(True, index=frame.index)
    for m in ("udr", "ap"):
        col = next((c for c in (f"drop_{m}_ci_high", f"{m}_drop_hi") if c in frame), None)
        if col is None:
            return []
        keep &= pd.to_numeric(frame[col], errors="coerce").le(0).fillna(False)
    return [str(u) for u in frame.loc[keep, "unit"]]


def render_summary(rows, common, run=None):
    if not rows:
        return common.screen("Transformer attention cross-check", [
            "No permutation units requested.", "Attention is descriptive, not feature importance.",
            "It describes within-transaction pooling, not how history is read."])
    frame = pd.DataFrame(rows)
    metric = "drop_udr"
    if metric not in frame:
        metric = next((c for c in frame if c.startswith("drop") and "udr" in c), "drop_ap")
    for col in {metric, "drop_ap"}:
        frame[col] = pd.to_numeric(frame[col], errors="coerce")
    ordered = frame.sort_values([metric, "drop_ap"], ascending=False, na_position="last")
    clusters = ordered[ordered.kind.eq("cluster")]
    chosen = clusters if len(clusters) else ordered
    lines = ["Permutation sensitivity of this checkpoint on RANK-A June targets.",
             "Positive drop: performance fell when the unit was perturbed.",
             "Units are re-ranked at the same alert count, with the same tie rule."]
    for title, sub in (("Largest drops", chosen.head(10)), ("Smallest drops", chosen.tail(10))):
        lines.append(title)
        for _, row in sub.iterrows():
            val = row.get(metric, float("nan"))
            ap = row.get("drop_ap", float("nan"))
            lines.append(f"{str(row.unit)[:30]}: UDR {val:.5g}, AP {ap:.5g}, "
                         f"attention {str(row.get('attention_ranks', 'n/a'))[:18]}")
    qualify = _reading_b(frame)
    lines += ["Qualify under reading B (whole interval at or below zero on UDR and AP, this fit):",
              "  information for the next model version; no field leaves this model on it"]
    names = ", ".join(qualify) if qualify else "none"
    wrapped = textwrap.wrap(names, 86) or ["none"]
    lines += ["  " + x for x in wrapped[:3]]
    if len(wrapped) > 3:
        lines.append(f"  ... {len(qualify)} units in all (importance.csv)")
    lines += ["Calendar perturbations hold timestamps fixed and are artificial checks.",
              "Direct output shuffles may disagree with raw inputs or sibling recipes.",
              "Account and permutation variation are not training-seed uncertainty.",
              "Attention is descriptive, not an importance or adoption threshold."]
    who = run or "this checkpoint"
    return common.screen(f"Feature sensitivity of {who}: this stage 2 fit, not the shipped model", lines)


def measured_hours(unit_count, repeats, baseline_seconds):
    """The cost measured on the baseline pass (the reviewers' decision D6): (1 + units x repeats) x its seconds."""
    return (1 + unit_count * repeats) * float(baseline_seconds) / 3600


def run(args, cfg, units, field_map, common, layout, estimate, fallback=None, estimates=None, units_used=None):
    """``fallback`` (name, units): the unit set used instead when the cost measured on the baseline pass exceeds
    --max-gpu-hours (the reviewers' decision D6); None when the fallback is already in use or not given."""
    from nf_importance_scoring import ScoreRunner
    if estimate["gpu_hours"] > args.max_gpu_hours:
        raise ValueError("estimated scoring cost exceeds --max-gpu-hours; change share, units or limit")
    busy = common.busy()
    if busy:
        raise ValueError("GPU already busy: " + "; ".join(busy))
    run_name = args.run_name or Path(args.checkpoint).parent.name
    out = Path(args.output) if args.output else common.C2 / "importance" / run_name
    out.mkdir(parents=True, exist_ok=False)
    checkpoint_hash = common.sha256_file(args.checkpoint)
    OmegaConf.save(cfg, out / "scoring_config.yaml")
    used = units_used or args.units
    plan = dict(run=run_name, units_used=used, estimate=estimate, estimates=estimates or {used: estimate},
                units=[asdict(u) for u in units], checkpoint_sha256=checkpoint_hash, outsort="0.006",
                repeats=args.repeats, account_share=args.account_share, seed=args.seed, draws=args.draws,
                bootstrap_seed=args.bootstrap_seed, max_gpu_hours=args.max_gpu_hours)
    common.write_json(out / "plan.json", _plain(plan))
    recompute = None
    if any(u.method == "family" for u in list(units) + list((fallback or (None, []))[1])):
        if field_map is None:
            raise ValueError("source families need --field-map for dependent recipes")
        recompute = make_recompute(field_map, str(cfg.data.account_col), str(cfg.data.order_col), args.extract_start)
    runner = ScoreRunner(cfg, args.checkpoint, account_share=args.account_share, seed=args.seed, recompute=recompute)
    if not units:
        null_unit = None
    else:
        null_unit = units[0]
    requested_share = runner.account_share
    try:
        # The null check uses whole accounts of one full file; a hash subsample
        # might otherwise contain no accounts in that file.
        runner.account_share = 1.0
        plain = _pass(runner, out, "null_plain", common, checkpoint_hash, args, file_limit=1)
        identity = _pass(runner, out, "null_identity", common, checkpoint_hash, args,
                         unit=null_unit, identity=True, attention=True, file_limit=1)
        assert_same_scores(plain.all_data, identity.all_data)
    finally:
        runner.account_share = requested_share
    common.write_json(out / "identity_check.json", dict(bitwise_equal=True, rows=len(plain.all_data)))
    baseline = _pass(runner, out, "baseline", common, checkpoint_hash, args, attention=True)
    if baseline.data.empty:
        raise ValueError("sample has no June targets")
    common.write_json(out / "engine_check.json", engine_check(baseline.data))
    hours = measured_hours(len(units), args.repeats, baseline.elapsed_seconds)
    plan["measured_after_baseline"] = {used: dict(units=len(units), gpu_hours=hours,
                                                  baseline_seconds=baseline.elapsed_seconds)}
    if hours > args.max_gpu_hours:
        figures = f"--units {used}: {hours:.2f} GPU hours"
        switched = False
        if fallback:
            name, f_units = fallback
            f_hours = measured_hours(len(f_units), args.repeats, baseline.elapsed_seconds)
            plan["measured_after_baseline"][name] = dict(units=len(f_units), gpu_hours=f_hours,
                                                         baseline_seconds=baseline.elapsed_seconds)
            figures += f"; the fallback --units {name}: {f_hours:.2f} GPU hours"
            if f_hours <= args.max_gpu_hours:
                print(f"measured after the baseline pass: {figures}; the cap {args.max_gpu_hours:g}: "
                      f"runs with --units {name}")
                units, used, switched = f_units, name, True
                plan.update(units_used=used, units=[asdict(u) for u in units])
        if not switched:
            common.write_json(out / "plan.json", _plain(plan))
            raise ValueError(f"the cost measured on the baseline pass exceeds --max-gpu-hours "
                             f"({args.max_gpu_hours:g}): {figures}; change share, units or limit")
    common.write_json(out / "plan.json", _plain(plan))
    baseline.data[[c for c in baseline.data if c != "score"]].to_parquet(out / "score_rows.parquet", index=False)
    attention_data = baseline.attention
    attention_values = {}
    common.write_json(out / "attention.json", _plain(attention_data))
    if isinstance(attention_data, dict):
        attention_values = attention_data.get("features", attention_data.get("feature_attention", {}))
        if isinstance(attention_values, dict):
            pd.DataFrame([dict(feature=k, attention=v) for k, v in attention_values.items()]).to_csv(out / "attention.csv", index=False)
    if not units:
        common.write_json(out / "importance.json", [])
    attention_ranks = {k: rank + 1 for rank, (k, _) in enumerate(
        sorted(attention_values.items(), key=lambda kv: kv[1], reverse=True))}
    rows = []
    for unit in units:
        scores, measured = [], []
        for repeat in range(args.repeats):
            result = _pass(runner, out, _slug(unit.name) + f"_r{repeat}", common, checkpoint_hash,
                           args, unit=unit, repeat=repeat)
            scores.append(align_pass(baseline.data, result.data))
            measured.append(result.elapsed_seconds)
        metrics = summarize_unit(baseline.data, baseline.data.score.to_numpy(), scores,
                                 draws=args.draws, seed=args.bootstrap_seed, outsort="0.006")
        row = dict(unit=unit.name, members=";".join(unit.members), kind=unit.kind,
                   method=unit.method, donor_unit=unit.donor_unit,
                   source_columns=";".join(unit.source_columns),
                   dependent_outputs=";".join(unit.dependent_outputs),
                   artificial_time_fixed=unit.artificial_time_fixed,
                   baseline_scoring_seconds=baseline.elapsed_seconds,
                   measured_scoring_seconds=sum(measured),
                   measured_gpu_seconds=sum(measured) if str(runner.device).startswith("cuda") else 0.0,
                   attention_sum=sum(attention_values.get(m, 0) for m in unit.members),
                   attention_ranks=";".join(f"{m}:{attention_ranks.get(m, 'n/a')}" for m in unit.members),
                   device=runner.device, coverage=json.dumps(_plain(baseline.coverage)), **metrics)
        rows.append(row)
        pd.DataFrame(rows).to_csv(out / "importance.csv", index=False)
        common.write_json(out / "importance.json", _plain(rows))
    if common.sha256_file(args.checkpoint) != checkpoint_hash:
        raise ValueError("checkpoint changed while scoring")
    summary = render_summary(rows, common)
    (out / "summary.txt").write_text(summary + "\n")
    common.write_json(out / "completed.json", dict(ended_utc=_utc(), units=len(units),
                      checkpoint_sha256=checkpoint_hash, no_adoption_threshold=True))
    print(summary)
    print(f"IMPORTANCE_DIR={out}")
    return 0


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    for command in ("estimate", "run"):
        s = sub.add_parser(command)
        s.add_argument("--config", required=True)
        s.add_argument("--checkpoint", required=True)
        s.add_argument("--output")
        s.add_argument("--run-name")
        s.add_argument("--rank-a-base", help="optional RANK-A data root; otherwise use config eval.base")
        s.add_argument("--field-map")
        s.add_argument("--clusters")
        s.add_argument("--unit-spec", help="JSON list of explicit unit definitions; family units name sources")
        s.add_argument("--profile-fields", nargs="*", default=[])
        s.add_argument("--units", choices=list(UNIT_CHOICES), default="both")
        s.add_argument("--fallback-units", choices=list(UNIT_CHOICES),
                       help="the unit set used when --units does not fit --max-gpu-hours (decision D6)")
        s.add_argument("--attention-only", action="store_true")
        s.add_argument("--account-share", type=float, default=.25)
        s.add_argument("--repeats", type=int, default=1)
        s.add_argument("--seed", type=int, default=20261102)
        s.add_argument("--bootstrap-seed", type=int, default=20261102)
        s.add_argument("--draws", type=int, default=2000)
        s.add_argument("--max-gpu-hours", type=float, default=24)
        s.add_argument("--seconds-per-row", type=float)
        s.add_argument("--rank-a-rows", type=int, help="all source rows, including history months")
        s.add_argument("--timing", help="measured scoring timing JSON")
        s.add_argument("--extract-start", default="2025-05-01")
    s = sub.add_parser("summary")
    s.add_argument("--output", required=True)
    return p


def main(argv=None):
    args = parser().parse_args(argv)
    common, layout = _shared()
    try:
        if args.command == "summary":
            out = Path(args.output)
            rows = common.read_json(out / "importance.json")
            plan = common.read_json(out / "plan.json") if (out / "plan.json").is_file() else {}
            print(render_summary(rows, common, run=plan.get("run") or out.name))
            return 0
        cfg = OmegaConf.load(args.config)
        # Reuse the fitted model settings; only the scoring range changes in memory.
        settings = common.settings()
        cfg.eval.file_start, cfg.eval.file_end = _rank_a_files(settings)
        if args.rank_a_base:
            cfg.eval.base = args.rank_a_base
        enforce_rank_a(cfg, settings)
        if args.draws < 2 or not math.isfinite(args.max_gpu_hours) or args.max_gpu_hours <= 0:
            raise ValueError("bootstrap draws must be at least two; maximum GPU hours must be positive")
        units, field_map = _plan(cfg, args, layout)
        account_col = str(cfg.data.get("account_col", "Nmap_account_reference_xid"))
        keyed = non_account_keys(field_map, units, account_col)
        requested = args.account_share
        share = account_share_for(keyed, requested)
        if share != args.account_share:
            print("account share 1.0 (was " + f"{args.account_share:g}): families keyed on another key: "
                  + "; ".join(f"{u} ({', '.join(k)})" for u, k in keyed.items()))
            args.account_share = share
        rows, seconds = _timing(args)
        estimate = estimate_cost(rows, len(units), args.repeats, seconds, args.account_share)
        print(json.dumps(estimate, indent=2))
        estimates, used, fallback = {args.units: estimate}, args.units, None
        if args.fallback_units and args.fallback_units != args.units and not args.attention_only:
            f_units, _ = _plan(cfg, args, layout, units=args.fallback_units)
            f_share = account_share_for(non_account_keys(field_map, f_units, account_col), requested)
            fallback = (args.fallback_units, f_units)
            if estimate["gpu_hours"] > args.max_gpu_hours:
                f_estimate = estimate_cost(rows, len(f_units), args.repeats, seconds, f_share)
                estimates[args.fallback_units] = f_estimate
                print(f"estimate --units {args.units}: {estimate['gpu_hours']:.2f} GPU hours, above the cap "
                      f"{args.max_gpu_hours:g}; the fallback --units {args.fallback_units}: "
                      f"{f_estimate['gpu_hours']:.2f} GPU hours")
                if f_estimate["gpu_hours"] > args.max_gpu_hours:
                    raise ValueError(f"estimated scoring cost exceeds --max-gpu-hours with --units {args.units} "
                                     f"({estimate['gpu_hours']:.2f} h) and with the fallback --units "
                                     f"{args.fallback_units} ({f_estimate['gpu_hours']:.2f} h); change share, "
                                     "units or limit")
                units, estimate, used, fallback = f_units, f_estimate, args.fallback_units, None
                args.account_share = f_share
        if args.command == "estimate":
            return 0
        return run(args, cfg, units, field_map, common, layout, estimate, fallback=fallback,
                   estimates=estimates, units_used=used)
    except (ValueError, AssertionError) as error:
        print(f"STOP: {error}", file=sys.stderr)
        return common.STOP


if __name__ == "__main__":
    raise SystemExit(main())
