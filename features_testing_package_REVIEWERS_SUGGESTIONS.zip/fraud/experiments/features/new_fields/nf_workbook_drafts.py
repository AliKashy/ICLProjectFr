"""Write the reviewers' draft feature lists and the decisions table template from the records.

REVIEWERS' SUGGESTIONS, NOT FINAL. Every row is UNCONFIRMED. The owner and Copilot decide.

Writes, under NF (``fraud/experiments/features/new_fields/``):
- ``DRAFT_TFM_FIELDS_UNCONFIRMED.csv``: the 217-row candidate list (120 V22B chart rows first), with
  the seven TFM-engineered V22B rows re-decided from no to hold and rank 75 kept as days until expiry
  (the second reviewer's feature review). A ``name`` column links each row to its feature.
- ``DRAFT_15298_RECIPES_UNCONFIRMED.csv``: the 94-row 15298 crosswalk, with a draft recipe in the
  recipe grammar where the crosswalk supports one, and a left_out_reason where it does not.
- ``DRAFT_OTHER_PROPOSED_UNCONFIRMED.csv``: the 16 features built on 26 October, two more built
  columns the features README lists, and the meeting ideas not built yet.
- ``DRAFT_FEATURE_ATTRIBUTES_UNCONFIRMED.csv``: one row per new feature name (type, categories,
  recipe, raw dependencies, date meaning, mapping status), in field-map column names.
- ``KEEP_DECISIONS.csv``: the one decisions table (name, group, verdict, reason, evidence,
  decided_by, date, definition_version). Every draft row says ``decided_by = proposed``.

Run from anywhere (records are read relative to the project root, or ``--records-root``):
    python fraud/experiments/features/new_fields/nf_workbook_drafts.py [--out DIR] [--force]

KEEP_DECISIONS.csv and the attributes table are never overwritten without ``--force``, because people edit them.
Records read:
    fraud/configs/predictors.csv
    waqas/feature_work/all_features_master.csv
    11_01_2026/features_work/CANDIDATE_FIELDS_UNCONFIRMED.csv
    11_01_2026/features_work/15298_RECIPE_CROSSWALK.csv
"""

import argparse
import csv
import io
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
NF_DIR = Path(__file__).resolve().parent
for _p in (str(ROOT / "src"), str(ROOT)):
    if _p not in sys.path:
        sys.path.insert(0, _p)
if str(NF_DIR) not in sys.path:
    sys.path.insert(0, str(NF_DIR))
import nf_common as C  # noqa: E402  (the 90-character refusal lines)

PREDICTORS = "fraud/configs/predictors.csv"
MASTER = "waqas/feature_work/all_features_master.csv"
CANDIDATES = "11_01_2026/features_work/CANDIDATE_FIELDS_UNCONFIRMED.csv"
CROSSWALK = "11_01_2026/features_work/15298_RECIPE_CROSSWALK.csv"

TFM_OUT = "DRAFT_TFM_FIELDS_UNCONFIRMED.csv"
F15298_OUT = "DRAFT_15298_RECIPES_UNCONFIRMED.csv"
OTHER_OUT = "DRAFT_OTHER_PROPOSED_UNCONFIRMED.csv"
ATTR_OUT = "DRAFT_FEATURE_ATTRIBUTES_UNCONFIRMED.csv"
KEEP_OUT = "KEEP_DECISIONS.csv"

DATE = "2026-11-02"
PROPOSED = "proposed"
EV_REVIEW = "reviewer records: FEATURE_REVIEW.md"
EV_CAND = "reviewer records: CANDIDATE_FIELDS_UNCONFIRMED.csv"
EV_XW = "reviewer records: 15298_RECIPE_CROSSWALK.csv"
EV_WEEKLY = "reviewer records: WEEKLY_2026-10-26.md"
EV_README = "reviewer records: README.md (features work)"

KEEP_COLUMNS = ["name", "group", "verdict", "reason", "evidence", "decided_by", "date", "definition_version"]
ATTR_COLUMNS = [
    "name", "origin", "group", "kind", "recipe", "source_columns", "model_type", "description",
    "yaqun_category", "business_category", "date_meaning", "mapping_status", "equivalence",
    "raw_alternative", "account_level_alternative", "left_out_reason", "proposed_work_type",
    "next_definition_needed", "kept_once_as", "flags", "tfm_name", "v22b_rank", "f15298_name",
    "f15298_rank", "excluded_by_sumegha", "sumegha_reason", "feasible_in_production", "in_owner_list",
    "definition_version", "list_status",
]

# ---------------------------------------------------------------------------------------------
# The second reviewer's replacement verdicts for the seven TFM-engineered V22B rows (verbatim).
SEVEN_HOLD = {
    "6": "Engineered candidate permitted. Resolve card and fuzzy-merchant keys, original count/window/cutoff, "
         "and observable earlier history. A different merchant grouping would be a distinct recipe.",
    "22": "Engineered candidate permitted. Map the actual birth-date field or subfield and define age relative "
          "to the transaction. The recorded raw lists do not establish that mapping.",
    "40": "Case-outcome recipe unresolved. Establish the event stream, known-at time and permitted meaning; "
          "current/later outcomes are not ordinary prior transaction history.",
    "44": "Event recipe unresolved. Define AIML event, dummy/count, entity and cutoff; the name does not "
          "establish the needed inputs or independence from later outcomes.",
    "48": "Encoding and strategy/action timing unresolved. Identify the raw value, original mapping and "
          "availability before treating it as a categorical alternative.",
    "56": "Engineered candidate permitted. Map the username event timestamp and determine whether it represents "
          "creation or an update and the value available at the transaction.",
    "59": "Engineered candidate permitted. Map account opening/reopening semantics and entity. First observed "
          "transaction is not a substitute for account opening.",
}
RANK75_REASON = (
    "Days until expiry. A known future expiry is legitimate, so a future date is not a leak sign here. "
    "Separate when the value was known from the date it represents. A duration is not month-free by "
    "itself: measure its overlap with month."
)
RANK75_AVAILABILITY = (
    "Expiry date: a future value is expected. Check that the stored expiry is the one known at the "
    "transaction, not a later reissue in an extract-time snapshot."
)
# Dates whose future value is known in advance (an expiry): days_until(c), date_meaning known_future_date.
# The 15298 crosswalk says "Known future expiry" for ranks 48, 50 and 57.
KNOWN_FUTURE_DATES = {"card_expiration_dt", "cprsrvc__pisinfo2_prev_exp_dt", "prior_action_db_expiration_dt"}
# Whole multi-output or packed fields: never a feature as they are; the subfield column must be named.
GENERIC_SOURCE = re.compile(r"^(user_data_\d+_strg|user_data_\d+_num|cprsrvc__pisinfo2?|cprcust__pisinfo\d?)$")
# Status-like tokens (whole tokens of a name split on "_" and digits), as data.
STATUS_TOKENS = {"status", "statuschg", "block", "blocked", "hold", "inactv", "inactive", "closed", "susp",
                 "counterfeit", "badchip", "disposition", "interdict", "ringdata", "atoevents", "susato", "frd",
                 "fraud", "claim", "chargeback", "dispute"}

# DESIGN.md 2.4: the 78 draft yes rows by kind (V22B ranks).
DESIGN_CODES = {3, 8, 15, 16, 18, 20, 21, 27, 29, 30, 31, 33, 37, 38, 39, 41, 46, 47, 49, 53, 54, 55, 57, 58, 77,
                79, 80, 82, 84, 86, 87, 88, 89, 90, 93, 97, 98, 100, 101, 107, 115}
DESIGN_NUMBERS = {23, 32, 64, 65, 69, 73, 83, 91, 96, 99, 105, 106, 110, 111, 113, 114, 117, 118, 119}
DESIGN_DATES = {25, 26, 28, 43, 45, 51, 52, 63, 66, 70, 75, 76, 94, 95, 102, 103, 108, 116}
SAME_TXN_DECISIONS = {10, 42, 60}
TIME_TOKENS = {"DELTA_TIME": "time_delta", "HOUR_OF_DAY": "hour", "DAY_OF_WEEK": "day_of_week"}
# Yaqun's plan (docs/fraud_detection_plan_detailed.md, Deliberately excluded) names these two fields.
PLAN_EXCLUDED = {"prior_action_db_expiration_dt", "transaction_advice_xcd"}
# TFM's V22 pipeline never feeds these two postal codes raw: it maps (postal code, country) to a geohash with its
# table (pkl_s3_to_tabular.py GEOHASH_PAIRS; tokenizer.py zip_geohash_handle). Their rows become geohash(...)
# recipes, and the raw postal code is the proposed alternative (part B, item 9).
GEOHASH_COUNTRY = {"merchant_postal_xcd": "merchant_country_xcd",
                   "cprsrvc__pisinfo_cardholder_postal_xcd": "cprsrvc__pisinfo_cardholder_country_xcd"}
EV_TFM_GEOHASH = "TFM source: pkl_s3_to_tabular.py GEOHASH_PAIRS, tokenizer.py zip_geohash_handle"
GEOHASH_REASON = ("V22B input as TFM feeds it: the geohash of (postal code, country) from TFM's table "
                  "(SETTINGS.yaml geohash_table), by TFM's rule. The raw postal code is the proposed alternative.")


def is_geohash_row(r):
    """A TFM row whose raw postal code TFM feeds as a geohash."""
    return r["pod_column"] in GEOHASH_COUNTRY and r["raw_or_engineered"] == "raw"

# ---------------------------------------------------------------------------------------------
# Categories.
BUSINESS_CATEGORIES = [
    "amount and balance", "limits", "card and authentication", "point of sale and terminal", "merchant",
    "transaction type and channel", "tokens, devices and logins", "account and customer profile", "time",
    "velocity and recency", "location", "merchant risk and claims", "bank decisions (lagged)",
    "external scores", "other bank-system codes",
]
_BUSINESS_RULES = [
    ("external scores", r"external_1_scr|^vaa$"),
    ("bank decisions (lagged)", r"falcondecline|predecline|processor_reason"),
    ("merchant risk and claims", r"claim|case_disposition|mchname|aiml"),
    ("time", r"^(month|day|hour|day_of_week|time_delta)$"),
    ("location", r"dist_|speed_|travel|gmt_offset|_country|cardholder_postal|risky_ip"),
    ("velocity and recency", r"cnt_|_count|count_|_vel_|_ct$|_ct_|24hr|48hr|14_1d|30_1d|since_last|since_first"
                             r"|mins_since|prev_auth|frst_txn|day30to1|accel|_new_30d|midrank|obs_days|no_prior"
                             r"|sigvervelocitysum|first_visit|merchant_visit|velocity"),
    ("limits", r"lmt|limit|_ddl|ddl_|line_used"),
    ("amount and balance", r"amt|bal|cash|dep|wd|spend|drain|headroom|ledger|chandepct"),
    ("tokens, devices and logins", r"token|device|login|logon|browser|_ip_|mobile|otp|username|pwstatus|password"
                                   r"|edruser"),
    ("card and authentication", r"cvv|avs|pin|crypto|card_|authctn|_aip_|verification|chip|security|expiration"
                                r"|plastic|pan_|atc_"),
    ("point of sale and terminal", r"pos_|terminal|atm_network|entry|capture|attend|premises"
                                   r"|cardholder_present"),
    ("merchant", r"merchant|mcc|mrch"),
    ("transaction type and channel", r"transaction_type|segment|category|advice|posting|p2p|transaction_amt|^channel$"),
    ("account and customer profile", r"^cpr|days_before__|days_until__|days_since__|date_of_birth|ddaopen|acct"),
]
HIGH_CARD = r"merchant_category|postal|state_xcd|country|token_requestor|ip_address|atm_network|_xid|browser|city"
LOW_CARD = r"xflg|_ind$|indicator|flag|tokenization|channel|_type$"


def business_category(name):
    n = (name or "").lower()
    for cat, pattern in _BUSINESS_RULES:
        if re.search(pattern, n):
            return cat
    return "other bank-system codes"


def yaqun_category(name, model_type, source=""):
    if str(source).startswith("derived:transaction_dttm"):
        return "Datetime-derived"
    if model_type == "continuous":
        return "Continuous"
    if model_type == "categorical":
        n = (name or "").lower()
        if re.search(HIGH_CARD, n):
            return "Categorical, high cardinality"
        if re.search(LOW_CARD, n):
            return "Categorical, low cardinality"
        return "Categorical, cardinality to check"
    return "To check"


# ---------------------------------------------------------------------------------------------
# CSV helpers (strings only, blanks as "", byte-stable output).
def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def header_of(path):
    with open(path, newline="", encoding="utf-8") as f:
        return next(csv.reader(f))


def write_csv(path, columns, rows):
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=columns, lineterminator="\n", extrasaction="raise")
    w.writeheader()
    for r in rows:
        w.writerow({c: r.get(c, "") for c in columns})
    Path(path).write_text(buf.getvalue(), encoding="utf-8")


class Registry:
    """One attribute row and one decision row per new feature name; the first list to name it wins."""

    def __init__(self, base_names):
        self.base = set(base_names)
        self.attrs, self.keep, self.order = {}, {}, []

    def add(self, attrs, verdict, reason, evidence):
        name = attrs["name"]
        if not name or name in self.base:
            return "base"
        if name in self.attrs:
            a = self.attrs[name]
            if attrs.get("group") == "f15298" and "not on the V22B chart" in a["flags"]:
                # A TFM raw column off the chart that 15298 uses: the 15298 list is why it is a candidate.
                row = {c: "" for c in ATTR_COLUMNS}
                row.update({k: ("" if v is None else str(v)) for k, v in attrs.items()})
                row.update(definition_version="1", list_status="UNCONFIRMED", tfm_name=a["tfm_name"],
                           origin="15298 (also a TFM raw column)",
                           flags="; ".join(x for x in (row["flags"], "also in the TFM raw selection list") if x))
                self.attrs[name] = row
                self.keep[name].update(group="f15298", verdict=verdict, reason=reason, evidence=evidence)
                return "replaced"
            if attrs.get("group") == "f15298" and a["group"] == "v22b":
                a["group"] = self.keep[name]["group"] = "both"
                a["origin"] = "TFM V22B and 15298"
            for k in ("f15298_name", "f15298_rank", "tfm_name", "v22b_rank"):
                if attrs.get(k) and not a.get(k):
                    a[k] = attrs[k]
            return "merged"
        row = {c: "" for c in ATTR_COLUMNS}
        row.update({k: ("" if v is None else str(v)) for k, v in attrs.items()})
        row["definition_version"] = "1"
        row["list_status"] = "UNCONFIRMED"
        self.attrs[name] = row
        self.keep[name] = {"name": name, "group": row["group"], "verdict": verdict, "reason": reason,
                           "evidence": evidence, "decided_by": PROPOSED, "date": DATE, "definition_version": "1"}
        self.order.append(name)
        return "new"


# ---------------------------------------------------------------------------------------------
# TFM V22B.
# The records' count of pod columns is not the owner's (227) and is never hard-coded (SCOPE ADD, review item 34).
POD_COLUMNS_OLD = "presence in the pod's 224 columns not confirmed"
POD_COLUMNS_NEW = ("presence among the pod's raw columns (227 by the owner's count; nf_intake.py schema gives the "
                   "number) not confirmed")


def tfm_draft(candidates):
    out = []
    for r in candidates:
        r = {k: (v.replace(POD_COLUMNS_OLD, POD_COLUMNS_NEW) if isinstance(v, str) else v) for k, v in r.items()}
        rank = r["v22b_importance_rank"]
        if r["scope"] == "v22b_chart" and rank in SEVEN_HOLD:
            if r["draft_include"] != "no":
                raise SystemExit(f"rank {rank}: expected draft no before the correction, got {r['draft_include']}")
            r["draft_include"] = "hold"
            r["draft_reason"] = (SEVEN_HOLD[rank] + f" ({EV_REVIEW}; was no under the superseded "
                                 "non-engineered rule.)")
        if r["scope"] == "v22b_chart" and rank == "75":
            r["draft_reason"] = RANK75_REASON + f" ({EV_REVIEW})"
            note = r["availability_note"]
            tail = note[note.find("Reviewer review"):] if "Reviewer review" in note else ""
            r["availability_note"] = (RANK75_AVAILABILITY + " " + tail).strip()
        out.append(r)
    return out


def _tfm_type(r, rank):
    if rank in DESIGN_CODES:
        return "categorical", False
    if rank in DESIGN_NUMBERS:
        return "continuous", False
    if rank in DESIGN_DATES:
        return "continuous", True
    d = r["dtype"].lower()
    is_date = ("temporal" in d or "date" in d or "suggests a date" in d or d == "days"
               or "DAYS_SINCE" in r["tfm_name"])
    if is_date:
        return "continuous", True
    if d.startswith(("str", "string", "flag", "label-encoded", "categorical")):
        return "categorical", False
    if d.startswith(("float", "double", "int", "count", "score", "continuous")):
        return "continuous", False
    return "", False


def date_recipe(col):
    if col in KNOWN_FUTURE_DATES:
        return f"days_until__{col}", f"days_until({col})", "known_future_date"
    return f"days_before__{col}", f"days_before({col})", "event_date"


def rank_number(rank_s):
    """A V22B importance rank as a number, or None for a row with no rank. The 97 TFM rows off the V22B chart have a
    blank rank; a blank or space-only cell is no rank, never int('')."""
    s = (rank_s or "").strip()
    return int(s) if s else None


def tfm_name_of(r, current_names):
    """The feature name a TFM row proposes (a base input name when it is one)."""
    rank = rank_number(r["v22b_importance_rank"])
    col, name = r["pod_column"], r["tfm_name"] or r["pod_column"]
    _, is_date = _tfm_type(r, rank)
    if name in TIME_TOKENS:
        return TIME_TOKENS[name]
    if r["already_a_current_input"] == "yes" and col in current_names:
        return col
    if rank in SAME_TXN_DECISIONS:
        return f"prev__{col or name.lower()}"
    if is_geohash_row(r):
        return f"geohash__{col}"
    if r["raw_or_engineered"] == "engineered":
        return name.lower()
    if is_date and col:
        return date_recipe(col)[0]
    return col or name.lower()


def tfm_register(tfm, reg, current_names):
    by_rank = {r["v22b_importance_rank"]: r for r in tfm if r["scope"] == "v22b_chart"}
    for r in tfm:
        rank_s = r["v22b_importance_rank"]
        rank = rank_number(rank_s)
        col, tname = r["pod_column"], r["tfm_name"] or r["pod_column"]
        name = r["name"]
        if name in reg.base:
            continue
        model_type, is_date = _tfm_type(r, rank)
        flags = []
        if r["is_status_field_or_status_date"] in ("yes", "unknown"):
            flags.append(f"status field or date: {r['is_status_field_or_status_date']}")
        if r["in_26oct_list"] == "yes":
            flags.append("in 26 October list")
        if r["scope"] != "v22b_chart":
            flags.append(f"not on the V22B chart ({r['scope']})")
        if col.lower() in PLAN_EXCLUDED:
            flags.append("deliberately excluded in Yaqun's plan")
        if rank == 1:
            flags.append("external score")
        tokens = set(re.split(r"[_\d]+", (col or tname).lower()))
        status_token = bool(tokens & STATUS_TOKENS) or any(t.endswith("susato") for t in tokens)
        if status_token and not r["is_status_field_or_status_date"] in ("yes", "unknown"):
            flags.append("status-like name token")
        generic = bool(GENERIC_SOURCE.match(col or ""))
        if generic:
            flags.append("generic multi-output field: name the subfield")
        a = dict(name=name, origin="TFM V22B", group="v22b", kind="raw", recipe="raw", source_columns=col,
                 model_type=model_type, tfm_name=tname, v22b_rank=rank_s, mapping_status="recorded" if col else
                 "to map on the pod")
        if rank in SAME_TXN_DECISIONS:
            src = col or tname.lower()
            a.update(kind="engineered", recipe=f"prev({src})", source_columns=src)
            flags.append("same-transaction bank decision: lagged only")
        elif r["raw_or_engineered"] == "engineered":
            a.update(kind="engineered", recipe="", source_columns="", mapping_status="definition_needed",
                     left_out_reason=SEVEN_HOLD.get(rank_s, r["draft_reason"]), proposed_work_type=(
                         "encoding_definition" if "_LE1__" in tname or "_LE3__" in tname else
                         "date_derivation" if "DAYS_SINCE" in tname else "recipe_definition"))
        elif is_date and col:
            _, rec, meaning = date_recipe(col)
            a.update(kind="engineered", recipe=rec, date_meaning=meaning)
        elif is_geohash_row(r):
            country = GEOHASH_COUNTRY[col]
            a.update(kind="engineered", recipe=f"geohash({col}; {country})", source_columns=f"{col};{country}",
                     model_type="categorical", raw_alternative=col)
            flags.append(f"raw alternative: {col}")
        if rank == 120:
            a["kept_once_as"] = by_rank["119"]["pod_column"]
        if rank_s == "75":
            desc = f"TFM V22B rank 75: {tname}. Days until card expiry."
        elif a["recipe"].startswith("days_"):
            desc = f"TFM V22B rank {rank_s}: {tname}. Date as days before the transaction."
        elif a["recipe"].startswith("prev("):
            desc = f"TFM V22B rank {rank_s}: {tname}. The previous transaction's value."
        elif a["recipe"].startswith("geohash("):
            desc = (f"TFM V22B rank {rank_s}: {tname}. TFM's geohash of the postal code with its country; the raw "
                    "postal code is the alternative.")
        elif rank_s:
            desc = f"TFM V22B rank {rank_s}: {tname} ({r['dtype']})"
        else:
            desc = f"TFM raw column {col or tname} ({r['dtype']})"
        a.update(description=desc, yaqun_category=yaqun_category(name, model_type),
                 business_category=business_category(name), flags="; ".join(flags))

        verdict_src, reason = r["draft_include"], r["draft_reason"]
        evidence = EV_REVIEW if rank_s in SEVEN_HOLD or rank_s == "75" else EV_CAND
        if verdict_src == "yes":
            verdict = "keep"
            if col.lower() in PLAN_EXCLUDED:
                verdict = "drop"
                reason = ("plan_exclusion: Yaqun's plan deliberately excludes it (no reason recorded there), "
                          "although the V22B draft said yes. The owner may reverse this.")
            else:
                if re.search(HIGH_CARD, name) and model_type == "categorical":
                    a["flags"] = "; ".join(x for x in (a["flags"], "high cardinality: Yaqun's plan excluded such "
                                                       "fields; check unique counts") if x)
                if is_geohash_row(r):
                    reason, evidence = GEOHASH_REASON, f"{EV_CAND}; {EV_TFM_GEOHASH}"
                reason = "draft_yes: " + (reason or "V22B input, raw field, on the 26 October list.")
        elif verdict_src == "hold":
            verdict = "hold"
            code = ("definition_needed" if rank_s in SEVEN_HOLD else "same_txn_decision" if rank in SAME_TXN_DECISIONS
                    else "external_score" if rank == 1 else "status")
            reason = f"{code}: {reason}"
            if col.lower() in PLAN_EXCLUDED:
                verdict = "drop"
                reason = ("plan_exclusion: Yaqun's plan deliberately excludes it (no reason recorded there). "
                          f"Also: {reason}")
        else:
            if a.get("kept_once_as"):
                verdict, reason = "drop", f"duplicate: {reason}"
            elif "Left out on 26 October" in reason:
                verdict, reason = "drop", f"status: {reason}"
            elif "excluded it by hand" in reason:
                verdict, reason = "drop", f"tfm_excluded: {reason}"
            elif "Masked identifier" in reason:
                verdict = "drop"
                reason = (f"identifier: {reason} An identifier is never a model input; it may still serve as a "
                          "recipe's grouping key.")
            elif "Status-like" in reason or status_token:
                verdict, reason = "hold", f"status: {reason}"
                if "Status-like" not in r["draft_reason"]:
                    reason += (" Status-like name token: out unless the data owner confirms it is fixed before the "
                               "decision.")
            elif generic:
                verdict = "hold"
                reason = ("definition_needed: A whole packed or multi-output field. Name the subfield or extracted "
                          "column; never cast the whole value.")
            elif r["scope"] != "v22b_chart":
                verdict = "unresolved"
                reason = ("owner_list_needed: Not on the V22B importance chart. The chart is not exhaustive: this "
                          "field enters only if the owner's supplied included list names it. (Source list verdict: "
                          "no.)")
            else:
                verdict, reason = "drop", f"other: {reason}"
        reg.add(a, verdict, reason, evidence)
        if rank in SAME_TXN_DECISIONS:
            raw = col or tname.lower()
            reg.add(dict(name=raw, origin="TFM V22B", group="v22b", kind="raw", recipe="raw", source_columns=raw,
                         model_type="categorical", tfm_name=tname, v22b_rank=rank_s,
                         mapping_status="recorded" if col else "to map on the pod",
                         description=f"TFM V22B rank {rank_s}: {tname} in raw form (this transaction's decision)",
                         yaqun_category="Deliberately excluded", business_category="bank decisions (lagged)",
                         flags="same-transaction bank decision"),
                    "drop", ("same_txn_decision: The bank's decision on the same transaction, in raw form. Only "
                             f"the previous transaction's value (prev__{raw}) may enter."), EV_CAND)


# ---------------------------------------------------------------------------------------------
# Model 15298.
F15298_EXTRA = ["kind", "model_type", "recipe", "recipe_support", "source_columns", "date_meaning",
                "mapping_status", "equivalence", "left_out_reason", "account_level_alternative", "raw_alternative",
                "same_output_as", "draft_note", "list_status"]


def _dc_auth_alternative(name):
    m = re.match(r"dc_auth_grpby_(card_num|customer_xid)_(.+?)_(tran_amt_(max|min|sum|mean)|count)_14_1d$", name)
    if not m:
        return "", ""
    key, grp, agg = m.group(1), m.group(2), m.group(4)
    if grp.endswith("xcd5") or "fuzzy" in grp:
        return key, ""
    if agg:
        return key, f"{agg}(14d; value=transaction_amt; same={grp})"
    return key, f"count(14d; same={grp})"


# Account-level recomputes guessed from the 15298 names: new output names (an engineered field never takes
# a raw column's name), held until the original definition is read.
FIXED_HISTORY = {
    "user_data_7_strg_24hr_count_same_mcc": ("count_24h_same_mcc", "count(24h; same=merchant_category_xcd)"),
    "user_data_7_strg_24hr_vel_same_mcc": ("amt_sum_24h_same_mcc",
                                           "sum(24h; value=transaction_amt; same=merchant_category_xcd)"),
    "user_data_1_strg_mins_since_last_auth": ("mins_since_last_txn", "since_last(minutes)"),
    "user_data_2_strg_prev_auth_amt": ("prev_txn_amt", "prev(transaction_amt)"),
}


def f15298_draft(crosswalk, master_ranked, reg, tfm_rows):
    """One row per ranked 15298 output, with a draft recipe or a left-out reason; registers new names."""
    master = {r["rank"]: r["name"] for r in master_ranked}
    tfm_by_name = {r["tfm_name"].lower(): r for r in tfm_rows if r["scope"] == "v22b_chart" and r["tfm_name"]}
    v22b_cols = {}
    for n, a in reg.attrs.items():
        if a["group"] in ("v22b", "both") and "not on the V22B chart" not in a["flags"]:
            cols = a["source_columns"].split(";")
            if a["recipe"].startswith("geohash("):
                cols = cols[:1]   # a geohash row stands for its postal code, not for the country it also reads
            for c in cols:
                if c:
                    v22b_cols.setdefault(c.lower(), n)
    all_tfm_cols = {r["pod_column"].lower() for r in tfm_rows if r["pod_column"]}

    def where(col):
        if col in reg.base:
            return f"current input {col}"
        n = v22b_cols.get(col.lower())
        if n:
            return f"V22B rank {reg.attrs[n]['v22b_rank']} ({n})"
        return ""

    out = []
    for x in crosswalk:
        rank, fname = x["rank_15298"], x["feature_15298"]
        if master.get(rank) != fname:
            raise SystemExit(f"15298 rank {rank}: crosswalk name {fname} differs from the master's {master.get(rank)}")
        wt, rec_src = x["proposed_work_type"], x["recorded_source_column"]
        e = {k: "" for k in F15298_EXTRA}
        e["list_status"] = "UNCONFIRMED"
        name = fname
        verdict, reason, evidence = "hold", "", EV_XW
        exact = tfm_by_name.get(x["exact_name_in_217_draft"].lower()) if x["exact_name_in_217_draft"] else None

        if exact is not None and wt != "recorded_raw_mapping":
            name = exact["name"]
            a = reg.attrs.get(name, {})
            e.update(kind=a.get("kind", "engineered"), model_type=a.get("model_type", ""), recipe=a.get("recipe", ""),
                     source_columns=a.get("source_columns", ""), mapping_status=a.get("mapping_status", ""),
                     recipe_support="same output as a V22B row",
                     same_output_as=f"V22B rank {exact['v22b_importance_rank']} ({name})",
                     left_out_reason=a.get("left_out_reason", ""),
                     draft_note="Same output as the V22B row; the decision is on that name.")
            if wt == "encoding_definition":
                stem = re.match(r"derived_le[13]__(.+)$", fname).group(1)
                e.update(mapping_status="open", equivalence="unverified", raw_alternative=stem,
                         draft_note=e["draft_note"] + f" Raw alternative {stem} is not in the recorded schema.")
        elif wt == "recorded_raw_mapping":
            col = rec_src
            note = ""
            if fname == "user_data_6_num_temp_line_used_ratio":
                col = fname
                note = f" The recorded source is the generic {rec_src}; the extracted column is used."
            name = col
            e.update(kind="raw", model_type="continuous", recipe="raw", recipe_support="recorded source" + note,
                     source_columns=col, mapping_status="recorded", same_output_as=where(col),
                     draft_note="Raw field already in the set; kept once as the earlier copy." + note)
        elif wt == "encoding_definition":
            m = re.match(r"derived_le[13]__(.+)$", fname)
            stem = m.group(1) if m else ""
            col = rec_src or stem
            support = "recorded source" if rec_src else "name only (source not in the recorded schema)"
            if rec_src == "user_data_1_strg":
                col = "user_data_1_strg_p2p_type"
                support = ("recorded source is the generic user_data_1_strg; the extracted column from the TFM raw "
                           "list is named. Confirm the subfield on the pod")
            w = where(col)
            e.update(kind="engineered", model_type="categorical", recipe="", recipe_support=support,
                     source_columns=col, raw_alternative=col, mapping_status="open", equivalence="unverified",
                     left_out_reason=(f"Original LE encoder not documented. Proposed alternative: the raw code "
                                      f"{col}, as code({col}), not proven equivalent."),
                     draft_note=("Open mapping. LE1/LE3 is an encoding whose original encoder and rare or unseen "
                                 f"handling are not verified. The raw categorical {col} is a proposed alternative, "
                                 "not proven equivalent" + (f"; it is in the list as {w}." if w else ".")))
            # one reading (integration decision 3): unresolved, with code(c) as the proposed alternative
            verdict = "unresolved"
            reason = ("open_mapping: original encoder unverified; raw code proposed as an alternative (reviewer "
                      f"feature review). Proposed alternative: code({col}).")
            evidence = EV_REVIEW
        elif wt == "date_derivation":
            col = re.match(r"derived__days_since__(.+)$", fname).group(1)
            note = ""
            if rec_src in ("cprsrvc__pisinfo2", "cprsrvc__pisinfo"):
                note = (f" The recorded source is the generic multi-output field {rec_src}; the extracted subfield "
                        f"column {col} is named, never a cast of the whole value.")
            new_name, rec, meaning = date_recipe(col)
            name = new_name
            support = ("recorded source" if rec_src else "source in the TFM raw lists" if col in all_tfm_cols
                       else "name only (source not in the recorded schema)")
            e.update(kind="engineered", model_type="continuous", recipe=rec, date_meaning=meaning,
                     recipe_support=support + note, source_columns=col, same_output_as=where(col),
                     mapping_status="recorded" if support != "name only (source not in the recorded schema)"
                     else "name_only")
            if col.endswith("status_dt"):
                reason = ("status: Status date: out unless the data owner confirms it is fixed before the "
                          "decision." + note)
            else:
                verdict = "keep"
                reason = ("draft_yes: Profile date as days before the transaction. Subject to the "
                          "moment-of-transaction check (dates after the transaction, overall and by label)." + note)
            e["draft_note"] = reason.split(": ", 1)[1]
        elif wt == "claim_history_definition":
            e.update(kind="engineered", mapping_status="definition_needed", left_out_reason=(
                "Claim history needs label-availability information (when each claim became known); the raw files "
                "hold no known-at date. MCC or merchant is only the grouping key. A claim-rate name may be a "
                "label-free count: read the original definition first."))
            reason = "definition_needed: " + e["left_out_reason"]
        elif wt == "event_history_definition":
            e.update(kind="engineered", mapping_status="definition_needed", left_out_reason=(
                "Event history from another system (logins, inquiries, AIML or case events) is not among the "
                "recorded raw columns; case outcomes are not ordinary prior history. Needs the event stream, "
                "known-at time, entity and cutoff."))
            reason = "definition_needed: " + e["left_out_reason"]
        elif wt == "transaction_history_definition":
            if fname.startswith("dc_tran_claim_rate_"):
                e.update(kind="engineered", mapping_status="definition_needed", left_out_reason=(
                    "Count over all customers of a merchant group (30_1d). The files are account buckets; whether "
                    "it can be built depends on the original definition and the pod's data. A merchant column is "
                    "not a merchant count."))
            else:
                key, alt = _dc_auth_alternative(fname)
                what = "card key" if key == "card_num" else "customer key"
                extra = (" The 5-digit postal prefix or fuzzy merchant name is not in the grammar." if not alt else "")
                e.update(kind="engineered", account_level_alternative=alt, mapping_status="definition_needed",
                         left_out_reason=(
                             f"Grouped by the {what}, which is not a recorded raw column. The grammar can group by "
                             f"it with key={key} if the pod holds that column; an account version is a different "
                             f"feature (owner's written word needed). The real window and cutoff of 14_1d still "
                             f"need definitions." + extra))
            reason = "definition_needed: " + e["left_out_reason"]
        else:  # recipe_definition
            e.update(kind="engineered")
            if fname in FIXED_HISTORY:
                name, rec = FIXED_HISTORY[fname]
                srcs = sorted(set(re.findall(r"(?:value=|same=|prev\()([a-z_0-9]+)", rec))) or ["transaction_dttm"]
                e.update(model_type="continuous", recipe=rec, source_columns=";".join(srcs),
                         mapping_status="guessed_from_name",
                         recipe_support=("recomputed from the account's earlier rows; the upstream packed value may "
                                         "use another entity or window"))
                if fname in all_tfm_cols:
                    e["raw_alternative"] = fname
                    e["recipe_support"] += "; the TFM raw list also holds it as a column, so raw is an alternative"
                reason = ("definition_needed: Draft recipe guessed from the name (account level, same-second "
                          "rule). Read the original definition (entity, window, which rows count) and compare with "
                          "the packed upstream value on the pod before keeping it.")
            elif fname.startswith("user_data_"):
                e.update(mapping_status="definition_needed", left_out_reason=(
                    "Packed upstream string with no documented layout, and the recompute needs code values the "
                    "records do not give (ATM, signature, POS entry mode or expiry-mismatch codes). Raw only if the "
                    "pod holds it as its own column."))
                reason = "definition_needed: " + e["left_out_reason"]
            elif fname.startswith("mchname_"):
                e.update(mapping_status="definition_needed", left_out_reason=(
                    "Merchant-name index over all customers (and label timing for rates). Needs the original "
                    "definition and merchant-name normalisation; account files may not support it."))
                reason = "definition_needed: " + e["left_out_reason"]
            elif fname == "days_since_frst_txn_cust_merch_90":
                e.update(account_level_alternative="since_first(days; same=Nmap_merchant_xid; within=90d)",
                         mapping_status="definition_needed", left_out_reason=(
                             "Keyed by customer and merchant. The grammar can key on the customer with key= if the "
                             "pod holds that column (same= adds the merchant); an account version is a different "
                             "feature (owner's written word needed). A 90-day window is censored on every June row "
                             "(evaluation files start on 1 May 2025)."))
                reason = "definition_needed: " + e["left_out_reason"]
            else:
                e.update(kind="raw", model_type="continuous", recipe="raw", source_columns=fname,
                         mapping_status="name_only", recipe_support="name only (source not in the recorded schema)")
                verdict = "keep"
                reason = ("draft_yes: " + ("Chip application transaction counter, a raw authorisation field. "
                                           "Matches Xiaoming's chip-card count idea. Raw if the pod holds it; check "
                                           "counter resets (the 1000 today, 2000 yesterday case)."
                                           if fname == "atc_card_cnt" else
                                           "Profile value stored on the row. Raw if the pod holds the column."))
            if not e["draft_note"]:
                e["draft_note"] = reason.split(": ", 1)[1] if ": " in reason else reason
        if not e["draft_note"]:
            e["draft_note"] = reason.split(": ", 1)[1] if ": " in reason else reason

        flags = []
        if fname == "external_1_scr":
            flags.append("external score")
        if e["account_level_alternative"]:
            flags.append("account-level alternative recorded")
        if e["raw_alternative"]:
            flags.append(f"raw alternative: {e['raw_alternative']}")
        a = dict(name=name, origin="15298", group="f15298", kind=e["kind"], recipe=e["recipe"],
                 source_columns=e["source_columns"], model_type=e["model_type"],
                 description=f"15298 rank {rank}: {fname} ({wt.replace('_', ' ')})",
                 yaqun_category=yaqun_category(name, e["model_type"]) if e["model_type"] else "To check",
                 business_category=business_category(fname), date_meaning=e["date_meaning"],
                 mapping_status=e["mapping_status"], equivalence=e["equivalence"], raw_alternative=e["raw_alternative"],
                 account_level_alternative=e["account_level_alternative"], left_out_reason=e["left_out_reason"],
                 proposed_work_type=wt, next_definition_needed=x["next_definition_needed"], flags="; ".join(flags),
                 f15298_name=fname, f15298_rank=rank)
        reg.add(a, verdict, reason, evidence)
        out.append({"name": name, **x, **e})
    return out


# ---------------------------------------------------------------------------------------------
# Other proposed features. Rows 1-16 are the 26 October Appendix C list, mapped to the columns the
# 26 October builders return (groups.py compute_groups, screen/features_new.py compute_new).
OTHER_COLUMNS = ["name", "item", "status", "what_it_captures", "kind", "model_type", "recipe", "builder",
                 "source_columns", "overlaps_with", "caution", "left_out_reason", "record", "list_status"]

_B = "built 26 October (Appendix C)"
_BR = "built 26 October (listed in the features README, not in Appendix C)"
_I = "idea, not built"
_G = "groups.py compute_groups"
_N = "screen/features_new.py compute_new"
_APC = EV_WEEKLY + " Appendix C"
_README = EV_README + ", last section"
_MEET2 = "waqas/docs/meeting_notes.md section 2"
_MEET7 = "waqas/docs/meeting_notes.md section 7"

OTHER = [
    ("Amount over available balance", "amt_over_balance", _B, "Share of the balance this transaction uses",
     "continuous", _G, "transaction_amt;total_available_balance_amt", "", "", "", _APC),
    ("Amount over remaining daily merchandise limit", "amt_over_merch_lmt", _B,
     "Share of the remaining daily limit this transaction uses", "continuous", _G,
     "transaction_amt;remain_day_merchandise_lmt_amt", "", "", "", _APC),
    ("Headroom code (overdraw, exact drain, 90% or more, 50-90%, under 50%)", "headroom_balance", _B,
     "How close the transaction comes to emptying the account", "categorical", _N,
     "transaction_amt;total_available_balance_amt", "", "", "", _APC),
    ("Balance drained in the last 24 hours, this purchase included", "drain_24h", _B, "A rapid cash-out",
     "continuous", _N, "transaction_amt;total_available_balance_amt;transaction_dttm", "", "", "", _APC),
    ("Transaction count, last 5 minutes", "cnt_5m_log1p", _B, "Velocity beyond the model's 20-transaction window",
     "continuous", _G, "transaction_dttm", "", "", "", _APC),
    ("Transaction count, last 1 hour", "cnt_1h_log1p", _B, "Velocity beyond the model's 20-transaction window",
     "continuous", _G, "transaction_dttm", "", "", "", _APC),
    ("Transaction count, last 24 hours", "cnt_24h_log1p", _B, "Velocity beyond the model's 20-transaction window",
     "continuous", _G, "transaction_dttm", "", "", "", _APC),
    ("Transaction count, last 7 days", "cnt_7d_log1p", _B, "Velocity beyond the model's 20-transaction window",
     "continuous", _G, "transaction_dttm", "", "", "", _APC),
    ("Transaction count, last 30 days", "cnt_30d_log1p", _B, "Velocity beyond the model's 20-transaction window",
     "continuous", _G, "transaction_dttm", "", "", "", _APC),
    ("MCC new for the account in the last 30 days", "mcc_new_30d", _B, "First use of a merchant type",
     "continuous", _N, "merchant_category_xcd;transaction_dttm", "",
     "A new merchant category is not a first visit to an exact merchant.", "", _APC),
    ("Card-present transactions in the last 5 minutes, all entry methods", "cp_cnt_5m_log1p", _B,
     "Bursts at a terminal", "continuous", _N, "cardholder_present_xflg;transaction_dttm",
     "15298 rank 92 (counts one transaction type only)", "Needs the card-present code value stated.", "", _APC),
    ("E-commerce transactions in the last 24 hours", "cnp_cnt_24h_log1p", _B, "Card-not-present bursts",
     "continuous", _N, "cardholder_present_xflg;transaction_dttm", "", "Needs the card-absent code value stated.",
     "", _APC),
    ("Amount rank among the account's own amounts in the last 30 days", "amt_midrank_30d", _B,
     "Unusual for this account", "continuous", _G, "transaction_amt;transaction_dttm", "", "", "", _APC),
    ("Distance from the previous located transaction", "dist_prev_km_log1p", _B, "Location jump", "continuous", _N,
     "merchant_postal_xcd;cardholder_present_xflg;transaction_dttm", "",
     "Needs a postal centroid table.", "", _APC),
    ("Implied travel speed from the previous located transaction", "speed_kmh_log1p", _B, "Impossible travel",
     "continuous", _N, "merchant_postal_xcd;cardholder_present_xflg;transaction_dttm", "",
     "Needs a postal centroid table.", "", _APC),
    ("Distance from the home postal code", "dist_home_km_log1p", _B, "Away from home", "continuous", _N,
     "merchant_postal_xcd;cprsrvc__pisinfo_cardholder_postal_xcd;cardholder_present_xflg", "",
     "If the extract holds today's address, a later move leaks. Needs a postal centroid table.", "", _APC),
    ("No transactions in the last 30 days", "no_prior_30d", _BR, "New or dormant account", "continuous", _G,
     "transaction_dttm", "", "Missing history is not a measured zero: missing while the window is censored.",
     "", _README),
    ("Days since the account's first row, up to 30", "obs_days_30", _BR, "Short observed history",
     "continuous", _G, "transaction_dttm", "",
     "First observed transaction is not account opening.", "", _README),
    ("Chip-card authorisation count (Xiaoming)", "chip_card_auth_count", _I,
     "How many authorisations this chip card has done", "continuous", "",
     "", "15298 rank 15 atc_card_cnt (the chip counter, draft keep there)",
     "Needs a card or chip identifier among the raw columns; cards can be spoofed (Xiaoming).",
     "Card key not among the recorded raw columns. The grammar can group by it with key= if the pod holds it; "
     "that is a different feature from an account version.", _MEET7 + "; " + _README),
    ("First time at this exact merchant", "merchant_first_visit_90d", _I, "First visit to this merchant",
     "continuous", "", "Nmap_merchant_xid;transaction_dttm", "15298 rank 5 (customer and merchant, 90 days)",
     "Needs the merchant identifier as a grouping key only (never an input). A 90-day window is censored on "
     "every June row; a shorter window may be needed.", "", _README),
    ("Days since the last visit to this merchant", "days_since_merchant_visit", _I,
     "Return to a known merchant", "continuous", "", "Nmap_merchant_xid;transaction_dttm", "",
     "Merchant identifier as a grouping key only.", "", _README),
    ("Changes since the previous transaction (amount, balance, limits, external score)", "delta_prev", _I,
     "Deltas on the raw continuous fields, like the time gap", "continuous", "",
     "transaction_amt;total_available_balance_amt;available_daily_cash_limit_amt;avlble_merch_day_cash_lmt_amt;"
     "remain_day_merchandise_lmt_amt;external_1_scr", "",
     "The model already sees the previous transactions in its 20-row window.",
     "The grammar has prev(c) but no difference; a native delta needs a change to the sequence builder "
     "(hashed code).", _MEET7 + "; " + _README),
    ("Yesterday's values of daily aggregates (Xiaoming)", "yesterday_aggregates", _I,
     "Use the value as of the end of yesterday instead of a same-day one", "continuous", "", "transaction_dttm",
     "", "Still an open proposal in the meeting notes (question 7).",
     "The grammar's lag gives a rolling lag (for example count(24h; lag=24h)), not a calendar day cut; "
     "define which is meant first.", _MEET7 + "; " + _README),
    ("Target encoding for high-cardinality fields (Xiaoming's caution)", "target_encoding", _I,
     "Fraud rate per category for merchant, postal, state and network fields", "continuous", "",
     "merchant_category_xcd;merchant_postal_xcd;merchant_state_xcd;atm_network_xid", "",
     "Do not use many: target encodings correlate with each other (Xiaoming). Use only labels available by "
     "then; train-only or random out-of-fold fitting is not enough. A limited pilot (5-10 files) first.",
     "Not in the recipe grammar; needs label-availability dates.", _MEET2 + "; " + _MEET7 + "; " + _README),
    ("Frequency encoding for high-cardinality fields", "frequency_encoding", _I,
     "How common each category is", "continuous", "", "merchant_category_xcd;merchant_postal_xcd", "",
     "For an ablation against target encoding.", "Not in the recipe grammar.", _MEET2),
    ("Days since the account's first transaction (tenure)", "account_tenure_days", _I,
     "Account age beyond the window", "continuous", "", "transaction_dttm", "obs_days_30 (capped at 30 days)",
     "First observed transaction is not account opening; the extract start censors it.",
     "Needs account opening dates (V22B rank 59 is on hold for this).", _MEET7),
    ("Rolling 90-day lookback window instead of a count window", "rolling_lookback_window", _I,
     "Same calendar span for every account", "", "", "transaction_dttm", "",
     "This is a windowing change, not a feature.",
     "Changes the sequence builder's windowing contract (hashed code); not part of this package.", _MEET7),
]


def other_draft(reg):
    rows = []
    for item, name, status, what, mt, builder, src, ovl, caution, left, record in OTHER:
        built = status != _I
        rows.append({
            "name": name, "item": item, "status": status, "what_it_captures": what, "kind": "engineered",
            "model_type": mt, "recipe": f"a3({name})" if built else "", "builder": builder,
            "source_columns": src, "overlaps_with": ovl, "caution": caution, "left_out_reason": left,
            "record": record, "list_status": "UNCONFIRMED",
        })
        if built:
            a = dict(name=name, origin="proposed (built 26 October)", group="a3", kind="engineered",
                     recipe=f"a3({name})", source_columns=src, model_type=mt, description=what,
                     yaqun_category=yaqun_category(name, mt), business_category=business_category(name),
                     mapping_status="recorded", flags="a3 step", proposed_work_type="built")
            reason = ("owner_answer_a3: Built 26 October; step A3 is off by default, pending the owner's answer." +
                      (" " + caution if caution else ""))
            reg.add(a, "hold", reason, EV_WEEKLY if status == _B else EV_README)
    return rows


# ---------------------------------------------------------------------------------------------
def build(records_root, out_dir, force=False):
    rr = Path(records_root)
    predictors = read_csv(rr / PREDICTORS)
    current_names = [p["feature"] for p in predictors]
    reg = Registry(current_names + ["time_delta"])

    cand_header = header_of(rr / CANDIDATES)
    tfm = tfm_draft(read_csv(rr / CANDIDATES))
    for r in tfm:
        r["name"] = tfm_name_of(r, set(current_names))
    tfm_register(tfm, reg, set(current_names))

    master = [r for r in read_csv(rr / MASTER) if r["category"] == "model_15298_xgboost_feature"]
    cw_header = header_of(rr / CROSSWALK)
    f_draft = f15298_draft(read_csv(rr / CROSSWALK), master, reg, tfm)
    o_draft = other_draft(reg)

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    write_csv(out / TFM_OUT, ["name"] + cand_header, tfm)
    write_csv(out / F15298_OUT, ["name"] + cw_header + F15298_EXTRA, f_draft)
    write_csv(out / OTHER_OUT, OTHER_COLUMNS, o_draft)
    keep_path, attr_path = out / KEEP_OUT, out / ATTR_OUT
    if (keep_path.exists() or attr_path.exists()) and not force:
        print(f"{KEEP_OUT} and {ATTR_OUT} exist: left unchanged (use --force to rewrite them from the records)")
    else:
        write_csv(attr_path, ATTR_COLUMNS, [reg.attrs[n] for n in reg.order])
        write_csv(keep_path, KEEP_COLUMNS, [reg.keep[n] for n in reg.order])
    counts = {}
    for n in reg.order:
        v = reg.keep[n]["verdict"]
        counts[v] = counts.get(v, 0) + 1
    print(f"TFM rows {len(tfm)}, 15298 rows {len(f_draft)}, other proposed rows {len(o_draft)}, "
          f"new feature names {len(reg.order)}: " + ", ".join(f"{k} {v}" for k, v in sorted(counts.items())))
    return reg


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--records-root", default=str(ROOT))
    ap.add_argument("--out", default=str(NF_DIR))
    ap.add_argument("--force", action="store_true", help="rewrite KEEP_DECISIONS.csv from the records")
    a = ap.parse_args(argv)
    rr = Path(a.records_root)
    missing = [n for n in (PREDICTORS, MASTER, CANDIDATES, CROSSWALK) if not (rr / n).is_file()]
    if missing:
        C.say("refused: the records the draft lists are built from are not here (records root "
              f"{rr.name or rr}): " + ", ".join(missing) + ". The shipped lists stay as they are; run this where "
              "the records are, or pass --records-root (exit 4)")
        return 4
    try:
        build(a.records_root, a.out, a.force)
    except (OSError, KeyError, ValueError) as e:
        C.say(f"refused: a record could not be read ({type(e).__name__}: {e}); nothing was replaced (exit 4)",
              file=sys.stderr)
        return 4
    return 0


if __name__ == "__main__":
    sys.exit(main())
