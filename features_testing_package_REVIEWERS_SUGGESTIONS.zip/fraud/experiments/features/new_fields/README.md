New-fields tools for stage 2: intake, checks, enriched copies, the extended artifact, configs, the queue, the reader and importance. Nothing here is under the trainer's source hash.
Run every tool by path from the project root; POD.md is the run sheet, and FEATURES_AND_TESTING.md in the package is the owner's step-by-step.

The extended artifact caps every new code field (the reviewers' decision D9-Y20): a value enters its vocabulary only
when at least 10 distinct accounts carry it over the fit files; rarer and unseen values encode to the unknown index
0. This is features-package functionality, not baseline behaviour: version 1's base fields keep their bytes, and
the field checks report a capped field's unknown shares instead of stopping on them. With no geohash table
configured, the geohash recipe gives the normalized postal code with its country (postal code, capped).
