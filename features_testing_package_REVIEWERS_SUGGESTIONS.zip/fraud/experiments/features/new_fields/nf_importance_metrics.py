"""Paired account uncertainty for fixed-model permutation sensitivity.

The alert budget is a count, and each perturbed score reranks the same rows at
that count. Bootstrap and permutation variation are not training-seed variation.
"""
from __future__ import annotations

from fractions import Fraction
import json

import numpy as np
import pandas as pd


METRICS = ("ap", "udr", "vdr", "fpr")
UNCERTAINTY_NOTE = (
    "90% percentile paired account intervals conditional on this fitted model; "
    "bootstrap and permutation variation are not training-seed uncertainty."
)


def _share(outsort):
    share = Fraction(str(outsort))
    if not 0 < share <= 1:
        raise ValueError("outsort must be a share greater than zero and at most one")
    return share


def _vector(values, n, name):
    values = np.asarray(values)
    if values.ndim != 1 or len(values) != n:
        raise ValueError(f"{name} must have one value per target row")
    return values


def _population(frame):
    if not isinstance(frame, pd.DataFrame) or frame.empty:
        raise ValueError("the target population must be a nonempty dataframe")
    for column in ("account", "id", "label"):
        if column not in frame or frame[column].isna().any():
            raise ValueError(f"nonmissing {column} is required for every target")
    labels = frame["label"].to_numpy()
    if not np.isin(labels, (0, 1)).all():
        raise ValueError("labels must be explicitly encoded 0/1")
    labels = labels.astype(np.int64)
    accounts = frame["account"].astype(str).to_numpy()
    keys = np.asarray([
        json.dumps([str(account), str(identity)])
        for account, identity in zip(frame["account"], frame["id"])
    ])
    if len(set(keys)) != len(keys):
        raise ValueError("each (account, id) must identify exactly one target row")
    _, codes = np.unique(accounts, return_inverse=True)
    key_order = np.argsort(keys, kind="stable")
    key_rank = np.empty(len(keys), dtype=np.int64)
    key_rank[key_order] = np.arange(len(keys))
    amount_reason = None
    values = None
    if "amount" not in frame:
        amount_reason = "amount column missing"
    else:
        amounts = pd.to_numeric(frame["amount"], errors="coerce").to_numpy(dtype=float)
        if not np.isfinite(amounts).all():
            amount_reason = "amount contains missing or non-finite values"
        elif (amounts < 0).any():
            amount_reason = "amount contains negative values"
        else:
            values = amounts * labels
            if values.sum() == 0:
                amount_reason = "zero total fraud amount"
    return labels, codes, values, key_rank, amount_reason


class RankedScore:
    """Sort once, then evaluate integer account multiplicities in linear time.

    AP groups tied scores at one threshold. The alert cut breaks ties by a
    label-independent identity rank and includes boundary copies only up to the
    integer budget. AP is 1 for all-positive targets and undefined for no frauds.
    """

    def __init__(self, scores, labels, codes, fraud_values, key_rank, outsort="0.006"):
        labels = np.asarray(labels)
        scores = _vector(scores, len(labels), "scores").astype(float)
        if not np.isfinite(scores).all() or ((scores < 0) | (scores > 1)).any():
            raise ValueError("scores must be finite probabilities in [0, 1]")
        if labels.ndim != 1 or not len(labels) or not np.isin(labels, (0, 1)).all():
            raise ValueError("labels must be nonempty and explicitly encoded 0/1")
        codes = _vector(codes, len(labels), "account codes")
        if not np.issubdtype(codes.dtype, np.integer) or (codes < 0).any():
            raise ValueError("account codes must be nonnegative integers")
        key_rank = _vector(key_rank, len(labels), "identity ranks")
        order = np.lexsort((key_rank, -scores))
        self.labels = labels.astype(np.int64)[order]
        self.codes = codes[order]
        self.n_accounts = int(codes.max()) + 1
        self.values = None
        if fraud_values is not None:
            values = _vector(fraud_values, len(labels), "fraud values").astype(float)
            if not np.isfinite(values).all() or (values < 0).any():
                raise ValueError("fraud values must be finite and nonnegative")
            self.values = values[order]
        sorted_scores = scores[order]
        self.ends = np.flatnonzero(np.r_[sorted_scores[1:] != sorted_scores[:-1], True])
        self.share = _share(outsort)

    def evaluate(self, multiplicity):
        multiplicity = _vector(multiplicity, self.n_accounts, "account multiplicities")
        if not np.issubdtype(multiplicity.dtype, np.integer) or (multiplicity < 0).any():
            raise ValueError("account multiplicities must be nonnegative integers")
        weights = multiplicity[self.codes].astype(np.int64)
        cumulative = np.cumsum(weights)
        cumulative_frauds = np.cumsum(weights * self.labels)
        rows = int(cumulative[-1])
        frauds = int(cumulative_frauds[-1])
        alerts = rows * self.share.numerator // self.share.denominator
        if frauds:
            true_positives = cumulative_frauds[self.ends]
            increments = np.diff(true_positives, prepend=0)
            precision = true_positives / np.maximum(cumulative[self.ends], 1)
            ap = float(np.dot(increments, precision) / frauds)
        else:
            ap = np.nan
        cumulative_values = None if self.values is None else np.cumsum(weights * self.values)
        fraud_amount = None if cumulative_values is None else float(cumulative_values[-1])
        if alerts:
            boundary = int(np.searchsorted(cumulative, alerts, side="left"))
            previous = int(cumulative[boundary - 1]) if boundary else 0
            copies = alerts - previous
            caught = (int(cumulative_frauds[boundary - 1]) if boundary else 0)
            caught += copies * int(self.labels[boundary])
            captured_amount = None
            if cumulative_values is not None:
                captured_amount = float(cumulative_values[boundary - 1]) if boundary else 0.0
                captured_amount += copies * float(self.values[boundary])
        else:
            caught, captured_amount = 0, 0.0
        return {
            "ap": ap,
            "udr": caught / frauds if frauds else np.nan,
            "vdr": captured_amount / fraud_amount if fraud_amount else np.nan,
            "fpr": (alerts - caught) / caught if caught else np.nan,
            "rows": rows, "frauds": frauds, "alerts": alerts,
            "frauds_caught": caught,
        }


def multiplicity_draws(n_accounts, draws=2000, seed=20261102):
    """Stream whole-account draws in canonical account order."""
    if not isinstance(n_accounts, (int, np.integer)) or n_accounts < 1:
        raise ValueError("at least one account is required")
    if not isinstance(draws, (int, np.integer)) or draws < 2:
        raise ValueError("bootstrap draws must be an integer at least two")
    rng = np.random.default_rng(seed)
    for _ in range(draws):
        yield np.bincount(rng.integers(0, n_accounts, n_accounts), minlength=n_accounts)


def point_metrics(frame, scores, *, multiplicity=None, outsort="0.006"):
    """Point measures, optionally using a canonical account multiplicity vector."""
    labels, codes, values, key_rank, amount_reason = _population(frame)
    ranked = RankedScore(scores, labels, codes, values, key_rank, outsort)
    if multiplicity is None:
        multiplicity = np.ones(ranked.n_accounts, dtype=np.int64)
    result = ranked.evaluate(multiplicity)
    result["accounts"] = ranked.n_accounts
    result["amount_reason"] = amount_reason
    result["ap_reason"] = "no fraud targets" if result["frauds"] == 0 else None
    return result


def summarize_unit(frame, baseline_scores, repeat_scores, *, draws=2000,
                   seed=20261102, outsort="0.006"):
    """Flat report for one unit; mean repeated drops within each paired draw.

    Call with the identical frame, seed and draws for every unit. Account draws
    then match across the entire importance table. Undefined repeats are not
    silently discarded: a draw is valid only if every repeated contrast exists.
    """
    labels, codes, values, key_rank, amount_reason = _population(frame)
    repeat_scores = np.asarray(repeat_scores, dtype=float)
    if repeat_scores.ndim == 1:
        repeat_scores = repeat_scores.reshape(1, -1)
    if repeat_scores.ndim != 2 or repeat_scores.shape[0] < 1 or repeat_scores.shape[1] != len(frame):
        raise ValueError("repeat_scores must contain at least one aligned score vector")
    baseline = RankedScore(baseline_scores, labels, codes, values, key_rank, outsort)
    repeated = [RankedScore(score, labels, codes, values, key_rank, outsort) for score in repeat_scores]
    ones = np.ones(baseline.n_accounts, dtype=np.int64)
    base_point = baseline.evaluate(ones)
    repeat_points = [ranked.evaluate(ones) for ranked in repeated]
    differences = {metric: [] for metric in METRICS}
    for multiplicity in multiplicity_draws(baseline.n_accounts, draws, seed):
        base = baseline.evaluate(multiplicity)
        others = [ranked.evaluate(multiplicity) for ranked in repeated]
        for metric in METRICS:
            contrast = np.asarray([base[metric] - other[metric] for other in others])
            differences[metric].append(float(contrast.mean()) if np.isfinite(contrast).all() else np.nan)
    report = {
        "rows": len(frame), "frauds": int(labels.sum()), "accounts": baseline.n_accounts,
        "alerts": base_point["alerts"], "repeats": len(repeated),
        "bootstrap_draws": int(draws), "bootstrap_seed": int(seed),
        "outsort_share": float(baseline.share),
        "amount_reason": amount_reason,
        "ap_reason": "no fraud targets" if not labels.sum() else None,
        "uncertainty_note": UNCERTAINTY_NOTE,
    }
    for metric in METRICS:
        points = np.asarray([point[metric] for point in repeat_points], dtype=float)
        deltas = base_point[metric] - points
        complete = np.isfinite(deltas).all()
        sampling = np.asarray(differences[metric])
        finite = sampling[np.isfinite(sampling)]
        low, high = np.quantile(finite, [.05, .95]) if len(finite) >= 2 else (np.nan, np.nan)
        report.update({
            f"baseline_{metric}": base_point[metric],
            f"perturbed_{metric}": float(points.mean()) if np.isfinite(points).all() else np.nan,
            f"drop_{metric}": float(deltas.mean()) if complete else np.nan,
            f"drop_{metric}_ci_low": float(low),
            f"drop_{metric}_ci_high": float(high),
            f"drop_{metric}_ci_reason": (
                "fewer than two finite paired bootstrap draws" if len(finite) < 2 else None
            ),
            f"drop_{metric}_draws_valid": int(len(finite)),
            f"drop_{metric}_draws_undefined": int(draws - len(finite)),
            f"drop_{metric}_repeat_sd": float(deltas.std(ddof=1)) if complete and len(deltas) > 1 else np.nan,
            f"drop_{metric}_repeat_min": float(deltas.min()) if complete else np.nan,
            f"drop_{metric}_repeat_max": float(deltas.max()) if complete else np.nan,
        })
    return report
