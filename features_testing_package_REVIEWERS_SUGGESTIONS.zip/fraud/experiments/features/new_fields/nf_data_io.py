"""File access and Arrow hashing for the enriched copies and the artifact tools.

Paths are local or ``s3://``. S3 goes through the project's own ``make_s3_filesystem`` (resolver key ``s3``).
The column hash is canonical: the same values, nulls and type give the same SHA-256 whatever the chunking,
the row-group layout or the bytes under a null slot. Importing this module does no work.
"""

from __future__ import annotations

import hashlib
import os
import posixpath
import sys
from pathlib import Path
from typing import Iterable, List, Optional

import numpy as np
import pyarrow as pa
import pyarrow.compute as pc
import pyarrow.parquet as pq

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))


def is_s3(path: str) -> bool:
    return str(path).startswith(("s3://", "s3a://"))


def strip(path: str) -> str:
    p = str(path)
    for pre in ("s3://", "s3a://"):
        if p.startswith(pre):
            return p[len(pre):]
    return p


def join(base: str, *parts: str) -> str:
    base = str(base).rstrip("/")
    return posixpath.join(base, *parts) if is_s3(base) else str(Path(base, *parts))


class Store:
    """Local or S3 access with one interface. ``cred_path`` is read only when a path is on S3."""

    def __init__(self, cred_path: Optional[str] = None):
        self.cred_path = cred_path
        self._fs = None

    def fs(self, path: str):
        if not is_s3(path):
            return None
        if self._fs is None:
            import nf_layout
            make = nf_layout.attr("s3", "make_s3_filesystem")
            self._fs = make(self.cred_path) if self.cred_path else make()
        return self._fs

    def exists(self, path: str) -> bool:
        fs = self.fs(path)
        return fs.exists(strip(path)) if fs is not None else os.path.exists(path)

    def listdir(self, path: str) -> List[str]:
        """Every file under ``path`` (recursive), as full paths; empty when the folder does not exist."""
        fs = self.fs(path)
        if fs is not None:
            if not fs.exists(strip(path)):
                return []
            pre = "s3://" if str(path).startswith("s3://") else "s3a://"
            return sorted(pre + p for p in fs.find(strip(path)))
        if not os.path.isdir(path):
            return [path] if os.path.isfile(path) else []
        out = []
        for d, _, files in os.walk(path):
            out += [os.path.join(d, f) for f in files]
        return sorted(out)

    def read_bytes(self, path: str) -> bytes:
        fs = self.fs(path)
        if fs is not None:
            with fs.open(strip(path), "rb") as f:
                return f.read()
        with open(path, "rb") as f:
            return f.read()

    def write_bytes(self, path: str, data: bytes) -> None:
        fs = self.fs(path)
        if fs is not None:
            with fs.open(strip(path), "wb") as f:
                f.write(data)
            return
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        tmp = f"{path}.tmp"
        with open(tmp, "wb") as f:
            f.write(data)
        os.replace(tmp, path)

    def size(self, path: str) -> int:
        fs = self.fs(path)
        return int(fs.size(strip(path))) if fs is not None else os.path.getsize(path)

    def read_table(self, path: str, columns: Optional[Iterable[str]] = None) -> pa.Table:
        fs = self.fs(path)
        cols = list(columns) if columns is not None else None
        if fs is not None:
            return pq.ParquetDataset(strip(path), filesystem=fs).read(columns=cols)
        return pq.read_table(path, columns=cols)

    def schema(self, path: str) -> pa.Schema:
        fs = self.fs(path)
        if fs is not None:
            with fs.open(strip(path), "rb") as f:
                return pq.ParquetFile(f).schema_arrow
        return pq.ParquetFile(path).schema_arrow

    def write_table(self, table: pa.Table, path: str) -> None:
        fs = self.fs(path)
        if fs is not None:
            with fs.open(strip(path), "wb") as f:
                pq.write_table(table, f)
            return
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        tmp = f"{path}.tmp"
        pq.write_table(table, tmp)
        os.replace(tmp, path)

    def copy(self, src: str, dst: str) -> None:
        """Byte for byte."""
        self.write_bytes(dst, self.read_bytes(src))


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _fixed_bytes(arr: pa.Array, valid: np.ndarray) -> bytes:
    width = arr.type.bit_width // 8
    buf = arr.buffers()[1]
    raw = np.frombuffer(buf, dtype=np.uint8)[arr.offset * width:(arr.offset + len(arr)) * width].copy()
    raw = raw.reshape(len(arr), width)
    raw[~valid] = 0  # bytes under a null slot carry no meaning
    return raw.tobytes()


def column_sha256(col) -> str:
    """Canonical SHA-256 of one Arrow column: its type, length, null positions and values."""
    arr = col.combine_chunks() if isinstance(col, pa.ChunkedArray) else col
    if isinstance(arr, pa.ChunkedArray):  # older pyarrow returns a ChunkedArray for an empty column
        arr = pa.concat_arrays(arr.chunks) if arr.num_chunks else pa.array([], type=arr.type)
    h = hashlib.sha256()
    h.update(str(arr.type).encode())
    h.update(str(len(arr)).encode())
    if pa.types.is_dictionary(arr.type):
        arr = arr.dictionary_decode()
    valid = arr.is_valid().to_numpy(zero_copy_only=False).astype(bool) if len(arr) else np.zeros(0, dtype=bool)
    h.update(np.packbits(valid).tobytes())
    t = arr.type
    if len(arr) == 0:
        pass
    elif pa.types.is_boolean(t):
        h.update(np.packbits(pc.fill_null(arr, False).to_numpy(zero_copy_only=False).astype(bool)).tobytes())
    elif (pa.types.is_integer(t) or pa.types.is_floating(t) or pa.types.is_temporal(t)
          or pa.types.is_decimal(t) or pa.types.is_fixed_size_binary(t)) and t.bit_width % 8 == 0:
        h.update(_fixed_bytes(arr, valid))
    elif pa.types.is_string(t) or pa.types.is_large_string(t) or pa.types.is_binary(t) or pa.types.is_large_binary(t):
        filled = pc.fill_null(arr, "" if (pa.types.is_string(t) or pa.types.is_large_string(t)) else b"")
        big = filled.cast(pa.large_binary())
        offs = np.frombuffer(big.buffers()[1], dtype=np.int64)[big.offset:big.offset + len(big) + 1]
        data = big.buffers()[2]
        start, stop = int(offs[0]), int(offs[-1])
        h.update((offs - offs[0]).tobytes())
        h.update(memoryview(data)[start:stop] if data is not None else b"")
    else:
        # nested and other types: the values as JSON (nulls and values only, never the bytes under a null)
        import json as _json
        h.update(_json.dumps(arr.to_pylist(), default=str, sort_keys=True).encode())
    return h.hexdigest()


def sequence_sha256(table: pa.Table, columns: List[str]) -> str:
    """SHA-256 of the row sequence of ``columns`` (each column's canonical hash, in order)."""
    h = hashlib.sha256()
    for c in columns:
        h.update(c.encode())
        h.update(column_sha256(table.column(c)).encode())
    return h.hexdigest()
