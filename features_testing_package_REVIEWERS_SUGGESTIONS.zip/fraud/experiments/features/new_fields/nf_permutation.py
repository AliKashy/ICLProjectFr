"""Repeatable donor substitutions before overlapping windows are constructed.

The mapping belongs to source events, not to their later copies in model windows.
The caller supplies the existing recipe engine for a family perturbation.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from typing import Callable, Sequence

import numpy as np
import pandas as pd


_METHODS = {"source", "family", "single_output_possibly_inconsistent"}
_CALENDAR_NAMES = {
    "month", "day", "day_of_month", "day_of_week", "dayofweek", "weekday",
    "hour", "minute", "second", "hour_sin", "hour_cos", "dow_sin", "dow_cos",
    "month_sin", "month_cos", "day_sin", "day_cos",
}


@dataclass(frozen=True)
class Unit:
    """One joint substitution with an explicit source and output contract."""

    name: str
    members: Sequence[str]
    kind: str = "single"
    method: str = "single_output_possibly_inconsistent"
    donor_unit: str = "event"
    source_columns: Sequence[str] = ()
    dependent_outputs: Sequence[str] = ()
    artificial_time_fixed: bool = False

    def __post_init__(self):
        if not self.name or not self.members:
            raise ValueError("A unit needs a name and at least one member")
        if self.method not in _METHODS:
            raise ValueError(f"Unknown perturbation method: {self.method}")
        if self.donor_unit not in {"event", "account"}:
            raise ValueError("donor_unit must be event or account")
        for name in ("members", "source_columns", "dependent_outputs"):
            values = getattr(self, name)
            if isinstance(values, str) or any(not isinstance(x, str) or not x for x in values):
                raise ValueError(f"{name} must be a sequence of column names")
            if len(set(values)) != len(values):
                raise ValueError(f"{name} contains duplicate column names")
            object.__setattr__(self, name, tuple(values))
        if self.method == "family" and (not self.source_columns or not self.dependent_outputs):
            raise ValueError("A family needs source_columns and dependent_outputs")
        if self.method != "family" and self.dependent_outputs:
            raise ValueError("Dependent outputs require the family method")


def _encoded(value) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _account_keys(frame: pd.DataFrame, account_col: str) -> np.ndarray:
    if account_col not in frame:
        raise ValueError(f"Missing account column: {account_col}")
    if frame[account_col].isna().any():
        raise ValueError("Account identities contain missing values")
    return frame[account_col].astype(str).to_numpy()


def select_accounts(
    frame: pd.DataFrame,
    share: float,
    account_col: str,
    salt: str = "feature-importance-accounts",
) -> pd.DataFrame:
    """Keep a repeatable hash fraction of whole accounts, including their history.

    The selection is independent of file order, row order and the perturbation.
    It is a hash sample, so the realized fraction need not equal ``share``.
    """
    if not np.isfinite(share) or not 0 < share <= 1:
        raise ValueError("account share must be in (0, 1]")
    accounts = _account_keys(frame, account_col)
    if share == 1:
        return frame.copy(deep=True)
    cutoff = int(share * (1 << 256))
    selected = {
        account: int.from_bytes(hashlib.sha256(_encoded([salt, account]).encode()).digest(), "big") < cutoff
        for account in set(accounts)
    }
    mask = np.fromiter((selected[a] for a in accounts), dtype=bool, count=len(accounts))
    return frame.loc[mask].copy(deep=True)


def _event_keys(frame, account_col, id_col):
    accounts = _account_keys(frame, account_col)
    if id_col not in frame or frame[id_col].isna().any():
        raise ValueError("Event identities are missing or contain missing values")
    ids = frame[id_col].astype(str).to_numpy()
    keys = np.asarray([_encoded([a, i]) for a, i in zip(accounts, ids)], dtype=object)
    if len(set(keys)) != len(keys):
        raise ValueError("Duplicate account/event identities in the source file")
    return accounts, keys


def _mapping(keys, unit, seed, repeat, file_key, identity):
    """Return donor row positions; sorted identities make row order irrelevant."""
    positions = np.argsort(keys, kind="stable")
    material = [int(seed), int(repeat), str(file_key), unit.name, unit.donor_unit]
    digest = hashlib.sha256(_encoded(material).encode()).digest()
    rng = np.random.default_rng(int.from_bytes(digest, "big"))
    donors = positions if identity else rng.permutation(positions)
    mapped = np.empty(len(keys), dtype=np.int64)
    mapped[positions] = donors
    return mapped


def _account_positions(frame, accounts, columns, unit, seed, repeat, file_key, identity):
    unique, first, inverse = np.unique(accounts, return_index=True, return_inverse=True)
    # A profile donor is a whole account's static profile, not an arbitrary event.
    # Non-static profile recipes need a separately specified temporal donor policy.
    for column in columns:
        counts = frame[column].groupby(accounts, sort=False, dropna=False).nunique(dropna=False)
        if (counts > 1).any():
            raise ValueError(f"Account donor requires a static profile field: {column}")
    donor_accounts = _mapping(unique, unit, seed, repeat, file_key, identity)
    return first[donor_accounts[inverse]]


def _equal_column(left, right) -> bool:
    return left.equals(right)


def perturb_frame(
    frame: pd.DataFrame,
    unit: Unit,
    *,
    seed: int,
    repeat: int,
    file_key: str,
    account_col: str,
    id_col: str,
    time_col: str,
    label_col: str,
    recompute: Callable[[pd.DataFrame, Unit], pd.DataFrame] | None = None,
    identity: bool = False,
    immutable_columns: Sequence[str] = (),
) -> tuple[pd.DataFrame, dict]:
    """Substitute jointly at source events and optionally rebuild a recipe family.

    The callback receives ``(changed_frame, unit)`` and must return the same rows
    in the same order. It may change only ``dependent_outputs`` beyond the source
    columns. Single-output substitutions deliberately leave sibling inputs alone.
    Identity mode returns an exact copy and does not recompute recipes.
    """
    if frame.columns.duplicated().any():
        raise ValueError("Duplicate dataframe columns")
    protected = set((account_col, id_col, time_col, label_col)) | set(immutable_columns)
    missing = protected.difference(frame.columns)
    if missing:
        raise ValueError(f"Missing immutable columns: {sorted(missing)}")
    accounts, keys = _event_keys(frame, account_col, id_col)
    columns = tuple(unit.members if unit.method == "single_output_possibly_inconsistent"
                    else (unit.source_columns or unit.members))
    allowed = set(columns) | set(unit.dependent_outputs)
    if protected & allowed:
        raise ValueError(f"Cannot perturb immutable columns: {sorted(protected & allowed)}")
    absent = set(columns).difference(frame.columns)
    if absent:
        raise ValueError(f"Missing donor columns: {sorted(absent)}")
    if unit.method == "family" and recompute is None:
        raise ValueError("Family perturbation requires the recipe recompute callback")
    if repeat < 0:
        raise ValueError("repeat must be nonnegative")

    if unit.donor_unit == "account":
        donors = _account_positions(frame, accounts, columns, unit, seed, repeat, file_key, identity)
    else:
        donors = _mapping(keys, unit, seed, repeat, file_key, identity)
    changed = frame.copy(deep=True)
    if not identity:
        for column in columns:
            # ExtensionArray assignment is positional and keeps nullable/category types.
            changed[column] = frame[column].iloc[donors].array.copy()
        if unit.method == "family":
            changed = recompute(changed, unit)
            if not isinstance(changed, pd.DataFrame):
                raise ValueError("The recipe callback must return a dataframe")
            if changed.columns.duplicated().any():
                raise ValueError("The recipe callback returned duplicate columns")
            absent = set(unit.dependent_outputs).difference(changed.columns)
            if absent:
                raise ValueError(f"Recipe callback omitted dependent outputs: {sorted(absent)}")
    if len(changed) != len(frame) or not changed.index.equals(frame.index):
        raise ValueError("Recipe callback changed row membership or order")
    if set(changed.columns).difference(frame.columns).difference(unit.dependent_outputs):
        raise ValueError("Recipe callback added undeclared columns")
    for column in frame.columns:
        if column not in changed:
            raise ValueError(f"Recipe callback removed a column: {column}")
        if column not in allowed and not _equal_column(frame[column], changed[column]):
            raise ValueError(f"Recipe callback changed an undeclared or immutable column: {column}")
    if not changed.columns[:len(frame.columns)].equals(frame.columns):
        raise ValueError("Recipe callback changed the original column order")

    mapping_digest = hashlib.sha256()
    for index in np.argsort(keys, kind="stable"):
        # Account profiles have no privileged representative event. Record the
        # donor account, so its arbitrary first row cannot change this identity.
        donor_key = accounts[donors[index]] if unit.donor_unit == "account" else keys[donors[index]]
        mapping_digest.update(_encoded([keys[index], donor_key]).encode())
        mapping_digest.update(b"\n")
    row_changed = np.zeros(len(frame), dtype=bool)
    for column in columns:
        equal = frame[column].eq(changed[column]) | (frame[column].isna() & changed[column].isna())
        row_changed |= ~equal.fillna(False).to_numpy(dtype=bool)
    calendar = unit.artificial_time_fixed or any(
        name.lower() in _CALENDAR_NAMES for name in unit.members
    )
    audit = {
        "unit": unit.name,
        "members": list(unit.members),
        "kind": unit.kind,
        "method": unit.method,
        "donor_unit": unit.donor_unit,
        "source_columns": list(columns),
        "dependent_outputs": list(unit.dependent_outputs),
        "interpretation": "artificial_time_fixed" if calendar else unit.method,
        "seed": int(seed),
        "repeat": int(repeat),
        "file_key": str(file_key),
        "identity": bool(identity),
        "source_rows": len(frame),
        "accounts": len(set(accounts)),
        "changed_source_rows": int(row_changed.sum()),
        "donor_mapping_sha256": mapping_digest.hexdigest(),
    }
    return changed, audit
