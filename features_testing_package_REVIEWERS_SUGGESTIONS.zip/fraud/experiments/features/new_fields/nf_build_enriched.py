"""Enriched parquet copies with the engineered columns, and a per-file identity proof (design 4.1).

Each copy holds every original column, unchanged and in its original order, then one column per engineered
field (numbers as float64, codes as text), in the map's order. Rows keep their order. Each file's columns are
built from all of that file's rows (every account's whole history in the split), before any target is chosen.

The identity proof, per file (C2/enriched/identity/<range>/part_<n>.json): the same row count; the same sequence
of (account, transaction id); every original column's canonical Arrow SHA-256 equal to the original's, and the
columns equal; the new columns' names and types as the map says. A failure deletes nothing, stops the build
(exit 3) and names the file and column.

Refusals (exit 4): an existing output prefix (unless --resume), any UNCONFIRMED map row, a map newer than
field_status.csv, an engineered name that is already a column of a file, a non-account history key whose values
sit in more than one file of a range, TFM's geohash table unreadable when a geohash field is built (before the
first file; an S3 table is read with the data's credentials).

Pairing note (design review item 14): the copies keep every row in the same order, so the file partition is the
control's. With num_workers above 0 the window order inside a worker can still differ between two models of
different width; only num_workers 0 gives the same window order.

Usage (Copilot adapts paths only):
    CUDA_VISIBLE_DEVICES= nice -n 19 $PY fraud/experiments/features/new_fields/nf_build_enriched.py \
        --map fraud/experiments/features/new_fields/FIELD_MAP.csv \
        --status checkpoints/new_fields/checks/field_status.csv
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path(__file__).resolve().parents[4]
for _p in (str(HERE), str(ROOT / "src"), str(ROOT)):
    if _p in sys.path:
        sys.path.remove(_p)
    sys.path.insert(0, _p)


def _parser():
    p = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    p.add_argument("--map", default=None, help="field map (default NF/FIELD_MAP.csv)")
    p.add_argument("--status", default=None, help="field_status.csv (default C2/checks/field_status.csv)")
    p.add_argument("--out", default=None, help="enriched root (default SETTINGS.yaml enriched_root)")
    p.add_argument("--ranges", nargs="*", default=None, help="range names (default every population range)")
    p.add_argument("--range", action="append", default=[], help="override one range: name=start-end")
    p.add_argument("--train-base", default=None, help="raw training base (default the chosen config's)")
    p.add_argument("--eval-base", default=None, help="raw evaluation base (default the chosen config's)")
    p.add_argument("--cred-path", default=None, help="S3 credentials file (default the chosen config's)")
    p.add_argument("--resume", action="store_true", help="keep files whose identity proof passed; build the rest")
    p.add_argument("--first-only", action="store_true", help="build and prove one file, print the projection, stop")
    return p


def main(argv=None) -> int:
    args = _parser().parse_args(argv)
    import nf_layout
    nf_layout.bootstrap()
    import nf_common as C
    import nf_data_fields as F
    import nf_data_io as io
    import nf_recipes as R

    lay = nf_layout.resolve(["strict_window", "groups", "features_new", "s3"])
    layout_line = f"layout={'reorganized' if lay.layout == nf_layout.REORGANIZED else 'fallback'}"
    settings = C.settings()
    map_path = Path(args.map) if args.map else C.NF / "FIELD_MAP.csv"
    status_path = Path(args.status) if args.status else C.out("checks", "field_status.csv")
    try:
        map_df = C.read_field_map(map_path)
        status = F.read_status(status_path)
        fields = F.select_fields(map_df, status, map_path, status_path, engineered_only=True)
        cfg = C.load_yaml(C.ROOT / settings.get("base_config", "fraud/configs/sequential_hier_allpos.yaml")) \
            if (args.train_base is None or args.eval_base is None) else {}
        tb, eb, cred = F.base_config_paths(cfg) if cfg else (None, None, None)
        train_base, eval_base = args.train_base or tb, args.eval_base or eb
        cred = args.cred_path or cred
        ranges = F.file_ranges(settings.get("populations", {}), train_base, eval_base, args.ranges,
                               F.parse_range_overrides(args.range))
    except F.Refused as e:
        return e.code
    out_root = args.out or settings.get("enriched_root")
    if not fields:
        C.print_screen("ENRICHED COPIES  nothing to build", [
            "no CONFIRMED engineered field passed the checks; steps read the original files"])
        return C.OK
    store = io.Store(cred)
    existing = store.listdir(out_root)
    if existing and not args.resume:
        C.say(f"refused: {out_root} already holds {len(existing)} file(s); choose a new prefix or --resume (exit 4)",
              file=sys.stderr)
        return C.REFUSED
    engine = R.load_engine()
    field_spec = [(f.name, f.recipe, f.model_type) for f in fields]
    want_type = {f.name: ("double" if f.model_type == "continuous" else "string") for f in fields}

    # A history key other than the account must sit in one file of a range (design 2.2).
    other_keys = sorted({f.parsed.key for f in fields if f.parsed.key})
    by_base = {}
    for rg in ranges:  # every file built from one base: a key value must sit in one of them
        by_base.setdefault(rg.base, {}).update(dict(rg.files()))
    for base_files in by_base.values():
        for key in other_keys:
            seen = {}
            for n, path in sorted(base_files.items()):
                vals = store.read_table(path, [key]).column(key).to_pylist()
                for v in set(vals) - {None}:
                    if v in seen and seen[v] != n:
                        C.say(f"STOP: history key {key} value {v!r} sits in part_{seen[v]} and part_{n}; "
                              "recipes keyed on it cannot be built per file (exit 3)", file=sys.stderr)
                        return C.STOP
                    seen[v] = n

    # TFM's geohash table shapes every geohash field: read once here, with the data's credentials (an unreadable
    # table refuses), and every file is built with this one table. Its SHA-256 joins each proof, so --resume never
    # keeps a copy built with another table.
    geo = [f.name for f in fields if f.parsed.op == "geohash"]
    try:
        geo_table = R.load_geohash_table(cred_path=cred or None) if geo else None
    except R.RecipeError as e:
        print(f"refused: {', '.join(geo)}: {e} (exit 4)", file=sys.stderr)
        return C.REFUSED
    geo_sha = geo_table.sha256 if geo_table is not None else None
    meta = {"recipes_sha256": C.sha256_file(HERE / "nf_recipes.py"),
            "map": C.rel(map_path), "map_sha256": C.sha256_file(map_path),
            "status": C.rel(status_path), "status_sha256": C.sha256_file(status_path),
            "geohash_table_sha256": geo_sha,
            "out_root": out_root, "fields": [{"name": f.name, "recipe": f.recipe, "model_type": f.model_type,
                                              "group": f.group} for f in fields]}
    summary = {"files": [], **meta, "layout": lay.layout}
    first_done = False
    t_start = time.time()
    for rg in ranges:
        sub = Path(rg.base.rstrip("/")).name if not io.is_s3(rg.base) else rg.base.rstrip("/").split("/")[-1]
        for n, src in rg.files():
            dst = io.join(out_root, sub, f"part_{n}.parquet")
            proof_path = C.out("enriched", "identity", rg.name, f"part_{n}.json")
            if args.resume and proof_path.exists() and store.exists(dst):
                old = C.read_json(proof_path)
                if kept_copy_ok(store, old, dst, meta, rg, field_spec):
                    summary["files"].append({"range": rg.name, "file": n, "result": "PASS", "kept": True})
                    continue
            t0 = time.time()
            try:
                proof = build_one(store, src, dst, rg, n, field_spec, want_type, engine, meta, geo_table)
            except (R.RecipeError, OverflowError, ValueError) as e:
                C.say(f"refused: {rg.name} part_{n}: {e} (exit 4)", file=sys.stderr)
                return C.REFUSED
            proof["seconds"] = round(time.time() - t0, 3)
            C.write_json(proof_path, proof)
            summary["files"].append({"range": rg.name, "file": n, "result": proof["result"],
                                     "rows": proof["rows"]["copy"], "fail": proof["failures"][:3]})
            if proof["result"] != "PASS":
                C.write_json(C.out("enriched", "summary.json"), summary)
                C.print_screen(f"ENRICHED COPIES  STOP  {rg.name} part_{n}", [
                    f"identity proof failed: {fl}" for fl in proof["failures"][:30]],
                    f"proof: {C.rel(proof_path)}; nothing was deleted (exit 3)")
                return C.STOP
            if not first_done:
                first_done = True
                todo = [p for r2 in ranges for _, p in r2.files()]
                src_size = max(store.size(src), 1)
                ratio = store.size(dst) / src_size
                total_src = sum(store.size(p) for p in todo if store.exists(p))
                C.print_screen("ENRICHED COPIES  first file measured", [
                    f"{rg.name} part_{n}: {proof['rows']['copy']} rows, {proof['seconds']} s, "
                    f"copy/original size {ratio:.2f}",
                    f"projected: {len(todo)} files, about {total_src * ratio / 1e9:.1f} GB, "
                    f"about {proof['seconds'] * len(todo) / 3600:.2f} h",
                ])
                if args.first_only:
                    C.write_json(C.out("enriched", "summary.json"), summary)
                    return C.OK
    summary["seconds"] = round(time.time() - t_start, 1)
    C.write_json(C.out("enriched", "summary.json"), summary)
    lines = [f"{layout_line} | map {meta['map_sha256'][:12]} | status {meta['status_sha256'][:12]}",
             f"fields built: {len(fields)} | files: {len(summary['files'])} | all identity proofs PASS",
             "row order is the original's: the file partition is the control's; window order matches only "
             "with num_workers 0 (review item 14)"]
    for rg in ranges:
        k = [f for f in summary["files"] if f["range"] == rg.name]
        lines.append(f"  {rg.name:10s} part_{rg.start}..part_{rg.end}: {len(k)} files PASS "
                     f"(extract start {rg.extract_start})")
    C.print_screen("ENRICHED COPIES  PASS", lines, f"proofs: {C.rel(C.out('enriched', 'identity'))}")
    return C.OK


def kept_copy_ok(store, old, dst, meta, rg, field_spec) -> bool:
    """A kept copy must match this run in every input that shapes it, and its new columns must still hash as
    recorded: map, check results, recipe code, TFM's geohash table, extract start and field list."""
    import nf_data_io as io
    if old.get("result") != "PASS":
        return False
    for k in ("map_sha256", "status_sha256", "recipes_sha256", "geohash_table_sha256"):
        if old.get(k) != meta.get(k):
            return False
    if old.get("extract_start") != rg.extract_start:
        return False
    recorded = {k: (v.get("recipe"), v.get("model_type")) for k, v in old.get("new_columns", {}).items()}
    if recorded != {f[0]: (f[1], f[2]) for f in field_spec}:
        return False
    names = [f[0] for f in field_spec]
    if store.schema(dst).names[-len(names):] != names:
        return False
    back = store.read_table(dst, names)
    return all(io.column_sha256(back.column(n)) == old["new_columns"][n]["sha256"] for n in names)


def build_one(store, src, dst, rg, n, field_spec, want_type, engine, meta, geohash_table=None):
    """Build one copy, write it, read it back and prove it. Returns the proof. ``geohash_table`` is the table the
    run read once (None reads SETTINGS.yaml's)."""
    import pyarrow as pa
    import nf_data_io as io
    import nf_recipes as R

    import nf_common as C
    orig = store.read_table(src)
    names = orig.column_names
    for name, _, _ in field_spec:
        if name in names:
            raise R.RecipeError(f"{name} is already a column of the file; an engineered name must be new")
    need = {R.ACCOUNT, R.TIME}
    if R.TIE in names:
        need.add(R.TIE)
    for _, text, _ in field_spec:
        need.update(c for c in R.parse(text).sources if c in names)
    df = orig.select([c for c in names if c in need]).to_pandas()
    frame, stats = R.build_columns(df, field_spec, rg.extract_start, engine=engine, geohash_table=geohash_table)
    table = orig
    for name, _, mt in field_spec:
        if mt == "continuous":
            arr = pa.array(frame[name].to_numpy(dtype="float64"), type=pa.float64(), from_pandas=True)
        else:
            arr = pa.array(list(frame[name]), type=pa.string())
        table = table.append_column(name, arr)
    store.write_table(table, dst)
    back = store.read_table(dst)
    failures = []
    rows = {"original": orig.num_rows, "copy": back.num_rows}
    if back.num_rows != orig.num_rows:
        failures.append(f"row count {orig.num_rows} -> {back.num_rows}")
    id_cols = [c for c in (R.ACCOUNT, R.TIE) if c in names]
    seq = {"original": io.sequence_sha256(orig, id_cols),
           "copy": io.sequence_sha256(back, id_cols) if all(c in back.column_names for c in id_cols) else ""}
    if seq["original"] != seq["copy"]:
        failures.append(f"(account, transaction id) sequence differs ({', '.join(id_cols)})")
    if back.column_names[:len(names)] != names:
        failures.append("original column order changed")
    cols = {}
    for c in names:
        a = io.column_sha256(orig.column(c))
        b = io.column_sha256(back.column(c)) if c in back.column_names else ""
        # the canonical hash is the proof (Arrow's equals treats NaN as unequal to itself)
        eq = c in back.column_names and a == b
        cols[c] = {"sha256_original": a, "sha256_copy": b, "equal": bool(eq)}
        if not eq:
            failures.append(f"column {c}: hash or values differ")
    new = {}
    extra = back.column_names[len(names):]
    if extra != [f[0] for f in field_spec]:
        failures.append(f"new columns {extra} differ from the map's {[f[0] for f in field_spec]}")
    for name, text, mt in field_spec:
        found = str(back.schema.field(name).type) if name in back.column_names else "absent"
        ok = found == want_type[name]
        if not ok:
            failures.append(f"new column {name}: type {found}, map says {want_type[name]}")
        new[name] = {"recipe": text, "model_type": mt, "type": found, "ok": ok,
                     "sha256": io.column_sha256(back.column(name)) if name in back.column_names else "",
                     **{k: v for k, v in stats[name].items()}}
    return {"range": rg.name, "file": n, "original": src, "copy": dst, "extract_start": rg.extract_start,
            "rows": rows, "id_columns": id_cols, "id_sequence_sha256": seq, "columns": cols, "new_columns": new,
            "map_sha256": meta["map_sha256"], "status_sha256": meta["status_sha256"],
            "recipes_sha256": meta["recipes_sha256"], "geohash_table_sha256": meta.get("geohash_table_sha256"),
            "result": "PASS" if not failures else "FAIL", "failures": failures, "utc": C.utc_now()}


if __name__ == "__main__":
    sys.exit(main())
