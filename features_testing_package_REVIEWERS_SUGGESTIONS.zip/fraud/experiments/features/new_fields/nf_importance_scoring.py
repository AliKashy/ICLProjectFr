"""Score source-row interventions with the existing target-ending model and windows."""
from contextlib import nullcontext
from dataclasses import dataclass
import time

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader


@dataclass
class ScorePass:
    data: pd.DataFrame
    all_data: pd.DataFrame
    elapsed_seconds: float
    coverage: dict
    attention: dict
    audit: list


def _key(account, transaction):
    return str(account), str(transaction)


def _june(stamps):
    values = pd.to_datetime(stamps, utc=True, errors="raise")
    return (values >= pd.Timestamp("2025-06-01", tz="UTC")) & (
        values < pd.Timestamp("2025-07-01", tz="UTC"))


class ScoreRunner:
    """Reuse a checkpoint's scorer; change only source values before building windows.

    The dataset wrapper lives in this process. Every pass therefore uses zero loader
    workers, independent of the configured training/scoring worker count. Amounts in
    returned metrics are the original transaction amounts, including when amount is
    the perturbed predictor. A family callback rebuilds declared dependent outputs.
    """

    def __init__(self, cfg, checkpoint, account_share=0.25, seed=20261102,
                 recompute=None, scorer=None, required_columns=()):
        if scorer is None:
            from nf_layout import bootstrap, get
            bootstrap()
            scorer = get("scorer")
        self.scorer = scorer
        self.cfg, self.checkpoint = cfg, str(checkpoint)
        self.account_share, self.seed = float(account_share), int(seed)
        if not 0 < self.account_share <= 1:
            raise ValueError("account_share must be above zero and at most one")
        self.recompute = recompute
        self.required_columns = tuple(required_columns)
        self.run = scorer.load_for_scoring(cfg, self.checkpoint)
        self.dataset = self.run["loader"].dataset
        self.device = self.run["device"]
        self.configured_workers = self.run["loader"].num_workers
        self.used_workers = 0
        self.feature_names = list(self.dataset.features.continuous) + list(
            self.dataset.features.categorical)
        self.token_names = list(self.dataset.continuous_cols) + list(self.dataset.categorical_cols)
        self.account_col = self.dataset.account_col
        self.id_col = cfg.data.get("tie_break_col") or next(
            (c for c in self.run["id_cols"] if c != self.account_col), None)
        if not self.id_col:
            raise ValueError("The scorer needs a transaction identity column")
        self.time_col = self.dataset.order_col
        self.label_col = self.dataset.target_col
        self.amount_col = cfg.data.get("amount_col") or "transaction_amt"
        self._original_encode = self.dataset._encode_file

    def _replace_outputs(self, encoded, unit, repeat, file_key, identity):
        """Change one encoded source row once; reuse it in every overlapping window.

        Derived calendars are already materialized here. Re-encoding just the changed
        columns avoids regenerating a permuted month from the unchanged timestamp.
        Missingness flags travel with their numeric feature.
        """
        from nf_permutation import perturb_frame
        cont, cat, target, times, frame, meta = encoded
        changed, audit = perturb_frame(
            frame, unit, seed=self.seed, repeat=repeat, file_key=file_key,
            account_col=self.account_col, id_col=self.id_col,
            time_col=self.time_col, label_col=self.label_col,
            identity=identity, immutable_columns=tuple(self.dataset.id_cols))
        if identity:
            return encoded, audit
        cont, cat = cont.copy(), cat.copy()
        changed_columns = set(unit.members)
        unknown = changed_columns.difference(self.feature_names)
        if unknown:
            raise ValueError(f"Not checkpoint predictors: {sorted(unknown)}")
        for name in changed_columns:
            if name in self.dataset.features.continuous:
                index = self.dataset.features.continuous.index(name)
                cont[:, index] = self.dataset.artifacts.standardize_continuous(name, changed[name])
                flag = name + "_isna"
                if flag in self.dataset.categorical_cols:
                    cat[:, self.dataset.categorical_cols.index(flag)] = changed[name].isna().to_numpy()
            if name in self.dataset.features.categorical:
                cat[:, self.dataset.categorical_cols.index(name)] = (
                    self.dataset.artifacts.encode_categorical(name, changed[name]))
        # The source-row values used for window metadata remain the original values.
        return (cont, cat, target, times, frame, meta), audit

    def score(self, unit=None, repeat=0, identity=False, attention=False, file_limit=None):
        from nf_permutation import perturb_frame, select_accounts
        dataset = self.dataset
        original_files, original_cols = dataset.file_list, dataset._read_cols
        if file_limit is not None and (int(file_limit) != file_limit or file_limit < 1):
            raise ValueError("file_limit must be a positive integer")
        files = list(original_files if file_limit is None else original_files[:int(file_limit)])
        extra_columns = [self.amount_col, *self.required_columns]
        if unit is not None and unit.method != "single_output_possibly_inconsistent":
            extra_columns.extend(unit.source_columns)
        if unit is not None and unit.method == "family" and self.recompute is not None:
            required = getattr(self.recompute, "required_columns", ())
            extra_columns.extend(required(unit) if callable(required) else required)
        selected_meta, account_files, original_accounts = {}, {}, set()
        totals = {"raw_rows": 0, "selected_rows": 0}
        audits, file_index = [], 0
        salt = f"feature-importance-accounts:{self.seed}"

        def encode(frame):
            nonlocal file_index
            if file_index >= len(files):
                raise ValueError("Scorer encoded more files than its declared range")
            file_key = str(files[file_index])
            file_index += 1
            totals["raw_rows"] += len(frame)
            if frame[[self.account_col, self.id_col]].isna().any().any():
                raise ValueError("Source identity contains missing values")
            for account in frame[self.account_col].astype(str).unique():
                if account in account_files and account_files[account] != file_key:
                    raise ValueError("One account spans multiple source files")
                account_files[account] = file_key
                original_accounts.add(account)
            frame = select_accounts(frame, self.account_share, self.account_col, salt=salt)
            totals["selected_rows"] += len(frame)
            for account, transaction, timestamp, amount in frame[
                    [self.account_col, self.id_col, self.time_col, self.amount_col]].itertuples(index=False, name=None):
                key = _key(account, transaction)
                if key in selected_meta:
                    raise ValueError("Duplicate source transaction identity")
                selected_meta[key] = (timestamp, amount)
            if unit is not None and unit.method != "single_output_possibly_inconsistent":
                frame, audit = perturb_frame(
                    frame, unit, seed=self.seed, repeat=repeat, file_key=file_key,
                    account_col=self.account_col, id_col=self.id_col,
                    time_col=self.time_col, label_col=self.label_col,
                    recompute=self.recompute, identity=identity,
                    immutable_columns=tuple(dataset.id_cols))
                audits.append(audit)
            encoded = self._original_encode(frame)
            if unit is not None and unit.method == "single_output_possibly_inconsistent":
                encoded, audit = self._replace_outputs(encoded, unit, repeat, file_key, identity)
                audits.append(audit)
            return encoded

        capture = None
        if attention:
            from nf_attention import AttentionCapture
            capture = AttentionCapture(self.run["model"], self.token_names)
        frames = []
        start = time.perf_counter()
        dataset.file_list = files
        dataset._read_cols = list(dict.fromkeys([*original_cols, *extra_columns]))
        dataset._encode_file = encode
        try:
            loader = DataLoader(dataset, batch_size=None, num_workers=0)
            with capture if capture is not None else nullcontext():
                for batch in loader:
                    if capture is not None:
                        metadata = batch["meta_seq"] if self.run["chunk"] else batch["meta"]
                        if self.run["chunk"]:
                            slots = batch["mask"].sum(1).numpy() - 1
                            accounts = np.asarray(metadata[self.account_col])[np.arange(len(slots)), slots]
                            identities = np.asarray(metadata[self.id_col])[np.arange(len(slots)), slots]
                        else:
                            accounts, identities = metadata[self.account_col], metadata[self.id_col]
                        stamps = [selected_meta[_key(a, i)][0] for a, i in zip(accounts, identities)]
                        capture.set_targets(~batch["mask"], target_rows=torch.as_tensor(np.asarray(_june(stamps))))
                    with torch.no_grad():
                        logits = self.run["model"](self.scorer._model_inputs(batch, self.run["device"])).cpu()
                    probabilities, labels, metadata = self.scorer.select(logits, batch, self.run["chunk"])
                    accounts, identities = metadata[self.account_col], metadata[self.id_col]
                    original = [selected_meta[_key(a, i)] for a, i in zip(accounts, identities)]
                    widths = batch["mask"].sum(1).numpy().astype(np.int64)
                    natural = self.scorer.natural_rows(batch, self.run["chunk"])
                    frames.append(pd.DataFrame({
                        "account": accounts, "id": identities, "label": labels,
                        "score": np.asarray(probabilities, dtype=np.float32),
                        "timestamp": [item[0] for item in original],
                        "amount": [item[1] for item in original],
                        "window_rows": widths, "window_natural_rows": natural,
                        "window_truncated": natural > widths,
                    }))
            if str(self.run["device"]).startswith("cuda"):
                torch.cuda.synchronize()
            elapsed = time.perf_counter() - start
        finally:
            dataset._encode_file = self._original_encode
            dataset.file_list, dataset._read_cols = original_files, original_cols
        if self.scorer.sha256(self.checkpoint) != self.run["checkpoint_hash"]:
            raise ValueError("Checkpoint changed during the scoring pass")
        if not frames:
            raise ValueError("The selected accounts produced no scored targets")
        data = pd.concat(frames, ignore_index=True)
        if data[["account", "id"]].astype(str).duplicated().any():
            raise ValueError("Scoring produced duplicate transaction identities")
        if len(data) != len(selected_meta):
            raise ValueError("Scored targets differ from the selected source transactions")
        scores = data["score"].to_numpy()
        if not np.isfinite(scores).all() or ((scores < 0) | (scores > 1)).any():
            raise ValueError("Scoring produced invalid probabilities")
        june = data.loc[_june(data["timestamp"])].reset_index(drop=True)
        coverage = {
            **totals, "raw_accounts": len(original_accounts),
            "selected_accounts": int(data["account"].astype(str).nunique()),
            "scored_rows": len(data), "june_rows": len(june),
            "june_frauds": int(june["label"].sum()), "files": len(files),
            "account_share": self.account_share,
            "configured_workers": self.configured_workers, "used_workers": self.used_workers,
        }
        attention_result = {}
        if capture is not None:
            attention_result = (capture.result() if len(june) else
                                {"target_rows": 0, "reason": "no June targets in this pass"})
        return ScorePass(june, data, elapsed, coverage, attention_result, audits)

    def verify_identity(self, unit, file_limit=1):
        """Compare the plain loop with its identity intervention on all target rows."""
        plain = self.score(file_limit=file_limit)
        wrapped = self.score(unit, identity=True, file_limit=file_limit)
        pd.testing.assert_frame_equal(plain.all_data, wrapped.all_data, check_exact=True)
        return {"bitwise_equal": True, "rows": len(plain.all_data), "files": file_limit}
