"""Rules of the CPU field checks (DESIGN.md 2.5, 3.2 and 3.3): stop, wait, flag.

Every threshold is read from CHECK_THRESHOLDS.yaml. A key is found by its leaf name
anywhere in that file (so the file may group keys as it likes); a key the file does not
hold takes the default below, and the screen lists which defaults were used. A field
gets every rule that fires. The worst result wins: STOP over WAIT over FLAG over PASS.
Nothing here removes a field or month; the results are listed for the owner.
"""

from __future__ import annotations

import math
import re
from typing import Dict, Iterable, List, Optional, Tuple

ORDER = {"PASS": 0, "FLAG": 1, "WAIT": 2, "STOP": 3}

# Leaf key -> default. Values follow DESIGN.md 3.3 and 3.2 unless the note says otherwise.
DEFAULTS: Dict[str, object] = {
    "min_free_gb": 32,
    # STOP
    "type_number_text": 0.001,         # share of non-null values that are not numbers
    "type_scale": 1e12,                # |mean| or sd above this
    "type_date_parse": 0.01,           # share of non-null date values that fail to parse
    "date_after_txn_rows": 0.001,      # own date after the transaction, share of non-null rows
    "date_after_txn_fraud": 0.01,      # the same, share of non-null fraud rows
    # The reviewers' decisions of 2 November (D3b, D3d)
    "date_after_fraud_ratio": 3.0,     # date_after_fraud_linked: after-transaction share among frauds at least
    "date_after_fraud_points": 0.001,  #   3 times that among non-frauds and at least 0.1 point above it
    "prev_not_earlier_share": 0.001,   # a CURR/PREV pair with PREV not earlier than CURR on 0.1% of rows with both
    "raw_date_parse_share": 0.99,      # a raw source whose non-null values parse as dates on 99% or more
    "fill_only_fraud_ratio": 10.0,
    "fill_only_fraud_nonfraud_max": 0.01,
    "fill_after_fraud_points": 20.0,
    "control_val_ap": 0.137146,        # the control's best validation AP (kept: the reviewers' decision D10)
    "duplicate_number_r": 0.9999,
    "vocab_size_stop": 100000,
    "unk_fit_files": 0.001,
    "unk_june": 0.5,
    "empty_train": 0.995,
    "empty_june": 0.99,
    "empty_june_train_max": 0.90,
    # Review items 5, 6, 9 and 13 (reviewer levels, declared before the first run; the owner approves)
    "same_day_times": 3.0,             # same_day_date: fraud share at least this many times the other
    "same_day_points": 1.0,            # ... and at least this many points above it
    "same_day_refresh_times": 3.0,     # same_day_refresh: event-day refresh rate against pseudo-event days
    "same_day_refresh_points": 5.0,
    "reissue_change_points": 10.0,     # known future dates: change after the first fraud above the pseudo-event
    "pre_event_ap": 0.5,               # pre_event_proxy: AP of "the account turns fraud later" on pre-event rows
    "pre_event_fill_ratio": 10.0,      # ... or pre-event fill share this many times that of matched accounts
    "pre_event_fill_nonfraud_max": 0.01,
    "pre_event_min_lift": 5.0,         # ... and in either form, at least this many times the base rate
    "snapshot_constant": 90.0,         # snapshot: percent of accounts constant throughout, with strong_alone
    "min_event_accounts": 30,          # event rules need at least this many fraud accounts measured
    "function_of_min_rows_per_value": 5,
    # FLAG
    "fill_ratio": 3.0,
    "fill_jump_points": 5.0,
    "change_at_event_points": 10.0,
    "change_at_event_times": 3.0,
    "change_after_event_points": 10.0,
    "strong_alone_share": 0.5,
    "near_duplicate_r": 0.98,
    "near_duplicate_rho": 0.999,
    "near_duplicate_v": 0.95,
    "near_duplicate_pairs": 1.01,
    "vocab_large": 10000,
    "unk_june_high": 0.10,
    "missing_drift_points": 20.0,
    "censored_june": 0.10,
    "absolute_time_rho": 0.9,
    "overlaps_month_v": 0.3,
    "overlaps_month_nmi": 0.1,
    "drift_june_psi": 0.25,
    "repetitive_v": 0.7,
    "repetitive_nmi": 0.5,
    "cluster_threshold": 0.8,
    "refreshed_by_transaction_share": 0.01,   # D3b: a timestamp in the transaction's own second on 1% of rows
    "joint_clock_rho": 0.9,            # D3d: the joint time fit's out-of-fold Spearman rho
    # TFM's precomputed geohash column (merchant_geohash, cprsrvc__pisinfo_cardholder_geohash), when the files hold
    # it, against the geohash recipe: FLAG below this share of matching rows (part B, item 9)
    "tfm_geohash_match_min": 0.999,
    # Exact recodes are read from factorized codes only below this share of distinct values per
    # row: a column with (nearly) all values distinct is trivially one-to-one with the transaction
    # id and with any other such column. Above it, copies are found as identical text, or as a
    # number with |r| or |rho| at the duplicate_number_r level (an affine or monotone copy).
    "recode_max_unique_share": 0.5,
    # Calendar shape: integer values 1-12 count as a month code only with this many distinct values
    # (a reviewer choice, so a small code such as 1-3 is not called a month; six, because the
    # training files hold only eight months).
    "calendar_min_distinct": 6,
    # Name patterns (lowercase substrings or regular expressions), data not code.
    "calendar_patterns": [r"(^|_)month($|_)", r"(^|_)mnth($|_)", r"(^|_)mon($|_)", r"(^|_)year($|_)",
                          r"(^|_)yr($|_)", r"(^|_)period($|_)", r"yyyymm", r"(^|_)qtr($|_)", r"(^|_)quarter($|_)"],
    "external_score_patterns": [r"^external_\d+_scr$", r"(^|_)vaa($|_)", r"(^|_)ext_?score"],
    # Name patterns: a plain word matches a whole token; anything else is a regular expression ("(x)" = anywhere).
    "decision_patterns": [r"(decline)", r"(processor_reason)", r"(^|_)decision", r"(^|_)disposition"],
    "profile_patterns": [r"^cpr"],
    # Status name scan, used only when STATUS_RULES.csv holds no patterns. Short patterns match whole
    # tokens (split on "_"), so merchant_state_xcd, cardholder, tokenization and authcsusploc pass.
    "status_substring_patterns": ["status", "block", "inactv", "inactive", "close", "counterfeit", "badchip",
                                  "disposition", "interdict", "prior_action", "frd", "fraud", "claim",
                                  "chargeback", "dispute", "suspect", "suspicious"],
    "status_token_patterns": ["stat", "ato", "ring", "hold", "susp"],
    "future_date_patterns": [r"(expir)", r"(^|_)exp_?dt($|_)"],
    "label_columns": ["frd_tag"],
    "outcome_patterns": [r"(^|_)frd_tag$", r"(chargeback)", r"(^|_)claim", r"(disposition)"],
}


# The thresholds file's own key names (the settings lane's CHECK_THRESHOLDS.yaml) for each key above, with the
# factor that turns the file's value into this module's unit (the file writes points as fractions: 0.20 = 20 points).
ALIASES: Dict[str, Tuple[str, float]] = {
    "min_free_gb": ("min_free_host_gb", 1.0),
    "control_val_ap": ("control_best_val_ap", 1.0),
    "type_number_text": ("type_number_text_share", 1.0),
    "type_scale": ("type_scale_abs", 1.0),
    "type_date_parse": ("type_date_parse_share", 1.0),
    "date_after_txn_rows": ("date_after_txn_share", 1.0),
    "date_after_txn_fraud": ("date_after_txn_fraud_share", 1.0),
    "same_day_times": ("same_day_ratio", 1.0),
    "same_day_points": ("same_day_points", 100.0),
    "same_day_refresh_points": ("same_day_refresh_points", 100.0),
    "reissue_change_points": ("reissue_change_points", 100.0),
    "fill_after_fraud_points": ("fill_after_fraud_points", 100.0),
    "duplicate_number_r": ("duplicate_number_abs_r", 1.0),
    "vocab_size_stop": ("vocab_size", 1.0),
    "unk_fit_files": ("unk_fit_files_share", 1.0),
    "unk_june": ("unk_june_share", 1.0),
    "empty_train": ("empty_train_share", 1.0),
    "empty_june": ("empty_june_share", 1.0),
    "empty_june_train_max": ("empty_june_train_below", 1.0),
    "fill_jump_points": ("fill_jump_points", 100.0),
    "change_at_event_points": ("change_at_event_points", 100.0),
    "change_at_event_times": ("change_at_event_ratio", 1.0),
    "change_after_event_points": ("change_after_event_points", 100.0),
    "strong_alone_share": ("strong_alone_ap_share", 1.0),
    "near_duplicate_r": ("near_duplicate_abs_r", 1.0),
    "near_duplicate_rho": ("near_duplicate_abs_rho", 1.0),
    "near_duplicate_v": ("near_duplicate_cramers_v", 1.0),
    "near_duplicate_pairs": ("near_duplicate_pairs_ratio", 1.0),
    "unk_june_high": ("unk_june_high_share", 1.0),
    "missing_drift_points": ("missing_drift_points", 100.0),
    "censored_june": ("censored_june_share", 1.0),
    "absolute_time_rho": ("absolute_time_abs_rho", 1.0),
    "overlaps_month_v": ("overlaps_month_cramers_v", 1.0),
    "overlaps_month_nmi": ("overlaps_month_nmi", 1.0),
    "calendar_patterns": ("calendar_name_patterns", 1.0),
}
for _k, _v in {"too_good_ap_share": 1.0, "pre_event_proxy_ap_ratio": None, "pre_event_proxy_fill_points": None,
               "function_of_entropy": 0.0, "constant_distinct": 1, "history_parity_max_days": 30,
               "change_after_event_days": 30, "reissue_window_days": 30, "pseudo_event_seed": None, "psi_bins": 10,
               "cluster_confirm_file": 3}.items():
    DEFAULTS.setdefault(_k, _v)


class Thresholds:
    """Lookup over the thresholds file: this module's key, else the file's own key name (ALIASES, with the
    unit factor), else the default above. Keys are found by leaf name anywhere in the file. The screen
    and thresholds_used.json list which keys took defaults."""

    def __init__(self, data: Optional[dict]):
        self.data = data or {}
        self.flat: Dict[str, object] = {}
        self._walk(self.data)
        self.defaulted: List[str] = []

    def _walk(self, d):
        if isinstance(d, dict):
            for k, v in d.items():
                if isinstance(v, dict):
                    self._walk(v)
                else:
                    self.flat.setdefault(str(k), v)

    def has(self, key: str) -> bool:
        return self.flat.get(key) is not None

    def path(self, dotted: str):
        cur = self.data
        for part in dotted.split("."):
            if not isinstance(cur, dict) or part not in cur:
                return None
            cur = cur[part]
        return cur

    def __call__(self, key: str):
        if key in ALIASES:
            fk, factor = ALIASES[key]
            if fk != key and self.has(key):
                return self.flat[key]
            if self.has(fk):
                v = self.flat[fk]
                return v * factor if isinstance(v, (int, float)) and not isinstance(v, bool) else v
        elif self.has(key):
            return self.flat[key]
        if key == "repetitive_v" and self.path("month_repetitive.cramers_v") is not None:
            return self.path("month_repetitive.cramers_v")
        if key == "repetitive_nmi" and self.path("month_repetitive.nmi") is not None:
            return self.path("month_repetitive.nmi")
        if key not in self.defaulted:
            self.defaulted.append(key)
        return DEFAULTS[key]

    def num(self, key: str) -> float:
        return float(self(key))

    def calendar_ranges(self) -> Dict[str, Tuple[float, float]]:
        r = self.path("calendar_int_ranges") or {}
        out = {"month": (1, 12), "yyyymm": (190001, 210012), "yyyymmdd": (19000101, 21001231)}
        for k, v in r.items():
            if isinstance(v, (list, tuple)) and len(v) == 2:
                out[str(k)] = (float(v[0]), float(v[1]))
        return out


def matches(text: str, patterns: Iterable[str]) -> List[str]:
    """Patterns found in the text. A plain word (letters and digits only) matches a whole token of the
    name split on "_"; anything else is a regular expression."""
    text = (text or "").lower()
    tokens = [t for t in re.split(r"[_\s]+", text) if t]
    out = []
    for p in patterns:
        p = str(p)
        if re.fullmatch(r"[A-Za-z0-9]+", p):
            if p.lower() in tokens:
                out.append(p)
        elif re.search(p, text):
            out.append(p)
    return out


def _fmt(x, nd=3) -> str:
    if x is None or (isinstance(x, float) and math.isnan(x)):
        return "na"
    if isinstance(x, float):
        if abs(x) >= 1e6 or (abs(x) < 1e-3 and x != 0):
            return f"{x:.2e}"
        return f"{x:.{nd}f}"
    return str(x)


def evaluate(m: Dict, th: Thresholds) -> List[Tuple[str, str, str]]:
    """All rules that fire for one field: (result, rule, value text)."""
    out: List[Tuple[str, str, str]] = []

    def add(res, rule, val=""):
        out.append((res, rule, val))

    g = m.get
    # ---- STOP, from the map and the files' presence
    if g("missing_from_files"):
        add("STOP", "missing_from_files", ";".join(g("missing_from_files"))[:200])
    if g("name_clash"):
        add("STOP", "name_clash", g("name_clash"))
    if g("excluded_by_sumegha"):
        add("STOP", "excluded_by_sumegha", g("sumegha_reason", ""))
    if g("sumegha_15298"):      # the reviewers' decision D3a
        if g("keep_written"):
            add("FLAG", "sumegha_15298", f"{g('sumegha_15298')}; kept in writing ({g('keep_written')}), A2 only")
        else:
            add("WAIT", "sumegha_15298", g("sumegha_15298"))
    if g("left_out_26oct"):
        add("STOP", "left_out_26oct")
    if g("left_out_reason"):
        add("STOP", "left_out_recipe", g("left_out_reason"))
    if g("uses_outcome"):
        add("STOP", "uses_outcome", g("uses_outcome"))
    if g("group_key_spans_files"):
        add("STOP", "group_key_spans_files", g("group_key_spans_files"))
    # ---- WAIT
    if g("status"):
        add("WAIT", "status", g("status"))
    if g("hold"):
        add("WAIT", "hold", g("hold"))
    if g("not_feasible"):
        add("WAIT", "not_feasible", g("feasibility_note", ""))
    if g("same_txn_decision"):
        add("STOP", "same_txn_decision", g("same_txn_decision"))
    if g("lagged_decision_wait"):
        add("WAIT", "lagged_decision", g("lagged_decision_wait"))
    if g("not_built"):
        add("WAIT", "not_built", g("not_built"))
    # ---- FLAG, from the map
    if g("external_score"):
        add("FLAG", "external_score", g("external_score"))
    if g("feasibility_unknown"):
        add("FLAG", "feasibility_unknown")
    if g("lagged_decision"):
        add("FLAG", "lagged_decision", g("lagged_decision"))
    if g("calendar_name") and not g("calendar_shape"):
        add("FLAG", "calendar_code", g("calendar_name"))

    for res, rule, val in g("inherited") or []:
        add(res, "inherited", f"{rule} from {val}")
    if not g("measured"):
        return out

    # ---- types
    nn = g("train_nonnull", 0)
    if g("model_type") == "continuous" and nn:
        fail = g("num_fail", 0) / nn
        if fail > th.num("type_number_text"):
            add("STOP", "type_number_text", _fmt(fail, 4))
        mean, sd = g("mean"), g("sd")
        if mean is not None and sd is not None and not (math.isnan(mean) or math.isnan(sd)):
            if abs(mean) > th.num("type_scale") or abs(sd) > th.num("type_scale"):
                add("STOP", "type_scale", f"mean {_fmt(mean)} sd {_fmt(sd)}")
    if g("date_parse_share") is not None and g("date_parse_share") > th.num("type_date_parse"):
        add("STOP", "type_date_parse", _fmt(g("date_parse_share"), 4))

    # ---- moment of the transaction
    min_ev = th.num("min_event_accounts")
    enough = (g("fraud_accounts_with_history") or 0) >= min_ev
    if g("date_nonnull"):
        rows = g("date_after", 0) / g("date_nonnull")
        fr = g("date_after_fraud", 0) / g("date_nonnull_fraud") if g("date_nonnull_fraud") else 0.0
        if g("future_by_meaning"):
            if g("date_after", 0):
                add("FLAG", "date_future_by_meaning", f"rows {_fmt(rows, 4)}")
            re_, rp = g("reissue_event"), g("reissue_pseudo")
            if _ok(re_) and _ok(rp) and re_ - rp >= th.num("reissue_change_points"):
                add("STOP", "reissue_change", f"{_fmt(re_, 1)} vs {_fmt(rp, 1)}")
        else:
            if rows > th.num("date_after_txn_rows") or fr > th.num("date_after_txn_fraud"):
                add("STOP", "date_after_txn", f"rows {_fmt(rows, 4)} fraud {_fmt(fr, 4)}")
            elif g("date_after", 0):
                add("FLAG", "date_after_any", f"n {g('date_after')}")
            # the reviewers' decision D3b: after-transaction rows now sit in the missing flag, so a link to the
            # label stops the field even below the absolute levels
            nf_n = g("date_nonnull_nonfraud")
            if g("date_nonnull_fraud") and nf_n:
                an = g("date_after_nonfraud", 0) / nf_n
                if fr > 0 and fr >= th.num("date_after_fraud_ratio") * an and \
                        fr - an >= th.num("date_after_fraud_points"):
                    add("STOP", "date_after_fraud_linked", f"after the transaction: frauds {_fmt(fr, 4)}, "
                                                           f"non-frauds {_fmt(an, 4)}")
    pn = g("prev_not_earlier_share")
    if _ok(pn) and g("pair_both_present") and pn >= th.num("prev_not_earlier_share"):
        add("STOP", "prev_not_earlier", f"PREV not earlier than CURR on {_fmt(100 * pn, 2)}% of rows with both")
    ss = g("same_second_share")
    if _ok(ss) and ss >= th.num("refreshed_by_transaction_share"):
        pv = g("same_second_prev")
        add("FLAG", "refreshed_by_transaction",
            f"{_fmt(100 * ss, 1)}% of rows in the transaction's own second; "
            + (f"the PREV column {pv} gives the time since the previous change (prev={pv})" if pv
               else "no PREV column found"))
    sd = []
    for a_, b_, what in (("same_day_fraud", "same_day_nonfraud", "frauds"),
                         ("same_day_event", "same_day_pseudo", "first frauds")):
        x, z = g(a_), g(b_)
        if _ok(x) and _ok(z) and x >= th.num("same_day_times") * z and (x - z) * 100 >= th.num("same_day_points"):
            sd.append(f"{what} {_fmt(100 * x, 1)}% vs {_fmt(100 * z, 1)}%")
    if sd:
        add("STOP", "same_day_date", "; ".join(sd))
    rf, rp = g("refresh_event"), g("refresh_pseudo")
    if enough and _ok(rf) and _ok(rp) and rf >= th.num("same_day_refresh_times") * rp \
            and rf - rp >= th.num("same_day_refresh_points"):
        add("STOP", "same_day_refresh", f"{_fmt(rf, 1)} vs {_fmt(rp, 1)}")
    ff, fn = g("fill_fraud"), g("fill_nonfraud")
    if _ok(ff) and _ok(fn):
        if fn < th.num("fill_only_fraud_nonfraud_max") and ff >= th.num("fill_only_fraud_ratio") * fn and ff > 0:
            add("STOP", "fill_only_fraud", f"fraud {_fmt(ff)} nonfraud {_fmt(fn, 4)}")
        elif fn > 0 and (ff >= th.num("fill_ratio") * fn or ff <= fn / th.num("fill_ratio")):
            add("FLAG", "fill_ratio", f"fraud {_fmt(ff)} nonfraud {_fmt(fn)}")
        elif fn == 0 and ff > 0:
            add("FLAG", "fill_ratio", f"fraud {_fmt(ff)} nonfraud 0")
    pf, pp = g("pre_fill_fraud"), g("pre_fill_pseudo")
    pre = []
    if th.has("pre_event_proxy_ap_ratio"):      # the thresholds file's rule: a share of the control's AP
        ap_lim = th.num("pre_event_proxy_ap_ratio") * th.num("control_val_ap")
    else:
        ap_lim = th.num("pre_event_ap")
    base = g("pre_event_base")
    lift_ok = _ok(base) and g("pre_event_ap") is not None and _ok(g("pre_event_ap")) and \
        g("pre_event_ap") >= th.num("pre_event_min_lift") * base
    pre_ok = (g("pre_fraud_accounts") or 0) >= min_ev
    if pre_ok and _ok(g("pre_event_ap")) and g("pre_event_ap") >= ap_lim and lift_ok:
        pre.append(f"AP {_fmt(g('pre_event_ap'), 3)} at base {_fmt(g('pre_event_base'), 3)}")
    if pre_ok and _ok(pf) and _ok(pp):
        if th.has("pre_event_proxy_fill_points"):   # the thresholds file's rule: a fill gap in points
            lo_, hi_ = min(pf, pp), max(pf, pp)
            # the gap, and also a ratio, so a field filled for 40% against 15% of accounts is a flag, not a stop
            if hi_ - lo_ >= th.num("pre_event_proxy_fill_points") and hi_ >= th.num("pre_event_fill_ratio") * lo_:
                pre.append(f"fill {_fmt(pf)} vs {_fmt(pp, 4)}")
            elif hi_ - lo_ >= th.num("pre_event_proxy_fill_points"):
                add("FLAG", "pre_event_fill_gap", f"accounts filled {_fmt(pf)} vs {_fmt(pp)}")
        elif pp < th.num("pre_event_fill_nonfraud_max") and pf > 0 and pf >= th.num("pre_event_fill_ratio") * pp:
            pre.append(f"fill {_fmt(pf)} vs {_fmt(pp, 4)}")
    if pre:
        add("STOP", "pre_event_proxy", "; ".join(pre))
    jump = g("fill_jump_excess")
    if _ok(jump):
        if jump >= th.num("fill_after_fraud_points"):
            add("STOP", "fill_after_fraud", f"{_fmt(jump, 1)} points")
        elif jump >= th.num("fill_jump_points"):
            add("FLAG", "fill_jump", f"{_fmt(jump, 1)} points")
    ce, cp = g("change_at_event"), g("change_at_pseudo")
    if enough and _ok(ce) and _ok(cp):
        if ce - cp >= th.num("change_at_event_points") and ce >= th.num("change_at_event_times") * cp:
            if g("is_profile"):
                add("WAIT", "profile_change_at_event", f"{_fmt(ce, 1)} vs {_fmt(cp, 1)}, the data owner confirms "
                                                         "the as-of time")
            else:
                add("FLAG", "change_at_event", f"{_fmt(ce, 1)} vs {_fmt(cp, 1)}")
    ae, apz = g("change_after_event"), g("change_after_pseudo")
    if enough and _ok(ae) and _ok(apz) and not g("future_by_meaning"):
        if ae - apz >= th.num("change_after_event_points"):
            add("FLAG", "change_after_event", f"{_fmt(ae, 1)} vs {_fmt(apz, 1)}")
    probes = g("probes") or {}
    failed = [k for k, v in probes.items() if v is False]
    if failed:
        add("STOP", "not_strictly_earlier", ",".join(failed))
    ap = g("single_ap")
    if ap is not None and not math.isnan(ap):
        ctrl = th.num("control_val_ap")
        if ap >= th.num("too_good_ap_share") * ctrl:
            add("STOP", "too_good", f"AP {_fmt(ap, 4)} >= {_fmt(th.num('too_good_ap_share') * ctrl, 4)}")
        elif ap >= th.num("strong_alone_share") * ctrl:
            add("FLAG", "strong_alone", f"AP {_fmt(ap, 4)}")
            if _ok(g("constant_in_account")) and g("constant_in_account") >= th.num("snapshot_constant"):
                add("WAIT", "snapshot", f"constant in {_fmt(g('constant_in_account'), 1)}% of accounts")

    # ---- TFM's precomputed geohash column against the geohash recipe (part B, item 9)
    tg = g("tfm_geohash_match")
    if isinstance(tg, dict) and tg.get("rows"):
        share = tg["match"] / tg["rows"]
        if share < th.num("tfm_geohash_match_min"):
            add("FLAG", "tfm_geohash_match",
                f"{tg.get('column', '')}: {100 * share:.3f}% of {tg['rows']} rows match; {tg['rows'] - tg['match']} "
                f"differ (TFM only {tg.get('tfm_only', 0)}, recipe only {tg.get('ours_only', 0)}, different "
                f"{tg.get('differ', 0)})")

    # ---- duplicates
    if g("label_copy"):
        add("STOP", "label_copy", g("label_copy"))
    if g("duplicate_of"):
        add("STOP", "duplicate", f"{g('duplicate_kind', '')} of {g('duplicate_of')}")
    if g("duplicate_number_of"):
        add("STOP", "duplicate_number", g("duplicate_number_of"))
    if g("function_of"):
        add("STOP", "function_of", g("function_of"))
    if g("refines"):
        add("FLAG", "refines", g("refines"))
    if g("near_duplicate_of"):
        add("FLAG", "near_duplicate", g("near_duplicate_of"))
    if g("distinct_train") is not None and g("distinct_train") <= th.num("constant_distinct"):
        add("STOP", "constant", f"{g('distinct_train')} value(s) in training, missing counted as a value")
    if g("raw_date"):
        add("STOP", "raw_date", g("raw_date"))
    elif _ok(g("date_like_share")) and g("date_like_share") >= th.num("raw_date_parse_share"):
        text = (f"{_fmt(100 * g('date_like_share'), 1)}% of values parse as dates ({g('date_like_rule', '')}); "
                "a date enters only as days before or until the transaction")
        if g("keep_written"):
            add("FLAG", "raw_date", f"{text}; kept in writing as not a date ({g('keep_written')})")
        else:
            add("STOP", "raw_date", text)
    if g("joint_clock"):
        add("FLAG", "joint_clock", g("joint_clock"))
    if g("history_parity"):
        add("FLAG", "history_parity", g("history_parity"))

    # ---- vocabulary and unknown share
    vs = g("vocab_size")
    if vs is not None:
        if vs > th.num("vocab_size_stop"):
            add("STOP", "vocab_size", str(vs))
        elif vs > th.num("vocab_large"):
            add("FLAG", "vocab_large", str(vs))
    if g("capped"):
        # a capped code field (the reviewers' decisions D9-Y20 and D10): rare values encode to the unknown index by
        # design, so the fit-file and June unknown shares are reported, not stops (the capped columns and
        # capped_fields.txt); a high June share under the cap is a flag
        uj = g("unk_june_capped")
        if _ok(uj) and uj > th.num("unk_june_high"):
            add("FLAG", "unk_june_high", f"capped: june {_fmt(uj)}, kept {g('capped_kept')} values")
    else:
        if g("unk_fit_max") is not None and g("unk_fit_max") > th.num("unk_fit_files"):
            add("STOP", "unk_fit_files", f"{_fmt(g('unk_fit_max'), 4)} in {g('unk_fit_file', '')}")
        uj, uv = g("unk_june"), g("unk_val")
        if uj is not None and not math.isnan(uj) and uj > th.num("unk_june"):
            add("STOP", "unk_june", _fmt(uj))
        elif max(x for x in (uj, uv, 0.0) if x is not None and not math.isnan(x)) > th.num("unk_june_high"):
            add("FLAG", "unk_june_high", f"june {_fmt(uj)} val {_fmt(uv)}")

    # ---- missing values
    mt, mj = g("missing_train"), g("missing_june")
    if mt is not None and not math.isnan(mt) and mt >= th.num("empty_train"):
        add("STOP", "empty_train", _fmt(mt, 4))
    if mj is not None and mt is not None and not (math.isnan(mj) or math.isnan(mt)):
        if mj >= th.num("empty_june") and mt < th.num("empty_june_train_max"):
            add("STOP", "empty_june", f"june {_fmt(mj)} train {_fmt(mt)}")
    if g("missing_drift_points") is not None and g("missing_drift_points") > th.num("missing_drift_points"):
        add("FLAG", "missing_drift", f"{_fmt(g('missing_drift_points'), 1)} points in {g('missing_drift_month', '')}")
    cj = g("censored_june")
    if cj is not None and not math.isnan(cj) and cj > th.num("censored_june"):
        add("FLAG", "censored_june", _fmt(cj))

    # ---- month-like (the reviewers' decision D3d)
    shape = g("calendar_shape")
    if shape in ("yyyymm", "yyyymmdd"):
        add("STOP", "calendar_code", f"{shape}: a date coded as a number; it enters only as days before or "
                                     "until the transaction" + ("; name too" if g("calendar_name") else ""))
    elif shape:
        add("FLAG", "calendar_code", shape + ("; name too" if g("calendar_name") else ""))
    # a field that repeats month or tracks time is held for the reviewers, who decide it under the owner's
    # delegation and record keep or drop and the reason in KEEP_DECISIONS.csv (the workbook's decisions table);
    # no owner signature is needed, and the owner is asked only for a missing source fact or preference
    decided, decided_by = g("month_decision"), g("month_decided_by")

    def month_hold(rule: str, what: str) -> None:
        if decided == "keep":
            add("FLAG", rule, f"{what}; kept by the reviewers' recorded decision ({decided_by})")
        elif decided == "drop":
            add("STOP", rule, f"{what}; dropped by the reviewers' recorded decision ({decided_by})")
        else:
            add("WAIT", rule, f"{what}; {MONTH_HOLD}")
    rho = g("time_rho")
    if rho is not None and not math.isnan(rho) and abs(rho) >= th.num("absolute_time_rho"):
        month_hold("tracks_time", f"rho {_fmt(rho)}")
    va, na = g("month_v_present_adj"), g("month_nmi_present_adj")
    if _ok(va) and _ok(na) and (va >= th.num("repetitive_v") or na >= th.num("repetitive_nmi")):
        month_hold("repeats_month", f"V {_fmt(va, 2)} NMI {_fmt(na, 2)} on present values, chance removed")
    v = g("month_v_uncensored") if _ok(g("month_v_uncensored")) else g("month_v")
    nmi = g("month_nmi_uncensored") if _ok(g("month_nmi_uncensored")) else g("month_nmi")
    if v is not None and nmi is not None and not (math.isnan(v) or math.isnan(nmi)):
        if v >= th.num("overlaps_month_v") or nmi >= th.num("overlaps_month_nmi"):
            add("FLAG", "overlaps_month", f"V {_fmt(v, 2)} NMI {_fmt(nmi, 2)} on rows not censored")
    psi = g("psi_june")
    if psi is not None and not math.isnan(psi) and psi >= th.num("drift_june_psi"):
        add("FLAG", "drift_june", f"PSI {_fmt(psi, 2)}")
    return out


def _ok(x) -> bool:
    return x is not None and not (isinstance(x, float) and math.isnan(x))


# The month-like hold's wording (the reviewers' decision D3d, as amended on 3 November): the field waits for the
# reviewers' recorded keep or drop decision, not for an owner signature.
MONTH_HOLD = "held until the reviewers record keep or drop and the reason in KEEP_DECISIONS.csv"


# Rules a recipe inherits from a source column that is itself a map field (review item 28).
INHERITED_RULES = ("date_after_txn", "date_after_fraud_linked", "prev_not_earlier", "same_day_date", "same_day_refresh", "fill_only_fraud", "fill_after_fraud",
                   "too_good", "label_copy", "uses_outcome", "left_out_26oct", "status", "hold", "excluded_by_sumegha",
                   "not_feasible", "pre_event_proxy", "snapshot", "reissue_change", "not_strictly_earlier",
                   "profile_change_at_event", "same_txn_decision")


def worst(rules: List[Tuple[str, str, str]]) -> str:
    res = "PASS"
    for r, _, _ in rules:
        if ORDER[r] > ORDER[res]:
            res = r
    return res


def reasons_text(rules: List[Tuple[str, str, str]]) -> str:
    return "; ".join(f"{r} {rule}" + (f" ({val})" if val else "") for r, rule, val in rules)


def month_statement(name: str, m: Dict, th: Thresholds, month_adds_nothing: Optional[bool],
                    ceiling: Optional[Dict] = None, joint: Optional[str] = None) -> str:
    """The plain per-field month statement (DESIGN.md 3.2, as the reviewers' decision D3d words it). Nothing is
    removed: a field that repeats month or tracks time is held until the reviewers record keep or drop and the
    reason in KEEP_DECISIONS.csv (under the owner's delegation; the owner is asked only for a missing source fact or
    preference), and month stays; exact month duplicates stay represented once; month leaves only through
    the month-out step."""
    g = m.get
    va, na, rho = g("month_v_present_adj"), g("month_nmi_present_adj"), g("time_rho")
    v = g("month_v_uncensored") if _ok(g("month_v_uncensored")) else g("month_v")
    nmi = g("month_nmi_uncensored") if _ok(g("month_nmi_uncensored")) else g("month_nmi")
    if not _ok(v) and not _ok(va):
        parts = [f"month overlap with {name} not measured"]
    else:
        ceil = (f", ceiling V {_fmt(ceiling.get('v'), 2)} NMI {_fmt(ceiling.get('nmi'), 2)}"
                if ceiling and _ok(ceiling.get("v")) else "")
        repeats = _ok(va) and _ok(na) and (va >= th.num("repetitive_v") or na >= th.num("repetitive_nmi"))
        tracks = _ok(rho) and abs(rho) >= th.num("absolute_time_rho")
        if repeats or tracks:
            what = []
            if repeats:
                what.append(f"repeats month on its present values (V {_fmt(va, 2)}, NMI {_fmt(na, 2)}{ceil})")
            if tracks:
                what.append(f"tracks time (rho {_fmt(rho, 2)})")
            dec = {"keep": "kept", "drop": "dropped"}.get(g("month_decision"))
            held = (f"{dec} by the reviewers' recorded decision ({g('month_decided_by')})" if dec
                    else f"it is {MONTH_HOLD}")
            parts = [f"{name} {' or '.join(what)}: {held}; month stays"]
        elif _ok(v) and (v >= th.num("overlaps_month_v") or nmi >= th.num("overlaps_month_nmi")):
            parts = [f"{name} overlaps month (V {_fmt(v, 2)}, NMI {_fmt(nmi, 2)} on rows not censored), below the "
                     "hold level; month stays"]
        else:
            parts = [f"month is not repeated by {name} (V {_fmt(v, 2)}, NMI {_fmt(nmi, 2)})"]
    view = {True: "adds nothing", False: "adds"}.get(month_adds_nothing)
    parts.append(f"the screen's view: month {view} once the new fields are in (information)" if view
                 else "the screen's view: not given (information)")
    parts.append("month leaves only through the month-out step")
    parts.append(f"joint time check: {joint}" if joint else "joint time check: not run")
    return "; ".join(parts)
