"""Recipes for engineered fields: the closed grammar of the design, section 2.2.

One recipe string per field-map row. ``parse`` checks it and returns a ``Recipe``.
``build_columns`` computes every engineered column of one file's rows. The CPU
checks, the CPU screen and the enriched copies all call this module, so a field is
computed by one piece of code everywhere.

The rules every history recipe follows (the model's own rules):

- Only rows of the same history key count. The key is the account
  (``Nmap_account_reference_xid``) unless the recipe names another raw column
  with ``key=``. Account, customer and card keys are different keys and give
  different features; the tools never swap one for another.
- Only strictly earlier rows count. The time key is ``transaction_dttm`` floored
  to whole seconds, as the sequence builder does (``datetime64[s]``). A row in
  the same second is not earlier, so same-second siblings never see each other.
- A window is ``[t - w - lag, t - lag)``. A window that reaches before the
  split's declared extract start is censored: the value is missing, never zero.
- The frame must hold every row of the file (each account's whole in-extract
  history). Build before any target is selected or downsampled.
- Missing raw values never match and never count. Raw values are compared as
  stored, before any vocabulary.
- The label ``frd_tag`` and label-like columns are never a source.

Windowed counts, sums, means and distinct counts reuse the base's
``strict_window.StrictWindows`` unchanged. A lag is served by one query row per
row at ``t - lag`` that never counts itself. Minimum, maximum, latest and first
rows use the same sorted (key, time) index built here.

Row-level recipes (``days_before``, ``days_until``, ``code``, ``ratio`` and
``geohash``) read only the row's own stored values. They have no window, no lag
and no censoring, so the history rules above hold for them as they are.

Dates and time intervals (the reviewers' decision D3b of 2 November) enter the
model's numeric path on a log scale:

- ``days_before`` (a past event): ln(1 + s), s the whole seconds from the event
  to the transaction (both floored to whole seconds); a date with no time part
  counts whole calendar days x 86,400. With ``prev=<column>`` (a CURR/PREV pair,
  for example a profile's current and previous change times) the event is CURR
  when CURR is strictly before the transaction, else PREV when PREV is, so a
  profile refreshed by this transaction or a later one reads the time since the
  previous change.
- ``days_until`` (a known future date, such as an expiry): sign(u) ln(1 + |u|), u
  the calendar days from the transaction's day to the date's; a month-level date
  (yyyymm or MMYY with ``format=``, or a source whose values all fall on day 1)
  is the last day of its month.
- ``since_last`` and ``since_first``: ln(1 + whole seconds) from the earlier row;
  ``unit=`` stays for the reports, which print the interval in that unit.
- Missing (the artifact then imputes the median and sets ``<name>_isna = 1``)
  with one counted reason per row: missing, sentinel, after_transaction,
  same_second, same_day (a date with no time part on the transaction's own day;
  ``same_day=keep`` gives ln(1) = 0, only with a person's keep row),
  implausible, or unparsed (a value the date rules cannot read). Sentinels: a
  stored numeric 0, 1899-12-30, 1900-01-01, 1960-01-01, 1970-01-01, any date
  after 2100-12-31 and the dates declared with ``sentinel=``. Implausible: an
  event before 1900-01-02 or more than 36,525 days before the transaction; a
  future date more than 3,653 days either side of the transaction's day.
  Implausible values count as parse failures for the checks' parse stop.

``geohash(postal_col; country_col)`` is TFM's postal-code geohash, made as TFM's
V22 pipeline makes it (its ``pkl_s3_to_tabular.py`` and the
``zip_geohash_handle`` of ``utility_lib/tokenizer.py``). The table is TFM's CSV
(postal_code, country_code, geohash_value), named by the SETTINGS.yaml key
``geohash_table``: TFM's S3 path by default, or a local copy. The value is a
category:

1. A missing postal code is missing (TFM's MISSING token). Codes are text as TFM
   casts them (pandas text: a number column gives the text of the number). Case
   is never changed.
2. For the two pairs TFM precomputes (``TFM_GEOHASH_COLUMNS``: the merchant's
   and the cardholder's postal code, each with its own country), TFM's tabular
   step looks up (postal, country), both stripped of whitespace at both ends, in
   the table with repeated (postal, country) rows dropped and the first kept.
   When it finds a geohash, that value (stripped) is the answer, as TFM's
   tokenizer keeps it. (The tokenizer keeps it only when it is in TFM's
   vocabulary; TFM builds that vocabulary from the same table's geohash values,
   so the recipe uses that set. A vocabulary file made from another table could
   differ, and that the recipe cannot see.) For any other pair TFM makes no such
   column, so only the tokenizer's own lookup (3) applies.
3. Otherwise the tokenizer's own lookup: the postal code with trailing whitespace
   removed and, when the country is exactly the text ``840`` (no padding, no
   strip), only its first 5 characters; the country as stored. Here the last of
   repeated rows wins (one dictionary over every row).
4. No matching row gives ``OTHER``. A matched row with a blank geohash gives
   ``UNK`` (TFM's token for it is not in its vocabulary). A missing country never
   matches, so a postal code with no country gives ``OTHER``.

Distance features (the 26 October travel speed and distance from home, step a3)
need a centroid per postal code. When no centroid table exists, the centre of the
postal code's geohash cell can serve, marked coarse. The cell size follows from
the table's geohash length p (``geohash_cell_km``): p = 3 about 156 by 156 km,
p = 4 about 39 by 20 km, p = 5 about 4.9 by 4.9 km (east-west by north-south at
the equator; east-west shrinks with the cosine of the latitude, so a p = 3 cell is
about 120 km wide at 40 degrees north). No centroid table is built here.

Importing this module does no work. Project modules come through the resolver.
"""

from __future__ import annotations

import hashlib
import io
import math
import os
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

ACCOUNT = "Nmap_account_reference_xid"
TIME = "transaction_dttm"
TIE = "fi_transaction_id"
LABEL = "frd_tag"
NS = 1_000_000_000
DAY = 86_400

# Fixed window labels; any other width is written as "<n>s".
WINDOWS: Dict[str, int] = {
    "5m": 300, "1h": 3_600, "24h": DAY, "48h": 2 * DAY, "7d": 7 * DAY,
    "14d": 14 * DAY, "30d": 30 * DAY, "90d": 90 * DAY,
}
MAX_WINDOW_SECONDS = 400 * DAY  # longer than any extract; also keeps nanosecond arithmetic in range
UNITS: Dict[str, int] = {"seconds": 1, "minutes": 60, "hours": 3_600, "days": DAY}

# Never a source: the label and names that look like an outcome.
LABEL_COLUMNS = (LABEL,)
LABEL_LIKE_PATTERNS = ("frd", "fraud", "chargeback", "claim", "dispute", "disposition")

# Declared extract starts per split (the same values as strict_window.EXTRACT_START).
EXTRACT_START = {"train": "2024-10-01", "validation": "2024-10-01", "evaluation": "2025-05-01"}

# Raw columns the 26 October builders read (groups.compute_groups and screen features_new.compute_new).
A3_SOURCES = ("transaction_amt", "transaction_type_xcd", "total_available_balance_amt",
              "remain_day_merchandise_lmt_amt", "available_daily_cash_limit_amt", "merchant_category_xcd")

# Multi-output fields: a date or a code inside them needs the named subfield column, never a cast of the whole
# value (feature review; design review item 3, rule generic_source).
GENERIC_SOURCE_PATTERN = r"__pisinfo\d*$"
# Lookback longer than this differs between training (from 2024-10-01) and June (from 2025-05-01): FLAG
# history_parity (design review item 12). History recipes without a window default to this lookback.
PARITY_SECONDS = 30 * DAY

# Dates (the reviewers' decision D3b): what is no date, and the plausible ranges.
SENTINEL_DAYS = ("1899-12-30", "1900-01-01", "1960-01-01", "1970-01-01")
LATEST_REAL_DAY = "2100-12-31"     # any later date is a placeholder (9999-12-31 and the like)
EVENT_FLOOR_DAY = "1900-01-02"     # a past event before it is implausible
EVENT_MAX_DAYS = 36_525            # a past event further back than this is implausible
FUTURE_MAX_ABS_DAYS = 3_653        # a known future date further away than this, either side, is implausible
DATE_REASONS = ("missing", "sentinel", "after_transaction", "same_second", "same_day", "implausible", "unparsed")
COUNT_FORMATS = ("days_since", "seconds_since")

AGGREGATES = ("sum", "mean", "min", "max")
HISTORY_OPS = ("count",) + AGGREGATES + ("distinct", "since_last", "since_first", "prev")
ALL_OPS = ("raw", "days_before", "days_until", "code", "ratio", "a3", "geohash") + HISTORY_OPS

_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


class RecipeError(ValueError):
    """A recipe that does not parse, or that the rules refuse."""


# --------------------------------------------------------------------------------------------- #
# Parsing
# --------------------------------------------------------------------------------------------- #
def window_seconds(text: str) -> int:
    """A window label (``24h``) or ``<n>s`` as whole seconds."""
    text = text.strip()
    if text in WINDOWS:
        return WINDOWS[text]
    m = re.fullmatch(r"(\d+)s", text)
    if m and 0 < int(m.group(1)) <= MAX_WINDOW_SECONDS:
        return int(m.group(1))
    if m:
        raise RecipeError(f"window {text!r} is longer than {MAX_WINDOW_SECONDS // DAY} days")
    raise RecipeError(f"unknown window {text!r}; use one of {', '.join(WINDOWS)} or <n>s")


def window_label(seconds: Optional[int]) -> str:
    if not seconds:
        return ""
    for k, v in WINDOWS.items():
        if v == seconds:
            return k
    return f"{seconds}s"


def is_label_like(column: str, patterns: Sequence[str] = LABEL_LIKE_PATTERNS) -> bool:
    low = column.lower()
    return column in LABEL_COLUMNS or any(p in low for p in patterns)


@dataclass
class Recipe:
    """A parsed recipe. ``text`` is the recipe string as written in the map."""

    text: str
    op: str
    column: Optional[str] = None          # raw, days_*, code, prev, a3 output name, geohash postal code
    country: Optional[str] = None         # geohash country code
    value: Optional[str] = None           # sum, mean, min, max, distinct
    numerator: Optional[str] = None       # ratio
    denominator: Optional[str] = None     # ratio
    window: Optional[int] = None          # seconds
    lag: int = 0                          # seconds
    within: Optional[int] = None          # since_first, seconds
    unit: Optional[str] = None            # since_last, since_first
    where_col: Optional[str] = None
    where_values: Tuple[str, ...] = ()
    same: Optional[str] = None
    key: Optional[str] = None             # history key; None is the account
    date_format: Optional[str] = None     # days_before, days_until
    same_day: str = "missing"             # days_before on a date with no time part: same day is missing or kept
    prev_column: Optional[str] = None     # days_before: the PREV column of a CURR/PREV pair
    sentinels: Tuple[str, ...] = ()       # days_*: declared default dates (yyyy-mm-dd), read as no date
    tz_offset_hours: Optional[float] = None   # days_*: the source's clock runs this many hours ahead of t's
    unlimited: bool = False               # since_last, prev with within=all
    notes: List[str] = field(default_factory=list)

    # -- facts other tools read ------------------------------------------------------------- #
    @property
    def is_history(self) -> bool:
        return self.op in HISTORY_OPS

    @property
    def is_engineered(self) -> bool:
        return self.op != "raw"

    @property
    def sources(self) -> List[str]:
        """Raw columns this recipe reads, besides the account and time keys."""
        if self.op == "a3":
            return list(A3_SOURCES)
        cols = [self.column, self.prev_column, self.country, self.value, self.numerator, self.denominator,
                self.where_col, self.same, self.key]
        out: List[str] = []
        for c in cols:
            if c and c not in out:
                out.append(c)
        return out

    @property
    def lookback_seconds(self) -> Optional[int]:
        """How far back a history recipe reads (window plus lag, or within); None for no limit."""
        if not self.is_history:
            return 0
        if self.window:
            return self.window + self.lag
        if self.unlimited:
            return None
        return self.within

    @property
    def history_key(self) -> str:
        return self.key or ACCOUNT

    def describe(self) -> Dict[str, str]:
        """The point-in-time facts of the field-map columns ``window``, ``lag`` and ``as_of_rule``."""
        key = self.history_key
        same_s = f", same {self.same} as this row" if self.same else ""
        where_s = f", only rows with {self.where_col} in {{{','.join(self.where_values)}}}" if self.where_col else ""
        base = (f"strictly earlier rows of the same {key}, whole seconds{same_s}{where_s}")
        if self.op == "raw":
            rule = "value stored on the row at the transaction time"
        elif self.op == "days_before":
            pair = (f"; the event is {self.column} when it is strictly before the transaction, else "
                    f"{self.prev_column} when that is" if self.prev_column else "")
            rule = (f"ln(1 + whole seconds from the date in {self.column} to the transaction time) (past "
                    f"event{pair}). A date with no time part counts whole calendar days x 86,400. Missing, with "
                    "its reason, when the date is after the transaction, in the same second, on the same day "
                    "for a date with no time part"
                    + (" (kept as ln(1) = 0 here: same_day=keep, with a person's keep row)"
                       if self.same_day == "keep" else "")
                    + f", a sentinel{self._sentinel_text()}, before {EVENT_FLOOR_DAY} or more than "
                    f"{EVENT_MAX_DAYS:,} days before the transaction" + self._offset_text())
        elif self.op == "days_until":
            rule = (f"sign(u) x ln(1 + |u|), u the calendar days from the transaction's day to the date in "
                    f"{self.column} (a date known in advance, such as an expiry); a month-level date (yyyymm "
                    "or MMYY with format=, or every value on day 1) is the last day of its month. Missing, "
                    f"with its reason, for a sentinel{self._sentinel_text()} or when |u| > "
                    f"{FUTURE_MAX_ABS_DAYS:,} days" + self._offset_text())
        elif self.op == "code":
            rule = (f"raw code of {self.column} on the row, as a category. A proposed alternative to the "
                    "original le1/le3 encoding, not a proven equivalent")
        elif self.op == "ratio":
            rule = f"{self.numerator} / {self.denominator} on the row; missing unless both present and the divisor > 0"
        elif self.op == "geohash":
            lookups = ("TFM's two lookups" if tfm_geohash_column(self) is not None else
                       "TFM's tokenizer lookup only, as TFM precomputes no column for this pair")
            rule = (f"TFM's geohash of the postal code {self.column} with the country {self.country} on the row, "
                    f"from the table in SETTINGS.yaml {GEOHASH_TABLE_KEY} ({lookups}; country "
                    f"{GEOHASH_US} keeps {GEOHASH_US_CHARS} characters); {GEOHASH_OTHER} when no table row "
                    "matches, missing when the postal code is missing; with no table configured, the normalized "
                    "postal code with its country (postal code, capped: the extended artifact keeps values of 10 "
                    "or more accounts)")
        elif self.op == "a3":
            rule = f"column {self.column} of the 26 October builders, called unchanged (stored time precision)"
        elif self.op == "prev":
            span = "since the extract start" if self.unlimited else f"within {window_label(self.within)}"
            rule = (f"{self.column} on the latest strictly earlier row of the same {key} {span}, whole seconds; "
                    "assumes the value on that row was recorded at that row's transaction time (the event-time "
                    "assumption: a bank action logged later than its row would be read too early)")
        elif self.op == "since_last":
            span = "since the extract start" if self.unlimited else f"within {window_label(self.within)}"
            rule = (f"ln(1 + whole seconds since the latest {base} {span}); missing if none (the reports print "
                    f"the interval in {self.unit})")
        elif self.op == "since_first":
            rule = (f"ln(1 + whole seconds since the first {base} in the window); censored before the extract "
                    f"start. Not account opening (the reports print the interval in {self.unit})")
        else:
            rule = f"{base}, window [t - w - lag, t - lag), censored before the extract start"
        lookback = self.lookback_seconds
        return {
            "date_meaning": {"days_before": "event_date", "days_until": "known_future_date"}.get(self.op, ""),
            "mapping_status": "open" if self.op == "code" else "",
            "equivalence": "unverified" if self.op == "code" else "",
            "lookback": ("all since the extract start" if self.is_history and lookback is None
                         else window_label(lookback)),
            "history_parity": ("" if not self.is_history else
                               "ok" if lookback is not None and lookback <= PARITY_SECONDS else "flag"),
            "window": window_label(self.window or self.within),
            "lag": window_label(self.lag),
            "as_of_rule": rule,
            "group_key": key if self.is_history else "",
            "time_key": f"{TIME}, whole seconds, strictly earlier" if self.is_history else TIME,
            "censoring_rule": self._censoring_rule(),
            "missing_rule": (DATE_MISSING_RULE if self.op in ("days_before", "days_until") else
                             "missing raw values never match or count; missing is kept apart from zero"),
        }

    def _sentinel_text(self) -> str:
        declared = f" or the declared {', '.join(self.sentinels)}" if self.sentinels else ""
        return (f" (a stored 0, {', '.join(SENTINEL_DAYS)}, any date after {LATEST_REAL_DAY}{declared})")

    def _offset_text(self) -> str:
        if self.tz_offset_hours is None:
            return ""
        return f"; {self.tz_offset_hours:g} hours are taken off a time of day (the source's clock runs ahead)"

    def _censoring_rule(self) -> str:
        if self.op in ("count", "sum", "mean", "min", "max", "distinct"):
            return "missing when t - w - lag is before the split's extract start"
        if self.op == "since_first":
            return "missing when t - within is before the split's extract start"
        if self.op in ("since_last", "prev"):
            if self.unlimited:
                return "missing when no earlier row is seen since the extract start"
            return "missing when t - within is before the split's extract start"
        return ""


DATE_MISSING_RULE = ("missing (the artifact imputes the median and sets <name>_isna = 1) with one counted reason: "
                     "missing, sentinel, after_transaction, same_second, same_day, implausible or unparsed; "
                     "implausible and unparsed values count as parse failures")


def _split_top(text: str, sep: str) -> List[str]:
    return [p.strip() for p in text.split(sep)]


def _column(name: str, what: str) -> str:
    name = name.strip()
    if not name or not _NAME.match(name):
        raise RecipeError(f"{what}: {name!r} is not a column name")
    return name


def parse(text: str, label_patterns: Sequence[str] = LABEL_LIKE_PATTERNS) -> Recipe:
    """Parse one recipe string of the closed grammar. Raises ``RecipeError`` with the reason."""
    if text is None:
        raise RecipeError("empty recipe")
    raw_text = str(text).strip()
    if not raw_text:
        raise RecipeError("empty recipe")
    if raw_text == "raw":
        return Recipe(text=raw_text, op="raw")
    m = re.fullmatch(r"([a-z_0-9]+)\((.*)\)", raw_text)
    if not m:
        raise RecipeError(f"{raw_text!r} does not parse: expected op(arguments)")
    op, inner = m.group(1), m.group(2).strip()
    if op == "raw":
        raise RecipeError(f"{raw_text!r}: raw takes no arguments; write raw (integration: raw(x) was accepted)")
    if op not in ALL_OPS:
        raise RecipeError(f"unknown recipe {op!r}; the grammar is closed: {', '.join(ALL_OPS)}")
    parts = _split_top(inner, ";") if inner else []
    positional = [p for p in parts if "=" not in p]
    options: Dict[str, str] = {}
    for p in parts:
        if "=" in p:
            k, v = p.split("=", 1)
            k = k.strip()
            if k in options:
                raise RecipeError(f"{raw_text!r}: option {k} given twice")
            options[k] = v.strip()
    r = Recipe(text=raw_text, op=op)

    def allow(*names):
        bad = sorted(set(options) - set(names))
        if bad:
            raise RecipeError(f"{raw_text!r}: option(s) {', '.join(bad)} not allowed for {op}")

    def npos(k):
        if len(positional) != k:
            raise RecipeError(f"{raw_text!r}: {op} takes {k} positional argument(s), got {len(positional)}")

    def common_history():
        if "where" in options:
            w = options["where"]
            if ":" not in w:
                raise RecipeError(f"{raw_text!r}: where=column:value1,value2")
            c, vals = w.split(":", 1)
            r.where_col = _column(c, "where")
            r.where_values = tuple(v.strip() for v in vals.split(",") if v.strip())
            if not r.where_values:
                raise RecipeError(f"{raw_text!r}: where= lists no value")
        if "same" in options:
            r.same = _column(options["same"], "same")
        if "key" in options:
            r.key = _column(options["key"], "key")
        if "lag" in options:
            r.lag = window_seconds(options["lag"])

    if op in ("days_before", "days_until"):
        npos(1)
        if op == "days_before":
            allow("format", "same_day", "prev", "sentinel", "tz_offset_hours")
        else:
            allow("format", "sentinel", "tz_offset_hours")
        r.column = _column(positional[0], op)
        r.date_format = options.get("format") or None
        if r.date_format and r.date_format.split(":", 1)[0] in COUNT_FORMATS:
            kind, _, epoch = r.date_format.partition(":")
            try:
                pd.Timestamp(epoch.strip())
            except (ValueError, TypeError):
                raise RecipeError(f"{raw_text!r}: format={kind}:<epoch date>, for example {kind}:1990-01-01")
            r.date_format = f"{kind}:{pd.Timestamp(epoch.strip()).strftime('%Y-%m-%d')}"
        r.same_day = options.get("same_day", "missing")
        if r.same_day not in ("missing", "keep"):
            raise RecipeError(f"{raw_text!r}: same_day=missing or same_day=keep")
        if "prev" in options:
            r.prev_column = _column(options["prev"], "prev")
            if r.prev_column == r.column:
                raise RecipeError(f"{raw_text!r}: prev= names another column than the date's")
        if "sentinel" in options:
            days = []
            for v in options["sentinel"].split(","):
                try:
                    days.append(pd.Timestamp(v.strip()).strftime("%Y-%m-%d"))
                except (ValueError, TypeError):
                    raise RecipeError(f"{raw_text!r}: sentinel={v.strip()!r} is not a date (sentinel=d1,d2)")
            r.sentinels = tuple(days)
        if "tz_offset_hours" in options:
            try:
                r.tz_offset_hours = float(options["tz_offset_hours"])
            except ValueError:
                raise RecipeError(f"{raw_text!r}: tz_offset_hours=<hours>, a number")
            if not math.isfinite(r.tz_offset_hours) or abs(r.tz_offset_hours) > 24:
                raise RecipeError(f"{raw_text!r}: tz_offset_hours is at most 24 hours either way")
    elif op in ("code", "prev", "a3"):
        npos(1)
        allow("key", "within") if op == "prev" else allow()
        r.column = _column(positional[0], op)
        if op == "prev":
            if "key" in options:
                r.key = _column(options["key"], "key")
            _within(r, options)
    elif op == "ratio":
        npos(2)
        allow()
        r.numerator = _column(positional[0], "ratio")
        r.denominator = _column(positional[1], "ratio")
    elif op == "geohash":
        npos(2)
        allow()
        r.column = _column(positional[0], "geohash postal column")
        r.country = _column(positional[1], "geohash country column")
        if r.column == r.country:
            raise RecipeError(f"{raw_text!r}: geohash(postal column; country column) reads two different columns")
    elif op == "count":
        npos(1)
        allow("where", "same", "key", "lag")
        r.window = window_seconds(positional[0])
        common_history()
    elif op in AGGREGATES or op == "distinct":
        npos(1)
        allow("value", "where", "same", "key", "lag")
        r.window = window_seconds(positional[0])
        if "value" not in options:
            raise RecipeError(f"{raw_text!r}: {op} needs value=<column>")
        r.value = _column(options["value"], "value")
        common_history()
    elif op == "since_last":
        npos(1)
        allow("where", "same", "key", "within")
        r.unit = positional[0]
        common_history()
        _within(r, options)
    elif op == "since_first":
        npos(1)
        allow("same", "within", "key", "where")
        r.unit = positional[0]
        if "same" not in options or "within" not in options:
            raise RecipeError(f"{raw_text!r}: since_first needs same=<column> and within=<window>")
        r.within = window_seconds(options["within"])
        common_history()
    if r.unit is not None and r.unit not in UNITS:
        raise RecipeError(f"{raw_text!r}: unit {r.unit!r}; use one of {', '.join(UNITS)}")
    for c in r.sources:
        if c in (ACCOUNT, TIME) and c != r.key:
            raise RecipeError(f"{raw_text!r}: {c} is the history key or time key, not a source")
        if r.op != "a3" and is_label_like(c, label_patterns):
            raise RecipeError(f"{raw_text!r}: {c} is the label or label-like; an outcome is never a source")
    for c in ([r.column] + ([r.prev_column] if r.prev_column else []) if op in ("days_before", "days_until", "code")
              else
              [r.column, r.country] if op == "geohash" else []):
        if re.search(GENERIC_SOURCE_PATTERN, c):
            raise RecipeError(f"{raw_text!r}: generic_source: {c} holds several outputs; name the subfield column")
    if r.key == ACCOUNT:
        r.key = None
    return r


def _within(r: Recipe, options: Dict[str, str]) -> None:
    """since_last and prev look back 30 days unless within= says otherwise; within=all has no limit."""
    w = options.get("within", "30d")
    if w == "all":
        r.unlimited = True
        r.within = None
    else:
        r.within = window_seconds(w)


# --------------------------------------------------------------------------------------------- #
# Values as stored
# --------------------------------------------------------------------------------------------- #
def code_text(values) -> np.ndarray:
    """Stored codes as text, one to one with the stored values; missing is None.

    Numbers (any numeric type, or numbers inside an object column) that are whole become integer text, so
    an int column read as float because of nulls ("1.0") gives "1". Text is kept exactly as stored, so
    "007" and "7" stay different codes.
    """
    s = pd.Series(values, copy=False)
    miss = s.isna().to_numpy()
    if pd.api.types.is_bool_dtype(s):
        out = s.astype(str).to_numpy(dtype=object)
    elif pd.api.types.is_integer_dtype(s):  # int64 ids stay exact (no float on the way)
        out = np.array([None if m else str(int(v)) for v, m in zip(s.to_numpy(dtype=object), miss)], dtype=object)
    elif pd.api.types.is_numeric_dtype(s):
        num = s.to_numpy(dtype=float)
        whole = np.isfinite(num) & (num == np.floor(np.where(np.isfinite(num), num, 0))) & (np.abs(num) < 2 ** 53)
        out = pd.Series(num).astype(str).to_numpy(dtype=object)
        out[whole] = num[whole].astype(np.int64).astype(str)
    else:
        obj = s.to_numpy(dtype=object)
        out = np.empty(len(obj), dtype=object)
        for i, v in enumerate(obj):
            if isinstance(v, (bool, np.bool_)) or v is None:
                out[i] = str(v)
            elif isinstance(v, (int, np.integer)):
                out[i] = str(int(v))
            elif isinstance(v, (float, np.floating)):
                f = float(v)
                out[i] = str(int(f)) if np.isfinite(f) and f == np.floor(f) and abs(f) < 2 ** 53 else str(f)
            else:
                out[i] = v if isinstance(v, str) else str(v)
    out[miss] = None
    return out


def numbers(values) -> np.ndarray:
    return pd.to_numeric(pd.Series(values, copy=False), errors="coerce").to_numpy(dtype=float)


def raw_codes(*arrays) -> np.ndarray:
    """Integer codes of a tuple of raw values; -1 where any part is missing (never matches)."""
    n = len(arrays[0])
    miss = np.zeros(n, dtype=bool)
    parts = []
    for a in arrays:
        c, _ = pd.factorize(pd.Series(a, dtype=object, copy=False), use_na_sentinel=True)
        miss |= c < 0
        parts.append(c.astype(np.int64))
    if len(parts) == 1:
        out = parts[0]
    else:
        _, out = np.unique(np.stack(parts, axis=1), axis=0, return_inverse=True)
        out = out.reshape(-1).astype(np.int64)
    return np.where(miss, -1, out)


def _time_parts(values):
    """(UTC nanoseconds, local calendar day number) of ``transaction_dttm``."""
    ts = pd.to_datetime(pd.Series(values, copy=False), errors="coerce")
    if ts.isna().any():
        raise RecipeError(f"{int(ts.isna().sum())} rows have a missing or unparseable {TIME}")
    local = ts
    if getattr(ts.dt, "tz", None) is not None:
        local = ts.dt.tz_localize(None)  # wall-clock time in the transaction's own zone
        ts = ts.dt.tz_convert("UTC").dt.tz_localize(None)
    ns = ts.to_numpy(dtype="datetime64[ns]").astype(np.int64)
    day = np.floor_divide(local.to_numpy(dtype="datetime64[ns]").astype(np.int64), np.int64(DAY) * NS)
    return ns, day


def second_key(values) -> Tuple[np.ndarray, float]:
    """``transaction_dttm`` floored to whole seconds as int64 nanoseconds, and the share with sub-second parts."""
    ns, _ = _time_parts(values)
    floored = (ns // NS) * NS
    share = float(np.mean(floored != ns)) if len(ns) else 0.0
    return floored, share


def extract_start_ns(value) -> Optional[int]:
    if value is None:
        return None
    if isinstance(value, str) and value in EXTRACT_START:
        value = EXTRACT_START[value]
    return int(pd.Timestamp(value).to_datetime64().astype("datetime64[ns]").astype(np.int64))


_NS_LO = pd.Timestamp.min.value
_NS_HI = pd.Timestamp.max.value
NAT = np.iinfo(np.int64).min


def _parse_core(values, date_format: Optional[str] = None):
    """Dates as UTC int64 nanoseconds (NaT as the int64 minimum), the parse report, and the same dates as wall-clock
    nanoseconds in their own zone (a value with no time part is midnight there; calendar days are read there).

    The rule is fixed per value, so it does not depend on which file a value sits in:
    - datetime types and date objects are used as stored; a zone is converted to UTC after the no-time test;
    - text of exactly eight digits is yyyymmdd; other digit-only text is read as a number;
    - numbers: an integer 19000101 to 21001231 is yyyymmdd; 1e9 to 1e10 is epoch seconds (2001 to 2286);
      1e12 to 1e13 is epoch milliseconds; anything else FAILS (for example MMYY expiry codes or yyyymm):
      write ``format=`` for those;
    - other text is an ISO date or date-time; mixed zone offsets are refused;
    - ``format=`` overrides all of this for text and numbers (strptime codes);
    - a date outside the nanosecond range (for example a 9999-12-31 sentinel) fails, never crashes.
    """
    s = pd.Series(values, copy=False)
    n = len(s)
    present = ~s.isna().to_numpy()
    out = np.full(n, NAT, dtype=np.int64)
    wall_out = np.full(n, NAT, dtype=np.int64)
    counts: Dict[str, int] = {}
    day_ns = np.int64(DAY) * NS

    def put(mask, parsed, rule):
        idx = np.flatnonzero(mask)
        parsed = pd.Series(parsed).reset_index(drop=True)
        try:
            if not pd.api.types.is_datetime64_any_dtype(parsed):
                parsed = pd.to_datetime(parsed, errors="coerce")
        except (ValueError, TypeError, AttributeError) as e:
            raise RecipeError(f"dates do not parse as one type (mixed zones?): {e}; write format=")
        if not pd.api.types.is_datetime64_any_dtype(parsed):
            raise RecipeError("dates mix time zones or types; write format=")
        tz = getattr(parsed.dt, "tz", None)
        wall = parsed.dt.tz_localize(None) if tz is not None else parsed
        utc = parsed.dt.tz_convert("UTC").dt.tz_localize(None) if tz is not None else parsed
        ok = utc.notna().to_numpy().copy()
        lo, hi = pd.Timestamp(_NS_LO + DAY * NS), pd.Timestamp(_NS_HI - DAY * NS)
        ok &= ((utc >= lo) & (utc <= hi)).fillna(False).to_numpy(dtype=bool)
        if ok.any():
            u = utc[ok].to_numpy(dtype="datetime64[ns]").astype(np.int64)
            w = wall[ok].to_numpy(dtype="datetime64[ns]").astype(np.int64)
            out[idx[ok]] = u
            wall_out[idx[ok]] = w
        counts[rule] = counts.get(rule, 0) + int(ok.sum())

    def numbers_rule(mask, num, label):
        whole = mask & (num == np.floor(np.where(mask, num, 0)))
        ymd = whole & (num >= 19000101) & (num <= 21001231)
        sec = mask & ~ymd & (num >= 1e9) & (num < 1e10)
        ms = mask & ~ymd & (num >= 1e12) & (num < 1e13)
        if ymd.any():
            put(ymd, pd.to_datetime(pd.Series(num[ymd].astype(np.int64).astype(str)), format="%Y%m%d",
                                    errors="coerce"), f"yyyymmdd {label}")
        if sec.any():
            put(sec, pd.to_datetime(pd.Series(num[sec]), unit="s", errors="coerce"), f"epoch seconds {label}")
        if ms.any():
            put(ms, pd.to_datetime(pd.Series(num[ms]), unit="ms", errors="coerce"), f"epoch milliseconds {label}")

    if pd.api.types.is_datetime64_any_dtype(s):
        put(present, s[present], "datetime")
    elif date_format:
        txt = pd.Series(code_text(s), dtype=object)
        put(present, pd.to_datetime(txt[present], format=date_format, errors="coerce"), f"format {date_format}")
    elif present.any() and pd.api.types.infer_dtype(s[present], skipna=True) in ("date", "datetime", "datetime64"):
        put(present, pd.to_datetime(pd.Series(list(s[present]), dtype=object), errors="coerce"), "date objects")
    elif pd.api.types.is_numeric_dtype(s) and not pd.api.types.is_bool_dtype(s):
        numbers_rule(present, s.to_numpy(dtype=float, na_value=np.nan), "number")
    else:
        obj = s.to_numpy(dtype=object)
        is_text = present & np.array([isinstance(v, str) for v in obj], dtype=bool)
        is_num = present & ~is_text
        num = pd.to_numeric(pd.Series(obj), errors="coerce").to_numpy(dtype=float)
        if is_num.any():
            numbers_rule(is_num & np.isfinite(num), num, "number")
        if is_text.any():
            t = pd.Series(obj).where(is_text, "").astype(str).str.strip()
            eight = is_text & t.str.fullmatch(r"\d{8}").to_numpy()
            digits = is_text & ~eight & t.str.fullmatch(r"\d+").to_numpy()
            iso = is_text & ~eight & ~digits
            if eight.any():
                put(eight, pd.to_datetime(t[eight], format="%Y%m%d", errors="coerce"), "yyyymmdd text")
            if digits.any():
                numbers_rule(digits, pd.to_numeric(t.where(digits, "0")).to_numpy(dtype=float), "text")
            if iso.any():
                try:
                    parsed = pd.to_datetime(t[iso], format="ISO8601", errors="coerce")
                    if not pd.api.types.is_datetime64_any_dtype(parsed):
                        raise ValueError("mixed offsets")
                    rule = "ISO text"
                except (ValueError, TypeError):
                    # several zone offsets: read every value as an instant in UTC (no-time test in UTC)
                    try:
                        parsed = pd.to_datetime(t[iso], format="ISO8601", errors="coerce", utc=True)
                    except (ValueError, TypeError) as e:
                        raise RecipeError(f"ISO dates do not parse: {e}; write format=")
                    rule = "ISO text, mixed zones read as UTC"
                put(iso, parsed, rule)
    return out, counts, wall_out, present




def _day_ns(day: str) -> int:
    return int(pd.Timestamp(day).value)


def _count_since(s: pd.Series, date_format: str, present: np.ndarray):
    """format=days_since:<epoch> or seconds_since:<epoch>: whole counts from the epoch; 0 is the sentinel;
    a count that is not a whole positive number fails and is counted."""
    kind, _, epoch = date_format.partition(":")
    step = np.int64(DAY) * NS if kind == "days_since" else np.int64(NS)
    v = pd.to_numeric(pd.Series(code_text(s), dtype=object), errors="coerce").to_numpy(dtype=float)
    whole = present & np.isfinite(v) & (v == np.floor(np.where(np.isfinite(v), v, 0)))
    zero = whole & (v == 0)
    base = _day_ns(epoch)
    limit = (_NS_HI - DAY * NS - base) // int(step)
    ok = whole & (v > 0) & (v <= limit)
    out = np.full(len(v), NAT, dtype=np.int64)
    out[ok] = base + v[ok].astype(np.int64) * step
    return out, out.copy(), zero, {f"{kind} {epoch}": int(ok.sum())}


def _late_placeholders(s: pd.Series, present: np.ndarray, out: np.ndarray) -> np.ndarray:
    """Values the parser could not hold because they lie after 2100-12-31 (9999-12-31 and the like): placeholders,
    read as sentinels, never as parse failures."""
    late = np.zeros(len(s), dtype=bool)
    unread = present & (out == NAT)
    if not unread.any():
        return late
    if pd.api.types.is_datetime64_any_dtype(s):
        years = s.dt.year.to_numpy(dtype=float, na_value=np.nan)
        return unread & (years > 2100)
    idx = np.flatnonzero(unread)
    sub = pd.Series(s.to_numpy(dtype=object)[idx])
    kinds = pd.api.types.infer_dtype(sub, skipna=True)
    if kinds in ("date", "datetime", "datetime64", "mixed"):
        years = np.array([getattr(v, "year", 0) if not isinstance(v, str) else 0 for v in sub], dtype=float)
        late[idx[years > 2100]] = True
    num = pd.to_numeric(sub, errors="coerce")
    txt = sub.astype(str).str.strip()
    whole = num.notna() & (num == np.floor(num.fillna(0))) & (num.abs() < 1e17)
    if whole.any():   # a number as its integer digits (99991231.0 is 99991231)
        txt.loc[whole] = num[whole].astype(np.int64).astype(str)
    y8 = pd.to_numeric(txt.str.extract(r"^(\d{4})\d{4}$")[0], errors="coerce")
    yiso = pd.to_numeric(txt.str.extract(r"^(\d{4})-\d{1,2}-\d{1,2}")[0], errors="coerce")
    hit = y8.fillna(yiso).gt(2100).to_numpy(dtype=bool)
    late[idx[hit]] = True
    return late


def _stored_zero(s: pd.Series, present: np.ndarray) -> np.ndarray:
    """A stored numeric 0 (or digits that are all zeros): no date."""
    if pd.api.types.is_datetime64_any_dtype(s):
        return np.zeros(len(s), dtype=bool)
    if pd.api.types.is_numeric_dtype(s) and not pd.api.types.is_bool_dtype(s):
        return present & (s.to_numpy(dtype=float, na_value=np.nan) == 0)
    out = np.zeros(len(s), dtype=bool)
    idx = np.flatnonzero(present)
    if len(idx):
        txt = pd.Series(s.to_numpy(dtype=object)[idx]).astype(str).str.strip()
        out[idx[txt.str.fullmatch(r"0+(\.0+)?").to_numpy(dtype=bool)]] = True
    return out


def parse_dates_detail(values, date_format: Optional[str] = None, sentinels: Sequence[str] = ()):
    """The dates of ``parse_dates``, the report, the wall-clock dates, and a per-row code: "" (a date), "missing",
    "sentinel" or "unparsed" (the reviewers' decision D3b). Sentinels are no dates, not parse failures: a stored
    numeric 0, 1899-12-30, 1900-01-01, 1960-01-01, 1970-01-01, any date after 2100-12-31 and the declared days.
    ``format=days_since:<epoch>`` and ``format=seconds_since:<epoch>`` read whole counts from the epoch."""
    s = pd.Series(values, copy=False)
    n = len(s)
    present = ~s.isna().to_numpy()
    if date_format and date_format.split(":", 1)[0] in COUNT_FORMATS:
        out, wall_out, zero, counts = _count_since(s, date_format, present)
        late = np.zeros(n, dtype=bool)
    else:
        out, counts, wall_out, present = _parse_core(s, date_format)
        zero = _stored_zero(s, present)
        late = _late_placeholders(s, present, out)
    day_ns = np.int64(DAY) * NS
    parsed = out != NAT
    wall_day = np.where(parsed, np.floor_divide(np.where(parsed, wall_out, 0), day_ns), 0)
    marks = np.array(sorted({_day_ns(d) // int(day_ns) for d in tuple(SENTINEL_DAYS) + tuple(sentinels)}),
                     dtype=np.int64)
    sentinel = present & (zero | late | (parsed & (np.isin(wall_day, marks) |
                                                   (wall_day > _day_ns(LATEST_REAL_DAY) // int(day_ns)))))
    out = np.where(sentinel, NAT, out)
    wall_out = np.where(sentinel, NAT, wall_out)
    parsed = out != NAT
    why = np.full(n, "", dtype=object)
    why[~present] = "missing"
    why[sentinel] = "sentinel"
    why[present & ~sentinel & ~parsed] = "unparsed"
    n_present = int(present.sum())
    failed = int((why == "unparsed").sum())
    report = {"rules": counts, "non_null": n_present, "failed": failed,
              "failed_share": (failed / n_present) if n_present else 0.0, "sentinel": int(sentinel.sum())}
    if parsed.any():
        w = wall_out[parsed]
        report["earliest"] = str(pd.Timestamp(int(w.min())).date())
        report["latest"] = str(pd.Timestamp(int(w.max())).date())
    return out, report, wall_out, why


def parse_dates(values, date_format: Optional[str] = None,
                sentinels: Sequence[str] = ()) -> Tuple[np.ndarray, Dict[str, object], np.ndarray]:
    """Dates as UTC int64 nanoseconds (NaT as the int64 minimum), the parse report, and the same dates as wall-clock
    nanoseconds in their own zone (a value with no time part is midnight there; calendar days are read there).

    The rule is fixed per value, so it does not depend on which file a value sits in:
    - datetime types and date objects are used as stored; a zone is converted to UTC after the no-time test;
    - text of exactly eight digits is yyyymmdd; other digit-only text is read as a number;
    - numbers: an integer 19000101 to 21001231 is yyyymmdd; 1e9 to 1e10 is epoch seconds (2001 to 2286);
      1e12 to 1e13 is epoch milliseconds; anything else FAILS (for example MMYY expiry codes or yyyymm):
      write ``format=`` for those; ``format=days_since:<epoch>`` and ``format=seconds_since:<epoch>`` read
      whole counts from the epoch (0 is the sentinel);
    - other text is an ISO date or date-time; mixed zone offsets are refused;
    - ``format=`` overrides all of this for text and numbers (strptime codes);
    - sentinels are no dates and not failures (``parse_dates_detail``): a stored 0, 1899-12-30, 1900-01-01,
      1960-01-01, 1970-01-01, any date after 2100-12-31 (9999-12-31 never crashes) and the declared days.
    """
    out, report, wall_out, _ = parse_dates_detail(values, date_format, sentinels)
    return out, report, wall_out


# --------------------------------------------------------------------------------------------- #
# The sorted (key, time) index
# --------------------------------------------------------------------------------------------- #
class _Sorted:
    """Eligible rows sorted by (group, time, tie); answers lexicographic bounds per query."""

    def __init__(self, g: np.ndarray, t: np.ndarray, eligible: np.ndarray, tie: Optional[np.ndarray] = None):
        idx = np.flatnonzero(eligible & (g >= 0))
        keys = (t[idx], g[idx]) if tie is None else (tie[idx], t[idx], g[idx])
        self.rows = idx[np.lexsort(keys)]
        self.g = g[self.rows]
        self.t = t[self.rows]

    def at_or_after(self, gq: np.ndarray, tq: np.ndarray) -> np.ndarray:
        """Position of the first sorted row with (g, t) >= (gq, tq)."""
        allt = np.unique(np.concatenate([self.t, tq]))
        m = np.int64(len(allt) + 1)
        key = self.g.astype(np.int64) * m + np.searchsorted(allt, self.t)
        q = gq.astype(np.int64) * m + np.searchsorted(allt, tq)
        return np.searchsorted(key, q, side="left")

    def latest_before(self, gq: np.ndarray, tq: np.ndarray) -> np.ndarray:
        """Sorted position of the latest row of the same group with t < tq; -1 if none."""
        p = self.at_or_after(gq, tq) - 1
        ok = (p >= 0) & (gq >= 0)
        ok[ok] &= self.g[p[ok]] == gq[ok]
        return np.where(ok, p, -1)

    def first_in(self, gq: np.ndarray, lo: np.ndarray, hi: np.ndarray) -> np.ndarray:
        """Sorted position of the first row of the same group with lo <= t < hi; -1 if none."""
        p = self.at_or_after(gq, lo)
        ok = (p < len(self.g)) & (gq >= 0)
        ok[ok] &= (self.g[p[ok]] == gq[ok]) & (self.t[p[ok]] < hi[ok])
        return np.where(ok, p, -1)


def _reduce_ranges(values_s: np.ndarray, lo: np.ndarray, hi: np.ndarray, how: str) -> np.ndarray:
    """min or max of values_s[lo:hi] per query; NaN for an empty range."""
    fill = np.inf if how == "min" else -np.inf
    a = np.append(values_s, fill)
    func = np.minimum if how == "min" else np.maximum
    idx = np.stack([lo, np.maximum(hi, lo)], axis=1).ravel()
    red = func.reduceat(a, idx)[::2] if len(idx) else np.zeros(0)
    out = np.where(hi > lo, red, np.nan)
    out[~np.isfinite(out)] = np.nan
    return out


# --------------------------------------------------------------------------------------------- #
# TFM's postal-code geohash (row level; the module docstring states the rule)
# --------------------------------------------------------------------------------------------- #
GEOHASH_TABLE_KEY = "geohash_table"     # SETTINGS.yaml: TFM's table on S3, or a local copy
GEOHASH_TABLE_COLUMNS = ("postal_code", "country_code", "geohash_value")
GEOHASH_OTHER = "OTHER"                 # TFM's token for a postal code no table row matches
GEOHASH_UNKNOWN = "UNK"                 # a matched row whose geohash is blank: TFM's token for it reads as unknown
GEOHASH_US = "840"                      # the country whose postal codes TFM's tokenizer cuts to 5 characters
GEOHASH_US_CHARS = 5
# TFM's precomputed columns (pkl_s3_to_tabular.py GEOHASH_PAIRS): (postal column, country column) -> its column.
TFM_GEOHASH_COLUMNS = {
    ("merchant_postal_xcd", "merchant_country_xcd"): "merchant_geohash",
    ("cprsrvc__pisinfo_cardholder_postal_xcd", "cprsrvc__pisinfo_cardholder_country_xcd"):
        "cprsrvc__pisinfo_cardholder_geohash",
}
KM_PER_DEGREE = 40_075.017 / 360.0      # one degree along the equator


def geohash_cell_km(precision: int) -> Tuple[float, float]:
    """The size of a geohash cell of ``precision`` characters: (east-west km at the equator, north-south km).

    Each character carries 5 bits, split between longitude and latitude, longitude first: a cell spans
    360 / 2**ceil(5p/2) degrees of longitude and 180 / 2**floor(5p/2) of latitude. East-west shrinks with the
    cosine of the latitude."""
    bits = 5 * int(precision)
    lon_bits, lat_bits = (bits + 1) // 2, bits // 2
    return 360.0 / 2 ** lon_bits * KM_PER_DEGREE, 180.0 / 2 ** lat_bits * KM_PER_DEGREE


def _text(values) -> pd.Series:
    """Codes as TFM's pipeline casts them before any lookup: pandas text (``astype("string")``), missing kept."""
    return pd.Series(values, copy=False).astype("string")


def _clean(v) -> Optional[str]:
    """A geohash value as TFM's tokenizer reads a precomputed one: missing or blank is no value; else stripped."""
    if v is None or v is pd.NA or (isinstance(v, float) and math.isnan(v)):
        return None
    s = str(v).strip()
    return s or None


class GeohashTable:
    """TFM's postal-code to geohash table, read as TFM reads it, with TFM's two lookups (module docstring).

    ``frame`` is the CSV as pandas reads it with the three columns as text and pandas' default missing markers (a
    blank cell, "NA", "nan" and the like are missing), as TFM reads it. Rows with a missing postal or country code
    can never match a code; they are counted and left out of both lookups.
    """

    def __init__(self, frame: pd.DataFrame, source: str = "", sha256: str = ""):
        lack = [c for c in GEOHASH_TABLE_COLUMNS if c not in frame.columns]
        if lack:
            raise RecipeError(f"the geohash table {source} has no column(s) {', '.join(lack)}; TFM's table holds "
                              f"{', '.join(GEOHASH_TABLE_COLUMNS)}")
        self.source, self.sha256 = source, sha256
        # the tabular step drops repeated keys and keeps the first row; the tokenizer builds one dictionary over
        # every row, so there the last row wins. One dictionary holds the first rows, a second only the keys whose
        # last row came later (a large table is held once).
        self.first: Dict[Tuple[str, str], object] = {}
        self._later: Dict[Tuple[str, str], object] = {}
        post, country, geo = (frame[c].to_numpy(dtype=object) for c in GEOHASH_TABLE_COLUMNS)
        self.rows, self.repeated_rows, self.blank_key_rows = len(frame), 0, 0
        for p, c, g in zip(post, country, geo):
            if not isinstance(p, str) or not isinstance(c, str):
                self.blank_key_rows += 1
                continue
            key = (p, c)
            if key in self.first:
                self.repeated_rows += 1
                self._later[key] = g
            else:
                self.first[key] = g
        # TFM builds the field's vocabulary from every non-missing geohash of the table, plus the field's OTHER and
        # MISSING tokens; its tokenizer keeps a precomputed value only when that value is in the vocabulary
        self.vocab = {g for g in geo if isinstance(g, str)}
        self._kept = self.vocab | {GEOHASH_OTHER, "MISSING"}
        self.blank_geohash_rows = int(sum(1 for g in geo if not isinstance(g, str)))
        self.conflicting_keys = sum(1 for k, g in self._later.items() if _clean(g) != _clean(self.first[k]))
        self.lengths = sorted({len(g.strip()) for g in self.vocab if g.strip()})

    def last(self, key: Tuple[str, str]):
        """The tokenizer's dictionary: the geohash of the key's last table row (call only for a key in the table)."""
        return self._later[key] if key in self._later else self.first[key]

    def summary(self) -> Dict[str, object]:
        """Counts and the precision (geohash length) with its cell size, for screens and reports."""
        cells = {p: [round(x, 1) for x in geohash_cell_km(p)] for p in self.lengths}
        return {"source": self.source, "sha256": self.sha256, "rows": self.rows, "keys": len(self.first),
                "repeated_rows": self.repeated_rows, "conflicting_keys": self.conflicting_keys,
                "blank_key_rows": self.blank_key_rows, "blank_geohash_rows": self.blank_geohash_rows,
                "geohashes": len(self.vocab), "precision": self.lengths, "cell_km": cells}

    def _one(self, p: Optional[str], c: Optional[str], precomputed: bool = True
             ) -> Tuple[Optional[str], Optional[str], str]:
        """(value, the tabular step's value, which rule gave the value) for one (postal, country) pair.
        ``precomputed`` False: a pair TFM's tabular step never computes, so only the tokenizer's lookup applies."""
        if p is None:
            return None, None, "missing"
        # 1. the tabular step: both codes stripped at both ends; the first of repeated rows. A missing country is
        #    the text "nan" there, which no table row holds (pandas reads it as missing), so it never matches.
        g1 = None
        if precomputed and c is not None:
            g1 = self.first.get((p.strip(), c.strip()))
            g1 = g1 if isinstance(g1, str) else None
            kept = _clean(g1)
            if kept is not None and kept in self._kept:
                return kept, g1, "first"
        # 2. the tokenizer's own lookup: trailing whitespace only; the country as stored (text, no strip, no
        #    padding); country 840 keeps the first 5 characters; the last of repeated rows wins
        v = p.rstrip()
        cc = "" if c is None else c
        if cc == GEOHASH_US and len(v) > GEOHASH_US_CHARS:
            v = v[:GEOHASH_US_CHARS]
        if (v, cc) not in self.first:
            return GEOHASH_OTHER, g1, "other"
        g2 = self.last((v, cc))
        if isinstance(g2, str):
            return (g2, g1, "second") if g2 else (GEOHASH_OTHER, g1, "other")
        return GEOHASH_UNKNOWN, g1, "unknown"

    def lookup(self, postal, country, precomputed: bool = True) -> Tuple[np.ndarray, np.ndarray, Dict[str, int]]:
        """Per row: the value (geohash, OTHER, UNK, or None for a missing postal code), the tabular step's value
        (what TFM's precomputed column holds: the first lookup's geohash as stored, or None), and the row counts
        by rule (missing, first, second, other, unknown). Works on each distinct (postal, country) pair once.
        ``precomputed`` False is for a pair TFM precomputes no column for: the tokenizer's lookup alone (module
        docstring, item 2), and no tabular value."""
        p_txt = _text(postal).to_numpy(dtype=object, na_value=None)
        c_txt = _text(country).to_numpy(dtype=object, na_value=None)
        n = len(p_txt)
        if len(c_txt) != n:
            raise RecipeError("geohash: the postal and country columns differ in length")
        # a missing code is coded -1 (pandas' default in every version the project allows)
        pc, pu = pd.factorize(pd.Series(p_txt, dtype=object))
        cc, cu = pd.factorize(pd.Series(c_txt, dtype=object))
        width = len(cu) + 1
        pair = (pc.astype(np.int64) + 1) * width + (cc.astype(np.int64) + 1)
        uniq, inv = np.unique(pair, return_inverse=True)
        inv = inv.reshape(-1)
        vals, firsts, hows = (np.empty(len(uniq), dtype=object) for _ in range(3))
        for i, key in enumerate(uniq.tolist()):
            ip, ic = divmod(int(key), width)
            vals[i], firsts[i], hows[i] = self._one(pu[ip - 1] if ip else None, cu[ic - 1] if ic else None,
                                                    precomputed)
        how = hows[inv]
        counts = {k: int(np.sum(how == k)) for k in ("missing", "first", "second", "other", "unknown")}
        return vals[inv], firsts[inv], counts


_GEOHASH_TABLES: Dict[Tuple, GeohashTable] = {}


def clear_geohash_tables() -> None:
    """Forget the tables read so far (tests, or a table replaced while a process runs)."""
    _GEOHASH_TABLES.clear()


def geohash_table_path() -> str:
    """SETTINGS.yaml ``geohash_table``, read through the settings loader (``NF_SETTINGS_DIR`` moves it)."""
    import nf_common as C
    path = str(C.settings().get(GEOHASH_TABLE_KEY) or "").strip()
    if not path:
        raise RecipeError(f"geohash(...) needs TFM's table: SETTINGS.yaml {GEOHASH_TABLE_KEY} is blank; give TFM's "
                          "S3 path or a local copy")
    return path


def geohash_table_configured() -> bool:
    """Whether SETTINGS.yaml names a geohash table (the fallback applies when it does not)."""
    import nf_common as C
    try:
        return bool(str(C.settings().get(GEOHASH_TABLE_KEY) or "").strip())
    except Exception:   # noqa: BLE001 - no settings file: no table
        return False


def postal_fallback(postal, country) -> np.ndarray:
    """The normalized postal code paired with its country (the reviewers' decision D9-Y20): trailing whitespace
    removed and, when the country is exactly the text 840, the first 5 characters, as TFM's tokenizer normalizes
    it; "<postal>|<country>"; a missing postal code stays missing."""
    p_txt = _text(postal).to_numpy(dtype=object, na_value=None)
    c_txt = _text(country).to_numpy(dtype=object, na_value=None)
    out = np.empty(len(p_txt), dtype=object)
    for i, (p, c) in enumerate(zip(p_txt, c_txt)):
        if p is None:
            out[i] = None
            continue
        p = str(p).rstrip()
        if c == GEOHASH_US:
            p = p[:GEOHASH_US_CHARS]
        out[i] = f"{p}|{'' if c is None else c}"
    return out


def _base_cred_path() -> Optional[str]:
    """The chosen config's S3 credentials file (SETTINGS.yaml base_config, s3.cred_path), as the data tools use."""
    import nf_common as C
    try:
        cfg = C.load_yaml(C.ROOT / C.settings().get("base_config", "fraud/configs/sequential_hier_allpos.yaml"))
    except (OSError, ValueError):
        return None
    return ((cfg or {}).get("s3") or {}).get("cred_path") or None


def load_geohash_table(path: Optional[str] = None, cred_path: Optional[str] = None) -> GeohashTable:
    """TFM's table from ``path`` (default SETTINGS.yaml ``geohash_table``): S3 through the project's file system
    (the chosen config's credentials), or a local file (relative to the project root). Read once per process; a
    local file is read again when it changes. Any read failure is a ``RecipeError`` with the reason."""
    import nf_common as C
    import nf_data_io as dio
    path = str(path or geohash_table_path()).strip()
    on_s3 = dio.is_s3(path)
    if not on_s3 and not Path(path).is_absolute():
        path = str(C.ROOT / path)
    shown = path if on_s3 else C.rel(path)   # screens never show an absolute path of the machine
    stamp: Tuple = ()
    if not on_s3:
        try:
            st = os.stat(path)
            stamp = (st.st_mtime_ns, st.st_size)
        except OSError as e:
            raise RecipeError(f"the geohash table {shown} cannot be read ({type(e).__name__}); copy TFM's table "
                              f"there or set SETTINGS.yaml {GEOHASH_TABLE_KEY}")
    key = (path,) + stamp
    if key in _GEOHASH_TABLES:
        return _GEOHASH_TABLES[key]
    try:
        data = dio.Store(cred_path if cred_path is not None or not on_s3 else _base_cred_path()).read_bytes(path)
    except (Exception, SystemExit) as e:  # a missing file, credentials or network: refused with the reason
        raise RecipeError(f"the geohash table {shown} cannot be read ({type(e).__name__}: {e}); copy it to the pod "
                          f"and set SETTINGS.yaml {GEOHASH_TABLE_KEY} to the copy")
    try:
        frame = pd.read_csv(io.BytesIO(data), dtype={c: str for c in GEOHASH_TABLE_COLUMNS})
    except ValueError as e:
        raise RecipeError(f"the geohash table {shown} is not a readable CSV ({e})")
    table = GeohashTable(frame, source=shown, sha256=hashlib.sha256(data).hexdigest())
    _GEOHASH_TABLES[key] = table
    return table


def tfm_geohash_column(r: "Recipe") -> Optional[str]:
    """TFM's precomputed column for a geohash recipe's (postal, country) pair, or None."""
    return TFM_GEOHASH_COLUMNS.get((r.column, r.country)) if r.op == "geohash" else None


def precomputed_geohash_match(frame: pd.DataFrame, recipe, column: str,
                              table: Optional[GeohashTable] = None) -> Dict[str, object]:
    """TFM's precomputed column ``column`` against this recipe's first lookup, the one TFM's tabular step makes (so
    the recipe's value whenever that column holds a geohash). Both sides are read as TFM's tokenizer reads the
    column: stripped, a blank or missing value is no value. Rows whose postal code is missing and whose column is
    empty agree trivially and are not counted. Returns the column, rows, match, tfm_only (only the column holds a
    value), ours_only and differ (both hold one, different)."""
    r = recipe if isinstance(recipe, Recipe) else parse(recipe)
    if r.op != "geohash":
        raise RecipeError(f"{r.text}: not a geohash recipe")
    table = table if table is not None else load_geohash_table()
    _, first, _ = table.lookup(frame[r.column], frame[r.country])

    def cleaned(values) -> pd.Series:   # _clean, for a whole column: stripped text, blank or missing is NA
        s = _text(values).str.strip()
        return s.where(~(s == "").fillna(False), pd.NA)

    theirs = cleaned(frame[column].to_numpy(dtype=object))
    ours = cleaned(pd.Series(first, dtype=object))
    t_none, o_none = theirs.isna().to_numpy(), ours.isna().to_numpy()
    same = (theirs.reset_index(drop=True) == ours.reset_index(drop=True)).fillna(False).to_numpy(dtype=bool)
    same |= t_none & o_none
    counted = ~(_text(frame[r.column]).isna().to_numpy() & t_none & o_none)
    return {"column": column, "rows": int(counted.sum()), "match": int((counted & same).sum()),
            "tfm_only": int((counted & ~t_none & o_none).sum()), "ours_only": int((counted & t_none & ~o_none).sum()),
            "differ": int((counted & ~t_none & ~o_none & ~same).sum())}


# --------------------------------------------------------------------------------------------- #
# Building one file's columns
# --------------------------------------------------------------------------------------------- #
@dataclass
class Built:
    """One engineered column: its values, which rows are censored, and notes for the screen. A date recipe also
    carries each row's reason code ("" for a value; DATE_REASONS otherwise) and the signed difference in days as
    days before the transaction (negative: the date is after it), for the checks (the reviewers' decision D3b)."""

    values: np.ndarray
    censored: np.ndarray
    report: Dict[str, object] = field(default_factory=dict)
    reasons: Optional[np.ndarray] = None
    signed: Optional[np.ndarray] = None
    detail: Dict[str, np.ndarray] = field(default_factory=dict)


class FileContext:
    """One file's rows: the time key, the history keys and the strict-window engine.

    ``df`` must be every row of the file, in stored order (each account's whole history).
    """

    def __init__(self, df: pd.DataFrame, extract_start, strict_window_module=None,
                 account_col: str = ACCOUNT, time_col: str = TIME, tie_col: Optional[str] = TIE):
        self.df = df
        self.n = len(df)
        self.account_col = account_col
        if df[account_col].isna().any():
            raise RecipeError(f"{int(df[account_col].isna().sum())} rows have a missing {account_col}")
        self.t_exact, self.t_day = _time_parts(df[time_col].to_numpy())
        self.t = (self.t_exact // NS) * NS
        self.subsecond_share = float(np.mean(self.t != self.t_exact)) if self.n else 0.0
        self.es = extract_start_ns(extract_start)
        self.extract_start = extract_start
        self.sw_mod = strict_window_module
        tie = None
        if tie_col and tie_col in df.columns:
            # ties inside one second follow the stored id, as the sequence builder's stable sort does
            ids = pd.Series(df[tie_col].to_numpy(), copy=False)
            try:
                ranks = ids.rank(method="dense").to_numpy(dtype=float)
            except TypeError:  # mixed types: order as text
                ranks = ids.astype(str).where(ids.notna()).rank(method="dense").to_numpy(dtype=float)
            tie = np.nan_to_num(ranks, nan=np.inf)
        tie = tie if tie is not None else np.arange(self.n, dtype=float)
        # inside one earlier second, rows follow the stored time, then the id, as the sequence builder orders them
        order = np.lexsort((tie, self.t_exact))
        self.tie = np.empty(self.n, dtype=float)
        self.tie[order] = np.arange(self.n, dtype=float)
        self._a3 = None

    # -- history keys ---------------------------------------------------------------------- #
    def group(self, r: Recipe) -> np.ndarray:
        parts = [self.df[r.history_key].to_numpy(dtype=object)]
        if r.same:
            parts.append(self.df[r.same].to_numpy(dtype=object))
        return raw_codes(*parts)

    def eligible(self, r: Recipe, g: np.ndarray) -> np.ndarray:
        ok = g >= 0
        if r.where_col:
            stored = code_text(self.df[r.where_col])
            hit = pd.Series(stored, dtype=object).isin(list(r.where_values)).to_numpy()
            self.where_report = {"where_matches": int(hit.sum()),
                                 "where_values_seen": sorted(set(v for v in stored[hit] if v is not None))}
            ok &= hit
        return ok

    def censored_window(self, span: int) -> np.ndarray:
        if self.es is None:
            return np.zeros(self.n, dtype=bool)
        return (self.t - np.int64(span) * NS) < self.es

    # -- strict windows (the base's engine) ------------------------------------------------- #
    def _strict(self, g: np.ndarray, lag: int):
        """StrictWindows over the rows, plus one query row per row at t - lag when lag > 0."""
        sw_mod = self.sw_mod
        if lag:
            acct = np.concatenate([g, g])
            t = np.concatenate([self.t, self.t - np.int64(lag) * NS])
        else:
            acct, t = g, self.t
        es = None if self.es is None else self.es
        return sw_mod.StrictWindows(acct, t, es), (self.n if lag else 0)

    def _pad(self, arr, lag):
        if not lag:
            return arr
        if arr.dtype == bool:
            return np.concatenate([arr, np.zeros(self.n, dtype=bool)])
        return np.concatenate([arr, np.full(self.n, np.nan)])

    def _take(self, out, off):
        return np.asarray(out, dtype=float)[off:off + self.n] if off else np.asarray(out, dtype=float)

    # -- the recipes ------------------------------------------------------------------------ #
    where_report: Dict[str, object] = {}

    def build(self, r: Recipe) -> Built:
        self.where_report = {}
        b = self._build(r)
        b.report.update(self.where_report)
        if r.where_col and self.where_report.get("where_matches", 0) == 0:
            b.report["warning"] = f"no row has {r.where_col} in {list(r.where_values)}: every count is 0"
        return b

    def _build(self, r: Recipe) -> Built:
        if self.sw_mod is None and r.op in ("count", "sum", "mean", "distinct"):
            raise RecipeError("the strict-window module is needed; pass it from the resolver")
        for c in r.sources:
            if c not in self.df.columns:
                raise RecipeError(f"{r.text}: source column {c} is not in the file")
        none = np.zeros(self.n, dtype=bool)
        if r.op == "raw":
            return Built(self.df[r.column].to_numpy() if r.column else None, none)
        if r.op in ("days_before", "days_until"):
            return self._dates(r)
        if r.op == "code":
            return Built(code_text(self.df[r.column]), none)
        if r.op == "ratio":
            a, b = numbers(self.df[r.numerator]), numbers(self.df[r.denominator])
            with np.errstate(invalid="ignore", divide="ignore"):
                v = np.where(np.isfinite(a) & np.isfinite(b) & (b > 0), a / b, np.nan)
            return Built(v, none)
        if r.op == "geohash":
            return self._geohash(r)
        if r.op == "a3":
            return self._a3_column(r)
        if r.op == "prev":
            return self._prev(r)
        if r.op == "since_last":
            return self._since_last(r)
        if r.op == "since_first":
            return self._since_first(r)
        return self._windowed(r)

    def _windowed(self, r: Recipe) -> Built:
        g = self.group(r)
        ok = self.eligible(r, g)
        span = r.window + r.lag
        cens = self.censored_window(span)
        own_missing = g < 0  # the row's own key (or own `same` value) is missing: no comparable history
        if r.op == "count":
            sw, off = self._strict(g, r.lag)
            v = self._take(sw.count(r.window, where=self._pad(ok, r.lag)), off)
        elif r.op in ("sum", "mean"):
            x = numbers(self.df[r.value])
            okx = ok & np.isfinite(x)
            sw, off = self._strict(g, r.lag)
            n = self._take(sw.count(r.window, where=self._pad(okx, r.lag)), off)
            s = self._take(sw.sum(r.window, self._pad(x, r.lag), where=self._pad(okx, r.lag)), off)
            with np.errstate(invalid="ignore", divide="ignore"):
                v = np.where(n > 0, s if r.op == "sum" else s / n, np.nan)
        elif r.op == "distinct":
            vals = self.df[r.value].to_numpy(dtype=object)
            okv = ok & ~pd.isna(vals)
            sw, off = self._strict(g, r.lag)
            if r.lag:
                vals = np.concatenate([vals, np.full(self.n, None, dtype=object)])
            v = self._take(sw.distinct_count(r.window, vals, where=self._pad(okv, r.lag)), off)
        else:  # min, max
            x = numbers(self.df[r.value])
            okx = ok & np.isfinite(x)
            S = _Sorted(g, self.t, okx)
            hi = S.at_or_after(g, self.t - np.int64(r.lag) * NS)
            lo = S.at_or_after(g, self.t - np.int64(span) * NS)
            v = _reduce_ranges(x[S.rows], lo, hi, r.op)
            v[own_missing] = np.nan
        v = np.asarray(v, dtype=float)
        v[cens] = np.nan
        v[own_missing] = np.nan
        return Built(v, cens.copy())

    def _latest(self, r: Recipe, S: "_Sorted", g: np.ndarray):
        """Latest earlier row in the lookback, and the censored rows (unknown, never a measured 'none')."""
        p = S.latest_before(g, self.t)
        if r.unlimited:
            hit = p >= 0
            return p, hit, (~hit) & (g >= 0)
        lo = self.t - np.int64(r.within) * NS
        hit = p >= 0
        hit[hit] &= S.t[p[hit]] >= lo[hit]
        cens = self.censored_window(r.within) & (g >= 0)
        hit &= ~cens
        return p, hit, cens

    def _dates(self, r: Recipe) -> Built:
        """days_before and days_until (the reviewers' decision D3b): the log encodings with a reason per row."""
        d, rep, wall, why = parse_dates_detail(self.df[r.column], r.date_format, r.sentinels)
        prev = None
        if r.prev_column:
            pd_, prep, pwall, pwhy = parse_dates_detail(self.df[r.prev_column], r.date_format, r.sentinels)
            prev = (pd_, pwall, pwhy)
            rep["prev_parse"] = prep
        month_end, convention = False, ""
        if r.op == "days_until":
            month_end, convention = month_level(r.date_format, wall, why)
            rep["convention"] = convention
        values, reasons, signed, extra = encode_dates(self.t_exact, self.t_day, d, wall, why, r.op, r.same_day,
                                                      prev=prev, month_end=month_end,
                                                      tz_offset_hours=r.tz_offset_hours)
        rep.update(extra)
        bad = int(extra["reasons"].get("implausible", 0))
        if bad:   # implausible values count as parse failures (the checks' parse stop)
            rep["failed"] = int(rep["failed"]) + bad
            rep["failed_share"] = rep["failed"] / rep["non_null"] if rep["non_null"] else 0.0
        usable = why == ""
        w = np.where(usable, wall, 0)
        detail = {"day": np.where(usable, np.floor_divide(w, np.int64(DAY) * NS), -1),
                  "timed": usable & (np.mod(w, np.int64(DAY) * NS) != 0)}
        return Built(values, np.zeros(self.n, dtype=bool), {"parse": rep}, reasons=reasons, signed=signed,
                     detail=detail)

    def _interval(self, r: Recipe, seconds: np.ndarray, hit: np.ndarray) -> Tuple[np.ndarray, Dict[str, object]]:
        """ln(1 + whole seconds) (the reviewers' decision D3b); the report keeps the interval in the recipe's unit."""
        v = np.full(self.n, np.nan)
        v[hit] = np.log1p(seconds[hit].astype(float))
        rep: Dict[str, object] = {"interval_unit": r.unit}
        if hit.any():
            rep["interval_median"] = float(np.median(seconds[hit])) / UNITS[r.unit]
        return v, rep

    def _since_last(self, r: Recipe) -> Built:
        g = self.group(r)
        ok = self.eligible(r, g)
        S = _Sorted(g, self.t, ok)
        p, hit, cens = self._latest(r, S, g)
        secs = np.zeros(self.n, dtype=np.int64)
        secs[hit] = (self.t[hit] - S.t[p[hit]]) // NS
        v, rep = self._interval(r, secs, hit)
        return Built(v, cens, rep)

    def _since_first(self, r: Recipe) -> Built:
        g = self.group(r)
        ok = self.eligible(r, g)
        S = _Sorted(g, self.t, ok)
        p = S.first_in(g, self.t - np.int64(r.within) * NS, self.t)
        hit = p >= 0
        secs = np.zeros(self.n, dtype=np.int64)
        secs[hit] = (self.t[hit] - S.t[p[hit]]) // NS
        v, rep = self._interval(r, secs, hit)
        cens = self.censored_window(r.within)
        v[cens] = np.nan
        return Built(v, cens.copy(), rep)

    def _prev(self, r: Recipe) -> Built:
        g = raw_codes(self.df[r.history_key].to_numpy(dtype=object))
        S = _Sorted(g, self.t, np.ones(self.n, dtype=bool), tie=self.tie)
        p, hit, cens = self._latest(r, S, g)
        vals = self.df[r.column].to_numpy(dtype=object)
        out = np.full(self.n, None, dtype=object)
        out[hit] = vals[S.rows[p[hit]]]
        out[pd.isna(out)] = None
        return Built(out, cens)

    def _a3_column(self, r: Recipe) -> Built:
        if self.subsecond_share > 0:
            raise RecipeError(f"{r.text}: the 26 October builders compare stored-precision times, and "
                              f"{self.subsecond_share:.2%} of rows carry sub-second parts; refused "
                              "(design review item 31)")
        if self._a3 is None:
            if self.a3_builders is None:
                raise RecipeError("a3 recipes need the 26 October builders from the resolver")
            groups_mod, new_mod = self.a3_builders
            parts = []
            if groups_mod is not None:
                parts.append(groups_mod.compute_groups(self.df, self.extract_start))
            if new_mod is not None:
                parts.append(new_mod.compute_new(self.df, self.extract_start))
            self._a3 = pd.concat(parts, axis=1) if parts else pd.DataFrame(index=self.df.index)
        if r.column not in self._a3.columns:
            raise RecipeError(f"{r.text}: the 26 October builders have no column {r.column}")
        return Built(self._a3[r.column].to_numpy(), np.zeros(self.n, dtype=bool))

    a3_builders = None
    # TFM's geohash table; None reads SETTINGS.yaml geohash_table (load_geohash_table). A caller may set its own.
    geohash_table: Optional[GeohashTable] = None

    def _geohash(self, r: Recipe) -> Built:
        """TFM's postal-code geohash: row level, so nothing is censored. TFM's tabular lookup applies only to the
        pairs TFM precomputes (module docstring, item 2). With no table configured (SETTINGS.yaml geohash_table
        blank), the fallback of the reviewers' decision D9-Y20: the normalized postal code paired with its
        country, a category the extended artifact caps at 10 accounts ("postal code, capped")."""
        if self.geohash_table is None and not geohash_table_configured():
            values = postal_fallback(self.df[r.column], self.df[r.country])
            return Built(values, np.zeros(self.n, dtype=bool),
                         {"geohash_fallback": "postal code, capped (no geohash table configured)",
                          "geohash_missing": int(pd.isna(pd.Series(values, dtype=object)).sum())})
        table = self.geohash_table if self.geohash_table is not None else load_geohash_table()
        values, _, counts = table.lookup(self.df[r.column], self.df[r.country],
                                         precomputed=tfm_geohash_column(r) is not None)
        report = {"geohash_table": table.source, "geohash_table_sha256": table.sha256,
                  **{f"geohash_{k}": v for k, v in counts.items()}}
        return Built(values, np.zeros(self.n, dtype=bool), report)


def month_level(date_format: Optional[str], wall: np.ndarray, why: np.ndarray) -> Tuple[bool, str]:
    """A known future date at month level is read as the last day of its month (the reviewers' decision D3b): a
    format with a month and a year but no day (yyyymm, MMYY), or a source whose values all fall on day 1."""
    if date_format and date_format.split(":", 1)[0] not in COUNT_FORMATS:
        has_day = any(c in date_format for c in ("%d", "%j"))
        if "%m" in date_format and ("%y" in date_format or "%Y" in date_format) and not has_day:
            return True, f"month-level format {date_format}: the last day of the month"
    ok = why == ""
    if ok.any():
        days = pd.to_datetime(wall[ok]).day
        if (np.asarray(days) == 1).all():
            return True, "every value on day 1: the last day of the month"
    return False, "the date as stored"


def _event_seconds(t_exact: np.ndarray, t_day: np.ndarray, d: np.ndarray, wall: np.ndarray, why: np.ndarray,
                   tz_offset_hours: Optional[float]):
    """Per row: whole seconds from the date to the transaction (a date with no time part: calendar days x
    86,400), whether it has no time part, and the reason before the time comparison."""
    day_ns = np.int64(DAY) * NS
    usable = why == ""
    w = np.where(usable, wall, 0)
    date_only = usable & (np.mod(w, day_ns) == 0)       # judged in the date's own zone
    dd = np.where(usable, d, 0)
    if tz_offset_hours:
        dd = dd - np.int64(round(tz_offset_hours * 3600)) * NS * (~date_only)
    secs = np.floor_divide(t_exact, NS) - np.floor_divide(dd, NS)
    cal = t_day - np.floor_divide(w, day_ns)
    secs = np.where(date_only, cal * DAY, secs)
    reason = why.copy()
    floor_day = _day_ns(EVENT_FLOOR_DAY) // int(day_ns)
    reason[usable & (np.floor_divide(w, day_ns) < floor_day)] = "implausible"
    return secs, date_only, reason


def encode_dates(t_exact: np.ndarray, t_day: np.ndarray, d: np.ndarray, wall: np.ndarray, why: np.ndarray,
                 op: str, same_day: str = "missing", prev=None, month_end: bool = False,
                 tz_offset_hours: Optional[float] = None):
    """The model's value of a date recipe (the reviewers' decision D3b), with a reason code per row, the signed
    difference in days (as days before the transaction) and the counts.

    days_before: ln(1 + s), s whole seconds from the event to the transaction; s < 0 is after_transaction; s = 0 is
    same_second, or same_day for a date with no time part (kept as ln(1) = 0 only with same_day=keep); an event
    before 1900-01-02 or more than 36,525 days back is implausible. ``prev`` (PREV's dates, wall dates and codes)
    makes a CURR/PREV pair: CURR when strictly before the transaction, else PREV when it is.
    days_until: sign(u) ln(1 + |u|), u the calendar days from the transaction's day to the date's (the last day of
    its month when ``month_end``); |u| > 3,653 is implausible."""
    n = len(t_exact)
    day_ns = np.int64(DAY) * NS
    out = np.full(n, np.nan)
    signed = np.full(n, np.nan)
    extra: Dict[str, object] = {}
    if op == "days_until":
        usable = why == ""
        w = np.where(usable, wall, 0)
        day = np.floor_divide(w, day_ns)
        if month_end and usable.any():
            last = pd.to_datetime(w[usable]) + pd.offsets.MonthEnd(0)
            day = day.copy()
            day[usable] = np.floor_divide(last.to_numpy(dtype="datetime64[ns]").astype(np.int64), day_ns)
        u = day - t_day
        reason = why.copy()
        reason[usable & (np.abs(u) > FUTURE_MAX_ABS_DAYS)] = "implausible"
        ok = reason == ""
        out[ok] = np.sign(u[ok]) * np.log1p(np.abs(u[ok]).astype(float))
        signed[usable] = -u[usable].astype(float)
        date_only = usable & (np.mod(w, day_ns) == 0)
        extra.update(date_only=int(date_only.sum()), with_time=int((usable & ~date_only).sum()), same_day=0)
    else:
        secs, date_only, reason = _event_seconds(t_exact, t_day, d, wall, why, tz_offset_hours)
        usable = reason == ""
        if prev is not None:
            pd_, pwall, pwhy = prev
            p_secs, p_date_only, p_reason = _event_seconds(t_exact, t_day, pd_, pwall, pwhy, tz_offset_hours)
            c_ok = usable & (secs > 0)
            p_ok = (p_reason == "") & (p_secs > 0)
            use_prev = ~c_ok & p_ok
            chosen = c_ok | use_prev
            both = usable & (p_reason == "")
            extra["prev_rows"] = int(use_prev.sum())
            extra["pair_both_present"] = int(both.sum())
            extra["prev_not_earlier"] = int((both & (pd_ >= d)).sum())
            # neither is strictly before the transaction: after it (CURR refreshed by this or a later
            # transaction), else the reason of the side that holds no date
            r_new = np.full(n, "", dtype=object)
            late_c = usable & ~c_ok
            late_p = (p_reason == "") & ~p_ok
            both_late = ~chosen & late_c & (late_p | (p_reason == "missing"))
            r_new[both_late] = "after_transaction"
            c_bad = ~chosen & ~both_late & (reason != "")
            r_new[c_bad] = reason[c_bad]
            p_bad = ~chosen & ~both_late & ~c_bad
            r_new[p_bad] = np.where(p_reason[p_bad] != "", p_reason[p_bad], "missing")
            signed[late_c] = secs[late_c] / DAY
            secs = np.where(use_prev, p_secs, secs)
            date_only = np.where(use_prev, p_date_only, date_only)
            reason, usable = r_new, chosen
            extra.update(date_only=int((chosen & date_only).sum()), with_time=int((chosen & ~date_only).sum()),
                         same_day=0)
        else:
            reason = reason.astype(object)
            reason[usable & (secs < 0)] = "after_transaction"
            same = usable & (secs == 0)
            keep_same = same & date_only & (same_day == "keep")
            reason[same & ~keep_same] = np.where(date_only[same & ~keep_same], "same_day", "same_second")
            extra.update(date_only=int((usable & date_only).sum()), with_time=int((usable & ~date_only).sum()),
                         same_day=int((same & date_only).sum()))
        signed[usable] = secs[usable] / DAY
        reason[usable & (secs > EVENT_MAX_DAYS * DAY) & (reason == "")] = "implausible"
        ok = reason == ""
        out[ok] = np.log1p(secs[ok].astype(float))
    codes = pd.Series(reason[reason != ""]).value_counts()
    extra["reasons"] = {str(k): int(v) for k, v in codes.items()}
    return out, reason, signed, extra


def days_from(t: np.ndarray, d: np.ndarray, op: str, same_day: str = "missing", wall: Optional[np.ndarray] = None,
              t_day: Optional[np.ndarray] = None) -> Tuple[np.ndarray, Dict[str, int]]:
    """Signed days between the transaction time ``t`` and the date ``d`` (both int64 ns; NaT is int64 min), for
    reports only: the model reads ``encode_dates`` (the reviewers' decision D3b).

    ``days_before`` is t minus d, ``days_until`` is d minus t. A date with no time part (exactly midnight) is
    compared by calendar day in whole days. For ``days_before`` that same-day value is missing unless
    ``same_day=keep``; a time part, when the source has one, gives fractional days.
    """
    day_ns = np.int64(DAY) * NS
    ok = d != np.iinfo(np.int64).min
    wall = d if wall is None else np.asarray(wall, dtype=np.int64)
    date_only = ok & (np.mod(wall, day_ns) == 0)  # judged in the date's own zone
    timed = ok & ~date_only
    out = np.full(len(t), np.nan)
    sign = 1.0 if op == "days_before" else -1.0
    out[timed] = sign * (t[timed] - d[timed]) / day_ns
    tday = np.floor_divide(t, day_ns) if t_day is None else t_day
    cal = tday - np.floor_divide(wall, day_ns)  # a date with no time part names a calendar day as written
    out[date_only] = sign * cal[date_only].astype(float)
    same = date_only & (cal == 0)
    if op == "days_before" and same_day == "missing":
        out[same] = np.nan
    return out, {"date_only": int(date_only.sum()), "with_time": int(timed.sum()), "same_day": int(same.sum())}


def cast_output(values, model_type: str) -> np.ndarray:
    """Numbers as float64; codes as text (``code_text``), missing as None."""
    if model_type == "continuous":
        return numbers(values)
    if model_type == "categorical":
        return code_text(values)
    raise RecipeError(f"model_type {model_type!r}; use continuous or categorical")


def load_engine():
    """The base's strict-window module and the 26 October builders, through the resolver."""
    import nf_layout
    sw = nf_layout.get("strict_window")
    try:
        groups = nf_layout.get("groups")
    except SystemExit:
        groups = None
    try:
        new = nf_layout.get("features_new")
    except SystemExit:
        new = None
    return sw, (groups, new)


def build_columns(df: pd.DataFrame, fields: Sequence[Tuple[str, str, str]], extract_start,
                  engine=None, account_col: str = ACCOUNT, time_col: str = TIME,
                  tie_col: Optional[str] = TIE, geohash_table: Optional[GeohashTable] = None
                  ) -> Tuple[pd.DataFrame, Dict[str, Dict[str, object]]]:
    """Every engineered column of one file.

    ``fields`` holds (name, recipe text, model_type) per field. Returns the new columns in that order
    (float64 numbers, text codes) aligned to ``df``, and per field: censored count, missing count, notes.
    ``engine`` is ``load_engine()``'s result; tests may pass their own. ``geohash_table`` is the table a run read
    once (``load_geohash_table``), so every file of the run uses that table; None reads SETTINGS.yaml's.
    """
    sw_mod, a3 = engine if engine is not None else load_engine()
    ctx = FileContext(df, extract_start, sw_mod, account_col, time_col, tie_col)
    ctx.a3_builders = a3
    if geohash_table is not None:
        ctx.geohash_table = geohash_table
    cols: Dict[str, pd.Series] = {}
    stats: Dict[str, Dict[str, object]] = {}
    for name, text, model_type in fields:
        if name in df.columns:
            raise RecipeError(f"{name} is already a column of the file; an engineered name must be new")
        r = parse(text)
        if r.op == "raw":
            raise RecipeError(f"{name}: a raw field is not built; it passes through unchanged")
        if r.op == "geohash" and model_type != "categorical":
            raise RecipeError(f"{name}: geohash(...) gives a category; model_type must be categorical")
        b = ctx.build(r)
        out = cast_output(b.values, model_type)
        miss = pd.isna(pd.Series(out, dtype=object if model_type == "categorical" else float)).to_numpy()
        stats[name] = {"rows": int(ctx.n), "censored": int(b.censored.sum()),
                       "missing_not_censored": int((miss & ~b.censored).sum()),
                       "subsecond_share": ctx.subsecond_share, **b.report}
        cols[name] = pd.Series(out, index=df.index, dtype=object if model_type == "categorical" else np.float64)
    frame = pd.DataFrame(cols, index=df.index)
    for name, col in cols.items():  # pandas 3 would infer a text dtype with NaN for missing; keep None
        frame[name] = col
    return frame, stats


# --------------------------------------------------------------------------------------------- #
# Interface for the importance tools (family perturbations) and the source-flag rule
# --------------------------------------------------------------------------------------------- #
def _map_rows(field_map) -> List[Tuple[str, str, str]]:
    """(name, recipe, model_type) per map row, in the map's order."""
    df = field_map if isinstance(field_map, pd.DataFrame) else pd.DataFrame(field_map)
    out = []
    for _, row in df.iterrows():
        recipe = str(row.get("recipe", "raw") or "raw").strip()
        out.append((str(row["name"]).strip(), recipe, str(row.get("model_type", "continuous") or "continuous")))
    return out


def _row_sources(name: str, recipe: str) -> List[str]:
    r = parse(recipe)
    return [name] if r.op == "raw" else r.sources


def build_fields(frame: pd.DataFrame, field_map, account_col: str = ACCOUNT, time_col: str = TIME,
                 extract_start=None, engine=None, tie_col: Optional[str] = TIE) -> pd.DataFrame:
    """``frame`` with every engineered column of ``field_map`` added, in the map's order.

    Raw fields pass through (they are already columns of ``frame``). Every other column is kept unchanged and
    the rows keep their order. Deterministic, with no side effects. ``frame`` must hold every row of the file
    (each account's whole history) and ``extract_start`` must be the split's declared start ("train",
    "evaluation" or a date); None switches censoring off and is for tests only.
    """
    fields = [(n, r, m) for n, r, m in _map_rows(field_map) if parse(r).op != "raw"]
    built, _ = build_columns(frame, fields, extract_start, engine=engine, account_col=account_col,
                             time_col=time_col, tie_col=tie_col)
    out = frame.copy()
    for name in built.columns:
        out[name] = built[name]
    return out


def dependency_closure(field_map, names: Sequence[str]) -> Dict[str, set]:
    """For the given field names: ``sources``, the raw columns they read (a raw field is its own source), and
    ``outputs``, every engineered field of the map that reads any of those sources (the given engineered names
    included). Perturbing the sources and rebuilding ``outputs`` together is a family perturbation."""
    rows = _map_rows(field_map)
    known = {n for n, _, _ in rows}
    missing = [n for n in names if n not in known]
    if missing:
        raise RecipeError(f"not in the field map: {', '.join(missing)}")
    src = set()
    for n, r, _ in rows:
        if n in names:
            src.update(_row_sources(n, r))
    outs = {n for n, r, _ in rows if parse(r).op != "raw" and set(parse(r).sources) & src}
    return {"sources": src, "outputs": outs}


def required_columns(field_map, names: Sequence[str], account_col: str = ACCOUNT, time_col: str = TIME,
                     tie_col: Optional[str] = TIE) -> List[str]:
    """The raw columns ``build_fields`` needs to compute these fields: the account and time keys, the
    transaction id (ties inside a second), then every source, in first-use order."""
    rows = {n: r for n, r, _ in _map_rows(field_map)}
    missing = [n for n in names if n not in rows]
    if missing:
        raise RecipeError(f"not in the field map: {', '.join(missing)}")
    out = [account_col, time_col] + ([tie_col] if tie_col else [])
    for n in names:
        for c in _row_sources(n, rows[n]):
            if c not in out:
                out.append(c)
    return out


def inherited_flags(field_map, results: Dict[str, str], blocking: Sequence[str] = ("STOP", "WAIT")
                    ) -> Dict[str, List[str]]:
    """Design review item 28: a STOP or WAIT on a source column carries to every recipe that reads it.

    ``results`` maps a field name (a raw field's name is its pod column) to its check result. Returns, per
    engineered field that reads a blocked source, reasons such as ``"source pwd_chg_dt: WAIT"``.
    """
    out: Dict[str, List[str]] = {}
    for n, r, _ in _map_rows(field_map):
        rec = parse(r)
        if rec.op == "raw":
            continue
        why = [f"source {c}: {results[c]}" for c in rec.sources if results.get(c, "").upper() in blocking]
        if why:
            out[n] = why
    return out
