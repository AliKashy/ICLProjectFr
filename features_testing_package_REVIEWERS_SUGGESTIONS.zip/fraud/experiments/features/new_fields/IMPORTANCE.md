# Transformer feature sensitivity

Use the fitted model's config and checkpoint. The tool scores the designated
`populations.rank_a.files` range in `SETTINGS.yaml` (initially 8228-8243) and
measures June targets, keeping earlier history in each window. A configured
replacement RANK-A file range is used by the scorer and its exposure records;
the two null checks use its first file. The configured target interval must
remain 2025-06-01 to 2025-07-01, which this scorer measures.
It changes the file range in memory; it does not edit the fitted config.
Use `--rank-a-base` only if that population is under a different data root.

Run the cost estimate first. These are command templates:

```bash
python fraud/experiments/features/new_fields/nf_importance.py estimate \
  --config FIT_CONFIG --checkpoint CHECKPOINT --timing TIMING_JSON
python fraud/experiments/features/new_fields/nf_importance.py run \
  --config FIT_CONFIG --checkpoint CHECKPOINT --timing TIMING_JSON \
  --field-map FIELD_MAP_CSV --clusters CLUSTERS_CSV
python fraud/experiments/features/new_fields/nf_importance.py summary \
  --output checkpoints/new_fields/importance/RUN_NAME
```

`TIMING_JSON` supplies measured `seconds_per_row` and full-file `rank_a_rows`.
The same values can be supplied with `--seconds-per-row` and `--rank-a-rows`.
Cost uses all scored rows, including history months. Two one-file null checks
and CPU statistics are extra. The account share is not an exact row fraction.

Defaults: 25% of whole accounts, one permutation repeat, 2,000 account draws,
90% intervals, and a 24 GPU-hour estimate limit. Options are shown by `--help`.
The default plan (`--units both`) measures individual inputs and supplied
clusters as direct output sensitivities. `--units groups` measures every
cluster with two or more inputs of this model, and singles only for inputs in no
such cluster. The queue passes `--units both --fallback-units groups` from
SETTINGS.yaml (the reviewers' decision D6): when both does not fit the GPU
limit, by the estimate or by the cost measured on the baseline pass
((1 + units x repeats) x the baseline's seconds), the run takes groups and
`plan.json` records both figures; when groups does not fit either, it stops
with both figures. Declare profile fields with `--profile-fields` or the
field map's `donor_unit=account`. The field-map category `account and customer
profile` also defaults to account donors; an explicit donor declaration takes
precedence. Other unmarked units use event donors; this is a
policy, not proof that a field is event-level. Changing account profiles need
a separately specified longitudinal donor policy; static donors cannot model it.

`--unit-spec` accepts a JSON list of unit definitions, including family units.
Family units name `name`, `method: family`, `source_columns`, and `donor_unit`.
Their complete recipe dependencies come from the field map and shared builder.
Those two dependency descriptions must agree. Families grouped by customer,
card or another non-account key use all accounts in the loaded files, including
in the cost estimate; an account subsample would truncate those groups. This
does not add history outside the loaded files. Cluster tables may list one
`member` per row.
The share applies to the whole run, so one family keyed by customer or card
makes every pass score 100% of the accounts; run such a family as its own job.
The queue passes no family units.
Direct output sensitivities can be inconsistent with sibling engineered values.
Calendar sensitivity holds timestamps fixed. Neither is a causal-effect estimate.

The return includes scores, row identities, per-pass exposure/cost, attention,
paired metrics, and a short summary. The summary's first line names the fit it
measured: a stage 2 fit, not the shipped model. The queue runs the tool once, on
the final kept fit after month out (before pruning when pruning is on), and only
when an adding step was adopted (the reviewers' decision D6).
The summary lists the units that qualify under reading B (the whole interval
at or below zero on UDR and AP, this fit) as information for the next model
version; no field leaves this model on it. Pruning is off by the reviewers'
decision D4b; when it is on, it uses reading B, and it reopens only for a stated
cost reason.
The baseline also writes `engine_check.json`, checking UDR, VDR, the bank's
FP/TP ratio and AP against the shared results reader at the same alert count.
Undefined values must agree as well.
Attention describes within-transaction
pooling, not historical attention. Bootstrap and permutation variation do not
measure training-seed uncertainty. This tool makes no keep/drop decision.
