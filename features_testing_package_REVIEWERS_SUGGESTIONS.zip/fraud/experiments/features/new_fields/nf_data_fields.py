"""Which fields the data tools build, and which files they read.

Shared by the enriched copies (``nf_build_enriched.py``) and the extended artifact (``nf_build_artifact.py``).
Every refusal raises ``Refused`` (exit 4) with the reason. Importing this module does no work.
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import pandas as pd

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

import nf_recipes as R  # noqa: E402

ENTERS = ("PASS", "FLAG")
# The order the design lists the file ranges in (section 2.3).
RANGE_ORDER = ("train", "epoch_val", "rank_a", "rank_b", "select", "test1", "ds_train", "ds_select")
EVAL_FROM = 8000  # files numbered 8000 and up sit in the evaluation base; their extract starts 2025-05-01


class Refused(SystemExit):
    """Exit 4 with the reason printed."""

    def __init__(self, message: str):
        import nf_common
        print(nf_common.wrap(message), file=sys.stderr)   # at most 90 characters a line
        super().__init__(4)
        self.message = message


@dataclass
class Field:
    name: str
    recipe: str
    model_type: str
    group: str
    kind: str
    sources: List[str]
    parsed: R.Recipe


def read_status(path) -> pd.DataFrame:
    """``field_status.csv`` of the CPU checks: field, result, reasons. A refusal names it from the project root
    when it lies under it, as the other tools do, so a screen never shows a path of this machine."""
    import nf_common
    p = Path(path)
    if not p.is_file():
        raise Refused(f"refused: {nf_common.rel(p)} is missing; run the CPU field checks first (exit 4)")
    st = pd.read_csv(p, dtype=str, keep_default_na=False)
    st.columns = [c.strip() for c in st.columns]
    for need in ("field", "result"):
        if need not in st.columns:
            raise Refused(f"refused: {nf_common.rel(p)} has no column {need} (exit 4)")
    return st


def select_fields(map_df: pd.DataFrame, status: pd.DataFrame, map_path, status_path,
                  engineered_only: bool) -> List[Field]:
    """CONFIRMED rows whose check result is PASS or FLAG, in the map's order.

    Refuses: any UNCONFIRMED row; a map newer than ``field_status.csv``; a CONFIRMED row with no check result;
    a recipe that does not parse; a recipe that disagrees with the row's kind.
    """
    unconf = map_df.loc[map_df["list_status"].str.upper() == "UNCONFIRMED", "name"].tolist()
    if unconf:
        raise Refused(f"refused: {len(unconf)} map row(s) are UNCONFIRMED (first: {', '.join(unconf[:5])}). "
                      "Adopt the owner's list first (exit 4)")
    if os.path.getmtime(map_path) > os.path.getmtime(status_path):
        raise Refused(f"refused: the map is newer than {Path(status_path).name}; run the CPU checks again (exit 4)")
    res = dict(zip(status["field"], status["result"].str.upper()))
    confirmed = map_df[map_df["list_status"].str.upper() == "CONFIRMED"]
    inherited = R.inherited_flags(confirmed[["name", "recipe", "model_type"]], res)  # review item 28
    out: List[Field] = []
    for _, row in map_df.iterrows():
        if row["list_status"].upper() != "CONFIRMED":
            continue
        name = row["name"]
        if name not in res:
            raise Refused(f"refused: {name} is CONFIRMED but has no result in field_status.csv (exit 4)")
        if res[name] not in ENTERS:
            continue
        if name in inherited:
            print(f"left out: {name}: {'; '.join(inherited[name])} (a blocked source blocks its recipes)",
                  file=sys.stderr)
            continue
        try:
            r = R.parse(row["recipe"])
        except R.RecipeError as e:
            raise Refused(f"refused: {name}: {e} (exit 4)")
        if (row["kind"] == "raw") != (r.op == "raw"):
            raise Refused(f"refused: {name}: kind {row['kind']} but recipe {row['recipe']!r} (exit 4)")
        if row["model_type"] not in ("continuous", "categorical"):
            raise Refused(f"refused: {name}: model_type {row['model_type']!r} (exit 4)")
        if engineered_only and r.op == "raw":
            continue
        srcs = [s.strip() for s in row["source_columns"].split(";") if s.strip()] or r.sources
        out.append(Field(name, row["recipe"], row["model_type"], row["group"], row["kind"], srcs, r))
    names = [f.name for f in out]
    dup = sorted({n for n in names if names.count(n) > 1})
    if dup:
        raise Refused(f"refused: names used twice: {', '.join(dup)} (exit 4)")
    return out


@dataclass
class FileRange:
    name: str
    start: int
    end: int
    base: str
    extract_start: str

    def files(self) -> List[Tuple[int, str]]:
        import nf_data_io as io
        return [(n, io.join(self.base, f"part_{n}.parquet")) for n in range(self.start, self.end + 1)]


def parse_range_overrides(items: Sequence[str]) -> Dict[str, Tuple[int, int]]:
    out = {}
    for it in items or ():
        try:
            name, span = it.split("=", 1)
            a, b = span.split("-", 1)
            out[name.strip()] = (int(a), int(b))
        except ValueError:
            raise Refused(f"refused: --range {it!r}; write name=start-end (exit 4)")
    return out


def file_ranges(populations: Dict, train_base: str, eval_base: str, names: Optional[Sequence[str]] = None,
                overrides: Optional[Dict[str, Tuple[int, int]]] = None,
                extract_train: str = R.EXTRACT_START["train"],
                extract_eval: str = R.EXTRACT_START["evaluation"]) -> List[FileRange]:
    """The file ranges the copies cover. A range under 8000 reads the training base, from 8000 the evaluation
    base. A range may not straddle 8000."""
    spans: Dict[str, Tuple[int, int]] = {}
    for k, v in (populations or {}).items():
        files = v.get("files") if isinstance(v, dict) else None
        if files and len(files) == 2:
            spans[k] = (int(files[0]), int(files[1]))
    spans.update(overrides or {})
    wanted = list(names) if names else [k for k in RANGE_ORDER if k in spans] + \
        [k for k in spans if k not in RANGE_ORDER]
    out = []
    for k in wanted:
        if k not in spans:
            raise Refused(f"refused: no file range named {k} (exit 4)")
        a, b = spans[k]
        if a > b or (a < EVAL_FROM <= b):
            raise Refused(f"refused: range {k} = {a}-{b} is empty or straddles {EVAL_FROM} (exit 4)")
        ev = a >= EVAL_FROM
        out.append(FileRange(k, a, b, eval_base if ev else train_base, extract_eval if ev else extract_train))
    return out


def base_config_paths(cfg: Dict) -> Tuple[str, str, Optional[str]]:
    """Training base, evaluation base and credentials path from the chosen config."""
    data = cfg.get("data", {}) or {}
    ev = cfg.get("eval", {}) or {}
    s3 = cfg.get("s3", {}) or {}
    return data.get("train_base"), ev.get("base"), s3.get("cred_path")
