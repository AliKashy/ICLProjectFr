"""Downstream check of a step's kept fit: the feature-store view (DESIGN.md sections 7.8 and 8.7, component 18).

For each kept fit it uses the unchanged embedding tools (reached through the resolver: the exporter, the export
records and the downstream XGBoost tool) and adds no model code of its own:
1. export the 48-number embedding on DS_TRAIN (4001-4010) and DS_SELECT (8217-8227), running the exporter script
   by path. The exporter records "exported" in the run's manifest, which makes the run final;
2. check each export: passing validation, width 48 (the embedding contract), one row per scored row, unique ids,
   finite values, same-pass reconstruction, and the parquet's SHA-256 equal to its manifest;
3. write the encoder contract and the downstream config with the export records' own functions;
4. fit the downstream model with the downstream tool: DS_TRAIN only, its fixed tree budget, seed 42; it reads
   DS_SELECT June once. The raw arm uses the base predictor list for every step (the flag reads this arm), and,
   when the step has new raw inputs, a second fit uses the step's own predictor list (design review item 24);
5. use 1 (now): the embedding's lift = metric(raw + embedding) minus metric(raw), for UDR at 0.6% and AP;
   use 2 (when model 15298's scores for those rows arrive): the same lift with 15298's score as an offset
   (a fixed base margin, logit of the score) in both arms. Off until SETTINGS.yaml turns it on;
6. ``lift`` hands the step's kept fit and its control to the reader (``nf_read.py lift``, the one writer of
   reads/<step>_lift.json). The reader compares them on the same DS_SELECT rows with a paired account bootstrap.
   If the group passed the fraud rule but its UDR lift is lower than the control's by more than one paired SE,
   the screen says so for the owner. The flag changes no decision.

Commands (from the project root, by path):
  run   --name <run>_seed42 --run-dir <fit folder>        export, check, contract, fit
  lift  --step A1 --fit <name> --control <name> [--use 1|2] [--decision ADOPT]
  use2  --name <name> --scores <15298 score file> [--scores ...]

Exit codes: 0 done; 1 crash; 2 bad arguments; 3 STOP (a check failed); 4 refused (busy GPU, partial outputs,
an incomplete run, different rows, changed inputs).
"""
import argparse
import json
import math
import os
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path(__file__).resolve().parents[4]
for _p in (str(HERE), str(ROOT / "src"), str(ROOT)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import nf_common  # noqa: E402
import nf_layout  # noqa: E402

EMBED_WIDTH = 48                 # the embedding's export contract
ID, ACCOUNT, LABEL = "fi_transaction_id", "Nmap_account_reference_xid", "frd_tag"
USE_ARMS = {1: ("raw_embedding", "raw"), 2: ("offset_raw_embedding", "offset_raw")}
USE_TEXT = {1: "use 1: raw alone against raw + embedding",
            2: "use 2: offset on 15298's score, raw alone against raw + embedding"}
COMPLETE = ("finished", "budget_reached")


class Refused(Exception):
    code = 4


class Stop(Exception):
    code = 3


# ---------------------------------------------------------------- folders

def dirs(name):
    c2 = nf_common.c2()
    return {"exports": c2 / "exports" / name, "down": c2 / "downstream" / name}


def _population(key):
    pops = (nf_common.settings().get("populations") or {})
    if key not in pops or "files" not in pops[key]:
        raise Refused(f"SETTINGS.yaml populations has no {key}.files")
    a, b = pops[key]["files"]
    return int(a), int(b), pops[key].get("targets")


def _abs(path):
    p = Path(str(path))
    return p if p.is_absolute() or "://" in str(path) else ROOT / p


# ---------------------------------------------------------------- export and check

def run_complete(run_dir):
    manifest = Path(run_dir) / "run_manifest_v2.json"
    if not manifest.is_file():
        raise Refused(f"{nf_common.rel(manifest)} not found: not a complete fit")
    m = nf_common.read_json(manifest)
    if m.get("status") not in COMPLETE or not (Path(run_dir) / "best.ckpt").is_file():
        raise Refused(f"{nf_common.rel(run_dir)} is not complete (status {m.get('status')}); the downstream "
                      "check reads kept fits only")
    return m


def export_population(cfg_path, checkpoint, out, base, start, end):
    """Run the unchanged exporter by path (design review item 29). Skips a passing export of the same checkpoint
    and file range; refuses partial ones and ones from another checkpoint or range."""
    out = Path(out)
    if out.exists():
        v = out / "validation.json"
        if v.is_file() and (out / "manifest.json").is_file() and nf_common.read_json(v).get("passed") is True:
            m = nf_common.read_json(out / "manifest.json")
            files = m.get("files") or {}
            if m.get("checkpoint_sha256") != nf_common.sha256_file(checkpoint):
                raise Refused(f"{nf_common.rel(out)} holds an export of another checkpoint; rename it")
            if (str(files.get("base")), int(files.get("start", -1)), int(files.get("end", -1))) != (
                    str(base), int(start), int(end)):
                raise Refused(f"{nf_common.rel(out)} holds files {files}, not {base} {start}-{end}; rename it")
            return "skipped (exists and passed)"
        raise Refused(f"partial outputs: {nf_common.rel(out)} exists without a passing export; rename it")
    exporter = nf_layout.get("export_embeddings").__file__
    out.parent.mkdir(parents=True, exist_ok=True)
    cmd = [sys.executable, exporter, "--config", str(cfg_path), "--checkpoint", str(checkpoint), "--out", str(out),
           f"eval.base={base}", f"eval.file_start={int(start)}", f"eval.file_end={int(end)}"]
    log = out.parent / f"{out.name}.log"
    with open(log, "a", encoding="utf-8") as f:
        f.write(f"{nf_common.utc_now()} {' '.join(cmd[1:])}\n")
        f.flush()
        rc = subprocess.call(cmd, stdout=f, stderr=subprocess.STDOUT)
    if rc != 0:
        raise Stop(f"exporter failed rc={rc} for {nf_common.rel(out)}; see {nf_common.rel(log)}")
    return "exported"


def check_export(out, width=EMBED_WIDTH):
    """The checks of DESIGN.md 7.8 step 2, read from the exporter's own records plus the parquet itself."""
    import pyarrow.parquet as pq
    out = Path(out)
    v = nf_common.read_json(out / "validation.json")
    m = nf_common.read_json(out / "manifest.json")
    parquet = out / "embeddings.parquet"
    meta = pq.ParquetFile(parquet).metadata
    cols = [c for c in pq.ParquetFile(parquet).schema_arrow.names if c.startswith("e_")]
    checks = {
        "passed": v.get("passed") is True,
        "width_48": int(v.get("embedding_width", -1)) == width and len(cols) == width,
        "rows_match": int(v.get("rows", -1)) == int(meta.num_rows) == int(m.get("rows", -2)),
        "unique_ids": v.get("unique_ids") is True,
        "finite": v.get("finite") is True,
        "reconstruction": (v.get("same_pass_reconstruction_max_abs") is not None
                           and float(v["same_pass_reconstruction_max_abs"]) <= 1e-6),
        "sha256": nf_common.sha256_file(parquet) == m.get("embeddings_sha256"),
        "label_free": m.get("labels_read") is False,
    }
    return {"export": nf_common.rel(out), "rows": int(meta.num_rows), "width": len(cols),
            "checkpoint_sha256": m.get("checkpoint_sha256"), "checks": checks, "ok": all(checks.values())}


# ---------------------------------------------------------------- contract, config and fit

def write_split(path, train_paths, select_paths, select_month):
    import yaml
    split = {"populations": {"DS_TRAIN": {"paths": [str(p) for p in train_paths]},
                             "DS_SELECT": {"paths": [str(p) for p in select_paths], "target_month": select_month}}}
    Path(path).write_text(yaml.safe_dump(split, sort_keys=True), encoding="utf-8")
    return path


def predictor_version(path):
    import pandas as pd
    return int(pd.read_csv(_abs(path))["version"].max())


def fit_downstream(dcfg, fit_dir, name, arm_label):
    """The unchanged downstream tool; skip if its report exists, refuse a partial folder. Each fit is one DS_SELECT
    read; it is logged (design review item 36)."""
    fit_dir = Path(fit_dir)
    if (fit_dir / "report.json").is_file() and (fit_dir / "predictions.parquet").is_file():
        return "skipped (report exists)"
    if fit_dir.exists():
        raise Refused(f"partial outputs: {nf_common.rel(fit_dir)} exists without report.json; rename it")
    fs = None
    if dcfg.get("s3_cred_path"):
        fs = nf_layout.attr("s3", "thin_read_filesystem")(dcfg["s3_cred_path"])
    run = nf_layout.attr("downstream_xgb", "run")
    nf_common.append_line(nf_common.c2() / "downstream" / "DS_SELECT_READS.log",
                          f"{nf_common.utc_now()} start {name} {arm_label} checkpoint "
                          f"{dcfg['encoder_contract']['checkpoint']['sha256'][:12]}")
    run(dcfg, str(fit_dir), filesystem=fs)
    nf_common.append_line(nf_common.c2() / "downstream" / "DS_SELECT_READS.log",
                          f"{nf_common.utc_now()} end   {name} {arm_label}")
    return "fitted"


def ds_select_reads(names):
    log = nf_common.c2() / "downstream" / "DS_SELECT_READS.log"
    if not log.is_file():
        return 0
    return sum(1 for ln in log.read_text(encoding="utf-8").splitlines()
               if " start " in ln and ln.split()[2] in names)


def run_main(args):
    lay = nf_layout.resolve(["export_embeddings", "export_records", "downstream_xgb", "s3"])
    from omegaconf import OmegaConf
    run_dir = Path(args.run_dir)
    run_complete(run_dir)
    cfg_path = Path(args.config) if args.config else run_dir / "resolved_train_v2.yaml"
    checkpoint = Path(args.checkpoint) if args.checkpoint else run_dir / "best.ckpt"
    cfg = OmegaConf.load(str(cfg_path))
    d = dirs(args.name)
    tr_a, tr_b, _ = _population("ds_train")
    se_a, se_b, se_targets = _population("ds_select")
    month = args.select_month or (str(se_targets[0])[:7] if se_targets else "2025-06")
    train_base = args.train_base or cfg.data.train_base
    select_base = args.select_base or cfg.eval.base
    lines = [f"layout={lay.layout}", f"run {nf_common.rel(run_dir)}", f"checkpoint {checkpoint.name}  "
             f"sha {nf_common.sha256_file(checkpoint)[:12]}"]
    if not args.no_busy_check:
        busy = nf_common.busy()
        if busy:
            raise Refused("the GPU is busy:\n  " + "\n  ".join(busy))
    exports = {}
    for pop, base, a, b in (("ds_train", train_base, tr_a, tr_b), ("ds_select", select_base, se_a, se_b)):
        out = d["exports"] / pop
        state = export_population(cfg_path, checkpoint, out, base, a, b)
        chk = check_export(out)
        nf_common.write_json(d["down"] / f"check_{pop}.json", chk)
        failed = [k for k, ok in chk["checks"].items() if not ok]
        lines.append(f"{pop} {a}-{b}: {state}; {chk['rows']} rows, width {chk['width']}: "
                     + ("checks passed" if not failed else "FAILED " + ", ".join(failed)))
        if failed:
            raise Stop(f"export check failed for {pop}: {', '.join(failed)}")
        exports[pop] = out
    contract_path = d["down"] / "encoder_contract.json"
    cred = cfg.s3.get("cred_path") if "s3" in cfg else None
    if not contract_path.is_file():
        contract = nf_layout.attr("export_records", "encoder_contract")(str(run_dir), cred, str(checkpoint))
        nf_common.write_json(contract_path, contract)
    contract = nf_common.read_json(contract_path)
    if contract["checkpoint"]["sha256"] != nf_common.sha256_file(checkpoint):
        raise Refused(f"{nf_common.rel(contract_path)} names another checkpoint; rename the folder")
    s3 = nf_layout.attr("s3", "build_file_list")
    split_path = d["down"] / "split.yaml"
    write_split(split_path, s3(train_base, tr_a, tr_b), s3(select_base, se_a, se_b), month)
    settings = nf_common.settings()
    base_predictors = str(_abs((settings.get("downstream") or {}).get("raw_predictors")
                               or settings.get("base_predictors") or "fraud/configs/predictors.csv"))
    make_cfg = nf_layout.attr("export_records", "downstream_config")
    arms = [("base_raw", base_predictors)]
    own = str(_abs(cfg.predictors.csv_path))
    if nf_common.sha256_file(own) != nf_common.sha256_file(base_predictors):
        arms.append(("own_raw", own))
    for label, predictors in arms:
        try:
            dcfg = make_cfg(str(split_path), str(contract_path), str(exports["ds_train"]), str(exports["ds_select"]),
                            cred_path=cred, predictors=predictors, seed=42)
        except ValueError as e:
            raise Refused(f"the export records refuse these exports: {e}")
        dcfg["predictor_version"] = 1 if label == "base_raw" else predictor_version(predictors)
        nf_common.write_json(d["down"] / label / "config.json", dcfg)
        state = fit_downstream(dcfg, d["down"] / label / "fit", args.name, label)
        rep = nf_common.read_json(d["down"] / label / "fit" / "report.json")
        m = rep["metrics"]
        lines.append(f"{label} ({Path(predictors).name}): {state}; DS_SELECT rows {rep['rows']}")
        lines.append(f"  the tool's AP: raw {_f(m['raw'].get('ap'))}, raw + embedding {_f(m['raw_embedding'].get('ap'))}")
    summary = {"name": args.name, "run_dir": nf_common.rel(run_dir), "checkpoint": nf_common.rel(checkpoint),
               "checkpoint_sha256": contract["checkpoint"]["sha256"], "arms": [a for a, _ in arms],
               "exports": {k: nf_common.rel(v) for k, v in exports.items()}, "utc": nf_common.utc_now(),
               "ds_select_reads": ds_select_reads({args.name})}
    summary["predictions"] = {a: nf_common.rel(d["down"] / a / "fit" / "predictions.parquet") for a, _ in arms}
    # the DS_SELECT predictions' sha256, so the planner's lift read covers them (review item 18)
    summary["predictions_sha256"] = {a: nf_common.sha256_file(d["down"] / a / "fit" / "predictions.parquet")
                                     for a, _ in arms}
    summary["columns"] = {"use1_with": USE_ARMS[1][0], "use1_without": USE_ARMS[1][1], "id": ID,
                          "account": ACCOUNT, "label": LABEL}
    nf_common.write_json(d["down"] / "summary.json", summary)
    nf_common.write_json(d["down"] / "result.json", {**summary, "status": "done"})  # the planner's marker
    lines.append(f"DS_SELECT reads for {args.name}: {summary['ds_select_reads']} (one per arm; the own raw arm")
    lines.append("  is a second read of the same rows, beyond the one read of DESIGN.md 7.8)")
    nf_common.print_screen(f"DOWNSTREAM {args.name}  {summary['utc']}", lines,
                           f"record: {nf_common.rel(d['down'] / 'summary.json')}")
    return nf_common.OK


def _f(v, nd=4):
    return "n/a" if v is None or (isinstance(v, float) and math.isnan(v)) else f"{v:.{nd}f}"


# ---------------------------------------------------------------- the metric engine and the account bootstrap

class Ranked:
    """One score ranked once: descending score, ties by the ascending identity key (its rank). Weighted UDR at
    0.6% (budget floor(W x 3 / 500), the boundary row's copies included only up to the budget) and AP with equal
    scores as one threshold (as scikit-learn), each from cumulative sums."""

    def __init__(self, y, score, key_rank):
        import numpy as np
        self.order = np.lexsort((key_rank, -np.asarray(score, dtype=float)))
        self.y = np.asarray(y, dtype=np.int64)[self.order]
        s = np.asarray(score, dtype=float)[self.order]
        self.ends = np.r_[s[1:] != s[:-1], True]

    def _w(self, w):
        import numpy as np
        return np.ones(len(self.y), dtype=np.int64) if w is None else np.asarray(w, dtype=np.int64)[self.order]

    def udr(self, w=None):
        import numpy as np
        ws = self._w(w)
        total = int(ws.sum())
        budget = total * 3 // 500
        cw = np.cumsum(ws)
        sel = np.minimum(ws, np.maximum(0, budget - (cw - ws)))
        pos = int(np.dot(ws, self.y))
        return float(np.dot(sel, self.y)) / pos if pos else float("nan")

    def ap(self, w=None):
        import numpy as np
        ws = self._w(w)
        tp = np.cumsum(ws * self.y)[self.ends]
        tot = np.cumsum(ws)[self.ends]
        pos = tp[-1] if len(tp) else 0
        if not pos:
            return float("nan")
        keep = tot > 0
        prec = np.where(keep, tp / np.where(keep, tot, 1), 0.0)
        rec = tp / pos
        return float(np.sum(np.diff(np.r_[0.0, rec]) * prec))


def key_ranks(frame, key=ID, account=ACCOUNT):
    """Rank of json.dumps([str(account), str(id)]) among the rows (the reader's tie key, in less memory)."""
    import numpy as np
    keys = np.array([json.dumps([str(a), str(i)]) for a, i in zip(frame[account], frame[key])])
    if len(np.unique(keys)) != len(keys):
        raise Refused("tie keys must identify rows uniquely")
    ranks = np.empty(len(keys), dtype=np.int64)
    ranks[np.argsort(keys, kind="stable")] = np.arange(len(keys))
    return ranks


def account_draws(accounts, draws, seed):
    """Yield one integer weight per row for each draw: whole accounts resampled with replacement, the same
    sequence for every fit (it depends only on the seed and the sorted account list)."""
    import numpy as np
    units, codes = np.unique(np.asarray([str(a) for a in accounts]), return_inverse=True)
    rng = np.random.default_rng(int(seed))
    n = len(units)
    for _ in range(int(draws)):
        counts = np.bincount(rng.integers(0, n, n), minlength=n)
        yield counts[codes]


def lift_stats(frame, arms, draws, seed, interval=90):
    """Point lifts, the difference of lifts (fit minus control) and its paired SE, for UDR and AP.

    ``arms`` maps fit_with, fit_without, control_with, control_without to score columns of ``frame``."""
    import numpy as np
    kr = key_ranks(frame)
    y = frame[LABEL].to_numpy().astype(np.int64)
    ranked = {k: Ranked(y, frame[c].to_numpy(dtype=float), kr) for k, c in arms.items()}
    point = {m: {k: getattr(r, m)() for k, r in ranked.items()} for m in ("udr", "ap")}
    boot = {m: [] for m in ("udr", "ap")}
    boot_lift = {m: {"fit": [], "control": []} for m in ("udr", "ap")}
    for w in account_draws(frame[ACCOUNT], draws, seed):
        for m in ("udr", "ap"):
            v = {k: getattr(r, m)(w) for k, r in ranked.items()}
            lf, lc = v["fit_with"] - v["fit_without"], v["control_with"] - v["control_without"]
            boot[m].append(lf - lc)
            boot_lift[m]["fit"].append(lf)
            boot_lift[m]["control"].append(lc)
    lo_q, hi_q = (100 - interval) / 2, 100 - (100 - interval) / 2
    out = {}
    for m in ("udr", "ap"):
        p = point[m]
        lf, lc = p["fit_with"] - p["fit_without"], p["control_with"] - p["control_without"]
        b = np.asarray(boot[m], dtype=float)
        b = b[np.isfinite(b)]
        se = float(np.std(b, ddof=1)) if len(b) > 1 else float("nan")
        out[m] = {"fit_without": p["fit_without"], "fit_with": p["fit_with"], "lift_fit": lf,
                  "control_without": p["control_without"], "control_with": p["control_with"], "lift_control": lc,
                  "difference": lf - lc, "paired_se": se,
                  "lo": float(np.percentile(b, lo_q)) if len(b) else float("nan"),
                  "hi": float(np.percentile(b, hi_q)) if len(b) else float("nan"),
                  "se_lift_fit": float(np.std(np.asarray(boot_lift[m]["fit"], float), ddof=1)) if draws > 1 else None,
                  "se_lift_control": float(np.std(np.asarray(boot_lift[m]["control"], float), ddof=1))
                  if draws > 1 else None,
                  "fell_by_more_than_one_se": bool(lf - lc < -se) if math.isfinite(se) else False}
    out["rows"], out["frauds"], out["accounts"] = int(len(frame)), int(y.sum()), int(frame[ACCOUNT].nunique())
    return out


# ---------------------------------------------------------------- lift read (8.7)

def _canon(frame):
    """Ids as text after the downstream tool's own lossless canonicalisation (12345678.0 and 12345678 match)."""
    canonical = nf_layout.attr("downstream_xgb", "canonical_ids")
    frame = frame.copy()
    for c in (ID, ACCOUNT):
        frame[c] = canonical(frame[c], c)[0].astype(str)
    return frame


def paired_frame(fit_pred, ctrl_pred, with_col, without_col):
    """Fit and control predictions on the same rows: equal (id, account) sets and labels, else refused."""
    import pandas as pd
    a = _canon(pd.read_parquet(fit_pred))
    b = _canon(pd.read_parquet(ctrl_pred))
    for name, f in (("fit", a), ("control", b)):
        missing = [c for c in (ID, ACCOUNT, LABEL, with_col, without_col) if c not in f]
        if missing:
            raise Refused(f"{name} predictions lack {missing}")
    if len(a) != len(b):
        raise Refused(f"different row sets: fit {len(a)} rows, control {len(b)} rows")
    for name, f in (("fit", a), ("control", b)):
        if f.duplicated([ID, ACCOUNT]).any():
            raise Refused(f"{name} predictions hold duplicate (id, account) rows")
    j = a[[ID, ACCOUNT, LABEL, with_col, without_col]].merge(
        b[[ID, ACCOUNT, LABEL, with_col, without_col]], on=[ID, ACCOUNT], how="outer", suffixes=("_f", "_c"),
        indicator=True, validate="one_to_one")
    if not j["_merge"].eq("both").all():
        raise Refused("different row sets: fit and control DS_SELECT rows differ")
    if not (j[f"{LABEL}_f"].to_numpy() == j[f"{LABEL}_c"].to_numpy()).all():
        raise Refused("labels differ between fit and control on the same rows")
    return pd.DataFrame({ID: j[ID], ACCOUNT: j[ACCOUNT], LABEL: j[f"{LABEL}_f"].astype(int),
                         "fit_with": j[f"{with_col}_f"], "fit_without": j[f"{without_col}_f"],
                         "control_with": j[f"{with_col}_c"], "control_without": j[f"{without_col}_c"]})


def fraud_decision(step, given=None):
    """The step's fraud-rule decision: the command line, else the reader's saved read (three seeds first)."""
    if given:
        return given, "command line"
    for n in (3, 1):
        p = nf_common.c2() / "reads" / f"{step}_{n}seed.json"
        if p.is_file():
            d = nf_common.read_json(p)
            for k in ("decision", "final_decision"):
                if isinstance(d.get(k), str):
                    return d[k], nf_common.rel(p)
    return None, "no read found"


def predictions_path(name, use, arm="base_raw"):
    d = dirs(name)["down"]
    return d / (f"{arm}/fit/predictions.parquet" if use == 1 else "use2/predictions.parquet")


def lift_main(args):
    """The lift is read by the reader (``nf_read.py lift``), the one writer of reads/<step>_lift.json. This command
    builds the reader's run table from the two fits' downstream records (paths and the DS_SELECT predictions'
    sha256 the downstream job recorded) and calls it. Use 2 reads the offset arms into reads/<step>_lift_use2.json."""
    import nf_read
    use = int(args.use)
    with_col, without_col = USE_ARMS[use]
    rows = []
    for role, name in (("candidate", args.fit), ("control", args.control)):
        p = predictions_path(name, use)
        if not p.is_file():
            raise Refused(f"{nf_common.rel(p)} not found: run the downstream check first")
        summ = dirs(name)["down"] / "summary.json"
        recorded = (nf_common.read_json(summ).get("predictions_sha256") or {}) if summ.is_file() else {}
        rows.append({"role": role, "seed": 42, "run": name, "predictions": nf_common.rel(p), "receipt": "",
                     "downstream": nf_common.rel(p),
                     "downstream_sha256": recorded.get("base_raw" if use == 1 else "use2", "")})
    reads = nf_common.c2() / "reads"
    stem = f"{args.step}_lift" if use == 1 else f"{args.step}_lift_use2"
    table = reads / f"{stem}.runs.json"
    nf_common.write_json(table, {"step": args.step, "population": "ds_select", "runs": rows})
    argv = ["lift", "--step", args.step, "--population", "ds_select", "--run-table", str(table),
            "--out", str(reads / f"{stem}.json"), "--arms", f"{without_col},{with_col}"]
    if args.decision:
        d = str(args.decision).strip().upper()
        if "PENDING" not in d:
            argv += ["--fraud-rule", "pass" if d.startswith(("ADOPT", "PASS")) else "fail"]
    return nf_read.main(argv)


# ---------------------------------------------------------------- use 2: offset on 15298's score

def use2_main(args):
    settings = nf_common.settings()
    switch = (settings.get("downstream") or {}).get("use2_15298_offset", "off")
    if str(switch).lower() in ("off", "false", "no", "none", "0") and not args.force:
        print("use 2 waits: model 15298's scores for the DS_TRAIN and DS_SELECT rows have not arrived "
              "(SETTINGS.yaml downstream.use2_15298_offset: off)")
        return nf_common.OK
    import numpy as np
    import pandas as pd
    nf_layout.resolve(["downstream_xgb", "s3"])
    dx = nf_layout.get("downstream_xgb")
    d = dirs(args.name)["down"]
    cfg_path = d / "base_raw" / "config.json"
    if not cfg_path.is_file():
        raise Refused(f"{nf_common.rel(cfg_path)} not found: run the downstream check first")
    out = d / "use2"
    if (out / "predictions.parquet").is_file():
        print(f"skip: {nf_common.rel(out / 'predictions.parquet')} exists")
        return nf_common.OK
    if out.exists():
        raise Refused(f"partial outputs: {nf_common.rel(out)} exists; rename it")
    cfg = nf_common.read_json(cfg_path)
    fs = nf_layout.attr("s3", "thin_read_filesystem")(cfg["s3_cred_path"]) if cfg.get("s3_cred_path") else None
    scores = pd.concat([pd.read_parquet(s) for s in args.scores], ignore_index=True)
    if args.score_col not in scores:
        raise Refused(f"score files lack the column {args.score_col}")
    scores = _canon(scores[[cfg["key"], cfg["account"], args.score_col]].rename(
        columns={args.score_col: "_s15298", cfg["key"]: ID, cfg["account"]: ACCOUNT}))
    if scores.duplicated([ID, ACCOUNT]).any():
        raise Refused("15298 scores hold duplicate (id, account) rows")
    audit = []
    train, _, cols = dx.load_population(cfg["train"], cfg, "train", audit, fs)
    select, _, _ = dx.load_population(cfg["select"], cfg, "select", audit, fs)

    def joined(frame, name):
        f = _canon(frame.rename(columns={cfg["key"]: ID, cfg["account"]: ACCOUNT}))
        j = f.merge(scores, on=[ID, ACCOUNT], how="left", validate="one_to_one")
        miss = int(j["_s15298"].isna().sum())
        if miss:
            raise Refused(f"{name}: {miss} rows have no 15298 score; use 2 needs a score for every row")
        return j.rename(columns={ID: cfg["key"], ACCOUNT: cfg["account"]})

    train, select = joined(train, "DS_TRAIN"), joined(select, "DS_SELECT")
    from sklearn.compose import ColumnTransformer
    from sklearn.impute import SimpleImputer
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import OneHotEncoder, StandardScaler
    tr_raw, num, cat = dx.raw_features(train, cfg["predictors"], cfg["predictor_version"], fs)
    se_raw, _, _ = dx.raw_features(select, cfg["predictors"], cfg["predictor_version"], fs)
    parts = []
    if num:
        parts.append(("numeric", Pipeline([("imputer", SimpleImputer(strategy="median", keep_empty_features=True)),
                                           ("scaler", StandardScaler())]), num))
    if cat:
        parts.append(("categorical", OneHotEncoder(handle_unknown="ignore", sparse_output=False,
                                                   dtype=np.float32), cat))
    transform = ColumnTransformer(parts, remainder="drop", sparse_threshold=0)
    xtr = transform.fit_transform(tr_raw).astype(np.float32)
    xse = transform.transform(se_raw).astype(np.float32)
    scaler = StandardScaler().fit(train[cols])
    etr, ese = scaler.transform(train[cols]).astype(np.float32), scaler.transform(select[cols]).astype(np.float32)

    def margin(s):
        p = np.clip(np.asarray(s, dtype=float), 1e-7, 1 - 1e-7)
        return np.log(p / (1 - p))

    mtr, mse = margin(train["_s15298"]), margin(select["_s15298"])
    y = dx.binary_labels(train[cfg["label"]])
    pred = {}
    for arm, (a, b) in {"offset_raw": (xtr, xse),
                        "offset_raw_embedding": (np.column_stack([xtr, etr]), np.column_stack([xse, ese]))}.items():
        model = dx.new_model(cfg.get("budget", {}), cfg.get("seed", 42))
        model.fit(a, y, base_margin=mtr)
        pred[arm] = model.predict_proba(b, base_margin=mse)[:, 1]
    out.mkdir(parents=True)
    nf_common.append_line(nf_common.c2() / "downstream" / "DS_SELECT_READS.log",
                          f"{nf_common.utc_now()} start {args.name} use2")
    kept = select[[cfg["key"], cfg["account"], cfg["label"]]].copy()
    kept.columns = [ID, ACCOUNT, LABEL]
    kept["s15298"] = select["_s15298"].to_numpy()
    for k, v in pred.items():
        kept[k] = v
    kept.to_parquet(out / "predictions.parquet", index=False)
    nf_common.write_json(out / "report.json", {"rows": int(len(kept)), "fit_population": "DS_TRAIN only",
                                               "offset": "logit of 15298's score, a fixed base margin in both arms",
                                               "scores": [nf_common.rel(s) for s in args.scores],
                                               "scores_sha256": [nf_common.sha256_file(s) for s in args.scores]})
    nf_common.append_line(nf_common.c2() / "downstream" / "DS_SELECT_READS.log",
                          f"{nf_common.utc_now()} end   {args.name} use2")
    print(f"use 2 fitted for {args.name}: {len(kept)} DS_SELECT rows; read it with lift --use 2")
    return nf_common.OK


# ---------------------------------------------------------------- command line

def parser():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    r.add_argument("--name", required=True, help="the kept fit's name, for example nf_a1_seed42")
    r.add_argument("--run-dir", required=True)
    r.add_argument("--config", default=None, help="default: the run's resolved_train_v2.yaml")
    r.add_argument("--checkpoint", default=None, help="default: the run's best.ckpt")
    r.add_argument("--train-base", default=None, help="DS_TRAIN base (default: the run's data.train_base)")
    r.add_argument("--select-base", default=None, help="DS_SELECT base (default: the run's eval.base)")
    r.add_argument("--select-month", default=None, help="DS_SELECT target month, default from SETTINGS")
    r.add_argument("--no-busy-check", action="store_true", help=argparse.SUPPRESS)
    li = sub.add_parser("lift")
    li.add_argument("--step", required=True)
    li.add_argument("--fit", required=True)
    li.add_argument("--control", required=True)
    li.add_argument("--use", choices=["1", "2"], default="1")
    li.add_argument("--decision", default=None, help="the step's fraud-rule decision, if not read from reads/")
    li.add_argument("--draws", type=int, default=None)
    u = sub.add_parser("use2")
    u.add_argument("--name", required=True)
    u.add_argument("--scores", nargs="+", required=True)
    u.add_argument("--score-col", default="score")
    u.add_argument("--force", action="store_true", help="run even while SETTINGS says off")
    return p


def planner_argv(argv):
    """The planner's form, ``--config <cfg> --checkpoint <ckpt> --out C2/downstream/<tag>``, as ``run``. The run
    folder is the checkpoint's folder; the name is the out folder's name, which must lie under C2/downstream."""
    a = argparse.ArgumentParser()
    a.add_argument("--config", required=True)
    a.add_argument("--checkpoint", required=True)
    a.add_argument("--out", required=True)
    a.add_argument("--no-busy-check", action="store_true")
    ns = a.parse_args(argv)
    out = Path(ns.out)
    if out.resolve().parent != (nf_common.c2() / "downstream").resolve():
        raise SystemExit(f"--out must be C2/downstream/<name>, not {ns.out}")
    run_dir = Path(ns.checkpoint).parent
    resolved = run_dir / "resolved_train_v2.yaml"  # the export must match the run as it ran
    cfg = str(resolved) if resolved.is_file() else ns.config
    return ["run", "--name", out.name, "--run-dir", str(run_dir), "--config", cfg, "--checkpoint", ns.checkpoint,
            *(["--no-busy-check"] if ns.no_busy_check else [])]


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0].startswith("--"):
        try:
            argv = planner_argv(argv)
        except SystemExit as e:
            print(f"refused: {e}" if isinstance(e.code, str) else "bad arguments")
            return nf_common.ARGS
    try:
        args = parser().parse_args(argv)
    except SystemExit as e:
        return nf_common.ARGS if e.code else nf_common.OK
    try:
        return {"run": run_main, "lift": lift_main, "use2": use2_main}[args.cmd](args)
    except (Refused, Stop) as e:
        print(nf_common.wrap(f"{'refused' if e.code == 4 else 'STOP'}: {e}"))
        return e.code
    except nf_layout.LayoutError as e:
        return e.code


if __name__ == "__main__":
    sys.exit(main())
