"""Extended preprocessing artifact: version 1's base fields copied byte for byte, the new fields fit by the
unchanged builder (design 4.2 and 4.3).

Steps:
1. Fields to add: every CONFIRMED map row with check result PASS or FLAG, from every group, in the map's order.
   One extended version serves every step; a field in the artifact but not in a predictor list is never read.
2. Scratch fit: C2/artifact/new_fields_only.csv and C2/artifact/preprocessing_scratch.yaml, then the unchanged
   fraud/scripts/build_preprocessing_artifacts.py on version 1's fit files. The data base is the enriched copies
   when any new field is engineered, else the original training base.
3. Merge into the extended version: every file of version 1 except its manifest, byte for byte; every new field's
   file of the scratch version, byte for byte, except a new code field's, which is capped (the reviewers' decision
   D9-Y20, features-package functionality, not baseline behaviour): the values seen in at least 10 distinct
   accounts over the fit files, renumbered from 2 in count order, rarer values to the unknown index 0; a new
   manifest (version 1's predictor_version and fit_files, today's date, the sorted union of features).
   With the optional cyclical calendar step (STEPS.yaml step C) on, a second scratch fit (datetime.encoding
   cyclical, on the original training base) adds the calendar's sin and cos numbers (and is_weekend when asked),
   merged the same way. The base fields stay byte for byte.
4. Month as a switch: C2/artifact/predictors_all_month_in.csv (the base list's bytes, then one line per new field)
   and predictors_all_month_out.csv (the same minus the month line). The config writer's step lists use the same
   rule (nf_data_artifact.month_in_list and month_out_list).
5. C2/artifact/artifact_hashes.json: every file's SHA-256 in version 1, the scratch and the extended versions; the
   payload digest of the base predictors and of each input set, month in and out; every list's SHA-256; the fit
   base of each new field (design review item 36).

Refusals (exit 4): an UNCONFIRMED row; field_status.csv missing or older than the map; a target version of 1 or
one that exists; scratch fit files that differ from version 1's; a new name already in version 1; version 1 fit
files that are not one run of part_<n>.

Every group must be in the map, CONFIRMED, before the first build (POD.md step 14). Each build starts from version 1
and fits every new field again, so a later build's earlier fields are not checked against the files the kept fits
were trained on.

Usage (Copilot adapts paths only):
    CUDA_VISIBLE_DEVICES= $PY fraud/experiments/features/new_fields/nf_build_artifact.py
"""

from __future__ import annotations

import argparse
import datetime as _dt
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path(__file__).resolve().parents[4]
for _p in (str(HERE), str(ROOT / "src"), str(ROOT)):
    if _p in sys.path:
        sys.path.remove(_p)
    sys.path.insert(0, _p)

BUILDER = "fraud/scripts/build_preprocessing_artifacts.py"


def _parser():
    p = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    p.add_argument("--map", default=None, help="field map (default NF/FIELD_MAP.csv)")
    p.add_argument("--status", default=None, help="field_status.csv (default C2/checks/field_status.csv)")
    p.add_argument("--config", default=None, help="chosen config (default SETTINGS.yaml base_config)")
    p.add_argument("--predictors", default=None, help="base predictor list (default SETTINGS.yaml base_predictors)")
    p.add_argument("--preprocessing", default="fraud/configs/preprocessing.yaml",
                   help="the builder's own config, for datetime and batching")
    p.add_argument("--art", default=None, help="artifact base (default the chosen config's artifacts.base)")
    p.add_argument("--v1", default=None, help="version 1's name (default the chosen config's artifacts.version)")
    p.add_argument("--scratch", default=None, help="scratch version (default SETTINGS.yaml scratch_artifact_version)")
    p.add_argument("--target", default=None, help="extended version (default SETTINGS.yaml extended_artifact_version)")
    p.add_argument("--enriched", default=None, help="enriched root (default SETTINGS.yaml enriched_root)")
    p.add_argument("--train-base", default=None, help="original training base (default the chosen config's)")
    p.add_argument("--cred-path", default=None, help="S3 credentials (default the chosen config's)")
    p.add_argument("--calendar-cyclical", default="auto", choices=("auto", "off", "cyclical", "cyclical_weekend"),
                   help="also fit the cyclical calendar's fields (auto: when STEPS.yaml step C is on)")
    p.add_argument("--today", default=None, help=argparse.SUPPRESS)
    return p


def run_builder(config_path: Path) -> int:
    """The unchanged builder, by path, in its own process."""
    cmd = [sys.executable, str(ROOT / BUILDER), "--config", str(config_path)]
    print("running: python " + " ".join([BUILDER, "--config", str(config_path)]))
    return subprocess.run(cmd, cwd=str(ROOT)).returncode


def calendar_choice(given, steps):
    """None, "cyclical" or "cyclical_weekend": the option, else STEPS.yaml's calendar_cyclical step when it is on."""
    if given in ("cyclical", "cyclical_weekend"):
        return given
    if given == "off":
        return None
    import nf_common as C
    for st in steps.get("steps") or []:
        if st.get("kind") == "calendar_cyclical" and C.step_on(st):
            return "cyclical_weekend" if st.get("is_weekend") else "cyclical"
    return None


def main(argv=None) -> int:
    args = _parser().parse_args(argv)
    import nf_layout
    nf_layout.bootstrap()
    import nf_common as C
    import nf_data_artifact as A
    import nf_data_fields as F
    import nf_data_io as io

    lay = nf_layout.resolve(["preprocessing", "export_records", "s3"])
    settings = C.settings()
    steps = C.steps()
    map_path = Path(args.map) if args.map else C.NF / "FIELD_MAP.csv"
    status_path = Path(args.status) if args.status else C.out("checks", "field_status.csv")
    cfg_path = Path(args.config or settings.get("base_config", "fraud/configs/sequential_hier_allpos.yaml"))
    cfg_path = cfg_path if cfg_path.is_absolute() else C.ROOT / cfg_path
    pred_path = Path(args.predictors or settings.get("base_predictors", "fraud/configs/predictors.csv"))
    pred_path = pred_path if pred_path.is_absolute() else C.ROOT / pred_path
    pre_path = Path(args.preprocessing)
    pre_path = pre_path if pre_path.is_absolute() else C.ROOT / pre_path
    # a pod path that is missing is a clear refusal, not a traceback (integration decision 13)
    missing = [f"{C.rel(p)} ({opt})" for p, opt in ((cfg_path, "--config"), (pred_path, "--predictors"),
                                                    (pre_path, "--preprocessing"), (map_path, "--map"))
               if not p.is_file()]
    if missing:
        C.say("refused: a pod path is missing: " + ", ".join(missing) + "; give the pod's path (exit 4)",
              file=sys.stderr)
        return C.REFUSED
    try:
        cfg = C.load_yaml(cfg_path)
        art = args.art or cfg["artifacts"]["base"]
        v1 = str(args.v1 if args.v1 is not None else cfg["artifacts"]["version"])
        scratch = str(args.scratch or settings.get("scratch_artifact_version", "nf_scratch1"))
        target = str(args.target or settings.get("extended_artifact_version", "nf_ext1"))
        cred = args.cred_path or (cfg.get("s3") or {}).get("cred_path")
        train_base = args.train_base or cfg["data"]["train_base"]
        enriched = args.enriched or settings.get("enriched_root")
        map_df = C.read_field_map(map_path)
        status = F.read_status(status_path)
        fields = F.select_fields(map_df, status, map_path, status_path, engineered_only=False)
        if target in ("1", v1) or scratch in ("1", v1) or target == scratch:
            raise A.ArtifactError(f"refused: target {target!r} and scratch {scratch!r} must be new names, "
                                  f"not version 1 {v1!r} (exit 4)")
        store = io.Store(cred)
        v1_root, scr_root, ext_root = (A.version_root(art, v) for v in (v1, scratch, target))
        for root, what in ((ext_root, "target"), (scr_root, "scratch")):
            if store.listdir(root):
                raise A.ArtifactError(f"refused: the {what} version {root} already exists; choose a new name (exit 4)")
        man1 = A.read_manifest(store, v1_root)
        start, end = A.fit_range(man1["fit_files"])
        if not fields:
            raise A.ArtifactError("refused: no CONFIRMED field passed the checks; nothing to add (exit 4)")
        clash = [f.name for f in fields if f.name in man1["features"]]
        if clash:
            raise A.ArtifactError(f"refused: already in version 1: {', '.join(clash)} (exit 4)")
    except (F.Refused, A.ArtifactError) as e:
        return e.code

    engineered = any(f.kind == "engineered" for f in fields)
    fit_base = io.join(enriched, Path(str(train_base).rstrip("/")).name) if engineered else train_base
    if engineered:
        # the fit reads the copies: each fit file's identity proof must have passed under this map
        map_sha = C.sha256_file(map_path)
        for n in range(start, end + 1):
            proofs = [C.read_json(p) for p in C.out("enriched", "identity").glob(f"*/part_{n}.json")]
            ok = [p for p in proofs if p.get("result") == "PASS" and p.get("map_sha256") == map_sha
                  and p.get("status_sha256") == C.sha256_file(status_path)
                  and str(p.get("copy", "")).startswith(str(fit_base).rstrip("/"))]
            if not ok:
                C.say(f"refused: no passed identity proof under this map for the enriched copy part_{n} in "
                      f"{fit_base}; run nf_build_enriched.py first (exit 4)", file=sys.stderr)
                return C.REFUSED
    base_csv = pred_path.read_bytes()
    base_names = A.list_features(base_csv)
    version = A.base_version(base_csv)
    new_csv = C.out("artifact", "new_fields_only.csv")
    header = base_csv.splitlines(keepends=True)[0]
    new_csv.write_bytes(header + A.new_rows_csv([(f.name, f.model_type, "new field") for f in fields],
                                                version, b"\r\n" if b"\r\n" in header else b"\n"))
    pre = C.load_yaml(pre_path)
    scratch_cfg = {
        "predictors": {"csv_path": str(new_csv), "version": None},
        "data": {"base": fit_base, "file_start": start, "file_end": end,
                 "order_col": (pre.get("data") or {}).get("order_col", "transaction_dttm")},
        "datetime": pre.get("datetime"),
        "build": {"features_per_batch": int((pre.get("build") or {}).get("features_per_batch", 5)),
                  "artifact_version": scratch, "output_base": art},
        "s3": {"cred_path": cred},
    }
    import yaml
    scfg = C.out("artifact", "preprocessing_scratch.yaml")
    scfg.write_text(yaml.safe_dump(scratch_cfg, sort_keys=False))
    rc = run_builder(scfg)
    if rc != 0:
        C.say(f"STOP: the builder exited {rc}; nothing was merged (exit 3)", file=sys.stderr)
        return C.STOP
    man_s = A.read_manifest(store, scr_root)
    if list(man_s["fit_files"]) != list(man1["fit_files"]):
        C.say(f"refused: scratch fit files {man_s['fit_files']} differ from version 1's {man1['fit_files']} (exit 4)",
              file=sys.stderr)
        return C.REFUSED
    missing = [f.name for f in fields if f.name not in man_s["features"]]
    if missing:
        C.say(f"STOP: the scratch version lacks {', '.join(missing)} (exit 3)", file=sys.stderr)
        return C.STOP

    # the optional cyclical calendar step: its sin and cos numbers (and is_weekend) from a second scratch fit
    cal_names = []
    cal = calendar_choice(args.calendar_cyclical, steps)
    if cal:
        import nf_make_configs as MC
        dt_fields = [f for f in ((pre.get("datetime") or {}).get("fields") or MC.CALENDAR_FIELDS)
                     if f in MC.CALENDAR_FIELDS]
        cal_rows = MC.calendar_rows(dt_fields, cal == "cyclical_weekend")
        cal_names = [n for n, _ in cal_rows]
        clash = [n for n in cal_names if n in man1["features"] or n in {f.name for f in fields}]
        if clash:
            C.say(f"refused: the cyclical calendar's names are taken: {', '.join(clash)} (exit 4)", file=sys.stderr)
            return C.REFUSED
        nl = b"\r\n" if b"\r\n" in header else b"\n"
        cal_csv = C.out("artifact", "calendar_cyclical_only.csv")
        cal_csv.write_bytes(header + b"".join(f"{n},{t},derived:transaction_dttm,{version},cyclical calendar".encode()
                                              + nl for n, t in cal_rows))
        cal_scratch = f"{scratch}_calendar"
        if store.listdir(A.version_root(art, cal_scratch)):
            C.say(f"refused: the calendar scratch version {cal_scratch} already exists (exit 4)", file=sys.stderr)
            return C.REFUSED
        cal_cfg = dict(scratch_cfg, predictors={"csv_path": str(cal_csv), "version": None},
                       data=dict(scratch_cfg["data"], base=train_base),
                       datetime=dict(pre.get("datetime") or {}, encoding="cyclical",
                                     is_weekend=cal == "cyclical_weekend"),
                       build=dict(scratch_cfg["build"], artifact_version=cal_scratch))
        ccfg = C.out("artifact", "preprocessing_calendar_scratch.yaml")
        ccfg.write_text(yaml.safe_dump(cal_cfg, sort_keys=False))
        rc = run_builder(ccfg)
        if rc != 0:
            C.say(f"STOP: the builder exited {rc} on the cyclical calendar; nothing was merged (exit 3)",
                  file=sys.stderr)
            return C.STOP
        man_c = A.read_manifest(store, A.version_root(art, cal_scratch))
        if list(man_c["fit_files"]) != list(man1["fit_files"]) or set(cal_names) - set(man_c["features"]):
            C.say("refused: the calendar scratch fit used other files or lacks a field (exit 4)", file=sys.stderr)
            return C.REFUSED

    # the cap of the new code fields (the reviewers' decision D9-Y20)
    capped, capped_bytes = {}, {}
    cats = [f.name for f in fields if f.model_type == "categorical"]
    if cats:
        acct = (cfg.get("data") or {}).get("account_col") or "Nmap_account_reference_xid"
        counts = A.accounts_per_value(store, fit_base, start, end, acct, cats)
        for n in cats:
            raw = store.read_bytes(io.join(scr_root, f"feature__{n}.json"))
            entry, info = A.cap_vocab(json.loads(raw), counts.get(n, {}))
            data = A.entry_bytes(entry)
            capped_bytes[n] = data
            capped[n] = dict(info, as_fit_sha256=io.sha256(raw), capped_sha256=io.sha256(data))

    # merge
    h1 = A.file_hashes(store, v1_root)
    for name in sorted(h1):
        if name != A.MANIFEST:
            store.copy(io.join(v1_root, name), io.join(ext_root, name))
    for f in fields:
        if f.name in capped_bytes:
            store.write_bytes(io.join(ext_root, f"feature__{f.name}.json"), capped_bytes[f.name])
        else:
            store.copy(io.join(scr_root, f"feature__{f.name}.json"), io.join(ext_root, f"feature__{f.name}.json"))
    for n in cal_names:
        store.copy(io.join(A.version_root(art, f"{scratch}_calendar"), f"feature__{n}.json"),
                   io.join(ext_root, f"feature__{n}.json"))
    manifest = {"artifact_version": target, "predictor_version": man1.get("predictor_version"),
                "created": args.today or _dt.date.today().isoformat(), "fit_files": list(man1["fit_files"]),
                "features": sorted(set(man1["features"]) | {f.name for f in fields} | set(cal_names))}
    store.write_bytes(io.join(ext_root, A.MANIFEST), A.manifest_bytes(manifest))

    # month as a switch: two lists over one artifact
    m_in = A.month_in_list(base_csv, [(f.name, f.model_type, "new field") for f in fields])
    m_out = A.month_out_list(m_in)
    p_in, p_out = C.out("artifact", "predictors_all_month_in.csv"), C.out("artifact", "predictors_all_month_out.csv")
    p_in.write_bytes(m_in)
    p_out.write_bytes(m_out)

    # hashes and digests
    pre_mod = nf_layout.get("preprocessing")
    ext = pre_mod.PreprocessingArtifacts.load(ext_root, filesystem=store.fs(ext_root))
    groups_of = {f.name: f.group for f in fields}
    sets = A.input_sets(steps, groups_of, [f.name for f in fields])
    digests = {"base": A.payload_digest(ext, base_names),
               "base_month_out": A.payload_digest(ext, [n for n in base_names if n != A.MONTH])}
    for k, names in sets.items():
        digests[f"{k}_month_in"] = A.payload_digest(ext, base_names + names)
        digests[f"{k}_month_out"] = A.payload_digest(ext, [n for n in base_names if n != A.MONTH] + names)
    record = {
        "layout": lay.layout, "art": art, "version1": v1, "scratch": scratch, "extended": target,
        "files": {"version1": h1, "scratch": A.file_hashes(store, scr_root), "extended": A.file_hashes(store, ext_root)},
        "base_predictors": base_names, "new_fields": [f.name for f in fields],
        "fit": {f.name: {"base": fit_base, "fit_files": man1["fit_files"],
                         "from_enriched_copies": bool(engineered)} for f in fields},
        "payload_sha256": digests, "input_sets": sets,
        "calendar_cyclical": {"choice": cal or "off", "fields": cal_names},
        "capped": capped,
        "lists": {"predictors_all_month_in.csv": C.sha256_file(p_in),
                  "predictors_all_month_out.csv": C.sha256_file(p_out),
                  "new_fields_only.csv": C.sha256_file(new_csv), "base": C.sha256_file(pred_path)},
        "map_sha256": C.sha256_file(map_path), "status_sha256": C.sha256_file(status_path), "utc": C.utc_now(),
    }
    C.write_json(C.out("artifact", "artifact_hashes.json"), record)
    C.print_screen(f"EXTENDED ARTIFACT  built {target}", [
        f"layout: {lay.layout}",
        f"version 1: {v1} ({len(h1)} files, {len(man1['features'])} features); copied byte for byte",
        f"new fields: {len(fields)} ({sum(f.kind == 'engineered' for f in fields)} engineered), "
        f"fit on {'enriched copies' if engineered else 'original files'} part_{start}..part_{end}",
        f"base payload digest {digests['base'][:16]}",
        f"code fields capped at {A.CAP_MIN_ACCOUNTS} accounts: {len(capped)}; values kept "
        f"{sum(c['kept'] for c in capped.values())} of {sum(c['as_fit'] for c in capped.values())}",
        "month switch: predictors_all_month_in.csv and _month_out.csv (one line apart)",
        "next: nf_check_artifact.py (the queue stops unless every line passes)",
    ], f"hashes: {C.rel(C.out('artifact', 'artifact_hashes.json'))}")
    return C.OK


if __name__ == "__main__":
    sys.exit(main())
