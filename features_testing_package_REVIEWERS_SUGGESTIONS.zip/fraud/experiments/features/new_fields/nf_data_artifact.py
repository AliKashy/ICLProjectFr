"""Helpers for the extended artifact (design 4.2 to 4.5): predictor lists, the month switch, per-file hashes,
payload digests and checkpoint digests. Importing this module does no work.

Month is a switch: two predictor lists over one artifact. The month-out list is the month-in list minus exactly
the month line; nothing else changes. The month-in list is the base list's bytes (all 23 lines, in order) followed
by one line per new field, in the map's order.
"""

from __future__ import annotations

import csv
import io as _io
import json
import sys
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

import nf_data_io as dio  # noqa: E402

MONTH = "month"
MANIFEST = "manifest.json"
# The cap of a new code field (the reviewers' decision D9-Y20, features-package functionality, not baseline
# behaviour): a value enters the vocabulary only when at least this many distinct accounts carry it over the fit
# files; rarer values encode to the unknown index 0.
CAP_MIN_ACCOUNTS = 10
FIRST_CATEGORY_INDEX = 2


class ArtifactError(SystemExit):
    """Exit with a code (3 stop, 4 refused) and the reason printed."""

    def __init__(self, message: str, code: int = 4):
        import nf_common
        print(nf_common.wrap(message), file=sys.stderr)   # at most 90 characters a line
        super().__init__(code)
        self.message = message


# ------------------------------------------------------------------------------------------- #
# Predictor lists
# ------------------------------------------------------------------------------------------- #
def _lines(data: bytes) -> List[bytes]:
    """Lines with their own line endings kept."""
    return data.splitlines(keepends=True)


def _newline(data: bytes) -> bytes:
    return b"\r\n" if b"\r\n" in data else b"\n"


def base_version(base_csv: bytes) -> str:
    """The base rows' shared ``version`` value (so the as-run ``predictors.version`` keeps every row)."""
    rows = list(csv.DictReader(_io.StringIO(base_csv.decode("utf-8"))))
    vals = {r.get("version", "") for r in rows}
    if len(vals) != 1:
        raise ArtifactError(f"refused: the base list's rows carry several versions {sorted(vals)}; "
                            "the new rows cannot match them all (exit 4)")
    return vals.pop()


def new_rows_csv(fields: Sequence[Tuple[str, str, str]], version: str, newline: bytes = b"\n") -> bytes:
    """``feature,type,source,version,description`` lines for new fields (source raw: the copy holds the column)."""
    buf = _io.StringIO()
    w = csv.writer(buf, lineterminator=newline.decode())
    for name, mtype, description in fields:
        w.writerow([name, mtype, "raw", version, description])
    return buf.getvalue().encode("utf-8")


def month_in_list(base_csv: bytes, fields: Sequence[Tuple[str, str, str]]) -> bytes:
    """The base list byte for byte, then one line per new field."""
    body = base_csv if base_csv.endswith((b"\n", b"\r")) else base_csv + _newline(base_csv)
    return body + new_rows_csv(fields, base_version(base_csv), _newline(base_csv))


def month_out_list(month_in: bytes) -> bytes:
    """The month-in list minus exactly the month line."""
    lines = _lines(month_in)
    keep, dropped = [], 0
    for i, ln in enumerate(lines):
        first = ln.split(b",", 1)[0].strip().strip(b'"')
        if i > 0 and first == MONTH.encode():
            dropped += 1
            continue
        keep.append(ln)
    if dropped != 1:
        raise ArtifactError(f"refused: the list holds {dropped} month lines, not 1 (exit 4)")
    return b"".join(keep)


def month_out_ok(month_in: bytes, month_out: bytes) -> bool:
    """True when ``month_out`` equals ``month_in`` minus exactly one line, the month line."""
    a, b = _lines(month_in), _lines(month_out)
    if len(a) != len(b) + 1:
        return False
    try:
        return month_out_list(month_in) == month_out
    except ArtifactError:
        return False


def list_features(data: bytes) -> List[str]:
    return [r["feature"] for r in csv.DictReader(_io.StringIO(data.decode("utf-8")))]


# ------------------------------------------------------------------------------------------- #
# Artifact folders
# ------------------------------------------------------------------------------------------- #
def version_root(art_base: str, version) -> str:
    return dio.join(art_base, str(version))


def file_hashes(store: dio.Store, root: str) -> Dict[str, str]:
    """{file name: SHA-256} of every file directly in an artifact folder."""
    out = {}
    for p in store.listdir(root):
        name = p.replace("\\", "/").rstrip("/").split("/")[-1]
        rel = p[len(root.rstrip("/")) + 1:].replace("\\", "/")
        if "/" in rel:  # nested files are not part of an artifact version
            continue
        out[name] = dio.sha256(store.read_bytes(p))
    return out


def read_manifest(store: dio.Store, root: str) -> Dict:
    path = dio.join(root, MANIFEST)
    if not store.exists(path):
        raise ArtifactError(f"refused: no {MANIFEST} under {root} (exit 4)")
    return json.loads(store.read_bytes(path).decode("utf-8"))


def fit_range(fit_files: Sequence[str]) -> Tuple[int, int]:
    """(start, end) when ``fit_files`` is one unbroken run of part_<n>.parquet files, else refused."""
    nums = []
    for f in fit_files:
        name = str(f).split("/")[-1]
        if not (name.startswith("part_") and name.endswith(".parquet")):
            raise ArtifactError(f"refused: version 1 fit file {f!r} is not part_<n>.parquet (exit 4)")
        nums.append(int(name[5:-8]))
    if not nums or nums != list(range(nums[0], nums[0] + len(nums))):
        raise ArtifactError(f"refused: version 1 fit files {list(fit_files)} are not one run of part_<n> (exit 4)")
    return nums[0], nums[-1]


def manifest_bytes(manifest: Dict) -> bytes:
    """Written as the unchanged ``PreprocessingArtifacts.save`` writes it (json.dump, indent 2)."""
    return json.dumps(manifest, indent=2).encode("utf-8")


# ------------------------------------------------------------------------------------------- #
# Digests
# ------------------------------------------------------------------------------------------- #
def payload_digest(artifacts, names: Sequence[str]) -> str:
    """The input contract's ``artifacts_sha256`` for these features (export_records.artifact_payload_sha256)."""
    import nf_layout
    fn = nf_layout.attr("export_records", "artifact_payload_sha256")
    return fn(artifacts, list(names))


def checkpoint_digest(path) -> Optional[str]:
    """``artifacts_sha256`` stored in a checkpoint's sequence contract, read on CPU; None if absent."""
    import torch
    ck = torch.load(str(path), map_location="cpu", weights_only=False)
    for getter in (lambda c: c["sequence_contract"]["input_contract"]["artifacts_sha256"],
                   lambda c: c["hyper_parameters"]["input_contract"]["artifacts_sha256"]):
        try:
            return str(getter(ck))
        except (KeyError, TypeError):
            continue
    return None


def input_sets(steps: Dict, groups_of: Dict[str, str], order: Sequence[str]) -> Dict[str, List[str]]:
    """New-field names per input set: each step's cumulative additions (A1, A1+A2, ...), every step on or off,
    and ``all`` (every new field). Step kinds other than additions (prune, month_out) add nothing."""
    sets: Dict[str, List[str]] = {}
    acc: List[str] = []
    for st in (steps or {}).get("steps", []):
        adds = st.get("adds")
        if not adds:
            continue
        mine = [n for n in order if groups_of.get(n) in adds]
        acc = acc + [n for n in mine if n not in acc]
        sets[str(st.get("name"))] = list(acc)          # on the previous steps' additions
        sets[f"{st.get('name')}_alone"] = list(mine)   # on the base inputs only (a previous group dropped)
    sets["all"] = list(order)
    return sets


# ------------------------------------------------------------------------------------------- #
# The cap of new code fields (the reviewers' decision D9-Y20)
# ------------------------------------------------------------------------------------------- #
def accounts_per_value(store: dio.Store, base: str, start: int, end: int, account_col: str,
                       names: Sequence[str]) -> Dict[str, Dict[str, List[int]]]:
    """{field: {value: [distinct accounts, rows]}} over the fit files part_<start>..part_<end>, values as the
    builder reads them (text). The fit files hold whole accounts, so the per-file account counts add up."""
    import pandas as pd
    out: Dict[str, Dict[str, List[int]]] = {n: {} for n in names}
    for n in range(int(start), int(end) + 1):
        path = dio.join(base, f"part_{n}.parquet")
        have = set(store.schema(path).names)
        cols = [account_col] + [c for c in names if c in have]
        df = store.read_table(path, cols).to_pandas()
        for c in cols[1:]:
            sub = df[[account_col, c]].dropna()
            if sub.empty:
                continue
            g = sub.assign(v=sub[c].astype(str)).groupby("v")[account_col].agg(["nunique", "size"])
            acc = out[c]
            for v, (a, r) in g.iterrows():
                cur = acc.setdefault(str(v), [0, 0])
                cur[0] += int(a)
                cur[1] += int(r)
    return out


def cap_vocab(entry: Dict, counts: Dict[str, List[int]], min_accounts: Optional[int] = None):
    """A fitted code field's entry with its vocabulary capped: the values seen in at least ``min_accounts``
    distinct accounts, renumbered contiguously from 2 in the builder's count order; n_categories and cardinality
    follow. Returns (entry, info) with the as-fit and kept counts and the rare rows' share of the fit rows."""
    min_accounts = CAP_MIN_ACCOUNTS if min_accounts is None else min_accounts
    vocab = entry["vocab"]
    order = sorted(vocab, key=vocab.get)
    kept = [v for v in order if counts.get(v, [0, 0])[0] >= int(min_accounts)]
    new = dict(entry)
    new["vocab"] = {v: i for i, v in enumerate(kept, start=FIRST_CATEGORY_INDEX)}
    new["n_categories"] = len(kept)
    new["cardinality"] = len(kept) + FIRST_CATEGORY_INDEX
    rows = sum(r for _, r in counts.values())
    rare = sum(r for v, (_, r) in counts.items() if v not in new["vocab"])
    info = {"min_accounts": int(min_accounts), "as_fit": len(vocab), "kept": len(kept),
            "rare_rows": int(rare), "rows": int(rows), "rare_row_share": (rare / rows) if rows else 0.0}
    return new, info


def entry_bytes(entry: Dict) -> bytes:
    """A feature file as the unchanged builder writes it (json.dump with indent 2)."""
    return json.dumps(entry, indent=2).encode()
