"""Width timing for one step's input width (DESIGN.md section 5, component 15).

It runs a few hundred timed training updates and some validation batches at the step's real input width, through
the trainer's own ``main``. It records peak GPU memory, the stage 1 row limit, and the micro-batch x accumulation
that keeps about 4,100 targets per update. Nothing hashed is edited: the timer and the step limits are added in
memory, from outside, by stage 1's method (stage 1 design sections 9 and 11, with its review corrections):
- the trainer's module-global ``build_trainer`` is replaced for the run and put back afterwards;
- inside it, ``pl.Trainer`` gets ``limit_train_batches = updates x accumulation``, ``limit_val_batches`` and
  ``num_sanity_val_steps = 0`` (the trainer passes none of these keys);
- the timer callback holds no state, draws no random numbers, never logs and never changes a batch;
- ``torch.cuda.synchronize()`` runs only when CUDA is available, before each clock read;
- peak memory is reset per phase (training, validation); every validation hook returns at once during a sanity
  check; the epoch-0 mark is the end of the sanity check, or the start of training when no sanity check runs;
  the run's overall peak is the largest phase peak.

Commands (run from the project root, by path):
  width   --config <cfg>                 tokens per transaction and the stage 1 row limit (CPU, no data read)
  real    --config <cfg> --run <name>    the timed run; one process per attempt; the memory rule
  chunks  --config <cfg> --batch B --accumulate A    the same chunks reach each update at B x A and at B/2 x 2A
  encode  --config <cfg>                 time the categorical encoding of one training and one EPOCH_VAL file
  score   --config <cfg> --checkpoint <ckpt> --run <name>    a fitted checkpoint through the scorer's own float32
                                         path: single windows one at a time and the scoring batch, median and 99th
                                         percentile, peak allocated and reserved memory, the fit's input count;
                                         figures only, no threshold (the reviewers' decisions D4b and D9-Y22)

``real`` writes ``C2/timing/<run>.json`` and ``C2/timing/<run>.txt`` (one screen). The memory rule: if the
training peak is above 85% of device memory, or training runs out of memory, the batch (chunks) halves and the
accumulation doubles, down to 8 chunks; if validation runs out of memory, the eval batch halves, down to 128.
Each attempt is a new process, so memory left by a failed attempt never distorts the next. When the rule fires,
the control must be refit at the same micro-batch, unless the owner accepts the difference as a declared confound
(SETTINGS.yaml ``microbatch_confound_accepted_by``). ``num_workers`` is never changed.

Exit codes: 0 done; 1 crash; 2 bad arguments; 3 STOP (no plan fits, row limit, host memory); 4 refused (busy
GPU, an output exists but is incomplete).
"""
import argparse
import functools
import json
import math
import os
import re
import resource
import shutil
import statistics
import subprocess
import sys
import threading
import time
from pathlib import Path
from unittest import mock

HERE = Path(__file__).resolve().parent
ROOT = Path(__file__).resolve().parents[4]
for _p in (str(HERE), str(ROOT / "src"), str(ROOT)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import nf_common  # noqa: E402
import nf_layout  # noqa: E402

UPDATES_PER_EPOCH = 2103       # stage 1 rule S7: every epoch of the chosen run has 2,103 updates
TARGETS_PER_UPDATE = 4100      # about 8,622,629 / 2,103
TARGET_BAND = (4059, 4141)     # stage 1 rule S7 band for the mean targets per update
MEM_SHARE = 0.85               # the memory rule (DESIGN.md section 5)
MIN_CHUNKS = 8                 # stage 1 width timing: the micro-batch search stops at 8 chunks
MIN_EVAL = 128                 # the eval batch search stops at 128 windows
OOM_EXIT = 7                   # an attempt's exit code when it ran out of memory
GIB = float(1 << 30)
# Test hook only: "train>=N" or "validation>=N" makes an attempt raise an out-of-memory error in that phase when
# its batch (training) or eval batch (validation) is at least N. Never set on the pod.
SIMULATE_OOM_ENV = "NF_TIMING_SIMULATE_OOM"


# ---------------------------------------------------------------- small helpers

def _cuda():
    try:
        import torch
        return bool(torch.cuda.is_available())
    except ImportError:
        return False


def _median(values):
    return float(statistics.median(values)) if values else None


def _mean(values):
    return float(sum(values) / len(values)) if values else None


def _rss_gib(pid=None):
    """Resident memory of a process in GiB (Linux /proc), or None."""
    try:
        with open(f"/proc/{pid or 'self'}/status", encoding="utf-8") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1]) * 1024 / GIB
    except (OSError, ValueError, IndexError):
        return None
    return None


def _children(pid):
    """Direct child pids of a process (the data loader workers), from /proc."""
    kids = []
    try:
        names = os.listdir("/proc")
    except OSError:
        return kids
    for name in names:
        if not name.isdigit():
            continue
        try:
            with open(f"/proc/{name}/stat", encoding="utf-8") as f:
                stat = f.read()
            ppid = int(stat.rsplit(")", 1)[1].split()[1])
        except (OSError, ValueError, IndexError):
            continue
        if ppid == pid:
            kids.append(int(name))
    return kids


def host_memory_gib():
    """Total host memory in GiB (/proc/meminfo), or None."""
    try:
        with open("/proc/meminfo", encoding="utf-8") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    return int(line.split()[1]) * 1024 / GIB
    except (OSError, ValueError, IndexError):
        return None
    return None


def nvidia(query):
    """Lines of an nvidia-smi --query-gpu call, or None when nvidia-smi is missing. The GPU name and memory come
    from nvidia-smi, never from torch.cuda (stage 1 review item 17)."""
    if shutil.which("nvidia-smi") is None:
        return None
    try:
        r = subprocess.run(["nvidia-smi", f"--query-gpu={query}", "--format=csv,noheader,nounits"],
                           capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.SubprocessError):
        return None
    if r.returncode != 0:
        return None
    return [ln.strip() for ln in r.stdout.splitlines() if ln.strip()]


def load_cfg(config, overrides=()):
    from omegaconf import OmegaConf
    cfg = OmegaConf.load(str(config))
    if overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(list(overrides)))
    return cfg


# ---------------------------------------------------------------- width and the row limit

def token_width(cfg):
    """Tokens per transaction from the step's predictor list (DESIGN.md section 5): each continuous predictor
    gives a value token and, with missing flags on, a missing-flag token; each categorical predictor (calendar
    fields included) one token; the time gap one continuous token. Plus one CLS token per transaction."""
    fs = None
    if cfg.s3.get("cred_path"):
        fs = nf_layout.attr("s3", "make_s3_filesystem")(cfg.s3.cred_path)
    feats = nf_layout.attr("feature_list", "load_feature_list")(cfg.predictors.csv_path,
                                                                version=cfg.predictors.version, filesystem=fs)
    c, k = len(feats.continuous), len(feats.categorical)
    flags = c if bool(cfg.preprocess.get("add_missing_flag", True)) else 0
    gap = 1 if bool(cfg.sequence.get("time_delta", True)) else 0
    continuous_dim, categorical = c + gap, k + flags
    tokens = continuous_dim + categorical
    return {"fields": c + k, "continuous_predictors": c, "categorical_predictors": k, "missing_flags": flags,
            "time_gap": gap, "continuous_dim": continuous_dim, "categorical_inputs": categorical,
            "tokens": tokens, "tokens_with_cls": tokens + 1,
            "label": (f"{c + k} fields -> {tokens} tokens ({continuous_dim} continuous incl. the time gap + "
                      f"{categorical} categorical incl. datetime and {flags} missing flags), {tokens + 1} with CLS")}


def row_limit(cfg):
    """The stage 1 row limit (65,535 rows per launch; batch x widest chunk, eval batch x window width). It counts
    rows only, so width never changes it; halving the batch only lowers it. The trainer's own check decides."""
    trainer = nf_layout.get("trainer")
    limit = int(nf_layout.attr("trainer", "MAX_STAGE1_ROWS"))
    eval_batch = int(nf_layout.attr("trainer", "eval_batch_size")(cfg))
    batch = int(cfg.training.batch_size)
    history = int(cfg.sequence.history_len)
    cap = cfg.sequence.get("max_window_rows", None)
    widest = cfg.sequence.get("max_chunk_rows", None)
    window = max(int(cap), history + 1) if cap is not None else history + 1
    if bool(cfg.sequence.get("train_target_ending", False)):
        train_rows, train_label = batch * window, f"batch {batch} x window width {window}"
    elif widest is not None:
        train_rows, train_label = batch * int(widest), f"batch {batch} x widest chunk {int(widest)}"
    else:
        train_rows, train_label = None, "no max_chunk_rows (not a chunk model)"
    out = {"limit": limit, "train_rows": train_rows, "train": train_label, "eval_rows": eval_batch * window,
           "eval": f"eval batch {eval_batch} x window width {window}", "batch": batch, "eval_batch": eval_batch,
           "accumulate_grad_batches": int(cfg.training.get("accumulate_grad_batches", 1))}
    try:
        trainer.check_batch_plan(cfg)
        out["ok"], out["reason"] = True, ""
    except ValueError as e:
        out["ok"], out["reason"] = False, str(e)
    return out


# ---------------------------------------------------------------- the timer callback

def _callback_base():
    try:
        from pytorch_lightning.callbacks import Callback
    except ImportError:  # the lightning package name, if the pod has only that one
        from lightning.pytorch.callbacks import Callback
    return Callback


def trainer_callback_base():
    """The Callback class of the Lightning package the trainer module imported, else pytorch_lightning's."""
    try:
        tm = nf_layout.get("trainer")
        pl = getattr(tm, "pl", None)
        if pl is not None and hasattr(pl, "callbacks") and hasattr(pl.callbacks, "Callback"):
            return pl.callbacks.Callback
    except SystemExit:
        pass
    return _callback_base()


def make_timer(warmup=50, chunk_route=True, base=None):
    """A WidthTimer instance. Built here so importing this file does not import Lightning. ``base`` is the
    Callback class of the Lightning package the trainer itself uses (a mixed-package callback is refused)."""
    Callback = base or trainer_callback_base()

    class WidthTimer(Callback):
        """Clock marks around Lightning 2.x hooks. It defines no state_dict, so checkpoints keep exactly the
        trainer's callback keys, and a plain trainer can read them."""

        def __init__(self):
            self.warmup = int(warmup)
            self.chunk_route = bool(chunk_route)
            self.cuda = _cuda()
            self.phase = "setup"
            self.updates = []
            self.unclosed_micro = 0
            self.val_batch_s = []
            self.val_total_s = []
            self.peaks = {}
            self.rss = {"main_gib": 0.0, "workers_gib": 0.0, "total_gib": 0.0}
            self.route_other = 0
            self.chunks, self.widths = [], []
            self.marks = {}
            self.sanity_ran = False
            self._epoch_mark = None
            self._from = None
            self._last_end = None
            self._t0 = None
            self._vb = None
            self._vstart = None
            self._closing = False
            self._acc = {"targets": 0, "compute_s": 0.0, "wait_s": 0.0, "micro": 0}
            self._simulate = os.environ.get(SIMULATE_OOM_ENV, "")
            self._batch = None
            self._eval_batch = None

        # -- helpers
        def _now(self):
            if self.cuda:
                import torch
                torch.cuda.synchronize()
            return time.perf_counter()

        def _peak(self):
            if not self.cuda:
                return None
            import torch
            torch.cuda.synchronize()
            return {"alloc_gib": torch.cuda.max_memory_allocated() / GIB,
                    "reserved_gib": torch.cuda.max_memory_reserved() / GIB}

        def _reset(self):
            if self.cuda:
                import torch
                torch.cuda.synchronize()
                torch.cuda.reset_peak_memory_stats()

        def _sample_rss(self):
            main = _rss_gib() or 0.0
            workers = sum((_rss_gib(p) or 0.0) for p in _children(os.getpid()))
            self.rss["main_gib"] = max(self.rss["main_gib"], main)
            self.rss["workers_gib"] = max(self.rss["workers_gib"], workers)
            self.rss["total_gib"] = max(self.rss["total_gib"], main + workers)

        def _maybe_oom(self, phase):
            m = re.fullmatch(r"(train|validation)>=(\d+)", self._simulate.strip())
            if not m or m.group(1) != phase:
                return
            size = self._batch if phase == "train" else self._eval_batch
            if size is not None and size >= int(m.group(2)):
                import torch
                raise torch.cuda.OutOfMemoryError(f"CUDA out of memory (simulated by {SIMULATE_OOM_ENV})")

        # -- Lightning hooks
        def on_fit_start(self, trainer, pl_module):
            self.marks["fit_start"] = self._now()

        def on_sanity_check_start(self, trainer, pl_module):
            self.marks["sanity_start"] = self._now()
            self._reset()

        def on_sanity_check_end(self, trainer, pl_module):
            self._epoch_mark = self._now()
            self.marks["sanity_end"] = self._epoch_mark
            self.sanity_ran = True
            self.peaks["sanity"] = self._peak()

        def on_train_start(self, trainer, pl_module):
            t = self._now()
            self.marks["train_start"] = t
            if self._epoch_mark is None:  # stage 1 review item 9: no sanity check ran
                self._epoch_mark = t

        def on_train_epoch_start(self, trainer, pl_module):
            t = self._now()
            self._reset()
            self.phase = "train"
            self._from = self._epoch_mark if trainer.current_epoch == 0 and self._epoch_mark is not None else t
            self._last_end = None
            self._sample_rss()

        def on_train_batch_start(self, trainer, pl_module, batch, batch_idx):
            t = self._now()
            self._acc["wait_s"] += t - (self._last_end if self._last_end is not None else self._from)
            mask = batch["mask"]
            self._batch = int(mask.shape[0])
            self._maybe_oom("train")
            if "target_seq" in batch:  # chunk batches: every real row; target-ending windows: one per window
                self._acc["targets"] += int((batch["target_seq"] != -100).sum())
            else:
                self._acc["targets"] += int(mask.shape[0])
            self.chunks.append(int(mask.shape[0]))
            self.widths.append(int(mask.shape[1]) if mask.dim() > 1 else 1)
            if self.chunk_route and "target_seq" in batch:
                import torch
                if not torch.equal(batch["target_seq"] != -100, mask):
                    self.route_other += 1
            self._t0 = self._now()

        def on_before_optimizer_step(self, trainer, pl_module, optimizer):
            self._closing = True

        def on_train_batch_end(self, trainer, pl_module, outputs, batch, batch_idx):
            t = self._now()
            self._acc["compute_s"] += t - self._t0
            self._acc["micro"] += 1
            self._last_end = t
            if self._closing:
                self.updates.append(dict(self._acc))
                self._acc = {"targets": 0, "compute_s": 0.0, "wait_s": 0.0, "micro": 0}
                self._closing = False
            if (len(self.chunks) % 50) == 0:
                self._sample_rss()

        def on_train_epoch_end(self, trainer, pl_module):
            self.unclosed_micro += self._acc["micro"]
            self._acc = {"targets": 0, "compute_s": 0.0, "wait_s": 0.0, "micro": 0}

        def on_validation_start(self, trainer, pl_module):
            if trainer.sanity_checking:  # stage 1 review item 8
                return
            self.peaks["train"] = self._peak()
            self._reset()
            self.phase = "validation"
            self._vstart = self._now()
            self._sample_rss()

        def on_validation_batch_start(self, trainer, pl_module, batch, batch_idx, dataloader_idx=0):
            if trainer.sanity_checking:
                return
            self._eval_batch = int(batch["mask"].shape[0])
            self._maybe_oom("validation")
            self._vb = self._now()

        def on_validation_batch_end(self, trainer, pl_module, outputs, batch, batch_idx, dataloader_idx=0):
            if trainer.sanity_checking:
                return
            self.val_batch_s.append(self._now() - self._vb)

        def on_validation_end(self, trainer, pl_module):
            if trainer.sanity_checking:
                return
            self.val_total_s.append(self._now() - self._vstart)
            self.peaks["validation"] = self._peak()
            self.phase = "train"
            self._sample_rss()

        def on_train_end(self, trainer, pl_module):
            self.marks["train_end"] = self._now()
            if "train" not in self.peaks:  # no validation ran: the training phase ends here
                self.peaks["train"] = self._peak()

        # -- result
        def summary(self):
            ups = self.updates
            post = ups[self.warmup:] if len(ups) > self.warmup else ups
            phase_peaks = [p for p in self.peaks.values() if p]
            overall = None
            if phase_peaks:  # stage 1 review item 20: the largest phase peak
                overall = {"alloc_gib": max(p["alloc_gib"] for p in phase_peaks),
                           "reserved_gib": max(p["reserved_gib"] for p in phase_peaks)}
            targets = [u["targets"] for u in ups]
            return {
                "cuda": self.cuda, "updates": len(ups), "micro_batches": len(self.chunks),
                "warmup_updates": self.warmup, "warmup_applied": len(ups) > self.warmup,
                "updates_measured": len(post),
                "compute_per_update_s": {"median": _median([u["compute_s"] for u in post]),
                                         "mean": _mean([u["compute_s"] for u in post])},
                "data_wait_per_update_s": {"median": _median([u["wait_s"] for u in post]),
                                           "mean": _mean([u["wait_s"] for u in post])},
                "targets_per_update": {"mean": _mean(targets), "min": min(targets) if targets else None,
                                       "max": max(targets) if targets else None},
                "micro_per_update": {"mean": _mean([u["micro"] for u in ups])},
                "unclosed_micro_batches": self.unclosed_micro,
                "chunks_per_micro": {"mean": _mean(self.chunks), "max": max(self.chunks) if self.chunks else None},
                "padded_width": {"mean": _mean(self.widths), "max": max(self.widths) if self.widths else None},
                "route_other": self.route_other,
                "validation_batches": len(self.val_batch_s),
                "validation_per_batch_s": {"median": _median(self.val_batch_s), "mean": _mean(self.val_batch_s)},
                "validation_total_s": sum(self.val_total_s),
                "peaks": self.peaks, "overall_peak": overall, "host_rss": dict(self.rss),
                "sanity_ran": self.sanity_ran,
            }

    return WidthTimer()


# ---------------------------------------------------------------- the wrapped trainer run

def run_wrapped(config, fit_dir, updates=None, val_batches=None, overrides=(), timer=None):
    """The trainer's own ``main`` with ``build_trainer`` replaced in memory, then put back. With ``updates`` or
    ``val_batches`` the Trainer gets the step limits; with ``timer`` the callback list gets the timer last. Both
    are optional, so a test can run the same limits with and without the timer."""
    tm = nf_layout.get("trainer")
    original = tm.build_trainer
    pl = getattr(tm, "pl", None)
    if pl is None:
        import pytorch_lightning as pl

    def patched(cfg, callbacks):
        cbs = list(callbacks) + ([timer] if timer is not None else [])
        if updates is None and val_batches is None:
            return original(cfg, cbs)
        extra = {"num_sanity_val_steps": 0}
        if updates is not None:
            extra["limit_train_batches"] = int(updates) * int(cfg.training.get("accumulate_grad_batches", 1))
        if val_batches is not None:
            extra["limit_val_batches"] = int(val_batches)
        real = pl.Trainer
        with mock.patch.object(pl, "Trainer", functools.partial(real, **extra)):
            return original(cfg, cbs)

    tm.build_trainer = patched
    try:
        tm.main(["--config", str(config), f"output.checkpoint_dir={fit_dir}", *list(overrides)])
    finally:
        tm.build_trainer = original


def plan_overrides(plan):
    return [f"training.batch_size={int(plan['batch_size'])}",
            f"training.accumulate_grad_batches={int(plan['accumulate_grad_batches'])}",
            f"training.eval_batch_size={int(plan['eval_batch_size'])}"]


def _is_oom(error):
    try:
        import torch
        if isinstance(error, torch.cuda.OutOfMemoryError):
            return True
    except (ImportError, AttributeError):
        pass
    return "out of memory" in str(error).lower()


def attempt_problems(summary, updates, val_batches, accumulate):
    """Reasons an attempt measured nothing trustworthy: the timer never attached, or the step limits were
    ignored (for example a trainer that imports Trainer by name or builds it elsewhere)."""
    out = []
    n, micro, vb = summary.get("updates", 0), summary.get("micro_batches", 0), summary.get("validation_batches", 0)
    if n == 0:
        out.append("no update was timed: the timer did not attach")
    if n > int(updates):
        out.append(f"{n} updates ran, above the limit {updates}: the step limits were ignored")
    if micro > int(updates) * int(accumulate):
        out.append(f"{micro} micro-batches ran, above {updates} x {accumulate}")
    if n and n * int(accumulate) < micro - int(accumulate):
        out.append(f"{micro} micro-batches for {n} updates at accumulation {accumulate}")
    if vb == 0:
        out.append("no validation batch was timed")
    if vb > int(val_batches):
        out.append(f"{vb} validation batches ran, above the limit {val_batches}")
    return out


def attempt_main(args):
    """One attempt, in its own process: the wrapped run at one plan; writes the attempt JSON."""
    cfg = load_cfg(args.config)
    plan = {"batch_size": args.batch_size, "accumulate_grad_batches": args.accumulate,
            "eval_batch_size": args.eval_batch_size}
    chunk = bool(cfg.sequence.get("predict_every_transaction", False)) and not bool(
        cfg.sequence.get("train_target_ending", False))
    timer = make_timer(args.warmup, chunk_route=chunk)
    overrides = ["training.max_epochs=1", *plan_overrides(plan)]
    result = {"plan": plan, "fit_dir": nf_common.rel(args.fit_dir), "utc_start": nf_common.utc_now(),
              "pid": os.getpid()}
    if timer.cuda:
        import torch
        free, total = torch.cuda.mem_get_info()
        result["device_total_gib"] = total / GIB
    code = nf_common.OK
    try:
        run_wrapped(args.config, args.fit_dir, args.updates, args.val_batches, overrides, timer)
        result["status"] = "ok"
    except BaseException as error:  # noqa: BLE001 - the attempt records its own end
        if _is_oom(error):
            result.update(status="oom", oom_phase=timer.phase, error=str(error)[:300])
            code = OOM_EXIT
        else:
            result.update(status="error", error_type=type(error).__name__, error=str(error)[:300],
                          phase=timer.phase)
            code = nf_common.CRASH
    result.update(timer.summary())
    if result["status"] == "ok":
        problems = attempt_problems(result, args.updates, args.val_batches, args.accumulate)
        if problems:
            result.update(status="error", error_type="NotMeasured", error="; ".join(problems))
            code = nf_common.CRASH
    result["utc_end"] = nf_common.utc_now()
    manifest = Path(args.fit_dir) / "run_manifest_v2.json"
    if manifest.is_file():
        m = nf_common.read_json(manifest)
        result["fit_status"] = m.get("status")
        result["optimizer_steps"] = m.get("optimizer_steps")
    nf_common.write_json(args.out, result)
    return code


# ---------------------------------------------------------------- the memory rule

def default_attempts(plan, min_chunks=MIN_CHUNKS, min_eval=MIN_EVAL):
    """Enough attempts for the rule to reach both floors: log2(B / min_chunks) + log2(E / min_eval) + 1."""
    b, e = int(plan["batch_size"]), int(plan["eval_batch_size"])
    steps_b = int(math.floor(math.log2(b / min_chunks))) if b >= min_chunks else 0
    steps_e = int(math.floor(math.log2(e / min_eval))) if e >= min_eval else 0
    return steps_b + steps_e + 1


def next_plan(plan, attempt, device_total_gib=None, mem_share=MEM_SHARE, min_chunks=MIN_CHUNKS, min_eval=MIN_EVAL):
    """The next plan after an attempt, or (None, reason) when the attempt's plan stands, or ("stop", reason).

    Training out of memory, or a training peak above mem_share of device memory: halve the batch, double the
    accumulation (batch x accumulation, so targets per update, stays the same). Validation out of memory, or a
    validation peak above the share: halve the eval batch."""
    status = attempt.get("status")
    peaks = attempt.get("peaks") or {}
    total = attempt.get("device_total_gib") or device_total_gib

    def high(phase):
        p = peaks.get(phase)
        return bool(total and p and p.get("reserved_gib") is not None and p["reserved_gib"] > mem_share * total)

    train_fix = (status == "oom" and attempt.get("oom_phase") in ("train", "setup")) or (status == "ok" and high("train"))
    val_fix = (status == "oom" and attempt.get("oom_phase") == "validation") or (status == "ok" and high("validation"))
    if status not in ("ok", "oom"):
        return "stop", f"attempt failed: {attempt.get('error_type')}: {attempt.get('error')}"
    new = dict(plan)
    if train_fix:
        b, a = int(plan["batch_size"]), int(plan["accumulate_grad_batches"])
        if b % 2 or b // 2 < min_chunks:
            return "stop", (f"training needs a smaller micro-batch, but batch {b} cannot halve to an even split at or "
                            f"above {min_chunks} chunks")
        new["batch_size"], new["accumulate_grad_batches"] = b // 2, a * 2
        why = "training out of memory" if status == "oom" else f"training peak above {mem_share:.0%} of device memory"
        return new, f"{why}: batch {b} -> {b // 2}, accumulation {a} -> {a * 2}"
    if val_fix:
        e = int(plan["eval_batch_size"])
        if e // 2 < min_eval:
            return "stop", f"validation needs a smaller eval batch, but {e} cannot halve at or above {min_eval}"
        new["eval_batch_size"] = e // 2
        why = "validation out of memory" if status == "oom" else f"validation peak above {mem_share:.0%} of device memory"
        return new, f"{why}: eval batch {e} -> {e // 2}"
    return None, "fits"


# ---------------------------------------------------------------- GPU-use sampler (a thread of the driver)

class GpuSampler(threading.Thread):
    QUERY = ("timestamp,index,name,utilization.gpu,utilization.memory,memory.used,memory.total,power.draw,"
             "temperature.gpu")

    def __init__(self, path, every=5.0):
        super().__init__(daemon=True)
        self.path, self.every, self.stop_event = Path(path), float(every), threading.Event()
        self.samples = []

    def run(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "a", encoding="utf-8") as f:
            if shutil.which("nvidia-smi") is None:
                f.write("nvidia-smi not found\n")
                return
            while not self.stop_event.is_set():
                lines = nvidia(self.QUERY) or []
                for ln in lines:
                    f.write(f"{nf_common.utc_now()},{ln}\n")
                    parts = [x.strip() for x in ln.split(",")]
                    try:
                        self.samples.append(float(parts[3]))
                    except (IndexError, ValueError):
                        pass
                f.flush()
                self.stop_event.wait(self.every)

    def stop(self):
        self.stop_event.set()
        self.join(timeout=10)


# ---------------------------------------------------------------- costs

def stage1_costs(path=None):
    """C_c and C_v (hours per epoch at the base width) from stage 1's timing summary, if present. Copilot points
    SETTINGS.yaml stage1.timing at it; the keys read are C_c and C_v (or c_c_hours and c_v_hours)."""
    if path is None:
        try:
            path = (nf_common.settings().get("stage1") or {}).get("timing")
        except (OSError, ValueError):
            path = None
    if not path:
        return None
    p = Path(path) if Path(path).is_absolute() else ROOT / path
    if not p.is_file():
        return None
    d = nf_common.read_json(p)
    cc = d.get("C_c", d.get("c_c_hours"))
    cv = d.get("C_v", d.get("c_v_hours"))
    if cc is None:
        return None
    return {"C_c": float(cc), "C_v": None if cv is None else float(cv), "source": nf_common.rel(p)}


def costs(result, base=None, stage1=None, updates_per_epoch=UPDATES_PER_EPOCH, encode=None):
    """C_f = C_c x (time per update now / at the base width), from the same session's base-width run; else a
    projection from the timed run, labelled as one. Step maxima are 10 and 20 epochs (DESIGN.md 6.8)."""
    cu = (result.get("compute_per_update_s") or {}).get("median")
    wait = (result.get("data_wait_per_update_s") or {}).get("median") or 0.0
    vb = (result.get("validation_per_batch_s") or {}).get("median")
    out = {"updates_per_epoch": updates_per_epoch}
    if cu is not None and (cu + wait) > 0:
        out["data_wait_share"] = wait / (cu + wait)
    if cu is not None:
        out["projected_train_h_per_epoch"] = updates_per_epoch * (cu + wait) / 3600.0
        out["projected_gpu_h_per_epoch"] = updates_per_epoch * cu / 3600.0
    if base and cu is not None:
        bcu = (base.get("compute_per_update_s") or {}).get("median")
        bwait = (base.get("data_wait_per_update_s") or {}).get("median") or 0.0
        bvb = (base.get("validation_per_batch_s") or {}).get("median")
        if bcu:
            out["ratio_update"] = (cu + wait) / (bcu + bwait)  # time per update: compute and data wait
            out["ratio_compute"] = cu / bcu
        if bvb and vb is not None:
            out["ratio_validation"] = vb / bvb
    if stage1 and "ratio_update" in out:
        out["C_c"], out["C_f"] = stage1["C_c"], stage1["C_c"] * out["ratio_update"]
        if stage1.get("C_v") is not None and "ratio_validation" in out:
            out["C_v"], out["C_vf"] = stage1["C_v"], stage1["C_v"] * out["ratio_validation"]
        out["epoch_h"], out["epoch_label"] = out["C_f"] + out.get("C_vf", 0.0), "C_f (+ C_v,f) from stage 1"
    elif "projected_train_h_per_epoch" in out:
        out["epoch_h"], out["epoch_label"] = out["projected_train_h_per_epoch"], "projection from the timed run"
    if encode and out.get("epoch_h") is not None and encode.get("projected_encode_h_per_epoch") is not None:
        out["encode_h_per_epoch"] = encode["projected_encode_h_per_epoch"]
        if encode["projected_encode_h_per_epoch"] > out["epoch_h"]:
            out["epoch_h"] = encode["projected_encode_h_per_epoch"]
            out["epoch_label"] += "; encoding bound (max of GPU and encoding time)"
    if out.get("epoch_h") is not None:
        out["step_max_h"] = 10 * out["epoch_h"]
        out["confirmation_max_h"] = 20 * out["epoch_h"]
    return out


# ---------------------------------------------------------------- settings

def write_microbatch(run, plan, settings_path=None):
    """Write ``microbatch: {<run>: {...}}`` into SETTINGS.yaml, changing that one line only."""
    import yaml
    path = Path(settings_path) if settings_path else (
        Path(os.environ["NF_SETTINGS_DIR"]) if os.environ.get("NF_SETTINGS_DIR") else HERE) / "SETTINGS.yaml"
    lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
    hits = [i for i, ln in enumerate(lines) if ln.startswith("microbatch:")]
    if len(hits) != 1:
        raise SystemExit(f"{path.name}: expected one line starting with 'microbatch:', found {len(hits)}")
    i = hits[0]
    text, _, comment = lines[i].rstrip("\n").partition("#")
    current = yaml.safe_load(text.split(":", 1)[1]) or {}
    current[str(run)] = {k: int(plan[k]) for k in ("batch_size", "accumulate_grad_batches", "eval_batch_size")}
    flow = yaml.safe_dump({"microbatch": current}, default_flow_style=True, sort_keys=True).strip()
    flow = flow[1:-1] if flow.startswith("{") and flow.endswith("}") else flow
    lines[i] = flow + (f"   #{comment}" if comment else "") + "\n"
    path.write_text("".join(lines), encoding="utf-8")
    return path


# ---------------------------------------------------------------- the driver

def _gb(v):
    return "n/a" if v is None else f"{v:.2f} GiB"


def _h(v):
    return "n/a" if v is None else f"{v:.2f} h"


def _s(v):
    return "n/a" if v is None else f"{v:.4f} s"


def timing_screen(rec):
    w, rl, r, c = rec["width"], rec["row_limit"], rec["result"], rec["costs"]
    lines = [f"layout={rec['layout']}", f"device {rec['gpu_name']}, memory {_gb(rec.get('device_total_gib'))}",
             f"config {rec['config']}", f"config sha256 {rec['config_sha256'][:12]}",
             f"width: {w['fields']} fields -> {w['tokens']} tokens, {w['tokens_with_cls']} with CLS",
             f"  {w['continuous_dim']} continuous incl. the time gap; {w['categorical_inputs']} categorical incl. "
             f"datetime and {w['missing_flags']} missing flags",
             f"row limit {rl['limit']} ({'ok' if rl['ok'] else 'FAIL'}): train {rl['train_rows']} = {rl['train']}",
             f"  eval {rl['eval_rows']} = {rl['eval']}",
             f"as-run plan: batch {rec['as_run']['batch_size']} x accumulation "
             f"{rec['as_run']['accumulate_grad_batches']}, eval batch {rec['as_run']['eval_batch_size']}"]
    for a in rec["attempts"]:
        head = (f"attempt {a['k']}: batch {a['plan']['batch_size']} x {a['plan']['accumulate_grad_batches']}, "
                f"eval {a['plan']['eval_batch_size']}: {a['status']}")
        one = f"{head}; {a['next']}"
        lines += [one] if len(one) <= nf_common.SCREEN_WIDTH else [head, f"  {a['next']}"]
    fp = rec.get("final_plan")
    lines.append("final plan: " + ("none fits" if fp is None else
                 f"batch {fp['batch_size']} x accumulation {fp['accumulate_grad_batches']}, eval batch "
                 f"{fp['eval_batch_size']}" + ("  (memory rule fired)" if rec["rule_fired"] else "  (as run)")))
    tpu = r.get("targets_per_update") or {}
    mean = tpu.get("mean")
    share = "n/a" if c.get("data_wait_share") is None else f"{c['data_wait_share']:.0%}"
    lines += [f"updates timed {r.get('updates_measured')} of {r.get('updates')} (warm-up {r.get('warmup_updates')})",
              f"targets/update mean {'n/a' if mean is None else f'{mean:.1f}'} (min {tpu.get('min')}, max "
              f"{tpu.get('max')}); stage 1 band {TARGET_BAND[0]}-{TARGET_BAND[1]}",
              f"compute/update median {_s((r.get('compute_per_update_s') or {}).get('median'))}; data wait "
              f"{_s((r.get('data_wait_per_update_s') or {}).get('median'))}; data-wait share "
              f"{share}",
              f"validation/batch median {_s((r.get('validation_per_batch_s') or {}).get('median'))} over "
              f"{r.get('validation_batches')} batches"]
    pk = r.get("peaks") or {}
    tr, va = pk.get("train") or {}, pk.get("validation") or {}
    lines.append(f"peak train alloc {_gb(tr.get('alloc_gib'))}, reserved {_gb(tr.get('reserved_gib'))}")
    lines.append(f"peak validation alloc {_gb(va.get('alloc_gib'))}, reserved {_gb(va.get('reserved_gib'))}")
    hr = r.get("host_rss") or {}
    lines.append(f"host RSS main {_gb(hr.get('main_gib'))}, workers {_gb(hr.get('workers_gib'))}; host memory "
                 f"{_gb(rec.get('host_total_gib'))}")
    gu = rec.get("gpu_use")
    lines.append("GPU use: not measured" if not gu else f"GPU use median {gu['median']:.0f}% mean {gu['mean']:.0f}% "
                 f"over {gu['samples']} samples")
    if "C_f" in c:
        lines.append(f"C_c {_h(c.get('C_c'))}  C_f {_h(c.get('C_f'))}  C_v {_h(c.get('C_v'))}  "
                     f"C_v,f {_h(c.get('C_vf'))}  (ratio {c['ratio_update']:.3f})")
    if c.get("epoch_h") is not None:
        lines.append(f"epoch {_h(c['epoch_h'])} ({c['epoch_label']})")
        lines.append(f"step maximum 10 epochs {_h(c['step_max_h'])}; confirmation 20 epochs "
                     f"{_h(c['confirmation_max_h'])}")
    if c.get("encode_h_per_epoch") is not None:
        lines.append(f"encoding per epoch {_h(c['encode_h_per_epoch'])}")
    if rec.get("microbatch_changed"):
        lines.append("memory rule fired: refit the control at this micro-batch, or the owner accepts the")
        lines.append("difference as a declared confound (SETTINGS.yaml microbatch_confound_accepted_by)")
    elif rec["rule_fired"]:
        lines.append("memory rule fired for the eval batch only: training is unchanged")
    for n in rec.get("notes", []):
        lines.append(n)
    footer = [f"verdict: {rec['verdict']}", f"full record: {rec['json']}"]
    return nf_common.screen(f"WIDTH TIMING {rec['run']}  {rec['utc']}", lines, footer)


def real_main(args):
    lay = nf_layout.resolve(["trainer", "feature_list", "s3"])
    cfg = load_cfg(args.config)
    tdir = nf_common.c2() / "timing"
    out_json, out_txt, work = tdir / f"{args.run}.json", tdir / f"{args.run}.txt", tdir / args.run
    if out_json.is_file():
        print(f"skip: {nf_common.rel(out_json)} exists")
        if out_txt.is_file():
            print(out_txt.read_text(encoding="utf-8"))
        saved = nf_common.read_json(out_json)
        return nf_common.OK if saved.get("verdict") == "OK" else nf_common.STOP
    if work.exists():
        nf_common.say(f"refused: {nf_common.rel(work)} exists but is incomplete: rename it to run it again",
                      file=sys.stdout)
        return nf_common.REFUSED
    if not args.no_busy_check:
        busy = nf_common.busy()
        if busy:
            nf_common.say("refused: the GPU is busy:\n  " + "\n  ".join(busy), file=sys.stdout)
            return nf_common.REFUSED
    width = token_width(cfg)
    rl = row_limit(cfg)
    notes = []
    as_run = {"batch_size": int(cfg.training.batch_size),
              "accumulate_grad_batches": int(cfg.training.get("accumulate_grad_batches", 1)),
              "eval_batch_size": int(nf_layout.attr("trainer", "eval_batch_size")(cfg))}
    gpu = nvidia("name,memory.total")
    gpu_name = gpu[0].split(",")[0].strip() if gpu else ("no nvidia-smi" if not _cuda() else "unknown")
    rec = {"run": args.run, "utc": nf_common.utc_now(), "layout": lay.layout, "config": nf_common.rel(args.config),
           "config_sha256": nf_common.sha256_file(args.config), "width": width, "row_limit": rl, "as_run": as_run,
           "gpu_name": gpu_name, "host_total_gib": host_memory_gib(), "attempts": [], "notes": notes,
           "json": nf_common.rel(out_json), "settings": {"updates": args.updates, "val_batches": args.val_batches,
                                                          "warmup": args.warmup, "mem_share": args.mem_share}}
    if gpu:
        try:
            rec["device_total_gib"] = float(gpu[0].split(",")[1]) / 1024.0
        except (IndexError, ValueError):
            pass
    base_path = tdir / f"{args.base_timing}.json" if args.base_timing else None
    if base_path is not None and not base_path.is_file():
        nf_common.say(f"refused: --base-timing {args.base_timing}: {nf_common.rel(base_path)} not found",
                      file=sys.stdout)
        return nf_common.REFUSED
    try:
        st1 = ({"C_c": args.c_c, "C_v": args.c_v, "source": "command line"} if args.c_c is not None
               else stage1_costs())
    except (OSError, ValueError, TypeError) as e:
        nf_common.say(f"refused: stage 1 timing summary unreadable: {e}", file=sys.stdout)
        return nf_common.REFUSED
    max_attempts = args.max_attempts or default_attempts(as_run, args.min_chunks, args.min_eval)
    rec["settings"]["max_attempts"] = max_attempts
    work.mkdir(parents=True)
    sampler = GpuSampler(work / "gpu.csv")
    sampler.start()
    plan, final, result, verdict = dict(as_run), None, {}, "OK"
    code = nf_common.OK
    try:
        if not rl["ok"]:
            verdict, code = f"STOP row limit: {rl['reason']}", nf_common.STOP
        for k in range(max_attempts if rl["ok"] else 0):
            ajson = work / f"attempt_{k}.json"
            cmd = [sys.executable, str(Path(__file__).resolve()), "_attempt", "--config", str(args.config),
                   "--fit-dir", str(work / f"attempt_{k}" / "fit"), "--out", str(ajson),
                   "--updates", str(args.updates), "--val-batches", str(args.val_batches),
                   "--warmup", str(args.warmup), "--batch-size", str(plan["batch_size"]),
                   "--accumulate", str(plan["accumulate_grad_batches"]),
                   "--eval-batch-size", str(plan["eval_batch_size"])]
            with open(work / f"attempt_{k}.log", "a", encoding="utf-8") as log:
                rc = subprocess.call(cmd, stdout=log, stderr=subprocess.STDOUT, cwd=str(Path.cwd()))
            attempt = nf_common.read_json(ajson) if ajson.is_file() else {"status": "error", "error_type": "NoResult",
                                                                         "error": f"rc {rc}, see attempt_{k}.log"}
            nxt, why = next_plan(plan, attempt, rec.get("device_total_gib"), args.mem_share, args.min_chunks,
                                 args.min_eval)
            rec["attempts"].append({"k": k, "plan": dict(plan), "rc": rc, "status": attempt.get("status"),
                                    "next": why, "json": nf_common.rel(ajson)})
            if attempt.get("device_total_gib"):
                rec["device_total_gib"] = attempt["device_total_gib"]
            if nxt is None:
                final, result = dict(plan), attempt
                break
            if nxt == "stop":
                verdict = f"STOP {why}"
                code = nf_common.STOP if attempt.get("status") in ("ok", "oom") else nf_common.CRASH
                result = attempt
                break
            plan = nxt
        else:
            if rl["ok"]:
                verdict, code = f"STOP no plan fits after {max_attempts} attempts", nf_common.STOP
    finally:
        sampler.stop()
    if sampler.samples:
        rec["gpu_use"] = {"median": statistics.median(sampler.samples), "mean": _mean(sampler.samples),
                          "samples": len(sampler.samples)}
    rec["final_plan"] = final
    rec["rule_fired"] = final is not None and final != as_run
    rec["microbatch_changed"] = final is not None and (
        final["batch_size"], final["accumulate_grad_batches"]) != (as_run["batch_size"], as_run["accumulate_grad_batches"])
    rec["microbatch"] = {args.run: final} if final else {}
    rec["result"] = result
    base = nf_common.read_json(base_path).get("result") if base_path is not None else None
    enc_path = tdir / "encode" / f"{args.run}.json"
    encode = nf_common.read_json(enc_path) if enc_path.is_file() else None
    rec["costs"] = costs(result, base, st1, args.updates_per_epoch, encode)
    if encode and encode.get("host_memory_ok") is False:
        verdict, code = f"STOP host memory: {encode.get('host_memory_reason')}", nf_common.STOP
    share = float((nf_common.settings().get("host_memory") or {}).get("max_fit_share", 0.8))
    measured = (result.get("host_rss") or {}).get("total_gib")
    total = rec.get("host_total_gib")
    rec["host_memory"] = {"measured_rss_gib": measured, "host_total_gib": total, "max_fit_share": share,
                          "ok": not (measured and total and measured > share * total)}
    if not rec["host_memory"]["ok"]:
        verdict, code = (f"STOP host memory: the timed run held {measured:.1f} GiB, above {share:.0%} of "
                         f"{total:.1f} GiB"), nf_common.STOP
    tpu = (result.get("targets_per_update") or {}).get("mean")
    if final and tpu is not None and not (TARGET_BAND[0] <= tpu <= TARGET_BAND[1]):
        notes.append(f"note: targets/update {tpu:.0f} is outside the stage 1 band {TARGET_BAND[0]}-{TARGET_BAND[1]}")
    if result.get("route_other"):
        notes.append(f"note: {result['route_other']} micro-batches with labels outside the mask (route check)")
    stage1_tool = ROOT / "fraud" / "experiments" / "reproduce" / "width_timing.py"
    if stage1_tool.is_file():
        notes.append(f"stage 1 width tool found ({nf_common.rel(stage1_tool)}): use it for synthetic widths;")
        notes.append("  this run is the real-data run at the step's own config")
    if not result.get("cuda"):
        notes.append("note: no CUDA in this run: memory not measured; times are CPU times")
    if final and args.write_settings and rec["rule_fired"]:
        p = write_microbatch(args.run, final)
        notes.append(f"microbatch for {args.run} written to SETTINGS.yaml ({p.parent.name})")
    elif final and rec["rule_fired"]:
        notes.append("write into SETTINGS.yaml (or rerun with --write-settings):")
        notes.append(f"  microbatch: {args.run}: {json.dumps(final, sort_keys=True)}")
    rec["verdict"] = verdict
    # top-level keys the morning report reads
    cst, ov = rec["costs"], (result.get("overall_peak") or {})
    for k_out, k_in in (("C_c", "C_c"), ("C_f", "C_f"), ("C_v", "C_v"), ("C_vf", "C_vf")):
        if cst.get(k_in) is not None:
            rec[k_out] = round(cst[k_in], 3)
    if ov.get("reserved_gib") is not None:
        rec["peak_gb"] = round(ov["reserved_gib"] * GIB / 1e9, 1)
    nf_common.write_json(out_json, rec)
    text = timing_screen(rec)
    out_txt.write_text(text + "\n", encoding="utf-8")
    print(text)
    return code


def width_main(args):
    lay = nf_layout.resolve(["trainer", "feature_list", "s3"])
    cfg = load_cfg(args.config)
    w, rl = token_width(cfg), row_limit(cfg)
    lines = [f"layout={lay.layout}", w["label"],
             f"row limit {rl['limit']}: train {rl['train_rows']} ({rl['train']})",
             f"                 eval {rl['eval_rows']} ({rl['eval']})",
             f"result: {'ok' if rl['ok'] else 'FAIL: ' + rl['reason']}",
             "the limit counts rows only; width changes memory, not this limit"]
    nf_common.print_screen(f"WIDTH {nf_common.rel(args.config)}", lines)
    return nf_common.OK if rl["ok"] else nf_common.STOP


# ---------------------------------------------------------------- chunks per update (design review item 16)

def _training_dataset(cfg, files=None):
    """The training builder exactly as the trainer's ``_fit`` builds it (pod patch 1 included)."""
    fs = nf_layout.attr("s3", "make_s3_filesystem")(cfg.s3.cred_path) if cfg.s3.get("cred_path") else None
    features = nf_layout.attr("feature_list", "load_feature_list")(cfg.predictors.csv_path,
                                                                   version=cfg.predictors.version, filesystem=fs)
    artifacts = nf_layout.attr("preprocessing", "PreprocessingArtifacts").load(
        f"{cfg.artifacts.base.rstrip('/')}/{cfg.artifacts.version}", filesystem=fs)
    dt = nf_layout.attr("datetime_features", "DatetimeConfig")(
        order_col=cfg.data.order_col, fields=list(cfg.datetime.fields), encoding=cfg.datetime.encoding,
        is_weekend=cfg.datetime.is_weekend)
    if files is None:
        files = nf_layout.attr("s3", "build_file_list")(cfg.data.train_base, cfg.data.train_start, cfg.data.train_end)
    kwargs = {}
    if bool(cfg.sequence.get("train_target_ending", False)):
        kwargs = {"builder_cls": nf_layout.attr("target_ending", "TargetEndingBuilder"),
                  "max_window_rows": cfg.sequence.get("max_window_rows", None)}
    make = nf_layout.attr("trainer", "make_dataset")
    return make(cfg, files, artifacts, features, dt, True, cfg.sequence.get("train_stride", 1), **kwargs), fs


def _chunk_fingerprints(batch):
    """One fingerprint per chunk: its real rows' times, targets and continuous values (padding removed)."""
    import hashlib
    import numpy as np
    out = []
    mask = batch["mask"].numpy().astype(bool)
    for i in range(mask.shape[0]):
        m = mask[i]
        h = hashlib.sha256()
        for key in ("time_seq", "target_seq", "continuous", "categorical"):
            if key in batch:
                h.update(np.ascontiguousarray(batch[key][i].numpy()[m]).tobytes())
        out.append(h.hexdigest())
    return out


def update_groups(cfg, batch, accumulate, max_updates, seed):
    """The sorted chunk fingerprints of each update, iterating the real training builder for one epoch with the
    trainer's seeding, through a DataLoader with the config's num_workers (workers take turns)."""
    import pytorch_lightning as pl
    c = cfg.copy()
    c.training.batch_size = int(batch)
    c.training.accumulate_grad_batches = int(accumulate)
    pl.seed_everything(int(seed), workers=True)
    ds, _ = _training_dataset(c)
    from torch.utils.data import DataLoader
    workers = int(c.training.get("num_workers", 0))
    init = None
    if workers:
        try:
            from lightning_fabric.utilities.seed import pl_worker_init_function as init
        except ImportError:
            init = None
    loader = DataLoader(ds, batch_size=None, num_workers=workers, worker_init_fn=init)
    groups, cur, micro = [], [], 0
    for b in loader:
        cur += _chunk_fingerprints(b)
        micro += 1
        if micro == int(accumulate):
            groups.append(sorted(cur))
            cur, micro = [], 0
            if len(groups) >= max_updates:
                break
    if cur and len(groups) < max_updates:
        groups.append(sorted(cur))  # Lightning steps the last partial accumulation at the epoch end
    return groups


def compare_chunks(cfg, batch, accumulate, max_updates=200):
    if int(batch) % 2:
        raise SystemExit(f"batch {batch} cannot halve evenly")
    seed = int(cfg.training.seed)
    a = update_groups(cfg, batch, accumulate, max_updates, seed)
    b = update_groups(cfg, int(batch) // 2, int(accumulate) * 2, max_updates, seed)
    n = min(len(a), len(b))
    differ = [i for i in range(n) if a[i] != b[i]]
    return {"plan_a": [int(batch), int(accumulate)], "plan_b": [int(batch) // 2, int(accumulate) * 2],
            "updates_a": len(a), "updates_b": len(b), "compared": n, "differ": len(differ),
            "first_differ": differ[:10], "same_chunks_every_update": not differ and len(a) == len(b),
            "buffer_windows": int(cfg.training.get("buffer_windows", 65536)),
            "num_workers": int(cfg.training.get("num_workers", 0)),
            "note": ("the window shuffle is one permutation per buffer, cut into batches; halving the batch keeps "
                     "the chunks of an update unless a buffer's last batch is partial or loader workers take turns. The loss weighting still "
                     "changes (a mean of micro-batch means), so the control is refit at the same micro-batch")}


def chunks_main(args):
    nf_layout.resolve(["trainer", "feature_list", "s3", "preprocessing", "datetime_features"])
    cfg = load_cfg(args.config)
    res = compare_chunks(cfg, args.batch, args.accumulate, args.max_updates)
    path = nf_common.out("timing", "chunks", f"{args.name}.json")
    nf_common.write_json(path, res)
    lines = [f"plan A batch {res['plan_a'][0]} x {res['plan_a'][1]}: {res['updates_a']} updates",
             f"plan B batch {res['plan_b'][0]} x {res['plan_b'][1]}: {res['updates_b']} updates",
             f"updates compared {res['compared']}; with different chunks {res['differ']}",
             f"same chunks in every update: {'yes' if res['same_chunks_every_update'] else 'no'}",
             "the per-update loss weighting differs either way: refit the control at the same micro-batch"]
    nf_common.print_screen(f"CHUNKS PER UPDATE {nf_common.rel(args.config)}", lines, f"record: {nf_common.rel(path)}")
    return nf_common.OK


# ---------------------------------------------------------------- encoding cost and host memory (review item 17)

def _peak_rss_gib():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024 / GIB  # Linux reports KiB


def encode_one(cfg, base, number):
    """Read one file's model columns and time the builder's ``_encode_file`` on it."""
    import pyarrow.parquet as pq
    files = nf_layout.attr("s3", "build_file_list")(base, int(number), int(number))
    ds, fs = _training_dataset(cfg, files)
    path = files[0]
    if fs is not None:
        path = nf_layout.attr("s3", "strip_scheme")(path)
    t0 = time.perf_counter()
    df = pq.ParquetDataset(path, filesystem=fs).read(columns=ds._read_cols).to_pandas()
    t1 = time.perf_counter()
    ds._encode_file(df)
    t2 = time.perf_counter()
    return {"file": number, "rows": int(len(df)), "read_s": t1 - t0, "encode_s": t2 - t1,
            "peak_rss_gib": _peak_rss_gib()}


def encode_main(args):
    nf_layout.resolve(["trainer", "feature_list", "s3", "preprocessing", "datetime_features"])
    cfg = load_cfg(args.config)
    w = token_width(cfg)
    train = encode_one(cfg, cfg.data.train_base, args.train_file if args.train_file is not None else cfg.data.train_start)
    val = encode_one(cfg, cfg.data.val_base, args.val_file if args.val_file is not None else cfg.data.val_start)
    n_train = int(cfg.data.train_end) - int(cfg.data.train_start) + 1
    n_val = int(cfg.data.val_end) - int(cfg.data.val_start) + 1
    workers = int(cfg.training.get("num_workers", 0))
    lanes = max(1, workers)
    per_epoch_s = (train["read_s"] + train["encode_s"]) * n_train / lanes + (val["read_s"] + val["encode_s"]) * n_val / lanes
    rows_w = int(cfg.sequence.get("max_chunk_rows", None) or (int(cfg.sequence.history_len) + 1))
    buffer_bytes = int(cfg.training.get("buffer_windows", 65536)) * rows_w * (
        4 * w["continuous_dim"] + 8 * w["categorical_inputs"] + 17)
    per_lane = max(train["peak_rss_gib"], val["peak_rss_gib"]) + buffer_bytes / GIB
    # during validation the training workers stay alive beside the validation workers
    projected = per_lane * (2 * workers + 1) if workers else per_lane
    total = host_memory_gib()
    share = float((nf_common.settings().get("host_memory") or {}).get("max_fit_share", 0.8)) if args.share is None \
        else float(args.share)
    ok = total is None or projected <= share * total
    rec = {"config": nf_common.rel(args.config), "width": w, "train": train, "validation": val,
           "train_files": n_train, "validation_files": n_val, "num_workers": workers,
           "projected_encode_h_per_epoch": per_epoch_s / 3600.0, "buffer_gib_per_worker": buffer_bytes / GIB,
           "projected_host_gib": projected, "host_total_gib": total, "max_fit_share": share,
           "host_memory_ok": ok,
           "host_memory_reason": "" if ok else (f"projected {projected:.1f} GiB is above {share:.0%} of "
                                                f"{total:.1f} GiB host memory")}
    path = nf_common.out("timing", "encode", f"{args.run}.json")
    nf_common.write_json(path, rec)
    lines = [w["label"],
             f"training file {train['file']}: {train['rows']} rows, read {train['read_s']:.1f} s, "
             f"encode {train['encode_s']:.1f} s, peak RSS {train['peak_rss_gib']:.2f} GiB",
             f"EPOCH_VAL file {val['file']}: {val['rows']} rows, read {val['read_s']:.1f} s, "
             f"encode {val['encode_s']:.1f} s, peak RSS {val['peak_rss_gib']:.2f} GiB",
             f"projected read and encode per epoch: {per_epoch_s / 3600:.2f} h over {lanes} worker lane(s) "
             f"({n_train} training + {n_val} validation files)",
             f"shuffle buffer per worker about {buffer_bytes / GIB:.2f} GiB; projected host memory "
             f"{projected:.1f} GiB of {_gb(total)}",
             f"host memory: {'ok' if ok else 'STOP ' + rec['host_memory_reason']}"]
    nf_common.print_screen(f"ENCODING COST {args.run}", lines, f"record: {nf_common.rel(path)}")
    return nf_common.OK if ok else nf_common.STOP


# ---------------------------------------------------------------- command line

# ---------------------------------------------------------------- the scoring pass (D4b, D9-Y22)

def _pct(values, q):
    if not values:
        return None
    v = sorted(values)
    k = min(len(v) - 1, max(0, int(math.ceil(q / 100 * len(v))) - 1))
    return v[k]


def score_pass(model, loader, scorer, device, batches, windows, cuda):
    """Time the scoring batch and single windows (the first batch's windows, one at a time) through the scorer's
    own model inputs, in float32 with no gradient. Returns (batch seconds, window seconds, targets per batch)."""
    import torch

    def sync():
        if cuda:
            torch.cuda.synchronize()
    bt, wt, targets, first = [], [], [], None
    with torch.no_grad():
        for i, b in enumerate(loader):
            if i >= batches:
                break
            first = b if first is None else first
            sync()
            t0 = time.perf_counter()
            model(scorer._model_inputs(b, device))
            sync()
            bt.append(time.perf_counter() - t0)
            targets.append(int(b["mask"].shape[0]))
        if first is not None:
            n = int(first["mask"].shape[0])
            for i in range(min(windows, n)):
                one = {k: v[i:i + 1] for k, v in first.items() if hasattr(v, "shape") and len(v.shape)}
                sync()
                t0 = time.perf_counter()
                model(scorer._model_inputs(one, device))
                sync()
                wt.append(time.perf_counter() - t0)
    return bt, wt, targets


def score_main(args):
    """The reviewers' decision D4b: a fitted checkpoint's scoring latency through the organized scorer, single
    windows one at a time and the scoring batch, written to C2/timing/<run>_scoring.json with the median, the 99th
    percentile and the fit's input count; figures only, no pass or fail. D9-Y22: the pass's peak allocated and
    reserved memory; when it runs out of memory or passes 85% of device memory, the eval batch halves (down to
    128) and the pass runs again; --write-settings writes the final eval batch into SETTINGS.yaml microbatch."""
    import torch
    cfg = load_cfg(args.config)
    scorer = nf_layout.get("scorer")
    out = nf_common.out("timing", f"{args.run}_scoring.json")
    eval_batch = int(cfg.training.get("eval_batch_size", cfg.training.get("batch_size", 256)))
    attempts = []
    while True:
        cfg.training.eval_batch_size = eval_batch
        run = scorer.load_for_scoring(cfg, args.checkpoint)
        model, loader, device = run["model"], run["loader"], run["device"]
        if args.cpu:
            device = "cpu"
            model.to("cpu")
        cuda = str(device).startswith("cuda")
        if cuda:
            torch.cuda.reset_peak_memory_stats()
        try:
            bt, wt, targets = score_pass(model, loader, scorer, device, args.batches, args.windows, cuda)
            status = "ok"
        except BaseException as error:  # noqa: BLE001 - an out-of-memory pass halves the batch
            if not _is_oom(error):
                raise
            status, bt, wt, targets = "oom", [], [], []
        peak = (torch.cuda.max_memory_allocated() / GIB, torch.cuda.max_memory_reserved() / GIB) if cuda else \
            (None, None)
        total = torch.cuda.mem_get_info()[1] / GIB if cuda else None
        over = cuda and peak[0] is not None and total and peak[0] > args.mem_share * total
        attempts.append({"eval_batch_size": eval_batch, "status": status, "peak_allocated_gib": peak[0],
                         "peak_reserved_gib": peak[1], "device_total_gib": total})
        if (status == "oom" or over) and eval_batch // 2 >= args.min_eval:
            eval_batch //= 2
            continue
        break
    names = list(run["loader"].dataset.features.continuous) + list(run["loader"].dataset.features.categorical)
    rec = {"run": args.run, "checkpoint": nf_common.rel(args.checkpoint), "device": str(device),
           "inputs": len(names), "eval_batch_size": eval_batch, "attempts": attempts,
           "batch_seconds": {"median": _median(bt) if bt else None, "p99": _pct(bt, 99), "n": len(bt)},
           "window_seconds": {"median": _median(wt) if wt else None, "p99": _pct(wt, 99), "n": len(wt)},
           "seconds_per_target": (sum(bt) / sum(targets)) if targets and sum(targets) else None,
           "note": "figures only; no threshold (the reviewers' decision D4b); any cap or budget the bank states "
                   "is compared in the stage 2 report", "utc": nf_common.utc_now()}
    if args.write_settings and attempts and attempts[0]["eval_batch_size"] != eval_batch:
        held = (nf_common.settings().get("microbatch") or {}).get(args.run)
        if held:      # only a run the memory rule already holds an entry for; its other keys stay
            mb = dict(held, eval_batch_size=eval_batch)
            write_microbatch(args.run, mb)
            rec["settings_microbatch"] = {args.run: mb}
        else:
            rec["settings_microbatch"] = f"not written: SETTINGS.yaml microbatch holds no entry for {args.run}"
    nf_common.write_json(out, rec)

    def ms(x):
        return "na" if x is None else f"{1000 * x:.2f} ms"
    lines = [f"device {rec['device']}; inputs {rec['inputs']}; eval batch {eval_batch}"
             + (f" (halved from {attempts[0]['eval_batch_size']}: the memory rule)" if len(attempts) > 1 else ""),
             f"scoring batch: median {ms(rec['batch_seconds']['median'])}, 99th percentile "
             f"{ms(rec['batch_seconds']['p99'])} over {len(bt)} batches",
             f"single window: median {ms(rec['window_seconds']['median'])}, 99th percentile "
             f"{ms(rec['window_seconds']['p99'])} over {len(wt)} windows",
             "peak memory: " + ("allocated {:.2f} GiB, reserved {:.2f} GiB".format(*peak) if cuda else "not on a GPU"),
             "figures only: no pass or fail; the stage 2 report compares them with any cap the bank states"]
    nf_common.print_screen(f"SCORING TIMING  {args.run}", lines, f"record: {nf_common.rel(out)}")
    return nf_common.OK


def parser():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    w = sub.add_parser("width")
    w.add_argument("--config", required=True)
    r = sub.add_parser("real")
    r.add_argument("--config", required=True)
    r.add_argument("--run", required=True)
    r.add_argument("--updates", type=int, default=300)
    r.add_argument("--val-batches", type=int, default=200)
    r.add_argument("--warmup", type=int, default=50)
    r.add_argument("--max-attempts", type=int, default=None, help="default: enough to reach both floors")
    r.add_argument("--min-chunks", type=int, default=MIN_CHUNKS)
    r.add_argument("--min-eval", type=int, default=MIN_EVAL)
    r.add_argument("--mem-share", type=float, default=MEM_SHARE)
    r.add_argument("--updates-per-epoch", type=int, default=UPDATES_PER_EPOCH)
    r.add_argument("--base-timing", default=None, help="run name of this session's base-width timing")
    r.add_argument("--c-c", type=float, default=None, help="stage 1 C_c in hours, if not read from SETTINGS")
    r.add_argument("--c-v", type=float, default=None)
    r.add_argument("--write-settings", action="store_true", help="write the micro-batch into SETTINGS.yaml")
    r.add_argument("--no-busy-check", action="store_true", help=argparse.SUPPRESS)
    c = sub.add_parser("chunks")
    c.add_argument("--config", required=True)
    c.add_argument("--batch", type=int, required=True)
    c.add_argument("--accumulate", type=int, default=1)
    c.add_argument("--max-updates", type=int, default=200)
    c.add_argument("--name", default="chunks")
    e = sub.add_parser("encode")
    e.add_argument("--config", required=True)
    e.add_argument("--run", required=True)
    e.add_argument("--train-file", type=int, default=None)
    e.add_argument("--val-file", type=int, default=None)
    e.add_argument("--share", type=float, default=None)
    sc = sub.add_parser("score")
    sc.add_argument("--config", required=True)
    sc.add_argument("--checkpoint", required=True)
    sc.add_argument("--run", required=True)
    sc.add_argument("--batches", type=int, default=50)
    sc.add_argument("--windows", type=int, default=200)
    sc.add_argument("--min-eval", type=int, default=MIN_EVAL)
    sc.add_argument("--mem-share", type=float, default=MEM_SHARE)
    sc.add_argument("--cpu", action="store_true", help="time on the CPU (if the bank serves on CPU)")
    sc.add_argument("--write-settings", action="store_true", help="write a halved eval batch into SETTINGS.yaml")
    a = sub.add_parser("_attempt")
    a.add_argument("--config", required=True)
    a.add_argument("--fit-dir", required=True)
    a.add_argument("--out", required=True)
    a.add_argument("--updates", type=int, required=True)
    a.add_argument("--val-batches", type=int, required=True)
    a.add_argument("--warmup", type=int, required=True)
    a.add_argument("--batch-size", type=int, required=True)
    a.add_argument("--accumulate", type=int, required=True)
    a.add_argument("--eval-batch-size", type=int, required=True)
    return p


def main(argv=None):
    try:
        args = parser().parse_args(argv)
    except SystemExit as e:
        return nf_common.ARGS if e.code else nf_common.OK
    cfg_path = getattr(args, "config", None)
    if args.cmd != "_attempt" and cfg_path and not Path(cfg_path).is_file():
        nf_common.say(f"refused: the config {cfg_path} does not exist; give the step's config (NF/configs/<run>.yaml)",
              file=sys.stderr)
        return nf_common.REFUSED
    try:
        return {"width": width_main, "real": real_main, "chunks": chunks_main, "encode": encode_main,
                "score": score_main, "_attempt": attempt_main}[args.cmd](args)
    except nf_layout.LayoutError as e:
        return e.code
    except SystemExit as e:
        return e.code if isinstance(e.code, int) else nf_common.CRASH
    except FileNotFoundError as e:
        # a pod path or record named by the config is missing: a clear refusal, not a traceback
        nf_common.say(f"refused: a file the config names is missing: {e.filename or e}", file=sys.stderr)
        return nf_common.REFUSED
    except Exception as e:  # noqa: BLE001
        import yaml
        from omegaconf.errors import MissingMandatoryValue, OmegaConfBaseException
        if isinstance(e, MissingMandatoryValue):
            nf_common.say(f"refused: the config leaves {getattr(e, 'full_key', '') or e} open ('???'); the chunk run's own "
                  "resolved_train_v2.yaml fills it (stage 1)", file=sys.stderr)
            return nf_common.REFUSED
        if isinstance(e, (yaml.YAMLError, OmegaConfBaseException)):
            nf_common.say(f"refused: the config cannot be read ({type(e).__name__}: {str(e).splitlines()[0]})",
                  file=sys.stderr)
            return nf_common.REFUSED
        raise


if __name__ == "__main__":
    sys.exit(main())
