"""CPU usefulness screen: XGBoost with and without one feature family (usefulness layer 1).

Re-delivered copy of the screen in fraud/experiments/features/screen/usefulness.py (before the
reorganization: waqas/v2/screen/usefulness.py). The logic of every copied function is unchanged:
account-grouped K-fold inside the training files, the same folds for both arms (every comparison is
paired), pooled out-of-fold AP, an account-cluster bootstrap interval for the AP difference, the
difference by month, grouped permutation importance of the family, and the fixed PASS_RULE and
FINAL_RULE texts.

Added below the copied part (section "Per-feature ranking"):
- shap_per_feature: XGBoost's built-in SHAP contributions (pred_contribs=True), the absolute value
  summed per feature over rows.
- feature_rank: one arm (base plus all new fields) on the same folds and training rows as
  run_screen, with SHAP on a fixed sample of held-out rows and permutation AP drops per feature and
  per cluster on the held-out folds.
- use_sklearn_fallback: for the dry run only, when xgboost is missing.

Every ranking here is XGBoost's view, not the transformer's. Row permutation on a table is only
the tree model's view: the transformer reads overlapping history windows, and its own importance
is measured at the source-event level by the importance tool after a fit. The ordinary
account-fold screen is account-held-out, not chronological; use the time-split screen
(fsc_stability.temporal_screen) for claims about later periods.
"""

import hashlib

import numpy as np
import pandas as pd

VIEW = "XGBoost's view, not the transformer's"

PASS_RULE = ("pooled out-of-fold AP(with) - AP(base) has a 95% account-bootstrap interval above 0; "
             "AND the paired fold difference is positive in at least K-1 of K folds; "
             "AND the difference is positive in at least two thirds of months that hold >= 50 frauds")

DEFAULT_PARAMS = {"tree_method": "hist", "max_depth": 6, "learning_rate": 0.1, "n_estimators": 300,
                  "subsample": 0.8, "colsample_bytree": 0.8, "min_child_weight": 1.0,
                  "max_cat_to_onehot": 1, "eval_metric": "aucpr", "n_jobs": 0}

MODEL = {"name": "xgboost"}


def account_folds(accounts, k=5, salt="screen-folds"):
    """Deterministic account -> fold in [0, k); every row of one account lands in one fold."""
    u, inv = np.unique(np.asarray(accounts).astype(str), return_inverse=True)
    f = np.array([int(hashlib.sha256((salt + a).encode()).hexdigest()[:8], 16) % k for a in u])
    return f[inv]


def weighted_ap(y, s, w=None):
    """Average precision as sklearn defines it (step-wise, ties grouped), with optional row weights."""
    y = np.asarray(y, dtype=float)
    s = np.asarray(s, dtype=float)
    w = np.ones_like(y) if w is None else np.asarray(w, dtype=float)
    o = np.argsort(-s, kind="mergesort")
    return _ap_sorted(y[o], s[o], w[o])


def _ap_sorted(y, s, w):
    tp = np.cumsum(w * y)
    fp = np.cumsum(w * (1 - y))
    last = np.r_[np.flatnonzero(np.diff(s) != 0), len(s) - 1]
    tp, fp = tp[last], fp[last]
    if tp[-1] <= 0:
        return float("nan")
    prec = tp / np.maximum(tp + fp, 1e-300)
    rec = tp / tp[-1]
    return float(np.sum(np.diff(np.r_[0.0, rec]) * prec))


def bootstrap_delta(y, s_base, s_with, accounts, n_boot=500, seed=0):
    """Account-cluster bootstrap (Poisson(1) weight per account) of AP(with) - AP(base). Each arm is
    sorted once; a replicate only reweights, so 500 replicates are cheap on millions of rows."""
    rng = np.random.default_rng(seed)
    _, inv = np.unique(np.asarray(accounts).astype(str), return_inverse=True)
    y = np.asarray(y, dtype=float)
    ob, ow = np.argsort(-s_base, kind="mergesort"), np.argsort(-s_with, kind="mergesort")
    deltas = np.empty(n_boot)
    for r in range(n_boot):
        wa = rng.poisson(1.0, inv.max() + 1).astype(float)[inv]
        deltas[r] = (_ap_sorted(y[ow], s_with[ow], wa[ow]) - _ap_sorted(y[ob], s_base[ob], wa[ob]))
    return np.nanpercentile(deltas, [2.5, 97.5]).tolist(), float(np.nanstd(deltas))


def _design(df, cols, cat_cols):
    X = df[cols].copy()
    for c in cols:
        if c in cat_cols:
            X[c] = X[c].astype("category")
        else:
            X[c] = pd.to_numeric(X[c], errors="coerce")
    return X


def _fit_predict(X_tr, y_tr, X_te, params, seed):
    import xgboost as xgb
    m = xgb.XGBClassifier(**params, enable_categorical=True, random_state=seed)
    m.fit(X_tr, y_tr)
    return m, m.predict_proba(X_te)[:, 1]


def run_screen(df, base_cols, family_cols, cat_cols=(), label="frd_tag",
               account="Nmap_account_reference_xid", time="transaction_dttm", k=5, seed=42,
               params=None, n_boot=500, min_month_frauds=50, permute=True, train_neg_rate=1.0, by_group=None):
    """Paired screen of `family_cols` on top of `base_cols`. Returns a JSON-ready dict of aggregates.

    `train_neg_rate` < 1 keeps that share of non-fraud rows in each training part only (features are already
    computed on the full stream, so this is target sampling after feature replay); held-out folds keep
    every row, so AP is at natural prevalence. `by_group` (a column name) adds the pooled AP difference per
    value of that column."""
    params = {**DEFAULT_PARAMS, **(params or {})}
    cat_cols = set(cat_cols)
    y = (pd.to_numeric(df[label], errors="coerce").to_numpy() == 1).astype(int)
    acc = df[account].astype(str).to_numpy()
    fold = account_folds(acc, k)
    Xb = _design(df, list(base_cols), cat_cols)
    Xw = _design(df, list(base_cols) + list(family_cols), cat_cols)
    oof_b, oof_w = np.full(len(df), np.nan), np.full(len(df), np.nan)
    per_fold, perm = [], []
    rng = np.random.default_rng(seed)
    keep_neg = np.random.default_rng(seed + 1).random(len(df))
    for f in range(k):
        te = fold == f
        tr = ~te & ((y == 1) | (keep_neg < train_neg_rate))
        if y[te].sum() == 0 or y[tr].sum() == 0:
            continue
        _, oof_b[te] = _fit_predict(Xb[tr], y[tr], Xb[te], params, seed)
        m_w, oof_w[te] = _fit_predict(Xw[tr], y[tr], Xw[te], params, seed)
        ap_b, ap_w = weighted_ap(y[te], oof_b[te]), weighted_ap(y[te], oof_w[te])
        per_fold.append({"fold": f, "rows": int(te.sum()), "frauds": int(y[te].sum()),
                         "ap_base": ap_b, "ap_with": ap_w, "delta": ap_w - ap_b})
        if permute:  # family permuted jointly (rows shuffled together) on the held-out fold
            Xp = Xw[te].copy()
            idx = rng.permutation(len(Xp))
            for c in family_cols:
                Xp[c] = Xp[c].to_numpy()[idx]
                if c in cat_cols:
                    Xp[c] = pd.Categorical(Xp[c], categories=Xw[c].cat.categories)
            perm.append(ap_w - weighted_ap(y[te], m_w.predict_proba(Xp)[:, 1]))
    ok = ~np.isnan(oof_b)
    pooled_b, pooled_w = weighted_ap(y[ok], oof_b[ok]), weighted_ap(y[ok], oof_w[ok])
    ci, se = bootstrap_delta(y[ok], oof_b[ok], oof_w[ok], acc[ok], n_boot, seed)
    month = pd.to_datetime(df[time]).dt.to_period("M").astype(str).to_numpy()
    by_month = []
    for mth in sorted(set(month[ok])):
        m = ok & (month == mth)
        if y[m].sum() == 0:
            continue
        by_month.append({"month": mth, "rows": int(m.sum()), "frauds": int(y[m].sum()),
                         "ap_base": weighted_ap(y[m], oof_b[m]), "ap_with": weighted_ap(y[m], oof_w[m])})
        by_month[-1]["delta"] = by_month[-1]["ap_with"] - by_month[-1]["ap_base"]
    groups = []
    if by_group is not None:
        gv = df[by_group].astype(object).fillna("<missing>").astype(str).to_numpy()
        for v in sorted(set(gv[ok])):
            m = ok & (gv == v)
            if y[m].sum() == 0:
                continue
            groups.append({"group": v, "rows": int(m.sum()), "frauds": int(y[m].sum()),
                           "delta": weighted_ap(y[m], oof_w[m]) - weighted_ap(y[m], oof_b[m])})
    big = [r for r in by_month if r["frauds"] >= min_month_frauds]
    folds_pos = sum(r["delta"] > 0 for r in per_fold)
    months_ok = (not big) or (sum(r["delta"] > 0 for r in big) >= (2 / 3) * len(big))
    passed = bool(ci[0] > 0 and folds_pos >= len(per_fold) - 1 and months_ok)
    return {"family": list(family_cols), "base": list(base_cols), "k": k, "seed": seed, "params": params,
            "train_neg_rate": train_neg_rate,
            "rows": int(ok.sum()), "frauds": int(y[ok].sum()), "accounts": int(len(set(acc[ok]))),
            "pooled_ap_base": pooled_b, "pooled_ap_with": pooled_w, "pooled_delta": pooled_w - pooled_b,
            "delta_ci95_account_bootstrap": ci, "delta_bootstrap_se": se, "n_boot": n_boot,
            "per_fold": per_fold, "folds_positive": folds_pos, "by_month": by_month,
            "months_rule_ok": bool(months_ok), "by_group": {"column": by_group, "rows": groups},
            "permutation_ap_drop_mean": float(np.mean(perm)) if perm else None,
            "pass_rule": PASS_RULE, "passed": passed}


def base_refit_aps(df, base_cols, cat_cols=(), label="frd_tag", account="Nmap_account_reference_xid", k=5,
                   seed=42, model_seeds=(43, 44), params=None, train_neg_rate=1.0):
    """Pooled out-of-fold AP of the base arm refitted with other XGBoost seeds, on the same folds and the
    same training rows as `run_screen(seed=seed)`. Only the model's random state changes."""
    params = {**DEFAULT_PARAMS, **(params or {})}
    y = (pd.to_numeric(df[label], errors="coerce").to_numpy() == 1).astype(int)
    fold = account_folds(df[account].astype(str).to_numpy(), k)
    keep_neg = np.random.default_rng(seed + 1).random(len(df))
    Xb = _design(df, list(base_cols), set(cat_cols))
    out = {}
    for ms in model_seeds:
        oof = np.full(len(df), np.nan)
        for f in range(k):
            te = fold == f
            tr = ~te & ((y == 1) | (keep_neg < train_neg_rate))
            if y[te].sum() == 0 or y[tr].sum() == 0:
                continue
            _, oof[te] = _fit_predict(Xb[tr], y[tr], Xb[te], params, ms)
        ok = ~np.isnan(oof)
        out[int(ms)] = weighted_ap(y[ok], oof[ok])
    return out


FINAL_RULE = ("PASS_RULE with its threshold raised from 0 to the noise floor: the 95% interval's lower end must "
              "exceed max(0, floor), floor = the larger of |null_noise pooled delta| and the largest pairwise "
              "difference in pooled base-arm AP across XGBoost seeds (refit spread)")


def noise_floor(null_result, base_aps):
    """The floor of FINAL_RULE from the null family's result and the base arm's AP per model seed."""
    aps = list(base_aps.values())
    spread = max((abs(a - b) for i, a in enumerate(aps) for b in aps[i + 1:]), default=0.0)
    return {"null_abs_delta": abs(null_result["pooled_delta"]), "refit_spread": spread,
            "floor": max(0.0, abs(null_result["pooled_delta"]), spread)}


def final_decision(result, floor):
    """True when the family passes PASS_RULE and its interval clears the floor."""
    return bool(result.get("passed") and result["delta_ci95_account_bootstrap"][0] > floor)


# ---------------------------------------------------------------------------------------------------
# Per-feature ranking (added in the re-delivery). XGBoost's view, not the transformer's.
# ---------------------------------------------------------------------------------------------------

def _fit_predict_sklearn(X_tr, y_tr, X_te, params, seed):
    """Dry-run stand-in when xgboost is missing: scikit-learn's HistGradientBoostingClassifier.
    Not used for any real screen; it gives no SHAP values."""
    from sklearn.ensemble import HistGradientBoostingClassifier
    m = HistGradientBoostingClassifier(max_iter=int(params.get("n_estimators", 100)),
                                       max_depth=params.get("max_depth"),
                                       learning_rate=float(params.get("learning_rate", 0.1)),
                                       categorical_features="from_dtype", random_state=seed)
    m.fit(X_tr, y_tr)
    return m, m.predict_proba(X_te)[:, 1]


def use_sklearn_fallback():
    """Rebind the fit function of this module (and every module that calls it through this module)."""
    global _fit_predict
    _fit_predict = _fit_predict_sklearn
    MODEL["name"] = "sklearn HistGradientBoostingClassifier (dry run only, no SHAP)"


def xgboost_available():
    try:
        import xgboost  # noqa: F401
        return True
    except ImportError:
        return False


def shap_per_feature(model, X):
    """XGBoost's built-in SHAP contributions on X: booster.predict(DMatrix(X, enable_categorical=True),
    pred_contribs=True). Returns (sum over rows of |contribution| per column, rows). The bias column
    (the last one) is dropped. None when the model is not an XGBoost model."""
    if not hasattr(model, "get_booster"):
        return None, 0
    import xgboost as xgb
    contribs = model.get_booster().predict(xgb.DMatrix(X, enable_categorical=True), pred_contribs=True)
    contribs = np.asarray(contribs)[:, : X.shape[1]]
    return dict(zip(X.columns, np.abs(contribs).sum(axis=0).astype(float).tolist())), int(X.shape[0])


def _permuted(X, cols, idx, cat_cols, categories):
    Xp = X.copy()
    for c in cols:
        Xp[c] = Xp[c].to_numpy()[idx]
        if c in cat_cols:
            Xp[c] = pd.Categorical(Xp[c], categories=categories[c])
    return Xp


def feature_rank(df, base_cols, new_cols, cat_cols=(), clusters=None, label="frd_tag",
                 account="Nmap_account_reference_xid", k=5, seed=42, params=None, train_neg_rate=1.0,
                 shap_rows=200_000, perm_repeats=1, rank_cols=None):
    """Per-feature ranking on the arm base + new fields, on the same folds and training rows as run_screen.

    For each held-out fold:
    - SHAP: on a fixed sample of at most `shap_rows` held-out rows (seeded), the sum of absolute
      contributions per feature; summed over folds and divided by the rows used (mean over rows).
    - permutation: each column of `rank_cols` (default: every column of the arm) shuffled alone across
      the held-out rows, and each cluster in `clusters` ({cluster_id: [columns]}, two or more columns
      in the arm) shuffled jointly with one shared row order, so twins do not hide each other. The AP
      drop is AP(held-out) - AP(permuted); `perm_repeats` shuffles per fold, averaged.
    Returns a JSON-ready dict. XGBoost's view, not the transformer's."""
    params = {**DEFAULT_PARAMS, **(params or {})}
    cat_cols = set(cat_cols)
    cols = list(base_cols) + [c for c in new_cols if c not in base_cols]
    rank_cols = list(cols if rank_cols is None else rank_cols)
    clusters = {str(cid): [c for c in m if c in cols] for cid, m in (clusters or {}).items()}
    clusters = {cid: m for cid, m in clusters.items() if len(m) >= 2}
    y = (pd.to_numeric(df[label], errors="coerce").to_numpy() == 1).astype(int)
    acc = df[account].astype(str).to_numpy()
    fold = account_folds(acc, k)
    keep_neg = np.random.default_rng(seed + 1).random(len(df))
    X = _design(df, cols, cat_cols)
    categories = {c: X[c].cat.categories for c in cols if c in cat_cols}
    rng = np.random.default_rng(seed + 11)
    shap_sum = {c: 0.0 for c in cols}
    shap_n = 0
    perm = {c: [] for c in rank_cols}
    perm_cl = {cid: [] for cid in clusters}
    folds = []
    for f in range(k):
        te = fold == f
        tr = ~te & ((y == 1) | (keep_neg < train_neg_rate))
        if y[te].sum() == 0 or y[tr].sum() == 0:
            continue
        Xte, yte = X[te], y[te]
        m, p = _fit_predict(X[tr], y[tr], Xte, params, seed)
        ap = weighted_ap(yte, p)
        folds.append({"fold": f, "rows": int(te.sum()), "frauds": int(yte.sum()), "ap": ap})
        n_s = min(int(shap_rows), len(Xte))
        pick = np.sort(np.random.default_rng(seed + 100 + f).choice(len(Xte), n_s, replace=False))
        s, n = shap_per_feature(m, Xte.iloc[pick])
        if s is not None:
            for c, v in s.items():
                shap_sum[c] += v
            shap_n += n
        for _ in range(int(perm_repeats)):
            for c in rank_cols:
                idx = rng.permutation(len(Xte))
                perm[c].append(ap - weighted_ap(yte, m.predict_proba(_permuted(Xte, [c], idx, cat_cols, categories))[:, 1]))
            for cid, members in clusters.items():
                idx = rng.permutation(len(Xte))
                perm_cl[cid].append(ap - weighted_ap(yte, m.predict_proba(
                    _permuted(Xte, members, idx, cat_cols, categories))[:, 1]))

    def stats(v):
        return {"ap_drop_mean": float(np.mean(v)) if v else None,
                "ap_drop_sd": float(np.std(v, ddof=1)) if len(v) > 1 else None, "n": len(v)}

    return {"view": VIEW, "model": MODEL["name"], "columns": cols, "k": k, "seed": seed, "params": params,
            "train_neg_rate": train_neg_rate, "folds": folds, "perm_repeats": int(perm_repeats),
            "shap": ({"rows": shap_n, "sum_abs": shap_sum,
                      "mean_abs": {c: v / shap_n for c, v in shap_sum.items()}} if shap_n else None),
            "permutation": {c: stats(v) for c, v in perm.items()},
            "cluster_permutation": {cid: {"members": clusters[cid], **stats(v)} for cid, v in perm_cl.items()}}
