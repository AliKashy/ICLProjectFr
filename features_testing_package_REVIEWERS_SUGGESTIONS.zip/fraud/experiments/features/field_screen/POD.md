# CPU field screen: run sheet for the pod

CPU only. It may run while the GPU is busy. It writes only under `checkpoints/new_fields/screen/` and reads no S3 file it is not given. Copilot adapts paths only, never the code's logic.

## Before

1. The field checks have run: `checkpoints/new_fields/checks/field_status.csv` exists.
2. The tests pass: `CUDA_VISIBLE_DEVICES= PYTHONPATH=src:. $PY -m pytest -q -p no:cacheprovider tests/experiments/features/field_screen`.
3. The dry run works: `CUDA_VISIBLE_DEVICES= $PY fraud/experiments/features/field_screen/fsc_run.py --dry-run`. It prints `layout:` and the one-screen summary.

## The command

```
CUDA_VISIBLE_DEVICES= nice -n 19 $PY fraud/experiments/features/field_screen/fsc_run.py \
  --map fraud/experiments/features/new_fields/FIELD_MAP.csv \
  --status checkpoints/new_fields/checks/field_status.csv \
  --clusters checkpoints/new_fields/checks/clusters.csv \
  --base s3://mrmcd-analytics-mrm-mmr-dsai/tfm_raw_data --start 1 --end 10 --cred-path <credentials file> \
  --extract-start 2024-10-01 --train-neg-rate 0.1 --temporal-split 2025-04-01 \
  --k 5 --n-boot 500 --seed 42 --extra-seeds 43 44 \
  --drift-base s3://mrmcd-analytics-mrm-mmr-dsai/tfm_EVAL_raw_data --drift-start 8228 --drift-end 8243 \
  --drift-extract-start 2025-05-01 --drift-month 2025-06 --out checkpoints/new_fields/screen
```

- If the engineered fields are in enriched copies, point `--base` and `--drift-base` at those copies. The screen then reads the columns as they are.
- The June drift check reads RANK-A files 8228-8243 (June rows), and never reads `frd_tag` there. It is a label-free check, not a read. Test 1 stays report-only. If RANK-A cannot be read, Test 1 files 8000-8010 may be used the same way, label-free; say so on the photograph.
- The cost guard times one fit first and prints the projected hours. It stops above `--max-hours` (default 6) with exit code 4. `--train-neg-rate 0.1` is the recommended first run.
- `--clusters` takes the field checks' `clusters.csv` as it is written. A missing or unreadable file stops the screen before any read (exit 2).
- The memory guard reads the parquet footers first. Free memory is the container's (cgroup) or the host's, whichever is smaller, in GiB. It refuses (exit 4) below the field checks' free-memory level (`CHECK_THRESHOLDS.yaml` `min_free_host_gb`, 32 GiB), or when the projected peak is above 80% of free memory. The projection holds the training read, the fits and the June read, and every part is printed.
- `--nthread` sets the CPU threads (default half the CPUs the container may use), so a GPU job's data loading keeps its share.
- If `--drift-month` has no rows in the drift files, the screen stops before any read (exit 2): check the month and the file range.
- The map is refused before any read (exit 2) when two rows share a name, or a row is named like a base input (letter case ignored), also when the field checks STOP that row. The screen prints the rows; Copilot shows them to the owner and does not rename on its own. The owner renames or removes them in the map. After a rename, the field checks run again, so the new name has a result, and then the screen.
- With `--history-lite`, a field named like a history-lite column (`lag1_amt` to `lag5_type`) is left out with its reason. With `--oct26`, so is a field named like a requested 26 October column, unless it is that very column (`a3(<its name>)`).
- `--oct26 velocity_E01_C5 drain_24h` adds 26 October families by name, if the owner wants them read here.

## Exit codes

0 done; 2 a wrong argument (a missing input file, a bad clusters file, an unknown family, a drift month with no rows, two map rows with one name, or a map row named like a base input); 4 refused (no field status, xgboost missing outside the dry run, the memory guard, or the cost guard).

## What the owner photographs

The summary screen (`checkpoints/new_fields/screen/summary.txt`, 40 lines at most).

## How to read it

- It decides nothing. It ranks families and fields in XGBoost's view, not the transformer's.
- A family marked leaky failed the label shuffle, or holds a field that failed future invariance. `?` means a member could not be shown either way: its recipe could not be rebuilt, or the stored column differs from its recipe.
- The `note` column of `feature_rank.csv` holds every flag of a field. The per-feature summary of the field checks reads it, and any note makes the draft verdict `review`.
- A field left out with `source_stop:<source> <rule>` reads a column that the field checks STOP or WAIT. Its own result may say PASS; the screen does not rank it. The per-feature summary drafts it `review`.
- June drift: a field is flagged only when its PSI is above its own cut, printed per field (the `cut` column): the larger of 0.25 and the 95th percentile of PSI between samples of whole reference accounts, at the reference's account count and the June row count. The reference is the last training month when it is a whole month (the training rows reach its last day) with 100 rows (`--drift-min-rows`); else the month before it, else the whole training stream. The summary prints the reference and its rows; a `not used:` line names a month passed over and why (partial, or too few rows).
- `w/o` is the field's rank when the screen is run again without the flagged fields (too good alone, leaky, stored differs). Read it when a label echo or a look-ahead tops the table.
- `final_pass` is `PASS_RULE` with its bar raised to the noise floor.
- Read time-split numbers for claims about later periods. The account-fold screen is not chronological.
- Month on top: "month adds nothing shown on the time split" is one input to the owner's month question. Nothing is removed.
- The per-field table is `feature_rank.csv`. The per-feature summary of the field checks joins it on `feature`.
