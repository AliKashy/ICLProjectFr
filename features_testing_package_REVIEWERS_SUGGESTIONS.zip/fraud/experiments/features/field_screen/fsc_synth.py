"""Synthetic worlds for the re-delivered CPU screen: tests and the one-command dry run only. Not bank data.

make: the old screen's synthetic accounts (copied unchanged from fraud/experiments/features/screen/synth.py;
    before the reorganization waqas/v2/screen/synth.py), with a known balance and limit mechanism and planted
    takeovers. Used by the ported tests.
world: a tiny screen world on disk: training parquet files (each account in one file), one June evaluation
    file, a field map in the field map's columns and a field status file. It plants a useful code, a useless
    number, two honest engineered fields, a look-ahead field (a planted defect) and a stopped field.
synth_builder: a small recipe stand-in for the synthetic world only (count over a window, previous value,
    and the planted look-ahead). The real recipes come from the new-fields recipe module.
"""

import re
from pathlib import Path

import numpy as np
import pandas as pd

CATS = {"transaction_type_xcd": ["TRA1", "TRA2", "TRA3"], "cardholder_present_xflg": ["CAR0", "CAR1"],
        "merchant_category_xcd": [f"M{i}" for i in range(30)]}


def make(n_accounts=400, days=150, start="2024-10-01", semantics="before", fraud_share=0.15, seed=0,
         daily_cap=5000.0, drain_signal=True):
    rng = np.random.default_rng(seed)
    t0 = pd.Timestamp(start)
    rows = []
    for a in range(n_accounts):
        acct = f"A{a:05d}"
        bal = float(rng.lognormal(7.0, 1.0))
        rate = rng.uniform(0.5, 4.0)  # transactions per day
        n = rng.poisson(rate * days)
        ts = np.sort(rng.uniform(0, days * 86400, n)).round()
        usual = rng.choice(CATS["merchant_category_xcd"], 4, replace=False)
        fraud_at = rng.uniform(20, days - 5) * 86400 if rng.random() < fraud_share else None
        if fraud_at is not None:
            burst = fraud_at + np.cumsum(rng.uniform(60, 900, rng.integers(2, 6)))
            ts = np.sort(np.r_[ts, burst])
            burst_set = set(burst.tolist())
        else:
            burst_set = set()
        spent_day, cur_day = 0.0, -1
        for s in ts:
            day = int(s // 86400)
            if day != cur_day:
                cur_day, spent_day = day, 0.0
                bal += float(rng.lognormal(6.0, 0.8)) * (rng.random() < 0.15)  # occasional deposit
            lim = daily_cap - spent_day
            fraud = s in burst_set
            if fraud and drain_signal:
                x = round(max(bal, 20.0) * rng.uniform(0.6, 1.0), 2)
                mcc = rng.choice(CATS["merchant_category_xcd"])
                cp = "CAR0"
            else:
                x = round(float(rng.lognormal(3.2, 0.9)), 2)
                mcc = rng.choice(usual)
                cp = rng.choice(["CAR0", "CAR1"], p=[0.3, 0.7])
            approved = x <= bal and x <= lim
            if semantics == "before":
                b_st, l_st = bal, lim
            elif semantics == "after":
                b_st, l_st = (bal - x, lim - x) if approved else (bal, lim)
            else:
                raise ValueError(semantics)
            rows.append({"Nmap_account_reference_xid": acct, "transaction_dttm": t0 + pd.Timedelta(seconds=s),
                         "transaction_amt": x, "total_available_balance_amt": round(b_st, 2),
                         "remain_day_merchandise_lmt_amt": round(l_st, 2),
                         "available_daily_cash_limit_amt": np.nan,
                         "transaction_type_xcd": rng.choice(CATS["transaction_type_xcd"]),
                         "cardholder_present_xflg": cp, "merchant_category_xcd": mcc,
                         "external_1_scr": float(rng.integers(0, 100)), "frd_tag": int(fraud)})
            if approved:
                bal -= x
                spent_day += x
    df = pd.DataFrame(rows)
    df["fi_transaction_id"] = [f"T{i:08d}" for i in range(len(df))]
    return df


# ---------------------------------------------------------------------------------------------------
# The screen's synthetic world (added in the re-delivery)
# ---------------------------------------------------------------------------------------------------

ACCOUNT, TIME, TIE, LABEL = "Nmap_account_reference_xid", "transaction_dttm", "fi_transaction_id", "frd_tag"
BASE_NUM = ["transaction_amt", "external_1_scr", "avlble_merch_day_cash_lmt_amt", "available_daily_cash_limit_amt",
            "remain_day_merchandise_lmt_amt", "total_available_balance_amt"]
BASE_CAT = ["transaction_type_xcd", "segment", "transaction_category_xcd", "transaction_pos_condition_xcd",
            "avs_request_xcd", "pos_security_xflg", "transaction_pin_verify_xcd", "cardholder_present_xflg",
            "pos_card_capture_xflg", "cvv_verify_xcd", "authzn_rqst_crypto_valid_xflg", "pos_off_premises_xflg",
            "pos_terminal_attend_xflg"]

# The planted fields of the synthetic world: (name, group, kind, recipe, source_columns, model_type, status).
PLANTED = [
    ("syn_useful_code", "v22b", "raw", "raw", "syn_useful_code", "categorical", "PASS"),
    ("syn_useless_num", "v22b", "raw", "raw", "syn_useless_num", "continuous", "PASS"),
    ("syn_profile_num", "both", "raw", "raw", "syn_profile_num", "continuous", "FLAG"),
    ("syn_cnt_24h", "f15298", "engineered", "count(24h)", "transaction_dttm", "continuous", "PASS"),
    ("syn_prev_amt", "f15298", "engineered", "prev(transaction_amt)", "transaction_amt", "continuous", "PASS"),
    ("syn_lookahead_amt", "f15298", "engineered", "lookahead(transaction_amt)", "transaction_amt", "continuous",
     "PASS"),
    ("syn_stopped_copy", "f15298", "raw", "raw", "syn_stopped_copy", "continuous", "STOP"),
]


def _accounts(rng, n_accounts, start, days, fraud_share, first_id):
    t0 = pd.Timestamp(start)
    parts = []
    for a in range(n_accounts):
        n = max(3, int(rng.integers(20, 60) * days / 210))  # the same rate per day in every world
        ts = np.sort(rng.uniform(0, days * 86400, n)).round()
        fraud = np.zeros(n, dtype=int)
        if rng.random() < fraud_share:  # a takeover burst: several rows within an hour, labelled fraud
            at = rng.uniform(5, days - 2) * 86400
            burst = at + np.cumsum(rng.uniform(60, 600, int(rng.integers(3, 6))))
            ts = np.r_[ts, burst]
            fraud = np.r_[fraud, np.ones(len(burst), dtype=int)]
            o = np.argsort(ts, kind="mergesort")
            ts, fraud = ts[o], fraud[o]
        parts.append(pd.DataFrame({ACCOUNT: f"S{first_id + a:06d}", TIME: t0 + pd.to_timedelta(ts, unit="s"),
                                   LABEL: fraud}))
    df = pd.concat(parts, ignore_index=True)
    n = len(df)
    y = df[LABEL].to_numpy()
    amt = np.round(np.exp(rng.normal(3.2, 0.9, n)) * np.where(y == 1, 3.0, 1.0), 2)
    df["transaction_amt"] = amt
    df["external_1_scr"] = np.clip(rng.normal(40, 20, n) + 15 * y, 0, 99).round()
    for c in BASE_NUM[2:]:
        df[c] = np.round(np.exp(rng.normal(6, 1, n)), 2)
    for i, c in enumerate(BASE_CAT):
        df[c] = rng.choice([f"{c[:3].upper()}{j}" for j in range(3 + i % 4)], n)
    df["cardholder_present_xflg"] = np.where(y == 1, "CAR0", rng.choice(["CAR0", "CAR1"], n, p=[0.3, 0.7]))
    # planted raw fields: a useful code, a useless number, a weakly useful profile number, a label copy (stopped)
    df["syn_useful_code"] = np.where(rng.random(n) < np.where(y == 1, 0.7, 0.03), "R",
                                     rng.choice(["A", "B", "C", "D"], n))
    df["syn_useless_num"] = rng.normal(0, 1, n)
    df["syn_profile_num"] = rng.normal(0, 1, n) + 0.3 * y
    df["syn_stopped_copy"] = y + rng.normal(0, 0.01, n)
    return df


def world(folder, n_accounts=360, n_files=2, june_accounts=120, seed=0, fraud_share=0.25, field_map_columns=None):
    """Write the synthetic world under `folder`; return its paths. Training: 1 October 2024 for 210 days, each
    account in one file. Evaluation: 1 May 2025 to 30 June 2025 (the June drift check reads it without labels)."""
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    tr = _accounts(rng, n_accounts, "2024-10-01", 210, fraud_share, 0)
    ev = _accounts(rng, june_accounts, "2025-05-01", 61, fraud_share, n_accounts)
    ev["syn_useless_num"] = ev["syn_useless_num"] * 3 + 2  # a planted June drift
    files = []
    acc_ids = sorted(tr[ACCOUNT].unique())
    for i in range(n_files):
        part = tr[tr[ACCOUNT].isin(acc_ids[i::n_files])].copy()
        part[TIE] = [f"T{i}{j:08d}" for j in range(len(part))]
        p = folder / f"part_{i + 1}.parquet"
        part.reset_index(drop=True).to_parquet(p)
        files.append(str(p))
    ev[TIE] = [f"E{j:08d}" for j in range(len(ev))]
    june = folder / "part_8000.parquet"
    ev.to_parquet(june)
    cols = list(field_map_columns or ["name", "group", "kind", "recipe", "source_columns", "model_type"])
    rows = []
    for name, group, kind, recipe, src, mtype, _ in PLANTED:
        r = {c: "" for c in cols}
        r.update({"name": name, "group": group, "kind": kind, "recipe": recipe, "source_columns": src,
                  "model_type": mtype, "definition_version": "1", "excluded_by_sumegha": "no",
                  "feasible_in_production": "yes", "list_status": "UNCONFIRMED"})
        rows.append({c: r.get(c, "") for c in cols})
    fmap = folder / "FIELD_MAP.csv"
    pd.DataFrame(rows, columns=cols).to_csv(fmap, index=False)
    status = folder / "field_status.csv"
    pd.DataFrame([{"field": n, "result": s, "reasons": "synthetic" if s == "PASS" else f"synthetic {s.lower()}"}
                  for n, *_, s in PLANTED]).to_csv(status, index=False)
    return {"files": files, "june": [str(june)], "map": str(fmap), "status": str(status),
            "extract_start": "2024-10-01", "june_extract_start": "2025-05-01", "temporal_split": "2025-02-15"}


_WINDOW = re.compile(r"^(\d+)([smhd])$")
_UNIT = {"s": 1, "m": 60, "h": 3600, "d": 86400}


def _keys(df):
    acc = pd.factorize(df[ACCOUNT].astype(str))[0].astype(np.int64)
    t = pd.to_datetime(df[TIME]).to_numpy(dtype="datetime64[ns]").astype("datetime64[s]").astype(np.int64)
    return acc, t


def synth_builder(df, recipe, extract_start, model_type=None):
    """Synthetic-world recipes only: count(<n><unit>), prev(c), and the planted defect lookahead(c).
    Strictly earlier rows of the same account, whole seconds; a window that reaches before the extract
    start is censored (missing)."""
    acc, t = _keys(df)
    key = acc * 10**11 + (t - t.min())
    o = np.argsort(key, kind="mergesort")
    ks = key[o]
    first = np.searchsorted(ks, key, side="left")  # first row of this second: rows before it are strictly earlier
    m = re.match(r"^(\w+)\((.*)\)$", recipe.strip())
    if not m:
        raise ValueError(f"synthetic builder: unknown recipe {recipe!r}")
    fn, arg = m.group(1), m.group(2).strip()
    xs = pd.Timestamp(extract_start).value // 10**9 - t.min()
    rel = t - t.min()
    if fn == "count":
        w = _WINDOW.match(arg)
        secs = int(w.group(1)) * _UNIT[w.group(2)]
        lo = np.searchsorted(ks, key - secs, side="left")
        v = (first - lo).astype(float)
        v[rel - secs < xs] = np.nan
        return pd.Series(v, index=df.index)
    if fn in ("prev", "lookahead"):
        vals = pd.to_numeric(df[arg], errors="coerce").to_numpy(dtype=float)[o]
        acc_s = acc[o]
        if fn == "prev":
            j = first - 1
        else:  # the planted defect: the next row's value (look-ahead)
            pos = np.empty(len(o), dtype=np.int64)
            pos[o] = np.arange(len(o))
            j = pos + 1
        ok = (j >= 0) & (j < len(o))
        js = np.where(ok, j, 0)
        ok &= acc_s[js] == acc
        return pd.Series(np.where(ok, vals[js], np.nan), index=df.index)
    raise ValueError(f"synthetic builder: unknown recipe {recipe!r}")
