# CPU field screen (re-delivered)

The CPU screen of `fraud/experiments/features/screen/`, re-delivered for the new fields. It is driven by the field map, takes the engineered fields as columns, and ranks families and fields. It decides nothing. XGBoost has no history window, so every number here is **XGBoost's view, not the transformer's**. Adoption is decided only by the transformer fits. The old folder stays as it is, as the record.

| File | What it is |
|---|---|
| `fsc_run.py` | The command. It reads the map, the field status and the files, then runs the probes, the noise floor, the family screens, month on top, the ranking and June drift. It writes the outputs. |
| `fsc_usefulness.py` | The paired XGBoost screen, copied unchanged (`run_screen`, the bootstrap, `PASS_RULE`, `FINAL_RULE`, the noise floor). Added: `shap_per_feature`, `feature_rank`, and the dry-run fallback. |
| `fsc_probes.py` | `future_invariance`, `single_feature_ap` and `label_shuffle`, copied unchanged (the runner passes each recipe's history key as the probe's `account`). |
| `fsc_stability.py` | `temporal_screen` (the chronological screen), `psi`, `feature_drift` and `history_lite`, copied unchanged. |
| `fsc_synth.py` | Synthetic worlds for the tests and the dry run. Not bank data. |
| `POD.md` | How to run it on the pod. |

## Inputs

- `--map`: the field map. One row per new field. The screen reads `name`, `group`, `kind`, `recipe`, `source_columns`, `model_type`, `excluded_by_sumegha`, `left_out_reason`, `cluster_id` and `list_status`.
- `--status`: the field checks' `field_status.csv` (`field`, `result`, `reasons`). Only PASS and FLAG fields enter. A map row that is not in the file is "not checked" and is left out: the map's own `check_result`, which may be stale, is not used for it. Without `--status`, the map's `check_result` column is used; if that is blank too, the screen refuses unless `--allow-unchecked` (the screen then says UNCHECKED).
- `--clusters`: the field checks' `clusters.csv` (`cluster_id`, `member`, `member_kind`, `size`, `max_link`, `result`). Base members are kept, because the ranking arm holds the base inputs too. Without it, the field status file's `cluster_id` is used, else the map's. A file without `cluster_id` and a member column is refused (exit 2) before any read.
- The base arm: the predictor list (`fraud/configs/predictors.csv`, the 23 inputs, month in). Calendar fields come from the model's own `datetime_features`.
- Families: `tfm` (groups `v22b` and `both`), `f15298`, `a3` and `all_new`. The 26 October families can be named with `--oct26`.
- Engineered fields: a column of the same name in the files (enriched copies) is used as it is. Otherwise the field is built from its recipe on whole account histories, before any target sampling, through `new_fields/nf_recipes.py` (`build_columns`, the same code the enriched copies use). Recipes are built file by file, every recipe of a file in one call, as the enriched copies are. Without that module only `raw`, `code(c)` and `a3(col)` are built. A field that cannot be built is listed as not built, never guessed. A `code(c)` or `geohash(postal; country)` row with a blank `model_type` is a category, as the recipe module builds it. The screen reads the map's `source_columns` and every column the recipe module needs to build a recipe: for `a3(col)`, every input of the 26 October builders, which the module needs in the file for any a3 output.
- A stored column whose recipe can be rebuilt is compared with the rebuilt values on the training rows (exact, missing equals missing only). A difference is written as "stored differs from recipe (n rows)" and the family's leak column shows `?`.
- Refused before any read (exit 2), with the rows named: two map rows that share a name (a second row would overwrite the first), and a map row named like a base input or a derived calendar field, letter case ignored (`Transaction_Amt` is `transaction_amt`). The base arm holds that input already, and every table of the screen and the per-feature summary is keyed by name, so such a row could not be told apart from the base input. This holds for a row the field checks STOP too. The owner renames or removes those rows in the map; after a rename the field checks run again, so the new name has a result.
- Left out with its reason, before any read: a map row named like the label, the account, the time, the tie or the order column, `null_noise`, `time_delta` or a `_isna` name. With `--history-lite`, a history-lite column's name too (`lag1_amt` to `lag5_type`). With `--oct26`, a requested 26 October column's name too, unless the row is that very column (recipe `a3(<its name>)`), which gives the same values.
- An engineered field is left out when a column it reads is STOP or WAIT in the field checks, whatever its own result says (the status file may be stale, or the rule one the checks do not pass on). Its reason and its `note` are `source_stop:<source> <rule>`. The columns it reads are the map's `source_columns` and its recipe's own columns (`nf_recipes.parse`; for `a3(col)`, the map's columns only). Two kinds of rule keep the source's values in use, so they do not carry: a twin kept once under another name (`duplicate`, `duplicate_number`, `function_of`), and a raw date (`raw_date`), which enters only through `days_before` or `days_until`, as the recipe does.

## What it measures

1. Future invariance on every field with a history recipe. Values are rebuilt from the recipe (never taken from a stored column) on a frame whose rows after a cutoff are changed or deleted. The cutoff is drawn per value of the recipe's own history key: the account, or the customer or card the recipe names with `key=` (one probe per key; `screen.json` `cut_by` lists the fields of each). Every recipe's source columns are perturbed, never a history key. A field whose earlier values move is leaky. A stored field whose recipe cannot be rebuilt is "not run" with the reason (no recipe module, or a recipe outside the grammar), and its family's leak column shows `?`. So does a stored field that differs from its own recipe.
2. The noise floor first: the `null_noise` family and the base arm at XGBoost seeds 43 and 44.
3. Per family: the paired account-fold screen, `PASS_RULE`, `FINAL_RULE`, single-field AP, the label shuffle, and the time-split screen. The time split runs by default at 2025-04-01 (the design's date); `--temporal-split none` switches it off, and the summary then says so.
4. Month on top: base plus all new fields, with and without month, on account folds and on the time split. Account folds see every month in training and overstate month. Read the time split. Month "still adds" only when the time-split interval's lower end clears the noise floor (the bar of `FINAL_RULE`).
5. The per-feature ranking on the `all_new` arm: SHAP (`pred_contribs=True`, the absolute contribution summed per feature, divided by the rows used) on at most 200,000 held-out rows per fold, and permutation AP drops per feature and per cluster on the held-out folds. When a field is flagged (future invariance failed, a stored column that differs from its recipe, or too good alone), the ranking is also run without the flagged fields, because a label echo takes the credit of every other field. It runs only when the time left under `--max-hours` allows.
6. June drift: PSI between training rows and June rows of RANK-A (no labels read; a check, not a read). For history parity, a field whose recipe can be rebuilt is rebuilt on both sides by the same code: June from the evaluation extract start, and the last training month on training rows that start on the first day of the month before it. That frame holds no earlier row, so a recipe with no lookback limit (`within=all`) sees about the same history on both sides. Other fields are compared with the whole training stream, and their row says so. A field whose reference rebuild failed is named with the reference used. A `--drift-month` with no rows in the drift files is a wrong argument (exit 2, before any read); below `--drift-min-rows` (100) rows nothing is compared and nothing is flagged. The reference month must be a whole month (the training rows reach its last day) and hold `--drift-min-rows` rows too: else the month before it is the reference (rebuilt from the first day of the month before that), else the whole training stream. A partial month is never the reference: a recipe with no lookback limit sees less history on its last days than June rows do, so a few days of it against a whole June differ for the calendar alone. The summary prints the reference with its row count, and a `not used:` line names each month passed over and why (partial, too few rows); `screen.json` `reference_note` says it in full. A field is flagged only when its PSI is above its own cut: the larger of `--drift-threshold` (0.25) and the 95th percentile of PSI between two samples of whole accounts of its reference rows, drawn with replacement: one at the reference's account count, and one of accounts drawn until the June row count is reached (1,000 draws, seeded per field; rows of one account move together, so a June month of few accounts gets a wider cut; for codes the June sample also draws codes the reference never showed, at the share of codes it showed once). A many-level code with few June rows, or a small reference, is then not flagged for its sampling noise alone. The cut is printed per field.

Guards, before the screen:
- Memory (design review item 27). Free memory is the smaller of the host's `MemAvailable` and the container's cgroup headroom (limit minus working set, cgroup v2 or v1), in GiB, the field checks' unit. It refuses below `min_free_host_gb` (32) or when the projected peak is above 80% of free memory. The projection reads the parquet footers (rows and column types: 8 bytes per number, a measured width for text) and holds two stages, the fits and the June read at the end. Every part is printed.
- Threads. `--nthread` defaults to half the CPUs this container may use (the CPU affinity and the cgroup CPU quota).
- Cost. It times one fit of the widest arm, then projects the fits, the permuted predictions and every recipe build pass (the training build is measured and reused by the future-invariance probe; the perturbed pass, June and the June reference are projected).

Row permutation on a table is XGBoost's view only. The transformer reads overlapping history windows; its own importance comes from the importance tool, at the source-event level. The account-fold screen is not chronological. Use the time-split screen for claims about later periods. Weak tree importance does not rule out a history effect the transformer can learn. Correlated fields share credit, so read the cluster rows too.

## `feature_rank.csv`

One row per column of the ranking arm (base inputs and new fields), then one row per map field that was not built or was left out (`in_arm` = `no`, with the reason in `how_built`), so every map row has a row.

| Column | Meaning |
|---|---|
| `feature` | the model input name (the join key) |
| `group`, `kind`, `model_type`, `recipe` | from the map; base inputs show `base` and `base input` |
| `how_built` | `column in files` (with "equals its recipe" or "stored differs from recipe (n rows)" when the recipe was rebuilt), `raw source`, `built (<recipe source>)`, or why it was not built |
| `cluster_id` | the cluster from the field checks |
| `in_arm` | `yes` when the field was in the ranking arm |
| `note` | the screen's flags, joined with `; ` (blank when none): `future_invariance_failed`, `stored_differs_from_recipe rows=n`, `future_invariance_not_run`, `too_good_alone ap=x`, `family_leaky:<family> label_shuffle`, `drift_june psi=x cut=y`, `june_stored_differs_from_recipe rows=n`; `not_built`, `left_out_name_clash` and `source_stop:<source> <rule>` for rows outside the arm. The per-feature summary of the field checks reads it by name, and any note makes its draft `review` |
| `shap_mean_abs`, `shap_sum_abs`, `shap_rows` | SHAP: the sum over sampled held-out rows of the absolute contribution, that sum divided by the rows, and the rows |
| `shap_rank`, `shap_rank_new` | rank by `shap_mean_abs` among all arm columns, and among new fields only (1 = largest) |
| `perm_ap_drop_mean`, `perm_ap_drop_sd`, `perm_n` | the held-out AP minus the AP with this column shuffled; mean and standard deviation over folds and repeats |
| `perm_rank`, `perm_rank_new` | rank by `perm_ap_drop_mean`, all columns and new fields only |
| `cluster_perm_ap_drop`, `cluster_members` | the AP drop when the whole cluster is shuffled together |
| `single_feature_ap`, `single_feature_too_good` | the field alone (numbers only), and whether it reaches the base arm's AP |
| `future_invariance` | `ok`, `failed`, `stored differs from recipe (n rows)`, `not run (<reason>)`, or `not needed (raw value or code)` |
| `families`, `family_final_pass`, `family_leaky` | the families holding the field and their results; `family_leaky` is `True`, `False` or `?` (a member not shown either way) |
| `psi_june`, `missing_train`, `missing_june`, `drift_flag`, `drift_cut`, `drift_reference` | June drift: PSI, the missing shares, the flag (PSI above the cut), the field's cut, and the reference it was compared with |
| `unflagged_shap_mean_abs`, `unflagged_shap_rank_new`, `unflagged_perm_ap_drop_mean`, `unflagged_perm_rank_new` | the ranking run without the flagged fields (blank for a flagged field) |
| `view`, `model` | always "XGBoost's view, not the transformer's", and the model used |

`cluster_rank.csv` holds one row per cluster of two or more fields in the arm.

## Tests

`tests/experiments/features/field_screen/test_field_screen_*.py`. The dry run in one command: `python3 fraud/experiments/features/field_screen/fsc_run.py --dry-run`.
