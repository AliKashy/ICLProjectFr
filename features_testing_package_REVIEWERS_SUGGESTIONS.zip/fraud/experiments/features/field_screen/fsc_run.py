"""The CPU screen, re-delivered (usefulness layer 1). CPU only. It decides nothing.

Driven by the field map: the feature list comes in, nothing is hard-coded. The base arm is the predictor
list (fraud/configs/predictors.csv, the 23 inputs, month included). Families are the map's groups among
fields that passed the CPU field checks (PASS or FLAG): tfm (v22b and both), f15298, a3 and all_new.
Engineered fields are read as columns when the files hold them (enriched copies), else built from their
recipe by the new-fields recipe module. A stored column whose recipe can be rebuilt is compared with it. An
engineered field that reads a column the field checks STOP or WAIT is left out (source_stop). Before any read,
a map with two rows of one name, or a row named like a base input, is refused (exit 2), and a row named like a
reserved, history-lite (with --history-lite) or 26 October (with --oct26) column is left out.

It writes, under --out (default checkpoints/new_fields/screen):
- screen.json: every aggregate with full numbers (noise floor, families, probes, month on top, the
  chronological screen, June drift, the per-feature ranking, cost, memory);
- feature_rank.csv: one row per feature (read by the per-feature summary of the field checks);
- cluster_rank.csv: one row per cluster of two or more fields;
- summary.txt: one screen (40 lines of 90 characters), also printed.

Every ranking is XGBoost's view, not the transformer's. Row permutation here is the tree model's view only;
the account-fold screen is not chronological, so later-period claims use the time-split screen.

  CUDA_VISIBLE_DEVICES= nice -n 19 $PY fraud/experiments/features/field_screen/fsc_run.py --dry-run
"""

import argparse
import importlib.util
import json
import os
import platform
import re
import shutil
import sys
import tempfile
import time as _time
import zlib
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
NF_DIR = ROOT / "fraud" / "experiments" / "features" / "new_fields"

ACCOUNT, TIME, TIE, LABEL = "Nmap_account_reference_xid", "transaction_dttm", "fi_transaction_id", "frd_tag"
ENTER = ("PASS", "FLAG")
GROUP_FAMILY = {"v22b": "tfm", "both": "tfm", "f15298": "f15298", "a3": "a3"}
MAP_FAMILIES = ("tfm", "f15298", "a3", "all_new")
DRY_PARAMS = {"n_estimators": 40, "max_depth": 3}
DEFAULT_SPLIT = "2025-04-01"  # design 3.6: train before 1 April 2025, test after
OFF = ("none", "off", "")

# The 26 October families (copied from the old screen's run_screen.FAMILIES; available by name with --oct26).
OCT26_FAMILIES = {
    "capacity_E13": ["amt_over_balance", "amt_over_merch_lmt"],
    "capacity_E13_headroom": ["amt_over_balance", "amt_over_merch_lmt", "headroom_balance", "headroom_merch_lmt"],
    "drain_24h": ["drain_24h"],
    "velocity_E01_C5": ["cnt_5m_log1p", "cnt_1h_log1p", "cnt_24h_log1p", "cnt_7d_log1p", "cnt_30d_log1p",
                        "no_prior_30d", "obs_days_30"],
    "type_familiarity_E08": ["type_frac_30d", "type_support_30d"],
    "amount_midrank_E11": ["amt_midrank_30d", "amt_rank_support_30d"],
    "mcc_novelty": ["mcc_new_30d", "same_mcc_24h_log1p"],
}
OCT26_CATS = ["headroom_balance", "headroom_merch_lmt", "loc_prev_status"]
OCT26_RAW = ["merchant_category_xcd", "merchant_postal_xcd", "transaction_advice_xcd"]  # the old screen's EXTRA_RAW


def _by_path(name, path):
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(name, path)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[name] = mod
        spec.loader.exec_module(mod)
    return sys.modules[name]


def _bootstrap():
    for p in (str(ROOT / "src"), str(ROOT)):
        if p in sys.path:
            sys.path.remove(p)
        sys.path.insert(0, p)


def modules():
    """The shared new-fields modules and this folder's modules, all by path."""
    _bootstrap()
    lay = _by_path("nf_layout", NF_DIR / "nf_layout.py")
    com = _by_path("nf_common", NF_DIR / "nf_common.py")
    lay.bootstrap()
    return {"layout": lay, "common": com, "U": _by_path("fsc_usefulness", HERE / "fsc_usefulness.py"),
            "P": _by_path("fsc_probes", HERE / "fsc_probes.py"), "S": _by_path("fsc_stability", HERE / "fsc_stability.py")}


# ------------------------------------------------------------------------------------------- inputs

_INT_TEXT = re.compile(r"^(-?\d+)\.0+$")


def _code1(x):
    if x is None or (isinstance(x, float) and np.isnan(x)) or x is pd.NA or x is pd.NaT:
        return np.nan
    if isinstance(x, (bool, np.bool_)):
        return str(bool(x))
    if isinstance(x, (int, np.integer)):
        return str(int(x))
    if isinstance(x, (float, np.floating)):
        return str(int(x)) if float(x).is_integer() else repr(float(x))  # Python int: no int64 overflow
    t = str(x).strip()
    m = _INT_TEXT.match(t)
    return m.group(1) if m else t


def as_code(s):
    """Codes as text, missing kept missing. An integer code reads the same whether a file stored it as an int,
    as a float (a null in that file gives '1.0') or as text '1.0', so one file cannot split a code in two."""
    s = pd.Series(s)
    return pd.Series([_code1(x) for x in s.astype(object).to_numpy()], index=s.index, dtype=object)


def is_code_dtype(v):
    """A column read as codes when the map leaves model_type blank: text, pandas string, category or bool."""
    v = pd.Series(v)
    return (v.dtype == object or isinstance(v.dtype, pd.CategoricalDtype) or pd.api.types.is_string_dtype(v)
            or pd.api.types.is_bool_dtype(v))


def differing_rows(stored, rebuilt, mtype):
    """Rows where a stored column and its rebuilt recipe disagree. Missing equals missing only; numbers are
    compared with the future-invariance probe's tolerance (a file round trip may move the last digit)."""
    if mtype == "categorical":
        x, z = as_code(stored).to_numpy(), as_code(rebuilt).to_numpy()
        same = (x == z) | (pd.isna(x) & pd.isna(z))
    else:
        x = pd.to_numeric(pd.Series(stored), errors="coerce").to_numpy(dtype=float)
        z = pd.to_numeric(pd.Series(rebuilt), errors="coerce").to_numpy(dtype=float)
        same = np.isclose(x, z, rtol=1e-9, atol=1e-12, equal_nan=True)
    return int((~np.asarray(same, dtype=bool)).sum())


def base_inputs(predictors_csv, lay):
    """(raw continuous, raw categorical, derived calendar fields, derived source column) from the predictor list."""
    fl = lay.get("feature_list").load_feature_list(str(predictors_csv))
    derived = list(fl.derived)
    num = [c for c in fl.continuous if c not in derived]
    cat = [c for c in fl.categorical if c not in derived]
    return num, cat, derived, fl.order_col or TIME, [c for c in fl.continuous + fl.categorical]


def add_calendar(df, derived, order_col, lay):
    """The calendar fields as the model's own builder derives them (integer categories, -1 for missing)."""
    if not derived:
        return df
    dtf = lay.get("datetime_features")
    out, _, _ = dtf.derive_datetime_features(df[[order_col]], dtf.DatetimeConfig(order_col=order_col,
                                                                                  fields=list(derived)))
    for c in derived:
        df[c] = out[c].astype(str).to_numpy()
    return df


def read_status(path):
    """field_status.csv (field, result, reasons) of the field checks -> {name: (result, reasons)}."""
    if not path:
        return {}
    st = pd.read_csv(path, dtype=str, keep_default_na=False)
    key = "field" if "field" in st.columns else "name"
    return {r[key]: (r.get("result", "").strip().upper(), r.get("reasons", "")) for _, r in st.iterrows()}


def row_result(r, status, status_given):
    """(result, reasons) of one map row: the field status file's when it is given (a row absent from it has
    none), else the file's or the map's own check_result and check_reasons."""
    name = r["name"].strip()
    if status_given:
        return status.get(name, ("", ""))
    return status.get(name, (r.get("check_result", "").strip().upper(), r.get("check_reasons", "")))


# A STOP or WAIT on a source column carries to every engineered field that reads it, whatever the field's own
# result says (the field status may be stale, or the rule one the field checks do not pass on). Two kinds of
# rule keep the source's values in use, so they do not carry: a twin kept once under another name (duplicate,
# duplicate_number, function_of), and a raw date, which enters only through days_before or days_until, which
# is what the recipe does.
BLOCKING = ("STOP", "WAIT")
SOURCE_RULES_NOT_CARRIED = ("duplicate", "duplicate_number", "function_of", "raw_date")
KEY_COLUMNS = (ACCOUNT, TIME, TIE)  # every history recipe reads them; they are never map rows
_RULE_TOKEN = re.compile(r"\b(STOP|WAIT|FLAG) ([A-Za-z0-9_]+)")


def carried_rule(result, reasons):
    """The rule a STOP or WAIT source passes on to a recipe that reads it, or None. The first blocking rule of
    its reasons that keeps no value in use; the result itself when the reasons name no rule."""
    if str(result).strip().upper() not in BLOCKING:
        return None
    rules = [rule for res, rule in _RULE_TOKEN.findall(str(reasons or "")) if res in BLOCKING]
    if not rules:
        return str(result).strip().upper()
    left = [x for x in rules if x not in SOURCE_RULES_NOT_CARRIED]
    return left[0] if left else None


def recipe_parser():
    """The recipe module's parser (nf_recipes.parse) by path, or None when the module is not there or does not
    load (the map's source_columns are then the sources)."""
    p = NF_DIR / "nf_recipes.py"
    if not p.exists():
        return None
    try:
        fn = getattr(_by_path("nf_recipes", p), "parse", None)
    except Exception:
        sys.modules.pop("nf_recipes", None)
        return None
    return fn if callable(fn) else None


def field_sources(row, parse_fn=None):
    """The columns an engineered map row reads: the map's source_columns (what the field checks read too) and its
    recipe's own sources (the recipe module's parser, for a recipe inside its grammar). An a3(col) recipe keeps
    the map's per-column sources only: the parser gives every column the 26 October builders read, for any
    output. Never the row's own name or the account, time and tie keys."""
    name, recipe = str(row["name"]).strip(), str(row.get("recipe", "") or "").strip()
    out = [s.strip() for s in str(row.get("source_columns", "") or "").split(";") if s.strip()]
    if parse_fn is not None and recipe not in ("", "raw") and not recipe.startswith("a3("):
        try:
            out += [str(s) for s in parse_fn(recipe).sources]
        except Exception:  # outside the grammar: the map's source_columns alone
            pass
    return [s for s in dict.fromkeys(out) if s and s != name and s not in KEY_COLUMNS]


def history_key(row, parse_fn=None):
    """The history key a map row's recipe groups rows by: the column its recipe names with key= (a customer or a
    card), else the account. A recipe the parser cannot read, or no parser, gives the account."""
    recipe = str(row.get("recipe", "") or "").strip()
    if parse_fn is None or recipe in ("", "raw"):
        return ACCOUNT
    try:
        return str(getattr(parse_fn(recipe), "history_key", None) or ACCOUNT)
    except Exception:  # outside the grammar
        return ACCOUNT


def read_columns(row, parse_fn=None):
    """The columns the screen reads from the files for a map row that enters: its source_columns and, for a recipe
    inside the recipe module's grammar, every column the module needs in the file to build it. For a3(col) that
    is every input of the 26 October builders (the module refuses an a3 recipe when one is missing, whatever the
    output), even where the map lists two of them. A recipe outside the grammar: the map's source_columns alone."""
    recipe = str(row.get("recipe", "") or "").strip()
    out = [s.strip() for s in str(row.get("source_columns", "") or "").split(";") if s.strip()]
    if parse_fn is not None and recipe not in ("", "raw"):
        try:
            out += [str(s) for s in parse_fn(recipe).sources]
        except Exception:  # outside the grammar
            pass
    return list(dict.fromkeys(out))


def source_results(fmap, status, status_given):
    """{column: (result, reasons)}: each map row's result under its name, and a raw row's also under its source
    column when no row has that name (a raw field's name is normally its pod column; the source column covers a
    renamed one). Of two raw rows on one source column, a STOP or WAIT one counts."""
    by, alias = {}, {}
    for _, r in fmap.iterrows():
        res = row_result(r, status, status_given)
        if not res[0]:
            continue
        by.setdefault(str(r["name"]).strip(), res)
        if str(r.get("recipe", "") or "").strip() in ("", "raw"):
            src = [s.strip() for s in str(r.get("source_columns", "") or "").split(";") if s.strip()]
            if src and (src[0] not in alias or (res[0] in BLOCKING and alias[src[0]][0] not in BLOCKING)):
                alias[src[0]] = res
    for c, res in alias.items():
        by.setdefault(c, res)
    return by


def source_stops(row, by_column, parse_fn=None):
    """'source_stop:<source> <rule>' for each source of an engineered row that is STOP or WAIT in the field
    checks, joined with '; ' (blank when none). A raw row has no source to stop it: its own result decides."""
    if str(row.get("recipe", "") or "").strip() in ("", "raw"):
        return ""
    out = []
    for s in field_sources(row, parse_fn):
        rule = carried_rule(*by_column[s]) if s in by_column else None
        if rule:
            out.append(f"source_stop:{s} {rule}")
    return "; ".join(out)


def select_fields(fmap, status, allow_unchecked, status_given=False, parse_fn=None):
    """Map rows that enter the screen, and the rows left out with their reason. Nothing is removed silently.
    With a field status file (`status_given`), a map row absent from it is not checked: the map's own
    check_result, which may be stale, is not used for it. An engineered row that would enter is left out when a
    source it reads is STOP or WAIT in the field checks ('source_stop:<source> <rule>'): the screen enforces it
    whatever the row's own result says."""
    enter, left = [], []
    by_column = source_results(fmap, status, status_given)
    for _, r in fmap.iterrows():
        name = r["name"].strip()
        res = row_result(r, status, status_given)[0]
        if r.get("list_status", "").strip() == "NOT_IN_OWNER_LIST":
            left.append((name, "not in the owner's list"))
        elif r.get("excluded_by_sumegha", "").strip().lower() == "yes":
            left.append((name, "excluded_by_sumegha"))
        elif r.get("left_out_reason", "").strip():
            left.append((name, "left_out_reason: " + r["left_out_reason"].strip()))
        elif res in ENTER or (not res and allow_unchecked):
            stop = source_stops(r, by_column, parse_fn)
            if stop:
                left.append((name, stop))
            else:
                enter.append(r)
        elif not res:
            left.append((name, "not checked (not in the field status file)" if status_given
                         else "not checked (no field status)"))
        else:
            left.append((name, f"{res} in the field checks"))
    return enter, left


def duplicate_names(fmap):
    """{name: [rows of the map file]} for every name two or more map rows share (the header is row 1)."""
    rows = {}
    for i, n in enumerate(fmap["name"].str.strip()):
        rows.setdefault(n, []).append(i + 2)
    return {n: r for n, r in rows.items() if len(r) > 1}


def base_named_rows(fmap, base_names):
    """[(row of the map file, name, base input)] for map rows named like a base input, letter case ignored: the
    base arm holds that input already, so a second column of that name would stand for it in every table."""
    low = {str(c).lower(): c for c in base_names}
    return [(i + 2, n, low[n.lower()]) for i, n in enumerate(fmap["name"].str.strip()) if n.lower() in low]


def _rows_text(rows):
    return ("row " if len(rows) == 1 else "rows ") + ", ".join(str(x) for x in rows)


def map_refusals(fmap, base_names, map_name):
    """Lines that refuse the map before any read (exit 2), or []: names two rows share (a second row would
    overwrite the first), and rows named like a base input."""
    lines = []
    dup = duplicate_names(fmap)
    if dup:
        lines.append(f"refused: map rows share a name in {map_name} (the header is row 1); give each its own name:")
        lines += [f"  {n or '(blank)'}: {_rows_text(r)}" for n, r in sorted(dup.items())]
    named = base_named_rows(fmap, base_names)
    if named:
        lines.append(f"refused: map rows named like a base input in {map_name} (the base arm holds it already); "
                     "rename or remove them:")
        lines += [f"  {n}: row {i}, base input {b}" for i, n, b in named]
    return lines


def clash_names(reserved, history_lite=False, hl_cols=(), oct26_cols=()):
    """{lower-case name: why} for the names a new field may not take: the reserved columns, with --history-lite
    the history-lite columns, and with --oct26 the requested 26 October columns. Checked before any read."""
    out = {str(c).lower(): "name clashes with a base input or a reserved name" for c in reserved}
    if history_lite:
        out.update({c.lower(): "name clashes with a history-lite column (--history-lite)" for c in hl_cols})
    for c, fam in oct26_cols:
        out.setdefault(c.lower(), f"name clashes with a 26 October column (--oct26 {fam})")
    return out


def clash_reason(row, clash):
    """Why a map row's name clashes, or "". A row built by the very 26 October column it is named after
    (recipe a3(<its name>)) is the same values, so it does not clash with that column."""
    name = row["name"].strip()
    low = name.lower()
    if low.endswith("_isna"):
        return "name clashes with a base input or a reserved name"
    why = clash.get(low, "")
    if why.startswith("name clashes with a 26 October column") and \
            str(row.get("recipe", "") or "").replace(" ", "").lower() == f"a3({low})":
        return ""
    return why


CLUSTER_KEYS = ("name", "field", "feature", "member")  # "member": the field checks' clusters.csv


def _group(pairs):
    out = {}
    for cid, n in pairs:
        if str(cid).strip() and str(n).strip():
            out.setdefault(str(cid).strip(), []).append(str(n).strip())
    return out


def read_clusters(path):
    """{cluster_id: [members]} from a clusters CSV. The field checks write clusters.csv with the columns
    cluster_id, member, member_kind, size, max_link and result; any file with cluster_id and one of name, field,
    feature or member is read the same way. Base members (member_kind base) are kept: the ranking arm holds the
    base inputs too. Raises ValueError with the reason."""
    p = Path(path)
    if not p.is_file():
        raise ValueError(f"{p.name}: file not found")
    c = pd.read_csv(p, dtype=str, keep_default_na=False)
    if "cluster_id" not in c.columns:
        raise ValueError(f"{p.name} has no cluster_id column (it has: {', '.join(c.columns)})")
    key = next((k for k in CLUSTER_KEYS if k in c.columns), None)
    if key is None:
        raise ValueError(f"{p.name} has none of the member columns {', '.join(CLUSTER_KEYS)} "
                         f"(it has: {', '.join(c.columns)})")
    return _group(zip(c["cluster_id"], c[key]))


def map_clusters(fmap, path=None, status_path=None):
    """(clusters, source). Order: --clusters (the field checks' clusters.csv); else the cluster_id column of the
    field status file when it fills any; else the map's cluster_id."""
    if path:
        return read_clusters(path), Path(path).name
    if status_path and Path(status_path).is_file():
        st = pd.read_csv(status_path, dtype=str, keep_default_na=False)
        key = "field" if "field" in st.columns else "name"
        if "cluster_id" in st.columns and st["cluster_id"].str.strip().ne("").any():
            return _group(zip(st["cluster_id"], st[key])), f"{Path(status_path).name} cluster_id"
    return _group(zip(fmap["cluster_id"], fmap["name"])), "map cluster_id"


def file_list(files, base, start, end, lay):
    if files:
        if base is not None:
            raise SystemExit("give --files or --base/--start/--end, not both")
        return list(files)
    if base is None or start is None or end is None:
        raise SystemExit("give --files, or --base with --start and --end")
    return _s3_attr(lay, "build_file_list")(base, start, end)


def _s3_attr(lay, name):
    m = lay.get("s3")
    for mm in (m if isinstance(m, list) else [m]):
        if hasattr(mm, name):
            return getattr(mm, name)
    return None


def read_frame(path, fs, columns, lay):
    """One parquet file, local or on S3, only the listed columns it has."""
    import pyarrow.parquet as pq
    if fs is None:
        have = set(pq.read_schema(path).names)
        return pd.read_parquet(path, columns=[c for c in columns if c in have])
    ds = pq.ParquetDataset(_s3_attr(lay, "strip_scheme")(path), filesystem=fs)
    have = set(ds.schema.names)
    return ds.read(columns=[c for c in columns if c in have]).to_pandas()


def read_files(files, fs, columns, lay):
    """The files as one frame, and each row's file number (recipes are built per file, as the enriched copies
    are, so a recipe keyed on another column never reaches into another file)."""
    frames = [read_frame(f, fs, columns, lay) for f in files]
    df = pd.concat(frames, ignore_index=True)
    parts = pd.Series(np.concatenate([np.full(len(f), i) for i, f in enumerate(frames)]) if frames else [],
                      index=df.index, dtype=int)
    return df, parts


# ------------------------------------------------------------------------------------------- building

def _align(v, df):
    if isinstance(v, pd.Series):
        if v.index.equals(df.index) or v.index.isin(df.index).all():
            return v.reindex(df.index)
        return pd.Series(v.to_numpy(), index=df.index)
    return pd.Series(np.asarray(v), index=df.index)


class Builder:
    """Builds map rows' values on frames of whole account histories.

    Order in the screen: a column the files already hold (enriched copies, raw fields; compared with its recipe
    when the recipe can be rebuilt); `raw`; every other recipe through the recipe module
    (`recipe_fn(df, recipe, extract_start, model_type)`, new_fields/nf_recipes.py; with `recipe_fn.batch` every
    recipe of one file in one call). Without the module, `code(c)` (the raw code as a category, design 2.2) and
    `a3(col)` (the 26 October builders, called unchanged through the resolver) are still built here; other
    recipes are not built and are listed. Every build pass is recorded in `passes` (the cost guard counts them)."""

    def __init__(self, lay, recipe_fn=None, recipe_source="none"):
        self.lay, self.recipe_fn, self.recipe_source = lay, recipe_fn, recipe_source
        self._a3 = {}
        self.passes = []

    def a3_frame(self, df, extract_start):
        key = (id(df), len(df), str(extract_start))
        if key not in self._a3:
            g = self.lay.get("groups").compute_groups(df, extract_start)
            n = self.lay.get("features_new").compute_new(df, extract_start)
            self._a3 = {key: pd.concat([g, n.drop(columns=[c for c in n.columns if c in g.columns])], axis=1)}
        return self._a3[key]

    @staticmethod
    def raw_values(row, df):
        """A raw field's values: its source column (or its own name). None when the files lack it."""
        src = [s.strip() for s in row["source_columns"].split(";") if s.strip()]
        c = src[0] if src else row["name"].strip()
        return df[c] if c in df.columns else None

    def recompute(self, row, df, extract_start, model_type=None):
        """One row's values from its recipe (never from a stored column). None when it cannot be built here."""
        recipe = row["recipe"].strip()
        if recipe in ("", "raw"):
            return self.raw_values(row, df)
        if self.recipe_fn is not None:
            mt = model_type or row.get("model_type", "").strip() or None
            return _align(self.recipe_fn(df, recipe, extract_start, mt), df)
        if recipe.startswith("code(") and recipe.endswith(")"):
            c = recipe[5:-1].strip()
            return df[c] if c in df.columns else None
        if recipe.startswith("a3(") and recipe.endswith(")"):
            c = recipe[3:-1].strip()
            f = self.a3_frame(df, extract_start)
            return f[c] if c in f.columns else None
        return None

    def can_recompute(self, row):
        recipe = row["recipe"].strip()
        return (recipe not in ("", "raw") and (self.recipe_fn is not None or recipe.startswith("code(")
                                               or recipe.startswith("a3(")))

    def _part(self, rows, sub, extract_start, mts, failed):
        names = [r["name"].strip() for r in rows]
        batch = getattr(self.recipe_fn, "batch", None)
        if batch is not None and rows:
            frame, bad = batch(sub, [(n, r["recipe"].strip(), mts.get(n)) for n, r in zip(names, rows)], extract_start)
            failed.update(bad)
            return {n: _align(frame[n], sub) for n in names if n in frame.columns and n not in bad}
        out = {}
        for n, r in zip(names, rows):
            try:
                v = self.recompute(r, sub, extract_start, mts.get(n))
            except Exception as e:  # recorded, never guessed
                failed[n] = f"{type(e).__name__}: {e}"[:300]
                continue
            if v is None:
                failed[n] = "no recipe module for this recipe"
                continue
            out[n] = v
        return out

    def rebuild_all(self, rows, df, extract_start, parts=None, what="build", model_types=None):
        """Every rebuildable row's recipe values on `df` in one pass, file by file (`parts`: each row's file
        number, aligned to df). Returns ({name: values aligned to df.index}, {name: why it failed})."""
        rows = [r for r in rows if self.can_recompute(r)]
        mts = dict(model_types or {})
        t0 = _time.perf_counter()
        failed, got = {}, {r["name"].strip(): [] for r in rows}
        if parts is None or len(df) == 0:
            pieces = [df]
        else:
            p = pd.Series(parts).reindex(df.index).to_numpy()
            pieces = [df[p == k] for k in pd.unique(p)]
        for sub in pieces:
            todo = [r for r in rows if r["name"].strip() not in failed]
            for n, v in self._part(todo, sub, extract_start, mts, failed).items():
                got[n].append(v)
        out = {n: pd.concat(v).reindex(df.index) for n, v in got.items() if n not in failed and v}
        self.passes.append({"what": what, "rows": int(len(df)), "files": len(pieces), "fields": len(rows),
                            "seconds": _time.perf_counter() - t0})
        return out, failed


RECIPE_TMP = "__screen_recipe_value__"
# Row-level recipes whose value is a category in the recipe module: code(c), the raw code as a category, and
# geohash(postal; country), TFM's geohash of a postal code (nf_recipes builds it as a category and refuses any
# other model_type). A map row of either with a blank model_type is screened as a category.
CATEGORY_RECIPES = ("code(", "geohash(")


def category_recipe(recipe):
    """True for a recipe whose value is a category whatever the map's model_type says is missing."""
    return str(recipe or "").strip().startswith(CATEGORY_RECIPES)


def recipe_module():
    """The new-fields recipe module (NF/nf_recipes.py) by path, if present: (callable, label). The callable is
    fn(df, recipe, extract_start, model_type) and uses nf_recipes.build_columns, the same code the enriched
    copies use; fn.batch(df, [(name, recipe, model_type)], extract_start) builds every recipe of one file in one
    build_columns call and returns (frame, {name: why it failed})."""
    p = NF_DIR / "nf_recipes.py"
    if not p.exists():
        return None, "none (nf_recipes.py not found)"
    m = _by_path("nf_recipes", p)
    if not callable(getattr(m, "build_columns", None)):
        return None, "none (nf_recipes.py has no build_columns)"

    def _mt(recipe, model_type):
        return model_type or ("categorical" if category_recipe(recipe) else "continuous")

    def fn(df, recipe, extract_start, model_type=None):
        frame, _ = m.build_columns(df.drop(columns=[RECIPE_TMP], errors="ignore"),
                                   [(RECIPE_TMP, recipe, _mt(recipe, model_type))], extract_start)
        return frame[RECIPE_TMP]

    def batch(df, fields, extract_start):
        base = df.drop(columns=[c for c in df.columns if str(c).startswith(RECIPE_TMP)])
        failed, todo = {}, []
        for i, (name, recipe, model_type) in enumerate(fields):
            if callable(getattr(m, "parse", None)):
                try:
                    m.parse(recipe)
                except Exception as e:  # outside the grammar: named, never guessed
                    failed[name] = f"{type(e).__name__}: {e}"[:300]
                    continue
            todo.append((name, f"{RECIPE_TMP}{i}", recipe, _mt(recipe, model_type)))
        if not todo:
            return pd.DataFrame(index=df.index), failed
        try:
            frame, _ = m.build_columns(base, [(t, r, mt) for _, t, r, mt in todo], extract_start)
            return pd.DataFrame({n: frame[t] for n, t, _, _ in todo}, index=df.index), failed
        except Exception:  # one recipe failed the call: build one at a time to name it
            cols = {}
            for n, t, r, mt in todo:
                try:
                    one, _ = m.build_columns(base, [(t, r, mt)], extract_start)
                    cols[n] = one[t]
                except Exception as e:
                    failed[n] = f"{type(e).__name__}: {e}"[:300]
            return pd.DataFrame(cols, index=df.index), failed

    fn.batch = batch
    return fn, "nf_recipes.build_columns"


def why_not_run(reason):
    """A short class for a recipe that could not be rebuilt (the summary groups by it)."""
    r = str(reason)
    if "no recipe module" in r:
        return "no recipe module"
    if "grammar is closed" in r or "does not parse" in r or "unknown recipe" in r:
        return "recipe outside the grammar"
    if "perturbed" in r:
        return "perturbed rebuild failed"
    return "recipe failed"


# ------------------------------------------------------------------------------------------- cost

def count_fits(k, n_families, n_extra_seeds, temporal, label_shuffle, history_lite, month_on_top):
    per_family = 2 * k * (1 + int(temporal) + int(label_shuffle) + int(history_lite))
    floor = 2 * k + k * n_extra_seeds
    month = (2 * k * (1 + int(temporal))) if month_on_top else 0
    return floor + n_families * per_family + month + k  # + k: the ranking arm


def time_one_fit(U, data, cols, cats, k, seed, params, train_neg_rate):
    """Seconds for one fit of the widest arm on fold 0's training rows, and one prediction of its held-out fold."""
    y = (pd.to_numeric(data[LABEL], errors="coerce").to_numpy() == 1).astype(int)
    fold = U.account_folds(data[ACCOUNT].astype(str).to_numpy(), k)
    keep = np.random.default_rng(seed + 1).random(len(data))
    te = fold == 0
    tr = ~te & ((y == 1) | (keep < train_neg_rate))
    X = U._design(data, cols, set(cats))
    t0 = _time.perf_counter()
    m, _ = U._fit_predict(X[tr], y[tr], X[te].iloc[:1], {**U.DEFAULT_PARAMS, **(params or {})}, seed)
    t1 = _time.perf_counter()
    m.predict_proba(X[te])
    return t1 - t0, _time.perf_counter() - t1


# ------------------------------------------------------------------------------------------- June drift

def naive_time(df):
    """The time column as timezone-naive datetimes (UTC wall time when it carries a zone)."""
    t = pd.to_datetime(df[TIME])
    if getattr(t.dt, "tz", None) is not None:
        t = t.dt.tz_convert("UTC").dt.tz_localize(None)
    df[TIME] = t
    return df


def _typed(v, mtype):
    return as_code(v) if mtype == "categorical" else pd.to_numeric(pd.Series(v), errors="coerce")


MONTH_NAMES = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")  # no locale


def reference_choice(df, min_rows):
    """The June reference month: the last training month when it is a whole month (the training rows reach its
    last day) and holds at least `min_rows` rows, else the month before it when that one holds them (it is
    whole: the rows run past it), else none (the whole training stream is the reference, with a note). A partial
    month is never the reference: a recipe with no lookback limit sees less history on its last days than June
    rows do, so a few days of it against a whole June differ for the calendar alone. The reference's rows are
    rebuilt on the frame from the first day of the month before it to its end, so the reference sees one month of
    history, as June does. `tried` holds each month looked at: its rows, and for a partial month (`ends`) the
    last day the training rows reach."""
    t = pd.to_datetime(df[TIME])
    if getattr(t.dt, "tz", None) is not None:
        t = t.dt.tz_convert("UTC").dt.tz_localize(None)
    per = t.dt.to_period("M")
    counts = per.value_counts()
    tried = []
    last = per.max() if len(per) else None
    t_max = t.max() if len(t) else None
    for month in ([] if last is None or pd.isna(last) else [last, last - 1]):
        n = int(counts.get(month, 0))
        partial = bool(t_max < month.end_time.normalize())  # the rows stop before the month's last day
        entry = {"month": str(month), "rows": n, "ends": str(t_max.date()) if partial else None}
        if n >= min_rows and not partial:
            note = "" if not tried else f"{_not_used(tried, min_rows)}: the reference is {month} ({n} rows)"
            return {"month": month, "start": (month - 1).start_time, "end": (month + 1).start_time, "rows": n,
                    "min_rows": int(min_rows), "tried": tried + [entry], "note": note}
        tried.append(entry)
    return {"month": None, "start": None, "end": None, "rows": 0, "min_rows": int(min_rows), "tried": tried,
            "note": f"{_not_used(tried, min_rows)}: the reference is the whole training stream"}


def _not_used(tried, min_rows):
    """Why each month looked at is not the reference: partial, too few rows, or both (screen.json's note)."""
    if not tried:
        return "no training rows"
    parts = []
    for t in tried:
        why = ([f"is partial (the training rows end on {t['ends']})"] if t.get("ends") else []) + (
            [f"has {t['rows']} rows"] if t["rows"] < min_rows else [])
        parts.append(f"{t['month']} " + " and ".join(why))
    few = any(t["rows"] < min_rows for t in tried)
    return "; ".join(parts) + (f", below --drift-min-rows {min_rows}" if few else "")


def reference_skips(d, width=88):
    """The summary's line for the months June drift looked at and did not take as the reference, or "", for
    example '  not used: 2025-05 (partial, to 18 May, 25 rows); minimum 100 rows'. It fits `width` characters;
    the full sentence is screen.json's reference_note."""
    ref, m = d.get("reference_month"), int(d.get("reference_min_rows") or 0)
    skipped = [t for t in (d.get("reference_tried") or []) if t.get("month") != ref]
    if not skipped:
        return ""
    bits = []
    for t in skipped:
        why = []
        if t.get("ends"):
            day = pd.Timestamp(t["ends"])
            why.append(f"partial, to {day.day} {MONTH_NAMES[day.month - 1]}")
        if t.get("rows", 0) < m:
            why.append(f"{t['rows']} rows")
        bits.append(f"{t['month']} ({', '.join(why)})" if why else str(t["month"]))
    few = any(t.get("rows", 0) < m for t in skipped)
    line = "  not used: " + ", ".join(bits) + (f"; minimum {m} rows" if few else "")
    if len(line) > width:
        line = "  not used: " + ", ".join(str(t["month"]) for t in skipped) + \
            f" (partial, or below --drift-min-rows {m})"
    return line


# ----- the drift cut. A field is flagged only when its PSI is above the larger of --drift-threshold and the 95th
# percentile of PSI between two samples drawn from its own reference rows: one the size of the reference and one
# the size of June. So a many-level code with few June rows, or a small reference, is not flagged for its
# sampling noise alone. The bins are fsc_stability.psi's (deciles of the finite reference values and a missing
# bin for numbers; the reference codes, one bin for codes the reference lacks and a missing bin for codes). When
# the reference rows' accounts are known (the screen passes them) a sample is whole accounts of the reference
# drawn with replacement: the reference's account count, and accounts until the June row count is reached. Rows
# of one account move together, so a June month of few accounts gets the wider cut its few accounts call for.
# Without accounts a draw is a multinomial of the reference's bin shares, the same as resampling its rows.

DRIFT_NULL_DRAWS = 1000
DRIFT_NULL_PERCENTILE = 95
PSI_EPS = 1e-6
NULL_CELLS = 2_000_000  # bin counts held at once per side while drawing (16 MB)


def psi_counts(ref, other, categorical=False, bins=10):
    """(reference counts, other counts, number of code bins) over the bins of fsc_stability.psi."""
    ref, other = pd.Series(ref), pd.Series(other)
    if categorical:
        r, o = ref.astype(object), other.astype(object)
        cats = sorted(set(r.dropna().astype(str)))
        pos = {c: i for i, c in enumerate(cats)}

        def counts(s):
            miss = s.isna().to_numpy()
            idx = s[~miss].astype(str).map(pos)
            seen = idx.dropna().to_numpy(dtype=np.int64)
            c = np.bincount(seen, minlength=len(cats)).astype(float)
            return np.r_[c, float(idx.isna().sum()), float(miss.sum())]
        return counts(r), counts(o), len(cats)
    r = pd.to_numeric(ref, errors="coerce").astype(float)
    o = pd.to_numeric(other, errors="coerce").astype(float)
    fin = r[np.isfinite(r)]
    edges = np.unique(np.quantile(fin, np.linspace(0, 1, bins + 1)[1:-1])) if len(fin) else np.array([])

    def counts(s):
        v = s.to_numpy()
        f = np.isfinite(v)
        c = np.bincount(np.searchsorted(edges, v[f], side="right"), minlength=len(edges) + 1)
        return np.r_[c, (~f).sum()].astype(float)
    return counts(r), counts(o), 0


def psi_from_counts(cr, co, eps=PSI_EPS):
    """PSI from bin counts as fsc_stability.psi computes it; rows of 2-d arrays are separate draws."""
    cr, co = np.atleast_2d(np.asarray(cr, float)), np.atleast_2d(np.asarray(co, float))
    pr = cr / np.maximum(cr.sum(axis=1, keepdims=True), 1) + eps
    po = co / np.maximum(co.sum(axis=1, keepdims=True), 1) + eps
    return ((po - pr) * np.log(po / pr)).sum(axis=1)


def psi_bins(ref, categorical=False, bins=10):
    """(bin of each reference row, number of bins, number of code bins) over the bins of psi_counts."""
    ref = pd.Series(ref)
    if categorical:
        r = ref.astype(object)
        cats = sorted(set(r.dropna().astype(str)))
        pos = {c: i for i, c in enumerate(cats)}
        miss = r.isna().to_numpy()
        b = np.full(len(r), len(cats) + 1, dtype=np.int64)
        b[~miss] = r[~miss].astype(str).map(pos).to_numpy(dtype=np.int64)
        return b, len(cats) + 2, len(cats)
    v = pd.to_numeric(ref, errors="coerce").astype(float).to_numpy()
    f = np.isfinite(v)
    edges = np.unique(np.quantile(v[f], np.linspace(0, 1, bins + 1)[1:-1])) if f.any() else np.array([])
    b = np.full(len(v), len(edges) + 1, dtype=np.int64)
    b[f] = np.searchsorted(edges, v[f], side="right")
    return b, len(edges) + 2, 0


def _code_bins(R, J, n_codes, unseen, rng):
    """Codes in a drawn June sample: a share `unseen` of each seen code's rows moves to the bin of codes the
    reference lacks; a code absent from the drawn reference falls in that bin too, as in psi."""
    if unseen > 0:
        moved = rng.binomial(J[:, :n_codes].astype(np.int64), unseen).astype(float)
        J[:, :n_codes] -= moved
        J[:, n_codes] += moved.sum(axis=1)
    absent = R[:, :n_codes] == 0
    J[:, n_codes] += (J[:, :n_codes] * absent).sum(axis=1)
    J[:, :n_codes] = np.where(absent, 0.0, J[:, :n_codes])
    return J


def drift_null(ref, n_other, categorical=False, draws=DRIFT_NULL_DRAWS, percentile=DRIFT_NULL_PERCENTILE, seed=0,
               ref_accounts=None):
    """The `percentile`-th percentile of PSI between two samples of the reference rows (with replacement): one
    the size of the reference and one the size of the June side (`n_other` rows). With `ref_accounts` (each
    reference row's account) the samples are whole reference accounts: the reference's account count, and
    accounts drawn until `n_other` rows are reached (the last account drawn is kept whole). Rows of independent
    values give about the cut of resampled rows; rows that move together within an account give a wider one. None
    when the reference has no row. For codes, the June-size sample also carries codes the reference never showed, at the share of codes it
    showed once (the Good-Turing estimate of the unseen share): June rows of an honest field carry such codes too."""
    cr, _, n_codes = psi_counts(ref, pd.Series([], dtype=float), categorical)
    n_ref = int(cr.sum())
    if n_ref == 0 or int(n_other) == 0:
        return None
    unseen = 0.0
    if n_codes:
        seen = cr[:n_codes]
        unseen = float((seen == 1).sum()) / max(1.0, float(seen.sum()))
    rng = np.random.default_rng(seed)
    if ref_accounts is not None:
        return _drift_null_accounts(ref, int(n_other), categorical, draws, percentile, rng, ref_accounts, n_codes,
                                    unseen)
    p = cr / cr.sum()
    q = p.copy()
    if n_codes:
        q[:n_codes] = p[:n_codes] * (1.0 - unseen)
        q[n_codes] = p[:n_codes].sum() * unseen
    q = q / q.sum()
    step = max(1, min(draws, NULL_CELLS // len(p)))  # draws in chunks: a code of many levels stays small in memory
    out = []
    for k in range(0, draws, step):
        m = min(step, draws - k)
        R = rng.multinomial(n_ref, p, size=m).astype(float)
        J = rng.multinomial(int(n_other), q, size=m).astype(float)
        if n_codes:  # a code absent from a drawn reference falls in its 'codes the reference lacks' bin, as in psi
            absent = R[:, :n_codes] == 0
            J[:, n_codes] += (J[:, :n_codes] * absent).sum(axis=1)
            J[:, :n_codes] = np.where(absent, 0.0, J[:, :n_codes])
        out.append(psi_from_counts(R, J))
    return float(np.percentile(np.concatenate(out), percentile))


def _drift_null_accounts(ref, n_other, categorical, draws, percentile, rng, ref_accounts, n_codes, unseen):
    """drift_null with whole reference accounts drawn: each draw's bin counts are the sums of its accounts'."""
    from scipy import sparse

    b, nb, _ = psi_bins(ref, categorical)
    acc = pd.Series(np.asarray(ref_accounts, dtype=object)).astype(str).to_numpy()
    if len(acc) != len(b):
        raise ValueError(f"drift_null: {len(acc)} reference accounts for {len(b)} reference rows")
    _, ai = np.unique(acc, return_inverse=True)
    n_acc = int(ai.max()) + 1
    size = np.bincount(ai, minlength=n_acc)  # rows per account
    M = sparse.csr_matrix((np.ones(len(b)), (ai, b)), shape=(n_acc, nb))  # each account's rows per bin
    k_june = int(np.ceil(2.0 * n_other / size.mean())) + 8  # accounts drawn per June-size sample, more if short
    out = []
    done = 0
    while done < draws:
        m = min(draws - done, max(1, NULL_CELLS // max(n_acc, k_june, nb, M.nnz)))
        off = np.arange(m)[:, None] * n_acc
        WR = np.bincount((off + rng.integers(n_acc, size=(m, n_acc))).ravel(), minlength=m * n_acc)
        pick = rng.integers(n_acc, size=(m, k_june))
        before = np.cumsum(size[pick], axis=1) - size[pick]  # rows drawn before each account
        if (before[:, -1] + size[pick[:, -1]] < n_other).any():  # a sample fell short: draw more accounts
            k_june *= 2
            continue
        keep = before < n_other
        WJ = np.bincount((off + pick)[keep], minlength=m * n_acc)
        R = np.asarray(M.T @ WR.reshape(m, n_acc).T.astype(float)).T
        J = np.asarray(M.T @ WJ.reshape(m, n_acc).T.astype(float)).T
        if n_codes:
            J = _code_bins(R, J, n_codes, unseen, rng)
        out.append(psi_from_counts(R, J))
        done += m
    return float(np.percentile(np.concatenate(out), percentile))


def _field_seed(seed, name):
    return [int(seed) & 0xFFFFFFFF, zlib.crc32(str(name).encode())]


def drift_month_rows(files, fs, month, lay):
    """Rows of --drift-month in the drift files, from the time column only (read before the screen)."""
    n = 0
    for f in files:
        t = naive_time(read_frame(f, fs, [TIME], lay))
        n += int((t[TIME].dt.to_period("M").astype(str) == month).sum())
    return n


def june_drift(a, df, ev, rows, new, info, builder, S, parts=None, ev_parts=None, train_failed=None):
    """PSI of each new field between training rows and June rows, no labels read.

    History parity (design review item 12): June rows can look back only to the evaluation extract start. A field
    whose recipe can be rebuilt is rebuilt on both sides from the same code: June from the evaluation extract
    start, and the reference (the last training month) on training rows that start on the first day of the month
    before it. The reference frame physically holds no earlier row, so a recipe with an unlimited lookback
    (within=all) sees about the same history on both sides. Any other field (raw values, codes, a stored column
    without a rebuildable recipe) is compared with the whole training stream, and its row says so. Below
    --drift-min-rows rows in the drift month nothing is compared and nothing is flagged. The reference month must
    be a whole month and hold --drift-min-rows rows too: else the month before it is the reference, else the whole
    training stream, with a note (see reference_choice). A field is flagged only above its own cut (see
    drift_null). `train_failed` holds the recipes that did not build on the training frame: they are not rebuilt
    again here."""
    min_rows = max(1, int(getattr(a, "drift_min_rows", 1) or 1))
    choice = reference_choice(df, min_rows)
    last = choice["month"]
    ref_day = None if last is None else str(choice["start"].date())
    june = (pd.to_datetime(ev[TIME]).dt.to_period("M").astype(str) == a.drift_month).to_numpy()
    res = {"month": a.drift_month, "june_rows": int(june.sum()),
           "reference_month": "whole training stream" if last is None else str(last),
           "reference_extract_start": ref_day, "reference_rows": choice["rows"], "reference_min_rows": min_rows,
           "reference_tried": choice["tried"], "reference_note": choice["note"], "threshold": a.drift_threshold,
           "cut_rule": (f"PSI above max({a.drift_threshold}, the {DRIFT_NULL_PERCENTILE}th percentile of PSI between "
                        f"two samples of whole accounts of the field's reference rows, at the reference's account "
                        f"count and the June row count; {DRIFT_NULL_DRAWS} draws)"),
           "columns": {}, "flagged": [], "skipped": {}, "reference_fallback": {}, "june_stored_differs": {}}
    if june.sum() < min_rows:
        res["not_run"] = (f"no rows in --drift-month {a.drift_month}" if not june.any() else
                          f"only {int(june.sum())} rows in --drift-month {a.drift_month} (minimum {min_rows})")
        return res
    rows = [r for r in rows if r["name"].strip() in new]
    mts = {n: info[n]["model_type"] for n in new}
    train_failed = train_failed or {}
    rb_rows = [r for r in rows if builder.can_recompute(r) and r["name"].strip() not in train_failed]
    jb, jfail = builder.rebuild_all(rb_rows, ev, a.drift_extract_start, ev_parts, "June", mts)
    rb, rfail, ref_rows = {}, {}, None
    if last is not None:
        t = pd.to_datetime(df[TIME])
        sub = df.loc[((t >= choice["start"]) & (t < choice["end"])).to_numpy()]
        rb, rfail = builder.rebuild_all([r for r in rb_rows if r["name"].strip() in jb], sub, ref_day,
                                        None if parts is None else parts.loc[sub.index], "June reference", mts)
        ref_rows = (pd.to_datetime(sub[TIME]).dt.to_period("M") == last).to_numpy()
    tr, jn, ref, tr_acc, jn_acc = {}, {}, {}, {}, {}
    ev_acc = ev[ACCOUNT].to_numpy(dtype=object)[june] if ACCOUNT in ev.columns else None
    df_acc = df[ACCOUNT].to_numpy(dtype=object) if ACCOUNT in df.columns else None
    for r in rows:
        n = r["name"].strip()
        mt = info[n]["model_type"]
        if n in jb and n in rb:
            jn[n], tr[n] = _typed(jb[n], mt).to_numpy()[june], _typed(rb[n], mt).to_numpy()[ref_rows]
            jn_acc[n] = ev_acc
            tr_acc[n] = sub[ACCOUNT].to_numpy(dtype=object)[ref_rows] if ACCOUNT in sub.columns else None
            ref[n] = f"{last} rebuilt from {ref_day} (no earlier row)"
            if n in ev.columns:
                d = differing_rows(ev[n], jb[n], mt)
                if d:
                    res["june_stored_differs"][n] = d
            continue
        if n in ev.columns:
            v = ev[n]
        elif r["recipe"].strip() in ("", "raw"):
            v = builder.raw_values(r, ev)
        else:
            v = jb.get(n)
        if v is None:
            res["skipped"][n] = jfail.get(n, "no June column and no recipe to build it")
            continue
        jn[n], tr[n] = _typed(v, mt).to_numpy()[june], np.asarray(new[n])
        jn_acc[n] = ev_acc
        tr_acc[n] = df_acc if df_acc is not None and len(df_acc) == len(tr[n]) else None
        why = rfail.get(n) or jfail.get(n) or train_failed.get(n)
        if why:
            res["reference_fallback"][n] = why
            ref[n] = f"whole training stream (reference rebuild failed: {why_not_run(why)})"
        elif last is None and n in jb:
            ref[n] = f"whole training stream (no reference month: {_not_used(choice['tried'], min_rows)})"
        else:
            ref[n] = "whole training stream (history not matched)"
    seed = getattr(a, "seed", 42)
    for n in jn:  # one column at a time: the two sides have different row counts per field
        cat = info[n]["model_type"] == "categorical"
        one = S.feature_drift(pd.DataFrame({n: pd.Series(tr[n])}), pd.DataFrame({n: pd.Series(jn[n])}), [n],
                              [n] if cat else [], threshold=a.drift_threshold)["columns"][n]
        ra, ja = tr_acc.get(n), jn_acc.get(n)
        by_acc = ra is not None
        q = drift_null(tr[n], len(jn[n]), cat, seed=_field_seed(seed, n), ref_accounts=ra if by_acc else None)
        cut = float(a.drift_threshold) if q is None else max(float(a.drift_threshold), q)
        res["columns"][n] = {**one, "flag": bool(one["psi"] > cut), "cut": cut, "null_psi_q95": q,
                             "null_resamples": "accounts" if by_acc else "rows",
                             "reference": ref[n], "reference_rows": int(len(tr[n])), "june_rows": int(len(jn[n]))}
        if by_acc:
            res["columns"][n]["reference_accounts"] = int(pd.Series(ra).astype(str).nunique())
        if ja is not None:
            res["columns"][n]["june_accounts"] = int(pd.Series(ja).astype(str).nunique())
        if res["columns"][n]["flag"]:
            res["flagged"].append(n)
    res["flagged"] = sorted(res["flagged"])
    return res


# ------------------------------------------------------------------------------------------- host limits

GIB = 1 << 30
_NO_LIMIT = 1 << 60  # cgroup v1 writes a huge number for "no limit"


def _read_file(path):
    try:
        return Path(path).read_text()
    except (OSError, UnicodeDecodeError):
        return None


def _int(text):
    try:
        return int(str(text).strip().split()[0])
    except (ValueError, IndexError, TypeError):
        return None


def _stat(read, path, keys):
    have = {}
    for line in (read(path) or "").splitlines():
        k, _, v = line.partition(" ")
        have[k] = v
    for k in keys:
        if k in have:
            return _int(have[k])
    return None


def _cgroup_dirs(read, controller):
    """This process's cgroup folders for one controller (None: the cgroup v2 line '0::/path'), the most
    specific first, then each parent up to the mount root."""
    out = []
    for line in (read("/proc/self/cgroup") or "").splitlines():
        parts = line.strip().split(":", 2)
        if len(parts) != 3:
            continue
        ctrls, path = parts[1], parts[2].strip() or "/"
        if controller is None:
            if parts[0] != "0" or ctrls:
                continue
            roots = ["/sys/fs/cgroup", "/sys/fs/cgroup/unified"]
        else:
            if controller not in ctrls.split(","):
                continue
            roots = [f"/sys/fs/cgroup/{ctrls}", f"/sys/fs/cgroup/{controller}"]
        for root in dict.fromkeys(roots):
            p = path
            while True:
                out.append(root + ("" if p == "/" else p))
                if p == "/":
                    break
                p = p.rsplit("/", 1)[0] or "/"
    return list(dict.fromkeys(out))


def resource_limits(read=None, affinity=None):
    """Free memory and usable CPUs as this process's container sees them (design review item 27).

    free_gib, in GiB (2**30 bytes, the field checks' unit): the smaller of the host's MemAvailable and the
    cgroup headroom. The headroom is the memory limit minus the working set (usage minus inactive file cache,
    as the container runtime counts it), the smallest over this process's cgroup and its parents: cgroup v2
    (memory.max, memory.current, memory.stat) or v1 (memory.limit_in_bytes, memory.usage_in_bytes).
    cpus: the smaller of the CPUs this process may run on (sched_getaffinity) and the cgroup CPU quota (v2
    cpu.max, v1 cpu.cfs_quota_us over cpu.cfs_period_us), at least 1.
    `read(path) -> text or None` and `affinity` (a CPU count) are injectable for tests."""
    read = read or _read_file
    host = None
    for line in (read("/proc/meminfo") or "").splitlines():
        if line.startswith("MemAvailable:"):
            kb = _int(line.split(":", 1)[1])
            host = None if kb is None else kb * 1024 / GIB
    head = limit = None
    kind = "none"
    for ctl, lim_f, use_f, inact in ((None, "memory.max", "memory.current", ("inactive_file",)),
                                     ("memory", "memory.limit_in_bytes", "memory.usage_in_bytes",
                                      ("total_inactive_file", "inactive_file"))):
        for d in _cgroup_dirs(read, ctl):
            lim, use = _int(read(f"{d}/{lim_f}")), _int(read(f"{d}/{use_f}"))
            if lim is None or lim >= _NO_LIMIT or use is None:
                continue
            ws = max(0, use - (_stat(read, f"{d}/memory.stat", inact) or 0))
            h = max(0, lim - ws) / GIB
            if head is None or h < head:
                head, limit, kind = h, lim / GIB, ("v2" if ctl is None else "v1")
    quota = None
    for d in _cgroup_dirs(read, None):
        q = (read(f"{d}/cpu.max") or "").split()
        if len(q) == 2 and q[0] != "max" and _int(q[0]) and _int(q[1]):
            quota = min(quota or float("inf"), _int(q[0]) / _int(q[1]))
    for d in _cgroup_dirs(read, "cpu"):
        q, p = _int(read(f"{d}/cpu.cfs_quota_us")), _int(read(f"{d}/cpu.cfs_period_us"))
        if q and q > 0 and p:
            quota = min(quota or float("inf"), q / p)
    if affinity is None:
        try:
            affinity = len(os.sched_getaffinity(0))
        except (AttributeError, OSError):
            affinity = os.cpu_count() or 1
    cpus = int(affinity) if quota is None else min(int(affinity), max(1, int(quota)))
    free = host if head is None else (head if host is None else min(host, head))
    rnd = (lambda x: None if x is None else round(float(x), 2))
    return {"free_gib": rnd(free), "host_available_gib": rnd(host), "cgroup": kind, "cgroup_limit_gib": rnd(limit),
            "cgroup_headroom_gib": rnd(head), "cpus": max(1, cpus), "cpus_affinity": int(affinity),
            "cpu_quota": None if quota is None else round(quota, 3)}


def shared_limits(com):
    """nf_common's shared helper when the spine carries it (one rule for the field checks and the screen),
    else this module's copy of it."""
    fn = getattr(com, "resource_limits", None)
    return fn if callable(fn) else resource_limits


# ------------------------------------------------------------------------------------------- memory

BYTES_PER_CELL_READ = 140  # text cell when no sample can be read (measured on the old screen)
BYTES_PER_NUMBER = 8
BYTES_PER_CELL_FIT = 8 * 4  # two design matrices, the fit's own copy and the held-out predictions, in 8-byte cells
BYTES_PER_CODE_TEXT = 56  # a short code turned into a Python string (a code column stored as a number)
TEXT_SAMPLE_ROWS = 5000


class _parquet:
    """A parquet file's footer and rows, local or through the S3 filesystem; the handle is closed after use."""

    def __init__(self, path, fs):
        self.path, self.fs, self.fh = path, fs, None

    def __enter__(self):
        import pyarrow.parquet as pq
        if self.fs is None:
            return pq.ParquetFile(self.path)
        self.fh = self.fs.open(str(self.path).split("://", 1)[-1], "rb")
        return pq.ParquetFile(self.fh)

    def __exit__(self, *exc):
        if self.fh is not None:
            self.fh.close()
        return False


def file_rows(path, fs):
    """Row count from the parquet footer only (no rows read)."""
    with _parquet(path, fs) as pf:
        return pf.metadata.num_rows


def cell_widths(path, fs, columns):
    """Bytes per row of each column as pandas holds it after the read, from the file's footer types: 8 for
    numbers and times, 1 for flags, and for text the deep size measured on the file's first rows."""
    with _parquet(path, fs) as pf:
        return _cell_widths(pf, columns)


def _cell_widths(pf, columns):
    import pyarrow as pa
    schema = pf.schema_arrow
    widths, text = {}, []
    for c in columns:
        if c not in schema.names:
            continue
        t = schema.field(c).type
        if pa.types.is_boolean(t):
            widths[c] = 1.0
        elif pa.types.is_integer(t) or pa.types.is_floating(t) or pa.types.is_temporal(t) or pa.types.is_decimal(t):
            widths[c] = float(BYTES_PER_NUMBER)
        else:
            text.append(c)
    if text:
        try:
            s = next(pf.iter_batches(batch_size=TEXT_SAMPLE_ROWS, columns=text)).to_pandas()
            for c in text:
                widths[c] = max(float(BYTES_PER_NUMBER), float(s[c].memory_usage(deep=True, index=False)) / max(1, len(s)))
        except Exception:
            widths.update({c: float(BYTES_PER_CELL_READ) for c in text})
    return widths


def _months(a, b):
    try:
        pa_, pb = pd.Period(str(a)[:7], "M"), pd.Period(str(b)[:7], "M")
        return max(1, (pb - pa_).n)
    except Exception:
        return 1


def memory_guard(a, com, files, fs, want, n_new, drift_files=(), limits=None, code_cols=()):
    """Design review item 27: refuse below the field checks' free-memory level, or when the projected peak is
    above the allowed share of free memory. Free memory is the container's (cgroup) or the host's, whichever is
    smaller, in GiB. The projection uses the parquet footers (rows, column types) and a small text sample, and
    holds two stages: the fits (the frame, its working copy, the new fields, the fit matrices) and the June
    read at the end (the frame, the new fields, the June frame and its builds, the reference rebuild; the
    working copy is freed first). A code column stored as a number (`code_cols`) becomes text in the working
    copy and is costed as a short string. Every part is printed."""
    try:
        floor = float(a.min_free_gb if a.min_free_gb is not None else com.thresholds().get("min_free_host_gb", 32))
    except Exception:
        floor = 32.0 if a.min_free_gb is None else float(a.min_free_gb)
    rows = int(sum(file_rows(f, fs) for f in files))
    ev_rows = int(sum(file_rows(f, fs) for f in (drift_files or [])))
    widths = cell_widths(files[0], fs, want) if files else {}
    present = [c for c in want if c in widths]
    w_read = sum(widths[c] for c in present)
    w_june = sum(widths[c] for c in present if c != LABEL)
    ref_share = min(1.0, 2.0 / _months(a.extract_start, a.drift_extract_start)) if drift_files else 0.0
    numeric_codes = sum(1 for c in dict.fromkeys(code_cols) if widths.get(c) == BYTES_PER_NUMBER)
    part = {
        "frame": rows * w_read,
        "working_copy": rows * (BYTES_PER_NUMBER * (len(present) + n_new + 1) + BYTES_PER_CODE_TEXT * numeric_codes),
        "new_fields": rows * BYTES_PER_NUMBER * n_new * 2,  # the values and the rebuilt copy the probe reuses
        "fit_matrices": rows * (len(present) + n_new + 8) * BYTES_PER_CELL_FIT,
        "june_frame": ev_rows * w_june,
        "june_builds": ev_rows * BYTES_PER_NUMBER * n_new * 2,
        "june_reference": rows * ref_share * (w_read + BYTES_PER_NUMBER * n_new),
    }
    part = {k: v / GIB for k, v in part.items()}
    stage_fits = part["frame"] + part["working_copy"] + part["new_fields"] + part["fit_matrices"]
    stage_june = part["frame"] + part["new_fields"] + part["june_frame"] + part["june_builds"] + part["june_reference"]
    peak = max(stage_fits, stage_june)
    lim = limits if limits is not None else resource_limits()
    free = lim.get("free_gib")
    refused = None
    if free is not None and free < floor:
        refused = (f"free memory {free} GiB is below {floor} GiB (CHECK_THRESHOLDS.yaml min_free_host_gb; "
                   f"host {lim.get('host_available_gib')} GiB, cgroup {lim.get('cgroup')} headroom "
                   f"{lim.get('cgroup_headroom_gib')} GiB)")
    elif free is not None and peak > a.max_memory_share * free:
        refused = (f"projected peak {peak:.2f} GiB is above {a.max_memory_share:.0%} of free memory {free} GiB; "
                   "use fewer files or fewer fields")
    return {"unit": "GiB", "rows": rows, "june_file_rows": ev_rows, "columns_read": len(present),
            "bytes_per_row_read": w_read, "cell_bytes": widths, "parts_gib": part,
            "stage_fits_gib": stage_fits, "stage_june_gib": stage_june, "projected_peak_gib": peak,
            "free_gib": free, "limits": lim, "min_free_gib": floor,
            "max_memory_share": a.max_memory_share, "refused": refused}


# ------------------------------------------------------------------------------------------- main

def parse(argv):
    p = argparse.ArgumentParser(description="CPU screen (XGBoost's view, not the transformer's). Decides nothing.")
    p.add_argument("--dry-run", action="store_true", help="build a tiny synthetic world in a temporary folder and run")
    p.add_argument("--map", help="the field map (FIELD_MAP.csv)")
    p.add_argument("--status", help="field_status.csv of the field checks (field, result, reasons)")
    p.add_argument("--allow-unchecked", action="store_true",
                   help="screen map rows that have no check result yet (the screen says UNCHECKED)")
    p.add_argument("--clusters", help="clusters.csv of the field checks (cluster_id, member, ...); default: the "
                                      "field status file's cluster_id, else the map's cluster_id")
    p.add_argument("--predictors", default=str(ROOT / "fraud" / "configs" / "predictors.csv"))
    p.add_argument("--files", nargs="+")
    p.add_argument("--base")
    p.add_argument("--start", type=int)
    p.add_argument("--end", type=int)
    p.add_argument("--cred-path", help="S3 credentials file; read, never copied")
    p.add_argument("--extract-start", default="2024-10-01")
    p.add_argument("--k", type=int, default=5)
    p.add_argument("--n-boot", type=int, default=500)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--extra-seeds", nargs="*", type=int, default=[43, 44])
    p.add_argument("--train-neg-rate", type=float, default=1.0)
    p.add_argument("--temporal-split", default=None,
                   help=f"the chronological screen: train before, test at or after (default {DEFAULT_SPLIT}; "
                        "'none' switches it off)")
    p.add_argument("--no-label-shuffle", action="store_true", help="skip the label-shuffle probe per family")
    p.add_argument("--history-lite", action="store_true", help="also screen each family on top of the previous 5 rows")
    p.add_argument("--families", nargs="*", default=list(MAP_FAMILIES),
                   help="map families to screen (tfm, f15298, a3, all_new); empty ones are skipped and listed")
    p.add_argument("--oct26", nargs="*", default=[], help="26 October families by name: " + ", ".join(OCT26_FAMILIES))
    p.add_argument("--shap-rows", type=int, default=200_000, help="held-out rows per fold for SHAP")
    p.add_argument("--perm-repeats", type=int, default=1)
    p.add_argument("--drift-files", nargs="*")
    p.add_argument("--drift-base")
    p.add_argument("--drift-start", type=int)
    p.add_argument("--drift-end", type=int)
    p.add_argument("--drift-extract-start", default="2025-05-01")
    p.add_argument("--drift-month", default="2025-06")
    p.add_argument("--drift-threshold", type=float, default=0.25, help="a field is flagged when PSI is above it")
    p.add_argument("--drift-min-rows", type=int, default=100,
                   help="below this many rows in --drift-month, June drift is not run and flags nothing; the "
                        "reference (the last training month, when it is a whole month) needs as many rows too, "
                        "else the month before it is the reference, else the whole training stream")
    p.add_argument("--max-hours", type=float, default=6.0, help="stop before the screen when the projection is above")
    p.add_argument("--min-free-gb", type=float, default=None,
                   help="refuse below this free memory in GiB, the container's or the host's, whichever is smaller "
                        "(default: CHECK_THRESHOLDS.yaml min_free_host_gb, 32)")
    p.add_argument("--max-memory-share", type=float, default=0.8,
                   help="refuse when the projected peak is above this share of the free memory")
    p.add_argument("--nthread", type=int, default=None,
                   help="CPU threads for the fits (default: half the CPUs this container may use)")
    p.add_argument("--params-json", default=None, help="XGBoost parameter overrides as JSON (tests)")
    p.add_argument("--out", default=None, help="output folder (default checkpoints/new_fields/screen)")
    return p.parse_args(argv)


def dry_run_args(a, tmp):
    """Point every input at a tiny synthetic world under `tmp`."""
    syn = _by_path("fsc_synth", HERE / "fsc_synth.py")
    com = sys.modules["nf_common"]
    w = syn.world(Path(tmp) / "world", field_map_columns=com.FIELD_MAP_COLUMNS)
    a.map, a.status, a.files, a.base = w["map"], w["status"], w["files"], None
    a.drift_files, a.drift_base = w["june"], None
    a.extract_start, a.drift_extract_start = w["extract_start"], w["june_extract_start"]
    a.temporal_split = a.temporal_split or w["temporal_split"]
    a.k, a.n_boot, a.extra_seeds = min(a.k, 3), min(a.n_boot, 100), a.extra_seeds[:2]
    a.params_json = a.params_json or json.dumps(DRY_PARAMS)
    a.out = a.out or str(Path(tmp) / "screen")
    if a.min_free_gb is None:
        a.min_free_gb = 0.0  # the dry run's world is a few megabytes
    a.predictors = str(Path(a.predictors))
    return syn


def main(argv=None, recipe_fn=None, read_limits=None):
    """`recipe_fn` and `read_limits` (a file reader for /proc and the cgroup files) are for tests."""
    a = parse(argv)
    M = modules()
    tmp = None
    try:
        if a.dry_run:
            tmp = tempfile.mkdtemp(prefix="fsc_dry_")
            syn = dry_run_args(a, tmp)
            recipe_fn, a._recipe_label = recipe_fn or syn.synth_builder, "synthetic builder (dry run)"
        rc = _main(a, M, recipe_fn, read_limits)
        if getattr(a, "_outdir", None) is not None:
            print(f"outputs: {Path(a._outdir).resolve()}")
        return rc
    finally:
        if tmp:  # the synthetic world is removed; the screen's outputs stay and their folder is printed
            shutil.rmtree(Path(tmp) / "world", ignore_errors=True)
            if not any(Path(tmp).iterdir()):  # --out was given elsewhere: nothing is left in the folder
                shutil.rmtree(tmp, ignore_errors=True)


def _main(a, M, recipe_fn, read_limits):
    lay, com, U, P, S = M["layout"], M["common"], M["U"], M["P"], M["S"]
    t_start = _time.perf_counter()
    layout = lay.resolve(["feature_list", "datetime_features", "s3"])
    lay.print_layout(layout)
    recipe_label = getattr(a, "_recipe_label", None)
    if not a.map:
        print("give --map (or --dry-run)")
        return com.ARGS
    if not U.xgboost_available():
        if not a.dry_run:
            print("xgboost is missing: the screen needs it (the scikit-learn fallback is for --dry-run only)")
            return com.REFUSED
        print("xgboost is missing: dry run with scikit-learn's HistGradientBoostingClassifier (no SHAP)")
        U.use_sklearn_fallback()
    if recipe_fn is None:
        recipe_fn, recipe_label = recipe_module()
    elif recipe_label is None:
        recipe_label = "recipe function given by the caller"
    bad = [f for f in a.families if f not in MAP_FAMILIES] + [f for f in a.oct26 if f not in OCT26_FAMILIES]
    if bad:
        print(f"unknown family name(s): {', '.join(bad)}; map families: {', '.join(MAP_FAMILIES)}; "
              f"26 October: {', '.join(OCT26_FAMILIES)}")
        return com.ARGS
    split = DEFAULT_SPLIT if a.temporal_split is None else a.temporal_split
    a.temporal_split = None if str(split).strip().lower() in OFF else str(split).strip()
    limits = shared_limits(com)(read=read_limits) if read_limits else shared_limits(com)()
    params = json.loads(a.params_json) if a.params_json else {}
    nthread = a.nthread or max(1, limits["cpus"] // 2)
    params = {**params, "n_jobs": nthread}
    outdir = Path(a.out) if a.out else com.out("screen", "screen.json").parent
    outdir.mkdir(parents=True, exist_ok=True)
    a._outdir = outdir

    # --- the field map, the field checks' results and the clusters (checked before any read)
    for flag, path in (("--map", a.map), ("--status", a.status), ("--clusters", a.clusters)):
        if path and not Path(path).is_file():
            print(f"{flag} {Path(path).name}: file not found")
            return com.ARGS
    fmap = com.read_field_map(a.map)
    status = read_status(a.status)
    checked = bool(status) or fmap["check_result"].str.strip().ne("").any()
    if not checked and not a.allow_unchecked:
        print("no field status: run the field checks first, or pass --allow-unchecked")
        return com.REFUSED
    try:
        clusters, clusters_source = map_clusters(fmap, a.clusters, a.status)
    except ValueError as e:
        print(f"bad --clusters: {e}")
        return com.ARGS
    num_b, cat_b, derived, order_col, base_all = base_inputs(a.predictors, lay)
    refusal = map_refusals(fmap, list(base_all) + list(derived), Path(a.map).name)
    if refusal:  # a name two rows share, or a base input's name: a wrong input, before any read
        print("\n".join(refusal))
        return com.ARGS
    parse_fn = recipe_parser()
    enter, left = select_fields(fmap, status, a.allow_unchecked, status_given=bool(a.status), parse_fn=parse_fn)
    listed = fmap[fmap["list_status"].str.strip() != "NOT_IN_OWNER_LIST"]
    list_status = ("CONFIRMED" if len(listed) and (listed["list_status"].str.strip() == "CONFIRMED").all()
                   else "UNCONFIRMED")
    # names a new field may not take, before any read: the reserved columns, with --history-lite the history-lite
    # columns, and with --oct26 the requested families' 26 October columns
    hl_cols, hl_cats = S.history_lite_columns()
    reserved = set(base_all) | set(derived) | {"time_delta", "null_noise", LABEL, ACCOUNT, TIME, TIE, order_col}
    oct_named = [(c, nm) for nm in a.oct26 for c in OCT26_FAMILIES.get(nm, [])]
    clash = clash_names(reserved, a.history_lite, hl_cols, oct_named)
    rows_ok = []
    for r in enter:
        why = clash_reason(r, clash)
        if why:
            left.append((r["name"].strip(), why))
        else:
            rows_ok.append(r)

    # --- inputs: the files, the June files and their drift month (an empty month is a wrong argument)
    fs = None
    if a.cred_path:
        mk = _s3_attr(lay, "thin_read_filesystem") or _s3_attr(lay, "make_s3_filesystem")
        fs = mk(a.cred_path)
    files = file_list(a.files, a.base, a.start, a.end, lay)
    drift_files = (file_list(a.drift_files, a.drift_base, a.drift_start, a.drift_end, lay)
                   if (a.drift_files or a.drift_base) else [])
    if drift_files:
        jrows = drift_month_rows(drift_files, fs, a.drift_month, lay)
        if jrows == 0:
            print(f"June drift: no rows in --drift-month {a.drift_month} in the {len(drift_files)} drift files; "
                  "check --drift-month and the drift file range (nothing was screened)")
            com.write_json(outdir / "drift.json", {"month": a.drift_month, "june_rows": 0, "files": len(drift_files),
                                                   "not_run": f"no rows in --drift-month {a.drift_month}"})
            return com.ARGS
    # the map's source columns and every column a recipe needs in the file (an a3 recipe needs every 26 October
    # input, though the map may list two); the future-invariance probe perturbs the same columns
    src_cols = sorted({c for r in rows_ok for c in read_columns(r, parse_fn)})
    want = list(dict.fromkeys(num_b + cat_b + [order_col, ACCOUNT, TIME, TIE, LABEL] + src_cols
                              + [r["name"].strip() for r in rows_ok]))
    if a.oct26:  # the raw fields the 26 October builders read besides the base inputs
        want += [c for c in OCT26_RAW if c not in want]
    code_cols = cat_b + [r["name"].strip() for r in rows_ok if r.get("model_type", "").strip() == "categorical"
                         or category_recipe(r["recipe"])]
    mem = memory_guard(a, com, files, fs, want, len(rows_ok), drift_files, limits, code_cols)
    pg = mem["parts_gib"]
    print(f"memory: free {mem['free_gib']} GiB (host {limits['host_available_gib']}, cgroup {limits['cgroup']} "
          f"headroom {limits['cgroup_headroom_gib']}), limit {mem['min_free_gib']} GiB; threads {nthread} of "
          f"{limits['cpus']} CPUs")
    print(f"memory: projected peak {mem['projected_peak_gib']:.2f} GiB = max(fits {mem['stage_fits_gib']:.2f}, "
          f"June {mem['stage_june_gib']:.2f}); {mem['rows']} rows, {mem['june_file_rows']} June file rows")
    print("memory parts GiB: " + ", ".join(f"{k} {v:.3f}" for k, v in pg.items()))
    if mem["refused"]:
        print("REFUSED: " + mem["refused"])
        com.write_json(outdir / "memory.json", mem)
        return com.REFUSED
    df, parts = read_files(files, fs, want, lay)
    mem["frame_gib"] = float(df.memory_usage(deep=True).sum() / GIB)
    df = add_calendar(naive_time(df), derived, order_col, lay)
    builder = Builder(lay, recipe_fn, recipe_label)

    # --- new fields, on the full stream before any target sampling: every recipe in one pass, file by file
    pre_mt = {}
    for r in rows_ok:
        n, mt = r["name"].strip(), r.get("model_type", "").strip()
        if not mt and n in df.columns:
            mt = "categorical" if is_code_dtype(df[n]) else "continuous"
        if mt:
            pre_mt[n] = mt
    t_build0 = _time.perf_counter()
    rebuilt, rebuild_failed = builder.rebuild_all([r for r in rows_ok if builder.can_recompute(r)], df,
                                                  a.extract_start, parts, "training", pre_mt)
    t_build = _time.perf_counter() - t_build0
    new, how, not_built, info, stored_differs = {}, {}, [], {}, {}
    for r in rows_ok:
        name, recipe = r["name"].strip(), r["recipe"].strip()
        if name in df.columns:
            v, h = df[name], "column in files"
        elif recipe in ("", "raw"):
            v = builder.raw_values(r, df)
            h = "raw source" if v is not None else "not built: the raw source column is not in the files"
        elif name in rebuilt:
            v, h = rebuilt[name], f"built ({builder.recipe_source})"
        elif name in rebuild_failed and rebuild_failed[name] != "no recipe module for this recipe":
            v, h = None, f"recipe failed: {rebuild_failed[name]}"
        else:
            v, h = None, "not built: no column in files and no recipe module for this recipe"
        if v is None:
            how[name] = h
            not_built.append((name, h))
            continue
        mtype = r.get("model_type", "").strip() or (
            "categorical" if (category_recipe(recipe) or is_code_dtype(v)) else "continuous")
        if name in df.columns and name in rebuilt:  # a stored column is compared with its own recipe
            d = differing_rows(v, rebuilt[name], mtype)
            if d:
                stored_differs[name] = d
                h += f"; stored differs from recipe ({d} rows)"
            else:
                h += "; equals its recipe"
        elif name in df.columns and name in rebuild_failed:
            h += f"; recipe not rebuilt ({why_not_run(rebuild_failed[name])})"
        how[name] = h
        info[name] = {"group": r["group"].strip(), "kind": r["kind"].strip(), "model_type": mtype,
                      "recipe": recipe, "cluster_id": r.get("cluster_id", "").strip(), "how": h}
        new[name] = as_code(v) if mtype == "categorical" else pd.to_numeric(pd.Series(v), errors="coerce")
    data = df.copy()
    for c in cat_b:
        if c in data.columns:
            data[c] = as_code(data[c])
    for name, v in new.items():
        data[name] = np.asarray(v, dtype=object) if info[name]["model_type"] == "categorical" else np.asarray(v, float)
    data["null_noise"] = np.random.default_rng(a.seed + 7).normal(size=len(data))
    base = [c for c in base_all if c in data.columns]
    missing_base = [c for c in base_all if c not in data.columns]
    cats = [c for c in cat_b + derived if c in data.columns] + [n for n in new if info[n]["model_type"] == "categorical"]

    oct_cols = {}
    if a.oct26:
        f26 = builder.a3_frame(df, a.extract_start)
        for nm in a.oct26:
            oct_cols[nm] = [c for c in OCT26_FAMILIES.get(nm, []) if c in f26.columns]
            for c in oct_cols[nm]:
                if c not in data.columns:
                    data[c] = f26[c].to_numpy()
        cats += [c for c in OCT26_CATS if c in data.columns and c not in cats]

    families = {}
    for fam in a.families:
        if fam == "all_new":
            families[fam] = list(new)
        else:
            families[fam] = [n for n in new if GROUP_FAMILY.get(info[n]["group"]) == fam]
    for nm in a.oct26:
        families[f"oct26:{nm}"] = oct_cols.get(nm, [])
    families = {f: [c for c in dict.fromkeys(cols) if c not in base] for f, cols in families.items()}
    run_fams = {f: c for f, c in families.items() if c}
    skipped = {f: "no field of this family entered" for f, c in families.items() if not c}

    # the fields the future-invariance probe rebuilds (history recipes rebuilt above), and the ones it cannot
    history = [r for r in rows_ok if r["name"].strip() in new and r["recipe"].strip() not in ("", "raw")
               and not r["recipe"].strip().startswith("code(")]
    eng = [r for r in history if r["name"].strip() in rebuilt]
    not_run_reasons = {r["name"].strip(): rebuild_failed.get(r["name"].strip(), "no recipe module for this recipe")
                       for r in history if r["name"].strip() not in rebuilt}
    drift_rows = [r for r in rows_ok if r["name"].strip() in new and builder.can_recompute(r)
                  and r["name"].strip() in rebuilt]

    # --- cost guard: time one fold of the widest arm first; count every later recipe build pass
    widest = list(dict.fromkeys(base + list(new) + [c for cols in oct_cols.values() for c in cols]))
    month_ok = "month" in base and bool(new)
    n_fits = count_fits(a.k, len(run_fams), len(a.extra_seeds), bool(a.temporal_split), not a.no_label_shuffle,
                        a.history_lite, month_ok)
    t_fit, t_pred = time_one_fit(U, data, widest, cats, a.k, a.seed, params, a.train_neg_rate)
    arm = set(base) | set(new)
    n_cl = sum(1 for m in clusters.values() if len(set(m) & arm) >= 2)
    n_perm = a.k * a.perm_repeats * (len(base) + len(new) + n_cl)
    ref_pick = reference_choice(df, max(1, int(a.drift_min_rows or 1)))
    tt = pd.to_datetime(df[TIME])
    ref_share = (0.0 if ref_pick["month"] is None or not len(df) else
                 float(((tt >= ref_pick["start"]) & (tt < ref_pick["end"])).mean()))
    later = {}
    if eng:
        later["future invariance (perturbed)"] = t_build  # at most the whole frame again
    if drift_files and drift_rows:
        later["June"] = t_build * mem["june_file_rows"] / max(1, len(df))
        if ref_share:
            later["June reference"] = t_build * ref_share
    proj_h = (n_fits * t_fit + n_perm * t_pred + sum(later.values())) / 3600
    # the ranking without flagged fields runs only when a field is flagged and the time left allows it
    extra_h = (a.k * t_fit + a.k * a.perm_repeats * (len(new) + n_cl) * t_pred) / 3600
    cost = {"fit_seconds_widest": t_fit, "predict_seconds_fold": t_pred, "fits": n_fits, "permutations": n_perm,
            "build_seconds": t_build, "builds": {"measured": {"training": t_build}, "projected": later},
            "projected_hours": proj_h, "max_hours": a.max_hours, "unflagged_ranking_hours_at_most": extra_h, "rows": int(len(data)), "width": len(widest),
            "not_counted": "SHAP contributions, the bootstraps and the 26 October builders (small next to the fits)"}
    print(f"cost: one fit {t_fit:.1f}s at width {len(widest)}; {n_fits} fits + {n_perm} permuted predictions "
          f"+ {len(later)} recipe build passes ({sum(later.values()):.0f}s) -> about {proj_h:.2f} h "
          f"(limit {a.max_hours} h); the ranking without flagged fields adds at most {extra_h:.2f} h, only "
          "when a field is flagged and time is left")
    if proj_h > a.max_hours:
        print(f"REFUSED: projected {proj_h:.2f} h is above --max-hours {a.max_hours}. "
              "Try --train-neg-rate 0.1, fewer families, or raise --max-hours.")
        com.write_json(outdir / "cost.json", cost)
        return com.REFUSED

    kw = dict(k=a.k, seed=a.seed, n_boot=a.n_boot, train_neg_rate=a.train_neg_rate, params=params)
    out = {"view": U.VIEW, "decides": "nothing: XGBoost has no history window; adoption is decided by transformer fits",
           "layout": layout.layout, "model": U.MODEL["name"], "recipes": recipe_label,
           "versions": {"python": platform.python_version(), "pandas": pd.__version__, "numpy": np.__version__},
           "map": Path(a.map).name, "map_sha256": com.sha256_file(a.map), "list_status": list_status,
           "status": Path(a.status).name if a.status else ("map check_result" if checked else "UNCHECKED"),
           "files": len(files), "rows": int(len(data)), "frauds": int((pd.to_numeric(data[LABEL], errors="coerce") == 1).sum()),
           "accounts": int(data[ACCOUNT].nunique()), "base_columns_used": base, "missing_base_columns": missing_base,
           "new_fields": info, "left_out": [{"field": n, "reason": r} for n, r in left],
           "not_built": [{"field": n, "reason": r} for n, r in not_built],
           "pass_rule": U.PASS_RULE, "final_rule": U.FINAL_RULE, "cost": cost, "memory": mem, "threads": nthread,
           "temporal_split": a.temporal_split, "clusters_source": clusters_source,
           "families": {},
           "skipped_families": skipped}

    # --- probes: future invariance on every field built from a recipe (rebuilt, never the stored column). The cut
    # is drawn per value of each recipe's own history key (the account, or the customer or card its recipe names
    # with key=), one probe per key: a customer's rows on two accounts are cut at one time, so an honest customer
    # field is not moved by a later row of the customer's other account. No history key is perturbed.
    fi = {"ok": True, "probed": [], "changed_columns": {}}
    if eng:
        by_key = {}
        for r in eng:
            by_key.setdefault(history_key(r, parse_fn), []).append(r)
        keys = set(by_key) | {ACCOUNT}
        num_src = [c for c in dict.fromkeys(num_b + src_cols) if c in df.columns and c not in cat_b
                   and c not in (TIME, ACCOUNT, TIE, LABEL) and c not in keys and pd.api.types.is_numeric_dtype(df[c])]
        cat_src = [c for c in dict.fromkeys(cat_b + src_cols) if c in df.columns and c not in num_src
                   and c not in (TIME, ACCOUNT, TIE, LABEL) and c not in keys]
        pert_failed = {}
        fi.update(rows_checked=0, rows_perturbed=0, rows_deleted=0, cut_by={})
        for key, grp in by_key.items():
            names = [r["name"].strip() for r in grp]
            if key not in df.columns:
                for n in names:
                    pert_failed[n] = f"history key {key} is not in the files"
                continue
            whole = pd.DataFrame({n: np.asarray(rebuilt[n]) for n in names}, index=df.index)  # the training pass

            def feature_fn(d, grp=grp, names=names, whole=whole):
                if d is df:
                    return whole
                vals, bad = builder.rebuild_all(grp, d, a.extract_start, parts.loc[d.index],
                                                "future invariance (perturbed)",
                                                {**pre_mt, **{n: info[n]["model_type"] for n in names}})
                pert_failed.update(bad)
                return pd.DataFrame({n: (np.asarray(vals[n]) if n in vals else np.full(len(d), np.nan))
                                     for n in names}, index=d.index)

            one = P.future_invariance(df, feature_fn, account=key, numeric_cols=num_src, shuffle_cols=cat_src,
                                      seed=a.seed)
            fi["changed_columns"].update(one["changed_columns"])
            for k in ("rows_checked", "rows_perturbed", "rows_deleted"):
                fi[k] += one[k]
            fi["cut_by"][key] = sorted(names)
        for n, why in pert_failed.items():  # no evidence either way for a field whose perturbed rebuild failed
            fi["changed_columns"].pop(n, None)
            not_run_reasons[n] = "perturbed rebuild failed: " + why
        fi["ok"] = not fi["changed_columns"]
        fi["probed"] = sorted(r["name"].strip() for r in eng if r["name"].strip() not in pert_failed)
        fi["perturbed_numeric"], fi["perturbed_codes"] = num_src, cat_src
    fi["not_run"] = sorted(not_run_reasons)  # fields whose recipe cannot be rebuilt here: no evidence either way
    fi["not_run_reasons"] = not_run_reasons
    fi["stored_differs"] = stored_differs  # stored columns that are not what their recipe gives: not shown
    fi["history_fields"] = len(history)
    if fi["ok"] and (not_run_reasons or stored_differs):
        fi["ok"] = None
    out["future_invariance"] = fi
    leaky_fields = set(fi.get("changed_columns", {}))
    unknown_fields = set(not_run_reasons) | set(stored_differs)

    # --- the noise floor first: null_noise and the base arm at the extra XGBoost seeds
    null = U.run_screen(data, base, ["null_noise"], cats, permute=False, **kw)
    base_aps = {a.seed: null["pooled_ap_base"]}
    base_aps.update(U.base_refit_aps(data, base, cats, k=a.k, seed=a.seed, model_seeds=a.extra_seeds,
                                     train_neg_rate=a.train_neg_rate, params=params))
    floor = U.noise_floor(null, base_aps)
    out["null_noise"], out["base_ap_by_model_seed"], out["noise_floor"] = null, {str(s): v for s, v in base_aps.items()}, floor

    if a.history_lite:  # its column names are in the clash set (above), so no new field takes one
        hl = S.history_lite(df)
        for c in hl.columns:
            data[c] = hl[c].to_numpy()
    for fam, cols in run_fams.items():
        r = U.run_screen(data, base, cols, cats, **kw)
        r["columns_used"] = cols
        r["single_feature_ap"] = P.single_feature_ap(data, [c for c in cols if c not in cats], r["pooled_ap_base"])
        if not a.no_label_shuffle:
            # the probe's own seed (7) shuffles the labels; its inner screen uses run_screen's default seed (42)
            r["label_shuffle"] = P.label_shuffle(data, base, cols, cats, **{x: v for x, v in kw.items() if x != "seed"})
        if a.history_lite:
            r["on_history_lite"] = U.run_screen(data, base + hl_cols, cols, cats + hl_cats, permute=False, **kw)
        if a.temporal_split:
            r["temporal"] = S.temporal_screen(data, base, cols, a.temporal_split, cats, **kw)
        r["final_pass"] = U.final_decision(r, floor["floor"])
        r["leaky_fields"] = sorted(set(cols) & leaky_fields)
        r["leaky"] = bool(r["leaky_fields"]) or not r.get("label_shuffle", {"ok": True})["ok"]
        r["future_invariance_not_run"] = sorted(set(cols) & unknown_fields)
        out["families"][fam] = r

    # --- month on top: base plus all new fields, with and without month, on folds and on the time split
    if month_ok:
        no_month = list(dict.fromkeys([c for c in base if c != "month"] + list(new)))
        mo = {"arm": "base plus all new fields; family = month", "folds": U.run_screen(data, no_month, ["month"], cats,
                                                                                     permute=False, **kw)}
        if a.temporal_split:
            mo["time_split"] = S.temporal_screen(data, no_month, ["month"], a.temporal_split, cats, **kw)
            ts = mo["time_split"]
            # the same bar as FINAL_RULE: the interval's lower end must clear the noise floor
            mo["month_adds_on_time_split"] = (None if "skipped" in ts else
                                              bool(ts["delta_ci95_account_bootstrap"][0] > floor["floor"]))
            mo["rule"] = "month adds when the time-split interval's lower end exceeds max(0, noise floor)"
        mo["note"] = "account folds see every month in training and overstate month; read the time split"
        out["month_on_top"] = mo

    # --- per-feature ranking on the all_new arm
    rank = U.feature_rank(data, base, list(new), cats, clusters=clusters, k=a.k, seed=a.seed, params=params,
                          train_neg_rate=a.train_neg_rate, shap_rows=a.shap_rows, perm_repeats=a.perm_repeats)
    out["feature_rank"] = rank

    # --- the same ranking without the flagged fields: a label echo or a look-ahead takes the credit of the rest
    flagged = flagged_fields(out, new)
    clean = [c for c in new if c not in flagged]
    if flagged:
        r2 = {"left_out": flagged}
        n_cl2 = sum(1 for m in clusters.values() if len(set(m) & (set(base) | set(clean))) >= 2)
        need_h = (a.k * t_fit + a.k * a.perm_repeats * (len(clean) + n_cl2) * t_pred) / 3600
        used_h = (_time.perf_counter() - t_start) / 3600
        if not clean:
            r2["skipped"] = "every new field is flagged"
        elif used_h + need_h > a.max_hours:
            r2["skipped"] = f"not run: {used_h:.2f} h used + {need_h:.2f} h needed is above --max-hours {a.max_hours}"
        else:
            r2.update(U.feature_rank(data, base, clean, cats, clusters=clusters, k=a.k, seed=a.seed, params=params,
                                     train_neg_rate=a.train_neg_rate, shap_rows=a.shap_rows,
                                     perm_repeats=a.perm_repeats, rank_cols=clean))
        out["feature_rank_unflagged"] = r2
    del data  # the working copy is not needed by June drift or the outputs (the memory projection counts this)

    # --- June drift (no labels read)
    if drift_files and new:
        ev, ev_parts = read_files(drift_files, fs, [c for c in want if c != LABEL], lay)
        ev = add_calendar(naive_time(ev), derived, order_col, lay)
        out["drift"] = june_drift(a, df, ev, rows_ok, new, info, builder, S, parts, ev_parts, rebuild_failed)
    cost["builds"]["done"] = builder.passes

    # --- outputs
    fr = rank_table(out, base, new, info, run_fams, not_built, clusters)
    fr.to_csv(outdir / "feature_rank.csv", index=False)
    cluster_table(rank).to_csv(outdir / "cluster_rank.csv", index=False)
    com.write_json(outdir / "screen.json", out)
    text = summary(out, fr, com, outdir)
    (outdir / "summary.txt").write_text(text + "\n")
    print(text)
    return com.OK


def flagged_fields(out, new):
    """{field: why} for the new fields the screen flags field by field: future invariance failed, a stored column
    that differs from its recipe, or a field too good alone. The ranking is also run without them."""
    fi = out["future_invariance"]
    why = {}
    for c in new:
        bits = []
        if c in fi.get("changed_columns", {}):
            bits.append("future invariance failed")
        if c in fi.get("stored_differs", {}):
            bits.append("stored differs from recipe")
        if any(v.get("too_good") for r in out["families"].values()
               for n, v in r["single_feature_ap"]["columns"].items() if n == c):
            bits.append("too good alone")
        if bits:
            why[c] = ", ".join(bits)
    return why


# The columns of feature_rank.csv. The per-feature summary of the field checks reads these by name: feature,
# shap_mean_abs, shap_rank_new, perm_ap_drop_mean, perm_rank_new and note (the screen's flags; blank when none).
# The new-field ranks come before the ranks among all arm columns, so a reader that takes the first rank
# column it finds also reads the new-field ranks. The unflagged_* columns come from the same ranking run
# without the flagged fields (blank for a flagged field, whose note says why); they come after every other
# SHAP and permutation column, so a reader that takes the first match never picks them. drift_cut is the
# field's own June drift cut (drift_flag: psi_june above it).
RANK_COLUMNS = ["feature", "group", "kind", "model_type", "recipe", "how_built", "cluster_id", "in_arm", "note",
                "shap_mean_abs", "shap_sum_abs", "shap_rows", "shap_rank_new", "shap_rank",
                "perm_ap_drop_mean", "perm_ap_drop_sd", "perm_n", "perm_rank_new", "perm_rank",
                "cluster_perm_ap_drop", "cluster_members", "single_feature_ap", "single_feature_too_good",
                "future_invariance", "families", "family_final_pass", "family_leaky", "psi_june",
                "missing_train", "missing_june", "drift_flag", "drift_cut", "drift_reference",
                "unflagged_shap_mean_abs", "unflagged_shap_rank_new", "unflagged_perm_ap_drop_mean",
                "unflagged_perm_rank_new", "view", "model"]


def _family_leak(r):
    return "True" if r["leaky"] else ("?" if r.get("future_invariance_not_run") else "False")


def feature_notes(out, new, fams):
    """The screen's flags per new field, as plain tokens joined with '; ' (blank when none). Every token is a
    reason for a person to look before keeping the field: the per-feature summary turns any note into review."""
    fi = out["future_invariance"]
    drift = out.get("drift", {})
    shuffle_failed = [f for f, r in out["families"].items() if not r.get("label_shuffle", {"ok": True})["ok"]]
    notes = {}
    for c in new:
        bits = []
        if c in fi.get("changed_columns", {}):
            bits.append("future_invariance_failed")
        if c in fi.get("stored_differs", {}):
            bits.append(f"stored_differs_from_recipe rows={fi['stored_differs'][c]}")
        if c in fi.get("not_run", []):
            bits.append("future_invariance_not_run")
        sfa = [out["families"][f]["single_feature_ap"]["columns"][c] for f in fams
               if c in fams[f] and c in out["families"][f]["single_feature_ap"]["columns"]]
        if sfa and sfa[0]["too_good"]:
            bits.append(f"too_good_alone ap={sfa[0]['ap']:.3f}")
        bits += [f"family_leaky:{f} label_shuffle" for f in shuffle_failed if c in fams.get(f, [])]
        dc = drift.get("columns", {}).get(c)
        if dc and dc.get("flag"):
            bits.append(f"drift_june psi={dc['psi']:.2f} cut={dc.get('cut', drift.get('threshold', 0.25)):.2f}")
        if c in drift.get("june_stored_differs", {}):
            bits.append(f"june_stored_differs_from_recipe rows={drift['june_stored_differs'][c]}")
        notes[c] = "; ".join(bits)
    return notes


def rank_table(out, base, new, info, fams, not_built, clusters=None):
    """One row per feature of the ranking arm (base and new) plus each new field that was not built."""
    rk = out["feature_rank"]
    shap = (rk["shap"] or {}).get("mean_abs", {})
    shap_sum = (rk["shap"] or {}).get("sum_abs", {})
    perm = rk["permutation"]
    cl = {m: (cid, v) for cid, v in rk["cluster_permutation"].items() for m in v["members"]}
    member_cluster = {m: cid for cid, ms in (clusters or {}).items() for m in ms}
    fi = out["future_invariance"]
    drift = out.get("drift", {}).get("columns", {})
    notes = feature_notes(out, new, fams)
    r2 = out.get("feature_rank_unflagged") or {}
    shap2 = (r2.get("shap") or {}).get("mean_abs", {})
    perm2 = r2.get("permutation", {})
    rows = []
    for c in rk["columns"]:
        i = info.get(c, {})
        fam_names = [f for f, cols in fams.items() if c in cols]
        sfa = [out["families"][f]["single_feature_ap"]["columns"].get(c) for f in fam_names
               if c in out["families"][f]["single_feature_ap"]["columns"]]
        cid, cv = cl.get(c, (member_cluster.get(c, i.get("cluster_id", "")), None))
        if c in new:
            bits = []
            if c in fi.get("changed_columns", {}):
                bits.append("failed")
            if c in fi.get("stored_differs", {}):
                bits.append(f"stored differs from recipe ({fi['stored_differs'][c]} rows)")
            if not bits:
                bits.append("ok" if c in fi.get("probed", []) else
                            f"not run ({why_not_run(fi['not_run_reasons'][c])})" if c in fi.get("not_run", []) else
                            "not needed (raw value or code)")
            fiv = "; ".join(bits)
        else:
            fiv = ""
        rows.append({"feature": c, "group": i.get("group", "base"), "kind": i.get("kind", "base input"),
                     "model_type": i.get("model_type", ""), "recipe": i.get("recipe", ""), "how_built": i.get("how", ""),
                     "cluster_id": cid, "in_arm": "yes", "note": notes.get(c, ""),
                     "shap_mean_abs": shap.get(c), "shap_sum_abs": shap_sum.get(c),
                     "shap_rows": (rk["shap"] or {}).get("rows"), "perm_ap_drop_mean": perm.get(c, {}).get("ap_drop_mean"),
                     "perm_ap_drop_sd": perm.get(c, {}).get("ap_drop_sd"), "perm_n": perm.get(c, {}).get("n"),
                     "cluster_perm_ap_drop": cv["ap_drop_mean"] if cv else None,
                     "cluster_members": ";".join(cv["members"]) if cv else "",
                     "single_feature_ap": sfa[0]["ap"] if sfa else None,
                     "single_feature_too_good": sfa[0]["too_good"] if sfa else None, "future_invariance": fiv,
                     "families": ";".join(fam_names),
                     "family_final_pass": ";".join(f"{f}={out['families'][f]['final_pass']}" for f in fam_names),
                     "family_leaky": ";".join(f"{f}={_family_leak(out['families'][f])}" for f in fam_names),
                     "psi_june": drift.get(c, {}).get("psi"), "missing_train": drift.get(c, {}).get("missing_train"),
                     "missing_june": drift.get(c, {}).get("missing_june"), "drift_flag": drift.get(c, {}).get("flag"),
                     "drift_cut": drift.get(c, {}).get("cut"), "drift_reference": drift.get(c, {}).get("reference", ""),
                     "unflagged_shap_mean_abs": shap2.get(c) if c in new else None,
                     "unflagged_perm_ap_drop_mean": perm2.get(c, {}).get("ap_drop_mean") if c in new else None,
                     "view": out["view"], "model": out["model"]})
    for n, reason in not_built:
        rows.append({"feature": n, "in_arm": "no", "how_built": reason, "note": "not_built",
                     "view": out["view"], "model": out["model"]})
    have = {r["feature"] for r in rows}
    for lo in out["left_out"]:  # every map row has a row, so a join on feature never loses one
        if lo["field"] in have:  # a name equal to a base input keeps the base input's row only
            continue
        clash = lo["reason"].startswith("name clashes")
        note = ("left_out_name_clash" if clash else lo["reason"] if lo["reason"].startswith("source_stop:") else "")
        rows.append({"feature": lo["field"], "in_arm": "no", "how_built": "left out: " + lo["reason"],
                     "note": note, "view": out["view"], "model": out["model"]})
    fr = pd.DataFrame(rows, columns=[c for c in RANK_COLUMNS])
    fr["note"] = fr["note"].fillna("")
    arm = fr["in_arm"] == "yes"
    isnew = arm & fr["feature"].isin(list(new))
    for col, src in (("shap_rank", "shap_mean_abs"), ("perm_rank", "perm_ap_drop_mean")):
        v = pd.to_numeric(fr[src], errors="coerce")
        fr[col] = v.where(arm).rank(ascending=False, method="min")
        fr[col + "_new"] = v.where(isnew).rank(ascending=False, method="min")
        v2 = pd.to_numeric(fr["unflagged_" + src], errors="coerce")
        fr[f"unflagged_{col}_new"] = v2.where(isnew).rank(ascending=False, method="min")
    order = pd.to_numeric(fr["shap_rank"], errors="coerce").fillna(pd.to_numeric(fr["perm_rank"], errors="coerce"))
    return fr.assign(_o=order).sort_values(["_o", "feature"], na_position="last").drop(columns="_o").reset_index(drop=True)


def cluster_table(rank):
    return pd.DataFrame([{"cluster_id": cid, "members": ";".join(v["members"]), "n_members": len(v["members"]),
                          "perm_ap_drop_mean": v["ap_drop_mean"], "perm_ap_drop_sd": v["ap_drop_sd"], "perm_n": v["n"],
                          "view": rank["view"]} for cid, v in rank["cluster_permutation"].items()],
                        columns=["cluster_id", "members", "n_members", "perm_ap_drop_mean", "perm_ap_drop_sd",
                                 "perm_n", "view"])


def _f(x, d=4):
    return "-" if x is None or (isinstance(x, float) and not np.isfinite(x)) else f"{x:.{d}f}"


def _num(x):
    """A number, or None for a blank or missing cell."""
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return v if np.isfinite(v) else None


def _names(names, width):
    """A list cut to fit, with the count of names left out."""
    names = list(names)
    if not names:
        return "none"
    shown, used = [], 0
    for n in names:
        if used + len(n) + 2 > width - 12 and shown:
            break
        shown.append(n)
        used += len(n) + 2
    rest = len(names) - len(shown)
    return ", ".join(shown) + (f" (+{rest} more)" if rest else "")


def summary(out, fr, com, outdir):
    """The one-screen summary: at most 40 lines of 90 characters."""
    L = []
    nf = out["noise_floor"]
    L.append(f"map={out['map']} {out['list_status']}  status={out['status']}  model={out['model'][:30]}")
    L.append(f"rows {out['rows']}  frauds {out['frauds']}  accounts {out['accounts']}  files {out['files']}  "
             f"base inputs {len(out['base_columns_used'])}  missing base {len(out['missing_base_columns'])}")
    counts = (f"new fields entered {len(out['new_fields'])}  not built {len(out['not_built'])}  "
              f"left out {len(out['left_out'])}")
    recipes = f"recipes: {out['recipes']}"
    if len(counts) + 2 + len(recipes) <= 90:
        L.append(f"{counts}  {recipes}")
    else:  # a long recipe label (a missing or broken recipe module) gets its own line, never a cut one
        L += [counts, f"  {recipes}"]
    stops = [(lo["field"], lo["reason"]) for lo in out["left_out"] if lo["reason"].startswith("source_stop:")]
    if stops:  # the field and the first source the checks stop or hold (the rule is in the note column)
        L.append("  source STOP or WAIT, left out: " +
                 _names([f"{n} ({r.split(';')[0][len('source_stop:'):].split(' ')[0]})" for n, r in stops], 57))
    L.append(f"noise floor {_f(nf['floor'])} (null |d| {_f(nf['null_abs_delta'])}, refit spread {_f(nf['refit_spread'])})")
    L.append("family                   n  dAP folds ci95 lo      hi pass fin | time dAP P | leak")
    for f, r in out["families"].items():
        ci = r["delta_ci95_account_bootstrap"]
        t = r.get("temporal", {})
        ts = ("skipped" if "skipped" in t else f"{_f(t.get('delta'))} {str(t.get('passed', '-'))[0]}") if t else "not run"
        lk = "YES" if r["leaky"] else ("?" if r.get("future_invariance_not_run") else "no")
        L.append(f"{f[:22]:<22} {len(r['columns_used']):>3} {_f(r['pooled_delta']):>10} {_f(ci[0]):>7} {_f(ci[1]):>7}"
                 f"  {str(r['passed'])[0]}    {str(r['final_pass'])[0]}  | {ts:<10} | {lk}")
    if out["skipped_families"]:
        L.append("skipped (no field entered): " + ", ".join(out["skipped_families"]))
    if "temporal_split" in out:
        L.append("account folds are not chronological; " +
                 (f"time split: train before {out['temporal_split']}, test after" if out["temporal_split"] else
                  "time split not run (--temporal-split none)"))
    mo = out.get("month_on_top")
    if mo:
        fo = mo["folds"]
        ts = mo.get("time_split", {})
        tss = ("not run" if not ts else "skipped" if "skipped" in ts else
               f"dAP {_f(ts['delta'])} [{_f(ts['delta_ci95_account_bootstrap'][0])}, "
               f"{_f(ts['delta_ci95_account_bootstrap'][1])}]")
        L.append(f"month on top: folds dAP {_f(fo['pooled_delta'])}; time split {tss}")
        if mo.get("month_adds_on_time_split") is not None:
            L.append("  month " + ("still adds on the time split" if mo["month_adds_on_time_split"]
                                   else "adds nothing shown on the time split (nothing is removed)"))
    fi = out["future_invariance"]
    bad = sorted(fi.get("changed_columns", {}))
    if not fi.get("history_fields", len(fi.get("probed", [])) + len(fi.get("not_run", []))) \
            and not fi.get("stored_differs") and not bad:
        L.append("future invariance: not run (no engineered field with a history recipe)")
    else:
        n_pr = len(fi.get("probed", []))
        if bad:
            L.append(f"future invariance: FAILED ({n_pr} rebuilt fields probed); LEAKY: {_names(bad, 46)}")
        elif fi.get("ok") is None:
            n_ns = len(set(fi.get("not_run", [])) | set(fi.get("stored_differs", {})))
            L.append(f"future invariance: NOT SHOWN for {n_ns} fields (below); ok on {n_pr} rebuilt fields")
        else:
            L.append(f"future invariance: ok on {n_pr} rebuilt fields")
    if fi.get("not_run"):
        why = Counter(why_not_run(v) for v in fi.get("not_run_reasons", {}).values())
        L.append(f"  not run on {len(fi['not_run'])} ({', '.join(f'{k} {v}' for k, v in sorted(why.items()))}): "
                 f"{_names(fi['not_run'], 34)}")
    if fi.get("stored_differs"):
        L.append(f"  stored column differs from its recipe: {_names(sorted(fi['stored_differs']), 48)}")
    too = sorted({c for r in out["families"].values() for c, v in r["single_feature_ap"]["columns"].items() if v["too_good"]})
    ls = sorted(f for f, r in out["families"].items() if not r.get("label_shuffle", {"ok": True})["ok"])
    L.append(f"label shuffle failed: {_names(ls, 66)}")
    L.append(f"too good alone: {_names(too, 72)}")
    d = out.get("drift")
    if not d:
        L.append("June drift: not run")
    elif d.get("not_run"):
        L.append(f"June drift: not run ({d['not_run']}); nothing flagged")
    else:
        if d.get("reference_month") == "whole training stream":
            L.append(f"June drift: {d['june_rows']} rows of {d['month']}; ref: the whole training stream")
        else:
            rr = d.get("reference_rows")
            L.append(f"June drift: {d['june_rows']} rows of {d['month']}; ref {d['reference_month']}"
                     + (f" ({rr} rows)" if rr is not None else "") + f" rebuilt from {d['reference_extract_start']}")
        skips = reference_skips(d)  # the months not taken as the reference, and why (the full note: screen.json)
        if skips:
            L.append(skips)
        L.append(("  " if d.get("reference_month") == "whole training stream" else "  else the whole stream; ")
                 + f"cut per field: max({d['threshold']}, 95th pct of PSI on resampled accounts)")
        raised = sorted((n, c["cut"]) for n, c in d.get("columns", {}).items()
                        if c.get("cut") is not None and c["cut"] > d["threshold"])
        if raised:
            L.append("  cut raised for: " + _names([f"{n} {c:.2f}" for n, c in raised], 72))
        L.append(f"  PSI > {d['threshold']} and above its cut: {_names(d['flagged'], 52)}")
        if d.get("reference_fallback"):
            L.append(f"  whole training stream used (reference rebuild failed): {_names(sorted(d['reference_fallback']), 32)}")
        if d.get("skipped"):
            L.append(f"  not compared (no June values): {_names(sorted(d['skipped']), 56)}")
    new = fr[(fr["in_arm"] == "yes") & fr["feature"].isin(list(out["new_fields"]))]
    key = "shap_rank_new" if new["shap_rank_new"].notna().any() else "perm_rank_new"
    new = new.sort_values(key)
    r2 = out.get("feature_rank_unflagged")
    if r2:
        L.append(f"w/o: {r2['skipped']}" if r2.get("skipped") else
                 f"w/o: rank without the {len(r2['left_out'])} flagged fields (too good alone, leaky, stored differs)")
    L.append(f"new fields by {'SHAP' if key == 'shap_rank_new' else 'permutation'} ({out['view']}):")
    L.append(f"{'rank':>4} {'name':<36} {'shap mean|abs|':>14} {'perm dAP':>9} {'PSI June':>8} {'cut':>5} {'w/o':>4} !")
    rows = list(new.itertuples())
    # the table takes the lines left on the screen (40 lines, with the title, the footer and the lines below it)
    cap = max(2, min(16, 38 - len(L) - 1 - (1 if out["not_built"] else 0)))
    if len(rows) <= min(15, cap):
        shown = rows
    elif cap >= 7:
        shown = rows[:cap - 6] + [None] + rows[-5:]
    else:
        shown = rows[:cap - 1] + [None]
    for r in shown:
        if r is None:
            L.append(f"... {len(rows) - len(shown) + 1} more fields in feature_rank.csv")
            continue
        flag = "!" if str(getattr(r, "note", "") or "").strip() not in ("", "nan") else ""
        wo = getattr(r, "unflagged_" + key, None)
        L.append(f"{_f(getattr(r, key), 0):>4} {str(r.feature)[:36]:<36} {_f(r.shap_mean_abs, 5):>14} "
                 f"{_f(r.perm_ap_drop_mean):>9} {_f(r.psi_june, 3):>8} {_f(_num(getattr(r, 'drift_cut', None)), 2):>5} "
                 f"{_f(wo, 0):>4} {flag}")
    if out["not_built"]:
        L.append(f"not built: {_names([n['field'] for n in out['not_built']], 74)}")
    L.append(f"full tables: {outdir.name}/feature_rank.csv (note column), cluster_rank.csv, screen.json")
    return com.screen(f"CPU SCREEN  {out['view']}  layout={out['layout']}", L,
                      "It decides nothing. Adoption is decided by the transformer fits.")


if __name__ == "__main__":
    sys.exit(main())
