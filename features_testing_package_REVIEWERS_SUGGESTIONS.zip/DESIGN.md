# Stage 2 features package: design

Reviewers, 2 November 2026; revised 3 November 2026 for the package (section R). This is the design of the stage 2 package (new input fields) for the reorganized pod. It applies the owner's stage 2 design of 2 November ("For V22B we're gonna run it on the seed that performed best for all pos B so we can compare with new features") and the three owner updates of the same day: the feature list comes from the owner and Copilot and includes engineered features; month stays in; every feature's usefulness is measured; and the feature-store view is kept.

**Read first.** The reviewers do not know the pod's state. The reorganization has been applied, but we do not know exactly how it turned out. Copilot adapts paths and commands to the pod. Copilot never changes the experiment: the steps, seeds, files, rules and thresholds below are the plan.

**Status.** The design of the package as delivered. The feature list is not confirmed (section 11, question 1). Nothing fits until the owner's list is adopted. The code was built and tested from this design on a reconstruction of the pod's code (package 009 with the three pod patches, pre-reorganization layout), not on the pod's code. Section R, next, lists every change made after the review.

## R. Revised for the package (read this first)

This design was reviewed (36 corrections), built in lanes, merged, checked twice and fixed before the package was
zipped. This section says what changed after the review. Where an older sentence below disagrees with this section,
this section is right, and the sections marked "(updated)" below say it in place.

- What runs is the tools and their tests. `NF/POD.md` is the run sheet, `FEATURES_AND_TESTING.md` the owner's
  step-by-step, and `TEST_RESULTS.md` the test counts to expect.
- Order of authority: the owner's decisions, then `PLAN.md`, then the final integration notes, then the review's
  corrections, then the text below.

### R.0 The reviewers' decisions of 2 November (D1 to D10), after this section was written

The reviewers decided the delegated questions D1 to D10 under the owner's delegation of 2 November. Where R.3, R.4
or R.5 below, or an older sentence, disagrees with them, the decisions are right. In short:

- Controls: every later step reads against a seed-42 refit of the kept recipe at the candidate's micro-batch
  (`refit_kept_control: true`, D5a). The base is refit at seeds 43 and 44 before the first read; the kept
  checkpoints are never controls (D5b).
- Month out (step B) is on by default, as the last stage 2 fitting step (D4c). Importance runs once, on the final
  kept fit after month out (D6). Pruning stays off, and the preflight refuses it until its three-seed step is built
  (D4b).
- Budget: the default steps A1, A2 and month out at most 170 epochs, 180 with a new seed-42 base control; A3 60 and
  pruning 20 when on; the cyclical calendar at most 60.
- Dates enter on a log scale: a past event as ln(1 + whole seconds) before the transaction, a known future date as
  sign(u) ln(1 + |u|) in days (D3b).
- UDR at the 0.6% outsort, counted in transactions, decides; T_1 uses the t value at the Welch-Satterthwaite
  degrees of freedom and the larger measured spread, with no fixed floor (D1, D2).
- The D2 correction of 3 November, applied in R.2 and section 8 below: T_1 = t
  x sqrt(sd_pair^2 + 2 x sd_run^2), a working rule for one seed that assumes the candidate and the control vary by
  the same amount from seed to seed. Nothing subtracts the pair term sd_null; the spread step prints it as
  information only. At three seeds LB_3 = gain - t x sqrt(v_acct + s_d^2 / k), s_d the SD of the k paired seed
  differences and t at k - 1 degrees of freedom. The SELECT check's limit is -k x sqrt(SE^2 + 2 x s_m^2 / n); its k
  values and the conflict line's are working rules for development whose error rates under unequal variances are not
  known. A UDR spread of zero is reported, not a stop: T_1 is then undefined because of the zero spread, and a
  one-seed gain above zero goes to seeds 43 and 44 instead of stopping. A T_1 that is not a number for any other
  reason still stops the read.

`FEATURES_AND_TESTING.md`, `README_FIRST.md` and `NF/POD.md` give each decision in full.

### R.1 The owner's naming rule

- No file of the package names the assistants that reviewed it or their makers. The word is "reviewer".
- No file holds an absolute path of a machine. Paths are relative to the project root on the pod.
- `NF/nf_naming_check.py` scans every file, every file and folder name, and the text inside the workbook. Any hit
  fails (exit 3).

### R.2 Decisions (the plan's rules; section 8.6 is updated)

- At one seed, the lower end LB of the interval is the account bootstrap's alone, because T_1 already carries the
  seed term.
- A gain at or above T_1 that also meets its rule (at or above the bar, LB above zero) is adopted at one seed,
  pending the SELECT check when RANK-B decides. Any other gain above zero runs seeds 43 and 44, so a larger gain
  never gets a worse outcome than a smaller one.
- A measured UDR seed spread of zero leaves T_1 undefined. At one seed, a gain above zero runs seeds 43 and 44;
  a nonpositive gain keeps the control (month or the current calendar for those steps). There is no one-seed
  adoption without T_1. A nonfinite gain, a required one-seed T_1 undefined for any other reason, or a nonfinite pruning
  upper bound stops the read (exit 3); a missing required spread refuses the read.
- At three seeds, LB_3 = g - t_(k-1)(0.95) x sqrt(v_acct + s_d^2 / k), with k = 3, s_d the sample SD of the
  paired seed differences and v_acct the account-bootstrap variance of their mean. No baseline spread is pooled
  into this bound, and no decision subtracts sd_null. Section 8.5 defines the one-seed Welch t threshold; section
  8.6 defines the SELECT check and its operational k values.
- Month out (step B) is read by the one-fit rule first (its gain is h), then by the month rule. At one seed,
  h of zero keeps month.
- Pruning (step P) is blocked in this package (D4b); the legacy reader's seed-42 path does not enable it.
- The optional cyclical calendar (step C) is read like month out, against the kept fit, with its SELECT check.
- The SELECT check also runs after MONTH OUT, KEEP THE SMALLER LIST and CALENDAR CYCLICAL.
- AP is computed whenever the rows hold a fraud (all frauds give 1.0, as scikit-learn gives). AUROC and KS need
  both classes, and are undefined otherwise.
- One lift tool: `nf_read.py lift` writes `reads/<step>_lift.json`; the downstream tool hands it its run table.
  The flag reads the UDR lift. The downstream job records the DS_SELECT predictions' SHA-256, and a changed file
  stops the read.
- A SELECT read must score the same checkpoints that earned the pending decision; another checkpoint stops it.

### R.3 Defaults the owner can change (`STEPS.yaml`, `SETTINGS.yaml`; section 6.1 is updated)

- Controls between steps: each later step's control is the previous step's kept fit, as it is (the owner's choice;
  review item 23 asked for the refit by default, and the owner decided otherwise). Every read says that fit's luck
  on RANK-B favours it. A refit at seed 42 first is the owner's option (`refit_kept_control: true`, 10 epochs more
  per later step).
- Base controls at seeds 43 and 44, when a confirmation at the base inputs needs them: refit by default (the plan's
  recommendation, `refit_base_controls_43_44: true`). Reusing the kept checkpoints is the owner's option; their
  selection bias is then written in `DECISIONS.log`.
- Permutation importance runs once, on the final kept fit (`importance: final`). Running it after every step is the
  owner's option (`importance: every_step`).
- TensorBoard is on (`tensorboard: true`). The queue's wrapper `NF/nf_fit.py` adds the logger in memory (the
  trainer runs with `logger=False`), and every fit logs to `checkpoints/new_fields/tb/<run>/seed<NN>/`. Training
  metrics, weights and checkpoints are the same with and without it (tested). `tensorboard: false` runs the trainer
  plainly.
- Optional steps, all off: A3, pruning (P), month out (B), and the cyclical calendar (C). Step C sets
  `datetime.encoding: cyclical` by config only, with `is_weekend` as a sub-option. It changes hour, day and day of
  week as well as month.
- Stride is not available for the chosen chunk model: its sequence builder refuses stride with all-position
  chunks. Class imbalance stays with the loss options of stage 3.
- If RANK-A or RANK-B fails its rank check, the plan's fallback files (8201-8205 with 8278-8300) get the same
  checks. RANK-B and the fallback failing: June SELECT decides. The fallback passing: the owner decides how it is
  used, and the queue and the reader wait until then. RANK-A failing: importance and attention wait for the owner.

### R.4 Budget (the plan's numbers; section 6.8 is updated)

- Default steps A1 and A2: at most 80 epochs (20 x C_c + 30 x C_f + 30 x C_g), plus 10 x C_c (90 in all) when a
  new seed-42 base control is fit (stage 0's best rate is not 3e-4, or the base artifact changed).
- Optional steps, each at most: A3 50, month out 50, pruning 10. The switch in place of A1 and A2: 50 (plus the
  same 10 for a new control). The refit option: 10 more per later step.
- The cyclical calendar step is not in the plan's budget. It is read like month out, so at most 50.
- The width timing counts the missing-flag column that preprocessing adds for each continuous field, so the width
  at about 190 fields is measured as it will run.

### R.5 Fields and recipes (section 2 is updated)

- Dates: a past event date enters as `days_before(c)`, days before the transaction. A known future date, such as
  card expiry, enters as `days_until(c)`: days until it, a signed difference, below zero once it has passed (map
  column `date_meaning = known_future_date`). A raw date stops.
- `code(c)` (15298's le1 and le3 outputs) is a proposed alternative, not proven equal to the original encoder. The
  check FLAGs it `encoding_alternative`, and the decisions table keeps the row unresolved until the encoder is
  documented.
- Postal codes: `geohash(postal_col; country_col)` is TFM's geohash of a postal code with its country, made from
  TFM's table (`SETTINGS.yaml` `geohash_table`) by TFM's own rules: trailing whitespace removed, a US (840) code
  cut to 5 characters, no match gives OTHER. It is a category. V22B ranks 8 (merchant postal code) and 30
  (cardholder postal code) use it, and their raw postal code is the proposed alternative. The 26 October distance
  features can take geohash cell centres as centroids when no centroid table exists, and that is coarse (precision
  3 is about 156 km cells).
- The draft lists are built from the cleaned records only. The 120 V22B chart rows are 78 yes, 13 hold, 29 no (the
  feature review moved ranks 6, 22, 40, 44, 48, 56 and 59 to hold). The 15298 list keeps all 94 outputs with the
  crosswalk's work types; an undefined recipe holds as `definition_needed`, and a multi-output field is never cast
  whole.
- One decisions table, `NF/KEEP_DECISIONS.csv`. The workbook's Final list, Excluded and Decisions sheets, and the
  pruning step, derive from it. Only a person's decision makes a row final.
- One recipe grammar, `NF/nf_recipes.py`. The intake, the field checks, the screen, the enriched copies and the
  importance tool all call it. A recipe may group by another raw key with `key=` (a different feature from the
  account version).
- The field map has `donor_unit` (account for a profile field, event for an event field; blank takes the default
  from the business category).

### R.6 The checks, the screen and the queue

- A field whose recipe reads a column that is missing from a file of any range is not built on any file. It stops
  with `missing_from_files`, naming the range, the file and the column, and the other fields are checked as usual.
- The status scan matches its short patterns (hold, close, susp, ato, frd) as whole tokens only, no longer uses
  stat or ring, and has an allow list with reasons in `STATUS_RULES.csv` (review item 7). The bank's decisions on
  the same transaction stop in raw form; their previous transaction's value, `prev(c)`, holds until the data owner
  confirms it (review item 10).
- Permutation importance follows `NF/IMPORTANCE.md` (review item 8): account donors for profile fields
  (`donor_unit = account`, or the business category "account and customer profile"), event donors for the others;
  inputs and supplied clusters are measured directly by default, and a family unit rebuilds its recipe
  dependencies through the shared builder. Calendar sensitivity holds timestamps fixed. It decides nothing.
- The GPU busy check reads the process table at `/proc`. `NF_PROC_ROOT` points it elsewhere for tests only; while
  it is set, the preflight stops at `process_table`.
- The CPU screen is in the package (`FS`, run sheet `FS/POD.md`). It leaves out an engineered field that reads a
  column the field checks STOP or WAIT (`source_stop`). June drift flags a field only above its own cut: the larger
  of 0.25 and the 95th percentile of PSI between resampled reference rows at the June row count, printed per field.
  The reference month must be a whole month with `--drift-min-rows` rows, else the month before it, else the whole
  training stream, with a note. The screen refuses (exit 2) a map with two rows of one name or a row named like a
  base input, and leaves out a field named like a history-lite or 26 October column before any read. A `code(c)` or
  `geohash(...)` row with a blank model_type is screened as a category.
- The field checks' temporal probes group by the recipe's own history key (`key=`), so a correct customer- or
  card-keyed field passes them and a leaky one still stops. The checks read every column a recipe needs, also one
  that the map's `source_columns` leave out, and an a3 field goes through every stage and probe.
- The queue lock is taken in one atomic step, so two queues started at once never both own it. A lock record that
  names no process refuses and names the file to remove. The morning report shows each fit by the planner's own
  fit state. Every command in `NF/POD.md` runs as written from the project root (`$C2` is set with `$PY`, `$NF`
  and `$FS`).

### R.7 The review's corrections, by the lane that applied them

Each lane applied the blocking and should items of its sections, and its report (kept with the integration
records) lists each item it applied or declined, with the reason.

| Lane | Review items |
|---|---|
| spine (resolver, settings, intake, guard, planner and queue, report, documents) | 1 (the naming check), 2 (the documents), 14, 15, 18, 19, 20, 21, 22, 23, 25, 26, 29, 33, 34, 36 |
| data (recipes, enriched copies, extended artifact) | 4, 5, 12, 17, 28, 31 |
| checks (CPU field checks, decisions proposer, summary) | 5, 6, 7, 9, 10, 11, 13, 28, 30, 32 |
| screen (the CPU screen) | 27, 32 |
| reader | 15, 20, 21, 35 |
| gpu (width timing, downstream check) | 16, 17 (GPU side), 24 |
| workbook (workbook, draft lists, decisions table) | 2 (the workbook and the decisions table), 3, 4 |
| importance | 8, 26 (never drop both twins of a cluster) |

### R.8 The integration's 13 decisions

| # | Decision |
|---|---|
| 1 | Attention is `nf_importance.py run --attention-only`. Both calls pass `--field-map`, `--clusters` and `--output`. Timing comes from the width timing record, else from the queue log's wall time of the latest scoring job. Missing or failed importance makes pruning wait with a line, never a crash |
| 2 | The intake's draft map is `DRAFT_FEATURE_ATTRIBUTES_UNCONFIRMED.csv`, one row per name |
| 3 | `code(c)` is a proposed alternative (FLAG `encoding_alternative`); the LE rows stay unresolved; the workbook shows it in `proposed_alternative` |
| 4 | One grammar: the intake calls `nf_recipes.parse`; `raw(x)` is refused |
| 5 | One lift tool, `nf_read.py lift`; its flag reads the UDR lift |
| 6 | Three metric engines are kept, with agreement tests; the importance tool checks itself against `nf_ranked` on every run |
| 7 | `donor_unit` is a field-map column, with a default from the kind of field |
| 8 | The workbook's `in_owner_list` comes from `list_status` and `list_source` |
| 9 | The run sheet says what the workbook builder reads |
| 10 | The SELECT check also runs after MONTH OUT, KEEP THE SMALLER LIST and CALENDAR CYCLICAL |
| 11 | The downstream summary records the DS_SELECT predictions' SHA-256; the lift run table carries it; a change stops |
| 12 | A family whose recipe keys on customer or card runs at a 100% account share, with a printed line |
| 13 | A missing pod path or record is a refusal with a clear line (exit 4), not a traceback |

### R.9 Open at delivery

- The importance lane's follow-up head (it scores the RANK-A files that `SETTINGS.yaml` names) is not in the
  package: its own integration test of the cost estimate fails there, and the lane is the one writer of its files.
  The package keeps the lane's previous head, which scores RANK-A as files 8228-8243; the planner waits, with a
  line, when `SETTINGS.yaml` names other RANK-A files.
- June drift on a very small June sample: on a synthetic world with 123 June rows from 48 accounts, an honest
  `since_last(days; within=all)` field is still flagged (PSI 0.424 against its cut of 0.25), although the screen now
  passes over the partial last training month. On the whole June of that world (2,333 rows) the same field gives
  0.163, below the cut. On the pod, June holds far more rows. It is a FLAG and decides nothing.
- The field checks' month table and June PSI keep censored rows in the missing bin, so a clean windowed field can
  get a month FLAG from its first training month. It is a FLAG and decides nothing.
- A recipe that the recipe engine refuses while it builds (for example an a3 field on data whose stored times carry
  sub-second parts) still ends the field checks with an error instead of a row. A missing column no longer does.

## 0. In short

- **Steps, at seed 42, read from a steps file.** Default: step A1 adds the V22B group (V22B included features minus Sumegha's exclusions; a feature in both lists belongs here) to the base inputs, against the stage 1 seed-42 retrain. Step A2 adds what model 15298 brings beyond V22B, against A1's kept fit. Off by default: step A3 (the 16 features built on 26 October, pending the owner), a pruning step, and step B (month out). A switch runs every group that is on as one step instead.
- **Month stays in.** Step B exists only as an option. The CPU checks measure whether any new field repeats month, and the owner decides after seeing the data.
- **Same settings for every fit:** the chosen model `sequential_hier_allpos_h20_chunk`, h20 chunk training, training files 1-10, EPOCH_VAL 4950-4954, 10 epochs, patience 5, deterministic false, stage 0's best learning rate for the chosen model (a placeholder, 3e-4 today).
- **Confirmation.** If a step's gain on the main measure is above zero but below the one-fit threshold T_1, seeds 43 and 44 of the candidate run, against seed 43 and 44 controls.
- **Decision population.** RANK-B (proposed 8244-8259, June targets) decides. It can be scored with no hashed change. If its eligibility check fails, June SELECT (8206-8216) decides, as a single logged read. Test 1 and Test 2 are reported only. Seed 42 was picked as the best seed on Test 1, so Test 1 never decides.
- **Measures.** Main: UDR at the 0.6% outsort. AP for screening and early stopping. VDR and the bank's FPR (false positives / true positives) reported.
- **Which features help, three layers.** (1) Before any GPU fit: the CPU screen, re-delivered in this package, with a per-feature XGBoost ranking. (2) After a fit: permutation importance on the trained transformer for every feature and every cluster of correlated features, scoring only, on RANK-A; plus attention importance from one scoring pass as a cross-check. (3) An optional pruning refit.
- **Feature-store view.** Each step's kept fit gets a downstream check of its 48-number embedding (DS_TRAIN 4001-4010, read once on DS_SELECT 8217-8227). The field map's recipes are kept as feature definitions a feature store can use.
- **Design goal, met.** Stage 2 runs on the same trainer code that stage 1 reproduces. No hashed file changes. Everything new is a yaml or csv config, a predictor list, a new artifact version, enriched data copies, or a tool under `fraud/experiments/features/`.

**Two parts.** Part A is CPU only and can run now, while stage 0 holds the GPU: intake, CPU checks, the CPU screen, the enriched copies, the artifact, the rank check, and the SELECT seed spread. Part B uses the GPU and starts only after stage 0, its resumes, and stage 1's GPU work have finished: timing, fits, scoring, importance and the downstream exports.

**Folder names** (relative to the project root on the pod):
- `NF` = `fraud/experiments/features/new_fields/` (tools, settings, field map, generated configs).
- `FS` = `fraud/experiments/features/field_screen/` (the re-delivered CPU screen).
- `TNF` = `tests/experiments/features/new_fields/`, `TFS` = `tests/experiments/features/field_screen/`.
- `C2` = `checkpoints/new_fields/` (every output: checks, fits, scores, reads, logs).
- `ART` = the chosen config's `artifacts.base`, `s3://mrmcd-analytics-mrm-users/K194855/tabular_fraud/artifacts`.
- `ENR` = the enriched data root, a setting (default `s3://mrmcd-analytics-mrm-users/K194855/tabular_fraud/enriched/nf_build1/`).
- `PY` = the pod's Python for the project (POD.md sets it once, with `NF` and `FS`).

## 1. Components

Every component is new. No existing file is edited, added to or removed. Scripts run by path. There is no `__init__.py` anywhere under `fraud/experiments/`. Each script finds the project root as `Path(__file__).resolve().parents[4]` (one folder deeper than `fraud/experiments/<purpose>/`, REORG 5.5) and puts the root and `root/src` first on `sys.path`. Importing a module does no work; work runs under `if __name__ == "__main__":`. Helper modules carry an `nf_` or `fsc_` prefix, and test files are named `test_new_fields_*.py` and `test_field_screen_*.py`, so no basename clashes with another folder's. No file or folder name holds `v[0-9]`, `l[0-9]`, `stage`, `package`, an 8-digit date or a long hex id (the REORG step 12 name check), so the V22B group is called `tfm` in file names.

| # | Component | Pod path | Inputs | Outputs | Device | Hashed |
|---|---|---|---|---|---|---|
| 1 | Module resolver | `NF/nf_layout.py` | project root | printed `layout: reorganized` or `layout: pre-reorganization (fallback)`; refuses a mix | CPU | No |
| 2 | Shared helpers | `NF/nf_common.py` | none | paths, exit codes, busy check, one-screen printer (40 lines, 90 characters), SHA-256, config flatten and diff | CPU | No |
| 3 | Settings | `NF/SETTINGS.yaml`, `NF/STEPS.yaml`, `NF/CHECK_THRESHOLDS.yaml`, `NF/STATUS_RULES.csv`, `NF/UPSTREAM.yaml` | written by us; `UPSTREAM.yaml` filled by Copilot from the stage 0 and stage 1 reports | read by every tool; each screen prints their SHA-256 | none | No (not .py) |
| 4 | Draft lists, UNCONFIRMED | `NF/DRAFT_TFM_FIELDS_UNCONFIRMED.csv` (scout B's 217-row table, copied unchanged; the same file as `11_01_2026/features_work/CANDIDATE_FIELDS_UNCONFIRMED.csv`), `NF/DRAFT_15298_RECIPES_UNCONFIRMED.csv` | records | reference for Copilot | none | No |
| 5 | Field map | `NF/FIELD_MAP.csv` | the owner's list, Copilot's mapping | the one table every later tool reads | none | No |
| 6 | Source guard | `NF/nf_guard.py` | the trainer's `source_sha256()`; stage 0 manifests under `runs/tuning/` and `checkpoints/`; the stage 1 control's manifest | `C2/guard/guard.jsonl` (appended); exit 3 on any difference | CPU | No |
| 7 | Intake | `NF/nf_intake.py` (`schema`, `draft`, `check-map`, `adopt`, `definitions`) | the map, parquet footers of every file range | `C2/intake/pod_columns.csv`, a checked map, `C2/intake/FEATURE_DEFINITIONS.csv` and `.json`, one screen | CPU | No |
| 8 | Recipes | `NF/nf_recipes.py` | a recipe string, one file's rows | built columns; used by components 9, 10 and 11 | CPU | No |
| 9 | CPU field checks | `NF/nf_field_checks.py` (`--dry-run` for a synthetic world) | the map, raw files, `CHECK_THRESHOLDS.yaml`, artifact version 1 | `C2/checks/field_checks.csv`, `field_status.csv`, `clusters.csv`, `month_overlap.csv`, `summary.txt` | CPU | No |
| 10 | CPU screen (re-delivered) | `FS/fsc_run.py` with `FS/fsc_usefulness.py`, `FS/fsc_probes.py`, `FS/fsc_stability.py`, `FS/fsc_synth.py`, `FS/README.md`, `FS/POD.md` | the map, `field_status.csv`, training files 1-10, Test 1 June rows (no labels) | `C2/screen/screen.json`, `feature_rank.csv`, `summary.txt` | CPU | No |
| 11 | Enriched copies | `NF/nf_build_enriched.py` | the map (CONFIRMED rows that passed), every file range stage 2 reads | parquet copies under `ENR` with the engineered columns added; a per-file identity proof under `C2/enriched/` | CPU | No |
| 12 | Extended artifact and its check | `NF/nf_build_artifact.py`, `NF/nf_check_artifact.py` | version 1 on `ART`; the unchanged `fraud/scripts/build_preprocessing_artifacts.py` | a scratch version and the extended version on `ART`; `C2/artifact/artifact_hashes.json`, `artifact_check.json` | CPU | No |
| 13 | Config writer | `NF/nf_make_configs.py` | `fraud/configs/sequential_hier_allpos.yaml`, `STEPS.yaml`, `SETTINGS.yaml`, the map | `NF/predictors/predictors_<inputs>_month_in.csv` and `_month_out.csv`, `NF/configs/<run>.yaml`; a printed key-by-key diff | CPU | No |
| 14 | Rank check | `NF/nf_rank_check.py` | `splits/file_inventory.json`, `splits/populations.yaml`, `splits/population_roles.yaml`, exposure records and receipts | `C2/reads/rank_check.json`, one screen | CPU | No |
| 15 | Width timing | stage 1's `width_timing.py` and callbacks if present, else `NF/nf_time_width.py` | the step's config | `C2/timing/<run>.json`, one screen | GPU, short | No |
| 16 | Reader | `NF/nf_read.py` (`spread`, `read`, `select-check`, `lift`, `report`), engine `NF/nf_ranked.py` | prediction files, receipts, five raw columns, `SETTINGS.yaml` | `C2/reads/<step>_<n>seed.json` and `.txt`; `C2/READS.log` (appended) | CPU | No |
| 17 | Importance | `NF/nf_importance.py` (`estimate`, `run`, `summary`) | a fit, RANK-A files, `clusters.csv` | `C2/importance/<run>/importance.csv`, `attention.csv`, `summary.txt` | GPU scoring passes | No |
| 18 | Downstream check | `NF/nf_downstream.py` | a kept fit; the unchanged tools in `fraud/experiments/embedding/` | exports under `C2/exports/`, downstream results under `C2/downstream/`, the lift read | GPU export, CPU fit | No |
| 19 | Planner and queue | `NF/nf_plan.py`, `NF/nf_run_all.sh`, `NF/nf_start.sh` | `STEPS.yaml`, saved reads | fits under `C2/runs/`, scores under `C2/scores/`, logs under `C2/logs/`, `C2/KEPT.json` | both | No |
| 20 | Morning report | `NF/nf_report.py` | `C2/` | one screen, `C2/REPORT.txt` | CPU | No |
| 21 | Docs | `NF/README.md` (two lines, like the other experiment folders), `NF/POD.md` (the run sheet for Copilot) | this design | text | none | No |
| 22 | Tests | `TNF/test_new_fields_*.py`, `TFS/test_field_screen_*.py`, helper `TNF/new_fields_world.py` | synthetic data | pytest results | CPU | No (tests/ is excluded) |

**Why nothing hashed changes.** The trainer's source hash covers the `.py` files under `fraud/` except `fraud/experiments/` and `tests/`, plus `pyproject.toml` and `requirements.txt` (REORG 5.4; `fraud/source_files.py`). Files are discovered, not listed, so any new `.py` file elsewhere under `fraud/` would change it. Every new `.py` file here is under `fraud/experiments/` or `tests/`. Every other new file is yaml, csv, sh or md. The package touches neither `pyproject.toml` nor `requirements.txt`. The guard (component 6) proves this on the pod.

**What each need uses instead of an edit.**

| Need | Route with no hashed edit |
|---|---|
| New raw codes and numbers | a new predictor list (csv), a new artifact version, and yaml values (`predictors.csv_path`, `artifacts.version`). Nothing on the train or score path refuses a list other than the 23 (scout A, part 5) |
| Engineered features, and dates as days before the transaction | precomputed columns in enriched parquet copies under `ENR` (section 4.1). The model has no datetime predictor type, and a raw date loaded as continuous is garbage (NaT becomes int64 minimum). The copies are a data step, with a per-file proof that every original column is unchanged |
| Month as a switch | two predictor lists over one artifact. The builder and the input contract read only the listed fields |
| RANK-A and RANK-B scoring | the scorer's existing `--population OTHER` with a free-text `--purpose` and `eval.file_start`, `eval.file_end` |
| UDR at 0.6% | 0.6% is exactly 6 per mille. The reader holds its own engine and checks it on the pod against the unmodified `business_metrics._alert(..., 6, ...)` with `_ranking` |
| Permutation importance | the scorer's own `load_for_scoring` and loop, with the dataset object wrapped in memory from outside (section 7.6) |
| Attention importance | forward pre-hooks on the model's first-stage encoder layers, attached from outside (section 7.7) |
| Timing | a wrapper that adds callbacks and step limits in memory (stage 1's method) |
| Paired reads on RANK-B | `compare_models` cannot read RANK-B (its `--population` choices leave out OTHER), so the reader is its own script; it imports `load_raw` and `target_mask` read-only |

**Hashed-file exceptions: none.** No part of stage 2 needs one. If a later production design wants a native "days before" predictor type (to avoid data copies), that is an edit to `fraud/data/datetime_features.py`, the sequence builder and the artifact builder. It is not part of stage 2, and it would install with part 2's tuning modules in one install after stage 0's resumes, default off and proven byte-identical by default.

**Part 2 and stage 0.** Stage 0 runs on the reorganized code and its kept runs will be resumed. A resume refuses any change to the source hash. Installing this package does not change it. If part 2's tuning modules (which may edit hashed files) are installed before stage 2 ends, the trainer is no longer the code the control ran on, and the guard refuses every later stage 2 fit. The owner then chooses: finish stage 2 first (recommended), or refit the control on the new code.

**The resolver.** It tries the reorganized names first and falls back to the pre-reorganization names (REORG 5.1). It prints which layout it found and each module's file path. If some names resolve only in one layout and some only in the other, it stops (exit 4) and lists them. Every module file must lie under the project root. It also checks that the attributes the tools use exist.

| Use | Reorganized | Fallback |
|---|---|---|
| trainer | `fraud.scripts.train_sequential_hier` | `waqas.v2.scripts.train_v2` |
| scorer | `fraud.scripts.score_sequential_hier` | `waqas.v2.scripts.score_v2` |
| target-ending model | `fraud.sequential_hier_target_ending_model` | `waqas.v2.models` |
| base model | `fraud.sequential_hier_model` | `waqas.phase4b.sequential_hier` |
| factory | `fraud.sequential_hier_factory` | `waqas.phase4b.factory` |
| sequence builder, target-ending data | `fraud.data.sequence_builder`, `fraud.data.target_ending` | `waqas.phase4b.sequence_builder`, `waqas.v2.target_ending` |
| business metrics (`_alert`, `_ranking`) | `fraud.scripts.business_metrics` | `waqas.v2.analysis.business_metrics` |
| raw join (`load_raw`, `target_mask`) | `fraud.scripts.compare_models` | `waqas.v2.analysis.paired_v2` |
| input contract, input checks | `fraud.data.input_contract`, `fraud.data.input_checks` | `waqas.base.data.contracts`, `waqas.base.data.input_contracts` |
| S3, thin reads | `fraud.data.s3_utils` | `fraud.data.s3_utils` plus `waqas.v2.storage` |
| prediction files, `read_table` | `fraud.data.prediction_files` | `waqas.scoring._prediction_utils` plus `waqas.v2.benchmark_v2` |
| preprocessing, feature list, calendar fields | `fraud.data.preprocessing`, `fraud.data.feature_list`, `fraud.data.datetime_features` | the same names |
| source list | `fraud.source_files` | `waqas.source_identity` |
| strict windows, 26 October groups | `fraud.experiments.features.strict_window`, `fraud.experiments.features.groups` | `waqas.v2.features.strict_window`, `waqas.v2.features.groups` |
| 26 October screen features | `fraud/experiments/features/screen/features_new.py` (by path) | `waqas/v2/screen/features_new.py` |
| embedding tools | `fraud.experiments.embedding.export_embeddings`, `.check_export`, `.export_records`, `.downstream_xgb` | `waqas.v2.export_v2`, `waqas.v2.scripts.l4_check`, `waqas.v2.scripts.make_v2_contracts`, `waqas.v2.downstream_xgb` |

Attributes checked: trainer `source_sha256`, `source_files`, `run_identity`, `check_batch_plan`, `eval_batch_size`, `MAX_STAGE1_ROWS`; scorer `load_for_scoring`, `select`, `_model_inputs`, `POPULATIONS` holding `OTHER`; builder classes `_encode_file`; base model `token_encoder`; business metrics `_alert`, `_ranking`. A missing attribute stops the tool that needs it, with its name.

## 2. Field intake

### 2.1 FIELD_MAP.csv

One row per new feature. Base inputs are not rows; they come from `fraud/configs/predictors.csv` (the 23: 6 numbers, 13 codes, and month, day, hour and day of week derived from `transaction_dttm`; the time gap is a model setting).

| Column | Filled by | Meaning |
|---|---|---|
| `name` | Copilot | the model input name, unique. For a raw field, the pod column name exactly. For an engineered field, a new lowercase name of letters, digits and underscores |
| `group` | the list | `v22b`, `f15298` or `both` (in both lists; it belongs to V22B for the steps), or `a3` |
| `kind` | the list | `raw` or `engineered` |
| `recipe` | Copilot, from the list | `raw`, or one expression of the grammar in 2.2 |
| `source_columns` | Copilot | the pod columns it reads, `;`-separated. Each must be one of the pod's raw columns (the intake counts them; the records say 227, earlier records about 224; no tool hard-codes the count) |
| `model_type` | Copilot proposes, intake checks | `continuous` or `categorical` |
| `window`, `lag` | intake, from the recipe | for example `24h`, `1d`; blank for raw fields |
| `as_of_rule` | intake, from kind and recipe | for example "value stored on the row at the transaction time"; "strictly earlier rows of the same account, whole seconds, censored before the extract start"; "days from the date to the transaction time" |
| `definition_version` | Copilot | 1 for a new definition; raised by one when a recipe changes |
| `tfm_name`, `f15298_name` | the list | the names in TFM's and 15298's records |
| `v22b_rank`, `f15298_rank` | the list | importance ranks, if any |
| `excluded_by_sumegha`, `sumegha_reason` | the list | `yes` or `no`, with the reason, kept for the record. A `yes` row never enters |
| `feasible_in_production`, `feasibility_note` | Copilot, as recorded | `yes`, `no` or `unknown` |
| `external_score` | intake proposes, Copilot confirms | `yes` for another model's score (for example `external_1_scr`, VAA) |
| `status_rule` | intake, from `STATUS_RULES.csv` | `none`, `left_out_26oct`, `rank52`, `status_like`, `hold` |
| `data_owner_fixed` | only from the data owner's written answer | `yes` with name and date in `notes`, else blank |
| `left_out_reason` | intake or Copilot | why a recipe cannot be expressed; a row with a reason never enters |
| `list_status`, `list_source` | `adopt` only | `CONFIRMED` or `UNCONFIRMED`; the owner's list file name and SHA-256. Copilot never edits these |
| `check_result`, `check_reasons`, `cluster_id`, `kept_once_as` | the CPU checks | `PASS`, `FLAG`, `WAIT` or `STOP`; every rule that fired with its value; the cluster; the twin it duplicates |
| `notes` | Copilot and intake | spellings tried, suggestions, reasons |

### 2.2 The recipe grammar

A closed set. Every history recipe follows the model's own rules (strict_window, and the sequence builder's same-second rule):
- Only rows of the same `Nmap_account_reference_xid` count.
- Only strictly earlier rows count. The time key is `transaction_dttm` floored to whole seconds, as the sequence builder does (`datetime64[s]`). A row in the same second is not earlier, so same-second siblings never see each other. If the pod's timestamps carry sub-second parts, the builder prints their share.
- A window is `[t - w - lag, t - lag)`. A window that reaches before the split's declared extract start is censored: the value is missing, never zero (training and validation 2024-10-01, evaluation 2025-05-01; `strict_window.EXTRACT_START`).
- Each account's whole in-extract history is read: all rows of its file (accounts sit inside one file), not only sampled targets.
- Missing raw values never match and never count. Raw values are compared before any vocabulary.
- The label `frd_tag` and label-like columns are never a source.

| Recipe | Value |
|---|---|
| `raw` | the column as stored on the row |
| `days_before(c)` | (transaction time minus the date in `c`) in days, as a float. Parses datetime64, strings, epoch seconds or milliseconds, and yyyymmdd numbers; the parse rule and failure share are printed. A date with no time part is midnight. Negative values are kept and checked (section 3) |
| `days_until(c)` | (updated) a known future date, such as card expiry: days from the transaction to the date in `c`, a signed difference, below zero once the date has passed. The map row says `date_meaning = known_future_date`; `date_after_txn` applies to event dates only |
| `code(c)` | (updated) 15298's `le1` and `le3` features: integer codes of a category. `code(c)` is the raw code `c` as a category, a proposed alternative that is not proven equal to the original encoder (its rare and unseen handling is not documented): check-map FLAGs it `encoding_alternative`, and the decisions table keeps the row unresolved. It is merged with a raw field only when the original encoder is documented |
| `count(w[; where=c:v1,v2][; same=c][; lag=w2])` | number of earlier rows in the window (only those with `c` in the listed values, or with the same value of `c` as this row) |
| `sum`, `mean`, `min`, `max(w; value=c[; where=...][; same=...][; lag=...])` | aggregate of `c` over the earlier rows in the window; missing when none |
| `distinct(w; value=c)` | number of distinct earlier values of `c` in the window |
| `since_last(unit[; where=...][; same=c])` | time since the latest earlier matching row, in minutes or days; missing if none since the extract start |
| `since_first(unit; same=c; within=w)` | time since the first earlier row with the same value of `c` in the window (for example 15298's days since the first transaction at this merchant within 90 days) |
| `prev(c)` | the value of `c` on the latest strictly earlier row (the bank's decisions on earlier transactions, as decided on 26 October) |
| `ratio(a; b)` | `a / b` on the current row; missing unless both are present and `b > 0` |
| `geohash(postal_col; country_col)` | (updated) TFM's geohash of a postal code with its country, from TFM's table (`SETTINGS.yaml` `geohash_table`), by TFM's V22 rules (section R.5). A category; no window, lag or censoring |
| `a3(col)` | a column of the 26 October builders (`compute_groups` in `groups.py`, `compute_new` in `screen/features_new.py`), called unchanged |

Windows: `5m`, `1h`, `24h`, `48h`, `7d`, `14d`, `30d`, `90d`, or `<n>s`.

**Left out, with the reason written in `left_out_reason`, never guessed:**
- a recipe that reads an outcome: claim rates and claim counts, case dispositions (15298's `dc_tran_claim_rate_*`, `dc_nm_evnt_*_case_disposition_*`). Outcomes become known later than the transaction, and the raw files hold no date for when each became known;
- an aggregate over all customers of a merchant (merchant claim rates, merchant-name indexes `mchname_*`): the files are account buckets, so they cannot be built faithfully from them;
- a group key that is not among the raw columns (card number, fuzzy merchant names) or whose values span files (checked for customer keys: every key value must sit in one file);
- a value packed into a string with no documented layout (some `user_data_*_strg_*` names), unless the pod holds it as its own raw column;
- an event from another system that is not among the raw columns (logins, mobile inquiries), unless the pod holds it.
Using the account instead of a customer or card key would make a different feature, so the tools do it only on the owner's written word.

### 2.3 How Copilot fills it on the pod

1. `CUDA_VISIBLE_DEVICES= $PY NF/nf_intake.py schema` reads only the parquet footers (no rows) of every file stage 2 reads: training 1-10, EPOCH_VAL 4950-4954, RANK-A 8228-8243, RANK-B 8244-8259, SELECT 8206-8216, Test 1 8000-8010, DS_TRAIN 4001-4010, DS_SELECT 8217-8227. It writes `C2/intake/pod_columns.csv` (every column, its type per range, names or types that differ between files) and prints the column count it found.
2. Copilot writes `NF/FIELD_MAP.csv` from the owner's list (V22B included features minus Sumegha's exclusions, plus 15298's features, as far as the raw columns allow), one row per feature, in the columns of 2.1. It fills `name`, `group`, `kind`, `recipe`, `source_columns`, `model_type`, `definition_version`, the list columns, Sumegha's columns, feasibility and `notes`. `NF/nf_intake.py draft` can write the UNCONFIRMED drafts in map form for comparison.
3. Spellings to try (scout B): `pinwfatmcurrdttm` and `pinwfatmcurdttm`; `ddatellerlastdepatttm` and `ddatellerlastdepattm`; `moble_amt_curr` and `MOBILE_CURR`; `edrlogonctcurr` and `edrlogonctcoun`. For a name with no exact match the intake prints up to three close pod names, as suggestions only.
4. `CUDA_VISIBLE_DEVICES= $PY NF/nf_intake.py check-map` checks: required columns and allowed values; each recipe parses; every source column exists in every file range the field is read on; two rows on one name; name clashes (a base input, `month`, `day`, `hour`, `day_of_week`, `time_delta`, or any `*_isna` name); status rules; external scores; Sumegha's yes rows; outcome sources and group keys (2.2). One screen.
5. When the owner confirms the list, `$PY NF/nf_intake.py adopt --list <owner file> --confirmed-by "<name, date>"` marks the rows CONFIRMED and records the file's SHA-256. Rows not in that file leave the map. No other command writes `list_status`.
6. `$PY NF/nf_intake.py definitions` writes the feature definitions (2.7).

### 2.4 The draft lists (UNCONFIRMED)

**V22B, from scout B.** No record holds a list called "V22B CSCA": the records call V22B the older BMG data and V30 the CSCA data (BACKGROUND.md:86-87). Scout B's draft is the V22B model's input fields minus the fields TFM engineered. Every row says `list_status=UNCONFIRMED`. The owner's update of 2 November says the list now comes from the owner and Copilot, so this draft is a reference only. Tools refuse to build copies, an artifact or a fit while any map row is UNCONFIRMED. The CPU checks and the screen may run on a draft, and their screens say UNCONFIRMED.

(updated) The shipped draft has 217 TFM rows, 120 of them on the V22B chart: 78 yes, 13 hold, 29 no, after the feature review moved ranks 6, 22, 40, 44, 48, 56 and 59 from no to hold. Rank 75 (card expiry) is `days_until`, and ranks 8 and 30 (the two postal codes) are `geohash(...)` recipes with the raw postal code as the proposed alternative. The reviewed design's counts, kept for the record: 78 `yes` (41 codes, 19 numbers, 18 dates; 49 are CPR profile fields; all 78 are in TFM's raw selection list and the 15298 schema); 6 `hold`; 133 `no`.

- **Codes (41):** 3 merchant_category_xcd, 8 merchant_postal_xcd, 15 token_requestor_id, 16 cprsrvc__dbt_regionchp, 18 merchant_state_xcd, 20 avs_response_xcd, 21 terminal_entry_capability_xcd, 27 atm_network_xid, 29 channel, 30 cprsrvc__pisinfo_cardholder_postal_xcd, 31 tokenization_indicator, 33 cvv2_response_xflg, 37 gmt_offset, 38 cprsrvc__dbt_otp_adx_response_adx_userdata24, 39 user_indicator_7_xcd, 41 transaction_advice_xcd, 46 cprsrvc__dbt_prov_datacapture_device_type, 47 transaction_posting_entry_xflg, 49 card_verification_results_xcd, 53 terml_verification_results_xcd, 54 cprc002__dbt_pos_concat1_terminal_level_card_diff_ind, 55 cprsrvc__pisinfo_plastic_issue_type, 57 terminal_type_xcd, 58 card_dynamic_authctn_xcd, 77 user_data_1_strg_p2p_type, 79 cprsrvc__pisinfo2_private_bank_ind, 80 cprcust__pisinfo3, 82 card_aip_verification_xflg, 84 cprcust__authcsusploc_risky_ip_country_xcd, 86 merchant_country_xcd, 87 card_issuer_auth_support_xflg, 88 card_combined_authctn_xflg, 89 card_aip_risk_xflg, 90 cpracct__ddaewstxndata_credit_acct_type, 93 cprsrvc__dbt_prov_datacapture_token_type, 97 cprsrvc__pisinfo_cardholder_country_xcd, 98 card_offln_static_authctn_xflg, 100 user_data_5_strg_device_ip_address_dbc3ds, 101 cprcust__edrmobilebrowser_most_recent_browser, 107 cpracct__ddaewstxndata_credit_seg_id, 115 cprsrvc__dbt_travel_countrydate_cardholder_travel_curr_country.
- **Numbers (19):** 23 user_data_6_num_temp_line_used_ratio, 32 cprcust__edrlogonctcurr, 64 cprcust__ddalesscashamtcurr, 65 cprcust__ddatellerwdamtcurr, 69 cprcust__ddacheckcashoffusamtcurr, 73 cprcust__ddaasatmamtcurr, 83 cpracct__ddabusdayamts13_atm_amt_curr, 91 cpracct__ddabusdayamts13_moble_amt_curr, 96 cpracct__ddatellerdepamtcurr, 99 cpracct__ddamobiledepamtcurr, 105 cpracct__ddabusdayamts13_teller_amt_curr, 106 cprsrvc__dbt_atm_ddl, 110 cpracct__ddaatmdepamtcurr, 111 cprsrvc__dbt_pos_ddl, 113 cprsrvc__dbt_mrchamtcnt_trnx_amt, 114 cprsrvc__dbt_deposit_atm_ddl, 117 transaction_cashback_amt, 118 cpracct__ddapostverifycashamtcurr, 119 cpracct__ddanontellerdepamtcurr.
- **Dates (18), as `days_before`:** 25 cprcust__dbt_highrisklogin_dttm, 26 cprsrvc__dbt_currchp_dttm, 28 cprcust__panprofilechgdt, 43 cprsrvc__dbt_tokenactdate, 45 cprcust__dbt_riskyloginevent_dttm, 51 cprcust__onlinebankusernamechgdt, 52 cprcust__onlinebankpwstatuschgdt, 63 cprsrvc__pisinfo2_pan_open_dt, 66 cprsrvc__pisinfo_pin_set_dt, 70 cprcust__custidentinfochgdt, 75 card_expiration_dt, 76 cprc002__dbt_pos_fb_currdttm, 94 cpracct__acctaddrchgdt, 95 cprc002__dbt_atmfb_currdttm, 102 cpracct__acctnametitlechgdt, 103 cprsrvc__pisinfo_last_issue_dt, 108 cprcust__atmddlchgdt, 116 cprsrvc__dbt_pinwfatmcurrdttm. Their stored types differ (date, double, float, string), so the parse rule matters.
- **Hold (6 in the reviewed design; 13 now, with the seven ranks above):** rank 1 VAA (probably the same Visa score as `external_1_scr`); ranks 10, 42, 60 (FALCONDECLINE_INDICATOR, PREDECLINE_INDICATOR, PROCESSOR_REASON: the bank's decision on the same transaction, usable only as `prev(...)`); ranks 7 and 78 (PRIOR_ACTION_DB_EXPIRATION_DT, CPRACCT__DDAEWSTXNDATA_HOLD_SEG: status-like).

**15298, from `waqas/feature_work/all_features_master.csv` (94 features).** (updated) The shipped `DRAFT_15298_RECIPES_UNCONFIRMED.csv` keeps all 94 outputs with the crosswalk's work types (16 encoding, 21 date derivation, 21 transaction history, 5 claim history, 5 event history, 21 recipe definition, 5 recorded raw mapping); an undefined recipe holds as `definition_needed`, and `days_before` or `code` is never applied to a whole multi-output field. The classes below are the reviewed design's. `DRAFT_15298_RECIPES_UNCONFIRMED.csv` gives a draft recipe or a left-out reason per feature. Draft classes:
- 16 `le1`/`le3` codes (ranks 2, 4, 9, 10, 12, 20, 23, 31, 37, 44, 46, 54, 56, 65, 73, 77): `code(c)`. Most are base inputs or V22B fields, so they are kept once as those.
- 21 days-since dates (ranks 6, 19, 21, 22, 26, 27, 29, 45, 48, 50, 52, 53, 57, 61, 68, 72, 75, 78, 81, 83, 91): `days_before(c)` where the column exists. Ranks 22 (`cprcust__astatuschgdt`) and 78 (`cprsrvc__pisinfo2_status_dt`) are status dates and stay out; rank 57 (`prior_action_db_expiration_dt`) waits as status-like; rank 81 is the password status-change date, the same field as V22B rank 52.
- 24- and 48-hour counts and recency (ranks 5, 7, 18, 25, 38, 42, 74, 80, 85, 89, 94): `count`, `since_first`, `since_last` and `prev` recipes, once Copilot reads 15298's definitions (for example rank 42 minutes since the last authorisation is `since_last(minutes)`; rank 80 previous authorisation amount is `prev(transaction_amt)`). Rank 5 uses a 90-day window, which is censored on every June row (evaluation files start on 1 May 2025), so it is expected to stop as `empty_june`.
- 14-day aggregates by card or customer (16 features: ranks 32, 39, 43, 62, 64, 66, 67, 71, 76, 79, 82, 84, 86, 87, 88, 90): only if the key is a raw column whose values sit in one file; otherwise left out.
- 30-day merchant claim rates and counts (9), case disposition (1), merchant-name indexes (3): left out (outcomes, or all customers of a merchant).
- Profile values (ranks 15, 51, 55, 59, 63, 70, 92, 93) and other-system events (ranks 11, 41, 47, 58): `raw` if the pod holds the column, else left out.
- 5 are raw fields already in the set: ranks 1, 14, 33 and 49 are base inputs, and rank 28 (`user_data_6_num_temp_line_used_ratio`) is V22B rank 23. Each is kept once as the earlier copy. Rank 1, `external_1_scr`, is an external score and is flagged.
- The classes add up to 94: 16 codes, 21 dates, 11 counts and recency, 16 aggregates, 9 claim fields, 1 case disposition, 3 merchant-name indexes, 8 profile values, 4 other-system events and 5 fields already in the set.

### 2.5 Status fields, holds, exclusions, feasibility, external scores

`STATUS_RULES.csv` holds these rules as data. No tool hard-codes a field name.
- **The seven left out on 26 October stay out** whatever the list says: `DERIVED__DAYS_SINCE__CPRCUST__ASTATUSCHGDT`, `INACTV_DT`, `CPRCUST__EBSLOGINBLOCKDT`, `CPRCUST__CARDSTATDT_CARD_STATUS_NM3102`, `CPRCUST__EBSLOGININTERDICTFAILDT`, `CPRACCT__DDAEWSTXNDATA_HOGAN_ACCT_STATUS`, `CPRSRVC__PISINFO2_STATUS` (the TFM developer's warning that V22B holds fraud proxies, with leakage from the card inactive date). Result `STOP left_out_26oct`.
- **Rank 52**, the password status-change date, stays in if listed, as `days_before`, subject to the moment-of-transaction check.
- **Any other status field or status date** stays out unless the data owner confirms in writing that it is fixed before the decision. Until then `WAIT status`. The intake also marks as `status_like` any field whose name or source contains a pattern listed in `STATUS_RULES.csv` (status, stat, block, hold, inactv, inactive, close, susp, ato, ring, counterfeit, badchip, disposition, interdict, prior_action, frd, fraud, claim, chargeback, dispute). Copilot cannot clear this mark; only the data owner's answer can.
- **Holds** in the list stay `WAIT hold` until the owner answers.
- **Sumegha's exclusions** (`excluded_by_sumegha = yes`) never enter: `STOP excluded_by_sumegha`, kept in the map with the reason.
- **Feasibility.** `feasible_in_production = no` gives `WAIT not_feasible` (the owner and Sumegha decide); `unknown` gives `FLAG feasibility_unknown`.
- **External scores** (`external_1_scr`, VAA if present) get `FLAG external_score` for the production-availability question. The tools never exclude them.

### 2.6 Overlap between the lists

A 15298 feature equal to, or a one-to-one recode of, a V22B field or a base input is caught by the duplicate and recode check (section 3) and kept once. The order of precedence is: base input, then the V22B group (`v22b` and `both`), then `f15298`, then `a3`; within a group, the map's order. The later twin gets `STOP duplicate` with `kept_once_as = <name>`. So A2 adds only what 15298 brings beyond V22B, even when A1's group was dropped. Every overlap is listed on the checks screen.

### 2.7 Feature definitions for a feature store

`nf_intake.py definitions` writes `C2/intake/FEATURE_DEFINITIONS.csv` and `.json`: one record per feature that passed, with name, `definition_version`, kind, recipe, source columns, window, lag, as-of rule, group key (the account), time key (`transaction_dttm`, whole seconds, strictly earlier), censoring rule, missing rule, model type, group, feasibility, Sumegha's flag, and the SHA-256 of the owner's list. These are the definitions a future feature store needs (a point-in-time contract per feature). The embedding width stays 48, its export contract.

## 3. CPU checks (one script)

`CUDA_VISIBLE_DEVICES= nice -n 19 $PY NF/nf_field_checks.py --map NF/FIELD_MAP.csv`. CPU only. It refuses to start if free host memory is below the level in `CHECK_THRESHOLDS.yaml` (default 32 GB), so it can run while a GPU job trains. It reads one file at a time and, inside a file, one batch of columns at a time, and keeps per-file partial counts under `C2/checks/partial/`. A stopped run restarts at the next file. It prints the thresholds file's SHA-256 first. Thresholds are fixed before the first run; a changed thresholds file makes it refuse to reuse partial counts. Engineered fields are computed in memory by `nf_recipes.py`, the same code the enriched copies use, so a field that stops is never written.

`--dry-run` builds a small synthetic world (two parquet files, a field map with planted cases) in a temporary folder and runs every check on it in one command.

### 3.1 Rows read

| Check | Rows |
|---|---|
| Moment of the transaction; missing values overall, by month and by label; month overlap; strictly-earlier probes | all rows of training files 1-10 |
| Vocabulary and unknown share | fit on version 1's `fit_files` (from its `manifest.json`) with the unchanged categorical fit; encoded per file with the unchanged encoder |
| Duplicates, recodes and clusters | all rows of training files 1 and 2; a pair found there is confirmed on file 3 |
| Single-field AP | encodings fit on training files 1-10; AP on EPOCH_VAL 4950-4954 |
| June values: missing, unknown share, censoring, drift | Test 1 files 8000-8010, June rows, with no label read. RANK-A, RANK-B and SELECT rows are never read by the checks |
| Presence | footers of every range (2.3) |

### 3.2 What is checked

**Availability at the moment of the transaction.**
- *Own date after the transaction* (date sources): the share of non-null rows whose date is later than `transaction_dttm` (a date with no time part counts as later only if its day is later); overall, among frauds, among non-frauds.
- *Filled only for frauds:* the non-missing share among fraud rows against non-fraud rows.
- *Filled only after a fraud is confirmed:* in fraud accounts, the non-missing share on rows at or after the first fraud minus the share before it; the same around a pseudo-event in non-fraud accounts (one row per account, drawn with a fixed seed among rows that have an earlier row). The excess jump is the difference of the two.
- *Changes at the event:* the share of first-fraud rows whose value differs from the account's previous row, against the same share at pseudo-event rows.
- *Values that change after the event:* the share of fraud accounts whose value changes within 30 days after the first fraud, against the same after the pseudo-event.
- *Constant within the account:* the share of accounts with two or more rows that show one value throughout (a sign of a snapshot taken at extraction). Information only.
- *Too good on its own:* single-field AP on EPOCH_VAL. Numbers: the better of the value and its negative, with missing placed first and last, taking the better. Codes: the training fraud rate per value, smoothed toward the overall rate with weight 100; unseen values get the overall rate.
- *Strictly earlier, for engineered fields:* (a) future invariance: rows after a random per-account cutoff are rescaled, permuted and partly deleted; no value at or before the cutoff may change (the screen's `future_invariance` probe); (b) same-second siblings: adding a row in the same second as row i never changes row i's value; (c) label permutation: permuting `frd_tag` changes no built value.

**Missing values.** The missing share overall; by month of `transaction_dttm` (2024-10 to 2025-06, June from Test 1); by label (fraud, non-fraud); per file range. For engineered fields, censored values are counted apart from other missing values.

**Type, vocabulary and unknown share.** Numbers: the share of non-null values that fail numeric conversion; mean and standard deviation after conversion. Codes: vocabulary size on the fit files; the unknown share on each fit file (an int column with nulls in some files gets keys like "1.0", so a file without nulls encodes every value as unknown); the unknown share on EPOCH_VAL and on June rows. The intake writes engineered codes as strings, so they cannot fall into this trap.

**Duplicates and one-to-one recodes.** Each field is compared with every base input as it enters the model (the four calendar fields derived from `transaction_dttm`, and the time gap to the previous row of the account), the two id columns, the label `frd_tag`, and every other field in the map. Two columns are factorized in row order, with missing as its own value. Their code arrays are equal exactly when one is a one-to-one recode of the other. Equal values as text means identical. This catches renamed copies, code-to-label recodes, 15298's `le1`/`le3` twins and affine copies of numbers in one pass. Near duplicates: absolute Pearson r and Spearman rho for numbers; Cramer's V and the distinct-pair count for codes.

**Clusters for the importance tools.** Single-linkage clusters of fields that are near duplicates or correlated at or above the declared threshold (default 0.8): absolute Spearman rho for two numbers, Cramer's V for two codes, the correlation ratio for a number and a code, all on the values as they enter the model (numbers with missing as its own value through the missing flag). Base inputs are included. Written to `clusters.csv` and the map's `cluster_id`.

**Month-like fields and month redundancy.** Month stays in. For month and every field that carries a date or calendar information:
- *Calendar code:* a name or source that suggests a month, year or period (patterns in `CHECK_THRESHOLDS.yaml`), or integer values that all fall in 1 to 12, or in yyyymm or yyyymmdd ranges.
- *Absolute time:* absolute Spearman rho between the field and the transaction time of at least 0.9 on training files (a raw timestamp or counter).
- *Tracks the month:* overlap with month on the training files, on the values as they enter the model (codes as categories with missing as a value; numbers in deciles of their training values, with missing as its own bin). Two measures: normalised mutual information NMI = I(X; M) / sqrt(H(X) x H(M)), and Cramer's V = sqrt(chi^2 / (n x (min(r, c) - 1))).
- *Drift:* PSI between training rows and Test 1 June rows (deciles fixed on training values; codes by value).
- Dates never enter as calendar parts: `days_before` (a past event date) and `days_until` (a known future date) are the only date recipes (updated).
The report says plainly, per field, whether month looks repetitive: "month looks repetitive with <field>" when V or NMI reaches the declared "repetitive" level and the screen shows month adds nothing once the new fields are in (3.6). The tools never remove month or a field. Flagged fields are listed for the owner.

### 3.3 Results: stop, wait, flag

Every threshold is in `CHECK_THRESHOLDS.yaml`, declared before the first run. A field gets every rule that fires. The worst result wins: STOP over WAIT over FLAG over PASS.

**STOP: the field does not enter.**

| Rule | Fires when |
|---|---|
| `missing_from_files` | a source column is absent from any file of a range the field is read on |
| `name_clash` | the name equals a base predictor, a calendar field, `time_delta`, or ends with `_isna` |
| `excluded_by_sumegha` | Sumegha's exclusion |
| `left_out_26oct` | one of the seven status fields |
| `left_out_recipe` | `left_out_reason` is set (2.2) |
| `uses_outcome` | a source is `frd_tag` or a label-like column |
| `group_key_spans_files` | a non-account group key has values in more than one file |
| `type_number_text` | a number has more than 0.1% non-null values that are not numbers |
| `type_scale` | a number's mean or standard deviation is above 1e12 in absolute value |
| `type_date_parse` | a date source fails to parse on more than 1% of non-null values |
| `date_after_txn` | own date later than the transaction on more than 0.1% of non-null rows, or more than 1% of fraud rows |
| `fill_only_fraud` | non-missing share among frauds at least 10 times that among non-frauds, with non-frauds below 1% |
| `fill_after_fraud` | excess fill jump at the first fraud of at least 20 points |
| `not_strictly_earlier` | any strictly-earlier probe fails for an engineered field |
| `too_good` | single-field AP on EPOCH_VAL at or above the control's best validation AP (0.137146 until the control fit gives its own) |
| `label_copy` | a one-to-one recode of `frd_tag` |
| `duplicate` | identical to, or a one-to-one recode of, a base input, a calendar field, the time gap, an id column, or an earlier field (2.6) |
| `duplicate_number` | absolute r at least 0.9999 with a base input or an earlier field |
| `vocab_size` | more than 100,000 categories |
| `unk_fit_files` | unknown share above 0.1% on any fit file |
| `unk_june` | unknown share above 50% on June rows |
| `empty_train` | at least 99.5% missing in training files |
| `empty_june` | at least 99% missing or censored on June rows while below 90% missing in training (a window longer than the evaluation history fires this: evaluation files start on 1 May 2025, so a window of more than about 31 days is censored on every June row) |

**WAIT: needs an owner or data-owner answer.** `status` (status-like), `hold` (the list's holds), `not_feasible` (recorded as not feasible in production).

**FLAG: enters, and is listed.**

| Rule | Fires when |
|---|---|
| `date_after_any` | any non-null row with its own date after the transaction |
| `fill_ratio` | non-missing share among frauds at least 3 times, or at most one third, that among non-frauds |
| `fill_jump` | excess fill jump at the first fraud of at least 5 points |
| `change_at_event` | change at the first fraud at least 10 points above the baseline and at least 3 times it |
| `change_after_event` | change within 30 days after the first fraud at least 10 points above the baseline |
| `strong_alone` | single-field AP at least half the control's validation AP |
| `near_duplicate` | absolute r at least 0.98, absolute rho at least 0.999, Cramer's V at least 0.95, or distinct pairs at most 1.01 x the larger cardinality |
| `vocab_large` | more than 10,000 categories |
| `unk_june_high` | unknown share above 10% on June rows or EPOCH_VAL |
| `missing_drift` | any month's missing share more than 20 points from the training-wide share |
| `censored_june` | more than 10% of June rows censored |
| `calendar_code`, `absolute_time` | 3.2 |
| `overlaps_month` | Cramer's V with month at least 0.3, or NMI at least 0.1 |
| `drift_june` | PSI at least 0.25 |
| `external_score`, `feasibility_unknown` | 2.5 |

The "repetitive" level for the month statement: V at least 0.7 or NMI at least 0.5. Changes at the event can be real signal (a new device, a new token), so they only flag.

### 3.4 Outputs

- `C2/checks/field_checks.csv`: one row per field and file range, every measured value, every rule that fired. Nothing is suppressed, redacted or masked.
- `C2/checks/field_status.csv`: field, result, reasons. Later tools read it.
- `C2/checks/clusters.csv`, `C2/checks/month_overlap.csv` (month against every date or calendar field: NMI, V, PSI, and the statement).
- `C2/checks/summary.txt`, printed, at most 40 lines of 90 characters:

```
FIELD CHECKS  list=<file> CONFIRMED|UNCONFIRMED  thresholds=<sha12>  layout=reorganized
pod raw columns 227 | files read: train 1-10, val 4950-4954, Test1 June (no labels)
fields 182 (v22b 96, f15298 61, both 12, a3 0) | PASS n FLAG n WAIT n STOP n
STOP by rule: duplicate 23 (kept once), left_out_recipe 31, uses_outcome 10, ...
WAIT: status n, hold n, not_feasible n
overlap 15298 with V22B or base: 25 kept once (list in field_checks.csv)
month: repetitive with 0 fields; overlaps month: cprsrvc__dbt_currchp_dttm__days V 0.34
STOP  name                                   rule(s) and value(s)
...   (every STOP field; by name only if more than fit)
FLAG  name                                   rule(s)
...
clusters: n (largest n fields); threshold 0.8
width if PASS and FLAG enter: 30 -> NNN tokens per transaction (month in)
full table: checkpoints/new_fields/checks/field_checks.csv
```

The numbers above are placeholders, not results.

### 3.5 Order on the pod

intake, then field checks, then the CPU screen (3.6), then the owner's list is adopted, then the checks run again if the adopted list differs, then enriched copies, then the artifact.

### 3.6 The CPU screen, re-delivered (usefulness layer 1)

The owner asked for it again ("since that's kind of outdated, I don't know if we still have it"). It is delivered in `FS/` as a self-contained copy of the screen in `fraud/experiments/features/screen/` (moved there by the reorganization from `waqas/v2/screen/`). The old folder is left as it is, as the record.

**What stays the same.** The account-grouped paired XGBoost screen (`usefulness.run_screen`: the same account folds for both arms, pooled out-of-fold AP, the account-cluster bootstrap of the AP difference, the difference by month, grouped permutation importance), the fixed `PASS_RULE` and `FINAL_RULE` texts, the noise floor (the `null_noise` family and the base arm refitted at XGBoost seeds 43 and 44, run first), the probes (`future_invariance`, `single_feature_ap`, `label_shuffle`) and the stability tools (`temporal_screen`, `psi`, `feature_drift`). The logic is copied, not changed.

**What changes.**
- **Layout and imports.** Modules carry the `fsc_` prefix and load each other by path, so no bare-name import and no `PYTHONPATH` trick is needed. Project modules come through the resolver.
- **Driven by the field map.** No feature name is hard-coded. The base arm is the 23 inputs from `fraud/configs/predictors.csv`, month included, because the transformer uses month. Families are the map's groups among fields that passed the CPU checks: `tfm` (V22B and both), `f15298`, `a3`, and `all_new`. Engineered columns come from `nf_recipes.py`. The 26 October families stay available by name.
- **Month on top.** Two extra arms: base plus all new fields, with and without month. Run on account folds and on the time split (train before 2025-04-01, test after). In the time split, April and May are months the training rows never saw, as June is for the model, so it is the honest read of month. Account folds see every month in training and overstate month. Both are reported; the month statement (3.2) uses the time split.
- **Per-feature ranking, labelled "XGBoost's view, not the transformer's".** (a) XGBoost's built-in SHAP contributions: `booster.predict(DMatrix(X, enable_categorical=True), pred_contribs=True)` on the held-out fold of the `all_new` arm, the absolute contribution summed per feature (mean over rows), on a fixed sample of 200,000 held-out rows per fold. (b) The screen's grouped permutation importance per feature and per cluster on the held-out folds (AP drop). Written to `C2/screen/feature_rank.csv`.
- **No row-level output and no redaction step.** The JSON holds aggregates with full numbers. The old note about checking the JSON for long numbers is dropped (owner rule).
- **Cost guard.** It times one fold first, prints the projected total, and stops above `--max-hours` (default 6). `--train-neg-rate 0.1` stays the recommended first run.
- **Dry run in one command:** `$PY FS/fsc_run.py --dry-run` builds a tiny synthetic file and map in a temporary folder and runs the whole screen. If `xgboost` is missing it says so and runs with scikit-learn's `HistGradientBoostingClassifier` for the dry run only (no SHAP).

**Command on the pod** (Copilot adapts paths only):

```
CUDA_VISIBLE_DEVICES= nice -n 19 $PY FS/fsc_run.py --map NF/FIELD_MAP.csv \
  --status checkpoints/new_fields/checks/field_status.csv \
  --base s3://mrmcd-analytics-mrm-mmr-dsai/tfm_raw_data --start 1 --end 10 --cred-path <credentials file> \
  --extract-start 2024-10-01 --train-neg-rate 0.1 --temporal-split 2025-04-01 \
  --k 5 --n-boot 500 --seed 42 --extra-seeds 43 44 \
  --drift-base s3://mrmcd-analytics-mrm-mmr-dsai/tfm_EVAL_raw_data --drift-start 8000 --drift-end 8010 \
  --drift-extract-start 2025-05-01 --drift-month 2025-06 --out checkpoints/new_fields/screen
```

**What it decides.** Nothing. XGBoost has no history window, so the screen ranks families and features and flags leaky or unstable ones. A family that fails the label shuffle or future invariance probe is listed as leaky on the checks screen. Adoption is decided only by the transformer fits.

## 4. Preprocessing

### 4.1 Enriched copies (engineered fields and dates)

`$PY NF/nf_build_enriched.py` writes parquet copies of every file any stage 2 candidate reads (training 1-10, EPOCH_VAL 4950-4954, RANK-A, RANK-B, SELECT, Test 1, DS_TRAIN, DS_SELECT) under `ENR/tfm_raw_data/part_<n>.parquet` and `ENR/tfm_EVAL_raw_data/part_<n>.parquet`. They live on S3, because the configs read every data path through the S3 filesystem when `s3.cred_path` is set.
- Each copy holds every original column, unchanged and in its original order, then one column per engineered field (numbers as float64, codes as strings). Raw fields are not changed or recomputed.
- Rows keep their order. Each file is built from its own rows, so each account's whole history in the split is used.
- It refuses an existing prefix, any UNCONFIRMED map row, and a map newer than `field_status.csv`.
- **Identity proof per file**, written to `C2/enriched/identity/<range>/part_<n>.json`: the same row count; the same sequence of (`Nmap_account_reference_xid`, `fi_transaction_id`); for every original column, the SHA-256 of its Arrow data equal to the original's; the new columns' names and types as the map says. A failure deletes nothing, stops the build (exit 3) and names the file and column.
- It measures one file first and prints the projected size and time before writing the rest. Copies hold all original columns, so they are about the size of the originals plus the new columns.
- The candidate's configs point `data.train_base`, `data.val_base` and `eval.base` at the copies. The control keeps the original files. With the same rows in the same order and the same seed, the candidate's file shuffle and window order are the control's.

Only the candidate reads copies, and only when its inputs include an engineered field. A step with raw fields only reads the original files.

### 4.2 Why the base fields are copied, not refit

The control is the stage 1 retrain on artifact version 1. For it to be a valid control, every base field's preprocessing must be byte-identical to version 1. A field's fit depends only on its own column, the fit files, their row order and the library version (scout A, part 2). But tied counts take vocabulary indices in order of first appearance, and means are float sums, so whether the pod's builder reproduces version 1's bits is not knowable from here. `manifest.json` is never byte-identical (it holds the build date). So the safe route is to fit only the new fields with the unchanged builder and copy version 1's base-field files byte for byte. This is the plan's "one refit adds the fields", with the base fields' identity proven by per-file hashes.

### 4.3 Steps (`nf_build_artifact.py`)

It refuses to start if any map row is UNCONFIRMED, if `field_status.csv` is missing or older than the map, or if the target version is `1` or already exists on `ART`.
1. **Fields to add:** every CONFIRMED row with result PASS or FLAG, from every group in the steps file (on or off), in the map's order. One extended artifact serves every step, because a field in the artifact but not in a predictor list is never read.
2. **Scratch fit.** It writes `C2/artifact/new_fields_only.csv` (columns `feature, type, source=raw, version, description`; `version` equals the base rows' value, so the as-run `predictors.version` keeps them) and `C2/artifact/preprocessing_scratch.yaml`: the data base is `ENR/tfm_raw_data` if any new field is engineered, else the original training base; the file range is version 1's `fit_files` from its `manifest.json` (it refuses if they are not one run of `part_<n>` files); `datetime` as in `fraud/configs/preprocessing.yaml`; output `ART`, version the scratch name (default `nf_scratch1`). Then it runs the unchanged builder: `$PY fraud/scripts/build_preprocessing_artifacts.py --config C2/artifact/preprocessing_scratch.yaml`.
3. **Merge** into the extended version (default `nf_ext1`, a setting) on `ART`: every `feature__<name>.json` of version 1, copied byte for byte; every file of the scratch version, copied byte for byte; a new `manifest.json` (`artifact_version` the new name, `predictor_version` and `fit_files` from version 1, `created` today, `features` the sorted union). It refuses if the scratch `fit_files` differ from version 1's, or a new name is already in version 1.
4. **Predictor lists** (`nf_make_configs.py`, section 6): for each input set, the 23 lines of `fraud/configs/predictors.csv` byte for byte and in order, then one line per new field in the map's order; and the month-out list, the same minus the month line and nothing else.
5. **Hashes** in `C2/artifact/artifact_hashes.json`: the SHA-256 of every file in version 1, the scratch version and the extended version; the payload digest of the 23 base predictors; the payload digest of each input set; every predictor list's SHA-256.

The payload digest is the one the input contract stores in every checkpoint (`sequence_contract.input_contract.artifacts_sha256`): SHA-256 of the JSON of `{name: entry}` for the active features. The tool computes it with `artifact_payload_sha256` from `fraud/experiments/embedding/export_records.py` (unhashed), and a test checks it against the unchanged input contract.

A group added later (A3) gets a second extended version that copies the first byte for byte and adds its fields the same way.

### 4.4 Month as a switch

Two predictor lists over one artifact. Month stays in by default. The month-out config changes only `predictors.csv_path`; `datetime.fields` keeps month (a calendar field that is derived but not listed is ignored, while a listed field that is not derived would stop the run). The `20261019` no-month artifact is not needed and not built.

### 4.5 The check (`nf_check_artifact.py`)

It prints one screen, writes `C2/artifact/artifact_check.json`, and stops the queue (exit 3) unless every line passes.
- Every file of version 1 has a file of the same name in the extended version with the same SHA-256: `base fields byte-identical: 23/23` (and the count of all version 1 files if it holds more).
- Every new field's file equals its scratch file byte for byte.
- The extended manifest lists exactly version 1's features plus the new ones; `fit_files` equal version 1's.
- The extended version loads with the unchanged `PreprocessingArtifacts.load`.
- The payload digest of the 23 base predictors in the extended version equals the digest stored in the control checkpoint and in the kept seed 42, 43 and 44 checkpoints (read on CPU from each checkpoint's sequence contract).
- The first 10,000 rows of training file 1 encode to identical arrays for every base field under version 1 and the extended version.
- Each month-out list equals its month-in list minus exactly the month line.
- Each new code field's vocabulary size equals the one the CPU checks measured.

Optional, information only and used by no run: a full refit of every field into a diagnostic version, reporting which base fields' bytes differ from version 1. It shows whether the pod's builder reproduces version 1.

## 5. Timing at the new width

**Tokens.** Tokens per transaction = 2 x C + K + 1, where C is the number of continuous predictors (each brings a value token and a missing-flag token), K the number of categorical predictors (calendar fields included), and 1 the time gap; plus one CLS token. Base: 6 and 17 give 30 (31 with CLS). The width of each step is computed from its real predictor list and artifact. With about 190 fields it can pass 300 tokens if most are numbers, so it is measured, not assumed.

**Reuse first.** Stage 1's tools fit if they are on the pod (the stage 1 build was paused by the owner on 2 November; `11_01_2026/stage1_spec/README.md`):
- `width_timing.py --widths <tokens> --extra-categorical-share <the step's share>` gives synthetic compute per update, validation compute per batch, peak memory, and the micro-batch search (one process per attempt; chunks halved and accumulation doubled after an out-of-memory exit; eval batch searched from 1,024 down to 128; stage 1 review items 16 and 29);
- its timing callbacks, loaded by path, time a short real-data run.
If they are not present, `nf_time_width.py` does both itself, by the same method (stage 1 design sections 11 and 12 with the review corrections).

**The real-data run** (`nf_time_width.py real --config NF/configs/<run>.yaml`): the trainer's own `main` with `output.checkpoint_dir=C2/timing/<run>/fit training.max_epochs=1`, and, inside the patched `build_trainer` only, `limit_train_batches = 300 x accumulation`, `limit_val_batches = 200`, `num_sanity_val_steps = 0`. It measures median compute per update after 50 warm-up updates, data wait per update (the categorical encoding is a Python loop per row and grows with the number of codes), validation per batch, peak allocated and reserved memory for training and validation (from `torch.cuda` inside the run; the GPU name from `nvidia-smi`), and GPU use every 5 seconds. A test proves every hashed file's bytes are unchanged by a run.

**Costs.** Rows do not change with width, so updates per epoch do not change (2,103 at about 4,100 targets per update, stage 1's rule S7):
- C_f = C_c x (time per update at the new width / time per update at the base width), from the same session's base-width run;
- C_v,f = C_v x the same ratio for validation batches;
- the screen prints C_c, C_f, C_v, C_v,f, peak memory, the data-wait share and the step's maximum GPU hours (6.8).
If stage 1 gave no C_c, the screen prints the projected epoch from the timed run directly, labelled as a projection.

**The row limit and the memory rule, declared before any fit.** The 65,535 limit counts rows only (training batch x `max_chunk_rows`; validation eval batch x max(32, 21)), so width does not change it. Memory grows with width. If peak memory at the new width is above 85% of the device memory, or the timed run runs out of memory, the step's fits halve `training.batch_size` and double `training.accumulate_grad_batches` (repeated until it fits). Targets per update stay about 4,100. The timing reruns at the new micro-batch. If validation runs out of memory, `training.eval_batch_size` halves (down to 128). The values go into `SETTINGS.yaml` (`microbatch:` per run) before the step's first fit, and the config writer prints them. The control keeps its as-run batch. `num_workers` is never changed, because it changes how files are split across workers and so the data order.

## 6. The run sheet

### 6.1 Settings

The current [STEPS.yaml](fraud/experiments/features/new_fields/STEPS.yaml) and
[SETTINGS.yaml](fraud/experiments/features/new_fields/SETTINGS.yaml) are the shipped defaults (`NF/STEPS.yaml` and
`NF/SETTINGS.yaml` on the pod). Read those files directly; this design does not duplicate their settings snapshot.
The planner reads the steps before every job. Settings are written before the first read; the reader records the
settings SHA-256 and refuses a changed decision section later. Copilot adapts paths only, never the rules.

`NF/UPSTREAM.yaml` (Copilot fills it from the stage 0 and stage 1 reports; facts, not decisions): the stage 1 control folder (`checkpoints/reproduce/retrain_seed42/` by stage 1's design) and its learning rate; `stage1_rescore_exact`, `stage1_route_test`, `stage1_same_batch` (true or false); the stage 1 control's `source_sha256`; `kept_dir` (`models/sequential_hier_allpos_h20_chunk`); the kept seeds' SELECT prediction files and receipts as Copilot finds them (probably under `tabular_fraud_old/runs/v2/L3/scores_slide/` for seed 42 and `tabular_fraud_old/runs/v2/seed_robustness/ALLPOS_H20_CHUNK_seed4{3,4}/` for 43 and 44; verified by `predictions_sha256`, never by the stale absolute paths in the receipts); stage 0's run folders under `runs/tuning/`; stage 1's timing (C_c, C_v, S).

### 6.2 Preflight (phase P0, CPU)

`nf_run_all.sh` starts with these and stops at the first failure:
1. The resolver prints the layout.
2. The guard: the trainer's `source_sha256()` equals the stage 1 control's recorded `source_sha256` (when stage 1 has run) and the latest start or resume identity of every stage 0 manifest under `runs/tuning/` and `checkpoints/` (it stops if no stage 0 manifest is found, and names the roots searched). Exit 3 on a difference.
3. Stage 1's checks passed (`stage1_rescore_exact`, `stage1_route_test`, `stage1_same_batch` true), and the control's manifest status is `finished` or `budget_reached`, with `best.ckpt` present. If stage 1 has not run, the planner adds the control fit (P1) and marks the kept seed 43 and 44 checkpoints as not valid controls.
4. `learning_rate_source` is not blank.
5. `artifact_check.json` passed; the map holds no UNCONFIRMED row; the enriched identity proofs all passed (if any step reads copies).
6. Every `NF/configs/<run>.yaml` exists, and `nf_make_configs.py --verify` shows each differs from `fraud/configs/sequential_hier_allpos.yaml` only in the allowed keys: `predictors.csv_path`, `artifacts.version`, `data.train_base`, `data.val_base` and `eval.base` (copies only), `training.learning_rate`, the micro-batch pair and eval batch (memory rule only), `output.checkpoint_dir`, `experiment.run_name`. Any other difference is refused.
7. If the learning rate equals the control's, the control's resolved config equals the base-inputs config except output and run-name keys.
8. The GPU is free and nothing else runs (6.6).
9. `rank_check.json` exists; its result sets the decision population for every read.

### 6.3 Jobs and the chain

The planner (`nf_plan.py next`) turns `STEPS.yaml`, `KEPT.json` and the saved reads into the next job. `KEPT.json` holds the kept inputs (an input-set id such as `base`, `a1`, `a1a2`) and the kept fit at each seed. Each read appends its decision to `C2/DECISIONS.log`.

| Phase | Job | Runs when | Output |
|---|---|---|---|
| P0 | preflight | always | `C2/reads/preflight.json` |
| P1 | fit `nf_control` seed 42 (base inputs) | the learning rate differs from the stage 1 control's, or stage 1 has not run; it becomes the control | `C2/runs/nf_control/seed42/` |
| P2 | score the control on RANK-B; score kept seeds 42, 43, 44 on RANK-B; `nf_read.py spread` | RANK-B decides (the kept seeds' scores give the UDR seed spread and the confirmation controls) | `C2/scores/`, `C2/reads/spread_rank_b.json` |
| S.1 | fit the step's candidate, seed 42 | each step that is on | `C2/runs/nf_<step>/seed42/` |
| S.2 | score it on RANK-B (or SELECT if SELECT decides) | always | `C2/scores/nf_<step>_seed42__rank_b.parquet` |
| S.3 | attention pass on RANK-A | `attention: every_candidate` | `C2/importance/nf_<step>_seed42/attention.csv` |
| S.4 | `nf_read.py read --step <step>` at one seed | always | `C2/reads/<step>_1seed.json` |
| S.5 | fit candidate seeds 43 and 44; controls at 43 and 44 (6.4); score all; read at three seeds | S.4 says RUN SEEDS 43 AND 44 | `C2/reads/<step>_3seed.json` |
| S.6 | score candidate and control on SELECT; `select-check` | RANK-B decides and S.4 or S.5 says ADOPT, pending the SELECT check | `C2/reads/<step>_select.json` |
| S.7 | downstream check of the step's kept fit (7.8) | `downstream: every_kept` and the kept fit has no export yet | `C2/downstream/<run>_seed42/`, `C2/reads/<step>_lift.json` |
| S.8 | permutation importance of the candidate | `importance: every_step` | `C2/importance/nf_<step>_seed42/` |
| I | permutation importance of the final kept fit | `importance: final`, after the last adding step | `C2/importance/<kept run>_seed42/` |
| P | pruning: drop the features or clusters of I whose UDR-drop and AP-drop intervals both have a lower end at or below zero (new fields only; base inputs stay); fit seed 42; score RANK-B; read under the prune rule (8.6) | P is on | `C2/reads/P_1seed.json` |
| B | month out on the kept inputs, seed 42; score; read under the month rule; confirmation as S.5 | B is on | `C2/reads/B_1seed.json` |
| E1 | score every stage 2 fit and the control on Test 1 (report only) | at the end | `C2/reads/test1_report.txt` |
| E2 | Test 2 for the final kept fit and the control, by the plan's BENCH path, if it is ready on the pod; else it waits and blocks nothing | at the end | `C2/reads/test2_report.txt` |
| E3 | result summary | at the end | `C2/reads/RESULT.txt` |

**The chain.** A step that adopts moves `KEPT.json` to its inputs and fits. A step that keeps the control is dropped, and the next step builds on the previous kept inputs. With `one_step_all: true`, one step `ALL` adds every group that is on, against the control, under the same rules.

### 6.4 Controls

- **Step A1 at seed 42:** the stage 1 retrain, or P1's fit.
- **Later steps at seed 42:** the previous step's kept fit, as the owner asked. That fit won its step on RANK-B, so its luck there makes the next gain look smaller: the bias works against adding fields, and every read says so. `refit_kept_control: true` refits it at seed 42 first (the plan's control rule; 10 epochs more per step).
- **Seeds 43 and 44 for a step whose control is base inputs:** the kept seed 43 and 44 checkpoints, only if all of these hold, checked at the start of S.5 and logged: stage 1's rescore and same-batch tests passed (the reorganized code reproduces the old one); the base fields' artifact is unchanged (4.5); the learning rate is 3e-4, the kept runs' rate; each kept `config.yaml` equals the base config except `training.seed` and output keys; `deterministic` false as theirs. Their selection bias (they chose today's model on Test 1 and SELECT, toward base inputs and month in) is written into `DECISIONS.log`. Otherwise `nf_control` seeds 43 and 44 are fit.
- **Seeds 43 and 44 for a step whose control has new inputs:** that control's own fits at 43 and 44 if they exist (from its own confirmation), else they are fit.

### 6.5 Commands, run names and folders

```bash
cd <the project root on the pod>
PY=<the pod's Python for the project>     # POD.md sets PY, NF and FS once
NF=fraud/experiments/features/new_fields
# one fit (the queue builds this line; nothing else is ever passed)
$PY -m fraud.scripts.train_sequential_hier --config $NF/configs/nf_a1.yaml training.seed=42 \
  output.checkpoint_dir=checkpoints/new_fields/runs/nf_a1/seed42 \
  >> checkpoints/new_fields/logs/nf_a1_seed42.log 2>&1
```

- Run names: `nf_control` (base inputs), `nf_a1`, `nf_a2`, `nf_a3`, `nf_all` (one-step switch), `nf_p` (pruned), `nf_b` (month out on the kept inputs), and `nf_k<step>` for a refit of a kept control. The input-set id of each run is in its config's header and in `KEPT.json`.
- Folders: fits `C2/runs/<run>/seed<NN>/`; scores `C2/scores/<run>_seed<NN>__<population>.parquet` (with the scorer's `.json` receipt and `.exposure.json`); reads `C2/reads/`; logs `C2/logs/<job>.log`; the queue log `C2/queue.log`; timing `C2/timing/`; importance `C2/importance/`; exports `C2/exports/`; downstream `C2/downstream/`. New training writes only under `checkpoints/`. Nothing is written into `models/`.
- The learning rate comes only from `SETTINGS.yaml` (`learning_rate`, 3e-4 until stage 0 reports), written into each config by the config writer.

### 6.6 Queue mechanics

- **Start.** `bash $NF/nf_start.sh` runs the busy check and refuses (exit 4) if anything runs. Otherwise it starts `nf_run_all.sh` with `nohup`, appending to `C2/queue.out`, prints the PID and the report command, and tails `C2/queue.log`. Closing the tail does not stop the queue. Neither Copilot nor the queue starts on its own: the owner runs `nf_start.sh` or tells Copilot to.
- **Busy check** (stage 1's rules, section 15.3, with review item 23): a process whose command line is an interpreter (`(\S*/)?python(3(\.\d+)?)?` with any options) running a trainer or scorer by module or path (`fraud.scripts.train_*`, `fraud.scripts.score_*`, `waqas.*train*`, `waqas.*score*`, `train_v2.py`, `score_v2.py`), stage 1's or stage 2's tools, stage 0's queue script (`lr_screen.sh`, as Copilot adapted it) or stage 1's `run_all.sh`; a compute process on the GPU, or more than 1,024 MiB used with no process of ours; a live `RUNNING.lock.json` under `runs/tuning/` or `checkpoints/`. Our own PID and parents are excluded. It runs before every GPU job.
- **One job at a time.** GPU jobs (fits, scoring passes, timing, importance, exports) run in sequence. The scorer uses CUDA whenever it is available, so a scoring pass is a GPU job. CPU jobs run with `CUDA_VISIBLE_DEVICES=`.
- **Skip if it exists.** A fit whose folder holds a complete run (status `finished` or `budget_reached`, `best.ckpt` present) is skipped, never overwritten. A folder that exists but is incomplete stops the queue with "exists but incomplete: rename it to run it again"; the queue never resumes on its own. A scoring pass whose `--out` and receipt exist (receipt hash matching) is skipped; leftover partial outputs (an exposure file with no receipt) stop with "partial outputs: rename them". A read whose decision JSON exists is skipped and returns its saved decision, so a saved STOP or KEEP is never stepped over (stage 1 review item 3).
- **Logs** are appended, never truncated: one per job under `C2/logs/`; `C2/queue.log` with `start <job> <utc>` and `end <job> rc=<rc> <utc>` lines (stage 0's format); `C2/READS.log` (one line per read: UTC, step, population, files, runs, settings SHA-256, decision); `C2/DECISIONS.log`.
- **Exit codes** (stage 1's): 0 done; 1 a crash; 2 bad arguments; 3 STOP (a check failed); 4 refused (busy GPU, an output exists, a wrong input or layout); 5 every decision read but a reported step failed (Test 2, an attention pass, a downstream fit). A failed fit or scoring pass stops the queue, because later jobs depend on it. The last line is `queue end rc=<n> at <phase>; report: checkpoints/new_fields/REPORT.txt`.
- **Restart.** Running `nf_start.sh` again continues at the first job whose output is missing.

### 6.7 Morning report

`$PY $NF/nf_report.py` prints one screen (at most 40 lines of 90 characters) and writes `C2/REPORT.txt`. It works at any time. Placeholders, not results:

```
NEW FIELDS <utc>  layout=reorganized  source=<12> = control: yes  GPU <name from nvidia-smi>
settings lr=3e-4 (<stage 0 report>)  decide=RANK-B  bar=+0.0100  rules=<12>  steps=<12>
steps: A1 on, A2 on, A3 off, P off, B off, one_step_all off
inputs: kept=a1 (base + 78) tokens 30 -> 132; artifact nf_ext1 base 23/23 identical
timing a1: C_c 1.9 h  C_f 4.1 h  C_v 0.6 h  C_v,f 1.3 h  peak 61 GB  microbatch as_run
run                     seed status          epochs best  valid_ap  h/epoch
control (stage 1)       42   finished        9      3     0.1371
nf_a1                   42   finished        10     4     0.1402    0.41
scores done 6  skipped 0  failed 0
reads: A1 1 seed  RUN SEEDS 43 AND 44  (gain +0.0078 < T1 0.0154)
lift A1: embedding lift UDR +0.012 (control +0.015); flag: no
importance: not run yet (final)
next: S.5 nf_a1 seed43 (running since <utc>, epoch 2)
queue: failed jobs 0
```

Statuses: complete (`finished` or `budget_reached`), FAILED rc=n, RUNNING, INCOMPLETE, MISSING.

### 6.8 Budget (maxima in epochs, before early stopping)

Each count is epochs at its own run's measured cost.

| Item | Epochs |
|---|---|
| Control refit, only if the rate is not the stage 1 control's, or stage 1 has not run | 10 x C_c |
| One adding step at one seed | 10 x C_f(step) |
| Its confirmation | 20 x C_f(step), plus 20 x C_control if the seed 43 and 44 controls do not exist |
| A kept-control refit (`refit_kept_control: true`, the owner's option) | 10 per later step |
| Optional steps, each at most (the plan) | A3 50, month out (B) 50, pruning (P) 10; the switch in place of A1 and A2 50 (plus 10 for a new control); the cyclical calendar (C), not in the plan, at most 50 |
| Default steps (A1, A2), maximum (updated: the plan's number) | 80 = 20 x C_c + 30 x C_f + 30 x C_g, plus 10 x C_c (90 in all) when a new seed-42 base control is fit |
| Default steps, least | 20 (A1 and A2 at one seed, control reused) |

Scoring adds: one RANK-B pass per fit; three for the kept seeds on RANK-B; one SELECT pass per fit in a decision that would change the kept inputs; one Test 1 pass per fit; one RANK-A attention pass per candidate; two export passes per kept fit (DS_TRAIN is about the size of the ten training files, so about 3.5 RANK-B passes, plus one DS_SELECT pass); and permutation importance (7.6), whose estimate is printed before it starts.

## 7. Scoring sheet

### 7.1 Commands

All scoring uses the unchanged scorer. `<cfg>` is the run's own `resolved_train_v2.yaml` for stage 2 fits and the control (its `eval.base` already points at the copies when the run reads copies), and `models/sequential_hier_allpos_h20_chunk/seed<NN>/config.yaml` for kept seeds. `<tag>` is `<run>_seed<NN>`, `control_seed42` or `kept_seed<NN>`.

```bash
# RANK-B, the decision population (the reader selects June targets)
$PY -m fraud.scripts.score_sequential_hier --config <cfg> --checkpoint <dir>/best.ckpt \
  --out checkpoints/new_fields/scores/<tag>__rank_b.parquet --population OTHER --purpose new_fields_rank_b_decision \
  eval.file_start=8244 eval.file_end=8259
# SELECT, one logged read per decision that would change the kept inputs
$PY -m fraud.scripts.score_sequential_hier --config <cfg> --checkpoint <dir>/best.ckpt \
  --out checkpoints/new_fields/scores/<tag>__select.parquet --population SELECT --purpose new_fields_select_check \
  eval.file_start=8206 eval.file_end=8216
# Test 1, report only
$PY -m fraud.scripts.score_sequential_hier --config <cfg> --checkpoint <dir>/best.ckpt \
  --out checkpoints/new_fields/scores/<tag>__test1.parquet --population DEV_OOT --purpose new_fields_report \
  eval.file_start=8000 eval.file_end=8010
```

The scorer writes `<out>.json` (receipt) and `<out>.exposure.json` for every pass, and refuses an existing `--out`. For a run folder with a `run_manifest_v2.json` it appends a "scored" record, which makes the run final; that is right for every stage 2 fit and for the stage 1 retrain (stage 1 scored it in place too). Kept runs in `models/` have no manifest, so nothing is written next to them.

### 7.2 RANK-B: what it needs

No hashed change. It needs `nf_rank_check.py` to pass (the open plan item, CPU 4), for RANK-A and RANK-B alike:
- files 8228-8259 exist under `eval.base`;
- `splits/file_inventory.json` shows June targets in them, and gives the June fraud count per half (estimate about 2,550 each, unverified);
- no population in `splits/populations.yaml` or `splits/population_roles.yaml` uses any of them;
- no exposure record or receipt it can find names an overlapping file range (it prints every root it searched);
- BENCH rows come from files 8000-8200, so there is no BENCH overlap.
The reader checks that every receipt's files are exactly the population's range and keeps RANK-B's read log in `READS.log`. A RANK-B role line in `splits/population_roles.yaml` is optional, after the owner's yes; it is a records file, not hashed, and no run needs it. If the check fails, June SELECT decides as a single logged read: no independent check remains, and every read screen says so.

### 7.3 SELECT

Each fit is scored on SELECT at most once. A decision reads SELECT June once, only when it would change the kept inputs (ADOPT, a pruned list kept, MONTH OUT). The kept seeds' existing SELECT files are reused when their `predictions_sha256` matches the receipt and the receipt's `checkpoint_sha256` matches `best.ckpt`. Seed 42's recorded SELECT number (0.110288) is June targets; seeds 43 and 44's recorded numbers are full files. The reader always filters to June targets, so they are never mixed.

### 7.4 Test 1 and Test 2

Test 1 (8000-8010) is scored for every stage 2 fit and the control at the end and reported only. Test 2 (BENCH) is reported once, at the end, for the final kept fit and its seed-42 control, by the plan's BENCH path (row-alignment check and the LoB exclusions first). If that path is not ready on the pod, Test 2 waits and blocks nothing.

### 7.5 The control's scores and the kept seeds

- **The control.** Stage 1 scores the retrain on Test 1 and SELECT (`checkpoints/reproduce/retrain_scores/test1.parquet` and `select_full.parquet` by stage 1's design). Stage 2 scores it on RANK-B (P2). If the control is P1's refit, it is scored on all three.
- **Kept seeds 42, 43 and 44** are scored on RANK-B in P2 when RANK-B decides: the UDR seed spread needs them, and seeds 43 and 44 are then ready as confirmation controls. They are valid controls only under 6.4.

### 7.6 Permutation importance on the transformer (usefulness layer 2)

`nf_importance.py` measures how much each feature, and each cluster of correlated features, matters to a trained fit. Scoring only, on RANK-A (8228-8243, June targets), or on EPOCH_VAL if RANK-A cannot be scored (then month's importance is overstated, because EPOCH_VAL months were seen in training). Never on RANK-B, so the decision population stays clean.

**How it drives the scorer without editing it.** It imports the scorer through the resolver and calls the scorer's own `load_for_scoring(cfg, checkpoint)`, which builds the checkpoint's model, the target-ending dataset and the loader exactly as the scorer does. It then wraps `_encode_file` on that one dataset object, in memory: the original runs first, then the unit's encoded columns are permuted. The batch loop is the scorer's (`_model_inputs`, `select`, float32, no autocast). No file is edited and no data is copied. If the start method of the loader workers is not `fork`, it sets `num_workers` to 0 for its own passes and says so.
- **Permutation.** For one unit (a feature, or a cluster) and one repeat, each file's rows get one fixed permutation (from the permutation seed, the unit, the repeat and the file name). The unit's columns are permuted together: a number's value column and its missing flag, a code's column, every member of a cluster. Each file is a bucket of whole accounts, so values come from the same population and months. Because the permutation is applied to the file's encoded rows before any window is built, a transaction carries the same permuted value wherever it appears, as a target or in another transaction's history.
- **Units.** Every predictor of the fit (the 23 base inputs, month included, and every new field) and every cluster from `clusters.csv`. The time gap is computed later, inside the window builder, and is not a unit.
- **Account subsample** (default 25% of RANK-A's accounts, by a hash of the account id with a fixed salt, so the same accounts in every pass): the wrapper keeps those accounts' rows before encoding, so histories stay whole. The reference pass uses the same subsample.
- **Measures.** On the subsample's June target rows: UDR at 0.6%, AP (and VDR and FPR reported), for the reference and for each permuted pass. Drop = reference minus permuted. The account bootstrap uses the same draws for the reference and every permuted pass (8.3), giving a 90% interval for each drop; with repeats, the drop is the mean over repeats and the spread between repeats is printed.
- **Cost, printed before it starts.** GPU hours = (1 + U x R) x seconds per scored row x rows in the subsample / 3,600, where U is the number of units, R the repeats, and seconds per row come from the fit's own RANK-B scoring exposure record (start and end time, rows). It refuses above `max_gpu_hours` (default 24) unless the owner raises it. Options: `--account-share`, `--repeats`, `--seed`, `--units singles|clusters|both`, `--max-gpu-hours`.
- **Null check, before the permuted passes.** On one RANK-A file, the wrapped loop with the identity permutation and the plain scorer loop give bitwise equal scores, ids and labels. A difference stops the tool (exit 3).
- **Outputs.** `importance.csv` (unit, members, kind, drop in UDR with its interval, drop in AP with its interval, repeats, rows, frauds), aligned score arrays per pass (float32, with a hash of the row order), and `summary.txt`: one screen with the top 10 and the bottom 10 clusters by UDR drop (AP drop as the tie-break), the attention rank beside each, and the note "permutation importance of the transformer on RANK-A June targets; a cluster is permuted together so twins do not hide each other".
- **Disk.** The in-memory route writes only score arrays (a few MB per pass). The alternative, permuted parquet copies of RANK-A, would cost about one full copy of the read columns per pass (several GB each, hundreds of passes), so it is kept only for a check of a few features.

### 7.7 Attention importance (a free cross-check)

The FT-Transformer attention importance (Gorishniy et al. 2021, arXiv 2106.11959): the CLS token's attention to each feature token, averaged over heads, layers and rows. In this model the feature tokens appear only in the first stage, `token_encoder`: two `nn.TransformerEncoderLayer` blocks with 8 heads, which pool each transaction's tokens into its CLS (`sequential_hier.py:150-157`, `:288-293`). That layer calls attention with `need_weights=False`, so the weights are never returned.

**It can be captured without editing hashed code.** A forward pre-hook on each `token_encoder` layer records the layer's input. The tool then recomputes the CLS row's attention from outside, with the layer's own weights: `z = norm1(x)` (the layers are `norm_first`), `q, k = in_proj(z)`, softmax(q_cls k^T / sqrt(6)) per head. There is no mask in this stage, and dropout is off in evaluation. Checked on the laptop on CPU with torch 2.14 (a probe script, a layer built as `_encoder` builds it): the recomputed weights equal `need_weights=True` to 9e-8, both hooks fire in evaluation under `no_grad`, and the model's output with the hooks is bitwise equal to the output without them. The pre-hook fires whether or not the fused fast path runs, because it records the layer's input, not the attention module's. The pod's torch may differ, so `test_new_fields_attention.py` repeats the check there.

- Rows: the target slot of each scored window only (the last real slot), so each transaction counts once.
- Tokens to features: the order comes from the checkpoint's sequence contract (continuous columns with the time gap last, then categorical columns with the missing flags last). A number's value token and its flag token are summed. The CLS token's attention to itself is reported apart.
- It runs inside the permutation tool's reference pass (no extra pass), and as its own RANK-A pass for each candidate fit (`attention: every_candidate`).
- Caveats printed on its screen: attention is not importance; it covers how a transaction's own fields are pooled, not how history is read; it is a cross-check of the permutation ranking.

### 7.8 Downstream check (the feature-store view)

For each step's kept fit (`downstream: every_kept`), with the unchanged tools in `fraud/experiments/embedding/`:
1. **Export** the 48-number embedding on DS_TRAIN 4001-4010 and DS_SELECT 8217-8227: `$PY -m fraud.experiments.embedding.export_embeddings --config <cfg> --checkpoint <ckpt> --out checkpoints/new_fields/exports/<run>_seed42/ds_train eval.base=<training base or its copy> eval.file_start=4001 eval.file_end=4010`, and the same for DS_SELECT on the evaluation base. The exporter records "exported" in the run's manifest, which makes the run final; stage 2 fits are final anyway.
2. **Check** each export with `check_export.py` (one row per scored row, unique ids, finite values, width 48, same-pass reconstruction within 1e-6).
3. **Contract and config** with `export_records.encoder_contract` and `export_records.downstream_config` (imported, unchanged). The handover function's "month absent" check belongs to the final freeze, not to this check, and is not called.
4. **Fit** with `downstream_xgb.py`: DS_TRAIN only, its fixed tree budget, seed 42; one DS_SELECT read. The raw arm uses `fraud/configs/predictors.csv` (the base raw fields, month dropped by the tool) for every step, so the lift measures the embedding, not the new raw fields.
5. **Use 1 now:** the embedding's lift = metric(raw + embedding) minus metric(raw), on UDR at 0.6% and AP, with a paired account bootstrap (8.7). **Use 2** (an offset on model 15298's score) is not built; it waits until 15298 scores for those rows arrive (`use2_15298_offset: off`).
6. The reader compares the step's lift with its control's lift (8.7). Each kept fit is exported once and reused.

## 8. The reader

`nf_read.py` is a generic paired comparison: a candidate against a control on the same rows, at the seeds available (1, or 3 after confirmation). It reads prediction files, their receipts and five raw columns. It never trains or scores.

### 8.1 Inputs and alignment

- A run table written by the planner: role (candidate or control), seed, run folder, checkpoint, prediction file, receipt.
- Each receipt must match: `predictions_sha256` equals the file's hash; `checkpoint_sha256` equals the run's `best.ckpt`; `files` equal the population's range; `validation_policy` is target-ending with window cap 32. Any mismatch stops the read (exit 3).
- The raw join: `load_raw` and `target_mask` from `fraud.scripts.compare_models` (through the resolver) read `fi_transaction_id`, `Nmap_account_reference_xid`, `transaction_dttm`, `frd_tag` and `transaction_amt` from each original raw file of the range. They refuse accounts that cross files.
- Rows R: June targets, 2025-06-01 <= `transaction_dttm` < 2025-07-01 (the scoring keeps the full-file history). Every fit must hold exactly the same (account, id) set on R, and its labels must equal the raw labels. Otherwise the read stops.
- Amount: `transaction_amt` from the prediction file, or from the raw join if the as-run config has no `data.amount_col`.

### 8.2 Point measures, per fit

- N = rows in R; F = frauds in R.
- Ranking: descending score, ties broken by the ascending identity key `json.dumps([str(account), str(id)])`, replaced by its rank among R (the same order in far less memory).
- Outsort: the top n = floor(N x 3 / 500) rows, exactly 0.6%, in integer arithmetic.
- UDR = frauds in the outsort / F (counts).
- VDR = fraud amount in the outsort / total fraud amount in R; null with a reason if an amount is missing, not finite or negative.
- FPR, as the bank uses it = false positives / true positives in the outsort = (n minus frauds in the outsort) / frauds in the outsort. Lower is better.
- AP over R, with equal scores as one threshold (as scikit-learn). For the SELECT check also AUROC and KS (KS read only after a whole tied-score group).
- These equal `modules/analysis` `outsort_metrics(y, scores, amounts=..., row_keys=..., percents=("0.6",))` on the same inputs (its `_outsort_cut`, boundary copies included only up to the budget), and the hashed `business_metrics._alert(y, amounts, None, order, 6, weights)` with `order` from `_ranking`. On the pod the reader recomputes the point and the first 10 bootstrap draws with `_alert` and prints `engine = _alert at 6 per mille: equal`; a difference stops the read. TFM's own metric keeps ties in input order and computes p x N in floats, so small differences from TFM's UDR are expected; the screen says so once.

### 8.3 Account bootstrap

- Units: the distinct `Nmap_account_reference_xid` values in R, in ascending string order.
- Draw b (b = 1 to 2,000): with `numpy.random.default_rng(20261102)`, draw as many accounts as there are, with replacement (`integers(0, n, n)`, counted with `bincount`, as `modules/analysis` `multiplicity_draws`). Each row gets its account's count as an integer weight. Draws are made one at a time, so memory stays flat.
- The same draws serve every fit in the comparison: the sequence depends only on the seed and the account list, which all fits share.
- Under weights, the outsort budget is floor(W x 3 / 500), W the total weight, and the boundary row's copies are included only up to the budget. AP, AUROC and KS are weighted the same way. Each fit is ranked once; each draw is three cumulative sums (the `RankedScore` method of `modules/analysis`, vendored into `nf_ranked.py`).

### 8.4 Differences

For each measure M (UDR, AP, VDR, FPR) and seed s: d_s = M(candidate_s) minus M(control_s). The gain g = the mean of the d_s. For draw b, g_b = the mean over seeds of the same difference under that draw's weights. sd_pair(M) = the standard deviation of g_b over draws. The 90% interval is the 5th and 95th percentiles of g_b; its lower end is the bootstrap lower bound LB. For FPR, lower is better, so its sign is printed as "candidate minus control, lower is better".

### 8.5 Thresholds and the UDR seed spread

- **One-seed threshold:** T_1 = t_(nu)(0.95) x sqrt(A + B), where A = sd_pair^2 is this read's account-bootstrap variance, B = 2 x sd_run^2, and nu = (A + B)^2 / (B^2 / df_run) is the Welch-Satterthwaite degrees of freedom. The UDR threshold governs the one-seed decision. T_1(AP) uses the same formula with the measured AP terms and is printed for information; there is no fixed AP threshold.
- **Assumption:** 2 x sd_run^2 is an operational one-seed rule assuming equal candidate and control seed variance, because one fit per arm gives no other estimate. No fixed floor or sd_null subtraction is used. This working rule does not establish coverage under unequal variances.
- **The spread step** (`nf_read.py spread --population rank_b|select_june`): for each measure, it reports the kept seeds 42, 43 and 44 and, when supplied, the current-pod base trio. The current settings specify pooling both trios for the decision spread. sd_run pools deviations within each trio, giving 4 degrees of freedom with both complete trios; a kept-only preliminary spread has 2 degrees of freedom. sd_null, the account-bootstrap same-recipe pair term, is information only. When RANK-B decides, each measure uses the larger spread from RANK-B and SELECT June, with its degrees of freedom (a tie takes the smaller df). When SELECT decides, only SELECT June's spread is used. A missing required spread refuses the read. With few degrees of freedom the measured spread is rough; the screen prints it and the t multiplier.
- **Zero or invalid spread:** a finite UDR spread of zero is reported and leaves T_1 undefined, with the seed-routing exception in section 8.6. A negative or nonfinite UDR spread stops the read; zero spread does not justify a one-seed adoption.

### 8.6 Decisions

**Adding steps (A1, A2, A3, ALL): the costly-change rule.** g = the UDR gain, candidate minus control.

| Seeds | Condition | Decision |
|---|---|---|
| 1 | g <= 0 | KEEP THE CONTROL |
| 1 | g > 0 and T_1 is undefined because the UDR seed spread is zero | RUN SEEDS 43 AND 44 |
| 1 | 0 < g < T_1(UDR) | RUN SEEDS 43 AND 44 |
| 1 | g >= T_1(UDR), g >= bar and LB > 0 (at one seed, LB is the account bootstrap's alone) | ADOPT (pending the SELECT check when RANK-B decides) |
| 1 | g >= T_1(UDR) but g < bar or LB <= 0 | RUN SEEDS 43 AND 44 (updated, the plan's row; reason printed) |
| 3 | g >= bar and LB_3 > 0 | ADOPT (pending the SELECT check when RANK-B decides) |
| 3 | otherwise | KEEP THE CONTROL (printed as unresolved if g > 0) |

At three seeds the bound is LB_3 = g - t_(k-1)(0.95) x sqrt(v_acct + s_d^2 / k), where k = 3, s_d is the sample SD of the three paired differences d_s (divisor k - 1), and v_acct is the account-bootstrap variance of g. The t multiplier is approximately 2.920 at 2 degrees of freedom. The bound uses this comparison's paired variability only: no baseline-spread pooling, maximum with the baseline spread, or sd_null subtraction. The account-bootstrap bound is printed too. No further seeds run after three.

**Step B (the month rule; on by default as the last fitting step, D4c).** h = UDR(month out) minus UDR(month in), which is minus the gain from keeping month.

| Seeds | Condition | Decision |
|---|---|---|
| 1 | h <= 0 | KEEP MONTH (updated: the one-fit rule first; h of zero keeps month) |
| 1 | h > 0 and T_1 is undefined because the UDR seed spread is zero | RUN SEEDS 43 AND 44 |
| 1 | 0 < h < T_1(UDR) | RUN SEEDS 43 AND 44 (one seed cannot show that removing month does not lose) |
| 1 | h >= T_1(UDR) | MONTH OUT if month out passes its check, else KEEP MONTH |
| 3 | mean h >= 0 and month out passes its check | MONTH OUT |
| 3 | otherwise | KEEP MONTH |

Month needs no bar: month out is a simplification and month is already built. Month out's check is the SELECT check.

**Step C, the cyclical calendar (off by default; updated).** Read like step B, against the kept fit: h = UDR(cyclical) minus UDR(kept). The decisions are CALENDAR CYCLICAL and KEEP THE CALENDAR, and CALENDAR CYCLICAL gets the SELECT check.

**Undefined inputs.** A nonfinite gain or a required T_1 that is undefined for any reason other than a zero UDR seed spread stops the read (exit 3). The zero-spread exception applies to adding, month out and cyclical calendar steps: at one seed, a positive gain runs seeds 43 and 44; a nonpositive gain keeps the control, month or current calendar respectively. The three-seed read then uses its own rule. The exception does not replace an invalid bootstrap term with zero.

**Pruning step P (blocked in this package, D4b).** The preflight refuses P on until the required three-seed compression step is built. The legacy reader path is read at seed 42 only, by this rule alone; more seeds are refused, and an undefined upper end of the interval stops the read (exit 3). The candidate is the pruned list, the control the unpruned kept fit, at seed 42. KEEP THE SMALLER LIST unless the unpruned fit beats it by at least the bar with LB > 0 (unpruned minus pruned); then KEEP THE UNPRUNED LIST. Keeping the smaller list is a change of inputs, so it gets the SELECT check.

**The SELECT check** (one logged read per decision that would change the kept inputs; plan section 4). For each of AP, AUROC, KS and UDR at 0.6%, the paired difference (candidate minus control, mean over n seeds) on SELECT June must be at least -k x sqrt(SE_acct^2 + 2 x s_m^2 / n). SE_acct is the account-bootstrap SD of that difference; s_m is the larger of that measure's SELECT June and RANK-B seed spreads when RANK-B decides, or SELECT June's spread alone when SELECT decides. k = 2.5 when RANK-B decides and 3.5 when SELECT decides. No sd_null term is subtracted. The check passes only if all four measures pass; a missing spread or SD fails its measure. These k values are operational development rules, not known coverage levels; their error rates under unequal candidate and control variances are not established. When RANK-B decides, a RANK-B read that meets every other condition prints "pending the SELECT check", and the SELECT read makes it final. When SELECT decides, the check is computed on the same read, and the screen says it is not independent.

**AP and the conflict line.** UDR is the main decision measure; AP remains the early-stopping monitor and one of the SELECT checks. The reader prints AP's difference, interval and informational T_1(AP), plus per-seed differences at three seeds. If a read would change the kept inputs and AP, or defined VDR, falls below -k x sqrt(SE_acct^2 + 2 x s_m^2 / n), the reader prints a conflict line; the decision stands. Here k = 2.5 is an operational development rule with the same uncertainty about error rates under unequal variances, not a known coverage level.

### 8.7 The downstream lift and its flag

`nf_read.py lift --step <step>` reads the downstream predictions of the step's kept fit and of its control on the same DS_SELECT rows. Lift(fit) = UDR(raw + embedding) minus UDR(raw), and the same for AP. The difference of lifts (step's kept fit minus control) gets the paired account bootstrap with the same draws for all arms, and its SD is the paired SE. **Flag** (the plan's rule, PLAN.md:104): if a group passes the fraud rule but its kept fit's lift is lower than the control's by more than one paired SE, the report says "the embedding's downstream lift fell by more than one paired SE" and lists both lifts. It is for the owner; it changes no decision. DS_SELECT is read once per kept fit.

### 8.8 Caveats the screen states

- With one seed, the bootstrap covers rows, not seed-to-seed variation. T_1 adds the measured seed term under the equal candidate/control variance assumption; it is an operational rule. A zero UDR spread leaves T_1 undefined and prevents one-seed adoption.
- A shared seed shares the file partition only when num_workers > 0. New input layers change the initial weights and later random draws, so pairing by seed does not remove seed noise. At three seeds the bound uses the observed paired differences themselves.
- Seed 42 was picked as best on Test 1. The control shares its seed and data order and may share some of its luck on June rows. The bias favours the control.
- If a kept checkpoint is used as control under a recorded change from the default refit policy, its earlier win on the deciding population favours it. Current defaults refit the kept recipe (R.0 and STEPS.yaml).
- RANK-B and SELECT are read once per decision but across decisions. They are development data, and adopted gains are somewhat optimistic. Only FINAL is a clean read.

### 8.9 The decision screen (one photograph)

Illustrative values, not results; this is a shortened screen. The threshold arithmetic uses `nf_read.py`'s
`t1_terms` helper with UDR sd_pair = 0.0041, sd_run = 0.0060, and AP sd_pair = 0.0062, sd_run = 0.0130,
both at 4 spread degrees of freedom. For this example, RANK-B supplies the larger measured spreads.

```
NEW FIELDS READ  step=A1  seeds=42  population=RANK-B June (8244-8259)  rules=<12>  layout=reorganized
rows 1,2xx,xxx  frauds 2,5xx  outsort 7,xxx (0.6% = floor(N x 3/500))  draws 2000 seed 20261102
candidate nf_a1 (base + 78)  control stage 1 retrain (base)  engine = _alert at 6 per mille: equal
metric     cand      control   diff      boot_sd   lo5       hi95
UDR@0.6    0.xxxx    0.xxxx    +0.0078   0.0041    +0.0011   +0.0145
AP         0.xxxx    0.xxxx    +0.0040   0.0062    -0.0062   +0.0142
VDR@0.6    0.xxxx    0.xxxx    +0.0051   0.0063    ...
FP/TP@0.6  x.xx      x.xx      -0.21     0.30      ...       (lower is better)
seed spread (pooled within kept and current-pod trios): sd_run(UDR) 0.0060 (4 df)
T1(UDR) = t 1.938 (nu 6.09) x sqrt(0.0041^2 + 2 x 0.0060^2) = 0.0183   bar +0.0100
  sd_pair: this read's bootstrap; sd_run: rank_b (4 df), the larger spread
  operational one-seed rule: equal candidate and control seed variance assumed
  no null subtraction; sd_null is information only; no fixed floor; T1(AP) 0.0392 (information)
LB at one seed: the account bootstrap's alone +0.0011 (T1 carries the seed term)
DECISION: RUN SEEDS 43 AND 44
reason: gain +0.0078 is above zero but below T1 0.0183
note: one seed; the bootstrap covers rows, not seed-to-seed variation
next: S.5 fit candidate seeds 43 and 44; controls: the base refits nf_control at seeds 43 and 44;
      then read at 3 seeds
```

The full numbers go to `C2/reads/<step>_<n>seed.json` and `.txt`.

## 9. Tests on synthetic data

(updated) The tests were built by lane and are named `test_new_fields_<lane>_*.py` and `test_field_screen_*.py`; the table below is the reviewed design's plan. `TEST_RESULTS.md` gives the counts of the delivered tests.

On the laptop the package is laid over a copy of the base tree (package 009 plus the reconstructed pod patches, pre-reorganization layout), so the resolver finds the fallback layout. Commands:
- `PYTHONPATH=src:. python3 -m pytest -q -p no:cacheprovider waqas/v2/tests waqas/tests tests/experiments/features/new_fields tests/experiments/features/field_screen`. The base suites must still give 1008 passed, and `python3 smoke_chosen.py` must still pass.
- On the pod: `CUDA_VISIBLE_DEVICES= PYTHONPATH=src:. $PY -m pytest -q -p no:cacheprovider tests/experiments/features/new_fields tests/experiments/features/field_screen` (the empty `CUDA_VISIBLE_DEVICES` keeps tests off the GPU while stage 0 runs).
- Tests that need `xgboost` skip on the laptop (it is not installed there) and run on the pod.

| File | What it proves |
|---|---|
| `test_new_fields_layout.py` | the base tree prints the fallback layout; a stub reorganized tree prints `reorganized`; a mixed tree stops and lists the names; a missing attribute is named |
| `test_new_fields_intake.py` | footer-only schema read, and the printed column count; mapping suggestions are never applied; recipe grammar parses and refuses unknown forms; name clashes; status rules from `STATUS_RULES.csv` (the seven stop, rank 52 stays, name-scan fields wait); Sumegha's yes rows stop; outcome sources and spanning group keys stop with their reasons; `adopt` is the only way to CONFIRMED; builders refuse an UNCONFIRMED map; the definitions file holds every column of 2.7 |
| `test_new_fields_recipes.py` | every recipe against a hand count on a small account history; whole-second keys (same-second siblings never see each other; a row's value does not change when a sibling is added); windows censored before the extract start are missing, not zero; missing raw values never count; future invariance (rows after a cutoff changed or deleted, earlier values unchanged); label permutation changes nothing; `code(c)` maps to the raw code |
| `test_new_fields_checks.py` | planted leakage: a date set after the transaction on fraud rows stops (`date_after_txn`); a field filled only on frauds stops (`fill_only_fraud`); a field filled from the first fraud on stops (`fill_after_fraud`); a noisy copy of the label stops (`too_good`); a planted look-ahead recipe stops (`not_strictly_earlier`); a clean field passes; a change at the event only flags; missing by month and by label match hand counts; the type traps (an int column with nulls in one fit file, text in a number, a date read as a number) stop; vocabulary and unknown-share rules; a 90-day window stops `empty_june` on evaluation-like files; restart from partial counts; the screen fits 40 lines |
| `test_new_fields_duplicates.py` | a renamed copy of a base input stops and is kept once as the base input; a one-to-one recode of a base code stops; an `le1`-style integer recode of a V22B code stops in the f15298 group and is kept once as the V22B field; a recode of the label stops as `label_copy`; an affine copy of a number stops; a near duplicate only flags; a field equal to the time gap stops; clusters at the 0.8 threshold match a hand result |
| `test_new_fields_month.py` | a planted month code and a planted absolute timestamp are flagged; a days-before field unrelated to month is not; NMI and Cramer's V match a hand computation; PSI flags a planted June shift; the "repetitive" statement needs both the overlap level and the screen's time-split result; nothing is removed |
| `test_new_fields_enriched.py` | copies hold every original column with equal hashes and the same row order; a changed original value fails the identity proof; an existing prefix is refused; the trainer's builder reads a copy and gives the same base arrays as the original |
| `test_new_fields_artifact.py` | version 1 built with the unchanged builder on synthetic parquet; the extended version's base files are byte-identical (SHA-256) to version 1; new files equal the scratch files; the base payload digest equals the digest the unchanged input contract stores for a dataset over version 1; refusals (version 1 as target, an existing version, scratch `fit_files` that differ, a name already in version 1); month-out lists equal month-in minus one line; base fields encode to identical arrays; a string artifact version loads through the unchanged trainer path |
| `test_new_fields_source_hash.py` | every installed file is under `NF`, `FS`, `TNF` or `TFS`; none is `__init__.py`; none replaces an existing file; under the 5.4 rule (folder `fraud`, excluded `tests/` and `fraud/experiments/`, plus `pyproject.toml` and `requirements.txt`) the source hash of a temporary tree is the same before and after the install; a stub reorganized tree's own `source_sha256()` agrees. (The base tree hashes `fraud/experiments/`, so the pod guard is the proof on the pod.) |
| `test_new_fields_configs.py` | generated configs differ from the base config only in the allowed keys; any other difference is refused; the learning-rate placeholder is written and a blank source is refused; the micro-batch pair keeps targets per update |
| `test_new_fields_metrics.py` | UDR, VDR and FPR equal `modules/analysis` `outsort_metrics` (loaded by path) at 0.6%, 1% and 5%, with tied scores, tied boundary rows and integer weights; UDR and VDR equal the base `_alert` at 6 per mille; AP equals scikit-learn with and without `sample_weight`; AUROC and KS match |
| `test_new_fields_bootstrap.py` | the draws are the same for every fit; reproducible from the seed; streaming draws equal a full matrix on a small case; every row of an account gets the account's count |
| `test_new_fields_reader.py` | planted effects at one seed: a large gain gives ADOPT; a small positive gain below T_1 gives RUN SEEDS 43 AND 44; a gain above T_1 but below the bar gives RUN SEEDS 43 AND 44 (updated); a loss gives KEEP THE CONTROL. At three seeds: a steady gain gives ADOPT; a mixed one gives KEEP THE CONTROL (unresolved). Month rule: KEEP MONTH, MONTH OUT, RUN SEEDS, and a failed SELECT check gives KEEP MONTH. Prune rule both ways. Refusals: different row sets, a receipt hash mismatch, a wrong file range, a changed settings file after the first read, a missing spread file. The one-seed note is on the screen; the screen fits 40 lines |
| `test_new_fields_lift.py` | lift and its paired SE on planted downstream predictions; the flag fires when a planted drop exceeds one SE and not otherwise |
| `test_new_fields_importance.py` | on the synthetic world with the real scorer: the identity wrapper gives bitwise the scorer's own scores; a permuted value is the same for a row as target and as history; the subsample keeps whole accounts; a planted strong feature ranks first and a pure-noise feature's interval covers zero; a cluster is permuted together; the cost estimate follows its formula and the limit refuses; no file changes |
| `test_new_fields_attention.py` | recomputed CLS attention equals `need_weights=True` within 1e-6; the model output is bitwise unchanged with the hooks; token-to-feature mapping by a perturbation test (changing one input column changes only its own token); target slots only |
| `test_new_fields_rank_check.py` | passes with no role and no exposure; fails on a role, an overlapping exposure record, or files with no June targets |
| `test_new_fields_queue.py` | with a fake trainer, scorer and `nvidia-smi` on PATH: a busy GPU refuses with exit 4; an existing complete folder is skipped; an incomplete one stops; a saved decision is re-read and never stepped over; logs are appended; each rc is logged; a failed fit stops with exit 1; the chain follows each decision (A1 kept the control, so A2 builds on base); off steps are skipped; `one_step_all` runs one step; a learning rate other than the control's adds P1; invalid kept controls add the refits |
| `test_new_fields_timing.py` | the wrapper limits steps and writes the timing file on CPU; every hashed file's bytes are unchanged; the memory rule halves and doubles as declared |
| `test_new_fields_smoke.py` | end to end on CPU on a small synthetic world: intake, checks, copies, extended artifact, a two-epoch control and candidate, scoring, a read that prints a decision, an importance run with two units |
| `test_field_screen_*.py` | the dry run completes in one command; the map drives the families and nothing is hard-coded; `PASS_RULE` and `FINAL_RULE` texts equal the old screen's; the old screen's tests, ported, pass on the same synthetic data; the month on-top arms run on folds and on the time split; SHAP per-feature sums equal the sum over rows of absolute contributions (xgboost only); the cost guard refuses above `--max-hours` |

## 10. On the pod

### 10.1 What Copilot does, step by step

Copilot adapts paths and commands only. If something cannot be found, or two candidates exist, it stops and asks the owner.

**Part A, CPU, may run now while stage 0 holds the GPU** (with `CUDA_VISIBLE_DEVICES=` and `nice -n 19`; heavy S3 reads may slow stage 0's data loading a little):
1. **Before installing.** Run `$PY -c "import sys; sys.path[:0]=['.','src']; from fraud.scripts.train_sequential_hier import source_sha256; print(source_sha256())"` and note the hash. Check that `fraud/source_files.py` lists `"fraud/experiments/"` among the excluded prefixes. If not, stop: REORG 5.4 was not applied, and installing would change the hash. Do not edit that file.
2. **Install.** Unzip the package into a new folder outside the project, then copy only `NF`, `FS`, `TNF` and `TFS` into the project. No `__init__.py`, unless pytest reports an import mismatch, and then only in a test folder (REORG 4.11 rule 7).
3. **Guard.** `$PY NF/nf_guard.py --before <hash>`. It must print `unchanged`, and equal stage 0's recorded identity. If not, remove the copied folders and stop.
4. **Tests.** The pod command of section 9.
5. **Intake.** `schema`; write `FIELD_MAP.csv` from the owner's list; `check-map` (2.3).
6. **CPU checks.** `nf_field_checks.py`.
7. **CPU screen.** `fsc_run.py` (3.6).
8. **Rank check and the SELECT spread.** `nf_rank_check.py`, then `nf_read.py spread --population select_june`.
9. **After the owner confirms the list.** `nf_intake.py adopt`, the checks again if the list changed, `nf_intake.py definitions`, `nf_build_enriched.py`, `nf_build_artifact.py`, `nf_check_artifact.py`.

**Part B, GPU, only after stage 0, its resumes and stage 1's GPU work have finished:**
10. **Fill `UPSTREAM.yaml`** from the stage 0 and stage 1 reports. Set `learning_rate` and `learning_rate_source` in `SETTINGS.yaml`. Set the steps file as the owner chooses. Run `nf_make_configs.py`.
11. **Timing** (GPU, short) for each step's width. Apply the memory rule if it fires.
12. **Start.** The owner runs `bash NF/nf_start.sh`, or tells Copilot to. Copilot does not start it on its own.
13. **Each morning.** `tail -n 40 checkpoints/new_fields/queue.log` and `$PY NF/nf_report.py`. After each read: `cat checkpoints/new_fields/reads/<step>_<n>seed.txt`.

### 10.2 What the owner photographs

1. The guard (`unchanged`, with the hashes) and the pytest line.
2. The `check-map` screen.
3. The field checks summary.
4. The CPU screen's summary.
5. The rank check screen and the SELECT spread line.
6. After adoption: the enriched build's identity summary and the artifact check (`base fields byte-identical: 23/23`, the digests equal).
7. The `nf_make_configs.py` diff screen and the timing screen.
8. Each morning: the queue log tail and the morning report.
9. Each read's decision screen, the SELECT checks, the lift reads, the importance summary, the Test 1 report and `RESULT.txt`.

### 10.3 What stage 2 needs from stage 0 and stage 1

- **From stage 0:** the chosen model's best learning rate (1e-4, 3e-4 or 1e-3), with its report's name and date. If it is not 3e-4, the control is refit at seed 42 (P1), and kept seeds 43 and 44 are not valid controls. Also stage 0's run folders, for the guard.
- **From stage 1:**
  - the seed-42 retrain: its folder, complete (`finished` or `budget_reached`), with `best.ckpt`, its learning rate, and its source hash;
  - the reproduction checks: the rescore is exact (or the gap explained), the route test passed, the same-batch test passed;
  - timing: C_c and C_v at the base width, S, and its width-timing tool if it is built;
  - its validation AP, which replaces 0.137146 in the `too_good` rule.
- **If stage 1 has not run** (its build was paused on 2 November): stage 2 fits its own control at seed 42 (P1), has no proof that the reorganized code reproduces the old one, and so treats the kept seed 43 and 44 checkpoints as not valid controls and fits `nf_control` seeds 43 and 44 when a confirmation runs. Its timing step then measures the base width itself.

## 11. Open questions for the owner

1. **The list.** Please send the final list as a file: the V22B included features minus Sumegha's exclusions, plus 15298's features, built from the 227 raw columns. We need, per feature, the columns of 2.1: group (V22B, 15298 or both), raw or engineered, the recipe, the source columns, Sumegha's flag with the reason, and feasibility. Nothing is fit until you confirm it. Please also confirm that a feature in both lists counts as V22B, and that dates go in as days before the transaction.
2. **The month step.** Month stays in, and step B is off. After you see the month report (3.2), do you want step B on? If a new field repeats month, would you remove that field or month?
3. **Main measure and bar.** Please confirm UDR at the 0.6% outsort as the main measure, the bar of +1 point UDR for each group, and whether T_1(UDR) should use a floor for the seed spread (it has only 2 degrees of freedom).
4. **Thresholds.** Please approve the stop, wait and flag thresholds of 3.3, the month levels, and the cluster threshold of 0.8, before the first run.
5. **Controls between steps.** (Answered: the previous step's kept fit as it is, by default; the refit is your option, `refit_kept_control: true`.) You asked that each step be compared with the previous step's kept fit. The plan's rule refits that fit first, because its luck on RANK-B makes the next gain look smaller. Keep your way (default), or refit (10 epochs more per step)?
6. **Kept seeds 43 and 44 as controls.** (The package refits them by default, the plan's recommendation; reuse is your option, `refit_base_controls_43_44: false`.) Reuse them when stage 1 passes (their bias, toward base inputs, is written down), or refit (the plan recommends the refit)?
7. **Features we cannot build faithfully** (2.2): merchant claim rates and case dispositions (they use outcomes), merchant-name indexes (all customers of a merchant), card or customer aggregates (no key, or keys spanning files), other systems' events and packed strings. Confirm they stay out, or send their definitions, the key columns, or the dates when outcomes became known.
8. **The bank's decisions on the same transaction** (FALCONDECLINE_INDICATOR, PREDECLINE_INDICATOR, PROCESSOR_REASON): in as the previous transaction's value only, as on 26 October?
9. **External scores** (`external_1_scr`, already an input, and VAA): available at decision time in production? This is for you and Sumegha; the tools only flag them.
10. **Group A3** (the 16 features built on 26 October): on or off? The distance features also need a postal-code table and the data owner's word on what the merchant postal code means.
11. **Importance budget.** (Default: once, on the final kept fit; every step is your option, `importance: every_step`.) Account share (default 25%), repeats (default 1), maximum GPU hours (default 24), and whether to run it on every step or only on the final fit. For pruning: is "the interval at or below zero" meant as "its lower end at or below zero" (our reading, which drops features not shown to help), or "the whole interval at or below zero" (drops only harmful ones)?
12. **High-cardinality codes** (the two postal codes now enter as TFM's geohash, section R.5) (merchant postal code, cardholder postal code, token requestor, device IP address): our builder has no hashing or cap. Keep them as raw categories if they pass the size rules, or leave them out?
13. **Downstream use 2** waits for 15298 scores on DS_TRAIN and DS_SELECT. Is the Test 2 (BENCH) path ready on the pod?
14. **Stage 1.** The control fit and the reproduction checks come from stage 1. If it stays paused, stage 2 fits its own control and refits the seed 43 and 44 controls when needed (10.3). Is that acceptable?
