"""Regression tests for the adversarial check of the screen lane (synthetic data only, no network).

Each test reproduces one finding's evidence and passes on the fixed screen. One screen run (the `screen`
fixture) is shared: a world with the field checks' real clusters.csv, a stored look-ahead that claims an
honest recipe, an honest stored column, a map row named like the label, a map row missing from the field
status file, June files, container limits read through an injected reader, and no --temporal-split flag."""

import argparse
import json
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from field_screen_helpers import NF, load, load_patched

FAST = json.dumps({"n_estimators": 10, "max_depth": 2})
GIB = 1 << 30
# The field checks write clusters.csv with exactly these columns (nf_field_checks.py, write of clusters.csv).
CHECKS_CLUSTERS_HEADER = ["cluster_id", "member", "member_kind", "size", "max_link", "result"]
# The field checks' field_status.csv header.
CHECKS_STATUS_HEADER = ["field", "group", "kind", "result", "reasons", "cluster_id", "kept_once_as"]


def _run_mod():
    run = load("fsc_run")
    U = run.modules()["U"]
    if not U.xgboost_available():
        U.use_sklearn_fallback()
    return run


def _world(folder, n_accounts=150, june_accounts=60):
    syn = load("fsc_synth")
    com = load("nf_common", NF / "nf_common.py")
    return syn.world(folder, n_accounts=n_accounts, june_accounts=june_accounts,
                     field_map_columns=com.FIELD_MAP_COLUMNS)


def _add_rows(w, rows, status_rows):
    m = pd.read_csv(w["map"], dtype=str, keep_default_na=False)
    new = []
    for r in rows:
        d = {c: "" for c in m.columns}
        d.update({"definition_version": "1", "excluded_by_sumegha": "no", "feasible_in_production": "yes",
                  "list_status": "UNCONFIRMED", **r})
        new.append(d)
    pd.concat([m, pd.DataFrame(new, columns=m.columns)], ignore_index=True).to_csv(w["map"], index=False)
    st = pd.read_csv(w["status"], dtype=str, keep_default_na=False)
    st = pd.concat([st, pd.DataFrame(status_rows)], ignore_index=True).fillna("")
    st.to_csv(w["status"], index=False)


def _store(files, name, recipe, extract_start):
    """Write a column built by the synthetic builder into each file, file by file (as enriched copies are)."""
    syn = load("fsc_synth")
    for f in files:
        d = pd.read_parquet(f)
        d[name] = syn.synth_builder(d, recipe, extract_start).to_numpy()
        d.to_parquet(f)


def fake_reader(files):
    """A reader for /proc and the cgroup files: {path: text}; a missing path reads as None."""
    return lambda p: files.get(str(p))


def v2_limits(mem_avail_gib=100, limit_gib=40, current_gib=30, inactive_gib=2, cpu="400000 100000"):
    d = "/sys/fs/cgroup/kubepods/pod1/c1"
    return {"/proc/meminfo": f"MemTotal: 999999999 kB\nMemAvailable: {int(mem_avail_gib * 1024 * 1024)} kB\n",
            "/proc/self/cgroup": "0::/kubepods/pod1/c1\n",
            f"{d}/memory.max": f"{int(limit_gib * GIB)}\n", f"{d}/memory.current": f"{int(current_gib * GIB)}\n",
            f"{d}/memory.stat": f"anon 1\ninactive_file {int(inactive_gib * GIB)}\n", f"{d}/cpu.max": cpu + "\n"}


@pytest.fixture(scope="module")
def screen(tmp_path_factory):
    tmp = tmp_path_factory.mktemp("fix")
    w = _world(tmp / "w")
    _store(w["files"], "syn_next_amt", "lookahead(transaction_amt)", w["extract_start"])  # the next row's amount
    _store(w["june"], "syn_next_amt", "lookahead(transaction_amt)", w["june_extract_start"])
    _store(w["files"], "syn_cnt_24h", "count(24h)", w["extract_start"])  # honest: equals its recipe
    _store(w["june"], "syn_cnt_24h", "count(24h)", w["june_extract_start"])
    _add_rows(w, [
        {"name": "syn_next_amt", "group": "a3", "kind": "engineered", "recipe": "prev(transaction_amt)",
         "source_columns": "transaction_amt", "model_type": "continuous"},
        {"name": "frd_tag", "group": "v22b", "kind": "raw", "recipe": "raw", "source_columns": "frd_tag",
         "model_type": "continuous"},
        {"name": "syn_absent_num", "group": "v22b", "kind": "raw", "recipe": "raw",
         "source_columns": "syn_useless_num", "model_type": "continuous", "check_result": "PASS"}],
        [{"field": "syn_next_amt", "result": "PASS", "reasons": "synthetic"},
         {"field": "frd_tag", "result": "PASS", "reasons": "synthetic"}])
    clusters = tmp / "clusters.csv"
    pd.DataFrame([["C001", "syn_useful_code", "new", 2, 0.91, "PASS"], ["C001", "syn_profile_num", "new", 2, 0.91, "FLAG"],
                  ["C002", "syn_prev_amt", "new", 2, 0.88, "PASS"], ["C002", "transaction_amt", "base", 2, 0.88, ""],
                  ["B001", "external_1_scr", "base", 2, 0.95, ""], ["B001", "total_available_balance_amt", "base", 2, 0.95, ""]],
                 columns=CHECKS_CLUSTERS_HEADER).to_csv(clusters, index=False)
    out = tmp / "o"
    run = _run_mod()
    args = ["--map", w["map"], "--status", w["status"], "--clusters", str(clusters), "--files", *w["files"],
            "--extract-start", w["extract_start"], "--drift-files", *w["june"],
            "--drift-extract-start", w["june_extract_start"], "--k", "3", "--n-boot", "20", "--extra-seeds", "43",
            "--params-json", FAST, "--min-free-gb", "1", "--no-label-shuffle", "--out", str(out)]
    rc = run.main(args, recipe_fn=load("fsc_synth").synth_builder,
                  read_limits=fake_reader(v2_limits(mem_avail_gib=100, limit_gib=40, current_gib=10, cpu="200000 100000")))
    assert rc == 0
    return {"w": w, "tmp": tmp, "out": out, "res": json.loads((out / "screen.json").read_text()),
            "fr": pd.read_csv(out / "feature_rank.csv", keep_default_na=False), "summary": (out / "summary.txt").read_text()}


# ---------------------------------------------------------------- finding 1 (blocking): the checks' clusters.csv

def test_clusters_csv_with_the_checks_header_is_read(screen):
    src = NF / "nf_field_checks.py"
    if src.exists():  # the header the field checks write is the one this test feeds
        assert 'columns=["cluster_id", "member", "member_kind", "size", "max_link", "result"]' in src.read_text()
    res = screen["res"]
    assert res["clusters_source"] == "clusters.csv"
    cl = pd.read_csv(screen["out"] / "cluster_rank.csv").set_index("cluster_id")
    assert set(cl.index) == {"C001", "C002", "B001"}  # new, mixed new and base, and base-only clusters
    assert set(cl.loc["C002", "members"].split(";")) == {"syn_prev_amt", "transaction_amt"}
    fr = screen["fr"].set_index("feature")
    assert fr.loc["syn_useful_code", "cluster_id"] == "C001" and fr.loc["transaction_amt", "cluster_id"] == "C002"


def test_a_bad_clusters_file_is_refused_before_any_read(tmp_path):
    run = _run_mod()
    w = _world(tmp_path / "w", n_accounts=40, june_accounts=10)
    bad = tmp_path / "clusters.csv"
    pd.DataFrame({"cluster_id": ["C1"], "unit": ["x"]}).to_csv(bad, index=False)
    with pytest.raises(ValueError, match="member"):
        run.read_clusters(bad)
    out = tmp_path / "o"
    rc = run.main(["--map", w["map"], "--status", w["status"], "--clusters", str(bad), "--files", *w["files"],
                   "--min-free-gb", "0", "--out", str(out)], recipe_fn=load("fsc_synth").synth_builder)
    assert rc == 2 and not (out / "memory.json").exists() and not (out / "screen.json").exists()
    assert run.main(["--map", w["map"], "--status", w["status"], "--clusters", str(tmp_path / "none.csv"),
                     "--files", *w["files"], "--out", str(out)]) == 2


# ---------------------------------------------------------------- finding 2: June history parity, within=all

def _sparse(rng, n_acc, start, days, first):
    rows = []
    for a in range(n_acc):
        n = rng.poisson(rng.uniform(0.02, 0.08) * days)
        ts = np.sort(rng.uniform(0, days * 86400, n)).round()
        rows.append(pd.DataFrame({"Nmap_account_reference_xid": f"P{first + a:06d}",
                                  "transaction_dttm": pd.Timestamp(start) + pd.to_timedelta(ts, unit="s")}))
    df = pd.concat(rows, ignore_index=True)
    df["fi_transaction_id"] = [f"X{first}{i:08d}" for i in range(len(df))]
    df["transaction_amt"] = 1.0
    return df


def since_all(df, recipe, extract_start, model_type=None):
    """since_last(days; within=all) as the recipe module builds it: days since the account's previous row,
    any row the frame holds counts (no lookback limit, so nothing before the extract start is censored)."""
    t = pd.to_datetime(df["transaction_dttm"])
    d = pd.DataFrame({"a": df["Nmap_account_reference_xid"].to_numpy(), "t": t.to_numpy()}, index=df.index)
    d = d.sort_values(["a", "t"], kind="mergesort")
    prev = d.groupby("a")["t"].shift(1)
    return ((d["t"] - prev).dt.total_seconds() / 86400).reindex(df.index)


@pytest.mark.parametrize("engine", ["stand-in", "nf_recipes"])
def test_june_reference_starts_where_the_june_files_start(engine):
    run = _run_mod()
    S = run.modules()["S"]
    rng = np.random.default_rng(5)
    df = _sparse(rng, 3000, "2024-10-01", 212, 0)  # training to 30 April 2025
    ev = _sparse(rng, 3000, "2025-05-01", 61, 10**5)  # June files from 1 May 2025
    recipe = "since_last(days; within=all)"
    if engine == "nf_recipes":
        fn, label = run.recipe_module()
        if fn is None:
            pytest.skip("nf_recipes.py not installed in this tree")
    else:
        fn, label = since_all, "stand-in"
    row = {"name": "eng_since_all", "group": "a3", "kind": "engineered", "recipe": recipe,
           "source_columns": "transaction_dttm", "model_type": "continuous"}
    b = run.Builder(None, fn, label)
    new = {"eng_since_all": run._typed(fn(df, recipe, "2024-10-01", "continuous"), "continuous").to_numpy()}
    a = argparse.Namespace(drift_month="2025-06", drift_extract_start="2025-05-01", drift_threshold=0.25,
                           drift_min_rows=100)
    res = run.june_drift(a, df, ev, [row], new, {"eng_since_all": {"model_type": "continuous"}}, b, S)
    col = res["columns"]["eng_since_all"]
    assert res["reference_month"] == "2025-04" and res["reference_extract_start"] == "2025-03-01"
    assert col["reference"].startswith("2025-04 rebuilt from 2025-03-01")
    assert col["psi"] < 0.1 and not res["flagged"]
    # the finding's evidence: the old reference passed the start only as an argument on the whole training frame,
    # so April saw about seven months of history while June sees at most two; that gives a false June flag
    t = pd.to_datetime(df["transaction_dttm"])
    old = pd.to_numeric(fn(df, recipe, "2025-03-01", "continuous"), errors="coerce").to_numpy()[
        (t.dt.to_period("M") == pd.Period("2025-04", "M")).to_numpy()]
    june = (pd.to_datetime(ev["transaction_dttm"]).dt.to_period("M") == pd.Period("2025-06", "M")).to_numpy()
    jv = pd.to_numeric(fn(ev, recipe, "2025-05-01", "continuous"), errors="coerce").to_numpy()[june]
    assert S.psi(old, jv) > 0.25


# ---------------------------------------------------------------- finding 3: a stored look-ahead claiming an honest recipe

def test_a_stored_lookahead_claiming_an_honest_recipe_is_not_shown_ok(screen):
    res, fr = screen["res"], screen["fr"].set_index("feature")
    fi = res["future_invariance"]
    assert fi["ok"] is not True and fi["stored_differs"]["syn_next_amt"] > 0  # False here: the planted look-ahead fails
    assert "syn_cnt_24h" not in fi["stored_differs"]  # an honest stored column equals its recipe
    assert fr.loc["syn_next_amt", "future_invariance"].startswith("stored differs from recipe (")
    assert "stored differs from recipe" in fr.loc["syn_next_amt", "how_built"]
    assert "equals its recipe" in fr.loc["syn_cnt_24h", "how_built"]
    assert "a3=?" in fr.loc["syn_next_amt", "family_leaky"] and res["families"]["a3"]["future_invariance_not_run"]
    assert "stored_differs_from_recipe" in fr.loc["syn_next_amt", "note"]
    assert "stored column differs from its recipe: syn_next_amt" in screen["summary"]
    d = res["drift"]  # June: the recipe is rebuilt on both sides, and the stored June column is compared too
    assert d["columns"]["syn_next_amt"]["reference"].startswith(d["reference_month"] + " rebuilt from")
    assert d["june_stored_differs"]["syn_next_amt"] > 0 and "syn_cnt_24h" not in d["june_stored_differs"]


# ---------------------------------------------------------------- finding 4: the contract with the checks summary

def _checks_folder(tmp, names):
    folder = Path(tmp) / "checks"
    folder.mkdir(parents=True, exist_ok=True)
    pd.DataFrame([{"field": n, "group": "v22b", "kind": "raw", "result": "PASS", "reasons": "", "cluster_id": "",
                   "kept_once_as": ""} for n in names], columns=CHECKS_STATUS_HEADER).to_csv(
        folder / "field_status.csv", index=False)
    return folder


def _summaries(tmp):
    cur = load("nf_feature_summary_current", NF / "nf_feature_summary.py")
    pat = load_patched("nf_feature_summary_patched", NF / "nf_feature_summary.py", "nf_feature_summary.diff",
                       "RANK_CONTRACT", tmp)
    return cur, pat


def test_feature_rank_carries_the_agreed_columns_and_the_summary_reads_them(screen, tmp_path):
    if not (NF / "nf_feature_summary.py").exists():
        pytest.skip("the checks lane's summary is not installed in this tree")
    run = load("fsc_run")
    fr = screen["fr"]
    agreed = ["feature", "shap_mean_abs", "shap_rank_new", "perm_ap_drop_mean", "perm_rank_new", "note"]
    assert set(agreed) <= set(fr.columns) and list(fr.columns) == run.RANK_COLUMNS
    new = [n for n in screen["res"]["new_fields"]]
    checks = _checks_folder(tmp_path, new)
    cur, pat = _summaries(tmp_path)
    rank = screen["out"] / "feature_rank.csv"
    ours = fr.set_index("feature")
    for mod in (cur, pat):  # both read the ranks among new fields, not among all arm columns
        df = mod.build(checks, rank, None).set_index("feature")
        for n in new:
            want = pd.to_numeric(ours.loc[n, "shap_rank_new"], errors="coerce")
            got = pd.to_numeric(df.loc[n, "shap_rank"], errors="coerce")
            assert (np.isnan(want) and np.isnan(got)) or want == got, n
    df = pat.build(checks, rank, None).set_index("feature")
    noted = [n for n in new if str(ours.loc[n, "note"]).strip()]
    clean = [n for n in new if not str(ours.loc[n, "note"]).strip()]
    assert {"syn_next_amt", "syn_lookahead_amt"} <= set(noted) and clean
    for n in noted:  # any screen flag turns the draft into review, with the screen's note as the reason
        assert df.loc[n, "draft_verdict"] == "review", n
        assert "screen: " + str(ours.loc[n, "note"]).strip() in df.loc[n, "draft_reason"]
        assert "screen:" + str(ours.loc[n, "note"]).strip() in df.loc[n, "evidence"]
    for n in clean:
        assert df.loc[n, "draft_verdict"] == "keep", n
    prop = pat.proposals(df.reset_index(), "2026-11-02").set_index("name")
    assert (prop.loc[noted, "verdict"] == "unresolved").all()


def test_every_kind_of_screen_flag_becomes_a_review_draft(tmp_path):
    if not (NF / "nf_feature_summary.py").exists():
        pytest.skip("the checks lane's summary is not installed in this tree")
    run = load("fsc_run")
    notes = {"f_fi": "future_invariance_failed", "f_stored": "stored_differs_from_recipe rows=12",
             "f_notrun": "future_invariance_not_run", "f_good": "too_good_alone ap=0.912",
             "f_shuffle": "family_leaky:f15298 label_shuffle", "f_drift": "drift_june psi=2.01",
             "f_june": "june_stored_differs_from_recipe rows=3", "f_two": "too_good_alone ap=0.9; drift_june psi=0.3",
             "f_clean": ""}
    rows = []
    for i, (n, note) in enumerate(notes.items()):
        rows.append({**{c: "" for c in run.RANK_COLUMNS}, "feature": n, "in_arm": "yes", "note": note,
                     "shap_mean_abs": 1.0 / (i + 1), "shap_rank_new": i + 1, "shap_rank": i + 24,
                     "perm_ap_drop_mean": 0.01, "perm_rank_new": i + 1, "perm_rank": i + 24})
    rank = tmp_path / "feature_rank.csv"
    pd.DataFrame(rows, columns=run.RANK_COLUMNS).to_csv(rank, index=False)
    checks = _checks_folder(tmp_path, list(notes))
    _, pat = _summaries(tmp_path)
    df = pat.build(checks, rank, None).set_index("feature")
    for n, note in notes.items():
        assert df.loc[n, "draft_verdict"] == ("review" if note else "keep"), n
        assert df.loc[n, "shap_rank"] == list(notes).index(n) + 1  # shap_rank_new, never the all-column rank
    # the screen writes exactly these tokens: every one of them is a reason to review
    src = (Path(run.__file__)).read_text()
    for token in ("future_invariance_failed", "stored_differs_from_recipe", "future_invariance_not_run",
                  "too_good_alone", "label_shuffle", "drift_june", "june_stored_differs_from_recipe"):
        assert token in src


def test_the_summary_patch_applies_to_the_checks_file_and_keeps_its_meaning_reader(tmp_path):
    if not (NF / "nf_feature_summary.py").exists():
        pytest.skip("the checks lane's summary is not installed in this tree")
    _, pat = _summaries(tmp_path)
    p = tmp_path / "rank_by_meaning.csv"  # a ranking file without the agreed columns is still read by meaning
    pd.DataFrame([{"feature": "a", "shap_mean_abs": 0.5, "perm_ap_drop": 0.01, "kind": "feature"},
                  {"feature": "b", "shap_mean_abs": 0.9, "perm_ap_drop": 0.02, "kind": "feature"},
                  {"feature": "C001", "shap_mean_abs": 0.3, "perm_ap_drop": 0.01, "kind": "cluster"}]).to_csv(p, index=False)
    r = pat.read_rank(p).set_index("feature")
    assert r.loc["b", "shap_rank"] == 1 and "C001" not in r.index and (r["screen_note"] == "").all()
    assert pat.draft_verdict("PASS", [], "", "") == ("keep", "no stop, wait or review flag")
    assert pat.draft_verdict("STOP", [("STOP", "date_after_txn", "")], "", "drift_june psi=1.0")[0] == "drop"
    assert pat.draft_verdict("PASS", [], "", float("nan"))[0] == "keep"


# ---------------------------------------------------------------- finding 5: a drift month with no rows

def test_a_drift_month_with_no_rows_flags_nothing(tmp_path):
    run = _run_mod()
    w = _world(tmp_path / "w", n_accounts=60, june_accounts=20)
    out = tmp_path / "o"
    rc = run.main(["--map", w["map"], "--status", w["status"], "--files", *w["files"], "--drift-files", *w["june"],
                   "--drift-extract-start", w["june_extract_start"], "--drift-month", "2025-07",
                   "--min-free-gb", "0", "--out", str(out)], recipe_fn=load("fsc_synth").synth_builder)
    assert rc == 2
    d = json.loads((out / "drift.json").read_text())
    assert d["june_rows"] == 0 and d["not_run"].startswith("no rows in --drift-month 2025-07")
    assert not (out / "screen.json").exists() and not (out / "feature_rank.csv").exists()
    # inside the screen too: below the minimum, nothing is compared and nothing is flagged (PSI was about 11.5)
    S = run.modules()["S"]
    df = pd.read_parquet(w["files"][0])
    ev = pd.read_parquet(w["june"][0])
    row = {"name": "syn_useless_num", "recipe": "raw", "source_columns": "syn_useless_num", "model_type": "continuous"}
    a = argparse.Namespace(drift_month="2025-07", drift_extract_start="2025-05-01", drift_threshold=0.25,
                           drift_min_rows=100)
    new = {"syn_useless_num": df["syn_useless_num"].to_numpy()}
    res = run.june_drift(a, df, ev, [row], new, {"syn_useless_num": {"model_type": "continuous"}},
                         run.Builder(None), S)
    assert res["june_rows"] == 0 and res["flagged"] == [] and res["columns"] == {} and "no rows" in res["not_run"]
    a.drift_month, a.drift_min_rows = "2025-06", 10**7
    res = run.june_drift(a, df, ev, [row], new, {"syn_useless_num": {"model_type": "continuous"}},
                         run.Builder(None), S)
    assert res["june_rows"] > 0 and res["flagged"] == [] and res["not_run"].startswith("only ")


# ---------------------------------------------------------------- finding 6: container (cgroup) limits

def test_cgroup_v2_limits_through_an_injectable_reader():
    run = load("fsc_run")
    lim = run.resource_limits(read=fake_reader(v2_limits()), affinity=64)
    assert lim["cgroup"] == "v2" and lim["host_available_gib"] == 100.0
    assert lim["free_gib"] == 12.0  # 40 GiB limit - (30 GiB used - 2 GiB inactive file cache)
    assert lim["cpus"] == 4 and lim["cpus_affinity"] == 64 and lim["cpu_quota"] == 4.0
    files = v2_limits()  # a parent cgroup with a smaller headroom wins
    files.update({"/sys/fs/cgroup/kubepods/pod1/memory.max": str(20 * GIB),
                  "/sys/fs/cgroup/kubepods/pod1/memory.current": str(17 * GIB)})
    assert run.resource_limits(read=fake_reader(files), affinity=64)["free_gib"] == 3.0
    files = v2_limits(cpu="max 100000")  # no CPU quota: the affinity count
    files["/sys/fs/cgroup/kubepods/pod1/c1/memory.max"] = "max\n"  # no memory limit: the host figure
    lim = run.resource_limits(read=fake_reader(files), affinity=6)
    assert lim["free_gib"] == 100.0 and lim["cgroup"] == "none" and lim["cpus"] == 6


def test_cgroup_v1_limits_and_the_gib_unit():
    run = load("fsc_run")
    files = {"/proc/meminfo": f"MemAvailable: {32 * 1024 * 1024} kB\n",
             "/proc/self/cgroup": "12:memory:/docker/abc\n11:cpu,cpuacct:/docker/abc\n",
             "/sys/fs/cgroup/memory/docker/abc/memory.limit_in_bytes": str(16 * GIB),
             "/sys/fs/cgroup/memory/docker/abc/memory.usage_in_bytes": str(10 * GIB),
             "/sys/fs/cgroup/memory/docker/abc/memory.stat": f"cache 5\ntotal_inactive_file {GIB}\n",
             "/sys/fs/cgroup/cpu,cpuacct/docker/abc/cpu.cfs_quota_us": "250000\n",
             "/sys/fs/cgroup/cpu,cpuacct/docker/abc/cpu.cfs_period_us": "100000\n"}
    lim = run.resource_limits(read=fake_reader(files), affinity=64)
    assert lim["cgroup"] == "v1" and lim["free_gib"] == 7.0 and lim["cpus"] == 2
    assert lim["host_available_gib"] == 32.0  # 32 GiB, the field checks' unit (34.4 in decimal GB)
    files["/sys/fs/cgroup/memory/docker/abc/memory.limit_in_bytes"] = "9223372036854771712"  # v1 "no limit"
    assert run.resource_limits(read=fake_reader(files), affinity=64)["free_gib"] == 32.0


def test_the_memory_guard_refuses_on_the_container_headroom(tmp_path):
    run = _run_mod()
    w = _world(tmp_path / "w", n_accounts=40, june_accounts=10)
    out = tmp_path / "o"
    # the host says 100 GiB free (the old guard passed); the container has 12 GiB left: below the 32 GiB level
    rc = run.main(["--map", w["map"], "--status", w["status"], "--files", *w["files"], "--out", str(out)],
                  recipe_fn=load("fsc_synth").synth_builder, read_limits=fake_reader(v2_limits()))
    assert rc == 4
    m = json.loads((out / "memory.json").read_text())
    assert m["unit"] == "GiB" and m["free_gib"] == 12.0 and m["limits"]["cgroup"] == "v2" and m["min_free_gib"] == 32
    assert "below 32" in m["refused"] and not (out / "screen.json").exists()


def test_threads_follow_the_container_cpu_quota(screen):
    res = screen["res"]  # the shared run's injected cgroup allows 2 CPUs: half is 1 thread
    assert res["memory"]["limits"]["cpus"] == min(2, res["memory"]["limits"]["cpus_affinity"])
    assert res["threads"] == max(1, res["memory"]["limits"]["cpus"] // 2)
    assert res["feature_rank"]["params"]["n_jobs"] == res["threads"]


def test_the_shared_helper_patch_for_nf_common_gives_the_same_limits(tmp_path):
    run = load("fsc_run")
    com = load("nf_common", NF / "nf_common.py")
    if not callable(getattr(com, "resource_limits", None)):
        assert run.shared_limits(com) is run.resource_limits  # the current spine: the screen's own copy
    pat = load_patched("nf_common_patched", NF / "nf_common.py", "nf_common.diff", "def resource_limits", tmp_path)
    assert run.shared_limits(pat) is pat.resource_limits
    v1 = {"/proc/meminfo": "MemAvailable: 1048576 kB\n", "/proc/self/cgroup": "4:memory:/x\n",
          "/sys/fs/cgroup/memory/x/memory.limit_in_bytes": str(GIB // 2),
          "/sys/fs/cgroup/memory/x/memory.usage_in_bytes": str(GIB // 4)}
    for files in (v2_limits(), v2_limits(cpu="150000 100000", current_gib=39.5), v1, {}):
        for aff in (1, 8):
            assert pat.resource_limits(read=fake_reader(files), affinity=aff) == \
                run.resource_limits(read=fake_reader(files), affinity=aff)


# ---------------------------------------------------------------- finding 7: the memory projection

def test_the_memory_projection_counts_the_june_read_and_types_the_cells(tmp_path):
    run = load("fsc_run")
    com = load("nf_common", NF / "nf_common.py")
    w = _world(tmp_path / "w", n_accounts=80, june_accounts=40)
    for f in w["files"]:  # a code column stored as numbers becomes text in the working copy
        d = pd.read_parquet(f)
        d["num_code"] = (np.arange(len(d)) % 7).astype("int64")
        d.to_parquet(f)
    want = ["transaction_amt", "external_1_scr", "transaction_type_xcd", "Nmap_account_reference_xid",
            "transaction_dttm", "frd_tag", "syn_useless_num", "syn_useful_code", "num_code"]
    a = argparse.Namespace(min_free_gb=0.0, max_memory_share=0.8, extract_start="2024-10-01",
                           drift_extract_start="2025-05-01")
    lim = {"free_gib": 1000.0}
    without = run.memory_guard(a, com, w["files"], None, want, 3, (), lim)
    with_june = run.memory_guard(a, com, w["files"], None, want, 3, w["june"], lim)
    coded = run.memory_guard(a, com, w["files"], None, want, 3, w["june"], lim, code_cols=["num_code"])
    june_rows = sum(len(pd.read_parquet(f)) for f in w["june"])
    assert without["june_file_rows"] == 0 and without["parts_gib"]["june_frame"] == 0
    assert with_june["june_file_rows"] == june_rows and with_june["parts_gib"]["june_frame"] > 0
    assert with_june["stage_june_gib"] > without["stage_june_gib"]
    assert with_june["projected_peak_gib"] == max(with_june["stage_fits_gib"], with_june["stage_june_gib"])
    cb = with_june["cell_bytes"]
    assert cb["transaction_amt"] == 8 and cb["frd_tag"] == 8 and cb["num_code"] == 8
    assert 8 < cb["transaction_type_xcd"] < 140  # text: measured, not the old flat 140 bytes per cell
    assert coded["parts_gib"]["working_copy"] > with_june["parts_gib"]["working_copy"]
    df = pd.concat([pd.read_parquet(f, columns=want) for f in w["files"]], ignore_index=True)
    measured = df.memory_usage(deep=True, index=False).sum() / GIB
    assert abs(with_june["parts_gib"]["frame"] - measured) / measured < 0.25


def test_the_screen_prints_and_records_every_memory_part(screen):
    m = screen["res"]["memory"]
    assert set(m["parts_gib"]) == {"frame", "working_copy", "new_fields", "fit_matrices", "june_frame",
                                   "june_builds", "june_reference"}
    assert m["june_file_rows"] > 0 and m["frame_gib"] > 0
    assert abs(m["parts_gib"]["frame"] - m["frame_gib"]) / m["frame_gib"] < 0.25


# ---------------------------------------------------------------- finding 8: every recipe build is counted

def test_the_cost_guard_counts_every_recipe_build(tmp_path):
    """The finding counted six builds per engineered field: the build, a pre-check rebuild, two future-invariance
    passes, June and the June reference, of which the projection counted two. Now the build is reused by the
    pre-check and by the unperturbed future-invariance pass, and the other three are in the projection."""
    run = _run_mod()
    syn = load("fsc_synth")
    calls = []

    def counting(df, recipe, extract_start, model_type=None):
        calls.append((recipe, len(df)))
        return syn.synth_builder(df, recipe, extract_start, model_type)

    w = _world(tmp_path / "w", n_accounts=80, june_accounts=60)
    out = tmp_path / "o"
    rc = run.main(["--map", w["map"], "--status", w["status"], "--files", *w["files"], "--drift-files", *w["june"],
                   "--drift-extract-start", w["june_extract_start"], "--extract-start", w["extract_start"],
                   "--families", "all_new", "--temporal-split", "none", "--no-label-shuffle", "--k", "3",
                   "--n-boot", "20", "--extra-seeds", "43", "--params-json", FAST, "--min-free-gb", "0",
                   "--out", str(out)], recipe_fn=counting)
    assert rc == 0
    cost = json.loads((out / "screen.json").read_text())["cost"]
    done = [p["what"] for p in cost["builds"]["done"]]
    assert done == ["training", "future invariance (perturbed)", "June", "June reference"]
    assert set(cost["builds"]["measured"]) == {"training"}
    assert set(cost["builds"]["projected"]) == set(done) - {"training"}
    # one call per recipe per file per pass: 2 training files, the perturbed copy of both, 1 June file, 2 reference
    per = pd.Series([r for r, _ in calls]).value_counts()
    assert set(per.index) == {"count(24h)", "prev(transaction_amt)", "lookahead(transaction_amt)"}
    assert (per == 2 + 2 + 1 + 2).all()


# ---------------------------------------------------------------- the nits

def test_family_leak_unknown_is_written_as_a_question_mark(screen):
    fr = screen["fr"].set_index("feature")
    assert fr.loc["syn_next_amt", "family_leaky"].split(";")[0] == "a3=?"
    assert "f15298=True" in fr.loc["syn_lookahead_amt", "family_leaky"]


def test_summary_wording_matches_what_happened(screen):
    run = load("fsc_run")
    com = load("nf_common", NF / "nf_common.py")
    text = screen["summary"]
    assert "PSI > 0.25" in text and "PSI >=" not in text
    assert "future invariance: FAILED (" in text and "LEAKY: syn_lookahead_amt" in text
    fr = pd.DataFrame({"feature": ["x"], "in_arm": "yes", "shap_rank_new": [1.0], "perm_rank_new": [1.0],
                       "shap_mean_abs": [0.1], "perm_ap_drop_mean": [0.0], "psi_june": [0.0],
                       "unflagged_shap_rank_new": [np.nan], "unflagged_perm_rank_new": [np.nan], "note": [""]})
    out = {"view": "XGBoost's view, not the transformer's", "layout": "x", "map": "m", "list_status": "UNCONFIRMED",
           "status": "s", "model": "xgboost", "rows": 1, "frauds": 1, "accounts": 1, "files": 1,
           "base_columns_used": [], "missing_base_columns": [], "new_fields": {"x": {}}, "not_built": [],
           "left_out": [], "recipes": "r", "noise_floor": {"floor": 0, "null_abs_delta": 0, "refit_spread": 0},
           "families": {}, "skipped_families": {}, "temporal_split": None,
           "future_invariance": {"ok": True, "probed": [], "not_run": [], "history_fields": 0},
           "drift": {"june_rows": 500, "month": "2025-06", "reference_month": "2025-04",
                     "reference_extract_start": "2025-03-01", "threshold": 0.25, "flagged": [],
                     "reference_fallback": {"x": "RecipeError: no"}, "skipped": {}}}
    t = run.summary(out, fr, com, Path("screen"))
    assert "future invariance: not run (no engineered field with a history recipe)" in t
    assert "whole training stream used (reference rebuild failed): x" in t and "not compared" not in t
    assert "time split not run (--temporal-split none)" in t
    out["future_invariance"] = {"ok": None, "probed": ["y"], "not_run": ["x"], "history_fields": 2,
                                "not_run_reasons": {"x": "RecipeError: 'lead(a)': the grammar is closed"}}
    t = run.summary(out, fr, com, Path("screen"))
    assert "not run on 1 (recipe outside the grammar 1): x" in t and "no recipe module" not in t
    assert "NOT SHOWN for 1 fields (below); ok on 1 rebuilt fields" in t


def test_a_recipe_outside_the_grammar_is_named_so(tmp_path):
    run = _run_mod()
    fn, _ = run.recipe_module()
    if fn is None:
        pytest.skip("nf_recipes.py not installed in this tree")
    d = pd.read_parquet(_world(tmp_path / "w", n_accounts=20, june_accounts=5)["files"][0])
    frame, failed = fn.batch(d, [("x", "lead(transaction_amt)", "continuous"), ("y", "count(24h)", "continuous")],
                             "2024-10-01")
    assert set(failed) == {"x"} and "y" in frame.columns
    assert run.why_not_run(failed["x"]) == "recipe outside the grammar"
    assert run.why_not_run("no recipe module for this recipe") == "no recipe module"


def test_the_time_split_runs_by_default(screen, tmp_path):
    assert screen["res"]["temporal_split"] == "2025-04-01"
    assert "account folds are not chronological; time split: train before 2025-04-01" in screen["summary"]
    run = _run_mod()
    w = _world(tmp_path / "w", n_accounts=40, june_accounts=10)
    fits = {}
    for flag in ([], ["--temporal-split", "none"]):
        out = tmp_path / ("o" + str(len(flag)))
        rc = run.main(["--map", w["map"], "--status", w["status"], "--files", *w["files"], "--max-hours", "1e-9",
                       "--min-free-gb", "0", "--params-json", FAST, "--out", str(out), *flag],
                      recipe_fn=load("fsc_synth").synth_builder)
        assert rc == 4
        fits[len(flag)] = json.loads((out / "cost.json").read_text())["fits"]
    assert fits[0] > fits[2]  # the default counts the time-split fits; none switches them off


def test_the_ranking_is_also_written_without_the_flagged_fields(screen):
    res, fr = screen["res"], screen["fr"].set_index("feature")
    r2 = res["feature_rank_unflagged"]
    assert {"syn_lookahead_amt", "syn_next_amt"} <= set(r2["left_out"])
    assert "future invariance failed" in r2["left_out"]["syn_lookahead_amt"]
    clean = [c for c in res["new_fields"] if c not in r2["left_out"]]
    assert clean and set(r2["columns"]) >= set(clean) and not set(r2["columns"]) & set(r2["left_out"])
    ranked = pd.to_numeric(fr["unflagged_perm_rank_new"], errors="coerce").dropna()
    assert set(ranked.index) == set(clean)
    for c in r2["left_out"]:
        assert pd.isna(pd.to_numeric(fr.loc[c, "unflagged_perm_rank_new"], errors="coerce")) and fr.loc[c, "note"]
    assert "w/o: rank without the" in screen["summary"]


def test_reserved_names_and_fields_missing_from_the_status_file_are_left_out(screen):
    res, fr = screen["res"], screen["fr"]
    left = {d["field"]: d["reason"] for d in res["left_out"]}
    assert left["frd_tag"] == "name clashes with a base input or a reserved name"
    assert left["syn_absent_num"] == "not checked (not in the field status file)"  # the map's PASS is not used
    assert "frd_tag" not in res["new_fields"] and "syn_absent_num" not in res["new_fields"]
    row = fr[fr["feature"] == "frd_tag"]
    assert len(row) == 1 and row["in_arm"].iloc[0] == "no" and row["note"].iloc[0] == "left_out_name_clash"


def test_the_dry_run_leaves_no_temporary_folder_behind(tmp_path, monkeypatch, capsys):
    run = _run_mod()
    made = []
    real = tempfile.mkdtemp

    def mk(*a, **k):
        made.append(real(*a, dir=str(tmp_path), **{x: v for x, v in k.items() if x != "dir"}))
        return made[-1]

    monkeypatch.setattr(run.tempfile, "mkdtemp", mk)
    out = tmp_path / "s"
    assert run.main(["--dry-run", "--out", str(out), "--k", "2", "--n-boot", "20", "--extra-seeds", "43",
                     "--temporal-split", "none", "--no-label-shuffle"]) == 0
    assert made and not Path(made[0]).exists()  # the world is removed, and the empty folder too
    assert (out / "summary.txt").exists()
    assert f"outputs: {out.resolve()}" in capsys.readouterr().out
