"""Per-feature ranking: SHAP sums and permutation, on a small planted frame."""

import numpy as np
import pandas as pd
import pytest

from field_screen_helpers import load, xgboost_available


def _frame(n=6000, seed=0):
    rng = np.random.default_rng(seed)
    y = (rng.random(n) < 0.08).astype(int)
    return pd.DataFrame({"Nmap_account_reference_xid": [f"a{i % 600}" for i in range(n)],
                         "transaction_dttm": pd.Timestamp("2024-10-01") + pd.to_timedelta(rng.uniform(0, 2e7, n), "s"),
                         "frd_tag": y, "b1": rng.normal(size=n), "sig": rng.normal(size=n) + 2.0 * y,
                         "twin": None, "noise": rng.normal(size=n),
                         "code": np.where(rng.random(n) < 0.5, "x", "z")}).assign(twin=lambda d: d["sig"] * 2 + 1)


@pytest.mark.skipif(not xgboost_available(), reason="xgboost not installed")
def test_shap_sum_equals_sum_of_absolute_contributions():
    import xgboost as xgb
    U = load("fsc_usefulness")
    d = _frame()
    X = U._design(d, ["b1", "sig", "noise", "code"], {"code"})
    m, _ = U._fit_predict(X, d["frd_tag"], X.iloc[:5], {**U.DEFAULT_PARAMS, "n_estimators": 20}, 0)
    s, n = U.shap_per_feature(m, X)
    c = m.get_booster().predict(xgb.DMatrix(X, enable_categorical=True), pred_contribs=True)
    assert n == len(X) and c.shape[1] == X.shape[1] + 1
    for j, col in enumerate(X.columns):
        assert np.isclose(s[col], np.abs(c[:, j]).sum())
    # contributions plus bias give the margin, so these are the model's own SHAP values
    assert np.allclose(c.sum(axis=1), m.get_booster().predict(xgb.DMatrix(X, enable_categorical=True), output_margin=True),
                       atol=1e-4)


def test_feature_rank_orders_signal_noise_and_clusters():
    U = load("fsc_usefulness")
    if not U.xgboost_available():
        U.use_sklearn_fallback()
    d = _frame()
    r = U.feature_rank(d, ["b1"], ["sig", "twin", "noise", "code"], {"code"}, clusters={"c1": ["sig", "twin"]},
                       k=3, params={"n_estimators": 30, "max_depth": 3}, shap_rows=1000)
    p = r["permutation"]
    assert p["noise"]["ap_drop_mean"] < 0.01
    # twins hide each other alone; together they cannot
    assert r["cluster_permutation"]["c1"]["ap_drop_mean"] > max(p["sig"]["ap_drop_mean"], p["twin"]["ap_drop_mean"])
    assert r["cluster_permutation"]["c1"]["ap_drop_mean"] > 0.1
    assert r["view"] == "XGBoost's view, not the transformer's"
    if r["shap"]:
        mean = r["shap"]["mean_abs"]
        assert r["shap"]["rows"] == 3000 and mean["noise"] < max(mean["sig"], mean["twin"])
        assert np.isclose(mean["sig"], r["shap"]["sum_abs"]["sig"] / r["shap"]["rows"])
