"""Regression tests for the screen recheck's six problems (synthetic data only, no network).

Each test reproduces the recheck's evidence and fails on the screen as folded at 8d7f61a:
1. an engineered field on a STOP or WAIT source was screened with no note;
2. June drift flagged an honest many-level code for its sampling noise (PSI > 0.25 at about 150 June rows);
3. the reference month had no row minimum (a few rows flagged honest numbers);
4. duplicate map names were dropped silently;
5. a map row named like a base input was not refused;
6. a field named like a history-lite column crashed under --history-lite, and one named like a 26 October column
   was read in place of the builder's column under --oct26.
One screen run (the `recheck` fixture) is shared by the first three."""

import argparse
import json
import re

import numpy as np
import pandas as pd
import pytest

from field_screen_helpers import NF, load, load_patched

FAST = json.dumps({"n_estimators": 10, "max_depth": 2})
STATUS_HEADER = ["field", "group", "kind", "result", "reasons", "cluster_id", "kept_once_as"]
LEVELS = np.array([f"R{j:02d}" for j in range(40)], dtype=object)
SHARES = 1.0 / np.arange(1, 41) ** 1.1
SHARES /= SHARES.sum()


def _run_mod():
    run = load("fsc_run")
    U = run.modules()["U"]
    if not U.xgboost_available():
        U.use_sklearn_fallback()
    return run


def _at_shares(rng, n, shares):
    """n codes holding each level at its share, rounded (an honest sample with no draw luck), shuffled."""
    k = np.floor(n * shares).astype(int)
    k[0] += n - k.sum()
    return rng.permutation(np.repeat(LEVELS, k))


def _world(folder, n_accounts=150, june_accounts=30):
    syn = load("fsc_synth")
    com = load("nf_common", NF / "nf_common.py")
    return syn.world(folder, n_accounts=n_accounts, june_accounts=june_accounts,
                     field_map_columns=com.FIELD_MAP_COLUMNS)


def _map_row(m, **kw):
    d = {c: "" for c in m.columns}
    d.update({"definition_version": "1", "excluded_by_sumegha": "no", "feasible_in_production": "yes",
              "list_status": "UNCONFIRMED", **kw})
    return d


def _add_rows(w, rows, status_rows=()):
    m = pd.read_csv(w["map"], dtype=str, keep_default_na=False)
    pd.concat([m, pd.DataFrame([_map_row(m, **r) for r in rows], columns=m.columns)],
              ignore_index=True).to_csv(w["map"], index=False)
    st = pd.read_csv(w["status"], dtype=str, keep_default_na=False)
    st = pd.concat([st, pd.DataFrame(list(status_rows))], ignore_index=True).fillna("")
    st.to_csv(w["status"], index=False)


def _args(w, out, *extra, june=True):
    a = ["--map", w["map"], "--status", w["status"], "--files", *w["files"], "--extract-start", w["extract_start"],
         "--k", "3", "--n-boot", "20", "--extra-seeds", "43", "--params-json", FAST, "--min-free-gb", "0",
         "--temporal-split", "none", "--no-label-shuffle", "--families", "all_new", "--out", str(out)]
    if june:
        a += ["--drift-files", *w["june"], "--drift-extract-start", w["june_extract_start"]]
    return a + list(extra)


@pytest.fixture(scope="module")
def recheck(tmp_path_factory):
    """A world whose training files end on 2 May (a few May rows: the last month is partial), with a label copy
    stopped by the checks and an engineered field reading it (its own status PASS, as a stale status file says),
    a twin stopped as a duplicate and an engineered field reading it, an honest 40-code field (its June rows hold
    the training shares) and the same codes with their June shares reversed. About 150 June rows."""
    tmp = tmp_path_factory.mktemp("recheck")
    w = _world(tmp / "w")
    rng = np.random.default_rng(11)
    for i, f in enumerate(w["files"]):
        d = pd.read_parquet(f)
        last = d.sort_values("transaction_dttm").groupby("Nmap_account_reference_xid").tail(1).head(10).copy()
        last["transaction_dttm"] = pd.Timestamp("2025-05-01") + pd.to_timedelta(rng.uniform(0, 36, len(last)), unit="h")
        last["fi_transaction_id"] = [f"M{i}{j:06d}" for j in range(len(last))]
        last["frd_tag"] = 0
        d = pd.concat([d, last], ignore_index=True)
        d["syn_leak_src"] = d["frd_tag"] + rng.normal(0, 0.05, len(d))  # a label copy: STOP label_copy
        d["syn_twin_src"] = d["syn_profile_num"]  # a twin of a kept field: STOP duplicate
        d["syn_rare_code"] = rng.choice(LEVELS, len(d), p=SHARES)
        d["syn_rare_drift"] = rng.choice(LEVELS, len(d), p=SHARES)
        d.to_parquet(f)
    for f in w["june"]:
        d = pd.read_parquet(f)
        d["syn_leak_src"] = d["frd_tag"] + rng.normal(0, 0.05, len(d))
        d["syn_twin_src"] = d["syn_profile_num"]
        june = (pd.to_datetime(d["transaction_dttm"]).dt.to_period("M") == pd.Period("2025-06", "M")).to_numpy()
        codes = rng.choice(LEVELS, len(d), p=SHARES).astype(object)
        codes[june] = _at_shares(rng, int(june.sum()), SHARES)  # honest June rows: the training shares
        d["syn_rare_code"] = codes
        d["syn_rare_drift"] = rng.choice(LEVELS, len(d), p=SHARES[::-1])  # a real June shift
        d.to_parquet(f)
    _add_rows(w, [
        {"name": "syn_leak_src", "group": "f15298", "kind": "raw", "recipe": "raw", "source_columns": "syn_leak_src",
         "model_type": "continuous"},
        {"name": "syn_leak_prev", "group": "f15298", "kind": "engineered", "recipe": "prev(syn_leak_src)",
         "source_columns": "syn_leak_src", "model_type": "continuous"},
        {"name": "syn_twin_src", "group": "v22b", "kind": "raw", "recipe": "raw", "source_columns": "syn_twin_src",
         "model_type": "continuous"},
        {"name": "syn_twin_prev", "group": "f15298", "kind": "engineered", "recipe": "prev(syn_twin_src)",
         "source_columns": "syn_twin_src", "model_type": "continuous"},
        {"name": "syn_rare_code", "group": "v22b", "kind": "raw", "recipe": "raw", "source_columns": "syn_rare_code",
         "model_type": "categorical"},
        {"name": "syn_rare_drift", "group": "v22b", "kind": "raw", "recipe": "raw",
         "source_columns": "syn_rare_drift", "model_type": "categorical"}],
        [{"field": "syn_leak_src", "result": "STOP", "reasons": "STOP label_copy (frd_tag)"},
         {"field": "syn_leak_prev", "result": "PASS", "reasons": ""},
         {"field": "syn_twin_src", "result": "STOP", "reasons": "STOP duplicate (copy of syn_profile_num)"},
         {"field": "syn_twin_prev", "result": "PASS", "reasons": ""},
         {"field": "syn_rare_code", "result": "PASS", "reasons": ""},
         {"field": "syn_rare_drift", "result": "PASS", "reasons": ""}])
    out = tmp / "o"
    run = _run_mod()
    rc = run.main(_args(w, out), recipe_fn=load("fsc_synth").synth_builder)
    assert rc == 0
    return {"w": w, "out": out, "res": json.loads((out / "screen.json").read_text()),
            "fr": pd.read_csv(out / "feature_rank.csv", keep_default_na=False),
            "summary": (out / "summary.txt").read_text()}


# ---------------------------------------------------------------- 1. an engineered field on a STOP or WAIT source

def _fmap(rows):
    cols = ["name", "kind", "recipe", "source_columns", "list_status", "excluded_by_sumegha", "left_out_reason",
            "check_result", "check_reasons"]
    return pd.DataFrame([{c: r.get(c, "") for c in cols} for r in rows], columns=cols)


def test_an_engineered_field_on_a_stopped_or_waiting_source_is_left_out():
    run = load("fsc_run")
    rec = NF / "nf_recipes.py"
    if not rec.exists():
        pytest.skip("nf_recipes.py not installed in this tree")
    parse = load("nf_recipes", rec).parse
    fmap = _fmap([
        {"name": "src_label", "kind": "raw", "recipe": "raw", "source_columns": "src_label"},
        {"name": "eng_mean", "kind": "engineered", "recipe": "mean(24h; value=src_label)", "source_columns": ""},
        {"name": "src_status", "kind": "raw", "recipe": "raw", "source_columns": "src_status"},
        {"name": "eng_sum", "kind": "engineered", "recipe": "sum(7d; value=src_status)", "source_columns": "src_status"},
        {"name": "scale_renamed", "kind": "raw", "recipe": "raw", "source_columns": "pod_scale_col"},
        {"name": "eng_scale", "kind": "engineered", "recipe": "max(24h; value=pod_scale_col)",
         "source_columns": "pod_scale_col"},
        {"name": "src_twin", "kind": "raw", "recipe": "raw", "source_columns": "src_twin"},
        {"name": "eng_twin", "kind": "engineered", "recipe": "min(24h; value=src_twin)", "source_columns": "src_twin"},
        {"name": "src_date", "kind": "raw", "recipe": "raw", "source_columns": "src_date"},
        {"name": "eng_days", "kind": "engineered", "recipe": "days_before(src_date)", "source_columns": "src_date"},
        {"name": "eng_base", "kind": "engineered", "recipe": "sum(24h; value=transaction_amt)",
         "source_columns": "transaction_amt"},
        {"name": "eng_two", "kind": "engineered", "recipe": "ratio(src_label; src_status)",
         "source_columns": "src_label;src_status"}])
    status = {"src_label": ("STOP", "STOP label_copy (frd_tag)"), "eng_mean": ("PASS", ""),
              "src_status": ("WAIT", "WAIT status (status-like name)"), "eng_sum": ("PASS", ""),
              "scale_renamed": ("STOP", "STOP type_scale (mean 1e9 sd 1e9)"), "eng_scale": ("FLAG", "FLAG fill_ratio (x)"),
              "src_twin": ("STOP", "STOP duplicate (exact of src_label2)"), "eng_twin": ("PASS", ""),
              "src_date": ("STOP", "STOP raw_date (a date enters only as days_before or days_until)"),
              "eng_days": ("PASS", ""), "eng_base": ("PASS", ""), "eng_two": ("PASS", "")}
    # the map's source_columns alone already leave out a field whose source is STOP or WAIT
    _, left0 = run.select_fields(fmap, status, False, status_given=True)
    assert dict(left0).get("eng_sum") == "source_stop:src_status status"
    # with the recipe module's parser, the recipe's own sources count too
    enter, left = run.select_fields(fmap, status, False, status_given=True, parse_fn=parse)
    why = dict(left)
    assert why["eng_mean"] == "source_stop:src_label label_copy"  # the recipe's own source, not source_columns
    assert why["eng_sum"] == "source_stop:src_status status"  # a WAIT carries too
    assert why["eng_scale"] == "source_stop:pod_scale_col type_scale"  # a renamed raw row, by its source column
    assert why["eng_two"] == "source_stop:src_label label_copy; source_stop:src_status status"
    entered = [r["name"] for r in enter]
    # a twin kept once under another name, and a raw date (it enters only through days_before) keep their values
    assert {"eng_twin", "eng_days", "eng_base"} <= set(entered)
    assert not {"eng_mean", "eng_sum", "eng_scale", "eng_two"} & set(entered)
    # the map's own check_result, without a field status file, is read the same way
    m2 = fmap.copy()
    m2["check_result"] = [status[n][0] for n in m2["name"]]
    m2["check_reasons"] = [status[n][1] for n in m2["name"]]
    _, left2 = run.select_fields(m2, {}, False, status_given=False, parse_fn=parse)
    assert dict(left2)["eng_mean"] == "source_stop:src_label label_copy"
    assert run.carried_rule("STOP", "STOP duplicate (x); STOP type_scale (y)") == "type_scale"
    assert run.carried_rule("WAIT", "") == "WAIT" and run.carried_rule("FLAG", "FLAG x (y)") is None


def test_the_screen_leaves_out_a_field_whose_source_is_stopped(recheck, tmp_path):
    res, fr = recheck["res"], recheck["fr"].set_index("feature")
    left = {d["field"]: d["reason"] for d in res["left_out"]}
    assert left["syn_leak_prev"] == "source_stop:syn_leak_src label_copy"
    assert "syn_leak_prev" not in res["new_fields"] and "syn_twin_prev" in res["new_fields"]
    assert fr.loc["syn_leak_prev", "in_arm"] == "no"
    assert fr.loc["syn_leak_prev", "note"] == "source_stop:syn_leak_src label_copy"
    assert "source STOP or WAIT, left out: syn_leak_prev (syn_leak_src)" in recheck["summary"]
    if not (NF / "nf_feature_summary.py").exists():
        return
    folder = tmp_path / "checks"  # the checks summary drafts review for it, with the screen's note as the reason
    folder.mkdir()
    pd.DataFrame([{"field": "syn_leak_prev", "group": "f15298", "kind": "engineered", "result": "PASS", "reasons": "",
                   "cluster_id": "", "kept_once_as": ""}], columns=STATUS_HEADER).to_csv(folder / "field_status.csv",
                                                                                          index=False)
    pat = load_patched("nf_feature_summary_patched", NF / "nf_feature_summary.py", "nf_feature_summary.diff",
                       "RANK_CONTRACT", tmp_path)
    df = pat.build(folder, recheck["out"] / "feature_rank.csv", None).set_index("feature")
    assert df.loc["syn_leak_prev", "draft_verdict"] == "review"
    assert "screen: source_stop:syn_leak_src label_copy" in df.loc["syn_leak_prev", "draft_reason"]


# ---------------------------------------------------------------- 2. the drift cut

def test_the_binned_psi_equals_the_copied_psi():
    run = load("fsc_run")
    S = run.modules()["S"]
    rng = np.random.default_rng(1)
    for _ in range(10):
        a = pd.Series(rng.choice(LEVELS, int(rng.integers(50, 2000)), p=SHARES), dtype=object)
        b = pd.Series(rng.choice(LEVELS, int(rng.integers(50, 2000)), p=SHARES[::-1]), dtype=object)
        b.iloc[:3], b.iloc[3:5] = "NEW", None
        cr, co, _ = run.psi_counts(a, b, True)
        assert abs(run.psi_from_counts(cr, co)[0] - S.psi(a, b, categorical=True)) < 1e-12
        x, z = pd.Series(rng.normal(0, 1, 500)), pd.Series(rng.normal(0.3, 1, 300))
        x.iloc[:20], z.iloc[:9] = np.nan, np.nan
        cr, co, _ = run.psi_counts(x, z, False)
        assert abs(run.psi_from_counts(cr, co)[0] - S.psi(x, z)) < 1e-12


def test_the_drift_cut_is_the_resampled_95th_percentile_per_field(recheck):
    run = load("fsc_run")
    d = recheck["res"]["drift"]
    honest, moved = d["columns"]["syn_rare_code"], d["columns"]["syn_rare_drift"]
    # the recheck's evidence: an honest 40-code field at about 150 June rows is above 0.25 by sampling alone
    assert 100 <= d["june_rows"] <= 300 and honest["psi"] > 0.25
    assert not honest["flag"] and "syn_rare_code" not in d["flagged"]
    assert honest["null_psi_q95"] > 0.25 and honest["cut"] == max(0.25, honest["null_psi_q95"])
    assert honest["psi"] <= honest["cut"]
    assert moved["flag"] and moved["psi"] > moved["cut"] and "syn_rare_drift" in d["flagged"]  # a real shift
    for n, c in d["columns"].items():  # per field: the larger of the threshold and the field's own percentile
        assert c["cut"] == max(d["threshold"], c["null_psi_q95"]) and c["flag"] == (c["psi"] > c["cut"]), n
    fr = recheck["fr"].set_index("feature")
    assert abs(float(fr.loc["syn_rare_code", "drift_cut"]) - honest["cut"]) < 1e-9
    assert "drift_june" not in fr.loc["syn_rare_code", "note"]
    assert f"drift_june psi={moved['psi']:.2f} cut={moved['cut']:.2f}" in fr.loc["syn_rare_drift", "note"]
    text = recheck["summary"]  # the cut is printed: the raised cuts, and a cut column in the table
    assert "cut per field: max(0.25, 95th pct of PSI on resampled accounts)" in text
    assert f"syn_rare_code {honest['cut']:.2f}" in text
    row = next(x for x in text.splitlines() if re.match(r"^\s*\d+ syn_rare_code ", x))  # its table row
    assert f" {honest['cut']:.2f} " in row
    # the draws are repeatable (seeded per field)
    ref = pd.Series(["a", "b", "c"] * 50)
    assert run.drift_null(ref, 30, True, seed=run._field_seed(42, "x")) == \
        run.drift_null(ref, 30, True, seed=run._field_seed(42, "x"))


def test_the_cut_keeps_honest_fields_quiet_and_flags_a_shift():
    """The recheck's numbers: an honest 40-code field against a large reference was flagged in every draw at 100
    June rows and in 57% at 300 by PSI > 0.25. With the cut, few honest draws are flagged; a real shift always is."""
    run = load("fsc_run")
    S = run.modules()["S"]
    rng = np.random.default_rng(3)
    ref = pd.Series(rng.choice(LEVELS, 30000, p=SHARES), dtype=object)
    for m in (100, 300):
        old = new = moved = 0
        for i in range(40):
            june = pd.Series(rng.choice(LEVELS, m, p=SHARES), dtype=object)
            shift = pd.Series(rng.choice(LEVELS, m, p=SHARES[::-1]), dtype=object)
            cut = max(0.25, run.drift_null(ref, m, True, seed=[i, m]))
            old += S.psi(ref, june, categorical=True) > 0.25
            new += S.psi(ref, june, categorical=True) > cut
            moved += S.psi(ref, shift, categorical=True) > cut
        assert old >= (38 if m == 100 else 12) and new <= 6 and moved == 40, (m, old, new, moved)


# ---------------------------------------------------------------- 3. a row minimum on the reference month

def _frame(rng, start, days, n_acc, first, rate):
    rows = []
    for a in range(n_acc):
        n = max(1, rng.poisson(rate * days))
        ts = np.sort(rng.uniform(0, days * 86400, n)).round()
        rows.append(pd.DataFrame({"Nmap_account_reference_xid": f"Q{first + a:05d}",
                                  "transaction_dttm": pd.Timestamp(start) + pd.to_timedelta(ts, unit="s")}))
    df = pd.concat(rows, ignore_index=True)
    df["fi_transaction_id"] = [f"Q{first}{i:07d}" for i in range(len(df))]
    df["transaction_amt"] = np.round(np.exp(rng.normal(3, 1, len(df))), 2)
    return df


SINCE_ALL = "since_last(days; within=all)"


def _since_last(df, recipe, extract_start, model_type=None):
    """since_last(days; within=all) as a stand-in recipe: days since the account's previous row in the frame."""
    t = pd.to_datetime(df["transaction_dttm"])
    d = pd.DataFrame({"a": df["Nmap_account_reference_xid"].to_numpy(), "t": t.to_numpy()}, index=df.index)
    d = d.sort_values(["a", "t"], kind="mergesort")
    prev = d.groupby("a")["t"].shift(1)
    return ((d["t"] - prev).dt.total_seconds() / 86400).reindex(df.index)


def test_the_reference_month_needs_the_minimum_rows_and_falls_back():
    run = _run_mod()
    S = run.modules()["S"]
    rng = np.random.default_rng(7)
    train = _frame(rng, "2024-10-01", 212, 600, 0, 0.6)  # 1 October 2024 to 30 April 2025
    may = train[train["transaction_dttm"] >= "2025-04-30"].head(25).copy()  # 25 rows on 1 to 2 May, one on 31 May
    may["transaction_dttm"] = pd.Timestamp("2025-05-01") + pd.to_timedelta(rng.uniform(0, 36, len(may)), unit="h")
    may.iloc[-1, may.columns.get_loc("transaction_dttm")] = pd.Timestamp("2025-05-31 12:00")  # a whole month, few rows
    may["fi_transaction_id"] = [f"MAY{i:04d}" for i in range(len(may))]
    df = pd.concat([train, may], ignore_index=True)
    ev = _frame(rng, "2025-05-01", 61, 600, 10**4, 0.6)
    row = {"name": "eng_since_all", "group": "f15298", "kind": "engineered", "recipe": SINCE_ALL,
           "source_columns": "transaction_dttm", "model_type": "continuous"}
    info = {"eng_since_all": {"model_type": "continuous"}}
    a = argparse.Namespace(drift_month="2025-06", drift_extract_start="2025-05-01", drift_threshold=0.25,
                           drift_min_rows=100, seed=42)
    res = run.june_drift(a, df, ev, [row], {"eng_since_all": _since_last(df, SINCE_ALL, "2024-10-01").to_numpy()},
                         info, run.Builder(None, _since_last, "stand-in"), S)
    april = int((df["transaction_dttm"].dt.to_period("M") == pd.Period("2025-04", "M")).sum())
    assert res["reference_month"] == "2025-04" and res["reference_extract_start"] == "2025-03-01"
    assert res["reference_rows"] == april and april >= 100
    assert res["reference_note"] == (f"2025-05 has 25 rows, below --drift-min-rows 100: the reference is 2025-04 "
                                     f"({april} rows)")
    col = res["columns"]["eng_since_all"]
    assert col["reference"].startswith("2025-04 rebuilt from 2025-03-01") and not col["flag"]
    # the recheck's evidence: the 25-row May reference (rebuilt from 1 April) flags this honest field
    t = pd.to_datetime(df["transaction_dttm"])
    sub = df[t >= "2025-04-01"]
    in_may = (sub["transaction_dttm"].dt.to_period("M") == pd.Period("2025-05", "M")).to_numpy()
    old_ref = _since_last(sub, SINCE_ALL, "2025-04-01")[in_may]
    in_june = (ev["transaction_dttm"].dt.to_period("M") == pd.Period("2025-06", "M")).to_numpy()
    jv = _since_last(ev, SINCE_ALL, "2025-05-01")[in_june]
    assert len(old_ref) == 25 and S.psi(old_ref, jv) > 0.25
    # with too few rows in both months, the whole training stream is the reference, with a note
    small = pd.concat([df[(t >= "2025-04-20") & (t < "2025-05-01")].head(40), may], ignore_index=True)
    res3 = run.june_drift(a, small, ev, [row], {"eng_since_all": _since_last(small, SINCE_ALL, "2024-10-01").to_numpy()},
                          info, run.Builder(None, _since_last, "stand-in"), S)
    assert res3["reference_month"] == "whole training stream" and res3["reference_rows"] == 0
    assert res3["reference_note"] == ("2025-05 has 25 rows; 2025-04 has 40 rows, below --drift-min-rows 100: "
                                      "the reference is the whole training stream")
    assert res3["columns"]["eng_since_all"]["reference"].startswith("whole training stream (no reference month")


def test_the_screen_prints_the_reference_rows_and_the_fallback(recheck):
    run = load("fsc_run")
    d = recheck["res"]["drift"]
    assert d["reference_month"] == "2025-04" and d["reference_tried"][0]["month"] == "2025-05"
    assert d["reference_tried"][0]["rows"] < 100 <= d["reference_rows"]
    may = d["reference_tried"][0]  # 20 rows on 1 to 2 May: too few rows, and a partial month
    assert may["ends"] == "2025-05-02" and d["reference_note"] == (
        f"2025-05 is partial (the training rows end on 2025-05-02) and has {may['rows']} rows, below "
        f"--drift-min-rows 100: the reference is 2025-04 ({d['reference_rows']} rows)")
    text = recheck["summary"]
    assert f"ref 2025-04 ({d['reference_rows']} rows) rebuilt from 2025-03-01" in text
    # the summary's short line (the full sentence above stays in screen.json); nothing is cut at 90 characters
    assert f"  not used: 2025-05 (partial, to 2 May, {may['rows']} rows); minimum 100 rows" in text.split("\n")
    lines = text.rstrip("\n").split("\n")
    assert len(lines) <= 40 and max(len(x) for x in lines) <= 90
    assert not any(len(x) == 90 and x.endswith("...") for x in lines)
    assert run.reference_skips(d) in lines
    for n in ("syn_cnt_24h", "syn_prev_amt"):  # honest rebuilt numbers are not flagged against the April reference
        assert d["columns"][n]["reference"].startswith("2025-04 rebuilt from 2025-03-01") and not d["columns"][n]["flag"]


# ---------------------------------------------------------------- 4 and 5. names refused before any read

def test_duplicate_map_names_are_refused_with_exit_2_naming_the_rows(tmp_path, capsys):
    run = _run_mod()
    w = _world(tmp_path / "w", n_accounts=40, june_accounts=10)
    _add_rows(w, [{"name": "syn_cnt_24h", "group": "f15298", "kind": "engineered", "recipe": "count(1h)",
                   "source_columns": "transaction_dttm", "model_type": "continuous"}])
    rows = [i + 2 for i, n in enumerate(pd.read_csv(w["map"], dtype=str)["name"]) if n == "syn_cnt_24h"]
    out = tmp_path / "o"
    assert run.main(_args(w, out, june=False), recipe_fn=load("fsc_synth").synth_builder) == 2
    text = capsys.readouterr().out
    assert "refused: map rows share a name in FIELD_MAP.csv" in text
    assert f"syn_cnt_24h: rows {rows[0]}, {rows[1]}" in text and len(rows) == 2
    assert not (out / "screen.json").exists() and not (out / "memory.json").exists()


def test_a_map_row_named_like_a_base_input_is_refused_with_exit_2(tmp_path, capsys):
    run = _run_mod()
    w = _world(tmp_path / "w", n_accounts=40, june_accounts=10)
    _add_rows(w, [{"name": "transaction_amt", "group": "v22b", "kind": "raw", "recipe": "raw",
                   "source_columns": "syn_useless_num", "model_type": "continuous"},
                  {"name": "Transaction_Amt", "group": "v22b", "kind": "raw", "recipe": "raw",
                   "source_columns": "transaction_amt", "model_type": "continuous"},
                  {"name": "Day_Of_Week", "group": "v22b", "kind": "raw", "recipe": "raw",
                   "source_columns": "syn_useless_num", "model_type": "continuous"}],
             [{"field": "transaction_amt", "result": "PASS"}, {"field": "Transaction_Amt", "result": "PASS"},
              {"field": "Day_Of_Week", "result": "PASS"}])
    out = tmp_path / "o"
    assert run.main(_args(w, out, june=False), recipe_fn=load("fsc_synth").synth_builder) == 2
    text = capsys.readouterr().out
    assert "refused: map rows named like a base input in FIELD_MAP.csv" in text
    n = len(pd.read_csv(w["map"], dtype=str))
    assert f"transaction_amt: row {n - 1}, base input transaction_amt" in text
    assert f"Transaction_Amt: row {n}, base input transaction_amt" in text  # letter case ignored
    assert f"Day_Of_Week: row {n + 1}, base input day_of_week" in text  # a derived calendar input too
    assert not (out / "screen.json").exists() and not (out / "memory.json").exists()


# ---------------------------------------------------------------- 6. history-lite and 26 October names

def _reads(run, monkeypatch):
    seen = []
    real = run.read_frame

    def spy(path, fs, columns, lay):
        seen.append(list(columns))
        return real(path, fs, columns, lay)

    monkeypatch.setattr(run, "read_frame", spy)
    return seen


def test_a_field_named_like_a_history_lite_column_is_left_out_before_any_read(tmp_path, monkeypatch):
    run = _run_mod()
    w = _world(tmp_path / "w", n_accounts=60, june_accounts=10)
    syn = load("fsc_synth")
    for f in w["files"]:  # a stored column of that name, which the screen must not read either
        d = pd.read_parquet(f)
        d["lag1_amt"] = syn.synth_builder(d, "prev(transaction_amt)", w["extract_start"]).to_numpy()
        d.to_parquet(f)
    _add_rows(w, [{"name": "lag1_amt", "group": "f15298", "kind": "engineered", "recipe": "prev(transaction_amt)",
                   "source_columns": "transaction_amt", "model_type": "continuous"}],
              [{"field": "lag1_amt", "result": "PASS"}])
    seen = _reads(run, monkeypatch)
    out = tmp_path / "o"
    rc = run.main(_args(w, out, "--history-lite", june=False), recipe_fn=syn.synth_builder)
    assert rc == 0  # it crashed in the history-lite arm (two columns of one name)
    res = json.loads((out / "screen.json").read_text())
    left = {d["field"]: d["reason"] for d in res["left_out"]}
    assert left["lag1_amt"] == "name clashes with a history-lite column (--history-lite)"
    assert "lag1_amt" not in res["new_fields"] and seen and all("lag1_amt" not in c for c in seen)
    assert "on_history_lite" in res["families"]["all_new"]
    fr = pd.read_csv(out / "feature_rank.csv", keep_default_na=False).set_index("feature")
    assert fr.loc["lag1_amt", "in_arm"] == "no" and fr.loc["lag1_amt", "note"] == "left_out_name_clash"
    # without --history-lite the name clashes with nothing, and the field enters
    rc = run.main(_args(w, tmp_path / "o2", june=False), recipe_fn=syn.synth_builder)
    assert rc == 0 and "lag1_amt" in json.loads((tmp_path / "o2" / "screen.json").read_text())["new_fields"]


def test_a_field_named_like_a_26_october_column_is_left_out_under_oct26(tmp_path):
    run = _run_mod()
    w = _world(tmp_path / "w", n_accounts=60, june_accounts=10)
    _add_rows(w, [{"name": "drain_24h", "group": "f15298", "kind": "engineered", "recipe": "count(24h)",
                   "source_columns": "transaction_dttm", "model_type": "continuous"}],
              [{"field": "drain_24h", "result": "PASS"}])
    out = tmp_path / "o"
    rc = run.main(_args(w, out, "--oct26", "drain_24h", june=False), recipe_fn=load("fsc_synth").synth_builder)
    assert rc == 0
    res = json.loads((out / "screen.json").read_text())
    left = {d["field"]: d["reason"] for d in res["left_out"]}
    # before, the 26 October family read the map field's count(24h) under the builder's name
    assert left["drain_24h"] == "name clashes with a 26 October column (--oct26 drain_24h)"
    assert "drain_24h" not in res["new_fields"] and "oct26:drain_24h" in res["families"]
    # an a3 row built by the very column it is named after is the same values: it does not clash
    clash = run.clash_names({"frd_tag"}, oct26_cols=[("drain_24h", "drain_24h")])
    same = pd.Series({"name": "drain_24h", "recipe": "a3(drain_24h)"})
    other = pd.Series({"name": "Drain_24h", "recipe": "count(24h)"})
    assert run.clash_reason(same, clash) == "" and run.clash_reason(other, clash).startswith("name clashes with a 26")
    assert run.clash_reason(pd.Series({"name": "FRD_TAG", "recipe": "raw"}), clash).startswith("name clashes")
