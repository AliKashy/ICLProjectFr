"""Shared helpers for the field-screen tests (synthetic data only, no network)."""

import importlib.util
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
FS = ROOT / "fraud" / "experiments" / "features" / "field_screen"
NF = ROOT / "fraud" / "experiments" / "features" / "new_fields"


def load(name, path=None):
    """A module by path, registered under its own name (the screen's modules load each other the same way)."""
    for p in (str(ROOT / "src"), str(ROOT)):
        if p not in sys.path:
            sys.path.insert(0, p)
    if name not in sys.modules:
        path = path or (FS / f"{name}.py")
        spec = importlib.util.spec_from_file_location(name, path)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[name] = mod
        spec.loader.exec_module(mod)
    return sys.modules[name]


def old_screen_file(name):
    """A file of the old screen: the reorganized folder first, then the pre-reorganization folder."""
    for rel in ("fraud/experiments/features/screen", "waqas/v2/screen"):
        p = ROOT / rel / name
        if p.exists():
            return p
    raise FileNotFoundError(name)


def xgboost_available():
    try:
        import xgboost  # noqa: F401
        return True
    except ImportError:
        return False


CROSS_LANE = Path(__file__).resolve().parent / "cross_lane"  # the screen's proposed patches to other lanes' files


def apply_unified_diff(text, diff):
    """Apply a one-file unified diff to `text` (pure Python; every hunk's old lines must match exactly)."""
    import re
    lines = text.splitlines(keepends=True)
    out, pos = [], 0
    for hunk in re.split(r"(?m)^@@", diff)[1:]:
        header, _, body = hunk.partition("\n")
        if not re.match(r" -\d+(?:,\d+)? \+\d+(?:,\d+)? @@", header):
            raise ValueError("bad hunk header: " + header)
        old, new = [], []
        for ln in body.splitlines(keepends=True):
            if ln.startswith("\\"):
                continue
            tag, rest = (ln[:1], ln[1:]) if ln not in ("\n", "\r\n") else (" ", ln)
            if tag in (" ", "-"):
                old.append(rest)
            if tag in (" ", "+"):
                new.append(rest)
        for i in range(pos, len(lines) - len(old) + 1):
            if lines[i:i + len(old)] == old:
                break
        else:
            raise ValueError("a hunk does not apply: " + header)
        out += lines[pos:i] + new
        pos = i + len(old)
    return "".join(out + lines[pos:])


def load_patched(name, path, diff_name, marker, tmp_dir):
    """The other lane's module `path` with the screen's cross-lane patch applied, loaded under `name` from a
    copy in `tmp_dir`. When the file already carries the patch (`marker` in its text), the file itself."""
    text = Path(path).read_text()
    if marker not in text:
        text = apply_unified_diff(text, (CROSS_LANE / diff_name).read_text())
    folder = Path(tmp_dir) / "a" / "b" / "c" / "d"
    folder.mkdir(parents=True, exist_ok=True)
    p = folder / Path(path).name
    p.write_text(text)
    saved = list(sys.path)
    try:
        spec = importlib.util.spec_from_file_location(name, p)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[name] = mod
        spec.loader.exec_module(mod)
    finally:
        sys.path[:] = saved
    return mod
