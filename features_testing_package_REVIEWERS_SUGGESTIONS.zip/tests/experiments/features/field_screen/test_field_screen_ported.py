"""The old screen's tests, ported to the re-delivered modules, on the same synthetic data.

Ported from fraud/experiments/features/screen/tests/test_screen.py and test_stability.py (before the
reorganization waqas/v2/screen/tests/). Tests of the 26 October builders themselves and of the state test stay
with the old folder; the 26 October columns are built here through the resolver, unchanged."""

import numpy as np
import pandas as pd
import pytest

from field_screen_helpers import NF, load

START = "2024-10-01"
BASE = ["transaction_amt", "total_available_balance_amt", "remain_day_merchandise_lmt_amt", "external_1_scr",
        "transaction_type_xcd", "cardholder_present_xflg"]
CATS = ["transaction_type_xcd", "cardholder_present_xflg", "headroom_balance", "headroom_merch_lmt"]
FAST = {"n_estimators": 60, "max_depth": 4}

U = load("fsc_usefulness")
P = load("fsc_probes")
S = load("fsc_stability")
syn = load("fsc_synth")


@pytest.fixture(scope="module", autouse=True)
def _model():
    if not U.xgboost_available():
        U.use_sklearn_fallback()


def _oct26():
    lay = load("nf_layout", NF / "nf_layout.py")
    return lay.get("groups"), lay.get("features_new")


@pytest.fixture(scope="module")
def data():
    groups, fn = _oct26()
    df = syn.make(n_accounts=250, days=120, seed=3)
    g = groups.compute_groups(df, START)[["amt_over_balance", "amt_over_merch_lmt"]]
    return pd.concat([df, g, fn.compute_new(df, START, present_value="CAR1", absent_value="CAR0")], axis=1)


def test_weighted_ap_matches_sklearn():
    from sklearn.metrics import average_precision_score
    rng = np.random.default_rng(0)
    y = rng.random(3000) < 0.05
    s = np.round(rng.random(3000) + y * 0.3, 2)
    w = rng.poisson(1.0, 3000).astype(float)
    assert np.isclose(U.weighted_ap(y, s), average_precision_score(y, s))
    assert np.isclose(U.weighted_ap(y, s, w), average_precision_score(y, s, sample_weight=w))


def test_new_features_are_future_invariant():
    _, fn = _oct26()
    df = syn.make(n_accounts=40, days=40, seed=7)
    r = P.future_invariance(df, lambda d: fn.compute_new(d, START, present_value="CAR1", absent_value="CAR0"))
    assert r["ok"], r


def test_future_invariance_catches_next_row_leak():
    df = syn.make(n_accounts=40, days=40, seed=7)

    def leaky(d):
        s = d.sort_values(["Nmap_account_reference_xid", "transaction_dttm"])
        nxt = s.groupby("Nmap_account_reference_xid")["total_available_balance_amt"].shift(-1)
        return pd.DataFrame({"next_bal_drop": (s["total_available_balance_amt"] - nxt)}).reindex(d.index)

    assert not P.future_invariance(df, leaky)["ok"]


def test_folds_are_account_disjoint_and_stable():
    acc = np.array(["a", "b", "a", "c", "b"] * 20)
    f1, f2 = U.account_folds(acc, 5), U.account_folds(acc, 5)
    assert (f1 == f2).all()
    assert pd.DataFrame({"a": acc, "f": f1}).groupby("a")["f"].nunique().max() == 1


def test_screen_passes_planted_signal_and_rejects_noise(data):
    r = U.run_screen(data, BASE, ["amt_over_balance", "headroom_balance"], CATS, k=4, params=FAST, n_boot=200)
    assert r["passed"] and r["pooled_delta"] > 0
    d = data.copy()
    d["noise"] = np.random.default_rng(1).normal(size=len(d))
    assert not U.run_screen(d, BASE, ["noise"], CATS, k=4, params=FAST, n_boot=200)["passed"]


def test_label_shuffle_does_not_pass(data):
    assert P.label_shuffle(data, BASE, ["amt_over_balance"], CATS, k=4, params=FAST, n_boot=100)["ok"]


def test_single_feature_too_good_flag(data):
    d = data.copy()
    d["echo"] = d["frd_tag"] + np.random.default_rng(2).normal(0, 0.01, len(d))
    r = P.single_feature_ap(d, ["echo", "drain_24h"], base_ap=0.5)
    assert r["columns"]["echo"]["too_good"] and not r["ok"]


def test_train_negative_sampling_keeps_eval_rows(data):
    r = U.run_screen(data, BASE, ["drain_24h"], CATS, k=4, params=FAST, n_boot=50, train_neg_rate=0.3, permute=False)
    assert r["rows"] == len(data)


def test_by_group_split_reports_each_headroom_code(data):
    r = U.run_screen(data, BASE, ["amt_over_balance"], CATS, k=4, params=FAST, n_boot=20, permute=False,
                     by_group="headroom_balance")
    assert {g["group"] for g in r["by_group"]["rows"]} <= set(data["headroom_balance"].astype(str))


def test_final_rule_uses_the_larger_of_zero_and_the_floor():
    f = U.noise_floor({"pooled_delta": -0.003}, {42: 0.100, 43: 0.104, 44: 0.101})
    assert np.isclose(f["floor"], 0.004) and np.isclose(f["null_abs_delta"], 0.003)
    assert U.noise_floor({"pooled_delta": 0.0}, {42: 0.1})["floor"] == 0.0
    ok = {"passed": True, "delta_ci95_account_bootstrap": [0.005, 0.02]}
    assert U.final_decision(ok, f["floor"])
    assert not U.final_decision({**ok, "delta_ci95_account_bootstrap": [0.003, 0.02]}, f["floor"])
    assert not U.final_decision({**ok, "passed": False}, 0.0)


def test_base_refit_aps_changes_only_the_model_seed(data):
    aps = U.base_refit_aps(data, BASE, CATS, k=4, seed=42, model_seeds=(42, 43), params=FAST)
    r = U.run_screen(data, BASE, ["drain_24h"], CATS, k=4, seed=42, params=FAST, n_boot=10, permute=False)
    assert np.isclose(aps[42], r["pooled_ap_base"])


def _frame():
    t = pd.to_datetime(["2024-11-01 10:00:00", "2024-11-01 10:05:00", "2024-11-01 10:05:00",
                        "2024-11-01 11:00:00", "2024-11-01 09:00:00"])
    return pd.DataFrame({"Nmap_account_reference_xid": ["A", "A", "A", "A", "B"], "transaction_dttm": t,
                         "fi_transaction_id": ["1", "2", "3", "4", "5"],
                         "transaction_amt": [10.0, 20.0, 30.0, 40.0, 50.0],
                         "total_available_balance_amt": [100.0, 90.0, 90.0, 40.0, 500.0],
                         "transaction_type_xcd": ["P", "P", "Q", "P", "P"]}, index=[10, 11, 12, 13, 14])


def test_history_lite_is_strict_and_ordered():
    h = S.history_lite(_frame(), k=3)
    assert h.loc[10, "lag1_amt"] != h.loc[10, "lag1_amt"]
    assert h.loc[11, "lag1_amt"] == 10.0 and h.loc[12, "lag1_amt"] == 10.0
    assert list(h.loc[13, ["lag1_amt", "lag2_amt", "lag3_amt"]]) == [30.0, 20.0, 10.0]
    assert np.isnan(h.loc[14, "lag1_amt"])


def test_temporal_screen_passes_planted_signal_and_not_noise():
    df = syn.make(n_accounts=400, days=150, seed=9)
    df["ratio"] = df["transaction_amt"] / df["total_available_balance_amt"].where(df["total_available_balance_amt"] > 0)
    df["noise"] = np.random.default_rng(3).normal(size=len(df))
    cats = ["transaction_type_xcd", "cardholder_present_xflg"]
    r = S.temporal_screen(df, BASE, ["ratio"], "2025-01-15", cats, k=4, params=FAST, n_boot=200)
    assert r["passed"] and r["delta"] > 0, r
    assert not S.temporal_screen(df, BASE, ["noise"], "2025-01-15", cats, k=4, params=FAST, n_boot=200)["passed"]


def test_temporal_screen_trains_only_before_the_split():
    """The chronological screen: training targets before the split, test targets at or after it."""
    df = syn.make(n_accounts=200, days=120, seed=4)
    df["extra"] = np.random.default_rng(5).normal(size=len(df))
    seen = []
    orig = U._fit_predict

    def spy(X_tr, y_tr, X_te, params, seed):
        seen.append((X_tr.index, X_te.index))
        return orig(X_tr, y_tr, X_te, params, seed)

    U._fit_predict = spy
    try:
        S.temporal_screen(df, BASE, ["extra"], "2025-01-01", ["transaction_type_xcd", "cardholder_present_xflg"],
                          k=3, params={"n_estimators": 5}, n_boot=5)
    finally:
        U._fit_predict = orig
    t = pd.to_datetime(df["transaction_dttm"])
    assert seen
    for tr, te in seen:
        assert (t[tr] < pd.Timestamp("2025-01-01")).all() and (t[te] >= pd.Timestamp("2025-01-01")).all()


def test_psi_basic_cases():
    rng = np.random.default_rng(0)
    a, b = rng.normal(size=20000), rng.normal(size=20000)
    assert S.psi(a, b) < 0.01 and S.psi(a, b + 1.0) > 0.25
    c = b.copy()
    c[: len(c) // 2] = np.nan
    assert S.psi(a, c) > 0.25
    ref = pd.Series(["x"] * 900 + ["y"] * 100)
    assert S.psi(ref, pd.Series(["x"] * 900 + ["y"] * 100), categorical=True) < 1e-6
    assert S.psi(ref, pd.Series(["x"] * 500 + ["z"] * 500), categorical=True) > 0.25


def test_feature_drift_flags_only_the_shifted_column():
    rng = np.random.default_rng(1)
    tr = pd.DataFrame({"same": rng.normal(size=5000), "moved": rng.normal(size=5000)})
    jn = pd.DataFrame({"same": rng.normal(size=5000), "moved": rng.normal(size=5000) * 3})
    assert S.feature_drift(tr, jn, ["same", "moved"])["flagged"] == ["moved"]
