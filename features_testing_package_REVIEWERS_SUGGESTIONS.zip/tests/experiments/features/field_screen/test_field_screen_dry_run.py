"""The one-command dry run on a tiny synthetic world, and what its outputs prove.

Planted in the world (fsc_synth.PLANTED): a useful code, a useless number (with a June shift), a look-ahead
engineered field, honest engineered fields, and a field the checks stopped."""

import json
import os
import subprocess
import sys

import pandas as pd
import pytest

from field_screen_helpers import FS, ROOT, load, xgboost_available


@pytest.fixture(scope="module")
def dry(tmp_path_factory):
    out = tmp_path_factory.mktemp("dry") / "screen"
    run = load("fsc_run")
    rc = run.main(["--dry-run", "--out", str(out)])
    assert rc == 0
    return {"out": out, "res": json.loads((out / "screen.json").read_text()),
            "rank": pd.read_csv(out / "feature_rank.csv"), "summary": (out / "summary.txt").read_text()}


def test_one_command_dry_run(tmp_path):
    env = dict(os.environ, CUDA_VISIBLE_DEVICES="")
    p = subprocess.run([sys.executable, str(FS / "fsc_run.py"), "--dry-run", "--out", str(tmp_path / "s")],
                       cwd=str(tmp_path), env=env, capture_output=True, text=True, timeout=900)
    assert p.returncode == 0, p.stdout[-3000:] + p.stderr[-3000:]
    assert "CPU SCREEN" in p.stdout and "layout:" in p.stdout
    assert f"outputs: {(tmp_path / 's').resolve()}" in p.stdout  # the full output folder, findable from anywhere
    for f in ("screen.json", "feature_rank.csv", "cluster_rank.csv", "summary.txt"):
        assert (tmp_path / "s" / f).exists()


def test_summary_fits_one_screen(dry):
    lines = dry["summary"].rstrip("\n").split("\n")
    assert len(lines) <= 40 and max(len(x) for x in lines) <= 90
    assert "XGBoost's view, not the transformer's" in dry["summary"]


def test_feature_rank_columns_and_label(dry):
    run = load("fsc_run")
    fr = dry["rank"]
    assert list(fr.columns) == run.RANK_COLUMNS
    assert (fr["view"] == "XGBoost's view, not the transformer's").all()
    assert {"syn_useful_code", "syn_useless_num", "syn_cnt_24h", "transaction_amt", "month"} <= set(fr["feature"])


def test_planted_useful_ranks_high_and_useless_low(dry):
    fr = dry["rank"].set_index("feature")
    new = fr[fr["kind"].isin(["raw", "engineered"])]
    assert new.loc["syn_useful_code", "perm_rank_new"] <= 2
    assert new.loc["syn_useless_num", "perm_rank_new"] >= len(new) - 1
    assert abs(new.loc["syn_useless_num", "perm_ap_drop_mean"]) < 0.01
    assert new.loc["syn_useful_code", "perm_ap_drop_mean"] > 0.02
    if xgboost_available():
        assert new.loc["syn_useful_code", "shap_rank_new"] <= 3
        assert new.loc["syn_useless_num", "shap_rank_new"] > new.loc["syn_useful_code", "shap_rank_new"]


def test_leaky_lookahead_is_flagged(dry):
    res, fr = dry["res"], dry["rank"].set_index("feature")
    assert not res["future_invariance"]["ok"]
    assert set(res["future_invariance"]["changed_columns"]) == {"syn_lookahead_amt"}
    assert fr.loc["syn_lookahead_amt", "future_invariance"] == "failed"
    assert fr.loc["syn_cnt_24h", "future_invariance"] == "ok" and fr.loc["syn_prev_amt", "future_invariance"] == "ok"
    assert res["families"]["f15298"]["leaky"] and res["families"]["all_new"]["leaky"]
    assert not res["families"]["tfm"]["leaky"]
    assert "LEAKY: syn_lookahead_amt" in dry["summary"]


def test_map_drives_families_and_stopped_field_never_enters(dry):
    res = dry["res"]
    assert set(res["families"]["tfm"]["columns_used"]) == {"syn_useful_code", "syn_useless_num", "syn_profile_num"}
    assert set(res["families"]["f15298"]["columns_used"]) == {"syn_cnt_24h", "syn_prev_amt", "syn_lookahead_amt"}
    assert "syn_stopped_copy" not in res["new_fields"]
    assert {"field": "syn_stopped_copy", "reason": "STOP in the field checks"} in res["left_out"]
    assert "a3" in res["skipped_families"]
    assert len(res["base_columns_used"]) == 23 and "month" in res["base_columns_used"]


def test_noise_floor_and_rules(dry):
    res = dry["res"]
    assert set(res["base_ap_by_model_seed"]) == {"42", "43", "44"}
    assert res["noise_floor"]["floor"] >= 0
    for f in res["families"].values():
        assert "final_pass" in f and "label_shuffle" in f and "temporal" in f


def test_month_on_top_runs_on_folds_and_time_split(dry):
    mo = dry["res"]["month_on_top"]
    assert mo["folds"]["family"] == ["month"] and "month" not in mo["folds"]["base"]
    assert "time_split" in mo and "split_time" in mo["time_split"]
    assert "syn_useful_code" in mo["folds"]["base"]


def test_temporal_screen_is_chronological(dry):
    t = dry["res"]["families"]["tfm"]["temporal"]
    assert t["split_time"] == "2025-02-15" and t["test_rows"] > 0


def test_june_drift_flags_the_planted_shift(dry):
    d = dry["res"]["drift"]
    assert d["june_rows"] > 0 and "syn_useless_num" in d["flagged"]
    assert "syn_useful_code" not in d["flagged"]


def test_outputs_hold_full_numbers_and_no_redaction(dry):
    txt = (dry["out"] / "screen.json").read_text()
    assert "redact" not in txt.lower() and "mask" not in txt.lower()
