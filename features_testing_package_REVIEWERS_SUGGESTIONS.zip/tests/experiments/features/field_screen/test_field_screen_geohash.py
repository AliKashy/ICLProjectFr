"""The CPU screen builds a geohash(postal; country) row whose map model_type is blank as a category, as the recipe
module builds it (the module refuses any other model_type). Before, the screen's fallback took such a row as a
number, so the module refused it and the field was listed as not built. Synthetic data only, no network: the
geohash table is a small local file named by a test SETTINGS.yaml."""
import sys

import numpy as np
import pandas as pd
import pytest
import yaml

from field_screen_helpers import load

RECIPE = "geohash(merchant_postal_xcd; merchant_country_xcd)"
TABLE = "postal_code,country_code,geohash_value\n94108,840,9q8\n10001,840,dr5\n\"K1A 0B1\",124,f24\n"


@pytest.fixture()
def screen(tmp_path, monkeypatch):
    table = tmp_path / "geohash_mapping_table.csv"
    table.write_text(TABLE)
    folder = tmp_path / "settings"
    folder.mkdir()
    (folder / "SETTINGS.yaml").write_text(yaml.safe_dump(
        {"geohash_table": str(table), "base_config": "fraud/configs/sequential_hier_allpos.yaml"}))
    monkeypatch.setenv("NF_SETTINGS_DIR", str(folder))
    run = load("fsc_run")
    fn, _ = run.recipe_module()
    if fn is None:
        pytest.skip("nf_recipes.py not installed in this tree")
    recipes = sys.modules["nf_recipes"]
    recipes.clear_geohash_tables()
    yield run, fn, recipes
    recipes.clear_geohash_tables()


def frame(recipes):
    return pd.DataFrame({
        recipes.ACCOUNT: ["a", "a", "b", "c", "d"],
        recipes.TIME: pd.to_datetime([f"2025-01-0{d} 10:00" for d in range(1, 6)]),
        recipes.TIE: [1, 2, 3, 4, 5],
        "merchant_postal_xcd": ["94108", "10001  ", None, "99999", "K1A 0B1"],
        "merchant_country_xcd": ["840", "840", "840", "840", "124"],
    })


def test_code_and_geohash_recipes_are_categories():
    run = load("fsc_run")
    assert run.category_recipe(RECIPE) and run.category_recipe("  code(merchant_category_xcd)")
    for other in ("count(24h)", "days_before(card_issue_dt)", "raw", "", None):
        assert not run.category_recipe(other), other


def test_a_geohash_row_with_a_blank_model_type_is_built_as_a_category(screen):
    run, fn, recipes = screen
    df = frame(recipes)
    one = fn(df, RECIPE, "2024-10-01", None)          # the map's model_type is blank
    got = [None if (x is None or (isinstance(x, float) and np.isnan(x))) else x for x in one]
    assert got == ["9q8", "dr5", None, "OTHER", "f24"]   # trailing spaces removed; no match gives OTHER
    built, failed = fn.batch(df, [("merchant_geohash_new", RECIPE, None)], "2024-10-01")
    assert failed == {}
    assert list(built["merchant_geohash_new"].fillna("missing")) == ["9q8", "dr5", "missing", "OTHER", "f24"]
    # the same values as the recipe module's own categorical build
    own, _ = recipes.build_columns(df, [("g", RECIPE, "categorical")], "2024-10-01")
    assert list(own["g"].fillna("missing")) == list(built["merchant_geohash_new"].fillna("missing"))


def test_a_geohash_row_said_to_be_a_number_is_still_refused_by_the_recipe_module(screen):
    run, fn, recipes = screen
    built, failed = fn.batch(frame(recipes), [("g", RECIPE, "continuous")], "2024-10-01")
    assert "g" in failed and "categor" in failed["g"]
