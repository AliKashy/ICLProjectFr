"""The future-invariance probe is cut by each recipe's own history key, and the June drift cut resamples whole
accounts. Synthetic data only.

1. A customer field (prev(transaction_amt; key=syn_customer)) on customers that hold two accounts: an account cut
   moves its value on rows kept before the cut (a later row of the customer's other account is perturbed), so an
   honest field fails. The screen cuts it per customer and it passes; the customer key itself is not perturbed.
2. A field whose value is fixed per account, and a June month of few accounts: resampling rows gives a cut far
   too low (the honest field is flagged nearly always); resampling whole accounts does not. With one row per
   account the two cuts agree.
"""

import argparse
import json

import numpy as np
import pandas as pd
import pytest

from field_screen_helpers import NF, load

FAST = json.dumps({"n_estimators": 10, "max_depth": 2})
ACC, TIME = "Nmap_account_reference_xid", "transaction_dttm"
CUST = "syn_customer"
CUST_PREV = f"prev(transaction_amt; key={CUST}; within=all)"


def _run_mod():
    run = load("fsc_run")
    U = run.modules()["U"]
    if not U.xgboost_available():
        U.use_sklearn_fallback()
    return run


def _recipes():
    return load("nf_recipes", NF / "nf_recipes.py")


def _customers(d, k):
    """Two accounts of file `k` per customer, in account order."""
    accs = sorted(d[ACC].unique())
    owner = {a: f"C{k}{i // 2:05d}" for i, a in enumerate(accs)}
    return d[ACC].map(owner)


def _builder(df, recipe, extract_start, model_type=None):
    """The synthetic world's recipes, and the recipe module's for a recipe with a history key."""
    if "key=" in recipe:
        frame, _ = _recipes().build_columns(df, [("v", recipe, model_type or "continuous")], extract_start)
        return frame["v"]
    return load("fsc_synth").synth_builder(df, recipe, extract_start, model_type)


def test_history_key_reads_the_recipe():
    run = _run_mod()
    parse = run.recipe_parser()
    assert parse is not None
    assert run.history_key({"recipe": CUST_PREV}, parse) == CUST
    assert run.history_key({"recipe": "prev(transaction_amt)"}, parse) == ACC
    assert run.history_key({"recipe": "raw"}, parse) == ACC
    assert run.history_key({"recipe": "not_a_recipe(x"}, parse) == ACC
    assert run.history_key({"recipe": CUST_PREV}, None) == ACC


def test_an_honest_customer_field_fails_an_account_cut_and_passes_the_customer_cut(tmp_path):
    run = _run_mod()
    P = run.modules()["P"]
    syn = load("fsc_synth")
    com = load("nf_common", NF / "nf_common.py")
    w = syn.world(tmp_path / "w", n_accounts=40, june_accounts=10, field_map_columns=com.FIELD_MAP_COLUMNS)
    for k, f in enumerate(w["files"]):
        d = pd.read_parquet(f)
        d[CUST] = _customers(d, k)
        d.to_parquet(f)
    df = pd.read_parquet(w["files"][0])
    assert (df.groupby(CUST)[ACC].nunique() == 2).all()

    def fn(d):
        return pd.DataFrame({"v": _builder(d, CUST_PREV, w["extract_start"]).to_numpy()}, index=d.index)

    old = P.future_invariance(df, fn, account=ACC, numeric_cols=["transaction_amt"], shuffle_cols=[], seed=42)
    assert not old["ok"] and old["changed_columns"]["v"] > 0  # the account cut moves an honest customer field
    new = P.future_invariance(df, fn, account=CUST, numeric_cols=["transaction_amt"], shuffle_cols=[], seed=42)
    assert new["ok"], new

    # the screen: one probe per history key, the customer key never perturbed
    m = pd.read_csv(w["map"], dtype=str, keep_default_na=False)
    row = {c: "" for c in m.columns}
    row.update({"name": "syn_cust_prev", "group": "f15298", "kind": "engineered", "recipe": CUST_PREV,
                "source_columns": f"transaction_amt;{CUST}", "model_type": "continuous", "definition_version": "1",
                "excluded_by_sumegha": "no", "feasible_in_production": "yes", "list_status": "UNCONFIRMED"})
    pd.concat([m, pd.DataFrame([row], columns=m.columns)], ignore_index=True).to_csv(w["map"], index=False)
    st = pd.read_csv(w["status"], dtype=str, keep_default_na=False)
    st = pd.concat([st, pd.DataFrame([{"field": "syn_cust_prev", "result": "PASS", "reasons": ""}])],
                   ignore_index=True).fillna("")
    st.to_csv(w["status"], index=False)
    out = tmp_path / "o"
    rc = run.main(["--map", w["map"], "--status", w["status"], "--files", *w["files"], "--extract-start",
                   w["extract_start"], "--k", "3", "--n-boot", "20", "--extra-seeds", "43", "--params-json", FAST,
                   "--min-free-gb", "0", "--temporal-split", "none", "--no-label-shuffle", "--families", "all_new",
                   "--out", str(out)], recipe_fn=_builder)
    assert rc == 0
    fi = json.loads((out / "screen.json").read_text())["future_invariance"]
    assert fi["cut_by"][CUST] == ["syn_cust_prev"]
    assert "syn_prev_amt" in fi["cut_by"][ACC] and "syn_lookahead_amt" in fi["cut_by"][ACC]
    assert "syn_cust_prev" in fi["probed"] and "syn_cust_prev" not in fi["changed_columns"]
    assert "syn_lookahead_amt" in fi["changed_columns"]  # the planted look-ahead is still caught
    assert CUST not in fi["perturbed_codes"] + fi["perturbed_numeric"]


def _clustered(rng, n_acc, rows, first):
    """`rows` rows per account, the value fixed per account (a profile field), every account honest."""
    acc = np.repeat([f"A{first + i:05d}" for i in range(n_acc)], rows)
    val = np.repeat(rng.normal(0, 1, n_acc), rows)
    return pd.Series(val), acc


def test_the_drift_cut_resamples_whole_accounts():
    run = _run_mod()
    S = run.modules()["S"]
    rng = np.random.default_rng(5)
    ref, ref_acc = _clustered(rng, 400, 20, 0)
    by_rows = by_acc = 0
    for i in range(30):
        june, june_acc = _clustered(rng, 8, 20, 10**4)
        obs = S.psi(ref, june)
        q_rows = run.drift_null(ref, len(june), False, seed=[i, 1])
        q_acc = run.drift_null(ref, len(june), False, seed=[i, 1], ref_accounts=ref_acc)
        by_rows += obs > max(0.25, q_rows)
        by_acc += obs > max(0.25, q_acc)
    assert by_rows >= 27 and by_acc <= 4, (by_rows, by_acc)
    # one row per account: whole accounts are rows, and the two cuts agree closely
    one, one_acc = pd.Series(rng.normal(0, 1, 5000)), np.array([f"B{i}" for i in range(5000)])
    a = run.drift_null(one, 200, False, seed=3)
    b = run.drift_null(one, 200, False, seed=3, ref_accounts=one_acc)
    assert abs(a - b) < 0.02, (a, b)
    # codes: repeatable, and a reference with accounts of mismatched length is refused
    codes = pd.Series(np.repeat(list("abcdefgh"), 50), dtype=object)
    cacc = np.repeat([f"K{i}" for i in range(100)], 4)
    assert run.drift_null(codes, 40, True, seed=1, ref_accounts=cacc) == \
        run.drift_null(codes, 40, True, seed=1, ref_accounts=cacc)
    with pytest.raises(ValueError):
        run.drift_null(codes, 40, True, seed=1, ref_accounts=cacc[:-1])
    # a June side larger than the first guess of accounts still gets its rows
    assert run.drift_null(codes, 5000, True, seed=1, ref_accounts=cacc) is not None


def test_june_drift_passes_the_accounts_of_both_sides():
    run = _run_mod()
    S = run.modules()["S"]
    rng = np.random.default_rng(9)
    rows = []
    for i in range(300):
        t = pd.Timestamp("2025-04-01") + pd.to_timedelta(np.sort(rng.uniform(0, 29 * 86400, 20)).round(), unit="s")
        rows.append(pd.DataFrame({ACC: f"R{i:04d}", TIME: t, "syn_profile": rng.normal()}))
    df = pd.concat(rows, ignore_index=True)
    df["fi_transaction_id"] = [f"T{i:07d}" for i in range(len(df))]
    ev = []
    for i in range(6):
        t = pd.Timestamp("2025-06-01") + pd.to_timedelta(np.sort(rng.uniform(0, 29 * 86400, 20)).round(), unit="s")
        ev.append(pd.DataFrame({ACC: f"J{i:04d}", TIME: t, "syn_profile": rng.normal()}))
    ev = pd.concat(ev, ignore_index=True)
    ev["fi_transaction_id"] = [f"E{i:07d}" for i in range(len(ev))]
    row = {"name": "syn_profile", "recipe": "raw", "source_columns": "syn_profile", "model_type": "continuous"}
    a = argparse.Namespace(drift_month="2025-06", drift_extract_start="2025-05-01", drift_threshold=0.25,
                           drift_min_rows=100, seed=42)
    res = run.june_drift(a, df, ev, [row], {"syn_profile": df["syn_profile"].to_numpy()},
                         {"syn_profile": {"model_type": "continuous"}}, run.Builder(None), S)
    c = res["columns"]["syn_profile"]
    assert c["null_resamples"] == "accounts" and c["june_accounts"] == 6 and c["reference_accounts"] == 300
    assert c["psi"] > 0.25 and not c["flag"] and c["cut"] > c["psi"]  # six honest accounts: not flagged
    assert "whole accounts" in res["cut_rule"]
