"""The re-delivered screen keeps the old screen's logic: the rule texts and every copied function are equal."""

import ast

import pytest

from field_screen_helpers import FS, load, old_screen_file


def _functions(path, skip_doc=True):
    tree = ast.parse(path.read_text())
    out = {}
    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            if skip_doc and node.body and isinstance(node.body[0], ast.Expr) and isinstance(
                    getattr(node.body[0], "value", None), ast.Constant):
                node.body = node.body[1:]
            out[node.name] = ast.dump(node)
        if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name):
            out[node.targets[0].id] = ast.dump(node.value)
    return out


@pytest.mark.parametrize("old,new", [("usefulness.py", "fsc_usefulness.py"), ("probes.py", "fsc_probes.py"),
                                     ("stability.py", "fsc_stability.py"), ("synth.py", "fsc_synth.py")])
def test_copied_functions_are_unchanged(old, new):
    a, b = _functions(old_screen_file(old)), _functions(FS / new)
    for n in a:
        assert n in b, n
        assert a[n] == b[n], n


def test_rule_texts_equal_the_old_screen():
    old = load("old_usefulness_for_rules", old_screen_file("usefulness.py"))
    new = load("fsc_usefulness")
    assert new.PASS_RULE == old.PASS_RULE and new.FINAL_RULE == old.FINAL_RULE
    assert new.DEFAULT_PARAMS == old.DEFAULT_PARAMS


def test_no_feature_name_is_hard_coded():
    """The screen's code names no candidate field: the list comes from the map."""
    words = ["cprsrvc", "cprcust", "cpracct", "cprc002", "user_data_", "token_requestor", "avs_response",
             "vaa", "falcon", "predecline", "syn_useful", "syn_useless"]
    for f in ("fsc_run.py", "fsc_usefulness.py", "fsc_probes.py", "fsc_stability.py"):
        text = (FS / f).read_text().lower()
        for w in words:
            assert w not in text, (f, w)
