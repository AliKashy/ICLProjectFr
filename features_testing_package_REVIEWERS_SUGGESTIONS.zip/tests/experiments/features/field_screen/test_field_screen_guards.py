"""Refusals: the cost guard, a map with no field status, and xgboost outside the dry run."""

import json

import pytest

from field_screen_helpers import load


def _world(tmp_path):
    syn = load("fsc_synth")
    com = load("nf_common", load("fsc_run").NF_DIR / "nf_common.py")
    return syn.world(tmp_path / "w", n_accounts=120, june_accounts=30, field_map_columns=com.FIELD_MAP_COLUMNS)


def _args(w, out, extra=()):
    return ["--map", w["map"], "--status", w["status"], "--files", *w["files"], "--extract-start", w["extract_start"],
            "--k", "3", "--n-boot", "20", "--params-json", json.dumps({"n_estimators": 10, "max_depth": 2}),
            "--min-free-gb", "0", "--out", str(out), *extra]


def _recipes():
    return load("fsc_synth").synth_builder


def test_cost_guard_refuses_above_max_hours(tmp_path):
    run = load("fsc_run")
    if not run.modules()["U"].xgboost_available():
        run.modules()["U"].use_sklearn_fallback()
    w = _world(tmp_path)
    rc = run.main(_args(w, tmp_path / "o", ["--max-hours", "0.0000001"]), recipe_fn=_recipes())
    assert rc == 4
    assert (tmp_path / "o" / "cost.json").exists() and not (tmp_path / "o" / "screen.json").exists()


def test_refuses_without_field_status(tmp_path):
    run = load("fsc_run")
    w = _world(tmp_path)
    args = _args(w, tmp_path / "o")
    i = args.index("--status")
    del args[i:i + 2]
    assert run.main(args, recipe_fn=_recipes()) == 4


def test_select_fields_reasons():
    run = load("fsc_run")
    import pandas as pd
    fmap = pd.DataFrame([{"name": n, "excluded_by_sumegha": e, "left_out_reason": lo, "check_result": "", "check_reasons": ""}
                         for n, e, lo in [("a", "no", ""), ("b", "yes", ""), ("c", "no", "uses an outcome"),
                                          ("d", "no", ""), ("e", "no", ""), ("f", "no", "")]])
    status = {"a": ("PASS", ""), "b": ("PASS", ""), "c": ("PASS", ""), "d": ("WAIT", "hold"), "e": ("FLAG", "x")}
    enter, left = run.select_fields(fmap, status, allow_unchecked=False)
    assert [r["name"] for r in enter] == ["a", "e"]
    reasons = dict(left)
    assert reasons["b"] == "excluded_by_sumegha" and reasons["c"].startswith("left_out_reason")
    assert reasons["d"] == "WAIT in the field checks" and reasons["f"].startswith("not checked")
    enter2, _ = run.select_fields(fmap, status, allow_unchecked=True)
    assert [r["name"] for r in enter2] == ["a", "e", "f"]


def test_as_code_avoids_the_float_key_trap():
    import numpy as np
    import pandas as pd
    run = load("fsc_run")
    a = run.as_code(pd.Series([1.0, np.nan, 3.0]))
    b = run.as_code(pd.Series([1, 2, 3]))
    assert a.tolist()[0] == "1" and pd.isna(a.tolist()[1]) and b.tolist() == ["1", "2", "3"]


def test_memory_guard_refuses_below_the_free_memory_level(tmp_path):
    run = load("fsc_run")
    w = _world(tmp_path)
    rc = run.main(_args(w, tmp_path / "o", ["--min-free-gb", "1000000"]), recipe_fn=_recipes())
    if run.resource_limits()["free_gib"] is None:
        pytest.skip("free memory cannot be read here")
    assert rc == 4
    m = json.loads((tmp_path / "o" / "memory.json").read_text())
    assert m["refused"] and m["rows"] > 0 and not (tmp_path / "o" / "screen.json").exists()


def test_not_in_owner_list_rows_never_enter():
    import pandas as pd
    run = load("fsc_run")
    fmap = pd.DataFrame([{"name": "a", "list_status": "NOT_IN_OWNER_LIST", "excluded_by_sumegha": "no",
                          "left_out_reason": "", "check_result": "PASS", "check_reasons": ""}])
    enter, left = run.select_fields(fmap, {}, allow_unchecked=True)
    assert not enter and left == [("a", "not in the owner's list")]
