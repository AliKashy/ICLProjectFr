"""Regression tests for the independent check of the screen in part B (synthetic data only, no network).

1. A partial last training month is not the June reference. A recipe with no lookback limit (since_last within=all)
   sees less history on a few days of it than June rows do, so the month before it is used instead.
2. The summary's line for the months not used as the reference fits the 90-character screen. The full sentence
   stays in screen.json.
3. An a3 recipe reads every input of the 26 October builders, though the map lists two of them. The recipe module
   refuses an a3 recipe when one input is missing, so the screen reads them all, with or without --oct26."""

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from field_screen_helpers import NF, load

FAST = json.dumps({"n_estimators": 10, "max_depth": 2})
SINCE_ALL = "since_last(days; within=all)"
ACCOUNT, TIME = "Nmap_account_reference_xid", "transaction_dttm"


def _run_mod():
    run = load("fsc_run")
    U = run.modules()["U"]
    if not U.xgboost_available():
        U.use_sklearn_fallback()
    return run


def _sparse(rng, n_acc, start, days, first):
    """Accounts with few rows (0.02 to 0.08 a day), so the days since the previous row depend on how much history
    the frame holds."""
    rows = []
    for a in range(n_acc):
        n = rng.poisson(rng.uniform(0.02, 0.08) * days)
        ts = np.sort(rng.uniform(0, days * 86400, n)).round()
        rows.append(pd.DataFrame({ACCOUNT: f"P{first + a:06d}", TIME: pd.Timestamp(start) + pd.to_timedelta(ts, unit="s")}))
    df = pd.concat(rows, ignore_index=True)
    df["fi_transaction_id"] = [f"X{first}{i:08d}" for i in range(len(df))]
    df["transaction_amt"] = 1.0
    return df


def _since_all(df, recipe, extract_start, model_type=None):
    """since_last(days; within=all) as a stand-in: days since the account's previous row in the frame."""
    t = pd.to_datetime(df[TIME])
    d = pd.DataFrame({"a": df[ACCOUNT].to_numpy(), "t": t.to_numpy()}, index=df.index).sort_values(["a", "t"],
                                                                                                 kind="mergesort")
    return ((d["t"] - d.groupby("a")["t"].shift(1)).dt.total_seconds() / 86400).reindex(df.index)


# ---------------------------------------------------------------- 1. a partial last month

@pytest.mark.parametrize("engine", ["stand-in", "nf_recipes"])
def test_a_partial_last_month_is_not_the_june_reference(engine):
    run = _run_mod()
    S = run.modules()["S"]
    if engine == "nf_recipes":
        fn, label = run.recipe_module()
        if fn is None:
            pytest.skip("nf_recipes.py not installed in this tree")
    else:
        fn, label = _since_all, "stand-in"
    rng = np.random.default_rng(6)
    df = _sparse(rng, 3000, "2024-10-01", 213, 0)  # 1 October 2024 to 1 May 2025: May holds one day
    ev = _sparse(rng, 3000, "2025-05-01", 61, 10**5)  # the June files start on 1 May 2025
    t = pd.to_datetime(df[TIME])
    may = int((t.dt.to_period("M") == pd.Period("2025-05", "M")).sum())
    april = int((t.dt.to_period("M") == pd.Period("2025-04", "M")).sum())
    assert str(t.max().date()) == "2025-05-01" and may >= 100  # enough rows: only the calendar is short
    row = {"name": "eng_since_all", "group": "a3", "kind": "engineered", "recipe": SINCE_ALL,
           "source_columns": TIME, "model_type": "continuous"}
    new = {"eng_since_all": run._typed(fn(df, SINCE_ALL, "2024-10-01", "continuous"), "continuous").to_numpy()}
    a = argparse.Namespace(drift_month="2025-06", drift_extract_start="2025-05-01", drift_threshold=0.25,
                           drift_min_rows=100, seed=42)
    res = run.june_drift(a, df, ev, [row], new, {"eng_since_all": {"model_type": "continuous"}},
                         run.Builder(None, fn, label), S)
    assert res["reference_month"] == "2025-04" and res["reference_extract_start"] == "2025-03-01"
    assert res["reference_rows"] == april
    assert res["reference_tried"][0] == {"month": "2025-05", "rows": may, "ends": "2025-05-01"}
    assert res["reference_note"] == (f"2025-05 is partial (the training rows end on 2025-05-01): the reference is "
                                     f"2025-04 ({april} rows)")
    col = res["columns"]["eng_since_all"]
    assert col["reference"].startswith("2025-04 rebuilt from 2025-03-01") and col["psi"] < 0.1 and not col["flag"]
    # the evidence: the one-day May reference, rebuilt from 1 April as before, flags this honest field
    sub = df[(t >= "2025-04-01").to_numpy()]
    in_may = (pd.to_datetime(sub[TIME]).dt.to_period("M") == pd.Period("2025-05", "M")).to_numpy()
    old = pd.to_numeric(fn(sub, SINCE_ALL, "2025-04-01", "continuous"), errors="coerce").to_numpy()[in_may]
    in_june = (pd.to_datetime(ev[TIME]).dt.to_period("M") == pd.Period("2025-06", "M")).to_numpy()
    jv = pd.to_numeric(fn(ev, SINCE_ALL, "2025-05-01", "continuous"), errors="coerce").to_numpy()[in_june]
    assert len(old) == may and S.psi(old, jv) > 0.25


def test_a_month_the_rows_reach_to_its_last_day_stays_the_reference():
    run = load("fsc_run")
    t = pd.Series(pd.to_datetime(["2025-04-02 10:00"] * 150 + ["2025-05-03 08:00"] * 150))
    for last, month in (("2025-05-31 00:00:00", "2025-05"), ("2025-05-31 23:59:58", "2025-05"),
                        ("2025-05-30 23:59:59", "2025-04")):
        c = run.reference_choice(pd.DataFrame({TIME: pd.concat([t, pd.Series(pd.to_datetime([last]))])}), 100)
        assert str(c["month"]) == month, last
    c = run.reference_choice(pd.DataFrame({TIME: pd.concat([t, pd.Series(pd.to_datetime(["2025-05-30 23:59:59"]))])}),
                             100)
    assert c["tried"] == [{"month": "2025-05", "rows": 151, "ends": "2025-05-30"},
                          {"month": "2025-04", "rows": 150, "ends": None}]
    # times with a zone are read as UTC wall time, as everywhere in the screen
    z = pd.DataFrame({TIME: pd.to_datetime(["2025-04-02 10:00"] * 150 + ["2025-05-31 20:30"] * 150).tz_localize("UTC")})
    assert str(run.reference_choice(z, 100)["month"]) == "2025-05"
    assert run.reference_choice(pd.DataFrame({TIME: pd.to_datetime([])}), 100)["note"] == (
        "no training rows: the reference is the whole training stream")


# ---------------------------------------------------------------- 2. the summary line

def _drift(ref, tried, note, min_rows=100):
    return {"june_rows": 500, "month": "2025-06", "reference_month": ref, "reference_rows": 793,
            "reference_extract_start": "2025-03-01", "reference_min_rows": min_rows, "reference_tried": tried,
            "reference_note": note, "threshold": 0.25, "flagged": [], "skipped": {}, "columns": {}}


def _summary_lines(d):
    run = load("fsc_run")
    com = load("nf_common", NF / "nf_common.py")
    fr = pd.DataFrame({"feature": ["x"], "in_arm": "yes", "shap_rank_new": [1.0], "perm_rank_new": [1.0],
                       "shap_mean_abs": [0.1], "perm_ap_drop_mean": [0.0], "psi_june": [0.0],
                       "unflagged_shap_rank_new": [np.nan], "unflagged_perm_rank_new": [np.nan], "note": [""]})
    out = {"view": "XGBoost's view, not the transformer's", "layout": "x", "map": "m", "list_status": "UNCONFIRMED",
           "status": "s", "model": "xgboost", "rows": 1, "frauds": 1, "accounts": 1, "files": 1,
           "base_columns_used": [], "missing_base_columns": [], "new_fields": {"x": {}}, "not_built": [],
           "left_out": [], "recipes": "r", "noise_floor": {"floor": 0, "null_abs_delta": 0, "refit_spread": 0},
           "families": {}, "skipped_families": {}, "temporal_split": None,
           "future_invariance": {"ok": True, "probed": [], "not_run": [], "history_fields": 0}, "drift": d}
    return run.summary(out, fr, com, Path("screen")).split("\n")


def test_the_months_not_used_fit_one_summary_line():
    run = load("fsc_run")
    rows = _drift("2025-04", [{"month": "2025-05", "rows": 20, "ends": None},
                              {"month": "2025-04", "rows": 793, "ends": None}],
                  "2025-05 has 20 rows, below --drift-min-rows 100: the reference is 2025-04 (793 rows)")
    part = _drift("2025-04", [{"month": "2025-05", "rows": 3005, "ends": "2025-05-18"},
                              {"month": "2025-04", "rows": 4807, "ends": None}],
                  "2025-05 is partial (the training rows end on 2025-05-18): the reference is 2025-04 (4807 rows)")
    both = _drift("whole training stream", [{"month": "2025-05", "rows": 25, "ends": "2025-05-02"},
                                            {"month": "2025-04", "rows": 40, "ends": None}],
                  "2025-05 is partial (the training rows end on 2025-05-02) and has 25 rows; 2025-04 has 40 rows, "
                  "below --drift-min-rows 100: the reference is the whole training stream")
    big = _drift("whole training stream", [{"month": "2025-05", "rows": 99999, "ends": "2025-05-02"},
                                           {"month": "2025-04", "rows": 88888, "ends": None}],
                 "2025-05 is partial (the training rows end on 2025-05-02) and has 99999 rows; 2025-04 has 88888 "
                 "rows, below --drift-min-rows 100000: the reference is the whole training stream", min_rows=100000)
    assert len(both["reference_note"]) > 90  # the full sentence (screen.json) does not fit a line of the screen
    for d in (rows, part, both, big):  # the summary prints a short line in full; no line is cut at 90 characters
        lines = _summary_lines(d)
        assert max(len(x) for x in lines) <= 90 and not any(len(x) == 90 and x.endswith("...") for x in lines)
        assert not any(d["reference_note"] in x for x in lines) and run.reference_skips(d) in lines
    assert run.reference_skips(rows) == "  not used: 2025-05 (20 rows); minimum 100 rows"
    assert run.reference_skips(part) == "  not used: 2025-05 (partial, to 18 May)"
    assert run.reference_skips(both) == ("  not used: 2025-05 (partial, to 2 May, 25 rows), 2025-04 (40 rows); "
                                         "minimum 100 rows")
    assert run.reference_skips(big) == "  not used: 2025-05, 2025-04 (partial, or below --drift-min-rows 100000)"
    assert run.reference_skips(_drift("2025-05", [{"month": "2025-05", "rows": 500, "ends": None}], "")) == ""
    assert run.reference_skips({"reference_month": "2025-04"}) == ""  # an older screen.json: no line


# ---------------------------------------------------------------- 3. what an a3 recipe reads

def test_an_a3_row_reads_every_26_october_input(tmp_path, monkeypatch):
    run = _run_mod()
    rec = NF / "nf_recipes.py"
    if not rec.exists():
        pytest.skip("nf_recipes.py not installed in this tree")
    nr = load("nf_recipes", rec)
    two = "transaction_amt;total_available_balance_amt"
    # the screen, no --oct26: before, both rows failed with "source column merchant_category_xcd is not in the file"
    syn = load("fsc_synth")
    com = load("nf_common", NF / "nf_common.py")
    w = syn.world(tmp_path / "w", n_accounts=40, june_accounts=10, field_map_columns=com.FIELD_MAP_COLUMNS)
    rng = np.random.default_rng(2)
    for f in w["files"]:
        d = pd.read_parquet(f)
        d["merchant_category_xcd"] = rng.choice(["M1", "M2", "M3", "M4"], len(d))
        d[TIME] = pd.to_datetime(d[TIME]).dt.floor("s")  # the 26 October builders need whole seconds (as the pod's)
        d.to_parquet(f)
    m = pd.read_csv(w["map"], dtype=str, keep_default_na=False)
    m = m[m["kind"] == "raw"]
    extra = []
    for name in ("drain_24h", "amt_over_balance"):
        r = {c: "" for c in m.columns}
        r.update({"name": name, "group": "a3", "kind": "engineered", "recipe": f"a3({name})", "source_columns": two,
                  "model_type": "continuous", "definition_version": "1", "excluded_by_sumegha": "no",
                  "feasible_in_production": "yes", "list_status": "UNCONFIRMED"})
        extra.append(r)
    pd.concat([m, pd.DataFrame(extra, columns=m.columns)], ignore_index=True).to_csv(w["map"], index=False)
    st = pd.read_csv(w["status"], dtype=str, keep_default_na=False)
    pd.concat([st, pd.DataFrame([{"field": n, "result": "PASS", "reasons": "synthetic"} for n in
                                 ("drain_24h", "amt_over_balance")])], ignore_index=True).to_csv(w["status"], index=False)
    seen = []
    real = run.read_frame

    def spy(path, fs, columns, lay):
        seen.append(list(columns))
        return real(path, fs, columns, lay)

    monkeypatch.setattr(run, "read_frame", spy)
    out = tmp_path / "o"
    rc = run.main(["--map", w["map"], "--status", w["status"], "--files", *w["files"], "--extract-start",
                   w["extract_start"], "--k", "3", "--n-boot", "20", "--extra-seeds", "43", "--params-json", FAST,
                   "--min-free-gb", "0", "--temporal-split", "none", "--no-label-shuffle", "--families", "all_new",
                   "--out", str(out)])
    assert rc == 0
    res = json.loads((out / "screen.json").read_text())
    for name in ("drain_24h", "amt_over_balance"):
        assert res["new_fields"][name]["how"] == "built (nf_recipes.build_columns)", res["not_built"]
    assert not res["not_built"]
    assert seen and all("merchant_category_xcd" in c for c in seen)
    # the columns read for one row: the map's, and every column the recipe module needs to build its recipe
    cols = run.read_columns(pd.Series({"name": "drain_24h", "recipe": "a3(drain_24h)", "source_columns": two}), nr.parse)
    assert set(nr.A3_SOURCES) <= set(cols) and "merchant_category_xcd" in cols
    assert run.read_columns(pd.Series({"recipe": "lookahead(x)", "source_columns": "x"}), nr.parse) == ["x"]
    assert run.read_columns(pd.Series({"recipe": "raw", "source_columns": "c"}), nr.parse) == ["c"]
    assert run.read_columns(pd.Series({"recipe": "mean(24h; value=v)", "source_columns": ""}), nr.parse) == ["v"]
