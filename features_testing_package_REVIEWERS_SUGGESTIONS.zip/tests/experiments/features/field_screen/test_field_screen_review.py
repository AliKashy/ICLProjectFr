"""Regression tests for the adversarial self-check's findings (synthetic data only)."""

import json

import numpy as np
import pandas as pd
import pytest

from field_screen_helpers import NF, load

FAST = json.dumps({"n_estimators": 10, "max_depth": 2})


def _world(tmp_path, **kw):
    syn = load("fsc_synth")
    com = load("nf_common", NF / "nf_common.py")
    return syn.world(tmp_path / "w", n_accounts=150, june_accounts=40, field_map_columns=com.FIELD_MAP_COLUMNS, **kw)


def _run(w, out, extra=(), recipe_fn="synth", june=True):
    run = load("fsc_run")
    U = run.modules()["U"]
    if not U.xgboost_available():
        U.use_sklearn_fallback()
    args = ["--map", w["map"], "--status", w["status"], "--files", *w["files"], "--extract-start", w["extract_start"],
            "--k", "3", "--n-boot", "20", "--extra-seeds", "43", "--params-json", FAST, "--min-free-gb", "0",
            "--temporal-split", w["temporal_split"], "--no-label-shuffle", "--out", str(out), *extra]
    if june:
        args += ["--drift-files", *w["june"], "--drift-extract-start", w["june_extract_start"]]
    fn = load("fsc_synth").synth_builder if recipe_fn == "synth" else recipe_fn
    rc = run.main(args, recipe_fn=fn) if fn is not None else run.main(args)
    return rc, (json.loads((out / "screen.json").read_text()) if (out / "screen.json").exists() else None)


def _edit_map(w, fn):
    m = pd.read_csv(w["map"], dtype=str, keep_default_na=False)
    m = fn(m)
    m.to_csv(w["map"], index=False)
    st = pd.read_csv(w["status"], dtype=str, keep_default_na=False)
    extra = [n for n in m["name"] if n not in set(st["field"])]
    st = pd.concat([st, pd.DataFrame({"field": extra, "result": "PASS", "reasons": "synthetic"})], ignore_index=True)
    st.to_csv(w["status"], index=False)


def test_as_code_mixed_files_and_big_numbers():
    run = load("fsc_run")
    mixed = pd.Series([1.0, np.nan, "2", "3.0", 2, 1e19], dtype=object)
    out = run.as_code(mixed).tolist()
    assert out[0] == "1" and pd.isna(out[1]) and out[2:5] == ["2", "3", "2"]
    assert out[5] == "10000000000000000000"
    assert run.as_code(pd.Series(["A", None, "b "])).tolist()[::2] == ["A", "b"]


def test_stored_engineered_fields_without_recipes_are_not_shown_ok(tmp_path):
    """A look-ahead stored in the files, with no recipe module: never reported as ok."""
    w = _world(tmp_path)
    syn = load("fsc_synth")
    for f in w["files"]:
        d = pd.read_parquet(f)
        for n, rec in (("syn_cnt_24h", "count(24h)"), ("syn_lookahead_amt", "lookahead(transaction_amt)")):
            d[n] = syn.synth_builder(d, rec, w["extract_start"]).to_numpy()
        d.to_parquet(f)
    _edit_map(w, lambda m: m[~m["name"].isin(["syn_prev_amt"])])
    rc, res = _run(w, tmp_path / "o", recipe_fn=None, june=False)
    assert rc == 0
    fi = res["future_invariance"]
    # without a recipe module neither is rebuilt; with one, count(24h) is rebuilt and the synthetic look-ahead
    # recipe (outside the closed grammar) is not: either way the look-ahead is never shown ok
    assert fi["ok"] is None and "syn_lookahead_amt" in fi["not_run"]
    assert res["families"]["f15298"]["future_invariance_not_run"]
    fr = pd.read_csv(tmp_path / "o" / "feature_rank.csv").set_index("feature")
    assert fr.loc["syn_lookahead_amt", "future_invariance"].startswith("not run")
    assert "NOT SHOWN" in (tmp_path / "o" / "summary.txt").read_text()


def test_a_field_named_like_a_base_input_is_refused_not_a_crash(tmp_path, capsys):
    """It crashed in the lane; then it was left out, and its row in feature_rank.csv was the base input's. Part B
    of the integration (the screen recheck) refuses it: exit 2, naming the row, before any read."""
    w = _world(tmp_path)

    def add(m):
        r = m.iloc[0].copy()
        r["name"], r["source_columns"], r["model_type"] = "external_1_scr", "external_1_scr", "continuous"
        return pd.concat([m, r.to_frame().T], ignore_index=True)

    _edit_map(w, add)
    rc, res = _run(w, tmp_path / "o", june=False)
    assert rc == 2 and res is None and not (tmp_path / "o" / "memory.json").exists()
    assert "external_1_scr: row " in capsys.readouterr().out


def test_overlapping_26_october_families_run(tmp_path):
    w = _world(tmp_path)
    rc, res = _run(w, tmp_path / "o", ["--oct26", "capacity_E13", "capacity_E13_headroom"], june=False)
    assert rc == 0
    assert "oct26:capacity_E13" in res["families"] and "oct26:capacity_E13_headroom" in res["families"]


def test_unknown_family_name_is_an_argument_error(tmp_path):
    w = _world(tmp_path)
    rc, _ = _run(w, tmp_path / "o", ["--families", "tfm", "nonsense"], june=False)
    assert rc == 2


def test_blank_model_type_reads_category_and_string_columns_as_codes(tmp_path):
    w = _world(tmp_path)
    for f in w["files"] + w["june"]:
        d = pd.read_parquet(f)
        d["syn_cat_col"] = d["syn_useful_code"].astype("category")
        d["syn_str_col"] = d["syn_useful_code"].astype("string")
        d.to_parquet(f)

    def add(m):
        rows = []
        for n in ("syn_cat_col", "syn_str_col"):
            r = m.iloc[0].copy()
            r["name"], r["source_columns"], r["model_type"] = n, n, ""
            rows.append(r.to_frame().T)
        return pd.concat([m] + rows, ignore_index=True)

    _edit_map(w, add)
    rc, res = _run(w, tmp_path / "o", june=False)
    assert rc == 0
    assert res["new_fields"]["syn_cat_col"]["model_type"] == "categorical"
    assert res["new_fields"]["syn_str_col"]["model_type"] == "categorical"
    perm = res["feature_rank"]["permutation"]
    assert perm["syn_cat_col"]["ap_drop_mean"] + perm["syn_str_col"]["ap_drop_mean"] + \
        perm["syn_useful_code"]["ap_drop_mean"] > 0.02  # the signal is read, not turned into missing values


def test_timezone_aware_time_runs(tmp_path):
    w = _world(tmp_path)
    for f in w["files"] + w["june"]:
        d = pd.read_parquet(f)
        d["transaction_dttm"] = pd.to_datetime(d["transaction_dttm"]).dt.tz_localize("UTC")
        d.to_parquet(f)
    rc, res = _run(w, tmp_path / "o")
    assert rc == 0 and "time_split" in res["month_on_top"]


def test_month_statement_uses_the_noise_floor(tmp_path):
    w = _world(tmp_path)
    rc, res = _run(w, tmp_path / "o", june=False)
    mo, floor = res["month_on_top"], res["noise_floor"]["floor"]
    lo = mo["time_split"]["delta_ci95_account_bootstrap"][0]
    assert mo["month_adds_on_time_split"] == (lo > floor)


def test_summary_lists_each_field_once_for_twelve_fields():
    run = load("fsc_run")
    com = load("nf_common", NF / "nf_common.py")
    names = [f"f{i:02d}" for i in range(12)]
    fr = pd.DataFrame({"feature": names, "in_arm": "yes", "shap_rank_new": range(1, 13), "perm_rank_new": range(1, 13),
                       "shap_mean_abs": np.linspace(1, 0.1, 12), "perm_ap_drop_mean": 0.0, "psi_june": 0.0})
    out = {"view": "XGBoost's view, not the transformer's", "layout": "x", "map": "m", "list_status": "UNCONFIRMED",
           "status": "s", "model": "xgboost", "rows": 1, "frauds": 1, "accounts": 1, "files": 1,
           "base_columns_used": [], "missing_base_columns": [], "new_fields": {n: {} for n in names}, "not_built": [],
           "left_out": [], "recipes": "r", "noise_floor": {"floor": 0, "null_abs_delta": 0, "refit_spread": 0},
           "families": {}, "skipped_families": {}, "future_invariance": {"ok": True, "probed": []}}
    from pathlib import Path
    text = run.summary(out, fr, com, Path("screen"))
    for n in names:
        assert sum(line.split()[1:2] == [n] for line in text.splitlines()) == 1, n


def test_recipe_module_builds_engineered_fields(tmp_path):
    """With the new-fields recipe module installed, count and prev recipes are built and probed through it."""
    run = load("fsc_run")
    fn, label = run.recipe_module()
    if fn is None:
        pytest.skip("nf_recipes.py not installed in this tree")
    w = _world(tmp_path)
    _edit_map(w, lambda m: m[m["name"] != "syn_lookahead_amt"])
    rc, res = _run(w, tmp_path / "o", recipe_fn=None, june=True)
    assert rc == 0 and res["recipes"] == "nf_recipes.build_columns"
    assert {"syn_cnt_24h", "syn_prev_amt"} <= set(res["future_invariance"]["probed"])
    assert res["future_invariance"]["ok"] is True
    # the module's values agree with the synthetic builder on the same rows
    d = pd.read_parquet(w["files"][0])
    syn = load("fsc_synth")
    a = syn.synth_builder(d, "prev(transaction_amt)", w["extract_start"]).to_numpy()
    b = np.asarray(fn(d, "prev(transaction_amt)", w["extract_start"], "continuous"), dtype=float)
    both = ~np.isnan(a) & ~np.isnan(b)  # the module caps its lookback (review item 12), so it has more missing
    assert both.sum() > 0.5 * len(a) and np.allclose(a[both], b[both])
