"""The reader refuses wrong inputs: rows, receipts, file ranges, settings, the spread, approvals, Test 1, and stale
saved reads. And the downstream lift with its flag (DESIGN.md 8.7)."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import yaml

from new_fields_reader_world import World, scores, write_spread, run_table, write_fit, POPS, ID, ACCT, LABEL

STOP, REFUSED = 3, 4


@pytest.fixture
def world(tmp_path, monkeypatch):
    return World(tmp_path, monkeypatch, accounts=400)


def _pair(w, pop="rank_b", cand_kw=None, ctrl_kw=None, seed=42):
    raw = w.raw[pop][0]
    write_spread(w.c2, "rank_b", 0.002)
    cand = w.fit(pop, "cand", seed, scores(raw, 3.0, 1), **(cand_kw or {}))
    ctrl = w.fit(pop, "ctrl", seed, scores(raw, 1.0, 2), **(ctrl_kw or {}))
    return cand, ctrl


def test_different_row_sets_stop(world, capsys):
    cand, ctrl = _pair(world)
    pred = pd.read_parquet(cand["predictions"])
    raw = world.raw["rank_b"][0]
    june_row = int(np.flatnonzero(pd.to_datetime(raw["transaction_dttm"]) >= "2025-06-01")[0])
    pred = pred[pred[ID] != raw[ID].iloc[june_row]]
    pred.to_parquet(cand["predictions"], index=False)
    _fix_receipt(cand)
    assert world.run("read", "--step", "A1", "--runs", world.table("t", [cand], [ctrl])) == STOP
    assert "does not hold the read's rows" in capsys.readouterr().out


def test_extra_rows_and_changed_labels_stop(world, capsys):
    cand, ctrl = _pair(world)
    pred = pd.read_parquet(cand["predictions"])
    pred.loc[pred.index[-1], LABEL] = 1 - pred.loc[pred.index[-1], LABEL]
    raw = world.raw["rank_b"][0]
    jm = (pd.to_datetime(raw["transaction_dttm"]) >= "2025-06-01").to_numpy()
    flip = pred[ID].isin(raw[ID][jm])
    pred.loc[flip.idxmax(), LABEL] = 1 - pred.loc[flip.idxmax(), LABEL]
    pred.to_parquet(cand["predictions"], index=False)
    _fix_receipt(cand)
    assert world.run("read", "--step", "A1", "--runs", world.table("t", [cand], [ctrl])) == STOP
    assert "labels differ" in capsys.readouterr().out
    extra = pd.concat([pd.read_parquet(ctrl["predictions"]).head(1).assign(**{ID: 999_999_999})])
    pd.concat([pd.read_parquet(ctrl["predictions"]), extra]).to_parquet(ctrl["predictions"], index=False)
    _fix_receipt(ctrl)
    cand2 = world.fit("rank_b", "cand2", 42, scores(world.raw["rank_b"][0], 3.0, 1))
    assert world.run("read", "--step", "A1", "--runs", world.table("t2", [cand2], [ctrl])) == STOP
    assert "not in the raw files" in capsys.readouterr().out


def test_receipt_hash_mismatch_stops(world, capsys):
    cand, ctrl = _pair(world)
    pd.read_parquet(cand["predictions"]).assign(score=0.5).to_parquet(cand["predictions"], index=False)
    assert world.run("read", "--step", "A1", "--runs", world.table("t", [cand], [ctrl])) == STOP
    assert "predictions_sha256 does not match" in capsys.readouterr().out


def test_checkpoint_hash_mismatch_stops(world, capsys):
    cand, ctrl = _pair(world)
    Path(cand["run_dir"], "best.ckpt").write_bytes(b"another checkpoint")
    assert world.run("read", "--step", "A1", "--runs", world.table("t", [cand], [ctrl])) == STOP
    assert "checkpoint_sha256" in capsys.readouterr().out


def test_wrong_file_range_stops(world, capsys):
    raw, base = world.raw["rank_b"]
    write_spread(world.c2, "rank_b", 0.002)
    cand = write_fit(world.tmp / "odd", "cand", 42, raw, scores(raw, 3.0, 1), [10, 12], base)
    ctrl = world.fit("rank_b", "ctrl", 42, scores(raw, 1.0, 2))
    assert world.run("read", "--step", "A1", "--runs", world.table("t", [cand], [ctrl])) == STOP
    assert "not the RANK-B range" in capsys.readouterr().out


def test_wrong_scoring_policy_and_population_stop(world, capsys):
    cand, ctrl = _pair(world, cand_kw={"cap": 64})
    assert world.run("read", "--step", "A1", "--runs", world.table("t", [cand], [ctrl])) == STOP
    assert "window cap 32" in capsys.readouterr().out
    raw, base = world.raw["rank_b"]
    cand = write_fit(world.tmp / "pop", "cand", 42, raw, scores(raw, 3.0, 1), POPS["rank_b"], base, "SELECT")
    assert world.run("read", "--step", "A1", "--runs", world.table("t2", [cand], [ctrl])) == STOP
    assert "scored as population SELECT" in capsys.readouterr().out


def test_changed_settings_after_the_first_read_stop(world, capsys):
    cand, ctrl = _pair(world)
    t = world.table("t", [cand], [ctrl])
    assert world.run("read", "--step", "A1", "--runs", t) == 0
    cfg = yaml.safe_load((world.set_dir / "SETTINGS.yaml").read_text())
    cfg["bar_udr"] = 0.005
    (world.set_dir / "SETTINGS.yaml").write_text(yaml.safe_dump(cfg))
    assert world.run("read", "--step", "A2", "--runs", t) == STOP
    assert "decision section of SETTINGS.yaml changed" in capsys.readouterr().out


def test_a_non_decision_change_to_settings_is_allowed(world):
    cand, ctrl = _pair(world)
    t = world.table("t", [cand], [ctrl])
    assert world.run("read", "--step", "A1", "--runs", t) == 0
    cfg = yaml.safe_load((world.set_dir / "SETTINGS.yaml").read_text())
    cfg["microbatch"] = {"nf_a2": {"batch_size": 2048}}
    (world.set_dir / "SETTINGS.yaml").write_text(yaml.safe_dump(cfg))
    assert world.run("read", "--step", "A2", "--runs", t) == 0


def test_missing_spread_file_refuses(world, capsys):
    cand, ctrl = _pair(world)
    (world.c2 / "reads" / "spread_rank_b.json").unlink()
    assert world.run("read", "--step", "A1", "--runs", world.table("t", [cand], [ctrl])) == REFUSED
    assert "spread --population rank_b" in capsys.readouterr().out


def test_missing_rank_check_refuses(world, capsys):
    cand, ctrl = _pair(world)
    (world.c2 / "reads" / "rank_check.json").unlink()
    assert world.run("read", "--step", "A1", "--runs", world.table("t", [cand], [ctrl])) == REFUSED
    assert "nf_rank_check.py" in capsys.readouterr().out


def test_blank_approval_refuses(tmp_path, monkeypatch, capsys):
    approvals = {k: {"approved_by": "owner", "approved_on": "2026-11-02"} for k in ("main_measure", "bar")}
    approvals["bar"]["approved_on"] = ""
    w = World(tmp_path, monkeypatch, accounts=300, approvals=approvals)
    cand, ctrl = _pair(w)
    assert w.run("read", "--step", "A1", "--runs", w.table("t", [cand], [ctrl])) == REFUSED
    out = capsys.readouterr().out
    assert "approval blank" in out and "bar" in out and "main_measure" not in out


def test_test1_never_decides(world, capsys):
    raw = world.raw["test1"][0]
    fits = [dict(world.fit("test1", "kept", s, scores(raw, 2.0, s)), role="kept") for s in (42, 43, 44)]
    assert world.run("spread", "--population", "test1", "--runs", run_table(world.tmp / "k.csv", fits)) == REFUSED
    assert "Test 1 never decides" in capsys.readouterr().out
    cand, ctrl = _pair(world)
    assert world.run("read", "--step", "A1", "--population", "test1",
                     "--runs", world.table("t", [cand], [ctrl])) == REFUSED
    # Test 1 predictions offered to a RANK-B read stop on the file range.
    t1c = dict(world.fit("test1", "cand", 42, scores(raw, 3.0, 1)))
    t1k = dict(world.fit("test1", "ctrl", 42, scores(raw, 1.0, 2)))
    assert world.run("read", "--step", "A1", "--runs", world.table("t1", [t1c], [t1k])) == STOP


def test_seed_sets_must_match_and_be_one_or_three(world, capsys):
    raw = world.raw["rank_b"][0]
    write_spread(world.c2, "rank_b", 0.002)
    c = [world.fit("rank_b", "cand", s, scores(raw, 3.0, s)) for s in (42, 43)]
    k = [world.fit("rank_b", "ctrl", s, scores(raw, 1.0, s)) for s in (42, 43)]
    assert world.run("read", "--step", "A1", "--runs", world.table("t", c, k)) == REFUSED
    assert "1 seed or 3 seeds" in capsys.readouterr().out
    k3 = [world.fit("rank_b", "ctrl", s, scores(raw, 1.0, s)) for s in (42, 43, 45)]
    c3 = c + [world.fit("rank_b", "cand", 44, scores(raw, 3.0, 44))]
    assert world.run("read", "--step", "A1", "--runs", world.table("t3", c3, k3)) == REFUSED
    assert world.run("read", "--step", "A1", "--runs", world.table("t0", c[:1], [])) == REFUSED
    assert "control exists" in capsys.readouterr().out


def test_stale_saved_read_stops(world, capsys):
    cand, ctrl = _pair(world)
    t = world.table("t", [cand], [ctrl])
    assert world.run("read", "--step", "A1", "--runs", t) == 0
    cand2 = world.fit("rank_b", "cand_new", 42, scores(world.raw["rank_b"][0], 2.0, 9))
    assert world.run("read", "--step", "A1", "--runs", world.table("t2", [cand2], [ctrl])) == STOP
    assert "inputs changed" in capsys.readouterr().out


def test_select_check_needs_a_pending_read(world, capsys):
    cand, ctrl = _pair(world)
    assert world.run("select-check", "--step", "A1", "--runs", world.table("t", [cand], [ctrl])) == REFUSED
    assert "no saved read" in capsys.readouterr().out


def _fix_receipt(fit):
    import hashlib
    p = Path(fit["predictions"])
    r = json.loads(Path(f"{p}.json").read_text())
    r["predictions_sha256"] = hashlib.sha256(p.read_bytes()).hexdigest()
    Path(f"{p}.json").write_text(json.dumps(r))


# ------------------------------------------------------------------ the downstream lift and its flag

def _downstream(path, raw, raw_arm, emb_arm):
    pd.DataFrame({ID: raw[ID], ACCT: raw[ACCT], LABEL: raw[LABEL], "depth": 3, "raw": raw_arm,
                  "raw_score": raw_arm, "raw_embedding": emb_arm, "raw_score_embedding": emb_arm}).to_parquet(path)
    return str(path)


def _lift_world(w, fit_emb_signal, ctrl_emb_signal=3.0):
    raw = w.raw["select"][0]
    base = scores(raw, 1.0, 1)
    fit = _downstream(w.tmp / "fit.parquet", raw, base, scores(raw, fit_emb_signal, 2))
    ctl = _downstream(w.tmp / "ctl.parquet", raw, base, scores(raw, ctrl_emb_signal, 3))
    return fit, ctl, raw, base


def test_lift_and_paired_se_on_planted_predictions(world):
    R = world.ranked
    fit, ctl, raw, base = _lift_world(world, 3.0)
    assert world.run("lift", "--step", "A1", "--fit", fit, "--control", ctl, "--fraud-rule", "pass") == 0
    rec = world.saved("A1_lift.json")
    keys = R.identity_keys(raw[ACCT], raw[ID])
    codes, units = R.account_units(raw[ACCT])
    kr = R.key_ranks(keys)
    y = raw[LABEL].to_numpy()

    def udr(s, m=None):
        return R.RankedScore(s, y, codes, kr).evaluate(m)["udr"]

    f = pd.read_parquet(fit)
    c = pd.read_parquet(ctl)
    lift_fit = udr(f["raw_embedding"].to_numpy()) - udr(f["raw"].to_numpy())
    lift_ctl = udr(c["raw_embedding"].to_numpy()) - udr(c["raw"].to_numpy())
    assert rec["lift"]["udr"]["lift_fit"] == pytest.approx(lift_fit)
    assert rec["lift"]["udr"]["difference"] == pytest.approx(lift_fit - lift_ctl)
    diffs = [(udr(f["raw_embedding"].to_numpy(), m) - udr(f["raw"].to_numpy(), m))
             - (udr(c["raw_embedding"].to_numpy(), m) - udr(c["raw"].to_numpy(), m))
             for m in R.draw_matrix(len(units), 200, 20261102)]
    assert rec["lift"]["udr"]["sd"] == pytest.approx(np.std(diffs, ddof=1))


def test_lift_flag_fires_on_a_planted_drop_only_when_the_step_passed(tmp_path, monkeypatch):
    w = World(tmp_path / "drop", monkeypatch, accounts=600)
    fit, ctl, _, _ = _lift_world(w, 0.3)  # the fit's embedding helps far less than the control's
    assert w.run("lift", "--step", "A1", "--fit", fit, "--control", ctl, "--fraud-rule", "pass") == 0
    rec = w.saved("A1_lift.json")
    assert rec["lift"]["udr"]["difference"] < -rec["lift"]["udr"]["sd"] and rec["flag"]
    text = w.text("A1_lift.txt")
    assert "FLAG: the embedding's downstream lift fell by more than one paired SE" in text
    assert len(text.rstrip("\n").split("\n")) <= 40
    w = World(tmp_path / "fail", monkeypatch, accounts=600)
    fit, ctl, _, _ = _lift_world(w, 0.3)
    assert w.run("lift", "--step", "A1", "--fit", fit, "--control", ctl, "--fraud-rule", "fail") == 0
    assert not w.saved("A1_lift.json")["flag"]
    w = World(tmp_path / "same", monkeypatch, accounts=600)
    fit, ctl, _, _ = _lift_world(w, 3.0, 3.0)
    assert w.run("lift", "--step", "A1", "--fit", fit, "--control", ctl, "--fraud-rule", "pass") == 0
    rec = w.saved("A1_lift.json")
    assert rec["lift"]["udr"]["difference"] >= -rec["lift"]["udr"]["sd"] and not rec["flag"]


def test_lift_reads_the_fraud_rule_from_the_saved_read_and_reports_the_own_raw_arm(world):
    fit, ctl, raw, base = _lift_world(world, 0.3)
    (world.c2 / "reads").mkdir(parents=True, exist_ok=True)
    (world.c2 / "reads" / "A1_select.json").write_text(json.dumps({"final_decision": "ADOPT"}))
    own = _downstream(world.tmp / "own.parquet", raw, scores(raw, 1.5, 7), base)
    assert world.run("lift", "--step", "A1", "--fit", fit, "--control", ctl, "--fit-own-raw", own) == 0
    rec = world.saved("A1_lift.json")
    assert rec["fraud_rule"] == "pass" and rec["lift_against_own_raw"] is not None
    assert "own raw arm" in world.text("A1_lift.txt")


def test_lift_refuses_different_rows(world, capsys):
    fit, ctl, raw, base = _lift_world(world, 3.0)
    pd.read_parquet(ctl).iloc[1:].to_parquet(ctl)
    assert world.run("lift", "--step", "A1", "--fit", fit, "--control", ctl, "--fraud-rule", "pass") == STOP
    assert "same DS_SELECT rows" in capsys.readouterr().out


# ------------------------------------------------------------------ edges found by the adversarial recompute

def test_a_decision_range_overlapping_test1_refuses_even_without_exposure_files(tmp_path, monkeypatch, capsys):
    w = World(tmp_path, monkeypatch, accounts=300)
    cfg = yaml.safe_load((w.set_dir / "SETTINGS.yaml").read_text())
    cfg["populations"]["test1"]["files"] = [12, 31]
    (w.set_dir / "SETTINGS.yaml").write_text(yaml.safe_dump(cfg))
    cand, ctrl = _pair(w)
    for f in (cand, ctrl):
        Path(f"{f['predictions']}.exposure.json").unlink()
    assert w.run("read", "--step", "A1", "--runs", w.table("t", [cand], [ctrl])) == REFUSED
    assert "overlap Test 1" in capsys.readouterr().out


def test_raw_join_errors_stop_with_exit_3(world, capsys):
    cand, ctrl = _pair(world)
    raw, base = world.raw["rank_b"]
    other = pd.read_parquet(base / "part_11.parquet")
    other.loc[0, ACCT] = pd.read_parquet(base / "part_10.parquet")[ACCT].iloc[0]  # an account in two files
    other.to_parquet(base / "part_11.parquet", index=False)
    assert world.run("read", "--step", "A1", "--runs", world.table("t", [cand], [ctrl])) == STOP
    assert "STOP" in capsys.readouterr().out


def test_spread_and_reads_use_the_planned_seeds_only(world, capsys):
    raw = world.raw["rank_b"][0]
    fits = [dict(world.fit("rank_b", "kept", s, scores(raw, 2.0, s)), role="kept") for s in (42, 43)]
    assert world.run("spread", "--population", "rank_b", "--runs", run_table(world.tmp / "k.csv", fits)) == REFUSED
    write_spread(world.c2, "rank_b", 0.002)
    c = world.fit("rank_b", "cand", 7, scores(raw, 3.0, 1))
    k = world.fit("rank_b", "ctrl", 7, scores(raw, 1.0, 2))
    assert world.run("read", "--step", "A1", "--runs", world.table("t", [c], [k])) == REFUSED
    assert "seeds [42]" in capsys.readouterr().out
    p = world.c2 / "reads" / "spread_rank_b.json"
    d = json.loads(p.read_text())
    d["seeds"] = [42, 43]
    p.write_text(json.dumps(d))
    cand, ctrl = _pair(world)
    p.write_text(json.dumps(d))
    assert world.run("read", "--step", "A1", "--runs", world.table("t2", [cand], [ctrl])) == REFUSED


def test_an_empty_outsort_stops(tmp_path, monkeypatch, capsys):
    w = World(tmp_path, monkeypatch, accounts=12, per_account=12)
    cand, ctrl = _pair(w)
    assert w.run("read", "--step", "B", "--runs", w.table("t", [cand], [ctrl])) == STOP
    assert "empty 0.6% outsort" in capsys.readouterr().out


def test_prediction_amounts_must_equal_the_raw_amounts(world, capsys):
    cand, ctrl = _pair(world)
    for f in (cand, ctrl):
        p = Path(f["predictions"])
        pd.read_parquet(p).assign(transaction_amt=1.0).to_parquet(p, index=False)
        _fix_receipt(f)
    assert world.run("read", "--step", "A1", "--runs", world.table("t", [cand], [ctrl])) == STOP
    assert "differs from the raw files" in capsys.readouterr().out


def test_lift_flag_reads_the_udr_lift_only(tmp_path, monkeypatch):
    """DESIGN.md 8.7 and the plan: the flag reads the UDR lift, the main measure; an AP-only fall is reported."""
    w = World(tmp_path, monkeypatch, accounts=600)
    fit, ctl, _, _ = _lift_world(w, 0.3)
    assert w.run("lift", "--step", "A1", "--fit", fit, "--control", ctl, "--fraud-rule", "pass") == 0
    rec = w.saved("A1_lift.json")
    assert rec["flag"] == bool(rec["falls_by_more_than_se"]["udr"])
    import nf_read as RD_
    assert RD_.lift_flag("pass", {"udr": False, "ap": True}) is False
    assert RD_.lift_flag("pass", {"udr": True, "ap": False}) is True
    assert RD_.lift_flag("fail", {"udr": True, "ap": True}) is False
    assert RD_.lift_flag("pending", {"udr": True, "ap": True}) is False
