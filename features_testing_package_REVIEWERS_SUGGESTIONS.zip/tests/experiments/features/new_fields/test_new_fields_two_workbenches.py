"""Two workbenches share one project folder. The owner runs two or more workbenches: each is its own pod with its
own hostname, and all of them mount the same project folder at the same paths. A lock that names another host is
never stale: the queue refuses (exit 4) and names that host, a fit whose trainer lock names another host is
RUNNING in the planner and in the morning report, and the busy check skips such locks because they do not use this
pod's GPU or CPU. A lock of this host whose process is dead is still replaced. A lock pid of 2**31 or more is a
lock naming no process in the busy check, never a crash (one pid rule, nf_common.lock_pid). Synthetic data only."""
import hashlib
import json
import os
import socket
import subprocess
import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from new_fields_checks_helpers import load  # noqa: E402
from new_fields_spine_world import default_map, make_world, run  # noqa: E402

DEAD = 999999999            # above any pid the system gives: never a live process
OTHER = "workbench-two"     # another of the owner's workbenches
STATUS = {"f_code": "PASS", "f_cnt24": "FLAG", "f_amt": "PASS"}


def _flat(text):
    return " ".join(text.split())


# ------------------------------------------------------------------ another host's queue lock is refused

@pytest.mark.parametrize("alive", [True, False], ids=["pid-alive-here", "pid-dead"])
def test_another_hosts_queue_lock_is_refused_and_stays(tmp_path, monkeypatch, alive):
    w = make_world(tmp_path, map_rows=default_map(), field_status=STATUS)
    c2 = w / "checkpoints" / "new_fields"
    monkeypatch.setenv("NF_OUT", str(c2))
    P = load("nf_plan")
    lock = c2 / "QUEUE.lock.json"
    pid = os.getpid() if alive else DEAD
    text = json.dumps({"pid": pid, "hostname": OTHER, "utc": "2026-11-02T01:00:00Z"})
    lock.write_text(text)
    assert P.owner_alive(json.loads(text)) and P.queue_alive()
    with pytest.raises(P.Stop) as e:
        P.acquire_lock(os.getpid() + 1)
    msg = _flat(str(e.value))
    assert OTHER in msg and f"pid {pid}" in msg and "2026-11-02T01:00:00Z" in msg, msg
    assert "run the queue on one workbench only" in msg and f"if no queue runs on {OTHER}, remove" in msg, msg
    assert lock.read_text() == text
    # the queue itself: exit 4, logged, and the lock as it was
    r = run(w, tmp_path, "nf_plan.py", "queue", "--skip-preflight", "--queue-pid", str(DEAD - 2))
    assert r.returncode == 4, r.stderr
    err = _flat(r.stderr)
    assert OTHER in err and "one workbench only" in err, r.stderr
    assert max(len(x) for x in r.stderr.splitlines()) <= 90
    assert lock.read_text() == text
    log = (c2 / "queue.log").read_text()
    assert "refused" in log and OTHER in log
    assert not list(c2.glob(".QUEUE.lock.json.takeover-*"))


def test_a_takeover_claim_from_another_host_is_refused(tmp_path, monkeypatch):
    c2 = tmp_path / "c2"
    monkeypatch.setenv("NF_OUT", str(c2))
    P = load("nf_plan")
    lock = c2 / "QUEUE.lock.json"
    lock.parent.mkdir(parents=True)
    lock.write_text(json.dumps({"pid": DEAD, "hostname": socket.gethostname(), "utc": "t"}))   # a dead queue here
    st = os.stat(lock)
    tag = hashlib.sha256(f"{st.st_dev}:{st.st_ino}:".encode() + lock.read_bytes()).hexdigest()[:16]
    claim = lock.with_name(f".QUEUE.lock.json.takeover-{tag}")
    claim_text = json.dumps({"pid": DEAD - 1, "hostname": OTHER, "utc": "2026-11-02T02:00:00Z"})
    claim.write_text(claim_text)
    before = lock.read_text()
    with pytest.raises(P.Stop) as e:
        P.acquire_lock(os.getpid())
    msg = _flat(str(e.value))
    assert OTHER in msg and "one workbench only" in msg and claim.name in msg, msg
    assert lock.read_text() == before and claim.read_text() == claim_text


# ------------------------------------------------------------------ a trainer on another host is RUNNING

def test_a_fit_whose_trainer_lock_names_another_host_is_running(tmp_path, monkeypatch):
    w = make_world(tmp_path, map_rows=default_map(), field_status=STATUS)
    c2 = w / "checkpoints" / "new_fields"
    monkeypatch.setenv("NF_OUT", str(c2))
    P = load("nf_plan")
    d = c2 / "runs" / "nf_a1" / "seed42"
    d.mkdir(parents=True)
    (d / "run_manifest_v2.json").write_text(json.dumps({"status": "running",
                                                        "start": {"utc": "2026-11-02T01:00:00Z"}}))
    (d / "RUNNING.lock.json").write_text(json.dumps({"pid": DEAD, "hostname": OTHER,
                                                     "utc": "2026-11-02T01:00:00Z"}))
    (c2 / "queue.log").write_text("queue start 2026-11-02T00:59:00Z pid 1\n"
                                  "start fit_nf_a1_seed42 2026-11-02T01:00:00Z\n")
    assert P.fit_state(d) == "RUNNING" and P.trainer_host(d) == OTHER
    with pytest.raises(P.Stop) as e:
        P.fit_job("nf_a1", 42, tmp_path / "cfg.yaml", "S.1")
    msg = str(e.value)
    assert "has a trainer running on " + OTHER in msg and "rename" not in msg, msg
    r = run(w, tmp_path, "nf_report.py")
    assert r.returncode == 0, r.stderr
    row = [x for x in r.stdout.splitlines() if x.startswith("nf_a1 ")]
    assert len(row) == 1 and f"RUNNING on {OTHER}" in row[0], r.stdout
    assert "(running: fit_nf_a1_seed42)" in r.stdout and "INCOMPLETE" not in r.stdout, r.stdout


# ------------------------------------------------------------------ this host's dead lock is still replaced

def test_this_hosts_lock_with_a_dead_pid_is_still_replaced(tmp_path, monkeypatch):
    c2 = tmp_path / "c2"
    monkeypatch.setenv("NF_OUT", str(c2))
    P = load("nf_plan")
    lock = c2 / "QUEUE.lock.json"
    lock.parent.mkdir(parents=True)
    held = {"pid": DEAD, "hostname": socket.gethostname(), "utc": "t"}
    lock.write_text(json.dumps(held))
    assert not P.owner_alive(held) and not P.queue_alive()
    assert P.acquire_lock(os.getpid()) == lock
    now = json.loads(lock.read_text())
    assert now["pid"] == os.getpid() and now["hostname"] == socket.gethostname()
    assert f"left by pid {DEAD} on {socket.gethostname()}" in (c2 / "queue.log").read_text()
    d = c2 / "runs" / "nf_a1" / "seed42"
    d.mkdir(parents=True)
    (d / "RUNNING.lock.json").write_text(json.dumps(held))
    assert P.fit_state(d) == "INCOMPLETE" and P.trainer_host(d) is None


# ------------------------------------------------------------------ the busy check: one pid rule, no crash

def _busy(C, tmp_path, held):
    q = tmp_path / "locks"
    q.mkdir(exist_ok=True)
    (q / "RUNNING.lock.json").write_text(json.dumps(held))
    procs = tmp_path / "proc"
    procs.mkdir(exist_ok=True)
    # my_pid names no process here, so a live child of this test reads as another process's lock
    return C.busy(proc_root=procs, nvidia_smi=str(tmp_path / "no-nvidia-smi"), lock_roots=[q], my_pid=DEAD)


@pytest.mark.parametrize("pid", [2 ** 31, 2 ** 63, 2 ** 70, 0, -5, "12x", None])
def test_a_lock_pid_out_of_range_is_a_lock_naming_no_process_in_busy(tmp_path, pid):
    P = load("nf_plan")
    C = P.C                 # the nf_common the planner uses
    assert P.lock_pid is C.lock_pid and P.PID_LIMIT == C.PID_LIMIT == 2 ** 31     # one helper, no second copy
    found = _busy(C, tmp_path, {"pid": pid, "hostname": socket.gethostname(), "utc": "t"})
    assert len(found) == 1 and "names no process" in found[0] and "RUNNING.lock.json" in found[0], found


def test_busy_skips_another_hosts_lock_and_sees_this_hosts_live_one(tmp_path):
    C = load("nf_plan").C
    live = subprocess.Popen(["sleep", "60"])
    try:
        assert _busy(C, tmp_path, {"pid": live.pid, "hostname": OTHER, "utc": "t"}) == []
        assert _busy(C, tmp_path, {"pid": 2 ** 31, "hostname": OTHER, "utc": "t"}) == []
        found = _busy(C, tmp_path, {"pid": live.pid, "hostname": socket.gethostname(), "utc": "t"})
        assert len(found) == 1 and f"pid {live.pid} alive" in found[0], found
    finally:
        live.kill()
        live.wait()
