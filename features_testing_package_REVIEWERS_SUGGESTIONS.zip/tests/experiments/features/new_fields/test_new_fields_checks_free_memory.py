"""The field checks' free-memory rule: the shared helper nf_common.resource_limits, the rule the CPU screen uses, so
both CPU tools see the smaller of the host's MemAvailable and the container's cgroup headroom. Without the helper
the checks read MemAvailable as before. Injected file readers only; nothing here reads the real cgroup."""
import functools
from pathlib import Path

import pytest

from new_fields_checks_helpers import load

F = load("nf_field_checks")
GIB = 2 ** 30


def _reader(files):
    return lambda path: files.get(path)


def _v2(host_gib, limit_gib, used_gib, inactive_gib=0):
    return {"/proc/meminfo": f"MemTotal: {4 * host_gib * 1024 * 1024} kB\nMemAvailable: {host_gib * 1024 * 1024} kB\n",
            "/proc/self/cgroup": "0::/kubepods/pod1/c1\n",
            "/sys/fs/cgroup/kubepods/pod1/c1/memory.max": str(limit_gib * GIB),
            "/sys/fs/cgroup/kubepods/pod1/c1/memory.current": str(used_gib * GIB),
            "/sys/fs/cgroup/kubepods/pod1/c1/memory.stat": f"anon 1\ninactive_file {inactive_gib * GIB}\n"}


@pytest.fixture
def nc():
    return F._load("nf_common")


def test_free_memory_is_the_shared_helpers_free_gib(nc, monkeypatch):
    monkeypatch.setattr(nc, "resource_limits", lambda: {"free_gib": 1.25, "cpus": 2})
    assert F.free_gb() == 1.25


def test_a_container_limit_below_the_host_figure_is_the_free_memory(nc, monkeypatch):
    real = nc.resource_limits
    # the host has 64 GiB available; the container's limit is 8 GiB with 7 GiB in use (1 GiB inactive cache)
    monkeypatch.setattr(nc, "resource_limits", functools.partial(real, read=_reader(_v2(64, 8, 7, 1)), affinity=4))
    assert F.free_gb() == 2.0
    # no container limit: the host figure, as before
    files = _v2(64, 8, 7)
    files["/sys/fs/cgroup/kubepods/pod1/c1/memory.max"] = "max\n"
    monkeypatch.setattr(nc, "resource_limits", functools.partial(real, read=_reader(files), affinity=4))
    assert F.free_gb() == 64.0


def test_without_the_shared_helper_the_checks_read_memavailable(nc, monkeypatch):
    monkeypatch.delattr(nc, "resource_limits")
    got = F.free_gb()
    if not Path("/proc/meminfo").exists():
        assert got is None
        return
    want = next(int(x.split()[1]) for x in Path("/proc/meminfo").read_text().splitlines()
                if x.startswith("MemAvailable:")) / 1024 / 1024
    assert got == pytest.approx(want, abs=1.0)


def test_the_refusal_names_the_unit_and_the_container_rule(nc, monkeypatch, tmp_path):
    monkeypatch.setattr(nc, "resource_limits", lambda: {"free_gib": 0.5, "cpus": 1})
    m = tmp_path / "FIELD_MAP.csv"
    m.write_text("name\n")
    a = F.build_args(["--map", str(m), "--min-free-gb", "2", "--out", str(tmp_path / "out")])
    log = []
    assert F.run(a, log=log.append) == nc.REFUSED
    line = [x for x in log if x.startswith("refused:")]
    assert line and "free host memory 0.5 GiB" in line[0] and "container" in line[0] and "below 2.0 GiB" in line[0]
