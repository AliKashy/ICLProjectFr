"""A small synthetic project for the spine lane's tests: a copy of the new-fields folder, the base predictors list, a
base config, a stage 1 control, kept seeds, and fake trainer, scorer, reader, importance and downstream tools.
No bank data, no network. Tools run in it by path, as on the pod."""
import json
import os
import shutil
import stat
import subprocess
import sys
import textwrap
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[4]
NF_SRC = ROOT / "fraud" / "experiments" / "features" / "new_fields"
NF_REL = "fraud/experiments/features/new_fields"
SPINE_FILES = ["nf_layout.py", "nf_common.py", "nf_guard.py", "nf_intake.py", "nf_make_configs.py", "nf_rank_check.py",
               "nf_plan.py", "nf_report.py", "nf_naming_check.py", "nf_run_all.sh", "nf_start.sh", "SETTINGS.yaml",
               "STEPS.yaml", "CHECK_THRESHOLDS.yaml", "STATUS_RULES.csv", "UPSTREAM.yaml", "FIELD_MAP.csv",
               # integration: the fit wrapper, the data lane's list rule (config writer) and the recipe grammar (intake)
               "nf_fit.py", "nf_data_artifact.py", "nf_data_io.py", "nf_recipes.py"]

BASE_CONFIG = {
    "predictors": {"csv_path": "fraud/configs/predictors.csv", "version": 1},
    "artifacts": {"base": "s3://bucket/artifacts", "version": 1},
    "data": {"target_col": "frd_tag", "order_col": "transaction_dttm", "account_col": "Nmap_account_reference_xid",
             "train_base": "s3://bucket/tfm_raw_data", "train_start": 1, "train_end": 10,
             "val_base": "s3://bucket/tfm_raw_data", "val_start": 4950, "val_end": 4954},
    "sequence": {"history_len": 20, "max_chunk_rows": 32, "max_window_rows": 32},
    "datetime": {"fields": ["month", "day", "hour", "day_of_week"]},
    "training": {"batch_size": 256, "accumulate_grad_batches": 16, "eval_batch_size": 1024, "num_workers": 4,
                 "learning_rate": 0.0003, "max_epochs": 10, "early_stopping_patience": 5, "seed": 42},
    "experiment": {"run_name": "allpos_h20_chunk"},
    "s3": {"cred_path": "creds.yaml"},
    "output": {"checkpoint_dir": "models/sequential_hier_allpos_h20_chunk/seed42"},
    "eval": {"base": "s3://bucket/tfm_EVAL_raw_data", "file_start": 8000, "file_end": 8010,
             "checkpoint": "${output.checkpoint_dir}/best.ckpt"},
}

FAKE_TRAINER = textwrap.dedent('''
    import hashlib, json, os, sys, yaml
    POPULATIONS = ("SELECT", "OTHER")
    MAX_STAGE1_ROWS = 65535
    def source_files(): return {"a.py": "x"}
    def source_sha256(): return os.environ.get("FAKE_SOURCE_SHA", "s" * 64)
    def run_identity(cfg, a): return {}
    def check_batch_plan(cfg): return None
    def eval_batch_size(cfg): return 1
    if __name__ == "__main__":
        args = sys.argv[1:]
        cfg = yaml.safe_load(open(args[args.index("--config") + 1]))
        over = dict(a.split("=", 1) for a in args if "=" in a and not a.startswith("--"))
        out = over["output.checkpoint_dir"]
        if os.environ.get("FAKE_FAIL_FIT") and os.environ["FAKE_FAIL_FIT"] in out:
            sys.exit(1)
        os.makedirs(out, exist_ok=True)
        cfg.setdefault("training", {})["seed"] = int(over.get("training.seed", 42))
        yaml.safe_dump(cfg, open(os.path.join(out, "resolved_train_v2.yaml"), "w"))
        open(os.path.join(out, "best.ckpt"), "wb").write(hashlib.sha256(out.encode()).digest())
        open(os.path.join(out, "metrics.csv"), "w").write("epoch,valid_ap\\n0,0.1\\n1,0.12\\n")
        steps = int(os.environ.get("FAKE_UPDATES_PER_EPOCH", "2103")) * 2   # stage 1 rule S7: 2,103 per epoch
        json.dump({"status": "finished", "epochs_run": 2, "optimizer_steps": steps,
                   "start": {"utc": "2026-11-02T00:00:00Z", "source_sha256": source_sha256()},
                   "ended_utc": "2026-11-02T02:00:00Z"}, open(os.path.join(out, "run_manifest_v2.json"), "w"))
''')

# The width timing (nf_time_width.py real) as the queue calls it for a later step's candidate (D5a): it writes
# C2/timing/<run>.json and, when FAKE_TIMING_MICROBATCH names the run, the memory rule's micro-batch into SETTINGS.yaml
FAKE_TIMING = textwrap.dedent('''
    import json, os, sys
    import yaml
    a = sys.argv[1:]
    if a[0] == "score":     # the scoring timing of the final kept fit (decision D4b): figures only
        run = a[a.index("--run") + 1]
        out = os.path.join(os.environ["NF_OUT"], "timing")
        os.makedirs(out, exist_ok=True)
        if os.environ.get("FAKE_TIMING_LOG"):
            open(os.environ["FAKE_TIMING_LOG"], "a").write(" ".join(a) + "\\n")
        json.dump({"run": run, "inputs": 3, "window_seconds": {"median": 0.002, "p99": 0.004, "n": 200}},
                  open(os.path.join(out, run + "_scoring.json"), "w"))
        sys.exit(0)
    assert a[0] == "real" and "--config" in a and "--run" in a and "--write-settings" in a, a
    run = a[a.index("--run") + 1]
    assert os.path.isfile(a[a.index("--config") + 1]), a
    if os.environ.get("FAKE_TIMING_LOG"):
        open(os.environ["FAKE_TIMING_LOG"], "a").write(" ".join(a) + "\\n")
    out = os.path.join(os.environ["NF_OUT"], "timing")
    os.makedirs(out, exist_ok=True)
    mb = json.loads(os.environ.get("FAKE_TIMING_MICROBATCH", "{}")).get(run)
    if mb:
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "SETTINGS.yaml")
        s = yaml.safe_load(open(p))
        s["microbatch"] = dict(s.get("microbatch") or {}, **{run: mb})
        yaml.safe_dump(s, open(p, "w"), sort_keys=False)
    json.dump({"run": run, "verdict": "OK", "microbatch": {run: mb} if mb else {}},
              open(os.path.join(out, run + ".json"), "w"))
''')

FAKE_SCORER = textwrap.dedent('''
    import hashlib, json, os, sys
    POPULATIONS = ("SELECT", "EPOCH_VAL", "DS_SELECT", "DEV_OOT", "FINAL", "BENCH", "OTHER")
    def load_for_scoring(c, p): pass
    def select(l, b, c): pass
    def _model_inputs(b, d): pass
    if __name__ == "__main__":
        a = sys.argv[1:]
        out = a[a.index("--out") + 1]
        if os.path.exists(out):
            sys.exit(1)
        os.makedirs(os.path.dirname(out), exist_ok=True)
        data = (out + open(a[a.index("--checkpoint") + 1], "rb").read().hex()).encode()
        open(out, "wb").write(data)
        files = [x for x in a if x.startswith("eval.file_")]
        json.dump({"population": a[a.index("--population") + 1], "purpose": a[a.index("--purpose") + 1]},
                  open(out + ".exposure.json", "w"))
        json.dump({"predictions_sha256": hashlib.sha256(data).hexdigest(), "files": files, "n_predictions": 100},
                  open(out + ".json", "w"))
''')

FAKE_READER = textwrap.dedent('''
    import json, os, sys
    a = sys.argv[1:]
    sub = a[0]
    out = a[a.index("--out") + 1]
    os.makedirs(os.path.dirname(out), exist_ok=True)
    plan = json.load(open(os.environ["FAKE_DECISIONS"])) if os.environ.get("FAKE_DECISIONS") else {}
    if sub == "report":
        open(out, "w").write("test 1 report\\n"); sys.exit(0)
    if sub == "spread":
        json.dump({"sd_run_udr": 0.006}, open(out, "w")); sys.exit(0)
    step = a[a.index("--step") + 1]
    kind = os.path.basename(out).split("_", 1)[1].replace(".json", "")
    default = {"select-check": "PASS", "lift": "LIFT"}.get(sub, "KEEP THE CONTROL")
    dec = plan.get(f"{step}_{kind}", default)
    if dec == "CRASH":
        sys.exit(1)
    json.dump({"decision": dec, "gain": 0.001}, open(out, "w"))
''')

FAKE_IMPORTANCE = textwrap.dedent('''
    import os, sys
    a = sys.argv[1:]
    assert a[0] == "run" and "--field-map" in a, a      # the importance lane's command line
    assert "--timing" in a or ("--seconds-per-row" in a and "--rank-a-rows" in a), a
    if os.environ.get("FAKE_IMPORTANCE_ARGS"):
        open(os.environ["FAKE_IMPORTANCE_ARGS"], "a").write(" ".join(a) + "\\n")
    out = a[a.index("--output") + 1]
    attention = "--attention-only" in a
    if os.environ.get("FAKE_FAIL_ATTENTION") and attention:
        sys.exit(2)
    if os.environ.get("FAKE_FAIL_IMPORTANCE") and not attention:
        sys.exit(3)
    os.makedirs(out, exist_ok=True)
    name = "attention.csv" if attention else "importance.csv"
    open(os.path.join(out, name), "w").write(os.environ.get("FAKE_IMPORTANCE_CSV", "unit,kind,members,udr_drop_lo,ap_drop_lo\\n"))
''')

FAKE_DOWNSTREAM = textwrap.dedent('''
    import json, os, sys
    a = sys.argv[1:]
    assert a[0] == "run" and "--run-dir" in a, a   # the downstream lane's command line
    name = a[a.index("--name") + 1]
    out = os.path.join(os.environ["NF_OUT"], "downstream", name)
    os.makedirs(out, exist_ok=True)
    json.dump({"name": name}, open(os.path.join(out, "summary.json"), "w"))
''')


def write(p, text):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text)
    return p


def make_world(tmp, *, stage1=True, kept=True, map_rows=None, field_status=None, rank_check="PASS",
               settings_patch=None, steps_patch=None, fake_smi_apps="", fake_smi_used="0"):
    w = Path(tmp) / "proj"
    nf = w / NF_REL
    nf.mkdir(parents=True)
    for f in SPINE_FILES:
        shutil.copy(NF_SRC / f, nf / f)
    # a reorganized-layout stub: packages with __init__.py, the trainer and scorer fakes
    for pkg in ("fraud", "fraud/scripts", "fraud/data"):
        write(w / pkg / "__init__.py", "")
    write(w / "fraud/scripts/train_sequential_hier.py", FAKE_TRAINER)
    write(w / "fraud/scripts/score_sequential_hier.py", FAKE_SCORER)
    write(w / "fraud/scripts/business_metrics.py", "def _alert(*a): pass\ndef _ranking(*a): pass\n")
    write(w / "fraud/scripts/compare_models.py", "def load_raw(*a): pass\ndef target_mask(*a): pass\n")
    write(w / "fraud/data/s3_utils.py", "def make_s3_filesystem(c=None): return None\n"
          "def strip_scheme(p): return p\n")
    shutil.copy(ROOT / "fraud/configs/predictors.csv", write(w / "fraud/configs/predictors.csv", ""))
    write(w / "fraud/configs/sequential_hier_allpos.yaml", yaml.safe_dump(BASE_CONFIG, sort_keys=False))
    write(nf / "nf_read.py", FAKE_READER)
    write(nf / "nf_importance.py", FAKE_IMPORTANCE)
    write(nf / "nf_downstream.py", FAKE_DOWNSTREAM)
    write(nf / "nf_time_width.py", FAKE_TIMING)
    s = yaml.safe_load((nf / "SETTINGS.yaml").read_text())
    s["learning_rate_source"] = "stage 0 report, test"
    for k in s["approvals"]:
        s["approvals"][k] = {"approved_by": "owner", "approved_on": "2026-11-02"}
    s.update(settings_patch or {})
    (nf / "SETTINGS.yaml").write_text(yaml.safe_dump(s, sort_keys=False))
    st = yaml.safe_load((nf / "STEPS.yaml").read_text())
    st.update(steps_patch or {})
    (nf / "STEPS.yaml").write_text(yaml.safe_dump(st, sort_keys=False))
    c2 = w / "checkpoints" / "new_fields"
    if stage1:
        d = w / "checkpoints/reproduce/retrain_seed42"
        cfg = json.loads(json.dumps(BASE_CONFIG))
        cfg["output"]["checkpoint_dir"] = "checkpoints/reproduce/retrain_seed42"
        write(d / "resolved_train_v2.yaml", yaml.safe_dump(cfg, sort_keys=False))
        write(d / "best.ckpt", "control")
        write(d / "run_manifest_v2.json", json.dumps({"status": "finished", "epochs_run": 9,
                                                      "start": {"source_sha256": "s" * 64, "utc": "x"}}))
    if kept:
        for sd in (42, 43, 44):
            d = w / f"models/sequential_hier_allpos_h20_chunk/seed{sd}"
            cfg = json.loads(json.dumps(BASE_CONFIG))
            cfg["training"]["seed"] = sd
            write(d / "config.yaml", yaml.safe_dump(cfg, sort_keys=False))
            write(d / "best.ckpt", f"kept{sd}")
    if map_rows is not None:
        import pandas as pd
        sys.path.insert(0, str(nf))
        import nf_common as C
        sys.path.remove(str(nf))
        rows = []
        for r in map_rows:
            row = {c: "" for c in C.FIELD_MAP_COLUMNS}
            row.update(r)
            rows.append(row)
        pd.DataFrame(rows, columns=C.FIELD_MAP_COLUMNS).to_csv(nf / "FIELD_MAP.csv", index=False)
    if field_status is not None:
        write(c2 / "checks/field_status.csv", "field,result,reasons\n" +
              "".join(f"{k},{v},\n" for k, v in field_status.items()))
        os.utime(c2 / "checks/field_status.csv", None)
    if rank_check:
        write(c2 / "reads/rank_check.json", json.dumps({"decide_on": "rank_b" if rank_check == "PASS"
                                                        else "select_june", "result": rank_check}))
    bin_ = Path(tmp) / "bin"
    bin_.mkdir(exist_ok=True)
    smi = bin_ / "nvidia-smi"
    smi.write_text("#!/bin/sh\ncase \"$1\" in\n"
                   f"  --query-compute-apps*) printf '%s' '{fake_smi_apps}';;\n"
                   f"  --query-gpu=memory*) echo '{fake_smi_used}';;\n"
                   "  --query-gpu=name*) echo 'Fake GPU';;\nesac\n")
    smi.chmod(smi.stat().st_mode | stat.S_IEXEC)
    return w


def default_map():
    return [
        {"name": "f_code", "group": "v22b", "kind": "raw", "recipe": "raw", "source_columns": "f_code",
         "model_type": "categorical", "definition_version": "1", "excluded_by_sumegha": "no",
         "feasible_in_production": "yes", "list_status": "CONFIRMED", "description": "a code"},
        {"name": "f_cnt24", "group": "f15298", "kind": "engineered", "recipe": "count(24h)",
         "source_columns": "", "model_type": "continuous", "definition_version": "1", "excluded_by_sumegha": "no",
         "feasible_in_production": "yes", "list_status": "CONFIRMED"},
        {"name": "f_amt", "group": "f15298", "kind": "raw", "recipe": "raw", "source_columns": "f_amt",
         "model_type": "continuous", "definition_version": "1", "excluded_by_sumegha": "no",
         "feasible_in_production": "yes", "list_status": "CONFIRMED"},
    ]


def env(world, tmp, **extra):
    """The tools' environment: the fake nvidia-smi first on PATH, and an empty process table of the test's own
    (NF_PROC_ROOT), so a trainer or another test run on the machine never makes the world's queue busy.
    A preflight run through env() therefore always stops at process_table; pass NF_PROC_ROOT="/proc" to see the
    result the pod gets (gpu_free then reads this machine's processes)."""
    procs = Path(tmp) / "proc_empty"
    procs.mkdir(parents=True, exist_ok=True)
    e = {"PATH": f"{Path(tmp) / 'bin'}:/usr/bin:/bin", "PYTHONDONTWRITEBYTECODE": "1", "HOME": str(tmp),
         "NF_OUT": str(world / "checkpoints" / "new_fields"), "NF_PROC_ROOT": str(procs)}
    e.update({k: str(v) for k, v in extra.items()})
    return e


def run(world, tmp, *args, **extra):
    """Runs a tool of the world's new-fields folder by path."""
    cmd = [sys.executable, str(world / NF_REL / args[0]), *args[1:]]
    return subprocess.run(cmd, cwd=world, capture_output=True, text=True, env=env(world, tmp, **extra), timeout=300)
