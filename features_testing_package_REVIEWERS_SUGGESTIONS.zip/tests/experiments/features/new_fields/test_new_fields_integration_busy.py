"""The busy check's process table (integration notes item 11). On the pod the check reads /proc: every process of the
machine. A test points NF_PROC_ROOT at a folder of its own, so a trainer or another test run on the same machine never
makes its queue busy, while a fake table still makes the queue refuse."""
import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from new_fields_spine_world import NF_REL, default_map, env, make_world, run  # noqa: E402

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / NF_REL))
import nf_common as C  # noqa: E402

STATUS = {"f_code": "PASS", "f_cnt24": "FLAG", "f_amt": "PASS"}
TRAINER = ["python3", "-m", "fraud.scripts.train_sequential_hier", "--config",
           "fraud/configs/sequential_hier_allpos.yaml"]
FAKE_PID = 4999999            # above the largest process id Linux allows, so never a real process
LINUX = Path("/proc/self/cmdline").is_file()


def world(tmp_path, **kw):
    kw.setdefault("map_rows", default_map())
    kw.setdefault("field_status", STATUS)
    return make_world(tmp_path, **kw)


def queue(w, tmp_path, **envx):
    p = tmp_path / "decisions.json"
    p.write_text(json.dumps({"A1_1seed": "KEEP THE CONTROL", "A2_1seed": "KEEP THE CONTROL"}))
    return run(w, tmp_path, "nf_plan.py", "queue", "--skip-preflight", FAKE_DECISIONS=p, **envx)


def qlog(w):
    return (w / "checkpoints" / "new_fields" / "queue.log").read_text()


def fake_table(root, procs):
    """A folder laid out as /proc: one folder per process id with its command line and its parent."""
    for pid, (ppid, argv) in procs.items():
        d = Path(root) / str(pid)
        d.mkdir(parents=True)
        (d / "cmdline").write_bytes(b"\0".join(a.encode() for a in argv) + b"\0")
        (d / "stat").write_text(f"{pid} ({Path(argv[0]).name}) S {ppid} 0 0\n")
    return Path(root)


@pytest.fixture
def matching_process(tmp_path):
    """A real process on this machine whose command line matches the busy rule (the width timing tool's attempt):
    a script named nf_time_width.py that only sleeps. It is stopped after this one test. It waits up to an hour,
    far longer than a queue run may take (300 s), but ends within a second once this test run has ended, so an
    interrupted run never leaves a process that makes the pod's own queue busy."""
    script = tmp_path / "elsewhere" / "nf_time_width.py"
    script.parent.mkdir()
    script.write_text("import os\nimport sys\nimport time\n"
                      "end = time.time() + 3600\n"
                      "while os.getppid() == int(sys.argv[2]) and time.time() < end:\n"
                      "    time.sleep(1)\n")
    argv = [sys.executable, str(script), "_attempt", str(os.getpid())]
    if not C.busy_patterns()[0].match(" ".join(argv)):
        pytest.skip(f"this interpreter's name is outside the busy rule: {Path(sys.executable).name}")
    p = subprocess.Popen(argv, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        cmdline = Path(f"/proc/{p.pid}/cmdline")
        for _ in range(50):
            if cmdline.is_file() and b"nf_time_width.py" in cmdline.read_bytes():
                break
            time.sleep(0.1)
        yield p
    finally:
        p.kill()
        p.wait(timeout=30)


# ------------------------------------------------------------------ the default table

def test_the_table_is_proc_unless_a_test_names_another(monkeypatch, tmp_path):
    monkeypatch.delenv("NF_PROC_ROOT", raising=False)
    assert C.default_proc_root() == Path("/proc") and C.proc_root_note() == ""
    monkeypatch.setenv("NF_PROC_ROOT", "")
    assert C.default_proc_root() == Path("/proc") and C.proc_root_note() == ""
    monkeypatch.setenv("NF_PROC_ROOT", "/proc")
    assert C.proc_root_note() == ""
    monkeypatch.setenv("NF_PROC_ROOT", str(tmp_path))
    assert C.default_proc_root() == tmp_path
    assert "NF_PROC_ROOT is set (tests only)" in C.proc_root_note()


def test_busy_reads_the_table_named_by_the_variable(monkeypatch, tmp_path):
    fake = fake_table(tmp_path / "proc", {FAKE_PID: (1, TRAINER)})
    empty = tmp_path / "empty"
    empty.mkdir()
    smi = str(tmp_path / "no-nvidia-smi")
    monkeypatch.setenv("NF_PROC_ROOT", str(fake))
    assert C.busy(nvidia_smi=smi, lock_roots=[]) == [f"process {FAKE_PID}: {' '.join(TRAINER)}"]
    assert C.busy(proc_root=empty, nvidia_smi=smi, lock_roots=[]) == []        # an explicit table wins
    monkeypatch.setenv("NF_PROC_ROOT", str(empty))
    assert C.busy(nvidia_smi=smi, lock_roots=[]) == []
    monkeypatch.setenv("NF_PROC_ROOT", str(tmp_path / "missing"))             # a wrong folder fails closed
    found = C.busy(nvidia_smi=smi, lock_roots=[])
    assert len(found) == 1 and "not found" in found[0]


@pytest.mark.skipif(not LINUX, reason="needs a Linux process table")
def test_another_spelling_of_proc_is_the_real_table(monkeypatch, tmp_path):
    """/proc written another way, or a link to it, is the machine's own table: no test note, nothing missing. A link
    that loops is not a table: it fails closed with a line, not a crash."""
    smi = str(tmp_path / "no-nvidia-smi")
    link = tmp_path / "link_to_proc"
    link.symlink_to("/proc")
    for spelling in ("/proc/", "//proc", "/proc/../proc", str(link)):
        monkeypatch.setenv("NF_PROC_ROOT", spelling)
        assert C.proc_root_note() == "", spelling
        assert not [f for f in C.busy(nvidia_smi=smi, lock_roots=[]) if "not found" in f], spelling
    loop = tmp_path / "loop"
    loop.symlink_to(loop)
    monkeypatch.setenv("NF_PROC_ROOT", str(loop))
    assert "NF_PROC_ROOT is set (tests only)" in C.proc_root_note()
    found = C.busy(nvidia_smi=smi, lock_roots=[])
    assert len(found) == 1 and "not found" in found[0]


def test_with_an_empty_table_the_locks_of_its_own_parents_stay_its_own(monkeypatch, tmp_path):
    """The queue's lock holds its parent's process id (the queue shell). With a test's empty table, the parents and
    children of the process itself still come from the real one, so that lock never reads as busy."""
    empty = tmp_path / "empty"
    empty.mkdir()
    monkeypatch.setenv("NF_PROC_ROOT", str(empty))
    q = tmp_path / "c2"
    q.mkdir()
    C.write_json(q / "QUEUE.lock.json", {"pid": os.getppid(), "hostname": socket.gethostname(), "utc": "t"})
    smi = str(tmp_path / "no-nvidia-smi")
    assert C.busy(nvidia_smi=smi, lock_roots=[q]) == []
    # the same lock, judged for another process id: held by a live process that is not one of its parents
    found = C.busy(nvidia_smi=smi, lock_roots=[q], my_pid=FAKE_PID)
    assert len(found) == 1 and "QUEUE.lock.json" in found[0]


# ------------------------------------------------------------------ the queue

@pytest.mark.skipif(not LINUX, reason="needs a Linux process table")
def test_queue_runs_while_a_matching_process_runs_on_the_machine(tmp_path, matching_process):
    """Notes item 11: a real process matching the busy rule runs on this machine; the real table sees it, and the
    world's queue, which reads its own empty table, still runs its GPU jobs."""
    w = world(tmp_path)
    host = run(w, tmp_path, "nf_plan.py", "busy", NF_PROC_ROOT="/proc")
    assert host.returncode == 4 and f"process {matching_process.pid}:" in host.stdout, host.stdout
    own = run(w, tmp_path, "nf_plan.py", "busy")
    assert own.returncode == 0 and own.stdout.splitlines()[0] == "free"
    assert "NF_PROC_ROOT is set (tests only)" in own.stdout
    r = queue(w, tmp_path)
    log = qlog(w)
    assert r.returncode in (0, 5), r.stderr + log
    assert "busy:" not in log and not [ln for ln in log.splitlines() if ln.startswith("refused")], log
    assert "start fit_nf_a1_seed42" in log and "end fit_nf_a1_seed42 rc=0" in log
    assert matching_process.poll() is None          # it ran the whole time


def test_a_trainer_in_a_fake_table_makes_the_queue_refuse_and_names_it(tmp_path):
    w = world(tmp_path)
    fake = fake_table(tmp_path / "proc_trainer", {FAKE_PID: (1, TRAINER)})
    r = queue(w, tmp_path, NF_PROC_ROOT=fake)
    log = qlog(w)
    assert r.returncode == 4, r.stderr + log
    refused = [ln for ln in log.splitlines() if ln.startswith("refused ")]
    assert len(refused) == 1 and f"busy: process {FAKE_PID}: {' '.join(TRAINER)}" in refused[0], log
    assert "start fit_" not in log and "queue end rc=4" in log
    b = run(w, tmp_path, "nf_plan.py", "busy", NF_PROC_ROOT=fake)
    assert b.returncode == 4 and f"process {FAKE_PID}: python3 -m fraud.scripts.train_sequential_hier" in b.stdout
    s = subprocess.run(["bash", str(w / NF_REL / "nf_start.sh")], cwd=w, capture_output=True, text=True,
                       env=env(w, tmp_path, PY=sys.executable, NF_NO_TAIL=1, NF_PROC_ROOT=fake), timeout=60)
    assert s.returncode == 4 and "refused" in s.stdout and str(FAKE_PID) in s.stdout


def test_preflight_stops_while_the_variable_is_set(tmp_path):
    """Tests only: on the pod the preflight refuses a run whose busy check would not read /proc."""
    w = world(tmp_path)
    pf = w / "checkpoints" / "new_fields" / "reads" / "preflight.json"
    run(w, tmp_path, "nf_plan.py", "preflight")
    row = {c["check"]: c for c in json.loads(pf.read_text())["checks"]}["process_table"]
    assert not row["ok"] and "NF_PROC_ROOT is set (tests only)" in row["detail"]
    run(w, tmp_path, "nf_plan.py", "preflight", NF_PROC_ROOT="/proc")
    row = {c["check"]: c for c in json.loads(pf.read_text())["checks"]}["process_table"]
    assert row["ok"] and row["detail"].startswith("/proc")
