"""Importance plans preserve recipe dependencies and explicit donor policies."""
from dataclasses import asdict
import importlib
from pathlib import Path
import sys

import pandas as pd
from pandas.testing import assert_frame_equal
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[4] / "fraud/experiments/features/new_fields"))
from nf_importance_units import build_units, make_recompute
from nf_permutation import Unit


def mapping():
    # Reversed order deliberately makes dependency sorting necessary.
    return pd.DataFrame([
        {"name": "scaled", "kind": "engineered", "recipe": "ratio(ratio; scale)",
         "source_columns": "ratio;scale"},
        {"name": "ratio", "kind": "engineered", "recipe": "ratio(amount; limit)",
         "source_columns": "amount;limit"},
        {"name": "profile", "kind": "raw", "recipe": "raw", "source_columns": "profile",
         "donor_unit": "account"},
        {"name": "unrelated", "kind": "engineered", "recipe": "prev(other)",
         "source_columns": "other"},
    ]).fillna("")


def family_spec(**kwargs):
    value = {"name": "family:amount", "method": "family", "source_columns": ["amount"]}
    value.update(kwargs)
    return value


def test_every_predictor_is_covered_and_calendar_is_explicit():
    units = build_units(["month", "amount", "profile"], mapping())
    assert [u.name for u in units] == ["month", "amount", "profile"]
    assert units[0].artificial_time_fixed
    assert units[1].donor_unit == "event"
    assert units[2].donor_unit == "account"
    assert all(u.method == "single_output_possibly_inconsistent" for u in units)


def test_profile_names_are_not_guessed_and_are_validated():
    assert build_units(["customer_age"])[0].donor_unit == "event"
    assert build_units(["customer_age"], profile_fields=["customer_age"])[0].donor_unit == "account"
    with pytest.raises(ValueError, match="Unknown profile"):
        build_units(["amount"], profile_fields=["customer_age"])
    with pytest.raises(ValueError, match="declared account profile"):
        build_units(["profile"], mapping(), unit_specs=[
            {"name": "profile", "members": ["profile"], "donor_unit": "event"}
        ])


def test_source_only_cannot_silently_stand_for_an_engineered_family():
    with pytest.raises(ValueError, match="engineered output"):
        build_units(["ratio"], mapping(), unit_specs=[
            {"name": "ratio", "members": ["ratio"], "method": "source"}
        ])
    with pytest.raises(ValueError, match="Source-only units"):
        build_units(["amount"], unit_specs=[
            {"name": "amount", "members": ["amount"], "method": "source", "source_columns": ["other"]}
        ])


def test_joint_cluster_covers_active_members_once_and_ignores_unfitted_candidates():
    clusters = pd.DataFrame({"cluster_id": ["c1", "c1", "c1", "c2"],
                             "name": ["amount", "ratio", "unfitted", "month"]})
    units = build_units(["amount", "ratio", "month"], clusters=clusters)
    assert units[-1].name == "cluster:c1"
    assert units[-1].members == ("amount", "ratio")
    assert len(units) == 4
    assert build_units(["amount", "ratio"], clusters=clusters, units="clusters")[0].kind == "cluster"


def test_cluster_members_cell_and_feature_column_formats():
    for table in [pd.DataFrame({"cluster_id": ["a"], "members": ['["amount", "month"]']}),
                  pd.DataFrame({"cluster_id": ["a", "a"], "feature": ["amount", "month"]})]:
        unit = build_units(["amount", "month"], clusters=table, units="clusters")[0]
        assert unit.members == ("amount", "month") and unit.artificial_time_fixed


def test_mixed_profile_and_event_cluster_requires_separate_units():
    table = pd.DataFrame({"cluster_id": ["a"], "members": ["amount;profile"]})
    with pytest.raises(ValueError, match="mixes event and account"):
        build_units(["amount", "profile"], mapping(), table)


def test_family_expands_transitive_descendants_and_keeps_single_sensitivity():
    units = build_units(["amount", "ratio", "scaled", "unrelated"], mapping(),
                        unit_specs=[family_spec(dependent_outputs=["ratio"])])
    family = units[-1]
    assert family.name == "family:amount" and family.kind == "family"
    assert family.members == ("amount", "ratio", "scaled")
    assert family.dependent_outputs == ("ratio", "scaled")
    assert units[1].method == "single_output_possibly_inconsistent"
    assert units[1].dependent_outputs == ()


def test_nonpredictor_raw_source_can_drive_a_modeled_family():
    unit = build_units(["ratio", "scaled"], mapping(), unit_specs=[family_spec()])[-1]
    assert unit.source_columns == ("amount",) and unit.members == ("ratio", "scaled")


def test_profile_source_does_not_need_to_be_a_model_input():
    table = pd.DataFrame([{"name": "age", "recipe": "days_before(birth_date)",
                           "source_columns": "birth_date"}])
    unit = build_units(["age"], table, profile_fields=["birth_date"], unit_specs=[
        {"name": "family:birth_date", "method": "family", "source_columns": ["birth_date"]}
    ])[-1]
    assert unit.donor_unit == "account" and unit.members == ("age",)


@pytest.mark.parametrize("spec, message", [
    (family_spec(source_columns=["transaction_dttm"]), "cannot change time"),
    (family_spec(source_columns=["frd_tag"]), "cannot change time"),
    (family_spec(source_columns=["not_a_source"]), "no declared dependent"),
    (family_spec(members=["unrelated"]), "not an affected"),
    (family_spec(dependent_outputs=["unrelated"]), "not dependent"),
])
def test_incomplete_or_incorrect_family_definition_is_not_silently_used(spec, message):
    with pytest.raises(ValueError, match=message):
        build_units(["amount", "ratio", "scaled", "unrelated"], mapping(), unit_specs=[spec])


def test_family_needs_field_map_and_checks_cycles():
    with pytest.raises(ValueError, match="recipe field map"):
        build_units(["amount"], unit_specs=[family_spec()])
    table = mapping()
    table.loc[table.name == "ratio", "source_columns"] = "amount;scaled"
    with pytest.raises(ValueError, match="cycle"):
        build_units(["amount", "ratio", "scaled"], table, unit_specs=[family_spec()])


def test_explicit_json_plan_can_override_single_policy(tmp_path):
    path = tmp_path / "units.json"
    path.write_text('[{"name":"amount","members":["amount"],"method":"source"}]')
    unit = build_units(["amount"], unit_specs=path)[0]
    assert unit.method == "source"
    assert len(build_units(["amount"], unit_specs=[asdict(unit)])) == 1
    with pytest.raises(ValueError, match="unique nonempty"):
        build_units(["amount"], unit_specs=[asdict(unit), asdict(unit)])


def test_recompute_uses_whole_stream_and_exact_selected_recipe_order():
    frame = pd.DataFrame({"account": ["a", "a", "b"], "time": [1, 2, 3],
                          "amount": [10., 20., 30.], "limit": [2., 2., 3.],
                          "scale": [2., 2., 2.], "ratio": [0., 0., 0.],
                          "scaled": [0., 0., 0.], "unrelated": [6, 6, 6]}, index=[9, 4, 2])
    original = frame.copy(deep=True)
    family = build_units(["amount", "ratio", "scaled"], mapping(), unit_specs=[family_spec()])[-1]
    seen = []

    def builder(raw, rows, **kwargs):
        seen.append((raw.copy(), rows.name.tolist(), kwargs))
        raw["ratio"] = raw.amount / raw.limit
        raw["scaled"] = raw.ratio / raw.scale
        return raw

    changed = make_recompute(mapping(), "account", "time", "2025-05-01", recipe_builder=builder)(frame, family)
    assert seen[0][1] == ["ratio", "scaled"]
    assert seen[0][2] == {"account_col": "account", "time_col": "time", "extract_start": "2025-05-01"}
    assert_frame_equal(seen[0][0], original.drop(columns=["ratio", "scaled"]))
    assert_frame_equal(frame, original)
    assert changed.ratio.tolist() == [5., 10., 10.]
    assert changed.scaled.tolist() == [2.5, 5., 5.]
    assert_frame_equal(changed.drop(columns=["ratio", "scaled"]), frame.drop(columns=["ratio", "scaled"]))


def test_recompute_reads_raw_ancestors_even_when_not_model_predictors():
    table = pd.DataFrame([
        {"name": "scaled", "recipe": "ratio(amount; scale)", "source_columns": "amount;scale"},
        {"name": "scale", "recipe": "ratio(limit; divisor)", "source_columns": "limit;divisor"},
    ])
    family = build_units(["scaled"], table, unit_specs=[family_spec()])[-1]
    seen = []

    def builder(raw, rows, **kwargs):
        seen.append(rows.name.tolist())
        raw["scale"] = raw.limit / raw.divisor
        raw["scaled"] = raw.amount / raw.scale
        return raw

    callback = make_recompute(table, "account", "time", "2025-05-01", recipe_builder=builder)
    assert callback.required_columns(family) == ["account", "amount", "divisor", "limit", "time"]
    frame = pd.DataFrame({"amount": [8.], "limit": [4.], "divisor": [2.], "scaled": [0.]})
    changed = callback(frame, family)
    assert seen == [["scale", "scaled"]]
    assert changed.scaled.tolist() == [4.]
    assert "scale" not in changed


@pytest.mark.parametrize("fault", ["drop", "reorder", "missing", "wrong_type"])
def test_recipe_engine_failures_are_explicit(fault):
    family = build_units(["ratio", "scaled"], mapping(), unit_specs=[family_spec()])[-1]
    frame = pd.DataFrame({"amount": [1, 2], "ratio": [3, 4], "scaled": [5, 6]}, index=[5, 7])

    def builder(raw, rows, **kwargs):
        if fault == "drop": return raw.iloc[:1]
        if fault == "reorder": return raw.iloc[::-1]
        if fault == "missing": return raw.assign(ratio=0.)
        return None

    with pytest.raises(ValueError):
        make_recompute(mapping(), "account", "time", "2025-05-01", recipe_builder=builder)(frame, family)


def test_missing_recipe_engine_does_not_leave_old_values(monkeypatch):
    family = build_units(["ratio", "scaled"], mapping(), unit_specs=[family_spec()])[-1]

    def missing(name): raise ImportError(name)

    monkeypatch.setattr(importlib, "import_module", missing)
    with pytest.raises(RuntimeError, match="nf_recipes module"):
        make_recompute(mapping(), "account", "time", "2025-05-01")(pd.DataFrame(), family)


def test_recompute_existing_enriched_output_with_create_only_recipe_builder():
    table = pd.DataFrame([
        {"name": "ratio", "recipe": "ratio(amount; limit)", "source_columns": "amount;limit",
         "model_type": "continuous"},
    ])
    family = build_units(["amount", "ratio"], table, unit_specs=[family_spec()])[-1]
    frame = pd.DataFrame({"account": ["a", "a", "b"], "time": [3, 1, 2],
                          "amount": [10., 20., 30.], "limit": [2., 2., 3.],
                          "ratio": [-1., -1., -1.], "unrelated": [6, 7, 8]}, index=[9, 4, 2])
    original = frame.copy(deep=True)

    def builder(raw, selected, **kwargs):
        # The shared engine rejects an engineered name already in its input.
        assert not set(selected.name).intersection(raw.columns)
        assert "unrelated" in raw
        return raw.assign(ratio=raw.amount / raw.limit)

    callback = make_recompute(table, "account", "time", "2025-05-01", recipe_builder=builder)
    changed = callback(frame, family)
    assert changed.ratio.tolist() == [5., 10., 10.]
    assert_frame_equal(changed.drop(columns="ratio"), original.drop(columns="ratio"))
    assert_frame_equal(frame, original)
