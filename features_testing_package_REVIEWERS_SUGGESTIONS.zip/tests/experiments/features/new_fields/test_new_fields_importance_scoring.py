"""Real scorer checks for source-row interventions and unchanged history geometry."""
from pathlib import Path
import hashlib
import sys

import numpy as np
import pandas as pd
import pytest
import torch

NF = Path(__file__).resolve().parents[4] / "fraud/experiments/features/new_fields"
sys.path.insert(0, str(NF))
from nf_importance_scoring import ScoreRunner
from nf_permutation import Unit
from test_new_fields_importance_world import synthetic_world


@pytest.fixture
def world(tmp_path):
    return synthetic_world(tmp_path)


def runner(world, **kwargs):
    cfg, path, _, scorer = world
    return ScoreRunner(cfg, path, scorer=scorer, account_share=kwargs.pop("account_share", 1), **kwargs)


def direct_scores(world):
    cfg, path, _, scorer = world
    loaded = scorer.load_for_scoring(cfg, str(path))
    rows = []
    for batch in loaded["loader"]:
        with torch.no_grad():
            logits = loaded["model"](scorer._model_inputs(batch, loaded["device"])).cpu()
        prob, label, metadata = scorer.select(logits, batch, loaded["chunk"])
        rows.append(pd.DataFrame({"account": metadata["account"], "id": metadata["id"],
                                  "score": prob, "label": label}))
    return pd.concat(rows, ignore_index=True)


def test_identity_is_bitwise_real_scorer_and_files_unchanged(world, tmp_path):
    before = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in tmp_path.rglob("*") if p.is_file()}
    r = runner(world)
    plain = direct_scores(world)
    identity = r.score(Unit("amount", ["amount"]), identity=True)
    pd.testing.assert_frame_equal(identity.all_data[list(plain)], plain, check_exact=True)
    assert r.verify_identity(Unit("month", ["month"], artificial_time_fixed=True))["bitwise_equal"]
    after = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in tmp_path.rglob("*") if p.is_file()}
    assert before == after


def test_original_amount_used_for_metrics_and_geometry_is_fixed(world):
    r = runner(world)
    plain = r.score()
    changed = r.score(Unit("amount", ["amount"]))
    pd.testing.assert_frame_equal(plain.all_data.drop(columns="score"), changed.all_data.drop(columns="score"))
    assert not np.array_equal(plain.all_data.score, changed.all_data.score)
    assert len(changed.data) == 3 * world[2].account.nunique()
    assert changed.data.window_rows.min() > 1  # May history still exists for June targets.
    assert changed.coverage["configured_workers"] == changed.coverage["used_workers"] == 0


def test_account_subsample_keeps_entire_histories_and_repeats_match(world):
    r = runner(world, account_share=0.5)
    first, second = r.score(), r.score()
    pd.testing.assert_frame_equal(first.all_data, second.all_data, check_exact=True)
    assert 0 < first.coverage["selected_accounts"] < first.coverage["raw_accounts"]
    assert set(first.all_data.groupby("account").size()) == {6}
    assert len(first.data) == 3 * first.coverage["selected_accounts"]


def test_calendar_is_actually_perturbed_even_though_time_is_fixed(world):
    r = runner(world)
    plain = r.score()
    changed = r.score(Unit("month", ["month"], artificial_time_fixed=True))
    assert not np.array_equal(plain.all_data.score, changed.all_data.score)
    pd.testing.assert_series_equal(plain.all_data.timestamp, changed.all_data.timestamp)


def test_wrapper_restored_after_recipe_failure(world):
    def fail(frame, unit):
        raise ValueError("planted recipe failure")
    r = runner(world, recompute=fail)
    cols, files = r.dataset._read_cols, r.dataset.file_list
    unit = Unit("family", ["amount"], method="family", source_columns=["amount"], dependent_outputs=["profile"])
    with pytest.raises(ValueError, match="planted recipe failure"):
        r.score(unit)
    assert r.dataset._encode_file == r._original_encode
    assert r.dataset._read_cols is cols and r.dataset.file_list is files
    assert len(r.score().data)


def test_no_silent_account_overlap_between_files(tmp_path):
    world = synthetic_world(tmp_path, files=2)
    frame = world[2]
    pd.concat([pd.read_parquet(tmp_path / "data/part_8229.parquet"), frame[frame.account == "a0000"]]).to_parquet(
        tmp_path / "data/part_8229.parquet", index=False)
    with pytest.raises(ValueError, match="account spans"):
        runner(world).score()


def test_unknown_predictor_fails_before_scores_are_reported(world):
    with pytest.raises(ValueError):
        runner(world).score(Unit("unknown", ["not_a_feature"]))


def test_attention_covers_only_june_target_slots(world):
    r = runner(world)
    plain = r.score()
    captured = r.score(attention=True)
    pd.testing.assert_frame_equal(plain.all_data, captured.all_data, check_exact=True)
    assert captured.attention["target_rows"] == len(captured.data)
    assert set(captured.attention["features"]) == set(r.feature_names + ["time_delta"])


def test_one_source_value_is_identical_in_target_and_history_copies(world, monkeypatch):
    r = runner(world)
    scorer = world[3]
    original = scorer._model_inputs
    values, roles = {}, {}

    def inspect(batch, device):
        meta, live = batch["meta_seq"], batch["mask"].numpy()
        encoded = batch["continuous"].numpy()
        target_slot = live.sum(axis=1) - 1
        for i, j in zip(*np.where(live)):
            key = (meta["account"][i, j], meta["id"][i, j])
            # The last channel is the window-edge time gap, not the perturbed amount.
            value = encoded[i, j, 0]
            if key in values:
                assert values[key] == value
            values[key] = value
            roles.setdefault(key, set()).add("target" if j == target_slot[i] else "history")
        return original(batch, device)

    monkeypatch.setattr(scorer, "_model_inputs", inspect)
    r.score(Unit("amount", ["amount"]))
    assert len(values) == len(world[2])
    assert sum(len(v) == 2 for v in roles.values()) > len(world[2]) / 2


def test_family_recomputes_with_unmodified_auxiliary_raw_columns(world):
    cfg, path, raw, scorer = world
    raw = raw.assign(offset=np.arange(len(raw), dtype=float))
    raw.to_parquet(Path(cfg.eval.base) / "part_8228.parquet", index=False)
    called = []

    def rebuild(frame, unit):
        called.append(len(frame))
        assert "offset" in frame
        return frame.assign(profile=frame.amount + frame.offset)

    rebuild.required_columns = lambda unit: ["offset"]
    r = runner(world, recompute=rebuild)
    plain = r.score()
    unit = Unit("amount_family", ["amount", "profile"], method="family",
                source_columns=["amount"], dependent_outputs=["profile"])
    changed = r.score(unit)
    assert called == [len(raw)]
    pd.testing.assert_frame_equal(plain.all_data.drop(columns="score"), changed.all_data.drop(columns="score"))
    assert not np.array_equal(plain.all_data.score, changed.all_data.score)
    assert changed.audit[0]["method"] == "family"
    assert changed.audit[0]["dependent_outputs"] == ["profile"]


def test_account_profile_donor_keeps_static_profile_and_same_target_population(world):
    r = runner(world)
    base = r.score()
    unit = Unit("profile", ["profile"], method="source", donor_unit="account")
    changed = r.score(unit)
    assert changed.audit[0]["donor_unit"] == "account"
    pd.testing.assert_frame_equal(base.all_data.drop(columns="score"), changed.all_data.drop(columns="score"))
    assert not np.array_equal(base.all_data.score, changed.all_data.score)



def test_first_file_without_june_still_supports_identity_and_attention_probe(tmp_path):
    world = synthetic_world(tmp_path, files=2)
    path = Path(world[0].eval.base) / "part_8228.parquet"
    first_file = pd.read_parquet(path)
    first_file["time"] -= pd.Timedelta(days=2)
    first_file.to_parquet(path, index=False)
    r = runner(world)
    plain = r.score(file_limit=1)
    captured = r.score(attention=True, file_limit=1)
    assert captured.data.empty
    assert len(captured.all_data) == len(first_file)
    assert captured.attention == {"target_rows": 0, "reason": "no June targets in this pass"}
    pd.testing.assert_frame_equal(plain.all_data, captured.all_data, check_exact=True)
    assert r.verify_identity(Unit("amount", ["amount"]), file_limit=1)["bitwise_equal"]
    full = r.score(attention=True)
    assert len(full.data) > 0
    assert full.attention["target_rows"] == len(full.data)


def test_attention_errors_are_not_suppressed_when_june_targets_exist(world, monkeypatch):
    from nf_attention import AttentionCapture

    def fail(self):
        raise ValueError("incomplete layer observations")

    monkeypatch.setattr(AttentionCapture, "result", fail)
    with pytest.raises(ValueError, match="incomplete layer observations"):
        runner(world).score(attention=True)
