"""The reviewers' decisions of 2 November in the feature workbook: an adopted month-out step drops month from the
Final list and the predictor export (D4c), and each kept row's entered_at step (D3a). Synthetic edits of the
shipped lists."""
import csv

from openpyxl import load_workbook

from test_new_fields_workbook_build import LISTS, build, inputs, rows, sheet_rows  # noqa: F401


def _append(path, row):
    with open(path, newline="", encoding="utf-8") as f:
        header = next(csv.reader(f))
    with open(path, "a", newline="", encoding="utf-8") as f:
        csv.DictWriter(f, fieldnames=header, lineterminator="\n").writerow(row)


MONTH_OUT = {"name": "month", "group": "base", "verdict": "drop",
             "reason": "month out adopted by the month rule and its SELECT check", "evidence": "read:reads/B_1seed.json",
             "decided_by": "reviewers (decision D4c and the month rule)", "date": "2026-11-20", "definition_version": "1"}


def test_an_adopted_month_out_drops_month_from_the_final_list_and_the_export(inputs, tmp_path):
    out, pred = tmp_path / "wb.xlsx", tmp_path / "pred.csv"
    assert build(inputs, out, "--export-predictors", str(pred)) == 0
    _, final = sheet_rows(load_workbook(out)["Final list (draft)"])
    assert "month" in {r["feature"] for r in final} and "month" in {r["feature"] for r in rows(pred)}
    readme = " ".join(str(c) for row in load_workbook(out)["README"].iter_rows(values_only=True) for c in row if c)
    assert "Month stays in until the month-out step reads" in readme and "(owner, 2 November)" not in readme
    _append(inputs / LISTS[4], MONTH_OUT)
    assert build(inputs, out, "--export-predictors", str(pred)) == 0
    wb = load_workbook(out)
    _, final = sheet_rows(wb["Final list (draft)"])
    assert "month" not in {r["feature"] for r in final}
    assert "month" not in {r["feature"] for r in rows(pred)} and len(rows(pred)) == 22
    readme = " ".join(str(c) for row in wb["README"].iter_rows(values_only=True) for c in row if c)
    assert "Month leaves: the month-out step was adopted under the month rule" in readme
    _, cur = sheet_rows(wb["Current features"])
    assert [r["verdict"] for r in cur if r["feature"] == "month"] == ["drop"]


def test_a_row_in_both_lists_enters_at_a2_when_a1_kept_its_control(inputs, tmp_path):
    out = tmp_path / "wb.xlsx"
    keep = rows(inputs / LISTS[4])
    both = [r["name"] for r in keep if r["group"] == "both" and r["verdict"] == "keep"]
    assert both
    assert build(inputs, out) == 0
    header, final = sheet_rows(load_workbook(out)["Final list (draft)"])
    assert header.index("entered_at") == header.index("group") + 1
    at = {r["feature"]: r["entered_at"] for r in final}
    assert at[both[0]] == "A1" and all(at[r["name"]] == "A1" for r in keep if r["group"] == "v22b"
                                       and r["verdict"] == "keep")
    assert build(inputs, out, "--a1-adopted", "no") == 0
    at = {r["feature"]: r["entered_at"] for r in sheet_rows(load_workbook(out)["Final list (draft)"])[1]}
    assert at[both[0]] == "A2"
    assert all(at[r["name"]] == "A2" for r in keep if r["group"] == "f15298" and r["verdict"] == "keep")


def test_the_readme_says_the_reviewers_decide_the_month_like_hold(inputs, tmp_path):
    """D3d as amended on 3 November: a month-like field waits for the reviewers' recorded keep or drop and reason in
    the decisions table, under the owner's delegation; the owner is asked only for a missing source fact or a
    preference, and no owner signature is needed."""
    out = tmp_path / "wb.xlsx"
    assert build(inputs, out) == 0
    readme = " ".join(str(c) for row in load_workbook(out)["README"].iter_rows(values_only=True) for c in row if c)
    assert ("waits until the reviewers record keep or drop and the reason in KEEP_DECISIONS.csv, under the owner's "
            "delegation; no owner signature is needed") in readme
    assert "Exact month duplicates stay represented once; month stays." in readme
    assert "A warning never shortens a declared history window." in readme
    assert "decided by the reviewers under the owner's delegation" in readme
    assert "The owner is asked only for a missing source fact or a preference." in readme
