"""The reviewers' decisions of 2 November in the intake's check-map and the field checks' map stage: the a3 rows
today's builder call cannot produce (D4a), a row in both lists that Sumegha excluded (D3a), the same output written
as two rows (D3a). Synthetic maps only."""
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_new_fields_spine_intake import C, I, check, row  # noqa: E402
from new_fields_checks_helpers import load  # noqa: E402

R = load("nf_checks_rules")
F = load("nf_field_checks")


def _reasons(x):
    return " | ".join(x["reasons"])


def test_unbuildable_a3_rows_are_listed_with_their_reason():
    _, res = check([row(name="cp_cnt_5m_log1p", group="a3", kind="engineered", recipe="a3(cp_cnt_5m_log1p)",
                        model_type="continuous", source_columns=""),
                    row(name="dist_home_km_log1p", group="a3", kind="engineered", recipe="a3(dist_home_km_log1p)",
                        model_type="continuous", source_columns="")])
    assert "FLAG a3_unbuildable" in _reasons(res["cp_cnt_5m_log1p"])
    assert "card-present and card-absent code values" in _reasons(res["cp_cnt_5m_log1p"])
    assert "postal-centroid table" in _reasons(res["dist_home_km_log1p"])
    _, res = check([row(name="amt_z_30d", group="a3", kind="engineered", recipe="a3(amt_z_30d)",
                        model_type="continuous", source_columns="")])
    assert "a3_unbuildable" not in _reasons(res["amt_z_30d"])


def test_a_row_in_both_lists_excluded_by_sumegha_moves_to_15298_and_waits(tmp_path, monkeypatch):
    monkeypatch.setattr(C, "person_decisions", lambda path=None: {})
    df, res = check([row(name="pos_entry_mode_xcd", group="both", excluded_by_sumegha="yes",
                         sumegha_reason="not in production")])
    assert df.loc[0, "group"] == "f15298" and "regrouped from both to f15298" in df.loc[0, "notes"]
    assert "WAIT sumegha_15298" in _reasons(res["pos_entry_mode_xcd"])
    assert "STOP excluded_by_sumegha" not in _reasons(res["pos_entry_mode_xcd"])
    # a person's keep row clears it, for A2 only
    monkeypatch.setattr(C, "person_decisions", lambda path=None: {"pos_entry_mode_xcd": {"verdict": "keep"}})
    _, res = check([row(name="pos_entry_mode_xcd", group="both", excluded_by_sumegha="yes")])
    assert "sumegha_15298" not in _reasons(res["pos_entry_mode_xcd"])
    # a V22B row stays stopped
    _, res = check([row(name="pos_entry_mode_xcd", group="v22b", excluded_by_sumegha="yes")])
    assert "STOP excluded_by_sumegha" in _reasons(res["pos_entry_mode_xcd"])


def test_the_same_output_in_two_rows_is_flagged_once():
    _, res = check([row(name="merchant_category_xcd", group="v22b"),
                    row(name="mcc_code", group="f15298", kind="engineered", recipe="code(merchant_category_xcd)",
                        source_columns="merchant_category_xcd"),
                    row(name="mcc_cnt_14d", group="f15298", kind="engineered",
                        recipe="count(14d; same=merchant_category_xcd)", source_columns="merchant_category_xcd",
                        model_type="continuous")])
    assert "FLAG same_feature_two_rows: the same output as merchant_category_xcd" in _reasons(res["mcc_code"])
    assert "same_feature_two_rows" not in _reasons(res["mcc_cnt_14d"])
    assert "same_feature_two_rows" not in _reasons(res["merchant_category_xcd"])


def _specs(rows, decisions=None):
    cols = load("nf_checks_synth").map_columns()
    fm = pd.DataFrame([{**{c: "" for c in cols}, "feasible_in_production": "yes", **r} for r in rows])
    return {s["name"]: s for s in F.field_specs(fm, [], R.Thresholds({}), [], "acct", decisions)}


def test_the_checks_wait_on_a_15298_twin_of_an_excluded_feature():
    sp = _specs([{"name": "f_v", "group": "v22b", "recipe": "raw", "excluded_by_sumegha": "yes"},
                 {"name": "f_w", "group": "f15298", "recipe": "raw", "excluded_by_sumegha": "yes"}])
    assert sp["f_v"]["flags"].get("excluded_by_sumegha") and "sumegha_15298" not in sp["f_v"]["flags"]
    assert "sumegha_15298" in sp["f_w"]["flags"] and not sp["f_w"]["flags"].get("excluded_by_sumegha")
    rules = {rule: res for res, rule, _ in R.evaluate({"sumegha_15298": "x", "measured": True}, R.Thresholds({}))}
    assert rules["sumegha_15298"] == "WAIT"
    rules = {rule: res for res, rule, _ in R.evaluate({"sumegha_15298": "x", "keep_written": "the owner 2026-11-03",
                                                       "measured": True}, R.Thresholds({}))}
    assert rules["sumegha_15298"] == "FLAG"


# ------------------------------------------------------------------ D9-Y16 and D10: the feature summary


def test_the_summary_counts_the_nearly_constant_missing_flags_and_the_prior_actions(tmp_path):
    FS = load("nf_feature_summary")
    ck = tmp_path / "checks"
    ck.mkdir()
    names = [("f_never", 0, 0), ("f_five", 5, 2), ("f_many", 500, 40)]
    pd.DataFrame([{"field": n, "group": "f15298", "kind": "engineered", "result": "PASS", "reasons": "",
                   "cluster_id": "", "kept_once_as": ""} for n, _, _ in names] +
                 [{"field": "prev_adv", "group": "f15298", "kind": "engineered", "result": "PASS", "reasons": "",
                   "cluster_id": "", "kept_once_as": ""}]).to_csv(ck / "field_status.csv", index=False)
    pd.DataFrame([{"field": n, "range": "train", "model_type": "continuous", "train_missing_rows": m,
                   "train_missing_frauds": f, "train_nonnull": 10_000 - m, "train_rows": 10_000}
                  for n, m, f in names] +
                 [{"field": "prev_adv", "range": "train", "model_type": "categorical", "train_missing_rows": 9_000,
                   "train_missing_frauds": 3, "train_nonnull": 1_000, "train_rows": 10_000}]).to_csv(
        ck / "field_checks.csv", index=False)
    pd.DataFrame([{"name": n, "list_status": "CONFIRMED", "recipe": "count(24h)", "definition_version": "1"}
                  for n, _, _ in names] +
                 [{"name": "prev_adv", "list_status": "CONFIRMED", "recipe": "prev(advice_xcd)",
                   "definition_version": "1"}]).to_csv(ck / "FIELD_MAP_checked.csv", index=False)
    df = FS.build(ck, None, None)
    lines, flags = FS.missing_report(df, ck)
    assert flags == "flags of new fields missing on fewer than 10 rows: 2 of 3 tokens (66.7%)"
    text = "\n".join(lines)
    assert "f_five: missing 5 rows, frauds among them 2" in text and "f_many: missing 500 rows, frauds among them 40" in text
    assert "prev_adv: 10.00% of rows" in text
    assert "A count below 10 rows is sparse information, not proof that the flag has no value." in text   # D9-Y16
    assert FS.main(["--checks", str(ck)]) == 0
    assert flags in (ck / "feature_summary.txt").read_text() and (ck / "feature_missing.txt").exists()
