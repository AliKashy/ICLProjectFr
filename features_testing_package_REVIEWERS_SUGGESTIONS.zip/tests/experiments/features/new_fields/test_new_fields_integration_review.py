"""Part B: the other reviewer's findings on part A and the verifier's notes on this lane, each with a test that
fails on part A and passes now.

FP-01: the field checks' temporal probes group by the recipe's own history key (key=customer or a card column),
as the recipe engine groups, so a correct customer- or card-keyed field is not stopped as not strictly earlier,
and a leaky one still is. Same-second siblings get ids of the stored ids' kind (numbers stay numbers).
FP-05: every command in POD.md runs as written: each starts with its program, and every variable and folder it
uses is set at the top (C2 among them).
FP-06: the morning report shows a fit as the planner sees it (nf_plan.fit_state): a dead trainer's lock is
INCOMPLETE in both, a live one RUNNING in both, also before the trainer's manifest says running.
FP-07: the queue lock is taken in one atomic step, so two queues started at the same moment never both own it,
also when both replace a stale lock; a lock that names no process (zero, below zero, too large, not a number)
refuses. The field checks: an engineered field on a column a file lacks (also one its source_columns leave out, or
one only the vocabulary fit file lacks) is not built and ends as a STOP row, and every other field keeps its
result. An a3 field is built from all six inputs of the 26 October builders and its same-second probe keeps
the stored precision. The data tools name a missing field_status.csv from the project root. Synthetic data
only."""
import json
import os
import re
import socket
import subprocess
import sys
import time
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from new_fields_checks_helpers import load  # noqa: E402
import new_fields_data_world as W  # noqa: E402
from new_fields_spine_world import default_map, make_world, run  # noqa: E402

ROOT = HERE.parents[3]
NF = ROOT / "fraud" / "experiments" / "features" / "new_fields"
DEAD = 999999999            # above any pid the system gives: never a live process


# ------------------------------------------------------------------ FP-01: the probes group by the recipe's key

VALID = [   # the reviewer's three customer recipes, the same on a card key, and an account recipe
    ("cust_mean_30d", "mean(30d; value=transaction_amt; key=customer_xid)", "transaction_amt;customer_xid"),
    ("cust_count_30d", "count(30d; key=customer_xid)", "customer_xid"),
    ("cust_prev_amt", "prev(transaction_amt; key=customer_xid)", "transaction_amt;customer_xid"),
    ("card_mean_30d", "mean(30d; value=transaction_amt; key=card_xid)", "transaction_amt;card_xid"),
    ("card_count_30d", "count(30d; key=card_xid)", "card_xid"),
    ("card_prev_amt", "prev(transaction_amt; key=card_xid)", "transaction_amt;card_xid"),
    ("acct_count_30d", "count(30d)", ""),
]
LEAKY = [
    ("cust_mean_all_rows", "leak_mean(30d; value=transaction_amt; key=customer_xid)", "transaction_amt;customer_xid"),
    ("cust_count_same_second", "leak_count(30d; key=customer_xid)", "customer_xid"),
]


def _history():
    """12 accounts; accounts 2k and 2k+1 share a customer; each account has two cards."""
    df = W.history(accounts=12, per_account=30, start="2024-10-01")
    rng = np.random.default_rng(5)
    df["card_xid"] = df[W.ACCOUNT] + "_c" + rng.integers(0, 2, len(df)).astype(str)
    return df


def _leak_mean(spec, frame, extract_start):
    """Planted fault: the customer's mean amount over all of its rows in the file, later rows included."""
    amt = pd.to_numeric(frame["transaction_amt"], errors="coerce")
    return amt.groupby(frame["customer_xid"].astype(str).to_numpy()).transform("mean").astype(float), None


def _leak_count(spec, frame, extract_start):
    """Planted fault: the customer's other rows up to and including the row's own second (its same-second
    siblings count), not only the strictly earlier ones."""
    key = frame["customer_xid"].astype(str).to_numpy()
    sec = pd.to_datetime(frame[W.TIME]).to_numpy(dtype="datetime64[s]").astype(np.int64)
    out = np.zeros(len(frame))
    for k in np.unique(key):
        idx = np.flatnonzero(key == k)
        ss = np.sort(sec[idx])
        out[idx] = np.searchsorted(ss, sec[idx], side="right") - 1
    return pd.Series(out, index=frame.index), None


def _checks(tmp_path, rows, frame, probe_units=500):
    F = load("nf_field_checks")
    RL = load("nf_checks_rules")
    nc = load("nf_common")
    R = F._load("nf_recipes")
    th = RL.Thresholds(nc.load_yaml(NF / "CHECK_THRESHOLDS.yaml"))
    fmap = pd.DataFrame([{"name": n, "group": "f15298", "kind": "engineered", "recipe": r, "source_columns": src,
                          "model_type": "continuous"} for n, r, src in rows])
    specs = F.field_specs(fmap, [], th, [], W.ACCOUNT, {}, recipes=R)
    a = SimpleNamespace(seed=20261102, probe_accounts=probe_units, train_extract_start="2024-10-01",
                        account_col=W.ACCOUNT, time_col=W.TIME, id_col=W.TIE, label_col="frd_tag", batch_fields=50)
    builder = F.Builder(R, {"leak_mean": _leak_mean, "leak_count": _leak_count}, W.ACCOUNT, W.TIME)
    train = tmp_path / "train"
    train.mkdir(exist_ok=True)
    frame.to_parquet(train / "part_1.parquet", index=False)
    ck = F.Checks(a, th, "t" * 64, "m" * 64, specs, {"table": pd.DataFrame({"feature": []})}, builder,
                  F.Files(None), tmp_path / "out", log=lambda *x: None)
    return ck, th, RL, str(train)


def test_customer_and_card_keyed_recipes_pass_every_probe(tmp_path):
    ck, th, RL, base = _checks(tmp_path, VALID, _history())
    ck.probes(base, 1)
    for name, recipe, _ in VALID:
        probes = ck.m[name]["probes"]
        bad = [k for k, v in probes.items() if v is False]
        assert not bad, (name, probes)
        key = re.search(r"key=(\w+)", recipe)
        assert probes["history_key"] == (key.group(1) if key else W.ACCOUNT)
        assert not [r for r in RL.evaluate({"measured": True, "probes": probes}, th) if r[1] == "not_strictly_earlier"]


def test_a_leaky_customer_recipe_still_stops(tmp_path):
    ck, th, RL, base = _checks(tmp_path, VALID[:1] + LEAKY, _history())
    ck.probes(base, 1)
    mean = ck.m["cust_mean_all_rows"]["probes"]       # reads the customer's later rows
    assert mean["history_key"] == "customer_xid"
    assert mean["future_invariance"] is False and mean["future_deletion"] is False
    count = ck.m["cust_count_same_second"]["probes"]  # counts the row's own same-second siblings
    assert count["same_second"] is False
    for name, _, _ in LEAKY:
        res = RL.evaluate({"measured": True, "probes": ck.m[name]["probes"]}, th)
        assert any(r[0] == "STOP" and r[1] == "not_strictly_earlier" for r in res), (name, res)


def test_the_probe_rows_are_whole_histories_of_the_key(tmp_path):
    df = _history()
    ck, _, _, _ = _checks(tmp_path, VALID, df, probe_units=3)
    # the account key: the same accounts and rows as before keys were read from the recipe
    accts = df[W.ACCOUNT].astype(str)
    u = np.array(sorted(accts.unique()))
    pick = set(np.random.default_rng(20261102).choice(u, size=3, replace=False))
    old = df[accts.isin(pick).to_numpy()].reset_index(drop=True)
    pd.testing.assert_frame_equal(ck._probe_rows(df, W.ACCOUNT), old)
    # the customer key: three customers, each with all of its rows (both of its accounts)
    fr = ck._probe_rows(df, "customer_xid")
    assert fr["customer_xid"].nunique() == 3
    for c, n in fr["customer_xid"].value_counts().items():
        assert n == int((df["customer_xid"] == c).sum()) and fr.loc[fr.customer_xid == c, W.ACCOUNT].nunique() == 2


def test_same_second_siblings_keep_the_ids_kind():
    M = load("nf_checks_measure")
    F = load("nf_field_checks")
    R = F._load("nf_recipes")
    assert M.sibling_ids(pd.Series([7, 12, 9]), 2) == [13, 14]
    assert M.sibling_ids(pd.Series([7.0, None, 9.0]), 1) == [10]
    assert M.sibling_ids(pd.Series(["t1", "t2"]), 2) == ["probe_sibling_0", "probe_sibling_1"]
    # two rows of one account at the same instant, ids 9 and 10; the next row's prev reads the later of them (10)
    t0 = pd.Timestamp("2024-11-01 10:00:00")
    rows = [("a1", t0, 9, 1.0), ("a1", t0, 10, 2.0), ("a1", t0 + pd.Timedelta(seconds=60), 11, 3.0),
            ("a1", t0 + pd.Timedelta(seconds=120), 12, 4.0)]
    rows += [(f"a{k}", t0 + pd.Timedelta(seconds=7 * j + k), 1000 + 3 * k + j, float(j))
             for k in range(2, 30) for j in range(3)]
    df = pd.DataFrame(rows, columns=[W.ACCOUNT, W.TIME, W.TIE, "transaction_amt"])
    df["frd_tag"] = 0
    b = F.Builder(R, account=W.ACCOUNT, time=W.TIME)
    spec = {"name": "p", "recipe": "prev(transaction_amt)", "fn": "prev", "sources": ["transaction_amt"],
            "row": {"model_type": "continuous"}}

    def build(fr):
        return b.build(spec, fr, "2024-10-01")[0]

    assert build(df).iloc[2:4].tolist() == [2.0, 3.0]
    # a text id among the numbers made the engine order every id as text (10 before 9): a false failure
    assert all(M.probe_same_second(df, build, ["transaction_amt"], W.ACCOUNT, W.TIME, W.TIE, seed=s)["ok"]
               for s in range(40))


# ------------------------------------------------------------------ FP-05: every POD.md command runs as written

POD = NF / "POD.md"
PROGRAMS = ("tail", "cat", "tensorboard", "bash", "nice")       # and $PY, or any program held in a variable
# the tools' subcommands: inline code that starts with one of them and gives options was meant as a command
SUBCOMMANDS = {"width", "real", "chunks", "encode", "preflight", "next", "plan", "busy", "queue", "schema", "draft",
               "check-map", "adopt", "definitions", "spread", "read", "select-check", "lift", "report", "run",
               "estimate", "use2"}


def _is_command(c):
    first = c.split()[0]
    return (first in PROGRAMS or first.startswith("$") or bool(re.match(r"[A-Z_][A-Z0-9_]*=", first))
            or (first in SUBCOMMANDS and " --" in c))


def _commands():
    """(the block that sets the variables, each command a person types from POD.md): inline code that starts with
    a program, a variable or an assignment (or with a subcommand and options), and each line of the other code
    blocks (comments left out, continuation lines joined)."""
    text = POD.read_text(encoding="utf-8")
    blocks = re.findall(r"```\n(.*?)```", text, flags=re.S)
    inline = re.findall(r"`([^`\n]+)`", re.sub(r"```\n.*?```", "", text, flags=re.S))
    cmds = [c for c in inline if c.strip() and _is_command(c)]
    for b in blocks[1:]:
        for ln in re.sub(r"\\\n\s*", " ", b).splitlines():
            ln = ln.strip()
            if ln and not ln.startswith("#"):
                cmds.append(ln.split("  #")[0].strip())
    return (blocks[0] if blocks else ""), cmds


def test_pod_commands_start_with_their_program_and_use_only_set_variables():
    setup, cmds = _commands()
    defined = set(re.findall(r"^([A-Z][A-Z0-9_]*)=", setup, flags=re.M))
    assert {"PY", "NF", "FS", "C2"} <= defined, setup
    assert cmds
    for c in cmds:
        words = c.split()
        first = next((x for x in words if not re.match(r"[A-Z_][A-Z0-9_]*=", x)), "")
        assert first in PROGRAMS or first.startswith("$") or first == "", c   # a program, never a bare subcommand
        for v, default in re.findall(r"\$\{?([A-Za-z_][A-Za-z0-9_]*)(:-)?", c):
            assert v in defined or default, (v, c)
        assert not re.search(r"(?<![$\w/.])(C2|NF|FS)/", c), c                # a folder by its variable
    text = POD.read_text(encoding="utf-8")
    assert "`$PY $NF/nf_time_width.py real --config" in text


def test_pod_log_commands_run_literally(tmp_path):
    setup, cmds = _commands()
    setup = re.sub(r"=<[^>\n]*>", "=python3", setup)      # the pod's Python: any Python here
    c2 = tmp_path / "proj" / "checkpoints" / "new_fields"
    (c2 / "reads").mkdir(parents=True)
    (c2 / "queue.log").write_text("queue start\n")
    (c2 / "reads" / "A1_1seed.txt").write_text("A1 read\n")
    for c in cmds:
        if c.split()[0] in ("tail", "cat"):
            line = c.replace("<step>_<n>seed", "A1_1seed")
            r = subprocess.run(["bash", "-c", setup + "\n" + line], cwd=tmp_path / "proj", capture_output=True,
                               text=True, env={"PATH": os.environ.get("PATH", "/usr/bin:/bin")}, timeout=60)
            assert r.returncode == 0 and r.stdout.strip(), (line, r.stderr)


# ------------------------------------------------------------------ FP-06: the report and the planner agree

def _crashed_fit(w, lock_pid, host=None, manifest=True):
    c2 = w / "checkpoints" / "new_fields"
    d = c2 / "runs" / "nf_a1" / "seed42"
    d.mkdir(parents=True, exist_ok=True)
    m = d / "run_manifest_v2.json"
    if manifest:
        m.write_text(json.dumps({"status": "running", "start": {"utc": "2026-11-02T01:00:00Z"}}))
    elif m.exists():
        m.unlink()
    (d / "RUNNING.lock.json").write_text(json.dumps({"pid": lock_pid, "hostname": host or socket.gethostname(),
                                                     "utc": "2026-11-02T01:00:00Z"}))
    (c2 / "queue.log").write_text("queue start 2026-11-02T00:59:00Z pid 1\n"
                                  "start fit_nf_a1_seed42 2026-11-02T01:00:00Z\n")
    return c2, d


def _report_row(w, tmp_path):
    r = run(w, tmp_path, "nf_report.py")
    assert r.returncode == 0, r.stderr
    lines = r.stdout.splitlines()
    assert len(lines) <= 40 and max(map(len, lines)) <= 90
    row = [x for x in lines if x.startswith("nf_a1 ")]
    assert len(row) == 1, r.stdout
    return row[0].split()[2], r.stdout


def test_the_report_shows_a_fit_as_the_planner_does(tmp_path, monkeypatch):
    w = make_world(tmp_path, map_rows=default_map(), field_status={"f_code": "PASS", "f_cnt24": "FLAG",
                                                                     "f_amt": "PASS"})
    monkeypatch.setenv("NF_OUT", str(w / "checkpoints" / "new_fields"))
    P = load("nf_plan")
    # the trainer and the queue were killed (a crash or a pod restart): both locks name a dead process
    c2, d = _crashed_fit(w, DEAD)
    (c2 / "QUEUE.lock.json").write_text(json.dumps({"pid": DEAD, "hostname": socket.gethostname(), "utc": "t"}))
    assert P.fit_state(d) == "INCOMPLETE"
    state, text = _report_row(w, tmp_path)
    assert state == "INCOMPLETE" and "RUNNING" not in text and "(running:" not in text
    assert "interrupted by a crash or a restart, not running: fit_nf_a1_seed42" in text
    # a lock of another host is another workbench's trainer on the shared folder: running in both, never incomplete
    _crashed_fit(w, os.getpid(), host="another-host")
    assert P.fit_state(d) == "RUNNING" and _report_row(w, tmp_path)[0] == "RUNNING"
    # a live trainer on this host: running in both, also before its manifest says running
    live = subprocess.Popen(["sleep", "60"])
    try:
        for manifest in (True, False):
            _crashed_fit(w, live.pid, manifest=manifest)
            assert P.fit_state(d) == "RUNNING"
            state, text = _report_row(w, tmp_path)
            assert state == "RUNNING" and "(running: fit_nf_a1_seed42)" in text and "interrupted" not in text
    finally:
        live.kill()
        live.wait()
    # the trainer is gone: both say incomplete again
    assert P.fit_state(d) == "INCOMPLETE" and _report_row(w, tmp_path)[0] == "INCOMPLETE"


def test_the_report_lists_a_started_job_as_running_only_while_its_queue_runs(tmp_path):
    w = make_world(tmp_path, map_rows=default_map(), field_status={"f_code": "PASS", "f_cnt24": "FLAG",
                                                                     "f_amt": "PASS"})
    c2 = w / "checkpoints" / "new_fields"
    (c2 / "queue.log").write_text("queue start 2026-11-02T00:59:00Z pid 1\n"
                                  "start score_control_seed42__rank_b 2026-11-02T01:00:00Z\n"
                                  "end score_control_seed42__rank_b rc=0 2026-11-02T01:10:00Z\n"
                                  "start fit_nf_a1_seed42 2026-11-02T01:10:01Z\n")   # its trainer has no folder yet
    queue_shell = subprocess.Popen(["sleep", "60"])
    try:
        for pid, running in ((queue_shell.pid, True), (DEAD, False)):
            (c2 / "QUEUE.lock.json").write_text(json.dumps({"pid": pid, "hostname": socket.gethostname(),
                                                            "utc": "2026-11-02T00:59:00Z"}))
            r = run(w, tmp_path, "nf_report.py")
            assert r.returncode == 0, r.stderr
            assert ("(running: fit_nf_a1_seed42)" in r.stdout) is running, r.stdout
            assert ("not running: fit_nf_a1_seed42" in r.stdout) is not running, r.stdout
    finally:
        queue_shell.kill()
        queue_shell.wait()


# ------------------------------------------------------------------ FP-07: one queue owns the lock

STARTER = r'''
import json, os, socket, sys, time
from pathlib import Path
nf, box, n = Path(sys.argv[1]), Path(sys.argv[2]), int(sys.argv[3])
sys.path.insert(0, str(nf))
import nf_plan as P
real, first = socket.gethostname, [True]
def aligned():
    # every starter waits here once, after any look at the lock it makes before writing its own record
    if first[0]:
        first[0] = False
        (box / f"ready.{os.getpid()}").touch()
        t0 = time.time()
        while len(list(box.glob("ready.*"))) < n and time.time() - t0 < 30:
            time.sleep(0.001)
    return real()
socket.gethostname = aligned
try:
    P.acquire_lock(os.getpid())
    res = "owner"
except P.Stop as e:
    res = "refused: " + str(e)
(box / f"result.{os.getpid()}").write_text(res)
t0 = time.time()
while not (box / "go_home").exists() and time.time() - t0 < 60:
    time.sleep(0.01)    # the owner stays alive while the others look at the lock
'''


def _start_together(tmp_path, n, stale=None):
    c2 = tmp_path / "c2"
    c2.mkdir()
    box = tmp_path / "box"
    box.mkdir()
    if stale is not None:
        (c2 / "QUEUE.lock.json").write_text(json.dumps(stale))
    script = tmp_path / "starter.py"
    script.write_text(STARTER)
    env = dict(os.environ, NF_OUT=str(c2), PYTHONDONTWRITEBYTECODE="1")
    ps = [subprocess.Popen([sys.executable, str(script), str(NF), str(box), str(n)], env=env,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) for _ in range(n)]
    try:
        t0 = time.time()
        while len(list(box.glob("result.*"))) < n and time.time() - t0 < 90:
            if any(p.poll() not in (None, 0) for p in ps):
                break
            time.sleep(0.02)
        results = {int(f.name.split(".")[1]): f.read_text() for f in box.glob("result.*")}
    finally:
        (box / "go_home").touch()
        for p in ps:
            try:
                p.wait(timeout=60)
            except subprocess.TimeoutExpired:
                p.kill()
    errors = [p.stderr.read() for p in ps if p.returncode != 0]
    assert len(results) == n and not errors, (results, errors)
    return c2, results


@pytest.mark.parametrize("n,stale", [
    (2, None),                                                           # no lock yet
    (2, {"pid": DEAD, "hostname": socket.gethostname(), "utc": "t"}),    # a dead queue's lock
    (4, {"pid": DEAD, "hostname": socket.gethostname(), "utc": "t"}),
])
def test_queues_started_at_the_same_moment_exactly_one_owns_the_lock(tmp_path, n, stale):
    c2, results = _start_together(tmp_path, n, stale)
    owners = [pid for pid, r in results.items() if r == "owner"]
    assert len(owners) == 1, results
    held = json.loads((c2 / "QUEUE.lock.json").read_text())
    assert held["pid"] == owners[0] and held["hostname"] == socket.gethostname() and held["utc"]
    assert sorted(held) == ["hostname", "pid", "utc"]
    for pid, r in results.items():
        if pid != owners[0]:
            assert r.startswith("refused: another queue"), r
    assert not list(c2.glob(".QUEUE.lock.json.takeover-*"))


def test_a_live_queue_lock_refuses_and_a_dead_ones_is_replaced(tmp_path, monkeypatch):
    monkeypatch.setenv("NF_OUT", str(tmp_path / "c2"))
    P = load("nf_plan")
    lock = tmp_path / "c2" / "QUEUE.lock.json"
    other = subprocess.Popen(["sleep", "60"])
    try:
        assert P.acquire_lock(other.pid) == lock                 # made when absent, with its record
        with pytest.raises(P.Stop, match="another queue holds"):
            P.acquire_lock(os.getpid())
    finally:
        other.kill()
        other.wait()
    assert P.acquire_lock(os.getpid()) == lock                   # its owner is dead: replaced
    assert json.loads(lock.read_text())["pid"] == os.getpid()
    log = (tmp_path / "c2" / "queue.log").read_text()
    assert f"left by pid {other.pid} on {socket.gethostname()}" in log and "which no longer runs" in log


def test_an_unreadable_lock_or_an_unfinished_replacement_refuses(tmp_path, monkeypatch):
    monkeypatch.setenv("NF_OUT", str(tmp_path / "c2"))
    P = load("nf_plan")
    monkeypatch.setattr(P, "LOCK_WAIT_SECONDS", 0.2)
    lock = tmp_path / "c2" / "QUEUE.lock.json"
    lock.parent.mkdir(parents=True)
    lock.write_text("")                                          # a start that died before writing its record
    with pytest.raises(P.Stop, match="cannot be read"):
        P.acquire_lock(os.getpid())
    assert lock.read_text() == ""
    # a start that died while it replaced a dead queue's lock: its claim stays, so nobody else replaces it
    lock.write_text(json.dumps({"pid": DEAD, "hostname": socket.gethostname(), "utc": "t"}))
    st = os.stat(lock)
    import hashlib
    tag = hashlib.sha256(f"{st.st_dev}:{st.st_ino}:".encode() + lock.read_bytes()).hexdigest()[:16]
    claim = lock.with_name(f".QUEUE.lock.json.takeover-{tag}")
    claim.write_text(json.dumps({"pid": DEAD - 1, "hostname": socket.gethostname(), "utc": "t"}))
    with pytest.raises(P.Stop, match="did not finish"):
        P.acquire_lock(os.getpid())
    claim.unlink()
    assert P.acquire_lock(os.getpid()) == lock
    # the queue refuses through the same lock, and its refusal fits 90 characters a line
    w = make_world(tmp_path / "w", map_rows=default_map(),
                   field_status={"f_code": "PASS", "f_cnt24": "FLAG", "f_amt": "PASS"})
    q = w / "checkpoints" / "new_fields" / "QUEUE.lock.json"
    q.write_text(json.dumps({"pid": os.getpid(), "hostname": socket.gethostname(), "utc": "t"}))
    r = run(w, tmp_path / "w", "nf_plan.py", "queue", "--skip-preflight", "--queue-pid", str(DEAD - 2))
    assert r.returncode == 4 and "another queue holds" in r.stderr, r.stderr
    assert max(len(x) for x in r.stderr.splitlines()) <= 90
    assert json.loads(q.read_text())["pid"] == os.getpid()       # the live owner's lock stays as it was


@pytest.mark.parametrize("pid", [0, -1, 2 ** 31, float("inf"), "12x", None])
def test_a_lock_that_names_no_process_refuses_and_stays(tmp_path, monkeypatch, pid):
    """Zero, below zero, too large to be a process id, or not a number: no process that stopped, so the start
    refuses and names the file to remove (it never replaces it as a dead owner's lock). The planner and the report
    read such a trainer's or queue's lock as not running, with no crash."""
    monkeypatch.setenv("NF_OUT", str(tmp_path / "c2"))
    P = load("nf_plan")
    lock = tmp_path / "c2" / "QUEUE.lock.json"
    lock.parent.mkdir(parents=True)
    text = json.dumps({"pid": pid, "hostname": socket.gethostname(), "utc": "t"})
    lock.write_text(text)
    with pytest.raises(P.Stop, match="names no process"):
        P.acquire_lock(os.getpid())
    assert lock.read_text() == text and not (tmp_path / "c2" / "queue.log").exists()
    assert P.lock_pid(json.loads(text)) is None
    assert not P.owner_alive(json.loads(text)) and not P.queue_alive()
    d = tmp_path / "c2" / "runs" / "nf_a1" / "seed42"
    d.mkdir(parents=True)
    (d / "RUNNING.lock.json").write_text(text)
    assert P.fit_state(d) == "INCOMPLETE"


# ------------------------------------------------------------------ the field checks: a column a file lacks

MISSING_COLUMN = [   # engineered fields on a column no file has: named in source_columns, and left out of them
    ("x_missing_listed", "f15298", "engineered", "count(7d; where=no_such_col:v0)", "no_such_col", "continuous", {}),
    ("x_missing_unlisted", "f15298", "engineered", "mean(30d; value=no_such_amt)", "", "continuous", {}),
    # on a column the training files 1 to 3 hold and the vocabulary fit file 4 lacks (a file only a stage reads)
    ("x_missing_in_fit_file", "f15298", "engineered", "prev(x_early_code)", "x_early_code", "categorical", {}),
]


def _checks_world_run(tmp, extra_rows=()):
    """The checks lane's dry-run world through the real recipe engine, read with training files 1 to 3 and
    vocabulary fit files 1 to 4; x_early_code is in every file but part_4. Returns (rc, field_status, log)."""
    F = load("nf_field_checks")
    S = load("nf_checks_synth")
    w = S.make_world(tmp)
    for base in {w["train_base"], w["june_base"]}:
        for f in sorted(Path(base).glob("part_*.parquet")):
            if not (base == w["train_base"] and f.name == "part_4.parquet"):
                df = pd.read_parquet(f)
                df["x_early_code"] = np.where(np.arange(len(df)) % 3 == 0, "a", "b")
                df.to_parquet(f, index=False)
    if extra_rows:
        fm = pd.read_csv(w["map"], dtype=str, keep_default_na=False)
        fm = pd.concat([fm, S.field_map(list(extra_rows)).reindex(columns=fm.columns).fillna("")],
                       ignore_index=True)
        fm.to_csv(w["map"], index=False)
    a = F.build_args(["--dry-run", "--out", str(tmp / "out")])
    a.map, a.thresholds, a.status_rules = str(w["map"]), str(w["thresholds"]), str(w["status_rules"])
    a.decisions, a.predictors, a.config = str(tmp / "KEEP_DECISIONS.csv"), str(w["predictors"]), str(w["config"])
    a.train_base, a.val_base, a.june_base = w["train_base"], w["val_base"], w["june_base"]
    a.train_files, a.val_files, a.june_files = "1-3", w["val_files"], w["june_files"]
    a.fit_files, a.dup_files, a.confirm_file = "1-4", w["dup_files"], w["confirm_file"]
    a.no_settings_ranges, a.min_free_gb, a.cred_path = True, 0.0, None
    a.sample_rows, a.probe_accounts = min(a.sample_rows, 50_000), min(a.probe_accounts, 80)
    log = []
    rc = F.run(a, extra_builders=S.dry_run_builders(w, True), log=log.append)
    st = pd.read_csv(tmp / "out" / "field_status.csv", dtype=str, keep_default_na=False).set_index("field") \
        if rc == 0 else None
    return rc, st, log


def test_a_field_on_a_column_a_file_lacks_stops_and_every_other_field_keeps_its_result(tmp_path):
    rc0, base, log0 = _checks_world_run(tmp_path / "base")
    rc, st, log = _checks_world_run(tmp_path / "with", MISSING_COLUMN)
    assert rc0 == 0, "\n".join(map(str, log0[-20:]))
    assert rc == 0, "\n".join(map(str, log[-20:]))     # one bad map row no longer ends the run with a traceback
    for name, where in (("x_missing_listed", "train:1:no_such_col"), ("x_missing_unlisted", "train:1:no_such_amt"),
                        ("x_missing_in_fit_file", "fit_files:4:x_early_code")):
        r = st.loc[name]
        assert r["result"] == "STOP" and r["reasons"].startswith("STOP missing_from_files"), (name, r["reasons"])
        assert where in r["reasons"], (name, r["reasons"])
    assert any("not built, a column is missing from a file" in str(x) and "x_missing_listed" in str(x)
               for x in log), log
    assert any("footers of" in str(x) for x in log)
    pd.testing.assert_frame_equal(st.loc[base.index], base)   # every other row: the same result and reasons


def test_a_recipe_column_left_out_of_source_columns_is_still_read(tmp_path):
    """The map's source_columns omit the recipe's value column: the frame still reads it (the recipe engine
    needs it), so the field is built as if the column were listed."""
    df = _history()
    ck, _, _, base = _checks(tmp_path, [("amt_listed", "mean(30d; value=transaction_amt)", "transaction_amt"),
                                        ("amt_unlisted", "mean(30d; value=transaction_amt)", "")], df)
    listed, unlisted = ck.specs
    assert unlisted["sources"] == [] and ck.needed_columns(unlisted) == ["transaction_amt"]
    fr = ck.frame(base + "/part_1.parquet", [unlisted])
    assert "transaction_amt" in fr.columns
    a, _ = ck.values(listed, fr, "2024-10-01")
    b, _ = ck.values(unlisted, fr, "2024-10-01")
    pd.testing.assert_series_equal(a, b, check_names=False)


def test_the_data_tools_name_a_missing_status_file_from_the_project_root(capsys):
    """The enriched and artifact builds refuse a missing field_status.csv with its path from the project root,
    as the other tools print paths, never the path of this machine."""
    D = load("nf_data_fields")
    for name in ("no_such_status.csv", "x" * 120 + ".csv"):      # a long name too: the path stays whole
        p = ROOT / "checkpoints" / "new_fields" / "checks" / name
        with pytest.raises(SystemExit) as e:
            D.read_status(p)
        assert e.value.code == 4
        err = capsys.readouterr().err
        assert f"refused: checkpoints/new_fields/checks/{name} is missing" in " ".join(err.split()), err
        assert str(ROOT) not in err, err


def test_the_same_second_probe_keeps_the_stored_precision_when_asked():
    """A builder that reads the stored precision refuses sub-second parts, as the 26 October builders do (design
    review item 31): with whole_seconds the probe's sibling sits at the row's whole second, so the builder runs
    and the probe can pass; without it the sibling carries milliseconds."""
    M = load("nf_checks_measure")
    df = _history()
    df[W.TIME] = pd.to_datetime(df[W.TIME]).dt.floor("s")     # stored in whole seconds, as such a builder needs
    df["frd_tag"] = 0
    seen = []

    def stored_precision_count(frame):
        t = pd.to_datetime(frame[W.TIME])
        if (t != t.dt.floor("s")).any():
            raise ValueError("sub-second parts: refused")
        seen.append(len(frame))
        return frame.groupby(W.ACCOUNT).cumcount().astype(float)

    with pytest.raises(ValueError, match="sub-second"):
        M.probe_same_second(df, stored_precision_count, ["transaction_amt"], W.ACCOUNT, W.TIME, W.TIE)
    seen.clear()
    r = M.probe_same_second(df, stored_precision_count, ["transaction_amt"], W.ACCOUNT, W.TIME, W.TIE,
                            whole_seconds=True)
    assert r["rows_checked"] > 0 and len(seen) == 2 and seen[1] > seen[0]


def test_an_a3_field_that_lists_two_of_its_inputs_is_built_and_probed(tmp_path):
    """An a3 row lists two of the six inputs the 26 October builders read, as the draft lists' row of this name
    does. Every input is read, the same-second probe keeps the stored precision, and the field checks end with
    exit 0 and a result for it from every probe. Before, the run ended with RecipeError (an input not read, or the
    probe's sub-second sibling)."""
    F = load("nf_field_checks")
    S = load("nf_checks_synth")
    w = S.make_world(tmp_path)
    for base in {w["train_base"], w["june_base"]}:
        for f in sorted(Path(base).glob("part_*.parquet")):
            df = pd.read_parquet(f)
            df["merchant_category_xcd"] = np.where(np.arange(len(df)) % 4 == 0, "5411", "5999")
            df.to_parquet(f, index=False)
    row = [("amt_over_balance", "a3", "engineered", "a3(amt_over_balance)",
            "transaction_amt;total_available_balance_amt", "continuous", {})]
    fm = pd.read_csv(w["map"], dtype=str, keep_default_na=False)
    fm = pd.concat([fm, S.field_map(row).reindex(columns=fm.columns).fillna("")], ignore_index=True)
    fm.to_csv(w["map"], index=False)
    a = F.build_args(["--dry-run", "--out", str(tmp_path / "out")])
    a.map, a.thresholds, a.status_rules = str(w["map"]), str(w["thresholds"]), str(w["status_rules"])
    a.decisions, a.predictors, a.config = str(tmp_path / "KEEP_DECISIONS.csv"), str(w["predictors"]), str(w["config"])
    a.train_base, a.val_base, a.june_base = w["train_base"], w["val_base"], w["june_base"]
    a.train_files, a.val_files, a.june_files = w["train_files"], w["val_files"], w["june_files"]
    a.fit_files, a.dup_files, a.confirm_file = w["fit_files"], w["dup_files"], w["confirm_file"]
    a.no_settings_ranges, a.min_free_gb, a.cred_path = True, 0.0, None
    a.sample_rows, a.probe_accounts = min(a.sample_rows, 50_000), min(a.probe_accounts, 80)
    log = []
    assert F.run(a, extra_builders=S.dry_run_builders(w, True), log=log.append) == 0, log[-10:]
    st = pd.read_csv(tmp_path / "out" / "field_status.csv", dtype=str, keep_default_na=False).set_index("field")
    r = st.loc["amt_over_balance"]
    assert "missing_from_files" not in r["reasons"] and "not_strictly_earlier" not in r["reasons"], r["reasons"]
    fc = pd.read_csv(tmp_path / "out" / "field_checks.csv", dtype=str, keep_default_na=False)
    probes = json.loads(fc[(fc["field"] == "amt_over_balance") & (fc["range"] == "train")]["probes"].iloc[0])
    assert all(probes[k] is True for k in ("future_invariance", "future_deletion", "history_deletion",
                                           "same_second", "label_permutation")), probes
