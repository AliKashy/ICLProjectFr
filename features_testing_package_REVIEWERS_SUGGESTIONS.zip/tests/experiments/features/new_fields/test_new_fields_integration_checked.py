"""Part A, checked: the fixes after the correctness and pod checks of the integrated package. The reader's AP when
every row is a fraud, no decision on an undefined gain, the lift's recorded sha256, the rank check's S3 refusal and
the plan's fallback files, importance waiting on a failed RANK-A or on other RANK-A files in SETTINGS.yaml, the base
controls at seeds 43 and 44, a stale trainer lock after a restart, the busy check's GPU subcommands and stage 0
queue name, and the field checks' map refusal and screen order. Synthetic data only."""
import json
import os
import socket
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from new_fields_checks_helpers import load  # noqa: E402
from new_fields_reader_world import ACCT, ID, LABEL, World, scores  # noqa: E402
from new_fields_spine_world import NF_REL, default_map, make_world, run, write  # noqa: E402

ROOT = HERE.parents[3]
NF = ROOT / "fraud" / "experiments" / "features" / "new_fields"
STOP, REFUSED = 3, 4


# ------------------------------------------------------------------ the reader's AP (final notes 10, first item)

def test_ap_is_defined_whenever_there_is_a_fraud():
    from sklearn.metrics import average_precision_score, roc_auc_score
    R = load("nf_ranked")
    n = 12
    acct = np.arange(n) // 3
    keys = R.key_ranks(R.identity_keys(acct, np.arange(n)))
    codes, units = R.account_units(acct)
    s = np.array([5, 5, 4, 3, 3, 3, 2, 1, 1, 0, 0, 0], dtype=float)
    # every row a fraud: AP 1.0 (as scikit-learn and average_precision); AUROC and KS undefined
    every = R.RankedScore(s, np.ones(n, int), codes, keys).evaluate(None)
    assert every["ap"] == 1.0 and np.isnan(every["auroc"]) and np.isnan(every["ks"])
    assert R.average_precision(np.ones(n, int), s) == 1.0
    assert average_precision_score(np.ones(n, int), s) == pytest.approx(1.0)
    w = np.array([2, 0, 1, 1])                                # on a draw too
    assert R.RankedScore(s, np.ones(n, int), codes, keys).evaluate(w)["ap"] == 1.0
    # no fraud: AP undefined
    none = R.RankedScore(s, np.zeros(n, int), codes, keys).evaluate(None)
    assert np.isnan(none["ap"]) and np.isnan(none["auroc"]) and np.isnan(none["udr"])
    # mixed, with ties and a draw's weights: scikit-learn with sample_weight
    y = np.array([1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0])
    for mult in (None, np.array([2, 0, 1, 3])):
        got = R.RankedScore(s, y, codes, keys).evaluate(mult)
        sw = np.ones(n) if mult is None else mult[codes]
        assert got["ap"] == pytest.approx(average_precision_score(y, s, sample_weight=sw), abs=1e-12)
        assert got["auroc"] == pytest.approx(roc_auc_score(y, s, sample_weight=sw), abs=1e-12)


# ------------------------------------------------------------------ the reader: no decision on an undefined gain

def test_decide_stops_on_an_undefined_gain_or_t1():
    RD = load("nf_read")
    for kind, seeds in (("add", 1), ("add", 3), ("month_out", 1), ("month_out", 3), ("calendar", 1), ("prune", 1)):
        with pytest.raises(RD.ReadError) as e:
            RD.decide(kind, seeds, float("nan"), 0.02, 0.01, 0.5, lb3=0.5, hi=0.5)
        assert e.value.code == STOP and "not a number" in str(e.value)
    for kind in ("add", "month_out", "calendar"):
        with pytest.raises(RD.ReadError):
            RD.decide(kind, 1, 0.03, float("nan"), 0.01, 0.5)
    # defined values are decided as before
    assert RD.decide("month_out", 1, 0.02, 0.02, 0.01, None)[0] == "MONTH OUT"
    assert RD.decide("add", 3, 0.02, None, 0.01, None, lb3=0.001)[0] == "ADOPT"


# ------------------------------------------------------------------ the lift refuses a missing recorded sha256

@pytest.fixture
def reader_world(tmp_path, monkeypatch):
    return World(tmp_path, monkeypatch, accounts=300)


@pytest.mark.parametrize("recorded", [None, "None", ""])
def test_lift_from_the_planner_refuses_when_no_sha256_was_recorded(reader_world, capsys, recorded):
    w = reader_world
    raw = w.raw["select"][0]
    rows = []
    for role, tag in (("candidate", "nf_a1_seed42"), ("control", "control_seed42")):
        d = w.c2 / "downstream" / tag / "base_raw" / "fit"
        d.mkdir(parents=True)
        f = d / "predictions.parquet"
        pd.DataFrame({ID: raw[ID], ACCT: raw[ACCT], LABEL: raw[LABEL], "raw": scores(raw, 1.0, 1),
                      "raw_embedding": scores(raw, 3.0, 2)}).to_parquet(f)
        rows.append({"role": role, "seed": 42, "run": tag, "run_dir": "x", "checkpoint": "x", "predictions": str(f),
                     "receipt": "", "downstream": str(f), "downstream_sha256": recorded,
                     "downstream_sha256_required": "yes"})
    p = w.c2 / "reads" / "A1_lift.runs.json"
    p.write_text(json.dumps({"step": "A1", "population": "ds_select", "runs": rows}))
    out = w.c2 / "reads" / "A1_lift.json"
    assert w.run("lift", "--step", "A1", "--population", "ds_select", "--run-table", p, "--out", out,
                 "--fraud-rule", "pass") == REFUSED
    text = capsys.readouterr().out
    assert "recorded no sha256" in text and not out.exists()
    # a hand-written table (no requirement) keeps the old behaviour: no recorded value, no comparison
    for r in rows:
        r.pop("downstream_sha256_required")
    p.write_text(json.dumps({"step": "A1", "population": "ds_select", "runs": rows}))
    assert w.run("lift", "--step", "A1", "--population", "ds_select", "--run-table", p, "--out", out,
                 "--fraud-rule", "pass") == 0


def test_the_planner_lift_table_requires_the_recorded_sha256(tmp_path, monkeypatch):
    monkeypatch.setenv("NF_OUT", str(tmp_path / "c2"))
    P = load("nf_plan")
    e = {"tag": "nf_a1_seed42", "dir": tmp_path / "c2" / "runs" / "nf_a1" / "seed42",
         "ckpt": tmp_path / "c2" / "runs" / "nf_a1" / "seed42" / "best.ckpt"}
    rows = P.lift_table([e], [("candidate", 42)])
    assert rows[0]["downstream_sha256_required"] == "yes" and rows[0]["downstream_sha256"] is None


# ------------------------------------------------------------------ the rank check: S3 refusal and the plan's fallback

def _splits(w, numbers, pops=None):
    files = [{"file_key": f"eval/{n}", "source": "eval", "number": n,
              "months": {"2025-06": {"rows": 10, "frauds": 2}}} for n in numbers]
    write(w / "splits/file_inventory.json", json.dumps({"files": files}))
    import yaml
    write(w / "splits/populations.yaml", yaml.safe_dump({"populations": pops or {
        "SELECT": {"source": "eval", "file_start": 8206, "file_end": 8216},
        "BENCH": {"source": "eval", "file_start": 8000, "file_end": 8200}}}))


def test_rank_check_refuses_when_the_s3_file_system_cannot_be_opened(tmp_path):
    w = make_world(tmp_path, rank_check=None)
    _splits(w, range(8228, 8260))
    write(w / "fraud/data/s3_utils.py", "def make_s3_filesystem(c=None):\n    raise FileNotFoundError(c)\n"
          "def strip_scheme(p): return p\n")
    r = run(w, tmp_path, "nf_rank_check.py", "--roots", "models")
    assert r.returncode == REFUSED, r.stdout + r.stderr
    assert "S3 file system cannot be opened" in r.stderr and "Traceback" not in r.stderr
    assert max(len(x) for x in r.stderr.splitlines()) <= 90


def test_rank_b_failing_checks_the_plan_fallback_and_the_owner_decides(tmp_path):
    rb_used = {"DS_SELECT": {"source": "eval", "file_start": 8250, "file_end": 8252}}
    # the fallback files pass the same checks: the owner decides, the queue and the reader wait
    w = make_world(tmp_path / "a", rank_check=None, map_rows=default_map(),
                   field_status={"f_code": "PASS", "f_cnt24": "FLAG", "f_amt": "PASS"})
    _splits(w, list(range(8201, 8206)) + list(range(8228, 8260)) + list(range(8278, 8301)), rb_used)
    r = run(w, tmp_path / "a", "nf_rank_check.py", "--skip-files", "--roots", "models")
    assert r.returncode == STOP, r.stdout
    j = json.loads((w / "checkpoints/new_fields/reads/rank_check.json").read_text())
    assert j["populations"]["rank_b"]["result"] == "FAIL" and j["populations"]["rank_a"]["result"] == "PASS"
    assert j["fallback"]["result"] == "PASS" and j["fallback"]["files"] == [[8201, 8205], [8278, 8300]]
    assert j["decide_on"] == "owner" and "the owner decides" in r.stdout
    assert len(r.stdout.splitlines()) <= 40 and max(len(x) for x in r.stdout.splitlines()) <= 90
    q = run(w, tmp_path / "a", "nf_plan.py", "queue", "--skip-preflight")
    log = (w / "checkpoints/new_fields/queue.log").read_text()
    assert q.returncode == STOP and "plan's fallback files passed" in log and "start fit_" not in log
    # the owner chooses June SELECT in SETTINGS.yaml: the queue reads it
    import yaml
    sp = w / NF_REL / "SETTINGS.yaml"
    s = yaml.safe_load(sp.read_text())
    s["decide_on"] = "select_june"
    sp.write_text(yaml.safe_dump(s, sort_keys=False))
    # the base refits nf_control at seeds 43 and 44 run first, before the first read (the reviewers' decision D5b)
    run(w, tmp_path / "a", "nf_plan.py", "queue", "--skip-preflight", "--max-jobs", "8")
    qlog = (w / "checkpoints/new_fields/queue.log").read_text()
    assert "fit_nf_control_seed43" in qlog and "score_control_seed42__select" in qlog
    # the fallback fails too (its files are not in the inventory): June SELECT decides, as the plan says
    w2 = make_world(tmp_path / "b", rank_check=None)
    _splits(w2, range(8228, 8260), rb_used)
    r = run(w2, tmp_path / "b", "nf_rank_check.py", "--skip-files", "--roots", "models")
    j = json.loads((w2 / "checkpoints/new_fields/reads/rank_check.json").read_text())
    assert r.returncode == STOP and j["fallback"]["result"] == "FAIL" and j["decide_on"] == "select_june"


def test_reader_refuses_while_the_owner_decides_the_population(reader_world, capsys):
    w = reader_world
    (w.c2 / "reads" / "rank_check.json").write_text(json.dumps(
        {"result": "FAIL", "decide_on": "owner", "populations": {"rank_b": {"result": "FAIL"}}}))
    RD = load("nf_read")
    with pytest.raises(RD.ReadError) as e:
        RD.decision_population(RD.C.settings())
    assert e.value.code == REFUSED and "fallback" in str(e.value)


def test_importance_and_attention_wait_when_rank_a_failed(tmp_path):
    steps = {"steps": [{"name": "A1", "on": True, "adds": ["v22b", "both"]}]}
    w = make_world(tmp_path, map_rows=default_map(), steps_patch=steps,
                   field_status={"f_code": "PASS", "f_cnt24": "FLAG", "f_amt": "PASS"})
    (w / "checkpoints/new_fields/reads/rank_check.json").write_text(json.dumps(
        {"decide_on": "rank_b", "result": "FAIL",
         "populations": {"rank_a": {"result": "FAIL"}, "rank_b": {"result": "PASS"}}}))
    dec = tmp_path / "decisions.json"
    dec.write_text(json.dumps({"A1_1seed": "ADOPT"}))
    r = run(w, tmp_path, "nf_plan.py", "queue", "--skip-preflight", FAKE_DECISIONS=dec)
    log = (w / "checkpoints/new_fields/queue.log").read_text()
    assert r.returncode in (0, 5), log
    assert "start attention_" not in log and "start importance_" not in log
    assert "start read_A1_1seed" in log            # the decisions on RANK-B go on
    assert "RANK-A failed its rank check" in log


def test_importance_runs_on_the_rank_a_files_settings_name_and_waits_only_when_rank_a_failed(tmp_path, monkeypatch):
    """The importance tool reads RANK-A's files from SETTINGS.yaml populations.rank_a (the lane's head 7be4f45), so
    another range there (the plan's fallback, chosen by the owner) is scored as named and does not make importance
    wait. A failed RANK-A still waits for the owner: the tool does not read the rank check."""
    monkeypatch.setenv("NF_OUT", str(tmp_path / "c2"))
    P = load("nf_plan")
    assert not hasattr(P, "IMPORTANCE_RANK_A")
    passed = {"populations": {"rank_a": {"result": "PASS"}, "rank_b": {"result": "PASS"}}}

    def ctx(rank, files):
        return SimpleNamespace(rank=rank, settings={"populations": {"rank_a": {"files": files}}}, steps={}, up={})

    assert P.importance_wait(ctx(passed, [8228, 8243])) is None
    assert P.importance_wait(ctx(passed, [8201, 8205])) is None
    failed = {"populations": {"rank_a": {"result": "FAIL"}, "rank_b": {"result": "PASS"}}}
    assert "RANK-A failed its rank check" in P.importance_wait(ctx(failed, [8228, 8243]))
    assert "RANK-A failed its rank check" in P.importance_wait(ctx(failed, [8201, 8205]))
    # the tool itself takes the range SETTINGS.yaml names, as the planner now assumes
    I = load("nf_importance")
    from omegaconf import OmegaConf
    settings = {"importance": {"population": "rank_a"},
                "populations": {"rank_a": {"files": [8201, 8205], "targets": ["2025-06-01", "2025-07-01"]}}}
    I.enforce_rank_a(OmegaConf.create({"eval": {"file_start": 8201, "file_end": 8205}}), settings)


# ------------------------------------------------------------------ the base controls at seeds 43 and 44 (plan, Q5)

def _ctx(steps):
    return SimpleNamespace(steps=steps, settings={}, up={})


@pytest.mark.parametrize("steps", [{}, {"refit_base_controls_43_44": True}, {"refit_base_controls_43_44": False}])
def test_base_controls_43_44_are_always_the_base_refits(tmp_path, monkeypatch, steps):
    """The reviewers' decision D5b replaced the owner's reuse option: the kept seed 43 and 44 checkpoints are never
    controls; the base refits nf_control at seeds 43 and 44 (a STEPS.yaml false stops the walk, tested with the
    planner's decisions)."""
    monkeypatch.setenv("NF_OUT", str(tmp_path / "c2"))
    P = load("nf_plan")
    ctl42 = P.fit_entry("control_seed42", tmp_path / "control")
    out, line = P.confirm_controls(_ctx(steps), {"is_base": True}, ctl42, [43, 44])
    assert [e["tag"] for e in out] == ["nf_control_seed43", "nf_control_seed44"]
    assert "the base refits nf_control (D5b)" in line
    import yaml
    assert yaml.safe_load((NF / "STEPS.yaml").read_text())["refit_base_controls_43_44"] is True


# ------------------------------------------------------------------ a stale trainer lock after a restart

def test_a_dead_trainers_lock_is_an_incomplete_folder_not_a_running_one(tmp_path, monkeypatch):
    monkeypatch.setenv("NF_OUT", str(tmp_path / "c2"))
    P = load("nf_plan")
    d = tmp_path / "c2" / "runs" / "nf_a1" / "seed42"
    d.mkdir(parents=True)
    (d / "run_manifest_v2.json").write_text(json.dumps({"status": "running"}))
    lock = d / "RUNNING.lock.json"
    lock.write_text(json.dumps({"pid": 999999999, "hostname": socket.gethostname(), "utc": "t"}))
    assert P.fit_state(d) == "INCOMPLETE"
    with pytest.raises(P.Stop) as e:
        P.fit_job("nf_a1", 42, tmp_path / "cfg.yaml", "S.1")
    assert "exists but incomplete: rename it" in str(e.value)
    # a lock of another host is another workbench's live trainer on the shared folder: running, never incomplete
    lock.write_text(json.dumps({"pid": os.getpid(), "hostname": "another-host", "utc": "t"}))
    assert P.fit_state(d) == "RUNNING"
    lock.write_text(json.dumps({"pid": os.getpid(), "hostname": socket.gethostname(), "utc": "t"}))
    assert P.fit_state(d) == "RUNNING"


# ------------------------------------------------------------------ the busy check

def _proc(root, procs):
    for pid, argv in procs.items():
        d = root / str(pid)
        d.mkdir(parents=True)
        (d / "cmdline").write_bytes(b"\0".join(a.encode() for a in argv) + b"\0")
        (d / "stat").write_text(f"{pid} (x y) S 1 0 0\n")
    return root


@pytest.mark.parametrize("argv,gpu", [
    (["python3", "fraud/experiments/features/new_fields/nf_time_width.py", "real", "--config", "a"], True),
    (["python3", "nf_time_width.py", "_attempt", "--config", "a"], True),
    (["python3", "nf_importance.py", "run", "--attention-only"], True),
    (["python3", "nf_downstream.py", "run", "--name", "x"], True),
    (["python3", "nf_downstream.py", "--config", "a", "--checkpoint", "b", "--out", "c"], True),
    (["python3", "nf_fit.py", "--run", "nf_a1"], True),
    (["python3", "nf_time_width.py", "width", "--config", "bad.yaml"], False),
    (["python3", "nf_time_width.py", "chunks", "--config", "a", "--batch", "8"], False),
    (["python3", "nf_time_width.py", "encode", "--config", "a", "--run", "x"], False),
    (["python3", "nf_importance.py", "estimate", "--config", "a"], False),
    (["python3", "nf_downstream.py", "use2", "--name", "x"], False),
    (["python3", "nf_downstream.py", "lift", "--step", "A1"], False),
])
def test_busy_matches_only_the_gpu_subcommands(tmp_path, argv, gpu):
    C = load("nf_common")
    proc = _proc(tmp_path / "proc", {100: ["sh"], 200: argv})
    found = C.busy(proc_root=proc, nvidia_smi=str(tmp_path / "absent"), lock_roots=[], my_pid=100)
    assert bool(found) == gpu, found


def test_busy_reads_the_stage0_queue_name_from_upstream(tmp_path, monkeypatch):
    C = load("nf_common")
    sdir = tmp_path / "settings"
    sdir.mkdir()
    (sdir / "UPSTREAM.yaml").write_text("stage0:\n  queue_script: fraud/experiments/tuning/stage0_queue.sh\n")
    monkeypatch.setenv("NF_SETTINGS_DIR", str(sdir))
    proc = _proc(tmp_path / "proc", {100: ["sh"], 200: ["bash", "fraud/experiments/tuning/stage0_queue.sh"]})
    found = C.busy(proc_root=proc, nvidia_smi=str(tmp_path / "absent"), lock_roots=[], my_pid=100)
    assert len(found) == 1 and "stage0_queue.sh" in found[0]


# ------------------------------------------------------------------ the field checks: a missing map, the screen last

def test_field_checks_refuse_a_missing_map_with_exit_4(tmp_path):
    e = dict(os.environ, NF_OUT=str(tmp_path / "c2"), CUDA_VISIBLE_DEVICES="", PYTHONDONTWRITEBYTECODE="1")
    r = subprocess.run([sys.executable, str(NF / "nf_field_checks.py"), "--map", "NF/FIELD_MAP.csv",
                        "--min-free-gb", "0"], cwd=ROOT, capture_output=True, text=True, env=e, timeout=300)
    assert r.returncode == REFUSED and "no field map at NF/FIELD_MAP.csv" in r.stderr
    assert "Traceback" not in r.stderr


def test_field_checks_print_the_screen_last_and_progress_to_the_error_stream(tmp_path):
    e = dict(os.environ, NF_OUT=str(tmp_path / "c2"), CUDA_VISIBLE_DEVICES="", PYTHONDONTWRITEBYTECODE="1",
             TMPDIR=str(tmp_path))
    r = subprocess.run([sys.executable, str(NF / "nf_field_checks.py"), "--dry-run"], cwd=ROOT,
                       capture_output=True, text=True, env=e, timeout=600)
    assert r.returncode == 0, r.stderr[-2000:]
    out = r.stdout.rstrip("\n").splitlines()
    assert out[0].startswith("FIELD CHECKS") and len(out) <= 40 and max(map(len, out)) <= 90
    assert "train file 1: reading" in r.stderr and "dry run done" in r.stderr
    th = [x for x in r.stderr.splitlines() if x.startswith("thresholds ")]
    assert th and len(th[0].split("sha256 ")[1]) == 12
