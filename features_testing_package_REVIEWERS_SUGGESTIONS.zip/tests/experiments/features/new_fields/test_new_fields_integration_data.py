"""The data lane's notes and the final notes, across lanes: the artifact check reads the checks lane's field_checks.csv
(field and vocab_size), the config writer's step lists are the data lane's rule, the width timing counts the
missing-flag columns at about 190 fields, and the optional cyclical calendar step's fields enter the extended
artifact by config only."""
import json
import sys
from pathlib import Path

import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from new_fields_checks_helpers import dry_world, load  # noqa: E402

A = load("nf_data_artifact")
K = load("nf_check_artifact")


def test_the_artifact_check_reads_the_checks_lane_field_checks_csv():
    """Data lane note 1: the artifact check needs a field (or name) column and vocab_size. The checks lane writes
    exactly those names, one vocabulary size per code field (the project's own vocabulary rule)."""
    w = dry_world()
    fc = pd.read_csv(w["out"] / "field_checks.csv", dtype=str, keep_default_na=False)
    assert "field" in fc.columns and "vocab_size" in fc.columns
    src = Path(K.__file__).read_text()
    assert '("vocab_size", "vocab_fit", "vocabulary_size")' in src and '("field", "name")' in src
    sizes = fc[(fc["range"] == "fit") & (fc["vocab_size"] != "")]
    assert len(sizes) and all(int(float(v)) >= 1 for v in sizes["vocab_size"])
    st = pd.read_csv(w["out"] / "field_status.csv", dtype=str, keep_default_na=False)
    cats = set(st.loc[st["kind"].isin(["raw", "engineered"]), "field"])
    assert set(sizes["field"]) <= cats


def test_the_config_writer_uses_the_data_lane_month_lists(tmp_path):
    """Data lane note 3: the step lists are nf_data_artifact.month_in_list and month_out_list, so the artifact
    check's month-switch line verifies them."""
    from new_fields_spine_world import default_map, make_world, run
    w = make_world(tmp_path, map_rows=default_map(), field_status={"f_code": "PASS", "f_cnt24": "FLAG",
                                                                   "f_amt": "PASS"})
    r = run(w, tmp_path, "nf_make_configs.py", "write", "--run", "nf_a1", "--steps", "A1")
    assert r.returncode == 0, r.stdout + r.stderr
    d = w / "fraud/experiments/features/new_fields/predictors"
    pin, pout = d / "predictors_a1_month_in.csv", d / "predictors_a1_month_out.csv"
    base = (w / "fraud/configs/predictors.csv").read_bytes()
    assert pin.read_bytes() == A.month_in_list(base, [("f_code", "categorical", "a code")])
    assert A.month_out_ok(pin.read_bytes(), pout.read_bytes())


def test_width_counts_the_missing_flag_columns_at_about_190_fields(tmp_path):
    """Final notes: the width timing counts a missing-flag token for every continuous field (the preprocessing
    adds them), so the width with about 190 fields is measured as it will run. The real run uses the trainer's
    own dataset, whose width the gpu lane's test proves equal to this count."""
    import nf_time_width as T
    from omegaconf import OmegaConf
    lines = ["feature,type,source,version,description"]
    lines += [f"n{i},continuous,raw,1,x" for i in range(6)] + [f"k{i},categorical,raw,1,x" for i in range(13)]
    lines += [f"{f},categorical,derived:transaction_dttm,1,x" for f in ("month", "day", "hour", "day_of_week")]
    lines += [f"new_n{i},continuous,raw,2,x" for i in range(110)] + [f"new_k{i},categorical,raw,2,x"
                                                                       for i in range(57)]
    p = tmp_path / "width190.csv"
    p.write_text("\n".join(lines) + "\n")
    cfg = OmegaConf.create({"s3": {}, "predictors": {"csv_path": str(p), "version": None},
                            "preprocess": {"add_missing_flag": True}, "sequence": {"time_delta": True}})
    w = T.token_width(cfg)
    assert w["fields"] == 190 and w["missing_flags"] == 116
    assert w["tokens"] == (116 + 1) + (74 + 116) == 307 and "116 missing flags" in w["label"]
    cfg.preprocess.add_missing_flag = False
    assert T.token_width(cfg)["tokens"] == 307 - 116


def test_the_cyclical_calendar_fields_enter_the_extended_artifact(tmp_path, monkeypatch):
    """The optional step C: a second scratch fit with datetime.encoding cyclical adds month_sin ... day_of_week_cos
    (and is_weekend) to the extended artifact; version 1's files stay byte for byte."""
    import test_new_fields_data_artifact as D
    lab = D.lab.__wrapped__(tmp_path, monkeypatch) if hasattr(D.lab, "__wrapped__") else None
    if lab is None:
        pytest.skip("the data lane's fixture cannot be called directly here")
    B = D.B
    assert B.main(lab.args + ["--calendar-cyclical", "cyclical_weekend"]) == 0
    ext, v1 = lab.art / "nf_ext1", lab.art / "1"
    rec = json.loads((lab.c2 / "artifact" / "artifact_hashes.json").read_text())
    names = rec["calendar_cyclical"]["fields"]
    assert {"month_sin", "month_cos", "hour_sin", "day_of_week_cos", "is_weekend"} <= set(names)
    for n in names:
        assert (ext / f"feature__{n}.json").is_file()
    for f in v1.iterdir():
        if f.name != "manifest.json":
            assert D.sha(ext / f.name) == D.sha(f), f.name
    man = json.loads((ext / "manifest.json").read_text())
    assert set(names) <= set(man["features"])
    sin = json.loads((ext / "feature__month_sin.json").read_text())
    assert sin["type"] == "continuous"
