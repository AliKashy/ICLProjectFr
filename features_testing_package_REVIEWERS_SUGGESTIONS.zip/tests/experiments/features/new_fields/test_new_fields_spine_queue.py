"""Planner and queue with a fake trainer, scorer, reader and nvidia-smi on PATH."""
import json
import os
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from new_fields_spine_world import NF_REL, default_map, env, make_world, run  # noqa: E402

STATUS = {"f_code": "PASS", "f_cnt24": "FLAG", "f_amt": "PASS"}


def world(tmp_path, **kw):
    kw.setdefault("map_rows", default_map())
    kw.setdefault("field_status", STATUS)
    return make_world(tmp_path, **kw)


def queue(w, tmp_path, *extra, decisions=None, **envx):
    if decisions is not None:
        p = tmp_path / "decisions.json"
        p.write_text(json.dumps(decisions))
        envx["FAKE_DECISIONS"] = p
    return run(w, tmp_path, "nf_plan.py", "queue", "--skip-preflight", *extra, **envx)


def c2(w):
    return w / "checkpoints" / "new_fields"


def qlog(w):
    return (c2(w) / "queue.log").read_text()


def test_busy_gpu_refuses(tmp_path):
    w = world(tmp_path, fake_smi_apps="999, python, 30000")
    r = queue(w, tmp_path)
    assert r.returncode == 4, r.stderr
    assert "busy" in qlog(w) and "queue end rc=4" in qlog(w)
    r2 = run(w, tmp_path, "nf_plan.py", "busy")
    assert r2.returncode == 4 and "999" in r2.stdout


def test_start_refuses_when_busy(tmp_path):
    w = world(tmp_path, fake_smi_apps="999, python, 30000")
    r = subprocess.run(["bash", str(w / NF_REL / "nf_start.sh")], cwd=w, capture_output=True, text=True,
                       env=env(w, tmp_path, PY=sys.executable, NF_NO_TAIL=1), timeout=60)
    assert r.returncode == 4 and "refused" in r.stdout


def test_chain_keep_then_a2_builds_on_base(tmp_path):
    w = world(tmp_path)
    r = queue(w, tmp_path, decisions={"A1_1seed": "KEEP THE CONTROL", "A2_1seed": "KEEP THE CONTROL"})
    assert r.returncode in (0, 5), r.stdout + r.stderr + qlog(w)
    log = qlog(w)
    assert "start fit_nf_a1_seed42" in log and "end fit_nf_a1_seed42 rc=0" in log
    assert "start score_control_seed42__rank_b" in log
    for s in (42, 43, 44):
        assert f"start score_kept_seed{s}__rank_b" in log
    head = (w / NF_REL / "configs" / "nf_a2.yaml").read_text().splitlines()[0]
    assert "input set a2;" in head          # A1 kept the control, so A2 builds on base
    kept = json.loads((c2(w) / "KEPT.json").read_text())
    assert kept["input_set"] == "base"
    assert "queue end rc=" in log.splitlines()[-1]
    assert (c2(w) / "reads" / "RESULT.txt").is_file()
    assert (c2(w) / "logs" / "fit_nf_a1_seed42.log").is_file()
    # restart: nothing is rerun, everything is skipped
    n_start = log.count("start ")
    r2 = queue(w, tmp_path, decisions={"A1_1seed": "KEEP THE CONTROL", "A2_1seed": "KEEP THE CONTROL"})
    assert r2.returncode in (0, 5)
    log2 = qlog(w)
    assert log2.startswith(log)                  # appended, never truncated
    assert log2.count("start fit_") == log.count("start fit_")


def test_adopt_pending_select_then_a2_reads_against_a_seed42_refit_by_default(tmp_path):
    """The reviewers' decision D5a: before every later step, the kept recipe is fit again at seed 42 at the
    candidate's micro-batch, and that refit is the step's control. The order: the candidate's config, its width
    timing, the refit's config, the refit fit, the candidate fit."""
    w = world(tmp_path)
    r = queue(w, tmp_path, decisions={"A1_1seed": "ADOPT (pending the SELECT check)"})
    assert r.returncode in (0, 5), qlog(w)
    log = qlog(w)
    assert "start read_A1_select" in log
    order = [log.index(f"start {j}") for j in ("config_nf_a2", "timing_nf_a2", "config_nf_ka2", "fit_nf_ka2_seed42",
                                                "fit_nf_a2_seed42", "read_A2_1seed")]
    assert order == sorted(order), log
    kept = json.loads((c2(w) / "KEPT.json").read_text())
    assert kept["input_set"] == "a1"
    assert "input set a1a2;" in (w / NF_REL / "configs" / "nf_a2.yaml").read_text().splitlines()[0]
    assert "input set a1;" in (w / NF_REL / "configs" / "nf_ka2.yaml").read_text().splitlines()[0]
    table = json.loads((c2(w) / "reads" / "A2_1seed.runs.json").read_text())
    ctl = [x for x in table["runs"] if x["role"] == "control"][0]
    assert ctl["run_dir"].endswith("runs/nf_ka2/seed42") and ctl["control_kind"] == "refit"
    assert ctl["previous_decision"] == "one_seed"
    assert [x["run_dir"] for x in table["runs"] if x["role"] == "kept_fit"][0].endswith("runs/nf_a1/seed42")
    dlog = (c2(w) / "DECISIONS.log").read_text()
    assert "a refit at seed 42 of the kept recipe" in dlog and "the kept fit stays nf_a1_seed42" in dlog
    assert "start downstream_nf_a1_seed42" in log
    # a recorded decision to drop the refits reuses the kept fit as it is
    w2 = world(tmp_path / "keep", steps_patch={"refit_kept_control": False,
                                               "refit_kept_control_chosen_by": "owner 2026-11-03"})
    queue(w2, tmp_path / "keep", decisions={"A1_1seed": "ADOPT (pending the SELECT check)"})
    assert "start fit_nf_ka2_seed42" not in qlog(w2) and "start read_A2_1seed" in qlog(w2)
    # false without that record stops
    w3 = world(tmp_path / "blank", steps_patch={"refit_kept_control": False, "refit_kept_control_chosen_by": ""})
    r = queue(w3, tmp_path / "blank", decisions={"A1_1seed": "ADOPT (pending the SELECT check)"})
    assert r.returncode == 3 and "without a recorded decision" in qlog(w3)


def test_run_seeds_uses_the_base_refits_never_the_kept_checkpoints(tmp_path):
    w = world(tmp_path)
    queue(w, tmp_path, decisions={"A1_1seed": "RUN SEEDS 43 AND 44", "A1_3seed": "KEEP THE CONTROL"})
    log = qlog(w)
    assert "start fit_nf_control_seed43" in log and "start fit_nf_control_seed44" in log
    assert "start fit_nf_a1_seed43" in log and "start read_A1_3seed" in log
    dl = (c2(w) / "DECISIONS.log").read_text()
    assert dl.count("controls at 43 and 44: the base refits nf_control (D5b)") == 1
    table = json.loads((c2(w) / "reads" / "A1_3seed.runs.json").read_text())
    ctl = sorted((x["seed"], x["run_dir"]) for x in table["runs"] if x["role"] == "control")
    assert ctl[1][1].endswith("runs/nf_control/seed43") and ctl[2][1].endswith("runs/nf_control/seed44")
    assert not any("models/" in x["run_dir"] for x in table["runs"] if x["role"] == "control")


def test_existing_complete_folder_skipped_incomplete_stops(tmp_path):
    w = world(tmp_path)
    d = c2(w) / "runs" / "nf_a1" / "seed42"
    d.mkdir(parents=True)
    (d / "partial.txt").write_text("x")
    r = queue(w, tmp_path)
    assert r.returncode == 3
    assert "exists but incomplete: rename it" in qlog(w)
    assert "start fit_nf_a1_seed42" not in qlog(w)


def test_partial_score_outputs_stop(tmp_path):
    w = world(tmp_path)
    p = c2(w) / "scores" / "control_seed42__rank_b.parquet.exposure.json"
    p.parent.mkdir(parents=True)
    p.write_text("{}")
    r = queue(w, tmp_path)
    assert r.returncode == 3 and "partial outputs" in qlog(w)


def test_failed_fit_stops_with_1(tmp_path):
    w = world(tmp_path)
    r = queue(w, tmp_path, FAKE_FAIL_FIT="nf_a1")
    assert r.returncode == 1
    log = qlog(w)
    assert "end fit_nf_a1_seed42 rc=1" in log and "queue end rc=1" in log


def test_saved_decision_reused_and_stale_inputs_stop(tmp_path):
    w = world(tmp_path)
    queue(w, tmp_path, decisions={"A1_1seed": "KEEP THE CONTROL"}, )
    saved = json.loads((c2(w) / "reads" / "A1_1seed.json").read_text())
    # a later run with another planted decision does not step over the saved one
    queue(w, tmp_path, decisions={"A1_1seed": "ADOPT"})
    assert json.loads((c2(w) / "reads" / "A1_1seed.json").read_text()) == saved
    # a changed prediction file makes the saved read stale
    p = c2(w) / "scores" / "nf_a1_seed42__rank_b.parquet"
    p.write_bytes(b"changed")
    rec = json.loads(Path(str(p) + ".json").read_text())
    import hashlib
    rec["predictions_sha256"] = hashlib.sha256(b"changed").hexdigest()
    Path(str(p) + ".json").write_text(json.dumps(rec))
    r = queue(w, tmp_path)
    assert r.returncode == 3 and "inputs changed" in qlog(w)


def test_off_steps_skipped_and_one_step_all(tmp_path):
    w = world(tmp_path, steps_patch={"one_step_all": True})
    r = queue(w, tmp_path)
    log = qlog(w)
    assert "start fit_nf_all_seed42" in log
    assert "fit_nf_a1" not in log and "fit_nf_a3" not in log
    assert "start fit_nf_b_seed42" in log            # month out is on by default, last (the reviewers' D4c)
    head = (w / NF_REL / "configs" / "nf_all.yaml").read_text().splitlines()[0]
    assert "input set a1a2;" in head


def test_missing_stage1_control_blocks_without_owner_yes(tmp_path):
    w = world(tmp_path, stage1=False)
    r = queue(w, tmp_path)
    assert r.returncode == 3
    assert "every read is blocked" in qlog(w)
    w2 = make_world(tmp_path / "b", stage1=False, map_rows=default_map(), field_status=STATUS,
                    settings_patch={"control_p1_owner_yes": {"by": "owner", "on": "2026-11-03"}})
    r = queue(w2, tmp_path / "b", "--max-jobs", "2")
    log = qlog(w2)
    assert "start config_nf_control" in log and "start fit_nf_control_seed42" in log


def test_other_learning_rate_needs_p1(tmp_path):
    w = world(tmp_path, settings_patch={"learning_rate": 0.001})
    r = queue(w, tmp_path)
    assert r.returncode == 3 and "another learning rate" in qlog(w)


def test_failed_attention_is_reported_not_fatal(tmp_path):
    w = world(tmp_path)
    r = queue(w, tmp_path, FAKE_FAIL_ATTENTION=1)
    assert r.returncode == 5, qlog(w)
    assert "end attention_nf_a1_seed42 rc=2" in qlog(w)
    assert "start read_A1_1seed" in qlog(w)


def test_memory_rule_confound_stops(tmp_path):
    w = world(tmp_path, settings_patch={"microbatch": {"nf_a1": {"batch_size": 128,
                                                                  "accumulate_grad_batches": 32}}})
    r = queue(w, tmp_path)
    assert r.returncode == 3 and "micro-batch" in qlog(w)


def test_queue_lock_refuses_second_queue(tmp_path):
    w = world(tmp_path)
    import socket
    lock = c2(w) / "QUEUE.lock.json"
    lock.parent.mkdir(parents=True, exist_ok=True)
    other = subprocess.Popen(["sleep", "60"])
    try:
        lock.write_text(json.dumps({"pid": other.pid, "hostname": socket.gethostname(), "utc": "t"}))
        r = queue(w, tmp_path)
        assert r.returncode == 4 and "another queue" in qlog(w)
        found = run(w, tmp_path, "nf_plan.py", "busy")
        assert found.returncode == 4 and "QUEUE.lock.json" in found.stdout
    finally:
        other.kill()


def test_missing_rank_check_stops(tmp_path):
    w = world(tmp_path, rank_check=None)
    r = queue(w, tmp_path)
    assert r.returncode == 3 and "rank_check.json is missing" in qlog(w)


def test_select_decides_skips_kept_rank_b_scores(tmp_path):
    w = world(tmp_path, rank_check="FAIL")
    r = queue(w, tmp_path, "--max-jobs", "10")
    log = qlog(w)
    assert "score_control_seed42__select" in log
    assert "kept_seed43__rank_b" not in log
    assert "read_spread_select_june" in log


def test_report_fits_one_screen(tmp_path):
    w = world(tmp_path)
    queue(w, tmp_path)
    r = run(w, tmp_path, "nf_report.py")
    assert r.returncode == 0, r.stderr
    lines = r.stdout.splitlines()
    assert len(lines) <= 40 and all(len(x) <= 90 for x in lines)
    assert lines[0].startswith("NEW FIELDS ")
    assert any(x.startswith("nf_a1") for x in lines)
    assert (c2(w) / "REPORT.txt").is_file()


def test_prune_clusters_first(tmp_path):
    sys.path.insert(0, str(Path(__file__).resolve().parents[4] / NF_REL))
    import nf_plan
    imp = tmp_path / "importance.csv"
    # reading B (D4b): the upper ends of the UDR-drop and AP-drop intervals, both at or below zero
    imp.write_text("unit,kind,members,udr_drop_hi,ap_drop_hi\n"
                   "c1,cluster,f_a;f_b,0.01,0.002\n"      # cluster matters: neither twin drops
                   "f_a,single,f_a,-0.001,-0.001\n"
                   "f_b,single,f_b,-0.002,-0.001\n"
                   "c2,cluster,f_c;f_d,-0.001,-0.001\n"   # cluster weak: both drop
                   "f_e,single,f_e,-0.001,0.0\n"          # no cluster, weak: drops
                   "transaction_amt,single,transaction_amt,-1,-1\n")  # base input never drops
    assert nf_plan.prune_list(imp, None) == ["f_c", "f_d", "f_e"]


def test_job_that_writes_nothing_does_not_loop(tmp_path):
    w = world(tmp_path)
    imp = w / NF_REL / "nf_importance.py"
    imp.write_text("print('attention cannot be captured; left out')\n")
    r = queue(w, tmp_path)
    log = qlog(w)
    assert log.count("start attention_nf_a1_seed42") == 1, log
    assert "no output: attention_nf_a1_seed42" in log
    assert r.returncode == 5
    # a required job that writes nothing stops the queue
    w2 = world(tmp_path / "b")
    (w2 / NF_REL / "nf_read.py").write_text("import sys\n")
    r = queue(w2, tmp_path / "b")
    assert r.returncode == 3 and qlog(w2).count("start read_spread_rank_b") == 1


def test_unexpected_error_is_a_crash(tmp_path):
    w = world(tmp_path)
    (c2(w) / "reads" / "rank_check.json").write_text("{")
    r = queue(w, tmp_path)
    assert r.returncode == 1
    assert "crash:" in qlog(w) and "queue end rc=1" in qlog(w)


def test_child_refusal_keeps_its_code(tmp_path):
    w = world(tmp_path)
    (w / NF_REL / "nf_read.py").write_text("import sys\nsys.exit(4)\n")
    r = queue(w, tmp_path)
    assert r.returncode == 4 and "queue end rc=4" in qlog(w)


def test_prune_and_month_out_act_on_decisions(tmp_path):
    imp = "unit,kind,members,udr_drop_hi,ap_drop_hi\nf_code,single,f_code,-1,-1\n"
    w = world(tmp_path, steps_patch={"steps": [{"name": "A1", "on": True, "adds": ["v22b", "both"]},
                                               {"name": "A2", "on": False, "adds": ["f15298"]},
                                               {"name": "P", "on": True, "kind": "prune"},
                                               {"name": "B", "on": True, "kind": "month_out"}]})
    dec = {"A1_1seed": "ADOPT", "P_1seed": "KEEP THE SMALLER LIST", "B_1seed": "RUN SEEDS 43 AND 44",
           "B_3seed": "MONTH OUT"}
    r = queue(w, tmp_path, decisions=dec, FAKE_IMPORTANCE_CSV=imp)
    log = qlog(w)
    assert "start read_P_select" in log                      # keeping the smaller list gets the SELECT check
    assert "input set a1p;" in (w / NF_REL / "configs" / "nf_b.yaml").read_text().splitlines()[0]
    assert "start fit_nf_b_seed43" in log and "start read_B_3seed" in log and "start read_B_select" in log
    # D5a: pruning and month out read against seed-42 refits of the kept recipe; month out's seed 43 and 44
    # controls are new fits of that recipe
    assert "start fit_nf_kp_seed42" in log and "start fit_nf_kb_seed42" in log and "start fit_nf_kb_seed43" in log
    # D4c: an adopted month out gets the downstream check and its lift read
    assert "start downstream_nf_b_seed42" in log and "start read_B_lift" in log
    kept = json.loads((c2(w) / "KEPT.json").read_text())
    assert kept["input_set"] == "a1p" and kept["month"] == "out"
    assert kept["runs"]["42"].endswith("runs/nf_b/seed42")
    assert r.returncode in (0, 5), log


def test_existing_select_scores_are_reused(tmp_path):
    import hashlib
    w = world(tmp_path, rank_check="FAIL")
    up = w / NF_REL / "UPSTREAM.yaml"
    import yaml
    u = yaml.safe_load(up.read_text())
    preds, recs = {}, {}
    for sd in (42, 43, 44):
        d = w / f"models/sequential_hier_allpos_h20_chunk/seed{sd}/scores"
        d.mkdir(parents=True)
        (d / "select.parquet").write_bytes(f"p{sd}".encode())
        ck = (w / f"models/sequential_hier_allpos_h20_chunk/seed{sd}/best.ckpt").read_bytes()
        (d / "select.parquet.json").write_text(json.dumps(
            {"predictions_sha256": hashlib.sha256(f"p{sd}".encode()).hexdigest(),
             "checkpoint_sha256": hashlib.sha256(ck).hexdigest()}))
        preds[f"seed{sd}"] = f"models/sequential_hier_allpos_h20_chunk/seed{sd}/scores/select.parquet"
        recs[f"seed{sd}"] = preds[f"seed{sd}"] + ".json"
    recs["seed44"] = preds["seed42"] + ".json"               # a receipt that does not match: seed 44 is rescored
    u["kept"]["select_predictions"], u["kept"]["select_receipts"] = preds, recs
    up.write_text(yaml.safe_dump(u))
    queue(w, tmp_path, "--max-jobs", "8")
    log = qlog(w)
    assert "score_kept_seed42__select" not in log and "score_kept_seed43__select" not in log
    assert "start score_kept_seed44__select" in log
    table = json.loads((c2(w) / "reads" / "spread_select_june.runs.json").read_text())
    assert table["runs"][0]["predictions"].endswith("seed42/scores/select.parquet")


def test_report_and_plan_write_nothing(tmp_path):
    w = world(tmp_path)
    before = sorted(p.relative_to(w) for p in c2(w).rglob("*"))
    run(w, tmp_path, "nf_plan.py", "plan")
    after = sorted(p.relative_to(w) for p in c2(w).rglob("*"))
    assert before == after
    r = run(w, tmp_path, "nf_report.py")
    after = sorted(p.relative_to(w) for p in c2(w).rglob("*") if p.name != "REPORT.txt")
    assert before == after, r.stderr


def test_read_without_inputs_record_stops(tmp_path):
    w = world(tmp_path)
    queue(w, tmp_path, decisions={"A1_1seed": "KEEP THE CONTROL"})
    (c2(w) / "reads" / "A1_1seed.inputs.json").unlink()
    r = queue(w, tmp_path)
    assert r.returncode == 3 and "no inputs record" in qlog(w)


def test_start_needs_the_project_python(tmp_path):
    w = world(tmp_path)
    r = subprocess.run(["bash", str(w / NF_REL / "nf_start.sh")], cwd=w, capture_output=True, text=True,
                       env=env(w, tmp_path, NF_NO_TAIL=1), timeout=60)
    assert r.returncode == 2 and "set PY" in r.stderr
