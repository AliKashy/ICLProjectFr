"""SELECT must check the same candidate/control checkpoints as the pending RANK-B read."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from new_fields_reader_world import World, scores, sha, write_spread


def _pending(world, seeds=(42,)):
    write_spread(world.c2, "rank_b", 0.001)
    pairs = {}
    for pop in ("rank_b", "select"):
        raw = world.raw[pop][0]
        pairs[pop] = (
            [world.fit(pop, "candidate", s, scores(raw, 6.0, s)) for s in seeds],
            [world.fit(pop, "control", s, scores(raw, 0.5, s + 10)) for s in seeds],
        )
    table = world.table("rank", *pairs["rank_b"])
    assert world.run("read", "--step", "A1", "--runs", table) == 0
    read = world.saved(f"A1_{len(seeds)}seed.json")
    assert read["pending_select_check"]
    return pairs["select"], read


def _replace_checkpoint(fit, content):
    checkpoint = Path(fit["run_dir"]) / "best.ckpt"
    checkpoint.write_bytes(content)
    receipt = Path(f"{fit['predictions']}.json")
    record = json.loads(receipt.read_text())
    record["checkpoint_sha256"] = sha(checkpoint)
    receipt.write_text(json.dumps(record))


@pytest.mark.parametrize("seeds,role,index", [
    ((42,), "candidate", 0), ((42,), "control", 0),
    ((42, 43, 44), "candidate", 1), ((42, 43, 44), "control", 2),
])
def test_select_rejects_a_different_checkpoint_with_valid_receipt(tmp_path, monkeypatch, capsys, seeds, role, index):
    world = World(tmp_path, monkeypatch, accounts=350)
    (candidates, controls), _ = _pending(world, seeds)
    changed = (candidates if role == "candidate" else controls)[index]
    # Same run name, seed and predictions; the new receipt correctly names the replacement checkpoint.
    _replace_checkpoint(changed, b"replacement checkpoint")
    assert world.run("select-check", "--step", "A1", "--runs",
                     world.table("select", candidates, controls)) == 3
    out = capsys.readouterr().out
    assert "checkpoint" in out and "pending read" in out
    assert role in out and str(changed["seed"]) in out
    assert not (world.c2 / "reads" / "A1_select.json").exists()


@pytest.mark.parametrize("seeds", [(42,), (42, 43, 44)])
def test_select_accepts_matching_checkpoints_with_different_population_predictions(tmp_path, monkeypatch, seeds):
    world = World(tmp_path, monkeypatch, accounts=350)
    (candidates, controls), pending = _pending(world, seeds)
    table = world.table("select", candidates[::-1], controls[::-1])
    assert world.run("select-check", "--step", "A1", "--runs", table) == 0
    checked = world.saved("A1_select.json")
    assert checked["final_decision"] == "ADOPT"
    previous = {(r["role"], r["seed"]): r for r in pending["inputs"]["fits"]}
    for row in checked["inputs"]["fits"]:
        old = previous[row["role"], row["seed"]]
        assert row["checkpoint_sha256"] == old["checkpoint_sha256"]
        assert row["predictions_sha256"] != old["predictions_sha256"]
    # The completed SELECT check remains reusable with exactly the same inputs.
    assert world.run("select-check", "--step", "A1", "--runs", table) == 0


def test_select_rejects_swapped_candidate_control_checkpoints(tmp_path, monkeypatch, capsys):
    world = World(tmp_path, monkeypatch, accounts=350)
    (candidates, controls), _ = _pending(world)
    c_bytes = (Path(candidates[0]["run_dir"]) / "best.ckpt").read_bytes()
    k_bytes = (Path(controls[0]["run_dir"]) / "best.ckpt").read_bytes()
    _replace_checkpoint(candidates[0], k_bytes)
    _replace_checkpoint(controls[0], c_bytes)
    assert world.run("select-check", "--step", "A1", "--runs",
                     world.table("select", candidates, controls)) == 3
    assert "pending read" in capsys.readouterr().out


@pytest.mark.parametrize("change", ["missing", "duplicate"])
def test_select_rejects_unrecorded_or_ambiguous_pending_checkpoint(tmp_path, monkeypatch, capsys, change):
    world = World(tmp_path, monkeypatch, accounts=350)
    (candidates, controls), pending = _pending(world)
    if change == "missing":
        pending["inputs"]["fits"][0].pop("checkpoint_sha256")
    else:
        pending["inputs"]["fits"].append(pending["inputs"]["fits"][0])
    (world.c2 / "reads" / "A1_1seed.json").write_text(json.dumps(pending))
    assert world.run("select-check", "--step", "A1", "--runs",
                     world.table("select", candidates, controls)) == 3
    assert "pending read" in capsys.readouterr().out
