"""Width timing (component 15): the wrapper changes nothing about training, the step limits and the timer work on
CPU, the memory rule halves and doubles as declared, the same chunks reach each update, and no hashed file
changes. CPU only; every cuda call in the tool is guarded."""
import json
import os
import sys
import warnings
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import new_fields_gpu_world as W  # noqa: E402

pytestmark = pytest.mark.skipif(W.base_config_path() is None, reason="no chosen-model base config in this tree")


@pytest.fixture()
def world(tmp_path, monkeypatch):
    monkeypatch.setenv("CUDA_VISIBLE_DEVICES", "")
    old = {k: os.environ.get(k) for k in ("NF_OUT", "NF_SETTINGS_DIR")}
    w = W.build(tmp_path / "world")
    yield w
    for k, v in old.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v


def T():
    import nf_time_width
    return nf_time_width


def _ckpt(path):
    import torch
    return torch.load(path, map_location="cpu", weights_only=False)


def _equal_tensors(a, b):
    import torch
    if isinstance(a, torch.Tensor):
        return isinstance(b, torch.Tensor) and a.dtype == b.dtype and a.shape == b.shape and torch.equal(a, b)
    if isinstance(a, dict):
        return isinstance(b, dict) and set(a) == set(b) and all(_equal_tensors(a[k], b[k]) for k in a)
    if isinstance(a, (list, tuple)):
        return isinstance(b, (list, tuple)) and len(a) == len(b) and all(_equal_tensors(x, y) for x, y in zip(a, b))
    return a == b


def _assert_same_run(dir_a, dir_b):
    for name in ("best.ckpt", "last.ckpt"):
        a, b = _ckpt(Path(dir_a) / name), _ckpt(Path(dir_b) / name)
        assert _equal_tensors(a["state_dict"], b["state_dict"]), f"{name} weights differ"
        assert _equal_tensors(a["optimizer_states"], b["optimizer_states"]), f"{name} optimizer state differs"
        assert set(a["callbacks"]) == set(b["callbacks"]), f"{name} callback keys differ"
        rs = [k for k in a["callbacks"] if "RandomStateCallback" in k]
        assert rs and _equal_tensors(a["callbacks"][rs[0]], b["callbacks"][rs[0]]), "random number use differs"
        assert a["global_step"] == b["global_step"] and a["epoch"] == b["epoch"]
    assert (Path(dir_a) / "training_metrics.csv").read_bytes() == (Path(dir_b) / "training_metrics.csv").read_bytes()
    ma = json.loads((Path(dir_a) / "run_manifest_v2.json").read_text())
    mb = json.loads((Path(dir_b) / "run_manifest_v2.json").read_text())
    for k in ("status", "epochs_run", "optimizer_steps"):
        assert ma[k] == mb[k]
    assert ma["start"]["identity"] == mb["start"]["identity"]
    assert ma["start"]["source_sha256"] == mb["start"]["source_sha256"]


def test_width_counts_tokens_as_the_model_does(world):
    t = T()
    cfg = t.load_cfg(world["config"])
    w = t.token_width(cfg)
    ds, _ = t._training_dataset(cfg)
    assert w["continuous_dim"] == len(ds.continuous_cols)
    assert w["categorical_inputs"] == len(ds.categorical_cardinality)
    assert w["tokens"] == len(ds.continuous_cols) + len(ds.categorical_cardinality) == 11
    # The base list: 6 continuous and 17 categorical (4 of them calendar fields) give 30 tokens, 31 with CLS.
    lines = ["feature,type,source,version,description"]
    lines += [f"n{i},continuous,raw,1,x" for i in range(6)] + [f"k{i},categorical,raw,1,x" for i in range(13)]
    lines += [f"{f},categorical,derived:transaction_dttm,1,x" for f in W.DATETIME_FIELDS]
    p = world["tmp"] / "base23.csv"
    p.write_text("\n".join(lines) + "\n")
    cfg.predictors.csv_path = str(p)
    w = t.token_width(cfg)
    assert (w["fields"], w["tokens"], w["tokens_with_cls"]) == (23, 30, 31)
    assert w["label"].startswith("23 fields -> 30 tokens")


def test_row_limit_uses_the_trainer_check(world):
    t = T()
    cfg = t.load_cfg(world["config"])
    rl = t.row_limit(cfg)
    assert rl["ok"] and rl["limit"] == 65535 and rl["train_rows"] == 8 * 96 and rl["eval_rows"] == 16 * 32
    cfg.training.batch_size = 700  # 700 x 96 = 67,200 rows
    rl = t.row_limit(cfg)
    assert not rl["ok"] and "65535" in rl["reason"]
    assert t.main(["width", "--config", str(world["config"])]) == 0


def test_memory_rule_halves_and_doubles():
    t = T()
    plan = {"batch_size": 64, "accumulate_grad_batches": 2, "eval_batch_size": 1024}
    nxt, why = t.next_plan(plan, {"status": "oom", "oom_phase": "train"})
    assert nxt == {"batch_size": 32, "accumulate_grad_batches": 4, "eval_batch_size": 1024}
    assert nxt["batch_size"] * nxt["accumulate_grad_batches"] == 128  # targets per update kept
    high = {"status": "ok", "device_total_gib": 100.0, "peaks": {"train": {"alloc_gib": 80, "reserved_gib": 86}}}
    assert t.next_plan(plan, high)[0]["batch_size"] == 32
    fits = {"status": "ok", "device_total_gib": 100.0, "peaks": {"train": {"alloc_gib": 80, "reserved_gib": 84}}}
    assert t.next_plan(plan, fits) == (None, "fits")
    nxt, _ = t.next_plan(plan, {"status": "oom", "oom_phase": "validation"})
    assert nxt["eval_batch_size"] == 512 and nxt["batch_size"] == 64
    assert t.next_plan({**plan, "eval_batch_size": 128}, {"status": "oom", "oom_phase": "validation"})[0] == "stop"
    assert t.next_plan({**plan, "batch_size": 8}, {"status": "oom", "oom_phase": "train"})[0] == "stop"
    assert t.next_plan({**plan, "batch_size": 33}, {"status": "oom", "oom_phase": "train"})[0] == "stop"
    assert t.next_plan(plan, {"status": "error", "error_type": "KeyError", "error": "x"})[0] == "stop"


def test_timer_changes_nothing_on_a_full_run(world):
    """Same weights, optimizer state, random number use, metrics CSV and manifest identity as the unwrapped
    trainer, over two full epochs; no hashed file changes."""
    import nf_layout
    t = T()
    before = W.hashed_files()
    source_before = nf_layout.attr("trainer", "source_sha256")()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        plain = world["tmp"] / "plain"
        nf_layout.get("trainer").main(["--config", str(world["config"]), f"output.checkpoint_dir={plain}"])
        wrapped = world["tmp"] / "wrapped"
        timer = t.make_timer(warmup=0)
        t.run_wrapped(world["config"], wrapped, timer=timer)
    _assert_same_run(plain, wrapped)
    s = timer.summary()
    assert s["updates"] > 0 and s["validation_batches"] > 0 and s["route_other"] == 0 and not s["cuda"]
    assert s["sanity_ran"] and set(s["peaks"]) == {"sanity", "train", "validation"}
    assert all(v is None for v in s["peaks"].values()) and s["overall_peak"] is None  # no CUDA: not measured
    assert nf_layout.get("trainer").build_trainer.__name__ == "build_trainer"  # put back
    assert W.hashed_files() == before
    assert nf_layout.attr("trainer", "source_sha256")() == source_before


def test_step_limits_with_and_without_timer(world):
    t = T()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        a, b = world["tmp"] / "lim_a", world["tmp"] / "lim_b"
        t.run_wrapped(world["config"], a, updates=2, val_batches=2, overrides=["training.max_epochs=1"])
        timer = t.make_timer(warmup=0)
        t.run_wrapped(world["config"], b, updates=2, val_batches=2, overrides=["training.max_epochs=1"], timer=timer)
    _assert_same_run(a, b)
    s = timer.summary()
    assert s["updates"] == 2 and s["micro_batches"] == 2 and s["validation_batches"] == 2
    assert not s["sanity_ran"] and s["targets_per_update"]["min"] > 0
    assert s["compute_per_update_s"]["median"] > 0 and s["host_rss"]["main_gib"] > 0
    m = json.loads((b / "run_manifest_v2.json").read_text())
    assert m["optimizer_steps"] == 2 and m["status"] == "budget_reached"


def test_accumulation_counts_updates_not_micro_batches(world):
    t = T()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        timer = t.make_timer(warmup=0)
        t.run_wrapped(world["config"], world["tmp"] / "acc", updates=1, val_batches=1,
                      overrides=["training.max_epochs=1", "training.batch_size=4",
                                 "training.accumulate_grad_batches=2"], timer=timer)
    s = timer.summary()
    assert s["micro_batches"] == 2 and s["updates"] == 1 and s["micro_per_update"]["mean"] == 2


def test_real_run_applies_the_memory_rule_one_process_per_attempt(world, monkeypatch, capsys):
    t = T()
    monkeypatch.setenv(t.SIMULATE_OOM_ENV, "train>=8")
    rc = t.main(["real", "--config", str(world["config"]), "--run", "nf_a1", "--updates", "2", "--val-batches", "2",
                 "--warmup", "0", "--min-chunks", "2", "--no-busy-check", "--write-settings"])
    assert rc == 0, capsys.readouterr().out
    rec = json.loads((world["c2"] / "timing" / "nf_a1.json").read_text())
    assert [a["status"] for a in rec["attempts"]] == ["oom", "ok"]
    assert rec["attempts"][0]["plan"]["batch_size"] == 8
    assert rec["final_plan"] == {"batch_size": 4, "accumulate_grad_batches": 2, "eval_batch_size": 16}
    assert rec["rule_fired"] and rec["verdict"] == "OK"
    assert rec["result"]["updates"] == 2 and rec["result"]["micro_per_update"]["mean"] == 2
    assert rec["costs"]["epoch_label"] == "projection from the timed run" and rec["costs"]["step_max_h"] > 0
    assert len({a["json"] for a in rec["attempts"]}) == 2
    pids = {json.loads((world["c2"] / "timing" / "nf_a1" / f"attempt_{k}.json").read_text())["pid"] for k in (0, 1)}
    assert len(pids) == 2 and os.getpid() not in pids
    text = (world["c2"] / "timing" / "nf_a1.txt").read_text()
    lines = text.rstrip("\n").splitlines()
    assert len(lines) <= 40 and max(len(x) for x in lines) <= 90
    assert "memory rule fired" in text and "declared confound" in text
    import yaml
    s = yaml.safe_load((world["settings"] / "SETTINGS.yaml").read_text())
    assert s["microbatch"]["nf_a1"] == {"accumulate_grad_batches": 2, "batch_size": 4, "eval_batch_size": 16}
    assert "# per run" in (world["settings"] / "SETTINGS.yaml").read_text()
    # A second call skips; an incomplete folder is refused.
    assert t.main(["real", "--config", str(world["config"]), "--run", "nf_a1", "--no-busy-check"]) == 0
    (world["c2"] / "timing" / "nf_a2").mkdir(parents=True)
    assert t.main(["real", "--config", str(world["config"]), "--run", "nf_a2", "--no-busy-check"]) == 4


def test_real_run_stops_when_no_plan_fits(world, monkeypatch):
    t = T()
    monkeypatch.setenv(t.SIMULATE_OOM_ENV, "validation>=1")
    rc = t.main(["real", "--config", str(world["config"]), "--run", "nf_v", "--updates", "1", "--val-batches", "1",
                 "--warmup", "0", "--min-eval", "8", "--no-busy-check"])
    assert rc == 3
    rec = json.loads((world["c2"] / "timing" / "nf_v.json").read_text())
    assert [a["plan"]["eval_batch_size"] for a in rec["attempts"]] == [16, 8]
    assert rec["verdict"].startswith("STOP") and rec["final_plan"] is None


def test_same_chunks_reach_each_update(world):
    t = T()
    cfg = t.load_cfg(world["config"])
    res = t.compare_chunks(cfg, 8, 1)
    assert res["same_chunks_every_update"] and res["differ"] == 0 and res["updates_a"] > 1
    cfg.training.buffer_windows = 12  # a buffer of 12 cuts into 8 + 4 at batch 8 but 4 + 4 + 4 at batch 4
    res = t.compare_chunks(cfg, 8, 1)
    assert not res["same_chunks_every_update"] and res["differ"] > 0
    assert t.main(["chunks", "--config", str(world["config"]), "--batch", "8"]) == 0


def test_encode_cost_and_host_memory(world):
    t = T()
    assert t.main(["encode", "--config", str(world["config"]), "--run", "nf_a1"]) == 0
    rec = json.loads((world["c2"] / "timing" / "encode" / "nf_a1.json").read_text())
    assert rec["train"]["rows"] == len(world["frames"][1]) and rec["validation"]["rows"] == len(world["frames"][3])
    assert rec["host_memory_ok"] and rec["projected_encode_h_per_epoch"] > 0
    assert t.main(["encode", "--config", str(world["config"]), "--run", "nf_tiny", "--share", "1e-9"]) == 3


def test_costs_scale_stage1_numbers():
    t = T()
    now = {"compute_per_update_s": {"median": 0.30}, "data_wait_per_update_s": {"median": 0.02},
           "validation_per_batch_s": {"median": 0.06}}
    base = {"compute_per_update_s": {"median": 0.15}, "validation_per_batch_s": {"median": 0.04}}
    c = t.costs(now, base, {"C_c": 2.0, "C_v": 0.5})
    # time per update = compute + data wait (DESIGN.md 5); the base run had no wait
    assert c["ratio_update"] == pytest.approx(0.32 / 0.15) and c["ratio_compute"] == pytest.approx(2.0)
    assert c["C_f"] == pytest.approx(2.0 * 0.32 / 0.15) and c["data_wait_share"] == pytest.approx(0.02 / 0.32)
    assert c["C_vf"] == pytest.approx(0.75) and c["epoch_h"] == pytest.approx(c["C_f"] + 0.75)
    assert c["step_max_h"] == pytest.approx(10 * c["epoch_h"]) and c["confirmation_max_h"] == pytest.approx(20 * c["epoch_h"])
    c = t.costs(now, None, None)
    assert c["epoch_label"] == "projection from the timed run"
    assert c["epoch_h"] == pytest.approx(2103 * 0.32 / 3600)
    c = t.costs(now, base, {"C_c": 2.0, "C_v": 0.5}, encode={"projected_encode_h_per_epoch": 9.0})
    assert c["epoch_h"] == 9.0 and "encoding bound" in c["epoch_label"]


def test_an_attempt_that_measured_nothing_is_an_error():
    t = T()
    ok = {"updates": 300, "micro_batches": 600, "validation_batches": 200}
    assert t.attempt_problems(ok, 300, 200, 2) == []
    assert t.attempt_problems({**ok, "updates": 0, "micro_batches": 0}, 300, 200, 2)  # timer never attached
    assert t.attempt_problems({**ok, "updates": 2103, "micro_batches": 4206}, 300, 200, 2)  # limits ignored
    assert t.attempt_problems({**ok, "validation_batches": 0}, 300, 200, 2)
    assert t.attempt_problems({**ok, "validation_batches": 5000}, 300, 200, 2)
    assert t.attempt_problems({**ok, "updates": 100, "micro_batches": 600}, 300, 200, 2)


def test_default_attempts_reach_both_floors():
    t = T()
    assert t.default_attempts({"batch_size": 512, "eval_batch_size": 1024}) == 6 + 3 + 1
    assert t.default_attempts({"batch_size": 8, "eval_batch_size": 128}) == 1


def test_loader_workers_change_the_chunks_of_an_update(world):
    t = T()
    cfg = t.load_cfg(world["config"])
    cfg.training.num_workers = 2  # batches come from the two workers in turn
    res = t.compare_chunks(cfg, 8, 1)
    assert res["num_workers"] == 2 and not res["same_chunks_every_update"] and res["differ"] > 0


def test_targets_count_one_per_window_for_target_ending_training(world):
    t = T()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        timer = t.make_timer(warmup=0)
        t.run_wrapped(world["config"], world["tmp"] / "te", updates=2, val_batches=1,
                      overrides=["training.max_epochs=1", "sequence.train_target_ending=true"], timer=timer)
    s = timer.summary()
    assert s["updates"] == 2
    assert s["targets_per_update"]["mean"] == s["chunks_per_micro"]["mean"]  # one target per window
