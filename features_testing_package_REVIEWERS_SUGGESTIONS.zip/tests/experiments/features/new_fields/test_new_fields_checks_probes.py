"""Strictly-earlier probes: a correct builder passes every probe; each planted fault fails its probe."""

import numpy as np
import pandas as pd

from new_fields_checks_helpers import load

M = load("nf_checks_measure")
S = load("nf_checks_synth")
ACC, TIME, TID, LAB = S.ACC, S.TIME, S.TID, S.LAB


def _frame(n_acct=40, seed=3):
    rng = np.random.default_rng(seed)
    rows = []
    for a in range(n_acct):
        ts = np.sort(rng.integers(pd.Timestamp("2024-10-01").value // 10**9,
                                  pd.Timestamp("2025-01-31").value // 10**9, 40))
        for i, t in enumerate(ts):
            rows.append((f"a{a}", pd.Timestamp(int(t), unit="s"), f"t{a}_{i}", int(rng.random() < 0.05),
                         float(rng.gamma(2, 50)), rng.choice(["m1", "m2", "m3"])))
    df = pd.DataFrame(rows, columns=[ACC, TIME, TID, LAB, "amt", "new_code"])
    df.index = pd.RangeIndex(len(df))
    return df


def _spec(recipe):
    return {"name": "x", "recipe": recipe, "fn": recipe.split("(")[0], "row": {}}


def count_24h(frame, start="2024-10-01"):
    return S.build_count(_spec("count(24h)"), frame, start)[0]


def count_24h_inclusive(frame, start="2024-10-01"):
    """Planted fault: counts rows in the same second (the row's own siblings)."""
    acct, _ = pd.factorize(frame[ACC].astype(str))
    sec = pd.to_datetime(frame[TIME]).to_numpy(dtype="datetime64[s]").astype(np.int64)
    key = acct.astype(np.int64) * 10**10 + sec
    ks = np.sort(key)
    lo = np.searchsorted(ks, key - 86400, side="left")
    hi = np.searchsorted(ks, key, side="right") - 1
    return pd.Series((hi - lo).astype(float), index=frame.index)


def next_new_code(frame):
    """Planted fault: a look-ahead over a new source column (not a base input)."""
    acct, _ = pd.factorize(frame[ACC].astype(str))
    sec = pd.to_datetime(frame[TIME]).to_numpy(dtype="datetime64[s]").astype(np.int64)
    order = np.lexsort((np.arange(len(frame)), sec, acct))
    v = frame["new_code"].to_numpy(dtype=object)[order]
    a = acct[order]
    nxt = np.r_[v[1:], None]
    nxt[np.r_[a[1:] != a[:-1], True]] = None
    out = np.empty(len(frame), dtype=object)
    out[order] = nxt
    return pd.Series(out, index=frame.index, dtype=object)


def label_rate(frame):
    """Planted fault: reads the label."""
    return frame.groupby(ACC)[LAB].transform("mean").astype(float)


def since_last_zero(frame):
    """Planted fault: zero when there is no earlier row, instead of missing."""
    t = pd.to_datetime(frame[TIME])
    prev = t.groupby(frame[ACC]).shift(1)
    return ((t - prev).dt.total_seconds() / 60.0).fillna(0.0)


def test_a_correct_builder_passes_every_probe():
    f = _frame()
    assert M.probe_future_invariance(f, count_24h, ["amt"], ACC, TIME)["ok"]
    assert M.probe_future_deletion(f, count_24h, ACC, TIME)["ok"]
    r = M.probe_history_deletion(f, lambda fr, s: count_24h(fr, s or "2024-10-01"), TIME, reach_seconds=86400)
    assert r["ok"] and r["rows_in_censor_zone"] > 0
    assert M.probe_same_second(f, count_24h, ["amt"], ACC, TIME, TID)["ok"]
    assert M.probe_label_permutation(f, count_24h, [LAB])["ok"]


def test_future_invariance_perturbs_the_new_source_column():
    f = _frame()
    r = M.probe_future_invariance(f, next_new_code, ["new_code"], ACC, TIME)
    assert not r["ok"] and r["rows_changed"] > 0


def test_same_second_sibling_is_caught():
    assert not M.probe_same_second(_frame(), count_24h_inclusive, ["amt"], ACC, TIME, TID)["ok"]


def test_label_permutation_catches_a_label_reader():
    assert not M.probe_label_permutation(_frame(), label_rate, [LAB])["ok"]


def test_history_deletion_catches_a_zero_where_history_is_censored():
    f = _frame()

    def no_censor(fr, start):
        return S.build_count_zero(_spec("dryrun_count_zero(24h)"), fr, start or "2024-10-01")[0]

    assert not M.probe_history_deletion(f, no_censor, TIME, reach_seconds=86400)["ok"]


def test_one_row_account_gives_missing():
    f = _frame()
    prev_amt = lambda fr: S.build_prev(_spec("prev(amt)"), fr, "2024-10-01")[0]  # noqa: E731
    assert M.probe_one_row(f, prev_amt, ACC)["ok"]
    assert not M.probe_one_row(f, since_last_zero, ACC)["ok"]


def test_recipe_reach_reads_window_lag_and_within():
    assert M.recipe_reach_seconds("count(24h; lag=1h)") == 90000
    assert M.recipe_reach_seconds("since_first(days; same=c; within=90d)") == 90 * 86400
    assert M.recipe_reach_seconds("since_last(minutes)") is None
