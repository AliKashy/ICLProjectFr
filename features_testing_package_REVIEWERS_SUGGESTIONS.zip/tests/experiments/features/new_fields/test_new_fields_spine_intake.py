"""Intake: footer-only schema read and the column count; suggestions never applied; the recipe grammar; name clashes;
status rules from STATUS_RULES.csv; Sumegha's rows; outcomes; generic sources; known future dates; adopt is the only
way to CONFIRMED and keeps the other rows; the definitions file holds every column of DESIGN.md 2.7."""
import json
import sys
from pathlib import Path

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from new_fields_spine_world import NF_REL, default_map, make_world, run  # noqa: E402

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / NF_REL))
import nf_common as C  # noqa: E402
import nf_intake as I  # noqa: E402


# ------------------------------------------------------------------ grammar

@pytest.mark.parametrize("text,func,cols,window", [
    ("raw", "raw", [], ""),
    ("days_before(cprcust__panprofilechgdt)", "days_before", ["cprcust__panprofilechgdt"], ""),
    ("days_until(card_expiration_dt)", "days_until", ["card_expiration_dt"], ""),
    ("code(merchant_category_xcd)", "code", ["merchant_category_xcd"], ""),
    ("count(24h)", "count", [], "24h"),
    ("count(48h; where=channel:A,B; same=merchant_category_xcd; lag=1h)", "count",
     ["channel", "merchant_category_xcd"], "48h"),
    ("mean(7d; value=transaction_amt)", "mean", ["transaction_amt"], "7d"),
    ("distinct(30d; value=merchant_postal_xcd)", "distinct", ["merchant_postal_xcd"], "30d"),
    ("since_last(minutes)", "since_last", [], "30d"),
    ("since_first(days; same=merchant_xid; within=30d)", "since_first", ["merchant_xid"], "30d"),
    ("prev(falcondecline_indicator)", "prev", ["falcondecline_indicator"], "30d"),
    ("ratio(transaction_amt; total_available_balance_amt)", "ratio",
     ["transaction_amt", "total_available_balance_amt"], ""),
    ("a3(amt_z_30d)", "a3", [], ""),
    ("count(3600s)", "count", [], "1h"),          # one grammar (nf_recipes): 3600 seconds is labelled 1h
])
def test_grammar_parses(text, func, cols, window):
    p = I.parse_recipe(text)
    assert p["func"] == func and p["columns"] == cols and p["window"] == window


@pytest.mark.parametrize("text", [
    # one grammar (integration decision 4): nf_recipes.parse. It also takes since_last(hours) and
    # distinct(...; same=y), so those two left this list.
    "", "sum(24h)", "count(25h)", "mean(value=x)", "days_before(a; b)", "since_last(weeks)", "since_first(days)",
    "lookup(x)", "count(24h; frob=1)", "count(24h; where=channel)", "ratio(a)", "prev(a; lag=2h)",
    "code(a b)", "raw(x)", "count(0s)", "mean(24h; value=transaction_dttm)",
])
def test_grammar_refuses(text):
    with pytest.raises(I.RecipeError):
        I.parse_recipe(text)


# ------------------------------------------------------------------ check-map rules

BASE = ["transaction_amt", "external_1_scr", "merchant_category_xcd_base", "month", "day", "hour", "day_of_week"]


def row(**kw):
    r = {c: "" for c in C.FIELD_MAP_COLUMNS}
    r.update(group="v22b", kind="raw", recipe="raw", model_type="categorical", definition_version="1",
             excluded_by_sumegha="no", feasible_in_production="yes", list_status="UNCONFIRMED")
    r.update(kw)
    if r["recipe"] == "raw" and not r["source_columns"]:
        r["source_columns"] = r["name"]
    return r


def check(rows, pod=None):
    df = pd.DataFrame(rows, columns=C.FIELD_MAP_COLUMNS)
    rules = I.status_rules(ROOT / NF_REL / "STATUS_RULES.csv")
    thr = C.load_yaml(ROOT / NF_REL / "CHECK_THRESHOLDS.yaml")
    df2, res = I.check_map(df, pod=pod, base=BASE, rules=rules, thr=thr)
    return df2, {x["name"]: x for x in res}


def has(res, name, rule, level=None):
    return any(r.split()[1].rstrip(":") == rule and (level is None or r.startswith(level))
               for r in res[name]["reasons"])


def test_clean_raw_field_passes():
    _, r = check([row(name="merchant_country_xcd")])
    assert r["merchant_country_xcd"]["result"] == "PASS", r["merchant_country_xcd"]["reasons"]


def test_name_clashes():
    rows = [row(name="transaction_amt", model_type="continuous"), row(name="month"),
            row(name="x_isna"), row(name="time_delta"),
            row(name="fi_transaction_id")]
    _, r = check(rows)
    for n in ("transaction_amt", "month", "x_isna", "time_delta", "fi_transaction_id"):
        assert has(r, n, "name_clash", "STOP"), n


def test_engineered_name_equal_to_pod_column_stops():
    pod = {"amt_cnt": {"ranges_missing": "", "files_missing": "", "types": "double"},
           "Nmap_account_reference_xid": {"ranges_missing": "", "files_missing": "", "types": "string"}}
    _, r = check([row(name="amt_cnt", kind="engineered", recipe="count(24h)", source_columns="",
                      model_type="continuous")], pod=pod)
    assert has(r, "amt_cnt", "name_clash", "STOP")


def test_status_rules_from_file():
    rows = [
        row(name="inactv_dt__days", kind="engineered", recipe="days_before(inactv_dt)", source_columns="inactv_dt",
            model_type="continuous"),
        row(name="pw__days", kind="engineered", recipe="days_before(cprcust__onlinebankpwstatuschgdt)",
            source_columns="cprcust__onlinebankpwstatuschgdt", model_type="continuous"),
        row(name="cprcust__astatus_flag"),
        row(name="cpracct__ddaewstxndata_hold_seg"),
        row(name="cprcust__cardblockdt"),
    ]
    df, r = check(rows)
    assert has(r, "inactv_dt__days", "left_out_26oct", "STOP")
    assert r["pw__days"]["result"] != "STOP" and not has(r, "pw__days", "status")
    assert df.loc[1, "status_rule"] == "rank52"
    assert has(r, "cpracct__ddaewstxndata_hold_seg", "status", "WAIT")
    assert has(r, "cprcust__cardblockdt", "status", "WAIT")


def test_left_out_names_apply_to_tfm_name_case_insensitively():
    _, r = check([row(name="my_flag", tfm_name="CPRSRVC__PISINFO2_STATUS")])
    assert has(r, "my_flag", "left_out_26oct", "STOP")


def test_status_scan_does_not_stop_legitimate_fields():
    """Design review item 7: whole tokens, so these are not status-like."""
    names = ["merchant_state_xcd", "cprsrvc__pisinfo_cardholder_postal_xcd", "tokenization_indicator",
             "user_indicator_7_xcd", "cprcust__authcsusploc_risky_ip_country_xcd",
             "cprsrvc__pisinfo_cardholder_country_xcd", "card_offln_static_authctn_xflg",
             "cprsrvc__dbt_travel_countrydate_cardholder_travel_curr_country", "cardholder_present_xflg"]
    _, r = check([row(name=n) for n in names])
    for n in names:
        assert not has(r, n, "status"), (n, r[n]["reasons"])


def test_status_scan_over_both_draft_lists():
    """Every yes row of the cleaned V22B draft and every 15298 source is free of a false status match."""
    cand = ROOT / "11_01_2026" / "features_work" / "CANDIDATE_FIELDS_UNCONFIRMED.csv"
    xw = ROOT / "11_01_2026" / "features_work" / "15298_RECIPE_CROSSWALK.csv"
    if not cand.is_file() or not xw.is_file():
        pytest.skip("draft lists are records outside the package")
    rules = I.status_rules(ROOT / NF_REL / "STATUS_RULES.csv")
    d = pd.read_csv(cand, dtype=str, keep_default_na=False)
    yes = d[(d.draft_include == "yes") & (d.is_status_field_or_status_date != "yes")]
    hits = [n for n in yes.pod_column if I.status_of({"name": n}, rules, [n])]
    assert hits == [], hits
    x = pd.read_csv(xw, dtype=str, keep_default_na=False)
    for src in [s for s in x.recorded_source_column if s]:
        st = I.status_of({"name": "f"}, rules, [src])
        assert st is None or st[0] in ("left_out_26oct", "rank52", "same_txn_decision") or \
            any(k in src.lower() for k in ("status", "prior_action", "claim", "disposition")), (src, st)


def test_same_transaction_decisions():
    rows = [row(name="falcondecline_indicator"),
            row(name="prev_falcon", kind="engineered", recipe="prev(falcondecline_indicator)",
                source_columns="falcondecline_indicator", model_type="categorical"),
            row(name="prev_predecline_ok", kind="engineered", recipe="prev(predecline_indicator)",
                source_columns="predecline_indicator", model_type="categorical", data_owner_fixed="yes")]
    _, r = check(rows)
    assert has(r, "falcondecline_indicator", "same_txn_decision", "STOP")
    assert has(r, "prev_falcon", "same_txn_prev", "WAIT") and r["prev_falcon"]["result"] == "WAIT"
    assert r["prev_predecline_ok"]["result"] != "STOP" and not has(r, "prev_predecline_ok", "same_txn_prev")


def test_sumegha_feasibility_external_hold_leftout():
    rows = [row(name="a_x", excluded_by_sumegha="yes", sumegha_reason="not feasible"),
            row(name="b_x", excluded_by_sumegha=""),
            row(name="c_x", feasible_in_production="no"),
            row(name="d_x", feasible_in_production="unknown"),
            row(name="vaa", model_type="continuous"),
            row(name="e_x", status_rule="hold"),
            row(name="f_x", kind="engineered", recipe="count(24h)", source_columns="", model_type="continuous",
                left_out_reason="reads all customers of a merchant")]
    df, r = check(rows)
    assert has(r, "a_x", "excluded_by_sumegha", "STOP")
    assert has(r, "b_x", "sumegha_blank", "FLAG")
    assert has(r, "c_x", "not_feasible", "WAIT")
    assert has(r, "d_x", "feasibility_unknown", "FLAG")
    assert has(r, "vaa", "external_score", "FLAG") and r["vaa"]["result"] == "FLAG"
    assert "external_score=yes" in df.loc[4, "notes"]
    assert has(r, "e_x", "hold", "WAIT")
    assert has(r, "f_x", "left_out_recipe", "STOP")


def test_outcome_sources_and_group_keys():
    rows = [row(name="lbl", kind="engineered", recipe="count(24h; where=frd_tag:1)", source_columns="frd_tag",
                model_type="continuous"),
            row(name="by_cust", kind="engineered", recipe="count(24h; same=nmap_customer_xid)",
                source_columns="nmap_customer_xid", model_type="continuous")]
    _, r = check(rows)
    assert has(r, "lbl", "uses_outcome", "STOP")
    assert has(r, "by_cust", "group_key_check", "FLAG")


def test_definition_needed_waits_not_left_out():
    _, r = check([row(name="dc_tran_claim_rate_x", kind="engineered", recipe="", source_columns="", model_type="",
                      next_definition_needed="read the original definition")])
    assert r["dc_tran_claim_rate_x"]["result"] == "WAIT"
    assert has(r, "dc_tran_claim_rate_x", "definition_needed", "WAIT")
    assert not has(r, "dc_tran_claim_rate_x", "left_out_recipe")


def test_generic_source_refused():
    rows = [row(name="pisinfo2__days", kind="engineered", recipe="days_before(cprsrvc__pisinfo2)",
                source_columns="cprsrvc__pisinfo2", model_type="continuous"),
            row(name="pisinfo_code", kind="engineered", recipe="code(cprsrvc__pisinfo)",
                source_columns="cprsrvc__pisinfo", model_type="categorical"),
            row(name="pin__days", kind="engineered", recipe="days_before(cprsrvc__pisinfo_pin_set_dt)",
                source_columns="cprsrvc__pisinfo_pin_set_dt", model_type="continuous")]
    _, r = check(rows)
    assert has(r, "pisinfo2__days", "generic_source", "STOP")
    assert has(r, "pisinfo_code", "generic_source", "STOP")
    assert not has(r, "pin__days", "generic_source")


def test_known_future_dates_and_date_meaning():
    rows = [row(name="exp__days", kind="engineered", recipe="days_until(card_expiration_dt)",
                source_columns="card_expiration_dt", model_type="continuous"),
            row(name="bad__days", kind="engineered", recipe="days_before(card_expiration_dt)",
                source_columns="card_expiration_dt", model_type="continuous", date_meaning="known_future_date")]
    df, r = check(rows)
    assert df.loc[0, "date_meaning"] == "known_future_date"
    assert r["exp__days"]["result"] != "STOP"
    assert has(r, "bad__days", "date_meaning", "STOP")


def test_code_is_a_proposed_alternative():
    df, r = check([row(name="le1_mcc", kind="engineered", recipe="code(merchant_category_xcd)",
                       source_columns="merchant_category_xcd", f15298_name="derived_le1__merchant_category_xcd")])
    assert df.loc[0, "mapping_status"] == "open" and df.loc[0, "equivalence"] == "unverified"
    assert has(r, "le1_mcc", "encoding_alternative", "FLAG")


def test_raw_date_and_missing_columns_with_suggestions():
    pod = {"cprsrvc__dbt_pinwfatmcurdttm": {"ranges_missing": "", "files_missing": "", "types": "timestamp[ns]"},
           "seen_dt": {"ranges_missing": "", "files_missing": "", "types": "timestamp[us]"},
           "half": {"ranges_missing": "rank_b", "files_missing": "", "types": "string"}}
    rows = [row(name="pin__days", kind="engineered", recipe="days_before(cprsrvc__dbt_pinwfatmcurrdttm)",
                source_columns="cprsrvc__dbt_pinwfatmcurrdttm", model_type="continuous"),
            row(name="seen_dt", model_type="continuous"),
            row(name="half")]
    _, r = check(rows, pod=pod)
    assert has(r, "pin__days", "missing_from_files", "STOP")
    assert any("cprsrvc__dbt_pinwfatmcurdttm" in s and "suggestion only" in s for s in r["pin__days"]["suggestions"])
    assert has(r, "seen_dt", "raw_date", "STOP")
    assert has(r, "half", "missing_from_files", "STOP")


def test_history_parity_flag():
    rows = [row(name="cnt90", kind="engineered", recipe="count(90d)", source_columns="", model_type="continuous"),
            row(name="cnt7", kind="engineered", recipe="count(7d)", source_columns="", model_type="continuous"),
            row(name="last60", kind="engineered", recipe="since_last(days; within=60d)", source_columns="",
                model_type="continuous") if False else
            row(name="last14", kind="engineered", recipe="since_last(days; within=14d)", source_columns="",
                model_type="continuous")]
    df, r = check(rows)
    assert has(r, "cnt90", "history_parity", "FLAG")
    assert not has(r, "cnt7", "history_parity")
    assert df.loc[2, "window"] == "14d"


def test_propagation_from_source_rows():
    rows = [row(name="cprcust__x_excl", excluded_by_sumegha="yes", model_type="continuous"),
            row(name="excl__ratio", kind="engineered", recipe="ratio(cprcust__x_excl; transaction_amt)",
                source_columns="cprcust__x_excl;transaction_amt", model_type="continuous")]
    _, r = check(rows)
    assert r["excl__ratio"]["result"] == "STOP"
    assert has(r, "excl__ratio", "source_stop")


def test_duplicate_definition_kept_once_by_group_precedence():
    rows = [row(name="mcc_15298", group="f15298", kind="engineered", recipe="code(merchant_category_xcd)",
                source_columns="merchant_category_xcd"),
            row(name="mcc_v22b", group="v22b", kind="engineered", recipe="code(merchant_category_xcd)",
                source_columns="merchant_category_xcd")]
    df, r = check(rows)
    assert has(r, "mcc_15298", "duplicate_definition", "STOP")
    assert df.loc[0, "kept_once_as"] == "mcc_v22b"
    assert r["mcc_v22b"]["result"] != "STOP"


def test_duplicate_names_and_bad_values():
    rows = [row(name="a_dup"), row(name="a_dup"), row(name="b_bad", group="tfm")]
    _, r = check(rows)
    assert has(r, "a_dup", "duplicate_name", "STOP")
    assert has(r, "b_bad", "bad_value", "STOP")


# ------------------------------------------------------------------ commands, in a synthetic project

def _parquet(path, cols):
    path.parent.mkdir(parents=True, exist_ok=True)
    vals = {pa.string(): ["a", "b"], pa.float64(): [1.0, 2.0]}
    pq.write_table(pa.table({c: pa.array(vals.get(t, [1, 2]), type=t) for c, t in cols.items()}), path)


def test_schema_footers_only_and_count(tmp_path):
    w = make_world(tmp_path, map_rows=default_map())
    s = C.load_yaml(w / NF_REL / "SETTINGS.yaml")
    s["populations"] = {"train": {"files": [1, 2]}, "rank_b": {"files": [8244, 8245]}}
    import yaml
    (w / NF_REL / "SETTINGS.yaml").write_text(yaml.safe_dump(s))
    tr, ev = tmp_path / "raw", tmp_path / "eval"
    _parquet(tr / "part_1.parquet", {"a": pa.int64(), "b": pa.float64()})
    _parquet(tr / "part_2.parquet", {"a": pa.float64(), "b": pa.float64()})
    _parquet(ev / "part_8244.parquet", {"a": pa.int64(), "b": pa.float64(), "c": pa.string()})
    _parquet(ev / "part_8245.parquet", {"a": pa.int64(), "b": pa.float64(), "c": pa.string()})
    r = run(w, tmp_path, "nf_intake.py", "schema", "--train-base", str(tr), "--eval-base", str(ev), "--cred-path", "")
    assert r.returncode == 0, r.stderr
    assert "pod raw columns: 3 distinct; 2 present in every file read" in r.stdout
    pc = pd.read_csv(w / "checkpoints/new_fields/intake/pod_columns.csv", dtype=str, keep_default_na=False)
    a = pc[pc.column == "a"].iloc[0]
    assert a.type_differs == "yes"
    c = pc[pc.column == "c"].iloc[0]
    assert c.ranges_missing == "train"


def test_check_map_screen_and_in_place(tmp_path):
    w = make_world(tmp_path, map_rows=default_map())
    r = run(w, tmp_path, "nf_intake.py", "check-map", "--in-place")
    assert r.returncode in (0, 3), r.stderr
    lines = r.stdout.splitlines()
    assert lines[0].startswith("CHECK-MAP") and len(lines) <= 40
    m = C.read_field_map(w / NF_REL / "FIELD_MAP.csv")
    assert m.loc[m.name == "f_cnt24", "window"].iloc[0] == "24h"
    assert m.loc[m.name == "f_cnt24", "as_of_rule"].iloc[0].startswith("strictly earlier rows")
    assert set(m.list_status) == {"CONFIRMED"}   # check-map never writes list_status


def test_adopt_only_way_to_confirmed_and_keeps_rows(tmp_path):
    rows = default_map()
    for r in rows:
        r["list_status"] = "UNCONFIRMED"
    w = make_world(tmp_path, map_rows=rows)
    owner = tmp_path / "owner_list.csv"
    owner.write_text("name\nf_code\nf_amt\n")
    r = run(w, tmp_path, "nf_intake.py", "adopt", "--list", str(owner), "--confirmed-by", "")
    assert r.returncode == 2
    r = run(w, tmp_path, "nf_intake.py", "adopt", "--list", str(owner), "--confirmed-by", "Owner, 2026-11-03")
    assert r.returncode == 0, r.stderr
    m = C.read_field_map(w / NF_REL / "FIELD_MAP.csv")
    st = dict(zip(m.name, m.list_status))
    assert st == {"f_code": "CONFIRMED", "f_amt": "CONFIRMED", "f_cnt24": "NOT_IN_OWNER_LIST"}
    assert "not in the owner's list" in m.loc[m.name == "f_cnt24", "notes"].iloc[0]
    assert C.sha256_file(owner) in m.list_source.iloc[0]
    bad = tmp_path / "bad.csv"
    bad.write_text("name\nf_code\nnot_in_map\n")
    r = run(w, tmp_path, "nf_intake.py", "adopt", "--list", str(bad), "--confirmed-by", "Owner")
    assert r.returncode == 4 and "not_in_map" in r.stderr


def test_builders_refuse_unconfirmed(tmp_path):
    rows = default_map()
    rows[0]["list_status"] = "UNCONFIRMED"
    w = make_world(tmp_path, map_rows=rows, field_status={"f_code": "PASS", "f_cnt24": "PASS", "f_amt": "PASS"})
    r = run(w, tmp_path, "nf_make_configs.py", "write", "--run", "nf_a1", "--steps", "A1")
    assert r.returncode == 4 and "UNCONFIRMED" in r.stderr
    r = run(w, tmp_path, "nf_intake.py", "definitions")
    assert r.returncode == 4


def test_definitions_columns(tmp_path):
    w = make_world(tmp_path, map_rows=default_map(), field_status={"f_code": "PASS", "f_cnt24": "FLAG",
                                                                   "f_amt": "STOP"})
    r = run(w, tmp_path, "nf_intake.py", "definitions")
    assert r.returncode == 0, r.stderr
    d = pd.read_csv(w / "checkpoints/new_fields/intake/FEATURE_DEFINITIONS.csv", dtype=str, keep_default_na=False)
    for col in ("name", "definition_version", "kind", "recipe", "source_columns", "window", "lag", "as_of_rule",
                "group_key", "time_key", "censoring_rule", "missing_rule", "model_type", "group",
                "feasible_in_production", "excluded_by_sumegha", "list_sha256"):
        assert col in d.columns, col
    assert list(d.name) == ["f_code", "f_cnt24"]
    assert d.loc[d.name == "f_cnt24", "censoring_rule"].iloc[0].startswith("a window reaching before")
    j = json.loads((w / "checkpoints/new_fields/intake/FEATURE_DEFINITIONS.json").read_text())
    assert j["embedding_width"] == 48 and len(j["features"]) == 2


def test_status_precedence_per_value():
    rules = I.status_rules(ROOT / NF_REL / "STATUS_RULES.csv")
    # an allow row clears only the value it matched
    st = I.status_of({"name": "x_ratio"}, rules, ["cardholder_present_xflg", "card_status_cd"])
    assert st is not None and st[0] == "status_like"
    # a rank52 source never hides a status source of the same recipe
    st = I.status_of({"name": "y_ratio"}, rules, ["cprcust__onlinebankpwstatuschgdt", "cpracct__ddaewstxndata_hold_seg"])
    assert st is not None and st[0] == "status_like"
    assert I.status_of({"name": "pw"}, rules, ["cprcust__onlinebankpwstatuschgdt"])[0] == "rank52"
    st = I.status_of({"name": "z"}, rules, ["cprcust__onlinebankpwstatuschgdt", "inactv_dt"])
    assert st[0] == "left_out_26oct"


def test_history_parity_counts_the_lag():
    _, r = check([row(name="cnt_lag", kind="engineered", recipe="count(24h; lag=30d)", source_columns="",
                      model_type="continuous")])
    assert has(r, "cnt_lag", "history_parity", "FLAG")
