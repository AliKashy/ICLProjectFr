"""Downstream check (component 18): the lift engine equals the base metrics, the account draws are shared, the
flag fires on a planted drop of more than one paired SE and not otherwise, and the whole check runs on a synthetic
export of a real (smoke-sized) fit through the unchanged exporter, export records and downstream tool."""
import json
import os
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import new_fields_gpu_world as W  # noqa: E402

pytest.importorskip("xgboost")
ID, ACCOUNT, LABEL = W.ID, W.ACCOUNT, W.LABEL


@pytest.fixture()
def env(tmp_path, monkeypatch):
    monkeypatch.setenv("CUDA_VISIBLE_DEVICES", "")
    old = {k: os.environ.get(k) for k in ("NF_OUT", "NF_SETTINGS_DIR")}
    yield tmp_path
    for k, v in old.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v


def D():
    import nf_downstream
    return nf_downstream


def planted(seed=0, n_acct=300, rows=8, emb_strength=1.0):
    rng = np.random.default_rng(seed)
    acct = np.repeat([f"a{i}" for i in range(n_acct)], rows)
    n = len(acct)
    ids = [f"r{i}" for i in range(n)]
    y = (rng.random(n) < 0.08).astype(int)
    raw = rng.normal(size=n) + 0.8 * y
    emb = raw + emb_strength * 2.0 * y + rng.normal(scale=0.5, size=n)
    return pd.DataFrame({ID: ids, ACCOUNT: acct, LABEL: y, "depth": 0, "raw": raw, "raw_embedding": emb})


def write_preds(c2, name, df, arm="base_raw"):
    p = Path(c2) / "downstream" / name / arm / "fit" / "predictions.parquet"
    p.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(p, index=False)
    return p


def settings_dir(tmp, draws=300):
    import yaml
    d = Path(tmp) / "settings"
    d.mkdir(parents=True, exist_ok=True)
    (d / "SETTINGS.yaml").write_text(yaml.safe_dump({
        "bootstrap": {"draws": draws, "seed": 20261102, "interval": 90},
        "populations": {"ds_train": {"files": [4001, 4010]}, "ds_select": {"files": [8217, 8227]}},
        "downstream": {"raw_predictors": "fraud/configs/predictors.csv", "use2_15298_offset": "off"}}))
    os.environ["NF_SETTINGS_DIR"] = str(d)
    os.environ["NF_OUT"] = str(Path(tmp) / "c2")
    return Path(tmp) / "c2"


def test_engine_equals_base_alert_and_sklearn():
    import nf_layout
    from sklearn.metrics import average_precision_score
    d = D()
    rng = np.random.default_rng(3)
    n = 997
    y = (rng.random(n) < 0.1).astype(int)
    s = np.round(rng.random(n) + 0.3 * y, 2)  # many tied scores, tied boundary rows
    frame = pd.DataFrame({ID: [f"i{k}" for k in range(n)], ACCOUNT: [f"a{k % 101}" for k in range(n)]})
    kr = d.key_ranks(frame)
    r = d.Ranked(y, s, kr)
    alert = nf_layout.attr("business_metrics", "_alert")
    ranking = nf_layout.attr("business_metrics", "_ranking")
    keys = [json.dumps([str(a), str(i)]) for a, i in zip(frame[ACCOUNT], frame[ID])]
    order, _ = ranking(s, keys)
    for w in (None, rng.integers(0, 4, n)):
        base = alert(y, None, None, order, 6, None if w is None else w.astype(np.int64))
        assert r.udr(w) == pytest.approx(base["detection_rate"], abs=0)
        assert r.ap(w) == pytest.approx(average_precision_score(y, s, sample_weight=w), rel=1e-12)
    assert r.udr() == pytest.approx(int(np.dot(np.minimum(1, np.maximum(0, n * 3 // 500 - np.arange(n))),
                                               y[np.lexsort((kr, -s))])) / y.sum())


def test_account_draws_are_shared_and_whole():
    d = D()
    accts = np.array(["b", "a", "c", "a", "b", "b"])
    one = [w.copy() for w in d.account_draws(accts, 20, 7)]
    two = [w.copy() for w in d.account_draws(accts[::-1].copy()[::-1], 20, 7)]
    assert all(np.array_equal(a, b) for a, b in zip(one, two))
    for w in one:
        assert w[1] == w[3] and w[0] == w[4] == w[5]
        assert w[1] + w[0] + w[2] == 3  # three accounts drawn with replacement


def test_lift_flag_fires_on_a_planted_drop_only(env, capsys):
    """The downstream tool's lift hands the run table to the reader, the one writer of reads/<step>_lift.json."""
    d = D()
    c2 = settings_dir(env)
    ctrl = planted(1, emb_strength=1.0)
    fit = ctrl.copy()
    fit["raw_embedding"] = planted(1, emb_strength=0.0)["raw_embedding"]  # the embedding lost its signal
    write_preds(c2, "ctl", ctrl)
    write_preds(c2, "cand", fit)
    assert d.main(["lift", "--step", "A1", "--fit", "cand", "--control", "ctl", "--decision", "ADOPT"]) == 0
    rec = json.loads((c2 / "reads" / "A1_lift.json").read_text())
    assert rec["kind"] == "lift"                                    # the reader's record
    u = rec["lift"]["udr"]
    assert u["lift_control"] > 0 and u["difference"] < -u["sd"] and rec["flag"] is True
    out = capsys.readouterr().out
    assert "FLAG: the embedding's downstream lift fell by more than one paired SE" in out
    lines = (c2 / "reads" / "A1_lift.txt").read_text().rstrip("\n").splitlines()
    assert len(lines) <= 40 and max(map(len, lines)) <= 90
    # by hand: UDR at 0.6% of each arm, with the downstream tool's own engine (the engines agree)
    for col, key in (("raw", "control_raw"), ("raw_embedding", "control_embedding")):
        kr = d.key_ranks(ctrl)
        order = np.lexsort((kr, -ctrl[col].to_numpy()))
        top = order[: len(ctrl) * 3 // 500]
        assert u[key] == pytest.approx(ctrl[LABEL].to_numpy()[top].sum() / ctrl[LABEL].sum())
    assert "A1_lift DS_SELECT" in (c2 / "READS.log").read_text()
    # The same drop with a group that kept the control: no flag.
    assert d.main(["lift", "--step", "A2", "--fit", "cand", "--control", "ctl", "--decision", "KEEP THE CONTROL"]) == 0
    assert json.loads((c2 / "reads" / "A2_lift.json").read_text())["flag"] is False
    # No drop: no flag even when the group passes.
    write_preds(c2, "same", ctrl)
    assert d.main(["lift", "--step", "A3", "--fit", "same", "--control", "ctl", "--decision", "ADOPT"]) == 0
    rec = json.loads((c2 / "reads" / "A3_lift.json").read_text())
    assert rec["flag"] is False and rec["lift"]["udr"]["difference"] == 0


def test_lift_reads_the_decision_and_refuses_changes(env):
    d = D()
    c2 = settings_dir(env, draws=50)
    ctrl = planted(2)
    write_preds(c2, "ctl", ctrl)
    write_preds(c2, "cand", ctrl)
    (c2 / "reads").mkdir(parents=True, exist_ok=True)
    (c2 / "reads" / "A1_1seed.json").write_text(json.dumps({"decision": "ADOPT (pending the SELECT check)",
                                                           "rule_decision": "ADOPT", "pending_select_check": True}))
    assert d.main(["lift", "--step", "A1", "--fit", "cand", "--control", "ctl"]) == 0
    rec = json.loads((c2 / "reads" / "A1_lift.json").read_text())
    assert rec["fraud_rule"] == "pending" and rec["fraud_rule_source"].endswith("pending the SELECT check")
    assert rec["flag"] is False
    assert d.main(["lift", "--step", "A1", "--fit", "cand", "--control", "ctl"]) == 0  # saved, inputs equal
    changed = ctrl.copy()
    changed["raw"] = changed["raw"] + 1e-3
    write_preds(c2, "cand", changed)
    assert d.main(["lift", "--step", "A1", "--fit", "cand", "--control", "ctl"]) == 3  # inputs changed: STOP
    write_preds(c2, "short", ctrl.iloc[:-5])
    assert d.main(["lift", "--step", "B9", "--fit", "short", "--control", "ctl"]) == 3  # different rows: STOP
    assert d.main(["lift", "--step", "B8", "--fit", "missing", "--control", "ctl"]) == 4


def test_downstream_summary_records_the_ds_select_sha256_and_a_change_stops_the_lift(env):
    """Review item 18: the downstream job records the DS_SELECT predictions' sha256; the lift read checks it."""
    d = D()
    c2 = settings_dir(env, draws=50)
    ctrl = planted(3)
    import hashlib
    for name in ("cand", "ctl"):
        p = write_preds(c2, name, ctrl)
        (p.parents[2] / "summary.json").write_text(json.dumps(
            {"name": name, "predictions_sha256": {"base_raw": hashlib.sha256(p.read_bytes()).hexdigest()}}))
    assert d.main(["lift", "--step", "A1", "--fit", "cand", "--control", "ctl", "--decision", "ADOPT"]) == 0
    table = json.loads((c2 / "reads" / "A1_lift.runs.json").read_text())
    assert all(len(r["downstream_sha256"]) == 64 for r in table["runs"])
    (c2 / "reads" / "A1_lift.json").unlink()
    changed = ctrl.copy()
    changed["raw_embedding"] = changed["raw_embedding"] + 1e-3      # rewritten after the job recorded it
    write_preds(c2, "cand", changed)
    assert d.main(["lift", "--step", "A1", "--fit", "cand", "--control", "ctl", "--decision", "ADOPT"]) == 3


def test_use2_waits_while_off(env, capsys):
    d = D()
    settings_dir(env)
    assert d.main(["use2", "--name", "x", "--scores", "nothing.parquet"]) == 0
    assert "use 2 waits" in capsys.readouterr().out


@pytest.mark.skipif(W.base_config_path() is None, reason="no chosen-model base config in this tree")
def test_downstream_check_end_to_end_on_a_synthetic_export(env, capsys):
    """A one-epoch smoke fit, then: the unchanged exporter by path on DS_TRAIN and DS_SELECT, the export checks,
    the encoder contract and downstream config from the export records, the unchanged downstream tool for the
    base raw arm and the step's own raw arm, the lift read, and use 2 with planted 15298 scores."""
    import nf_layout
    import nf_time_width
    d = D()
    w = W.build(env / "world")
    before = W.hashed_files()
    run_dir = w["tmp"] / "runs" / "nf_a1" / "seed42"
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        nf_time_width.run_wrapped(w["step_config"], run_dir, updates=3, val_batches=2,
                                  overrides=["training.max_epochs=1"])
    assert json.loads((run_dir / "run_manifest_v2.json").read_text())["status"] == "budget_reached"
    args = ["run", "--name", "nf_a1_seed42", "--run-dir", str(run_dir), "--no-busy-check"]
    assert d.main(args) == 0, capsys.readouterr().out
    c2 = w["c2"]
    down = c2 / "downstream" / "nf_a1_seed42"
    for pop in ("ds_train", "ds_select"):
        chk = json.loads((down / f"check_{pop}.json").read_text())
        assert chk["ok"] and chk["width"] == 48
    n_train = len(w["frames"][4001]) + len(w["frames"][4002])
    assert json.loads((down / "check_ds_train.json").read_text())["rows"] == n_train
    manifest = json.loads((run_dir / "run_manifest_v2.json").read_text())
    assert manifest.get("exported"), "the exporter records the export in the run's manifest"
    for arm in ("base_raw", "own_raw"):
        rep = json.loads((down / arm / "fit" / "report.json").read_text())
        assert rep["fit_population"] == "DS_TRAIN only" and rep["embedding_width"] == 48
        june = sum(int((f[W.TIME] >= "2025-06-01").sum()) for k, f in w["frames"].items() if k in (8217, 8218))
        assert rep["rows"] == june
    cfg_own = json.loads((down / "own_raw" / "config.json").read_text())
    assert cfg_own["predictors"].endswith("predictors_step.csv")
    reads = (c2 / "downstream" / "DS_SELECT_READS.log").read_text()
    assert reads.count(" start nf_a1_seed42 ") == 2
    assert json.loads((down / "result.json").read_text())["status"] == "done"
    # A second run, in the planner's form, skips every part and reads DS_SELECT no more.
    assert d.main(["--config", str(w["step_config"]), "--checkpoint", str(run_dir / "best.ckpt"),
                   "--out", str(down), "--no-busy-check"]) == 0
    assert d.main(["--config", "x", "--checkpoint", "y", "--out", str(w["tmp"] / "elsewhere")]) == 2
    assert (c2 / "downstream" / "DS_SELECT_READS.log").read_text().count(" start ") == 2
    # The summary records the DS_SELECT predictions' sha256 for every arm (review item 18).
    summ = json.loads((down / "summary.json").read_text())
    import hashlib
    for arm in ("base_raw", "own_raw"):
        assert summ["predictions_sha256"][arm] == hashlib.sha256(
            (down / arm / "fit" / "predictions.parquet").read_bytes()).hexdigest()
    # Lift of the fit against itself, read by the reader: no difference, no flag.
    assert d.main(["lift", "--step", "A1", "--fit", "nf_a1_seed42", "--control", "nf_a1_seed42",
                   "--decision", "ADOPT"]) == 0
    rec = json.loads((c2 / "reads" / "A1_lift.json").read_text())
    assert rec["kind"] == "lift" and rec["flag"] is False and rec["lift"]["udr"]["difference"] == 0
    # An export of the same checkpoint over other files is refused, not reused.
    import shutil
    shutil.copytree(c2 / "exports" / "nf_a1_seed42", c2 / "exports" / "copy")
    assert d.main(["run", "--name", "copy", "--run-dir", str(run_dir), "--no-busy-check",
                   "--train-base", str(w["data"]) + "/"]) == 4
    # Partial outputs are refused.
    (c2 / "exports" / "other" / "ds_train").mkdir(parents=True)
    assert d.main(["run", "--name", "other", "--run-dir", str(run_dir), "--no-busy-check"]) == 4
    # Use 2: planted 15298 scores for every DS_TRAIN and DS_SELECT row.
    rng = np.random.default_rng(5)
    rows = pd.concat([w["frames"][k] for k in (4001, 4002, 8217, 8218)], ignore_index=True)
    sc = rows[[ID, ACCOUNT]].copy()
    sc["score"] = 1 / (1 + np.exp(-(rows["f1"].to_numpy() - 1.5 + rng.normal(scale=0.3, size=len(rows)))))
    sp = w["tmp"] / "s15298.parquet"
    sc.to_parquet(sp, index=False)
    assert d.main(["use2", "--name", "nf_a1_seed42", "--scores", str(sp)]) == 0  # off: waits
    assert not (down / "use2").exists()
    assert d.main(["use2", "--name", "nf_a1_seed42", "--scores", str(sp), "--force"]) == 0
    p = pd.read_parquet(down / "use2" / "predictions.parquet")
    assert {"offset_raw", "offset_raw_embedding", "s15298"} <= set(p.columns) and len(p) == rep["rows"]
    assert d.main(["lift", "--step", "A1", "--fit", "nf_a1_seed42", "--control", "nf_a1_seed42", "--use", "2",
                   "--decision", "ADOPT"]) == 0
    rec2 = json.loads((c2 / "reads" / "A1_lift_use2.json").read_text())
    assert rec2["kind"] == "lift" and rec2["inputs"]["arms"] == ["offset_raw", "offset_raw_embedding"]
    assert W.hashed_files() == before
    assert nf_layout.get("trainer").build_trainer.__name__ == "build_trainer"


def test_ids_match_after_canonicalisation(env):
    d = D()
    settings_dir(env)
    a = pd.DataFrame({ID: [1.0, 2.0], ACCOUNT: [12345678.0, 12345679.0]})
    b = pd.DataFrame({ID: [1, 2], ACCOUNT: [12345678, 12345679]})
    assert d._canon(a)[[ID, ACCOUNT]].equals(d._canon(b)[[ID, ACCOUNT]])
