"""A small synthetic world for the reader's tests: raw files, prediction files, receipts, checkpoints, settings.

No bank data and no network. Everything is written under a pytest temporary folder.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parents[4]
NF = ROOT / "fraud" / "experiments" / "features" / "new_fields"
ID, ACCT, TIME, LABEL, AMOUNT = "fi_transaction_id", "Nmap_account_reference_xid", "transaction_dttm", "frd_tag", \
    "transaction_amt"
POPS = {"rank_b": [10, 13], "select": [20, 23], "rank_a": [40, 41], "test1": [30, 31]}


def load(name):
    """Import a reader module by path (no package under fraud/experiments)."""
    for p in (str(NF), str(ROOT / "src"), str(ROOT)):
        if p not in sys.path:
            sys.path.insert(0, p)
    if name in sys.modules:
        return sys.modules[name]
    spec = importlib.util.spec_from_file_location(name, NF / f"{name}.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def make_raw(base, start, end, accounts=300, per_account=12, fraud_share=0.04, seed=0, id_offset=0):
    """Raw parquet files part_<n>.parquet; every account sits in one file; May and June rows."""
    rng = np.random.default_rng(seed)
    base = Path(base)
    base.mkdir(parents=True, exist_ok=True)
    frames = []
    files = list(range(start, end + 1))
    tid = id_offset
    for a in range(accounts):
        n = per_account
        times = pd.Timestamp("2025-05-10") + pd.to_timedelta(np.sort(rng.integers(0, 45 * 86400, n)), unit="s")
        fraud_account = rng.random() < fraud_share * 4
        labels = (rng.random(n) < (0.35 if fraud_account else 0.0)).astype(np.int64)
        frames.append(pd.DataFrame({
            ID: np.arange(tid, tid + n, dtype=np.int64), ACCT: f"acct{a:05d}", TIME: times, LABEL: labels,
            AMOUNT: np.round(rng.gamma(2.0, 40.0, n), 2), "_file": files[a % len(files)]}))
        tid += n
    raw = pd.concat(frames, ignore_index=True)
    for f in files:
        part = raw[raw["_file"] == f].drop(columns="_file").sort_values([ACCT, TIME]).reset_index(drop=True)
        part.to_parquet(base / f"part_{f}.parquet", index=False)
    return raw.drop(columns="_file").reset_index(drop=True)


def june(raw):
    t = pd.to_datetime(raw[TIME])
    return raw[(t >= pd.Timestamp("2025-06-01")) & (t < pd.Timestamp("2025-07-01"))].reset_index(drop=True)


def scores(raw, signal, seed, decimals=None):
    rng = np.random.default_rng(seed)
    s = 1.0 / (1.0 + np.exp(-(signal * raw[LABEL].to_numpy() + rng.normal(0, 1, len(raw)) - 2.0)))
    s = s.astype(np.float32)
    if decimals is not None:
        s = np.round(s, decimals).astype(np.float32)
    return s


def bump(raw, base_scores, k, seed=0):
    """The same scores, with k June frauds that sit outside the 0.6% outsort moved to the very top."""
    s = np.asarray(base_scores, dtype=np.float32).copy()
    jm = june_mask(raw)
    idx = np.flatnonzero(jm)
    n = len(idx) * 3 // 500
    order = idx[np.lexsort((np.arange(len(idx)), -s[idx]))]
    outside = [i for i in order[n:] if raw[LABEL].iloc[i] == 1]
    rng = np.random.default_rng(seed)
    for j, i in enumerate(rng.permutation(outside)[:k]):
        s[i] = np.float32(1.0 - 1e-4 * j)
    return s


def june_mask(raw):
    t = pd.to_datetime(raw[TIME])
    return ((t >= pd.Timestamp("2025-06-01")) & (t < pd.Timestamp("2025-07-01"))).to_numpy()


def write_fit(folder, name, seed, raw, score, files, base, population="OTHER", shuffle=None, amount=True,
              scoring="target-ending", cap=32):
    """A prediction file, a checkpoint, the receipt and the exposure record, as the scorer writes them."""
    folder = Path(folder) / f"{name}_seed{seed}"
    folder.mkdir(parents=True, exist_ok=True)
    ckpt = folder / "best.ckpt"
    ckpt.write_bytes(f"checkpoint {name} {seed}".encode())
    pred = pd.DataFrame({ID: raw[ID].to_numpy(), ACCT: raw[ACCT].to_numpy(), LABEL: raw[LABEL].to_numpy(),
                         "score": np.asarray(score, dtype=np.float32)})
    if amount:
        pred[AMOUNT] = raw[AMOUNT].to_numpy()
    pred["window_rows"] = 5
    if shuffle is not None:
        pred = pred.sample(frac=1.0, random_state=shuffle).reset_index(drop=True)
    out = folder / "scores.parquet"
    pred.to_parquet(out, index=False)
    receipt = {"predictions": "x", "predictions_sha256": sha(out), "checkpoint": "y", "checkpoint_sha256": sha(ckpt),
               "validation_policy": {"name": "target_ending_v1", "max_window_rows": cap,
                                     "validation_precision": "bf16-mixed"},
               "scoring": scoring, "max_window_rows": cap,
               "files": {"base": str(base), "start": int(files[0]), "end": int(files[1])},
               "n_predictions": int(len(pred)), "n_positives": int(pred[LABEL].sum())}
    Path(f"{out}.json").write_text(json.dumps(receipt))
    Path(f"{out}.exposure.json").write_text(json.dumps({"population": population, "purpose": "test"}))
    (folder / "config.yaml").write_text("training:\n  num_workers: 4\n")
    return {"role": "", "seed": seed, "run": name, "predictions": str(out), "receipt": "", "checkpoint": "",
            "run_dir": str(folder), "label": ""}


def run_table(path, rows):
    pd.DataFrame(rows).to_csv(path, index=False)
    return str(path)


def settings(folder, **overrides):
    """SETTINGS.yaml (the spine's file when present, with test populations and approvals) and STEPS.yaml."""
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    src = NF / "SETTINGS.yaml"
    cfg = yaml.safe_load(src.read_text()) if src.is_file() else {}
    for k in ("t1_ap", "z_one_sided", "t_one_sided_2df", "sd_run_udr_floor"):   # removed by the decisions D1, D2
        cfg.pop(k, None)
    cfg.update({"main_measure": "udr_at_0.6pct", "udr_unit": "transaction", "bar_udr": 0.01,
                "t1_multiplier": "welch_satterthwaite", "null_correction": False, "three_seed_bound": "paired",
                "conflict_line": {"k_se": 2.5, "metrics": ["ap", "vdr"]}, "learning_rate": 3.0e-4,
                "bootstrap": {"draws": 200, "seed": 20261102, "unit": ACCT, "interval": 90},
                "select_check": {"k_se": 2.5, "k_se_when_select_decides": 3.5, "seed_term": True,
                                 "null_correction": False, "spread_from": ["select_june", "rank_b"],
                                 "metrics": ["ap", "auroc", "ks", "udr_at_0.6pct"]},
                "decide_on": "rank_b",
                "populations": {"rank_b": {"files": POPS["rank_b"], "targets": ["2025-06-01", "2025-07-01"]},
                                "select": {"files": POPS["select"], "targets": ["2025-06-01", "2025-07-01"]},
                                "rank_a": {"files": POPS["rank_a"], "targets": ["2025-06-01", "2025-07-01"]},
                                "test1": {"files": POPS["test1"]}},
                "approvals": {k: {"approved_by": "owner", "approved_on": "2026-11-02"}
                              for k in ("main_measure", "bar", "check_thresholds", "cluster_threshold")}})
    cfg.update(overrides)
    (folder / "SETTINGS.yaml").write_text(yaml.safe_dump(cfg, sort_keys=False))
    (folder / "STEPS.yaml").write_text(yaml.safe_dump({"steps": [
        {"name": "A1", "on": True, "adds": ["v22b", "both"]}, {"name": "A2", "on": True, "adds": ["f15298"]},
        {"name": "P", "on": False, "kind": "prune"}, {"name": "B", "on": False, "kind": "month_out"}]}))
    return cfg


def rank_check(c2, result="PASS"):
    p = Path(c2) / "reads" / "rank_check.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({"result": result}))


SPREAD_METRICS = ("udr", "ap", "vdr", "fpr", "auroc", "ks")


def write_spread(c2, pop, sd_run, sd_null=0.0, df=2, metrics=None, select=True):
    """A spread file as the spread step writes it: per measure sd_run, df and the pair term sd_null (the same values
    for every measure unless ``metrics`` gives others). A RANK-B file also gets the SELECT June file a RANK-B read needs
    (the reviewers' decision D2): the same spread when ``select`` is True, that spread when it is a number."""
    def one(name, sd):
        m = {k: {"sd_run": sd, "df": df, "sd_null": sd_null, "values": [0, 0, 0]} for k in SPREAD_METRICS}
        for k, v in (metrics or {}).items():
            m[k] = dict(m.get(k, {}), **v)
        p = Path(c2) / "reads" / f"spread_{name}.json"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps({"kind": "spread", "population": name, "seeds": [42, 43, 44], "metrics": m}))
    one(pop, sd_run)
    if pop == "rank_b" and select is not False:
        one("select_june", sd_run if select is True else select)


class World:
    """One test's folders and the commands it runs."""

    def __init__(self, tmp, monkeypatch, accounts=1000, per_account=12, seed=0, **settings_overrides):
        self.tmp = Path(tmp)
        self.c2 = self.tmp / "c2"
        self.set_dir = self.tmp / "settings"
        monkeypatch.setenv("NF_OUT", str(self.c2))
        monkeypatch.setenv("NF_SETTINGS_DIR", str(self.set_dir))
        self.cfg = settings(self.set_dir, **settings_overrides)
        self.raw = {}
        for i, (pop, files) in enumerate(POPS.items()):
            base = self.tmp / "raw" / pop
            self.raw[pop] = (make_raw(base, files[0], files[1], accounts, per_account, seed=seed + i,
                                      id_offset=1_000_000 * i), base)
        self.read = load("nf_read")
        self.ranked = load("nf_ranked")
        rank_check(self.c2)

    def fit(self, pop, name, seed, score, **kw):
        raw, base = self.raw[pop]
        population = {"rank_b": "OTHER", "select": "SELECT", "test1": "DEV_OOT", "rank_a": "OTHER"}[pop]
        return write_fit(self.tmp / "fits" / pop, name, seed, raw, score, POPS[pop], base, population, **kw)

    def table(self, name, cands, ctrls):
        rows = [dict(r, role="candidate") for r in cands] + [dict(r, role="control") for r in ctrls]
        return run_table(self.tmp / f"{name}.csv", rows)

    def run(self, *argv):
        return self.read.main([str(a) for a in argv])

    def saved(self, name):
        return json.loads((self.c2 / "reads" / name).read_text())

    def text(self, name):
        return (self.c2 / "reads" / name).read_text()
