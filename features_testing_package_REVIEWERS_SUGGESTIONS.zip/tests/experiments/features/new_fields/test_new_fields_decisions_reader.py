"""The reviewers' joint decisions of 2 November in the reader: the measure and its unit (D1), the conflict line
(D1), T_1, the paired three-seed bound, no null subtraction, no fixed floor, a zero spread routed to the seed path and
the SELECT check (D2, corrected 3 November), the spread pooled
within two trios (D5b), the refit control's information lines (D5a), the A2 membership (D3a), the pruning and
month-out texts (D4b, D4c), the external score line until it is certified (D3c). Synthetic data only."""
from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import yaml

from new_fields_reader_world import World, load, scores, write_spread, run_table, june_mask, write_fit, POPS

R = load("nf_ranked")
RD = load("nf_read")
STOP, REFUSED = 3, 4


@pytest.fixture
def world(tmp_path, monkeypatch):
    return World(tmp_path, monkeypatch, accounts=600)


def _settings(w, **changes):
    cfg = yaml.safe_load((w.set_dir / "SETTINGS.yaml").read_text())
    cfg.update(changes)
    (w.set_dir / "SETTINGS.yaml").write_text(yaml.safe_dump(cfg, sort_keys=False))


def _pair(w, cand_signal=3.0, ctrl_signal=1.0, pop="rank_b", sd_run=0.002, **kw):
    raw = w.raw[pop][0]
    write_spread(w.c2, "rank_b" if pop == "rank_b" else "select_june", sd_run, **kw)
    cand = w.fit(pop, "cand", 42, scores(raw, cand_signal, 1))
    ctrl = w.fit(pop, "ctrl", 42, scores(raw, ctrl_signal, 2))
    return cand, ctrl


# ------------------------------------------------------------------ D2: T_1, the paired bound, the SELECT check
# The D2 correction of 3 November: no null subtraction anywhere, the paired three-seed bound, and a zero UDR spread
# routed to the seed path instead of a STOP.


def test_t1_uses_the_welch_satterthwaite_t_without_a_null_subtraction():
    assert RD.t1(0.014, 0.015) == pytest.approx(0.053728, abs=5e-7)
    terms = RD.t1_terms(0.014, 0.015)
    assert terms["nu"] == pytest.approx(4.1216, abs=5e-5)
    assert terms["a"] == pytest.approx(0.014 ** 2, rel=1e-15) and terms["b"] == pytest.approx(2 * 0.015 ** 2)
    assert "sd_null" not in terms and "equal candidate and control seed variance" in terms["assumes"]
    assert RD.t1(0.014, 0.022) == pytest.approx(0.081529, abs=5e-7)
    assert RD.t1_terms(0.014, 0.022)["nu"] == pytest.approx(2.8919, abs=5e-5)
    assert RD.t1(0.014, 0.015, df_run=6) == pytest.approx(0.045188, abs=5e-7)
    # at 4 degrees of freedom (the spread pooled over two trios, D5b)
    for args, want, nu in (((0.014, 0.015), 0.047083, 8.2433), ((0.014, 0.022), 0.066743, 5.7838)):
        assert RD.t1(*args, df_run=4) == pytest.approx(want, abs=5e-7), args
        assert RD.t1_terms(*args, df_run=4)["nu"] == pytest.approx(nu, abs=5e-5), args
    # a spread that is not finite, or below zero, stays a STOP
    for bad in (float("nan"), float("inf"), -0.01, None):
        with pytest.raises(RD.ReadError) as e:
            RD.t1(0.014, bad)
        assert e.value.code == STOP
    # T1(AP), information: sd_pair(AP) 0.008, the chosen model's AP spread 0.006077
    assert RD.t1(0.008, 0.006077) == pytest.approx(0.022260, abs=1e-5)
    assert RD.t1(0.008, 0.006077, df_run=4) == pytest.approx(0.020687, abs=1e-5)


def test_a_zero_spread_leaves_t1_undefined_without_a_stop():
    terms = RD.t1_terms(0.014, 0.0)
    assert terms["undefined"] == RD.ZERO_SPREAD and not math.isfinite(terms["t1"])
    assert terms["a"] == pytest.approx(0.014 ** 2) and terms["b"] == 0.0
    # an undefined bootstrap SD is still non-finite, not a zero spread: the read stops on it
    assert RD.t1_terms(float("nan"), 0.0)["undefined"] is None
    with pytest.raises(RD.ReadError) as e:
        RD.decide("add", 1, 0.03, float("nan"), 0.01, 0.5)
    assert e.value.code == STOP


@pytest.mark.parametrize("kind", ["add", "month_out", "calendar"])
def test_a_zero_spread_routes_a_one_seed_gain_to_the_seed_path(kind):
    why = RD.ZERO_SPREAD
    dec, reason, changes = RD.decide(kind, 1, 0.20, float("nan"), 0.01, 0.15, t1_undefined=why)
    assert dec == "RUN SEEDS 43 AND 44" and not changes and "T1 is undefined" in reason
    keep = {"add": "KEEP THE CONTROL", "month_out": "KEEP MONTH", "calendar": "KEEP THE CALENDAR"}[kind]
    assert RD.decide(kind, 1, -0.01, float("nan"), 0.01, -0.02, t1_undefined=why)[0] == keep
    assert RD.decide(kind, 1, 0.0, float("nan"), 0.01, -0.02, t1_undefined=why)[0] == keep
    # three seeds need no T1: the paired bound decides
    if kind == "add":
        assert RD.decide(kind, 3, 0.02, float("nan"), 0.01, None, lb3=0.001, t1_undefined=why)[0] == "ADOPT"


def test_the_paired_three_seed_bound_on_fixed_differences():
    d = [0.03, 0.04, 0.05]                                  # s_d = 0.01 exactly; k = 3, so t at 2 df
    lb, s_d, t, df = RD.lb_three(0.04, d, 0.000196)
    assert s_d == pytest.approx(0.01, rel=1e-12) and df == 2
    assert t == pytest.approx(2.919986, abs=1e-6)
    assert lb == pytest.approx(0.04 - 2.919986 * math.sqrt(0.000196 + 0.01 ** 2 / 3), abs=1e-6)
    assert lb == pytest.approx(-0.004220, abs=5e-7)
    assert RD.lb_three(0.04, d, 0.0)[0] == pytest.approx(0.023141, abs=5e-7)
    # two seeds: t at 1 df
    assert RD.lb_three(0.04, [0.03, 0.05], 0.0)[2] == pytest.approx(6.313752, abs=1e-6)
    with pytest.raises(ValueError):
        RD.lb_three(0.04, [0.04], 0.0)


def _old_pooled_bound(gain, diffs, sd_run, v_acct, df_p):
    """The pooled bound the D2 correction removed (nf_read.py at 8a440a2), kept here only as the reference."""
    k = len(diffs)
    var_seed = ((k - 1) * np.var(diffs, ddof=1) + df_p * 2 * sd_run ** 2) / ((k - 1) + df_p)
    return gain - RD.t_one_sided((k - 1) + df_p) * math.sqrt(v_acct + var_seed / k)


def test_a_more_variable_candidate_no_longer_gets_a_positive_bound():
    # the other reviewer's unequal-variance case (probes.py): control SD 0.015, the candidate's SD four times it,
    # the baseline spread with 4 df. A fixed draw: gain +0.05, s_d 0.0624 against 2 x 0.015^2 from the baseline.
    d, sd_run = [0.10, -0.02, 0.07], 0.015
    old = _old_pooled_bound(0.05, d, sd_run, 0.0, 4)
    new = RD.lb_three(0.05, d, 0.0)[0]
    assert old == pytest.approx(0.005124, abs=5e-7) and old > 0
    assert new == pytest.approx(-0.055282, abs=5e-7) and new <= 0
    assert RD.decide("add", 3, 0.05, None, 0.01, None, lb3=old)[0] == "ADOPT"
    assert RD.decide("add", 3, 0.05, None, 0.01, None, lb3=new)[0] == "KEEP THE CONTROL"
    # the probe's sensitivity, smaller: under no effect the paired bound keeps near 5% false adoptions at SD ratio 4,
    # the pooled one does not (the other reviewer: 14.59% at 200 000 draws)
    rng = np.random.default_rng(20261103)
    draws, n, control_sd, df_prior = 40_000, 3, 0.015, 4
    pair_sd = math.sqrt(control_sd ** 2 + (4 * control_sd) ** 2)
    diffs = rng.normal(0, pair_sd, size=(draws, n))
    prior = control_sd ** 2 * rng.chisquare(df_prior, draws) / df_prior
    gain, sv = diffs.mean(axis=1), diffs.var(axis=1, ddof=1)
    pooled = gain - RD.t_one_sided(n - 1 + df_prior) * np.sqrt(((n - 1) * sv + df_prior * 2 * prior) / (n - 1 + df_prior) / n)
    paired = gain - RD.t_one_sided(n - 1) * np.sqrt(sv / n)
    for i in (0, 1, 2, 100, draws - 1):           # the vectorized form is the function's
        assert RD.lb_three(gain[i], diffs[i], 0.0)[0] == pytest.approx(paired[i], rel=1e-12, abs=1e-14)
    assert np.mean(pooled > 0) > 0.12
    assert abs(np.mean(paired > 0) - 0.05) < 0.006


def test_the_select_check_limit_has_the_seed_term_and_no_null_subtraction():
    def check(m, diff, sd, spread, both=True):
        sp = {"select_june": {"metrics": {m: {"sd_run": spread, "df": 2, "sd_null": 0.017}}}}
        if both:
            sp["rank_b"] = {"metrics": {m: {"sd_run": spread / 2, "df": 4, "sd_null": 0.017}}}
        return RD.select_check({m: {"gain": diff, "sd": sd}}, 2.5, sp, 1, names=(m,))
    r = check("auroc", -0.006, 0.003, 0.004808)
    assert r["pass"] and r["rows"][0]["limit"] == pytest.approx(-0.018580, abs=5e-7)
    r = check("udr", -0.07, 0.017, 0.015)
    assert not r["pass"] and r["rows"][0]["limit"] == pytest.approx(-0.067961, abs=5e-7)
    # the old form subtracted sd_null^2/n (limit -0.053033 here); now the spread file's sd_null changes nothing
    r = check("udr", -0.06, 0.017, 0.015)
    assert r["pass"] and r["rows"][0]["limit"] == pytest.approx(-0.067961, abs=5e-7)
    assert "sd_null" not in r["rows"][0] and "not established" in r["k_note"]
    # three seeds: SE_acct^2 + 2 s_m^2 / 3
    sp = {"select_june": {"metrics": {"udr": {"sd_run": 0.015, "df": 2}}}}
    r = RD.select_check({"udr": {"gain": -0.05, "sd": 0.01}}, 2.5, sp, 3, names=("udr",))
    assert r["rows"][0]["limit"] == pytest.approx(-2.5 * math.sqrt(0.01 ** 2 + 2 * 0.015 ** 2 / 3), rel=1e-12)
    # the larger spread governs: RANK-B's when it is the larger (both files when RANK-B decides)
    sp = {"select_june": {"metrics": {"udr": {"sd_run": 0.010, "df": 2}}},
          "rank_b": {"metrics": {"udr": {"sd_run": 0.022, "df": 4}}}}
    r = RD.select_check({"udr": {"gain": 0.0, "sd": 0.0}}, 2.5, sp, 1, names=("udr",))
    assert r["rows"][0]["s_m"] == 0.022 and r["rows"][0]["s_m_source"] == "rank_b"
    r = check("udr", -0.0, 0.017, 0.015, both=False)        # SELECT decides: SELECT June's spread alone
    assert r["rows"][0]["s_m_source"] == "select_june"
    # a zero spread is a value, not a failure: the limit is the bootstrap's alone
    sp = {"select_june": {"metrics": {"udr": {"sd_run": 0.0, "df": 2}}}}
    r = RD.select_check({"udr": {"gain": -0.02, "sd": 0.01}}, 2.5, sp, 1, names=("udr",))
    assert r["rows"][0]["limit"] == pytest.approx(-0.025) and r["pass"]


def test_null_correction_false_changes_t1_and_the_select_check(world, monkeypatch):
    # the default (no null_correction key) and the shipped SETTINGS.yaml: no subtraction, sd_null information only
    shipped = yaml.safe_load((Path(RD.__file__).with_name("SETTINGS.yaml")).read_text())
    assert shipped["null_correction"] is False and shipped["select_check"]["null_correction"] is False
    assert shipped["three_seed_bound"] == "paired"
    cfg = yaml.safe_load((world.set_dir / "SETTINGS.yaml").read_text())
    cfg.pop("null_correction")
    cfg["select_check"].pop("null_correction")
    (world.set_dir / "SETTINGS.yaml").write_text(yaml.safe_dump(cfg, sort_keys=False))
    cand, ctrl = _pair(world, sd_run=0.002, sd_null=0.5)
    assert world.run("read", "--step", "A1", "--runs", world.table("t", [cand], [ctrl])) == 0
    rec = world.saved("A1_1seed.json")
    sd_pair = rec["metrics"]["udr"]["sd"]
    assert rec["t1_terms"]["a"] == pytest.approx(sd_pair ** 2, rel=1e-12) and sd_pair > 0
    b = 2 * 0.002 ** 2
    nu = (sd_pair ** 2 + b) ** 2 / (b ** 2 / 2)
    assert rec["t1_udr"] == pytest.approx(RD.t_one_sided(nu) * math.sqrt(sd_pair ** 2 + b), rel=1e-12)
    assert rec["sd_null"]["udr"] == 0.5 and rec["sd_null_use"] == "information only (D2)"
    text = world.text("A1_1seed.txt")
    assert "no null subtraction" in text and "assumes equal candidate and" in " ".join(text.split())
    # SELECT decides, so the same read runs the SELECT check: SE_acct^2 + 2 s_m^2 / n, the pair term not subtracted
    w2 = World(world.tmp / "sel", monkeypatch, accounts=600)
    from new_fields_reader_world import rank_check
    rank_check(w2.c2, "FAIL")
    cfg = yaml.safe_load((w2.set_dir / "SETTINGS.yaml").read_text())
    cfg.pop("null_correction")
    cfg["select_check"].pop("null_correction")
    (w2.set_dir / "SETTINGS.yaml").write_text(yaml.safe_dump(cfg, sort_keys=False))
    sraw = w2.raw["select"][0]
    write_spread(w2.c2, "select_june", 0.002, sd_null=0.5)
    c = w2.fit("select", "cand", 42, scores(sraw, 6.0, 1))
    k = w2.fit("select", "ctrl", 42, scores(sraw, 0.5, 2))
    assert w2.run("read", "--step", "A1", "--runs", w2.table("t", [c], [k])) == 0
    sel = w2.saved("A1_1seed.json")["select_check_same_read"]
    met = w2.saved("A1_1seed.json")["metrics"]
    for row in sel["rows"]:
        assert row["se"] == pytest.approx(math.sqrt(met[row["metric"]]["sd"] ** 2 + 2 * 0.002 ** 2), rel=1e-12)
        assert row["se"] > 0.002 * math.sqrt(2)


@pytest.mark.parametrize("key, value, words", [
    ("null_correction", True, "no null subtraction is used"),
    ("select_check", {"k_se": 2.5, "k_se_when_select_decides": 3.5, "null_correction": True},
     "select_check null_correction True: no null subtraction"),
    ("three_seed_bound", "pooled", "the three-seed bound is paired, the only accepted value"),
    ("three_seed_bound", "written", "a more variable candidate then gets a bound that is too high")])
def test_a_null_correction_or_the_pooled_bound_is_refused(world, capsys, key, value, words):
    cand, ctrl = _pair(world)
    _settings(world, **{key: value})
    assert world.run("read", "--step", "A1", "--runs", world.table("t", [cand], [ctrl])) == REFUSED
    assert words in " ".join(capsys.readouterr().out.split())
    assert not (world.c2 / "reads" / "settings_lock.json").exists()


def test_a_zero_spread_one_seed_read_goes_to_seeds_43_and_44_without_a_stop(world):
    cand, ctrl = _pair(world, cand_signal=6.0, ctrl_signal=0.5, sd_run=0.0)
    assert world.run("read", "--step", "A1", "--runs", world.table("t", [cand], [ctrl])) == 0
    rec = world.saved("A1_1seed.json")
    assert rec["gain_udr"] > 0.01 and rec["lb_bootstrap"] > 0      # one seed would have adopted with a spread
    assert rec["rule_decision"] == "RUN SEEDS 43 AND 44" and not rec["pending_select_check"]
    assert rec["t1_udr"] is None and rec["t1_undefined"] == RD.ZERO_SPREAD
    text = " ".join(world.text("A1_1seed.txt").split())
    assert "T1 undefined: the UDR seed spread sd_run is zero" in text and "next: S.5" in text
    import importlib.util
    spec = importlib.util.spec_from_file_location("nf_plan_z", Path(RD.__file__).with_name("nf_plan.py"))
    plan = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(plan)
    assert plan.classify(rec["decision"].upper()) == "confirm"         # the planner's seed path


def test_a_zero_udr_spread_is_reported_not_a_stop(world):
    raw = world.raw["rank_b"][0]
    jm = june_mask(raw)
    base = scores(raw, 2.0, 1).astype(np.float64)
    deep = np.sort(base[jm])[::-1][3 * (int(jm.sum()) * 3 // 500)]     # well below the 0.6% cut
    fits = []
    for s in (42, 43, 44):                    # different fits, the same top 0.6%: rows below it reordered per fit
        sc = base.copy()
        below = sc < deep
        sc[below] = np.random.default_rng(s).uniform(0.0, 0.99 * deep, int(below.sum()))
        fits.append(dict(world.fit("rank_b", "kept", s, sc.astype(np.float32)), role="kept"))
    assert world.run("spread", "--population", "rank_b", "--runs", run_table(world.tmp / "k.csv", fits)) == 0
    rec = world.saved("spread_rank_b.json")
    assert rec["metrics"]["udr"]["sd_run"] == 0.0 and rec["udr_spread_zero"] is True
    assert rec["metrics"]["ap"]["sd_run"] > 0                           # the fits differ
    assert "UDR spread zero: reported, not a stop" in " ".join(world.text("spread_rank_b.txt").split())


def test_the_larger_spread_is_used_and_select_decides_on_select_june_alone(world, monkeypatch, capsys):
    cand, ctrl = _pair(world, sd_run=0.010, select=0.022)
    t = world.table("t", [cand], [ctrl])
    assert world.run("read", "--step", "A1", "--runs", t) == 0
    rec = world.saved("A1_1seed.json")
    assert rec["sd_run_udr_used"] == 0.022 and rec["sd_run_udr_source"] == "select_june"
    assert "sd_run_udr_floor" not in rec
    (world.c2 / "reads" / "spread_select_june.json").unlink()
    (world.c2 / "reads" / "A1_1seed.json").unlink()
    assert world.run("read", "--step", "A1", "--runs", t) == REFUSED
    assert "spread --population select_june" in capsys.readouterr().out
    # SELECT decides: only spread_select_june.json is read, and the same-read check takes k 3.5
    w2 = World(world.tmp / "sel", monkeypatch, accounts=600)
    from new_fields_reader_world import rank_check
    rank_check(w2.c2, "FAIL")
    sraw = w2.raw["select"][0]
    write_spread(w2.c2, "select_june", 0.002)
    c = w2.fit("select", "cand", 42, scores(sraw, 6.0, 1))
    k = w2.fit("select", "ctrl", 42, scores(sraw, 0.5, 2))
    assert w2.run("read", "--step", "A1", "--runs", w2.table("t", [c], [k])) == 0
    rec = w2.saved("A1_1seed.json")
    assert list(rec["inputs"]["spread_sha256"]) == ["select_june"]
    assert rec["select_check_same_read"]["k_se"] == 3.5


def test_a_settings_file_with_a_floor_is_refused(world, capsys):
    cand, ctrl = _pair(world)
    _settings(world, sd_run_udr_floor=0.015)
    assert world.run("read", "--step", "A1", "--runs", world.table("t", [cand], [ctrl])) == REFUSED
    assert "no fixed floor is used (reviewers' decision of 2026-11-02)" in capsys.readouterr().out


@pytest.mark.parametrize("key, value", [("udr_unit", "account_later"), ("conflict_line", {"k_se": 3.0}),
                                        ("t1_multiplier", "other"), ("null_correction", True),
                                        ("three_seed_bound", "written"), ("select_check", {"k_se": 2.0}),
                                        ("spread_pool", ["kept"])])
def test_changing_a_decided_key_after_the_first_read_stops(world, capsys, key, value):
    cand, ctrl = _pair(world)
    t = world.table("t", [cand], [ctrl])
    assert world.run("read", "--step", "A1", "--runs", t) == 0
    lock = json.loads((world.c2 / "reads" / "settings_lock.json").read_text())
    assert key in lock["keys"]
    _settings(world, **{key: value})
    rc = world.run("read", "--step", "A2", "--runs", t)
    out = capsys.readouterr().out
    assert rc in (STOP, REFUSED)
    if rc == STOP:
        assert "decision section of SETTINGS.yaml changed" in out


@pytest.mark.parametrize("pool", [["kept"], ["current", "kept"], ["kept", "current", "old"]])
def test_a_spread_pool_other_than_the_two_trios_is_refused(world, capsys, pool):
    cand, ctrl = _pair(world)
    _settings(world, spread_pool=pool)
    assert world.run("read", "--step", "A1", "--runs", world.table("t", [cand], [ctrl])) == REFUSED
    assert "the seed spread pools the kept trio and the current-pod base trio" in capsys.readouterr().out
    assert not (world.c2 / "reads" / "settings_lock.json").exists()


def test_every_read_says_the_external_score_is_assumed_until_it_is_certified(world, monkeypatch):
    cand, ctrl = _pair(world)
    t = world.table("t", [cand], [ctrl])
    line = "external_1_scr: availability at the decision assumed, not certified (OQ-14)"
    assert world.run("read", "--step", "A1", "--runs", t) == 0
    assert world.saved("A1_1seed.json")["external_score_line"] == line and line in world.text("A1_1seed.txt")
    # a certification needs both who and when; who alone keeps the line
    w2 = World(world.tmp / "half", monkeypatch, accounts=600, external_1_scr_certified={"by": "owner", "on": ""})
    c2_, k2 = _pair(w2)
    assert w2.run("read", "--step", "A1", "--runs", w2.table("t", [c2_], [k2])) == 0
    assert line in w2.text("A1_1seed.txt")
    # the owner writes the record by hand, with a bare key `on` (which YAML 1.1 reads as True)
    w3 = World(world.tmp / "cert", monkeypatch, accounts=600)
    cfg = yaml.safe_load((w3.set_dir / "SETTINGS.yaml").read_text())
    cfg.pop("external_1_scr_certified", None)
    (w3.set_dir / "SETTINGS.yaml").write_text(yaml.safe_dump(cfg, sort_keys=False)
                                              + "external_1_scr_certified: {by: owner, on: 2026-11-05}\n")
    assert yaml.safe_load((w3.set_dir / "SETTINGS.yaml").read_text())["external_1_scr_certified"][True]
    c3, k3 = _pair(w3)
    assert w3.run("read", "--step", "A1", "--runs", w3.table("t", [c3], [k3])) == 0
    assert w3.saved("A1_1seed.json")["external_score_line"] is None
    assert "external_1_scr" not in w3.text("A1_1seed.txt")


def test_the_account_unit_is_refused_until_it_is_defined(world, capsys):
    cand, ctrl = _pair(world)
    _settings(world, udr_unit="account")
    assert world.run("read", "--step", "A1", "--runs", world.table("t", [cand], [ctrl])) == REFUSED
    assert "the account measure is not defined yet" in capsys.readouterr().out
    assert not (world.c2 / "reads" / "settings_lock.json").exists()


# ------------------------------------------------------------------ D1: the conflict line, FP/TP, account counts


def test_the_conflict_line_numbers():
    met = {"ap": {"gain": -0.030, "sd": 0.007}, "vdr": {"gain": -0.5, "sd": 0.01}}
    sp = {"rank_b": {"metrics": {"ap": {"sd_run": 0.006077, "df": 2}, "vdr": {"sd_run": 0.01, "df": 2}}}}
    r = RD.conflict_check(met, 2.5, sp, 1, "an amount is missing", ("ap", "vdr"))
    # -2.5 x sqrt(0.007^2 + 2 x 0.006077^2), no null subtraction (D2, corrected 3 November)
    assert r["rows"][0]["limit"] == pytest.approx(-0.027711, abs=5e-7) and r["rows"][0]["conflict"]
    assert [x["metric"] for x in r["rows"]] == ["ap"] and r["line"].startswith("conflict: AP -0.0300")
    met["ap"]["gain"] = -0.020
    assert RD.conflict_check(met, 2.5, sp, 1, "an amount is missing")["line"] is None


def _adopt_with_an_ap_drop(w):
    raw = w.raw["rank_b"][0]
    jm = june_mask(raw)
    y = raw["frd_tag"].to_numpy()
    n_top = 3 * (int(jm.sum()) * 3 // 500)       # three times the cut, so every resample's cut stays inside it
    rng = np.random.default_rng(0)
    noise = (rng.random(len(y)) * 0.4).astype(np.float32)
    ctrl = noise.copy()
    ctrl[np.flatnonzero(jm & (y == 0))[:n_top]] = 1.0      # the control's cut holds no fraud; its frauds come next
    ctrl[jm & (y == 1)] = 0.9
    cand = noise.copy()
    frauds = np.flatnonzero(jm & (y == 1))
    cand[frauds[:n_top]] = 1.0                            # the candidate's cut is all fraud; its other frauds last
    cand[frauds[n_top:]] = 0.0
    write_spread(w.c2, "rank_b", 0.001)
    return w.table("t", [w.fit("rank_b", "cand", 42, cand)], [w.fit("rank_b", "ctrl", 42, ctrl)])


def test_a_conflict_is_reported_and_the_decision_stands(world):
    t = _adopt_with_an_ap_drop(world)
    assert world.run("read", "--step", "A1", "--runs", t) == 0
    rec = world.saved("A1_1seed.json")
    assert rec["decision"] == "ADOPT (pending the SELECT check)"
    assert rec["conflict"]["line"].startswith("conflict: AP")
    text = world.text("A1_1seed.txt")
    assert "conflict: AP" in text and "AP screen" not in text and "FPR@0.6" not in text and "FP/TP@0.6" in text
    assert "A1 conflict | conflict: AP" in (world.c2 / "DECISIONS.log").read_text()
    import importlib.util
    spec = importlib.util.spec_from_file_location("nf_plan_c", Path(RD.__file__).with_name("nf_plan.py"))
    plan = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(plan)
    assert plan.classify(rec["decision"].upper()) == "adopt_pending"


def test_fp_tp_is_the_label_on_every_screen(world):
    raw = world.raw["rank_b"][0]
    fits = [dict(world.fit("rank_b", "kept", s, scores(raw, 2.0 + 0.3 * (s - 42), s)), role="kept")
            for s in (42, 43, 44)]
    assert world.run("spread", "--population", "rank_b", "--runs", run_table(world.tmp / "k.csv", fits)) == 0
    traw = world.raw["test1"][0]
    rows = [dict(world.fit("test1", "a", 42, scores(traw, 2.0, 1)), role="report")]
    assert world.run("report", "--population", "test1", "--runs", run_table(world.tmp / "r.csv", rows)) == 0
    for name in ("spread_rank_b.txt", "test1_report.txt"):
        text = world.text(name)
        assert "FP/TP@0.6" in text and "FPR@0.6" not in text, name


def test_the_account_count_is_information_at_the_point():
    n = 400
    y = np.zeros(n, dtype=np.int64)
    acct = np.array([f"z{i:04d}" for i in range(n)], dtype=object)
    s = np.linspace(0.5, 0.0, n)
    rows = [(0, "a1"), (1, "a1"), (10, "a1"), (20, "a2"), (30, "a3")]   # account a1 has 3 frauds, a2 and a3 one each
    for i, a in rows:
        y[i], acct[i] = 1, a
    s[0], s[1] = 0.99, 0.98            # the top cut, floor(400 x 3/500) = 2 rows, holds two of a1's frauds
    codes, units = R.account_units(acct)
    rk = R.RankedScore(s, y, codes, R.key_ranks(R.identity_keys(acct, range(n))))
    assert rk.evaluate(None)["udr"] == pytest.approx(0.4)
    assert rk.fraud_accounts_caught() == (1, 3)


# ------------------------------------------------------------------ D2 and D5b: the spread step


def test_the_spread_pair_term_is_the_rms_of_the_pairs_bootstrap_sds(world, monkeypatch):
    raw = world.raw["rank_b"][0]
    sigs = {42: 2.0, 43: 2.6, 44: 3.4}
    fits = [dict(world.fit("rank_b", "kept", s, scores(raw, sigs[s], s)), role="kept") for s in (42, 43, 44)]
    assert world.run("spread", "--population", "rank_b", "--runs", run_table(world.tmp / "k.csv", fits)) == 0
    rec = world.saved("spread_rank_b.json")
    jm = june_mask(raw)
    jr = raw[jm].reset_index(drop=True)
    codes, units = R.account_units(jr["Nmap_account_reference_xid"])
    kr = R.key_ranks(R.identity_keys(jr["Nmap_account_reference_xid"], jr["fi_transaction_id"]))
    rk = [R.RankedScore(scores(raw, sigs[s], s)[jm].astype(float), jr["frd_tag"].to_numpy(), codes, kr,
                        jr["transaction_amt"].to_numpy()) for s in (42, 43, 44)]
    for m in ("udr", "ap", "auroc"):
        sds = [R.paired([rk[a]], [rk[b]], len(units), 200, 20261102)["metrics"][m]["sd"]
               for a, b in ((0, 1), (0, 2), (1, 2))]
        assert rec["metrics"][m]["sd_null"] == pytest.approx(math.sqrt(np.mean(np.square(sds))), rel=1e-12, abs=1e-15)
    assert rec["metrics"]["udr"]["df"] == 2 and rec["same_seed_information"] is None
    # one checkpoint named twice stops; three fits with identical scores stop
    w2 = World(world.tmp / "b", monkeypatch, accounts=300)
    raw2 = w2.raw["rank_b"][0]
    same = [dict(w2.fit("rank_b", f"k{s}", s, scores(raw2, 2.0, 7)), role="kept") for s in (42, 43, 44)]
    assert w2.run("spread", "--population", "rank_b", "--runs", run_table(w2.tmp / "s.csv", same)) == STOP
    twice = [dict(w2.fit("rank_b", "kx", s, scores(raw2, 2.0 + s / 100, s)), role="kept") for s in (42, 43, 44)]
    twice[2]["checkpoint"] = str(Path(twice[0]["run_dir"]) / "best.ckpt")
    Path(f"{twice[2]['predictions']}.json").write_text(json.dumps(dict(
        json.loads(Path(f"{twice[2]['predictions']}.json").read_text()),
        checkpoint_sha256=json.loads(Path(f"{twice[0]['predictions']}.json").read_text())["checkpoint_sha256"])))
    assert w2.run("spread", "--population", "rank_b", "--runs", run_table(w2.tmp / "t.csv", twice)) == STOP


def test_the_spread_pools_the_kept_and_the_current_pod_trios_with_4_df(world):
    raw = world.raw["rank_b"][0]
    kept = {42: 2.0, 43: 2.6, 44: 3.4}
    cur = {42: 2.2, 43: 2.9, 44: 2.5}
    rows = [dict(world.fit("rank_b", "kept", s, scores(raw, v, s)), role="kept") for s, v in kept.items()]
    rows += [dict(world.fit("rank_b", "base", s, scores(raw, v, 100 + s)), role="current") for s, v in cur.items()]
    assert world.run("spread", "--population", "rank_b", "--runs", run_table(world.tmp / "k.csv", rows)) == 0
    rec = world.saved("spread_rank_b.json")
    m = rec["metrics"]["udr"]
    vk, vc = np.asarray(m["values"]), np.asarray(m["values_current"])
    pooled = math.sqrt((((vk - vk.mean()) ** 2).sum() + ((vc - vc.mean()) ** 2).sum()) / 4)
    assert m["df"] == 4 and m["sd_run"] == pytest.approx(pooled, rel=1e-12)
    assert m["sd_kept"] == pytest.approx(np.std(vk, ddof=1)) and m["sd_current"] == pytest.approx(np.std(vc, ddof=1))
    info = rec["same_seed_information"]
    assert info["note"].startswith("cross-pod and old tree") and set(info["kept_minus_current"]) == {"42", "43", "44"}
    assert info["kept_minus_current"]["43"]["udr"] == pytest.approx(vk[1] - vc[1])
    assert "same seed, kept minus current (information; cross-pod" in world.text("spread_rank_b.txt")
    # the read takes the pooled spread and its 4 degrees of freedom
    write_spread(world.c2, "select_june", 0.0001)
    c = world.fit("rank_b", "cand", 42, scores(raw, 3.0, 1))
    k = world.fit("rank_b", "ctrl", 42, scores(raw, 1.0, 2))
    assert world.run("read", "--step", "A1", "--runs", world.table("t", [c], [k])) == 0
    read = world.saved("A1_1seed.json")
    assert read["sd_run_udr_used"] == pytest.approx(pooled) and read["sd_run_udr_df"] == 4
    assert read["sd_null"]["udr"] == pytest.approx(m["sd_null"])


# ------------------------------------------------------------------ D5a, D5b: controls


def _json_rows(w, name, rows, pop="rank_b", **meta):
    out = []
    for r in rows:
        out.append({k: r[k] for k in ("role", "seed", "run", "run_dir", "predictions")} | {
            "checkpoint": str(Path(r["run_dir"]) / "best.ckpt"), "receipt": f"{r['predictions']}.json",
            **{k: r[k] for k in ("control_kind", "previous_decision") if k in r}})
    p = w.c2 / "reads" / f"{name}.runs.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({"step": "A2", "population": pop, "runs": out, **meta}))
    return str(p)


def test_a_refit_control_prints_the_kept_fit_and_the_gap_and_changes_no_decision(world, monkeypatch):
    raw = world.raw["rank_b"][0]
    write_spread(world.c2, "rank_b", 0.002)
    cand = dict(world.fit("rank_b", "nf_a2", 42, scores(raw, 3.0, 1)), role="candidate")
    ctl = dict(world.fit("rank_b", "nf_ka2", 42, scores(raw, 1.0, 2)), role="control", control_kind="refit",
               previous_decision="one_seed")
    kept = dict(world.fit("rank_b", "nf_a1", 42, scores(raw, 1.2, 3)), role="kept_fit")
    t = _json_rows(world, "A2_1seed", [cand, ctl, kept], membership="15298 beyond the kept inputs; A1 was adopted",
                   a1_adopted=True)
    assert world.run("read", "--step", "A2", "--runs", t) == 0
    rec = world.saved("A2_1seed.json")
    rf = rec["refit_control"]
    assert rf["kept_fit"] == "nf_a1" and rf["refit"] == "nf_ka2"
    assert rf["gap_udr"] == pytest.approx(rf["kept_udr"] - rf["refit_udr"])
    assert "favours the control" in rf["leaves"]
    text = world.text("A2_1seed.txt")
    assert "refit control (information): kept fit nf_a1" in text and "the refit leaves" in text
    assert "NEW FIELDS READ  step=A2 (15298 beyond the kept inputs)" in text
    assert rec["membership"].startswith("15298 beyond the kept inputs") and rec["a1_adopted"] is True
    assert "A2 refit control | kept fit nf_a1" in (world.c2 / "DECISIONS.log").read_text()
    # the same read without the kept fit row gives the same decision
    w2 = World(world.tmp / "plain", monkeypatch, accounts=600)
    raw2 = w2.raw["rank_b"][0]
    write_spread(w2.c2, "rank_b", 0.002)
    c2_ = dict(w2.fit("rank_b", "nf_a2", 42, scores(raw2, 3.0, 1)), role="candidate")
    k2 = dict(w2.fit("rank_b", "nf_ka2", 42, scores(raw2, 1.0, 2)), role="control")
    assert w2.run("read", "--step", "A2", "--runs", _json_rows(w2, "A2_1seed", [c2_, k2])) == 0
    assert w2.saved("A2_1seed.json")["decision"] == rec["decision"]


# ------------------------------------------------------------------ D4b, D4c: pruning and month-out texts


@pytest.mark.parametrize("hi", [float("nan"), None, float("inf")])
def test_a_prune_read_without_a_finite_upper_end_stops(hi):
    # D4b: an undefined interval never falls through to KEEP THE SMALLER LIST
    with pytest.raises(RD.ReadError) as e:
        RD.decide("prune", 1, -0.002, 0.0, 0.01, None, hi=hi)
    assert e.value.code == STOP and "upper end is not a number" in str(e.value)
    assert RD.decide("prune", 1, -0.002, 0.0, 0.01, None, hi=0.004)[0] == "KEEP THE SMALLER LIST"


def test_the_pruning_and_month_out_reads_state_their_limits(world):
    raw = world.raw["rank_b"][0]
    base = scores(raw, 2.0, 3)
    write_spread(world.c2, "rank_b", 0.05)
    cand = world.fit("rank_b", "nf_p", 42, base)
    ctrl = world.fit("rank_b", "nf_kp", 42, base.copy())
    assert world.run("read", "--step", "P", "--runs", world.table("p", [cand], [ctrl])) == 0
    text = world.text("P_1seed.txt")
    assert world.saved("P_1seed.json")["rule_decision"] == "KEEP THE SMALLER LIST"
    assert "no loss detected at one seed; this read cannot show no loss" in text and "interval [" in text
    c = world.fit("rank_b", "nf_b", 42, scores(raw, 0.5, 1))
    k = world.fit("rank_b", "nf_kb", 42, scores(raw, 4.0, 2))
    assert world.run("read", "--step", "B", "--runs", world.table("b", [c], [k])) == 0
    text = world.text("B_1seed.txt")
    assert "an operational simplification, not proof that removing month loses nothing" in text
    assert "favours month in" in text and "never saw in training" in text
