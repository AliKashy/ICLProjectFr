"""Recipes (design section 2.2): every form against a brute-force count, and the point-in-time rules.

Planted cases: same-second siblings, censoring before the extract start, missing kept apart from zero,
future rows changed or deleted, the label permuted, lags, other history keys, prev with ties.
"""

import importlib.util
import math
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

_W = Path(__file__).resolve().parent / "new_fields_data_world.py"
_spec = importlib.util.spec_from_file_location("new_fields_data_world", _W)
world = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(world)

import nf_recipes as R  # noqa: E402  (the world put the folder on sys.path)

ENGINE = world.engine()
ES = "2024-10-01"
NS = 10 ** 9
DAY = 86_400


def build(df, recipe, model_type="continuous", extract_start=ES, name="x"):
    frame, stats = R.build_columns(df, [(name, recipe, model_type)], extract_start, engine=ENGINE)
    return frame[name].to_numpy(), stats[name]


# ------------------------------------------------------------------------------------------ #
# A brute-force oracle: loops over rows, written straight from the rules
# ------------------------------------------------------------------------------------------ #
def oracle(df, r, es=ES):
    t = (pd.to_datetime(df[world.TIME]).to_numpy(dtype="datetime64[ns]").astype(np.int64) // NS)
    es_s = None if es is None else pd.Timestamp(R.EXTRACT_START.get(es, es)).value // NS
    key = df[r.history_key].to_numpy(dtype=object)
    same = df[r.same].to_numpy(dtype=object) if r.same else None
    where = None
    if r.where_col:
        where = pd.Series(R.code_text(df[r.where_col])).isin(r.where_values).to_numpy()
    out = []
    for i in range(len(df)):
        if pd.isna(key[i]) or (same is not None and pd.isna(same[i])):
            out.append(np.nan)
            continue
        span = None if r.unlimited else (r.window or r.within) + r.lag
        if span is not None and es_s is not None and t[i] - span < es_s:
            out.append(np.nan)
            continue
        hi = t[i] - r.lag
        lo = -10 ** 12 if span is None else t[i] - span
        js = [j for j in range(len(df)) if key[j] == key[i] and lo <= t[j] < hi
              and (same is None or (not pd.isna(same[j]) and same[j] == same[i]))
              and (where is None or where[j])]
        if r.op == "count":
            out.append(float(len(js)))
            continue
        if r.op in ("sum", "mean", "min", "max"):
            x = [float(df[r.value].iloc[j]) for j in js if np.isfinite(float(df[r.value].iloc[j]))]
            if not x:
                out.append(np.nan)
            else:
                out.append({"sum": sum, "mean": lambda v: sum(v) / len(v), "min": min, "max": max}[r.op](x))
            continue
        if r.op == "distinct":
            out.append(float(len({df[r.value].iloc[j] for j in js if not pd.isna(df[r.value].iloc[j])})))
            continue
        if r.op == "since_last":   # ln(1 + whole seconds) (the reviewers' decision D3b)
            out.append(np.log1p(t[i] - max(t[j] for j in js)) if js else np.nan)
            continue
        if r.op == "since_first":
            out.append(np.log1p(t[i] - min(t[j] for j in js)) if js else np.nan)
            continue
        raise AssertionError(r.op)
    return np.asarray(out, dtype=float)


HISTORY_RECIPES = [
    "count(24h)", "count(48h)", "count(7d; lag=24h)", "count(30d; where=transaction_type_xcd:A,B)",
    "count(7d; same=merchant_category_xcd)", "count(14d; key=customer_xid)", "count(3600s)",
    "sum(7d; value=transaction_amt)", "mean(30d; value=transaction_amt; where=transaction_type_xcd:A)",
    "min(7d; value=transaction_amt)", "max(14d; value=transaction_amt; lag=24h)",
    "sum(48h; value=transaction_amt; key=customer_xid; lag=1h)",
    "distinct(30d; value=merchant_xid)", "distinct(7d; value=merchant_category_xcd)",
    "since_last(minutes)", "since_last(days; where=transaction_type_xcd:C; within=7d)",
    "since_last(hours; same=merchant_xid)", "since_last(minutes; within=all)", "since_first(days; same=merchant_xid; within=30d)",
    "since_first(minutes; same=merchant_category_xcd; within=7d)",
]


@pytest.fixture(scope="module")
def df():
    return world.history(seed=3, accounts=8, per_account=25, start="2024-09-20", days=50)


@pytest.mark.parametrize("text", HISTORY_RECIPES)
def test_every_history_recipe_equals_the_brute_force_count(df, text):
    r = R.parse(text)
    got, _ = build(df, text)
    want = oracle(df, r)
    np.testing.assert_allclose(got, want, rtol=1e-12, atol=1e-9, equal_nan=True)


def test_hand_count_on_one_small_account():
    t = pd.to_datetime(["2024-10-10 10:00:00", "2024-10-10 10:00:00.400", "2024-10-10 12:00:00",
                        "2024-10-11 09:00:00", "2024-10-11 11:00:00"], format="ISO8601")
    d = pd.DataFrame({world.ACCOUNT: "a", world.TIME: t, world.TIE: [1, 2, 3, 4, 5],
                      "transaction_amt": [10.0, np.nan, 5.0, 7.0, 1.0], "frd_tag": 0})
    cnt, _ = build(d, "count(24h)")
    # row 1 is in the same second as row 0: neither sees the other
    assert list(cnt) == [0, 0, 2, 3, 2]
    s, _ = build(d, "sum(24h; value=transaction_amt)")
    assert np.isnan(s[0]) and np.isnan(s[1])  # nothing earlier: missing, not zero
    assert list(s[2:]) == [10.0, 15.0, 12.0]   # the missing amount never counts
    last, _ = build(d, "since_last(minutes; within=24h)")
    assert np.isnan(last[0]) and np.isnan(last[1]) and last[2] == np.log1p(7200) and last[4] == np.log1p(7200)


def test_same_second_sibling_never_changes_a_row(df):
    i = 10
    sib = df.iloc[[i]].copy()
    sib[world.TIME] = sib[world.TIME].dt.floor("s") + pd.Timedelta(milliseconds=999)
    sib[world.TIE] = 10 ** 9
    sib["transaction_amt"] = 9999.0
    sib["merchant_xid"] = "m_new"
    bigger = pd.concat([df, sib], ignore_index=True)
    for text in HISTORY_RECIPES + ["prev(transaction_type_xcd)"]:
        mt = "categorical" if text.startswith("prev") else "continuous"
        a, _ = build(df, text, mt)
        b, _ = build(bigger, text, mt)
        assert pd.Series(a[i], dtype=object).equals(pd.Series(b[i], dtype=object)) or \
            (pd.isna(a[i]) and pd.isna(b[i])) or a[i] == b[i], text


def test_windows_before_the_extract_start_are_missing_not_zero():
    t = pd.to_datetime(["2024-10-01 00:00:05", "2024-10-03 00:00:00", "2024-10-09 00:00:00"])
    d = pd.DataFrame({world.ACCOUNT: "a", world.TIME: t, world.TIE: [1, 2, 3], "transaction_amt": 1.0})
    c7, st = build(d, "count(7d)")
    assert np.isnan(c7[0]) and np.isnan(c7[1]) and c7[2] == 1.0  # 10-01 is outside [10-02, 10-09)
    assert st["censored"] == 2
    c1, _ = build(d, "count(24h)")
    assert c1[0] != c1[0] and c1[1] == 0.0  # complete empty window is a measured zero
    lagged, _ = build(d, "count(24h; lag=7d)")
    assert np.isnan(lagged[1]) and lagged[2] == 1.0  # 10-03 minus 8 days is before the start; 10-09 is not
    ev, _ = build(d.assign(**{world.TIME: t + pd.Timedelta(days=210)}), "count(30d)", extract_start="evaluation")
    assert np.isnan(ev).all()                # evaluation files start on 2025-05-01


def test_missing_values_never_count_or_match():
    t = pd.to_datetime(["2024-11-01 00:00:00", "2024-11-01 00:01:00", "2024-11-01 00:02:00"])
    d = pd.DataFrame({world.ACCOUNT: "a", world.TIME: t, world.TIE: [1, 2, 3],
                      "merchant_xid": [None, None, None], "transaction_amt": [np.nan, np.nan, 3.0],
                      "transaction_type_xcd": [None, "A", None]})
    same, _ = build(d, "count(24h; same=merchant_xid)")
    assert np.isnan(same).all()              # own value missing: no comparable history
    s, _ = build(d, "sum(24h; value=transaction_amt)")
    assert np.isnan(s).all()                 # no observed amount earlier
    w, _ = build(d, "count(24h; where=transaction_type_xcd:A)")
    assert list(w) == [0.0, 0.0, 1.0]
    dist, _ = build(d, "distinct(24h; value=transaction_type_xcd)")
    assert list(dist) == [0.0, 0.0, 1.0]


def test_future_rows_changed_or_deleted_leave_earlier_values_unchanged(df):
    rng = np.random.default_rng(7)
    t = pd.to_datetime(df[world.TIME])
    # one cutoff for every key (account, customer, merchant), on a whole second
    cutoff = t.sort_values().iloc[len(t) // 2].floor("s")
    after = (t.dt.floor("s") > cutoff).to_numpy()
    changed = df.copy()
    changed.loc[after, "transaction_amt"] = changed.loc[after, "transaction_amt"] * 13 + 1
    changed.loc[after, "merchant_xid"] = rng.permutation(changed.loc[after, "merchant_xid"].to_numpy())
    changed.loc[after, "transaction_type_xcd"] = "C"
    keep = ~(after & (rng.random(len(df)) < 0.4))
    changed = changed[keep]
    before = ~after
    for text in HISTORY_RECIPES + ["prev(falcon_decision_xcd)", "days_before(pwd_chg_dt)"]:
        mt = "categorical" if text.startswith("prev") else "continuous"
        a, _ = build(df, text, mt)
        b, _ = build(changed, text, mt)
        a_before = pd.Series(a, dtype=object)[before]
        b_all = pd.Series(b, index=changed.index, dtype=object)
        b_before = b_all.loc[a_before.index]
        assert a_before.fillna("<NA>").astype(str).tolist() == b_before.fillna("<NA>").astype(str).tolist(), text


def test_permuting_the_label_changes_no_built_value(df):
    p = df.copy()
    p["frd_tag"] = np.random.default_rng(1).permutation(p["frd_tag"].to_numpy())
    fields = [(f"f{k}", text, "continuous") for k, text in enumerate(HISTORY_RECIPES)]
    a, _ = R.build_columns(df, fields, ES, engine=ENGINE)
    b, _ = R.build_columns(p, fields, ES, engine=ENGINE)
    pd.testing.assert_frame_equal(a, b)


def test_build_before_selecting_targets(df):
    """Histories come from every row of the file; computing on a downsampled frame gives other values."""
    full, _ = build(df, "count(30d)")
    keep = (np.arange(len(df)) % 3) == 0
    sub, _ = build(df[keep].reset_index(drop=True), "count(30d)")
    finite = ~np.isnan(full[keep])
    assert not np.array_equal(full[keep][finite], sub[finite])
    assert (sub[finite] <= full[keep][finite]).all()


def test_other_keys_stay_distinct(df):
    acct, _ = build(df, "count(30d)")
    cust, _ = build(df, "count(30d; key=customer_xid)")
    ok = ~np.isnan(acct)
    assert (cust[ok] >= acct[ok]).all() and (cust[ok] > acct[ok]).any()


def test_since_first_is_not_account_opening(df):
    v, _ = build(df, "since_first(days; same=merchant_xid; within=30d)")
    first_rows = ~df.duplicated(world.ACCOUNT)
    t = pd.to_datetime(df[world.TIME])
    complete = (t - pd.Timedelta(days=30) >= pd.Timestamp(ES)).to_numpy()
    assert np.isnan(v[first_rows.to_numpy() & complete]).all()


def test_prev_takes_the_latest_strictly_earlier_row_with_ties_by_id():
    t = pd.to_datetime(["2024-11-01 00:00:00", "2024-11-01 00:00:00.5", "2024-11-01 00:00:09",
                        "2024-11-01 00:00:09"], format="ISO8601")
    d = pd.DataFrame({world.ACCOUNT: "a", world.TIME: t, world.TIE: [11, 10, 12, 13],
                      "falcon_decision_xcd": ["x", "y", "z", "w"]})
    v, st = build(d, "prev(falcon_decision_xcd)", "categorical")
    assert v[0] is None and v[1] is None          # same second, nothing earlier
    assert v[2] == "y" and v[3] == "y"            # latest earlier row by stored time (.5 s after the other)
    same_ns = d.assign(**{world.TIME: pd.to_datetime(["2024-11-01 00:00:00"] * 2 + ["2024-11-01 00:00:09"] * 2)})
    w, _ = build(same_ns, "prev(falcon_decision_xcd)", "categorical")
    assert w[2] == "x"                            # equal stored times: the larger id is later
    assert st["censored"] == 0                    # the 30-day lookback is complete: none earlier is measured
    _, st_all = build(d, "prev(falcon_decision_xcd; within=all)", "categorical")
    assert st_all["censored"] == 2                # no limit: nothing seen since the start is unknown
    num, _ = build(d.assign(falcon_decision_xcd=[1.0, 2.0, np.nan, 4.0]), "prev(falcon_decision_xcd)",
                   "categorical")
    assert num[2] == "2"                         # the .5 s row is the later one


def test_code_is_the_raw_code_one_to_one():
    s = pd.Series([1.0, 2.0, np.nan, 1.0])
    assert list(R.code_text(s)) == ["1", "2", None, "1"]
    assert list(R.code_text(pd.Series(["007", "7", None]))) == ["007", "7", None]
    d = pd.DataFrame({world.ACCOUNT: "a", world.TIME: pd.to_datetime(["2024-11-01"] * 3), world.TIE: [1, 2, 3],
                      "transaction_type_xcd": ["A", None, "B"]})
    v, _ = build(d, "code(transaction_type_xcd)", "categorical")
    assert list(v) == ["A", None, "B"]
    r = R.parse("code(transaction_type_xcd)")
    assert "not a proven equivalent" in r.describe()["as_of_rule"]


def test_dates_parse_rules_and_days_before_and_until():
    t = pd.Timestamp("2024-11-11 12:00:00")
    vals = pd.Series(["20241101", "2024-11-01", "2024-11-01 06:00:00", "not a date", None], dtype=object)
    d = pd.DataFrame({world.ACCOUNT: "a", world.TIME: [t] * 5, world.TIE: range(5), "pwd_chg_dt": vals})
    v, st = build(d, "days_before(pwd_chg_dt)")
    # ln(1 + whole seconds) (the reviewers' decision D3b): a date with no time part counts whole calendar days
    assert v[:3].tolist() == pytest.approx([np.log1p(10 * DAY), np.log1p(10 * DAY), np.log1p(10.25 * DAY)])
    assert np.isnan(v[3]) and np.isnan(v[4])
    assert st["parse"]["failed"] == 1 and st["parse"]["non_null"] == 4
    nums = pd.Series([20241101, t.value // NS - 86_400, (t.value // NS - 2 * 86_400) * 1000], dtype="float64")
    v2, st2 = build(d.iloc[:3].assign(pwd_chg_dt=nums.to_numpy()), "days_before(pwd_chg_dt)")
    assert v2.tolist() == pytest.approx([np.log1p(10 * DAY), np.log1p(DAY), np.log1p(2 * DAY)])
    assert set(st2["parse"]["rules"]) == {"yyyymmdd number", "epoch seconds number", "epoch milliseconds number"}
    u, _ = build(d.iloc[:1].assign(pwd_chg_dt="20241121"), "days_until(pwd_chg_dt)")
    assert u[0] == pytest.approx(np.log1p(10))     # a known future date: sign(u) ln(1 + |u|), u in days
    f, st_f = build(d.iloc[:1].assign(pwd_chg_dt="0127"), "days_until(pwd_chg_dt; format=%m%y)")
    # a month-level expiry is the last day of its month
    assert f[0] == pytest.approx(np.log1p((pd.Timestamp("2027-01-31") - t.normalize()).days))
    assert "last day of the month" in st_f["parse"]["convention"]
    neg, st_n = build(d.iloc[:1].assign(pwd_chg_dt="20241201"), "days_before(pwd_chg_dt)")
    assert np.isnan(neg[0]) and st_n["parse"]["reasons"] == {"after_transaction": 1}   # missing, with its reason


def test_ratio_needs_both_values_and_a_positive_divisor():
    d = pd.DataFrame({world.ACCOUNT: "a", world.TIME: pd.to_datetime(["2024-11-01"] * 4), world.TIE: range(4),
                      "transaction_amt": [10.0, 10.0, np.nan, 10.0],
                      "total_available_balance_amt": [5.0, 0.0, 5.0, -1.0]})
    v, _ = build(d, "ratio(transaction_amt; total_available_balance_amt)")
    assert v[0] == 2.0 and np.isnan(v[1:]).all()


def test_same_day_date_without_time_is_missing_not_a_fraction_of_a_day():
    """A status date written on the transaction's own day (after it) must not look earlier (review item 6)."""
    t = pd.Timestamp("2024-11-11 09:00:00")
    d = pd.DataFrame({world.ACCOUNT: "a", world.TIME: [t] * 3, world.TIE: range(3),
                      "pwd_chg_dt": ["2024-11-11", "2024-11-11 08:00:00", "2024-11-10"]})
    v, st = build(d, "days_before(pwd_chg_dt)")
    assert np.isnan(v[0]) and v[1] == pytest.approx(np.log1p(3600)) and v[2] == pytest.approx(np.log1p(DAY))
    assert st["parse"]["same_day"] == 1 and st["parse"]["date_only"] == 2
    k, _ = build(d, "days_before(pwd_chg_dt; same_day=keep)")
    assert k[0] == 0.0                       # ln(1), only with same_day=keep
    u, _ = build(d, "days_until(pwd_chg_dt)")
    assert u[0] == 0.0                       # a known future date on the same day is no leak


def test_one_row_account_gives_missing_not_zero():
    """Review item 11 (e): an account with one row has no history: since_last, prev and mean are missing."""
    d = pd.DataFrame({world.ACCOUNT: ["solo"], world.TIME: [pd.Timestamp("2025-01-15 10:00:00")],
                      world.TIE: [1], "transaction_amt": [5.0], "falcon_decision_xcd": ["1"]})
    for text, mt in [("since_last(minutes)", "continuous"), ("prev(falcon_decision_xcd)", "categorical"),
                     ("mean(7d; value=transaction_amt)", "continuous"), ("max(7d; value=transaction_amt)",
                                                                         "continuous")]:
        v, _ = build(d, text, mt)
        assert pd.isna(v[0]), text
    c, _ = build(d, "count(7d)")
    assert c[0] == 0.0                       # a complete empty window is a measured zero


def test_deleting_history_changes_values_only_as_the_recipe_implies(df):
    """Review item 11 (d): delete earlier rows; every value equals the brute force on what is left, and
    censored rows stay missing (never a zero)."""
    keep = np.random.default_rng(5).random(len(df)) > 0.35
    small = df[keep].reset_index(drop=True)
    for text in HISTORY_RECIPES:
        r = R.parse(text)
        got, st = build(small, text)
        np.testing.assert_allclose(got, oracle(small, r), rtol=1e-12, atol=1e-9, equal_nan=True)
        full, st_full = build(df, text)
        cens_small = R.FileContext(small, ES, ENGINE[0]).build(r).censored
        assert np.isnan(got[cens_small]).all(), text


def test_history_parity_and_lookback_are_declared():
    assert R.parse("since_last(minutes)").describe()["lookback"] == "30d"
    assert R.parse("prev(falcon_decision_xcd)").describe()["history_parity"] == "ok"
    assert R.parse("since_last(minutes; within=all)").describe()["history_parity"] == "flag"
    assert R.parse("count(90d)").describe()["history_parity"] == "flag"
    assert R.parse("count(24h; lag=7d)").describe()["history_parity"] == "ok"
    assert R.parse("days_until(card_expiration_dt)").describe()["date_meaning"] == "known_future_date"
    d = R.parse("code(transaction_type_xcd)").describe()
    assert d["mapping_status"] == "open" and d["equivalence"] == "unverified"


def test_engine_reuses_strict_window_unchanged(df):
    sw_mod = ENGINE[0]
    t, _ = R.second_key(df[world.TIME])
    sw = sw_mod.StrictWindows(df[world.ACCOUNT].to_numpy(), t, R.extract_start_ns(ES))
    got, _ = build(df, "count(24h)")
    np.testing.assert_array_equal(got, sw.count("24h"))


def test_a3_calls_the_26_october_builders_unchanged(df):
    whole = df.assign(**{world.TIME: pd.to_datetime(df[world.TIME]).dt.floor("s")})
    want = ENGINE[1][0].compute_groups(whole, ES)["cnt_24h_log1p"].to_numpy()
    got, _ = build(whole, "a3(cnt_24h_log1p)")
    np.testing.assert_array_equal(got, want)
    want_new = ENGINE[1][1].compute_new(whole, ES)["drain_24h"].to_numpy()
    got_new, _ = build(whole, "a3(drain_24h)")
    np.testing.assert_array_equal(got_new, want_new)


def test_a3_is_refused_when_times_carry_subsecond_parts(df):
    with pytest.raises(R.RecipeError, match="sub-second"):
        build(df, "a3(cnt_24h_log1p)")


def test_subsecond_share_is_reported(df):
    _, st = build(df, "count(24h)")
    assert 0 < st["subsecond_share"] < 1


@pytest.mark.parametrize("text,reason", [
    ("velocity(24h)", "unknown recipe"),
    ("count(25h)", "unknown window"),
    ("count(24h; value=transaction_amt)", "not allowed"),
    ("sum(24h)", "needs value"),
    ("sum(24h; value=frd_tag)", "label"),
    ("count(24h; where=chargeback_flag:1)", "label"),
    ("days_before(case_disposition_dt)", "label"),
    ("since_first(days; same=merchant_xid)", "within"),
    ("since_last(weeks)", "unit"),
    ("count(24h; same=transaction_dttm)", "time key"),
    ("count 24h", "does not parse"),
    ("days_before(cprsrvc__pisinfo2)", "generic_source"),
    ("code(cprsrvc__pisinfo)", "generic_source"),
    ("days_before(x_dt; same_day=drop)", "same_day"),
    ("days_until(x_dt; same_day=keep)", "not allowed"),
    ("since_last(minutes; within=40h)", "unknown window"),
    ("", "empty"),
])
def test_parse_refuses_with_a_reason(text, reason):
    with pytest.raises(R.RecipeError, match=reason):
        R.parse(text)


def test_describe_gives_window_lag_and_as_of_rule():
    d = R.parse("count(48h; lag=24h; key=customer_xid)").describe()
    assert d["window"] == "48h" and d["lag"] == "24h" and d["group_key"] == "customer_xid"
    assert "censored" in d["as_of_rule"] and "whole seconds" in d["as_of_rule"]
    assert R.parse("raw").describe()["as_of_rule"].startswith("value stored on the row")
    assert R.parse("since_first(days; same=merchant_xid; within=90d)").describe()["window"] == "90d"


def test_build_refuses_raw_rows_and_existing_names(df):
    with pytest.raises(R.RecipeError, match="passes through"):
        R.build_columns(df, [("y", "raw", "continuous")], ES, engine=ENGINE)
    with pytest.raises(R.RecipeError, match="already a column"):
        R.build_columns(df, [("transaction_amt", "count(24h)", "continuous")], ES, engine=ENGINE)


def test_output_types_numbers_float_codes_text(df):
    frame, _ = R.build_columns(df, [("a", "count(24h)", "continuous"), ("b", "count(24h)", "categorical")], ES,
                               engine=ENGINE)
    assert frame["a"].dtype == np.float64
    assert all(v is None or isinstance(v, str) for v in frame["b"])
    assert math.isnan(frame["a"].iloc[0]) or frame["a"].iloc[0] >= 0


MAP = pd.DataFrame([
    {"name": "transaction_amt", "recipe": "raw", "model_type": "continuous"},
    {"name": "amt_sum_7d", "recipe": "sum(7d; value=transaction_amt)", "model_type": "continuous"},
    {"name": "amt_ratio", "recipe": "ratio(transaction_amt; total_available_balance_amt)", "model_type": "continuous"},
    {"name": "cnt_24h", "recipe": "count(24h)", "model_type": "continuous"},
    {"name": "type_code", "recipe": "code(transaction_type_xcd)", "model_type": "categorical"},
])


def test_build_fields_adds_engineered_columns_and_keeps_the_rest(df):
    out = R.build_fields(df, MAP, extract_start=ES, engine=ENGINE)
    assert list(out.columns) == list(df.columns) + ["amt_sum_7d", "amt_ratio", "cnt_24h", "type_code"]
    pd.testing.assert_frame_equal(out[df.columns], df)
    want, _ = build(df, "sum(7d; value=transaction_amt)")
    np.testing.assert_array_equal(out["amt_sum_7d"].to_numpy(), want)
    again = R.build_fields(df, MAP, extract_start=ES, engine=ENGINE)
    pd.testing.assert_frame_equal(out, again)


def test_dependency_closure_and_required_columns():
    c = R.dependency_closure(MAP, ["transaction_amt"])
    assert c["sources"] == {"transaction_amt"} and c["outputs"] == {"amt_sum_7d", "amt_ratio"}
    c2 = R.dependency_closure(MAP, ["amt_ratio"])
    assert c2["sources"] == {"transaction_amt", "total_available_balance_amt"}
    assert c2["outputs"] == {"amt_sum_7d", "amt_ratio"}
    assert R.dependency_closure(MAP, ["cnt_24h"])["outputs"] == set()  # reads only the keys
    assert R.required_columns(MAP, ["amt_ratio", "type_code"]) == [
        world.ACCOUNT, world.TIME, world.TIE, "transaction_amt", "total_available_balance_amt",
        "transaction_type_xcd"]
    with pytest.raises(R.RecipeError):
        R.dependency_closure(MAP, ["nope"])


def test_a_blocked_source_blocks_every_recipe_that_reads_it():
    flags = R.inherited_flags(MAP, {"transaction_amt": "WAIT", "transaction_type_xcd": "PASS"})
    assert set(flags) == {"amt_sum_7d", "amt_ratio"}
    assert flags["amt_ratio"] == ["source transaction_amt: WAIT"]


# ------------------------------------------------------------------------------------------ #
# Self-check findings, each pinned by a test
# ------------------------------------------------------------------------------------------ #
def test_unrecognised_date_numbers_fail_instead_of_becoming_1970():
    d, rep, _ = R.parse_dates(pd.Series(["2712", "202712", "99991231", "00000000", "21010101"], dtype=object))
    # the reviewers' decision D3b: a stored 0 and any date after 2100-12-31 are sentinels, not parse failures
    assert (d == R.NAT).all() and rep["failed"] == 2 and rep["sentinel"] == 3
    d2, rep2, _ = R.parse_dates(pd.Series([202712.0, 2712.0, 1.7e9, 1.7e12]))
    assert (d2[:2] == R.NAT).all() and (d2[2:] != R.NAT).all()
    d3, _, _ = R.parse_dates(pd.Series(["0127"], dtype=object), "%m%y")
    assert d3[0] == pd.Timestamp("2027-01-01").value


def test_a_9999_sentinel_date_fails_and_does_not_crash():
    stored = pd.Series(np.array(["9999-12-31", "2024-01-01"], dtype="datetime64[us]"))
    d, rep, _ = R.parse_dates(stored)
    assert d[0] == R.NAT and d[1] == pd.Timestamp("2024-01-01").value and rep["failed"] == 0 and rep["sentinel"] == 1
    d2, rep2, _ = R.parse_dates(pd.Series(["9999-12-31", "99991231"], dtype=object))
    assert (d2 == R.NAT).all() and rep2["failed"] == 0 and rep2["sentinel"] == 2


def test_large_integer_codes_stay_distinct():
    s = pd.Series([9007199254740993, 9007199254740992], dtype="int64")
    assert list(R.code_text(s)) == ["9007199254740993", "9007199254740992"]
    assert list(R.code_text(pd.Series([5, None], dtype="Int64"))) == ["5", None]


def test_zoned_midnight_dates_are_judged_in_their_own_zone():
    t = pd.Series(pd.to_datetime(["2025-01-10 09:00:00"]).tz_localize("Europe/Berlin"))
    dz = pd.Series(pd.to_datetime(["2025-01-10 00:00:00"]).tz_localize("Europe/Berlin"))
    d = pd.DataFrame({world.ACCOUNT: ["a"], world.TIME: t, world.TIE: [1], "pwd_chg_dt": dz})
    v, st = build(d, "days_before(pwd_chg_dt)")
    assert np.isnan(v[0]) and st["parse"]["same_day"] == 1
    mixed = d.assign(pwd_chg_dt=pd.Series(["2025-01-09T00:00:00+01:00"], dtype=object))
    v2, _ = build(mixed, "days_before(pwd_chg_dt)")
    assert v2[0] == pytest.approx(np.log1p(DAY))


def test_mixed_zone_text_is_refused_with_a_reason():
    d = pd.DataFrame({world.ACCOUNT: "a", world.TIME: pd.to_datetime(["2025-01-10"] * 2), world.TIE: [1, 2],
                      "pwd_chg_dt": pd.Series(["2025-01-09T00:00:00+01:00", "2025-01-09T00:00:00+05:00"],
                                              dtype=object)})
    try:
        v, _ = build(d, "days_before(pwd_chg_dt)")
    except R.RecipeError as e:
        assert "zone" in str(e) or "format" in str(e)
    else:  # read as instants in UTC: 2025-01-08 23:00 and 19:00 UTC, both one or two days before
        assert np.isfinite(v).all()
        assert v.tolist() == pytest.approx([
            np.log1p((pd.Timestamp("2025-01-10") - pd.Timestamp("2025-01-08 23:00")).total_seconds()),
            np.log1p((pd.Timestamp("2025-01-10") - pd.Timestamp("2025-01-08 19:00")).total_seconds())])


def test_prev_follows_stored_time_inside_the_earlier_second():
    t = pd.to_datetime(["2025-01-10 10:00:00.900", "2025-01-10 10:00:00.100", "2025-01-10 10:00:05"],
                       format="ISO8601")
    d = pd.DataFrame({world.ACCOUNT: "a", world.TIME: t, world.TIE: [1, 2, 3], "falcon_decision_xcd":
                      ["late", "early", "now"]})
    v, _ = build(d, "prev(falcon_decision_xcd)", "categorical")
    assert v[2] == "late"


def test_windows_are_capped_and_a_where_value_never_seen_is_reported():
    with pytest.raises(R.RecipeError, match="longer than"):
        R.parse("count(9300000000s)")
    d = pd.DataFrame({world.ACCOUNT: "a", world.TIME: pd.to_datetime(["2025-01-10", "2025-01-11"]),
                      world.TIE: [1, 2], "cardholder_present_xflg": [True, True]})
    _, st = build(d, "count(24h; where=cardholder_present_xflg:true)")
    assert st["where_matches"] == 0 and "every count is 0" in st["warning"]
    _, st2 = build(d, "count(24h; where=cardholder_present_xflg:True)")
    assert st2["where_matches"] == 2
