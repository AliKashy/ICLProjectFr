"""Synthetic data for the data lane's tests: small account histories, parquet files and a field map.

No bank data and no network. Every value is drawn from a fixed seed.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[4]
NF = ROOT / "fraud" / "experiments" / "features" / "new_fields"
for p in (str(NF), str(ROOT / "src"), str(ROOT)):
    if p not in sys.path:
        sys.path.insert(0, p)

ACCOUNT = "Nmap_account_reference_xid"
TIME = "transaction_dttm"
TIE = "fi_transaction_id"

# The 23 base predictors' raw columns (19 raw fields; month, day, hour and day of week come from the time).
BASE_CONT = ["transaction_amt", "total_available_balance_amt", "remain_day_merchandise_lmt_amt",
             "available_daily_cash_limit_amt", "external_1_scr", "cvv_score"]
BASE_CAT = ["transaction_type_xcd", "merchant_category_xcd", "cardholder_present_xflg", "pos_entry_xcd",
            "channel_code", "mcc_group", "country_xcd", "currency_xcd", "card_type_xcd", "auth_xcd",
            "terminal_xcd", "network_xcd", "region_xcd"]


def history(seed: int = 0, accounts: int = 30, per_account: int = 40, start="2024-10-01",
            days: int = 120, fraud_share: float = 0.05) -> pd.DataFrame:
    """Rows of several accounts in stored order, with same-second siblings and missing values."""
    rng = np.random.default_rng(seed)
    rows = []
    t0 = pd.Timestamp(start).value
    tid = 0
    for a in range(accounts):
        n = int(rng.integers(per_account // 2, per_account + 1))
        secs = np.sort(rng.integers(0, days * 86_400, size=n))
        # plant same-second siblings
        if n > 4:
            secs[2] = secs[1]
            secs[4] = secs[3]
        for s in secs:
            tid += 1
            sub = int(rng.integers(0, 1_000_000_000)) if rng.random() < 0.3 else 0
            rows.append({
                ACCOUNT: f"acct{a:03d}",
                "customer_xid": f"cust{a // 2:03d}",
                TIME: pd.Timestamp(t0 + int(s) * 1_000_000_000 + sub),
                TIE: tid,
                "frd_tag": int(rng.random() < fraud_share),
                "transaction_amt": float(np.round(rng.gamma(2.0, 40.0), 2)) if rng.random() > 0.05 else np.nan,
                "transaction_type_xcd": rng.choice(["A", "B", "C", None], p=[0.5, 0.3, 0.15, 0.05]),
                "merchant_category_xcd": float(rng.choice([5411, 5812, 5999, 6011])) if rng.random() > 0.1 else np.nan,
                "merchant_xid": f"m{int(rng.integers(0, 12))}",
                "falcon_decision_xcd": rng.choice(["0", "1", None], p=[0.8, 0.15, 0.05]),
                "card_expiration_dt": "20270131" if rng.random() > 0.1 else None,
                "pwd_chg_dt": (pd.Timestamp(t0 - int(rng.integers(1, 400)) * 86_400 * 10 ** 9).strftime("%Y-%m-%d")
                               if rng.random() > 0.2 else None),
                "pin_set_epoch": float(pd.Timestamp(t0).value // 10 ** 9 - int(rng.integers(0, 10 ** 7)))
                if rng.random() > 0.2 else np.nan,
                "total_available_balance_amt": float(rng.normal(1000, 300)) if rng.random() > 0.1 else np.nan,
                "remain_day_merchandise_lmt_amt": float(rng.normal(800, 100)),
                "available_daily_cash_limit_amt": float(rng.choice([0.0, 500.0, 1000.0])),
            })
    return pd.DataFrame(rows)


def write_file(df: pd.DataFrame, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(path, index=False)
    return path


def raw_world(root: Path, seed: int = 0, train_files=(1, 2, 3), eval_files=(8000, 8001)) -> dict:
    """Training-like files under root/tfm_raw_data and evaluation-like files under root/tfm_EVAL_raw_data.

    Accounts sit inside one file. Evaluation files start on 2025-05-01.
    """
    out = {"train": {}, "eval": {}}
    for k, n in enumerate(train_files):
        df = history(seed=seed + k, accounts=12, per_account=30, start="2024-10-01")
        df[ACCOUNT] = df[ACCOUNT] + f"_f{n}"
        df["customer_xid"] = df["customer_xid"] + f"_f{n}"
        out["train"][n] = write_file(df, root / "tfm_raw_data" / f"part_{n}.parquet")
    for k, n in enumerate(eval_files):
        df = history(seed=seed + 100 + k, accounts=10, per_account=30, start="2025-05-01", days=60)
        df[ACCOUNT] = df[ACCOUNT] + f"_e{n}"
        df["customer_xid"] = df["customer_xid"] + f"_e{n}"
        out["eval"][n] = write_file(df, root / "tfm_EVAL_raw_data" / f"part_{n}.parquet")
    return out


MAP_COLUMNS = ["name", "group", "kind", "recipe", "source_columns", "model_type", "window", "lag", "as_of_rule",
               "definition_version", "tfm_name", "f15298_name", "v22b_rank", "f15298_rank", "excluded_by_sumegha",
               "sumegha_reason", "feasible_in_production", "feasibility_note", "external_score", "status_rule",
               "data_owner_fixed", "left_out_reason", "list_status", "list_source", "check_result", "check_reasons",
               "cluster_id", "kept_once_as", "notes"]

FIELDS = [
    # name, group, kind, recipe, sources, model_type
    ("cnt_24h", "f15298", "engineered", "count(24h)", "", "continuous"),
    ("cnt_48h_lag_1d", "f15298", "engineered", "count(48h; lag=24h)", "", "continuous"),
    ("amt_sum_7d", "f15298", "engineered", "sum(7d; value=transaction_amt)", "transaction_amt", "continuous"),
    ("min_since_last", "f15298", "engineered", "since_last(minutes)", "", "continuous"),
    ("prev_falcon", "v22b", "engineered", "prev(falcon_decision_xcd)", "falcon_decision_xcd", "categorical"),
    ("pwd_chg_days", "v22b", "engineered", "days_before(pwd_chg_dt)", "pwd_chg_dt", "continuous"),
    ("card_exp_days_until", "v22b", "engineered", "days_until(card_expiration_dt)", "card_expiration_dt",
     "continuous"),
    ("type_code", "f15298", "engineered", "code(transaction_type_xcd)", "transaction_type_xcd", "categorical"),
    ("merchant_xid", "v22b", "raw", "raw", "merchant_xid", "categorical"),
]


def field_map(path: Path, fields=FIELDS, list_status="CONFIRMED", check_result="PASS") -> Path:
    rows = []
    for name, group, kind, recipe, src, mtype in fields:
        r = {c: "" for c in MAP_COLUMNS}
        r.update(name=name, group=group, kind=kind, recipe=recipe, source_columns=src, model_type=mtype,
                 definition_version="1", excluded_by_sumegha="no", feasible_in_production="yes",
                 list_status=list_status, list_source="owner_list.csv sha256 0", check_result=check_result)
        rows.append(r)
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows, columns=MAP_COLUMNS).to_csv(path, index=False)
    return path


def field_status(path: Path, map_path: Path, result="PASS") -> Path:
    m = pd.read_csv(map_path, dtype=str, keep_default_na=False)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame({"field": m["name"], "result": result, "reasons": ""}).to_csv(path, index=False)
    return path


def engine():
    """The base's strict-window module and the 26 October builders (pre-reorganization names)."""
    import nf_layout
    sw = nf_layout.get("strict_window")
    return sw, (nf_layout.get("groups"), nf_layout.get("features_new"))
