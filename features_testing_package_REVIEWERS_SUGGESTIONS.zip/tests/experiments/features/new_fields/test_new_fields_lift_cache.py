"""A saved lift stays reusable only while its actual prediction file is unchanged."""
from pathlib import Path
import sys

import pytest

NF = Path(__file__).resolve().parents[4] / "fraud/experiments/features/new_fields"
sys.path.insert(0, str(NF))
import nf_plan as P


@pytest.mark.parametrize("relative_path", [False, True])
@pytest.mark.parametrize("change", ["replace", "delete"])
def test_lift_reuse_checks_current_prediction_bytes(tmp_path, monkeypatch, relative_path, change):
    monkeypatch.setenv("NF_OUT", str(tmp_path / "outputs"))
    monkeypatch.setattr(P.C, "ROOT", tmp_path)
    monkeypatch.setattr(P.C, "settings_hashes", lambda: {"SETTINGS.yaml": "unchanged"})
    checkpoint = tmp_path / "candidate" / "best.ckpt"
    checkpoint.parent.mkdir()
    checkpoint.write_bytes(b"fixed model")
    prediction = tmp_path / "outputs" / "downstream" / "candidate" / "predictions.parquet"
    prediction.parent.mkdir(parents=True)
    prediction.write_bytes(b"original predictions")
    recorded = P.C.sha256_file(prediction)
    path = str(prediction.relative_to(tmp_path) if relative_path else prediction)
    P.C.write_json(prediction.parent / "summary.json", {
        "predictions": {"base_raw": path},
        "predictions_sha256": {"base_raw": recorded},
    })
    entries = [{"tag": "candidate", "dir": checkpoint.parent, "ckpt": checkpoint}]
    roles = [("candidate", 42)]
    rows = P.lift_table(entries, roles)
    P.C.write_json(P.read_path("A1", "lift"), {"flag": False})
    P.C.write_json(P.c2("reads", "A1_lift.inputs.json"), P.inputs_record(rows))
    assert P.read_job("A1", "lift", "lift", rows, "ds_select", "S.7") is None

    if change == "replace":
        prediction.write_bytes(b"changed predictions")
    else:
        prediction.unlink()
    changed = P.lift_table(entries, roles)
    # The expected receipt hash is retained separately from current file identity.
    assert changed[0]["downstream_sha256"] == recorded
    with pytest.raises(P.Stop, match="inputs changed"):
        P.read_job("A1", "lift", "lift", changed, "ds_select", "S.7")
