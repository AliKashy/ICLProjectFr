"""The resolver: this tree resolves in its own layout (the base before the reorganization, the pod after it); a stub
tree of either layout is that layout; a mixed tree stops with exit 4 and lists the names; a missing attribute is
named."""
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[4]
NF = ROOT / "fraud" / "experiments" / "features" / "new_fields"
sys.path.insert(0, str(NF))
import nf_layout  # noqa: E402

REO_ATTRS = {
    "fraud.scripts.train_sequential_hier": "def source_sha256(): return 'x'\ndef source_files(): return {}\n"
    "def run_identity(cfg, a): return {}\ndef check_batch_plan(cfg): return None\n"
    "def eval_batch_size(cfg): return 1\nMAX_STAGE1_ROWS = 65535\n",
    "fraud.scripts.score_sequential_hier": "def load_for_scoring(c, p): pass\ndef select(l, b, c): pass\n"
    "def _model_inputs(b, d): pass\nPOPULATIONS = ('SELECT', 'OTHER')\n",
    "fraud.scripts.business_metrics": "def _alert(*a): pass\ndef _ranking(*a): pass\n",
    "fraud.scripts.compare_models": "def load_raw(*a): pass\ndef target_mask(*a): pass\n",
    "fraud.data.prediction_files": "def read_table(*a): pass\n",
}
# the same attributes under the pre-reorganization names (read_table in the second module of the split key)
FB_ATTRS = {
    "waqas.v2.scripts.train_v2": REO_ATTRS["fraud.scripts.train_sequential_hier"],
    "waqas.v2.scripts.score_v2": REO_ATTRS["fraud.scripts.score_sequential_hier"],
    "waqas.v2.analysis.business_metrics": REO_ATTRS["fraud.scripts.business_metrics"],
    "waqas.v2.analysis.paired_v2": REO_ATTRS["fraud.scripts.compare_models"],
    "waqas.v2.benchmark_v2": "def read_table(*a): pass\n",
}


def _write_module(root, name, body=""):
    if name.startswith("path:"):
        p = root / name[5:]
    else:
        parts = name.split(".")
        p = root.joinpath(*parts).with_suffix(".py")
        # regular packages under fraud/ except fraud/experiments (namespace, no __init__.py), as on the pod
        for i in range(1, len(parts)):
            d = root.joinpath(*parts[:i])
            if "experiments" not in d.relative_to(root).parts and parts[0] in ("fraud", "waqas"):
                d.mkdir(parents=True, exist_ok=True)
                (d / "__init__.py").touch()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(body)


def _stub_tree(tmp_path, side, keys=None, drop_attr=None):
    root = tmp_path / "proj"
    for k, (reo, fb) in nf_layout.TABLE.items():
        if keys is not None and k not in keys:
            continue
        for n in (reo if side == 0 else fb):
            body = (REO_ATTRS if side == 0 else FB_ATTRS).get(n, "")
            if drop_attr and drop_attr in body:
                body = "\n".join(ln for ln in body.splitlines() if drop_attr not in ln) + "\n"
            _write_module(root, n, body)
    dst = root / "fraud" / "experiments" / "features" / "new_fields"
    dst.mkdir(parents=True, exist_ok=True)
    shutil.copy(NF / "nf_layout.py", dst / "nf_layout.py")
    return root


def _run(root, code):
    return subprocess.run([sys.executable, "-c", code], cwd=root, capture_output=True, text=True,
                          env={"PATH": "/usr/bin:/bin", "PYTHONDONTWRITEBYTECODE": "1"})


PRELUDE = "import sys; sys.path.insert(0, 'fraud/experiments/features/new_fields'); import nf_layout as L\n"


def test_root_is_project_root():
    assert nf_layout.ROOT == ROOT
    assert (nf_layout.ROOT / "fraud").is_dir()


SCORER = {nf_layout.REORGANIZED: "fraud/scripts/score_sequential_hier.py",
          nf_layout.FALLBACK: "waqas/v2/scripts/score_v2.py"}
ATTR_KEYS = ["scorer", "business_metrics", "trainer", "raw_join"]


def test_this_tree_resolves_in_its_own_layout():
    """The base tree is the fallback layout; the pod, where the package runs, is reorganized. Either way the first
    line names the layout found and the scorer comes from that layout."""
    layout, _ = nf_layout.detect()
    assert layout in SCORER
    r = subprocess.run([sys.executable, str(NF / "nf_layout.py")], cwd=ROOT, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    assert r.stdout.splitlines()[0] == f"layout: {layout}"
    assert SCORER[layout] in r.stdout


def test_this_tree_resolves_attributes():
    lay = nf_layout.resolve(ATTR_KEYS)
    assert lay.layout == nf_layout.detect()[0]
    assert nf_layout.check_attributes(ATTR_KEYS)
    assert callable(nf_layout.attr("business_metrics", "_alert"))


def test_split_keys_on_this_tree():
    """s3 and prediction_files are two modules each before the reorganization and one each after it (REORGANIZATION
    5.4); attr finds read_table either way."""
    lay = nf_layout.resolve(["s3", "prediction_files"])
    n = 2 if lay.layout == nf_layout.FALLBACK else 1
    for key in ("s3", "prediction_files"):
        mods = lay.modules[key]
        assert (len(mods) if isinstance(mods, list) else 1) == n, key
    assert callable(nf_layout.attr("prediction_files", "read_table"))


SPLIT = ("s = L.resolve(['s3', 'prediction_files']); "
         "print('split', *[len(m) if isinstance(m, list) else 1 for m in "
         "(s.modules['s3'], s.modules['prediction_files'])], callable(L.attr('prediction_files', 'read_table')))")


def test_stub_fallback_tree_is_the_fallback_layout(tmp_path):
    """The pre-reorganization layout on a synthetic tree, so the fallback stays tested on the reorganized pod."""
    root = _stub_tree(tmp_path, 1)
    r = _run(root, PRELUDE + "lay = L.resolve(); L.print_layout(lay); "
             f"print('attrs', L.check_attributes({ATTR_KEYS!r})); " + SPLIT)
    assert r.returncode == 0, r.stderr
    assert r.stdout.splitlines()[0] == "layout: pre-reorganization (fallback)"
    assert "waqas/v2/scripts/score_v2.py" in r.stdout
    assert "attrs True" in r.stdout and "split 2 2 True" in r.stdout


def test_stub_reorganized_tree_has_one_module_per_split_key(tmp_path):
    root = _stub_tree(tmp_path, 0)
    r = _run(root, PRELUDE + f"print('attrs', L.check_attributes({ATTR_KEYS!r})); " + SPLIT)
    assert r.returncode == 0, r.stderr
    assert "attrs True" in r.stdout and "split 1 1 True" in r.stdout


def test_bootstrap_is_idempotent():
    nf_layout.bootstrap()
    nf_layout.bootstrap()
    assert sys.path[0] == str(ROOT) and sys.path[1] == str(ROOT / "src")
    assert sys.path.count(str(ROOT)) == 1


def test_stub_reorganized_tree(tmp_path):
    root = _stub_tree(tmp_path, 0)
    r = _run(root, PRELUDE + "lay = L.resolve(); L.print_layout(lay); L.check_attributes(['scorer','trainer'])")
    assert r.returncode == 0, r.stderr
    assert r.stdout.splitlines()[0] == "layout: reorganized"
    assert "fraud/scripts/score_sequential_hier.py" in r.stdout


def test_stub_reorganized_with_old_leftovers_is_reorganized(tmp_path):
    root = _stub_tree(tmp_path, 0)
    _stub_tree(tmp_path, 1)  # same root: both layouts present
    r = _run(root, PRELUDE + "print(L.detect()[0])")
    assert r.stdout.strip() == "reorganized", r.stderr


def test_mixed_tree_stops_and_lists(tmp_path):
    keys = list(nf_layout.TABLE)
    root = _stub_tree(tmp_path, 0, keys=keys[:3])           # trainer, scorer, te_model reorganized only
    _stub_tree(tmp_path, 1, keys=["business_metrics", "groups"])  # these fallback only
    r = _run(root, PRELUDE + "L.resolve()")
    assert r.returncode == 4
    assert "MIXED" in r.stderr
    assert "reorganized only: trainer" in r.stderr
    assert "fallback only:    business_metrics" in r.stderr


def test_missing_attribute_named(tmp_path):
    root = _stub_tree(tmp_path, 0, drop_attr="def select")
    r = _run(root, PRELUDE + "L.attr('scorer', 'select')")
    assert r.returncode == 4
    assert "select" in r.stderr and "scorer" in r.stderr


def test_scorer_without_other_refused(tmp_path):
    root = _stub_tree(tmp_path, 0)
    p = root / "fraud" / "scripts" / "score_sequential_hier.py"
    p.write_text(p.read_text().replace("'SELECT', 'OTHER'", "'SELECT',"))
    r = _run(root, PRELUDE + "L.check_attributes(['scorer'])")
    assert r.returncode == 4 and "OTHER" in r.stderr


def test_requested_key_missing_refused(tmp_path):
    root = _stub_tree(tmp_path, 0, keys=["trainer", "scorer"])
    r = _run(root, PRELUDE + "L.resolve(['groups'])")
    assert r.returncode == 4 and "groups not found" in r.stderr


def test_module_outside_root_refused(tmp_path):
    root = _stub_tree(tmp_path, 0, keys=["trainer"])
    other = tmp_path / "elsewhere"
    _write_module(other, "fraud.scripts.train_sequential_hier", REO_ATTRS["fraud.scripts.train_sequential_hier"])
    code = ("import sys; sys.path.insert(0, %r)\n" % str(other)) + PRELUDE + \
        "L.bootstrap = lambda root=None: None\nL.resolve(['trainer'])"
    r = _run(root, code)
    assert r.returncode == 4 and "outside the project root" in r.stderr


def test_unknown_key_refused():
    with pytest.raises(SystemExit) as e:
        nf_layout.resolve(["no_such_key"])
    assert e.value.code == 4


def test_importing_does_no_work():
    r = subprocess.run([sys.executable, "-c", PRELUDE + "print(len(sys.modules.get('nf_layout').__dict__))"],
                       cwd=ROOT, capture_output=True, text=True)
    assert r.returncode == 0 and r.stdout.strip()
    assert "layout:" not in r.stdout
