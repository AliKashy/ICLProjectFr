"""The reviewers' decision D3b of 2 November in the recipe engine: dates and time intervals on a log scale, the
CURR/PREV pair, the month-level expiry, sentinels, count formats and a reason per row. The vectors are the
reviewers' (date_encoding_v2.py); synthetic data only."""
import importlib.util
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

_W = Path(__file__).resolve().parent / "new_fields_data_world.py"
_spec = importlib.util.spec_from_file_location("new_fields_data_world", _W)
world = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(world)
import nf_recipes as R  # noqa: E402

ENGINE = world.engine()
DAY = 86_400
T = pd.Timestamp("2025-03-10 14:30:00")


def build(df, recipe, name="x"):
    frame, stats = R.build_columns(df, [(name, recipe, "continuous")], "2024-10-01", engine=ENGINE)
    return frame[name].to_numpy(), stats[name]


def frame(n, **cols):
    return pd.DataFrame({world.ACCOUNT: [f"a{i}" for i in range(n)], world.TIME: [T] * n, world.TIE: range(n),
                         **cols})


def test_the_fifteen_event_vectors():
    d = ["2025-03-09 02:30:00", "2025-03-10 14:30:00", "2025-03-10 15:00:00", "2025-03-10 14:25:00", "2025-03-10",
         "2025-03-09", "1900-01-01", "1970-01-01", "1880-05-05", None, "1925-03-11", "1925-03-09", "1899-12-30",
         "1960-01-01", "2262-04-01"]
    v, st = build(frame(15, ev_dt=pd.Series(d, dtype=object)), "days_before(ev_dt)")
    want = [math.log1p(1.5 * DAY), None, None, math.log1p(300), None, math.log1p(DAY), None, None, None, None,
            math.log1p(36_524 * DAY), None, None, None, None]
    for i, e in enumerate(want):
        assert (np.isnan(v[i]) if e is None else v[i] == pytest.approx(e, abs=1e-12)), (i, v[i], e)
    assert st["parse"]["reasons"] == {"after_transaction": 1, "same_second": 1, "same_day": 1, "sentinel": 5,
                                      "implausible": 2, "missing": 1}
    # implausible values count as parse failures for the checks' parse stop
    assert st["parse"]["failed"] == 2 and st["parse"]["sentinel"] == 5


def test_the_reasons_and_the_signed_difference_ride_on_the_built_column():
    df = frame(3, ev_dt=pd.Series(["2025-03-09", "2025-03-10 20:00:00", None], dtype=object))
    ctx = R.FileContext(df, "2024-10-01", ENGINE[0])
    b = ctx.build(R.parse("days_before(ev_dt)"))
    assert list(b.reasons) == ["", "after_transaction", "missing"]
    assert b.signed[0] == 1.0 and b.signed[1] == pytest.approx(-(5.5 / 24)) and np.isnan(b.signed[2])


def test_the_five_pair_vectors():
    curr = ["2025-03-10 14:30:00", "2025-03-10 18:00:00", "2025-03-08 09:00:00", "2025-03-11 00:00:00", None]
    prev = ["2025-03-01 14:30:00", "2025-03-09 14:30:00", "2025-02-01 00:00:00", "2025-03-10 20:00:00", None]
    df = frame(5, cur_dt=pd.Series(curr, dtype=object), prv_dt=pd.Series(prev, dtype=object))
    v, st = build(df, "days_before(cur_dt; prev=prv_dt)")
    assert v[0] == pytest.approx(math.log1p(9 * DAY)) and v[1] == pytest.approx(math.log1p(DAY))
    assert v[2] == pytest.approx(math.log1p(2 * DAY + 5.5 * 3600)) and np.isnan(v[3]) and np.isnan(v[4])
    assert st["parse"]["reasons"] == {"after_transaction": 1, "missing": 1} and st["parse"]["prev_rows"] == 2
    assert st["parse"]["prev_not_earlier"] == 0 and st["parse"]["pair_both_present"] == 4
    assert "prv_dt" in R.parse("days_before(cur_dt; prev=prv_dt)").sources


def test_the_history_recency_is_ln_1_plus_whole_seconds():
    df = pd.DataFrame({world.ACCOUNT: ["a", "a"], world.TIME: [T - pd.Timedelta(seconds=300), T],
                       world.TIE: [1, 2]})
    v, st = build(df, "since_last(minutes)")
    assert np.isnan(v[0]) and v[1] == pytest.approx(math.log1p(300))
    assert st["interval_unit"] == "minutes" and st["interval_median"] == 5.0


def test_the_month_level_expiry_and_the_future_window():
    df = frame(3, exp_ym=pd.Series(["202503", "202504", "202502"], dtype=object))
    v, st = build(df, "days_until(exp_ym; format=%Y%m)")
    assert v[0] == pytest.approx(math.log1p(21)) and v[1] == pytest.approx(math.log1p(51))
    assert v[2] == pytest.approx(-math.log1p(10)) and "last day of the month" in st["parse"]["convention"]
    # a source whose values all fall on day 1 is read the same way
    v1, st1 = build(frame(2, exp_dt=pd.Series(["2025-03-01", "2025-04-01"], dtype=object)), "days_until(exp_dt)")
    assert v1[0] == pytest.approx(math.log1p(21)) and "every value on day 1" in st1["parse"]["convention"]
    days = (pd.Timestamp("2025-03-10") + pd.to_timedelta([3653, 3654, -3653, -3654, 0, 30], unit="D"))
    v2, st2 = build(frame(6, exp_dt=pd.Series(days.strftime("%Y-%m-%d"), dtype=object)), "days_until(exp_dt)")
    assert v2[0] == pytest.approx(math.log1p(3653)) and np.isnan(v2[1]) and v2[2] == pytest.approx(-math.log1p(3653))
    assert np.isnan(v2[3]) and v2[4] == 0.0 and v2[5] == pytest.approx(math.log1p(30))
    assert st2["parse"]["reasons"] == {"implausible": 2}


def test_count_formats_and_the_misread_count():
    d, rep, _ = R.parse_dates(pd.Series([0, 12_839, None, 12_839.5], dtype=object), "days_since:1990-01-01")
    assert d[0] == R.NAT and pd.Timestamp(d[1]).date() == pd.Timestamp("2025-02-25").date()
    assert rep["sentinel"] == 1 and rep["failed"] == 1
    d2, _, _ = R.parse_dates(pd.Series([23_797]), "days_since:1960-01-01")
    assert pd.Timestamp(d2[0]) == pd.Timestamp("2025-02-25")
    d3, _, _ = R.parse_dates(pd.Series([2_056_096_800]), "seconds_since:1960-01-01")
    assert pd.Timestamp(d3[0]) == pd.Timestamp("2025-02-25 10:00:00")
    # the same SAS datetime read as Unix seconds lands 3,653 days late
    d4, _, _ = R.parse_dates(pd.Series([2_056_096_800]))
    assert (pd.Timestamp(d4[0]).normalize() - pd.Timestamp("2025-02-25")).days == 3653
    # an expiry two years ahead, misread that way, falls outside the ten-year window
    v, st = build(frame(1, exp_dt=pd.Series([pd.Timestamp("2027-03-31") + pd.Timedelta(days=3653)])),
                  "days_until(exp_dt)")
    assert np.isnan(v[0]) and st["parse"]["reasons"] == {"implausible": 1}
    for bad in ("days_before(x_dt; format=days_since:notadate)", "days_before(x_dt; sentinel=junk)",
                "days_before(x_dt; tz_offset_hours=30)", "days_until(x_dt; prev=y_dt)",
                "days_before(x_dt; prev=x_dt)"):
        with pytest.raises(R.RecipeError):
            R.parse(bad)


def test_declared_sentinels_and_the_zone_offset():
    df = frame(3, ev_dt=pd.Series(["2001-01-01", "2025-03-09 19:30:00", "2025-03-09"], dtype=object))
    v, st = build(df, "days_before(ev_dt; sentinel=2001-01-01; tz_offset_hours=5)")
    assert np.isnan(v[0]) and st["parse"]["reasons"] == {"sentinel": 1}
    assert v[1] == pytest.approx(math.log1p(24 * 3600))       # 19:30 less 5 hours: one day before 14:30
    assert v[2] == pytest.approx(math.log1p(DAY))             # a date with no time part is not shifted


def test_the_definitions_text_states_the_encoding_and_the_missing_rules():
    d = R.parse("days_before(ev_dt)").describe()
    assert "ln(1 + whole seconds" in d["as_of_rule"] and "negative kept" not in d["as_of_rule"]
    assert "after the transaction" in d["as_of_rule"] and "sentinel" in d["missing_rule"]
    u = R.parse("days_until(exp_dt)").describe()["as_of_rule"]
    assert "sign(u) x ln(1 + |u|)" in u and "last day of its month" in u and "negative kept" not in u
    assert "ln(1 + whole seconds" in R.parse("since_last(minutes)").describe()["as_of_rule"]
    assert "ln(1 + whole seconds" in R.parse("since_first(days; same=m; within=30d)").describe()["as_of_rule"]
    assert "event-time assumption" in R.parse("prev(falcon_decision_xcd)").describe()["as_of_rule"]
    assert "with a person's keep row" in R.parse("days_before(ev_dt; same_day=keep)").describe()["as_of_rule"]
