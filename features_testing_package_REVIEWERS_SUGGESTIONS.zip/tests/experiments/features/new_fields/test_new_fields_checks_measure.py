"""Measurements against hand counts: missing by month and label, events, AP, overlap with month, PSI."""

import math

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score

from new_fields_checks_helpers import load

M = load("nf_checks_measure")


def _meta(acct, days, y):
    t = pd.Timestamp("2024-10-01") + pd.to_timedelta(days, unit="D")
    return pd.DataFrame({"acct": acct, "t": t, "y": y, "month": M.month_of(pd.Series(t))})


def test_missing_counts_by_month_and_label_match_hand_counts():
    meta = _meta(["a"] * 6, [0, 1, 31, 32, 33, 62], [0, 1, 0, 1, 0, 0])
    v = pd.Series([1.0, np.nan, np.nan, 2.0, np.nan, 3.0])
    cens = np.array([False, False, True, False, False, False])
    c = M.missing_counts(v, meta, cens)
    assert c["rows"] == 6 and c["missing"] == 2 and c["censored"] == 1
    assert c["by_month"]["2024-10"] == [2, 1, 0]
    assert c["by_month"]["2024-11"] == [3, 1, 1]
    assert c["by_month"]["2024-12"] == [1, 0, 0]
    assert c["by_label"]["fraud"] == [2, 1, 0]
    assert c["by_label"]["nonfraud"] == [4, 1, 1]
    pooled = M.add_missing(c, c)
    assert pooled["by_month"]["2024-11"] == [6, 2, 2]


def test_fill_jump_and_change_at_event_on_a_small_history():
    # account f turns fraud at its 3rd row; the field fills from that row on
    meta = _meta(["f"] * 5 + ["n"] * 5, [0, 1, 2, 3, 4] * 2, [0, 0, 1, 0, 0] + [0] * 5)
    v = pd.Series([np.nan, np.nan, 1.0, 1.0, 1.0] + [np.nan, 5.0, np.nan, 5.0, np.nan])
    ev = M.FileEvents(meta, seed=0)
    c = ev.stats(v)
    assert c["f_before_n"] == 2 and c["f_before_fill"] == 0
    assert c["f_after_n"] == 3 and c["f_after_fill"] == 3
    assert c["f_at_n"] == 1 and c["f_at_changed"] == 1
    m = M.event_measures(c)
    assert m["fill_jump_fraud"] == 100.0


def test_constant_within_account_counts_accounts_with_two_rows():
    meta = _meta(["a", "a", "b", "b", "c"], [0, 1, 0, 1, 0], [0, 0, 0, 0, 0])
    c = M.FileEvents(meta).stats(pd.Series(["x", "x", "x", "y", "z"]))
    assert c["acc_multi"] == 2 and c["acc_constant"] == 1


def test_ap_from_groups_equals_scikit_learn_with_ties():
    rng = np.random.default_rng(0)
    s = rng.integers(0, 5, 400).astype(float)
    y = (rng.random(400) < 0.1 + 0.05 * s).astype(int)
    u, inv = np.unique(s, return_inverse=True)
    n = np.bincount(inv)
    p = np.bincount(inv, weights=y)
    assert math.isclose(M.ap_from_groups(u, n, p), average_precision_score(y, s), rel_tol=1e-12)


def test_number_ap_takes_the_better_direction_and_missing_place():
    y = np.array([1, 1, 0, 0, 0, 0])
    v = pd.Series([-5.0, -4.0, 1.0, 2.0, 3.0, np.nan])
    counts = M.value_label_counts(M.number_keys(v), y)
    assert M.number_ap(counts) == 1.0


def test_code_ap_uses_smoothed_training_rates_and_overall_rate_for_unseen():
    train = {"a": [100, 50], "b": [100, 0]}
    val = {"a": [10, 5], "b": [10, 0], "zz": [10, 1]}
    ap = M.code_ap(train, val, weight=100.0)
    # ranking a > unseen (overall rate) > b
    assert math.isclose(ap, average_precision_score([1] * 5 + [0] * 5 + [1] + [0] * 9 + [0] * 10,
                                                    [3] * 10 + [2] * 10 + [1] * 10))


def test_nmi_and_cramers_v_match_a_hand_computation():
    m = np.array([[30, 10], [10, 30]], dtype=float)
    o = M.overlap_from_matrix(m)
    n = m.sum()
    exp = np.outer(m.sum(1), m.sum(0)) / n
    chi2 = ((m - exp) ** 2 / exp).sum()
    assert math.isclose(o["cramers_v"], math.sqrt(chi2 / n), rel_tol=1e-12)
    p = m / n
    mi = sum(p[i, j] * math.log(p[i, j] / (p[i].sum() * p[:, j].sum())) for i in range(2) for j in range(2))
    assert math.isclose(o["nmi"], mi / math.log(2), rel_tol=1e-12)


def test_overlap_is_one_for_a_copy_of_month_and_zero_for_independence():
    assert M.overlap_from_matrix(np.diag([10.0, 20.0, 30.0]))["cramers_v"] == 1.0
    assert M.overlap_from_matrix(np.ones((3, 4)))["nmi"] == 0.0


def test_psi_flags_a_planted_shift_and_not_a_copy():
    ref = {"d0": 500, "d1": 500, M.MISSING_KEY: 10}
    assert M.psi_counts(ref, dict(ref)) < 1e-9
    assert M.psi_counts(ref, {"d0": 900, "d1": 100, "new": 50}) > 0.25


def test_parse_dates_reads_the_stored_forms():
    assert M.parse_dates(pd.Series([20250102]))[0] == pd.Timestamp("2025-01-02")
    assert M.parse_dates(pd.Series([1735776000]))[0] == pd.Timestamp("2025-01-02")
    assert M.parse_dates(pd.Series([1735776000000]))[0] == pd.Timestamp("2025-01-02")
    assert M.parse_dates(pd.Series(["2025-01-02"]))[0] == pd.Timestamp("2025-01-02")


def test_same_day_counts_compare_frauds_with_non_frauds():
    meta = _meta(["a"] * 4, [0, 1, 2, 3], [0, 0, 1, 0])
    src = pd.Series(pd.to_datetime(["2024-09-01", "2024-09-01", "2024-10-03", "2024-09-01"]))
    c = M.same_day_counts(src, meta, M.FileEvents(meta))
    assert c["sd_fraud"] == 1 and c["sd_fraud_n"] == 1 and c["sd_nonfraud"] == 0
    assert c["sd_f_event"] == 1


def test_calendar_shape():
    c = M.number_counts(pd.Series([1.0, 2, 3, 4, 5, 6, 7, 8, 12]))
    assert M.calendar_shape(c, 6) == "month"
    assert M.calendar_shape(M.number_counts(pd.Series([1.0, 2, 3])), 6) is None
    assert M.calendar_shape(M.number_counts(pd.Series([202410.0, 202501])), 6) == "yyyymm"
    assert M.calendar_shape(M.number_counts(pd.Series([20241001.0, 20250131])), 6) == "yyyymmdd"


def test_pre_event_rates_cannot_memorise_account_constant_noise():
    rng = np.random.default_rng(1)
    n_acct, rows = 6000, 6
    acct = np.repeat([f"a{i}" for i in range(n_acct)], rows)
    days = np.tile(np.arange(rows), n_acct)
    fraud_acct = rng.random(n_acct) < 0.03
    y = np.zeros(n_acct * rows, dtype=int)
    y[np.repeat(fraud_acct, rows) & (days == rows - 1)] = 1
    code = pd.Series(np.repeat(rng.integers(0, 2000, n_acct).astype(str), rows))   # independent of fraud
    ev = M.FileEvents(_meta(acct, days, y), seed=0)
    c = ev.stats(code, keys=M.code_keys(code))
    ap = np.mean([M.code_ap(c["pre_counts_a"], c["pre_counts_b"]), M.code_ap(c["pre_counts_b"], c["pre_counts_a"])])
    base = sum(v[1] for v in c["pre_counts_a"].values()) / sum(v[0] for v in c["pre_counts_a"].values())
    assert ap < 3 * base


def test_same_day_ignores_a_timed_source_earlier_the_same_day():
    meta = _meta(["a"] * 3, [0, 1, 2], [0, 0, 1])
    t = pd.to_datetime(meta["t"]) + pd.Timedelta(12, unit="h")
    meta["t"] = t
    src = pd.Series(t - pd.Timedelta(2, unit="h"))          # a login two hours before, with a time part
    c = M.same_day_counts(src, meta, M.FileEvents(meta))
    assert c["sd_fraud"] == 0
