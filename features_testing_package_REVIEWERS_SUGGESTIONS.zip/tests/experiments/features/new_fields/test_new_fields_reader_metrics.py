"""The reader's engine against the reference outsort_metrics (loaded by path), scikit-learn and the project's
_alert at 6 per mille: ties, tied boundary rows, small N, integer weights, and the account bootstrap."""
from __future__ import annotations

from fractions import Fraction
import importlib.util
from pathlib import Path

import numpy as np
import pytest
from sklearn.metrics import average_precision_score, roc_auc_score

from new_fields_reader_world import load

HERE = Path(__file__).resolve().parent
R = load("nf_ranked")


def _reference():
    spec = importlib.util.spec_from_file_location("nf_test_outsort_reference", HERE / "new_fields_reader_outsort_copy.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


REF = _reference()


def _case(n, seed, decimals=None, tie_all=False, accounts=None, fraud=0.1):
    rng = np.random.default_rng(seed)
    y = (rng.random(n) < fraud).astype(np.int64)
    s = rng.random(n) + 0.3 * y
    if decimals is not None:
        s = np.round(s, decimals)
    if tie_all:
        s = np.full(n, 0.5)
    acct = np.asarray([f"a{int(v):04d}" for v in rng.integers(0, accounts or max(1, n // 3), n)])
    ids = np.asarray([str(10_000 + i) for i in rng.permutation(n)])
    amt = np.round(rng.gamma(2.0, 30.0, n), 2)
    return y, s, acct, ids, amt


def _engine(y, s, acct, ids, amt=None, share=R.SHARE_06):
    keys = R.identity_keys(acct, ids)
    codes, units = R.account_units(acct)
    return R.RankedScore(s, y, codes, R.key_ranks(keys), amt, share), keys, codes, units


def _cut(ref, y, s, keys, amt, pct, weights=None):
    report = REF.outsort_metrics(y, s, amounts=amt, row_keys=keys, percents=(pct,), weights=weights)
    return report["cuts"][0]


def _eq(a, b):
    if a is None or (isinstance(a, float) and np.isnan(a)):
        return b is None or (isinstance(b, float) and np.isnan(b))
    return np.isclose(a, b, rtol=1e-12, atol=1e-15)


CASES = [dict(n=5000, seed=1), dict(n=5000, seed=2, decimals=2), dict(n=3000, seed=3, decimals=1),
         dict(n=800, seed=4, tie_all=True), dict(n=1, seed=5, fraud=1.0), dict(n=7, seed=6), dict(n=166, seed=7),
         dict(n=167, seed=8, decimals=1), dict(n=334, seed=9, decimals=0), dict(n=2000, seed=10, accounts=3)]


@pytest.mark.parametrize("case", CASES)
@pytest.mark.parametrize("pct", ["0.6", "1", "5"])
def test_outsort_equals_reference_at_the_point(case, pct):
    y, s, acct, ids, amt = _case(**case)
    eng, keys, _, _ = _engine(y, s, acct, ids, amt, share=Fraction(pct) / 100)
    got = eng.evaluate(None)
    ref = _cut(REF, y, s, keys, amt, pct)
    share = Fraction(pct) / 100
    assert got["outsorted"] == ref["outsorted"] == len(y) * share.numerator // share.denominator
    assert got["frauds_outsorted"] == ref["frauds_outsorted"]
    assert _eq(got["udr"], ref["udr"]) and _eq(got["fpr"], ref["fpr"]) and _eq(got["vdr"], ref["vdr"])


@pytest.mark.parametrize("case", CASES)
def test_outsort_equals_reference_under_bootstrap_weights(case):
    y, s, acct, ids, amt = _case(**case)
    eng, keys, codes, units = _engine(y, s, acct, ids, amt)
    for mult in R.multiplicity_draws(len(units), 15, 99):
        w = mult[codes]
        got, ref = eng.evaluate(mult), _cut(REF, y, s, keys, amt, "0.6", weights=w)
        assert got["outsorted"] == ref["outsorted"] and got["frauds_outsorted"] == ref["frauds_outsorted"]
        assert _eq(got["udr"], ref["udr"]) and _eq(got["fpr"], ref["fpr"]) and _eq(got["vdr"], ref["vdr"])


def test_outsort_count_is_floor_n_times_3_over_500():
    for n in (1, 166, 167, 333, 334, 500, 1000, 1234567):
        assert n * R.SHARE_06.numerator // R.SHARE_06.denominator == (n * 6) // 1000


def test_ties_broken_by_ascending_identity_key_not_by_input_order():
    # Every score equal: the outsort is the rows with the smallest keys, whatever their input order.
    n = 1000
    y = np.zeros(n, dtype=np.int64)
    acct = np.asarray([f"a{i:04d}" for i in range(n)])
    ids = np.asarray([str(i) for i in range(n)])
    y[:6] = 1  # the six smallest keys are frauds: all caught
    perm = np.random.default_rng(0).permutation(n)
    eng, _, _, _ = _engine(y[perm], np.full(n, 0.2), acct[perm], ids[perm])
    got = eng.evaluate(None)
    assert got["outsorted"] == 6 and got["frauds_outsorted"] == 6 and got["udr"] == 1.0 and got["fpr"] == 0.0


def test_negative_or_missing_amount_gives_null_vdr_with_reason():
    y, s, acct, ids, amt = _case(400, 3)
    amt[5] = -1.0
    eng, _, _, _ = _engine(y, s, acct, ids, amt)
    assert np.isnan(eng.evaluate(None)["vdr"]) and "negative" in eng.amount_reason
    amt[5] = np.nan
    eng, _, _, _ = _engine(y, s, acct, ids, amt)
    assert np.isnan(eng.evaluate(None)["vdr"]) and "missing" in eng.amount_reason


@pytest.mark.parametrize("decimals", [None, 2, 1])
def test_ap_auroc_equal_sklearn_with_and_without_weights(decimals):
    y, s, acct, ids, amt = _case(4000, 11, decimals=decimals)
    eng, _, codes, units = _engine(y, s, acct, ids, amt)
    got = eng.evaluate(None)
    assert np.isclose(got["ap"], average_precision_score(y, s), rtol=1e-12)
    assert np.isclose(got["auroc"], roc_auc_score(y, s), rtol=1e-12)
    for mult in R.multiplicity_draws(len(units), 5, 3):
        w = mult[codes]
        got = eng.evaluate(mult)
        assert np.isclose(got["ap"], average_precision_score(y, s, sample_weight=w), rtol=1e-10)
        assert np.isclose(got["auroc"], roc_auc_score(y, s, sample_weight=w), rtol=1e-10)


def test_ap_defined_when_the_top_account_is_drawn_zero_times():
    y, s, acct, ids, amt = _case(800, 17, decimals=2)
    eng, _, codes, units = _engine(y, s, acct, ids, amt)
    top = codes[np.argmax(s)]
    mult = np.ones(len(units), dtype=np.int64)
    mult[top] = 0
    w = mult[codes]
    got = eng.evaluate(mult)
    assert np.isfinite(got["ap"])
    assert np.isclose(got["ap"], average_precision_score(y, s, sample_weight=w), rtol=1e-10)
    assert np.isclose(got["auroc"], roc_auc_score(y, s, sample_weight=w), rtol=1e-10)


def test_ks_read_only_after_a_whole_tied_group():
    y, s, acct, ids, _ = _case(3000, 12, decimals=1)
    eng, _, _, _ = _engine(y, s, acct, ids)
    order = np.lexsort((np.arange(len(s)), -s))
    sy, ss = y[order], s[order]
    ends = np.r_[ss[1:] != ss[:-1], True]
    tpr, fpr = np.cumsum(sy) / y.sum(), np.cumsum(1 - sy) / (len(y) - y.sum())
    assert np.isclose(eng.evaluate(None)["ks"], np.abs(tpr[ends] - fpr[ends]).max(), rtol=1e-12)


def test_engine_equals_project_alert_at_6_per_mille():
    L = load("nf_layout")
    alert, ranking = L.attr("business_metrics", "_alert"), L.attr("business_metrics", "_ranking")
    for case in CASES:
        y, s, acct, ids, amt = _case(**case)
        eng, keys, codes, units = _engine(y, s, acct, ids, amt)
        order, _ = ranking(s, R.compact_keys(R.key_ranks(keys)))
        for mult in [None] + list(R.multiplicity_draws(len(units), 5, 1)):
            a = alert(y, amt, None, order, 6, None if mult is None else mult[codes])
            e = eng.evaluate(mult)
            assert a["alerts"] == e["outsorted"] and a["true_frauds_caught"] == e["frauds_outsorted"]
            assert _eq(a["detection_rate"], e["udr"])
            assert _eq(a["value_detection_rate"], e["vdr"])


def test_compact_keys_sort_as_the_identity_keys():
    _, _, acct, ids, _ = _case(500, 13)
    keys = R.identity_keys(acct, ids)
    compact = R.compact_keys(R.key_ranks(keys))
    assert list(np.argsort(compact, kind="stable")) == list(np.argsort(keys.astype(str), kind="stable"))


def test_duplicate_identity_keys_refused():
    with pytest.raises(ValueError):
        R.key_ranks(R.identity_keys(["a", "a"], ["1", "1"]))


# ------------------------------------------------------------------ the account bootstrap

def test_draws_reproducible_from_the_seed_and_streaming_equals_matrix():
    a = R.draw_matrix(50, 30, 20261102)
    b = np.vstack(list(R.multiplicity_draws(50, 30, 20261102)))
    assert np.array_equal(a, b)
    assert not np.array_equal(a, R.draw_matrix(50, 30, 1))
    assert (a.sum(axis=1) == 50).all()
    rng = np.random.default_rng(20261102)
    assert np.array_equal(a[0], np.bincount(rng.integers(0, 50, 50), minlength=50))


def test_units_are_accounts_in_ascending_string_order():
    codes, units = R.account_units(np.asarray(["b", "a", "c", "a", "10", "9"]))
    assert list(units) == ["10", "9", "a", "b", "c"]
    assert list(codes) == [3, 2, 4, 2, 0, 1]


def test_every_row_of_an_account_gets_the_account_count():
    y, s, acct, ids, amt = _case(600, 14, accounts=40)
    eng, keys, codes, units = _engine(y, s, acct, ids, amt)
    mult = next(R.multiplicity_draws(len(units), 1, 5))
    # A replicated data set (each row copied its account's count times) gives the same AP as the weights.
    rep = np.repeat(np.arange(len(y)), mult[codes])
    assert np.isclose(eng.evaluate(mult)["ap"], average_precision_score(y[rep], s[rep]), rtol=1e-10)
    by_acct = {}
    for a, c in zip(acct, mult[codes]):
        by_acct.setdefault(a, set()).add(int(c))
    assert all(len(v) == 1 for v in by_acct.values())


def test_the_same_draws_serve_every_fit_and_row_order_does_not_matter():
    y, s, acct, ids, amt = _case(2000, 15)
    s2 = s + 0.05 * np.random.default_rng(1).normal(size=len(s))
    cand, _, codes, units = _engine(y, s2, acct, ids, amt)
    ctrl, _, _, _ = _engine(y, s, acct, ids, amt)
    res = R.paired([cand], [ctrl], len(units), 40, 7, keep_draws=40)
    # Each fit evaluated alone on the draw matrix gives the same per-draw gains.
    mats = R.draw_matrix(len(units), 40, 7)
    alone = np.asarray([cand.evaluate(m)["udr"] - ctrl.evaluate(m)["udr"] for m in mats])
    assert np.allclose(res["gain_draws"][0], alone, equal_nan=True)
    assert all(np.array_equal(a, b) for a, b in zip(res["first_draws"], mats))
    # The same rows in another order: the same accounts in every draw, so the same numbers.
    perm = np.random.default_rng(2).permutation(len(y))
    cand_p, _, _, units_p = _engine(y[perm], s2[perm], acct[perm], ids[perm], amt[perm])
    ctrl_p, _, _, _ = _engine(y[perm], s[perm], acct[perm], ids[perm], amt[perm])
    res_p = R.paired([cand_p], [ctrl_p], len(units_p), 40, 7)
    assert np.allclose(res_p["gain_draws"], res["gain_draws"], equal_nan=True)


def test_paired_three_seeds_gain_is_the_mean_of_the_differences():
    y, s, acct, ids, amt = _case(1500, 16)
    rng = np.random.default_rng(3)
    cands = [_engine(y, s + 0.1 * rng.normal(size=len(s)), acct, ids, amt)[0] for _ in range(3)]
    ctrls = [_engine(y, s + 0.1 * rng.normal(size=len(s)), acct, ids, amt)[0] for _ in range(3)]
    n_units = len(R.account_units(acct)[1])
    res = R.paired(cands, ctrls, n_units, 30, 3)
    d = [c.evaluate(None)["udr"] - k.evaluate(None)["udr"] for c, k in zip(cands, ctrls)]
    assert np.isclose(res["metrics"]["udr"]["gain"], np.mean(d))
    mats = R.draw_matrix(n_units, 30, 3)
    g_b = [np.mean([c.evaluate(m)["udr"] - k.evaluate(m)["udr"] for c, k in zip(cands, ctrls)]) for m in mats]
    assert np.isclose(res["metrics"]["udr"]["sd"], np.std(g_b, ddof=1))
    assert np.isclose(res["metrics"]["udr"]["lo"], np.percentile(g_b, 5))
    assert np.isclose(res["metrics"]["udr"]["hi"], np.percentile(g_b, 95))


def test_convenience_functions_equal_the_engine_and_the_reference():
    y, s, acct, ids, amt = _case(3000, 21, decimals=2)
    got = R.outsort(y, s, acct, ids, amt, per_mille=6)
    ref = _cut(REF, y, s, R.identity_keys(acct, ids), amt, "0.6")
    assert got["frauds_outsorted"] == ref["frauds_outsorted"] and _eq(got["udr"], ref["udr"])
    assert _eq(got["vdr"], ref["vdr"]) and _eq(got["fpr"], ref["fpr"])
    assert np.isclose(R.average_precision(y, s), average_precision_score(y, s), rtol=1e-12)
    s2 = s + 0.1 * np.random.default_rng(4).normal(size=len(s))
    out = R.paired_bootstrap([s, s2], y, acct, ids, amt, draws=20, seed=5)
    eng, _, codes, units = _engine(y, s2, acct, ids, amt)
    mats = R.draw_matrix(len(units), 20, 5)
    u = out["metrics"].index("udr")
    assert np.allclose(out["draws"][1, u], [eng.evaluate(m)["udr"] for m in mats], equal_nan=True)
    w = mats[3][codes]
    assert np.isclose(R.average_precision(y, s, w), average_precision_score(y, s, sample_weight=w), rtol=1e-10)
