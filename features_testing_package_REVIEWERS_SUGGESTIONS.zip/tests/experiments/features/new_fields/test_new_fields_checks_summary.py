"""The per-feature summary: draft verdicts, the screen join, the decisions table and its proposer."""

import shutil

import pandas as pd
import pytest

from new_fields_checks_helpers import dry_world, load

FS = load("nf_feature_summary")
COLS = ["name", "group", "verdict", "reason", "evidence", "decided_by", "date", "definition_version"]


@pytest.fixture()
def checks(tmp_path):
    out = tmp_path / "checks"
    shutil.copytree(dry_world()["out"], out)
    return out


def _rank(tmp_path):
    p = tmp_path / "feature_rank.csv"
    pd.DataFrame([{"feature": "syn_clean_num", "shap_mean_abs": 0.5, "perm_ap_drop": 0.010, "kind": "feature"},
                  {"feature": "syn_vaa", "shap_mean_abs": 0.9, "perm_ap_drop": 0.020, "kind": "feature"},
                  {"feature": "C001", "shap_mean_abs": 0.3, "perm_ap_drop": 0.010, "kind": "cluster"}]).to_csv(
        p, index=False)
    return p


def test_template_has_the_decisions_columns():
    # the workbook lane owns the table and ships its proposed rows; the header is the LANES.md column list
    head = (FS.HERE / "KEEP_DECISIONS.csv").read_text().strip().split("\n")
    assert head[0] == ",".join(COLS)


def test_draft_verdicts_follow_the_checks(checks):
    df = FS.build(checks, None, None).set_index("feature")
    assert df.loc["syn_clean_num", "draft_verdict"] == "keep"
    assert df.loc["syn_vaa", "draft_verdict"] == "review"
    assert df.loc["syn_hold", "draft_verdict"] == "hold"
    assert df.loc["syn_date_after", "draft_verdict"] == "drop"
    assert df.loc["syn_le_recode", "draft_reason"] == "kept once as syn_clean_code"
    assert (df["status"] == "unresolved").all()


def test_the_screen_rank_is_joined_by_column_meaning(checks, tmp_path):
    df = FS.build(checks, _rank(tmp_path), None).set_index("feature")
    assert df.loc["syn_vaa", "shap_rank"] == 1 and df.loc["syn_clean_num", "shap_rank"] == 2
    assert "C001" not in df.index
    assert "screen:shap rank 1" in df.loc["syn_vaa", "evidence"]


def test_only_a_person_decision_is_final_and_the_latest_counts(checks, tmp_path):
    p = tmp_path / "KEEP_DECISIONS.csv"
    pd.DataFrame([["syn_vaa", "v22b", "keep", "first", "", "owner", "2026-11-01", "1"],
                  ["syn_vaa", "v22b", "hold", "ask Sumegha", "", "owner", "2026-11-02", "1"],
                  ["syn_clean_num", "v22b", "keep", "tool", "", "proposed", "2026-11-02", "1"]],
                 columns=COLS).to_csv(p, index=False)
    df = FS.build(checks, None, p).set_index("feature")
    assert df.loc["syn_vaa", "decision"] == "hold" and df.loc["syn_vaa", "decision_rows"] == 2
    assert df.loc["syn_clean_num", "status"] == "unresolved"


def test_a_bad_verdict_is_refused(checks, tmp_path):
    p = tmp_path / "KEEP_DECISIONS.csv"
    pd.DataFrame([["syn_vaa", "v22b", "maybe", "", "", "owner", "2026-11-02", "1"]], columns=COLS).to_csv(p, index=False)
    with pytest.raises(FS.BadDecisions):
        FS.build(checks, None, p)


def test_proposer_adds_rows_only_for_names_without_a_row(checks, tmp_path):
    p = tmp_path / "KEEP_DECISIONS.csv"
    pd.DataFrame([["syn_vaa", "v22b", "hold", "ask", "", "owner", "2026-11-02", "1"]], columns=COLS).to_csv(
        p, index=False)
    before = p.read_text()
    df = FS.build(checks, None, p)
    prop = FS.proposals(df, "2026-11-02")
    assert "syn_vaa" not in set(prop["name"])
    assert set(prop["decided_by"]) == {"proposed"}
    assert prop.set_index("name").loc["syn_clean_num", "verdict"] == "keep"
    assert prop.set_index("name").loc["syn_near_dup", "verdict"] == "unresolved"  # review becomes unresolved
    n = FS.append_proposals(p, prop)
    after = pd.read_csv(p, dtype=str, keep_default_na=False)
    assert p.read_text().startswith(before)                   # no existing row changed
    assert n == len(prop) and len(after) == 1 + len(prop)
    assert FS.append_proposals(p, prop) == 0                  # never twice


def test_pages_fit_one_screen_each(checks):
    df = FS.build(checks, None, None)
    big = pd.concat([df] * 6, ignore_index=True)
    big["feature"] = [f"{f}_{i}" for i, f in enumerate(big["feature"])]
    pages = FS.pages(big, "test")
    assert len(pages) > 1
    for pg in pages:
        lines = pg.split("\n")
        assert len(lines) <= 40 and max(len(x) for x in lines) <= 90


def test_main_writes_the_summary_and_proposals(checks, tmp_path, capsys):
    rc = FS.main(["--checks", str(checks), "--decisions", str(tmp_path / "none.csv"), "--propose", "--page", "1"])
    assert rc == 0
    assert (checks / "feature_summary.csv").exists() and (checks / "KEEP_DECISIONS_proposed.csv").exists()
    out = capsys.readouterr().out.rstrip("\n").split("\n")
    assert out[0].startswith("FEATURE SUMMARY") and len(out) <= 40


def test_long_twin_names_stay_distinct_on_the_page():
    a = FS._short("cprsrvc__dbt_prov_datacapture_device_type_and_more_text", 44)
    b = FS._short("cprsrvc__dbt_prov_datacapture_token_type_and_more_text_x", 44)
    assert a != b and len(a) == 44
