# An unchanged copy of the analysis module business_metrics.py (outsort_metrics), loaded by path by the
# reader tests as the reference for UDR, VDR and FPR. Do not edit: the tests compare the reader against it.
"""Aggregate descriptive fraud metrics; no alert level is a deployment policy.

Amounts and amount bands are optional. Bands must come from an explicitly
training-fitted artifact; this reader never estimates them on evaluated rows.

The bank's outsort metrics (UDR, VDR and the bank's FPR at a top share of
transactions, by default 0.6%, 1% and 5%) are in ``outsort_metrics``. They are
separate from the alert grid and appear in ``business_report`` only when a
caller passes ``outsort_percents``; without it every output is unchanged.
"""
from __future__ import annotations

import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

DEPTH_BANDS = (("depth_0", 0, 1), ("depth_1_4", 1, 5), ("depth_5_9", 5, 10),
               ("depth_10_19", 10, 20), ("depth_20_plus", 20, None))
ALERT_PER_MILLE = (1, 5, 10, 20, 50)
QUINTILES = (.2, .4, .6, .8)
POLICY_NOTE = "The bank has not set an alert level; this grid is descriptive, not an operating policy."
OUTSORT_PERCENTS = ("0.6", "1", "5")
OUTSORT_DEFINITIONS = {
    "outsorted": "floor(transactions x share) with exact rational arithmetic: the top rows by descending score, ties "
                 "broken by the ascending identity key when one is supplied (label independent), as in the alert grid",
    "udr": "unit detection rate: frauds in the outsort / all frauds",
    "vdr": "value detection rate: fraud amount in the outsort / all fraud amount",
    "fpr": "the bank's false-positive ratio: non-frauds in the outsort / frauds in the outsort (false positives per "
           "true positive). It is not the alert grid's false_positive_rate (non-frauds alerted / all non-frauds)",
}
OUTSORT_UNCONFIRMED = ("Not yet confirmed with the bank: how its outsort treats rows tied at the boundary score, which "
                       "amount (column, sign, currency) its VDR uses, which transactions are eligible (for example "
                       "advice rows, declines, channels), the period the share is taken over (here the whole evaluated "
                       "population, not each day), and whether UDR counts fraud transactions (as here) or fraud "
                       "cases or accounts. These numbers follow the definitions given here.")


def unavailable(reason):
    return {"status": "not_available", "reason": reason}


def _vector(values, n, name, dtype=None):
    result = np.asarray(values, dtype=dtype)
    if result.ndim != 1 or len(result) != n:
        raise ValueError(f"{name} must have one value per evaluated row")
    return result


def fit_amount_bins(amounts, *, population, source_sha256=None):
    """Fit four linear quantiles on TRAIN/DS_TRAIN only; retain duplicate edges."""
    if population not in ("TRAIN", "DS_TRAIN"):
        raise ValueError("Amount bands must be fitted on TRAIN or DS_TRAIN, never evaluation rows")
    values = np.asarray(amounts, dtype=float)
    if values.ndim != 1 or not len(values) or not np.isfinite(values).all():
        raise ValueError("Training amounts must be nonempty and finite")
    return {"schema_version": 1, "fitted_population": population, "rows": len(values),
            "quantile_probabilities": list(QUINTILES), "quantile_method": "linear",
            "edges": np.quantile(values, QUINTILES, method="linear").tolist(),
            "training_amounts_sha256": hashlib.sha256(np.sort(values).astype("<f8").tobytes()).hexdigest(),
            "source_sha256": source_sha256,
            "boundary_rule": "right-closed bands; duplicate edges produce empty bands; tails are unbounded"}


def validate_amount_bins(artifact):
    if (not isinstance(artifact, dict) or artifact.get("schema_version") != 1
            or artifact.get("fitted_population") not in ("TRAIN", "DS_TRAIN")
            or artifact.get("quantile_probabilities") != list(QUINTILES)
            or artifact.get("quantile_method") != "linear"
            or not isinstance(artifact.get("rows"), int) or artifact["rows"] < 1):
        raise ValueError("Need a versioned TRAIN/DS_TRAIN amount-quintile artifact")
    edges = np.asarray(artifact.get("edges"), dtype=float)
    if edges.shape != (4,) or not np.isfinite(edges).all() or (np.diff(edges) < 0).any():
        raise ValueError("Amount-quintile edges must be four ordered finite values")
    return edges


def _ratio(num, den, name, reason, undefined):
    if den == 0:
        undefined[name] = reason
        return None
    return float(num / den)


def _amounts(values, n):
    if values is None:
        return None, "amount metadata not supplied"
    result = _vector(values, n, "amounts", float)
    if not np.isfinite(result).all():
        return None, "amount metadata contains missing or nonfinite values"
    if (result < 0).any():
        return result, "negative amounts require an explicit value convention; none was assumed"
    if not np.isfinite(result.sum()):
        return None, "total amount is not finite"
    return result, None


def _ranking(scores, row_keys):
    if row_keys is None:
        return np.argsort(-scores, kind="stable"), "descending score; equal scores retain supplied input order"
    keys = _vector(row_keys, len(scores), "row_keys")
    if pd.isna(keys).any():
        raise ValueError("Tie keys must be nonnull")
    keys = np.asarray([str(v) for v in keys])
    if len(np.unique(keys)) != len(keys):
        raise ValueError("Tie keys must uniquely identify evaluated rows")
    return np.lexsort((keys, -scores)), "descending score, then ascending supplied identity key; independent of labels"


def _ks(y, scores, order):
    if not len(y) or y.sum() == 0 or y.sum() == len(y):
        return None
    sorted_y = y[order]
    # Evaluate only after a whole tied-score group, as a score-threshold KS requires.
    ends = np.r_[scores[order][1:] != scores[order][:-1], True]
    tpr = np.cumsum(sorted_y) / y.sum()
    fpr = np.cumsum(1 - sorted_y) / (len(y) - y.sum())
    return float(np.abs(tpr[ends] - fpr[ends]).max())


def _alert(y, amounts, amount_reason, order, per_mille, weights=None):
    weights = np.ones(len(y), dtype=np.int64) if weights is None else weights
    total = int(weights.sum())
    count = total * per_mille // 1000
    # Account multiplicities replicate transactions, including partial inclusion
    # of the boundary transaction's identical copies. No label enters ordering.
    ranked_weights = weights[order]
    selected_weights = np.minimum(ranked_weights, np.maximum(0, count - (np.cumsum(ranked_weights) - ranked_weights)))
    tp = int(np.dot(selected_weights, y[order]))
    positives = int(np.dot(weights, y))
    negatives = total - positives
    fp = count - tp
    undefined = {}
    result = {"alert_fraction": per_mille / 1000, "alerts": count,
              "actual_alert_fraction": _ratio(count, total, "actual_alert_fraction", "no transactions", undefined),
              "true_frauds_caught": tp, "false_positives": fp,
              "detection_rate": _ratio(tp, positives, "detection_rate", "no fraud targets", undefined),
              "false_positive_rate": _ratio(fp, negatives, "false_positive_rate", "no nonfraud targets", undefined),
              "precision": _ratio(tp, count, "precision", "no alerts at this integer budget", undefined)}
    if amounts is None or amount_reason is not None:
        result.update(fraud_amount=None, fraud_amount_caught=None, value_detection_rate=None)
        undefined["value_detection_rate"] = amount_reason
    else:
        values = amounts * y
        den = float(np.dot(weights, values))
        num = float(np.dot(selected_weights, values[order]))
        result.update(fraud_amount=den, fraud_amount_caught=num,
                      value_detection_rate=_ratio(num, den, "value_detection_rate", "zero total fraud amount", undefined))
    result["undefined"] = undefined
    return result


def _calibration(y, scores, score_is_probability):
    if not score_is_probability:
        return unavailable("score probability semantics not declared; values in [0,1] alone do not establish probabilities")
    if not len(y):
        return unavailable("no transactions")
    if ((scores < 0) | (scores > 1)).any():
        return unavailable("scores are not probabilities in [0,1]; no score rescaling was assumed")
    edges = np.quantile(scores, np.arange(1, 10) / 10, method="linear")
    membership = np.searchsorted(edges, scores, side="left")
    bins, ece = [], 0.
    for i in range(10):
        mask = membership == i
        count = int(mask.sum())
        mean = float(scores[mask].mean()) if count else None
        observed = float(y[mask].mean()) if count else None
        bins.append({"bin": i + 1, "count": count, "mean_score": mean, "observed_rate": observed})
        if count:
            ece += count / len(y) * abs(mean - observed)
    return {"status": "available", "bins": bins, "expected_calibration_error": float(ece),
            "quantile_edges": edges.tolist(),
            "bin_rule": "10 right-closed linear score-quantile bins; equal scores stay together; empty bins retained"}


def _summary(y, scores, amounts, amount_reason, row_keys, score_is_probability):
    order, _ = _ranking(scores, row_keys)
    ks = _ks(y, scores, order)
    return {"rows": len(y), "frauds": int(y.sum()), "nonfrauds": int(len(y) - y.sum()),
            "ks": ks, "ks_undefined_reason": "both target classes are required" if ks is None else None,
            "alert_grid": [_alert(y, amounts, amount_reason, order, rate) for rate in ALERT_PER_MILLE],
            "calibration": _calibration(y, scores, score_is_probability)}


def outsort_share(percent):
    """The exact share for an outsort percent given as text or a number: "0.6" (or 0.6) gives 3/500."""
    if isinstance(percent, (bool, np.bool_)):
        raise ValueError("Outsort percents must be numbers, not booleans")
    try:
        share = Fraction(str(percent).strip()) / 100
    except (ValueError, ZeroDivisionError) as error:
        raise ValueError(f"Outsort percent {percent!r} is not a finite number") from error
    if not 0 < share <= 1:
        raise ValueError(f"Outsort percent {percent!r} must be above 0 and at most 100")
    return share


def outsort_shares(percents):
    """Distinct exact shares, in the order given."""
    if isinstance(percents, (str, bytes)) or not len(percents):
        raise ValueError("Give at least one outsort percent, as a list")
    shares = [outsort_share(p) for p in percents]
    if len(set(shares)) != len(shares):
        raise ValueError("Outsort percents must be distinct")
    return shares


def _outsort_cut(y, scores, fraud_values, value_reason, order, share, weights=None):
    """One outsort: the top share of transactions by the ranking ``order``.

    ``weights`` are integer row multiplicities (an account bootstrap draw); the boundary row's identical copies are
    included only up to the integer budget, exactly as in ``_alert``. No label enters the ranking.
    """
    weights = np.ones(len(y), dtype=np.int64) if weights is None else weights
    total = int(weights.sum())
    count = total * share.numerator // share.denominator
    ranked = weights[order]
    selected = np.minimum(ranked, np.maximum(0, count - (np.cumsum(ranked) - ranked)))
    tp = int(np.dot(selected, y[order]))
    frauds = int(np.dot(weights, y))
    fp = count - tp
    undefined = {}
    result = {"outsort_percent": float(share * 100), "outsort_share": float(share),
              "outsort_share_exact": f"{share.numerator}/{share.denominator}",
              "transactions": total, "outsorted": count, "frauds": frauds, "frauds_outsorted": tp,
              "false_positives": fp,
              "udr": _ratio(tp, frauds, "udr", "no fraud targets", undefined),
              "fpr": _ratio(fp, tp, "fpr", "no frauds in the outsort", undefined)}
    if fraud_values is None:
        result.update(fraud_amount=None, fraud_amount_outsorted=None, vdr=None)
        undefined["vdr"] = value_reason
    else:
        den = float(np.dot(weights, fraud_values))
        num = float(np.dot(selected, fraud_values[order]))
        result.update(fraud_amount=den, fraud_amount_outsorted=num,
                      vdr=_ratio(num, den, "vdr", "zero total fraud amount", undefined))
    if count:
        # Counts only (no score is emitted): rows sharing the last outsorted row's score, inside and outside the cut.
        last = int(np.flatnonzero(selected)[-1])
        tied = scores[order] == scores[order][last]
        inside = int(np.dot(selected, tied))
        result["boundary_tied_rows"] = {"inside": inside, "outside": int(np.dot(ranked, tied)) - inside}
    else:
        result["boundary_tied_rows"] = None
    result["undefined"] = undefined
    return result


def _outsort_report(y, scores, amounts, amount_reason, order, tie_rule, shares, weights=None):
    fraud_values = None if amounts is None or amount_reason is not None else amounts * y
    reason = amount_reason if fraud_values is None else None
    return {"status": "available", "definitions": OUTSORT_DEFINITIONS, "unconfirmed": OUTSORT_UNCONFIRMED,
            "tie_rule": tie_rule,
            "value_convention": "nonnegative supplied transaction amounts; no currency conversion or absolute value",
            "cuts": [_outsort_cut(y, scores, fraud_values, reason, order, share, weights) for share in shares]}


def outsort_metrics(y, scores, *, amounts=None, row_keys=None, percents=OUTSORT_PERCENTS, weights=None):
    """UDR, VDR and the bank's FPR (false positives / true positives) at each outsort percent.

    The outsort at p% is the top floor(N x p/100) transactions by descending score, ties broken by the ascending
    ``row_keys`` (or input order without keys). ``weights`` are optional integer row multiplicities (one account
    bootstrap draw). Amounts follow the alert grid's convention: missing, nonfinite or negative amounts make VDR
    null with a reason. The bank's exact tie, amount and eligibility rules are not confirmed (OUTSORT_UNCONFIRMED).
    """
    y = np.asarray(y)
    if y.ndim != 1 or not np.isin(y, [0, 1]).all():
        raise ValueError("Labels must be explicitly encoded 0/1, with no nulls")
    y = y.astype(np.int64)
    scores = _vector(scores, len(y), "scores", float)
    if not np.isfinite(scores).all():
        raise ValueError("Scores must be finite")
    shares = outsort_shares(percents)
    amounts, amount_reason = _amounts(amounts, len(y))
    order, tie_rule = _ranking(scores, row_keys)
    if weights is not None:
        weights = _vector(weights, len(y), "weights")
        if not np.issubdtype(weights.dtype, np.integer) or (weights < 0).any():
            raise ValueError("Weights must be nonnegative integer multiplicities")
        weights = weights.astype(np.int64)
    return _outsort_report(y, scores, amounts, amount_reason, order, tie_rule, shares, weights)


def _bootstrap(y, scores, accounts, amounts, amount_reason, order, draws, seed):
    if not isinstance(draws, (int, np.integer)) or draws < 2:
        raise ValueError("bootstrap draws must be an integer >=2")
    point = _alert(y, amounts, amount_reason, order, 10)
    fields = ("detection_rate", "value_detection_rate")
    result = {"alert_fraction": .01, "requested_draws": int(draws), "seed": int(seed),
              "method": "95% percentile account bootstrap, resampling accounts with replacement; recompute integer alert budget in each draw",
              "interpretation": "pointwise account sampling conditional on this fitted model; not training or selection uncertainty"}
    if accounts is None:
        reason = "account metadata not supplied"
        codes, groups = None, []
    else:
        accounts = _vector(accounts, len(y), "accounts")
        if pd.isna(accounts).any():
            reason, codes, groups = "account metadata contains nulls", None, []
        else:
            codes, groups = pd.factorize(accounts, sort=True)
            reason = "fewer than two accounts" if len(groups) < 2 else None
    values = {key: [] for key in fields}
    if reason is None:
        rng = np.random.default_rng(seed)
        for _ in range(draws):
            multiplicities = rng.multinomial(len(groups), np.full(len(groups), 1 / len(groups)))
            sample = _alert(y, amounts, amount_reason, order, 10, multiplicities[codes])
            for key in fields:
                if sample[key] is not None:
                    values[key].append(sample[key])
    for key in fields:
        valid = len(values[key])
        result[key] = {"point": point[key], "ci95": np.quantile(values[key], [.025, .975]).tolist() if valid >= 2 else None,
                       "valid_draws": valid, "undefined_draws": int(draws) - valid,
                       "reason": reason or point["undefined"].get(key) or ("fewer than two defined draws" if valid < 2 else None)}
    return result


def business_report(y, scores, accounts=None, *, amounts=None, row_keys=None, depth=None,
                    source_files=None, amount_bins=None, draws=1000, seed=42, score_is_probability=True,
                    outsort_percents=None):
    """Return aggregates; callers declare probability semantics for calibration.

    Direct callers default to probabilities for compatibility. Rank or unknown
    scores must pass score_is_probability=False; [0,1] is only a range check.
    Slice alert budgets are relative to each slice. ``outsort_percents`` (for
    example OUTSORT_PERCENTS) adds an ``outsort`` entry for the whole
    population; left at None, the report is exactly as before.
    """
    if not isinstance(score_is_probability, (bool, np.bool_)):
        raise ValueError("score_is_probability must be a boolean declaration")
    shares = None if outsort_percents is None else outsort_shares(outsort_percents)
    y = np.asarray(y)
    if y.ndim != 1 or not np.isin(y, [0, 1]).all():
        raise ValueError("Labels must be explicitly encoded 0/1, with no nulls")
    y = y.astype(np.int64)
    scores = _vector(scores, len(y), "scores", float)
    if not np.isfinite(scores).all():
        raise ValueError("Scores must be finite")
    amounts, amount_reason = _amounts(amounts, len(y))
    order, tie_rule = _ranking(scores, row_keys)
    keys = None if row_keys is None else np.asarray(row_keys)
    result = _summary(y, scores, amounts, amount_reason, keys, score_is_probability)
    result.update(status="available", score_semantics="probability" if score_is_probability else "not_declared_probability",
                  alert_policy=POLICY_NOTE,
                  alert_count_rule="floor(transaction_count * alert_fraction), using exact integer per-mille arithmetic",
                  tie_rule=tie_rule, ks_definition="maximum absolute difference of fraud/nonfraud score CDFs at tied-score group boundaries",
                  value_convention="nonnegative supplied transaction amounts; no currency conversion or absolute-value transformation",
                  bootstrap_at_1_percent=_bootstrap(y, scores, accounts, amounts, amount_reason, order, draws, seed))

    def sliced(mask, **metadata):
        return dict(metadata, **_summary(y[mask], scores[mask], None if amounts is None else amounts[mask],
                                        amount_reason, None if keys is None else keys[mask], score_is_probability))

    slices = {"alert_budget_scope": "each slice separately; not a partition of global alerts"}
    edges = validate_amount_bins(amount_bins) if amount_bins is not None else None
    if amounts is None:
        slices["amount"] = unavailable(amount_reason)
    elif edges is None:
        slices["amount"] = unavailable("training-fitted amount-quintile artifact not supplied")
    else:
        bands = np.searchsorted(edges, amounts, side="left")
        slices["amount"] = {"status": "available", "training_artifact": amount_bins,
                            "bands": [sliced(bands == i, band=f"quintile_{i + 1}") for i in range(5)]}
    if depth is None:
        slices["account_depth"] = unavailable("actual full-history depth metadata not supplied")
    else:
        depth = _vector(depth, len(y), "depth", float)
        if not np.isfinite(depth).all() or (depth < 0).any() or (depth != np.floor(depth)).any():
            raise ValueError("History depth must be finite nonnegative integer counts")
        slices["account_depth"] = {"status": "available", "bands": [
            sliced((depth >= lo) & (True if hi is None else depth < hi), band=name)
            for name, lo, hi in DEPTH_BANDS]}
    if source_files is None:
        slices["source_file"] = unavailable("source-file metadata not supplied")
    else:
        source_files = _vector(source_files, len(y), "source_files")
        if pd.isna(source_files).any():
            slices["source_file"] = unavailable("source-file metadata contains nulls")
        else:
            sources = np.asarray([str(v) for v in source_files])
            slices["source_file"] = {"status": "available", "identity": "SHA-256 of source-file reference; no row identifiers",
                                     "files": [sliced(sources == value, source_sha256=hashlib.sha256(value.encode()).hexdigest())
                                               for value in sorted(set(sources))]}
    result["slices"] = slices
    if shares is not None:
        result["outsort"] = _outsort_report(y, scores, amounts, amount_reason, order, tie_rule, shares)
    return result


def main(argv=None):
    """Fit the reusable amount artifact before a labelled evaluation is read."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--training-files", nargs="+", required=True)
    parser.add_argument("--population", choices=("TRAIN", "DS_TRAIN"), required=True)
    parser.add_argument("--amount-col", required=True)
    parser.add_argument("--cred")
    parser.add_argument("--out", required=True)
    args = parser.parse_args(argv)
    from waqas.v2.benchmark_v2 import read_table
    from waqas.v2.storage import thin_read_filesystem
    frame = read_table(args.training_files, thin_read_filesystem(args.cred), columns=[args.amount_col])
    if args.amount_col not in frame:
        raise ValueError("Training amount column not available")
    artifact = fit_amount_bins(frame[args.amount_col], population=args.population,
                               source_sha256=hashlib.sha256(json.dumps(args.training_files).encode()).hexdigest())
    with Path(args.out).open("x") as handle:
        json.dump(artifact, handle, indent=2, allow_nan=False)
        handle.write("\n")
    return artifact


if __name__ == "__main__":
    main()
