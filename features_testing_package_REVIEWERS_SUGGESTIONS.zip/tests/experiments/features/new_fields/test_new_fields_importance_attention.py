"""Attention diagnostics must leave predictions and target populations alone."""

import importlib
from pathlib import Path
import sys

import pytest
import torch
from torch import nn

ROOT = Path(__file__).resolve().parents[4]
sys.path[:0] = [str(ROOT / "fraud/experiments/features/new_fields"), str(ROOT), str(ROOT / "src")]
from nf_attention import AttentionCapture, cls_attention, default_feature_groups


@pytest.mark.parametrize("norm_first", [True, False])
@pytest.mark.parametrize("bias", [True, False])
def test_cls_attention_matches_actual_attention_weights(norm_first, bias):
    torch.manual_seed(81)
    layer = nn.TransformerEncoderLayer(
        48, 8, 96, dropout=0.2, batch_first=True, norm_first=norm_first, bias=bias,
    ).eval()
    x = torch.randn(7, 14, 48)
    z = layer.norm1(x) if norm_first else x
    with torch.no_grad():
        _, expected = layer.self_attn(z, z, z, need_weights=True, average_attn_weights=False)
        actual = cls_attention(layer, x)
    torch.testing.assert_close(actual, expected[:, :, 0, :], atol=1e-6, rtol=0)


def model_class():
    try:
        module = importlib.import_module("fraud.sequential_hier_target_ending_model")
    except ModuleNotFoundError as exc:
        if exc.name != "fraud.sequential_hier_target_ending_model":
            raise
        module = importlib.import_module("waqas.v2.models")
    return module.FTTransformerHierTargetEnding


@pytest.fixture
def model_and_batch():
    torch.manual_seed(42)
    model = model_class()(
        continuous_dim=3, categorical_cardinality=[3, 2], history_len=2,
        embed_dim=16, num_heads=2, num_txn_blocks=2, num_seq_blocks=2,
        attn_dropout=0.0, ff_dropout=0.0, predict_every_transaction=True,
        all_position_layout="nonoverlapping_chunks", time_delta_reference="previous_transaction",
        attention_mask="causal", history_time_order="strict",
    ).eval()
    batch = {
        "continuous": torch.randn(3, 4, 3),
        "categorical": torch.zeros(3, 4, 2, dtype=torch.long),
        "mask": torch.tensor([[True, False, False, False],
                              [True, True, True, False], [True, True, True, True]]),
        "time_seq": torch.tensor([[10, 0, 0, 0], [10, 20, 30, 0], [10, 20, 20, 30]]) * 10**9,
    }
    return model, batch


TOKENS = ["amount", "balance", "time_gap", "type", "amount_isna"]


def test_real_model_scores_bitwise_unchanged_and_only_targets_count(model_and_batch):
    model, batch = model_and_batch
    observed = []
    with torch.no_grad():
        plain = model(batch).clone()
        with AttentionCapture(model, TOKENS) as capture:
            capture.set_targets(~batch["mask"], torch.tensor([True, False, True]))
            hooked = model(batch).clone()
        result = capture.result()
        assert torch.equal(plain, hooked)
        assert torch.equal(plain, model(batch))
        assert all(not layer._forward_pre_hooks for layer in model.token_encoder.layers)
        assert result["target_rows"] == 2
        assert result["layers"] == 2

        # Independent weights from the actual attention module at the two target
        # positions (flattened slots 0 and 11). No history slots enter the mean.
        def reference(layer, args):
            z = layer.norm1(args[0])
            _, weights = layer.self_attn(z, z, z, need_weights=True, average_attn_weights=False)
            observed.append(weights[[0, 11], :, 0, :].mean(dim=(0, 1)))

        handles = [layer.register_forward_pre_hook(reference) for layer in model.token_encoder.layers]
        try:
            model(batch)
        finally:
            for handle in handles:
                handle.remove()
    expected = torch.stack(observed).mean(0)
    torch.testing.assert_close(torch.tensor(list(result["token_attention"].values())),
                               expected[1:], atol=1e-6, rtol=0)
    assert result["features"]["amount"] == pytest.approx(float(expected[1] + expected[5]), abs=1e-6)
    assert result["features"]["time_gap"] == pytest.approx(float(expected[3]), abs=1e-6)
    assert sum(result["features"].values()) + result["cls_self"] == pytest.approx(1.0, abs=1e-6)


def test_target_average_weights_rows_not_batches(model_and_batch):
    model, batch = model_and_batch
    with torch.no_grad(), AttentionCapture(model, TOKENS) as combined:
        combined.set_targets(~batch["mask"])
        model(batch)
    with torch.no_grad(), AttentionCapture(model, TOKENS) as split:
        for pick in (slice(0, 1), slice(1, 3)):
            small = {key: value[pick] for key, value in batch.items()}
            split.set_targets(~small["mask"])
            model(small)
    assert split.result()["target_rows"] == 3
    for name, weight in combined.result()["features"].items():
        assert split.result()["features"][name] == pytest.approx(weight, abs=1e-6)


def test_empty_selected_batch_does_not_add_history(model_and_batch):
    model, batch = model_and_batch
    with torch.no_grad(), AttentionCapture(model, TOKENS) as capture:
        capture.set_targets(~batch["mask"], torch.zeros(3, dtype=torch.bool))
        model(batch)
        with pytest.raises(ValueError, match="No complete"):
            capture.result()
        capture.set_targets(~batch["mask"], torch.tensor([False, True, False]))
        model(batch)
    assert capture.result()["target_rows"] == 1


@pytest.mark.parametrize("column", range(5))
def test_real_tokenizer_feature_column_order(model_and_batch, column):
    model, batch = model_and_batch
    continuous = batch["continuous"].reshape(-1, 3).clone()
    categorical = batch["categorical"].reshape(-1, 2).clone()
    before = model.embedding(continuous, categorical)
    if column < 3:
        continuous[:, column] += 1.0
    else:
        categorical[:, column - 3] += 1
    after = model.embedding(continuous, categorical)
    changed = (before != after).any(0).any(-1)
    expected = torch.zeros(5, dtype=torch.bool)
    expected[column] = True
    assert torch.equal(changed, expected)


def test_default_groups_do_not_invent_a_base_for_a_standalone_flag():
    assert default_feature_groups(["x", "x_isna", "orphan_isna", "time_gap"]) == {
        "x": ["x", "x_isna"], "orphan_isna": ["orphan_isna"], "time_gap": ["time_gap"],
    }


def test_context_cleans_hooks_after_failure(model_and_batch):
    model, batch = model_and_batch
    with pytest.raises(RuntimeError, match="set_targets"):
        with AttentionCapture(model, TOKENS):
            model(batch)
    assert all(not layer._forward_pre_hooks for layer in model.token_encoder.layers)


def test_each_forward_requires_a_fresh_population_mask(model_and_batch):
    model, batch = model_and_batch
    with torch.no_grad(), AttentionCapture(model, TOKENS) as capture:
        capture.set_targets(~batch["mask"])
        model(batch)
        with pytest.raises(RuntimeError, match="set_targets"):
            model(batch)
    assert capture.result()["target_rows"] == 3


def test_explicit_groups_sum_tokens_without_changing_weights(model_and_batch):
    model, batch = model_and_batch
    groups = {"amount_family": ["amount", "amount_isna", "balance"],
              "type": ["type"], "time_gap": ["time_gap"]}
    with torch.no_grad(), AttentionCapture(model, TOKENS, groups) as capture:
        capture.set_targets(~batch["mask"])
        model(batch)
    result = capture.result()
    assert result["features"]["amount_family"] == pytest.approx(sum(
        result["token_attention"][name] for name in groups["amount_family"]))


def test_refuse_training_or_wrong_token_contract(model_and_batch):
    model, batch = model_and_batch
    with pytest.raises(ValueError, match="partition"):
        AttentionCapture(model, TOKENS, {"amount": ["amount"]})
    with torch.no_grad(), AttentionCapture(model, TOKENS[:-1]) as capture:
        capture.set_targets(~batch["mask"])
        with pytest.raises(ValueError, match="token count"):
            model(batch)
    model.train()
    with pytest.raises(ValueError, match="evaluation"):
        with AttentionCapture(model, TOKENS):
            pass


def test_target_selection_supports_left_padding_and_rejects_empty_windows(model_and_batch):
    model, _ = model_and_batch
    capture = AttentionCapture(model, TOKENS)
    capture.set_targets(torch.tensor([[True, True, False], [False, True, False]]))
    assert capture._flat_targets.tolist() == [2, 5]
    with pytest.raises(ValueError, match="real target"):
        capture.set_targets(torch.ones((1, 3), dtype=torch.bool))
    with pytest.raises(ValueError, match="boolean"):
        capture.set_targets(torch.ones((1, 3)))
