"""Statistical checks against expanded rows and the existing metric engine."""
from fractions import Fraction
import importlib.util
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import pytest
from sklearn.metrics import average_precision_score


ROOT = Path(__file__).resolve().parents[4]
NF = ROOT / "fraud/experiments/features/new_fields"
sys.path.insert(0, str(NF))
from nf_importance_metrics import (  # noqa: E402
    RankedScore, multiplicity_draws, point_metrics, summarize_unit,
)


def world(n=2000):
    rng = np.random.default_rng(29)
    labels = rng.random(n) < .17
    frame = pd.DataFrame({
        "account": [f"a{i // 5}" for i in range(n)],
        "id": [f"i{i}" for i in range(n)], "label": labels.astype(int),
        "amount": rng.uniform(2, 200, n),
    })
    return frame, np.round(rng.random(n), 1)


def expanded_oracle(frame, scores, multiplicity, outsort):
    accounts = sorted(frame.account.unique())
    codes = np.array([accounts.index(a) for a in frame.account])
    copies = np.repeat(np.arange(len(frame)), multiplicity[codes])
    y = frame.label.to_numpy()[copies]
    s = np.asarray(scores)[copies]
    keys = np.asarray([json.dumps([str(a), str(i)]) for a, i in zip(frame.account, frame.id)])[copies]
    order = np.lexsort((keys, -s))
    share = Fraction(outsort)
    alerts = len(y) * share.numerator // share.denominator
    selected = order[:alerts]
    caught = y[selected].sum()
    amounts = frame.amount.to_numpy()[copies] * y
    return {
        "ap": average_precision_score(y, s) if y.sum() else np.nan,
        "udr": caught / y.sum() if y.sum() else np.nan,
        "vdr": amounts[selected].sum() / amounts.sum() if amounts.sum() else np.nan,
        "fpr": (alerts - caught) / caught if caught else np.nan,
        "alerts": alerts, "frauds_caught": caught,
    }


@pytest.mark.parametrize("outsort", ["0.006", "0.01", "0.05", "1"])
@pytest.mark.parametrize("weighted", [False, True])
def test_exact_metrics_equal_expanded_rows_with_ties(outsort, weighted):
    frame, scores = world(1000)
    weights = next(multiplicity_draws(200, 2, 71)) if weighted else np.ones(200, dtype=np.int64)
    actual = point_metrics(frame, scores, multiplicity=weights, outsort=outsort)
    expected = expanded_oracle(frame, scores, weights, outsort)
    for key, value in expected.items():
        assert actual[key] == pytest.approx(value, nan_ok=True)


def test_boundary_account_copies_partially_enter_exact_budget():
    frame = pd.DataFrame({"account": ["a", "b"], "id": ["2", "1"],
                          "label": [1, 0], "amount": [100., 50.]})
    result = point_metrics(frame, [.8, .7], multiplicity=np.array([9, 1]), outsort="0.5")
    assert result["alerts"] == 5
    assert result["frauds_caught"] == 5
    assert result["udr"] == pytest.approx(5 / 9)
    assert result["vdr"] == pytest.approx(5 / 9)


def test_identity_repeats_are_zero_with_paired_uncertainty():
    frame, scores = world()
    report = summarize_unit(frame, scores, [scores, scores], draws=31)
    for metric in ("ap", "udr", "vdr", "fpr"):
        assert report[f"drop_{metric}"] == pytest.approx(0)
        assert report[f"drop_{metric}_ci_low"] == pytest.approx(0)
        assert report[f"drop_{metric}_ci_high"] == pytest.approx(0)
        assert report[f"drop_{metric}_ci_reason"] is None
        assert report[f"drop_{metric}_repeat_sd"] == pytest.approx(0)
    assert "not training-seed" in report["uncertainty_note"]


def test_strong_signal_beats_noise_and_null_feature_interval_contains_zero():
    frame, noise = world(3000)
    y = frame.label.to_numpy()
    signal = .15 + .7 * y + noise * .1
    rng = np.random.default_rng(18)
    shuffled = signal[rng.permutation(len(signal))]
    weak = signal + (rng.random(len(signal)) - .5) * .00001
    strong_report = summarize_unit(frame, signal, [shuffled], draws=70)
    weak_report = summarize_unit(frame, signal, [weak], draws=70)
    assert strong_report["drop_ap_ci_low"] > .5
    assert strong_report["drop_udr_ci_low"] > 0
    assert strong_report["drop_ap"] > weak_report["drop_ap"]
    assert weak_report["drop_ap_ci_low"] <= 0 <= weak_report["drop_ap_ci_high"]


def test_repeat_mean_is_inside_paired_draw_and_shared_across_units():
    frame, scores = world(500)
    opposite = 1 - scores
    first = summarize_unit(frame, scores, [opposite], draws=37, seed=95)
    mixture = summarize_unit(frame, scores, [scores, opposite], draws=37, seed=95)
    for name in ("drop_ap", "drop_ap_ci_low", "drop_ap_ci_high", "drop_udr", "drop_udr_ci_low"):
        assert mixture[name] == pytest.approx(first[name] / 2)
    reordered = frame.sample(frac=1, random_state=7)
    picks = reordered.index.to_numpy()
    again = summarize_unit(reordered, scores[picks], [opposite[picks]], draws=37, seed=95)
    for name in ("drop_ap", "drop_ap_ci_low", "drop_ap_ci_high", "drop_udr_ci_low"):
        assert again[name] == pytest.approx(first[name])


@pytest.mark.parametrize("seed,valid", [(4, 0), (0, 1), (2, 2)])
def test_interval_needs_two_finite_paired_draws_without_losing_point_or_counts(seed, valid):
    labels = np.zeros(200, dtype=int)
    labels[0] = 1
    frame = pd.DataFrame({"account": ["a"] * 100 + ["b"] * 100,
                          "id": np.arange(200), "label": labels, "amount": np.ones(200)})
    scores = labels * .8 + .1
    report = summarize_unit(frame, scores, [1 - scores], draws=2, seed=seed)
    assert report["baseline_ap"] == pytest.approx(1)
    assert report["perturbed_ap"] == pytest.approx(.005)
    assert report["drop_ap"] == pytest.approx(.995)
    assert report["drop_ap_draws_valid"] == valid
    assert report["drop_ap_draws_undefined"] == 2 - valid
    if valid < 2:
        assert np.isnan(report["drop_ap_ci_low"])
        assert np.isnan(report["drop_ap_ci_high"])
        assert report["drop_ap_ci_reason"] == "fewer than two finite paired bootstrap draws"
    else:
        assert np.isfinite(report["drop_ap_ci_low"])
        assert np.isfinite(report["drop_ap_ci_high"])
        assert report["drop_ap_ci_reason"] is None


@pytest.mark.parametrize("labels,ap", [([1, 1, 1], 1.), ([0, 0, 0], np.nan)])
def test_single_class_average_precision_is_explicit(labels, ap):
    frame = pd.DataFrame({"account": ["a", "b", "c"], "id": [1, 2, 3],
                          "label": labels, "amount": [1., 2., 3.]})
    result = point_metrics(frame, [.1, .3, .2])
    assert result["ap"] == pytest.approx(ap, nan_ok=True)
    assert (result["ap_reason"] == "no fraud targets") == (sum(labels) == 0)
    assert result["alerts"] == 0
    assert np.isnan(result["fpr"])


@pytest.mark.parametrize("bad", [np.nan, np.inf, -1.])
def test_bad_amount_keeps_count_metrics_and_marks_value_unavailable(bad):
    frame, scores = world(1000)
    frame.loc[0, "amount"] = bad
    report = summarize_unit(frame, scores, [scores], draws=11)
    assert report["amount_reason"]
    assert np.isnan(report["baseline_vdr"])
    assert report["drop_vdr_draws_undefined"] == 11
    assert report["drop_ap"] == pytest.approx(0)


def test_shared_draws_match_canonical_multinomial_sequence():
    rng = np.random.default_rng(20261102)
    actual = list(multiplicity_draws(7, 5))
    expected = [np.bincount(rng.integers(0, 7, 7), minlength=7) for _ in range(5)]
    np.testing.assert_array_equal(actual, expected)


@pytest.mark.parametrize("error", ["duplicate", "label", "score", "empty", "repeats", "draws"])
def test_invalid_comparison_cannot_produce_a_result(error):
    frame, scores = world(100)
    kwargs = {"draws": 5}
    repeats = [scores]
    if error == "duplicate":
        frame.loc[1, ["account", "id"]] = frame.loc[0, ["account", "id"]]
    if error == "label":
        frame.loc[0, "label"] = -100
    if error == "score":
        scores[0] = np.nan
    if error == "empty":
        frame = frame.iloc[:0]
    if error == "repeats":
        repeats = []
    if error == "draws":
        kwargs["draws"] = 1
    with pytest.raises(ValueError):
        summarize_unit(frame, scores, repeats, **kwargs)


def test_engine_equals_existing_outsort_reference_when_available():
    reference = ROOT / "work/features_pkg/INPUTS/module_analysis/files/waqas/v2/analysis/business_metrics.py"
    if not reference.is_file():
        pytest.skip("the independent integration reference is not installed in this tree")
    spec = importlib.util.spec_from_file_location("metric_reference", reference)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    frame, scores = world(1000)
    accounts = sorted(frame.account.unique())
    weights = next(multiplicity_draws(len(accounts), 2))
    row_weights = weights[np.array([accounts.index(a) for a in frame.account])]
    keys = [json.dumps([str(a), str(i)]) for a, i in zip(frame.account, frame.id)]
    for percent, share in [("0.6", "0.006"), ("1", "0.01"), ("5", "0.05")]:
        expected = module.outsort_metrics(frame.label, scores, amounts=frame.amount,
                                         row_keys=keys, percents=[percent], weights=row_weights)["cuts"][0]
        actual = point_metrics(frame, scores, multiplicity=weights, outsort=share)
        for key in ("udr", "vdr", "fpr"):
            assert actual[key] == pytest.approx(expected[key], nan_ok=True)
        assert actual["alerts"] == expected["outsorted"]
