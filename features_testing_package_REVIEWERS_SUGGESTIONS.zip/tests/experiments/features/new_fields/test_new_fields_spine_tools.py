"""Config writer, guard, rank check, preflight and the naming check, in a synthetic project."""
import json
import sys
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
from new_fields_spine_world import BASE_CONFIG, NF_REL, default_map, make_world, run, write  # noqa: E402

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / NF_REL))
import nf_common as C  # noqa: E402

STATUS = {"f_code": "PASS", "f_cnt24": "FLAG", "f_amt": "PASS"}


def W(tmp_path, **kw):
    kw.setdefault("map_rows", default_map())
    kw.setdefault("field_status", STATUS)
    return make_world(tmp_path, **kw)


# ------------------------------------------------------------------ config writer

def test_configs_differ_only_in_allowed_keys(tmp_path):
    w = W(tmp_path)
    r = run(w, tmp_path, "nf_make_configs.py")
    assert r.returncode == 0, r.stderr
    cfgs = w / NF_REL / "configs"
    assert sorted(p.name for p in cfgs.glob("*.yaml")) == ["nf_a1.yaml", "nf_control.yaml"]
    r2 = run(w, tmp_path, "nf_make_configs.py", "write", "--run", "nf_a2", "--steps", "A1", "A2")
    assert r2.returncode == 0, r2.stderr
    a2 = yaml.safe_load((cfgs / "nf_a2.yaml").read_text())
    d = C.diff_configs(BASE_CONFIG, a2)
    keys = {k for k, _, _ in d}
    assert keys <= {"predictors.csv_path", "artifacts.version", "data.train_base", "data.val_base", "eval.base",
                    "output.checkpoint_dir", "experiment.run_name"}
    assert a2["data"]["train_base"].endswith("/enriched/nf_build1/tfm_raw_data")   # f_cnt24 is engineered
    assert a2["eval"]["base"].endswith("/enriched/nf_build1/tfm_EVAL_raw_data")
    a1 = yaml.safe_load((cfgs / "nf_a1.yaml").read_text())
    assert a1["data"]["train_base"] == BASE_CONFIG["data"]["train_base"]           # raw only: original files
    ctl = yaml.safe_load((cfgs / "nf_control.yaml").read_text())
    assert ctl["artifacts"]["version"] == 1 and ctl["predictors"]["csv_path"].endswith("predictors_base_month_in.csv")
    assert "num_workers (as run) 4" in r.stdout and "file partition" in r.stdout
    r = run(w, tmp_path, "nf_make_configs.py", "--verify")
    assert r.returncode == 0, r.stdout
    # any other difference is refused
    p = cfgs / "nf_a1.yaml"
    p.write_text(p.read_text().replace("max_epochs: 10", "max_epochs: 12"))
    r = run(w, tmp_path, "nf_make_configs.py", "--verify")
    assert r.returncode == 3 and "training.max_epochs" in r.stdout


def test_predictor_lists(tmp_path):
    w = W(tmp_path)
    run(w, tmp_path, "nf_make_configs.py", "write", "--run", "nf_a2", "--steps", "A1", "A2")
    base = (w / "fraud/configs/predictors.csv").read_bytes()
    pin = (w / NF_REL / "predictors/predictors_a1a2_month_in.csv").read_bytes()
    pout = (w / NF_REL / "predictors/predictors_a1a2_month_out.csv").read_text()
    assert pin.startswith(base)
    added = pin[len(base):].decode().splitlines()
    assert [x.split(",")[0] for x in added] == ["f_code", "f_cnt24", "f_amt"]
    assert [x.split(",")[1] for x in added] == ["categorical", "continuous", "continuous"]
    assert all(x.split(",")[2] == "raw" and x.split(",")[3] == "1" for x in added)
    lin = pin.decode().splitlines()
    lout = pout.splitlines()
    assert len(lin) - len(lout) == 1 and [x for x in lin if x not in lout][0].startswith("month,")


def test_blank_learning_rate_source_refused_and_lr_written(tmp_path):
    w = W(tmp_path, settings_patch={"learning_rate_source": ""})
    r = run(w, tmp_path, "nf_make_configs.py")
    assert r.returncode == 4 and "learning_rate_source" in r.stderr
    w2 = W(tmp_path / "b", settings_patch={"learning_rate": 0.001})
    r = run(w2, tmp_path / "b", "nf_make_configs.py")
    assert r.returncode == 0, r.stderr
    assert yaml.safe_load((w2 / NF_REL / "configs/nf_a1.yaml").read_text())["training"]["learning_rate"] == 0.001


def test_microbatch_keeps_targets_per_update(tmp_path):
    w = W(tmp_path, settings_patch={"microbatch": {"nf_a1": {"batch_size": 128, "accumulate_grad_batches": 32,
                                                             "eval_batch_size": 512}}})
    r = run(w, tmp_path, "nf_make_configs.py")
    assert r.returncode == 0, r.stderr
    a1 = yaml.safe_load((w / NF_REL / "configs/nf_a1.yaml").read_text())
    assert (a1["training"]["batch_size"], a1["training"]["accumulate_grad_batches"]) == (128, 32)
    assert "memory rule fired" in r.stdout
    w2 = W(tmp_path / "b", settings_patch={"microbatch": {"nf_a1": {"batch_size": 128,
                                                                    "accumulate_grad_batches": 16}}})
    r = run(w2, tmp_path / "b", "nf_make_configs.py")
    assert r.returncode == 3 and "targets per update" in r.stderr


def test_existing_config_not_overwritten(tmp_path):
    w = W(tmp_path)
    run(w, tmp_path, "nf_make_configs.py", "write", "--run", "nf_a2", "--steps", "A2")
    r = run(w, tmp_path, "nf_make_configs.py", "write", "--run", "nf_a2", "--steps", "A1", "A2")
    assert r.returncode == 4 and "rename it" in r.stderr


def test_map_newer_than_status_refused(tmp_path):
    w = W(tmp_path)
    import os
    import time
    fs = w / "checkpoints/new_fields/checks/field_status.csv"
    os.utime(fs, (time.time() - 100, time.time() - 100))
    r = run(w, tmp_path, "nf_make_configs.py")
    assert r.returncode == 4 and "newer than field_status" in r.stderr


# ------------------------------------------------------------------ guard

def _stage0(w, sha):
    write(w / "runs/tuning/lr3e-4/run_manifest_v2.json", json.dumps(
        {"status": "running", "start": {"source_sha256": "old", "utc": "a"},
         "resume_events": [{"source_sha256": sha, "utc": "b"}]}))


def test_guard_unchanged_and_changed(tmp_path):
    w = W(tmp_path)
    _stage0(w, "s" * 64)
    r = run(w, tmp_path, "nf_guard.py", "--before", "s" * 64, "--cpu-only")
    assert r.returncode == 0, r.stdout + r.stderr
    assert "-> unchanged" in r.stdout and "layout: reorganized" in r.stdout
    log = (w / "checkpoints/new_fields/guard/guard.jsonl").read_text().splitlines()
    assert json.loads(log[-1])["result"] == "unchanged"
    r = run(w, tmp_path, "nf_guard.py", "--before", "t" * 64, "--cpu-only")
    assert r.returncode == 3 and "CHANGED" in r.stdout
    assert len((w / "checkpoints/new_fields/guard/guard.jsonl").read_text().splitlines()) == 2   # appended


def test_guard_latest_stage0_identity_and_control(tmp_path):
    w = W(tmp_path)
    _stage0(w, "x" * 64)
    r = run(w, tmp_path, "nf_guard.py", "--cpu-only")
    assert r.returncode == 3 and "stage 0 DIFFERS" in r.stdout
    w2 = W(tmp_path / "b")
    r = run(w2, tmp_path / "b", "nf_guard.py", "--cpu-only")
    assert r.returncode == 3 and "no stage 0 manifest found" in r.stdout and "runs/tuning" in r.stdout
    w3 = W(tmp_path / "c")
    _stage0(w3, "s" * 64)
    m = w3 / "checkpoints/reproduce/retrain_seed42/run_manifest_v2.json"
    m.write_text(json.dumps({"status": "finished", "start": {"source_sha256": "y" * 64}}))
    r = run(w3, tmp_path / "c", "nf_guard.py", "--cpu-only")
    assert r.returncode == 3 and "stage 1 control DIFFERS" in r.stdout


def test_guard_reads_stage1_result_files(tmp_path):
    w = W(tmp_path)
    _stage0(w, "s" * 64)
    write(w / "checkpoints/reproduce/rescore/summary.json", json.dumps({"result": "PASS"}))
    write(w / "checkpoints/reproduce/route.json", json.dumps({"passed": True}))
    write(w / "checkpoints/reproduce/wrapper_check.json", json.dumps({"status": "ok"}))
    write(w / "checkpoints/reproduce/same_batch/cpu/result.json", json.dumps({"passed": False}))
    r = run(w, tmp_path, "nf_guard.py", "--cpu-only")
    assert r.returncode == 0, r.stdout
    rec = json.loads((w / "checkpoints/new_fields/guard/guard.jsonl").read_text().splitlines()[-1])
    assert rec["stage1_results"]["route_result"]["passed"] is True
    assert rec["stage1_results"]["same_batch"]["cpu"]["passed"] is False
    assert rec["stage1_ok"] is False
    assert len(rec["stage1_results"]["rescore_summary"]["sha256"]) == 64


def test_guard_environment_difference(tmp_path):
    w = W(tmp_path)
    _stage0(w, "s" * 64)
    m = w / "checkpoints/reproduce/retrain_seed42/run_manifest_v2.json"
    m.write_text(json.dumps({"status": "finished", "start": {"source_sha256": "s" * 64, "torch": "0.0.1",
                                                             "lightning": "0.0.1"}}))
    r = run(w, tmp_path, "nf_guard.py")
    assert r.returncode == 3 and "environment DIFFERS torch" in r.stdout
    r = run(w, tmp_path, "nf_guard.py", "--cpu-only")
    assert r.returncode == 0 and "environment DIFFERS torch" in r.stdout


# ------------------------------------------------------------------ rank check

def _splits(w, pops=None, june=(10, 2)):
    files = [{"file_key": f"eval/{n}", "source": "eval", "number": n,
              "months": {"2025-06": {"rows": june[0], "frauds": june[1]}}} for n in range(8228, 8260)]
    write(w / "splits/file_inventory.json", json.dumps({"files": files}))
    write(w / "splits/populations.yaml", yaml.safe_dump({"populations": pops or {
        "SELECT": {"source": "eval", "file_start": 8206, "file_end": 8216},
        "BENCH": {"source": "eval", "file_start": 8000, "file_end": 8200}}}))
    write(w / "splits/population_roles.yaml", yaml.safe_dump({"populations": {"SELECT": {}}}))


def test_rank_check_passes_with_no_role_and_no_exposure(tmp_path):
    w = W(tmp_path, rank_check=None)
    _splits(w)
    r = run(w, tmp_path, "nf_rank_check.py", "--skip-files", "--roots", "checkpoints", "models")
    assert r.returncode == 0, r.stdout
    j = json.loads((w / "checkpoints/new_fields/reads/rank_check.json").read_text())
    assert j["decide_on"] == "rank_b" and j["populations"]["rank_b"]["june_frauds"] == 32
    assert "roots searched: checkpoints, models" in r.stdout


def test_rank_check_fails_on_role_exposure_or_no_june(tmp_path):
    w = W(tmp_path, rank_check=None)
    _splits(w, pops={"DS_SELECT": {"source": "eval", "file_start": 8240, "file_end": 8250}})
    r = run(w, tmp_path, "nf_rank_check.py", "--skip-files", "--roots", "checkpoints")
    assert r.returncode == 3 and "used by populations: DS_SELECT" in r.stdout
    j = json.loads((w / "checkpoints/new_fields/reads/rank_check.json").read_text())
    assert j["decide_on"] == "select_june"
    w2 = W(tmp_path / "b", rank_check=None)
    _splits(w2)
    write(w2 / "models/x/scores/select.parquet.json", json.dumps(
        {"checkpoint_sha256": "a", "files": {"base": "s3://x", "start": 8250, "end": 8255}}))
    r = run(w2, tmp_path / "b", "nf_rank_check.py", "--skip-files", "--roots", "models")
    assert r.returncode == 3 and "exposure" in r.stdout
    assert json.loads((w2 / "checkpoints/new_fields/reads/rank_check.json").read_text())["populations"]["rank_a"][
        "result"] == "PASS"
    w3 = W(tmp_path / "c", rank_check=None)
    _splits(w3, june=(0, 0))
    r = run(w3, tmp_path / "c", "nf_rank_check.py", "--skip-files", "--roots", "models")
    assert r.returncode == 3 and "no June targets" in r.stdout


def test_rank_check_own_reads_do_not_fail(tmp_path):
    w = W(tmp_path, rank_check=None)
    _splits(w)
    write(w / "checkpoints/new_fields/scores/a__rank_b.parquet.exposure.json", json.dumps(
        {"purpose": "new_fields_rank_b_decision", "population": "OTHER", "files": {"start": 8244, "end": 8259}}))
    r = run(w, tmp_path, "nf_rank_check.py", "--skip-files", "--roots", "checkpoints")
    assert r.returncode == 0, r.stdout


# ------------------------------------------------------------------ preflight

def test_preflight_lists_every_failure(tmp_path):
    w = W(tmp_path)
    s = yaml.safe_load((w / NF_REL / "SETTINGS.yaml").read_text())
    s["approvals"]["bar"] = {"approved_by": "", "approved_on": ""}
    s["check_thresholds_sha256"] = ""        # the shipped file records the approved SHA-256 (decision D10)
    (w / NF_REL / "SETTINGS.yaml").write_text(yaml.safe_dump(s))
    r = run(w, tmp_path, "nf_plan.py", "preflight")
    assert r.returncode == 3
    pf = json.loads((w / "checkpoints/new_fields/reads/preflight.json").read_text())
    bad = {c["check"] for c in pf["checks"] if not c["ok"]}
    assert {"approvals", "thresholds_unchanged", "artifact_check", "guard", "stage1_checks"} <= bad
    assert "control" not in bad and "rank_check" not in bad and "gpu_free" not in bad
    assert len(r.stdout.splitlines()) <= 40


# ------------------------------------------------------------------ naming check

def test_naming_check(tmp_path):
    sys.path.insert(0, str(ROOT / NF_REL))
    import codecs
    import zipfile

    import nf_naming_check as N
    good = tmp_path / "ok"
    write(good / "a.md", "the reviewers wrote this; CLI and CHECK are fine words\n")
    assert N.scan([good]) == []
    bad = tmp_path / "bad"
    word = codecs.decode("Pynhqr", "rot13")
    write(bad / "a.md", f"written by {word}\n")
    write(bad / "b.md", "see the " + codecs.decode("PY", "rot13") + " folder\n")
    write(bad / codecs.decode("PU", "rot13") / "c.txt", "x\n")
    with zipfile.ZipFile(bad / "w.xlsx", "w") as z:
        z.writestr("xl/sharedStrings.xml", f"<sst><si><t>{codecs.decode('bcranv', 'rot13').upper()}</t></si></sst>")
    hits = N.scan([bad])
    assert len(hits) == 4, hits
    assert any("w.xlsx:xl/sharedStrings.xml" in h for h in hits)
    assert N.main([str(good)]) == 0 and N.main([str(bad)]) == 3


def test_package_files_pass_naming_check():
    sys.path.insert(0, str(ROOT / NF_REL))
    import nf_naming_check as N
    spine = [ROOT / NF_REL / f for f in ("nf_layout.py", "nf_common.py", "nf_guard.py", "nf_intake.py",
                                          "nf_make_configs.py", "nf_rank_check.py", "nf_plan.py", "nf_report.py",
                                          "nf_naming_check.py", "nf_run_all.sh", "nf_start.sh", "SETTINGS.yaml",
                                          "STEPS.yaml", "CHECK_THRESHOLDS.yaml", "STATUS_RULES.csv", "UPSTREAM.yaml",
                                          "FIELD_MAP.csv")]
    docs = [p for p in (ROOT / NF_REL / "README.md", ROOT / NF_REL / "POD.md") if p.is_file()]
    assert N.scan(spine + docs + [Path(__file__).resolve().parent]) == []


def test_no_init_and_no_hashed_paths():
    nf = ROOT / NF_REL
    assert not list(nf.rglob("__init__.py"))
    assert not list((ROOT / "tests/experiments/features/new_fields").rglob("__init__.py"))


# ------------------------------------------------------------------ the one decisions table

def test_keep_decisions_person_rows_only(tmp_path):
    w = W(tmp_path)
    kd = w / NF_REL / "KEEP_DECISIONS.csv"
    kd.write_text(",".join(C.KEEP_DECISIONS_COLUMNS) + "\n"
                  "f_amt,f15298,drop,weak,screen:rank 90,Owner,2026-11-03,1\n"
                  "f_code,v22b,drop,tool says so,checks:FLAG,proposed,2026-11-03,1\n")
    r = run(w, tmp_path, "nf_make_configs.py", "write", "--run", "nf_a2", "--steps", "A1", "A2")
    assert r.returncode == 0, r.stderr
    pin = (w / NF_REL / "predictors/predictors_a1a2_month_in.csv").read_text()
    assert "f_code," in pin and "f_amt," not in pin     # a person's drop leaves; a proposal does not


def test_prune_never_drops_a_field_a_person_kept(tmp_path, monkeypatch):
    import nf_plan
    kd = tmp_path / "KEEP_DECISIONS.csv"
    kd.write_text(",".join(C.KEEP_DECISIONS_COLUMNS) + "\nf_e,f15298,keep,owner keeps it,,Owner,2026-11-03,1\n")
    monkeypatch.setattr(C, "NF", tmp_path)
    monkeypatch.setenv("NF_SETTINGS_DIR", str(ROOT / NF_REL))
    imp = tmp_path / "importance.csv"
    imp.write_text("unit,kind,members,udr_drop_hi,ap_drop_hi\nf_e,single,f_e,-1,-1\nf_f,single,f_f,-1,-1\n")
    assert nf_plan.prune_list(imp, None) == ["f_f"]


def test_status_match_cleared_by_person_only(tmp_path, monkeypatch):
    import nf_intake as I
    kd = tmp_path / "KEEP_DECISIONS.csv"
    kd.write_text(",".join(C.KEEP_DECISIONS_COLUMNS) + "\n"
                  "a_hold_x,v22b,keep,status match cleared: a hold-out code,,Owner,2026-11-03,1\n"
                  "b_hold_x,v22b,keep,status match cleared,,proposed,2026-11-03,1\n")
    monkeypatch.setattr(C, "NF", tmp_path)
    assert I.cleared_status("a_hold_x") and not I.cleared_status("b_hold_x")
