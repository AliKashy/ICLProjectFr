"""The planner against the other lanes' real command lines (integration decisions 1, 10 and 11, the plan's pruning
and calendar rules), with the spine lane's synthetic project and fakes on PATH."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from new_fields_spine_world import NF_REL, default_map, make_world, run  # noqa: E402

STATUS = {"f_code": "PASS", "f_cnt24": "FLAG", "f_amt": "PASS"}
ONE_STEP = {"steps": [{"name": "A1", "on": True, "adds": ["v22b", "both"]},
                      {"name": "A2", "on": False, "adds": ["f15298"]},
                      {"name": "P", "on": True, "kind": "prune"},
                      {"name": "B", "on": False, "kind": "month_out"},
                      {"name": "C", "on": False, "kind": "calendar_cyclical", "is_weekend": False}]}


def world(tmp_path, **kw):
    kw.setdefault("map_rows", default_map())
    kw.setdefault("field_status", STATUS)
    return make_world(tmp_path, **kw)


def queue(w, tmp_path, decisions=None, **envx):
    if decisions is not None:
        p = tmp_path / "decisions.json"
        p.write_text(json.dumps(decisions))
        envx["FAKE_DECISIONS"] = p
    return run(w, tmp_path, "nf_plan.py", "queue", "--skip-preflight", **envx)


def c2(w):
    return w / "checkpoints" / "new_fields"


def qlog(w):
    return (c2(w) / "queue.log").read_text()


def test_importance_and_attention_use_the_importance_lane_command_line(tmp_path):
    """Decision 1: attention is run --attention-only; both pass --field-map, --clusters (the checks lane's
    clusters.csv), --output exactly, the SETTINGS options, and a timing input from the queue's own log."""
    w = world(tmp_path, steps_patch={"steps": ONE_STEP["steps"][:2]})
    (c2(w) / "checks" / "clusters.csv").write_text("cluster_id,member,member_kind,size,max_link,result\n"
                                                   "C001,f_code,new,2,0.95,FLAG\nC001,f_amt,new,2,0.95,FLAG\n")
    args = tmp_path / "importance_args.txt"
    r = queue(w, tmp_path, decisions={"A1_1seed": "ADOPT"}, FAKE_IMPORTANCE_ARGS=args)
    assert r.returncode in (0, 5), qlog(w)
    calls = args.read_text().splitlines()
    att = [c for c in calls if "--attention-only" in c]
    imp = [c for c in calls if "--attention-only" not in c]
    assert att and imp, calls
    for c in att + imp:
        a = c.split()
        assert a[0] == "run" and "--output" in a and "--out" not in a
        assert a[a.index("--field-map") + 1].endswith("FIELD_MAP.csv")
        assert a[a.index("--clusters") + 1].endswith("checks/clusters.csv")
        assert float(a[a.index("--seconds-per-row") + 1]) > 0 and int(a[a.index("--rank-a-rows") + 1]) > 0
        assert a[a.index("--account-share") + 1] == "0.25" and a[a.index("--max-gpu-hours") + 1] == "24"
    assert att[0].split()[att[0].split().index("--output") + 1].endswith("nf_a1_seed42_attention")
    assert imp[0].split()[imp[0].split().index("--output") + 1].endswith("importance/nf_a1_seed42")
    assert (c2(w) / "importance" / "nf_a1_seed42_attention" / "attention.csv").is_file()


def test_importance_takes_the_width_timing_json_when_it_holds_the_rate(tmp_path):
    w = world(tmp_path, steps_patch={"steps": ONE_STEP["steps"][:2]})
    t = c2(w) / "timing"
    t.mkdir(parents=True)
    (t / "nf_a1.json").write_text(json.dumps({"seconds_per_row": 0.0002, "rank_a_rows": 5000000, "C_f": 1.0}))
    args = tmp_path / "importance_args.txt"
    queue(w, tmp_path, decisions={"A1_1seed": "ADOPT"}, FAKE_IMPORTANCE_ARGS=args)
    calls = [c.split() for c in args.read_text().splitlines()]
    assert any(c[c.index("--timing") + 1].endswith("timing/nf_a1.json") for c in calls if "--timing" in c)


def test_importance_runs_on_the_final_kept_fit_by_default_and_every_step_is_the_owners_option(tmp_path):
    """The plan (section 5, question 6): permutation importance runs once, on the final kept fit, by default.
    STEPS.yaml importance: every_step is the owner's option, one run per step that fits."""
    two = [dict(s, on=True) if s["name"] == "A2" else dict(s) for s in ONE_STEP["steps"]]
    two = [s for s in two if s["name"] in ("A1", "A2")]
    dec = {"A1_1seed": "ADOPT", "A2_1seed": "ADOPT"}
    w = world(tmp_path / "final", steps_patch={"steps": two})
    assert queue(w, tmp_path / "final", decisions=dec).returncode in (0, 5), qlog(w)
    runs = [ln.split()[1] for ln in qlog(w).splitlines() if ln.startswith("start importance_")]
    assert runs == ["importance_nf_a2_seed42"], runs
    w2 = world(tmp_path / "every", steps_patch={"steps": two, "importance": "every_step"})
    assert queue(w2, tmp_path / "every", decisions=dec).returncode in (0, 5), qlog(w2)
    runs = [ln.split()[1] for ln in qlog(w2).splitlines() if ln.startswith("start importance_")]
    assert runs == ["importance_nf_a1_seed42", "importance_nf_a2_seed42"], runs


def test_failed_importance_makes_the_prune_step_wait_never_crash(tmp_path):
    """Decision 1 (e): a missing or failed importance run gives a clear WAIT line; the queue ends with exit 5."""
    w = world(tmp_path, steps_patch=ONE_STEP)
    r = queue(w, tmp_path, decisions={"A1_1seed": "ADOPT"}, FAKE_FAIL_IMPORTANCE=1)
    log = qlog(w)
    assert r.returncode == 5, log
    assert "crash:" not in log and "Traceback" not in r.stderr
    assert "P WAITS: pruning needs" in log and "the importance run failed" in log
    assert "start fit_nf_p_seed42" not in log and "start read_test1_report" not in log   # later steps wait too
    kept = json.loads((c2(w) / "KEPT.json").read_text())
    assert kept["history"][-1].startswith("P: WAIT")


def test_pending_month_out_and_smaller_list_get_their_select_check(tmp_path):
    """Decision 10: the reader's own texts at one seed, '... (pending the SELECT check)', start the SELECT check
    for MONTH OUT and KEEP THE SMALLER LIST, as for every decision that changes the kept inputs. Pruning is read
    at seed 42 only."""
    steps = [dict(s) for s in ONE_STEP["steps"]]
    steps[3]["on"] = True
    imp = "unit,kind,members,drop_udr_ci_high,drop_ap_ci_high\nf_code,single,f_code,-1,-1\n"
    w = world(tmp_path, steps_patch={"steps": steps})
    dec = {"A1_1seed": "ADOPT", "P_1seed": "KEEP THE SMALLER LIST (pending the SELECT check)",
           "B_1seed": "MONTH OUT (pending the SELECT check)"}
    r = queue(w, tmp_path, decisions=dec, FAKE_IMPORTANCE_CSV=imp)
    log = qlog(w)
    assert r.returncode in (0, 5), log
    assert "start read_P_select" in log and "start read_B_select" in log
    assert "start fit_nf_p_seed43" not in log and "start read_P_3seed" not in log
    kept = json.loads((c2(w) / "KEPT.json").read_text())
    assert kept["input_set"] == "a1p" and kept["month"] == "out"
    # a pruning read that asked for more seeds stops: it is read at seed 42 only
    w2 = world(tmp_path / "b", steps_patch=ONE_STEP)
    r = queue(w2, tmp_path / "b", decisions={"A1_1seed": "ADOPT", "P_1seed": "RUN SEEDS 43 AND 44"},
              FAKE_IMPORTANCE_CSV=imp)
    assert r.returncode == 3 and "read at seed 42 only" in qlog(w2)


def test_lift_run_table_carries_the_downstream_sha256(tmp_path):
    """Decision 11 (review item 18): the downstream job records its DS_SELECT predictions' sha256; the planner's
    lift run table and the read's inputs record carry it."""
    w = world(tmp_path, steps_patch={"steps": ONE_STEP["steps"][:2]})
    fake = w / NF_REL / "nf_downstream.py"
    fake.write_text(
        "import hashlib, json, os, sys\n"
        "a = sys.argv[1:]\n"
        "name = a[a.index('--name') + 1]\n"
        "out = os.path.join(os.environ['NF_OUT'], 'downstream', name)\n"
        "p = os.path.join(out, 'base_raw', 'fit', 'predictions.parquet')\n"
        "os.makedirs(os.path.dirname(p), exist_ok=True)\n"
        "open(p, 'wb').write(name.encode())\n"
        "sha = hashlib.sha256(name.encode()).hexdigest()\n"
        "rel = os.path.relpath(p, os.getcwd())\n"
        "json.dump({'name': name, 'predictions': {'base_raw': rel}, 'predictions_sha256': {'base_raw': sha}},"
        " open(os.path.join(out, 'summary.json'), 'w'))\n")
    r = queue(w, tmp_path, decisions={"A1_1seed": "ADOPT"})
    assert r.returncode in (0, 5), qlog(w)
    import hashlib
    table = json.loads((c2(w) / "reads" / "A1_lift.runs.json").read_text())
    inputs = json.loads((c2(w) / "reads" / "A1_lift.inputs.json").read_text())
    for row, tag in zip(table["runs"], ("nf_a1_seed42", "control_seed42")):
        assert row["downstream_sha256"] == hashlib.sha256(tag.encode()).hexdigest() == row["predictions_sha256"]
    assert all(r_["predictions_sha256"] for r_ in inputs["runs"])


def test_calendar_cyclical_step_is_config_only_and_read_under_the_month_rule(tmp_path):
    """The optional calendar step C: datetime.encoding cyclical by config, its own list (sin and cos numbers for
    every calendar field, and is_weekend when asked), read with --rule calendar against the kept fit, SELECT-checked."""
    steps = [dict(s) for s in ONE_STEP["steps"]]
    steps[2]["on"] = False
    steps[4].update({"on": True, "is_weekend": True})
    w = world(tmp_path, steps_patch={"steps": steps})
    r = queue(w, tmp_path, decisions={"A1_1seed": "ADOPT", "C_1seed": "CALENDAR CYCLICAL (pending the SELECT check)"})
    log = qlog(w)
    assert r.returncode in (0, 5), log
    cfg_text = (w / NF_REL / "configs" / "nf_c.yaml").read_text()
    head = cfg_text.splitlines()[0]
    assert "input set a1;" in head and "calendar cyclical with is_weekend" in head
    import yaml
    cfg = yaml.safe_load(cfg_text)
    assert cfg["datetime"]["encoding"] == "cyclical" and cfg["datetime"]["is_weekend"] is True
    lst = (w / cfg["predictors"]["csv_path"]).read_text().splitlines()
    names = [ln.split(",")[0] for ln in lst[1:]]
    for f in ("month", "day", "hour", "day_of_week"):
        assert f not in names and f"{f}_sin" in names and f"{f}_cos" in names
    assert "is_weekend" in names
    assert "start fit_nf_c_seed42" in log and "start read_C_1seed" in log and "start read_C_select" in log
    kept = json.loads((c2(w) / "KEPT.json").read_text())
    assert kept["calendar"] == "cyclical_weekend" and kept["runs"]["42"].endswith("runs/nf_c/seed42")
    v = run(w, tmp_path, "nf_make_configs.py", "--verify")
    assert v.returncode == 0, v.stdout + v.stderr


def test_artifact_check_wait_for_the_control_checkpoint_runs_again_before_the_first_fit(tmp_path):
    """The data lane's note: a control checkpoint not on disk yet gives WAIT. The preflight accepts a WAIT that is
    only about checkpoints; the queue runs the check again, with the control's own, before the first candidate fit.
    Any other WAIT or FAIL stops."""
    sys.path.insert(0, str(Path(__file__).resolve().parents[4] / NF_REL))
    import nf_plan
    wait = {"result": "WAIT", "lines": {"base_identical": {"result": "PASS"}, "ckpt_control": {"result": "WAIT"}}}
    ok, why = nf_plan.artifact_state(wait)
    assert ok and "runs the check again" in why
    assert not nf_plan.artifact_state({"result": "WAIT", "lines": {"vocab": {"result": "WAIT"}}})[0]
    assert not nf_plan.artifact_state({"result": "FAIL", "lines": {"base_identical": {"result": "FAIL"}}})[0]
    assert not nf_plan.artifact_state(None)[0]
    w = world(tmp_path, steps_patch={"steps": ONE_STEP["steps"][:2]})
    (c2(w) / "artifact").mkdir(parents=True, exist_ok=True)
    (c2(w) / "artifact" / "artifact_check.json").write_text(json.dumps(wait))
    (w / NF_REL / "nf_check_artifact.py").write_text(
        "import json, os, sys\n"
        "assert '--checkpoints' in sys.argv\n"
        "p = os.path.join(os.environ['NF_OUT'], 'artifact', 'artifact_check.json')\n"
        "json.dump({'result': 'PASS', 'lines': {}, 'checkpoints': sys.argv[2:]}, open(p, 'w'))\n")
    r = queue(w, tmp_path, decisions={"A1_1seed": "KEEP THE CONTROL"})
    log = qlog(w)
    assert r.returncode in (0, 5), log
    assert log.index("start artifact_recheck") < log.index("start fit_nf_a1_seed42")
    rec = json.loads((c2(w) / "artifact" / "artifact_check.json").read_text())
    assert any(c.endswith("retrain_seed42/best.ckpt") for c in rec["checkpoints"])
