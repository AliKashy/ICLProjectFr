"""The source guard prints the pandas version and stops in one clear line when it is older than 2.0 (faked
versions; nothing else of the guard runs then)."""

import importlib.util
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
NF = ROOT / "fraud" / "experiments" / "features" / "new_fields"


def _guard():
    if "nf_guard" not in sys.modules:
        spec = importlib.util.spec_from_file_location("nf_guard", NF / "nf_guard.py")
        mod = importlib.util.module_from_spec(spec)
        sys.modules["nf_guard"] = mod
        spec.loader.exec_module(mod)
    return sys.modules["nf_guard"]


def test_pandas_versions():
    g = _guard()
    for ok in ("2.0.0", "2.0.0rc1", "2.3.3", "2.10.1"):
        assert g.pandas_problem(ok) is None, ok
    for old in ("1.1.5", "1.5.3", "0.25.3"):
        line = g.pandas_problem(old)
        assert line == (f"STOP: pandas {old} is installed; the new-fields tools need pandas 2.0 or later. "
                        "Ask the owner before installing another version."), old
        assert "\n" not in line
    assert g.pandas_problem(None).startswith("STOP: pandas is not installed;")
    assert g.pandas_problem("dev") is not None


def test_an_old_pandas_stops_the_guard_before_anything_else(monkeypatch, capsys):
    g = _guard()
    monkeypatch.setattr(g, "pandas_version", lambda: "1.5.3")

    def never(args):
        raise AssertionError("the guard ran with an old pandas")

    monkeypatch.setattr(g, "run", never)
    assert g.main([]) == g.C.STOP == 3
    out = capsys.readouterr().out.splitlines()
    assert out == ["pandas 1.5.3", "STOP: pandas 1.5.3 is installed; the new-fields tools need pandas 2.0 or later. "
                   "Ask the owner before installing another version."]


def test_a_current_pandas_is_printed_and_the_guard_runs(monkeypatch, capsys):
    g = _guard()
    monkeypatch.setattr(g, "pandas_version", lambda: "2.3.3")
    monkeypatch.setattr(g, "run", lambda args: g.C.OK)
    assert g.main([]) == 0
    assert capsys.readouterr().out.splitlines()[0] == "pandas 2.3.3"
