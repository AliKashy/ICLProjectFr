"""Month-like fields and month redundancy on the synthetic world. Nothing is removed."""

import pandas as pd

from new_fields_checks_helpers import dry_world


def _mo():
    return pd.read_csv(dry_world()["out"] / "month_overlap.csv", keep_default_na=False).set_index("field")


def _st():
    return pd.read_csv(dry_world()["out"] / "field_status.csv", keep_default_na=False).set_index("field")


def test_planted_month_code_and_timestamp_are_flagged():
    st = _st()
    assert "calendar_code" in st.loc["syn_month_code", "reasons"]
    assert "overlaps_month" in st.loc["syn_month_code", "reasons"]
    # the reviewers' decision D3d: a field that tracks time is held (WAIT tracks_time, which folds the old FLAG
    # absolute_time in), and a raw source whose values are dates stops (raw_date)
    assert "WAIT tracks_time" in st.loc["syn_epoch", "reasons"] and "STOP raw_date" in st.loc["syn_epoch", "reasons"]


def test_days_before_unrelated_to_month_is_not_flagged():
    mo = _mo()
    assert mo.loc["syn_clean_days", "carries_date"] == "yes"
    assert mo.loc["syn_clean_days", "flagged"] == "no"
    assert float(mo.loc["syn_clean_days", "month_v"]) < 0.3


def test_june_shift_is_flagged_by_psi():
    assert "drift_june" in _st().loc["syn_june_shift", "reasons"]
    assert float(_mo().loc["syn_june_shift", "psi_june"]) >= 0.25


def test_statement_holds_the_field_and_keeps_month():
    mo = _mo()
    s = mo.loc["syn_month_code", "statement"]
    assert "repeats month on its present values" in s and "it is held until the reviewers record keep or drop" in s and "month stays" in s
    assert "the screen's view: not given (information)" in s and "month leaves only through the month-out step" in s
    assert all("month looks repetitive" not in x for x in mo["statement"])


def test_nothing_is_removed():
    fm = pd.read_csv(dry_world()["folder"] / "FIELD_MAP.csv", keep_default_na=False)
    assert set(_mo().index) == set(fm["name"])
