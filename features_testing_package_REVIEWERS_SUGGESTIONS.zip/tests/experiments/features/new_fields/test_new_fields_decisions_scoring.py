"""The reviewers' decisions D4b and D9-Y22 of 2 November in the width timing tool: a fitted checkpoint's scoring
latency (single windows and the scoring batch, median and 99th percentile, the input count; figures only) and the
memory rule on the scoring pass (an out-of-memory pass halves the eval batch). The importance lane's synthetic
checkpoint, on the CPU."""
import json
import sys
from pathlib import Path

import pytest
from omegaconf import OmegaConf

NF = Path(__file__).resolve().parents[4] / "fraud/experiments/features/new_fields"
sys.path.insert(0, str(NF))
sys.path.insert(0, str(Path(__file__).resolve().parent))


@pytest.fixture
def scored(tmp_path, monkeypatch):
    from test_new_fields_importance_world import synthetic_world
    import nf_time_width as TW
    cfg, checkpoint, raw, _ = synthetic_world(tmp_path, accounts=16, files=2)
    config = tmp_path / "config.yaml"
    OmegaConf.save(cfg, config)
    monkeypatch.setenv("NF_OUT", str(tmp_path / "c2"))
    return TW, config, checkpoint, tmp_path


def test_the_scoring_timing_writes_figures_only(scored, capsys):
    TW, config, ckpt, tmp = scored
    assert TW.main(["score", "--config", str(config), "--checkpoint", str(ckpt), "--run", "nf_b",
                    "--batches", "3", "--windows", "5"]) == 0
    rec = json.loads((tmp / "c2" / "timing" / "nf_b_scoring.json").read_text())
    assert rec["inputs"] == 4 and rec["window_seconds"]["n"] == 5 and rec["batch_seconds"]["n"] >= 1
    assert rec["window_seconds"]["median"] > 0 and rec["window_seconds"]["p99"] >= rec["window_seconds"]["median"]
    out = capsys.readouterr().out
    assert "PASS" not in out and "FAIL" not in out and "figures only" in out
    assert len(out.splitlines()) <= 40


def test_an_out_of_memory_scoring_pass_halves_the_eval_batch(scored, monkeypatch):
    TW, config, ckpt, tmp = scored
    import torch
    real = TW.score_pass
    calls = []

    def oom_once(*a, **k):
        calls.append(1)
        if len(calls) == 1:
            raise torch.cuda.OutOfMemoryError("CUDA out of memory (injected)")
        return real(*a, **k)
    monkeypatch.setattr(TW, "score_pass", oom_once)
    assert TW.main(["score", "--config", str(config), "--checkpoint", str(ckpt), "--run", "nf_b",
                    "--batches", "2", "--windows", "2", "--min-eval", "2"]) == 0
    rec = json.loads((tmp / "c2" / "timing" / "nf_b_scoring.json").read_text())
    assert [a["status"] for a in rec["attempts"]] == ["oom", "ok"]
    assert rec["attempts"][0]["eval_batch_size"] == 11 and rec["eval_batch_size"] == 5
