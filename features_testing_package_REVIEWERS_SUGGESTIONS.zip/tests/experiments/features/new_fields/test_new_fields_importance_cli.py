"""Observable CLI/output contracts, including failure and unchanged-target checks."""
from argparse import Namespace
from pathlib import Path
import sys
from types import SimpleNamespace
import json

import numpy as np
import pandas as pd
import pytest
from omegaconf import OmegaConf

NF = Path(__file__).resolve().parents[4] / "fraud/experiments/features/new_fields"
sys.path.insert(0, str(NF))
from nf_importance import (estimate_cost, enforce_rank_a, assert_same_scores, align_pass,
                           _pass, _timing, render_summary)


def frame():
    return pd.DataFrame(dict(account=["a", "b"], id=["x", "y"], label=[1, 0],
                             amount=[20., 30.], timestamp=["2025-06-01"] * 2,
                             score=np.array([.9, .1], dtype=np.float32)))


def test_cost_covers_all_units_repeats_and_states_overhead():
    cost = estimate_cost(10000, 20, 3, .02, .25)
    assert cost["gpu_hours"] == pytest.approx(61 * 2500 * .02 / 3600)
    assert cost["null_check_extra_passes"] == 2
    assert "variable row count" in cost["note"]


@pytest.mark.parametrize("args", [(0, 1, 1, .1, 1), (5, -1, 1, .1, 1),
    (5, 1, 0, .1, 1), (5, 1, 1, float("nan"), 1), (5, 1, 1, .1, 0)])
def test_bad_cost_inputs(args):
    with pytest.raises(ValueError):
        estimate_cost(*args)


@pytest.mark.parametrize("share", [0, -.25, -np.inf, np.nan, 1.25])
def test_full_share_promotion_keeps_existing_invalid_share_validation(share):
    from nf_importance import account_share_for
    with pytest.raises(ValueError, match="account share"):
        account_share_for({"family:amount": ["customer"]}, share)


@pytest.mark.parametrize("start,end", [(8244, 8259), (4950, 4954), (8228, 8244)])
def test_no_fallback_to_decision_or_validation_population(start, end):
    with pytest.raises(ValueError, match="RANK-A"):
        enforce_rank_a(OmegaConf.create({"eval": {"file_start": start, "file_end": end}}))


def test_identity_detects_one_float_bit_and_no_rows():
    a = frame()
    assert_same_scores(a, a.copy())
    b = a.copy()
    b.loc[0, "score"] = np.nextafter(b.loc[0, "score"], np.float32(1))
    with pytest.raises(ValueError, match="bitwise"):
        assert_same_scores(a, b)
    with pytest.raises(ValueError, match="no scored"):
        assert_same_scores(a.iloc[:0], a.iloc[:0])


def test_alignment_reorders_but_rejects_changed_labels_amounts_and_population():
    a = frame()
    assert np.array_equal(align_pass(a, a.iloc[::-1]), a.score)
    for column, value in [("label", 0), ("amount", 300), ("timestamp", "2025-06-02")]:
        b = a.copy()
        b.loc[0, column] = value
        with pytest.raises(AssertionError):
            align_pass(a, b)
    with pytest.raises(ValueError, match="population"):
        align_pass(a, a.iloc[:1])


def test_failed_pass_preserves_exposure(tmp_path):
    records = []
    def write(path, obj):
        Path(path).write_text(json.dumps(obj))
    common = SimpleNamespace(C2=tmp_path, write_json=write,
                              append_jsonl=lambda p, obj: records.append(obj.copy()))
    def fail(**kwargs):
        assert (tmp_path / "failure.exposure.json").exists()
        raise RuntimeError("broken scorer")
    runner = SimpleNamespace(account_share=.25, cfg=OmegaConf.create({
        "eval": {"base": "data", "file_start": 8228, "file_end": 8243}}), score=fail)
    args = Namespace(account_share=.25, seed=7)
    with pytest.raises(RuntimeError, match="broken scorer"):
        _pass(runner, tmp_path, "failure", common, "hash", args)
    record = json.loads((tmp_path / "failure.exposure.json").read_text())
    assert record["status"] == "failed" and record["error"] == "broken scorer"
    assert [r["status"] for r in records] == ["started", "failed"]
    assert record["files"]["start"] == 8228 and record["files"]["end"] == 8243


def test_timing_never_guesses_per_row_from_target_subset(tmp_path):
    path = tmp_path / "timing.json"
    path.write_text(json.dumps(dict(started_utc="2026-11-02T00:00:00Z",
        ended_utc="2026-11-02T00:00:10Z", n_predictions=100, rank_a_rows=2000)))
    args = Namespace(timing=str(path), seconds_per_row=None, rank_a_rows=None)
    assert _timing(args) == (2000, .1)
    path.write_text("{}")
    with pytest.raises(ValueError, match="measured"):
        _timing(args)


def test_summary_has_no_adoption_and_states_uncertainty():
    common = SimpleNamespace(screen=lambda title, lines: "\n".join([title] + lines))
    rows = [dict(unit="amount", kind="single", drop_udr=.1, drop_ap=.01)]
    report = render_summary(rows, common)
    assert "not training-seed uncertainty" in report
    assert "adoption threshold" in report
    assert "same alert count" in report


def test_run_real_synthetic_scorer_writes_complete_outputs_and_summary(tmp_path, monkeypatch):
    from test_new_fields_importance_world import synthetic_world
    import nf_common
    import nf_importance
    cfg, checkpoint, raw, _ = synthetic_world(tmp_path, accounts=64, files=16)
    config = tmp_path / "config.yaml"
    OmegaConf.save(cfg, config)
    monkeypatch.setattr(nf_common, "C2", tmp_path / "records")
    monkeypatch.setattr(nf_common, "busy", lambda: [])
    out = tmp_path / "importance"
    rc = nf_importance.main(["run", "--config", str(config), "--checkpoint", str(checkpoint),
        "--output", str(out), "--account-share", "1", "--repeats", "2", "--draws", "20",
        "--units", "singles", "--profile-fields", "profile",
        "--seconds-per-row", "0.001", "--rank-a-rows", str(len(raw))])
    assert rc == 0
    result = pd.read_csv(out / "importance.csv")
    assert set(result.unit) == {"amount", "profile", "category", "month"}
    assert len(result) == 4 and set(result.repeats) == {2}
    assert result.loc[result.unit.eq("profile"), "donor_unit"].item() == "account"
    assert result.loc[result.unit.eq("month"), "artificial_time_fixed"].item()
    assert {"baseline_ap", "perturbed_ap", "baseline_udr", "perturbed_udr", "drop_ap_ci_low",
            "coverage", "measured_scoring_seconds", "attention_ranks"} <= set(result.columns)
    assert json.loads((out / "identity_check.json").read_text())["bitwise_equal"]
    engine = json.loads((out / "engine_check.json").read_text())
    assert set(engine["metrics"]) == {"udr", "vdr", "fpr", "ap"}
    assert engine["rows"] == int(result.rows.iloc[0])
    assert len(list(out.glob("*.exposure.json"))) == 11  # 2 null, reference, 4 x 2 repeats
    assert (out / "completed.json").exists() and (out / "attention.csv").exists()
    assert len((out / "summary.txt").read_text().splitlines()) <= 40
    assert nf_importance.main(["summary", "--output", str(out)]) == 0
    with pytest.raises(FileExistsError):
        nf_importance.main(["run", "--config", str(config), "--checkpoint", str(checkpoint),
            "--output", str(out), "--seconds-per-row", "0.001", "--rank-a-rows", "384"])


def test_budget_stop_happens_before_scorer_load(tmp_path, monkeypatch):
    from test_new_fields_importance_world import synthetic_world
    import nf_common
    import nf_importance
    import nf_importance_scoring
    cfg, checkpoint, _, _ = synthetic_world(tmp_path, accounts=64, files=16)
    config = tmp_path / "config.yaml"
    OmegaConf.save(cfg, config)
    monkeypatch.setattr(nf_common, "busy", lambda: [])
    def forbidden(*a, **kw):
        pytest.fail("scorer loaded above cost limit")
    monkeypatch.setattr(nf_importance_scoring, "ScoreRunner", forbidden)
    out = tmp_path / "importance"
    assert nf_importance.main(["run", "--config", str(config), "--checkpoint", str(checkpoint),
        "--output", str(out), "--seconds-per-row", "1", "--rank-a-rows", "1000000",
        "--max-gpu-hours", "0.01"]) == 3
    assert not out.exists()


def test_summary_rereads_undefined_metrics_as_json_nulls():
    common = SimpleNamespace(screen=lambda title, lines: "\n".join([title] + lines))
    text = render_summary([dict(unit="none", kind="single", drop_udr=None, drop_ap=None)], common)
    assert "nan" in text


@pytest.mark.parametrize("amount_case", ["valid", "missing", "nan", "negative", "zero"])
@pytest.mark.parametrize("no_fraud", [False, True])
def test_shared_reader_baseline_agrees_with_ties_and_undefined_amounts(amount_case, no_fraud):
    pytest.importorskip("nf_ranked", reason="requires the shared reader lane")
    from nf_importance import engine_check
    data = pd.DataFrame({
        "account": [f"a{i // 4}" for i in range(500)],
        "id": [str(i) for i in range(500)],
        "label": [0 if no_fraud else int(i % 7 == 0) for i in range(500)],
        "score": np.round(np.linspace(0.99, 0.01, 500), 1),
        "amount": np.arange(1, 501, dtype=float),
    })
    if amount_case == "missing":
        data = data.drop(columns="amount")
    elif amount_case != "valid":
        data["amount"] = {"nan": np.nan, "negative": -1.0, "zero": 0.0}[amount_case]
    report = engine_check(data)
    assert report["rows"] == 500
    for pair in report["metrics"].values():
        if pair["importance"] is None:
            assert pair["reader"] is None
        else:
            assert pair["importance"] == pytest.approx(pair["reader"], abs=1e-12)
    if amount_case != "valid" or no_fraud:
        assert report["metrics"]["vdr"] == {"importance": None, "reader": None}


@pytest.mark.parametrize("metric,missing_amount", [("udr", False), ("vdr", True)])
def test_baseline_check_does_not_report_agreement_after_reader_disagrees(monkeypatch, metric, missing_amount):
    reader = pytest.importorskip("nf_ranked", reason="requires the shared reader lane")
    from nf_importance import engine_check
    original = reader.outsort
    def changed(*args, **kwargs):
        result = original(*args, **kwargs)
        result[metric] = .5
        return result
    monkeypatch.setattr(reader, "outsort", changed)
    data = frame().drop(columns="amount") if missing_amount else frame()
    with pytest.raises(ValueError, match="differ.*" + metric):
        engine_check(data)
