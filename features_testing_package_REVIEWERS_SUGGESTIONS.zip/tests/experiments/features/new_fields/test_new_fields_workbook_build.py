"""Tests for the feature workbook builder and the reviewers' draft lists (no bank data, no network)."""

import csv
import importlib.util
import re
import shutil
import zipfile
from pathlib import Path

import pytest
from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parents[4]
NF = ROOT / "fraud" / "experiments" / "features" / "new_fields"
TNF = Path(__file__).resolve().parent

SHEETS = ["README", "Current features", "Model 15298 features", "TFM V22B features",
          "Other proposed features", "Final list (draft)", "Excluded", "Decisions"]
LISTS = ["DRAFT_TFM_FIELDS_UNCONFIRMED.csv", "DRAFT_15298_RECIPES_UNCONFIRMED.csv",
         "DRAFT_OTHER_PROPOSED_UNCONFIRMED.csv", "DRAFT_FEATURE_ATTRIBUTES_UNCONFIRMED.csv", "KEEP_DECISIONS.csv"]
SHIPPED_XLSX = NF / "FEATURE_WORKBOOK_REVIEWERS_SUGGESTIONS.xlsx"
# The words are assembled from parts so this file does not contain them.
# (joined at run time, so neither this file nor its compiled form holds them).
_PARTS = [("cla", "ude"), ("chat", "gpt"), ("co", "dex"), ("open", "ai"), ("anthro", "pic")]
FORBIDDEN = re.compile("|".join("".join(p) for p in _PARTS), re.I)
ABSOLUTE = re.compile("|".join(["/" + "home/", "/" + "tmp/", "/" + "Users/"]))
TAGS = re.compile("".join([r"(?<![A-Za-z0-9_])(", "C", "L|", "C", "H)(?![A-Za-z0-9_])"]))
RECORDS = [ROOT / "11_01_2026" / "features_work" / "CANDIDATE_FIELDS_UNCONFIRMED.csv",
           ROOT / "11_01_2026" / "features_work" / "15298_RECIPE_CROSSWALK.csv",
           ROOT / "waqas" / "feature_work" / "all_features_master.csv"]


def _load(name, filename):
    spec = importlib.util.spec_from_file_location(name, NF / filename)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


wbmod = _load("nf_workbook_builder_under_test", "build_feature_workbook.py")
drafts = _load("nf_workbook_drafts_under_test", "nf_workbook_drafts.py")


def rows(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_rows(path, header, data):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=header, lineterminator="\n")
        w.writeheader()
        for r in data:
            w.writerow(r)


@pytest.fixture()
def inputs(tmp_path):
    """A copy of the shipped lists in a temporary folder, so a test can edit them."""
    d = tmp_path / "in"
    d.mkdir()
    for n in LISTS:
        shutil.copy(NF / n, d / n)
    shutil.copy(ROOT / "fraud" / "configs" / "predictors.csv", d / "predictors.csv")
    return d


def build(d, out, *extra):
    argv = ["--predictors", str(d / "predictors.csv"), "--tfm", str(d / LISTS[0]), "--f15298", str(d / LISTS[1]),
            "--other", str(d / LISTS[2]), "--attributes", str(d / LISTS[3]), "--decisions", str(d / LISTS[4]),
            "--field-map", str(d / "FIELD_MAP.csv"), "--out", str(out), *extra]
    return wbmod.main(argv)


def sheet_rows(ws):
    vals = list(ws.iter_rows(values_only=True))
    header = list(vals[0])
    return header, [dict(zip(header, ["" if v is None else v for v in r])) for r in vals[1:]]


@pytest.fixture()
def built(inputs, tmp_path):
    out = tmp_path / "wb.xlsx"
    assert build(inputs, out) == 0
    return inputs, out, load_workbook(out)


# ---------------------------------------------------------------------------------------------
def test_every_sheet_is_present_in_order_and_opens(built):
    _, out, wb = built
    assert wb.sheetnames == SHEETS
    assert wb["README"]["A1"].value == "REVIEWERS' SUGGESTIONS, NOT FINAL"


def test_row_counts_match_the_csvs(built):
    d, _, wb = built
    pred = rows(d / "predictors.csv")
    tfm, f15298, other, attrs, keep = (rows(d / n) for n in LISTS)
    _, cur = sheet_rows(wb["Current features"])
    assert sum(1 for r in cur if r["row_kind"] == "predictor") == len(pred) == 23
    meta = [r for r in cur if r["row_kind"].startswith("model metadata")]
    assert [r["feature"] for r in meta] == ["time_delta"]
    assert len(sheet_rows(wb["Model 15298 features"])[1]) == len(f15298) == 94
    _, t = sheet_rows(wb["TFM V22B features"])
    assert len(t) == len(tfm) == 217
    assert [r["scope"] for r in t[:120]] == ["v22b_chart"] * 120
    assert all(r["scope"] != "v22b_chart" for r in t[120:])
    assert len(sheet_rows(wb["Other proposed features"])[1]) == len(other)
    assert len(sheet_rows(wb["Decisions"])[1]) == len(keep) == len(attrs)
    n_keep = sum(1 for r in keep if r["verdict"] == "keep")
    n_drop = sum(1 for r in keep if r["verdict"] == "drop")
    assert len(sheet_rows(wb["Final list (draft)"])[1]) == len(pred) + n_keep
    assert len(sheet_rows(wb["Excluded"])[1]) == n_drop


def _structure(path):
    """Every sheet's name, size, frozen panes, filter, column widths, and every cell's value and fill: what a person
    sees, independent of the XML writer openpyxl happens to use (with or without lxml the bytes differ)."""
    wb = load_workbook(path)
    out = []
    for ws in wb.worksheets:
        widths = {k: round(v.width or 0, 2) for k, v in sorted(ws.column_dimensions.items()) if v.width}
        cells = [[(c.value, c.fill.fgColor.rgb if c.fill and c.fill.fill_type else None) for c in row]
                 for row in ws.iter_rows()]
        out.append((ws.title, ws.max_row, ws.max_column, ws.freeze_panes, ws.auto_filter.ref, widths, cells))
    return out


def test_output_is_byte_stable_and_matches_the_shipped_workbook(inputs, tmp_path):
    """Two builds in the same environment give the same bytes; the shipped workbook holds the same sheets, cells and
    layout as a fresh build (compared by content, so the test does not depend on lxml being present)."""
    a, b = tmp_path / "a.xlsx", tmp_path / "b.xlsx"
    assert build(inputs, a) == 0
    assert build(inputs, b) == 0
    assert a.read_bytes() == b.read_bytes()
    assert _structure(a) == _structure(SHIPPED_XLSX), "rerun build_feature_workbook.py and ship the result"


def test_forbidden_word_scan_of_the_unzipped_xml_is_empty(built):
    _, out, _ = built
    hits = []
    with zipfile.ZipFile(out) as z:
        for name in z.namelist():
            text = z.read(name).decode("utf-8", errors="replace")
            hits += [(name, m.group(0)) for m in FORBIDDEN.finditer(text)]
            hits += [(name, m.group(0)) for m in TAGS.finditer(text)]
            hits += [(name, "absolute path") for _ in ABSOLUTE.finditer(text)]
    assert hits == []
    raw = out.read_bytes()
    assert not FORBIDDEN.search(raw.decode("latin-1")) and not TAGS.search(raw.decode("latin-1"))


def test_lane_files_carry_no_forbidden_words():
    files = [NF / "build_feature_workbook.py", NF / "nf_workbook_drafts.py", Path(__file__)] + [NF / n for n in LISTS]
    for f in files:
        text = f.read_text(encoding="utf-8")
        assert not FORBIDDEN.search(text), f.name
        assert not TAGS.search(text), f.name


def test_no_formulas_frozen_headers_filters(built):
    _, _, wb = built
    for name in SHEETS[1:]:
        ws = wb[name]
        assert ws.freeze_panes == "B2"
        assert ws.auto_filter.ref == f"A1:{ws.cell(row=1, column=ws.max_column).column_letter}{ws.max_row}"
        assert ws.cell(row=2, column=1).alignment.wrap_text
        for row in ws.iter_rows():
            for c in row:
                assert c.data_type != "f", (name, c.coordinate)


def test_one_colour_per_verdict(built):
    _, _, wb = built
    header, data = sheet_rows(wb["Decisions"])
    col = header.index("verdict") + 1
    seen = {}
    for i, r in enumerate(data, 2):
        seen.setdefault(r["verdict"], set()).add(wb["Decisions"].cell(row=i, column=col).fill.fgColor.rgb[-6:])
    assert all(len(v) == 1 for v in seen.values())
    assert {k: v.pop() for k, v in seen.items()} == {k: wbmod.FILLS[k] for k in seen}


def test_final_excluded_decisions_come_from_keep_decisions(inputs, tmp_path):
    keep_path = inputs / "KEEP_DECISIONS.csv"
    keep = rows(keep_path)
    holds = [r for r in keep if r["verdict"] == "hold"]
    keeps = [r for r in keep if r["verdict"] == "keep"]
    to_drop, to_decide = holds[0]["name"], keeps[0]["name"]
    for r in keep:
        if r["name"] == to_drop:
            r.update(verdict="drop", reason="excluded_by_sumegha: test", decided_by="Test Person", date="2026-11-03")
        if r["name"] == to_decide:
            r.update(decided_by="Test Person", date="2026-11-03")
    write_rows(keep_path, wbmod.KEEP_COLUMNS, keep)
    out = tmp_path / "wb.xlsx"
    assert build(inputs, out) == 0
    wb = load_workbook(out)
    _, final = sheet_rows(wb["Final list (draft)"])
    _, excl = sheet_rows(wb["Excluded"])
    _, dec = sheet_rows(wb["Decisions"])
    assert to_drop in {r["feature"] for r in excl}
    assert to_drop not in {r["feature"] for r in final}
    shown = {r["feature"]: r["shown_as"] for r in final}
    assert shown[to_decide] == "keep"
    assert all(shown[r["name"]] == "unresolved" for r in keeps[1:] if r["decided_by"] == "proposed")
    assert [r["name"] for r in dec] == [r["name"] for r in keep]
    assert {r["feature"] for r in excl} == {r["name"] for r in keep if r["verdict"] == "drop"}
    new_names = {r["feature"] for r in final if r["group"] != "current"}
    assert new_names == {r["name"] for r in keep if r["verdict"] == "keep"}


def test_unresolved_rows_stay_visible(built):
    d, _, wb = built
    keep = rows(d / "KEEP_DECISIONS.csv")
    pending = {r["name"] for r in keep if r["verdict"] in ("hold", "unresolved")}
    assert pending
    _, final = sheet_rows(wb["Final list (draft)"])
    assert not pending & {r["feature"] for r in final}
    _, dec = sheet_rows(wb["Decisions"])
    assert pending <= {r["name"] for r in dec}
    _, f = sheet_rows(wb["Model 15298 features"])
    shown = {r["name"]: r["verdict"] for r in f}
    for r in keep:
        if r["name"] in shown:
            assert shown[r["name"]] == r["verdict"]
    _, final_rows = sheet_rows(wb["Final list (draft)"])
    assert all(r["shown_as"] == "unresolved" for r in final_rows if r["decided_by"] == "proposed")


def test_predictors_export_uses_output_names_and_types(inputs, tmp_path):
    out, pred_out = tmp_path / "wb.xlsx", tmp_path / "predictors_new.csv"
    assert build(inputs, out, "--export-predictors", str(pred_out), "--include-proposed") == 0
    with open(pred_out, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        exported = list(reader)
        assert reader.fieldnames == ["feature", "type", "source", "version", "description"]
    keep = rows(inputs / "KEEP_DECISIONS.csv")
    base = rows(inputs / "predictors.csv")
    assert [r["feature"] for r in exported[:23]] == [r["feature"] for r in base]
    assert exported[:23] == base
    new = exported[23:]
    assert [r["feature"] for r in new] == [r["name"] for r in keep if r["verdict"] == "keep"]
    assert all(r["type"] in ("continuous", "categorical") for r in exported)
    assert all(r["source"] == "raw" and r["version"] == "2" for r in new)
    assert all(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", r["feature"]) for r in exported)
    assert "transaction_dttm" not in {r["feature"] for r in exported}
    assert not any(r["feature"].startswith("derived__days_since") for r in new)
    decided = tmp_path / "decided.csv"
    assert build(inputs, out, "--export-predictors", str(decided)) == 0
    assert len(rows(decided)) == 23, "by default only rows a person decided are exported"


@pytest.mark.parametrize("change, message", [
    ("sumegha", "excluded_by_sumegha is yes"),
    ("repeat", "name repeats"),
    ("verdict", "is not one of"),
    ("header", "columns must be exactly"),
    ("base", "baseline"),
])
def test_wrong_inputs_are_refused(inputs, tmp_path, capsys, change, message):
    keep_path, attr_path = inputs / "KEEP_DECISIONS.csv", inputs / LISTS[3]
    keep, attrs = rows(keep_path), rows(attr_path)
    kept = next(r for r in keep if r["verdict"] == "keep")
    header = wbmod.KEEP_COLUMNS
    if change == "sumegha":
        for a in attrs:
            if a["name"] == kept["name"]:
                a["excluded_by_sumegha"] = "yes"
        write_rows(attr_path, list(attrs[0].keys()), attrs)
    elif change == "repeat":
        keep.append(dict(kept))
    elif change == "verdict":
        kept["verdict"] = "maybe"
    elif change == "header":
        header = list(reversed(wbmod.KEEP_COLUMNS))
    elif change == "base":
        keep.append(dict(kept, name="transaction_amt"))
    write_rows(keep_path, header, keep)
    assert build(inputs, tmp_path / "wb.xlsx") == 2
    assert message in capsys.readouterr().out


def test_adding_rows_needs_no_formula_and_flows_through(inputs, tmp_path):
    attrs, keep = rows(inputs / LISTS[3]), rows(inputs / "KEEP_DECISIONS.csv")
    attrs.append(dict({k: "" for k in attrs[0]}, name="added_feature", model_type="continuous", group="v22b",
                      origin="TFM V22B", description="Added by a test"))
    keep.append({"name": "added_feature", "group": "v22b", "verdict": "keep", "reason": "test",
                 "evidence": "test", "decided_by": "Test Person", "date": "2026-11-03", "definition_version": "1"})
    write_rows(inputs / LISTS[3], list(attrs[0].keys()), attrs)
    write_rows(inputs / "KEEP_DECISIONS.csv", wbmod.KEEP_COLUMNS, keep)
    out = tmp_path / "wb.xlsx"
    assert build(inputs, out) == 0
    _, final = sheet_rows(load_workbook(out)["Final list (draft)"])
    assert final[-1]["feature"] == "added_feature" and final[-1]["shown_as"] == "keep"


def test_field_map_values_win(inputs, tmp_path):
    keep = rows(inputs / "KEEP_DECISIONS.csv")
    name = next(r["name"] for r in keep if r["verdict"] == "keep")
    write_rows(inputs / "FIELD_MAP.csv", ["name", "description", "model_type"],
               [{"name": name, "description": "from the field map", "model_type": ""}])
    out = tmp_path / "wb.xlsx"
    assert build(inputs, out) == 0
    _, final = sheet_rows(load_workbook(out)["Final list (draft)"])
    row = next(r for r in final if r["feature"] == name)
    assert row["description"] == "from the field map" and row["type"] in ("continuous", "categorical")


# ---------------------------------------------------------------------------------------------
# The draft lists against the records (skipped where the records are not in the tree).
needs_records = pytest.mark.skipif(not all(p.is_file() for p in RECORDS), reason="records not in this tree")


def rank_order(rank):
    """Sort key for V22B ranks: the numbers in order, then the rows with no rank (the 97 TFM rows off the chart have a
    blank rank, so a changed one must show up in the comparison, not stop it with int(''))."""
    s = str(rank).strip()
    return (0, int(s), "") if s.isdigit() else (1, 0, s)


def test_blank_v22b_ranks_are_no_rank_in_the_drafts_and_in_their_record_check():
    assert drafts.rank_number("") is None and drafts.rank_number("   ") is None and drafts.rank_number(None) is None
    assert drafts.rank_number("8") == 8 and drafts.rank_number(" 75 ") == 75
    assert sorted(["75", "unranked B", "6", "", "22"], key=rank_order) == ["6", "22", "75", "", "unranked B"]
    unranked = [r for r in rows(NF / LISTS[0]) if not r["v22b_importance_rank"]]
    assert len(unranked) == 97
    for r in unranked[:5] + [dict(unranked[0], v22b_importance_rank="  ")]:
        assert drafts.tfm_name_of(r, set())   # a name, no int('') on the blank rank


def test_shipped_tfm_list_applies_the_feature_review():
    tfm = rows(NF / LISTS[0])
    chart = [r for r in tfm if r["scope"] == "v22b_chart"]
    assert len(tfm) == 217 and len(chart) == 120
    counts = {k: sum(1 for r in chart if r["draft_include"] == k) for k in ("yes", "hold", "no")}
    assert counts == {"yes": 78, "hold": 13, "no": 29}
    by_rank = {r["v22b_importance_rank"]: r for r in chart}
    for rank, text in drafts.SEVEN_HOLD.items():
        assert by_rank[rank]["draft_include"] == "hold"
        assert by_rank[rank]["draft_reason"].startswith(text)
        assert "non-engineered fields" not in by_rank[rank]["draft_reason"]
    r75 = by_rank["75"]
    assert r75["name"] == "days_until__card_expiration_dt" and "Days until expiry" in r75["draft_reason"]
    assert "must be on or before" not in r75["availability_note"]


def test_shipped_15298_list_covers_all_94_outputs():
    f = rows(NF / LISTS[1])
    assert [int(r["rank_15298"]) for r in f] == list(range(1, 95))
    work = {}
    for r in f:
        work[r["proposed_work_type"]] = work.get(r["proposed_work_type"], 0) + 1
    assert work == {"encoding_definition": 16, "date_derivation": 21, "transaction_history_definition": 21,
                    "claim_history_definition": 5, "event_history_definition": 5, "recipe_definition": 21,
                    "recorded_raw_mapping": 5}
    for r in f:
        assert r["recipe"] or r["left_out_reason"], r["rank_15298"]
        if r["proposed_work_type"] == "encoding_definition":
            assert r["mapping_status"] == "open" and r["equivalence"] == "unverified" and r["raw_alternative"]
        if r["recipe"].startswith(("days_before(", "code(")):
            assert r["source_columns"] not in ("cprsrvc__pisinfo2", "cprsrvc__pisinfo", "user_data_1_strg")
    by_rank = {r["rank_15298"]: r for r in f}
    assert by_rank["48"]["recipe"] == "days_until(card_expiration_dt)"
    assert by_rank["48"]["date_meaning"] == "known_future_date"
    keep = {r["name"]: r for r in rows(NF / "KEEP_DECISIONS.csv")}
    for r in f:
        if r["proposed_work_type"] in ("claim_history_definition", "event_history_definition",
                                       "transaction_history_definition") and r["name"] in keep:
            assert keep[r["name"]]["verdict"] in ("hold", "drop")
            if keep[r["name"]]["group"] == "f15298":
                assert keep[r["name"]]["verdict"] == "hold"


def test_keep_decisions_template_shape():
    keep = rows(NF / "KEEP_DECISIONS.csv")
    with open(NF / "KEEP_DECISIONS.csv", newline="", encoding="utf-8") as fh:
        assert next(csv.reader(fh)) == wbmod.KEEP_COLUMNS
    assert all(r["decided_by"] == "proposed" for r in keep)
    assert all(r["group"] in wbmod.GROUPS for r in keep)
    assert len({r["name"] for r in keep}) == len(keep)


@needs_records
def test_drafts_regenerate_byte_for_byte_from_the_records(tmp_path):
    drafts.build(ROOT, tmp_path, force=True)
    for n in LISTS:
        assert (tmp_path / n).read_bytes() == (NF / n).read_bytes(), n


@needs_records
def test_draft_lists_keep_every_record_row():
    cand = rows(RECORDS[0])
    xw = rows(RECORDS[1])
    master = [r for r in rows(RECORDS[2]) if r["category"] == "model_15298_xgboost_feature"]
    tfm, f = rows(NF / LISTS[0]), rows(NF / LISTS[1])
    assert len(tfm) == len(cand) and len(f) == len(xw) == len(master) == 94
    assert [r["tfm_name"] for r in tfm] == [r["tfm_name"] for r in cand]
    assert [r["feature_15298"] for r in f] == [r["name"] for r in master]
    # the records' count of the pod's columns (224) is reworded to the owner's (227, from the intake's schema) in
    # every row that names it; that rewording is the only other change, so compare after it
    assert sum(drafts.POD_COLUMNS_OLD in c["pod_column_evidence"] for c in cand) == 183
    cand = [{k: v.replace(drafts.POD_COLUMNS_OLD, drafts.POD_COLUMNS_NEW) for k, v in c.items()} for c in cand]
    assert sum(drafts.POD_COLUMNS_NEW in r["pod_column_evidence"] for r in tfm) == 183
    changed = [r["v22b_importance_rank"] or f"unranked {r['tfm_name']}" for r, c in zip(tfm, cand)
               if any(r[k] != c[k] for k in c)]
    assert sorted(changed, key=rank_order) == ["6", "22", "40", "44", "48", "56", "59", "75"]


def test_status_same_transaction_and_plan_exclusions():
    keep = {r["name"]: r for r in rows(NF / "KEEP_DECISIONS.csv")}
    seven = ["derived__days_since__cprcust__astatuschgdt", "inactv_dt", "days_before__cprcust__ebsloginblockdt",
             "cprcust__cardstatdt_card_status_nm3102", "days_before__cprcust__ebslogininterdictfaildt",
             "cpracct__ddaewstxndata_hogan_acct_status", "cprsrvc__pisinfo2_status"]
    for n in seven:
        assert keep[n]["verdict"] == "drop" and keep[n]["reason"].startswith("status:"), n
    for raw in ("falcondecline_indicator", "predecline_indicator", "processor_reason_xcd"):
        assert keep[raw]["verdict"] == "drop" and keep[raw]["reason"].startswith("same_txn_decision:")
        assert keep["prev__" + raw]["verdict"] == "hold"
    for n in ("transaction_advice_xcd", "days_until__prior_action_db_expiration_dt"):
        assert keep[n]["verdict"] == "drop" and keep[n]["reason"].startswith("plan_exclusion:")
    assert keep["days_before__cprcust__onlinebankpwstatuschgdt"]["verdict"] == "keep"  # rank 52, owner's decision


def test_generic_sources_and_new_engineered_names():
    attrs = rows(NF / LISTS[3])
    keep = {r["name"]: r for r in rows(NF / "KEEP_DECISIONS.csv")}
    generic = re.compile(r"^(user_data_\d+_strg|user_data_\d+_num|cprsrvc__pisinfo2?)$")
    for a in attrs:
        for col in a["source_columns"].split(";"):
            if generic.match(col):
                assert keep[a["name"]]["verdict"] != "keep", a["name"]
    raw_cols = {r["pod_column"] for r in rows(NF / LISTS[0]) if r["pod_column"]}
    for a in attrs:
        if a["kind"] == "engineered" and keep[a["name"]]["verdict"] == "keep":
            assert a["name"] not in raw_cols, a["name"]
    f = {r["rank_15298"]: r for r in rows(NF / LISTS[1])}
    assert f["50"]["date_meaning"] == "known_future_date"


def test_readme_counts_match_the_sheets(built):
    d, _, wb = built
    readme = {r[0]: r[1] for r in wb["README"].iter_rows(min_row=3, values_only=True)}
    for name in SHEETS[1:]:
        assert readme[f"Rows: {name}"] == str(wb[name].max_row - 1)
    assert readme["V22B chart draft verdicts"].startswith("120 chart rows: yes 78, hold 13, no 29")
    assert readme["15298 work types"].startswith("94 outputs:")


def test_appendix_c_rows_are_the_built_outputs():
    other = rows(NF / LISTS[2])
    appendix = [r for r in other if r["status"] == "built 26 October (Appendix C)"]
    assert len(appendix) == 16
    names = {"amt_over_balance", "amt_over_merch_lmt", "headroom_balance", "drain_24h", "cnt_5m_log1p",
             "cnt_1h_log1p", "cnt_24h_log1p", "cnt_7d_log1p", "cnt_30d_log1p", "mcc_new_30d", "cp_cnt_5m_log1p",
             "cnp_cnt_24h_log1p", "amt_midrank_30d", "dist_prev_km_log1p", "speed_kmh_log1p", "dist_home_km_log1p"}
    assert {r["name"] for r in appendix} == names
    base_groups = ROOT / "waqas" / "v2" / "features" / "groups.py"
    base_new = ROOT / "waqas" / "v2" / "screen" / "features_new.py"
    if base_groups.is_file() and base_new.is_file():
        code = base_groups.read_text() + base_new.read_text()
        for n in names:
            stem = n.replace("cp_cnt_5m", "cnt_").replace("cnp_cnt_24h", "cnt_")
            assert n in code or "cnt_{w}_log1p" in code or stem in code, n


def test_le_outputs_show_code_c_as_the_proposed_alternative_and_stay_unresolved(built):
    """Integration decision 3, one reading: the decisions table keeps the LE1/LE3 rows with a recorded raw code
    unresolved with the agreed reason; the workbook shows code(c) in the proposed_alternative column."""
    d, _, wb = built
    keep = {r["name"]: r for r in rows(d / "KEEP_DECISIONS.csv")}
    attrs = {r["name"]: r for r in rows(d / LISTS[3])}
    le = [n for n, a in attrs.items() if n.startswith("derived_le") and a["raw_alternative"] and not a["recipe"]]
    assert len(le) == 15
    for n in le:
        assert keep[n]["verdict"] == "unresolved"
        assert keep[n]["reason"].startswith("open_mapping: original encoder unverified; raw code proposed as an "
                                            "alternative (reviewer feature review)")
    header, f = sheet_rows(wb["Model 15298 features"])
    assert header.index("proposed_alternative") == header.index("recipe") + 1
    by = {r["name"]: r for r in f}
    for n in le:
        if n in by:
            assert by[n]["proposed_alternative"] == f"code({attrs[n]['raw_alternative']})" and not by[n]["recipe"]


def test_in_owner_list_comes_from_list_status_and_list_source(inputs, tmp_path):
    """Integration decision 8: no new map column; yes for a CONFIRMED row from the owner's list, no for
    NOT_IN_OWNER_LIST, blank before the list is adopted."""
    assert wbmod.owner_list_mark("CONFIRMED", "owner_list.csv sha256=ab") == "yes"
    assert wbmod.owner_list_mark("NOT_IN_OWNER_LIST", "owner_list.csv") == "no"
    assert wbmod.owner_list_mark("UNCONFIRMED", "") == ""
    tfm = rows(inputs / LISTS[0])
    names = [r["name"] for r in tfm if r["scope"] == "v22b_chart"][:2]
    with open(NF / "FIELD_MAP.csv", encoding="utf-8") as fh:
        header = next(csv.reader(fh))
    fm = [{c: "" for c in header} for _ in names]
    for r, n, st in zip(fm, names, ("CONFIRMED", "NOT_IN_OWNER_LIST")):
        r.update(name=n, list_status=st, list_source="owner_list.csv")
    write_rows(inputs / "FIELD_MAP.csv", header, fm)
    out = tmp_path / "wb.xlsx"
    assert build(inputs, out) == 0
    _, t = sheet_rows(load_workbook(out)["TFM V22B features"])
    by = {r["name"]: r for r in t}
    assert by[names[0]]["in_owner_list"] == "yes" and by[names[1]]["in_owner_list"] == "no"
