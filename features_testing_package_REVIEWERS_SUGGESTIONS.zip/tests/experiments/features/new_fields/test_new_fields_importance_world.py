"""A local synthetic checkpoint using the real encoder, artifacts and scorer."""
import importlib
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from omegaconf import OmegaConf


def modules():
    try:
        import nf_layout
    except ModuleNotFoundError:
        names = {
            "factory": "waqas.phase4b.factory", "scorer": "waqas.v2.scripts.score_v2",
            "te_model": "waqas.v2.models", "target_ending": "waqas.v2.target_ending",
            "datetime_features": "fraud.data.datetime_features",
            "feature_list": "fraud.data.feature_list", "preprocessing": "fraud.data.preprocessing",
        }
        return {k: importlib.import_module(v) for k, v in names.items()}
    return {k: nf_layout.get(k) for k in (
        "factory", "scorer", "te_model", "target_ending", "datetime_features",
        "feature_list", "preprocessing")}


def synthetic_world(tmp_path, accounts=20, files=1):
    torch.set_num_threads(1)
    torch.manual_seed(41)
    mods = modules()
    rows = []
    for account in range(accounts):
        for j, second in enumerate([0, 1, 1.5, 3, 8, 20]):
            rows.append({
                "account": f"a{account:04d}", "id": f"a{account:04d}t{j}",
                "time": pd.Timestamp("2025-05-31 23:59:58") + pd.Timedelta(int(second * 1_000_000_000), unit="ns"),
                "amount": float(10 + account * 6 + j), "profile": float(account),
                "category": "x" if j % 2 else "y", "label": int((account + j) % 3 == 0),
            })
    frame = pd.DataFrame(rows)
    predictors = tmp_path / "predictors.csv"
    predictors.write_text("feature,type,source,version,description\n"
                          "amount,continuous,raw,1,amount\n"
                          "profile,continuous,raw,1,profile\n"
                          "category,categorical,raw,1,category\n"
                          "month,categorical,derived:time,1,month\n")
    features = mods["feature_list"].load_feature_list(str(predictors), version=1)
    dt = mods["datetime_features"].DatetimeConfig(order_col="time", fields=["month"],
                                               encoding="categorical", is_weekend=False)
    derived, _, _ = mods["datetime_features"].derive_datetime_features(frame, dt)
    artifacts = mods["preprocessing"].PreprocessingArtifacts(artifact_version=1, predictor_version=1)
    for name in features.continuous:
        artifacts.fit_feature(name, derived[name], "continuous")
    for name in features.categorical:
        artifacts.fit_feature(name, derived[name], "categorical")
    artifacts.save(str(tmp_path / "artifacts/1"))
    data = tmp_path / "data"
    data.mkdir()
    for i in range(files):
        part = frame[frame["account"].str[1:].astype(int) % files == i]
        part.to_parquet(data / f"part_{8228 + i}.parquet", index=False)
    cfg = OmegaConf.create({
        "predictors": {"csv_path": str(predictors), "version": 1},
        "artifacts": {"base": str(tmp_path / "artifacts"), "version": 1},
        "data": {"target_col": "label", "account_col": "account", "order_col": "time",
                 "tie_break_col": "id", "id_cols": ["id", "account"], "positive_label": 1,
                 "amount_col": "amount"},
        "sequence": {"history_len": 3, "train_stride": 1, "eval_stride": 1,
                     "attention_mask": "causal", "time_delta": True,
                     "predict_every_transaction": True, "all_position_layout": "nonoverlapping_chunks",
                     "time_delta_reference": "previous_transaction", "history_time_order": "strict",
                     "max_window_rows": 4, "max_chunk_rows": 64},
        "datetime": {"fields": ["month"], "encoding": "categorical", "is_weekend": False},
        "preprocess": {"add_missing_flag": True},
        "model": {"type": "FTTransformerHier", "input_embed_dim": 8, "num_heads": 2,
                  "num_txn_blocks": 2, "num_seq_blocks": 1, "attn_dropout": 0., "ff_dropout": 0.},
        "training": {"eval_batch_size": 11, "batch_size": 11, "num_workers": 0},
        "s3": {"cred_path": None},
        "eval": {"base": str(data), "file_start": 8228, "file_end": 8228 + files - 1},
    })
    dataset = mods["target_ending"].TargetEndingBuilder(
        file_list=[str(data / f"part_{8228 + i}.parquet") for i in range(files)],
        artifacts=artifacts, features=features, datetime_config=dt,
        target_col="label", account_col="account", order_col="time", history_len=3,
        positive_label=1, add_missing_flag=True, time_delta=True, batch_size=11,
        shuffle=False, tie_break_col="id", id_cols=["id", "account"], amount_col="amount",
        max_window_rows=4, max_chunk_rows=64, **mods["factory"].sequence_dataset_options(cfg))
    base = mods["factory"].build_sequential_model(cfg, dataset)
    model = mods["te_model"].FTTransformerHierTargetEnding(**dict(base.hparams)).eval()
    model.max_window_rows, model.validation_precision = 4, "32-true"
    checkpoint = {"state_dict": model.state_dict()}
    model.on_save_checkpoint(checkpoint)
    path = tmp_path / "best.ckpt"
    torch.save(checkpoint, path)
    return cfg, path, frame, mods["scorer"]
