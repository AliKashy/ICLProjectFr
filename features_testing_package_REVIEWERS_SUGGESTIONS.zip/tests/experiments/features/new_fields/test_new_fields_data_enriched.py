"""Enriched copies (design 4.1): every original column unchanged, rows in order, a per-file identity proof."""

import importlib.util
import json
import os
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import pytest

_W = Path(__file__).resolve().parent / "new_fields_data_world.py"
_spec = importlib.util.spec_from_file_location("new_fields_data_world", _W)
world = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(world)

import nf_build_enriched as E  # noqa: E402
import nf_data_io as io  # noqa: E402
import nf_recipes as R  # noqa: E402


@pytest.fixture
def setup(tmp_path, monkeypatch):
    monkeypatch.setenv("NF_OUT", str(tmp_path / "c2"))
    raw = world.raw_world(tmp_path / "raw")
    mp = world.field_map(tmp_path / "FIELD_MAP.csv")
    st = world.field_status(tmp_path / "c2" / "checks" / "field_status.csv", mp)
    args = ["--map", str(mp), "--status", str(st), "--out", str(tmp_path / "enr"),
            "--train-base", str(tmp_path / "raw" / "tfm_raw_data"),
            "--eval-base", str(tmp_path / "raw" / "tfm_EVAL_raw_data"),
            "--range", "train=1-3", "--range", "test1=8000-8001", "--ranges", "train", "test1"]
    return tmp_path, raw, mp, st, args


def engineered(mp):
    m = pd.read_csv(mp, dtype=str, keep_default_na=False)
    m = m[m["kind"] == "engineered"]
    return list(zip(m["name"], m["recipe"], m["model_type"]))


def test_copies_keep_every_column_and_row_and_add_the_new_ones(setup):
    tmp, raw, mp, st, args = setup
    assert E.main(args) == 0
    fields = engineered(mp)
    for rng, sub, files, es in (("train", "tfm_raw_data", raw["train"], "train"),
                                ("test1", "tfm_EVAL_raw_data", raw["eval"], "evaluation")):
        for n, src in files.items():
            orig = pq.read_table(src)
            copy = pq.read_table(tmp / "enr" / sub / f"part_{n}.parquet")
            assert copy.column_names == orig.column_names + [f[0] for f in fields]
            assert copy.num_rows == orig.num_rows
            for c in orig.column_names:
                assert copy.column(c).equals(orig.column(c)), c
                assert io.column_sha256(copy.column(c)) == io.column_sha256(orig.column(c))
            want, _ = R.build_columns(orig.to_pandas(), fields, es, engine=world.engine())
            for name, _, mt in fields:
                got = copy.column(name).to_pandas()
                if mt == "continuous":
                    assert str(copy.schema.field(name).type) == "double"
                    np.testing.assert_array_equal(got.to_numpy(dtype=float), want[name].to_numpy(dtype=float))
                else:
                    assert str(copy.schema.field(name).type) == "string"
                    assert [None if pd.isna(v) else v for v in got] == list(want[name])
            proof = json.loads((tmp / "c2" / "enriched" / "identity" / rng / f"part_{n}.json").read_text())
            assert proof["result"] == "PASS" and proof["rows"]["original"] == proof["rows"]["copy"]
            assert proof["id_sequence_sha256"]["original"] == proof["id_sequence_sha256"]["copy"]
            assert set(proof["columns"]) == set(orig.column_names)
            assert "merchant_xid" not in proof["new_columns"]  # a raw field is never rebuilt
    # June files use the evaluation start: a 7-day window on 2025-05-03 is censored
    p = json.loads((tmp / "c2" / "enriched" / "identity" / "test1" / "part_8000.json").read_text())
    assert p["extract_start"] == "2025-05-01" and p["new_columns"]["amt_sum_7d"]["censored"] > 0


def test_a_changed_original_value_fails_the_proof_and_deletes_nothing(setup, monkeypatch):
    tmp, raw, mp, st, args = setup
    real = io.Store.write_table

    def tamper(self, table, path):
        if path.endswith("part_2.parquet"):
            col = table.column("transaction_amt").to_pandas().to_numpy(copy=True)
            col[5] = 123456.0
            i = table.column_names.index("transaction_amt")
            table = table.set_column(i, "transaction_amt", pa.array(col, from_pandas=True))
        return real(self, table, path)

    monkeypatch.setattr(io.Store, "write_table", tamper)
    assert E.main(args) == 3
    proof = json.loads((tmp / "c2" / "enriched" / "identity" / "train" / "part_2.json").read_text())
    assert proof["result"] == "FAIL"
    assert any("transaction_amt" in f for f in proof["failures"])
    assert (tmp / "enr" / "tfm_raw_data" / "part_1.parquet").exists()
    assert (tmp / "enr" / "tfm_raw_data" / "part_2.parquet").exists()  # kept for inspection


def test_an_existing_prefix_is_refused_and_resume_keeps_passed_files(setup):
    tmp, raw, mp, st, args = setup
    assert E.main(args) == 0
    assert E.main(args) == 4
    copy1 = tmp / "enr" / "tfm_raw_data" / "part_1.parquet"
    before = copy1.stat().st_mtime_ns
    (tmp / "c2" / "enriched" / "identity" / "train" / "part_3.json").unlink()
    assert E.main(args + ["--resume"]) == 0
    assert copy1.stat().st_mtime_ns == before


def test_unconfirmed_rows_and_a_stale_status_are_refused(setup):
    tmp, raw, mp, st, args = setup
    world.field_map(mp, list_status="UNCONFIRMED")
    os.utime(st, (os.path.getmtime(mp) + 10,) * 2)
    assert E.main(args) == 4
    world.field_map(mp)
    os.utime(mp, (os.path.getmtime(st) + 10,) * 2)
    assert E.main(args) == 4


def test_an_engineered_name_equal_to_a_file_column_is_refused(setup):
    tmp, raw, mp, st, args = setup
    world.field_map(mp, fields=[("pwd_chg_dt", "v22b", "engineered", "count(24h)", "", "continuous")])
    world.field_status(st, mp)
    assert E.main(args) == 4


def test_a_history_key_spanning_files_stops(setup):
    tmp, raw, mp, st, args = setup
    df = pd.read_parquet(raw["train"][2])
    df.loc[0, "customer_xid"] = pd.read_parquet(raw["train"][1])["customer_xid"].iloc[0]
    df.to_parquet(raw["train"][2], index=False)
    world.field_map(mp, fields=[("cust_cnt_7d", "f15298", "engineered", "count(7d; key=customer_xid)", "",
                                 "continuous")])
    world.field_status(st, mp)
    assert E.main(args) == 3
    assert not (tmp / "enr").exists()


def test_the_trainers_builder_reads_a_copy_like_the_original(setup):
    tmp, raw, mp, st, args = setup
    assert E.main(args) == 0
    import nf_layout
    sb_mod = nf_layout.get("sequence_builder")
    pre = nf_layout.get("preprocessing")
    fl = nf_layout.get("feature_list")
    dtf = nf_layout.get("datetime_features")
    csv = tmp / "predictors.csv"
    pd.DataFrame({"feature": ["transaction_amt", "total_available_balance_amt", "transaction_type_xcd",
                              "merchant_category_xcd", "month", "hour"],
                  "type": ["continuous", "continuous", "categorical", "categorical", "categorical", "categorical"],
                  "source": ["raw", "raw", "raw", "raw", "derived:transaction_dttm", "derived:transaction_dttm"],
                  "version": 1, "description": "x"}).to_csv(csv, index=False)
    features = fl.load_feature_list(str(csv))
    dcfg = dtf.DatetimeConfig(fields=["month", "hour"])
    src = raw["train"][1]
    fit = pd.read_parquet(src)
    fit, _, _ = dtf.derive_datetime_features(fit, dcfg)
    art = pre.PreprocessingArtifacts(artifact_version="t", fit_files=["part_1.parquet"])
    for f in features.frame.itertuples(index=False):
        art.fit_feature(f.feature, fit[f.feature], f.type)
    outs = []
    for path in (src, tmp / "enr" / "tfm_raw_data" / "part_1.parquet"):
        sb = sb_mod.SequenceBuilder([str(path)], art, features, dcfg, target_col="frd_tag",
                                    account_col=world.ACCOUNT, order_col=world.TIME, history_len=4,
                                    tie_break_col=world.TIE)
        outs.append(sb._encode_file(pd.read_parquet(path)))
    for a, b in zip(outs[0][:4], outs[1][:4]):
        np.testing.assert_array_equal(a, b)


def test_column_hash_is_canonical():
    a = pa.chunked_array([pa.array([1.5, None, 3.0]), pa.array([4.0])])
    b = pa.chunked_array([pa.array([1.5, None, 3.0, 4.0])])
    assert io.column_sha256(a) == io.column_sha256(b)
    s1 = pa.chunked_array([pa.array(["x", None]), pa.array(["yz"])])
    s2 = pa.chunked_array([pa.array(["x", None, "yz"])])
    assert io.column_sha256(s1) == io.column_sha256(s2)
    assert io.column_sha256(pa.chunked_array([pa.array([1.5, None, 3.0, 4.5])])) != io.column_sha256(b)
    assert io.column_sha256(pa.array([1, 2], pa.int64())) != io.column_sha256(pa.array([1, 2], pa.int32()))
    assert io.column_sha256(pa.array([None, 1.0])) != io.column_sha256(pa.array([0.0, 1.0]))
    ts = pa.array(pd.to_datetime(["2024-10-01", None]))
    assert io.column_sha256(ts) == io.column_sha256(pa.chunked_array([ts[:1], ts[1:]]))


def test_a_source_that_waits_keeps_its_recipes_out(setup):
    tmp, raw, mp, st, args = setup
    world.field_map(mp, fields=world.FIELDS + [("transaction_amt", "v22b", "raw", "raw", "transaction_amt",
                                                "continuous")])
    s = pd.read_csv(world.field_status(st, mp), dtype=str, keep_default_na=False)
    s.loc[s["field"] == "transaction_amt", "result"] = "WAIT"
    s.to_csv(st, index=False)
    assert E.main(args) == 0
    copy = pq.read_table(tmp / "enr" / "tfm_raw_data" / "part_1.parquet")
    assert "amt_sum_7d" not in copy.column_names and "cnt_24h" in copy.column_names


def test_a_real_nan_in_a_float_column_passes_the_proof(setup):
    tmp, raw, mp, st, args = setup
    df = pd.read_parquet(raw["train"][1])
    df["total_available_balance_amt"] = df["total_available_balance_amt"].astype(object)
    vals = pa.array([float("nan") if i % 7 == 0 else (None if i % 5 == 0 else 1.0) for i in range(len(df))],
                    type=pa.float64(), from_pandas=False)
    tbl = pa.Table.from_pandas(df, preserve_index=False)
    i = tbl.column_names.index("total_available_balance_amt")
    pq.write_table(tbl.set_column(i, "total_available_balance_amt", vals), raw["train"][1])
    assert E.main(args) == 0


def test_resume_rebuilds_when_the_check_results_change(setup):
    tmp, raw, mp, st, args = setup
    assert E.main(args) == 0
    copy1 = tmp / "enr" / "tfm_raw_data" / "part_1.parquet"
    before = copy1.stat().st_mtime_ns
    s = pd.read_csv(st, dtype=str, keep_default_na=False)
    s.loc[s["field"] == "cnt_24h", "result"] = "STOP"
    s.to_csv(st, index=False)
    assert E.main(args + ["--resume"]) == 0
    assert copy1.stat().st_mtime_ns != before
    assert "cnt_24h" not in pq.read_table(copy1).column_names
