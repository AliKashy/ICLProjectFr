"""The checks read the settings lane's CHECK_THRESHOLDS.yaml and STATUS_RULES.csv as written.
These tests skip when the settings files are not installed next to the tools."""

import pandas as pd
import pytest
import yaml

from new_fields_checks_helpers import NF, load

R = load("nf_checks_rules")
F = load("nf_field_checks")
TH = NF / "CHECK_THRESHOLDS.yaml"
SR = NF / "STATUS_RULES.csv"


def _leaves(d, out):
    for k, v in d.items():
        if isinstance(v, dict):
            _leaves(v, out)
        else:
            out.append(k)
    return out


@pytest.mark.skipif(not TH.exists(), reason="settings file not installed")
def test_every_threshold_key_in_the_file_is_read():
    data = yaml.safe_load(TH.read_text())
    read = {fk for fk, _ in R.ALIASES.values()} | set(R.DEFAULTS) | {"cramers_v", "nmi", "month", "yyyymm",
                                                                      "yyyymmdd"}
    unread = [k for k in _leaves(data, []) if k not in read and k not in ("calendar_int_ranges", "month_repetitive",
                                                                      # read by the intake's generic_source rule
                                                                      "generic_source_columns")]
    assert not unread, unread


@pytest.mark.skipif(not TH.exists(), reason="settings file not installed")
def test_points_in_the_file_become_points_here():
    th = R.Thresholds(yaml.safe_load(TH.read_text()))
    assert th.num("fill_after_fraud_points") == pytest.approx(20.0)
    assert th.num("control_val_ap") == pytest.approx(0.137146)
    assert th.num("repetitive_v") == pytest.approx(0.7) and th.num("repetitive_nmi") == pytest.approx(0.5)
    assert th.calendar_ranges()["month"] == (1.0, 12.0)


@pytest.mark.skipif(not SR.exists(), reason="settings file not installed")
def test_status_rules_file_spares_legitimate_fields_and_stops_the_seven():
    rules = F.read_status_rules(SR)
    legit = ["merchant_state_xcd", "cprsrvc__pisinfo_cardholder_postal_xcd", "tokenization_indicator",
             "user_indicator_7_xcd", "cprcust__authcsusploc_risky_ip_country_xcd",
             "cprsrvc__pisinfo_cardholder_country_xcd", "card_offln_static_authctn_xflg",
             "cprsrvc__dbt_travel_countrydate_cardholder_travel_curr_country"]
    rows = [{"name": n, "recipe": "raw"} for n in legit]
    rows += [{"name": "inactv_days", "recipe": "days_before(inactv_dt)", "source_columns": "inactv_dt"},
             {"name": "pw_days", "recipe": "days_before(cprcust__onlinebankpwstatuschgdt)",
              "source_columns": "cprcust__onlinebankpwstatuschgdt"},
             {"name": "falcondecline_indicator", "recipe": "raw"},
             {"name": "prev_falcon", "recipe": "prev(falcondecline_indicator)",
              "source_columns": "falcondecline_indicator"},
             {"name": "cprcust__ebsloginblock_flag", "recipe": "raw"}]
    cols = load("nf_checks_synth").map_columns()
    fm = pd.DataFrame([{**{c: "" for c in cols}, "feasible_in_production": "yes", **r} for r in rows])
    sp = {s["name"]: s for s in F.field_specs(fm, [], R.Thresholds(yaml.safe_load(TH.read_text())
                                                                   if TH.exists() else {}), rules, "acct")}
    for n in legit:
        assert "status" not in sp[n]["flags"], n
    assert sp["inactv_days"]["flags"].get("left_out_26oct")
    assert not sp["pw_days"]["flags"].get("status") and not sp["pw_days"]["flags"].get("left_out_26oct")
    assert sp["falcondecline_indicator"]["flags"].get("same_txn_decision")
    assert sp["prev_falcon"]["flags"].get("lagged_decision_wait")
    assert sp["cprcust__ebsloginblock_flag"]["flags"].get("status")


@pytest.mark.skipif(not TH.exists(), reason="settings file not installed")
def test_planted_world_holds_under_the_settings_thresholds(tmp_path):
    S = load("nf_checks_synth")
    a = F.build_args(["--dry-run", "--thresholds", str(TH), "--out", str(tmp_path / "out")])
    log = []
    assert F.dry_run(a, folder=tmp_path, log=log.append) == 0
    st = pd.read_csv(tmp_path / "out" / "field_status.csv", keep_default_na=False).set_index("field")
    wrong = [f"{n}: {st.loc[n, 'result']} {st.loc[n, 'reasons']}" for n, (res, rule) in S.EXPECTED.items()
             if st.loc[n, "result"] != res or (rule and rule not in st.loc[n, "reasons"])]
    assert not wrong, "\n".join(wrong)
