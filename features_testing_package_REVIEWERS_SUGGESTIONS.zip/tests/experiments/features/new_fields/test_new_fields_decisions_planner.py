"""The reviewers' joint decisions of 2 November in the planner and the config writer, with the spine lane's synthetic
project and fakes on PATH: the controls (D5a, D5b), the group membership (D3a), A3 and pruning (D4a, D4b), month
out by default (D4c) and the one importance run (D6)."""
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pandas as pd
import pytest
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
from new_fields_spine_world import NF_REL, default_map, make_world, run  # noqa: E402

ROOT = Path(__file__).resolve().parents[4]
STATUS = {"f_code": "PASS", "f_cnt24": "FLAG", "f_amt": "PASS"}
A1A2 = [{"name": "A1", "on": True, "adds": ["v22b", "both"]}, {"name": "A2", "on": True, "adds": ["f15298", "both"]}]


def world(tmp_path, steps=None, **kw):
    kw.setdefault("map_rows", default_map())
    kw.setdefault("field_status", STATUS)
    if steps is not None:
        kw["steps_patch"] = dict(kw.get("steps_patch") or {}, steps=steps)
    return make_world(tmp_path, **kw)


def queue(w, tmp_path, decisions=None, *extra, **envx):
    if decisions is not None:
        p = tmp_path / "decisions.json"
        p.write_text(json.dumps(decisions))
        envx["FAKE_DECISIONS"] = p
    return run(w, tmp_path, "nf_plan.py", "queue", "--skip-preflight", *extra, **envx)


def c2(w):
    return w / "checkpoints" / "new_fields"


def qlog(w):
    return (c2(w) / "queue.log").read_text()


def started(log):
    return [ln.split()[1] for ln in log.splitlines() if ln.startswith("start ")]


def table(w, name):
    return json.loads((c2(w) / "reads" / f"{name}.runs.json").read_text())


def controls(w, name):
    return {r["seed"]: r for r in table(w, name)["runs"] if r["role"] == "control"}


def head(w, run_):
    return (w / NF_REL / "configs" / f"{run_}.yaml").read_text().splitlines()[0]


# ------------------------------------------------------------------ D5b: the base refits come first


def test_the_base_refits_at_43_and_44_are_the_first_gpu_jobs_before_any_read(tmp_path):
    w = world(tmp_path, A1A2)
    queue(w, tmp_path, {"A1_1seed": "KEEP THE CONTROL", "A2_1seed": "KEEP THE CONTROL"})
    jobs = started(qlog(w))
    gpu = [j for j in jobs if j.startswith(("fit_", "score_"))]
    assert gpu[:2] == ["fit_nf_control_seed43", "fit_nf_control_seed44"], jobs
    first_read = next(i for i, j in enumerate(jobs) if j.startswith("read_"))
    assert jobs.index("fit_nf_control_seed44") < first_read
    # the spread pools the kept trio and the current-pod base trio, on the decision rows
    rows = table(w, "spread_rank_b")["runs"]
    assert sorted((r["role"], r["seed"]) for r in rows) == [("current", 42), ("current", 43), ("current", 44),
                                                            ("kept", 42), ("kept", 43), ("kept", 44)]
    cur = {r["seed"]: r["run_dir"] for r in rows if r["role"] == "current"}
    assert cur[42].endswith("retrain_seed42") and cur[43].endswith("runs/nf_control/seed43")
    # D2: RANK-B decides, so the kept seeds' SELECT June spread is read too
    assert "read_spread_select_june" in jobs
    assert {r["role"] for r in table(w, "spread_select_june")["runs"]} == {"kept"}


def test_kept_checkpoints_are_never_controls_and_false_is_refused(tmp_path):
    """Fixture (a): with every validity check of the kept checkpoints passing, the planner never returns them as
    controls; refit_base_controls_43_44 false is refused."""
    sys.path.insert(0, str(ROOT / NF_REL))
    import nf_plan
    kept = {"is_base": True}
    ctl = {"control_kind": "base", "tag": "control_seed42", "dir": "x"}
    out, why = nf_plan.confirm_controls(SimpleNamespace(steps={}, settings={}), kept, ctl, [43, 44])
    assert [e["tag"] for e in out] == ["nf_control_seed43", "nf_control_seed44"] and "D5b" in why
    w = world(tmp_path, A1A2, steps_patch={"refit_base_controls_43_44": False})
    r = queue(w, tmp_path, {})
    assert r.returncode == 3 and "never controls" in qlog(w)
    assert "start fit_" not in qlog(w)


def test_a_stage0_seed43_run_never_fills_the_seed43_slot(tmp_path):
    """Fixture (e): a finished stage 0 run at seed 43 at the chosen rate on disk; nf_control seed 43 is still fit."""
    w = world(tmp_path, A1A2)
    d = w / "runs" / "tuning" / "lr3e-4_seed43"
    d.mkdir(parents=True)
    (d / "run_manifest_v2.json").write_text(json.dumps({"status": "finished", "start": {"source_sha256": "s" * 64}}))
    (d / "best.ckpt").write_text("stage0")
    queue(w, tmp_path, {"A1_1seed": "KEEP THE CONTROL", "A2_1seed": "KEEP THE CONTROL"})
    assert "start fit_nf_control_seed43" in qlog(w)


def test_our_base_controls_must_pass_stage1s_training_check(tmp_path):
    """P1 and the base refits are read only after 2,103 optimizer updates per epoch (stage 1 rule S7)."""
    w = world(tmp_path, A1A2)
    r = queue(w, tmp_path, {}, FAKE_UPDATES_PER_EPOCH=2000)
    log = qlog(w)
    assert r.returncode == 3 and "stage 1's training check" in log and "2,103 per epoch" in log
    assert "start read_" not in log


def test_p1_and_the_base_refits_take_the_first_steps_micro_batch(tmp_path):
    """Fixture (c): a micro-batch entry for the first step's candidate makes the stage 1 retrain no longer A1's
    control; P1 (nf_control seed 42) and the refits at 43 and 44 carry it."""
    mb = {"nf_a1": {"batch_size": 128, "accumulate_grad_batches": 32, "eval_batch_size": 512}}
    w = world(tmp_path, A1A2, settings_patch={"microbatch": mb})
    r = queue(w, tmp_path, {})
    assert r.returncode == 3 and "memory rule changed nf_a1's micro-batch" in qlog(w)
    assert "control_p1_owner_yes" in qlog(w)
    w = world(tmp_path / "yes", A1A2, settings_patch={"microbatch": mb, "control_p1_owner_yes": {
        "by": "the reviewers under the owner's delegation, stage 1 report run-002", "on": "2026-11-04"}})
    r = queue(w, tmp_path / "yes", {"A1_1seed": "KEEP THE CONTROL", "A2_1seed": "KEEP THE CONTROL"})
    assert r.returncode in (0, 5), qlog(w)
    for sd in (42, 43, 44):
        cfg = yaml.safe_load((c2(w) / "runs" / "nf_control" / f"seed{sd}" / "resolved_train_v2.yaml").read_text())
        assert (cfg["training"]["batch_size"], cfg["training"]["accumulate_grad_batches"]) == (128, 32)
    assert controls(w, "A1_1seed")[42]["run_dir"].endswith("runs/nf_control/seed42")


def test_the_preflight_needs_stage1_on_both_paths_and_the_first_step_timing(tmp_path):
    """Fixture (b): a start-check record without stage1_ok stops on the retrain path and on the P1 path; a missing
    first-step timing record fails the preflight."""
    for name, patch in (("retrain", {}), ("p1", {"learning_rate": 0.001, "control_p1_owner_yes": {
            "by": "the reviewers", "on": "2026-11-04"}})):
        w = world(tmp_path / name, A1A2, settings_patch=patch)
        g = c2(w) / "guard" / "guard.jsonl"
        g.parent.mkdir(parents=True, exist_ok=True)
        g.write_text(json.dumps({"utc": "t", "stage1_ok": False}) + "\n")
        run(w, tmp_path / name, "nf_plan.py", "preflight")
        checks = {c["check"]: c for c in json.loads((c2(w) / "reads" / "preflight.json").read_text())["checks"]}
        assert checks["stage1_checks"]["ok"] is False, name
        assert checks["first_step_timing"]["ok"] is False and "missing" in checks["first_step_timing"]["detail"]
        assert checks["control"]["ok"] is True, checks["control"]
        assert checks["control"]["detail"].startswith("nf_control" if name == "p1" else "control_stage1")
    (c2(w) / "timing").mkdir(parents=True, exist_ok=True)
    (c2(w) / "timing" / "nf_a1.json").write_text(json.dumps({"verdict": "OK"}))
    run(w, tmp_path / "p1", "nf_plan.py", "preflight")
    checks = {c["check"]: c for c in json.loads((c2(w) / "reads" / "preflight.json").read_text())["checks"]}
    assert checks["first_step_timing"]["ok"] is True


# ------------------------------------------------------------------ D5a: a seed-42 refit before every later step


def test_a2_reads_against_a_refit_both_when_a1_adopts_and_when_a1_keeps_the_base(tmp_path):
    for name, dec, kept_set in (("adopt", "ADOPT", "a1"), ("keep", "KEEP THE CONTROL", "base")):
        w = world(tmp_path / name, A1A2)
        queue(w, tmp_path / name, {"A1_1seed": dec, "A2_1seed": "KEEP THE CONTROL"})
        jobs = started(qlog(w))
        assert jobs.index("fit_nf_ka2_seed42") < jobs.index("read_A2_1seed"), jobs
        assert f"input set {kept_set};" in head(w, "nf_ka2")
        ctl = controls(w, "A2_1seed")[42]
        assert ctl["run_dir"].endswith("runs/nf_ka2/seed42") and ctl["control_kind"] == "refit"
        kept_fit = [r for r in table(w, "A2_1seed")["runs"] if r["role"] == "kept_fit"][0]
        assert kept_fit["run_dir"].endswith("runs/nf_a1/seed42" if name == "adopt" else "retrain_seed42")


def test_a1_keeps_the_base_so_a2s_controls_are_its_refit_and_the_base_refits(tmp_path):
    """Fixture (a): A2's seed-42 control is nf_ka2 on the base inputs; its seed 43 and 44 controls are nf_control's."""
    w = world(tmp_path, A1A2)
    queue(w, tmp_path, {"A1_1seed": "KEEP THE CONTROL", "A2_1seed": "RUN SEEDS 43 AND 44",
                        "A2_3seed": "KEEP THE CONTROL"})
    ctl = controls(w, "A2_3seed")
    assert ctl[42]["run_dir"].endswith("runs/nf_ka2/seed42")
    assert ctl[43]["run_dir"].endswith("runs/nf_control/seed43") and ctl[44]["run_dir"].endswith("nf_control/seed44")
    assert "start fit_nf_ka2_seed43" not in qlog(w)


def test_a1_adopted_at_one_seed_gives_new_controls_at_42_43_and_44(tmp_path):
    """Fixture (b)."""
    w = world(tmp_path, A1A2)
    queue(w, tmp_path, {"A1_1seed": "ADOPT", "A2_1seed": "RUN SEEDS 43 AND 44", "A2_3seed": "KEEP THE CONTROL"})
    ctl = controls(w, "A2_3seed")
    assert [ctl[s]["run_dir"].split("runs/")[-1] for s in (42, 43, 44)] == ["nf_ka2/seed42", "nf_ka2/seed43",
                                                                            "nf_ka2/seed44"]
    assert "input set a1;" in head(w, "nf_ka2")


def test_a1_adopted_at_three_seeds_never_reuses_its_own_43_and_44_fits(tmp_path):
    """Fixture (c): A2's seed 43 and 44 controls are nf_ka2's, not nf_a1's."""
    w = world(tmp_path, A1A2)
    queue(w, tmp_path, {"A1_1seed": "RUN SEEDS 43 AND 44", "A1_3seed": "ADOPT", "A2_1seed": "RUN SEEDS 43 AND 44",
                        "A2_3seed": "KEEP THE CONTROL"})
    ctl = controls(w, "A2_3seed")
    assert ctl[43]["run_dir"].endswith("runs/nf_ka2/seed43") and ctl[44]["run_dir"].endswith("runs/nf_ka2/seed44")
    assert ctl[42]["previous_decision"] == "three_seed"
    assert "start fit_nf_ka2_seed43" in qlog(w)


def test_the_refit_takes_the_candidates_micro_batch_and_a_stale_config_stops_before_any_fit(tmp_path):
    """Fixture (d): the width timing writes a micro-batch entry for nf_a2 after nf_a2's config was written; the
    memory rule stops before either fit. Renamed, the configs carry the same values and both fits run."""
    mb = {"nf_a2": {"batch_size": 128, "accumulate_grad_batches": 32, "eval_batch_size": 512}}
    w = world(tmp_path, A1A2)
    r = queue(w, tmp_path, {"A1_1seed": "ADOPT", "A2_1seed": "KEEP THE CONTROL"},
              FAKE_TIMING_MICROBATCH=json.dumps(mb))
    log = qlog(w)
    assert r.returncode == 3 and "the memory rule fired after it was written" in log, log
    assert "start fit_nf_ka2_seed42" not in log and "start fit_nf_a2_seed42" not in log
    cfg = yaml.safe_load((w / NF_REL / "configs" / "nf_ka2.yaml").read_text())
    assert (cfg["training"]["batch_size"], cfg["training"]["accumulate_grad_batches"]) == (128, 32)
    assert cfg["training"]["eval_batch_size"] == 512
    stale = w / NF_REL / "configs" / "nf_a2.yaml"
    stale.rename(stale.with_name("nf_a2.yaml.before_timing"))
    r = queue(w, tmp_path, {"A1_1seed": "ADOPT", "A2_1seed": "KEEP THE CONTROL"})
    assert r.returncode in (0, 5), qlog(w)
    for run_ in ("nf_ka2", "nf_a2"):
        got = yaml.safe_load((c2(w) / "runs" / run_ / "seed42" / "resolved_train_v2.yaml").read_text())["training"]
        assert (got["batch_size"], got["accumulate_grad_batches"]) == (128, 32), run_
    # the timing changed SETTINGS.yaml mid-queue; the saved reads stay current (microbatch is not a read input)
    assert "inputs changed" not in qlog(w)


def test_pruning_month_out_and_the_calendar_step_read_against_refits(tmp_path):
    """Fixture (e): nf_kp, nf_kb and nf_kc, each a seed-42 refit of the kept recipe at its candidate's micro-batch;
    month out's and the calendar step's seed 43 and 44 controls are new fits of the refit's recipe."""
    steps = A1A2[:1] + [{"name": "P", "on": True, "kind": "prune"}, {"name": "B", "on": True, "kind": "month_out"},
                        {"name": "C", "on": True, "kind": "calendar_cyclical", "is_weekend": False}]
    imp = "unit,kind,members,drop_udr_ci_high,drop_ap_ci_high\nf_code,single,f_code,-1,-1\n"
    w = world(tmp_path, steps)
    dec = {"A1_1seed": "ADOPT", "P_1seed": "KEEP THE UNPRUNED LIST", "B_1seed": "RUN SEEDS 43 AND 44",
           "B_3seed": "KEEP MONTH", "C_1seed": "RUN SEEDS 43 AND 44", "C_3seed": "KEEP THE CALENDAR"}
    r = queue(w, tmp_path, dec, FAKE_IMPORTANCE_CSV=imp)
    assert r.returncode in (0, 5), qlog(w)
    for step, run_ in (("P", "nf_kp"), ("B", "nf_kb"), ("C", "nf_kc")):
        assert controls(w, f"{step}_1seed")[42]["run_dir"].endswith(f"runs/{run_}/seed42"), step
        assert "input set a1;" in head(w, run_)
    for step, run_ in (("B", "nf_kb"), ("C", "nf_kc")):
        ctl = controls(w, f"{step}_3seed")
        assert ctl[43]["run_dir"].endswith(f"runs/{run_}/seed43") and ctl[44]["run_dir"].endswith(f"{run_}/seed44")
    assert "month in" in head(w, "nf_kb") and "month out" in head(w, "nf_b")


# ------------------------------------------------------------------ D3a: the rows in both lists


BOTH_MAP = default_map() + [
    {"name": "f_both", "group": "both", "kind": "raw", "recipe": "raw", "source_columns": "f_both",
     "model_type": "continuous", "definition_version": "1", "excluded_by_sumegha": "no",
     "feasible_in_production": "yes", "list_status": "CONFIRMED"},
    {"name": "f_v22b_twin", "group": "v22b", "kind": "raw", "recipe": "raw", "source_columns": "f_v22b_twin",
     "model_type": "continuous", "definition_version": "1", "excluded_by_sumegha": "no",
     "feasible_in_production": "yes", "list_status": "CONFIRMED"},
    {"name": "f_15298_twin", "group": "f15298", "kind": "raw", "recipe": "raw", "source_columns": "f_15298_twin",
     "model_type": "continuous", "definition_version": "1", "excluded_by_sumegha": "no",
     "feasible_in_production": "yes", "list_status": "CONFIRMED", "kept_once_as": "f_v22b_twin"}]
BOTH_STATUS = dict(STATUS, f_both="PASS", f_v22b_twin="PASS", f_15298_twin="STOP")


def _names(w, sid):
    lst = (w / NF_REL / "predictors" / f"predictors_{sid}_month_in.csv").read_text().splitlines()
    return [ln.split(",")[0] for ln in lst[1:]]


def test_the_rows_in_both_lists_join_a2_when_a1_keeps_its_control_and_count_once(tmp_path):
    w = world(tmp_path / "keep", A1A2, map_rows=BOTH_MAP, field_status=BOTH_STATUS)
    queue(w, tmp_path / "keep", {"A1_1seed": "KEEP THE CONTROL", "A2_1seed": "KEEP THE CONTROL"})
    a2 = _names(w, "a2")
    assert "f_both" in a2 and a2.count("f_both") == 1
    assert "f_v22b_twin" in a2 and "f_15298_twin" not in a2      # the twin enters through its V22B row
    assert "f_code" not in a2
    mem = table(w, "A2_1seed")
    assert mem["membership"].startswith("15298 beyond the kept inputs") and mem["a1_adopted"] is False
    w = world(tmp_path / "adopt", A1A2, map_rows=BOTH_MAP, field_status=BOTH_STATUS)
    queue(w, tmp_path / "adopt", {"A1_1seed": "ADOPT", "A2_1seed": "KEEP THE CONTROL"})
    a1a2 = _names(w, "a1a2")
    assert a1a2.count("f_both") == 1 and a1a2.count("f_v22b_twin") == 1 and "f_15298_twin" not in a1a2
    assert table(w, "A2_1seed")["a1_adopted"] is True
    w = world(tmp_path / "all", A1A2, map_rows=BOTH_MAP, field_status=BOTH_STATUS,
              steps_patch={"one_step_all": True})
    queue(w, tmp_path / "all", {})
    assert sorted(_names(w, "a1a2")) == sorted(a1a2)


def test_a_dropped_or_failed_v22b_twin_does_not_join_a2(tmp_path, monkeypatch):
    sys.path.insert(0, str(ROOT / NF_REL))
    import nf_common as C
    import nf_make_configs as M
    c2_ = tmp_path / "c2"
    (c2_ / "checks").mkdir(parents=True)
    monkeypatch.setenv("NF_OUT", str(c2_))
    rows = []
    for r in BOTH_MAP:
        row = {c: "" for c in C.FIELD_MAP_COLUMNS}
        row.update(r)
        rows.append(row)
    df = pd.DataFrame(rows, columns=C.FIELD_MAP_COLUMNS)
    monkeypatch.setattr(C, "NF", tmp_path)
    for twin, result, keep in (("PASS", "PASS", True), ("STOP", "STOP", False), ("drop", "PASS", False)):
        status = dict(BOTH_STATUS, f_v22b_twin=result)
        (c2_ / "checks" / "field_status.csv").write_text("field,result,reasons,kept_once_as\n" + "".join(
            f"{k},{v},,{'f_v22b_twin' if k == 'f_15298_twin' else ''}\n" for k, v in status.items()))
        kd = tmp_path / "KEEP_DECISIONS.csv"
        kd.write_text(",".join(C.KEEP_DECISIONS_COLUMNS) + "\n" + (
            "f_v22b_twin,v22b,drop,owner drops it,,Owner,2026-11-03,1\n" if twin == "drop" else ""))
        names = [r["name"] for r in M.fields_for(["f15298", "both"], df)]
        assert ("f_v22b_twin" in names) is keep, twin
        assert "f_both" in names and "f_code" not in names
        names = [r["name"] for r in M.fields_for(["v22b", "both", "f15298", "both"], df)]
        assert names.count("f_both") == 1


# ------------------------------------------------------------------ D4a, D4b: A3 and pruning


def test_the_a3_switch_must_agree_with_the_confirmed_list():
    sys.path.insert(0, str(ROOT / NF_REL))
    import nf_plan

    def ctx(on):
        return SimpleNamespace(steps={"steps": [{"name": "A3", "on": on, "adds": ["a3"]}]})
    with_a3 = pd.DataFrame({"group": ["v22b", "a3"], "list_status": ["CONFIRMED", "CONFIRMED"]})
    without = pd.DataFrame({"group": ["v22b", "a3"], "list_status": ["CONFIRMED", "NOT_IN_OWNER_LIST"]})
    ok, why = nf_plan.a3_switch_state(ctx(False), with_a3)
    assert not ok and "set A3 on in STEPS.yaml, or leave those rows out of the list" in why
    assert nf_plan.a3_switch_state(ctx(True), with_a3)[0]
    assert nf_plan.a3_switch_state(ctx(False), without)[0]
    assert not nf_plan.a3_switch_state(ctx(True), without)[0]


def test_the_default_steps_queue_no_a3_job(tmp_path):
    w = make_world(tmp_path, map_rows=default_map(), field_status=STATUS)
    queue(w, tmp_path, {"A1_1seed": "ADOPT", "A2_1seed": "ADOPT"})
    assert not any("nf_a3" in j for j in started(qlog(w)))


def test_pruning_reads_the_upper_ends_reading_b(tmp_path, monkeypatch):
    sys.path.insert(0, str(ROOT / NF_REL))
    import nf_common as C
    import nf_plan
    kd = tmp_path / "KEEP_DECISIONS.csv"
    kd.write_text(",".join(C.KEEP_DECISIONS_COLUMNS) + "\nf_kept,f15298,keep,owner keeps it,,Owner,2026-11-03,1\n")
    monkeypatch.setattr(C, "NF", tmp_path)
    monkeypatch.setenv("NF_SETTINGS_DIR", str(ROOT / NF_REL))
    imp = tmp_path / "importance.csv"
    imp.write_text("unit,kind,members,drop_udr_ci_low,drop_udr_ci_high,drop_ap_ci_low,drop_ap_ci_high\n"
                   "f_wide,single,f_wide,-0.01,0.08,-0.01,0.08\n"          # admits a large benefit: kept
                   "f_neg,single,f_neg,-0.02,-0.001,-0.02,-0.001\n"        # whole interval below zero: pruned
                   "f_zero,single,f_zero,0,0,0,0\n"                         # at zero: pruned
                   "f_one,single,f_one,-0.02,-0.001,-0.02,0.003\n"         # straddles on AP: kept
                   "cluster:c1,cluster,f_in;f_x,-0.01,0.01,-0.01,0.01\n"   # a cluster that does not qualify
                   "f_in,single,f_in,-0.02,-0.001,-0.02,-0.001\n"          # qualifies alone, in that cluster: kept
                   "f_kept,single,f_kept,-0.02,-0.001,-0.02,-0.001\n"      # a person kept it
                   "transaction_amt,single,transaction_amt,-1,-1,-1,-1\n")  # a base input
    assert nf_plan.prune_list(imp, None) == ["f_neg", "f_zero"]
    only_low = tmp_path / "low.csv"
    only_low.write_text("unit,kind,members,drop_udr_ci_low,drop_ap_ci_low\nf_a,single,f_a,-1,-1\n")
    assert nf_plan.prune_list(only_low, None) == []                         # no upper ends: kept


# ------------------------------------------------------------------ D4c and D6: month out and importance


def test_month_out_is_the_last_fitting_step_by_default_then_importance_once(tmp_path):
    """With the default STEPS.yaml and A1 and A2 adopted at one seed, B runs after A2's read; the one importance run
    is on the final kept fit after B's read, before the Test 1 report."""
    w = make_world(tmp_path, map_rows=default_map(), field_status=STATUS)
    queue(w, tmp_path, {"A1_1seed": "ADOPT", "A2_1seed": "ADOPT", "B_1seed": "KEEP MONTH"})
    jobs = started(qlog(w))
    assert jobs.index("read_A2_1seed") < jobs.index("fit_nf_b_seed42") < jobs.index("read_B_1seed")
    imp = [j for j in jobs if j.startswith("importance_")]
    assert imp == ["importance_nf_a2_seed42"], jobs                         # B kept month: A2's fit is final
    assert jobs.index("read_B_1seed") < jobs.index("importance_nf_a2_seed42") < jobs.index("read_test1_report")
    assert "start downstream_nf_b_seed42" not in qlog(w) and "read_B_lift" not in jobs
    # D4b: the scoring timing runs once, on the final kept fit, after the last fitting step
    timing = [j for j in jobs if j.startswith("scoring_timing_")]
    assert timing == ["scoring_timing_nf_a2"], jobs
    assert jobs.index("read_B_1seed") < jobs.index("scoring_timing_nf_a2") < jobs.index("read_test1_report")


def test_an_adopted_month_out_gets_its_downstream_lift_importance_and_decision_row(tmp_path):
    steps = A1A2[:1] + [{"name": "B", "on": True, "kind": "month_out"}]
    w = world(tmp_path, steps)
    queue(w, tmp_path, {"A1_1seed": "ADOPT", "B_1seed": "MONTH OUT"})
    jobs = started(qlog(w))
    assert "downstream_nf_b_seed42" in jobs and "read_B_lift" in jobs
    assert [j for j in jobs if j.startswith("importance_")] == ["importance_nf_b_seed42"]
    rows = (w / NF_REL / "KEEP_DECISIONS.csv").read_text()
    assert "month,base,drop," in rows and "D4c" in rows and "read:" in rows
    # no adding step adopted and month out adopted: no importance run
    w = world(tmp_path / "none", steps)
    queue(w, tmp_path / "none", {"A1_1seed": "KEEP THE CONTROL", "B_1seed": "MONTH OUT"})
    assert not [j for j in started(qlog(w)) if j.startswith("importance_")]


def test_with_pruning_on_importance_stays_before_pruning(tmp_path):
    steps = A1A2[:1] + [{"name": "P", "on": True, "kind": "prune"}, {"name": "B", "on": True, "kind": "month_out"}]
    imp = "unit,kind,members,drop_udr_ci_high,drop_ap_ci_high\nf_code,single,f_code,0.01,0.01\n"
    w = world(tmp_path, steps)
    queue(w, tmp_path, {"A1_1seed": "ADOPT"}, FAKE_IMPORTANCE_CSV=imp)
    jobs = started(qlog(w))
    assert [j for j in jobs if j.startswith("importance_")] == ["importance_nf_a1_seed42"]
    assert jobs.index("importance_nf_a1_seed42") < jobs.index("fit_nf_b_seed42")


def test_the_shipped_settings_record_the_d10_approvals_and_leave_the_owner_items_blank():
    """D10: the four approvals and the thresholds SHA-256 are filled under the owner's delegation; the owner's own
    items (P1 as the control, the external score's certification) and the pruning keys stay blank; step P is off."""
    import hashlib
    nf = ROOT / NF_REL
    s = yaml.safe_load((nf / "SETTINGS.yaml").read_text())
    for k in ("main_measure", "bar", "check_thresholds", "cluster_threshold"):
        a = s["approvals"][k]
        assert a["approved_by"].startswith("reviewers, under the owner's delegation of 2026-11-02"), k
        assert a["approved_on"] == "2026-11-02", k
    assert s["check_thresholds_sha256"] == hashlib.sha256((nf / "CHECK_THRESHOLDS.yaml").read_bytes()).hexdigest()
    def plain(rec):          # YAML 1.1 reads the bare key `on` as True
        return {("on" if k is True else k): v for k, v in rec.items()}
    assert plain(s["control_p1_owner_yes"]) == {"by": "", "on": ""}
    assert plain(s["external_1_scr_certified"]) == {"by": "", "on": ""}
    assert s["spread_pool"] == ["kept", "current"]
    assert s["prune_reason"] == "" and s["prune_allowable_loss_udr"] == ""
    steps = yaml.safe_load((nf / "STEPS.yaml").read_text())["steps"]
    assert [plain(st)["on"] for st in steps if st.get("kind") == "prune"] == [False]


def test_the_preflight_refuses_pruning_on_until_the_compression_step_is_built(tmp_path):
    """D4b: pruning reopens only as the three-seed compression step with a stated reason and allowable loss, which
    the package does not build; the preflight fails while STEPS.yaml has step P on, and passes that check when off."""
    on = A1A2[:1] + [{"name": "P", "on": True, "kind": "prune"}, {"name": "B", "on": True, "kind": "month_out"}]
    w = world(tmp_path / "on", on)
    r = run(w, tmp_path / "on", "nf_plan.py", "preflight")
    checks = {c["check"]: c for c in json.loads((c2(w) / "reads" / "preflight.json").read_text())["checks"]}
    assert r.returncode == 3 and checks["prune_step"]["ok"] is False
    assert "set step P off" in checks["prune_step"]["detail"]
    assert f"STOP {'prune_step':<22} set step P off: pruning is D4b's compression step, not built" in r.stdout
    w = world(tmp_path / "off", A1A2[:1] + [{"name": "P", "on": False, "kind": "prune"}])
    run(w, tmp_path / "off", "nf_plan.py", "preflight")
    checks = {c["check"]: c for c in json.loads((c2(w) / "reads" / "preflight.json").read_text())["checks"]}
    assert checks["prune_step"] == {"check": "prune_step", "ok": True,
                                    "detail": "pruning off (the reviewers' decision D4b)"}


@pytest.mark.parametrize("run_, src", [("nf_control", "nf_a1"), ("nf_ka2", "nf_a2"), ("nf_kb", "nf_b"),
                                       ("nf_a2", "nf_a2")])
def test_each_config_takes_its_candidates_micro_batch(run_, src):
    sys.path.insert(0, str(ROOT / NF_REL))
    import nf_plan
    ctx = SimpleNamespace(steps={"steps": A1A2}, settings={})
    assert nf_plan.microbatch_source(ctx, run_) == src
