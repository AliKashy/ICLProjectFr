"""Part A, checked: the field checks on the checks lane's synthetic world plus planted fields that must not be
flagged by mistake. A clean date-only source with same-day rows above 1% passes (the parser's own failure count
decides type_date_parse; a real parse failure still stops). prev and since_last read 30 days unless within= says
otherwise (the recipe engine's rule), so only within=all or a longer reach gets history_parity. Censored rows are
missing by design and never count as missing drift. Synthetic data only."""
import functools
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from new_fields_checks_helpers import load  # noqa: E402

F = load("nf_field_checks")
S = load("nf_checks_synth")


def _plant(df, rng):
    n = len(df)
    t = pd.to_datetime(df[S.TIME])
    # a statement date with no time part, on the transaction's own day for about 3% of rows
    k = np.where(rng.random(n) < 0.03, 0, rng.integers(1, 29, n))
    df["x_stmt_dt"] = (t.dt.normalize() - pd.to_timedelta(k, unit="D")).astype("datetime64[ns]")
    # ISO text dates, 5% of them text that is not a date
    good = (t - pd.to_timedelta(rng.integers(1, 200, n), unit="D")).dt.strftime("%Y-%m-%d")
    df["x_bad_dt"] = np.where(rng.random(n) < 0.05, "not a date", good)
    return df


@functools.lru_cache(maxsize=1)
def world():
    tmp = Path(tempfile.mkdtemp(prefix="nf_checks_checked_"))
    w = S.make_world(tmp)
    rng = np.random.default_rng(11)
    for base in {w["train_base"], w["june_base"]}:
        for f in sorted(Path(base).glob("part_*.parquet")):
            _plant(pd.read_parquet(f), rng).to_parquet(f, index=False)
    bt = S.base_table()
    cat = [r["feature"] for _, r in bt.iterrows() if r["type"] == "categorical" and r["source"] == "raw"][0]
    rows = [
        ("x_clean_stmt_days", "v22b", "engineered", "days_before(x_stmt_dt)", "x_stmt_dt", "continuous", {}),
        ("x_bad_dt_days", "v22b", "engineered", "days_before(x_bad_dt)", "x_bad_dt", "continuous", {}),
        ("x_prev_default", "f15298", "engineered", "prev(syn_clean_code)", "syn_clean_code", "categorical", {}),
        ("x_prev_all", "f15298", "engineered", "prev(syn_clean_code; within=all)", "syn_clean_code",
         "categorical", {}),
        ("x_since_default", "f15298", "engineered", "since_last(days)", "transaction_dttm", "continuous", {}),
        ("x_count7", "f15298", "engineered", f"count(7d; where={cat}:v0,v1)", cat, "continuous", {}),
    ]
    fm = pd.read_csv(w["map"], dtype=str, keep_default_na=False)
    fm = pd.concat([fm, S.field_map(rows).reindex(columns=fm.columns).fillna("")], ignore_index=True)
    fm.to_csv(w["map"], index=False)
    a = F.build_args(["--dry-run", "--out", str(tmp / "out")])
    a.map, a.thresholds, a.status_rules = str(w["map"]), str(w["thresholds"]), str(w["status_rules"])
    a.decisions, a.predictors, a.config = str(tmp / "KEEP_DECISIONS.csv"), str(w["predictors"]), str(w["config"])
    a.train_base, a.val_base, a.june_base = w["train_base"], w["val_base"], w["june_base"]
    a.train_files, a.val_files, a.june_files = w["train_files"], w["val_files"], w["june_files"]
    a.fit_files, a.dup_files, a.confirm_file = w["fit_files"], w["dup_files"], w["confirm_file"]
    a.no_settings_ranges, a.min_free_gb, a.cred_path = True, 0.0, None
    a.sample_rows, a.probe_accounts = min(a.sample_rows, 50_000), min(a.probe_accounts, 80)
    log = []
    rc = F.run(a, extra_builders=S.dry_run_builders(w, True), log=log.append)
    st = pd.read_csv(tmp / "out" / "field_status.csv", dtype=str, keep_default_na=False).set_index("field")
    return {"rc": rc, "status": st, "log": log, "out": tmp / "out"}


def _row(name):
    w = world()
    assert w["rc"] == 0, "\n".join(w["log"][-20:])
    return w["status"].loc[name]


def test_a_clean_date_only_source_with_same_day_rows_passes():
    r = _row("x_clean_stmt_days")
    assert "type_date_parse" not in r["reasons"] and r["result"] == "PASS", r["reasons"]


def test_a_real_parse_failure_still_stops():
    r = _row("x_bad_dt_days")
    assert r["result"] == "STOP" and "type_date_parse" in r["reasons"], r["reasons"]


def test_history_parity_reads_the_engines_lookback():
    for name in ("x_prev_default", "x_since_default"):        # 30 days by the engine's default
        assert "history_parity" not in _row(name)["reasons"], name
    r = _row("x_prev_all")                                    # within=all: every row back to the extract start
    assert r["result"] == "FLAG" and "history_parity" in r["reasons"], r["reasons"]


def test_censored_rows_are_not_missing_drift():
    for name in ("x_count7", "x_prev_default"):
        assert "missing_drift" not in _row(name)["reasons"], name
    mb = pd.read_csv(world()["out"] / "missing_by_month.csv")
    first = mb[(mb.field == "x_count7")].sort_values("month").iloc[0]
    assert first["censored"] > 0 and "missing_share_not_censored" in mb.columns


def test_the_lanes_expected_results_still_hold():
    st = world()["status"]
    bad = [(n, st.loc[n, "result"] if n in st.index else None, res) for n, (res, rule) in S.EXPECTED.items()
           if n not in st.index or st.loc[n, "result"] != res or (rule and rule not in st.loc[n, "reasons"])]
    assert not bad, bad
