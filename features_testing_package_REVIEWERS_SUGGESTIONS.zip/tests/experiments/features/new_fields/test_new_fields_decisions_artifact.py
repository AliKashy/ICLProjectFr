"""The reviewers' decisions of 2 November in the extended artifact: the cap of new code fields (D9-Y20) and the
month vocabulary information line (D4c). Synthetic data only."""
import json

import numpy as np
import pandas as pd
import pytest

from test_new_fields_data_artifact import A, B, K, check_args, fake_ckpt, lab, sha, world  # noqa: F401


def test_the_cap_keeps_values_of_ten_accounts_and_sends_the_rest_to_unknown(tmp_path):
    rows = []
    for a in range(10):                                   # "keep": 10 accounts
        rows.append({"acct": f"a{a}", "code": "keep"})
    for a in range(9):                                    # "nine": 9 accounts
        rows.append({"acct": f"b{a}", "code": "nine"})
    rows += [{"acct": "c0", "code": "busy"}] * 500        # "busy": 500 rows of one account
    df = pd.DataFrame(rows)
    first = df["acct"].isin([f"a{i}" for i in range(5)] + [f"b{i}" for i in range(5)])   # whole accounts per file
    world.write_file(df[first], tmp_path / "fit" / "part_1.parquet")
    world.write_file(df[~first], tmp_path / "fit" / "part_2.parquet")
    counts = A.accounts_per_value(A.dio.Store(None), str(tmp_path / "fit"), 1, 2, "acct", ["code"])["code"]
    assert counts["keep"][0] == 10 and counts["nine"][0] == 9 and counts["busy"] == [1, 500]
    entry = {"type": "categorical", "method": "vocab", "unk_index": 0, "missing_index": 1,
             "vocab": {"busy": 2, "keep": 3, "nine": 4}, "n_categories": 3, "cardinality": 5, "missing_frac": 0.0}
    capped, info = A.cap_vocab(entry, counts)
    assert capped["vocab"] == {"keep": 2} and capped["n_categories"] == 1 and capped["cardinality"] == 3
    assert info["as_fit"] == 3 and info["kept"] == 1 and info["rare_row_share"] == pytest.approx(509 / 519)
    from fraud.data.preprocessing import PreprocessingArtifacts
    art = PreprocessingArtifacts(features={"code": capped})
    enc = art.encode_categorical("code", pd.Series(["keep", "nine", "busy", "never seen", None]))
    assert list(enc) == [2, 0, 0, 0, 1]


def test_the_build_writes_capped_code_files_and_the_check_accepts_them(lab, monkeypatch):
    monkeypatch.setattr(A, "CAP_MIN_ACCOUNTS", 23)        # most merchants of the 24 fit accounts are now rare
    assert B.main(lab.args) == 0
    rec = json.loads((lab.c2 / "artifact" / "artifact_hashes.json").read_text())
    cap = rec["capped"]["merchant_xid"]
    ext, scr, v1 = lab.art / "nf_ext1", lab.art / "nf_scratch1", lab.art / "1"
    assert cap["kept"] < cap["as_fit"] and cap["capped_sha256"] == sha(ext / "feature__merchant_xid.json")
    assert cap["as_fit_sha256"] == sha(scr / "feature__merchant_xid.json") != cap["capped_sha256"]
    e = json.loads((ext / "feature__merchant_xid.json").read_text())
    assert sorted(e["vocab"].values()) == list(range(2, 2 + cap["kept"])) and e["cardinality"] == cap["kept"] + 2
    for f in v1.iterdir():                                 # base fields' bytes unchanged
        if f.name != "manifest.json":
            assert sha(ext / f.name) == sha(f), f.name
    # the checks measure the vocabulary before the cap
    p = lab.c2 / "checks" / "field_checks.csv"
    rows = [{"field": f.name[9:-5], "range": "train", "vocab_size": json.loads(f.read_text())["n_categories"]}
            for f in sorted(scr.glob("feature__*.json")) if json.loads(f.read_text())["type"] == "categorical"]
    from test_new_fields_data_artifact import A as _A  # noqa: F401
    import nf_data_artifact as AA
    digest = rec["payload_sha256"]["base"]
    ckpts = [fake_ckpt(lab.tmp / "ck" / f"s{i}" / "best.ckpt", digest) for i in range(2)]
    args = check_args(lab, ckpts)
    pd.DataFrame(rows).to_csv(p, index=False)
    assert K.main(args) == 0
    res = json.loads((lab.c2 / "artifact" / "artifact_check.json").read_text())
    assert res["lines"]["new_equal_scratch"]["result"] == "PASS" and res["lines"]["vocab"]["result"] == "PASS"
    assert AA.CAP_MIN_ACCOUNTS == 23


def test_the_month_vocabulary_line_is_information(lab):
    import nf_layout
    nf_layout.bootstrap()
    dtf = nf_layout.get("datetime_features")
    pre = nf_layout.get("preprocessing")
    months = pd.to_datetime([f"{y}-{m:02d}-15" for y, m in ((2024, 10), (2024, 11), (2024, 12), (2025, 1),
                                                            (2025, 2), (2025, 3), (2025, 4), (2025, 5))])
    cfg = dtf.DatetimeConfig(order_col="transaction_dttm", fields=["month"], encoding="categorical",
                             is_weekend=False)
    frame = pd.DataFrame({"transaction_dttm": np.repeat(months, [8, 7, 6, 5, 4, 3, 2, 1])})
    derived, _, _ = dtf.derive_datetime_features(frame, cfg)
    art = pre.PreprocessingArtifacts()
    art.fit_feature("month", derived["month"], "categorical")
    enc = {"month": art.encode_categorical("month", derived["month"])}
    info = K.month_vocabulary(art, enc, dtf, cfg)
    assert sorted(info["vocab"].values()) == list(range(2, 10)) and info["train_rows_at_0"] == 0
    assert info["june_index"] == 0 and info["line"].startswith("INFO  month vocabulary of version 1: ")
    # the line joins the artifact check's screen as information, and the exit code is unchanged
    assert B.main(lab.args) == 0
    rec = json.loads((lab.c2 / "artifact" / "artifact_hashes.json").read_text())
    ckpts = [fake_ckpt(lab.tmp / "ck" / f"s{i}" / "best.ckpt", rec["payload_sha256"]["base"]) for i in range(2)]
    assert K.main(check_args(lab, ckpts)) == 0
    res = json.loads((lab.c2 / "artifact" / "artifact_check.json").read_text())
    assert "month_vocabulary" in res["info"] and "month_vocabulary" not in res["lines"]


def test_the_geohash_falls_back_to_the_capped_postal_code_without_a_table(tmp_path, monkeypatch):
    import yaml
    import nf_recipes as R
    sdir = tmp_path / "settings"
    sdir.mkdir()
    (sdir / "SETTINGS.yaml").write_text(yaml.safe_dump({"geohash_table": ""}))
    monkeypatch.setenv("NF_SETTINGS_DIR", str(sdir))
    t = pd.Timestamp("2025-03-10 10:00:00")
    df = pd.DataFrame({world.ACCOUNT: ["a", "b", "c", "d"], world.TIME: [t] * 4, world.TIE: range(4),
                       "postal": ["12345-6789  ", "SW1A 1AA ", None, "98765"],
                       "ctry": ["840", "826", "840", None]})
    b = R.FileContext(df, "2024-10-01", world.engine()[0]).build(R.parse("geohash(postal; ctry)"))
    assert list(b.values) == ["12345|840", "SW1A 1AA|826", None, "98765|"]
    assert b.report["geohash_fallback"].startswith("postal code, capped")
    assert "postal code, capped" in R.parse("geohash(postal; ctry)").describe()["as_of_rule"]
