"""The reviewers' joint decisions of 2 November in the importance tool: the groups unit set and the fallback when
both does not fit the GPU cap, by the estimate or by the cost measured on the baseline pass (D6); the summary's first
line names the fit; the units that qualify under reading B are listed as information (D4b); a customer-keyed
family makes every pass score every account (D6, IMPORTANCE.md). Synthetic data only."""
import dataclasses
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pandas as pd
import pytest
import yaml
from omegaconf import OmegaConf

ROOT = Path(__file__).resolve().parents[4]
NF = ROOT / "fraud/experiments/features/new_fields"
sys.path.insert(0, str(NF))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import nf_importance as NI  # noqa: E402
from nf_importance_units import build_units, non_account_keys  # noqa: E402

SCREEN = SimpleNamespace(screen=lambda title, lines: "\n".join([title] + lines))


def test_groups_gives_the_clusters_and_singles_only_outside_them():
    clusters = pd.DataFrame([{"cluster_id": "C1", "member": m} for m in ("a", "b", "c")])
    names = ["a", "b", "c", "d", "e"]
    groups = build_units(names, clusters=clusters, units="groups")
    assert sorted(u.name for u in groups) == ["cluster:C1", "d", "e"]
    assert len(build_units(names, clusters=clusters, units="both")) == 6
    # a cluster with one active member is no group: its input stays a single
    one = pd.DataFrame([{"cluster_id": "C2", "member": "a"}, {"cluster_id": "C2", "member": "zz"}])
    assert sorted(u.name for u in build_units(names, clusters=one, units="groups")) == names


def _world(tmp_path, monkeypatch):
    from test_new_fields_importance_world import synthetic_world
    import nf_common
    cfg, checkpoint, raw, _ = synthetic_world(tmp_path, accounts=64, files=16)
    config = tmp_path / "config.yaml"
    OmegaConf.save(cfg, config)
    clusters = tmp_path / "clusters.csv"
    pd.DataFrame([{"cluster_id": "C1", "member": m} for m in ("amount", "profile", "category")]).to_csv(
        clusters, index=False)
    monkeypatch.setattr(nf_common, "C2", tmp_path / "records")
    monkeypatch.setattr(nf_common, "busy", lambda: [])
    base = ["run", "--config", str(config), "--checkpoint", str(checkpoint), "--account-share", "1",
            "--repeats", "1", "--draws", "20", "--clusters", str(clusters), "--units", "both",
            "--fallback-units", "groups"]
    return base, raw


def test_the_estimate_takes_the_fallback_when_both_exceeds_and_records_both(tmp_path, monkeypatch, capsys):
    base, _ = _world(tmp_path, monkeypatch)
    # 0.1 GPU hour a pass: both (4 singles, 1 cluster) 6 passes = 0.6 h; groups (1 cluster, month) 3 passes = 0.3 h
    cost = ["--seconds-per-row", "0.36", "--rank-a-rows", "1000"]
    out = tmp_path / "imp"
    assert NI.main(base + cost + ["--output", str(out), "--max-gpu-hours", "0.45"]) == 0
    plan = json.loads((out / "plan.json").read_text())
    assert plan["units_used"] == "groups" and set(plan["estimates"]) == {"both", "groups"}
    assert plan["estimates"]["both"]["gpu_hours"] == pytest.approx(0.6)
    assert plan["estimates"]["groups"]["gpu_hours"] == pytest.approx(0.3)
    assert sorted(pd.read_csv(out / "importance.csv").unit) == ["cluster:C1", "month"]
    assert "the fallback --units groups: 0.30 GPU hours" in capsys.readouterr().out
    # groups exceeds too: a stop with both figures, before the scorer loads
    out2 = tmp_path / "imp2"
    assert NI.main(base + cost + ["--output", str(out2), "--max-gpu-hours", "0.2"]) == 3
    err = capsys.readouterr().err
    assert "with --units both (0.60 h) and with the fallback --units groups (0.30 h)" in err
    assert not out2.exists()


def _slow_baseline(monkeypatch, seconds):
    real = NI._pass

    def slow(runner, out, name, *a, **kw):
        r = real(runner, out, name, *a, **kw)
        return dataclasses.replace(r, elapsed_seconds=seconds) if name == "baseline" else r
    monkeypatch.setattr(NI, "_pass", slow)


def test_the_cost_measured_on_the_baseline_pass_is_tested_again(tmp_path, monkeypatch, capsys):
    base, raw = _world(tmp_path, monkeypatch)
    cheap = ["--seconds-per-row", "0.000001", "--rank-a-rows", str(len(raw))]
    _slow_baseline(monkeypatch, 100.0)
    # measured: both (1 + 5) x 100 s = 0.167 h, groups (1 + 2) x 100 s = 0.083 h; the cap 0.12 takes groups
    out = tmp_path / "imp"
    assert NI.main(base + cheap + ["--output", str(out), "--max-gpu-hours", "0.12"]) == 0
    plan = json.loads((out / "plan.json").read_text())
    m = plan["measured_after_baseline"]
    assert m["both"]["gpu_hours"] == pytest.approx(600 / 3600) and m["groups"]["gpu_hours"] == pytest.approx(300 / 3600)
    assert plan["units_used"] == "groups"
    assert sorted(pd.read_csv(out / "importance.csv").unit) == ["cluster:C1", "month"]
    # both exceed: the run stops after the baseline pass with both figures; no unit pass ran
    out2 = tmp_path / "imp2"
    assert NI.main(base + cheap + ["--output", str(out2), "--max-gpu-hours", "0.05"]) == 3
    err = capsys.readouterr().err
    assert "--units both: 0.17 GPU hours; the fallback --units groups: 0.08 GPU hours" in err
    assert (out2 / "baseline.exposure.json").exists() and not (out2 / "importance.csv").exists()
    assert set(json.loads((out2 / "plan.json").read_text())["measured_after_baseline"]) == {"both", "groups"}


def test_the_summary_names_the_fit_and_lists_reading_b_as_information():
    rows = [dict(unit="amount", kind="single", drop_udr=.02, drop_ap=.01, drop_udr_ci_high=.05, drop_ap_ci_high=.03),
            dict(unit="noise", kind="single", drop_udr=-.01, drop_ap=-.002, drop_udr_ci_high=-.001,
                 drop_ap_ci_high=0.0),
            dict(unit="half", kind="single", drop_udr=-.01, drop_ap=.0, drop_udr_ci_high=-.001, drop_ap_ci_high=.01)]
    text = NI.render_summary(rows, SCREEN, run="nf_b_seed42")
    first = text.splitlines()[0]
    assert "nf_b_seed42" in first and "this stage 2 fit, not the shipped model" in first
    i = text.index("Qualify under reading B")
    assert "no field leaves this model on it" in text[i:]
    assert text[i:].splitlines()[2].strip() == "noise"
    none = NI.render_summary(rows[:1], SCREEN, run="nf_a1_seed42")
    j = none.index("Qualify under reading B")
    assert none[j:].splitlines()[2].strip() == "none"
    # a row with lower ends only never qualifies
    assert NI._reading_b(pd.DataFrame([dict(unit="x", drop_udr_ci_low=-1, drop_ap_ci_low=-1)])) == []


def test_the_queue_passes_both_and_the_groups_fallback_from_settings(tmp_path, monkeypatch):
    monkeypatch.setenv("NF_OUT", str(tmp_path / "c2"))
    import importlib.util
    spec = importlib.util.spec_from_file_location("nf_plan_imp", NF / "nf_plan.py")
    plan = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(plan)
    settings = yaml.safe_load((NF / "SETTINGS.yaml").read_text())
    args = plan.importance_args(SimpleNamespace(settings=settings))
    assert args[args.index("--units") + 1] == "both" and args[args.index("--fallback-units") + 1] == "groups"


def test_a_customer_keyed_family_makes_every_pass_score_every_account():
    """Today's behaviour, as IMPORTANCE.md says: the share applies to the whole run, so one family keyed by
    customer makes every pass, the singles' too, score 100% of the accounts."""
    fm = pd.DataFrame([
        dict(name="transaction_amt", recipe="raw", source_columns="transaction_amt", model_type="continuous"),
        dict(name="cust_sum_7d", recipe="sum(7d; value=transaction_amt; key=customer_xid)",
             source_columns="transaction_amt;customer_xid", model_type="continuous"),
        dict(name="hour", recipe="raw", source_columns="hour", model_type="continuous")])
    units = build_units(["transaction_amt", "cust_sum_7d", "hour"], field_map=fm, units="singles", unit_specs=[
        dict(name="family:transaction_amt", method="family", source_columns="transaction_amt")])
    keyed = non_account_keys(fm, units)
    assert list(keyed) == ["family:transaction_amt"]
    share = NI.account_share_for(keyed, 0.25)
    assert share == 1.0
    cost = NI.estimate_cost(10000, len(units), 1, 0.001, share)
    assert cost["estimated_selected_rows"] == 10000 and cost["scoring_passes"] == 1 + len(units)
