"""The reviewers' decisions D3b and D3d of 2 November in the CPU field checks: after-transaction rows counted from
the reasons, the label-linked stop, the CURR/PREV pair, the refresh flag; the month table without censored rows,
the present values with the chance part removed, the clock ceiling, the hold rules, the raw date and calendar code
stops, the joint time fit. The expected values are the reviewers' (flag_leak_rule.py, chance_adjust.py,
censor_fix.py, clock_ceiling.py, joint_clock_oof.py); synthetic data only."""
import importlib.util
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from new_fields_checks_helpers import load

R = load("nf_checks_rules")
M = load("nf_checks_measure")
_W = Path(__file__).resolve().parent / "new_fields_data_world.py"
_spec = importlib.util.spec_from_file_location("new_fields_data_world", _W)
world = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(world)
import nf_recipes as RC  # noqa: E402

TH = Path(__file__).resolve().parents[4] / "fraud/experiments/features/new_fields/CHECK_THRESHOLDS.yaml"
MONTHS = np.array(["2024-10", "2024-11", "2024-12", "2025-01", "2025-02", "2025-03", "2025-04", "2025-05"])


def _rules(m, th=None):
    return {rule: res for res, rule, _ in R.evaluate(dict(m, measured=True), th or R.Thresholds({}))}


def _table(keys, months):
    ct = pd.crosstab(np.asarray(keys), np.asarray(months))
    return {str(r): {str(c): int(x) for c, x in row.items() if x} for r, row in ct.iterrows()}


# ------------------------------------------------------------------ D3b


@pytest.mark.parametrize("m_f, m_n, a_f, a_n, fires", [
    (0.001, 0.001, 0.009, 0.0008, True), (0.001, 0.001, 0.009, 0.0, True), (0.01, 0.01, 0.009, 0.0008, True),
    (0.30, 0.30, 0.009, 0.0008, True), (0.001, 0.001, 0.0008, 0.0008, False), (0.001, 0.001, 0.00099, 0.00099, False),
    (0.00001, 0.00001, 0.0008, 0.00002, False)])
def test_the_seven_cases_of_the_label_linked_stop(m_f, m_n, a_f, a_n, fires):
    n_f, n_n = 12_757, 8_622_629 - 12_757
    m = {"date_nonnull_fraud": n_f, "date_after_fraud": round(a_f * n_f), "date_nonnull_nonfraud": n_n,
         "date_after_nonfraud": round(a_n * n_n), "date_nonnull": n_f + n_n,
         "date_after": round(a_f * n_f) + round(a_n * n_n), "future_by_meaning": False}
    r = _rules(m, R.Thresholds({"stop": {"date_after_fraud_ratio": 3.0, "date_after_fraud_points": 0.001}}))
    assert (r.get("date_after_fraud_linked") == "STOP") is fires
    assert "date_after_txn" not in r              # none of the cases passes the absolute levels


def test_after_transaction_rows_still_fire_the_absolute_stop_from_the_reasons():
    """A field with after-transaction rows on 0.11% of rows: the value is missing there now (D3b), and the counts
    come from the reasons and the signed difference, so date_after_txn still fires."""
    n = 100_000
    t = pd.Timestamp("2025-03-10 14:30:00")
    ev = np.where(np.arange(n) < 110, (t + pd.Timedelta(hours=2)).strftime("%Y-%m-%d %H:%M:%S"),
                  (t - pd.Timedelta(days=3)).strftime("%Y-%m-%d %H:%M:%S"))
    df = pd.DataFrame({world.ACCOUNT: [f"a{i % 5000}" for i in range(n)], world.TIME: [t] * n, world.TIE: range(n),
                       "ev_dt": pd.Series(ev, dtype=object)})
    b = RC.FileContext(df, "2024-10-01", world.engine()[0]).build(RC.parse("days_before(ev_dt)"))
    assert np.isnan(b.values[:110]).all()
    y = np.zeros(n, dtype=int)
    d = M.date_after_counts(b.signed, y)
    assert d["date_after"] == 110 and d["date_nonnull"] == n
    assert _rules(dict(d, future_by_meaning=False))["date_after_txn"] == "STOP"
    rc = M.reason_counts(b.reasons, y)
    assert rc["after_transaction"] == [0, 110] and rc["__rows__"] == [0, n]


def test_a_pair_whose_prev_is_after_curr_on_one_percent_of_rows_stops():
    n = 1000
    t = pd.Timestamp("2025-03-10 14:30:00")
    curr = [(t - pd.Timedelta(days=2)).isoformat()] * n
    prev = [(t - pd.Timedelta(days=5)).isoformat()] * n
    for i in range(10):            # 1% of rows: PREV after CURR
        prev[i] = (t - pd.Timedelta(days=1)).isoformat()
    df = pd.DataFrame({world.ACCOUNT: [f"a{i}" for i in range(n)], world.TIME: [t] * n, world.TIE: range(n),
                       "cur_dt": pd.Series(curr, dtype=object), "prv_dt": pd.Series(prev, dtype=object)})
    b = RC.FileContext(df, "2024-10-01", world.engine()[0]).build(RC.parse("days_before(cur_dt; prev=prv_dt)"))
    rep = b.report["parse"]
    m = {"prev_rows": rep["prev_rows"], "pair_both_present": rep["pair_both_present"],
         "prev_not_earlier_share": rep["prev_not_earlier"] / rep["pair_both_present"]}
    assert m["prev_not_earlier_share"] == pytest.approx(0.01)
    assert _rules(m)["prev_not_earlier"] == "STOP"
    assert "prev_not_earlier" not in _rules(dict(m, prev_not_earlier_share=0.0005))


def test_a_default_date_a_zone_shift_and_a_refresh_show():
    rng = np.random.default_rng(1)
    n = 20_000
    t = pd.Timestamp("2025-03-10 14:30:00") + pd.to_timedelta(rng.integers(0, 86_400 * 20, n), unit="s")
    d = t - pd.to_timedelta(rng.integers(3_600, 86_400 * 90, n), unit="s")
    d = pd.Series(d)
    d[: int(0.4 * n)] = pd.Timestamp("2024-01-01")                 # a 40% default date
    shift = slice(int(0.4 * n), int(0.5 * n))                       # a 5-hour zone shift
    d[shift] = t[shift] + pd.Timedelta(hours=5)
    d[int(0.5 * n): int(0.52 * n)] = t[int(0.5 * n): int(0.52 * n)].floor("s")   # 2% refreshed by the transaction
    df = pd.DataFrame({world.ACCOUNT: [f"a{i}" for i in range(n)], world.TIME: t, world.TIE: range(n), "ev_dt": d})
    b = RC.FileContext(df, "2024-10-01", world.engine()[0]).build(RC.parse("days_before(ev_dt)"))
    top = M.top_days(b.detail["day"])
    day = str(pd.Timestamp("2024-01-01").value // (86_400 * 10 ** 9))
    assert top[day] / top["__n__"] == pytest.approx(0.4, abs=1e-9)
    hours = M.hour_histogram(b.signed, b.detail["timed"])
    assert sum(v for k, v in hours.items() if int(k) == -5) >= 0.09 * n
    same = (b.detail["timed"] & (b.signed == 0)).sum() / (b.detail["day"] >= 0).sum()
    m = {"same_second_share": float(same), "same_second_prev": ""}
    assert same == pytest.approx(0.02, abs=1e-3) and _rules(m)["refreshed_by_transaction"] == "FLAG"


# ------------------------------------------------------------------ D3d


def test_the_clock_ceiling():
    assert M.clock_ceiling([1] * 8, 10)["v"] == pytest.approx(0.845154, abs=1e-6)
    real = M.clock_ceiling([31, 30, 31, 31, 28, 31, 30, 31], 10)
    assert real["v"] == pytest.approx(0.839186, abs=1e-6) and real["nmi"] == pytest.approx(0.774963, abs=1e-6)


def test_the_chance_adjusted_overlap_holds_month_codes_but_not_sparse_random_codes():
    rng = np.random.default_rng(20261102)
    keys = rng.integers(0, 70_000, size=100_000).astype(str)
    mon = MONTHS[rng.integers(0, 8, size=100_000)]
    tab = _table(keys, mon)
    raw = M.overlap_measures(tab)
    adj = M.overlap_adjusted(tab)
    assert raw["cramers_v"] > 0.7 and adj["v_adj"] < 0.1           # the raw V holds a random code; V_adj does not
    m = {"month_v_present_adj": adj["v_adj"], "month_nmi_present_adj": adj["nmi_adj"]}
    assert "repeats_month" not in _rules(m)
    # a time-local code (30-day epochs per account) repeats month
    n = 200_000
    acct = rng.integers(0, 3000, size=n)
    day = rng.uniform(0, 243, size=n)
    mon_real = MONTHS[np.searchsorted(np.cumsum([0, 31, 30, 31, 31, 28, 31, 30, 31]), day, side="right") - 1]
    dev = np.char.add(np.char.add("d", acct.astype(str)), np.char.add("_", np.floor(day / 30).astype(int).astype(str)))
    adj = M.overlap_adjusted(_table(dev, mon_real))
    assert adj["v_adj"] > 0.7
    m = {"month_v_present_adj": adj["v_adj"], "month_nmi_present_adj": adj["nmi_adj"]}
    assert _rules(m)["repeats_month"] == "WAIT"
    # the hold ends on the reviewers' recorded decision (D3d as amended on 3 November), not on an owner signature
    assert _rules(dict(m, keep_written="the data owner 2026-11-03"))["repeats_month"] == "WAIT"
    assert _rules(dict(m, month_decision="keep", month_decided_by="reviewers 2026-11-03"))["repeats_month"] == "FLAG"


def test_the_month_hold_waits_for_the_reviewers_recorded_decision(tmp_path):
    """D3d as amended on 3 November: a field that repeats month or tracks time waits until the reviewers record
    keep or drop and the reason in KEEP_DECISIONS.csv (the owner's delegation); no owner signature is asked for.
    A recorded keep lets it enter with a flag, a recorded drop stops it, and a proposed row or a row without a
    reason leaves it held."""
    F = load("nf_field_checks")
    cols = load("nf_checks_synth").map_columns()
    names = ["kept_f", "dropped_f", "proposed_f", "no_reason_f", "no_row_f"]
    fm = pd.DataFrame([{**{c: "" for c in cols}, "feasible_in_production": "yes", "name": n, "recipe": "raw"}
                       for n in names])
    dec = tmp_path / "KEEP_DECISIONS.csv"
    pd.DataFrame([
        {"name": "kept_f", "verdict": "keep", "reason": "month code checked: launch date only", "decided_by":
         "reviewers", "date": "2026-11-03"},
        {"name": "dropped_f", "verdict": "drop", "reason": "a calendar copy", "decided_by": "reviewers",
         "date": "2026-11-03"},
        {"name": "proposed_f", "verdict": "keep", "reason": "draft", "decided_by": "proposed", "date": "2026-11-03"},
        {"name": "no_reason_f", "verdict": "keep", "reason": "", "decided_by": "reviewers", "date": "2026-11-03"},
    ]).to_csv(dec, index=False)
    specs = {s["name"]: s for s in F.field_specs(fm, [], R.Thresholds({}), [], "acct", F.read_decisions(dec))}
    assert specs["kept_f"]["flags"]["month_decision"] == "keep"
    assert specs["kept_f"]["flags"]["month_decided_by"] == "reviewers 2026-11-03"
    assert specs["dropped_f"]["flags"]["month_decision"] == "drop"
    for n in ("proposed_f", "no_reason_f", "no_row_f"):
        assert "month_decision" not in specs[n]["flags"], n
    month_like = {"month_v_present_adj": 0.8, "month_nmi_present_adj": 0.6, "time_rho": 0.97}
    got = {n: R.evaluate(dict(month_like, measured=True, **specs[n]["flags"]), R.Thresholds({})) for n in names}
    res = {n: {rule: r for r, rule, _ in got[n]} for n in names}
    for rule in ("repeats_month", "tracks_time"):
        assert res["kept_f"][rule] == "FLAG" and res["dropped_f"][rule] == "STOP"
        for n in ("proposed_f", "no_reason_f", "no_row_f"):
            assert res[n][rule] == "WAIT", (n, rule)
    held = [v for r, rule, v in got["no_row_f"] if rule in ("repeats_month", "tracks_time")]
    assert all("held until the reviewers record keep or drop and the reason in KEEP_DECISIONS.csv" in v for v in held)
    assert not any("owner" in v or "in writing" in v for v in held)
    kept = [v for r, rule, v in got["kept_f"] if rule == "repeats_month"][0]
    assert "kept by the reviewers' recorded decision (reviewers 2026-11-03)" in kept


def test_a_history_warning_never_shortens_the_declared_window():
    F = load("nf_field_checks")
    cols = load("nf_checks_synth").map_columns()
    fm = pd.DataFrame([{**{c: "" for c in cols}, "feasible_in_production": "yes", "name": "cnt90",
                        "recipe": "count(90d)"}])
    sp = F.field_specs(fm, [], R.Thresholds({}), [], "acct", {})[0]
    assert "reads 90 days back" in sp["flags"]["history_parity"]
    assert sp["flags"]["history_parity"].endswith("the declared window stays")
    assert sp["recipe"] == "count(90d)"


def test_censored_rows_leave_the_overlap_table():
    rng = np.random.default_rng(20261102)
    n = 300_000
    start = np.datetime64("2024-10-01T00:00:00")
    span = int((np.datetime64("2025-06-01T00:00:00") - start) / np.timedelta64(1, "s"))
    t = start + rng.integers(0, span, size=n).astype("timedelta64[s]")
    mon = pd.Series(pd.to_datetime(t).strftime("%Y-%m"))
    v = rng.poisson(3.0, size=n).astype(float)
    cens = (t - np.timedelta64(30, "D")) < start
    v[cens] = np.nan
    s = pd.Series(v)
    keys = M.bin_keys(s, "continuous", M.decile_edges(s[~cens]))
    all_rows = M.overlap_measures(M.contingency(keys, mon, 100_000))
    unc = M.overlap_measures(M.contingency(keys[~cens], mon[~cens], 100_000))
    assert all_rows["cramers_v"] >= 0.3 and unc["cramers_v"] < 0.05
    m = {"month_v": all_rows["cramers_v"], "month_nmi": all_rows["nmi"], "month_v_uncensored": unc["cramers_v"],
         "month_nmi_uncensored": unc["nmi"]}
    assert "overlaps_month" not in _rules(m)                       # a 30-day count with censored October passes
    launched = {"month_v_uncensored": 0.408254, "month_nmi_uncensored": 0.319383, "month_v_present_adj": 0.003,
                "month_nmi_present_adj": 0.0}
    r = _rules(launched)
    assert r["overlaps_month"] == "FLAG" and "repeats_month" not in r     # a field launched on 1 January


def test_the_june_psi_reference_bins_leave_out_the_censored_rows():
    """Notes item 10.7.5: the June PSI compares June with the training rows the extract start does not censor."""
    from types import SimpleNamespace
    F = load("nf_field_checks")
    fake = SimpleNamespace(m={"f": {}}, th=None, _drift=lambda m: None)
    s = {"name": "f", "model_type": "continuous", "fn": "count", "is_date": False, "is_profile": False}
    tab = {"(missing)": {"2024-10": 900, "2024-11": 100}, "b1": {"2024-10": 100, "2024-11": 900}}
    unc = {"(missing)": {"2024-11": 100}, "b1": {"2024-10": 100, "2024-11": 900}}
    acc = {"missing": {"rows": 2000, "missing": 200, "censored": 800, "by_month": {}, "by_label": {}},
           "events": {}, "month_table": tab, "month_table_unc": unc}
    F.Checks._finish_train(fake, s, acc, None)
    assert fake.bins["f"] == {"(missing)": 100, "b1": 1000}
    june = {"(missing)": 10, "b1": 100}               # June's own bins leave its censored rows out too
    assert M.psi_counts(fake.bins["f"], june) < 0.01
    assert M.psi_counts({k: int(sum(v.values())) for k, v in tab.items()}, june) > 0.25
    # on the synthetic world: a 90-day count whose first training months are censored is not flagged
    from new_fields_checks_helpers import dry_world
    mo = pd.read_csv(dry_world()["out"] / "month_overlap.csv", keep_default_na=False).set_index("field")
    st = pd.read_csv(dry_world()["out"] / "field_status.csv", keep_default_na=False).set_index("field")
    assert float(mo.loc["syn_count_90d", "month_v"]) >= 0.3
    assert float(mo.loc["syn_count_90d", "month_v_uncensored"]) < 0.05
    assert "overlaps_month" not in st.loc["syn_count_90d", "reasons"]


def test_a_clock_is_held_and_a_half_missing_clock_too():
    assert _rules({"time_rho": 0.99})["tracks_time"] == "WAIT"
    assert "absolute_time" not in _rules({"time_rho": 0.99})
    assert _rules({"time_rho": -0.93})["tracks_time"] == "WAIT"
    assert "tracks_time" not in _rules({"time_rho": 0.5})


def test_raw_dates_and_calendar_codes_stop():
    r = _rules({"date_like_share": 0.995, "date_like_rule": "yyyymmdd number"})
    assert r["raw_date"] == "STOP"
    assert _rules({"date_like_share": 0.995, "date_like_rule": "epoch seconds number",
                   "keep_written": "the data owner 2026-11-03"})["raw_date"] == "FLAG"     # a 10-digit identifier
    assert "raw_date" not in _rules({"date_like_share": 0.5})
    assert _rules({"calendar_shape": "yyyymm"})["calendar_code"] == "STOP"
    assert _rules({"calendar_shape": "yyyymmdd"})["calendar_code"] == "STOP"
    assert _rules({"calendar_shape": "month"})["calendar_code"] == "FLAG"


def test_the_joint_time_fit_flags_one_year_spread_durations_and_not_stationary_fields():
    rng = np.random.default_rng(20261102)
    n_acct = 3000
    lam = rng.gamma(1.5, 0.6, size=n_acct)
    counts = rng.poisson(lam * 243.0)
    acct = np.repeat(np.arange(n_acct), counts)
    tday = rng.uniform(0, 243.0, size=counts.sum())
    order = np.lexsort((tday, acct))
    acct, tday = acct[order], tday[order]
    for k in (1, 4, 8):           # the reference script's earlier worlds, drawn in the same order
        rng.uniform(1, 365.25, size=(n_acct, k))
    e = -rng.uniform(1, 365.25, size=(n_acct, 18))
    X = tday[:, None] - e[acct, :]
    fold = M.account_folds(acct)
    res = M.joint_time_fit(X, tday, fold, [f"d{i}" for i in range(18)])
    assert res["rho"] == pytest.approx(0.945165, abs=1e-6)
    assert len(res["top"]) == 10
    flat = M.joint_time_fit(rng.exponential(400, size=(len(tday), 18)), tday, fold, [f"s{i}" for i in range(18)])
    assert abs(flat["rho"]) < 0.1
    assert _rules({"joint_clock": "A1 set: out-of-fold rho 0.945"})["joint_clock"] == "FLAG"


def test_the_thresholds_file_holds_the_new_levels():
    import yaml
    th = R.Thresholds(yaml.safe_load(TH.read_text()))
    assert th.num("date_after_fraud_ratio") == 3.0 and th.num("date_after_fraud_points") == 0.001
    assert th.num("joint_clock_rho") == 0.9 and th.num("refreshed_by_transaction_share") == 0.01
    assert th.num("prev_not_earlier_share") == 0.001 and th.num("raw_date_parse_share") == 0.99
    assert "replaced when it exists" not in TH.read_text() and "replaced by the stage 1" not in TH.read_text()


# ------------------------------------------------------------------ D9-Y20 and D10: capped code fields


def test_a_capped_field_reports_its_unknown_shares_and_never_stops_on_them():
    m = {"capped": True, "unk_june_capped": 0.6, "unk_june": 0.6, "unk_fit_max": 0.2, "unk_fit_file": "3",
         "capped_kept": 40}
    r = _rules(m)
    assert "unk_june" not in r and "unk_fit_files" not in r and r["unk_june_high"] == "FLAG"
    plain = dict(m, capped=False)
    r = _rules(plain)
    assert r["unk_june"] == "STOP" and r["unk_fit_files"] == "STOP"


def test_the_dry_run_writes_the_capped_report():
    from new_fields_checks_helpers import dry_world
    text = (dry_world()["out"] / "capped_fields.txt").read_text()
    assert "syn_int_nulls: kept" in text and "unknown files 1-5" in text and "fraud rate unknown" in text
    assert "10 accounts is an engineering default, not a discovered optimum." in text     # D9-Y20 wording


def test_the_date_report_says_what_the_screen_does_not_establish():
    """D3b: missingness can carry information from a post-transaction update, and a passed rarity threshold does
    not establish point-in-time availability (a source-definition condition)."""
    from new_fields_checks_helpers import dry_world
    text = (dry_world()["out"] / "date_fields.txt").read_text()
    assert "Missingness can itself carry information from a post-transaction update" in text
    assert "does not establish point-in-time availability: that is a source-definition condition." in text
    st = pd.read_csv(dry_world()["out"] / "field_status.csv", keep_default_na=False).set_index("field")
    assert "unk_fit_files" not in st.loc["syn_int_nulls", "reasons"]
