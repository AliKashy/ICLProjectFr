"""The field checks when the recipe engine refuses a recipe while building it on one file (open item f of the final
integration): an a3 field on a file whose times carry sub-second parts. The checks end with exit 0 and a STOP row
(build_refused) that names the field, the file and the engine's reason, and every other field is still checked.
Before, the run ended with the engine's RecipeError. A rerun on the same output folder reuses the partial counts and
keeps the same STOP. Synthetic data only; no bank data and no network."""
import functools
import shutil
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from new_fields_checks_helpers import load  # noqa: E402

F = load("nf_field_checks")
S = load("nf_checks_synth")

A3 = "amt_over_balance"
SUBSECOND_FILE = S.TRAIN_FILES[1]


def _args(w, tmp: Path, out: Path):
    a = F.build_args(["--dry-run", "--out", str(out)])
    a.map, a.thresholds, a.status_rules = str(w["map"]), str(w["thresholds"]), str(w["status_rules"])
    a.decisions, a.predictors, a.config = str(tmp / "KEEP_DECISIONS.csv"), str(w["predictors"]), str(w["config"])
    a.train_base, a.val_base, a.june_base = w["train_base"], w["val_base"], w["june_base"]
    a.train_files, a.val_files, a.june_files = w["train_files"], w["val_files"], w["june_files"]
    a.fit_files, a.dup_files, a.confirm_file = w["fit_files"], w["dup_files"], w["confirm_file"]
    a.no_settings_ranges, a.min_free_gb, a.cred_path = True, 0.0, None
    a.sample_rows, a.probe_accounts = min(a.sample_rows, 30_000), min(a.probe_accounts, 60)
    return a


def _run(w, tmp: Path, out: Path):
    log = []
    rc = F.run(_args(w, tmp, out), extra_builders=S.dry_run_builders(w, True), log=log.append)
    st = pd.read_csv(out / "field_status.csv", dtype=str, keep_default_na=False).set_index("field") \
        if (out / "field_status.csv").is_file() else None
    return {"rc": rc, "status": st, "log": log, "out": out}


@functools.lru_cache(maxsize=1)
def world():
    tmp = Path(tempfile.mkdtemp(prefix="nf_checks_build_refused_"))
    w = S.make_world(tmp, n_acct=150)
    for base in {w["train_base"], w["june_base"]}:
        for f in sorted(Path(base).glob("part_*.parquet")):
            df = pd.read_parquet(f)
            df["merchant_category_xcd"] = np.where(np.arange(len(df)) % 4 == 0, "5411", "5999")
            df.to_parquet(f, index=False)
    # an a3 field (the 26 October builders refuse times with sub-second parts), and sub-second times on the
    # second training file only, so the refusal comes in the middle of the training stage
    row = [(A3, "a3", "engineered", f"a3({A3})", "transaction_amt;total_available_balance_amt", "continuous", {})]
    fm = pd.read_csv(w["map"], dtype=str, keep_default_na=False)
    fm = pd.concat([fm, S.field_map(row).reindex(columns=fm.columns).fillna("")], ignore_index=True)
    fm.to_csv(w["map"], index=False)
    p = Path(w["train_base"]) / f"part_{SUBSECOND_FILE}.parquet"
    df = pd.read_parquet(p)
    t = pd.to_datetime(df[S.TIME])
    df[S.TIME] = t + pd.to_timedelta(np.where(np.arange(len(df)) % 3 == 0, 250, 0), unit="ms")
    df.to_parquet(p, index=False)
    first = _run(w, tmp, tmp / "out")
    # the same run again on a copy of the folder, as if stopped while reading training file 3: the partial counts
    # are reused (no stage rebuilds the file that refused), file 3 is read again without the refused field, and
    # the refusal is still a STOP
    shutil.copytree(tmp / "out", tmp / "out_again")
    (tmp / "out_again" / "partial" / f"train_{S.TRAIN_FILES[2]}.json").unlink()
    again = _run(w, tmp, tmp / "out_again")
    return {"first": first, "again": again}


def test_a_recipe_the_engine_refuses_while_building_is_a_stop_row_naming_field_file_and_reason():
    r = world()["first"]
    assert r["rc"] == 0, "\n".join(r["log"][-20:])
    row = r["status"].loc[A3]
    assert row["result"] == "STOP", row["reasons"]
    assert "build_refused" in row["reasons"], row["reasons"]
    assert f"train file part_{SUBSECOND_FILE}.parquet" in row["reasons"], row["reasons"]
    assert "sub-second parts" in row["reasons"], row["reasons"]
    lines = [x for x in r["log"] if x.startswith("refused while building")]
    assert len(lines) == 1 and A3 in lines[0] and f"part_{SUBSECOND_FILE}.parquet" in lines[0], r["log"]


def test_the_other_fields_are_still_checked_after_the_refusal():
    r = world()["first"]
    st = r["status"]
    for name in ("syn_clean_num", "syn_clean_code", "syn_count_24h"):
        assert st.loc[name, "result"] == "PASS", (name, st.loc[name, "reasons"])
    assert "build_refused" not in ";".join(st.drop(index=A3)["reasons"])
    fc = pd.read_csv(r["out"] / "field_checks.csv", dtype=str, keep_default_na=False)
    assert set(fc.loc[fc["field"] == "syn_clean_num", "range"]) >= {"train", "fit", "val", "june"}
    # the refused field takes no part in the duplicate and cluster checks
    dup = r["out"] / "duplicates.csv"
    if dup.is_file():
        assert A3 not in dup.read_text()


def test_a_rerun_on_the_same_folder_keeps_the_stop_and_the_other_results():
    w = world()
    a, b = w["first"], w["again"]
    assert b["rc"] == 0, "\n".join(b["log"][-20:])
    assert any(f"train file {S.TRAIN_FILES[1]}: partial counts reused" in x for x in b["log"])
    assert any(f"train file {S.TRAIN_FILES[2]}: reading" in x for x in b["log"])
    assert not any(x.startswith("refused while building: field") for x in b["log"])
    assert b["status"].loc[A3, "result"] == "STOP"
    assert b["status"].loc[A3, "reasons"] == a["status"].loc[A3, "reasons"]
    pd.testing.assert_series_equal(a["status"]["result"], b["status"]["result"])
