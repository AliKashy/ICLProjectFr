"""TFM's postal-code geohash as a recipe (part B, item 9): the rule as TFM's code applies it, the grammar, the
settings key, the history and censoring rules, the field map rows, and the check of TFM's precomputed column.

The oracle below restates TFM's two code paths line by line: pkl_s3_to_tabular._add_geohash_columns (the tabular
step's precomputed column) and tokenizer.zip_geohash_handle (the tokenizer, with fill_missing on, as the V22 runs
use it). Synthetic data only; no bank data and no network.
"""

import hashlib
import itertools
import os
import sys
import types
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import yaml

ROOT = Path(__file__).resolve().parents[4]
NF = ROOT / "fraud" / "experiments" / "features" / "new_fields"
TNF = Path(__file__).resolve().parent
for _p in (str(NF), str(ROOT / "src"), str(ROOT), str(TNF)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from new_fields_checks_helpers import load  # noqa: E402
import nf_common as C  # noqa: E402
import nf_intake as I  # noqa: E402
import nf_recipes as R  # noqa: E402

TFM_TABLE = ("s3://mrmcd-analytics-mrm-mmr/pfm/debit/account_level_transaction_dict/geohash_table/"
             "geohash_mapping_table_p3_v1.csv")
MERCHANT = "geohash(merchant_postal_xcd; merchant_country_xcd)"
HOLDER = "geohash(cprsrvc__pisinfo_cardholder_postal_xcd; cprsrvc__pisinfo_cardholder_country_xcd)"
ACQUIRER = "geohash(acquirer_postal_xcd; acquirer_country_xcd)"    # a pair TFM precomputes no column for
S3_TABLE = "s3://test-bucket/geohash_table/geohash_mapping_table_p3_v1.csv"   # never reached: Store is replaced
# every postal code against every country (the combination tests)
POSTAL_CODES = ["94108", "94108   ", " 94108", " 94108  ", "941081234", " 941081234", "94108-1234", "9410", "10001",
                "10001-0001", "00501", "501", "K1A 0B1", "k1a 0b1", "K1A 0B1  ", " K1A 0B1", "K1A0B1", "EC1A 1BB",
                "55555", "555551234", " 555551234", "NA", "", "   ", None, "60601", "60601 ", "60605", "60605  ",
                " 60605", "99999"]
COUNTRY_CODES = ["840", " 840", "840 ", "0840", "124", "826", "", None, "840.0", "USA"]
# Repeated keys (94108/840 and K1A 0B1/124, with another geohash), a blank geohash (55555), a postal code pandas
# reads as missing (NA), a blank postal code, a key with a trailing space (60601 ), a geohash with a trailing space
# (60605: "dp7 ") and a country with a trailing space (94108 with "840 ", which only a cut code whose country was
# stripped would reach). The quoted cells keep their spaces as pandas reads them, and no line ends in a space.
TABLE_CSV = """postal_code,country_code,geohash_value
94108,840,9q8
94108,840,9q9
10001,840,dr5
00501,840,dr7
K1A 0B1,124,f24
K1A 0B1,124,f2m
EC1A 1BB,826,gcp
55555,840,
NA,840,zzz
,840,abc
60601 ,840,dp3
60605,840,"dp7 "
94108,"840 ",9qy
"""
TABLE_ROWS = 13
TABLE_DTYPES = {"postal_code": str, "country_code": str, "geohash_value": str}


# ------------------------------------------------------------------------------------------ #
# TFM's code, restated (the oracle)
# ------------------------------------------------------------------------------------------ #
def tfm_tabular(df, postal_col, country_col, table):
    """pkl_s3_to_tabular: load_mapping_table_s3 drops repeated keys (keep first); _add_geohash_columns strips both
    sides of the codes (str(), then .str.strip()) and left-merges. Missing record fields are NaN there."""
    t = table.drop_duplicates(subset=["postal_code", "country_code"], keep="first")
    keyed = pd.DataFrame({"postal_code": df[postal_col].astype(str).str.strip(),
                          "country_code": df[country_col].astype(str).str.strip()})
    merged = keyed.merge(t, on=["postal_code", "country_code"], how="left")
    return merged["geohash_value"].values


def tfm_tokens(df, postal_col, country_col, table, precomputed):
    """tokenizer.zip_geohash_handle with fill_missing (the token suffix; None is the MISSING token, UNK an id the
    vocabulary lacks): the precomputed value when set and in the vocabulary, else its own lookup."""
    # _build_feature_vocab: the table's geohash values, then <prefix>_OTHER, and <prefix>_MISSING with fill_missing
    vocab = set(table["geohash_value"].dropna().unique()) | {"OTHER", "MISSING"}
    mapping = {(row["postal_code"], row["country_code"]): row["geohash_value"]   # _build_mapping_dict
               for _, row in table.iterrows()}
    out = []
    for value, country, pre in zip(df[postal_col], df[country_col], precomputed):
        if value is None or value != value:                              # _is_missing: the MISSING token
            out.append(None)
            continue
        paired = "" if country is None or country != country else str(country)   # an absent field gives ''
        if not (pre is None or pre != pre):
            pre = str(pre).strip()
            if pre and pre in vocab:
                out.append(pre)
                continue
        value = value.rstrip()
        if paired == "840" and len(value) > 5:
            value = value[:5]
        g = mapping.get((value, paired), None)
        if g:
            out.append("UNK" if isinstance(g, float) else g)             # NaN is truthy: <prefix>_nan, unknown
        else:
            out.append("OTHER")
    return out


# ------------------------------------------------------------------------------------------ #
# Helpers
# ------------------------------------------------------------------------------------------ #
@pytest.fixture(autouse=True)
def fresh_tables():
    R.clear_geohash_tables()
    yield
    R.clear_geohash_tables()


def write_settings(folder, table):
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "SETTINGS.yaml").write_text(yaml.safe_dump({"geohash_table": str(table),
                                                          "base_config": "fraud/configs/sequential_hier_allpos.yaml"}))
    return folder


@pytest.fixture()
def table_path(tmp_path, monkeypatch):
    p = tmp_path / "geohash_mapping_table.csv"
    p.write_text(TABLE_CSV)
    monkeypatch.setenv("NF_SETTINGS_DIR", str(write_settings(tmp_path / "settings", p)))
    return p


def table_frame():
    import io
    return pd.read_csv(io.StringIO(TABLE_CSV), dtype=TABLE_DTYPES)


def frame(postal, country, pcol="merchant_postal_xcd", ccol="merchant_country_xcd"):
    n = len(postal)
    return pd.DataFrame({R.ACCOUNT: [f"a{i % 3}" for i in range(n)],
                         R.TIME: pd.date_range("2024-10-02", periods=n, freq="min"),
                         R.TIE: np.arange(n),
                         pcol: pd.Series(list(postal), dtype=object), ccol: pd.Series(list(country), dtype=object)})


def build(df, recipe=MERCHANT, model_type="categorical", name="g"):
    out, stats = R.build_columns(df, [(name, recipe, model_type)], "train", engine=(None, (None, None)))
    return list(out[name]), stats[name]


def one(postal, country, recipe=MERCHANT):
    return build(frame([postal], [country]), recipe)[0][0]


# ------------------------------------------------------------------------------------------ #
# The rule
# ------------------------------------------------------------------------------------------ #
def test_whitespace_is_removed_as_tfm_removes_it(table_path):
    for postal in ("94108", "94108   ", " 94108", " 94108  ", "\t94108\n"):
        assert one(postal, "840") == "9q8", postal          # the tabular step strips both ends
    assert one("94108", " 840") == "9q8"                     # ... the country too
    assert one("94108", "840 ") == "9q8"
    # where the tabular step finds nothing, the tokenizer reads the country as stored: no strip, so no 840 cut (the
    # table's 94108 with "840 " would match a cut code)
    assert one("941081234", "840") == "9q9" and one("941081234", "840 ") == "OTHER"
    assert one("941081234   ", "840") == "9q9"               # trailing whitespace goes before the cut
    # ... and only trailing whitespace: a leading space stays, so the cut gives " 9410" (no row), not 94108 or 55555
    assert one(" 941081234", "840") == "OTHER" and one(" 555551234", "840") == "OTHER"
    # a table key that itself ends in a space never matches (TFM never strips the table)
    assert one("60601", "840") == "OTHER" and one("60601 ", "840") == "OTHER"
    # a table geohash that ends in a space: the tokenizer strips the precomputed value, which is then not in its
    # vocabulary (built from the values as stored), so its own lookup gives the value as stored; with a leading
    # space that lookup finds no row (" 6060" after the cut), so OTHER, although the tabular step found one
    assert one("60605", "840") == "dp7 " and one("60605  ", "840") == "dp7 " and one(" 60605", "840") == "OTHER"


def test_us_codes_keep_five_characters_and_no_other_country_is_cut(table_path):
    for postal in ("941081234", "94108-1234", "94108ABCD"):
        assert one(postal, "840") == "9q9", postal           # the tokenizer's cut; its dictionary keeps the last row
    assert one("9410", "840") == "OTHER"
    assert one("K1A 0B1  ", "124") == "f24"
    assert one("K1A 0B1X", "124") == "OTHER"                 # no cut outside 840
    assert one("EC1A 1BBX", "826") == "OTHER"
    for country in ("0840", "840.0", "USA", "US"):           # the country is compared as text, with no padding
        assert one("941081234", country) == "OTHER", country
    # codes are text as TFM casts them: an integer column gives "840", a float column "840.0"
    df = frame(["941081234", "941081234"], [0, 0])
    df["merchant_country_xcd"] = pd.Series([840, 840], dtype="int64")
    assert build(df)[0] == ["9q9", "9q9"]
    df["merchant_country_xcd"] = pd.Series([840.0, np.nan], dtype="float64")
    assert build(df)[0] == ["OTHER", "OTHER"]
    df = frame([0, 0], ["840", "840"])
    df["merchant_postal_xcd"] = pd.Series([10001, 501], dtype="int64")   # no padding: 501 is not 00501
    assert build(df)[0] == ["dr5", "OTHER"]


def test_unmatched_codes_give_other_and_case_is_kept(table_path):
    assert one("99999", "840") == "OTHER"
    assert one("EC1A 1BB", "826") == "gcp"
    assert one("ec1a 1bb", "826") == "OTHER" and one("k1a 0b1", "124") == "OTHER"
    assert one("K1A0B1", "124") == "OTHER"                   # inner spaces are kept


def test_missing_inputs(table_path):
    values, stats = build(frame(["94108", None, np.nan, "94108", "", "   ", "NA", "55555", "555551234"],
                                ["840", "840", "840", None, "840", "840", "840", "840", "840"]))
    # a missing postal code is missing (TFM's MISSING token); a missing country never matches; blank text is not
    # missing; "NA" in the table is missing to pandas, as to TFM; a blank geohash reads as unknown
    assert values == ["9q8", None, None, "OTHER", "OTHER", "OTHER", "OTHER", "UNK", "UNK"]
    assert stats["geohash_missing"] == 2 and stats["geohash_unknown"] == 2 and stats["censored"] == 0
    assert stats["missing_not_censored"] == 2
    assert build(frame([pd.NA], ["840"]))[0] == [None]
    t = R.load_geohash_table()
    assert t.blank_key_rows == 2 and t.blank_geohash_rows == 1


def test_repeated_rows_resolve_as_tfm_does(table_path):
    # the tabular step keeps the first repeated row; the tokenizer's own lookup (a cut US code) the last
    assert one("94108", "840") == "9q8" and one("941081234", "840") == "9q9"
    assert one("K1A 0B1", "124") == "f24"
    s = R.load_geohash_table().summary()
    assert s["repeated_rows"] == 2 and s["conflicting_keys"] == 2 and s["rows"] == TABLE_ROWS


def combinations(pcol="merchant_postal_xcd", ccol="merchant_country_xcd"):
    """Every postal code with every country, in a shuffled order (missing codes as NaN, as TFM's frames hold them)."""
    rows = [(p, c) for p in POSTAL_CODES for c in COUNTRY_CODES]
    rng = np.random.default_rng(20261102)
    rows = [rows[i] for i in rng.permutation(len(rows))]
    return rows, frame([p if p is not None else np.nan for p, _ in rows],
                       [c if c is not None else np.nan for _, c in rows], pcol, ccol)


def test_the_recipe_equals_tfm_code_on_every_combination(table_path):
    rows, df = combinations()
    table = table_frame()
    pre = tfm_tabular(df, "merchant_postal_xcd", "merchant_country_xcd", table)
    want = tfm_tokens(df, "merchant_postal_xcd", "merchant_country_xcd", table, pre)
    got, _ = build(df)
    bad = [(rows[i], got[i], want[i]) for i in range(len(rows)) if got[i] != want[i]]
    assert not bad, bad[:10]
    # the recipe's first lookup is TFM's precomputed column, row for row
    _, first, _ = R.load_geohash_table().lookup(df["merchant_postal_xcd"], df["merchant_country_xcd"])
    assert [R._clean(x) for x in first] == [R._clean(x) for x in pre]
    assert len(set(want)) >= 6


def test_a_pair_tfm_does_not_precompute_takes_the_tokenizer_lookup_alone(table_path):
    """TFM's tabular step makes a column for its two pairs only; for any other pair TFM's tokenizer has no
    precomputed value and runs its own lookup (trailing whitespace only; the last of repeated rows)."""
    pcol, ccol = "acquirer_postal_xcd", "acquirer_country_xcd"
    rows, df = combinations(pcol, ccol)
    want = tfm_tokens(df, pcol, ccol, table_frame(), [None] * len(df))
    got, stats = build(df, ACQUIRER)
    bad = [(rows[i], got[i], want[i]) for i in range(len(rows)) if got[i] != want[i]]
    assert not bad, bad[:10]
    assert stats["geohash_first"] == 0 and stats["geohash_second"] > 0
    _, first, _ = R.load_geohash_table().lookup(df[pcol], df[ccol], precomputed=False)
    assert all(x is None for x in first)                       # no tabular value for this pair
    # the same codes give other values than for the merchant's pair, which TFM precomputes
    codes = frame([" 94108", "94108", "K1A 0B1"], ["840", "840", "124"], pcol, ccol)
    assert build(codes, ACQUIRER)[0] == ["OTHER", "9q9", "f2m"]
    assert [one(p, c) for p, c in ((" 94108", "840"), ("94108", "840"), ("K1A 0B1", "124"))] == ["9q8", "9q8", "f24"]
    assert "tokenizer lookup only" in R.parse(ACQUIRER).describe()["as_of_rule"]
    assert "TFM's two lookups" in R.parse(MERCHANT).describe()["as_of_rule"]


# ------------------------------------------------------------------------------------------ #
# The grammar and the history rules
# ------------------------------------------------------------------------------------------ #
def test_grammar_parses_and_refuses_a_malformed_geohash():
    r = R.parse(MERCHANT)
    assert (r.op, r.column, r.country, r.sources) == ("geohash", "merchant_postal_xcd", "merchant_country_xcd",
                                                     ["merchant_postal_xcd", "merchant_country_xcd"])
    p = I.parse_recipe(HOLDER)
    assert p["func"] == "geohash" and p["columns"] == ["cprsrvc__pisinfo_cardholder_postal_xcd",
                                                      "cprsrvc__pisinfo_cardholder_country_xcd"]
    assert p["window"] == "" and p["lag"] == "" and p["lookback_seconds"] == 0
    for bad in ("geohash()", "geohash(merchant_postal_xcd)", "geohash(a; b; c)", "geohash(a, b)", "geohash(a; a)",
                "geohash(a; b; key=c)", "geohash(a; b; within=30d)", "geohash(a b; c)", "geohash(a;)",
                "geohash(frd_tag; c)", "geohash(cprsrvc__pisinfo; merchant_country_xcd)", "geohash a; b",
                "geohash[a; b]", "Geohash(a; b)"):
        with pytest.raises(R.RecipeError):
            R.parse(bad)
        with pytest.raises(I.RecipeError):
            I.parse_recipe(bad)


def test_a_row_level_recipe_passes_the_history_and_censoring_rules(table_path):
    r = R.parse(MERCHANT)
    assert not r.is_history and r.is_engineered and r.lookback_seconds == 0 and r.history_key == R.ACCOUNT
    d = r.describe()
    assert d["censoring_rule"] == "" and d["history_parity"] == "" and d["lookback"] == "" and d["window"] == ""
    assert d["time_key"] == R.TIME and d["group_key"] == ""
    df = frame(["94108", "941081234", None, "10001", "K1A 0B1", "99999"] * 3, ["840", "840", "840", "840", "124",
                                                                               "840"] * 3)
    values, stats = build(df)
    assert stats["censored"] == 0
    # a row's value depends on that row only: reordering rows or deleting earlier rows changes no value
    order = np.random.default_rng(1).permutation(len(df))
    shuffled, _ = build(df.iloc[order].reset_index(drop=True))
    assert shuffled == [values[i] for i in order]
    later, _ = build(df.iloc[7:].reset_index(drop=True))
    assert later == values[7:]
    F = load("nf_field_checks")
    assert "geohash" in F.NO_WINDOW and "geohash" in F.ROW_LEVEL and "geohash" not in F.HISTORY_NO_WINDOW


def test_dependency_closure_and_required_columns_list_both_sources():
    fmap = pd.DataFrame([
        {"name": "geohash__merchant_postal_xcd", "recipe": MERCHANT, "model_type": "categorical"},
        {"name": "merchant_country_xcd", "recipe": "raw", "model_type": "categorical"},
        {"name": "transaction_amt", "recipe": "raw", "model_type": "continuous"}])
    dep = R.dependency_closure(fmap, ["geohash__merchant_postal_xcd"])
    assert dep == {"sources": {"merchant_postal_xcd", "merchant_country_xcd"},
                   "outputs": {"geohash__merchant_postal_xcd"}}
    # perturbing the country rebuilds the geohash too (a family)
    assert "geohash__merchant_postal_xcd" in R.dependency_closure(fmap, ["merchant_country_xcd"])["outputs"]
    assert R.required_columns(fmap, ["geohash__merchant_postal_xcd"]) == [
        R.ACCOUNT, R.TIME, R.TIE, "merchant_postal_xcd", "merchant_country_xcd"]
    # a blocked country column blocks the geohash that reads it (design review item 28)
    assert R.inherited_flags(fmap, {"merchant_country_xcd": "WAIT"}) == {
        "geohash__merchant_postal_xcd": ["source merchant_country_xcd: WAIT"]}


def test_build_refuses_a_geohash_that_is_not_a_category(table_path):
    with pytest.raises(R.RecipeError, match="categorical"):
        build(frame(["94108"], ["840"]), model_type="continuous")


def test_build_columns_uses_the_table_it_is_given(tmp_path, monkeypatch):
    # a run reads the table once and passes it on: SETTINGS.yaml is then not read again (here it names none)
    monkeypatch.setenv("NF_SETTINGS_DIR", str(write_settings(tmp_path / "blank", "")))
    own = R.GeohashTable(pd.DataFrame({"postal_code": ["94108"], "country_code": ["840"], "geohash_value": ["abc"]}),
                         source="given", sha256="0" * 64)
    out, stats = R.build_columns(frame(["94108", "10001"], ["840", "840"]), [("g", MERCHANT, "categorical")],
                                 "train", engine=(None, (None, None)), geohash_table=own)
    assert list(out["g"]) == ["abc", "OTHER"]
    assert stats["g"]["geohash_table"] == "given" and stats["g"]["geohash_table_sha256"] == "0" * 64
    # without it, the blank key gives the postal-code fallback (the reviewers' decision D9-Y20), capped later
    assert list(build(frame(["94108"], ["840"]))[0]) == ["94108|840"]


# ------------------------------------------------------------------------------------------ #
# The settings key and the table
# ------------------------------------------------------------------------------------------ #
def test_the_settings_key_defaults_to_tfm_table_and_a_local_copy_works(tmp_path, monkeypatch):
    shipped = yaml.safe_load((NF / "SETTINGS.yaml").read_text())
    assert shipped["geohash_table"] == TFM_TABLE
    monkeypatch.delenv("NF_SETTINGS_DIR", raising=False)
    assert R.geohash_table_path() == TFM_TABLE                       # through the settings loader
    local = tmp_path / "copy.csv"
    local.write_text(TABLE_CSV)
    monkeypatch.setenv("NF_SETTINGS_DIR", str(write_settings(tmp_path / "s1", local)))
    t = R.load_geohash_table()
    assert t.sha256 == C.sha256_file(local) and t.rows == TABLE_ROWS and t.lengths == [3]
    assert R.load_geohash_table() is t                                # read once
    rel = os.path.relpath(local, C.ROOT)                              # a path relative to the project root
    R.clear_geohash_tables()
    monkeypatch.setenv("NF_SETTINGS_DIR", str(write_settings(tmp_path / "s2", rel)))
    assert R.load_geohash_table().sha256 == t.sha256
    # a changed local file is read again (its size changes too, so a coarse clock cannot hide the change)
    local.write_text(TABLE_CSV.replace("gcp", "gcpz"))
    assert R.load_geohash_table().sha256 != t.sha256


def test_a_blank_or_unreadable_table_is_refused(tmp_path, monkeypatch):
    monkeypatch.setenv("NF_SETTINGS_DIR", str(write_settings(tmp_path / "blank", "")))
    with pytest.raises(R.RecipeError, match="geohash_table is blank"):
        R.load_geohash_table()
    # the recipe itself falls back to the normalized postal code with its country (decision D9-Y20)
    assert list(build(frame(["94108"], ["840"]))[0]) == ["94108|840"]
    monkeypatch.setenv("NF_SETTINGS_DIR", str(write_settings(tmp_path / "gone", tmp_path / "no_such.csv")))
    with pytest.raises(R.RecipeError, match="cannot be read"):
        R.load_geohash_table()
    bad = tmp_path / "bad.csv"
    bad.write_text("postal_code,geohash_value\n94108,9q8\n")
    with pytest.raises(R.RecipeError, match="country_code"):
        R.load_geohash_table(str(bad))


def test_cell_sizes_follow_the_geohash_length():
    w3, h3 = R.geohash_cell_km(3)
    w4, h4 = R.geohash_cell_km(4)
    w5, h5 = R.geohash_cell_km(5)
    assert round(w3) == 157 and round(h3) == 157                     # about 156 by 156 km
    assert round(w4, 1) == 39.1 and round(h4, 1) == 19.6
    assert round(w5, 1) == 4.9 and round(h5, 1) == 4.9
    assert 119 < w3 * np.cos(np.radians(40)) < 121                     # about 120 km wide at 40 degrees north
    t = R.GeohashTable(pd.DataFrame({"postal_code": ["1", "2"], "country_code": ["840", "840"],
                                     "geohash_value": ["9q8yy", "9q8yz"]}))
    assert t.summary()["precision"] == [5] and t.summary()["cell_km"][5] == [4.9, 4.9]


# ------------------------------------------------------------------------------------------ #
# The intake's map checks
# ------------------------------------------------------------------------------------------ #
def map_row(**kw):
    r = {c: "" for c in C.FIELD_MAP_COLUMNS}
    r.update(name="geohash__merchant_postal_xcd", group="v22b", kind="engineered", recipe=MERCHANT,
             source_columns="merchant_postal_xcd;merchant_country_xcd", model_type="categorical",
             definition_version="1", excluded_by_sumegha="no", feasible_in_production="yes",
             list_status="UNCONFIRMED")
    r.update(kw)
    return r


def check(rows):
    df = pd.DataFrame(rows, columns=C.FIELD_MAP_COLUMNS)
    rules = I.status_rules(NF / "STATUS_RULES.csv")
    thr = C.load_yaml(NF / "CHECK_THRESHOLDS.yaml")
    _, res = I.check_map(df, pod=None, base=["transaction_amt"], rules=rules, thr=thr)
    return {x["name"]: x for x in res}


def stops(x):
    return [rr for rr in x["reasons"] if rr.startswith("STOP")]


def test_check_map_takes_the_geohash_row_and_names_its_faults(table_path):
    res = check([map_row(), map_row(name="g_cont", model_type="continuous"),
                 map_row(name="g_one", source_columns="merchant_postal_xcd"),
                 map_row(name="g_generic", recipe="geohash(merchant_postal_xcd; cprsrvc__pisinfo)",
                         source_columns="merchant_postal_xcd;cprsrvc__pisinfo")])
    assert not stops(res["geohash__merchant_postal_xcd"]), res["geohash__merchant_postal_xcd"]["reasons"]
    assert any("bad_value" in s and "categorical" in s for s in stops(res["g_cont"]))
    assert any("source_columns" in s and "merchant_country_xcd" in s for s in stops(res["g_one"]))
    assert any("generic_source" in s for s in stops(res["g_generic"]))


def test_check_map_stops_a_geohash_when_the_settings_key_is_blank(tmp_path, monkeypatch):
    monkeypatch.setenv("NF_SETTINGS_DIR", str(write_settings(tmp_path / "blank", "")))
    res = check([map_row()])
    assert any(s.startswith("STOP geohash_table") for s in stops(res["geohash__merchant_postal_xcd"]))


# ------------------------------------------------------------------------------------------ #
# TFM's precomputed column against the recipe
# ------------------------------------------------------------------------------------------ #
def test_the_precomputed_column_is_compared_with_the_first_lookup(table_path):
    df = frame(["94108", " 94108", "941081234", "10001", "99999", None, None, "K1A 0B1", "00501"],
               ["840", "840", "840", "840", "840", "840", "840", "124", "840"])
    df["merchant_geohash"] = ["9q8", " 9q8 ", np.nan, "dr5", "", np.nan, "zzz", "f2m", "dr7"]
    m = R.precomputed_geohash_match(df, MERCHANT, "merchant_geohash")
    # row 7 (missing postal, empty column) is not counted; row 3 (ZIP+4) has no precomputed value in TFM either;
    # row 6 holds a value for a missing postal code; row 8 differs (the other repeated row)
    assert m == {"column": "merchant_geohash", "rows": 8, "match": 6, "tfm_only": 1, "ours_only": 0, "differ": 1}
    assert R.tfm_geohash_column(R.parse(MERCHANT)) == "merchant_geohash"
    assert R.tfm_geohash_column(R.parse(HOLDER)) == "cprsrvc__pisinfo_cardholder_geohash"
    assert R.tfm_geohash_column(R.parse("geohash(acquirer_postal_xcd; acquirer_country_xcd)")) is None


def test_the_rule_flags_a_match_below_99_9_percent_with_the_count():
    Rules = load("nf_checks_rules")
    th = Rules.Thresholds(yaml.safe_load((NF / "CHECK_THRESHOLDS.yaml").read_text()))
    assert th.num("tfm_geohash_match_min") == 0.999 and "tfm_geohash_match_min" not in th.defaulted

    def rules(match, rows=1000):
        m = {"measured": True, "tfm_geohash_match": {"column": "merchant_geohash", "rows": rows, "match": match,
                                                     "tfm_only": 0, "ours_only": rows - match, "differ": 0}}
        return [x for x in Rules.evaluate(m, th) if x[1] == "tfm_geohash_match"]

    fired = rules(998)
    assert len(fired) == 1 and fired[0][0] == "FLAG"
    assert "99.800% of 1000 rows match; 2 differ" in fired[0][2]
    assert rules(999) == [] and rules(1000) == []                      # 99.9% exactly is not below
    assert rules(0, rows=0) == []


@pytest.fixture(scope="module")
def checked(tmp_path_factory):
    """The CPU field checks on a small synthetic world with both geohash fields and TFM's precomputed columns:
    the merchant column differs on a few rows, the cardholder column agrees everywhere. A third geohash row is not
    a category. The table file is removed once the run has read it, so every build and comparison after that uses
    the table the run read (a table replaced during a run cannot mix into its counts)."""
    S, F = load("nf_checks_synth"), load("nf_field_checks")
    tmp = tmp_path_factory.mktemp("geohash_checks")
    table = tmp / "geohash_mapping_table.csv"
    table.write_text(TABLE_CSV)
    settings = write_settings(tmp / "settings", table)
    old = os.environ.get("NF_SETTINGS_DIR")
    os.environ["NF_SETTINGS_DIR"] = str(settings)
    try:
        R.clear_geohash_tables()
        world = S.make_world(tmp / "w", n_acct=40)
        tdf = table_frame()
        rng = np.random.default_rng(5)
        codes = [("94108", "840"), ("94108  ", "840"), ("941081234", "840"), ("10001", "840"), ("00501", "840"),
                 ("K1A 0B1", "124"), ("EC1A 1BB", "826"), ("99999", "840"), (None, "840"), ("10001", None)]
        n_changed = 0
        for base in (world["train_base"], world["june_base"]):
            for p in sorted(Path(base).glob("part_*.parquet")):
                df = pd.read_parquet(p)
                for prefix, col in (("merchant", "merchant_geohash"),
                                    ("cprsrvc__pisinfo_cardholder", "cprsrvc__pisinfo_cardholder_geohash")):
                    pick = rng.integers(0, len(codes), len(df))
                    df[f"{prefix}_postal_xcd"] = pd.Series([codes[i][0] for i in pick], dtype=object)
                    df[f"{prefix}_country_xcd"] = pd.Series([codes[i][1] for i in pick], dtype=object)
                    pre = tfm_tabular(df.assign(**{f"{prefix}_postal_xcd": df[f"{prefix}_postal_xcd"].where(
                        df[f"{prefix}_postal_xcd"].notna(), np.nan)}), f"{prefix}_postal_xcd",
                        f"{prefix}_country_xcd", tdf)
                    pre = pd.Series(pre, dtype=object)
                    if prefix == "merchant" and int(p.stem.split("_")[1]) in S.TRAIN_FILES:
                        bad = np.flatnonzero(pre.notna().to_numpy())[:3]   # three planted rows per training file
                        pre.iloc[bad] = "zzz"
                        n_changed += len(bad)
                    df[col] = pre
                df.to_parquet(p, index=False)
        rows = [("geohash__merchant_postal_xcd", "v22b", "engineered", MERCHANT,
                 "merchant_postal_xcd;merchant_country_xcd", "categorical", {}),
                ("geohash__cprsrvc__pisinfo_cardholder_postal_xcd", "v22b", "engineered", HOLDER,
                 "cprsrvc__pisinfo_cardholder_postal_xcd;cprsrvc__pisinfo_cardholder_country_xcd", "categorical", {}),
                ("geohash_as_a_number", "v22b", "engineered", MERCHANT, "merchant_postal_xcd;merchant_country_xcd",
                 "continuous", {})]
        S.field_map(rows=rows).to_csv(tmp / "FIELD_MAP.csv", index=False)
        out = tmp / "out"
        a = F.build_args(["--map", str(tmp / "FIELD_MAP.csv"), "--thresholds", str(NF / "CHECK_THRESHOLDS.yaml"),
                          "--status-rules", str(world["status_rules"]), "--decisions", str(tmp / "KEEP.csv"),
                          "--predictors", str(world["predictors"]), "--config", str(world["config"]),
                          "--train-base", world["train_base"], "--train-files", world["train_files"],
                          "--val-base", world["val_base"], "--val-files", world["val_files"],
                          "--june-base", world["june_base"], "--june-files", world["june_files"],
                          "--fit-files", world["fit_files"], "--dup-files", world["dup_files"],
                          "--confirm-file", world["confirm_file"], "--no-settings-ranges", "--min-free-gb", "0",
                          "--probe-accounts", "30", "--out", str(out)])
        log = []
        presence = F.Checks.presence

        def presence_after_removing_the_table(self, ranges):
            table.unlink()
            return presence(self, ranges)

        with pytest.MonkeyPatch.context() as mp:
            mp.setattr(F.Checks, "presence", presence_after_removing_the_table)
            rc = F.run(a, log=log.append)
        table_removed = not table.exists()
    finally:
        if old is None:
            os.environ.pop("NF_SETTINGS_DIR", None)
        else:
            os.environ["NF_SETTINGS_DIR"] = old
        R.clear_geohash_tables()
    return {"rc": rc, "out": out, "log": log, "changed": n_changed, "table_removed": table_removed}


def test_field_checks_flag_a_precomputed_column_that_differs(checked):
    assert checked["rc"] == 0, checked["log"][-5:]
    assert checked["table_removed"]                       # every file was built with the table read at the start
    st = pd.read_csv(checked["out"] / "field_status.csv", keep_default_na=False).set_index("field")
    merchant = st.loc["geohash__merchant_postal_xcd", "reasons"]
    holder = st.loc["geohash__cprsrvc__pisinfo_cardholder_postal_xcd", "reasons"]
    assert "FLAG tfm_geohash_match (merchant_geohash: " in merchant
    assert f"; {checked['changed']} differ (TFM only 0, recipe only 0, different {checked['changed']})" in merchant
    assert "tfm_geohash_match" not in holder
    for reasons in (merchant, holder):
        assert "not_strictly_earlier" not in reasons and "history_parity" not in reasons
    fc = pd.read_csv(checked["out"] / "field_checks.csv", keep_default_na=False)
    cell = fc[(fc.field == "geohash__cprsrvc__pisinfo_cardholder_postal_xcd") & (fc.range == "train")][
        "tfm_geohash_match"].iloc[0]
    assert '"column": "cprsrvc__pisinfo_cardholder_geohash"' in cell and '"share": 1.0' in cell
    text = (checked["out"] / "summary.txt").read_text()
    assert "TFM's precomputed geohash: geohash__merchant_postal_xcd vs merchant_geohash" in text
    assert "p3 cells about 156.5 x 156.5 km" in text and "repeated rows" in text
    assert all(len(line) <= 90 for line in text.splitlines()) and len(text.splitlines()) <= 40


def test_field_checks_leave_a_geohash_that_is_not_a_category_unbuilt(checked, table_path):
    st = pd.read_csv(checked["out"] / "field_status.csv", keep_default_na=False).set_index("field")
    reasons = st.loc["geohash_as_a_number", "reasons"]
    assert st.loc["geohash_as_a_number", "result"] == "WAIT"
    assert "WAIT not_built (the recipes module refuses this recipe: geohash(...) gives a category; model_type " \
           "must be categorical" in reasons, reasons
    lines = (checked["out"] / "summary.txt").read_text().splitlines()
    at = next(i for i, line in enumerate(lines) if line.startswith("TFM's precomputed geohash: "))
    block = [lines[at]] + list(itertools.takewhile(lambda line: line.startswith("  "), lines[at + 1:]))
    assert "geohash__merchant_postal_xcd" in block[0] and "geohash_as_a_number" not in " ".join(block)
    assert "WAIT not_built 1: geohash_as_a_number" in lines
    # the builder itself refuses it too, rather than cast the codes to numbers that are all missing
    F = load("nf_field_checks")
    spec = {"fn": "geohash", "name": "g", "recipe": MERCHANT, "row": {"model_type": "continuous"}}
    builder = F.Builder(R, account=R.ACCOUNT, time=R.TIME)
    assert builder.refused(spec) == F.GEOHASH_NOT_CATEGORICAL
    assert builder.refused(dict(spec, row={"model_type": ""})) == F.GEOHASH_NOT_CATEGORICAL   # blank: a number
    assert builder.refused(dict(spec, row={"model_type": "categorical"})) == ""
    with pytest.raises(R.RecipeError, match="g: geohash.*must be categorical"):
        builder.build(spec, frame(["94108"], ["840"]), "2024-10-01")


def test_the_builder_uses_the_table_the_run_read(tmp_path, monkeypatch):
    F = load("nf_field_checks")
    monkeypatch.setenv("NF_SETTINGS_DIR", str(write_settings(tmp_path / "blank", "")))   # no table to read again
    builder = F.Builder(R, account=R.ACCOUNT, time=R.TIME)
    builder.geohash_table = R.GeohashTable(table_frame(), source="run", sha256="1" * 64)
    spec = {"fn": "geohash", "name": "g", "recipe": MERCHANT, "row": {"model_type": "categorical"}}
    values, cens = builder.build(spec, frame(["94108", "941081234", None], ["840", "840", "840"]), "2024-10-01")
    assert [None if pd.isna(v) else v for v in values] == ["9q8", "9q9", None] and not cens.any()


def test_the_table_hash_joins_the_run_identity(tmp_path):
    """Partial counts made with one table are recomputed, never reused, after the table changes."""
    F = load("nf_field_checks")

    def checks(sha):
        a = types.SimpleNamespace(account_col="acct", time_col="t", id_col="id", label_col="y",
                                  geohash_table_sha256=sha)
        th = types.SimpleNamespace(num=lambda key: 1000)
        return F.Checks(a, th, "thresholds", "map", [], {}, F.Builder(), None, tmp_path / "out", log=lambda *x: None)

    first, same, other, none = checks("a" * 64), checks("a" * 64), checks("b" * 64), checks(None)
    assert first.run_sha == same.run_sha
    assert len({first.run_sha, other.run_sha, none.run_sha}) == 3
    first._pput("train_1", {"rows": 7})
    assert same._pget("train_1") == {"rows": 7} and other._pget("train_1") is None


def test_field_checks_read_an_s3_table_with_the_data_credentials(tmp_path, monkeypatch):
    """The table on S3 is read with the credentials the run reads its files with: --cred-path, else the config's
    s3.cred_path. No network: the store records each read and fails as an unreachable bucket would."""
    S, F = load("nf_checks_synth"), load("nf_field_checks")
    import nf_data_io as dio
    reads = []

    class S3Store:
        def __init__(self, cred_path=None):
            self.cred_path = cred_path

        def read_bytes(self, path):
            reads.append((self.cred_path, path))
            raise OSError("no S3 in tests")

    class LocalFiles(F.Files):   # the world's files are local: no credentials file is opened for them
        def __init__(self, cred_path):
            self.fs = None

    monkeypatch.setattr(dio, "Store", S3Store)
    monkeypatch.setattr(F, "Files", LocalFiles)
    monkeypatch.setenv("NF_SETTINGS_DIR", str(write_settings(tmp_path / "s", S3_TABLE)))
    world = S.make_world(tmp_path / "w", n_acct=5)
    cfg = yaml.safe_load(Path(world["config"]).read_text())
    cfg["s3"] = {"cred_path": "creds/from_config.yaml"}
    (tmp_path / "config.yaml").write_text(yaml.safe_dump(cfg))
    S.field_map(rows=[("geohash__merchant_postal_xcd", "v22b", "engineered", MERCHANT,
                       "merchant_postal_xcd;merchant_country_xcd", "categorical", {})]).to_csv(
        tmp_path / "FIELD_MAP.csv", index=False)
    for extra, cred in ((["--cred-path", "creds/pod_s3.yaml"], "creds/pod_s3.yaml"), ([], "creds/from_config.yaml")):
        reads.clear()
        a = F.build_args(["--map", str(tmp_path / "FIELD_MAP.csv"), "--config", str(tmp_path / "config.yaml"),
                          "--predictors", str(world["predictors"]), "--train-base", world["train_base"],
                          "--june-base", world["june_base"], "--no-settings-ranges", "--min-free-gb", "0",
                          "--out", str(tmp_path / f"out{len(extra)}")] + extra)
        log = []
        assert F.run(a, log=log.append) == C.REFUSED
        assert reads == [(cred, S3_TABLE)]
        assert any(line.startswith("refused: geohash field(s) geohash__merchant_postal_xcd: the geohash table "
                                   f"{S3_TABLE} cannot be read (OSError: no S3 in tests)") for line in log), log


def test_field_checks_refuse_an_unreadable_table(tmp_path, monkeypatch):
    S, F = load("nf_checks_synth"), load("nf_field_checks")
    monkeypatch.setenv("NF_SETTINGS_DIR", str(write_settings(tmp_path / "s", tmp_path / "missing.csv")))
    world = S.make_world(tmp_path / "w", n_acct=5)
    S.field_map(rows=[("geohash__merchant_postal_xcd", "v22b", "engineered", MERCHANT,
                       "merchant_postal_xcd;merchant_country_xcd", "categorical", {})]).to_csv(
        tmp_path / "FIELD_MAP.csv", index=False)
    a = F.build_args(["--map", str(tmp_path / "FIELD_MAP.csv"), "--config", str(world["config"]),
                      "--predictors", str(world["predictors"]), "--train-base", world["train_base"],
                      "--june-base", world["june_base"], "--no-settings-ranges", "--min-free-gb", "0",
                      "--out", str(tmp_path / "out")])
    log = []
    assert F.run(a, log=log.append) == C.REFUSED
    assert any(line.startswith("refused: geohash field(s) geohash__merchant_postal_xcd") for line in log)
    assert not (tmp_path / "out" / "field_status.csv").exists()


# ------------------------------------------------------------------------------------------ #
# The field map rows, the drafts, the workbook and the enriched copies
# ------------------------------------------------------------------------------------------ #
def csv_rows(name):
    return pd.read_csv(NF / name, dtype=str, keep_default_na=False)


def test_the_two_v22b_postal_rows_are_geohash_recipes_with_the_raw_code_as_alternative():
    attrs = csv_rows("DRAFT_FEATURE_ATTRIBUTES_UNCONFIRMED.csv").set_index("name")
    keep = csv_rows("KEEP_DECISIONS.csv").set_index("name")
    tfm = csv_rows("DRAFT_TFM_FIELDS_UNCONFIRMED.csv").set_index("v22b_importance_rank")
    for rank, postal, country in (("8", "merchant_postal_xcd", "merchant_country_xcd"),
                                  ("30", "cprsrvc__pisinfo_cardholder_postal_xcd",
                                   "cprsrvc__pisinfo_cardholder_country_xcd")):
        name = f"geohash__{postal}"
        a = attrs.loc[name]
        assert (a["kind"], a["recipe"], a["source_columns"], a["model_type"], a["raw_alternative"]) == (
            "engineered", f"geohash({postal}; {country})", f"{postal};{country}", "categorical", postal)
        assert a["v22b_rank"] == rank and a["group"] == "v22b"
        assert keep.loc[name, "verdict"] == "keep" and keep.loc[name, "decided_by"] == "proposed"
        assert "geohash" in keep.loc[name, "reason"] and "proposed alternative" in keep.loc[name, "reason"]
        assert tfm.loc[rank, "name"] == name and tfm.loc[rank, "pod_column"] == postal
        assert postal not in attrs.index and postal not in keep.index       # the raw code is not a row of its own
        assert country in attrs.index                                       # the country stays a V22B row
        R.parse(a["recipe"])
    # the intake's draft carries the recipe as written
    draft = {r["name"]: r for r in I.draft_rows(attrs.reset_index())}
    d = draft["geohash__merchant_postal_xcd"]
    assert (d["kind"], d["recipe"], d["model_type"]) == ("engineered", MERCHANT, "categorical")


def test_the_workbook_shows_the_raw_postal_code_as_the_proposed_alternative():
    from openpyxl import load_workbook
    import importlib.util
    spec = importlib.util.spec_from_file_location("nf_workbook_builder_geohash", NF / "build_feature_workbook.py")
    wb_mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(wb_mod)
    assert wb_mod.proposed_alternative({"recipe": MERCHANT, "raw_alternative": "merchant_postal_xcd"}) == \
        "merchant_postal_xcd (raw)"
    assert wb_mod.proposed_alternative({"recipe": "code(x)", "mapping_status": "open"}) == "code(x)"
    ws = load_workbook(NF / "FEATURE_WORKBOOK_REVIEWERS_SUGGESTIONS.xlsx", read_only=True)["TFM V22B features"]
    rows = list(ws.iter_rows(values_only=True))
    head = list(rows[0])
    by = {r[head.index("name")]: dict(zip(head, r)) for r in rows[1:]}
    for postal, recipe in (("merchant_postal_xcd", MERCHANT), ("cprsrvc__pisinfo_cardholder_postal_xcd", HOLDER)):
        r = by[f"geohash__{postal}"]
        assert r["recipe"] == recipe and r["proposed_alternative"] == f"{postal} (raw)"


ENRICHED_CODES = [("94108", "840"), ("941081234", "840"), (None, "840"), ("K1A 0B1", "124"), ("99999", "840"),
                  ("10001", None)]


def enriched_world(tmp_path, monkeypatch, table, extra=()):
    """The data lane's small raw world with merchant postal and country codes added, a confirmed map with one
    geohash field, its check results, and SETTINGS.yaml naming ``table``. Returns the raw files and the arguments."""
    import new_fields_data_world as W
    monkeypatch.setenv("NF_OUT", str(tmp_path / "c2"))
    monkeypatch.setenv("NF_SETTINGS_DIR", str(write_settings(tmp_path / "settings", table)))
    raw = W.raw_world(tmp_path / "raw")
    for files in (raw["train"], raw["eval"]):
        for path in files.values():
            df = pd.read_parquet(path)
            pick = [ENRICHED_CODES[i % len(ENRICHED_CODES)] for i in range(len(df))]
            df["merchant_postal_xcd"] = pd.Series([p for p, _ in pick], dtype=object)
            df["merchant_country_xcd"] = pd.Series([c for _, c in pick], dtype=object)
            df.to_parquet(path, index=False)
    mp = W.field_map(tmp_path / "FIELD_MAP.csv", fields=[
        ("geohash__merchant_postal_xcd", "v22b", "engineered", MERCHANT, "merchant_postal_xcd;merchant_country_xcd",
         "categorical")])
    st = W.field_status(tmp_path / "c2" / "checks" / "field_status.csv", mp)
    args = ["--map", str(mp), "--status", str(st), "--out", str(tmp_path / "enr"),
            "--train-base", str(tmp_path / "raw" / "tfm_raw_data"),
            "--eval-base", str(tmp_path / "raw" / "tfm_EVAL_raw_data"),
            "--range", "train=1-3", "--range", "test1=8000-8001", "--ranges", "train", "test1"] + list(extra)
    return raw, args


def copies(tmp_path):
    return sorted((tmp_path / "enr").rglob("*.parquet"))


def test_the_enriched_build_refuses_an_unreadable_table_before_the_first_file(tmp_path, monkeypatch, capsys):
    E = load("nf_build_enriched")
    _, args = enriched_world(tmp_path, monkeypatch, tmp_path / "missing.csv")
    assert E.main(args) == C.REFUSED
    err = capsys.readouterr().err
    assert "refused: geohash__merchant_postal_xcd: the geohash table " in err and "cannot be read" in err
    assert not copies(tmp_path) and not (tmp_path / "c2" / "enriched").exists()   # no copy, no proof


def test_the_enriched_build_reads_an_s3_table_once_with_the_data_credentials(tmp_path, monkeypatch):
    E = load("nf_build_enriched")
    import nf_data_io as dio
    reads = []

    class S3TableStore(dio.Store):   # local files as they are; the table on S3 from memory (no network)
        def read_bytes(self, path):
            if dio.is_s3(path):
                reads.append((self.cred_path, path))
                return TABLE_CSV.encode()
            return super().read_bytes(path)

    monkeypatch.setattr(dio, "Store", S3TableStore)
    raw, args = enriched_world(tmp_path, monkeypatch, S3_TABLE, extra=["--cred-path", "creds/pod_s3.yaml"])
    assert E.main(args) == 0
    assert reads == [("creds/pod_s3.yaml", S3_TABLE)]          # once, with the credentials given for the files
    sha = hashlib.sha256(TABLE_CSV.encode()).hexdigest()
    table = table_frame()
    for rng, sub, files in (("train", "tfm_raw_data", raw["train"]), ("test1", "tfm_EVAL_raw_data", raw["eval"])):
        for n, src in files.items():
            orig = pd.read_parquet(src)
            got = list(pd.read_parquet(tmp_path / "enr" / sub / f"part_{n}.parquet")["geohash__merchant_postal_xcd"])
            pre = tfm_tabular(orig, "merchant_postal_xcd", "merchant_country_xcd", table)
            want = tfm_tokens(orig, "merchant_postal_xcd", "merchant_country_xcd", table, pre)
            assert [None if v is None or v != v else v for v in got] == want
            proof = C.read_json(tmp_path / "c2" / "enriched" / "identity" / rng / f"part_{n}.json")
            col = proof["new_columns"]["geohash__merchant_postal_xcd"]
            assert proof["result"] == "PASS" and proof["geohash_table_sha256"] == sha
            assert col["geohash_table"] == S3_TABLE and col["geohash_table_sha256"] == sha
    assert set(want) >= {"9q8", "9q9", None, "f24", "OTHER"}


def test_the_enriched_build_uses_the_table_it_read_for_every_file(tmp_path, monkeypatch):
    E = load("nf_build_enriched")
    table = tmp_path / "geohash_mapping_table.csv"
    table.write_text(TABLE_CSV)
    _, args = enriched_world(tmp_path, monkeypatch, table)
    build_one = E.build_one

    def build_one_after_removing_the_table(*a, **k):
        if table.exists():
            table.unlink()                        # read once by main(); a later read would be refused
        return build_one(*a, **k)

    monkeypatch.setattr(E, "build_one", build_one_after_removing_the_table)
    assert E.main(args) == 0 and not table.exists()
    assert len(copies(tmp_path)) == 5


def test_a_resumed_enriched_build_never_keeps_a_copy_made_with_another_table():
    E = load("nf_build_enriched")
    old = {"result": "PASS", "map_sha256": "m", "status_sha256": "s", "recipes_sha256": "r",
           "geohash_table_sha256": "a" * 64}
    assert E.kept_copy_ok(None, old, "dst", dict(old, geohash_table_sha256="b" * 64), None, []) is False
    assert E.kept_copy_ok(None, old, "dst", dict(old, geohash_table_sha256=None), None, []) is False
