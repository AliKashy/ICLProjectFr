"""Synthetic world for the GPU lane's tests (width timing and the downstream check). CPU only, no bank data, no
network. It writes small parquet files, a predictor list, artifact version 1 fitted on the training files, the
chosen model's config at smoke sizes, and a settings folder for the new-fields tools."""
import os
import shutil
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[4]
NF = ROOT / "fraud" / "experiments" / "features" / "new_fields"
for _p in (str(NF), str(ROOT / "src"), str(ROOT)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

ID, ACCOUNT, TIME, LABEL = "fi_transaction_id", "Nmap_account_reference_xid", "transaction_dttm", "frd_tag"
CONTINUOUS, CATEGORICAL = ["f1", "f2"], ["c1", "c2"]
DATETIME_FIELDS = ["month", "day", "hour", "day_of_week"]
BASE_CONFIGS = ("fraud/configs/sequential_hier_allpos.yaml", "waqas/phase4b/configs/sequential_hier_allposition.yaml")

SMOKE = {  # the chosen model's settings at smoke sizes
    "sequence.history_len": 20, "sequence.attention_mask": "causal", "sequence.predict_every_transaction": True,
    "sequence.all_position_layout": "nonoverlapping_chunks", "sequence.time_delta": True,
    "sequence.time_delta_reference": "previous_transaction", "sequence.history_time_order": "strict",
    "sequence.max_window_rows": 32, "sequence.max_chunk_rows": 96,
    "model.input_embed_dim": 48, "model.num_heads": 8, "model.num_txn_blocks": 2, "model.num_seq_blocks": 4,
    "model.attn_dropout": 0.1, "model.ff_dropout": 0.1, "model.continuous_embedding": "linear",
    "training.learning_rate": 3e-4, "training.weight_decay": 1e-5, "training.pos_weight": 1.0,
    "training.optimizer": "adamw", "training.monitor": "valid_ap", "training.monitor_mode": "max",
    "training.early_stopping_patience": 5, "training.ema": False, "training.deterministic": False,
    "training.seed": 42, "training.precision": "bf16-mixed", "training.max_epochs": 2, "training.batch_size": 8,
    "training.eval_batch_size": 16, "training.buffer_windows": 64, "training.accumulate_grad_batches": 1,
    "training.num_workers": 0, "training.accelerator": "cpu", "training.log_every_n_steps": 1,
}


def base_config_path():
    for rel in BASE_CONFIGS:
        if (ROOT / rel).is_file():
            return ROOT / rel
    return None


def frame(tag, seed, start, accounts=4, rows=(35, 60), fraud=0.12):
    rng = np.random.default_rng(seed)
    out = []
    for a in range(accounts):
        t = pd.Timestamp(start) + pd.Timedelta(hours=float(rng.integers(0, 48)))
        for k in range(int(rng.integers(*rows))):
            t = t + pd.Timedelta(seconds=float(rng.choice([0, 1, 2, 7, 60, 600, 3600, 20000])))
            out.append({TIME: t, ACCOUNT: f"{tag}a{a}", ID: f"{tag}a{a}r{k:03}"})
    df = pd.DataFrame(out).sort_values([ACCOUNT, TIME, ID], kind="stable").reset_index(drop=True)
    n = len(df)
    y = rng.random(n) < fraud
    y[:2] = [True, False]
    df[LABEL] = y.astype(int)
    df["f1"] = rng.normal(size=n) + 2.0 * y
    df["f2"] = rng.normal(size=n)
    df.loc[rng.random(n) < 0.05, "f2"] = np.nan
    df["c1"], df["c2"] = rng.choice(["A", "B", "C"], size=n), rng.choice(["X", "Y"], size=n)
    df["transaction_amt"] = np.abs(rng.normal(50, 20, size=n))
    return df


def predictor_lines(description="x"):
    lines = ["feature,type,source,version,description"]
    lines += [f"{c},continuous,raw,1,{c} {description}" for c in CONTINUOUS]
    lines += [f"{c},categorical,raw,1,{c} {description}" for c in CATEGORICAL]
    lines += [f"{f},categorical,derived:{TIME},1,{f} {description}" for f in DATETIME_FIELDS]
    return "\n".join(lines) + "\n"


def build(tmp, settings_overrides=None):
    """The world under tmp. Returns a dict of paths; sets NF_OUT and NF_SETTINGS_DIR in os.environ."""
    from omegaconf import OmegaConf
    from fraud.data.datetime_features import DatetimeConfig, derive_datetime_features
    from fraud.data.feature_list import load_feature_list
    from fraud.data.preprocessing import PreprocessingArtifacts

    tmp = Path(tmp)
    data = tmp / "data"
    data.mkdir(parents=True)
    frames = {1: frame("t1", 1, "2024-10-05"), 2: frame("t2", 2, "2024-11-05"), 3: frame("v3", 3, "2025-01-05"),
              4001: frame("d1", 11, "2024-12-01", accounts=6), 4002: frame("d2", 12, "2025-01-10", accounts=6),
              8217: frame("s1", 21, "2025-05-30", accounts=6), 8218: frame("s2", 22, "2025-06-02", accounts=6)}
    predictors = tmp / "predictors.csv"
    predictors.write_text(predictor_lines(), encoding="utf-8")
    own_predictors = tmp / "predictors_step.csv"  # same fields, other bytes: a step's own list
    own_predictors.write_text(predictor_lines("step"), encoding="utf-8")
    features = load_feature_list(str(predictors), version=1)
    dt = DatetimeConfig(order_col=TIME, fields=DATETIME_FIELDS, encoding="categorical", is_weekend=False)
    derived, _, _ = derive_datetime_features(pd.concat([frames[1], frames[2]]), dt)
    artifacts = PreprocessingArtifacts(artifact_version=1, predictor_version=1)
    for c in features.continuous:
        artifacts.fit_feature(c, derived[c], "continuous")
    for c in features.categorical:
        artifacts.fit_feature(c, derived[c], "categorical")
    artifacts.save(str(tmp / "artifacts" / "1"))
    for i, f in frames.items():
        f.to_parquet(data / f"part_{i}.parquet", index=False)

    base = base_config_path()
    cfg = OmegaConf.load(str(base))
    cfg.s3.cred_path = None
    cfg.predictors.csv_path, cfg.predictors.version = str(predictors), 1
    cfg.artifacts.base, cfg.artifacts.version = str(tmp / "artifacts"), 1
    cfg.data.train_base = cfg.data.val_base = str(data)
    cfg.data.train_start, cfg.data.train_end, cfg.data.val_start, cfg.data.val_end = 1, 2, 3, 3
    cfg.eval.base, cfg.eval.file_start, cfg.eval.file_end = str(data), 3, 3
    cfg.output.checkpoint_dir = str(tmp / "unused")
    for key, value in SMOKE.items():
        OmegaConf.update(cfg, key, value)
    config = tmp / "chosen.yaml"
    OmegaConf.save(cfg, config)
    step_cfg = cfg.copy()
    step_cfg.predictors.csv_path = str(own_predictors)
    step_config = tmp / "step.yaml"
    OmegaConf.save(step_cfg, step_config)

    sdir = tmp / "settings"
    sdir.mkdir()
    for name in ("SETTINGS.yaml", "STEPS.yaml", "UPSTREAM.yaml", "CHECK_THRESHOLDS.yaml", "STATUS_RULES.csv"):
        if (NF / name).is_file():
            shutil.copy(NF / name, sdir / name)
    import yaml
    s = yaml.safe_load((sdir / "SETTINGS.yaml").read_text(encoding="utf-8")) if (sdir / "SETTINGS.yaml").is_file() else {}
    s.setdefault("populations", {})
    s["populations"]["ds_train"] = {"files": [4001, 4002]}
    s["populations"]["ds_select"] = {"files": [8217, 8218]}
    s["bootstrap"] = {"draws": 200, "seed": 20261102, "unit": ACCOUNT, "interval": 90}
    s["downstream"] = {"raw_predictors": str(predictors), "use2_15298_offset": "off"}
    s.setdefault("stage1", {})["timing"] = ""
    for k, v in (settings_overrides or {}).items():
        s[k] = v
    text = yaml.safe_dump(s, sort_keys=False)
    text = "\n".join(("microbatch: {}   # per run, written by the timing step" if ln.startswith("microbatch:") else ln)
                     for ln in text.splitlines()) + "\n"
    if "microbatch:" not in text:
        text += "microbatch: {}   # per run, written by the timing step\n"
    (sdir / "SETTINGS.yaml").write_text(text, encoding="utf-8")
    c2 = tmp / "c2"
    os.environ["NF_OUT"] = str(c2)
    os.environ["NF_SETTINGS_DIR"] = str(sdir)
    return {"tmp": tmp, "data": data, "frames": frames, "predictors": predictors, "own_predictors": own_predictors,
            "config": config, "step_config": step_config, "settings": sdir, "c2": c2}


def hashed_files():
    """SHA-256 of every .py file under fraud/ and waqas/ outside fraud/experiments/ (the base's hash covers
    fraud/experiments too; we compare the files that exist in both layouts' scope) and the two top files."""
    import hashlib
    out = {}
    for top in ("fraud", "waqas"):
        for p in sorted((ROOT / top).rglob("*.py")) if (ROOT / top).is_dir() else []:
            rel = p.relative_to(ROOT).as_posix()
            if "__pycache__" in rel or rel.startswith("fraud/experiments/"):
                continue
            out[rel] = hashlib.sha256(p.read_bytes()).hexdigest()
    for name in ("pyproject.toml", "requirements.txt"):
        if (ROOT / name).is_file():
            out[name] = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
    return out
