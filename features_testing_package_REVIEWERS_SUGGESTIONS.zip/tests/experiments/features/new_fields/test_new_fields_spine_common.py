"""Shared helpers: exit codes, paths, hashes, JSON, config flatten and diff, the busy check, the one-screen printer
and the field map reader."""
import json
import os
import stat
import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[4]
NF = ROOT / "fraud" / "experiments" / "features" / "new_fields"
sys.path.insert(0, str(NF))
import nf_common as C  # noqa: E402


def test_exit_codes_and_paths(tmp_path, monkeypatch):
    assert (C.OK, C.CRASH, C.ARGS, C.STOP, C.REFUSED, C.PARTIAL) == (0, 1, 2, 3, 4, 5)
    assert C.NF == NF and C.ROOT == ROOT
    assert C.FS == ROOT / "fraud" / "experiments" / "features" / "field_screen"
    assert C.C2 == ROOT / "checkpoints" / "new_fields" or os.environ.get("NF_OUT")
    monkeypatch.setenv("NF_OUT", str(tmp_path / "c2"))
    p = C.out("checks", "x", "a.json")
    assert p == tmp_path / "c2" / "checks" / "x" / "a.json" and p.parent.is_dir()


def test_hashes_and_json(tmp_path):
    f = tmp_path / "a.bin"
    f.write_bytes(b"abc")
    assert C.sha256_file(f) == C.sha256_bytes(b"abc") == \
        "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
    j = C.write_json(tmp_path / "d" / "x.json", {"b": 1, "a": [1, 2]})
    assert C.read_json(j) == {"a": [1, 2], "b": 1}
    assert not [p for p in j.parent.iterdir() if p.name.endswith(".tmp")]
    C.append_jsonl(tmp_path / "l.jsonl", {"x": 1})
    C.append_jsonl(tmp_path / "l.jsonl", {"x": 2})
    assert [json.loads(x)["x"] for x in (tmp_path / "l.jsonl").read_text().splitlines()] == [1, 2]


def test_settings_files_load_and_hash():
    s = C.settings()
    assert s["main_measure"] == "udr_at_0.6pct"
    st = C.steps()
    assert [x["name"] for x in st["steps"]][:2] == ["A1", "A2"]
    assert isinstance(C.thresholds(), dict)
    h = C.settings_hashes()
    assert set(h) == set(C.SETTINGS_FILES)
    assert all(v and len(v) == 64 for v in h.values())


def test_flatten_and_diff():
    a = {"training": {"learning_rate": 3e-4, "seed": 42}, "data": {"files": [1, 2]}, "x": {}}
    b = {"training": {"learning_rate": 1e-3, "seed": 42}, "data": {"files": [1, 2]}, "y": 1}
    fa = C.flatten(a)
    assert fa["training.learning_rate"] == 3e-4 and fa["data.files"] == [1, 2] and fa["x"] == {}
    d = C.diff_configs(a, b)
    assert d == [("training.learning_rate", 3e-4, 1e-3), ("x", {}, C.ABSENT), ("y", C.ABSENT, 1)]
    from omegaconf import OmegaConf
    assert C.flatten(OmegaConf.create(a)) == fa


def test_screen_limits():
    lines = [f"line {i} " + "x" * 200 for i in range(100)]
    text = C.screen("TITLE", lines, footer="full table: somewhere")
    rows = text.splitlines()
    assert len(rows) == 40
    assert all(len(r) <= 90 for r in rows)
    assert rows[0] == "TITLE" and rows[-1] == "full table: somewhere"
    assert rows[-2] == "... 63 more lines"
    short = C.screen("T", ["a", "b"])
    assert short == "T\na\nb"
    exact = C.screen("T", [str(i) for i in range(39)])
    assert len(exact.splitlines()) == 40 and "more lines" not in exact


# ---------------------------------------------------------------- busy check

def _fake_proc(root, procs):
    """procs: {pid: (ppid, argv)}"""
    for pid, (ppid, argv) in procs.items():
        d = root / str(pid)
        d.mkdir(parents=True)
        (d / "cmdline").write_bytes(b"\0".join(a.encode() for a in argv) + b"\0")
        (d / "stat").write_text(f"{pid} (x y) S {ppid} 0 0\n")
    return root


def _fake_smi(tmp_path, apps="", used="0"):
    p = tmp_path / "nvidia-smi"
    p.write_text("#!/bin/sh\ncase \"$1\" in\n"
                 f"  --query-compute-apps*) printf '%s' '{apps}';;\n"
                 f"  --query-gpu*) echo '{used}';;\nesac\n")
    p.chmod(p.stat().st_mode | stat.S_IEXEC)
    return str(p)


@pytest.mark.parametrize("argv", [
    ["python", "-u", "-m", "fraud.scripts.train_sequential_hier", "--config", "a.yaml"],
    ["venv/bin/python3.10", "-m", "fraud.scripts.score_sequential_hier", "--out", "x"],
    ["python3", "waqas/v2/scripts/train_v2.py", "--config", "c.yaml"],
    ["python3.11", "-m", "waqas.v2.scripts.score_v2"],
    ["bash", "fraud/experiments/tuning/lr_screen.sh"],
    ["bash", "fraud/experiments/reproduce/run_all.sh"],
    ["bin/bash", "fraud/experiments/features/new_fields/nf_run_all.sh"],
    ["python", "fraud/experiments/features/new_fields/nf_importance.py", "run"],
    ["python", "width_timing.py", "--widths", "30"],
    ["python", "-W", "ignore", "-m", "fraud.scripts.train_sequential_hier"],
    ["python", "-X", "faulthandler", "-m", "fraud.scripts.score_sequential_hier", "--out", "x"],
])
def test_busy_matches(tmp_path, argv):
    proc = _fake_proc(tmp_path / "proc", {100: (1, ["sh"]), 200: (1, argv)})
    found = C.busy(proc_root=proc, nvidia_smi=_fake_smi(tmp_path), lock_roots=[], my_pid=100)
    assert len(found) == 1 and "process 200" in found[0]


@pytest.mark.parametrize("argv", [
    ["python", "-m", "pytest", "tests/test_train_v2.py"],
    ["bash", "-c", "grep train_v2 log.txt"],
    ["vim", "fraud/scripts/train_sequential_hier.py"],
    ["python", "fraud/experiments/features/new_fields/nf_report.py"],
    ["less", "waqas/v2/scripts/score_v2.py"],
])
def test_busy_ignores(tmp_path, argv):
    proc = _fake_proc(tmp_path / "proc", {100: (1, ["sh"]), 200: (1, argv)})
    assert C.busy(proc_root=proc, nvidia_smi=_fake_smi(tmp_path), lock_roots=[], my_pid=100) == []


def test_busy_never_matches_itself_parents_or_children(tmp_path):
    q = ["bash", "fraud/experiments/features/new_fields/nf_run_all.sh"]
    me = ["python", "fraud/experiments/features/new_fields/nf_importance.py", "run"]
    child = ["python", "-m", "fraud.scripts.score_sequential_hier"]
    proc = _fake_proc(tmp_path / "proc", {10: (1, q), 20: (10, me), 30: (20, child), 40: (30, child)})
    assert C.busy(proc_root=proc, nvidia_smi=_fake_smi(tmp_path), lock_roots=[], my_pid=20) == []
    # another queue's trainer is found
    proc2 = _fake_proc(tmp_path / "proc2", {10: (1, q), 20: (10, me), 50: (1, child)})
    assert len(C.busy(proc_root=proc2, nvidia_smi=_fake_smi(tmp_path), lock_roots=[], my_pid=20)) == 1


def test_busy_gpu(tmp_path):
    proc = _fake_proc(tmp_path / "proc", {100: (1, ["sh"])})
    found = C.busy(proc_root=proc, nvidia_smi=_fake_smi(tmp_path, apps="4242, python, 30000"),
                   lock_roots=[], my_pid=100)
    assert any("gpu compute process: 4242" in f for f in found)
    found = C.busy(proc_root=proc, nvidia_smi=_fake_smi(tmp_path, used="2048"), lock_roots=[], my_pid=100)
    assert any("2048 MiB" in f for f in found)
    assert C.busy(proc_root=proc, nvidia_smi=_fake_smi(tmp_path, used="500"), lock_roots=[], my_pid=100) == []
    assert C.busy(proc_root=proc, nvidia_smi=str(tmp_path / "absent"), lock_roots=[], my_pid=100) == []


def test_busy_locks(tmp_path):
    import socket
    proc = _fake_proc(tmp_path / "proc", {100: (1, ["sh"])})
    runs = tmp_path / "runs" / "tuning" / "r1"
    runs.mkdir(parents=True)
    C.write_json(runs / "RUNNING.lock.json", {"pid": os.getpid(), "hostname": socket.gethostname(), "utc": "t"})
    found = C.busy(proc_root=proc, nvidia_smi=_fake_smi(tmp_path), lock_roots=[tmp_path / "runs"], my_pid=100)
    assert len(found) == 1 and "RUNNING.lock.json" in found[0]
    C.write_json(runs / "RUNNING.lock.json", {"pid": 999999999, "hostname": socket.gethostname(), "utc": "t"})
    assert C.busy(proc_root=proc, nvidia_smi=_fake_smi(tmp_path), lock_roots=[tmp_path / "runs"], my_pid=100) == []
    q = tmp_path / "c2"
    q.mkdir()
    C.write_json(q / "QUEUE.lock.json", {"pid": os.getpid(), "hostname": socket.gethostname(), "utc": "t"})
    found = C.busy(proc_root=proc, nvidia_smi=_fake_smi(tmp_path), lock_roots=[q], my_pid=100)
    assert len(found) == 1 and "QUEUE.lock.json" in found[0]


def test_busy_real_proc_does_not_match_self(monkeypatch):
    monkeypatch.delenv("NF_PROC_ROOT", raising=False)      # the real table, whatever the caller's environment
    found = C.busy(nvidia_smi="/nonexistent/nvidia-smi", lock_roots=[])
    assert not [f for f in found if f"process {os.getpid()}:" in f]


# ---------------------------------------------------------------- field map

def _map(tmp_path, cols, rows=1):
    df = pd.DataFrame({c: ["x"] * rows for c in cols})
    p = tmp_path / "map.csv"
    df.to_csv(p, index=False)
    return p


def test_field_map_columns_and_allowed():
    assert C.FIELD_MAP_COLUMNS[:5] == ["name", "group", "kind", "recipe", "source_columns"]
    assert len(C.FIELD_MAP_COLUMNS) == len(set(C.FIELD_MAP_COLUMNS))
    for k in ("group", "kind", "model_type", "check_result", "status_rule", "list_status"):
        assert C.ALLOWED[k]
    for k in C.YES_NO_COLUMNS:
        assert k in C.ALLOWED
    assert set(C.ALLOWED["group"]) == {"v22b", "f15298", "both", "a3"}


def test_read_field_map_strings_and_blanks(tmp_path):
    p = tmp_path / "m.csv"
    p.write_text(",".join(C.FIELD_MAP_COLUMNS) + ",extra\n" + ",".join(["7"] + [""] * (len(C.FIELD_MAP_COLUMNS) - 1))
                 + ",e\n")
    df = C.read_field_map(p)
    assert list(df.columns) == C.FIELD_MAP_COLUMNS + ["extra"]
    assert df.loc[0, "name"] == "7" and df.loc[0, "group"] == "" and df.loc[0, "extra"] == "e"
    assert df.attrs["added_columns"] == []


def test_read_field_map_refuses_missing_core(tmp_path):
    p = _map(tmp_path, [c for c in C.FIELD_MAP_CORE if c != "recipe"])
    with pytest.raises(SystemExit) as e:
        C.read_field_map(p)
    assert e.value.code == 4 and "recipe" in e.value.message


def test_read_field_map_adds_review_columns(tmp_path):
    p = _map(tmp_path, C.FIELD_MAP_CORE)
    df = C.read_field_map(p)
    assert list(df.columns) == C.FIELD_MAP_COLUMNS
    assert df.attrs["added_columns"] == C.FIELD_MAP_REVIEW
    assert (df["date_meaning"] == "").all()


def test_template_map_reads():
    df = C.read_field_map(NF / "FIELD_MAP.csv")
    assert list(df.columns)[:len(C.FIELD_MAP_COLUMNS)] == C.FIELD_MAP_COLUMNS


def test_approvals():
    assert C.blank_approvals({"a": {"approved_by": "x", "approved_on": "2026-11-02"}, "b": {"approved_by": ""}},
                             ["a", "b", "c"]) == ["b", "c"]
