"""The designated RANK-A range reaches the scorer and its exposure records."""
import json
from pathlib import Path
import sys

import pytest
from omegaconf import OmegaConf

NF = Path(__file__).resolve().parents[4] / "fraud/experiments/features/new_fields"
sys.path.insert(0, str(NF))


def settings(start=8201, end=8205):
    return {"importance": {"population": "rank_a"}, "populations": {
        "rank_a": {"files": [start, end], "targets": ["2025-06-01", "2025-07-01"]},
        "rank_b": {"files": [8244, 8259]}, "test1": {"files": [8000, 8010]}}}


def test_configured_fallback_range_scores_real_files_and_records_them(tmp_path, monkeypatch):
    from test_new_fields_importance_world import synthetic_world
    import nf_common
    import nf_importance as I
    cfg, checkpoint, raw, _ = synthetic_world(tmp_path, accounts=64, files=5)
    for i in range(5):
        (tmp_path / "data" / f"part_{8228 + i}.parquet").rename(
            tmp_path / "data" / f"part_{8201 + i}.parquet")
    config = tmp_path / "config.yaml"
    OmegaConf.save(cfg, config)
    original = config.read_bytes()
    monkeypatch.setattr(nf_common, "settings", settings)
    monkeypatch.setattr(nf_common, "C2", tmp_path / "records")
    monkeypatch.setattr(nf_common, "busy", lambda: [])
    out = tmp_path / "importance"
    assert I.main(["run", "--config", str(config), "--checkpoint", str(checkpoint),
        "--output", str(out), "--attention-only", "--account-share", "1",
        "--draws", "2", "--seconds-per-row", "0.001", "--rank-a-rows", str(len(raw))]) == 0
    assert config.read_bytes() == original
    saved = OmegaConf.load(out / "scoring_config.yaml")
    assert (saved.eval.file_start, saved.eval.file_end) == (8201, 8205)
    for name, end, files in [("null_plain", 8201, 1), ("null_identity", 8201, 1),
                             ("baseline", 8205, 5)]:
        receipt = json.loads((out / f"{name}.exposure.json").read_text())
        assert receipt["population"] == "RANK-A" and receipt["status"] == "completed"
        assert receipt["files"]["start"] == 8201 and receipt["files"]["end"] == end
        assert receipt["coverage"]["files"] == files
    assert (out / "completed.json").exists()


def test_enforcement_uses_designated_population_not_an_arbitrary_scoring_range():
    from nf_importance import enforce_rank_a
    cfg = OmegaConf.create({"eval": {"file_start": 8201, "file_end": 8205}})
    enforce_rank_a(cfg, settings())
    cfg.eval.file_start, cfg.eval.file_end = 8244, 8259
    with pytest.raises(ValueError, match="RANK-A"):
        enforce_rank_a(cfg, settings())


@pytest.mark.parametrize("change", ["population", "targets", "reversed"])
def test_settings_cannot_silently_select_another_population_or_target_period(change):
    from nf_importance import enforce_rank_a
    declared = settings()
    if change == "population":
        declared["importance"]["population"] = "test1"
    elif change == "targets":
        declared["populations"]["rank_a"]["targets"] = ["2025-05-01", "2025-06-01"]
    else:
        declared["populations"]["rank_a"]["files"] = [8205, 8201]
    cfg = OmegaConf.create({"eval": {"file_start": 8201, "file_end": 8205}})
    with pytest.raises(ValueError, match="RANK-A|June"):
        enforce_rank_a(cfg, declared)
