"""The optional calendar artifact must pass the real checker and retain its scratch provenance."""

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_new_fields_data_artifact as D  # noqa: E402

lab = D.lab


def _build_calendar(lab, choice):
    assert D.B.main(lab.args + ["--calendar-cyclical", choice]) == 0
    rec = json.loads((lab.c2 / "artifact" / "artifact_hashes.json").read_text())
    checkpoints = [D.fake_ckpt(lab.tmp / "m" / f"seed{s}" / "best.ckpt",
                               rec["payload_sha256"]["base"]) for s in (42, 43, 44)]
    return rec, D.check_args(lab, checkpoints)


def _result(lab):
    return json.loads((lab.c2 / "artifact" / "artifact_check.json").read_text())


@pytest.mark.parametrize("choice", ["cyclical", "cyclical_weekend"])
def test_calendar_build_passes_the_required_artifact_check(lab, choice):
    rec, args = _build_calendar(lab, choice)
    assert D.K.main(args) == 0
    result = _result(lab)
    assert result["result"] == "PASS"
    for key in ("calendar_equal_scratch", "manifest", "no_extra_files", "base_identical", "digest_v1", "encode",
                "month_switch"):
        assert result["lines"][key]["result"] == "PASS", result["lines"][key]
    calendar = set(rec["calendar_cyclical"]["fields"])
    assert ("is_weekend" in calendar) == (choice == "cyclical_weekend")
    assert calendar.isdisjoint(rec["new_fields"])
    for names in rec["input_sets"].values():
        assert calendar.isdisjoint(names)
    month_in = (lab.c2 / "artifact" / "predictors_all_month_in.csv").read_bytes()
    assert month_in.startswith(lab.pred.read_bytes())
    assert "month" in D.A.list_features(month_in)


@pytest.mark.parametrize("version", ["nf_ext1", "nf_scratch1_calendar"])
def test_calendar_check_rejects_changed_calendar_payload_bytes(lab, version):
    _, args = _build_calendar(lab, "cyclical_weekend")
    assert D.K.main(args) == 0
    payload = lab.art / version / "feature__month_sin.json"
    payload.write_bytes(payload.read_bytes() + b" ")  # valid JSON, same values, different bytes
    assert D.K.main(args) == 3
    result = _result(lab)
    failed = {key for key, line in result["lines"].items() if line["result"] == "FAIL"}
    assert failed == {"calendar_equal_scratch"}
