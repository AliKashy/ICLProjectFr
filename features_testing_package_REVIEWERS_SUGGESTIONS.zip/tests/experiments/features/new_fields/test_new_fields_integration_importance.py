"""The importance lane wired to the data lane's engine and the reader's metrics (integration decisions 1 (d), 6, 12
and the final notes): the checks lane's clusters.csv, one dependency rule, families keyed on another key, and the
run-time agreement with nf_ranked."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[4] / "fraud/experiments/features/new_fields"))
import nf_importance as NI  # noqa: E402
import nf_recipes  # noqa: E402
from nf_importance_units import build_units, make_recompute, non_account_keys  # noqa: E402
from nf_permutation import select_accounts  # noqa: E402

ACC, TIME, TIE = "Nmap_account_reference_xid", "transaction_dttm", "fi_transaction_id"


def test_the_checks_lane_clusters_csv_gives_cluster_units():
    clusters = pd.DataFrame([{"cluster_id": "C001", "member": "a", "member_kind": "new", "size": 2},
                             {"cluster_id": "C001", "member": "b", "member_kind": "new", "size": 2},
                             {"cluster_id": "C002", "member": "c", "member_kind": "base", "size": 1}])
    units = build_units(["a", "b", "c"], clusters=clusters, units="clusters")
    assert [(u.name, list(u.members), u.kind) for u in units] == [("cluster:C001", ["a", "b"], "cluster")]


def _keyed_map():
    return pd.DataFrame([
        dict(name="transaction_amt", recipe="raw", source_columns="transaction_amt", model_type="continuous"),
        dict(name="cust_sum_7d", recipe="sum(7d; value=transaction_amt; key=customer_xid)",
             source_columns="transaction_amt;customer_xid", model_type="continuous"),
        dict(name="acct_sum_7d", recipe="sum(7d; value=transaction_amt)", source_columns="transaction_amt",
             model_type="continuous"),
    ])


def _frame(n=80, seed=3):
    rng = np.random.default_rng(seed)
    acct = rng.choice(["a1", "a2", "a3", "a4"], n)
    cust = np.where(np.isin(acct, ["a1", "a2"]), "c1", "c2")       # two accounts per customer
    t = pd.Timestamp("2025-06-01") + pd.to_timedelta(np.sort(rng.integers(0, 10 * 86400, n)), unit="s")
    return pd.DataFrame({ACC: acct, "customer_xid": cust, TIME: t, TIE: np.arange(n).astype(str),
                         "transaction_amt": rng.gamma(2, 30, n).round(2), "frd_tag": 0})


def test_a_customer_keyed_family_needs_every_account_and_the_tool_takes_a_full_share():
    """Decision 12. The problem: a sample of whole accounts rebuilds a customer-keyed recipe from a partial
    customer history, so its value changes with no perturbation at all (the null check at a 100% share would not
    see it). The fix: such families make the run take every account."""
    fm = _keyed_map()
    full = nf_recipes.build_fields(_frame(), fm, extract_start="2025-05-01")
    frame = _frame()
    salt = next(f"feature-importance-accounts:{k}" for k in range(1000)
                if (lambda kept: kept & {"a1", "a2"} and not {"a1", "a2"} <= kept)(
                    set(select_accounts(frame, 0.5, ACC, salt=f"feature-importance-accounts:{k}")[ACC])))
    part = select_accounts(frame, 0.5, ACC, salt=salt)      # the tool's own whole-account sample
    rebuilt = nf_recipes.build_fields(part, fm, extract_start="2025-05-01")
    joined = rebuilt.merge(full[[TIE, "cust_sum_7d", "acct_sum_7d"]], on=TIE, suffixes=("", "_full"))
    assert np.allclose(joined["acct_sum_7d"], joined["acct_sum_7d_full"], equal_nan=True)     # account: fine
    assert not np.allclose(joined["cust_sum_7d"], joined["cust_sum_7d_full"], equal_nan=True)  # customer: wrong
    units = build_units(["transaction_amt", "cust_sum_7d", "acct_sum_7d"], field_map=fm, unit_specs=[
        dict(name="family:transaction_amt", method="family", source_columns="transaction_amt")])
    keyed = non_account_keys(fm, units)
    assert keyed == {"family:transaction_amt": ["customer_xid"]}
    acct_only = fm[fm.name != "cust_sum_7d"]
    units2 = build_units(["transaction_amt", "acct_sum_7d"], field_map=acct_only, unit_specs=[
        dict(name="family:transaction_amt", method="family", source_columns="transaction_amt")])
    assert non_account_keys(acct_only, units2) == {}
    assert NI.account_share_for(keyed, 0.25) == 1.0 and NI.account_share_for({}, 0.25) == 0.25


def test_one_dependency_rule_the_engine_and_the_map_must_agree():
    """The family rebuild uses nf_recipes.build_fields and its dependency_closure; a map whose source_columns
    disagree with the recipe is refused, never rebuilt silently with a stale output."""
    fm = _keyed_map()
    fam = [u for u in build_units(["transaction_amt", "cust_sum_7d", "acct_sum_7d"], field_map=fm, unit_specs=[
        dict(name="family:transaction_amt", method="family", source_columns="transaction_amt")])
        if u.method == "family"][0]
    scored = nf_recipes.build_fields(_frame(), fm, extract_start="2025-05-01")
    got = make_recompute(fm, ACC, TIME, "2025-05-01")(scored, fam)
    assert set(fam.dependent_outputs) == nf_recipes.dependency_closure(fm, ["transaction_amt"])["outputs"]
    assert np.allclose(got["acct_sum_7d"], scored["acct_sum_7d"], equal_nan=True)
    cb = make_recompute(fm, ACC, TIME, "2025-05-01")
    assert TIE in cb.required_columns(fam)      # the engine's own list: the tie id orders a second's rows
    wrong = fm.copy()
    wrong.loc[wrong.name == "acct_sum_7d", "source_columns"] = "other_col"   # the map forgets its real source
    fam_w = [u for u in build_units(["transaction_amt", "cust_sum_7d", "acct_sum_7d"], field_map=wrong,
                                    unit_specs=[dict(name="family:transaction_amt", method="family",
                                                     source_columns="transaction_amt")]) if u.method == "family"][0]
    with pytest.raises(ValueError, match="dependency_closure"):
        make_recompute(wrong, ACC, TIME, "2025-05-01")(scored, fam_w)


def test_importance_metrics_are_checked_against_the_reader_engine(monkeypatch):
    rng = np.random.default_rng(5)
    n = 600
    frame = pd.DataFrame({"account": [f"a{i % 97}" for i in range(n)], "id": [f"t{i}" for i in range(n)],
                          "label": (rng.random(n) < 0.08).astype(int), "amount": rng.gamma(2, 50, n),
                          "score": np.round(rng.random(n), 2).astype(np.float32)})
    rec = NI.engine_check(frame)
    assert rec["engine"].endswith("equal") and set(rec["metrics"]) == {"udr", "vdr", "fpr", "ap"}
    import nf_ranked
    real = nf_ranked.outsort

    def off(*a, **k):
        r = dict(real(*a, **k))
        r["udr"] = r["udr"] + 0.01
        return r
    monkeypatch.setattr(nf_ranked, "outsort", off)
    with pytest.raises(ValueError, match="differ from the reader's engine"):
        NI.engine_check(frame)


def test_donor_unit_defaults_from_the_kind_of_field():
    """Decision 7: a profile field (business category "account and customer profile") takes account donors when its
    donor_unit is blank; an event field takes event donors; a written value wins."""
    fm = pd.DataFrame([dict(name="opened", recipe="raw", business_category="account and customer profile"),
                       dict(name="amt", recipe="raw", business_category="amount and balance"),
                       dict(name="seg", recipe="raw", business_category="account and customer profile",
                            donor_unit="event")])
    units = {u.name: u.donor_unit for u in build_units(["opened", "amt", "seg"], field_map=fm, units="singles")}
    assert units == {"opened": "account", "amt": "event", "seg": "event"}
