"""Intake, field map and robustness after integration: one naming scheme (decision 2), one LE reading (3), one recipe
grammar (4), the donor_unit column (7), and clear refusals with exit 4 when a pod path or record is missing (13)."""
import os
import subprocess
import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[4]
NF = ROOT / "fraud" / "experiments" / "features" / "new_fields"
sys.path.insert(0, str(NF))
import nf_common as C  # noqa: E402
import nf_intake as I  # noqa: E402
import nf_recipes  # noqa: E402

ATTRS = NF / "DRAFT_FEATURE_ATTRIBUTES_UNCONFIRMED.csv"
LE_REASON = "original encoder unverified; raw code proposed as an alternative (reviewer feature review)"


def tool(name, *args, tmp, **env):
    e = dict(os.environ, NF_OUT=str(tmp / "c2"), CUDA_VISIBLE_DEVICES="", **{k: str(v) for k, v in env.items()})
    return subprocess.run([sys.executable, str(NF / name), *args], cwd=ROOT, capture_output=True, text=True, env=e,
                          timeout=300)


@pytest.fixture(scope="module")
def draft(tmp_path_factory):
    tmp = tmp_path_factory.mktemp("draft")
    r = tool("nf_intake.py", "draft", tmp=tmp)
    assert r.returncode == 0, r.stderr
    df = C.read_field_map(tmp / "c2" / "intake" / "FIELD_MAP_DRAFT_UNCONFIRMED.csv")
    _, res = I.check_map(df, pod=None)
    return df, {x["name"]: x for x in res}


def test_the_draft_is_the_attributes_file_one_row_per_name(draft):
    df, res = draft
    attrs = pd.read_csv(ATTRS, dtype=str, keep_default_na=False)
    keep = pd.read_csv(NF / "KEEP_DECISIONS.csv", dtype=str, keep_default_na=False)
    assert len(df) == len(attrs) == 287 and not df["name"].duplicated().any()
    assert set(df["name"]) == set(attrs["name"]) == set(keep["name"])      # adopt and the table join by name
    a = attrs.set_index("name")
    for _, r in df.iterrows():
        src = a.loc[r["name"]]
        if src["recipe"]:
            assert (r["recipe"], r["source_columns"]) == (src["recipe"], src["source_columns"]), r["name"]
    rules = [rr.split()[1].rstrip(":") for x in res.values() for rr in x["reasons"]]
    assert "raw_name" not in rules and "duplicate_name" not in rules
    assert all(x["result"] != "STOP" or not any("raw_name" in rr for rr in x["reasons"]) for x in res.values())


def test_le_outputs_carry_code_c_as_a_proposed_alternative_flag_not_stop(draft):
    df, res = draft
    attrs = pd.read_csv(ATTRS, dtype=str, keep_default_na=False).set_index("name")
    keep = pd.read_csv(NF / "KEEP_DECISIONS.csv", dtype=str, keep_default_na=False).set_index("name")
    le = [n for n in attrs.index if n.startswith("derived_le") and attrs.loc[n, "raw_alternative"]
          and not attrs.loc[n, "recipe"]]
    assert len(le) == 15
    m = df.set_index("name")
    for n in le:
        alt = attrs.loc[n, "raw_alternative"]
        assert m.loc[n, "recipe"] == f"code({alt})" and m.loc[n, "model_type"] == "categorical"
        assert m.loc[n, "mapping_status"] == "open" and m.loc[n, "equivalence"] == "unverified"
        assert any(rr.startswith("FLAG encoding_alternative") for rr in res[n]["reasons"])
        assert not any(rr.startswith("STOP") for rr in res[n]["reasons"]), res[n]["reasons"]
        assert keep.loc[n, "verdict"] == "unresolved" and LE_REASON in keep.loc[n, "reason"]


def test_one_grammar_the_intake_calls_nf_recipes_parse():
    attrs = pd.read_csv(ATTRS, dtype=str, keep_default_na=False)
    for text in sorted(set(attrs["recipe"]) - {""}) + ["count(24h; key=customer_xid)", "days_before(d; same_day=keep)",
                                                        "prev(x; within=all)", "raw(x)", "count(25h)"]:
        try:
            nf_recipes.parse(text)
            ok = True
        except nf_recipes.RecipeError:
            ok = False
        try:
            I.parse_recipe(text)
            mine = True
        except I.RecipeError:
            mine = False
        assert ok == mine, text
    p = I.parse_recipe("since_last(days; within=all)")
    assert p["lookback_seconds"] is None and p["within"] == "all"


def test_donor_unit_is_a_map_column_with_a_default_from_the_kind_of_field(draft):
    df, _ = draft
    assert C.FIELD_MAP_COLUMNS[-1] == "donor_unit" and C.ALLOWED["donor_unit"] == ["", "event", "account"]
    assert (NF / "FIELD_MAP.csv").read_text().splitlines()[0].split(",") == C.FIELD_MAP_COLUMNS
    prof = df[df["business_category"] == C.PROFILE_CATEGORY]
    assert len(prof) and set(prof["donor_unit"]) == {"account"}
    assert set(df.loc[df["business_category"] != C.PROFILE_CATEGORY, "donor_unit"]) == {"event"}
    assert C.default_donor_unit({"donor_unit": "event", "business_category": C.PROFILE_CATEGORY}) == "event"


# ------------------------------------------------------------------ decision 13: clear refusals, exit 4

def test_width_and_chunks_refuse_a_missing_config_or_open_values(tmp_path):
    for args in (["width", "--config", "nope.yaml"], ["chunks", "--config", "nope.yaml", "--batch", "8"]):
        r = tool("nf_time_width.py", *args, tmp=tmp_path)
        assert r.returncode == 4 and "refused:" in r.stderr and "Traceback" not in r.stderr
    c20 = ROOT / "waqas" / "v2" / "configs" / "c20.yaml"     # the chunk config, its micro-batch fields open
    if c20.is_file():
        r = tool("nf_time_width.py", "width", "--config", str(c20), tmp=tmp_path)
        assert r.returncode == 4 and "Traceback" not in r.stderr, r.stderr
    bad = tmp_path / "bad.yaml"
    bad.write_text("training: [\n")
    r = tool("nf_time_width.py", "width", "--config", str(bad), tmp=tmp_path)
    assert r.returncode == 4 and "cannot be read" in r.stderr and "Traceback" not in r.stderr, r.stderr


def test_drafts_builder_refuses_missing_records(tmp_path):
    r = tool("nf_workbook_drafts.py", "--records-root", str(tmp_path / "none"), "--out", str(tmp_path / "out"),
             tmp=tmp_path)
    assert r.returncode == 4 and "refused:" in r.stderr and "Traceback" not in r.stderr
    assert not (tmp_path / "out").exists()


def test_intake_schema_refuses_missing_data_folders(tmp_path):
    r = tool("nf_intake.py", "schema", "--train-base", str(tmp_path / "no_train"), "--val-base",
             str(tmp_path / "no_val"), "--eval-base", str(tmp_path / "no_eval"), "--cred-path", "", tmp=tmp_path)
    assert r.returncode == 4 and "refused:" in r.stderr and "Traceback" not in r.stderr
    assert not (tmp_path / "c2" / "intake" / "pod_columns.csv").exists()


def test_data_and_checks_tools_refuse_missing_pod_paths(tmp_path):
    """Decision 13 for the tools merged in part A: a missing config, field_status.csv or artifact record is a clear
    refusal with exit 4, never a traceback."""
    calls = [("nf_build_artifact.py", "--config", str(tmp_path / "no_config.yaml")),
             ("nf_build_enriched.py",), ("nf_check_artifact.py",), ("nf_feature_summary.py",)]
    for name, *args in calls:
        r = tool(name, *args, tmp=tmp_path)
        assert r.returncode == 4 and "refused" in (r.stderr + r.stdout) and "Traceback" not in r.stderr, \
            (name, r.returncode, r.stderr[-400:])
