"""Extended artifact and its check (design 4.2 to 4.5): base fields byte-identical to version 1 across the refit
and the month switch, per-file hashes, the checkpoint digest, refusals.

Version 1 is built with the unchanged builder on synthetic parquet. The builder always opens an S3 filesystem, so
the tests run its own main in this process with that one call answered by None (local files); its code is not
changed.
"""

import importlib.util
import json
import os
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest
import yaml

_W = Path(__file__).resolve().parent / "new_fields_data_world.py"
_spec = importlib.util.spec_from_file_location("new_fields_data_world", _W)
world = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(world)

import nf_build_artifact as B  # noqa: E402
import nf_build_enriched as E  # noqa: E402
import nf_check_artifact as K  # noqa: E402
import nf_data_artifact as A  # noqa: E402

BUILDER = world.ROOT / "fraud" / "scripts" / "build_preprocessing_artifacts.py"

BASE_PREDICTORS = (
    "feature,type,source,version,description\n"
    "transaction_amt,continuous,raw,1,amount\n"
    "total_available_balance_amt,continuous,raw,1,balance\n"
    "transaction_type_xcd,categorical,raw,1,type\n"
    "merchant_category_xcd,categorical,raw,1,mcc\n"
    "month,categorical,derived:transaction_dttm,1,month\n"
    "day,categorical,derived:transaction_dttm,1,day\n"
    "hour,categorical,derived:transaction_dttm,1,hour\n"
    "day_of_week,categorical,derived:transaction_dttm,1,weekday\n"
)


def builder_in_process(config_path):
    """The unchanged builder's main, by path, with make_s3_filesystem answering None for local files."""
    spec = importlib.util.spec_from_file_location("nf_test_builder", BUILDER)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.make_s3_filesystem = lambda *a, **k: None
    argv = sys.argv
    sys.argv = [str(BUILDER), "--config", str(config_path)]
    try:
        mod.main()
    finally:
        sys.argv = argv
    return 0


@pytest.fixture
def lab(tmp_path, monkeypatch):
    monkeypatch.setenv("NF_OUT", str(tmp_path / "c2"))
    monkeypatch.setattr(B, "run_builder", builder_in_process)
    raw = world.raw_world(tmp_path / "raw", train_files=(1, 2, 3))
    pred = tmp_path / "predictors.csv"
    pred.write_text(BASE_PREDICTORS)
    art = tmp_path / "art"
    cfg1 = tmp_path / "pre_v1.yaml"
    cfg1.write_text(yaml.safe_dump({
        "predictors": {"csv_path": str(pred), "version": None},
        "data": {"base": str(tmp_path / "raw" / "tfm_raw_data"), "file_start": 1, "file_end": 2,
                 "order_col": "transaction_dttm"},
        "datetime": {"fields": ["month", "day", "hour", "day_of_week"], "encoding": "categorical",
                     "is_weekend": False},
        "build": {"features_per_batch": 3, "artifact_version": 1, "output_base": str(art)},
        "s3": {"cred_path": None}}))
    builder_in_process(cfg1)
    chosen = tmp_path / "chosen.yaml"
    chosen.write_text(yaml.safe_dump({
        "artifacts": {"base": str(art), "version": 1},
        "data": {"train_base": str(tmp_path / "raw" / "tfm_raw_data")},
        "eval": {"base": str(tmp_path / "raw" / "tfm_EVAL_raw_data")}, "s3": {"cred_path": None}}))
    mp = world.field_map(tmp_path / "FIELD_MAP.csv")
    st = world.field_status(tmp_path / "c2" / "checks" / "field_status.csv", mp)
    enr = tmp_path / "enr"
    assert E.main(["--map", str(mp), "--status", str(st), "--out", str(enr),
                   "--train-base", str(tmp_path / "raw" / "tfm_raw_data"),
                   "--eval-base", str(tmp_path / "raw" / "tfm_EVAL_raw_data"),
                   "--range", "train=1-3", "--ranges", "train"]) == 0
    args = ["--map", str(mp), "--status", str(st), "--config", str(chosen), "--predictors", str(pred),
            "--enriched", str(enr), "--today", "2026-11-02"]
    return SimpleNamespace(tmp=tmp_path, raw=raw, pred=pred, art=art, chosen=chosen, mp=mp, st=st, enr=enr,
                           args=args, c2=tmp_path / "c2")


def fake_ckpt(path, digest):
    import torch
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save({"sequence_contract": {"input_contract": {"artifacts_sha256": digest}}}, path)
    return path


def vocab_sizes(lab):
    """field_checks.csv as the CPU checks write it: one vocabulary size per code field."""
    ext = lab.art / "nf_ext1"
    rows = []
    for f in sorted(ext.glob("feature__*.json")):
        e = json.loads(f.read_text())
        if e["type"] == "categorical":
            rows.append({"field": f.name[9:-5], "range": "train", "vocab_size": e["n_categories"]})
    p = lab.c2 / "checks" / "field_checks.csv"
    pd.DataFrame(rows).to_csv(p, index=False)
    return p


def check_args(lab, ckpts):
    vocab_sizes(lab)
    return ["--train-file", str(lab.raw["train"][1]), "--cred-path", "none",
            "--checkpoints", *[str(c) for c in ckpts]]


def sha(p):
    import hashlib
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def test_extended_version_copies_version_1_and_adds_the_scratch_fields(lab):
    assert B.main(lab.args) == 0
    v1, ext, scr = lab.art / "1", lab.art / "nf_ext1", lab.art / "nf_scratch1"
    base = A.list_features(lab.pred.read_bytes())
    for f in v1.iterdir():
        if f.name != "manifest.json":
            assert sha(ext / f.name) == sha(f), f.name
    rec = json.loads((lab.c2 / "artifact" / "artifact_hashes.json").read_text())
    for n in rec["new_fields"]:
        assert sha(ext / f"feature__{n}.json") == sha(scr / f"feature__{n}.json")
    assert "merchant_xid" in rec["new_fields"] and "cnt_24h" in rec["new_fields"]  # raw and engineered
    man = json.loads((ext / "manifest.json").read_text())
    m1 = json.loads((v1 / "manifest.json").read_text())
    assert man["fit_files"] == m1["fit_files"] == ["part_1.parquet", "part_2.parquet"]
    assert man["features"] == sorted(set(m1["features"]) | set(rec["new_fields"]))
    assert man["artifact_version"] == "nf_ext1" and man["created"] == "2026-11-02"
    assert set(base) <= set(m1["features"])
    assert rec["fit"]["cnt_24h"]["from_enriched_copies"] is True
    assert rec["fit"]["cnt_24h"]["base"].endswith("tfm_raw_data") and str(lab.enr) in rec["fit"]["cnt_24h"]["base"]
    # a new code field's vocabulary is fit on the enriched copies' text codes
    voc = json.loads((ext / "feature__type_code.json").read_text())["vocab"]
    assert set(voc) <= {"A", "B", "C"}


def test_base_digest_equals_what_the_unchanged_input_contract_stores(lab):
    assert B.main(lab.args) == 0
    import nf_layout
    contracts = nf_layout.get("input_contract")
    pre = nf_layout.get("preprocessing")
    fl = nf_layout.get("feature_list")
    rec = json.loads((lab.c2 / "artifact" / "artifact_hashes.json").read_text())
    v1 = pre.PreprocessingArtifacts.load(str(lab.art / "1"))
    features = fl.load_feature_list(str(lab.pred))
    ds = SimpleNamespace(features=features, artifacts=v1, categorical_cardinality=[], continuous_cols=[],
                         categorical_cols=[], datetime_config=SimpleNamespace(), target_col="frd_tag",
                         positive_label=1)
    import dataclasses
    ds.datetime_config = nf_layout.get("datetime_features").DatetimeConfig()
    assert dataclasses.is_dataclass(ds.datetime_config)
    stored = contracts.build_input_contract(ds)["artifacts_sha256"]
    assert stored == rec["payload_sha256"]["base"]


def test_check_passes_with_matching_checkpoints_and_stops_on_a_mismatch(lab):
    assert B.main(lab.args) == 0
    rec = json.loads((lab.c2 / "artifact" / "artifact_hashes.json").read_text())
    good = [fake_ckpt(lab.tmp / "m" / f"seed{s}" / "best.ckpt", rec["payload_sha256"]["base"]) for s in (42, 43, 44)]
    assert K.main(check_args(lab, good)) == 0
    out = json.loads((lab.c2 / "artifact" / "artifact_check.json").read_text())
    assert out["result"] == "PASS"
    assert out["lines"]["base_identical"]["text"].startswith("base fields byte-identical: 8/8")
    assert out["lines"]["encode"]["result"] == "PASS" and out["lines"]["month_switch"]["result"] == "PASS"
    assert out["lines"]["vocab"]["result"] == "PASS"
    t = pd.read_csv(lab.c2 / "checks" / "field_checks.csv")
    t.loc[t["field"] == "type_code", "vocab_size"] = 99
    t.to_csv(lab.c2 / "checks" / "field_checks.csv", index=False)
    assert K.main(["--train-file", str(lab.raw["train"][1]), "--cred-path", "none",
                                               "--checkpoints", *map(str, good)]) == 3
    assert json.loads((lab.c2 / "artifact" / "artifact_check.json").read_text())["lines"]["vocab"]["result"] == "FAIL"
    bad = good[:2] + [fake_ckpt(lab.tmp / "m" / "seed44b" / "best.ckpt", "0" * 64)]
    assert K.main(check_args(lab, bad)) == 3
    absent = good[:2] + [lab.tmp / "nowhere" / "best.ckpt"]
    assert K.main(check_args(lab, absent)) == 3
    assert json.loads((lab.c2 / "artifact" / "artifact_check.json").read_text())["result"] == "WAIT"


def test_check_fails_when_a_base_file_changes(lab):
    assert B.main(lab.args) == 0
    rec = json.loads((lab.c2 / "artifact" / "artifact_hashes.json").read_text())
    good = [fake_ckpt(lab.tmp / "m" / f"seed{s}" / "best.ckpt", rec["payload_sha256"]["base"]) for s in (42, 43, 44)]
    f = lab.art / "nf_ext1" / "feature__transaction_amt.json"
    entry = json.loads(f.read_text())
    f.write_text(json.dumps(entry, indent=2) + " ")  # same values, different bytes
    assert K.main(check_args(lab, good)) == 3
    out = json.loads((lab.c2 / "artifact" / "artifact_check.json").read_text())
    assert out["lines"]["base_identical"]["result"] == "FAIL"


def test_month_switch_lists_differ_by_the_month_line_only(lab):
    assert B.main(lab.args) == 0
    m_in = (lab.c2 / "artifact" / "predictors_all_month_in.csv").read_bytes()
    m_out = (lab.c2 / "artifact" / "predictors_all_month_out.csv").read_bytes()
    assert m_in.startswith(lab.pred.read_bytes())          # the base list byte for byte, in order
    assert A.month_out_ok(m_in, m_out)
    assert b"month," not in m_out and len(m_in.splitlines()) == len(m_out.splitlines()) + 1
    assert not A.month_out_ok(m_in, m_out.replace(b"hour,", b"hourx,"))
    rec = json.loads((lab.c2 / "artifact" / "artifact_hashes.json").read_text())
    # month out over the same artifact: the base fields' entries (and so their bytes) are the same
    import nf_layout
    pre = nf_layout.get("preprocessing")
    v1 = pre.PreprocessingArtifacts.load(str(lab.art / "1"))
    base = A.list_features(lab.pred.read_bytes())
    assert rec["payload_sha256"]["base_month_out"] == A.payload_digest(v1, [n for n in base if n != "month"])
    assert rec["payload_sha256"]["all_month_in"] != rec["payload_sha256"]["all_month_out"]
    assert set(rec["input_sets"]) >= {"A1", "A2", "A3", "all", "A1_alone", "A2_alone"}


def test_a_second_refit_keeps_the_base_fields_byte_identical(lab):
    assert B.main(lab.args) == 0
    assert B.main(lab.args + ["--target", "nf_ext2", "--scratch", "nf_scratch2"]) == 0
    for f in (lab.art / "1").iterdir():
        if f.name != "manifest.json":
            assert sha(lab.art / "nf_ext2" / f.name) == sha(f) == sha(lab.art / "nf_ext1" / f.name)
    rec = json.loads((lab.c2 / "artifact" / "artifact_hashes.json").read_text())
    assert rec["extended"] == "nf_ext2"


def test_a_string_version_loads_through_the_trainers_path(lab):
    assert B.main(lab.args) == 0
    from omegaconf import OmegaConf
    import nf_layout
    pre = nf_layout.get("preprocessing")
    cfg = OmegaConf.create({"artifacts": {"base": str(lab.art) + "/", "version": "nf_ext1"}})
    # the expression train_v2 and score_v2 use
    arts = pre.PreprocessingArtifacts.load(f"{cfg.artifacts.base.rstrip('/')}/{cfg.artifacts.version}")
    assert "cnt_24h" in arts.features and arts.artifact_version == "nf_ext1"


@pytest.mark.parametrize("extra", [["--target", "1"], ["--scratch", "1"], ["--target", "nf_scratch1"]])
def test_refuses_version_1_or_a_clashing_target(lab, extra):
    assert B.main(lab.args + extra) == 4


def test_refuses_an_existing_target(lab):
    (lab.art / "nf_ext1").mkdir()
    (lab.art / "nf_ext1" / "manifest.json").write_text("{}")
    assert B.main(lab.args) == 4


def test_refuses_scratch_fit_files_that_differ(lab, monkeypatch):
    def other_fit(cfg_path):
        cfg = yaml.safe_load(Path(cfg_path).read_text())
        cfg["data"]["file_end"] = 3
        Path(cfg_path).write_text(yaml.safe_dump(cfg))
        return builder_in_process(cfg_path)
    monkeypatch.setattr(B, "run_builder", other_fit)
    assert B.main(lab.args) == 4
    assert not (lab.art / "nf_ext1").exists()


def test_refuses_a_name_already_in_version_1_and_unconfirmed_or_stale_maps(lab):
    world.field_map(lab.mp, fields=[("transaction_amt", "v22b", "raw", "raw", "transaction_amt", "continuous")])
    world.field_status(lab.st, lab.mp)
    assert B.main(lab.args) == 4
    world.field_map(lab.mp, list_status="UNCONFIRMED")
    world.field_status(lab.st, lab.mp)
    assert B.main(lab.args) == 4
    world.field_map(lab.mp)
    os.utime(lab.mp, (os.path.getmtime(lab.st) + 10,) * 2)
    assert B.main(lab.args) == 4
    assert not (lab.art / "nf_ext1").exists()


def test_refuses_fit_files_that_are_not_one_run():
    with pytest.raises(SystemExit):
        A.fit_range(["part_1.parquet", "part_3.parquet"])
    assert A.fit_range(["part_1.parquet", "part_2.parquet"]) == (1, 2)


def test_month_out_refuses_a_list_without_one_month_line():
    with pytest.raises(SystemExit):
        A.month_out_list(b"feature,type,source,version,description\nhour,categorical,derived:t,1,h\n")


def test_diagnostic_refit_reports_base_fields_and_time_encoding(lab):
    assert B.main(lab.args) == 0
    rec = json.loads((lab.c2 / "artifact" / "artifact_hashes.json").read_text())
    good = [fake_ckpt(lab.tmp / "m" / f"seed{s}" / "best.ckpt", rec["payload_sha256"]["base"]) for s in (42, 43, 44)]
    monkey_builder = B.run_builder
    assert monkey_builder is builder_in_process
    assert K.main(check_args(lab, good) + ["--diagnostic-refit", "--time-encoding"]) == 0
    out = json.loads((lab.c2 / "artifact" / "artifact_check.json").read_text())
    assert out["info"]["diagnostic_refit"]["differ"] == []   # this builder reproduces version 1 here
    assert out["info"]["time_encoding"]["fields"] == len(rec["base_predictors"]) + len(rec["new_fields"])
    assert np.isfinite(out["info"]["time_encoding"]["peak_rss_mb"])
