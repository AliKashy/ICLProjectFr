"""End to end on the synthetic world: every planted case gives its result, clean fields get no rule,
the outputs exist, the input map is untouched and the summary fits one screen."""

import hashlib

import pandas as pd

from new_fields_checks_helpers import dry_world, load

S = load("nf_checks_synth")
CLEAN = ("syn_clean_num", "syn_clean_code", "syn_clean_days", "syn_count_24h")


def _status():
    w = dry_world()
    assert w["rc"] == 0, "\n".join(w["log"][-20:])
    return pd.read_csv(w["out"] / "field_status.csv", keep_default_na=False)


def test_every_planted_case_gets_its_result():
    st = _status().set_index("field")
    wrong = []
    for name, (result, rule) in S.EXPECTED.items():
        r = st.loc[name]
        if r["result"] != result or (rule and rule not in r["reasons"]):
            wrong.append(f"{name}: {r['result']} {r['reasons']}")
    assert not wrong, "\n".join(wrong)


def test_clean_fields_get_no_rule_at_all():
    st = _status().set_index("field")
    for name in CLEAN:
        assert st.loc[name, "result"] == "PASS"
        assert st.loc[name, "reasons"] == ""


def test_nothing_is_removed_and_every_field_has_a_row():
    st = _status()
    fm = pd.read_csv(dry_world()["folder"] / "FIELD_MAP.csv", keep_default_na=False)
    assert list(st["field"]) == list(fm["name"])
    checked = pd.read_csv(dry_world()["out"] / "FIELD_MAP_checked.csv", keep_default_na=False)
    assert list(checked["name"]) == list(fm["name"])
    assert (checked["check_result"] != "").all()


def test_input_map_is_not_changed():
    w = dry_world()
    fm = S.field_map()
    expect = fm.to_csv(index=False).encode()
    have = (w["folder"] / "FIELD_MAP.csv").read_bytes()
    assert hashlib.sha256(have).hexdigest() == hashlib.sha256(expect).hexdigest()


def test_outputs_exist_with_full_numbers():
    out = dry_world()["out"]
    for f in ("field_checks.csv", "field_status.csv", "clusters.csv", "month_overlap.csv", "missing_by_month.csv",
              "duplicates.csv", "FIELD_MAP_checked.csv", "summary.txt", "thresholds_used.json"):
        assert (out / f).exists(), f
    fc = pd.read_csv(out / "field_checks.csv", keep_default_na=False)
    assert set(fc["range"]) == {"train", "fit", "val", "june", "duplicates"}
    tr = fc[(fc["range"] == "train") & (fc["field"] == "syn_clean_num")].iloc[0]
    # full precision, nothing rounded away or masked
    assert len(str(tr["missing_train"]).split(".")[-1]) > 4


def test_summary_fits_one_screen():
    text = (dry_world()["out"] / "summary.txt").read_text().rstrip("\n").split("\n")
    assert len(text) <= 40
    assert max(len(x) for x in text) <= 90
    assert text[0].startswith("FIELD CHECKS")
    assert any(x.startswith("June: Test 1 June rows only") for x in text)


def test_overlap_is_kept_once_with_the_precedence():
    st = _status().set_index("field")
    assert st.loc["syn_base_copy", "kept_once_as"] != ""          # a base input wins
    assert st.loc["syn_le_recode", "kept_once_as"] == "syn_clean_code"   # v22b before f15298
    dups = pd.read_csv(dry_world()["out"] / "duplicates.csv", keep_default_na=False)
    assert ((dups["field"] == "syn_le_recode") & (dups["other"] == "syn_clean_code")).any()
