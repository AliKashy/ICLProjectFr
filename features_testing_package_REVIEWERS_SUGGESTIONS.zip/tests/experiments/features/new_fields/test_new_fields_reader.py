"""The reader end to end on a synthetic world: planted effects at one seed and at three, the month rule, the
prune rule, the SELECT check, the spread step, the screen and the logs."""
from __future__ import annotations

import json

import numpy as np
import pytest

from new_fields_reader_world import World, june, load, scores, bump, write_spread, rank_check

R = load("nf_ranked")
RD = load("nf_read")


@pytest.fixture
def world(tmp_path, monkeypatch):
    return World(tmp_path, monkeypatch)


def _one_seed(w, step, cand_score, ctrl_score, pop="rank_b", seed=42, sd_run=0.001, name="cand"):
    write_spread(w.c2, "rank_b" if pop == "rank_b" else "select_june", sd_run)
    cand = w.fit(pop, name, seed, cand_score)
    ctrl = w.fit(pop, "ctrl", seed, ctrl_score)
    return w.table(f"{step}_{seed}", [cand], [ctrl])


def _screen_ok(text):
    lines = text.rstrip("\n").split("\n")
    assert len(lines) <= 40 and max(len(x) for x in lines) <= 90
    return lines


# ------------------------------------------------------------------ adding steps, one seed

def test_large_gain_gives_adopt_pending_the_select_check(world):
    raw = world.raw["rank_b"][0]
    t = _one_seed(world, "A1", scores(raw, 6.0, 1), scores(raw, 0.5, 2))
    assert world.run("read", "--step", "A1", "--runs", t) == 0
    rec = world.saved("A1_1seed.json")
    assert rec["rule_decision"] == "ADOPT" and rec["pending_select_check"] and rec["final_decision"] is None
    assert rec["decision"] == "ADOPT (pending the SELECT check)"
    assert rec["gain_udr"] >= rec["t1_udr"] and rec["gain_udr"] >= 0.01 and rec["lb_bootstrap"] > 0
    lines = _screen_ok(world.text("A1_1seed.txt"))
    assert "DECISION: ADOPT (pending the SELECT check)" in lines
    assert "engine = _alert at 6 per mille: equal" in lines
    assert "note: one seed; the bootstrap covers rows, not seed-to-seed variation" in lines


def test_small_gain_below_t1_gives_run_seeds_43_and_44(world):
    raw = world.raw["rank_b"][0]
    base = scores(raw, 0.8, 3)
    t = _one_seed(world, "A1", bump(raw, base, 2), base, sd_run=0.05)
    assert world.run("read", "--step", "A1", "--runs", t) == 0
    rec = world.saved("A1_1seed.json")
    assert 0 < rec["gain_udr"] < rec["t1_udr"]
    assert rec["rule_decision"] == "RUN SEEDS 43 AND 44" and not rec["pending_select_check"]
    # T1(UDR) = t x sqrt(sd_pair^2 + 2 x sd_run^2), t one-sided 95% at the Welch-Satterthwaite degrees of freedom
    # (the reviewers' decision D2, corrected 3 November: no null subtraction), with the spread file's sd_run (2 df)
    from scipy.stats import t as student_t
    sd_pair = rec["metrics"]["udr"]["sd"]
    a, b = sd_pair ** 2, 2 * 0.05 ** 2
    nu = (a + b) ** 2 / (b ** 2 / 2)
    assert rec["t1_udr"] == pytest.approx(student_t.ppf(0.95, nu) * np.sqrt(a + b))
    assert "next: S.5" in world.text("A1_1seed.txt")


def test_gain_above_t1_but_below_the_bar_runs_seeds_43_and_44(tmp_path, monkeypatch):
    # the plan's one-fit rule: any gain above zero that is not adopted at one seed runs seeds 43 and 44
    w = World(tmp_path, monkeypatch, bar_udr=0.95)
    raw = w.raw["rank_b"][0]
    t = _one_seed(w, "A1", scores(raw, 6.0, 1), scores(raw, 0.5, 2))
    assert w.run("read", "--step", "A1", "--runs", t) == 0
    rec = w.saved("A1_1seed.json")
    assert rec["gain_udr"] >= rec["t1_udr"]
    assert rec["rule_decision"] == "RUN SEEDS 43 AND 44" and "below the bar" in rec["reason"]
    assert "account bootstrap's alone" in w.text("A1_1seed.txt")


def test_a_loss_keeps_the_control(world):
    raw = world.raw["rank_b"][0]
    t = _one_seed(world, "A1", scores(raw, 0.3, 1), scores(raw, 4.0, 2))
    assert world.run("read", "--step", "A1", "--runs", t) == 0
    rec = world.saved("A1_1seed.json")
    assert rec["gain_udr"] <= 0 and rec["rule_decision"] == "KEEP THE CONTROL"


def test_point_measures_equal_the_reference_on_the_read_rows(world):
    ref = load_reference()
    raw = world.raw["rank_b"][0]
    cand_s, ctrl_s = scores(raw, 3.0, 1, decimals=2), scores(raw, 1.0, 2, decimals=2)
    t = _one_seed(world, "A1", cand_s, ctrl_s)
    assert world.run("read", "--step", "A1", "--runs", t) == 0
    rec = world.saved("A1_1seed.json")
    jm = _june_mask(raw)
    jr = raw[jm]
    keys = R.identity_keys(jr["Nmap_account_reference_xid"], jr["fi_transaction_id"])
    for s, side in ((cand_s, "candidate"), (ctrl_s, "control")):
        cut = ref.outsort_metrics(jr["frd_tag"].to_numpy(), s[jm].astype(float), amounts=jr["transaction_amt"].to_numpy(),
                                  row_keys=keys, percents=("0.6",))["cuts"][0]
        assert rec["metrics"]["udr"][side][0] == pytest.approx(cut["udr"], rel=1e-12)
        assert rec["metrics"]["vdr"][side][0] == pytest.approx(cut["vdr"], rel=1e-12)
        assert rec["metrics"]["fpr"][side][0] == pytest.approx(cut["fpr"], rel=1e-12)
    assert rec["rows"] == int(jm.sum()) and rec["outsorted"] == int(jm.sum()) * 3 // 500


def test_shuffled_prediction_rows_give_the_same_read(tmp_path, monkeypatch):
    out = []
    for i, shuffle in enumerate((None, 7)):
        w = World(tmp_path / str(i), monkeypatch)
        raw = w.raw["rank_b"][0]
        write_spread(w.c2, "rank_b", 0.001)
        cand = w.fit("rank_b", "cand", 42, scores(raw, 3.0, 1, decimals=2), shuffle=shuffle)
        ctrl = w.fit("rank_b", "ctrl", 42, scores(raw, 1.0, 2, decimals=2), shuffle=shuffle)
        assert w.run("read", "--step", "A1", "--runs", w.table("t", [cand], [ctrl])) == 0
        out.append(w.saved("A1_1seed.json")["metrics"])
    for m in ("udr", "ap", "vdr", "fpr"):
        for k in ("gain", "sd", "lo", "hi"):
            assert out[0][m][k] == pytest.approx(out[1][m][k], rel=1e-12, abs=1e-15)


# ------------------------------------------------------------------ three seeds

def test_three_seeds_steady_gain_adopts(world):
    raw = world.raw["rank_b"][0]
    write_spread(world.c2, "rank_b", 0.001)
    cands = [world.fit("rank_b", "cand", s, scores(raw, 6.0, 10 + s)) for s in (42, 43, 44)]
    ctrls = [world.fit("rank_b", "ctrl", s, scores(raw, 0.5, 20 + s)) for s in (42, 43, 44)]
    assert world.run("read", "--step", "A1", "--runs", world.table("t3", cands, ctrls)) == 0
    rec = world.saved("A1_3seed.json")
    assert rec["seeds"] == [42, 43, 44] and rec["rule_decision"] == "ADOPT" and rec["lb_three_seed_plan"] > 0
    # the paired three-seed bound (D2, corrected 3 November): the SD of the three paired differences, t at 2 df
    d = rec["metrics"]["udr"]["differences"]
    lb3 = rec["gain_udr"] - 2.919986 * np.sqrt(rec["metrics"]["udr"]["var"] + np.var(d, ddof=1) / 3)
    assert rec["lb_three_seed_plan"] == pytest.approx(lb3, rel=1e-5)
    assert rec["three_seed_bound"] == "paired" and rec["three_seed_df"] == 2
    text = world.text("A1_3seed.txt")
    assert "LB_3 (paired: gain - t x sqrt(v_acct + s_d^2/3)" in text and "t 2.920 at 2 df" in text
    assert "bootstrap LB" in text
    assert "note: one seed" not in text


def test_three_seeds_mixed_gain_keeps_the_control_unresolved(world):
    raw = world.raw["rank_b"][0]
    write_spread(world.c2, "rank_b", 0.001)
    base = scores(raw, 2.0, 5)
    cands = [world.fit("rank_b", "cand", 42, scores(raw, 6.0, 1)),
             world.fit("rank_b", "cand", 43, scores(raw, 0.2, 2)),
             world.fit("rank_b", "cand", 44, bump(raw, base, 1))]
    ctrls = [world.fit("rank_b", "ctrl", s, base) for s in (42, 43, 44)]
    assert world.run("read", "--step", "A2", "--runs", world.table("t3", cands, ctrls)) == 0
    rec = world.saved("A2_3seed.json")
    assert rec["rule_decision"] == "KEEP THE CONTROL"
    if rec["gain_udr"] > 0:
        assert rec["reason"].startswith("unresolved")
    assert "the control won its own step" in world.text("A2_3seed.txt")


# ------------------------------------------------------------------ the month rule (step B)

def test_month_rule_keep_month_when_removing_it_loses(world):
    raw = world.raw["rank_b"][0]
    t = _one_seed(world, "B", scores(raw, 0.5, 1), scores(raw, 4.0, 2))
    assert world.run("read", "--step", "B", "--runs", t) == 0
    rec = world.saved("B_1seed.json")
    assert rec["rule"] == "month_out" and rec["rule_decision"] == "KEEP MONTH"


def test_month_rule_keeps_month_when_h_is_zero(world):
    # the one-fit rule first: h (the gain of month out) at or below zero keeps month in
    raw = world.raw["rank_b"][0]
    base = scores(raw, 2.0, 3)
    t = _one_seed(world, "B", base, base.copy(), sd_run=0.05)
    assert world.run("read", "--step", "B", "--runs", t) == 0
    rec = world.saved("B_1seed.json")
    assert rec["gain_udr"] == 0 and rec["rule_decision"] == "KEEP MONTH"


def test_month_rule_month_out_then_the_select_check_both_ways(tmp_path, monkeypatch):
    for passes in (True, False):
        w = World(tmp_path / str(passes), monkeypatch)
        raw = w.raw["rank_b"][0]
        t = _one_seed(w, "B", scores(raw, 6.0, 1), scores(raw, 0.5, 2))
        assert w.run("read", "--step", "B", "--runs", t) == 0
        assert w.saved("B_1seed.json")["rule_decision"] == "MONTH OUT"
        sraw = w.raw["select"][0]
        good, bad = scores(sraw, 4.0, 3), scores(sraw, 0.2, 4)
        cand = w.fit("select", "cand", 42, good if passes else bad)
        ctrl = w.fit("select", "ctrl", 42, scores(sraw, 2.0, 5))
        assert w.run("select-check", "--step", "B", "--runs", w.table("sel", [cand], [ctrl])) == 0
        rec = w.saved("B_select.json")
        assert rec["check"]["pass"] is passes
        assert rec["final_decision"] == ("MONTH OUT" if passes else "KEEP MONTH")
        assert rec["decision"] == ("PASS: MONTH OUT" if passes else "FAIL: KEEP MONTH")
        _screen_ok(w.text("B_select.txt"))
        assert f"B {'MONTH OUT' if passes else 'KEEP MONTH'}" in (w.c2 / "DECISIONS.log").read_text()


# ------------------------------------------------------------------ the prune rule (step P)

def test_prune_rule_both_ways(tmp_path, monkeypatch):
    w = World(tmp_path / "a", monkeypatch)
    raw = w.raw["rank_b"][0]
    t = _one_seed(w, "P", scores(raw, 0.3, 1), scores(raw, 6.0, 2))  # pruned much worse
    assert w.run("read", "--step", "P", "--runs", t) == 0
    assert w.saved("P_1seed.json")["rule_decision"] == "KEEP THE UNPRUNED LIST"
    w = World(tmp_path / "b", monkeypatch)
    raw = w.raw["rank_b"][0]
    base = scores(raw, 2.0, 3)
    t = _one_seed(w, "P", base, base.copy())
    assert w.run("read", "--step", "P", "--runs", t) == 0
    rec = w.saved("P_1seed.json")
    assert rec["rule_decision"] == "KEEP THE SMALLER LIST" and rec["pending_select_check"]


@pytest.mark.parametrize("upper", [None, float("nan"), float("inf"), -float("inf")])
def test_prune_undefined_upper_bound_stops(upper):
    with pytest.raises(RD.ReadError, match="upper.*not finite") as err:
        RD.decide("prune", 1, -0.02, 0.0, 0.01, None, hi=upper)
    assert err.value.code == 3


def test_prune_undefined_upper_bound_returns_stop_without_decision(world, monkeypatch, capsys):
    raw = world.raw["rank_b"][0]
    base = scores(raw, 2.0, 3)
    table = _one_seed(world, "P", base, base.copy())
    paired = world.ranked.paired

    def undefined_upper(*args, **kwargs):
        result = paired(*args, **kwargs)
        result["metrics"]["udr"]["hi"] = None
        return result

    monkeypatch.setattr(world.ranked, "paired", undefined_upper)
    assert world.run("read", "--step", "P", "--runs", table) == 3
    assert "upper" in capsys.readouterr().out
    assert not (world.c2 / "reads" / "P_1seed.json").exists()
    assert not (world.c2 / "DECISIONS.log").exists()


# ------------------------------------------------------------------ SELECT decides

def test_select_decides_when_the_rank_check_fails_and_checks_on_the_same_read(world):
    rank_check(world.c2, "FAIL")
    sraw = world.raw["select"][0]
    t = _one_seed(world, "A1", scores(sraw, 6.0, 1), scores(sraw, 0.5, 2), pop="select")
    assert world.run("read", "--step", "A1", "--runs", t) == 0
    rec = world.saved("A1_1seed.json")
    assert rec["population"] == "select_june" and rec["rule_decision"] == "ADOPT"
    assert rec["final_decision"] == "ADOPT" and not rec["pending_select_check"]
    assert rec["select_check_same_read"]["pass"]
    text = world.text("A1_1seed.txt")
    assert "not independent" in text and "no independent check remains" in text


def test_failed_select_check_on_the_same_read_reverts_adopt(world):
    rank_check(world.c2, "FAIL")
    sraw = world.raw["select"][0]
    # The UDR gain is large, but AP falls far below the control: the check fails.
    jm = _june_mask(sraw)
    y = sraw["frd_tag"].to_numpy()
    n_out = int(jm.sum()) * 3 // 500
    rng = np.random.default_rng(0)
    noise = (rng.random(len(y)) * 0.4).astype(np.float32)
    ctrl = noise.copy()
    ctrl[np.flatnonzero(jm & (y == 0))[:n_out]] = 1.0  # the control's outsort is all non-frauds...
    ctrl[jm & (y == 1)] = 0.9  # ...and every fraud comes right after it: UDR 0, AP high
    cand = noise.copy()
    cand[np.flatnonzero(jm & (y == 1))[:n_out]] = 1.0  # the candidate's outsort is all frauds...
    cand[np.flatnonzero(jm & (y == 1))[n_out:]] = 0.0  # ...and the other frauds at the bottom: AP low
    t = _one_seed(world, "A1", cand, ctrl, pop="select")
    assert world.run("read", "--step", "A1", "--runs", t) == 0
    rec = world.saved("A1_1seed.json")
    assert rec["rule_decision"] == "ADOPT"
    assert not rec["select_check_same_read"]["pass"]
    assert rec["final_decision"] == "KEEP THE CONTROL"


# ------------------------------------------------------------------ the spread step

def test_spread_measures_the_kept_seed_spread_with_two_degrees_of_freedom(world):
    ref = load_reference()
    raw = world.raw["rank_b"][0]
    fits, cuts = [], []
    jm = _june_mask(raw)
    jr = raw[jm]
    keys = R.identity_keys(jr["Nmap_account_reference_xid"], jr["fi_transaction_id"])
    for seed, signal in ((42, 2.0), (43, 2.6), (44, 3.4)):
        s = scores(raw, signal, seed)
        fits.append(dict(world.fit("rank_b", "kept", seed, s), role="kept"))
        cuts.append(ref.outsort_metrics(jr["frd_tag"].to_numpy(), s[jm].astype(float), row_keys=keys,
                                        percents=("0.6",))["cuts"][0]["udr"])
    from new_fields_reader_world import run_table
    t = run_table(world.tmp / "kept.csv", fits)
    assert world.run("spread", "--population", "rank_b", "--runs", t) == 0
    rec = world.saved("spread_rank_b.json")
    assert rec["metrics"]["udr"]["values"] == pytest.approx(cuts, rel=1e-12)
    assert rec["metrics"]["udr"]["sd_run"] == pytest.approx(np.std(cuts, ddof=1), rel=1e-12)
    assert rec["metrics"]["udr"]["df"] == 2
    _screen_ok(world.text("spread_rank_b.txt"))
    # Saved: running it again returns the saved spread.
    assert world.run("spread", "--population", "rank_b", "--runs", t) == 0


# ------------------------------------------------------------------ logs, saved reads and the report

def test_saved_read_is_returned_and_logs_are_appended(world, capsys):
    raw = world.raw["rank_b"][0]
    t = _one_seed(world, "A1", scores(raw, 0.3, 1), scores(raw, 4.0, 2))
    assert world.run("read", "--step", "A1", "--runs", t) == 0
    first = world.text("A1_1seed.txt")
    capsys.readouterr()
    assert world.run("read", "--step", "A1", "--runs", t) == 0
    assert capsys.readouterr().out.strip() == first.strip()
    reads = (world.c2 / "READS.log").read_text().splitlines()
    assert len(reads) == 1 and "decision=KEEP THE CONTROL" in reads[0] and "files=10-13" in reads[0]
    assert len((world.c2 / "DECISIONS.log").read_text().splitlines()) == 1
    assert world.run("report") == 0
    out = capsys.readouterr().out
    assert "A1 1 seed  rank_b: KEEP THE CONTROL" in out
    assert world.run("report", "--step", "A1") == 0


def test_decision_functions_at_their_boundaries():
    d = RD.decide
    assert d("add", 1, 0.0, 0.02, 0.01, 0.5)[0] == "KEEP THE CONTROL"
    assert d("add", 1, 0.019, 0.02, 0.01, 0.5)[0] == "RUN SEEDS 43 AND 44"
    assert d("add", 1, 0.02, 0.02, 0.01, 0.001)[0] == "ADOPT"
    # at or above T1 but short of its rule at one seed: seeds 43 and 44 decide (plan; DESIGN.md 8.6 row 4 changed)
    assert d("add", 1, 0.02, 0.02, 0.01, 0.0)[0] == "RUN SEEDS 43 AND 44"
    assert d("add", 1, 0.02, 0.02, 0.03, 0.5)[0] == "RUN SEEDS 43 AND 44"
    assert d("add", 1, 0.02, 0.02, 0.01, None)[0] == "RUN SEEDS 43 AND 44"
    assert d("add", 1, 0.02, 0.02, 0.01, 0.001)[0] == "ADOPT"
    # a larger gain never gets a worse outcome than a smaller one at one seed
    order = {"KEEP THE CONTROL": 0, "RUN SEEDS 43 AND 44": 1, "ADOPT": 2}
    outcomes = [order[d("add", 1, g, 0.02, 0.01, lb)[0]] for g, lb in
                ((-0.01, -0.02), (0.0, -0.01), (0.005, -0.001), (0.019, 0.001), (0.02, -0.001), (0.03, 0.002))]
    assert outcomes == sorted(outcomes)
    assert d("add", 3, 0.02, None, 0.01, None, lb3=0.001)[0] == "ADOPT"
    dec, why, _ = d("add", 3, 0.02, None, 0.01, None, lb3=-0.001)
    assert dec == "KEEP THE CONTROL" and why.startswith("unresolved")
    assert not d("add", 3, -0.02, None, 0.01, None, lb3=-0.1)[1].startswith("unresolved")
    assert d("month_out", 1, -0.0001, 0.02, 0.01, None)[0] == "KEEP MONTH"
    # the one-fit rule first: a gain (h) at or below zero keeps the control (month in)
    assert d("month_out", 1, 0.0, 0.02, 0.01, None)[0] == "KEEP MONTH"
    assert d("month_out", 1, 0.0001, 0.02, 0.01, None)[0] == "RUN SEEDS 43 AND 44"
    assert d("month_out", 1, 0.02, 0.02, 0.01, None)[0] == "MONTH OUT"
    assert d("month_out", 3, 0.0, None, 0.01, None)[0] == "MONTH OUT"
    assert d("month_out", 3, -0.001, None, 0.01, None)[0] == "KEEP MONTH"
    assert d("prune", 1, -0.02, 0.0, 0.01, None, hi=-0.005)[0] == "KEEP THE UNPRUNED LIST"
    assert d("prune", 1, -0.02, 0.0, 0.01, None, hi=0.001)[0] == "KEEP THE SMALLER LIST"
    assert d("prune", 1, -0.005, 0.0, 0.01, None, hi=-0.001)[0] == "KEEP THE SMALLER LIST"
    import pytest
    with pytest.raises(ValueError):   # pruning is read at seed 42 only
        d("prune", 3, -0.02, None, 0.01, None, lb3=0.01, hi=-0.001)
    # T_1 and the SELECT check as the reviewers decided (D2); exact values in test_new_fields_decisions_reader.py
    assert RD.t1(0.014, 0.015) == pytest.approx(0.053728, abs=1e-6)
    sp = {"select_june": {"metrics": {m: {"sd_run": 0.01, "df": 2} for m in ("ap", "auroc", "ks", "udr")}}}
    lim = -2.5 * np.sqrt(0.01 ** 2 + 2 * 0.01 ** 2)
    sc = RD.select_check({m: {"gain": lim, "sd": 0.01} for m in ("ap", "auroc", "ks", "udr")}, 2.5, sp, 1)
    assert sc["pass"]
    sc = RD.select_check({m: {"gain": lim - 1e-4, "sd": 0.01} for m in ("ap", "auroc", "ks", "udr")}, 2.5, sp, 1)
    assert not sc["pass"]
    assert RD.finalize("ADOPT", {"pass": False})[0] == "KEEP THE CONTROL"
    assert RD.finalize("KEEP THE SMALLER LIST", {"pass": False})[0] == "KEEP THE UNPRUNED LIST"
    assert RD.finalize("RUN SEEDS 43 AND 44", {"pass": False})[0] == "RUN SEEDS 43 AND 44"


def _june_mask(raw):
    from new_fields_reader_world import june_mask
    return june_mask(raw)


def load_reference():
    import importlib.util
    from pathlib import Path
    p = Path(__file__).resolve().parent / "new_fields_reader_outsort_copy.py"
    spec = importlib.util.spec_from_file_location("nf_test_outsort_reference_b", p)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_calendar_step_reads_under_the_month_rule():
    """The optional cyclical calendar step (C): the one-fit rule, then the month rule, with its own words."""
    d = RD.decide
    assert d("calendar", 1, -0.001, 0.02, 0.01, None)[0] == "KEEP THE CALENDAR"
    assert d("calendar", 1, 0.0, 0.02, 0.01, None)[0] == "KEEP THE CALENDAR"
    assert d("calendar", 1, 0.001, 0.02, 0.01, None)[0] == "RUN SEEDS 43 AND 44"
    dec, _, changes = d("calendar", 1, 0.03, 0.02, 0.01, None)
    assert dec == "CALENDAR CYCLICAL" and changes
    assert d("calendar", 3, 0.0, None, 0.01, None)[0] == "CALENDAR CYCLICAL"
    assert d("calendar", 3, -0.001, None, 0.01, None)[0] == "KEEP THE CALENDAR"
    assert RD.finalize("CALENDAR CYCLICAL", {"pass": False})[0] == "KEEP THE CALENDAR"
    assert RD.step_kind("C") == "calendar"
