"""Restart from partial counts, refusals, and the one-screen limit at about 190 fields."""

import shutil
from pathlib import Path
from types import SimpleNamespace

import pandas as pd

from new_fields_checks_helpers import dry_world, load

F = load("nf_field_checks")
R = load("nf_checks_rules")


def _rerun(out, **over):
    w = dry_world()
    a = F.build_args(["--out", str(out)])
    a.dry_run = True
    folder = w["folder"]
    # reuse the world's files, no rebuild
    a.map = str(folder / "FIELD_MAP.csv")
    a.thresholds = str(over.get("thresholds", folder / "CHECK_THRESHOLDS.yaml"))
    a.status_rules = str(folder / "STATUS_RULES.csv")
    a.decisions = str(folder / "KEEP_DECISIONS.csv")
    a.predictors = str(folder / "predictors.csv")
    a.config = str(folder / "config.yaml")
    S = load("nf_checks_synth")
    a.train_base, a.val_base, a.june_base = str(folder / "raw"), str(folder / "raw"), str(folder / "raw_eval")
    a.train_files, a.val_files, a.june_files = "1-4", "4950-4951", "8000-8001"
    a.fit_files, a.dup_files, a.confirm_file = "1-2", "1,2", "3"
    a.no_settings_ranges = True
    a.min_free_gb = over.get("min_free_gb", 0.0)
    a.sample_rows, a.probe_accounts = 50_000, 80
    log = []
    # the same builders as the first run: the recipes module's engine when it is installed (as dry_run does)
    rc = F.run(a, extra_builders=S.dry_run_builders({}, F.load_recipes(a.recipes) is not None), log=log.append)
    return rc, log


def test_restart_reuses_partial_counts_and_gives_the_same_results(tmp_path):
    w = dry_world()
    out = tmp_path / "out"
    shutil.copytree(w["out"], out)
    (out / "partial" / "train_3.json").unlink()      # as if stopped during file 3
    rc, log = _rerun(out)
    assert rc == 0
    assert any("train file 1: partial counts reused" in x for x in log)
    assert any("train file 3: reading" in x for x in log)
    a = pd.read_csv(w["out"] / "field_status.csv", keep_default_na=False)
    b = pd.read_csv(out / "field_status.csv", keep_default_na=False)
    pd.testing.assert_frame_equal(a, b)


def test_changed_thresholds_refuse_partial_counts(tmp_path):
    w = dry_world()
    out = tmp_path / "out"
    shutil.copytree(w["out"], out)
    th = tmp_path / "CHECK_THRESHOLDS.yaml"
    th.write_text((w["folder"] / "CHECK_THRESHOLDS.yaml").read_text() + "\nextra: 1\n")
    rc, log = _rerun(out, thresholds=th)
    assert rc == 4
    assert any("another thresholds file" in x for x in log)


def test_low_free_memory_is_refused(tmp_path):
    rc, log = _rerun(tmp_path / "out", min_free_gb=10**9)
    assert rc == 4 and any("free host memory" in x for x in log)


def test_two_rows_on_one_name_are_refused(tmp_path):
    w = dry_world()
    fm = pd.read_csv(w["folder"] / "FIELD_MAP.csv", keep_default_na=False)
    p = tmp_path / "FIELD_MAP.csv"
    pd.concat([fm, fm.iloc[[0]]]).to_csv(p, index=False)
    a = F.build_args(["--map", str(p), "--train-base", "x", "--june-base", "y", "--min-free-gb", "0",
                      "--thresholds", str(w["folder"] / "CHECK_THRESHOLDS.yaml")])
    log = []
    assert F.run(a, log=log.append) == 4
    assert any("two rows share one name" in x for x in log)


def test_summary_fits_one_screen_at_190_fields_worst_case():
    rules = ["duplicate", "too_good", "date_after_txn", "fill_only_fraud", "status", "hold", "near_duplicate",
             "overlaps_month", "drift_june", "unk_june", "empty_june", "left_out_recipe", "same_day_date",
             "external_score", "calendar_code", "function_of", "inherited", "missing_drift", "vocab_large"]
    specs, m = [], {}
    for i in range(190):
        name = f"a_rather_long_field_name_number_{i:03d}_for_the_screen"
        res = ["STOP", "WAIT", "FLAG"][i % 3]
        specs.append({"name": name, "group": ["v22b", "f15298", "both"][i % 3], "model_type": "categorical",
                      "is_date": False, "flags": {}})
        rr = [(res, rules[(i + k) % len(rules)], "a value text") for k in range(4)]
        m[name] = {"rules": rr, "result": res, "month_statement": "", "kept_once_as": "x" if i % 5 == 0 else ""}
    ck = SimpleNamespace(specs=specs, m=m, th=R.Thresholds({}), base_tokens=30, pod_columns=227,
                         cluster_rows=[{"cluster_id": "C001", "size": 3}])
    a = SimpleNamespace(train_files="1-10", val_files="4950-4954", june_files="8000-8010",
                        month_adds_nothing=None, map_name="FIELD_MAP.csv")
    text = F.summary_screen(ck, a, "0" * 64, "UNCONFIRMED", "reorganized", Path("checks"))
    lines = text.split("\n")
    assert len(lines) <= 40 and max(len(x) for x in lines) <= 90
    assert any("more rules" in x or "more" in x for x in lines)
