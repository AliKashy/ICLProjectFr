"""Importance contracts against the shared lanes' public recipe API.

The data lane's nf_recipes must be importable for the recipe integration tests;
the importance-only checkout still runs the field-map and cluster contracts.
"""
import json
from pathlib import Path
import sys
from types import SimpleNamespace

import pandas as pd
from pandas.testing import assert_frame_equal
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[4] / "fraud/experiments/features/new_fields"))
from nf_importance_units import build_units, make_recompute, non_account_keys


@pytest.fixture
def recipes():
    return pytest.importorskip("nf_recipes", reason="requires the shared data lane")


def family(table, features, sources=("amount",)):
    return build_units(features, table, unit_specs=[
        {"name": "family:amount", "method": "family", "source_columns": list(sources)}
    ])[-1]


def test_checks_member_rows_make_one_joint_unit_from_fitted_members():
    clusters = pd.DataFrame([
        {"cluster_id": "c1", "member": "amount", "member_kind": "raw"},
        {"cluster_id": "c1", "member": "ratio", "member_kind": "engineered"},
        {"cluster_id": "c1", "member": "ratio", "member_kind": "engineered"},
        {"cluster_id": "c1", "member": "candidate", "member_kind": "engineered"},
        {"cluster_id": "c2", "member": "month", "member_kind": "raw"},
    ])
    units = build_units(["amount", "ratio", "month"], clusters=clusters)
    joint = [unit for unit in units if unit.kind == "cluster"]
    assert len(joint) == 1
    assert joint[0].name == "cluster:c1"
    assert joint[0].members == ("amount", "ratio")
    assert [unit.name for unit in units[:3]] == ["amount", "ratio", "month"]


def test_profile_category_defaults_to_account_for_singles_and_raw_family_sources():
    table = pd.DataFrame([
        {"name": "birth_date", "recipe": "raw", "source_columns": "birth_date",
         "business_category": "account and customer profile"},
        {"name": "age", "recipe": "days_before(birth_date)", "source_columns": "birth_date",
         "business_category": "account and customer profile"},
        {"name": "amount", "recipe": "raw", "source_columns": "amount",
         "business_category": "transaction"},
    ])
    units = build_units(["age", "amount"], table)
    assert [unit.donor_unit for unit in units] == ["account", "event"]
    assert family(table, ["age"], sources=("birth_date",)).donor_unit == "account"
    with pytest.raises(ValueError, match="declared account profile"):
        build_units(["age"], table, unit_specs=[
            {"name": "age", "members": ["age"], "donor_unit": "event"}
        ])


def test_explicit_map_donor_policy_takes_precedence_over_profile_category():
    table = pd.DataFrame([
        {"name": "profile", "recipe": "raw", "business_category": "account and customer profile",
         "donor_unit": "event"},
    ])
    assert build_units(["profile"], table)[0].donor_unit == "event"


def test_check_cluster_cannot_mix_default_profile_and_event_donors():
    table = pd.DataFrame([
        {"name": "profile", "business_category": "account and customer profile"},
        {"name": "amount", "business_category": "transaction"},
    ])
    clusters = pd.DataFrame({"cluster_id": ["c1", "c1"], "member": ["profile", "amount"]})
    with pytest.raises(ValueError, match="mixes event and account"):
        build_units(["profile", "amount"], table, clusters=clusters)


def test_real_builder_rebuilds_whole_stream_and_keeps_tie_identity(recipes, monkeypatch):
    # Neither ratio nor prev uses StrictWindows or the A3 builders. Keep the
    # published parser, FileContext, build_columns and build_fields unchanged.
    monkeypatch.setattr(recipes, "load_engine", lambda: (None, {}))
    table = pd.DataFrame([
        {"name": "ratio", "recipe": "ratio(amount; limit)", "source_columns": "amount;limit",
         "model_type": "continuous"},
        {"name": "previous", "recipe": "prev(amount; key=customer; within=all)",
         "source_columns": "amount;customer", "model_type": "continuous"},
    ])
    unit = family(table, ["ratio", "previous"])
    frame = pd.DataFrame({
        "account": ["a", "b", "b"], "customer": ["shared"] * 3,
        "time": pd.to_datetime(["2025-06-01 00:00:00", "2025-06-01 00:00:00", "2025-06-01 00:00:01"]),
        "fi_transaction_id": ["b", "a", "c"], "amount": [9., 5., 100.], "limit": [3., 2., 10.],
        "ratio": [-1.] * 3, "previous": [-1.] * 3, "untouched": [8, 7, 6],
    }, index=[12, 8, 3])
    original = frame.copy(deep=True)
    recompute = make_recompute(table, "account", "time", "2025-05-01")
    changed = recompute(frame, unit)
    assert changed.ratio.tolist() == [3., 2.5, 10.]
    assert changed.previous.iloc[:2].isna().all()
    assert changed.previous.iloc[2] == 9.  # account a's same-customer row, tie id b
    assert_frame_equal(changed.drop(columns=["ratio", "previous"]),
                       original.drop(columns=["ratio", "previous"]))
    assert_frame_equal(frame, original)


@pytest.mark.parametrize("source_columns", ["limit", "amount;limit"])
def test_recipe_closure_rejects_missing_or_invented_metadata_dependency(recipes, source_columns):
    # The first row establishes an amount family. The second has either an
    # omitted real dependency or an invented dependency in the metadata.
    recipe = "ratio(amount; limit)" if source_columns == "limit" else "ratio(other; limit)"
    table = pd.DataFrame([
        {"name": "ratio", "recipe": "ratio(amount; limit)", "source_columns": "amount;limit"},
        {"name": "other_ratio", "recipe": recipe, "source_columns": source_columns},
    ])
    unit = family(table, ["ratio", "other_ratio"])
    with pytest.raises(ValueError, match="dependency_closure.*source_columns"):
        make_recompute(table, "account", "time", "2025-05-01")(pd.DataFrame(), unit)


def test_transitive_output_recipe_cannot_bypass_raw_recipe_closure(recipes):
    table = pd.DataFrame([
        {"name": "ratio", "recipe": "ratio(amount; limit)", "source_columns": "amount;limit"},
        {"name": "scaled", "recipe": "ratio(ratio; scale)", "source_columns": "ratio;scale"},
    ])
    unit = family(table, ["ratio", "scaled"])
    with pytest.raises(ValueError, match="dependency_closure"):
        make_recompute(table, "account", "time", "2025-05-01")(pd.DataFrame(), unit)


def test_required_columns_include_recipe_only_filter_match_key_and_tie(recipes):
    # source_columns declares the perturbation dependency, but the engine is
    # authoritative about every raw column needed to execute the recipe.
    table = pd.DataFrame([
        {"name": "total", "recipe": "sum(24h; value=amount; same=merchant; where=status:1; key=customer)",
         "source_columns": "amount", "model_type": "continuous"},
    ])
    unit = family(table, ["total"])
    recompute = make_recompute(table, "account", "time", "2025-05-01")
    assert set(recompute.required_columns(unit)) == {
        "account", "time", "fi_transaction_id", "amount", "merchant", "status", "customer"
    }


def test_non_account_keys_collects_all_affected_recipes_only_for_families(recipes):
    table = pd.DataFrame([
        {"name": "customer_prev", "recipe": "prev(amount; key=customer)",
         "source_columns": "amount;customer"},
        {"name": "card_prev", "recipe": "prev(amount; key=card)", "source_columns": "amount;card"},
        {"name": "account_prev", "recipe": "prev(amount; key=account)", "source_columns": "amount;account"},
        {"name": "default_prev", "recipe": "prev(amount)", "source_columns": "amount"},
        {"name": "unrelated", "recipe": "prev(other; key=household)", "source_columns": "other;household"},
    ])
    singles = build_units(["customer_prev", "unrelated"], table)
    assert non_account_keys(table, singles, "account") == {}
    unit = family(table, ["customer_prev"])
    # card_prev is not fitted, but is still rebuilt as a family descendant.
    assert non_account_keys(table, singles + [unit], "account") == {"family:amount": ["card", "customer"]}


@pytest.mark.parametrize("recipe,key,share", [
    ("prev(amount; key=customer)", "customer", 1.0),
    ("prev(amount; key=card)", "card", 1.0),
    ("prev(amount; key=account)", "account", .25),
    ("prev(amount)", "", .25),
])
def test_estimate_uses_full_history_share_for_non_account_families(
        recipes, recipe, key, share, tmp_path, monkeypatch, capsys):
    import nf_importance

    table = pd.DataFrame([
        {"name": "previous", "recipe": recipe,
         "source_columns": ";".join(name for name in ("amount", key) if name)},
    ])
    unit = family(table, ["previous"])
    config = tmp_path / "config.yaml"
    config.write_text("eval:\n  file_start: 8228\n  file_end: 8243\ndata:\n  account_col: account\n")
    # main() reads the designated RANK-A range from settings(), so the stub supplies one.
    rank_a = {"importance": {"population": "rank_a"}, "populations": {
        "rank_a": {"files": [8228, 8243], "targets": ["2025-06-01", "2025-07-01"]}}}
    monkeypatch.setattr(nf_importance, "_shared",
                        lambda: (SimpleNamespace(STOP=3, settings=lambda: rank_a), object()))
    monkeypatch.setattr(nf_importance, "_plan", lambda cfg, args, layout: ([unit], table))
    rc = nf_importance.main([
        "estimate", "--config", str(config), "--checkpoint", "unused.pt",
        "--account-share", ".25", "--rank-a-rows", "10000",
        "--seconds-per-row", ".02", "--repeats", "3",
    ])
    captured = capsys.readouterr()
    assert rc == 0 and captured.err == ""
    cost = json.loads(captured.out[captured.out.index("{"):])
    assert cost["scoring_passes"] == 4
    assert cost["estimated_selected_rows"] == 10000 * share
    assert cost["gpu_hours"] == pytest.approx(4 * 10000 * share * .02 / 3600)
    if share == 1.0:
        assert "account share 1.0 (was 0.25)" in captured.out
        assert f"family:amount ({key})" in captured.out
    else:
        assert "account share 1.0" not in captured.out
