"""Helpers for the field-check tests: load the tools by path, and run the synthetic world once.

Synthetic data only; no bank data and no network.
"""

import functools
import importlib.util
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
NF = ROOT / "fraud" / "experiments" / "features" / "new_fields"


def load(name: str):
    """A module from the new-fields folder, by path (cached)."""
    if name in sys.modules and getattr(sys.modules[name], "__file__", "").startswith(str(NF)):
        return sys.modules[name]
    for p in (str(NF), str(ROOT / "src"), str(ROOT)):
        if p not in sys.path:
            sys.path.insert(0, p)
    spec = importlib.util.spec_from_file_location(name, NF / f"{name}.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


@functools.lru_cache(maxsize=1)
def dry_world():
    """Builds the synthetic world and runs every check on it once per test session."""
    F = load("nf_field_checks")
    folder = Path(tempfile.mkdtemp(prefix="nf_checks_test_"))
    out = folder / "out"
    lines = []
    a = F.build_args(["--dry-run", "--out", str(out)])
    rc = F.dry_run(a, folder=folder, log=lines.append)
    return {"rc": rc, "folder": folder, "out": out, "log": lines, "args": a}
