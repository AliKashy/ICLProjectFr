"""Checks across lanes: the planner's calls match the other lanes' tools, the three metric engines agree, and the
importance tools rebuild a recipe family with the shared recipe engine. Synthetic data only, no network."""
import shlex
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[4]
NF = ROOT / "fraud" / "experiments" / "features" / "new_fields"
for p in (str(ROOT / "src"), str(ROOT), str(NF)):
    if p in sys.path:
        sys.path.remove(p)
    sys.path.insert(0, p)

import nf_downstream  # noqa: E402
import nf_importance_metrics as IM  # noqa: E402
import nf_plan  # noqa: E402
import nf_ranked as RK  # noqa: E402
import nf_read  # noqa: E402
import nf_recipes  # noqa: E402
from nf_importance_units import build_units, make_recompute  # noqa: E402


def test_planner_downstream_command_parses_with_the_downstream_tool(tmp_path, monkeypatch):
    monkeypatch.setenv("NF_OUT", str(tmp_path / "c2"))
    fit = tmp_path / "models" / "nf_a1" / "seed42"
    e = {"tag": "nf_a1_seed42", "dir": fit, "config": fit / "resolved_train_v2.yaml", "ckpt": fit / "best.ckpt"}
    j = nf_plan.downstream_job(e, SimpleNamespace(failed_optional=set()))
    assert Path(j["cmd"][1]).name == "nf_downstream.py"
    args = nf_downstream.parser().parse_args(j["cmd"][2:])
    assert (args.cmd, args.name) == ("run", "nf_a1_seed42"), shlex.join(j["cmd"])
    assert Path(args.run_dir).name == "seed42"
    done = Path(tmp_path / "c2" / "downstream" / "nf_a1_seed42" / "summary.json")
    done.parent.mkdir(parents=True)
    done.write_text("{}")
    assert nf_plan.downstream_job(e, SimpleNamespace(failed_optional=set())) is None


def test_prune_reads_the_importance_lane_columns(tmp_path):
    # reading B (D4b): the upper ends nf_importance.py writes, drop_<m>_ci_high
    imp = tmp_path / "importance.csv"
    imp.write_text("unit,members,kind,method,drop_udr_ci_high,drop_ap_ci_high\n"
                   "cluster:c1,f_a;f_b,cluster,single_output_possibly_inconsistent,0.01,0.002\n"
                   "f_a,f_a,single,single_output_possibly_inconsistent,-0.001,-0.001\n"
                   "cluster:c2,f_c;f_d,cluster,single_output_possibly_inconsistent,-0.001,-0.001\n"
                   "f_e,f_e,single,single_output_possibly_inconsistent,-0.001,0.0\n"
                   "family:src,f_g;f_h,family,family,-1,-1\n"
                   "f_k,f_k,single,single_output_possibly_inconsistent,0.002,-0.001\n")
    assert nf_plan.prune_list(imp, None) == ["f_c", "f_d", "f_e"]


def test_reader_picks_the_base_raw_arm_of_the_downstream_tool(tmp_path, monkeypatch):
    monkeypatch.setenv("NF_OUT", str(tmp_path / "c2"))
    for arm in ("base_raw", "own_raw"):
        p = tmp_path / "c2" / "downstream" / "nf_a1_seed42" / arm / "fit" / "predictions.parquet"
        p.parent.mkdir(parents=True)
        p.write_bytes(b"x")
    got = nf_read.downstream_predictions(SimpleNamespace(downstream="", run="nf_a1_seed42"))
    assert got.as_posix().endswith("nf_a1_seed42/base_raw/fit/predictions.parquet")


def _world(n, decimals, seed):
    rng = np.random.default_rng(seed)
    acc = rng.integers(0, max(3, n // 7), n).astype(str)
    ids = np.arange(n)
    y = (rng.random(n) < 0.08).astype(int)
    s = rng.random(n)
    if decimals is not None:
        s = np.round(s, decimals)
    return acc, ids, y, s, rng.gamma(2, 50, n)


def test_the_three_metric_engines_agree():
    for n, dec in [(400, None), (1500, 2), (1500, 1), (166, None), (167, None), (2000, 0)]:
        acc, ids, y, s, amt = _world(n, dec, n)
        codes, units = RK.account_units(acc)
        reader = RK.RankedScore(s, y, codes, RK.key_ranks(RK.identity_keys(acc, ids)), amounts=amt)
        frame = pd.DataFrame(dict(account=acc, id=ids, label=y, amount=amt))
        imp = IM.point_metrics(frame, s, outsort="0.006")
        gpu = nf_downstream.Ranked(y, s, nf_downstream.key_ranks(pd.DataFrame(
            {nf_downstream.ID: ids, nf_downstream.ACCOUNT: acc, nf_downstream.LABEL: y})))
        r = reader.evaluate()
        for k in ("udr", "vdr", "fpr", "ap"):
            a, b = float(r[k]), float(imp[k])
            assert (np.isnan(a) and np.isnan(b)) or abs(a - b) < 1e-12, (n, dec, k, a, b)
        assert abs(gpu.udr() - r["udr"]) < 1e-12 and abs(gpu.ap() - r["ap"]) < 1e-12
        draws_r = np.asarray(RK.draw_matrix(len(units), 5, 20261102))
        draws_i = np.stack(list(IM.multiplicity_draws(len(units), 5, 20261102)))
        assert np.array_equal(draws_r, draws_i)
        for w_row, mult in zip(nf_downstream.account_draws(acc, 5, 20261102), draws_r):
            assert np.array_equal(w_row, mult[codes])
            rb = reader.evaluate(mult)
            assert (np.isnan(rb["udr"]) and np.isnan(gpu.udr(w_row))) or abs(gpu.udr(w_row) - rb["udr"]) < 1e-12


def test_family_rebuild_with_the_shared_recipe_engine():
    rng = np.random.default_rng(1)
    n = 60
    t = pd.Timestamp("2025-05-02") + pd.to_timedelta(np.sort(rng.integers(0, 20 * 86400, n)), unit="s")
    raw = pd.DataFrame({"Nmap_account_reference_xid": rng.choice(["a1", "a2", "a3"], n), "transaction_dttm": t,
                        "fi_transaction_id": np.arange(n).astype(str),
                        "transaction_amt": rng.gamma(2, 40, n).round(2),
                        "total_available_balance_amt": rng.gamma(3, 300, n).round(2), "frd_tag": 0})
    fm = pd.DataFrame([
        dict(name="transaction_amt", recipe="raw", source_columns="transaction_amt", model_type="continuous"),
        dict(name="total_available_balance_amt", recipe="raw", source_columns="total_available_balance_amt",
             model_type="continuous"),
        dict(name="amt_to_balance", recipe="ratio(transaction_amt; total_available_balance_amt)",
             source_columns="transaction_amt;total_available_balance_amt", model_type="continuous"),
        dict(name="amt_sum_24h", recipe="sum(24h; value=transaction_amt)", source_columns="transaction_amt",
             model_type="continuous"),
    ])
    scored = nf_recipes.build_fields(raw, fm, extract_start="2025-05-01")   # the frame as the scorer holds it
    names = ["transaction_amt", "total_available_balance_amt", "amt_to_balance", "amt_sum_24h"]
    fam = [u for u in build_units(names, field_map=fm, unit_specs=[
        dict(name="family:transaction_amt", method="family", source_columns="transaction_amt")])
        if u.method == "family"][0]
    assert set(fam.dependent_outputs) == nf_recipes.dependency_closure(fm, ["transaction_amt"])["outputs"]
    perturbed = scored.copy()
    perturbed["transaction_amt"] = perturbed["transaction_amt"].sample(frac=1, random_state=0).to_numpy()
    got = make_recompute(fm, "Nmap_account_reference_xid", "transaction_dttm", "2025-05-01")(perturbed, fam)
    fresh = nf_recipes.build_fields(perturbed.drop(columns=list(fam.dependent_outputs)), fm,
                                    extract_start="2025-05-01")
    for c in fam.dependent_outputs:
        assert np.allclose(got[c].astype(float), fresh[c].astype(float), equal_nan=True), c
        assert not np.allclose(got[c].astype(float), scored[c].astype(float), equal_nan=True), c
