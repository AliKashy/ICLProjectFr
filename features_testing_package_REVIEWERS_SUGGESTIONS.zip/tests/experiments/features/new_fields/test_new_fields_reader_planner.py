"""The reader as the planner calls it: JSON run tables, --out, --rule, the rank check's decide_on, the SELECT
check's PASS/FAIL decision, the lift found under the downstream folder, the Test 1 report; and design review items
15 (environment of control and candidate) and 21 (kept controls need the guard's stage 1 results)."""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import pytest
import yaml

from new_fields_reader_world import World, scores, write_spread, ID, ACCT, LABEL

STOP, REFUSED = 3, 4


@pytest.fixture
def world(tmp_path, monkeypatch):
    return World(tmp_path, monkeypatch, accounts=500)


def _json_table(w, name, rows, step="A1", pop="rank_b"):
    """The planner's run table: no run name, predictions named <tag>__<population>.parquet."""
    out = []
    for r in rows:
        src = Path(r["predictions"])
        tag = f"{r['run']}_seed{r['seed']}"
        dst = src.with_name(f"{tag}__{pop}.parquet")
        src.rename(dst)
        Path(f"{src}.json").rename(f"{dst}.json")
        Path(f"{src}.exposure.json").rename(f"{dst}.exposure.json")
        out.append({"role": r["role"], "seed": r["seed"], "run_dir": r["run_dir"],
                    "checkpoint": str(Path(r["run_dir"]) / "best.ckpt"), "predictions": str(dst),
                    "receipt": f"{dst}.json", "checkpoint_sha256": None, "predictions_sha256": None})
    p = w.c2 / "reads" / f"{name}.runs.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({"step": step, "population": pop, "runs": out}))
    return str(p)


def _pair_rows(w, cand_signal=6.0, ctrl_signal=0.5, pop="rank_b"):
    raw = w.raw[pop][0]
    c = dict(w.fit(pop, "nf_a1", 42, scores(raw, cand_signal, 1)), role="candidate")
    k = dict(w.fit(pop, "control", 42, scores(raw, ctrl_signal, 2)), role="control")
    return [c, k]


def test_planner_json_table_out_and_rule(world):
    write_spread(world.c2, "rank_b", 0.001)
    t = _json_table(world, "A1_1seed", _pair_rows(world))
    out = world.c2 / "reads" / "A1_1seed.json"
    assert world.run("read", "--step", "A1", "--population", "rank_b", "--run-table", t, "--out", out,
                     "--rule", "add") == 0
    rec = json.loads(out.read_text())
    assert rec["decision"].upper() == "ADOPT (PENDING THE SELECT CHECK)"  # the planner's classify reads this
    assert out.with_suffix(".txt").is_file()
    assert "nf_a1_seed42" in out.with_suffix(".txt").read_text()


def test_rule_month_maps_to_the_month_rule(world):
    write_spread(world.c2, "rank_b", 0.001)
    t = _json_table(world, "B_1seed", _pair_rows(world, 0.5, 4.0), step="B")
    assert world.run("read", "--step", "B", "--population", "rank_b", "--run-table", t, "--rule", "month") == 0
    assert world.saved("B_1seed.json")["rule_decision"] == "KEEP MONTH"


def test_rank_check_decide_on_wins_over_the_overall_result(world, capsys):
    (world.c2 / "reads" / "rank_check.json").write_text(json.dumps(
        {"result": "FAIL", "decide_on": "rank_b",
         "populations": {"rank_a": {"result": "FAIL"}, "rank_b": {"result": "PASS"}}}))
    write_spread(world.c2, "rank_b", 0.001)
    t = _json_table(world, "A1_1seed", _pair_rows(world))
    assert world.run("read", "--step", "A1", "--population", "rank_b", "--run-table", t) == 0
    (world.c2 / "reads" / "A1_1seed.json").unlink()
    (world.c2 / "reads" / "rank_check.json").write_text(json.dumps(
        {"populations": {"rank_b": {"result": "FAIL"}}, "result": "FAIL", "decide_on": "select_june"}))
    assert world.run("read", "--step", "A1", "--population", "rank_b", "--run-table", t) == REFUSED
    assert "not the decision population select_june" in capsys.readouterr().out


def test_select_check_writes_pass_or_fail_first(world):
    write_spread(world.c2, "rank_b", 0.001)
    t = _json_table(world, "A1_1seed", _pair_rows(world))
    assert world.run("read", "--step", "A1", "--population", "rank_b", "--run-table", t) == 0
    ts = _json_table(world, "A1_select", _pair_rows(world, 4.0, 1.0, pop="select"), pop="select")
    out = world.c2 / "reads" / "A1_select.json"
    assert world.run("select-check", "--step", "A1", "--population", "select_june", "--run-table", ts,
                     "--out", out) == 0
    rec = json.loads(out.read_text())
    assert rec["decision"] == "PASS: ADOPT" and rec["final_decision"] == "ADOPT"


def test_report_test1_is_report_only(world):
    raw = world.raw["test1"][0]
    rows = [dict(world.fit("test1", "nf_a1", 42, scores(raw, 3.0, 1)), role="report"),
            dict(world.fit("test1", "control", 42, scores(raw, 1.0, 2)), role="report")]
    t = _json_table(world, "test1_report", rows, step="test1", pop="test1")
    out = world.c2 / "reads" / "test1_report.txt"
    assert world.run("report", "--population", "test1", "--run-table", t, "--out", out) == 0
    text = out.read_text()
    assert "reported only. It never decides" in text and "nf_a1_seed42" in text
    assert json.loads(out.with_suffix(".json").read_text())["decides"] is False
    assert len(text.rstrip("\n").split("\n")) <= 40


def test_lift_from_the_planner_run_table_finds_the_downstream_predictions(world):
    raw = world.raw["select"][0]
    for tag, sig in (("nf_a1_seed42", 3.0), ("control_seed42", 3.0)):
        d = world.c2 / "downstream" / tag / "ds_select"
        d.mkdir(parents=True)
        pd.DataFrame({ID: raw[ID], ACCT: raw[ACCT], LABEL: raw[LABEL], "depth": 2,
                      "raw": scores(raw, 1.0, 1), "raw_embedding": scores(raw, sig, 2)}).to_parquet(
            d / "predictions.parquet")
    p = world.c2 / "reads" / "A1_lift.runs.json"
    p.write_text(json.dumps({"step": "A1", "population": "ds_select", "runs": [
        {"role": "candidate", "seed": 42, "run_dir": "x", "checkpoint": "x",
         "predictions": str(world.c2 / "scores" / "nf_a1_seed42__ds_select.parquet"), "receipt": ""},
        {"role": "control", "seed": 42, "run_dir": "x", "checkpoint": "x",
         "predictions": str(world.c2 / "scores" / "control_seed42__ds_select.parquet"), "receipt": ""}]}))
    out = world.c2 / "reads" / "A1_lift.json"
    assert world.run("lift", "--step", "A1", "--population", "ds_select", "--run-table", p, "--out", out,
                     "--fraud-rule", "pass") == 0
    rec = json.loads(out.read_text())
    assert rec["lift"]["udr"]["difference"] == pytest.approx(0.0) and not rec["flag"]


# ------------------------------------------------------------------ review items 15 and 21

def _manifest(run_dir, **env):
    Path(run_dir, "run_manifest_v2.json").write_text(json.dumps({"status": "finished", "start": dict(env)}))


def test_control_on_another_torch_or_gpu_is_not_a_valid_control(world, capsys):
    write_spread(world.c2, "rank_b", 0.001)
    rows = _pair_rows(world)
    _manifest(rows[0]["run_dir"], torch="2.5.1", lightning="2.4.0", gpu="H200")
    _manifest(rows[1]["run_dir"], torch="2.3.0", lightning="2.4.0", gpu="H200")
    t = _json_table(world, "A1_1seed", rows)
    assert world.run("read", "--step", "A1", "--run-table", t) == STOP
    assert "not a valid control" in capsys.readouterr().out


def test_equal_environments_pass_and_unknown_ones_are_listed(world):
    write_spread(world.c2, "rank_b", 0.001)
    rows = _pair_rows(world)
    for r in rows:
        _manifest(r["run_dir"], torch="2.5.1", lightning="2.4.0")
    t = _json_table(world, "A1_1seed", rows)
    assert world.run("read", "--step", "A1", "--run-table", t) == 0
    rec = world.saved("A1_1seed.json")
    assert rec["environment"]["unknown"] == ["cuda", "gpu"]
    assert "not recorded: cuda, gpu" in world.text("A1_1seed.txt")


def test_kept_checkpoints_are_never_controls(tmp_path, monkeypatch, capsys):
    """The reviewers' decision D5b: the kept seed 43 and 44 checkpoints are never controls, even with stage 1's
    results all passed (design review item 21 asked for the guard; the decision goes further)."""
    w = World(tmp_path, monkeypatch, accounts=400)
    kept_dir = w.tmp / "kept"
    (w.set_dir / "UPSTREAM.yaml").write_text(yaml.safe_dump({"kept": {"dir": str(kept_dir)}}))
    raw = w.raw["rank_b"][0]
    write_spread(w.c2, "rank_b", 0.001)
    from new_fields_reader_world import write_fit, POPS
    base = w.raw["rank_b"][1]
    cands = [dict(w.fit("rank_b", "nf_a1", s, scores(raw, 6.0, s)), role="candidate") for s in (42, 43, 44)]
    ctrls = [dict(w.fit("rank_b", "control", 42, scores(raw, 0.5, 1)), role="control")]
    ctrls += [dict(write_fit(kept_dir, "seed", s, raw, scores(raw, 0.5, s), POPS["rank_b"], base), role="control")
              for s in (43, 44)]
    t = _json_table(w, "A1_3seed", cands + ctrls)
    g = w.c2 / "guard" / "guard.jsonl"
    g.parent.mkdir(parents=True, exist_ok=True)
    g.write_text(json.dumps({"utc": "2026-11-02T00:00:00Z", "stage1_ok": True, "stage1_results": {}}) + "\n")
    assert w.run("read", "--step", "A1", "--run-table", t) == REFUSED
    assert "never controls" in capsys.readouterr().out


def test_lift_checks_the_downstream_sha256_the_job_recorded(world):
    """Integration (review item 18): the planner's lift run table carries the DS_SELECT predictions and the sha256
    the downstream job recorded; a file that changed since then stops the read."""
    import hashlib
    raw = world.raw["select"][0]
    rows = []
    for role, tag in (("candidate", "nf_a1_seed42"), ("control", "control_seed42")):
        d = world.c2 / "downstream" / tag / "base_raw" / "fit"
        d.mkdir(parents=True)
        f = d / "predictions.parquet"
        pd.DataFrame({ID: raw[ID], ACCT: raw[ACCT], LABEL: raw[LABEL], "raw": scores(raw, 1.0, 1),
                      "raw_embedding": scores(raw, 3.0, 2)}).to_parquet(f)
        rows.append({"role": role, "seed": 42, "run_dir": "x", "checkpoint": "x", "predictions": str(f),
                     "receipt": "", "downstream": str(f),
                     "downstream_sha256": hashlib.sha256(f.read_bytes()).hexdigest()})
    p = world.c2 / "reads" / "A1_lift.runs.json"
    p.write_text(json.dumps({"step": "A1", "population": "ds_select", "runs": rows}))
    out = world.c2 / "reads" / "A1_lift.json"
    assert world.run("lift", "--step", "A1", "--population", "ds_select", "--run-table", p, "--out", out,
                     "--fraud-rule", "pass") == 0
    assert json.loads(out.read_text())["inputs"]["fit_sha256"] == rows[0]["downstream_sha256"]
    out.unlink()
    rows[1]["downstream_sha256"] = "0" * 64
    p.write_text(json.dumps({"step": "A1", "population": "ds_select", "runs": rows}))
    assert world.run("lift", "--step", "A1", "--population", "ds_select", "--run-table", p, "--out", out,
                     "--fraud-rule", "pass") == 3
