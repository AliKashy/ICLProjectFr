"""Source donors stay consistent before histories reuse the same transaction."""
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import pytest
from pandas.testing import assert_frame_equal

sys.path.insert(0, str(Path(__file__).resolve().parents[4] / "fraud/experiments/features/new_fields"))
from nf_permutation import Unit, perturb_frame, select_accounts


def world():
    return pd.DataFrame({
        "account": np.repeat(["a", "b", "c", "d"], 3),
        "id": list(range(12)),
        "time": pd.date_range("2025-06-01", periods=12, freq="s"),
        "label": [0, 1, 0] * 4,
        "amount": np.arange(12, dtype=float),
        "twin": np.arange(12, dtype=float) * 2,
        "profile": pd.array(np.repeat([1, 2, 3, None], 3), dtype="Int64"),
        "code": pd.Categorical(["red", "blue", None] * 4),
        "month": [6] * 12,
    }, index=np.arange(100, 112))


def run(frame, unit, **kwargs):
    options = dict(seed=9, repeat=0, file_key="part_8228", account_col="account",
                   id_col="id", time_col="time", label_col="label")
    options.update(kwargs)
    return perturb_frame(frame, unit, **options)


def test_joint_source_substitution_keeps_twins_and_original():
    frame = world()
    original = frame.copy(deep=True)
    unit = Unit("twins", ["amount", "twin"], kind="cluster", method="source")
    changed, audit = run(frame, unit)
    assert_frame_equal(frame, original)
    assert changed.amount.tolist() != frame.amount.tolist()
    np.testing.assert_equal(changed.twin.to_numpy(), 2 * changed.amount.to_numpy())
    assert_frame_equal(changed.drop(columns=["amount", "twin"]), frame.drop(columns=["amount", "twin"]))
    assert audit["changed_source_rows"] > 0
    assert audit["method"] == "source"


def test_mapping_does_not_depend_on_row_order_and_repeats_are_repeatable():
    frame = world()
    unit = Unit("amount", ["amount"], method="source")
    changed, audit = run(frame, unit)
    reordered, other = run(frame.sample(frac=1, random_state=5), unit)
    assert_frame_equal(changed.sort_values("id"), reordered.sort_values("id"))
    assert audit["donor_mapping_sha256"] == other["donor_mapping_sha256"]
    assert_frame_equal(changed, run(frame, unit)[0])
    assert run(frame, unit, repeat=1)[1]["donor_mapping_sha256"] != audit["donor_mapping_sha256"]
    assert run(frame, unit, file_key="part_8229")[1]["donor_mapping_sha256"] != audit["donor_mapping_sha256"]


def test_same_source_event_reused_as_target_and_history_has_one_value():
    frame = world()
    changed, _ = run(frame, Unit("amount", ["amount"], method="source"))
    # Overlapping windows are rebuilt from the one perturbed source dataframe.
    windows = [changed.iloc[max(0, i - 2):i + 1] for i in range(len(changed))]
    seen = {}
    for window in windows:
        for row in window.itertuples():
            key = (row.account, row.id)
            if key in seen:
                assert seen[key] == row.amount
            seen[key] = row.amount
    assert len(seen) == len(frame)


def test_identity_is_exact_including_nullable_categorical_and_index():
    frame = world()
    unit = Unit("all", ["amount", "code", "profile"], method="source")
    changed, audit = run(frame, unit, identity=True)
    assert_frame_equal(frame, changed, check_exact=True)
    assert audit["changed_source_rows"] == 0
    assert audit["identity"]


def test_categorical_missing_and_nullable_types_survive():
    frame = world()
    changed, _ = run(frame, Unit("types", ["code", "profile"], method="source"))
    assert changed.code.dtype == frame.code.dtype
    assert changed.profile.dtype == frame.profile.dtype
    assert changed.code.isna().sum() == frame.code.isna().sum()
    assert changed.profile.isna().sum() == frame.profile.isna().sum()


def test_account_donors_preserve_a_profile_for_all_its_events():
    frame = world()
    unit = Unit("profile", ["profile"], method="source", donor_unit="account")
    changed, audit = run(frame, unit)
    assert (changed.groupby("account").profile.nunique(dropna=False) == 1).all()
    assert sorted(changed.groupby("account").profile.first().dropna()) == [1, 2, 3]
    assert audit["donor_unit"] == "account"
    shuffled, other = run(frame.sample(frac=1, random_state=13), unit)
    assert_frame_equal(changed.sort_values("id"), shuffled.sort_values("id"))
    assert audit["donor_mapping_sha256"] == other["donor_mapping_sha256"]


def test_time_varying_profile_is_not_silently_mapped_by_event():
    with pytest.raises(ValueError, match="static profile"):
        run(world(), Unit("amount", ["amount"], method="source", donor_unit="account"))


def test_account_profiles_map_jointly_with_unequal_history_lengths():
    frame = world().drop(index=[101, 102, 105])
    frame["second_profile"] = frame.profile * 10
    unit = Unit("profile pair", ["profile", "second_profile"], method="source",
                donor_unit="account", kind="cluster")
    changed, _ = run(frame, unit)
    assert len(changed) == len(frame)
    assert changed.groupby("account").size().equals(frame.groupby("account").size())
    assert (changed.groupby("account").profile.nunique(dropna=False) == 1).all()
    assert changed.second_profile.equals(changed.profile * 10)


def test_family_recomputes_declared_descendants_once():
    frame = world()
    calls = []
    unit = Unit("amount family", ["amount", "twin"], method="family",
                source_columns=["amount"], dependent_outputs=["twin"])
    def recompute(changed, used_unit):
        calls.append(used_unit)
        changed["twin"] = 2 * changed.amount
        return changed
    changed, audit = run(frame, unit, recompute=recompute)
    assert calls == [unit]
    np.testing.assert_equal(changed.twin.to_numpy(), 2 * changed.amount.to_numpy())
    assert audit["dependent_outputs"] == ["twin"]
    identity, _ = run(frame, unit, recompute=recompute, identity=True)
    assert_frame_equal(frame, identity)
    assert len(calls) == 1


def test_single_output_preserves_raw_and_siblings_and_labels_method():
    frame = world()
    changed, audit = run(frame, Unit("twin sensitivity", ["twin"]))
    np.testing.assert_equal(changed.amount.to_numpy(), frame.amount.to_numpy())
    assert not (changed.twin == changed.amount * 2).all()
    assert audit["method"] == "single_output_possibly_inconsistent"


@pytest.mark.parametrize("column", ["account", "id", "time", "label"])
def test_immutable_columns_cannot_be_units(column):
    with pytest.raises(ValueError, match="immutable"):
        run(world(), Unit(column, [column], method="source"))


@pytest.mark.parametrize("damage", ["label", "time", "amount", "order", "extra", "remove"])
def test_family_cannot_modify_unrelated_columns_or_order(damage):
    frame = world()
    unit = Unit("profile family", ["profile", "twin"], method="family",
                source_columns=["profile"], dependent_outputs=["twin"])
    def bad(changed, _unit):
        if damage == "order":
            return changed.iloc[::-1]
        if damage == "extra":
            changed["surprise"] = 1
        elif damage == "remove":
            return changed.drop(columns="label")
        else:
            changed[damage] = 0
        return changed
    with pytest.raises(ValueError):
        run(frame, unit, recompute=bad)


def test_family_requires_a_recipe_callback_and_complete_output_list():
    with pytest.raises(ValueError, match="dependent_outputs"):
        Unit("family", ["amount"], method="family", source_columns=["amount"])
    unit = Unit("family", ["amount", "new"], method="family",
                source_columns=["amount"], dependent_outputs=["new"])
    with pytest.raises(ValueError, match="callback"):
        run(world(), unit)
    with pytest.raises(ValueError, match="omitted"):
        run(world(), unit, recompute=lambda frame, _: frame)
    changed, _ = run(world(), unit, recompute=lambda frame, _: frame.assign(new=frame.amount * 3))
    assert "new" in changed


def test_family_cannot_return_duplicate_columns():
    unit = Unit("family", ["amount", "twin"], method="family",
                source_columns=["amount"], dependent_outputs=["twin"])
    with pytest.raises(ValueError, match="duplicate columns"):
        run(world(), unit, recompute=lambda frame, _: pd.concat([frame, frame[["twin"]]], axis=1))


def test_empty_and_one_event_frames_preserve_identity_and_dtypes():
    for frame in [world().iloc[:0], world().iloc[:1]]:
        changed, audit = run(frame, Unit("amount", ["amount"], method="source"))
        assert_frame_equal(frame, changed, check_exact=True)
        assert audit["changed_source_rows"] == 0


def test_whole_account_sampling_is_repeatable_across_files_and_row_order():
    frame = pd.DataFrame({"account": np.repeat([f"a{i}" for i in range(100)], 7),
                          "history_row": np.tile(np.arange(7), 100)})
    chosen = select_accounts(frame, 0.25, "account")
    assert 0 < len(chosen) < len(frame)
    assert (chosen.groupby("account").size() == 7).all()
    parts = pd.concat([select_accounts(frame.iloc[:211], 0.25, "account"),
                       select_accounts(frame.iloc[211:], 0.25, "account")])
    assert_frame_equal(chosen, parts)
    shuffled = select_accounts(frame.sample(frac=1, random_state=1), 0.25, "account")
    assert_frame_equal(chosen.sort_index(), shuffled.sort_index())
    assert_frame_equal(frame, select_accounts(frame, 1.0, "account"))


@pytest.mark.parametrize("share", [0, -1, 1.01, float("nan")])
def test_bad_account_share_rejected(share):
    with pytest.raises(ValueError, match="share"):
        select_accounts(world(), share, "account")


def test_calendar_perturbation_is_marked_artificial_with_time_fixed():
    frame = world()
    changed, audit = run(frame, Unit("month", ["month"]))
    assert audit["interpretation"] == "artificial_time_fixed"
    assert changed.time.equals(frame.time)


def test_duplicate_event_keys_are_rejected():
    frame = world()
    frame.loc[101, "id"] = 0
    with pytest.raises(ValueError, match="Duplicate account/event"):
        run(frame, Unit("amount", ["amount"], method="source"))
