"""Rules: thresholds lookup, the review's added rules, status scan, decisions and inheritance."""

import pandas as pd

from new_fields_checks_helpers import load

R = load("nf_checks_rules")
F = load("nf_field_checks")


def _rules(m, th=None):
    return {rule: res for res, rule, _ in R.evaluate(dict(m, measured=True), th or R.Thresholds({}))}


def test_thresholds_are_found_by_leaf_key_and_defaults_are_listed():
    th = R.Thresholds({"stop": {"control_val_ap": 0.2}, "flag": {"x": {"cluster_threshold": 0.7}}})
    assert th.num("control_val_ap") == 0.2 and th.num("cluster_threshold") == 0.7
    th.num("unk_june")
    assert "unk_june" in th.defaulted and "control_val_ap" not in th.defaulted


def test_known_future_date_is_not_stopped_but_a_reissue_is():
    m = {"date_nonnull": 100, "date_after": 100, "date_nonnull_fraud": 5, "date_after_fraud": 5,
         "future_by_meaning": True, "reissue_event": 2.0, "reissue_pseudo": 1.0}
    r = _rules(m)
    assert "date_after_txn" not in r and r["date_future_by_meaning"] == "FLAG"
    m["reissue_event"] = 60.0
    assert _rules(m)["reissue_change"] == "STOP"
    m["future_by_meaning"] = False
    assert _rules(m)["date_after_txn"] == "STOP"


def test_same_day_date_and_refresh_stop():
    assert _rules({"same_day_fraud": 0.30, "same_day_nonfraud": 0.01})["same_day_date"] == "STOP"
    assert "same_day_date" not in _rules({"same_day_fraud": 0.012, "same_day_nonfraud": 0.01})
    m = {"fraud_accounts_with_history": 100, "refresh_event": 80.0, "refresh_pseudo": 5.0}
    assert _rules(m)["same_day_refresh"] == "STOP"
    m["fraud_accounts_with_history"] = 5
    assert "same_day_refresh" not in _rules(m)


def test_change_at_event_waits_for_profile_fields_and_flags_others():
    m = {"fraud_accounts_with_history": 100, "change_at_event": 60.0, "change_at_pseudo": 5.0}
    assert _rules(m)["change_at_event"] == "FLAG"
    assert _rules(dict(m, is_profile=True))["profile_change_at_event"] == "WAIT"


def test_snapshot_and_pre_event_proxy():
    m = {"single_ap": 0.08, "constant_in_account": 97.0}
    r = _rules(m)
    assert r["strong_alone"] == "FLAG" and r["snapshot"] == "WAIT"
    n = {"pre_fraud_accounts": 100}
    assert _rules({**n, "pre_event_ap": 0.9, "pre_event_base": 0.04})["pre_event_proxy"] == "STOP"
    assert _rules({**n, "pre_fill_fraud": 0.5, "pre_fill_pseudo": 0.0})["pre_event_proxy"] == "STOP"
    assert "pre_event_proxy" not in _rules({**n, "pre_event_ap": 0.1, "pre_event_base": 0.04,
                                            "pre_fill_fraud": 0.5, "pre_fill_pseudo": 0.45})
    assert "pre_event_proxy" not in _rules({"pre_fraud_accounts": 5, "pre_event_ap": 0.9, "pre_event_base": 0.04})
    # the settings file's fill-gap form: a gap alone flags, a gap with a large ratio stops
    th = R.Thresholds({"pre_event_proxy_fill_points": 0.20})
    assert _rules({**n, "pre_fill_fraud": 0.40, "pre_fill_pseudo": 0.15}, th)["pre_event_fill_gap"] == "FLAG"
    assert _rules({**n, "pre_fill_fraud": 0.40, "pre_fill_pseudo": 0.01}, th)["pre_event_proxy"] == "STOP"


def test_worst_result_wins():
    assert R.worst([("FLAG", "a", ""), ("STOP", "b", ""), ("WAIT", "c", "")]) == "STOP"
    assert R.worst([]) == "PASS"


# ---- status name scan, decisions and the 26 October names (review items 7 and 10)
LEGIT = ["merchant_state_xcd", "cprsrvc__pisinfo_cardholder_postal_xcd", "tokenization_indicator",
         "user_indicator_7_xcd", "cprcust__authcsusploc_risky_ip_country_xcd", "cprsrvc__pisinfo_cardholder_country_xcd",
         "card_offln_static_authctn_xflg", "cprsrvc__dbt_travel_countrydate_cardholder_travel_curr_country",
         "cardholder_present_xflg"]
STATUS_LIKE = ["cprcust__onlinebankusernamechgdt_status", "inactv_dt", "cprcust__ebsloginblockdt",
               "cprcust__cardstatdt_card_status_nm3102", "cpracct__ddaewstxndata_hold_seg",
               "prior_action_db_expiration_dt", "cprsrvc__pisinfo2_status"]


def _specs(rows, rules=None, decisions=None, base=()):
    cols = load("nf_checks_synth").map_columns()
    fm = pd.DataFrame([{**{c: "" for c in cols}, "feasible_in_production": "yes", **r} for r in rows])
    th = R.Thresholds({})
    rules = rules or []
    return {s["name"]: s for s in F.field_specs(fm, list(base), th, rules, "acct", decisions)}


def test_status_scan_spares_the_legitimate_fields_and_marks_status_names():
    sp = _specs([{"name": n, "recipe": "raw"} for n in LEGIT + STATUS_LIKE])
    for n in LEGIT:
        assert "status" not in sp[n]["flags"], n
    for n in STATUS_LIKE:
        assert sp[n]["flags"].get("status"), n


def test_status_rules_file_allow_list_and_precedence(tmp_path):
    p = tmp_path / "STATUS_RULES.csv"
    pd.DataFrame([{"rule": "left_out_26oct", "name": "INACTV_DT", "pattern": "", "reason": ""},
                  {"rule": "rank52", "name": "cprcust__onlinebankpwstatuschgdt", "pattern": "", "reason": ""},
                  {"rule": "status_like", "name": "", "pattern": "status", "reason": ""},
                  {"rule": "allow", "name": "syn_status_ok", "pattern": "", "reason": "not a status"}]).to_csv(p, index=False)
    rules = F.read_status_rules(p)
    sp = _specs([{"name": "x_days", "recipe": "days_before(inactv_dt)", "source_columns": "inactv_dt"},
                 {"name": "pw_days", "recipe": "days_before(cprcust__onlinebankpwstatuschgdt)",
                  "source_columns": "cprcust__onlinebankpwstatuschgdt"},
                 {"name": "syn_status_ok", "recipe": "raw"},
                 {"name": "other_status", "recipe": "raw", "tfm_name": "INACTV_DT"}], rules)
    assert sp["x_days"]["flags"].get("left_out_26oct")           # names on a recipe's source, any case
    assert sp["other_status"]["flags"].get("left_out_26oct")     # the TFM name counts too
    assert not sp["pw_days"]["flags"].get("status")              # rank 52 stays in
    assert not sp["syn_status_ok"]["flags"].get("status")        # allow list


def test_a_written_clearance_lifts_a_name_scan_wait():
    dec = {"merchant_status_code": {"verdict": "keep", "decided_by": "data owner", "date": "2026-11-02"}}
    sp = _specs([{"name": "merchant_status_code", "recipe": "raw"}], decisions=dec)
    assert "status" not in sp["merchant_status_code"]["flags"]
    assert sp["merchant_status_code"]["flags"]["status_cleared"].startswith("status mark cleared in writing by data owner")


def test_same_transaction_decisions_stop_raw_and_wait_lagged():
    sp = _specs([{"name": "falcondecline_indicator", "recipe": "raw"},
                 {"name": "prev_falcon", "recipe": "prev(falcondecline_indicator)",
                  "source_columns": "falcondecline_indicator"},
                 {"name": "prev_falcon_fixed", "recipe": "prev(falcondecline_indicator)",
                  "source_columns": "falcondecline_indicator", "data_owner_fixed": "yes, name, 2026-11-02"}])
    assert "same_txn_decision" in _rules(sp["falcondecline_indicator"]["flags"])
    assert _rules(sp["prev_falcon"]["flags"])["lagged_decision"] == "WAIT"
    assert _rules(sp["prev_falcon_fixed"]["flags"])["lagged_decision"] == "FLAG"


def test_known_future_date_meaning_from_the_map_column():
    sp = _specs([{"name": "exp_days", "recipe": "days_until(card_expiration_dt)", "date_meaning": "known_future_date"},
                 {"name": "evt_days", "recipe": "days_before(card_expiration_dt)", "date_meaning": "event_date"}])
    assert sp["exp_days"]["future_by_meaning"] and not sp["evt_days"]["future_by_meaning"]


def test_month_statement_holds_the_field_and_month_stays():
    """The reviewers' decision D3d: a field that repeats month or tracks time is held until the reviewers record
    keep or drop and the reason; month stays and leaves only through the month-out step; the screen's view is
    information."""
    th = R.Thresholds({})
    rep = {"month_v_present_adj": 0.8, "month_nmi_present_adj": 0.6, "month_v_uncensored": 0.8,
           "month_nmi_uncensored": 0.6}
    t = R.month_statement("f", rep, th, True, {"v": 0.84, "nmi": 0.77}, "rho 0.95 for the A1 set (FLAG joint_clock)")
    assert t.startswith("f repeats month on its present values (V 0.80, NMI 0.60, ceiling V 0.84 NMI 0.77): it is "
                        "held until the reviewers record keep or drop and the reason in KEEP_DECISIONS.csv; month "
                        "stays")
    assert "owner" not in t and "in writing" not in t
    kept = R.month_statement("f", dict(rep, month_decision="keep", month_decided_by="reviewers 2026-11-03"), th, True)
    assert "kept by the reviewers' recorded decision (reviewers 2026-11-03); month stays" in kept
    assert "the screen's view: month adds nothing once the new fields are in (information)" in t
    assert "month leaves only through the month-out step" in t and "joint time check: rho 0.95" in t
    clock = R.month_statement("g", {"time_rho": 0.95, "month_v": 0.1, "month_nmi": 0.01}, th, None)
    assert "tracks time (rho 0.95)" in clock and "the screen's view: not given" in clock
    some = {"month_v_uncensored": 0.4, "month_nmi_uncensored": 0.05, "month_v_present_adj": 0.1,
            "month_nmi_present_adj": 0.01}
    assert "overlaps month (V 0.40" in R.month_statement("h", some, th, False)
    assert R.month_statement("k", {"month_v": 0.1, "month_nmi": 0.01}, th, False).startswith("month is not repeated by k")


def test_month_result_is_read_from_the_screen_file(tmp_path):
    p = tmp_path / "screen.json"
    p.write_text('{"month_on_top": {"time_split": {"delta": 0.001, "ci95": [-0.002, 0.004]}}}')
    assert F.month_result_from_screen(str(p)) is True
    p.write_text('{"month_on_top": {"time_split": {"delta": 0.01, "ci95": [0.004, 0.02]}}}')
    assert F.month_result_from_screen(str(p)) is False
    assert F.month_result_from_screen(str(tmp_path / "missing.json")) is None


def test_map_status_like_yields_to_rank52_allow_and_a_written_clearance(tmp_path):
    p = tmp_path / "STATUS_RULES.csv"
    pd.DataFrame([{"rule": "rank52", "pattern": "cprcust__onlinebankpwstatuschgdt", "match": "exact_ci"},
                  {"rule": "allow", "pattern": "merchant_status_ok", "match": "exact_ci"},
                  {"rule": "status_like", "pattern": "status", "match": "substring_ci"}]).to_csv(p, index=False)
    rules = F.read_status_rules(p)
    dec = {"other_status": {"verdict": "keep", "decided_by": "data owner", "date": "2026-11-02"}}
    sp = _specs([{"name": "cprcust__onlinebankpwstatuschgdt", "recipe": "raw", "status_rule": "status_like"},
                 {"name": "merchant_status_ok", "recipe": "raw", "status_rule": "status_like"},
                 {"name": "other_status", "recipe": "raw", "status_rule": "status_like"}], rules, dec)
    for n in sp:
        assert "status" not in sp[n]["flags"], n


def test_a_decision_read_through_any_current_row_recipe_stops():
    sp = _specs([{"name": "code_reason", "recipe": "code(processor_reason)", "source_columns": "processor_reason"},
                 {"name": "ratio_falcon", "recipe": "ratio(falcondecline_indicator; transaction_amt)",
                  "source_columns": "falcondecline_indicator;transaction_amt"}])
    for n in sp:
        assert "same_txn_decision" in _rules(sp[n]["flags"]), n


def test_history_parity_reads_the_recipe_engines_lookback():
    """Integration (part A, checked): the reach is the recipe engine's own. prev and since_last read 30 days
    unless within= says otherwise, so only within=all or a reach above 30 days gets history_parity."""
    sp = _specs([{"name": "p1", "recipe": "prev(transaction_amt)", "source_columns": "transaction_amt"},
                 {"name": "p2", "recipe": "since_last(minutes; within=30d)", "source_columns": "transaction_dttm"},
                 {"name": "p3", "recipe": "count(90d)", "source_columns": "transaction_dttm"},
                 {"name": "p4", "recipe": "count(24h)", "source_columns": "transaction_dttm"},
                 {"name": "p5", "recipe": "prev(transaction_amt; within=all)", "source_columns": "transaction_amt"},
                 {"name": "p6", "recipe": "since_last(days)", "source_columns": "transaction_dttm"},
                 {"name": "p7", "recipe": "since_first(days; same=merchant_category_xcd; within=90d)",
                  "source_columns": "merchant_category_xcd"}])
    for n in ("p3", "p5", "p7"):
        assert sp[n]["flags"].get("history_parity"), n
    for n in ("p1", "p2", "p4", "p6"):
        assert not sp[n]["flags"].get("history_parity"), n


def test_raw_date_stops():
    assert _rules({"raw_date": "a stored date"})["raw_date"] == "STOP"
