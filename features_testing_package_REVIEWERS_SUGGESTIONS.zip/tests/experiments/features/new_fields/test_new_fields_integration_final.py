"""Final integration: the field checks when a recipe's source column is missing from one file of a range (must-fix
b). The checks name the range, the file and the column (STOP missing_from_files) and do not build that field on any
file, instead of stopping with the recipe engine's error on the first file that lacks the column. A raw field
missing from a file is built as before (missing there) and gets the same STOP. The code is the review lane's fix
(Checks.needed_columns and presence); these tests also cover a source missing from one June file. Synthetic data
only."""
import functools
import sys
import tempfile
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from new_fields_checks_helpers import load  # noqa: E402

F = load("nf_field_checks")
S = load("nf_checks_synth")


def _drop(path: Path, column: str):
    df = pd.read_parquet(path)
    assert column in df.columns
    df.drop(columns=[column]).to_parquet(path, index=False)


@functools.lru_cache(maxsize=1)
def world():
    tmp = Path(tempfile.mkdtemp(prefix="nf_checks_missing_src_"))
    w = S.make_world(tmp, n_acct=150)
    # a recipe's source missing from the second training file, another's from the second June file
    _drop(Path(w["train_base"]) / f"part_{S.TRAIN_FILES[1]}.parquet", "syn_clean_date_src")
    _drop(Path(w["june_base"]) / f"part_{S.JUNE_FILES[1]}.parquet", "syn_expiry_src")
    a = F.build_args(["--dry-run", "--out", str(tmp / "out")])
    a.map, a.thresholds, a.status_rules = str(w["map"]), str(w["thresholds"]), str(w["status_rules"])
    a.decisions, a.predictors, a.config = str(tmp / "KEEP_DECISIONS.csv"), str(w["predictors"]), str(w["config"])
    a.train_base, a.val_base, a.june_base = w["train_base"], w["val_base"], w["june_base"]
    a.train_files, a.val_files, a.june_files = w["train_files"], w["val_files"], w["june_files"]
    a.fit_files, a.dup_files, a.confirm_file = w["fit_files"], w["dup_files"], w["confirm_file"]
    a.no_settings_ranges, a.min_free_gb, a.cred_path = True, 0.0, None
    a.sample_rows, a.probe_accounts = min(a.sample_rows, 30_000), min(a.probe_accounts, 60)
    log = []
    rc = F.run(a, extra_builders=S.dry_run_builders(w, True), log=log.append)
    out = tmp / "out"
    st = pd.read_csv(out / "field_status.csv", dtype=str, keep_default_na=False).set_index("field") \
        if (out / "field_status.csv").is_file() else None
    return {"rc": rc, "status": st, "log": log, "out": out}


def test_a_recipe_source_missing_from_one_training_file_is_a_stop_naming_the_file_not_a_crash():
    w = world()
    assert w["rc"] == 0, "\n".join(w["log"][-20:])
    r = w["status"].loc["syn_clean_days"]
    assert r["result"] == "STOP" and "missing_from_files" in r["reasons"], r["reasons"]
    assert f"train:{S.TRAIN_FILES[1]}:syn_clean_date_src" in r["reasons"]
    assert any(line.startswith("presence: not built") and "syn_clean_days" in line for line in w["log"])


def test_a_recipe_source_missing_from_one_june_file_is_a_stop_naming_the_file():
    # the June files are the Test 1 range of the presence check (--june-files)
    r = world()["status"].loc["syn_expiry"]
    assert r["result"] == "STOP" and f"test1:{S.JUNE_FILES[1]}:syn_expiry_src" in r["reasons"], r["reasons"]


def test_the_other_fields_are_still_checked_and_a_raw_field_missing_from_june_still_stops():
    st = world()["status"]
    assert st.loc["syn_missing_col", "result"] == "STOP" and "missing_from_files" in st.loc["syn_missing_col",
                                                                                              "reasons"]
    for name in ("syn_clean_num", "syn_clean_code", "syn_count_24h"):
        assert st.loc[name, "result"] == "PASS", (name, st.loc[name, "reasons"])
    fc = pd.read_csv(world()["out"] / "field_checks.csv", dtype=str, keep_default_na=False)
    assert set(fc.loc[fc["field"] == "syn_clean_num", "range"]) >= {"train", "fit", "val", "june"}
