"""Duplicates, recodes, many-to-one recodes, near duplicates and clusters."""

import numpy as np
import pandas as pd

from new_fields_checks_helpers import dry_world, load

M = load("nf_checks_measure")
F = load("nf_field_checks")


def test_fingerprints_separate_identical_recode_and_different():
    a = pd.Series(["x", "y", "x", None, "z"])
    renamed = a.copy()
    recode = a.map({"x": 7, "y": 8, "z": 9})
    other = pd.Series(["x", "x", "y", None, "z"])
    assert M.text_fingerprint(a) == M.text_fingerprint(renamed)
    assert M.recode_fingerprint(a)[0] == M.recode_fingerprint(recode)[0]
    assert M.text_fingerprint(a) != M.text_fingerprint(recode)
    assert M.recode_fingerprint(a)[0] != M.recode_fingerprint(other)[0]


def test_affine_copy_is_a_recode_and_correlates_fully():
    v = pd.Series(np.random.default_rng(0).integers(0, 50, 1000).astype(float))
    assert M.recode_fingerprint(v)[0] == M.recode_fingerprint(3 * v - 1)[0]
    assert M.pearson_pairwise(v.to_numpy(), (3 * v - 1).to_numpy()) > 0.9999


def test_all_distinct_columns_are_not_grouped_as_recodes():
    fps = {"id": {"recode": "h", "text": "t1", "card": 1000}, "num": {"recode": "h", "text": "t2", "card": 1000},
           "code": {"recode": "c", "text": "t3", "card": 5}, "code2": {"recode": "c", "text": "t4", "card": 5}}
    assert F._groups(fps, max_card=500) == [["code", "code2"]]


def test_cramers_v_and_distinct_pairs():
    a = np.array([0, 0, 1, 1, 2, 2])
    v, pairs = M.cramers_v_codes(a, a)
    assert abs(v - 1.0) < 1e-12 and pairs == 3
    v, _ = M.cramers_v_codes(np.array([0, 1] * 50), np.array([0] * 50 + [1] * 50))
    assert v < 0.05


def test_single_linkage_clusters_match_a_hand_result():
    names = ["a", "b", "c", "d", "e"]
    edges = [("a", "b"), ("b", "c"), ("d", "e")]
    assert M.single_linkage(names, edges) == [["a", "b", "c"], ["d", "e"]]


def test_world_duplicates_and_recodes():
    st = pd.read_csv(dry_world()["out"] / "field_status.csv", keep_default_na=False).set_index("field")
    assert "identical" in st.loc["syn_base_copy", "reasons"]
    assert "one-to-one recode" in st.loc["syn_base_recode", "reasons"]
    assert "label_copy" in st.loc["syn_label_recode", "reasons"]
    assert "duplicate_number" in st.loc["syn_affine_num", "reasons"]
    assert st.loc["syn_near_dup", "result"] == "FLAG" and "near_duplicate" in st.loc["syn_near_dup", "reasons"]
    assert "function_of" in st.loc["syn_coarse", "reasons"]       # many-to-one recode of a base code
    assert "refines" in st.loc["syn_fine", "reasons"]
    # random continuous fields are not "recodes" of the transaction id
    for n in ("syn_clean_num", "syn_june_shift", "syn_status_dt"):
        assert "duplicate" not in st.loc[n, "reasons"], n


def test_world_clusters_include_base_inputs_at_the_threshold():
    cl = pd.read_csv(dry_world()["out"] / "clusters.csv", keep_default_na=False)
    members = cl.groupby("cluster_id")["member"].apply(set).tolist()
    assert any({"syn_near_dup"} < m for m in members)
    near = next(m for m in members if "syn_near_dup" in m)
    assert any(x in near for x in ("transaction_amt",))
    assert (cl["max_link"].astype(float) >= 0.8).all()
    # stopped fields are not cluster members
    assert "syn_affine_num" not in set(cl["member"])


def test_external_score_is_compared_with_the_current_one():
    fc = pd.read_csv(dry_world()["out"] / "field_checks.csv", keep_default_na=False)
    row = fc[(fc["field"] == "syn_vaa") & (fc["range"] == "duplicates")].iloc[0]
    assert "external_1_scr" in row["external_vs_current"]
