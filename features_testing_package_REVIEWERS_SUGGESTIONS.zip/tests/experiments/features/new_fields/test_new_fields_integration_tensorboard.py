"""TensorBoard through the queue's wrapper (nf_fit.py): on by default, and training is the same with and without
it. Same weights, optimizer state, random number use, epoch and step, training_metrics.csv and manifest identity,
over two full epochs of the chosen trainer on a synthetic world. CPU only."""
import os
import sys
import warnings
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import new_fields_gpu_world as W  # noqa: E402
from test_new_fields_gpu_timing import _assert_same_run, _ckpt  # noqa: E402

pytestmark = pytest.mark.skipif(W.base_config_path() is None, reason="no chosen-model base config in this tree")


@pytest.fixture()
def world(tmp_path, monkeypatch):
    monkeypatch.setenv("CUDA_VISIBLE_DEVICES", "")
    old = {k: os.environ.get(k) for k in ("NF_OUT", "NF_SETTINGS_DIR")}
    w = W.build(tmp_path / "world")
    yield w
    for k, v in old.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v


def test_tensorboard_is_on_by_default():
    import nf_common as C
    import yaml
    s = yaml.safe_load((C.NF / "SETTINGS.yaml").read_text())
    assert s.get("tensorboard") is True


def test_training_is_the_same_with_and_without_tensorboard(world):
    pytest.importorskip("tensorboard")
    import nf_fit
    import nf_layout
    before = W.hashed_files()
    source_before = nf_layout.attr("trainer", "source_sha256")()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        plain = world["tmp"] / "plain"
        nf_layout.get("trainer").main(["--config", str(world["config"]), f"output.checkpoint_dir={plain}"])
        logged = world["tmp"] / "logged"
        rc = nf_fit.main(["--run", "nf_tb", "--config", str(world["config"]), "training.seed=42",
                          f"output.checkpoint_dir={logged}"])
    assert rc == 0
    tb = world["c2"] / "tb" / "nf_tb" / "seed42"
    events = list(tb.rglob("events.out.tfevents.*"))
    assert events, "the wrapper writes TensorBoard event files"
    # training_metrics.csv, weights, optimizer state, random state, steps and the manifest identity are equal
    import json
    plain_cfg = json.loads((plain / "run_manifest_v2.json").read_text())["start"]["identity"]
    logged_cfg = json.loads((logged / "run_manifest_v2.json").read_text())["start"]["identity"]
    assert plain_cfg == logged_cfg
    _assert_same_run(plain, logged)
    for name in ("best.ckpt", "last.ckpt"):
        assert set(_ckpt(plain / name)) == set(_ckpt(logged / name)), f"{name} holds other top-level keys"
    assert nf_layout.get("trainer").build_trainer.__name__ == "build_trainer"   # put back
    assert W.hashed_files() == before
    assert nf_layout.attr("trainer", "source_sha256")() == source_before
    # the TensorBoard scalars are the metrics the model logs
    from tensorboard.backend.event_processing.event_accumulator import EventAccumulator
    acc = EventAccumulator(str(events[0].parent))
    acc.Reload()
    assert any("loss" in t for t in acc.Tags()["scalars"])


def test_tensorboard_off_runs_the_trainer_plainly(world, monkeypatch, capsys):
    import nf_fit
    import yaml
    sdir = world["settings"]
    s = yaml.safe_load((sdir / "SETTINGS.yaml").read_text())
    s["tensorboard"] = False
    (sdir / "SETTINGS.yaml").write_text(yaml.safe_dump(s))
    out = world["tmp"] / "off"
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        rc = nf_fit.main(["--run", "nf_off", "--config", str(world["config"]), "training.max_epochs=1",
                          f"output.checkpoint_dir={out}"])
    assert rc == 0 and (out / "best.ckpt").is_file()
    assert not (world["c2"] / "tb" / "nf_off").exists()
