"""Censored rows must not give a clean windowed field a month FLAG (integration item j).

A small world: eight training months from the extract start, activity with no link to time, and six counts over
30 to 180 days (as seconds) built by the recipe engine. Each count is censored (missing) on the rows whose window
reaches before the extract start, so on all rows its missing share falls month by month.

- The month overlap table: the reviewers' decisions D3b and D3d already read the rows not censored, so no
  overlaps_month FLAG. The test keeps that.
- The joint time fit (D3d): it read every sampled row, and the censored rows' missing flags together dated each row
  (out-of-fold rho at least 0.9, FLAG joint_clock on every field of the set). It now leaves those rows out."""
import json
from types import SimpleNamespace

import numpy as np
import pandas as pd

from new_fields_checks_helpers import load

F = load("nf_field_checks")
M = load("nf_checks_measure")
R = load("nf_checks_rules")
import nf_recipes as RC  # noqa: E402

START = "2024-10-01"
DAYS = (30, 60, 90, 120, 150, 180)


def _world(n=60_000, accounts=3_000, seed=20261103):
    rng = np.random.default_rng(seed)
    start = np.datetime64(START + "T00:00:00")
    span = int((np.datetime64("2025-06-01T00:00:00") - start) / np.timedelta64(1, "s"))
    t = start + np.sort(rng.integers(0, span, size=n)).astype("timedelta64[s]")
    return pd.DataFrame({RC.ACCOUNT: rng.integers(0, accounts, size=n).astype(str), RC.TIME: t,
                         RC.TIE: np.arange(n).astype(str)})


def _specs():
    return [{"name": f"count_{d}d", "fn": "count", "recipe": f"count({d * 86_400}s)",
             "row": {"model_type": "continuous"},
             "model_type": "continuous", "flags": {}, "group": "v22b", "sources": [RC.TIME]} for d in DAYS]


def _checks(df, out):
    th = R.Thresholds({})
    fake = SimpleNamespace(builder=F.Builder(RC), acc=RC.ACCOUNT, tcol=RC.TIME, ycol="label", out=out,
                           th=th, log=lambda *_: None, refused_fields=set(),
                           a=SimpleNamespace(joint_rows=len(df), seed=7, train_extract_start=START, batch_fields=3))
    specs = _specs()
    fake.m = {s["name"]: {"result": "PASS"} for s in specs}
    fake.buildable = lambda: specs
    fake.batches = lambda sp: F.Checks.batches(fake, sp)
    fake.frame = lambda path, batch: df
    fake.meta = lambda frame, with_label=True: F.Checks.meta(fake, frame, with_label)
    fake.values = lambda s, frame, es: F.Checks.values(fake, s, frame, es)
    return fake


def test_the_month_overlap_reads_rows_not_censored_so_a_clean_windowed_count_passes():
    df = _world()
    fake = _checks(df, None)
    month = M.month_of(pd.to_datetime(df[RC.TIME]))
    for s in _specs():
        vals, cens = fake.values(s, df, START)
        assert cens.any() and not cens.all()
        keys = M.bin_keys(vals, "continuous", M.decile_edges(vals[~cens]))
        every = M.overlap_measures(M.contingency(keys, month, 100_000))
        unc = M.overlap_measures(M.contingency(keys[~cens], month[~cens], 100_000))
        present = ~cens & ~M.is_missing(vals)
        adj = M.overlap_adjusted(M.contingency(keys[present], month[present], 100_000))
        m = {"month_v": every["cramers_v"], "month_nmi": every["nmi"], "month_v_uncensored": unc["cramers_v"],
             "month_nmi_uncensored": unc["nmi"], "month_v_present_adj": adj["v_adj"],
             "month_nmi_present_adj": adj["nmi_adj"]}
        rules = {rule for _, rule, _ in R.evaluate(dict(m, measured=True), R.Thresholds({}))}
        if s["name"] != "count_30d":            # on all rows the censored months alone would flag it
            assert every["cramers_v"] >= 0.3
        assert unc["cramers_v"] < 0.05
        assert not rules & {"overlaps_month", "repeats_month", "tracks_time", "joint_clock"}


def test_the_joint_time_fit_leaves_out_censored_rows_so_clean_windowed_counts_get_no_joint_clock(tmp_path):
    df = _world()
    fake = _checks(df, tmp_path)
    # the old fit, on every row: the censored rows' missing flags date the rows
    t = pd.to_datetime(df[RC.TIME]).to_numpy(dtype="datetime64[ns]").astype(np.int64) / 86_400e9
    fold = M.account_folds(df[RC.ACCOUNT].to_numpy())
    X = np.column_stack([M.as_number(fake.values(s, df, START)[0])[0].to_numpy(dtype=float) for s in _specs()])
    old = M.joint_time_fit(X, t, fold, [s["name"] for s in _specs()])
    assert old["rho"] >= R.Thresholds({}).num("joint_clock_rho")
    F.Checks.joint_time(fake, "unused", [1])
    whole = json.loads((tmp_path / "joint_time_fit.json").read_text())
    rec = whole["sets"]["A1"]
    # Q2: the record says what the fit measures and what it does not establish
    for scope in (whole["scope"], rec["scope"]):
        assert "joint time predictability on the uncensored subset" in scope
        assert "does not establish that the model inputs, including censored-row missingness, carry no time" in scope
    assert abs(rec["rho"]) < 0.1
    assert rec["rows_censored_left_out"] > 0 and rec["rows"] + rec["rows_censored_left_out"] == len(df)
    for s in _specs():
        assert "joint_clock" not in fake.m[s["name"]]
        assert "FLAG joint_clock" not in fake.m[s["name"]]["joint_time"]
        assert "uncensored subset only, not proof that the model inputs" in fake.m[s["name"]]["joint_time"]


def test_the_joint_time_fit_still_flags_a_clock_on_rows_not_censored(tmp_path):
    df = _world()
    fake = _checks(df, tmp_path)
    clock = {"name": "clock", "fn": "clock", "recipe": "clock", "row": {"model_type": "continuous"},
             "model_type": "continuous", "flags": {}, "group": "v22b", "sources": [RC.TIME]}
    secs = (pd.to_datetime(df[RC.TIME]) - pd.Timestamp(START)).dt.total_seconds()
    fake.builder = F.Builder(RC, extra={"clock": lambda spec, frame, es: (secs, pd.Series(False, index=frame.index))})
    specs = _specs() + [clock]
    fake.buildable = lambda: specs
    fake.m = {s["name"]: {"result": "PASS", "measured": True} for s in specs}
    F.Checks.joint_time(fake, "unused", [1])
    rec = json.loads((tmp_path / "joint_time_fit.json").read_text())["sets"]["A1"]
    assert rec["rho"] >= 0.9 and rec["rows_censored_left_out"] > 0
    assert "joint_clock" in fake.m["clock"] and fake.m["clock"]["result"] == "FLAG"
