# Test results: features and testing package (reviewers' suggestions), D2 correction round

The package was tested on a reconstruction of the pod's code, not on the pod: the base is package 009 at `60232e9`
with the three reconstructed pod patches, in the pre-reorganization layout (the tree's first commit `92bc0d3`).
Synthetic data only; no bank data and no network in any test. Machine: 4 CPUs, Python 3.11, pandas 2.3.3, no GPU.

- Tested head: `b6297376303b8f08fd0bc3c01dbc9138759b467b` (branch `final3`).
- What it holds: the decisions round head `8a440a2` (the head of the last delivery), then the two builders of the
  3 November amendments merged on top: R `8b0c102` (the D2 correction in the reader and settings) and K `d1ebff1`
  (the D3d month-like hold, and the report wording for Q2, D3b, D9-Y16 and D9-Y20), merge commit `754c19d`, and one
  document fix `b629737` (FEATURES_AND_TESTING.md step 5 on the month-like hold, as the checks now do it). No
  conflicts. No test needed a fix.
- Logs are named as they sit in the integration folder (`logs/d2_...`).
- Each suite ran alone, from the project root, one at a time, all on the tested head's code.

## What to expect on the pod (POD.md step 6)

`CUDA_VISIBLE_DEVICES= PYTHONPATH=src:. nice -n 19 $PY -m pytest -q -p no:cacheprovider tests/experiments/features/new_fields tests/experiments/features/field_screen`

- Here: 1044 passed, 4 skipped (27 min 36 s) (log `logs/d2_install_check/06_step6_pytest.log`), on a clean copy of the base with the
  package's four folders copied in as step 3 says, while a process whose command line matches the GPU busy rule
  (`nf_time_width.py _attempt`) was alive, as stage 0's trainer will be on the pod. That stand-in sleeps 20
  minutes, so it was alive for the first 1200 s of the run, not for the end (the log says so).
- The last line must show `passed` and `skipped` only. The 4 skipped tests need inputs that are not in the
  package, so they skip on the pod too:
  - `test_new_fields_importance_metrics.py:193`: the independent integration reference is not installed;
  - `test_new_fields_spine_intake.py:148`, `test_new_fields_workbook_build.py:384` and `:391`: the records the
    draft lists were made from are not in the package.

## Suites

| Run | Command | Result | Log |
|---|---|---|---|
| Base suite | `PYTHONPATH=src:. python3 -m pytest -q -p no:cacheprovider waqas/v2/tests waqas/tests` | 1008 passed (6 min 7 s) | `logs/d2_base_suite.log` |
| Package tests | `PYTHONPATH=src:. python3 -m pytest -q -p no:cacheprovider -rs -o tmp_path_retention_policy=failed tests/experiments` | 1044 passed, 4 skipped, 0 failed (22 min 47 s) | `logs/d2_experiments.log` |
| Install check (POD.md steps 1 to 6) | above; `tests/experiments` holds exactly these two folders, so this is also a second run of the package tests | 1044 passed, 4 skipped (27 min 36 s) | `logs/d2_install_check/` |

Collected: 1048 tests in `tests/experiments` (`new_fields` and `field_screen`), 16 more than the last round's 1032:
the new and updated D2 tests in `test_new_fields_decisions_reader.py` (R) and the recorded-decision hold, window
warning, joint time scope, report line and workbook README tests (K).

## Install check, steps 1 to 5 (`logs/d2_install_check/`)

- Step 1 as written fails on this base (`No module named 'fraud.scripts.train_sequential_hier'`), because the base
  is in the pre-reorganization layout (`01_step1_hash.log`). The base's own trainer gives
  `c890474b5ab7a2ebc298de16259da89bc47aba892b9b35c8854b6713a94a2264` (`01b_step1_hash_fallback.log`).
- Step 2: the base has no `fraud/source_files.py` (`02_step2_source_files.log`): on the pod this means stop, as
  POD.md says, until the reorganization is applied.
- Step 3: the four folders copied in (`03_step3_install.log`).
- Step 4: the guard's first line is `pandas 2.3.3`; it then reports the pre-reorganization hash as CHANGED and
  stops, as expected on a base without the reorganization's hash rule (`04_step4_guard.log`). Under the reorganized
  rule the hash does not change (below).
- Step 5: `layout: pre-reorganization (fallback)` with every role found (`05_step5_layout.log`).
- The package installed was the tested head's, from a zip built the same way as the delivered one. The delivered
  zip differs from it only in `TEST_RESULTS.md` (this file) and nothing else; every other file is byte for byte the
  same.

## Each builder's own tests, as it was merged (from the builders' reports)

| Builder | Tests | Result |
|---|---|---|
| R (D2 correction) | the reader, select, lift, spread, planner and decisions tests (`test_new_fields_decisions_*`, `reader*`, `select_identity`, `lift_cache`, `integration_planner`, `integration_checked`), the POD command test and the naming check | 279 passed; the 17 new or updated D2 tests fail on the old reader and settings |
| K (D3d, Q2, D3b, D9-Y16, D9-Y20) | field checks, feature summary, workbook, decisions, month and calendar tests | 222 passed, 2 skipped |
| K | integration checks world, spine intake, field screen patch tests | 95 passed, 1 skipped |

## Checks

- Naming check (`nf_naming_check.py`) on every file of the unzipped package (147 files, the workbook's XML
  text included): PASS, 0 hits (`logs/d2_naming_check_unzipped.txt`). With no arguments on the tree: PASS, 0 hits
  (`logs/d2_naming_check_default.txt`).
- Em and en dashes, and absolute machine paths, in every file of the unzipped package and the workbook text:
  none, 0 lines (`logs/d2_scan_unzipped.txt`).
- Trainer source hash (the trainer's own `source_sha256()`; `logs/d2_source_hash_base.json`,
  `logs/d2_source_hash_head.json`):

| Rule | Base `92bc0d3` | Tested head | Result |
|---|---|---|---|
| Reorganized (folders `fraud`, excluded `tests/` and `fraud/experiments/`, plus `pyproject.toml` and `requirements.txt`) | `96d5e0c2357c743f897e1366c9fffa6807cd58a4ae9b99e5414f0f1d799012ce` (22 files) | `96d5e0c2357c743f897e1366c9fffa6807cd58a4ae9b99e5414f0f1d799012ce` (22 files) | equal |
| Pre-reorganization (as the base ships it) | `c890474b5ab7a2ebc298de16259da89bc47aba892b9b35c8854b6713a94a2264` (118 files) | `0cd7e0c7807839edf63cc4329684ebf068c008dd8a3be93e250fbb41959f5bc3` (157 files) | changed, as expected: only by the 39 `.py` files under `fraud/experiments/`. Install only after the reorganization |

- Against the base, every changed file is new (153 added, none modified or removed); none is under the trainer's
  hashed set. Since the last round (`2452afb`), 22 files changed, all under `fraud/experiments/`,
  `tests/experiments/` or the root documents.

## The zip

- `features_testing_package_REVIEWERS_SUGGESTIONS.zip`: 147 files. Its SHA-256 is given beside it, since this
  file is inside it.
- Contents, as README_FIRST.md "What is in the package" says: `fraud/experiments/features/new_fields/`,
  `fraud/experiments/features/field_screen/`, `tests/experiments/features/new_fields/`,
  `tests/experiments/features/field_screen/` (as tracked, with no caches), `README_FIRST.md`,
  `FEATURES_AND_TESTING.md`, `COPILOT_PROMPT.md`, `DESIGN.md` (revised), `TEST_RESULTS.md` (this file) and
  `changes.diff` (every change from the base to the tested head).

## After the tested head

- `5ca039f`, the second reviewer's documentation commit (a child of `b629737`), changes `DESIGN.md` only: sections
  R.2 and 8 now state the reader rules of the D2 correction. No code or test changed, so the counts above stand
  for this zip. `changes.diff` runs from the base to `5ca039f`.
