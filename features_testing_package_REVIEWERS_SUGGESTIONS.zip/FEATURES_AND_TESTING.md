# Features and testing: the owner's step-by-step

This is the order of work. Part A comes first, with Copilot, on CPU. Part B comes after the list is settled and the
GPU is free. Copilot runs the commands; you photograph the screens. The full run sheet is
`fraud/experiments/features/new_fields/POD.md`. The rules are the plan's (`PLAN.md`, sections 4 and 5).

## What we are testing

- **Step A1.** Seed 42, the base inputs plus the V22B group (V22B's included features minus Sumegha's exclusions; a
  feature in both lists counts here), against the stage 1 seed-42 retrain.
- **Step A2.** What model 15298 brings beyond the inputs kept after A1. When A1 keeps its control, the rows in both
  lists and the kept twins of 15298 rows join A2. Sumegha's exclusions follow the feature into every group: an
  excluded feature never enters at A1, and enters at A2 only with a person's keep row (the reviewers' decision D3a).
- **Step B, month out, on by default:** the last stage 2 fitting step; you may set it off with the bars (the
  reviewers' decision D4c under your delegation of 2 November). Month stays in through every adding step.
- **Off unless you turn them on:** A3 (off until your confirmed list holds a3 rows; the preflight checks it, D4a),
  pruning (D4b; the preflight refuses step P on), the cyclical calendar (step C), and one step with all groups
  at once.
- **Main measure (decided by the reviewers under your delegation of 2 November, D1):** UDR at the 0.6% outsort,
  counted in fraud transactions. VDR at 0.6% and FP/TP at 0.6% (false alerts per caught fraud, the bank's FPR) are
  reported on every read; AP is the early-stopping monitor, a SELECT-check measure and the conflict line, and
  decides no read.
- **Decision population:** RANK-B (files 8244-8259, June targets), if its check passes. If it fails, the plan's
  fallback files (8201-8205 with 8278-8300) get the same checks. If they fail too, June SELECT decides. If they pass,
  you decide how they are used, and the queue waits until then.
- **Reported only:** Test 1. Seed 42 was picked on it, so it never decides. This package does not score Test 2
  (BENCH): it needs the BENCH path, the row-alignment check and the LoB exclusions first, and is reported once those
  exist. Neither decides.

## Part A: CPU, with Copilot (safe while the GPU trains)

1. **Install and guard.** Copilot notes the trainer's source hash, copies the package folders in, and runs the guard.
   Photograph the guard screen (`unchanged`) and the pytest line.
2. **Pod columns.** `nf_intake.py schema` reads only file footers and prints how many raw columns the pod has.
3. **The field map.** `nf_intake.py draft` turns the workbook's attributes list (one row per feature name, with its
   recipe and source columns) into map form. Copilot then writes one row per feature from your list: group (V22B,
   15298 or both), raw or engineered, the recipe, the source columns, Sumegha's flag with the reason, feasibility,
   and the donor unit (account for a profile field, event for the others). Features with no definition yet are kept
   and marked as waiting, not dropped. Dates: a past event date goes in as the time before the transaction
   (`days_before`); a known future date, such as card expiry, as the time until it (`days_until`, signed: below
   zero once the date has passed). Both are on a log scale (step 5, D3b). The two V22B postal codes go in as TFM feeds them, `geohash(postal; country)` (see "Postal
   codes" below); the raw postal code is the proposed alternative.
4. **Check the map.** `nf_intake.py check-map`. Photograph the screen. It lists stops, waits and flags by rule:
   - stops: the seven status fields left out on 26 October, Sumegha's exclusions, label-like sources, a bank decision
     on the same transaction in raw form, a whole multi-output field cast as one value, a raw date;
   - waits: status-like fields (only the data owner's written answer clears them), holds, features not feasible in
     production, features still needing a definition, raw fields whose pod column or type is not known yet;
   - flags: external scores, unknown feasibility, a blank Sumegha column, look-backs longer than June can have,
     and the le1 and le3 outputs. Their original encoder is unverified, so the raw code, `code(c)`, is a proposed
     alternative (FLAG `encoding_alternative`). They stay unresolved in the decisions table.
5. **The thresholds.** The main measure and the bar (+1 point UDR) were decided by the reviewers under your
   delegation of 2 November and are recorded in `SETTINGS.yaml` approvals; the check thresholds (with the decided
   additions) and the cluster threshold (0.8) are recorded the same way, with `CHECK_THRESHOLDS.yaml`'s SHA-256.
   Nothing reads until every approval is filled. **Decided on 2 November** (no longer open):
   - A feature in both lists counts as V22B; when A1 keeps its control it joins A2 (D3a).
   - Dates enter on a log scale: a past event as ln(1 + whole seconds) before the transaction, a known future date
     as sign(u) ln(1 + |u|) in days (a month-level expiry is the last day of its month), with sentinels, the
     after-transaction rows and implausible dates missing with a counted reason (D3b).
   - A new field that repeats month on its present values, or tracks time, is held until the reviewers record keep
     or drop and the reason in `KEEP_DECISIONS.csv`, under your delegation; you are asked only for a missing source
     fact or a preference. Exact month duplicates stay represented once; month stays and leaves only through the
     month-out step (D3d).
   - Pruning reopens only as a three-seed compression step with a stated reason and an allowable loss (D4b).
     This package does not build that step, so the preflight refuses step P on. "Not helping" means the whole
     interval at or below zero on UDR and AP.
   - No fixed floor for the UDR seed spread: T_1 takes the t value at the Welch-Satterthwaite degrees of freedom
     and the larger measured spread (D2). A spread of zero is reported, not a stop (D2, corrected 3 November).
   - UDR counts transactions; the account measure is not defined yet (D1).
   - Still yours: external scores (`external_1_scr`, VAA) only if present at decision time in production; they are
     flagged for you (the field map's `feasible_in_production` and `external_score`). Every read says that
     `external_1_scr` is assumed available, not certified, until you record who certified it and when in
     `SETTINGS.yaml` `external_1_scr_certified` (D3c, OQ-14).
6. **Field checks.** Availability at the moment of the transaction, leakage probes, missing values (overall, by
   month, by label), duplicates and recodes, clusters, and whether any new field repeats month. Photograph the
   summary. Nothing is removed automatically; flagged fields are listed for you.
7. **CPU screen.** A quick XGBoost ranking of groups and single features. It is XGBoost's view, not the
   transformer's, so it decides nothing. Copilot runs `fsc_run.py --dry-run` first, then the full command in
   `fraud/experiments/features/field_screen/POD.md`, with the field checks' `field_status.csv` and `clusters.csv`.
   It writes `checkpoints/new_fields/screen/`: `summary.txt` (photograph it), `feature_rank.csv` (one row per
   field; its `note` column holds the field's flags, and the per-feature summary turns any note into `review`),
   `cluster_rank.csv` and `screen.json`. It leaves out a field that reads a column the checks stop or hold, and
   refuses a map with two rows of one name or a row named like a base input, even a row the checks stop. You
   rename or remove the rows it names; after a rename the field checks run again. June drift flags a field only
   above its own cut, so a field with few June rows is not flagged for chance alone.
8. **Rank check.** Whether RANK-A and RANK-B can be read: files present, June targets, no other role, no
   exposure, no BENCH overlap. If either fails, the plan's fallback files get the same checks, and the screen says
   what you decide. If RANK-A fails, importance and attention wait for you. The seed spread of the three kept seeds
   is read by the queue.
9. **The workbook.** Current features, 15298 features, TFM V22B features, other proposed features, the final list,
   the excluded list and the decisions. All three last sheets come from one decisions table,
   `NF/KEEP_DECISIONS.csv`. Unresolved rows stay visibly unresolved. The le1 and le3 rows show `code(c)` in the
   `proposed_alternative` column.
10. **Confirm the list.** When you are happy, Copilot runs `nf_intake.py adopt` with your list file and your name and
    date. Rows not in your list stay in the map, marked as not in your list. Then the enriched copies and the
    extended artifact are built and checked. Photograph `base fields byte-identical: 23/23`. Every group you want
    must be in the list before the extended artifact is built: a later build fits the earlier groups' fields again,
    and nothing checks them against the files the kept fits used.

## Postal codes: TFM's geohash

- TFM never feeds the postal codes raw. Its V22 pipeline maps (postal code, country) to a geohash cell with one
  table. `geohash(postal; country)` follows TFM's rule as its code reads: spaces at the ends are removed (TFM's own
  lookup, the one that cuts a US code, removes only trailing spaces and reads the country as stored), a US code
  (country 840) keeps its first 5 characters, a code the table lacks gives OTHER, a missing postal code stays
  missing, and where the table repeats a code the row TFM uses wins (the first; the last for a cut US code).
- The table is `SETTINGS.yaml` `geohash_table`, TFM's S3 path by default. If the pod cannot read it, copy the file
  to the pod and put the copy's path there.
- If the pod's files already hold TFM's own `merchant_geohash` or `cprsrvc__pisinfo_cardholder_geohash`, the field
  checks compare it with the recipe. Below 99.9% of rows matching, they FLAG `tfm_geohash_match` with the count.
- The 26 October distance features (A3: travel speed and distance from home) need a centre point per postal code.
  With no centroid table, the centre of the postal code's geohash cell can serve, but it is coarse. The field
  checks print the table's precision p (the length of its geohash values; the file name's p3 probably means 3) and
  the cell size: p = 3 is about 156 by 156 km, p = 4 about 39 by 20 km, p = 5 about 4.9 by 4.9 km (east-west at
  the equator; at 40 degrees north a p = 3 cell is about 120 km wide). No centroid table is built yet.

## Part B: GPU, after stage 0 and stage 1 have finished

11. **Facts from stage 0 and stage 1.** Copilot fills paths in `UPSTREAM.yaml` and the learning rate with its
    report's name. The guard reads stage 1's result files itself.
12. **Your choices in `STEPS.yaml`.** Which steps run. Controls (the reviewers' decisions D5a and D5b): every later
    step reads against a seed-42 refit of the kept recipe at the candidate's micro-batch (10 epochs per later
    step), with new seed 43 and 44 fits for a recipe adopted at three seeds; the base is refit at seeds 43 and 44
    on this pod before the first read. The kept checkpoints are never controls. Each read prints the refit control
    beside the kept fit as information; the decision does not change. Importance runs once, on the final kept fit
    after month out (before pruning when pruning is on), only when an adding step was adopted (D6); after every
    step is your option (`importance: every_step`). Month out (step B) is on; you may set it off.
13. **Configs and timing.** `nf_make_configs.py` writes each step's config; it may change only a few allowed keys.
    The timing step measures the new width (with the missing-flag columns the preprocessing adds) and the GPU
    memory. Photograph both screens.
14. **Preflight and start.** `nf_plan.py preflight` must show every line `ok`. Then you run
    `PY=$PY bash fraud/experiments/features/new_fields/nf_start.sh`, or tell Copilot to. It refuses if anything runs
    on the GPU. The project folder is shared by your workbenches, so run the queue on one workbench only. A lock
    that names another workbench is never replaced: the queue refuses with exit 4 and names it. Remove it by hand
    only after checking on that workbench that nothing runs there. One-off work on another workbench that writes
    to its own folders is fine. The lock needs a POSIX file system: the workbenches' shared volume is one, an S3 or
    object-store mount is not.
15. **Each morning.** Photograph the queue log tail and `nf_report.py`. Watch the curves with
    `tensorboard --logdir checkpoints/new_fields/tb`, or
    `$PY fraud/scripts/show_progress.py --source tensorboard --granularity epoch --logdir checkpoints/new_fields/tb/<run>/seed42`.
    TensorBoard needs the `tensorboard` package in the pod's Python, and the workbook needs `openpyxl`. If one is
    missing, Copilot asks you before installing it, because an install can change packages stage 0 relies on.
    After each read, photograph its decision screen.
16. **After the fits.** Permutation importance of the final kept fit on RANK-A (every feature and every cluster of
    correlated features), the attention cross-check, the downstream check of the embedding, Test 1 and the result
    summary. Photograph each summary.

## How each step is decided (on RANK-B, the gain is candidate minus control in UDR)

- **A step that adds a group** is read at seed 42 first. T_1 is the one-fit noise threshold.
  - A gain at or below zero: KEEP THE CONTROL.
  - A gain at or above T_1 that also meets its bar with the lower end of the interval above zero: ADOPT, pending the
    SELECT check. At one seed the lower end is the account bootstrap's alone, because T_1 already carries the seed
    term.
  - Any other gain above zero: RUN SEEDS 43 AND 44. Then three seeds decide: ADOPT if the gain reaches the bar and
    the lower end of its interval (seed spread included) is above zero; otherwise KEEP THE CONTROL, printed as
    unresolved if the gain is above zero. No step runs more than three seeds.
- **Month out** (on by default, last of the fitting steps, D4c): the one-fit rule first, then the month rule.
  MONTH OUT only if removing month loses nothing (mean gain at or above zero) and it passes its SELECT check;
  otherwise KEEP MONTH. The rule is an operational simplification, not proof that removing month loses nothing; June
  is a month the month-in fit never saw in training. An adopted month out records month as dropped in
  `NF/KEEP_DECISIONS.csv`, so the workbook's final list and its export drop it too.
- **Cyclical calendar, step C** (off): `datetime.encoding: cyclical` by config only, with `is_weekend` as a choice.
  It changes hour, day and day of week as well as month (sin and cos numbers instead of codes). It is read like
  month out, against the kept fit: CALENDAR CYCLICAL or KEEP THE CALENDAR.
- **Pruning** (off, D4b; it reopens only for a stated cost reason, as a three-seed compression step that this
  package does not build yet, so the preflight refuses step P on): only new fields, clusters first; a field drops
  only if the whole interval of its importance is at or below zero on UDR and AP, and its cluster's too (reading
  B). Read at seed 42 only, by its own rule: the smaller list is kept unless the unpruned fit beats it by the bar
  with the lower end above zero (the account bootstrap's); KEEP THE SMALLER LIST means no loss was detected at one
  seed, not that there is none. If importance is missing or failed, pruning waits with a line saying why.
- **T_1** (D2, corrected 3 November): t(0.95, nu) x sqrt(sd_pair^2 + 2 sd_run^2), nu by Welch-Satterthwaite;
  sd_pair is the read's account bootstrap, sd_run the larger measured UDR spread (RANK-B and SELECT June when RANK-B
  decides). No fixed floor. The 2 sd_run^2 term is a working rule for one seed: it assumes the candidate and the
  control vary from seed to seed by the same amount, because one fit of each gives no other estimate. Nothing
  subtracts the pair term sd_null; the spread step prints it for information only.
- **A UDR spread of zero** can happen for a count of frauds in the top 0.6%, even with different valid fits. The
  spread step reports it and does not stop. T_1 is then undefined, so no step is adopted at one seed: a gain above
  zero goes to seeds 43 and 44, and the three-seed read decides. Two fits that are the same checkpoint or the same
  prediction file, and values that are not numbers, still stop.
- **At three seeds** the lower bound uses the comparison's own seed differences: LB_3 = gain - t x sqrt(v_acct +
  s_d^2 / k), where s_d is the SD of the k candidate-minus-control seed differences, v_acct the bootstrap variance
  of the gain and t the one-sided 95% value at k - 1 degrees of freedom (2 for three seeds). It no longer borrows
  the baseline spread: that needed the candidate to vary as much as the control, which is not shown.
- **The SELECT check:** every decision that changes the kept inputs (ADOPT, MONTH OUT, KEEP THE SMALLER LIST,
  CALENDAR CYCLICAL) gets one logged SELECT read. It fails, and the control stays, if AP, AUROC, KS or UDR falls
  below -k x sqrt(SE^2 + 2 s_m^2/n), with k 2.5 (3.5 when SELECT decides) and s_m the larger of the measure's SELECT
  June and RANK-B spreads (D2). The k values here and in the conflict line are working rules for development; how
  often they give a wrong answer when the candidate and the control vary by different amounts is not known.
- **The conflict line** (D1): when a decision that changes the kept inputs drops AP or VDR below the same kind of
  limit (k 2.5), the read prints a conflict line and writes it to the decision log; the decision stands.
- **The downstream lift:** if a group passes the fraud rule but its kept fit's UDR lift falls below the control's by
  more than one paired SE, the report says so for you. It changes no decision. DS_SELECT is read once per kept fit.

## Budget in epochs (maxima before early stopping; the plan's numbers as the reviewers' decisions change them)

- Default steps A1, A2 and month out: at most 170. A1 and A2 at most 110: the seed-42 refit control of the later
  step makes it 90, and the new seed 43 and 44 fits of the refit's recipe after a three-seed adoption 110 (D5a);
  the base refits at seeds 43 and 44 (20 at today's width, D5b) are inside that figure. Month out adds at most 60,
  its own fits and its refit controls (D4c). Plus 10·C_c (180) if a new seed-42 base control (P1) is fit.
- Optional steps, each at most: A3 60 and pruning 20, each refit control counted. The switch in place of A1 and A2:
  50 (plus the same 10 for a new control).
- The cyclical calendar step is not in the plan's budget. It is read like month out, so at most 60.
- Scoring, importance and the downstream exports come on top; importance prints its GPU time before it starts.

## What decides, and what does not

- Adoption is decided only by the transformer fits on the decision population, under the rules in `SETTINGS.yaml`.
- The CPU screen, the importance tools and attention rank features. They do not decide.
- A saved decision is never stepped over. If its inputs change, the queue stops and says so.
- Stride is not available for the chosen chunk model; imbalance handling stays with the loss options in stage 3.
