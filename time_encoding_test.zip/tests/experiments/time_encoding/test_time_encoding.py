"""Tests of the time-gap encoding test arm and its comparison script.

The model tests build the chosen model's own class (organized layout on the pod, old layout elsewhere) at tiny
sizes on CPU. The end-to-end test trains and scores on the old layout's synthetic data; it is skipped where that
data does not exist (the pod).

Run: CUDA_VISIBLE_DEVICES= PYTHONPATH=src:. python -m pytest -q -p no:cacheprovider tests/experiments/time_encoding
"""
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import torch
from sklearn.metrics import average_precision_score, roc_auc_score

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "fraud" / "experiments" / "time_encoding"))
import te_compare  # noqa: E402
import te_layout  # noqa: E402
import te_patch  # noqa: E402

KW = dict(continuous_dim=3, categorical_cardinality=[4, 5], history_len=3, embed_dim=8, num_heads=2,
          num_txn_blocks=1, num_seq_blocks=1, attention_mask="causal", predict_every_transaction=True,
          all_position_layout="nonoverlapping_chunks", time_delta_reference="previous_transaction",
          history_time_order="strict")


@pytest.fixture
def mods():
    layout, mods = te_layout.resolve(roles=("base_model", "target_ending_model"))
    model_cls = mods["base_model"].FTTransformerHierModel
    yield mods
    te_patch.remove(model_cls)


def build(model_cls, seed=0, **over):
    torch.manual_seed(seed)
    return model_cls(**{**KW, **over}).eval()


def batch(gaps=None):
    """Two strict chunks (T = 4): row 0 has four distinct seconds, row 1 three real rows with a same-second tie."""
    g = torch.zeros(2, 4)
    sec0, sec1 = [0, 30, 630, 7830], [100, 101, 101, 0]
    g[0] = torch.tensor([0.0, math.log1p(30), math.log1p(600), math.log1p(7200)])
    g[1] = torch.tensor([0.0, math.log1p(1), math.log1p(1), 0.0])
    if gaps is not None:
        g = gaps
    torch.manual_seed(7)
    cont = torch.randn(2, 4, 3)
    cont[..., -1] = g
    return {
        "continuous": cont,
        "categorical": torch.tensor([[[0, 1], [1, 2], [2, 3], [3, 4]], [[1, 0], [2, 1], [3, 2], [0, 0]]]),
        "mask": torch.tensor([[True, True, True, True], [True, True, True, False]]),
        "time_seq": torch.tensor([sec0, sec1], dtype=torch.long) * 10**9,
    }


def test_zero_gain_is_exactly_the_plain_model(mods):
    model_cls = mods["base_model"].FTTransformerHierModel
    plain = build(model_cls)
    out_plain = plain(batch())
    te_patch.apply(te_patch.settings_from(gain=0.0), model_cls)
    te = build(model_cls)
    assert torch.equal(te.txn_position.emb.weight, plain.txn_position.weight)
    assert torch.equal(te(batch()), out_plain)


def test_gain_changes_the_scores_and_trains_the_norm(mods):
    model_cls = mods["base_model"].FTTransformerHierModel
    out_plain = build(model_cls)(batch())
    te_patch.apply(te_patch.settings_from(gain=0.5), model_cls)
    te = build(model_cls)
    out = te(batch())
    assert out.shape == out_plain.shape
    assert not torch.allclose(out, out_plain)
    out.sum().backward()
    assert te.txn_position.norm.weight.grad is not None
    assert float(te.txn_position.norm.weight.grad.abs().sum()) > 0


def test_the_term_follows_the_time_ids(mods):
    model_cls = mods["base_model"].FTTransformerHierModel
    te_patch.apply(te_patch.settings_from(gain=0.01), model_cls)
    te = build(model_cls)
    b = batch()
    idx = torch.tensor([[0, 1, 2, 3], [0, 1, 1, 0]])
    pos = te.txn_position.emb(idx)
    ids = te_patch.gap_ids(b["time_seq"], b["mask"], "ms")
    te.txn_position.current_ids = ids
    a = te.txn_position(idx)
    te.txn_position.current_ids = ids + 1000
    assert not torch.allclose(a, te.txn_position(idx))
    expected = pos + 0.01 * te.txn_position.norm(te_patch.gap_sinusoid(ids, 8, 1e7))
    assert torch.allclose(a, expected)


def test_the_term_reads_time_seq(mods):
    """Doubling every timestamp keeps the order and the ties, so the strict mask and the positions: the plain
    model does not change, the arm does, because its gaps double."""
    model_cls = mods["base_model"].FTTransformerHierModel
    plain = build(model_cls)
    b, b2 = batch(), batch()
    b2["time_seq"] = b2["time_seq"] * 2
    assert torch.equal(plain(b), plain(b2))
    te_patch.apply(te_patch.settings_from(gain=0.5), model_cls)
    te = build(model_cls)
    assert not torch.allclose(te(b), te(b2))
    seen = []
    orig = te_patch.gap_ids
    try:
        te_patch.gap_ids = lambda *a: seen.append(orig(*a)) or seen[-1]
        te(b)
    finally:
        te_patch.gap_ids = orig
    assert len(seen) == 1 and torch.equal(seen[0], orig(b["time_seq"], b["mask"], "ms"))
    nb = batch()
    del nb["time_seq"]
    with pytest.raises(ValueError, match="time_seq"):
        te(nb)


def test_gap_ids_follow_the_models_strict_rule():
    sec = 10 ** 9
    times = torch.tensor([[10, 20, 20, 35, 0], [7, 7, 8, 0, 0]], dtype=torch.long) * sec
    mask = torch.tensor([[True, True, True, True, False], [True, True, True, False, False]])
    # [10, 20, 20] -> 0, 10, 10 (a tie measures to the latest strictly earlier time); padding 0; chunk start 0
    assert te_patch.gap_ids(times, mask, "s").tolist() == [[0, 10, 10, 15, 0], [0, 0, 1, 0, 0]]
    assert te_patch.gap_ids(times, mask, "ms").tolist() == [[0, 10000, 10000, 15000, 0], [0, 0, 1000, 0, 0]]
    # stored precision finer than a second: whole milliseconds of the exact difference
    fine = torch.tensor([[10 * sec + 500_000_000, 20 * sec + 250_000_000]])
    assert te_patch.gap_ids(fine, torch.tensor([[True, True]]), "ms").tolist() == [[0, 9750]]
    assert te_patch.gap_ids(fine, torch.tensor([[True, True]]), "s").tolist() == [[0, 9]]
    # pre-1970 timestamps are ordinary times; a padded slot (time 0) is never an earlier row
    neg = torch.tensor([[-50, -20, 0]], dtype=torch.long) * sec
    assert te_patch.gap_ids(neg, torch.tensor([[True, True, False]]), "s").tolist() == [[0, 30, 0]]
    # a 100-day gap in ms stays exact
    far = torch.tensor([[0, 100 * 86400 * sec]], dtype=torch.long)
    assert te_patch.gap_ids(far, torch.tensor([[True, True]]), "ms").tolist() == [[0, 100 * 86400 * 1000]]
    with pytest.raises(ValueError):
        te_patch.gap_ids(times, mask[:, :4], "ms")
    b = batch()
    assert te_patch.gap_ids(b["time_seq"], b["mask"], "s").tolist() == [[0, 30, 600, 7200], [0, 1, 1, 0]]


def test_sinusoid_follows_the_paper():
    """e = [sin(id * theta) ; cos(id * theta)], theta_k = base ** (-2k / d): all sines, then all cosines."""
    ids = torch.tensor([0, 1, 3600], dtype=torch.long)
    e = te_patch.gap_sinusoid(ids, 8, 1e7)
    assert e.shape == (3, 8)
    assert torch.equal(e[0], torch.tensor([0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0]))  # sin 0, then cos 0
    theta = [1e7 ** (-2.0 * k / 8) for k in range(4)]
    for row, i in ((1, 1), (2, 3600)):
        for k in range(4):
            assert math.isclose(float(e[row, k]), math.sin(i * theta[k]), rel_tol=1e-6, abs_tol=1e-7)
            assert math.isclose(float(e[row, 4 + k]), math.cos(i * theta[k]), rel_tol=1e-6, abs_tol=1e-7)
    big = torch.tensor([8_640_000_000], dtype=torch.long)  # 100 days in ms; float64 keeps the angle exact
    assert math.isclose(float(te_patch.gap_sinusoid(big, 8, 1e7)[0, 0]), math.sin(8_640_000_000.0),
                        rel_tol=1e-6, abs_tol=1e-6)
    with pytest.raises(ValueError):
        te_patch.gap_sinusoid(ids, 7, 1e7)


def test_settings_record_the_paper_defaults_and_refuse_bad_values():
    s = te_patch.settings_from()
    assert s == {"gain": 0.01, "base": 1e7, "layernorm": True, "unit": "ms"}
    assert te_patch.checked(s) == s
    assert te_patch.checked({**s, "note": "ignored"}) == s  # other keys are ignored
    assert te_patch.settings_from(base=1.0)["base"] == 1.0  # the paper's grid starts at f_base 1
    for bad in (dict(gain=-1.0), dict(base=0.5), dict(unit="us"), dict(gain=float("nan"))):
        with pytest.raises(ValueError):
            te_patch.settings_from(**bad)
    with pytest.raises(ValueError):
        te_patch.checked({k: v for k, v in s.items() if k != "unit"})


def test_class_swap_keeps_the_encoding(mods):
    model_cls = mods["base_model"].FTTransformerHierModel
    te_patch.apply(te_patch.settings_from(gain=0.5), model_cls)
    te = build(model_cls)
    before = te(batch())
    te.__class__ = mods["target_ending_model"].FTTransformerHierTargetEnding
    assert torch.equal(te(batch()), before)


def test_checkpoint_records_settings_and_round_trips(mods):
    model_cls = mods["base_model"].FTTransformerHierModel
    settings = te_patch.settings_from(gain=0.5)
    te_patch.apply(settings, model_cls)
    te = build(model_cls, seed=0)
    ckpt = {}
    te.on_save_checkpoint(ckpt)
    assert ckpt[te_patch.CHECKPOINT_KEY] == settings
    state = te.state_dict()
    other = build(model_cls, seed=1)
    other.load_state_dict(state)
    assert torch.equal(other(batch()), te(batch()))
    te_patch.remove(model_cls)
    plain = build(model_cls)
    with pytest.raises(RuntimeError):
        plain.load_state_dict(state)  # the normal scorer refuses an arm checkpoint


def test_other_modes_are_refused(mods):
    model_cls = mods["base_model"].FTTransformerHierModel
    te_patch.apply(te_patch.settings_from(), model_cls)
    with pytest.raises(ValueError, match="time-gap encoding needs"):
        build(model_cls, predict_every_transaction=False, attention_mask="bidirectional",
              all_position_layout=None, time_delta_reference="target", history_time_order=None)


def test_other_settings_and_bypassed_forward_are_refused(mods):
    model_cls = mods["base_model"].FTTransformerHierModel
    te_patch.apply(te_patch.settings_from(gain=0.01), model_cls)
    te_patch.apply(te_patch.settings_from(gain=0.01), model_cls)  # same settings: fine
    with pytest.raises(RuntimeError, match="other settings"):
        te_patch.apply(te_patch.settings_from(gain=0.02), model_cls)
    te = build(model_cls)
    with pytest.raises(RuntimeError, match="bypassed"):
        te.txn_position(torch.zeros(2, 4, dtype=torch.long))
    with pytest.raises(ValueError):
        te_patch.settings_from(gain=-1.0)


# ------------------------------------------------------------------------------------------ comparison script

def test_decision_formulas_by_hand():
    from scipy.stats import t as student_t
    # T_1 with the Welch-Satterthwaite degrees of freedom
    a, b = 0.004 ** 2, 2 * 0.006 ** 2
    nu = (a + b) ** 2 / (b * b / 2)
    t1 = te_compare.t1_terms(0.004, 0.006, 2)
    assert math.isclose(t1["nu"], nu, rel_tol=1e-12)
    assert math.isclose(t1["t1"], student_t.ppf(0.95, nu) * math.sqrt(a + b), rel_tol=1e-12)
    assert t1["undefined"] is None
    zero = te_compare.t1_terms(0.003, 0.0, 2)
    assert math.isnan(zero["t1"]) and zero["undefined"]
    # LB_3 from three paired differences
    diffs, v = [0.012, 0.004, 0.02], 1e-5
    s_d = float(np.std(diffs, ddof=1))
    want = 0.012 - student_t.ppf(0.95, 2) * math.sqrt(v + s_d ** 2 / 3)
    assert math.isclose(te_compare.lb_three(0.012, diffs, v)[0], want, rel_tol=1e-12)
    # the decision at one seed (T_1 0.015, bar 0.01) and at three seeds
    d = te_compare.decide_add
    assert d(1, -0.01, 0.015, 0.01, 0.002)[0] == "KEEP THE CONTROL"
    assert d(1, 0.02, 0.015, 0.01, 0.002)[0] == "ADOPT"
    assert d(1, 0.012, 0.015, 0.01, 0.002)[0] == "RUN SEEDS 43 AND 44"  # above 0, below T_1
    assert d(1, 0.016, 0.015, 0.01, -0.001)[0] == "RUN SEEDS 43 AND 44"  # lower end not above 0
    assert d(1, 0.005, float("nan"), 0.01, 0.002, t1_undefined="zero spread")[0] == "RUN SEEDS 43 AND 44"
    assert d(1, -0.005, float("nan"), 0.01, 0.002, t1_undefined="zero spread")[0] == "KEEP THE CONTROL"
    assert d(3, 0.012, None, 0.01, None, lb3=0.003)[0] == "ADOPT"
    assert d(3, 0.012, None, 0.01, None, lb3=-0.001)[1].startswith("unresolved")
    assert d(3, 0.008, None, 0.01, None, lb3=0.003)[0] == "KEEP THE CONTROL"  # below the bar
    # the seed spread: the larger of those given; a tie takes the smaller degrees of freedom
    spreads = {"a": {"metrics": {"udr": {"sd_run": 0.004, "df": 2}}},
               "b": {"metrics": {"udr": {"sd_run": 0.006, "df": 4}, "ap": {"sd_run": 0.002, "df": 2}}},
               "c": {"metrics": {"ap": {"sd_run": 0.002, "df": 4}}}}
    assert te_compare.seed_spread(spreads, "udr") == (0.006, 4, "b")
    assert te_compare.seed_spread(spreads, "ap") == (0.002, 2, "b")
    assert te_compare.seed_spread(spreads, "ks") == (None, None, None)
    # the SELECT check limit -k x sqrt(sd^2 + 2 s_m^2 / n)
    metrics = {m: {"gain": g, "sd": 0.003} for m, g in (("ap", -0.004), ("auroc", 0.001), ("ks", -0.03),
                                                         ("udr", 0.002))}
    sp = {"x": {"metrics": {m: {"sd_run": 0.005, "df": 2} for m in ("ap", "auroc", "ks", "udr")}}}
    rows = {r["metric"]: r for r in te_compare.select_check(metrics, 2.5, sp, 1)["rows"]}
    limit = -2.5 * math.sqrt(0.003 ** 2 + 2 * 0.005 ** 2)
    assert all(math.isclose(r["limit"], limit, rel_tol=1e-12) for r in rows.values())
    assert rows["ap"]["pass"] and rows["udr"]["pass"] and not rows["ks"]["pass"]


def _fits(tmp_path, n=6000, accounts=900, seed=3):
    """Prediction files as the scorer writes them: one control and one arm per seed 42, 43, 44, plus the plain
    model's kept fits (the spread), on the same rows; the arm is a little better."""
    rng = np.random.default_rng(seed)
    y = (rng.random(n) < 0.04).astype(np.int64)
    acc = np.array([f"acct{i % accounts:04d}" for i in range(n)])
    ids = np.array([f"t{i:06d}" for i in rng.permutation(n)])
    amt = np.round(np.abs(rng.normal(60, 25, n)), 2)
    base = rng.random(n) + 0.35 * y
    files = {}
    for s in (42, 43, 44):
        noise = np.random.default_rng(s).normal(0, 0.3, n)
        ctrl = np.round(base + noise, 3)
        arm = np.round(base + noise + 0.25 * y * np.random.default_rng(s + 100).random(n), 3)
        kept = np.round(base + np.random.default_rng(s + 7).normal(0, 0.3, n), 3)
        for name, sc in (("control", ctrl), ("arm", arm), ("kept", kept)):
            f = tmp_path / f"{name}_{s}.parquet"
            pd.DataFrame({"fi_transaction_id": ids, "Nmap_account_reference_xid": acc, "transaction_amt": amt,
                          "frd_tag": y, "score": sc, "window_rows": 3}).to_parquet(f, index=False)
            files[(name, s)] = f
    return files, (y, acc, ids, amt)


def test_read_numbers_are_the_engines_and_the_decision_follows_the_rule(tmp_path):
    files, (y, acc, ids, amt) = _fits(tmp_path)
    out = tmp_path / "one.json"
    argv = ["--role", "decide", "--control", str(files[("control", 42)]), "--arm", str(files[("arm", 42)]),
            "--all-rows", "--spread-fits"] + [str(files[("kept", s)]) for s in (42, 43, 44)] + \
           ["--draws", "200", "--out", str(out)]
    assert te_compare.main(argv) == 0
    rec = json.loads(out.read_text())
    R = te_compare.R
    keys = R.key_ranks(R.identity_keys(acc, ids))
    codes, units = R.account_units(acc)
    sc = {k: pd.read_parquet(f)["score"].to_numpy(float) for k, f in files.items()}
    rk = lambda s: R.RankedScore(s, y, codes, keys, amt)  # noqa: E731
    want = R.paired([rk(sc[("arm", 42)])], [rk(sc[("control", 42)])], len(units), 200, 20261102, 90)["metrics"]
    for m in te_compare.METRICS:
        assert rec["metrics"][m]["gain"] == want[m]["gain"] and rec["metrics"][m]["sd"] == want[m]["sd"]
    # UDR by hand: the top floor(6 N / 1000) rows by score, ties by [account, id]
    order = np.lexsort((keys, -sc[("arm", 42)]))
    k = len(y) * 6 // 1000
    assert rec["metrics"]["udr"]["candidate"][0] == y[order][:k].sum() / y.sum()
    assert math.isclose(want["ap"]["candidate"][0], average_precision_score(y, sc[("arm", 42)]), rel_tol=1e-12)
    assert math.isclose(want["auroc"]["candidate"][0], roc_auc_score(y, sc[("arm", 42)]), rel_tol=1e-12)
    kept = [R.RankedScore(sc[("kept", s)], y, codes, keys, amt).evaluate(None)["udr"] for s in (42, 43, 44)]
    assert math.isclose(rec["spread"]["metrics"]["udr"]["sd_run"], float(np.std(kept, ddof=1)), rel_tol=1e-12)
    assert rec["spread"]["metrics"]["udr"]["df"] == 2 and rec["spread_from_fits"]["fits"] == 3
    t = te_compare.t1_terms(want["udr"]["sd"], rec["spread"]["metrics"]["udr"]["sd_run"], 2)
    assert math.isfinite(t["t1"]) and rec["t1"]["t1"] == t["t1"] and rec["spread"]["metrics"]["udr"]["sd_run"] > 0
    assert (rec["decision"], rec["reason"]) == te_compare.decide_add(1, want["udr"]["gain"], t["t1"], 0.01,
                                                                     want["udr"]["lo"])[:2]
    assert (out.with_suffix(".txt")).read_text().count("DECISION:") == 1

    three = tmp_path / "three.json"
    argv3 = ["--role", "decide", "--seed-labels", "42", "43", "44", "--all-rows", "--draws", "200", "--out",
             str(three)]
    for s in (42, 43, 44):
        argv3 += ["--control", str(files[("control", s)]), "--arm", str(files[("arm", s)])]
    assert te_compare.main(argv3) == 0  # three seeds need no seed spread: LB_3 uses the paired differences
    rec3 = json.loads(three.read_text())
    lb3 = te_compare.lb_three(rec3["metrics"]["udr"]["gain"], rec3["metrics"]["udr"]["differences"],
                              rec3["metrics"]["udr"]["var"])[0]
    assert rec3["lb_three_seed"] == lb3 and rec3["t1"] is None
    assert len(rec3["metrics"]["udr"]["differences"]) == 3

    pooled = tmp_path / "pooled.json"
    assert te_compare.main(["--role", "report", "--control", str(files[("control", 42)]), "--arm",
                            str(files[("arm", 42)]), "--all-rows", "--draws", "20", "--spread-fits"]
                           + [str(files[("kept", s)]) for s in (42, 43, 44)]
                           + ["--spread-fits"] + [str(files[("control", s)]) for s in (42, 43, 44)]
                           + ["--out", str(pooled)]) == 0
    prec = json.loads(pooled.read_text())["spread"]["metrics"]["udr"]
    trios = [[R.RankedScore(sc[(name, s)], y, codes, keys, amt).evaluate(None)["udr"] for s in (42, 43, 44)]
             for name in ("kept", "control")]
    ss = sum(float(((np.asarray(v) - np.mean(v)) ** 2).sum()) for v in trios)
    assert prec["df"] == 4 and math.isclose(prec["sd_run"], math.sqrt(ss / 4), rel_tol=1e-12)
    sel = tmp_path / "sel.json"
    assert te_compare.main(["--role", "select-check", "--control", str(files[("control", 42)]), "--arm",
                            str(files[("arm", 42)]), "--all-rows", "--spread-fits"]
                           + [str(files[("kept", s)]) for s in (42, 43, 44)]
                           + ["--spread-json", str(out), "--draws", "200", "--out", str(sel)]) == 0
    srec = json.loads(sel.read_text())
    assert [r["metric"] for r in srec["select_check"]["rows"]] == ["ap", "auroc", "ks", "udr"]
    assert all(r["limit"] is not None for r in srec["select_check"]["rows"])


def test_read_refusals_and_stops(tmp_path):
    files, (y, acc, ids, amt) = _fits(tmp_path, n=3000)
    c42, a42 = str(files[("control", 42)]), str(files[("arm", 42)])
    base = ["--control", c42, "--arm", a42, "--draws", "20"]
    assert te_compare.main(["--role", "decide", *base, "--out", str(tmp_path / "a.json")]) == 4  # no rows given
    assert te_compare.main(["--role", "decide", *base, "--all-rows", "--out", str(tmp_path / "b.json")]) == 4  # spread
    assert te_compare.main(["--role", "report", *base, "--out", str(tmp_path / "r.json")]) == 0
    assert te_compare.main(["--role", "report", *base, "--out", str(tmp_path / "r.json")]) == 4  # out exists
    with pytest.raises(SystemExit) as exc:
        te_compare.main(["--role", "report", "--control", c42, "--out", str(tmp_path / "x.json")])  # no --arm
    assert exc.value.code == 2
    assert te_compare.main(["--role", "report", "--control", c42, "--control", c42, "--arm", a42, "--all-rows",
                            "--out", str(tmp_path / "x.json")]) == 4  # unpaired
    bad = pd.read_parquet(files[("arm", 42)])
    bad.loc[0, "frd_tag"] = 1 - bad.loc[0, "frd_tag"]
    bad.to_parquet(tmp_path / "bad.parquet", index=False)
    assert te_compare.main(["--role", "report", "--control", c42, "--arm", str(tmp_path / "bad.parquet"),
                            "--out", str(tmp_path / "c.json")]) == 3  # labels differ
    short = pd.read_parquet(files[("arm", 42)]).iloc[:-5]
    short.to_parquet(tmp_path / "short.parquet", index=False)
    assert te_compare.main(["--role", "report", "--control", c42, "--arm", str(tmp_path / "short.parquet"),
                            "--out", str(tmp_path / "d.json")]) == 3  # rows differ
    keep = pd.DataFrame({"fi_transaction_id": ids[:1000]})
    keep.to_csv(tmp_path / "keep.csv", index=False)
    assert te_compare.main(["--role", "report", "--control", c42, "--arm", str(tmp_path / "short.parquet"),
                            "--keep-ids", str(tmp_path / "keep.csv"), "--out", str(tmp_path / "e.json")]) == 0
    rec_keep = tmp_path / "f.json"
    assert te_compare.main(["--role", "report", *base, "--keep-ids", str(tmp_path / "keep.csv"),
                            "--out", str(rec_keep)]) == 0
    assert json.loads(rec_keep.read_text())["rows"] == 1000
    same = ["--spread-fits", c42, c42]  # two copies of one fit: a note, a zero spread, so T_1 is undefined
    assert te_compare.main(["--role", "decide", *base, "--all-rows", *same, "--out", str(tmp_path / "g.json")]) == 0
    assert "T1 undefined" in json.loads((tmp_path / "g.json").read_text())["reason"] or \
        "T1 is undefined" in json.loads((tmp_path / "g.json").read_text())["reason"]


# ------------------------------------------------------------------------- end to end (old layout only)

def test_train_score_compare_end_to_end(tmp_path):
    conftest = pytest.importorskip("waqas.v2.tests.conftest")
    helpers = pytest.importorskip("waqas.tests.test_sequence_builder")
    if te_layout.resolve(roles=("base_model",))[0] != "old":
        pytest.skip("the end-to-end test runs on the old code layout only")
    from omegaconf import OmegaConf
    import train_time_encoding
    import score_time_encoding
    from fraud.data.datetime_features import DatetimeConfig
    from fraud.data.feature_list import load_feature_list
    from waqas.v2.scripts import score_v2, train_v2

    torch.set_num_threads(1)
    frames = {i: conftest._frame(i) for i in (1, 2, 3)}
    predictors = helpers._write_predictors(tmp_path)
    features = load_feature_list(predictors, version=1)
    dt = DatetimeConfig(order_col="transaction_dttm", fields=helpers.DATETIME_FIELDS, encoding="categorical",
                        is_weekend=False)
    helpers._fit_artifacts(pd.concat(frames.values()), features, dt).save(str(tmp_path / "artifacts/1"))
    data = tmp_path / "data"
    data.mkdir()
    for i, f in frames.items():
        f.to_parquet(data / f"part_{i}.parquet", index=False)
    c = OmegaConf.load(ROOT / "waqas/phase4b/configs/sequential_hier_allposition.yaml")
    c.s3.cred_path = None
    c.predictors.csv_path, c.predictors.version = predictors, 1
    c.artifacts.base, c.artifacts.version = str(tmp_path / "artifacts"), 1
    c.data.train_base = c.data.val_base = str(data)
    c.data.train_start, c.data.train_end, c.data.val_start, c.data.val_end = 1, 2, 3, 3
    c.sequence.history_len = 3
    c.sequence.max_chunk_rows = 64
    c.sequence.max_window_rows = 64
    c.training.update(dict(batch_size=16, buffer_windows=64, max_epochs=1, accelerator="cpu", precision="32-true",
                           num_workers=0, seed=42, log_every_n_steps=1, early_stopping_patience=5,
                           eval_batch_size=7))
    c.model.update(dict(input_embed_dim=8, num_heads=2, num_txn_blocks=1, num_seq_blocks=1))
    cfg_path = tmp_path / "cfg.yaml"
    OmegaConf.save(c, cfg_path)
    score_args = ["--population", "EPOCH_VAL", "--purpose", "test", "--config", str(cfg_path),
                  f"eval.base={data}", "eval.file_start=3", "eval.file_end=3"]

    train_v2.main(["--config", str(cfg_path), f"output.checkpoint_dir={tmp_path / 'control'}"])
    score_v2.main(score_args + ["--checkpoint", str(tmp_path / "control/best.ckpt"),
                               "--out", str(tmp_path / "control.parquet")])

    layout, mods = te_layout.resolve(roles=("base_model",))
    model_cls = mods["base_model"].FTTransformerHierModel
    seen = []

    def record():
        """Pre-apply the arm's settings (the scripts' own apply is then a no-op) and keep every batch's inputs."""
        te_patch.apply(te_patch.settings_from(gain=0.01), model_cls)
        patched = model_cls.forward

        def forward(self, batch):
            seen.append({k: batch[k].detach().cpu().clone() for k in ("continuous", "time_seq", "mask")})
            return patched(self, batch)
        model_cls.forward = forward

    try:
        assert train_time_encoding.main(["--gain", "0.01", "--", "--config", str(cfg_path)]) == 4  # no output dir
        record()
        rc = train_time_encoding.main(["--gain", "0.01", "--", "--config", str(cfg_path),
                                       f"output.checkpoint_dir={tmp_path / 'arm'}"])
        assert rc == 0
        ckpt = torch.load(tmp_path / "arm/best.ckpt", map_location="cpu", weights_only=False)
        assert ckpt[te_patch.CHECKPOINT_KEY] == te_patch.settings_from(gain=0.01)
        assert ckpt[te_patch.CHECKPOINT_KEY]["unit"] == "ms" and ckpt[te_patch.CHECKPOINT_KEY]["base"] == 1e7
        assert any(k.endswith("txn_position.norm.weight") for k in ckpt["state_dict"])
    finally:
        te_patch.remove(model_cls)
    n_train = len(seen)
    with pytest.raises(Exception):
        score_v2.main(score_args + ["--checkpoint", str(tmp_path / "arm/best.ckpt"),
                                   "--out", str(tmp_path / "plain_arm.parquet")])  # normal scorer refuses
    try:
        record()
        assert score_time_encoding.main(["--"] + score_args + ["--checkpoint", str(tmp_path / "arm/best.ckpt"),
                                                               "--out", str(tmp_path / "arm.parquet")]) == 0
    finally:
        te_patch.remove(model_cls)
    # The time ids equal the model's own gap input on every real row of every training, validation and scoring
    # batch: round(expm1(time_delta)) seconds, x 1000 in ms. Same rule, exact integers.
    assert n_train > 0 and len(seen) > n_train
    real_rows = 0
    for b in seen:
        m = b["mask"]
        feature = torch.round(torch.expm1(b["continuous"][..., -1].double())).long()
        assert torch.equal(te_patch.gap_ids(b["time_seq"], m, "s")[m], feature[m])
        assert torch.equal(te_patch.gap_ids(b["time_seq"], m, "ms")[m], 1000 * feature[m])
        real_rows += int(m.sum())
    assert real_rows > 0 and any(bool((te_patch.gap_ids(b["time_seq"], b["mask"], "s") > 0).any()) for b in seen)
    assert score_time_encoding.main(["--"] + score_args + ["--checkpoint", str(tmp_path / "control/best.ckpt"),
                                                           "--out", str(tmp_path / "z.parquet")]) == 4
    # The read on the target rows of the raw files, through the project's own load_raw and target_mask.
    label = c.data.target_col
    pair = ["--control", str(tmp_path / "control.parquet"), "--arm", str(tmp_path / "arm.parquet"),
            "--label", label, "--draws", "20", "--config", str(cfg_path), "--raw-base", str(data), "--files", "3",
            "3"]
    raw3 = frames[3]
    t0, t1 = "2024-01-01", str((raw3["transaction_dttm"].max() + pd.Timedelta(seconds=1)).date()
                               + pd.Timedelta(days=1))
    out = tmp_path / "read_all.json"
    assert te_compare.main(["--role", "report", *pair, "--targets", t0, t1, "--out", str(out)]) == 0
    rep = json.loads(out.read_text())
    assert rep["rows"] == len(raw3) and set(rep["metrics"]) == set(te_compare.METRICS)
    assert rep["rows_read"].startswith(f"targets {t0}")
    day2 = str((raw3["transaction_dttm"].min() + pd.Timedelta(days=1)).date())
    out2 = tmp_path / "read_window.json"
    assert te_compare.main(["--role", "report", *pair, "--targets", day2, t1, "--out", str(out2)]) == 0
    n_window = int((raw3["transaction_dttm"] >= pd.Timestamp(day2)).sum())
    assert 0 < json.loads(out2.read_text())["rows"] == n_window < len(raw3)
    spread = tmp_path / "spread.json"
    spread.write_text(json.dumps({"metrics": {m: {"sd_run": 0.02, "df": 2} for m in te_compare.METRICS}}))
    out3 = tmp_path / "read_decide.json"
    assert te_compare.main(["--role", "decide", *pair, "--targets", t0, t1, "--spread-json", str(spread),
                            "--out", str(out3)]) == 0
    assert json.loads(out3.read_text())["decision"] in ("KEEP THE CONTROL", "RUN SEEDS 43 AND 44", "ADOPT")

    # The paper's one-epoch screen, one pair, in its own process as on the pod; then collect.
    import te_screen
    screen = tmp_path / "screen"
    trainer_args = ["--config", str(cfg_path), "training.max_epochs=7", f"output.checkpoint_dir={tmp_path / 'x'}"]
    assert te_screen.main(["run", "--root", str(screen), "--dry-run", "--"] + trainer_args) == 0
    assert not screen.exists()  # a dry run starts nothing
    assert te_screen.main(["run", "--root", str(screen), "--bases", "1e7", "--gains", "0.01", "--"]
                          + trainer_args) == 0
    folder = screen / "base1e+07_gain0.01_ms"
    assert (folder / "best.ckpt").is_file() and not (tmp_path / "x").exists()
    assert te_screen.main(["run", "--root", str(screen), "--bases", "1e7", "--gains", "0.01", "--"]
                          + trainer_args) == 0  # done already: skipped
    assert te_screen.main(["collect", "--root", str(screen), "--control-metrics",
                           str(tmp_path / "control/training_metrics.csv")]) == 0
    summary = json.loads((screen / "screen_summary.json").read_text())
    assert [(r["base"], r["gain"], r["unit"]) for r in summary["runs"]] == [(1e7, 0.01, "ms")]
    assert summary["runs"][0]["valid_ap"] == te_screen.first_epoch(folder / "training_metrics.csv")["valid_ap"]
    assert summary["control_epoch0"]["valid_ap"] is not None


def test_screen_commands_and_collect(tmp_path):
    import te_screen
    rest = ["--config", "c.yaml", "a.b=1", "training.max_epochs=10", "output.checkpoint_dir=runs/x"]
    todo = te_screen.commands(rest, tmp_path, te_screen.PAPER_BASES, te_screen.PAPER_GAINS, "ms", 1)
    assert len(todo) == 16
    folder, argv = todo[13]  # base 1e7, gain 0.1
    assert folder == tmp_path / "base1e+07_gain0.1_ms"
    tail = argv[argv.index("--") + 1:]
    assert tail == ["--config", "c.yaml", "a.b=1", "training.max_epochs=1", f"output.checkpoint_dir={folder}"]
    assert argv[argv.index("--gain") + 1] == "0.1" and argv[argv.index("--base") + 1] == "1e+07"
    with pytest.raises(ValueError):
        te_screen.commands(rest, tmp_path, [0.5], [0.01], "ms", 1)
    assert te_screen.main(["run", "--root", str(tmp_path), "--"]) == 4  # no trainer arguments
    for base, gain, ap in ((1e7, 0.01, 0.12), (1e5, 0.1, 0.15), (1e8, 0.01, 0.10)):
        d = te_screen.run_dir(tmp_path, base, gain, "ms")
        d.mkdir()
        torch.save({te_patch.CHECKPOINT_KEY: te_patch.settings_from(gain, base)}, d / "best.ckpt")
        (d / "training_metrics.csv").write_text(f"epoch,step,valid_ap,valid_loss\n0,10,{ap},0.3\n1,20,0.5,0.2\n")
    rep = te_screen.collect(tmp_path)
    assert [(r["base"], r["gain"], r["valid_ap"]) for r in rep["runs"]] == [(1e5, 0.1, 0.15), (1e7, 0.01, 0.12),
                                                                          (1e8, 0.01, 0.10)]
    assert rep["best"]["base"] == 1e5
    assert te_screen.main(["collect", "--root", str(tmp_path / "empty")]) == 4
