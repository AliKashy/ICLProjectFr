"""Train the chosen model with the paper's sinusoidal time-gap embedding: the test arm.

Where it runs: on the pod, from the project root, on a workbench whose GPU is free.

Usage, everything after `--` going to the trainer unchanged:

    $PY fraud/experiments/time_encoding/train_time_encoding.py [--gain 0.01] [--base 1e7] [--unit ms] \
        [--no-layernorm] -- <the exact trainer arguments of the seed-42 control run> \
        output.checkpoint_dir=runs/time_encoding/paper_seed42

ADAPT: `<the exact trainer arguments ...>` are those of the owner's seed-42 rerun of the chosen model (the control):
the same --config and the same overrides, so the only difference is this embedding. That includes
training.deterministic: false, as the chosen model's config sets it (the trainer turns it on when the key is
missing). Only the output folder changes; keep it under runs/time_encoding/, apart from the other runs.

The defaults are the paper's chosen setting: gain (lambda) 0.01, base (f_base) 1e7, time ids in milliseconds,
LayerNorm on. The checkpoint stores the settings under "time_encoding". Score it with score_time_encoding.py: the
normal scorer cannot load this checkpoint, because it has two extra weights. With --gain 0 the model gives exactly
the plain model's outputs.
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import te_layout  # noqa: E402
import te_patch  # noqa: E402

OUT_PREFIX = "output.checkpoint_dir="


def split_argv(argv):
    if "--" not in argv:
        raise SystemExit("usage: train_time_encoding.py [--gain G] [--base B] [--unit ms|s] [--no-layernorm] "
                         "-- <trainer args>")
    i = argv.index("--")
    return argv[:i], argv[i + 1:]


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    ours, rest = split_argv(argv)
    ap = argparse.ArgumentParser(description="train the chosen model with the sinusoidal time-gap embedding")
    ap.add_argument("--gain", type=float, default=te_patch.DEFAULTS["gain"], help="lambda; the paper's is 0.01")
    ap.add_argument("--base", type=float, default=te_patch.DEFAULTS["base"], help="f_base; the paper's is 1e7")
    ap.add_argument("--unit", choices=sorted(te_patch.UNITS), default=te_patch.DEFAULTS["unit"],
                    help="unit of the time id; the paper's is ms")
    ap.add_argument("--no-layernorm", action="store_true")
    a = ap.parse_args(ours)
    outs = [x for x in rest if x.startswith(OUT_PREFIX)]
    if len(outs) != 1 or not outs[0][len(OUT_PREFIX):].strip():
        print("error: give exactly one output.checkpoint_dir=runs/time_encoding/<arm>_seed<NN> after --",
              file=sys.stderr)
        return 4
    settings = te_patch.settings_from(a.gain, a.base, not a.no_layernorm, a.unit)
    layout, mods = te_layout.resolve(roles=("base_model", "trainer"))
    te_patch.apply(settings, mods["base_model"].FTTransformerHierModel)
    print(f"time-gap encoding: layout {layout}; gain {settings['gain']}, base {settings['base']:g}, unit "
          f"{settings['unit']}, layernorm {settings['layernorm']}; trainer {mods['trainer'].__name__}; {outs[0]}",
          flush=True)
    rc = mods["trainer"].main(rest)
    return int(rc or 0)


if __name__ == "__main__":
    sys.exit(main())
