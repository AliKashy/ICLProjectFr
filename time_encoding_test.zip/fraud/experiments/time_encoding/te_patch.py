"""Sinusoidal time-gap embedding for the chosen model, as in the FraudTransformer paper (arXiv 2509.23712).

The paper's best variant (relative time, learned position, LayerNorm):
- every token of an event gets  e_tok + e_col + p_learn + lambda * LN(e_t);
- e_t = [sin(theta * id) ; cos(theta * id)]: all the sines first, then all the cosines;
- theta_k = f_base ** (-2k / d), k = 0 .. d/2 - 1, d the model width;
- id is the time since the previous event, in whole milliseconds, shared by every token of the event;
- LN is a LayerNorm with a learned scale and shift, on the time term only;
- lambda is a fixed setting, not learned. The paper's chosen values are lambda 0.01 and f_base 1e7.
- Only time gets a sinusoid. Numeric fields are not sine encoded. (The config option
  continuous_embedding: periodic is a different method, sine features on every numeric input; it is not used.)

What this module adds to the chosen model, and nothing else:

    position(i) + lambda * LN([sin(theta * id_i) ; cos(theta * id_i)])

- It is added where the model adds its learned position embedding, at the transaction level. The model pools a
  transaction's field tokens into one vector first, so the term is added once per transaction vector.
- id_i is computed in 64-bit integers from batch["time_seq"] (per-row timestamps in nanoseconds): whole
  milliseconds (default) or whole seconds from the latest strictly earlier timestamp of the row's chunk or window,
  0 when there is none. This is the model's own gap rule: rows with the same timestamp cannot see each other, so a
  tied row measures to the latest strictly earlier timestamp. The first rows of a chunk or window get 0.
- The model's existing inputs are unchanged, including its time_delta input (log1p seconds).
- With lambda (gain) 0 the model gives exactly the plain model's outputs.

apply() patches the model class in memory only (__init__, forward and on_save_checkpoint); no project file is
edited. The target-ending subclass the trainer switches to inherits the patch. The checkpoint stores the settings
under "time_encoding", and score_time_encoding.py applies the same patch from there.
"""
import functools
import math

import torch
from torch import nn

DEFAULTS = {"gain": 0.01, "base": 1.0e7, "layernorm": True, "unit": "ms"}
UNITS = {"ms": 10 ** 6, "s": 10 ** 9}  # nanoseconds per step of the time id
CHECKPOINT_KEY = "time_encoding"

_PATCHED = {}  # class -> {"init", "forward", "on_save_checkpoint", "settings"}


def settings_from(gain=DEFAULTS["gain"], base=DEFAULTS["base"], layernorm=DEFAULTS["layernorm"],
                  unit=DEFAULTS["unit"]):
    gain, base = float(gain), float(base)
    if not (math.isfinite(gain) and gain >= 0):
        raise ValueError(f"gain must be 0 or more, got {gain}")
    if not (math.isfinite(base) and base >= 1):
        raise ValueError(f"base must be 1 or more, got {base}")
    if unit not in UNITS:
        raise ValueError(f"unit must be one of {sorted(UNITS)}, got {unit!r}")
    return {"gain": gain, "base": base, "layernorm": bool(layernorm), "unit": unit}


def checked(settings):
    """The four settings read from a dict (for example a checkpoint's), validated; other keys are ignored."""
    s = dict(settings)
    missing = [k for k in DEFAULTS if k not in s]
    if missing:
        raise ValueError(f"time-gap encoding settings lack {missing}: {s}")
    return settings_from(**{k: s[k] for k in DEFAULTS})


def gap_ids(times, mask, unit):
    """[batch, time] int64 time ids: whole `unit`s from the latest strictly earlier real timestamp of the row's
    chunk to the row's timestamp; 0 when there is none and on padding.

    times: [batch, time] int64 nanoseconds (batch["time_seq"]); mask: [batch, time] bool, True on real rows.
    The comparison is the one the model uses for its strict positions: row j counts for row i when j is real and
    time_j < time_i.
    """
    if tuple(times.shape) != tuple(mask.shape) or times.dim() != 2:
        raise ValueError(f"time_seq and mask must both be [batch, time]; got {tuple(times.shape)} and "
                         f"{tuple(mask.shape)}")
    mask = mask.to(torch.bool)
    times = times.to(device=mask.device, dtype=torch.long)
    earlier = (times.unsqueeze(1) < times.unsqueeze(2)) & mask.unsqueeze(1)  # [b, i, j]: j real, time_j < time_i
    lowest = torch.iinfo(torch.long).min
    prev = torch.where(earlier, times.unsqueeze(1).expand_as(earlier),
                       torch.full_like(earlier, lowest, dtype=torch.long)).amax(-1)  # latest earlier time
    has = earlier.any(-1) & mask
    gap_ns = times - torch.where(has, prev, times)
    return torch.div(gap_ns, UNITS[unit], rounding_mode="floor")


def gap_sinusoid(ids, dim, base):
    """[..., dim] = [sin(id * theta) ; cos(id * theta)], theta_k = base ** (-2k / dim), k = 0 .. dim/2 - 1.

    The paper's layout: all the sines, then all the cosines. Computed in float64 (a 100-day gap is about 1e10 ms,
    exact in float64), returned as float32.
    """
    if dim % 2:
        raise ValueError(f"the model width must be even, got {dim}")
    half = dim // 2
    k = torch.arange(half, device=ids.device, dtype=torch.float64)
    theta = torch.pow(torch.tensor(float(base), dtype=torch.float64, device=ids.device), -2.0 * k / dim)
    angles = ids.to(torch.float64).unsqueeze(-1) * theta
    return torch.cat([torch.sin(angles), torch.cos(angles)], dim=-1).to(torch.float32)


class TimeAwarePosition(nn.Module):
    """The model's learned position table plus gain * LayerNorm(sinusoid(time id)) for the current batch."""

    def __init__(self, position, dim, gain, base, layernorm):
        super().__init__()
        self.emb = position
        self.dim, self.gain, self.base = int(dim), float(gain), float(base)
        self.norm = nn.LayerNorm(self.dim) if layernorm else nn.Identity()
        self.current_ids = None  # [batch, time] int64 time ids, set by the patched forward for each batch

    @property
    def weight(self):
        return self.emb.weight

    def forward(self, idx):
        pos = self.emb(idx)
        ids, self.current_ids = self.current_ids, None
        if ids is None:
            raise RuntimeError("time-gap encoding: no time ids for this batch (the model's forward was bypassed)")
        if idx.dim() != 2 or tuple(ids.shape) != tuple(idx.shape):
            raise ValueError("time-gap encoding supports the strict all-position model only: position index and "
                             f"time ids must both be [batch, time]; got {tuple(idx.shape)} and {tuple(ids.shape)}")
        enc = self.norm(gap_sinusoid(ids.to(pos.device), self.dim, self.base))
        return pos + self.gain * enc.to(pos.dtype)


def _check_model(model):
    hp = model.hparams
    ok = (hp.get("predict_every_transaction") and hp.get("history_time_order") == "strict"
          and hp.get("time_delta_reference") == "previous_transaction")
    if not ok:
        raise ValueError("time-gap encoding needs the chosen model's mode: predict_every_transaction true, "
                         "history_time_order strict, time_delta_reference previous_transaction; got "
                         f"{hp.get('predict_every_transaction')}, {hp.get('history_time_order')}, "
                         f"{hp.get('time_delta_reference')}")


def apply(settings, model_cls):
    """Patch model_cls (the chosen model's base class) in memory. Idempotent for equal settings."""
    s = checked(settings)
    done = _PATCHED.get(model_cls)
    if done is not None:
        if done["settings"] != s:
            raise RuntimeError(f"already patched with other settings: {done['settings']} vs {s}")
        return
    orig_init, orig_forward = model_cls.__init__, model_cls.forward
    orig_save = model_cls.on_save_checkpoint

    @functools.wraps(orig_init)  # Lightning's save_hyperparameters reads the original signature through it
    def __init__(self, *args, **kwargs):
        orig_init(self, *args, **kwargs)
        _check_model(self)
        self.txn_position = TimeAwarePosition(self.txn_position, self.hparams["embed_dim"], s["gain"], s["base"],
                                              s["layernorm"])
        self.time_encoding_settings = dict(s)

    @functools.wraps(orig_forward)
    def forward(self, batch):
        times = batch.get("time_seq")
        if times is None:
            raise ValueError("time-gap encoding needs batch['time_seq'] (per-row timestamps, ns), as the strict "
                             "model itself does")
        self.txn_position.current_ids = gap_ids(times, batch["mask"], s["unit"])
        return orig_forward(self, batch)

    @functools.wraps(orig_save)
    def on_save_checkpoint(self, checkpoint):
        out = orig_save(self, checkpoint)
        checkpoint[CHECKPOINT_KEY] = dict(s)
        return out

    model_cls.__init__, model_cls.forward, model_cls.on_save_checkpoint = __init__, forward, on_save_checkpoint
    _PATCHED[model_cls] = {"init": orig_init, "forward": orig_forward, "on_save_checkpoint": orig_save,
                           "settings": s}


def remove(model_cls):
    """Undo apply() (used by the tests)."""
    done = _PATCHED.pop(model_cls, None)
    if done is not None:
        model_cls.__init__ = done["init"]
        model_cls.forward = done["forward"]
        model_cls.on_save_checkpoint = done["on_save_checkpoint"]
