"""Paired comparison of the time-encoding arm against its control: per seed, arm minus control, on the same rows.

Where it runs: on the pod, from the project root, CPU only (no GPU), minutes per read.

Measures (te_ranked.py computes them):
- UDR at the 0.6% outsort decides: frauds among the top floor(6 N / 1000) rows by score (ties broken by
  [account, id]) over all frauds. AP, VDR, FPR, AUROC and KS are reported beside it.
- Each arm fit is paired with the control fit of the same seed. The gain is the mean over seeds of arm minus
  control. Account bootstrap: 2000 draws, seed 20261102, whole accounts, the same draws for every fit; 90% interval.

Decision (bar +0.01 UDR):
- one seed: T_1 = t x sqrt(sd_pair^2 + 2 x sd_run^2) (t one-sided 95% at the Welch-Satterthwaite degrees of
  freedom; sd_pair the bootstrap SD of the gain, sd_run the plain model's seed spread). Gain at or below 0:
  KEEP THE CONTROL. Gain >= T_1, >= the bar, and the bootstrap's lower end above 0: ADOPT, pending the SELECT
  check. Any other gain above 0: RUN SEEDS 43 AND 44. A seed spread of 0 leaves T_1 undefined, so a gain above 0
  goes to seeds 43 and 44.
- three seeds: ADOPT if the gain >= the bar and LB_3 = gain - t x sqrt(v_acct + s_d^2 / k) > 0 (t at k - 1
  degrees of freedom, s_d the SD of the k per-seed differences, v_acct the bootstrap variance of the mean gain);
  else KEEP THE CONTROL (unresolved if the gain is above 0).
- SELECT check: each of AP, AUROC, KS and UDR must not fall below -k x sqrt(SE_acct^2 + 2 x s_m^2 / n), k 2.5
  (3.5 when SELECT decides), s_m the measure's seed spread (the larger of those given). An ADOPT that fails it
  becomes KEEP THE CONTROL.

Rows: the population's June 2025 target rows. Every row of the raw files of the range is loaded (history months
included) and the target window [2025-06-01, 2025-07-01) is kept, with the project's load_raw and target_mask.
Every prediction file must hold those rows with the same labels. Alternatively --keep-ids lists the rows' ids, or
--all-rows reads every predicted row (for reporting only).

Usage, one read per population (RANK-B 8244-8259 decides; SELECT 8206-8216 checks; Test 1 8000-8010 is reported):

    $PY fraud/experiments/time_encoding/te_compare.py --role decide \
        --control <control seed 42 predictions> --arm <arm seed 42 predictions> \
        --config <the control's training config> --files 8244 8259 \
        --spread-fits <plain model's kept seed 42, 43, 44 predictions on the same files> \
        --out runs/time_encoding/reads/rank_b_seed42.json

    Seeds 43 and 44: repeat --control and --arm, one pair per seed, in the same seed order.
    The SELECT check: --role select-check --files 8206 8216, --spread-fits on SELECT, and --spread-json with the
    deciding read's .json (it keeps its seed spread), so s_m is the larger of the two.
    Test 1: --role report --all-rows (every scored row of 8000-8010; no spread needed).

ADAPT: --config is the control's training config: the raw files' base (its eval.base, else data.val_base) and its
S3 access setting (s3.cred_path) are read from it. --raw-base and --cred set them directly instead. The prediction
files are those the scorers wrote (the control's by the normal scorer, the arm's by score_time_encoding.py) on the
same file range. Column names default to the project's (--id, --account, --label, --score, --amount, --time).

Exit codes: 0 done; 2 bad arguments; 3 the files do not hold the same rows or labels, or a needed number is not
defined; 4 a needed input is missing or the output exists.
"""
import argparse
import json
import math
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import te_ranked as R  # noqa: E402

METRICS = R.METRICS  # udr, ap, vdr, fpr, auroc, ks
SELECT_METRICS = ("ap", "auroc", "ks", "udr")
DEFAULTS = {"draws": 2000, "seed": 20261102, "interval": 90.0, "bar_udr": 0.01, "k_select": 2.5,
            "k_select_when_select_decides": 3.5, "k_conflict": 2.5, "targets": ("2025-06-01", "2025-07-01")}
CHANGES = {"ADOPT": "KEEP THE CONTROL"}
ZERO_SPREAD = ("the UDR seed spread sd_run is zero (possible for a top-k count even with different valid fits): "
               "T_1's seed term has no estimate, so the one-seed noise threshold is undefined; no one-seed adoption")


class Stop(Exception):
    """A check failed (exit 3)."""


class Refused(Exception):
    """A needed input is missing (exit 4)."""


def _finite(x):
    try:
        return x is not None and math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


# ----------------------------------------------------------------------------------------------- decision formulas
def t_one_sided(df, level=0.95):
    from scipy.stats import t as student_t
    return float(student_t.ppf(level, df))


def t1_terms(sd_pair, sd_run, df_run=2):
    """A = sd_pair^2, B = 2 sd_run^2, nu = (A + B)^2 / (B^2 / df_run), T_1 = t(0.95, nu) x sqrt(A + B)."""
    if not (_finite(sd_run) and float(sd_run) >= 0):
        raise Stop(f"the seed spread sd_run is {sd_run}: T_1 needs a finite measured spread")
    a = float(sd_pair) ** 2 if _finite(sd_pair) else float("nan")
    b = 2.0 * float(sd_run) ** 2
    undefined = ZERO_SPREAD if b == 0.0 and math.isfinite(a) else None
    if b > 0 and math.isfinite(a):
        nu = (a + b) ** 2 / (b * b / float(df_run))
        tq = t_one_sided(nu)
        value = tq * math.sqrt(a + b)
    else:
        nu = tq = value = float("nan")
    return {"t1": float(value), "a": a, "b": b, "nu": nu, "t": tq, "df_run": df_run, "sd_pair": sd_pair,
            "sd_run": sd_run, "undefined": undefined,
            "assumes": "equal candidate and control seed variance (one fit per arm gives no other estimate)"}


def lb_three(gain, diffs, v_acct):
    """LB_3 = gain - t(k - 1) x sqrt(v_acct + s_d^2 / k). Returns (LB_3, s_d, t, k - 1)."""
    k = len(diffs)
    if k < 2:
        raise ValueError(f"the three-seed bound needs at least two paired seed differences, got {k}")
    s_d = float(np.std(np.asarray(diffs, float), ddof=1))
    tq = t_one_sided(k - 1)
    return float(gain - tq * math.sqrt(float(v_acct) + s_d ** 2 / k)), s_d, tq, k - 1


def _f(x, digits=4, sign=True):
    if not _finite(x):
        return "n/a"
    return f"{float(x):+.{digits}f}" if sign else f"{float(x):.{digits}f}"


def decide_add(seeds, gain, t1_udr, bar, lb, lb3=None, t1_undefined=None):
    """The decision for one read. Returns (decision, reason, whether it changes the model)."""
    if not _finite(gain):
        raise Stop(f"the gain is not a number ({gain}): no decision is made on an undefined gain")
    zero_spread = seeds == 1 and bool(t1_undefined)
    if seeds == 1 and not _finite(t1_udr) and not zero_spread:
        raise Stop(f"T1 is not a number ({t1_udr}): no one-seed decision is made without the noise threshold")
    if zero_spread:
        if gain <= 0:
            return "KEEP THE CONTROL", f"gain {gain:+.4f} is zero or below (T1 undefined: {t1_undefined})", False
        return ("RUN SEEDS 43 AND 44", f"gain {gain:+.4f} is above zero and T1 is undefined ({t1_undefined}); the "
                "three-seed read decides", False)
    if seeds == 1:
        if gain <= 0:
            return "KEEP THE CONTROL", f"gain {gain:+.4f} is zero or below", False
        if gain >= t1_udr and gain >= bar and lb is not None and lb > 0:
            return ("ADOPT", f"gain {gain:+.4f} >= T1 {t1_udr:.4f}, >= bar {bar:+.4f}, account bootstrap LB "
                    f"{lb:+.4f} > 0", True)
        if gain < t1_udr:
            return ("RUN SEEDS 43 AND 44", f"gain {gain:+.4f} is above zero but below T1 {t1_udr:.4f}", False)
        why = []
        if gain < bar:
            why.append(f"gain {gain:+.4f} is at or above T1 {t1_udr:.4f} but below the bar {bar:+.4f}")
        if lb is None or lb <= 0:
            why.append(f"account bootstrap LB {_f(lb)} is not above zero")
        return "RUN SEEDS 43 AND 44", "; ".join(why) + "; seeds 43 and 44 decide", False
    if gain >= bar and lb3 is not None and lb3 > 0:
        return "ADOPT", f"gain {gain:+.4f} >= bar {bar:+.4f} and LB_3 {lb3:+.4f} > 0", True
    why = f"gain {gain:+.4f}, bar {bar:+.4f}, LB_3 {_f(lb3)}"
    return ("KEEP THE CONTROL", ("unresolved: " if gain > 0 else "") + why, False)


def seed_spread(spreads, m):
    """(s_m, df, source): the larger of the given seed spreads for measure m; a tie takes the smaller df."""
    best = None
    for name, data in spreads.items():
        r = ((data.get("metrics") or {}).get(m)) or {}
        v = r.get("sd_run")
        if not _finite(v):
            continue
        cand = (float(v), -int(r.get("df") or 2), name)
        if best is None or cand > best:
            best = cand
    if best is None:
        return None, None, None
    return best[0], -best[1], best[2]


def select_check(metrics, k_se, spreads, n_seeds, names=SELECT_METRICS):
    """Each difference must not fall below -k x sqrt(SE_acct^2 + 2 x s_m^2 / n)."""
    rows, ok = [], True
    for m in names:
        d, sd = metrics[m]["gain"], metrics[m]["sd"]
        s_m, df_m, src = seed_spread(spreads, m)
        se = None
        if sd is not None and _finite(sd) and s_m is not None:
            se = math.sqrt(float(sd) ** 2 + 2.0 * s_m ** 2 / n_seeds)
        limit = None if se is None else -k_se * se
        passed = limit is not None and _finite(d) and d >= limit
        ok &= bool(passed)
        rows.append({"metric": m, "difference": d, "sd": sd, "s_m": s_m, "s_m_source": src,
                     "se": se, "limit": limit, "pass": bool(passed)})
    return {"pass": bool(ok), "k_se": k_se, "n_seeds": n_seeds, "rows": rows}


def conflict_check(metrics, k_se, spreads, n_seeds, vdr_null_reason, names=("ap", "vdr")):
    """A note when AP or VDR falls clearly. Information only: UDR decides and the decision stands."""
    rows = []
    for m in names:
        if m == "vdr" and vdr_null_reason:
            continue
        d, sd = metrics[m]["gain"], metrics[m]["sd"]
        s_m, _, _ = seed_spread(spreads, m)
        if sd is None or not _finite(sd) or s_m is None or not _finite(d):
            continue
        se = math.sqrt(float(sd) ** 2 + 2.0 * s_m ** 2 / n_seeds)
        rows.append({"metric": m, "difference": float(d), "se": se, "limit": -k_se * se,
                     "conflict": bool(d < -k_se * se)})
    hits = [r for r in rows if r["conflict"]]
    line = None
    if hits:
        line = "conflict: " + "; ".join(f"{r['metric'].upper()} {r['difference']:+.4f} below {r['limit']:+.4f}"
                                        for r in hits) + " (UDR decides; the decision stands)"
    return {"k_se": k_se, "rows": rows, "line": line}


def finalize(decision, check):
    if decision not in CHANGES:
        return decision, None
    if check["pass"]:
        return decision, "the SELECT check passed"
    return CHANGES[decision], f"the SELECT check failed, so {decision} becomes {CHANGES[decision]}"


# ----------------------------------------------------------------------------------------------- rows and files
def prediction_frame(path, c):
    import pyarrow.parquet as pq
    have = set(pq.ParquetFile(path).schema_arrow.names)
    missing = [x for x in (c.account, c.id, c.label, c.score) if x not in have]
    if missing:
        raise Stop(f"{path}: the prediction file lacks {missing}")
    cols = [c.account, c.id, c.label, c.score] + ([c.amount] if c.amount and c.amount in have else [])
    pred = pq.read_table(path, columns=cols).to_pandas()
    frame = pd.DataFrame({"_acct": pred[c.account].map(str).to_numpy(), "_id": pred[c.id].map(str).to_numpy(),
                          "_plabel": pd.to_numeric(pred[c.label], errors="coerce").to_numpy(float),
                          "_score": pd.to_numeric(pred[c.score], errors="coerce").to_numpy(float)})
    if c.amount and c.amount in pred:
        frame["_pamount"] = pd.to_numeric(pred[c.amount], errors="coerce").to_numpy(float)
    if frame.duplicated(["_acct", "_id"]).any():
        raise Stop(f"{path}: duplicate (account, id) rows in the prediction file")
    return frame


def load_raw_rows(raw_base, start, end, targets, cred, c):
    """Every row of the raw files start..end (full-file history), then the target window, with the project's own
    load_raw and target_mask. Returns (rows frame, keys of every raw row, layout)."""
    import te_layout
    layout, mods = te_layout.resolve(roles=("base_model", "raw_join", "s3_files", "s3_fs"))
    files = mods["s3_files"].build_file_list(str(raw_base), int(start), int(end))
    fs = mods["s3_fs"].thin_read_filesystem(cred) if str(raw_base).startswith("s3://") else None
    args = SimpleNamespace(id=c.id, account=c.account, order_col=c.time, target=c.label, positive_label=1,
                           amount_col=None, exclude_col=None)
    try:
        raw = mods["raw_join"].load_raw(files, fs, args)
        mask = np.asarray(mods["raw_join"].target_mask(raw, targets[0], targets[1]), dtype=bool)
    except (ValueError, FileNotFoundError, OSError) as exc:
        raise Stop(f"the raw join of files {start}-{end} failed: {exc}")
    frame = pd.DataFrame({"_acct": raw["_acct"].map(str).to_numpy(), "_id": raw["_id"].map(str).to_numpy(),
                          "_label": np.asarray(raw["_label"], dtype=np.int64)})
    return frame.loc[mask].reset_index(drop=True), frame[["_acct", "_id"]], layout


def align(paths, rows, all_keys, c):
    """Every file holds exactly the read's rows with the read's labels. rows None: the rows
    are the first file's, and every file must hold the same (account, id) set with the same labels."""
    preds = [prediction_frame(p, c) for p in paths]
    rows_from_first = rows is None
    if rows_from_first:
        first = preds[0]
        rows = first[["_acct", "_id"]].assign(_label=first["_plabel"].to_numpy()).reset_index(drop=True)
        if not np.isin(rows["_label"].to_numpy(), [0, 1]).all():
            raise Stop(f"{paths[0]}: labels must be 0 or 1")
        rows["_label"] = rows["_label"].astype(np.int64)
    scores, amounts = [], []
    for path, pred in zip(paths, preds):
        if all_keys is not None:
            extra = pred.merge(all_keys, on=["_acct", "_id"], how="left", indicator=True)
            n_extra = int((extra["_merge"] == "left_only").sum())
            if n_extra:
                raise Stop(f"{path}: {n_extra} predicted rows are not in the raw files of the range")
        elif rows_from_first and len(pred) != len(rows):
            raise Stop(f"{path}: holds {len(pred)} rows, the first file {len(rows)}; every fit must hold exactly the "
                       "same (account, id) set (or give the read's rows with --raw-base or --keep-ids)")
        merged = rows.merge(pred, on=["_acct", "_id"], how="left", validate="one_to_one")
        n_missing = int(merged["_score"].isna().sum())
        if n_missing:
            raise Stop(f"{path}: does not hold the read's rows ({n_missing} of {len(rows)} missing); every fit must "
                       "hold exactly the same (account, id) set")
        if not np.array_equal(merged["_plabel"].to_numpy(float), rows["_label"].to_numpy(float)):
            raise Stop(f"{path}: labels differ from the read's labels")
        if not np.isfinite(merged["_score"].to_numpy(float)).all():
            raise Stop(f"{path}: scores are not finite")
        scores.append(merged["_score"].to_numpy(float))
        amounts.append(merged["_pamount"].to_numpy(float) if "_pamount" in merged else None)
    amount = None
    if all(a is not None for a in amounts):
        for a, path in zip(amounts[1:], paths[1:]):
            if not np.array_equal(a, amounts[0], equal_nan=True):
                raise Stop(f"{path}: {c.amount} differs from the first file's")
        amount = amounts[0]
    keys = R.identity_keys(rows["_acct"], rows["_id"])
    codes, units = R.account_units(rows["_acct"])
    data = SimpleNamespace(y=rows["_label"].to_numpy(np.int64), amounts=amount, key_rank=R.key_ranks(keys),
                           codes=codes, n_units=len(units), rows=len(rows))
    data.amount_reason = R.amount_reason(amount)
    return data, scores


def read_keep(path, c):
    p = Path(path)
    df = pd.read_parquet(p) if p.suffix == ".parquet" else pd.read_csv(p, dtype=str)
    if c.id not in df:
        raise Refused(f"{path} has no column {c.id}")
    keep = pd.DataFrame({"_id": df[c.id].map(str)})
    if c.account in df:
        keep["_acct"] = df[c.account].map(str)
    if keep.duplicated().any():
        raise Stop(f"{path}: duplicate rows")
    return keep


def keep_rows(first_path, keep, c):
    """The read's rows from an id list: the first prediction file's rows whose id (and account, if given) is listed."""
    pred = prediction_frame(first_path, c)
    on = ["_acct", "_id"] if "_acct" in keep else ["_id"]
    rows = pred.merge(keep, on=on, how="inner")
    if len(rows) != len(keep):
        raise Stop(f"{len(keep) - len(rows)} listed rows are not in {first_path}")
    if not np.isin(rows["_plabel"].to_numpy(), [0, 1]).all():
        raise Stop(f"{first_path}: labels must be 0 or 1")
    return pd.DataFrame({"_acct": rows["_acct"], "_id": rows["_id"],
                         "_label": rows["_plabel"].astype(np.int64)}).reset_index(drop=True)


# ----------------------------------------------------------------------------------------------- the read
def spread_from_fits(data, scores):
    """The plain model's seed spread per measure from its kept fits on the read's rows: the SD across the fits
    (ddof 1), df = fits - 1."""
    for i in range(len(scores)):
        for j in range(i + 1, len(scores)):
            if np.array_equal(scores[i], scores[j]):
                print(f"note: spread fits {i + 1} and {j + 1} give the same scores; check that they are different "
                      "seeds, or the seed spread comes out too small", flush=True)
    points = [R.RankedScore(s, data.y, data.codes, data.key_rank, data.amounts).evaluate(None) for s in scores]
    out = {}
    for m in METRICS:
        v = np.asarray([p[m] for p in points if _finite(p[m])], float)
        out[m] = {"values": [float(p[m]) for p in points], "sd_run": float(np.std(v, ddof=1)) if len(v) > 1 else None,
                  "df": int(len(v) - 1)}
    return {"metrics": out, "fits": len(scores)}


def run_read(a, c):
    if len(a.control) != len(a.arm) or not a.control:
        raise Refused("give one --control and one --arm per seed, in the same seed order")
    n = len(a.arm)
    paths = list(a.arm) + list(a.control)
    rows, all_keys, layout, scope = None, None, None, "all predicted rows (information only)"
    if a.config and not a.all_rows and not a.keep_ids:
        from omegaconf import OmegaConf
        cfg = OmegaConf.load(a.config)
        a.raw_base = a.raw_base or OmegaConf.select(cfg, "eval.base") or OmegaConf.select(cfg, "data.val_base")
        a.cred = a.cred or OmegaConf.select(cfg, "s3.cred_path")
        if not a.raw_base:
            raise Refused(f"{a.config} has no eval.base or data.val_base; give --raw-base")
    if a.raw_base:
        if not a.files:
            raise Refused("reading the raw files needs --files START END")
        rows, all_keys, layout = load_raw_rows(a.raw_base, a.files[0], a.files[1], a.targets, a.cred, c)
        scope = f"targets {a.targets[0]} to {a.targets[1]} of files {a.files[0]}-{a.files[1]} (raw join, {layout})"
    elif a.keep_ids:
        rows = keep_rows(paths[0], read_keep(a.keep_ids, c), c)
        scope = f"the rows listed in {a.keep_ids}"
    elif a.role != "report" and not a.all_rows:
        raise Refused("a decision or a SELECT check reads the population's June target rows: give --config (or "
                      "--raw-base) and --files, or --keep-ids; --all-rows is for information only")
    if rows is not None and rows.empty:
        raise Stop("the read has no rows")
    spread_paths = [p for group in (a.spread_fits or []) for p in group]
    data, scores = align(paths + spread_paths, rows, all_keys, c)
    if int(data.y.sum()) == 0:
        raise Stop("no fraud row in the read's rows")
    if data.rows * 3 // 500 == 0:
        raise Stop(f"{data.rows} rows give an empty 0.6% outsort; UDR cannot decide")
    fit_scores, spread_scores = scores[:2 * n], scores[2 * n:]
    rk = [R.RankedScore(s, data.y, data.codes, data.key_rank, data.amounts) for s in fit_scores]
    comp = R.paired(rk[:n], rk[n:], data.n_units, a.draws, a.seed, a.interval)
    met = comp["metrics"]

    spreads = {}
    for p in a.spread_json or []:
        loaded = json.loads(Path(p).read_text())
        spreads[f"json:{p}"] = loaded.get("spread") or loaded  # a read's record, or a reader spread file
    if spread_scores:
        if len(a.spread_fits) != 1:
            # pooled within groups: sum of squared deviations from each group's mean over the pooled df
            groups, start = [], 0
            for g in a.spread_fits:
                groups.append(spread_from_fits(data, spread_scores[start:start + len(g)]))
                start += len(g)
            pooled = {}
            for m in METRICS:
                ss, df = 0.0, 0
                for g in groups:
                    v = np.asarray([x for x in g["metrics"][m]["values"] if _finite(x)], float)
                    if len(v) > 1:
                        ss += float(((v - v.mean()) ** 2).sum())
                        df += len(v) - 1
                pooled[m] = {"sd_run": math.sqrt(ss / df) if df else None, "df": int(df),
                             "groups": [g["metrics"][m]["values"] for g in groups]}
            spreads["fits"] = {"metrics": pooled, "fits": len(spread_scores)}
        else:
            spreads["fits"] = spread_from_fits(data, spread_scores)
    own_spread = spreads.get("fits")
    used = {}
    for m in METRICS:
        s_m, df_m, src = seed_spread(spreads, m)
        used[m] = {"sd_run": s_m, "df": df_m, "source": src}
    used_spread = {"metrics": used} if any(v["sd_run"] is not None for v in used.values()) else None

    bar = float(a.bar_udr)
    rec = {"kind": "time-encoding read", "role": a.role, "rows_read": scope, "rows": data.rows,
           "frauds": int(data.y.sum()), "accounts": data.n_units, "seeds": a.seed_labels or list(range(1, n + 1)),
           "arm_files": [str(Path(p).resolve()) for p in a.arm],
           "control_files": [str(Path(p).resolve()) for p in a.control],
           "spread_fit_files": [str(Path(p).resolve()) for p in spread_paths],
           "bootstrap": {"draws": int(a.draws), "seed": int(a.seed), "interval": float(a.interval),
                         "unit": c.account},
           "outsort": "top floor(6 x N / 1000) rows (0.6%), ties by the identity key [account, id]",
           "metrics": met, "spread": used_spread, "spread_from_fits": own_spread, "spreads_given": sorted(spreads),
           "bar_udr": bar,
           "amount": "prediction files" if data.amounts is not None else None, "vdr_null_reason": data.amount_reason}
    g = met["udr"]["gain"]
    if a.role == "decide":
        sd_run, df_run, run_src = seed_spread(spreads, "udr")
        terms = None
        if n == 1:
            if sd_run is None:
                raise Refused("a one-seed decision needs the plain model's UDR seed spread: give --spread-fits (its "
                              "kept seed 42, 43, 44 predictions on the same files) or --spread-json")
            terms = t1_terms(met["udr"]["sd"] if met["udr"]["sd"] is not None else float("nan"), sd_run, df_run)
        lb3 = s_d = t3 = df3 = None
        if n > 1:
            lb3, s_d, t3, df3 = lb_three(g, met["udr"]["differences"], met["udr"]["var"] or 0.0)
        decision, reason, changes = decide_add(n, g, terms["t1"] if terms else None, bar, met["udr"]["lo"], lb3,
                                               terms["undefined"] if terms else None)
        final, sel = decision, None
        if changes and a.select_decides:
            sel = select_check(met, float(a.k_select_when_select_decides), spreads, n)
            final, why = finalize(decision, sel)
            reason = f"{reason}; {why} (same read, not independent)"
        rec.update(t1=terms, udr_seed_spread={"sd_run": sd_run, "df": df_run, "source": run_src},
                   lb_bootstrap=met["udr"]["lo"], lb_three_seed=lb3, s_d=s_d, t_three=t3, df_three=df3,
                   decision=decision, final=final, reason=reason, select_check=sel,
                   pending_select_check=bool(changes and not a.select_decides),
                   conflict=conflict_check(met, float(a.k_conflict), spreads, n, data.amount_reason)
                   if changes else None)
    elif a.role == "select-check":
        sel = select_check(met, float(a.k_select), spreads, n)
        if any(r["s_m"] is None for r in sel["rows"]):
            raise Refused("the SELECT check needs each measure's seed spread: give --spread-fits (the plain model's "
                          "kept seed fits on SELECT) and --spread-json (the deciding read's JSON)")
        rec.update(select_check=sel)
    return rec


def screen(rec):
    met = rec["metrics"]
    lines = [f"{rec['role']}: {rec['rows_read']}",
             f"rows {rec['rows']:,}  frauds {rec['frauds']:,}  accounts {rec['accounts']:,}  draws "
             f"{rec['bootstrap']['draws']} seed {rec['bootstrap']['seed']}, whole accounts, the same draws for "
             f"every fit",
             f"{'measure':<7}{'control':>11}{'arm':>11}{'arm-control':>13}{'boot sd':>10}   "
             f"{int(rec['bootstrap']['interval'])}% interval"]
    for m in METRICS:
        r = met[m]
        lines.append(f"{m:<7}{_f(r['control_mean'], 6, False):>11}{_f(r['candidate_mean'], 6, False):>11}"
                     f"{_f(r['gain'], 6):>13}{_f(r['sd'], 6, False):>10}   [{_f(r['lo'], 6)}, {_f(r['hi'], 6)}]")
    if len(met["udr"]["differences"]) > 1:
        lines.append("per-seed UDR differences: " + ", ".join(f"{s}: {d:+.4f}" for s, d in
                                                             zip(rec["seeds"], met["udr"]["differences"])))
    if rec["vdr_null_reason"]:
        lines.append(f"VDR is not defined: {rec['vdr_null_reason']}")
    if rec["role"] == "decide":
        if rec["t1"]:
            t = rec["t1"]
            lines.append(f"T1 {_f(t['t1'], 4, False)} = t {_f(t['t'], 3, False)} (df {_f(t['nu'], 2, False)}) x "
                         f"sqrt(sd_pair^2 {_f(t['a'], 6, False)} + 2 sd_run^2 {_f(t['b'], 6, False)}); seed spread "
                         f"{_f(rec['udr_seed_spread']['sd_run'], 4, False)} (df {rec['udr_seed_spread']['df']}, "
                         f"{rec['udr_seed_spread']['source']})")
        if rec["lb_three_seed"] is not None:
            lines.append(f"LB_3 {rec['lb_three_seed']:+.4f} = gain - t {rec['t_three']:.3f} x sqrt(v_acct + s_d^2/k), "
                         f"s_d {rec['s_d']:.4f}")
        lines.append(f"bar {rec['bar_udr']:+.4f}  account bootstrap LB {_f(rec['lb_bootstrap'])}")
        lines.append(f"DECISION: {rec['final']}  ({rec['reason']})")
        if rec["pending_select_check"]:
            lines.append("pending: the SELECT check (--role select-check on files 8206-8216) makes it final")
        if rec.get("conflict") and rec["conflict"]["line"]:
            lines.append(rec["conflict"]["line"])
    if rec.get("select_check") and rec["role"] == "select-check":
        sc = rec["select_check"]
        for r in sc["rows"]:
            lines.append(f"  {r['metric']:<6} difference {_f(r['difference'])}  limit {_f(r['limit'])}  "
                         f"{'pass' if r['pass'] else 'FAIL'}")
        lines.append(f"SELECT CHECK: {'PASS' if sc['pass'] else 'FAIL'} (k {sc['k_se']}, {sc['n_seeds']} seed(s))")
    if rec["role"] == "report":
        lines.append("report only: this population does not decide")
    return "\n".join(lines)


def main(argv=None):
    ap = argparse.ArgumentParser(description="paired read of the time-encoding arm against its control")
    ap.add_argument("--role", choices=("decide", "select-check", "report"), required=True)
    ap.add_argument("--control", action="append", required=True, help="control predictions, one per seed")
    ap.add_argument("--arm", action="append", required=True, help="arm predictions, one per seed, same order")
    ap.add_argument("--seed-labels", type=int, nargs="+", default=None, help="the seeds, for the screen")
    ap.add_argument("--out", required=True, help="JSON record; refused if it exists (a .txt screen goes beside it)")
    ap.add_argument("--config", default=None, help="the control's config: raw base and S3 access setting")
    ap.add_argument("--raw-base", default=None)
    ap.add_argument("--files", type=int, nargs=2, default=None, metavar=("START", "END"))
    ap.add_argument("--targets", nargs=2, default=list(DEFAULTS["targets"]), metavar=("FROM", "BEFORE"))
    ap.add_argument("--cred", default=None)
    ap.add_argument("--keep-ids", default=None)
    ap.add_argument("--all-rows", action="store_true")
    ap.add_argument("--spread-fits", action="append", nargs="+", default=None,
                    help="the plain model's kept seed fits on the same files (a group of 2 or more; repeat to pool)")
    ap.add_argument("--spread-json", action="append", default=None,
                    help="a read's JSON (its 'spread') or a reader spread file; the larger spread is used")
    ap.add_argument("--select-decides", action="store_true",
                    help="SELECT decides (RANK-B failed its check): the SELECT check runs in the same read, k 3.5")
    ap.add_argument("--bar-udr", type=float, default=DEFAULTS["bar_udr"])
    ap.add_argument("--k-select", type=float, default=DEFAULTS["k_select"])
    ap.add_argument("--k-select-when-select-decides", type=float, default=DEFAULTS["k_select_when_select_decides"])
    ap.add_argument("--k-conflict", type=float, default=DEFAULTS["k_conflict"])
    ap.add_argument("--draws", type=int, default=DEFAULTS["draws"])
    ap.add_argument("--seed", type=int, default=DEFAULTS["seed"])
    ap.add_argument("--interval", type=float, default=DEFAULTS["interval"])
    ap.add_argument("--id", default="fi_transaction_id")
    ap.add_argument("--account", default="Nmap_account_reference_xid")
    ap.add_argument("--label", default="frd_tag")
    ap.add_argument("--score", default="score")
    ap.add_argument("--amount", default="transaction_amt")
    ap.add_argument("--time", default="transaction_dttm")
    a = ap.parse_args(argv)
    c = SimpleNamespace(id=a.id, account=a.account, label=a.label, score=a.score, amount=a.amount, time=a.time)
    out = Path(a.out)
    try:
        if out.exists():
            raise Refused(f"{out} exists; choose a new --out")
        if a.seed_labels and len(a.seed_labels) != len(a.arm):
            raise Refused("--seed-labels needs one seed per --arm")
        rec = run_read(a, c)
    except Refused as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 4
    except Stop as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 3
    text = screen(rec)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(rec, indent=2, default=float))
    out.with_suffix(".txt").write_text(text + "\n")
    print(text)
    print(f"record: {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
