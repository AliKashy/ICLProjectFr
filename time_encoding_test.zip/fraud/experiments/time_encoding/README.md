# Time-encoding test (FraudTransformer paper, arXiv 2509.23712)

The paper's sinusoidal time-gap embedding, added to the chosen model in memory only, with its training and scoring
wrappers, the paired comparison against the control, and the paper's optional one-epoch screen. Steps, commands and
what each result means: `TIME_ENCODING_README.md` at the project root. Tests:
`$PY -m pytest -q tests/experiments/time_encoding`.
