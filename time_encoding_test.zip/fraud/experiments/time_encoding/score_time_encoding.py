"""Score a checkpoint trained by train_time_encoding.py, with the normal scorer and the same embedding.

Where it runs: on the pod, from the project root, on a workbench with nothing else training on its GPU.

Usage, everything after `--` going to the scorer unchanged:

    $PY fraud/experiments/time_encoding/score_time_encoding.py -- <the exact scorer arguments used for the control>

ADAPT: the scorer arguments are those used to score the owner's seed-42 rerun (the control) on the same file range:
the same --config, --population, file range and overrides. Change only --checkpoint (this arm's best.ckpt) and --out
(a new parquet). Three ranges are needed:
- RANK-B, which decides: eval.file_start=8244 eval.file_end=8259;
- SELECT, the one check: eval.file_start=8206 eval.file_end=8216;
- Test 1, reported only: eval.file_start=8000 eval.file_end=8010.
The control needs predictions on the same three ranges (the normal scorer).

The settings are read from the checkpoint ("time_encoding"). A checkpoint without them is a plain model: score it
with the normal scorer instead. The output parquet has the same columns as the normal scorer's.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import te_layout  # noqa: E402
import te_patch  # noqa: E402


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if "--" not in argv:
        raise SystemExit("usage: score_time_encoding.py -- <scorer args>")
    rest = argv[argv.index("--") + 1:]
    if "--checkpoint" not in rest or rest.index("--checkpoint") + 1 >= len(rest):
        print("error: the scorer arguments need --checkpoint <arm>/best.ckpt", file=sys.stderr)
        return 4
    ckpt_path = Path(rest[rest.index("--checkpoint") + 1])
    import torch
    ckpt = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    settings = ckpt.get(te_patch.CHECKPOINT_KEY)
    if not settings:
        print(f"error: {ckpt_path} was not trained with the time-gap encoding; use the normal scorer",
              file=sys.stderr)
        return 4
    del ckpt
    try:
        settings = te_patch.checked(settings)
    except ValueError as exc:
        print(f"error: {ckpt_path}: {exc}", file=sys.stderr)
        return 4
    layout, mods = te_layout.resolve(roles=("base_model", "scorer"))
    te_patch.apply(settings, mods["base_model"].FTTransformerHierModel)
    print(f"time-gap encoding: layout {layout}; settings from the checkpoint {settings}", flush=True)
    rc = mods["scorer"].main(rest)
    return int(rc or 0)


if __name__ == "__main__":
    sys.exit(main())
