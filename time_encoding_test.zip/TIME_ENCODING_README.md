# Time-encoding test on the chosen model (FraudTransformer paper, arXiv 2509.23712)

A test of the paper's time encoding on the chosen model, ALLPOS-H20-CHUNK (the all-position h20 chunk model, scored
on target-ending windows). It trains one extra arm beside the owner's seed-42 rerun (the control), scores it with
the normal scorer through a thin wrapper, and compares arm against control on the same rows. No file of the trainer,
the scorer or the configs is edited.

Unzip at the project root on the pod. Every file is new; nothing existing is replaced.

## 1. The paper's method and what this test adds

The paper's best variant (relative time, learned position, LayerNorm):

- the time id of an event is t_event minus t_previous event, a whole number of milliseconds;
- e_t = [sin(theta x id) ; cos(theta x id)]: all the sines, then all the cosines, with theta_k = f_base^(-2k/d),
  k = 0 .. d/2 - 1, d the model width;
- every token of the event gets e_tok + e_col + p_learn + lambda x LN(e_t); LN has a learned scale and shift and is
  on the time term only; lambda is a fixed setting, not learned;
- the setting was picked by a one-epoch screen judged on validation PRAUC (f_base from 1 to 1e8, lambda 0.01 and
  0.1): lambda 0.01, f_base 1e7.

Only time gets a sinusoid. The paper's numeric fields (amounts, limits and the rest) are binned into tokens and are
never sine encoded.

Note on `continuous_embedding: periodic`: that option re-embeds every numeric input (amount, limits and so on, with
the time gap as one input among about 30). It is a different method, not the paper's, and this test does not use
it. The chosen model keeps `continuous_embedding: linear`; the test adds only the paper's time term.

What the test adds to the chosen model, and nothing else, where the model already adds its learned position
embedding:

    position(i) + lambda x LN([sin(theta x id_i) ; cos(theta x id_i)])

Settings: the paper's chosen ones. lambda (`--gain`) 0.01, f_base (`--base`) 1e7, time id in milliseconds
(`--unit ms`), LayerNorm on; d = 48, the chosen model's width.

### Where our model differs from the paper (all small)

1. Level. The paper adds the term to every token of an event. Our model first pools a transaction's field tokens
   into one transaction vector and adds the position embedding there, so the term is added once per transaction
   vector, beside the position. It is the same information at the hierarchical model's event level.
2. Ties. The model hides rows with the same timestamp from each other, so a tied row measures its gap to the latest
   strictly earlier timestamp (the model's own time_delta rule). The paper would give the second of two same-time
   events a gap of 0.
3. Chunk and window starts. Their first rows get a gap of 0, as in the model's own gap.
4. The model keeps its time_delta input (log1p seconds, one of its continuous inputs). The test adds the paper's
   term and removes nothing.
5. Numeric fields keep their linear embedding; the paper bins them. That is a tokenization choice separate from
   the time idea; changing it would test something else.

The time id is computed in 64-bit integers from the batch's timestamps (`time_seq`, nanoseconds), in whole
milliseconds. The tests check that it equals the model's own time_delta gap times 1000 on every real row of every
training, validation and scoring batch.

## 2. Files

| File | What it does |
|---|---|
| `fraud/experiments/time_encoding/te_patch.py` | The encoding. Patches the model class in memory only. |
| `fraud/experiments/time_encoding/train_time_encoding.py` | Trains the arm: the normal trainer with the patch. |
| `fraud/experiments/time_encoding/score_time_encoding.py` | Scores an arm checkpoint: the normal scorer with the patch. |
| `fraud/experiments/time_encoding/te_compare.py` | The paired comparison and the decision rule. |
| `fraud/experiments/time_encoding/te_ranked.py` | The measures (UDR, AP, AUROC, KS, VDR, FPR) and the account bootstrap. |
| `fraud/experiments/time_encoding/te_screen.py` | Optional: the paper's one-epoch screen of lambda and f_base. |
| `fraud/experiments/time_encoding/te_layout.py` | Finds the project modules: organized names first, then the old ones. |
| `tests/experiments/time_encoding/test_time_encoding.py` | 16 tests. |

## 3. Where each step runs

All on the pod, from the project root. `$PY` is the pod's Python, the one used for training.

| Step | Runs on | Time |
|---|---|---|
| Tests | CPU | about a minute |
| Train an arm | a workbench whose GPU is free | as long as the control's training took |
| Score | GPU, as the normal scorer (a workbench with nothing else training) | as the control's scoring |
| Compare | CPU | minutes per comparison |
| Optional screen | a workbench whose GPU is free | 16 runs of one epoch, one after another |

Every output goes under `runs/time_encoding/`, apart from the other runs.

## 4. Steps

### Step 1. Tests

    $PY -m pytest -q tests/experiments/time_encoding

On the pod the end-to-end test is skipped (it runs on the old code layout only). The other 15 build the pod's own
model class and should pass.

### Step 2. Train the arm at seed 42

    $PY fraud/experiments/time_encoding/train_time_encoding.py -- <CONTROL_TRAIN_ARGS> \
        output.checkpoint_dir=runs/time_encoding/paper_seed42

ADAPT: `<CONTROL_TRAIN_ARGS>` are the exact trainer arguments of the owner's seed-42 rerun of the chosen model (its
`--config` and every override, as in that run's manifest), so the only difference is the encoding. The defaults
are the paper's (`--gain 0.01 --base 1e7 --unit ms`). The first line printed says
`time-gap encoding: layout organized; gain 0.01, base 1e+07, unit ms, layernorm True`.

Keep `training.deterministic` as the control ran it: `false` for the chosen model (the trainer turns it on when the
key is missing). Both runs' `run_manifest_v2.json` show it under `start` (`deterministic` and
`deterministic_in_force`); the two runs should show the same values. If they differ, retrain the arm with the
control's setting before comparing.

### Step 3. Score the arm on the three populations

RANK-B decides, SELECT is checked once, and Test 1 is reported only. Score the arm on each:

    A=runs/time_encoding/paper_seed42
    $PY fraud/experiments/time_encoding/score_time_encoding.py -- --config $A/resolved_train_v2.yaml \
        --checkpoint $A/best.ckpt --out runs/time_encoding/scores/paper_seed42__rank_b.parquet \
        --population OTHER --purpose time_encoding_rank_b_decision eval.file_start=8244 eval.file_end=8259
    $PY fraud/experiments/time_encoding/score_time_encoding.py -- --config $A/resolved_train_v2.yaml \
        --checkpoint $A/best.ckpt --out runs/time_encoding/scores/paper_seed42__select.parquet \
        --population SELECT --purpose time_encoding_select_check eval.file_start=8206 eval.file_end=8216
    $PY fraud/experiments/time_encoding/score_time_encoding.py -- --config $A/resolved_train_v2.yaml \
        --checkpoint $A/best.ckpt --out runs/time_encoding/scores/paper_seed42__test1.parquet \
        --population DEV_OOT --purpose time_encoding_report eval.file_start=8000 eval.file_end=8010

ADAPT: use the same scorer arguments as the control's scoring on these ranges; change only `--checkpoint` and
`--out`. If the run folder's resolved config has another name, use that file. The normal scorer cannot load an arm
checkpoint (it has two extra weights); that is expected.

The comparison also needs, scored with the normal scorer on the same ranges (skip any that already exist):

- the control (the seed-42 rerun) on RANK-B, SELECT and Test 1;
- the seed spread's fits on RANK-B and SELECT: the kept seed 42, 43 and 44 checkpoints of the chosen model, and,
  if they exist, the current base trio (the seed-42 rerun and the base refits at seeds 43 and 44).

### Step 4. The comparison

RANK-B decides if the rank check has cleared it; otherwise see the end of this step. ADAPT: `<CONTROL_CONFIG>` is
the control's training config (the comparison takes the raw files' base and the S3 access setting from it);
`<KEPT_42/43/44_...>` and `<BASE_...>` are the spread fits' prediction files on that range.

    $PY fraud/experiments/time_encoding/te_compare.py --role decide \
        --control <CONTROL_42_RANK_B> --arm runs/time_encoding/scores/paper_seed42__rank_b.parquet \
        --config <CONTROL_CONFIG> --files 8244 8259 \
        --spread-fits <KEPT_42_RANK_B> <KEPT_43_RANK_B> <KEPT_44_RANK_B> \
        --spread-fits <BASE_42_RANK_B> <BASE_43_RANK_B> <BASE_44_RANK_B> \
        --out runs/time_encoding/reads/rank_b_seed42.json

- One `--spread-fits` group gives the kept trio's spread (2 degrees of freedom); two groups are pooled (4 degrees
  of freedom). The `.json` keeps the spread it used, so the SELECT check below takes it from there.
- It uses only the June 2025 target rows of files 8244 to 8259, loaded with full-file history by the project's
  `load_raw` and `target_mask`. Every prediction file must hold those rows with the same labels; if one does not,
  the comparison ends with exit 3 and names the file.

If the decision is ADOPT, the SELECT check makes it final:

    $PY fraud/experiments/time_encoding/te_compare.py --role select-check \
        --control <CONTROL_42_SELECT> --arm runs/time_encoding/scores/paper_seed42__select.parquet \
        --config <CONTROL_CONFIG> --files 8206 8216 \
        --spread-fits <KEPT_42_SELECT> <KEPT_43_SELECT> <KEPT_44_SELECT> \
        --spread-json runs/time_encoding/reads/rank_b_seed42.json \
        --out runs/time_encoding/reads/select_seed42.json

Test 1, reported only (every scored row of files 8000 to 8010; it never decides):

    $PY fraud/experiments/time_encoding/te_compare.py --role report \
        --control <CONTROL_42_TEST1> --arm runs/time_encoding/scores/paper_seed42__test1.parquet \
        --all-rows --out runs/time_encoding/reads/test1_seed42.json

If RANK-B was not cleared and June SELECT decides, run the SELECT comparison with `--role decide --select-decides`
(the SELECT check then runs in the same comparison, with k 3.5).

Each comparison prints a summary and writes a `.json` and a `.txt` beside it. Send back the `.txt` summaries.

### Step 5. What the decision means

The bar is +0.01 UDR at the 0.6% outsort (one point), with a lower bound above 0 and the SELECT check.

- One seed. Gain at or below 0: KEEP THE CONTROL. Gain at or above T_1, at or above the bar, and the account
  bootstrap's lower end above 0: ADOPT, pending the SELECT check. Any other gain above 0: RUN SEEDS 43 AND 44.
  T_1 = t x sqrt(sd_pair^2 + 2 x sd_run^2) is the one-fit noise threshold (sd_pair from the account bootstrap,
  sd_run the plain model's seed spread).
- RUN SEEDS 43 AND 44: train and score the arm at seeds 43 and 44 (steps 2 and 3 with `training.seed=43` or 44
  added and new folders, for example `runs/time_encoding/paper_seed43`). The controls at those seeds are the plain
  chosen model refit with the control's exact command and `training.seed=43` or 44 (existing refits made the same
  way can be reused). The kept seed 43 and 44 checkpoints are not used as controls. Then compare on RANK-B with
  three pairs, in seed order:

      $PY fraud/experiments/time_encoding/te_compare.py --role decide --seed-labels 42 43 44 \
          --control <C42> --arm <A42> --control <C43> --arm <A43> --control <C44> --arm <A44> \
          --config <CONTROL_CONFIG> --files 8244 8259 --out runs/time_encoding/reads/rank_b_3seeds.json

  Three seeds: ADOPT if the mean gain is at or above the bar and LB_3 = gain - t x sqrt(v_acct + s_d^2 / 3) is
  above 0; otherwise KEEP THE CONTROL (unresolved if the gain is above 0). An ADOPT then takes the SELECT check
  with the same three pairs.
- The SELECT check: each of AP, AUROC, KS and UDR must not fall below -2.5 x sqrt(SE_acct^2 + 2 x s_m^2 / n). A
  failed check turns ADOPT into KEEP THE CONTROL.

### Step 6 (optional). The paper's screen of lambda and f_base

The paper chose its setting with this screen. Our gaps (seconds to weeks between card transactions) differ from
its events, so the best f_base here may differ. Validation files only; Test 1, SELECT and RANK-B are not touched.

    $PY fraud/experiments/time_encoding/te_screen.py run -- <CONTROL_TRAIN_ARGS>
    $PY fraud/experiments/time_encoding/te_screen.py collect \
        --control-metrics <the control's run folder>/training_metrics.csv

`run` trains 16 pairs (f_base 1, 10, 1e3, 1e4, 1e5, 1e6, 1e7, 1e8 times lambda 0.01, 0.1; the paper ran 14 of
them, 1e4 only at lambda 0.1 and 1e5 only at 0.01), one epoch each, under `runs/time_encoding/screen/`. A finished
pair is skipped, so the same command continues after a stop. `--dry-run` prints the commands only. `collect` ranks
the pairs by epoch-0 `valid_ap`. If the best pair is not the paper's (1e7, 0.01), train it as a second arm (step 2
with `--base` and `--gain`, folder for example `runs/time_encoding/screen_best_seed42`) and compare it the same way.

## 5. What to send back

The `.txt` summaries of the comparisons (step 4), the first lines of the arm's training log (the settings line),
and, if the screen ran, the `collect` table.
