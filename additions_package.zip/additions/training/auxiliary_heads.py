"""Auxiliary heads: extra training targets taken from the account's whole timeline.

What this file does
-------------------
It builds extra yes/no targets for every row, gives each target a small head on the row
vector, and adds their losses to the fraud loss under a cap:

    build_targets      the target columns, from a table of raw rows:
                         fraud_prev_1h, _24h, _72h, _7d   a fraud was labelled on the account in the
                                                          previous hour, day, three days, week
                         fraud_next_24h, _7d              a fraud is labelled on the account within
                                                          the next day, week (looks FORWARD)
                         risk_decline                     the bank declined this very row for risk
    AuxiliaryHeads     one linear head per target, all on the same row vector
    auxiliary_losses   the cross-entropy of every head over the rows that have a target
    capped_total       the fraud loss plus the auxiliary losses, each held to the size of the
                       fraud loss
    head_columns       the heads' outputs as columns for export

Every one of these targets is made of things a model must not read when it scores a row:
the labels of other rows, rows that come later, the bank's decision on the row itself. Here
they are targets and only targets. The labels of other rows are never inputs; the columns of
`build_targets` must never be joined to the model's inputs, and the heads' outputs must not
be fed back into the fraud score.

Why it exists
-------------
The fraud label marks single rows. The account's timeline knows more. Frauds come in runs on
one account, so most frauds follow an earlier fraud of that account, and a model whose row
vector holds "this account is in a run" is ahead on every follow-on fraud. That fact cannot
be an input, because fraud labels arrive weeks after the transaction. It can be a target:
the `fraud_prev` heads ask the vector of every row whether a fraud happened shortly before,
and to answer, the history stage has to learn the traces a fraud leaves in the rows after it.
A row two steps after a fraud can judge that fraud far better than the fraud row itself.

The `fraud_next` heads ask the opposite question and mark the rows before a run: the small
test purchases and the declined attempts that come before the first labelled fraud, which
the fraud label calls clean. The `risk_decline` head adds a target with many more positives
than the fraud label has. A fraud label sits only on approved rows, so the fraud head alone
learns "approved and fraud"; the decline head hands the shared vector the other half, what
the bank's own systems judged risky.

A plain sum of losses can hurt the main task. The side targets are far more frequent than
fraud, so their losses are larger and so are their gradients. In a plain sum the shared
vector is shaped mostly by the side targets and the fraud head gets what is left over.
`capped_total` scales every side loss down to the size of the fraud loss whenever it is
larger, so no side target can outweigh the main one. The price of side targets is a risk to
watch: honest rows inside a run may score higher and take places in the alert budget.

Where it goes
-------------
Raw files, then the loader, then head and loss, then exports. The targets are per-row
arrays like the label (in the original code those are made in `SequenceBuilder._encode_file`
and the label travels as `target_seq`). The heads read the vector the fraud head reads (in
`FTTransformerHierModel.forward` that is `out[:, 1:]`, just before `self.head`), and
`capped_total` takes the place of the single loss in `FTTransformerHierModel._step`.
Scoring is unchanged: the heads are not needed for the fraud score.

What to change for the pod
--------------------------
`settings.ACCOUNT_COL`, `TIME_COL`, `LABEL_COL`, `POSITIVE_LABEL`, `REASON_COL`,
`RISK_DECLINE_REASONS`, `ADVICE_COL` and `EMBED_DIM`; the windows in `PREVIOUS_WINDOWS` and
`NEXT_WINDOWS`; `data_start` and `data_end` when the table does not hold whole files. Whether
the bank's decision may serve as a training target is a question for the data owner.

How to try it
-------------
    python additions/training/auxiliary_heads.py --demo
    python additions/training/auxiliary_heads.py --base /path/to/files --files 1 2 --out targets.parquet

    targets = build_targets(df)                                  # df: whole files
    heads = AuxiliaryHeads(TARGET_NAMES)
    side = auxiliary_losses(heads(row_vectors), {name: target_tensor, ...})
    loss = capped_total(fraud_loss, side)
    python -m pytest -q additions/tests/test_training_auxiliary_heads.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F

from additions import settings
from additions.common import synthetic, tables, timekeys
from additions.common.history import EarlierRows, later_rows
from additions.common.timekeys import MISSING_SECOND
from additions.training._loss_shared import weighted_mean

# The windows of the run-state targets (looking back) and of the forward targets, as (label, seconds).
PREVIOUS_WINDOWS = (("1h", 3_600), ("24h", 86_400), ("72h", 72 * 3_600), ("7d", 7 * 86_400))
NEXT_WINDOWS = (("24h", 86_400), ("7d", 7 * 86_400))

# The names of all targets, in the order of the columns. A head is named after its target.
TARGET_NAMES = tuple([f"fraud_prev_{label}" for label, _ in PREVIOUS_WINDOWS]
                     + [f"fraud_next_{label}" for label, _ in NEXT_WINDOWS] + ["risk_decline"])

# The prefix of the target columns. It says what they are, so that none is taken for an input.
TARGET_PREFIX = "target_"


def needed_columns():
    """The raw columns `build_targets` reads (None entries are optional columns that are switched off)."""
    return [settings.ACCOUNT_COL, settings.TIME_COL, settings.ID_COL, settings.LABEL_COL, settings.REASON_COL,
            settings.ADVICE_COL]


def _has_code(values, codes):
    """Yes/no per row: is the value one of `codes`? A missing value never is.

    A column of numbers is compared as numbers (the code "05" matches 5), a column of text as
    text with blanks stripped. The codes in settings are written as text.
    """
    series = pd.Series(np.asarray(values))
    if pd.api.types.is_numeric_dtype(series.dtype):
        numbers = []
        for code in codes:
            try:
                numbers.append(float(code))
            except (TypeError, ValueError):
                pass                                   # a code such as "Y" cannot match a number
        return np.isin(series.to_numpy(dtype=np.float64), numbers)
    return (series.notna() & series.astype(str).str.strip().isin([str(c).strip() for c in codes])).to_numpy()


def _second(value, fallback):
    """A date as text, a Timestamp or a number of seconds, as whole seconds; None gives `fallback`."""
    if value is None:
        return int(fallback)
    if isinstance(value, (int, float, np.integer, np.floating)):
        return int(value)
    return int(timekeys.seconds(pd.Series([pd.Timestamp(value)]))[0])


def build_targets(df, account_col=None, time_col=None, label_col=None, positive_label=None, reason_col=None,
                  risk_reasons=None, advice_col=None, data_start=None, data_end=None, next_on_fraud_rows=True,
                  prefix=TARGET_PREFIX):
    """The auxiliary target columns for every row of `df`.

    df            every row of one or more whole files (whole account histories), in any order
    account_col, time_col, label_col, reason_col, advice_col   column names; None reads settings
    positive_label   the value of the label column that means fraud; None reads settings
    risk_reasons  the response codes that mean "declined for risk"; None reads settings
    data_start    the first second of data (a date as text, a Timestamp or seconds); None takes
                  the earliest time in the table
    data_end      the first second after the data; None takes the latest time in the table plus
                  one second. Pass an earlier moment to leave out the last weeks as well, in
                  which fraud labels are still arriving
    next_on_fraud_rows   False gives fraud rows no forward target. After the first fraud of a
                  run "a fraud follows" is nearly the same as "the run goes on"; without the
                  fraud rows the target is about the rows before a run
    prefix        put in front of every column name

    Returns a DataFrame [rows, 7] of float32 with the index of `df` (6 columns when there is
    no response-code column): 1.0, 0.0, or a missing value where the row has no target. A
    missing value means "leave this row out of the loss of this head", never "zero".

    Which rows get no target:
      fraud_prev_<w>   rows closer than the window to the start of the data: the window
                       reaches back to before the files begin, so "no fraud seen" is not "no fraud"
      fraud_next_<w>   rows closer than the window to the end of the data, for the same reason
                       on the other side
      risk_decline     rows without a response code, and advice rows (a notice, no decision)
      all of them      rows without a time

    Time rule. `fraud_prev` uses the labels of rows of strictly earlier seconds of the account
    and `fraud_next` those of strictly later seconds; rows of one second never count for each
    other. All three kinds are targets. `fraud_next` looks forward in time and `risk_decline`
    is the outcome of the row itself: neither may ever be an input. `fraud_prev` may not be
    one either, because the labels of the last days are not known when a row is scored.
    """
    account = timekeys.codes(df[settings.ACCOUNT_COL if account_col is None else account_col])
    secs = timekeys.seconds(df[settings.TIME_COL if time_col is None else time_col])
    positive = settings.POSITIVE_LABEL if positive_label is None else positive_label
    fraud = _has_code(df[settings.LABEL_COL if label_col is None else label_col], (positive,))
    placed = secs != MISSING_SECOND
    start = _second(data_start, secs[placed].min() if placed.any() else 0)
    end = _second(data_end, secs[placed].max() + 1 if placed.any() else 0)

    out = {}
    # Run state: was a fraud labelled on the account in the window before this row? The engine counts
    # rows of strictly earlier seconds only, so the row's own label and the labels of its second stay out.
    # A row without a time holds the most negative whole number; adding or subtracting a window from it
    # would wrap around, so the window edges are only compared on the rows that have a time.
    safe_secs = np.where(placed, secs, start)
    before = EarlierRows(account, secs)
    for label, window in PREVIOUS_WINDOWS:
        target = (before.count(window, where=fraud) > 0).astype(np.float32)
        target[~placed | (safe_secs - window < start)] = np.nan
        out[f"{prefix}fraud_prev_{label}"] = target
    # Foresight: is a fraud labelled on the account in the window after this row? This is the same
    # engine with time reversed. It reads the future, which is why the result can only be a target.
    after = later_rows(account, secs)
    for label, window in NEXT_WINDOWS:
        target = (after.count(window, where=fraud) > 0).astype(np.float32)
        target[~placed | (safe_secs + window >= end)] = np.nan
        if not next_on_fraud_rows:
            target[fraud] = np.nan
        out[f"{prefix}fraud_next_{label}"] = target

    # The bank's decision on the row itself. Declines are far more frequent than fraud labels, which is
    # what makes them useful as a target and dangerous as an unweighted loss (see `capped_total`).
    reason_col = settings.REASON_COL if reason_col is None else reason_col
    advice_col = settings.ADVICE_COL if advice_col is None else advice_col
    if not reason_col or reason_col not in df.columns:
        print("note: no response-code column is set or found; the risk_decline target is skipped")
    else:
        reasons = settings.RISK_DECLINE_REASONS if risk_reasons is None else risk_reasons
        target = _has_code(df[reason_col], reasons).astype(np.float32)
        decided = df[reason_col].notna().to_numpy() & placed
        if advice_col and advice_col in df.columns:
            decided &= df[advice_col].isna().to_numpy()
        else:
            print("note: no advice column is set or found; advice rows keep their risk_decline target")
        target[~decided] = np.nan
        out[f"{prefix}risk_decline"] = target
    return pd.DataFrame(out, index=df.index)


def target_summary(targets):
    """One line per target column: rows with a target, their share of all rows, and the share of ones."""
    lines = []
    for name in targets.columns:
        values = targets[name].to_numpy(dtype=np.float64)
        have = ~np.isnan(values)
        lines.append({"target": name, "rows_with_target": int(have.sum()),
                      "share_with_target": have.mean() if len(values) else np.nan,
                      "share_of_ones": values[have].mean() if have.any() else np.nan})
    return pd.DataFrame(lines, columns=["target", "rows_with_target", "share_with_target", "share_of_ones"])


class AuxiliaryHeads(nn.Module):
    """One small linear head per auxiliary target, all reading the same row vector.

    names   the targets, one head each (default: `TARGET_NAMES`)
    dim     the width of the row vector; None reads settings.EMBED_DIM

    The heads are linear on purpose. A head with layers of its own could work the answer
    out by itself; a linear head can only read what the shared vector already holds, so the
    side loss has to put the knowledge into the vector, where the fraud head finds it too.
    """

    def __init__(self, names=TARGET_NAMES, dim=None):
        super().__init__()
        dim = settings.EMBED_DIM if dim is None else dim
        self.heads = nn.ModuleDict({name: nn.Linear(dim, 1) for name in names})

    def forward(self, vectors):
        """vectors float [..., dim] -> {name: float [...]}: one log-odds value per row and target."""
        return {name: head(vectors).squeeze(-1) for name, head in self.heads.items()}


def auxiliary_losses(head_logits, targets, row_weight=None):
    """The cross-entropy of every head, over the rows that have a target.

    head_logits   {name: float [...]} from `AuxiliaryHeads`
    targets       {name: float [...]}: 1.0, 0.0, or a missing value for "no target" (padding
                  included); a head without an entry here is skipped
    row_weight    None or float [...]: further row weights, the same for every head

    Returns {name: scalar tensor}. A head whose target is missing on every row of the batch
    gets a loss of zero that is still tied to the network, so the step runs on.
    """
    losses = {}
    for name, logits in head_logits.items():
        if name not in targets:
            continue
        target = targets[name].to(logits.dtype)
        has = torch.isfinite(target).to(logits.dtype)
        # A missing target is replaced by 0 before the loss is taken and its weight is 0 afterwards.
        per_row = F.binary_cross_entropy_with_logits(logits, torch.nan_to_num(target, nan=0.0), reduction="none")
        losses[name] = weighted_mean(per_row, has if row_weight is None else has * row_weight)
    return losses


def capped_total(main_loss, aux_losses, weight=1.0):
    """The main loss plus the auxiliary losses, none of which may count for more than the main loss.

    main_loss    scalar tensor: the fraud loss
    aux_losses   {name: scalar tensor} or a list of scalar tensors
    weight       multiplies the capped mean; 1.0 adds it in full

    Returns a scalar tensor:
        main + weight * mean over k of ( min(1, main / aux_k) * aux_k )
    Each scaled auxiliary loss equals min(aux_k, main), so none exceeds the main loss, and
    their mean does not either: however many heads there are, together they weigh at most as
    much as the fraud loss.

    The scale min(1, main / aux_k) is computed from detached values, so it acts as a plain
    number in this step. If gradients flowed through it, the network could lower its loss
    by raising the fraud loss (a higher cap) or by gaming the ratio instead of learning the
    target. An auxiliary loss that is already below the main loss is left as it is.
    """
    losses = list(aux_losses.values()) if isinstance(aux_losses, dict) else list(aux_losses)
    if not losses:
        return main_loss
    capped = []
    for loss in losses:
        scale = (main_loss.detach() / loss.detach().clamp_min(1e-12)).clamp(max=1.0)
        capped.append(scale * loss)
    return main_loss + weight * torch.stack(capped).mean()


def head_columns(head_logits, fraud_logits=None, prefix="aux_"):
    """The heads' outputs as columns for export.

    head_logits    {name: float [rows]} from `AuxiliaryHeads`, for the rows to export
    fraud_logits   None or float [rows]: the fraud head's log-odds for the same rows

    Returns {column name: float32 numpy array [rows]}: the probability of every target, named
    prefix + target name. With a `risk_decline` head and `fraud_logits` there is one more
    column, `risk_if_approved`: the fraud log-odds plus the log of 1 / (chance of no risk
    decline). The fraud head scores a row low when the bank will probably decline it, because
    declined rows never carry the label; this column divides that effect out again.

    These columns are for other models and for case work, as account-level signals. They
    are not inputs of this model.
    """
    columns = {prefix + name: torch.sigmoid(logits.detach()).float().cpu().numpy()
               for name, logits in head_logits.items()}
    if fraud_logits is not None and "risk_decline" in head_logits:
        # log(1 / (1 - p_decline)) is softplus(decline log-odds).
        risk = fraud_logits.detach() + F.softplus(head_logits["risk_decline"].detach())
        columns[prefix + "risk_if_approved"] = risk.float().cpu().numpy()
    return columns


def main(argv=None):
    """Command line: build the target columns for some files (or made-up rows) and print how often each is 1."""
    parser = argparse.ArgumentParser(description="Auxiliary training targets from the account's whole timeline.")
    parser.add_argument("--base", default=settings.TRAIN_BASE, help="folder that holds the numbered files")
    parser.add_argument("--files", type=int, nargs="+", default=None,
                        help="file numbers to read (default: settings.TRAIN_FILES)")
    parser.add_argument("--demo", action="store_true", help="run on made-up rows instead of files")
    parser.add_argument("--out", default=None,
                        help="write the target columns, with the transaction id, to this parquet file")
    args = parser.parse_args(argv)
    if args.demo:
        df = synthetic.make_transactions(n_accounts=300, seed=1)
    else:
        df = tables.read_files(args.base, args.files or settings.TRAIN_FILES, needed_columns())
    targets = build_targets(df)
    print(f"{len(targets)} rows, {targets.shape[1]} target columns")
    print(target_summary(targets).to_string(index=False, float_format=lambda x: f"{x:.4f}"))
    if args.out:
        out = targets.copy()
        if settings.ID_COL in df.columns:
            out.insert(0, settings.ID_COL, df[settings.ID_COL].to_numpy())
        tables.write_table(out, args.out)
        print(f"written: {args.out}")
    return targets


if __name__ == "__main__":
    main()
