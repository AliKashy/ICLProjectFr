"""Account sampling: keep every fraud account and a share of the others.

What this file does
-------------------
It chooses which accounts a training run reads and how much each kept row counts:

    account_draw      one number in [0, 1) per account, from a seed, by plain integer
                      arithmetic on the account id. The same account gets the same number
                      whatever files are read and in whatever order
    sample_accounts   per row: is the account kept, is it a fraud account, is it a "risky"
                      clean account, how likely a row like this one was to stay in the loss,
                      and the row's loss weight
    sampling_offset   per row, the amount to add to the model's log-odds during training so
                      that the model learns the log-odds of the unsampled population
    undo_sampling     the constant (the log of the share) to add to a log-odds score after
                      training when probabilities are needed
    bags              several samples with different seeds: the same fraud accounts, other
                      clean accounts
    sample_summary    a plain table of what a sample keeps

Every fraud account is kept whole. Of the clean accounts (accounts without any fraud label in
the rows read) a share S is kept whole and the rest are left out of the run. Optionally, every
clean account whose highest risk score lies above a quantile of all rows' scores is kept as
well: those are the clean accounts that look like fraud, the ones whose rows compete with
frauds for the alert places. Two ways keep the ranking honest:

    mode "mask"    the non-fraud rows of fraud accounts stay in the sequences as history, but
                   each one is in the loss only with probability S. Every non-fraud row then
                   reaches the loss at the same rate S, so the model's log-odds are the full
                   population's log-odds minus a constant, and the ranking is untouched.
    mode "weight"  every row of a kept account is in the loss, and the kept non-fraud rows of
                   sampled clean accounts carry the weight 1/S, so they stand for the clean
                   accounts that were left out.

Why it exists
-------------
What a fraud model can learn grows with the number of frauds it reads, not with the number of
rows. Clean accounts are the great majority of accounts and of rows, and past a point another
clean account teaches almost nothing new. Thinning them buys more files, and so more fraud
accounts, in the same training time. Whole accounts are kept or dropped, never single rows, so
every kept account keeps its full history and the strictly-earlier rule is untouched. The files
hold whole accounts and no account is in two files, so an account's fraud status can be read
from the files it is in.

Random thinning removes the hard clean accounts at the same rate as the easy ones, and the hard
ones decide the top of the ranking. Keeping the risky clean accounts at rate one protects them.
Their non-fraud rows then reach the loss at a higher rate than the others, which `keep_prob`
records and `sampling_offset` corrects.

Choosing fraud accounts reads the labels of the account's rows, including later rows. That is
a choice of training data, not an input: no label ever enters a row's features. Validation and
scored files are never sampled.

Where it goes
-------------
Raw files, before the sequence builder (in the original code `SequenceBuilder._encode_file`):
rows of accounts that are not kept are dropped before chunks are built, and `loss_weight`
travels beside the label as one more per-row array. In the loss
(`FTTransformerHierModel._step`) the per-row cross-entropy becomes a weighted mean
(`_loss_shared.weighted_mean`); in mode "mask" with risky accounts, `sampling_offset` is added
to the log-odds before the loss. `undo_sampling` is applied to scores only where a probability,
not a ranking, is needed (a second-stage model that reads the score, an amount tilt).

What to change for the pod
--------------------------
settings.py: ACCOUNT_COL, TIME_COL, ID_COL, LABEL_COL, POSITIVE_LABEL, VISA_SCORE_COL (the
default risk score for the risky-account rule; a pilot model's score column works as well),
TRAIN_BASE and TRAIN_FILES. The share, the mode, the seeds and the risky quantile are
arguments. Account ids are read as text for the draw, so numeric ids work unchanged.

How to try it
-------------
    python additions/training/account_sampling.py --demo --share 0.25 --seeds 0 1 2
    python additions/training/account_sampling.py --base /path/to/files --files 1 2 3 --share 0.1 --risky-quantile 0.98

    sample = sample_accounts(df, share=0.25, seed=0)            # DataFrame, one line per row of df
    train_rows = df[sample["account_kept"].to_numpy()]
    loss_weight = sample["loss_weight"].to_numpy()[sample["account_kept"].to_numpy()]
    probability = sigmoid(undo_sampling(logits, 0.25))
    python -m pytest -q additions/tests/test_rows_account_sampling.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd
import torch

from additions import settings
from additions.common import synthetic, tables, timekeys

# Constants of the integer mixing step below (the "splitmix64" finaliser). They are fixed
# numbers of a well known mixing function, not data; changing them changes every draw.
_MIX_A = np.uint64(0xBF58476D1CE4E5B9)
_MIX_B = np.uint64(0x94D049BB133111EB)
_STEP = np.uint64(0x9E3779B97F4A7C15)
_PRIME = np.uint64(1099511628211)

MODES = ("mask", "weight")


def _mix(x):
    """Scramble 64-bit integers so that close inputs give unrelated outputs (wrap-around arithmetic)."""
    x = np.asarray(x, dtype=np.uint64)
    with np.errstate(over="ignore"):
        x = x ^ (x >> np.uint64(30))
        x = x * _MIX_A
        x = x ^ (x >> np.uint64(27))
        x = x * _MIX_B
        x = x ^ (x >> np.uint64(31))
    return x


def _uniform(x):
    """Mixed 64-bit integers as numbers in [0, 1): the top 53 bits divided by 2**53."""
    return (x >> np.uint64(11)).astype(np.float64) / float(2 ** 53)


def _id_integers(values):
    """One 64-bit integer per value, from the bytes of the value written as text.

    values   array [n] of account ids (text or numbers)

    Returns uint64 [n]. The same text always gives the same integer, on any machine. The loop
    runs over byte positions (the length of the longest id, a few dozen at most), never over
    ids, so a million accounts take one vectorised step per byte position.
    """
    text = np.asarray(pd.Series(values).astype(str).to_numpy(), dtype=str)
    raw = np.char.encode(text, "utf-8")                        # fixed-width bytes, padded with zeros
    width = raw.dtype.itemsize
    if len(raw) == 0 or width == 0:
        return np.zeros(len(raw), dtype=np.uint64)
    as_bytes = raw.view(np.uint8).reshape(len(raw), width).astype(np.uint64)
    out = np.full(len(raw), np.uint64(14695981039346656037), dtype=np.uint64)
    with np.errstate(over="ignore"):
        for j in range(width):                                  # a loop over byte positions only
            out = (out ^ (as_bytes[:, j] + np.uint64(1))) * _PRIME
        lengths = np.char.str_len(raw).astype(np.uint64)
        out = out ^ (lengths * _STEP)                           # "ab" and "ab\0" never collide by padding
    return out


def account_draw(account_values, seed=0):
    """One number in [0, 1) per account, the same for an account wherever and whenever it is read.

    account_values   array [n] of account ids (one per account or one per row; repeats are fine)
    seed             an integer; another seed gives an unrelated set of numbers

    Returns float64 [n]. The number is computed from the account id and the seed alone, by
    integer arithmetic, so it does not depend on which files were read, on the row order or on
    the other accounts present. An account kept at share 0.25 is therefore also kept at share
    0.5 with the same seed, and two runs on overlapping files agree on the accounts they share.
    """
    ids = _id_integers(account_values)
    with np.errstate(over="ignore"):
        seed_part = _mix(np.uint64(int(seed) & 0xFFFFFFFFFFFFFFFF) + _STEP)
    return _uniform(_mix(ids ^ seed_part))


def _is_fraud(values, positive):
    """Yes/no per row: the label equals the positive value (compared as numbers when it can be)."""
    series = pd.Series(np.asarray(values))
    if pd.api.types.is_numeric_dtype(series.dtype):
        try:
            return series.to_numpy(dtype=np.float64) == float(positive)
        except (TypeError, ValueError):
            return np.zeros(len(series), dtype=bool)
    return (series.notna() & (series.astype(str).str.strip() == str(positive).strip())).to_numpy()


def sample_accounts(df, share=0.25, seed=0, mode="mask", risky_quantile=None, risk_col=None, account_col=None,
                    time_col=None, id_col=None, label_col=None, positive_label=None):
    """Which accounts a training run keeps, and the loss weight of every row.

    df               a table of raw rows from whole files (whole account histories), any order
    share            S, the share of clean accounts kept, between 0 (exclusive) and 1
    seed             the seed of the account draw; another seed gives another bag
    mode             "mask" or "weight" (see the module text)
    risky_quantile   None, or a number such as 0.98: clean accounts with a row whose risk score
                     is above this quantile of all rows' scores are kept at rate one
    risk_col         the risk score column for that rule; None reads settings.VISA_SCORE_COL
    account_col, time_col, id_col, label_col, positive_label   None reads settings

    Returns a DataFrame with the index of `df` and these columns, one line per row:
      fraud_account   bool: the account has a fraud label on some row read
      risky_account   bool: a clean account kept by the risk-score rule
      account_kept    bool: the account is in the training run (every row of it, as history)
      keep_prob       float64: the probability that a non-fraud row like this one reaches the
                      loss (1.0 on fraud rows). Rows of dropped accounts carry their share too
      loss_weight     float32: the row's weight in the loss; 0.0 on rows of dropped accounts and
                      on masked non-fraud rows of fraud accounts (which stay as history)
    """
    if not 0.0 < share <= 1.0:
        raise ValueError(f"share must be in (0, 1], got {share}")
    if mode not in MODES:
        raise ValueError(f"mode must be one of {MODES}, got {mode!r}")
    account_values = df[settings.ACCOUNT_COL if account_col is None else account_col].to_numpy()
    positive = settings.POSITIVE_LABEL if positive_label is None else positive_label
    fraud = _is_fraud(df[settings.LABEL_COL if label_col is None else label_col], positive)
    account = timekeys.codes(account_values)
    n_accounts = int(account.max()) + 1 if len(account) else 0

    # Account level: fraud status, the draw, and the risky-account rule.
    fraud_account = (np.bincount(account, weights=fraud, minlength=n_accounts) > 0)[account]
    # The codes run from 0 to n_accounts - 1, so the first row of each code, in code order, gives
    # one id per account and every per-account array below is indexed by the code.
    first_row = np.unique(account, return_index=True)[1]
    account_ids = account_values[first_row]
    draw = account_draw(account_ids, seed)
    picked = draw[account] < share
    risky = np.zeros(len(df), dtype=bool)
    if risky_quantile is not None:
        risk_col = settings.VISA_SCORE_COL if risk_col is None else risk_col
        if not risk_col or risk_col not in df.columns:
            print(f"note: no risk score column ('{risk_col}') for the risky-account rule; that rule is skipped")
        else:
            score = pd.to_numeric(df[risk_col], errors="coerce").to_numpy(dtype=np.float64)
            have = np.isfinite(score)
            if have.any():
                cut = np.quantile(score[have], risky_quantile)
                highest = np.full(n_accounts, -np.inf)
                np.maximum.at(highest, account[have], score[have])
                risky = (highest > cut)[account] & ~fraud_account
    kept = fraud_account | risky | picked

    # Row level: how likely a non-fraud row of this kind is to reach the loss, and its weight.
    keep_prob = np.full(len(df), float(share))
    keep_prob[risky] = 1.0
    weight = np.zeros(len(df), dtype=np.float32)
    clean_kept = kept & ~fraud_account
    if mode == "weight":
        # Every row of a kept account is in the loss. Non-fraud rows of fraud accounts were all
        # kept (rate one); rows of sampled clean accounts stand for 1/S accounts each.
        keep_prob[fraud_account] = 1.0
        weight[fraud_account] = 1.0
        weight[clean_kept] = (1.0 / keep_prob[clean_kept]).astype(np.float32)
    else:
        # Each non-fraud row of a fraud account reaches the loss with probability S. The draw is
        # per row and comes from the account's number and the row's place in the account, so it
        # is repeatable and does not depend on the other accounts read.
        secs = timekeys.seconds(df[settings.TIME_COL if time_col is None else time_col])
        id_col = settings.ID_COL if id_col is None else id_col
        tie = df[id_col].to_numpy() if id_col and id_col in df.columns else None
        order = timekeys.stable_order(account, secs, tie)
        place = np.empty(len(df), dtype=np.int64)
        sorted_account = account[order]
        new = np.ones(len(df), dtype=bool)
        new[1:] = sorted_account[1:] != sorted_account[:-1]
        start = np.maximum.accumulate(np.where(new, np.arange(len(df)), 0)) if len(df) else new
        place[order] = np.arange(len(df)) - start
        # A salt of seed + 1 keeps the row draw unrelated to the account draw of the same seed.
        account_part = _mix(_id_integers(account_ids) ^ _mix(np.uint64((int(seed) + 1) & 0xFFFFFFFFFFFFFFFF)))
        with np.errstate(over="ignore"):
            row_part = _mix(place.astype(np.uint64) + _STEP)
        row_draw = _uniform(_mix(account_part[account] ^ row_part))
        in_loss = fraud | (row_draw < share)
        weight[fraud_account & in_loss] = 1.0
        weight[clean_kept] = 1.0
    keep_prob[fraud] = 1.0
    weight[fraud & kept] = 1.0
    weight[~kept] = 0.0
    return pd.DataFrame({"fraud_account": fraud_account, "risky_account": risky, "account_kept": kept,
                         "keep_prob": keep_prob, "loss_weight": weight}, index=df.index)


def sampling_offset(keep_prob):
    """The amount to add to the model's log-odds during training, per row: minus the log of `keep_prob`.

    keep_prob   [rows] numpy array or tensor: the `keep_prob` column of `sample_accounts`

    Returns the same kind of array, float. When non-fraud rows reach the loss at rate q, the
    odds of fraud among the rows that do are the true odds divided by q. Training on
    (model log-odds - log q) instead of the model log-odds makes the model itself learn the
    true log-odds: the offset absorbs the sampling. It matters when q differs between rows (mode
    "mask" with risky accounts kept at rate one). It is used in the loss only, never at scoring.
    """
    if torch.is_tensor(keep_prob):
        return -torch.log(keep_prob.clamp_min(1e-12))
    return -np.log(np.clip(np.asarray(keep_prob, dtype=np.float64), 1e-12, None))


def undo_sampling(logits, share):
    """Log-odds of a model trained on sampled rows, moved back to the unsampled population.

    logits   [rows] numpy array or tensor: the model's fraud log-odds
    share    S, the rate at which non-fraud rows reached the loss

    Returns logits + log(S), the same kind of array. The ranking of rows does not change (one
    constant is added to every row), so the alert cut and the capture are the same with and
    without it. It is needed only where the score is read as a probability. It is exact when
    every non-fraud row reached the loss at the same rate S and no offset was used in training;
    a model trained with `sampling_offset` or in mode "weight" needs no correction.
    """
    return logits + float(np.log(share))


def bags(df, share=0.25, seeds=(0, 1, 2), **options):
    """Several samples of the same table with different seeds, one per seed.

    df, share   as in `sample_accounts`
    seeds       one sample per seed
    options     passed on to `sample_accounts` (mode, risky_quantile, column names)

    Returns {seed: DataFrame}. Every bag keeps the same fraud accounts and the same risky
    accounts and a different random share of the other clean accounts. Models trained on
    different bags make different mistakes on clean rows, so the mean of their log-odds is
    steadier than any one of them; that mean can then teach one model that ships.
    """
    return {int(seed): sample_accounts(df, share=share, seed=seed, **options) for seed in seeds}


def sample_summary(df, sample, account_col=None, label_col=None, positive_label=None):
    """A plain table of what one sample keeps: accounts, rows, frauds and the loss weight.

    df       the table that was sampled
    sample   what `sample_accounts` returned for it
    account_col, label_col, positive_label   None reads settings

    Returns a DataFrame with one line per measure and two columns: all, kept.
    """
    account = timekeys.codes(df[settings.ACCOUNT_COL if account_col is None else account_col])
    positive = settings.POSITIVE_LABEL if positive_label is None else positive_label
    fraud = _is_fraud(df[settings.LABEL_COL if label_col is None else label_col], positive)
    kept = sample["account_kept"].to_numpy()
    weight = sample["loss_weight"].to_numpy(dtype=np.float64)
    fraud_account = sample["fraud_account"].to_numpy()
    risky = sample["risky_account"].to_numpy()
    lines = [
        ("accounts", len(np.unique(account)), len(np.unique(account[kept]))),
        ("fraud accounts", len(np.unique(account[fraud_account])), len(np.unique(account[fraud_account & kept]))),
        ("risky clean accounts", len(np.unique(account[risky])), len(np.unique(account[risky & kept]))),
        ("rows (as history)", len(df), int(kept.sum())),
        ("rows in the loss", len(df), int((weight > 0).sum())),
        ("fraud rows in the loss", int(fraud.sum()), int((fraud & (weight > 0)).sum())),
        ("weighted non-fraud rows", int((~fraud).sum()), round(float(weight[~fraud].sum()), 1)),
    ]
    # The table is kept as plain objects so whole counts print without a decimal point.
    return pd.DataFrame(lines, columns=["measure", "all", "kept"], dtype=object)


def needed_columns(risk_col=None):
    """The raw columns this file reads (None entries are optional columns that are switched off)."""
    return [settings.ACCOUNT_COL, settings.TIME_COL, settings.ID_COL, settings.LABEL_COL,
            settings.VISA_SCORE_COL if risk_col is None else risk_col]


def main(argv=None):
    """Command line: sample the accounts of some files (or made-up rows) and print what each bag keeps."""
    parser = argparse.ArgumentParser(description="Keep every fraud account and a share of the clean accounts.")
    parser.add_argument("--base", default=settings.TRAIN_BASE, help="folder that holds the numbered files")
    parser.add_argument("--files", type=int, nargs="+", default=None,
                        help="file numbers to read (default: settings.TRAIN_FILES)")
    parser.add_argument("--demo", action="store_true", help="run on made-up rows instead of files")
    parser.add_argument("--share", type=float, default=0.25, help="share of clean accounts kept")
    parser.add_argument("--seeds", type=int, nargs="+", default=[0], help="one bag per seed")
    parser.add_argument("--mode", choices=MODES, default="mask",
                        help="how non-fraud rows of fraud accounts are handled")
    parser.add_argument("--risky-quantile", type=float, default=None,
                        help="keep clean accounts with a risk score above this quantile of all rows (for example 0.98)")
    parser.add_argument("--risk-col", default=None, help="risk score column (default: settings.VISA_SCORE_COL)")
    parser.add_argument("--out", default=None,
                        help="write the transaction id and, per seed, account_kept_<seed> and loss_weight_<seed>")
    args = parser.parse_args(argv)
    if args.demo:
        df = synthetic.make_transactions(n_accounts=400, seed=1)
    else:
        df = tables.read_files(args.base, args.files or settings.TRAIN_FILES, needed_columns(args.risk_col))
    samples = bags(df, share=args.share, seeds=args.seeds, mode=args.mode, risky_quantile=args.risky_quantile,
                   risk_col=args.risk_col)
    for seed, sample in samples.items():
        print(f"seed {seed}: share {args.share}, mode {args.mode}; add {np.log(args.share):.4f} to a log-odds "
              f"score to undo the sampling (mode mask, no risky accounts)")
        print(sample_summary(df, sample).to_string(index=False))
    if args.out:
        out = pd.DataFrame(index=range(len(df)))
        if settings.ID_COL in df.columns:
            out[settings.ID_COL] = df[settings.ID_COL].to_numpy()
        for seed, sample in samples.items():
            out[f"account_kept_{seed}"] = sample["account_kept"].to_numpy()
            out[f"loss_weight_{seed}"] = sample["loss_weight"].to_numpy()
        tables.write_table(out, args.out)
        print(f"written: {args.out}")
    return samples


if __name__ == "__main__":
    main()
