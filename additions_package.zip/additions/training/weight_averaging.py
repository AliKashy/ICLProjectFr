"""Averaged weights: an exponential moving average and a plain running average of a model.

What this file does
-------------------
It keeps a second copy of a model's weights that moves more slowly than the weights the
optimiser updates, and lets that copy be scored in place of the trained one:

    ExponentialAverage   after every optimiser step: average = decay * average + (1 - decay) * weights.
                         A decay of 0.999 averages over roughly the last thousand steps
    RunningAverage       the plain mean of the weights taken at chosen moments (for example at the
                         end of every epoch from the first one on): every snapshot counts the same
    both                 copy_to(model) writes the average into a model; swapped(model) does that
                         for the length of a `with` block and puts the trained weights back
                         afterwards; state_dict() and load_state_dict() save and restore the
                         average with a checkpoint

Only floating-point parameters and buffers are averaged. Whole-number buffers (step counters,
the batch count of a normalisation layer) are copied as they are, because their mean has no
meaning.

Why it exists
-------------
Two trainings that differ only in the random seed, or a training restarted from the same seed,
end with weights that rank the rows near the alert cut differently. The alert budget is a fixed
small share of rows, so that noise moves frauds in and out of the cut, and a real gain of a
change can be smaller than the noise. The last steps of training jitter around a good region of
weight space; an average of the weights along that path sits nearer its middle and ranks more
steadily. Averaging costs one more copy of the weights in memory and no extra training time.

The averaged weights are a different model from the trained weights. They reach their best
score at another epoch, usually later, because the average lags behind the training. So they
must be judged at their own best checkpoint: score the averaged weights at every validation,
keep the best epoch for them separately, and compare against the trained weights at their own
best epoch. Comparing both at the epoch that suits the trained weights would understate the
average. A shorter run averaged from the first epoch is a separate arm worth one try.

Where it goes
-------------
The training loop. In the original code the optimiser step is driven by the training framework
around `FTTransformerHierModel._step`; `ExponentialAverage.update(model)` is called right after
each optimiser step (a framework hook after the step, or the line after `optimizer.step()`),
and `RunningAverage.update(model)` at the end of each epoch. For validation, wrap the
validation pass in `with average.swapped(model):`. Save `average.state_dict()` beside the
model checkpoint, and write the averaged weights with `copy_to` before the final export, so
exported scores and vectors come from the same weights that were judged.

What to change for the pod
--------------------------
Nothing that depends on the data. The decay (0.999), the warm-up and the epoch at which the
running average starts are arguments. On a GPU the copy lives on the same device as the model.

How to try it
-------------
    average = ExponentialAverage(model, decay=0.999)
    for batch in loader:
        loss.backward(); optimizer.step(); optimizer.zero_grad()
        average.update(model)
    with average.swapped(model):
        validation_score = evaluate(model)
    python -m pytest -q additions/tests/test_rows_weight_averaging.py
"""
from contextlib import contextmanager

import torch


class _AveragedWeights:
    """What both averages share: the copy of the weights, writing it into a model, and saving it.

    model   the torch.nn.Module whose weights are averaged; the copy starts equal to its weights

    The copy is a dict {name: tensor} over `model.state_dict()`, detached from the graph, so no
    gradient ever reaches it and the optimiser never sees it.
    """

    def __init__(self, model):
        self.average = {name: value.detach().clone() for name, value in model.state_dict().items()}
        self.updates = 0

    @staticmethod
    def _averaged(value):
        """True for tensors whose mean has a meaning (floating point); others are copied."""
        return torch.is_floating_point(value)

    @torch.no_grad()
    def _blend(self, model, keep):
        """average = keep * average + (1 - keep) * current, for every floating-point tensor."""
        for name, value in model.state_dict().items():
            mine = self.average[name]
            if self._averaged(value):
                mine.mul_(keep).add_(value.detach().to(mine.dtype), alpha=1.0 - keep)
            else:
                mine.copy_(value)
        self.updates += 1

    @torch.no_grad()
    def copy_to(self, model):
        """Write the averaged weights into `model` (its trained weights are overwritten)."""
        model.load_state_dict(self.average, strict=True)

    @contextmanager
    def swapped(self, model):
        """Inside the `with` block `model` holds the averaged weights; afterwards its own weights are back.

        The trained weights are copied aside first and restored exactly, also when the block
        raises an error, so validation with the average never disturbs training.
        """
        saved = {name: value.detach().clone() for name, value in model.state_dict().items()}
        self.copy_to(model)
        try:
            yield model
        finally:
            model.load_state_dict(saved, strict=True)

    def state_dict(self):
        """The average and the update count, for a checkpoint (a plain dict of tensors and numbers)."""
        return {"average": {name: value.clone() for name, value in self.average.items()}, "updates": self.updates}

    def load_state_dict(self, state):
        """Restore what `state_dict` returned (for example when training resumes from a checkpoint)."""
        for name, value in state["average"].items():
            self.average[name].copy_(value)
        self.updates = int(state["updates"])


class ExponentialAverage(_AveragedWeights):
    """An exponential moving average of a model's weights, updated after every optimiser step.

    model    the model being trained
    decay    how much of the old average is kept at each update (0.999 averages over about
             1 / (1 - decay) = 1000 steps); 0 makes the average a plain copy of the weights
    warmup   True makes early updates use a smaller decay, min(decay, (1 + n) / (10 + n)) at
             update n. Without it the average would start as the untrained weights and need
             thousands of steps to forget them; with it the average follows quickly at first and
             settles to `decay` later

    `update(model)` takes no batch and returns nothing; the weights it reads must have the same
    names and shapes as the model given at the start.
    """

    def __init__(self, model, decay=0.999, warmup=True):
        super().__init__(model)
        if not 0.0 <= decay < 1.0:
            raise ValueError(f"decay must be in [0, 1), got {decay}")
        self.decay = float(decay)
        self.warmup = bool(warmup)

    def current_decay(self):
        """The decay the next update will use (smaller during the warm-up)."""
        if not self.warmup:
            return self.decay
        n = self.updates
        return min(self.decay, (1.0 + n) / (10.0 + n))

    def update(self, model):
        """Move the average one step toward the model's current weights."""
        self._blend(model, self.current_decay())


class RunningAverage(_AveragedWeights):
    """The plain mean of a model's weights over chosen moments, every snapshot counting the same.

    model         the model being trained
    start_epoch   updates for epochs before this one are ignored (0 averages from the first epoch)

    `update(model, epoch=None)` adds one snapshot: call it at the end of each epoch with the
    epoch number. The first snapshot that counts replaces the starting copy, so the average is
    exactly the mean of the snapshots taken, not of the weights at construction.
    """

    def __init__(self, model, start_epoch=0):
        super().__init__(model)
        self.start_epoch = int(start_epoch)

    def update(self, model, epoch=None):
        """Add the model's current weights to the mean (skipped before `start_epoch`)."""
        if epoch is not None and epoch < self.start_epoch:
            return
        # The n-th snapshot moves the mean by 1/n of the difference: mean_n = mean_{n-1} + (x - mean_{n-1}) / n,
        # which is the same as keeping (n - 1)/n of the old mean. The first one (n = 1) keeps nothing.
        n = self.updates + 1
        self._blend(model, (n - 1) / n)
