"""A small pairwise term aimed at the top of the ranking.

What this file does
-------------------
It adds one term to the training loss. Inside a batch it pairs every fraud row with every
non-fraud row whose score lies above a running high quantile of all scores, and each pair
adds softplus(non-fraud log-odds - fraud log-odds): next to nothing when the fraud is ranked
well above the non-fraud, about the size of the gap when it is ranked below.

    RunningQuantile   follows a high quantile of the scores from batch to batch
    pairwise_term     the mean of softplus(non-fraud - fraud) over those pairs
    scaled_term       that mean scaled down until it is worth at most a set fraction of the
                      cross-entropy
    PairwiseTop       the three together with a warm-up: the object a training step calls

Why it exists
-------------
The decision measure counts the frauds inside a fixed small share of rows. The cross-entropy
does not look at that cut. It rewards a better probability on every row alike, and most of
its gradient goes to rows that are nowhere near the cut. Only one kind of event moves the
measure: a fraud changing places with a non-fraud that sits in the alerted region. The pair
term puts gradient exactly there, on the non-frauds at the very top and on the frauds they
keep out.

It must stay small, for four reasons. A pair term only orders. It does not care what the
numbers mean, and when it is given room it stretches the scores until they are no longer
probabilities; everything downstream that reads the score as a probability then suffers (a
tilt toward dollars, a second-stage model, soft targets for another model, a fixed
threshold). Frauds are rare, so a batch holds only a few of them: the term rests on a
handful of rows, and a large weight makes the training chase their noise. The non-frauds at
the top are not all clean: a fraud label sits only on approved rows, so declined attempts
inside a fraud run are never labelled, and they are exactly the rows a good model scores
high; a small term nudges them, a large one teaches the model to forget them. And without
any scaling the term is many times the cross-entropy, because the cross-entropy is an
average over all rows, almost all of them easy, while the pair term averages over the
hardest pairs only. Hence the scaling to a fraction of the cross-entropy, a small fraction,
and a warm-up: early in training the top of the ranking is noise, and "the non-frauds above
the quantile" means nothing yet.

Where it goes
-------------
Head and loss. In the original code the loss is computed in `FTTransformerHierModel._step`;
the term is added there, after the cross-entropy, on the real rows of the batch and in the
training step only. The validation loss stays the plain cross-entropy, so that runs with
and without the term can be compared on one number. `PairwiseTop` is a module: its running
quantile and its step count are saved with the model.

What to change for the pod
--------------------------
`WARMUP_STEPS` below (about one pass over the training files, counted in training steps),
and, if wanted, `TOP_QUANTILE`, `FRACTION` and `MOMENTUM`. Rows that are kept out of the
loss (padding, rows that can never carry a label) should be dropped before the call. The
term bends probabilities a little even when small; a consumer that needs probabilities
should recalibrate the score.

How to try it
-------------
    pairwise = PairwiseTop()                                     # once, next to the model
    z = fraud_log_odds(model_output)[valid]                      # one log-odds value per real row
    ce = F.binary_cross_entropy_with_logits(z, labels[valid].float())
    loss = ce + pairwise(z, labels[valid], ce)                   # adds zero during the warm-up
    python -m pytest -q additions/tests/test_training_pairwise_top.py
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from additions.training._loss_shared import ramp

# PLACEHOLDER: the number of training steps before the term is switched on; about one pass over
# the training files.
WARMUP_STEPS = 2_000

# A non-fraud row is "at the top" when its score lies above this quantile of all scores.
TOP_QUANTILE = 0.97

# The term may be worth at most this fraction of the cross-entropy.
FRACTION = 0.25

# How much of its old value the running quantile keeps at every batch.
MOMENTUM = 0.99


class RunningQuantile(nn.Module):
    """Follows a high quantile of the scores from batch to batch.

    quantile   the quantile to follow, between 0 and 1; None reads `TOP_QUANTILE`
    momentum   the share of the old value kept at every update; None reads `MOMENTUM`

    One batch holds too few rows for a steady high quantile, and the scores drift while the
    model trains. The tracker therefore keeps a moving average of the batch quantiles:
        new value = momentum * old value + (1 - momentum) * quantile of this batch
    The first batch sets the value directly. The value and the number of updates are
    buffers: they are saved with the model, they move with it to another device, and no
    gradient flows through them.
    """

    def __init__(self, quantile=None, momentum=None):
        super().__init__()
        self.quantile = float(TOP_QUANTILE if quantile is None else quantile)
        self.momentum = float(MOMENTUM if momentum is None else momentum)
        self.register_buffer("value", torch.zeros(()))
        self.register_buffer("updates", torch.zeros((), dtype=torch.long))

    @torch.no_grad()
    def update(self, scores):
        """Move the value toward the quantile of `scores` (float, any shape) and return it."""
        scores = scores.detach().float().reshape(-1)
        if scores.numel() == 0:
            return self.value
        if scores.numel() > 1_000_000:
            # torch.quantile refuses very long inputs; an evenly spaced sample gives the same quantile.
            scores = scores[:: scores.numel() // 1_000_000 + 1]
        batch = torch.quantile(scores, self.quantile)
        if int(self.updates) == 0:
            self.value.copy_(batch)
        else:
            self.value.mul_(self.momentum).add_((1.0 - self.momentum) * batch)
        self.updates += 1
        return self.value


def pairwise_term(logits, labels, threshold):
    """The mean of softplus(non-fraud log-odds - fraud log-odds) over pairs at the top.

    logits      float [rows]: the fraud log-odds of the rows of a batch that count in the loss
    labels      [rows]: 1 for fraud, 0 otherwise
    threshold   a number or a scalar tensor: a non-fraud row is paired only when its log-odds
                lie above it

    Returns (term, pairs): a scalar tensor and the number of pairs. Every fraud of the batch
    is paired with every non-fraud above the threshold. A fraud far below the top is paired
    too: it is one the top non-frauds keep out. With no fraud, or no non-fraud above the
    threshold, the term is zero (still tied to the network) and `pairs` is 0.

    softplus(x) = log(1 + exp(x)) is a smooth count of wrongly ordered pairs: close to 0 when
    the fraud is well above the non-fraud, log 2 when they tie, close to the gap when the
    fraud is far below. Its gradient pushes the fraud up and the non-fraud down by the same
    amount, sigmoid(gap), which fades as the pair comes into the right order.
    """
    logits = logits.reshape(-1)
    labels = labels.reshape(-1)
    fraud = logits[labels > 0.5]
    # The choice of the top rows is a selection, not something to learn from: detach() keeps the
    # comparison with the threshold out of the graph.
    top = logits[(labels < 0.5) & (logits.detach() > threshold)]
    if fraud.numel() == 0 or top.numel() == 0:
        return logits.sum() * 0.0, 0
    gaps = top.unsqueeze(0) - fraud.unsqueeze(1)                 # [frauds, top non-frauds]
    return F.softplus(gaps).mean(), gaps.numel()


def scaled_term(term, cross_entropy, fraction=None):
    """The pair term scaled down until it is worth at most `fraction` of the cross-entropy.

    term            scalar tensor from `pairwise_term`
    cross_entropy   scalar tensor: the main loss of the same batch
    fraction        the largest share of the cross-entropy the term may be worth; None reads
                    `FRACTION`

    Returns a scalar tensor: min(1, fraction * cross_entropy / term) * term, so its value is
    never above fraction * cross_entropy. A term that is already smaller is left alone; it is
    never scaled up. The scale is computed from detached values and acts as a plain number,
    so the network cannot shrink the term by raising the cross-entropy.
    """
    fraction = FRACTION if fraction is None else fraction
    scale = (fraction * cross_entropy.detach() / term.detach().clamp_min(1e-12)).clamp(max=1.0)
    return scale * term


class PairwiseTop(nn.Module):
    """The pair term as one object for the training step: running quantile, warm-up and scaling.

    quantile       the quantile above which a non-fraud is "at the top"; None reads `TOP_QUANTILE`
    fraction       the largest share of the cross-entropy the term may be worth; None reads `FRACTION`
    warmup_steps   training steps before the term is switched on; None reads `WARMUP_STEPS`
    ramp_steps     steps over which it then rises to its full size; 0 switches it on at once
    momentum       for the running quantile; None reads `MOMENTUM`

    The object counts its own calls in training mode, so the warm-up works without the
    trainer's step counter; a `step` passed to the call is used in its place.
    """

    def __init__(self, quantile=None, fraction=None, warmup_steps=None, ramp_steps=0, momentum=None):
        super().__init__()
        self.fraction = float(FRACTION if fraction is None else fraction)
        self.warmup_steps = int(WARMUP_STEPS if warmup_steps is None else warmup_steps)
        self.ramp_steps = int(ramp_steps)
        self.tracker = RunningQuantile(quantile, momentum)
        self.register_buffer("steps", torch.zeros((), dtype=torch.long))

    def forward(self, logits, labels, cross_entropy, step=None):
        """The term to ADD to the cross-entropy of this batch.

        logits          float [rows]: fraud log-odds of the rows that count in the loss
        labels          [rows]: 1 for fraud, 0 otherwise
        cross_entropy   scalar tensor: the main loss of this batch
        step            None, or the trainer's count of training steps done so far

        Returns a scalar tensor: zero during the warm-up, afterwards at most
        fraction * cross_entropy. The running quantile is updated at every call in training
        mode, during the warm-up as well, so that it is settled when the term switches on.
        """
        step = int(self.steps) if step is None else step
        if self.training:
            self.tracker.update(logits)
            self.steps += 1
        on = ramp(step, self.warmup_steps, self.ramp_steps)
        if on <= 0.0 or int(self.tracker.updates) == 0:
            return logits.sum() * 0.0
        term, _ = pairwise_term(logits, labels, self.tracker.value)
        return on * scaled_term(term, cross_entropy, self.fraction)
