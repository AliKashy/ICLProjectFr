"""Loss terms, row weights, sampling, look-back cuts, weight averaging and teachers.

account_sampling.py        account sampling: keep every fraud account and a share of the others
auxiliary_heads.py         auxiliary heads: extra training targets taken from the account's whole
                           timeline
distillation.py            distillation: one model learns from several
lookahead_teacher.py       a look-ahead teacher: a history stage that may also read the next rows of
                           the account
lookback_cut.py            a visibility mask that also limits how far back a row may read, in days
loss_masks.py              row weights for the loss: rows that can never carry a fraud label teach
                           nothing
next_transaction_heads.py  next-transaction heads: predict the next row of the account, and read how
                           unexpected each row was
offset_head.py             an offset head: a second fraud head trained on top of another model's
                           fixed score
pairwise_top.py            a small pairwise term aimed at the top of the ranking
weight_averaging.py        averaged weights: an exponential moving average and a plain running
                           average of a model
_loss_shared.py            small helpers shared by the loss terms and teachers of this folder
"""
