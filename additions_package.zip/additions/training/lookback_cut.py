"""A visibility mask that also limits how far back a row may read, in days.

What this file does
-------------------
It builds the attention mask of the history stage with one more condition than the plain time
rule. Row i of a chunk may read row j only when

    both rows are real (not padding),
    row j is in a strictly earlier whole second than row i, and
    row j is at most `lookback_days[i]` days older than row i.

    lookback_mask        the mask in torch, bool [B, T, T], allowed[b, i, j]
    lookback_mask_numpy  the same in numpy, for CPU tools and for tests
    draw_lookback_days   one look-back per row, drawn evenly between two bounds (training only)
    available_span_days  per row, how many days of history the row could actually read: the
                         smaller of its look-back and the time since the data begins
    default_bounds       the two bounds that match the scored rows, read from the dates in settings
    LookbackCut          the pieces above in one object: drawn look-backs while training, no
                         extra cut at scoring, and the available span as an extra input

Why it exists
-------------
The evaluation files start one month before the scored month, so a scored row has between one
and two months of history. Training files run for many months, so most training rows have a
long, full history behind them. A model trained like that learns to lean on old rows that a
scored row never has: the history window of a training row is full where the same window of a
scored row is half empty, and the model has seldom seen the half-empty case. The gap grows with
the history length, because a longer window reaches further back.

Cutting each training row's look-back at a random number of days between the two bounds of the
scored rows (31 and 61 days with the dates in settings) gives training rows the same amount of
history as scored rows. The span a row could actually read is given to the model as an extra
input, so the model knows whether "no earlier row" means "a quiet account" or "the data does
not reach back that far". A row that has a long history in production can then use it once the
bounds are moved.

The cut is one more time condition on top of the strict rule. It only ever removes keys, never
adds one, so nothing that was hidden by the strict rule becomes visible.

Where it goes
-------------
Stage 2. In the original code the strict mask is built in
`FTTransformerHierModel._build_causal_mask` from `times` and the padding mask: the line
`earlier = (times.unsqueeze(1) < times.unsqueeze(2)) & real...` becomes
`earlier = lookback_mask(times, real, lookback_days, time_unit=10**9)`, and the rest of that
method (the open diagonal, the class token rules) stays as it is. The span is one more numeric
field of the row (in the original code a column made in `SequenceBuilder._encode_file` and read
by `FeatureTokenizer`), or a small learned vector added to the row vector before stage 2.

What to change for the pod
--------------------------
settings.py: EVAL_HISTORY_START, TARGET_START and TARGET_END (they give the two bounds),
TRAIN_HISTORY_START (where the training data begins, for the span of training rows). A
deployed model that will have 90 days of history uses bounds of 31 to 90 days or no cut.
`TIME_UNITS_PER_SECOND` below says what one unit of the time tensor is (the original code
carries nanoseconds).

How to try it
-------------
    cut = LookbackCut()                                         # bounds from settings
    allowed, span = cut(times, valid, training=True)            # [B, T, T] and [B, T]
    blocked = ~allowed                                          # the convention of nn.MultiheadAttention
    python -m pytest -q additions/tests/test_rows_lookback_cut.py
"""
import numpy as np
import pandas as pd
import torch

from additions import settings

# PLACEHOLDER: how many units of the time tensor make one second (1 for whole seconds, 10**9 for
# nanoseconds as in the original model's time_seq).
TIME_UNITS_PER_SECOND = 1

SECONDS_PER_DAY = 86_400


def _as_seconds(value):
    """A date (text or Timestamp) or a number of seconds, as whole seconds since 1970."""
    if isinstance(value, (int, float, np.integer, np.floating)):
        return int(value)
    return int(pd.Timestamp(value).timestamp())


def default_bounds(eval_start=None, target_start=None, target_end=None):
    """The shortest and the longest history of a scored row, in days.

    eval_start     first day of the evaluation files; None reads settings.EVAL_HISTORY_START
    target_start   first day of the scored month; None reads settings.TARGET_START
    target_end     first day after the scored month; None reads settings.TARGET_END

    Returns (low_days, high_days) as floats: a row at the start of the scored month has
    `low_days` of history behind it, a row at its end almost `high_days`.
    """
    start = _as_seconds(settings.EVAL_HISTORY_START if eval_start is None else eval_start)
    low = _as_seconds(settings.TARGET_START if target_start is None else target_start)
    high = _as_seconds(settings.TARGET_END if target_end is None else target_end)
    return (low - start) / SECONDS_PER_DAY, (high - start) / SECONDS_PER_DAY


def lookback_mask(times, valid, lookback_days=None, time_unit=None, include_self=False):
    """Which rows each row may read: real, in a strictly earlier second, and within its look-back.

    times           int64 tensor [B, T]: the time of every slot in units of `time_unit`
    valid           bool tensor [B, T]: True at real rows, False at padding
    lookback_days   None (no cut), a number (the same for every row), or a float tensor [B, T]
                    (one look-back per reading row i). Infinity or "not a number" means no cut
    time_unit       units per second; None reads TIME_UNITS_PER_SECOND
    include_self    True also opens the diagonal. The row's own slot is not another row, and
                    some attention layers need at least one open key per query to avoid a
                    division by zero; the original model opens the diagonal for that reason

    Returns bool tensor [B, T, T]: allowed[b, i, j] is True when row i may read row j.

    Times are floored to whole seconds first: two rows in the same second never see each other,
    whatever their order inside the chunk. The age limit is inclusive: a row exactly
    `lookback_days` days older is still visible.
    """
    unit = TIME_UNITS_PER_SECOND if time_unit is None else time_unit
    secs = torch.div(times.long(), int(unit), rounding_mode="floor")
    real = valid.bool()
    query = secs.unsqueeze(2)                                   # [B, T, 1]: row i
    key = secs.unsqueeze(1)                                     # [B, 1, T]: row j
    allowed = (key < query) & real.unsqueeze(2) & real.unsqueeze(1)
    if lookback_days is not None:
        days = torch.as_tensor(lookback_days, dtype=torch.float64, device=times.device)
        if days.dim() == 2:
            days = days.unsqueeze(2)                            # one limit per reading row i
        limit = torch.nan_to_num(days * SECONDS_PER_DAY, nan=float("inf"))
        allowed = allowed & ((query - key).double() <= limit)
    if include_self:
        allowed = allowed | torch.eye(times.shape[1], dtype=torch.bool, device=times.device).unsqueeze(0)
    return allowed


def lookback_mask_numpy(times, valid, lookback_days=None, time_unit=None, include_self=False):
    """The same mask as `lookback_mask`, with numpy arrays in and out ([B, T] in, bool [B, T, T] out)."""
    unit = TIME_UNITS_PER_SECOND if time_unit is None else time_unit
    secs = np.floor_divide(np.asarray(times, dtype=np.int64), int(unit))
    real = np.asarray(valid, dtype=bool)
    query = secs[:, :, None]
    key = secs[:, None, :]
    allowed = (key < query) & real[:, :, None] & real[:, None, :]
    if lookback_days is not None:
        days = np.asarray(lookback_days, dtype=np.float64)
        if days.ndim == 2:
            days = days[:, :, None]
        limit = np.nan_to_num(days * SECONDS_PER_DAY, nan=np.inf)
        allowed &= (query - key).astype(np.float64) <= limit
    if include_self:
        allowed |= np.eye(secs.shape[1], dtype=bool)[None]
    return allowed


def draw_lookback_days(shape, low_days=None, high_days=None, generator=None, device=None):
    """One look-back per row, drawn evenly between two bounds. For training only.

    shape                 the shape of the result, usually [B, T]
    low_days, high_days   the bounds; None reads `default_bounds()`
    generator             an optional torch.Generator, for repeatable draws

    Returns float64 tensor of `shape`. Every row draws its own look-back, so the rows of one
    chunk see different amounts of history, as scored rows of different days do.
    """
    default_low, default_high = default_bounds()
    low = default_low if low_days is None else float(low_days)
    high = default_high if high_days is None else float(high_days)
    u = torch.rand(tuple(shape), generator=generator, dtype=torch.float64)
    days = low + (high - low) * u
    return days if device is None else days.to(device)


def available_span_days(times, valid, lookback_days=None, history_start=None, time_unit=None):
    """How many days of history each row could read: its look-back, or less where the data begins later.

    times, valid    as in `lookback_mask` ([B, T])
    lookback_days   None, a number or a float tensor [B, T], as in `lookback_mask`
    history_start   the first second of the data the rows come from (a date as text or a number
                    of seconds); None reads settings.TRAIN_HISTORY_START. For scored rows pass
                    settings.EVAL_HISTORY_START
    time_unit       units per second; None reads TIME_UNITS_PER_SECOND

    Returns float32 tensor [B, T], 0.0 at padding. It describes how far back the row's window
    reaches, never what is in it, so it uses no other row. Divided by the upper bound it makes
    a number between 0 and about 1 that can be fed to the model as one more input.
    """
    unit = TIME_UNITS_PER_SECOND if time_unit is None else time_unit
    start = _as_seconds(settings.TRAIN_HISTORY_START if history_start is None else history_start)
    secs = torch.div(times.long(), int(unit), rounding_mode="floor")
    since_start = (secs - start).double().clamp_min(0.0) / SECONDS_PER_DAY
    span = since_start
    if lookback_days is not None:
        days = torch.as_tensor(lookback_days, dtype=torch.float64, device=times.device)
        span = torch.minimum(since_start, torch.nan_to_num(days, nan=float("inf")))
    return torch.where(valid.bool(), span, torch.zeros_like(span)).float()


class LookbackCut:
    """Drawn look-backs while training, the data's own limit at scoring, and the span as an input.

    low_days, high_days    bounds of the training look-back; None reads `default_bounds()`
    train_history_start    first second of the training data; None reads settings.TRAIN_HISTORY_START
    eval_history_start     first second of the scored data; None reads settings.EVAL_HISTORY_START
    score_lookback_days    None (no extra cut at scoring, the data already limits it) or a number
    time_unit              units per second of the time tensor; None reads TIME_UNITS_PER_SECOND
    include_self           passed to `lookback_mask`

    Calling the object with (times [B, T], valid [B, T], training, generator=None) returns
    (allowed bool [B, T, T], span_days float32 [B, T]). With training=False nothing random
    happens, so scoring is repeatable. The drawn look-backs are a training device only: they
    are never stored with a row and never reach the scored rows.
    """

    def __init__(self, low_days=None, high_days=None, train_history_start=None, eval_history_start=None,
                 score_lookback_days=None, time_unit=None, include_self=False):
        default_low, default_high = default_bounds()
        self.low_days = default_low if low_days is None else float(low_days)
        self.high_days = default_high if high_days is None else float(high_days)
        if self.high_days < self.low_days:
            raise ValueError(f"high_days ({self.high_days}) is below low_days ({self.low_days})")
        self.train_history_start = settings.TRAIN_HISTORY_START if train_history_start is None else train_history_start
        self.eval_history_start = settings.EVAL_HISTORY_START if eval_history_start is None else eval_history_start
        self.score_lookback_days = score_lookback_days
        self.time_unit = time_unit
        self.include_self = include_self

    def __call__(self, times, valid, training, generator=None):
        if training:
            days = draw_lookback_days(times.shape, self.low_days, self.high_days, generator).to(times.device)
            start = self.train_history_start
        else:
            days = self.score_lookback_days
            start = self.eval_history_start
        allowed = lookback_mask(times, valid, days, self.time_unit, self.include_self)
        span = available_span_days(times, valid, days, start, self.time_unit)
        return allowed, span

    def span_input(self, span_days):
        """The span as a number between 0 and about 1 (divided by the upper bound), shape unchanged."""
        return span_days / max(self.high_days, 1e-9)
