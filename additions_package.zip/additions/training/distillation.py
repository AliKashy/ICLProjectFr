"""Distillation: one model learns from several.

What this file does
-------------------
It holds the pieces of a teacher-student training in which the student is the model that
ships and the teachers are only scored:

    average_teachers       the mean of several teachers' log-odds for the same rows
    to_probability         a monotone map from an uncalibrated teacher score to a probability
    cross_fit_plan         which teacher trains on which files and scores which
    out_of_sample_scores   for every row, the score of the teacher that did not train on its file
    soft_target_loss       cross-entropy on the label plus a weighted cross-entropy on the
                           teacher's probability (the "soft target")

Why it exists
-------------
Almost every row carries the label zero, and a label of zero says the same about all of
them. A teacher's probability does not: one zero-label row gets a value close to that of a
fraud, another a value close to nothing. Those graded values put the zero-label rows in an
order, and the top of that order is where the alert cut falls, because the alert budget is a
fixed small share of rows. Some of the rows up there are fraud in everything but the label:
a fraud label sits only on approved rows, so declined attempts inside a fraud run are never
labelled, and the plain label teaches the model that they are clean. A soft target between 0
and 1 tells the student how fraud-like such a row is, where the label can only say "no".

Several teachers are better than one. Two trainings that differ only in the random seed do
not rank the rows around the cut alike. Their average is steadier than either of them, and a
student trained on the average holds that steadier ranking in one set of weights, so a
single model is shipped and scored once per row.

A teacher's scores are only worth learning from on rows it has not trained on. A model has
fitted its training rows: there its score has moved toward the label it was shown, high on
the frauds it has seen and low on the zero-label rows it has seen, further than it would go
on new rows of the same kind. A soft target taken from such rows collapses to the label,
with the grading squeezed out, and the student would learn the teacher's memory in place
of its judgement. The files hold whole accounts and no account is in two files, so a teacher
that did not train on a file has seen none of its accounts. `cross_fit_plan` uses that: it
splits the files so that each one is scored by a teacher trained on the others.

When the teachers are trainings of the same model, nothing from outside enters the student.
When the teacher is another model, its knowledge enters the student through the soft
targets. The student is then no longer an independent challenger of that model: a comparison
of the two no longer shows what this model finds on its own, the student cannot be said to
have beaten its teacher unaided, and every refresh needs the teacher's scores again.

Where it goes
-------------
Scores, then head and loss. First the teachers score files they did not train on
(`reads/seed_average.py` reports what their average gains over a single one and can write
the averaged score). Then the soft target is joined to the training rows by transaction id
and carried as one more per-row array beside the label (in the original code the per-row
arrays are made in `SequenceBuilder._encode_file` and the label travels as `target_seq`).
Last, `soft_target_loss` takes the place of the plain cross-entropy (in the original code in
`FTTransformerHierModel._step`). It wants one log-odds value per row;
`_loss_shared.fraud_log_odds` makes that from the two outputs of the original head. Nothing
changes at scoring: the student is scored like any other model.

What to change for the pod
--------------------------
`settings.SCORE_COL` and `settings.SCORE_KIND` say what the teachers' prediction files hold,
`settings.ID_COL` is the join key and `settings.TRAIN_FILES` is the list `cross_fit_plan`
splits by default. The weight of the soft term (0.5), the number of folds and
`only_on_negatives` are arguments. `only_on_negatives` is for a teacher that has seen the
frauds of these very rows in its own training but not the other rows: its score is then the
label on the fraud rows and a real judgement only on the rest. A teacher that did not score
a row leaves a missing value there; the row keeps its label loss and gets no soft term.

How to try it
-------------
    plan = cross_fit_plan(settings.TRAIN_FILES, n_folds=2)       # train one teacher per entry
    logit = out_of_sample_scores(df["_file"], {0: avg_logit_teacher_0, 1: avg_logit_teacher_1}, plan)
    teacher_prob = to_probability(logit, kind="logit")           # or with held-out rows, see the function
    loss = soft_target_loss(fraud_log_odds(model_output)[valid], labels[valid], teacher_prob[valid])
    python -m pytest -q additions/tests/test_training_distillation.py
"""
import numpy as np
import torch
import torch.nn.functional as F
from scipy.special import expit
from sklearn.isotonic import IsotonicRegression

from additions import settings
from additions.common import ranking
from additions.training._loss_shared import weighted_mean


def average_teachers(logit_list):
    """The mean of several teachers' log-odds for the same rows.

    logit_list   K arrays or tensors of shape [rows]: the log-odds that each teacher gives
                 to the same rows, in the same order (`ranking.to_logit` turns a probability
                 into log-odds). A missing value means "this teacher did not score the row".

    Returns float64 [rows]: the mean over the teachers that scored the row, and a missing
    value where none did. The mean of log-odds is the geometric mean of the odds, so a row
    comes out high only when the teachers agree on it. Only scores are averaged, never
    vectors: two trainings do not share coordinate axes.
    """
    stack = np.stack([np.asarray(z.detach().cpu() if torch.is_tensor(z) else z, dtype=np.float64)
                      for z in logit_list], axis=0)                        # [K, rows]
    have = np.isfinite(stack)
    count = have.sum(axis=0)
    total = np.where(have, stack, 0.0).sum(axis=0)
    return np.where(count > 0, total / np.maximum(count, 1), np.nan)


def to_probability(teacher_scores, held_out_scores=None, held_out_labels=None, reference_logits=None,
                   kind=None, floor=1e-6):
    """A monotone map from a teacher score that is not a calibrated probability to a probability.

    teacher_scores    [rows]: the teacher's score on the rows that are to get a soft target
    held_out_scores, held_out_labels
                      [m] each: the teacher's score and the 0/1 fraud label on rows the teacher
                      did not train on. When given, the map is an isotonic regression of the
                      label on the score: the share of frauds at each score level
    reference_logits  [any length]: log-odds of a model whose probabilities can be trusted on
                      rows of the same kind (for example the labels-only training). When
                      given (and no held-out rows are), the teacher's log-odds are
                      standardised and then given the mean and the spread of these
    kind              "probability" or "logit": what the teacher's score is; None reads
                      settings.SCORE_KIND
    floor             the result is kept inside [floor, 1 - floor]

    Returns float64 [rows]; missing where the teacher's score is missing. With neither
    held-out rows nor a reference the score is taken at face value.

    Why a map is needed: a model trained on a thinned-out sample of the zero-label rows, or
    with weighted rows, ranks well but its number is not a probability on all rows. Used as
    a soft target as it stands, it would pull every student probability up or down. Both maps
    are monotone, so the teacher's ranking, which is what the student is meant to learn, is
    kept.
    """
    z = ranking.to_logit(np.asarray(teacher_scores, dtype=np.float64), kind)
    if held_out_scores is not None and held_out_labels is not None:
        x = ranking.to_logit(np.asarray(held_out_scores, dtype=np.float64), kind)
        y = np.asarray(held_out_labels, dtype=np.float64)
        ok = np.isfinite(x) & np.isfinite(y)
        # Isotonic regression gives a staircase: stretches of neighbouring scores share one value, the
        # share of frauds among them. Read as it stands, it would give every row of a step the same
        # soft target and throw the grading inside the step away. So each step is reduced to one
        # point (its mean score, its value) and the map runs in straight lines from point to point.
        # It still never decreases, and it rises wherever two steps differ.
        fitted = IsotonicRegression(y_min=0.0, y_max=1.0, out_of_bounds="clip").fit_transform(x[ok], y[ok])
        values, step = np.unique(fitted, return_inverse=True)
        centres = np.bincount(step, weights=x[ok]) / np.bincount(step)
        prob = np.interp(z, centres, values)
    elif reference_logits is not None:
        reference = np.asarray(reference_logits, dtype=np.float64)
        reference = reference[np.isfinite(reference)]
        have = np.isfinite(z)
        spread = z[have].std() if have.any() else 0.0
        # Standardise (subtract the mean, divide by the spread), then put on the reference's scale. The
        # map is a straight line in log-odds, so no two rows ever change places and no tie is created.
        standard = (z - (z[have].mean() if have.any() else 0.0)) / (spread if spread > 0 else 1.0)
        prob = expit(standard * reference.std() + reference.mean())
    else:
        prob = expit(z)
    return np.clip(prob, floor, 1.0 - floor)


def cross_fit_plan(file_numbers=None, n_folds=2):
    """Which teacher trains on which files and scores which, so that no teacher scores its own training rows.

    file_numbers   the files that are to carry soft targets; None reads settings.TRAIN_FILES
    n_folds        the number of teachers, at least 2. A "teacher" may itself be several seeds
                   trained on the same files, whose log-odds are averaged with `average_teachers`

    Returns a list with one dict per teacher:
        {"teacher": k, "train_files": [...], "score_files": [...]}
    The files are dealt out in turn, so the folds have the same size to within one file.
    Teacher k trains on every file outside its fold and scores the files of its fold. Every
    file is scored exactly once, by a teacher that never saw it, and so never saw any of its
    accounts. With two folds each teacher trains on one half and scores the other.

    The student may then train on all the files: each of its soft targets is out-of-sample
    for the teacher that made it.
    """
    files = list(dict.fromkeys(settings.TRAIN_FILES if file_numbers is None else file_numbers))
    if n_folds < 2 or n_folds > len(files):
        raise ValueError(f"n_folds must be between 2 and the number of files ({len(files)}), got {n_folds}")
    plan = []
    for k in range(n_folds):
        score_files = files[k::n_folds]
        held = set(score_files)
        plan.append({"teacher": k, "train_files": [f for f in files if f not in held], "score_files": score_files})
    return plan


def out_of_sample_scores(file_of_row, scores_by_teacher, plan):
    """For every row, the score of the teacher that did not train on the row's file.

    file_of_row         [rows]: the file each row came from (the `_file` column that
                        `tables.read_files` adds)
    scores_by_teacher   {teacher: [rows]}, or a list in teacher order: each teacher's score for
                        the same rows. What a teacher holds on rows of its own training files
                        is never read, so those entries may be anything, also missing
    plan                what `cross_fit_plan` returned

    Returns float64 [rows]: missing where the row's file is in no teacher's `score_files`.
    This function is the one place where "which teacher may speak about which row" is decided.
    """
    file_of_row = np.asarray(file_of_row)
    out = np.full(len(file_of_row), np.nan)
    for entry in plan:
        mine = np.isin(file_of_row, entry["score_files"])
        out[mine] = np.asarray(scores_by_teacher[entry["teacher"]], dtype=np.float64)[mine]
    return out


def soft_target_loss(logits, labels, teacher_prob, weight=0.5, only_on_negatives=False, row_weight=None,
                     return_parts=False):
    """Cross-entropy on the label plus `weight` times cross-entropy on the teacher's probability.

    logits              float [...]: the student's fraud log-odds, one per row
    labels              [...]: 1 for fraud, 0 otherwise
    teacher_prob        float [...]: the teacher's probability of fraud for the same rows; a
                        missing value means "no soft target for this row"
    weight              how much the soft term counts beside the label term
    only_on_negatives   True: fraud rows get no soft term (see the module text for when)
    row_weight          None or float [...]: the weight of every row in both terms; 0 takes a
                        row out of the loss (padding, or rows that are kept as history only)
    return_parts        True returns (total, label_term, soft_term), for logging

    Returns a scalar tensor. The loss of one row is
        ce(logit, label) + weight * ce(logit, teacher_prob)
    with the second part left out on rows without a soft target, and the rows are averaged
    with `row_weight`. Both parts share one denominator, so a row with a soft target counts
    (1 + weight) times and a row without one counts once, whatever share of the batch has a
    teacher score. The loss of a row is smallest where the student's probability equals
    (label + weight * teacher_prob) / (1 + weight): the student is pulled to a blend of what
    the label says and what the teacher says.
    """
    labels = labels.to(logits.dtype)
    has_soft = torch.isfinite(teacher_prob)
    if only_on_negatives:
        has_soft = has_soft & (labels < 0.5)
    # The teacher is data. detach() makes sure that no gradient ever flows back into whatever made
    # it. Missing values are replaced before the loss is taken, because a loss computed on a missing
    # value would spoil the gradients even when it is multiplied by zero afterwards.
    target = torch.nan_to_num(teacher_prob.detach().to(logits.dtype), nan=0.0).clamp(0.0, 1.0)
    hard = F.binary_cross_entropy_with_logits(logits, labels, reduction="none")
    soft = F.binary_cross_entropy_with_logits(logits, target, reduction="none") * has_soft.to(logits.dtype)
    label_term = weighted_mean(hard, row_weight)
    soft_term = weighted_mean(soft, row_weight)
    total = label_term + weight * soft_term
    return (total, label_term, soft_term) if return_parts else total
