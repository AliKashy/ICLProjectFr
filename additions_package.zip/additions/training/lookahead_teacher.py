"""A look-ahead teacher: a history stage that may also read the next rows of the account.

What this file does
-------------------
It builds the visibility rule of a teacher that sees a little of the future, and the small
pieces that go with it:

    lookahead_visibility     which rows each row may read: the strict rule, plus a band of
                             later rows when one is asked for
    attention_mask           that rule in the form an attention layer takes
    HistoryStack             a small history stage with its own weights that reads row vectors
                             under such a rule. Called with a band it is the teacher; called
                             without one it is an ordinary causal stage
    second_look_delay        how many seconds after a row its look-ahead score can exist
    student_loss             the causal model's loss, with the teacher's probability as a
                             soft target beside the label
    change_from_later_rows   a check that the scores of earlier rows do not move when the
                             rows after them are replaced

Nothing built with the look-ahead band may score live traffic. The band reads rows that do
not exist yet when a transaction is authorised. It is a training-only teacher and the source
of a delayed score, never an input and never the model that decides.

Why it exists
-------------
Frauds come in runs on one account, so most frauds follow an earlier fraud of that account,
and what follows a row says a great deal about it: a burst of attempts at new merchants, a
string of declines, or nothing at all. A model that also reads the next rows can tell a row
inside a run from an ordinary odd row far better than a model that reads only the past.
There are two ways to use such a model without breaking the time rule.

As a teacher. Its probability becomes a soft target for the causal model, next to the label.
The teacher's value is graded where the label is flat. A declined attempt in the middle of
a run is never labelled, because a fraud label sits only on approved rows; the teacher sees
the run around it and gives it a high value, where the label says zero. The causal model
still reads only the past. It is taught to rank the rows it can see the way a model with
hindsight would rank them.

As a delayed second look. The teacher's own score is a lawful score from the moment the rows
of its band have arrived, seconds or minutes after the transaction. It cannot stop that
transaction. It can re-order a case queue, support a block before the next attempt, or serve
as a cleaner training label for other models. `second_look_delay` says how long after each
row the score can exist; it should be exported with the score.

Two things would turn the teacher into a leak. The teacher and the causal model must not
share the weights of the history stage, or the future would reach the causal model through
them; sharing stage 1 is safe, because stage 1 encodes each transaction on its own. And the
soft targets must come from rows the teacher did not train on (`distillation.cross_fit_plan`),
or they repeat the labels. `change_from_later_rows` tests the first point on the causal model.

Where it goes
-------------
Stage 2, then head and loss; for the second look, scores and exports. The teacher is a
second copy of the history stage. In the original code the rows a transaction may read are
decided in `FTTransformerHierModel._build_causal_mask`, where `earlier | eye` is the strict
rule; `lookahead_visibility` is that line with the band added, and belongs in the teacher's
copy only. `student_loss` takes the place of the cross-entropy in
`FTTransformerHierModel._step` of the causal model.

What to change for the pod
--------------------------
`settings.EMBED_DIM`, `NUM_HEADS`, `STAGE2_BLOCKS` and `HISTORY_LEN` size `HistoryStack`; in a
real model the pod's own history stage takes its place and only the mask is used. Times are
whole seconds here. The original batch carries `time_seq` in nanoseconds; divide it first
(`torch.div(time_seq, 10**9, rounding_mode="floor")`). The band is `seconds_ahead` in seconds
of the clock or `rows_ahead` in rows, the soft term has a weight and a warm-up.

How to try it
-------------
    teacher, student = HistoryStack(), HistoryStack()            # separate weights
    teacher_logits = teacher(vectors, times, valid, rows_ahead=3)
    student_logits = student(vectors, times, valid)              # the strict rule
    loss = student_loss(student_logits[valid], labels[valid], teacher_logits[valid])
    kept, replaced = change_from_later_rows(student.eval(), vectors, times, valid)   # kept must be ~0
    python -m pytest -q additions/tests/test_training_lookahead_teacher.py
"""
import torch
import torch.nn as nn

from additions import settings
from additions.common.timekeys import MISSING_SECOND
from additions.training._loss_shared import ramp
from additions.training.distillation import soft_target_loss


def lookahead_visibility(times, valid, seconds_ahead=None, rows_ahead=None):
    """Which rows each row may read: the strict rule, plus a band into the future for a teacher.

    times           int64 [B, T]: the whole second of every row of every chunk (anything at padding)
    valid           bool [B, T]: True at real rows
    seconds_ahead   None, or a number of seconds: the row may also read the other rows of its
                    own second and every row of the next `seconds_ahead` seconds
    rows_ahead      None, or a number of rows: the row may also read the other rows of its own
                    second and the next `rows_ahead` real rows of its chunk (the real rows of
                    a chunk are taken to be in time order)

    Returns bool [B, T, T]. Entry [b, i, j] is True when row i of chunk b may read row j.

    With both arguments None the result is the strict rule, the only one a model that scores
    live traffic may use: a row reads itself and the rows of strictly earlier seconds. Rows
    of one second never read each other, because the timestamp cannot say which came first.
    A row with no time reads itself and is read by nobody.

    With a band the result looks forward in time: a training-only teacher and a delayed
    score may use it, nothing else. When both bands are given a row is visible if either
    band holds it. The band of rows can end between two rows that share a second, since their
    order in the chunk is arbitrary; that does no harm to a teacher, and `seconds_ahead`
    avoids it.
    """
    times = times.long()
    real = valid.bool()
    placed = real & (times != MISSING_SECOND)       # rows that can take part in anyone's history
    reader = times.unsqueeze(2)                     # [B, T, 1]: the second of the row that reads
    read = times.unsqueeze(1)                       # [B, 1, T]: the second of the row that is read
    visible = read < reader                         # the strict rule: strictly earlier seconds only
    if seconds_ahead is not None:
        visible = visible | ((read >= reader) & (read <= reader + int(seconds_ahead)))
    if rows_ahead is not None:
        place = placed.long().cumsum(dim=1)                    # 1, 2, 3, ... over the placed rows of a chunk
        ahead = place.unsqueeze(1) - place.unsqueeze(2)        # how many rows after the reader the read row sits
        visible = visible | (read == reader) | ((ahead > 0) & (ahead <= int(rows_ahead)))
    visible = visible & placed.unsqueeze(2) & placed.unsqueeze(1)
    own = torch.eye(times.shape[1], dtype=torch.bool, device=times.device) & real.unsqueeze(2)
    return visible | own                            # every real row reads itself


def attention_mask(visible, num_heads=None):
    """The visibility rule in the form `nn.TransformerEncoder` and `nn.MultiheadAttention` take.

    visible     bool [B, T, T] from `lookahead_visibility`
    num_heads   the attention heads of the layer; None reads settings.NUM_HEADS

    Returns float32 [B * num_heads, T, T]: 0.0 where reading is allowed and minus infinity
    where it is not, with the lines of one chunk repeated once per head, which is the layout
    those layers expect.

    The diagonal is always open. A padded row has nothing it may read, and a line of the
    attention matrix that is closed everywhere turns into "not a number" and spoils the
    gradients of the whole batch. A padded row that reads itself harms nobody, because no
    real row reads it.
    """
    num_heads = settings.NUM_HEADS if num_heads is None else num_heads
    own = torch.eye(visible.shape[-1], dtype=torch.bool, device=visible.device)
    mask = torch.zeros(visible.shape, dtype=torch.float32, device=visible.device)
    mask.masked_fill_(~(visible | own), float("-inf"))
    return mask.repeat_interleave(num_heads, dim=0)


class HistoryStack(nn.Module):
    """A small history stage: row vectors of a chunk in, one fraud log-odds per row out.

    dim           width of a row vector; None reads settings.EMBED_DIM
    num_heads     attention heads; None reads settings.NUM_HEADS
    blocks        attention blocks; None reads settings.STAGE2_BLOCKS
    history_len   earlier rows the position table can tell apart; None reads settings.HISTORY_LEN
    dropout       dropout rate inside the blocks

    Two objects of this class, with separate weights, make a teacher and a causal model: the
    teacher is called with a band, the causal model without one. The weights must stay
    separate. Shared weights would carry what the teacher learned from the future into the
    model that must not know it.
    """

    def __init__(self, dim=None, num_heads=None, blocks=None, history_len=None, dropout=0.1):
        super().__init__()
        dim = settings.EMBED_DIM if dim is None else dim
        self.num_heads = settings.NUM_HEADS if num_heads is None else num_heads
        blocks = settings.STAGE2_BLOCKS if blocks is None else blocks
        history_len = settings.HISTORY_LEN if history_len is None else history_len
        layer = nn.TransformerEncoderLayer(d_model=dim, nhead=self.num_heads, dim_feedforward=4 * dim,
                                           dropout=dropout, activation="gelu", batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(layer, num_layers=blocks, enable_nested_tensor=False)
        self.position = nn.Embedding(history_len + 1, dim)
        self.head = nn.Linear(dim, 1)

    def forward(self, vectors, times, valid, seconds_ahead=None, rows_ahead=None):
        """Score every row of every chunk.

        vectors   float [B, T, dim]: one vector per row, from stage 1
        times     int64 [B, T] whole seconds; valid   bool [B, T]
        seconds_ahead, rows_ahead   the band of `lookahead_visibility`; both None is the strict rule

        Returns float [B, T]: fraud log-odds. The value at a padded row means nothing.
        """
        visible = lookahead_visibility(times, valid, seconds_ahead, rows_ahead)
        # A row's position is the number of real rows in strictly earlier seconds, with or without a
        # band. Counting chunk slots instead would let a row of the same second, or a later row, show
        # that it exists by shifting the position of its neighbours.
        earlier = lookahead_visibility(times, valid).sum(dim=-1) - valid.long()
        position = earlier.clamp(min=0, max=self.position.num_embeddings - 1)
        out = self.encoder(vectors + self.position(position), mask=attention_mask(visible, self.num_heads))
        return self.head(out).squeeze(-1)


def second_look_delay(times, valid, seconds_ahead=None, rows_ahead=None):
    """How many seconds after a row its look-ahead score can exist.

    Arguments as in `lookahead_visibility`.

    Returns float32 [B, T]; missing at padding and where the band is not complete.
      no band         0: the score needs nothing that comes later
      seconds_ahead   that number of seconds: only when they have passed is it known that no
                      further row falls inside the band
      rows_ahead      the seconds from the row to the last row of its band; missing when the
                      chunk holds fewer later rows than the band asks for (more may still
                      come, and the score of such a row was made from a shorter band)
      both            the larger of the two
    The column belongs next to an exported second-look score: it tells a consumer from when
    on the score may be used.
    """
    times = times.long()
    placed = valid.bool() & (times != MISSING_SECOND)
    delay = torch.zeros(times.shape, dtype=torch.float32, device=times.device)
    if seconds_ahead is not None:
        delay = delay + float(seconds_ahead)
    complete = placed.clone()
    if rows_ahead is not None and int(rows_ahead) > 0:
        place = placed.long().cumsum(dim=1)
        ahead = place.unsqueeze(1) - place.unsqueeze(2)                        # [B, reader, read]
        last = (ahead == int(rows_ahead)) & placed.unsqueeze(1)                # the last row of each reader's band
        wait = ((times.unsqueeze(1) - times.unsqueeze(2)) * last).sum(dim=-1)  # at most one row matches
        delay = torch.maximum(delay, wait.to(delay.dtype))
        complete = complete & last.any(dim=-1)
    return torch.where(complete, delay, torch.full_like(delay, float("nan")))


def student_loss(student_logits, labels, teacher_logits, weight=0.5, step=None, warmup_steps=0, ramp_steps=0,
                 row_weight=None):
    """The causal model's loss: the label, plus the look-ahead teacher's probability as a soft target.

    student_logits   float [...]: fraud log-odds of the causal model (strict rule), one per row
    labels           [...]: 1 for fraud, 0 otherwise
    teacher_logits   float [...]: the teacher's fraud log-odds for the same rows; a missing
                     value means "no soft target for this row"
    weight           the weight of the soft term once it is fully on
    step, warmup_steps, ramp_steps
                     the soft term is off for the first `warmup_steps` training steps and then
                     rises over `ramp_steps`; step=None means fully on. A warm-up is needed
                     only when teacher and causal model train in the same run, because the
                     teacher's early output is noise. With teacher scores made beforehand
                     and joined as a column, leave step=None
    row_weight       None or float [...]: row weights, as in `distillation.soft_target_loss`

    Returns a scalar tensor. The teacher's output is detached first: the loss of the causal
    model must never change the teacher, or the teacher would drift toward targets that are
    easy to copy.
    """
    teacher_prob = torch.sigmoid(teacher_logits.detach())          # a missing value stays missing
    return soft_target_loss(student_logits, labels, teacher_prob,
                            weight=weight * ramp(step, warmup_steps, ramp_steps), row_weight=row_weight)


def change_from_later_rows(score_fn, vectors, times, valid, seed=0):
    """A check of the time rule: how far scores move when rows that must be invisible are replaced.

    score_fn   a function (vectors, times, valid) -> float [B, T]: the model under test, in
               evaluation mode (no dropout), so that two calls on the same input agree
    vectors    float [B, T, dim]; times   int64 [B, T] whole seconds; valid   bool [B, T]
    seed       fixes the draw of the probe rows and of the replacement vectors

    In every chunk one real row is drawn as the probe. Every other row of the probe's second
    and every row of a later second gets a new random vector. The rows of earlier seconds
    and the probe itself keep theirs. Under the strict rule none of the kept rows may read a
    replaced row, so their scores must not move.

    Returns (kept, replaced): the largest absolute change of a score among the rows that
    kept their vector, and among the rows that were replaced. A model that obeys the strict
    rule gives `kept` of zero up to rounding; a model with a look-ahead band gives a clearly
    larger value. `replaced` shows that the replacement did change something.
    """
    generator = torch.Generator().manual_seed(seed)
    real = valid.bool().cpu()
    # A chunk without any real row has nothing to check; it still needs a positive weight for the draw.
    draw_weight = real.float() + (~real.any(dim=1, keepdim=True)).float()
    probe = torch.multinomial(draw_weight, 1, generator=generator).to(times.device)      # [B, 1]
    slots = torch.arange(times.shape[1], device=times.device).unsqueeze(0)
    replaced = valid.bool() & (times >= times.gather(1, probe)) & (slots != probe)
    noise = torch.randn(vectors.shape, generator=generator).to(vectors)
    changed = torch.where(replaced.unsqueeze(-1), noise, vectors)
    with torch.no_grad():
        move = (score_fn(changed, times, valid) - score_fn(vectors, times, valid)).abs()
    kept = valid.bool() & ~replaced
    return (float(move[kept].max()) if kept.any() else 0.0,
            float(move[replaced].max()) if replaced.any() else 0.0)
