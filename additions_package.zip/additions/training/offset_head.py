"""An offset head: a second fraud head trained on top of another model's fixed score.

What this file does
-------------------
It adds a second fraud head, "head B", to the model. Head B does not predict fraud from
nothing. Its output is added to the fixed log-odds of another model (the "offset"), and the
sum is trained against the fraud label:

    loss_b = cross-entropy( other model's log-odds + head B's output , label )

    offset_log_odds   the other model's score column as log-odds, missing values kept
    OffsetHead        head B: one linear layer on the row vector, zero at the start
    offset_loss       the loss above, over the rows that have the other model's score
    two_head_loss     the standalone fraud loss plus head B's loss, ramped in and capped
    export_columns    head B's output and the combined log-odds, as columns

The model's own fraud head ("head A") stays as it is and keeps its own loss, so the model's
standalone score is not given up.

Why it exists
-------------
A model that is trained alone spends much of its capacity on what an existing model already
knows. When the two are later combined, for example in a tree model that takes this model's
score and vector next to its own features, most of what this model brings is a repeat.

Head B changes what the shared vector is asked for. The gradient of its loss on one row is
sigmoid(offset + head B) minus the label. Where the other model is right and sure, that is
close to zero and the row teaches nothing. Where the other model is wrong, a fraud it scores
low or a clean row it scores high, it is large. So head B is trained only by what the other
model gets wrong, and through head B the shared vector is pushed to hold what that model
lacks. For a model that reads each account as a sequence, the natural candidate is what
the history shows: frauds come in runs on one account, so most frauds follow an earlier
fraud of that account, and the rows before a fraud say a great deal about it.

The consumer gains two things: head B's output is a correction to the other model's
log-odds, a column built to add to that model, and the vector trained beside it carries more
of what is new to that model.

Three limits. The other model's scores must be out-of-sample for it on the training rows.
On rows that model was trained on, its score sits closer to the label than it would on new
rows; less error is left for head B there than in real use, and head B learns too small a
correction. The head is tied to one version of the other model and has to be trained again
when that model changes. And it does nothing for the standalone score by itself.

Where it goes
-------------
Scores, head and loss, exports. The other model's score is joined to the training rows by
transaction id and carried as one more per-row array beside the label (in the original code
the per-row arrays are made in `SequenceBuilder._encode_file`). Head B sits next to
`self.head` of `FTTransformerHierModel` and reads the same vector (`out[:, 1:]` in `forward`);
`two_head_loss` takes the place of the single loss in `_step`. At scoring, head B's output
is written next to the score and the vector.

What to change for the pod
--------------------------
`OFFSET_SCORE_COL` and `OFFSET_SCORE_KIND` below (the column that holds the other model's
score, and whether it is a probability or a log-odds value), `settings.ID_COL` for the join
and `settings.EMBED_DIM`. The start and the length of the ramp are counted in training
steps. When no other model's score can be had, the offset can come from a tree model on
the row's own fields that is fitted on files outside the training list and applied to every
training row; the out-of-sample rule is the same.

How to try it
-------------
    offset = torch.from_numpy(offset_log_odds(df)).float()       # missing where there is no score
    head_b = OffsetHead()
    loss_b = offset_loss(head_b(row_vectors)[valid], offset[valid], labels[valid])
    loss = two_head_loss(fraud_loss, loss_b, step, start_step=1_000, ramp_steps=1_000)
    columns = export_columns(head_b(row_vectors)[valid], offset[valid])
    python -m pytest -q additions/tests/test_training_offset_head.py
"""
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F

from additions import settings
from additions.common import ranking
from additions.training._loss_shared import ramp, weighted_mean
from additions.training.auxiliary_heads import capped_total

# PLACEHOLDER: the column that holds the other model's score for every training row.
OFFSET_SCORE_COL = "other_model_score"

# PLACEHOLDER: what that column holds: "probability" or "logit" (a log-odds value).
OFFSET_SCORE_KIND = "probability"

# The offset is kept inside [-OFFSET_LIMIT, OFFSET_LIMIT]. A score of exactly 0 or 1 is an infinite
# log-odds value; no correction of any size could ever be learned against it.
OFFSET_LIMIT = 12.0


def offset_log_odds(scores, score_col=None, kind=None, limit=None):
    """The other model's score as log-odds, one value per row.

    scores      a table that holds the score column, or the scores themselves [rows]
    score_col   the name of the column; None reads `OFFSET_SCORE_COL`
    kind        "probability" or "logit": what the scores are; None reads `OFFSET_SCORE_KIND`
    limit       the result is kept inside [-limit, limit]; None reads `OFFSET_LIMIT`

    Returns float64 [rows]; missing where the row has no score. A table without the column
    gives one printed line and a result that is missing everywhere: head B then gets no loss
    and the rest of the training is untouched.
    """
    limit = OFFSET_LIMIT if limit is None else limit
    if isinstance(scores, pd.DataFrame):
        score_col = OFFSET_SCORE_COL if score_col is None else score_col
        if not score_col or score_col not in scores.columns:
            print(f"note: the table has no column '{score_col}' with the other model's score; head B gets no loss")
            return np.full(len(scores), np.nan)
        scores = pd.to_numeric(scores[score_col], errors="coerce")
    values = np.asarray(scores, dtype=np.float64)
    return np.clip(ranking.to_logit(values, OFFSET_SCORE_KIND if kind is None else kind), -limit, limit)


class OffsetHead(nn.Module):
    """Head B: one linear layer on the row vector, whose output is a correction to the offset.

    dim   the width of the row vector; None reads settings.EMBED_DIM

    The layer starts at zero, so at the first step offset + head B is the other model's score
    exactly and head B's loss is that model's own loss. From there every change is a learned
    correction. A random start would first add noise to a good score, and the early steps
    would be spent taking it out again. A zero start also means that no gradient reaches the
    shared vector through head B at the very first step; it begins to flow as the layer moves.

    To use head B as a readout only, without any effect on the shared vector, call it on
    `vectors.detach()`.
    """

    def __init__(self, dim=None):
        super().__init__()
        self.linear = nn.Linear(settings.EMBED_DIM if dim is None else dim, 1)
        nn.init.zeros_(self.linear.weight)
        nn.init.zeros_(self.linear.bias)

    def forward(self, vectors):
        """vectors float [..., dim] -> float [...]: head B's output, a log-odds correction per row."""
        return self.linear(vectors).squeeze(-1)


def offset_loss(logit_b, offset, labels, row_weight=None):
    """Cross-entropy of (offset + head B's output) against the label.

    logit_b      float [...]: head B's output, one per row
    offset       float [...]: the other model's log-odds for the same rows; a missing value
                 means "no score for this row"
    labels       [...]: 1 for fraud, 0 otherwise
    row_weight   None or float [...]: row weights; 0 takes a row out (padding, masked rows)

    Returns a scalar tensor: the mean over the rows that have an offset. A batch in which no
    row has one gives zero, still tied to the network. The offset is data: it is detached,
    and nothing is ever learned about it.

    The gradient with respect to head B's output on one row is
    sigmoid(offset + logit_b) - label, divided by the number of rows: nearly nothing where
    the other model is right and sure, large where it is wrong.
    """
    offset = offset.detach().to(logit_b.dtype)
    finite = torch.isfinite(offset)
    has = finite.to(logit_b.dtype)
    # A missing or infinite offset is replaced by 0 and its row weighted 0. Replacing it by 0, and not by
    # the largest float, keeps the per-row loss finite, so 0 times that loss is 0 and not "not a number".
    combined = torch.where(finite, offset, torch.zeros_like(offset)) + logit_b
    per_row = F.binary_cross_entropy_with_logits(combined, labels.to(logit_b.dtype), reduction="none")
    return weighted_mean(per_row, has if row_weight is None else has * row_weight)


def two_head_loss(main_loss, loss_b, step=None, start_step=0, ramp_steps=0, weight=1.0):
    """The standalone fraud loss plus head B's loss, ramped in and held to the size of the fraud loss.

    main_loss   scalar tensor: the loss of head A, the model's own fraud head
    loss_b      scalar tensor from `offset_loss`
    step        the number of training steps done so far; None means "fully on"
    start_step, ramp_steps   head B's loss is off before `start_step` and rises in a straight
                line over the next `ramp_steps`
    weight      the weight of head B's loss once it is fully on

    Returns a scalar tensor: main + weight * ramp * min(1, main / loss_b) * loss_b.

    The ramp lets head A shape the shared vector first; head B then bends a vector that
    already ranks, instead of fighting over a random one. The cap (`capped_total` of
    auxiliary_heads.py) keeps head B's loss from ever counting for more than head A's, so
    the standalone score stays the main task.
    """
    return capped_total(main_loss, [loss_b], weight=weight * ramp(step, start_step, ramp_steps))


def export_columns(logit_b, offset=None, prefix="head_b_"):
    """Head B's output as columns for export.

    logit_b   float [rows]: head B's output for the rows to export
    offset    None or float [rows]: the other model's log-odds for the same rows

    Returns {column name: float32 numpy array [rows]}:
      <prefix>logit            head B's output: the correction this model makes to the other
                               model's log-odds. This is the column to hand to a consumer that
                               already holds the other model's score
      <prefix>combined_logit   offset + head B's output (only with `offset`; missing where the
                               row has no offset)
    """
    logit_b = logit_b.detach().float()
    columns = {prefix + "logit": logit_b.cpu().numpy()}
    if offset is not None:
        columns[prefix + "combined_logit"] = (offset.detach().float() + logit_b).cpu().numpy()
    return columns
