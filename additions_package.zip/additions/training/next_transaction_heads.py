"""Next-transaction heads: predict the next row of the account, and read how unexpected each row was.

What this file does
-------------------
From the state of every row it predicts four fields of the account's NEXT row: its merchant
category, the band of its amount, the band of the time until it, and whether its merchant is
one the account has used before. The predictions are trained beside the fraud loss, and they
are turned into "surprise" columns: for each row, how unlikely its own values were under the
prediction that was made before it.

    category_vocabulary    the most frequent merchant categories, fitted once
    field_classes          the four fields of every row as class numbers (from raw rows)
    shift_targets          each row's classes moved onto the row before it: the targets
    NextTransactionHeads   one linear head per field on the row vector
    next_field_losses      the cross-entropy per field, with smoothed targets for ordered bands
    total_loss             the fraud loss plus those losses under the cap of auxiliary_heads.py
    state_before           for every row, the prediction made by the last row before it
    surprise               per field: negative log probability of what happened, entropy of
                           the prediction, rank of the observed value; as exportable columns

Why it exists
-------------
A "seen before" flag can only say yes or no. A prediction says how expected a row is, given
everything the account has done: a new merchant in a familiar category for a usual amount is
a mild surprise; a new category, an unusual amount and a gap of seconds after weeks of quiet
is not. Frauds come in runs on one account, and a run is the moment the account stops
behaving like itself. The surprise columns measure that departure, and they need no fraud
label at all. Fraud labels arrive weeks after the transaction; these heads can train on
every row, the newest included. For the network they are targets on every row, where the
fraud label is almost always zero. For a downstream tree model they are something it cannot
compute from raw fields: "how unlikely is this value for this account", in a fixed unit that
keeps its meaning when the model is retrained, which the axes of an exported vector do not.

Surprise is also high for honest novelty (travel, a first purchase of a new kind) and on
accounts with little history. The columns are evidence to combine with the rest, not a score.

The time rule. The prediction for a row is made by the last row of the latest strictly
earlier second. Rows of one second share that prediction and never predict each other. The
targets look one row ahead, which a target may do; a surprise is read from a state that
existed before its row. No fraud label is used anywhere in this file.

Where it goes
-------------
Raw files, the loader, head and loss, exports. The class numbers are per-row arrays like
the label (in the original code made in `SequenceBuilder._encode_file`). The heads read the
vector the fraud head reads (`out[:, 1:]` in `FTTransformerHierModel.forward`), `total_loss`
takes the place of the single loss in `FTTransformerHierModel._step`, and the surprise
columns are written by the scoring pass next to the score.

What to change for the pod
--------------------------
`settings.MCC_COL`, `AMOUNT_COL`, `MERCHANT_COL`, `ACCOUNT_COL`, `TIME_COL` and `EMBED_DIM`; the
three constants below. Fit `category_vocabulary` once on training files and pass the same
list wherever classes are made. `history_start` keeps "used before" alike in long training
files and short evaluation files (features/lookback.py builds such a start). Times in the
batch are whole seconds.

How to try it
-------------
    classes = field_classes(df)                                   # int columns, -1 = no value
    heads = NextTransactionHeads(field_sizes(classes.attrs["vocabulary"]))
    target, has_next = shift_targets(category, valid, times)      # category: int64 [B, T]; once per field
    loss = total_loss(fraud_loss, heads(row_vectors), {"category": target}, has_next)
    before, has_before = state_before(heads(row_vectors)["category"], valid, times)
    columns = surprise({"category": before[valid]}, {"category": category[valid]}, has_before[valid])
    python -m pytest -q additions/tests/test_training_next_transaction_heads.py
"""
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F

from additions import settings
from additions.common import timekeys
from additions.common.history import EarlierRows
from additions.common.timekeys import MISSING_SECOND
from additions.training._loss_shared import weighted_mean
from additions.training.auxiliary_heads import capped_total

# PLACEHOLDER: the dollar amounts that separate the amount bands, ascending.
AMOUNT_BIN_EDGES = (1.0, 5.0, 10.0, 25.0, 50.0, 100.0, 250.0, 500.0, 1000.0, 2500.0)

# PLACEHOLDER: the gaps in seconds that separate the time-gap bands, ascending (1 minute to 1 week).
GAP_BIN_EDGES = (60, 600, 3_600, 6 * 3_600, 86_400, 3 * 86_400, 7 * 86_400)

# PLACEHOLDER: how many of the most frequent merchant categories get a class of their own.
MAX_CATEGORIES = 50

# The fields whose classes are ordered bands; a near miss on them costs less than a far miss.
ORDERED_FIELDS = ("amount_bin", "gap_bin")


def _coded_text(values):
    """(codes, texts): a small integer per row (-1 for a missing value) and the text of each distinct value.

    A whole number is written without a decimal point, so 5411 and 5411.0 are the same text.
    The texts are made once per distinct value, never once per row.
    """
    codes, distinct = pd.factorize(pd.Series(np.asarray(values)))
    texts = [str(int(v)) if isinstance(v, (float, np.floating)) and float(v).is_integer() else str(v).strip()
             for v in distinct]
    return codes.astype(np.int64), texts


def category_vocabulary(values, max_categories=None):
    """The most frequent values of a code column as a list of texts, most frequent first.

    values           the merchant category of every row of the files the list is fitted on
    max_categories   length of the list; None reads `MAX_CATEGORIES`

    The position in the list is the class number; every value outside it shares the class
    "other". Fit the list once and reuse it, so that a class means the same in every file.
    """
    max_categories = MAX_CATEGORIES if max_categories is None else max_categories
    codes, texts = _coded_text(values)
    counts = {}
    for text, n in zip(texts, np.bincount(codes[codes >= 0], minlength=len(texts))):
        counts[text] = counts.get(text, 0) + int(n)
    return sorted(counts, key=lambda text: (-counts[text], text))[: int(max_categories)]


def field_sizes(vocabulary=None, amount_edges=None, gap_edges=None):
    """The number of classes of each field, as {field: classes}: what `NextTransactionHeads` needs."""
    n_categories = MAX_CATEGORIES if vocabulary is None else len(vocabulary)
    return {"category": n_categories + 1,
            "amount_bin": len(AMOUNT_BIN_EDGES if amount_edges is None else amount_edges) + 1,
            "gap_bin": len(GAP_BIN_EDGES if gap_edges is None else gap_edges) + 1,
            "repeat_merchant": 2}


def field_classes(df, vocabulary=None, account_col=None, time_col=None, category_col=None, amount_col=None,
                  merchant_col=None, amount_edges=None, gap_edges=None, history_start=None):
    """The four predicted fields of every row of `df`, as class numbers.

    df              every row of one or more whole files (whole account histories), in any order
    vocabulary      the list from `category_vocabulary`; None fits it on `df` itself
    account_col, time_col, category_col, amount_col, merchant_col   column names; None reads settings
    amount_edges, gap_edges   the band edges; None reads the constants of this file
    history_start   None, a second or int64 [rows]: the earliest second a row may look back to
                    when "used before" is decided

    Returns a DataFrame of int64 with the index of `df`; the list of categories is kept in
    `.attrs["vocabulary"]`. -1 means "no value": such a row is no target for the field and has
    no surprise for it.
      category          0 .. K-1 for the K listed categories, K for every other one
      amount_bin        the number of edges at or below the amount (0 .. number of edges)
      gap_bin           the band of the seconds since the account's latest strictly earlier
                        row; -1 on a row with no earlier row
      repeat_merchant   1 when the account used this merchant in a strictly earlier second, else 0
    A field whose column is not set or not in the table is skipped with one printed line.
    These are the row's OWN values; `shift_targets` turns them into "the next row's" values.
    """
    account = timekeys.codes(df[settings.ACCOUNT_COL if account_col is None else account_col])
    secs = timekeys.seconds(df[settings.TIME_COL if time_col is None else time_col])
    names = {"category": settings.MCC_COL if category_col is None else category_col,
             "amount_bin": settings.AMOUNT_COL if amount_col is None else amount_col,
             "repeat_merchant": settings.MERCHANT_COL if merchant_col is None else merchant_col}
    have = {field: bool(col) and col in df.columns for field, col in names.items()}
    for field, found in have.items():
        if not found:
            print(f"note: no column is set or found for the field '{field}'; it is skipped")
    out = {}
    if have["category"]:
        codes, texts = _coded_text(df[names["category"]])
        if vocabulary is None:
            vocabulary = category_vocabulary(df[names["category"]])
        place = {text: k for k, text in enumerate(vocabulary)}
        per_value = np.array([place.get(text, len(vocabulary)) for text in texts] + [-1], dtype=np.int64)
        out["category"] = per_value[codes]                    # a code of -1 picks the last entry, which is -1
    if have["amount_bin"]:
        amount = pd.to_numeric(df[names["amount_bin"]], errors="coerce").to_numpy(dtype=np.float64)
        edges = np.asarray(AMOUNT_BIN_EDGES if amount_edges is None else amount_edges, dtype=np.float64)
        out["amount_bin"] = np.where(np.isnan(amount), -1, np.searchsorted(edges, amount, side="right"))
    # The gap is measured to the latest row of a strictly earlier second, so rows of one second have
    # the same gap and none of them is "the previous row" of another.
    gap = EarlierRows(account, secs).seconds_since_last()
    edges = np.asarray(GAP_BIN_EDGES if gap_edges is None else gap_edges, dtype=np.float64)
    out["gap_bin"] = np.where(np.isnan(gap), -1, np.searchsorted(edges, np.nan_to_num(gap), side="right"))
    if have["repeat_merchant"]:
        codes, _ = _coded_text(df[names["repeat_merchant"]])
        # One history per (account, merchant). A row without a merchant gets no clock, so it has no
        # history and is in nobody's: a missing merchant never counts as "the same merchant".
        clock = np.where(codes >= 0, secs, MISSING_SECOND)
        seen = EarlierRows(timekeys.codes(account, codes), clock, start=history_start).count() > 0
        out["repeat_merchant"] = np.where(clock != MISSING_SECOND, seen.astype(np.int64), -1)
    frame = pd.DataFrame({field: np.asarray(values, dtype=np.int64) for field, values in out.items()}, index=df.index)
    frame.attrs["vocabulary"] = vocabulary
    return frame


def _neighbour(valid, times, forward):
    """For every row, the slot of the row that follows it (or, with forward=False, comes before it).

    Returns (index int64 [B, T], has bool [B, T]). With `times` the neighbour is taken by
    whole seconds: forward, the first row of the next later second; backward, the last row of
    the latest earlier second. Rows of the row's own second are never chosen. Without `times`
    it is simply the next (or the previous) real row of the chunk. The comparison is made
    between all pairs of rows of a chunk, [B, T, T] like the attention mask itself, so it
    needs no assumption about the order of the rows.
    """
    valid = valid.bool()
    n_chunks, width = valid.shape
    slots = torch.arange(width, device=valid.device)
    clock = slots.expand(n_chunks, width) if times is None else times.long()
    if times is not None:
        valid = valid & (clock != MISSING_SECOND)
    me, other = clock.unsqueeze(2), clock.unsqueeze(1)              # [B, T, 1] and [B, 1, T]
    both = valid.unsqueeze(2) & valid.unsqueeze(1)
    if forward:
        candidates = (other > me) & both
        nearest = torch.where(candidates, other, torch.iinfo(torch.int64).max).min(dim=-1, keepdim=True).values
        index = torch.where(candidates & (other == nearest), slots, width).min(dim=-1).values
    else:
        candidates = (other < me) & both
        nearest = torch.where(candidates, other, torch.iinfo(torch.int64).min).max(dim=-1, keepdim=True).values
        index = torch.where(candidates & (other == nearest), slots, -1).max(dim=-1).values
    return index.clamp(0, width - 1), candidates.any(dim=-1)


def _take(per_row, index):
    """per_row [B, T, ...] read at the slots `index` [B, T] along the second dimension."""
    shape = index.shape + (1,) * (per_row.dim() - 2)
    return per_row.gather(1, index.reshape(shape).expand(index.shape + per_row.shape[2:]))


def shift_targets(values, valid, times=None):
    """Move each row's value onto the row before it: the target of "predict the next row".

    values   [B, T] or [B, T, ...]: something known for every row, for example a class number
    valid    bool [B, T]: True at real rows
    times    None or int64 [B, T] whole seconds

    Returns (targets, has_next):
      targets    the shape of `values`: at row i, the value of the row that follows i, and -1
                 where no row follows
      has_next   bool [B, T]: True where a row follows. The last row of a chunk has none, nor
                 has padding; such rows get no loss

    Which row "follows" is decided as in `_neighbour`: with `times`, the first row of the next
    later second, so all rows of one second get the same target and never each other.
    """
    index, has_next = _neighbour(valid, times, forward=True)
    targets = _take(values, index)
    keep = has_next.reshape(has_next.shape + (1,) * (values.dim() - 2))
    return torch.where(keep, targets, torch.full_like(targets, -1)), has_next


def state_before(per_row, valid, times=None):
    """For every row, what the last row before it held: the prediction made before the row happened.

    per_row   [B, T, ...]: something computed at every row, for example the logits of a head
    valid     bool [B, T]; times   None or int64 [B, T] whole seconds

    Returns (before, has_before):
      before       the shape of `per_row`: at row j, the entry of the last row of the latest
                   earlier second (without `times`: of the previous real row)
      has_before   bool [B, T]: False on the first second of a chunk and at padding; `before`
                   means nothing there
    """
    index, has_before = _neighbour(valid, times, forward=False)
    return _take(per_row, index), has_before


def smoothed_bins(targets, n_bins, width=1.0):
    """Soft targets for a field of ordered bands: most weight on the true band, some on its neighbours.

    targets   int64 [...]: the true band of every row (a negative entry is read as band 0;
              such rows must be masked out by the caller)
    n_bins    the number of bands
    width     how far the weight spreads, in bands: a band at distance d from the true one
              gets a weight proportional to exp(-(d / width)^2 / 2); 0 gives the plain target

    Returns float32 [..., n_bins]; every line sums to 1. With a plain target a prediction one
    band off is punished as hard as one eight bands off, although the band edges are
    arbitrary and neighbouring bands are nearly the same answer.
    """
    bands = torch.arange(n_bins, device=targets.device, dtype=torch.float32)
    distance = bands - targets.clamp(min=0).unsqueeze(-1).to(torch.float32)
    if width <= 0:
        return (distance == 0).to(torch.float32)
    weight = torch.exp(-0.5 * (distance / width) ** 2)
    return weight / weight.sum(dim=-1, keepdim=True)


class NextTransactionHeads(nn.Module):
    """One linear head per predicted field, all reading the same row vector.

    sizes   {field: number of classes}, for example from `field_sizes`
    dim     the width of the row vector; None reads settings.EMBED_DIM
    """

    def __init__(self, sizes=None, dim=None):
        super().__init__()
        dim = settings.EMBED_DIM if dim is None else dim
        sizes = field_sizes() if sizes is None else sizes
        self.heads = nn.ModuleDict({field: nn.Linear(dim, int(n)) for field, n in sizes.items()})

    def forward(self, vectors):
        """vectors float [..., dim] -> {field: float [..., classes]}: logits for the NEXT row's class."""
        return {field: head(vectors) for field, head in self.heads.items()}


def next_field_losses(head_logits, targets, has_next, ordered=ORDERED_FIELDS, width=1.0, row_weight=None):
    """The cross-entropy of every head against the classes of the next row.

    head_logits   {field: float [B, T, classes]} from `NextTransactionHeads`
    targets       {field: int64 [B, T]} from `shift_targets`; a negative entry is "no target"
    has_next      bool [B, T] from `shift_targets`
    ordered       the fields that get `smoothed_bins` targets
    width         the spread of that smoothing, in bands
    row_weight    None or float [B, T]: further row weights

    Returns {field: scalar tensor}. A row that no row follows, and a row whose next row has
    no value for the field, add nothing to that field's loss. No fraud label enters.
    """
    losses = {}
    for field, logits in head_logits.items():
        if field not in targets:
            continue
        target = targets[field]
        use = (has_next & (target >= 0)).to(logits.dtype)
        log_prob = F.log_softmax(logits, dim=-1)
        if field in ordered:
            per_row = -(smoothed_bins(target, logits.shape[-1], width).to(logits.dtype) * log_prob).sum(dim=-1)
        else:
            per_row = -log_prob.gather(-1, target.clamp(min=0).unsqueeze(-1)).squeeze(-1)
        losses[field] = weighted_mean(per_row, use if row_weight is None else use * row_weight)
    return losses


def total_loss(fraud_loss, head_logits, targets, has_next, weight=1.0, **options):
    """The fraud loss plus the next-row losses, each held to the size of the fraud loss.

    A next-row loss is a choice among dozens of classes on every row and is far larger than
    the fraud loss, which is close to zero on almost every row. Summed as they are, the
    next-row losses would shape the shared vector alone; `capped_total` prevents that.
    `options` are passed to `next_field_losses`. Returns a scalar tensor.
    """
    return capped_total(fraud_loss, next_field_losses(head_logits, targets, has_next, **options), weight)


def surprise(logits_before, observed, has_before=None, prefix="surprise_"):
    """How unexpected each row was under the prediction made before it, as exportable columns.

    logits_before   {field: float [rows, classes]}: for every row, the logits held by the last
                    row before it (from `state_before`)
    observed        {field: int64 [rows]}: the row's own class (from `field_classes`); negative
                    means "no value"
    has_before      None or bool [rows]: False where the row had no earlier row

    Returns {column name: float32 tensor [rows]}, detached from the network:
      <prefix><field>_nll       negative log probability of the observed class, in nats
      <prefix><field>_entropy   entropy of the prediction: how unsure it was. A high nll under
                                a confident prediction is what stands out
      <prefix><field>_rank      1 when the observed class was thought the most likely, 2 when
                                one class was thought more likely, and so on
      <prefix>total             the sum of the nll columns over the fields with a value
      <prefix>has_before        1.0 where the row had an earlier row, else 0.0
    The columns of a field hold a missing value where the row had no earlier row or no value
    for that field. The values are detached on purpose: if a fraud loss could push gradients
    through them, the heads would drift from "what comes next" toward "what is fraud" and
    the columns would lose their fixed meaning.
    """
    columns, total, any_field = {}, None, None
    for field, logits in logits_before.items():
        log_prob = F.log_softmax(logits.detach().float(), dim=-1)
        seen = observed[field] >= 0
        if has_before is not None:
            seen = seen & has_before.bool()
        own = log_prob.gather(-1, observed[field].clamp(min=0).unsqueeze(-1))        # [rows, 1]
        missing = torch.full_like(own.squeeze(-1), float("nan"))
        nll = torch.where(seen, -own.squeeze(-1), missing)
        columns[f"{prefix}{field}_nll"] = nll
        columns[f"{prefix}{field}_entropy"] = torch.where(seen, -(log_prob.exp() * log_prob).sum(dim=-1), missing)
        columns[f"{prefix}{field}_rank"] = torch.where(seen, 1.0 + (log_prob > own).sum(dim=-1).float(), missing)
        total = torch.nan_to_num(nll, nan=0.0) if total is None else total + torch.nan_to_num(nll, nan=0.0)
        any_field = seen if any_field is None else any_field | seen
    if total is not None:
        columns[f"{prefix}total"] = torch.where(any_field, total, torch.full_like(total, float("nan")))
        flag = any_field if has_before is None else has_before.bool()
        columns[f"{prefix}has_before"] = flag.float()
    return columns
