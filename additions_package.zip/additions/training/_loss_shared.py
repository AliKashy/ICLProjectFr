"""Small helpers shared by the loss terms and teachers of this folder.

What this file does
-------------------
It holds four short steps that several files of `additions/training/` repeat:

    fraud_log_odds    the two outputs of a two-class fraud head as one log-odds value per row
    weighted_mean     the mean of per-row losses under row weights (a weight of 0 drops a row)
    ramp              a straight-line switch that turns a loss term on over some training steps
    account_chunks    the rows of a table laid out as padded chunks per account, the layout the
                      network reads; the examples and the tests use it to get from a table to
                      a batch

Why it exists
-------------
Each step is short, and each has one detail that is easy to get wrong when it is written again
in every file. Frauds are rare, so many batches hold no row at all for a rare target: no
fraud for a pair term, no row with a teacher score, no row with a forward-looking target. A
mean over no rows is a division by zero; `weighted_mean` returns a zero that is still tied
to the network, so the training step runs on and that batch simply teaches nothing for that
term. A loss term that is switched on at full strength in one step jolts a model that has
already settled; `ramp` brings it in gradually. The cross-entropy of a two-class head equals
the binary cross-entropy of the difference of its two outputs, so every loss term of this
folder is written once, for one log-odds value per row, and `fraud_log_odds` is the bridge
from a two-class head.

Where it goes
-------------
Head and loss. The three small functions are called inside the training step (in the
original code the loss is computed in `FTTransformerHierModel._step`, on the output of
`self.head`, which has two columns). `account_chunks` stands in for the sequence builder (in
the original code `SequenceBuilder._chunks_for_file`) wherever an example or a test needs
chunks; a real training run takes its chunks from the builder in use.

What to change for the pod
--------------------------
`FRAUD_CLASS` if the two-class head puts "fraud" in its first column. `account_chunks` reads
`settings.ACCOUNT_COL`, `settings.TIME_COL` and `settings.HISTORY_LEN`; it cuts a chunk every
`width` rows, while the builder in use may cut differently (the original cuts only between
whole seconds). Nothing in the loss terms depends on how chunks are cut.

How to try it
-------------
    log_odds = fraud_log_odds(model_output)                  # [B, T, 2] becomes [B, T]
    loss = weighted_mean(per_row_loss, row_weight)           # a scalar
    weight = 0.25 * ramp(step, start=2_000, length=500)      # 0 until step 2000, 0.25 from step 2500
    chunks = account_chunks(df, [settings.LABEL_COL])        # dict of tensors [chunks, width]
    python -m pytest -q additions/tests/test_training_loss_shared.py
"""
import numpy as np
import torch

from additions import settings
from additions.common import timekeys
from additions.common.timekeys import MISSING_SECOND

# PLACEHOLDER: the output column of a two-class fraud head that stands for "fraud" (0 or 1).
FRAUD_CLASS = 1


def fraud_log_odds(two_class_output, fraud_class=None):
    """One fraud log-odds value per row from the output of a two-class head.

    two_class_output   float [..., 2]: the two outputs of the head for every row
    fraud_class        which of the two columns stands for "fraud"; None reads `FRAUD_CLASS`

    Returns float [...]: the "fraud" output minus the "not fraud" output. The softmax over two
    outputs gives the fraud class the probability sigmoid(that difference), so the usual
    two-class cross-entropy and the binary cross-entropy on this value are the same number.
    A head with a single output already returns a log-odds value and needs no conversion.
    """
    fraud_class = FRAUD_CLASS if fraud_class is None else fraud_class
    return two_class_output[..., fraud_class] - two_class_output[..., 1 - fraud_class]


def weighted_mean(per_row, weight=None):
    """The mean of per-row values in which every row counts `weight` times.

    per_row   float [...]: one value per row, for example a loss per row. Every entry must be
              finite, also where the weight is 0 (0 times "not a number" is not 0)
    weight    None (every row counts once), or float or bool of a shape that broadcasts to
              `per_row`; 0 or False takes a row out

    Returns a scalar tensor. When no row has any weight the result is 0.0 and is still part
    of the graph, so `backward()` runs and gives zero gradients instead of failing.
    """
    if weight is None:
        return per_row.mean() if per_row.numel() else per_row.sum()
    weight = torch.broadcast_to(weight.to(per_row.dtype), per_row.shape)
    # The floor only matters when every weight is 0: the sum above it is then 0 as well, and 0 divided
    # by a tiny number is 0. With any real weight the floor is far below the total and changes nothing.
    return (per_row * weight).sum() / weight.sum().clamp_min(1e-12)


def ramp(step, start=0, length=0):
    """How far a loss term is switched on at training step `step`, as a number from 0.0 to 1.0.

    step     the number of training steps done so far; None means "no schedule" and gives 1.0
    start    the term is off (0.0) before this step
    length   the term rises in a straight line over this many steps after `start`; 0 switches
             it on at once

    Returns a Python float: 0.0 before `start`, 1.0 from `start + length` on. The caller
    multiplies the weight of its loss term by it.
    """
    if step is None:
        return 1.0
    if step < start:
        return 0.0
    if length <= 0:
        return 1.0
    return min(1.0, (step - start) / float(length))


def account_chunks(df, columns=(), width=None, account_col=None, time_col=None):
    """Lay the rows of a table out as the network reads them: chunks of one account, padded to one width.

    df            a table with one row per transaction, in any order
    columns       names of numeric columns to lay out next to the times
    width         rows per chunk; None reads settings.HISTORY_LEN + 1
    account_col, time_col   column names; None reads settings

    Returns a dict of tensors, all of shape [chunks, width]:
      "valid"   bool; True at real rows. Real rows fill a chunk from the left, in time order
      "times"   int64 whole seconds (0 at padding)
      "row"     int64 position of the row in `df` (-1 at padding). It carries a result back to
                the table: `out[chunks["row"][valid]] = result[valid]`
      one entry per name in `columns`: whole-number columns as int64 with -1 at padding, the
      others as float32 with "not a number" at padding

    A chunk is simply the next `width` rows of an account. Rows of one second stay in the order
    they have in the table, which is not a trustworthy order; the masks of this folder never
    rely on it. A row with no time cannot be placed and is left out of every chunk.
    """
    width = settings.HISTORY_LEN + 1 if width is None else int(width)
    account = timekeys.codes(df[settings.ACCOUNT_COL if account_col is None else account_col])
    secs = timekeys.seconds(df[settings.TIME_COL if time_col is None else time_col])
    order = timekeys.stable_order(account, secs)                  # by account, then by second
    order = order[secs[order] != MISSING_SECOND]
    n = len(order)
    sorted_account = account[order]
    new_account = np.ones(n, dtype=bool)
    new_account[1:] = sorted_account[1:] != sorted_account[:-1]
    first = np.maximum.accumulate(np.where(new_account, np.arange(n), 0))
    slot = (np.arange(n) - first) % width                         # 0, 1, ..., width - 1, 0, 1, ... inside an account
    chunk = np.cumsum(slot == 0) - 1                              # a new chunk begins wherever the slot returns to 0
    n_chunks = int(chunk[-1]) + 1 if n else 0

    def lay(values, fill, dtype):
        out = np.full((n_chunks, width), fill, dtype=dtype)
        out[chunk, slot] = np.asarray(values)[order]
        return torch.from_numpy(out)

    out = {"valid": lay(np.ones(len(df), dtype=bool), False, bool),
           "times": lay(secs, 0, np.int64),
           "row": lay(np.arange(len(df)), -1, np.int64)}
    for name in columns:
        values = df[name].to_numpy()
        whole = np.issubdtype(values.dtype, np.integer) or values.dtype == bool
        out[name] = lay(values, -1, np.int64) if whole else lay(values.astype(np.float32), np.nan, np.float32)
    return out
