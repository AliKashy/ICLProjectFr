"""A learning rate that warms up and then falls to its end value over the planned number of steps.

What this file does
-------------------
It gives the factor by which the peak learning rate is multiplied at every training step: a
straight rise during the first steps (the warm-up), then a fall along half a cosine wave down
to a chosen share of the peak at the last planned step. `planned_steps` computes that last
step from the number of rows, the batch size and the number of passes. `schedule` wraps the
factor for a torch optimizer, and `lightning_entry` returns what a Lightning module hands back
from `configure_optimizers` so that the rate changes at every step.

Why it exists
-------------
A run that passes once or twice over a very large set of rows has one or two epoch ends. A
rule that lowers the learning rate when an end-of-epoch validation figure stops improving
therefore never acts, and the weights finish at the starting rate, where each step still
moves them by a noticeable amount: the last checkpoint is a noisy one. A rate that falls on
a fixed plan does not wait for validation. Late steps are small, so the model settles on
what the whole pass taught it. The warm-up is there because the first steps of an adaptive
optimizer are taken on poor estimates of the gradient's size; small first steps keep them
from sending the weights far away.

Where it goes
-------------
Training: where the optimizer is built. The scheduler is stepped once per optimizer step,
not once per epoch. Nothing in the network or in scoring changes.

What to change for the pod
--------------------------
`WARMUP_SHARE` (or a fixed number of warm-up steps), `FINAL_RATIO`, and the numbers that give
the planned steps: rows per pass, rows per optimizer step, passes. When gradients are
accumulated over several batches, the rows per optimizer step are the batch size times that
number. The plan needs the number of rows the run will really read: with thinned accounts or
masked rows, count the rows that reach the loader, not the rows of the files. If the run is
longer than planned, the rate stays at its end value and never rises again; if the run is
stopped early, the rate has not come down yet, so the plan should match the hours available.

How to try it
-------------
    total = planned_steps(rows_per_pass=500_000_000, rows_per_step=4096, passes=1)
    scheduler = schedule(optimizer, total)             # scheduler.step() after every optimizer step
    factor(0, total), factor(total // 2, total), factor(total, total)
    # in a Lightning module:
    return lightning_entry(optimizer, total)
The test is additions/tests/test_training_lr_schedule.py.
"""
import math

import torch

# PLACEHOLDER: the share of the planned steps spent on the warm-up. A few percent is the usual
# choice; a fixed number of steps can be passed instead.
WARMUP_SHARE = 0.03

# PLACEHOLDER: the learning rate at the last planned step as a share of the peak. Zero lets the
# weights come to rest; a small value such as 0.01 keeps the last steps from being wasted.
FINAL_RATIO = 0.0


def planned_steps(rows_per_pass, rows_per_step, passes=1.0):
    """The number of optimizer steps of the whole run.

    rows_per_pass   rows the loader delivers in one pass over the training files
    rows_per_step   rows per optimizer step (the batch size times the number of accumulated batches)
    passes          passes over the files; a fraction is allowed (1.5 passes)

    The last batch of a pass is smaller, so the steps of one pass are rounded up.
    """
    per_pass = -(-int(rows_per_pass) // int(rows_per_step))
    return int(math.ceil(per_pass * float(passes)))


def warmup_length(total_steps, warmup_steps=None):
    """The number of warm-up steps: the given number, or WARMUP_SHARE of the plan; always below the plan's end."""
    wanted = int(round(WARMUP_SHARE * total_steps)) if warmup_steps is None else int(warmup_steps)
    return max(0, min(wanted, int(total_steps) - 1))


def factor(step, total_steps, warmup_steps=None, final_ratio=None):
    """The share of the peak learning rate at one optimizer step (the first step is step 0).

    During the warm-up the factor rises in equal steps and reaches 1 on the first step after
    it. From there it follows half a cosine wave down to `final_ratio` at `total_steps`. From
    the last planned step on it stays at `final_ratio`, so a run that is longer than planned
    keeps training at the end value.
    """
    final = FINAL_RATIO if final_ratio is None else float(final_ratio)
    total = int(total_steps)
    if total <= 0:
        return 1.0
    warm = warmup_length(total, warmup_steps)
    step = int(step)
    if step < warm:
        return (step + 1) / (warm + 1)
    if step >= total:
        return final
    progress = (step - warm) / max(1, total - warm)             # 0 at the end of the warm-up, 1 at the plan's end
    return final + (1.0 - final) * 0.5 * (1.0 + math.cos(math.pi * progress))


def schedule(optimizer, total_steps, warmup_steps=None, final_ratio=None):
    """A torch scheduler that multiplies the optimizer's learning rate by `factor` at every step.

    The learning rate the optimizer was built with is the peak. `scheduler.step()` is called
    once after every optimizer step.
    """
    return torch.optim.lr_scheduler.LambdaLR(
        optimizer, lambda step: factor(step, total_steps, warmup_steps, final_ratio))


def lightning_entry(optimizer, total_steps, warmup_steps=None, final_ratio=None):
    """What `configure_optimizers` of a Lightning module returns for this schedule.

    The interval is "step": Lightning then advances the scheduler after every optimizer step.
    With the default interval ("epoch") the rate would change once per pass, which is the
    behaviour this file replaces.
    """
    return {"optimizer": optimizer,
            "lr_scheduler": {"scheduler": schedule(optimizer, total_steps, warmup_steps, final_ratio),
                             "interval": "step", "frequency": 1}}
