"""Row weights for the loss: rows that can never carry a fraud label teach nothing.

What this file does
-------------------
It decides, for every row, whether the row takes part in the fraud loss, and it offers the
matching rule for scoring:

    row_classes               yes/no per row for each row type that the loss may leave out:
                                declined          declined before the fraud engine (the decline flag)
                                risk_decline      declined with one of the risk-decline response codes
                                advice            an advice row (a notice, not a live request)
                                zero_check        a zero-dollar check (address verification only)
                                excluded_segment  a segment the benchmark population leaves out
    loss_weights              0.0 for the rows of the chosen types, 1.0 for every other row
    chunk_weights             the same weights laid out as the network reads rows (chunks of
                              one account), with 0.0 at padding
    never_labelled            yes/no per row: can this row type ever carry a fraud label?
    rank_never_labelled_last  a copy of the scores in which those rows rank below every other row
    class_table               a plain table: rows, frauds and loss weight per row type

A row with weight 0.0 is NOT removed. It stays in its account's sequence and is read as
history by the rows after it; it only stops being a target. That is the whole point: the
declined attempt two minutes before a fraud is some of the best evidence the later rows have.

Why it exists
-------------
A fraud label sits only on approved rows, so declined attempts are never labelled, and neither
are advice rows or zero-dollar checks. Trained with the label as it stands, all of these rows
are "not fraud". Many declined attempts are fraud attempts that the bank stopped: they sit
inside fraud runs and look exactly like the frauds next to them. Training them as "not fraud"
teaches the model that what the bank already stopped is safe, and pushes it away from the very
patterns that fill the top of the ranking. Because the alert budget is a fixed small share of
rows, a few hundred such look-alikes near the cut are enough to move frauds out of it.

The benchmark population also leaves some rows out entirely (rows declined before the fraud
engine, and possibly a segment). A loss that is computed on rows the benchmark never scores
spends the model's capacity on a population that is not judged. Matching the loss population
to the scored population is the plain fix, and keeping those rows as history costs nothing.

At scoring time the same knowledge gives a rule: a row type that can never carry the label can
never count as a caught fraud, so ranking it last frees its alert places for rows that can.
Whether such a rule is allowed in a comparison is a question about the comparison, and it has
to be stated next to any figure read with it.

The row's own decision columns are used here only to choose which rows teach (training) and
which rows may be alerted (after scoring). They are never inputs of the model.

Where it goes
-------------
Head and loss, and scores. `loss_weights` makes one more per-row array beside the label (in
the original code those arrays are made in `SequenceBuilder._encode_file`, and the label
travels as `target_seq`). `chunk_weights` lays it out per chunk, and the loss of
`FTTransformerHierModel._step` becomes a weighted mean (`_loss_shared.weighted_mean`) instead
of a plain one. Nothing changes in `forward`: the rows are still in the sequence. After
scoring, `rank_never_labelled_last` is applied to the score column before the cut is drawn.

What to change for the pod
--------------------------
settings.py: DECLINE_FLAG_COL and DECLINE_FLAG_VALUES, REASON_COL, RISK_DECLINE_REASONS and
APPROVED_REASONS, ADVICE_COL, TYPE_COL and ZERO_CHECK_TYPES, SEGMENT_COL and EXCLUDED_SEGMENTS,
LABEL_COL and POSITIVE_LABEL, ID_COL, TRAIN_BASE and TRAIN_FILES. `ADVICE_EMPTY_VALUES` below
lists the values of the advice column that mean "not an advice row". Which row types to drop
is the `drop` argument: the default drops declines (by the flag), advice rows, zero-dollar
checks and excluded segments; `drop=("risk_decline",)` is the narrower variant that takes only
the risk-decline codes out of the loss. A column that is None in settings or absent from the
table switches its row type off with one printed line.

How to try it
-------------
    python additions/training/loss_masks.py --demo
    python additions/training/loss_masks.py --base /path/to/files --files 1 2 3 --drop risk_decline advice

    weight = loss_weights(df)                                  # float32 [rows]
    w = chunk_weights(weight, chunks)                          # [chunks, width], chunks from the builder
    loss = weighted_mean(per_row_ce, w)                        # _loss_shared.weighted_mean
    ranked = rank_never_labelled_last(scores, never_labelled(df))
    python -m pytest -q additions/tests/test_rows_loss_masks.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd
import torch

from additions import settings
from additions.common import synthetic, tables

# PLACEHOLDER: the values of the advice column that mean "this is not an advice row"; a missing
# value always means that. For a 0/1 flag use ("", "0"), for a Y/N flag ("", "N").
ADVICE_EMPTY_VALUES = ("",)

# Every row type this file knows, in the order of the tables it prints.
ROW_CLASSES = ("declined", "risk_decline", "advice", "zero_check", "excluded_segment")

# The row types that leave the loss by default. "risk_decline" is not in it because the decline
# flag already covers those rows; it exists for the narrower variant that drops only them.
DEFAULT_DROP = ("declined", "advice", "zero_check", "excluded_segment")


def has_code(values, codes):
    """Yes/no per row: is the value one of `codes`? A missing value never is.

    values   array or Series [rows]
    codes    the codes, written as text in settings ("00", "51", "A")

    A column of numbers is compared as numbers (the code "05" matches 5), a column of text as
    text with blanks stripped, so the same settings serve both ways of storing a code.
    """
    series = pd.Series(np.asarray(values))
    if pd.api.types.is_numeric_dtype(series.dtype):
        numbers = []
        for code in codes:
            try:
                numbers.append(float(code))
            except (TypeError, ValueError):
                pass                                   # a code such as "Y" cannot match a number
        return np.isin(series.to_numpy(dtype=np.float64), numbers)
    text = series.astype(str).str.strip()
    return (series.notna() & text.isin([str(c).strip() for c in codes])).to_numpy()


def _column(df, name, what):
    """The column `name` of `df`, or None with one printed line when it is switched off or absent."""
    if not name or name not in df.columns:
        reason = "no column is set" if not name else f"the table has no column '{name}'"
        print(f"note: {reason} for {what}; that row type is skipped")
        return None
    return df[name]


def row_classes(df, decline_flag_col=None, decline_flag_values=None, reason_col=None, risk_reasons=None,
                advice_col=None, advice_empty_values=None, type_col=None, zero_check_types=None,
                segment_col=None, excluded_segments=None):
    """Yes/no arrays per row type, for every row of `df`.

    df    a table of raw rows (any order); only the columns named below are read
    all other arguments   column names and code lists; None reads settings (or
                          ADVICE_EMPTY_VALUES for the advice column)

    Returns {row type: bool array [rows]} for the types whose column is available. A type whose
    column is switched off or absent is left out of the dict (one printed line), so the rest of
    the file treats it as "no row is of this type". A row may be of several types at once (an
    advice row with a decline code); every type is tested on its own.
    """
    out = {}
    flag = _column(df, settings.DECLINE_FLAG_COL if decline_flag_col is None else decline_flag_col,
                   "the decline flag (declined)")
    if flag is not None:
        values = settings.DECLINE_FLAG_VALUES if decline_flag_values is None else decline_flag_values
        out["declined"] = has_code(flag, values)
    reason = _column(df, settings.REASON_COL if reason_col is None else reason_col, "the response code (risk_decline)")
    if reason is not None:
        out["risk_decline"] = has_code(reason, settings.RISK_DECLINE_REASONS if risk_reasons is None else risk_reasons)
    advice = _column(df, settings.ADVICE_COL if advice_col is None else advice_col, "the advice flag (advice)")
    if advice is not None:
        empty = ADVICE_EMPTY_VALUES if advice_empty_values is None else advice_empty_values
        # A filled advice column marks a notice about a transaction, not a live request. Its
        # missing values and its "empty" values both mean "not an advice row".
        out["advice"] = advice.notna().to_numpy() & ~has_code(advice, empty)
    kind = _column(df, settings.TYPE_COL if type_col is None else type_col, "the transaction type (zero_check)")
    if kind is not None:
        out["zero_check"] = has_code(kind, settings.ZERO_CHECK_TYPES if zero_check_types is None else zero_check_types)
    excluded = settings.EXCLUDED_SEGMENTS if excluded_segments is None else excluded_segments
    if excluded:
        segment = _column(df, settings.SEGMENT_COL if segment_col is None else segment_col,
                          "the segment (excluded_segment)")
        if segment is not None:
            out["excluded_segment"] = has_code(segment, excluded)
    else:
        print("note: no excluded segment is set; the excluded_segment row type is skipped")
    return out


def loss_weights(df, drop=DEFAULT_DROP, classes=None, **columns):
    """The loss weight of every row: 0.0 for rows of the dropped types, 1.0 for all others.

    df        a table of raw rows
    drop      the row types (names from ROW_CLASSES) whose rows leave the loss
    classes   what `row_classes` returned, when it was already computed; None computes it
    columns   passed on to `row_classes` (column names and code lists)

    Returns float32 [rows]. Multiply it into any other row weight (padding, sampling) and use
    the product in a weighted mean. The rows with weight 0.0 must stay in the sequences: they
    are history for the rows after them, and removing them would change every later input.
    """
    unknown = [name for name in drop if name not in ROW_CLASSES]
    if unknown:
        raise ValueError(f"unknown row type(s) {unknown}; the known ones are {ROW_CLASSES}")
    classes = row_classes(df, **columns) if classes is None else classes
    out = np.ones(len(df), dtype=np.float32)
    for name in drop:
        if name in classes:                    # a type whose column is missing drops nothing
            out[classes[name]] = 0.0
    return out


def chunk_weights(row_weight, chunks):
    """Row weights laid out like the chunks the network reads, with 0.0 at padding.

    row_weight   [rows]: one weight per row of the table the chunks were made from
    chunks       a dict with "row" (int64 [chunks, width], -1 at padding) and "valid"
                 (bool [chunks, width]), as `_loss_shared.account_chunks` returns it; a real
                 builder can return the same two arrays

    Returns float32 tensor [chunks, width]. The "valid" mask is not changed: rows with weight
    0.0 remain real rows of the chunk, readable as history, and only their loss is switched off.
    """
    row = chunks["row"]
    valid = chunks["valid"]
    weight = torch.as_tensor(np.asarray(row_weight, dtype=np.float32))
    out = torch.zeros(row.shape, dtype=torch.float32)
    out[valid] = weight[row[valid]]
    return out


def never_labelled(df, classes=None, reason_col=None, approved_reasons=None, **columns):
    """Yes/no per row: a row of a type that can never carry a fraud label.

    df                 a table of raw rows (after scoring, joined to the scores)
    classes            what `row_classes` returned, or None to compute it
    reason_col, approved_reasons   the response code and the codes meaning "approved"; None
                       reads settings
    columns            passed on to `row_classes`

    Returns bool [rows]: True for declined rows (by the flag or by any response code that is
    not an approval), advice rows and zero-dollar checks. Only an approved live request can
    carry the label. An excluded segment is not part of this: its rows can be fraud, the
    benchmark simply does not score them.
    """
    classes = row_classes(df, reason_col=reason_col, **columns) if classes is None else classes
    out = np.zeros(len(df), dtype=bool)
    for name in ("declined", "risk_decline", "advice", "zero_check"):
        if name in classes:
            out |= classes[name]
    reason_col = settings.REASON_COL if reason_col is None else reason_col
    if reason_col and reason_col in df.columns:
        approved = settings.APPROVED_REASONS if approved_reasons is None else approved_reasons
        # Any code other than an approval (insufficient funds, other declines) also means the
        # label can never be set. A missing code is left alone: it may be an approved row whose
        # code was not recorded.
        out |= df[reason_col].notna().to_numpy() & ~has_code(df[reason_col], approved)
    return out


def rank_never_labelled_last(scores, never):
    """A copy of the scores in which the marked rows rank below every other row.

    scores   [rows] numpy array or torch tensor (probability or log-odds; only the order matters)
    never    bool [rows]: the rows to send to the bottom, usually `never_labelled(df)`

    Returns the same kind of array as `scores`. The marked rows all get one value, one below
    the lowest unmarked score, so they tie with each other at the very end and the order of
    the other rows is untouched. This is a scoring rule, not a training change: it frees the
    alert places that such rows would take, because they can never count as a caught fraud.
    """
    if torch.is_tensor(scores):
        never_t = torch.as_tensor(never, dtype=torch.bool, device=scores.device)
        out = scores.detach().clone()
        rest = out[~never_t & torch.isfinite(out)]
        low = (rest.min() if rest.numel() else torch.tensor(0.0, dtype=out.dtype)) - 1.0
        out[never_t] = low.to(out.dtype)
        return out
    out = np.array(scores, dtype=np.float64)
    never = np.asarray(never, dtype=bool)
    rest = out[~never & np.isfinite(out)]
    out[never] = (rest.min() if len(rest) else 0.0) - 1.0
    return out


def class_table(df, classes, weight, label_col=None, positive_label=None):
    """A plain table: per row type, how many rows, how many fraud labels, how many leave the loss.

    df        the table the classes were computed on
    classes   what `row_classes` returned
    weight    what `loss_weights` returned
    label_col, positive_label   None reads settings

    Returns a DataFrame with one line per available row type plus a line "in the loss" for the
    rows with a weight above zero. A row type with fraud labels on it is worth a look: by the
    data rules it should have none, and its rows lose their label if they are dropped.
    """
    label_col = settings.LABEL_COL if label_col is None else label_col
    positive = settings.POSITIVE_LABEL if positive_label is None else positive_label
    fraud = has_code(df[label_col], (positive,)) if label_col in df.columns else np.zeros(len(df), dtype=bool)
    n = max(len(df), 1)
    lines = []
    for name in ROW_CLASSES:
        if name in classes:
            rows = classes[name]
            lines.append({"row_type": name, "rows": int(rows.sum()), "share_of_rows": rows.sum() / n,
                          "fraud_rows": int((rows & fraud).sum()), "weight_zero": int((rows & (weight == 0)).sum())})
    kept = weight > 0
    lines.append({"row_type": "in the loss", "rows": int(kept.sum()), "share_of_rows": kept.sum() / n,
                  "fraud_rows": int((kept & fraud).sum()), "weight_zero": 0})
    return pd.DataFrame(lines, columns=["row_type", "rows", "share_of_rows", "fraud_rows", "weight_zero"])


def needed_columns():
    """The raw columns this file reads (None entries are optional columns that are switched off)."""
    return [settings.ID_COL, settings.LABEL_COL, settings.DECLINE_FLAG_COL, settings.REASON_COL,
            settings.ADVICE_COL, settings.TYPE_COL, settings.SEGMENT_COL]


def main(argv=None):
    """Command line: the loss weights of some files (or made-up rows), with a table per row type."""
    parser = argparse.ArgumentParser(description="Loss weights that leave never-labelled row types out of the loss.")
    parser.add_argument("--base", default=settings.TRAIN_BASE, help="folder that holds the numbered files")
    parser.add_argument("--files", type=int, nargs="+", default=None,
                        help="file numbers to read (default: settings.TRAIN_FILES)")
    parser.add_argument("--demo", action="store_true", help="run on made-up rows instead of files")
    parser.add_argument("--drop", nargs="+", default=list(DEFAULT_DROP), choices=ROW_CLASSES,
                        help="row types that leave the loss")
    parser.add_argument("--out", default=None, help="write the transaction id and the loss weight to this parquet file")
    args = parser.parse_args(argv)
    if args.demo:
        df = synthetic.make_transactions(n_accounts=300, seed=1)
    else:
        df = tables.read_files(args.base, args.files or settings.TRAIN_FILES, needed_columns())
    classes = row_classes(df)
    weight = loss_weights(df, drop=args.drop, classes=classes)
    print(f"{len(df)} rows; dropped from the loss: {', '.join(args.drop)}")
    print(class_table(df, classes, weight).to_string(index=False, float_format=lambda x: f"{x:.4f}"))
    if args.out:
        out = pd.DataFrame({"loss_weight": weight})
        if settings.ID_COL in df.columns:
            out.insert(0, settings.ID_COL, df[settings.ID_COL].to_numpy())
        tables.write_table(out, args.out)
        print(f"written: {args.out}")
    return weight


if __name__ == "__main__":
    main()
