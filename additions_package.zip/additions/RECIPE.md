# The next runs: scoring, settings, order and reads

`BEST_MODEL.md` gives the long order of work for the strongest model. This note is the short
range: what to do in the next runs, with which settings, and how to read the results. It was
written on 25 November 2026 after the first result of the gated field re-read and after two
independent checks of a first draft. Where a value was read in a paper the paper is named;
where it is a judgement the note says so.

## 1. Where things stand

| Fact | Where it comes from |
|---|---|
| The gated re-read, trained alone for one night on the finished model, raised AP by about 2 points and UDR and VDR by about 2 to 3 points each | reported from the pod: one seed, one read, the design with the memory of 5; the base values and the rows of the read are not on record |
| Scoring 947 thousand rows with that model took more than 9 hours | reported from the pod |
| The scorer builds one window for every scored row (the rows of up to 120 distinct earlier seconds of the account in the same file, then the row, padded to at least 121 slots, with no cap) and keeps the last real row's score | read in the scorer's code |
| The block makes one window 2.3 times (A), 2.9 to 3.3 times (M) and 3.6 times (AM) as heavy to score as the model without it | measured on a CPU with the stand-in model at the pod's shapes; the ratio on a GPU has to be measured |
| The learning rate of the current recipe is in practice never lowered | read in the training configuration; to be confirmed in the pod's own log |
| The batch size of 4,096 counts chunks, not rows | read in the training configuration; the number of steps of a pass therefore has to be read from a run's log |
| The standard read has 1,418 frauds; two runs must differ by 0.02 to 0.03 UDR to be told apart on it | worked out earlier from the size of the read |

## 2. The decision

No single large run on the current setup. The current recipe never lowers its learning rate, so
a new run would carry that fault and no comparison with the old model could separate the
recipe from the architecture. The order is: what needs no training, then short runs on the
finished model, then runs from scratch that differ in one thing each, then the winners
together at full scale.

## 3. Step 0: no training

1. **The history that scored rows receive.** The scorer builds a window from the rows of the
   same account in the same file only. A benchmark whose history rows sit in other files than
   its scored rows is scored with almost no history, and no change to the model repairs that.
   The scored output carries the size of every row's window: compare it with the history the
   pool holds for the same accounts. This comes first for the benchmark of 12 million
   targets, where the model is far below the tree model and the foundation model.
2. **Scoring that is fast enough to read experiments.** In this order:
   - the run says which device it scores on (the scorer takes the CPU without a word when it
     finds no GPU);
   - one window for all rows of an account that share a first row (an option of the program's
     scoring tool, off by default; the scores stay as they are up to rounding, and an account
     whose rows lie within 121 distinct seconds of a file is then one window where it was one
     per row). On a first use one file is scored both ways and the two outputs are compared on
     their id columns before the option is trusted;
   - loader workers above zero, and one scoring process for every GPU over separate ranges of
     files;
   - the mark of scored rows handed to the model, which the re-read uses (section 8 of
     `INTERLEAVED_REREAD.md`);
   - `reads/scoring_speed.py` around the scoring loop for thirty batches says where the time
     goes.
3. **Two blocks of evaluation files.** One to choose on and one to confirm on, of about equal
   size (ten files each where they exist). Every choice is made on the first; every number
   that is reported comes from the second. The standard read is read once, at the end.
   Every model that is compared is scored the same way: the same window rule, the same cap.
4. **The night's result, read again.** The finished model and the model with the block, on the
   same choose block, with a paired interval that resamples accounts
   (`proof/head_to_head.py`).
5. **How much history there is.** For every scored row, fraud row and fraud dollar: the
   number of distinct earlier seconds of its account, in the three-month pool and as the
   scored file delivers it. The window counts seconds, not rows, so the count does too.
   Then the current model scored with its history cut at 30, 60 and 120, read only on the
   rows that have at least 120 earlier seconds. A rise says that history is used. A flat line
   says little: the model was trained on chunks in which a row saw half a window on average.
6. **What the finished model is worth to the tree model.** Scores and vectors made out of
   fold on training months, a tree model fitted on them beside its own features, read on an
   untouched month (`DOWNSTREAM.md`). And the CPU screens of the input families that the
   window cannot hold, such as counts and amounts over 7, 30 and 90 days
   (`after_model/family_screen.py`). Neither needs a training run of the network.
7. **Three measurements that every later step needs.** The optimiser steps of one pass, from
   a run's log. The time of one training step for every arm, from fifty steps each: on a CPU
   the stand-in took 3.0 times (A), 4.9 times (M) and 7.8 times (AM) as long per training
   step as the model without the block. The spread between seeds: three seeds of the control
   at the reduced scale of step 2.

## 4. Step 1: short runs on the finished model

Each run takes hours. Together they decide which design of the block is carried.

1. **Cooldown.** The finished model, every weight trainable, the learning rate from 3e-4 in a
   straight line to zero over 10 to 20 percent of a pass, no block, two seeds. It shows what
   lowering the rate alone gives, and its result is the base for everything below.
2. **The block on the cooled model, held still.** One run each for M, AM and A, all with the
   same schedule: block rate 1e-3, a warm-up over the first 1 percent of the steps, a straight
   fall to zero (judgement). With them:
   - the control for "field evidence or only more weights": the same block, handed one
     learned table of 64 vectors that is the same for every row in place of the bank. The
     block keeps its weights and its question; the evidence of the row is gone;
   - two cheaper variants: the bank without its attention (the predictor tokens as they are),
     and a memory of 2 rows.
   Every arm is read on the choose block, with its scoring cost beside it. The margin that
   counts as "as good" is fixed before the runs; the chosen design is read once more on the
   confirm block.
3. **The pair that can be defended.** The whole-model cooldown of item 1 against the same
   cooldown with the chosen block in: the same schedule, the same steps, two seeds. Trained
   weights at 6e-5 and the block at 9e-5 when the block comes from item 2 (the ratio is from
   nuFormer, arXiv 2507.23267; the values are judgement).

Dropout inside the block is 0.1 by default; it is stated with every result.

## 5. Step 2: runs from scratch

At a reduced scale first (about 250 files, or the number of steps that fits one day), each run
with its schedule falling to zero inside its own budget. A run that is cut short is not a
short run.

### The settings

| Setting | Value | Basis |
|---|---|---|
| Schedule | a warm-up over the first 2 percent of the steps, then a straight fall to zero at the last planned step | read: training under a fixed budget does best with a rate that falls smoothly to zero (arXiv 1905.04753, 2502.15938, 2405.18392); the 2 percent is judgement |
| Peak learning rate | three values for every architecture at 5 percent of the budget, each a complete run of its own: 1.5e-4, 3e-4 and 6e-4 at today's size, half of each when the history stage is 288 wide | judgement; no source gives the value. Every architecture is compared at its own best rate |
| Weight decay in a sweep | the rate times the weight decay is held fixed across the arms | read: with the usual optimiser the effective decay moves with the rate (arXiv 2309.14322) |
| Gradient clipping | global norm 1.0 | read as the common setting (arXiv 2410.24210, 2309.14322) |
| Everything else | as in the current configuration: dropout, weight decay, mixed precision, batch, passes, loss | an earlier check found no evidence that a change helps, and a control that changes eight things cannot be read |
| One bundled arm | weight decay 0.01, no dropout, 32-bit numbers | read: the settings of the large payment models (arXiv 2611.15814, 2511.08939); tested once, together |
| The checkpoint that is the model | the last step | fixed beforehand; validation on training months follows the evaluation month only weakly |
| Seeds | the control with three seeds first; the number for every later arm is set from that spread (`proof/noise_budget.py`) | two seeds do not settle a gain of 0.01 UDR |

One more arm for the schedule: the rate falling to 10 percent of its peak in place of zero
(one source found that falling to exactly zero cost a little downstream, arXiv 2405.18392).

### The arms

Each differs from the control in one thing. The cost is the estimated number of multiply-adds
against the model of today, without the block; it is not a measured time.

| Arm | The one change | Cost | What it answers |
|---|---|---|---|
| Control, three seeds | today's model with the schedule above | 1.0 | what the schedule gives; the spread between seeds |
| The block | the design chosen in step 1, in from the first step | to be measured | what the block gives when the whole model learns with it |
| The block's control | the same block with the learned table in place of the bank | as the block | whether a gain of the block is field evidence |
| Four heads in stage 1 | 12 numbers for each head where there are 6 | 1.0 | whether the narrow heads of stage 1 hold it back (a head narrower than the sequence it reads is a known limit, arXiv 2002.07028) |
| One more layer in stage 1 | 3 layers | about 1.2 | more depth on the side of the transaction |
| Six summary tokens | the note 288 wide, the history layers four times as large | about 3.0 | a larger hand-off and history stage |
| Full-history training rows | chunks that overlap and score only their tail (`training/lookback_cut.py`) | to be measured | whether the model uses a long history when it is trained on one |
| Inputs that passed their screen | counts and amounts over 7, 30 and 90 days as predictors | about 1.1 | what the window cannot hold |
| Next-transaction heads | one more loss on every row (`training/next_transaction_heads.py`) | about 1.0 | learning from every row, not only from the labels |
| Token width 96, last | tokens of 96 and a note of 288 | about 3.9 | only when the cheaper arms point that way; with two rates |

The first five are the first batch. Token width 96 with the history stage left at 144 (the
joined summary tokens projected down) costs about 2.0 and separates the token width from the
size of the history stage.

## 6. Step 3: together, at full scale

The arms that held, in one model, beside a control at the same scale: every training file and
more of the non-fraud accounts (more rows that were not seen before come before more passes),
three seeds, read once on the confirm block and then once on the standard read. Its scores and
vectors go to the tree model, which is the result the production side uses.

## 7. What waits

- **A longer window.** 120 stays until the count of step 0, the probe and the full-history arm
  say that more helps. A longer window needs a new position table (the learned one cannot be
  read past its last entry, arXiv 2108.12409): the 121 learned rows stretched and trained on,
  or a time encoding that needs no table and a run from scratch.
- **Channels kept apart through the history**, as the Large Payments Model has them (about a
  fifth as many channels as fields, each with its own history attention, mixed between the
  layers). Six joined summary tokens are the first step in that direction. Channels need a
  new stage 2 and a full run; the published model came with pretraining on up to 400 billion
  tokens, and no published test sets channels against a joined note.
- **A re-read on a side stream.** Re-reads at every layer that write into a read-out of the
  row which no other row reads. Every row can still be trained, and at scoring only the
  scored row's read-out is needed, so it would cost about what design M costs. It has not
  been built.

## 8. Reading a result

- A gain is believed when the paired difference on the choose block is above the spread
  between seeds and it shows again on the confirm block.
- Two models are compared only when they were scored the same way.
- A number that is shown to others comes from the confirm block or from the standard read,
  never from the rows a choice was made on.
