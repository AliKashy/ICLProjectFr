# The order of work for the strongest model

This note puts the pieces of this folder in the order in which they are worth doing when the
aim is the best fraud model, not a tour of every idea. Each step names what is done, why it
sits where it does, and the files that hold its code. `SWEEP.md` remains the plan for testing
every piece once; this note is the short path through it.

The measure is the one used throughout: the share of all frauds, and of fraud dollars, inside
the top 0.6 percent of rows by score, on the same rows for every model, with a paired interval
that resamples whole accounts (`proof/head_to_head.py`).

## The steps

| Step | What is done | Why it sits here | Files |
|---|---|---|---|
| 1 | **Prove what exists.** Count how much history every scored row really has. Compare models on the same rows. Run three seeds of the current recipe. Switch each part of the current model off once (no re-read, one summary token, no history, no row weights). | Every later step is judged against this. A scored set whose rows arrive without their history turns a history model into a single-row model, and no architecture repairs that. One seed cannot tell a gain from run-to-run spread. | `reads/history_census.py`, `proof/head_to_head.py`, `proof/noise_budget.py`, `sweep/plan.py` (tier `control`) |
| 2 | **Hand the frozen model to the tree model.** Scores and vectors made out of fold on training months, a tree model fitted on them next to its own features, read on an untouched month. | It needs no new training of the network and it is the result the production side uses. A network and a tree model on engineered features see different things; together they have beaten either alone wherever it was measured. | `DOWNSTREAM.md`, `exports/bundle.py`, `exports/stage1_hook.py`, `after_model/second_stage.py`, `training/offset_head.py` |
| 3 | **Field evidence while history is read.** A gated re-read of one representation per predictor after every history layer, and a memory of the fields of the latest earlier rows. First on the trained model with everything else held still, then with the whole model training at a low rate. | Stage 1 squeezes a transaction before the account is known, and what it drops is gone for every history layer. This is the largest change to the network itself that starts from the trained weights without changing a score. | `INTERLEAVED_REREAD.md`, `model/interleaved_reread.py`, `model/interleaved_wiring_template.py` |
| 4 | **Inputs the history window cannot give.** Counts and amounts over 7, 30 and 90 days, exact-match columns (this merchant, this amount, this place before), merchant and geography inputs, the bank's earlier decisions. Each family is screened on the CPU first; only what passes gets a training run. | A window of the latest rows does not hold a quarter of a busy account, and a tree model on such columns is what the network is compared with. Published sequence models that beat production models read such aggregates as inputs. | `features/possible_features.py` (135 entries), `features/exact_match.py`, `features/novelty_amount.py`, `features/geo_velocity.py`, `features/outcome_history.py`, `merchant/`, `after_model/family_screen.py`, `encoding/capped_vocab.py` |
| 5 | **A wider hand-off between the stages.** One, three, six and twelve summary tokens. | More of every earlier transaction reaches the history layers. It changes the width of stage 2, so it needs a full training run and is tried after step 3 has shown what field evidence is worth. | `model/summary_tokens.py`, `model/history_stage.py` |
| 6 | **A memory beyond the window.** A stored account state in front of the history, and a learned bias on attention for "same value" and time gap. | Older rows than the window holds, at the cost of a few positions. | `model/state_prefix.py`, `after_model/account_state_vectors.py`, `model/attention_bias.py` |
| 7 | **Training.** Heads that predict the next transaction beside the fraud loss; training rows that see the history scored rows see; rows that can carry no label kept as history without a loss; averaged weights; a learning rate that falls to its end value; a calendar input whose scored value was never trained taken care of. | Each is a setting on a run that is made anyway. The next-transaction heads train on every row, not only on the rare labelled ones. | `training/next_transaction_heads.py`, `training/auxiliary_heads.py`, `training/lookback_cut.py`, `training/loss_masks.py`, `training/weight_averaging.py`, `training/lr_schedule.py`, `reads/month_token.py`, `encoding/numeric_frontend.py` |
| 8 | **Scale.** Every training file, and a wider model. | Size pays only once the inputs and the hand-off are right; published gains from size come from models several times this one. | `settings.py` (`EMBED_DIM`, `STAGE1_BLOCKS`, `STAGE2_BLOCKS`, `TRAIN_FILES`) |
| 9 | **Put together what held.** One run with every piece that passed, three seeds, read once on rows no choice was made on. | Pieces that each help do not always add up. | `sweep/promote.py`, `proof/head_to_head.py` |

## What one night allows

Step 3 on the trained model with everything else held still: the trained model is its own
comparison, so one run per design is a complete experiment. Steps 1 and 2 need no change to
the network and can run beside it.

## What is not in this folder

The model in use, its tokenizer and its training loop. Every piece here takes plain tensors
or tables and says in its own docstring where it goes and what has to change to fit.
