"""Unknown-value dropout: make the "unknown" row of every code table a trained state.

What this file does
-------------------
During training it swaps a code for the unknown index of its table with a small
probability, field by field. A calendar field whose value in the scored month was never
trained gets a higher rate. It is never applied at scoring. The pieces:

    field_rates              the swap rate of every code field, from the field names
    unknown_dropout_numpy    the swap on a numpy array of codes [..., K] (for a data loader)
    unknown_dropout_torch    the same on a torch tensor (for the training step)
    UnknownDropout           a torch module that swaps in training mode and does nothing in eval mode
    trained_codes            which codes of every field occur in the training rows
    unseen_to_unknown        at scoring: send every code that training never saw to the unknown row

Why it exists
-------------
A code table has one row for "a value the vocabulary does not know". That row is updated
only when a training row carries the unknown code. When the vocabulary was fitted on the
training files themselves, no training row ever does, so the row still holds the random
numbers it started with. At scoring a value that appeared later lands on that row, and the
model adds an untrained vector to exactly the rows on which it has the least to go on. The
exported vector of those rows carries the same noise, so a downstream tree model reads
shifted columns on them.

The same happens, on every scored row at once, with a calendar field. The evaluation files
start one month before the scored month, and the training rows come from earlier months;
unless they reach back a full year to the same calendar month, the month of the scored rows
is a value that no training row had. Its row was never trained and no
amount of training on earlier months can change that.

Swapping codes for the unknown index during training teaches the unknown row what to
believe when the value is not given: an average over the values, in the proportions in
which they occur. An unseen value then lands on a trained state. The higher rate for the
calendar field makes "month not given" an ordinary situation, so the scored month can be
sent to the unknown row on purpose. A small rate also keeps the model from leaning on any
single code entirely. The price is that a strong code is hidden on a few training rows,
which is why the rate is set per field and kept small.

Where it goes
-------------
Preprocessing and tokenizer, in training only. The swap acts on the integer codes just
before the code tables are read: in the original code on `batch["categorical"]` at the top
of `FTTransformerHierModel.forward` when the model is in training mode (or in `_step` for
the training tag), before `FeatureTokenizer.forward` looks the codes up in
`cat_embeddings`. The numpy version does the same inside a training data loader.

At scoring nothing is swapped at random. Scoring an unseen value with the trained unknown
row takes two steps, both where the codes are built (`SequenceBuilder._encode_file`). A
value that the vocabulary does not hold must be encoded as UNKNOWN_INDEX; most encoders
already do that. A value that the vocabulary holds but training never saw (the month of
the scored month, a code that only occurs in files the model was not trained on) is
replaced by `unseen_to_unknown`. For a model that was trained without this file,
reads/month_token.py holds repairs that act at scoring time only.

What to change for the pod
--------------------------
UNKNOWN_INDEX (the row that stands for an unknown value; one number, or one per field),
DEFAULT_RATE, CALENDAR_RATE, CALENDAR_FIELDS and NO_UNKNOWN_SUFFIXES below, and
settings.CODE_COLS (the default list of field names). A field without an unknown row must
have rate 0: for a yes/no flag the code 0 is a real value, and swapping it would turn
"missing" into "present". Padded positions are protected by passing `real`.

How to try it
-------------
    rates = field_rates(["transaction_type_xcd", "month", "transaction_amt_isna"])    # 0.05, 0.3, 0.0
    drop = UnknownDropout(rates)                                 # inside the model
    codes = drop(codes, real=mask)                               # swaps only while model.training is True

    trained = trained_codes(train_codes, cardinalities)          # once, on the training rows
    codes = unseen_to_unknown(codes, trained)                    # at scoring, before the model
    python -m pytest -q additions/tests/test_encoding_unknown_dropout.py
"""
import numpy as np
import torch
import torch.nn as nn

from additions import settings

# PLACEHOLDER: the row of a code table that stands for "a value the vocabulary does not know".
UNKNOWN_INDEX = 0

# PLACEHOLDER: the share of training rows on which an ordinary code field is swapped for unknown.
DEFAULT_RATE = 0.05

# PLACEHOLDER: the swap rate of a calendar field whose value in the scored month was never trained.
CALENDAR_RATE = 0.3

# PLACEHOLDER: the names of those calendar fields among the code fields of the model.
CALENDAR_FIELDS = ("month",)

# PLACEHOLDER: endings of the names of code fields that have no unknown row (two-valued flags whose
# code 0 is a real value, such as the is-missing flags of numeric inputs). They are never swapped.
NO_UNKNOWN_SUFFIXES = ("_isna",)


def field_rates(field_names=None, rate=None, calendar_rate=None, calendar_fields=None, no_unknown_suffixes=None,
                overrides=None):
    """The swap rate of every code field, as float64 [K] in the order of `field_names`.

    field_names           the code fields in the order of the code array (default settings.CODE_COLS)
    rate                  the rate of an ordinary field (default DEFAULT_RATE)
    calendar_rate         the rate of a calendar field (default CALENDAR_RATE)
    calendar_fields       names that get the calendar rate (default CALENDAR_FIELDS)
    no_unknown_suffixes   name endings that get rate 0 (default NO_UNKNOWN_SUFFIXES)
    overrides             {field name: rate} for single fields; it wins over every rule above

    A field with very many values that is mostly a memory aid (a merchant id) can be given a
    high rate through `overrides`, which stops the model from relying on it.
    """
    names = list(settings.CODE_COLS if field_names is None else field_names)
    rate = DEFAULT_RATE if rate is None else rate
    calendar_rate = CALENDAR_RATE if calendar_rate is None else calendar_rate
    calendar_fields = CALENDAR_FIELDS if calendar_fields is None else calendar_fields
    suffixes = tuple(NO_UNKNOWN_SUFFIXES if no_unknown_suffixes is None else no_unknown_suffixes)
    out = np.full(len(names), float(rate))
    for k, name in enumerate(names):                     # a loop over the fields, a few dozen at most
        if name in calendar_fields:
            out[k] = calendar_rate
        if suffixes and str(name).endswith(suffixes):
            out[k] = 0.0
        if overrides and name in overrides:
            out[k] = overrides[name]
    return out


def unknown_dropout_numpy(codes, rates, unknown_index=None, real=None, whole_sequence=False, training=True,
                          rng=None):
    """Swap codes for the unknown index at random; the numpy version, for a training data loader.

    codes            whole numbers [..., K]; the last axis runs over the K code fields
    rates            the swap rate per field, [K] (from `field_rates`), or one number for all fields
    unknown_index    the unknown row: one number or [K] (default UNKNOWN_INDEX)
    real             yes/no [...] without the field axis: True on real rows. Padded positions are
                     never swapped. None means every position is real
    whole_sequence   True with codes [B, T, K]: one draw per sequence and field, so all rows of a
                     sequence lose a field together. That is how a calendar value that was never
                     trained looks when a whole window lies in the scored month
    training         False returns `codes` untouched; scoring code can call the function safely
    rng              a numpy Generator or a seed; None draws fresh numbers on every call

    Returns a new array of the shape and type of `codes`; the input is not changed. Every
    entry is either its old value or the unknown index, and each entry is swapped on its own
    draw, so a row usually loses at most one or two fields.
    """
    codes = np.asarray(codes)
    if not training:
        return codes
    shape = list(codes.shape)
    if whole_sequence and codes.ndim >= 3:
        shape[-2] = 1                                    # one draw for all rows of a sequence
    swap = np.random.default_rng(rng).random(shape) < np.asarray(rates, dtype=np.float64)
    if real is not None:
        swap = swap & np.asarray(real, dtype=bool)[..., None]
    unknown = np.asarray(UNKNOWN_INDEX if unknown_index is None else unknown_index, dtype=codes.dtype)
    return np.where(swap, unknown, codes)


def unknown_dropout_torch(codes, rates, unknown_index=None, real=None, whole_sequence=False, training=True,
                          generator=None):
    """Swap codes for the unknown index at random; the torch version, for the training step.

    The arguments are those of `unknown_dropout_numpy`, with tensors in place of arrays:
    `codes` is a whole-number tensor [..., K], `real` a yes/no tensor [...], and `generator`
    an optional torch.Generator on the device of `codes`. Returns a new tensor of the shape
    and type of `codes`. Codes carry no gradient, so nothing has to flow through the swap;
    the unknown row learns because the rows that were swapped now read it.
    """
    if not training:
        return codes
    shape = list(codes.shape)
    if whole_sequence and codes.dim() >= 3:
        shape[-2] = 1                                    # one draw for all rows of a sequence
    rates = torch.as_tensor(rates, dtype=torch.float32, device=codes.device)
    swap = torch.rand(shape, generator=generator, device=codes.device) < rates
    if real is not None:
        swap = swap & real.bool().unsqueeze(-1)          # a padding mask of 0/1 numbers works as well
    unknown = UNKNOWN_INDEX if unknown_index is None else unknown_index
    return torch.where(swap, torch.as_tensor(unknown, dtype=codes.dtype, device=codes.device), codes)


class UnknownDropout(nn.Module):
    """The swap as a module: active in training mode, the identity in eval mode.

    rates            the swap rate per field, [K] (from `field_rates`)
    unknown_index    the unknown row: one number or [K] (default UNKNOWN_INDEX)
    whole_sequence   see `unknown_dropout_numpy`

    forward(codes, real=None): codes [..., K] whole numbers, real [...] yes/no; returns codes
    of the same shape. Because the module follows `model.train()` and `model.eval()`, scoring
    can never swap a code by accident. The rates are settings, not weights: they are kept out
    of the saved state, so a checkpoint loads the same with or without this module.
    """

    def __init__(self, rates, unknown_index=None, whole_sequence=False):
        super().__init__()
        unknown = UNKNOWN_INDEX if unknown_index is None else unknown_index
        self.register_buffer("rates", torch.as_tensor(np.asarray(rates), dtype=torch.float32), persistent=False)
        self.register_buffer("unknown", torch.as_tensor(np.asarray(unknown), dtype=torch.long), persistent=False)
        self.whole_sequence = whole_sequence

    def forward(self, codes, real=None):
        """codes [..., K] in, codes of the same shape out; a code is swapped only in training mode."""
        return unknown_dropout_torch(codes, self.rates, self.unknown.to(codes.dtype), real, self.whole_sequence,
                                     self.training)


def trained_codes(codes, cardinalities, min_rows=1):
    """Which codes of every field the training rows hold: a list of K yes/no arrays.

    codes           whole numbers [..., K] of the training rows (numpy), before any swap
    cardinalities   the number of rows of each field's table, [K]
    min_rows        a code counts as trained when at least this many training rows carry it

    Entry k has one yes/no per row of table k. A code can be in the vocabulary and still be
    untrained: a month that the calendar knows but the training files do not reach, or a code
    that only occurs in files the vocabulary was fitted on and the model was not trained on.
    With `min_rows` above one, codes with very few rows count as untrained too; the same
    replacement then has to be applied to the training rows, so that training and scoring agree.
    """
    codes = np.asarray(codes)
    flat = codes.reshape(-1, codes.shape[-1])
    counts = []
    for k, size in enumerate(cardinalities):             # one count per field, never per row
        column = flat[:, k]
        counts.append(np.bincount(column[column >= 0], minlength=int(size))[: int(size)] >= min_rows)
    return counts


def unseen_to_unknown(codes, trained, unknown_index=None):
    """At scoring: replace every code that training never saw by the unknown index.

    codes           whole numbers [..., K], a numpy array or a torch tensor
    trained         the list from `trained_codes` (fitted on the training rows, stored with the model)
    unknown_index   the unknown row: one number or [K] (default UNKNOWN_INDEX)

    Returns codes of the same kind and shape. A code outside its table is also sent to the
    unknown row. This is the step that lets an unseen value be scored with the trained
    unknown row; it draws nothing at random and gives the same answer on every call.
    """
    unknown = np.broadcast_to(np.asarray(UNKNOWN_INDEX if unknown_index is None else unknown_index), (len(trained),))
    is_tensor = torch.is_tensor(codes)
    out = codes.clone() if is_tensor else np.array(codes)
    for k, known in enumerate(trained):                  # a loop over the fields
        column = out[..., k]
        if is_tensor:
            known = torch.as_tensor(known, dtype=torch.bool, device=codes.device)
            inside = (column >= 0) & (column < len(known))
            seen = inside & known[column.clamp(0, len(known) - 1)]
            out[..., k] = torch.where(seen, column, torch.full_like(column, int(unknown[k])))
        else:
            inside = (column >= 0) & (column < len(known))
            seen = inside & np.asarray(known, dtype=bool)[np.clip(column, 0, len(known) - 1)]
            out[..., k] = np.where(seen, column, unknown[k])
    return out
