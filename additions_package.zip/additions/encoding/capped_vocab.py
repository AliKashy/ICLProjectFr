"""A capped vocabulary and a tiered embedding for a field with very many values (a merchant id).

What this file does
-------------------
It turns a field with far too many values for one table row each into a small code field:

    fit_vocab         on training rows: keep the values seen on enough different accounts, rank them
                      by their number of rows, and split them into a full-width tier and a narrow tier
    encode            any rows: the table index of every row. A kept value reads its own row; every
                      other value reads one of a small number of shared rows
    text_keys, shared_rows   the arithmetic that picks the shared row from (category, id): a fixed
                      mixing of the characters, written out in whole-number arithmetic. It only
                      spreads values over the shared rows; it identifies nothing and checks nothing
    TieredEmbedding   the torch table: full-width rows, narrow rows projected up to the token
                      width, shared rows; in training it sends a kept value to its shared row now
                      and then, so that the shared rows are trained
    tier_report       how many rows of a table land in each tier
    save_vocab, load_vocab   the fitted vocabulary as one file of plain arrays

Why it exists
-------------
Stage 2 can only match "the same merchant as an earlier row" exactly when the merchant is
part of the row's vector, and a large merchant has a stable identity worth learning. A
table with one row per merchant is the wrong way to get either. Trained on the fraud
label, a merchant's row learns how often that merchant's rows were fraud in the training
files: an in-sample fraud rate per merchant, with no time lag and with the row's own
account counted in. The files hold whole accounts and no account is in two files, so a
merchant's rows are present only for the accounts in the files that were read; for most
merchants that is a handful of accounts, and the rate is noise that the model memorises.
The table also goes stale. Fraud labels arrive weeks after the transaction, so the newest
rows of a merchant under attack still say "not fraud"; a point of compromise is abandoned
once it is known; and a merchant that first appears in the scored month has no row at all.

Equality features therefore come first. "Is this the merchant of an earlier row of the
account" needs no table and no learned weight per merchant, works for merchants that were
never in training, and cannot memorise a label (features/exact_match.py and
features/recurrence_tokens.py build it). The capped table is the second step, for what
equality cannot say. The caps are what keep it honest: a value gets a row only when many
accounts contribute to it; the weights go where the rows are; every other value, seen or
unseen, lands on a shared row that depends on its category; and a kept value is sent to
its shared row on a share of the training rows, so the model cannot lean on identity alone
and the fallback is a trained state. A gain from this token should be read on the scored
month: a gain that shows only on rows from the training period is memory, not signal.

Where it goes
-------------
Raw files, then one more code field. `fit_vocab` runs once on the training files and the
vocabulary is stored with the model. `encode` runs in the per-file encoding
(`SequenceBuilder._encode_file` in the original code) and adds one whole-number column to
the code array. `TieredEmbedding` sits beside the other code tables of the tokenizer
(`FeatureTokenizer.cat_embeddings`): the field's token is `tiered(index)`.

What to change for the pod
--------------------------
settings.py: MERCHANT_COL (the field), ACCOUNT_COL, MCC_COL (the category; None or absent
means the shared row depends on the id alone), EMBED_DIM, TRAIN_BASE and TRAIN_FILES. In
this file: MIN_ACCOUNTS, N_FULL, N_NARROW, NARROW_DIM, N_SHARED, SHARED_PER_CATEGORY and
REPLACE_RATE. The sizes should follow the number of training files: with few files only
the very largest merchants pass MIN_ACCOUNTS. Whether an id means the same merchant in
every file should be confirmed before the token is trusted.

How to try it
-------------
    python additions/encoding/capped_vocab.py --demo
    python additions/encoding/capped_vocab.py --base /path/to/training/files --files 1 2 3 --out merchant_vocab.npz

    vocab = fit_vocab(train_df)                          # training rows only
    index = encode(df, vocab)                            # int64 [rows]: one more code field
    table = TieredEmbedding.from_vocab(vocab)            # tokens = table(torch.as_tensor(index))
    python -m pytest -q additions/tests/test_encoding_capped_vocab.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd
import torch
import torch.nn as nn

from additions import settings
from additions.common import synthetic, tables, timekeys

# PLACEHOLDER: a value needs rows on at least this many different accounts to get a row of its own.
MIN_ACCOUNTS = 50

# PLACEHOLDER: how many of the busiest kept values get a full-width row.
N_FULL = 5_000

# PLACEHOLDER: how many of the next busiest values get a narrow row, and the width of a narrow row.
N_NARROW = 50_000
NARROW_DIM = 12

# PLACEHOLDER: the number of shared rows for all other values, and over how many of them the
# values of one category are spread.
N_SHARED = 4_096
SHARED_PER_CATEGORY = 8

# PLACEHOLDER: the share of training rows on which a value with its own row reads its shared row instead.
REPLACE_RATE = 0.2

# The two constants of the byte-folding step in `text_keys` (a published pair for 64-bit numbers).
_START = np.uint64(14695981039346656037)
_STEP = np.uint64(1099511628211)


# ----------------------------------------------------------------------------------------------
# stable whole-number keys, by integer arithmetic only
# ----------------------------------------------------------------------------------------------

def _as_text(value):
    """One value as text; a whole number stored as a decimal is written without the point (5.0 is "5")."""
    if isinstance(value, (float, np.floating)) and float(value).is_integer():
        return str(int(value))
    return str(value).strip()


def _coded_text(values):
    """(codes, texts): int64 [rows] with -1 on a missing value, and the distinct values as text.

    Values are compared as text so that an id stored as a number in one set of files and as
    text in another is still the same id. A blank text counts as missing. The conversion
    loops over the distinct values only, never over the rows.
    """
    values = np.asarray(values)
    codes = timekeys.codes(values)                       # a missing value is one more code at this point
    _, example = np.unique(codes, return_index=True)     # one example row per code
    distinct = values[example]
    as_text = np.array(["" if pd.isna(v) else _as_text(v) for v in distinct], dtype=str)
    present = as_text != ""
    final = np.full(len(distinct), -1, dtype=np.int64)
    texts = as_text[:0]
    if present.any():
        final[present] = timekeys.codes(as_text[present])            # values that are equal as text share one code
        _, example = np.unique(final[present], return_index=True)
        texts = as_text[present][example]
    return final[codes], texts


def mix(keys):
    """Stir 64-bit whole numbers so that every bit of the result depends on every bit of the input.

    Shifts, exclusive-or and multiplications modulo 2**64, nothing else. Without this step the
    low bits of a key, which decide the shared row, would depend on the last characters only.
    """
    x = np.array(keys, dtype=np.uint64, ndmin=1)
    x ^= x >> np.uint64(30)
    x *= np.uint64(0xBF58476D1CE4E5B9)
    x ^= x >> np.uint64(27)
    x *= np.uint64(0x94D049BB133111EB)
    x ^= x >> np.uint64(31)
    return x


def text_keys(texts):
    """One stable 64-bit whole number per text: uint64 [n] for an array of n texts.

    The bytes of a text are folded in one after the other: the running number is combined
    with the byte by exclusive-or and multiplied by a fixed odd constant, modulo 2**64; `mix`
    finishes. The key depends on the characters alone, so it is the same in every run, on
    every machine and in any language that can multiply whole numbers. Python's built-in
    way of turning a text into a number changes from one process to the next and cannot be
    used for this. The loop runs over the character positions of the longest text, never
    over the rows.
    """
    texts = np.asarray(texts, dtype=str)
    if len(texts) == 0:
        return np.zeros(0, dtype=np.uint64)
    raw = np.char.encode(texts, "utf-8")                 # bytes of equal width; shorter texts end in zeros
    letters = np.frombuffer(raw.tobytes(), dtype=np.uint8).reshape(len(raw), raw.dtype.itemsize)
    keys = np.full(len(raw), _START, dtype=np.uint64)
    for position in range(letters.shape[1]):
        byte = letters[:, position].astype(np.uint64)
        keys = np.where(byte != 0, (keys ^ byte) * _STEP, keys)      # the zeros after the end are skipped
    return mix(keys)


def shared_rows(id_keys, category_keys=None, n_shared=None, per_category=None):
    """The shared row of every value: int64 [n] between 0 and n_shared - 1.

    id_keys         uint64 [n] from `text_keys` of the ids
    category_keys   uint64 [n] from `text_keys` of the categories, or None when there is no category
    n_shared        the number of shared rows (default N_SHARED)
    per_category    over how many rows the ids of one category are spread (default SHARED_PER_CATEGORY)

    With a category, the category picks a home row and the id picks one of the `per_category`
    rows that start there:  row = (category_key % n_shared + id_key % per_category) % n_shared.
    Small merchants of one category then share a few rows, so a shared row means "a small or
    new merchant of this kind" and not a random mixture. Without a category the id alone picks
    the row. Two different values can land on one row; that is the point of sharing.
    """
    n_shared = np.uint64(N_SHARED if n_shared is None else n_shared)
    id_keys = np.asarray(id_keys, dtype=np.uint64)
    if category_keys is None:
        return (id_keys % n_shared).astype(np.int64)
    spread = np.uint64(min(SHARED_PER_CATEGORY if per_category is None else per_category, int(n_shared)))
    home = np.asarray(category_keys, dtype=np.uint64) % n_shared
    return ((home + id_keys % spread) % n_shared).astype(np.int64)


# ----------------------------------------------------------------------------------------------
# the vocabulary (numpy, fitted on training rows)
# ----------------------------------------------------------------------------------------------

def _category_texts(df, category_col):
    """(codes, texts) of the category column with "" for a missing category, or None without the column."""
    name = settings.MCC_COL if category_col is None else category_col
    if not name or name not in df.columns:
        print("note: no category column; the shared row then depends on the id alone")
        return None
    codes, texts = _coded_text(df[name])
    return np.where(codes < 0, len(texts), codes), np.append(texts, "")


def fit_vocab(df, id_col=None, account_col=None, category_col=None, min_accounts=None, n_full=None,
              n_narrow=None, n_shared=None, per_category=None):
    """Fit the capped vocabulary on training rows.

    df             training rows (rows of training files only)
    id_col         the field with very many values (default settings.MERCHANT_COL)
    account_col    the account (default settings.ACCOUNT_COL)
    category_col   the category that goes with an id (default settings.MCC_COL); pass "" for none
    min_accounts   a value is kept when it has rows on at least this many accounts (default MIN_ACCOUNTS)
    n_full, n_narrow, n_shared, per_category   the tier sizes (defaults at the top of the file)

    Returns the vocabulary, a dict of plain values:
      full_ids       text [F]: the busiest kept values, busiest first. Table index 1 + position
      narrow_ids     text [W]: the next busiest. Table index 1 + F + position
      fallback       int64 [1 + F + W]: for every own row, the index of the shared row its value
                     would read if it were not kept (entry 0, the "no value" row, points to itself)
      n_shared, per_category   the sizes used for the shared rows

    The cap counts accounts, not rows. A merchant with many rows from one account is a habit
    of that account, and a row learned from it would be a fact about that account. The rank
    inside the kept values is by rows, because that is how much training a row will get.
    No label is read.
    """
    codes, texts = _coded_text(df[settings.MERCHANT_COL if id_col is None else id_col])
    account = timekeys.codes(df[settings.ACCOUNT_COL if account_col is None else account_col])
    has = codes >= 0
    rows = np.bincount(codes[has], minlength=len(texts))
    # Different accounts per value: every (value, account) pair is counted once.
    _, first = np.unique(timekeys.codes(codes[has], account[has]), return_index=True)
    accounts = np.bincount(codes[has][first], minlength=len(texts))
    kept = np.flatnonzero(accounts >= (MIN_ACCOUNTS if min_accounts is None else min_accounts))
    # Busiest first; values with equal rows are put in the order of their text, so that the
    # result does not depend on the order of the rows.
    kept = kept[np.lexsort((texts[kept], -rows[kept]))]
    n_full = N_FULL if n_full is None else int(n_full)
    n_narrow = N_NARROW if n_narrow is None else int(n_narrow)
    own = kept[: n_full + n_narrow]
    vocab = {"full_ids": texts[own[:n_full]], "narrow_ids": texts[own[n_full:]],
             "n_shared": int(N_SHARED if n_shared is None else n_shared),
             "per_category": int(SHARED_PER_CATEGORY if per_category is None else per_category)}
    # Where each kept value falls when it is replaced in training: the shared row of (its category, id).
    category_keys = None
    category = _category_texts(df, category_col)
    if category is not None and len(own):
        cat_codes, cat_texts = category
        # The category of a value is the one most of its rows carry (the smaller text on a tie).
        pair, count = np.unique(codes[has] * len(cat_texts) + cat_codes[has], return_counts=True)
        value, cat = pair // len(cat_texts), pair % len(cat_texts)
        best = np.lexsort((cat_texts[cat], -count, value))
        best = best[np.r_[True, value[best][1:] != value[best][:-1]]]          # the first pair of every value
        usual = np.zeros(len(texts), dtype=np.int64)
        usual[value[best]] = cat[best]
        category_keys = text_keys(cat_texts)[usual[own]]
    shared = shared_rows(text_keys(texts[own]), category_keys, vocab["n_shared"], vocab["per_category"])
    vocab["fallback"] = np.concatenate(([0], 1 + len(own) + shared)).astype(np.int64)
    return vocab


def encode(df, vocab, id_col=None, category_col=None):
    """The table index of every row: int64 [rows], one more code field for the network.

    df             any rows (training or scoring)
    vocab          the dict from `fit_vocab`
    id_col, category_col   as in `fit_vocab`

    The index space, with F full-width values, W narrow values and S shared rows:
      0                          the row has no value
      1 .. F                     a full-width row of its own
      F + 1 .. F + W             a narrow row of its own
      F + W + 1 .. F + W + S     a shared row, picked by `shared_rows` from (category, id)
    A value that was not kept, or that did not exist when the vocabulary was fitted, reads a
    shared row; nothing is ever "unknown", and nothing is fitted here.
    """
    codes, texts = _coded_text(df[settings.MERCHANT_COL if id_col is None else id_col])
    own = np.concatenate([np.asarray(vocab["full_ids"], dtype=str), np.asarray(vocab["narrow_ids"], dtype=str)])
    category = _category_texts(df, category_col)
    index = np.zeros(len(codes), dtype=np.int64)         # 0 stays on every row without a value
    has = codes >= 0
    if has.any():
        value = codes[has]
        place = pd.Index(own).get_indexer(texts)[value]  # the value's own row, or -1 when it has none
        category_keys = None if category is None else text_keys(category[1])[category[0][has]]
        shared = shared_rows(text_keys(texts)[value], category_keys, vocab["n_shared"], vocab["per_category"])
        index[has] = np.where(place >= 0, 1 + place, 1 + len(own) + shared)
    return index


def tier_report(index, vocab):
    """How the rows of a table spread over the tiers: a DataFrame with one line per tier.

    index   int64 [rows] from `encode`
    Columns: tier, table_rows (rows of the embedding table in the tier), rows and share (rows
    of the data that read the tier). The share that lands on shared rows in the scored month,
    against the same share in training, shows how fast the vocabulary ages.
    """
    n_full, n_narrow = len(vocab["full_ids"]), len(vocab["narrow_ids"])
    ends = np.array([1, 1 + n_full, 1 + n_full + n_narrow])
    tier = np.searchsorted(ends, np.asarray(index), side="right")        # 0 none, 1 full, 2 narrow, 3 shared
    rows = np.bincount(tier, minlength=4)
    return pd.DataFrame({"tier": ["no value", "full width", "narrow", "shared"],
                         "table_rows": [1, n_full, n_narrow, int(vocab["n_shared"])],
                         "rows": rows, "share": rows / max(len(tier), 1)})


def save_vocab(vocab, path):
    """Write the vocabulary to one file of plain arrays in numpy's .npz form (an existing file is replaced)."""
    with open(path, "wb") as handle:
        np.savez(handle, full_ids=np.asarray(vocab["full_ids"], dtype=str),
                 narrow_ids=np.asarray(vocab["narrow_ids"], dtype=str), fallback=vocab["fallback"],
                 n_shared=vocab["n_shared"], per_category=vocab["per_category"])
    return path


def load_vocab(path):
    """Read a vocabulary written by `save_vocab`."""
    with np.load(path) as stored:
        return {"full_ids": stored["full_ids"], "narrow_ids": stored["narrow_ids"], "fallback": stored["fallback"],
                "n_shared": int(stored["n_shared"]), "per_category": int(stored["per_category"])}


# ----------------------------------------------------------------------------------------------
# the table (torch)
# ----------------------------------------------------------------------------------------------

class TieredEmbedding(nn.Module):
    """An embedding table in three tiers, read with the index from `encode`.

    n_full, n_narrow, n_shared   the tier sizes F, W and S
    embed_dim      width d of a token (default settings.EMBED_DIM)
    narrow_dim     width of a narrow row (default NARROW_DIM)
    fallback       int64 [1 + F + W] from the vocabulary; None switches the replacement off
    replace_rate   share of training rows on which an own row is replaced (default REPLACE_RATE)

    forward(index): whole numbers [...] from `encode`; returns [..., d].

    The busiest values get d numbers each. The next tier gets `narrow_dim` numbers and one
    shared linear map up to d: a value with fewer rows has less to learn from, and fewer
    numbers of its own leave less room to memorise. All other values read shared rows of
    full width, which are the best-trained rows of all. In training mode an index that
    points to an own row is replaced by its fallback with probability `replace_rate`; the
    shared rows then also see the traffic of the large merchants, and a value that is not
    in the vocabulary at scoring lands on a row that knows what merchants of its category
    look like. In eval mode nothing is replaced.
    """

    def __init__(self, n_full, n_narrow, n_shared, embed_dim=None, narrow_dim=None, fallback=None, replace_rate=None):
        super().__init__()
        embed_dim = settings.EMBED_DIM if embed_dim is None else int(embed_dim)
        narrow_dim = NARROW_DIM if narrow_dim is None else int(narrow_dim)
        self.n_full, self.n_narrow, self.n_shared = int(n_full), int(n_narrow), int(n_shared)
        self.replace_rate = 0.0 if fallback is None else float(REPLACE_RATE if replace_rate is None else replace_rate)
        # Full-width rows in one table: the "no value" row, the busiest values, then the shared rows.
        self.wide = nn.Embedding(1 + self.n_full + self.n_shared, embed_dim)
        if self.n_narrow:
            self.narrow = nn.Embedding(self.n_narrow, narrow_dim)
            self.narrow_up = nn.Linear(narrow_dim, embed_dim, bias=False)
            # With this spread a projected narrow row starts as wide as a full-width row.
            nn.init.normal_(self.narrow_up.weight, std=narrow_dim ** -0.5)
        n_own = 1 + self.n_full + self.n_narrow
        own = torch.arange(n_own) if fallback is None else torch.as_tensor(np.asarray(fallback))
        self.register_buffer("fallback", own.long())

    @classmethod
    def from_vocab(cls, vocab, embed_dim=None, narrow_dim=None, replace_rate=None):
        """The table that fits a vocabulary from `fit_vocab`, with its fallback rows."""
        return cls(len(vocab["full_ids"]), len(vocab["narrow_ids"]), vocab["n_shared"], embed_dim, narrow_dim,
                   vocab["fallback"], replace_rate)

    def forward(self, index):
        """Table indexes [...] from `encode` in, vectors [..., embed_dim] out.

        In training a kept value reads its shared row now and then, so the shared rows are trained.
        """
        last_own = self.n_full + self.n_narrow
        if self.training and self.replace_rate > 0:
            # Only own rows are replaced; the "no value" row and the shared rows stay what they are.
            drawn = torch.rand(index.shape, device=index.device) < self.replace_rate
            swap = (index >= 1) & (index <= last_own) & drawn
            index = torch.where(swap, self.fallback[index.clamp(max=last_own)], index)
        is_narrow = (index > self.n_full) & (index <= last_own)
        # Position in the wide table: shared rows move down by the size of the narrow tier.
        wide_index = torch.where(index > last_own, index - self.n_narrow, index)
        out = self.wide(torch.where(is_narrow, torch.zeros_like(index), wide_index))
        if self.n_narrow:
            narrow_index = torch.where(is_narrow, index - self.n_full - 1, torch.zeros_like(index))
            out = torch.where(is_narrow.unsqueeze(-1), self.narrow_up(self.narrow(narrow_index)), out)
        return out


def main(argv=None):
    """Command line: fit the vocabulary on training files (or made-up rows) and print the tiers."""
    parser = argparse.ArgumentParser(description="Fit a capped vocabulary for a field with very many values.")
    parser.add_argument("--base", default=settings.TRAIN_BASE, help="folder that holds the numbered training files")
    parser.add_argument("--files", type=int, nargs="+", default=None,
                        help="file numbers to read (default: settings.TRAIN_FILES)")
    parser.add_argument("--demo", action="store_true", help="run on made-up rows with small tiers")
    parser.add_argument("--min-accounts", type=int, default=None, help="accounts a value needs (default: MIN_ACCOUNTS)")
    parser.add_argument("--n-full", type=int, default=None, help="size of the full-width tier (default: N_FULL)")
    parser.add_argument("--n-narrow", type=int, default=None, help="size of the narrow tier (default: N_NARROW)")
    parser.add_argument("--n-shared", type=int, default=None, help="number of shared rows (default: N_SHARED)")
    parser.add_argument("--out", default=None, help="write the vocabulary to this .npz file")
    args = parser.parse_args(argv)

    if args.demo:
        df = synthetic.make_transactions(n_accounts=300, seed=1)
        sizes = (args.min_accounts or 20, args.n_full or 20, args.n_narrow or 40, args.n_shared or 16)
    else:
        df = tables.read_files(args.base, args.files or settings.TRAIN_FILES,
                               [settings.MERCHANT_COL, settings.ACCOUNT_COL, settings.MCC_COL])
        sizes = (args.min_accounts, args.n_full, args.n_narrow, args.n_shared)
    vocab = fit_vocab(df, min_accounts=sizes[0], n_full=sizes[1], n_narrow=sizes[2], n_shared=sizes[3])
    report = tier_report(encode(df, vocab), vocab)
    print(f"{len(df)} rows, field '{settings.MERCHANT_COL}'")
    print(report.to_string(index=False, float_format=lambda x: f"{x:.4f}"))
    if args.out:
        save_vocab(vocab, args.out)
        print(f"written: {args.out}")
    return report


if __name__ == "__main__":
    main()
