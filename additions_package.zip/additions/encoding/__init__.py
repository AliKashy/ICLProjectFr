"""How numbers and codes are turned into tokens before stage 1.

capped_vocab.py      a capped vocabulary and a tiered embedding for a field with very many values (a
                     merchant id)
numeric_encoders.py  numbers as tokens with the encoder as a switch: fixed bins, learned bins,
                     Fourier features, or all three
numeric_frontend.py  numbers as tokens: a log or quantile scale, learned bins, and a table for the
                     risk score
text_init.py         a category table that starts from text: description vectors, projected to the
                     token width
time_encoders.py     time as row inputs: the gap to the latest earlier row under the model's rule,
                     the clock and the calendar
unknown_dropout.py   unknown-value dropout: make the "unknown" row of every code table a trained
                     state
"""
