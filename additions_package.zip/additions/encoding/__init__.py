"""How numbers and codes are turned into tokens before stage 1.

capped_vocab.py      a capped vocabulary and a tiered embedding for a field with very many values (a
                     merchant id)
numeric_frontend.py  numbers as tokens: a log or quantile scale, learned bins, and a table for the
                     risk score
text_init.py         a category table that starts from text: description vectors, projected to the
                     token width
unknown_dropout.py   unknown-value dropout: make the "unknown" row of every code table a trained
                     state
"""
