"""A category table that starts from text: description vectors, projected to the token width.

What this file does
-------------------
It gives the embedding table of a code field (the merchant category, or any code field whose
values have a written meaning) a starting point made from the descriptions of its values,
instead of random numbers. The pieces:

    load_descriptions     read {code value: description text} from a small csv or parquet file
    embed_texts           one vector per text. PLACEHOLDER: the default is a stand-in made from
                          character n-gram and word counts with numpy, so that the file runs; it is
                          meant to be replaced by a real text encoder
    initial_rows          text vectors [n, D] to table rows [n, d]: centred, projected on their
                          principal components, scaled to the spread of a freshly started table
    copy_into_table       write those rows into an nn.Embedding at the rows of the described values
    init_embedding_from_text   all of the above in one call, for a table of a model being built
    made_up_descriptions  invented descriptions for the tests and the demo

Why it exists
-------------
A code table learns one row per value from the rows that carry the value. A common category
gets millions of rows and learns its row well whatever it started from. A rare category gets
a few hundred, and its row stays close to the random numbers it began with: two kinds of
merchant that are close in meaning (two sorts of fuel station, two sorts of travel agent)
start in unrelated corners of token space and the network has to learn each from its own
few rows. Started from the descriptions, a rare category begins next to the categories whose
descriptions are close to its own, so what is learned on the common one carries over before
the rare one has been seen much. A value that is in the vocabulary but never in the training
rows also keeps a row that says what kind of merchant it is, instead of untrained noise. The
exported vector of a row then places such categories near their kin, which a downstream tree
model reads as columns that agree with the common categories instead of shifted ones.

The text encoder is used once, offline, on a few hundred strings. Nothing about it runs at
training or scoring time, and no label is read: the starting rows depend on the descriptions
alone. With very many rows per category the table may learn everything from the data anyway,
so the gain can be zero; the only test is a training run with and without the starting rows.

Where it goes
-------------
Stage 1, the tokenizer, at the moment the model is built and before the first training step.
In the original code the code tables are `FeatureTokenizer.cat_embeddings` (one nn.Embedding
per code field, built in `FTTransformerHierModel.__init__`); `init_embedding_from_text` is
called on the table of the category field, with the vocabulary that maps a category value to
its row (the vocabulary that `SequenceBuilder._encode_file` uses to turn values into codes).
A model loaded from a checkpoint already has trained rows and must not be started again.

What to change for the pod
--------------------------
settings.py: MCC_COL (the field; only the demo reads it) and EMBED_DIM. In this file:
DESCRIPTIONS_PATH, DESCRIPTION_CODE_COL and DESCRIPTION_TEXT_COL (where the descriptions are
and how their columns are named), TEXT_DIM and NGRAM_SIZES (the stand-in encoder) and
INIT_STD. Most important: replace the body of `embed_texts` by a real text encoder (a
sentence encoder run once on the descriptions; its vectors can be saved and read back). The
code values in the description file must be written the way the vocabulary writes them; the
two are compared as text, with a whole number stored as a decimal written without the point.

How to try it
-------------
    python additions/encoding/text_init.py --demo
    python additions/encoding/text_init.py --descriptions category_texts.csv --out category_rows.npz

    descriptions = load_descriptions("category_texts.csv")          # {code: text}
    report = init_embedding_from_text(model_table, vocab, descriptions)   # vocab: {code: row}
    python -m pytest -q additions/tests/test_encoding_text_init.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse
import re

import numpy as np
import pandas as pd
import torch

from additions import settings
from additions.common import synthetic, tables
from additions.encoding.capped_vocab import text_keys

# PLACEHOLDER: the file that holds one description per code value (csv or parquet), or None.
DESCRIPTIONS_PATH = None

# PLACEHOLDER: the column of that file that holds the code value, and the one that holds its text.
DESCRIPTION_CODE_COL = "code"
DESCRIPTION_TEXT_COL = "description"

# PLACEHOLDER: the length of a stand-in text vector; a real text encoder sets its own length.
TEXT_DIM = 512

# PLACEHOLDER: the character n-gram lengths that the stand-in encoder counts, besides whole words.
NGRAM_SIZES = (3, 4)

# PLACEHOLDER: the spread of a freshly started table row; 1.0 is what nn.Embedding starts with.
# Only the command line uses it: `init_embedding_from_text` measures the spread of the table it
# is given, so the starting rows match whatever start the model's own code chose.
INIT_STD = 1.0


# ----------------------------------------------------------------------------------------------
# reading the descriptions
# ----------------------------------------------------------------------------------------------

def code_text(value):
    """One code value as text: a whole number stored as a decimal loses the point (5411.0 is "5411").

    The description file and the vocabulary may store the same code as a number in one place
    and as text in the other. Comparing both as text written this way makes them meet.
    """
    if isinstance(value, (float, np.floating)) and float(value).is_integer():
        return str(int(value))
    return str(value).strip()


def load_descriptions(path=None, code_col=None, text_col=None, filesystem=None):
    """Read {code value as text: description} from a csv or parquet file.

    path        the file (default DESCRIPTIONS_PATH); a name ending in .parquet is read as parquet,
                anything else as csv
    code_col    the column of code values (default DESCRIPTION_CODE_COL)
    text_col    the column of descriptions (default DESCRIPTION_TEXT_COL)

    Returns a dict. Rows with no code or an empty description are left out; when a code has
    several rows the last one wins. Without a file one line is printed and the dict is empty,
    so a model is then built with its usual random start.
    """
    path = DESCRIPTIONS_PATH if path is None else path
    code_col = DESCRIPTION_CODE_COL if code_col is None else code_col
    text_col = DESCRIPTION_TEXT_COL if text_col is None else text_col
    if path is None:
        print("note: no description file is set; the table keeps its random start")
        return {}
    if str(path).endswith(".parquet"):
        df = tables.read_columns(path, [code_col, text_col], filesystem)
    else:
        df = pd.read_csv(path, dtype=str, keep_default_na=False)
    out = {}
    for code, text in zip(df[code_col], df[text_col]):   # a few hundred rows: a plain loop is clear
        if pd.isna(code) or pd.isna(text) or not code_text(code) or not str(text).strip():
            continue                                     # a blank code or a blank text says nothing
        out[code_text(code)] = str(text).strip()
    return out


# ----------------------------------------------------------------------------------------------
# text to vectors
# ----------------------------------------------------------------------------------------------

def _pieces(text, ngram_sizes):
    """The pieces the stand-in encoder counts in one text: whole words and character n-grams.

    The text is lower-cased, every run of characters that is not a letter or a digit becomes
    one space, and a space is put at both ends, so that n-grams at the start and end of a word
    are marked as such. Words are prefixed with "w:" so that a word never collides with an
    n-gram that happens to spell the same characters.
    """
    clean = " " + re.sub(r"[^a-z0-9]+", " ", str(text).lower()).strip() + " "
    pieces = ["w:" + word for word in clean.split()]
    for n in ngram_sizes:
        pieces.extend(clean[i:i + n] for i in range(len(clean) - n + 1))
    return pieces


def embed_texts(texts, dim=None, ngram_sizes=None):  # PLACEHOLDER: replace the body by a real text encoder.
    """One vector per text: float64 [n, dim] for a list of n texts.

    texts         descriptions, any list of strings
    dim           length of a vector (default TEXT_DIM)
    ngram_sizes   character n-gram lengths to count (default NGRAM_SIZES)

    This default is a stand-in so that the file runs without any model. Every word and every
    character n-gram of a text is turned into a stable 64-bit key (`capped_vocab.text_keys`,
    plain whole-number arithmetic, the same in every run). The key picks one of `dim` slots
    and, from another of its bits, a sign; the signed counts are added up per slot. The
    counts are then softened with log(1 + count), keeping the sign, so that a piece that
    occurs five times does not outweigh five different pieces, and every vector is scaled to
    length one so that long and short descriptions are comparable. A text with no letters or
    digits gets a vector of zeros.

    Texts that share words and word stems get vectors that point the same way, which is all
    that the starting rows need. A real text encoder also knows that "petrol" and "fuel" mean
    the same; the stand-in does not. Whatever replaces it must return one row per text, in
    the order given, and the same vector for the same text on every call.
    """
    dim = TEXT_DIM if dim is None else int(dim)
    ngram_sizes = NGRAM_SIZES if ngram_sizes is None else tuple(ngram_sizes)
    texts = [str(t) for t in texts]
    out = np.zeros((len(texts), dim))
    # The pieces are cut out with a Python loop over the texts: there are a few hundred short
    # descriptions, and string slicing has no useful numpy form. The keys and counts that
    # follow are computed for all pieces at once.
    piece_lists = [_pieces(t, ngram_sizes) for t in texts]
    owner = np.repeat(np.arange(len(texts)), [len(p) for p in piece_lists])
    flat = [piece for pieces in piece_lists for piece in pieces]
    if not flat:
        return out
    distinct, which = np.unique(np.asarray(flat, dtype=str), return_inverse=True)
    keys = text_keys(distinct)[which]
    slot = (keys % np.uint64(dim)).astype(np.int64)
    sign = np.where(((keys >> np.uint64(40)) & np.uint64(1)) == 1, 1.0, -1.0)
    # Signed slots: two pieces that land in the same slot cancel as often as they add, so a
    # collision blurs the vector less than a plain count would.
    np.add.at(out, (owner, slot), sign)
    out = np.sign(out) * np.log1p(np.abs(out))
    length = np.linalg.norm(out, axis=1, keepdims=True)
    return np.where(length > 0, out / np.where(length > 0, length, 1.0), 0.0)


# ----------------------------------------------------------------------------------------------
# vectors to table rows
# ----------------------------------------------------------------------------------------------

def initial_rows(vectors, width=None, std=None):
    """Text vectors [n, D] to starting rows [n, width] with the spread of a fresh table.

    vectors   float [n, D], one text vector per described value (n of at least 2)
    width     the token width d (default settings.EMBED_DIM)
    std       the spread of one number of a freshly started row (default INIT_STD)

    Returns (rows, kept): rows float64 [n, width] and kept, the number of principal
    components used.

    The steps, and why:
      1. Centre the vectors on their mean. A random table has mean zero; rows that all share
         one large offset would look alike to the network, which is the opposite of the aim.
      2. Project on the principal components (a singular value decomposition) and keep the
         first `width` of them. These are the directions in which the descriptions differ
         most, so the projection keeps as much of the "which is close to which" as `width`
         numbers can hold. When every component fits (fewer texts than the width, as for a
         small code field) the distances between rows are kept exactly, up to one common factor.
      3. Fix the sign of each component so that its largest entry is positive. A
         decomposition may return a direction or its opposite; fixing the sign makes the
         result the same whatever the order of the texts.
      4. Scale all rows by one common factor so that the mean square of their numbers equals
         std**2, which is the spread of a randomly started row. One factor for everything
         keeps the relative distances; the right overall size keeps the first steps of
         training as they would be with the usual start.
    Components beyond the rank of the vectors (at most n - 1 after centring) carry nothing
    and are left at zero; training fills them.
    """
    width = settings.EMBED_DIM if width is None else int(width)
    std = INIT_STD if std is None else float(std)
    x = np.asarray(vectors, dtype=np.float64)
    if x.ndim != 2 or len(x) < 2:
        raise ValueError("initial_rows needs at least two text vectors, as an array [n, D]")
    x = x - x.mean(axis=0)
    u, s, _ = np.linalg.svd(x, full_matrices=False)
    # Components whose size is rounding noise next to the largest one are not real directions.
    kept = int(min(width, (s > 1e-9 * max(float(s[0]), 1e-300)).sum()))
    scores = u[:, :kept] * s[:kept]
    if kept:
        biggest = np.abs(scores).argmax(axis=0)
        scores = scores * np.where(scores[biggest, np.arange(kept)] < 0, -1.0, 1.0)
    rows = np.zeros((len(x), width))
    rows[:, :kept] = scores
    mean_square = float((rows ** 2).mean())
    if mean_square > 0:
        rows *= std / np.sqrt(mean_square)
    return rows, kept


def copy_into_table(table, value_to_row, codes, rows):
    """Write starting rows into an nn.Embedding at the rows of their values.

    table          a torch nn.Embedding with weight [V, d]
    value_to_row   {code value: row of the table}, the field's vocabulary (keys compared as text)
    codes          the code values, [n], in the order of `rows`
    rows           float [n, d] from `initial_rows`

    Returns int64 [m], the table rows that were written. A code that the vocabulary does not
    hold is skipped. Every other row of the table (the unknown row, values without a
    description) keeps exactly what it had. The weights stay ordinary trainable weights.
    """
    lookup = {code_text(k): int(v) for k, v in value_to_row.items()}
    pairs = [(lookup[code_text(c)], i) for i, c in enumerate(codes) if code_text(c) in lookup]
    target = np.array([p[0] for p in pairs], dtype=np.int64)
    source = np.array([p[1] for p in pairs], dtype=np.int64)
    if len(target):
        with torch.no_grad():                            # a start value, not a step of training
            values = torch.as_tensor(np.asarray(rows)[source], dtype=table.weight.dtype, device=table.weight.device)
            table.weight[torch.as_tensor(target, device=table.weight.device)] = values
    return target


def init_embedding_from_text(table, value_to_row, descriptions, embed_fn=None, init_std=None):
    """Start a category table from the descriptions of its values.

    table          nn.Embedding [V, d] of the field, freshly built (not from a checkpoint)
    value_to_row   {code value: row of the table}, the vocabulary of the field
    descriptions   {code value: text}, for example from `load_descriptions`
    embed_fn       a function from a list of n texts to float [n, D] (default `embed_texts`)
    init_std       the spread of the starting rows; None measures the spread of the table as
                   it is now, so the rows match whatever start the model's own code chose

    Returns a dict: described (values with a description), in_table (of those, values the
    vocabulary holds), written (int64 table rows that were set) and components (principal
    components used). Only values that are both described and in the vocabulary take part,
    so the projection is fitted on exactly the rows it writes. With fewer than two such
    values nothing is changed and one line is printed.
    """
    embed_fn = embed_texts if embed_fn is None else embed_fn
    lookup = {code_text(k) for k in value_to_row}
    codes = [code_text(c) for c in descriptions if code_text(c) in lookup]
    report = {"described": len(descriptions), "in_table": len(codes), "written": np.zeros(0, np.int64),
              "components": 0}
    if len(codes) < 2:
        print(f"note: {len(codes)} described value(s) are in the vocabulary; the table keeps its random start")
        return report
    by_text = {code_text(c): t for c, t in descriptions.items()}
    vectors = np.asarray(embed_fn([by_text[c] for c in codes]), dtype=np.float64)
    std = float(table.weight.detach().float().std()) if init_std is None else float(init_std)
    rows, kept = initial_rows(vectors, table.embedding_dim, std)
    report.update(written=copy_into_table(table, value_to_row, codes, rows), components=kept)
    return report


# ----------------------------------------------------------------------------------------------
# made-up descriptions and the command line
# ----------------------------------------------------------------------------------------------

# Families of related words for the made-up descriptions: values of one family share words, so
# a working start places them near each other.
_FAMILIES = (
    ("grocery", "food market supermarket"), ("fuel", "service station automated dispenser"),
    ("airline", "air carrier passenger travel"), ("hotel", "lodging motel resort"),
    ("restaurant", "eating place dining"), ("electronics", "computer software store"),
    ("pharmacy", "drug store medicine"), ("clothing", "apparel fashion shoes"),
)
_VARIANTS = ("", "small", "online", "chain", "outlet", "wholesale")


def made_up_descriptions(codes):
    """Invented descriptions {code value as text: text} for the tests and the demo.

    The values are dealt out to eight families in turn; each description names its family,
    two of the family's words and a variant word. Nothing here resembles a real code list.
    """
    out = {}
    for i, code in enumerate(codes):
        name, words = _FAMILIES[i % len(_FAMILIES)]
        words = words.split()
        variant = _VARIANTS[(i // len(_FAMILIES)) % len(_VARIANTS)]
        out[code_text(code)] = " ".join(w for w in (name, words[i % len(words)], words[(i + 1) % len(words)],
                                                      variant) if w)
    return out


def nearest(rows, codes):
    """For every row, the code of its nearest other row by cosine: a list of len(codes) values."""
    rows = np.asarray(rows, dtype=np.float64)
    unit = rows / np.maximum(np.linalg.norm(rows, axis=1, keepdims=True), 1e-12)
    similar = unit @ unit.T
    np.fill_diagonal(similar, -np.inf)
    return [codes[j] for j in similar.argmax(axis=1)]


def save_rows(path, codes, rows):
    """Write codes [n] and rows [n, d] to one .npz file (an existing file is replaced)."""
    with open(path, "wb") as handle:
        np.savez(handle, codes=np.asarray(codes, dtype=str), rows=np.asarray(rows, dtype=np.float64))
    return path


def load_rows(path):
    """Read (codes, rows) written by `save_rows`; `copy_into_table` takes them as they are."""
    with np.load(path) as stored:
        return stored["codes"], stored["rows"]


def main(argv=None):
    """Command line: make starting rows from descriptions, print each value's nearest neighbour."""
    parser = argparse.ArgumentParser(description="Starting rows of a category table from text descriptions.")
    parser.add_argument("--descriptions", default=None, help="csv or parquet file of codes and texts "
                                                            "(default: DESCRIPTIONS_PATH)")
    parser.add_argument("--demo", action="store_true", help="use made-up descriptions of the made-up categories")
    parser.add_argument("--width", type=int, default=None, help="token width (default: settings.EMBED_DIM)")
    parser.add_argument("--std", type=float, default=None, help="spread of a fresh row (default: INIT_STD)")
    parser.add_argument("--show", type=int, default=12, help="how many values to print")
    parser.add_argument("--out", default=None, help="write the codes and rows to this .npz file")
    args = parser.parse_args(argv)

    if args.demo:
        df = synthetic.make_transactions(n_accounts=60, seed=0)
        if settings.MCC_COL is None or settings.MCC_COL not in df.columns:
            print("note: no category column in settings; the demo uses the codes 1000 to 1039")
            codes = list(range(1000, 1040))
        else:
            codes = sorted(pd.unique(df[settings.MCC_COL]).tolist())
        descriptions = made_up_descriptions(codes)
    else:
        descriptions = load_descriptions(args.descriptions)
    if len(descriptions) < 2:
        print("note: fewer than two descriptions; nothing to do")
        return None
    codes = list(descriptions)
    rows, kept = initial_rows(embed_texts([descriptions[c] for c in codes]), args.width, args.std)
    near = nearest(rows, codes)
    report = pd.DataFrame({"code": codes, "description": [descriptions[c] for c in codes],
                           "nearest": near, "nearest_description": [descriptions[c] for c in near]})
    print(f"{len(codes)} descriptions, {kept} principal components, rows of width {rows.shape[1]}, "
          f"spread {rows.std():.3f}")
    print(report.head(args.show).to_string(index=False))
    if args.out:
        save_rows(args.out, codes, rows)
        print(f"written: {args.out}")
    return report


if __name__ == "__main__":
    main()
