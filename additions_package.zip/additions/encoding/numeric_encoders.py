"""Numbers as tokens with the encoder as a switch: fixed bins, learned bins, Fourier features, or all three.

What this file does
-------------------
It turns the numeric fields of a transaction into tokens, with the way of encoding them as a switch,
so that each way can be tried against the encoder of the model in use. The pieces:

    UnitQuantileScaler     every field placed on [0, 1] by its own training quantiles; a value beyond the
                           training range is held at 0 or 1, and a missing value stays missing
    FixedBinBranch         the encoding of the model in use: fixed bin edges and a learned vector per bin
    LearnedBinBranch       learned, ordered centres with a learned vector at each, read between neighbours
    FourierBranch          the value and the sine and cosine of learned frequencies, through a learned matrix
    RawBranch              a learned vector times the value
    ProjectedBranches      branches side by side, then a learned projection per field to the token width
    NumericEncoder         [..., C] numbers in, [..., C, d] tokens out, for any number of leading dimensions;
                           `kind` is "ple", "learned_ple", "periodic" or "hybrid"
    fit_centres            starting centres per field from scaled training rows: the distinct quantiles, and
                           the places that heaps of equal values leave over spread evenly between them
    fit_edges              bin edges for "ple" by the same rule
    interval_use           per field, how many intervals (bins, or gaps between centres) hold rows
    centre_parameters      the weights that place the learned centres, in any model, for an optimiser group
                           of their own
    load_piecewise_weight  the trained W and b of a piecewise-linear encoding put into "ple", from the
                           layout of rtdl_num_embeddings or from bins in order
    count_weights          the number of weights of a module
    weight_table           the number of weights of every kind for a number of fields and token widths
    describe               one line per switch of an encoder with its value, and the number of weights

The four kinds:

    "ple"          W_c PLE(x) + b_c with fixed bin edges: the encoder of the model in use (16 bins today).
                   Given the same edges and weights it gives the same tokens, up to float rounding.
    "learned_ple"  the piecewise branch alone, its centres learned and started at the quantiles, then a
                   projection per field
    "periodic"     A_c [x, sin(w_c,j x), cos(w_c,j x)], j = 1..F, with learned frequencies and the matrix
                   A per field or one matrix for all fields (`lite`); no activation follows it
    "hybrid"       P_c( r_c(x) (+) f_c(x) (+) p_c(x) ): the raw, Fourier and piecewise branches side by
                   side, then a projection per field. This is the numeric encoder of the Large Payments
                   Model (JPMorgan, arXiv 2611.15814, Section 3.1, Eq. 2 and 3); (+) joins vectors.

Every field has its own parameters, except the matrix of "periodic" with `lite`. Every kind adds a
learned identity vector per field to its value part; for "ple" that vector is b_c of the model in
use. Where a value is missing, a missing vector of the field takes the place of the value part and
the identity stays, so the model still knows which field is absent (the paper keeps the field
identity of a masked field in the same way). The missing vector is a fixed zero by default
(missing="zero"), so that a missing number gives its field identity alone, as in the tokenizer of the
model in use, which has no vector for a missing number; missing="learned", the arm, learns a vector
per field instead.

The paper gives neither F nor K, nor how the parts start, how the order of the centres is kept or
what happens outside the outer centres. This file chooses:

    F = 16 frequencies     log-spaced from 0.5 to 64 turns over [0, 1], the same for every field at the
                           start (a switch draws them at random instead, 2 pi times a normal number of
                           turns with a chosen spread). Neighbouring frequencies are 1.38 times apart,
                           so every scale from the whole range down to under two percent of the rows has
                           a frequency within about a fifth of it. 16 is also the count of the periodic
                           embedding the owner's trainers already carry.
    K = 17 centres         one more than the bins of the model in use, so that "learned_ple" starts with
                           16 intervals where "ple" has its 16 bins. It then differs from "ple" in two
                           ways, not one: its centres move, and its parametrization is another (the
                           vectors at the centres start at unit spread and reach the token through a
                           branch and a projection per field that starts at 0.02, where "ple" maps the
                           shares straight to the token with W at 0.02). learn_centres=False keeps the
                           centres where they start. That arm differs from "ple" only in the
                           parametrization and from "learned_ple" only in the moving centres, so run
                           beside both it tells the two effects apart. In a synthetic check (one field,
                           1,500 Adam steps, three seeds, branches of 16) the parametrization carried the
                           gain under an MLP head: a staircase of 32 steps at 32 bins gave a mean error of
                           0.0749 for "ple", 0.0388 for "learned_ple" and 0.0315 with the centres frozen.
                           Under a linear head the frozen arm equalled "ple" (0.274 against 0.277) and the
                           moving centres carried the gain (0.088).
    the centres at start   on the [0, 1] scale of UnitQuantileScaler the q-quantile of a continuous field
                           without ties sits at q, so the default centres are 17 evenly spaced numbers from
                           0 to 1. A field with heaps (many rows of one value, a limit of zero, say) or
                           with few values is not like that: a heap sits at one point, the middle of the
                           shares it covers, and evenly spaced centres leave intervals that hold no row,
                           whose centres then get no gradient. fit_centres starts every field at its
                           distinct quantiles and spreads the other centres evenly between them;
                           interval_use counts the intervals that hold rows. Centres at the quantiles of
                           values on another scale come from fit_centres on those values too.
    the branch width       BRANCH_DIM = 16 numbers per branch, or as many as there are intervals when there
                           are more, so that 33 centres keep the 32 directions that 32 fixed bins have; a
                           branch of 16 would hold the piecewise part to 16 (in the check that cap cost
                           nothing measurable: 0.0656 against 0.0662, one seed, a linear head). Inside
                           "hybrid" all three branches take this width, so its weights grow with it.
    the order              each centre is the one before it plus a gap, and each gap is a floor plus the
                           softplus of a free weight. A gap is therefore always above the floor (a
                           thousandth of the mean starting gap), whatever a training step does, so no
                           step can swap or merge two centres. The interpolation divides by that gap
                           itself, never by the difference of two rounded centres.
    the learning rate      the order holds at any rate, but nothing keeps the centres on the data. They
                           live on the scale of [0, 1], where one interval is a sixteenth wide, and share
                           the global learning rate, so at a rate that suits the other weights a few steps
                           can carry a centre past several intervals or off [0, 1], and an interval
                           pushed off the data stays empty. In a synthetic check (five heavy-tailed
                           fields, Adam at a rate of 0.1, three seeds), 42 to 68 percent of the centres of
                           "learned_ple" ended outside [0, 1], its errors were 0.079 to 0.105 against
                           0.021 to 0.024 for "ple", and one run of "hybrid" fell to predicting the mean.
                           With the centres at a tenth of the rate, every centre stayed between -0.09 and
                           1.19 and the errors were 0.016 to 0.020 ("learned_ple") and 0.017 to 0.044
                           ("hybrid"). centre_parameters gives the centres a group of their own, and
                           CENTRE_LR_FACTOR (0.1) is the share of the global rate recommended for it.
    outside the centres    a value below the first centre reads the first vector, a value above the last
                           centre the last vector. The kinds that read the unit scale (below) hold every
                           value to [0, 1] before any branch sees it, and UnitQuantileScaler has already
                           held every value beyond the training range at 0 or 1, so in "hybrid" no branch
                           sees how far out a value lies: an amount far above every training amount reads
                           as the largest one.
    the start              the vectors at the centres, the raw vectors and the Fourier matrix inside
                           "hybrid" start at a spread that makes each branch's numbers about one in size;
                           every weight that makes a token starts at a spread of 0.02, as the token
                           weights of numeric_frontend.py do, so a fresh encoder gives tokens of about
                           the size of today's. The identity starts small and random, the missing vector
                           at zero.
    16-bit numbers         the values, the Fourier angles, the gaps, the centres and the bin shares are
                           formed in 32-bit numbers at least, whatever the number type of the module, and
                           only the results go to that type: bfloat16 rounds x to steps of 1/256 near 1,
                           and one such step turns an angle at 64 turns by 1.6 radians. A cast of the
                           module to 16 bits (.half(), .to(torch.bfloat16)) also leaves the tensors that
                           place a value in float32: the fixed edges, the weights that place the centres
                           and the frequencies; the matrices and vectors take the 16-bit type. Rounded to
                           bfloat16, those tensors moved a frequency by up to 0.99 radians per unit of x,
                           a centre by up to 0.0075 and a fitted edge by up to 0.0019. Measured on float32
                           encoders of 3 fields at width 16 cast to bfloat16, the largest token error as a
                           share of the largest token is now 0.0050 ("periodic"), 0.0068 ("hybrid"),
                           0.0088 ("learned_ple") and 0.0053 ("ple" with fitted edges), where it was 0.21,
                           0.16, 0.10 and 0.13 with those tensors rounded too; in float16 it is 0.0006 to
                           0.0010, where it was 0.021, 0.015, 0.0010 and 0.025. What is left is the
                           rounding of the matrices and vectors themselves.

What the frequencies resolve, for inputs on [0, 1], where a stretch of the scale is a share of the
training rows: a frequency of f turns has a period of 1 / f, and it tells apart values about half a
period apart.

    0.5 to 0.7     less than a period over the range: the cosine of 0.5 turn falls from one end to the
                   other, so it says where a value lies in the whole range, smoothly
    1 to 2 turns   broad shapes with periods of the whole down to half of the rows (small against large
                   amounts)
    2.5 to 9       periods of 40 down to 11 percent of the rows: patterns two to six bins of the model
                   in use wide
    13 to 64       fine detail, periods of 8 down to 1.6 percent of the rows: one bin of the model in
                   use (6.25 percent) and below

A step at one value (a sharp threshold) needs many frequencies to draw; the piecewise branch draws it
with one centre, which is why "hybrid" has both. A pattern that repeats in the raw value (the cents of
an amount, round amounts) does not repeat on the quantile scale; `amount_flags` of
numeric_frontend.py keeps it as code fields.

Why it exists
-------------
The model in use turns every number into a token with fixed bins: it can bend at every edge, but only
at edges set before training, and every bin has the same say. A threshold that falls inside a bin is
drawn as a ramp across the bin. Learned centres move to where the label changes. Fourier features add
smooth shape at many scales at once, and the raw branch keeps the plain order of the values. The
Large Payments Model joins all three in its field encoder; the paper reports the gains of the whole
model, not of the encoder alone, so whether the encoder helps on card fraud, and which branch carries
it, is what the switch is for. Each kind can be run against "ple" with every other part of the model
unchanged; "learned_ple" is run beside its frozen arm, so that a gain is not put down to moving
centres when the parametrization made it.

Where it goes
-------------
Preprocessing and the tokenizer. UnitQuantileScaler is fitted once on rows of training files and
stored with the model; it takes the place of the step that standardises the numeric columns in the
per-file encoding (`SequenceBuilder._encode_file` in the original code). Its saved state goes back
through `scaler_from_state` of numeric_frontend.py as well. NumericEncoder takes the place of the
numeric half of the field tokenizer (in the original `FeatureTokenizer.forward`, the line that turns
the numeric columns into tokens). The code-field half stays as it is, and the tokens of both halves
go on to stage 1 side by side, as today.

    "ple" as today         the model's own edges and scale: NumericEncoder(C, 48, kind="ple", edges=E)
                           with C its numeric fields and E [C, B + 1], a field with fewer bins padded at
                           its end by repeating its last edge (as numeric_frontend.py pads). To score as
                           the trained model, load_piecewise_weight(encoder, W, bin_counts, b=b) puts W
                           into `encoder.value.weight` [C, B, d] and b into `encoder.identity` [C, d],
                           and sets unit_scale to False, saved with the weights, so that the encoder
                           reads its numbers as the trained model did, even when the model's own edges
                           all lie on [0, 1].
                           Two conditions decide whether the tokens agree. A field with n < B bins keeps
                           its last bin at index n - 1 here, while rtdl_num_embeddings keeps it at index
                           B - 1; layout="rtdl" moves it, layout="in_order" copies W as it is. And rtdl
                           lets its first bin run on below the lowest edge and its last bin above the
                           highest edge, so the encoder is built with open_ends=True for it
                           (PLE_OPEN_ENDS); load_piecewise_weight warns when it is not.
    every other kind       inputs on the [0, 1] scale of UnitQuantileScaler. "ple" with no edges given
                           uses 16 even bins on that scale, which are equal-share bins for a continuous
                           field without ties: the control arm on the new scale. fit_edges gives a field
                           with heaps bins that start at its distinct quantiles.

Which kinds read the unit scale: "periodic" and "hybrid" always, and "ple" and "learned_ple" when their
edges or centres lie on [0, 1] (the defaults do, and so do the results of fit_edges and fit_centres on
scaled rows); `unit_scale` forces either way, and load_piecewise_weight turns it off. Those kinds hold
every value to [0, 1]. In training mode they count the values of every field over the first training
batches, and a field with more than half of its values so far outside [0, 1] gives a warning that names
UnitQuantileScaler: numbers that skipped the scaler would otherwise all read as 0 or 1 without a sound. A
field stops being looked at once LOOK_VALUES of its values have not shown it unscaled, and every field after
LOOK_BATCHES training batches. unscaled="raise" makes that warning a ValueError with the same text, which
stops the batch. The look sees numbers that lie mostly outside [0, 1]; numbers that skipped the quantile
scaler but lie on [0, 1] (min-max scaled, say) pass it, and crowd into the first bins: interval_use on
scaled training rows says how many bins of each field hold rows. "ple" given the model's own edges on
another scale keeps today's arithmetic; with open ends a value far beyond the outer edges then grows
its token without bound, as it does in the model in use.

A missing mask comes from the model's own is-missing code fields, or from values that are not finite
numbers: NaN, and plus or minus infinity, count as missing whether a mask is given or not.

What to change for the pod
--------------------------
The three PLACEHOLDER values below: N_BINS, the bins of the model in use, PLE_OPEN_ENDS, the form of
its outer bins, and CENTRE_LR_FACTOR, the learning rate of the centres as a share of the global rate.
The scaler must be fitted on training rows only, and the scaler, the edges and the encoder are stored
together. A model trained with one kind cannot read the tokens of another; the weights are trained
again.

The number of weights of each kind at 64 fields, with the defaults above (`weight_table` gives them,
the demo prints them). With the default missing="zero", "ple" has the weights of the model in use
and no more, W and b, 64 x 17 x d = 52,224 at width 48; missing="learned" adds a vector of d per
field to every kind, 3,072 at width 48:

    kind                width 48   width 96   width 144
    ple                   52,224    104,448     156,672
    learned_ple           70,720    122,944     175,168
    periodic             105,472    209,920     314,368
    periodic, lite         5,680     10,336      14,992
    hybrid               204,864    355,392     505,920

Memory grows with rows times fields. The numbers each kind keeps for the backward pass, per row and
field, with the defaults above at width 48 (the growth of the tensors saved for the backward pass
from 2,048 to 4,096 rows of 64 fields, so the weights themselves do not count; the test file
(package only) measures them again):

    kind                numbers per row and field
    ple                          17
    learned_ple                  66
    periodic                     51
    periodic, lite               51
    hybrid                      148

"ple" keeps its 16 shares, as the encoder of the model in use does; "learned_ple" its 17 mixing
weights, two steps of 16 on the way to them and the 16 numbers of its branch; "periodic" the value,
its 16 angles and its 33 features; "hybrid" all of these for its three branches and their joined 48.
Every kind also keeps the missing mask, one number per row and field. The tokens themselves,
[..., C, d], are the same for every kind. When a GPU runs out of memory, the batch size goes down.

How to try it
-------------
    scaler = UnitQuantileScaler().fit(train_values)              # [N, C] training rows only
    x = torch.as_tensor(scaler.transform(values))                # float32 [N, C] on [0, 1]; missing stays NaN
    encoder = NumericEncoder(64, 96, kind="hybrid")              # or "ple", "learned_ple", "periodic"
    tokens = encoder(x, missing=is_missing)                      # [N, 64, 96]; the mask may be left out
    scaled = scaler.transform(train_values)                      # the training rows on [0, 1]
    encoder = NumericEncoder(64, 96, kind="learned_ple", centres=fit_centres(scaled, N_CENTRES))
    print(interval_use(encoder, scaled)["held"])                 # per field, the intervals that hold rows
    frozen = NumericEncoder(64, 96, kind="learned_ple", learn_centres=False)   # the arm beside "learned_ple"
    centres = centre_parameters(model)                           # their own group at a tenth of the rate:
    ids = {id(weight) for weight in centres}
    others = [weight for weight in model.parameters() if id(weight) not in ids]
    optimiser = torch.optim.Adam([{"params": others}, {"params": centres, "lr": lr * CENTRE_LR_FACTOR}], lr=lr)
    load_piecewise_weight(encoder, W, bin_counts, layout="rtdl", b=b)    # "ple" with the model's trained weights
    print(describe(encoder))                                     # every switch and the number of weights
    python numeric_encoders.py                                   # the weight table at 64 fields, in the kit
    python -m additions.encoding.numeric_encoders                # the same inside the package (package only)
    python -m pytest -q additions/tests/test_encoding_numeric_encoders.py   # package only
"""
import math
import warnings

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

try:                                    # inside the package
    from .numeric_frontend import PiecewiseLinearEmbedding, QuantileScaler
except ImportError:
    try:                                # the package on the path, this file run on its own
        from additions.encoding.numeric_frontend import PiecewiseLinearEmbedding, QuantileScaler
    except ImportError:                 # the files side by side in one folder
        from numeric_frontend import PiecewiseLinearEmbedding, QuantileScaler

# PLACEHOLDER: the number of bins of the piecewise-linear encoding of the model in use (16 today).
N_BINS = 16

# PLACEHOLDER: True when the encoding of the model in use lets its first bin run on below the lowest edge and its
# last bin above the highest edge (the form of Gorishniy et al., 2022, and of rtdl_num_embeddings); False when it holds
# such values at the ends, as numeric_frontend.py does.
PLE_OPEN_ENDS = False

# PLACEHOLDER: the learning rate of the learned centres as a share of the global rate of the training script that
# trains the model in use; a tenth kept every centre on the data in a check at a global rate of 0.1.
CENTRE_LR_FACTOR = 0.1

# The number K of learned centres: one more than the bins of the model in use, so that the learned bins start with
# as many intervals as the fixed ones have bins.
N_CENTRES = N_BINS + 1

# The number F of frequencies of the Fourier branch.
N_FREQUENCIES = 16

# The log-spaced start of the frequencies, in turns over [0, 1] (one turn is one full period, 2 pi radians).
LOWEST_TURNS = 0.5
HIGHEST_TURNS = 64.0

# The spread, in turns over [0, 1], of the random start of the frequencies (frequency_init="normal").
FREQUENCY_SCALE = 4.0

# The smallest width of each branch inside "learned_ple" and "hybrid", before the projection to the token width; the
# default width is this or the number of intervals, whichever is larger.
BRANCH_DIM = 16

# The smallest gap between two neighbouring centres, as a share of their mean gap at the start.
MIN_GAP_SHARE = 1e-3

# The spread at which every weight that makes a token starts, the value numeric_frontend.py uses.
TOKEN_STD = 0.02

# The share of a field's values outside [0, 1], over the training batches it has been looked at in, above which a kind
# that reads the unit scale names the field (one warning for the fields named in a batch, or a plain error): the
# scaler never gives such values, so more than half of them means the scaler was skipped.
OUTSIDE_SHARE = 0.5

# The values of a field after which the look at the scale stops looking at it, when they have not shown it unscaled,
# and the training batches after which it stops looking at every field: a field is judged on many values, not on
# the few that a sparse field holds in its first batch, and the look costs nothing once training is under way.
LOOK_VALUES = 256
LOOK_BATCHES = 64

# The values the switches `kind`, `missing` and `unscaled` accept, the two starts of the frequencies, and the two
# layouts of a trained piecewise weight that load_piecewise_weight reads.
KINDS = ("ple", "learned_ple", "periodic", "hybrid")
MISSING_KINDS = ("learned", "zero")
UNSCALED_KINDS = ("warn", "raise")
FREQUENCY_INITS = ("log", "normal")
PIECEWISE_LAYOUTS = ("rtdl", "in_order")


def _working_type(dtype):
    """The number type the inner steps work in: the type given, but never fewer than 32 bits."""
    return torch.promote_types(dtype, torch.float32)


def _on_unit_scale(values):
    """True when every number of `values` lies on [0, 1]: edges or centres on the scale of UnitQuantileScaler."""
    values = np.asarray(values, dtype=np.float64)
    return bool(np.all((values >= 0.0) & (values <= 1.0)))


# ----------------------------------------------------------------------------------------------
# the scale (numpy, fitted on training rows)
# ----------------------------------------------------------------------------------------------

class UnitQuantileScaler(QuantileScaler):
    """Every field on [0, 1] by its own training quantiles: the share of training rows below a value.

    fit(values)         values [N, C]: training rows only; missing values are left out (QuantileScaler.fit)
    transform(values)   [N, C] in, float32 [N, C] out on [0, 1]; a missing value stays missing
    state()             plain arrays {"kind", "probs" [Q], "quantiles" [C, Q]}; `from_state` reads them back,
                        and so does `scaler_from_state` of numeric_frontend.py

    The fit is the one of QuantileScaler in numeric_frontend.py: Q stored quantiles per field. Only the
    last step differs. QuantileScaler reads the share on the normal curve; here the share itself is
    the value, which is the scale the Large Payments Model encodes. A value below every training value
    reads 0 and a value above every training value reads 1, so nothing a new row holds can leave
    [0, 1]. A value that many training rows share (a limit of zero, say) covers a stretch of shares and
    is put at the middle of that stretch, as QuantileScaler does. The q-quantile of a field therefore
    sits at q only for a continuous field without ties; the quantiles of the scaled rows of a field with
    a heap repeat the point of the heap, which fit_centres and fit_edges allow for.
    """

    def transform(self, values):
        """Place values [N, C] on [0, 1], float32 [N, C]; a missing value stays missing."""
        values = np.asarray(values, dtype=np.float64)
        # A single column [N] is read as one field, [N, 1], as the scalers of numeric_frontend.py read it.
        values = values[:, None] if values.ndim == 1 else values
        out = np.full(values.shape, np.nan, dtype=np.float32)
        for c in range(values.shape[1]):                 # one pass per field, never per row
            col = values[:, c]
            ok = ~np.isnan(col)
            xs = self.quantiles[c]
            # Read from the left, the table gives the top of the stretch of shares that a repeated value covers;
            # read from the right, its bottom. Their mean is the middle of the stretch. np.interp holds every value
            # beyond the table at the share of its end, 0 or 1, which is the clamping.
            up = np.interp(col[ok], xs, self.probs)
            down = -np.interp(-col[ok], -xs[::-1], -self.probs[::-1])
            out[ok, c] = 0.5 * (up + down)
        return out

    def state(self):
        """The fitted numbers as plain arrays, to be saved beside a checkpoint."""
        # A kind of its own, so that `scaler_from_state` of numeric_frontend.py rebuilds this scaler and not the one of
        # the normal curve.
        return {"kind": "unit_quantile", "probs": self.probs, "quantiles": self.quantiles}

    @classmethod
    def from_state(cls, state):
        """Rebuild a fitted scaler from the plain arrays that its `state()` returned."""
        scaler = cls(len(state["probs"]))
        scaler.probs = np.asarray(state["probs"], dtype=np.float64)
        scaler.quantiles = np.asarray(state["quantiles"], dtype=np.float64)
        return scaler


# ----------------------------------------------------------------------------------------------
# the branches (torch); each maps x [..., C] to [..., C, width] and holds no constant per field
# ----------------------------------------------------------------------------------------------

class _Keep32Bits:
    """A mixin for the branches whose own tensors place a value on the scale: those stay in 32 bits under a 16-bit cast.

    KEEP_32_BITS   the names of the parameters and buffers that stay in float32 when a cast of the module
                   (module.half(), module.to(torch.bfloat16), the cast of a whole model) would leave them in
                   float16 or bfloat16: the edges, the weights that place the centres, the frequencies

    A device move, float32 and float64 keep the usual behaviour, and every other tensor of the module,
    its matrices and vectors, takes the 16-bit type as usual.
    """

    KEEP_32_BITS = ()

    def _apply(self, fn, recurse=True):
        """Apply `fn` to every tensor as torch does, then put the named tensors back in float32 where it left 16 bits.

        fn        what torch applies to every parameter, buffer and gradient: a cast, a device move
        recurse   True applies it to the child modules as well, as in torch

        Returns the module. A named tensor that the cast left in float16 or bfloat16 gets its values from
        before the cast back, as float32 on its new device; its gradient, if it has one, does the same.
        """
        # The values before the cast. A detached view keeps the old numbers even when torch then gives the tensor it
        # came from new data, or swaps that data out.
        saved = {}
        for name in self.KEEP_32_BITS:
            tensor = getattr(self, name)
            saved[name] = (tensor.detach(), None if tensor.grad is None else tensor.grad.detach())
        # `recurse` goes on only when it is False (to_empty(recurse=False)), so that a torch whose _apply takes `fn`
        # alone, such as torch 2.0, runs this as well.
        module = super()._apply(fn) if recurse else super()._apply(fn, recurse)
        for name, (values, grad) in saved.items():
            tensor = getattr(self, name)
            if tensor.dtype not in (torch.float16, torch.bfloat16):
                continue                                   # a device move, float32 or float64: as torch left it
            kept = values.to(device=tensor.device, dtype=torch.float32)
            if isinstance(tensor, nn.Parameter):
                # The same weight object takes the 32-bit numbers, so an optimiser built on it later finds it.
                tensor.data = kept
                if grad is not None:
                    tensor.grad = grad.to(device=tensor.device, dtype=torch.float32)
            else:
                self._buffers[name] = kept
        return module


class FixedBinBranch(_Keep32Bits, PiecewiseLinearEmbedding):
    """The encoding of the model in use without its constant: the bin shares of x times W_c.

    edges       [C, B + 1] bin edges per field (the model's own, `fit_edges` on scaled rows, or
                `quantile_edges` / `tree_edges` of numeric_frontend.py)
    out_dim     width d of a token
    open_ends   True lets the first bin of a field run on below its lowest edge and its last bin above
                its highest edge; None reads PLE_OPEN_ENDS

    forward(x): x [..., C]; returns [..., C, d], the sum over bins of share_b(x) times weight[c, b].

    The edges, the shares and the weights [C, B, d] are those of PiecewiseLinearEmbedding of
    numeric_frontend.py. Its constant per field is left out here: b_c of the formula is the field
    identity of NumericEncoder, which every kind has. The shares are formed in 32-bit numbers at
    least, and only they go to the number type of the weights. The edges, `left` and `width`, stay in
    float32 when the module is cast to 16 bits; the weights take the 16-bit type.
    """

    # The fixed edges: rounded to bfloat16, an edge near 1 moves by up to 0.002, a share of a narrow bin.
    KEEP_32_BITS = ("left", "width")

    def __init__(self, edges, out_dim, open_ends=None):
        super().__init__(edges, embed_dim=int(out_dim))
        # b_c is the identity of NumericEncoder; a second constant here would be a weight doing the same work twice.
        self.bias = None
        self.out_dim = int(out_dim)
        self.open_ends = PLE_OPEN_ENDS if open_ends is None else bool(open_ends)
        # The first and the last bin of every field that has a width; only those two run on past the edges when
        # `open_ends` is on. A field whose edges all coincide has neither.
        real = self.width > 0
        n_bins = real.shape[1]
        place = torch.arange(n_bins).expand_as(real)
        first = torch.where(real, place, torch.full_like(place, n_bins)).amin(dim=1, keepdim=True)
        last = torch.where(real, place, torch.full_like(place, -1)).amax(dim=1, keepdim=True)
        self.register_buffer("is_first", place == first)
        self.register_buffer("is_last", place == last)

    def shares(self, x):
        """x [..., C] to shares [..., C, B]: how far x has come through every bin."""
        # In 32 bits at least: a value rounded to 16 bits would land in the wrong place of a narrow bin.
        x = x.to(_working_type(self.left.dtype))
        share = self.encode(x)                           # held between 0 and 1, zero on bins of no width
        if not self.open_ends:
            return share
        real = self.width > 0
        # The plain position inside every bin; a bin of no width is divided by one and is never first or last.
        through = (x.unsqueeze(-1) - self.left) / torch.where(real, self.width, torch.ones_like(self.width))
        # The first bin keeps its hold at 1 but not at 0, so it runs on below the lowest edge; the last bin keeps
        # its hold at 0 but not at 1, so it runs on above the highest edge. A field with one bin lets it run both ways.
        share = torch.where(self.is_first, through.clamp(max=1.0), share)
        share = torch.where(self.is_last, through.clamp(min=0.0), share)
        return torch.where(self.is_first & self.is_last, through, share)

    def forward(self, x):
        """x [..., C] to the value part of the tokens, [..., C, d]."""
        # The shares go to the type of the weights only at the product, which needs both in one type.
        return torch.einsum("...cb,cbd->...cd", self.shares(x).to(self.weight.dtype), self.weight)


class LearnedBinBranch(_Keep32Bits, nn.Module):
    """Learned, ordered centres per field with a learned vector at each, read between neighbours.

    n_fields        C
    out_dim         width of the vector at every centre
    centres         None, or [C, K] starting centres per field, increasing. None puts K centres evenly on
                    [0, 1], which are the quantiles on the scale of UnitQuantileScaler of a continuous
                    field without ties; `fit_centres` gives centres for fields with heaps, and for values
                    on another scale.
    n_centres       K when `centres` is None; None reads N_CENTRES
    learn_centres   True: the centres learn; False: they stay where they start (requires_grad False on
                    `first` and `raw_gaps`), the arm that tells moving centres from the parametrization

    forward(x): x [..., C] finite values; returns [..., C, out_dim].
    centres():  the current centres [C, K], strictly increasing in every field. They are formed in
                32-bit numbers at least, and the tensors that place them (`first`, `raw_gaps` and the
                `floor`) stay in float32 when the module is cast to 16 bits, so the cast neither moves
                the centres nor merges two of them; the vectors take the 16-bit type.
    centre_parameters(): [first, raw_gaps], the two weights that place the centres.

    Between the centres a_k and a_k+1 the branch returns (1 - t) v_k + t v_k+1 with
    t = (x - a_k) / (a_k+1 - a_k), Eq. 3 of the paper. Below the first centre it returns v_1 and above
    the last centre v_K.
    """

    # The tensors that place the centres: rounded to bfloat16, the gaps move and the centres with them, by up to 0.0075
    # of the scale at 17 centres, an eighth of an interval.
    KEEP_32_BITS = ("first", "raw_gaps", "floor")

    def __init__(self, n_fields, out_dim, centres=None, n_centres=None, learn_centres=True):
        super().__init__()
        n_fields, self.out_dim = int(n_fields), int(out_dim)
        if centres is None:
            k = N_CENTRES if n_centres is None else int(n_centres)
            centres = np.tile(np.linspace(0.0, 1.0, k), (n_fields, 1))
        centres = np.asarray(centres, dtype=np.float64)
        if centres.ndim != 2 or centres.shape[0] != n_fields or centres.shape[1] < 2:
            raise ValueError(f"centres must be [C, K] = [{n_fields}, K] with K of at least 2, one row of starting "
                             f"centres per field; got shape {centres.shape}")
        k = centres.shape[1]
        span = centres[:, -1] - centres[:, 0]
        # A field whose starting centres all coincide gets a span of one, so that its floor is still a positive gap.
        span = np.where(span > 0, span, 1.0)
        floor = MIN_GAP_SHARE * span / (k - 1)
        gaps = np.diff(centres, axis=1)
        # Every starting gap must lie above the floor, or the free weight below could not express it. Ties (a heap
        # of equal training values) and gaps that are too small start at twice the floor instead.
        short = gaps < 2.0 * floor[:, None]
        if short.any():
            print(f"note: the starting centres of field(s) {sorted(set(np.nonzero(short)[0].tolist()))} are not "
                  f"strictly increasing; gaps below twice the smallest gap start at twice the smallest gap")
            gaps = np.where(short, 2.0 * floor[:, None], gaps)
        # A buffer, not a weight: the floor is fixed by the start and travels with the model.
        self.register_buffer("floor", torch.tensor(floor, dtype=torch.float32))
        learn = bool(learn_centres)
        # With learn_centres=False the two weights stay parameters, so the arm holds the same weights and the same
        # arithmetic as "learned_ple", but they get no gradient and an optimiser leaves them where they start.
        self.first = nn.Parameter(torch.tensor(centres[:, 0], dtype=torch.float32), requires_grad=learn)
        # softplus(raw) = gap - floor. The inverse is written as y + log(1 - exp(-y)), which stays finite for small
        # and for large gaps, where log(exp(y) - 1) would overflow.
        excess = gaps - floor[:, None]
        self.raw_gaps = nn.Parameter(torch.tensor(excess + np.log(-np.expm1(-excess)), dtype=torch.float32),
                                     requires_grad=learn)
        # Unit spread: the branch's numbers are then about one in size, and the projection after it sets the scale.
        self.vectors = nn.Parameter(torch.randn(n_fields, k, self.out_dim))

    def gaps(self):
        """The gaps between neighbouring centres [C, K - 1]: the floor plus a softplus, so always above the floor."""
        # In 32 bits at least: a gap at the floor (6e-5 of a unit) is below the step of 16-bit numbers near 1.
        work = _working_type(self.raw_gaps.dtype)
        return self.floor.to(work).unsqueeze(-1) + F.softplus(self.raw_gaps.to(work))

    def _centres_from(self, gaps):
        """The centres [C, K] from given gaps: the first centre, then each next one a gap further."""
        start = self.first.to(gaps.dtype).unsqueeze(-1)
        # The running sum in the type of the gaps, 32 bits at least, so that centres a floor apart stay apart.
        return torch.cat([start, start + torch.cumsum(gaps, dim=-1)], dim=-1)

    def centres(self):
        """The centres [C, K]: the first centre, then each next one a positive gap further."""
        return self._centres_from(self.gaps())

    def centre_parameters(self):
        """The two weights that place the centres, [first, raw_gaps], for an optimiser group of their own."""
        return [self.first, self.raw_gaps]

    def forward(self, x):
        """x [..., C] to [..., C, out_dim], the vectors at the centres mixed by where x lies between them."""
        gaps = self.gaps()                                                  # [C, K - 1]
        lower = self._centres_from(gaps)[:, :-1]                            # a_1 .. a_K-1, the left end of each gap
        # How far x has come through every interval, held between 0 and 1. The division is by the gap itself, so it
        # can never be a division by zero, even where two centres round to the same number.
        through = ((x.to(gaps.dtype).unsqueeze(-1) - lower) / gaps).clamp(0.0, 1.0)     # [..., C, K - 1]
        # The weight of every centre: 1 - t at the left end of the interval that holds x, t at its right end, 0
        # elsewhere. Beyond the last centre every interval reads 1 and the whole weight sits on v_K; below the
        # first centre every interval reads 0 and it sits on v_1. That is the hold at the end vectors.
        weight = torch.cat([1.0 - through[..., :1], through[..., :-1] - through[..., 1:], through[..., -1:]], dim=-1)
        # Only the mixing weights go to the type of the vectors, for the product that needs both in one type.
        return torch.einsum("...ck,ckh->...ch", weight.to(self.vectors.dtype), self.vectors)


class FourierBranch(_Keep32Bits, nn.Module):
    """The value and the sine and cosine of F learned frequencies, through a learned matrix: A_c [x, sin, cos].

    n_fields          C
    out_dim           width of the result
    n_frequencies     F; None reads N_FREQUENCIES
    frequency_init    "log": the same F log-spaced frequencies for every field, LOWEST_TURNS to HIGHEST_TURNS
                      turns over [0, 1]; "normal": 2 pi times a normal number of turns with spread
                      `frequency_scale`, drawn per field
    frequency_scale   the spread of "normal", in turns; None reads FREQUENCY_SCALE
    shared            True: one matrix for every field ("lite"); False: a matrix per field
    matrix_std        the spread at which the matrix starts

    forward(x): x [..., C] finite values; returns [..., C, out_dim]. The frequencies are in radians per
    unit of x and are learned like every other weight; nothing follows the matrix (no activation).

    A module cast to 16 bits keeps the frequencies in float32 and forms the angles in 32-bit numbers at
    least; only the features go to the type of the matrix. The upper frequencies therefore keep their
    phase: cast to bfloat16, the sines of every frequency up to 64 turns stay within 0.002 of those of
    the float32 module, the rounding of the features alone, where rounding the frequencies as well put
    them up to 0.95 apart (float16: under 0.001, where it was up to 0.12).
    """

    # The frequencies: rounded to bfloat16, the one at 64 turns (402 radians) moves by up to one radian per unit of x,
    # which turns its angle near x = 1 by as much and loses its phase.
    KEEP_32_BITS = ("frequencies",)

    def __init__(self, n_fields, out_dim, n_frequencies=None, frequency_init="log", frequency_scale=None,
                 shared=False, matrix_std=TOKEN_STD):
        super().__init__()
        n_fields, self.out_dim = int(n_fields), int(out_dim)
        n = N_FREQUENCIES if n_frequencies is None else int(n_frequencies)
        if frequency_init not in FREQUENCY_INITS:
            raise ValueError(f"frequency_init must be one of {FREQUENCY_INITS}; got {frequency_init!r}")
        if frequency_init == "log":
            # The same ladder for every field: no field starts blind to a scale another field can see.
            turns = torch.tensor(np.geomspace(LOWEST_TURNS, HIGHEST_TURNS, n), dtype=torch.float32)
            start = (2.0 * math.pi * turns).expand(n_fields, n).clone()
        else:
            scale = FREQUENCY_SCALE if frequency_scale is None else float(frequency_scale)
            start = 2.0 * math.pi * scale * torch.randn(n_fields, n)
        self.frequencies = nn.Parameter(start)
        # The matrix reads 1 + 2F numbers per field: the value, then F sines, then F cosines.
        shape = (2 * n + 1, self.out_dim) if shared else (n_fields, 2 * n + 1, self.out_dim)
        self.weight = nn.Parameter(torch.randn(shape) * matrix_std)
        self.shared = bool(shared)

    def features(self, x):
        """x [..., C] to [..., C, 1 + 2F]: the value, the sines and the cosines, in the number type of the matrix."""
        # The angle in 32 bits at least: at 64 turns a step of 1/256 in x, the step of bfloat16 near 1, turns the angle
        # by 1.6 radians, which would leave the upper frequencies as noise.
        work = _working_type(self.frequencies.dtype)
        x = x.to(work)
        angle = x.unsqueeze(-1) * self.frequencies.to(work)                # [..., C, F]
        features = torch.cat([x.unsqueeze(-1), torch.sin(angle), torch.cos(angle)], dim=-1)
        return features.to(self.weight.dtype)

    def forward(self, x):
        """x [..., C] to [..., C, out_dim]: the features through the matrix of the field (or the shared one)."""
        if self.shared:
            return torch.einsum("...ci,io->...co", self.features(x), self.weight)
        return torch.einsum("...ci,cio->...co", self.features(x), self.weight)


class RawBranch(nn.Module):
    """A learned vector per field times the value: r_c(x) = x u_c, which keeps the plain order of the values."""

    def __init__(self, n_fields, out_dim):
        super().__init__()
        self.out_dim = int(out_dim)
        # Unit spread, like the other branches inside "hybrid"; the projection after them sets the scale.
        self.weight = nn.Parameter(torch.randn(int(n_fields), self.out_dim))

    def forward(self, x):
        """x [..., C] to [..., C, out_dim], in the number type of the weight."""
        # The product of a 32-bit value and a 16-bit weight is a 32-bit number; it goes back to the type of the weight.
        return (x.unsqueeze(-1) * self.weight).to(self.weight.dtype)


class ProjectedBranches(nn.Module):
    """Branches side by side, then a learned projection per field to the token width.

    n_fields   C
    out_dim    width d of a token
    branches   modules that map x [..., C] to [..., C, w_i], each with an `out_dim` of w_i

    forward(x): x [..., C]; returns [..., C, d] = P_c( b_1(x) (+) b_2(x) (+) ... ). The projection has no
    constant: the field identity of NumericEncoder is the constant of every field.
    """

    def __init__(self, n_fields, out_dim, branches):
        super().__init__()
        self.branches = nn.ModuleList(branches)
        width = sum(branch.out_dim for branch in self.branches)
        self.projection = nn.Parameter(torch.randn(int(n_fields), width, int(out_dim)) * TOKEN_STD)

    def forward(self, x):
        """x [..., C] to [..., C, d]."""
        # torch.cat brings the parts to one number type, which matters when mixed precision makes some of them in 16
        # bits and others in 32; the joined parts then take the type of the projection, which the product needs.
        joined = torch.cat([branch(x) for branch in self.branches], dim=-1).to(self.projection.dtype)
        return torch.einsum("...ci,cio->...co", joined, self.projection)


# ----------------------------------------------------------------------------------------------
# the encoder
# ----------------------------------------------------------------------------------------------

def _keep_missing_zero(state_dict, prefix, local_metadata, strict, missing_keys, unexpected_keys, error_msgs):
    """Stop a load that would put a trained missing vector into the fixed zero of missing="zero".

    The arguments are those torch gives a load_state_dict pre-hook registered without its module; only
    `state_dict` and `prefix` are read. Returns nothing. Raises ValueError when the entry
    prefix + "missing" holds a number that is not zero (NaN included); an all-zero entry, or none,
    loads as before, and so does an entry on the meta device, which holds no numbers to look at.
    """
    entry = state_dict.get(prefix + "missing")
    if torch.is_tensor(entry) and not entry.is_meta and bool((entry != 0).any()):
        raise ValueError(f"NumericEncoder with missing='zero': the checkpoint holds a trained missing vector at "
                         f"'{prefix}missing', which this encoder would hold as a fixed zero. Build the encoder with "
                         f"missing='learned' to load it, or set that entry to zero to drop it")


class NumericEncoder(nn.Module):
    """Numbers to tokens, [..., C] -> [..., C, d], with the encoder as a switch.

    n_fields         C, the number of numeric fields
    token_dim        width d of a token
    kind             "ple" (the model in use, the default), "learned_ple", "periodic" or "hybrid"
    edges            "ple": [C, B + 1] fixed bin edges; None puts n_bins even bins on [0, 1]
    n_bins           "ple": B when no edges are given; None reads N_BINS
    open_ends        "ple": the outer bins run on past the outer edges; None reads PLE_OPEN_ENDS
    centres          "learned_ple", "hybrid": [C, K] starting centres (`fit_centres`); None puts
                     n_centres even centres on [0, 1], the quantiles on the scale of UnitQuantileScaler
                     of a continuous field without ties
    n_centres        "learned_ple", "hybrid": K when no centres are given; None reads N_CENTRES
    branch_dim       "learned_ple", "hybrid": the width of each branch; None reads the larger of BRANCH_DIM
                     and the number of intervals K - 1, so that the piecewise part keeps a direction per
                     interval
    n_frequencies    "periodic", "hybrid": F; None reads N_FREQUENCIES
    frequency_init   "periodic", "hybrid": "log" (log-spaced) or "normal" (random)
    frequency_scale  "periodic", "hybrid": the spread of "normal", in turns; None reads FREQUENCY_SCALE
    lite             "periodic": one matrix for every field instead of one per field
    learn_centres    "learned_ple", "hybrid": True, the centres learn; False, they stay where they start,
                     the control arm that isolates the effect of moving centres
    missing          "zero" (the default): a fixed zero buffer is the value part of a missing number, so a
                     missing number gives its field identity alone, as in the model in use; "learned": a
                     trained vector per field instead, the arm. Both keep the entry "missing" in their
                     state; "zero" loads it only when it is all zero, and a ValueError stops a load that
                     would put a trained missing vector there
    unit_scale       None: "periodic" and "hybrid" read the unit scale, and "ple" and "learned_ple" do when
                     their edges or centres lie on [0, 1]; True or False forces it. A kind that reads the
                     unit scale holds every value to [0, 1] and looks at the scale of every field over the
                     first training batches (see `_check_scale`). The flag is kept in the state as
                     the buffer `held_to_unit`, so an encoder loaded from a checkpoint reads its numbers as
                     the one saved did (load_piecewise_weight turns it off); a checkpoint without that
                     entry leaves the flag as the encoder was built
    unscaled         what that look does when more than half the values of a field lie outside [0, 1]:
                     "warn" (the default) gives a UserWarning; "raise" gives a ValueError with the same
                     text, and the counts of the fields it names start again, so that the next training
                     batch is judged afresh

    forward(x, missing=None): x [..., C] numbers; missing None or bool [..., C], True where a value is
    missing. Returns [..., C, d]: the value part of every field plus its identity, with the missing
    vector of the field as the value part where a value is missing. A value that is not a finite number
    (NaN, plus or minus infinity) counts as missing in any case. `settings` holds the switches that apply
    to the kind. centre_parameters() gives the weights that place the centres, [] for kinds without them.
    """

    def __init__(self, n_fields, token_dim, kind="ple", edges=None, n_bins=None, open_ends=None, centres=None,
                 n_centres=None, branch_dim=None, n_frequencies=None, frequency_init="log", frequency_scale=None,
                 lite=False, learn_centres=True, missing="zero", unit_scale=None, unscaled="warn"):
        super().__init__()
        if kind not in KINDS:
            raise ValueError(f"kind must be one of {KINDS}; got {kind!r}")
        if missing not in MISSING_KINDS:
            raise ValueError(f"missing must be one of {MISSING_KINDS}: a trained vector or a fixed zero for a missing "
                             f"number; got {missing!r}")
        if unscaled not in UNSCALED_KINDS:
            raise ValueError(f"unscaled must be one of {UNSCALED_KINDS}: a warning or an error when most values of a "
                             f"field lie outside [0, 1]; got {unscaled!r}")
        C, d = self.n_fields, self.token_dim = int(n_fields), int(token_dim)
        self.kind = kind
        n_freq = N_FREQUENCIES if n_frequencies is None else int(n_frequencies)
        scale = FREQUENCY_SCALE if frequency_scale is None else float(frequency_scale)
        if kind == "ple":
            if edges is None:
                n = N_BINS if n_bins is None else int(n_bins)
                # Even bins on [0, 1] are equal-share bins on the scale of UnitQuantileScaler, for a field without ties.
                edges = np.tile(np.linspace(0.0, 1.0, n + 1), (C, 1))
            edges = np.asarray(edges, dtype=np.float64)
            if edges.ndim != 2 or edges.shape[0] != C or edges.shape[1] < 2:
                raise ValueError(f"edges must be [C, B + 1] = [{C}, B + 1], one row of bin edges per field; got "
                                 f"shape {edges.shape}")
            self.value = FixedBinBranch(edges, d, open_ends)
            reads_unit = _on_unit_scale(edges)
            self.settings = {"kind": kind, "n_fields": C, "token_dim": d, "n_bins": edges.shape[1] - 1,
                             "open_ends": self.value.open_ends}
        elif kind == "periodic":
            self.value = FourierBranch(C, d, n_freq, frequency_init, scale, shared=lite, matrix_std=TOKEN_STD)
            reads_unit = True
            self.settings = {"kind": kind, "n_fields": C, "token_dim": d, "n_frequencies": n_freq,
                             "frequency_init": frequency_init, "lite": bool(lite)}
            if frequency_init == "normal":
                self.settings["frequency_scale"] = scale
        else:
            given = None if centres is None else np.asarray(centres, dtype=np.float64)
            # The number of centres decides the default branch width; a malformed array is left to the branch, which
            # says what shape it needs.
            if given is not None and given.ndim == 2:
                k = given.shape[1]
            else:
                k = N_CENTRES if n_centres is None else int(n_centres)
            # One direction per interval at least: with 33 centres a branch of 16 would hold the 32 intervals to 16
            # directions, where 32 fixed bins have 32.
            b = max(BRANCH_DIM, k - 1) if branch_dim is None else int(branch_dim)
            bins = LearnedBinBranch(C, b, centres, n_centres, learn_centres=learn_centres)
            pieces = [bins]
            # "hybrid" reads the unit scale whatever its centres: its raw and Fourier branches are made for [0, 1].
            reads_unit = kind == "hybrid" or given is None or _on_unit_scale(given)
            self.settings = {"kind": kind, "n_fields": C, "token_dim": d, "n_centres": bins.vectors.shape[1],
                             "branch_dim": b, "learn_centres": bool(learn_centres)}
            if kind == "hybrid":
                # Inside "hybrid" the Fourier matrix starts at the spread that makes its b numbers about one in size,
                # like the other two branches; the projection after the three sets the scale of the token.
                fourier = FourierBranch(C, b, n_freq, frequency_init, scale, shared=False,
                                        matrix_std=1.0 / math.sqrt(2 * n_freq + 1))
                pieces = [RawBranch(C, b), fourier, bins]
                self.settings.update({"n_frequencies": n_freq, "frequency_init": frequency_init})
                if frequency_init == "normal":
                    self.settings["frequency_scale"] = scale
            self.value = ProjectedBranches(C, d, pieces)
        # The identity of every field, added to its value part and kept when the value is missing; for "ple" it is
        # b_c of the model in use. A small random start lets fields tell each other apart from the first step.
        self.identity = nn.Parameter(torch.randn(C, d) * TOKEN_STD)
        if missing == "learned":
            # The value part of a missing value. It starts at zero, so a fresh encoder gives a missing field its
            # identity alone; it learns from the first step on, since its gradient is that of the token itself.
            self.missing = nn.Parameter(torch.zeros(C, d))
        else:
            # A fixed zero under the same name, so checkpoints of either form share their keys: a missing number then
            # gives its identity alone, and no weight waits for missing values that a batch may never hold.
            self.register_buffer("missing", torch.zeros(C, d))
            # The shared name would let a checkpoint of "learned" fill the zero without a word; the hook stops a load
            # whose missing entry is not all zero, and lets an all-zero entry through as before. It is registered with
            # the method behind register_load_state_dict_pre_hook, since torch 2.0 to 2.4 have only this one.
            self._register_load_state_dict_pre_hook(_keep_missing_zero)
        # Whether every value is held to [0, 1], as a buffer so that it is saved and loaded with the weights; the
        # setter of unit_scale writes it, and the plain flag beside it is what a call reads, without a wait on a GPU.
        self.register_buffer("held_to_unit", torch.tensor(False))
        self.unit_scale = reads_unit if unit_scale is None else bool(unit_scale)
        self.unscaled = unscaled
        self.settings.update({"missing": missing, "unit_scale": self.unit_scale, "unscaled": unscaled})
        # The look at the scale: per field, the values seen and those outside [0, 1] over the training batches so far,
        # and whether the field is still looked at. Plain tensors made on the CPU whatever the default device, so that
        # an encoder built under torch.device("meta") or "cuda" keeps them where a training step can count, and not
        # saved; `_look_open` is a plain bool, so that a training step after the look has closed reads no tensor.
        self._seen = torch.zeros(C, dtype=torch.long, device="cpu")
        self._outside = torch.zeros(C, dtype=torch.long, device="cpu")
        self._scale_open = torch.ones(C, dtype=torch.bool, device="cpu")
        self._looks = 0
        self._look_open = True

    @property
    def unit_scale(self):
        """True when the encoder holds every value to [0, 1] and looks at the scale of the first batches."""
        return self._unit_scale

    @unit_scale.setter
    def unit_scale(self, flag):
        """Set the flag, the buffer held_to_unit that saves it, and `settings`."""
        self._unit_scale = bool(flag)
        if not self.held_to_unit.is_meta:
            self.held_to_unit.fill_(self._unit_scale)
        settings = self.__dict__.get("settings")
        if settings is not None:
            settings["unit_scale"] = self._unit_scale

    def _load_from_state_dict(self, state_dict, prefix, *args, **kwargs):
        # A checkpoint saved before the flag was kept has no entry for it: the encoder then keeps the flag it was built
        # with, as such a load did before, and a strict load does not miss the entry.
        key = prefix + "held_to_unit"
        if key not in state_dict:
            # From the flag itself, on the device of the buffer, or on the CPU for an encoder built on the meta device,
            # whose buffer holds no value that a load with assign=True could keep.
            device = None if self.held_to_unit.is_meta else self.held_to_unit.device
            state_dict = {**state_dict, key: torch.tensor(self._unit_scale, device=device)}
        super()._load_from_state_dict(state_dict, prefix, *args, **kwargs)
        if not self.held_to_unit.is_meta:
            self.unit_scale = bool(self.held_to_unit)

    def forward(self, x, missing=None):
        """x [..., C] numbers to tokens [..., C, d]; `missing` is None or bool [..., C]."""
        if x.dim() == 0 or x.shape[-1] != self.n_fields:
            raise ValueError(f"x must be [..., C] with C = {self.n_fields} fields; got shape {tuple(x.shape)}. Build "
                             f"the encoder with n_fields equal to the last dimension, or bring x to {self.n_fields} "
                             f"fields")
        # The values stay in 32-bit numbers at least until a branch has formed its shares, angles or positions; whole
        # numbers and 64-bit numbers are brought to that type, and only the branches' results take the module's type.
        x = x.to(_working_type(self.identity.dtype))
        # Every value that is not a finite number counts as missing: NaN, and plus or minus infinity, which no branch
        # could turn into a finite token.
        absent = ~torch.isfinite(x)
        if missing is not None:
            if tuple(missing.shape) != tuple(x.shape):
                raise ValueError(f"missing must have the shape of x, {tuple(x.shape)}, True where a value is missing; "
                                 f"got {tuple(missing.shape)}")
            absent = absent | missing.bool()
        # A missing slot is read as 0 before any branch sees it. Whatever it held then reaches no weight and no
        # gradient; the missing vector takes the place of its value part.
        filled = torch.where(absent, torch.zeros_like(x), x)
        if self.unit_scale:
            if self.training and self._look_open:
                self._check_scale(filled, absent)
            # The scaler holds every value to [0, 1]; the same hold here keeps a value that bypassed it (a huge amount,
            # say) from growing a token without bound through the raw and Fourier branches.
            filled = filled.clamp(0.0, 1.0)
        value = self.value(filled)
        # The two learned vectors take the number type of the value part, so that mixed precision stays mixed.
        value = torch.where(absent.unsqueeze(-1), self.missing.to(value.dtype), value)
        return value + self.identity.to(value.dtype)

    def _check_scale(self, x, absent):
        """Look at the fields still open for numbers that skipped the scaler: most of their values outside [0, 1].

        x        [..., C] the values, a missing slot read as 0
        absent   bool [..., C], True where a value is missing

        Returns nothing. The values of every field still looked at are counted over the training batches, with
        those outside [0, 1]. A field whose values so far lie more than half outside [0, 1] is named at once:
        unscaled="warn" gives one UserWarning for the fields named in that batch and stops looking at them, and
        unscaled="raise" gives a ValueError with the same text and starts their counts again, so that a batch given
        again, or a scaled one, is judged afresh. A field stops being looked at once LOOK_VALUES of its values have
        not named it, so that it is judged on many values and not on the few of its first batch, and every field
        stops after LOOK_BATCHES training batches. A field missing from every batch keeps one small count going
        per training batch until then. While the look is open, a training step compiled with fullgraph=True stops
        on it; `close_look` ends it at once.
        """
        present = (~absent).reshape(-1, self.n_fields)
        seen = present.sum(dim=0).cpu().masked_fill(~self._scale_open, 0)          # [C] values that are there
        outside = (present & ((x < 0.0) | (x > 1.0)).reshape(-1, self.n_fields)).sum(dim=0).cpu()
        self._seen += seen
        self._outside += outside.masked_fill(~self._scale_open, 0)
        self._looks += 1
        named = self._scale_open & (self._seen > 0) & (self._outside > OUTSIDE_SHARE * self._seen)
        fields = torch.nonzero(named).flatten().tolist()
        if fields:
            shown = f"{fields[:10]}" + (f" and {len(fields) - 10} more" if len(fields) > 10 else "")
            text = (f"NumericEncoder (kind {self.kind!r}): more than half the values of field(s) {shown} lie outside "
                    f"[0, 1]. This kind reads numbers on the [0, 1] scale of UnitQuantileScaler and holds every value "
                    f"to [0, 1], so unscaled numbers all read as 0 or 1: fit UnitQuantileScaler on training rows and "
                    f"pass scaler.transform(values)")
            if self.unscaled == "raise":
                # The look stays open and the counts of the named fields start again: the error stops this batch, so
                # a batch given again is judged afresh.
                self._seen[named], self._outside[named] = 0, 0
                raise ValueError(text)
            warnings.warn(text, stacklevel=2)
            self._scale_open = self._scale_open & ~named
        self._scale_open = self._scale_open & (self._seen < LOOK_VALUES)
        if self._looks >= LOOK_BATCHES:
            self._scale_open = torch.zeros_like(self._scale_open)
        self._look_open = bool(self._scale_open.any())

    def close_look(self):
        """Stop the look at the scale for every field at once. A training step compiled with
        torch.compile(fullgraph=True) needs the look closed, since the look reads tensors on the CPU: warm up eagerly
        until `_look_open` is False, or call this once the numbers are known to be scaled."""
        self._scale_open = torch.zeros_like(self._scale_open)
        self._look_open = False

    def learned_bins(self):
        """The branch with learned centres ("learned_ple" and "hybrid"), or None; its centres() reads them."""
        branches = getattr(self.value, "branches", ())
        return next((branch for branch in branches if isinstance(branch, LearnedBinBranch)), None)

    def centre_parameters(self):
        """The weights that place the learned centres, [first, raw_gaps], or [] for "ple" and "periodic"."""
        bins = self.learned_bins()
        return [] if bins is None else bins.centre_parameters()


# ----------------------------------------------------------------------------------------------
# the centres in training: an optimiser group of their own
# ----------------------------------------------------------------------------------------------

def centre_parameters(model):
    """Every weight that places learned centres anywhere in `model`, each once, for an optimiser group of its own.

    model   any torch module: a NumericEncoder, a whole model holding one or several, or a LearnedBinBranch

    Returns a list of parameters, [first, raw_gaps] of every LearnedBinBranch in the model, empty when it
    has none. The centres live on [0, 1] with intervals a sixteenth wide, and at the global learning
    rate a few steps can carry them off the data (the module docstring gives the measurement); the
    recommended rate of the group is the global rate times CENTRE_LR_FACTOR:

        centres = centre_parameters(model)
        ids = {id(weight) for weight in centres}
        others = [weight for weight in model.parameters() if id(weight) not in ids]
        optimiser = torch.optim.Adam([{"params": others}, {"params": centres, "lr": lr * CENTRE_LR_FACTOR}], lr=lr)

    Frozen centres (learn_centres=False) are listed too; they get no gradient, so the optimiser leaves them.
    """
    found, seen = [], set()
    for module in model.modules():
        # The class is also recognised by its name, so a model built from another copy of this file (a folder of its
        # own next to the package) is read as well.
        if isinstance(module, LearnedBinBranch) or type(module).__name__ == "LearnedBinBranch":
            for weight in (module.first, module.raw_gaps):
                if id(weight) not in seen:
                    seen.add(id(weight))
                    found.append(weight)
    return found


# ----------------------------------------------------------------------------------------------
# where the bins and centres start, and how many of them the rows use
# ----------------------------------------------------------------------------------------------

def _between(distinct, k):
    """k places from m distinct sorted values: all of them, and k - m more spread evenly over the m - 1 gaps."""
    m = len(distinct)
    if m < 2:
        # One value (a constant field) or none (no finite row): there is nothing to spread between, so the places are
        # the even grid of the unit scale, where the default centres and bins lie as well.
        return np.linspace(0.0, 1.0, k)
    widths = np.diff(distinct)
    extra = k - m
    count = np.full(m - 1, extra // (m - 1))
    # What an even share leaves over goes to the widest gaps, one place each, so that no gap stays much coarser.
    count[np.argsort(-widths, kind="stable")[:extra % (m - 1)]] += 1
    pieces = [distinct[j] + widths[j] * np.arange(count[j] + 1) / (count[j] + 1) for j in range(m - 1)]
    return np.concatenate(pieces + [distinct[-1:]])


def _spread(values, k):
    """Per field, k strictly increasing float32 places: the distinct quantiles, the rest spread evenly between them."""
    values = values.detach().cpu().numpy() if torch.is_tensor(values) else values
    values = np.asarray(values, dtype=np.float64)
    # A single column [N] is read as one field, [N, 1], as the scalers read it.
    values = values[:, None] if values.ndim == 1 else values
    if values.ndim != 2:
        raise ValueError(f"the rows must be [N, C], one column per field; got shape {values.shape}")
    probs = np.linspace(0.0, 1.0, k)
    out = np.empty((values.shape[1], k), dtype=np.float32)
    for c in range(values.shape[1]):                     # one pass per field, never per row
        col = values[:, c]
        col = col[np.isfinite(col)]
        # The quantiles at the same shares quantile_edges of numeric_frontend.py takes, without their repeats.
        distinct = np.unique(np.quantile(col, probs)) if len(col) else np.empty(0)
        places = _between(distinct, k).astype(np.float32)
        # Two places that are apart in 64 bits can meet in 32; each is kept at least one 32-bit step above the last.
        for j in range(1, k):
            if places[j] <= places[j - 1]:
                places[j] = np.nextafter(places[j - 1], np.float32(np.inf))
        out[c] = places
    return out


def fit_centres(scaled_train_rows, n_centres=None):
    """Starting centres per field for "learned_ple" and "hybrid": float32 [C, K], strictly increasing.

    scaled_train_rows   [N, C] training rows on the scale the encoder reads (UnitQuantileScaler's [0, 1]);
                        values that are not finite are left out
    n_centres           K; None reads N_CENTRES

    Every field starts at its distinct quantiles (the K quantiles at even shares, without repeats), and
    the places that heaps leave over are spread evenly between them: the gaps between neighbouring
    distinct quantiles get the same number of extra centres, evenly spaced, and the widest gaps take
    what an even share leaves over. A continuous field without ties gets its K quantiles, which on the
    unit scale are the even grid of the default; a field with one value or none gets the even grid on
    [0, 1]. Pass the result as NumericEncoder(..., centres=fit_centres(scaled, K)).
    """
    k = N_CENTRES if n_centres is None else int(n_centres)
    if k < 2:
        raise ValueError(f"n_centres must be 2 or more, the two ends at least; got {k}")
    return _spread(scaled_train_rows, k)


def fit_edges(scaled_train_rows, n_bins=None):
    """Bin edges per field for "ple" on the unit scale, by the rule of fit_centres: float32 [C, B + 1], increasing.

    scaled_train_rows   [N, C] training rows on the scale the encoder reads; values that are not finite are left out
    n_bins              B; None reads N_BINS

    Unlike `quantile_edges` of numeric_frontend.py, which drops the repeated quantiles of a heap and
    leaves the bins it cannot fill with no width, every field keeps B bins with a width, the extra edges
    spread evenly between its distinct quantiles.
    """
    n = N_BINS if n_bins is None else int(n_bins)
    if n < 1:
        raise ValueError(f"n_bins must be 1 or more; got {n}")
    return _spread(scaled_train_rows, n + 1)


def interval_use(encoder, scaled_rows):
    """Per field, how many intervals hold rows: the bins of "ple", the gaps between the centres of the others.

    encoder       a NumericEncoder of kind "ple", "learned_ple" or "hybrid"
    scaled_rows   [..., C] rows on the scale the encoder reads (numpy or torch); values that are not finite are
                  left out

    Returns a dict of numpy arrays:
        "intervals"   int64 [C]: the intervals of every field (bins with a width, or the K - 1 gaps between centres)
        "held"        int64 [C]: how many of them hold at least one row
        "rows"        int64 [C, n]: the rows in every interval, n = B bins or K - 1 gaps; 0 on a bin of no width
        "outside"     int64 [C]: the rows below the first edge or centre or above the last, which read an end vector

    A row on an inner edge counts for the interval above it, a row on the last edge for the last
    interval. The rows are read as the encoder reads them: on the unit scale they are first held to
    [0, 1]. The learned centres are read where they are now, so after training the count shows the
    intervals that training left empty, whose centres get no gradient.
    """
    if not isinstance(encoder, NumericEncoder) and type(encoder).__name__ != "NumericEncoder":
        raise ValueError(f"interval_use reads a NumericEncoder; got {type(encoder).__name__}")
    rows = scaled_rows.detach().cpu().numpy() if torch.is_tensor(scaled_rows) else scaled_rows
    rows = np.asarray(rows, dtype=np.float64)
    if rows.ndim == 0 or rows.shape[-1] != encoder.n_fields:
        raise ValueError(f"scaled_rows must be [..., C] with C = {encoder.n_fields} fields, the fields of the encoder; "
                         f"got shape {rows.shape}")
    rows = rows.reshape(-1, encoder.n_fields)
    if encoder.kind == "ple":
        left = encoder.value.left.detach().double().cpu().numpy()
        right = left + encoder.value.width.detach().double().cpu().numpy()
        real = encoder.value.width.detach().cpu().numpy() > 0
    elif encoder.learned_bins() is not None:
        centres = encoder.learned_bins().centres().detach().double().cpu().numpy()
        left, right = centres[:, :-1], centres[:, 1:]
        real = np.ones(left.shape, dtype=bool)
    else:
        raise ValueError(f"interval_use counts the bins of 'ple' or the gaps between the centres of 'learned_ple' and "
                         f"'hybrid'; kind {encoder.kind!r} has neither")
    counts = np.zeros(real.shape, dtype=np.int64)
    outside = np.zeros(encoder.n_fields, dtype=np.int64)
    for c in range(encoder.n_fields):                    # one pass per field, never per row
        col = rows[:, c]
        # As the encoder reads them: a value that is not finite counts as missing, and only then are the rest held to
        # [0, 1] on the unit scale, so an infinity is left out here rather than counted at an end.
        col = col[np.isfinite(col)]
        if encoder.unit_scale:
            col = np.clip(col, 0.0, 1.0)
        if not real[c].any():
            outside[c] = len(col)                        # no bin with a width: every row reads the same token
            continue
        # The bins with a width follow one another, so their edges are one increasing line; np.histogram counts
        # half-open intervals, the last one closed, and leaves the rows beyond both ends out.
        bounds = np.concatenate([left[c][real[c]], right[c][real[c]][-1:]])
        held = np.histogram(col, bins=bounds)[0]
        counts[c][real[c]] = held
        outside[c] = len(col) - held.sum()
    return {"intervals": real.sum(axis=1).astype(np.int64), "held": ((counts > 0) & real).sum(axis=1).astype(np.int64),
            "rows": counts, "outside": outside}


# ----------------------------------------------------------------------------------------------
# the trained weights of the model in use
# ----------------------------------------------------------------------------------------------

def load_piecewise_weight(encoder, W, bin_counts, layout="rtdl", b=None):
    """Put the trained weights of a piecewise-linear encoding, W_c PLE(x) + b_c, into a "ple" encoder.

    encoder      NumericEncoder(C, d, kind="ple", edges=E) with the model's own edges E [C, B + 1], a field
                 with n < B bins padded at its end by repeating its last edge (as numeric_frontend.py pads)
    W            [C, B, d], numpy or torch: the trained weight of the model in use
    bin_counts   [C]: the number of bins n of every field, 1 to B
    layout       where W keeps the bins of a field with n < B bins. "rtdl": the first n - 1 bins at the
                 start, zeros after them, the last bin at index B - 1, as rtdl_num_embeddings (the package
                 of Gorishniy et al., 2022) lays it out; that bin is moved to index n - 1, where this
                 encoder keeps it. "in_order": the n bins at the start, copied as they are.
    b            None, or [C, d]: the trained constant, which goes into `encoder.identity`

    Returns the encoder, its weights replaced. Bins of no width get zero weights, which they never read.
    The encoder then reads its numbers as the trained model did: unit_scale is set to False, in
    `settings` too, so no value is held to [0, 1] and the scale is not looked at, even when the model's
    own edges all lie on [0, 1] (numbers min-max scaled before its encoding). Held there, a value
    beyond the trained range would give another token than the trained model gives with open ends.
    The flag is saved with the weights (the buffer `held_to_unit`), so an encoder built again the same
    way and loaded from a checkpoint of this one reads its numbers as this one does.
    rtdl's encoding also lets its first bin run on below the lowest edge and its last bin above the
    highest edge: with layout "rtdl" the encoder must be built with open_ends=True (or PLE_OPEN_ENDS set)
    to give the same tokens, and a warning says so when it is not. Edges whose bins with a width are not
    the first n of a field get a warning too: the weights would then sit on other bins than the model's.
    """
    if getattr(encoder, "kind", None) != "ple":
        raise ValueError(f"load_piecewise_weight fills the bins of 'ple'; got kind {getattr(encoder, 'kind', None)!r}. "
                         f"Build the encoder with kind='ple' and the model's own edges")
    if layout not in PIECEWISE_LAYOUTS:
        raise ValueError(f"layout must be one of {PIECEWISE_LAYOUTS}; got {layout!r}")
    target = encoder.value.weight
    C, B, d = target.shape
    W = torch.as_tensor(W).detach().to(device=target.device, dtype=target.dtype)
    if tuple(W.shape) != (C, B, d):
        raise ValueError(f"W must be [C, B, d] = [{C}, {B}, {d}], the shape of encoder.value.weight; got "
                         f"{tuple(W.shape)}. Build the encoder with the model's own edges, [C, B + 1], and token_dim d")
    counts = np.asarray(bin_counts).reshape(-1)
    if len(counts) != C or not np.all((counts >= 1) & (counts <= B)) or not np.all(counts == np.round(counts)):
        raise ValueError(f"bin_counts must hold {C} whole numbers from 1 to {B}, the bins of every field; got "
                         f"{counts.tolist()}")
    counts = counts.astype(np.int64)
    if b is not None:
        b = torch.as_tensor(b).detach().to(device=encoder.identity.device, dtype=encoder.identity.dtype)
        if tuple(b.shape) != (C, d):
            raise ValueError(f"b must be [C, d] = [{C}, {d}], the shape of encoder.identity; got {tuple(b.shape)}")
    placed = torch.zeros_like(target)
    for c, n in enumerate(counts.tolist()):
        if layout == "rtdl":
            # rtdl writes the last bin of every field at the last index; this encoder reads it at index n - 1.
            placed[c, :n - 1] = W[c, :n - 1]
            placed[c, n - 1] = W[c, B - 1]
        else:
            placed[c, :n] = W[c, :n]
    # Every input was checked before anything is written, so a call that fails leaves the encoder as it was.
    with torch.no_grad():
        target.copy_(placed)
        if b is not None:
            encoder.identity.copy_(b)
    # The trained model held no value to [0, 1], so neither does the encoder that scores as it: with edges on [0, 1]
    # and open ends, a value beyond the trained range keeps running on through the outer bins, as it did there.
    # The setter writes the buffer that saves the flag, and `settings`.
    encoder.unit_scale = False
    # Two likely mistakes, said once each without stopping the call: the weights are in place whatever the edges hold.
    real = (encoder.value.width > 0).cpu().numpy()
    first_n = np.arange(B)[None, :] < counts[:, None]
    off = np.nonzero((real != first_n).any(axis=1))[0].tolist()
    if off:
        warnings.warn(f"load_piecewise_weight: the edges of field(s) {off[:10]} do not have bin_counts bins with a "
                      f"width at their start, so those weights sit on other bins than the model's. Build the encoder "
                      f"with the model's own edges, padded at the end by repeating the last edge", stacklevel=2)
    if layout == "rtdl" and not encoder.value.open_ends:
        warnings.warn("load_piecewise_weight: rtdl lets the first bin run on below the lowest edge and the last bin "
                      "above the highest edge, but this encoder holds such values at the ends (open_ends=False), so "
                      "its tokens differ there. Build it with open_ends=True, or set PLE_OPEN_ENDS = True",
                      stacklevel=2)
    return encoder


# ----------------------------------------------------------------------------------------------
# counting and describing
# ----------------------------------------------------------------------------------------------

def count_weights(module):
    """The number of weights of `module`: every number in its parameters, a shared parameter counted once."""
    return sum(weight.numel() for weight in module.parameters())


def weight_table(n_fields=64, widths=(48, 96, 144)):
    """The number of weights of every kind with the default settings, as {row name: {width: count}}.

    The rows are the four kinds and "periodic, lite". The encoders are built only to be counted.
    """
    rows = {"ple": {}, "learned_ple": {}, "periodic": {}, "periodic, lite": {}, "hybrid": {}}
    for d in widths:
        for name in rows:
            kind, lite = ("periodic", True) if name == "periodic, lite" else (name, False)
            rows[name][int(d)] = count_weights(NumericEncoder(n_fields, d, kind=kind, lite=lite))
    return rows


def describe(encoder):
    """One line per switch of `encoder` with its value, then the number of weights, as one string."""
    s = encoder.settings
    lines = [f"NumericEncoder: kind {s['kind']}, {s['n_fields']} fields, tokens of width {s['token_dim']}"]
    lines += [f"  {name:<16} {value}" for name, value in s.items()]
    lines.append(f"  {'weights':<16} {count_weights(encoder):,}")
    return "\n".join(lines)


def _demo():
    """Prints the weight table at 64 fields, then the default encoder of every kind on made-up values."""
    table = weight_table()
    widths = list(next(iter(table.values())))
    print(f"{'kind':<16}" + "".join(f"{'width ' + str(d):>14}" for d in widths))
    for name, counts in table.items():
        print(f"{name:<16}" + "".join(f"{counts[d]:>14,}" for d in widths))
    torch.manual_seed(0)
    x = torch.rand(4, 7, 64)
    x[0, 0, :3] = float("nan")                          # three missing values in the first row
    x[0, 1, :2] = float("inf")                          # and two that are not finite either
    for kind in KINDS:
        tokens = NumericEncoder(64, 48, kind=kind)(x)
        print(f"{kind:<12} tokens {tuple(tokens.shape)}, finite: {bool(torch.isfinite(tokens).all())}")


if __name__ == "__main__":
    _demo()
