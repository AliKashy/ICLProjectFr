"""Time as row inputs: the gap to the latest earlier row under the model's rule, the clock and the calendar.

What this file does
-------------------
It turns the times of a batch into vectors [B, T, d] that are added to the rows, with the encoding as a
switch, so that each way can be tried against the time input of the model in use.

    gap_seconds       for every row, the seconds to the latest real row of its sequence in a strictly
                      earlier whole second, 0 when there is none
    soft_log          8 ln(1 + seconds / 8): close to the seconds themselves for the first few seconds, a
                      logarithm after that (PRAGMA, Revolut, arXiv 2604.08649, Section 2.2)
    GapEncoder        a gap in seconds to a vector of width d, with `kind`
                        "scalar"    a learned vector times log(1 + gap) plus a learned bias: the model in use
                        "ple"       the soft log of the gap through fixed bins (PiecewiseLinearEmbedding of
                                    numeric_frontend.py), edges from ten seconds to ninety days
                        "sinusoid"  the time encoder of FraudTransformer (HSBC, arXiv 2509.23712)
    calendar_parts    the second of the day, the second of the week from Monday 00:00 and the day of the
                      month of every time, on the local clock
    CalendarEncoder   the hour of the day and the day of the week (the day of the month as a switch) as
                      sines and cosines of the calendar periods, then two small linear layers (PRAGMA,
                      Section 2.3.3)

The gap follows the one time rule of the package: the rows a row may measure to are those that
`eligible_rows` of interleaved_reread.py gives it, which is the rule of the mask of stage 2. Two rows
of one second never measure to each other, padding is never counted, and a later row never changes an
earlier row's gap. The whole second of a time is the one `whole_seconds` of masks.py gives, the same
for the mask, the memory, the bias and this file: a unit that is a whole number divides as an integer
(1e9 written as a float included), times in 64-bit floats are floored even with a unit of 1, and times
in 32-bit or 16-bit floats stop with a plain error, since their steps near the times of today are 128
seconds wide or more. The builder's int64 times are the ones to pass.

The gap is the difference of the two whole seconds, and rows tie by their whole second: with times
[10, 20, 20] the gaps are 0, 10 and 10. That is the gap a sequence builder computes from whole-second
times. A builder that ties rows by the full timestamp gives another gap on times with fractions of a
second: times 10.0, 20.2, 20.7 and 30.0 s give 0, 10, 10 and 10 here, and 0, 10, 0 and 10 from such a
builder, since there the row at 20.7 s measures to the row at 20.2 s. Whether the builder of the model
in use ties by the whole second is to be confirmed before "scalar" is called its gap.

"sinusoid" as the paper gives it (checked against its text, Section 6 and Table 7): the time of an
event is counted in milliseconds, and with the relative scheme the encoder reads the difference to the
previous event. For a width d it forms theta_i = base ^ (-2 i / d), i = 0 .. d/2 - 1, takes
[sin(theta * t); cos(theta * t)], normalises that with a layer norm of its own (learned scale and
shift) and adds lambda times the result to the token, with base = 1e7 and lambda = 0.01 chosen by the
paper's tuning. Here t is the gap of this file counted in milliseconds, and lambda is the fixed `gain`.
The defaults are that paper-faithful arm. What its frequencies resolve: the fastest pair turns once in
6.3 ms and the slowest once in 9 hours at d = 48 and 14 hours at d = 144, so gaps of days and weeks
wrap around every pair. With whole-second times, every pair that turns in under two seconds (36 to 38
percent of them at these widths) only ever sees whole seconds and carries no pattern of its own.
`ticks_per_second` moves the whole ladder: ticks_per_second=1 spreads the same pairs from a period of
6.3 seconds to one of 1.0 year (d = 48) or 1.6 years (d = 144), a range that fits gaps of seconds to
months. That is the arm to run beside the paper-faithful one. In a synthetic check on whole-second
gaps of seconds to 90 days (width 32, three seeds), the paper-faithful sinusoid was the weakest gap
encoder, 0.072 against 0.059 for "scalar" and 0.037 for "ple" at a learning rate of 0.01, while
ticks_per_second=1 gave 0.043. At a rate of 0.1 ticks_per_second=1 gave 0.015, where the
paper-faithful sinusoid gave 0.059, "scalar" 0.082 and "ple" 0.037. A sinusoid arm run with the
defaults alone would understate what sines can do.

The calendar follows PRAGMA: the hour of the day, the day of the week and the day of the month become
sines and cosines with periods fixed to the calendar rather than learned, and two linear layers with a
GELU between them make a vector that is added to the row. Each period is used with its first
`harmonics` multiples (3 by default: 24, 12 and 8 hours for the hour of the day), so that a pattern a
few hours long, the small hours of the night, is easy to draw. The day of the month is read as the
share of its own month that has passed, the number of days of that month coming from the same
whole-number calendar rule as the date: the end of every month, of 28, 29, 30 or 31 days, falls at
the same phase, the end of the cycle, where the next month begins. Bills and salaries at the end of
the month therefore read alike in every month; a date in the middle reads a little apart in months of
other lengths (the 15th is 14 / 28 of February and 14 / 31 of March).

Why it exists
-------------
The model in use tells stage 2 one thing about time: log(1 + the gap to the latest earlier row), one
number that moves the row along one direction. A burst of tries ten seconds apart and a bill a month
after the last one differ only in how far along that direction the row sits. Bins on the soft log give
every range of gaps (a burst, a session, a day, a week, a monthly bill) a direction of its own, fine
where gaps are short and coarse where they are long. FraudTransformer reports its relative sinusoidal
encoding with a layer norm, together with a learned position table, as its strongest variant on bank
payments. The clock and the calendar are not in the gap at all: legitimate spending keeps its hours and
its days, fraud can keep others (the night, a weekend), and bills and salaries come at the start and
the end of the month. PRAGMA adds such calendar features to every event.

The gap to the latest row is one number per row. How long ago every other readable row lay is a number
per pair of rows, which a row vector cannot carry; that is the time-gap part of the learned attention
bias below.

Where it goes
-------------
Stage 2, once per batch, with the times, the mask of real rows and the time unit that stage 2 already
takes. The unit is passed to every call, as an int (1_000_000_000 for the nanoseconds of the builder):

    unit = 1_000_000_000                                   # time units per second of the batch, as an int
    gaps = gap_seconds(times, valid, units_per_second=unit)                       # float64 [B, T], whole seconds
    clock = CalendarEncoder(144, units_per_second=unit)(times, valid)             # [B, T, 144]
    vectors = vectors + GapEncoder(144, kind="ple")(gaps, valid) + clock
    history = stage2(vectors, times, valid)                # history_stage.HistoryStage
    rows = stage(channels, fields, times, valid, row_extra=GapEncoder(96)(gaps, valid))   # latent_channels.py

The encoders take the place of the time-gap input of the model in use. Its sequence builder writes
log1p of the gap as one more number of the row (`w_cont[..., n_cont]` in the original
`SequenceBuilder`), and the field tokenizer turns that number into a token: a learned vector times the
number plus a bias, which is "scalar". A GapEncoder at the width of stage 1 can stand in for that token
among the field tokens; one at the width of stage 2 is added to the row as above. Either way its
width is the width of what it joins.

The time-gap part of the learned attention bias is in the package: `AttentionBias` of
additions/model/attention_bias.py. It works on batches [B, T] without any match field. Built with
num_fields=0 and handed an empty [B, T, 0] tensor of codes, it holds one learned number per head and
time-gap bucket, and one per head for a row reading itself, and nothing else:

    bias_block = AttentionBias(num_fields=0, num_heads=8, units_per_second=unit)
    no_codes = torch.zeros(B, T, 0, dtype=torch.long)
    bias = bias_block(no_codes, times, valid)               # float [B, 8, T, T], zero while fresh
    history = stage2(vectors, times, valid, bias=bias)      # history_stage.HistoryStage

The unit goes to that block as the same whole number as everywhere else; a block that reads another
unit than the mask puts pairs into the wrong buckets. The bias is a float per head and pair of rows,
added to the attention logit of row i reading row j before the softmax. A fresh block gives zero, so
stage 2 starts exactly as it was. It changes only the pairs that the time rule opens: a closed pair
stays closed (minus infinity plus any number is minus infinity), and a row that may read only itself
keeps its result. LatentChannelStage of latent_channels.py takes the same tensor as `bias=`
([B, heads, T, T] or [B, 1, T, T]), the same number per head and pair in every channel, and
BestModel of best_model_template.py builds this block itself when its configuration has
time_bias=True. The test file of this module (package only) shows all of this on made-up batches.

What to change for the pod
--------------------------
The four PLACEHOLDER values below. TIME_UNITS_PER_SECOND must be the unit of the times of the batch and
of the mask of stage 2 (the sequence builder of the model in use writes nanoseconds, 1_000_000_000);
every call above names its unit as well, so that no piece falls back to a default that differs from
the mask's. LOCAL_TIME_OFFSET_SECONDS reads stored times on the local clock; a fixed offset ignores the
change to summer time, and a column with the offset of every row (from the time zone of the merchant,
say) can be handed to CalendarEncoder per call instead. GAP_EDGES_SECONDS ends at the longest gap a
window of the model in use can hold. SCALAR_GAP_SECONDS is the unit in which the model in use counts
its gap. A model trained with one kind of gap encoder cannot read another; the weights are trained
again.

How to try it
-------------
    gaps = gap_seconds(times, valid, units_per_second=unit)     # [B, T]; times [10, 20, 20] give 0, 10, 10
    vector = GapEncoder(144, kind="sinusoid")(gaps, valid)      # [B, T, 144]; "scalar", "ple" or "sinusoid"
    beside = GapEncoder(144, kind="sinusoid", ticks_per_second=1)   # the arm beside the paper-faithful one
    clock = CalendarEncoder(144, monthday=True, units_per_second=unit)(times, valid)
    day, week, month_day = calendar_parts(times, units_per_second=unit)    # seconds of day and week, day of month
    python time_encoders.py                                     # gaps and every encoder on a small batch, in the kit
    python -m additions.encoding.time_encoders                  # the same inside the package (package only)
    python -m pytest -q additions/tests/test_encoding_time_encoders.py   # package only
"""
import math

import torch
import torch.nn as nn
import torch.nn.functional as F

try:                                    # inside the package
    from ..model.interleaved_reread import eligible_rows
    from ..model.masks import whole_seconds
    from .numeric_encoders import _Keep32Bits, _working_type
    from .numeric_frontend import PiecewiseLinearEmbedding
except ImportError:
    try:                                # the package on the path, this file run on its own
        from additions.encoding.numeric_encoders import _Keep32Bits, _working_type
        from additions.encoding.numeric_frontend import PiecewiseLinearEmbedding
        from additions.model.interleaved_reread import eligible_rows
        from additions.model.masks import whole_seconds
    except ImportError:                 # the files side by side in one folder
        from interleaved_reread import eligible_rows
        from masks import whole_seconds
        from numeric_encoders import _Keep32Bits, _working_type
        from numeric_frontend import PiecewiseLinearEmbedding

# PLACEHOLDER: how many units of the batch's time values make one second: 1 when the builder writes whole seconds,
# 1_000_000_000 when it writes nanoseconds; it must be the unit the mask of stage 2 is built with.
TIME_UNITS_PER_SECOND = 1

# PLACEHOLDER: the seconds added to a stored time to read the local clock of the transaction: 0 when times are stored
# in local time, -18_000 for times stored in UTC and read in New York in winter.
LOCAL_TIME_OFFSET_SECONDS = 0

# PLACEHOLDER: how many seconds make one unit of the gap that the model in use takes log(1 + gap) of: 1 when it counts
# the gap in seconds.
SCALAR_GAP_SECONDS = 1.0

# PLACEHOLDER: the edges of the gap bins in seconds, from no time to the longest gap a window of the model in use can
# hold (90 days today): 0, 10 s, 1 min, 5 min, 15 min, 1 h, 3 h, 6 h, 12 h, 1 day, then 2, 4, 7, 14, 30, 60, 90 days.
GAP_EDGES_SECONDS = (0, 10, 60, 300, 900, 3_600, 10_800, 21_600, 43_200, 86_400, 172_800, 345_600, 604_800,
                     1_209_600, 2_592_000, 5_184_000, 7_776_000)

# The sinusoid of FraudTransformer as the paper runs it, the paper-faithful arm: base 1e7 on milliseconds and a fixed
# gain of 0.01. ticks_per_second=1 is the arm to run beside it.
SINUSOID_BASE = 1e7
SINUSOID_TICKS_PER_SECOND = 1_000
SINUSOID_GAIN = 0.01

# How many multiples of each calendar period are used, and the width of the layer between the two linear layers.
CALENDAR_HARMONICS = 3
CALENDAR_HIDDEN = 32

# The values the switch `kind` of GapEncoder accepts.
KINDS = ("scalar", "ple", "sinusoid")

SECONDS_PER_DAY = 86_400
SECONDS_PER_WEEK = 7 * SECONDS_PER_DAY
# 1970-01-01, where the times count from, was a Thursday: day 3 of a week that starts on Monday.
EPOCH_WEEKDAY = 3


def _units(units_per_second=None):
    """The number of time units in one second; a whole number given as a float becomes an integer."""
    units = TIME_UNITS_PER_SECOND if units_per_second is None else units_per_second
    # The rule of masks.py turns a whole number into an integer itself; it is done here as well so that the unit an
    # encoder keeps in its settings reads as the integer it stands for.
    return int(units) if float(units).is_integer() else float(units)


def _seconds(times, units_per_second=None):
    """The times as whole seconds, int64, by the one rule of the package: `whole_seconds` of masks.py.

    The rule floors, so times before 1970 stay in their own second; it floors 64-bit float times even
    with a unit of 1, divides by a whole-number unit as an integer, and stops with a plain error on
    times in 32-bit or 16-bit floats, which cannot hold the second of a time of today.
    """
    seconds = whole_seconds(torch.as_tensor(times), _units(units_per_second))
    # The rule gives integers, or 64-bit floats that hold whole numbers. int64 holds every second of the calendar
    # exactly, so the gaps and the calendar below are whole-number arithmetic from here on.
    return seconds.long()


# ----------------------------------------------------------------------------------------------
# the gap to the latest earlier row
# ----------------------------------------------------------------------------------------------

def gap_seconds(times, valid, units_per_second=None):
    """For every row, the seconds to the latest real row of its sequence in a strictly earlier whole second.

    times             int64 (or 64-bit float) [B, T]: the time of every slot (any value on padding)
    valid             bool [B, T]: True on real rows
    units_per_second  how many units of `times` make one second; None reads TIME_UNITS_PER_SECOND

    Returns float64 [B, T], whole seconds: the second of the row minus the second of that latest
    row. A row without such a row (the rows of the first second of a sequence, and every padded
    slot) gets 0. "Latest" goes by the time itself, so the batch does not have to be sorted. Rows tie
    by their whole second, as `whole_seconds` of masks.py gives it; times in 32-bit or 16-bit floats
    stop with a plain error there.
    """
    seconds = _seconds(times, units_per_second)
    # The rows each row may use, by the one rule of the package: real rows of the same sequence in strictly earlier
    # whole seconds. The times go in as whole seconds with a unit of one, so the rule and the gap below read the same
    # seconds whatever the unit or the number type of the batch.
    eligible = eligible_rows(seconds, valid, 1)                           # [B, T, T]; [b, i, j]: i may use j
    B, T = seconds.shape
    # Every line holds the seconds of all rows, with the rows the row may not use set to the lowest number there is,
    # so that the largest entry of a line is the latest second the row may use.
    lowest = torch.iinfo(seconds.dtype).min
    latest = seconds.unsqueeze(1).expand(B, T, T).masked_fill(~eligible, lowest).amax(dim=-1)
    # A row with no row to use measures to its own second, which gives the gap of 0.
    latest = torch.where(eligible.any(dim=-1), latest, seconds)
    # The difference is exact in whole numbers and only then turned into a float.
    return (seconds - latest).to(torch.float64)


def soft_log(seconds):
    """8 ln(1 + seconds / 8): about the seconds themselves below a few seconds, a logarithm above (PRAGMA).

    seconds   a tensor or a number of seconds, 0 or more

    The constant 8 sets where the bend lies: one second reads 0.94, ten seconds 6.5, an hour 49 and ten
    years 140. Short gaps keep a fine, nearly even resolution, and long ones are squeezed so that months
    and years do not take over the scale.
    """
    if torch.is_tensor(seconds):
        return 8.0 * torch.log1p(seconds / 8.0)
    return 8.0 * math.log1p(float(seconds) / 8.0)


class _GapBins(_Keep32Bits, PiecewiseLinearEmbedding):
    """PiecewiseLinearEmbedding over the soft log of the gap, its edges kept in float32 under a 16-bit cast.

    The edges, `left` and `width`, are soft logs of up to about 50; rounded to bfloat16 they would move
    by up to 0.25 and the shares of their bins with them. The shares are formed in 32 bits at least, and
    only they take the number type of the weights, at the product.
    """

    KEEP_32_BITS = ("left", "width")

    def forward(self, x):
        """x [..., 1] soft logs to [..., 1, d]: the bin shares times the learned weights, plus a bias."""
        share = self.encode(x.to(_working_type(self.left.dtype)))
        return torch.einsum("...cb,cbd->...cd", share.to(self.weight.dtype), self.weight) + self.bias


class GapEncoder(nn.Module):
    """A gap in seconds to a vector that is added to a row: [...] -> [..., d].

    token_dim          width d of the vector, the width of the rows it is added to
    kind               "scalar" (the model in use, the default), "ple" or "sinusoid"
    edges_seconds      "ple": the bin edges in seconds, increasing; None reads GAP_EDGES_SECONDS
    base               "sinusoid": the base of the frequencies; None reads SINUSOID_BASE
    ticks_per_second   "sinusoid": the unit the gap is counted in; None reads SINUSOID_TICKS_PER_SECOND
                       (milliseconds, as in the paper: the paper-faithful arm). ticks_per_second=1 spreads
                       the pairs from seconds to a year and more, the arm to run beside it
    gain               "sinusoid": the fixed factor on the normalised sines and cosines; None reads
                       SINUSOID_GAIN
    scalar_seconds     "scalar": how many seconds make one unit of the gap; None reads SCALAR_GAP_SECONDS

    forward(gaps, valid=None): gaps float [...] in seconds (from `gap_seconds`), valid None or bool
    [...]; returns [..., d], zero on padded rows when `valid` is given. A row's vector depends on its
    own gap only. `settings` holds the switches that apply to the kind.

    "ple" cuts the soft log of the gap at the soft logs of the edges. The default edges are round gaps
    (ten seconds, a minute, five minutes, ... ninety days), not even steps of the soft log: their bins
    are 3.2 to 12.1 soft-log units wide (10.6 from ten seconds to a minute, 5.5 from one day to two,
    3.2 from sixty days to ninety). Its edges stay in float32 when the module is cast to 16 bits, and
    the soft log and the shares are formed in 32 bits; only the shares take the 16-bit type.
    """

    def __init__(self, token_dim, kind="scalar", edges_seconds=None, base=None, ticks_per_second=None, gain=None,
                 scalar_seconds=None):
        super().__init__()
        if kind not in KINDS:
            raise ValueError(f"kind must be one of {KINDS}; got {kind!r}")
        d = self.token_dim = int(token_dim)
        self.kind = kind
        if kind == "scalar":
            self.unit = SCALAR_GAP_SECONDS if scalar_seconds is None else float(scalar_seconds)
            # One learned vector and one bias, started as the numeric tokens of numeric_frontend.py start.
            self.weight = nn.Parameter(torch.randn(d) * 0.02)
            self.bias = nn.Parameter(torch.zeros(d))
            self.settings = {"kind": kind, "token_dim": d, "scalar_seconds": self.unit}
        elif kind == "ple":
            edges = [float(e) for e in (GAP_EDGES_SECONDS if edges_seconds is None else edges_seconds)]
            if len(edges) < 2 or any(b < a for a, b in zip(edges, edges[1:])):
                raise ValueError(f"edges_seconds must be two or more increasing gaps in seconds; got {edges}")
            # The edges on the soft-log scale, as the one field of the block. The bins are not even in soft-log units:
            # the edges are round gaps, and their bins are 3.2 to 12.1 units wide. The soft log turns every doubling
            # of a long gap into the same 5.5 units, so one day against two is told apart as finely as six hours
            # against twelve, where on plain seconds the bin from one day to two is four times as wide.
            self.bins = _GapBins([[soft_log(e) for e in edges]], embed_dim=d)
            self.settings = {"kind": kind, "token_dim": d, "edges_seconds": tuple(edges)}
        else:
            if d % 2:
                raise ValueError(f"the sinusoid needs an even token_dim, half sines and half cosines; got {d}. "
                                 f"Build it with token_dim={d + 1}, or {d - 1}")
            self.base = SINUSOID_BASE if base is None else float(base)
            self.ticks_per_second = SINUSOID_TICKS_PER_SECOND if ticks_per_second is None else float(ticks_per_second)
            self.gain = SINUSOID_GAIN if gain is None else float(gain)
            # The layer norm of the paper, on the sines and cosines alone, with a learned scale and shift.
            self.norm = nn.LayerNorm(d)
            self.settings = {"kind": kind, "token_dim": d, "base": self.base, "ticks_per_second": self.ticks_per_second,
                             "gain": self.gain}

    def forward(self, gaps, valid=None):
        """gaps [...] in seconds to [..., d]; padded rows get 0 when `valid` is given."""
        # A gap below zero cannot come from gap_seconds; holding it at 0 keeps every kind defined.
        gaps = gaps.to(torch.float64).clamp(min=0.0)
        if self.kind == "scalar":
            # The logarithm is taken in 64 bits and only its result is brought to the number type of the weights.
            level = torch.log1p(gaps / self.unit).to(self.weight.dtype)
            out = level.unsqueeze(-1) * self.weight + self.bias
        elif self.kind == "ple":
            # The soft log stays in 32 bits at least up to the shares; only they take the type of the weights.
            level = soft_log(gaps).to(_working_type(self.bins.left.dtype))
            out = self.bins(level.unsqueeze(-1)).squeeze(-2)
        else:
            out = self.gain * self.norm(self.wave(gaps))
        if valid is not None:
            # A padded row gets nothing, so that whatever its gap holds cannot reach a real row through stage 2.
            out = out.masked_fill(~valid.bool().unsqueeze(-1), 0.0)
        return out

    def wave(self, gaps):
        """The sines and cosines of the paper before the norm, [sin(theta * t); cos(theta * t)]: [...] -> [..., d]."""
        half = self.token_dim // 2
        # theta_i = base ^ (-2 i / d) radians per tick, i = 0 .. d/2 - 1, worked out in 64 bits for every call so that
        # a cast of the module to 16 bits cannot round the frequencies.
        theta = self.base ** (-2.0 * torch.arange(half, dtype=torch.float64, device=gaps.device) / self.token_dim)
        # The angles are formed in 64 bits as well: a gap of years in milliseconds is too large a number for the 24 bits
        # of a 32-bit float to keep its phase.
        angle = (gaps.to(torch.float64) * self.ticks_per_second).unsqueeze(-1) * theta
        dtype = self.norm.weight.dtype
        return torch.cat([torch.sin(angle), torch.cos(angle)], dim=-1).to(dtype)


# ----------------------------------------------------------------------------------------------
# the clock and the calendar
# ----------------------------------------------------------------------------------------------

def _civil_day(days):
    """The day of the month (1 to 31) and the length of that month (28 to 31) of whole days counted from 1970-01-01.

    The civil-from-days rule of H. Hinnant, in whole-number arithmetic: the days are counted from 1 March
    of the year 0, in eras of 400 years (146,097 days) inside which the calendar repeats exactly; inside
    an era, the year, the day of the year from 1 March, the month and the day follow by whole-number
    division. Every date is exact, before 1970 too, and nothing goes through a float.
    """
    z = days + 719_468                                                    # days from 0000-03-01 to 1970-01-01
    era = torch.div(z, 146_097, rounding_mode="floor")
    day_of_era = z - era * 146_097                                        # 0 .. 146,096
    year_of_era = torch.div(day_of_era - torch.div(day_of_era, 1_460, rounding_mode="floor")
                            + torch.div(day_of_era, 36_524, rounding_mode="floor")
                            - torch.div(day_of_era, 146_096, rounding_mode="floor"), 365, rounding_mode="floor")
    # The day of the year counted from 1 March, 0 .. 365: the leap day, if any, is then the last day of the year.
    day_of_year = day_of_era - (365 * year_of_era + torch.div(year_of_era, 4, rounding_mode="floor")
                                - torch.div(year_of_era, 100, rounding_mode="floor"))
    month_from_march = torch.div(5 * day_of_year + 2, 153, rounding_mode="floor")      # 0 = March .. 11 = February
    month_start = torch.div(153 * month_from_march + 2, 5, rounding_mode="floor")      # its first day of the year
    day_of_month = day_of_year - month_start + 1
    # The same rule gives where the next month starts, so March to January take their lengths from it (31, 30, 31,
    # 30, 31, 31, 30, 31, 30, 31, 31). February is the last month of a year counted from March, and its length is
    # what the year leaves: 29 days when the civil year it falls in is a leap year, 28 otherwise.
    next_start = torch.div(153 * (month_from_march + 1) + 2, 5, rounding_mode="floor")
    civil_year = year_of_era + era * 400 + 1                              # the year of the February that ends it
    leap = ((torch.remainder(civil_year, 4) == 0) & (torch.remainder(civil_year, 100) != 0)) | \
        (torch.remainder(civil_year, 400) == 0)
    february = 28 + leap.to(day_of_year.dtype)
    days_in_month = torch.where(month_from_march == 11, february, next_start - month_start)
    return day_of_month, days_in_month


def _calendar(times, offset_seconds=None, units_per_second=None):
    """The second of the day, the second of the week, the day of the month and the length of its month."""
    times = torch.as_tensor(times)
    offset = LOCAL_TIME_OFFSET_SECONDS if offset_seconds is None else offset_seconds
    local = _seconds(times, units_per_second) + torch.as_tensor(offset, dtype=torch.int64, device=times.device)
    second_of_day = torch.remainder(local, SECONDS_PER_DAY)
    # The week is counted from Monday 00:00; the epoch fell three days after a Monday.
    second_of_week = torch.remainder(local + EPOCH_WEEKDAY * SECONDS_PER_DAY, SECONDS_PER_WEEK)
    day_of_month, days_in_month = _civil_day(torch.div(local, SECONDS_PER_DAY, rounding_mode="floor"))
    return second_of_day, second_of_week, day_of_month, days_in_month


def calendar_parts(times, offset_seconds=None, units_per_second=None):
    """The second of the day, the second of the week from Monday 00:00, and the day of the month.

    times             int64 (or 64-bit float) [...]: times in the unit of the batch, counted from
                      1970-01-01 00:00; the whole second is the one `whole_seconds` of masks.py gives
    offset_seconds    None (LOCAL_TIME_OFFSET_SECONDS), a whole number of seconds, or an integer tensor that
                      broadcasts against `times` (one offset per row)
    units_per_second  how many units of `times` make one second; None reads TIME_UNITS_PER_SECOND

    Returns (second_of_day, second_of_week, day_of_month), int64 of the shape of `times`, on the local
    clock: 0 to 86,399, 0 to 604,799 and 1 to 31. All three come from whole-number arithmetic, so two
    times one week apart give exactly the same second of the week, and two times one day apart exactly
    the same second of the day.
    """
    second_of_day, second_of_week, day_of_month, _ = _calendar(times, offset_seconds, units_per_second)
    return second_of_day, second_of_week, day_of_month


class CalendarEncoder(nn.Module):
    """The clock and the calendar of every row as a vector that is added to the row: [...] -> [..., d].

    token_dim          width d of the vector, the width of the rows it is added to
    hour, weekday      read the hour of the day and the day of the week (both on by default)
    monthday           read the day of the month (off by default), as the share of its own month that has
                       passed, so that the end of every month falls at the same phase
    harmonics          how many multiples of each period are used; None reads CALENDAR_HARMONICS
    hidden             width of the layer between the two linear layers; None reads CALENDAR_HIDDEN
    offset_seconds     seconds added to a stored time to read the local clock; None reads
                       LOCAL_TIME_OFFSET_SECONDS when the encoder is built
    units_per_second   unit of the times; None reads TIME_UNITS_PER_SECOND when the encoder is built

    forward(times, valid=None, offset_seconds=None): times int64 (or 64-bit float) [...]; valid None or
    bool [...]; offset_seconds None (the built offset) or an integer tensor that broadcasts against
    `times`. Returns [..., d], zero on padded rows when `valid` is given. A row's vector depends on its
    own time only.

    The second linear layer starts at zero, so a model that gains the encoder scores exactly as before
    until training moves it; its weights learn from the first step, since their input is not zero.
    """

    def __init__(self, token_dim, hour=True, weekday=True, monthday=False, harmonics=None, hidden=None,
                 offset_seconds=None, units_per_second=None):
        super().__init__()
        self.parts = tuple(name for name, on in (("hour", hour), ("weekday", weekday), ("monthday", monthday)) if on)
        if not self.parts:
            raise ValueError("the calendar encoder reads at least one of hour, weekday and monthday; switch one on")
        self.harmonics = CALENDAR_HARMONICS if harmonics is None else int(harmonics)
        width = CALENDAR_HIDDEN if hidden is None else int(hidden)
        # The offset and the unit are fixed when the encoder is built, as latent_channels.py fixes its unit, so that a
        # later edit of a constant cannot change what a trained encoder reads.
        self.offset_seconds = LOCAL_TIME_OFFSET_SECONDS if offset_seconds is None else int(offset_seconds)
        self.units_per_second = _units(units_per_second)
        self.first = nn.Linear(2 * self.harmonics * len(self.parts), width)
        self.second = nn.Linear(width, int(token_dim))
        nn.init.zeros_(self.second.weight)
        nn.init.zeros_(self.second.bias)
        self.settings = {"token_dim": int(token_dim), "parts": self.parts, "harmonics": self.harmonics,
                         "hidden": width, "offset_seconds": self.offset_seconds,
                         "units_per_second": self.units_per_second}

    def features(self, times, offset_seconds=None):
        """times [...] to the sines and cosines [..., 2 x harmonics x parts], in the order hour, weekday, monthday."""
        offset = self.offset_seconds if offset_seconds is None else offset_seconds
        second_of_day, second_of_week, day_of_month, days_in_month = _calendar(times, offset, self.units_per_second)
        # Where in its cycle every time lies, as a share of the cycle, in 64 bits.
        day = second_of_day.to(torch.float64)
        into_month = (day_of_month - 1).to(torch.float64) * SECONDS_PER_DAY + day
        share = {"hour": day / SECONDS_PER_DAY,
                 "weekday": second_of_week.to(torch.float64) / SECONDS_PER_WEEK,
                 # The share of the month's own length: the last second of every month reads just under a whole
                 # cycle, and the first second of the next month reads 0, whether the month has 28 days or 31.
                 "monthday": into_month / (days_in_month.to(torch.float64) * SECONDS_PER_DAY)}
        multiples = torch.arange(1, self.harmonics + 1, dtype=torch.float64, device=day.device)
        parts = []
        for name in self.parts:
            angle = 2.0 * math.pi * share[name].unsqueeze(-1) * multiples
            parts += [torch.sin(angle), torch.cos(angle)]
        return torch.cat(parts, dim=-1).to(self.first.weight.dtype)

    def forward(self, times, valid=None, offset_seconds=None):
        """times [...] to [..., d]: the calendar features through two linear layers with a GELU between them."""
        out = self.second(F.gelu(self.first(self.features(times, offset_seconds))))
        if valid is not None:
            # A padded row gets nothing, so that whatever time it holds cannot reach a real row through stage 2.
            out = out.masked_fill(~valid.bool().unsqueeze(-1), 0.0)
        return out


# ----------------------------------------------------------------------------------------------
# a look at a small batch
# ----------------------------------------------------------------------------------------------

def _demo():
    """Prints the gaps of a small batch with ties and padding, then the shape of every encoder's result."""
    torch.manual_seed(0)
    # Two sequences in whole seconds: ties in time in the first, three padded slots at the end of the second.
    times = torch.tensor([[0, 5, 5, 9, 20, 20, 21, 40, 41], [3, 3, 4, 8, 9, 12, 0, 0, 0]]) + 1_767_225_600
    valid = torch.tensor([[True] * 9, [True] * 6 + [False] * 3])
    gaps = gap_seconds(times, valid, units_per_second=1)
    print(f"gaps in seconds: {gaps.long().tolist()}")
    for kind in KINDS:
        out = GapEncoder(48, kind=kind)(gaps, valid)
        print(f"{kind:<9} {tuple(out.shape)}, finite: {bool(torch.isfinite(out).all())}")
    clock = CalendarEncoder(48, monthday=True, units_per_second=1)(times, valid)
    print(f"calendar  {tuple(clock.shape)}, finite: {bool(torch.isfinite(clock).all())}")


if __name__ == "__main__":
    _demo()
