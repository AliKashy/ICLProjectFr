"""Numbers as tokens: a log or quantile scale, learned bins, and a table for the risk score.

What this file does
-------------------
It replaces the way a numeric input becomes a token. Today each number is a z-score
multiplied by one weight vector. The file holds the pieces of a finer front end:

    signed_log1p               sign(x) * log(1 + |x|): squeezes large values and keeps the sign
    LogScaler                  signed log, then centred and scaled with training means and spreads
    QuantileScaler             the rank of a value among the training rows, on a roughly normal scale
    quantile_edges             bin edges that give every bin the same share of the training rows
    tree_edges                 bin edges where the fraud rate changes (a shallow tree per field)
    PiecewiseLinearEmbedding   a value becomes "how far through each bin", then a linear map to a token
    ScoreTableEmbedding        an integer risk score from 0 to 99: a lookup row plus a linear term
    amount_flags               cents part, whole-dollar and round-amount flags, small-amount bucket
    NumericFrontEnd            [N, C] numbers in, [N, C, d] tokens out: linear term, bins, score table
    fit_front_end, scale_numbers   fit all of it on training rows; apply it to any rows

Why it exists
-------------
Amounts, balances and limits spread over several orders of magnitude: most rows are small
and a few are very large. On a raw z-scale the few large values set the spread, so nearly
every row sits in a thin sliver next to the mean. The step from a one-dollar to a
five-dollar purchase, which matters when a card is being tried out, is then a tiny fraction
of the scale, and one weight vector times such a value cannot tell the two apart. A raw
scale hides small amounts. A log or quantile scale spreads the rows out evenly. Bins then
let a small model resolve amounts finely: every bin owns a direction in the token, so the
token can bend at every edge instead of being one straight line through the whole range.
The risk score is an integer with few values whose meaning need not be evenly spaced, so
every value gets a row of its own, and a linear term keeps neighbouring scores close. The
cents and round-amount flags keep the fine structure that every scale and every bin
smooths away. A downstream tree model gains a vector that separates small amounts and
single score values instead of one that blurs them.

A tree screen cannot test a rescaling. A tree splits on the order of the values, and a log
or a quantile map keeps the order, so a tree model gives the same answer before and after;
it ignores the change. The only test is a training run of the network: the plain z-score
against the log scale with the linear term alone, against the log scale with bins.

Where it goes
-------------
Preprocessing and tokenizer. The scaler and the bin edges are fitted once on training rows
and stored with the model; they take the place of the step that standardises the numeric
columns in the per-file encoding (`SequenceBuilder._encode_file` in the original code).
`NumericFrontEnd` replaces the numeric half of the field tokenizer: in the original
`FeatureTokenizer.forward` it stands in for
`continuous.unsqueeze(-1) * self.cont_weight + self.cont_bias`. The code-field half stays as
it is; `amount_flags` gives it a few extra code fields.

What to change for the pod
--------------------------
settings.py: NUMERIC_COLS (the numeric inputs of the model in use), VISA_SCORE_COL, AMOUNT_COL,
LABEL_COL, POSITIVE_LABEL and EMBED_DIM. In this file: N_BINS, N_QUANTILES, SCORE_VALUES,
ROUND_AMOUNTS and SMALL_AMOUNT_EDGES. A numeric column that is really a code (a number that
names something, a limit that takes a handful of values) belongs with the code fields. An
input that is computed after the per-file encoding (the time gap to the previous row, for
example) is not a column of the table: append a row of edges for it, from `quantile_edges`
on a sample of its values, or a row of equal numbers, which leaves that field with the
linear term alone. The scaler and the edges must come from training files only:
label-aware edges fitted on rows that are later scored would carry the labels of those
rows into the inputs. A model trained on z-scores cannot read the new scale; the weights
have to be trained again.

The file also runs from a folder of its own, next to the other files of the kit, with only
numpy and torch installed. It then cannot read the package's settings.py, so FLAT_EMBED_DIM
below gives the token width and fit_front_end takes the column names as arguments. pandas,
scipy and scikit-learn are imported only inside the functions that need them: reading a
table (`_numbers`), the normal curve of QuantileScaler and the tree of `tree_edges`.

How to try it
-------------
    fitted = fit_front_end(train_df)                       # scaler state, bin edges, column list
    x = scale_numbers(df, fitted)                          # float32 [rows, C]; the risk score stays raw
    front = NumericFrontEnd(len(fitted["columns"]), fitted["edges"], score_index=fitted["score_index"])
    tokens = front(torch.as_tensor(x))                     # [rows, C, d]
    scaler = scaler_from_state(saved_state)                # "log", "quantile" or "unit_quantile" (numeric_encoders.py)
    python -m pytest -q additions/tests/test_encoding_numeric_frontend.py   # package only
"""
from types import SimpleNamespace

import numpy as np
import torch
import torch.nn as nn

# PLACEHOLDER: the width of a field token of the model in use, read only where the package's settings.py cannot be
# imported (this file in a folder of its own); inside the package settings.EMBED_DIM holds it.
FLAT_EMBED_DIM = 48

try:                                    # inside the package
    from .. import settings
except ImportError:
    try:                                # the package on the path, this file run on its own
        from additions import settings
    except ImportError:                 # the files side by side in one folder, without the package
        # Only the names this file reads. No column of the table is known without settings.py, so fit_front_end then
        # needs its columns as arguments; the token width falls back to the width of the model in use.
        settings = SimpleNamespace(EMBED_DIM=FLAT_EMBED_DIM, NUMERIC_COLS=(), VISA_SCORE_COL=None, LABEL_COL=None,
                                   POSITIVE_LABEL=1)

# PLACEHOLDER: the number of bins per numeric field; 16 to 32 suit a token of a few dozen numbers.
N_BINS = 32

# PLACEHOLDER: the number of steps of the quantile scale; more steps follow the training rows more closely.
N_QUANTILES = 257

# PLACEHOLDER: how many values the risk score can take; 100 stands for the whole numbers 0 to 99.
SCORE_VALUES = 100

# PLACEHOLDER: the round-amount flags as (name, step in cents), for a currency with two decimals.
ROUND_AMOUNTS = (("whole_dollar", 100), ("round_5", 500), ("round_100", 10_000))

# PLACEHOLDER: the dollar cut points of the small-amount bucket; card testing sits below the first ones.
SMALL_AMOUNT_EDGES = (1.0, 2.0, 5.0, 10.0)


# ----------------------------------------------------------------------------------------------
# scales (numpy, fitted on training rows)
# ----------------------------------------------------------------------------------------------

def signed_log1p(values):
    """sign(x) * log(1 + |x|), for a numpy array or a torch tensor of any shape.

    The logarithm turns "ten times larger" into "one step further", which is how amounts
    differ. The sign is kept so that credits and negative balances stay on their own side,
    and adding one keeps zero at zero. A missing value stays missing.
    """
    if torch.is_tensor(values):
        return torch.sign(values) * torch.log1p(values.abs())
    values = np.asarray(values, dtype=np.float64)
    return np.sign(values) * np.log1p(np.abs(values))


def _matrix(values):
    """The input as a float64 array [N, C]; a single column [N] becomes [N, 1]."""
    values = np.asarray(values, dtype=np.float64)
    return values[:, None] if values.ndim == 1 else values


class LogScaler:
    """Signed log, then centred and scaled with the mean and the spread of the training rows.

    fit(values)         values [N, C]: training rows only; missing values are left out
    transform(values)   [N, C] in, float32 [N, C] out; a missing value stays missing
    state()             plain arrays {"kind", "mean" [C], "std" [C]}; `scaler_from_state` reads them back

    This is the plain control for every finer encoding: the same linear token as today, on a
    scale where small amounts are no longer squeezed together.
    """

    def __init__(self):
        self.mean = None
        self.std = None

    def fit(self, values):
        """Learn the mean and the spread of the signed log on training rows [N, C]; returns the scaler itself."""
        logged = signed_log1p(_matrix(values))
        ok = np.isfinite(logged)
        n = np.maximum(ok.sum(axis=0), 1)
        self.mean = np.where(ok, logged, 0.0).sum(axis=0) / n
        std = np.sqrt((np.where(ok, logged - self.mean, 0.0) ** 2).sum(axis=0) / n)
        # A field that never varies gets a spread of one, so its scaled value is zero and not rounding
        # noise divided by nearly nothing. "Never varies" is judged against the size of the mean.
        self.std = np.where(std > 1e-9 * np.maximum(1.0, np.abs(self.mean)), std, 1.0)
        return self

    def transform(self, values):
        """Scale values [N, C] to float32 [N, C]; a missing value stays missing."""
        return ((signed_log1p(_matrix(values)) - self.mean) / self.std).astype(np.float32)

    def state(self):
        """The fitted numbers as plain arrays, to be saved beside a checkpoint."""
        return {"kind": "log", "mean": self.mean, "std": self.std}


class QuantileScaler:
    """The rank of a value among the training rows, mapped to a roughly normal scale.

    fit(values)         values [N, C]: training rows only; missing values are left out
    transform(values)   [N, C] in, float32 [N, C] out; a missing value stays missing
    state()             plain arrays {"kind", "probs" [Q], "quantiles" [C, Q]}

    `quantiles[c, q]` is the value of field c below which a share `probs[q]` of the training
    rows lies. A new value is placed between those stored values, which gives its share, and
    the share is read on the normal curve: the median becomes 0 and the top percent about
    +2.3. Whatever the shape of the raw field, the network sees the same bell shape, and no
    single huge value can stretch the scale.
    """

    def __init__(self, n_quantiles=None):
        self.n_quantiles = N_QUANTILES if n_quantiles is None else int(n_quantiles)
        self.probs = None
        self.quantiles = None

    def fit(self, values):
        """Learn the quantile table of every field on training rows [N, C]; returns the scaler itself."""
        values = _matrix(values)
        self.probs = np.linspace(0.0, 1.0, self.n_quantiles)
        self.quantiles = np.zeros((values.shape[1], self.n_quantiles))
        for c in range(values.shape[1]):                 # one pass per field, never per row
            col = values[:, c]
            col = col[np.isfinite(col)]
            if len(col):
                self.quantiles[c] = np.quantile(col, self.probs)
        return self

    def transform(self, values):
        """Place values [N, C] on the roughly normal scale, float32 [N, C]; a missing value stays missing."""
        # scipy is read here and nowhere else in the file, so the file imports where scipy is not installed.
        from scipy.special import ndtri

        values = _matrix(values)
        out = np.full(values.shape, np.nan, dtype=np.float32)
        # The two ends are held half a step inside 0 and 1. A value beyond every training value
        # then lands at a finite point (about 2.9 either side of zero with 257 steps), not at infinity.
        edge = 0.5 / (self.n_quantiles - 1)
        for c in range(values.shape[1]):
            col = values[:, c]
            ok = ~np.isnan(col)
            xs = self.quantiles[c]
            # A value that many rows share (a limit of zero, say) covers a whole stretch of shares.
            # Read from the left the table gives the top of that stretch, read from the right the
            # bottom; the mean of the two is its middle, where the heap of equal values belongs.
            up = np.interp(col[ok], xs, self.probs)
            down = -np.interp(-col[ok], -xs[::-1], -self.probs[::-1])
            out[ok, c] = ndtri(np.clip(0.5 * (up + down), edge, 1.0 - edge))
        return out

    def state(self):
        """The fitted numbers as plain arrays, to be saved beside a checkpoint."""
        return {"kind": "quantile", "probs": self.probs, "quantiles": self.quantiles}


def scaler_from_state(state):
    """Rebuild a fitted scaler from the plain arrays that its `state()` returned.

    The kind of the state picks the scaler: "log" (LogScaler), "quantile" (QuantileScaler) or
    "unit_quantile" (UnitQuantileScaler of numeric_encoders.py, the [0, 1] scale that the numeric
    encoders of that file read). Any other kind is a plain error that names the three.
    """
    kind = str(state["kind"])
    if kind == "unit_quantile":
        # Imported here and not at the top: numeric_encoders.py imports this file, so a top-level import would go round
        # in a circle. The three branches are the three places the two files can sit.
        try:                            # inside the package
            from .numeric_encoders import UnitQuantileScaler
        except ImportError:
            try:                        # the package on the path, this file run on its own
                from additions.encoding.numeric_encoders import UnitQuantileScaler
            except ImportError:         # the files side by side in one folder
                from numeric_encoders import UnitQuantileScaler
        return UnitQuantileScaler.from_state(state)
    if kind == "quantile":
        scaler = QuantileScaler(len(state["probs"]))
        scaler.probs = np.asarray(state["probs"], dtype=np.float64)
        scaler.quantiles = np.asarray(state["quantiles"], dtype=np.float64)
        return scaler
    if kind == "log":
        scaler = LogScaler()
        scaler.mean = np.asarray(state["mean"], dtype=np.float64)
        scaler.std = np.asarray(state["std"], dtype=np.float64)
        return scaler
    # An unknown kind used to fall through to the log scale and fail later on a missing key; saying so here is clearer.
    raise ValueError(f"the scaler state has kind {kind!r}; scaler_from_state reads 'log', 'quantile' and "
                     f"'unit_quantile'. Pass the dict that the scaler's own state() returned")


# ----------------------------------------------------------------------------------------------
# bin edges (numpy, fitted on training rows)
# ----------------------------------------------------------------------------------------------

def _pad(found, size):
    """`found` (increasing, distinct) made `size` long by repeating its last value.

    Every field needs the same number of edges to fit one array. The repeated edges make bins
    of zero width, which the embedding switches off.
    """
    return np.concatenate([found, np.full(size - len(found), found[-1])])


def quantile_edges(values, n_bins=None):
    """Bin edges that give every bin the same share of the training rows, per field.

    values   [N, C] training rows on the scale the network will see (after the scaler)
    n_bins   bins per field (default N_BINS)

    Returns float32 [C, n_bins + 1], never decreasing along a row. Equal shares put the edges
    where the rows are: many narrow bins among the small amounts, a few wide ones in the tail.
    A field with few distinct values gets fewer real bins and the rest have zero width.
    """
    values = _matrix(values)
    n_bins = N_BINS if n_bins is None else int(n_bins)
    edges = np.zeros((values.shape[1], n_bins + 1), dtype=np.float32)
    for c in range(values.shape[1]):                     # one pass per field
        col = values[:, c]
        col = col[np.isfinite(col)]
        found = np.unique(np.quantile(col, np.linspace(0.0, 1.0, n_bins + 1))) if len(col) else np.zeros(1)
        edges[c] = _pad(found, n_bins + 1)
    return edges


def tree_edges(values, labels, n_bins=None, min_leaf_share=0.002, max_rows=2_000_000, seed=0):
    """Label-aware bin edges: per field, the split points of a shallow decision tree.

    values           [N, C] training rows on the scale the network will see
    labels           [N] 1 on fraud rows and 0 on the others, of the same training rows
    n_bins           the largest number of bins per field (the tree gets that many leaves)
    min_leaf_share   every bin holds at least this share of the rows
    max_rows         a field with more rows is fitted on a random sample of this size

    Returns float32 [C, n_bins + 1] in the form of `quantile_edges`. The tree cuts a field
    where the fraud rate changes most, so the bins are narrow where the label moves and wide
    where it does not. Frauds are rare; they are weighted up to the weight of all other rows,
    or the tree would place its cuts by the non-fraud rows alone. A field in which the tree
    finds no cut keeps its quantile edges.

    The labels are read here to place edges, exactly as training reads them to set weights.
    That is only sound on training rows: the edges are frozen afterwards and applied
    unchanged to every other row. The floor on the bin size keeps an edge from being drawn
    round a handful of frauds, which would be memorising them.
    """
    # scikit-learn is read here and nowhere else in the file, so the file imports where it is not installed.
    from sklearn.tree import DecisionTreeClassifier

    values = _matrix(values)
    labels = np.asarray(labels).astype(np.int64)
    n_bins = N_BINS if n_bins is None else int(n_bins)
    edges = quantile_edges(values, n_bins)
    rng = np.random.default_rng(seed)
    for c in range(values.shape[1]):                     # one small tree per field
        rows = np.flatnonzero(np.isfinite(values[:, c]))
        if len(rows) > max_rows:
            rows = rng.choice(rows, max_rows, replace=False)
        x, y = values[rows, c], labels[rows]
        if n_bins < 2 or len(rows) == 0 or y.min() == y.max():
            continue                                     # one bin, no row or one class only: nothing to split
        tree = DecisionTreeClassifier(max_leaf_nodes=n_bins, class_weight="balanced", random_state=0,
                                      min_samples_leaf=max(1, int(min_leaf_share * len(rows))))
        tree.fit(x[:, None], y)
        cuts = tree.tree_.threshold[tree.tree_.feature >= 0]          # leaves carry no cut
        if len(cuts):
            edges[c] = _pad(np.unique(np.concatenate(([x.min()], cuts, [x.max()]))), n_bins + 1)
    return edges


# ----------------------------------------------------------------------------------------------
# network blocks (torch)
# ----------------------------------------------------------------------------------------------

class PiecewiseLinearEmbedding(nn.Module):
    """A value becomes "how far through each bin", then a linear map makes the token.

    edges       [C, B + 1] bin edges per field, from `quantile_edges` or `tree_edges`
    embed_dim   width d of a token (default settings.EMBED_DIM)
    zero_init   True starts the map at zero, so the block adds nothing until it has learned

    forward(x): x [..., C] finite values on the scale of the edges; returns [..., C, d].

    For a value x and a bin from `left` to `right` the share is 0 when x is below the bin,
    1 when x is above it, and (x - left) / (right - left) inside it. A value in the fifth bin
    therefore reads 1, 1, 1, 1, part, 0, 0, ... Every bin has its own weight vector, so the
    token moves in a new direction each time x crosses an edge: a piecewise-linear curve
    through token space, fine where the bins are narrow. Values beyond the outermost edges
    are held at the ends; how far out they are is left to the linear term of the front end.
    """

    def __init__(self, edges, embed_dim=None, zero_init=False):
        super().__init__()
        embed_dim = settings.EMBED_DIM if embed_dim is None else int(embed_dim)
        edges = torch.as_tensor(np.asarray(edges), dtype=torch.float32)
        # Buffers, not weights: the edges are fixed by the training rows and travel with the model.
        self.register_buffer("left", edges[:, :-1].clone())
        self.register_buffer("width", (edges[:, 1:] - edges[:, :-1]).clone())
        n_fields, n_bins = self.left.shape
        self.weight = nn.Parameter(torch.zeros(n_fields, n_bins, embed_dim))
        self.bias = nn.Parameter(torch.zeros(n_fields, embed_dim))
        if not zero_init:
            nn.init.normal_(self.weight, std=0.02)

    def encode(self, x):
        """x [..., C] to shares [..., C, B] between 0 and 1; a bin of zero width always gives 0."""
        real = self.width > 0
        # A bin of zero width is divided by one, not by zero, and its share is then set to 0.
        share = (x.unsqueeze(-1) - self.left) / torch.where(real, self.width, torch.ones_like(self.width))
        return share.clamp(0.0, 1.0) * real

    def forward(self, x):
        """x [..., C] to tokens [..., C, d]: the bin shares times the learned weights, plus a bias."""
        return torch.einsum("...cb,cbd->...cd", self.encode(x), self.weight) + self.bias


class ScoreTableEmbedding(nn.Module):
    """A token for an integer risk score: one lookup row per value plus a linear term.

    embed_dim   width d of a token (default settings.EMBED_DIM)
    n_values    how many values the score takes (default SCORE_VALUES: the integers 0 to 99)
    zero_init   True starts the lookup rows at zero, so the token starts as the linear term alone

    forward(score): raw scores [...] as floats (missing allowed); returns [..., d].

    The lookup row lets a single value mean something of its own: a score of 0 can stand
    for "not scored", and the step from 90 to 95 can matter more than the step from 40 to
    45. The linear term carries the order, so a value that is rare in training still lands
    between its neighbours. A missing score reads a row of its own, the last one.
    """

    def __init__(self, embed_dim=None, n_values=None, zero_init=True):
        super().__init__()
        embed_dim = settings.EMBED_DIM if embed_dim is None else int(embed_dim)
        self.n_values = SCORE_VALUES if n_values is None else int(n_values)
        self.table = nn.Embedding(self.n_values + 1, embed_dim)          # the last row: no score
        self.weight = nn.Parameter(torch.empty(embed_dim))
        self.bias = nn.Parameter(torch.zeros(embed_dim))
        nn.init.normal_(self.weight, std=0.02)
        if zero_init:
            nn.init.zeros_(self.table.weight)

    def forward(self, score):
        """score [...] to tokens [..., d]: the lookup row of the value plus a linear term.

        A missing score reads the last row of the table, which stands for "no score".
        """
        score = score.to(self.weight.dtype)
        missing = ~torch.isfinite(score)
        value = torch.where(missing, torch.zeros_like(score), score).clamp(0, self.n_values - 1)
        row = torch.where(missing, torch.full_like(value, self.n_values), value.round()).long()
        # The linear term reads the score on a scale from -1 to 1; a missing score reads 0, the middle.
        unit = torch.where(missing, torch.zeros_like(value), value / (self.n_values - 1) * 2.0 - 1.0)
        return self.table(row) + unit.unsqueeze(-1) * self.weight + self.bias


class NumericFrontEnd(nn.Module):
    """Turns [N, C] numbers into [N, C, d] tokens; replaces the numeric half of a field tokenizer.

    n_features    C, the number of numeric fields
    edges         [C, B + 1] bin edges, or None for the linear term alone
    embed_dim     width d of a token (default settings.EMBED_DIM)
    score_index   the position of the integer risk score among the C fields, or None
    n_score_values   how many values the risk score takes (default SCORE_VALUES)

    forward(x): x [..., C]. Every field is on the scale of its scaler, except the field at
    `score_index`, which holds the raw score. Returns [..., C, d], fields in the input order.

    The token of a field is  x * weight + bias  (what the tokenizer computes today)  plus the
    bins. The bins start at zero: at the first step the block gives exactly the linear token
    and the bins grow only as far as the data asks. With `edges=None` and no score field the
    block is the old tokenizer on a new scale, which is the control arm. A missing value is
    read as 0, the centre of the scale, as a mean-filled z-score is today; whether a value was
    missing is carried by the model's own is-missing code fields.
    """

    def __init__(self, n_features, edges=None, embed_dim=None, score_index=None, n_score_values=None):
        super().__init__()
        embed_dim = settings.EMBED_DIM if embed_dim is None else int(embed_dim)
        self.weight = nn.Parameter(torch.empty(n_features, embed_dim))
        self.bias = nn.Parameter(torch.zeros(n_features, embed_dim))
        nn.init.normal_(self.weight, std=0.02)
        self.bins = None if edges is None else PiecewiseLinearEmbedding(edges, embed_dim, zero_init=True)
        self.score_index = score_index
        self.score = None if score_index is None else ScoreTableEmbedding(embed_dim, n_score_values)

    def forward(self, x):
        """x [..., C] numbers to tokens [..., C, d]; a missing value reads as zero."""
        value = torch.where(torch.isfinite(x), x, torch.zeros_like(x))
        tokens = value.unsqueeze(-1) * self.weight + self.bias
        if self.bins is not None:
            tokens = tokens + self.bins(value)
        if self.score is not None:
            j = self.score_index
            # The score field takes its token from the table. The linear weights and bins of that one
            # position are simply not used; they are a few numbers and get no gradient.
            own = self.score(x[..., j]).unsqueeze(-2)
            tokens = torch.cat([tokens[..., :j, :], own, tokens[..., j + 1:, :]], dim=-2)
        return tokens


# ----------------------------------------------------------------------------------------------
# from a table of rows to the arrays the blocks need
# ----------------------------------------------------------------------------------------------

def _numbers(df, columns):
    """The named columns as a float64 array [rows, len(columns)]; text that is no number becomes missing."""
    # pandas is read here and nowhere else in the file: only the steps that take a table need it.
    import pandas as pd

    return np.column_stack([pd.to_numeric(df[c], errors="coerce").to_numpy(dtype=np.float64) for c in columns])


def fit_front_end(df, numeric_cols=None, scale="log", edges="quantile", n_bins=None, score_col=None,
                  label_col=None, positive_label=None):
    """Fit the scaler and the bin edges on training rows.

    df             training rows (rows of training files only)
    numeric_cols   the numeric inputs (default settings.NUMERIC_COLS)
    scale          "log" for LogScaler or "quantile" for QuantileScaler
    edges          "quantile", "tree" (label-aware, reads the label column) or None for no bins
    score_col      the integer risk score (default settings.VISA_SCORE_COL); pass "" for no score table
    label_col, positive_label   the fraud label (default: settings), read only for edges="tree"

    Returns a dict of plain values: "columns" (the fields that were found, in order), "scaler"
    (the scaler's state), "edges" (float32 [C, n_bins + 1] or None) and "score_index" (the
    position of the risk score among the columns, or None). A column the table does not have
    is skipped with one printed line.
    """
    wanted = [c for c in (settings.NUMERIC_COLS if numeric_cols is None else numeric_cols) if c is not None]
    columns = [c for c in wanted if c in df.columns]
    if not columns:
        # Nothing to fit: say which names were looked for, instead of failing inside numpy on an empty list.
        raise ValueError(f"no numeric column to fit: the table has none of {wanted}. Pass numeric_cols= with the "
                         f"numeric columns of the table (without the package's settings.py no column name is known)")
    if len(columns) < len(wanted):
        print(f"note: the table has no column(s) {[c for c in wanted if c not in df.columns]}; they are skipped")
    raw = _numbers(df, columns)
    scaler = {"log": LogScaler, "quantile": QuantileScaler}[scale]().fit(raw)
    scaled = scaler.transform(raw)
    label_col = settings.LABEL_COL if label_col is None else label_col
    if edges == "tree" and label_col not in df.columns:
        print(f"note: the table has no column '{label_col}'; quantile edges are used instead of label-aware ones")
        edges = "quantile"
    if edges == "tree":
        positive = settings.POSITIVE_LABEL if positive_label is None else positive_label
        found = tree_edges(scaled, (df[label_col] == positive).to_numpy(), n_bins)
    else:
        found = None if edges is None else quantile_edges(scaled, n_bins)
    score_col = settings.VISA_SCORE_COL if score_col is None else score_col
    return {"columns": columns, "scaler": scaler.state(), "edges": found,
            "score_index": columns.index(score_col) if score_col in columns else None}


def scale_numbers(df, fitted):
    """Apply a fitted front end to any rows: float32 [rows, C], ready for `NumericFrontEnd`.

    Every column is put on the fitted scale except the risk score, which is handed over as
    it is because `ScoreTableEmbedding` looks its value up. Nothing is fitted here, so rows
    that are scored are treated exactly like the rows of training.
    """
    raw = _numbers(df, fitted["columns"])
    out = scaler_from_state(fitted["scaler"]).transform(raw)
    if fitted["score_index"] is not None:
        out[:, fitted["score_index"]] = raw[:, fitted["score_index"]]
    return out


# ----------------------------------------------------------------------------------------------
# the fine structure of the amount
# ----------------------------------------------------------------------------------------------

def amount_flags(amounts, round_amounts=None, small_edges=None):
    """Small whole-number codes that keep what a scale and a bin smooth away in an amount.

    amounts        dollars per row, [N]; missing values are allowed and the sign is ignored
    round_amounts  (name, step in cents) per flag (default ROUND_AMOUNTS)
    small_edges    dollar cut points of the small-amount bucket (default SMALL_AMOUNT_EDGES)

    Returns a dict of int64 arrays [N], each one a code field for an embedding table:
      amount_cents          the cents part, 0 to 99, and 100 on a row with no amount
      amount_<name>         1 when the amount is a multiple of the step, else 0
      amount_small_bucket   0 on a row with no amount; 1 below the first cut point, 2 from the first
                            to the second, and so on; the last code means "the last cut point or more"

    "No amount" is a missing or zero amount: a zero-dollar check is not a purchase of a round
    sum. A card that is being tried out is charged small or round sums, a subscription repeats
    to the cent, shopping ends in arbitrary cents. The sizes of the tables come from
    `amount_flag_sizes`. Columns that also look at the account's earlier amounts are built by
    features/novelty_amount.py.
    """
    round_amounts = ROUND_AMOUNTS if round_amounts is None else round_amounts
    small_edges = SMALL_AMOUNT_EDGES if small_edges is None else small_edges
    # Whole cents: comparing amounts exactly needs whole numbers, not decimals.
    whole_cents = np.round(np.abs(np.asarray(amounts, dtype=np.float64)) * 100.0)
    bought = np.isfinite(whole_cents) & (whole_cents > 0)
    cents = np.where(bought, whole_cents, 0).astype(np.int64)
    out = {"amount_cents": np.where(bought, cents % 100, 100)}
    for name, step in round_amounts:
        out[f"amount_{name}"] = (bought & (cents % int(step) == 0)).astype(np.int64)
    cuts = np.round(np.asarray(small_edges, dtype=np.float64) * 100.0).astype(np.int64)
    out["amount_small_bucket"] = np.where(bought, np.searchsorted(cuts, cents, side="right") + 1, 0)
    return out


def amount_flag_sizes(round_amounts=None, small_edges=None):
    """How many rows the embedding table of each `amount_flags` code needs, as {name: size}."""
    round_amounts = ROUND_AMOUNTS if round_amounts is None else round_amounts
    small_edges = SMALL_AMOUNT_EDGES if small_edges is None else small_edges
    sizes = {"amount_cents": 101}
    sizes.update({f"amount_{name}": 2 for name, _ in round_amounts})
    sizes["amount_small_bucket"] = len(small_edges) + 2
    return sizes
