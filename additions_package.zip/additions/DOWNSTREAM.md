# Downstream value: what the model adds for other models, and how to show it

This file lists the experiments that show what the model is worth to others: as one score in
a blend, as columns in another team's model, as a vector that several consumers can reuse,
and as rules and tables for fraud operations. They are in the order in which they are worth
running. Each entry names the file of this package that runs it, what it needs, and how it
can mislead.

Three models appear throughout: **the tree model** (a tree model that already runs), **the
other sequence model** (a second model that reads account histories, built by another team)
and **this model**. A score file is a parquet file with the id, account, time, label, amount
and score columns named in `settings.py`.

## Four rules before any number is quoted

1. **Out of sample for every model.** A model scored on rows it trained on looks sharper than
   it is. A blend or a tree fitted on such rows leans on that model, and the lean does not
   carry over to new rows. Each model has its own list of training files; the role of every
   file is written down before anything is fitted. Rows that no model trained on are the only
   safe ground for fitting a consumer.
2. **Against the best set without the new model.** A blend nearly always beats each of its
   members. What the new model is worth is the blend with it against the blend without it.
3. **An interval with every gain, and one decision on fresh rows.** The alert budget is a
   small share of rows, so capture moves with a handful of frauds. A gain is read with the
   paired account bootstrap; whatever was chosen on one group of rows is read once on rows
   that played no part in the choice. `proof/noise_budget.py` says how small a gain a given
   number of frauds can show.
4. **Whole accounts where history matters.** Blends and the row-level comparison work on any
   rows the models share. Everything that looks at an account's earlier rows (the run
   scorecard, the history slices, the account state, the sticky rule) needs every row of the
   account, so it needs score files of whole files, not of sampled rows.

## Step 1. What the score adds in a blend

    python additions/proof/blend_ladder.py --preds tree.parquet other.parquet this.parquet \
        --names tree other this --reference tree other --folds 10 --out blends.parquet

The tool fits a logistic blend for every set of two or more models on some accounts and reads
it on the others (a model alone is read on its own score). Three lines carry the result:

- in "What each model adds", the line `this` added to `tree + other`: what this model adds
  to the models that already run;
- in "Every set against the reference", the line `tree + this`: whether this model or the
  other sequence model is the better partner for the tree model;
- the control line (the reference plus a column of random numbers): what one more weight and
  the breaking of tied scores are worth when the added column knows nothing. A real gain is
  clear of it.

A second fit of one of the models, given as one more score file, is the other useful control:
it shows what plain averaging of two fits of the same model is worth.

To read a choice once on fresh rows, the weights are frozen and applied to a second group of
score files, and the frozen blends are compared like any two models (with `--start` and
`--end` when the second group lies in another month). The `--out` file of the first command
holds blended columns keyed by id, not a score file; the files in the `--apply-out` folder are
score files:

    python additions/proof/blend_ladder.py --preds tree.parquet other.parquet this.parquet \
        --names tree other this --reference tree other --form logit --kinds logit logit logit \
        --apply-preds tree_new.parquet other_new.parquet this_new.parquet --apply-out frozen
    python additions/proof/head_to_head.py \
        --preds frozen/blend__tree__other__this.parquet frozen/blend__tree__other.parquet \
        --names all_three without_this

What it can mislead on: a member that is in sample on these rows (rule 1); a gain smaller
than the rows can show (rule 3); a blend that needs every member at serving time, which is a
cost the capture figure does not show.

## Step 2. Where the model wins

    python additions/proof/diagnosis.py --preds this.parquet other.parquet tree.parquet \
        --names this other tree --raw-base <folder of raw files> --raw-files 8228-8243 --out slices.parquet
    python additions/proof/run_scorecard.py --preds this.parquet tree.parquet --names this tree \
        --raw-base <folder of raw files> --raw-files 8228-8243 --gap-days 7 --out runs.parquet
    python additions/proof/head_to_head.py --preds this.parquet other.parquet tree.parquet \
        --names this other tree

- `diagnosis.py`: the frauds only one model catches, the capture by slice (first fraud of a
  run or a later one, amount, card present, length of history) and a tree that names where
  two models differ. A frozen blend from the `--apply-out` folder of step 1 can be passed as
  one of the files, beside the other models' files of the same second group.
- `run_scorecard.py`: fraud runs caught at all, capture of the first fraud of a run, how
  early in a run the first catch comes, fraud dollars after the first catch.
- `head_to_head.py`: capture at several budgets, non-fraud alerts per fraud alert, and the
  preset sensitivity reads.
- `reads/eligible_rows.py`: the share of this model's alerts that falls on rows that can
  never carry a fraud label.

The slices and the scorecard follow rule 4. Slicing a group of rows and then making the claim
on the same rows makes the claim a post-hoc one: slice on one group, claim on another.

## Step 3. Dollars and operating rules

    python additions/reads/amount_tilt.py --pred this_choose.parquet --report this_report.parquet \
        --score-kind logit --max-udr-loss 0.01
    python additions/reads/lock_on.py --choose this_choose.parquet --report this_report.parquet --score-kind logit

- `amount_tilt.py`: one ranking for frauds and for dollars. It trades frauds caught for
  dollars caught with one number, chosen on one file and reported on another. The same tilt
  is applied to every model that is compared, a blended score included.
- `lock_on.py`: a bonus for rows that follow a high-scoring row of the same account, with the
  alert budget kept fixed. It needs no retraining, only the time of the account's last alert.

## Step 4. The model's outputs as columns for a tree model

One scoring pass writes the score and two vectors per row: the stage-1 vector (one
transaction alone) and the vector that enters the head. `exports/stage1_hook.py` captures
both without changing the model. Its setting `SUMMARY_INDEX` has to match the model: the
position (or positions) of the summary token when stage 1 returns one entry per token, and
`None` when stage 1 already returns one vector per transaction, as an encoder with several
joined summary tokens usually does. In a model with a block between the history stage and
the head, the export says which vector was taken: the one before that block or the one after.

Three groups of rows are kept apart: one to fit the probes and directions of the bundle, one
to fit the consumer, one to read it. None of them may hold rows a model in the comparison
trained on.

    python additions/exports/bundle.py --fit-export probe_block.parquet --save-fitted bundle_fit.json \
        --export consumer_fit_export.parquet --out bundle_fit.parquet
    python additions/exports/bundle.py --fitted bundle_fit.json --export consumer_read_export.parquet \
        --out bundle_read.parquet
    python additions/exports/consumer_margin.py --fit consumer_fit.parquet --read consumer_read.parquet \
        --other-col <tree model's score column> --other-kind logit \
        --bundle-columns s_txn s_ctx p_acct_24h p_acct_7d s_val --out arms.parquet

The consumer tables (`consumer_fit.parquet`, `consumer_read.parquet`) are the export rows
with the bundle columns and the tree model's score joined by transaction id beforehand.

- `consumer_margin.py` enters both scores through the base margin and lets trees learn
  corrections from the other columns. Its arms are the tree model alone, the two-score blend,
  and the blend with the bundle columns. `--base-columns` adds columns that every arm may
  use, which is how another model's own columns are given the same form; pointing
  `SCORE_COL` at another model's score puts that model in this model's place for a
  like-for-like run.
- `after_model/score_state.py` builds the account risk state from this model's own earlier
  scores (highest score in the last hour, day, week; alerts so far; time since the last
  one). No label is used. `after_model/oracle_ladder.py` sizes the idea first, for
  measurement only.
- `after_model/family_screen.py` asks, family by family, what a tree still sees on top of a
  score. To screen on top of a blend, the blended score is written into the score column.
- `after_model/second_stage.py` fits a tree on all rows and a specialist on the rows just
  above and below the cut.
- `exports/release_gates.py` checks that the exported columns look the same in two periods.
- `exports/soft_labels.py` lets a tree model learn from this model's score without running
  it. It helps only where this model is ahead of the student.

With a block that lets the scored row read its own fields again after history, the
difference between the model's score and the no-history probe is no longer "what history
added" alone; the column is better described as "beyond the no-history probe".

## Step 5. The vector as an asset for several consumers

    python additions/exports/probe_suite.py --export export.parquet --other-prefix other_ \
        --label-shares 1 0.3 0.1 0.03 --second export_next_checkpoint.parquet --out probes.parquet

`exports/probe_suite.py` fits linear probes on the frozen columns. Every row is read by a fit
that never saw its account. The other model's columns are joined to the export table by
transaction id beforehand and named by their prefix. Three reads are printed:

- **One vector, several targets.** A fraud now, the first fraud of a run, another fraud of
  the account within 24 hours and within 7 days, and the bank's own decline, each for four
  sets of columns: this model's score alone, its vector, the other model's columns, and the
  vector with the other model's columns. On the fraud target the vector and the score are
  close when the head is one linear layer, because the head already is such a probe; the
  other targets are where a vector shows more than its score.
- **Fewer labels.** The same rows, read by probes fitted on a shrinking share of the fit
  accounts: how many labelled frauds a new consumer needs with each set of columns.
- **From one checkpoint to the next.** With `--second` (the same rows exported from another
  checkpoint): the share of alerts the two scores have in common, and what a probe fitted
  on the first checkpoint's vector still catches when it reads the second's vector without
  being fitted again. `reads/seed_average.py` gives the spread of the score between fits.

A linear probe says what is easy to read from the columns. A tree consumer can find more;
that is step 4. The remaining uses of the vector:

- **Another sequence model as a consumer.** `exports/phat_writer.py` writes this model's score
  on the earlier rows of every target row in the layout such a reader expects: one call per
  data file, written as `phat_<number>.parquet` after that file's number, rows in the order of
  the reader's file, positions from the oldest to the target row, the target's own slot as a
  plain number. Only rows of strictly earlier seconds are history; a reader whose window also
  holds earlier rows of the same second reads shifted positions there (the file's docstring
  says how to see it).

      python additions/exports/phat_writer.py --pred this_scores.parquet --target-ids reader_rows_42.parquet \
          --fill 0 --with-ids --out phat_42.parquet

  The scores must come from a model that did not train on those rows.
- **A state per account.** `after_model/account_state_vectors.py` keeps faded sums of the
  stage-1 vectors per account, readable at any moment; `after_model/readout_control.py` says
  whether order adds anything on top of them.
- **Serving.** `exports/feature_store.py` holds the exported columns with a valid-from time
  and answers as-of lookups, with a lag for the time a score takes to reach the store.

## Step 6. Products beyond the row score

    python additions/merchant/heat.py --panel-files <many files> --files <target files> \
        --scores this_scores.parquet --out heat.parquet

`merchant/heat.py` turns this model's scores on other accounts into a risk value per
merchant and day, with the row's own account removed and only completed days used.
`merchant/exposure.py` and `merchant/burst_tables.py` are its label-based and intraday
relatives. They need scores on many files, because one file holds few of a merchant's
customers.

## Step 7. One model instead of several

A blend needs every member at serving time. Two ways to keep most of its gain in one model,
both worth a run only after steps 1 and 4 show a gain:

- `training/offset_head.py`: a second head trained on top of the tree model's fixed score, so
  that it learns what that model gets wrong.
- `training/distillation.py`: the blended, out-of-fold probability as a soft target for one
  student. A model taught by another model is no longer an independent challenger, and
  teacher scores on the teacher's own training rows are of no use.

## What each step needs

| Step | Scores of the other models | Rows |
|---|---|---|
| 1 blend | yes, row by row | any rows all models score; fresh rows for the one decision |
| 2 where it wins | yes for the comparison; none for this model's own scorecard | whole files for slices and runs |
| 3 dollars, rules | none | whole files, two groups: choose and report |
| 4 columns | the tree model's score; the other model's columns for the like-for-like arm | three groups no model trained on |
| 5 asset | the other model's columns for the comparison only | whole files no model trained on; the probe tool splits them by account |
| 6 merchant | none | many files |
| 7 one model | the tree model's score on training rows, out of sample for that model | training files |
