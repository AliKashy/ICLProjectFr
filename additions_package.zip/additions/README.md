# Additions for a two-stage transaction fraud model

This folder is a set of ready-made pieces that can be added to a card-fraud model that reads
each account as a sequence of transactions. Every piece is working code with tests on made-up
data. Every piece is one file, and every file explains itself in its own docstring under five
headings: what the file does, why it exists, where it goes, what to change for the pod, and
how to try it.

The code was written against a model with two stages. Stage 1 turns the field tokens of one
transaction into one vector. Stage 2 reads the account's earlier transaction vectors under a
strict time rule. A linear head gives a fraud logit for every row. The measure throughout is
the share of all frauds that fall inside the top 0.6 percent of rows by score, and the same
by dollars.

None of the pieces depends on that model's code. They are meant to be read, changed and
fitted into the code base in use: a model with other inputs, other file names and another
layout. Nothing in this folder checks where it runs or what it runs against, and nothing
refuses to run. Every file can be edited freely; the files depend on each other only through
ordinary imports.

## Where to start

1. `additions/settings.py` holds every name that depends on the data or the machine: column
   names, paths, file ranges, code values and model sizes. Each line to check is marked
   `# PLACEHOLDER:` with one sentence saying what belongs there. Every function also takes
   those names as arguments, so one call can use other names without touching the settings.
2. The tests run from the folder that holds `additions/`:

       python -m pytest -q additions/tests

   They use made-up rows from `common/synthetic.py`, need no real data and no GPU, and each
   test file doubles as a usage example of its module.
3. `additions/SWEEP.md` gives the order in which the pieces are meant to be tried: one
   complete sweep at a small scale (250 training files by default), then whatever holds at
   full scale (1,000 training files by default).
4. `additions/DOWNSTREAM.md` lists the experiments that show what the model adds for other
   models (a blend of scores, columns for a tree model, the vector as an asset, rules for
   operations), in the order in which they are worth running, with the command for each.
5. The index below names every file. The docstring at the top of a file says what has to
   change for it to fit another code base.

A tool runs by path or as a module, and prints its options with `--help`:

    python additions/reads/lock_on.py --help
    python -m additions.reads.lock_on --help

## How the folders are laid out

| Folder | What it holds | Files | Test files |
|---|---|---|---|
| `common/` | Shared helpers that the other folders use: reading files, whole-second time keys, the "strictly earlier rows" engine, the alert cut and capture, the paired bootstrap, made-up rows. | 6 | 1 |
| `reads/` | Reads on scores and files that already exist. No training is needed. | 11 | 11 |
| `features/` | New per-row input columns built from raw transactions, and the catalogue of possible features. | 11 | 11 |
| `encoding/` | How numbers and codes are turned into tokens before stage 1. | 4 | 4 |
| `model/` | Blocks for the network itself, and a compact reference model that wires them together. | 12 | 12 |
| `training/` | Loss terms, row weights, sampling, look-back cuts, weight averaging and teachers. | 11 | 11 |
| `after_model/` | What is built from the model's own scores and vectors after scoring. | 7 | 7 |
| `merchant/` | Tables that carry what other accounts did at the same merchant. | 8 | 8 |
| `exports/` | Columns and tables for other models to consume. | 9 | 9 |
| `proof/` | Tools for comparing models fairly. | 9 | 9 |
| `sweep/` | The testing plan: every arm at a small scale, and the rule for what goes on to full scale. | 3 | 2 |
| `settings.py` | Every name that depends on the data or the machine. | 1 | |
| `tests/` | Small tests on made-up data; they double as usage examples. | | 85 |

## Every file, by folder

The first column is the file. The second is the first line of its docstring. The third is
the place in the pipeline where the piece goes; the file's own docstring says more, and names
the class or method of the original model code as a hint where one applies.

### `common/`

Shared helpers that the other folders use: reading files, whole-second time keys, the "strictly earlier rows" engine, the alert cut and capture, the paired bootstrap, made-up rows.

| File | What it does | Where it goes |
|---|---|---|
| `bootstrap.py` | Paired bootstrap that resamples whole units (accounts, days or clusters). | After scoring, whenever two variants are compared: a new feature against the control, an export arm against its base, one model against another. |
| `history.py` | The "strictly earlier rows" engine. | It is a building block. |
| `ranking.py` | The alert cut and what it catches. | After scoring. |
| `synthetic.py` | Made-up transactions for the tests and the examples. | Only in the tests and in the examples. |
| `tables.py` | Reading and writing parquet files. | It is the first step of every CPU tool: raw rows in, a DataFrame out. |
| `timekeys.py` | Whole-second time keys and stable ordering of rows. | Every history feature, every score state and every sequence of rows starts by calling these functions. |

### `reads/`

Reads on scores and files that already exist. No training is needed.

| File | What it does | Where it goes |
|---|---|---|
| `amount_tilt.py` | The amount tilt: one ranking, moved between frauds caught and dollars caught. | After scoring (scores). |
| `eligible_rows.py` | Capture on the rows the benchmark keeps, and where the alert budget goes. | After scoring (scores), before any comparison with another model. |
| `file_inventory.py` | File inventory: what each raw file holds, and fresh blocks of unused files. | On the raw files, before any scoring: it plans which files are scored for choosing between variants, which for the decision, and which are kept back to confirm. |
| `history_census.py` | History census: how much history the scored rows really have. | On raw files or on a prediction file, before the history length of stage 2 is changed (in the original code the `history_len` given to `SequenceBuilder` and to `FTTransformerHierModel`). |
| `lock_on.py` | Lock-on: does the model stay on an account after its first alert, and a sticky-alert rule. | After scoring (scores), before a second stage is built. |
| `month_token.py` | A calendar input whose scored value was never trained: clamp it, or give it the mean row. | Preprocessing and tokenizer, at scoring time only. |
| `multi_history_average.py` | Several views of each row from one model: score with different history lengths, then average. | After scoring (scores): the same checkpoint is scored several times, each time with another history length, and the prediction files are given to this tool. |
| `run_census.py` | Run census: how frauds cluster on accounts, how they are caught, and how labels arrive. | On raw files or on scores, before design decisions: it is a read that sizes ideas (a memory of the model's own alerts, the use of matured labels, weights by recency). |
| `seed_average.py` | Seed spread, and score averages over several trainings of the same model. | After scoring (scores), on prediction files of several seeds; before any decision that compares two variants, and before a teacher-student training. |
| `_cli.py` | Command-line pieces shared by the tools of this folder. | Only inside the `main` function of each tool in this folder, after scoring. |
| `_rows.py` | Rows of a prediction file: loading, raw columns by id, the scored month and the row type. | After scoring, in front of every tool of this folder: a prediction file and raw files in, one table and a few arrays out. |

### `features/`

New per-row input columns built from raw transactions, and the catalogue of possible features.

| File | What it does | Where it goes |
|---|---|---|
| `asof_audit.py` | As-of audit: was a date or profile column known at the transaction, or written later? | Before any new column becomes an input: raw files in, one table of verdicts out. |
| `exact_match.py` | Exact-match history columns: has this account been at this merchant (category, place) before? | Raw files, then these feature columns, then either the network or a tree model. |
| `geo_velocity.py` | Geographic velocity: how far, and how fast, between consecutive card-present purchases. | Raw files, then these feature columns, then the network (extra numeric inputs, appended in the per-file step that is `SequenceBuilder._encode_file` in the original code, each one a numeric token of `FeatureTokenizer`) or a second-stage tree model. |
| `lookback.py` | The look-back start that keeps training rows and scored rows alike. | Between the raw files and the feature columns. |
| `novelty_amount.py` | Exact-value novelty: the joint template of the code fields, and the fine structure of the amount. | Raw files, then these feature columns, then the network (extra numeric inputs, appended in the per-file step that is `SequenceBuilder._encode_file` in the original code, each one a numeric token of `FeatureTokenizer`) or a second-stage tree model. |
| `outcome_history.py` | Outcome history: what the bank decided on the account's EARLIER rows. | Raw files, then these feature columns, then the network (extra numeric inputs, appended in the per-file step that is `SequenceBuilder._encode_file` in the original code, each one a numeric token of `FeatureTokenizer`) or a second-stage tree model. |
| `possible_features.py` | A catalogue of possible features, in addition to the inputs the model already has. | On the CPU, before training: raw rows in, feature columns out. |
| `ratios.py` | Ratio columns: the amount against what the account holds and against what it usually spends. | Raw files, then these feature columns, then the network (extra numeric inputs, appended in the per-file step that is `SequenceBuilder._encode_file` in the original code, each one a numeric token of `FeatureTokenizer`) or a second-stage tree model. |
| `recurrence_tokens.py` | Recurrence tokens: small codes that let the network see "the same merchant as before". | Raw files, then these codes, then the tokenizer. |
| `surprise.py` | Count-based surprise: how unusual is each value of a row, for this account and for everyone? | Raw files, then these feature columns, then the network (extra numeric inputs, appended in the per-file step that is `SequenceBuilder._encode_file` in the original code, each one a numeric token of `FeatureTokenizer`) or a second-stage tree model. |
| `_shared.py` | Small helpers shared by the feature builders of this folder. | Nowhere by itself. |

### `encoding/`

How numbers and codes are turned into tokens before stage 1.

| File | What it does | Where it goes |
|---|---|---|
| `capped_vocab.py` | A capped vocabulary and a tiered embedding for a field with very many values (a merchant id). | Raw files, then one more code field. |
| `numeric_frontend.py` | Numbers as tokens: a log or quantile scale, learned bins, and a table for the risk score. | Preprocessing and tokenizer. |
| `text_init.py` | A category table that starts from text: description vectors, projected to the token width. | Stage 1, the tokenizer, at the moment the model is built and before the first training step. |
| `unknown_dropout.py` | Unknown-value dropout: make the "unknown" row of every code table a trained state. | Preprocessing and tokenizer, in training only. |

### `model/`

Blocks for the network itself, and a compact reference model that wires them together.

| File | What it does | Where it goes |
|---|---|---|
| `aligned_outcomes.py` | Later rows read what the bank decided on an earlier row; no row reads its own decision. | Raw files, then `outcome_codes` (or the family column of additions/features/outcome_history.py), then stage 2: the layer is the `first_layer` of history_stage.py and takes the place of its first block. |
| `attention_bias.py` | A learned bias on stage-2 attention: same value, time gap, how often. | Raw files, then `match_values` (one integer per row and field, laid out like the batch), then this block, then stage 2: history_stage.py takes the result as `bias` and adds it to the float mask of masks.to_attention_mask. |
| `history_stage.py` | Stage 2 at its own width, under the strict time rule. | After stage 1, before the head. |
| `masks.py` | Who may read whom: the strict time rule as an attention mask. | Stage 2, the attention over the rows of one account. |
| `members.py` | Several members inside one model: shared stage 2, own scaling vector, own head. | Between stage 1 and stage 2 (`expand`), and at the head (`combine`); the loss changes with it (`member_loss`). |
| `merchant_context.py` | What other accounts just did at the row's merchant, pooled into one vector for the head. | A first pass of the model scores every row and exports its vector and score (exports). |
| `profile_encoder.py` | A small encoder for slow account fields, run once per sequence. | Raw files, then the profile values of the FIRST row of every sequence, then this encoder, then stage 2 as a `prefix` (history_stage.py puts it in front of the rows and masks.with_prefix opens it to every row). |
| `reference_model.py` | A compact two-stage model that wires every block of this folder together. | This is a model of its own, not a part of the pipeline. |
| `reread_block.py` | After history, a row reads its own fields once more. | Stage 1 (field-token outputs kept), stage 2, then this block, then the head. |
| `state_prefix.py` | A stored account memory as extra positions in front of the history. | Stage 1 vectors of a frozen first model are stored for every row (exports); `account_state` turns them into the state (after the model); the state as of the first row of each sequence travels with the batch; `StatePrefix` makes the positions; stage 2 takes them as `prefix` (history_stage.py, masks.with_prefix). |
| `summary_tokens.py` | Stage 1 with several summary tokens per transaction. | Preprocessing and tokenizer, then this block, then stage 2. |
| `_shared.py` | Small helpers shared by the model blocks of this folder. | Nowhere by itself. |

### `training/`

Loss terms, row weights, sampling, look-back cuts, weight averaging and teachers.

| File | What it does | Where it goes |
|---|---|---|
| `account_sampling.py` | Account sampling: keep every fraud account and a share of the others. | Raw files, before the sequence builder (in the original code `SequenceBuilder._encode_file`): rows of accounts that are not kept are dropped before chunks are built, and `loss_weight` travels beside the label as one more per-row array. |
| `auxiliary_heads.py` | Auxiliary heads: extra training targets taken from the account's whole timeline. | Raw files, then the loader, then head and loss, then exports. |
| `distillation.py` | Distillation: one model learns from several. | Scores, then head and loss. |
| `lookahead_teacher.py` | A look-ahead teacher: a history stage that may also read the next rows of the account. | Stage 2, then head and loss; for the second look, scores and exports. |
| `lookback_cut.py` | A visibility mask that also limits how far back a row may read, in days. | Stage 2. |
| `loss_masks.py` | Row weights for the loss: rows that can never carry a fraud label teach nothing. | Head and loss, and scores. |
| `next_transaction_heads.py` | Next-transaction heads: predict the next row of the account, and read how unexpected each row was. | Raw files, the loader, head and loss, exports. |
| `offset_head.py` | An offset head: a second fraud head trained on top of another model's fixed score. | Scores, head and loss, exports. |
| `pairwise_top.py` | A small pairwise term aimed at the top of the ranking. | Head and loss. |
| `weight_averaging.py` | Averaged weights: an exponential moving average and a plain running average of a model. | The training loop. |
| `_loss_shared.py` | Small helpers shared by the loss terms and teachers of this folder. | Head and loss. |

### `after_model/`

What is built from the model's own scores and vectors after scoring.

| File | What it does | Where it goes |
|---|---|---|
| `account_state_vectors.py` | The slow account memory: faded sums of each row's stage-1 vector. | Stage 1, then exports, then stage 2. |
| `family_screen.py` | Screens one family of candidate columns at a time on top of the model's own score. | Comparison, on the CPU, after scoring and before a training run. |
| `oracle_ladder.py` | MEASUREMENT ONLY, never shipped: what the true labels of earlier rows would add (an upper bound). | Comparison, on the CPU, after scoring and before any run-state work is started. |
| `readout_control.py` | Three small readouts on exported vectors: does the account's history need a recurrent block? | Comparison, on the CPU, after scoring and exporting, before any work on recurrent blocks or account memories in the network. |
| `score_state.py` | Account risk state from the model's own EARLIER scores. | After scoring (scores), in front of anything that consumes scores: the second stage in second_stage.py, the measurement in oracle_ladder.py, or an export of columns for other models. |
| `second_stage.py` | A tree model on top of the network's out-of-sample scores, and a specialist for the top band. | Second stage, after scoring: the network (stage 1 and stage 2 of the network together, up to the head in `FTTransformerHierModel.forward`) scores every row; this file reads the export files and puts trees on top. |
| `_shared.py` | Pieces shared by the tools of this folder: export tables, month blocks, tree fits, result lines. | Nowhere by itself. |

### `merchant/`

Tables that carry what other accounts did at the same merchant.

| File | What it does | Where it goes |
|---|---|---|
| `burst_tables.py` | Merchant-by-hour tables: is this merchant under attack right now, seen through OTHER accounts? | Raw files, then these tables, then feature columns: extra numeric inputs of the network (appended in `SequenceBuilder._encode_file` in the original code, one numeric token each in `FeatureTokenizer`) or columns of a second-stage tree model, joined by transaction id. |
| `coverage.py` | How merchant columns depend on the share of accounts sampled, and one model for thin and full tables. | Raw files, then nested merchant tables, then feature columns. |
| `covisit_vectors.py` | Merchant vectors learned from inside accounts, and how well a merchant fits the account's habits. | Raw files, then this table, then feature columns. |
| `day_tables.py` | Merchant-by-day tables: what OTHER accounts did at this merchant yesterday, last week, last month. | Raw files, then these tables, then feature columns. |
| `exposure.py` | Compromise-point exposure: did this account recently shop where other accounts later went bad? | Raw files, then these tables, then feature columns. |
| `heat.py` | Merchant heat: how the model's own scores ran on OTHER accounts' earlier rows at this merchant. | After scores. |
| `visa_view.py` | The network's view of a merchant: the network risk score averaged over OTHER accounts there. | Raw files, then these tables, then feature columns. |
| `_panel.py` | Shared steps of the merchant tables: periods, adding tables, sums over other accounts, priors. | Nowhere by itself. |

### `exports/`

Columns and tables for other models to consume.

| File | What it does | Where it goes |
|---|---|---|
| `bundle.py` | The export bundle: named scores, supervised directions and account windows of the score. | After scoring (scores and vectors), before a second stage or another team's model (exports). |
| `consumer_margin.py` | How a downstream tree model should take two scores: through the margin. | Second stage and comparison: after scoring, after the bundle (bundle.py) is built, on the consumer's side. |
| `feature_store.py` | A table of export columns with a valid-from time, and the as-of lookup that reads it. | In the exports, after the export columns are built: bundle.py or phat_writer.py write per-row columns, `build_store` turns them into the store, `write_store` saves it with its manifest, and a consumer calls `asof_lookup` with its own (account, time) pairs. |
| `phat_writer.py` | Earlier-row scores as columns: the model's score on each of the account's latest earlier rows. | After scoring, in the exports. |
| `probe_suite.py` | One vector, several targets: what the exported columns are worth to consumers that do not exist yet. | After the scoring pass that writes scores and vectors (exports), on rows that no model in the comparison trained on. |
| `release_gates.py` | Two checks on export columns before they go to other models: a domain check and a stability index per column. | In the exports, after bundle.py (or any builder of per-row columns) and before the columns are given to consumers. |
| `soft_labels.py` | Soft labels: another team's tree model learns from this model's score without running it. | Exports and second stage: after scoring the other team's training rows with a model that never saw those accounts. |
| `stage1_hook.py` | Capturing the stage-1 vector and the head-input vector of a model with forward hooks. | Stage 1, stage 2 and the head are untouched; the hooks sit on them during the scoring pass that writes scores and vectors (exports). |
| `_shared.py` | Small helpers shared by the export files of this folder. | Nowhere by itself. |

### `proof/`

Tools for comparing models fairly.

| File | What it does | Where it goes |
|---|---|---|
| `blend_ladder.py` | Blend ladder: what each model adds to a blend of several scores, read out of fold. | Comparison, after scoring, on score files of whole accounts that share transaction ids. |
| `block_bootstrap.py` | Other ways to resample: by calendar day and by cluster, and a bar raised for many arms. | Comparison: after scoring, beside every paired read of a candidate against its control (additions/common/bootstrap.py does the resampling; this file only supplies other units). |
| `diagnosis.py` | Diagnosis: where two or three models win and lose, read on the same rows at each model's own cut. | Comparison: after scoring, on score files of whole accounts that share transaction ids (read with `_shared.common_rows`, as in head_to_head.py). |
| `head_to_head.py` | Head-to-head: two or three models compared on the same transactions, counted one way. | Comparison: after scoring, on score files of the same transactions. |
| `noise_budget.py` | Noise budget: what a block of files and a number of seeds can show, before any arm is read. | Comparison: before the reads, when blocks and seeds are chosen, and again beside every decision. |
| `run_scorecard.py` | Run-level scorecard: how early a model enters a fraud run, and what lies after its first alert. | Comparison: after scoring, as a second table beside the row measure. |
| `screening_rule.py` | The order in which ideas are decided: a cheap tree screen first, then one decision for the bundle. | Comparison. |
| `time_consistency.py` | Time consistency of candidate columns: does a column rank fraud the same way later, and does it drift? | Raw files and feature columns, before a column becomes a model input or an export column (features/ and the tokenizer, FeatureTokenizer in the original code), and again as a monitoring read. |
| `_shared.py` | Shared pieces of the comparison tools: score files lined up by id, per-row arrays, fraud runs. | After scoring, in front of every tool of this folder (comparison). |

### `sweep/`

The testing plan: every arm at a small scale, and the rule for what goes on to full scale.

| File | What it does | Where it goes |
|---|---|---|
| `arms.py` | Every experiment of the sweep, one entry each. | Before the sweep: it is the menu. |
| `plan.py` | The sweep as an ordered list of steps, with its cost. | At the start of the sweep. |
| `promote.py` | Which arms held up in the sweep, and what goes on to the full-scale run. | After the sweep's reads. |

## The rules every file keeps

- **The time rule.** A row may use only rows of strictly earlier seconds of the same key
  (the account, or the account and a merchant, and so on). Rows that share a second never see
  each other. `common/history.py` is the engine that every history column, every state and
  every export window is built on, and `model/masks.py` is the same rule as an attention mask.
- **Labels are never inputs.** The fraud label of another row is used only as a training
  target, or in a file whose name and docstring say that it is an upper bound for measurement
  (`after_model/oracle_ladder.py`).
- **Other accounts' activity.** A table that carries what other accounts did removes the row's
  own account from every value and uses only completed earlier periods. The files hold whole
  accounts and only some accounts are read, so a merchant's rows are a sample: such tables
  give rates and means with their counts, pulled toward a prior when few rows are seen.
- **Anything that looks forward in time** is a training target or a training-only teacher,
  never an input, and its docstring says so.
- **Scores used to fit something** (a second stage, a probe, a table of merchant heat) must
  come from a model that did not train on those rows.
- **An optional column** that is `None` in the settings, or absent from the data, makes the
  code skip that part and print one line. It never stops a run.

## Placeholders

`settings.py` holds 61 names. They are, in the order of the file:

`ACCOUNT_COL`, `TIME_COL`, `ID_COL`, `ORDER_COL`, `LABEL_COL`, `POSITIVE_LABEL`, `AMOUNT_COL`,
`VISA_SCORE_COL`, `BALANCE_COL`, `MERCH_LIMIT_COL`, `CASH_LIMIT_COL`, `MERCHANT_COL`,
`MCC_COL`, `MERCHANT_POSTAL_COL`, `MERCHANT_STATE_COL`, `MERCHANT_COUNTRY_COL`, `REASON_COL`,
`DECLINE_FLAG_COL`, `ADVICE_COL`, `TYPE_COL`, `SEGMENT_COL`, `CARD_PRESENT_COL`, `CARD_COL`,
`TERMINAL_COL`, `DEVICE_COL`, `TOKEN_COL`, `IP_COL`, `NUMERIC_COLS`, `CODE_COLS`,
`APPROVED_REASONS`, `RISK_DECLINE_REASONS`, `FUNDS_DECLINE_REASONS`, `DECLINE_FLAG_VALUES`,
`ZERO_CHECK_TYPES`, `EXCLUDED_SEGMENTS`, `TRAIN_BASE`, `EVAL_BASE`, `FILE_NAME`, `FILESYSTEM`,
`TRAIN_FILES`, `CONSUMER_FIT_FILES`, `CONSUMER_READ_FILES`, `CHOOSE_FILES`, `DECIDE_FILES`,
`TRAIN_HISTORY_START`, `EVAL_HISTORY_START`, `TARGET_START`, `TARGET_END`, `OUTSORT_PER_MILLE`,
`OUTSORT_ROUNDING`, `BOOTSTRAP_DRAWS`, `BOOTSTRAP_SEED`, `INTERVAL_PERCENT`, `SCORE_COL`,
`SCORE_KIND`, `VECTOR_PREFIX`, `EMBED_DIM`, `NUM_HEADS`, `STAGE1_BLOCKS`, `STAGE2_BLOCKS`,
`HISTORY_LEN`.

Some files carry a name of their own that is likely to differ on another setup. Each is a
constant or a small function at the top of its file, marked `# PLACEHOLDER:`.

| File | Name | What to put there |
|---|---|---|
| `after_model/_shared.py` | `TREE_PARAMS` | settings of the tree fits; raise the depth and the rounds for exports of many millions of rows, and add "nthread" to use fewer cores than the machine has. |
| `after_model/_shared.py` | `TREE_ROUNDS` | the most trees a fit may grow, and how many rounds without a better held-out value end it. |
| `after_model/_shared.py` | `INNER_SHARE` | the share of the fit accounts that is held out of every tree fit for early stopping. |
| `after_model/account_state_vectors.py` | `STAGE1_PREFIX` | the prefix of the stage-1 (no-history) vector columns in an export file, as exports/stage1_hook.py names them (s1_0, s1_1, ...). They are read when the export has them. |
| `after_model/account_state_vectors.py` | `STATE_PREFIX` | the prefix of the column names written by `build_account_state`. |
| `after_model/account_state_vectors.py` | `CHUNK_ROWS` | how many rows are worked on at once; lower it when memory is short, raise it for speed. One chunk needs a few times rows x half-lives x (dim + 1) x 8 bytes. |
| `after_model/family_screen.py` | `FAMILIES` | the candidate families, as {family name: [column names, or prefixes ending with "*"]}. The examples are the prefixes written by the builders in additions/features/ and by score_state.py. |
| `after_model/family_screen.py` | `PASS_GAIN` | the least gain in the share of frauds caught at the cut for a family to pass. |
| `after_model/family_screen.py` | `STABILITY_FLOOR` | a one-column model must score an AUC above this on the late months to be stable. |
| `after_model/family_screen.py` | `STABILITY_PARAMS` | settings of the small one-column models of the stability check. The small min_child_weight lets a split form on a few hundred rows even when fraud is rare (the weight of a row is p * (1 - p), which is tiny when p is small). |
| `after_model/oracle_ladder.py` | `REPORT_CURVE` | the reporting curve as (days after the transaction, share of fraud labels known by then), with rising days and shares. These numbers are an example only; put the bank's own table here. A last share below 1 means that the remaining labels are never known inside the data. |
| `after_model/oracle_ladder.py` | `REPORT_SEED` | the seed of the draws of report delays; any whole number. |
| `after_model/oracle_ladder.py` | `WORTH_DOING` | the gain of the zero-delay arm (share of frauds caught) below which run-state work is not worth doing. The tool only prints a sentence that compares the measured gain with it. |
| `after_model/oracle_ladder.py` | `NOW_PREFIX` | the prefixes of the label columns. The word "oracle" is in the name on purpose, so that such a column is recognised if it ever turns up among model inputs. |
| `after_model/readout_control.py` | `HISTORY_DAYS` | the shortest and the longest history of a scored row, in days (one to two months when the evaluation files start one month before the scored month). |
| `after_model/readout_control.py` | `HIDDEN` | width of the hidden layers of every readout, and the number of units of the GRU. |
| `after_model/readout_control.py` | `EPOCHS` | training length and batch sizes (rows per batch for a_vector and b_memory, account blocks per batch for c_gru), the learning rate, and the seed. |
| `after_model/readout_control.py` | `POSITIVE_WEIGHT` | the weight of a fraud row in the loss. Fraud is rare, so with weight 1 a batch holds almost no fraud and the readouts learn slowly; a larger weight speeds learning up. It changes the level of the logits, not the order of the rows, and only the order is read here. |
| `after_model/readout_control.py` | `KILL_GAIN` | the gain in the share of frauds caught below which a memory is judged not to pay. |
| `after_model/readout_control.py` | `TORCH_THREADS` | CPU threads torch may use; None leaves torch's own choice. |
| `after_model/score_state.py` | `LATCH_BASELINE_BELOW_CUT` | the latch, in log-odds of the model's score; tune the four numbers on the fit files. |
| `after_model/score_state.py` | `STATE_PREFIX` | the prefixes of the column names written for the account and for the account and card. |
| `after_model/second_stage.py` | `BAND_PER_MILLE` | the width of the specialist's band in rows per thousand of the fit rows (50 is the top 5 percent); the floor of the band is taken once on the fit rows as a fixed logit value. |
| `encoding/capped_vocab.py` | `MIN_ACCOUNTS` | a value needs rows on at least this many different accounts to get a row of its own. |
| `encoding/capped_vocab.py` | `N_FULL` | how many of the busiest kept values get a full-width row. |
| `encoding/capped_vocab.py` | `N_NARROW` | how many of the next busiest values get a narrow row, and the width of a narrow row. |
| `encoding/capped_vocab.py` | `N_SHARED` | the number of shared rows for all other values, and over how many of them the values of one category are spread. |
| `encoding/capped_vocab.py` | `REPLACE_RATE` | the share of training rows on which a value with its own row reads its shared row instead. |
| `encoding/numeric_frontend.py` | `N_BINS` | the number of bins per numeric field; 16 to 32 suit a token of a few dozen numbers. |
| `encoding/numeric_frontend.py` | `N_QUANTILES` | the number of steps of the quantile scale; more steps follow the training rows more closely. |
| `encoding/numeric_frontend.py` | `SCORE_VALUES` | how many values the risk score can take; 100 stands for the whole numbers 0 to 99. |
| `encoding/numeric_frontend.py` | `ROUND_AMOUNTS` | the round-amount flags as (name, step in cents), for a currency with two decimals. |
| `encoding/numeric_frontend.py` | `SMALL_AMOUNT_EDGES` | the dollar cut points of the small-amount bucket; card testing sits below the first ones. |
| `encoding/text_init.py` | `DESCRIPTIONS_PATH` | the file that holds one description per code value (csv or parquet), or None. |
| `encoding/text_init.py` | `DESCRIPTION_CODE_COL` | the column of that file that holds the code value, and the one that holds its text. |
| `encoding/text_init.py` | `TEXT_DIM` | the length of a stand-in text vector; a real text encoder sets its own length. |
| `encoding/text_init.py` | `NGRAM_SIZES` | the character n-gram lengths that the stand-in encoder counts, besides whole words. |
| `encoding/text_init.py` | `INIT_STD` | the spread of a freshly started table row; 1.0 is what nn.Embedding starts with. Only the command line uses it: `init_embedding_from_text` measures the spread of the table it is given, so the starting rows match whatever start the model's own code chose. |
| `encoding/unknown_dropout.py` | `UNKNOWN_INDEX` | the row of a code table that stands for "a value the vocabulary does not know". |
| `encoding/unknown_dropout.py` | `DEFAULT_RATE` | the share of training rows on which an ordinary code field is swapped for unknown. |
| `encoding/unknown_dropout.py` | `CALENDAR_RATE` | the swap rate of a calendar field whose value in the scored month was never trained. |
| `encoding/unknown_dropout.py` | `CALENDAR_FIELDS` | the names of those calendar fields among the code fields of the model. |
| `encoding/unknown_dropout.py` | `NO_UNKNOWN_SUFFIXES` | endings of the names of code fields that have no unknown row (two-valued flags whose code 0 is a real value, such as the is-missing flags of numeric inputs). They are never swapped. |
| `exports/_shared.py` | `STAGE1_PREFIX` | the prefix of the stage-1 (no-history) vector columns in an export file (s1_0, s1_1, ...). The columns of the vector that enters the head use settings.VECTOR_PREFIX. |
| `exports/_shared.py` | `TREE_PARAMS` | the settings of the small tree models, in the names XGBoost uses. Put a consumer's own settings here when its model is to be imitated. Every arm of a comparison gets the same settings, so no arm wins because it was tuned harder. |
| `exports/_shared.py` | `TREE_ROUNDS` | the number of trees of those models. |
| `exports/_shared.py` | `LOGISTIC_SOLVER` | the solver of the small logistic fits. "newton-cholesky" is exact and fast when rows far outnumber inputs, and needs scikit-learn 1.2 or later; with an older version put "lbfgs" here. |
| `exports/bundle.py` | `VALUE_TILT` | k of the value score s_val = s_full + k * log(1 + amount). With a logit that is a true log-odds value, 1.0 is close to ranking by expected fraud dollars; put the k chosen for the data here. |
| `exports/bundle.py` | `PROBE_L2` | the pull toward zero of the probe weights (larger means smaller weights). |
| `exports/consumer_margin.py` | `OTHER_SCORE_COL` | the column that holds the other model's score, and whether it is a probability ("probability") or a log-odds value ("logit"). |
| `exports/feature_store.py` | `VALID_FROM_COL` | the name of the valid-from column in the store. |
| `exports/feature_store.py` | `LAG_SECONDS` | seconds between a transaction and the moment its export values can be read (the time scoring and writing take in serving). 0 means "from the next second on". |
| `exports/feature_store.py` | `STORE_VERSION` | the version text written in the manifest. |
| `exports/feature_store.py` | `MODEL_NAME` | the model name written in the manifest. |
| `exports/feature_store.py` | `MANIFEST_SUFFIX` | what is added to the table's file name (without its extension) to name the manifest. |
| `exports/feature_store.py` | (the line below the comment) | with remote storage, write this small text file the way that storage writes files. |
| `exports/phat_writer.py` | `HISTORY_ROWS` | the number of history positions the reading model takes per target row. |
| `exports/phat_writer.py` | `HISTORY_COLUMNS` | the column names the reading model expects for those positions. Entry 0 is the column of the most recent earlier row, entry 1 the one before it, and so on. The reader this layout was written for numbers its columns from the oldest position to the target row, so the most recent earlier row is phat_h17 and the oldest is phat_h1. For a reader that counts from the most recent row, reverse the list. |
| `exports/phat_writer.py` | `EMPTY_COLUMNS` | columns of the reader's layout that hold no earlier row, for example its slot for the target row itself, and the value written into them. Put () when the layout has none. The value is a number, not a missing value, because the reader named above leaves out a row with a missing value in a column it reads. |
| `exports/phat_writer.py` | `FILL_VALUE` | what is written at a history position that has no earlier row. None writes a missing value. A reader that leaves out rows with a missing value needs a number here: 0.0 says "no sign of fraud", which is also what the reader named above puts there by itself unless its skip_nan_phats option is on. |
| `exports/phat_writer.py` | `COUNT_COLUMN` | the column that holds the number of earlier rows found; None leaves it out. |
| `exports/phat_writer.py` | `ID_COLUMNS` | the names of the optional columns that hold the transaction id of each history row. |
| `exports/phat_writer.py` | `MAX_AGE_SECONDS` | the oldest an earlier row may be, in seconds; None means no limit (the last rows of the account, however old they are). |
| `exports/probe_suite.py` | `OTHER_PREFIX` | the prefix of the other model's columns in the table (other_0, other_1, ...). None means "the table holds no second set of columns"; the comparison is then skipped. |
| `exports/probe_suite.py` | `FOLDS` | the number of account folds. Each row is read by a probe fitted on the other folds. |
| `exports/probe_suite.py` | `PROBE_L2` | the pull toward zero of the probe weights (larger means smaller weights). It is the same for every set of columns, so that no set is tuned more than another. |
| `exports/probe_suite.py` | `LABEL_SHARES` | the shares of the fit accounts on which the label curve is fitted, largest first. |
| `exports/probe_suite.py` | `CURVE_TARGET` | the target of the label curve (one of the target names below). |
| `exports/probe_suite.py` | `RUN_GAP` | two frauds of one account belong to the same run when at most this many seconds lie between them. Seven days keeps a burst of a few hours and a series of weekly charges together. |
| `exports/release_gates.py` | `AUC_LIMIT` | the area under the ROC curve of the domain check above which the verdict reads "moved". |
| `exports/release_gates.py` | `PSI_LIMIT` | the stability index above which a column's verdict reads "moved". |
| `exports/release_gates.py` | `PSI_BINS` | the number of quantile bins of a numeric column in the stability index. |
| `exports/release_gates.py` | `PSI_FLOOR` | the smallest share a bin is given before the logarithm is taken. An empty bin would otherwise give an infinite index; with the floor, a bin that empties counts as a large but finite move. |
| `exports/release_gates.py` | `FOLDS` | the number of account groups of the domain check. Each group is scored by a model trained on the other groups. |
| `exports/release_gates.py` | `ROUNDS` | the number of trees of the domain check. Few are needed: the question is whether any difference exists, not how well it can be modelled. |
| `exports/release_gates.py` | `MAX_ROWS_PER_PERIOD` | the most rows of each period that enter the domain check; more are drawn at random down to this number, which keeps the check quick on millions of rows. |
| `exports/release_gates.py` | `THREADS` | the processor threads of the domain check. One thread is steady on a shared machine and quick enough for a few hundred thousand rows; put the number of free cores here on a machine of its own, or None to let XGBoost take all of them. |
| `exports/release_gates.py` | `TOP_COLUMNS` | how many of the columns the domain check leaned on most are listed. |
| `exports/soft_labels.py` | `SOFT_WEIGHT` | put the share of the model's probability in the training target here: 0 means plain labels, 1 means the probability alone, and 0.5 is the usual start. |
| `exports/stage1_hook.py` | `STAGE1_ATTR` | the attribute name of the stage-1 encoder inside the model (the module whose output holds one summary vector per transaction, computed from that transaction's fields alone). |
| `exports/stage1_hook.py` | `HEAD_ATTR` | the attribute name of the head (the module that turns the final vector into logits). |
| `exports/stage1_hook.py` | `SUMMARY_INDEX` | where the summary sits in the stage-1 output. - The module returns [rows, tokens, width] (one row per transaction, one entry per token, as the original token encoder does): put the position of the summary token, 0 in the original model. With several summary tokens put all their positions, for example (0, 1, 2); their vectors are joined, in that order, into one vector of 3 x width per transaction. - The module already returns one vector per transaction, as [rows, width] or as [batch, positions, width] (the SummaryTokenEncoder of additions/model/summary_tokens.py returns the joined summary tokens this way): put None. The two 3-D layouts cannot be told apart from the numbers alone, so this setting has to match the model. `VectorTap.rows` stops with a plain message when the row count shows a mismatch. |
| `exports/stage1_hook.py` | `MASK_KEY` | the key of the batch dict that marks real positions (True) against padding (False). |
| `features/_shared.py` | `MISSING_TEXT` | text values that stand for "no value" in the raw files, besides real missing values. A blank text is the usual one; add markers such as "NA" or "UNKNOWN" if the files use them. |
| `features/_shared.py` | `ip_prefix` | how much of an IP address is compared; return one text per distinct address. |
| `features/asof_audit.py` | `to_days` | how a column is read as a date; return whole days per row, or None when it is not a date. |
| `features/geo_velocity.py` | `CENTRE_POSTAL` | the column names of the table of postal-code centres. |
| `features/geo_velocity.py` | `CARD_PRESENT_VALUES` | the values of settings.CARD_PRESENT_COL that mean the card was physically present. |
| `features/geo_velocity.py` | `load_postal_centres` | read the table of postal-code centres of the pod here and return it. |
| `features/geo_velocity.py` | `postal_key` | how a postal code is written before it is looked up in the table of centres. |
| `features/novelty_amount.py` | `ROUND_AMOUNTS` | the round-amount flags, as (name, step in cents), for a currency with two decimals. |
| `features/outcome_history.py` | `outcome_family` | the rules that turn the raw decision columns into a family; change them here if the pod tells outcomes apart in another way (more families can be added to `FAMILIES`). |
| `features/possible_features.py` | `CARD_NOT_PRESENT_VALUES` | the value(s) of the card-present column that mean the card was NOT present. |
| `features/possible_features.py` | `SMALL_AMOUNT` | an amount below this many dollars counts as a "small" amount. Card testing often shows as a few very small purchases before a large one. |
| `features/possible_features.py` | `HIGH_SCORE` | a network risk score at or above this value counts as "high". |
| `features/possible_features.py` | `OPTIONAL_COLUMNS` | columns that some extracts hold and that have no entry in settings.py. Each value is the column's name in the files, or None when the files do not have it. A feature whose column is None or absent is left out and one line says so. |
| `features/ratios.py` | `BALANCE_IS_BEFORE_THE_ROW` | True when the balance column holds the balance BEFORE the row's amount is taken off. Set it to False if the files store the balance after the transaction; the amount is then added back. |
| `features/surprise.py` | `AMOUNT_BIN_EDGES` | upper edges of the amount bins, in the currency of the files. The first bin holds zero and negative amounts (zero-dollar checks, refunds); the last one everything above the last edge. |
| `features/surprise.py` | `TRANSITION_FIELDS` | the two code fields that get the "given the previous value" column. The second name is not in settings.py; put the column that holds the transaction category here. |
| `merchant/_panel.py` | `PANEL_BASE` | the folder and the numbers of the panel files, the files whose rows fill the tables. None for the folder means settings.EVAL_BASE. The list is an example. |
| `merchant/_panel.py` | `DAY_SHIFT_SECONDS` | seconds added to every timestamp before it is cut into calendar days. 0 cuts at midnight of the clock the timestamps are written in; put the offset of the bank's processing day here. |
| `merchant/_panel.py` | `LABEL_LAG_DAYS` | the number of days after which a fraud label is taken as known. The files hold no report date, so this lag stands in for it; a measured reporting curve can replace it (day_tables.py). |
| `merchant/_panel.py` | `PRIOR_ROWS` | how many made-up rows at the prior's value every rate and mean starts with. With 20, a merchant with 20 rows of its own sits halfway between its own value and the prior. |
| `merchant/burst_tables.py` | `SMALL_AMOUNT` | the amount in dollars under which an authorisation counts as small (a typical test amount). |
| `merchant/burst_tables.py` | `BUSIEST` | how many merchants get the 5-minute table: the ones with the most rows in the hour table. |
| `merchant/coverage.py` | `ALL_FILES` | the number of files the whole account population is split into. The coverage of a panel is its number of files over this number. |
| `merchant/coverage.py` | `COVERAGE_COL` | the name of the column that tells the model the log of the coverage of its merchant columns. |
| `merchant/covisit_vectors.py` | `TABLE_END` | the first day NOT counted into the table (text). None means settings.TARGET_START, so the table is fitted on rows before the scored month. When the columns are built for training rows of earlier months, put the first day of the earliest of those rows here, so that the table never holds visits made after a row it is used on. |
| `merchant/covisit_vectors.py` | `PAIR_DAYS` | two visits of one account form a pair when their days are at most this far apart. |
| `merchant/covisit_vectors.py` | `MAX_LAG` | how many later visits of the same account each visit is paired with at most. It bounds the work for very busy accounts; with 200 it is rarely reached. |
| `merchant/covisit_vectors.py` | `MIN_ACCOUNTS` | a merchant with fewer accounts than this gets the vector of its category by postal code (or of its category) instead of its own. |
| `merchant/covisit_vectors.py` | `DIM` | the number of numbers per merchant. |
| `merchant/day_tables.py` | `LABEL_PRIOR_ROWS` | made-up rows at the prior's value for the fraud rate. Fraud is rare, so the prior has to weigh far more than for the other rates, or one fraud at a small merchant reads as a hot spot. |
| `merchant/day_tables.py` | `REPORTING_CURVE` | a measured reporting curve, to replace the fixed label lag. None keeps the fixed lag. The form is a list of (age in days, share of frauds reported by that age), for example [(7, s7), (14, s14), (30, s30), (60, s60)] with the measured shares in place of s7 ... s60. |
| `merchant/day_tables.py` | (the line below the comment) | wrap the amount in np.log1p here to keep its mean and spread on a log scale. |
| `merchant/exposure.py` | `WEEK_DAYS` | the length of the merchant period in days. 7 groups visits by week; 1 gives merchant-days, which suits small test amounts at card-testing sites. |
| `merchant/exposure.py` | `PROXY_BLAME_DAYS` | how many days before a label-free bad outcome the account's visits are blamed. |
| `merchant/exposure.py` | `FRAUD_BLAME_DAYS` | how many days before the first reported fraud the account's visits are blamed. |
| `merchant/exposure.py` | `HIGH_SCORE` | the network risk score at or above which a row counts as a label-free bad outcome (the scale of settings.VISA_SCORE_COL runs from 0 to 99; put its top-decile value here). |
| `merchant/exposure.py` | `EXPOSURE_PRIOR_ROWS` | made-up visitors at the prior's share that every merchant-week starts with. Bad outcomes are rare, so the prior has to weigh well above a typical merchant-week's visitors. |
| `merchant/heat.py` | `ALERT_CUT_LOGIT` | the alert cut in log-odds as one fixed number (the cut used in production, or the cut measured on an earlier month). None takes it from the scores of the first panel file. |
| `merchant/heat.py` | `HEAT_EDGES` | the edges of the score histogram in log-odds; scores outside fall into the end bins. |
| `merchant/visa_view.py` | `SCORE_EDGES` | the edges of the score histogram; the default gives 10 bins of width 10 for a score from 0 to 99. |
| `merchant/visa_view.py` | `BASE_DAYS` | completed days in the baseline window and in the recent window, both ending the day before the row. |
| `model/_shared.py` | (the line below the comment) | the real pipeline applies its frozen preprocessing here; this stand-in takes a signed logarithm and then scales every numeric column with the mean and spread of the table itself. |
| `model/aligned_outcomes.py` | `NUM_OUTCOME_CODES` | the number of outcome codes, counting code 0 ("not known"); 6 fits the five families of additions/features/outcome_history.py (approved, funds decline, risk decline, other decline, advice). |
| `model/masks.py` | `TIME_UNITS_PER_SECOND` | how many units of the batch's time values make one second: 1 when the builder writes whole seconds, 1_000_000_000 when it writes nanoseconds (the original SequenceBuilder does). |
| `model/members.py` | `NUM_MEMBERS` | how many members the model holds when the caller does not say; 1 is the plain model. |
| `model/merchant_context.py` | `N_LAST` | how many rows of other accounts are kept per row. |
| `model/merchant_context.py` | `STORE_DELAY_SECONDS` | how many seconds old a row must be before another row may read it; 1 means "from the next second on". A store that needs longer to make a scored row readable needs a larger number here. |
| `model/profile_encoder.py` | `PROFILE_TOKEN_DIM` | width of a profile token; narrow on purpose, because a slow field carries little. |
| `model/profile_encoder.py` | `PROFILE_HEADS` | attention heads inside the encoder; PROFILE_TOKEN_DIM must be a multiple of it. |
| `model/profile_encoder.py` | `PROFILE_QUERIES` | how many vectors the encoder hands to stage 2 (each becomes one position in front of the rows). |
| `model/reference_model.py` | `DEMO_VECTOR_DIM` | width of the stored per-row vectors that the demo makes up for the state and merchant blocks; in a real run it is the width of the vectors exported from a frozen first model. |
| `model/reference_model.py` | `DEMO_PROFILE_COLS` | the slow account date columns the demo turns into profile fields (made up by synthetic.add_profile_dates); in a real run, the profile columns that pass additions/features/asof_audit.py. |
| `model/state_prefix.py` | `HALF_LIVES` | the half-lives of the stored state, in seconds; they must be the ones the state was built with. |
| `model/summary_tokens.py` | `NUM_SUMMARY` | how many summary tokens a transaction gets when the caller does not say; 1 is the original design, 3 makes the transaction vector three field tokens wide. |
| `proof/blend_ladder.py` | `FOLDS` | into how many groups of accounts the rows are dealt. Each group is scored by a blend fitted on the other groups. Five keeps four fifths of the frauds in every fit. |
| `proof/blend_ladder.py` | `REPEATS` | how many times the dealing is repeated with another shuffle. The out-of-fold scores of the repeats are averaged, which removes most of the noise of one particular deal. |
| `proof/blend_ladder.py` | `FORM` | what the blend reads from each model. "rank": the log-odds of the row's rank share, the same scale for every model whatever it stores (a probability, a margin, a raw score). "logit": the model's own log-odds, which keeps how far apart two scores are; it needs to know what each file stores (see --kinds). |
| `proof/blend_ladder.py` | `BLEND_C` | the inverse strength of the pull of the blend weights toward zero. A large value means almost no pull, which suits a fit of a few weights on many rows. |
| `proof/blend_ladder.py` | `MAX_MODELS` | the most models read at once. Five models already make 31 sets. |
| `proof/blend_ladder.py` | `CONTROL_NAME` | the name of the control column of random numbers in the printed tables. |
| `proof/diagnosis.py` | `AMOUNT_EDGES` | dollar edges of the amount bands; set them to the currency and spread of the data. |
| `proof/diagnosis.py` | `RISK_EDGES` | edges of the network risk-score bands (the score runs from 0 to 99 in the original data). |
| `proof/diagnosis.py` | `CARD_PRESENT_YES` | the values of CARD_PRESENT_COL that mean "the card was present". |
| `proof/head_to_head.py` | `LATE_ROWS_AFTER_DAYS` | the number of days after the start of the scored month from which the "rows from a given date on" read starts; by then every row has more than a month of history behind it. |
| `proof/noise_budget.py` | `BLOCK_SIZES` | the block sizes, in numbers of files, for which the ladder is printed; put here the sizes of the blocks that can actually be read. |
| `proof/screening_rule.py` | `TREE_ROUNDS` | settings of the screen's tree model; deeper trees or more rounds suit blocks with many more frauds than the made-up data. |
| `proof/time_consistency.py` | `EARLY_PERIOD` | the early period (start inclusive, end exclusive) on which each one-column model is fitted; put here the months of the training files. |
| `proof/time_consistency.py` | `LATE_PERIOD` | the late period on which the models are read; the default is the month before the scored month, so that the scored month plays no part in choosing columns. |
| `reads/_rows.py` | `ADVICE_EMPTY_VALUES` | put here the values of the advice column that mean "this is not an advice row"; a missing value always means that. For a 0/1 flag use ("", "0"), for a Y/N flag ("", "N"). |
| `reads/amount_tilt.py` | `TILTED_COL` | the name of the column that holds the tilted score in the file written with --out. |
| `reads/history_census.py` | `HISTORY_LENGTHS` | the history lengths under consideration, in earlier seconds read by stage 2. Put the current length first and the candidates after it. |
| `reads/lock_on.py` | `STICKY_COL` | the names of the two columns written with --out: the logit after the bonus, and the largest earlier logit of the account inside the chosen window. |
| `reads/month_token.py` | `CALENDAR_FIELD` | the name of the calendar input field whose value in the scored month was never trained. It is the column that `clamp_month` overwrites and the field whose table is patched. |
| `reads/month_token.py` | `TRAINED_ROWS` | the rows of that field's embedding table that training updated. The example fits a table whose rows 0 and 1 are kept for "unknown" and "missing" and whose rows 2 to 9 hold eight trained months; list the rows of the months that occur in the training files. |
| `reads/month_token.py` | `TARGET_ROW` | the row an unseen month lands on at scoring time. In a table with a row for unknown values that is this row; in a table with one row per month it is the row of the scored month. A list of rows is allowed. |
| `sweep/plan.py` | `SWEEP_FILES` | the number of training files of the sweep and of the full-scale run. |
| `sweep/plan.py` | `HOURS_PER_RUN` | hours one control training run takes at the sweep scale, start to finish. None means "not measured yet": the plan then reports runs only, not hours. |
| `sweep/plan.py` | `GPUS` | how many training runs can run at the same time. |
| `sweep/promote.py` | `MIN_GAIN` | the smallest gain in capture (as a share of all frauds; 0.005 is half a point) that an arm with a cost must show on the choose block. |
| `sweep/promote.py` | `REQUIRE_CONFIRM` | whether an arm must also be above zero on a second block that was not used to choose. With True, an arm with no confirm read is "unclear", not "holds". |
| `sweep/promote.py` | `COSTLY_FACTOR` | an arm whose training run takes at least this many times the control's time is "costly": at full scale it also gets a run without it, to show what it adds on its own. |
| `training/_loss_shared.py` | `FRAUD_CLASS` | the output column of a two-class fraud head that stands for "fraud" (0 or 1). |
| `training/lookback_cut.py` | `TIME_UNITS_PER_SECOND` | how many units of the time tensor make one second (1 for whole seconds, 10**9 for nanoseconds as in the original model's time_seq). |
| `training/loss_masks.py` | `ADVICE_EMPTY_VALUES` | the values of the advice column that mean "this is not an advice row"; a missing value always means that. For a 0/1 flag use ("", "0"), for a Y/N flag ("", "N"). |
| `training/next_transaction_heads.py` | `AMOUNT_BIN_EDGES` | the dollar amounts that separate the amount bands, ascending. |
| `training/next_transaction_heads.py` | `GAP_BIN_EDGES` | the gaps in seconds that separate the time-gap bands, ascending (1 minute to 1 week). |
| `training/next_transaction_heads.py` | `MAX_CATEGORIES` | how many of the most frequent merchant categories get a class of their own. |
| `training/offset_head.py` | `OFFSET_SCORE_COL` | the column that holds the other model's score for every training row. |
| `training/offset_head.py` | `OFFSET_SCORE_KIND` | what that column holds: "probability" or "logit" (a log-odds value). |
| `training/pairwise_top.py` | `WARMUP_STEPS` | the number of training steps before the term is switched on; about one pass over the training files. |

## Possible features

`features/possible_features.py` is a catalogue of candidate input columns that can be added
to the inputs the model already has. Each entry has a name, a family, the columns it needs
and a status: built by the catalogue itself, built by another file of `features/`, or waiting
for a column that the settings do not name yet.

    python additions/features/possible_features.py --list
    python additions/features/possible_features.py --demo

From Python, `build_possible_features(df, families=[...])` returns the new columns aligned to
the rows of `df`. A family is screened on the CPU first (`after_model/family_screen.py`) and
gets a training run only when it adds something on top of the model's own score.

## The testing plan

`additions/SWEEP.md` describes it in full. In short:

    python additions/sweep/plan.py --list                          # every arm and what turns it on
    python additions/sweep/plan.py --hours-per-run 20 --gpus 2     # the order and the cost
    python additions/sweep/promote.py --results results.csv        # what holds, and the full-scale runs

The time of one control run at the sweep scale has to be measured on the pod and passed in;
the plan multiplies it by the number of runs.

## What is needed to run

Python with numpy, pandas, pyarrow, torch, xgboost, scikit-learn and scipy. The model blocks
and the tests run on a CPU.

The whole test suite was run on two sets of library versions, on Python 3.11 with torch 2.15:

| | pandas | numpy | scikit-learn | xgboost | scipy | pyarrow |
|---|---|---|---|---|---|---|
| newer | 2.3.3 | 2.4.6 | 1.9.1 | 3.2.0 | 1.17.1 | 26.0.1 |
| older | 1.5.3 | 1.26.4 | 1.3.2 | 2.0.3 | 1.10.1 | 12.0.1 |

Three places depend on the library version, and each says so where it stands: text
timestamps are parsed in `common/timekeys.py` in a way that works on pandas 1 and pandas 2;
the logistic solver named in `exports/_shared.py` needs scikit-learn 1.2 or later; and the
argument `custom_metric` in `after_model/_shared.py` is called `feval` before xgboost 1.6.
