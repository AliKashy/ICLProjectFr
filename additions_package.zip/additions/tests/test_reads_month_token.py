"""Tests of the helpers for a calendar value that training never saw.

The clamp is checked on timestamps and on plain numbers, the mean row on numpy arrays and on
torch tensors and layers, and the reader is shown to compare on the scored month only.
"""
import numpy as np
import pandas as pd
import pytest
import torch

from additions import settings
from additions.common import ranking, synthetic, tables
from additions.reads import _rows, month_token

STANDARD = [settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL, settings.LABEL_COL, settings.AMOUNT_COL,
            settings.SCORE_COL]


def test_clamp_on_timestamps_replaces_only_the_months_after_training():
    """Months up to the last trained one keep their number, also across a year end; later ones get the last."""
    times = pd.Series(pd.to_datetime(["2024-10-03 00:00:00", "2024-12-31 23:59:59", "2025-01-01 00:00:00",
                                      "2025-05-31 23:59:59", "2025-06-01 00:00:00", "2025-07-15 12:00:00",
                                      "2026-01-02 00:00:00"]))
    assert month_token.clamp_month(times, "2025-05").tolist() == [10, 12, 1, 5, 5, 5, 5]
    assert month_token.clamp_month(times.to_numpy(), pd.Timestamp("2025-05-17")).tolist() == [10, 12, 1, 5, 5, 5, 5]
    as_text = ["2025-06-10 08:00:00.5", "2025-04-30", None]       # text, with and without fractions of a second
    out = month_token.clamp_month(as_text, "2025-05")
    assert out[0] == 5 and out[1] == 4 and np.isnan(out[2])       # a missing time stays missing
    # The default for the last trained month is the month before the scored month in settings.
    start = pd.Timestamp(settings.TARGET_START)
    before = (start - pd.Timedelta(seconds=1)).month
    around = pd.Series([start - pd.Timedelta(seconds=1), start, start + pd.Timedelta(days=45)])
    assert month_token.clamp_month(around).tolist() == [before, before, before]


def test_clamp_on_numbers_uses_their_own_scale():
    """A scale that grows with time is compared directly; months of the year need the first trained month."""
    grows = np.array([202410, 202505, 202506, 202601])
    assert month_token.clamp_month(grows, 202505).tolist() == [202410, 202505, 202505, 202505]
    months = np.array([10, 11, 12, 1, 5, 6, 9])
    assert month_token.clamp_month(months, last_trained=5, first_trained=10).tolist() == [10, 11, 12, 1, 5, 5, 5]
    assert month_token.clamp_month(months, last_trained=11, first_trained=2).tolist() == [10, 11, 11, 11, 5, 6, 9]
    with pytest.raises(ValueError):
        month_token.clamp_month(months)                           # numbers carry no default for the last month
    # Both forms give the same months on a table of timestamps.
    times = pd.to_datetime(synthetic.make_transactions(n_accounts=30, seed=0)[settings.TIME_COL])
    from_times = month_token.clamp_month(times, "2025-05")
    from_months = month_token.clamp_month(times.dt.month.to_numpy(), last_trained=5, first_trained=10)
    assert np.array_equal(from_times, from_months) and set(from_times) == {5}


def test_mean_row_changes_only_the_target_row():
    """The target row becomes the mean of the trained rows; every other row and the input stay as they were."""
    values = np.random.default_rng(0).normal(size=(14, 6))
    out = month_token.mean_row(values, trained_rows=range(2, 10), target_row=0)
    assert out.shape == values.shape and not np.shares_memory(out, values)
    assert month_token.mean_row(values.astype(np.float32), range(2, 10), 0).dtype == np.float32
    assert np.allclose(out[0], values[2:10].mean(axis=0)) and np.array_equal(out[1:], values[1:])
    # A torch tensor comes back as a new tensor that is cut off from the gradient of the original.
    weight = torch.tensor(values, dtype=torch.float32, requires_grad=True)
    patched = month_token.mean_row(weight)                         # the defaults at the top of the file
    trained, target = list(month_token.TRAINED_ROWS), month_token.TARGET_ROW
    others = [row for row in range(14) if row != target]
    assert torch.is_tensor(patched) and patched.shape == weight.shape and not patched.requires_grad
    assert torch.allclose(patched[target], weight[trained].mean(dim=0))
    assert torch.equal(patched[others], weight.detach()[others])
    assert torch.equal(weight.detach(), torch.tensor(values, dtype=torch.float32))
    # Every row as the target makes the field say the same for any value.
    blank = month_token.mean_row(values, range(2, 10), target_row=range(14))
    assert np.allclose(blank, values[2:10].mean(axis=0)[None, :])


def test_patched_layer_gives_the_mean_vector_and_still_trains():
    """After the patch the unseen value reads the mean vector, other values read their own, and gradients flow."""
    torch.manual_seed(0)
    layer = torch.nn.Embedding(14, 6)
    before = layer.weight.detach().clone()
    assert month_token.patch_embedding(layer, trained_rows=range(2, 10), target_row=0) is layer
    out = layer(torch.tensor([0, 3]))
    assert out.shape == (2, 6) and bool(torch.isfinite(out).all())
    assert torch.allclose(out[0], before[2:10].mean(dim=0)) and torch.equal(out[1], before[3])
    out.sum().backward()
    assert layer.weight.grad is not None and float(layer.weight.grad[0].abs().sum()) > 0
    assert float(layer.weight.grad[5].abs().sum()) == 0            # a row that was not used gets no gradient


@pytest.fixture(scope="module")
def variants(tmp_path_factory):
    """Three prediction files: a control, a variant that ranks frauds higher, and one that differs on history only."""
    folder = tmp_path_factory.mktemp("month")
    df = synthetic.make_transactions(n_accounts=300, seed=1)
    control = synthetic.make_scores(df, seed=1, strength=1.5)
    better = synthetic.make_scores(df, seed=1, strength=2.5)       # the same noise with the frauds moved up
    history_only = control.copy()
    outside = ~_rows.in_scored_month(df)
    history_only.loc[outside, settings.SCORE_COL] = np.random.default_rng(0).random(int(outside.sum()))
    paths = [tables.write_table(frame[STANDARD], str(folder / f"{name}.parquet"))
             for name, frame in (("as_is", control), ("clamped", better), ("mean_row", history_only))]
    return df, control, paths


def test_reader_compares_on_the_scored_month_only(variants):
    """Each file is read on the scored month; a file that differs only on history rows shows no difference."""
    df, control, paths = variants
    scored = _rows.in_scored_month(df)
    table = month_token.compare_files(paths, ["as_is", "clamped", "mean_row"], draws=60)
    assert table["read"].tolist() == ["as_is", "clamped", "mean_row"] and (table["rows"] == scored.sum()).all()
    y, a = df[settings.LABEL_COL].to_numpy()[scored], df[settings.AMOUNT_COL].to_numpy()[scored]
    expected = ranking.capture(y, control[settings.SCORE_COL].to_numpy()[scored], a)
    assert np.isclose(table.loc[0, "udr"], expected["udr"]) and np.isclose(table.loc[0, "vdr"], expected["vdr"])
    assert np.isnan(table.loc[0, "gain"])                          # the first file is the control
    assert np.isclose(table.loc[1, "gain"], table.loc[1, "udr"] - table.loc[0, "udr"]) and table.loc[1, "gain"] > 0
    assert table.loc[1, "low"] <= table.loc[1, "gain"] <= table.loc[1, "high"]
    assert table.loc[2, "gain"] == 0 and table.loc[2, "low"] == 0 and table.loc[2, "high"] == 0
    # With every row ranked the scrambled history rows do change the read.
    everything = month_token.compare_files(paths, all_rows=True, draws=20)
    assert everything.loc[0, "rows"] == len(df) and everything.loc[2, "udr"] != everything.loc[0, "udr"]


def test_tool_takes_named_files_and_writes_the_table(variants, tmp_path, capsys):
    """Files are given as name=path, a bare path is named after its file, and the table is written on request."""
    _, _, paths = variants
    out = str(tmp_path / "month.parquet")
    month_token.main(["--pred", f"as_is={paths[0]}", f"clamped={paths[1]}", paths[2], "--draws", "20", "--out", out])
    printed = capsys.readouterr().out
    assert month_token.CALENDAR_FIELD in printed and "rows of the scored month only" in printed
    written = tables.read_columns(out)
    assert written["read"].tolist() == ["as_is", "clamped", "mean_row"]
    # A month in which the files hold no row is reported in one line; nothing is raised.
    month_token.main(["--pred", f"as_is={paths[0]}", "--start", "2031-01-01", "--end", "2031-02-01"])
    assert "no row falls in the scored month" in capsys.readouterr().out
