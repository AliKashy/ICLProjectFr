"""Tests of the seed spread and of the three score averages.

The averages are compared with their definitions written out slowly, identical files are shown
to average to themselves, and the file that the tool writes is read back.
"""
import numpy as np
import pytest

from additions import settings
from additions.common import ranking, synthetic, tables
from additions.reads import _rows, seed_average

STANDARD = [settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL, settings.LABEL_COL, settings.AMOUNT_COL,
            settings.SCORE_COL]


@pytest.fixture(scope="module")
def files(tmp_path_factory):
    """Three prediction files of the same made-up rows, as three training seeds would give them."""
    folder = tmp_path_factory.mktemp("seeds")
    df = synthetic.make_transactions(n_accounts=400, seed=1)
    paths = []
    for seed in (42, 43, 44):
        scored = synthetic.make_scores(df, seed=seed, strength=1.5)[STANDARD]
        if seed == 43:
            scored = scored.sample(frac=1.0, random_state=0)   # one file in another row order
        paths.append(tables.write_table(scored, str(folder / f"seed{seed}.parquet")))
    return df, paths


def _logit_matrix(df):
    """The log-odds of the three made-up seeds, in the row order of `df`."""
    columns = [synthetic.make_scores(df, seed=seed, strength=1.5)[settings.SCORE_COL] for seed in (42, 43, 44)]
    return ranking.to_logit(np.column_stack(columns))


def test_three_averages_match_their_definitions():
    """Mean of logits, mean of probabilities and mean of ranks equal the slow way of computing each."""
    rng = np.random.default_rng(0)
    matrix = rng.normal(-4.0, 2.0, size=(200, 3))
    matrix[:20, 1] = matrix[20:40, 1]                          # some equal scores, to test tied ranks
    got = seed_average.averages(matrix)
    assert set(got) == set(seed_average.AVERAGES) and all(v.shape == (200,) for v in got.values())
    assert np.allclose(got["logit"], [row.sum() / 3 for row in matrix])
    assert np.allclose(got["probability"], [(1.0 / (1.0 + np.exp(-row))).sum() / 3 for row in matrix])
    rank = np.zeros_like(matrix)
    for j in range(3):
        column = matrix[:, j]
        for i in range(200):                                   # rows below, plus half of the rows that tie
            rank[i, j] = (column < column[i]).sum() + ((column == column[i]).sum() + 1) / 2
    assert np.allclose(got["rank"], (rank / 200).mean(axis=1))


def test_identical_files_average_to_themselves():
    """Averaging copies of one score column changes no alert and no figure, and the spread is zero."""
    rng = np.random.default_rng(1)
    y = (rng.random(20_000) < 0.01).astype(float)
    logit = rng.normal(-5.0, 1.0, 20_000) + 2.0 * y
    matrix = np.column_stack([logit, logit, logit])
    single = ranking.alert_mask(logit)
    for values in seed_average.averages(matrix).values():
        assert (ranking.alert_mask(values) == single).all()
    table = seed_average.score_table(y, matrix).set_index("read")
    assert abs(table.loc["sd of files", "udr"]) < 1e-12
    for name in seed_average.AVERAGE_NAMES.values():
        assert np.isclose(table.loc[name, "udr"], table.loc["file 1", "udr"])
        assert np.isclose(table.loc[name, "gain_over_mean"], 0.0)
    assert (seed_average.alert_overlap(matrix)["share"] == 1.0).all()


def test_table_holds_each_file_their_mean_and_their_spread(files):
    """The lines of the single files equal capture of each; mean and spread are taken over them."""
    df, paths = files
    result = seed_average.read_files(paths, names=["42", "43", "44"], draws=50)
    scored = _rows.in_scored_month(df)
    y, a = df[settings.LABEL_COL].to_numpy()[scored], df[settings.AMOUNT_COL].to_numpy()[scored]
    matrix = _logit_matrix(df)[scored]
    table = result["table"].set_index("read")
    singles = [ranking.capture(y, matrix[:, j], a) for j in range(3)]
    for j, name in enumerate(("42", "43", "44")):                # the shuffled file was lined up by id
        assert np.isclose(table.loc[name, "udr"], singles[j]["udr"])
        assert np.isclose(table.loc[name, "vdr"], singles[j]["vdr"])
        assert np.isclose(table.loc[name, "ap"], ranking.average_precision(y, matrix[:, j]))
    udr = [c["udr"] for c in singles]
    assert np.isclose(table.loc["mean of files", "udr"], np.mean(udr))
    assert np.isclose(table.loc["sd of files", "udr"], np.std(udr, ddof=1))
    mean_logit = ranking.capture(y, matrix.mean(axis=1), a)
    assert np.isclose(table.loc["average of logits", "udr"], mean_logit["udr"])
    assert np.isclose(table.loc["average of logits", "gain_over_mean"], mean_logit["udr"] - np.mean(udr))
    assert result["ranked"].sum() == scored.sum() and result["logits"].shape == (len(df), 3)
    # The bootstrap line compares the logit average with the first file on the same rows.
    line = result["bootstrap"].iloc[0]
    assert np.isclose(line["average_of_logits"], mean_logit["udr"]) and np.isclose(line["first_file"], udr[0])
    assert np.isclose(line["gain"], mean_logit["udr"] - udr[0]) and line["low"] <= line["high"]
    # The overlap table counts the alerts shared with the first file.
    overlap = result["overlap"].set_index("read")
    first, second = ranking.alert_mask(matrix[:, 0]), ranking.alert_mask(matrix[:, 1])
    assert overlap.loc["42", "share"] == 1.0 and overlap.loc["43", "shared_with_first"] == (first & second).sum()


def test_all_rows_can_be_ranked_instead_of_the_scored_month(files):
    """With all_rows the history rows are ranked too, which changes the population and the figures."""
    df, paths = files
    everything = seed_average.read_files(paths, all_rows=True, draws=10)
    assert everything["ranked"].all()
    y, a = df[settings.LABEL_COL].to_numpy(), df[settings.AMOUNT_COL].to_numpy()
    expected = ranking.capture(y, _logit_matrix(df)[:, 0], a)
    assert np.isclose(everything["table"].set_index("read").loc["file 1", "udr"], expected["udr"])


def test_averages_are_written_in_the_kind_of_the_inputs():
    """A logit average becomes a probability for probability files and stays a logit for logit files."""
    logit = np.array([-3.0, 0.0, 2.0])
    assert np.allclose(seed_average.as_score_kind(logit, "logit", "probability"), 1.0 / (1.0 + np.exp(-logit)))
    assert np.array_equal(seed_average.as_score_kind(logit, "logit", "logit"), logit)
    share = np.array([0.1, 0.5, 0.9])
    assert np.array_equal(seed_average.as_score_kind(share, "rank", "probability"), share)
    assert np.allclose(seed_average.as_score_kind(share, "probability", "logit"), np.log(share / (1.0 - share)))


def test_tool_writes_the_average_and_it_reads_back(files, tmp_path, capsys):
    """The written file holds every shared row with the mean of the logits, and gives the reported capture."""
    df, paths = files
    out = str(tmp_path / "averaged.parquet")
    seed_average.main(["--preds", *paths, "--names", "42", "43", "44", "--draws", "30", "--out", out])
    printed = capsys.readouterr().out
    for text in ("Capture of each file", "Alerts shared with the first file", "average of probabilities",
                 "Average of logits against the first file"):
        assert text in printed
    written = _rows.load_predictions(out).set_index(settings.ID_COL)
    assert len(written) == len(df)                               # history rows are written too
    mean_logit = _logit_matrix(df).mean(axis=1)
    expected = 1.0 / (1.0 + np.exp(-mean_logit))                 # the input files hold probabilities
    assert np.allclose(written[settings.SCORE_COL].reindex(df[settings.ID_COL]).to_numpy(), expected)
    scored = _rows.in_scored_month(df)
    again = ranking.capture(df[settings.LABEL_COL].to_numpy()[scored], expected[scored])
    assert f"{again['udr']:.4f}" in printed
    # A wrong number of names is not an error: the files are numbered instead.
    seed_average.main(["--preds", *paths, "--names", "only-one", "--draws", "10"])
    printed = capsys.readouterr().out
    assert "numbered instead" in printed and "file 3" in printed
