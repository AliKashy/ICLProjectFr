"""Tests of the command-line pieces shared by the tools of the reads folder.

They check that the shared arguments mean what they say and that tables are printed and
written in the plain way every tool relies on.
"""
import argparse

import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, tables
from additions.reads import _cli, _rows


def test_file_numbers_and_ranges_undo_each_other():
    """Text such as "1-3,7" becomes the numbers it names, and the numbers become the same text again."""
    assert _cli.file_numbers("1-3, 7,9-10") == [1, 2, 3, 7, 9, 10]
    assert _cli.file_numbers(None) == [] and _cli.file_numbers("") == []
    assert _cli.number_ranges([10, 9, 7, 3, 2, 1]) == "1-3,7,9-10"
    assert _cli.number_ranges([]) == ""
    numbers = sorted(np.random.default_rng(0).choice(500, 120, replace=False).tolist())
    assert _cli.file_numbers(_cli.number_ranges(numbers)) == numbers


def test_shared_arguments_choose_the_ranked_rows():
    """No flag ranks the scored month from settings, --all-rows ranks everything, --start and --end move the month."""
    df = synthetic.make_transactions(n_accounts=40, seed=1)
    parser = _cli.add_raw_arguments(_cli.add_score_arguments(argparse.ArgumentParser()))
    args = parser.parse_args([])
    assert args.score_col is None and args.per_mille is None and args.raw_files is None   # None: use settings
    month = _rows.in_scored_month(df)
    assert (_cli.scored_rows(df, args) == month).all() and 0 < month.sum() < len(df)
    assert _cli.scored_rows(df, parser.parse_args(["--all-rows"])).all()
    # Moving the window to the month before picks the history rows and none of the scored month.
    earlier = parser.parse_args(["--start", settings.EVAL_HISTORY_START, "--end", settings.TARGET_START])
    before = _cli.scored_rows(df, earlier)
    assert before.sum() > 0 and not (before & month).any()
    assert parser.parse_args(["--per-mille", "10"]).per_mille == 10


def test_tables_are_printed_as_plain_text(capsys):
    """A table is printed under its title with rounded decimals and a dash for a missing number."""
    _cli.show("A title", [{"g": 0.5, "udr": 0.123456, "count": 7, "vdr": np.nan}])
    out = capsys.readouterr().out
    assert "A title" in out and "0.1235" in out and "0.123456" not in out
    assert out.strip().splitlines()[-1].split() == ["0.5000", "0.1235", "7", "-"]
    _cli.show("Nothing", pd.DataFrame())
    assert "(no rows)" in capsys.readouterr().out


def test_save_replaces_an_existing_file(tmp_path, capsys):
    """Writing to a path that exists replaces the file; nothing asks for a confirmation."""
    path = str(tmp_path / "table.parquet")
    _cli.save(pd.DataFrame({"a": [1, 2, 3]}), path)
    _cli.save(pd.DataFrame({"a": [9]}), path)
    assert tables.read_columns(path)["a"].tolist() == [9]
    assert "wrote 1 row(s)" in capsys.readouterr().out


def test_an_empty_selection_is_reported_and_nothing_is_raised(capsys):
    """When no row is left to rank, one line says what to change and the tool can return quietly."""
    assert _cli.nothing_to_rank(np.zeros(5, dtype=bool)) is True
    assert "scored month" in capsys.readouterr().out
    assert _cli.nothing_to_rank(np.array([False, True])) is False
    assert capsys.readouterr().out == ""
