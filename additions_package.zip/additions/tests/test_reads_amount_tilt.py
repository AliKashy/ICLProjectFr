"""Tests of the amount tilt.

They check the formula, that a tilt of zero is the model's own ranking, that every line of the
frontier equals capture of the tilted scores, and that the picked g respects the limit.
"""
import numpy as np
import pandas as pd
import pytest

from additions import settings
from additions.common import ranking, synthetic, tables
from additions.reads import _rows, amount_tilt

STANDARD = [settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL, settings.LABEL_COL, settings.AMOUNT_COL,
            settings.SCORE_COL]


@pytest.fixture(scope="module")
def table():
    """Made-up rows with a score; frauds tend to have larger amounts, so the tilt has something to trade."""
    return synthetic.make_scores(synthetic.make_transactions(n_accounts=400, seed=3), seed=3, strength=1.5)


def _ranked(table):
    """Fraud flags, logits and amounts of the rows of the scored month."""
    scored = _rows.in_scored_month(table)
    return (scored, table[settings.LABEL_COL].to_numpy()[scored].astype(float),
            ranking.to_logit(table[settings.SCORE_COL])[scored], table[settings.AMOUNT_COL].to_numpy()[scored])


def test_tilt_formula_and_the_rule_for_odd_amounts():
    """The tilt adds g times log(1 + amount); a missing or negative amount adds nothing; g = 0 changes nothing."""
    logit = np.array([0.0, -1.0, 2.0, 0.5])
    amount = np.array([0.0, 9.0, np.nan, -3.0])
    assert np.allclose(amount_tilt.tilted_logit(logit, amount, 0.5), [0.0, -1.0 + 0.5 * np.log(10.0), 2.0, 0.5])
    assert np.array_equal(amount_tilt.tilted_logit(logit, amount, 0.0), logit)
    # A larger amount never lowers the tilted score of a row.
    steps = amount_tilt.tilted_logit(np.zeros(5), np.array([0.0, 1.0, 10.0, 100.0, 1e6]), 0.3)
    assert (np.diff(steps) > 0).all()


def test_frontier_lines_are_capture_of_the_tilted_scores(table):
    """Each g gives the capture of logit + g * log(1 + amount) at the unchanged budget; g = 0 is the base."""
    scored, y, logit, a = _ranked(table)
    grid = (0.0, 0.3, 1.0)
    frontier = amount_tilt.frontier(table, grid)
    assert frontier["g"].tolist() == list(grid)
    base = ranking.capture(y, logit, a)
    for line in frontier.to_dict("records"):
        expected = ranking.capture(y, logit + line["g"] * np.log1p(a), a)
        assert np.isclose(line["udr"], expected["udr"]) and np.isclose(line["vdr"], expected["vdr"])
        assert np.isclose(line["udr_change"], expected["udr"] - base["udr"])
        assert np.isclose(line["vdr_change"], expected["vdr"] - base["vdr"])
    assert frontier.loc[0, "udr_change"] == 0 and frontier.loc[0, "vdr_change"] == 0
    # The changes are against g = 0 even when the grid leaves it out, and history rows play no part.
    only = amount_tilt.frontier(table[scored].reset_index(drop=True), (1.0,))
    assert np.isclose(only.loc[0, "udr_change"], frontier.loc[2, "udr_change"])
    assert len(amount_tilt.frontier(table)) == len(amount_tilt.GRID)


def test_picked_g_is_the_largest_inside_the_limit():
    """The largest g whose own loss is inside the limit is taken; with none inside, there is no tilt."""
    frontier = pd.DataFrame({"g": [0.0, 0.2, 0.4, 0.6], "udr_change": [0.0, -0.004, -0.02, -0.009]})
    assert amount_tilt.pick_g(frontier, 0.01) == 0.6
    assert amount_tilt.pick_g(frontier, 0.005) == 0.2
    assert amount_tilt.pick_g(frontier, 0.0) == 0.0
    assert amount_tilt.pick_g(frontier.iloc[2:3], 0.01) == 0.0


def test_one_g_is_read_against_the_untilted_ranking(table):
    """The paired read gives both captures for both measures, and g = 0 gives a change of exactly zero."""
    scored, y, logit, a = _ranked(table)
    nothing = amount_tilt.read_g(table, 0.0, draws=30)
    assert nothing["measure"].tolist() == ["udr", "vdr"]
    assert (nothing["change"] == 0).all() and (nothing["low"] == 0).all() and (nothing["high"] == 0).all()
    read = amount_tilt.read_g(table, 0.5, draws=40).set_index("measure")
    tilted = ranking.capture(y, logit + 0.5 * np.log1p(a), a)
    base = ranking.capture(y, logit, a)
    assert np.isclose(read.loc["udr", "tilted"], tilted["udr"]) and np.isclose(read.loc["udr", "untilted"], base["udr"])
    assert np.isclose(read.loc["vdr", "tilted"], tilted["vdr"]) and np.isclose(read.loc["vdr", "untilted"], base["vdr"])
    assert np.isclose(read.loc["vdr", "change"], tilted["vdr"] - base["vdr"])
    assert read.loc["vdr", "low"] <= read.loc["vdr", "high"]


def test_without_amounts_the_tilt_is_skipped(table, capsys):
    """A table with no amount column gives empty tables and one line each; nothing is raised."""
    bare = table.drop(columns=[settings.AMOUNT_COL])
    assert len(amount_tilt.frontier(bare)) == 0 and len(amount_tilt.read_g(bare, 0.5)) == 0
    assert "amount" in capsys.readouterr().out
    same = amount_tilt.tilted_frame(bare, 0.5)
    assert np.allclose(same[amount_tilt.TILTED_COL], ranking.to_logit(bare[settings.SCORE_COL]))


def test_tool_prints_the_frontier_and_writes_the_tilted_score(table, tmp_path, capsys):
    """The tool picks g on the first file, reads it on the second, and writes the tilted column for every row."""
    pred = tables.write_table(table[STANDARD], str(tmp_path / "pred.parquet"))
    other = synthetic.make_scores(table.drop(columns=[settings.SCORE_COL]), seed=8, strength=1.5)
    report = tables.write_table(other[STANDARD], str(tmp_path / "report.parquet"))
    out = str(tmp_path / "tilted.parquet")
    amount_tilt.main(["--pred", pred, "--report", report, "--grid", "0", "0.2", "0.4", "--max-udr-loss", "1.0",
                      "--draws", "20", "--out", out])
    printed = capsys.readouterr().out
    assert "Frontier" in printed and "g used from here on: 0.4" in printed and "against the untilted ranking" in printed
    written = tables.read_columns(out)
    assert len(written) == len(other)                            # history rows are written too
    expected = ranking.to_logit(other[settings.SCORE_COL]) + 0.4 * np.log1p(other[settings.AMOUNT_COL].to_numpy())
    assert np.allclose(written[amount_tilt.TILTED_COL], expected)
    assert np.allclose(written[settings.SCORE_COL], other[settings.SCORE_COL])   # the model's score is kept
    # A g given by hand is used as it is, and no second file is needed.
    amount_tilt.main(["--pred", pred, "--g", "0.25", "--draws", "10"])
    assert "g used from here on: 0.25 (given on the command line)" in capsys.readouterr().out
