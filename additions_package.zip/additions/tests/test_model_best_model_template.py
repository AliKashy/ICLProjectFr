"""Tests of the stand-in for the strongest model, of its configurations, of its arms and of its checks.

The four named configurations must pass every check, and so must a grid over the switches: it is sampled, but every
value of every switch is tried at least once in a configuration where that switch has an effect, and every setting
of the grid must build, run a forward pass and a training step, and keep the time rule. TODAY must have the shape
of the model in use, its weights are counted by hand and set against those of the model in use, and WIDE_JOINED and
the two candidates must have the widths their docstrings state. Every arm must change one entry of the arm it is set
against and ask one question. The checks themselves must fail on models that break the rule they check, so that a
"yes" means something: a time unit that does not fit the times, a leak through the times of later rows, rows of one
second put in an order, a model that keeps something between two calls, a score that the order inside a second
moves, a mask that is True on padding, a leak in training mode only, a row that reads the other rows of its own
second, and a time origin fixed on the first call. A model that reads no history fails the first check, raw numbers
stop the checks with a plain error, the cut of check 3 takes the real rows in time order, and channels_stay_apart
sees a hand-off that mixes the summary outputs. The parameter groups must hold every weight once, parts that start at
zero must change no score when they are switched on, the route that adds a bias must keep the arithmetic of the
standard layer, and the module must run as a script inside the package (tests/test_kit_runs_flat.py runs it from a
flat folder).
"""
import ast
import collections
import dataclasses
import importlib.util
import logging
import math
import os
import subprocess
import sys
import threading
import types
from dataclasses import replace
from pathlib import Path

import numpy as np
import pytest
import torch
import torch.nn as nn
import torch.nn.functional as F

from additions.model import best_model_template as bm

# Sizes small enough for a grid of fifty settings to run in seconds; every head count divides every width.
SMALL = dict(token_dim=16, n_bins=4, n_frequencies=3, num_summary=2, stage1_layers=1, stage1_heads=2,
             history_layers=2, history_heads=2, history_len=8)

# The unit of the made-up batch, which every check is handed by its caller.
UNIT = bm.TIME_UNITS_PER_SECOND

# Every value of every switch: the entries that take a name or a yes or no, num_back (none or some rows back) and
# the ticks of the sinusoid (the paper's, or seconds).
SWITCHES = {
    "numeric_encoder": bm.NUMERIC_ENCODERS,
    "learn_centres": (True, False),
    "missing": bm.MISSING_KINDS,
    "stage1": bm.STAGE1_KINDS,
    "stage1_fields": bm.STAGE1_FIELDS,
    "history": bm.HISTORIES,
    "interleaved_reread": bm.REREADS,
    "last_reread": (True, False),
    "layout": bm.LAYOUTS,
    "channel_identity": (True, False),
    "channel_projections": (False, True),
    "share_temporal": (True, False),
    "intra_self_attention": (True, False),
    "intra_cross_attention": (True, False),
    "intra_order": bm.INTRA_ORDERS,
    "num_back": (0, 2),
    "memory_ties": bm.TIES,
    "final_intra": (False, True),
    "readout": bm.READOUTS,
    "bank": bm.BANKS,
    "gap_encoder": bm.GAP_ENCODERS,
    "gap_ticks_per_second": (None, 1.0),
    "calendar": (False, True),
    "time_bias": (False, True),
    "head": bm.HEAD_KINDS,
}

# The arms the owner asked for by name, beside the four named configurations.
ASKED_FOR = ("WIDTH_48", "WIDTH_144", "CHANNELS_3", "CHANNELS_12", "NUMBERS_PLE16", "NUMBERS_LEARNED_PLE",
             "NUMBERS_FROZEN_CENTRES", "NUMBERS_PERIODIC", "NUMBERS_HYBRID", "GAP_SCALAR", "GAP_SINUSOID",
             "GAP_SINUSOID_SECONDS", "CALENDAR", "MISSING_LEARNED", "MEMORY_0", "MEMORY_10", "MEMORY_SLOT",
             "INTRA_SELF_FIRST", "INTRA_SELF_OFF", "INTRA_CROSS_OFF", "FINAL_INTRA_OFF", "TIME_BIAS_OFF",
             "SHARE_TEMPORAL_OFF", "CHANNEL_PROJECTIONS_ON", "CHANNEL_IDENTITY_OFF", "READOUT_ATTENTION",
             "READOUT_MEAN", "LAYOUT_STAGED", "LAYOUT_TEMPORAL_ONLY")

# The ten modules of the kit, which run side by side in one folder with torch and numpy alone.
KIT = ("best_model_template.py", "latent_channels.py", "interleaved_reread.py", "masks.py", "attention_bias.py",
       "numeric_frontend.py", "numeric_encoders.py", "time_encoders.py", "interleaved_wiring_template.py",
       "scoring_speed.py")


def _scores(model, batch):
    """Scoring-mode logits of a model as it was built (not moved)."""
    model.eval()
    with torch.no_grad():
        return model(batch)


def _built(config, seed=0):
    """A model of `config`, built from a fixed seed so that two configurations can be set side by side."""
    torch.manual_seed(seed)
    return bm.BestModel(config)


def _layer_weights(w):
    """The weights of one standard layer of width w: query, key and value packed, the way out, a feed-forward layer
    four times as wide, and two layer norms."""
    return (3 * w * w + 3 * w) + (w * w + w) + (4 * w * w + 4 * w) + (4 * w * w + w) + 2 * (2 * w)


def _sorted_inside_seconds(batch):
    """The batch with the slots of every sequence in the order of their full times, as a builder that sorts by the
    timestamp writes them; padding stays at the end."""
    valid, times = batch["mask"], batch["time_seq"]
    B, T = valid.shape
    key = torch.where(valid, times, torch.full_like(times, torch.iinfo(torch.int64).max))
    order = torch.argsort(key, dim=1, stable=True)
    rows = torch.arange(B).unsqueeze(1)
    return {name: value[rows, order] if torch.is_tensor(value) and value.dim() >= 2 and tuple(value.shape[:2]) == (B, T)
            else value for name, value in batch.items()}


# ---------------------------------------------------------------------------------------------- named configurations

def test_every_named_configuration_passes_every_check():
    """TODAY, WIDE_JOINED, CANDIDATE and CANDIDATE_LPM keep the time rule bit for bit in scoring and in training mode,
    read their history, keep padding out, score the first rows as the cut window, give every weight a gradient, read
    2026 in their times, score a second batch as a fresh copy does and keep their scores when the rows of a second
    change places or change, and print no line but the dates."""
    batch = bm.make_batch(seed=1, sequences=4, rows=30)
    for name, config in bm.CONFIGURATIONS.items():
        lines = []
        result = bm.run_checks(_built(config), batch, units_per_second=UNIT, build=lambda config=config: bm.BestModel(
            config), say=lines.append)
        assert all(result["passes"].values()), (name, result)
        assert result["kept"] == 0.0 and result["later"] > 0.0 and result["read"] > 0.0, name
        assert result["padding"] == 0.0 and result["finite"], name
        assert result["prefix"] < bm.PREFIX_TOLERANCE and result["unlearned"] == [], name
        assert result["two_batches"] == 0.0 and result["order"] <= bm.ORDER_TOLERANCE, name
        assert result["alone"] <= bm.ORDER_TOLERANCE, name
        assert result["same_second"] == 0.0, name
        assert result["first"].startswith("2026-01-01") and result["last"].startswith("2026"), name
        assert len(result["passes"]) == 7, name
        assert [line for line in lines if not line.startswith("time unit:")] == [], (name, lines)


def test_main_prints_yes_for_every_check_of_every_configuration():
    """The run of the module answers yes seven times for each named configuration, prints the dates of the batch
    once and ends with the cost table."""
    lines = []
    results, table = bm.main(sequences=3, rows=16, repeats=1, say=lines.append)
    assert list(results) == list(bm.CONFIGURATIONS)
    checked = [line for line in lines if "weights |" in line]
    assert len(checked) == len(bm.CONFIGURATIONS)
    for name, line in zip(bm.CONFIGURATIONS, checked):
        assert line.startswith(name) and line.count(": yes") == 7 and ": NO" not in line, line
        assert all(results[name]["passes"].values()), name
    assert [row["name"] for row in table] == list(bm.CONFIGURATIONS)
    assert table[0]["forward_ratio"] == 1.0 and table[0]["step_ratio"] == 1.0
    assert any("x TODAY" in line for line in lines)
    dates = [line for line in lines if line.startswith("time unit:")]
    assert len(dates) == 1 and "2026-01-01" in dates[0] and "inside" in dates[0]


def test_the_defaults_are_today_and_read_the_placeholders():
    """Config() is TODAY, its sizes are the PLACEHOLDER values, and those are the sizes of the model in use."""
    assert bm.Config() == bm.TODAY
    t = bm.TODAY
    assert (t.token_dim, t.n_bins, t.num_summary, t.stage1_layers, t.stage1_heads, t.history_layers, t.history_heads,
            t.history_len, t.dropout) == (bm.TOKEN_DIM, bm.N_BINS, bm.NUM_SUMMARY, bm.STAGE1_LAYERS, bm.STAGE1_HEADS,
                                          bm.HISTORY_LAYERS, bm.HISTORY_HEADS, bm.HISTORY_LEN, bm.DROPOUT)
    assert (bm.TOKEN_DIM, bm.N_BINS, bm.NUM_SUMMARY, bm.STAGE1_LAYERS, bm.STAGE1_HEADS, bm.HISTORY_LAYERS,
            bm.HISTORY_HEADS, bm.HISTORY_LEN) == (48, 16, 3, 2, 8, 4, 8, 120)
    assert (t.numeric_encoder, t.stage1, t.stage1_fields, t.history, t.gap_encoder, t.head) == (
        "ple", "summary", "grouped", "joined", "scalar", "linear")
    assert t.interleaved_reread is None and t.last_reread and not (t.calendar or t.time_bias)
    # The new switches default to today (no missing vector) or to the rule every arm with a memory runs.
    assert (t.missing, t.learn_centres, t.memory_ties, t.intra_order, t.gap_ticks_per_second) == (
        "zero", True, "whole_seconds", "cross_first", None)
    # Both candidates keep a missing number to its field identity, as today.
    assert bm.CANDIDATE.missing == bm.CANDIDATE_LPM.missing == "zero"
    # 64 predictors; stage 1 runs on 3 summary tokens, 4 predictors kept alone and 3 groups of the other 60.
    assert bm.N_PREDICTORS == 64 and bm.NUM_SUMMARY + bm.N_PRIORITY + bm.N_GROUPS == 10
    # A named configuration cannot be changed by accident.
    with pytest.raises(dataclasses.FrozenInstanceError):
        bm.TODAY.token_dim = 96


def test_today_has_the_shape_of_the_model_in_use():
    """TODAY: 64 tokens of 48, numbers through 16 bins, stage 1 of 2 layers and 8 heads over 10 tokens, 144 numbers
    into 4 history layers of 8 heads with a table of 121 positions, the re-read after the history, a head 144 -> 2.
    Its weights are counted by hand and set against those of the model in use."""
    model = _built(bm.TODAY).eval()
    batch = bm.make_batch(seed=3, sequences=2, rows=9)
    B, T = batch["mask"].shape
    seen = {}
    model.numbers.register_forward_hook(lambda m, inputs, out: seen.update(numbers=tuple(out.shape)))
    model.stage1.register_forward_hook(lambda m, inputs, out: seen.update(stage1=tuple(inputs[0].shape)))
    first = model.history_layers.layers[0]
    first.register_forward_hook(lambda m, inputs, out: seen.update(history=tuple(inputs[0].shape)))
    model.head.register_forward_hook(lambda m, inputs, out: seen.update(head=tuple(inputs[0].shape)))
    with torch.no_grad():
        logits = model(batch)
    assert logits.shape == (B, T, 2)
    assert seen["numbers"] == (B, T, bm.N_NUMERIC, 48)
    assert seen["stage1"] == (B * T, 10, 48)
    assert seen["history"] == (B, T, 144) and seen["head"] == (B, T, 144)
    assert model.numbers.value.weight.shape == (bm.N_NUMERIC, 16, 48)
    assert model.numbers.identity.shape == (bm.N_NUMERIC, 48)
    assert "missing" not in dict(model.numbers.named_parameters())             # no vector for a missing number today
    assert len(model.code_tables) == bm.N_CODES == 64 - bm.N_NUMERIC and model.code_bias.shape == (bm.N_CODES, 48)
    assert len(model.stage1.layers) == 2 and model.stage1.layers[0].self_attn.num_heads == 8
    assert len(model.history_layers.layers) == 4 and first.self_attn.num_heads == 8
    assert model.position.weight.shape == (121, 144) and model.last_reread is not None
    assert (model.head.in_features, model.head.out_features) == (144, 2) and model.gap.kind == "scalar"
    assert model.stage is model.pooler is model.interleaved is model.time_bias is model.calendar is None

    # The weights by hand, part by part, with the stand-in's split of the 64 predictors.
    d, W = 48, 144
    numbers = bm.N_NUMERIC * 16 * d + bm.N_NUMERIC * d             # W_c over 16 bins and b_c, the field identity
    codes = bm.N_CODES * bm.CODE_SIZE * d + bm.N_CODES * d         # a table per code field and its bias
    stage1 = 3 * d + 2 * _layer_weights(d)                         # the summary tokens and two layers
    history = 121 * W + 4 * _layer_weights(W)                      # the position table and four layers
    gap = 2 * W                                                    # a learned vector times log(1 + gap), and a bias
    last = 2 * (2 * d) + (3 * d * d + 3 * d) + (d * d + d) + (W * W + W)   # two norms, the attention, the write-back
    head = W * 2 + 2
    by_hand = numbers + codes + stage1 + history + gap + last + head
    n = bm.count_weights(model)
    assert n == by_hand == 1_155_602
    assert sum(bm.weights_by_part(model).values()) == n
    # The model in use has more weights; with everything else alike, the difference is code values of 48 numbers.
    fewer = bm.WEIGHTS_IN_USE - n
    assert 0 < fewer < bm.WEIGHTS_IN_USE // 2
    print(f"TODAY has {n:,} weights, the model in use {bm.WEIGHTS_IN_USE:,}: {fewer:,} fewer, about {fewer / d:,.0f} "
          f"code values of {d} numbers; the stand-in's {bm.N_CODES} code tables hold {bm.CODE_SIZE} values each")


def test_wide_joined_and_the_candidates_have_the_widths_stated():
    """WIDE_JOINED: tokens of 96, three summary outputs joined into 288, 4 heads of 24 in stage 1 and 4 of 72 in the
    history. CANDIDATE: tokens of 96 through 32 bins, stage 1 with 4 heads of 24 over 6 summary tokens and the 7
    grouped inputs, six channels of 96 through 4 interleaved pairs with 4 heads of 24 that read the 64 predictor
    tokens and those of 5 earlier rows, the final block, the bias the stage builds, the gap in bins, 576 numbers to the
    head. CANDIDATE_LPM: the pooler over the 64 tokens, the hybrid encoder with 33 centres (32 intervals) and branches
    of 32 (32 directions), no final block, 96 numbers to the head."""
    batch = bm.make_batch(seed=4, sequences=2, rows=12)
    B, T = batch["mask"].shape

    wide = _built(bm.WIDE_JOINED).eval()
    seen = {}
    wide.stage1.register_forward_hook(lambda m, inputs, out: seen.update(stage1=tuple(inputs[0].shape)))
    with torch.no_grad():
        exported = wide.export(batch)
    assert wide.numbers.value.weight.shape == (bm.N_NUMERIC, 16, 96) and wide.summary.shape == (1, 3, 96)
    assert seen["stage1"] == (B * T, 10, 96)
    attention = wide.stage1.layers[0].self_attn
    assert (attention.num_heads, attention.head_dim) == (4, 24)
    attention = wide.history_layers.layers[0].self_attn
    assert (attention.embed_dim, attention.num_heads, attention.head_dim) == (288, 4, 72)
    assert len(wide.history_layers.layers) == 4 and wide.position.weight.shape == (121, 288)
    assert wide.last_reread.width == 288 and wide.out_dim == 288 and exported.shape == (B, T, 288)

    candidate = _built(bm.CANDIDATE).eval()
    stage = candidate.stage
    seen = {}
    candidate.stage1.register_forward_hook(lambda m, inputs, out: seen.update(stage1=tuple(inputs[0].shape)))
    stage.register_forward_pre_hook(lambda m, inputs: seen.update(channels=tuple(inputs[0].shape),
                                                                  fields=tuple(inputs[1].shape)))
    stage.bank.register_forward_hook(lambda m, inputs, out: seen.update(keys=tuple(out[0].shape)))
    stage.time_bias.register_forward_hook(lambda m, inputs, out: seen.update(bias=tuple(out.shape)))
    with torch.no_grad():
        exported = candidate.export(batch)
    assert candidate.numbers.value.weight.shape == (bm.N_NUMERIC, 32, 96)
    assert seen["stage1"] == (B * T, 6 + 7, 96)
    attention = candidate.stage1.layers[0].self_attn
    assert (attention.num_heads, attention.head_dim) == (4, 24)
    assert seen["channels"] == (B, T, 6, 96) and seen["fields"] == (B, T, 64, 96)
    assert seen["keys"] == (B, T, (1 + 5) * 64, 96) and seen["bias"] == (B, 4, T, T)
    s = stage.settings
    assert (s["channel_dim"], s["num_channels"], s["num_heads"], s["num_pairs"], s["layout"]) == (96, 6, 4, 4,
                                                                                                  "interleaved")
    assert (s["intra_self_attention"], s["intra_cross_attention"], s["share_temporal"], s["channel_identity"],
            s["channel_projections"], s["final_intra"], s["readout"], s["num_back"]) == (True, True, True, True,
                                                                                         False, True, "concat", 5)
    assert (s["ties"], s["intra_order"], s["time_bias"]) == ("whole_seconds", "cross_first", True)
    # The stage owns the bias, built with its heads and its unit; the model holds none of its own.
    assert candidate.time_bias is None and stage.time_bias.units_per_second == UNIT
    assert stage.final_within is not None and candidate.gap.kind == "ple" and candidate.gap.token_dim == 96
    assert candidate.out_dim == 576 and exported.shape == (B, T, 576) and candidate.head.in_features == 576

    lpm = _built(bm.CANDIDATE_LPM).eval()
    seen = {}
    lpm.pooler.register_forward_pre_hook(lambda m, inputs: seen.update(pooled=tuple(inputs[0].shape)))
    with torch.no_grad():
        exported = lpm.export(batch)
    assert lpm.stage1 is None and lpm.pooler.queries.shape == (6, 96) and seen["pooled"] == (B, T, 64, 96)
    assert lpm.numbers.kind == "hybrid" and lpm.stage.final_within is None
    # 32 intervals with 32 directions: 33 centres and every branch 32 wide.
    assert (lpm.numbers.settings["n_centres"], lpm.numbers.settings["branch_dim"]) == (33, 32)
    assert lpm.numbers.learned_bins().centres().shape == (bm.N_NUMERIC, 33)
    assert lpm.stage.settings["readout"] == "attention"
    assert lpm.out_dim == 96 and exported.shape == (B, T, 96)


def test_every_entry_of_the_configuration_has_a_docstring():
    """In the source, every entry of Config is followed by a string of its own, in the order of the entries."""
    tree = ast.parse(Path(bm.__file__).read_text())
    config = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "Config")
    names = []
    for place, node in enumerate(config.body):
        if isinstance(node, ast.AnnAssign):
            after = config.body[place + 1] if place + 1 < len(config.body) else None
            assert isinstance(after, ast.Expr) and isinstance(after.value, ast.Constant), node.target.id
            assert isinstance(after.value.value, str) and len(after.value.value.split()) >= 5, node.target.id
            names.append(node.target.id)
    assert names == [entry.name for entry in dataclasses.fields(bm.Config)]


def test_every_named_configuration_has_a_docstring_with_its_reasons():
    """Each named configuration is followed by a string; the two candidates name every entry in which they differ
    from the configuration they are made from, with what a source says and what is judgement."""
    tree = ast.parse(Path(bm.__file__).read_text())
    docs = {}
    for place, node in enumerate(tree.body):
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
            if name in bm.CONFIGURATIONS:
                after = tree.body[place + 1]
                assert isinstance(after, ast.Expr) and isinstance(after.value.value, str), name
                docs[name] = after.value.value
    assert set(docs) == set(bm.CONFIGURATIONS)
    for name, base in (("CANDIDATE", bm.TODAY), ("CANDIDATE_LPM", bm.CANDIDATE)):
        config = bm.CONFIGURATIONS[name]
        differ = [entry.name for entry in dataclasses.fields(bm.Config)
                  if getattr(config, entry.name) != getattr(base, entry.name)]
        assert differ, name
        for entry in differ:
            assert entry in docs[name], (name, entry)
        assert "read:" in docs[name] and "judgement" in docs[name] and "arXiv 2611.15814" in docs[name]
    assert "Table" in docs["CANDIDATE"] and "Eq. 8" in docs["CANDIDATE_LPM"]
    # The new switches are explained where the candidate sets them, and the old claim about the order is gone.
    for entry in ("missing", "memory_ties", "intra_order", "time_bias"):
        assert entry in docs["CANDIDATE"], entry
    assert "32 directions" in docs["CANDIDATE_LPM"] and "before they read the fields" not in docs["CANDIDATE_LPM"]


def test_the_new_switches_reach_the_pieces_they_name():
    """memory_ties and intra_order reach the stage, its memory and its blocks; memory_ties reaches the memory of the
    joined re-reads; the channel stage builds its own time bias and the joined history its; learn_centres holds the
    centres still; missing makes a learned vector or a fixed zero; the ticks of the sinusoid reach the gap encoder."""
    slot = _built(replace(bm.CANDIDATE, memory_ties="slot", intra_order="self_first"))
    assert slot.stage.ties == "slot" and slot.stage.bank.ties == "slot" and slot.stage.intra_order == "self_first"
    assert all(block.intra_order == "self_first" for block in [*slot.stage.within, slot.stage.final_within])
    candidate = _built(bm.CANDIDATE)
    assert candidate.stage.bank.ties == "whole_seconds"
    assert all(block.intra_order == "cross_first" for block in candidate.stage.within)
    assert isinstance(candidate.stage.time_bias, bm.AttentionBias) and candidate.time_bias is None
    assert _built(replace(bm.CANDIDATE, time_bias=False)).stage.time_bias is None
    for ties in bm.TIES:
        joined = _built(replace(bm.TODAY, interleaved_reread="AM", memory_ties=ties))
        assert joined.interleaved.memory.ties == ties
    joined = _built(replace(bm.TODAY, time_bias=True))
    assert isinstance(joined.time_bias, bm.AttentionBias) and joined.time_bias.units_per_second == UNIT
    frozen = _built(replace(bm.CANDIDATE, numeric_encoder="learned_ple", learn_centres=False))
    moving = _built(replace(bm.CANDIDATE, numeric_encoder="learned_ple"))
    assert not any(weight.requires_grad for weight in bm.centre_parameters(frozen))
    assert all(weight.requires_grad for weight in bm.centre_parameters(moving))
    assert len(bm.centre_parameters(moving)) == 2
    learned = _built(replace(bm.CANDIDATE, missing="learned"))
    assert isinstance(learned.numbers.missing, nn.Parameter)
    assert "missing" not in dict(candidate.numbers.named_parameters())
    assert not candidate.numbers.missing.any()
    seconds = _built(bm.ARMS["GAP_SINUSOID_SECONDS"].config)
    assert seconds.gap.ticks_per_second == 1.0
    assert _built(bm.ARMS["GAP_SINUSOID"].config).gap.ticks_per_second == bm.SINUSOID_TICKS_PER_SECOND


def test_inactive_names_every_entry_without_effect():
    """n_frequencies has no effect on learned_ple, learn_centres none on ple and periodic, memory_ties none without a
    memory of earlier rows, intra_order none with fewer than two attention parts, and the ticks none without the
    sinusoid; each is listed, and an entry that does act is not."""
    assert "n_frequencies" in bm.inactive(replace(bm.TODAY, numeric_encoder="learned_ple"))
    assert "n_frequencies" not in bm.inactive(replace(bm.TODAY, numeric_encoder="hybrid"))
    assert "learn_centres" in bm.inactive(bm.TODAY)
    assert "learn_centres" in bm.inactive(replace(bm.TODAY, numeric_encoder="periodic"))
    assert "learn_centres" not in bm.inactive(replace(bm.TODAY, numeric_encoder="hybrid"))
    assert "memory_ties" in bm.inactive(bm.TODAY) and "memory_ties" not in bm.inactive(bm.CANDIDATE)
    assert "memory_ties" in bm.inactive(replace(bm.CANDIDATE, num_back=0))
    assert "memory_ties" in bm.inactive(replace(bm.CANDIDATE, intra_cross_attention=False))
    assert "memory_ties" in bm.inactive(replace(bm.TODAY, interleaved_reread="A"))
    assert "memory_ties" not in bm.inactive(replace(bm.TODAY, interleaved_reread="M"))
    assert "intra_order" in bm.inactive(bm.TODAY) and "intra_order" not in bm.inactive(bm.CANDIDATE)
    assert "intra_order" in bm.inactive(replace(bm.CANDIDATE, intra_self_attention=False))
    assert "gap_ticks_per_second" in bm.inactive(bm.CANDIDATE)
    assert "gap_ticks_per_second" not in bm.inactive(bm.ARMS["GAP_SINUSOID"].config)


# ---------------------------------------------------------------------------------------------- the arms

def test_the_arms_change_one_entry_each_and_answer_one_question():
    """ARMS starts with the four named configurations; every other arm differs from the arm it is set against in one
    entry, which has an effect in the arm; every arm asks one question; the arms the owner named are all there."""
    names = list(bm.ARMS)
    assert names[:4] == list(bm.CONFIGURATIONS)
    assert all(bm.ARMS[name].config == config for name, config in bm.CONFIGURATIONS.items())
    assert set(ASKED_FOR) <= set(names)
    assert len({arm.config for arm in bm.ARMS.values()}) == len(bm.ARMS)           # no arm is another arm twice
    for place, (name, arm) in enumerate(bm.ARMS.items()):
        bm.check_config(arm.config)
        question = arm.question
        assert question.endswith("?") and question.count("?") == 1 and ". " not in question, name
        assert question.isascii() and len(question.split()) >= 5, name
        if arm.against is None:
            assert name == "TODAY" and bm.arm_change(name) == "the model in use"
            continue
        assert arm.against in names[:place], name
        base = bm.ARMS[arm.against].config
        differ = [entry.name for entry in dataclasses.fields(bm.Config)
                  if getattr(arm.config, entry.name) != getattr(base, entry.name)]
        assert bm.arm_change(name).count("->") == len(differ) >= 1, name
        if name not in bm.CONFIGURATIONS:
            assert len(differ) == 1, (name, differ)
            assert differ[0] not in bm.inactive(arm.config), (name, differ)
    configs = {name: arm.config for name, arm in bm.ARMS.items()}
    assert [configs[n].token_dim for n in ("WIDTH_48", "CANDIDATE", "WIDTH_144")] == [48, 96, 144]
    assert [configs[n].num_summary for n in ("CHANNELS_3", "CANDIDATE", "CHANNELS_12")] == [3, 6, 12]
    assert [configs[n].num_back for n in ("MEMORY_0", "CANDIDATE", "MEMORY_10")] == [0, 5, 10]
    assert (configs["NUMBERS_PLE16"].n_bins, configs["CANDIDATE"].n_bins, configs["CANDIDATE"].numeric_encoder) == (
        16, 32, "ple")
    assert not configs["NUMBERS_FROZEN_CENTRES"].learn_centres
    assert configs["NUMBERS_FROZEN_CENTRES"].numeric_encoder == "learned_ple"
    assert configs["GAP_SINUSOID"].gap_ticks_per_second is None
    assert configs["GAP_SINUSOID_SECONDS"].gap_ticks_per_second == 1.0
    assert bm.ARMS["GAP_SINUSOID_SECONDS"].against == "GAP_SINUSOID"
    assert bm.ARMS["NUMBERS_FROZEN_CENTRES"].against == "NUMBERS_LEARNED_PLE"
    assert configs["MEMORY_SLOT"].memory_ties == "slot" and configs["MISSING_LEARNED"].missing == "learned"


def test_the_list_prints_every_arm_and_compare_takes_names():
    """arm_table gives every arm with its weights, change and question; compare runs any arms by name, TODAY first;
    a name that is not an arm is a plain error; --list prints every arm from the command line."""
    lines = []
    rows = bm.arm_table(["CANDIDATE", "WIDTH_48"], say=lines.append)
    assert [row["name"] for row in rows] == ["CANDIDATE", "WIDTH_48"]
    assert rows[1]["weights"] == bm.count_weights(_built(bm.ARMS["WIDTH_48"].config))
    assert rows[1]["change"] == "token_dim: 96 -> 48" and rows[1]["against"] == "CANDIDATE"
    assert "compared with" in lines[0] and any(bm.ARMS["WIDTH_48"].question in line for line in lines)
    batch = bm.make_batch(seed=12, sequences=2, rows=12)
    table = bm.compare(["WIDTH_48"], batch, repeats=1, say=lambda line: None)
    assert [row["name"] for row in table] == ["TODAY", "WIDTH_48"]
    with pytest.raises(ValueError, match="no arm is named"):
        bm.compare(["WIDTH_47"], batch, repeats=1, say=lambda line: None)
    env = {name: value for name, value in os.environ.items() if name != "PYTHONPATH"}
    env.update(OMP_NUM_THREADS="1", MKL_NUM_THREADS="1")
    result = subprocess.run([sys.executable, str(Path(bm.__file__)), "--list"], env=env, capture_output=True,
                            text=True, timeout=900)
    assert result.returncode == 0, result.stderr
    for name, arm in bm.ARMS.items():
        assert any(line.startswith(name + " ") for line in result.stdout.splitlines()), name
        assert arm.question in result.stdout, name


# ---------------------------------------------------------------------------------------------- the grid of switches

def _setting(name, value, g):
    """A random setting of every switch with `name` at `value`, moved where needed so that `name` has an effect."""
    def pick(values):
        return values[int(torch.randint(len(values), (1,), generator=g))]

    choice = {other: pick(values) for other, values in SWITCHES.items()}
    choice[name] = value
    if name in bm.CHANNEL_ENTRIES:
        choice["history"] = "channels"
    if name in ("interleaved_reread", "last_reread"):
        choice["history"] = "joined"
    if name == "stage1_fields":
        choice["stage1"] = "summary"
    if name == "learn_centres" and choice["numeric_encoder"] in ("ple", "periodic"):
        choice["numeric_encoder"] = "learned_ple"
    if name == "gap_ticks_per_second":
        choice["gap_encoder"] = "sinusoid"
    if name == "intra_order":
        choice["intra_self_attention"] = choice["intra_cross_attention"] = True
    if name == "memory_ties":
        if choice["history"] == "channels":
            choice["intra_cross_attention"], choice["num_back"] = True, 2
        else:
            choice["interleaved_reread"] = "AM" if choice["interleaved_reread"] in (None, "A") else "M"
    within = ("intra_self_attention", "intra_cross_attention", "intra_order", "num_back", "memory_ties", "bank")
    if name in within and choice["history"] == "channels":
        # A within-transaction block, so that the entry acts on something.
        if choice["layout"] == "temporal_only" and not choice["final_intra"]:
            choice["layout"] = "interleaved"
    if name in ("num_back", "bank") and choice["history"] == "channels":
        choice["intra_cross_attention"] = True
    if name == "bank" and choice["history"] == "joined" and choice["interleaved_reread"] is None:
        choice["interleaved_reread"] = "AM"
    if choice["bank"] == "stage1" and choice["stage1"] == "pooler":
        # The pooler leaves no field outputs of stage 1 for the bank to read.
        if name == "bank":
            choice["stage1"] = "summary"
        else:
            choice["bank"] = "predictor"
    return replace(bm.TODAY, **SMALL, **choice)


def _grid():
    """One setting for every value of every switch, each with that switch in effect: (switch, value, Config)."""
    g = torch.Generator().manual_seed(11)
    return [(name, value, _setting(name, value, g)) for name, values in SWITCHES.items() for value in values]


def test_the_grid_covers_every_value_of_every_switch_where_it_has_an_effect():
    """Every value of every switch is in the grid, in a setting where `inactive` does not list that switch."""
    grid = _grid()
    for name, values in SWITCHES.items():
        for value in values:
            assert any(n == name and getattr(c, name) == value and name not in bm.inactive(c)
                       for n, _, c in grid), (name, value)
    assert len(grid) == sum(len(values) for values in SWITCHES.values())


def test_every_setting_of_the_grid_builds_runs_trains_and_keeps_the_time_rule():
    """Each setting builds, gives finite logits for every real row, takes one training step with finite gradients,
    and keeps the time rule: later rows and padding change no earlier real row, in scoring and in training mode,
    later rows read the earlier ones, the first rows score as the cut window, a second batch scores as on a fresh
    copy, no row reads another row of its own second, and, unless a memory takes rows by slot, the order inside a
    second moves no score."""
    batch = bm.make_batch(seed=2, sequences=3, rows=12)
    valid = batch["mask"]
    B, T = valid.shape
    for name, value, config in _grid():
        model = _built(config, seed=1)
        logits = _scores(model, batch)
        assert logits.shape == (B, T, 2) and torch.isfinite(logits[valid]).all(), (name, value)
        model.train()
        optimiser = torch.optim.AdamW(bm.param_groups(model, lr=1e-3))
        optimiser.zero_grad()
        loss = bm.row_loss(model, batch)
        loss.backward()
        assert torch.isfinite(loss), (name, value)
        assert all(w.grad is None or torch.isfinite(w.grad).all() for w in model.parameters()), (name, value)
        optimiser.step()
        kept, later, read = bm.later_rows_change_nothing(model, batch, units_per_second=UNIT)
        assert kept == 0.0 and later > 0.0 and read > 0.0, (name, value, config)
        change, finite = bm.padding_stays_out(model, batch)
        assert change == 0.0 and finite, (name, value, config)
        assert bm.prefix_agrees(model, batch, units_per_second=UNIT) < bm.PREFIX_TOLERANCE, (name, value, config)
        two, alone = bm.one_model_two_batches(model, batch, units_per_second=UNIT)
        assert two == 0.0 and alone <= bm.ORDER_TOLERANCE, (name, value, config)
        order, same_second = bm.order_inside_a_second(model, batch, units_per_second=UNIT)
        assert same_second == 0.0, (name, value, config)
        if not (bm.reads_memory(config) and config.memory_ties == "slot"):
            assert order <= bm.ORDER_TOLERANCE, (name, value)


def test_every_weight_learns_in_every_setting_of_the_grid():
    """One training step of a moved copy gives every weight of every setting of the grid a gradient."""
    batch = bm.make_batch(seed=5, sequences=3, rows=12)
    for name, value, config in _grid():
        assert bm.every_weight_learns(_built(config, seed=2), batch) == [], (name, value, config)


# ---------------------------------------------------------------------------------------------- the checks can fail

class _RowByItself(nn.Module):
    """A model whose score of a row comes from that row alone: it keeps the time rule, and reads no history."""

    def __init__(self):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(2))

    def row(self, batch):
        return torch.nan_to_num(batch["continuous"], nan=0.0, posinf=0.0).clamp(-10, 10).mean(dim=-1)   # [B, T]

    def forward(self, batch):
        x = self.row(batch)
        return torch.stack([x, -x], dim=-1) * self.weight


def _earlier_mean(x, batch):
    """For every row, the mean of x over the real rows of strictly earlier whole seconds of its sequence, [B, T], in
    the number type of x, so that a model built on it runs in 64 bits as in 32."""
    valid = batch["mask"].bool()
    seconds = torch.div(batch["time_seq"], UNIT, rounding_mode="floor")
    earlier = (seconds.unsqueeze(1) < seconds.unsqueeze(2)) & valid.unsqueeze(1) & valid.unsqueeze(2)   # [b, i, j]
    return (earlier.to(x.dtype) @ x.unsqueeze(-1)).squeeze(-1) / earlier.sum(dim=-1).clamp(min=1)


class _ReadsEarlierSeconds(_RowByItself):
    """Every score holds the mean of the real rows of strictly earlier seconds: it reads its history and keeps every
    rule the checks test."""

    def forward(self, batch):
        x = self.row(batch)
        mean = _earlier_mean(x, batch)
        return torch.stack([x + 0.5 * mean, x - 0.5 * mean], dim=-1) * self.weight


class _ReadsTheFuture(nn.Module):
    """TODAY plus, on every real row, a map of the mean numbers of every real row of its sequence, later rows
    included: a leak through the numbers of later rows."""

    def __init__(self):
        super().__init__()
        torch.manual_seed(0)
        self.inner = bm.BestModel(bm.TODAY)
        self.w = nn.Linear(bm.N_NUMERIC, 2)

    def forward(self, batch):
        valid = batch["mask"]
        x = torch.nan_to_num(batch["continuous"], nan=0.0) * valid.unsqueeze(-1)
        mean = x.sum(dim=1, keepdim=True) / valid.sum(dim=1, keepdim=True).clamp(min=1).unsqueeze(-1)
        return self.inner(batch) + self.w(mean) * valid.unsqueeze(-1)


class _SameSecondMean(nn.Module):
    """TODAY plus a map of the mean numbers of the other real rows of a row's own whole second: a leak inside one
    second that no order of the rows of that second can show."""

    def __init__(self):
        super().__init__()
        torch.manual_seed(0)
        self.inner = bm.BestModel(bm.TODAY)
        self.w = nn.Linear(bm.N_NUMERIC, 2)

    def forward(self, batch):
        seconds = torch.div(batch["time_seq"], UNIT, rounding_mode="floor")
        valid = batch["mask"]
        same = (seconds.unsqueeze(1) == seconds.unsqueeze(2)) & valid.unsqueeze(1) & valid.unsqueeze(2)
        same = same & ~torch.eye(seconds.shape[1], dtype=torch.bool)
        x = torch.nan_to_num(batch["continuous"], nan=0.0)
        mean = (same.float() @ x) / same.sum(dim=-1, keepdim=True).clamp(min=1)
        return self.inner(batch) + self.w(mean)


class _NormedNumbers(nn.Module):
    """TODAY with a batch norm over the numbers of every slot of the batch, then a sigmoid that keeps them on [0, 1]:
    in training the norm reads the statistics of the whole batch, later rows and padding included; in scoring it
    reads its running statistics, and nothing leaks."""

    def __init__(self):
        super().__init__()
        torch.manual_seed(0)
        self.norm = nn.BatchNorm1d(bm.N_NUMERIC)
        self.inner = bm.BestModel(bm.TODAY)

    def forward(self, batch):
        raw = batch["continuous"]
        B, T, C = raw.shape
        x = torch.sigmoid(self.norm(torch.nan_to_num(raw, nan=0.0).reshape(B * T, C))).reshape(B, T, C)
        return self.inner({**batch, "continuous": torch.where(torch.isnan(raw), raw, x)})


class _NormedLogits(nn.Module):
    """TODAY with a batch norm over the two logits of every slot of the batch: a leak in training mode only."""

    def __init__(self):
        super().__init__()
        torch.manual_seed(0)
        self.inner = bm.BestModel(bm.TODAY)
        self.norm = nn.BatchNorm1d(2)

    def forward(self, batch):
        out = self.inner(batch)
        B, T, K = out.shape
        return self.norm(out.reshape(B * T, K)).reshape(B, T, K)


class _LazyOrigin(nn.Module):
    """TODAY plus a term of the days since an origin that is fixed on the first call: the earliest whole second of the
    first batch the instance scores. Right on every batch for a fresh copy, and wrong after a first batch."""

    def __init__(self):
        super().__init__()
        torch.manual_seed(0)
        self.inner = bm.BestModel(bm.TODAY)
        self.w = nn.Parameter(torch.tensor([0.5, -0.5]))
        self.register_buffer("origin", torch.tensor(-1, dtype=torch.long))

    def forward(self, batch):
        seconds = torch.div(batch["time_seq"], UNIT, rounding_mode="floor")
        if int(self.origin) < 0:
            self.origin.fill_(int(seconds[batch["mask"]].min()))
        days = (seconds - self.origin).clamp(min=0).float() / 86_400.0
        return self.inner(batch) + self.w * torch.log1p(days).unsqueeze(-1)


class _ReadsEveryRow(_RowByItself):
    """Every score holds the mean of every real row of its sequence, later rows included: a leak."""

    def forward(self, batch):
        x, valid = self.row(batch), batch["mask"].bool()
        context = (x * valid).sum(dim=1, keepdim=True) / valid.sum(dim=1, keepdim=True).clamp(min=1)
        return torch.stack([x + context, x - context], dim=-1) * self.weight


class _ReadsPadding(_RowByItself):
    """Every score holds the raw sum of every slot of its sequence, padding included."""

    def forward(self, batch):
        x = self.row(batch) + batch["continuous"].sum(dim=(1, 2)).unsqueeze(1) * 0.001
        return torch.stack([x, -x], dim=-1) * self.weight


class _KnowsItsWindow(_RowByItself):
    """Every score depends on how many slots the window has: cutting the window changes it."""

    def forward(self, batch):
        x = self.row(batch) * batch["mask"].shape[1]
        return torch.stack([x, -x], dim=-1) * self.weight


class _UnusedWeight(_RowByItself):
    """A model with a weight that nothing reads."""

    def __init__(self):
        super().__init__()
        self.unused = nn.Parameter(torch.zeros(3))


class _ReadsLatestTime(_RowByItself):
    """Every score holds the hour of the day of the latest real row of its sequence: a leak through the times of
    later rows, which an `alter` that keeps the times cannot show."""

    def forward(self, batch):
        x, valid, times = self.row(batch), batch["mask"].bool(), batch["time_seq"]
        latest = torch.where(valid, times, torch.zeros_like(times)).amax(dim=1, keepdim=True)
        hour = (torch.div(latest, UNIT, rounding_mode="floor") % 86_400).float() / 86_400
        return torch.stack([x + hour, x - hour], dim=-1) * self.weight


class _OrdersItsSecond(_RowByItself):
    """Every score holds how many real rows of its own whole second have a smaller time: the rows of one second put
    in an order by the part inside the second, as a model that reads nanoseconds as seconds puts them."""

    def forward(self, batch):
        x, valid, times = self.row(batch), batch["mask"].bool(), batch["time_seq"]
        seconds = torch.div(times, UNIT, rounding_mode="floor")
        both = valid.unsqueeze(1) & valid.unsqueeze(2)
        first = (seconds.unsqueeze(1) == seconds.unsqueeze(2)) & (times.unsqueeze(1) < times.unsqueeze(2)) & both
        count = first.sum(dim=-1).float() * 0.1
        return torch.stack([x + count, x - count], dim=-1) * self.weight


class _KeepsFirstCall(_ReadsEarlierSeconds):
    """Reads its history, keeps the hour of the day of every slot of the first batch it scores and adds it to every
    score after that: right for that batch, since a row reads only its own time, and wrong for every other batch."""

    def __init__(self):
        super().__init__()
        self.kept = None

    def forward(self, batch):
        out = super().forward(batch)
        if self.kept is None:
            seconds = torch.div(batch["time_seq"], UNIT, rounding_mode="floor")
            self.kept = (seconds % 86_400).float() / 86_400
        # A cut batch reads the first slots of what it kept, so the cut of check 3 agrees with the whole.
        hour = self.kept[:, :out.shape[1]]
        return out + torch.stack([hour, -hour], dim=-1) * self.weight


class _CachedBias(nn.Module):
    """An AttentionBias whose first bias is kept for every call after it: 'once per batch' read as 'once'."""

    def __init__(self, inner):
        super().__init__()
        self.inner, self.kept = inner, None

    def forward(self, values, times, valid):
        if self.kept is None:
            self.kept = self.inner(values, times, valid)
        return self.kept


class _ReadsFirstSlotOfLastSecond(_RowByItself):
    """Every score holds the mean of the real rows of strictly earlier seconds and the value of the row in the first
    slot of the latest strictly earlier second: a reading that the order of the rows inside that second decides, as a
    memory that takes rows by their slots does."""

    def forward(self, batch):
        x, valid = self.row(batch), batch["mask"].bool()
        seconds = torch.div(batch["time_seq"], UNIT, rounding_mode="floor")
        earlier = (seconds.unsqueeze(1) < seconds.unsqueeze(2)) & valid.unsqueeze(1) & valid.unsqueeze(2)
        last = torch.where(earlier, seconds.unsqueeze(1), torch.full_like(earlier, 0, dtype=seconds.dtype)).amax(-1)
        there = earlier & (seconds.unsqueeze(1) == last.unsqueeze(-1))                 # [b, i, j]: j in that second
        first = there.long().argmax(dim=-1)                                            # the smallest such slot
        value = torch.gather(x, 1, first) * there.any(dim=-1) + _earlier_mean(x, batch)
        return torch.stack([x + 0.5 * value, x - 0.5 * value], dim=-1) * self.weight


def test_the_checks_pass_any_model_that_keeps_their_rules_and_fail_one_that_breaks_them():
    """Each check takes any model; on a model that breaks its rule it gives a failing answer. A model that keeps
    the rule and reads its history passes all seven; one that reads no history fails the first check alone, and a
    printed line says why."""
    batch = bm.make_batch(seed=6, sequences=4, rows=20)
    assert all(bm.run_checks(_ReadsEarlierSeconds(), batch, units_per_second=UNIT)["passes"].values())
    lines = []
    alone = bm.run_checks(_RowByItself(), batch, units_per_second=UNIT, say=lines.append)
    assert [name for name, ok in alone["passes"].items() if not ok] == ["later rows"]
    assert alone["kept"] == 0.0 and alone["later"] > 0.0 and alone["read"] == 0.0
    assert any("reads no history" in line for line in lines)
    kept, later, read = bm.later_rows_change_nothing(_ReadsEveryRow(), batch, units_per_second=UNIT)
    assert kept > 0.0 and later > 0.0
    change, finite = bm.padding_stays_out(_ReadsPadding(), batch)
    assert change > 0.0 or not finite
    assert bm.prefix_agrees(_KnowsItsWindow(), batch, units_per_second=UNIT) > bm.PREFIX_TOLERANCE
    assert bm.every_weight_learns(_UnusedWeight(), batch) == ["unused"]
    result = bm.run_checks(_ReadsEveryRow(), batch, units_per_second=UNIT)
    assert not result["passes"]["later rows"] and not result["passes"]["prefix"]


def test_the_checks_take_the_unit_from_the_caller_only():
    """run_checks and every check that measures seconds stop with a plain error without the unit of the caller; the
    unit of the model is never read in its place. Check 6 needs it only to build its own second batch."""
    batch = bm.make_batch(seed=13, sequences=2, rows=10)
    model = _ReadsEarlierSeconds()
    for call in (lambda: bm.run_checks(model, batch), lambda: bm.later_rows_change_nothing(model, batch),
                 lambda: bm.time_unit_fits(batch), lambda: bm.order_inside_a_second(model, batch),
                 lambda: bm.prefix_agrees(model, batch), lambda: bm.one_model_two_batches(model, batch)):
        with pytest.raises(ValueError, match="units_per_second"):
            call()
    with pytest.raises(ValueError, match="units_per_second"):
        bm.run_checks(model, batch, units_per_second=0)
    # A second batch from the caller needs no unit.
    assert bm.one_model_two_batches(model, batch, other=bm.make_batch(seed=14, sequences=2, rows=10)) == (0.0, 0.0)


def test_the_time_unit_check_prints_the_dates_and_fails_a_unit_that_does_not_fit():
    """Nanosecond times read with 1e9 lie in 2026 and pass, also with the unit written as a float; read as seconds
    they give a year in the billions, and seconds read as nanoseconds give 1970: both fail, with the dates printed."""
    batch = bm.make_batch(seed=14, sequences=3, rows=12)
    lines = []
    first, last, fits = bm.time_unit_fits(batch, UNIT, say=lines.append)
    assert fits and first.startswith("2026-01-01") and last.startswith("2026") and "inside" in lines[-1]
    assert bm.time_unit_fits(batch, 1e9, say=lines.append)[2]
    first, last, fits = bm.time_unit_fits(batch, 1, say=lines.append)
    assert not fits and first.startswith("year ") and "OUTSIDE" in lines[-1]
    as_seconds = dict(batch, time_seq=torch.div(batch["time_seq"], UNIT, rounding_mode="floor"))
    first, last, fits = bm.time_unit_fits(as_seconds, UNIT, say=lines.append)
    assert not fits and first.startswith("1970-01-01")
    assert bm.time_unit_fits(as_seconds, 1, say=lines.append)[2]
    # A mask that names no real row gives no date and no pass.
    nothing = dict(batch, nothing_real=torch.zeros_like(batch["mask"]))
    assert bm.time_unit_fits(nothing, UNIT, real="nothing_real", say=lines.append) == (None, None, False)


def test_a_model_that_reads_nanoseconds_as_seconds_no_longer_passes_on_a_sorted_batch(monkeypatch):
    """A model and its checks that share the unit 1 on nanosecond times passed the four first checks on a batch sorted
    by time, while rows of one second read each other. The time unit check now fails it, and check 1 with the right
    unit sees the leak."""
    batch = _sorted_inside_seconds(bm.make_batch(seed=15, sequences=6, rows=40))
    monkeypatch.setattr(bm, "TIME_UNITS_PER_SECOND", 1)
    for config in (bm.TODAY, bm.CANDIDATE):
        model = _built(config)
        assert model.units_per_second == 1
        result = bm.run_checks(model, batch, units_per_second=model.units_per_second, say=lambda line: None)
        assert not result["passes"]["time unit"] and not all(result["passes"].values()), config.history
        kept, later, read = bm.later_rows_change_nothing(model, batch, units_per_second=UNIT, say=lambda line: None)
        assert kept > 0.0, config.history


def test_the_first_check_moves_the_times_of_later_rows():
    """A score that reads the time of the latest row of its sequence leaks later rows through their times; check 1
    pushes the later rows out in time and sees it, and with the times kept it does not."""
    batch = bm.make_batch(seed=16, sequences=4, rows=24)
    kept, later, read = bm.later_rows_change_nothing(_ReadsLatestTime(), batch, units_per_second=UNIT)
    assert kept > 0.0
    kept, later, read = bm.later_rows_change_nothing(_ReadsLatestTime(), batch, units_per_second=UNIT,
                                                     move_times=False)
    assert kept == 0.0 and later > 0.0
    # A model that keeps the rule keeps every kept row to the bit while the times move.
    assert bm.later_rows_change_nothing(_built(replace(bm.CANDIDATE, **SMALL)), batch, units_per_second=UNIT)[0] == 0.0


def test_the_first_check_keeps_every_kept_time_and_the_time_order():
    """Check 1 gave every real row a new part inside its second, so a model that reads its own time to the nanosecond,
    which the rule allows, failed it, and a batch in time order by slot came out of order, which the model in use
    stops on. The rows of later seconds now move by whole seconds, each keeping its part inside the second, and no
    kept row's time changes: that model passes, a model that takes only batches in time order passes check 1, and a
    row that puts the rows of its second in an order by their nanoseconds is still seen, by check 7."""
    batch = _sorted_inside_seconds(bm.make_batch(seed=17, sequences=4, rows=24))
    result = bm.run_checks(_ReadsItsOwnNanoseconds(), batch, units_per_second=UNIT, say=lambda line: None)
    assert all(result["passes"].values()), result
    kept, later, read = bm.later_rows_change_nothing(_TakesOnlyTimeOrder(24), batch, units_per_second=UNIT)
    assert kept == 0.0 and later > 0.0 and read > 0.0
    for seen in (bm.make_batch(seed=17, sequences=4, rows=24), batch):
        result = bm.run_checks(_OrdersItsSecond(), seen, units_per_second=UNIT, say=lambda line: None)
        assert not result["passes"]["order in a second"] and result["order"] > 0.1
    # The later rows move by whole seconds, each by its own distance, and keep their part inside the second.
    times = torch.tensor([[10 * UNIT + 7, 20 * UNIT + 3, 20 * UNIT + 1]])
    rows = torch.tensor([[False, True, True]])
    moved = bm._later_times(times, rows, UNIT, torch.tensor([[0, 3_610, 3_610]]))
    assert moved.tolist() == [[10 * UNIT + 7, 3_630 * UNIT + 3, 3_630 * UNIT + 1]]


def test_one_model_two_batches_catches_what_a_model_keeps_between_calls():
    """A model that keeps something from its first call, and the joined history with a time bias kept from the first
    batch, pass the four first checks, which score every batch on a copy of their own; the check of two batches
    fails them and passes the same models without the keeping."""
    batch = bm.make_batch(seed=18, sequences=4, rows=20)
    lines = []
    keeping = bm.run_checks(_KeepsFirstCall(), batch, units_per_second=UNIT, say=lines.append)
    assert not keeping["passes"]["two batches"] and keeping["two_batches"] > 0.0
    assert all(keeping["passes"][name] for name in ("later rows", "padding", "prefix", "gradient"))
    assert any("the model keeps kept from one call to the next" in line for line in lines)
    model = _built(replace(bm.TODAY, **SMALL, time_bias=True))
    assert bm.one_model_two_batches(model, batch, units_per_second=UNIT) == (0.0, 0.0)
    model.time_bias = _CachedBias(model.time_bias)
    cached = bm.run_checks(model, batch, units_per_second=UNIT)
    assert cached["two_batches"] > 0.0 and not cached["passes"]["two batches"]
    assert all(cached["passes"][name] for name in ("later rows", "padding", "prefix", "gradient"))
    # A second batch can be handed over; a batch of one sequence is checked against its own second batch, not rolled.
    other = bm.make_batch(seed=19, sequences=4, rows=20)
    assert bm.one_model_two_batches(_KeepsFirstCall(), batch, other=other)[0] > 0.0
    single = bm.make_batch(seed=20, sequences=1, rows=8)
    assert bm.one_model_two_batches(_ReadsEarlierSeconds(), single, units_per_second=UNIT) == (0.0, 0.0)
    assert bm.one_model_two_batches(_LazyOrigin(), single, units_per_second=UNIT)[0] > 0.0


def test_the_second_batch_of_check_6_holds_other_rows_at_other_times():
    """A time origin fixed on the first call passed check 6 when its second batch was the same rows rolled by one
    place, since its earliest second did not change; the second batch now holds other numbers and times a month,
    five hours and seven seconds later, and the check fails that model in either order while every named
    configuration still passes."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    assert bm.one_model_two_batches(_LazyOrigin(), batch, units_per_second=UNIT)[0] > 1.0
    # The default second batch: every real row of the rolled batch has new inputs and moves by the shift; padded
    # slots keep their times.
    rolled = {name: value.roll(1, dims=0) for name, value in batch.items()}
    other = bm._other_batch(batch, 8, bm.alter_rows, "mask", "time_seq", UNIT)
    valid = rolled["mask"]
    assert torch.equal(other["mask"], valid)
    shift = bm.OTHER_SHIFT_SECONDS * UNIT
    assert torch.equal(other["time_seq"][valid], rolled["time_seq"][valid] + shift)
    assert torch.equal(other["time_seq"][~valid], rolled["time_seq"][~valid])
    assert bm.OTHER_SHIFT_SECONDS == 30 * 86_400 + 5 * 3_600 + 7
    assert not torch.equal(other["categorical"][valid], rolled["categorical"][valid])
    # Float times move by the same rule, in 64-bit floats; whole seconds of 64-bit floats stay exact here.
    floats = dict(batch, time_seq=torch.div(batch["time_seq"], UNIT, rounding_mode="floor").double())
    moved = bm._other_batch(floats, 8, bm.alter_rows, "mask", "time_seq", 1)["time_seq"]
    assert torch.equal(moved[rolled["mask"]], floats["time_seq"].roll(1, dims=0)[rolled["mask"]]
                       + bm.OTHER_SHIFT_SECONDS)
    small = bm.make_batch(seed=1, sequences=4, rows=30)
    for name, config in bm.CONFIGURATIONS.items():
        two, alone = bm.one_model_two_batches(_built(config), small, units_per_second=UNIT)
        assert two == 0.0 and alone <= bm.ORDER_TOLERANCE, name


def test_the_order_inside_a_second_check_catches_a_memory_that_takes_rows_by_slot():
    """A memory that takes the rows of an earlier second by their slots (memory_ties "slot", the rule of the re-read of
    24 November) and a toy that reads the first slot of a second pass the four first checks, and the order check
    fails them; the same memory under "whole_seconds" moves no score beyond rounding."""
    batch = bm.make_batch(seed=21, sequences=4, rows=30)
    order, same_second = bm.order_inside_a_second(_built(bm.CANDIDATE), batch, units_per_second=UNIT)
    assert order <= bm.ORDER_TOLERANCE and same_second == 0.0
    result = bm.run_checks(_built(bm.ARMS["MEMORY_SLOT"].config), batch, units_per_second=UNIT)
    assert result["order"] > 100 * bm.ORDER_TOLERANCE and not result["passes"]["order in a second"]
    assert result["same_second"] == 0.0
    assert all(result["passes"][name] for name in ("later rows", "padding", "prefix", "gradient", "time unit"))
    joined = _built(replace(bm.TODAY, **SMALL, interleaved_reread="AM", memory_ties="slot"))
    assert bm.order_inside_a_second(joined, batch, units_per_second=UNIT)[0] > bm.ORDER_TOLERANCE
    toy = bm.run_checks(_ReadsFirstSlotOfLastSecond(), batch, units_per_second=UNIT)
    assert not toy["passes"]["order in a second"] and toy["passes"]["later rows"] and toy["passes"]["prefix"]
    assert bm.order_inside_a_second(_RowByItself(), batch, units_per_second=UNIT) == (0.0, 0.0)
    # Without a second that holds two real rows the check makes one in a copy, and says so; with no sequence of two
    # real rows it cannot run.
    lonely = dict(batch, time_seq=batch["time_seq"] + torch.arange(30).unsqueeze(0) * 10 * UNIT)
    lines = []
    order, same_second = bm.order_inside_a_second(_RowByItself(), lonely, units_per_second=UNIT, say=lines.append)
    assert (order, same_second) == (0.0, 0.0) and "took the time of the earliest" in lines[0]
    order, same_second = bm.order_inside_a_second(_SameSecondMean(), lonely, units_per_second=UNIT,
                                                  say=lambda line: None)
    assert same_second > 0.0 and order > bm.ORDER_TOLERANCE
    alone = {name: value[:, :1] if value.dim() >= 2 else value for name, value in batch.items()}
    lines = []
    order, same_second = bm.order_inside_a_second(_RowByItself(), alone, units_per_second=UNIT, say=lines.append)
    assert order != order and same_second != same_second and "no sequence holds two real rows" in lines[-1]


def test_real_takes_a_function_and_a_mask_true_on_padding_gets_a_hint():
    """`real` may be a function of the batch, so a model whose mask is True on padding is checked without a new batch
    entry; handed that mask as if it were True on real rows, check 1 sees no row move, fails, and says why."""
    batch = bm.make_batch(seed=22, sequences=4, rows=20)
    padded = dict(batch, is_pad=~batch["mask"])
    # A model that reads its own mask and sets the inputs of padded slots to zero, so that a padded slot's score is the
    # same whatever it holds: the channel stage does so.
    model = _built(replace(bm.CANDIDATE, **SMALL))
    result = bm.run_checks(model, padded, units_per_second=UNIT, real=lambda b: ~b["is_pad"],
                           pad=lambda b, rows: dict(b, is_pad=b["is_pad"] | rows))
    assert all(result["passes"].values())
    lines = []
    kept, later, read = bm.later_rows_change_nothing(model, padded, real="is_pad", units_per_second=UNIT,
                                                     say=lines.append)
    assert kept == 0.0 and later == 0.0 and read == 0.0
    assert any("True on padding" in line for line in lines)
    # The read of the earlier rows is 0.0 as well; the padded slots of make_batch share one time, so the line that
    # reports it says that no changed row has an earlier second among the rows `real` names.
    assert any("the later rows did not move when the earlier rows changed" in line
               or "no changed row has a real row of an earlier second" in line for line in lines)
    wrong = bm.run_checks(model, padded, real="is_pad", units_per_second=UNIT, say=lambda line: None)
    assert not wrong["passes"]["later rows"]


def _left_padded(batch):
    """The batch with the real rows of every sequence moved to the end of its window, in time order, and every padded
    slot given the time of the first real row of its sequence, as a builder that pads on the left with that time
    writes it."""
    valid = batch["mask"]
    B, T = valid.shape
    count = valid.sum(dim=1)
    order = torch.stack([torch.roll(torch.arange(T), T - int(count[b])) for b in range(B)])
    out = bm._taken(batch, order)
    times, valid = out["time_seq"], out["mask"]
    first = torch.where(valid, times, torch.full_like(times, torch.iinfo(torch.int64).max)).amin(dim=1, keepdim=True)
    out["time_seq"] = torch.where(valid, times, first)
    return out


def test_a_mask_true_on_padding_cannot_hide_a_model_that_reads_later_rows():
    """On a left-padded batch whose padded slots carry the time of the first real row, check 1 handed the mask True
    on padding tested padded slots only, and a model that reads later rows passed all seven checks with nothing
    printed. Check 1 now also needs the rows it calls real to read each other: it fails that model with the mask
    True on padding, and with the right mask it sees the leak, while the named configurations pass."""
    batch = _left_padded(bm.make_batch(seed=0, sequences=8, rows=40))
    assert bool(batch["mask"][:, -1].all()) and not bool(batch["mask"][:, 0].all())
    lines = []
    wrong = bm.run_checks(_ReadsTheFuture(), batch, units_per_second=UNIT, real=lambda b: ~b["mask"], say=lines.append)
    assert not wrong["passes"]["later rows"] and wrong["read"] == 0.0
    # The padded slots share one time, so the line that reports read 0.0 says that no changed row has an earlier
    # second among the rows `real` names, and names the mask.
    assert any("True on padding" in line and ("reads no history" in line
                                              or "no changed row has a real row of an earlier second" in line)
               for line in lines), lines
    right = bm.run_checks(_ReadsTheFuture(), batch, units_per_second=UNIT, say=lambda line: None)
    assert not right["passes"]["later rows"] and right["kept"] > 0.0
    small = _left_padded(bm.make_batch(seed=1, sequences=4, rows=30))
    for name in ("TODAY", "CANDIDATE"):
        result = bm.run_checks(_built(bm.CONFIGURATIONS[name]), small, units_per_second=UNIT)
        assert all(result["passes"].values()), (name, result)


def test_a_time_unit_that_does_not_fit_the_times_fails_the_first_check():
    """A model told that its nanosecond times are seconds puts the rows of one second in an order, so a row reads
    another row of its own second: the first check sees it, in the joined history and in the channel stage."""
    batch = bm.make_batch(seed=7, sequences=4, rows=24)
    for config in (bm.TODAY, bm.CANDIDATE):
        model = _built(config)
        assert bm.later_rows_change_nothing(model, batch, units_per_second=UNIT)[0] == 0.0
        model.units_per_second = 1
        if model.stage is not None:
            model.stage.units_per_second = 1
        kept, later, read = bm.later_rows_change_nothing(model, batch, units_per_second=UNIT)
        assert kept > 0.0, config.history


def test_the_first_check_says_why_it_cannot_run(capsys):
    """Without a real row on both sides of any probe the check prints the reason and gives no passing answer."""
    batch = bm.make_batch(seed=8, sequences=2, rows=10)
    nothing = dict(batch, nothing_real=torch.zeros_like(batch["mask"]))
    kept, later, read = bm.later_rows_change_nothing(_RowByItself(), nothing, real="nothing_real",
                                                     units_per_second=UNIT)
    assert kept != kept and later == 0.0 and read == 0.0
    assert "no sequence holds a row on both sides" in capsys.readouterr().out
    result = bm.run_checks(_RowByItself(), nothing, real="nothing_real", units_per_second=UNIT)
    assert not result["passes"]["later rows"]


def test_the_first_two_checks_see_a_leak_of_training_mode():
    """Every check scored in scoring mode only, so a batch norm over every slot of the batch, which leaks later rows,
    padding and the other sequences in training alone, passed all seven. Checks 1, 2 and 7 now run their comparisons
    in training mode as well, with the same dropout masks in both calls, check 3 cuts in training mode on a copy whose
    dropout is off, and check 6 changes half the sequences in training mode: such models fail them, with a line that
    names the usual cause, while TODAY and CANDIDATE keep every kept row to the bit in training mode too, and the
    random state of the caller is left as it was."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    for model in (_NormedNumbers(), _NormedLogits()):
        lines = []
        result = bm.run_checks(model, batch, units_per_second=UNIT, say=lines.append)
        failing = [name for name, ok in result["passes"].items() if not ok]
        assert failing == ["later rows", "padding", "prefix", "two batches", "order in a second"], (
            type(model).__name__, result)
        assert result["kept"] > 0.0 and result["padding"] > 0.0
        assert any("in training mode only" in line and "batch norm" in line for line in lines)
        # In scoring mode alone nothing moves: the leak is one of training.
        work, real = bm.moved(model), batch["mask"]
        dirty = bm.fill_rows(batch, ~real, 1e30)
        assert torch.equal(bm._fresh_scores(work, batch)[real], bm._fresh_scores(work, dirty)[real])
    # The control: a model that keeps the rule draws the same dropout in both calls and moves no kept row.
    valid = batch["mask"]
    seconds = torch.div(batch["time_seq"], UNIT, rounding_mode="floor")
    later = valid & (seconds > seconds[:, 10:11])
    kept = valid & ~later
    for name in ("TODAY", "CANDIDATE"):
        work = bm.moved(_built(bm.CONFIGURATIONS[name]))
        state = torch.random.get_rng_state()
        first = bm._training_scores(work, batch)
        second = bm._training_scores(work, bm.alter_rows(batch, later))
        assert torch.equal(torch.random.get_rng_state(), state), name
        assert torch.equal(first[kept], second[kept]), name
        assert not torch.equal(first[later], second[later]), name
        # Dropout is on in training mode: another seed draws other masks.
        assert not torch.equal(first[kept], bm._training_scores(work, batch, seed=bm.DROPOUT_SEED + 1)[kept]), name


def _few_ties(seed, sequences=16, rows=40, share=0.02):
    """A made-up batch whose rows share a second about `share` of the time, as a caller's batch may."""
    batch = bm.make_batch(seed=seed, sequences=sequences, rows=rows)
    g = torch.Generator().manual_seed(seed + 100)
    same = torch.rand(sequences, rows, generator=g) < share
    steps = torch.floor(10.0 ** (torch.rand(sequences, rows, generator=g) * 5.5)).long().clamp(min=1)
    seconds = 1_767_225_600 + torch.cumsum(steps.masked_fill(same, 0), dim=1)
    times = seconds * UNIT + torch.randint(0, UNIT, (sequences, rows), generator=g)
    batch["time_seq"] = times.masked_fill(~batch["mask"], 0)
    return batch


def test_a_row_that_reads_the_other_rows_of_its_second_fails_on_a_batch_with_few_ties():
    """A row that reads the mean of the other rows of its own second passed all seven checks on batches with about 2
    percent of shared seconds, since the probe of check 1 sat in a second of its own and a shuffle cannot move a mean.
    The probe of check 1 now sits in a shared second in the middle of its window whenever there is one, and check 7
    changes the other rows of every shared second, or takes them out of the window, while a witness must not move;
    the model fails both on every such batch."""
    for seed in (2, 3, 5, 7, 11):
        batch = _few_ties(seed)
        result = bm.run_checks(_SameSecondMean(), batch, units_per_second=UNIT, say=lambda line: None)
        assert not result["passes"]["later rows"] and result["kept"] > 0.0, seed
        assert not result["passes"]["order in a second"] and result["same_second"] > 0.0, seed
        assert result["order"] > bm.ORDER_TOLERANCE, seed              # its second's rows leave the window
    # The probe: among the real rows that share a second, the one nearest count // 2, the lower rank on a tie.
    valid = torch.tensor([[True] * 7 + [False]])
    seconds = torch.tensor([[1, 2, 2, 3, 5, 5, 6, 0]])
    assert bm._probes(valid, seconds).nonzero()[:, 1].tolist() == [2]     # ranks 1, 2, 4, 5 share; count // 2 is 3
    seconds = torch.tensor([[1, 2, 3, 4, 5, 6, 7, 0]])
    assert bm._probes(valid, seconds).nonzero()[:, 1].tolist() == [3]     # no shared second: the middle real row


class _CountsItsSecond(nn.Module):
    """TODAY plus a term of how many real rows share a row's whole second, the row itself included: a position counted
    with <= in place of <, or the size of a burst. No change of the values of those rows moves it; their leaving
    does."""

    def __init__(self):
        super().__init__()
        torch.manual_seed(0)
        self.inner = bm.BestModel(bm.TODAY)
        self.w = nn.Parameter(torch.tensor([0.5, -0.5]))

    def forward(self, batch):
        seconds = torch.div(batch["time_seq"], UNIT, rounding_mode="floor")
        valid = batch["mask"]
        same = (seconds.unsqueeze(1) == seconds.unsqueeze(2)) & valid.unsqueeze(1) & valid.unsqueeze(2)
        return self.inner(batch) + self.w * torch.log1p(same.sum(dim=-1).float()).unsqueeze(-1)


def test_a_row_that_counts_the_rows_of_its_second_fails_checks_3_and_7_on_a_batch_with_few_ties():
    """A row that reads only how many rows share its second passed all seven checks whenever no shared second crossed
    the middle cut of check 3, since checks 1 and 7 changed values and no row left. Check 3 now cuts inside a shared
    second, and check 7 moves the other rows of a witness's second an hour later, out of it; the model fails both on
    batches with about 2 percent of shared seconds, and TODAY passes both."""
    today = _built(bm.TODAY)
    for seed in (0, 1, 3, 10):
        batch = _few_ties(seed)
        quiet = lambda line: None
        moved = bm.prefix_agrees(_CountsItsSecond(), batch, units_per_second=UNIT, say=quiet)
        assert moved >= bm.PREFIX_TOLERANCE, seed
        assert bm.order_inside_a_second(_CountsItsSecond(), batch, UNIT, say=quiet)[1] > 0.0, seed
        assert bm.prefix_agrees(today, batch, units_per_second=UNIT, say=quiet) < bm.PREFIX_TOLERANCE, seed
        assert bm.order_inside_a_second(today, batch, UNIT, say=quiet)[1] == 0.0, seed
    # The cut splits a shared second in the most sequences, nearest T // 2 among those; None without one, where the
    # middle cut alone is taken, nearest T // 2 among the cuts with real rows on both sides in the most sequences.
    valid = torch.tensor([[True] * 6 + [False, False], [True] * 8])
    assert bm._cut_in_a_second(valid, torch.tensor([[1, 2, 2, 3, 4, 5, 0, 0], [1, 2, 3, 3, 4, 5, 6, 6]])) == 3
    assert bm._cut_in_a_second(valid, torch.tensor([[1, 2, 3, 3, 3, 4, 0, 0], [1, 2, 3, 3, 4, 5, 6, 7]])) == 3
    assert bm._cut_in_a_second(valid, torch.tensor([[1, 2, 3, 4, 5, 6, 0, 0], [1, 2, 3, 4, 5, 6, 7, 8]])) is None
    assert bm._middle_cut(valid) == 4
    assert bm._middle_cut(torch.tensor([[False] * 5 + [True] * 3])) == 6
    assert bm._cut_in_a_second(torch.tensor([[True, True, False, True]]), torch.tensor([[1, 2, 0, 2]])) == 2


def test_check_6_moves_integer_times_in_a_unit_that_is_not_whole():
    """With integer times in whole minutes (1/60 units per second) check 6 kept the times of its second batch, so an
    origin of time fixed on the first call passed. Such times now move by the nearest whole number of units."""
    minutes = torch.tensor([[29_000_000, 29_000_001]])
    rows = torch.tensor([[True, False]])
    assert bm._later_times(minutes, rows, 1 / 60, bm.OTHER_SHIFT_SECONDS).tolist() == [[29_043_500, 29_000_001]]
    assert bm._later_times(minutes, rows, 1, 60).tolist() == [[29_000_060, 29_000_001]]
    nanoseconds = torch.tensor([[1.7e18, 1.8e18]], dtype=torch.float64)
    assert bm._later_times(nanoseconds, rows, 10 ** 9, 3_600)[0, 0] == 1.7e18 + 3.6e12
    batch = bm.make_batch(seed=0, sequences=4, rows=12)
    batch["time_seq"] = torch.div(batch["time_seq"], 60 * UNIT, rounding_mode="floor")
    other = bm._other_batch(batch, 4, bm.alter_rows, "mask", "time_seq", 1 / 60)
    valid = other["mask"].bool()
    assert bool(((other["time_seq"] - batch["time_seq"].roll(1, dims=0))[valid] == 43_500).all())


class _AuxInTraining(_ReadsEarlierSeconds):
    """Keeps every rule, and returns its scores with an auxiliary loss in training mode, as some models do."""

    def forward(self, batch):
        out = super().forward(batch)
        return (out, out.pow(2).mean()) if self.training else out


def test_the_training_passes_take_the_scores_of_a_tuple_and_seed_only_what_they_put_back(monkeypatch):
    """Checks 1 and 2 index the training-mode output, so a model that returns its scores with an auxiliary loss there
    stopped them with a TypeError; they now take the first part of a tuple, and an output of another kind stops
    with a plain error. They seeded every device torch knows and put back only the CPU and the CUDA devices of the
    weights; now they seed only those."""
    calls = []
    monkeypatch.setattr(torch.cuda, "manual_seed_all", lambda seed: calls.append(("cuda, every device", seed)))
    monkeypatch.setattr(torch.cuda, "manual_seed", lambda seed: calls.append(("cuda", seed)))
    if hasattr(torch, "mps"):
        monkeypatch.setattr(torch.mps, "manual_seed", lambda seed: calls.append(("mps", seed)))
    batch = bm.make_batch(seed=1, sequences=4, rows=12)
    summary = torch.randn(2, 3, 4, 5, generator=torch.Generator().manual_seed(0))
    state = torch.random.get_rng_state()
    kept, later, read = bm.later_rows_change_nothing(_AuxInTraining(), batch, units_per_second=UNIT)
    assert kept == 0.0 and later > 0.0 and read > 0.0
    assert bm.padding_stays_out(_AuxInTraining(), batch) == (0.0, True)
    assert bm.every_weight_learns(_ReadsEarlierSeconds(), batch) == []
    assert bm.channels_stay_apart(nn.Dropout(0.5).train(), summary)["apart"]
    assert calls == [] and torch.equal(torch.random.get_rng_state(), state)

    class _Table(_RowByItself):
        def forward(self, batch):
            return {"scores": super().forward(batch)}

    with pytest.raises(TypeError, match="scores as a tensor"):
        bm.later_rows_change_nothing(_Table(), batch, units_per_second=UNIT)


class _GatedMix(nn.Module):
    """A hand-off that keeps the channels apart while its gate is at its start, 0, and mixes them once it has moved:
    a linear map of the joined vector behind the gate."""

    def __init__(self, M, d):
        super().__init__()
        self.mix = nn.Linear(M * d, M * d)
        self.gate = nn.Parameter(torch.zeros(()))

    def forward(self, s):
        B, T, M, d = s.shape
        return s + self.gate * self.mix(s.reshape(B, T, M * d)).view(B, T, M, d)


class _WithHandOff(nn.Module):
    """A model whose hand-off is a method that runs a gated mix."""

    def __init__(self, M, d):
        super().__init__()
        self.part = _GatedMix(M, d)

    def hand_off(self, s):
        return self.part(s)


def test_channels_stay_apart_moves_the_weights_of_the_hand_off_first():
    """A hand-off whose mixing part starts at zero read as apart on a fresh model and mixes once trained. A module, or
    the module of a method, now runs with its weights moved a little, as the checks run a model; both forms of the
    gated mix are seen, and the two candidates still keep every output in one channel of its own."""
    M, d = 3, 4
    summary = torch.randn(2, 5, M, d, generator=torch.Generator().manual_seed(1))
    assert not _GatedMix(M, d)(summary).ne(summary).any()                 # fresh: the gate leaves every channel alone
    assert not bm.channels_stay_apart(_GatedMix(M, d), summary)["apart"]
    assert not bm.channels_stay_apart(_WithHandOff(M, d).hand_off, summary)["apart"]
    big = torch.randn(2, 5, bm.CANDIDATE.num_summary, bm.CANDIDATE.token_dim,
                      generator=torch.Generator().manual_seed(2))
    for name in ("CANDIDATE", "CANDIDATE_LPM"):
        assert bm.channels_stay_apart(_built(bm.CONFIGURATIONS[name]).hand_off, big)["apart"], name


def test_the_cut_of_check_3_takes_the_real_rows_in_time_order():
    """Check 3 cuts by slot, so a model that keeps the rule failed it on a batch whose real rows are not in time order
    by slot (late rows in the first slots, the earliest after the padding). The real rows are now put in time order
    among their own slots before the cut, with one line that says so, and a batch already in time order is not
    changed; TODAY and CANDIDATE pass on that layout and on a left-padded one."""
    base = bm.make_batch(seed=0, sequences=8, rows=40)
    count = base["mask"].sum(dim=1)
    order = torch.stack([torch.roll(torch.arange(40), int(count[b])) for b in range(8)])
    rotated = bm._taken(base, order)
    for name in ("TODAY", "CANDIDATE"):
        lines = []
        model = _built(bm.CONFIGURATIONS[name])
        assert bm.prefix_agrees(model, rotated, units_per_second=UNIT, say=lines.append) < bm.PREFIX_TOLERANCE, name
        assert lines and "put in time order" in lines[0], name
        lines = []
        assert bm.prefix_agrees(model, _left_padded(base), units_per_second=UNIT, say=lines.append) < \
            bm.PREFIX_TOLERANCE, name
        assert lines == [], name
    # The sort is stable inside a second and keeps padded slots where they are.
    valid = torch.tensor([[True, True, False, True, True]])
    seconds = torch.tensor([[7, 3, 0, 3, 1]])
    slots, moved_any = bm._time_ordered(valid, seconds)
    assert slots.tolist() == [[4, 1, 2, 3, 0]] and moved_any
    assert not bm._time_ordered(valid, torch.tensor([[1, 3, 0, 3, 7]]))[1]


def test_channels_stay_apart_sees_a_hand_off_that_mixes_the_summary_outputs():
    """A hand-off that mixes the summary outputs before .view keeps the time rule and passes the seven checks. Run on
    the hand-off alone, channels_stay_apart finds every output in one channel of its own for the two candidates, and
    in every channel for a linear layer or a layer norm over the joined vector and for the d numbers joined d-major;
    a joined hand-off has no channels to keep apart and gives a plain error."""
    M, d = bm.CANDIDATE.num_summary, bm.CANDIDATE.token_dim
    summary = torch.randn(2, 5, M, d, generator=torch.Generator().manual_seed(1))
    for name in ("CANDIDATE", "CANDIDATE_LPM"):
        result = bm.channels_stay_apart(_built(bm.CONFIGURATIONS[name]).hand_off, summary)
        assert result["apart"] and torch.equal(result["moved"], torch.eye(M, dtype=torch.bool)), name
    # A relabelling of the channels is harmless; a norm of every channel on its own keeps them apart as well.
    turned = bm.channels_stay_apart(lambda s: s.roll(1, dims=-2), summary)
    assert turned["apart"] and not torch.equal(turned["moved"], torch.eye(M, dtype=torch.bool))
    own_norm = nn.LayerNorm(d)
    assert bm.channels_stay_apart(own_norm, summary)["apart"]
    torch.manual_seed(0)
    linear, norm = nn.Linear(M * d, M * d), nn.LayerNorm(M * d)
    for hand_off in (lambda s: linear(s.reshape(2, 5, M * d)).view(2, 5, M, d),
                     lambda s: norm(s.reshape(2, 5, M * d)).view(2, 5, M, d),
                     lambda s: s.transpose(-1, -2).reshape(2, 5, M * d).view(2, 5, M, d)):
        result = bm.channels_stay_apart(hand_off, summary)
        assert not result["apart"] and bool(result["moved"].all())
    # Dropout in training mode draws the same masks in every call, so it does not count as a change.
    dropped = nn.Dropout(0.5).train()
    assert bm.channels_stay_apart(dropped, summary)["apart"]
    with pytest.raises(ValueError, match="no channels to keep apart"):
        bm.channels_stay_apart(_built(bm.TODAY).hand_off, torch.randn(2, 5, 3, 48))
    # The hand-off of the model is the one its export takes, and it is not an eighth check.
    model = _built(replace(bm.CANDIDATE, **SMALL))
    seen = {}
    model.stage.register_forward_pre_hook(lambda m, inputs: seen.update(channels=inputs[0]))
    with torch.no_grad():
        model.eval()(bm.make_batch(seed=2, sequences=2, rows=6))
    assert seen["channels"].shape[-2:] == (SMALL["num_summary"], SMALL["token_dim"])
    assert len(bm.run_checks(_ReadsEarlierSeconds(), bm.make_batch(seed=3, sequences=2, rows=8),
                             units_per_second=UNIT)["passes"]) == 7


def test_raw_numbers_stop_the_checks_with_a_plain_error():
    """Numbers that skipped the scaler gave one warning in training and passed every check. The numeric encoder of
    BestModel is now built with unscaled="raise", so raw numbers stop run_checks at the first training step with the
    plain error of the encoder. Padded slots count as missing numbers, so the look of the encoder judges the numbers
    of real rows only: raw numbers are seen however much padding the batch holds, and padding that holds anything
    stops nothing, in check 2 as well."""
    batch = bm.make_batch(seed=1, sequences=4, rows=30)
    raw = dict(batch, continuous=batch["continuous"] * 5_000.0 + 20.0)
    for name in ("CANDIDATE", "TODAY"):
        with pytest.raises(ValueError, match="UnitQuantileScaler"):
            bm.run_checks(_built(bm.CONFIGURATIONS[name]), raw, units_per_second=UNIT, say=lambda line: None)
        assert _built(bm.CONFIGURATIONS[name]).numbers.unscaled == "raise", name
    # Most of the slots padded: the raw numbers of the few real rows are still seen.
    sparse = bm.make_batch(seed=4, sequences=4, rows=30)
    sparse["mask"] = sparse["mask"] & (torch.arange(30) < 6)
    raw = dict(sparse, continuous=torch.where(sparse["mask"].unsqueeze(-1), sparse["continuous"] * 5_000.0, 0.0))
    model = _built(bm.CANDIDATE).train()
    with pytest.raises(ValueError, match="UnitQuantileScaler"):
        bm.row_loss(model, raw)
    # Scaled real rows and padded slots that hold huge numbers: no stop, and check 2 passes in training mode too.
    lines = []
    change, finite = bm.padding_stays_out(_built(bm.CANDIDATE), sparse, say=lines.append)
    assert change == 0.0 and finite and lines == []


# ------------------------------------------------------------------------------------- what more the checks see

class _Plus(_ReadsEarlierSeconds):
    """_ReadsEarlierSeconds with one more term on every row, term(batch) [B, T]; each subclass says what it reads."""

    def term(self, batch):
        raise NotImplementedError

    def forward(self, batch):
        extra = self.term(batch).float()
        return super().forward(batch) + torch.stack([extra, -extra], dim=-1) * self.weight


def _seconds(batch):
    """The whole seconds of the made-up batch."""
    return torch.div(batch["time_seq"], UNIT, rounding_mode="floor")


class _ReadsItsOwnNanoseconds(_Plus):
    """Keeps the rule: its own time of day to the nanosecond, which the rule lets a row read."""

    def term(self, batch):
        return (batch["time_seq"] % (86_400 * UNIT)).double() / (86_400 * UNIT)


class _TakesOnlyTimeOrder(_ReadsEarlierSeconds):
    """Keeps the rule, and takes only a batch laid out as a strict builder writes one, as the model in use does: real
    rows in time order by slot, at its own width, and no window holding more distinct seconds than `seconds`. Any
    other batch stops it with a ValueError."""

    def __init__(self, width, seconds=None):
        super().__init__()
        self.width, self.seconds = width, seconds

    def forward(self, batch):
        valid, times = batch["mask"].bool(), batch["time_seq"]
        if valid.shape[1] != self.width:
            raise ValueError(f"the batch is {valid.shape[1]} slots wide, the model {self.width}")
        both = valid[:, 1:] & valid[:, :-1]
        if bool((both & (times[:, 1:] < times[:, :-1])).any()):
            raise ValueError("the real rows are not in time order")
        if self.seconds is not None:
            for b in range(valid.shape[0]):
                if int(_seconds(batch)[b][valid[b]].unique().numel()) > self.seconds:
                    raise ValueError("a window holds more distinct seconds than the model takes")
        return super().forward(batch)


class _ReadsTheWindowLength(_Plus):
    """Reads the number of real rows of its window from an entry laid out per window, lengths [B]: later rows leak."""

    def term(self, batch):
        return batch["lengths"].float().unsqueeze(1).expand(batch["mask"].shape) / 10


class _ReadsItsOwnLabel(_Plus):
    """Reads its own label: part of its own answer."""

    def term(self, batch):
        return (batch["target_seq"] == 1).float()


class _ReadsEarlierLabels(_Plus):
    """Keeps the rule: the share of positive labels among the real rows of strictly earlier seconds."""

    def term(self, batch):
        return _earlier_mean((batch["target_seq"] == 1).float(), batch)


class _CountsPaddingInFront(_Plus):
    """Reads how many padded slots lie in front of the first real row: in a window padded on the left that is the
    width less the number of real rows, later rows included."""

    def term(self, batch):
        valid = batch["mask"].bool()
        T = valid.shape[1]
        first = torch.where(valid, torch.arange(T), torch.full_like(valid, T, dtype=torch.long)).amin(dim=1)
        return torch.log1p(first.float()).unsqueeze(1).expand(valid.shape)


class _ReadsTheBatchOrigin(_Plus):
    """Reads the hours since the earliest real second of the whole batch: the other sequences leak."""

    def term(self, batch):
        seconds = _seconds(batch)
        return torch.log1p((seconds - seconds[batch["mask"].bool()].min()).clamp(min=0).double() / 3_600)


class _ShareOfWindow(_Plus):
    """Reads its share of the window: the real rows of earlier seconds over every real row of the window."""

    def term(self, batch):
        valid, seconds = batch["mask"].bool(), _seconds(batch)
        earlier = (seconds.unsqueeze(1) < seconds.unsqueeze(2)) & valid.unsqueeze(1) & valid.unsqueeze(2)
        return earlier.sum(dim=-1).float() / valid.sum(dim=1, keepdim=True).clamp(min=1)


class _ReadsLaterRowsWhileLearning(_Plus):
    """Reads the mean of the later rows, only in training mode with gradients on: a leak of training steps alone."""

    def term(self, batch):
        valid = batch["mask"].bool()
        if not (self.training and torch.is_grad_enabled()):
            return torch.zeros(valid.shape)
        seconds = _seconds(batch)
        later = ((seconds.unsqueeze(1) > seconds.unsqueeze(2)) & valid.unsqueeze(1) & valid.unsqueeze(2)).float()
        return (later @ self.row(batch).unsqueeze(-1)).squeeze(-1) / later.sum(dim=-1).clamp(min=1)


class _TrainingMemory(_Plus):
    """Adds, in training mode, the mean row of the batch of its previous training call: a memory between steps."""

    def __init__(self):
        super().__init__()
        self.memory = None

    def term(self, batch):
        out = torch.zeros(batch["mask"].shape)
        if self.training:
            if self.memory is not None:
                out = out + self.memory
            self.memory = self.row(batch).mean().detach()
        return out


class _LazyPlainOrigin(_Plus):
    """Fixes an origin of time on its first call in a plain attribute, which a checkpoint does not hold."""

    def __init__(self):
        super().__init__()
        self.origin = None

    def term(self, batch):
        seconds = _seconds(batch)
        if self.origin is None:
            self.origin = int(seconds[batch["mask"].bool()].min())
        return torch.log1p((seconds - self.origin).clamp(min=0).double() / 3_600)


class _NumpyDropout(_ReadsEarlierSeconds):
    """Keeps the rule, with a dropout in training mode whose masks numpy draws."""

    def forward(self, batch):
        out = super().forward(batch)
        if self.training:
            keep = torch.from_numpy((np.random.rand(*out.shape) > 0.3).astype("float32"))
            out = out * keep / 0.7
        return out


class _ReadsTheSlotIndex(_Plus):
    """Reads a slot index the builder writes into the batch, pos [B, T]: the rows of its own second in earlier slots
    count."""

    def term(self, batch):
        return torch.log1p(batch["pos"].float())


def _with_slot_index(batch):
    """The batch with the builder's slot index of every real row among the real rows of its window, pos [B, T]."""
    valid = batch["mask"].bool()
    return {**batch, "pos": (valid.long().cumsum(dim=1) - 1).clamp(min=0) * valid}


class _BlockScan(_RowByItself):
    """Keeps the rule on a batch in time order by slot: a running mean over the slots up to the first slot of the
    row's own run of rows of one second, the way a scorer that reads its history in slot order runs."""

    def forward(self, batch):
        x, valid, seconds = self.row(batch), batch["mask"].bool(), _seconds(batch)
        B, T = valid.shape
        x0 = torch.where(valid, x, torch.zeros_like(x))
        total = torch.cat([torch.zeros(B, 1), x0.cumsum(dim=1)[:, :-1]], dim=1)
        count = torch.cat([torch.zeros(B, 1), valid.float().cumsum(dim=1)[:, :-1]], dim=1)
        same = torch.zeros(B, T, dtype=torch.bool)
        same[:, 1:] = valid[:, 1:] & valid[:, :-1] & (seconds[:, 1:] == seconds[:, :-1])
        start = torch.cummax(torch.where(same, torch.zeros(B, T, dtype=torch.long), torch.arange(T).expand(B, T)),
                             dim=1).values
        mean = total.gather(1, start) / count.gather(1, start).clamp(min=1)
        return torch.stack([x + 0.5 * mean, x - 0.5 * mean], dim=-1) * self.weight


class _MaskFromPadding(nn.Module):
    """A model whose own mask is True on padding: it reads is_pad and hands its opposite to the model inside."""

    def __init__(self, inner):
        super().__init__()
        self.inner = inner

    def forward(self, batch):
        return self.inner({**batch, "mask": ~batch["is_pad"]})


def test_the_checks_run_on_a_model_that_takes_only_batches_in_time_order_at_its_own_width():
    """The model in use stops on real rows out of time order and on a window narrower than its own, and check 1 (new
    parts inside the second), check 3 (a sliced window) and check 7 (rows pushed an hour later in their slots) handed
    it such batches, so run_checks stopped. Every check now keeps a batch in time order, check 3 scores the cut window
    at the full width, its other slots made padding, when the narrower one stops the model, and check 7 shuffles only
    rows that share their time to the last unit when the model takes no other order: a model that keeps the rule
    passes, on whole seconds and with parts inside the second."""
    fine = _sorted_inside_seconds(bm.make_batch(seed=0, sequences=8, rows=40))
    whole = dict(fine, time_seq=torch.where(fine["mask"], _seconds(fine) * UNIT, fine["time_seq"]))
    for batch, shuffled in ((whole, True), (fine, False)):
        most = max(int(_seconds(batch)[b][batch["mask"][b]].unique().numel()) for b in range(8))
        lines = []
        result = bm.run_checks(_TakesOnlyTimeOrder(40, most), batch, units_per_second=UNIT, say=lines.append)
        assert all(result["passes"].values()), result
        assert any("scored at the full width instead" in line for line in lines)
        assert any("the shuffle is left out" in line for line in lines) != shuffled, lines


def test_an_entry_laid_out_per_window_is_named_and_seen_through_rebuild():
    """No check wrote an entry laid out per window again, so a model that read the length of its window from lengths
    [B] passed all seven. run_checks now names every such entry, and with `rebuild`, which writes it again from every
    batch a check makes, the model fails while one that keeps the rule passes."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    batch["lengths"] = batch["mask"].sum(dim=1)

    def rebuild(made):
        return {**made, "lengths": made["mask"].sum(dim=1)}

    lines = []
    blind = bm.run_checks(_ReadsTheWindowLength(), batch, units_per_second=UNIT, say=lines.append)
    assert all(blind["passes"].values()) and any("lengths is not laid out per row" in line for line in lines)
    seen = bm.run_checks(_ReadsTheWindowLength(), batch, units_per_second=UNIT, rebuild=rebuild, say=lambda line: None)
    assert not seen["passes"]["prefix"] and not seen["passes"]["order in a second"]
    lines = []
    kept = bm.run_checks(_ReadsEarlierSeconds(), batch, units_per_second=UNIT, rebuild=rebuild, say=lines.append)
    assert all(kept["passes"].values()) and not any("lengths" in line for line in lines)


def test_a_row_that_reads_its_own_answer_fails_and_one_that_reads_earlier_answers_passes():
    """No check changed a label, so a row that read its own passed all seven. Checks 1 and 7 now redraw the entries
    named by `labels` on rows that no compared row may read, the compared row's own among them: that row fails, and
    one that reads the labels of earlier seconds, which the rule allows, passes."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    own = bm.run_checks(_ReadsItsOwnLabel(), batch, units_per_second=UNIT, say=lambda line: None)
    assert not own["passes"]["later rows"] and not own["passes"]["order in a second"]
    assert all(bm.run_checks(_ReadsEarlierLabels(), batch, units_per_second=UNIT)["passes"].values())
    unnamed = bm.run_checks(_ReadsItsOwnLabel(), batch, units_per_second=UNIT, labels=(), say=lambda line: None)
    assert all(unnamed["passes"].values())
    # A class label moves to the next class and -100 stays; a yes-or-no label turns over; a missing name is passed over.
    rows = torch.tensor([[True, True, True, True]])
    out = bm._redrawn({"target_seq": torch.tensor([[0, 1, 2, -100]])}, rows, ("target_seq", "outcome"))
    assert out["target_seq"].tolist() == [[1, 2, 0, -100]]
    flags = bm._redrawn({"y": torch.tensor([[True, False]])}, torch.tensor([[True, False]]), "y")
    assert flags["y"].tolist() == [[False, False]]


def test_check_3_cuts_a_window_padded_on_the_left_as_its_builder_writes_it():
    """Check 3 kept the padded slots in front of the kept rows of a window padded on the left, so a row that read how
    much padding lay in front of it, which holds the length of the whole window, passed. The cut window of such a
    batch is now also scored at the full width with the kept rows at its end: that row fails, TODAY and CANDIDATE
    pass, and windows at most half full with no shared second are cut among their rows."""
    batch = _left_padded(bm.make_batch(seed=0, sequences=8, rows=40))
    result = bm.run_checks(_CountsPaddingInFront(), batch, units_per_second=UNIT, say=lambda line: None)
    assert not result["passes"]["prefix"] and result["prefix"] > 0.1
    for name in ("TODAY", "CANDIDATE"):
        assert bm.prefix_agrees(_built(bm.CONFIGURATIONS[name]), batch, units_per_second=UNIT) < bm.PREFIX_TOLERANCE
    half = bm.make_batch(seed=3, sequences=6, rows=30)
    half["mask"] = half["mask"] & (torch.arange(30) < 15)
    half["time_seq"] = half["time_seq"] + torch.arange(30) * 10 * UNIT
    half = _left_padded(half)
    lines = []
    prefix = bm.prefix_agrees(_built(bm.TODAY), half, units_per_second=UNIT, say=lines.append)
    assert prefix < bm.PREFIX_TOLERANCE and lines == []
    # The window a builder writes from some rows alone: kept rows side by side at the start or at the end.
    keep = torch.tensor([[False, True, False, True]])
    small = {"mask": torch.tensor([[True, True, True, True]]), "x": torch.tensor([[10, 11, 12, 13]])}
    out, where = bm._relaid(small, keep, False, bm._padder("mask", None))
    assert out["x"][0, :2].tolist() == [11, 13] and out["mask"].tolist() == [[True, True, False, False]]
    assert where.tolist() == [[-1, 0, -1, 1]]
    out, where = bm._relaid(small, keep, True, bm._padder("mask", None))
    assert out["x"][0, 2:].tolist() == [11, 13] and where.tolist() == [[-1, 2, -1, 3]]
    assert bm._pad_side(batch["mask"]) == "left"
    assert bm._pad_side(bm.make_batch(seed=0, sequences=8, rows=40)["mask"]) == "right"
    assert bm._pad_side(torch.ones(2, 5, dtype=torch.bool)) is None


def test_check_3_also_cuts_near_the_middle():
    """The cut inside a shared second fell on the first slot when most windows share their first second, and a row
    whose leak is zero without history passed. Check 3 now also cuts near the middle: the share of the window is
    seen there."""
    batch = bm.make_batch(seed=2, sequences=8, rows=40)
    assert bm._cut_in_a_second(batch["mask"], _seconds(batch)) == 1
    assert bm.prefix_agrees(_ShareOfWindow(), batch, cut=1, units_per_second=UNIT) < bm.PREFIX_TOLERANCE
    assert bm.prefix_agrees(_ShareOfWindow(), batch, units_per_second=UNIT) > 0.01


def test_check_6_scores_every_sequence_alone():
    """Every check changed every sequence of the batch alike, so a row that read the earliest time of the whole batch,
    the other sequences', passed. Check 6 now scores every sequence alone, against its scores in the batch, on a
    32-bit copy: that row fails, and the named configurations pass."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    two, alone = bm.one_model_two_batches(_ReadsTheBatchOrigin(), batch, units_per_second=UNIT)
    assert two == 0.0 and alone > 0.01
    result = bm.run_checks(_ReadsTheBatchOrigin(), batch, units_per_second=UNIT, say=lambda line: None)
    assert [name for name, ok in result["passes"].items() if not ok] == ["two batches"]
    for name in ("TODAY", "CANDIDATE"):
        two, alone = bm.one_model_two_batches(_built(bm.CONFIGURATIONS[name]), batch, units_per_second=UNIT)
        assert two == 0.0 and alone <= bm.ORDER_TOLERANCE, name


def test_check_6_sets_the_model_against_a_new_instance_and_a_training_call_against_a_first_one():
    """Every new instance of check 6 was a copy of the model as handed over, so an origin fixed on a call before the
    checks rode into every copy, and training mode was never called twice on one instance. With `build` the new
    instance has never been called, and check 6 runs two training calls on one instance against one call on a new
    one: both leaks fail, and BestModel passes."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    model = _LazyPlainOrigin()
    with torch.no_grad():
        model.eval()(bm.make_batch(seed=5, sequences=8, rows=40))         # called once, as a trained model has been
    assert bm.one_model_two_batches(model, batch, units_per_second=UNIT)[0] == 0.0
    assert bm.one_model_two_batches(model, batch, units_per_second=UNIT, build=_LazyPlainOrigin)[0] > 0.0
    memory = bm.run_checks(_TrainingMemory(), batch, units_per_second=UNIT, say=lambda line: None)
    assert [name for name, ok in memory["passes"].items() if not ok] == ["two batches"]
    small = bm.make_batch(seed=1, sequences=4, rows=20)
    two, alone = bm.one_model_two_batches(_built(bm.CANDIDATE), small, units_per_second=UNIT,
                                          build=lambda: bm.BestModel(bm.CANDIDATE))
    assert two == 0.0 and alone <= bm.ORDER_TOLERANCE


def test_reads_of_training_steps_alone_are_seen_and_dropout_from_numpy_is_drawn_alike():
    """The training passes ran without gradients and only in checks 1 and 2, and seeded torch alone. They now run
    with gradients on, checks 3 and 7 have training passes too, and Python's random module and numpy are seeded
    alike: a read of later rows while gradients are on fails check 1, a count of the row's own second in training
    alone fails checks 3 and 7, and a model that keeps the rule with a numpy dropout passes."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    later = bm.run_checks(_ReadsLaterRowsWhileLearning(), batch, units_per_second=UNIT, say=lambda line: None)
    assert not later["passes"]["later rows"] and later["kept"] > 0.0

    class _CountsItsSecondInTraining(_Plus):
        def term(self, batch):
            valid, seconds = batch["mask"].bool(), _seconds(batch)
            same = (seconds.unsqueeze(1) == seconds.unsqueeze(2)) & valid.unsqueeze(1) & valid.unsqueeze(2)
            return same.sum(dim=-1).float() if self.training else torch.zeros(valid.shape)

    burst = bm.run_checks(_CountsItsSecondInTraining(), batch, units_per_second=UNIT, say=lambda line: None)
    assert [name for name, ok in burst["passes"].items() if not ok] == ["prefix", "order in a second"]
    state = np.random.get_state()
    assert all(bm.run_checks(_NumpyDropout(), batch, units_per_second=UNIT)["passes"].values())
    assert np.array_equal(np.random.get_state()[1], state[1])


def test_an_entry_the_builder_works_out_is_seen_through_rebuild():
    """Every check carried every entry with its row, so a model that read a slot index the builder writes passed all
    seven although the index counts the rows of its own second in earlier slots. With `rebuild` writing the index
    again after every change the model fails, and one that keeps the rule passes."""
    batch = _with_slot_index(_sorted_inside_seconds(bm.make_batch(seed=0, sequences=8, rows=30)))
    assert all(bm.run_checks(_ReadsTheSlotIndex(), batch, units_per_second=UNIT)["passes"].values())
    seen = bm.run_checks(_ReadsTheSlotIndex(), batch, units_per_second=UNIT, rebuild=_with_slot_index,
                         say=lambda line: None)
    assert not seen["passes"]["order in a second"]
    kept = bm.run_checks(_ReadsEarlierSeconds(), batch, units_per_second=UNIT, rebuild=_with_slot_index)
    assert all(kept["passes"].values())


def test_a_scan_over_slots_in_time_order_and_a_row_that_reads_its_own_time_pass():
    """Check 7 pushed the other rows of a witness's second an hour later in their own slots, so a batch in time order
    came out of it, and a scorer that reads its history in slot order read them. They now leave the second for the
    next second of their sequence, at the time of its earliest row, or leave the window: such a scorer passes."""
    for seed in (0, 1):
        batch = _sorted_inside_seconds(bm.make_batch(seed=seed, sequences=8, rows=40))
        assert all(bm.run_checks(_BlockScan(), batch, units_per_second=UNIT)["passes"].values()), seed


def test_the_comparisons_that_allow_rounding_run_in_32_bits_at_full_precision():
    """Checks 3 and 7 allow rounding, and a model under autocast to 16 bits, cast to 16 bits or with matrix products
    at medium precision failed them by rounding alone. They now run on a copy in 64 bits, or in 32 bits at full
    precision, with autocast off, every setting put back after: CANDIDATE passes in each case, and so does the model
    cast to 16 bits on its slots made padding in place, in its own number type."""
    batch = bm.make_batch(seed=0, sequences=4, rows=30)
    with torch.autocast("cpu", dtype=torch.bfloat16):
        assert all(bm.run_checks(_built(bm.CANDIDATE), batch, units_per_second=UNIT)["passes"].values())
    cast = _built(bm.CANDIDATE).to(torch.bfloat16)
    assert bm.prefix_agrees(cast, batch, units_per_second=UNIT) < bm.PREFIX_TOLERANCE
    assert bm.order_inside_a_second(cast, batch, units_per_second=UNIT)[0] <= bm.ORDER_TOLERANCE
    before = torch.get_float32_matmul_precision()
    torch.set_float32_matmul_precision("medium")
    try:
        assert bm.prefix_agrees(_built(bm.CANDIDATE), batch, units_per_second=UNIT) < bm.PREFIX_TOLERANCE
        assert torch.get_float32_matmul_precision() == "medium"
    finally:
        torch.set_float32_matmul_precision(before)


def test_a_batch_without_padding_is_checked_on_a_copy_with_a_padded_slot():
    """Check 2 gave not a number on a batch of full windows. It now makes the last real row of the fullest sequence
    padding in a copy, says so, and runs there; with a mask given as a function and no `pad` it cannot, and says
    so."""
    batch = bm.make_batch(seed=1, sequences=4, rows=12)
    full = {name: value[:1] for name, value in batch.items()}
    assert bool(full["mask"].all())
    lines = []
    change, finite = bm.padding_stays_out(_ReadsEarlierSeconds(), full, say=lines.append)
    assert change == 0.0 and finite and "was made padding" in lines[0]
    assert bm.padding_stays_out(_ReadsPadding(), full, say=lambda line: None)[0] > 0.0
    lines = []
    change, finite = bm.padding_stays_out(_ReadsEarlierSeconds(), full, real=lambda b: b["mask"], say=lines.append)
    assert change != change and "none can be made" in lines[0]


def test_a_mask_true_on_padding_is_named_with_a_tilde_and_pad_follows_it():
    """real="~is_pad" names a mask that is True on padding: the checks read it and write it, so that check 3 and check
    7 can make padding of their own. A function in its place without `pad` cannot make padding: checks 3 and 7
    give not a number on a batch padded on the left, with a line."""
    batch = _left_padded(bm.make_batch(seed=22, sequences=4, rows=20))
    padded = {name: value for name, value in batch.items() if name != "mask"}
    padded["is_pad"] = ~batch["mask"]
    model = _MaskFromPadding(_ReadsEarlierSeconds())

    def loss(model, batch):
        valid = ~batch["is_pad"]
        return F.cross_entropy(model(batch)[valid], batch["target_seq"][valid])

    result = bm.run_checks(model, padded, units_per_second=UNIT, real="~is_pad", loss=loss)
    assert all(result["passes"].values()), result
    assert bm._real(padded, "~is_pad").equal(batch["mask"])
    written = bm._padder("~is_pad", None)(padded, torch.ones_like(batch["mask"]))
    assert bool(written["is_pad"].all()) and not bool(padded["is_pad"].all())
    lines = []
    blind = bm.run_checks(model, padded, units_per_second=UNIT, real=lambda b: ~b["is_pad"], loss=loss,
                          say=lines.append)
    assert not blind["passes"]["prefix"] and not blind["passes"]["order in a second"]
    assert any("needs `pad`" in line for line in lines)


def test_check_1_moves_integer_minutes_by_whole_minutes():
    """With integer times in whole minutes check 1 kept every time, and a read of the times of later rows was left to
    checks 3 and 7. The later rows now move by whole minutes: such a read fails check 1 there too."""

    class _ReadsLatestMinute(_RowByItself):
        def forward(self, batch):
            x, valid, times = self.row(batch), batch["mask"].bool(), batch["time_seq"]
            latest = torch.where(valid, times, torch.zeros_like(times)).amax(dim=1, keepdim=True)
            minute = (latest % 1_440).float() / 1_440
            return torch.stack([x + minute, x - minute], dim=-1) * self.weight

    batch = bm.make_batch(seed=16, sequences=4, rows=24)
    batch["time_seq"] = torch.where(batch["mask"], torch.div(batch["time_seq"], 60 * UNIT, rounding_mode="floor"), 0)
    lines = []
    kept, later, read = bm.later_rows_change_nothing(_ReadsLatestMinute(), batch, units_per_second=1 / 60,
                                                     say=lines.append)
    assert kept > 0.0 and not any("cannot be moved" in line for line in lines)


def test_channels_stay_apart_says_when_the_hand_off_is_a_plain_function():
    """A lambda or a functools.partial runs as it is, its weights not moved, so a mixing part behind it that starts at
    zero reads as apart; one printed line says so, and a module or a method of one prints nothing."""
    M, d = 3, 4
    summary = torch.randn(2, 5, M, d, generator=torch.Generator().manual_seed(1))
    lines = []
    bm.channels_stay_apart(lambda s: s, summary, say=lines.append)
    assert len(lines) == 1 and "plain function" in lines[0]
    lines = []
    bm.channels_stay_apart(_WithHandOff(M, d).hand_off, summary, say=lines.append)
    bm.channels_stay_apart(nn.LayerNorm(d), summary, say=lines.append)
    assert lines == []


# ------------------------------------------------------- what the checks no longer fail, and the lines they print

class _PackedDropout(_RowByItself):
    """Keeps the rule: its history is a mean over the real rows of strictly earlier seconds after a dropout drawn
    over the real rows alone, packed as x[valid], as a model that drops its padding before its layers does."""

    def __init__(self):
        super().__init__()
        self.drop = nn.Dropout(0.3)

    def forward(self, batch):
        x, valid = self.row(batch), batch["mask"].bool()
        packed = torch.zeros_like(x)
        packed[valid] = self.drop(x[valid])
        mean = _earlier_mean(packed, batch)
        return torch.stack([x + 0.5 * mean, x - 0.5 * mean], dim=-1) * self.weight


class _ReadsEarlierTimesOnly(_RowByItself):
    """Keeps the rule and reads only the times of earlier rows: how many real rows of strictly earlier seconds lie in
    the hour before its own second."""

    def forward(self, batch):
        x, valid, seconds = self.row(batch), batch["mask"].bool(), _seconds(batch)
        gap = seconds.unsqueeze(2) - seconds.unsqueeze(1)                                  # [b, i, j]: i's second - j's
        recent = (gap > 0) & (gap <= 3_600) & valid.unsqueeze(1) & valid.unsqueeze(2)
        count = torch.log1p(recent.sum(dim=-1).float())
        return torch.stack([x + count, x - count], dim=-1) * self.weight


class _ReadsEarlierLabelsOnly(_RowByItself):
    """Keeps the rule and reads only the answers of earlier rows: the share of positive labels among the real rows
    of strictly earlier seconds."""

    def forward(self, batch):
        x = self.row(batch)
        share = _earlier_mean((batch["target_seq"] == 1).float(), batch)
        return torch.stack([x + share, x - share], dim=-1) * self.weight


class _AssertsItsWidth(_ReadsEarlierSeconds):
    """Keeps the rule, and checks its width with an assert, as research code often does."""

    def __init__(self, width):
        super().__init__()
        self.width = width

    def forward(self, batch):
        assert batch["mask"].shape[1] == self.width, "the batch must be as wide as the model"
        return super().forward(batch)


class _TakesOnlyLeftPadding(_ReadsEarlierSeconds):
    """Keeps the rule, and takes only windows padded on the left: a padded slot after a real row stops it."""

    def forward(self, batch):
        valid = batch["mask"].bool()
        if bool((valid[:, :-1] & ~valid[:, 1:]).any()):
            raise ValueError("a padded slot after a real row")
        return super().forward(batch)


class _DropoutFromItsOwnGenerator(_ReadsEarlierSeconds):
    """Keeps the rule, with a dropout in training mode drawn from a torch.Generator the model holds, which every
    training call moves on."""

    def __init__(self):
        super().__init__()
        self.generator = torch.Generator().manual_seed(123)

    def forward(self, batch):
        out = super().forward(batch)
        if self.training:
            out = out * (torch.rand(out.shape, generator=self.generator) > 0.3).float() / 0.7
        return out


class _WithExtraState(_ReadsEarlierSeconds):
    """Keeps the rule, and keeps a setting that is not a tensor in its state (get_extra_state)."""

    def __init__(self):
        super().__init__()
        self.unit = "ns"

    def get_extra_state(self):
        return {"unit": self.unit}

    def set_extra_state(self, state):
        self.unit = state["unit"]


class _CountsItsCalls(_ReadsEarlierSeconds):
    """Keeps the rule, and counts its calls in a plain attribute that no score reads."""

    def __init__(self):
        super().__init__()
        self.calls = 0

    def forward(self, batch):
        self.calls += 1
        return super().forward(batch)


class _ReadsItsOwnChargeback(_Plus):
    """Reads the days from its own time to its own chargeback, an outcome held in whole nanoseconds."""

    def term(self, batch):
        days = (batch["chargeback_time"] - batch["time_seq"]).clamp(min=0).double() / (86_400 * UNIT)
        return torch.log1p(days)


def test_the_passes_in_training_mode_keep_every_row_real():
    """Check 7 made the other rows of a sequence's last shared second padding and compared the witness in training
    mode, so a model that drops its padding before a dropout drew other masks for later rows and failed. Every row now
    stays real and in its slot in that pass: the model passes, and a count of the row's own second is still seen."""
    for seed in (0, 1):
        batch = bm.make_batch(seed=seed, sequences=8, rows=40)
        assert all(bm.run_checks(_PackedDropout(), batch, units_per_second=UNIT)["passes"].values()), seed
    result = bm.run_checks(_CountsItsSecond(), bm.make_batch(seed=0, sequences=8, rows=40), units_per_second=UNIT,
                           say=lambda line: None)
    assert not result["passes"]["order in a second"]


def test_a_history_of_times_or_answers_alone_is_read():
    """The read of check 1 changed only the inputs of the earlier rows, so a model whose history reads only their
    times or their answers got read 0.0 and failed, with a line that blamed the mask. The read now also redraws their
    answers and moves the rows of earlier seconds an hour earlier: both models pass. A batch with no earlier second to
    read says so, and names the mask only as one cause of it."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    for model in (_ReadsEarlierTimesOnly(), _ReadsEarlierLabelsOnly()):
        result = bm.run_checks(model, batch, units_per_second=UNIT)
        assert all(result["passes"].values()) and result["read"] > 0.0, type(model).__name__
    burst = bm.make_batch(seed=0, sequences=2, rows=6)
    burst["time_seq"] = torch.where(burst["mask"], burst["time_seq"][:, :1], burst["time_seq"])
    lines = []
    bm.later_rows_change_nothing(_ReadsEarlierSeconds(), burst, units_per_second=UNIT, say=lines.append)
    assert any("no changed row has a real row of an earlier second" in line for line in lines), lines


def test_models_that_check_their_input_their_own_way_pass():
    """A model that checks its width with an assert stopped run_checks in check 3, and one that takes only windows
    padded on the left stopped it in checks 2 and 7. Check 3 now also falls back on an AssertionError, check 7 keeps
    every row real, and check 2 makes the first real row padding when the model stops on the last: both pass."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    assert all(bm.run_checks(_AssertsItsWidth(40), batch, units_per_second=UNIT, say=lambda line: None)[
        "passes"].values())
    left = _left_padded(batch)
    assert all(bm.run_checks(_TakesOnlyLeftPadding(), left, units_per_second=UNIT)["passes"].values())
    full = {name: value[:1] for name, value in bm.make_batch(seed=1, sequences=4, rows=12).items()}
    lines = []
    change, finite = bm.padding_stays_out(_TakesOnlyLeftPadding(), full, say=lines.append)
    assert change == 0.0 and finite and "the first real row" in lines[0]


def test_answers_of_other_types_and_quantities_are_redrawn():
    """_redrawn took the classes from the largest value of the whole entry, padding included, in its own type, so
    labels in uint8 with 255 on padding stopped the checks, and it moved a quantity such as a time by one unit. Classes
    are now taken from the redrawn rows in int64, and a quantity moves by its spread: uint8 labels pass, and a row
    that reads its own chargeback time fails once the entry is named."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    narrow = dict(batch, target_seq=torch.where(batch["mask"], batch["target_seq"], 255).to(torch.uint8))
    assert all(bm.run_checks(_ReadsEarlierLabels(), narrow, units_per_second=UNIT)["passes"].values())
    own = bm.run_checks(_ReadsItsOwnLabel(), narrow, units_per_second=UNIT, say=lambda line: None)
    assert not own["passes"]["later rows"]
    later = batch["time_seq"] + torch.randint(1, 90, batch["mask"].shape) * 86_400 * UNIT
    outcome = dict(batch, chargeback_time=torch.where(batch["mask"], later, 0))
    named = bm.run_checks(_ReadsItsOwnChargeback(), outcome, units_per_second=UNIT,
                          labels=("target_seq", "chargeback_time"), say=lambda line: None)
    assert not named["passes"]["later rows"] and not named["passes"]["order in a second"]
    rows = torch.tensor([[True, True, False]])
    moved = bm._redrawn({"t": torch.tensor([[100, 130, 7]])}, rows, "t")["t"]
    assert moved.tolist() == [[131, 161, 7]]


def test_check_6_takes_state_that_is_not_a_tensor_and_a_generator_the_model_holds():
    """With build, check 6 stopped on a model that keeps a setting that is not a tensor in its state, and it failed a
    model whose dropout comes from a generator of its own, since one instance had taken a training call more than
    the other. The state is now copied whatever it holds, and both instances take one training call before the
    compared one: both models pass, and a memory of the previous training batch still fails."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    assert all(bm.run_checks(_WithExtraState(), batch, units_per_second=UNIT, build=_WithExtraState)[
        "passes"].values())
    assert all(bm.run_checks(_DropoutFromItsOwnGenerator(), batch, units_per_second=UNIT)["passes"].values())
    memory = bm.run_checks(_TrainingMemory(), batch, units_per_second=UNIT, say=lambda line: None)
    assert not memory["passes"]["two batches"]


def test_the_state_line_names_what_a_later_call_reads_and_not_a_counter():
    """The line of check 6 named every attribute an instance held otherwise after another batch, a count of calls
    among them. It now names one only when a second call on the same batch leaves it as the first left it: an origin
    fixed on the first call is named, a counter is not."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    lines = []
    bm.one_model_two_batches(_LazyPlainOrigin(), batch, units_per_second=UNIT, say=lines.append)
    assert any("keeps origin" in line for line in lines), lines
    lines = []
    two, alone = bm.one_model_two_batches(_CountsItsCalls(), batch, units_per_second=UNIT, say=lines.append)
    assert two == 0.0 and alone <= bm.ORDER_TOLERANCE and lines == []


def test_run_checks_names_what_no_check_changes_and_reads_the_mask_it_is_given():
    """run_checks named entries laid out per window only, so an answer under another name than target_seq, or a column
    the builder works out from the answers, passed with nothing printed, and its default loss read batch["mask"]
    whatever `real` said. It now names a name of `labels` the batch does not hold and an entry per row that `alter`
    leaves as it is, and the default loss reads the mask `real` names."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    renamed = {("label" if name == "target_seq" else name): value for name, value in batch.items()}
    renamed["frauds_so_far"] = (renamed["label"] == 1).long().cumsum(dim=1)
    lines = []
    bm.run_checks(_ReadsEarlierSeconds(), renamed, units_per_second=UNIT, labels=("target_seq",),
                  loss=lambda model, b: model(b).sum(), say=lines.append)
    assert any("labels names target_seq, which the batch does not hold" in line for line in lines), lines
    assert any("`alter` leaves label, frauds_so_far as they are" in line for line in lines), lines
    padded = {name: value for name, value in batch.items() if name != "mask"}
    padded["is_pad"] = ~batch["mask"]
    result = bm.run_checks(_MaskFromPadding(_ReadsEarlierSeconds()), padded, units_per_second=UNIT, real="~is_pad")
    assert all(result["passes"].values())


def test_the_precision_is_put_back_however_it_was_set():
    """The checks put back the summary of the matmul precision, so a setting made through the older flag, or on one
    backend after the summary, came back otherwise. Every backend is now put back as it was read."""
    flag = torch.backends.cuda.matmul.allow_tf32
    try:
        torch.backends.cuda.matmul.allow_tf32 = True
        before = (torch.get_float32_matmul_precision(), torch.backends.mkldnn.matmul.fp32_precision)
        with bm._full_precision():
            assert torch.get_float32_matmul_precision() == "highest"
        assert (torch.get_float32_matmul_precision(), torch.backends.mkldnn.matmul.fp32_precision) == before
        assert torch.backends.cuda.matmul.allow_tf32 is True
    finally:
        torch.backends.cuda.matmul.allow_tf32 = flag
        torch.set_float32_matmul_precision("highest")


def test_check_7_spreads_its_passes_over_many_shared_seconds():
    """Check 7 ran a pass for every shared second of the sequence that holds the most, so its time grew with them. It
    now runs at most ORDER_PASSES passes, spread from a sequence's first shared second to its last."""
    assert [bm._pass_second(3, step, 8) for step in range(8)] == [0, 1, 2, None, None, None, None, None]
    assert [bm._pass_second(22, step, 8) for step in range(8)] == [0, 3, 6, 9, 12, 15, 18, 21]
    assert bm.ORDER_PASSES == 8


def test_the_look_of_the_encoder_can_be_closed_at_once():
    """A training step compiled with fullgraph needs the look of the encoder closed; close_look closes it."""
    model = _built(bm.TODAY).train()
    assert model.numbers._look_open
    model.numbers.close_look()
    assert model.numbers._look_open is False and not bool(model.numbers._scale_open.any())


class _ReadsTheNextRowLate(_Plus):
    """Reads the next real row, but only in the last quarter of its window's real rows: a leak late in a window."""

    def term(self, batch):
        valid, x = batch["mask"].bool(), self.row(batch)
        rank = valid.long().cumsum(dim=1) - 1
        late = valid & (rank >= 3 * valid.sum(dim=1, keepdim=True) // 4)
        following = torch.cat([x[:, 1:], torch.zeros_like(x[:, :1])], dim=1)
        real_next = torch.cat([valid[:, 1:], torch.zeros_like(valid[:, :1])], dim=1)
        return torch.where(late & real_next, following, torch.zeros_like(x))


class _FirstRowReadsTheSecond(_Plus):
    """The first real row of a window reads the second: a leak at the start of a window alone."""

    def term(self, batch):
        valid, x = batch["mask"].bool(), self.row(batch)
        rank = valid.long().cumsum(dim=1) - 1
        second = (x * (valid & (rank == 1))).sum(dim=1, keepdim=True)
        return torch.where(valid & (rank == 0), second.expand_as(x), torch.zeros_like(x))


class _TakesOnlyRightPadding(_ReadsEarlierSeconds):
    """Keeps the rule, and takes only windows padded on the right: a padded slot before a real row stops it."""

    def forward(self, batch):
        valid = batch["mask"].bool()
        if bool((~valid[:, :-1] & valid[:, 1:]).any()):
            raise ValueError("a padded slot before a real row")
        return super().forward(batch)


class _FixesOnItsSecondCall(_Plus):
    """Fixes an origin of time on its second call, in a plain attribute, and reads it from the third call on: the
    batch it scored before reaches every later score."""

    def __init__(self):
        super().__init__()
        self.calls, self.origin = 0, None

    def term(self, batch):
        self.calls += 1
        seconds = _seconds(batch)
        if self.calls == 2:
            self.origin = int(seconds[batch["mask"].bool()].min())
        if self.calls < 3:
            return torch.zeros(seconds.shape)
        return (seconds - self.origin).double() / 86_400 / 1_000


class _CentreFromTraining(_Plus):
    """Keeps the mean row of its latest training batch in a plain attribute, outside its weights and buffers, and
    adds it to every score in scoring mode: the batch it last trained on reaches every later score."""

    def __init__(self):
        super().__init__()
        self.centre = 0.0

    def term(self, batch):
        valid = batch["mask"].bool()
        if self.training:
            self.centre = float(self.row(batch)[valid].mean())
            return torch.zeros(valid.shape)
        return torch.full(valid.shape, self.centre)


class _ReadsOtherSequencesWhileLearning(_Plus):
    """In training mode, adds the mean first real row of every sequence of the batch: the other sequences reach a
    training step alone."""

    def term(self, batch):
        valid = batch["mask"].bool()
        if not self.training:
            return torch.zeros(valid.shape)
        rank = valid.long().cumsum(dim=1) - 1
        first = (self.row(batch) * (valid & (rank == 0))).sum(dim=1)
        return first.mean().expand(valid.shape)


class _LastRowsReadEachOther(_Plus):
    """The last `n` real rows of a window read the mean of all of them: a leak confined to the end of a window."""

    def __init__(self, n=3):
        super().__init__()
        self.n = n

    def term(self, batch):
        valid, x = batch["mask"].bool(), self.row(batch)
        rank = valid.long().cumsum(dim=1) - 1
        last = valid & (rank >= valid.sum(dim=1, keepdim=True) - self.n)
        mean = (x * last).sum(dim=1, keepdim=True) / last.sum(dim=1, keepdim=True).clamp(min=1)
        return torch.where(last, mean.expand_as(x), torch.zeros_like(x))


class _SlotsFromReadEachOther(_Plus):
    """The real rows in slots `start` and after read the mean of all of them: a leak confined to the end of a window,
    by slot."""

    def __init__(self, start):
        super().__init__()
        self.start = start

    def term(self, batch):
        valid, x = batch["mask"].bool(), self.row(batch)
        block = valid & (torch.arange(valid.shape[1]) >= self.start)
        mean = (x * block).sum(dim=1, keepdim=True) / block.sum(dim=1, keepdim=True).clamp(min=1)
        return torch.where(block, mean.expand_as(x), torch.zeros_like(x))


def test_the_probes_of_check_1_are_spread_over_the_window_and_one_pass_keeps_all_but_the_last_rows(monkeypatch):
    """Check 1 put every probe near the middle of its window, so a leak late in a window passed; with the probes at a
    few fixed places, a leak among the last rows still passed on some batches (seed 1 here). The probes now aim at
    1/2, 1/4, 3/4, 1/8 and so on of the way through the real rows, sequence by sequence, and a second pass puts every
    probe at the second-to-last real row: a leak among the last rows fails, and passes again without that pass."""
    valid = torch.ones(7, 16, dtype=torch.bool)
    seconds = torch.arange(16).repeat(7, 1)
    assert bm._probes(valid, seconds).nonzero()[:, 1].tolist() == [8, 4, 12, 2, 10, 6, 14]
    assert bm._probes(valid, seconds, late=True).nonzero()[:, 1].tolist() == [14] * 7
    assert [bm._probe_share(b) for b in range(8)] == [0.5, 0.25, 0.75, 0.125, 0.625, 0.375, 0.875, 0.0625]
    batch = bm.make_batch(seed=1, sequences=8, rows=40)
    quiet = lambda line: None
    for model in (_ReadsTheNextRowLate(), _LastRowsReadEachOther()):
        kept, later, read = bm.later_rows_change_nothing(model, batch, units_per_second=UNIT, say=quiet)
        assert kept > 0.0, type(model).__name__
    spread = bm._probes
    monkeypatch.setattr(bm, "_probes", lambda valid, seconds, late=False: spread(valid, seconds))
    kept, later, read = bm.later_rows_change_nothing(_LastRowsReadEachOther(), batch, units_per_second=UNIT, say=quiet)
    assert kept == 0.0


def test_check_3_cuts_near_the_start_every_eighth_and_the_end_of_the_window(monkeypatch):
    """Check 3 cuts near the first slot, near every eighth and near the last slot, each cut leaving real rows on both
    sides in some sequence, so that a late cut still cuts the long windows of a batch: a leak at the start fails and
    passes again with the middle cut alone, and a leak in the last two slots of a full window, cut as slices, fails
    and passes again without the cut near the last slot."""
    assert bm._spread_cuts(torch.ones(1, 16, dtype=torch.bool)) == [1, 2, 4, 6, 8, 10, 12, 14, 15]
    assert bm._spread_cuts(torch.tensor([[False] * 8 + [True] * 8])) == [9, 10, 12, 14, 15]
    assert bm._cut_near(torch.tensor([[True, False, False, False]]), 2) == 2
    lengths = torch.zeros(2, 16, dtype=torch.bool)
    lengths[0], lengths[1, :4] = True, True
    assert bm._cut_near(lengths, 14) == 14
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    assert bm.prefix_agrees(_FirstRowReadsTheSecond(), batch, units_per_second=UNIT) > bm.PREFIX_TOLERANCE
    full = {name: value[:1] for name, value in bm.make_batch(seed=1, sequences=4, rows=12).items()}
    quiet = lambda line: None
    assert bm.prefix_agrees(_SlotsFromReadEachOther(10), full, units_per_second=UNIT, say=quiet) > bm.PREFIX_TOLERANCE
    # Without the cut near the last slot (and without the cut inside a shared second, which may fall there too).
    spread = bm._spread_cuts
    monkeypatch.setattr(bm, "_spread_cuts", lambda valid: [k for k in spread(valid) if k < valid.shape[1] - 1])
    monkeypatch.setattr(bm, "_cut_in_a_second", lambda valid, seconds: None)
    assert bm.prefix_agrees(_SlotsFromReadEachOther(10), full, units_per_second=UNIT,
                            say=quiet) <= bm.PREFIX_TOLERANCE
    monkeypatch.setattr(bm, "_spread_cuts", lambda valid: [bm._middle_cut(valid)])
    assert bm.prefix_agrees(_FirstRowReadsTheSecond(), batch, units_per_second=UNIT) <= bm.PREFIX_TOLERANCE


class _BlockInTheMiddle(_Plus):
    """The rows in slots 21 to 23 read the mean of all three: a leak confined to three slots in the middle."""

    def term(self, batch):
        valid, x = batch["mask"].bool(), self.row(batch)
        block = valid & (torch.arange(valid.shape[1]) >= 21) & (torch.arange(valid.shape[1]) <= 23)
        mean = (x * block).sum(dim=1, keepdim=True) / block.sum(dim=1, keepdim=True).clamp(min=1)
        return torch.where(block, mean.expand_as(x), torch.zeros_like(x))


def test_check_3_takes_a_list_of_cuts_and_a_sweep_over_every_slot():
    """A leak confined to a few slots between two cuts passes the cuts check 3 takes by itself; `cut` takes several
    slots, and range(1, T) cuts after every one of them, which sees it."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    quiet = lambda line: None
    assert bm.prefix_agrees(_BlockInTheMiddle(), batch, cut=[20, 25], units_per_second=UNIT,
                            say=quiet) <= bm.PREFIX_TOLERANCE
    assert bm.prefix_agrees(_BlockInTheMiddle(), batch, cut=range(1, 40), units_per_second=UNIT,
                            say=quiet) > bm.PREFIX_TOLERANCE
    assert bm.prefix_agrees(_ReadsEarlierSeconds(), batch, cut=range(1, 40), units_per_second=UNIT,
                            say=quiet) <= bm.PREFIX_TOLERANCE


class _FromLengths(_ReadsEarlierSeconds):
    """Keeps the rule for a builder that pads on the right: it takes its real rows to be the first n slots of a window,
    n the number of real rows, as a model handed lengths does."""

    def forward(self, batch):
        valid = batch["mask"].bool()
        first = torch.arange(valid.shape[1]).unsqueeze(0) < valid.sum(dim=1, keepdim=True)
        return super().forward(dict(batch, mask=first))


def test_a_batch_of_full_windows_is_cut_as_slices_unless_pads_names_the_side():
    """A batch of full windows does not say on which side its builder pads. Laying its cut windows out padded on the
    left failed a model that takes its real rows from the window's length, which keeps the rule for a builder that
    pads on the right, and laying them out on the right stopped a model that takes only windows padded on the left.
    Such a batch is now cut as slices, with one line, and `pads` names the side: with pads="left" a row that reads
    the padding in front of it fails; without it, every one of these models passes."""
    full = {name: value[:1] for name, value in bm.make_batch(seed=1, sequences=4, rows=12).items()}
    assert bool(full["mask"].all())
    lines = []
    assert bm.prefix_agrees(_CountsPaddingInFront(), full, units_per_second=UNIT,
                            say=lines.append) <= bm.PREFIX_TOLERANCE
    assert sum("cannot be read" in line for line in lines) == 1, lines
    assert bm.prefix_agrees(_CountsPaddingInFront(), full, units_per_second=UNIT, pads="left",
                            say=lambda line: None) > bm.PREFIX_TOLERANCE
    for model in (_FromLengths(), _TakesOnlyRightPadding(), _TakesOnlyLeftPadding()):
        result = bm.run_checks(model, full, units_per_second=UNIT, say=lambda line: None)
        assert all(result["passes"].values()), (type(model).__name__, result)
    assert all(bm.run_checks(_FromLengths(), bm.make_batch(seed=0, sequences=8, rows=40), units_per_second=UNIT)[
        "passes"].values())
    lines = []
    change, finite = bm.padding_stays_out(_ReadsEarlierSeconds(), full, pads="left", say=lines.append)
    assert change == 0.0 and finite and "the first real row" in lines[0]


def test_a_function_mask_without_pad_fails_where_padding_must_be_made():
    """With a function `real` and no `pad`, check 3 compared a batch padded on the left as slices and check 7 left
    its second pass out, each with a line, and every check passed: a row that reads the padding in front of it went
    unseen. Both checks now give not a number there, with their line; with `pad` the same model passes."""
    batch = _left_padded(bm.make_batch(seed=0, sequences=8, rows=40))
    padded = {name: value for name, value in batch.items() if name != "mask"}
    padded["is_pad"] = ~batch["mask"]
    model = _MaskFromPadding(_ReadsEarlierSeconds())

    def loss(model, batch):
        valid = ~batch["is_pad"]
        return F.cross_entropy(model(batch)[valid], batch["target_seq"][valid])

    lines = []
    blind = bm.run_checks(model, padded, units_per_second=UNIT, real=lambda b: ~b["is_pad"], loss=loss,
                          say=lines.append)
    assert blind["prefix"] != blind["prefix"] and blind["order"] != blind["order"]
    assert sum("needs `pad`" in line for line in lines) == 2, lines
    seen = bm.run_checks(model, padded, units_per_second=UNIT, real=lambda b: ~b["is_pad"], loss=loss,
                         pad=lambda b, rows: dict(b, is_pad=b["is_pad"] | rows))
    assert all(seen["passes"].values()), seen


class _OrderWhileLearning(_Plus):
    """In training mode only, reads how many real rows of its own second sit in earlier slots."""

    def term(self, batch):
        valid = batch["mask"].bool()
        if not self.training:
            return torch.zeros(valid.shape)
        seconds, T = _seconds(batch), valid.shape[1]
        earlier_slot = torch.arange(T).unsqueeze(0) < torch.arange(T).unsqueeze(1)        # [i, j]: j before i
        same = (seconds.unsqueeze(2) == seconds.unsqueeze(1)) & valid.unsqueeze(1) & valid.unsqueeze(2) & earlier_slot
        return torch.log1p(same.sum(dim=-1).float())


class _ShareWhileLearning(_ShareOfWindow):
    """_ShareOfWindow in training mode only: its share of the window."""

    def term(self, batch):
        if not self.training:
            return torch.zeros(batch["mask"].shape)
        return super().term(batch)


class _KeepsItsFirstPosition(_ReadsEarlierSeconds):
    """Keeps the rule, and keeps the scores of its first position from its last call, as the model in use keeps its
    first position: after a call with gradients on, a tensor that is no leaf of the graph."""

    def forward(self, batch):
        out = super().forward(batch)
        self._first = out[:, 0]
        return out


class _ReadsTheProfileOfItsWindow(_Plus):
    """Keeps the rule: reads one value per window from the entry `profile`, a list, an array or a tensor of B values."""

    def term(self, batch):
        profile = torch.as_tensor(np.asarray(batch["profile"], dtype=np.float32))
        return profile.unsqueeze(1).expand(batch["mask"].shape)


def test_the_checks_take_a_model_after_a_step_compiled_or_from_meta_numbers_in_16_bits_and_lists_per_window():
    """The checks deep-copied the model as handed over, so one that keeps a tensor of its last call stopped them after
    a training step; check 2 wrote 1e30 into numbers in float16; check 6 cut and rolled only tensors, so a value per
    window held in a list failed it; a compiled model with `build` stopped check 6; and an encoder built on the meta
    device kept its flag there when loaded from a checkpoint without it. Each now runs, and every model keeps the
    rule and passes."""
    batch = bm.make_batch(seed=0, sequences=6, rows=20)
    quiet = lambda line: None
    model = _KeepsItsFirstPosition()
    model.train()
    bm.row_loss(model, batch).backward()
    assert not model._first.is_leaf
    result = bm.run_checks(model, batch, units_per_second=UNIT, build=_KeepsItsFirstPosition, say=quiet)
    assert all(result["passes"].values()), result
    assert bm.cost(model, batch, repeats=1)["forward_seconds"] > 0.0
    half = dict(batch, continuous=batch["continuous"].half())
    result = bm.run_checks(_built(bm.TODAY), half, units_per_second=UNIT, say=quiet)
    assert all(result["passes"].values()) and result["padding"] == 0.0, result
    for kind in (list, np.array, torch.tensor):
        lines = []
        held = dict(batch, profile=kind([0.1 * i for i in range(6)]))
        result = bm.run_checks(_ReadsTheProfileOfItsWindow(), held, units_per_second=UNIT, say=lines.append)
        assert all(result["passes"].values()), (kind.__name__, result)
        assert any(line.startswith("run_checks: profile is not laid out per row") for line in lines), lines
    compiled = torch.compile(bm.BestModel(bm.TODAY), backend="eager")
    result = bm.run_checks(compiled, bm.make_batch(seed=0, sequences=4, rows=16), units_per_second=UNIT,
                           build=lambda: bm.BestModel(bm.TODAY), say=quiet)
    assert all(result["passes"].values()), result
    with torch.device("meta"):
        empty = bm.BestModel(bm.TODAY)
    state = {name: value for name, value in bm.BestModel(bm.TODAY).state_dict().items()
             if not name.endswith("held_to_unit")}
    empty.load_state_dict(state, assign=True)
    assert not any(value.is_meta for value in empty.state_dict().values())
    bm.BestModel(bm.TODAY).load_state_dict(empty.state_dict())


def test_the_passes_without_dropout_run_only_when_the_model_draws_nothing_else():
    """Checks 3 and 7 compare in training mode on a copy whose dropout modules are off. A model whose training-mode
    masks come from numpy or from a generator of its own still draws there, and its masks follow the slots, so a cut
    window or a row taken out of a second set other masks side by side and the model failed although it keeps the
    rule. Such a copy is now seen to draw, with a line, and those passes compare in scoring mode alone; the copy of a
    model whose dropout is all in modules draws nothing."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    for model in (_NumpyDropout(), _DropoutFromItsOwnGenerator()):
        exact = bm._in_32_bits(bm.moved(model))
        assert bm._training_draws(bm._without_dropout(exact), batch, batch["mask"], exact)[1], type(model).__name__
        lines = []
        result = bm.run_checks(model, batch, units_per_second=UNIT, say=lines.append)
        assert all(result["passes"].values()), (type(model).__name__, result)
        assert sum("draws random numbers that no dropout of it holds" in line for line in lines) == 2, lines
    for model in (_PackedDropout(), _built(bm.CANDIDATE)):
        exact = bm._in_32_bits(bm.moved(model))
        assert bm._training_draws(bm._without_dropout(exact), batch, batch["mask"], exact)[1] is None


def test_parts_that_read_the_order_or_the_share_of_the_window_in_training_alone_fail():
    """Every training-mode pass kept every row real and in its slot, since a model that drops its padding before a
    dropout draws other masks for other real rows, so a part that reads, in training mode only, how many rows of its
    second sit in earlier slots or its share of the window passed. Checks 3 and 7 now also run their cuts, shuffles
    and rows taken out in training mode, on a copy whose dropout is off: both parts fail, and a model that drops its
    padding before a dropout still passes."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    quiet = lambda line: None
    order = bm.run_checks(_OrderWhileLearning(), batch, units_per_second=UNIT, say=quiet)
    assert not order["passes"]["order in a second"] and order["order"] > bm.ORDER_TOLERANCE
    share = bm.run_checks(_ShareWhileLearning(), batch, units_per_second=UNIT, say=quiet)
    assert not share["passes"]["prefix"]
    assert all(bm.run_checks(_PackedDropout(), batch, units_per_second=UNIT)["passes"].values())
    model = _built(bm.CANDIDATE)
    off = bm._without_dropout(model)
    drops = [m for m in off.modules() if isinstance(m, nn.Dropout)]
    assert drops and all(m.p == 0.0 for m in drops)
    assert all(m.dropout == 0.0 for m in off.modules() if isinstance(m, nn.MultiheadAttention))
    assert all(v == 0.0 for m in off.modules() for k, v in vars(m).items() if k == "attn_dropout")
    assert any(m.p > 0.0 for m in model.modules() if isinstance(m, nn.Dropout))


def test_check_6_scores_after_a_training_call_and_on_a_third_call():
    """Check 6 compared a second call alone, so a model that fixes something on its second call and reads it from the
    third passed, and so did one that keeps the centre of its latest training batch outside its weights for scoring.
    It now scores a third call against a new instance, and after a training call against a new instance holding the
    weights and buffers that call left: both fail, and a model that keeps the rule still passes."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    for model in (_FixesOnItsSecondCall(), _CentreFromTraining()):
        two, alone = bm.one_model_two_batches(model, batch, units_per_second=UNIT, say=lambda line: None)
        assert two > 0.0, type(model).__name__
    two, alone = bm.one_model_two_batches(_ReadsEarlierSeconds(), batch, units_per_second=UNIT)
    assert two == 0.0 and alone <= bm.ORDER_TOLERANCE


def test_check_6_sees_a_part_that_reads_other_sequences_in_training_alone():
    """Every sequence was scored alone in scoring mode only, so a part that reads the other sequences of its batch in
    training mode alone (a batch norm across them) passed check 6. Half the sequences now change while the other half
    keep their rows, in training mode, and then the other way round: that part fails."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    two, alone = bm.one_model_two_batches(_ReadsOtherSequencesWhileLearning(), batch, units_per_second=UNIT,
                                          say=lambda line: None)
    assert alone > bm.ORDER_TOLERANCE
    assert bm._swapped_in_training(bm.moved(_ReadsEarlierSeconds()), batch, batch["mask"], bm.alter_rows, "mask",
                                   "time_seq", UNIT, None) == 0.0


def test_the_share_of_a_change_is_taken_score_by_score():
    """The share of checks 3, 6 and 7 was taken of the largest score of all, so a large score in one place (an amount
    beside the logits) widened what every other score might move. It is now taken score by score."""
    assert bm._share(torch.tensor([1e6, 0.5]), torch.tensor([1e6, 0.51])) == pytest.approx(0.01)
    assert bm._share(torch.tensor([200.0]), torch.tensor([201.0])) == pytest.approx(0.005)
    assert bm._share(torch.tensor([]), torch.tensor([])) == 0.0
    assert bm._share(torch.tensor([1.0]), torch.tensor([float("nan")])) == float("inf")


def test_later_times_moves_rows_earlier_as_well():
    """The read pass of check 1 moves the rows of earlier seconds an hour earlier, so _later_times takes a move below
    zero: by whole units, and by one unit at least in the direction of the move when the unit is not whole."""
    rows = torch.tensor([[True, False]])
    assert bm._later_times(torch.tensor([[5_000_000_000, 7]]), rows, 1_000_000_000, -2).tolist() == [[3_000_000_000,
                                                                                                    7]]
    assert bm._later_times(torch.tensor([[100, 7]]), rows, 1 / 60, -1).tolist() == [[99, 7]]
    assert bm._later_times(torch.tensor([[100, 7]]), rows, 1 / 60, 1).tolist() == [[101, 7]]
    assert bm._later_times(torch.tensor([[100, 7]]), rows, 1 / 60, -3_600).tolist() == [[40, 7]]
    assert bm._later_times(torch.tensor([[1.5, 7.0]], dtype=torch.float64), rows, 1.0, -1).tolist() == [[0.5, 7.0]]


# ---------------------------------------------------------------------------------------------- the optimiser

def test_param_groups_put_every_weight_in_one_group_with_its_rate_and_decay():
    """Every weight is in one group: the centres at a tenth of the rate without decay; norms, biases, tables and the
    learned vectors without decay; every map decayed. AdamW takes the groups and steps."""
    model = _built(bm.CANDIDATE_LPM)
    groups = bm.param_groups(model, lr=1e-3, weight_decay=0.05)
    by_name = {group["name"]: group for group in groups}
    assert set(by_name) == {"decayed", "not decayed", "centres"}
    ids = [id(weight) for group in groups for weight in group["params"]]
    assert len(ids) == len(set(ids)) and set(ids) == {id(weight) for weight in model.parameters()}
    assert by_name["centres"]["lr"] == pytest.approx(1e-3 * bm.CENTRE_LR_FACTOR)
    assert by_name["centres"]["weight_decay"] == 0.0 and by_name["not decayed"]["weight_decay"] == 0.0
    assert (by_name["decayed"]["lr"], by_name["decayed"]["weight_decay"]) == (1e-3, 0.05)
    assert {id(w) for w in by_name["centres"]["params"]} == {id(w) for w in bm.centre_parameters(model)}
    free = {id(w) for w in by_name["not decayed"]["params"]}
    for weight in (model.stage.position.weight, model.code_tables[0].weight, model.code_bias, model.numbers.identity,
                   model.stage.identity, model.pooler.queries, model.stage.time_bias.gap_weight,
                   model.stage.read_norm.weight, model.head.bias, model.stage.read_query):
        assert id(weight) in free
    decayed = {id(w) for w in by_name["decayed"]["params"]}
    for weight in (model.head.weight, model.numbers.value.projection, model.stage.read_kv.weight):
        assert id(weight) in decayed
    optimiser = torch.optim.AdamW(groups)
    batch = bm.make_batch(seed=23, sequences=2, rows=10)
    model.train()
    bm.row_loss(model, batch).backward()
    optimiser.step()
    # The defaults read the PLACEHOLDER values; a model without learned centres has no group of centres.
    plain = bm.param_groups(_built(bm.TODAY))
    assert [group["name"] for group in plain] == ["decayed", "not decayed"]
    assert plain[0]["lr"] == bm.LEARNING_RATE and plain[0]["weight_decay"] == bm.WEIGHT_DECAY


# ---------------------------------------------------------------------------------------------- the model itself

def test_forward_is_the_head_on_the_exported_vector():
    """For every named configuration the logits are the head on the vector of export, bit for bit."""
    batch = bm.make_batch(seed=9, sequences=2, rows=10)
    for name, config in bm.CONFIGURATIONS.items():
        model = _built(config).eval()
        with torch.no_grad():
            exported = model.export(batch)
            assert exported.shape == (*batch["mask"].shape, model.out_dim), name
            assert torch.equal(model(batch), model.head(exported)), name


def test_a_part_that_starts_at_zero_changes_no_score_when_it_is_switched_on():
    """The calendar, a learned missing vector and the re-reads start as no-ops and are made after every other weight:
    a fresh model with one of them scores as the model without it, bit for bit, and so do frozen centres against
    moving ones. The bias starts at zero too; in the channel stage, which builds it, that is bit for bit, in the
    joined history it takes the route that adds the mask, which rounds otherwise."""
    batch = bm.make_batch(seed=10, sequences=3, rows=20)
    valid = batch["mask"]
    base = _scores(_built(bm.TODAY), batch)
    for switch in (dict(calendar=True), dict(missing="learned"), dict(interleaved_reread="A"),
                   dict(interleaved_reread="M"), dict(interleaved_reread="AM")):
        assert torch.equal(_scores(_built(replace(bm.TODAY, **switch)), batch)[valid], base[valid]), switch
    biased = _scores(_built(replace(bm.TODAY, time_bias=True)), batch)
    assert torch.allclose(biased[valid], base[valid], atol=1e-5)
    plain = _scores(_built(replace(bm.CANDIDATE, time_bias=False)), batch)
    assert torch.equal(_scores(_built(bm.CANDIDATE), batch)[valid], plain[valid])
    moving = _scores(_built(bm.ARMS["NUMBERS_LEARNED_PLE"].config), batch)
    assert torch.equal(_scores(_built(bm.ARMS["NUMBERS_FROZEN_CENTRES"].config), batch)[valid], moving[valid])


def test_the_route_with_a_bias_keeps_the_arithmetic_of_the_standard_layer():
    """run_layer gives what the standard layer gives on its ordinary route: without a bias, with a bias of zero, and
    with a bias that the ordinary route adds to the logits; in scoring as well, against the layer's quick route."""
    torch.manual_seed(0)
    layer = bm._stack(32, 4, 1, 0.0).layers[0]
    B, T, H = 3, 9, 4
    x = torch.randn(B, T, 32)
    g = torch.Generator().manual_seed(1)
    allowed = (torch.rand(B, T, T, generator=g) < 0.5) | torch.eye(T, dtype=torch.bool)
    plain = torch.zeros(B, T, T).masked_fill(~allowed, float("-inf"))
    bias = torch.randn(B, H, T, T, generator=g)
    biased = torch.where(allowed.unsqueeze(1), bias, float("-inf"))
    layer.train()                                                  # dropout 0: the ordinary route, deterministic
    with torch.no_grad():
        own = layer(x, src_mask=plain.repeat_interleave(H, dim=0))
        assert torch.allclose(bm.run_layer(layer, x, plain.unsqueeze(1)), own, atol=1e-6)
        zero = torch.where(allowed.unsqueeze(1), torch.zeros(B, H, T, T), float("-inf"))
        assert torch.allclose(bm.run_layer(layer, x, zero), own, atol=1e-6)
        added = layer(x, src_mask=biased.reshape(B * H, T, T))
        assert torch.allclose(bm.run_layer(layer, x, biased), added, atol=1e-6)
        assert not torch.allclose(added, own, atol=1e-3)           # the bias does change the result
        layer.eval()
        assert torch.allclose(bm.run_layer(layer, x, plain.unsqueeze(1)),
                              layer(x, src_mask=plain.repeat_interleave(H, dim=0)), atol=1e-5)


def test_the_made_up_batch_has_what_the_checks_need():
    """Real rows first, a full window and a padded one, rows that share a second but not a nanosecond (the first two
    rows of the first window always), gaps from a second to days, missing numbers on real rows only, labels on real
    rows only."""
    batch = bm.make_batch(seed=0, sequences=16)
    valid, times = batch["mask"], batch["time_seq"]
    B, T = valid.shape
    assert (B, T) == (16, bm.HISTORY_LEN + 1)
    assert valid[0].all() and not valid[-1].all()
    assert torch.equal(valid, torch.arange(T).unsqueeze(0) < valid.sum(dim=1, keepdim=True))
    seconds = torch.div(times, UNIT, rounding_mode="floor")
    both = valid[:, 1:] & valid[:, :-1]
    step = (seconds[:, 1:] - seconds[:, :-1])[both]
    assert (step == 0).any() and step.max() > 86_400 and (step >= 0).all()
    shared = both & (seconds[:, 1:] == seconds[:, :-1])
    assert (times[:, 1:] != times[:, :-1])[shared].all()
    assert seconds[0, 0] == seconds[0, 1]
    absent = torch.isnan(batch["continuous"])
    assert absent.any() and not absent[~valid].any()
    assert (batch["target_seq"][~valid] == -100).all() and set(batch["target_seq"][valid].tolist()) == {0, 1}


# ---------------------------------------------------------------------------------------------- the table and the words

def test_compare_prints_one_table_with_the_ratio_to_today():
    """compare measures TODAY first when it is not asked for, gives every row its ratio to TODAY, and keeps every
    timed call so that the spread can be read."""
    batch = bm.make_batch(seed=12, sequences=2, rows=12)
    small = replace(bm.TODAY, **SMALL)
    lines = []
    table = bm.compare({"SMALL": small}, batch, repeats=2, say=lines.append)
    assert [row["name"] for row in table] == ["TODAY", "SMALL"]
    assert table[0]["forward_ratio"] == 1.0 and table[0]["step_ratio"] == 1.0
    assert all(row["forward_seconds"] > 0 and row["step_seconds"] > 0 for row in table)
    assert all(len(row["forward_spans"]) == 2 and row["step_seconds"] == min(row["step_spans"]) for row in table)
    assert table[1]["weights"] == bm.count_weights(_built(small))
    assert table[1]["forward_ratio"] == pytest.approx(table[1]["forward_seconds"] / table[0]["forward_seconds"])
    assert len(lines) == 2 + len(table) and "x TODAY" in lines[1] and lines[3].startswith("SMALL")
    measured = bm.cost(_built(small), batch, repeats=1)
    assert set(measured) == {"weights", "forward_seconds", "step_seconds", "forward_spans", "step_spans"}


def test_describe_lists_every_entry_and_says_which_have_no_effect():
    """Every entry has a line; an entry without effect says so with the reason; a model adds its weights by part, the
    time bias of the stage counted as the time bias."""
    model = _built(bm.TODAY)
    text = bm.describe(model)
    lines = {line.split()[0]: line for line in text.splitlines()[1:] if line.startswith("  ") and line[2] != " "}
    assert {entry.name for entry in dataclasses.fields(bm.Config)} <= set(lines)
    assert "no effect: the joined history has no channel stage" in lines["layout"]
    assert "no effect" in lines["bank"] and "no effect" not in lines["history"]
    assert f"{bm.count_weights(model):,}" in lines["weights"]
    assert "history" in text and "head" in text
    text = bm.describe(bm.CANDIDATE)
    lines = {line.split()[0]: line for line in text.splitlines()[1:]}
    assert "no effect" in lines["interleaved_reread"] and "no effect" not in lines["layout"]
    assert "paper (1,000 a second)" in lines["gap_ticks_per_second"] and "no effect" in lines["gap_ticks_per_second"]
    assert "weights" not in lines
    for name, config in bm.CONFIGURATIONS.items():
        model = _built(config)
        assert sum(bm.weights_by_part(model).values()) == bm.count_weights(model), name
        assert "other" not in bm.weights_by_part(model), name
    parts = bm.weights_by_part(_built(bm.CANDIDATE))
    assert parts["time bias"] == bm.count_weights(_built(bm.CANDIDATE).stage.time_bias) == 4 * 10 + 4


def test_plain_errors_say_what_to_change():
    """A size or a name that cannot work gives an error that says what to change; an entry without effect does not."""
    with pytest.raises(ValueError, match="multiple of stage1_heads"):
        bm.BestModel(replace(bm.TODAY, stage1_heads=5))
    with pytest.raises(ValueError, match="multiple of history_heads"):
        bm.BestModel(replace(bm.TODAY, history_heads=7))
    with pytest.raises(ValueError, match="pooler"):
        bm.BestModel(replace(bm.CANDIDATE, stage1="pooler", bank="stage1"))
    with pytest.raises(ValueError, match="history must be one of"):
        bm.BestModel(replace(bm.TODAY, history="joint"))
    with pytest.raises(ValueError, match="cannot be negative"):
        bm.BestModel(replace(bm.CANDIDATE, num_back=-1))
    with pytest.raises(ValueError, match="1 or more"):
        bm.BestModel(replace(bm.TODAY, history_layers=0))
    for entry, value in (("missing", "learnt"), ("memory_ties", "seconds"), ("intra_order", "cross")):
        with pytest.raises(ValueError, match=f"{entry} must be one of"):
            bm.BestModel(replace(bm.CANDIDATE, **{entry: value}))
    with pytest.raises(ValueError, match="gap_ticks_per_second"):
        bm.BestModel(replace(bm.ARMS["GAP_SINUSOID"].config, gap_ticks_per_second=0))
    # Nothing reads the bank of TODAY, so a bank of stage 1 beside the pooler is no error there.
    assert bm.BestModel(replace(bm.TODAY, stage1="pooler", bank="stage1")).pooler is not None


def test_the_pod_text_names_the_unit_in_every_snippet_and_the_kit():
    """Every call in the docstring that reads times names its unit; the text lists the twelve files of the kit and
    says that torch and numpy suffice, marks every other file as package only, defines W1 to W8 in place, and says the
    rules the hostile checks found missing: final_intra in the words of latent_channels.py, the .view rule, the
    dropped prefix, "ple" at another bin count, and missing="zero"."""
    doc = bm.__doc__
    for call in ("gap_seconds(", "CalendarEncoder(", "AttentionBias(", "LatentChannelStage(", "run_checks("):
        start = doc.find(call)
        assert start >= 0, call
        while start >= 0:
            depth, end = 0, start + len(call) - 1
            for end in range(start + len(call) - 1, len(doc)):
                depth += {"(": 1, ")": -1}.get(doc[end], 0)
                if depth == 0:
                    break
            assert "units_per_second" in doc[start:end], doc[start:end + 1]
            start = doc.find(call, end)
    pod = doc.split("What to change for the pod")[1].split("How to try it")[0]
    for name in KIT:
        assert name in pod, name
    assert "torch and numpy" in pod
    for code in ("W1 ", "W2 ", "W3 ", "W4 ", "W5 ", "W6 ", "W7 ", "W8 "):
        assert f"\n    {code}" in pod, code
    stage_doc = (Path(bm.__file__).parent / "latent_channels.py").read_text()
    sentence = "final_intra takes the place of the model's re-read after stage 2; keep only one of the two."
    assert sentence in stage_doc and sentence in " ".join(pod.split())
    for words in ("channel-major order", "dropped", "fit_edges", "UnitQuantileScaler", 'missing="zero"',
                  "unit = 1_000_000_000"):
        assert words in pod, words
    source = Path(bm.__file__).read_text()
    assert "twelve files" in pod and "CONFIGURATIONS.md" in pod and "INTERLEAVED_REREAD.md" in pod
    assert "W1 to W15 mean what they mean in interleaved_wiring_template.py" in " ".join(pod.split())
    for name in ("RECIPE.md", "_shared.py", "history_stage.py", "test_kit_runs_flat.py",
                 "test_model_best_model_template.py", "settings.py"):
        place = source.find(name)
        while place >= 0:
            assert "package only" in source[place:place + len(name) + 40], (name, source[place:place + 80])
            place = source.find(name, place + 1)


def test_the_files_hold_only_plain_ascii_words():
    """Every file of this change is ASCII and holds none of the words the house rules keep out."""
    banned = ("review" + "er", "cla" + "ude", "chat" + "gpt", "co" + "pilot", "gem" + "ini", "open" + "ai",
              "anth" + "ropic", "k19" + "4855", "assis" + "tant", "ha" + "sh", "sha" + "256", "sh" + "a1", "m" + "d5",
              "finger" + "print", "check" + "sum")
    additions = Path(bm.__file__).parents[1]
    paths = (Path(bm.__file__), Path(__file__), Path(__file__).parent / "test_kit_runs_flat.py",
             Path(__file__).parent / "test_sweep_plan.py", additions / "CONFIGURATIONS.md", additions / "SWEEP.md",
             additions / "sweep" / "arms.py")
    for path in paths:
        text = path.read_text()
        assert text.isascii(), path
        lowered = text.lower()
        assert not [word for word in banned if word in lowered], path


# ---------------------------------------------------------------------------------------------- the module as a script

def test_the_module_runs_as_a_script_inside_the_package():
    """Run as a script inside the package with no path set, the module answers yes to every check of every named
    configuration and prints the table, and runs the checks of any arms by name (test_kit_runs_flat.py runs it from a
    flat folder of the twelve files of the kit)."""
    here = Path(bm.__file__).parent
    root = here.parents[1]
    env = {name: value for name, value in os.environ.items() if name != "PYTHONPATH"}
    env.update(OMP_NUM_THREADS="1", MKL_NUM_THREADS="1")
    script = str(here / "best_model_template.py")
    small = ["--sequences", "2", "--rows", "10", "--repeats", "1"]
    for extra, lines in (([], 4), (["--arms", "MEMORY_SLOT", "GAP_SINUSOID_SECONDS"], 2)):
        result = subprocess.run([sys.executable, script, *small, *extra], cwd=root, env=env, capture_output=True,
                                text=True, timeout=900)
        assert result.returncode == 0, result.stderr
        checked = [line for line in result.stdout.splitlines() if "weights |" in line]
        assert len(checked) == lines and "x TODAY" in result.stdout, result.stdout
        for line in checked:
            if line.startswith("MEMORY_SLOT"):
                assert line.count(": yes") == 6 and "order in a second: NO" in line, line
            else:
                assert line.count(": yes") == 7, line


# ---------------------------------------------------------------------------------------------- round 4 of the checks

class _BurstRank(_Plus):
    """Reads how many slots of its own second hold an earlier full time, found by the times alone without the mask
    (padding holds time 0, in no real second): it reads the rows of its own second."""

    def term(self, batch):
        times, seconds = batch["time_seq"], _seconds(batch)
        same = seconds.unsqueeze(1) == seconds.unsqueeze(2)
        earlier = times.unsqueeze(1) < times.unsqueeze(2)
        return (same & earlier).sum(dim=-1).float()


def test_rows_taken_out_of_a_second_leave_no_time_behind(monkeypatch):
    """The checks made padding by writing the mask alone, so a row taken out of its second left its time in the slot
    it left, and a row that finds the rows of its own second by their times, without the mask, still found it: on a
    batch sorted by full time inside its seconds, as a builder that sorts by the timestamp writes it, such a row passed
    all seven checks. Padding is now written as a builder writes it, a time in no real second among it: the row fails
    check 7, a model that keeps the rule passes, and the row passes again with the mask alone written."""
    batch = _sorted_inside_seconds(bm.make_batch(seed=1, sequences=8, rows=40))
    rows = torch.zeros_like(batch["mask"])
    rows[0, :3] = True
    made = bm._padder("mask", None, "time_seq", UNIT)(batch, rows)
    assert not made["mask"][rows].any() and bool((made["time_seq"][rows] == 0).all())
    assert bool((made["continuous"][rows] == 0).all()) and bool((made["categorical"][rows] == 0).all())
    assert bool((made["target_seq"][rows] == -100).all())
    quiet = lambda line: None
    result = bm.run_checks(_BurstRank(), batch, units_per_second=UNIT, say=quiet)
    assert not result["passes"]["order in a second"] and result["order"] > bm.ORDER_TOLERANCE, result
    assert all(bm.run_checks(_ReadsEarlierSeconds(), batch, units_per_second=UNIT, say=quiet)["passes"].values())

    def mask_alone(real, pad, time=None, units=None):
        def write(batch, rows):
            out = dict(batch)
            out[real] = batch[real].clone()
            out[real][rows] = False
            return out

        return write

    monkeypatch.setattr(bm, "_padder", mask_alone)
    order, same_second = bm.order_inside_a_second(_BurstRank(), batch, units_per_second=UNIT, say=quiet)
    assert order <= bm.ORDER_TOLERANCE and same_second == 0.0


def test_the_time_of_padding_lies_in_no_real_second():
    """The time written on a slot made padding is the one the padded slots of the batch hold, else 0, unless a real
    row lies in its second; then two seconds before the earliest real row."""
    times = torch.tensor([[5 * UNIT, 7 * UNIT, 0], [6 * UNIT, 0, 0]])
    valid = times > 0
    assert int(bm._padding_time(times, valid, UNIT)) == 0
    early = torch.tensor([[0, UNIT // 2, 3 * UNIT]])
    assert int(bm._padding_time(early, torch.ones_like(early, dtype=torch.bool), UNIT)) == -2 * UNIT
    sentinel = torch.tensor([[5 * UNIT, -1, -1]])
    assert int(bm._padding_time(sentinel, sentinel > 0, UNIT)) == -1


class _OtherIn64Bits(_RowByItself):
    """Reads the mean of the real rows of strictly earlier seconds in the number type of its numbers, so that it runs
    in 64 bits as in 32, and keeps the rule in 32 bits; in 64 bits it reads its numbers otherwise, as a model whose
    float32 mask a float64 attention misreads: there every score moves by the width of its window (`short`: only in a
    window narrower than `width`, so that the whole batch agrees in 64 and 32 bits)."""

    def __init__(self, short=False, width=40):
        super().__init__()
        self.short, self.width = short, width

    def forward(self, batch):
        x, valid = self.row(batch), batch["mask"].bool()
        seconds = torch.div(batch["time_seq"], UNIT, rounding_mode="floor")
        earlier = (seconds.unsqueeze(1) < seconds.unsqueeze(2)) & valid.unsqueeze(1) & valid.unsqueeze(2)
        mean = (earlier.to(x.dtype) @ x.unsqueeze(-1)).squeeze(-1) / earlier.sum(dim=-1).clamp(min=1)
        out = torch.stack([x + 0.5 * mean, x - 0.5 * mean], dim=-1) * self.weight
        width = valid.shape[1]
        if out.dtype == torch.float64 and (not self.short or width < self.width):
            out = out + width
        return out


class _CastsItsInputs(_ReadsEarlierSeconds):
    """Keeps the rule, and casts its numbers to float32 before a linear layer, as many models do: in 64 bits the
    layer would stop on them, were the cast not widened there."""

    def __init__(self):
        super().__init__()
        self.proj = nn.Linear(bm.N_NUMERIC, 2)

    def forward(self, batch):
        x = torch.nan_to_num(batch["continuous"].float(), nan=0.0)
        return super().forward(batch) + self.proj(x) * batch["mask"].unsqueeze(-1)


class _WithItsOwn32BitTensor(nn.Module):
    """A model that keeps the rule, with a plain float32 tensor of its own (no weight, no buffer) applied to its
    scores: no .double() of the model reaches it."""

    def __init__(self, inner):
        super().__init__()
        self.inner = inner
        self.mix = torch.eye(2)

    def forward(self, batch):
        return self.inner(batch).to(self.mix.dtype) @ self.mix


class _NoEntryFor64Bits(_ReadsEarlierSeconds):
    """Keeps the rule, and looks a small number up in a table by the number type of its numbers, which holds no
    entry for 64 bits: there it stops with a KeyError."""

    def forward(self, batch):
        out = super().forward(batch)
        return out + {torch.float32: 1e-6, torch.float16: 1e-3, torch.bfloat16: 1e-2}[out.dtype]


def test_the_comparisons_that_allow_rounding_run_in_64_bits_when_the_model_runs_there():
    """Checks 3 and 7 compared a 32-bit copy against 1e-5, which rounding alone passes in a joined history several
    hundred numbers wide: WIDE_JOINED failed on some of the kit's own batches, and so did the run of section 8 with six
    summary outputs joined. They now compare a 64-bit copy, where rounding is about 1e-14 of a score, whenever the
    model runs there and scores the whole batch there as in 32 bits; a model that stops in 64 bits, or scores the
    whole batch otherwise there, is compared in 32 bits with a line, and when a window moves in 64 bits alone the
    32-bit comparison stands, with a line.

    A model that held a float32 tensor of its own, or cast its numbers to float32 inside, stopped in 64 bits and was
    sent to 32, where a wide one failed on rounding (WIDE_JOINED with a plain float32 matrix on its scores: 1.19e-5
    on seed 8). Inside the 64-bit copy every narrower float is now widened where a torch function takes it or hands
    it back, so such a model is compared in 64 bits. A model that stops there with any error (a table with no entry
    for 64 bits) is compared in 32 bits with the line and no longer stops the checks."""
    quiet = lambda line: None
    model = _built(bm.WIDE_JOINED)
    for seed in (8, 12, 17):
        batch = bm.make_batch(seed=seed, sequences=8, rows=40)
        assert bm.prefix_agrees(model, batch, units_per_second=UNIT, say=quiet) < 1e-12
        assert bm.order_inside_a_second(model, batch, units_per_second=UNIT, say=quiet)[0] < 1e-12
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    joined = _built(replace(bm.WIDE_JOINED, n_bins=32, gap_encoder="ple", time_bias=True, num_summary=6))
    assert bm.prefix_agrees(joined, batch, units_per_second=UNIT, say=quiet) < 1e-12
    copies = bm._exact_copies(bm.moved(joined), batch, batch["mask"], quiet, "test", training=False)
    assert copies.wide and bm._float_type(copies.exact) == torch.float64
    for model, said in ((_NoEntryFor64Bits(), "in 64-bit numbers the model stops"),
                        (_OtherIn64Bits(), "in 64-bit numbers the model scores the whole batch otherwise"),
                        (_OtherIn64Bits(short=True), "in 64-bit numbers and by")):
        lines = []
        assert bm.prefix_agrees(model, batch, units_per_second=UNIT, say=lines.append) < bm.PREFIX_TOLERANCE
        assert any(said in line for line in lines), (type(model).__name__, lines)
    assert all(bm.run_checks(_NoEntryFor64Bits(), batch, units_per_second=UNIT, say=quiet)["passes"].values())
    # a cast to float32 inside, or a float32 tensor of the model's own: 64 bits all the same, and no line
    wide = _WithItsOwn32BitTensor(_built(bm.WIDE_JOINED))
    eight = bm.make_batch(seed=8, sequences=8, rows=40)
    for model, rows in ((_CastsItsInputs(), batch), (wide, eight)):
        lines = []
        assert bm.prefix_agrees(model, rows, units_per_second=UNIT, say=lines.append) < 1e-12, lines
        assert bm.order_inside_a_second(model, rows, units_per_second=UNIT, say=lines.append)[0] < 1e-12, lines
        assert not any("64-bit" in line for line in lines), lines
        copies = bm._exact_copies(bm.moved(model), rows, rows["mask"], quiet, "test")
        assert copies.wide and bm._float_type(copies.exact) == torch.float64
    lines = []
    two, alone = bm.one_model_two_batches(_OtherIn64Bits(short=False), batch, units_per_second=UNIT,
                                          say=lines.append)
    assert two == 0.0 and alone <= bm.ORDER_TOLERANCE, (two, alone, lines)


class _ShareWithFunctionalDropout(_ShareWhileLearning):
    """_ShareWhileLearning with a dropout drawn through F.dropout at a rate it holds under a name of its own: its
    share of the window in training mode alone is a leak."""

    def __init__(self):
        super().__init__()
        self.rate = 0.3

    def forward(self, batch):
        return F.dropout(super().forward(batch), self.rate, self.training)


class _FunctionalDropout(_ReadsEarlierSeconds):
    """Keeps the rule, with a dropout drawn through F.dropout at a rate it holds under a name of its own."""

    def __init__(self):
        super().__init__()
        self.rate = 0.3

    def forward(self, batch):
        return F.dropout(super().forward(batch), self.rate, self.training)


class _KeepProbability(_ReadsEarlierSeconds):
    """Keeps the rule, with a dropout written by hand that holds the probability of keeping a score, under a name
    that holds "dropout"."""

    def __init__(self):
        super().__init__()
        self.dropout_keep_prob = 0.7

    def forward(self, batch):
        out = super().forward(batch)
        if self.training:
            out = out * (torch.rand(out.shape) < self.dropout_keep_prob).to(out) / self.dropout_keep_prob
        return out


class _DropoutTemperature(_ReadsEarlierSeconds):
    """Keeps the rule, with noise in training mode scaled by a float whose name holds "dropout" and that is no
    probability of a drop: at zero it divides by zero."""

    def __init__(self):
        super().__init__()
        self.dropout_temperature = 0.5

    def forward(self, batch):
        out = super().forward(batch)
        if self.training:
            out = out + torch.randn(out.shape).to(out) * 0.01 / self.dropout_temperature
        return out


def test_a_dropout_drawn_through_torch_functions_is_off_in_the_copy_and_a_keep_probability_stays():
    """The copy without dropout set p of the dropout modules and every float named for dropout to zero, so a dropout
    drawn through F.dropout at a rate of the model's own still drew there, and the training-mode comparisons of checks
    3 and 7 were left out: a part that read its share of the window in training mode alone then passed. The dropout
    functions of torch now run as the identity in that copy: that part fails, a model with such a dropout passes with
    no line, a keep probability is left as it is (the copy draws, and a line says so), and a float named for dropout
    whose zero breaks the forward gives a line, not a failure."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    quiet = lambda line: None
    result = bm.run_checks(_ShareWithFunctionalDropout(), batch, units_per_second=UNIT, say=quiet)
    assert not result["passes"]["prefix"], result
    lines = []
    result = bm.run_checks(_FunctionalDropout(), batch, units_per_second=UNIT, say=lines.append)
    assert all(result["passes"].values()) and not any("in training mode the copy" in line for line in lines), lines
    for model, said in ((_KeepProbability(), "draws random numbers"), (_DropoutTemperature(), "not finite numbers")):
        lines = []
        result = bm.run_checks(model, batch, units_per_second=UNIT, say=lines.append)
        assert all(result["passes"].values()), (type(model).__name__, result)
        assert sum(said in line for line in lines) == 2, (type(model).__name__, lines)
    quiet_copy = bm._without_dropout(_KeepProbability())
    assert quiet_copy.dropout_keep_prob == 0.7 and bm._without_dropout(_DropoutTemperature()).dropout_temperature == 0.0
    with bm._dropout_functions_off():
        x = torch.ones(4, 6)
        assert torch.equal(F.dropout(x, 0.5, True), x) and torch.equal(nn.Dropout(0.5).train()(x), x)
    assert not torch.equal(F.dropout(torch.ones(64, 64), 0.5, True), torch.ones(64, 64))


class _RefusesAnEmptyWindow(_ReadsEarlierSeconds):
    """Keeps the rule, and stops on a window without a real row, as an input check of a model may."""

    def forward(self, batch):
        if not bool(batch["mask"].bool().any(dim=1).all()):
            raise ValueError("a window without a real row")
        return super().forward(batch)


def test_a_cut_window_is_never_empty():
    """On a batch padded on the left, the cuts near the first slots leave most windows without a real row before the
    cut, and a model that stops on a window without a real row made check 3 give not a number. Such a window now keeps
    its earliest real row, which is not compared."""
    batch = _left_padded(bm.make_batch(seed=1, sequences=8, rows=40))
    lines = []
    assert bm.prefix_agrees(_RefusesAnEmptyWindow(), batch, units_per_second=UNIT,
                            say=lines.append) < bm.PREFIX_TOLERANCE, lines
    assert all(bm.run_checks(_RefusesAnEmptyWindow(), batch, units_per_second=UNIT,
                             say=lambda line: None)["passes"].values())


class _Compiled(nn.Module):
    """Stands for a model compiled with torch.compile: it holds the module it wraps as `_orig_mod`, and its own code
    rounds otherwise than the plain module does."""

    def __init__(self, inner):
        super().__init__()
        self._orig_mod = inner

    def forward(self, batch):
        return self._orig_mod(batch) * (1 + 1e-6)


def test_check_6_reads_a_compiled_model_through_the_module_it_wraps():
    """With `build` giving the plain model of a compiled one, as the docstring allows, check 6 set the compiled code
    against the plain one, whose rounding differs, while two must be exactly 0.0. It now reads both through the module
    the compiled model wraps."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    two, alone = bm.one_model_two_batches(_Compiled(_ReadsEarlierSeconds()), batch, units_per_second=UNIT,
                                          build=_ReadsEarlierSeconds, say=lambda line: None)
    assert two == 0.0 and alone <= bm.ORDER_TOLERANCE
    instance = bm._new_instance(bm.moved(_Compiled(_ReadsEarlierSeconds())), lambda: _Compiled(_ReadsEarlierSeconds()))
    assert type(instance) is _ReadsEarlierSeconds


class _KeepsDeep(_ReadsEarlierSeconds):
    """Keeps the rule, and keeps outputs of its latest call deep inside plain containers, a plain object and a module
    held in a plain list: after a call with gradients on, tensors that are no leaves of the graph."""

    def __init__(self):
        super().__init__()
        self.records = {"calls": [], "pairs": []}
        self.note = types.SimpleNamespace(last=None)
        self.helpers = [nn.Linear(2, 2)]

    def forward(self, batch):
        out = super().forward(batch)
        self.records = {"calls": [out[:, :1]], "pairs": [(out[:, :1], out[:, 1:2])]}
        self.note.last = out.sum()
        self.helpers[0].kept = out.mean()
        return out


def test_a_copy_reaches_tensors_kept_at_any_depth():
    """A deep copy stops on a tensor that is no leaf of the graph, and the copies of the checks replaced such a tensor
    only in an attribute or one level inside a list, a tuple or a dict: a model that kept one deeper crashed the
    checks after a training step. Every such tensor is now replaced wherever the model keeps it."""
    batch = bm.make_batch(seed=0, sequences=4, rows=16)
    model = _KeepsDeep()
    bm.row_loss(model.train(), batch).backward()
    copied = bm._copy(model)
    assert copied.records["pairs"][0][0].is_leaf and copied.note.last.is_leaf and copied.helpers[0].kept.is_leaf
    assert all(bm.run_checks(model, batch, units_per_second=UNIT, say=lambda line: None)["passes"].values())


def test_entries_not_laid_out_per_row_are_named_whatever_their_type():
    """run_checks named a tensor or a list with one item per window, and passed over a number, a string, a dict or a
    numpy scalar, though a model reads them as well (the latest time of the batch, say). Every entry not laid out per
    row is now named, unless `rebuild` writes it again for the cut window. With a function `real`, the mask entry
    was named as an input `alter` leaves as it is; it no longer is."""
    batch = bm.make_batch(seed=0, sequences=4, rows=16)
    held = dict(batch, as_of=int(batch["time_seq"].max()), file="part-0001", sizes={"rows": 16}, scale=np.float64(2.0))
    lines = bm._unchecked(held, bm.alter_rows, "mask", "time_seq", ("target_seq",), None)
    named = [line for line in lines if "not laid out per row" in line]
    assert named and all(name in named[0] for name in ("as_of", "file", "sizes", "scale")), lines

    def rebuild(entries):
        return dict(entries, as_of=int(entries["time_seq"].max()))

    lines = bm._unchecked(held, bm.alter_rows, "mask", "time_seq", ("target_seq",), rebuild)
    left = [line for line in lines if line.startswith("run_checks: `rebuild` leaves")]
    assert left and "as_of" not in left[0] and "file" in left[0], lines
    lines = bm._unchecked(batch, bm.alter_rows, lambda entries: entries["mask"], "time_seq", ("target_seq",), None)
    assert not any("leaves mask" in line for line in lines), lines


_ORIGIN = {}


class _OriginOutside(_Plus):
    """Fixes an origin of time on its first call and keeps it in a variable of its module, outside every instance, so
    that every copy and every new instance share it."""

    def term(self, batch):
        seconds = _seconds(batch).double()
        if "origin" not in _ORIGIN:
            _ORIGIN["origin"] = float(seconds[batch["mask"].bool()].min())
        return ((seconds - _ORIGIN["origin"]) / 86_400.0).float() * batch["mask"]


def test_a_state_kept_outside_the_instances_is_named():
    """An origin fixed on the first call and kept in a module variable, or on a class, is shared by every copy and
    every new instance, so no check can set one call against another through it, and nothing said so. run_checks now
    names what the code of the model reads outside its instances that changes while the checks run."""
    _ORIGIN.clear()
    lines = []
    bm.run_checks(_OriginOutside(), bm.make_batch(seed=0, sequences=4, rows=16), units_per_second=UNIT,
                  say=lines.append)
    assert any("_ORIGIN" in line and "changed while the checks ran" in line for line in lines), lines
    _ORIGIN.clear()
    lines = []
    bm.run_checks(_ReadsEarlierSeconds(), bm.make_batch(seed=0, sequences=4, rows=16), units_per_second=UNIT,
                  say=lines.append)
    assert not any("changed while the checks ran" in line for line in lines), lines


class _RemembersUnderInference(_Plus):
    """Keeps the mean of the latest batch it scored under torch.inference_mode() and reads it in the next such call;
    under torch.no_grad() it keeps nothing."""

    def __init__(self):
        super().__init__()
        self.last = 0.0

    def term(self, batch):
        before = self.last
        if torch.is_inference_mode_enabled():
            self.last = float(torch.nan_to_num(batch["continuous"]).mean())
        return torch.full(batch["mask"].shape, before)


def test_check_6_scores_under_inference_mode_as_well():
    """Every scoring call of the checks ran under torch.no_grad(), so a memory kept and read only under
    torch.inference_mode(), the other way a scorer may score, passed. Check 6 now scores once more there."""
    two, alone = bm.one_model_two_batches(_RemembersUnderInference(), bm.make_batch(seed=0, sequences=4, rows=16),
                                          units_per_second=UNIT, say=lambda line: None)
    assert two > 0.0


class _ReadsTheWindowIn16Bits(_ReadsEarlierSeconds):
    """Keeps the rule in 32 and 64 bits; with its weights in 16 bits it divides every score by the real rows of its
    window, as a model that keeps a sum in range in half precision may: there it reads the later rows."""

    def forward(self, batch):
        out = super().forward(batch)
        if self.weight.dtype in (torch.float16, torch.bfloat16):
            out = out / batch["mask"].sum(dim=1, keepdim=True).clamp(min=1).unsqueeze(-1).to(out)
        return out


def test_a_path_taken_in_16_bits_alone_is_scored_in_place():
    """Checks 3 and 7 compare a copy in 32 or 64 bits, so a path the model takes in 16 bits alone was never cut. Check
    3 now also scores the model as handed over, in its own number type, on the window whose slots from every cut on
    are made padding in place: a read of the window there fails, and a model that keeps the rule in 16 bits passes."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    quiet = lambda line: None
    assert bm.prefix_agrees(_ReadsTheWindowIn16Bits().to(torch.bfloat16), batch, units_per_second=UNIT,
                            say=quiet) > bm.PREFIX_TOLERANCE
    assert bm.prefix_agrees(_ReadsEarlierSeconds().to(torch.bfloat16), batch, units_per_second=UNIT,
                            say=quiet) < bm.PREFIX_TOLERANCE


class _LossFirst(_ReadsEarlierSeconds):
    """Keeps the rule, and hands back (loss, scores) in training mode, as some models do when they hold labels."""

    def forward(self, batch):
        out = super().forward(batch)
        return (out.sum(), out) if self.training else out


def test_inputs_of_other_forms_and_plain_errors():
    """A loss handed back before the scores crashed check 1 with an IndexError; pads spelled otherwise was read as the
    right side; a batch built under torch.inference_mode() crashed the first training call; a cut handed over as a
    tensor of one value crashed check 3; a list with one item per window was rolled and cut with no line; a learned
    vector for missing numbers failed check 4 on a batch without one, with no line. Each now gives a plain error,
    works or says so."""
    batch = bm.make_batch(seed=0, sequences=4, rows=16)
    quiet = lambda line: None
    with pytest.raises(TypeError, match=r"shape \(\)"):
        bm.run_checks(_LossFirst(), batch, units_per_second=UNIT, say=quiet)
    with pytest.raises(ValueError, match="pads"):
        bm.run_checks(_ReadsEarlierSeconds(), batch, units_per_second=UNIT, pads="Left", say=quiet)
    with torch.inference_mode():
        held = bm.make_batch(seed=0, sequences=4, rows=16)
    assert all(bm.run_checks(_ReadsEarlierSeconds(), held, units_per_second=UNIT, say=quiet)["passes"].values())
    assert bm.prefix_agrees(_ReadsEarlierSeconds(), batch, cut=torch.tensor(8), units_per_second=UNIT,
                            say=quiet) < bm.PREFIX_TOLERANCE
    assert bm._cut_list(torch.tensor([3, 5])) == [3, 5] and bm._cut_list(np.int64(4)) == [4]
    assert bm._cut_list(range(1, 3)) == [1, 2] and bm._cut_list(6) == [6]
    lines = []
    bm.one_model_two_batches(_ReadsEarlierSeconds(), dict(batch, names=["a", "b", "c", "d"]), units_per_second=UNIT,
                             say=lines.append)
    assert any(line.startswith("one_model_two_batches: names holds one item per window") for line in lines), lines
    filled = dict(batch, continuous=torch.nan_to_num(batch["continuous"], nan=0.5))
    lines = []
    result = bm.run_checks(_built(bm.ARMS["MISSING_LEARNED"].config), filled, units_per_second=UNIT, say=lines.append)
    assert result["unlearned"] == ["numbers.missing"], result["unlearned"]
    assert any("a learned vector for missing numbers" in line for line in lines), lines


def test_run_checks_takes_the_cuts_of_check_3():
    """run_checks took no cut, so the sweep over every slot that finds a leak confined to a few slots ran only
    through prefix_agrees. It now takes `cut` and hands it to check 3."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    quiet = lambda line: None
    assert bm.run_checks(_BlockInTheMiddle(), batch, units_per_second=UNIT, cut=range(1, 40),
                         say=quiet)["prefix"] > bm.PREFIX_TOLERANCE



class _CastsTo16Bits(_ReadsEarlierSeconds):
    """Keeps the rule in 16 bits, and casts its numbers to its own fixed type before a linear layer, as a model kept
    in 16 bits has to cast a float32 batch somewhere."""

    def __init__(self, kind):
        super().__init__()
        self.kind = kind
        self.proj = nn.Linear(bm.N_NUMERIC, 2)

    def forward(self, batch):
        x = torch.nan_to_num(batch["continuous"], nan=0.0).to(self.kind)
        return super().forward(batch) + self.proj(x) * batch["mask"].unsqueeze(-1)


class _NeedsItsDropoutAboveZero(_ReadsEarlierSeconds):
    """Keeps the rule; in training mode it takes the logarithm of its dropout rate, as concrete dropout does, and so
    stops once that rate is set to zero."""

    def __init__(self):
        super().__init__()
        self.dropout = 0.1

    def forward(self, batch):
        out = super().forward(batch)
        return out * (1.0 + 0.0 * math.log(self.dropout)) if self.training else out


def test_models_in_16_bits_with_a_cast_of_their_own_and_a_dropout_that_may_not_be_zero_are_checked():
    """A model in 16 bits that casts its numbers to its own fixed type, or holds a plain 16-bit tensor, stopped check
    3: its 32-bit copy mixed float32 weights with 16-bit tensors. A model whose forward stops once its dropout rate
    is zero stopped the checks as well. The first is now widened inside the copy like any narrower float; the second
    has its training-mode comparisons left out with a line."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    for kind in (torch.bfloat16, torch.float16):
        model = _CastsTo16Bits(kind).to(kind)
        assert all(bm.run_checks(model, batch, units_per_second=UNIT, say=lambda line: None)["passes"].values())
        held = _WithItsOwn32BitTensor(_ReadsEarlierSeconds()).to(kind)
        held.mix = held.mix.to(kind)
        assert bm.prefix_agrees(held, batch, units_per_second=UNIT, say=lambda line: None) < bm.PREFIX_TOLERANCE
    lines = []
    result = bm.run_checks(_NeedsItsDropoutAboveZero(), batch, units_per_second=UNIT, say=lines.append)
    assert all(result["passes"].values()), result
    assert any("stops once its dropout is set to zero" in line for line in lines), lines


class _KeepsTheLengthInItsBatch(_ReadsEarlierSeconds):
    """Works out the number of real rows of each window once and keeps it in the batch it is handed (in the dict
    itself, or in a dict the batch holds): every score is divided by it, so every row reads how many rows follow."""

    def __init__(self, nested=False):
        super().__init__()
        self.nested = nested

    def forward(self, batch):
        store = batch["extras"] if self.nested else batch
        if "lengths" not in store:
            store["lengths"] = batch["mask"].sum(dim=1, keepdim=True).float()
        out = super().forward(batch)
        return out / store["lengths"].clamp(min=1).unsqueeze(-1).to(out)


class _FillsItsBatchInPlace(_ReadsEarlierSeconds):
    """Keeps the rule, and writes the missing numbers of the batch it is handed to zero in place."""

    def forward(self, batch):
        batch["continuous"].nan_to_num_(nan=0.0)
        return super().forward(batch)


def test_an_entry_a_model_keeps_in_its_batch_is_worked_out_afresh_in_every_call():
    """A model that kept the length of its window in the batch it was handed passed all seven checks: the first call
    wrote the entry into the checks' own dict, and every changed, cut and relaid window made from it carried the
    whole window's value. Every call now gets a batch of its own (a new dict, tensors cloned, the rest deep-copied),
    so the read fails checks 3 and 7 as it does when worked out afresh, and a line names what the model writes."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    for nested in (False, True):
        given = dict(batch, extras={}) if nested else batch
        lines = []
        result = bm.run_checks(_KeepsTheLengthInItsBatch(nested), given, units_per_second=UNIT, say=lines.append)
        assert not result["passes"]["prefix"] and not result["passes"]["order in a second"], result
        assert "lengths" not in given and (not nested or given["extras"] == {})
        if not nested:
            assert any("adds lengths" in line and "the batch it is handed" in line for line in lines), lines
    lines = []
    before = batch["continuous"].clone()
    result = bm.run_checks(_FillsItsBatchInPlace(), batch, units_per_second=UNIT, say=lines.append)
    assert all(result["passes"].values()), result
    assert any("writes in place into continuous" in line for line in lines), lines
    assert bm._same_values(before, batch["continuous"])           # the caller's own tensor is as it was
    lines = []
    bm.run_checks(_ReadsEarlierSeconds(), batch, units_per_second=UNIT, say=lines.append)
    assert not any("the batch it is handed" in line for line in lines), lines
    # an entry that cannot be copied (a lock) is handed over as it is
    locked = dict(batch, lock=threading.Lock())
    assert all(bm.run_checks(_ReadsEarlierSeconds(), locked, units_per_second=UNIT,
                             say=lambda line: None)["passes"].values())


def _with_outcomes(batch, seed=0):
    """The batch with two outcome entries told by their presence: the amount of a chargeback (not a number where
    there was none) and the days to it (-1 where there was none, -100 on padding)."""
    generator = torch.Generator().manual_seed(seed)
    valid, hit = batch["mask"].bool(), batch["target_seq"] == 1
    amount = torch.where(hit, 10.0 + 490.0 * torch.rand(hit.shape, generator=generator, dtype=torch.float64),
                         torch.full(hit.shape, float("nan"), dtype=torch.float64))
    days = torch.where(hit, torch.randint(0, 91, hit.shape, generator=generator), torch.full(hit.shape, -1))
    return dict(batch, cb_amount=amount, cb_days=torch.where(valid, days, torch.full(hit.shape, -100)))


class _ReadsWhetherItsOutcomeIsThere(_Plus):
    """Reads only whether its own outcome is there: a chargeback amount that is a number, or days to it from 0 up."""

    def __init__(self, entry):
        super().__init__()
        self.entry = entry

    def term(self, batch):
        value = batch[self.entry]
        there = ~torch.isnan(value) if value.is_floating_point() else value >= 0
        return there.float() * batch["mask"]


class _HandsBackItsLoss(_ReadsEarlierSeconds):
    """Keeps the rule, and hands back (scores, its cross-entropy on target_seq), with -100 for a row without an
    answer."""

    def forward(self, batch):
        out = super().forward(batch)
        return out, F.cross_entropy(out.reshape(-1, 2), batch["target_seq"].reshape(-1).long(), ignore_index=-100)


def test_a_row_that_reads_whether_its_own_outcome_is_there_moves():
    """The redraw of the answers kept what tells an outcome by its presence: not a number stayed not a number, and a
    value below 0 stayed. A row that read only whether its own chargeback was there passed all seven checks with the
    entry named in `labels`. Checks 1 and 7 now run once more with that presence turned over. The first redraw keeps
    -100 where it stood, so a model that reads target_seq as a class is not stopped."""
    batch = _with_outcomes(bm.make_batch(seed=0, sequences=8, rows=40))
    for entry in ("cb_amount", "cb_days"):
        result = bm.run_checks(_ReadsWhetherItsOutcomeIsThere(entry), batch, units_per_second=UNIT,
                               labels=("target_seq", entry), say=lambda line: None)
        assert not result["passes"]["later rows"] and not result["passes"]["order in a second"], (entry, result)
        assert result["kept"] > 0.0 and result["same_second"] > 0.0
    kept = bm.run_checks(_ReadsEarlierSeconds(), batch, units_per_second=UNIT,
                         labels=("target_seq", "cb_amount", "cb_days"), say=lambda line: None)
    assert all(kept["passes"].values()), kept
    # rows without an answer (-100 on a tenth of the real rows), and a loss read from them as classes
    unlabeled = dict(batch, target_seq=torch.where(torch.rand(batch["mask"].shape, generator=torch.Generator(
        ).manual_seed(1)) < 0.1, torch.full_like(batch["target_seq"], -100), batch["target_seq"]))
    assert all(bm.run_checks(_HandsBackItsLoss(), unlabeled, units_per_second=UNIT, labels=("target_seq", "cb_days"),
                             say=lambda line: None)["passes"].values())
    rows = torch.zeros(1, 4, dtype=torch.bool)
    rows[0, :3] = True
    assert bm._redrawn({"y": torch.tensor([[0, 1, 2, -100]])}, rows, "y")["y"].tolist() == [[1, 2, 0, -100]]
    turned = bm._redrawn({"d": torch.tensor([[-1, 7, -1, -100]])}, rows, "d", valid=rows, presence=True)["d"]
    assert turned.tolist() == [[7, -1, 7, -100]]
    amounts = torch.tensor([[float("nan"), 5.0, 9.0, float("nan")]])
    turned = bm._redrawn({"a": amounts}, rows, "a", valid=rows, presence=True)["a"]
    assert turned[0, 0] == 10.0 and torch.isnan(turned[0, 1:]).all()


class _RemembersEveryTransaction(_ReadsEarlierSeconds):
    """Keeps on its instance, for every transaction it has seen (by its time and its first number), the mean of the
    whole window it was first seen in, later rows included, and reads it from there ever after."""

    def __init__(self):
        super().__init__()
        self.memo = {}

    def forward(self, batch):
        x, valid = self.row(batch), batch["mask"].bool()
        extra = torch.zeros_like(x)
        for b in range(x.shape[0]):
            whole = float(x[b][valid[b]].mean()) if bool(valid[b].any()) else 0.0
            for i in torch.nonzero(valid[b]).flatten().tolist():
                key = (int(batch["time_seq"][b, i]), float(batch["continuous"][b, i, 0]))
                extra[b, i] = self.memo.setdefault(key, whole)
        return super().forward(batch) + torch.stack([extra, -extra], dim=-1) * self.weight


def test_what_an_instance_kept_before_the_checks_does_not_answer_them_when_build_is_given():
    """A model that keeps what it worked out for each transaction on its instance, called once on the batch before
    the checks, answered every changed and cut window from that store and passed all seven. With `build`, checks 1,
    2, 3, 4 and 7 now run on an instance that was never called, and the read of later rows fails them."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    model = _RemembersEveryTransaction()
    with torch.no_grad():
        model(dict(batch))                                         # a look at its output before the checks
    result = bm.run_checks(model, batch, units_per_second=UNIT, build=_RemembersEveryTransaction,
                           say=lambda line: None)
    assert not result["passes"]["later rows"] and not result["passes"]["prefix"], result
    assert all(bm.run_checks(_ReadsEarlierSeconds(), batch, units_per_second=UNIT, build=_ReadsEarlierSeconds,
                             say=lambda line: None)["passes"].values())


class _ReadsOnlyInOneWayOfScoring(_ReadsEarlierSeconds):
    """Keeps the rule under torch.no_grad() and in training mode. Under torch.inference_mode() (`way` "inference"),
    or in evaluation mode with gradients on (`way` "gradients"), every row also reads `what`: the mean of its whole
    window ("window"), the number of real rows of its window ("length"), or the mean of the rows of its own second
    ("second")."""

    def __init__(self, way, what):
        super().__init__()
        self.way, self.what = way, what

    def forward(self, batch):
        out = super().forward(batch)
        on = torch.is_inference_mode_enabled() if self.way == "inference" else (
            torch.is_grad_enabled() and not self.training)
        if not on:
            return out
        x, valid = self.row(batch), batch["mask"].bool()
        if self.what == "window":
            extra = (x * valid).sum(dim=1, keepdim=True) / valid.sum(dim=1, keepdim=True).clamp(min=1)
        elif self.what == "length":
            extra = valid.sum(dim=1, keepdim=True).float() / 10.0
        else:
            seconds = _seconds(batch)
            same = (seconds.unsqueeze(1) == seconds.unsqueeze(2)) & valid.unsqueeze(1) & valid.unsqueeze(2)
            extra = (same.to(x.dtype) @ x.unsqueeze(-1)).squeeze(-1) / same.sum(dim=-1).clamp(min=1)
        extra = extra.expand_as(x) * valid
        return out + torch.stack([extra, -extra], dim=-1) * self.weight


def test_a_read_taken_only_under_inference_mode_or_with_gradients_on_moves():
    """Checks 1, 3 and 7 scored under torch.no_grad() and in training mode only. A model that read its whole window
    only under torch.inference_mode(), or only in evaluation mode with gradients on, passed all seven. The kept rows
    of check 1, the pass in place of check 3 and the first pass of check 7 are now scored in those two ways too."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    quiet = lambda line: None
    for way in ("inference", "gradients"):
        kept, later, read = bm.later_rows_change_nothing(_ReadsOnlyInOneWayOfScoring(way, "window"), batch,
                                                         units_per_second=UNIT, say=quiet)
        assert kept > 0.0, (way, kept)
        assert bm.prefix_agrees(_ReadsOnlyInOneWayOfScoring(way, "length"), batch, units_per_second=UNIT,
                                say=quiet) >= bm.PREFIX_TOLERANCE, way
        order, same_second = bm.order_inside_a_second(_ReadsOnlyInOneWayOfScoring(way, "second"),
                                                      _sorted_inside_seconds(batch), units_per_second=UNIT, say=quiet)
        assert same_second > 0.0, (way, order, same_second)


@dataclasses.dataclass(slots=True)
class _Slots:
    kept: object = None


class _KeepsInADequeAndInSlots(_ReadsEarlierSeconds):
    """Keeps the rule, and keeps its latest training outputs in a deque and in an object with __slots__."""

    def __init__(self):
        super().__init__()
        self.recent, self.slots = collections.deque(maxlen=2), _Slots()

    def forward(self, batch):
        out = super().forward(batch)
        if self.training:
            self.recent.append(out)
            self.slots.kept = out
        return out


def test_a_copy_reaches_a_tensor_in_a_deque_and_in_an_object_with_slots():
    """A tensor kept from a training step in a deque, or in an object with __slots__, stopped every copy: the walk
    that looked for such tensors knew dicts, lists, tuples, sets and objects with a __dict__ only. The copy now
    stands in for torch.Tensor's own deep copy while it runs, so it reaches whatever a deep copy reaches."""
    batch = bm.make_batch(seed=0, sequences=4, rows=16)
    model = _KeepsInADequeAndInSlots()
    model.train()
    bm.row_loss(model, batch).backward()
    assert not model.recent[0].is_leaf and not model.slots.kept.is_leaf
    twin = bm._copy(model)
    assert twin.recent[0].is_leaf and twin.slots.kept.is_leaf and twin.recent[0] is twin.slots.kept
    assert torch.equal(twin.recent[0], model.recent[0].detach())
    assert torch.Tensor.__deepcopy__ is not getattr(bm._copy, "detached", None)       # torch's own is back
    assert all(bm.run_checks(model, batch, units_per_second=UNIT, say=lambda line: None)["passes"].values())


class _CountsItsWindowIn32Bits(_ReadsEarlierSeconds):
    """Keeps the rule in 64 bits. In 32 bits every score gets a ten-millionth of the number of real rows of its
    window: a read of the later rows too small for a tolerance of one in a hundred thousand."""

    def forward(self, batch):
        out = super().forward(batch)
        if out.dtype == torch.float32:
            out = out + 1e-7 * batch["mask"].sum(dim=1, keepdim=True).unsqueeze(-1)
        return out


def test_the_pass_in_place_allows_no_change_and_runs_on_either_padding_side():
    """The pass in place of check 3 allowed the kept rows to move by a share of 1e-5, although every model that
    keeps the rule scores them bit for bit there: a small read of the later rows in the model's own number type
    passed. It allowed nothing on batches padded on the left, where it did not run. It now allows no change (unless
    two scorings of one batch already differ) and runs whichever side is padded; with a function `real` and no
    `pad` a line says that it does not run."""
    batch = bm.make_batch(seed=0, sequences=8, rows=40)
    lines = []
    moved = bm.prefix_agrees(_CountsItsWindowIn32Bits(), batch, units_per_second=UNIT, cut=range(1, 40),
                             say=lines.append)
    assert moved >= bm.PREFIX_TOLERANCE and any("they must not move" in line for line in lines), (moved, lines)
    left = _left_padded(batch)
    quiet = lambda line: None
    assert bm.prefix_agrees(_ReadsTheWindowIn16Bits().to(torch.bfloat16), left, units_per_second=UNIT,
                            say=quiet) > bm.PREFIX_TOLERANCE
    for rows in (batch, left):
        assert bm.prefix_agrees(_ReadsEarlierSeconds().to(torch.bfloat16), rows, units_per_second=UNIT,
                                say=quiet) < bm.PREFIX_TOLERANCE
        assert bm.prefix_agrees(_ReadsEarlierSeconds(), rows, units_per_second=UNIT, say=quiet) < 1e-12
    lines = []
    bm.prefix_agrees(_ReadsEarlierSeconds(), batch, units_per_second=UNIT, real=lambda entries: entries["mask"],
                     say=lines.append)
    assert any("is not scored on its slots made padding in place" in line for line in lines), lines


# Places outside a model's instances where the next model keeps an origin of time, and what lies beside them in
# this module without any model naming it.
_SAID = []                                    # the caller's own list of printed lines
_BESIDE = torch.zeros(400_000)                # the caller's own data (1.6 MB), named by no model
_LARGE = torch.zeros(400_000)                 # a large store a model writes into in place
_DEEP = {"a": {"b": {"c": {}}}}
_RECENT = collections.deque()
_HOLDER = types.SimpleNamespace(origin=None)
_LOG = logging.getLogger("additions.tests.origin")
_helper = None                                # a module of the caller's own, set by the test


class _Place:
    """A class used as a place to keep a value."""
    origin = None


class _Thing:
    """A plain object of the caller's own."""

    def __init__(self):
        self.origin = None


_THING = _Thing()


def _by_default(first, memo={}):  # noqa: B006 - the store is the default itself
    return memo.setdefault("origin", first)


def _closing():
    store = {}

    def origin(first):
        return store.setdefault("origin", first)

    return origin


_closed = _closing()


class _SharedByCopies(dict):
    """A store that a deep copy hands back as itself."""

    def __deepcopy__(self, memo):
        return self


class _KeepsItsOriginIn(_Plus):
    """Fixes an origin of time on its first call and keeps it outside its instances, in the place `where` names, so
    that every copy and every new instance share it."""

    def __init__(self, where):
        super().__init__()
        self.where, self.shared = where, _SharedByCopies()

    def term(self, batch):
        seconds = _seconds(batch).double()
        first = float(seconds[batch["mask"].bool()].min())
        origin = first
        if self.where == "deep":
            origin = _DEEP["a"]["b"]["c"].setdefault("origin", first)
        elif self.where == "deque":
            if not _RECENT:
                _RECENT.append(first)
            origin = _RECENT[0]
        elif self.where == "namespace":
            if _HOLDER.origin is None:
                _HOLDER.origin = first
            origin = _HOLDER.origin
        elif self.where == "class":
            if _Place.origin is None:
                _Place.origin = first
            origin = _Place.origin
        elif self.where == "object":
            if _THING.origin is None:
                _THING.origin = first
            origin = _THING.origin
        elif self.where == "default":
            origin = _by_default(first)
        elif self.where == "closure":
            origin = _closed(first)
        elif self.where == "helper":
            origin = _helper.STORE.setdefault("origin", first)
        elif self.where == "shared":
            origin = self.shared.setdefault("origin", first)
        elif self.where == "large":
            _LARGE[0] += 1.0
        elif self.where == "logger":
            _LOG.debug("scored %d rows", int(batch["mask"].sum()))
        return ((seconds - origin) / 86_400.0).float() * batch["mask"]


def test_the_state_outside_the_instances_is_read_where_the_code_reads_it_and_nowhere_else(tmp_path):
    """The line about state outside the instances read every variable of the module that defines the model's class:
    it copied the data a script or a notebook holds there, twice (a 1 GB tensor cost 3 GB), and named the caller's
    own list of lines; and it read two levels deep, so a store in a deeper dict, in an object, a deque, a class used
    as a place, a function's default or closure, a module of the caller's own, or an attribute every copy shares
    went unnamed. It now reads what the code of the model reads, wherever that lies, to eight levels, marks a large
    tensor instead of copying it, and knows an object of a library (a logger) by its identity."""
    global _helper
    path = tmp_path / "origin_helper.py"
    path.write_text("STORE = {}\nOTHER = [0]\n")
    spec = importlib.util.spec_from_file_location("origin_helper", path)
    _helper = importlib.util.module_from_spec(spec)
    sys.modules["origin_helper"] = _helper
    spec.loader.exec_module(_helper)
    batch = bm.make_batch(seed=0, sequences=4, rows=16)
    named = {"deep": "_DEEP", "deque": "_RECENT", "namespace": "_HOLDER", "class": "_Place.origin",
             "object": "_THING", "default": "_by_default()", "closure": "_closed()", "helper": "origin_helper.STORE",
             "shared": "instance shared", "large": "_LARGE"}
    try:
        for where, name in named.items():
            del _SAID[:]
            bm.run_checks(_KeepsItsOriginIn(where), batch, units_per_second=UNIT, say=_SAID.append)
            lines = [line for line in _SAID if "changed while the checks ran" in line]
            assert len(lines) == 1 and name in lines[0], (where, _SAID)
            # nothing else of this module is named: not the list the lines go to, not the data beside the class
            assert "_SAID" not in lines[0] and "_BESIDE" not in lines[0] and "OTHER" not in lines[0], lines
            assert sum(other in lines[0] for other in named.values()) == 1, (where, lines)
        for model in (_KeepsItsOriginIn("logger"), _ReadsEarlierSeconds()):
            del _SAID[:]
            bm.run_checks(model, batch, units_per_second=UNIT, say=_SAID.append)
            assert not any("changed while the checks ran" in line for line in _SAID), _SAID
        # a base class from an installed package that keeps something of its own on every call (a framework's
        # record of the warnings it gave, say) is no code of the model: nothing of it is named
        folder = tmp_path / "site-packages"
        folder.mkdir()
        (folder / "framework_base.py").write_text(
            "import torch.nn as nn\nGIVEN = set()\n\n\nclass Base(nn.Module):\n"
            "    def note(self, rows):\n        GIVEN.add(rows)\n        return len(GIVEN)\n")
        spec = importlib.util.spec_from_file_location("framework_base", folder / "framework_base.py")
        framework = importlib.util.module_from_spec(spec)
        sys.modules["framework_base"] = framework
        spec.loader.exec_module(framework)

        class OnAFramework(framework.Base, _ReadsEarlierSeconds):
            def forward(self, batch):
                self.note(int(batch["mask"].sum()))
                return _ReadsEarlierSeconds.forward(self, batch)

        del _SAID[:]
        result = bm.run_checks(OnAFramework(), batch, units_per_second=UNIT, say=_SAID.append)
        assert all(result["passes"].values()) and len(framework.GIVEN) > 1
        assert not any("changed while the checks ran" in line for line in _SAID), _SAID
        # a very long list, dict or set is not copied item by item: its count and a sample of its items are kept
        long_list, long_dict = list(range(300_000)), {k: k for k in range(300_000)}
        for store in (long_list, long_dict, set(long_list)):
            kept = bm._deep_snapshot(store)
            assert kept[0] == "plain" or len(kept[1]) < 8192, len(kept[1])
            assert bm._same_snapshot(kept, bm._deep_snapshot(store))
        long_list.append(0)
        long_dict[0] = 1
        assert not bm._same_snapshot(bm._deep_snapshot(list(range(300_000))), bm._deep_snapshot(long_list))
        assert not bm._same_snapshot(bm._deep_snapshot({k: k for k in range(300_000)}), bm._deep_snapshot(long_dict))
        assert bm._deep_snapshot(set(range(300_001))) != bm._deep_snapshot(set(range(300_000)))
        held = bm._outside_state(_KeepsItsOriginIn("large"))
        assert not any("_BESIDE" in name or "_SAID" in name for name in held), sorted(held)
        mark = [value for name, value in held.items() if name.endswith("._LARGE")]
        assert len(mark) == 1 and mark[0][0] == "sequence" and mark[0][1][0][1][0] == "large"   # a mark, not a copy
        assert mark[0][1][1][1].numel() < 8192                    # about 4,096 numbers of the 400,000
    finally:
        sys.modules.pop("origin_helper", None)
        sys.modules.pop("framework_base", None)
        _helper = None
