"""Tests of the catalogue of possible features.

They check the builder against slow, obvious computations on made-up data, and the two
promises every history feature makes: later rows change nothing, and a row never reads its
own bank decision.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, timekeys
from additions.features import possible_features as pf


def _data(seed=11, n_accounts=120):
    return synthetic.make_transactions(n_accounts=n_accounts, seed=seed).reset_index(drop=True)


def test_catalogue_is_well_formed():
    """Names are unique, every buildable entry has a recipe, and derived entries come after what they use."""
    names = [e["name"] for e in pf.CATALOGUE]
    assert len(names) == len(set(names))
    seen = set()
    for e in pf.CATALOGUE:
        if e["status"] == "here":
            assert e["how"] is not None
            for used in e["how"].get("uses", ()):
                assert used in seen, (e["name"], used)
        seen.add(e["name"])
    table = pf.list_features()
    assert len(table) == len(names) and (table["status"] == "here").sum() >= 90


def test_every_buildable_feature_builds_with_finite_values():
    """All features that need no extra column come out, aligned to the rows, with no infinite value."""
    df = _data()
    cols = pf.build_possible_features(df, quiet=True)
    assert len(cols) == len(df) and cols.shape[1] >= 90
    values = cols.to_numpy(dtype=np.float64)
    assert np.isfinite(values[~np.isnan(values)]).all()
    assert cols["amount_z_30d"].abs().max() < 1e4


def test_values_match_the_slow_definition():
    """A handful of features are recomputed row by row with plain filters and must agree."""
    df = _data(seed=12, n_accounts=40)
    cols = pf.build_possible_features(df, quiet=True)
    secs = timekeys.seconds(df[settings.TIME_COL])
    acct = df[settings.ACCOUNT_COL].to_numpy()
    amount = df[settings.AMOUNT_COL].to_numpy()
    merchant = df[settings.MERCHANT_COL].to_numpy()
    score = df[settings.VISA_SCORE_COL].to_numpy(dtype=float)
    declined = (df[settings.REASON_COL].to_numpy() != settings.APPROVED_REASONS[0]) | (df[settings.DECLINE_FLAG_COL].to_numpy() == 1)
    for i in range(0, len(df), 37):
        earlier = (acct == acct[i]) & (secs < secs[i])                      # strictly earlier seconds only
        day, week, month = earlier & (secs >= secs[i] - 86_400), earlier & (secs >= secs[i] - 604_800), earlier & (secs >= secs[i] - 2_592_000)
        assert cols["n_rows_24h"][i] == day.sum()
        assert np.isclose(cols["amount_sum_7d"][i], amount[week].sum(), rtol=1e-5)
        assert cols["merchant_n_30d"][i] == (month & (merchant == merchant[i])).sum()
        assert cols["n_distinct_merchants_7d"][i] == len(set(merchant[week]))
        assert cols["n_declines_24h"][i] == (day & declined).sum()
        if day.any():
            assert np.isclose(cols["score_max_24h"][i], score[day].max())
        else:
            assert np.isnan(cols["score_max_24h"][i])


def test_later_rows_change_nothing():
    """Dropping every row after a point in time leaves the features of the remaining rows unchanged."""
    df = _data(seed=13)
    secs = timekeys.seconds(df[settings.TIME_COL])
    keep = secs <= np.median(secs)
    full = pf.build_possible_features(df, quiet=True)[keep].reset_index(drop=True)
    part = pf.build_possible_features(df[keep].reset_index(drop=True), quiet=True)
    pd.testing.assert_frame_equal(full, part, check_exact=False, rtol=1e-5)


def test_a_row_never_reads_its_own_bank_decision():
    """Turning one approved row into a declined row changes later rows' features, never its own."""
    df = _data(seed=14)
    names = ["n_declines_1h", "n_declines_24h", "n_risk_declines_24h", "decline_share_24h",
             "seconds_since_decline_log", "previous_was_declined", "merchant_n_declines_24h", "n_funds_declines_7d"]
    before = pf.build_possible_features(df, names=names, quiet=True)
    approved = np.flatnonzero((df[settings.REASON_COL] == settings.APPROVED_REASONS[0]).to_numpy())
    row = int(approved[len(approved) // 2])
    changed = df.copy()
    changed.loc[row, settings.REASON_COL] = settings.RISK_DECLINE_REASONS[0]
    changed.loc[row, settings.DECLINE_FLAG_COL] = 1
    after = pf.build_possible_features(changed, names=names, quiet=True)
    pd.testing.assert_series_equal(before.loc[row], after.loc[row])           # its own columns are untouched
    assert not before.equals(after)                                           # a later row of the account sees it


def test_families_and_optional_columns():
    """A family filter builds only that family; a feature whose column is absent is left out, not failed."""
    df = _data(seed=15, n_accounts=30)
    only = pf.build_possible_features(df, families=["velocity"], quiet=True)
    velocity = {e["name"] for e in pf.CATALOGUE if e["family"] == "velocity"}
    assert set(only.columns) <= velocity and "n_rows_5m" in only
    out = pf.build_possible_features(df, names=["bank_pos_count_15m", "days_since_last_login", "n_rows_1h"], quiet=True)
    assert list(out.columns) == ["n_rows_1h"]
    with_column = df.assign(my_counter=np.arange(len(df)))
    old = pf.OPTIONAL_COLUMNS["bank_pos_count_15m"]
    pf.OPTIONAL_COLUMNS["bank_pos_count_15m"] = "my_counter"                   # how a column is switched on
    try:
        got = pf.build_possible_features(with_column, names=["bank_pos_count_15m"], quiet=True)
    finally:
        pf.OPTIONAL_COLUMNS["bank_pos_count_15m"] = old
    assert got["bank_pos_count_15m"].tolist() == list(range(len(df)))


def test_the_tool_lists_the_catalogue(capsys):
    """The command-line listing prints one line per entry."""
    assert pf.main(["--list", "--families", "outcomes"]) == 0
    printed = capsys.readouterr().out
    assert "n_declines_24h" in printed and "entries" in printed


def test_the_tool_builds_on_made_up_rows(capsys):
    """--demo builds the features on made-up rows, with no file at all."""
    assert pf.main(["--demo", "--families", "velocity"]) == 0
    assert "n_rows_5m" in capsys.readouterr().out


def test_rows_without_an_account_have_no_history():
    """A row with no account matches nothing: such rows never count for each other."""
    df = _data(seed=16, n_accounts=20)
    df[settings.ACCOUNT_COL] = df[settings.ACCOUNT_COL].astype(object)
    df.loc[df.index[:30], settings.ACCOUNT_COL] = None
    cols = pf.build_possible_features(df, names=["n_rows_30d", "amount_sum_30d"], quiet=True)
    assert (cols.loc[df.index[:30], "n_rows_30d"] == 0).all()
    assert (cols.loc[df.index[:30], "amount_sum_30d"] == 0).all()


def test_a_table_without_the_amount_builds_no_amount_feature():
    """Without an amount column every feature that reads the amount is left out, not filled with zeros."""
    df = _data(seed=17, n_accounts=20).drop(columns=[settings.AMOUNT_COL])
    cols = pf.build_possible_features(df, quiet=True)
    amount_names = [e["name"] for e in pf.CATALOGUE if e["family"] == "amount"]
    assert not [name for name in amount_names if name in cols.columns]
    assert "amount_sum_30d" not in cols.columns and "n_rows_30d" in cols.columns
    # No column is the same number on every row because a value was made up for it.
    full = pf.build_possible_features(_data(seed=17, n_accounts=20), quiet=True)
    assert set(cols.columns) < set(full.columns)
    assert np.array_equal(cols["n_rows_30d"].to_numpy(), full["n_rows_30d"].to_numpy())


def test_a_decline_means_the_same_as_in_the_outcome_history_file():
    """An advice row and a row with no response code are not declines; the counts follow the shared families."""
    from additions.features import outcome_history
    df = _data(seed=18, n_accounts=40).copy()
    df[settings.REASON_COL] = df[settings.REASON_COL].astype(object)
    df.loc[df.index[::7], settings.REASON_COL] = None                 # rows with no response code
    family = outcome_history.outcome_family(df)
    declined = np.isin(family, [outcome_history.FUNDS_DECLINE, outcome_history.RISK_DECLINE,
                                outcome_history.OTHER_DECLINE])
    assert (family == outcome_history.ADVICE).any() and (family == outcome_history.UNKNOWN).any()
    cols = pf.build_possible_features(df, names=["n_declines_24h"], quiet=True)
    account = df[settings.ACCOUNT_COL].to_numpy()
    secs = timekeys.seconds(df[settings.TIME_COL])
    slow = np.zeros(len(df))
    for i in range(len(df)):                                          # a slow loop: the definition itself
        earlier = (account == account[i]) & (secs < secs[i]) & (secs >= secs[i] - 86_400) & declined
        slow[i] = earlier.sum()
    assert np.array_equal(cols["n_declines_24h"].to_numpy(), slow.astype(np.float32))


def test_a_blank_merchant_matches_nothing():
    """Two rows of one account with a blank merchant text are not "the same merchant"."""
    df = _data(seed=19, n_accounts=5).copy()
    one = df[settings.ACCOUNT_COL] == df[settings.ACCOUNT_COL].iloc[0]
    df[settings.MERCHANT_COL] = df[settings.MERCHANT_COL].astype(object)
    df.loc[one, settings.MERCHANT_COL] = ""
    cols = pf.build_possible_features(df, names=["merchant_n_30d"], quiet=True)
    assert (cols.loc[one, "merchant_n_30d"] == 0).all()
    assert (cols.loc[~one, "merchant_n_30d"] > 0).any()

