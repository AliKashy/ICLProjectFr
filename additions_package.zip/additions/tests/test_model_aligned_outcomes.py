"""Tests of the first stage-2 layer that shows earlier rows' bank outcomes to later rows.

The central test changes the outcome code of single rows and checks that each such row's
own output does not move, nor do the outputs of the other rows of its second or of earlier
rows, while the outputs of later rows of the account do. The other tests check the outcome
codes, the strict time rule for the vectors, padding, gradients and the scoring route.
"""
import numpy as np
import torch

from additions import settings
from additions.common import synthetic
from additions.model._shared import layout, sequences_from_table
from additions.model.aligned_outcomes import AlignedOutcomeLayer, NUM_OUTCOME_CODES, outcome_codes
from additions.model.history_stage import HistoryStage

WIDTH, HEADS = 16, 4


def _batch(seed=0, n_accounts=10):
    """A padded batch of made-up transactions, its outcome codes laid out like it, and one random vector per slot."""
    df = synthetic.make_transactions(n_accounts=n_accounts, days=15, seed=seed, tie_share=0.15,
                                     fraud_account_share=0.8)
    batch, row_index, _ = sequences_from_table(df, seconds_per_sequence=8)
    codes = layout(outcome_codes(df), row_index, fill=0)
    torch.manual_seed(seed)
    vectors = torch.randn(*batch["mask"].shape, WIDTH)
    return batch, codes, vectors


def _stage(blocks=2, dropout=0.0):
    """A small stage 2 whose first layer is the outcome layer."""
    torch.manual_seed(1)
    layer = AlignedOutcomeLayer(width=WIDTH, num_heads=HEADS, dropout=dropout, attn_dropout=dropout)
    with torch.no_grad():
        layer.outcome.weight[1:].normal_(std=1.0)          # outcome embeddings large enough to move the outputs
    return HistoryStage(in_dim=WIDTH, num_heads=HEADS, num_blocks=blocks, history_len=6, first_layer=layer,
                        dropout=dropout, attn_dropout=dropout)


def test_outcome_codes_follow_the_families():
    """Codes are 1 + family, 0 for unknown, within the embedding table, and zeros when no decision column exists."""
    df = synthetic.make_transactions(n_accounts=20, days=10, seed=0, fraud_account_share=0.8)
    codes = outcome_codes(df)
    assert codes.dtype == np.int64 and len(codes) == len(df)
    assert codes.min() >= 0 and codes.max() < NUM_OUTCOME_CODES
    approved = df[settings.REASON_COL].isin(settings.APPROVED_REASONS) & (df[settings.ADVICE_COL].isna())
    assert (codes[approved.to_numpy()] == 1).all()
    assert np.array_equal(outcome_codes(df, family=np.array([-1, 0, 4])), [0, 1, 5])
    bare = df.drop(columns=[settings.REASON_COL, settings.DECLINE_FLAG_COL])
    assert np.array_equal(outcome_codes(bare), np.zeros(len(df), dtype=np.int64))


def test_a_row_never_reads_its_own_outcome_and_later_rows_do():
    """Changing a row's outcome code leaves that row, its second and earlier rows unchanged, and moves later rows."""
    batch, codes, vectors = _batch(seed=1)
    stage = _stage().eval()
    times, valid = batch["time_seq"], batch["mask"]
    with torch.no_grad():
        before = stage(vectors, times, valid, outcome=codes)
    checked = 0
    for b in range(times.shape[0]):
        real = int(valid[b].sum())
        for i in range(real):
            later = valid[b] & (times[b] > times[b, i])
            if not later.any():
                continue
            changed = codes.clone()
            changed[b, i] = 3 if int(codes[b, i]) != 3 else 1
            with torch.no_grad():
                after = stage(vectors, times, valid, outcome=changed)
            not_later = valid[b] & ~later
            assert torch.allclose(before[b, not_later], after[b, not_later], atol=1e-5)
            assert not torch.allclose(before[b, later], after[b, later], atol=1e-5)
            # Other sequences are untouched.
            others = torch.ones(times.shape[0], dtype=torch.bool)
            others[b] = False
            assert torch.allclose(before[others], after[others], atol=1e-5)
            checked += 1
            break
    assert checked >= 3


def test_the_layer_alone_hides_a_row_from_itself():
    """In the layer by itself, a row's output does not depend on its own outcome, even with nothing earlier to read."""
    torch.manual_seed(0)
    layer = AlignedOutcomeLayer(width=WIDTH, num_heads=HEADS, dropout=0.0, attn_dropout=0.0).eval()
    x = torch.randn(1, 3, WIDTH)
    allowed = torch.tensor([[[True, False, False], [True, True, False], [True, True, True]]])
    with torch.no_grad():
        a = layer(x, allowed, torch.tensor([[1, 2, 3]]))
        b = layer(x, allowed, torch.tensor([[4, 2, 3]]))
        c = layer(x, allowed, torch.tensor([[1, 2, 5]]))
    assert torch.allclose(a[0, 0], b[0, 0]) and not torch.allclose(a[0, 1:], b[0, 1:])
    assert torch.allclose(a, c, atol=1e-6)                     # the last row is read by no one
    assert torch.isfinite(a).all()


def test_rows_never_read_later_rows_or_rows_of_their_own_second():
    """Altering the vectors and outcomes of every row a row may not read leaves that row's output unchanged."""
    batch, codes, vectors = _batch(seed=2)
    stage = _stage().eval()
    times, valid = batch["time_seq"], batch["mask"]
    with torch.no_grad():
        before = stage(vectors, times, valid, outcome=codes)
    for b in range(min(6, times.shape[0])):
        i = int(valid[b].sum()) // 2
        hidden = valid[b] & (times[b] >= times[b, i])
        hidden[i] = False
        altered_v, altered_c = vectors.clone(), codes.clone()
        altered_v[b, hidden] = torch.randn(int(hidden.sum()), WIDTH) * 3
        altered_c[b, hidden] = torch.randint(1, NUM_OUTCOME_CODES, (int(hidden.sum()),))
        with torch.no_grad():
            after = stage(altered_v, times, valid, outcome=altered_c)
        assert torch.allclose(before[b, i], after[b, i], atol=1e-5)


def test_padding_and_prefix_keep_every_output_finite():
    """Padded slots, a prefix and rows with nothing earlier to read all give finite outputs."""
    batch, codes, vectors = _batch(seed=3)
    stage = _stage().eval()
    prefix = torch.randn(vectors.shape[0], 2, WIDTH)
    with torch.no_grad():
        out = stage(vectors, batch["time_seq"], batch["mask"], outcome=codes, prefix=prefix)
        plain = stage(vectors, batch["time_seq"], batch["mask"])
    assert torch.isfinite(out).all() and torch.isfinite(plain).all()
    assert not batch["mask"].all()


def test_a_zero_bias_changes_nothing():
    """A bias of zeros gives the output of no bias."""
    batch, codes, vectors = _batch(seed=4)
    stage = _stage().eval()
    B, T = batch["mask"].shape
    with torch.no_grad():
        plain = stage(vectors, batch["time_seq"], batch["mask"], outcome=codes)
        zero = stage(vectors, batch["time_seq"], batch["mask"], outcome=codes, bias=torch.zeros(B, HEADS, T, T))
    assert torch.allclose(plain, zero, atol=1e-6)


def test_gradients_reach_the_outcome_embedding_and_the_nothing_key():
    """A loss on the real rows sends a gradient to the outcome embedding, the learned empty key and the attention."""
    batch, codes, vectors = _batch(seed=5)
    stage = _stage(dropout=0.1).train()
    out = stage(vectors, batch["time_seq"], batch["mask"], outcome=codes)
    out[batch["mask"]].pow(2).mean().backward()
    layer = stage.first_layer
    assert layer.outcome.weight.grad[1:].abs().sum() > 0
    assert layer.outcome.weight.grad[0].abs().sum() == 0              # code 0 stays the zero vector
    assert layer.nothing.grad.abs().sum() > 0
    assert layer.attend.in_proj_weight.grad.abs().sum() > 0


def test_scoring_route_agrees_with_training_at_dropout_zero():
    """Evaluation mode under torch.no_grad() gives the training-mode output at dropout zero."""
    batch, codes, vectors = _batch(seed=6)
    stage = _stage(dropout=0.0)
    train_out = stage.train()(vectors, batch["time_seq"], batch["mask"], outcome=codes)
    with torch.no_grad():
        eval_out = stage.eval()(vectors, batch["time_seq"], batch["mask"], outcome=codes)
    assert torch.allclose(train_out, eval_out, atol=1e-5)
