"""Tests of the account sampling.

The draw is shown to depend on the account and the seed only, the sample is checked against
the slow account-by-account rule, and the log-odds correction is checked on exact numbers.
"""
import numpy as np
import pandas as pd
import torch

from additions import settings
from additions.common import synthetic
from additions.training import account_sampling
from additions.training.account_sampling import (account_draw, bags, sample_accounts, sample_summary,
                                                 sampling_offset, undo_sampling)


def _rows(seed=0, n_accounts=200):
    """Made-up raw rows with a fair number of fraud accounts."""
    return synthetic.make_transactions(n_accounts=n_accounts, seed=seed, fraud_account_share=0.2, days=31)


def test_draw_depends_only_on_the_account_and_the_seed():
    """An account's number is the same in any order and next to any other accounts, and is spread evenly."""
    ids = np.array([f"acct{i:07d}" for i in range(20_000)])
    draw = account_draw(ids, seed=3)
    assert draw.min() >= 0.0 and draw.max() < 1.0
    assert abs(draw.mean() - 0.5) < 0.01 and abs((draw < 0.1).mean() - 0.1) < 0.01
    shuffled = np.random.default_rng(0).permutation(20_000)
    assert np.array_equal(account_draw(ids[shuffled], seed=3), draw[shuffled])
    assert np.array_equal(account_draw(ids[:7], seed=3), draw[:7])                  # other accounts do not matter
    assert np.array_equal(account_draw(np.arange(5), 1), account_draw(np.array(["0", "1", "2", "3", "4"]), 1))
    other = account_draw(ids, seed=4)
    assert abs(np.corrcoef(draw, other)[0, 1]) < 0.03                                  # another seed is unrelated


def test_sample_equals_the_slow_account_rule():
    """Kept accounts are the fraud accounts, the risky clean ones and the clean ones whose number is below S."""
    df = _rows()
    share = 0.3
    sample = sample_accounts(df, share=share, seed=5, risky_quantile=0.95)
    score_cut = np.quantile(df[settings.VISA_SCORE_COL].to_numpy(dtype=float), 0.95)
    for account, rows in df.groupby(settings.ACCOUNT_COL):
        fraud = (rows[settings.LABEL_COL] == settings.POSITIVE_LABEL).any()
        risky = (not fraud) and rows[settings.VISA_SCORE_COL].max() > score_cut
        picked = account_draw(np.array([account]), 5)[0] < share
        got = sample.loc[rows.index]
        assert (got["fraud_account"] == fraud).all() and (got["risky_account"] == risky).all()
        assert (got["account_kept"] == (fraud or risky or picked)).all()     # whole accounts only
        if not (fraud or risky or picked):
            assert (got["loss_weight"] == 0).all()
    assert sample["risky_account"].any() and not sample["account_kept"].all()


def test_mask_mode_keeps_history_and_thins_fraud_account_negatives():
    """Fraud rows always count; non-fraud rows of fraud accounts stay as history and reach the loss at about S."""
    df = _rows(seed=1, n_accounts=300)
    share = 0.25
    sample = sample_accounts(df, share=share, seed=2, mode="mask")
    fraud = (df[settings.LABEL_COL] == settings.POSITIVE_LABEL).to_numpy()
    fa = sample["fraud_account"].to_numpy()
    w = sample["loss_weight"].to_numpy()
    assert (w[fraud] == 1.0).all() and sample["account_kept"].to_numpy()[fa].all()
    negatives = fa & ~fraud
    assert abs((w[negatives] > 0).mean() - share) < 0.05
    assert set(np.unique(w)) <= {0.0, 1.0}
    assert np.allclose(sample["keep_prob"].to_numpy()[negatives], share)
    # The same seed gives the same rows; the table's row order does not matter.
    again = sample_accounts(df.iloc[::-1], share=share, seed=2, mode="mask")
    assert np.array_equal(again.loc[df.index, "loss_weight"].to_numpy(), w)


def test_weight_mode_makes_kept_clean_rows_stand_for_the_dropped_ones():
    """Sampled clean rows carry 1/S, fraud-account rows 1; the weighted clean count is near the full count."""
    df = _rows(seed=2, n_accounts=400)
    share = 0.5
    sample = sample_accounts(df, share=share, seed=1, mode="weight")
    fa = sample["fraud_account"].to_numpy()
    kept = sample["account_kept"].to_numpy()
    w = sample["loss_weight"].to_numpy()
    assert (w[fa] == 1.0).all()
    assert np.allclose(w[kept & ~fa], 1.0 / share) and (w[~kept] == 0).all()
    ratio = w[~fa].sum() / (~fa).sum()
    assert 0.8 < ratio < 1.2


def test_offsets_undo_the_sampling_exactly():
    """With negatives kept at rate q, true log-odds = sampled log-odds + log q, and the offset is -log q."""
    p = np.array([0.001, 0.01, 0.2, 0.7])
    q = 0.1
    true_logit = np.log(p / (1 - p))
    sampled_odds = p / ((1 - p) * q)                       # negatives thinned to a share q
    sampled_logit = np.log(sampled_odds)
    assert np.allclose(undo_sampling(sampled_logit, q), true_logit)
    assert np.allclose(true_logit + sampling_offset(np.full(4, q)), sampled_logit)
    t = undo_sampling(torch.tensor(sampled_logit), q)
    assert torch.is_tensor(t) and np.allclose(t.numpy(), true_logit)
    assert torch.allclose(sampling_offset(torch.tensor([1.0, 0.5])), torch.tensor([0.0, np.log(2.0)]).float())
    # Adding one constant to every row leaves the order of the rows as it was.
    assert np.array_equal(np.argsort(undo_sampling(sampled_logit, q)), np.argsort(sampled_logit))


def test_bags_share_fraud_accounts_and_differ_in_clean_ones():
    """Every bag keeps the same fraud accounts; the clean accounts differ between seeds."""
    df = _rows(seed=3)
    samples = bags(df, share=0.3, seeds=(0, 1, 2))
    assert sorted(samples) == [0, 1, 2]
    kept = [s["account_kept"].to_numpy() for s in samples.values()]
    fa = samples[0]["fraud_account"].to_numpy()
    assert all(k[fa].all() for k in kept)
    assert not np.array_equal(kept[0], kept[1]) and not np.array_equal(kept[1], kept[2])
    table = sample_summary(df, samples[0]).set_index("measure")
    assert table.loc["fraud rows in the loss", "kept"] == table.loc["fraud rows in the loss", "all"]


def test_missing_risk_column_skips_the_rule(capsys):
    """Without a risk score column the risky-account rule is skipped with one line and nothing fails."""
    df = _rows(seed=4).drop(columns=[settings.VISA_SCORE_COL])
    sample = sample_accounts(df, share=0.2, risky_quantile=0.98)
    assert "risky-account rule" in capsys.readouterr().out
    assert not sample["risky_account"].any()


def test_command_line_demo_writes_one_column_pair_per_seed(tmp_path):
    """The demo prints a summary per bag and writes the kept flag and weight per seed."""
    out = tmp_path / "sample.parquet"
    account_sampling.main(["--demo", "--seeds", "0", "1", "--mode", "weight", "--out", str(out)])
    written = pd.read_parquet(out)
    assert {"account_kept_0", "loss_weight_0", "account_kept_1", "loss_weight_1", settings.ID_COL} <= set(written)
