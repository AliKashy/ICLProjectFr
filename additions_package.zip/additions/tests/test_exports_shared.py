"""Tests of additions/exports/_shared.py on made-up data. They double as usage examples."""
import numpy as np
import pandas as pd
from scipy.special import expit

from additions import settings
from additions.common import ranking, synthetic
from additions.common.bootstrap import paired_bootstrap
from additions.common.timekeys import MISSING_SECOND
from additions.exports import _shared as shared


def test_codes_are_compared_as_numbers_or_as_text_and_a_missing_value_never_matches():
    """The code "00" matches the number 0 and the text " 00 "; a missing value matches nothing."""
    assert shared.has_code([0, 5, 59.0, np.nan], ("00", "59")).tolist() == [True, False, True, False]
    assert shared.has_code(["00", " 59 ", "5", None], ("00", "59")).tolist() == [True, True, False, False]
    assert shared.has_code([1.0, 2.0], ("Y",)).tolist() == [False, False]


def test_an_optional_column_that_is_absent_is_skipped_with_one_line(capsys):
    """A name of None or a name the table lacks gives None and one printed line; a present name gives the column."""
    df = pd.DataFrame({"a": [1, 2]})
    assert shared.optional_column(df, None, "the card key") is None
    assert shared.optional_column(df, "b", "the card key") is None
    printed = capsys.readouterr().out.strip().splitlines()
    assert len(printed) == 2 and all("skipped" in line for line in printed)
    assert shared.optional_column(df, "a", "the card key").tolist() == [1, 2]
    assert shared.amounts(pd.DataFrame({"x": [1.0]})) is None


def test_rows_are_placed_by_account_and_second_and_periods_are_half_open():
    """A row without an account gets the missing-time marker, and a period includes its start only."""
    df = synthetic.make_transactions(n_accounts=5, seed=0).head(8).copy()
    df.loc[df.index[3], settings.ACCOUNT_COL] = None
    keys, secs = shared.account_and_time(df)
    assert secs[3] == MISSING_SECOND and (np.delete(secs, 3) != MISSING_SECOND).all()
    assert len(keys) == len(df)

    stamps = pd.to_datetime(["2025-05-31 23:59:59", "2025-06-01 00:00:00", "2025-06-30 23:59:59",
                             "2025-07-01 00:00:00"])
    seconds = np.append(stamps.astype("int64") // 1_000_000_000, MISSING_SECOND)
    assert shared.in_period(seconds, "2025-06-01", "2025-07-01").tolist() == [False, True, True, False, False]


def test_vector_columns_come_in_the_order_of_their_numbers_and_text_becomes_missing():
    """e_10 sorts after e_2, a look-alike name is left out, and a cell that is not a number is missing."""
    df = pd.DataFrame({"e_10": [1.0], "e_2": [2.0], "e_0": [3.0], "ex_1": [4.0], "e_x": [5.0]})
    assert shared.vector_columns(df, "e_") == ["e_0", "e_2", "e_10"]
    mixed = pd.DataFrame({"a": ["1.5", "x", None], "b": [1, 2, 3]})
    matrix = shared.numeric_matrix(mixed, ["a", "b"])
    assert matrix.dtype == np.float32 and matrix.shape == (3, 2)
    np.testing.assert_array_equal(matrix[:, 0], np.array([1.5, np.nan, np.nan], dtype=np.float32))
    assert shared.numeric_matrix(mixed, []).shape == (3, 0)


def test_scores_are_read_as_log_odds_or_as_probabilities_whatever_is_stored():
    """A stored probability and a stored log-odds value give the same two readings."""
    p = np.array([0.01, 0.2, 0.9])
    as_probability = pd.DataFrame({settings.SCORE_COL: p})
    as_logit = pd.DataFrame({settings.SCORE_COL: np.log(p / (1 - p))})
    np.testing.assert_allclose(shared.logits(as_probability, score_kind="probability"),
                               shared.logits(as_logit, score_kind="logit"), rtol=1e-9)
    np.testing.assert_allclose(shared.probabilities(as_logit, score_kind="logit"),
                               shared.probabilities(as_probability, score_kind="probability"), rtol=1e-9)
    assert shared.fraud_flags(pd.DataFrame({settings.LABEL_COL: [1, 0, 1.0, None]})).tolist() == [1.0, 0.0, 1.0, 0.0]


def test_the_logistic_fit_recovers_known_weights_and_keeps_the_event_rate():
    """Weights used to draw the outcomes come back, and the mean fitted probability equals the event rate."""
    rng = np.random.default_rng(0)
    x = rng.normal(size=(40_000, 2)) * np.array([1.0, 25.0]) + np.array([0.0, 100.0])    # two very different scales
    true_weights, true_bias = np.array([1.5, -0.03]), 1.0
    y = (rng.random(len(x)) < expit(x @ true_weights + true_bias)).astype(float)

    fitted = shared.fit_logistic(x, y, l2=1e-6)
    np.testing.assert_allclose(fitted["weights"], true_weights, rtol=0.08)
    assert abs(fitted["bias"] - true_bias) < 0.25
    log_odds = shared.apply_logistic(x, fitted)
    assert abs(expit(log_odds).mean() - y.mean()) < 1e-5

    # Rows with a missing input are left out of the fit, and get a missing value when scored.
    holed = np.vstack([x, [[np.nan, 1.0]]])
    again = shared.fit_logistic(holed, np.append(y, 1.0), l2=1e-6)
    np.testing.assert_allclose(again["weights"], fitted["weights"], rtol=1e-6)
    assert np.isnan(shared.apply_logistic(holed, again)[-1])

    # One input may be given as a plain vector.
    single = shared.fit_logistic(x[:, 0], y, l2=1e-6)
    assert len(single["weights"]) == 1 and shared.apply_logistic(x[:, 0], single).shape == (len(x),)


def test_a_logistic_fit_on_one_outcome_is_skipped_with_one_line(capsys):
    """Rows that hold only one of the two outcomes give None, and one line says what was skipped."""
    x = np.arange(10.0)
    assert shared.fit_logistic(x, np.zeros(10), what="the probe of this test") is None
    printed = capsys.readouterr().out
    assert "the probe of this test" in printed and "skipped" in printed


def test_trees_start_from_the_base_margin_and_accept_targets_between_zero_and_one():
    """With zero trees the base margin comes back; trees on a helpful column lower the loss; a soft target is taken."""
    df = synthetic.make_scores(synthetic.make_transactions(n_accounts=300, seed=4), seed=4, strength=1.5)
    labels = shared.fraud_flags(df)
    base = shared.logits(df)
    rng = np.random.default_rng(1)
    x = np.column_stack([labels + rng.normal(scale=0.5, size=len(labels)), rng.normal(size=len(labels))])

    nothing = shared.fit_trees(x, labels, base_margin=base, rounds=0)
    np.testing.assert_allclose(shared.tree_margin(nothing, x, base), base, rtol=1e-5, atol=1e-5)

    def loss(margin):
        return float(np.mean(np.logaddexp(0.0, margin) - labels * margin))

    model = shared.fit_trees(x, labels, base_margin=base, rounds=30)
    assert loss(shared.tree_margin(model, x, base)) < loss(base)

    soft = 0.5 * labels + 0.5 * shared.probabilities(df)
    soft_model = shared.fit_trees(x, soft, rounds=10)
    assert np.isfinite(shared.tree_margin(soft_model, x)).all()


def test_result_lines_repeat_the_capture_and_the_bootstrap_under_the_given_names():
    """A capture line holds what ranking.capture gives, and a bootstrap line renames the two captures."""
    df = synthetic.make_scores(synthetic.make_transactions(n_accounts=300, seed=6), seed=6)
    labels, scores, amount = shared.fraud_flags(df), shared.logits(df), shared.amounts(df)
    line = shared.capture_line("model", labels, scores, amount)
    got = ranking.capture(labels, scores, amount)
    assert line["read"] == "model" and line["rows"] == len(df) and line["frauds"] == int(labels.sum())
    assert line["caught"] == got["caught"] and line["udr"] == got["udr"] and line["vdr"] == got["vdr"]
    assert line["ap"] == ranking.average_precision(labels, scores)

    noisy = scores + np.random.default_rng(0).normal(size=len(scores))
    result = paired_bootstrap(df[settings.ACCOUNT_COL].to_numpy(), labels, scores, noisy, draws=100)
    renamed = shared.bootstrap_line(result, first="with", second="without")
    assert renamed["with"] == result["a"] and renamed["without"] == result["b"]
    assert renamed["gain"] == result["gain"] and renamed["draws"] == 100


def test_tables_are_summarised_printed_and_saved(tmp_path, capsys):
    """The summary skips text columns, an empty table prints a note, and a saved table reads back equal."""
    frame = pd.DataFrame({"a": [1.0, np.nan, 3.0, 5.0], "b": ["x", "y", "z", "w"], "c": [np.nan] * 4})
    summary = shared.summary(frame).set_index("column")
    assert list(summary.index) == ["a", "c"]
    assert summary.loc["a", "missing"] == 0.25 and summary.loc["a", "mean"] == 3.0
    assert summary.loc["a", "min"] == 1.0 and summary.loc["a", "max"] == 5.0
    assert summary.loc["c", "missing"] == 1.0 and np.isnan(summary.loc["c", "mean"])

    shared.show("a title", [])
    shared.show("another title", [{"x": 1.23456, "y": np.nan}])
    printed = capsys.readouterr().out
    assert "a title" in printed and "(no rows)" in printed and "1.2346" in printed

    path = str(tmp_path / "table.parquet")
    shared.save(frame, path)
    shared.save(frame, path)                                   # an existing file is replaced
    pd.testing.assert_frame_equal(pd.read_parquet(path), frame)
