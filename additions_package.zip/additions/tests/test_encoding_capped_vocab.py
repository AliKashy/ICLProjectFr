"""Tests of the capped vocabulary and the tiered embedding.

The keys and the shared rows are compared with slow whole-number arithmetic in plain
Python, the vocabulary with a slow pandas count, and the table is checked for shapes,
finite values, gradient flow into every tier, and for replacing values only in training.
"""
import numpy as np
import pandas as pd
import torch

from additions import settings
from additions.common import synthetic
from additions.encoding import capped_vocab as cv

SIZES = dict(min_accounts=20, n_full=20, n_narrow=40, n_shared=16, per_category=4)


def _table(n_accounts=300, seed=1):
    return synthetic.make_transactions(n_accounts=n_accounts, seed=seed)


def _slow_key(text):
    """The key of one text with Python whole numbers: fold the bytes, then stir."""
    h = 14695981039346656037
    for byte in text.encode("utf-8"):
        h = ((h ^ byte) * 1099511628211) % 2**64
    h ^= h >> 30
    h = (h * 0xBF58476D1CE4E5B9) % 2**64
    h ^= h >> 27
    h = (h * 0x94D049BB133111EB) % 2**64
    return h ^ (h >> 31)


def test_keys_match_slow_whole_number_arithmetic_and_do_not_depend_on_the_other_texts():
    """Every key equals the byte-by-byte computation, and a text has the same key whatever else is in the array."""
    texts = ["", "a", "ab", "abc", "5411", "merchant 00042", "a much longer text than all the others", "caf\u00e9"]
    keys = cv.text_keys(texts)
    assert keys.dtype == np.uint64 and [int(k) for k in keys] == [_slow_key(t) for t in texts]
    assert len(set(keys.tolist())) == len(texts)
    assert int(cv.text_keys(["ab"])[0]) == int(keys[2]) and int(cv.text_keys(texts[::-1])[-1]) == int(keys[0])
    assert len(cv.text_keys([])) == 0


def test_shared_rows_follow_the_formula_and_keep_a_category_together():
    """The row is (category key % S + id key % spread) % S; ids of one category stay within a few neighbouring rows."""
    ids = [f"m{i}" for i in range(400)]
    id_keys = cv.text_keys(ids)
    rows = cv.shared_rows(id_keys, None, n_shared=16)
    assert rows.dtype == np.int64 and [int(r) for r in rows] == [_slow_key(t) % 16 for t in ids]
    assert set(rows.tolist()) == set(range(16))                         # every shared row is used
    cats = ["5411"] * 200 + ["5812"] * 200
    with_cat = cv.shared_rows(id_keys, cv.text_keys(cats), n_shared=64, per_category=4)
    slow = [(_slow_key(c) % 64 + _slow_key(t) % 4) % 64 for t, c in zip(ids, cats)]
    assert [int(r) for r in with_cat] == slow
    for cat in ("5411", "5812"):
        home = _slow_key(cat) % 64
        used = {int(r) for r, c in zip(with_cat, cats) if c == cat}
        assert used == {(home + step) % 64 for step in range(4)}


def test_vocabulary_keeps_values_seen_on_enough_accounts_ranked_by_rows():
    """The kept values and their tiers equal a slow pandas count; labels and row order play no part."""
    df = _table()
    vocab = cv.fit_vocab(df, **SIZES)
    merchant = df[settings.MERCHANT_COL].astype(str)
    stats = pd.DataFrame({"accounts": df.groupby(merchant)[settings.ACCOUNT_COL].nunique(),
                          "rows": merchant.value_counts()})
    kept = stats[stats["accounts"] >= 20].reset_index(names="id").sort_values(["rows", "id"], ascending=[False, True])
    assert len(kept) > 60                                                # all three tiers are in use
    assert vocab["full_ids"].tolist() == kept["id"].tolist()[:20]
    assert vocab["narrow_ids"].tolist() == kept["id"].tolist()[20:60]
    assert vocab["fallback"].shape == (61,) and vocab["fallback"][0] == 0
    assert vocab["fallback"][1:].min() >= 61 and vocab["fallback"][1:].max() <= 60 + 16
    shuffled = df.sample(frac=1.0, random_state=0).assign(**{settings.LABEL_COL: 1})
    again = cv.fit_vocab(shuffled, **SIZES)
    assert all(np.array_equal(vocab[key], again[key]) for key in ("full_ids", "narrow_ids", "fallback"))


def test_a_value_with_many_rows_on_one_account_gets_no_row_of_its_own():
    """The cap counts accounts: a habit of one account is not kept, a value spread over many accounts is."""
    one = pd.DataFrame({settings.ACCOUNT_COL: ["a0"] * 500, settings.MERCHANT_COL: ["habit"] * 500})
    many = pd.DataFrame({settings.ACCOUNT_COL: [f"a{i}" for i in range(30)], settings.MERCHANT_COL: ["spread"] * 30})
    vocab = cv.fit_vocab(pd.concat([one, many], ignore_index=True), category_col="", min_accounts=20, n_full=5,
                         n_narrow=5, n_shared=8)
    assert vocab["full_ids"].tolist() == ["spread"] and len(vocab["narrow_ids"]) == 0


def test_encoding_gives_own_rows_shared_rows_and_a_row_for_no_value():
    """Kept values read their own row, all others a shared row picked from category and id, a missing value row 0."""
    df = _table()
    vocab = cv.fit_vocab(df, **SIZES)
    other = _table(n_accounts=80, seed=5).reset_index(drop=True)        # other accounts, as at scoring
    other.loc[::9, settings.MERCHANT_COL] = 10_000_000 + other.index[::9]          # values that did not exist at the fit
    other[settings.MERCHANT_COL] = other[settings.MERCHANT_COL].astype(object)
    other.loc[::13, settings.MERCHANT_COL] = None
    index = cv.encode(other, vocab)
    assert index.shape == (len(other),) and index.dtype == np.int64
    own = {text: 1 + i for i, text in enumerate(list(vocab["full_ids"]) + list(vocab["narrow_ids"]))}
    for i in range(0, len(other), 3):
        value, category = other[settings.MERCHANT_COL].iloc[i], str(other[settings.MCC_COL].iloc[i])
        if value is None:
            slow = 0
        elif str(value) in own:
            slow = own[str(value)]
        else:
            slow = 61 + (_slow_key(category) % 16 + _slow_key(str(value)) % 4) % 16
        assert index[i] == slow
    assert (index[::13] == 0).all() and index.max() <= 60 + 16
    # A row gets the same index whichever rows are encoded with it, and whether the id is stored as number or text.
    assert np.array_equal(cv.encode(other.iloc[:200], vocab), index[:200])
    as_text = other.assign(**{settings.MERCHANT_COL: other[settings.MERCHANT_COL].map(lambda v: None if v is None else str(v))})
    as_decimal = other.assign(**{settings.MERCHANT_COL: pd.to_numeric(other[settings.MERCHANT_COL]).astype(float)})
    assert np.array_equal(cv.encode(as_text, vocab), index) and np.array_equal(cv.encode(as_decimal, vocab), index)


def test_a_replaced_value_lands_where_an_unseen_value_of_its_category_would():
    """The fallback of a kept value is the shared row that the same category and id get without a vocabulary."""
    df = _table()
    vocab = cv.fit_vocab(df, **SIZES)
    empty = dict(vocab, full_ids=np.array([], dtype=str), narrow_ids=np.array([], dtype=str))
    with_vocab, without = cv.encode(df, vocab), cv.encode(df, empty)
    kept = with_vocab <= 60
    assert kept.any() and (without >= 1).all() and (without <= 16).all()
    assert np.array_equal(vocab["fallback"][with_vocab[kept]] - 60, without[kept])


def test_table_reads_the_right_tier_and_every_tier_learns():
    """Shapes and values are right for each tier, and one backward pass reaches the wide rows, the narrow rows and the map."""
    torch.manual_seed(0)
    table = cv.TieredEmbedding(n_full=5, n_narrow=7, n_shared=4, embed_dim=6, narrow_dim=3).eval()
    index = torch.tensor([[0, 1, 5, 6], [12, 13, 16, 9]])
    out = table(index)
    assert out.shape == (2, 4, 6) and bool(torch.isfinite(out).all())
    assert torch.equal(out[0, :3], table.wide.weight[[0, 1, 5]])        # no value and full-width rows
    assert torch.equal(out[1, 1:3], table.wide.weight[[6, 9]])          # shared rows sit after the full rows
    narrow = table.narrow_up(table.narrow(torch.tensor([0, 6, 3])))
    assert torch.allclose(torch.stack([out[0, 3], out[1, 0], out[1, 3]]), narrow)
    out.pow(2).sum().backward()
    read = torch.nonzero(table.wide.weight.grad.abs().sum(1)).flatten().tolist()
    assert read == [0, 1, 5, 6, 9]
    assert torch.nonzero(table.narrow.weight.grad.abs().sum(1)).flatten().tolist() == [0, 3, 6]
    assert float(table.narrow_up.weight.grad.abs().sum()) > 0
    # A projected narrow row starts about as wide as a full-width row; a table without a narrow tier works too.
    big = cv.TieredEmbedding(200, 2000, 8, embed_dim=48, narrow_dim=12)
    spread = big.narrow_up(big.narrow.weight).std().item()
    assert 0.8 < spread / big.wide.weight.std().item() < 1.25
    flat = cv.TieredEmbedding(3, 0, 2, embed_dim=4).eval()
    assert torch.equal(flat(torch.tensor([0, 3, 4, 5])), flat.wide.weight[[0, 3, 4, 5]])


def test_values_are_sent_to_their_shared_row_in_training_only():
    """In training an own row is replaced by its fallback at the given rate; in eval mode nothing is replaced."""
    torch.manual_seed(1)
    df = _table()
    vocab = cv.fit_vocab(df, **SIZES)
    index = torch.as_tensor(cv.encode(df, vocab))
    fallback = torch.as_tensor(vocab["fallback"])
    own = (index >= 1) & (index <= 60)
    always = cv.TieredEmbedding.from_vocab(vocab, embed_dim=8, replace_rate=1.0)
    expected = always.eval()(torch.where(own, fallback[index.clamp(max=60)], index))
    assert torch.equal(always.train()(index), expected)                  # every own row reads its shared row
    assert torch.equal(always.eval()(index), always.eval()(index))
    assert not torch.equal(always.eval()(index), expected)               # eval mode reads the own rows
    never = cv.TieredEmbedding.from_vocab(vocab, embed_dim=8, replace_rate=0.0)
    assert torch.equal(never.train()(index), never.eval()(index))
    plain = cv.TieredEmbedding(20, 40, 16, embed_dim=8)                  # no fallback given: nothing to replace with
    assert torch.equal(plain.train()(index), plain.eval()(index))
    # At the default rate about one own row in five is replaced, and shared rows learn from kept values.
    some = cv.TieredEmbedding.from_vocab(vocab, embed_dim=8)
    changed = (some.train()(index) != some.eval()(index)).any(dim=1)
    assert not changed[~own].any() and abs(changed[own].float().mean().item() - cv.REPLACE_RATE) < 0.03
    only_own = index[own]
    some.zero_grad()
    some.eval()(only_own).sum().backward()
    assert float(some.wide.weight.grad[21:].abs().sum()) == 0            # in eval mode the shared rows are not read
    some.zero_grad()
    some.train()(only_own).sum().backward()
    assert float(some.wide.weight.grad[21:].abs().sum()) > 0             # in training they are


def test_report_storage_and_the_command_line(tmp_path, capsys):
    """The tier report counts the rows of each tier, a stored vocabulary encodes the same, and the tool prints and writes."""
    df = _table()
    vocab = cv.fit_vocab(df, **SIZES)
    index = cv.encode(df, vocab)
    report = cv.tier_report(index, vocab)
    assert report["tier"].tolist() == ["no value", "full width", "narrow", "shared"]
    assert report["rows"].tolist() == [int((index == 0).sum()), int(((index >= 1) & (index <= 20)).sum()),
                                       int(((index > 20) & (index <= 60)).sum()), int((index > 60).sum())]
    assert np.isclose(report["share"].sum(), 1.0) and report["table_rows"].tolist() == [1, 20, 40, 16]
    path = cv.save_vocab(vocab, str(tmp_path / "vocab.npz"))
    assert np.array_equal(cv.encode(df, cv.load_vocab(path)), index)
    # Without a category column the id alone picks the shared row, and one line says so.
    capsys.readouterr()
    plain = cv.encode(df.drop(columns=[settings.MCC_COL]), vocab)
    assert "no category column" in capsys.readouterr().out
    assert np.array_equal(plain[index <= 60], index[index <= 60]) and (plain[index > 60] > 60).all()
    out = str(tmp_path / "demo.npz")
    table = cv.main(["--demo", "--out", out])
    printed = capsys.readouterr().out
    assert "full width" in printed and "written" in printed and len(table) == 4
    assert len(cv.load_vocab(out)["full_ids"]) == 20
