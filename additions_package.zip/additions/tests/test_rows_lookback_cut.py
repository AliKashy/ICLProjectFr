"""Tests of the look-back mask.

The mask is compared with a slow double loop on made-up chunks, rows of one second are shown
never to see each other, later rows are shown not to change what earlier rows may read, and
the training and scoring behaviour of LookbackCut is checked.
"""
import numpy as np
import pandas as pd
import torch

from additions import settings
from additions.common import synthetic
from additions.training import lookback_cut
from additions.training._loss_shared import account_chunks
from additions.training.lookback_cut import (LookbackCut, available_span_days, default_bounds, draw_lookback_days,
                                             lookback_mask, lookback_mask_numpy)


def _chunks(seed=0, width=12):
    """Made-up chunks of one account each, with many same-second rows."""
    df = synthetic.make_transactions(n_accounts=30, seed=seed, days=120, start="2024-10-01", tie_share=0.15)
    return account_chunks(df, width=width)


def _slow(times, valid, days, include_self=False):
    """The mask written as a double loop over reading row i and read row j."""
    b, t = times.shape
    out = np.zeros((b, t, t), dtype=bool)
    for k in range(b):
        for i in range(t):
            for j in range(t):
                limit = days if np.isscalar(days) or days is None else days[k, i]
                ok = valid[k, i] and valid[k, j] and times[k, j] < times[k, i]
                if limit is not None and np.isfinite(limit):
                    ok = ok and (times[k, i] - times[k, j]) <= limit * 86_400
                out[k, i, j] = ok or (include_self and i == j)
    return out


def test_mask_equals_the_slow_loop_in_torch_and_numpy():
    """For no cut, one cut and a cut per row, both versions equal the double loop."""
    chunks = _chunks()
    times, valid = chunks["times"], chunks["valid"]
    per_row = torch.rand(times.shape, generator=torch.Generator().manual_seed(0), dtype=torch.float64) * 20
    for days in (None, 3.0, per_row):
        limit = days.numpy() if torch.is_tensor(days) else days
        slow = _slow(times.numpy(), valid.numpy(), limit)
        got = lookback_mask(times, valid, days)
        assert got.dtype == torch.bool and got.shape == (*times.shape, times.shape[1])
        assert np.array_equal(got.numpy(), slow)
        as_numpy = days.numpy() if torch.is_tensor(days) else days
        assert np.array_equal(lookback_mask_numpy(times.numpy(), valid.numpy(), as_numpy), slow)
    with_self = lookback_mask(times, valid, 3.0, include_self=True)
    assert np.array_equal(with_self.numpy(), _slow(times.numpy(), valid.numpy(), 3.0, include_self=True))


def test_rows_of_one_second_never_see_each_other():
    """Two real rows that share a whole second are hidden from each other, also with sub-second units."""
    chunks = _chunks(seed=1)
    times, valid = chunks["times"], chunks["valid"]
    allowed = lookback_mask(times, valid, 30.0)
    same = (times.unsqueeze(1) == times.unsqueeze(2)) & valid.unsqueeze(1) & valid.unsqueeze(2)
    assert same.sum() > valid.sum()                       # the made-up chunks hold same-second pairs
    assert not (allowed & same).any()
    # Times in nanoseconds: rows 0.4 s apart in one second stay hidden, rows in the next second do not.
    ns = torch.tensor([[1_000_000_000, 1_400_000_000, 2_000_000_000]])
    m = lookback_mask(ns, torch.ones(1, 3, dtype=torch.bool), time_unit=10**9)
    assert m[0].tolist() == [[False, False, False], [False, False, False], [True, True, False]]


def test_later_rows_do_not_change_what_earlier_rows_read():
    """Cutting a chunk after row k leaves the mask of rows 0..k exactly as it was."""
    chunks = _chunks(seed=2)
    times, valid = chunks["times"], chunks["valid"]
    days = torch.full(times.shape, 10.0, dtype=torch.float64)
    full = lookback_mask(times, valid, days)
    for k in (1, 4, 8):
        short_valid = valid.clone()
        short_valid[:, k + 1:] = False
        part = lookback_mask(times, short_valid, days)
        assert torch.equal(part[:, :k + 1, :k + 1], full[:, :k + 1, :k + 1])
    # A cut only ever removes keys from the plain strict mask.
    assert not (full & ~lookback_mask(times, valid)).any()


def test_draws_bounds_and_span():
    """Drawn look-backs stay inside the bounds, the bounds come from the dates, and the span is the smaller limit."""
    low, high = default_bounds()
    assert (low, high) == (31.0, 61.0)
    assert default_bounds("2025-01-01", "2025-01-11", "2025-01-21") == (10.0, 20.0)
    g1, g2 = torch.Generator().manual_seed(5), torch.Generator().manual_seed(5)
    d = draw_lookback_days((50, 7), generator=g1)
    assert d.shape == (50, 7) and d.min() >= low and d.max() <= high
    assert torch.equal(d, draw_lookback_days((50, 7), generator=g2))
    start = int(pd.Timestamp(settings.TRAIN_HISTORY_START).timestamp())
    times = torch.tensor([[start + 5 * 86_400, start + 50 * 86_400, 0]])
    valid = torch.tensor([[True, True, False]])
    span = available_span_days(times, valid, 31.0)
    assert torch.allclose(span, torch.tensor([[5.0, 31.0, 0.0]]))
    assert torch.allclose(available_span_days(times, valid), torch.tensor([[5.0, 50.0, 0.0]]))


def test_lookback_cut_draws_while_training_and_is_fixed_at_scoring():
    """Training masks differ between draws and are never wider than the strict mask; scoring is repeatable."""
    chunks = _chunks(seed=3)
    times, valid = chunks["times"], chunks["valid"]
    cut = LookbackCut(low_days=2, high_days=6, train_history_start="2024-10-01", eval_history_start="2024-10-01")
    a, span_a = cut(times, valid, training=True, generator=torch.Generator().manual_seed(0))
    b, _ = cut(times, valid, training=True, generator=torch.Generator().manual_seed(1))
    strict = lookback_mask(times, valid)
    assert not torch.equal(a, b) and not (a & ~strict).any() and (a.sum() < strict.sum())
    assert (span_a[valid] <= 6.0).all() and (span_a[~valid] == 0).all()
    s1, sp1 = cut(times, valid, training=False)
    s2, sp2 = cut(times, valid, training=False)
    assert torch.equal(s1, strict) and torch.equal(s1, s2) and torch.equal(sp1, sp2)
    assert (cut.span_input(sp1)[valid] >= 0).all()
    assert lookback_cut.TIME_UNITS_PER_SECOND == 1
