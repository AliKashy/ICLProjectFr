"""Tests of the time encoders (additions/encoding/time_encoders.py).

The gaps must equal a slow loop over rows on random sequences with ties and padding (padding never
counted, rows of one second never measuring to each other, the batch in any order), and later rows
must never change an earlier row's gap or encoding. Every kind of GapEncoder must follow its formula
and stay finite for gaps from 0 to ten years; the calendar must agree with the calendar of the
standard library, repeat after a week and its hour part after a day. The time-gap part of the learned
attention bias must work alone on batches [B, T]: zero while fresh, and once moved it changes only
the pairs the time rule opens. The module must import from a flat folder.

The checks of the build that followed are tested too: float times follow the whole-second rule of
masks.py (floored at any unit, a plain error in 32 or 16 bits), the day of the month is a share of
the month's own length, and the docstrings pass the unit in every call and say what the code does.
"""
import calendar
import inspect
import math
import os
import shutil
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path

import pytest
import torch

from additions.encoding import time_encoders as te
from additions.encoding.numeric_frontend import PiecewiseLinearEmbedding
from additions.model import masks
from additions.model.attention_bias import GAP_EDGES, AttentionBias
from additions.model.history_stage import HistoryStage
from additions.model.interleaved_reread import eligible_rows
from additions.model.latent_channels import LatentChannelStage

HEADS, WIDTH = 4, 16
TEN_YEARS = 10 * 365.25 * 86_400


@pytest.fixture(autouse=True)
def _one_thread():
    """Every test of this file runs on one thread, and the thread count is restored afterwards.

    The blocks here are tiny; several threads competing with other jobs for the same cores can be a
    hundred times slower than one (the reason conftest.py gives for its default of one thread).
    """
    before = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(before)


def _batch(seed=0, lengths=(14, 12, 9, 4, 1, 0), units=1):
    """A padded batch of made-up rows in time order: ties, gaps of seconds to weeks, padding with made-up times.

    Returns (times [B, T], valid [B, T]). Steps of zero put several rows in one second. With `units`
    above 1 every row also gets a fraction of a second, so that rows of one whole second differ in
    their raw times. Padded slots hold huge, negative or zero times, which would count as earlier or
    later than every real row if padding were not kept out; the last sequence is padding only.
    """
    g = torch.Generator().manual_seed(seed)
    B, T = len(lengths), max(lengths)
    choice = torch.randint(0, 3, (B, T), generator=g)
    small = torch.randint(1, 120, (B, T), generator=g)
    large = torch.randint(120, 3_000_000, (B, T), generator=g)
    step = torch.where(choice == 0, torch.zeros_like(small), torch.where(choice == 1, small, large))
    seconds = 1_700_000_000 + torch.cumsum(step, dim=1)
    times = seconds * units
    if units > 1:
        times = times + torch.randint(0, units, (B, T), generator=g)
    valid = torch.arange(T).unsqueeze(0) < torch.tensor(lengths).unsqueeze(1)
    junk = torch.randint(-10 ** 12, 10 ** 12, (B, T), generator=g)
    # One padded slot at time 0, the value a builder usually writes there.
    junk[1, -1] = 0
    return torch.where(valid, times, junk), valid


def _slow_gaps(times, valid, units=1):
    """The gaps with plain Python loops, straight from the definition: whole second of the row minus the latest
    whole second among the real rows of strictly earlier seconds, 0 when there is none."""
    B, T = times.shape
    out = torch.zeros(B, T, dtype=torch.float64)
    for b in range(B):
        for i in range(T):
            if not valid[b, i]:
                continue
            own = int(times[b, i]) // units
            earlier = [int(times[b, j]) // units for j in range(T) if valid[b, j] and int(times[b, j]) // units < own]
            if earlier:
                out[b, i] = own - max(earlier)
    return out


def _moved(module, seed=0):
    """The same module with every weight set to a random number, so that zero starts hide nothing."""
    g = torch.Generator().manual_seed(seed)
    with torch.no_grad():
        for weight in module.parameters():
            weight.copy_(torch.randn(weight.shape, generator=g) * 0.5)
    return module


def _encoders(width=16):
    """Every kind of GapEncoder and a calendar encoder with all three parts, each with moved weights."""
    gap = {kind: _moved(te.GapEncoder(width, kind=kind), seed=n) for n, kind in enumerate(te.KINDS)}
    return gap, _moved(te.CalendarEncoder(width, monthday=True), seed=9)


# ---------------------------------------------------------------------------------------------- the gap

def test_gaps_equal_a_slow_loop_over_rows_with_ties_and_padding():
    """Over several batches, in whole seconds and in milliseconds with fractions: the slow loop, bit for bit."""
    for seed in range(4):
        for units in (1, 1_000):
            times, valid = _batch(seed=seed, units=units)
            fast = te.gap_seconds(times, valid, units_per_second=units)
            assert fast.dtype == torch.float64 and fast.shape == times.shape
            assert torch.equal(fast, _slow_gaps(times, valid, units)), (seed, units)
            # Padding is never counted and never gets a gap of its own.
            assert torch.all(fast[~valid] == 0)
    # The module's own unit is the default, and a whole number given as a float divides exactly.
    times, valid = _batch(seed=5, units=1_000_000_000)
    assert torch.equal(te.gap_seconds(times, valid, units_per_second=1e9), _slow_gaps(times, valid, 1_000_000_000))


def test_rows_of_one_second_never_measure_to_each_other():
    """[10, 20, 20, 30] gives 0, 10, 10, 10: the second row of second 20 measures to second 10, not to its twin."""
    times = torch.tensor([[10, 20, 20, 30], [5, 5, 5, 5], [7, 0, 0, 0]])
    valid = torch.tensor([[True] * 4, [True] * 4, [True, False, False, False]])
    assert te.gap_seconds(times, valid).tolist() == [[0.0, 10.0, 10.0, 10.0], [0.0] * 4, [0.0] * 4]
    # The same rows in milliseconds, all inside their whole seconds: the gap is in whole seconds.
    milli = torch.tensor([[10_999, 20_001, 20_999, 30_500]])
    assert te.gap_seconds(milli, torch.ones(1, 4, dtype=torch.bool), units_per_second=1_000).tolist() == \
        [[0.0, 10.0, 10.0, 10.0]]


def test_the_batch_need_not_be_sorted():
    """Shuffling the slots of every sequence shuffles the gaps with them and changes nothing else."""
    times, valid = _batch(seed=6)
    gaps = te.gap_seconds(times, valid)
    g = torch.Generator().manual_seed(1)
    order = torch.stack([torch.randperm(times.shape[1], generator=g) for _ in range(times.shape[0])])
    shuffled = te.gap_seconds(times.gather(1, order), valid.gather(1, order))
    assert torch.equal(shuffled, gaps.gather(1, order))


def test_later_rows_never_change_an_earlier_row_gap_or_encoding():
    """Cut every sequence after a row, or move its later rows further on: every row up to it keeps its gap, its
    gap vector of every kind and its calendar vector, bit for bit."""
    times, valid = _batch(seed=7)
    gap_encoders, calendar = _encoders()
    g = torch.Generator().manual_seed(2)
    with torch.no_grad():
        gaps = te.gap_seconds(times, valid)
        before = {kind: enc(gaps, valid) for kind, enc in gap_encoders.items()}
        before_clock = calendar(times, valid)
        for b in range(times.shape[0]):
            n = int(valid[b].sum())
            for probe in range(n):
                later = torch.zeros_like(valid)
                later[b, probe + 1:n] = True
                cut_valid = valid & ~later
                cut_times = torch.where(later, torch.randint(-10 ** 9, 10 ** 9, times.shape, generator=g), times)
                moved_times = torch.where(later, times + torch.randint(1, 10 ** 6, times.shape, generator=g), times)
                kept = valid & ~later
                for new_times, new_valid in ((cut_times, cut_valid), (moved_times, valid)):
                    new_gaps = te.gap_seconds(new_times, new_valid)
                    assert torch.equal(new_gaps[kept], gaps[kept]), (b, probe)
                    for kind, enc in gap_encoders.items():
                        assert torch.equal(enc(new_gaps, new_valid)[kept], before[kind][kept]), (b, probe, kind)
                    assert torch.equal(calendar(new_times, new_valid)[kept], before_clock[kept]), (b, probe)


# ---------------------------------------------------------------------------------------------- the encoders

def test_soft_log_is_eight_times_the_log_of_one_plus_an_eighth():
    """8 ln(1 + t / 8) value by value: about t itself for small t, a logarithm for large t."""
    t = torch.tensor([0.0, 0.01, 1.0, 10.0, 3_600.0, TEN_YEARS], dtype=torch.float64)
    expected = torch.tensor([8.0 * math.log(1.0 + v / 8.0) for v in t.tolist()], dtype=torch.float64)
    assert torch.allclose(te.soft_log(t), expected, rtol=1e-12, atol=0)
    assert te.soft_log(0.0) == 0.0 and abs(te.soft_log(0.01) - 0.01) < 1e-5
    assert abs(te.soft_log(TEN_YEARS) - 139.9) < 0.1 and (torch.diff(te.soft_log(t)) > 0).all()


def test_the_scalar_kind_is_the_input_of_the_model_in_use():
    """"scalar" is a learned vector times log(1 + gap in seconds) plus a learned bias, and the default kind."""
    encoder = _moved(te.GapEncoder(WIDTH))
    assert encoder.kind == "scalar"
    gaps = torch.tensor([[0.0, 1.0, 59.0, 86_400.0], [3.0, 0.0, 1e6, TEN_YEARS]], dtype=torch.float64)
    with torch.no_grad():
        expected = torch.log1p(gaps).float().unsqueeze(-1) * encoder.weight + encoder.bias
        assert torch.allclose(encoder(gaps), expected, atol=1e-6, rtol=0)


def test_the_ple_kind_cuts_minutes_to_months_on_the_soft_log_scale():
    """"ple" is the block of numeric_frontend.py on soft_log(gap) with the edges soft_log(GAP_EDGES_SECONDS)."""
    encoder = _moved(te.GapEncoder(WIDTH, kind="ple"))
    edges = [te.soft_log(e) for e in te.GAP_EDGES_SECONDS]
    block = PiecewiseLinearEmbedding([edges], embed_dim=WIDTH)
    with torch.no_grad():
        block.weight.copy_(encoder.bins.weight)
        block.bias.copy_(encoder.bins.bias)
        gaps = torch.tensor([0.0, 5.0, 60.0, 120.0, 3_600.0, 86_400.0, 30 * 86_400.0, 365 * 86_400.0, TEN_YEARS],
                            dtype=torch.float64)
        out = encoder(gaps)
        assert torch.allclose(out, block(te.soft_log(gaps).float().unsqueeze(-1)).squeeze(-2), atol=1e-6, rtol=0)
        # One minute and two minutes read apart; a year and ten years lie beyond the last edge and read alike.
        assert not torch.allclose(out[2], out[3])
        assert torch.equal(out[7], out[8])


def test_the_sinusoid_follows_the_formula_of_the_paper():
    """[sin(theta t); cos(theta t)], theta_i = 1e7 ^ (-2 i / d), t in milliseconds, a layer norm, a gain of 0.01."""
    d = 24
    encoder = _moved(te.GapEncoder(d, kind="sinusoid"))
    gaps = [0.0, 1.0, 2.5, 60.0, 3_600.0, 86_400.0, 3e7]
    with torch.no_grad():
        out = encoder(torch.tensor(gaps, dtype=torch.float64))
    scale, shift = encoder.norm.weight.tolist(), encoder.norm.bias.tolist()
    for n, gap in enumerate(gaps):
        ticks = gap * 1_000.0
        theta = [1e7 ** (-2 * i / d) for i in range(d // 2)]
        wave = [math.sin(f * ticks) for f in theta] + [math.cos(f * ticks) for f in theta]
        mean = sum(wave) / d
        spread = math.sqrt(sum((v - mean) ** 2 for v in wave) / d + 1e-5)
        expected = [0.01 * ((v - mean) / spread * a + c) for v, a, c in zip(wave, scale, shift)]
        assert max(abs(x - y) for x, y in zip(out[n].tolist(), expected)) < 1e-6, gap


def test_every_encoder_is_finite_for_gaps_from_zero_to_ten_years():
    """Every kind at widths 48, 96 and 144, and the calendar over ten years of times: finite values and gradients."""
    gaps = torch.cat([torch.tensor([0.0, 0.25, 1.0, 9.0, 60.0, 3_600.0, 86_400.0, 90 * 86_400.0, TEN_YEARS],
                                   dtype=torch.float64),
                      torch.logspace(0, math.log10(TEN_YEARS), 200, dtype=torch.float64)]).view(1, -1)
    for width in (48, 96, 144):
        for kind in te.KINDS:
            encoder = te.GapEncoder(width, kind=kind)
            out = encoder(gaps)
            assert out.shape == (1, gaps.shape[1], width) and bool(torch.isfinite(out).all()), (width, kind)
            out.square().sum().backward()
            assert all(bool(torch.isfinite(w.grad).all()) for w in encoder.parameters()), (width, kind)
        calendar = _moved(te.CalendarEncoder(width, monthday=True))
        start = 1_767_225_600
        times = torch.cat([start + gaps.long(), start - gaps.long(), gaps.long()], dim=0)
        out = calendar(times)
        assert out.shape == (3, gaps.shape[1], width) and bool(torch.isfinite(out).all()), width
        out.square().sum().backward()
        assert all(bool(torch.isfinite(w.grad).all()) for w in calendar.parameters()), width


def test_a_fresh_calendar_encoder_adds_nothing_and_still_learns():
    """The second layer starts at zero: the vector is zero, and that layer gets a gradient at once."""
    calendar = te.CalendarEncoder(WIDTH)
    times = _batch(seed=8)[0].clamp(min=0)
    out = calendar(times)
    assert torch.all(out == 0)
    (out * torch.randn(out.shape)).sum().backward()
    assert float(calendar.second.weight.grad.abs().sum()) > 0


def test_padded_rows_get_nothing():
    """With `valid` given, padded rows read zero whatever their gap or time; real rows are unchanged."""
    times, valid = _batch(seed=9)
    gaps = te.gap_seconds(times, valid)
    gap_encoders, calendar = _encoders()
    with torch.no_grad():
        for enc in gap_encoders.values():
            with_mask, without = enc(gaps, valid), enc(gaps)
            assert torch.all(with_mask[~valid] == 0) and torch.equal(with_mask[valid], without[valid])
        with_mask, without = calendar(times, valid), calendar(times)
        assert torch.all(with_mask[~valid] == 0) and torch.equal(with_mask[valid], without[valid])


# ---------------------------------------------------------------------------------------------- the calendar

def test_calendar_parts_agree_with_the_calendar_of_the_standard_library():
    """The second of the day, of the week (Monday 00:00 is 0) and the day of the month, from 1900 to 2100,
    leap days and times before 1970 included."""
    g = torch.Generator().manual_seed(10)
    seconds = torch.randint(-2_208_988_800, 4_102_444_800, (3_000,), generator=g)
    # Around 29 February 2000 and 2024, 1 March 1900 (no leap day), and the first seconds around the epoch.
    marks = torch.tensor([951_782_400, 951_868_799, 951_868_800, 1_709_164_800, 1_709_251_200, -2_203_891_200,
                          -2_203_891_201, -1, 0, 86_399, 86_400])
    seconds = torch.cat([seconds, marks])
    day, week, month_day = te.calendar_parts(seconds, offset_seconds=0, units_per_second=1)
    for s, d, w, m in zip(seconds.tolist(), day.tolist(), week.tolist(), month_day.tolist()):
        when = datetime(1970, 1, 1) + timedelta(seconds=s)
        assert d == when.hour * 3_600 + when.minute * 60 + when.second, s
        assert w == when.weekday() * 86_400 + d, s
        assert m == when.day, s
    # The unit of the batch and the offset to the local clock: milliseconds with fractions read their whole second,
    # and an offset of one hour reads as the time one hour later.
    milli = te.calendar_parts(seconds * 1_000 + 999, offset_seconds=0, units_per_second=1_000)
    assert all(torch.equal(a, b) for a, b in zip(milli, (day, week, month_day)))
    shifted = te.calendar_parts(seconds, offset_seconds=3_600, units_per_second=1)
    later = te.calendar_parts(seconds + 3_600, offset_seconds=0, units_per_second=1)
    assert all(torch.equal(a, b) for a, b in zip(shifted, later))


def test_the_calendar_repeats_after_a_week_and_its_hour_part_after_a_day():
    """Times one week apart give the same vector; with the hour alone, times one day apart do too."""
    times, valid = _batch(seed=11)
    times = times.clamp(min=0)
    week, day = 7 * 86_400, 86_400
    calendar = _moved(te.CalendarEncoder(WIDTH))                        # hour of the day and day of the week
    hour_only = _moved(te.CalendarEncoder(WIDTH, weekday=False), seed=3)
    with torch.no_grad():
        assert torch.equal(calendar(times), calendar(times + week))
        assert torch.equal(hour_only(times), hour_only(times + day))
        # The day of the week moves with a day; within the features the hour part repeats and the weekday part not.
        assert not torch.allclose(calendar(times), calendar(times + day))
        h = 2 * calendar.harmonics
        now, next_day = calendar.features(times), calendar.features(times + day)
        assert torch.equal(now[..., :h], next_day[..., :h]) and not torch.allclose(now[..., h:], next_day[..., h:])
    # The day of the month is a share of the month's own length: the 5th of January and the 5th of March, months of
    # 31 days, at the same hour read the same; the 5th and the 6th do not.
    monthday = _moved(te.CalendarEncoder(WIDTH, hour=False, weekday=False, monthday=True), seed=4)
    jan5, mar5 = 1_767_571_200 + 13 * 3_600, 1_772_668_800 + 13 * 3_600
    with torch.no_grad():
        assert torch.equal(monthday(torch.tensor([jan5])), monthday(torch.tensor([mar5])))
        assert not torch.allclose(monthday(torch.tensor([jan5])), monthday(torch.tensor([jan5 + day])))


def test_a_row_offset_reads_each_row_on_its_own_clock():
    """An offset per row equals the time moved by that offset, row by row."""
    times, _ = _batch(seed=12)
    times = times.clamp(min=0)
    offsets = torch.randint(-12, 13, times.shape, generator=torch.Generator().manual_seed(5)) * 3_600
    calendar = _moved(te.CalendarEncoder(WIDTH, monthday=True))
    with torch.no_grad():
        assert torch.equal(calendar(times, offset_seconds=offsets), calendar(times + offsets))


# ---------------------------------------------------------------------------------------------- the attention bias

def test_the_time_gap_part_of_the_attention_bias_works_alone_on_batches_of_rows():
    """AttentionBias with no match field, on [B, T] batches: zero while fresh; once moved, every open pair carries
    the weight of its time-gap bucket, closed pairs stay closed, and a row that may read only itself keeps its
    result through stage 2."""
    times, valid = _batch(seed=13)
    B, T = times.shape
    block = AttentionBias(num_fields=0, num_heads=HEADS, units_per_second=1)
    no_codes = torch.zeros(B, T, 0, dtype=torch.long)
    fresh = block(no_codes, times, valid)
    assert fresh.shape == (B, HEADS, T, T) and torch.all(fresh == 0)
    _moved(block, seed=6)
    with torch.no_grad():
        bias = block(no_codes, times, valid)
    allowed = masks.strict_visibility(times, valid)                                # [B, T, T]
    # Every open pair: the weight of its bucket, or the weight of a row reading itself on the diagonal.
    for b in range(B):
        for i in range(T):
            for j in range(T):
                if not allowed[b, i, j]:
                    continue
                if i == j:
                    expected = block.self_weight.detach()
                else:
                    gap = int(times[b, i] - times[b, j])
                    expected = block.gap_weight.detach()[:, sum(1 for e in GAP_EDGES if gap >= e)]
                assert torch.equal(bias[b, :, i, j], expected), (b, i, j)
    # The attention of every head: a closed pair gets nothing with or without the bias, and only open pairs change.
    mask = masks.to_attention_mask(allowed, HEADS).view(B, HEADS, T, T)
    plain, biased = torch.softmax(mask, dim=-1), torch.softmax(mask + bias, dim=-1)
    closed = ~allowed.unsqueeze(1).expand_as(plain)
    assert torch.all(plain[closed] == 0) and torch.all(biased[closed] == 0)
    alone = allowed.sum(dim=-1) == 1                                               # [B, T]: reads only itself
    assert not torch.allclose(plain[~alone.unsqueeze(1).expand(B, HEADS, T)],
                              biased[~alone.unsqueeze(1).expand(B, HEADS, T)])
    # Through stage 2: the bias moves the rows that read history and leaves the rows that may read only themselves.
    torch.manual_seed(0)
    stage2 = HistoryStage(in_dim=WIDTH, num_heads=HEADS, num_blocks=2, history_len=8, dropout=0.0,
                          attn_dropout=0.0).eval()
    x = torch.randn(B, T, WIDTH)
    with torch.no_grad():
        without, with_bias = stage2(x, times, valid), stage2(x, times, valid, bias=bias)
    readers = valid & ~(eligible_rows(times, valid).sum(dim=-1) == 0)
    assert torch.allclose(without[valid & ~readers], with_bias[valid & ~readers], atol=1e-6, rtol=0)
    assert not torch.allclose(without[readers], with_bias[readers], atol=1e-4)
    # A later row changes no earlier row's result with the bias in place: cut every sequence after its middle row.
    real = valid.sum(dim=1)
    later = valid & (torch.arange(T).unsqueeze(0) > (real // 2).unsqueeze(1))
    cut_valid, cut_times = valid & ~later, torch.where(later, torch.zeros_like(times), times)
    with torch.no_grad():
        cut = stage2(x, cut_times, cut_valid, bias=block(no_codes, cut_times, cut_valid))
    kept = valid & ~later
    assert torch.allclose(cut[kept], with_bias[kept], atol=1e-6, rtol=0)


# ---------------------------------------------------------------------------------------------- errors and import

def test_settings_that_cannot_work_give_a_plain_error_that_says_what_to_change():
    """An unknown kind, an odd width for the sinusoid, edges that go down, a calendar with nothing switched on."""
    with pytest.raises(ValueError, match="kind must be one of"):
        te.GapEncoder(WIDTH, kind="rotary")
    with pytest.raises(ValueError, match="token_dim=16"):
        te.GapEncoder(15, kind="sinusoid")
    with pytest.raises(ValueError, match="increasing"):
        te.GapEncoder(WIDTH, kind="ple", edges_seconds=(0, 60, 30))
    with pytest.raises(ValueError, match="switch one on"):
        te.CalendarEncoder(WIDTH, hour=False, weekday=False)


# Run in a fresh interpreter inside a folder that holds copies of the files: pandas, scipy and scikit-learn are made
# unimportable first, and the folder that holds `additions/` is not on the path, so the files reach each other through
# the last branch of their imports.
FLAT_RUN = """
import runpy
import sys
for name in ("pandas", "scipy", "sklearn"):
    sys.modules[name] = None
runpy.run_path("time_encoders.py", run_name="__main__")
assert "additions" not in sys.modules, "the package was imported"
"""


def test_the_module_runs_from_a_flat_folder(tmp_path):
    """Copied next to interleaved_reread.py, masks.py, numeric_encoders.py and numeric_frontend.py into a folder of
    their own, with no path to the package and with pandas, scipy and scikit-learn unimportable, the module imports
    and its demo runs."""
    encoding = Path(te.__file__).parent
    model = encoding.parent / "model"
    for source in (encoding / "time_encoders.py", encoding / "numeric_encoders.py", encoding / "numeric_frontend.py",
                   model / "interleaved_reread.py", model / "masks.py"):
        shutil.copy(source, tmp_path / source.name)
    env = {name: value for name, value in os.environ.items() if name != "PYTHONPATH"}
    env.update(OMP_NUM_THREADS="1", MKL_NUM_THREADS="1")
    result = subprocess.run([sys.executable, "-c", FLAT_RUN], cwd=tmp_path, env=env, capture_output=True, text=True,
                            timeout=600)
    assert result.returncode == 0, result.stderr
    assert "gaps in seconds: [[0, 5, 5, 4, 11, 11, 1, 19, 1], [0, 0, 1, 4, 1, 3, 0, 0, 0]]" in result.stdout
    assert result.stdout.count("finite: True") == 4


# ---------------------------------------------------------------------------------------------- the later checks

def test_float_times_follow_the_whole_second_rule_of_the_package():
    """64-bit float times are floored to their whole second at any unit, as masks.whole_seconds and the mask of stage 2
    floor them; times in 32-bit or 16-bit floats are a plain error; a whole unit written as a float is exact."""
    valid = torch.ones(1, 4, dtype=torch.bool)
    floats = torch.tensor([[100.2, 100.7, 101.5, 161.9]], dtype=torch.float64)
    assert te.gap_seconds(floats, valid, units_per_second=1).tolist() == [[0.0, 0.0, 1.0, 60.0]]
    # The same rows as the rule of the package reads them: the rows of one whole second never read each other.
    assert torch.equal(eligible_rows(floats, valid, 1), eligible_rows(torch.tensor([[100, 100, 101, 161]]), valid, 1))
    day, week, month_day = te.calendar_parts(floats, offset_seconds=0, units_per_second=1)
    assert day.tolist() == [[100, 100, 101, 161]] and month_day.tolist() == [[1, 1, 1, 1]]
    # Nanoseconds as 64-bit floats, with the unit as an int and as a float, read the seconds of the int64 times.
    whole = torch.tensor([[1_767_225_600, 1_767_225_601, 1_767_225_661, 1_767_229_261]])
    nanos = whole * 1_000_000_000 + 250_000_000
    for unit in (1_000_000_000, 1e9):
        assert te.gap_seconds(nanos, valid, units_per_second=unit).tolist() == [[0.0, 1.0, 60.0, 3_600.0]]
        assert torch.equal(te.calendar_parts(nanos, 0, unit)[0], te.calendar_parts(whole, 0, 1)[0])
    # 32-bit and 16-bit floats cannot hold a time of today to the second: a plain error that names int64, from the
    # gap, from the calendar and from the encoder alike, where they used to give gaps of 0, 0, 0 and 3,712.
    calendar_encoder = te.CalendarEncoder(WIDTH, units_per_second=1)
    for dtype in (torch.float32, torch.float16, torch.bfloat16):
        short = whole.to(dtype)
        for call in (lambda: te.gap_seconds(short, valid, units_per_second=1),
                     lambda: te.calendar_parts(short, 0, 1), lambda: calendar_encoder(short)):
            with pytest.raises(ValueError, match="int64"):
                call()


def test_the_day_of_the_month_is_a_share_of_the_month_s_own_length():
    """The monthday feature is (day - 1 + second of the day / 86,400) / days of that month, against the calendar of the
    standard library from 1900 to 2100; the last second of every month reads the same phase, the next second 0."""
    encoder = te.CalendarEncoder(8, hour=False, weekday=False, monthday=True, harmonics=1, units_per_second=1)

    def share(times):
        sine, cosine = encoder.features(times).double().unbind(-1)
        return torch.remainder(torch.atan2(sine, cosine) / (2.0 * math.pi), 1.0)

    g = torch.Generator().manual_seed(14)
    seconds = torch.randint(-2_208_988_800, 4_102_444_800, (2_000,), generator=g)
    got = share(seconds)
    for s, value in zip(seconds.tolist(), got.tolist()):
        when = datetime(1970, 1, 1) + timedelta(seconds=s)
        length = calendar.monthrange(when.year, when.month)[1]
        expected = (when.day - 1 + (when.hour * 3_600 + when.minute * 60 + when.second) / 86_400) / length
        # Up to the rounding of sines in 32 bits, and on either side of the turn from 1 to 0.
        assert min(abs(value - expected), 1.0 - abs(value - expected)) < 1e-6, (when, value, expected)
    ends = []
    for year, month in ((2026, 1), (2026, 2), (2024, 2), (2026, 4), (1900, 2), (2000, 2)):
        last = calendar.monthrange(year, month)[1]
        end = int((datetime(year, month, last, 23, 59, 59) - datetime(1970, 1, 1)).total_seconds())
        before, after = share(torch.tensor([end, end + 1])).tolist()
        ends.append(before)
        assert after < 1e-9 or after > 1.0 - 1e-9
    # The last second of every month sits at the end of the cycle, whatever the length of the month.
    assert max(ends) - min(ends) < 1e-5 and min(ends) > 0.99999


def test_the_docstrings_pass_the_unit_and_say_what_the_code_does():
    """Every call in the docstrings that reads raw times names its unit; the stage is said to take `bias=` (which
    it does); the gap bins are given their real widths in soft-log units; the default sinusoid is called
    paper-faithful with ticks_per_second=1 as the arm beside it; and the example of ties by the full timestamp is what
    gap_seconds gives."""
    docs = "\n".join(text for text in (te.__doc__, te.gap_seconds.__doc__, te.calendar_parts.__doc__,
                                         te.GapEncoder.__doc__, te.CalendarEncoder.__doc__) if text)
    calls = [line for line in docs.splitlines()
             if any(f"{name}(" in line for name in ("gap_seconds", "calendar_parts", "AttentionBias"))
             or "CalendarEncoder(1" in line]
    assert len(calls) >= 6 and all("units_per_second" in line for line in calls), calls
    flat = " ".join(te.__doc__.split())
    assert "does not take it yet" not in flat
    assert "LatentChannelStage of latent_channels.py takes the same tensor as `bias=`" in flat
    assert "bias" in inspect.signature(LatentChannelStage.forward).parameters
    # The bins of "ple" in soft-log units: the smallest and the largest width, as the docstring gives them.
    edges = [te.soft_log(e) for e in te.GAP_EDGES_SECONDS]
    widths = [b - a for a, b in zip(edges, edges[1:])]
    assert f"{min(widths):.1f} to {max(widths):.1f} soft-log units wide" in " ".join(te.GapEncoder.__doc__.split())
    assert "paper-faithful" in flat and "ticks_per_second=1" in flat and "the arm to run beside" in flat
    # Ties by the whole second: times 10.0, 20.2, 20.7 and 30.0 s give 0, 10, 10 and 10.
    nanos = torch.tensor([[10_000_000_000, 20_200_000_000, 20_700_000_000, 30_000_000_000]])
    gaps = te.gap_seconds(nanos, torch.ones(1, 4, dtype=torch.bool), units_per_second=1_000_000_000)
    assert gaps.tolist() == [[0.0, 10.0, 10.0, 10.0]]
    assert "times 10.0, 20.2, 20.7 and 30.0 s give 0, 10, 10 and 10 here" in flat


def test_the_gap_bins_keep_their_edges_in_32_bits_under_a_16_bit_cast():
    """GapEncoder "ple" rounded its edges, soft logs of up to about 50, under a cast of the module to bfloat16: a token
    error of 0.03 of the largest token. Its edges now stay in float32 and the soft log and the shares are formed in
    32 bits; only the shares take the 16-bit type, as in numeric_encoders.py. At width 16 the error was 0.020 in bfloat16
    and 0.0013 in float16, and is now 0.0032 and 0.00047."""
    torch.manual_seed(0)
    encoder = te.GapEncoder(WIDTH, kind="ple")
    gaps = torch.tensor([0.0, 3.0, 45.0, 400.0, 7_000.0, 90_000.0, 2e6, 9e6])
    with torch.no_grad():
        full = encoder(gaps)
        for dtype, bound in ((torch.bfloat16, 0.012), (torch.float16, 0.001)):
            low = te.GapEncoder(WIDTH, kind="ple")
            low.load_state_dict(encoder.state_dict())
            low = low.to(dtype)
            assert low.bins.left.dtype == torch.float32 and low.bins.width.dtype == torch.float32, dtype
            assert low.bins.weight.dtype == dtype and low.bins.bias.dtype == dtype, dtype
            error = float((low(gaps).float() - full).abs().max() / full.abs().max())
            assert error < bound, (dtype, error)
