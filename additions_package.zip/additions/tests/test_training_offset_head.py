"""Tests of the offset head.

They check that a zero head leaves the other model's own loss, that no gradient reaches the
other model's score, that the gradient on head B's output is the probability minus the
label, and that the ramp and the cap behave as stated.
"""
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

from additions import settings
from additions.common import synthetic
from additions.training import offset_head
from additions.training.offset_head import OffsetHead, export_columns, offset_log_odds, offset_loss, two_head_loss


def _rows(seed=0):
    """Made-up rows: labels, the other model's log-odds (a few missing) and row vectors."""
    df = synthetic.make_scores(synthetic.make_transactions(n_accounts=80, seed=seed, fraud_account_share=0.4),
                               seed=seed)
    offset = torch.tensor(offset_log_odds(df[settings.SCORE_COL].to_numpy(), kind="probability"))
    offset[::17] = float("nan")
    labels = torch.tensor(df[settings.LABEL_COL].to_numpy(), dtype=torch.float64)
    vectors = torch.randn(len(df), 12, generator=torch.Generator().manual_seed(seed), dtype=torch.float64)
    return df, offset, labels, vectors


def test_a_zero_head_gives_the_loss_of_the_offset_alone():
    """At the start head B outputs zero, so its loss is the other model's own cross-entropy on the scored rows."""
    _, offset, labels, vectors = _rows()
    head = OffsetHead(dim=12).double()
    logit_b = head(vectors)
    assert logit_b.shape == labels.shape and torch.equal(logit_b, torch.zeros_like(logit_b))
    has = torch.isfinite(offset)
    alone = F.binary_cross_entropy_with_logits(offset[has], labels[has])
    assert torch.isclose(offset_loss(logit_b, offset, labels), alone)


def test_no_gradient_reaches_the_other_models_score():
    """The offset is data: after backward it holds no gradient, while head B's output does."""
    _, offset, labels, _ = _rows(seed=1)
    offset = offset.clone().requires_grad_(True)
    logit_b = torch.zeros_like(labels, requires_grad=True)
    offset_loss(logit_b, offset, labels).backward()
    assert offset.grad is None
    assert logit_b.grad is not None and logit_b.grad.abs().sum() > 0


def test_gradient_on_head_b_is_probability_minus_label():
    """Per scored row the gradient is sigmoid(offset + head B) - label over the scored rows; zero elsewhere."""
    _, offset, labels, _ = _rows(seed=2)
    logit_b = (0.3 * torch.randn(len(labels), dtype=torch.float64)).requires_grad_(True)
    offset_loss(logit_b, offset, labels).backward()
    has = torch.isfinite(offset)
    expected = torch.where(has, torch.sigmoid(torch.nan_to_num(offset) + logit_b.detach()) - labels,
                           torch.zeros_like(labels)) / has.sum()
    assert torch.allclose(logit_b.grad, expected)


def test_infinite_or_missing_offsets_are_left_out_without_spoiling_the_loss():
    """A row with an infinite or missing offset adds nothing, and the loss and gradient stay finite."""
    labels = torch.tensor([1.0, 0.0, 1.0, 0.0])
    offset = torch.tensor([float("inf"), float("-inf"), float("nan"), -2.0])
    logit_b = torch.zeros(4, requires_grad=True)
    loss = offset_loss(logit_b, offset, labels)
    loss.backward()
    assert torch.isclose(loss, F.binary_cross_entropy_with_logits(torch.tensor(-2.0), torch.tensor(0.0)))
    assert torch.isfinite(logit_b.grad).all() and (logit_b.grad[:3] == 0).all()
    assert offset_loss(logit_b, torch.full((4,), float("nan")), labels).item() == 0.0


def test_offset_log_odds_reads_probabilities_and_log_odds_and_skips_a_missing_column(capsys):
    """Probabilities become clipped log-odds, log-odds pass through, and an absent column gives missing values."""
    p = np.array([0.5, 0.9, 0.0, 1.0, np.nan])
    got = offset_log_odds(p, kind="probability")
    assert np.isclose(got[0], 0.0) and np.isclose(got[1], np.log(9.0))
    assert got[2] == -offset_head.OFFSET_LIMIT and got[3] == offset_head.OFFSET_LIMIT and np.isnan(got[4])
    assert np.allclose(offset_log_odds(np.array([-1.0, 3.0]), kind="logit"), [-1.0, 3.0])
    table = pd.DataFrame({"their_score": [0.5, 0.2]})
    assert np.allclose(offset_log_odds(table, score_col="their_score", kind="probability"), [0.0, np.log(0.25)])
    missing = offset_log_odds(table)
    assert np.isnan(missing).all() and len(missing) == 2
    assert "head B gets no loss" in capsys.readouterr().out


def test_two_head_loss_ramps_in_and_is_capped():
    """Before the start only the main loss counts; once on, head B adds at most the main loss times its weight."""
    main, small, large = torch.tensor(0.2), torch.tensor(0.05), torch.tensor(3.0)
    assert torch.isclose(two_head_loss(main, large, step=5, start_step=10, ramp_steps=10), main)
    assert torch.isclose(two_head_loss(main, small, step=15, start_step=10, ramp_steps=10), main + 0.5 * small)
    assert torch.isclose(two_head_loss(main, large, step=None), main + main)
    assert torch.isclose(two_head_loss(main, large, step=None, weight=0.5), main + 0.5 * main)


def test_export_columns_hold_head_b_and_the_combined_log_odds():
    """The export carries head B's output and, with an offset, the sum of the two."""
    logit_b = torch.tensor([0.5, -1.0, 2.0])
    offset = torch.tensor([1.0, float("nan"), -3.0])
    columns = export_columns(logit_b, offset)
    assert np.allclose(columns["head_b_logit"], [0.5, -1.0, 2.0])
    combined = columns["head_b_combined_logit"]
    assert np.isclose(combined[0], 1.5) and np.isnan(combined[1]) and np.isclose(combined[2], -1.0)
    assert set(export_columns(logit_b)) == {"head_b_logit"}


def test_training_head_b_moves_the_vector_toward_what_the_offset_misses():
    """A few steps on head B lower its loss and, once the layer moves, gradient reaches the row vectors."""
    _, offset, labels, vectors = _rows(seed=3)
    head = OffsetHead(dim=12).double()
    optimiser = torch.optim.SGD(head.parameters(), lr=0.5)
    first = offset_loss(head(vectors), offset, labels).item()
    for _ in range(30):
        optimiser.zero_grad()
        offset_loss(head(vectors), offset, labels).backward()
        optimiser.step()
    shared = vectors.clone().requires_grad_(True)
    loss = offset_loss(head(shared), offset, labels)
    loss.backward()
    assert loss.item() < first
    assert torch.isfinite(shared.grad).all() and shared.grad.abs().sum() > 0
