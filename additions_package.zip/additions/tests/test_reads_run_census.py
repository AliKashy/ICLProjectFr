"""Tests of the run census.

The per-fraud table is compared with a walk through the frauds of each account in time order,
the time rule is checked on frauds that share a second, and the summary tables are checked
against plain counts.
"""
import numpy as np
import pandas as pd
import pytest

from additions import settings
from additions.common import ranking, synthetic, tables, timekeys
from additions.reads import _rows, run_census

STANDARD = [settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL, settings.LABEL_COL, settings.AMOUNT_COL,
            settings.SCORE_COL]


@pytest.fixture(scope="module")
def table():
    """Made-up rows with fraud runs and with extra frauds scattered over the two months."""
    df = synthetic.make_transactions(n_accounts=150, seed=4, fraud_account_share=0.3, tie_share=0.1)
    rng = np.random.default_rng(4)
    plain = np.flatnonzero(_rows.row_type(df) == "approved")
    df.loc[rng.choice(plain, 300, replace=False), settings.LABEL_COL] = 1     # gaps of every length
    return synthetic.make_scores(df, seed=4, strength=1.5)


def _frame(rows):
    """A tiny table from (account, second, label) tuples, with the column names of settings and no score."""
    start = pd.Timestamp(settings.TARGET_START)
    return pd.DataFrame({
        settings.ID_COL: np.arange(len(rows)),
        settings.ACCOUNT_COL: [r[0] for r in rows],
        settings.TIME_COL: [start + pd.Timedelta(seconds=r[1]) for r in rows],
        settings.LABEL_COL: [r[2] for r in rows],
    })


def _slow_runs(df, run_gap):
    """Run, position and gap of every fraud, found by walking through each account's fraud seconds."""
    account = df[settings.ACCOUNT_COL].to_numpy()
    secs = timekeys.seconds(df[settings.TIME_COL])
    is_fraud = df[settings.LABEL_COL].to_numpy() == 1
    out = {}
    for name in np.unique(account[is_fraud]):
        rows = np.flatnonzero(is_fraud & (account == name))
        seconds = sorted(set(secs[rows].tolist()))
        run, earlier_in_run = -1, 0
        for j, second in enumerate(seconds):
            gap = np.nan if j == 0 else second - seconds[j - 1]
            if j == 0 or gap > run_gap:                      # a long gap opens a new run
                run, earlier_in_run = run + 1, 0
            here = rows[secs[rows] == second]
            for i in here:                                   # frauds of one second share everything
                out[df[settings.ID_COL].iloc[i]] = ((name, run), earlier_in_run + 1, gap)
            earlier_in_run += len(here)
    return out


def test_runs_match_a_walk_through_each_account(table):
    """Run membership, position, run size and the gap to the previous fraud agree with the slow walk."""
    fast = run_census.fraud_runs(table)
    slow = _slow_runs(table, run_census.RUN_GAP)
    assert len(fast) == len(slow) == (table[settings.LABEL_COL] == 1).sum()
    slow_run = [slow[i][0] for i in fast["id"]]
    assert fast["position"].tolist() == [slow[i][1] for i in fast["id"]]
    gaps = np.array([slow[i][2] for i in fast["id"]], dtype=float)
    assert np.array_equal(fast["seconds_since_previous"].to_numpy(), gaps, equal_nan=True)
    # The run numbers differ from the slow names, but they must split the frauds in the same way.
    pairs = set(zip(fast["run"].tolist(), slow_run))
    assert len(pairs) == fast["run"].nunique() == len(set(slow_run))
    sizes = pd.Series(slow_run).map(pd.Series(slow_run).value_counts())
    assert fast["run_size"].tolist() == sizes.tolist()
    assert fast["run_size"].max() > 1 and fast.groupby("account")["run"].nunique().max() > 1
    # A shorter gap splits runs further; no run grows.
    tight = run_census.fraud_runs(table, run_gap=3_600)
    assert tight["run"].nunique() > fast["run"].nunique() and (tight["run_size"] <= fast["run_size"]).all()


def test_frauds_of_one_second_share_their_place_in_the_run(capsys):
    """Frauds in the same second get the same position and gap, and a long gap starts a new run."""
    df = _frame([("a", 0, 1), ("a", 50, 1), ("a", 50, 1), ("a", 90, 1), ("a", 90 + 8 * 86_400, 1), ("b", 50, 1),
                 ("a", 60, 0)])
    runs = run_census.fraud_runs(df)
    assert "no score column" in capsys.readouterr().out and runs["inside_cut"].isna().all()
    assert runs["position"].tolist() == [1, 2, 2, 4, 1, 1]
    assert runs["run_size"].tolist() == [4, 4, 4, 4, 1, 1]
    assert runs["run"].tolist()[:4] == [runs["run"].iloc[0]] * 4 and runs["run"].nunique() == 3
    expected = [np.nan, 50.0, 50.0, 40.0, 8.0 * 86_400, np.nan]
    assert np.array_equal(runs["seconds_since_previous"].to_numpy(), np.array(expected), equal_nan=True)


def test_later_rows_do_not_change_the_place_of_earlier_frauds(table):
    """Cutting the table off at a point in time leaves position and gap of every earlier fraud as they were."""
    secs = timekeys.seconds(table[settings.TIME_COL])
    keep = secs <= np.median(secs)
    full = run_census.fraud_runs(table).set_index("id")
    part = run_census.fraud_runs(table[keep].reset_index(drop=True)).set_index("id")
    same = full.loc[part.index]
    assert part["position"].tolist() == same["position"].tolist()
    assert np.array_equal(part["seconds_since_previous"].to_numpy(), same["seconds_since_previous"].to_numpy(),
                          equal_nan=True)
    assert (part["run_size"] <= same["run_size"]).all()      # only the run size can still grow


def test_summary_tables_are_plain_counts_of_the_fraud_lines(table):
    """Every scored fraud is in exactly one line of each split, and capture is the share inside the cut."""
    runs = run_census.fraud_runs(table)
    scored = runs[runs["scored"]]
    logit = ranking.to_logit(table[settings.SCORE_COL])
    ranked = _rows.in_scored_month(table)
    inside = logit >= np.sort(logit[ranked])[-ranking.cut_size(int(ranked.sum()))]
    by_id = pd.Series(inside, index=table[settings.ID_COL].to_numpy())
    assert (runs["inside_cut"] == by_id.reindex(runs["id"]).to_numpy()).all()

    first = run_census.first_and_follow_on(runs).set_index("part")
    assert first.loc["first of its run", "frauds"] == (scored["position"] == 1).sum()
    assert first.loc["follow-on", "frauds"] == (scored["position"] > 1).sum()
    assert first.loc["all", "frauds"] == len(scored) == first.loc[["first of its run", "follow-on"], "frauds"].sum()
    assert np.isclose(first.loc["follow-on", "capture"], scored.loc[scored["position"] > 1, "inside_cut"].mean())
    assert np.isclose(first.loc["all", "caught"], scored["inside_cut"].sum())

    gaps = run_census.gap_table(runs).set_index("part")
    since = scored["seconds_since_previous"]
    assert gaps.loc["no earlier fraud", "frauds"] == since.isna().sum()
    assert gaps.loc["under 1 hour", "frauds"] == (since < 3_600).sum()
    assert gaps.loc["7 to 30 days", "frauds"] == ((since >= 7 * 86_400) & (since < 30 * 86_400)).sum()
    assert np.isclose(gaps.drop("all")["share_of_frauds"].sum(), 1.0) and gaps.loc["7 to 30 days", "frauds"] > 0

    sizes = run_census.run_sizes(runs)
    assert sizes["frauds"].sum() == len(runs) and sizes["runs"].sum() == runs["run"].nunique()
    assert np.isclose(sizes["share_of_runs"].sum(), 1.0) and np.isclose(sizes["share_of_frauds"].sum(), 1.0)
    assert sizes.loc[0, "runs"] == (runs.groupby("run")["run_size"].first() == 1).sum()

    old = run_census.old_previous_share(runs).iloc[0]
    assert old["previous_older_than_limit"] == (since > 30 * 86_400).sum() and old["frauds"] == len(scored)
    assert np.isclose(old["share_of_follow_ups"], (since > 30 * 86_400).sum() / since.notna().sum())
    hour = run_census.old_previous_share(runs, old_gap=3_600).iloc[0]
    assert hour["previous_older_than_limit"] == (since > 3_600).sum()


def test_daily_fraud_rate_matches_a_count_per_day(table):
    """Rows and frauds per calendar day equal a plain group-by, and the trend compares the ends of the month."""
    daily = run_census.daily_fraud_rate(table)
    day = pd.to_datetime(table[settings.TIME_COL]).dt.strftime("%Y-%m-%d")
    slow = table.groupby(day)[settings.LABEL_COL].agg(["size", "sum"])
    assert daily["day"].tolist() == slow.index.tolist()
    assert daily["rows"].tolist() == slow["size"].tolist() and daily["frauds"].tolist() == slow["sum"].tolist()
    assert np.allclose(daily["frauds_per_10000"], 10_000.0 * slow["sum"].to_numpy() / slow["size"].to_numpy())
    trend = run_census.rate_trend(daily).iloc[0]
    month = daily[(daily["day"] >= settings.TARGET_START) & (daily["day"] < settings.TARGET_END)]
    first, last = month.head(7), month.tail(7)
    assert np.isclose(trend["first_days_rate"], 10_000.0 * first["frauds"].sum() / first["rows"].sum())
    assert np.isclose(trend["last_days_rate"], 10_000.0 * last["frauds"].sum() / last["rows"].sum())
    assert np.isclose(trend["ratio"], trend["last_days_rate"] / trend["first_days_rate"])
    # Labels that have not arrived for the last days show up as a ratio far below one.
    late = table.copy()
    late.loc[pd.to_datetime(late[settings.TIME_COL]) >= pd.Timestamp(month["day"].iloc[-7]), settings.LABEL_COL] = 0
    assert run_census.rate_trend(run_census.daily_fraud_rate(late)).iloc[0]["ratio"] == 0


def test_tool_runs_on_predictions_and_on_raw_files(table, tmp_path, capsys):
    """With a prediction file the tool gives capture; on raw files it gives the label tables only."""
    pred = tables.write_table(table[STANDARD], str(tmp_path / "pred.parquet"))
    out = str(tmp_path / "runs.parquet")
    run_census.main(["--pred", pred, "--out", out])
    printed = capsys.readouterr().out
    for title in ("First frauds against follow-ons", "Frauds by the time since", "Run sizes",
                  "Fraud rate by calendar day", "Fraud rate at the start and at the end"):
        assert title in printed
    assert "no score column" not in printed
    written = tables.read_columns(out)
    assert len(written) == (table[settings.LABEL_COL] == 1).sum() and written["inside_cut"].notna().all()
    synthetic.write_files(table, tmp_path / "raw", 2, first_number=7)
    run_census.main(["--base", str(tmp_path / "raw"), "--files", "7-8", "--gap-days", "1"])
    printed = capsys.readouterr().out
    assert "no score column" in printed and "gaps of at most 1 days" in printed
    run_census.main([])                                      # nothing to read: one line, no error
    assert "nothing to read" in capsys.readouterr().out
