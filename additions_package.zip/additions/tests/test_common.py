"""Tests of the shared helpers.

Each test compares a fast helper with the slow, obvious way of computing the same thing on a
small made-up table. They also show how the helpers are called.
"""
import tempfile

import numpy as np
import pandas as pd

from additions import settings
from additions.common import bootstrap, ranking, synthetic, tables, timekeys
from additions.common.history import EarlierRows, later_rows
from additions.common.timekeys import MISSING_SECOND


def _toy(n=1500, seed=0):
    rng = np.random.default_rng(seed)
    keys = rng.integers(0, 25, n)
    secs = rng.integers(1_700_000_000, 1_700_000_000 + 30 * 86_400, n).astype(np.int64)
    tie = rng.random(n) < 0.15
    secs[tie] = secs[rng.integers(0, n, int(tie.sum()))]       # several rows share a second
    secs[:4] = MISSING_SECOND                                    # a few rows have no time at all
    vals = rng.normal(size=n)
    vals[rng.random(n) < 0.05] = np.nan
    return rng, keys, secs, vals


def _earlier(keys, secs, i, window=None, start=None, where=None):
    """The slow, obvious definition: rows of the same key in strictly earlier seconds."""
    if secs[i] == MISSING_SECOND:
        return np.zeros(0, dtype=int)
    m = (keys == keys[i]) & (secs < secs[i]) & (secs != MISSING_SECOND)
    if window is not None:
        m &= secs >= secs[i] - window
    if start is not None:
        m &= secs >= start[i]
    if where is not None:
        m &= where
    return np.flatnonzero(m)


def test_counts_sums_and_extremes_match_the_slow_definition():
    rng, keys, secs, vals = _toy()
    where = rng.random(len(keys)) < 0.5
    start = np.where(rng.random(len(keys)) < 0.5, 1_700_000_000 + 8 * 86_400, 1_700_000_000 + 15 * 86_400)
    for st in (None, start):
        e = EarlierRows(keys, secs, start=st)
        for window in (None, 3_600, 86_400, 7 * 86_400):
            cnt, tot = e.count(window, where), e.total(vals, window)
            mx, mean = e.maximum(vals, window), e.mean(vals, window)
            since_last, since_first = e.seconds_since_last(window), e.seconds_since_first(window, where)
            for i in range(0, len(keys), 11):
                b, bw = _earlier(keys, secs, i, window, st), _earlier(keys, secs, i, window, st, where)
                assert cnt[i] == len(bw)
                assert np.isclose(tot[i], np.nansum(vals[b]))
                have = vals[b][~np.isnan(vals[b])]
                assert (np.isnan(mx[i]) and len(have) == 0) or np.isclose(mx[i], have.max())
                assert (np.isnan(mean[i]) and len(have) == 0) or np.isclose(mean[i], have.mean())
                assert (np.isnan(since_last[i]) and len(b) == 0) or since_last[i] == secs[i] - secs[b].max()
                assert (np.isnan(since_first[i]) and len(bw) == 0) or since_first[i] == secs[i] - secs[bw].min()


def test_rows_of_the_same_second_never_see_each_other():
    keys = np.array([7, 7, 7, 7])
    secs = np.array([100, 200, 200, 300], dtype=np.int64)
    e = EarlierRows(keys, secs)
    assert e.count().tolist() == [0, 1, 1, 3]                   # the two rows at second 200 do not count each other
    assert e.total(np.array([1.0, 10.0, 100.0, 1000.0])).tolist() == [0.0, 1.0, 1.0, 111.0]


def test_later_rows_do_not_change_earlier_answers():
    rng, keys, secs, vals = _toy(seed=1)
    full = EarlierRows(keys, secs).total(vals, 86_400)
    keep = secs <= np.median(secs[secs != MISSING_SECOND])       # drop every row after the middle of the period
    part = EarlierRows(keys[keep], secs[keep]).total(vals[keep], 86_400)
    assert np.allclose(full[keep], part)


def test_distinct_values_and_faded_sums():
    rng, keys, secs, vals = _toy(seed=2)
    other = rng.integers(-1, 9, len(keys))
    e = EarlierRows(keys, secs)
    half_lives = [600.0, 86_400.0]
    faded = e.decayed_sum(vals, half_lives)
    for window in (None, 2 * 86_400):
        d = e.distinct(other, window)
        for i in range(0, len(keys), 13):
            b = _earlier(keys, secs, i, window)
            assert d[i] == len(set(other[b][other[b] >= 0]))
    for i in range(0, len(keys), 13):
        b = _earlier(keys, secs, i)
        for h, half in enumerate(half_lives):
            assert np.isclose(faded[i, h], np.nansum(vals[b] * 0.5 ** ((secs[i] - secs[b]) / half)))


def test_looking_forward_counts_strictly_later_rows():
    rng, keys, secs, vals = _toy(seed=3)
    ahead = later_rows(keys, secs).count(86_400)
    for i in range(4, len(keys), 17):
        assert ahead[i] == ((keys == keys[i]) & (secs > secs[i]) & (secs <= secs[i] + 86_400)).sum()


def test_cut_size_and_capture_with_ties():
    assert ranking.cut_size(952_905) == 5_717 and ranking.cut_size(952_905, rounding="ceil") == 5_718
    rng = np.random.default_rng(4)
    n = 50_000
    y = (rng.random(n) < 0.004).astype(int)
    s = rng.normal(size=n) + 3.0 * y
    amt = rng.lognormal(3, 1, n)
    c = ranking.capture(y, s, amt)
    top = np.argsort(-s)[: ranking.cut_size(n)]
    assert np.isclose(c["caught"], y[top].sum()) and np.isclose(c["vdr"], (amt * y)[top].sum() / (amt * y).sum())
    tied = ranking.capture(y, np.zeros(n))                       # every row ties: capture equals the alert share
    assert np.isclose(tied["udr"], 0.006) and tied["caught_min"] == 0
    assert ranking.alert_mask(s).sum() == ranking.cut_size(n)


def test_paired_bootstrap_is_exact_and_paired():
    rng = np.random.default_rng(5)
    n = 60_000
    acct = rng.integers(0, 6_000, n)
    y = (rng.random(n) < 0.003).astype(int)
    a = rng.normal(size=n) + 3.0 * y
    b = rng.normal(size=n) + 2.5 * y
    same = bootstrap.paired_bootstrap(acct, y, a, a, draws=30, seed=1)
    assert same["gain"] == 0 and same["low"] == 0 and same["high"] == 0
    r = bootstrap.paired_bootstrap(acct, y, a, b, draws=200, seed=1)
    assert np.isclose(r["a"], ranking.capture(y, a)["udr"]) and r["low"] <= r["gain"] <= r["high"]


def test_paired_bootstrap_credits_ties_at_the_cut_like_capture():
    n = 1_000                                                    # six alerts
    s = np.zeros(n)
    s[:4], s[4:20] = 1.0, 0.5                                    # sixteen rows tie for the last two places
    y = np.zeros(n, dtype=int)
    y[[0, 15, 16, 17, 18, 19]] = 1                               # the tied frauds sit late in row order
    r = bootstrap.paired_bootstrap(np.arange(n), y, s, s[::-1].copy(), draws=20, seed=0)
    assert np.isclose(r["a"], ranking.capture(y, s)["udr"])
    many = np.repeat(s[:40], 50)                                 # a tie longer than the first head
    yy = np.repeat(y[:40], 50)
    assert np.isclose(bootstrap.paired_bootstrap(np.arange(len(many)), yy, many, many, draws=5)["a"],
                      ranking.capture(yy, many)["udr"])


def test_made_up_data_keeps_the_properties_the_logic_relies_on():
    df = synthetic.make_transactions(n_accounts=150, seed=6)
    assert df.loc[df[settings.DECLINE_FLAG_COL] == 1, settings.LABEL_COL].sum() == 0     # no label on declined rows
    assert df[settings.ID_COL].is_unique
    with tempfile.TemporaryDirectory() as folder:
        numbers = synthetic.write_files(df, folder, 3)
        back = tables.read_files(folder, numbers, [settings.ACCOUNT_COL, settings.TIME_COL, None, "absent_column"])
        assert len(back) == len(df)
        assert back.groupby(settings.ACCOUNT_COL)["_file"].nunique().max() == 1          # no account in two files


def test_time_keys():
    s = timekeys.seconds(pd.Series(["2025-06-01 10:00:00.7", "2025-06-01 10:00:01", None]))
    assert s[1] - s[0] == 1 and s[2] == MISSING_SECOND
    month = pd.to_datetime(timekeys.month_start_seconds(s[:2], 1), unit="s")
    assert str(month[0].date()) == "2025-05-01"
    assert timekeys.codes(["a", "b", "a"]).tolist() == [0, 1, 0]
    aware = pd.Series(pd.to_datetime(["2025-06-01 12:00:00", "2025-06-01 12:00:05"]).tz_localize("Europe/Berlin"))
    naive_utc = timekeys.seconds(pd.Series(["2025-06-01 10:00:00", "2025-06-01 10:00:05"]))
    assert timekeys.seconds(aware).tolist() == naive_utc.tolist()               # 12:00 in Berlin is 10:00 UTC


def test_capture_with_missing_scores_ranks_them_last():
    y = np.zeros(1_000)
    y[-1] = 1
    s = np.r_[np.full(995, np.nan), np.ones(5)]                  # six alerts, only five real scores
    c = ranking.capture(y, s)
    assert c["alerts"] == 6 and np.isclose(c["caught"], 1.0) and c["tied_rows"] == 995


def test_average_ranks_agree_with_the_slow_definition_and_keep_infinite_and_missing_scores_in_place():
    """The rank of a row is the number of lower scores plus the mean place among its ties."""
    rng = np.random.default_rng(3)
    values = rng.normal(size=300).round(1)                       # rounding makes many ties
    values[:5] = np.inf
    values[5:9] = -np.inf
    values[9:12] = np.nan
    got = ranking.average_ranks(values)
    filled = np.where(np.isnan(values), -np.inf, values)          # a missing score ranks last, with minus infinity
    slow = np.array([(filled < v).sum() + ((filled == v).sum() + 1) / 2 for v in filled])
    assert np.array_equal(got, slow)
    assert np.isfinite(got).all() and got.min() >= 1.0 and got.max() <= len(values)
    assert got[:5].min() > got[12:].max()                         # plus infinity is above every finite score
    assert got[5:12].max() < got[12:].min()                       # minus infinity and missing are below all of them
    assert len(set(got[5:12])) == 1                               # and they tie with each other
    assert got.sum() == len(values) * (len(values) + 1) / 2       # ranks always add up to 1 + 2 + ... + rows

    matrix = np.column_stack([values, -filled, rng.normal(size=300)])
    by_column = ranking.average_ranks(matrix)
    assert by_column.shape == matrix.shape
    for j in range(3):
        assert np.array_equal(by_column[:, j], ranking.average_ranks(matrix[:, j]))
    assert ranking.average_ranks(np.zeros(0)).shape == (0,)
    assert ranking.average_ranks(np.zeros((0, 2))).shape == (0, 2)


def test_ids_as_text_match_across_the_forms_a_file_can_store_them_in():
    """Whole numbers, the same numbers as floats beside a missing id, and their text all give the same text."""
    as_numbers = np.array([12, 1_000_000_007, 5], dtype=np.int64)
    as_floats = np.array([12.0, 1_000_000_007.0, np.nan])       # one id is missing, so the column is float
    as_texts = np.array(["12", "1000000007", "x-5"], dtype=object)
    assert tables.id_text(as_numbers).tolist() == ["12", "1000000007", "5"]
    assert tables.id_text(as_floats).tolist()[:2] == ["12", "1000000007"]
    assert tables.id_text(as_texts).tolist() == ["12", "1000000007", "x-5"]
    assert tables.id_text(np.array([2.5, np.inf])).tolist() == ["2.5", "inf"]     # not whole numbers: left as they are
    assert tables.id_text(pd.Series(as_numbers, index=[7, 8, 9])).tolist() == ["12", "1000000007", "5"]
    found = pd.Index(tables.id_text(as_texts)).isin(tables.id_text(as_floats))
    assert found.tolist() == [True, True, False]

