"""Tests of stage 1 with several summary tokens.

The tests check the shapes, that a transaction's vector depends on its own fields only,
that gradients reach the learned summary tokens, and that scoring under torch.no_grad()
gives the same vectors as training at dropout zero.
"""
import torch

from additions.model.summary_tokens import SummaryTokenEncoder

D, HEADS = 16, 4


def _encoder(k=3, blocks=2, dropout=0.0):
    """A small stage 1 with `k` summary tokens."""
    torch.manual_seed(0)
    return SummaryTokenEncoder(embed_dim=D, num_summary=k, num_heads=HEADS, num_blocks=blocks, dropout=dropout,
                               attn_dropout=dropout)


def test_shapes_and_finite_values():
    """K summary tokens give a vector K field tokens wide, and the field outputs keep their shape."""
    encoder = _encoder(k=3)
    tokens = torch.randn(2, 5, 7, D)
    vectors = encoder(tokens)
    assert encoder.out_dim == 3 * D
    assert vectors.shape == (2, 5, 3 * D) and torch.isfinite(vectors).all()
    vectors2, fields = encoder(tokens, return_fields=True)
    assert fields.shape == (2, 5, 7, D) and torch.isfinite(fields).all()
    assert torch.allclose(vectors, vectors2)
    # Any leading layout works: a flat list of transactions as well.
    assert encoder(tokens.reshape(10, 7, D)).shape == (10, 3 * D)


def test_one_summary_token_is_the_original_width():
    """With one summary token the vector is one field token wide, as in the original stage 1."""
    encoder = _encoder(k=1)
    assert encoder(torch.randn(3, 4, 6, D)).shape == (3, 4, D)


def test_a_row_depends_only_on_its_own_fields():
    """Changing the fields of other rows leaves a row's vector unchanged."""
    encoder = _encoder().eval()
    tokens = torch.randn(2, 6, 5, D)
    altered = tokens.clone()
    altered[:, 3:] = torch.randn(2, 3, 5, D) * 5             # later rows, and a whole other sequence slot
    altered[1] = torch.randn(6, 5, D)
    with torch.no_grad():
        before, after = encoder(tokens), encoder(altered)
    assert torch.allclose(before[0, :3], after[0, :3], atol=1e-6)
    assert not torch.allclose(before[0, 3:], after[0, 3:])


def test_gradients_reach_the_summary_tokens_and_the_blocks():
    """A loss on the vectors sends a gradient to the summary tokens and to every block."""
    encoder = _encoder(dropout=0.1).train()
    encoder(torch.randn(2, 4, 5, D)).pow(2).mean().backward()
    assert encoder.summary.grad is not None and encoder.summary.grad.abs().sum() > 0
    for layer in encoder.encoder.layers:
        assert layer.linear1.weight.grad is not None and layer.linear1.weight.grad.abs().sum() > 0


def test_scoring_route_agrees_with_training_at_dropout_zero():
    """Evaluation mode under torch.no_grad() gives the vectors that training mode gives at dropout zero."""
    encoder = _encoder(dropout=0.0)
    tokens = torch.randn(3, 4, 5, D)
    train_out = encoder.train()(tokens)
    with torch.no_grad():
        eval_out = encoder.eval()(tokens)
    assert torch.allclose(train_out, eval_out, atol=1e-5)


def test_zero_blocks_returns_the_summary_tokens_themselves():
    """A stage with no blocks still runs and hands over the learned summary tokens unchanged."""
    encoder = _encoder(k=2, blocks=0)
    out = encoder(torch.randn(2, 3, 4, D))
    expected = encoder.summary.reshape(1, 1, 2 * D).expand(2, 3, -1)
    assert torch.allclose(out, expected)
