"""Tests of the rule for "it holds" and of the full-scale plan."""
import pandas as pd

from additions.sweep import promote
from additions.sweep.promote import HOLDS, NOT, UNCLEAR


def test_an_arm_with_a_cost_needs_size_interval_and_confirmation():
    """Large enough, interval above zero and repeated on the second block: holds. Anything less: not or unclear."""
    assert promote.verdict(0.012, 0.003, 0.008)[0] == HOLDS
    assert promote.verdict(0.003, 0.001, 0.004)[0] == NOT                 # too small
    assert promote.verdict(0.012, -0.002, 0.008)[0] == UNCLEAR            # interval reaches zero
    assert promote.verdict(0.012, 0.003, -0.001)[0] == NOT                # did not repeat
    assert promote.verdict(0.012, 0.003, None)[0] == UNCLEAR              # not yet confirmed
    assert promote.verdict(0.012, 0.003, None, require_confirm=False)[0] == HOLDS


def test_a_free_arm_only_has_to_be_above_zero_twice():
    """An arm that costs nothing holds with any gain above zero on both blocks."""
    assert promote.verdict(0.001, -0.004, 0.002, free=True)[0] == HOLDS
    assert promote.verdict(-0.001, -0.004, 0.002, free=True)[0] == NOT
    assert promote.verdict(0.001, -0.004, -0.002, free=True)[0] == NOT


def test_no_arm_is_both_free_and_slower_to_train():
    """A free arm costs nothing at training time, so its runs take no longer than the control's."""
    from additions.sweep.arms import ARMS
    assert [a["id"] for a in ARMS if a["free"] and a["time_factor"] > 1.0] == []


def test_full_scale_plan_trains_holders_together_and_isolates_costly_ones():
    """Trained holders share one run; a costly holder also gets a run without it; CPU holders are applied after."""
    results = pd.DataFrame({
        "id": ["loss_mask", "summary_tokens", "lock_on", "pairwise_top", "precision_32bit"],
        "gain": [0.010, 0.020, 0.004, 0.001, 0.008],
        "low": [0.002, 0.006, 0.001, -0.004, 0.001],
        "high": [0.018, 0.034, 0.007, 0.006, 0.015],
        "gain_confirm": [0.007, 0.015, 0.003, 0.002, 0.004],
    })
    judged = promote.judge(results)
    assert dict(zip(judged["id"], judged["verdict"])) == {
        "loss_mask": HOLDS, "summary_tokens": HOLDS, "lock_on": HOLDS, "pairwise_top": NOT, "precision_32bit": HOLDS}
    plan = promote.full_scale_plan(judged)
    runs = dict(zip(plan["run"], plan["switched_on"]))
    assert runs["all_that_held"] == "loss_mask, summary_tokens, precision_32bit"
    assert runs["without_summary_tokens"] == "loss_mask, precision_32bit"           # the wide stage is costly to train
    assert "without_precision_32bit" in runs and "without_loss_mask" not in runs
    assert runs["applied_after_scoring"] == "lock_on"


def test_the_tool_reads_a_results_file(tmp_path, capsys):
    """The command-line tool prints verdicts and writes the full-scale plan."""
    path = tmp_path / "results.csv"
    pd.DataFrame({"id": ["loss_mask"], "gain": [0.01], "low": [0.002], "high": [0.02], "gain_confirm": [0.006]}).to_csv(path, index=False)
    out = tmp_path / "plan.csv"
    assert promote.main(["--results", str(path), "--out", str(out)]) == 0
    assert "holds" in capsys.readouterr().out and pd.read_csv(out)["run"].tolist() == ["control", "all_that_held"]
