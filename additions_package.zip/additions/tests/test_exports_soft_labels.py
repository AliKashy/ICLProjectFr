"""Tests of the soft-label export.

The made-up rows come with their true fraud probability, which plays the teacher. That makes
the gain of a soft target measurable without label noise: the expected number of frauds
among a student's alerts is the sum of the true probabilities of the rows it alerts.
"""
import numpy as np
import pandas as pd
import pytest
from scipy.special import expit
from scipy.stats import spearmanr

from additions import settings
from additions.common import ranking, tables
from additions.exports import _shared, soft_labels

INPUTS = dict(numeric_cols=["f0", "f1", "f2", "f3"], code_cols=["kind"])


def _made_up(n, seed):
    """Rows whose fraud probability depends on four inputs; the score column holds that true probability."""
    rng = np.random.default_rng(seed)
    x = rng.normal(size=(n, 4))
    p = expit(-5.5 + 1.2 * x[:, 0] + 1.0 * x[:, 1] * (x[:, 2] > 0) - 0.8 * x[:, 3])
    start = pd.Timestamp(settings.TARGET_START)
    return pd.DataFrame({
        settings.ID_COL: np.arange(n) + seed * 1_000_000,
        settings.ACCOUNT_COL: rng.integers(0, n // 10, n) + seed * 1_000_000,
        settings.TIME_COL: start + pd.to_timedelta(rng.integers(0, 20 * 86_400, n), unit="s"),
        settings.LABEL_COL: (rng.random(n) < p).astype(int),
        settings.AMOUNT_COL: np.round(rng.lognormal(3.0, 1.0, n), 2),
        settings.SCORE_COL: p,
        **{f"f{j}": x[:, j] for j in range(4)},
        "kind": rng.choice(["a", "b", "c"], n),
    })


@pytest.fixture(scope="module")
def tables_pair():
    """A small training table and a read table of other accounts."""
    return _made_up(8_000, seed=1), _made_up(20_000, seed=2)


def test_soft_target_is_the_stated_mix():
    """The target is (1 - w) * label + w * probability, stays between 0 and 1, and keeps labels where no score exists."""
    y = np.array([0, 1, 0, 1, 1])
    p = np.array([0.2, 0.9, np.nan, 0.0, 1.0])
    assert np.allclose(soft_labels.soft_targets(y, p), [0.1, 0.95, 0.0, 0.5, 1.0])
    assert np.allclose(soft_labels.soft_targets(y, p, weight=0.25), [0.05, 0.975, 0.0, 0.75, 1.0])
    assert np.array_equal(soft_labels.soft_targets(y, p, weight=0.0), y)
    assert np.allclose(soft_labels.soft_targets(y, np.nan_to_num(p), weight=1.0), np.nan_to_num(p))
    mixed = soft_labels.soft_targets(y, np.array([-0.5, 1.5, 0.3, 0.3, 0.3]))
    assert mixed.min() >= 0.0 and mixed.max() <= 1.0


def test_a_teacher_that_repeats_the_labels_teaches_nothing(tables_pair):
    """Scores equal to the labels give the plain labels back, and with them the hard-label student."""
    fit_table, read_table = tables_pair
    y = _shared.fraud_flags(fit_table)
    assert np.array_equal(soft_labels.soft_targets(y, y), y)
    in_sample = fit_table.assign(**{settings.SCORE_COL: y})
    result = soft_labels.compare(in_sample, read_table, rounds=20, draws=10, **INPUTS)
    assert np.array_equal(result["scores"][soft_labels.SOFT], result["scores"][soft_labels.HARD])
    assert (result["bootstrap"]["gain"] == 0).all()


def test_a_weight_of_zero_switches_the_soft_target_off(tables_pair):
    """With no share for the probability the soft student is the hard student."""
    fit_table, read_table = tables_pair
    result = soft_labels.compare(fit_table, read_table, weight=0.0, rounds=20, draws=10, **INPUTS)
    assert np.array_equal(result["scores"][soft_labels.SOFT], result["scores"][soft_labels.HARD])


def test_soft_student_ranks_closer_to_the_truth_than_the_hard_student(tables_pair):
    """With few frauds to learn from, the mix with an out-of-sample probability gives the better ranking."""
    fit_table, read_table = tables_pair
    result = soft_labels.compare(fit_table, read_table, rounds=60, draws=30, **INPUTS)
    truth = read_table[settings.SCORE_COL].to_numpy()
    expected = {name: truth[ranking.alert_mask(s, per_mille=20)].sum() for name, s in result["scores"].items()}
    assert expected[soft_labels.SOFT] > expected[soft_labels.HARD] + 2.0       # expected frauds among the alerts
    assert expected[soft_labels.TEACHER] >= expected[soft_labels.SOFT]         # the student does not beat the truth
    rank = {name: spearmanr(s, truth).statistic for name, s in result["scores"].items()}
    assert rank[soft_labels.SOFT] > rank[soft_labels.HARD] + 0.03
    # The table is read against the true labels, with the same capture rules as everywhere else.
    table = result["table"].set_index("read")
    y, amount = _shared.fraud_flags(read_table), read_table[settings.AMOUNT_COL].to_numpy()
    for name, scores in result["scores"].items():
        c = ranking.capture(y, scores, amount)
        assert np.isclose(table.loc[name, "udr"], c["udr"]) and np.isclose(table.loc[name, "vdr"], c["vdr"])
        assert np.isclose(table.loc[name, "ap"], ranking.average_precision(y, scores))
    boot = result["bootstrap"].set_index("measure")
    assert np.isclose(boot.loc["udr", "gain"], table.loc[soft_labels.SOFT, "udr"] - table.loc[soft_labels.HARD, "udr"])
    assert boot.loc["udr", "low"] <= boot.loc["udr", "gain"] <= boot.loc["udr", "high"] and set(boot.index) == {"udr", "vdr"}


def test_student_inputs_code_text_columns_and_skip_absent_ones(capsys):
    """A code column becomes one number per value of the fit table; unseen and missing codes become missing."""
    fit_table = pd.DataFrame({"f0": [1.0, 2.0, 3.0], "kind": ["a", "b", "a"], "only_here": [1, 2, 3]})
    read_table = pd.DataFrame({"f0": [5.0, np.nan], "kind": ["b", "z"]})
    x_fit, x_read, names = soft_labels.student_inputs(fit_table, read_table, ["f0", "only_here"], ["kind", "absent"])
    assert names == ["f0", "kind"] and x_fit.shape == (3, 2) and x_read.shape == (2, 2)
    assert x_fit[:, 1].tolist() == [0.0, 1.0, 0.0] and x_read[0, 1] == 1.0 and np.isnan(x_read[1, 1])
    assert np.isnan(x_read[1, 0]) and x_fit.dtype == np.float32
    printed = capsys.readouterr().out
    assert "only_here" in printed and "absent" in printed
    with_gap = pd.DataFrame({"f0": [1.0], "kind": [None]})
    assert np.isnan(soft_labels.student_inputs(fit_table, with_gap, ["f0"], ["kind"])[1][0, 1])
    # A code stored as numbers in one table and as text in the other still lines up.
    as_numbers = pd.DataFrame({"f0": [1.0, 2.0, 3.0], "mcc": [5411.0, 5812.0, 5411.0]})
    as_text = pd.DataFrame({"f0": [1.0, 2.0, 3.0], "mcc": ["5812", " 5411 ", "9999"]})
    numbers_side, text_side, _ = soft_labels.student_inputs(as_numbers, as_text, ["f0"], ["mcc"])
    assert numbers_side[:, 1].tolist() == [0.0, 1.0, 0.0]
    assert text_side[:2, 1].tolist() == [1.0, 0.0] and np.isnan(text_side[2, 1])


def test_tool_reads_files_and_writes_both_students(tables_pair, tmp_path, capsys):
    """The tool prints the comparison for the scored month and writes the two students' scores on request."""
    fit_table, read_table = tables_pair
    fit_path = tables.write_table(fit_table, str(tmp_path / "fit.parquet"))
    read_path = tables.write_table(read_table, str(tmp_path / "read.parquet"))
    out_path = str(tmp_path / "students.parquet")
    result = soft_labels.main(["--fit", fit_path, "--read", read_path, "--numeric-cols", "f0", "f1", "f2", "f3",
                               "--code-cols", "kind", "--rounds", "15", "--draws", "10", "--out", out_path])
    printed = capsys.readouterr().out
    assert "student on soft labels" in printed and "paired bootstrap" in printed
    written = tables.read_columns(out_path)
    assert len(written) == len(read_table) and {"student_hard", "student_soft"} <= set(written.columns)
    assert np.allclose(written["student_soft"], result["scores"][soft_labels.SOFT])
    # Rows outside the scored month are not ranked; with none inside, the tool says so and stops quietly.
    assert soft_labels.main(["--fit", fit_path, "--read", read_path, "--start", "2031-01-01", "--end", "2031-02-01"]) is None
    assert "no row of the read table falls in the scored month" in capsys.readouterr().out
    demo = soft_labels.main(["--demo", "--rounds", "10", "--draws", "10"])
    assert len(demo["table"]) == 3
