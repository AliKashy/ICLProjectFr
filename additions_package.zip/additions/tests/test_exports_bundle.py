"""Tests of the export bundle.

The window columns are compared with a loop over the earlier rows of each account, the
directions with partial least squares written out step by step, and the scores with their
definitions. Further tests check the time rule and that no label is read when the bundle is built.
"""
import numpy as np
import pandas as pd
import pytest
from scipy.special import expit

from additions import settings
from additions.common import ranking, tables, timekeys
from additions.exports import _shared, bundle

DAY = 86_400


@pytest.fixture(scope="module")
def blocks():
    """Two made-up export tables with their fitted parts: (fit table, table to build for, fitted)."""
    fit_table, table = bundle.demo_tables(n_accounts=120, seed=3)
    return fit_table, table, bundle.fit_bundle(fit_table)


@pytest.fixture(scope="module")
def built(blocks):
    """The bundle of the second table."""
    _, table, fitted = blocks
    return bundle.build_bundle(table, fitted)


def _arrays(table, fitted):
    """Account, whole second, logit and standardised vector of every row."""
    vectors = table[fitted["vector_columns"]].to_numpy(dtype=np.float64)
    z = (vectors - np.asarray(fitted["vector_mean"])) / np.asarray(fitted["vector_sd"])
    return (table[settings.ACCOUNT_COL].to_numpy(), timekeys.seconds(table[settings.TIME_COL]),
            ranking.to_logit(table[settings.SCORE_COL]), z)


def _slow_windows(account, secs, logit, z, alert, i):
    """The fourteen window columns of row i, from a plain look at the earlier rows of its account."""
    earlier = (account == account[i]) & (secs < secs[i])
    out = {}
    for label, window in bundle.WINDOWS:
        seen = earlier & (secs >= secs[i] - window)
        out[f"w_max_{label}"] = logit[seen].max() if seen.any() else np.nan
        out[f"w_mean_{label}"] = logit[seen].mean() if seen.any() else np.nan
    seen = earlier & (secs >= secs[i] - 30 * DAY)
    alerts = seen & (logit >= alert)
    out["w_last"] = logit[seen & (secs == secs[seen].max())].max() if seen.any() else np.nan
    out["w_secs_since_alert"] = secs[i] - secs[alerts].max() if alerts.any() else np.nan
    out["w_alerts_30d"] = alerts.sum()
    out["w_minus_mean_30d"] = logit[i] - out["w_mean_30d"]
    out["w_rows_30d"] = seen.sum()
    out["w_cos_30d"] = np.nan
    if seen.any():
        mean_vector = z[seen].mean(axis=0)
        out["w_cos_30d"] = z[i] @ mean_vector / np.sqrt((z[i] @ z[i]) * (mean_vector @ mean_vector))
    return out


def _same(a, b):
    """Equal up to the precision of the float32 columns; two missing values count as equal."""
    return np.allclose(np.asarray(a, dtype=np.float64), np.asarray(b, dtype=np.float64), rtol=1e-4, atol=1e-4,
                       equal_nan=True)


def test_bundle_has_the_29_named_columns_in_order(blocks, built):
    """Keys come first, then 7 scores, the directions that could be fitted and 14 windows, all finite or missing."""
    _, table, fitted = blocks
    n_directions = len(fitted["direction_gain"])
    names = bundle.bundle_columns(n_directions)
    assert len(bundle.bundle_columns()) == 29 and len(bundle.window_columns()) == 14
    assert list(built.columns) == [settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL] + names
    assert len(built) == len(table) and (built.index == table.index).all()
    values = built[names].to_numpy(dtype=np.float64)
    assert np.isfinite(values[~np.isnan(values)]).all() and built[names].dtypes.eq(np.float32).all()
    never_missing = list(bundle.SCORE_COLUMNS) + bundle.direction_columns(n_directions) + ["w_alerts_30d", "w_rows_30d"]
    assert not built[never_missing].isna().any().any()


def test_window_columns_match_a_loop_over_earlier_rows(blocks, built):
    """Every window column equals the same statistic taken over the account's rows of strictly earlier seconds."""
    _, table, fitted = blocks
    account, secs, logit, z = _arrays(table, fitted)
    checked = 0
    for i in range(0, len(table), 37):
        slow = _slow_windows(account, secs, logit, z, fitted["alert_logit"], i)
        for name in bundle.window_columns():
            assert _same(built[name].iloc[i], slow[name]), (name, i)
        checked += 1
    assert checked > 100
    assert built["w_secs_since_alert"].notna().any() and built["w_rows_30d"].max() > 20
    assert (built["w_rows_30d"] < timekeys.codes(account).shape[0]).all()
    # The files run for two months, so some earlier rows lie outside the 30 days and are not counted.
    all_earlier = pd.Series(secs).groupby(account).rank(method="min").to_numpy() - 1
    assert (built["w_rows_30d"].to_numpy() < all_earlier).any()


def test_rows_of_the_same_second_do_not_see_each_other():
    """Two rows of one account in one second get the same windows, built from earlier seconds only."""
    keys = np.array([0, 0, 0, 0, 1])
    secs = np.array([100, 200, 200, 300, 250], dtype=np.int64)
    logit = np.array([1.0, 5.0, -2.0, 0.0, 9.0])
    z = np.array([[1.0, 0.0], [0.0, 1.0], [0.0, -1.0], [1.0, 1.0], [5.0, 5.0]])
    w = bundle.score_windows(keys, secs, logit, z, alert_logit=4.0)
    assert np.isnan(w["w_max_30d"][0]) and np.isnan(w["w_last"][0]) and w["w_rows_30d"][0] == 0
    assert w["w_max_30d"][1] == w["w_max_30d"][2] == 1.0          # the rows at second 200 see second 100 only
    assert w["w_rows_30d"].tolist() == [0, 1, 1, 3, 0]            # the other account sees nothing of this one
    assert w["w_max_30d"][3] == 5.0 and w["w_last"][3] == 5.0     # the latest second holds 5 and -2: the highest
    assert np.isclose(w["w_mean_30d"][3], (1.0 + 5.0 - 2.0) / 3) and w["w_alerts_30d"].tolist() == [0, 0, 0, 1, 0]
    assert w["w_secs_since_alert"][3] == 100 and np.isnan(w["w_secs_since_alert"][1])
    assert np.isclose(w["w_cos_30d"][1], 0.0) and np.isclose(w["w_cos_30d"][2], 0.0)      # (0, 1) against (1, 0)
    assert np.isclose(w["w_cos_30d"][3], 1.0 / np.sqrt(2.0))                               # (1, 1) against (1, 0)


def test_later_rows_do_not_change_the_columns_of_earlier_rows(blocks, built):
    """Cutting the table off at a point in time leaves every column of the rows before it as it was."""
    _, table, fitted = blocks
    secs = timekeys.seconds(table[settings.TIME_COL])
    keep = secs <= np.median(secs)
    part = bundle.build_bundle(table[keep], fitted)
    names = [c for c in built.columns if c in bundle.bundle_columns()]
    # The directions are a matrix product, whose last digits can depend on how many rows are
    # multiplied at once; a later row leaking in would move a column by far more than that.
    assert np.allclose(part[names].to_numpy(), built.loc[keep, names].to_numpy(), rtol=1e-5, atol=1e-5, equal_nan=True)


def test_no_label_is_read_when_the_bundle_is_built(blocks, built):
    """The columns are the same without the label column: labels are fitting targets only."""
    _, table, fitted = blocks
    without = bundle.build_bundle(table.drop(columns=[settings.LABEL_COL, settings.REASON_COL]), fitted)
    assert without.equals(built)


def test_scores_follow_their_definitions(blocks, built):
    """s_full is the logit, s_val adds the amount tilt, s_ctx is the calibrated logit minus the stage-1 probe."""
    fit_table, table, fitted = blocks
    logit = ranking.to_logit(table[settings.SCORE_COL])
    amount = table[settings.AMOUNT_COL].to_numpy()
    assert _same(built["s_full"], logit) and fitted["value_tilt"] == bundle.VALUE_TILT
    assert _same(built["s_val"], logit + bundle.VALUE_TILT * np.log1p(amount))
    stage1 = table[fitted["stage1_columns"]].to_numpy()
    s_txn = stage1 @ np.asarray(fitted["probes"]["s_txn"]["weights"]) + fitted["probes"]["s_txn"]["bias"]
    calibrated = logit * fitted["calibration"]["weights"][0] + fitted["calibration"]["bias"]
    assert _same(built["s_txn"], s_txn) and _same(built["s_ctx"], calibrated - s_txn)
    for name in ("p_acct_24h", "p_acct_7d", "p_decline"):
        assert built[name].between(0.0, 1.0).all() and built[name].std() > 0
    # The alert cut is a number about the scores of the fit block: the lowest logit among its top rows.
    fit_logit = np.sort(ranking.to_logit(fit_table[settings.SCORE_COL]))[::-1]
    assert np.isclose(fitted["alert_logit"], fit_logit[ranking.cut_size(len(fit_table)) - 1])
    # On the fit block both scores are log-odds of the same label, so their fitted rates agree with it.
    y = _shared.fraud_flags(fit_table)
    fit_bundle = bundle.build_bundle(fit_table, fitted)
    assert np.isclose(expit(fit_bundle["s_txn"]).mean(), y.mean(), rtol=1e-2)
    assert np.isclose(expit(fit_bundle["s_ctx"] + fit_bundle["s_txn"]).mean(), y.mean(), rtol=1e-2)


def test_look_ahead_target_counts_strictly_later_frauds_and_marks_cut_off_rows(blocks):
    """The fitting target of the look-ahead probes equals a loop over the later rows of the account."""
    fit_table, _, _ = blocks
    keys, secs = _shared.account_and_time(fit_table)
    is_fraud = _shared.fraud_flags(fit_table) > 0
    follows, known = bundle.fraud_follows(keys, secs, is_fraud, DAY)
    for i in range(0, len(fit_table), 23):
        later = (keys == keys[i]) & (secs > secs[i]) & (secs <= secs[i] + DAY) & is_fraud
        assert follows[i] == later.any()
    assert follows.any() and np.array_equal(known, secs <= secs.max() - DAY) and not known.all()
    # A fraud in the same second is not "later": two frauds in one second do not announce each other.
    same_second, _ = bundle.fraud_follows(np.zeros(3, dtype=int), np.array([10, 10, 50]), np.array([1, 1, 0]), 100)
    assert same_second.tolist() == [False, False, False]


def _slow_directions(x, residual, k):
    """Partial least squares step by step on the full table: weight, direction, take it out, repeat."""
    x = x.copy()
    residual = residual - residual.mean()
    found = []
    for _ in range(k):
        weight = x.T @ residual
        weight /= np.linalg.norm(weight)
        direction = x @ weight
        gain = (direction @ residual) ** 2 / (direction @ direction) / (residual @ residual)
        found.append((gain, direction / direction.std()))
        x = x - np.outer(direction, x.T @ direction / (direction @ direction))
    found.sort(key=lambda pair: -pair[0])
    return np.array([g for g, _ in found]), np.column_stack([d for _, d in found])


def test_directions_match_partial_least_squares_step_by_step():
    """The rotation gives the same directions as the slow method: unit spread, uncorrelated, ordered by gain."""
    rng = np.random.default_rng(0)
    n, d = 4000, 6
    x = rng.normal(size=(n, d)) @ rng.normal(size=(d, d))                # correlated columns
    x = (x - x.mean(axis=0)) / x.std(axis=0)
    residual = 0.3 * x[:, 0] - 0.2 * x[:, 3] + rng.normal(size=n)
    rotation, gain = bundle.fit_directions(x.astype(np.float32), residual, n_directions=4, chunk=700)
    slow_gain, slow = _slow_directions(x, residual, 4)
    fast = x @ rotation
    assert rotation.shape == (d, 4) and np.allclose(gain, slow_gain, rtol=1e-3)
    assert np.allclose(fast, slow, atol=2e-3)
    assert np.allclose(np.cov(fast.T, bias=True), np.eye(4), atol=1e-3)   # unit spread, no shared part
    assert (np.diff(gain) <= 0).all() and ((fast.T @ (residual - residual.mean())) > 0).all()
    # More directions than the vector has independent columns: the search stops, nothing breaks.
    thin = np.column_stack([x[:, 0], 2.0 * x[:, 0]])
    rotation, gain = bundle.fit_directions(thin, residual, n_directions=5)
    assert rotation.shape[0] == 2 and rotation.shape[1] <= 2 and len(gain) == rotation.shape[1]


def test_first_direction_finds_what_the_score_misses():
    """A fraud signal that lies across the vector's axes and is absent from the score lands on dir_1."""
    rng = np.random.default_rng(1)
    n, d = 30_000, 10
    vectors = rng.normal(size=(n, d)) @ rng.normal(size=(d, d))
    hidden = vectors @ rng.normal(size=d)
    hidden = (hidden - hidden.mean()) / hidden.std()
    seen = rng.normal(size=n)
    y = (rng.random(n) < expit(-3.0 + 1.5 * seen + 1.5 * hidden)).astype(int)
    start = pd.Timestamp(settings.EVAL_HISTORY_START)
    table = pd.DataFrame({
        settings.ACCOUNT_COL: rng.integers(0, 500, n), settings.LABEL_COL: y,
        settings.TIME_COL: start + pd.to_timedelta(rng.integers(0, 40 * DAY, n), unit="s"),
        settings.SCORE_COL: expit(-3.0 + 1.5 * seen), settings.AMOUNT_COL: 10.0,
        **{f"{settings.VECTOR_PREFIX}{j}": vectors[:, j] for j in range(d)}})
    fitted = bundle.fit_bundle(table, n_directions=3)
    out = bundle.build_bundle(table, fitted)
    assert abs(np.corrcoef(out["dir_1"], hidden)[0, 1]) > 0.9
    assert abs(np.corrcoef(out["dir_1"], seen)[0, 1]) < 0.1 and fitted["direction_gain"][0] > 0.02
    assert "s_txn" not in out.columns and "p_decline" not in out.columns     # no stage-1 vector, no response code


def test_missing_optional_columns_skip_their_parts(blocks, capsys):
    """Without stage-1 columns, vector columns or amounts the remaining columns are still built."""
    fit_table, table, _ = blocks
    vector_names = _shared.vector_columns(table, settings.VECTOR_PREFIX)
    stage1_names = _shared.vector_columns(table, _shared.STAGE1_PREFIX)
    assert len(vector_names) == 8 and len(stage1_names) == 4
    drop = vector_names + stage1_names + [settings.AMOUNT_COL]
    fitted = bundle.fit_bundle(fit_table.drop(columns=drop), reason_col="absent")
    out = bundle.build_bundle(table.drop(columns=drop), fitted)
    printed = capsys.readouterr().out
    assert "stage-1" in printed and "vector columns" in printed and "amount" in printed
    expected = ["s_full"] + [c for c in bundle.window_columns() if c != "w_cos_30d"]
    assert [c for c in out.columns if c in bundle.bundle_columns()] == expected
    # A block without any fraud cannot fit a probe: the probe columns are skipped, the windows remain.
    no_fraud = fit_table.assign(**{settings.LABEL_COL: 0})
    fitted = bundle.fit_bundle(no_fraud)
    assert fitted["probes"]["s_txn"] is None and fitted["calibration"] is None and fitted["frauds"] == 0
    out = bundle.build_bundle(table, fitted)
    assert "s_ctx" not in out.columns and "w_max_24h" in out.columns and "p_decline" in out.columns


def test_fitted_parts_survive_a_json_file_and_the_tool_writes_the_bundle(blocks, built, tmp_path, capsys):
    """The fitted parts are plain numbers: a round trip through JSON gives the same bundle, and the tool writes it."""
    fit_table, table, fitted = blocks
    path = bundle.save_fitted(fitted, str(tmp_path / "bundle_fit.json"))
    again = bundle.build_bundle(table, bundle.load_fitted(path))
    assert again.equals(built)
    fit_path = tables.write_table(fit_table, str(tmp_path / "fit.parquet"))
    export_path = tables.write_table(table, str(tmp_path / "export.parquet"))
    out_path = str(tmp_path / "bundle.parquet")
    bundle.main(["--fit-export", fit_path, "--export", export_path, "--out", out_path,
                 "--save-fitted", str(tmp_path / "fit2.json")])
    printed = capsys.readouterr().out
    assert "Bundle columns" in printed and "w_max_24h" in printed
    written = tables.read_columns(out_path)
    names = [c for c in built.columns if c in bundle.bundle_columns()]
    assert np.allclose(written[names].to_numpy(), built[names].to_numpy(), equal_nan=True, atol=1e-5)
    from_file = bundle.main(["--fitted", str(tmp_path / "fit2.json"), "--export", export_path])
    assert np.allclose(from_file[names].to_numpy(), built[names].to_numpy(), equal_nan=True, atol=1e-5)
    assert len(bundle.main(["--demo"])) > 0
