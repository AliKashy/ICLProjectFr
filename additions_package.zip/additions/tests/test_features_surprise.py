"""Tests of the count-based surprise columns.

The main test recomputes the surprises of sampled rows from first principles: take the
account's rows inside the look-back, count values by hand, apply the formula. The other
tests check the rules one by one.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, timekeys
from additions.features import _shared, lookback, surprise

FIELDS = (settings.TYPE_COL, settings.SEGMENT_COL, settings.CARD_PRESENT_COL)
TRANSITIONS = (settings.TYPE_COL, settings.SEGMENT_COL)
PRIOR = 5.0


def _table(seed=0, n_accounts=25, **kwargs):
    """Made-up rows with a few missing codes and amounts."""
    df = synthetic.make_transactions(n_accounts=n_accounts, seed=seed, **kwargs)
    rng = np.random.default_rng(seed)
    df.loc[rng.random(len(df)) < 0.05, settings.SEGMENT_COL] = None
    df.loc[rng.random(len(df)) < 0.03, settings.AMOUNT_COL] = np.nan
    return df


def _fit(seed=10):
    return surprise.fit_surprise_tables(_table(seed, days=92, start="2024-10-01"), code_cols=FIELDS,
                                        transition_fields=TRANSITIONS)


def _build(df, fitted, **kwargs):
    return surprise.build_surprise(df, fitted, code_cols=FIELDS, transition_fields=TRANSITIONS, **kwargs)


def _label(value, edges):
    """The slow, obvious binning: the first edge that is not below the value names the bin."""
    return next((f"up to {edge:g}" for edge in edges if value <= edge), f"over {edges[-1]:g}")


def _share(table, text):
    """The smoothed population share of one value, straight from the fitted dictionary."""
    return (table["counts"].get(text, 0) + 1.0) / (table["rows"] + len(table["counts"]) + 1.0)


def _row_values(df, secs, fitted):
    """Per row, the text of every field that does not depend on history (None where there is no value)."""
    values = {name: [None if pd.isna(v) else str(v) for v in df[name]] for name in FIELDS}
    values["amount_bin"] = [None if np.isnan(a) else _label(a, fitted["amount_edges"]) for a in df[settings.AMOUNT_COL]]
    values["hour"] = [str((s // 3_600) % 24) for s in secs]
    return values


def _slow_lookback(values, fitted, account, secs, i, start_i):
    """Surprises of row i and of every earlier row of its look-back, each from the rows before it.

    Returns (rows, per_field, sums): the positions of the account's rows from the look-back
    start to row i's second, a list with one {field: (account, population)} per such row, and
    one (account_sum, diff_sum) per such row.
    """
    rows = np.flatnonzero((account == account[i]) & (secs >= start_i) & (secs <= secs[i]))
    per_field, sums = [], []
    for r in rows:
        before = rows[secs[rows] < secs[r]]
        mine = {name: values[name][r] for name in values}
        theirs = {name: [values[name][b] for b in before] for name in values}
        # The time gap of a row is counted from the latest earlier row inside this look-back.
        gap_of = {b: secs[b] - secs[rows[secs[rows] < secs[b]]].max() for b in before if (secs[rows] < secs[b]).any()}
        mine["gap_bin"] = _label(secs[r] - secs[before].max(), fitted["gap_edges"]) if len(before) else None
        theirs["gap_bin"] = [_label(gap_of[b], fitted["gap_edges"]) if b in gap_of else None for b in before]
        out = {}
        for name, value in mine.items():
            if value is None:
                continue
            share = _share(fitted["fields"][name], value)
            same = sum(v == value for v in theirs[name])
            any_value = sum(v is not None for v in theirs[name])
            out[name] = (-np.log((same + PRIOR * share) / (any_value + PRIOR)), -np.log(share))
        per_field.append(out)
        sums.append((sum(a for a, _ in out.values()), sum(a - p for a, p in out.values())))
    return rows, per_field, sums


def test_tables_count_values_and_transitions():
    """The fitted tables equal plain counts of values and of (previous value, value) pairs."""
    df = _table(seed=1)
    fitted = surprise.fit_surprise_tables(df, code_cols=FIELDS, transition_fields=TRANSITIONS)
    secs = timekeys.seconds(df[settings.TIME_COL])
    assert fitted["fields"][settings.TYPE_COL]["counts"] == df[settings.TYPE_COL].value_counts().to_dict()
    assert fitted["fields"][settings.SEGMENT_COL]["rows"] == df[settings.SEGMENT_COL].notna().sum()
    assert fitted["fields"]["hour"]["counts"] == pd.Series((secs // 3_600) % 24).astype(str).value_counts().to_dict()
    bins = [_label(a, fitted["amount_edges"]) for a in df[settings.AMOUNT_COL].dropna()]
    assert fitted["fields"]["amount_bin"]["counts"] == pd.Series(bins).value_counts().to_dict()
    # Transitions the slow way: for every row, the value on the latest strictly earlier row of its account.
    account = timekeys.codes(df[settings.ACCOUNT_COL])
    start = lookback.lookback_start(secs)
    kind = df[settings.TYPE_COL].to_numpy()
    pairs = {}
    for i in range(len(df)):
        earlier = np.flatnonzero((account == account[i]) & (secs < secs[i]) & (secs >= start[i]))
        if len(earlier):
            previous = earlier[secs[earlier] == secs[earlier].max()][-1]
            key = f"{kind[previous]} > {kind[i]}"
            pairs[key] = pairs.get(key, 0) + 1
    assert fitted["transitions"][settings.TYPE_COL]["pairs"]["counts"] == pairs
    assert fitted["transitions"][settings.TYPE_COL]["previous"]["rows"] == sum(pairs.values())


def test_columns_equal_the_slow_definition():
    """Per-field surprises, sums, maxima and standardised sums match a recomputation from raw counts."""
    fitted = _fit()
    df = _table(seed=2, n_accounts=12, days=92, start="2024-10-01")
    got = _build(df, fitted, min_rows_for_z=10)
    account = timekeys.codes(df[settings.ACCOUNT_COL])
    secs = timekeys.seconds(df[settings.TIME_COL])
    start = lookback.lookback_start(secs)
    values = _row_values(df, secs, fitted)
    n_fields = len(FIELDS) + 3
    assert got.shape == (len(df), 3 * n_fields + 8 + len(TRANSITIONS)) and got.index.equals(df.index)
    assert np.isfinite(got.to_numpy()[~np.isnan(got.to_numpy())]).all()
    checked_z = 0
    for i in range(0, len(df), 23):
        rows, per_field, sums = _slow_lookback(values, fitted, account, secs, i, start[i])
        row, mine = got.iloc[i], per_field[-1]                                   # row i is the last of its look-back
        assert rows[-1] == i or secs[rows[-1]] == secs[i]
        mine = per_field[list(rows).index(i)]
        for name in list(FIELDS) + ["amount_bin", "hour", "gap_bin"]:
            a, p = mine.get(name, (np.nan, np.nan))
            assert np.isclose(row[f"surprise_{name}_account"], a, rtol=1e-5, atol=1e-5, equal_nan=True)
            assert np.isclose(row[f"surprise_{name}_population"], p, rtol=1e-5, atol=1e-5, equal_nan=True)
            assert np.isclose(row[f"surprise_{name}_diff"], a - p, rtol=1e-4, atol=1e-5, equal_nan=True)
        assert row["surprise_fields_used"] == len(mine)
        assert np.isclose(row["surprise_account_sum"], sum(a for a, _ in mine.values()), rtol=1e-5)
        assert np.isclose(row["surprise_account_max"], max(a for a, _ in mine.values()), rtol=1e-5)
        assert np.isclose(row["surprise_population_sum"], sum(p for _, p in mine.values()), rtol=1e-5)
        assert np.isclose(row["surprise_diff_sum"], sum(a - p for a, p in mine.values()), rtol=1e-4, atol=1e-5)
        assert np.isclose(row["surprise_diff_max"], max(a - p for a, p in mine.values()), rtol=1e-4, atol=1e-5)
        earlier = [s for r, s in zip(rows, sums) if secs[r] < secs[i]]
        for column, k in (("surprise_account_z", 0), ("surprise_diff_z", 1)):
            past = np.array([s[k] for s in earlier])
            if len(past) < 10 or past.std() <= surprise.MIN_SPREAD:
                assert np.isnan(row[column])
            else:
                own = sums[list(rows).index(i)][k]
                assert np.isclose(row[column], (own - past.mean()) / past.std(), rtol=1e-3, atol=1e-3)
                checked_z += 1
    assert checked_z > 20


def test_transition_surprise_equals_the_slow_definition():
    """-log P(value | previous value) is the pair count over the previous-value count, pulled toward the plain share."""
    fitted = _fit()
    df = _table(seed=3)
    got = _build(df, fitted)
    account = timekeys.codes(df[settings.ACCOUNT_COL])
    secs = timekeys.seconds(df[settings.TIME_COL])
    start = lookback.lookback_start(secs)
    for name in TRANSITIONS:
        value = df[name].to_numpy()
        tables = fitted["transitions"][name]
        for i in range(0, len(df), 11):
            earlier = np.flatnonzero((account == account[i]) & (secs < secs[i]) & (secs >= start[i]) & ~pd.isna(value))
            if pd.isna(value[i]) or len(earlier) == 0:
                assert np.isnan(got[f"surprise_{name}_given_previous"].iloc[i])
                continue
            previous = value[earlier[secs[earlier] == secs[earlier].max()][-1]]
            pair = tables["pairs"]["counts"].get(f"{previous} > {value[i]}", 0)
            conditional = (pair + PRIOR * _share(fitted["fields"][name], str(value[i]))) / \
                          (tables["previous"]["counts"].get(str(previous), 0) + PRIOR)
            assert np.isclose(got[f"surprise_{name}_given_previous"].iloc[i], -np.log(conditional), rtol=1e-5)


def test_an_account_without_history_is_scored_like_the_population():
    """With no earlier row the account surprise equals the population surprise and the difference is zero."""
    df = _table(seed=4)
    got = _build(df, _fit())
    account = timekeys.codes(df[settings.ACCOUNT_COL])
    secs = timekeys.seconds(df[settings.TIME_COL])
    first = np.array([np.flatnonzero(account == a)[np.argmin(secs[account == a])] for a in np.unique(account)])
    assert np.allclose(got["surprise_account_sum"].iloc[first], got["surprise_population_sum"].iloc[first])
    assert np.allclose(got["surprise_diff_sum"].iloc[first], 0.0, atol=1e-6)
    assert got["surprise_gap_bin_account"].iloc[first].isna().all()              # no earlier row, so no gap
    assert got["surprise_account_z"].iloc[first].isna().all()
    # An account with a habit: its usual value is less surprising for it than for everyone, a break is more.
    hours = pd.Timestamp("2025-06-03") + pd.to_timedelta(np.arange(21), unit="h")
    habit = pd.DataFrame({settings.ACCOUNT_COL: "a", settings.TIME_COL: hours, settings.TYPE_COL: ["P"] * 20 + ["W"]})
    mixed = habit.assign(**{settings.TYPE_COL: ["P", "W"] * 10 + ["P"]})        # both values about equally common
    fitted = surprise.fit_surprise_tables(mixed, code_cols=[settings.TYPE_COL], transition_fields=())
    diff = surprise.build_surprise(habit, fitted, code_cols=[settings.TYPE_COL],
                                   transition_fields=())[f"surprise_{settings.TYPE_COL}_diff"]
    assert diff.iloc[19] < -0.5 and diff.iloc[20] > 1.0


def test_rows_of_the_same_second_do_not_see_each_other():
    """Two rows of one second with a new value are equally surprising; the next row has seen both."""
    df = pd.DataFrame({
        settings.ACCOUNT_COL: ["a"] * 4,
        settings.TIME_COL: pd.to_datetime(["2025-06-03 10:00:00", "2025-06-03 11:00:00", "2025-06-03 11:00:00",
                                           "2025-06-03 12:00:00"]),
        settings.TYPE_COL: ["P", "W", "W", "W"],
        settings.AMOUNT_COL: [10.0, 10.0, 10.0, 10.0],
    })
    fitted = surprise.fit_surprise_tables(df, code_cols=[settings.TYPE_COL], transition_fields=())
    got = surprise.build_surprise(df, fitted, code_cols=[settings.TYPE_COL], transition_fields=())
    share = _share(fitted["fields"][settings.TYPE_COL], "W")
    column = got[f"surprise_{settings.TYPE_COL}_account"]
    assert np.isclose(column.iloc[1], column.iloc[2])
    assert np.isclose(column.iloc[1], -np.log(PRIOR * share / (1 + PRIOR)))      # one earlier row, none with "W"
    assert np.isclose(column.iloc[3], -np.log((2 + PRIOR * share) / (3 + PRIOR)))


def test_later_rows_do_not_change_earlier_columns():
    """Dropping every row after the middle of the period leaves the columns of the rows before it unchanged."""
    df = _table(seed=5)
    fitted = _fit()
    secs = timekeys.seconds(df[settings.TIME_COL])
    keep = secs <= np.median(secs)
    assert np.allclose(_build(df, fitted)[keep].to_numpy(), _build(df[keep], fitted).to_numpy(), equal_nan=True)


def test_training_rows_get_what_scored_rows_get():
    """A December row in long files gets the columns, standardised sums included, of files that begin on 1 November."""
    df = _table(seed=6, n_accounts=15, days=92, start="2024-10-01")
    fitted = _fit()
    secs = timekeys.seconds(df[settings.TIME_COL])
    december = secs >= lookback.data_start("2024-12-01")
    cut = secs >= lookback.data_start("2024-11-01")
    long_files, short_files = _build(df, fitted), _build(df[cut], fitted)
    assert np.allclose(long_files[december].to_numpy(), short_files[december[cut]].to_numpy(), equal_nan=True)
    assert long_files.loc[december, "surprise_account_z"].notna().mean() > 0.5   # the comparison covers real values


def test_the_rows_own_account_can_be_left_out_of_the_population():
    """On the rows the tables were fitted on, the population share is that of the other accounts only."""
    df = _table(seed=7, n_accounts=12)
    fitted = surprise.fit_surprise_tables(df, code_cols=FIELDS, transition_fields=TRANSITIONS)
    got = _build(df, fitted, remove_own_account=True)
    plain = _build(df, fitted)
    account = timekeys.codes(df[settings.ACCOUNT_COL])
    kind = df[settings.TYPE_COL].to_numpy()
    distinct = len(fitted["fields"][settings.TYPE_COL]["counts"])
    for i in range(0, len(df), 17):
        others = account != account[i]
        share = ((kind[others] == kind[i]).sum() + 1.0) / (others.sum() + distinct + 1.0)
        assert np.isclose(got[f"surprise_{settings.TYPE_COL}_population"].iloc[i], -np.log(share), rtol=1e-5)
    assert (got[f"surprise_{settings.TYPE_COL}_population"] != plain[f"surprise_{settings.TYPE_COL}_population"]).any()
    assert np.isfinite(got.to_numpy()[~np.isnan(got.to_numpy())]).all()


def test_unseen_values_missing_values_and_unfitted_fields(capsys):
    """A never-seen value is finite and most surprising; a missing field adds nothing; an unfitted one is skipped."""
    fitted = _fit()
    df = _table(seed=8, n_accounts=6)
    df.loc[df.index[5], settings.TYPE_COL] = "never_seen_before"
    df.loc[df.index[6], list(FIELDS) + [settings.AMOUNT_COL]] = None
    capsys.readouterr()
    got = surprise.build_surprise(df, fitted, code_cols=FIELDS + (settings.MCC_COL, "absent_col"),
                                  transition_fields=TRANSITIONS)
    printed = capsys.readouterr().out
    assert printed.count("note:") == 2 and settings.MCC_COL in printed          # an absent column, an unfitted field
    population = got[f"surprise_{settings.TYPE_COL}_population"]
    assert np.isfinite(population.iloc[5]) and population.iloc[5] == population.max()
    assert got["surprise_fields_used"].iloc[6] <= 2                                # only the hour and maybe the gap
    assert np.isnan(got[f"surprise_{settings.TYPE_COL}_account"].iloc[6])
    assert not [c for c in got.columns if settings.MCC_COL in c]
    assert not _build(df, fitted, fill=0.0).isna().any().any()


def test_tables_can_be_saved_and_the_command_line_runs(tmp_path, capsys):
    """Tables written to a file give the same columns after reading, and the tool runs on made-up rows."""
    fitted = _fit()
    df = _table(seed=9, n_accounts=6)
    path = _shared.save_tables(fitted, str(tmp_path / "surprise.json"))
    reloaded = _build(df, _shared.load_tables(path))
    assert np.array_equal(_build(df, fitted).to_numpy(), reloaded.to_numpy(), equal_nan=True)
    saved = tmp_path / "demo_tables.json"
    first = surprise.main(["--demo", "--save-tables", str(saved)])
    again = surprise.main(["--demo", "--tables", str(saved), "--out", str(tmp_path / "surprise.parquet")])
    assert "surprise_account_sum" in capsys.readouterr().out
    assert np.array_equal(first.to_numpy(), again.to_numpy(), equal_nan=True)
    assert len(pd.read_parquet(tmp_path / "surprise.parquet")) == len(first)
