"""Tests of the earlier-row score columns.

Every column is compared with a plain loop over the earlier rows of each account. Further tests
check the time rule (rows of one second never see each other, later rows change nothing before
them), the empty positions, the optional parts and the tool.
"""
import numpy as np
import pandas as pd
import pytest
from scipy.special import expit

from additions import settings
from additions.common import synthetic, tables, timekeys
from additions.exports import phat_writer


@pytest.fixture(scope="module")
def scored():
    """Made-up whole account histories with a score, including rows that share a second."""
    return synthetic.make_scores(synthetic.make_transactions(n_accounts=80, seed=5, tie_share=0.08), seed=5)


@pytest.fixture(scope="module")
def written(scored):
    """The columns of every row of the made-up table, with the ids of the history rows."""
    return phat_writer.write_phats(scored, with_ids=True)


def _slow_history(account, secs, order, i, n_rows, max_age=None):
    """Row numbers of the latest earlier rows of row i, most recent first, from a plain look at the table."""
    earlier = np.flatnonzero((account == account[i]) & (secs < secs[i]))
    if max_age is not None:
        earlier = earlier[secs[earlier] >= secs[i] - max_age]
    # Most recent first: the latest second first, and inside one second the higher sequence number first.
    ranked = sorted(earlier, key=lambda j: (secs[j], order[j]), reverse=True)
    return ranked[:n_rows]


def test_layout_is_the_history_positions_then_the_empty_slot_and_the_count(scored, written):
    """The table has the keys, 17 history columns, one empty slot, the count and the 17 id columns."""
    assert len(phat_writer.HISTORY_COLUMNS) == phat_writer.HISTORY_ROWS == 17
    assert phat_writer.HISTORY_COLUMNS[0] == "phat_h1" and phat_writer.EMPTY_COLUMNS == ("phat_h18",)
    expected = ([settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL] + list(phat_writer.HISTORY_COLUMNS)
                + list(phat_writer.EMPTY_COLUMNS) + [phat_writer.COUNT_COLUMN] + list(phat_writer.ID_COLUMNS))
    assert list(written.columns) == expected and len(written) == len(scored)
    assert (written.index == scored.index).all()
    assert written["phat_h18"].isna().all() and written[list(phat_writer.HISTORY_COLUMNS)].dtypes.eq(np.float32).all()
    values = written[list(phat_writer.HISTORY_COLUMNS)].to_numpy(dtype=np.float64)
    have = values[~np.isnan(values)]
    assert len(have) and have.min() >= 0.0 and have.max() <= 1.0


def test_position_k_holds_the_kth_most_recent_earlier_row(scored, written):
    """Every position equals the score and id of the same row found by a plain loop; empty positions are missing."""
    account = scored[settings.ACCOUNT_COL].to_numpy()
    secs = timekeys.seconds(scored[settings.TIME_COL])
    order = scored[settings.ORDER_COL].to_numpy()
    score = scored[settings.SCORE_COL].to_numpy()
    ids = scored[settings.ID_COL].to_numpy()
    checked = 0
    for i in range(0, len(scored), 7):
        slow = _slow_history(account, secs, order, i, phat_writer.HISTORY_ROWS)
        assert written[phat_writer.COUNT_COLUMN].iloc[i] == len(slow)
        for k, name in enumerate(phat_writer.HISTORY_COLUMNS):
            got = written[name].iloc[i]
            if k < len(slow):
                assert np.isclose(got, score[slow[k]], rtol=1e-6), (i, k)
                assert written[phat_writer.ID_COLUMNS[k]].iloc[i] == ids[slow[k]]
            else:
                assert np.isnan(got) and written[phat_writer.ID_COLUMNS[k]].iloc[i] is None
        checked += 1
    assert checked > 200
    counts = written[phat_writer.COUNT_COLUMN]
    full = phat_writer.HISTORY_ROWS
    assert (counts == 0).any() and (counts == full).any() and ((counts > 0) & (counts < full)).any()


def test_rows_of_the_same_second_are_never_history():
    """Two rows of one second see only earlier seconds; the other account and missing times are never history."""
    df = pd.DataFrame({
        settings.ID_COL: [1, 2, 3, 4, 5, 6],
        settings.ACCOUNT_COL: ["a", "a", "a", "a", "b", "a"],
        settings.TIME_COL: pd.to_datetime([100, 200, 200, 300, 250, None], unit="s"),
        settings.ORDER_COL: [0, 1, 2, 3, 0, 4],
        settings.SCORE_COL: [0.1, 0.2, 0.3, 0.4, 0.9, 0.8],
    })
    out = phat_writer.write_phats(df, history_columns=["h1", "h2", "h3"], empty_columns=[], with_ids=True,
                                  id_columns=["i1", "i2", "i3"])
    assert out["phat_n"].tolist() == [0, 1, 1, 3, 0, 0]
    assert np.isclose(out["h1"].iloc[1], 0.1) and np.isclose(out["h1"].iloc[2], 0.1)    # second 200 sees second 100
    assert np.isnan(out["h2"].iloc[1]) and np.isnan(out["h2"].iloc[2])
    # Row 4 sees second 200 first, the row with the higher sequence number ahead, then second 100.
    assert np.allclose(out[["h1", "h2", "h3"]].iloc[3].to_numpy(dtype=float), [0.3, 0.2, 0.1])
    assert out[["i1", "i2", "i3"]].iloc[3].tolist() == [3, 2, 1]
    assert np.isnan(out["h1"].iloc[4]) and np.isnan(out["h1"].iloc[5])                  # other account; no time
    # The order of the table does not decide which same-second row is the more recent one.
    shuffled = phat_writer.write_phats(df.iloc[[3, 2, 1, 0, 5, 4]], history_columns=["h1", "h2", "h3"])
    assert np.allclose(shuffled.loc[3, ["h1", "h2", "h3"]].to_numpy(dtype=float), [0.3, 0.2, 0.1])


def test_later_rows_do_not_change_the_columns_of_earlier_rows(scored, written):
    """Cutting the table off at a point in time leaves every column of the rows before it as it was."""
    secs = timekeys.seconds(scored[settings.TIME_COL])
    keep = secs <= np.median(secs)
    part = phat_writer.write_phats(scored[keep])
    names = list(phat_writer.HISTORY_COLUMNS) + [phat_writer.COUNT_COLUMN]
    assert np.array_equal(part[names].to_numpy(dtype=np.float64), written.loc[keep, names].to_numpy(dtype=np.float64),
                          equal_nan=True)


def test_a_row_never_reads_its_own_score_or_any_label(scored, written):
    """Changing the scores of the target rows and dropping the label leaves the target rows' columns unchanged."""
    secs = timekeys.seconds(scored[settings.TIME_COL])
    last = secs == pd.Series(secs).groupby(scored[settings.ACCOUNT_COL].to_numpy()).transform("max").to_numpy()
    changed = scored.drop(columns=[settings.LABEL_COL]).copy()
    changed.loc[last, settings.SCORE_COL] = 0.999                       # the latest second of every account
    out = phat_writer.write_phats(changed, targets=last)
    names = list(phat_writer.HISTORY_COLUMNS)
    assert len(out) == int(last.sum())
    assert np.array_equal(out[names].to_numpy(dtype=np.float64), written.loc[last, names].to_numpy(dtype=np.float64),
                          equal_nan=True)


def test_max_age_and_logit_scores(scored):
    """A maximum age keeps only rows young enough, and scores stored as log-odds are written as probabilities."""
    account = scored[settings.ACCOUNT_COL].to_numpy()
    secs = timekeys.seconds(scored[settings.TIME_COL])
    order = scored[settings.ORDER_COL].to_numpy()
    logit = np.log(scored[settings.SCORE_COL]) - np.log1p(-scored[settings.SCORE_COL])
    as_logit = scored.assign(**{settings.SCORE_COL: logit})
    out = phat_writer.write_phats(as_logit, history_columns=["h1", "h2", "h3", "h4"], max_age=86_400,
                                  score_kind="logit")
    for i in range(0, len(scored), 23):
        slow = _slow_history(account, secs, order, i, 4, max_age=86_400)
        assert out["phat_n"].iloc[i] == len(slow)
        for k in range(4):
            want = expit(logit.iloc[slow[k]]) if k < len(slow) else np.nan
            assert np.isclose(out[f"h{k + 1}"].iloc[i], want, rtol=1e-6, equal_nan=True)


def test_tool_writes_the_columns_for_the_target_ids(scored, tmp_path, capsys):
    """The tool reads a prediction file and a list of target ids, prints a summary and writes the target rows."""
    pred_path = tables.write_table(scored, str(tmp_path / "pred.parquet"))
    wanted = scored[settings.ID_COL].iloc[::5]
    target_path = tables.write_table(pd.DataFrame({settings.ID_COL: wanted}), str(tmp_path / "targets.parquet"))
    out_path = str(tmp_path / "phats.parquet")
    frame = phat_writer.main(["--pred", pred_path, "--target-ids", target_path, "--with-ids", "--out", out_path])
    printed = capsys.readouterr().out
    assert "target rows" in printed and "phat_h1" in printed
    saved = tables.read_columns(out_path)
    assert len(saved) == len(wanted) and saved[settings.ID_COL].tolist() == wanted.tolist()
    assert np.allclose(saved["phat_h1"], frame["phat_h1"], equal_nan=True)
    assert len(phat_writer.main(["--demo"])) > 0
