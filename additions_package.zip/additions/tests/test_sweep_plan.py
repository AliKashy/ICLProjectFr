"""Tests of the sweep plan: the order of arms and the arithmetic of its cost."""
import pandas as pd

from additions.sweep import plan
from additions.sweep.arms import ARMS, TIERS, by_id


def test_arms_are_well_formed():
    """Ids are unique, tiers are known, and every dependency that names an arm exists."""
    ids = [a["id"] for a in ARMS]
    assert len(ids) == len(set(ids))
    tiers = {name for name, _ in TIERS}
    for arm in ARMS:
        assert arm["tier"] in tiers and arm["kind"] in ("read", "cpu", "gpu")
        assert (arm["runs"] == 0) if arm["kind"] != "gpu" else arm["runs"] >= 0
        for need in arm["needs"]:
            if " " not in need:                      # a single word is the id of another arm
                assert need in by_id(), (arm["id"], need)


def test_cheap_tiers_come_first_and_dependencies_are_respected():
    """Reads and CPU arms come before any training arm, and no arm runs before an arm it needs."""
    p = plan.sweep_plan()
    step = dict(zip(p["id"], p["step"]))
    first_training = p.loc[(p["kind"] == "gpu") & (p["tier"] != "control"), "step"].min()
    assert p.loc[p["kind"].isin(["read", "cpu"]), "step"].max() < first_training
    for arm in ARMS:
        for need in arm["needs"]:
            if need in step:
                assert step[need] < step[arm["id"]], (arm["id"], need)


def test_cost_adds_up():
    """Hours are runs times the time factor times the hours of one run; days divide by the GPUs."""
    p = plan.sweep_plan(hours_per_run=10.0)
    assert abs(p["gpu_hours"].sum() - 10.0 * sum(a["runs"] * a["time_factor"] for a in ARMS)) < 1e-9
    cost = plan.cost_summary(p, hours_per_run=10.0, gpus=4)
    total = cost.loc[cost["tier"] == "all"].iloc[0]
    assert abs(total["days_on_the_gpus"] - total["gpu_hours"] / 4 / 24) < 1e-9
    assert total["runs"] == sum(a["runs"] for a in ARMS)


def test_arms_can_be_left_out(capsys):
    """Skipped arms disappear from the plan, and the tool prints a table."""
    p = plan.sweep_plan(skip=["members", "same_second_order"])
    assert "members" not in set(p["id"]) and len(p) == len(ARMS) - 2
    assert plan.main(["--tiers", "reads"]) == 0
    assert "eligible_rows" in capsys.readouterr().out
