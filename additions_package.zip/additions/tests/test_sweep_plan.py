"""Tests of the sweep plan: the order of arms, the arithmetic of its cost, one arm for every configuration of the
template, and the counts that SWEEP.md quotes."""
import re
from pathlib import Path

import pandas as pd

from additions.model import best_model_template as bm
from additions.sweep import plan
from additions.sweep.arms import ARMS, TIERS, by_id


def test_arms_are_well_formed():
    """Ids are unique, tiers are known, and every dependency that names an arm exists."""
    ids = [a["id"] for a in ARMS]
    assert len(ids) == len(set(ids))
    tiers = {name for name, _ in TIERS}
    for arm in ARMS:
        assert arm["tier"] in tiers and arm["kind"] in ("read", "cpu", "gpu")
        assert (arm["runs"] == 0) if arm["kind"] != "gpu" else arm["runs"] >= 0
        for need in arm["needs"]:
            if " " not in need:                      # a single word is the id of another arm
                assert need in by_id(), (arm["id"], need)


def test_cheap_tiers_come_first_and_dependencies_are_respected():
    """Reads and CPU arms come before any training arm, and no arm runs before an arm it needs."""
    p = plan.sweep_plan()
    step = dict(zip(p["id"], p["step"]))
    first_training = p.loc[(p["kind"] == "gpu") & (p["tier"] != "control"), "step"].min()
    assert p.loc[p["kind"].isin(["read", "cpu"]), "step"].max() < first_training
    for arm in ARMS:
        for need in arm["needs"]:
            if need in step:
                assert step[need] < step[arm["id"]], (arm["id"], need)


def test_cost_adds_up():
    """Hours are runs times the time factor times the hours of one run; days divide by the GPUs."""
    p = plan.sweep_plan(hours_per_run=10.0)
    assert abs(p["gpu_hours"].sum() - 10.0 * sum(a["runs"] * a["time_factor"] for a in ARMS)) < 1e-9
    cost = plan.cost_summary(p, hours_per_run=10.0, gpus=4)
    total = cost.loc[cost["tier"] == "all"].iloc[0]
    assert abs(total["days_on_the_gpus"] - total["gpu_hours"] / 4 / 24) < 1e-9
    assert total["runs"] == sum(a["runs"] for a in ARMS)


def test_arms_can_be_left_out(capsys):
    """Skipped arms disappear from the plan, and the tool prints a table."""
    p = plan.sweep_plan(skip=["members", "same_second_order"])
    assert "members" not in set(p["id"]) and len(p) == len(ARMS) - 2
    assert plan.main(["--tiers", "reads"]) == 0
    assert "eligible_rows" in capsys.readouterr().out


def test_every_arm_of_the_template_is_one_arm_of_the_sweep():
    """Every entry of ARMS in best_model_template.py is one arm of the model tier under its name in lower case, with
    its change against the arm it is set against, its question, and the entry named in what switches it on; TODAY is
    the control. The changes of one entry run after the candidate, the head-to-head after the control."""
    arms = by_id()
    assert "TODAY" in bm.ARMS and 'ARMS["TODAY"]' in arms["control"]["how_to_switch_on"]
    names = [name for name in bm.ARMS if name != "TODAY"]
    configured = [arm["id"] for arm in ARMS
                  if "best_model_template" in arm["how_to_switch_on"] and arm["id"] != "control"]
    assert configured == [name.lower() for name in names]
    for name in names:
        arm = arms[name.lower()]
        assert (arm["tier"], arm["kind"]) == ("model", "gpu"), name
        assert f'ARMS["{name}"]' in arm["how_to_switch_on"], name
        assert bm.arm_change(name) in arm["changes"] and bm.ARMS[name].question in arm["changes"], name
        assert f"Against {bm.ARMS[name].against}:" in arm["changes"], name
        assert "model/best_model_template.py" in arm["files"] and arm["time_factor"] > 0, name
        head_to_head = name in ("WIDE_JOINED", "CANDIDATE")
        assert arm["needs"] == (("control",) if head_to_head else ("candidate",)), name
        assert arm["runs"] == (2 if head_to_head else 1), name


def test_sweep_md_quotes_the_counts_of_the_plan():
    """The runs and control-run equivalents that SWEEP.md quotes for the whole sweep are those of the plan, and so are
    its GPU hours and days at 20 hours a run."""
    text = " ".join((Path(plan.__file__).parents[1] / "SWEEP.md").read_text().split())
    found = re.search(r"the sweep is ([\d,]+) training runs, which take as long as ([\d,.]+) control runs", text)
    assert found, "SWEEP.md must state the runs and the control-run equivalents of the whole sweep"
    runs, equivalents = int(found.group(1).replace(",", "")), float(found.group(2).replace(",", ""))
    total = plan.cost_summary(plan.sweep_plan(), hours_per_run=20.0, gpus=4)
    total = total.loc[total["tier"] == "all"].iloc[0]
    assert runs == int(total["runs"]) and abs(equivalents - total["run_equivalents"]) < 0.05
    hours = f"{total['gpu_hours']:,.0f} GPU hours"
    assert hours in text, hours
