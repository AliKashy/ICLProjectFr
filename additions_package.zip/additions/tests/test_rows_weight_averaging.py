"""Tests of the weight averages.

The averages are compared with the slow formula over a few training steps of a small model,
the swap is shown to leave the trained model exactly as it was, and a checkpoint round trip
is checked.
"""
import torch
import torch.nn as nn

from additions import settings
from additions.common import synthetic
from additions.training.weight_averaging import ExponentialAverage, RunningAverage


def _model(seed=0):
    """A small model with a normalisation layer, so that it has float and whole-number buffers."""
    torch.manual_seed(seed)
    return nn.Sequential(nn.Linear(6, 8), nn.BatchNorm1d(8), nn.ReLU(), nn.Linear(8, 1))


def _batches(n=6, seed=0):
    """Small batches from made-up transactions: a few numeric columns and the fraud label."""
    df = synthetic.make_transactions(n_accounts=20, seed=seed, days=10)
    names = [settings.AMOUNT_COL, settings.VISA_SCORE_COL, settings.BALANCE_COL, settings.MERCH_LIMIT_COL,
             settings.CASH_LIMIT_COL, settings.ORDER_COL]
    x = torch.tensor(df[names].to_numpy(dtype="float32"))
    x = (x - x.mean(0)) / (x.std(0) + 1e-6)
    y = torch.tensor(df[settings.LABEL_COL].to_numpy(dtype="float32"))
    size = len(x) // n
    return [(x[i * size:(i + 1) * size], y[i * size:(i + 1) * size]) for i in range(n)]


def _train(model, average, steps, every_step=True):
    """A few optimiser steps; returns a snapshot of the weights after every step."""
    optimiser = torch.optim.SGD(model.parameters(), lr=0.5)
    snapshots = []
    for i, (x, y) in enumerate(_batches(steps)):
        loss = nn.functional.binary_cross_entropy_with_logits(model(x).squeeze(-1), y)
        optimiser.zero_grad()
        loss.backward()
        optimiser.step()
        if every_step:
            average.update(model)
        else:
            average.update(model, epoch=i)
        snapshots.append({k: v.detach().clone() for k, v in model.state_dict().items()})
    return snapshots


def test_exponential_average_equals_the_slow_formula():
    """After each step the average is decay_n * old + (1 - decay_n) * new, with the warm-up decay."""
    model = _model()
    start = {k: v.detach().clone() for k, v in model.state_dict().items()}
    average = ExponentialAverage(model, decay=0.9, warmup=True)
    snapshots = _train(model, average, steps=5)
    slow = {k: v.clone() for k, v in start.items()}
    for n, snap in enumerate(snapshots):
        d = min(0.9, (1 + n) / (10 + n))
        for k, v in snap.items():
            slow[k] = d * slow[k] + (1 - d) * v if torch.is_floating_point(v) else v.clone()
    for k in slow:
        assert torch.allclose(average.average[k], slow[k], atol=1e-6), k
    assert average.average["1.num_batches_tracked"] == snapshots[-1]["1.num_batches_tracked"]
    assert average.updates == 5
    # A decay of zero is a plain copy of the latest weights.
    copy = ExponentialAverage(model, decay=0.0, warmup=False)
    copy.update(model)
    assert all(torch.equal(copy.average[k], v) for k, v in model.state_dict().items())


def test_running_average_is_the_mean_of_the_counted_snapshots():
    """The running average equals the plain mean of the snapshots from the start epoch on."""
    model = _model(seed=1)
    average = RunningAverage(model, start_epoch=2)
    snapshots = _train(model, average, steps=6, every_step=False)
    counted = snapshots[2:]
    for k, v in average.average.items():
        if torch.is_floating_point(v):
            assert torch.allclose(v, torch.stack([s[k] for s in counted]).mean(0), atol=1e-6), k
    assert average.updates == 4


def test_swap_scores_the_average_and_restores_the_trained_weights():
    """Inside the block the model gives the averaged output; afterwards the trained output is back unchanged."""
    model = _model(seed=2)
    average = ExponentialAverage(model, decay=0.9)
    _train(model, average, steps=4)
    model.eval()
    x = torch.randn(10, 6, generator=torch.Generator().manual_seed(0))
    before = model(x).detach()
    averaged_model = _model(seed=2).eval()
    average.copy_to(averaged_model)
    with average.swapped(model):
        inside = model(x).detach()
    assert torch.allclose(inside, averaged_model(x).detach())
    assert not torch.allclose(inside, before)
    assert torch.equal(model(x).detach(), before)
    try:
        with average.swapped(model):
            raise RuntimeError("validation failed")
    except RuntimeError:
        pass
    assert torch.equal(model(x).detach(), before)
    # Training the model further does not move the average until update is called.
    kept = {k: v.clone() for k, v in average.average.items()}
    with torch.no_grad():
        model[0].weight.add_(1.0)
    assert all(torch.equal(kept[k], average.average[k]) for k in kept)
    assert all(not v.requires_grad for v in average.average.values())


def test_checkpoint_round_trip():
    """state_dict and load_state_dict restore the average and the count exactly."""
    model = _model(seed=3)
    average = ExponentialAverage(model, decay=0.95)
    _train(model, average, steps=3)
    state = average.state_dict()
    fresh = ExponentialAverage(_model(seed=4), decay=0.95)
    fresh.load_state_dict(state)
    assert fresh.updates == 3 and fresh.current_decay() == average.current_decay()
    assert all(torch.equal(fresh.average[k], average.average[k]) for k in average.average)
