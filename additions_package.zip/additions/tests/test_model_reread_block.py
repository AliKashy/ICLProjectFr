"""Tests of the block in which a row reads its own fields again after history.

The tests check that a fresh block is an exact no-op, that the zero-initialised write-back
layer still receives a gradient, that a row reads only its own fields, the shapes with and
without the projection into segments, and the scoring route.
"""
import torch

from additions.model.reread_block import RereadBlock

D, HEADS = 16, 4


def _block(width=3 * D, dropout=0.0, **kwargs):
    """A small re-read block with no dropout unless asked."""
    torch.manual_seed(0)
    return RereadBlock(width=width, field_dim=D, num_heads=HEADS, dropout=dropout, **kwargs)


def _switched_on(block):
    """The same block with a write-back layer that is no longer zero, as after some training."""
    torch.manual_seed(1)
    with torch.no_grad():
        block.write_back.weight.normal_(std=0.1)
        block.write_back.bias.normal_(std=0.1)
    return block


def test_a_fresh_block_leaves_the_history_vector_unchanged():
    """With its zero-initialised write-back layer the block returns its input exactly."""
    history = torch.randn(2, 5, 3 * D)
    fields = torch.randn(2, 5, 7, D)
    assert torch.equal(_block()(history, fields), history)


def test_shapes_and_finite_values():
    """The output has the width of the history vector, with and without a projection into segments."""
    fields = torch.randn(2, 5, 7, D)
    block = _switched_on(_block())
    assert block.num_segments == 3 and isinstance(block.to_segments, torch.nn.Identity)
    out = block(torch.randn(2, 5, 3 * D), fields)
    assert out.shape == (2, 5, 3 * D) and torch.isfinite(out).all()
    odd = _switched_on(_block(width=40))                                # not a multiple of 16: three segments
    assert odd.num_segments == 3 and isinstance(odd.to_segments, torch.nn.Linear)
    out = odd(torch.randn(2, 5, 40), fields)
    assert out.shape == (2, 5, 40) and torch.isfinite(out).all()
    two = _switched_on(_block(width=40, num_segments=2))
    assert two(torch.randn(4, 40), torch.randn(4, 7, D)).shape == (4, 40)


def test_a_row_reads_only_its_own_fields():
    """Changing other rows' fields and history vectors leaves a row's output unchanged."""
    block = _switched_on(_block()).eval()
    history = torch.randn(2, 6, 3 * D)
    fields = torch.randn(2, 6, 7, D)
    altered_h, altered_f = history.clone(), fields.clone()
    altered_h[:, 3:] = torch.randn(2, 3, 3 * D)
    altered_f[:, 3:] = torch.randn(2, 3, 7, D) * 4
    with torch.no_grad():
        before, after = block(history, fields), block(altered_h, altered_f)
    assert torch.allclose(before[:, :3], after[:, :3], atol=1e-6)
    # The row's own fields do matter once the block is switched on.
    own = fields.clone()
    own[0, 0] = torch.randn(7, D)
    with torch.no_grad():
        moved = block(history, own)
    assert not torch.allclose(before[0, 0], moved[0, 0])


def test_the_zero_start_still_receives_a_gradient():
    """At the zero start the write-back layer gets a gradient; after it moves, the inner layers get one too."""
    block = _block(dropout=0.1).train()
    history = torch.randn(2, 4, 3 * D)
    fields = torch.randn(2, 4, 5, D)
    block(history, fields).pow(2).mean().backward()
    assert block.write_back.weight.grad.abs().sum() > 0
    block.zero_grad()
    _switched_on(block)
    block(history, fields).pow(2).mean().backward()
    assert block.attend.in_proj_weight.grad.abs().sum() > 0
    assert block.feed_forward[0].weight.grad.abs().sum() > 0


def test_scoring_route_agrees_with_training_at_dropout_zero():
    """Evaluation mode under torch.no_grad() gives the training-mode output at dropout zero."""
    block = _switched_on(_block(dropout=0.0))
    history = torch.randn(3, 4, 3 * D)
    fields = torch.randn(3, 4, 6, D)
    train_out = block.train()(history, fields)
    with torch.no_grad():
        eval_out = block.eval()(history, fields)
    assert torch.allclose(train_out, eval_out, atol=1e-5)
