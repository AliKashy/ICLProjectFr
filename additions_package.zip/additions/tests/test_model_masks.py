"""Tests of the strict time rule as an attention mask.

The visibility is compared with a slow loop over every pair of rows of a real batch built
from made-up transactions. Hand-made sequences check the cases that matter most: rows of one
second, padding, and positions put in front of the rows. The last tests hold the one rule for
whole seconds together across this file, the memory of interleaved_reread.py, the attention bias
and the channel stage: units written as floats, units with a fraction, float times, and number
types that cannot hold a time of today.
"""
import math

import numpy as np
import pytest
import torch

from additions.common import synthetic
from additions.model import interleaved_reread as ir
from additions.model import masks
from additions.model._shared import sequences_from_table
from additions.model.attention_bias import AttentionBias
from additions.model.latent_channels import LatentChannelStage


def _batch(seed=0, n_accounts=12):
    """A padded batch of made-up transactions, with same-second rows and padding."""
    df = synthetic.make_transactions(n_accounts=n_accounts, days=20, seed=seed, tie_share=0.15)
    batch, _, _ = sequences_from_table(df, seconds_per_sequence=8)
    return batch


def test_visibility_equals_a_slow_loop():
    """Every entry of the visibility equals the rule written out pair by pair."""
    batch = _batch()
    times, valid = batch["time_seq"], batch["mask"]
    got = masks.strict_visibility(times, valid)
    B, T = times.shape
    t, v = times.numpy(), valid.numpy()
    expected = np.zeros((B, T, T), dtype=bool)
    for b in range(B):
        for i in range(T):
            for j in range(T):
                expected[b, i, j] = (i == j) or (v[b, i] and v[b, j] and t[b, j] < t[b, i])
    assert got.shape == (B, T, T) and got.dtype == torch.bool
    assert np.array_equal(got.numpy(), expected)
    # The made-up batch really holds rows of one second, so the test covers them.
    same_second = (t[:, :, None] == t[:, None, :]) & v[:, :, None] & v[:, None, :] & ~np.eye(T, dtype=bool)
    assert same_second.any()


def test_rows_of_one_second_do_not_see_each_other():
    """Two rows of one second read neither each other nor anything later; both read the earlier row."""
    times = torch.tensor([[100, 105, 105, 110, 0]])
    valid = torch.tensor([[True, True, True, True, False]])
    allowed = masks.strict_visibility(times, valid)[0]
    assert not allowed[1, 2] and not allowed[2, 1]
    assert allowed[1, 0] and allowed[2, 0]
    assert allowed[3, :3].all()
    assert not allowed[0, 1:].any()


def test_padding_reads_only_itself_and_is_read_by_no_row():
    """A padded slot carries time 0, which is earlier than every real row, and still stays out of every history."""
    times = torch.tensor([[100, 200, 0, 0]])
    valid = torch.tensor([[True, True, False, False]])
    allowed = masks.strict_visibility(times, valid)[0]
    assert not allowed[:, 2].logical_and(torch.tensor([True, True, False, True])).any()
    assert not allowed[:, 3].logical_and(torch.tensor([True, True, True, False])).any()
    assert allowed[2].tolist() == [False, False, True, False]
    assert allowed[3].tolist() == [False, False, False, True]


def test_whole_seconds_floors_other_units():
    """Times in nanoseconds count as whole seconds, and times before 1970 fall into the right second."""
    ns = torch.tensor([[1_500_000_000, 1_900_000_000, 2_000_000_000, -500_000_000]])
    assert masks.whole_seconds(ns, units_per_second=1_000_000_000).tolist() == [[1, 1, 2, -1]]
    # Two rows a fraction of a second apart share their second, so neither reads the other.
    allowed = masks.strict_visibility(ns[:, :2], torch.tensor([[True, True]]), units_per_second=1_000_000_000)
    assert allowed[0].tolist() == [[True, False], [False, True]]


def test_attention_mask_layout_and_open_diagonal():
    """The float mask is zero where reading is allowed, minus infinity elsewhere, one copy per head."""
    batch = _batch(seed=1)
    allowed = masks.strict_visibility(batch["time_seq"], batch["mask"])
    heads = 4
    mask = masks.to_attention_mask(allowed, heads)
    B, T, _ = allowed.shape
    assert mask.shape == (B * heads, T, T) and mask.dtype == torch.float32
    for b in range(B):
        for h in range(heads):
            copy = mask[b * heads + h]
            assert torch.equal(copy == 0, allowed[b])
            assert torch.isinf(copy[~allowed[b]]).all() and (copy[~allowed[b]] < 0).all()
    # A row whose every entry is closed still keeps its diagonal open, so a softmax never sees only -inf.
    closed = torch.zeros(1, 3, 3, dtype=torch.bool)
    opened = masks.to_attention_mask(closed, 2)
    assert torch.equal(torch.diagonal(opened, dim1=-2, dim2=-1), torch.zeros(2, 3))
    weights = torch.softmax(torch.randn(2, 3, 3) + opened, dim=-1)
    assert torch.isfinite(weights).all()


def test_softmax_over_a_real_batch_is_finite_on_every_row():
    """Attention weights under the mask are finite on real and padded rows alike."""
    batch = _batch(seed=2)
    mask = masks.to_attention_mask(masks.strict_visibility(batch["time_seq"], batch["mask"]), 2)
    weights = torch.softmax(torch.randn(mask.shape) + mask, dim=-1)
    assert torch.isfinite(weights).all()
    assert torch.allclose(weights.sum(-1), torch.ones(weights.shape[:-1]))


def test_prefix_is_read_by_every_row_and_reads_only_itself():
    """Positions in front are open to every row, read only themselves, and leave the rows' answers as they were."""
    batch = _batch(seed=3)
    allowed = masks.strict_visibility(batch["time_seq"], batch["mask"])
    p = 2
    out = masks.with_prefix(allowed, p)
    B, T, _ = allowed.shape
    assert out.shape == (B, p + T, p + T)
    assert torch.equal(out[:, p:, p:], allowed)
    assert out[:, p:, :p].all()
    assert torch.equal(out[:, :p, :], torch.eye(p, p + T, dtype=torch.bool).expand(B, -1, -1))
    # No prefix at all gives the same answers back.
    assert torch.equal(masks.with_prefix(allowed, 0), allowed)


# --------------------------------------------------------------------------------- one rule for whole seconds

def _today(seed=0, B=4, T=14):
    """Whole seconds of today (about 1.7e9) with ties, and a mask of real rows with padding at the end of each row."""
    g = torch.Generator().manual_seed(seed)
    steps = torch.randint(0, 3, (B, T), generator=g)                     # steps of zero put rows in one second
    seconds = 1_700_000_000 + torch.cumsum(steps, dim=1)
    lengths = torch.randint(T // 2, T + 1, (B,), generator=g)
    valid = torch.arange(T).unsqueeze(0) < lengths.unsqueeze(1)
    return seconds, valid, g


def _every_rule(times, valid, unit):
    """What every piece makes of the times: the whole seconds of both files, the visibility of the mask, the eligible
    rows and the latest earlier rows under both ties of the memory, and the bias of an AttentionBias with random
    weights (the time-gap buckets and the how-often count both read the rule)."""
    torch.manual_seed(0)
    block = AttentionBias(2, num_heads=3, units_per_second=unit)
    with torch.no_grad():
        for weight in block.parameters():
            weight.normal_()
    codes = torch.randint(-1, 3, (*valid.shape, 2), generator=torch.Generator().manual_seed(1))
    with torch.no_grad():
        bias = block(codes, times, valid)
    return {"masks": masks.whole_seconds(times, unit), "memory": ir._whole_seconds(times, unit),
            "visible": masks.strict_visibility(times, valid, unit), "eligible": ir.eligible_rows(times, valid, unit),
            "slot": ir.latest_prior_rows(times, valid, 4, unit, ties="slot"),
            "whole": ir.latest_prior_rows(times, valid, 4, unit, ties="whole_seconds"), "bias": bias}


def _agree(got, want, case):
    """Every piece of `got` equals the same piece of `want`, to the bit (the whole seconds by value)."""
    assert torch.equal(got["masks"].double(), want["masks"].double()), case
    assert torch.equal(got["memory"].double(), want["memory"].double()), case
    assert torch.equal(got["masks"].double(), got["memory"].double()), case
    T = got["eligible"].shape[-1]
    # The mask is the eligible rows and the row itself; nothing else may differ between the two.
    assert torch.equal(got["visible"], got["eligible"] | torch.eye(T, dtype=torch.bool)), case
    for name in ("visible", "eligible"):
        assert torch.equal(got[name], want[name]), (case, name)
    for name in ("slot", "whole"):
        assert all(torch.equal(a, b) for a, b in zip(got[name], want[name])), (case, name)
    allowed = want["visible"].unsqueeze(1).expand_as(want["bias"])
    assert torch.equal(got["bias"][allowed], want["bias"][allowed]), case


def test_the_mask_the_memory_and_the_bias_follow_one_rule_for_whole_seconds():
    """Nanosecond times of today (about 1.7e18) with the unit 10**9 or 1e9 give, in every piece, exactly what the
    whole seconds give with the unit 1; a unit with a fraction gives in every piece what its floored seconds give; and
    float seconds with fractions are floored, also with the unit 1, so rows a fraction apart share their second."""
    seconds, valid, g = _today()
    # Within its second a row lies anywhere, its first and its last nanosecond included.
    inside = torch.randint(0, 10 ** 9, seconds.shape, generator=g)
    inside[:, 0], inside[:, 1] = 0, 10 ** 9 - 1
    ns = seconds * 10 ** 9 + inside
    # The mask of stage 2 itself first: the float unit and the float times give the whole seconds.
    assert torch.equal(masks.whole_seconds(ns, 1e9), seconds)
    assert torch.equal(masks.strict_visibility(ns, valid, 1e9), masks.strict_visibility(seconds, valid))
    assert torch.equal(masks.strict_visibility(seconds.double() + 0.5, valid), masks.strict_visibility(seconds, valid))
    want = _every_rule(seconds, valid, 1)
    for unit in (10 ** 9, 1e9, 1000000000.0):
        got = _every_rule(ns, valid, unit)
        assert got["masks"].dtype == torch.int64 and torch.equal(got["masks"], seconds), unit
        _agree(got, want, unit)
    # A float unit divided in 32-bit numbers, as the first version of masks.py did, puts rows into other seconds here,
    # so the equalities above test something.
    old = torch.div(ns, 1e9, rounding_mode="floor")
    assert old.dtype == torch.float32 and not torch.equal(old.to(torch.int64), seconds)
    # A unit with a fraction: every piece follows the 64-bit floored seconds, which are those of the unit 1 on them.
    odd = 999_999_999.5
    floored = torch.floor(ns.double() / odd)
    assert floored.dtype == torch.float64 and torch.equal(masks.whole_seconds(ns, odd), floored)
    _agree(_every_rule(ns, valid, odd), _every_rule(floored.long(), valid, 1), "unit with a fraction")
    # Float seconds with fractions: floored with the unit 1, as with a unit of 1000 on their milliseconds.
    fraction = torch.rand(seconds.shape, generator=g, dtype=torch.float64) * 0.999
    float_seconds = seconds.double() + fraction
    assert not torch.equal(float_seconds, seconds.double())
    got = _every_rule(float_seconds, valid, 1)
    assert got["masks"].dtype == torch.float64
    _agree(got, want, "float seconds")
    ms = seconds * 1000 + (fraction * 1000).long()
    _agree(_every_rule(ms, valid, 1000), want, "milliseconds")


def test_two_rows_a_fraction_of_a_second_apart_never_read_each_other():
    """Float times 100.2 and 100.7 lie in one second: neither row reads the other in the mask, the memory or the bias,
    and the time gap between either of them and the row of second 101 falls in the bucket of one second."""
    times = torch.tensor([[100.2, 100.7, 101.5]], dtype=torch.float64)
    valid = torch.ones(1, 3, dtype=torch.bool)
    assert not masks.strict_visibility(times, valid)[0, 1, 0]
    assert not ir.eligible_rows(times, valid)[0, 1, 0]
    index, exists = ir.latest_prior_rows(times, valid, 2)
    assert not exists[0, 1].any() and exists[0, 2].tolist() == [True, True]
    block = AttentionBias(0, num_heads=1, units_per_second=1, gap_edges=(1, 2))
    with torch.no_grad():
        block.gap_weight.copy_(torch.tensor([[0.0, 1.0, 2.0]]))
        bias = block(torch.zeros(1, 3, 0, dtype=torch.long), times, valid)[0, 0]
    assert bias[2, 0] == 1.0 and bias[2, 1] == 1.0                     # one whole second back, not 1.3 or 0.8


def test_times_in_short_floats_stop_with_a_plain_error_in_every_piece():
    """float32, float16 and bfloat16 cannot hold the second of a time of today; every piece that reads the times says
    so and names int64, while int64 and float64 times run."""
    seconds, valid, _ = _today(seed=2, B=2, T=6)
    stage = LatentChannelStage(channel_dim=8, num_channels=2, num_heads=2, num_pairs=1, history_len=6, num_back=2,
                               num_fields=3)
    channels, fields = torch.randn(2, 6, 2, 8), torch.randn(2, 6, 3, 8)
    block = AttentionBias(0, num_heads=2)
    calls = {"masks.whole_seconds": lambda t: masks.whole_seconds(t),
             "strict_visibility": lambda t: masks.strict_visibility(t, valid),
             "_whole_seconds": lambda t: ir._whole_seconds(t),
             "eligible_rows": lambda t: ir.eligible_rows(t, valid),
             "latest_prior_rows": lambda t: ir.latest_prior_rows(t, valid, 2, ties="whole_seconds"),
             "AttentionBias": lambda t: block(torch.zeros(2, 6, 0, dtype=torch.long), t, valid),
             "LatentChannelStage": lambda t: stage(channels, fields, t, valid)}
    for name, call in calls.items():
        for dtype in (torch.float32, torch.float16, torch.bfloat16):
            with pytest.raises(ValueError, match="int64"):
                call(seconds.to(dtype))
        for dtype in (torch.int64, torch.float64):
            call(seconds.to(dtype))                                    # runs
    # The steps of a 32-bit float near 1.7e9 really are 128 seconds wide.
    assert float(torch.tensor(1_700_000_000.0) + 63) == 1_700_000_000.0


def test_a_whole_unit_becomes_an_int_and_a_unit_that_cannot_work_stops():
    """1e9 written as a float is the int 10**9 in the mask, the memory, the bias and the stage; a unit with a fraction
    stays a float; zero, a negative number and a value that is not a number stop with a plain error."""
    for unit in (1e9, 10 ** 9, np.int64(10 ** 9), 1000000000.0):
        assert masks._unit(unit) == 10 ** 9 and type(masks._unit(unit)) is int
        assert ir._unit(unit) == 10 ** 9 and type(ir._unit(unit)) is int
        assert type(AttentionBias(0, num_heads=1, units_per_second=unit).units_per_second) is int
        stage = LatentChannelStage(channel_dim=8, num_channels=2, num_heads=2, num_pairs=1, units_per_second=unit,
                                   time_bias=True)
        assert stage.units_per_second == stage.time_bias.units_per_second == 10 ** 9
    assert masks._unit(2.5) == 2.5 and ir._unit(2.5) == 2.5
    for bad in (0, -1, float("nan"), float("inf")):
        for unit_of in (masks._unit, ir._unit):
            with pytest.raises(ValueError, match="units_per_second"):
                unit_of(bad)
    assert math.isclose(masks.whole_seconds(torch.tensor([[5]]), 2.5).item(), 2.0)
