"""Tests of the strict time rule as an attention mask.

The visibility is compared with a slow loop over every pair of rows of a real batch built
from made-up transactions. Hand-made sequences check the cases that matter most: rows of one
second, padding, and positions put in front of the rows.
"""
import numpy as np
import torch

from additions.common import synthetic
from additions.model import masks
from additions.model._shared import sequences_from_table


def _batch(seed=0, n_accounts=12):
    """A padded batch of made-up transactions, with same-second rows and padding."""
    df = synthetic.make_transactions(n_accounts=n_accounts, days=20, seed=seed, tie_share=0.15)
    batch, _, _ = sequences_from_table(df, seconds_per_sequence=8)
    return batch


def test_visibility_equals_a_slow_loop():
    """Every entry of the visibility equals the rule written out pair by pair."""
    batch = _batch()
    times, valid = batch["time_seq"], batch["mask"]
    got = masks.strict_visibility(times, valid)
    B, T = times.shape
    t, v = times.numpy(), valid.numpy()
    expected = np.zeros((B, T, T), dtype=bool)
    for b in range(B):
        for i in range(T):
            for j in range(T):
                expected[b, i, j] = (i == j) or (v[b, i] and v[b, j] and t[b, j] < t[b, i])
    assert got.shape == (B, T, T) and got.dtype == torch.bool
    assert np.array_equal(got.numpy(), expected)
    # The made-up batch really holds rows of one second, so the test covers them.
    same_second = (t[:, :, None] == t[:, None, :]) & v[:, :, None] & v[:, None, :] & ~np.eye(T, dtype=bool)
    assert same_second.any()


def test_rows_of_one_second_do_not_see_each_other():
    """Two rows of one second read neither each other nor anything later; both read the earlier row."""
    times = torch.tensor([[100, 105, 105, 110, 0]])
    valid = torch.tensor([[True, True, True, True, False]])
    allowed = masks.strict_visibility(times, valid)[0]
    assert not allowed[1, 2] and not allowed[2, 1]
    assert allowed[1, 0] and allowed[2, 0]
    assert allowed[3, :3].all()
    assert not allowed[0, 1:].any()


def test_padding_reads_only_itself_and_is_read_by_no_row():
    """A padded slot carries time 0, which is earlier than every real row, and still stays out of every history."""
    times = torch.tensor([[100, 200, 0, 0]])
    valid = torch.tensor([[True, True, False, False]])
    allowed = masks.strict_visibility(times, valid)[0]
    assert not allowed[:, 2].logical_and(torch.tensor([True, True, False, True])).any()
    assert not allowed[:, 3].logical_and(torch.tensor([True, True, True, False])).any()
    assert allowed[2].tolist() == [False, False, True, False]
    assert allowed[3].tolist() == [False, False, False, True]


def test_whole_seconds_floors_other_units():
    """Times in nanoseconds count as whole seconds, and times before 1970 fall into the right second."""
    ns = torch.tensor([[1_500_000_000, 1_900_000_000, 2_000_000_000, -500_000_000]])
    assert masks.whole_seconds(ns, units_per_second=1_000_000_000).tolist() == [[1, 1, 2, -1]]
    # Two rows a fraction of a second apart share their second, so neither reads the other.
    allowed = masks.strict_visibility(ns[:, :2], torch.tensor([[True, True]]), units_per_second=1_000_000_000)
    assert allowed[0].tolist() == [[True, False], [False, True]]


def test_attention_mask_layout_and_open_diagonal():
    """The float mask is zero where reading is allowed, minus infinity elsewhere, one copy per head."""
    batch = _batch(seed=1)
    allowed = masks.strict_visibility(batch["time_seq"], batch["mask"])
    heads = 4
    mask = masks.to_attention_mask(allowed, heads)
    B, T, _ = allowed.shape
    assert mask.shape == (B * heads, T, T) and mask.dtype == torch.float32
    for b in range(B):
        for h in range(heads):
            copy = mask[b * heads + h]
            assert torch.equal(copy == 0, allowed[b])
            assert torch.isinf(copy[~allowed[b]]).all() and (copy[~allowed[b]] < 0).all()
    # A row whose every entry is closed still keeps its diagonal open, so a softmax never sees only -inf.
    closed = torch.zeros(1, 3, 3, dtype=torch.bool)
    opened = masks.to_attention_mask(closed, 2)
    assert torch.equal(torch.diagonal(opened, dim1=-2, dim2=-1), torch.zeros(2, 3))
    weights = torch.softmax(torch.randn(2, 3, 3) + opened, dim=-1)
    assert torch.isfinite(weights).all()


def test_softmax_over_a_real_batch_is_finite_on_every_row():
    """Attention weights under the mask are finite on real and padded rows alike."""
    batch = _batch(seed=2)
    mask = masks.to_attention_mask(masks.strict_visibility(batch["time_seq"], batch["mask"]), 2)
    weights = torch.softmax(torch.randn(mask.shape) + mask, dim=-1)
    assert torch.isfinite(weights).all()
    assert torch.allclose(weights.sum(-1), torch.ones(weights.shape[:-1]))


def test_prefix_is_read_by_every_row_and_reads_only_itself():
    """Positions in front are open to every row, read only themselves, and leave the rows' answers as they were."""
    batch = _batch(seed=3)
    allowed = masks.strict_visibility(batch["time_seq"], batch["mask"])
    p = 2
    out = masks.with_prefix(allowed, p)
    B, T, _ = allowed.shape
    assert out.shape == (B, p + T, p + T)
    assert torch.equal(out[:, p:, p:], allowed)
    assert out[:, p:, :p].all()
    assert torch.equal(out[:, :p, :], torch.eye(p, p + T, dtype=torch.bool).expand(B, -1, -1))
    # No prefix at all gives the same answers back.
    assert torch.equal(masks.with_prefix(allowed, 0), allowed)
