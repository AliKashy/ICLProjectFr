"""Tests of the look-ahead teacher.

The visibility rule is compared entry by entry with a slow loop over pairs of rows, for the
strict rule and for both kinds of band. The two history stages are then checked against the
time rule: the causal one, after some training, does not move when later rows change or are
cut off, and the teacher does. The delay of the second-look score and the student's loss are
compared with slow computations as well.
"""
import numpy as np
import torch
import torch.nn.functional as F

from additions import settings
from additions.common import synthetic
from additions.common.timekeys import MISSING_SECOND
from additions.training._loss_shared import account_chunks
from additions.training.distillation import soft_target_loss
from additions.training.lookahead_teacher import (HistoryStack, attention_mask, change_from_later_rows,
                                                  lookahead_visibility, second_look_delay, student_loss)


def _times(seed=0, chunks=6, width=9):
    """Chunks of whole seconds in time order with many same-second ties, padding, and a row without a time."""
    rng = np.random.default_rng(seed)
    gaps = rng.choice([0, 0, 1, 2, 5, 40], size=(chunks, width))       # a gap of 0 puts a row on the second before it
    times = 1_000 + np.cumsum(gaps, axis=1)
    valid = np.ones((chunks, width), dtype=bool)
    for b in range(chunks):
        valid[b, width - b:] = False                                  # chunk b ends with b padded slots
    times[~valid] = 0
    times[1, 2] = MISSING_SECOND                                      # a real row whose time is missing
    return torch.tensor(times, dtype=torch.int64), torch.tensor(valid)


def _slow_visibility(times, valid, seconds_ahead=None, rows_ahead=None):
    """The rule written out pair by pair: may row i of a chunk read row j?"""
    times, valid = times.numpy(), valid.numpy()
    chunks, width = times.shape
    out = np.zeros((chunks, width, width), dtype=bool)
    for b in range(chunks):
        placed = [j for j in range(width) if valid[b, j] and times[b, j] != MISSING_SECOND]
        for i in range(width):
            if not valid[b, i]:
                continue
            out[b, i, i] = True                                       # a real row reads itself
            if i not in placed:
                continue                                              # a row without a time reads nothing else
            later_placed = [j for j in placed if j > i]
            for j in placed:
                t_i, t_j = times[b, i], times[b, j]
                ok = t_j < t_i                                        # strictly earlier seconds
                if seconds_ahead is not None and t_i <= t_j <= t_i + seconds_ahead:
                    ok = True
                if rows_ahead is not None and (t_j == t_i or j in later_placed[:rows_ahead]):
                    ok = True
                out[b, i, j] = out[b, i, j] or ok
    return torch.tensor(out)


def test_strict_rule_and_both_bands_equal_the_slow_pairwise_rule():
    """The mask is the strict rule, plus exactly the stated band by seconds, by rows, or by either."""
    times, valid = _times()
    for seconds_ahead, rows_ahead in ((None, None), (0, None), (3, None), (40, None),
                                      (None, 0), (None, 1), (None, 3), (2, 2)):
        got = lookahead_visibility(times, valid, seconds_ahead, rows_ahead)
        assert got.shape == (times.shape[0], times.shape[1], times.shape[1])
        assert torch.equal(got, _slow_visibility(times, valid, seconds_ahead, rows_ahead)), (seconds_ahead, rows_ahead)


def test_the_strict_rule_hides_the_same_second_and_the_band_only_adds_later_rows():
    """Strictly: no same-second neighbour, no later row. A band keeps every strict entry and adds only forward ones."""
    times, valid = _times(seed=1)
    strict = lookahead_visibility(times, valid)
    reader, read = times.unsqueeze(2), times.unsqueeze(1)
    off_diagonal = ~torch.eye(times.shape[1], dtype=torch.bool)
    assert not (strict & off_diagonal & (read >= reader)).any()
    assert (reader == read).logical_and(off_diagonal).logical_and(valid.unsqueeze(1) & valid.unsqueeze(2)).any()
    for band in ({"seconds_ahead": 5}, {"rows_ahead": 2}):
        wide = lookahead_visibility(times, valid, **band)
        assert torch.equal(wide & strict, strict)                         # nothing of the strict rule is lost
        added = wide & ~strict
        assert added.any() and not (added & (read < reader)).any()       # every added entry looks forward or sideways
    # Padding is read by nobody and reads only itself.
    padded = ~valid
    assert padded.any()
    assert not (strict & padded.unsqueeze(1)).any() and not (strict & padded.unsqueeze(2)).any()


def test_attention_mask_has_one_copy_per_head_and_an_open_diagonal():
    """Float mask [B * heads, T, T]: 0 where reading is allowed, minus infinity elsewhere, diagonal always open."""
    times, valid = _times(seed=2)
    visible = lookahead_visibility(times, valid)
    mask = attention_mask(visible, num_heads=3)
    assert mask.shape == (3 * times.shape[0], times.shape[1], times.shape[1]) and mask.dtype == torch.float32
    for b in range(times.shape[0]):
        for h in range(3):
            open_ = (mask[b * 3 + h] == 0)
            expected = visible[b] | torch.eye(times.shape[1], dtype=torch.bool)
            assert torch.equal(open_, expected)
            assert torch.isneginf(mask[b * 3 + h][~expected]).all()
    assert attention_mask(visible).shape[0] == settings.NUM_HEADS * times.shape[0]


def _chunks(seed=3):
    """Made-up rows laid out as chunks, with random row vectors and the labels."""
    df = synthetic.make_transactions(n_accounts=30, seed=seed, fraud_account_share=0.5, tie_share=0.2)
    chunks = account_chunks(df, [settings.LABEL_COL], width=12)
    generator = torch.Generator().manual_seed(seed)
    vectors = torch.randn(chunks["valid"].shape + (16,), generator=generator)
    return chunks["times"], chunks["valid"], vectors, chunks[settings.LABEL_COL].clamp(min=0).float()


def _small_stack(seed):
    """A small history stage with fixed starting weights and no dropout, so two calls on one input agree."""
    torch.manual_seed(seed)
    return HistoryStack(dim=16, num_heads=2, blocks=2, history_len=12, dropout=0.0)


def test_a_trained_student_ignores_later_rows_and_the_teacher_does_not():
    """After training steps, replacing later rows moves none of the student's earlier scores but moves the teacher's."""
    times, valid, vectors, labels = _chunks()
    teacher, student = _small_stack(0), _small_stack(1)
    assert not set(map(id, teacher.parameters())) & set(map(id, student.parameters()))     # separate weights
    optimiser = torch.optim.Adam(list(teacher.parameters()) + list(student.parameters()), lr=1e-2)
    for _ in range(5):
        optimiser.zero_grad()
        teacher_logits = teacher(vectors, times, valid, rows_ahead=3)
        student_logits = student(vectors, times, valid)
        loss = (F.binary_cross_entropy_with_logits(teacher_logits[valid], labels[valid])
                + student_loss(student_logits[valid], labels[valid], teacher_logits[valid]))
        loss.backward()
        optimiser.step()
    teacher.eval()
    student.eval()
    kept, replaced = change_from_later_rows(student, vectors, times, valid)
    assert kept < 1e-5 and replaced > 1e-4
    kept_teacher, _ = change_from_later_rows(lambda v, t, m: teacher(v, t, m, rows_ahead=3), vectors, times, valid)
    assert kept_teacher > 1e-3
    kept_seconds, _ = change_from_later_rows(lambda v, t, m: teacher(v, t, m, seconds_ahead=600), vectors, times, valid)
    assert kept_seconds > 1e-3


def test_cutting_a_chunk_short_leaves_the_students_earlier_scores_unchanged():
    """Scores of the first rows are the same whether or not the later rows of the chunk exist at all."""
    times, valid, vectors, _ = _chunks(seed=4)
    student, teacher = _small_stack(2).eval(), _small_stack(3).eval()
    with torch.no_grad():
        full = student(vectors, times, valid)
        full_teacher = teacher(vectors, times, valid, rows_ahead=2)
        for cut in (3, 7):
            short = valid.clone()
            short[:, cut:] = False                                        # the later rows are not there yet
            part = student(vectors, times, short)
            assert torch.allclose(part[short], full[short], atol=1e-5)
            part_teacher = teacher(vectors, times, short, rows_ahead=2)
            assert not torch.allclose(part_teacher[short], full_teacher[short], atol=1e-3)


def test_history_stack_shapes_finite_values_and_gradients():
    """Scores are [B, T] and finite, padding included; every weight gets a finite gradient."""
    times, valid, vectors, labels = _chunks(seed=5)
    stack = _small_stack(4)
    for band in ({}, {"seconds_ahead": 3}, {"rows_ahead": 2}):
        stack.zero_grad()
        logits = stack(vectors, times, valid, **band)
        assert logits.shape == valid.shape and torch.isfinite(logits).all()
        F.binary_cross_entropy_with_logits(logits[valid], labels[valid]).backward()
        for name, parameter in stack.named_parameters():
            assert parameter.grad is not None and torch.isfinite(parameter.grad).all(), name
        assert stack.head.weight.grad.abs().sum() > 0


def test_second_look_delay_equals_the_slow_wait():
    """No band waits 0 s, a band of seconds waits that long, a band of rows waits for its last row or is missing."""
    times, valid = _times(seed=6)
    t, v = times.numpy(), valid.numpy()
    placed = v & (t != MISSING_SECOND)
    assert torch.equal(torch.isnan(second_look_delay(times, valid)), torch.tensor(~placed))
    assert (second_look_delay(times, valid)[torch.tensor(placed)] == 0).all()
    assert (second_look_delay(times, valid, seconds_ahead=30)[torch.tensor(placed)] == 30).all()
    for rows_ahead, seconds_ahead in ((2, None), (3, 4)):
        got = second_look_delay(times, valid, seconds_ahead, rows_ahead).numpy()
        for b in range(t.shape[0]):
            positions = np.flatnonzero(placed[b])
            for i in range(t.shape[1]):
                if not placed[b, i]:
                    assert np.isnan(got[b, i])
                    continue
                later = positions[positions > i]
                if len(later) < rows_ahead:
                    assert np.isnan(got[b, i])                             # the band is not complete in this chunk
                else:
                    wait = t[b, later[rows_ahead - 1]] - t[b, i]
                    assert got[b, i] == max(wait, seconds_ahead or 0)


def test_student_loss_is_the_soft_target_loss_with_a_detached_teacher_and_a_warm_up():
    """The loss equals soft_target_loss on the teacher's probability; no gradient reaches the teacher."""
    generator = torch.Generator().manual_seed(7)
    student = torch.randn(200, generator=generator, dtype=torch.float64).requires_grad_(True)
    teacher = torch.randn(200, generator=generator, dtype=torch.float64).requires_grad_(True)
    labels = (torch.rand(200, generator=generator) < 0.1).double()
    with torch.no_grad():
        teacher_missing = teacher.clone()
        teacher_missing[::5] = float("nan")
    expected = soft_target_loss(student.detach(), labels, torch.sigmoid(teacher_missing), weight=0.5)
    assert torch.isclose(student_loss(student.detach(), labels, teacher_missing), expected)
    student_loss(student, labels, teacher).backward()
    assert teacher.grad is None and student.grad.abs().sum() > 0
    plain = F.binary_cross_entropy_with_logits(student.detach(), labels)
    assert torch.isclose(student_loss(student.detach(), labels, teacher, step=10, warmup_steps=100), plain)
    halfway = soft_target_loss(student.detach(), labels, torch.sigmoid(teacher.detach()), weight=0.25)
    assert torch.isclose(student_loss(student.detach(), labels, teacher, step=150, warmup_steps=100, ramp_steps=100),
                         halfway)
