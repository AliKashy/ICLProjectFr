"""Tests of the pairwise term aimed at the top of the ranking.

The term is compared with a slow loop over pairs, and the tests check the warm-up, the use
of only the non-frauds above the running quantile, the cap at a fraction of the
cross-entropy, and that the running quantile settles near the true quantile of a stream.
"""
import numpy as np
import torch
import torch.nn.functional as F

from additions.training.pairwise_top import PairwiseTop, RunningQuantile, pairwise_term, scaled_term


def _batch(seed=0, rows=400, fraud_share=0.05):
    """A made-up batch: fraud log-odds a little higher on frauds than on the other rows."""
    generator = torch.Generator().manual_seed(seed)
    labels = (torch.rand(rows, generator=generator) < fraud_share).float()
    logits = torch.randn(rows, generator=generator, dtype=torch.float64) - 3.0 + 1.5 * labels
    return logits, labels


def test_pairwise_term_equals_a_slow_loop_over_pairs_above_the_threshold():
    """The term is the mean of softplus(non-fraud - fraud) over every fraud and every non-fraud above the threshold."""
    logits, labels = _batch()
    threshold = float(torch.quantile(logits, 0.9))
    term, pairs = pairwise_term(logits, labels, threshold)
    values = []
    for i in range(len(logits)):
        for j in range(len(logits)):
            if labels[i] == 1 and labels[j] == 0 and logits[j] > threshold:
                values.append(np.log1p(np.exp(float(logits[j] - logits[i]))))
    assert pairs == len(values) > 0
    assert np.isclose(term.item(), np.mean(values))


def test_only_non_frauds_above_the_threshold_count():
    """Moving a non-fraud that stays below the threshold changes nothing, and it gets no gradient."""
    logits, labels = _batch(seed=1)
    threshold = float(torch.quantile(logits, 0.95))
    z = logits.clone().requires_grad_(True)
    term, _ = pairwise_term(z, labels, threshold)
    term.backward()
    below = (labels == 0) & (logits <= threshold)
    assert (z.grad[below] == 0).all()
    assert (z.grad[(labels == 0) & (logits > threshold)] > 0).all()      # top non-frauds are pushed down
    assert (z.grad[labels == 1] < 0).all()                                # frauds are pushed up
    moved = logits.clone()
    moved[below] = moved[below] - 5.0
    assert torch.isclose(pairwise_term(moved, labels, threshold)[0], term.detach())


def test_without_frauds_or_top_rows_the_term_is_a_differentiable_zero():
    """A batch with no fraud, or no non-fraud above the threshold, adds zero and still runs backward."""
    logits, labels = _batch(seed=2)
    z = logits.clone().requires_grad_(True)
    term, pairs = pairwise_term(z, torch.zeros_like(labels), 0.0)
    term.backward()
    assert term.item() == 0.0 and pairs == 0 and (z.grad == 0).all()
    assert pairwise_term(logits, labels, 1e9)[1] == 0


def test_scaled_term_stays_at_or_below_its_fraction_and_is_never_scaled_up():
    """The scaled term is at most fraction times the cross-entropy, and a smaller term is left as it is."""
    for term_value in (0.01, 0.5, 3.0, 40.0):
        term = torch.tensor(term_value, requires_grad=True)
        ce = torch.tensor(0.08)
        scaled = scaled_term(term, ce, fraction=0.25)
        assert scaled.item() <= 0.25 * ce.item() + 1e-9
        assert np.isclose(scaled.item(), min(term_value, 0.25 * ce.item()))
        scaled.backward()
        assert np.isclose(term.grad.item(), min(1.0, 0.25 * 0.08 / term_value))


def test_the_term_is_zero_during_the_warm_up_and_capped_afterwards():
    """PairwiseTop adds zero until the warm-up ends, and then at most its fraction of the cross-entropy."""
    pairwise = PairwiseTop(quantile=0.9, fraction=0.2, warmup_steps=5, momentum=0.5)
    pairwise.train()
    added = []
    for step in range(10):
        logits, labels = _batch(seed=10 + step)
        ce = F.binary_cross_entropy_with_logits(logits, labels.double())
        value = pairwise(logits, labels, ce)
        added.append(value.item())
        assert value.item() <= 0.2 * ce.item() + 1e-9
    assert added[:5] == [0.0] * 5
    assert all(v > 0 for v in added[5:])
    assert int(pairwise.steps) == 10 and int(pairwise.tracker.updates) == 10
    # A step passed by the trainer takes the place of the object's own count.
    logits, labels = _batch(seed=99)
    ce = F.binary_cross_entropy_with_logits(logits, labels.double())
    assert pairwise(logits, labels, ce, step=0).item() == 0.0


def test_the_term_uses_the_running_quantile_as_its_threshold():
    """After the warm-up the term equals the scaled pair term at the tracker's current value."""
    pairwise = PairwiseTop(quantile=0.97, fraction=1e6, warmup_steps=0, momentum=0.9)
    pairwise.train()
    for step in range(4):
        logits, labels = _batch(seed=20 + step)
        value = pairwise(logits, labels, torch.tensor(1.0, dtype=torch.float64))
        term, _ = pairwise_term(logits, labels, pairwise.tracker.value)
        assert torch.isclose(value, term)
    # In evaluation mode the tracker and the step count stay where they are.
    pairwise.eval()
    before = (pairwise.tracker.value.clone(), int(pairwise.steps))
    pairwise(logits + 10.0, labels, torch.tensor(1.0))
    assert torch.equal(pairwise.tracker.value, before[0]) and int(pairwise.steps) == before[1]


def test_running_quantile_settles_near_the_true_quantile_of_a_stream():
    """Fed batches of one distribution, the tracked value ends close to that distribution's quantile."""
    tracker = RunningQuantile(quantile=0.97, momentum=0.95)
    generator = torch.Generator().manual_seed(4)
    tracker.update(torch.randn(256, generator=generator) + 5.0)            # a first batch far from the rest
    for _ in range(400):
        tracker.update(torch.randn(256, generator=generator))
    true = float(torch.distributions.Normal(0.0, 1.0).icdf(torch.tensor(0.97)))
    assert abs(tracker.value.item() - true) < 0.1
    assert int(tracker.updates) == 401
    assert tracker.update(torch.zeros(0)) is tracker.value and int(tracker.updates) == 401
