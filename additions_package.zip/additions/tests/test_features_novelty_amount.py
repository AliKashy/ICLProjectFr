"""Tests of the template and amount novelty columns.

The main test recomputes the columns of sampled rows by hand from the account's rows inside
the look-back. The other tests check the population tables and the rules one by one.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, timekeys
from additions.features import _shared, lookback, novelty_amount

FIELDS = (settings.TYPE_COL, settings.SEGMENT_COL, settings.CARD_PRESENT_COL)
MONTH = 30 * 86_400
PRIOR = 5.0


def _table(seed=0, n_accounts=25, **kwargs):
    """Made-up rows with a few missing codes and amounts, and amounts that repeat exactly."""
    df = synthetic.make_transactions(n_accounts=n_accounts, seed=seed, **kwargs)
    rng = np.random.default_rng(seed)
    whole = rng.random(len(df)) < 0.5                                            # half the amounts in whole dollars
    df[settings.AMOUNT_COL] = np.where(whole, np.round(df[settings.AMOUNT_COL]), df[settings.AMOUNT_COL])
    df.loc[rng.random(len(df)) < 0.05, settings.SEGMENT_COL] = None
    df.loc[rng.random(len(df)) < 0.03, settings.AMOUNT_COL] = np.nan
    return df


def _fit(seed=10, **kwargs):
    return novelty_amount.fit_novelty_tables(_table(seed, days=92, start="2024-10-01"), code_cols=FIELDS, **kwargs)


def _build(df, fitted, **kwargs):
    return novelty_amount.build_novelty_amount(df, fitted, code_cols=FIELDS, **kwargs)


def _texts(df):
    """The template of every row as text, the slow way: the code values joined, a missing one left empty."""
    return ["|".join("" if pd.isna(v) else str(v) for v in values) for values in df[list(FIELDS)].to_numpy()]


def _log_share(table, text):
    return np.log((table["counts"].get(text, 0) + 1.0) / (table["rows"] + len(table["counts"]) + 1.0))


def _same(a, b, tol=1e-5):
    return bool(np.isclose(a, b, rtol=tol, atol=tol, equal_nan=True))


def _previous(rows, secs, r):
    """The latest row of `rows` in a second strictly before row r (the last listed when several share it)."""
    before = rows[secs[rows] < secs[r]]
    return before[secs[before] == secs[before].max()][-1] if len(before) else None


def test_tables_count_templates_pairs_and_exact_amounts():
    """The fitted tables equal plain counts of templates, of (previous, current) pairs and of amounts in cents."""
    df = _table(seed=1)
    fitted = novelty_amount.fit_novelty_tables(df, code_cols=FIELDS)
    text = _texts(df)
    assert fitted["templates"]["counts"] == pd.Series(text).value_counts().to_dict()
    cents = np.round(df[settings.AMOUNT_COL].dropna() * 100).astype(int).astype(str)
    assert fitted["amounts"]["counts"] == cents.value_counts().to_dict()
    account = timekeys.codes(df[settings.ACCOUNT_COL])
    secs = timekeys.seconds(df[settings.TIME_COL])
    start = lookback.lookback_start(secs)
    pairs = {}
    for i in range(len(df)):
        previous = _previous(np.flatnonzero((account == account[i]) & (secs >= start[i])), secs, i)
        if previous is not None:
            key = f"{text[previous]} > {text[i]}"
            pairs[key] = pairs.get(key, 0) + 1
    assert fitted["pairs"]["counts"] == pairs
    # A capped table keeps the most frequent entries and still knows how many rows it was fitted on.
    capped = novelty_amount.fit_novelty_tables(df, code_cols=FIELDS, max_templates=3, max_amounts=5)
    assert len(capped["templates"]["counts"]) == 3 and len(capped["amounts"]["counts"]) == 5
    assert capped["templates"]["rows"] == len(df)
    assert min(capped["templates"]["counts"].values()) >= sorted(fitted["templates"]["counts"].values())[-3]


def test_columns_equal_the_slow_definition():
    """Template, pair and amount columns match a recomputation from the account's rows inside the look-back."""
    fitted = _fit()
    df = _table(seed=2, n_accounts=15, days=92, start="2024-10-01")
    got = _build(df, fitted)
    account = timekeys.codes(df[settings.ACCOUNT_COL])
    secs = timekeys.seconds(df[settings.TIME_COL])
    start = lookback.lookback_start(secs)
    text = np.array(_texts(df), dtype=object)
    amount = df[settings.AMOUNT_COL].to_numpy()
    cents = np.round(amount * 100)
    assert got.shape == (len(df), 21) and got.index.equals(df.index)
    assert np.isfinite(got.to_numpy()[~np.isnan(got.to_numpy())]).all()
    for i in range(0, len(df), 9):
        row = got.iloc[i]
        mine = np.flatnonzero((account == account[i]) & (secs >= start[i]))        # the account's look-back and after
        earlier = mine[secs[mine] < secs[i]]
        recent = earlier[secs[earlier] >= secs[i] - MONTH]
        assert row["novelty_has_earlier_row"] == float(len(earlier) > 0)

        same = earlier[text[earlier] == text[i]]
        n_30d = (text[recent] == text[i]).sum()
        log_share = _log_share(fitted["templates"], text[i])
        assert _same(row["novelty_template_pop_log_share"], log_share)
        assert row["novelty_template_seen"] == float(len(same) > 0) and row["novelty_template_n_30d"] == n_30d
        assert _same(row["novelty_template_share_30d"], n_30d / len(recent) if len(recent) else np.nan)
        age = np.log1p(secs[i] - secs[same].min()) if len(same) else np.nan
        assert _same(row["novelty_template_log_secs_since_first"], age)
        lift = np.log((n_30d + PRIOR * np.exp(log_share)) / (len(recent) + PRIOR)) - log_share
        assert _same(row["novelty_template_log_lift"], lift, 1e-4)
        assert row["novelty_template_distinct_30d"] == len(set(text[recent]))

        # The pair of a row: the template of the previous row inside THIS look-back, then its own template.
        def pair_of(r):
            previous = _previous(mine, secs, r)
            return None if previous is None else f"{text[previous]} > {text[r]}"
        own_pair = pair_of(i)
        earlier_pairs = [pair_of(r) for r in earlier]
        same_pair = [r for r, p in zip(earlier, earlier_pairs) if p is not None and p == own_pair]
        n_pair = sum(1 for r in same_pair if secs[r] >= secs[i] - MONTH)
        assert _same(row["novelty_pair_pop_log_share"], _log_share(fitted["pairs"], own_pair) if own_pair else np.nan)
        assert row["novelty_pair_seen"] == float(len(same_pair) > 0) and row["novelty_pair_n_30d"] == n_pair
        assert _same(row["novelty_pair_share_30d"], n_pair / len(recent) if len(recent) else np.nan)
        assert _same(row["novelty_pair_log_secs_since_first"],
                     np.log1p(secs[i] - min(secs[r] for r in same_pair)) if same_pair else np.nan)

        if np.isnan(amount[i]):
            assert np.isnan(row["novelty_amount_cents"]) and np.isnan(row["novelty_amount_whole"])
            assert row["novelty_amount_n_same_30d"] == 0 and row["novelty_amount_equals_previous"] == 0
            continue
        assert row["novelty_amount_cents"] == cents[i] % 100
        for name, step in (("whole", 1), ("multiple_5", 5), ("multiple_10", 10), ("multiple_100", 100)):
            dollars = cents[i] / 100
            is_round = amount[i] > 0 and dollars == int(dollars) and int(dollars) % step == 0
            assert row[f"novelty_amount_{name}"] == float(is_round)
        assert _same(row["novelty_amount_pop_log_share"], _log_share(fitted["amounts"], str(int(cents[i]))))
        assert row["novelty_amount_n_same_30d"] == (cents[recent] == cents[i]).sum()
        paid = earlier[~np.isnan(amount[earlier])]
        last_paid = paid[secs[paid] == secs[paid].max()][-1] if len(paid) else None
        assert row["novelty_amount_equals_previous"] == float(last_paid is not None and cents[last_paid] == cents[i])


def test_rows_of_the_same_second_do_not_see_each_other():
    """Two rows of one second with a new template and amount are both new; the next row has seen both."""
    df = pd.DataFrame({
        settings.ACCOUNT_COL: ["a"] * 4,
        settings.TIME_COL: pd.to_datetime(["2025-06-03 10:00:00", "2025-06-03 11:00:00", "2025-06-03 11:00:00",
                                           "2025-06-03 12:00:00"]),
        settings.TYPE_COL: ["P", "W", "W", "W"],
        settings.AMOUNT_COL: [10.0, 25.0, 25.0, 25.0],
    })
    fitted = novelty_amount.fit_novelty_tables(df, code_cols=[settings.TYPE_COL])
    got = novelty_amount.build_novelty_amount(df, fitted, code_cols=[settings.TYPE_COL])
    assert got["novelty_template_seen"].tolist() == [0, 0, 0, 1]
    assert got["novelty_template_n_30d"].tolist() == [0, 0, 0, 2]
    assert got["novelty_template_distinct_30d"].tolist() == [0, 1, 1, 2]
    assert got["novelty_amount_n_same_30d"].tolist() == [0, 0, 0, 2]
    assert got["novelty_amount_equals_previous"].tolist() == [0, 0, 0, 1]
    assert got["novelty_pair_seen"].tolist() == [0, 0, 0, 0]                       # "W > W" is new on the last row
    assert got["novelty_amount_multiple_5"].tolist() == [1, 1, 1, 1]
    assert got["novelty_amount_multiple_10"].tolist() == [1, 0, 0, 0]


def test_later_rows_do_not_change_earlier_columns():
    """Dropping every row after the middle of the period leaves the columns of the rows before it unchanged."""
    df = _table(seed=3)
    fitted = _fit()
    secs = timekeys.seconds(df[settings.TIME_COL])
    keep = secs <= np.median(secs)
    assert np.allclose(_build(df, fitted)[keep].to_numpy(), _build(df[keep], fitted).to_numpy(), equal_nan=True)


def test_training_rows_get_what_scored_rows_get():
    """A December row in long files gets the columns it would get in files that begin on 1 November."""
    df = _table(seed=4, n_accounts=15, days=92, start="2024-10-01")
    fitted = _fit()
    secs = timekeys.seconds(df[settings.TIME_COL])
    december = secs >= lookback.data_start("2024-12-01")
    cut = secs >= lookback.data_start("2024-11-01")
    long_files, short_files = _build(df, fitted), _build(df[cut], fitted)
    assert np.allclose(long_files[december].to_numpy(), short_files[december[cut]].to_numpy(), equal_nan=True)


def test_the_rows_own_account_can_be_left_out_of_the_population():
    """On the rows the tables were fitted on, an amount only this account paid is as rare as one never seen."""
    df = _table(seed=5, n_accounts=12)
    df.loc[df[settings.ACCOUNT_COL] == df[settings.ACCOUNT_COL].iloc[0], settings.AMOUNT_COL] = 123_456.78
    fitted = novelty_amount.fit_novelty_tables(df, code_cols=FIELDS)
    without = _build(df, fitted, remove_own_account=True)
    plain = _build(df, fitted)
    account = timekeys.codes(df[settings.ACCOUNT_COL])
    cents = np.round(df[settings.AMOUNT_COL].to_numpy() * 100)
    paid = ~np.isnan(cents)
    distinct = len(fitted["amounts"]["counts"])
    for i in np.flatnonzero(paid)[::13]:
        others = paid & (account != account[i])
        share = ((cents[others] == cents[i]).sum() + 1.0) / (others.sum() + distinct + 1.0)
        assert _same(without["novelty_amount_pop_log_share"].iloc[i], np.log(share))
    only_here = (account == account[0]) & paid
    column = "novelty_amount_pop_log_share"
    assert (without.loc[only_here, column] < plain.loc[only_here, column]).all()
    assert np.isfinite(without.to_numpy()[~np.isnan(without.to_numpy())]).all()


def test_values_outside_the_tables_and_missing_columns(capsys):
    """A capped table reads the rest as never seen; a table without codes or amounts only drops columns."""
    df = _table(seed=6, n_accounts=6)
    capped = _fit(max_templates=2)
    got = _build(df, capped)
    floor = np.log(1.0 / (capped["templates"]["rows"] + 3.0))
    assert np.isclose(got["novelty_template_pop_log_share"].min(), floor, rtol=1e-5)
    assert (got["novelty_template_pop_log_share"] > floor + 1e-6).any()
    capsys.readouterr()
    no_codes = _build(df.drop(columns=list(FIELDS)), capped)
    assert [c for c in no_codes.columns if "template" in c or "pair" in c] == [] and no_codes.shape[1] == 9
    no_amount = _build(df.drop(columns=[settings.AMOUNT_COL]), capped, fill=0.0)
    assert no_amount.shape[1] == 13 and not no_amount.isna().any().any()
    assert _build(df, {"amounts": capped["amounts"]}).shape[1] == 9             # an unfitted table is skipped
    assert capsys.readouterr().out.count("note:") == 3


def test_tables_can_be_saved_and_the_command_line_runs(tmp_path, capsys):
    """Tables written to a file give the same columns after reading, and the tool runs on made-up rows."""
    fitted = _fit()
    df = _table(seed=7, n_accounts=6)
    path = _shared.save_tables(fitted, str(tmp_path / "novelty.json"))
    reloaded = _build(df, _shared.load_tables(path))
    assert np.array_equal(_build(df, fitted).to_numpy(), reloaded.to_numpy(), equal_nan=True)
    frame = novelty_amount.main(["--demo", "--out", str(tmp_path / "novelty.csv")])
    assert "novelty_template_log_lift" in capsys.readouterr().out and frame.shape[1] == 21
    assert len(pd.read_csv(tmp_path / "novelty.csv")) == len(frame)
