"""Tests of the speed card.

A tiny model with named parts is run through short loops in which the loader or the model sleeps
for a known time. The card must count the batches and rows, put the sleep on the right side of
the waiting share, time the watched parts, read the gradient flag and the training mode inside
the model's calls, take every hook off again, and never raise, also with zero or one batch.
Further tests cover the ordinary misuses: a loop that calls model.forward, work after
batch_done, warm-up calls outside the batches, a part that is not a module, batches never
closed by batch_done, a frozen model, parts that overlap, and the card as a context manager.
Sleeps are small and the tolerances wide, so that a busy machine does not make the tests fail.
"""
import time

import pytest
import torch

from additions.reads import scoring_speed
from additions.reads.scoring_speed import SpeedCard


class _Sleepy(torch.nn.Module):
    """A part that sleeps for a set time on every call, so that its share of the time is known."""

    def __init__(self, pause):
        super().__init__()
        self.pause = pause
        self.scale = torch.nn.Linear(4, 4)

    def forward(self, x):
        time.sleep(self.pause)
        return self.scale(x)


class _Model(torch.nn.Module):
    """Two named parts: `front` is fast, `slow` sleeps for `pause` seconds on every call."""

    def __init__(self, pause=0.0):
        super().__init__()
        self.front = torch.nn.Linear(4, 4)
        self.slow = _Sleepy(pause)

    def forward(self, x):
        return self.slow(self.front(x)).sum(dim=1)


def _run(model, batches, rows=8, loader_pause=0.0, grad=False, card=None):
    """Runs a scoring loop with the card on and returns the card; the loader sleeps `loader_pause` per batch."""
    card = SpeedCard(model) if card is None else card
    for _ in range(batches):
        time.sleep(loader_pause)
        batch = torch.randn(rows, 4)
        card.batch_arrived(rows)
        # The gradient flag is set as asked, so that both sides of the gradient rule are tested.
        with torch.set_grad_enabled(grad):
            model(batch)
        card.batch_done()
    return card


def _hook_count(model):
    """The number of forward hooks and forward pre-hooks left on the model and every module in it."""
    return sum(len(m._forward_hooks) + len(m._forward_pre_hooks) for m in model.modules())


def test_batches_and_rows_are_counted():
    """Batches, rows, and rows per batch (smallest, middle, largest) come out as fed in."""
    model = _Model().eval()
    card = SpeedCard(model)
    for rows in (5, 7, 9, 11):
        card.batch_arrived(rows)
        with torch.no_grad():
            model(torch.randn(rows, 4))
        card.batch_done()
    n = card.numbers()
    assert card.batches == 4 and n["batches"] == 4
    assert n["rows"] == 32
    # The first batch is left out of the averages, so 7 + 9 + 11 rows are measured.
    assert n["measured_batches"] == 3 and n["measured_rows"] == 27
    assert (n["rows_per_batch_smallest"], n["rows_per_batch_middle"], n["rows_per_batch_largest"]) == (5, 8, 11)
    assert n["rows_per_second"] > 0
    assert n["seconds_per_million_rows"] == pytest.approx(1_000_000 / n["rows_per_second"])
    card.close()


def test_waiting_share_rises_when_the_loader_sleeps():
    """A loader that sleeps makes the waiting share large; a fast loader keeps it smaller."""
    fast = _run(_Model().eval(), batches=6, loader_pause=0.0).numbers()["waiting_share"]
    slow_card = _run(_Model().eval(), batches=6, loader_pause=0.03)
    slow = slow_card.numbers()["waiting_share"]
    assert slow > fast
    assert slow > 0.5
    # The loader rule fires when more than half of the wall time is spent waiting.
    assert any("waiting for the next batch" in line for line in slow_card.numbers()["stands_out"])


def test_model_share_rises_when_the_model_sleeps():
    """A model that sleeps makes the batch share and the model share large."""
    card = _run(_Model(pause=0.03).eval(), batches=6, loader_pause=0.0)
    n = card.numbers()
    assert n["batch_share"] > 0.7
    assert n["model_share"] > 0.7
    assert n["waiting_share"] < 0.3
    assert n["batch_share"] + n["waiting_share"] == pytest.approx(1.0)
    # Nothing about waiting is pointed out when the model sets the pace.
    assert not any("waiting for the next batch" in line for line in n["stands_out"])


def test_watched_parts_are_timed_and_counted():
    """Each part is called once per batch; the sleeping part takes most of the model time."""
    card = _run(_Model(pause=0.02).eval(), batches=5)
    parts = card.numbers()["parts"]
    assert set(parts) == {"front", "slow"}
    # Four measured batches (the first is left out), one call of each part per batch.
    assert parts["front"]["calls"] == 4 and parts["slow"]["calls"] == 4
    assert parts["slow"]["seconds_per_batch"] > 0.015
    assert parts["slow"]["share_of_model"] > 0.8
    assert parts["front"]["share_of_model"] < 0.2
    assert any("'slow'" in line for line in card.numbers()["stands_out"])


def test_parts_given_as_a_dict_are_watched_and_timed_inclusively():
    """A part given by hand is watched; a part that holds another includes that part's time."""
    model = _Model(pause=0.02).eval()
    card = _run(model, batches=4, card=SpeedCard(model, parts={"inner": model.slow.scale, "outer": model.slow}))
    parts = card.numbers()["parts"]
    assert set(parts) == {"inner", "outer"}
    assert parts["outer"]["seconds_per_batch"] >= parts["inner"]["seconds_per_batch"]
    assert parts["inner"]["calls"] == 3


def test_gradient_line_fires_without_no_grad_and_not_with_it():
    """Gradients recorded during the calls are pointed out; under no_grad they are not."""
    with_grad = _run(_Model().eval(), batches=3, grad=True).numbers()
    without = _run(_Model().eval(), batches=3, grad=False).numbers()
    assert with_grad["calls_with_gradients"] == 3
    assert any("gradients were being recorded" in line for line in with_grad["stands_out"])
    assert without["calls_with_gradients"] == 0
    assert not any("gradients were being recorded" in line for line in without["stands_out"])


def test_training_mode_line_fires_in_train_and_not_in_eval():
    """A model in train() is pointed out; the same model in eval() is not."""
    trained = _run(_Model().train(), batches=3).numbers()
    evaluated = _run(_Model().eval(), batches=3).numbers()
    assert trained["calls_in_training_mode"] == 3
    assert any("training mode" in line for line in trained["stands_out"])
    assert evaluated["calls_in_training_mode"] == 0
    assert not any("training mode" in line for line in evaluated["stands_out"])


def test_close_removes_every_hook():
    """After close() neither the model nor any module in it has a forward hook or pre-hook left."""
    model = _Model().eval()
    before = _hook_count(model)
    card = _run(model, batches=2)
    assert _hook_count(model) > before
    card.close()
    assert _hook_count(model) == before == 0
    # The numbers stay readable after close(), and calling close() twice does nothing.
    assert card.numbers()["batches"] == 2
    card.close()


def test_numbers_and_report_agree():
    """The values in report() are the values of numbers()."""
    card = _run(_Model(pause=0.005).eval(), batches=5, rows=13)
    n, text = card.numbers(), card.report()
    assert f"batches seen: {n['batches']}" in text
    assert f"rows seen: {n['rows']:,}" in text
    assert f"rows per second: {n['rows_per_second']:,.0f}" in text
    assert f"device of the weights: {n['device']}" in text
    assert f"number type: {n['dtype']}" in text
    assert f"waiting for the next batch: {100 * n['waiting_share']:.1f}%" in text
    for name, part in n["parts"].items():
        assert name in text and f"{100 * part['share_of_model']:.1f}% of the model time" in text
    for line in n["stands_out"]:
        assert line in text
    assert n["device"] == "cpu" and n["dtype"] == "float32" and n["peak_gpu_bytes"] is None
    card.close()


def test_nothing_raises_with_zero_or_one_batch():
    """With zero batches and with one batch the card still prints and gives numbers."""
    model = _Model().eval()
    empty = SpeedCard(model)
    assert empty.numbers()["batches"] == 0 and empty.numbers()["rows_per_second"] is None
    assert "Speed card" in empty.report()
    empty.close()
    one = _run(model, batches=1)
    n = one.numbers()
    assert n["batches"] == 1 and n["averaged_over"] == "the first batch only"
    assert "Speed card" in one.report()
    one.close()


def test_out_of_order_calls_print_a_note_and_carry_on(capsys):
    """batch_done without batch_arrived, and batch_arrived twice, each print one note and carry on."""
    model = _Model().eval()
    card = SpeedCard(model)
    card.batch_done()
    card.batch_arrived(3)
    card.batch_arrived(4)
    card.batch_done()
    assert card.batches == 2
    assert capsys.readouterr().out.count("speed card:") == 2
    card.close()


def test_outputs_are_unchanged_with_the_card_on():
    """The hooks return nothing, so the model's scores are the same with and without the card."""
    model = _Model().eval()
    x = torch.randn(6, 4)
    with torch.no_grad():
        plain = model(x)
        card = SpeedCard(model)
        watched = model(x)
        card.close()
    assert torch.equal(plain, watched)


def test_main_prints_a_card(capsys):
    """The example in main() runs and prints a card with the three parts of the tiny model."""
    scoring_speed.main()
    out = capsys.readouterr().out
    assert "Speed card" in out and "encoder" in out and "what stands out:" in out


def test_model_forward_called_directly_shows_the_model_share_as_not_known():
    """A loop that calls model.forward skips the model's hooks; the card says so and shows no 0."""
    model = _Model(pause=0.005).train()
    card = SpeedCard(model)
    for _ in range(3):
        card.batch_arrived(8)
        # forward() runs the model without its hooks, as a predict() method that wraps it would.
        model.forward(torch.randn(8, 4))
        card.batch_done()
    n = card.numbers()
    assert n["model_calls"] == 0
    assert n["model_share"] is None and n["model_seconds_per_batch"] is None
    assert n["first_batch_model_seconds"] is None
    assert all(part["share_of_model"] is None for part in n["parts"].values())
    assert any("hooks never fired" in line and "model(...)" in line for line in n["stands_out"])
    assert "inside the model: not known" in card.report()
    card.close()


def test_work_after_batch_done_is_named_as_outside_the_batch():
    """Time after batch_done counts outside the batch; the line and the rule name the loop's own work too."""
    model = _Model().eval()
    with SpeedCard(model) as card:
        for _ in range(6):
            card.batch_arrived(8)
            with torch.no_grad():
                model(torch.randn(8, 4))
            card.batch_done()
            # The loader is instant; the loop itself sleeps after batch_done, like writing scores.
            time.sleep(0.03)
        n, text = card.numbers(), card.report()
    assert n["waiting_share"] > 0.5
    words = "outside the batch: the loader and whatever the loop does after batch_done"
    assert words in text
    assert any(words in line for line in n["stands_out"])


def test_training_and_gradient_flags_count_only_calls_inside_a_batch():
    """Warm-up calls with gradients on, made before the loop, set off neither rule."""
    model = _Model().train()
    for _ in range(5):
        model(torch.randn(8, 4))
    card = SpeedCard(model)
    # The warm-up is repeated with the card on, outside any batch, so that the hooks see it.
    for _ in range(5):
        model(torch.randn(8, 4))
    model.eval()
    _run(model, batches=4, grad=False, card=card)
    n = card.numbers()
    assert n["model_calls"] == 4 and n["model_calls_outside_batches"] == 5
    assert n["calls_with_gradients"] == 0 and n["calls_in_training_mode"] == 0
    assert not any("gradients were being recorded" in line for line in n["stands_out"])
    assert not any("training mode" in line for line in n["stands_out"])
    card.close()


def test_a_part_that_is_not_a_module_is_named_and_leaves_no_hook():
    """A wrong entry in parts raises a plain error naming it, before any hook is put on."""
    model = _Model().eval()
    with pytest.raises(TypeError, match="'bad'"):
        SpeedCard(model, parts={"front": model.front, "bad": lambda x: x})
    assert _hook_count(model) == 0


def test_batches_closed_by_the_next_arrival_are_counted():
    """Without batch_done the share outside the batch is not known, and the card says how many batches."""
    model = _Model().eval()
    card = SpeedCard(model)
    for _ in range(6):
        time.sleep(0.01)
        card.batch_arrived(8)
        with torch.no_grad():
            model(torch.randn(8, 4))
    n = card.numbers()
    assert n["batches_closed_by_next_arrival"] == 5
    assert n["waiting_share"] is None and n["batch_share"] is None
    assert any(line.startswith("5 batches were closed by the next batch_arrived") for line in n["stands_out"])
    card.close()


def test_gradient_rule_needs_a_weight_that_asks_for_a_gradient():
    """A frozen model with gradients switched on records no graph, so the rule stays quiet."""
    model = _Model().eval()
    for weight in model.parameters():
        weight.requires_grad_(False)
    n = _run(model, batches=3, grad=True).numbers()
    assert n["calls_with_gradients"] == 0
    assert not any("gradients were being recorded" in line for line in n["stands_out"])


def test_big_part_rule_skipped_for_one_part_and_overlaps_are_named():
    """One watched part never gets the big-part line; a module listed twice and overlapping shares do."""
    wrapped = torch.nn.Sequential(_Model(pause=0.005)).eval()
    single = _run(wrapped, batches=3).numbers()
    assert list(single["parts"]) == ["0"]
    assert not any("look there first" in line for line in single["stands_out"])
    model = _Model(pause=0.01).eval()
    twice = _run(model, batches=3, card=SpeedCard(model, parts={"x": model.slow, "y": model.slow})).numbers()
    assert any("listed more than once" in line and "'x'" in line and "'y'" in line for line in twice["stands_out"])
    assert any("add up to" in line for line in twice["stands_out"])


def test_one_batch_leaves_the_waiting_share_not_known():
    """With no measured wait the share outside the batch is None, not 0."""
    card = _run(_Model().eval(), batches=1)
    n = card.numbers()
    assert n["waiting_share"] is None and n["batch_share"] is None
    assert "waiting for the next batch: not known" in card.report()
    card.close()


def test_mixed_number_types_and_devices_are_said():
    """Weights of two number types, or on two devices, read as "mixed" instead of the first one."""
    model = _Model().eval()
    model.front.half()
    with SpeedCard(model) as card:
        assert card.numbers()["dtype"] == "mixed (float16, float32)"
    # The meta device holds no data but has a name, which lets two devices be shown on a CPU.
    other = _Model().eval()
    other.front.to("meta")
    with SpeedCard(other) as card:
        n = card.numbers()
    assert n["device"] == "mixed (cpu, meta)"
    assert any("more than one device" in line for line in n["stands_out"])


def test_sync_parts_off_changes_nothing_on_the_cpu():
    """sync_parts=False still times the parts on the CPU, where there is no GPU to wait for."""
    model = _Model(pause=0.01).eval()
    card = _run(model, batches=4, card=SpeedCard(model, sync_parts=False))
    n = card.numbers()
    assert n["parts_synced"] is True
    assert n["parts"]["slow"]["share_of_model"] > 0.7
    assert "rough" not in card.report()
    card.close()


def test_context_manager_takes_the_hooks_off_also_after_an_error():
    """Leaving the with block, normally or by an error, removes every hook; the error reaches the caller."""
    model = _Model().eval()
    with SpeedCard(model) as card:
        assert isinstance(card, SpeedCard) and _hook_count(model) > 0
    assert _hook_count(model) == 0
    with pytest.raises(RuntimeError, match="inside the loop"):
        with SpeedCard(model) as card:
            card.batch_arrived(4)
            raise RuntimeError("inside the loop")
    assert _hook_count(model) == 0
