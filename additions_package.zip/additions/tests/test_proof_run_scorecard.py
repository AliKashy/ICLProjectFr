"""Tests of the run-level scorecard.

Every measure is compared with a slow, plain count written with Python loops: runs are cut by
walking each account's frauds in time order, positions by counting the frauds of the run in
strictly earlier seconds, and every share by counting lines. A small hand-made table, whose
answers are worked out by hand in the comments, checks the run types and the edge cases: a run
that began before the scored month, frauds of one second, a series at one merchant, and the
response lags.
"""
import numpy as np
import pandas as pd
import pytest

from additions import settings
from additions.common import ranking, synthetic, tables
from additions.proof import _shared, run_scorecard

HOUR, DAY = 3_600, 86_400
JUNE = pd.Timestamp(settings.TARGET_START)

STANDARD = [settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL, settings.LABEL_COL, settings.AMOUNT_COL,
            settings.SCORE_COL]

# (account, seconds after the start of the scored month, fraud, amount, merchant, alerted)
HAND_ROWS = [
    # a1: a burst of three frauds within five hours, first caught at its second fraud.
    ("a1", 1 * DAY, 1, 10.0, "m1", False), ("a1", 1 * DAY + 2 * HOUR, 1, 20.0, "m2", True),
    ("a1", 1 * DAY + 5 * HOUR, 1, 30.0, "m3", False),
    # a2: a single fraud, caught; one alerted non-fraud row later on.
    ("a2", 3 * DAY, 1, 40.0, "m1", True), ("a2", 4 * DAY, 0, 99.0, "m1", True),
    # a3: a series of three frauds at one merchant over eight days (gaps of three and five days), never caught.
    ("a3", 1 * DAY, 1, 5.0, "m9", False), ("a3", 4 * DAY, 1, 6.0, "m9", False), ("a3", 9 * DAY, 1, 7.0, "m9", False),
    # a4: a run that began two days before the scored month; the history fraud is alerted but not ranked.
    ("a4", -2 * DAY, 1, 50.0, "m4", True), ("a4", 1 * DAY, 1, 60.0, "m4", False), ("a4", 2 * DAY, 1, 70.0, "m5", True),
    # a5: two frauds in one second (the second one caught) and one more an hour later: a burst caught at position 1.
    ("a5", 10 * DAY, 1, 8.0, "m6", False), ("a5", 10 * DAY, 1, 9.0, "m6", True),
    ("a5", 10 * DAY + HOUR, 1, 11.0, "m7", False),
    # a6: two frauds nineteen days apart: two single runs, never caught.
    ("a6", 1 * DAY, 1, 12.0, "m8", False), ("a6", 20 * DAY, 1, 13.0, "m8", False),
    # a7: two frauds three days apart at two merchants: neither a burst nor a series.
    ("a7", 2 * DAY, 1, 14.0, "m1", False), ("a7", 5 * DAY, 1, 15.0, "m2", False),
    # a8: an account without fraud with two alerted rows.
    ("a8", 1 * DAY, 0, 100.0, "m1", True), ("a8", 2 * DAY, 0, 100.0, "m1", True),
    ("a8", 3 * DAY, 0, 100.0, "m1", False),
]


def hand_table():
    """The hand-made rows as a table with the column names of settings, plus the alerted flags."""
    rows = pd.DataFrame(HAND_ROWS, columns=["account", "offset", "fraud", "amount", "merchant", "alerted"])
    df = pd.DataFrame({
        settings.ID_COL: np.arange(len(rows)) + 1,
        settings.ACCOUNT_COL: rows["account"],
        settings.TIME_COL: JUNE + pd.to_timedelta(rows["offset"], unit="s"),
        settings.LABEL_COL: rows["fraud"],
        settings.AMOUNT_COL: rows["amount"],
        settings.MERCHANT_COL: rows["merchant"],
    })
    return df, rows["alerted"].to_numpy()


def slow_runs(df, alerted, ranked, gap=_shared.RUN_GAP):
    """Runs, positions and first catches by walking each account's frauds in time order (plain loops)."""
    secs = _shared.row_seconds(df)
    fraud = _shared.fraud_flags(df) > 0
    accounts = df[settings.ACCOUNT_COL].to_numpy()
    merchants = df[settings.MERCHANT_COL].to_numpy() if settings.MERCHANT_COL in df.columns else None
    amounts = df[settings.AMOUNT_COL].to_numpy(dtype=float)
    runs = []
    for account in pd.unique(accounts):
        rows = sorted((int(secs[i]), i) for i in range(len(df)) if accounts[i] == account and fraud[i])
        current, last = [], None
        for second, i in rows:
            if last is not None and second - last > gap:
                runs.append(current)
                current = []
            current.append(i)
            last = second
        if current:
            runs.append(current)
    lines = []
    for members in runs:
        position = {i: 1 + sum(1 for j in members if secs[j] < secs[i]) for i in members}
        caught = [i for i in members if alerted[i] and ranked[i]]
        span = max(secs[i] for i in members) - min(secs[i] for i in members)
        series = False
        if merchants is not None:
            for m in set(merchants[i] for i in members):
                here = [secs[i] for i in members if merchants[i] == m]
                series = series or (len(here) >= 3 and max(here) - min(here) > run_scorecard.SERIES_SPAN)
        kind = ("single" if len(members) == 1 else "burst" if span <= run_scorecard.BURST_SPAN
                else "series" if series else "other")
        lines.append({"members": members, "position": position, "kind": kind,
                      "starts_ranked": any(ranked[i] for i in members if position[i] == 1),
                      "first_position": min(position[i] for i in caught) if caught else None,
                      "first_second": min(secs[i] for i in caught) if caught else None,
                      "amount": {i: amounts[i] for i in members}})
    return lines


def slow_card(df, alerted, ranked, alerted_accounts, gap=_shared.RUN_GAP):
    """Every scorecard measure as a dict, counted line by line from `slow_runs`."""
    runs = slow_runs(df, alerted, ranked, gap)
    secs = _shared.row_seconds(df)
    ranked_frauds = [i for r in runs for i in r["members"] if ranked[i]]
    own = [r for r in runs if r["starts_ranked"]]
    out = {"ranked frauds": len(ranked_frauds),
           "frauds inside the cut": sum(1 for i in ranked_frauds if alerted[i]),
           "runs that start in the ranked rows": len(own),
           "runs that began earlier": sum(1 for r in runs
                                          if not r["starts_ranked"] and any(ranked[i] for i in r["members"])),
           "runs caught at all": sum(1 for r in own if r["first_position"] is not None) / len(own),
           "first fraud of the run caught": sum(1 for r in own if r["first_position"] == 1) / len(own)}
    out["row capture"] = out["frauds inside the cut"] / len(ranked_frauds)
    for n in run_scorecard.WITHIN[1:]:
        out[f"runs caught within their first {n} frauds"] = sum(
            1 for r in own if r["first_position"] is not None and r["first_position"] <= n) / len(own)
    total_dollars = sum(r["amount"][i] for r in runs for i in r["members"] if ranked[i])
    for lag, name in run_scorecard.LAGS:
        saved = [(r, i) for r in runs if r["first_second"] is not None for i in r["members"]
                 if ranked[i] and secs[i] >= r["first_second"] + lag]
        out[f"frauds at or after the first catch, {name}"] = len(saved) / len(ranked_frauds)
        saved_dollars = sum(r["amount"][i] for r, i in saved)
        out[f"fraud dollars at or after the first catch, {name}"] = saved_dollars / total_dollars
    caught_accounts = len({df[settings.ACCOUNT_COL].iloc[i] for i in ranked_frauds if alerted[i]})
    out["alerted accounts"] = alerted_accounts
    out["accounts with a caught fraud"] = caught_accounts
    out["alerted accounts per account with a caught fraud"] = alerted_accounts / caught_accounts
    return out, runs


def card_dict(card):
    """The scorecard table as a dict from measure to value."""
    return dict(zip(card["measure"], card["value"]))


def assert_same_card(card, expected):
    """Every line of the scorecard equals the slow count, and no line is missing or extra."""
    got = card_dict(card)
    assert set(got) == set(expected)
    for measure, value in expected.items():
        assert np.isclose(got[measure], value), measure


@pytest.fixture(scope="module")
def table():
    """Made-up whole accounts over two months with a model score, so that runs can begin before the scored month."""
    df = synthetic.make_transactions(n_accounts=700, seed=41, fraud_account_share=0.15)
    # Second runs on some fraud accounts, a few days or weeks after the first, so that the gap matters.
    rng = np.random.default_rng(41)
    fraud_rows = df.index[df[settings.LABEL_COL] == 1]
    extra = df.loc[rng.choice(fraud_rows, 60, replace=False)].copy()
    extra[settings.TIME_COL] = extra[settings.TIME_COL] + pd.to_timedelta(rng.choice([2, 5, 12, 20], 60), unit="D")
    extra[settings.ID_COL] = df[settings.ID_COL].max() + 1 + np.arange(len(extra))
    df = pd.concat([df, extra], ignore_index=True)
    return synthetic.make_scores(df, seed=41, strength=2.0)


def test_hand_made_runs_get_the_worked_out_types_positions_and_catches():
    """On the hand-made rows each run has the type, first catch and start that the comments above work out."""
    df, alerted = hand_table()
    ranked = _shared.ranked_rows(df)
    assert ranked.sum() == len(df) - 1                                    # only the May fraud of a4 is history
    frauds = run_scorecard.fraud_lines(df, alerted, ranked)
    runs = run_scorecard.run_lines(frauds)
    names = {code: name for code, name in zip(_shared.account_codes(df), df[settings.ACCOUNT_COL])}
    runs["name"] = runs["account"].map(names)
    by = runs.sort_values(["name", "first_second"]).set_index(["name", "first_second"])
    assert len(runs) == 8 and frauds["position"].min() == 1
    got = {(name, kind) for (name, _), kind in by["run_type"].items()}
    assert got == {("a1", "burst"), ("a2", "single"), ("a3", "series"), ("a4", "other"), ("a5", "burst"),
                   ("a6", "single"), ("a7", "other")}
    first = runs.groupby("name")["first_catch_position"].min()
    assert first["a1"] == 2 and first["a2"] == 1 and first["a5"] == 1 and first["a4"] == 3
    assert np.isnan(first["a3"]) and np.isnan(first["a6"]) and np.isnan(first["a7"])
    assert runs.loc[runs["name"] == "a4", "starts_ranked"].tolist() == [False]
    assert runs.loc[runs["name"] != "a4", "starts_ranked"].all()
    # The two frauds of a5 in one second share position 1; the fraud an hour later is position 3.
    a5 = frauds[frauds["account"] == _shared.account_codes(df)[df[settings.ACCOUNT_COL].eq("a5").to_numpy()][0]]
    assert sorted(a5["position"]) == [1, 1, 3]


def test_hand_made_scorecard_equals_the_figures_worked_out_by_hand():
    """Runs, first catches, prevented frauds and dollars at each lag match a count done by hand."""
    df, alerted = hand_table()
    ranked = _shared.ranked_rows(df)
    frauds = run_scorecard.fraud_lines(df, alerted, ranked)
    runs = run_scorecard.run_lines(frauds)
    card = card_dict(run_scorecard.scorecard(frauds, runs, alerted_accounts=5))
    assert card["ranked frauds"] == 16 and card["frauds inside the cut"] == 4
    assert card["runs that start in the ranked rows"] == 7 and card["runs that began earlier"] == 1
    assert np.isclose(card["runs caught at all"], 3 / 7) and np.isclose(card["first fraud of the run caught"], 2 / 7)
    assert np.isclose(card["runs caught within their first 2 frauds"], 3 / 7)
    # No lag: a1 keeps 2 frauds (20 + 30 dollars), a2 1 (40), a4 1 (70), a5 all 3 (28).
    assert np.isclose(card["frauds at or after the first catch, no lag"], 7 / 16)
    assert np.isclose(card["fraud dollars at or after the first catch, no lag"], 188 / 330)
    # One hour: only the 5-hour fraud of a1 and the fraud of a5 one hour after its catch remain.
    assert np.isclose(card["frauds at or after the first catch, lag 1 hour"], 2 / 16)
    assert np.isclose(card["fraud dollars at or after the first catch, lag 1 hour"], 41 / 330)
    assert card["frauds at or after the first catch, lag 24 hours"] == 0
    assert card["accounts with a caught fraud"] == 4
    assert np.isclose(card["alerted accounts per account with a caught fraud"], 5 / 4)
    expected, _ = slow_card(df, alerted, ranked, 5)
    assert_same_card(run_scorecard.scorecard(frauds, runs, alerted_accounts=5), expected)


def test_run_type_table_counts_frauds_and_misses_per_type():
    """Each run type's frauds, catches and share of the missed frauds equal plain counts over the hand-made runs."""
    df, alerted = hand_table()
    ranked = _shared.ranked_rows(df)
    frauds = run_scorecard.fraud_lines(df, alerted, ranked)
    types = run_scorecard.run_type_table(frauds, run_scorecard.run_lines(frauds)).set_index("run_type")
    assert list(types.index) == list(run_scorecard.RUN_TYPES) + ["all"]
    # Ranked frauds per type: single a2 + a6 (3), burst a1 + a5 (6), series a3 (3), other a4 + a7 (4).
    assert types["frauds"].to_dict() == {"single": 3, "burst": 6, "series": 3, "other": 4, "all": 16}
    assert types["caught"].to_dict() == {"single": 1, "burst": 2, "series": 0, "other": 1, "all": 4}
    assert types["runs"].to_dict() == {"single": 3, "burst": 2, "series": 1, "other": 1, "all": 7}
    assert np.isclose(types.loc["series", "share_of_missed"], 3 / 12)
    assert np.isclose(types.loc["all", "share_of_missed"], 1.0)
    assert np.isclose(types.loc["burst", "first_caught"], 0.5) and np.isclose(types.loc["single", "runs_caught"], 1 / 3)
    assert np.isclose(types.loc[list(run_scorecard.RUN_TYPES), "share_of_frauds"].sum(), 1.0)


def test_gap_and_missing_merchant_change_the_runs_as_expected(capsys):
    """A one-day gap splits the slower runs, and without a merchant column the series becomes 'other'."""
    df, alerted = hand_table()
    ranked = _shared.ranked_rows(df)
    tight = run_scorecard.run_lines(run_scorecard.fraud_lines(df, alerted, ranked, run_gap=DAY))
    # a3 splits into three singles, a4 into two runs (May alone; June 2 and 3 together), a7 into two singles.
    assert len(tight) == 12 and (tight["run_type"] == "series").sum() == 0
    no_merchant = df.drop(columns=[settings.MERCHANT_COL])
    frauds = run_scorecard.fraud_lines(no_merchant, alerted, ranked)
    assert "series' is skipped" in capsys.readouterr().out and "merchant" not in frauds.columns
    kinds = run_scorecard.run_lines(frauds)["run_type"].value_counts().to_dict()
    assert kinds == {"single": 3, "burst": 2, "other": 3}
    # An unknown merchant matches no other row, so three frauds without a merchant are never a series.
    blank = df.copy()
    blank.loc[blank[settings.ACCOUNT_COL] == "a3", settings.MERCHANT_COL] = None
    assert "series" not in set(run_scorecard.run_lines(run_scorecard.fraud_lines(blank, alerted, ranked))["run_type"])
    # Without amounts the dollar lines stay empty, one line says so, and the counts are unchanged.
    frauds = run_scorecard.fraud_lines(df.drop(columns=[settings.AMOUNT_COL]), alerted, ranked)
    assert "dollar figures are skipped" in capsys.readouterr().out
    card = card_dict(run_scorecard.scorecard(frauds, run_scorecard.run_lines(frauds)))
    assert np.isnan(card["fraud dollars at or after the first catch, no lag"])
    assert np.isclose(card["frauds at or after the first catch, no lag"], 7 / 16) and np.isnan(card["alerted accounts"])


@pytest.mark.parametrize("gap", [DAY, _shared.RUN_GAP, 40 * DAY])
def test_scorecard_equals_a_slow_count_on_made_up_accounts(table, gap):
    """At three gaps, every measure and every run type equals the loop count over the same alerts."""
    result = run_scorecard.score_one(table, table[settings.SCORE_COL].to_numpy(), run_gap=gap)
    ranked = _shared.ranked_rows(table)
    alerted = np.zeros(len(table), dtype=bool)
    alerted[ranked] = ranking.alert_mask(table[settings.SCORE_COL].to_numpy()[ranked])
    alerted_accounts = table.loc[alerted, settings.ACCOUNT_COL].nunique()
    expected, runs = slow_card(table, alerted, ranked, alerted_accounts, gap)
    assert_same_card(result["card"], expected)
    assert 0 < expected["runs caught at all"] < 1
    if gap >= _shared.RUN_GAP:
        assert expected["runs that began earlier"] > 0                      # some runs reach back into May
    got = result["runs"]
    assert len(got) == len(runs)
    assert got["run_type"].value_counts().to_dict() == pd.Series([r["kind"] for r in runs]).value_counts().to_dict()
    assert np.isclose(got["first_catch_position"].sum(), sum(r["first_position"] or 0 for r in runs))
    assert result["types"].set_index("run_type").loc["all", "frauds"] == expected["ranked frauds"]


def test_history_rows_take_no_alert_place_and_row_order_does_not_matter(table):
    """The cut is found on the ranked rows only, and shuffling the rows leaves every figure unchanged."""
    scores = table[settings.SCORE_COL].to_numpy().copy()
    ranked = _shared.ranked_rows(table)
    scores[~ranked] = 1.0                                                   # history rows with the top score
    result = run_scorecard.score_one(table, scores)
    base = run_scorecard.score_one(table, table[settings.SCORE_COL].to_numpy())
    inside = "frauds inside the cut"
    assert card_dict(result["card"])[inside] == card_dict(base["card"])[inside]
    assert card_dict(base["card"])["frauds inside the cut"] == ranking.capture(
        _shared.fraud_flags(table)[ranked], table[settings.SCORE_COL].to_numpy()[ranked])["caught"]
    shuffled = table.sample(frac=1.0, random_state=3).reset_index(drop=True)
    again = run_scorecard.score_one(shuffled, shuffled[settings.SCORE_COL].to_numpy())
    assert np.allclose(base["card"]["value"], again["card"]["value"], equal_nan=True)


def test_tool_prints_the_tables_and_writes_the_runs(table, tmp_path, capsys):
    """The tool reads two score files, joins the merchant from raw files and writes the per-run table when asked."""
    first = tables.write_table(table[STANDARD], str(tmp_path / "a.parquet"))
    other = synthetic.make_scores(table, seed=7, strength=1.0)[[settings.ID_COL, settings.SCORE_COL]]
    second = tables.write_table(other, str(tmp_path / "b.parquet"))
    numbers = synthetic.write_files(table, tmp_path / "raw", 2, first_number=30)
    out = str(tmp_path / "runs.parquet")
    run_scorecard.main(["--preds", first, second, "--names", "strong", "weak", "--raw-base", str(tmp_path / "raw"),
                        "--raw-files", f"{numbers[0]}-{numbers[-1]}", "--out", out])
    printed = capsys.readouterr().out
    for text in ("Run types for strong", "Run types for weak", "Run-level scorecard", "series"):
        assert text in printed
    written = tables.read_columns(out)
    assert {"run", "frauds", "first_catch_position", "run_type"} <= set(written.columns)
    direct = run_scorecard.score_one(table, table[settings.SCORE_COL].to_numpy())["runs"]
    assert len(written) == len(direct) and written["run_type"].tolist() == direct["run_type"].tolist()
    run_scorecard.main(["--preds", first, "--gap-days", "1"])
    assert "series' is skipped" in capsys.readouterr().out                  # the score file has no merchant
    run_scorecard.main(["--preds", first, "--start", "2031-01-01", "--end", "2031-02-01"])
    assert "no row falls in the scored month" in capsys.readouterr().out
