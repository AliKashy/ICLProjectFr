"""Tests of the helpers shared by the feature builders.

Each test states one rule the helpers keep and checks it on a few hand-made values.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic
from additions.common.history import EarlierRows
from additions.features import _shared


def test_a_missing_or_blank_value_gets_no_code():
    """Missing values and blank text carry -1, and equal values share one code."""
    codes, distinct = _shared.value_codes(np.array(["a", None, " ", "b", "a", np.nan, ""], dtype=object))
    assert codes.tolist() == [0, -1, -1, 1, 0, -1, -1]
    assert distinct.tolist() == ["a", "b"]
    assert _shared.value_codes(np.array([]))[0].tolist() == []


def test_whole_numbers_and_decimals_become_the_same_text():
    """A column stored as decimals and the same column stored as whole numbers give equal texts."""
    codes, texts = _shared.coded_text(np.array([5.0, 5.5, np.nan, 5.0, 7.0]))
    assert codes.tolist() == [0, 1, -1, 0, 2] and texts.tolist() == ["5", "5.5", "7"]
    assert _shared.coded_text(np.array([5, 7]))[1].tolist() == ["5", "7"]
    assert _shared.coded_text(np.array(["05 ", "05", None], dtype=object))[0].tolist() == [0, 0, -1]


def test_a_change_of_the_distinct_values_merges_their_codes():
    """Two addresses in the same network share a code once only the first two parts are compared."""
    values = np.array(["1.2.3.4", "1.2.9.9", "8.8.8.8", None], dtype=object)
    codes, distinct = _shared.value_codes(values, _shared.ip_prefix)
    assert codes.tolist() == [0, 0, 1, -1] and distinct.tolist() == ["1.2", "8.8"]


def test_rows_without_a_value_never_match_in_the_key_engine():
    """Two rows with no merchant are not "the same merchant", and a later row does not count them."""
    account = np.zeros(5, dtype=np.int64)
    secs = np.array([10, 20, 30, 40, 50], dtype=np.int64)
    codes, _ = _shared.value_codes(np.array(["m", None, None, "m", "m"], dtype=object))
    engine = _shared.key_engine(account, codes, secs)
    assert engine.count().tolist() == [0, 0, 0, 1, 2]
    # Two values that must match at once: the merchant and an amount.
    cents, _ = _shared.value_codes(np.array([100.0, 100.0, 100.0, np.nan, 100.0]))
    both = _shared.key_engine(account, [codes, cents], secs)
    assert both.count().tolist() == [0, 0, 0, 0, 1]


def test_a_row_without_account_or_time_is_outside_every_history():
    """A row that cannot be placed gets the missing-time marker and its own account code."""
    df = pd.DataFrame({settings.ACCOUNT_COL: ["a", None, "a", "a"],
                       settings.TIME_COL: pd.to_datetime(["2025-05-01", "2025-05-02", None, "2025-05-03"])})
    account, secs = _shared.account_and_time(df)
    assert (secs[1] == _shared.MISSING_SECOND) and (secs[2] == _shared.MISSING_SECOND)
    assert account[0] == account[3] != account[1]
    assert _shared.history_start(secs, 1)[1] == 0 and _shared.history_start(secs, None) is None


def test_blockwise_cuts_the_table_at_each_rows_lookback_start():
    """Computed block by block, a plain count equals the count the engine gives with a look-back start."""
    df = synthetic.make_transactions(n_accounts=20, days=92, start="2024-10-01", seed=3)
    df.loc[df.index[7], settings.TIME_COL] = pd.NaT                              # one row cannot be placed in time
    account, secs = _shared.account_and_time(df)
    placed = secs != _shared.MISSING_SECOND

    def earlier_rows(rows):
        return {"n": EarlierRows(account[rows], secs[rows]).count()}

    by_block = _shared.blockwise(secs, 1, earlier_rows)["n"]
    with_start = EarlierRows(account, secs, start=_shared.history_start(secs, 1)).count()
    assert (by_block[placed] == with_start[placed]).all() and np.isnan(by_block[7])
    one_block = _shared.blockwise(secs, None, earlier_rows)["n"]                 # no calendar rule: the whole table
    assert (one_block[placed] == EarlierRows(account, secs).count()[placed]).all()
    times_target = np.zeros(len(df), dtype=int)
    for rows, is_target in _shared.blocks(secs, 1):
        times_target[rows[is_target]] += 1
    assert (times_target[placed] == 1).all() and times_target[7] == 0            # each row is a target exactly once


def test_ratio_gives_a_missing_value_instead_of_a_large_number():
    """A zero, negative or missing denominator gives a missing value, never an infinite one."""
    out = _shared.ratio([1.0, 1.0, 1.0, 1.0, np.nan], [2.0, 0.0, -1.0, np.nan, 1.0])
    assert out[0] == 0.5 and np.isnan(out[1:]).all()


def test_population_share_can_leave_out_the_rows_own_account():
    """With the own account removed, the count equals that of a table fitted without the account."""
    account = np.array([0, 0, 1, 1, 2])
    codes, texts = _shared.coded_text(np.array(["x", "x", "x", "y", "z"], dtype=object))
    table = _shared.count_table(codes, texts)
    assert table == {"counts": {"x": 3, "y": 1, "z": 1}, "rows": 5}
    assert np.allclose(_shared.table_share(codes, texts, table), (np.array([3, 3, 3, 1, 1]) + 1) / (5 + 4))
    own, own_rows = _shared.own_counts(account, codes)
    for i in range(len(account)):
        others = account != account[i]
        without = _shared.count_table(codes[others], texts)
        assert _shared.table_counts(codes, texts, table, own)[i] == without["counts"].get(texts[codes[i]], 0)
        assert table["rows"] - own_rows[i] == without["rows"]
    # A table cut to its most frequent value reads every other value as never seen.
    top = _shared.count_table(codes, texts, top=1)
    assert _shared.table_counts(codes, texts, top).tolist() == [3, 3, 3, 0, 0] and top["rows"] == 5


def test_previous_pairs_follow_the_strictly_earlier_rule():
    """The pair of a row joins the value of the account's previous row with its own value."""
    account = np.zeros(5, dtype=np.int64)
    secs = np.array([10, 20, 20, 30, 40], dtype=np.int64)
    codes, texts = _shared.coded_text(np.array(["a", "b", "c", None, "a"], dtype=object))
    pair, pair_texts, previous = _shared.previous_pairs(EarlierRows(account, secs), codes, texts)
    # Rows two and three share a second: both follow "a", neither follows the other. Row four has no value.
    assert [pair_texts[p] if p >= 0 else None for p in pair] == [None, "a > b", "a > c", None, "c > a"]
    assert previous.tolist() == [-1, 0, 0, -1, 2]


def test_tables_survive_a_round_trip_through_a_file(tmp_path):
    """Fitted tables are plain dictionaries, so writing and reading them changes nothing."""
    fitted = {"fields": {"hour": {"counts": {"3": 2, "17": 5}, "rows": 7}}, "edges": [1.0, 5.0]}
    path = _shared.save_tables(fitted, str(tmp_path / "tables.json"))
    assert _shared.load_tables(path) == fitted


def test_frames_are_aligned_and_optional_columns_are_skipped_with_one_line(capsys):
    """Output rows follow the input index; a column that is switched off or absent is skipped, not fatal."""
    df = synthetic.make_transactions(n_accounts=5, seed=1).iloc[::-1]
    frame = _shared.as_frame({"flag": np.ones(len(df), dtype=bool), "value": np.full(len(df), np.nan),
                              "code": np.arange(len(df)) % 3}, df.index, fill=0.0, codes=("code",))
    assert frame.index.equals(df.index) and frame["value"].eq(0.0).all()
    assert str(frame["flag"].dtype) == "float32" and str(frame["code"].dtype) == "int16"
    assert _shared.column(df, None, "the test") is None and _shared.column(df, "absent", "the test") is None
    found = _shared.columns(df, {"merchant": settings.MERCHANT_COL, "card": None, "other": "absent"}, "keys")
    assert list(found) == ["merchant"]
    assert capsys.readouterr().out.count("note:") == 3
    assert list(_shared.summary(frame)["column"]) == ["flag", "value", "code"]
