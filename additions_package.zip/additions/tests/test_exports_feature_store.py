"""Tests of the store of export columns and its as-of lookup.

Every answer is compared with a plain loop over the store rows of the query's account. Further
tests check the time rule, the lag, that the label is never stored and that the manifest is
written beside the table and read back.
"""
import json

import numpy as np
import pandas as pd
import pytest

from additions import settings
from additions.common import tables, timekeys
from additions.exports import feature_store

COLUMNS = [settings.SCORE_COL, f"{settings.VECTOR_PREFIX}0", "w_max_24h"]


@pytest.fixture(scope="module")
def table():
    """Made-up export columns of whole account histories."""
    return feature_store.demo_table(n_accounts=60, seed=2)


@pytest.fixture(scope="module")
def store(table):
    """The store of the made-up table, with no lag."""
    return feature_store.build_store(table, COLUMNS, lag_seconds=0)


@pytest.fixture(scope="module")
def queries(table):
    """Queries at made-up moments: at transaction times (same second), a little after, and on unknown accounts."""
    rng = np.random.default_rng(0)
    pick = table.iloc[rng.integers(0, len(table), 400)]
    shift = rng.choice([0, 1, 30, 3_600, -5], len(pick))
    when = pd.to_datetime(pick[settings.TIME_COL]).to_numpy() + pd.to_timedelta(shift, unit="s")
    q = pd.DataFrame({settings.ACCOUNT_COL: pick[settings.ACCOUNT_COL].to_numpy(), settings.TIME_COL: when})
    extra = pd.DataFrame({settings.ACCOUNT_COL: ["nobody", None],
                          settings.TIME_COL: pd.to_datetime(["2025-05-20", "2025-05-20"])})
    return pd.concat([q, extra], ignore_index=True)


def _slow_answer(store, account, when):
    """Position in the store of the answer to one query, from a plain look at the store; -1 when none."""
    valid = timekeys.seconds(store[feature_store.VALID_FROM_COL])
    candidates = np.flatnonzero((store[settings.ACCOUNT_COL].to_numpy() == account) & (valid < when)
                                & (valid != timekeys.MISSING_SECOND))
    if len(candidates) == 0:
        return -1
    latest = valid[candidates].max()
    return int(candidates[valid[candidates] == latest].max())          # the last in table order inside one second


def test_store_has_keys_valid_from_and_columns_but_never_the_label(table, store, capsys):
    """The store keeps one row per transaction with id, account, valid-from and the export columns only."""
    assert list(store.columns) == [settings.ID_COL, settings.ACCOUNT_COL, feature_store.VALID_FROM_COL] + COLUMNS
    assert len(store) == len(table) and set(store[settings.ID_COL]) == set(table[settings.ID_COL])
    by_id = table.set_index(settings.ID_COL)
    assert np.allclose(store[settings.SCORE_COL], by_id.loc[store[settings.ID_COL], settings.SCORE_COL])
    assert (timekeys.seconds(store[feature_store.VALID_FROM_COL])
            == timekeys.seconds(by_id.loc[store[settings.ID_COL], settings.TIME_COL])).all()
    default = feature_store.build_store(table)
    assert settings.LABEL_COL not in default.columns and settings.ORDER_COL not in default.columns
    asked = feature_store.build_store(table, [settings.LABEL_COL, settings.SCORE_COL, "absent"])
    assert list(asked.columns)[3:] == [settings.SCORE_COL]
    printed = capsys.readouterr().out
    assert "absent" in printed and "not stored" in printed


def test_lookup_equals_a_loop_over_earlier_store_rows(store, queries):
    """Every answer is the latest store row of the same account with a strictly earlier valid-from second."""
    answers = feature_store.asof_lookup(store, queries)
    assert list(answers.columns) == [feature_store.ASOF_ID_COL, feature_store.ASOF_VALID_FROM_COL] + COLUMNS
    assert (answers.index == queries.index).all()
    when = timekeys.seconds(queries[settings.TIME_COL])
    found = 0
    for i in range(len(queries)):
        slow = _slow_answer(store, queries[settings.ACCOUNT_COL].iloc[i], when[i])
        if slow < 0:
            assert pd.isna(answers[feature_store.ASOF_ID_COL].iloc[i]) and np.isnan(answers[settings.SCORE_COL].iloc[i])
            continue
        found += 1
        assert answers[feature_store.ASOF_ID_COL].iloc[i] == store[settings.ID_COL].iloc[slow]
        for name in COLUMNS:
            assert np.isclose(answers[name].iloc[i], store[name].iloc[slow], equal_nan=True)
    assert 300 < found < len(queries)
    assert pd.isna(answers[feature_store.ASOF_ID_COL].iloc[-1]) and pd.isna(answers[feature_store.ASOF_ID_COL].iloc[-2])
    assert answers[feature_store.ASOF_ID_COL].dtype == "Int64"             # ids stay whole numbers


def test_same_second_rows_never_answer_and_the_lag_moves_the_valid_from_time():
    """A query at a row's own second reads the earlier second; a lag hides values until they are valid."""
    df = pd.DataFrame({
        settings.ID_COL: [11, 12, 13, 14, 15],
        settings.ACCOUNT_COL: ["a", "a", "a", "b", "a"],
        settings.TIME_COL: pd.to_datetime([100, 200, 200, 150, None], unit="s"),
        settings.ORDER_COL: [0, 2, 1, 0, 3],
        "value": [1.0, 2.0, 3.0, 9.0, 7.0],
    })
    store = feature_store.build_store(df, ["value"])
    q = pd.DataFrame({settings.ACCOUNT_COL: ["a", "a", "a", "a", "b"],
                      settings.TIME_COL: pd.to_datetime([100, 101, 200, 201, 150], unit="s")})
    got = feature_store.asof_lookup(store, q)
    assert [None if pd.isna(v) else int(v) for v in got[feature_store.ASOF_ID_COL]] == [None, 11, 11, 12, None]
    # Second 200 holds ids 13 (sequence 1) and 12 (sequence 2): the later in sequence answers.
    assert got["value"].iloc[3] == 2.0 and np.isnan(got["value"].iloc[4])
    lagged = feature_store.build_store(df, ["value"], lag_seconds=60)
    later = pd.DataFrame({settings.ACCOUNT_COL: ["a", "a", "a"],
                          settings.TIME_COL: pd.to_datetime([160, 161, 261], unit="s")})
    got = feature_store.asof_lookup(lagged, later)
    assert np.isnan(got["value"].iloc[0]) and got["value"].iloc[1] == 1.0 and got["value"].iloc[2] == 2.0


def test_later_store_rows_do_not_change_earlier_answers(table, store, queries):
    """A store cut off at a moment gives the same answers to every query before that moment."""
    cut = np.quantile(timekeys.seconds(table[settings.TIME_COL]), 0.6)
    part = feature_store.build_store(table[timekeys.seconds(table[settings.TIME_COL]) < cut], COLUMNS, lag_seconds=0)
    early = timekeys.seconds(queries[settings.TIME_COL]) <= cut
    full = feature_store.asof_lookup(store, queries[early])
    cut_off = feature_store.asof_lookup(part, queries[early])
    assert early.sum() > 50 and full.equals(cut_off)


def test_manifest_is_written_beside_the_table_and_read_back(store, tmp_path, capsys):
    """The table and a plain-text manifest with model, version, columns and rule are written and read again."""
    path = str(tmp_path / "store.parquet")
    _, manifest_file = feature_store.write_store(store, path, version="v7", model_name="demo model",
                                                 extra={"drift_auc": 0.51})
    assert manifest_file == str(tmp_path / "store.manifest.json")
    table, manifest = feature_store.read_store(path)
    assert len(table) == len(store) and manifest["version"] == "v7" and manifest["model_name"] == "demo model"
    assert list(manifest["columns"]) == COLUMNS and manifest["rows"] == len(store) and manifest["drift_auc"] == 0.51
    assert "strictly earlier" in manifest["lookup_rule"]
    with open(manifest_file, encoding="ascii") as handle:
        assert json.load(handle) == manifest
    feature_store.write_store(store.iloc[:10], path, version="v8")              # an existing store is replaced
    assert len(feature_store.read_store(path)[0]) == 10
    (tmp_path / "store.manifest.json").unlink()
    assert feature_store.read_store(path)[1] is None and "no manifest" in capsys.readouterr().out


def test_tool_builds_a_store_and_answers_queries(table, queries, tmp_path, capsys):
    """The tool writes a store with its manifest, then answers queries from it."""
    table_path = tables.write_table(table, str(tmp_path / "export.parquet"))
    store_path = str(tmp_path / "store.parquet")
    feature_store.main(["--table", table_path, "--version", "v2", "--out", store_path])
    assert (tmp_path / "store.manifest.json").exists()
    query_path = tables.write_table(queries.iloc[:-2], str(tmp_path / "queries.parquet"))
    answer_path = str(tmp_path / "answers.parquet")
    answers = feature_store.main(["--store", store_path, "--queries", query_path, "--out", answer_path])
    printed = capsys.readouterr().out
    assert "version v2" in printed and "queries found an earlier row" in printed
    assert len(tables.read_columns(answer_path)) == len(answers) == len(queries) - 2
    assert len(feature_store.main(["--demo"])) > 0
