"""Tests of the day and cluster resampling and of the bar raised for many arms.

The units are compared with a plain group-by, each interval with a direct call of the paired
bootstrap on those units, the expected best of several arms with a simulation, and the day
interval is shown to widen when fraud comes in waves.
"""
import numpy as np
import pandas as pd
import pytest

from additions import settings
from additions.common import ranking, synthetic, tables
from additions.common.bootstrap import paired_bootstrap
from additions.common.timekeys import MISSING_SECOND
from additions.proof import _shared, block_bootstrap

STANDARD = [settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL, settings.LABEL_COL, settings.AMOUNT_COL,
            settings.SCORE_COL]


@pytest.fixture(scope="module")
def june():
    """The scored month of a made-up table, with a candidate score and a control score."""
    df = synthetic.make_transactions(n_accounts=800, seed=31, fraud_account_share=0.12)
    df = synthetic.make_scores(df, seed=31, strength=2.5)
    df = synthetic.make_scores(df, seed=32, strength=2.0, column="control")
    part = df[_shared.ranked_rows(df)].reset_index(drop=True)
    return {"table": df, "frame": part, "labels": _shared.fraud_flags(part), "secs": _shared.row_seconds(part),
            "accounts": _shared.account_codes(part), "a": part[settings.SCORE_COL].to_numpy(),
            "b": part["control"].to_numpy(), "merchant": part[settings.MERCHANT_COL].to_numpy()}


def test_day_blocks_and_clusters_group_the_right_rows(june):
    """Rows share a day unit exactly when they share a calendar day, and a missing value stands alone."""
    stamps = pd.to_datetime(june["frame"][settings.TIME_COL])
    day = block_bootstrap.day_units(june["secs"])
    assert pd.Series(day).groupby(stamps.dt.floor("D").to_numpy()).nunique().max() == 1
    assert len(np.unique(day)) == stamps.dt.floor("D").nunique() == 30
    three = block_bootstrap.day_units(june["secs"], 3)
    assert pd.Series(three).groupby(day).nunique().max() == 1                # a day is never split over two blocks
    assert pd.Series(day).groupby(three).nunique().max() == 3 and len(np.unique(three)) < 12
    secs = june["secs"].copy()
    secs[:5] = MISSING_SECOND
    assert len(set(block_bootstrap.day_units(secs)[:5].tolist())) == 1       # rows without a time form one block

    values = np.array(["m1", "m2", None, "m1", None, "m3"], dtype=object)
    units = block_bootstrap.cluster_units(values)
    assert units[0] == units[3] and len(set(units.tolist())) == 5            # the two missing values do not cluster
    merchant = block_bootstrap.cluster_units(june["merchant"])
    assert pd.Series(merchant).groupby(june["merchant"]).nunique().max() == 1
    assert len(np.unique(merchant)) == len(np.unique(june["merchant"]))


def test_every_interval_is_the_paired_bootstrap_on_other_units(june):
    """Each line equals a direct call of the paired bootstrap with that line's units; the gain never changes."""
    table = block_bootstrap.all_intervals(june["labels"], june["a"], june["b"], june["accounts"], june["secs"],
                                          june["merchant"], draws=80, seed=7)
    assert table["resampled"].tolist() == ["account", "day", "3-day block", "cluster"]
    units = {"account": june["accounts"], "day": june["secs"] // 86_400, "3-day block": june["secs"] // (3 * 86_400),
             "cluster": june["merchant"]}
    gain = ranking.capture(june["labels"], june["a"])["udr"] - ranking.capture(june["labels"], june["b"])["udr"]
    for line in table.itertuples():
        direct = paired_bootstrap(units[line.resampled], june["labels"], june["a"], june["b"], draws=80, seed=7)
        assert np.isclose(line.low, direct["low"]) and np.isclose(line.high, direct["high"])
        assert np.isclose(line.gain, gain) and np.isclose(line.width, direct["high"] - direct["low"])
        assert line.units == len(np.unique(units[line.resampled]))
    assert table["widest"].sum() == 1 and table.loc[table["widest"], "width"].iloc[0] == table["width"].max()
    assert block_bootstrap.widest(table)["resampled"] == table.loc[table["widest"], "resampled"].iloc[0]
    only_accounts = block_bootstrap.all_intervals(june["labels"], june["a"], june["b"], june["accounts"], draws=20)
    assert only_accounts["resampled"].tolist() == ["account"]
    dollars = block_bootstrap.all_intervals(june["labels"], june["a"], june["b"], june["accounts"], june["secs"],
                                            amounts=june["frame"][settings.AMOUNT_COL].to_numpy(), block_days=(1,),
                                            draws=20, value=True)
    vdr = [ranking.capture(june["labels"], s, june["frame"][settings.AMOUNT_COL].to_numpy())["vdr"] for s in (june["a"], june["b"])]
    assert dollars["resampled"].tolist() == ["account", "day"] and np.isclose(dollars["gain"].iloc[0], vdr[0] - vdr[1])


def test_resampling_days_widens_the_interval_when_fraud_comes_in_waves(june):
    """When each day favours one of the two models, the day interval is clearly wider than the account interval."""
    rng = np.random.default_rng(0)
    y, day = june["labels"], june["secs"] // 86_400
    favours_a = (rng.random(int(day.max()) + 1) < 0.5)[day]                  # every day belongs to one model
    base = rng.normal(size=len(y))
    a = base + 0.5 * y + 2.5 * y * favours_a
    b = base + 0.5 * y + 2.5 * y * ~favours_a
    table = block_bootstrap.all_intervals(y, a, b, june["accounts"], june["secs"], block_days=(1,), draws=300, seed=1)
    table = table.set_index("resampled")
    assert table.loc["day", "width"] > 1.2 * table.loc["account", "width"] and bool(table.loc["day", "widest"])
    summary, days = block_bootstrap.daily_wins(y, a, b, june["secs"])
    assert summary["a_ahead"] > 5 and summary["b_ahead"] > 5                 # each model wins its own days
    # Without waves (the same noise, the same bonus on every day) the two intervals are close.
    flat = block_bootstrap.all_intervals(y, base + 2.0 * y, base + 1.0 * y + 0.3 * rng.normal(size=len(y)),
                                         june["accounts"], june["secs"], block_days=(1,), draws=300, seed=1)
    flat = flat.set_index("resampled")
    assert flat.loc["day", "width"] < 1.2 * flat.loc["account", "width"]


def test_daily_wins_are_counts_of_days(june):
    """The frauds each model catches per day equal a loop over the days, and a model against itself is level."""
    summary, days = block_bootstrap.daily_wins(june["labels"], june["a"], june["b"], june["secs"], per_mille=10)
    in_a, in_b = ranking.alert_mask(june["a"], 10), ranking.alert_mask(june["b"], 10)
    stamps = pd.to_datetime(june["frame"][settings.TIME_COL]).dt.strftime("%Y-%m-%d").to_numpy()
    fraud = june["labels"] > 0
    for line in days.itertuples():
        here = fraud & (stamps == line.day)
        assert line.frauds == here.sum() and line.caught_a == (here & in_a).sum() and line.caught_b == (here & in_b).sum()
    assert days["frauds"].sum() == fraud.sum() and days["day"].is_monotonic_increasing
    assert summary["days"] == len(days) == summary["a_ahead"] + summary["b_ahead"] + summary["level"]
    assert summary["a_ahead"] == (days["caught_a"] > days["caught_b"]).sum()
    assert np.isclose(summary["share_a_ahead"], summary["a_ahead"] / (summary["a_ahead"] + summary["b_ahead"]))
    assert np.isclose(summary["p_value"], _shared.exact_test(summary["a_ahead"], summary["b_ahead"]))
    same, _ = block_bootstrap.daily_wins(june["labels"], june["a"], june["a"], june["secs"])
    assert same["level"] == same["days"] and np.isnan(same["share_a_ahead"]) and same["p_value"] == 1.0


def test_expected_best_of_matches_known_values_and_a_simulation():
    """The expected maximum of n normal draws equals the closed forms for two and three and a direct simulation."""
    assert block_bootstrap.expected_best_of(1) == 0.0
    assert np.isclose(block_bootstrap.expected_best_of(2), 1.0 / np.sqrt(np.pi), atol=1e-6)
    assert np.isclose(block_bootstrap.expected_best_of(3), 1.5 / np.sqrt(np.pi), atol=1e-6)
    rng = np.random.default_rng(0)
    for n in (10, 30):
        simulated = rng.normal(size=(200_000, n)).max(axis=1).mean()
        assert abs(block_bootstrap.expected_best_of(n) - simulated) < 0.01
    assert np.isclose(block_bootstrap.expected_best_of(10), 1.5388, atol=1e-3)
    assert np.isclose(block_bootstrap.expected_best_of(30), 2.0428, atol=1e-3)
    # Arms that share part of their noise: the best of them gains less, by the factor sqrt(1 - r).
    shared = np.sqrt(0.6) * rng.normal(size=(200_000, 1)) + np.sqrt(0.4) * rng.normal(size=(200_000, 10))
    assert abs(block_bootstrap.expected_best_of(10, correlation=0.6) - shared.max(axis=1).mean()) < 0.01
    assert np.isclose(block_bootstrap.deflated_bar(10, 0.006), 1.5388 * 0.006, atol=1e-5)
    assert block_bootstrap.deflated_bar(1, 0.006) == 0.0
    assert block_bootstrap.deflated_bar(30, 0.006) > block_bootstrap.deflated_bar(10, 0.006) > block_bootstrap.deflated_bar(10, 0.003)


def test_tool_prints_every_interval_and_the_raised_bar(june, tmp_path, capsys):
    """The tool reads two score files, joins the cluster column from raw files and writes the table when asked."""
    table = june["table"]
    first = tables.write_table(table[STANDARD], str(tmp_path / "candidate.parquet"))
    control = table[[settings.ID_COL, "control"]].rename(columns={"control": settings.SCORE_COL})
    second = tables.write_table(control, str(tmp_path / "control.parquet"))
    numbers = synthetic.write_files(table, tmp_path / "raw", 2, first_number=5)
    out = str(tmp_path / "intervals.parquet")
    block_bootstrap.main(["--preds", first, second, "--draws", "40", "--arms", "12", "--bar", "0.005",
                          "--raw-base", str(tmp_path / "raw"), "--raw-files", f"{numbers[0]}-{numbers[-1]}", "--out", out])
    printed = capsys.readouterr().out
    for text in ("one interval per way of resampling", "widest interval: resampling by", "Days on which each model",
                 "Bar raised for 12 arms"):
        assert text in printed
    written = tables.read_columns(out)
    assert written["resampled"].tolist() == ["account", "day", "3-day block", "cluster"] and written["widest"].sum() == 1
    block_bootstrap.main(["--preds", first, second, "--draws", "20", "--value", "--block-days", "2"])
    printed = capsys.readouterr().out
    assert "2-day block" in printed and "the cluster read is skipped" in printed
