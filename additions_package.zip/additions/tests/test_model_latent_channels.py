"""Tests of the history stage over latent channels.

The central tests are about the time rule, over a grid of every switch (both orders of the two
attention parts inside a row, and both rules for rows of one earlier second, included): a row's
result must not move, bit for bit, when later rows or other rows of its own second are altered or
when padded slots hold anything at all; the first rows of a sequence must give what the sequence cut
after them gives (to rounding), and exactly what it gives with the later slots marked as padding.
Under "whole_seconds" no order of the slots inside a second moves a result beyond rounding, and a
value that is not a number in a later real row leaves the earlier rows bit for bit, in every layout,
as does a finite value larger in size than LARGEST_INPUT, which the stage sets aside the same way.
The others check that channels stay apart where no block mixes them, that one channel with every
extra switched off is a plain stack of standard layers, which earlier rows the memory reaches, that
every weight learns, the weight counts, the identity start of the per-channel maps, shapes for every
readout, mixed precision, the pooler, the description, the plain errors and the import from a flat
folder with pandas out of reach.

The attention bias has tests of its own: a bias of zero gives exactly the result without one, a
bias on pairs the time rule closes changes nothing, a bias on open pairs moves the rows that read
earlier rows, later rows change no earlier row with an AttentionBias of attention_bias.py in place,
and a learned bias trains through the stage. The final within-transaction block (`final_intra`)
is part of the grid, and its own tests check that it is one block more, made after every other
weight, and that it runs last. The stage's own time-gap bias (`time_bias`) starts as a no-op, bit for
bit, keeps the time rule once it has moved, and stops at a second bias. The two orders of the parts of
a within-transaction block hold the same weights and give other results.
"""
import itertools
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest
import torch
import torch.nn as nn

from additions.model import latent_channels as lc
from additions.model import masks
from additions.model._shared import encoder_stack, run_blocks
from additions.model.attention_bias import GAP_EDGES, AttentionBias
from additions.model.interleaved_reread import eligible_rows, latest_prior_rows
from additions.model.latent_channels import ChannelPooler, LatentChannelStage, count_weights, describe

D, M, HEADS, PAIRS, FIELDS, HISTORY = 16, 3, 4, 2, 5, 6

# Match fields of the attention bias in the tests (merchant, merchant category, ... in the model in use).
N_CODES = 3

# Every value of every switch that the grid tests run over: 3 x 2 x 2 x 2 x 2 x 2 x 3 x 2 x 2 = 1152 settings, with the
# default order of the attention parts ("cross_first") and the default rule for ties ("whole_seconds"); `_grid` adds
# the other order and the other rule wherever they make a difference.
SWITCHES = {
    "layout": lc.LAYOUTS,
    "share_temporal": (True, False),
    "intra_self_attention": (True, False),
    "intra_cross_attention": (True, False),
    "channel_identity": (True, False),
    "channel_projections": (False, True),
    "readout": lc.READOUTS,
    "num_back": (0, 3),
    "final_intra": (False, True),
}


def _rule(ties):
    """The keyword arguments that choose a rule for rows of one earlier second: none for the default "whole_seconds",
    so that the default call is the one tested."""
    return {} if ties == "whole_seconds" else {"ties": ties}


def _grid():
    """Every setting of the switches above, as keyword dictionaries, and on top of them every setting where the order of
    the two attention parts of a within-transaction block, or the rule for rows of one earlier second, makes a
    difference, with the value that is not the default: 1152 + 240 + 240 = 1632 settings."""
    names = list(SWITCHES)
    base = [dict(zip(names, values)) for values in itertools.product(*SWITCHES.values())]
    extra = []
    for switches in base:
        within = switches["layout"] != "temporal_only" or switches["final_intra"]
        if within and switches["intra_self_attention"] and switches["intra_cross_attention"]:
            extra.append(dict(switches, intra_order="self_first"))
        if within and switches["intra_cross_attention"] and switches["num_back"]:
            extra.append(dict(switches, ties="slot"))
    return base + extra


def _bias_grid():
    """The switches that decide where a bias goes (layout, shared or own through-time layers, the final block,
    the memory) with every readout: 72 settings. The other switches act inside a row, which a bias never reaches."""
    names = ("layout", "share_temporal", "final_intra", "num_back", "readout")
    values = (lc.LAYOUTS, (True, False), (False, True), (0, 3), lc.READOUTS)
    return [dict(zip(names, chosen)) for chosen in itertools.product(*values)]


def _batch(seed=0, n_channels=M, lengths=(14, 12, 9, 4, 1, 0)):
    """A padded batch of made-up rows with ties in time.

    Returns (channels [B, T, n_channels, D], fields [B, T, FIELDS, D], extra [B, T, D], times [B, T],
    valid [B, T]). Real rows come first in every sequence, and steps of zero seconds put several rows
    in one second. Padded slots carry time 0, which would count as earlier than every real row if
    padding were not kept out, and the last sequence is padding only.
    """
    g = torch.Generator().manual_seed(seed)
    B, T = len(lengths), max(lengths)
    steps = torch.randint(0, 3, (B, T), generator=g)
    times = 1_000 + torch.cumsum(steps, dim=1)
    valid = torch.arange(T).unsqueeze(0) < torch.tensor(lengths).unsqueeze(1)
    times = times.masked_fill(~valid, 0)
    channels = torch.randn(B, T, n_channels, D, generator=g)
    fields = torch.randn(B, T, FIELDS, D, generator=g)
    extra = torch.randn(B, T, D, generator=g)
    return channels, fields, extra, times, valid


def _stage(seed=0, moved=True, **switches):
    """A small stage in evaluation mode.

    With `moved` every weight is shifted by a little noise, as after some training, so that the zero
    starts and the identity maps of a fresh stage hide nothing from the tests.
    """
    settings = dict(channel_dim=D, num_channels=M, num_heads=HEADS, num_pairs=PAIRS, num_fields=FIELDS,
                    history_len=HISTORY, dropout=0.1)
    settings.update(switches)
    torch.manual_seed(seed)
    stage = LatentChannelStage(**settings)
    if moved:
        with torch.no_grad():
            for weight in stage.parameters():
                weight.add_(torch.randn_like(weight) * 0.05)
    return stage.eval()


def _run(stage, channels, fields, extra, times, valid, bias=None):
    """Scoring-mode result of the stage."""
    with torch.no_grad():
        return stage(channels, fields, times, valid, row_extra=extra, bias=bias)


def _codes(valid, seed=0):
    """Match codes [B, T, N_CODES] for a batch: three values per field, so that rows match often, and -1 (no
    value) here and there. Padded slots hold codes too, which no real row may read."""
    g = torch.Generator().manual_seed(seed)
    return torch.randint(-1, 3, (*valid.shape, N_CODES), generator=g)


def _attention_bias(heads=HEADS, seed=0):
    """An AttentionBias over N_CODES match fields with every weight drawn at random, so that every part shows."""
    maker = AttentionBias(N_CODES, num_heads=heads)
    g = torch.Generator().manual_seed(seed)
    with torch.no_grad():
        for weight in maker.parameters():
            weight.copy_(torch.randn(weight.shape, generator=g))
    return maker


def _open_pairs(times, valid):
    """bool [B, 1, T, T]: the pairs the time rule opens, a real row reading itself or one of its eligible rows.

    Every other pair is closed: later rows, rows of the same second, padding, and a padded slot reading
    itself (the stage reads that one with a bias of zero)."""
    T = valid.shape[1]
    rule = eligible_rows(times, valid) | torch.eye(T, dtype=torch.bool)
    return (rule & valid.unsqueeze(-1)).unsqueeze(1)


# ---------------------------------------------------------------------------------------------- the time rule

def test_later_rows_and_rows_of_the_same_second_change_no_earlier_row_bit_for_bit():
    """Over the whole grid: every input (channels, fields, extra) of a later row and of every other row of
    the same second is replaced; the earlier rows and the row itself keep their result bit for bit."""
    channels, fields, extra, times, valid = _batch(seed=1)
    B = valid.shape[0]
    real = valid.sum(dim=1)
    every = torch.arange(B)
    # Two probes per sequence, its middle real row and its last real row; the rows to replace are every
    # real row whose second is not earlier than the probe's, except the probe itself.
    hidden_sets = []
    for share in (0.5, 1.0):
        probe = ((real - 1).clamp(min=0).float() * share).long()
        hidden = valid & (times >= times[every, probe].unsqueeze(1))
        hidden[every, probe] = False
        hidden_sets.append(hidden)
    g = torch.Generator().manual_seed(5)
    for switches in _grid():
        stage = _stage(**switches)
        before = _run(stage, channels, fields, extra, times, valid)
        kept_channels = stage.last_channels.clone()
        for hidden in hidden_sets:
            n = int(hidden.sum())
            c, f, e = channels.clone(), fields.clone(), extra.clone()
            c[hidden] = torch.randn(n, M, D, generator=g) * 3
            f[hidden] = torch.randn(n, FIELDS, D, generator=g) * 3
            e[hidden] = torch.randn(n, D, generator=g) * 3
            after = _run(stage, c, f, e, times, valid)
            kept = valid & ~hidden
            assert torch.equal(before[kept], after[kept]), switches
            assert torch.equal(kept_channels[kept], stage.last_channels[kept]), switches
            # The replacement reached the rows it was made on, so the check above could have seen a leak.
            assert not torch.equal(before[hidden], after[hidden]), switches


def test_whatever_a_padded_slot_holds_never_reaches_a_real_row():
    """Over the whole grid: values that are not numbers, infinite or huge in every input of padded slots,
    and any time there, leave every real row bit for bit as it was; every result stays finite."""
    channels, fields, extra, times, valid = _batch(seed=2)
    padded = ~valid
    n = int(padded.sum())
    g = torch.Generator().manual_seed(6)
    dirty = []
    for filler in (float("nan"), float("-inf"), 1e30):
        c, f, e, t = channels.clone(), fields.clone(), extra.clone(), times.clone()
        c[padded], f[padded], e[padded] = filler, filler, filler
        t[padded] = torch.randint(-10 ** 12, 10 ** 12, (n,), generator=g)
        dirty.append((c, f, e, t))
    for switches in _grid():
        stage = _stage(**switches)
        clean = _run(stage, channels, fields, extra, times, valid)
        for c, f, e, t in dirty:
            out = _run(stage, c, f, e, t, valid)
            assert torch.isfinite(out).all() and torch.isfinite(stage.last_channels).all(), switches
            assert torch.equal(out[valid], clean[valid]), switches


def test_the_first_rows_give_what_the_sequence_cut_after_them_gives_with_a_tie_at_the_cut():
    """Over the whole grid: the results of the first k rows equal those of the sequence cut after row k
    to rounding (1e-6), where row k and the row after it share one second, and they equal, bit for bit,
    those of the same sequence at its full length with the slots after row k marked as padding."""
    g = torch.Generator().manual_seed(7)
    B, T, k = 3, 12, 7
    steps = torch.randint(1, 3, (B, T), generator=g)
    steps[:, k] = 0                       # slot k, the first row after the cut, shares the second of slot k - 1
    steps[:, 3] = 0                       # and a tie further back
    times = 500 + torch.cumsum(steps, dim=1)
    valid = torch.arange(T).unsqueeze(0) < torch.tensor([12, 10, k + 1]).unsqueeze(1)
    channels = torch.randn(B, T, M, D, generator=g)
    fields = torch.randn(B, T, FIELDS, D, generator=g)
    extra = torch.randn(B, T, D, generator=g)
    assert torch.equal(times[:, k], times[:, k - 1]) and valid[:, k].all()
    worst = 0.0
    for switches in _grid():
        stage = _stage(**switches)
        whole = _run(stage, channels, fields, extra, times, valid)
        cut = _run(stage, channels[:, :k], fields[:, :k], extra[:, :k], times[:, :k], valid[:, :k])
        gap = float((whole[:, :k] - cut).abs().max())
        assert gap <= 1e-6, (switches, gap)
        worst = max(worst, gap)
        # The later slots marked as padding at the same length: the arithmetic runs over the same shapes, so the
        # first rows are equal to the bit.
        masked = _run(stage, channels, fields, extra, times, valid & (torch.arange(T) < k))
        assert torch.equal(masked[:, :k], whole[:, :k]), switches
    print(f"largest difference between the first rows and the cut sequence: {worst:.2e}")


def test_rows_in_another_slot_order_give_the_same_results():
    """The time rule follows the times, not the slots: the rows of every sequence put in another order give
    the same results in that order (to 1e-5), with and without a memory, since under "whole_seconds" the
    memory takes the rows of one second all or none and gives them one look-back index."""
    channels, fields, extra, times, valid = _batch(seed=14)
    B, T = valid.shape
    g = torch.Generator().manual_seed(15)
    order = torch.stack([torch.randperm(T, generator=g) for _ in range(B)])          # [B, T]
    rows = torch.arange(B).unsqueeze(1)
    shuffled = (channels[rows, order], fields[rows, order], extra[rows, order], times[rows, order],
                valid[rows, order])
    for switches in (dict(), dict(layout="staged", readout="attention"), dict(share_temporal=False, readout="mean"),
                     dict(layout="temporal_only", channel_projections=True), dict(final_intra=True, readout="mean"),
                     dict(layout="temporal_only", final_intra=True, share_temporal=False), dict(num_back=3),
                     dict(layout="staged", num_back=5, intra_order="self_first"), dict(num_back=2, time_bias=True)):
        stage = _stage(**switches)
        straight = _run(stage, channels, fields, extra, times, valid)
        moved = _run(stage, *shuffled)
        assert torch.allclose(moved[valid[rows, order]], straight[rows, order][valid[rows, order]], atol=1e-5), switches


def test_times_in_nanoseconds_with_their_unit_give_the_result_of_whole_seconds():
    """A stage told that its times are nanoseconds gives, on nanosecond times of today, the result of whole
    seconds, also when the unit is written as the float 1e9."""
    channels, fields, extra, times, valid = _batch(seed=16)
    g = torch.Generator().manual_seed(17)
    # Times of today in nanoseconds are near 1.7e18, where a division in 32-bit numbers would lose the second.
    nanoseconds = (1_700_000_000 + times) * 10 ** 9 + torch.randint(0, 10 ** 9, times.shape, generator=g)
    seconds = _run(_stage(num_back=3), channels, fields, extra, 1_700_000_000 + times, valid)
    for unit in (10 ** 9, 1e9):
        finer = _stage(num_back=3, units_per_second=unit)
        assert finer.units_per_second == 10 ** 9 and isinstance(finer.units_per_second, int)
        assert torch.equal(seconds, _run(finer, channels, fields, extra, nanoseconds, valid)), unit


# ---------------------------------------------------------------------------------------------- the attention bias

def test_a_bias_of_zero_gives_exactly_the_result_without_a_bias():
    """Over the settings where a bias goes, with one value per head and one for every head: a bias of zero gives
    the result of the call without a bias, bit for bit, and so does a fresh AttentionBias, which starts at zero."""
    channels, fields, extra, times, valid = _batch(seed=30)
    B, T = valid.shape
    with torch.no_grad():
        fresh = AttentionBias(N_CODES, num_heads=HEADS)(_codes(valid, seed=30), times, valid)
    assert fresh.shape == (B, HEADS, T, T) and not fresh.any()
    for switches in _bias_grid():
        stage = _stage(**switches)
        plain = _run(stage, channels, fields, extra, times, valid)
        kept = stage.last_channels.clone()
        for bias in (torch.zeros(B, HEADS, T, T), torch.zeros(B, 1, T, T), fresh):
            assert torch.equal(plain, _run(stage, channels, fields, extra, times, valid, bias=bias)), switches
            assert torch.equal(kept, stage.last_channels), switches


def test_a_bias_on_pairs_the_time_rule_closes_changes_nothing():
    """Over the settings where a bias goes: values that are not numbers, infinite or huge on every pair the rule
    closes (later rows, rows of the same second, padding, a padded slot reading itself) leave every result, padded
    slots included, bit for bit as it is with zero there; every result stays finite."""
    channels, fields, extra, times, valid = _batch(seed=31)
    B, T = valid.shape
    open_ = _open_pairs(times, valid)
    g = torch.Generator().manual_seed(32)
    # Every closed pair gets one of these at random, so one call sees all of them at once.
    fillers = torch.tensor([float("nan"), float("inf"), float("-inf"), 1e30, -1e30])
    for switches in _bias_grid():
        stage = _stage(**switches)
        for heads in (HEADS, 1):
            bias = torch.randn(B, heads, T, T, generator=g).masked_fill(~open_, 0.0)
            clean = _run(stage, channels, fields, extra, times, valid, bias=bias)
            dirty = torch.where(open_, bias, fillers[torch.randint(0, len(fillers), bias.shape, generator=g)])
            assert dirty.isnan().any() and dirty.isinf().any()
            out = _run(stage, channels, fields, extra, times, valid, bias=dirty)
            assert torch.isfinite(out).all() and torch.isfinite(stage.last_channels).all(), (switches, heads)
            assert torch.equal(out, clean), (switches, heads)


def test_a_bias_on_open_pairs_moves_the_rows_that_read_earlier_rows():
    """Over the settings where a bias goes: a bias on the pairs the rule opens moves every real row that has an
    eligible earlier row, and leaves a row with nothing earlier to read bit for bit as it is, since its only open
    pair is itself and a softmax over one place gives that place everything."""
    channels, fields, extra, times, valid = _batch(seed=33)
    B, T = valid.shape
    open_ = _open_pairs(times, valid)
    reads = valid & (eligible_rows(times, valid).sum(dim=-1) > 0)
    alone = valid & ~reads
    assert reads.sum() > 10 and alone.sum() > 3                  # both kinds of row are there to be looked at
    g = torch.Generator().manual_seed(34)
    for switches in _bias_grid():
        stage = _stage(**switches)
        plain = _run(stage, channels, fields, extra, times, valid)
        for heads in (HEADS, 1):
            bias = (2 * torch.randn(B, heads, T, T, generator=g)).masked_fill(~open_, 0.0)
            out = _run(stage, channels, fields, extra, times, valid, bias=bias)
            assert torch.equal(out[alone], plain[alone]), (switches, heads)
            moved = (out - plain).abs().amax(dim=-1) > 1e-5      # [B, T]: the rows whose result moved
            assert moved[reads].all(), (switches, heads)


def test_later_rows_change_no_earlier_row_with_an_attention_bias_in_place():
    """Over the settings where a bias goes, with an AttentionBias of random weights per head and one for every
    head, built from random match codes on times with ties and padding: every input of the later rows and of
    the other rows of a row's second (channels, fields, extra, match codes, and the times moved later still) is
    replaced and the bias is built again from them; the earlier rows and the row itself keep their result bit
    for bit. The first rows also give what the sequence cut after them gives, the bias built on the cut."""
    channels, fields, extra, times, valid = _batch(seed=35)
    codes = _codes(valid, seed=35)
    B, T = valid.shape
    real = valid.sum(dim=1)
    every = torch.arange(B)
    hidden_sets = []
    for share in (0.5, 1.0):
        probe = ((real - 1).clamp(min=0).float() * share).long()
        hidden = valid & (times >= times[every, probe].unsqueeze(1))
        hidden[every, probe] = False
        hidden_sets.append(hidden)
    makers = (_attention_bias(HEADS, seed=1), _attention_bias(1, seed=2))
    g = torch.Generator().manual_seed(36)
    k = 7
    for switches in _bias_grid():
        stage = _stage(**switches)
        for maker in makers:
            with torch.no_grad():
                bias = maker(codes, times, valid)
            before = _run(stage, channels, fields, extra, times, valid, bias=bias)
            for hidden in hidden_sets:
                n = int(hidden.sum())
                c, f, e, s, t = channels.clone(), fields.clone(), extra.clone(), codes.clone(), times.clone()
                c[hidden] = torch.randn(n, M, D, generator=g) * 3
                f[hidden] = torch.randn(n, FIELDS, D, generator=g) * 3
                e[hidden] = torch.randn(n, D, generator=g) * 3
                s[hidden] = torch.randint(-1, 3, (n, N_CODES), generator=g)
                # Moved later only: a row of the probe's second or after it stays where the probe cannot read it.
                t[hidden] = t[hidden] + torch.randint(0, 4, (n,), generator=g)
                with torch.no_grad():
                    rebuilt = maker(s, t, valid)
                after = _run(stage, c, f, e, t, valid, bias=rebuilt)
                kept = valid & ~hidden
                assert torch.equal(before[kept], after[kept]), switches
                assert not torch.equal(before[hidden], after[hidden]), switches
            # The cut after slot k: the real rows are in time order, so no row before the cut reads a row after it.
            with torch.no_grad():
                cut_bias = maker(codes[:, :k], times[:, :k], valid[:, :k])
            cut = _run(stage, channels[:, :k], fields[:, :k], extra[:, :k], times[:, :k], valid[:, :k], bias=cut_bias)
            assert torch.allclose(before[:, :k][valid[:, :k]], cut[valid[:, :k]], atol=1e-5), switches


def test_the_bias_reaches_head_h_of_every_channel_as_stage_two_adds_it():
    """One channel and no extras: with an AttentionBias per head, or one for every head, the stage equals the
    standard stack run the way HistoryStage runs it, the bias added to the float mask of masks.to_attention_mask
    (head h of sequence b in row b * heads + h), to 1e-5. With three channels, through shared layers or a layer
    per channel, every channel gives what it gives alone, so every channel reads the bias of the same head."""
    channels, _, _, times, valid = _batch(seed=38)
    codes = _codes(valid, seed=38)
    B, T = valid.shape
    simple = dict(layout="temporal_only", channel_identity=False, readout="mean", dropout=0.0)
    alone = _stage(num_channels=1, **simple)
    stack = encoder_stack(D, HEADS, PAIRS, dropout=0.0, attn_dropout=0.0).eval()
    with torch.no_grad():
        for block, layer in zip(alone.through_time, stack.layers):
            layer.self_attn.in_proj_weight.copy_(block.in_proj.weight)
            layer.self_attn.in_proj_bias.copy_(block.in_proj.bias)
            layer.self_attn.out_proj.weight.copy_(block.out_proj.weight)
            layer.self_attn.out_proj.bias.copy_(block.out_proj.bias)
            for name in ("linear1", "linear2", "norm1", "norm2"):
                getattr(layer, name).load_state_dict(getattr(block, name).state_dict())
    n_earlier = eligible_rows(times, valid).sum(dim=-1).clamp(max=HISTORY)
    shared = _stage(num_channels=M, **simple)
    shared.load_state_dict(alone.state_dict())                    # one channel or three: the same weights
    own = _stage(num_channels=M, share_temporal=False, **simple)
    for heads in (HEADS, 1):
        with torch.no_grad():
            bias = _attention_bias(heads, seed=4)(codes, times, valid)
            # The arithmetic of HistoryStage: the bias of every head added to the float mask of the time rule.
            mask = masks.to_attention_mask(masks.strict_visibility(times, valid), HEADS)
            mask = mask + bias.expand(B, HEADS, T, T).reshape(B * HEADS, T, T)
            x = channels[:, :, 0].masked_fill(~valid.unsqueeze(-1), 0.0) + alone.position(n_earlier)
            want = run_blocks(stack, x, mask)
        got = _run(alone, channels[:, :, :1], None, None, times, valid, bias=bias)
        assert torch.allclose(got[valid], want[valid], atol=1e-5), heads
        # Shared layers: channel c of three is channel c alone.
        _run(shared, channels, None, None, times, valid, bias=bias)
        together = shared.last_channels.clone()
        for c in range(M):
            _run(alone, channels[:, :, c:c + 1], None, None, times, valid, bias=bias)
            assert torch.allclose(together[:, :, c][valid], alone.last_channels[:, :, 0][valid], atol=1e-5), (heads, c)
        # A layer per channel: channel c of three is channel c alone with the weights of layer c.
        _run(own, channels, None, None, times, valid, bias=bias)
        together = own.last_channels.clone()
        for c in range(M):
            weights = {"position.weight": own.position.weight}
            for n, layers in enumerate(own.through_time):
                weights.update({f"through_time.{n}.{name}": tensor for name, tensor in layers[c].state_dict().items()})
            alone.load_state_dict(weights)
            _run(alone, channels[:, :, c:c + 1], None, None, times, valid, bias=bias)
            assert torch.allclose(together[:, :, c][valid], alone.last_channels[:, :, 0][valid], atol=1e-5), (heads, c)
        alone.load_state_dict(shared.state_dict())                # back to the weights the reference stack holds


def test_a_learned_bias_trains_through_the_stage_and_runs_in_mixed_precision():
    """In training mode an AttentionBias gets a finite gradient on every weight through the stage, and the bias
    itself on open pairs only; under torch.autocast on the CPU (bfloat16) the stage with a bias gives finite rows
    close to the full-precision ones."""
    channels, fields, extra, times, valid = _batch(seed=37)
    codes = _codes(valid, seed=37)
    open_ = _open_pairs(times, valid)
    for share in (True, False):
        for heads in (HEADS, 1):
            stage = _stage(share_temporal=share, num_back=2, final_intra=True, readout="attention").train()
            maker = _attention_bias(heads, seed=3)
            bias = maker(codes, times, valid)
            bias.retain_grad()
            stage(channels, fields, times, valid, row_extra=extra, bias=bias)[valid].pow(2).mean().backward()
            for name, weight in maker.named_parameters():
                assert weight.grad is not None and torch.isfinite(weight.grad).all(), (name, share, heads)
                assert weight.grad.abs().sum() > 0, (name, share, heads)
            closed = ~open_.expand_as(bias)
            assert torch.isfinite(bias.grad).all() and not bias.grad[closed].any(), (share, heads)
            assert all(w.grad is not None and torch.isfinite(w.grad).all() for w in stage.parameters())
            stage.eval()
            fixed = bias.detach()
            full = _run(stage, channels, fields, extra, times, valid, bias=fixed)
            with torch.no_grad(), torch.autocast("cpu", dtype=torch.bfloat16):
                mixed = stage(channels, fields, times, valid, row_extra=extra, bias=fixed)
            assert torch.isfinite(mixed).all(), (share, heads)
            assert torch.allclose(full[valid], mixed.float()[valid], atol=0.25), (share, heads)


# ---------------------------------------------------------------------------------------------- channels and memory

def test_channels_stay_apart_unless_self_attention_mixes_them():
    """Without self-attention among the channels the final state of channel 1 does not move, bit for bit,
    when the input of channel 0 changes (reading the fields does not mix them either); with it, it moves."""
    channels, fields, extra, times, valid = _batch(seed=3)
    other = channels.clone()
    other[:, :, 0] = torch.randn(other[:, :, 0].shape, generator=torch.Generator().manual_seed(8)) * 3
    apart = [dict(layout="temporal_only"),
             dict(layout="interleaved", intra_self_attention=False, intra_cross_attention=False),
             dict(layout="interleaved", intra_self_attention=False),
             dict(layout="staged", intra_self_attention=False, num_back=3),
             dict(layout="interleaved", intra_self_attention=False, final_intra=True),
             dict(layout="temporal_only", intra_self_attention=False, final_intra=True, num_back=3)]
    for switches in apart:
        for share in (True, False):
            for projections in (False, True):
                stage = _stage(share_temporal=share, channel_projections=projections, **switches)
                _run(stage, channels, fields, extra, times, valid)
                first = stage.last_channels.clone()
                _run(stage, other, fields, extra, times, valid)
                assert torch.equal(first[:, :, 1:], stage.last_channels[:, :, 1:]), (switches, share, projections)
                assert not torch.equal(first[:, :, 0][valid], stage.last_channels[:, :, 0][valid])
    # With self-attention the channels mix, also when the final block is the only within-transaction block.
    for switches in (dict(layout="interleaved"), dict(layout="staged"), dict(layout="temporal_only", final_intra=True)):
        stage = _stage(intra_self_attention=True, **switches)
        _run(stage, channels, fields, extra, times, valid)
        first = stage.last_channels.clone()
        _run(stage, other, fields, extra, times, valid)
        assert not torch.allclose(first[:, :, 1][valid], stage.last_channels[:, :, 1][valid], atol=1e-4), switches


def test_one_channel_without_extras_is_a_plain_stack_of_standard_layers():
    """One channel, no identity vector, no per-channel map, layout temporal_only and readout mean: the stage
    equals a stack of nn.TransformerEncoderLayer(norm_first=True, batch_first=True, gelu) at width d with the
    time mask and the position table, once the weights are copied across (below 1e-5), in scoring mode and
    in training mode."""
    channels, _, _, times, valid = _batch(seed=4, n_channels=1)
    B, T = valid.shape
    stage = _stage(num_channels=1, layout="temporal_only", channel_identity=False, channel_projections=False,
                   readout="mean", num_pairs=3, dropout=0.0)
    layers = []
    for block in stage.through_time:
        layer = nn.TransformerEncoderLayer(D, HEADS, dim_feedforward=4 * D, dropout=0.0, activation="gelu",
                                           batch_first=True, norm_first=True)
        with torch.no_grad():
            layer.self_attn.in_proj_weight.copy_(block.in_proj.weight)
            layer.self_attn.in_proj_bias.copy_(block.in_proj.bias)
            layer.self_attn.out_proj.weight.copy_(block.out_proj.weight)
            layer.self_attn.out_proj.bias.copy_(block.out_proj.bias)
            for name in ("linear1", "linear2", "norm1", "norm2"):
                getattr(layer, name).load_state_dict(getattr(block, name).state_dict())
        layers.append(layer)
    eligible = eligible_rows(times, valid)
    allowed = eligible | torch.eye(T, dtype=torch.bool)
    mask = torch.zeros(B, T, T).masked_fill(~allowed, float("-inf")).repeat_interleave(HEADS, dim=0)

    def plain(x):
        x = x[:, :, 0].masked_fill(~valid.unsqueeze(-1), 0.0) + stage.position(eligible.sum(-1).clamp(max=HISTORY))
        for layer in layers:
            x = layer(x, src_mask=mask)
        return x

    for layer in layers:
        layer.eval()
    with torch.no_grad():
        scoring = float((stage(channels, times=times, valid=valid) - plain(channels)).abs().max())
    stage.train()
    for layer in layers:
        layer.train()
    training = float((stage(channels, times=times, valid=valid) - plain(channels)).abs().max().detach())
    assert scoring < 1e-5 and training < 1e-5, (scoring, training)


def test_the_memory_reaches_exactly_the_latest_eligible_earlier_rows():
    """In the staged layout the fields enter through the last block only, so a row moves with the fields of
    itself and of its latest num_back eligible earlier rows and with no other row's; the same holds for the
    layout temporal_only with the final block, and for staged with the final block after its own. In the
    interleaved layout, with or without the final block, the fields of every earlier row reach a row (through
    time as well), and those of another row of its own second or of a later row never do."""
    times = torch.tensor([[10, 11, 11, 12, 15, 15, 16, 20, 20]])
    valid = torch.ones(1, 9, dtype=torch.bool)
    g = torch.Generator().manual_seed(9)
    channels, fields, extra = torch.randn(1, 9, M, D, generator=g), torch.randn(1, 9, FIELDS, D, generator=g), \
        torch.randn(1, 9, D, generator=g)
    for ties in ("whole_seconds", "slot"):
        index, exists = latest_prior_rows(times, valid, 2, ties=ties)
        # Stages whose fields enter after the last through-time block only, and stages that read them in between.
        at_the_end = [_stage(layout="staged", num_back=2, ties=ties),
                      _stage(layout="temporal_only", num_back=2, final_intra=True, ties=ties),
                      _stage(layout="staged", num_back=2, final_intra=True, ties=ties)]
        in_between = [_stage(layout="interleaved", num_back=2, ties=ties),
                      _stage(layout="interleaved", num_back=2, final_intra=True, ties=ties)]
        base_end = [_run(stage, channels, fields, extra, times, valid) for stage in at_the_end]
        base_between = [_run(stage, channels, fields, extra, times, valid) for stage in in_between]
        for other in range(9):
            altered = fields.clone()
            altered[0, other] = torch.randn(FIELDS, D, generator=g) * 3
            out_end = [_run(stage, channels, altered, extra, times, valid) for stage in at_the_end]
            out_between = [_run(stage, channels, altered, extra, times, valid) for stage in in_between]
            for row in range(9):
                reach = {row} | set(index[0, row][exists[0, row]].tolist())
                for number, (base, out) in enumerate(zip(base_end, out_end)):
                    moved = not torch.equal(base[0, row], out[0, row])
                    assert moved == (other in reach), ("fields at the end", ties, number, row, other)
                for number, (base, out) in enumerate(zip(base_between, out_between)):
                    moved = not torch.equal(base[0, row], out[0, row])
                    assert moved == (bool(times[0, other] < times[0, row]) or other == row), ("between", number, row,
                                                                                               other)
        if ties == "slot":
            # Row 4 lies in second 15: it reaches row 3 (second 12) and row 2, the later slot of second 11.
            assert index[0, 4][exists[0, 4]].tolist() == [3, 2]
        else:
            # Second 11 holds two rows and only one more fits: neither of them is held, whatever their slots.
            assert index[0, 4][exists[0, 4]].tolist() == [3]


# ---------------------------------------------------------------------------------------------- weights

def test_every_weight_learns_with_every_switch_on():
    """With every switch on (the stage's own time bias included), for every readout, both orders of the attention parts
    and with shared or per-channel through-time layers, every weight gets a finite gradient, and every one but the
    constant term of the bank's keys a gradient that is not zero. That term shifts every key of a row alike, which
    attention does not see, so its gradient is zero in exact arithmetic (the same holds in every attention, where the
    term sits inside a tensor with others). The final block is checked off and on, so its weights are among those that
    learn. The match-field weights of a time bias without match fields hold no number and are left out."""
    channels, fields, extra, times, valid = _batch(seed=10)
    for final in (False, True):
        for share in (True, False):
            for readout in lc.READOUTS:
                for order in lc.INTRA_ORDERS:
                    stage = _stage(moved=False, share_temporal=share, readout=readout, channel_projections=True,
                                   num_back=3, out_dim=11, final_intra=final, time_bias=True, intra_order=order).train()
                    c, f = channels.clone().requires_grad_(True), fields.clone().requires_grad_(True)
                    stage(c, f, times, valid, row_extra=extra)[valid].pow(2).mean().backward()
                    case = (share, readout, final, order)
                    for name, weight in stage.named_parameters():
                        if not weight.numel():
                            continue
                        assert weight.grad is not None and torch.isfinite(weight.grad).all(), (name, case)
                        if name != "bank.key.bias":
                            assert weight.grad.abs().sum() > 0, (name, case)
                    assert c.grad.abs().sum() > 0 and f.grad.abs().sum() > 0
                    assert final == any(name.startswith("final_within.") for name, _ in stage.named_parameters())
                    assert any(name.startswith("time_bias.gap_weight") for name, _ in stage.named_parameters())


def _by_hand(n_channels, d, pairs=4, history_len=120, ff=4, final=False):
    """The weights of a stage with every default switch on, counted part by part; `final` adds the final block."""
    def linear(n_in, n_out):
        return n_in * n_out + n_out                          # the matrix and the constant terms

    norm = 2 * d                                             # a layer norm: a scale and a shift per number
    feed_forward = norm + linear(d, ff * d) + linear(ff * d, d)
    self_attention = norm + linear(d, 3 * d) + linear(d, d)  # query, key and value side by side, then the way out
    cross_attention = norm + linear(d, d) + linear(d, d)     # the question and the way out; the bank is shared
    within = self_attention + cross_attention + feed_forward
    through_time = self_attention + feed_forward
    bank = norm + 2 * linear(d, d) + 2 * d                   # its norm, keys, values, one look-back vector each
    position = (history_len + 1) * d
    identity = n_channels * d
    readout = 2 * n_channels * d                             # the layer norm over the joined channels
    # The final block is one more within-transaction block; it reads the bank the other blocks read already.
    return position + identity + bank + pairs * (within + through_time) + readout + (within if final else 0)


def test_the_weight_count_matches_a_count_by_hand():
    """Four pairs and every default switch on, at (M=3, d=48), (M=6, d=96) and (M=12, d=96)."""
    counts = {}
    for n_channels, d in ((3, 48), (6, 96), (12, 96)):
        stage = LatentChannelStage(channel_dim=d, num_channels=n_channels, num_heads=8, num_pairs=4)
        counts[(n_channels, d)] = count_weights(stage)
        assert counts[(n_channels, d)] == _by_hand(n_channels, d), (n_channels, d)
    assert counts == {(3, 48): 256_512, (6, 96): 1_002_336, (12, 96): 1_004_064}
    print(f"weights with every default switch on: {counts}")


def test_the_final_block_and_the_bias_in_the_weight_count():
    """With final_intra the count grows by one within-transaction block, the count by hand says by how much, and
    in the layout temporal_only, where nothing read the fields before, by the bank as well. A bias adds no weight
    to the stage; the AttentionBias that makes it has 2 x heads x fields + heads x (gap buckets + 1) of its own."""
    counts = {}
    for n_channels, d in ((3, 48), (6, 96), (12, 96)):
        stage = LatentChannelStage(channel_dim=d, num_channels=n_channels, num_heads=8, num_pairs=4, final_intra=True)
        counts[(n_channels, d)] = count_weights(stage)
        assert counts[(n_channels, d)] == _by_hand(n_channels, d, final=True), (n_channels, d)
        one_block = count_weights(lc.WithinTransactionBlock(d, 8))
        assert counts[(n_channels, d)] - _by_hand(n_channels, d) == one_block == count_weights(stage.final_within)
    assert counts == {(3, 48): 289_584, (6, 96): 1_132_992, (12, 96): 1_134_720}
    # Every layout and both settings of the field read: one block more, and the bank where it is new.
    for layout in lc.LAYOUTS:
        for cross in (True, False):
            for read_self in (True, False):
                switches = dict(layout=layout, intra_cross_attention=cross, intra_self_attention=read_self, num_back=2)
                off, on = _stage(moved=False, **switches), _stage(moved=False, final_intra=True, **switches)
                block = lc.WithinTransactionBlock(D, HEADS, self_attention=read_self, cross_attention=cross)
                new_bank = count_weights(on.bank) if layout == "temporal_only" and cross else 0
                assert count_weights(on) - count_weights(off) == count_weights(block) + new_bank, switches
    # The bias is an input: a call with one leaves the count where it was.
    channels, fields, extra, times, valid = _batch(seed=21)
    B, T = valid.shape
    stage = _stage()
    before = count_weights(stage)
    _run(stage, channels, fields, extra, times, valid, bias=_attention_bias()(_codes(valid), times, valid))
    assert count_weights(stage) == before
    maker = AttentionBias(N_CODES, num_heads=HEADS)
    assert count_weights(maker) == 2 * HEADS * N_CODES + HEADS * (len(GAP_EDGES) + 1) + HEADS
    # The stage's own time bias has no match field: one weight per head and gap bucket, and one per head for a row
    # reading itself. The order of the attention parts adds none.
    assert count_weights(_stage(time_bias=True)) - before == HEADS * (len(GAP_EDGES) + 1) + HEADS
    assert count_weights(_stage(intra_order="self_first")) == before
    print(f"weights with every default switch on and the final block: {counts}")


def test_the_final_block_is_made_last_and_runs_last():
    """Built with the same seed, a stage with final_intra has every weight of the stage without it, equal to the
    bit; only the block (and in temporal_only the bank it reads) is new. In every layout the block runs after the
    last through-time block, and the readout reads what it hands back."""
    channels, fields, extra, times, valid = _batch(seed=22)
    for layout in lc.LAYOUTS:
        for cross in (True, False):
            off = _stage(moved=False, layout=layout, intra_cross_attention=cross, num_back=2)
            on = _stage(moved=False, layout=layout, intra_cross_attention=cross, num_back=2, final_intra=True)
            shared, own = off.state_dict(), on.state_dict()
            new = {name for name in own if name.startswith("final_within.")}
            if layout == "temporal_only" and cross:
                new |= {name for name in own if name.startswith("bank.")}
            assert set(own) - set(shared) == new and new and set(shared) <= set(own), (layout, cross)
            assert all(torch.equal(own[name], tensor) for name, tensor in shared.items()), (layout, cross)
            assert on.order == off.order + (("final", 0),)
            # The order of the calls, seen from inside: the final block comes last, right after the last through-time
            # block, or in the layout staged right after the within-transaction block that layout ends with.
            calls = []
            for name, module in on.named_modules():
                if isinstance(module, (lc.ThroughTimeBlock, lc.WithinTransactionBlock)):
                    module.register_forward_hook(lambda module, inputs, output, name=name: calls.append((name, output)))
            _run(on, channels, fields, extra, times, valid)
            before = "within.0" if layout == "staged" else f"through_time.{PAIRS - 1}"
            names = [name for name, _ in calls]
            assert names[-2:] == [before, "final_within"] and names.count("final_within") == 1, (layout, cross)
            assert torch.equal(on.last_channels, calls[-1][1].reshape(on.last_channels.shape))


def test_per_channel_maps_switched_on_change_nothing_at_first():
    """Built with the same seed, a stage with the per-channel maps has the same other weights as one
    without them and gives the same result, for every layout and readout."""
    channels, fields, extra, times, valid = _batch(seed=11)
    for layout in lc.LAYOUTS:
        for readout in lc.READOUTS:
            off = _stage(moved=False, layout=layout, readout=readout, channel_projections=False, num_back=2)
            on = _stage(moved=False, layout=layout, readout=readout, channel_projections=True, num_back=2)
            shared, own = off.state_dict(), on.state_dict()
            assert set(own) - set(shared) == {"projection_weight", "projection_bias"}
            assert all(torch.equal(own[name], tensor) for name, tensor in shared.items())
            assert torch.allclose(_run(off, channels, fields, extra, times, valid),
                                  _run(on, channels, fields, extra, times, valid), atol=1e-6), (layout, readout)


# ---------------------------------------------------------------------------------------------- shapes and precision

def test_shapes_for_every_readout_and_width():
    """The row representation has the width each readout and out_dim promise; the final channels are kept."""
    channels, fields, extra, times, valid = _batch(seed=12)
    B, T = valid.shape
    for readout in lc.READOUTS:
        for out_dim in (None, 7, M * D):
            stage = _stage(readout=readout, out_dim=out_dim)
            out = _run(stage, channels, fields, extra, times, valid)
            natural = M * D if readout == "concat" else D
            width = natural if out_dim is None else out_dim
            assert out.shape == (B, T, width) and stage.out_dim == width, (readout, out_dim)
            assert (stage.to_out is None) == (out_dim is None)
            assert stage.last_channels.shape == (B, T, M, D) and not stage.last_channels.requires_grad
    # Without a bank the stage needs no fields, and every slot counts as real without `valid`.
    stage = _stage(layout="temporal_only")
    assert stage(channels, times=times).shape == (B, T, M * D)


def test_mixed_precision_on_the_cpu_runs_and_stays_close():
    """Under torch.autocast on the CPU (bfloat16) the stage gives finite rows close to the full-precision
    ones, and training in mixed precision reaches every weight with a finite gradient."""
    channels, fields, extra, times, valid = _batch(seed=13)
    for readout in lc.READOUTS:
        for share in (True, False):
            stage = _stage(readout=readout, share_temporal=share, num_back=2, channel_projections=True)
            full = _run(stage, channels, fields, extra, times, valid)
            with torch.no_grad(), torch.autocast("cpu", dtype=torch.bfloat16):
                mixed = stage(channels, fields, times, valid, row_extra=extra)
            assert torch.isfinite(mixed).all(), (readout, share)
            assert torch.allclose(full[valid], mixed.float()[valid], atol=0.25), (readout, share)
            stage.train()
            with torch.autocast("cpu", dtype=torch.bfloat16):
                out = stage(channels, fields, times, valid, row_extra=extra)
            out.float()[valid].pow(2).mean().backward()
            assert all(w.grad is not None and torch.isfinite(w.grad).all() for w in stage.parameters())


def test_evaluation_mode_with_dropout_is_deterministic():
    """With dropout in the stage, evaluation mode gives one result every time; training mode does not."""
    channels, fields, extra, times, valid = _batch(seed=18)
    stage = _stage(dropout=0.3, num_back=2, readout="attention")
    assert torch.equal(_run(stage, channels, fields, extra, times, valid),
                       _run(stage, channels, fields, extra, times, valid))
    stage.train()
    with torch.no_grad():
        first, second = (stage(channels, fields, times, valid, row_extra=extra) for _ in range(2))
    assert not torch.equal(first, second)


# ---------------------------------------------------------------------------------------------- the other parts

def test_the_pooler_makes_the_channels_of_every_transaction_from_its_own_fields():
    """M learned queries read the fields of one transaction; another transaction's fields change nothing,
    and the channels it makes go into the stage as they are."""
    channels, fields, extra, times, valid = _batch(seed=19)
    torch.manual_seed(0)
    pooler = ChannelPooler(channel_dim=D, num_channels=M, num_heads=HEADS, dropout=0.0).eval()
    with torch.no_grad():
        made = pooler(fields)
        altered = fields.clone()
        altered[0, 2] = torch.randn(FIELDS, D) * 3
        moved = pooler(altered)
        single = pooler(fields[0, 1])
    assert made.shape == (*valid.shape, M, D) and single.shape == (M, D)
    assert torch.allclose(single, made[0, 1], atol=1e-6)
    changed = (made - moved).abs().amax(dim=(-1, -2)) > 0
    assert changed[0, 2] and int(changed.sum()) == 1
    rows = _run(_stage(), made, fields, extra, times, valid)
    assert torch.isfinite(rows).all()


def test_describe_lists_every_switch_and_the_weights():
    """One line per switch with its value and the number of weights; switches without effect say so."""
    stage = _stage(layout="temporal_only", num_back=3)
    text = describe(stage)
    for name, value in stage.settings.items():
        assert any(line.split()[:2] == [name, str(value)] for line in text.splitlines()), name
    assert f"{count_weights(stage):,}" in text
    # Both intra switches, the order of the two, num_back, the rule for ties and num_fields.
    assert text.count("unused") == 6
    assert "unused" not in describe(_stage(num_back=3))
    # Without a memory the rule for ties has no effect, and with one attention part neither has the order.
    def unused(stage):
        return [line.split()[0] for line in describe(stage).splitlines() if "unused" in line]

    assert unused(_stage()) == ["ties"]
    assert unused(_stage(intra_self_attention=False, num_back=3)) == ["intra_order"]
    assert "ChannelPooler" in describe(ChannelPooler(channel_dim=D, num_channels=M, num_heads=HEADS))


def test_describe_shows_the_final_block_and_the_bias_of_the_latest_call():
    """final_intra has its line with its value, and a note where it meets a block of the layout or stands in for
    one; with the final block the layout temporal_only reads the fields, so nothing there is unused. The bias line
    says what the latest call had and which layout forward takes."""
    lines = describe(_stage()).splitlines()
    assert any(line.split()[:2] == ["final_intra", "False"] for line in lines)
    text = describe(_stage(layout="temporal_only", final_intra=True, num_back=3))
    assert any(line.split()[:2] == ["final_intra", "True"] for line in text.splitlines())
    assert "unused" not in text and "layout staged" in text
    assert "second within-transaction block" in describe(_stage(layout="staged", final_intra=True))
    # In the layout interleaved the block simply comes on top, so its line carries no note.
    line = next(line for line in describe(_stage(final_intra=True)).splitlines() if line.split()[0] == "final_intra")
    assert line.split() == ["final_intra", "True"]
    channels, fields, extra, times, valid = _batch(seed=23)
    B, T = valid.shape
    stage = _stage(final_intra=True)
    assert "no call yet" in describe(stage)
    _run(stage, channels, fields, extra, times, valid, bias=torch.zeros(B, HEADS, T, T))
    bias_line = [line for line in describe(stage).splitlines() if line.split()[0] == "bias"]
    assert len(bias_line) == 1 and f"[B, {HEADS}, T, T] in the latest call" in bias_line[0]
    assert f"[B, {HEADS}, T, T] or [B, 1, T, T]" in bias_line[0]
    _run(stage, channels, fields, extra, times, valid, bias=torch.zeros(B, 1, T, T))
    assert "[B, 1, T, T] in the latest call" in describe(stage)
    _run(stage, channels, fields, extra, times, valid)
    assert "not given in the latest call" in describe(stage)


def test_plain_errors_say_what_to_change():
    """Shapes that cannot work stop with a plain error that names what to change."""
    channels, fields, extra, times, valid = _batch(seed=20)
    B, T = valid.shape
    stage = _stage()
    with pytest.raises(ValueError, match="num_channels=4"):
        stage(torch.randn(B, T, 4, D), fields, times, valid)
    with pytest.raises(ValueError, match="view"):
        stage(channels.reshape(B, T, M * D), fields, times, valid)
    with pytest.raises(ValueError, match="intra_cross_attention=False"):
        stage(channels, None, times, valid)
    with pytest.raises(ValueError, match="num_fields=6"):
        stage(channels, torch.randn(B, T, 6, D), times, valid)
    with pytest.raises(ValueError, match="linear layer"):
        stage(channels, torch.randn(B, T, FIELDS, D + 2), times, valid)
    with pytest.raises(ValueError, match="times"):
        stage(channels, fields, None, valid)
    with pytest.raises(ValueError, match="row_extra"):
        stage(channels, fields, times, valid, row_extra=torch.randn(B, T, D + 1))
    with pytest.raises(ValueError, match=f"num_heads={HEADS}"):
        stage(channels, fields, times, valid, bias=torch.zeros(B, HEADS + 1, T, T))
    with pytest.raises(ValueError, match="unsqueeze"):
        stage(channels, fields, times, valid, bias=torch.zeros(B, T, T))
    with pytest.raises(ValueError, match="bias must be float"):
        stage(channels, fields, times, valid, bias=torch.zeros(B, HEADS, T, T, dtype=torch.bool))
    with pytest.raises(ValueError, match="bias must be float"):
        stage(channels, fields, times, valid, bias=torch.zeros(B, HEADS, T - 1, T - 1))
    with pytest.raises(ValueError, match="layout"):
        LatentChannelStage(channel_dim=D, num_heads=HEADS, layout="sideways")
    with pytest.raises(ValueError, match="readout"):
        LatentChannelStage(channel_dim=D, num_heads=HEADS, readout="max")
    with pytest.raises(ValueError, match="multiple"):
        LatentChannelStage(channel_dim=18, num_heads=4)
    with pytest.raises(ValueError, match="time_bias"):
        _stage(time_bias=True)(channels, fields, times, valid, bias=torch.zeros(B, HEADS, T, T))
    with pytest.raises(ValueError, match="ties"):
        LatentChannelStage(channel_dim=D, num_heads=HEADS, ties="seconds")
    with pytest.raises(ValueError, match="intra_order"):
        LatentChannelStage(channel_dim=D, num_heads=HEADS, intra_order="both")
    with pytest.raises(ValueError, match="units_per_second"):
        LatentChannelStage(channel_dim=D, num_heads=HEADS, units_per_second=0)
    with pytest.raises(ValueError, match="int64"):
        stage(channels, fields, times.float(), valid)
    # The error for a joined vector says when .view is right.
    with pytest.raises(ValueError, match="channel-major order"):
        stage(channels.reshape(B, T, M * D), fields, times, valid)


def test_the_placeholders_are_the_defaults():
    """Sizes that are not given are read from the PLACEHOLDER values of the module."""
    stage = LatentChannelStage()
    assert (stage.channel_dim, stage.num_channels, stage.num_heads) == (lc.CHANNEL_DIM, lc.NUM_CHANNELS, lc.NUM_HEADS)
    assert len(stage.through_time) == len(stage.within) == lc.NUM_PAIRS
    assert stage.position.num_embeddings == lc.HISTORY_LEN + 1
    assert stage.units_per_second == lc.TIME_UNITS_PER_SECOND
    assert stage.out_dim == lc.NUM_CHANNELS * lc.CHANNEL_DIM
    pooler = ChannelPooler()
    assert pooler.queries.shape == (lc.NUM_CHANNELS, lc.CHANNEL_DIM)


# Run in a folder of its own with pandas, scipy and sklearn out of reach: the four modules import from one another as
# flat files, and their blocks run.
_FLAT_RUN = """
import sys
for name in ("pandas", "scipy", "sklearn"):
    sys.modules[name] = None
import runpy
import torch
import masks, interleaved_reread, attention_bias, latent_channels
assert "additions" not in sys.modules
stage = latent_channels.LatentChannelStage(channel_dim=8, num_channels=2, num_heads=2, num_pairs=1, num_back=2,
                                           num_fields=3, history_len=6, time_bias=True, units_per_second=1e9)
times = torch.tensor([[1, 2, 2, 3, 0], [4, 4, 5, 6, 7]]) * 10 ** 9 + 1_795_000_000 * 10 ** 9
valid = torch.tensor([[True, True, True, True, False], [True] * 5])
rows = stage(torch.randn(2, 5, 2, 8), torch.randn(2, 5, 3, 8), times, valid)
assert torch.isfinite(rows).all() and stage.units_per_second == 10 ** 9
bias = attention_bias.AttentionBias(0, num_heads=2, units_per_second=10 ** 9)(torch.zeros(2, 5, 0, dtype=torch.long),
                                                                              times, valid)
assert bias.shape == (2, 2, 5, 5)
try:
    attention_bias.AttentionBias(0)
    raise SystemExit("num_heads left out outside the package must stop with a plain error")
except ValueError as error:
    assert "num_heads" in str(error)
print(latent_channels.describe(stage).splitlines()[-2])
runpy.run_path("latent_channels.py", run_name="__main__")
"""


def test_the_module_runs_from_a_flat_folder(tmp_path):
    """Copied next to interleaved_reread.py, attention_bias.py and masks.py into a folder of their own, with pandas,
    scipy and sklearn out of reach and no PYTHONPATH, the four modules import, the stage runs with its time bias, the
    bias block runs and asks for its heads, and the demo runs."""
    here = Path(lc.__file__).parent
    for name in ("latent_channels.py", "interleaved_reread.py", "attention_bias.py", "masks.py"):
        shutil.copy(here / name, tmp_path / name)
    env = {key: value for key, value in os.environ.items() if key != "PYTHONPATH"}
    env.update(OMP_NUM_THREADS="1", MKL_NUM_THREADS="1")
    result = subprocess.run([sys.executable, "-c", _FLAT_RUN], cwd=tmp_path, env=env, capture_output=True,
                            text=True, timeout=600)
    assert result.returncode == 0, result.stderr
    assert "finite: True" in result.stdout and "weights" in result.stdout
    assert "2026-11-18" in result.stdout                    # the times of the stage read as dates with its unit


# ---------------------------------------------------------------------------------- rows of one earlier second

def _straddling(seed=0, B=4, T=16):
    """A batch whose seconds hold one to four rows each, so that the end of every memory size falls inside a second
    somewhere: real rows first, in time order, padding after them."""
    g = torch.Generator().manual_seed(seed)
    times = torch.zeros(B, T, dtype=torch.long)
    valid = torch.zeros(B, T, dtype=torch.bool)
    for b in range(B):
        n, slot, second = T - 2 * b, 0, 1_000
        while slot < n:
            size = min(int(torch.randint(1, 5, (1,), generator=g)), n - slot)
            times[b, slot:slot + size] = second
            slot, second = slot + size, second + int(torch.randint(1, 4, (1,), generator=g))
        valid[b, :n] = True
    channels = torch.randn(B, T, M, D, generator=g)
    fields = torch.randn(B, T, FIELDS, D, generator=g)
    extra = torch.randn(B, T, D, generator=g)
    return channels, fields, extra, times, valid


def _inside_seconds(times, valid, seed):
    """A new order of the slots [B, T] that moves rows only among the real rows of their own second."""
    g = torch.Generator().manual_seed(seed)
    B, T = times.shape
    order = torch.arange(T).repeat(B, 1)
    for b in range(B):
        for second in times[b][valid[b]].unique():
            slots = torch.nonzero((times[b] == second) & valid[b]).squeeze(1)
            order[b, slots] = slots[torch.randperm(len(slots), generator=g)]
    return order


def test_the_slot_order_inside_a_second_moves_no_result():
    """With memories of 1, 3, 5 and 10 rows, in every layout (temporal_only with the final block, which reads the
    fields), both orders of the attention parts and with the stage's own time bias: the rows of every second put in
    another slot order give every result to rounding under "whole_seconds", the default. Under "slot" the same new
    order moves results, because it decides which rows of a second that straddles the end of the memory are held."""
    moved_by_slot = 0.0
    for seed in (0, 1):
        channels, fields, extra, times, valid = _straddling(seed)
        B, T = valid.shape
        rows = torch.arange(B).unsqueeze(1)
        order = _inside_seconds(times, valid, seed + 20)
        assert not torch.equal(order, torch.arange(T).expand_as(order))
        shuffled = (channels[rows, order], fields[rows, order], extra[rows, order], times[rows, order],
                    valid[rows, order])
        for num_back in (1, 3, 5, 10):
            for layout, final in (("interleaved", False), ("staged", False), ("temporal_only", True),
                                  ("interleaved", True)):
                for more in (dict(), dict(intra_order="self_first", time_bias=True, readout="attention")):
                    for ties in ("whole_seconds", "slot"):
                        stage = _stage(layout=layout, final_intra=final, num_back=num_back, **_rule(ties), **more)
                        straight = _run(stage, channels, fields, extra, times, valid)[rows, order]
                        moved = _run(stage, *shuffled)
                        gap = float((moved[valid] - straight[valid]).abs().max())
                        if ties == "whole_seconds":
                            assert gap < 1e-5, (seed, num_back, layout, final, more, gap)
                        else:
                            moved_by_slot = max(moved_by_slot, gap)
    assert moved_by_slot > 1e-3


# --------------------------------------------------------------------------------- values that are not numbers

def test_a_value_that_is_not_a_number_in_a_later_real_row_reaches_no_earlier_row():
    """In every layout with a memory (interleaved, staged, temporal_only with the final block, and the final block on
    top of the first two), under both rules for ties: an infinite value or one that is not a number in the fields, the
    channels or the extra input of any one real row leaves every row that may not read that row bit for bit as it was,
    and finite; the row itself and every row that may read it come out as not a number."""
    times = torch.tensor([[10, 20, 20, 30, 40, 50, 0, 0], [5, 5, 6, 9, 9, 9, 11, 0]])
    valid = times > 0
    B, T = times.shape
    g = torch.Generator().manual_seed(41)
    channels, fields, extra = torch.randn(B, T, M, D, generator=g), torch.randn(B, T, FIELDS, D, generator=g), \
        torch.randn(B, T, D, generator=g)
    reads = eligible_rows(times, valid)                                   # [b, i, j]: row i may read row j
    for layout, final in (("interleaved", False), ("staged", False), ("temporal_only", True), ("interleaved", True),
                          ("staged", True)):
        for ties in ("whole_seconds", "slot"):
            stage = _stage(layout=layout, final_intra=final, num_back=3, **_rule(ties))
            clean = _run(stage, channels, fields, extra, times, valid)
            assert torch.isfinite(clean).all()
            for b, r in torch.nonzero(valid).tolist():
                tainted = reads[b, :, r].clone()
                tainted[r] = True
                keep = valid[b] & ~tainted
                for where, filler in (("fields", float("inf")), ("fields", float("nan")), ("channels", float("nan")),
                                      ("extra", float("-inf"))):
                    c, f, e = channels.clone(), fields.clone(), extra.clone()
                    {"fields": f, "channels": c, "extra": e}[where][b, r].view(-1)[3] = filler
                    out = _run(stage, c, f, e, times, valid)
                    assert torch.equal(out[b][keep], clean[b][keep]), (layout, final, ties, r, where)
                    assert torch.isfinite(out[b][keep]).all(), (layout, final, ties, r, where)
                    assert torch.isnan(out[b][tainted]).all(), (layout, final, ties, r, where)
                    # The other sequence of the batch does not move at all.
                    assert torch.equal(out[1 - b][valid[1 - b]], clean[1 - b][valid[1 - b]])



def test_a_huge_finite_input_in_a_later_row_gives_the_result_of_a_value_that_is_not_a_number():
    """3e20, 1e30, -1e30 and 3e38 in the channels, the fields or the extra input of a real row, in one number or in the
    whole row, in every layout: every row that may not read that row keeps its result bit for bit, and the result of
    the whole batch is the one a value that is not a number in the same place gives, so the row itself and every row
    that may read it come out as not a number. Before the bound the layer norms overflowed from about 3e20, and every
    row that may not read the row moved, the earlier ones included: with the number in the channels or the extra input
    in every layout, and in the fields in "interleaved". LARGEST_INPUT itself is read as it is."""
    times = torch.tensor([[10, 20, 20, 30, 40, 50, 0, 0], [5, 5, 6, 9, 9, 9, 11, 0]])
    valid = times > 0
    B, T = times.shape
    g = torch.Generator().manual_seed(43)
    channels, fields, extra = torch.randn(B, T, M, D, generator=g), torch.randn(B, T, FIELDS, D, generator=g), \
        torch.randn(B, T, D, generator=g)
    reads = eligible_rows(times, valid)                                   # [b, i, j]: row i may read row j
    huge = (3e20, 1e30, -1e30, 3e38)
    # One object for the value that is not a number, so that it finds its own run again (NaN equals nothing).
    nan = float("nan")
    for layout, final in (("interleaved", False), ("staged", False), ("temporal_only", False), ("temporal_only", True)):
        stage = _stage(layout=layout, final_intra=final, num_back=3)
        clean = _run(stage, channels, fields, extra, times, valid)
        # A row with another row of its own second, and later rows that may read it, in each sequence.
        for b, r in ((0, 2), (1, 3)):
            tainted = reads[b, :, r].clone()
            tainted[r] = True
            keep = valid[b] & ~tainted
            for where, whole in itertools.product(("channels", "fields", "extra"), (False, True)):
                runs = {}
                for value in (nan, lc.LARGEST_INPUT) + huge:
                    c, f, e = channels.clone(), fields.clone(), extra.clone()
                    row = {"channels": c, "fields": f, "extra": e}[where][b, r]
                    # All of the row, or its first number; where a large number sits decides when a norm overflows,
                    # so both are tried.
                    if whole:
                        row.fill_(value)
                    else:
                        row.view(-1)[0] = value
                    runs[value] = _run(stage, c, f, e, times, valid)
                for value in huge:
                    out = runs[value]
                    assert torch.equal(out[b][keep], clean[b][keep]), (layout, final, where, whole, value)
                    torch.testing.assert_close(out, runs[nan], rtol=0, atol=0, equal_nan=True)
                    if where == "fields" and stage.bank is None:
                        # Without a bank the stage does not read the fields at all, so nothing moves.
                        assert torch.equal(out, clean), (layout, final, whole, value)
                    else:
                        assert torch.isnan(out[b][tainted]).all(), (layout, final, where, whole, value)
                edge = runs[lc.LARGEST_INPUT]
                assert torch.isfinite(edge[valid]).all(), (layout, final, where, whole)
                assert torch.equal(edge[b][keep], clean[b][keep]), (layout, final, where, whole)


def test_a_batch_of_ordinary_size_gives_the_bits_of_the_stage_without_the_bound(monkeypatch):
    """Finite inputs of ordinary size, one number at LARGEST_INPUT itself among them, give bit for bit what the stage
    gives with the bound taken away (LARGEST_INPUT set to infinity, the rule before the bound), in every layout, with
    and without the memory, the final block and the stage's own time bias."""
    channels, fields, extra, times, valid = _batch(seed=7)
    g = torch.Generator().manual_seed(44)
    # Sizes over many orders: most numbers near one, some a thousand times larger, one at the bound itself.
    channels = channels * torch.exp(torch.randn(channels.shape, generator=g) * 2.0)
    fields = fields * torch.exp(torch.randn(fields.shape, generator=g) * 2.0)
    channels[0, 3, 1, 5] = lc.LARGEST_INPUT
    for layout in lc.LAYOUTS:
        for switches in ({}, {"num_back": 3}, {"final_intra": True}, {"time_bias": True, "num_back": 3}):
            stage = _stage(layout=layout, **switches)
            bounded = _run(stage, channels, fields, extra, times, valid)
            monkeypatch.setattr(lc, "LARGEST_INPUT", float("inf"))
            unbounded = _run(stage, channels, fields, extra, times, valid)
            monkeypatch.undo()
            assert torch.equal(bounded, unbounded), (layout, switches)
            assert torch.isfinite(bounded[valid]).all(), (layout, switches)


# ----------------------------------------------------------------------------------- the stage's own time bias

def test_the_stage_s_own_time_bias_starts_as_a_no_op_bit_for_bit():
    """Built with the same seed, a stage with time_bias=True holds every weight of the stage without it, equal to the
    bit, and gives its results bit for bit in scoring (to rounding in training, where a bias that learns takes the
    plain attention path); the bias has the heads and the unit of the stage, and it moves the rows that read earlier
    rows once its weights have moved."""
    channels, fields, extra, times, valid = _batch(seed=50)
    reads = valid & (eligible_rows(times, valid).sum(dim=-1) > 0)
    for layout in lc.LAYOUTS:
        for share in (True, False):
            for num_back in (0, 3):
                switches = dict(layout=layout, share_temporal=share, num_back=num_back, final_intra=True, dropout=0.0)
                off, on = _stage(moved=False, **switches), _stage(moved=False, time_bias=True, **switches)
                plain, own = off.state_dict(), on.state_dict()
                assert set(own) - set(plain) == {name for name in own if name.startswith("time_bias.")}
                assert all(torch.equal(own[name], tensor) for name, tensor in plain.items()), switches
                assert on.time_bias.gap_weight.shape[0] == on.num_heads == HEADS
                assert on.time_bias.units_per_second == on.units_per_second
                assert torch.equal(_run(off, channels, fields, extra, times, valid),
                                   _run(on, channels, fields, extra, times, valid)), switches
                off.train(), on.train()
                trained_off = off(channels, fields, times, valid, row_extra=extra)
                trained_on = on(channels, fields, times, valid, row_extra=extra)
                assert torch.allclose(trained_off, trained_on, atol=1e-5), switches
                on.eval()
                with torch.no_grad():
                    on.time_bias.gap_weight.normal_()
                    on.time_bias.self_weight.normal_()
                out = _run(on, channels, fields, extra, times, valid)
                moved = (out - _run(off.eval(), channels, fields, extra, times, valid)).abs().amax(dim=-1) > 1e-5
                assert moved[reads].all(), switches


def test_the_stage_s_own_time_bias_keeps_the_time_rule_and_follows_each_call():
    """With every weight moved, the stage's own time bias included: later rows and the other rows of a row's second,
    their times moved later still, change no earlier row bit for bit; padding reaches no real row; the first rows give
    what the window cut after them gives; and a stage that scored another batch first gives the result of a fresh copy,
    since the bias is built from the times of every call."""
    channels, fields, extra, times, valid = _batch(seed=51)
    B = valid.shape[0]
    real = valid.sum(dim=1)
    probe = ((real - 1).clamp(min=0).float() * 0.5).long()
    hidden = valid & (times >= times[torch.arange(B), probe].unsqueeze(1))
    hidden[torch.arange(B), probe] = False
    other = _batch(seed=52)
    g = torch.Generator().manual_seed(53)
    settings = (dict(), dict(layout="staged", num_back=3), dict(share_temporal=False, num_back=3, final_intra=True),
                dict(layout="temporal_only", readout="mean"), dict(intra_order="self_first", num_back=3))
    for switches in settings:
        stage = _stage(time_bias=True, **switches)
        before = _run(stage, channels, fields, extra, times, valid)
        n = int(hidden.sum())
        c, f, e, t = channels.clone(), fields.clone(), extra.clone(), times.clone()
        c[hidden], f[hidden], e[hidden] = (torch.randn(n, M, D, generator=g), torch.randn(n, FIELDS, D, generator=g),
                                           torch.randn(n, D, generator=g))
        t[hidden] = t[hidden] + torch.randint(0, 4, (n,), generator=g)
        after = _run(stage, c, f, e, t, valid)
        kept = valid & ~hidden
        assert torch.equal(before[kept], after[kept]) and not torch.equal(before[hidden], after[hidden]), switches
        dirty_c, dirty_t = channels.clone(), times.clone()
        dirty_c[~valid] = float("nan")
        dirty_t[~valid] = torch.randint(-10 ** 12, 10 ** 12, (int((~valid).sum()),), generator=g)
        assert torch.equal(_run(stage, dirty_c, fields, extra, dirty_t, valid)[valid], before[valid]), switches
        k = 7
        cut = _run(stage, channels[:, :k], fields[:, :k], extra[:, :k], times[:, :k], valid[:, :k])
        assert torch.allclose(before[:, :k][valid[:, :k]], cut[valid[:, :k]], atol=1e-5), switches
        fresh = _stage(time_bias=True, **switches)
        fresh.load_state_dict(stage.state_dict())
        _run(stage, *other)
        assert torch.equal(_run(stage, channels, fields, extra, times, valid), _run(fresh, channels, fields, extra,
                                                                                    times, valid)), switches


# ---------------------------------------------------------------------------------------------- the order inside a row

def test_the_two_orders_of_a_within_transaction_block_hold_the_same_weights_and_give_other_results():
    """Built with the same seed, a stage with intra_order "cross_first" (the default) and one with "self_first" hold the
    same weights, to the bit and in number, and give other results on the same rows; inside a block the bank is read
    before the channels read one another in the first order, and after it in the second."""
    channels, fields, extra, times, valid = _batch(seed=54)
    for layout, final in (("interleaved", False), ("staged", False), ("temporal_only", True)):
        first, second = (_stage(layout=layout, final_intra=final, num_back=2, intra_order=order)
                         for order in lc.INTRA_ORDERS)
        assert first.settings["intra_order"] == "cross_first" == LatentChannelStage().intra_order
        one, two = first.state_dict(), second.state_dict()
        assert one.keys() == two.keys() and all(torch.equal(one[name], two[name]) for name in one), layout
        assert count_weights(first) == count_weights(second)
        out_first = _run(first, channels, fields, extra, times, valid)
        out_second = _run(second, channels, fields, extra, times, valid)
        assert not torch.allclose(out_first[valid], out_second[valid], atol=1e-3), layout
    for order, expected in (("cross_first", ["norm_cross", "norm_self"]), ("self_first", ["norm_self", "norm_cross"])):
        block = lc.WithinTransactionBlock(D, HEADS, intra_order=order).eval()
        calls = []
        for name in ("norm_cross", "norm_self"):
            getattr(block, name).register_forward_hook(lambda module, inputs, output, name=name: calls.append(name))
        keys = values = torch.randn(6, HEADS, 4, D // HEADS)
        with torch.no_grad():
            block(torch.randn(6, M, D), keys, values)
        assert calls == expected, order


# ---------------------------------------------------------------------------------------------- the times as dates

def test_describe_reads_the_times_of_the_latest_call_as_dates():
    """The times line reads the first and the last real row as dates in UTC with the stage's unit: nanoseconds of
    November 2026 with the unit 10**9 give that month, the same times read as seconds give a year in the billions,
    and seconds read as nanoseconds give the year 1970."""
    channels, fields, extra, _, valid = _batch(seed=55)
    B, T = valid.shape
    seconds = (1_795_000_000 + torch.arange(T).expand(B, T)).masked_fill(~valid, 0)
    ns = seconds * 10 ** 9 + 123

    def line(stage):
        return next(text for text in describe(stage).splitlines() if text.split()[:1] == ["times"])

    right = _stage(units_per_second=10 ** 9)
    assert "no call yet" in line(right)
    _run(right, channels, fields, extra, ns, valid)
    assert "2026-11-18 11:06:40 UTC to 2026-11-18 11:06:53 UTC" in line(right)
    as_seconds = _stage(units_per_second=1)
    _run(as_seconds, channels, fields, extra, ns, valid)
    assert "year 56,8" in line(as_seconds)
    as_nanoseconds = _stage(units_per_second=10 ** 9)
    _run(as_nanoseconds, channels, fields, extra, seconds, valid)
    assert "1970-01-01 00:00:01 UTC" in line(as_nanoseconds)
    _run(as_nanoseconds, channels, fields, extra, seconds, torch.zeros_like(valid))
    assert "no real row" in line(as_nanoseconds)
