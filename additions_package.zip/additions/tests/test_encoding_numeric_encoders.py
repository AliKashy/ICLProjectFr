"""Tests of the numeric encoders (additions/encoding/numeric_encoders.py).

"ple" must give the formula of the model in use, W_c PLE(x) + b_c, to 1e-6 against a slow reference
and against the block of numeric_frontend.py. The learned centres must stay strictly ordered under a
loss that pushes them together, read between neighbours as a slow reference does, and hold values
outside at the end vectors. Every kind must keep its fields apart, put the missing vector where a
value is missing without ever giving a value that is not a number, give finite gradients at 0, at 1
and far outside, run under bfloat16 autocast on the CPU, take any number of leading dimensions and
learn a sharp threshold and a periodic pattern. The scaler must place heavy-tailed fields on [0, 1],
the weight counts must be those of the module docstring, and the module must import from a flat
folder.

The checks of the build that followed are tested too: frozen centres and the branch width of the
control arm, the centres' own optimiser group, values that are not finite and values outside
[0, 1], a module cast to 16 bits, starting places for fields with heaps and the intervals that rows
use, the trained weights of the model in use in the layout of rtdl, a fixed zero for a missing
number, the warning for numbers that skipped the scaler, and the memory figures of the docstring.

So are the fixes of the check after it: the default missing="zero" and the switch `unscaled`, the
trained model's own edges on [0, 1] read as the model read them, the edges, centres and frequencies
kept in 32 bits under a cast to 16 bits, and a checkpoint with a trained missing vector stopped at
the load of an encoder with missing="zero".
"""
import copy
import io
import math
import os
import shutil
import subprocess
import sys
import warnings
from pathlib import Path

import numpy as np
import pytest
import torch
import torch.nn as nn
import torch.nn.functional as F

from additions.encoding import numeric_encoders as ne
from additions.encoding.numeric_frontend import PiecewiseLinearEmbedding, QuantileScaler, quantile_edges

# Every kind, with the switches that change the arithmetic: open outer bins for "ple", a shared matrix and a
# random start of the frequencies for "periodic".
SETTINGS = [("ple", {}), ("ple", {"open_ends": True}), ("learned_ple", {}), ("periodic", {}),
            ("periodic", {"lite": True}), ("periodic", {"frequency_init": "normal"}), ("hybrid", {})]


@pytest.fixture(autouse=True)
def _one_thread():
    """Every test of this file runs on one thread, and the thread count is restored afterwards.

    The encoders here are tiny. One thread does a training step of the learning test in a few
    milliseconds; four threads competing with other jobs for four cores took about half a second per
    step, a hundred times as long (the reason conftest.py gives for its default of one thread).
    """
    before = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(before)


def _encoder(kind, switches, n_fields=5, width=12, seed=0):
    """A small encoder whose every weight is moved a little, as after some training.

    The missing vector is the learned one of the arm missing="learned" unless `switches` say otherwise:
    it starts at zero and the identity small; moved, they show up in every comparison.
    """
    torch.manual_seed(seed)
    encoder = ne.NumericEncoder(n_fields, width, kind=kind, **{"missing": "learned", **switches})
    with torch.no_grad():
        for name, weight in encoder.named_parameters():
            # The centres are left where they start, so that they stay inside [0, 1] and every interval is used.
            if "first" not in name and "raw_gaps" not in name:
                weight.add_(torch.randn_like(weight) * 0.1)
    return encoder


def _slow_ple(x, edges, weight, bias, open_ends):
    """W_c PLE(x) + b_c for every row and field, with plain Python loops straight from the definition.

    A bin of no width gives 0. Held ends: every share is held between 0 and 1. Open ends: the first
    bin with a width is held only at 1, the last only at 0, and a field with a single such bin not at
    all (the form of Gorishniy et al., 2022).
    """
    n_rows, n_fields = x.shape
    n_bins = edges.shape[1] - 1
    out = np.zeros((n_rows, n_fields, weight.shape[-1]))
    for c in range(n_fields):
        real = [b for b in range(n_bins) if edges[c, b + 1] > edges[c, b]]
        for n in range(n_rows):
            value = float(x[n, c])
            total = bias[c].astype(np.float64).copy()
            for b in real:
                share = (value - float(edges[c, b])) / (float(edges[c, b + 1]) - float(edges[c, b]))
                if not open_ends or b not in (real[0], real[-1]):
                    share = min(max(share, 0.0), 1.0)
                elif b == real[0] and b != real[-1]:
                    share = min(share, 1.0)
                elif b == real[-1] and b != real[0]:
                    share = max(share, 0.0)
                total += share * weight[c, b].astype(np.float64)
            out[n, c] = total
    return out


def _slow_interpolation(x, centres, vectors):
    """(1 - t) v_k + t v_k+1 between neighbouring centres, the end vectors outside, row by row."""
    n_rows, n_fields = x.shape
    out = np.zeros((n_rows, n_fields, vectors.shape[-1]))
    for c in range(n_fields):
        a = centres[c]
        for n in range(n_rows):
            value = float(x[n, c])
            if value <= a[0]:
                out[n, c] = vectors[c, 0]
            elif value >= a[-1]:
                out[n, c] = vectors[c, -1]
            else:
                k = max(i for i in range(len(a) - 1) if a[i] <= value)
                t = (value - a[k]) / (a[k + 1] - a[k])
                out[n, c] = (1.0 - t) * vectors[c, k] + t * vectors[c, k + 1]
    return out


# ---------------------------------------------------------------------------------------------- the model in use

def test_ple_equals_the_formula_of_the_model_in_use_to_one_in_a_million():
    """With the same edges and weights, "ple" gives W_c PLE(x) + b_c of a slow reference, held or open ends."""
    rng = np.random.default_rng(0)
    edges = np.array([np.sort(rng.uniform(-2.0, 3.0, 7)),             # seven distinct edges
                      [0.0, 1.0, 1.0, 2.0, 3.0, 3.0, 3.0],             # bins of no width in the middle and at the end
                      [0.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0],             # a single bin with a width
                      [5.0] * 7,                                       # no bin with a width at all
                      np.linspace(0.0, 1.0, 7)])
    weight = rng.normal(0.0, 0.1, (5, 6, 9)).astype(np.float32)
    bias = rng.normal(0.0, 0.1, (5, 9)).astype(np.float32)
    # Values inside, exactly on edges, and beyond both ends of every field.
    x = np.concatenate([rng.uniform(-4.0, 6.0, (60, 5)), edges.T[:, :5], np.full((1, 5), -9.0), np.full((1, 5), 9.0)])
    x = torch.tensor(x, dtype=torch.float32)
    for open_ends in (False, True):
        encoder = ne.NumericEncoder(5, 9, kind="ple", edges=edges, open_ends=open_ends)
        with torch.no_grad():
            encoder.value.weight.copy_(torch.tensor(weight))
            encoder.identity.copy_(torch.tensor(bias))
            fast = encoder(x).double().numpy()
        slow = _slow_ple(x.numpy(), edges, weight, bias, open_ends)
        # To 1e-6, and to 1e-6 of the token's size where it is larger than one: open ends carry a value far past a
        # narrow bin to tokens of ten and more, where the last bit of a 32-bit number is already worth 1e-6.
        assert (np.abs(fast - slow) <= 1e-6 * np.maximum(1.0, np.abs(slow))).all(), open_ends
    # Held ends are the block of numeric_frontend.py with the same weight and constant: one formula, one code path.
    block = PiecewiseLinearEmbedding(edges, embed_dim=9)
    encoder = ne.NumericEncoder(5, 9, kind="ple", edges=edges, open_ends=False)
    with torch.no_grad():
        for target in (block.weight, encoder.value.weight):
            target.copy_(torch.tensor(weight))
        block.bias.copy_(torch.tensor(bias))
        encoder.identity.copy_(torch.tensor(bias))
        assert torch.allclose(encoder(x), block(x), atol=1e-6, rtol=0)
    # The default is the hold at the ends, which is what numeric_frontend.py does.
    assert ne.NumericEncoder(5, 9, kind="ple", edges=edges).value.open_ends is ne.PLE_OPEN_ENDS


@pytest.mark.filterwarnings("ignore:NumericEncoder:UserWarning")
def test_open_ends_change_only_values_beyond_the_outer_edges():
    """With edges on a scale of their own: inside the outer edges both forms agree, beyond them only the open form
    keeps moving. On the unit scale every value is held to [0, 1] first, so there both forms agree everywhere."""
    edges = np.linspace(-2.0, 3.0, 17)[None, :]
    encoder = _encoder("ple", {"open_ends": True, "edges": edges}, n_fields=1)
    held = _encoder("ple", {"open_ends": False, "edges": edges}, n_fields=1)
    inside = torch.linspace(-2.0, 3.0, 41).unsqueeze(-1)
    with torch.no_grad():
        assert torch.allclose(encoder(inside), held(inside), atol=1e-7, rtol=0)
        far, farther = torch.tensor([[4.0]]), torch.tensor([[5.0]])
        assert torch.equal(held(far), held(farther))
        assert not torch.allclose(encoder(far), encoder(farther))
    unit_open, unit_held = _encoder("ple", {"open_ends": True}, n_fields=1), _encoder("ple", {}, n_fields=1)
    with torch.no_grad():
        beyond = torch.tensor([[-1.0], [2.0], [3.0]])
        assert torch.equal(unit_open(beyond), unit_held(beyond))
    assert unit_open.unit_scale and unit_held.unit_scale and not encoder.unit_scale and not held.unit_scale


# ---------------------------------------------------------------------------------------------- learned centres

@pytest.mark.filterwarnings("ignore:NumericEncoder:UserWarning")
def test_centres_stay_strictly_ordered_under_a_loss_that_pushes_them_together():
    """300 Adam steps at a learning rate of 0.1 pull every centre to the middle and the last below the first;
    the centres stay strictly increasing and the tokens stay finite."""
    for kind in ("learned_ple", "hybrid"):
        torch.manual_seed(0)
        encoder = ne.NumericEncoder(4, 8, kind=kind)
        bins = encoder.learned_bins()
        optimiser = torch.optim.Adam(encoder.parameters(), lr=0.1)
        for _ in range(300):
            a = bins.centres()
            # Every centre is drawn to the mean of its field, and the last one is drawn below the first: a loss that
            # would swap the ends if the order were not built in.
            loss = ((a - a.mean(dim=1, keepdim=True)) ** 2).sum() + (a[:, -1] - a[:, 0]).sum()
            optimiser.zero_grad()
            loss.backward()
            optimiser.step()
        a = bins.centres().detach()
        assert (torch.diff(a, dim=1) > 0).all(), kind
        # The loss did move them: the whole span of every field is now far below its start of 1.
        assert float((a[:, -1] - a[:, 0]).max()) < 0.05, kind
        x = torch.linspace(-0.5, 1.5, 201).unsqueeze(-1).expand(201, 4)
        tokens = encoder(x)
        assert bool(torch.isfinite(tokens).all()), kind
        tokens.square().sum().backward()
        assert all(bool(torch.isfinite(w.grad).all()) for w in encoder.parameters() if w.grad is not None), kind


def test_the_learned_branch_reads_between_neighbouring_centres_as_a_slow_reference_does():
    """Uneven centres, random vectors: every value reads (1 - t) v_k + t v_k+1, and the end vectors outside."""
    rng = np.random.default_rng(1)
    centres = np.array([[0.0, 0.05, 0.4, 0.45, 0.9, 1.0], [-3.0, -1.0, 0.0, 0.5, 4.0, 10.0]])
    branch = ne.LearnedBinBranch(2, 5, centres=centres)
    with torch.no_grad():
        branch.vectors.copy_(torch.tensor(rng.normal(0.0, 1.0, (2, 6, 5)), dtype=torch.float32))
    # The start reproduces the given centres.
    assert np.abs(branch.centres().detach().numpy() - centres).max() < 1e-6
    x = np.concatenate([rng.uniform(-5.0, 12.0, (80, 2)), centres.T, [[-50.0, -50.0], [50.0, 50.0]]])
    x = torch.tensor(x, dtype=torch.float32)
    with torch.no_grad():
        fast = branch(x).double().numpy()
    slow = _slow_interpolation(x.numpy(), branch.centres().detach().double().numpy(),
                               branch.vectors.detach().double().numpy())
    assert np.abs(fast - slow).max() < 1e-5


@pytest.mark.filterwarnings("ignore:NumericEncoder:UserWarning")
def test_values_outside_the_outer_centres_are_held_at_the_end_vectors():
    """Below the first centre a field reads its first vector, above the last its last vector, exactly."""
    torch.manual_seed(2)
    branch = ne.LearnedBinBranch(3, 4)
    with torch.no_grad():
        branch.vectors.normal_()
        low = branch(torch.full((5, 3), -7.0))
        # Clearly above the last centre: 1.0 itself may lie a rounding step below it.
        high = branch(torch.tensor([[1.5, 2.0, 1e6]]).expand(5, 3))
    assert torch.equal(low, branch.vectors[:, 0].detach().expand(5, 3, 4))
    assert torch.equal(high, branch.vectors[:, -1].detach().expand(5, 3, 4))
    # The same hold reaches the tokens: past the outer centre the token no longer moves.
    for kind in ("learned_ple", "ple"):
        encoder = _encoder(kind, {}, n_fields=3)
        with torch.no_grad():
            assert torch.equal(encoder(torch.full((1, 3), 1.5)), encoder(torch.full((1, 3), 40.0))), kind
            assert torch.equal(encoder(torch.full((1, 3), -0.5)), encoder(torch.full((1, 3), -40.0))), kind


def test_tied_starting_centres_are_moved_apart_with_one_note(capsys):
    """Quantile centres of a field with a heap of equal values tie; they start apart, in order, and one line says so."""
    values = np.column_stack([np.r_[np.zeros(700), np.linspace(1.0, 2.0, 300)], np.linspace(0.0, 1.0, 1000)])
    centres = quantile_edges(values, ne.N_CENTRES - 1)
    branch = ne.LearnedBinBranch(2, 3, centres=centres)
    assert "field(s) [0]" in capsys.readouterr().out
    a = branch.centres().detach()
    assert (torch.diff(a, dim=1) > 0).all()
    # A field without ties keeps its quantile centres.
    assert np.abs(a[1].numpy() - centres[1]).max() < 1e-6


# ---------------------------------------------------------------------------------------------- every kind

def test_changing_one_field_changes_only_its_own_token():
    """Every kind: a new value in field 0 changes token 0 and leaves the tokens of the other fields bit for bit."""
    g = torch.Generator().manual_seed(3)
    x = torch.rand(9, 5, generator=g)
    other = x.clone()
    other[:, 0] = torch.rand(9, generator=g)
    for kind, switches in SETTINGS:
        encoder = _encoder(kind, switches)
        with torch.no_grad():
            before, after = encoder(x), encoder(other)
        assert torch.equal(before[:, 1:], after[:, 1:]), (kind, switches)
        assert not torch.allclose(before[:, 0], after[:, 0]), (kind, switches)


def test_missing_values_read_the_missing_vector_and_never_give_a_value_that_is_not_a_number():
    """Every kind: masked slots read missing + identity whatever they hold (NaN, infinity, huge numbers); the
    other slots keep their tokens; a NaN without a mask counts as missing; every gradient stays finite."""
    g = torch.Generator().manual_seed(4)
    x = torch.rand(8, 5, generator=g)
    mask = torch.rand(8, 5, generator=g) < 0.4
    mask[0, :] = True                                    # one row with every value missing
    mask[1, :] = False                                   # one row with none missing
    dirty = x.clone()
    fillers = torch.tensor([float("nan"), float("inf"), -float("inf"), 1e30, -1e30])
    dirty[mask] = fillers[torch.arange(int(mask.sum())) % len(fillers)]
    for kind, switches in SETTINGS:
        encoder = _encoder(kind, switches)
        tokens = encoder(dirty, missing=mask)
        assert bool(torch.isfinite(tokens).all()), (kind, switches)
        expected = (encoder.missing + encoder.identity).detach()
        rows, fields = torch.nonzero(mask, as_tuple=True)
        assert torch.allclose(tokens[rows, fields].detach(), expected[fields], atol=1e-7, rtol=0), (kind, switches)
        with torch.no_grad():
            clean = encoder(x)
        assert torch.equal(tokens.detach()[~mask], clean[~mask]), (kind, switches)
        tokens.square().sum().backward()
        for name, weight in encoder.named_parameters():
            assert weight.grad is not None and bool(torch.isfinite(weight.grad).all()), (kind, switches, name)
        # A value that is not a number counts as missing without a mask too.
        nan_only = x.clone()
        nan_only[mask] = float("nan")
        with torch.no_grad():
            assert torch.equal(encoder(nan_only), encoder(nan_only, missing=mask)), (kind, switches)


@pytest.mark.filterwarnings("ignore:NumericEncoder:UserWarning")
def test_gradients_are_finite_at_zero_at_one_and_far_outside():
    """Every kind: inputs at 0, at 1, far below and far above give finite tokens and finite gradients."""
    x = torch.tensor([[0.0, 1.0, -1e3, 1e3, -50.0], [1.0, 0.0, 50.0, -1e3, 1e3]])
    for kind, switches in SETTINGS:
        encoder = _encoder(kind, switches)
        tokens = encoder(x)
        assert bool(torch.isfinite(tokens).all()), (kind, switches)
        tokens.square().sum().backward()
        for name, weight in encoder.named_parameters():
            if weight.grad is not None:
                assert bool(torch.isfinite(weight.grad).all()), (kind, switches, name)


def test_every_kind_runs_under_bfloat16_autocast_on_the_cpu():
    """Under torch.autocast on the CPU with bfloat16, every kind gives finite tokens and finite gradients."""
    g = torch.Generator().manual_seed(5)
    x = torch.rand(6, 7, 5, generator=g)
    mask = torch.rand(6, 7, 5, generator=g) < 0.2
    x[mask] = float("nan")
    for kind, switches in SETTINGS:
        encoder = _encoder(kind, switches)
        with torch.autocast("cpu", dtype=torch.bfloat16):
            tokens = encoder(x, missing=mask)
        assert tokens.shape == (6, 7, 5, 12), (kind, switches)
        assert bool(torch.isfinite(tokens.float()).all()), (kind, switches)
        tokens.float().sum().backward()
        assert all(bool(torch.isfinite(w.grad).all()) for w in encoder.parameters() if w.grad is not None)


def test_every_kind_takes_any_number_of_leading_dimensions():
    """[C], [N, C], [B, T, C] and [2, 3, 4, C] give [..., C, d], and a row's tokens do not depend on the layout."""
    g = torch.Generator().manual_seed(6)
    x = torch.rand(2, 3, 4, 5, generator=g)
    for kind, switches in SETTINGS:
        encoder = _encoder(kind, switches)
        with torch.no_grad():
            whole = encoder(x)
            assert whole.shape == (2, 3, 4, 5, 12)
            assert encoder(x[0, 0, 0]).shape == (5, 12)
            assert encoder(x[0, 0]).shape == (4, 5, 12)
            assert encoder(x[0]).shape == (3, 4, 5, 12)
            assert torch.allclose(encoder(x[1, 2, 3]), whole[1, 2, 3], atol=1e-6, rtol=0), (kind, switches)
            assert torch.allclose(encoder(x.reshape(24, 5)).reshape(2, 3, 4, 5, 12), whole, atol=1e-6, rtol=0)


def test_shapes_that_cannot_work_give_a_plain_error_that_says_what_to_change():
    """A wrong number of fields, a mask of another shape, an unknown kind, edges or centres of the wrong shape."""
    encoder = ne.NumericEncoder(5, 8)
    with pytest.raises(ValueError, match="n_fields"):
        encoder(torch.rand(3, 4))
    with pytest.raises(ValueError, match="shape of x"):
        encoder(torch.rand(3, 5), missing=torch.zeros(3, 4, dtype=torch.bool))
    with pytest.raises(ValueError, match="kind must be one of"):
        ne.NumericEncoder(5, 8, kind="linear")
    with pytest.raises(ValueError, match="one row of bin edges per field"):
        ne.NumericEncoder(5, 8, kind="ple", edges=np.zeros((4, 17)))
    with pytest.raises(ValueError, match="one row of starting centres per field"):
        ne.NumericEncoder(5, 8, kind="learned_ple", centres=np.zeros((5, 1)))
    with pytest.raises(ValueError, match="frequency_init"):
        ne.NumericEncoder(5, 8, kind="periodic", frequency_init="uniform")


# ---------------------------------------------------------------------------------------------- the scale

def test_the_unit_scale_places_heavy_tailed_fields_on_zero_to_one():
    """Lognormal, Pareto, Cauchy and a heap of zeros, with missing values: the scale is the share of training rows,
    held inside [0, 1] beyond the training range, and every kind encodes it to finite tokens."""
    rng = np.random.default_rng(7)
    n = 20_000
    train = np.column_stack([rng.lognormal(3.0, 2.0, n), rng.pareto(1.1, n) * 100.0, rng.standard_cauchy(n),
                             np.where(rng.random(n) < 0.6, 0.0, rng.lognormal(5.0, 1.0, n))])
    train[rng.random(train.shape) < 0.05] = np.nan
    scaler = ne.UnitQuantileScaler().fit(train)
    # The fit is the one of QuantileScaler: the same table of quantiles.
    assert np.array_equal(scaler.quantiles, QuantileScaler().fit(train).quantiles)
    out = scaler.transform(train)
    assert out.dtype == np.float32 and out.shape == train.shape
    assert np.array_equal(np.isnan(out), np.isnan(train))
    ok = ~np.isnan(out)
    assert out[ok].min() >= 0.0 and out[ok].max() <= 1.0
    # Every tenth of the scale holds about a tenth of the rows of the three fields without a heap.
    for c in range(3):
        counts = np.histogram(out[ok[:, c], c], bins=np.linspace(0.0, 1.0, 11))[0] / ok[:, c].sum()
        assert np.abs(counts - 0.1).max() < 0.01, c
    # The heap of zeros lands on one point, the middle of the shares it covers (about 0.3 of 0.6).
    zeros = out[train[:, 3] == 0.0, 3]
    assert np.ptp(zeros) == 0.0 and abs(float(zeros[0]) - 0.3) < 0.01
    # The order of the values is kept, and values beyond every training value are held at 0 and 1.
    grid = np.sort(rng.lognormal(3.0, 3.0, 500))
    assert (np.diff(scaler.transform(np.column_stack([grid] * 4))[:, 0]) >= 0).all()
    beyond = scaler.transform(np.array([[1e300] * 4, [-1e300] * 4, [np.inf] * 4, [-np.inf] * 4]))
    assert np.array_equal(beyond, np.array([[1.0] * 4, [0.0] * 4, [1.0] * 4, [0.0] * 4], dtype=np.float32))
    # A single column is one field, and the saved state rebuilds the same scale.
    assert scaler.transform(train[:, 0]).shape == (n, 1)
    again = ne.UnitQuantileScaler.from_state(scaler.state())
    assert np.array_equal(again.transform(train), out, equal_nan=True)
    # Every kind encodes the scaled rows to finite tokens; centres at the quantiles of the scaled rows start ordered.
    x = torch.as_tensor(out[:2000])
    for kind, switches in SETTINGS:
        assert bool(torch.isfinite(_encoder(kind, switches, n_fields=4)(x)).all()), (kind, switches)
    # quantile_edges skips the missing values itself; the heap of zeros gives tied centres, which start apart.
    encoder = ne.NumericEncoder(4, 8, kind="learned_ple", centres=quantile_edges(out, ne.N_CENTRES - 1))
    assert (torch.diff(encoder.learned_bins().centres(), dim=1) > 0).all()


# ---------------------------------------------------------------------------------------------- learning

LEARN_STEPS, LEARN_ROWS, LEARN_WIDTH = 300, 2048, 16

# The mean squared error each kind must reach on fresh rows. Over the seeds 0 to 7 the worst errors were 0.0107
# ("ple"), 0.0043 ("learned_ple"), 0.0072 ("periodic") and 0.0024 ("hybrid"); every bar lies at least 2.8 times
# above them, so the test passes on other machines and other seeds too. Predicting the mean scores about 0.36 and
# the best straight line through the values about 0.19, so every bar lies far under what an encoder could reach
# without bending.
LOSS_BARS = {"ple": 0.03, "learned_ple": 0.02, "periodic": 0.02, "hybrid": 0.01}


def _task(n_rows, generator):
    """Three fields on [0, 1]: a step at 0.37 in field 0, three periods of a sine in field 1, field 2 unused."""
    x = torch.rand(n_rows, 3, generator=generator)
    y = (x[:, 0] > 0.37).float() + 0.5 * torch.sin(2.0 * math.pi * 3.0 * x[:, 1])
    return x, y


def _learn(kind, seed=0):
    """The mean squared error on fresh rows after LEARN_STEPS full-batch Adam steps of an encoder and a linear head."""
    torch.manual_seed(seed)
    g = torch.Generator().manual_seed(100 + seed)
    x, y = _task(LEARN_ROWS, g)
    fresh_x, fresh_y = _task(LEARN_ROWS, g)
    encoder = ne.NumericEncoder(3, LEARN_WIDTH, kind=kind)
    head = nn.Linear(3 * LEARN_WIDTH, 1)
    optimiser = torch.optim.Adam(list(encoder.parameters()) + list(head.parameters()), lr=0.01)
    for _ in range(LEARN_STEPS):
        loss = F.mse_loss(head(encoder(x).flatten(1)).squeeze(-1), y)
        optimiser.zero_grad()
        loss.backward()
        optimiser.step()
    with torch.no_grad():
        return float(F.mse_loss(head(encoder(fresh_x).flatten(1)).squeeze(-1), fresh_y))


def test_every_kind_learns_a_sharp_threshold_and_a_periodic_pattern():
    """In 300 steps every kind brings the error on fresh rows below its bar; the losses are printed (pytest -s)."""
    reached = {kind: _learn(kind) for kind in ne.KINDS}
    print("loss on fresh rows after 300 steps: " + ", ".join(f"{k} {v:.4f}" for k, v in reached.items()))
    for kind, loss in reached.items():
        assert loss < LOSS_BARS[kind], (kind, loss)


# ---------------------------------------------------------------------------------------------- counts and import

def test_the_weight_counts_are_those_of_the_module_docstring():
    """At 64 fields and widths 48, 96 and 144 the counts equal the table the docstring gives."""
    table = ne.weight_table(64, (48, 96, 144))
    assert table == {"ple": {48: 52_224, 96: 104_448, 144: 156_672},
                     "learned_ple": {48: 70_720, 96: 122_944, 144: 175_168},
                     "periodic": {48: 105_472, 96: 209_920, 144: 314_368},
                     "periodic, lite": {48: 5_680, 96: 10_336, 144: 14_992},
                     "hybrid": {48: 204_864, 96: 355_392, 144: 505_920}}
    for name, counts in table.items():
        # The row as the docstring lays it out: the name, then the three counts right-aligned under their widths.
        line = f"{name:<20}{counts[48]:>8,}{counts[96]:>11,}{counts[144]:>12,}"
        assert line in ne.__doc__, line
    # With the default missing="zero", "ple" is the W and b of the model in use and no more; the arm "learned" adds
    # one missing vector per field.
    assert table["ple"][48] == 64 * 17 * 48
    assert ne.count_weights(ne.NumericEncoder(64, 48, missing="learned")) == 64 * 17 * 48 + 64 * 48
    assert "weights" in ne.describe(ne.NumericEncoder(64, 48, kind="hybrid"))


# Run in a fresh interpreter inside a folder that holds copies of the files: pandas, scipy and scikit-learn are made
# unimportable first, and the folder that holds `additions/` is not on the path, so the files reach each other through
# the last branch of their imports.
FLAT_RUN = """
import runpy
import sys
for name in ("pandas", "scipy", "sklearn"):
    sys.modules[name] = None
runpy.run_path("numeric_encoders.py", run_name="__main__")
assert "additions" not in sys.modules, "the package was imported"
"""


def test_the_module_runs_from_a_flat_folder(tmp_path):
    """Copied next to numeric_frontend.py into a folder of their own, with no path to the package and with pandas, scipy
    and scikit-learn unimportable, the module imports and its demo runs: the file needs torch, numpy and the standard
    library only."""
    here = Path(ne.__file__).parent
    for name in ("numeric_encoders.py", "numeric_frontend.py"):
        shutil.copy(here / name, tmp_path / name)
    env = {name: value for name, value in os.environ.items() if name != "PYTHONPATH"}
    env.update(OMP_NUM_THREADS="1", MKL_NUM_THREADS="1")
    result = subprocess.run([sys.executable, "-c", FLAT_RUN], cwd=tmp_path, env=env, capture_output=True, text=True,
                            timeout=600)
    assert result.returncode == 0, result.stderr
    assert result.stdout.count("finite: True") == len(ne.KINDS) and "hybrid" in result.stdout


# ---------------------------------------------------------------------------------------------- the control arm

def test_frozen_centres_stay_where_they_start_and_the_branch_keeps_a_direction_per_interval():
    """learn_centres=False: the same weights and the same first tokens as "learned_ple", but the centres take no
    gradient and stay put while every other weight learns. The default branch width keeps one direction per interval,
    32 at 33 centres, and no sentence says any more that "learned_ple" differs from "ple" only in its moving centres."""
    g = torch.Generator().manual_seed(20)
    x = torch.rand(256, 3, generator=g)
    y = (x[:, 0] > 0.37).float() + torch.sin(6.0 * x[:, 1])
    for kind in ("learned_ple", "hybrid"):
        arms = {}
        for learn in (True, False):
            torch.manual_seed(0)
            arms[learn] = ne.NumericEncoder(3, 8, kind=kind, learn_centres=learn)
        learned, frozen = arms[True], arms[False]
        assert [n for n, _ in learned.named_parameters()] == [n for n, _ in frozen.named_parameters()], kind
        with torch.no_grad():
            assert torch.equal(learned(x), frozen(x)), kind
        assert frozen.settings["learn_centres"] is False and learned.settings["learn_centres"] is True
        bins = frozen.learned_bins()
        assert not bins.first.requires_grad and not bins.raw_gaps.requires_grad
        moved = {}
        for learn, encoder in arms.items():
            start = {n: w.detach().clone() for n, w in encoder.named_parameters()}
            centres = encoder.learned_bins().centres().detach().clone()
            head = nn.Linear(3 * 8, 1)
            weights = [w for w in list(encoder.parameters()) + list(head.parameters()) if w.requires_grad]
            optimiser = torch.optim.Adam(weights, lr=0.01)
            for _ in range(20):
                loss = F.mse_loss(head(encoder(x).flatten(1)).squeeze(-1), y)
                optimiser.zero_grad()
                loss.backward()
                optimiser.step()
            moved[learn] = float((encoder.learned_bins().centres().detach() - centres).abs().max())
            still = [n for n, w in encoder.named_parameters() if torch.equal(w.detach(), start[n])]
            # Every weight learns except the two that place frozen centres; the missing vector of the default
            # missing="zero" is a buffer, not a weight.
            expected = [] if learn else [n for n in start if "first" in n or "raw_gaps" in n]
            assert sorted(still) == sorted(expected), (kind, learn, still)
        assert moved[False] == 0.0 and moved[True] > 1e-3, (kind, moved)
    # One direction per interval: 16 up to 17 centres, then as many as there are intervals.
    for n_centres, width in ((9, 16), (17, 16), (33, 32), (65, 64)):
        for kind in ("learned_ple", "hybrid"):
            assert ne.NumericEncoder(2, 96, kind=kind, n_centres=n_centres).settings["branch_dim"] == width
    assert ne.NumericEncoder(2, 96, kind="learned_ple", n_centres=33, branch_dim=16).settings["branch_dim"] == 16
    # The tokens of "learned_ple" at its 33 centres span 32 directions, as the knot tokens of "ple" with 32 bins do.
    for kind, switches in (("learned_ple", {"n_centres": 33}), ("ple", {"n_bins": 32})):
        torch.manual_seed(0)
        encoder = ne.NumericEncoder(1, 96, kind=kind, **switches).double()
        with torch.no_grad():
            tokens = encoder(torch.linspace(0.0, 1.0, 33, dtype=torch.float64).unsqueeze(-1))[:, 0]
        singular = torch.linalg.svdvals(tokens - tokens[0])
        assert int((singular > 1e-9 * singular[0]).sum()) == 32, kind
    # The sentences that said the two kinds differ only in the moving centres are gone, and the frozen arm is named.
    source = " ".join(Path(ne.__file__).read_text().split())
    assert "only in that its centres" not in source and "only in that they move" not in source
    assert "learn_centres=False keeps the centres where they start" in " ".join(ne.__doc__.split())


def test_centre_parameters_give_the_centres_an_optimiser_group_of_their_own():
    """The encoder lists the two weights that place its centres, the module-level helper finds them in any model, each
    once, and the recipe of the docstring splits a model's weights into two groups that hold every weight once; one
    Adam step then moves the centres by a tenth of the global rate (CENTRE_LR_FACTOR = 0.1)."""
    torch.manual_seed(0)
    model = nn.ModuleDict({"a": ne.NumericEncoder(3, 8, kind="learned_ple"),
                           "b": ne.NumericEncoder(2, 8, kind="hybrid"), "c": ne.NumericEncoder(2, 8, kind="ple"),
                           "d": ne.NumericEncoder(2, 8, kind="periodic"), "head": nn.Linear(8, 1)})
    bins = model["a"].learned_bins()
    assert all(a is b for a, b in zip(model["a"].centre_parameters(), (bins.first, bins.raw_gaps)))
    assert len(model["a"].centre_parameters()) == 2
    assert model["c"].centre_parameters() == [] and model["d"].centre_parameters() == []
    found = ne.centre_parameters(model)
    expected = model["a"].centre_parameters() + model["b"].centre_parameters()
    assert [id(w) for w in found] == [id(w) for w in expected]
    # An encoder that appears twice in a model is listed once.
    assert len(ne.centre_parameters(nn.ModuleList([model["a"], model["a"]]))) == 2
    assert ne.centre_parameters(nn.Linear(3, 3)) == []
    assert ne.CENTRE_LR_FACTOR == 0.1
    lr = 0.1
    ids = {id(w) for w in found}
    others = [w for w in model.parameters() if id(w) not in ids]
    assert len(others) + len(found) == len(list(model.parameters()))
    optimiser = torch.optim.Adam([{"params": others}, {"params": found, "lr": lr * ne.CENTRE_LR_FACTOR}], lr=lr)
    start = [w.detach().clone() for w in found]
    vectors = bins.vectors.detach().clone()
    x = torch.rand(64, 3, generator=torch.Generator().manual_seed(21))
    model["a"](x).square().sum().backward()
    optimiser.step()
    # Adam's first step moves every weight with a gradient by about its own rate.
    step = max(float((w.detach() - s).abs().max()) for w, s in zip(found[:2], start[:2]))
    assert 0.5 * lr * ne.CENTRE_LR_FACTOR < step <= 1.01 * lr * ne.CENTRE_LR_FACTOR
    assert float((bins.vectors.detach() - vectors).abs().max()) > 0.5 * lr


# ---------------------------------------------------------------------------------------------- the inputs

def test_values_that_are_not_finite_count_as_missing_and_the_unit_scale_holds_the_rest_to_zero_to_one():
    """Without a mask, plus and minus infinity read the missing vector as NaN does, so every kind gives finite tokens.
    The kinds that read the unit scale hold a finite value outside [0, 1] at 0 or 1, so in "hybrid" no branch sees
    how far out a value lies; "ple" given edges on another scale keeps its own arithmetic there."""
    g = torch.Generator().manual_seed(22)
    x = torch.rand(6, 5, generator=g)
    dirty = x.clone()
    dirty[0, 0], dirty[1, 1], dirty[2, 2], dirty[3, :] = float("inf"), -float("inf"), float("nan"), float("inf")
    absent = ~torch.isfinite(dirty)
    for kind, switches in SETTINGS:
        encoder = _encoder(kind, switches).eval()
        with torch.no_grad():
            tokens = encoder(dirty)
            assert bool(torch.isfinite(tokens).all()), (kind, switches)
            # An infinity is a missing value: the same tokens as the slot marked missing, whatever it held.
            assert torch.equal(tokens, encoder(torch.where(absent, torch.full_like(x, 0.5), dirty), missing=absent))
            for far, end in ((1.5, 1.0), (1e30, 1.0), (3e38, 1.0), (-0.5, 0.0), (-1e30, 0.0)):
                assert torch.equal(encoder(torch.full((1, 5), far)), encoder(torch.full((1, 5), end))), (kind, far)
        assert encoder.unit_scale, (kind, switches)
        # Gradients stay finite with infinities in the batch.
        encoder.train()
        encoder(dirty).square().sum().backward()
        assert all(bool(torch.isfinite(w.grad).all()) for w in encoder.parameters() if w.grad is not None)
    # "ple" with edges on a scale of its own: no hold, so open ends still run on; infinity is still missing.
    edges = np.tile(np.linspace(-3.0, 5.0, 9), (2, 1))
    own = ne.NumericEncoder(2, 4, kind="ple", edges=edges, open_ends=True)
    assert not own.unit_scale and not own.settings["unit_scale"]
    with torch.no_grad():
        a = own(torch.tensor([[7.0, float("inf")]]))
        b = own(torch.tensor([[9.0, float("nan")]]))
    assert not torch.allclose(a[:, 0], b[:, 0]) and torch.equal(a[:, 1], b[:, 1])
    # The switch forces either way.
    assert not ne.NumericEncoder(2, 4, kind="hybrid", unit_scale=False).unit_scale
    assert ne.NumericEncoder(2, 4, kind="ple", edges=edges, unit_scale=True).unit_scale


def test_a_module_cast_to_16_bits_forms_its_angles_and_centres_in_32_bits():
    """Cast to bfloat16 or float16: the Fourier features keep their phase up to 64 turns, the centres stay strictly
    increasing with their gaps at the floor, and every kind agrees with a 64-bit copy of the same rounded weights to
    the rounding of its result alone."""
    g = torch.Generator().manual_seed(23)
    x = torch.rand(2000, 5, generator=g)
    for dtype, tolerance in ((torch.bfloat16, 0.02), (torch.float16, 0.004)):
        torch.manual_seed(0)
        branch = ne.FourierBranch(5, 4).to(dtype)
        with torch.no_grad():
            low = branch.features(x)
            angle = x.double().unsqueeze(-1) * branch.frequencies.detach().double()
            exact = torch.cat([x.double().unsqueeze(-1), torch.sin(angle), torch.cos(angle)], dim=-1)
        assert low.dtype == dtype and float((low.double() - exact).abs().max()) < 0.01, dtype
        bins = ne.LearnedBinBranch(1, 4)
        with torch.no_grad():
            bins.raw_gaps[0, 12:] = -100.0               # the last four gaps at the floor, near the top of [0, 1]
        centres = bins.to(dtype).centres().detach()
        assert centres.dtype == torch.float32 and bool((torch.diff(centres, dim=1) > 0).all()), dtype
        for kind, switches in SETTINGS:
            encoder = _encoder(kind, switches).to(dtype)
            reference = copy.deepcopy(encoder).double()
            with torch.no_grad():
                tokens, exact = encoder(x), reference(x)
            assert tokens.dtype == dtype, (kind, switches)
            error = float((tokens.double() - exact).abs().max() / exact.abs().max())
            assert error < tolerance, (dtype, kind, switches, error)


# The last part of the name of every tensor that places a value: under a cast to 16 bits it stays in float32.
PLACES = ("left", "width", "first", "raw_gaps", "floor", "frequencies")


def _token_error(encoder, other, x):
    """The largest difference of the tokens of `other` from those of `encoder` on x, as a share of the largest token."""
    with torch.no_grad():
        exact = encoder(x).double()
        return float((other(x).double() - exact).abs().max() / exact.abs().max())


def test_a_module_cast_to_16_bits_gives_its_edges_centres_and_frequencies_in_32_bits():
    """After .to(torch.bfloat16) or .half() the fixed edges, the tensors that place the centres and the frequencies are
    float32 and every other floating tensor is 16-bit, so the tokens stay near those of the float32 encoder: in
    bfloat16 they were 0.10 to 0.21 of the largest token apart when those tensors were rounded too. A device move,
    .float() and .double() keep the usual behaviour; the state round trip, one AdamW step and copy.deepcopy work."""
    g = torch.Generator().manual_seed(31)
    x = torch.rand(512, 5, generator=g)
    # Edges as fit_edges gives them, which 16 bits cannot hold exactly, unlike the even sixteenths of the default.
    uneven = np.sort(np.random.default_rng(31).random((5, 17)), axis=1)
    uneven[:, 0], uneven[:, -1] = 0.0, 1.0
    for kind, switches in SETTINGS + [("ple", {"edges": uneven}), ("ple", {"edges": uneven, "open_ends": True})]:
        encoder = _encoder(kind, switches).eval()
        cast = {torch.bfloat16: copy.deepcopy(encoder).to(torch.bfloat16), torch.float16: copy.deepcopy(encoder).half()}
        for dtype, bar in ((torch.bfloat16, 0.02), (torch.float16, 0.003)):
            low = cast[dtype]
            types = {name: t.dtype for name, t in list(low.named_parameters()) + list(low.named_buffers())
                     if t.is_floating_point()}
            places = [name for name in types if name.split(".")[-1] in PLACES]
            assert places, (kind, switches)
            assert all(types[name] == torch.float32 for name in places), (kind, switches, dtype, types)
            assert all(types[name] == dtype for name in types if name not in places), (kind, switches, dtype, types)
            error = _token_error(encoder, low, x)
            assert error < bar, (kind, switches, dtype, error)
            # Back to float32, the tensors that place a value are those of the encoder bit for bit: never rounded.
            back = copy.deepcopy(low).float()
            assert all(torch.equal(back.state_dict()[name], encoder.state_dict()[name]) for name in places), kind
            # copy.deepcopy and the state round trip give the same types and the same tokens.
            again = _encoder(kind, switches, seed=1).eval()
            again = again.to(torch.bfloat16) if dtype == torch.bfloat16 else again.half()
            again.load_state_dict(low.state_dict())
            for other in (copy.deepcopy(low), again):
                assert [t.dtype for t in other.state_dict().values()] == [t.dtype for t in low.state_dict().values()]
                with torch.no_grad():
                    assert torch.equal(other(x), low(x)), (kind, switches, dtype)
        # One AdamW step on the module cast to bfloat16: every weight stays finite and keeps its type, gradients too.
        # (In float16 the eps of AdamW, 1e-8, rounds to zero, a matter of float16 training and not of this module.)
        low = cast[torch.bfloat16].train()
        optimiser = torch.optim.AdamW(low.parameters(), lr=1e-3)
        before = {name: w.detach().clone() for name, w in low.named_parameters()}
        low(x).float().square().mean().backward()
        optimiser.step()
        for name, w in low.named_parameters():
            assert bool(torch.isfinite(w).all()) and w.dtype == before[name].dtype, (kind, name)
            assert w.grad is None or w.grad.dtype == w.dtype, (kind, name)
        assert any(not torch.equal(w.detach(), before[name]) for name, w in low.named_parameters()), kind
        # A device move keeps every type; a move and a cast at once keep the places in float32 on the new device.
        moved = copy.deepcopy(low).to("meta")
        assert all(t.device.type == "meta" and t.dtype == low.state_dict()[name].dtype
                   for name, t in moved.state_dict().items()), kind
        both = copy.deepcopy(encoder).to("meta", torch.bfloat16).state_dict()
        assert all(both[name].dtype == torch.float32 and both[name].device.type == "meta" for name in places), kind
        # .double() widens every tensor, as torch does, and the tokens are those of the float32 encoder to the rounding
        # of 32-bit numbers.
        wide = copy.deepcopy(encoder).double()
        assert all(t.dtype == torch.float64 for t in wide.state_dict().values() if t.is_floating_point()), kind
        assert _token_error(encoder, wide, x) < 1e-5, kind


def test_missing_zero_holds_a_fixed_zero_so_a_missing_number_reads_its_identity_alone():
    """missing="zero", the default: the missing vector is a zero buffer, not a weight, so a missing number gives the
    identity of its field and nothing learns for it; every other weight is drawn as with the arm "learned", and the
    two forms share the key of their state."""
    default = ne.NumericEncoder(5, 8)
    assert default.settings["missing"] == "zero" and "missing" in dict(default.named_buffers())
    g = torch.Generator().manual_seed(24)
    x = torch.rand(8, 5, generator=g)
    mask = torch.rand(8, 5, generator=g) < 0.4
    for kind, switches in SETTINGS:
        forms = {}
        for missing in ("learned", "zero"):
            torch.manual_seed(0)
            forms[missing] = ne.NumericEncoder(5, 12, kind=kind, missing=missing, **switches)
        learned, zero = forms["learned"], forms["zero"]
        assert learned.settings["missing"] == "learned" and zero.settings["missing"] == "zero"
        assert "missing" in dict(learned.named_parameters()) and "missing" not in dict(zero.named_parameters())
        assert "missing" in dict(zero.named_buffers()) and torch.equal(zero.missing, torch.zeros(5, 12))
        assert ne.count_weights(learned) - ne.count_weights(zero) == 5 * 12
        with torch.no_grad():
            assert torch.equal(zero(x), learned(x)), (kind, switches)
        tokens = zero(x, missing=mask)
        rows, fields = torch.nonzero(mask, as_tuple=True)
        assert torch.equal(tokens[rows, fields].detach(), zero.identity.detach()[fields]), (kind, switches)
        tokens.square().sum().backward()
        torch.optim.SGD(zero.parameters(), lr=0.1).step()
        assert torch.equal(zero.missing, torch.zeros(5, 12))
        zero.load_state_dict(learned.state_dict())
    with pytest.raises(ValueError, match="missing must be one of"):
        ne.NumericEncoder(5, 8, missing="mean")


def test_a_checkpoint_with_a_trained_missing_vector_gives_a_value_error_in_an_encoder_with_missing_zero():
    """missing="zero" keeps the key of "learned", and a checkpoint of a trained "learned" encoder used to fill the zero
    buffer while load_state_dict reported every key matched. Now the load stops with a ValueError that says what to do
    and leaves the encoder as it was, inside a model, in a copy and in a saved module too; an entry of zeros loads as
    before, so checkpoints of both forms keep their keys."""
    torch.manual_seed(0)
    learned = ne.NumericEncoder(3, 4, kind="ple", missing="learned")
    with torch.no_grad():
        learned.missing.normal_()                                       # as after training
    zero = ne.NumericEncoder(3, 4, kind="ple")
    start = {name: tensor.clone() for name, tensor in zero.state_dict().items()}
    with pytest.raises(ValueError, match="missing='learned' to load it"):
        zero.load_state_dict(learned.state_dict())
    assert all(torch.equal(tensor, start[name]) for name, tensor in zero.state_dict().items())
    with torch.no_grad():
        assert torch.equal(zero(torch.tensor([[float("nan"), 0.5, 0.5]]))[0, 0], zero.identity[0])
    # Inside a model, in a copy and in a module saved whole, the load stops the same way and names the entry.
    model = nn.ModuleDict({"numbers": copy.deepcopy(zero)})
    with pytest.raises(ValueError, match="numbers.missing"):
        model.load_state_dict({"numbers." + name: tensor for name, tensor in learned.state_dict().items()})
    saved = io.BytesIO()
    torch.save(zero, saved)
    saved.seek(0)
    with pytest.raises(ValueError, match="trained missing vector"):
        torch.load(saved, weights_only=False).load_state_dict(learned.state_dict())
    # A NaN in the entry is not a zero either, and strict=False does not let it through.
    odd = learned.state_dict()
    odd["missing"] = torch.full_like(odd["missing"], float("nan"))
    with pytest.raises(ValueError, match="trained missing vector"):
        zero.load_state_dict(odd, strict=False)
    # The entry set to zero drops it: the rest loads and every key matches.
    dropped = learned.state_dict()
    dropped["missing"] = torch.zeros_like(dropped["missing"])
    result = zero.load_state_dict(dropped)
    assert not result.missing_keys and not result.unexpected_keys
    assert torch.equal(zero.identity, learned.identity) and torch.equal(zero.missing, torch.zeros(3, 4))
    # A "zero" checkpoint loads into "learned" as before.
    learned.load_state_dict(zero.state_dict())
    assert torch.equal(learned.missing.detach(), torch.zeros(3, 4))


def test_a_kind_that_reads_the_unit_scale_warns_once_when_most_values_skipped_the_scaler():
    """In training mode, a field with more than half its values outside [0, 1] gives one warning that names the field
    and UnitQuantileScaler, once per encoder; evaluation mode, scaled values, a field with fewer than half outside and
    "ple" given edges on another scale say nothing."""
    g = torch.Generator().manual_seed(25)
    x = torch.rand(64, 5, generator=g)
    x[:, 3] = torch.rand(64, generator=g) * 3_000.0 + 2.0              # raw amounts in field 3
    x[:20, 1] = 5.0                                                     # a few values outside in field 1
    for kind, switches in SETTINGS:
        encoder = _encoder(kind, switches)
        with pytest.warns(UserWarning, match="UnitQuantileScaler") as record:
            encoder(x)
        assert len(record) == 1 and "field(s) [3]" in str(record[0].message), (kind, switches)
        with warnings.catch_warnings():
            warnings.simplefilter("error")
            encoder(x)                                                  # said once only
            quiet = _encoder(kind, switches)
            quiet.eval()
            quiet(x)                                                    # evaluation mode
            quiet.train()
            quiet(torch.rand(64, 5, generator=g))                       # scaled values
    # The example of the check: three raw numbers into the 32 even bins of "ple" all read alike, and now say so.
    with pytest.warns(UserWarning, match="UnitQuantileScaler"):
        ne.NumericEncoder(1, 4, kind="ple", n_bins=32)(torch.tensor([[2.0], [50.0], [3000.0]]))
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        own = ne.NumericEncoder(5, 8, kind="ple", edges=np.tile(np.linspace(-3.0, 5_000.0, 17), (5, 1)))
        own(x)


def test_an_encoder_with_unscaled_raise_gives_a_value_error_with_the_text_of_the_warning():
    """unscaled="raise": the look at the first training batches stops on raw numbers with a ValueError that carries
    the text of the warning, and the look stays open, so the same batch given again stops again. Enough scaled values
    pass and close the look, evaluation mode does not look, settings record the switch, and an unknown value is a plain
    error."""
    g = torch.Generator().manual_seed(29)
    x = torch.rand(64, 5, generator=g)
    x[:, 3] = torch.rand(64, generator=g) * 3_000.0 + 2.0              # raw amounts in field 3
    for kind, switches in SETTINGS:
        warned = _encoder(kind, switches)
        with pytest.warns(UserWarning, match="UnitQuantileScaler") as record:
            warned(x)
        stopped = _encoder(kind, {"unscaled": "raise", **switches})
        assert warned.settings["unscaled"] == "warn" and stopped.settings["unscaled"] == "raise", (kind, switches)
        for _ in range(2):
            with pytest.raises(ValueError, match="UnitQuantileScaler") as error:
                stopped(x)
            assert str(error.value) == str(record[0].message), (kind, switches)
        with warnings.catch_warnings():
            warnings.simplefilter("error")
            stopped(torch.rand(ne.LOOK_VALUES, 5, generator=g))         # enough scaled values pass and close it
            assert stopped._look_open is False, (kind, switches)
            stopped(x)                                                  # the look is closed
            _encoder(kind, {"unscaled": "raise", **switches}).eval()(x)  # evaluation mode does not look
    # "ple" given edges on a scale of its own does not read the unit scale, so it never looks.
    own = ne.NumericEncoder(5, 8, kind="ple", edges=np.tile(np.linspace(-3.0, 5_000.0, 17), (5, 1)), unscaled="raise")
    own(x)
    with pytest.raises(ValueError, match="unscaled must be one of"):
        ne.NumericEncoder(5, 8, unscaled="ignore")


# ---------------------------------------------------------------------------------------------- heaps and ties

def test_fit_centres_and_fit_edges_start_at_distinct_quantiles_and_spread_the_rest_between_them():
    """A heap of zeros, a field of four values, a continuous field and a constant one, on the unit scale: every field
    gets strictly increasing places that hold its distinct quantiles, with the other places spread evenly over the gaps
    between them. The even grid leaves 8 of 16 intervals of the heap field without a row; the fitted centres leave 1."""
    rng = np.random.default_rng(26)
    n = 200_000
    raw = np.column_stack([np.where(rng.random(n) < 0.6, 0.0, rng.lognormal(3.0, 1.5, n)),
                           rng.choice([1.0, 2.0, 3.0, 50.0], size=n, p=[0.7, 0.2, 0.07, 0.03]),
                           rng.normal(size=n), np.full(n, 5.0)])
    scaled = ne.UnitQuantileScaler().fit(raw).transform(raw)
    centres = ne.fit_centres(scaled, 17)
    assert centres.shape == (4, 17) and centres.dtype == np.float32
    assert (np.diff(centres, axis=1) > 0).all()
    for c in range(3):
        distinct = np.unique(np.quantile(scaled[:, c], np.linspace(0.0, 1.0, 17))).astype(np.float32)
        assert np.isin(distinct, centres[c]).all(), c
        # The same number of extra centres in every gap between neighbouring distinct quantiles, give or take one,
        # evenly spaced inside it.
        extra = [int(((centres[c] > lo) & (centres[c] < hi)).sum()) for lo, hi in zip(distinct[:-1], distinct[1:])]
        assert max(extra) - min(extra) <= 1, (c, extra)
        for lo, hi in zip(distinct[:-1], distinct[1:]):
            inside = centres[c][(centres[c] >= lo) & (centres[c] <= hi)]
            assert np.abs(np.diff(inside) - (hi - lo) / (len(inside) - 1)).max() < 1e-6, c
    # A continuous field gets its plain quantiles, the even grid on the unit scale; a constant field the even grid.
    assert np.abs(centres[2] - np.linspace(0.0, 1.0, 17)).max() < 0.01
    assert np.array_equal(centres[3], np.linspace(0.0, 1.0, 17).astype(np.float32))
    even = ne.NumericEncoder(4, 8, kind="learned_ple")
    fitted = ne.NumericEncoder(4, 8, kind="learned_ple", centres=centres)
    assert fitted.unit_scale
    use_even, use_fitted = ne.interval_use(even, scaled), ne.interval_use(fitted, scaled)
    assert use_even["intervals"].tolist() == [16] * 4 and use_fitted["intervals"].tolist() == [16] * 4
    assert use_even["held"].tolist() == [8, 4, 16, 1] and use_fitted["held"].tolist() == [15, 4, 16, 1]
    assert use_fitted["rows"].sum(axis=1).tolist() == [n] * 4 and use_fitted["outside"].tolist() == [0] * 4
    # fit_edges follows the same rule for "ple": B bins with a width, where quantile_edges keeps 7 for the heap field.
    edges = ne.fit_edges(scaled, 16)
    assert edges.shape == (4, 17) and np.array_equal(edges, centres)
    use_ple = ne.interval_use(ne.NumericEncoder(4, 8, kind="ple", edges=edges), scaled)
    assert use_ple["held"].tolist() == [15, 4, 16, 1]
    padded = ne.interval_use(ne.NumericEncoder(4, 8, kind="ple", edges=quantile_edges(scaled, 16)), scaled)
    assert padded["intervals"][0] == 7 and padded["held"][0] == 7
    # interval_use reads rows as the encoder does: infinities and NaN left out, the rest held to [0, 1].
    odd = np.array([[np.inf, np.nan, -5.0, 2.0]])
    assert ne.interval_use(even, odd)["rows"].sum(axis=1).tolist() == [0, 0, 1, 1]
    with pytest.raises(ValueError, match="neither"):
        ne.interval_use(ne.NumericEncoder(4, 8, kind="periodic"), scaled)
    with pytest.raises(ValueError, match="C = 4"):
        ne.interval_use(even, scaled[:, :3])
    with pytest.raises(ValueError, match="n_centres"):
        ne.fit_centres(scaled, 1)


# ---------------------------------------------------------------------------------------------- the model in use

def _rtdl_shares(x, bins):
    """The piecewise-linear encoding of rtdl_num_embeddings 0.0.11, version A, re-typed from its source and not run
    from the package: x [N, C] to [N, C, max bins]. A field with n bins fills places 0 .. n - 2 and the last place;
    the first place runs on below its edge, the last above its edge, and a single bin both ways."""
    n_bins = [len(b) - 1 for b in bins]
    m = max(n_bins)
    weight = torch.zeros(len(bins), m, dtype=torch.float64)
    bias = torch.zeros(len(bins), m, dtype=torch.float64)
    for i, e in enumerate(bins):
        width = e.diff()
        w, b = 1.0 / width, -e[:-1] / width
        weight[i, -1], bias[i, -1] = w[-1], b[-1]
        weight[i, :n_bins[i] - 1] = w[:-1]
        bias[i, :n_bins[i] - 1] = b[:-1]
    single = torch.tensor(n_bins) == 1
    z = torch.addcmul(bias, weight, x[..., None])
    return torch.cat([z[..., :1].clamp_max(1.0), z[..., 1:-1].clamp(0.0, 1.0),
                      torch.where(single[..., None], z[..., -1:], z[..., -1:].clamp_min(0.0))], dim=-1)


def test_load_piecewise_weight_reproduces_the_rtdl_reference_for_fields_with_fewer_bins():
    """A field of 16 bins, a heap field with fewer and a field of one bin: W and b of the rtdl layout loaded with
    layout="rtdl" into "ple" with open ends give the tokens of the reference to 1e-6; a straight copy does not for the
    short fields, held ends say so in a warning, and inputs that cannot work are plain errors that change nothing."""
    rng = np.random.default_rng(27)
    n = 20_000
    train = np.column_stack([rng.normal(size=n), np.where(rng.random(n) < 0.6, 0.0, rng.lognormal(0.0, 1.0, n)),
                             np.where(rng.random(n) < 0.99, 0.0, 1.0)])
    # The bins of rtdl: the distinct quantiles of every field.
    bins = [torch.as_tensor(np.unique(np.quantile(train[:, c], np.linspace(0.0, 1.0, 17))), dtype=torch.float64)
            for c in range(3)]
    counts = [len(b) - 1 for b in bins]
    assert counts[0] == 16 and 1 < counts[1] < 16 and counts[2] == 1
    d = 8
    g = torch.Generator().manual_seed(27)
    W = torch.randn(3, 16, d, generator=g, dtype=torch.float64) * 0.1
    b = torch.randn(3, d, generator=g, dtype=torch.float64) * 0.1
    x = torch.as_tensor(np.r_[train[:2000], [[-9.0, -1.0, -3.0], [9.0, 99.0, 4.0]]], dtype=torch.float64)
    reference = torch.einsum("ncb,cbd->ncd", _rtdl_shares(x, bins), W) + b
    # The edges as numeric_frontend.py pads them: the last edge repeated to 17.
    edges = np.stack([np.r_[e.numpy(), np.full(17 - len(e), e.numpy()[-1])] for e in bins])
    encoder = ne.NumericEncoder(3, d, kind="ple", edges=edges, open_ends=True).double()
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        assert ne.load_piecewise_weight(encoder, W, counts, layout="rtdl", b=b) is encoder
    # To 1e-6: the encoder holds its edges in 32-bit numbers, which is all that is left between the two.
    with torch.no_grad():
        assert float((encoder(x) - reference).abs().max()) < 1e-6
    straight = ne.NumericEncoder(3, d, kind="ple", edges=edges, open_ends=True).double()
    ne.load_piecewise_weight(straight, W, counts, layout="in_order", b=b)
    with torch.no_grad():
        apart = (straight(x) - reference).abs().amax(dim=(0, 2))
    assert apart[0] < 1e-6 and apart[1] > 1e-2 and apart[2] > 1e-2
    held = ne.NumericEncoder(3, d, kind="ple", edges=edges, open_ends=False).double()
    with pytest.warns(UserWarning, match="open_ends=True"):
        ne.load_piecewise_weight(held, W, counts, layout="rtdl", b=b)
    with pytest.warns(UserWarning, match="do not have bin_counts"):
        ne.load_piecewise_weight(encoder, W, [16, 16, 1], layout="rtdl")
    before = encoder.value.weight.detach().clone()
    for (weight, count, constant), match in (((W[:, :8], counts, b), "W must be"), ((W, counts[:2], b), "bin_counts"),
                                             ((W, [16, 0, 1], b), "bin_counts"), ((W, counts, b[:2]), "b must be")):
        with pytest.raises(ValueError, match=match):
            ne.load_piecewise_weight(encoder, weight, count, layout="rtdl", b=constant)
    assert torch.equal(encoder.value.weight.detach(), before)
    with pytest.raises(ValueError, match="layout"):
        ne.load_piecewise_weight(encoder, W, counts, layout="rtdl_b")
    with pytest.raises(ValueError, match="'ple'"):
        ne.load_piecewise_weight(ne.NumericEncoder(3, d, kind="learned_ple"), W, counts)


def test_a_trained_model_with_edges_on_zero_to_one_gives_the_tokens_of_the_rtdl_reference_beyond_them():
    """The model's own edges all on [0, 1] (numbers min-max scaled before its encoding), open ends, and values below 0
    and above 1: load_piecewise_weight sets the encoder to read its numbers as the trained model did, unit_scale False
    in its settings too, so its tokens agree with the rtdl reference to 1e-6 there as well. Held to [0, 1], the
    values beyond the edges gave differences of 0.775 and 13.5."""
    rng = np.random.default_rng(30)
    n = 20_000
    train = np.column_stack([rng.random(n), rng.beta(0.5, 3.0, n), np.where(rng.random(n) < 0.6, 0.0, rng.random(n))])
    bins = [torch.as_tensor(np.unique(np.quantile(train[:, c], np.linspace(0.0, 1.0, 17))), dtype=torch.float64)
            for c in range(3)]
    counts = [len(b) - 1 for b in bins]
    edges = np.stack([np.r_[e.numpy(), np.full(17 - len(e), e.numpy()[-1])] for e in bins])
    assert ((edges >= 0.0) & (edges <= 1.0)).all() and counts[0] == 16 and counts[2] < 16
    d = 8
    g = torch.Generator().manual_seed(30)
    W = torch.randn(3, 16, d, generator=g, dtype=torch.float64) * 0.1
    b = torch.randn(3, d, generator=g, dtype=torch.float64) * 0.1
    beyond = [[-0.2, -0.1, -0.5], [1.3, 1.6, 2.0], [-3.0, 5.0, 9.0]]
    x = torch.as_tensor(np.r_[train[:2000], beyond], dtype=torch.float64)
    reference = torch.einsum("ncb,cbd->ncd", _rtdl_shares(x, bins), W) + b
    encoder = ne.NumericEncoder(3, d, kind="ple", edges=edges, open_ends=True).double()
    # Edges on [0, 1] read as the unit scale until the trained weights come in.
    assert encoder.unit_scale and encoder.settings["unit_scale"]
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        ne.load_piecewise_weight(encoder, W, counts, layout="rtdl", b=b)
        assert encoder.unit_scale is False and encoder.settings["unit_scale"] is False
        # In training mode: the look at the scale is off too, so values beyond [0, 1] say nothing.
        with torch.no_grad():
            tokens = encoder(x)
    apart = (tokens - reference).abs()
    assert bool((apart <= 1e-6 * torch.clamp(reference.abs(), min=1.0)).all()), float(apart.max())
    # The rows beyond the edges are the ones a hold to [0, 1] changed; they now move with the value, as in rtdl.
    assert not torch.allclose(tokens[-3], tokens[-2])


# ---------------------------------------------------------------------------------------------- memory

def _kept(encoder, rows):
    """The numbers of every tensor the backward pass keeps after one call on `rows` rows, each storage counted once."""
    x = torch.rand(rows, encoder.n_fields, generator=torch.Generator().manual_seed(28))
    storages = {}

    def keep(t):
        storage = t.untyped_storage()
        storages[storage.data_ptr()] = max(storages.get(storage.data_ptr(), 0), storage.nbytes() // t.element_size())
        return t

    with torch.autograd.graph.saved_tensors_hooks(keep, lambda t: t):
        encoder(x)
    return sum(storages.values())


def test_the_memory_figures_are_those_of_the_module_docstring():
    """The numbers kept for the backward pass per row and field, the growth from 2,048 to 4,096 rows at width 48 and
    64 fields so that the weights do not count, are the figures of the module docstring."""
    doc = ne.__doc__
    for name in ("ple", "learned_ple", "periodic", "periodic, lite", "hybrid"):
        kind, lite = ("periodic", True) if name == "periodic, lite" else (name, False)
        torch.manual_seed(0)
        encoder = ne.NumericEncoder(64, 48, kind=kind, lite=lite)
        per = (_kept(encoder, 4096) - _kept(encoder, 2048)) / (2048 * 64)
        line = f"    {name:<20}{round(per):>11}\n"
        assert line in doc, (name, per)


def test_the_unit_scale_flag_is_saved_with_the_weights_and_an_older_checkpoint_keeps_the_built_one():
    """load_piecewise_weight turns unit_scale off on the encoder it fills. The flag was a plain attribute, so an encoder
    built again the same way and loaded from that checkpoint held its values to [0, 1] again, and rows beyond the edges
    moved by 0.91 and 15.8. It is now kept in the buffer held_to_unit: the rebuilt encoder takes it back and gives the
    same tokens. A checkpoint without that entry loads strictly and leaves the flag as the encoder was built."""
    d = 6
    edges = np.tile(np.linspace(0.0, 1.0, 9), (2, 1))
    g = torch.Generator().manual_seed(31)
    W, b = torch.randn(2, 8, d, generator=g), torch.randn(2, d, generator=g)
    trained = ne.NumericEncoder(2, d, kind="ple", edges=edges, open_ends=True)
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        ne.load_piecewise_weight(trained, W, [8, 8], layout="rtdl", b=b)
    state = trained.state_dict()
    assert state["held_to_unit"].dtype == torch.bool and not bool(state["held_to_unit"])
    x = torch.tensor([[0.3, 0.7], [-0.2, 1.3], [-3.0, 9.0]])
    rebuilt = ne.NumericEncoder(2, d, kind="ple", edges=edges, open_ends=True)
    assert rebuilt.unit_scale and bool(rebuilt.held_to_unit)
    rebuilt.load_state_dict(state)
    assert rebuilt.unit_scale is False and rebuilt.settings["unit_scale"] is False
    with torch.no_grad():
        assert torch.equal(rebuilt.eval()(x), trained.eval()(x))
        held = ne.NumericEncoder(2, d, kind="ple", edges=edges, open_ends=True)
        held.load_state_dict({**state, "held_to_unit": torch.tensor(True)})
        assert not torch.allclose(held.eval()(x)[1:], trained(x)[1:])        # held to [0, 1], as before the fix
    # A checkpoint saved before the flag was kept: a strict load passes and the flag stays as built.
    older = {name: tensor for name, tensor in state.items() if name != "held_to_unit"}
    again = ne.NumericEncoder(2, d, kind="ple", edges=edges, open_ends=True)
    again.load_state_dict(older)
    assert again.unit_scale and bool(again.held_to_unit)
    # The flag goes with copies and casts, and setting it writes the buffer and the settings.
    low = copy.deepcopy(trained).to(torch.bfloat16)
    assert low.unit_scale is False and low.held_to_unit.dtype == torch.bool
    trained.unit_scale = True
    assert bool(trained.held_to_unit) and trained.settings["unit_scale"]


def test_a_field_missing_from_the_first_batch_is_looked_at_on_the_first_batch_that_holds_it():
    """The look at the scale closed on the first batch that held any value, so a field missing from that batch was
    never judged and its raw numbers passed later without a word, even under unscaled="raise". Every field is now
    looked at from the first training batch that holds a value of it."""
    first = torch.rand(16, 2, generator=torch.Generator().manual_seed(32))
    first[:, 1] = float("nan")
    raw = first.clone()
    raw[:, 1] = 300.0
    for unscaled, expected in (("warn", pytest.warns(UserWarning, match=r"field\(s\) \[1\]")),
                               ("raise", pytest.raises(ValueError, match=r"field\(s\) \[1\]"))):
        encoder = ne.NumericEncoder(2, 4, kind="periodic", unscaled=unscaled)
        with warnings.catch_warnings():
            warnings.simplefilter("error")
            encoder(first)                                   # field 0 on [0, 1], field 1 missing: nothing to say
        assert encoder._seen.tolist() == [16, 0] and encoder._scale_open.tolist() == [True, True]
        with expected:
            encoder(raw)
    encoder = ne.NumericEncoder(2, 4, kind="periodic")
    encoder(torch.rand(ne.LOOK_VALUES, 2))
    assert not bool(encoder._scale_open.any()) and encoder._look_open is False      # every field judged: closed


def test_a_sparse_field_is_judged_on_many_values_not_on_its_first_few():
    """A field was judged, and closed for good, on the first training batch that held any value of it, so a raw count
    that skipped the scaler and first showed as 0, 1 and 0 trained on unseen, every later value read as 1. Its values
    are now counted until LOOK_VALUES of them have not shown it unscaled; the raw counts that follow are named, while
    a field on [0, 1] closes once it has shown enough values, and every field closes after LOOK_BATCHES batches."""
    g = torch.Generator().manual_seed(41)
    for unscaled, expected in (("warn", pytest.warns(UserWarning, match=r"field\(s\) \[1\]")),
                               ("raise", pytest.raises(ValueError, match=r"field\(s\) \[1\]"))):
        encoder = ne.NumericEncoder(2, 4, kind="periodic", unscaled=unscaled)
        sparse = torch.rand(64, 2, generator=g)
        sparse[:, 1] = float("nan")
        sparse[:3, 1] = torch.tensor([0.0, 1.0, 0.0])                    # three values of the raw count, all on [0, 1]
        with warnings.catch_warnings():
            warnings.simplefilter("error")
            encoder(sparse)
        assert encoder._scale_open.tolist() == [True, True]
        counts = torch.rand(64, 2, generator=g)
        counts[:, 1] = torch.randint(0, 40, (64,), generator=g).float()  # the raw count in every row
        with expected:
            encoder(counts)
    # A field on [0, 1] is closed once it has shown LOOK_VALUES values; a field that never shows is closed after
    # LOOK_BATCHES training batches, after which no batch is looked at.
    encoder = ne.NumericEncoder(2, 4, kind="periodic")
    half = torch.rand(ne.LOOK_VALUES // 2, 2, generator=g)
    half[:, 1] = float("nan")
    encoder(half)
    encoder(half)
    assert encoder._scale_open.tolist() == [False, True] and encoder._look_open
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        for _ in range(ne.LOOK_BATCHES - 2):
            encoder(half)
    assert encoder._look_open is False and encoder._looks == ne.LOOK_BATCHES


def test_the_look_keeps_its_counts_on_the_cpu_and_a_meta_build_trains():
    """The flags of the look were a plain tensor made on the default device, so an encoder built under
    torch.device("meta") and loaded with assign=True scored but stopped on its first training step. They are now made
    on the CPU, and the gate the forward pass reads is a plain bool, so a training step after the look has closed
    reads no tensor for it."""
    reference = ne.NumericEncoder(3, 4, kind="hybrid")
    state = reference.state_dict()
    with torch.device("meta"):
        encoder = ne.NumericEncoder(3, 4, kind="hybrid")
    assert encoder._seen.device.type == "cpu" and encoder._scale_open.device.type == "cpu"
    encoder.load_state_dict(state, assign=True)
    x = torch.rand(8, 3, generator=torch.Generator().manual_seed(43))
    assert torch.equal(encoder.eval()(x), reference.eval()(x))
    encoder.train()(x).sum().backward()                                  # the first training step runs
    assert isinstance(encoder._look_open, bool)
    encoder(torch.rand(ne.LOOK_VALUES, 3))
    assert encoder._look_open is False

    def stop(*args):
        raise AssertionError("the look ran after it had closed")

    encoder._check_scale = stop
    encoder(x)


def test_a_missing_entry_on_the_meta_device_loads_into_missing_zero():
    """A model built on the meta device and loaded with assign=True hands over a missing entry that holds no numbers;
    the hook that keeps the fixed zero stopped on Tensor.item() there, and now lets it through."""
    with torch.device("meta"):
        meta = ne.NumericEncoder(3, 4, kind="ple")
    target = ne.NumericEncoder(3, 4, kind="ple")
    target.load_state_dict(meta.state_dict(), assign=True)
    assert target.missing.is_meta and target.held_to_unit.is_meta and target.unit_scale
