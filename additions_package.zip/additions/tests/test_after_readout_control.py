"""Tests of the three readouts on exported vectors.

The blocks are checked against their definition (one to two months of history, every row a
target once), the order-free memory and the GRU state are recomputed the slow way from the
rows of strictly earlier seconds, and the time rule is checked on rows that share a second
and on later rows. The readouts are checked for shapes, finite values, gradient flow, the
zero start of the GRU projection and that training learns a plain signal.
"""
import numpy as np
import pandas as pd
import torch

from additions import settings
from additions.after_model import readout_control as rc
from additions.common import ranking, synthetic, tables, timekeys
from additions.common.timekeys import MISSING_SECOND

DAY = 86_400


def _export(n_accounts=40, seed=0, days=61, start=None, dim=4, strength=1.5):
    """Made-up scored rows with vectors; fraud runs on a third of the accounts."""
    df = synthetic.make_transactions(n_accounts=n_accounts, seed=seed, days=days, start=start, fraud_account_share=0.35)
    return synthetic.make_vectors(synthetic.make_scores(df, seed=seed, strength=strength), dim=dim, seed=seed)


def _data(**kwargs):
    df = _export(**kwargs)
    return df, rc.prepare(df)


def test_training_blocks_give_one_to_two_months_of_complete_history():
    """Every target sees 31 to 61 days back, is a target once, and its block holds every earlier row from its start."""
    df, data = _data(days=150, start="2024-10-01", n_accounts=25)
    account, secs = data["account"], data["secs"]
    blocks = rc.training_blocks(account, secs, np.random.default_rng(1))
    row, block, target = blocks["member_row"], blocks["member_block"], blocks["member_target"]
    targets = row[target]
    assert len(np.unique(targets)) == len(targets)                                  # a target once at most
    start = blocks["hist_start"]
    has = start != MISSING_SECOND
    assert set(targets) == set(np.flatnonzero(has))
    look = secs[has] - start[has]
    assert look.min() >= 31 * DAY and look.max() < 61 * DAY
    # Rows too early for the shortest history are never targets.
    assert not has[secs < secs.min() + 31 * DAY].any()
    for m in np.flatnonzero(target)[::40]:
        i = row[m]
        members = row[block == block[m]]
        seen = set(members[secs[members] < secs[i]])
        slow = set(np.flatnonzero((account == account[i]) & (secs >= start[i]) & (secs < secs[i])))
        assert seen == slow


def test_calendar_blocks_reach_back_to_the_previous_month():
    """On the read side every row is a target once, and its history starts on the first day of the previous month."""
    _, data = _data(n_accounts=15, seed=2)
    blocks = rc.calendar_blocks(data["account"], data["secs"])
    targets = blocks["member_row"][blocks["member_target"]]
    assert sorted(targets) == list(range(len(data["secs"])))
    assert np.array_equal(blocks["hist_start"], timekeys.month_start_seconds(data["secs"], 1))


def test_memory_equals_the_slow_definition():
    """Each faded mean is the decay-weighted mean of the account's vectors from the start to the previous second."""
    _, data = _data(n_accounts=12, seed=3)
    blocks = rc.calendar_blocks(data["account"], data["secs"])
    memory = rc.memory_features(data, blocks)
    dim, n_half = data["vectors"].shape[1], len(rc.HALF_LIVES)
    assert memory.shape == (len(data["secs"]), n_half * (dim + 1)) and np.isfinite(memory).all()
    account, secs, start = data["account"], data["secs"], blocks["hist_start"]
    for i in range(0, len(secs), 37):
        earlier = (account == account[i]) & (secs < secs[i]) & (secs >= start[i])
        for h, (_, half) in enumerate(rc.HALF_LIVES):
            weight = 0.5 ** ((secs[i] - secs[earlier]) / half)
            mean = (data["vectors"][earlier] * weight[:, None]).sum(0) / weight.sum() if weight.sum() > 1e-9 else 0.0
            assert np.allclose(memory[i, h * dim:(h + 1) * dim], mean, atol=1e-4)
            assert np.isclose(memory[i, n_half * dim + h], np.log1p(weight.sum()), atol=1e-4)


def _states(data, model, months_back=1):
    """The GRU state every row reads under calendar blocks, as float [rows, units + 2]."""
    layout = rc.sequence_layout(data, rc.calendar_blocks(data["account"], data["secs"], months_back))
    with torch.no_grad():
        targets, state = model.ordered_state(layout, np.arange(len(layout["block_start"])))
    out = np.full((len(data["secs"]), state.shape[1]), np.nan)
    out[layout["target_row"][targets]] = state.numpy()
    return out


def test_gru_state_equals_a_slow_run_over_the_earlier_rows():
    """The state of a row is the GRU run, step by step, over its block's rows of strictly earlier seconds."""
    _, data = _data(n_accounts=10, seed=4)
    torch.manual_seed(0)
    model = rc.Readout(4, hidden=8, gru_inputs=5, gru_units=6)
    states = _states(data, model)
    account, secs = data["account"], data["secs"]
    start = timekeys.month_start_seconds(secs, 1)
    month_end = timekeys.month_start_seconds(secs, -1)
    for i in range(0, len(secs), 23):
        # The block of row i: its account, from the previous month's first day to its own month's end,
        # in time order with ties kept in table order. The steps fed before row i are the earlier seconds.
        block = np.flatnonzero((account == account[i]) & (secs >= start[i]) & (secs < month_end[i]))
        block = block[np.argsort(secs[block], kind="stable")]
        gaps = np.diff(secs[block], prepend=secs[block][0]).astype(float)
        steps = np.column_stack([data["vectors"][block], np.log1p(gaps)])[secs[block] < secs[i]]
        if len(steps) == 0:
            assert np.allclose(states[i, :6], 0.0) and states[i, 7] == 0.0
            continue
        with torch.no_grad():
            out, _ = model.gru(torch.tensor(steps, dtype=torch.float32)[None])
        assert np.allclose(states[i, :6], out[0, -1].numpy(), atol=1e-5)
        last = secs[block][secs[block] < secs[i]].max()
        assert np.isclose(states[i, 6], np.log1p(secs[i] - last)) and states[i, 7] == 1.0


def test_same_second_rows_do_not_see_each_other_and_later_rows_change_nothing():
    """Rows of one second read one state whatever their vectors; dropping later rows leaves earlier states unchanged."""
    df, data = _data(n_accounts=12, seed=5)
    torch.manual_seed(1)
    model = rc.Readout(4, hidden=8, gru_inputs=5, gru_units=6)
    states = _states(data, model)
    keys = pd.DataFrame({"a": data["account"], "s": data["secs"]})
    groups = [g.to_numpy() for _, g in keys[keys.duplicated(keep=False)].groupby(["a", "s"]).groups.items()]
    assert len(groups) >= 2
    memory = rc.memory_features(data, rc.calendar_blocks(data["account"], data["secs"]))
    for tied in groups[:5]:
        # Change the vectors of the rows of one second only: their own states must not move, because
        # none of them may read another row of the same second.
        changed = dict(data, vectors=data["vectors"].copy())
        changed["vectors"][tied] += 5.0
        assert np.allclose(states[tied], _states(changed, model)[tied], atol=1e-6)
        assert np.allclose(states[tied], states[tied[0]], atol=1e-6)        # they all read the same state
        memory_changed = rc.memory_features(changed, rc.calendar_blocks(data["account"], data["secs"]))
        assert np.allclose(memory[tied], memory_changed[tied], atol=1e-5)
    # Later rows: keep the rows before a cut time and recompute.
    cut = np.quantile(data["secs"], 0.8)
    keep = data["secs"] < cut
    short = rc.prepare(df[keep].reset_index(drop=True), data["scale"])
    assert np.allclose(_states(short, model), states[keep], atol=1e-5)


def test_readout_shapes_gradients_and_the_zero_start_of_the_gru_projection():
    """Logits are finite, one per row; the GRU projection starts at zero, so the GRU changes nothing until trained."""
    torch.manual_seed(2)
    model = rc.Readout(10, hidden=8, gru_inputs=5, gru_units=6)
    x, ordered = torch.randn(7, 10), torch.randn(7, 8)
    plain = model(x)
    with_gru = model(x, ordered)
    assert with_gru.shape == (7,) and torch.isfinite(with_gru).all()
    assert torch.allclose(plain, with_gru)
    loss = torch.nn.functional.binary_cross_entropy_with_logits(with_gru, torch.tensor([0., 1, 0, 0, 1, 0, 0]))
    loss.backward()
    assert model.from_gru.weight.grad.abs().sum() > 0 and model.first.weight.grad.abs().sum() > 0
    # Once the projection has moved away from zero, the gradient reaches the GRU weights through the states.
    _, data = _data(n_accounts=8, seed=6)
    layout = rc.sequence_layout(data, rc.calendar_blocks(data["account"], data["secs"]))
    model = rc.Readout(4, hidden=8, gru_inputs=5, gru_units=6)
    with torch.no_grad():
        model.from_gru.weight.normal_()
    targets, state = model.ordered_state(layout, np.arange(len(layout["block_start"])))
    out = model(torch.from_numpy(data["vectors"][layout["target_row"][targets]]), state)
    out.sum().backward()
    assert out.shape == (len(targets),) and torch.isfinite(out).all()
    assert model.gru.weight_ih_l0.grad.abs().sum() > 0


def test_training_learns_a_plain_signal():
    """A vector that carries the label lets every readout rank frauds high on new accounts."""
    fit = _export(n_accounts=60, seed=7, days=92, start=settings.TRAIN_HISTORY_START, dim=3)
    read = _export(n_accounts=60, seed=8, dim=3)
    for df in (fit, read):
        df[f"{settings.VECTOR_PREFIX}0"] += 3.0 * df[settings.LABEL_COL]
    fit_data = rc.prepare(fit)
    read_data = rc.prepare(read, fit_data["scale"])
    for kind in rc.ARMS:
        model = rc.fit_readout(kind, fit_data, epochs=3, hidden=16, gru_units=8, row_batch=256, sequence_batch=16)
        scores = rc.score_readout(kind, model, read_data)
        assert np.isfinite(scores).all()
        assert ranking.average_precision(read_data["labels"], scores) > 0.3


def test_tool_runs_on_made_up_rows_and_on_files(tmp_path, capsys):
    """The tool prints the comparisons and the verdict, and writes the table to the given path."""
    rc.main(["--demo", "--accounts", "80", "--epochs", "1", "--draws", "50"])
    printed = capsys.readouterr().out
    assert "c_gru" in printed and "recurrent block" in printed
    fit = _export(n_accounts=40, seed=9, days=92, start=settings.TRAIN_HISTORY_START)
    read = _export(n_accounts=40, seed=10)
    fit_path = tables.write_table(fit, str(tmp_path / "fit.parquet"))
    read_path = tables.write_table(read.drop(columns=[settings.SCORE_COL]), str(tmp_path / "read.parquet"))
    out = str(tmp_path / "readouts.parquet")
    table = rc.main(["--fit", fit_path, "--read", read_path, "--epochs", "1", "--draws", "50", "--out", out])
    assert "skipped" in capsys.readouterr().out
    written = tables.read_columns(out)
    assert list(written["arm"]) == ["b_memory", "c_gru", "c_gru"] and list(written.columns) == list(table.columns)
