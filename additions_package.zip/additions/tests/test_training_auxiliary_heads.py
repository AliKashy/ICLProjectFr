"""Tests of the auxiliary targets, heads and the capped total loss.

Every target column is compared with a slow loop over the rows of each account. The
run-state targets are checked against the time rule (rows of the same second and later rows
never count), the forward targets for the rows near the end of the data that must get no
target, and the capped total for its bound and for its gradients.
"""
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

from additions import settings
from additions.common import synthetic, tables, timekeys
from additions.training import auxiliary_heads
from additions.training.auxiliary_heads import (NEXT_WINDOWS, PREVIOUS_WINDOWS, TARGET_NAMES, TARGET_PREFIX,
                                                AuxiliaryHeads, auxiliary_losses, build_targets, capped_total,
                                                head_columns)


def _table(seed=0, n_accounts=50):
    """Made-up rows with many fraud runs and many same-second ties, shuffled so that row order means nothing."""
    df = synthetic.make_transactions(n_accounts=n_accounts, seed=seed, fraud_account_share=0.5, tie_share=0.2)
    return df.sample(frac=1.0, random_state=seed)


def _slow_window_targets(df, window, forward):
    """Per row, with a plain loop: is a fraud labelled on the account in [t - w, t) (or in (t, t + w])?"""
    secs = timekeys.seconds(df[settings.TIME_COL])
    account = df[settings.ACCOUNT_COL].to_numpy()
    fraud = df[settings.LABEL_COL].to_numpy() == settings.POSITIVE_LABEL
    out = np.zeros(len(df))
    for a in np.unique(account):
        rows = np.flatnonzero(account == a)
        for i in rows:
            others = secs[rows]
            if forward:
                inside = (others > secs[i]) & (others <= secs[i] + window)
            else:
                inside = (others < secs[i]) & (others >= secs[i] - window)
            out[i] = float((fraud[rows] & inside).any())
    return out, secs


def test_run_state_targets_equal_the_slow_loop_and_are_missing_near_the_start():
    """fraud_prev_<w> is 1 when a strictly earlier row of the account within w was fraud; missing before the data."""
    df = _table()
    targets = build_targets(df)
    assert list(targets.index) == list(df.index)
    for label, window in PREVIOUS_WINDOWS:
        slow, secs = _slow_window_targets(df, window, forward=False)
        got = targets[f"{TARGET_PREFIX}fraud_prev_{label}"].to_numpy()
        too_early = secs - window < secs.min()
        assert np.isnan(got[too_early]).all() and not np.isnan(got[~too_early]).any()
        assert np.array_equal(got[~too_early], slow[~too_early])
        assert got[~too_early].sum() > 0


def test_forward_targets_equal_the_slow_loop_and_are_missing_near_the_end():
    """fraud_next_<w> is 1 when a strictly later row within w is fraud; rows closer than w to the end get no target."""
    df = _table(seed=1)
    targets = build_targets(df)
    for label, window in NEXT_WINDOWS:
        slow, secs = _slow_window_targets(df, window, forward=True)
        got = targets[f"{TARGET_PREFIX}fraud_next_{label}"].to_numpy()
        too_late = secs + window > secs.max()
        assert np.isnan(got[too_late]).all() and not np.isnan(got[~too_late]).any()
        assert np.array_equal(got[~too_late], slow[~too_late])
        assert got[~too_late].sum() > 0
    # An earlier end of the data, given by the caller, takes more rows out.
    secs = timekeys.seconds(df[settings.TIME_COL])
    end = int(secs.max()) - 10 * 86_400
    cut = build_targets(df, data_end=end)[f"{TARGET_PREFIX}fraud_next_24h"].to_numpy()
    assert np.array_equal(np.isnan(cut), secs + 86_400 >= end)
    # Without fraud rows the forward target is about the rows before a run only.
    fraud = df[settings.LABEL_COL].to_numpy() == settings.POSITIVE_LABEL
    quiet = build_targets(df, next_on_fraud_rows=False)[f"{TARGET_PREFIX}fraud_next_7d"].to_numpy()
    assert np.isnan(quiet[fraud]).all()
    full = targets[f"{TARGET_PREFIX}fraud_next_7d"].to_numpy()
    assert np.array_equal(quiet[~fraud], full[~fraud], equal_nan=True)


def test_rows_of_the_same_second_never_count_for_each_other():
    """A fraud in the row's own second is invisible to both kinds of target; one second earlier or later it counts."""
    t0 = pd.Timestamp("2025-05-20 12:00:00")
    times = [t0 - pd.Timedelta(days=9), t0, t0, t0 + pd.Timedelta(seconds=1), t0 + pd.Timedelta(days=9)]
    df = pd.DataFrame({settings.ACCOUNT_COL: ["a"] * 5, settings.TIME_COL: times,
                       settings.LABEL_COL: [0, 1, 0, 0, 0],
                       settings.REASON_COL: [settings.APPROVED_REASONS[0]] * 5, settings.ADVICE_COL: [None] * 5})
    targets = build_targets(df)
    prev, nxt = targets[f"{TARGET_PREFIX}fraud_prev_1h"], targets[f"{TARGET_PREFIX}fraud_next_24h"]
    assert prev[2] == 0.0 and prev[3] == 1.0                               # same second: no; next second: yes
    assert prev[1] == 0.0                                                  # a row's own label never counts
    assert nxt[2] == 0.0 and nxt[1] == 0.0                                 # neither forward
    # A fraud in the same second as the reading row, moved one second earlier, is seen by it.
    moved = df.copy()
    moved.loc[1, settings.TIME_COL] = t0 - pd.Timedelta(seconds=1)
    assert build_targets(moved)[f"{TARGET_PREFIX}fraud_prev_1h"][2] == 1.0
    assert build_targets(moved)[f"{TARGET_PREFIX}fraud_next_24h"][2] == 0.0


def test_later_rows_do_not_change_the_run_state_targets():
    """Dropping every row after a cut leaves the fraud_prev targets of the rows before it unchanged."""
    df = _table(seed=2)
    secs = timekeys.seconds(df[settings.TIME_COL])
    cut = int(np.quantile(secs, 0.6))
    full = build_targets(df)
    early = df[secs < cut]
    part = build_targets(early, data_start=int(secs.min()))
    columns = [f"{TARGET_PREFIX}fraud_prev_{label}" for label, _ in PREVIOUS_WINDOWS]
    pd.testing.assert_frame_equal(part[columns], full.loc[early.index, columns])


def test_risk_decline_target_and_the_optional_columns():
    """1 on risk-decline codes, 0 on other decisions, missing on advice rows and rows without a code."""
    df = _table(seed=3, n_accounts=40)
    df.loc[df.index[::31], settings.REASON_COL] = None
    targets = build_targets(df)
    got = targets[f"{TARGET_PREFIX}risk_decline"].to_numpy()
    reason = df[settings.REASON_COL]
    no_target = reason.isna().to_numpy() | df[settings.ADVICE_COL].notna().to_numpy()
    assert np.isnan(got[no_target]).all() and not np.isnan(got[~no_target]).any()
    slow = reason.isin(settings.RISK_DECLINE_REASONS).to_numpy().astype(float)
    assert np.array_equal(got[~no_target], slow[~no_target]) and got[~no_target].sum() > 0
    # Without a response-code column the target is skipped and the rest is still built.
    skipped = build_targets(df.drop(columns=[settings.REASON_COL]))
    assert f"{TARGET_PREFIX}risk_decline" not in skipped.columns and skipped.shape[1] == len(TARGET_NAMES) - 1
    assert build_targets(df, reason_col=False).shape[1] == len(TARGET_NAMES) - 1
    # Without an advice column advice rows keep a target.
    kept = build_targets(df.drop(columns=[settings.ADVICE_COL]))[f"{TARGET_PREFIX}risk_decline"].to_numpy()
    assert np.array_equal(np.isnan(kept), reason.isna().to_numpy())


def test_heads_shapes_gradients_and_the_masked_loss():
    """One [B, T] output per target; the loss of a head is the cross-entropy over the rows with a target only."""
    generator = torch.Generator().manual_seed(4)
    vectors = torch.randn(5, 7, 16, generator=generator, requires_grad=True)
    heads = AuxiliaryHeads(dim=16)
    out = heads(vectors)
    assert list(out) == list(TARGET_NAMES) and all(v.shape == (5, 7) for v in out.values())
    targets = {name: (torch.rand(5, 7, generator=generator) < 0.3).float() for name in TARGET_NAMES}
    for name in TARGET_NAMES:
        targets[name][torch.rand(5, 7, generator=generator) < 0.4] = float("nan")
    targets["risk_decline"][:] = float("nan")                              # a head with no target in this batch
    del targets["fraud_next_7d"]                                           # a head without a target entry is skipped
    losses = auxiliary_losses(out, targets)
    assert set(losses) == set(TARGET_NAMES) - {"fraud_next_7d"}
    for name, loss in losses.items():
        has = torch.isfinite(targets[name])
        if has.any():
            slow = F.binary_cross_entropy_with_logits(out[name][has], targets[name][has])
            assert torch.isclose(loss, slow, atol=1e-6)
    assert losses["risk_decline"].item() == 0.0
    total = capped_total(torch.tensor(0.5, requires_grad=True), losses)
    total.backward()
    assert torch.isfinite(vectors.grad).all() and vectors.grad.abs().sum() > 0
    for name, head in heads.heads.items():
        if name not in losses:
            assert head.weight.grad is None                                # a skipped head is not in the graph
            continue
        assert torch.isfinite(head.weight.grad).all()
        assert (head.weight.grad.abs().sum() > 0) == (name != "risk_decline")


def test_capped_total_bounds_every_term_and_its_scales_carry_no_gradient():
    """main + mean(min(aux, main)); no scaled term exceeds the main loss; d total / d aux_k is the fixed scale / K."""
    main = torch.tensor(0.2, dtype=torch.float64, requires_grad=True)
    raw = [0.05, 0.2, 0.9, 3.0]
    aux = [torch.tensor(v, dtype=torch.float64, requires_grad=True) for v in raw]
    total = capped_total(main, aux)
    scaled = [min(v, 0.2) for v in raw]
    assert all(s <= main.item() + 1e-12 for s in scaled)
    assert np.isclose(total.item(), 0.2 + np.mean(scaled))
    total.backward()
    assert main.grad.item() == 1.0                                         # the cap's ratio passes no gradient back
    for value, tensor in zip(raw, aux):
        assert np.isclose(tensor.grad.item(), min(1.0, 0.2 / value) / len(raw))
    # The same with a dict and a weight; an empty set of side losses leaves the main loss alone.
    named = {f"h{k}": torch.tensor(v, dtype=torch.float64) for k, v in enumerate(raw)}
    assert np.isclose(capped_total(main, named, weight=0.3).item(), 0.2 + 0.3 * np.mean(scaled))
    assert capped_total(main, {}) is main
    # However large the side losses get, their part of the total never exceeds the main loss.
    rng = np.random.default_rng(5)
    for _ in range(50):
        m = torch.tensor(rng.uniform(0.01, 2.0))
        side = [torch.tensor(v) for v in rng.uniform(0.0, 50.0, size=rng.integers(1, 6))]
        assert (capped_total(m, side) - m).item() <= m.item() + 1e-9


def test_head_columns_hold_probabilities_and_the_risk_if_approved_column():
    """Probabilities per head, and fraud log-odds plus log(1 / (1 - p_decline)) for risk_if_approved."""
    generator = torch.Generator().manual_seed(6)
    logits = {name: torch.randn(30, generator=generator) for name in TARGET_NAMES}
    fraud = torch.randn(30, generator=generator)
    columns = head_columns(logits, fraud)
    for name in TARGET_NAMES:
        assert np.allclose(columns["aux_" + name], torch.sigmoid(logits[name]).numpy())
    p_decline = torch.sigmoid(logits["risk_decline"]).double()
    assert np.allclose(columns["aux_risk_if_approved"], (fraud.double() - torch.log(1 - p_decline)).numpy(), atol=1e-5)
    assert "aux_risk_if_approved" not in head_columns(logits)


def test_command_line_prints_and_writes_only_with_an_out_path(capsys):
    """The demo prints one line per target; with --out it writes the columns next to the transaction id."""
    targets = auxiliary_heads.main(["--demo"])
    printed = capsys.readouterr().out
    assert all(TARGET_PREFIX + name in printed for name in TARGET_NAMES)
    with tempfile.TemporaryDirectory() as folder:
        path = str(Path(folder) / "targets.parquet")
        auxiliary_heads.main(["--demo", "--out", path])
        auxiliary_heads.main(["--demo", "--out", path])                    # an existing file is overwritten
        written = tables.read_columns(path)
    assert list(written.columns) == [settings.ID_COL] + list(targets.columns) and len(written) == len(targets)
