"""Tests of the two-score margin and of the three arms built on it.

The made-up rows have three independent sources of fraud signal: one only the other model
sees, one only this model sees, and one that only a bundle column carries. Each step of the
set-up should then pay: the blend over the other model alone, the bundle over the blend.
"""
import numpy as np
import pandas as pd
import pytest
from scipy.special import expit

from additions import settings
from additions.common import ranking, tables
from additions.exports import _shared, consumer_margin

OTHER = consumer_margin.OTHER_SCORE_COL


def _made_up(n, seed):
    """Rows with two scores and two bundle columns: `dir_1` carries a third signal, `w_rows_30d` carries none."""
    rng = np.random.default_rng(seed)
    seen_by_other, seen_by_ours, seen_by_bundle = rng.normal(size=(3, n))
    y = rng.random(n) < expit(-8.0 + 1.5 * (seen_by_other + seen_by_ours + seen_by_bundle))
    start = pd.Timestamp(settings.TARGET_START)
    return pd.DataFrame({
        settings.ID_COL: np.arange(n) + seed * 1_000_000,
        settings.ACCOUNT_COL: rng.integers(0, n // 8, n) + seed * 1_000_000,
        settings.TIME_COL: start + pd.to_timedelta(rng.integers(0, 25 * 86_400, n), unit="s"),
        settings.LABEL_COL: y.astype(int),
        settings.AMOUNT_COL: np.round(rng.lognormal(3.0, 1.0, n), 2),
        settings.SCORE_COL: expit(-8.0 + 1.5 * seen_by_ours),
        OTHER: expit(-8.0 + 1.5 * seen_by_other),
        "dir_1": seen_by_bundle + 0.3 * rng.normal(size=n),
        "w_rows_30d": rng.integers(0, 40, n).astype(float),
    })


@pytest.fixture(scope="module")
def pair():
    """A fit table and a read table of other accounts."""
    return _made_up(30_000, seed=1), _made_up(30_000, seed=2)


@pytest.fixture(scope="module")
def result(pair):
    """The three arms fitted on the first table and read on the second."""
    return consumer_margin.run_arms(*pair, rounds=40, draws=40)


def test_blend_is_the_best_weighting_of_the_two_logits(pair):
    """At the fitted a, b and c the fitted probabilities match the labels on average and along both scores."""
    fit_table, _ = pair
    y = _shared.fraud_flags(fit_table)
    other, own = consumer_margin.other_logits(fit_table), _shared.logits(fit_table)
    blend = consumer_margin.fit_blend(y, other, own)
    miss = y - expit(consumer_margin.blend_margin(blend, other, own))
    assert abs(miss.sum()) < 1e-4 and abs(miss @ other) < 1e-3 and abs(miss @ own) < 1e-3
    assert blend["a"] > 0.5 and blend["b"] > 0.5                              # both scores carry signal of their own
    alone = consumer_margin.fit_blend(y, other)
    assert alone["b"] == 0.0 and alone["a"] > 0
    miss = y - expit(consumer_margin.blend_margin(alone, other, 0.0))
    assert abs(miss.sum()) < 1e-4 and abs(miss @ other) < 1e-3
    # Without any fraud nothing can be fitted: the scores are simply added, and nothing stops.
    assert consumer_margin.fit_blend(np.zeros(len(y)), other, own) == {"a": 1.0, "b": 1.0, "c": 0.0}


def test_each_step_of_the_set_up_pays_on_other_accounts(result):
    """The blend beats the other model alone and the bundle column adds to the blend, by capture and by precision."""
    table = result["table"].set_index("read")
    assert list(table.index) == list(consumer_margin.ARMS)
    assert table.loc["blend", "udr"] > table.loc["other", "udr"] + 0.03
    assert table.loc["blend + bundle", "udr"] > table.loc["blend", "udr"] + 0.03
    assert table.loc["blend", "ap"] > table.loc["other", "ap"] + 0.03
    assert table.loc["blend + bundle", "ap"] > table.loc["blend", "ap"] + 0.03
    assert all(np.isfinite(scores).all() for scores in result["scores"].values())


def test_arms_without_trees_are_their_margins(pair, result):
    """With no tree columns, or no trees, an arm is exactly its margin: the other model's ranking, or the blend."""
    fit_table, read_table = pair
    other, own = consumer_margin.other_logits(read_table), _shared.logits(read_table)
    blend = result["blend"]
    assert np.allclose(result["scores"]["blend"], blend["a"] * other + blend["b"] * own + blend["c"])
    order = np.argsort(other, kind="stable")
    assert (np.diff(result["scores"]["other"][order]) >= 0).all()             # same ranking as the other model
    off, _ = consumer_margin.arm_scores(fit_table, read_table, ["dir_1", "w_rows_30d"], rounds=0)
    assert np.array_equal(off["blend + bundle"], off["blend"])
    none, _ = consumer_margin.arm_scores(fit_table, read_table, [])
    assert np.array_equal(none["blend + bundle"], none["blend"])
    # The consumer's own columns go to the trees of every arm, so every arm moves away from its margin.
    based, _ = consumer_margin.arm_scores(fit_table, read_table, ["dir_1"], base_columns=["w_rows_30d"], rounds=5)
    assert not np.allclose(based["other"], off["other"]) and not np.allclose(based["blend"], off["blend"])


def test_swap_table_counts_what_moved_across_the_cut(pair, result):
    """Frauds that moved in and out equal the difference of the two alert sets, and rows in equal rows out."""
    _, read_table = pair
    y = _shared.fraud_flags(read_table)
    amount = read_table[settings.AMOUNT_COL].to_numpy()
    old, new = result["scores"]["other"], result["scores"]["blend + bundle"]
    k = ranking.cut_size(len(y))
    top_old, top_new = set(np.argsort(-old, kind="stable")[:k]), set(np.argsort(-new, kind="stable")[:k])
    swap = consumer_margin.swap_table(y, old, new, amount).set_index("rows")
    came, went = sorted(top_new - top_old), sorted(top_old - top_new)
    assert swap.loc["frauds", "moved_in"] == y[came].sum() and swap.loc["frauds", "moved_out"] == y[went].sum()
    assert swap.loc["frauds", "in_both"] == y[sorted(top_new & top_old)].sum()
    assert np.isclose(swap.loc["fraud dollars", "moved_in"], (y * amount)[came].sum())
    assert swap.loc["frauds", "net"] == y[sorted(top_new)].sum() - y[sorted(top_old)].sum() > 0
    moved_in = swap.loc["frauds", "moved_in"] + swap.loc["other rows", "moved_in"]
    assert moved_in == swap.loc["frauds", "moved_out"] + swap.loc["other rows", "moved_out"] == len(came)
    same = consumer_margin.swap_table(y, old, old)
    assert (same["moved_in"] == 0).all() and (same["net"] == 0).all() and list(same["rows"]) == ["frauds", "other rows"]
    # The result holds one swap table per compared pair of arms.
    pairs = set(zip(result["swaps"]["candidate"], result["swaps"]["control"]))
    assert pairs == set(consumer_margin.PAIRS) and len(result["swaps"]) == 9


def test_bootstrap_lines_agree_with_the_table_and_are_paired_over_accounts(pair, result):
    """Each line holds the capture of both arms, their difference and an interval around it."""
    _, read_table = pair
    table = result["table"].set_index("read")
    boot = result["bootstrap"]
    assert len(boot) == 6 and set(boot["measure"]) == {"udr", "vdr"}
    for line in boot.to_dict("records"):
        assert np.isclose(line["candidate_capture"], table.loc[line["candidate"], line["measure"]])
        assert np.isclose(line["control_capture"], table.loc[line["control"], line["measure"]])
        assert np.isclose(line["gain"], line["candidate_capture"] - line["control_capture"])
        assert line["low"] <= line["high"] and line["draws"] == 40
    first = boot[(boot["candidate"] == "blend") & (boot["measure"] == "udr")].iloc[0]
    assert first["low"] > 0                                                    # the made-up gain is far from noise


def test_rows_without_both_scores_are_left_out(pair, capsys):
    """A row that lacks one of the two scores is dropped with a printed line instead of stopping the run."""
    fit_table, read_table = pair
    read_table = read_table.copy()
    read_table.loc[read_table.index[:25], OTHER] = np.nan
    out = consumer_margin.run_arms(fit_table, read_table, rounds=3, draws=5)
    assert len(out["read"]) == len(read_table) - 25 and len(out["scores"]["blend"]) == len(read_table) - 25
    assert "25 of 30000 read rows lack one of the two scores" in capsys.readouterr().out
    assert consumer_margin.default_bundle_columns(fit_table, read_table) == ["dir_1", "w_rows_30d"]


def test_tool_prints_the_three_tables_and_writes_the_arm_scores(pair, tmp_path, capsys):
    """The tool reads two files, ranks the scored month, prints margin, arms, swaps and bootstrap, and writes on request."""
    fit_table, read_table = pair
    fit_path = tables.write_table(fit_table, str(tmp_path / "fit.parquet"))
    read_path = tables.write_table(read_table, str(tmp_path / "read.parquet"))
    out_path = str(tmp_path / "arms.parquet")
    result = consumer_margin.main(["--fit", fit_path, "--read", read_path, "--rounds", "10", "--draws", "10",
                                   "--out", out_path])
    printed = capsys.readouterr().out
    for text in ("base margin =", "Arms on the read rows", "Swap table at the cut", "Paired bootstrap over accounts"):
        assert text in printed
    written = tables.read_columns(out_path)
    assert len(written) == len(read_table)
    assert {"arm_other", "arm_blend", "arm_blend_bundle", settings.ID_COL} <= set(written.columns)
    assert np.allclose(written["arm_blend_bundle"], result["scores"]["blend + bundle"])
    assert consumer_margin.main(["--fit", fit_path, "--read", read_path, "--start", "2031-01-01",
                                 "--end", "2031-02-01"]) is None
    assert "no row of the read table falls in the scored month" in capsys.readouterr().out


def test_demo_runs_end_to_end_on_made_up_files(capsys):
    """The demo builds a bundle on a third block, joins it, and reads the three arms."""
    result = consumer_margin.main(["--demo", "--rounds", "10", "--draws", "10"])
    assert len(result["table"]) == 3 and "blend + bundle" in capsys.readouterr().out
    fit_table, read_table = consumer_margin.demo_tables(n_accounts=40)
    assert set(fit_table[settings.ACCOUNT_COL]).isdisjoint(read_table[settings.ACCOUNT_COL])
    assert len(consumer_margin.default_bundle_columns(fit_table, read_table)) >= 20
