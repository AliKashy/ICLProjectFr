"""Tests of the merchant context of other accounts (additions/model/merchant_context.py).

The listed rows must be exactly the last rows of other accounts at the merchant in strictly
earlier seconds, the gathered facts must belong to them, and the pooling block must ignore
empty places, fall back to its learned vector and pass gradients.
"""
import numpy as np
import torch

from additions import settings
from additions.common import ranking, synthetic, timekeys
from additions.model.merchant_context import (MerchantContext, context_index, gather_context, last_other_rows)

D, C, HEADS = 5, 16, 4


def _slow_last_other_rows(merchants, accounts, secs, n_last, min_age=1, max_age=None):
    """For every row, a plain scan of all rows: same merchant, other account, old enough, latest first."""
    out = np.full((len(secs), n_last), -1, dtype=np.int64)
    for r in range(len(secs)):
        if merchants[r] < 0:
            continue
        found = [q for q in range(len(secs))
                 if merchants[q] == merchants[r] and accounts[q] != accounts[r]
                 and secs[r] - secs[q] >= min_age and (max_age is None or secs[r] - secs[q] <= max_age)]
        # Latest first; among rows of one second the later position in the merchant's sorted order comes first,
        # which is the original row order because the sort is stable.
        found.sort(key=lambda q: (secs[q], q), reverse=True)
        out[r, :len(found[:n_last])] = found[:n_last]
    return out


def _crowded(seed=0, n=300):
    """Many rows on few merchants and few accounts, with many shared seconds: the hard case for the index."""
    rng = np.random.default_rng(seed)
    merchants = rng.integers(0, 4, n)
    merchants[rng.random(n) < 0.05] = -1                             # some rows without a merchant
    accounts = rng.integers(0, 5, n)
    secs = rng.integers(0, 60, n).astype(np.int64)
    return merchants, accounts, secs


def _as_sets(index):
    """Each row's listed rows as a set, so that ties inside one second do not depend on the order chosen."""
    return [set(r[r >= 0].tolist()) for r in index]


def test_the_index_equals_a_slow_scan():
    """The listed rows equal a plain scan for several sizes, ages and look-back limits."""
    merchants, accounts, secs = _crowded()
    for n_last, min_age, max_age in [(4, None, None), (16, None, None), (3, 5, None), (6, 1, 20), (50, 2, 30)]:
        fast = last_other_rows(merchants, accounts, secs, n_last=n_last, min_age=min_age, max_age=max_age)
        slow = _slow_last_other_rows(merchants, accounts, secs, n_last, min_age or 1, max_age)
        assert fast.shape == (len(secs), n_last)
        # The same number of rows, the same seconds in the same order, and the same set of rows.
        assert np.array_equal(fast >= 0, slow >= 0)
        assert np.array_equal(np.where(fast >= 0, secs[np.maximum(fast, 0)], -1),
                              np.where(slow >= 0, secs[np.maximum(slow, 0)], -1))
        # Rows of the oldest second that is kept may be chosen differently when that second is cut in two.
        full = (slow >= 0).sum(axis=1) < n_last
        assert [a for a, f in zip(_as_sets(fast), full) if f] == [b for b, f in zip(_as_sets(slow), full) if f]


def test_no_listed_row_is_from_the_own_account_or_not_strictly_earlier():
    """Every listed row is at the same merchant, on another account, and in a strictly earlier second."""
    merchants, accounts, secs = _crowded(seed=1)
    index = last_other_rows(merchants, accounts, secs, n_last=8)
    rows, slots = np.nonzero(index >= 0)
    listed = index[rows, slots]
    assert len(listed) > 0
    assert np.all(merchants[listed] == merchants[rows])
    assert np.all(accounts[listed] != accounts[rows])
    assert np.all(secs[listed] < secs[rows])
    assert np.all(index[merchants < 0] == -1)                       # no merchant: nothing listed
    assert not np.isin(np.flatnonzero(merchants < 0), listed).any()  # and listed by nobody
    # Latest first along each row.
    ages = np.where(index >= 0, secs[np.maximum(index, 0)], -1)
    assert np.all(np.diff(ages, axis=1) <= 0)


def test_later_rows_do_not_change_what_earlier_rows_list():
    """Adding rows in a later second leaves the lists of every earlier row unchanged."""
    merchants, accounts, secs = _crowded(seed=2)
    before = last_other_rows(merchants, accounts, secs, n_last=6)
    extra = 40
    rng = np.random.default_rng(9)
    m2 = np.r_[merchants, rng.integers(0, 4, extra)]
    a2 = np.r_[accounts, rng.integers(0, 5, extra)]
    s2 = np.r_[secs, np.full(extra, secs.max() + 1)]
    after = last_other_rows(m2, a2, s2, n_last=6)
    assert np.array_equal(after[:len(secs)], before)


def test_context_index_reads_the_columns_and_skips_a_missing_merchant(capsys):
    """The table version agrees with the array version, and without a merchant column every row lists nothing."""
    df = synthetic.make_transactions(40, days=10, seed=3)
    index = context_index(df, n_last=5)
    merchants = timekeys.codes(df[settings.MERCHANT_COL])
    accounts = timekeys.codes(df[settings.ACCOUNT_COL])
    secs = timekeys.seconds(df[settings.TIME_COL])
    assert np.array_equal(index, last_other_rows(merchants, accounts, secs, n_last=5))
    assert (index >= 0).any()
    none = context_index(df.drop(columns=[settings.MERCHANT_COL]), n_last=5)
    assert none.shape == (len(df), 5) and np.all(none == -1)
    assert "merchant" in capsys.readouterr().out


def test_gather_context_takes_the_facts_of_the_listed_rows():
    """Vectors, log-odds scores and ages belong to the listed rows; padding and empty places hold zeros."""
    merchants, accounts, secs = _crowded(seed=4, n=80)
    index = last_other_rows(merchants, accounts, secs, n_last=4)
    vectors = np.random.default_rng(0).normal(size=(80, D))
    scores = np.random.default_rng(1).uniform(0.01, 0.99, 80)
    rows = np.array([[5, 17, 60], [33, -1, -1]])
    ctx = gather_context(index, vectors, scores, secs, rows=rows, score_kind="probability")
    assert ctx["vectors"].shape == (2, 3, 4, D) and ctx["present"].shape == (2, 3, 4)
    for b in range(2):
        for t in range(3):
            r = rows[b, t]
            for k in range(4):
                q = index[r, k] if r >= 0 else -1
                assert ctx["present"][b, t, k] == (q >= 0)
                if q >= 0:
                    assert np.allclose(ctx["vectors"][b, t, k], vectors[q], atol=1e-6)
                    assert np.isclose(ctx["scores"][b, t, k], ranking.to_logit(scores[q], "probability"), atol=1e-5)
                    assert ctx["ages"][b, t, k] == secs[r] - secs[q] and secs[r] - secs[q] >= 1
                else:
                    assert np.all(ctx["vectors"][b, t, k] == 0) and ctx["scores"][b, t, k] == 0


def _inputs(B=3, T=4, N=6, seed=0):
    """Random gathered facts with some empty places and one row with nothing at all."""
    g = torch.Generator().manual_seed(seed)
    present = torch.rand(B, T, N, generator=g) < 0.6
    present[0, 0] = False                                           # a row with no context
    present[1, 1] = True
    return (torch.randn(B, T, N, D, generator=g), torch.randn(B, T, N, generator=g),
            torch.rand(B, T, N, generator=g) * 1_000, present)


def test_the_block_falls_back_to_its_learned_vector_and_ignores_empty_places():
    """No context gives the learned vector; changing an empty place or the order of the places changes nothing."""
    torch.manual_seed(0)
    block = MerchantContext(vector_dim=D, context_dim=C, num_heads=HEADS, dropout=0.0).eval()
    vectors, scores, ages, present = _inputs()
    out = block(vectors, scores, ages, present)
    assert out.shape == (3, 4, C) and torch.isfinite(out).all()
    assert torch.equal(out[0, 0], block.no_context.detach())
    # Whatever sits in an empty place has no influence.
    noisy = vectors.clone()
    noisy[~present] = 1e3
    assert torch.allclose(block(noisy, scores, ages, present), out, atol=1e-5)
    # The order of the places does not matter: the age is an input, not a position.
    perm = torch.randperm(present.shape[-1])
    shuffled = block(vectors[..., perm, :], scores[..., perm], ages[..., perm], present[..., perm])
    assert torch.allclose(shuffled, out, atol=1e-5)


def test_gradients_reach_every_weight_of_the_block():
    """A loss on the context gives every weight a finite, non-zero gradient, the fallback vector included."""
    torch.manual_seed(1)
    block = MerchantContext(vector_dim=D, context_dim=C, num_heads=HEADS, dropout=0.0)
    vectors, scores, ages, present = _inputs(seed=1)
    out = block(vectors, scores, ages, present)
    (out * torch.randn(out.shape)).sum().backward()
    for name, p in block.named_parameters():
        assert p.grad is not None and torch.isfinite(p.grad).all(), name
        assert p.grad.abs().sum() > 0, name


def test_the_table_flow_runs_end_to_end():
    """Index, gather and pool on made-up rows give one finite context vector per slot of a batch."""
    df = synthetic.make_scores(synthetic.make_transactions(30, days=8, seed=5))
    index = context_index(df, n_last=4)
    vectors = np.random.default_rng(0).normal(size=(len(df), D))
    secs = timekeys.seconds(df[settings.TIME_COL])
    rows = np.arange(len(df))[:40].reshape(4, 10)
    ctx = gather_context(index, vectors, df[settings.SCORE_COL].to_numpy(), secs, rows=rows)
    block = MerchantContext(vector_dim=D, context_dim=C, num_heads=HEADS)
    out = block(*(torch.as_tensor(ctx[k]) for k in ("vectors", "scores", "ages", "present")))
    assert out.shape == (4, 10, C) and torch.isfinite(out).all()
