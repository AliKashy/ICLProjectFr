"""Tests of the tree second stage and the top-band specialist.

The band ranking is compared with a plain sort, a specialist that agrees with the network is
shown to leave the ranking unchanged, and the arms are run end to end on made-up exports:
the band floor is a fixed number, the specialist is fitted only on band rows, rows below the
band keep the network's order, and the tool writes its tables.
"""
import numpy as np
import pytest

from additions import settings
from additions.after_model import _shared, score_state, second_stage
from additions.common import ranking, synthetic, tables


def _plain_order(base, band_score, in_band):
    """Row positions from the top of the ranking down: band rows by band score first, then the rest by base."""
    key = np.where(in_band, band_score, base)
    return np.lexsort((-key, ~in_band))          # the last key sorts first: band rows, then by the score


def test_band_order_matches_a_plain_sort():
    """The band ranking puts band rows on top in specialist order and keeps every other row's base value."""
    rng = np.random.default_rng(0)
    base = rng.normal(size=2_000)
    floor = np.quantile(base, 0.95)
    in_band = base >= floor
    special = rng.normal(size=2_000)
    got = second_stage.band_order(base, special, in_band)
    assert np.array_equal(got[~in_band], base[~in_band])
    assert got[in_band].min() > got[~in_band].max()
    assert np.array_equal(np.argsort(-got, kind="stable"), _plain_order(base, special, in_band))
    # Equal specialist scores stay equal: the band is shifted, never rescaled.
    special[np.flatnonzero(in_band)[:2]] = 0.25
    tied = second_stage.band_order(base, special, in_band)[np.flatnonzero(in_band)[:2]]
    assert tied[0] == tied[1]


def test_a_specialist_that_agrees_with_the_network_changes_nothing():
    """When the band score orders the band like the network, both band arms rank exactly like the network."""
    df = synthetic.make_scores(synthetic.make_transactions(n_accounts=300, seed=1, fraud_account_share=0.2), seed=1)
    y, logit = _shared.fraud_flags(df), _shared.logits(df)
    in_band = logit >= _shared.cut_value(logit, per_mille=50)
    for ranked in (second_stage.band_order(logit, 3.0 * logit - 1.0, in_band),
                   second_stage.averaged_band(logit, logit, in_band)):
        assert np.array_equal(np.argsort(-ranked, kind="stable"), np.argsort(-logit, kind="stable"))
        assert ranking.capture(y, ranked)["caught"] == ranking.capture(y, logit)["caught"]
    # With no band row at all the ranking is the base logit itself.
    assert np.array_equal(second_stage.band_order(logit, -logit, np.zeros(len(df), bool)), logit)


def test_inputs_hold_the_score_state_only_when_asked(capsys):
    """The inputs are the base columns plus the score state; switched off, the state is absent and a line says so."""
    fit = _shared.demo_export(n_accounts=60, seed=2, dim=3)
    read = _shared.demo_export(n_accounts=40, seed=3, dim=3)
    cut = _shared.cut_value(_shared.logits(fit))
    x_fit, x_read, names = second_stage.stage_inputs(fit, read, cut)
    base_fit, _, base_names = _shared.base_inputs(fit, read)
    state = score_state.build_score_state(read, cut)
    assert names == base_names + list(state.columns) and x_fit.shape == (len(fit), len(names))
    assert x_read.shape == (len(read), len(names)) and x_fit.dtype == np.float32
    assert np.array_equal(x_fit[:, :len(base_names)], base_fit, equal_nan=True)
    assert np.array_equal(x_read[:, len(base_names):], state.to_numpy(), equal_nan=True)
    capsys.readouterr()
    _, _, bare = second_stage.stage_inputs(fit, read, cut, with_state=False)
    assert bare == base_names and "switched off" in capsys.readouterr().out


@pytest.fixture(scope="module")
def result():
    """The arms fitted on one made-up export and read on another, with few trees and draws, one thread per fit."""
    fit = _shared.demo_export(n_accounts=400, seed=11, days=92, start=settings.TRAIN_HISTORY_START,
                              fraud_account_share=0.3, dim=4)
    read = _shared.demo_export(n_accounts=300, seed=12, fraud_account_share=0.3, dim=4)
    out = second_stage.second_stage(fit, read, rounds=60, patience=15, draws=40, params={"nthread": 1})
    return fit, read, out


def test_arms_run_end_to_end_with_one_line_each(result):
    """Every arm has one line with finite capture against the network's score; the trees learn the vector's signal."""
    fit, read, out = result
    table = out["table"]
    assert table["arm"].tolist() == list(second_stage.ARMS)
    assert table["udr"].between(0, 1).all() and (table["low"] <= table["high"]).all()
    score = table.loc[table["arm"] == "score"].iloc[0]
    assert score["gain"] == 0 and np.isclose(score["udr"], score["base_udr"])
    assert np.allclose(table["base_udr"], score["udr"])                               # every arm against the same base
    assert out["scores"].shape == (len(read), 4) and np.isfinite(out["scores"].to_numpy()).all()
    for arm in ("trees_all", "specialist"):
        assert out["info"][arm]["stop_on"] == "capture"
    # The made-up vector carries fraud signal that the made-up score lacks; the all-row trees must find it.
    y, ranked = _shared.fraud_flags(read), _shared.scored_rows(read)
    assert out["info"]["trees_all"]["trees"] > 0
    assert (ranking.average_precision(y[ranked], out["scores"]["trees_all"].to_numpy()[ranked])
            > ranking.average_precision(y[ranked], out["scores"]["score"].to_numpy()[ranked]))


def test_band_is_a_fixed_floor_and_the_rest_keeps_the_network_order(result):
    """The band of the read rows is 'logit at or above the floor taken on the fit rows'; below it nothing moves."""
    fit, read, out = result
    logit_fit, logit_read = _shared.logits(fit), _shared.logits(read)
    _, secs_fit = _shared.account_and_time(fit)
    fit_rows = _shared.full_lookback(secs_fit, 1)
    assert out["band_floor"] == _shared.cut_value(logit_fit[fit_rows], second_stage.BAND_PER_MILLE)
    assert out["cut"] == _shared.cut_value(logit_fit[fit_rows])
    in_band = logit_read >= out["band_floor"]
    assert 0 < in_band.mean() < 0.2
    for arm in ("specialist", "average"):
        values = out["scores"][arm].to_numpy()
        assert np.array_equal(values[~in_band], logit_read[~in_band])
        assert values[in_band].min() > values[~in_band].max()
    y, ranked = _shared.fraud_flags(read), _shared.scored_rows(read)
    assert np.isclose(out["band_recall"], in_band[ranked][y[ranked] > 0].mean())


def test_specialist_is_fitted_only_on_band_rows(result):
    """The specialist's fit rows are exactly the band rows with a full look-back outside the held-out accounts."""
    fit, _, out = result
    account_fit, secs_fit = _shared.account_and_time(fit)
    held = _shared.held_out_accounts(account_fit, None, 0)
    band = _shared.logits(fit) >= out["band_floor"]
    fit_rows = _shared.full_lookback(secs_fit, 1)
    assert out["info"]["specialist"]["fit_rows"] == int((band & fit_rows & ~held).sum())
    assert out["info"]["trees_all"]["fit_rows"] == int((fit_rows & ~held).sum())
    assert out["info"]["specialist"]["inner_rows"] == out["info"]["trees_all"]["inner_rows"] == int(held.sum())


def test_tool_runs_on_files_and_writes_both_tables(tmp_path, capsys, monkeypatch):
    """The tool prints the frozen numbers and the arms, and writes the table of arms and the per-row scores."""
    monkeypatch.setitem(_shared.TREE_PARAMS, "nthread", 1)                         # one thread per tree fit
    fit = _shared.demo_export(n_accounts=250, seed=13, days=92, start=settings.TRAIN_HISTORY_START,
                              fraud_account_share=0.3, dim=3)
    read = _shared.demo_export(n_accounts=200, seed=14, fraud_account_share=0.3, dim=3)
    fit_path = tables.write_table(fit, str(tmp_path / "fit.parquet"))
    read_path = tables.write_table(read, str(tmp_path / "read.parquet"))
    out, scores_out = str(tmp_path / "arms.parquet"), str(tmp_path / "scores.parquet")
    result = second_stage.main(["--fit", fit_path, "--read", read_path, "--rounds", "20", "--draws", "20",
                                "--no-state", "--out", out, "--scores-out", scores_out])
    printed = capsys.readouterr().out
    assert "band floor (logit)" in printed and "specialist" in printed and "switched off" in printed
    assert tables.read_columns(out)["arm"].tolist() == list(second_stage.ARMS)
    written = tables.read_columns(scores_out)
    assert list(written.columns) == [settings.ID_COL, *second_stage.ARMS] and len(written) == len(read)
    assert np.array_equal(written["average"].to_numpy(), result["scores"]["average"].to_numpy())
