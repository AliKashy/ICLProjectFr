"""Tests of the oracle ladder, a measurement that never ships.

The label state is recomputed the slow way, row by row, from the frauds of the same account
whose labels were known in strictly earlier seconds. Further tests check the reporting curve,
the time rule on rows that share a second, that the arms run end to end with one line each,
and that the file says plainly that it is for measurement only.
"""
import numpy as np
import pandas as pd
import pytest

from additions import settings
from additions.after_model import _shared, oracle_ladder
from additions.common import synthetic, tables, timekeys
from additions.common.timekeys import MISSING_SECOND

DAY = 86_400


def _rows(n_accounts=40, seed=0, days=75, start="2025-04-20"):
    """Made-up rows with fraud runs on most accounts, so that the label state has something to count."""
    return synthetic.make_transactions(n_accounts=n_accounts, seed=seed, days=days, start=start,
                                       fraud_account_share=0.8)


def _frame(rows):
    """A tiny table from (account, second, fraud) tuples, with the column names of settings."""
    start = pd.Timestamp(settings.TARGET_START)
    return pd.DataFrame({
        settings.ACCOUNT_COL: [r[0] for r in rows],
        settings.TIME_COL: [start + pd.Timedelta(seconds=r[1]) for r in rows],
        settings.LABEL_COL: [r[2] for r in rows],
    })


def _same(a, b):
    return bool(np.isclose(a, b, rtol=1e-4, atol=1e-5, equal_nan=True))


def _slow_state(i, account, secs, fraud, known, start):
    """The label state of row i from the definition.

    A fraud of the same account counts when its own row lies inside the look-back (at or after
    `start`), in a strictly earlier second, and its label was known in a second strictly before
    the row's second. Windows and fading are measured from the fraud's own transaction time.
    """
    seen = ((account == account[i]) & fraud & (secs >= start) & (secs < secs[i]) & (known != MISSING_SECOND)
            & (known < secs[i]))
    age = (secs[i] - secs[seen]).astype(np.float64)
    out = {}
    for label, window in oracle_ladder.WINDOWS:
        out[f"n_known_{label}"] = float((age <= window).sum())
    month = age <= oracle_ladder.WINDOWS[-1][1]
    out["secs_since_known"] = age[month].min() if month.any() else np.nan
    for label, half in oracle_ladder.HALF_LIVES:
        out[f"decayed_known_{label}"] = float((0.5 ** (age / half)).sum())
    return out


def test_zero_delay_state_equals_the_slow_definition():
    """With no delay every column matches a row-by-row count of earlier frauds, with and without the look-back."""
    df = _rows()
    account, secs = _shared.account_and_time(df)
    fraud = _shared.fraud_flags(df) > 0
    known = np.where(fraud, secs, MISSING_SECOND)
    for months_back in (None, 1):
        got = oracle_ladder.build_label_state(df, delayed=False, months_back=months_back)
        assert got.shape == (len(df), 11) and got.index.equals(df.index)
        assert list(got.columns) == oracle_ladder.label_columns(oracle_ladder.NOW_PREFIX)
        start = np.full(len(df), secs.min()) if months_back is None else timekeys.month_start_seconds(secs, 1)
        checked = 0
        for i in range(len(df)):
            # Every row of a fraud account and every fifth other row: the fraud accounts are where it matters.
            if not (fraud[account == account[i]].any() or i % 5 == 0):
                continue
            slow = _slow_state(i, account, secs, fraud, known, start[i])
            for name, value in slow.items():
                assert _same(got[oracle_ladder.NOW_PREFIX + name].iloc[i], value), (months_back, i, name)
            checked += 1
        assert checked > 100 and got[oracle_ladder.NOW_PREFIX + "n_known_24h"].max() >= 2


def test_own_label_and_labels_of_the_same_second_are_not_seen():
    """A fraud is invisible to itself and to every row of its own second, and visible from the next second on."""
    df = _frame([("a", 100, 1), ("a", 100, 0), ("a", 101, 1), ("b", 101, 0), ("a", 101, 0), ("a", 5_000, 0)])
    got = oracle_ladder.build_label_state(df, delayed=False, months_back=None)
    n_1h = got[oracle_ladder.NOW_PREFIX + "n_known_1h"].tolist()
    assert n_1h == [0, 0, 1, 0, 1, 0]                                   # the last row is 81 minutes on
    assert got[oracle_ladder.NOW_PREFIX + "n_known_24h"].tolist() == [0, 0, 1, 0, 1, 2]
    since = got[oracle_ladder.NOW_PREFIX + "secs_since_known"].to_numpy()
    assert np.isnan(since[[0, 1, 3]]).all() and since[2] == 1 and since[5] == 4_899


def test_later_rows_do_not_change_earlier_columns():
    """Dropping every row after the middle of the period leaves the zero-delay state of the rows before it unchanged."""
    df = _rows(seed=1)
    secs = timekeys.seconds(df[settings.TIME_COL])
    keep = secs <= np.median(secs)
    full = oracle_ladder.build_label_state(df, delayed=False)
    part = oracle_ladder.build_label_state(df[keep], delayed=False)
    assert np.allclose(full[keep].to_numpy(), part.to_numpy(), rtol=1e-5, atol=1e-6, equal_nan=True)


def test_a_label_counts_only_once_its_report_time_has_passed():
    """With a fixed two-day delay a fraud is unseen up to and including its report second, and seen after it."""
    curve = ((2.0, 0.0), (2.0, 1.0))                                   # every label is reported after exactly two days
    report = 2 * DAY
    df = _frame([("a", 0, 1), ("a", DAY, 0), ("a", report, 0), ("a", report + 1, 0), ("a", report + 3_600, 0)])
    got = oracle_ladder.build_label_state(df, delayed=True, curve=curve, months_back=None)
    name = oracle_ladder.LATE_PREFIX + "n_known_1h"
    assert got[oracle_ladder.LATE_PREFIX + "n_known_30d"].tolist() == [0, 0, 0, 1, 1]
    assert got[name].tolist() == [0, 0, 0, 0, 0]                       # the fraud itself is two days old by then
    assert got[oracle_ladder.LATE_PREFIX + "secs_since_known"].iloc[3] == report + 1
    # The zero-delay state of the same rows sees the fraud from the second after it.
    now = oracle_ladder.build_label_state(df, delayed=False, months_back=None)
    assert now[oracle_ladder.NOW_PREFIX + "n_known_30d"].tolist() == [0, 1, 1, 1, 1]


def test_delayed_state_equals_the_slow_definition_with_drawn_report_times():
    """Every delayed column matches a row-by-row count that uses the report times drawn from the curve."""
    df = _rows(seed=2)
    account, secs = _shared.account_and_time(df)
    fraud = _shared.fraud_flags(df) > 0
    curve = ((0.0, 0.0), (0.5, 0.3), (3.0, 0.7), (10.0, 0.9))           # a tenth of the labels is never reported
    delays = oracle_ladder.draw_report_delays(len(df), curve, seed=7)
    known = oracle_ladder.known_seconds(secs, fraud, delays)
    assert np.array_equal(known[~fraud], np.full((~fraud).sum(), MISSING_SECOND))
    reported = fraud & (known != MISSING_SECOND)
    assert (known[reported] >= secs[reported]).all() and (known[reported] - secs[reported] <= 10 * DAY).all()
    got = oracle_ladder.build_label_state(df, delayed=True, curve=curve, seed=7)
    start = timekeys.month_start_seconds(secs, 1)
    for i in np.flatnonzero(np.isin(account, account[fraud])):
        slow = _slow_state(i, account, secs, fraud, known, start[i])
        for name, value in slow.items():
            assert _same(got[oracle_ladder.LATE_PREFIX + name].iloc[i], value), (i, name)
    # Delayed labels can only be fewer than labels with no delay.
    now = oracle_ladder.build_label_state(df, delayed=False)
    assert (got.to_numpy()[:, :4] <= now.to_numpy()[:, :4]).all()
    assert got.to_numpy()[:, 3].sum() < now.to_numpy()[:, 3].sum()


def test_report_delays_follow_the_curve():
    """The drawn delays reproduce the shares of the curve, and a share below one leaves labels never reported."""
    curve = ((0.0, 0.0), (7.0, 0.25), (30.0, 0.8), (60.0, 0.9))
    delays = oracle_ladder.draw_report_delays(200_000, curve, seed=3)
    for days, share in curve[1:]:
        assert abs((delays <= days * DAY).mean() - share) < 0.01
    assert abs(np.isinf(delays).mean() - 0.1) < 0.01 and (delays[np.isfinite(delays)] >= 0).all()
    assert np.array_equal(delays, oracle_ladder.draw_report_delays(200_000, curve, seed=3))     # repeatable


def test_later_frauds_follow_an_earlier_fraud_of_the_account():
    """A fraud is 'later' only when a fraud of its account lies in a strictly earlier second."""
    df = _frame([("a", 10, 1), ("a", 10, 1), ("a", 20, 1), ("a", 30, 0), ("b", 5, 0), ("b", 6, 1)])
    assert oracle_ladder.later_frauds(df).tolist() == [False, False, True, False, False, False]


@pytest.fixture(scope="module")
def ladder_table():
    """The four arms fitted on one made-up export and read on another, with few trees and draws."""
    fit = _shared.demo_export(n_accounts=400, seed=11, days=92, start=settings.TRAIN_HISTORY_START,
                              fraud_account_share=0.3, dim=4)
    read = _shared.demo_export(n_accounts=300, seed=12, fraud_account_share=0.3, dim=4)
    # One thread per tree fit: on a busy machine many threads fighting over few cores are far slower.
    return oracle_ladder.ladder(fit, read, rounds=40, patience=10, draws=40, params={"nthread": 1})


def test_arms_run_end_to_end_with_one_line_each(ladder_table):
    """The ladder gives the model's own score and each arm one line, with finite capture figures."""
    table = ladder_table
    assert table["arm"].tolist() == ["score", *oracle_ladder.ARMS]
    for column in ("trees", "udr", "vdr", "base_udr", "gain", "low", "high", "udr_first", "udr_later"):
        assert column in table.columns
    assert table["udr"].between(0, 1).all() and np.isfinite(table["base_udr"]).all()
    base = table.loc[table["arm"] == "base"].iloc[0]
    assert base["gain"] == 0 and np.isclose(base["udr"], base["base_udr"])        # the base arm against itself
    assert (table["low"] <= table["high"]).all()
    sentence = oracle_ladder.verdict(table)
    assert "upper bound" in sentence and ("not worth doing" in sentence or "has room" in sentence)


def test_tool_runs_on_files_and_writes_the_table(tmp_path, capsys, monkeypatch):
    """The tool reads two export files, prints the ladder and the verdict, and writes one line per arm."""
    monkeypatch.setitem(_shared.TREE_PARAMS, "nthread", 1)                 # one thread per tree fit
    fit = _shared.demo_export(n_accounts=250, seed=13, days=92, start=settings.TRAIN_HISTORY_START,
                              fraud_account_share=0.3, dim=3)
    read = _shared.demo_export(n_accounts=200, seed=14, fraud_account_share=0.3, dim=3)
    fit_path = tables.write_table(fit, str(tmp_path / "fit.parquet"))
    read_path = tables.write_table(read, str(tmp_path / "read.parquet"))
    out = str(tmp_path / "ladder.parquet")
    table = oracle_ladder.main(["--fit", fit_path, "--read", read_path, "--rounds", "20", "--draws", "20",
                                "--out", out])
    printed = capsys.readouterr().out
    assert "measurement only" in printed and "zero_delay_labels" in printed and "upper bound" in printed
    written = tables.read_columns(out)
    assert written["arm"].tolist() == table["arm"].tolist() == ["score", *oracle_ladder.ARMS]


def test_the_file_says_it_is_for_measurement_only():
    """The file name, the docstrings and the column prefixes all mark the label state as measurement only."""
    assert oracle_ladder.__file__.endswith("oracle_ladder.py")
    assert oracle_ladder.__doc__.startswith("MEASUREMENT ONLY, never shipped")
    assert "MUST NEVER REACH A MODEL THAT SHIPS" in oracle_ladder.__doc__
    for function in (oracle_ladder.build_label_state, oracle_ladder.label_state):
        assert "MEASUREMENT ONLY" in function.__doc__
    assert "oracle" in oracle_ladder.NOW_PREFIX and "oracle" in oracle_ladder.LATE_PREFIX
