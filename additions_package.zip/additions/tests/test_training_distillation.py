"""Tests of the distillation pieces.

The loss is compared with the slow formula row by row, the cross-fit plan is checked on
made-up files that hold whole accounts, and one test shows the reason for the plan: a
teacher's scores on its own training rows sit much closer to the labels than its scores on
rows it has not seen.
"""
import tempfile

import numpy as np
import pytest
import torch
import torch.nn.functional as F
import xgboost
from scipy.special import expit
from sklearn.isotonic import IsotonicRegression

from additions import settings
from additions.common import ranking, synthetic, tables
from additions.training import distillation
from additions.training.distillation import (average_teachers, cross_fit_plan, out_of_sample_scores,
                                             soft_target_loss, to_probability)


def _rows(seed=0, n_accounts=120):
    """Made-up rows as tensors: 0/1 labels, a teacher probability and the log-odds of a student."""
    df = synthetic.make_scores(synthetic.make_transactions(n_accounts=n_accounts, seed=seed, fraud_account_share=0.4),
                               seed=seed)
    generator = torch.Generator().manual_seed(seed)
    labels = torch.tensor(df[settings.LABEL_COL].to_numpy(), dtype=torch.float64)
    teacher = torch.tensor(df[settings.SCORE_COL].to_numpy(), dtype=torch.float64)
    logits = torch.randn(len(df), generator=generator, dtype=torch.float64) - 3.0
    return df, logits, labels, teacher


def _ce(z, t):
    """The slow cross-entropy of log-odds z against a target t between 0 and 1, per row (numpy)."""
    p = expit(z)
    return -(t * np.log(p) + (1.0 - t) * np.log(1.0 - p))


def test_loss_equals_the_slow_formula():
    """Per row: ce(label) + weight * ce(teacher) where a soft target exists; rows averaged with their weights."""
    _, logits, labels, teacher = _rows()
    rng = np.random.default_rng(0)
    teacher[torch.tensor(rng.random(len(teacher)) < 0.2)] = float("nan")       # rows the teacher did not score
    row_weight = torch.tensor(rng.random(len(teacher)) * (rng.random(len(teacher)) < 0.9))
    z, y, p, w = logits.numpy(), labels.numpy(), teacher.numpy(), row_weight.numpy()
    for only_negatives in (False, True):
        has = ~np.isnan(p) & ((y == 0) if only_negatives else True)
        per_row = _ce(z, y) + 0.5 * np.where(has, _ce(z, np.nan_to_num(p)), 0.0)
        got = soft_target_loss(logits, labels, teacher, 0.5, only_negatives, row_weight)
        assert np.isclose(got.item(), (per_row * w).sum() / w.sum())
        total, label_term, soft_term = soft_target_loss(logits, labels, teacher, 0.5, only_negatives, row_weight,
                                                        return_parts=True)
        assert np.isclose(label_term.item(), (_ce(z, y) * w).sum() / w.sum())
        assert np.isclose(total.item(), label_term.item() + 0.5 * soft_term.item())
    # Without row weights every row counts once.
    has = ~np.isnan(p)
    slow = (_ce(z, y) + 0.3 * np.where(has, _ce(z, np.nan_to_num(p)), 0.0)).mean()
    assert np.isclose(soft_target_loss(logits, labels, teacher, weight=0.3).item(), slow)


def test_without_a_teacher_the_loss_is_the_plain_cross_entropy():
    """A weight of zero, or a teacher that scored no row, leaves the label loss and its gradients unchanged."""
    _, logits, labels, teacher = _rows(seed=1)
    plain = F.binary_cross_entropy_with_logits(logits, labels)
    assert torch.isclose(soft_target_loss(logits, labels, teacher, weight=0.0), plain)
    nothing = torch.full_like(teacher, float("nan"))
    z = logits.clone().requires_grad_(True)
    loss = soft_target_loss(z, labels, nothing)
    loss.backward()
    assert torch.isclose(loss.detach(), plain)
    assert torch.isfinite(z.grad).all()
    assert torch.allclose(z.grad, (torch.sigmoid(logits) - labels) / len(labels))


def test_gradient_pulls_the_student_to_a_blend_of_label_and_teacher():
    """The gradient of a row is (p - label) + weight * (p - teacher); it vanishes at the blend of the two."""
    _, logits, labels, teacher = _rows(seed=2)
    teacher[::7] = float("nan")
    z = logits.clone().requires_grad_(True)
    soft_target_loss(z, labels, teacher, weight=0.5).backward()
    p = torch.sigmoid(logits)
    has = torch.isfinite(teacher)
    expected = ((p - labels) + 0.5 * has * (p - torch.nan_to_num(teacher))) / len(labels)
    assert torch.allclose(z.grad, expected, atol=1e-12)
    # At a probability of (label + weight * teacher) / (1 + weight) the gradient of every row is zero.
    blend = (labels + 0.5 * torch.nan_to_num(teacher)) / torch.where(has, torch.tensor(1.5), torch.tensor(1.0))
    inside = (blend > 0) & (blend < 1)                                   # rows whose best log-odds is finite
    rest = torch.logit(blend[inside]).requires_grad_(True)
    soft_target_loss(rest, labels[inside], teacher[inside], weight=0.5).backward()
    assert inside.sum() > 100 and rest.grad.abs().max() < 1e-12


def test_no_gradient_reaches_the_teacher_and_fraud_rows_can_be_left_out():
    """The teacher is data: nothing flows back into it. With only_on_negatives its value on fraud rows is unused."""
    _, logits, labels, teacher = _rows(seed=3)
    teacher_param = teacher.clone().requires_grad_(True)
    z = logits.clone().requires_grad_(True)
    soft_target_loss(z, labels, teacher_param).backward()
    assert teacher_param.grad is None and z.grad.abs().sum() > 0
    changed = teacher.clone()
    changed[labels == 1] = 0.123
    assert labels.sum() > 0
    same = soft_target_loss(logits, labels, changed, only_on_negatives=True)
    assert torch.equal(same, soft_target_loss(logits, labels, teacher, only_on_negatives=True))
    assert not torch.equal(soft_target_loss(logits, labels, changed), soft_target_loss(logits, labels, teacher))


def test_average_of_teachers_is_the_mean_of_their_log_odds():
    """Each row gets the mean over the teachers that scored it; a row nobody scored stays missing."""
    rng = np.random.default_rng(4)
    a, b, c = rng.normal(size=50), rng.normal(size=50), rng.normal(size=50)
    assert np.allclose(average_teachers([a, b, c]), (a + b + c) / 3)
    assert np.allclose(average_teachers([torch.tensor(a), b]), (a + b) / 2)       # tensors and arrays mix
    b[:10] = np.nan
    c[:5] = np.nan
    a[0] = np.nan
    got = average_teachers([a, b, c])
    assert np.isnan(got[0])
    assert np.allclose(got[1:5], a[1:5]) and np.allclose(got[5:10], (a[5:10] + c[5:10]) / 2)
    assert np.allclose(got[10:], (a[10:] + b[10:] + c[10:]) / 3)
    # The mean of log-odds is the geometric mean of the odds.
    odds = np.exp(np.stack([a[10:], b[10:], c[10:]]))
    assert np.allclose(np.exp(got[10:]), odds.prod(axis=0) ** (1 / 3))


def test_isotonic_map_is_monotone_calibrated_and_keeps_the_grading():
    """The map never decreases, gives the right fraud rate, and keeps more levels than a staircase."""
    df = synthetic.make_scores(synthetic.make_transactions(n_accounts=600, seed=5, fraud_account_share=0.3), seed=5)
    y = df[settings.LABEL_COL].to_numpy()
    # A teacher that ranks like the made-up score but is far too high everywhere.
    teacher = expit(ranking.to_logit(df[settings.SCORE_COL].to_numpy(), "probability") + 4.0)
    held_out = np.arange(len(df)) % 2 == 0                                # the map is fitted on every second row
    prob = to_probability(teacher[~held_out], teacher[held_out], y[held_out], kind="probability")
    order = np.argsort(teacher[~held_out], kind="stable")
    assert (np.diff(prob[order]) >= 0).all()                             # monotone in the teacher's score
    assert prob.min() >= 1e-6 and prob.max() <= 1 - 1e-6
    assert abs(prob.mean() - y[~held_out].mean()) < 0.3 * y.mean()        # the level is right ...
    assert teacher[~held_out].mean() > 5 * y.mean()                      # ... where the raw score was not
    staircase = IsotonicRegression(y_min=0.0, y_max=1.0, out_of_bounds="clip").fit(
        ranking.to_logit(teacher[held_out], "probability"), y[held_out])
    steps = staircase.predict(ranking.to_logit(teacher[~held_out], "probability"))
    assert len(np.unique(prob)) > 5 * len(np.unique(steps))               # the grading inside a step is kept
    # A missing teacher score stays missing.
    with_gap = teacher[~held_out].copy()
    with_gap[:3] = np.nan
    mapped = to_probability(with_gap, teacher[held_out], y[held_out], kind="probability")
    assert np.isnan(mapped[:3]).all() and np.allclose(mapped[3:], prob[3:])


def test_matching_standardised_log_odds_keeps_the_order_exactly():
    """The teacher's log-odds take the mean and the spread of the reference; no two rows change places."""
    rng = np.random.default_rng(6)
    teacher = rng.normal(2.0, 5.0, size=4000)                             # an uncalibrated score on an open scale
    reference = rng.normal(-6.0, 1.5, size=3000)
    prob = to_probability(teacher, reference_logits=reference, kind="logit", floor=1e-12)
    mapped = ranking.to_logit(prob, "probability")
    assert np.isclose(mapped.mean(), reference.mean()) and np.isclose(mapped.std(), reference.std())
    assert np.array_equal(np.argsort(teacher), np.argsort(mapped))        # a strictly rising map
    # With neither held-out rows nor a reference the score is taken at face value.
    assert np.allclose(to_probability(teacher, kind="logit", floor=0.0), expit(teacher))
    assert np.allclose(to_probability(expit(teacher[:50] / 5)), expit(teacher[:50] / 5))      # settings: a probability


def test_plan_scores_every_file_once_by_a_teacher_that_did_not_train_on_it():
    """Folds are disjoint and cover all files; a teacher's training files and scoring files never overlap."""
    files = list(range(1, 11))
    for n_folds in (2, 3, 5, 10):
        plan = cross_fit_plan(files, n_folds)
        assert [entry["teacher"] for entry in plan] == list(range(n_folds))
        scored = [f for entry in plan for f in entry["score_files"]]
        assert sorted(scored) == files                                    # every file exactly once
        for entry in plan:
            assert not set(entry["train_files"]) & set(entry["score_files"])
            assert sorted(entry["train_files"] + entry["score_files"]) == files
        sizes = [len(entry["score_files"]) for entry in plan]
        assert max(sizes) - min(sizes) <= 1
    assert cross_fit_plan(n_folds=2)[0]["score_files"] == settings.TRAIN_FILES[0::2]      # the default list
    assert len(cross_fit_plan([3, 3, 4, 4], 2)[0]["score_files"]) == 1                    # a repeated number counts once
    for bad in (1, 11):
        with pytest.raises(ValueError):
            cross_fit_plan(files, bad)


def test_cross_fitted_scores_are_out_of_sample_and_in_sample_scores_collapse_to_the_labels():
    """Each row is scored by the teacher that never saw its account; scores from the other teacher hug the labels."""
    df = synthetic.make_transactions(n_accounts=400, seed=7, fraud_account_share=0.3)
    with tempfile.TemporaryDirectory() as folder:
        numbers = synthetic.write_files(df, folder, 4, first_number=11)
        rows = tables.read_files(folder, numbers)
    plan = cross_fit_plan(numbers, n_folds=2)
    inputs = rows[[settings.AMOUNT_COL, settings.VISA_SCORE_COL, settings.BALANCE_COL, settings.MERCH_LIMIT_COL]]
    y = rows[settings.LABEL_COL].to_numpy()
    file_of_row = rows["_file"].to_numpy()
    scores = {}
    for entry in plan:                                                    # one small tree model per teacher
        train = np.isin(file_of_row, entry["train_files"])
        model = xgboost.XGBClassifier(n_estimators=60, max_depth=6, learning_rate=0.3, n_jobs=2, random_state=0)
        model.fit(inputs[train], y[train])
        scores[entry["teacher"]] = ranking.to_logit(model.predict_proba(inputs)[:, 1], "probability")
        # No account of the files this teacher scores is among the accounts it trained on.
        scored = np.isin(file_of_row, entry["score_files"])
        assert not set(rows.loc[scored, settings.ACCOUNT_COL]) & set(rows.loc[train, settings.ACCOUNT_COL])
    out_of_sample = out_of_sample_scores(file_of_row, scores, plan)
    assert np.isfinite(out_of_sample).all()
    for entry in plan:                                                    # each row holds its own teacher's score
        scored = np.isin(file_of_row, entry["score_files"])
        assert np.array_equal(out_of_sample[scored], scores[entry["teacher"]][scored])
    # What a teacher holds on its own training rows is never read, so it may be anything.
    hidden = {k: np.where(np.isin(file_of_row, plan[k]["train_files"]), np.nan, v) for k, v in scores.items()}
    assert np.array_equal(out_of_sample_scores(file_of_row, [hidden[0], hidden[1]], plan), out_of_sample)
    # A file outside the plan gets no soft target.
    assert np.isnan(out_of_sample_scores(np.array([99]), {0: np.zeros(1), 1: np.zeros(1)}, plan)).all()

    # The reason for the plan: scores from the teacher that DID train on a row are the label again.
    in_sample = out_of_sample_scores(file_of_row, {0: scores[1], 1: scores[0]}, plan)
    distance_in = np.abs(expit(in_sample) - y).mean()
    distance_out = np.abs(expit(out_of_sample) - y).mean()
    assert distance_in < 0.5 * distance_out
    assert _ce(in_sample, y).mean() < 0.5 * _ce(out_of_sample, y).mean()
    # As soft targets they would add next to nothing to the labels, the cross-fitted ones do.
    z = torch.full((len(y),), -4.0, dtype=torch.float64)
    labels = torch.tensor(y, dtype=torch.float64)
    parts_in = soft_target_loss(z, labels, torch.tensor(expit(in_sample)), return_parts=True)
    parts_out = soft_target_loss(z, labels, torch.tensor(expit(out_of_sample)), return_parts=True)
    assert abs(parts_in[2] - parts_in[1]) < abs(parts_out[2] - parts_out[1])


def test_a_student_trains_on_labels_and_soft_targets():
    """A small model takes gradient steps on the loss: finite values, a falling loss, gradients in every weight."""
    df = synthetic.make_vectors(synthetic.make_scores(synthetic.make_transactions(n_accounts=150, seed=8), seed=8), dim=8)
    vectors = torch.tensor(df[[f"{settings.VECTOR_PREFIX}{j}" for j in range(8)]].to_numpy(), dtype=torch.float32)
    labels = torch.tensor(df[settings.LABEL_COL].to_numpy(), dtype=torch.float32)
    teacher = torch.tensor(to_probability(df[settings.SCORE_COL].to_numpy(), kind="probability"), dtype=torch.float32)
    torch.manual_seed(0)
    student = torch.nn.Linear(8, 1)
    optimiser = torch.optim.Adam(student.parameters(), lr=0.05)
    history = []
    for _ in range(40):
        optimiser.zero_grad()
        loss = soft_target_loss(student(vectors).squeeze(-1), labels, teacher, weight=0.5)
        loss.backward()
        assert all(torch.isfinite(p.grad).all() and p.grad.abs().sum() > 0 for p in student.parameters())
        optimiser.step()
        history.append(loss.item())
    assert np.isfinite(history).all() and history[-1] < 0.5 * history[0]
    assert distillation.weighted_mean is not None                        # the loss uses the shared weighted mean
