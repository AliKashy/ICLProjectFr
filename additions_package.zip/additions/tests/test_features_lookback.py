"""Tests of the calendar look-back.

The tests build one table shaped like evaluation files (a history month, then a scored
month) and one shaped like training files (several months), and check that the rule gives
both the same kind of window.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, timekeys
from additions.common.history import EarlierRows
from additions.features import lookback

def _secs(start, days, seed=0, n_accounts=40):
    df = synthetic.make_transactions(n_accounts=n_accounts, days=days, start=start, seed=seed)
    return df, timekeys.seconds(df[settings.TIME_COL])


def _slow_start(stamp):
    """The first day of the month before `stamp`, by plain year and month arithmetic."""
    year, month = (stamp.year, stamp.month - 1) if stamp.month > 1 else (stamp.year - 1, 12)
    return pd.Timestamp(year=year, month=month, day=1)


def test_the_start_is_the_first_day_of_the_previous_month():
    """The fast function equals the slow, obvious calendar arithmetic, also across a year end."""
    stamps = pd.to_datetime(["2025-06-17 10:00:00", "2025-01-01 00:00:00", "2025-03-31 23:59:59", None])
    secs = timekeys.seconds(pd.Series(stamps))
    got = lookback.lookback_start(secs)
    assert pd.to_datetime(got[:3], unit="s").tolist() == [_slow_start(s) for s in stamps[:3]]
    assert got[3] == timekeys.MISSING_SECOND                                  # no time, no look-back
    assert str(pd.to_datetime(lookback.lookback_start(secs[:1], 0), unit="s")[0]) == "2025-06-01 00:00:00"
    # The first day of data can be given as text, as a timestamp or as seconds.
    as_text = lookback.data_start("2025-05-01")
    assert lookback.data_start(pd.Timestamp("2025-05-01")) == as_text == lookback.data_start(float(as_text))


def test_scored_rows_have_one_to_two_months_and_a_full_lookback():
    """In files that start one month before the scored month, every scored row has its whole look-back."""
    _, secs = _secs("2025-05-01", 61)
    june = secs >= lookback.data_start("2025-06-01")
    days = lookback.days_available(secs, "2025-05-01")
    assert days[june].min() >= 31 and days[june].max() <= 61
    assert lookback.has_full_lookback(secs, "2025-05-01")[june].all()
    assert not lookback.has_full_lookback(secs, "2025-05-01")[~june].any()     # the history month has no earlier month
    # With no start given, the first day found in the rows is used, which is the same day here.
    assert np.allclose(days, lookback.days_available(secs))


def test_training_rows_get_the_same_window_as_scored_rows():
    """Under the calendar rule a training row deep inside long files still has 28 to 62 days."""
    _, secs = _secs("2024-10-01", 150, seed=1)
    full = lookback.has_full_lookback(secs, "2024-10-01")
    days = lookback.days_available(secs, "2024-10-01")
    assert days[full].min() >= 28 and days[full].max() <= 62
    assert (pd.to_datetime(secs[~full], unit="s").month == 10).all()           # only the first month lacks it


def test_a_fixed_window_is_cut_short_on_scored_rows_only():
    """A 90-day window is full deep inside long files and cut on every row of short files."""
    _, eval_secs = _secs("2025-05-01", 61)
    assert (lookback.fixed_window_days(eval_secs, "2025-05-01") < 90).all()
    _, train_secs = _secs("2024-10-01", 150, seed=1)
    deep = train_secs >= lookback.data_start("2025-01-01")
    assert (lookback.fixed_window_days(train_secs, "2024-10-01")[deep] == 90).all()
    table = lookback.coverage_by_month(eval_secs, "2025-05-01")
    assert table["month"].tolist() == ["2025-05", "2025-06"]
    assert table["fixed_cut_short"].tolist() == [1.0, 1.0] and table["full_lookback"].tolist() == [0.0, 1.0]
    assert table["rows"].sum() == len(eval_secs)


def test_the_engine_with_a_start_equals_a_table_cut_like_an_evaluation_file():
    """Reading from the look-back start gives a December row what it would see in files that begin in November."""
    df, secs = _secs("2024-10-01", 92, seed=2)
    account = timekeys.codes(df[settings.ACCOUNT_COL])
    amount = df[settings.AMOUNT_COL].to_numpy()
    december = secs >= lookback.data_start("2024-12-01")
    with_start = EarlierRows(account, secs, start=lookback.lookback_start(secs))
    cut = secs >= lookback.data_start("2024-11-01")                           # drop October, as short files would
    as_eval_file = EarlierRows(account[cut], secs[cut])
    assert (with_start.count()[december] == as_eval_file.count()[december[cut]]).all()
    assert np.allclose(with_start.total(amount)[december], as_eval_file.total(amount[cut])[december[cut]])


def test_blocks_cover_every_row_once_as_a_target():
    """Each row is a target in exactly one block, and that block starts at the row's look-back start."""
    _, secs = _secs("2024-10-01", 92, seed=3)
    blocks = lookback.month_blocks(secs)
    assert blocks["month"].tolist() == ["2024-10", "2024-11", "2024-12"]
    times_target = np.zeros(len(secs), dtype=int)
    for block in blocks.itertuples(index=False):
        target = (secs >= block.target_start) & (secs < block.target_end)
        times_target += target
        assert (lookback.lookback_start(secs[target]) == block.block_start).all()
    assert (times_target == 1).all()
    own_month = lookback.month_blocks(secs, months_back=0)
    assert (own_month["block_start"] == own_month["target_start"]).all()


def test_the_command_line_prints_and_writes_the_table(tmp_path, capsys):
    """The tool runs on made-up rows and writes its table only when a path is given."""
    out = tmp_path / "coverage.csv"
    table = lookback.main(["--demo", "--out", str(out)])
    assert "fixed_cut_short" in capsys.readouterr().out
    assert pd.read_csv(out)["rows"].tolist() == table["rows"].tolist()
