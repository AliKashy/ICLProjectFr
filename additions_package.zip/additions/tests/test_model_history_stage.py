"""Tests of stage 2 under the strict time rule.

The central tests alter the rows that a row may not read (rows of later seconds and the
other rows of its own second) and check that the row's output does not move, and recompute
each row's output from a sequence cut down to what the row may read. The other tests check
the position by count, the projection, the hooks, padding and the scoring route.
"""
import torch

from additions.common import synthetic
from additions.model import masks
from additions.model._shared import sequences_from_table
from additions.model.history_stage import HistoryStage

IN, WIDTH, HEADS = 12, 16, 4


def _batch(seed=0, n_accounts=10):
    """A padded batch of made-up transactions with same-second rows, and one random vector per slot."""
    df = synthetic.make_transactions(n_accounts=n_accounts, days=15, seed=seed, tie_share=0.15)
    batch, _, _ = sequences_from_table(df, seconds_per_sequence=8)
    torch.manual_seed(seed)
    vectors = torch.randn(*batch["mask"].shape, IN)
    return batch, vectors


def _stage(blocks=2, dropout=0.0, in_dim=IN, width=WIDTH, history_len=6):
    """A small stage 2 with no dropout unless asked."""
    torch.manual_seed(1)
    return HistoryStage(in_dim=in_dim, width=width, num_heads=HEADS, num_blocks=blocks, history_len=history_len,
                        dropout=dropout, attn_dropout=dropout)


def test_shapes_and_finite_values():
    """One vector per slot at the stage's width, finite on real rows and on padding."""
    batch, vectors = _batch()
    out = _stage().eval()(vectors, batch["time_seq"], batch["mask"])
    assert out.shape == (*batch["mask"].shape, WIDTH)
    assert torch.isfinite(out).all()
    assert not batch["mask"].all()                                  # the batch really has padding


def test_rows_never_read_later_rows_or_rows_of_their_own_second():
    """Altering every row a row may not read leaves that row's output unchanged."""
    batch, vectors = _batch(seed=1)
    stage = _stage().eval()
    times, valid = batch["time_seq"], batch["mask"]
    with torch.no_grad():
        before = stage(vectors, times, valid)
    for b in range(min(6, times.shape[0])):
        real = int(valid[b].sum())
        i = real // 2
        hidden = (times[b] >= times[b, i]).clone()
        hidden[i] = False                                          # the row itself keeps its vector
        hidden &= valid[b]
        altered = vectors.clone()
        altered[b, hidden] = torch.randn(int(hidden.sum()), IN) * 3
        with torch.no_grad():
            after = stage(altered, times, valid)
        assert torch.allclose(before[b, i], after[b, i], atol=1e-5)
        earlier = valid[b] & (times[b] < times[b, i])
        assert torch.allclose(before[b, earlier], after[b, earlier], atol=1e-5)


def test_each_row_equals_a_run_on_what_it_may_read():
    """A row's output equals the output of the stage run on that row and its strictly earlier rows alone."""
    batch, vectors = _batch(seed=2)
    stage = _stage().eval()
    times, valid = batch["time_seq"], batch["mask"]
    with torch.no_grad():
        full = stage(vectors, times, valid)
        for b in range(min(4, times.shape[0])):
            for i in range(int(valid[b].sum())):
                keep = valid[b] & (times[b] < times[b, i])
                keep[i] = True
                alone = stage(vectors[b:b + 1, keep], times[b:b + 1, keep], valid[b:b + 1, keep])
                position_of_i = int(keep[:i].sum())
                assert torch.allclose(full[b, i], alone[0, position_of_i], atol=1e-5)


def test_rows_of_one_second_share_their_position():
    """With no blocks the output is projection plus position, and the position counts strictly earlier rows."""
    batch, vectors = _batch(seed=3)
    stage = _stage(blocks=0, history_len=50)
    times, valid = batch["time_seq"], batch["mask"]
    out = stage(vectors, times, valid)
    for b in range(times.shape[0]):
        for i in range(int(valid[b].sum())):
            count = int((valid[b] & (times[b] < times[b, i])).sum())
            expected = stage.project(vectors[b, i]) + stage.position.weight[count]
            assert torch.allclose(out[b, i], expected, atol=1e-6)


def test_projection_only_when_the_widths_differ():
    """Equal widths pass the vectors through untouched; other widths get a learned projection."""
    assert isinstance(_stage(in_dim=WIDTH, width=WIDTH).project, torch.nn.Identity)
    assert isinstance(_stage(in_dim=IN, width=WIDTH).project, torch.nn.Linear)
    assert _stage(in_dim=WIDTH, width=None).width == WIDTH


def test_padding_never_turns_an_output_into_a_missing_value():
    """Missing values and huge values on padded slots change no real row and leave every output finite."""
    batch, vectors = _batch(seed=4)
    stage = _stage().eval()
    times, valid = batch["time_seq"], batch["mask"]
    with torch.no_grad():
        before = stage(vectors, times, valid)
        dirty = vectors.clone()
        dirty[~valid] = float("nan")
        after_nan = stage(dirty, times, valid)
        dirty[~valid] = 1e6
        after_big = stage(dirty, times, valid)
    assert torch.isfinite(after_nan).all() and torch.isfinite(after_big).all()
    assert torch.allclose(before[valid], after_nan[valid], atol=1e-5)
    assert torch.allclose(before[valid], after_big[valid], atol=1e-5)


def test_a_zero_bias_changes_nothing_and_a_bias_cannot_open_a_closed_entry():
    """A zero bias gives the plain output; a bias on entries the rule closes leaves every output unchanged."""
    batch, vectors = _batch(seed=5)
    stage = _stage().eval()
    times, valid = batch["time_seq"], batch["mask"]
    B, T = valid.shape
    with torch.no_grad():
        plain = stage(vectors, times, valid)
        zero = stage(vectors, times, valid, bias=torch.zeros(B, HEADS, T, T))
        allowed = masks.strict_visibility(times, valid)
        closed_bias = torch.where(allowed, 0.0, 50.0).unsqueeze(1).expand(B, HEADS, T, T).contiguous()
        closed = stage(vectors, times, valid, bias=closed_bias)
        open_bias = torch.randn(B, HEADS, T, T)
        biased = stage(vectors, times, valid, bias=open_bias)
    assert torch.allclose(plain, zero, atol=1e-6)
    assert torch.allclose(plain[valid], closed[valid], atol=1e-5)
    assert not torch.allclose(plain[valid], biased[valid], atol=1e-4)


def test_a_prefix_is_read_by_every_row_and_dropped_from_the_output():
    """Positions in front change the rows' outputs and do not appear in the result."""
    batch, vectors = _batch(seed=6)
    stage = _stage().eval()
    times, valid = batch["time_seq"], batch["mask"]
    prefix = torch.randn(valid.shape[0], 2, WIDTH)
    with torch.no_grad():
        plain = stage(vectors, times, valid)
        with_prefix = stage(vectors, times, valid, prefix=prefix)
    assert with_prefix.shape == plain.shape
    first_rows = valid.clone()
    first_rows[:, 1:] = False
    # Even the first row of a sequence, which has no earlier row, reads the prefix.
    assert not torch.allclose(plain[first_rows], with_prefix[first_rows], atol=1e-4)


def test_gradients_reach_every_part():
    """A loss on the real rows sends a gradient to the projection, the position table and the blocks."""
    batch, vectors = _batch(seed=7)
    stage = _stage(dropout=0.1).train()
    out = stage(vectors, batch["time_seq"], batch["mask"])
    out[batch["mask"]].pow(2).mean().backward()
    assert stage.project.weight.grad.abs().sum() > 0
    assert stage.position.weight.grad.abs().sum() > 0
    for layer in stage.blocks.layers:
        assert layer.self_attn.in_proj_weight.grad.abs().sum() > 0


def test_scoring_route_agrees_with_training_at_dropout_zero():
    """Evaluation mode under torch.no_grad() gives the training-mode output at dropout zero, bias included."""
    batch, vectors = _batch(seed=8)
    stage = _stage(dropout=0.0)
    times, valid = batch["time_seq"], batch["mask"]
    B, T = valid.shape
    bias = torch.randn(B, HEADS, T, T)
    train_out = stage.train()(vectors, times, valid, bias=bias)
    with torch.no_grad():
        eval_out = stage.eval()(vectors, times, valid, bias=bias)
    assert torch.allclose(train_out, eval_out, atol=1e-5)
