"""Tests of the small helpers shared by the loss terms and teachers.

Each test compares a helper with the slow, obvious way of computing the same thing. They
also show how the helpers are called.
"""
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

from additions import settings
from additions.common import synthetic, timekeys
from additions.training import _loss_shared
from additions.training._loss_shared import account_chunks, fraud_log_odds, ramp, weighted_mean


def test_two_class_cross_entropy_equals_the_binary_one_on_the_log_odds():
    """The loss of a two-class head and the binary loss on the difference of its outputs are one number."""
    generator = torch.Generator().manual_seed(0)
    output = torch.randn(7, 5, 2, generator=generator)
    labels = (torch.rand(7, 5, generator=generator) < 0.3).long()
    log_odds = fraud_log_odds(output)
    assert log_odds.shape == (7, 5)
    two_class = F.cross_entropy(output.reshape(-1, 2), labels.reshape(-1))
    binary = F.binary_cross_entropy_with_logits(log_odds.reshape(-1), labels.reshape(-1).float())
    assert torch.isclose(two_class, binary, atol=1e-6)
    assert torch.allclose(torch.softmax(output, dim=-1)[..., 1], torch.sigmoid(log_odds), atol=1e-6)
    # A head that puts "fraud" in its first column gives the opposite sign.
    assert torch.equal(fraud_log_odds(output, fraud_class=0), -log_odds)
    assert _loss_shared.FRAUD_CLASS == 1


def test_weighted_mean_equals_the_slow_sum():
    """The weighted mean is the sum of value times weight over the sum of the weights."""
    rng = np.random.default_rng(1)
    values, weights = rng.normal(size=(6, 9)), rng.random((6, 9))
    weights[rng.random((6, 9)) < 0.3] = 0.0
    got = weighted_mean(torch.tensor(values), torch.tensor(weights))
    assert np.isclose(float(got), (values * weights).sum() / weights.sum())
    assert np.isclose(float(weighted_mean(torch.tensor(values))), values.mean())
    # A yes/no weight keeps the marked rows; a weight per chunk broadcasts over its rows.
    keep = weights > 0
    assert np.isclose(float(weighted_mean(torch.tensor(values), torch.tensor(keep))), values[keep].mean())
    per_chunk = torch.tensor(rng.random((6, 1)))
    slow = (values * per_chunk.numpy()).sum() / (per_chunk.numpy().sum() * 9)
    assert np.isclose(float(weighted_mean(torch.tensor(values), per_chunk)), slow)


def test_weighted_mean_of_no_rows_is_a_zero_that_can_be_differentiated():
    """A batch without any weighted row gives zero and zero gradients instead of an error."""
    values = torch.randn(4, 3, requires_grad=True)
    loss = weighted_mean(values, torch.zeros(4, 3))
    loss.backward()
    assert loss.item() == 0.0 and torch.equal(values.grad, torch.zeros(4, 3))
    empty = torch.zeros(0, requires_grad=True)
    assert weighted_mean(empty).item() == 0.0 and weighted_mean(empty, torch.zeros(0)).item() == 0.0


def test_ramp_is_off_then_rises_then_stays_on():
    """The ramp is 0 before its start, a straight line over its length and 1 afterwards."""
    assert [ramp(s, start=10, length=4) for s in (0, 9, 10, 11, 12, 14, 99)] == [0.0, 0.0, 0.0, 0.25, 0.5, 1.0, 1.0]
    assert ramp(9, start=10) == 0.0 and ramp(10, start=10) == 1.0       # no length: on at once
    assert ramp(None, start=10, length=4) == 1.0                         # no schedule: fully on
    assert ramp(0) == 1.0


def test_chunks_hold_every_row_once_in_time_order():
    """Every row with a time sits in exactly one slot, chunks hold one account and run forward in time."""
    df = synthetic.make_transactions(n_accounts=40, seed=2, tie_share=0.2)
    df.loc[df.index[::97], settings.TIME_COL] = pd.NaT                   # a few rows that cannot be placed
    df["flag"] = df[settings.LABEL_COL] == 1
    chunks = account_chunks(df, [settings.LABEL_COL, settings.AMOUNT_COL, "flag"], width=7)
    valid, row, times = chunks["valid"].numpy(), chunks["row"].numpy(), chunks["times"].numpy()
    secs = timekeys.seconds(df[settings.TIME_COL])
    account = timekeys.codes(df[settings.ACCOUNT_COL])
    has_time = secs != timekeys.MISSING_SECOND
    assert valid.shape[1] == 7 and all(v.shape == valid.shape for v in chunks.values())
    assert sorted(row[valid]) == np.flatnonzero(has_time).tolist()       # each placed row once, no other row
    assert (row[~valid] == -1).all() and (times[~valid] == 0).all()
    assert np.array_equal(times[valid], secs[row[valid]])
    for b in range(len(valid)):
        n = int(valid[b].sum())
        assert n >= 1 and valid[b, :n].all()                             # real rows fill a chunk from the left
        assert len(set(account[row[b, :n]])) == 1                        # one account per chunk
        assert (np.diff(times[b, :n]) >= 0).all()                        # forward in time
    # A chunk is full unless it is the last one of its account.
    last_of_account = np.r_[account[row[1:, 0]] != account[row[:-1, 0]], True]
    assert (valid.sum(axis=1)[~last_of_account] == 7).all()
    # The carried columns hold the table's values; whole numbers stay whole and padding is marked.
    label = chunks[settings.LABEL_COL]
    assert label.dtype == torch.int64 and (label[~chunks["valid"]] == -1).all()
    assert np.array_equal(label.numpy()[valid], df[settings.LABEL_COL].to_numpy()[row[valid]])
    assert chunks["flag"].dtype == torch.int64
    amount = chunks[settings.AMOUNT_COL]
    assert amount.dtype == torch.float32 and torch.isnan(amount[~chunks["valid"]]).all()
    # A result computed on the chunks is carried back to the rows of the table through "row".
    back = np.full(len(df), np.nan)
    back[row[valid]] = amount.numpy()[valid]
    assert np.allclose(back[has_time], df[settings.AMOUNT_COL].to_numpy()[has_time])
    assert np.isnan(back[~has_time]).all()


def test_chunk_width_defaults_to_the_history_length_in_settings():
    """Without a width a chunk is one row longer than the history the second stage reads."""
    df = synthetic.make_transactions(n_accounts=5, seed=3)
    assert account_chunks(df)["valid"].shape[1] == settings.HISTORY_LEN + 1
    assert account_chunks(df.iloc[:0])["valid"].shape == (0, settings.HISTORY_LEN + 1)
