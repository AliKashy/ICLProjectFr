"""Tests of the network-score view of a merchant.

The columns are recomputed row by row from other accounts' scores on completed earlier days,
with the priors and the histogram smoothing applied the slow way. Further tests check that
tables of files add up, that the row's own account and the row's own day are never read, and
that a missing score column is skipped rather than fatal.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, timekeys
from additions.merchant import _panel, visa_view

ACCOUNT, MERCHANT, MCC, SCORE = settings.ACCOUNT_COL, settings.MERCHANT_COL, settings.MCC_COL, settings.VISA_SCORE_COL
LEVELS = ([], [MCC], [MERCHANT])                                  # from the broadest key to the narrowest


def _rows(seed=0, n_accounts=100, days=50):
    """Made-up rows on a few dozen merchants; some scores are missing and some sit at the top edge."""
    df = synthetic.make_transactions(n_accounts=n_accounts, days=days, seed=seed, fraud_account_share=0.5)
    df[MERCHANT] = df[MERCHANT] % 30
    df[MCC] = 1000 + df[MERCHANT] % 4
    rng = np.random.default_rng(seed)
    df.loc[rng.random(len(df)) < 0.03, SCORE] = np.nan
    df.loc[rng.random(len(df)) < 0.01, SCORE] = 100.0
    return df


def _day(df):
    return _panel.days(timekeys.seconds(df[settings.TIME_COL]))


def _others(df, day, i, keys, days):
    """Scores of other accounts at the same key on the `days` days before row i's day, the obvious way."""
    m = (df[ACCOUNT].to_numpy() != df[ACCOUNT].iloc[i]) & (day < day[i]) & (day >= day[i] - days)
    for k in keys:
        m &= (df[k] == df[k].iloc[i]).to_numpy()
    s = df.loc[m, SCORE].to_numpy(dtype=float)
    return s[~np.isnan(s)]


def _hist(scores):
    """A 10-bin histogram of scores; anything at or above 100 goes into the last bin."""
    return np.histogram(np.clip(scores, 0.0, 99.999), bins=visa_view.SCORE_EDGES)[0].astype(float)


def _same(a, b):
    return bool(np.isclose(a, b, rtol=2e-4, atol=2e-4, equal_nan=True))


def test_columns_equal_the_slow_definition():
    """Every column matches a recomputation from other accounts' scores of completed earlier days."""
    df = _rows()
    day = _day(df)
    got = visa_view.visa_features(df, *visa_view.build_visa_tables(df))
    assert got.shape == (len(df), 10) and got.index.equals(df.index)
    k, edges = _panel.PRIOR_ROWS, visa_view.SCORE_EDGES
    for i in range(0, len(df), 113):
        reads = {}
        for label, days in (("30d", 30), ("1d", 1)):
            parts = [_others(df, day, i, keys, days) for keys in LEVELS]
            assert got[f"visa_n_{label}"].iloc[i] == len(parts[-1])
            mean, hist = np.nan, None
            for s in parts:
                if np.isnan(mean):
                    mean = s.sum() / len(s) if len(s) else np.nan
                else:
                    mean = (s.sum() + k * mean) / (len(s) + k)
                if hist is None:
                    hist = _hist(s)
                else:
                    shape = hist / hist.sum() if hist.sum() > 0 else np.zeros_like(hist)
                    hist = _hist(s) + k * shape
            p90 = _panel.histogram_quantile(hist[None, :], edges, 0.9)[0]
            assert _same(got[f"visa_mean_{label}"].iloc[i], mean)
            assert _same(got[f"visa_p90_{label}"].iloc[i], p90)
            reads[label] = (mean, p90, hist)
        assert _same(got["visa_recent_minus_base_mean"].iloc[i], reads["1d"][0] - reads["30d"][0])
        assert _same(got["visa_recent_minus_base_p90"].iloc[i], reads["1d"][1] - reads["30d"][1])
        own = df[SCORE].iloc[i]
        assert _same(got["visa_own_minus_base"].iloc[i], own - reads["30d"][0])
        rank = _panel.histogram_rank(reads["30d"][2][None, :], edges, [own])[0]
        assert _same(got["visa_own_pct_30d"].iloc[i], rank)
    pct = got["visa_own_pct_30d"].dropna()
    assert len(pct) > 0.9 * len(got) and pct.between(0, 1).all()


def test_the_own_account_and_the_own_day_are_never_read():
    """A burst of high scores is invisible to its own account and on its own day, and visible to others the next day."""
    stamp = pd.Timestamp("2025-06-10 09:00:00")
    df = pd.DataFrame({
        ACCOUNT: ["a", "a", "b", "b", "a", "c"], MERCHANT: 7, MCC: 5411,
        settings.TIME_COL: [stamp - pd.Timedelta(days=2), stamp, stamp + pd.Timedelta(hours=1),
                            stamp + pd.Timedelta(hours=2), stamp + pd.Timedelta(days=1), stamp + pd.Timedelta(days=1)],
        SCORE: [10.0, 95.0, 95.0, 10.0, 10.0, 10.0]})
    got = visa_view.visa_features(df, *visa_view.build_visa_tables(df), prior_rows=0.0)
    assert got["visa_n_1d"].tolist() == [0, 0, 0, 0, 2, 3]           # yesterday only, never the own day
    assert got["visa_n_30d"].tolist() == [0, 0, 1, 1, 2, 4]           # b's rows see a's row of day -2 only
    assert got["visa_mean_30d"].iloc[3] == 10.0                      # neither a's 95 nor b's own 95 of the same day
    assert got["visa_mean_1d"].iloc[4] == 52.5                       # a reads b's two rows of yesterday, not its own 95
    assert np.isclose(got["visa_mean_1d"].iloc[5], (95 + 95 + 10) / 3)
    assert np.isclose(got["visa_own_minus_base"].iloc[4], 10.0 - (95 + 10) / 2)


def test_the_own_account_is_absent_and_later_days_change_nothing():
    """An account reads what it would read without its rows in the panel; dropping later rows changes nothing."""
    df = _rows(seed=1)
    one = (df[ACCOUNT] == pd.unique(df[ACCOUNT])[2]).to_numpy()
    inside = visa_view.visa_features(df[one], *visa_view.build_visa_tables(df))
    alone = visa_view.visa_features(df[one], visa_view.build_visa_tables(df[~one])[0], None)
    assert np.allclose(inside.to_numpy(), alone.to_numpy(), rtol=1e-5, atol=1e-5, equal_nan=True)
    with_own = visa_view.visa_features(df[one], visa_view.build_visa_tables(df)[0], None)
    assert not np.allclose(inside.to_numpy(), with_own.to_numpy(), equal_nan=True)   # the subtraction matters
    day = _day(df)
    keep = day <= np.median(day)
    full = visa_view.visa_features(df, *visa_view.build_visa_tables(df))
    part = visa_view.visa_features(df[keep], *visa_view.build_visa_tables(df[keep]))
    assert np.allclose(full[keep].to_numpy(), part.to_numpy(), rtol=1e-5, atol=1e-5, equal_nan=True)


def test_tables_of_files_add_up():
    """Tables built file by file and added give the same columns as tables built on all rows at once."""
    df = _rows(seed=2)
    part = pd.factorize(df[ACCOUNT])[0] % 3
    added = visa_view.combine([visa_view.build_visa_tables(df[part == f]) for f in range(3)])
    whole = visa_view.build_visa_tables(df)
    assert added[0][visa_view.bin_names()].to_numpy().sum() == df[SCORE].notna().sum()
    a, b = visa_view.visa_features(df, *added), visa_view.visa_features(df, *whole)
    assert np.allclose(a.to_numpy(), b.to_numpy(), rtol=1e-5, atol=1e-5, equal_nan=True)


def test_missing_columns_are_skipped_and_the_command_line_runs(capsys):
    """Without the score nothing is built and nothing stops; without the category all columns come; the tool runs."""
    df = _rows(seed=3, n_accounts=30)
    _panel._SAID.clear()
    tabs = visa_view.build_visa_tables(df.drop(columns=[SCORE]))
    assert tabs == (None, None)
    assert visa_view.visa_features(df, *tabs).shape == (len(df), 0)
    bare = df.drop(columns=[MCC])
    got = visa_view.visa_features(bare, *visa_view.build_visa_tables(bare))
    assert got.shape[1] == 10 and np.isfinite(got.to_numpy()[~np.isnan(got.to_numpy())]).all()
    assert "note:" in capsys.readouterr().out
    frame = visa_view.main(["--demo"])
    assert frame.shape[1] == 10 and "visa_own_pct_30d" in capsys.readouterr().out
