"""Tests of the diagnosis tables.

The slice inputs are compared with plain loops over each account's earlier rows, the catch
matrix with set arithmetic, the headroom lines with direct captures and a plain union, every
slice line with a count over each model's alert set, and the stack and the tree are shown to
be honest: what a row receives never depends on the labels of its own half of the accounts.
"""
import numpy as np
import pandas as pd
import pytest

from additions import settings
from additions.common import ranking, synthetic, tables
from additions.proof import _shared, diagnosis

STANDARD = [settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL, settings.LABEL_COL, settings.AMOUNT_COL,
            settings.SCORE_COL]


@pytest.fixture(scope="module")
def table():
    """Made-up whole accounts over two months with three scores of different strength."""
    df = synthetic.make_transactions(n_accounts=900, seed=51, fraud_account_share=0.15, tie_share=0.06)
    df = synthetic.make_scores(df, seed=51, strength=2.5)
    df = synthetic.make_scores(df, seed=52, strength=2.0, column="second")
    return synthetic.make_scores(df, seed=53, strength=1.5, column="third")


@pytest.fixture(scope="module")
def june(table):
    """The ranked rows with their labels, accounts, slice inputs and the three scores."""
    ranked = _shared.ranked_rows(table)
    part = table[ranked].reset_index(drop=True)
    inputs = diagnosis.slice_inputs(table)[ranked].reset_index(drop=True)
    return {"frame": part, "labels": _shared.fraud_flags(part), "units": _shared.account_codes(part), "inputs": inputs,
            "scores": {"first": part[settings.SCORE_COL].to_numpy(), "second": part["second"].to_numpy(),
                       "third": part["third"].to_numpy()}}


def test_slice_inputs_equal_plain_loops_and_use_only_earlier_seconds(table):
    """Earlier-row counts, same-second flags and earlier declines match loops, and later rows change nothing."""
    small = table[table[settings.ACCOUNT_COL].isin(table[settings.ACCOUNT_COL].unique()[:40])].reset_index(drop=True)
    inputs = diagnosis.slice_inputs(small)
    secs = _shared.row_seconds(small)
    accounts = small[settings.ACCOUNT_COL].to_numpy()
    approved = _shared.approved_rows(small)
    for i in range(0, len(small), 7):
        same = accounts == accounts[i]
        earlier = same & (secs < secs[i])
        assert inputs["earlier_rows"][i] == earlier.sum()
        assert inputs["same_second"][i] == ((same & (secs == secs[i])).sum() > 1)
        assert inputs["decline_24h"][i] == (earlier & (secs >= secs[i] - 86_400) & ~approved).any()
        assert inputs["hour_of_day"][i] == (secs[i] % 86_400) // 3_600
    fraud = _shared.fraud_flags(small) > 0
    assert inputs["run_position"][~fraud].isna().all() and (inputs["run_position"][fraud] >= 1).all()
    # Cutting the table at a time leaves every input of the rows before the cut unchanged.
    cut = np.sort(secs)[len(secs) // 2]
    early = diagnosis.slice_inputs(small[secs < cut].reset_index(drop=True))
    assert early.equals(inputs[secs < cut].reset_index(drop=True))


def test_slice_bands_and_missing_columns(table, capsys):
    """Bands follow the edges, and a missing column skips its slice with one printed line."""
    inputs = diagnosis.slice_inputs(table.head(3000))
    bands = diagnosis.slice_bands(inputs)
    assert set(bands.columns) == {"run position", "since previous fraud", "amount band", "card present", "earlier rows",
                                  "same second", "risk-score band", "decline in previous 24h"}
    amount = inputs["amount"].to_numpy()
    assert (bands["amount band"][amount < 10] == "under 10").all()
    assert (bands["amount band"][amount >= 1000] == "1000+").all()
    assert (bands["earlier rows"][inputs["earlier_rows"] == 0] == "0").all()
    bare = table.head(3000).drop(columns=[settings.VISA_SCORE_COL, settings.CARD_PRESENT_COL, settings.REASON_COL,
                                          settings.DECLINE_FLAG_COL])
    thin = diagnosis.slice_bands(diagnosis.slice_inputs(bare))
    printed = capsys.readouterr().out
    assert "risk-score slice is skipped" in printed and "card-present slice is skipped" in printed
    assert "approved-row part is skipped" in printed
    assert not {"risk-score band", "card present", "decline in previous 24h"} & set(thin.columns)


def test_catch_matrix_is_plain_set_arithmetic(june):
    """Every pattern count and every pair count equals the matching intersection of the alert sets."""
    patterns, pairs = diagnosis.catch_matrix(june["labels"], june["scores"])
    fraud = june["labels"] > 0
    sets = {name: ranking.alert_mask(s) for name, s in june["scores"].items()}
    assert len(patterns) == 8 and patterns["frauds"].sum() == fraud.sum()
    for line in patterns.itertuples():
        here = np.ones(len(fraud), dtype=bool)
        for name in sets:
            here &= sets[name] if getattr(line, name) else ~sets[name]
        assert line.frauds == (here & fraud).sum()
    alerted_any = np.logical_or.reduce(list(sets.values()))
    assert patterns["alerted_non_frauds"].sum() == (alerted_any & ~fraud).sum()
    names = [(p.first, p.second) for p in pairs.itertuples()]
    assert names == [("first", "second"), ("first", "third"), ("second", "third")]
    for p in pairs.itertuples():
        a, b = set(np.flatnonzero(sets[p.first] & fraud)), set(np.flatnonzero(sets[p.second] & fraud))
        assert p.both == len(a & b) and p.only_a == len(a - b) and p.only_b == len(b - a)
        assert np.isclose(p.jaccard, len(a & b) / len(a | b))


def test_headroom_lines_are_direct_captures_and_the_union_is_an_upper_bound(june):
    """Each model line equals ranking.capture, the union is a plain union, and the stack is read out of fold."""
    room = diagnosis.headroom(june["labels"], june["scores"], june["units"], seed=4)
    assert set(room["reader"]) == {"first", "second", "third", "rank average", "stack (two folds by account)",
                                   "union (upper bound)"}
    for line in room.itertuples():
        per_mille = int(round(line.percent * 10))
        if line.reader in june["scores"]:
            direct = ranking.capture(june["labels"], june["scores"][line.reader], None, per_mille)
            assert np.isclose(line.caught, direct["caught"])
        if line.reader == "union (upper bound)":
            union = np.logical_or.reduce([ranking.alert_mask(s, per_mille) for s in june["scores"].values()])
            assert line.alerts == union.sum() and line.caught == june["labels"][union].sum()
            best = room[(room["percent"] == line.percent) & room["reader"].isin(list(june["scores"]))]["caught"].max()
            assert line.caught >= best
        else:
            assert line.alerts == ranking.cut_size(len(june["labels"]), per_mille)


def test_stack_never_sees_the_labels_of_the_half_it_scores(june):
    """Changing the labels of one half of the accounts leaves the stack scores of that half unchanged."""
    fold = _shared.account_folds(june["units"], 2, 4)
    base = diagnosis.stack_scores(june["labels"], june["scores"], june["units"], seed=4)
    flipped = june["labels"].copy()
    flipped[fold == 0] = 1.0 - flipped[fold == 0]
    again = diagnosis.stack_scores(flipped, june["scores"], june["units"], seed=4)
    assert np.allclose(base[fold == 0], again[fold == 0]) and not np.allclose(base[fold == 1], again[fold == 1])
    assert np.isfinite(base).all()
    ranks = diagnosis.rank_logits(june["scores"]["first"])
    assert np.array_equal(np.argsort(ranks, kind="stable"), np.argsort(june["scores"]["first"], kind="stable"))


def test_slice_lines_equal_counts_over_the_global_alert_sets(june):
    """Capture, alert share and precision per slice come from the global cut; the gap is the capture difference."""
    bands = diagnosis.slice_bands(june["inputs"])
    table = diagnosis.slice_table(bands, june["labels"], june["scores"], june["units"], draws=200, seed=2)
    fraud = june["labels"] > 0
    sets = {name: ranking.alert_mask(s) for name, s in june["scores"].items()}
    k = ranking.cut_size(len(fraud))
    for line in table.itertuples():
        here = bands[line.slice].to_numpy() == line.value
        assert line.rows == here.sum() and line.frauds == (here & fraud).sum()
        for name, mask in sets.items():
            assert np.isclose(getattr(line, f"caught_{name}"), (here & fraud & mask).sum())
            assert np.isclose(getattr(line, f"alert_share_{name}"), (here & mask).sum() / k)
        if line.frauds:
            first, second = (here & fraud & sets["first"]).sum(), (here & fraud & sets["second"]).sum()
            assert np.isclose(line.capture_first, first / line.frauds)
            assert np.isclose(line.gap, (first - second) / line.frauds)
            assert line.low - 1e-12 <= line.gap <= line.high + 1e-12
    for (_, name), shares in table.groupby("slice")[[f"alert_share_{m}" for m in sets]].sum().stack().items():
        assert np.isclose(shares, 1.0)                 # every alert falls in exactly one value of each slice
    ok = table["p_value"].notna()
    # The q-values against the textbook rule, written out slowly: sort the p-values, scale the i-th
    # smallest by (number of tests / i), and let no larger p-value have a smaller q-value.
    p_sorted = np.sort(table.loc[ok, "p_value"].to_numpy())
    scaled = p_sorted * len(p_sorted) / np.arange(1, len(p_sorted) + 1)
    by_hand = np.minimum(1.0, [scaled[i:].min() for i in range(len(scaled))])
    assert np.allclose(np.sort(table.loc[ok, "q_value"].to_numpy()), by_hand)
    order = np.argsort(table.loc[ok, "p_value"].to_numpy(), kind="stable")
    assert np.all(np.diff(table.loc[ok, "q_value"].to_numpy()[order]) >= -1e-12)     # q rises with p


def test_disagreement_tree_is_grown_on_one_half_and_counted_on_the_other(june):
    """A planted split is found; leaves count every held discordant fraud; held labels never move the rules."""
    inputs = june["inputs"][june["labels"] > 0].reset_index(drop=True)
    units = june["units"][june["labels"] > 0]
    rng = np.random.default_rng(0)
    # Model A wins on the large amounts, model B on the small ones, with some noise.
    big = inputs["amount"].to_numpy() > 60
    only_a = np.where(rng.random(len(inputs)) < 0.85, big, ~big)
    only_b = ~only_a
    tree = diagnosis.disagreement_tree(inputs, only_a, only_b, units, min_leaf=15, seed=3)
    held = _shared.account_folds(units, 2, 3) == 1
    assert tree["held_only_a"].sum() == (only_a & held).sum() and tree["held_only_b"].sum() == (only_b & held).sum()
    assert (tree["grown_only_a"] + tree["grown_only_b"]).min() >= 15
    assert tree["rule"].str.contains("amount").all()
    assert tree["held_gap"].max() > 0.4 and tree["held_gap"].min() < -0.4 and tree["q_value"].min() < 0.05
    # Changing who caught the held frauds changes the counts, never the tree.
    swapped_a = np.where(held, ~only_a, only_a)
    other = diagnosis.disagreement_tree(inputs, swapped_a, ~swapped_a, units, min_leaf=15, seed=3)
    assert other["rule"].tolist() == tree["rule"].tolist()
    assert other["grown_only_a"].tolist() == tree["grown_only_a"].tolist()
    assert other["held_only_a"].tolist() == tree["held_only_b"].tolist()


def test_too_few_discordant_frauds_skip_the_tree(june, capsys):
    """With fewer frauds than two leaves need, the tree is skipped with one line instead of stopping the run."""
    inputs = june["inputs"].head(30)
    flags = np.arange(30) % 2 == 0
    assert diagnosis.disagreement_tree(inputs, flags, ~flags, np.arange(30), min_leaf=40) is None
    assert "disagreement tree; it is skipped" in capsys.readouterr().out


def test_diagnose_ranks_only_the_scored_month(table):
    """History rows take no alert place: giving them the top score changes no table."""
    scores = {"first": table[settings.SCORE_COL].to_numpy(), "second": table["second"].to_numpy()}
    base = diagnosis.diagnose(table, scores, draws=50, seed=1, tree_min_leaf=10)
    ranked = _shared.ranked_rows(table)
    lifted = {name: np.where(ranked, s, 2.0) for name, s in scores.items()}
    again = diagnosis.diagnose(table, lifted, draws=50, seed=1, tree_min_leaf=10)
    for key in ("patterns", "pairs", "headroom", "slices"):
        assert base[key].equals(again[key]), key
    assert base["patterns"]["frauds"].sum() == _shared.fraud_flags(table)[ranked].sum()


def test_tool_prints_every_table_and_writes_the_slices(table, tmp_path, capsys):
    """The tool reads three score files, joins the slice columns from raw files and writes the slice table."""
    first = tables.write_table(table[STANDARD], str(tmp_path / "first.parquet"))
    paths = [first]
    for name in ("second", "third"):
        part = table[[settings.ID_COL, name]].rename(columns={name: settings.SCORE_COL})
        paths.append(tables.write_table(part, str(tmp_path / f"{name}.parquet")))
    numbers = synthetic.write_files(table, tmp_path / "raw", 2, first_number=70)
    out = str(tmp_path / "slices.parquet")
    diagnosis.main(["--preds", *paths, "--names", "a", "b", "c", "--draws", "30", "--min-leaf", "10",
                    "--raw-base", str(tmp_path / "raw"), "--raw-files", f"{numbers[0]}-{numbers[-1]}", "--out", out])
    printed = capsys.readouterr().out
    for title in ("Catch matrix", "Pairs:", "Headroom", "Capture by slice", "Disagreement tree"):
        assert title in printed
    assert "risk-score slice is skipped" not in printed
    written = tables.read_columns(out)
    assert {"slice", "value", "capture_a", "capture_c", "alert_share_b", "gap", "q_value"} <= set(written.columns)
    assert "decline in previous 24h" in set(written["slice"])
    diagnosis.main(["--preds", paths[0], paths[1], "--draws", "20"])
    assert "risk-score slice is skipped" in capsys.readouterr().out          # the score files hold no raw columns
    diagnosis.main(["--preds", paths[0], paths[1], "--start", "2031-01-01", "--end", "2031-02-01"])
    assert "no row falls in the scored month" in capsys.readouterr().out
