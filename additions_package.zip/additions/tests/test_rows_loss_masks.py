"""Tests of the loss weights that leave never-labelled row types out of the loss.

The weights are compared with a slow row-by-row rule, the rows with weight zero are shown to
stay in the chunks as history, and the scoring rule is shown to move only the marked rows.
"""
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

from additions import settings
from additions.common import ranking, synthetic
from additions.training import loss_masks
from additions.training._loss_shared import account_chunks, weighted_mean
from additions.training.loss_masks import (chunk_weights, class_table, loss_weights, never_labelled,
                                           rank_never_labelled_last, row_classes)


def _rows(seed=0, n_accounts=120):
    """Made-up raw rows with declines, advice rows and zero-dollar checks."""
    return synthetic.make_transactions(n_accounts=n_accounts, seed=seed, fraud_account_share=0.3)


def _slow_weight(row, drop, excluded=()):
    """The loss weight of one row, decided with plain if-statements."""
    declined = str(row[settings.DECLINE_FLAG_COL]) in settings.DECLINE_FLAG_VALUES
    risk = str(row[settings.REASON_COL]).strip() in settings.RISK_DECLINE_REASONS
    advice = row[settings.ADVICE_COL] is not None and not pd.isna(row[settings.ADVICE_COL]) \
        and str(row[settings.ADVICE_COL]).strip() not in loss_masks.ADVICE_EMPTY_VALUES
    zero = str(row[settings.TYPE_COL]).strip() in settings.ZERO_CHECK_TYPES
    segment = str(row[settings.SEGMENT_COL]).strip() in excluded
    hit = {"declined": declined, "risk_decline": risk, "advice": advice, "zero_check": zero,
           "excluded_segment": segment}
    return 0.0 if any(hit[name] for name in drop) else 1.0


def test_weights_equal_the_slow_rule():
    """Every row's weight equals the plain if-statement rule, for the default and the narrow variant."""
    df = _rows()
    excluded = ("3. ATM",)
    for drop in (loss_masks.DEFAULT_DROP, ("risk_decline",), ("advice", "zero_check")):
        got = loss_weights(df, drop=drop, excluded_segments=excluded)
        slow = np.array([_slow_weight(r, drop, excluded) for _, r in df.iterrows()], dtype=np.float32)
        assert got.dtype == np.float32 and np.array_equal(got, slow)
    # The narrow variant drops a subset of what the flag drops in the made-up data.
    narrow = loss_weights(df, drop=("risk_decline",))
    flag = loss_weights(df, drop=("declined",))
    assert ((narrow == 0) <= (flag == 0)).all() and (narrow == 0).sum() < (flag == 0).sum()


def test_no_fraud_label_is_dropped_and_the_table_counts_rows():
    """The dropped row types carry no fraud label, and the table counts match the arrays."""
    df = _rows(seed=1)
    classes = row_classes(df)
    weight = loss_weights(df, classes=classes)
    fraud = df[settings.LABEL_COL].to_numpy() == settings.POSITIVE_LABEL
    assert fraud.any() and (weight[fraud] == 1.0).all()
    table = class_table(df, classes, weight).set_index("row_type")
    assert table.loc["in the loss", "rows"] == int((weight > 0).sum())
    assert table.loc["in the loss", "fraud_rows"] == int(fraud.sum())
    assert table.loc["advice", "rows"] == int(classes["advice"].sum())
    assert (table["fraud_rows"].drop("in the loss") == 0).all()


def test_missing_column_switches_its_row_type_off(capsys):
    """A column that is absent or set to None drops nothing and prints one line; the run goes on."""
    df = _rows(seed=2).drop(columns=[settings.ADVICE_COL])
    weight = loss_weights(df, type_col=None, zero_check_types=None)
    assert "advice" in capsys.readouterr().out
    off = loss_weights(df, decline_flag_col="", type_col="no_such_column")
    out = capsys.readouterr().out
    assert "decline flag" in out and "no_such_column" in out
    classes = row_classes(df)
    assert "advice" not in classes and "excluded_segment" not in classes   # no excluded segment is set
    assert (off >= weight).all()


def test_dropped_rows_stay_in_the_chunks_as_history():
    """Weight zero switches only the loss off: the chunk layout and its valid mask are unchanged."""
    df = _rows(seed=3)
    weight = loss_weights(df)
    chunks = account_chunks(df, [settings.LABEL_COL], width=9)
    w = chunk_weights(weight, chunks)
    valid, row = chunks["valid"], chunks["row"]
    assert w.shape == valid.shape and (w[~valid] == 0).all()
    assert torch.equal(w[valid], torch.as_tensor(weight)[row[valid]])
    dropped_real = valid & (w == 0)
    assert dropped_real.any()                                  # dropped rows are still real slots
    # The weighted loss equals the plain mean over the kept rows only.
    logits = torch.randn(valid.shape, generator=torch.Generator().manual_seed(0), requires_grad=True)
    labels = chunks[settings.LABEL_COL].clamp_min(0).float()
    per_row = F.binary_cross_entropy_with_logits(logits, labels, reduction="none")
    loss = weighted_mean(per_row, w)
    kept = valid & (w > 0)
    assert torch.isclose(loss, per_row[kept].mean())
    loss.backward()
    assert (logits.grad[dropped_real] == 0).all() and (logits.grad[kept] != 0).any()


def test_never_labelled_rows_rank_last_and_others_keep_their_order():
    """Marked rows fall below every other row; the order of the rest and the capture rule are unchanged."""
    df = synthetic.make_scores(_rows(seed=4), seed=4)
    never = never_labelled(df)
    reason = df[settings.REASON_COL].astype(str).to_numpy()
    assert never[reason != settings.APPROVED_REASONS[0]].all()          # every non-approved row is marked
    fraud = df[settings.LABEL_COL].to_numpy() == settings.POSITIVE_LABEL
    assert not (never & fraud).any()
    scores = df[settings.SCORE_COL].to_numpy()
    ranked = rank_never_labelled_last(scores, never)
    assert ranked[never].max() < ranked[~never].min()
    assert np.array_equal(ranked[~never], scores[~never]) and np.array_equal(scores, df[settings.SCORE_COL])
    # Moving rows that can never be fraud down can only keep or raise the frauds caught.
    assert ranking.capture(fraud, ranked)["caught"] >= ranking.capture(fraud, scores)["caught"]
    as_tensor = rank_never_labelled_last(torch.tensor(scores), never)
    assert torch.is_tensor(as_tensor) and np.allclose(as_tensor.numpy(), ranked)


def test_command_line_demo_writes_the_weights(tmp_path):
    """The demo prints a table and writes one weight per row with the transaction id."""
    out = tmp_path / "weights.parquet"
    weight = loss_masks.main(["--demo", "--drop", "risk_decline", "advice", "--out", str(out)])
    written = pd.read_parquet(out)
    assert list(written.columns) == [settings.ID_COL, "loss_weight"]
    assert np.array_equal(written["loss_weight"].to_numpy(), weight)
