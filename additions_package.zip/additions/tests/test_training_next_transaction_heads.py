"""Tests of the next-transaction heads and the surprise columns.

The targets, the "state before" and the surprise columns are compared with slow loops over
small made-up chunks. Further tests check that a row with no later row adds nothing to the
loss, that rows of one second never see each other, and that later rows do not change what
an earlier row is given.
"""
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

from additions import settings
from additions.common import synthetic, timekeys
from additions.training._loss_shared import account_chunks
from additions.training.next_transaction_heads import (AMOUNT_BIN_EDGES, GAP_BIN_EDGES, NextTransactionHeads,
                                                       field_classes, field_sizes, next_field_losses,
                                                       shift_targets, smoothed_bins, state_before, surprise,
                                                       total_loss)


def _chunks(seed=0, n_chunks=6, width=9):
    """Random chunks: real rows fill each chunk from the left, times rise with many same-second ties."""
    rng = np.random.default_rng(seed)
    valid = np.zeros((n_chunks, width), dtype=bool)
    times = np.zeros((n_chunks, width), dtype=np.int64)
    for b in range(n_chunks):
        n = int(rng.integers(1, width + 1))
        valid[b, :n] = True
        times[b, :n] = 1_000 + np.cumsum(rng.integers(0, 3, n))          # steps of 0 make same-second rows
    values = rng.integers(0, 50, (n_chunks, width))
    return torch.tensor(valid), torch.tensor(times), torch.tensor(values)


def _slow_next(valid, times, use_times):
    """The slot of the row that follows each row, by a plain loop; -1 where none follows."""
    out = np.full(valid.shape, -1)
    for b in range(valid.shape[0]):
        for i in range(valid.shape[1]):
            if not valid[b, i]:
                continue
            later = [j for j in range(valid.shape[1]) if valid[b, j] and
                     (times[b, j] > times[b, i] if use_times else j > i)]
            if later:
                first = min(times[b, j] for j in later) if use_times else None
                out[b, i] = min(j for j in later if not use_times or times[b, j] == first)
    return out


def _slow_before(valid, times):
    """The slot of the last row of the latest strictly earlier second, by a plain loop; -1 where none."""
    out = np.full(valid.shape, -1)
    for b in range(valid.shape[0]):
        for i in range(valid.shape[1]):
            earlier = [j for j in range(valid.shape[1]) if valid[b, i] and valid[b, j] and times[b, j] < times[b, i]]
            if earlier:
                latest = max(times[b, j] for j in earlier)
                out[b, i] = max(j for j in earlier if times[b, j] == latest)
    return out


def test_shift_targets_equals_a_slow_loop():
    """Each row's target is the value of the first row of the next later second, or of the next real row."""
    valid, times, values = _chunks()
    for use_times in (True, False):
        targets, has_next = shift_targets(values, valid, times if use_times else None)
        slow = _slow_next(valid.numpy(), times.numpy(), use_times)
        assert np.array_equal(has_next.numpy(), slow >= 0)
        expected = np.where(slow >= 0, np.take_along_axis(values.numpy(), np.maximum(slow, 0), axis=1), -1)
        assert np.array_equal(targets.numpy(), expected)
    # Values with an extra dimension are moved the same way.
    wide = torch.stack([values, values * 10], dim=-1)
    targets, _ = shift_targets(wide, valid, times)
    assert torch.equal(targets[..., 1], torch.where(targets[..., 0] >= 0, targets[..., 0] * 10, -1))


def test_rows_of_one_second_share_a_target_and_never_target_each_other():
    """Rows of the same second get the same target, and it comes from a strictly later second."""
    valid, times, values = _chunks(seed=1)
    index_targets, has_next = shift_targets(torch.arange(valid.shape[1]).expand_as(values), valid, times)
    for b in range(valid.shape[0]):
        for i in range(valid.shape[1]):
            if has_next[b, i]:
                assert times[b, index_targets[b, i]] > times[b, i]
                same = (times[b] == times[b, i]) & valid[b]
                assert (index_targets[b][same] == index_targets[b, i]).all()


def test_shift_targets_never_cross_from_one_account_into_the_next():
    """On chunks of a real table, the target of a row always comes from a later row of the same account."""
    df = synthetic.make_transactions(n_accounts=30, seed=4, tie_share=0.2)
    chunks = account_chunks(df, width=6)
    row, valid, times = chunks["row"], chunks["valid"], chunks["times"]
    next_row, has_next = shift_targets(row, valid, times)
    account = timekeys.codes(df[settings.ACCOUNT_COL])
    secs = timekeys.seconds(df[settings.TIME_COL])
    mine, theirs = row[has_next].numpy(), next_row[has_next].numpy()
    assert (account[mine] == account[theirs]).all()
    assert (secs[theirs] > secs[mine]).all()
    # The last second of every chunk has no target, even when the account goes on in the next chunk.
    last_second = (times == torch.where(valid, times, -1).max(dim=1, keepdim=True).values) & valid
    assert not has_next[last_second].any()
    assert not has_next[~valid].any() and (next_row[~has_next] == -1).all()


def test_state_before_equals_a_slow_loop_and_ignores_later_and_same_second_rows():
    """The state given to a row is the last row of the latest earlier second; later or tied rows never change it."""
    valid, times, _ = _chunks(seed=2)
    per_row = torch.randn(valid.shape + (4,), generator=torch.Generator().manual_seed(2))
    before, has_before = state_before(per_row, valid, times)
    slow = _slow_before(valid.numpy(), times.numpy())
    assert np.array_equal(has_before.numpy(), slow >= 0)
    for b, i in zip(*np.nonzero(slow >= 0)):
        assert torch.equal(before[b, i], per_row[b, slow[b, i]])
    # Change one row: no row of its own second or of an earlier second gets a different state.
    b = int(np.argmax(valid.sum(dim=1).numpy()))
    j = int(valid[b].sum()) // 2
    changed = per_row.clone()
    changed[b, j] += 100.0
    again, _ = state_before(changed, valid, times)
    untouched = valid[b] & (times[b] <= times[b, j])
    assert torch.equal(again[b][untouched], before[b][untouched])


def test_rows_with_no_later_row_add_nothing_to_the_loss():
    """Changing the logits of rows that no row follows leaves every field loss unchanged and gives them no gradient."""
    valid, times, values = _chunks(seed=3)
    sizes = {"category": 51, "amount_bin": 11}
    generator = torch.Generator().manual_seed(3)
    logits = {field: torch.randn(valid.shape + (n,), generator=generator, requires_grad=True)
              for field, n in sizes.items()}
    targets = {}
    for field, n in sizes.items():
        targets[field], has_next = shift_targets(values % n, valid, times)
    base = next_field_losses(logits, targets, has_next)
    sum(base.values()).backward()
    for field in sizes:
        assert torch.equal(logits[field].grad[~has_next], torch.zeros_like(logits[field].grad[~has_next]))
        assert logits[field].grad[has_next].abs().sum() > 0
    moved = {field: torch.where(has_next.unsqueeze(-1), l.detach(), l.detach() + 50.0) for field, l in logits.items()}
    again = next_field_losses(moved, targets, has_next)
    for field in sizes:
        assert torch.isclose(again[field], base[field])
    # The plain field is the mean cross-entropy over the rows that have a next row.
    slow = F.cross_entropy(logits["category"].detach()[has_next], targets["category"][has_next])
    assert torch.isclose(base["category"], slow)


def test_smoothed_bins_sum_to_one_and_peak_at_the_true_bin():
    """Every line of soft targets sums to one, is largest at the true band and falls off with distance."""
    targets = torch.tensor([0, 3, 7, 10])
    soft = smoothed_bins(targets, 11, width=1.5)
    assert soft.shape == (4, 11)
    assert torch.allclose(soft.sum(dim=-1), torch.ones(4))
    assert torch.equal(soft.argmax(dim=-1), targets)
    for line, t in zip(soft, targets.tolist()):
        assert (torch.diff(line[t:]) <= 0).all() and (torch.diff(line[: t + 1]) >= 0).all()
    assert torch.equal(smoothed_bins(targets, 11, width=0), F.one_hot(targets, 11).float())


def test_surprise_equals_the_slow_negative_log_probability_entropy_and_rank():
    """Per field the nll, entropy and rank columns match a slow loop; rows without a value stay missing."""
    generator = torch.Generator().manual_seed(5)
    logits = {"category": torch.randn(12, 7, generator=generator), "gap_bin": torch.randn(12, 4, generator=generator)}
    observed = {"category": torch.randint(0, 7, (12,), generator=generator),
                "gap_bin": torch.randint(0, 4, (12,), generator=generator)}
    observed["gap_bin"][[1, 4]] = -1
    has_before = torch.ones(12, dtype=torch.bool)
    has_before[0] = False
    columns = surprise(logits, observed, has_before)
    for field in logits:
        for r in range(12):
            p = np.exp(logits[field][r].numpy().astype(np.float64))
            p /= p.sum()
            o = int(observed[field][r])
            got = [columns[f"surprise_{field}_{k}"][r].item() for k in ("nll", "entropy", "rank")]
            if o < 0 or not has_before[r]:
                assert all(np.isnan(got))
                continue
            assert np.isclose(got[0], -np.log(p[o]), atol=1e-5)
            assert np.isclose(got[1], -(p * np.log(p)).sum(), atol=1e-5)
            assert got[2] == 1 + sum(p[k] > p[o] for k in range(len(p)))
    total = columns["surprise_total"].numpy()
    slow = np.nansum(np.stack([columns["surprise_category_nll"].numpy(), columns["surprise_gap_bin_nll"].numpy()]), 0)
    assert np.isnan(total[0]) and np.allclose(total[1:], slow[1:])
    assert columns["surprise_has_before"].tolist() == has_before.float().tolist()


def test_field_classes_equal_a_slow_computation():
    """Amount band, gap band and "merchant used before" match plain loops over a small table."""
    df = synthetic.make_transactions(n_accounts=12, days=20, seed=6, tie_share=0.25)
    df.loc[df.index[::11], settings.MERCHANT_COL] = np.nan
    classes = field_classes(df)
    vocabulary = classes.attrs["vocabulary"]
    secs = timekeys.seconds(df[settings.TIME_COL])
    account = df[settings.ACCOUNT_COL].to_numpy()
    merchant = df[settings.MERCHANT_COL].to_numpy()
    for r in range(len(df)):
        earlier = (account == account[r]) & (secs < secs[r])
        amount = df[settings.AMOUNT_COL].iloc[r]
        assert classes["amount_bin"].iloc[r] == sum(edge <= amount for edge in AMOUNT_BIN_EDGES)
        if earlier.any():
            gap = secs[r] - secs[earlier].max()
            assert classes["gap_bin"].iloc[r] == sum(edge <= gap for edge in GAP_BIN_EDGES)
        else:
            assert classes["gap_bin"].iloc[r] == -1
        if pd.isna(merchant[r]):
            assert classes["repeat_merchant"].iloc[r] == -1
        else:
            assert classes["repeat_merchant"].iloc[r] == int((earlier & (merchant == merchant[r])).any())
        mcc = str(int(df[settings.MCC_COL].iloc[r]))
        expected = vocabulary.index(mcc) if mcc in vocabulary else len(vocabulary)
        assert classes["category"].iloc[r] == expected
    assert len(field_sizes(vocabulary)) == 4


def test_a_missing_column_skips_its_field():
    """A field whose column is absent is left out with one printed line; the others are still made."""
    df = synthetic.make_transactions(n_accounts=4, seed=7).drop(columns=[settings.MERCHANT_COL])
    classes = field_classes(df)
    assert "repeat_merchant" not in classes.columns and {"category", "amount_bin", "gap_bin"} <= set(classes.columns)


def test_heads_shapes_gradient_flow_and_the_cap():
    """The heads give logits per field, gradients reach the row vectors, and no field loss exceeds the main one."""
    valid, times, values = _chunks(seed=8)
    heads = NextTransactionHeads(field_sizes(["a", "b", "c"]), dim=16)
    vectors = torch.randn(valid.shape + (16,), requires_grad=True)
    logits = heads(vectors)
    assert {f: tuple(l.shape) for f, l in logits.items()} == {
        "category": valid.shape + (4,), "amount_bin": valid.shape + (11,),
        "gap_bin": valid.shape + (8,), "repeat_merchant": valid.shape + (2,)}
    targets = {}
    for field, l in logits.items():
        targets[field], has_next = shift_targets(values % l.shape[-1], valid, times)
    main = torch.tensor(0.05)
    loss = total_loss(main, logits, targets, has_next)
    assert torch.isfinite(loss) and loss.item() <= 2 * main.item() + 1e-6
    loss.backward()
    assert torch.isfinite(vectors.grad).all() and vectors.grad.abs().sum() > 0
