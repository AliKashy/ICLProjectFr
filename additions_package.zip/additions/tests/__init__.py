"""Small tests on made-up data. Each test file doubles as a usage example of its module."""
