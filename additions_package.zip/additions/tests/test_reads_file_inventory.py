"""Tests of the file inventory and of the split into fresh blocks.

The per-file counts are compared with counts made the slow way on the whole file, and the
blocks are checked for the properties that make them usable: right size, no file twice, no
file lost.
"""
import numpy as np
import pandas as pd
import pytest

from additions import settings
from additions.common import synthetic, tables
from additions.reads import _rows, file_inventory


@pytest.fixture(scope="module")
def files(tmp_path_factory):
    """Six numbered files of made-up rows that each hold whole accounts."""
    folder = tmp_path_factory.mktemp("files")
    df = synthetic.make_transactions(n_accounts=180, seed=6)
    numbers = synthetic.write_files(df, folder, 6, first_number=8301)
    return df, folder, numbers


def test_inventory_matches_a_slow_count_per_file(files):
    """Rows, accounts, frauds, fraud accounts, months and scored-month frauds agree with the whole file."""
    df, folder, numbers = files
    table = file_inventory.inventory(folder, numbers)
    assert table["file"].tolist() == numbers
    for line in table.to_dict("records"):
        part = tables.read_columns(tables.file_path(folder, line["file"]))      # every column, the slow way
        fraud = (part[settings.LABEL_COL] == settings.POSITIVE_LABEL).to_numpy()
        in_month = _rows.in_scored_month(part)
        account = part[settings.ACCOUNT_COL]
        assert line["rows"] == len(part) and line["accounts"] == account.nunique()
        assert line["frauds"] == fraud.sum() and line["fraud_accounts"] == account[fraud].nunique()
        assert line["scored_rows"] == in_month.sum() and line["scored_frauds"] == (fraud & in_month).sum()
        assert line["scored_fraud_accounts"] == account[fraud & in_month].nunique()
        months = sorted(set(pd.to_datetime(part[settings.TIME_COL]).dt.strftime("%Y-%m")))
        assert line["months"] == " ".join(months) and line["repeated_ids"] == 0
    assert table["rows"].sum() == len(df) and table["accounts"].sum() == df[settings.ACCOUNT_COL].nunique()
    totals = file_inventory.cumulative(table)
    assert totals["files"].tolist() == [1, 2, 3, 4, 5, 6] and totals["file"].tolist() == numbers
    assert totals["rows"].tolist() == np.cumsum(table["rows"]).tolist()
    assert totals["fraud_accounts"].iloc[-1] == df.loc[df[settings.LABEL_COL] == 1, settings.ACCOUNT_COL].nunique()


def test_only_four_columns_are_read(files, monkeypatch):
    """The inventory asks the reader for the id, account, time and label columns and for nothing else."""
    _, folder, numbers = files
    asked = []
    real = tables.read_columns

    def recording(path, columns=None, *args, **kwargs):
        asked.append(list(columns))
        return real(path, columns, *args, **kwargs)

    monkeypatch.setattr(tables, "read_columns", recording)
    file_inventory.inventory(folder, numbers[:2])
    four = sorted([settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL, settings.LABEL_COL])
    assert len(asked) == 2 and all(sorted(columns) == four for columns in asked)


def test_an_unreadable_file_is_reported_and_left_out(files, capsys):
    """A file that is not there costs one line; the other files are still counted."""
    _, folder, numbers = files
    table = file_inventory.inventory(folder, [numbers[0], 99_999, numbers[1]], check_accounts=True)
    assert table["file"].tolist() == numbers[:2] and "file 99999" in capsys.readouterr().out
    assert table["accounts_seen_before"].tolist() == [0, 0]            # two files share no account
    # The same file listed twice: on the second pass every one of its accounts was seen before.
    twice = file_inventory.inventory(folder, [numbers[0], numbers[0]], check_accounts=True)
    assert twice["accounts_seen_before"].tolist() == [0, twice.loc[0, "accounts"]]
    assert len(file_inventory.inventory(folder, [99_999])) == 0 and len(file_inventory.cumulative(pd.DataFrame())) == 0


def test_repeated_ids_and_missing_columns_do_not_stop_the_inventory(tmp_path, capsys):
    """A file with a repeated id, or without a label or time column, is still counted."""
    df = synthetic.make_transactions(n_accounts=10, seed=7)
    doubled = pd.concat([df, df.head(3)], ignore_index=True)
    tables.write_table(doubled, tables.file_path(tmp_path, 1))
    line = file_inventory.inventory(tmp_path, [1]).iloc[0]
    assert line["rows"] == len(df) + 3 and line["repeated_ids"] == 3
    bare = df.drop(columns=[settings.LABEL_COL, settings.TIME_COL, settings.ID_COL])
    tables.write_table(bare, tables.file_path(tmp_path, 2))
    capsys.readouterr()
    line = file_inventory.inventory(tmp_path, [2]).iloc[0]
    assert "has no column(s)" in capsys.readouterr().out                # the reader names what is missing
    assert line["rows"] == len(df) and line["accounts"] == 10
    assert line["frauds"] == 0 and line["months"] == "" and line["scored_rows"] == 0


def test_blocks_are_disjoint_and_of_the_given_size():
    """Every block has the asked size, no file is in two blocks, and no file is lost."""
    numbers = list(range(8301, 8338))
    blocks = file_inventory.split_blocks(numbers, block_size=10)
    assert list(blocks) == ["choose", "decide", "confirm", "left over"]
    assert [len(part) for part in blocks.values()] == [10, 10, 10, 7]
    assert blocks["choose"] == numbers[:10] and blocks["left over"] == numbers[30:]
    assert sorted(sum(blocks.values(), [])) == numbers
    # A seed spreads each block over the whole range, the same way every time.
    shuffled = file_inventory.split_blocks(numbers, 10, seed=5)
    assert shuffled == file_inventory.split_blocks(numbers, 10, seed=5) and shuffled != blocks
    assert sorted(sum(shuffled.values(), [])) == numbers
    assert [len(part) for part in shuffled.values()] == [10, 10, 10, 7]
    assert all(part == sorted(part) for part in shuffled.values())
    # Too few files: the later blocks are short or empty, and nothing is raised.
    short = file_inventory.split_blocks(numbers[:14], 10, names=("a", "b", "c"))
    assert [len(part) for part in short.values()] == [10, 4, 0, 0]


def test_blocks_use_only_files_of_the_scored_month_and_are_summed_from_the_inventory(files, tmp_path):
    """A file without rows of the scored month is kept out of the blocks; a block's line is the sum of its files."""
    df, folder, numbers = files
    table = file_inventory.inventory(folder, numbers)
    assert file_inventory.usable_files(table) == numbers
    blocks = file_inventory.split_blocks(file_inventory.usable_files(table), 2)
    summary = file_inventory.block_summary(table, blocks).set_index("block")
    for name, part in blocks.items():
        lines = table[table["file"].isin(part)]
        assert summary.loc[name, "files"] == len(part)
        for column in ("rows", "frauds", "fraud_accounts", "scored_frauds", "scored_fraud_accounts"):
            assert summary.loc[name, column] == lines[column].sum()
    assert summary["rows"].sum() == len(df)
    # A file that ends before the scored month starts is counted but is not usable.
    early = df[pd.to_datetime(df[settings.TIME_COL]) < pd.Timestamp(settings.TARGET_START)]
    tables.write_table(early, tables.file_path(tmp_path, 5))
    old = file_inventory.inventory(tmp_path, [5])
    assert old.loc[0, "rows"] == len(early) and old.loc[0, "scored_rows"] == 0
    assert file_inventory.usable_files(old) == [] and file_inventory.usable_files(pd.DataFrame()) == []


def test_tool_prints_the_inventory_and_the_block_lists(files, tmp_path, capsys):
    """The tool prints the per-file table, the running totals and the blocks, and writes the block of each file."""
    _, folder, numbers = files
    out = str(tmp_path / "inventory.parquet")
    file_inventory.main(["--base", str(folder), "--files", "8300-8307", "--block-size", "2", "--out", out])
    printed = capsys.readouterr().out
    for text in ("Inventory by file", "Running totals", "What each block holds", "file 8300: could not be read",
                 "choose: 2 files: 8301-8302", "decide: 2 files: 8303-8304", "confirm: 2 files: 8305-8306",
                 "left over: 0 files: (none)"):
        assert text in printed
    written = tables.read_columns(out).set_index("file")
    assert written["block"].to_dict() == {8301: "choose", 8302: "choose", 8303: "decide", 8304: "decide",
                                          8305: "confirm", 8306: "confirm"}
    # Other block names and a seed are taken from the command line.
    file_inventory.main(["--base", str(folder), "--files", "8301-8306", "--block-size", "3", "--block-names", "a", "b",
                         "--seed", "1"])
    printed = capsys.readouterr().out
    assert "a: 3 files" in printed and "b: 3 files" in printed and "choose" not in printed
    file_inventory.main(["--base", str(tmp_path / "nowhere"), "--files", "1-2"])
    assert "no file could be read" in capsys.readouterr().out
