"""Tests of the as-of audit.

Three made-up date columns that behave in three different ways must get three different
verdicts. The other tests recount the audit's numbers the slow way and build small columns
that trip each rule in turn.
"""
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

from additions import settings
from additions.common import synthetic
from additions.features import asof_audit
from additions.features.asof_audit import SNAPSHOT, STAMPED, STATIC


def _table(seed=0, n_accounts=120):
    return synthetic.add_profile_dates(synthetic.make_transactions(n_accounts=n_accounts, seed=seed), seed=seed)


def _verdicts(summary):
    return dict(zip(summary["column"], summary["verdict"]))


def _early_and_clean(df, days_before=30):
    """The two groups of the labelled check, the slow way: (early rows of fraud accounts, rows of clean accounts)."""
    time = pd.to_datetime(df[settings.TIME_COL])
    fraud_time = time.where(df[settings.LABEL_COL] == settings.POSITIVE_LABEL)
    first_fraud = fraud_time.groupby(df[settings.ACCOUNT_COL]).transform("min")
    early = first_fraud.notna() & (time <= first_fraud - pd.Timedelta(days=days_before))
    return early.to_numpy(), first_fraud.isna().to_numpy()


def test_three_made_up_columns_get_three_different_verdicts():
    """A date stamped at the transaction, a fixed date and a date written after the fraud are told apart."""
    df, columns = _table()
    summary, by_month = asof_audit.audit_columns(df, columns)
    expected = {"profile_asof_dt": STAMPED, "profile_static_dt": STATIC, "profile_snapshot_dt": SNAPSHOT}
    assert _verdicts(summary) == expected
    assert (summary["kind"] == "date").all() and summary["evidence"].str.len().gt(10).all()
    lines = summary.set_index("column")
    snapshot = lines.loc["profile_snapshot_dt"]
    assert snapshot["auc_later_fraud"] < 0.05 and snapshot["auc_rows_fraud"] > 0     # the date gives the label away
    assert abs(lines.loc["profile_asof_dt", "auc_later_fraud"] - 0.5) < 0.15
    assert sorted(by_month["column"].unique()) == sorted(columns) and set(by_month["month"]) == {"2025-05", "2025-06"}


def test_the_numbers_equal_slow_counts():
    """The four label-free numbers match plain pandas counts on the same rows."""
    df, columns = _table(seed=1)
    summary, by_month = asof_audit.audit_columns(df, columns)
    time = pd.to_datetime(df[settings.TIME_COL])
    by_time = [settings.ACCOUNT_COL, settings.TIME_COL]
    ordered = df.assign(_month=time.dt.to_period("M")).sort_values(by_time, kind="stable")
    same_account = (ordered[settings.ACCOUNT_COL] == ordered[settings.ACCOUNT_COL].shift()).to_numpy()
    across = (ordered["_month"] != ordered["_month"].shift()).to_numpy()
    for line in summary.itertuples(index=False):
        later = pd.to_datetime(df[line.column]) > time.dt.floor("D")
        assert np.isclose(line.share_later, later.mean())
        for month, rows in by_month[by_month["column"] == line.column].groupby("month"):
            in_month = (time.dt.strftime("%Y-%m") == month).to_numpy()
            assert rows["rows"].iloc[0] == in_month.sum()
            assert np.isclose(rows["share_later"].iloc[0], later[in_month].mean())
        per_account = df.groupby(settings.ACCOUNT_COL)[line.column].agg(["size", "nunique"])
        changing = (per_account.loc[per_account["size"] >= 2, "nunique"] > 1).mean()
        assert np.isclose(line.share_accounts_changing, changing)
        changed = same_account & (ordered[line.column] != ordered[line.column].shift()).to_numpy()
        assert line.changes == changed.sum()
        assert np.isclose(line.share_pairs_across_months, across[same_account].mean())
        if changed.any():
            assert np.isclose(line.share_changes_at_month_start, across[changed].mean())
        assert line.rows_with_value == len(df)


def test_a_monthly_refresh_is_called_a_snapshot():
    """A value that changes only between calendar months is a snapshot even though no date lies in the future."""
    df, _ = _table(seed=2)
    time = pd.to_datetime(df[settings.TIME_COL])
    df["refreshed_monthly"] = time.dt.to_period("M").dt.to_timestamp() - pd.Timedelta(days=10)
    summary, _ = asof_audit.audit_columns(df, ["refreshed_monthly"])
    line = summary.iloc[0]
    assert line["share_later"] == 0 and line["share_changes_at_month_start"] == 1.0
    assert line["share_pairs_across_months"] < 0.1 and line["verdict"] == SNAPSHOT and "monthly" in line["evidence"]


def test_a_column_that_foresees_fraud_is_called_a_snapshot(capsys):
    """A fixed date that separates accounts with a later fraud is flagged by the labelled check alone."""
    df, _ = _table(seed=3)
    has_fraud = df.groupby(settings.ACCOUNT_COL)[settings.LABEL_COL].transform("max") == settings.POSITIVE_LABEL
    df["status_dt"] = np.where(has_fraud, pd.Timestamp("2018-01-01"), pd.Timestamp("2019-01-01"))
    df["status_dt"] = pd.to_datetime(df["status_dt"])
    line = asof_audit.audit_columns(df, ["status_dt"])[0].iloc[0]
    assert line["share_later"] == 0 and line["share_accounts_changing"] == 0     # nothing label-free looks wrong
    assert line["auc_later_fraud"] == 1.0 and line["verdict"] == SNAPSHOT and "AUC" in line["evidence"]
    # Without labels the labelled check is skipped with one line, and the column passes as static.
    capsys.readouterr()
    unlabelled = asof_audit.audit_columns(df, ["status_dt"], label_col=False)[0].iloc[0]
    assert unlabelled["verdict"] == STATIC and np.isnan(unlabelled["auc_later_fraud"])
    assert capsys.readouterr().out.count("note:") == 1


def test_only_early_rows_of_fraud_accounts_enter_the_labelled_check():
    """Rows less than 30 days before the first fraud, and rows after it, are left out."""
    df, _ = _table(seed=4)
    early, clean = _early_and_clean(df)
    line = asof_audit.audit_columns(df, ["profile_asof_dt"])[0].iloc[0]
    assert line["auc_rows_fraud"] == early.sum() and line["auc_rows_clean"] == clean.sum()
    fewer = asof_audit.audit_columns(df, ["profile_asof_dt"], days_before=45)[0].iloc[0]
    assert fewer["auc_rows_fraud"] < line["auc_rows_fraud"]


def test_the_labelled_check_compares_rows_of_the_same_day():
    """The pooled AUC equals day-by-day AUCs weighted by their pairs; a date that never varies knows nothing."""
    df, _ = _table(seed=6)
    df["fixed_dt"] = pd.Timestamp("2020-03-03")
    summary, _ = asof_audit.audit_columns(df, ["profile_static_dt", "fixed_dt"])
    lines = summary.set_index("column")
    early, clean = _early_and_clean(df)
    day = pd.to_datetime(df[settings.TIME_COL]).dt.floor("D")
    measure = (day - df["profile_static_dt"]).dt.days.to_numpy()
    day = day.to_numpy()
    total, pairs = 0.0, 0
    for d in np.unique(day[early]):
        pos, neg = measure[early & (day == d)], measure[clean & (day == d)]
        if len(neg):
            target = np.r_[np.ones(len(pos)), np.zeros(len(neg))]
            total += roc_auc_score(target, np.r_[pos, neg]) * len(pos) * len(neg)
            pairs += len(pos) * len(neg)
    assert np.isclose(lines.loc["profile_static_dt", "auc_later_fraud"], total / pairs)
    # Without the day-by-day comparison a fixed date would look informative, only because the early rows
    # of fraud accounts sit early in the files. Compared inside a day, every pair is a tie.
    assert lines.loc["fixed_dt", "auc_later_fraud"] == 0.5 and lines.loc["fixed_dt", "verdict"] == STATIC
    since_fixed = (pd.to_datetime(df[settings.TIME_COL]).dt.floor("D") - df["fixed_dt"]).dt.days.to_numpy()
    target = np.r_[np.ones(early.sum()), np.zeros(clean.sum())]
    assert roc_auc_score(target, np.r_[since_fixed[early], since_fixed[clean]]) < 0.4


def test_dates_are_recognised_and_plain_values_are_audited_as_values(capsys):
    """Datetimes, year-month-day numbers and date text are dates; codes and amounts are not."""
    stamps = pd.Series(pd.to_datetime(["2025-06-01", "2025-06-17", None]))
    expected = [20240.0, 20256.0]
    assert asof_audit.to_days(stamps)[:2].tolist() == expected and np.isnan(asof_audit.to_days(stamps)[2])
    assert asof_audit.to_days(np.array([20250601, 20250617])).tolist() == expected
    assert asof_audit.to_days(np.array([20250601.0, np.nan]))[0] == expected[0]
    assert asof_audit.to_days(np.array(["2025-06-01", "2025-06-17 10:00:00"], dtype=object)).tolist() == expected
    assert asof_audit.to_days(np.array(["A", "B", "A"], dtype=object)) is None
    assert asof_audit.to_days(np.array([12.5, 300.0])) is None

    df, _ = _table(seed=5)
    rng = np.random.default_rng(0)
    code_of = {a: rng.choice(["A", "B"]) for a in df[settings.ACCOUNT_COL].unique()}
    df["status_code"] = df[settings.ACCOUNT_COL].map(code_of)
    df["expiry_dt"] = pd.Timestamp("2027-12-31")
    capsys.readouterr()
    audited = ["status_code", "expiry_dt", "absent_col"]
    summary, by_month = asof_audit.audit_columns(df, audited, future_ok=["expiry_dt"])
    assert capsys.readouterr().out.count("note:") == 1                           # the absent column, and only that
    lines = summary.set_index("column")
    assert lines.loc["status_code", "kind"] == "value" and np.isnan(lines.loc["status_code", "share_later"])
    assert lines.loc["status_code", "verdict"] == STATIC
    # A scheduled date lies in the future by design: with future_ok that is not held against it.
    assert lines.loc["expiry_dt", "share_later"] == 1.0 and lines.loc["expiry_dt", "verdict"] == STATIC
    assert _verdicts(asof_audit.audit_columns(df, ["expiry_dt"])[0]) == {"expiry_dt": SNAPSHOT}
    assert set(by_month["column"]) == {"expiry_dt"}
    # A plain value that changes inside accounts at any time behaves like a value stamped at the transaction.
    df["moving_value"] = rng.integers(0, 5, len(df))
    moving = asof_audit.audit_columns(df, ["moving_value"])[0].iloc[0]
    assert moving["kind"] == "value" and moving["verdict"] == STAMPED and "any time" in moving["evidence"]


def test_the_command_line_prints_verdicts_and_writes_the_table(tmp_path, capsys):
    """The tool runs on made-up rows, prints one verdict per column and writes the summary when asked."""
    out = tmp_path / "audit.csv"
    summary = asof_audit.main(["--demo", "--out", str(out)])
    printed = capsys.readouterr().out
    assert printed.count("Evidence:") == 3 and "later snapshot" in printed
    written = pd.read_csv(out)
    assert written["verdict"].tolist() == summary["verdict"].tolist() and len(set(written["verdict"])) == 3
