"""Tests of the lock-on table and of the sticky-alert rule.

The rule is compared with a loop that looks at every earlier row of the account, the time rule
is checked on rows that share a second, and the table is compared with a walk through the
frauds of each account.
"""
import numpy as np
import pandas as pd
import pytest

from additions import settings
from additions.common import ranking, synthetic, tables, timekeys
from additions.reads import _rows, lock_on

STANDARD = [settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL, settings.LABEL_COL, settings.AMOUNT_COL,
            settings.SCORE_COL]


@pytest.fixture(scope="module")
def table():
    """Made-up rows with fraud runs, a few scattered extra frauds, and a score that is far from perfect."""
    df = synthetic.make_transactions(n_accounts=120, seed=2, fraud_account_share=0.4)
    rng = np.random.default_rng(2)
    plain = np.flatnonzero(_rows.row_type(df) == "approved")
    df.loc[rng.choice(plain, 150, replace=False), settings.LABEL_COL] = 1     # frauds far from any run
    return synthetic.make_scores(df, seed=2, strength=1.5)


def _frame(rows):
    """A tiny table from (account, second, probability, label) tuples, with the column names of settings."""
    start = pd.Timestamp(settings.TARGET_START)
    return pd.DataFrame({
        settings.ID_COL: np.arange(len(rows)),
        settings.ACCOUNT_COL: [r[0] for r in rows],
        settings.TIME_COL: [start + pd.Timedelta(seconds=r[1]) for r in rows],
        settings.SCORE_COL: [r[2] for r in rows],
        settings.LABEL_COL: [r[3] for r in rows],
        settings.AMOUNT_COL: 10.0,
    })


def _arrays(df):
    """Account, whole second, logit and fraud flag of every row."""
    return (df[settings.ACCOUNT_COL].to_numpy(), timekeys.seconds(df[settings.TIME_COL]),
            ranking.to_logit(df[settings.SCORE_COL]), df[settings.LABEL_COL].to_numpy() == 1)


def test_sticky_bonus_matches_the_slow_rule(table):
    """A row gets the bonus exactly when an earlier row of its account, inside the window, is at or above the cut."""
    account, secs, logit, _ = _arrays(table)
    scored = _rows.in_scored_month(table)
    threshold = _rows.cut_threshold(logit[scored])
    for window in (3_600, 3 * 86_400):
        new, earlier_max, boosted = lock_on.sticky_logits(table, window, beta=2.0)
        for i in range(0, len(table), 3):
            seen = (account == account[i]) & (secs < secs[i]) & (secs >= secs[i] - window)
            if not seen.any():
                assert np.isnan(earlier_max[i]) and not boosted[i] and new[i] == logit[i]
                continue
            assert earlier_max[i] == logit[seen].max()
            assert boosted[i] == (logit[seen].max() >= threshold)
            assert np.isclose(new[i], logit[i] + 2.0 * boosted[i])
        assert 0 < boosted.sum() < len(table)


def test_rows_of_the_same_second_do_not_boost_each_other():
    """Only strictly earlier seconds of the same account count, and only inside the window."""
    df = _frame([("a", 100, 0.9, 1), ("a", 100, 0.01, 1), ("a", 160, 0.01, 1), ("b", 160, 0.01, 0),
                 ("a", 5_000, 0.01, 1)])
    threshold = ranking.to_logit(np.array([0.5]))[0]
    new, earlier_max, boosted = lock_on.sticky_logits(df, window=3_600, beta=2.0, threshold=threshold)
    # Second 100 holds an alert, but its two rows do not see each other; second 160 of the same
    # account sees it; the other account does not; second 5000 is more than an hour later.
    assert boosted.tolist() == [False, False, True, False, False]
    assert np.isnan(earlier_max[0]) and np.isnan(earlier_max[1]) and np.isnan(earlier_max[3])
    low = ranking.to_logit(np.array([0.01]))[0]
    assert np.isclose(new[2], low + 2.0) and np.isclose(new[4], low)


def test_later_rows_do_not_change_the_bonus_of_earlier_rows(table):
    """Cutting the table off at a point in time leaves every earlier row's new score as it was."""
    _, secs, logit, _ = _arrays(table)
    threshold = _rows.cut_threshold(logit[_rows.in_scored_month(table)])
    full, _, _ = lock_on.sticky_logits(table, 86_400, 1.0, threshold=threshold)
    keep = secs <= np.median(secs)
    part, _, _ = lock_on.sticky_logits(table[keep].reset_index(drop=True), 86_400, 1.0, threshold=threshold)
    assert np.array_equal(full[keep], part)


def test_grid_cells_spend_the_same_budget_and_a_zero_bonus_changes_nothing(table):
    """Each cell equals capture of the boosted scores at the unchanged number of alerts."""
    scored = _rows.in_scored_month(table)
    _, _, logit, is_fraud = _arrays(table)
    y, a = is_fraud[scored].astype(float), table[settings.AMOUNT_COL].to_numpy()[scored]
    base = ranking.capture(y, logit[scored], a)
    cells = lock_on.grid(table, windows=(3_600, 86_400), betas=(0.0, 1.0))
    assert len(cells) == 4
    switched_off = cells[cells["beta"] == 0.0]
    assert (switched_off["udr_gain"] == 0).all() and np.allclose(switched_off["udr"], base["udr"])
    new, _, boosted = lock_on.sticky_logits(table, 86_400, 1.0)
    cell = cells[(cells["window_seconds"] == 86_400) & (cells["beta"] == 1.0)].iloc[0]
    after = ranking.capture(y, new[scored], a)
    assert np.isclose(cell["udr"], after["udr"]) and np.isclose(cell["vdr"], after["vdr"])
    assert np.isclose(cell["udr_gain"], after["udr"] - base["udr"])
    assert np.isclose(cell["boosted_share"], boosted[scored].mean())
    assert after["alerts"] == base["alerts"] == ranking.alert_mask(new[scored]).sum()   # the budget is the same
    assert len(lock_on.grid(table)) == len(lock_on.WINDOWS) * len(lock_on.BETAS)


def test_the_mildest_of_the_best_cells_is_chosen():
    """The highest capture wins; among equals the smallest bonus, then the shortest window."""
    cells = pd.DataFrame({"window_seconds": [3_600, 21_600, 3_600, 21_600], "beta": [1.0, 1.0, 2.0, 2.0],
                          "udr": [0.5, 0.6, 0.6, 0.6]})
    assert lock_on.choose_cell(cells) == (21_600, 1.0)
    cells["udr"] = 0.6
    assert lock_on.choose_cell(cells) == (3_600, 1.0)


def test_lock_on_table_matches_a_walk_through_the_frauds_of_each_account(table):
    """Every fraud of the scored month is counted once, under what happened to the account's previous fraud."""
    account, secs, logit, is_fraud = _arrays(table)
    scored = _rows.in_scored_month(table)
    inside = logit >= np.sort(logit[scored])[-ranking.cut_size(int(scored.sum()))]
    counts = {}
    for i in np.flatnonzero(is_fraud & scored):
        earlier = np.flatnonzero(is_fraud & (account == account[i]) & (secs < secs[i]))
        if len(earlier) == 0:
            key = ("none", "all")
        else:
            last = secs[earlier].max()
            previous_caught = inside[earlier[secs[earlier] == last]].any()
            gap = secs[i] - last
            name = ("under 1 hour" if gap < 3_600 else "1 to 24 hours" if gap < 86_400
                    else "1 to 7 days" if gap < 7 * 86_400 else "longer")
            key = ("caught" if previous_caught else "missed", name)
        frauds, caught = counts.get(key, (0, 0))
        counts[key] = (frauds + 1, caught + int(inside[i]))
    fast = lock_on.lock_on_table(table)
    for line in fast.to_dict("records"):
        if line["previous"] == "none" or line["gap"] != "all":
            assert (line["frauds"], line["caught"]) == counts.get((line["previous"], line["gap"]), (0, 0))
        else:                                                # an "all" line sums the gaps of its kind
            parts = [v for (previous, _), v in counts.items() if previous == line["previous"]]
            assert (line["frauds"], line["caught"]) == (sum(p[0] for p in parts), sum(p[1] for p in parts))
    totals = fast[fast["gap"] == "all"]
    assert totals["frauds"].sum() == (is_fraud & scored).sum() and np.isclose(totals["share_of_frauds"].sum(), 1.0)
    assert len({key[1] for key in counts}) >= 4              # the table has frauds in several gap buckets


def test_a_cell_is_read_against_the_untouched_scores(table):
    """The paired read gives capture of both rankings, and a zero bonus gives a gain of exactly zero."""
    scored = _rows.in_scored_month(table)
    _, _, logit, is_fraud = _arrays(table)
    y, a = is_fraud[scored].astype(float), table[settings.AMOUNT_COL].to_numpy()[scored]
    nothing = lock_on.read_cell(table, 86_400, 0.0, draws=40)
    assert (nothing["gain"] == 0).all() and (nothing["low"] == 0).all() and (nothing["high"] == 0).all()
    read = lock_on.read_cell(table, 86_400, 1.0, draws=60).set_index("measure")
    new, _, _ = lock_on.sticky_logits(table, 86_400, 1.0)
    assert np.isclose(read.loc["udr", "sticky"], ranking.capture(y, new[scored])["udr"])
    assert np.isclose(read.loc["udr", "base"], ranking.capture(y, logit[scored])["udr"])
    assert np.isclose(read.loc["vdr", "sticky"], ranking.capture(y, new[scored], a)["vdr"])
    assert np.isclose(read.loc["udr", "gain"], read.loc["udr", "sticky"] - read.loc["udr", "base"])
    assert read.loc["udr", "low"] <= read.loc["udr", "high"] and read.loc["udr", "draws"] == 60


def test_tool_chooses_on_one_file_and_reports_on_another(table, tmp_path, capsys):
    """The tool prints the table, the grid and the chosen cell, reads it on the second file, and writes on request."""
    choose = tables.write_table(table[STANDARD], str(tmp_path / "choose.parquet"))
    other = synthetic.make_scores(table.drop(columns=[settings.SCORE_COL]), seed=9, strength=1.5)
    report = tables.write_table(other[STANDARD], str(tmp_path / "report.parquet"))
    out = str(tmp_path / "sticky.parquet")
    lock_on.main(["--choose", choose, "--report", report, "--windows-hours", "1", "24", "--betas", "1", "2",
                  "--draws", "40", "--out", out])
    printed = capsys.readouterr().out
    for text in ("Lock-on table", "Sticky-alert grid", "chosen cell", "Chosen cell on the second file"):
        assert text in printed
    written = tables.read_columns(out)
    assert len(written) == len(other) and {lock_on.STICKY_COL, lock_on.EARLIER_MAX_COL} <= set(written.columns)
    bonus = written[lock_on.STICKY_COL].to_numpy() - ranking.to_logit(written[settings.SCORE_COL])
    assert set(np.round(bonus, 6)) <= {0.0, 1.0, 2.0} and len(set(np.round(bonus, 6))) == 2
    # With one file only, the tool warns that the best cell was read on the rows that chose it.
    lock_on.main(["--choose", choose, "--windows-hours", "24", "--betas", "1"])
    assert "no --report file was given" in capsys.readouterr().out
