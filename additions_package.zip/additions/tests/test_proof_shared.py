"""Tests of the shared pieces of the comparison tools.

Each helper is compared with the slow, obvious way of computing the same thing on a small
made-up table. The tests also show how the helpers are called.
"""
import argparse

import numpy as np
import pandas as pd
import pytest
from scipy import stats

from additions import settings
from additions.common import ranking, synthetic, tables, timekeys
from additions.proof import _shared

STANDARD = [settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL, settings.LABEL_COL, settings.AMOUNT_COL,
            settings.SCORE_COL]


@pytest.fixture(scope="module")
def table():
    """Made-up rows with fraud runs, same-second rows and a score."""
    df = synthetic.make_transactions(n_accounts=120, seed=11, fraud_account_share=0.4, tie_share=0.1)
    return synthetic.make_scores(df, seed=11)


def test_common_rows_keep_the_transactions_every_file_scores(table, tmp_path):
    """Only ids that every file scores are kept, in the first file's order, with the right scores."""
    rng = np.random.default_rng(0)
    first = table[STANDARD]
    second = synthetic.make_scores(table, seed=12)[[settings.ID_COL, settings.SCORE_COL, settings.LABEL_COL]]
    second = second.drop(index=rng.choice(len(table), 50, replace=False)).sample(frac=1.0, random_state=1)
    second.iloc[:7, second.columns.get_loc(settings.LABEL_COL)] = 1 - second.iloc[:7][settings.LABEL_COL]
    third = synthetic.make_scores(table, seed=13)[[settings.ID_COL, settings.SCORE_COL]].copy()
    third.loc[third.index[:9], settings.SCORE_COL] = np.nan                 # nine rows without a score
    third = pd.concat([third, third.iloc[20:24]])                           # four ids appear twice
    third[settings.ID_COL] = third[settings.ID_COL].astype(str)             # this file stores the id as text
    paths = []
    for name, part in (("a", first), ("b", second), ("c", third)):
        paths.append(tables.write_table(part, str(tmp_path / f"{name}.parquet")))
    frame, scores, files = _shared.common_rows(paths, names=["one", "two", "three"])

    ids_two = set(second[settings.ID_COL])
    ids_three = set(third.loc[third[settings.SCORE_COL].notna(), settings.ID_COL].astype(int))
    expected = [i for i in first[settings.ID_COL] if i in ids_two and i in ids_three]
    assert frame[settings.ID_COL].tolist() == expected and len(expected) < len(first)
    lookup_two = dict(zip(second[settings.ID_COL], second[settings.SCORE_COL]))
    lookup_three = dict(zip(third[settings.ID_COL].astype(int), third[settings.SCORE_COL]))
    assert np.array_equal(scores["two"], np.array([lookup_two[i] for i in expected]))
    assert np.array_equal(scores["three"], np.array([lookup_three[i] for i in expected]))
    assert np.array_equal(scores["one"], frame[settings.SCORE_COL].to_numpy())
    files = files.set_index("file")
    assert files.loc["two", "rows"] == len(first) - 50 and files.loc["three", "repeated_ids"] == 4
    assert files.loc["three", "without_score"] == 9 and (files["common_rows"] == len(expected)).all()
    # The seven flipped labels are counted on the rows that are common, and nothing is refused.
    flipped = set(second.iloc[:7][settings.ID_COL])
    assert files.loc["two", "label_differs"] == len(flipped & set(expected)) and files.loc["one", "label_differs"] == 0
    assert np.isnan(files.loc["three", "label_differs"])                    # the third file carries no label


def test_ranked_rows_are_the_rows_of_the_scored_month(table, capsys):
    """A row is ranked when its time is inside the scored month; other rows stay as history."""
    ranked = _shared.ranked_rows(table)
    stamps = pd.to_datetime(table[settings.TIME_COL])
    slow = (stamps >= pd.Timestamp(settings.TARGET_START)) & (stamps < pd.Timestamp(settings.TARGET_END))
    assert np.array_equal(ranked, slow.to_numpy()) and 0 < ranked.sum() < len(table)
    assert _shared.ranked_rows(table, all_rows=True).all()
    week = _shared.ranked_rows(table, start="2025-06-08", end="2025-06-15")
    assert week.sum() == ((stamps >= "2025-06-08") & (stamps < "2025-06-15")).sum()
    assert _shared.ranked_rows(table.drop(columns=[settings.TIME_COL])).all()
    assert "no time column" in capsys.readouterr().out


def test_shares_second_matches_a_count_per_account_and_second(table):
    """A row shares its second exactly when the account has two or more rows in that second."""
    keys = _shared.account_codes(table)
    secs = _shared.row_seconds(table)
    fast = _shared.shares_second(keys, secs)
    count = table.groupby([settings.ACCOUNT_COL, settings.TIME_COL])[settings.ID_COL].transform("size").to_numpy()
    assert np.array_equal(fast, count > 1) and fast.any() and not fast.all()
    # A row without a time shares its second with nobody, even when two such rows exist.
    secs = secs.copy()
    secs[:2] = timekeys.MISSING_SECOND
    assert not _shared.shares_second(np.zeros(len(secs), dtype=int), secs)[:2].any()


def _slow_runs(keys, secs, fraud, run_gap):
    """Run, position and gap of every fraud, found by walking through each account's fraud seconds."""
    run = np.full(len(keys), -1)
    position = np.zeros(len(keys), dtype=int)
    since = np.full(len(keys), np.nan)
    next_run = 0
    for key in np.unique(keys[fraud]):
        rows = np.flatnonzero(fraud & (keys == key))
        seconds = sorted(set(secs[rows].tolist()))
        earlier_in_run = 0
        for j, second in enumerate(seconds):
            gap = np.nan if j == 0 else second - seconds[j - 1]
            if j == 0 or gap > run_gap:                              # a long gap opens a new run
                current, earlier_in_run = next_run, 0
                next_run += 1
            here = rows[secs[rows] == second]
            run[here], position[here], since[here] = current, earlier_in_run + 1, gap
            earlier_in_run += len(here)
    return run, position, since


def test_fraud_runs_match_a_walk_through_each_account(table):
    """Run membership, place in the run and the gap to the previous fraud agree with the slow walk."""
    keys = _shared.account_codes(table)
    secs = _shared.row_seconds(table)
    fraud = _shared.fraud_flags(table) > 0
    for gap in (_shared.RUN_GAP, 1_800):
        fast = _shared.fraud_runs(keys, secs, fraud, gap)
        run, position, since = _slow_runs(keys, secs, fraud, gap)
        assert np.array_equal(fast["position"], position)
        assert np.array_equal(fast["since_previous"], since, equal_nan=True)
        # Run numbers may differ from the slow ones, but they must split the frauds the same way.
        pairs = set(zip(fast["run"][fraud].tolist(), run[fraud].tolist()))
        assert len(pairs) == len(set(run[fraud].tolist())) == len(set(fast["run"][fraud].tolist()))
        assert (fast["run"][~fraud] == -1).all() and (fast["position"][~fraud] == 0).all()
    assert fast["position"].max() > 1 and len(pairs) > fraud.sum() / 8        # the short gap splits runs


def test_frauds_of_one_second_share_their_place_and_later_rows_change_nothing(table):
    """Same-second frauds get one position; cutting the table in time leaves earlier frauds as they were."""
    keys = np.array([3, 3, 3, 3, 3, 9])
    secs = np.array([0, 50, 50, 90, 90 + 8 * 86_400, 50], dtype=np.int64)
    out = _shared.fraud_runs(keys, secs, np.ones(6, dtype=bool))
    assert out["position"].tolist() == [1, 2, 2, 4, 1, 1]
    assert out["run"][:4].tolist() == [out["run"][0]] * 4 and len(set(out["run"].tolist())) == 3
    assert np.array_equal(out["since_previous"], [np.nan, 50, 50, 40, 8 * 86_400, np.nan], equal_nan=True)

    keys, secs = _shared.account_codes(table), _shared.row_seconds(table)
    fraud = _shared.fraud_flags(table) > 0
    keep = secs <= np.median(secs)
    full = _shared.fraud_runs(keys, secs, fraud)
    part = _shared.fraud_runs(keys[keep], secs[keep], fraud[keep])
    assert np.array_equal(full["position"][keep], part["position"])
    assert np.array_equal(full["since_previous"][keep], part["since_previous"], equal_nan=True)


def test_approved_rows_follow_the_response_code_and_the_decline_flag(table, capsys):
    """A row is approved when its code is an approval code and the decline flag is not set."""
    approved = _shared.approved_rows(table)
    slow = table[settings.REASON_COL].isin(settings.APPROVED_REASONS) & (table[settings.DECLINE_FLAG_COL] != 1)
    assert np.array_equal(approved, slow.to_numpy()) and 0 < approved.sum() < len(table)
    # Every fraud label sits on an approved row, in the made-up data as in the real files.
    assert approved[_shared.fraud_flags(table) > 0].all()
    only_flag = _shared.approved_rows(table.drop(columns=[settings.REASON_COL]))
    assert np.array_equal(only_flag, (table[settings.DECLINE_FLAG_COL] != 1).to_numpy())
    assert _shared.approved_rows(table[STANDARD]) is None
    assert "approved-row part is skipped" in capsys.readouterr().out


def test_account_folds_keep_every_account_whole(table):
    """All rows of an account land in one fold, the folds are of similar size, and a seed repeats."""
    folds = _shared.account_folds(table[settings.ACCOUNT_COL], n_folds=2, seed=5)
    per_account = pd.Series(folds).groupby(table[settings.ACCOUNT_COL].to_numpy()).nunique()
    assert per_account.max() == 1 and set(folds.tolist()) == {0, 1}
    accounts_per_fold = pd.Series(folds).groupby(table[settings.ACCOUNT_COL].to_numpy()).first().value_counts()
    assert abs(accounts_per_fold[0] - accounts_per_fold[1]) <= 1
    assert np.array_equal(folds, _shared.account_folds(table[settings.ACCOUNT_COL], 2, seed=5))
    assert not np.array_equal(folds, _shared.account_folds(table[settings.ACCOUNT_COL], 2, seed=6))
    assert set(_shared.account_folds(table[settings.ACCOUNT_COL], 3).tolist()) == {0, 1, 2}


def test_exact_test_is_the_two_sided_binomial_tail():
    """The p-value equals the exact two-sided binomial test at one half for uneven and even splits."""
    for only_a, only_b in ((0, 0), (5, 5), (12, 3), (3, 12), (40, 25), (1, 0), (0, 9), (130, 100)):
        fast = _shared.exact_test(only_a, only_b)
        slow = 1.0 if only_a + only_b == 0 else stats.binomtest(only_a, only_a + only_b, 0.5).pvalue
        assert np.isclose(fast, slow)
    assert _shared.exact_test(12, 3) == _shared.exact_test(3, 12) < 0.05 < _shared.exact_test(40, 30)
    assert np.isclose(_shared.interval_z(90.0), 1.6449, atol=1e-4) and np.isclose(_shared.interval_z(95.0), 1.96, atol=1e-3)


def test_alert_sets_give_every_model_its_own_cut(table):
    """Each model alerts exactly the budget, and its set holds its own highest scores."""
    scores = {"a": table[settings.SCORE_COL].to_numpy(), "b": synthetic.make_scores(table, seed=3)[settings.SCORE_COL].to_numpy()}
    alerts = _shared.alert_sets(scores, per_mille=10)
    k = ranking.cut_size(len(table), 10)
    for name, mask in alerts.items():
        assert mask.sum() == k and scores[name][mask].min() >= scores[name][~mask].max()
    assert not np.array_equal(alerts["a"], alerts["b"])


def test_raw_columns_are_joined_by_id_in_the_order_of_the_scores(table, tmp_path, capsys):
    """A raw column lands on the row with the same id; unknown ids get a missing value."""
    numbers = synthetic.write_files(table, tmp_path / "raw", 3, first_number=40)
    scored = table[STANDARD].sample(frac=0.5, random_state=2).reset_index(drop=True)
    extra = scored.iloc[:3].copy()
    extra[settings.ID_COL] = [-1, -2, -3]                                   # ids no raw file holds
    scored = pd.concat([scored, extra], ignore_index=True)
    wanted = [settings.REASON_COL, settings.MERCHANT_COL, None, settings.SCORE_COL]
    out = _shared.join_raw_columns(scored, wanted, base=str(tmp_path / "raw"), numbers=numbers)
    assert out[settings.ID_COL].tolist() == scored[settings.ID_COL].tolist()
    by_id = table.set_index(settings.ID_COL)
    known = out.iloc[:-3]
    assert (known[settings.REASON_COL].to_numpy() == by_id.loc[known[settings.ID_COL], settings.REASON_COL].to_numpy()).all()
    assert (known[settings.MERCHANT_COL].to_numpy() == by_id.loc[known[settings.ID_COL], settings.MERCHANT_COL].to_numpy()).all()
    assert out[settings.REASON_COL].iloc[-3:].isna().all()
    assert _shared.file_numbers("40-42, 7") == [40, 41, 42, 7] and _shared.file_numbers(None) == []
    # Without raw files the table comes back unchanged and one line says what is skipped.
    same = _shared.join_raw_columns(scored, [settings.REASON_COL])
    assert list(same.columns) == list(scored.columns) and "no raw files were named" in capsys.readouterr().out


def test_tables_are_printed_and_written(table, tmp_path, capsys):
    """A table prints as plain text with a title, an empty one says so, and a written file reads back."""
    _shared.show("capture", pd.DataFrame({"model": ["a"], "udr": [0.123456], "vdr": [np.nan]}))
    _shared.show("nothing", [])
    printed = capsys.readouterr().out
    assert "capture" in printed and "0.1235" in printed and "(no rows)" in printed
    path = _shared.save(table[STANDARD].head(10), str(tmp_path / "out.parquet"))
    _shared.save(table[STANDARD].head(5), path)                              # an existing file is replaced
    assert len(tables.read_columns(path)) == 5
    args = _shared.add_score_arguments(argparse.ArgumentParser()).parse_args(["--per-mille", "10", "--all-rows"])
    assert args.per_mille == 10 and args.all_rows and args.score_col is None and args.raw_files is None
