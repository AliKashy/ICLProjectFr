"""Tests of merchant heat from the model's own scores.

The columns are recomputed row by row from other accounts' scores on completed earlier days,
with the priors applied the slow way. Further tests check that the row's own account and the
row's own day are never read, that the previous-merchant columns come from a strictly earlier
second, that tables of files add up, and that a missing score column is skipped.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.common import ranking, synthetic, timekeys
from additions.merchant import _panel, heat

ACCOUNT, MERCHANT, MCC, STATE = (settings.ACCOUNT_COL, settings.MERCHANT_COL, settings.MCC_COL,
                                 settings.MERCHANT_STATE_COL)
SCORE, TIME = settings.SCORE_COL, settings.TIME_COL
LEVELS = ([], [MCC], [MCC, STATE], [MERCHANT])                  # from the broadest key to the narrowest


def _rows(seed=0, n_accounts=100, days=45):
    """Made-up scored rows on a few dozen merchants; the label is dropped, because heat never reads it."""
    df = synthetic.make_transactions(n_accounts=n_accounts, days=days, seed=seed, fraud_account_share=0.5)
    df[MERCHANT] = df[MERCHANT] % 30
    df[MCC], df[STATE] = 1000 + df[MERCHANT] % 4, df[MERCHANT] % 3
    df = synthetic.make_scores(df, seed=seed).drop(columns=[settings.LABEL_COL])
    df.loc[np.random.default_rng(seed).random(len(df)) < 0.03, SCORE] = np.nan
    return df


def _day(df):
    return _panel.days(timekeys.seconds(df[TIME]))


def _others(df, day, i, keys, days):
    """Log-odds scores of other accounts at the same key on the `days` days before row i's day."""
    m = (df[ACCOUNT].to_numpy() != df[ACCOUNT].iloc[i]) & (day < day[i]) & (day >= day[i] - days)
    for k in keys:
        m &= (df[k] == df[k].iloc[i]).to_numpy()
    s = df.loc[m, SCORE].to_numpy(dtype=float)
    return ranking.to_logit(s[~np.isnan(s)])


def _chain(parts, value_of, k):
    value = np.nan
    for s in parts:
        total, count = value_of(s), float(len(s))
        if np.isnan(value):
            value = total / count if count else np.nan
        else:
            value = (total + k * value) / (count + k)
    return value


def _same(a, b):
    return bool(np.isclose(a, b, rtol=2e-4, atol=2e-4, equal_nan=True))


def test_columns_equal_the_slow_definition():
    """Every column matches a recomputation from other accounts' scores of completed earlier days."""
    df = _rows()
    day = _day(df)
    cut = heat.alert_cut(df[SCORE])
    got = heat.heat_features(df, *heat.build_heat_tables(df, cut))
    assert got.shape == (len(df), 18) and got.index.equals(df.index)
    k, edges = _panel.PRIOR_ROWS, heat.HEAT_EDGES
    for i in range(0, len(df), 109):
        for label, days in heat.WINDOWS:
            parts = [_others(df, day, i, keys, days) for keys in LEVELS]
            assert got[f"heat_n_{label}"].iloc[i] == len(parts[-1])
            assert _same(got[f"heat_mean_{label}"].iloc[i], _chain(parts, np.sum, k))
            assert _same(got[f"heat_alert_share_{label}"].iloc[i], _chain(parts, lambda s: float((s >= cut).sum()), k))
            hist = None
            for s in parts:
                own = np.histogram(np.clip(s, edges[0], edges[-1] - 1e-9), bins=edges)[0].astype(float)
                hist = own if hist is None else own + k * (hist / hist.sum() if hist.sum() else hist)
            assert _same(got[f"heat_p90_{label}"].iloc[i], _panel.histogram_quantile(hist[None, :], edges, 0.9)[0])
    assert (got["heat_alert_share_7d"] > 0).any()


def test_the_cut_is_the_top_share_of_rows():
    """The alert cut leaves exactly the alerted number of rows at or above it when no scores tie."""
    p = np.random.default_rng(1).random(20_000) * 0.5
    cut = heat.alert_cut(p)
    assert (ranking.to_logit(p) >= cut).sum() == ranking.cut_size(len(p))


def test_the_own_account_the_own_day_and_the_previous_row():
    """Hot scores reach other accounts the next day only; the previous row is in a strictly earlier second."""
    stamp = pd.Timestamp("2025-06-10 09:00:00")
    hour, day = pd.Timedelta(hours=1), pd.Timedelta(days=1)
    df = pd.DataFrame({
        ACCOUNT: ["a", "a", "a", "b", "b", "b", "c"], MERCHANT: [7, 7, 7, 7, 8, 8, 8], MCC: 5411, STATE: 1,
        TIME: [stamp - day, stamp, stamp + hour, stamp + 2 * hour, stamp + day, stamp + day, stamp + day + hour],
        SCORE: [0.01, 0.9, 0.9, 0.01, 0.01, 0.01, 0.01]})
    cut = float(ranking.to_logit([0.5])[0])
    got = heat.heat_features(df, *heat.build_heat_tables(df, cut), prior_rows=1.0)
    share, previous = got["heat_alert_share_1d"].to_numpy(), got["heat_prev_alert_share_1d"].to_numpy()
    assert got["heat_n_1d"].tolist() == [0, 0, 0, 1, 0, 0, 0]
    assert np.isnan(share[:3]).all()                    # a never reads its own rows, and nobody else was there before
    assert share[3] == 0.0                              # b reads a's cold row of yesterday, not a's hot rows of today
    assert share[4] == 1.0 and share[5] == 1.0          # the next day b reads a's two hot rows; its own row is out
    assert np.isclose(share[6], 2 / 3)                  # c reads a's two hot rows and b's cold row
    # b's two rows share a second: each one's previous row is b's row of yesterday, never the other one.
    assert previous[4] == 0.0 and previous[5] == 0.0
    assert np.isnan(previous[3]) and np.isnan(previous[6])        # b and c have no earlier row there


def test_previous_merchant_columns_are_the_values_of_the_previous_row():
    """On made-up rows each previous-merchant value equals the heat of the account's latest strictly earlier second."""
    df = _rows(seed=4, n_accounts=40)
    got = heat.heat_features(df, *heat.build_heat_tables(df))
    secs = timekeys.seconds(df[TIME])
    acct = df[ACCOUNT].to_numpy()
    for i in range(0, len(df), 37):
        earlier = np.flatnonzero((acct == acct[i]) & (secs < secs[i]))
        if len(earlier):
            last = earlier[secs[earlier] == secs[earlier].max()]           # every row of the latest earlier second
            values = got["heat_mean_7d"].to_numpy(dtype=float)[last]
            expected = np.nanmean(values) if np.isfinite(values).any() else np.nan
        else:
            expected = np.nan
        assert _same(got["heat_prev_mean_7d"].iloc[i], expected)


def test_the_own_account_is_absent_tables_add_up_and_later_days_change_nothing():
    """An account reads what it would read without its rows in the panel; tables add; later rows change nothing."""
    df = _rows(seed=2)
    cut = heat.alert_cut(df[SCORE])
    one = (df[ACCOUNT] == pd.unique(df[ACCOUNT])[5]).to_numpy()
    inside = heat.heat_features(df[one], *heat.build_heat_tables(df, cut))
    alone = heat.heat_features(df[one], heat.build_heat_tables(df[~one], cut)[0], None)
    assert np.allclose(inside.to_numpy(), alone.to_numpy(), rtol=1e-5, atol=1e-5, equal_nan=True)
    part = pd.factorize(df[ACCOUNT])[0] % 3
    added = heat.combine([heat.build_heat_tables(df[part == f], cut) for f in range(3)])
    a, b = heat.heat_features(df, *added), heat.heat_features(df, *heat.build_heat_tables(df, cut))
    assert np.allclose(a.to_numpy(), b.to_numpy(), rtol=1e-5, atol=1e-5, equal_nan=True)
    day = _day(df)
    keep = day <= np.median(day)
    short = heat.heat_features(df[keep], *heat.build_heat_tables(df[keep], cut))
    assert np.allclose(b[keep].to_numpy(), short.to_numpy(), rtol=1e-5, atol=1e-5, equal_nan=True)


def test_missing_columns_are_skipped_and_the_command_line_runs(capsys):
    """Without scores nothing is built and nothing stops; without category and state the columns still come."""
    df = _rows(seed=3, n_accounts=30)
    _panel._SAID.clear()
    tabs = heat.build_heat_tables(df.drop(columns=[SCORE]))
    assert tabs == (None, None) and heat.heat_features(df, *tabs).shape == (len(df), 0)
    bare = df.drop(columns=[MCC, STATE])
    got = heat.heat_features(bare, *heat.build_heat_tables(bare))
    assert got.shape[1] == 18 and np.isfinite(got.to_numpy()[~np.isnan(got.to_numpy())]).all()
    assert "note:" in capsys.readouterr().out
    frame = heat.main(["--demo"])
    assert frame.shape[1] == 18 and "heat_prev_alert_share_30d" in capsys.readouterr().out
