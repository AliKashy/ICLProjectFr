"""Tests of the average over several history lengths of one checkpoint.

The tool reuses the averaging code of seed_average, so the tests check what it adds (the names
of the views) and that the figures are those of that code on the same files.
"""
import numpy as np
import pandas as pd
import pytest

from additions import settings
from additions.common import ranking, synthetic, tables
from additions.reads import _rows, multi_history_average, seed_average

STANDARD = [settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL, settings.LABEL_COL, settings.AMOUNT_COL,
            settings.SCORE_COL]


@pytest.fixture(scope="module")
def views(tmp_path_factory):
    """Three prediction files of the same made-up rows, standing for three history lengths."""
    folder = tmp_path_factory.mktemp("views")
    df = synthetic.make_transactions(n_accounts=300, seed=5)
    paths = []
    for length in (20, 40, 80):
        scored = synthetic.make_scores(df, seed=length, strength=1.5)[STANDARD]
        paths.append(tables.write_table(scored, str(folder / f"h{length}.parquet")))
    return df, paths


def test_views_are_named_by_their_history_length(capsys):
    """Each file is named after its history length; a wrong count of lengths falls back to numbers."""
    assert multi_history_average.view_names(3, [20, 40, 80]) == ["history 20", "history 40", "history 80"]
    assert multi_history_average.view_names(2) == ["view 1", "view 2"]
    assert capsys.readouterr().out == ""
    assert multi_history_average.view_names(3, [20, 40]) == ["view 1", "view 2", "view 3"]
    assert "numbered instead" in capsys.readouterr().out


def test_figures_are_those_of_the_shared_averaging_code(views):
    """Apart from the names of the lines, the tables equal the ones seed_average gives for the same files."""
    _, paths = views
    mine = multi_history_average.read_views(paths, lengths=[20, 40, 80], draws=30)
    theirs = seed_average.read_files(paths, draws=30)
    assert mine["table"]["read"].tolist()[:3] == ["history 20", "history 40", "history 80"]
    for key in ("table", "overlap"):
        pd.testing.assert_frame_equal(mine[key].drop(columns="read"), theirs[key].drop(columns="read"))
    pd.testing.assert_frame_equal(mine["bootstrap"], theirs["bootstrap"])
    assert np.array_equal(mine["logits"], theirs["logits"])


def test_the_same_view_three_times_averages_to_that_view(views):
    """Views that do not differ give an average with the capture of the single view and no gain."""
    _, paths = views
    result = multi_history_average.read_views([paths[0]] * 3, lengths=[20, 20, 20], draws=20)
    table = result["table"].set_index("read")
    assert np.isclose(table.loc["average of logits", "udr"], table.loc["mean of files", "udr"])
    assert np.isclose(table.loc["average of logits", "gain_over_mean"], 0.0)
    assert (result["overlap"]["share"] == 1.0).all()
    assert result["bootstrap"].loc[0, "gain"] == 0 and result["bootstrap"].loc[0, "high"] == 0


def test_tool_prints_the_views_and_writes_their_average(views, tmp_path, capsys):
    """The written score is the mean of the logits of the views, for every shared row."""
    df, paths = views
    out = str(tmp_path / "averaged.parquet")
    multi_history_average.main(["--preds", *paths, "--lengths", "20", "40", "80", "--draws", "20", "--out", out])
    printed = capsys.readouterr().out
    for text in ("Capture of each history length", "history 40", "Alerts shared with the first view",
                 "Average of logits against the first view"):
        assert text in printed
    logits = [ranking.to_logit(synthetic.make_scores(df, seed=length, strength=1.5)[settings.SCORE_COL])
              for length in (20, 40, 80)]
    expected = 1.0 / (1.0 + np.exp(-np.mean(logits, axis=0)))
    written = _rows.load_predictions(out).set_index(settings.ID_COL)
    assert len(written) == len(df)
    assert np.allclose(written[settings.SCORE_COL].reindex(df[settings.ID_COL]).to_numpy(), expected)
