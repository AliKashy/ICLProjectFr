"""Tests of the stored account state as prefix positions (additions/model/state_prefix.py).

The state must equal a slow sum over strictly earlier seconds, ignore later rows and rows of
the same second, turn into features that do not depend on when they are read, and become
prefix positions that stage 2 can read with gradients flowing back.
"""
import numpy as np
import torch

from additions import settings
from additions.common import synthetic, timekeys
from additions.model import masks
from additions.model.history_stage import HistoryStage
from additions.model.state_prefix import HALF_LIVES, StatePrefix, account_state, state_features

HEADS, WIDTH, D = 4, 16, 6


def _rows(n_accounts=6, seed=0):
    """Accounts, seconds and made-up stored vectors of a small table with many same-second rows."""
    df = synthetic.make_transactions(n_accounts, days=6, seed=seed, tie_share=0.3)
    accounts = timekeys.codes(df[settings.ACCOUNT_COL])
    secs = timekeys.seconds(df[settings.TIME_COL])
    vectors = np.random.default_rng(seed).normal(size=(len(df), D))
    return accounts, secs, vectors


def _slow_state(accounts, secs, vectors, half_lives):
    """The faded sums and counts written as a plain double loop over rows, straight from the definition."""
    n = len(secs)
    sums = np.zeros((n, len(half_lives), vectors.shape[1]))
    counts = np.zeros((n, len(half_lives)))
    for r in range(n):
        for q in range(n):
            if accounts[q] == accounts[r] and secs[q] < secs[r]:
                fade = 0.5 ** ((secs[r] - secs[q]) / np.asarray(half_lives, dtype=float))
                sums[r] += fade[:, None] * vectors[q][None, :]
                counts[r] += fade
    return sums, counts


def test_the_state_equals_a_slow_sum_over_strictly_earlier_seconds():
    """Faded sums and counts equal the double loop, which only lets strictly earlier seconds count."""
    accounts, secs, vectors = _rows()
    sums, counts = account_state(accounts, secs, vectors)
    slow_sums, slow_counts = _slow_state(accounts, secs, vectors, HALF_LIVES)
    assert sums.shape == (len(secs), len(HALF_LIVES), D) and counts.shape == (len(secs), len(HALF_LIVES))
    assert np.allclose(sums, slow_sums, atol=1e-9) and np.allclose(counts, slow_counts, atol=1e-9)


def test_rows_of_one_second_and_later_rows_are_not_in_the_state():
    """Two rows of one second see neither each other nor anything later; the first row of an account sees nothing."""
    accounts = np.array([0, 0, 0, 0, 1])
    secs = np.array([100, 200, 200, 300, 200], dtype=np.int64)
    vectors = np.array([[1.0], [10.0], [20.0], [40.0], [80.0]])
    sums, counts = account_state(accounts, secs, vectors, half_lives=[1e12])        # practically no fading
    assert np.allclose(sums[:, 0, 0], [0.0, 1.0, 1.0, 31.0, 0.0])
    assert np.allclose(counts[:, 0], [0.0, 1.0, 1.0, 3.0, 0.0])
    # A later row changed out of all recognition leaves every earlier state as it was.
    changed = vectors.copy()
    changed[3] = 1e6
    assert np.allclose(account_state(accounts, secs, changed, half_lives=[1e12])[0][:4], sums[:4])


def test_the_mean_does_not_depend_on_when_the_state_is_read():
    """Fading sum and count by the same factor leaves the mean part of the features unchanged."""
    accounts, secs, vectors = _rows(seed=1)
    sums, counts = account_state(accounts, secs, vectors)
    s, c = torch.as_tensor(sums), torch.as_tensor(counts)
    feats = state_features(s, c)
    later = state_features(s * 0.25, c * 0.25)
    assert feats.shape == (len(secs), len(HALF_LIVES), D + 1)
    has = c > 1e-3
    assert torch.allclose(feats[..., :D][has], later[..., :D][has], atol=1e-8)
    # The log count is what tells how much history there is; it fades with the reading time.
    assert torch.all(later[..., D][has] < feats[..., D][has])


def test_an_account_without_history_gives_zero_features():
    """A time scale with no earlier rows gives a zero mean and a zero log count, never a NaN."""
    feats = state_features(torch.zeros(2, 3, D), torch.zeros(2, 3))
    assert torch.equal(feats, torch.zeros(2, 3, D + 1))
    block = StatePrefix(vector_dim=D, out_dim=WIDTH, num_states=3)
    out = block(torch.zeros(2, 3, D), torch.zeros(2, 3))
    # With nothing to read, the positions are the projection's bias plus the learned vector of each time scale.
    assert torch.allclose(out, (block.project.bias + block.scale).expand(2, 3, WIDTH))


def test_prefix_positions_have_the_stage_two_shape_and_pass_gradients():
    """The prefix is [B, H, width], finite, readable by stage 2, and every weight gets a gradient."""
    accounts, secs, vectors = _rows(seed=2)
    sums, counts = account_state(accounts, secs, vectors)
    first = np.array([3, 10, 25])                                  # the first rows of three sequences
    block = StatePrefix(vector_dim=D, out_dim=WIDTH)
    prefix = block(torch.as_tensor(sums[first]).float(), torch.as_tensor(counts[first]).float())
    assert prefix.shape == (3, len(HALF_LIVES), WIDTH) and torch.isfinite(prefix).all()

    torch.manual_seed(0)
    stage2 = HistoryStage(in_dim=WIDTH, num_heads=HEADS, num_blocks=1, history_len=8, dropout=0.0, attn_dropout=0.0)
    times = torch.tensor([[5, 6, 6, 9], [1, 2, 3, 0], [4, 4, 4, 4]])
    valid = torch.tensor([[True] * 4, [True, True, True, False], [True] * 4])
    x = torch.randn(3, 4, WIDTH)
    out = stage2(x, times, valid, prefix=prefix)
    assert out.shape == (3, 4, WIDTH) and torch.isfinite(out).all()
    # Every row reads the prefix, so the prefix really changes every real row's output.
    plain = stage2(x, times, valid)
    assert not torch.allclose(out[valid], plain[valid], atol=1e-5)
    out[valid].sum().backward()
    for name, p in block.named_parameters():
        assert p.grad is not None and torch.isfinite(p.grad).all() and p.grad.abs().sum() > 0, name


def test_later_rows_do_not_change_earlier_outputs_when_a_prefix_is_read():
    """With a prefix in front, altering the last second of a sequence leaves the earlier rows unchanged."""
    torch.manual_seed(1)
    block = StatePrefix(vector_dim=D, out_dim=WIDTH, num_states=2)
    stage2 = HistoryStage(in_dim=WIDTH, num_heads=HEADS, num_blocks=2, history_len=8, dropout=0.0, attn_dropout=0.0)
    prefix = block(torch.randn(1, 2, D), torch.rand(1, 2) * 5)
    times = torch.tensor([[1, 2, 2, 3, 7, 7]])
    valid = torch.ones(1, 6, dtype=torch.bool)
    x = torch.randn(1, 6, WIDTH)
    before = stage2(x, times, valid, prefix=prefix)
    x2 = x.clone()
    x2[0, 4:] = torch.randn(2, WIDTH) * 10
    after = stage2(x2, times, valid, prefix=prefix)
    assert torch.allclose(before[0, :4], after[0, :4], atol=1e-6)
    assert not torch.allclose(before[0, 4:], after[0, 4:], atol=1e-3)
    # The prefix rule itself: rows read the prefix, the prefix reads only itself.
    allowed = masks.with_prefix(masks.strict_visibility(times, valid), 2)
    assert allowed[0, 2:, :2].all() and not allowed[0, :2, 2:].any()


def test_numpy_arrays_and_a_single_half_life_are_accepted():
    """`state_features` takes the arrays of `account_state` as they come, and one half-life gives H = 1."""
    accounts, secs, vectors = _rows(seed=3)
    sums, counts = account_state(accounts, secs, vectors, half_lives=86_400)
    assert sums.shape == (len(secs), 1, D) and counts.shape == (len(secs), 1)
    assert torch.allclose(state_features(sums, counts), state_features(torch.as_tensor(sums), torch.as_tensor(counts)))
