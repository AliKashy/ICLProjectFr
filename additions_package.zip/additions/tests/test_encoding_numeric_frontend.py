"""Tests of the numeric front end.

The scales, the bin edges and the bin encoding are compared with slow, obvious computations
on small made-up tables. The network blocks are checked for shapes, finite values and
gradient flow, and for giving exactly the plain linear token while their extra parts are
still at zero. A saved state of every scaler, the [0, 1] scale of numeric_encoders.py included,
must rebuild the same scale, and the file must import from a folder of its own with neither
the package nor pandas, scipy or scikit-learn.
"""
import os
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np
import pytest
import torch
from scipy.special import ndtri

from additions import settings
from additions.common import synthetic
from additions.encoding import numeric_encoders as ne
from additions.encoding import numeric_frontend as nf


def _tables():
    """Two made-up tables with different accounts: one to fit on, one to apply the fit to."""
    return synthetic.make_transactions(n_accounts=120, seed=0), synthetic.make_transactions(n_accounts=60, seed=1)


def test_signed_log_matches_its_definition_in_numpy_and_torch():
    """The signed log equals sign(x) * log(1 + |x|) value by value, is odd, keeps the order, and both versions agree."""
    x = np.array([-50000.0, -3.2, -1.0, 0.0, 0.01, 1.0, 5.0, 21.71, 50000.0, np.nan])
    out = nf.signed_log1p(x)
    slow = [np.nan if np.isnan(v) else float(np.sign(v)) * np.log(1.0 + abs(v)) for v in x]
    assert np.allclose(out, slow, equal_nan=True)
    assert np.allclose(nf.signed_log1p(-x[:-1]), -out[:-1])          # odd: the sign survives
    assert (np.diff(out[:-1]) > 0).all()                               # the order of the values is kept
    assert np.allclose(nf.signed_log1p(torch.tensor(x)).numpy(), out, equal_nan=True)


def test_log_scale_separates_small_amounts_that_a_raw_scale_hides():
    """One dollar and five dollars are far apart on the log scale and nearly one point on the raw z-scale."""
    train, other = _tables()
    amount = train[settings.AMOUNT_COL].to_numpy(dtype=float)
    amount = np.concatenate([amount, [50_000.0, 35_000.0]])            # a few very large rows set the raw spread
    scaler = nf.LogScaler().fit(amount)
    raw_step = (5.0 - 1.0) / amount.std()
    log_step = float(np.diff(scaler.transform(np.array([1.0, 5.0]))[:, 0])[0])
    assert log_step > 10 * raw_step
    # On the training rows the scaled column has mean 0 and spread 1, and equals the slow formula.
    scaled = scaler.transform(amount)[:, 0]
    logged = np.sign(amount) * np.log1p(np.abs(amount))
    assert abs(scaled.mean()) < 1e-4 and abs(scaled.std() - 1.0) < 1e-4
    assert np.allclose(scaled, (logged - logged.mean()) / logged.std(), atol=1e-5)
    # Other rows are scaled with the training mean and spread, and a missing value stays missing.
    new = other[settings.AMOUNT_COL].to_numpy(dtype=float)[:50]
    expected = (np.sign(new) * np.log1p(np.abs(new)) - logged.mean()) / logged.std()
    assert np.allclose(scaler.transform(new)[:, 0], expected, atol=1e-5)
    assert np.isnan(scaler.transform(np.array([np.nan, 3.0]))[0, 0])
    # A field that never varies is scaled to zero; its spread of nothing is not divided by.
    assert np.abs(nf.LogScaler().fit(np.full(20, 7.0)).transform(np.full(5, 7.0))).max() < 1e-9
    again = nf.scaler_from_state(scaler.state())
    assert isinstance(again, nf.LogScaler) and np.array_equal(again.transform(new), scaler.transform(new))


def test_quantile_scale_is_the_rank_on_a_normal_curve():
    """With one step per training row the scaled value is the row's rank read on the normal curve."""
    rng = np.random.default_rng(0)
    values = rng.lognormal(3.0, 1.5, 300)
    scaler = nf.QuantileScaler(n_quantiles=300).fit(values)
    rank = np.argsort(np.argsort(values))                               # 0 for the smallest row
    edge = 0.5 / 299
    slow = ndtri(np.clip(rank / 299.0, edge, 1.0 - edge))
    out = scaler.transform(values)[:, 0]
    assert np.allclose(out, slow, atol=1e-4)
    # The order is kept, the shape is a bell whatever the raw shape was, and no value can run away.
    grid = np.sort(rng.lognormal(3.0, 2.0, 500))
    assert (np.diff(scaler.transform(grid)[:, 0]) >= 0).all()
    assert abs(out.mean()) < 0.05 and abs(out.std() - 1.0) < 0.1
    huge = scaler.transform(np.array([1e12, -1e12, np.inf]))[:, 0]
    assert np.allclose(huge, [ndtri(1 - edge), ndtri(edge), ndtri(1 - edge)], atol=1e-4)
    assert np.isnan(scaler.transform(np.array([np.nan]))[0, 0])
    again = nf.scaler_from_state(scaler.state())
    assert isinstance(again, nf.QuantileScaler) and np.array_equal(again.transform(grid), scaler.transform(grid))


def test_quantile_scale_puts_a_heap_of_equal_values_in_the_middle_of_its_stretch():
    """Many rows with one value all land on one point: the middle of the shares that the value covers."""
    values = np.concatenate([np.zeros(60), np.arange(1, 41, dtype=float)])     # 60 rows at zero, then 40 distinct
    scaler = nf.QuantileScaler(n_quantiles=100).fit(values)
    at_zero = scaler.transform(np.zeros(3))[:, 0]
    assert np.allclose(at_zero, at_zero[0])
    # Ranks 0 to 59 share the value, so the middle is rank 29.5 of 99; the stored table is exact to one step.
    assert abs(at_zero[0] - ndtri(29.5 / 99.0)) < 0.03
    assert scaler.transform(np.array([1.0]))[0, 0] > at_zero[0]


def test_quantile_edges_give_every_bin_the_same_share_of_rows():
    """Each bin between two neighbouring edges holds about the same number of training rows."""
    rng = np.random.default_rng(1)
    values = np.column_stack([rng.lognormal(3.0, 1.0, 4000), rng.choice([0.0, 1.0, 2.0], 4000)])
    edges = nf.quantile_edges(values, n_bins=16)
    assert edges.shape == (2, 17) and edges.dtype == np.float32
    assert (np.diff(edges, axis=1) >= 0).all()
    assert np.isclose(edges[0, 0], values[:, 0].min()) and np.isclose(edges[0, -1], values[:, 0].max())
    counts = np.histogram(values[:, 0], bins=edges[0].astype(np.float64))[0]
    assert counts.sum() >= 3990 and np.abs(counts - 250).max() <= 10
    # A field with three values has three distinct edges; the others repeat the last one.
    assert np.unique(edges[1]).tolist() == [0.0, 1.0, 2.0] and (edges[1, 2:] == 2.0).all()


def test_tree_edges_fall_where_the_fraud_rate_changes():
    """A shallow tree places edges at the two points where the fraud rate jumps, and respects the bin floor."""
    rng = np.random.default_rng(2)
    x = rng.uniform(0.0, 10.0, 20_000)
    risky = (x > 4.0) & (x < 6.0)
    y = (rng.random(len(x)) < np.where(risky, 0.30, 0.01)).astype(int)
    edges = nf.tree_edges(x, y, n_bins=8, min_leaf_share=0.01)[0]
    assert edges.shape == (9,) and (np.diff(edges) >= 0).all()
    assert np.abs(edges - 4.0).min() < 0.25 and np.abs(edges - 6.0).min() < 0.25
    real = np.unique(edges)
    assert np.histogram(x, bins=real.astype(np.float64))[0].min() >= 0.01 * len(x) - 1
    # With one class only there is nothing to split on and the quantile edges are kept.
    assert np.array_equal(nf.tree_edges(x, np.zeros(len(x), dtype=int), n_bins=8), nf.quantile_edges(x, 8))


def test_bin_encoding_matches_the_slow_definition_and_rebuilds_the_value():
    """Each share equals the clipped position inside its bin, and the shares times the bin widths give the value back."""
    rng = np.random.default_rng(3)
    edges = np.array([[-2.0, -1.0, 0.0, 0.5, 3.0], [0.0, 1.0, 1.0, 1.0, 1.0]], dtype=np.float32)
    block = nf.PiecewiseLinearEmbedding(edges, embed_dim=6)
    x = torch.tensor(rng.uniform(-3.0, 4.0, (40, 2)), dtype=torch.float32)
    share = block.encode(x)
    assert share.shape == (40, 2, 4)
    for n in range(40):
        for c in range(2):
            for b in range(4):
                left, right = float(edges[c, b]), float(edges[c, b + 1])
                slow = 0.0 if right == left else min(max((float(x[n, c]) - left) / (right - left), 0.0), 1.0)
                assert abs(float(share[n, c, b]) - slow) < 1e-5
    rebuilt = torch.tensor(edges[:, 0]) + (share * block.width).sum(-1)
    clipped = torch.minimum(torch.maximum(x, torch.tensor(edges[:, 0])), torch.tensor(edges[:, -1]))
    assert torch.allclose(rebuilt, clipped, atol=1e-5)
    # The token has the right shape, is finite, and every bin weight that a value reaches gets a gradient.
    tokens = block(x)
    assert tokens.shape == (40, 2, 6) and bool(torch.isfinite(tokens).all())
    tokens.sum().backward()
    assert float(block.weight.grad[0].abs().sum()) > 0
    assert float(block.weight.grad[1, 1:].abs().sum()) == 0             # bins of zero width never learn
    silent = nf.PiecewiseLinearEmbedding(edges, embed_dim=6, zero_init=True)
    assert float(silent(x).detach().abs().sum()) == 0


def test_score_table_reads_one_row_per_value_plus_a_linear_term():
    """Every score value reads its own row, a missing score reads the last row, and the start is the linear term."""
    torch.manual_seed(0)
    block = nf.ScoreTableEmbedding(embed_dim=5, n_values=100)
    score = torch.tensor([0.0, 3.0, 3.2, 99.0, 150.0, -4.0, float("nan")])
    unit = torch.tensor([0.0, 3.0, 3.2, 99.0, 99.0, 0.0, 49.5]) / 99.0 * 2.0 - 1.0
    linear = unit[:, None] * block.weight + block.bias
    out = block(score)
    assert out.shape == (7, 5) and bool(torch.isfinite(out).all())
    assert torch.allclose(out, linear, atol=1e-6)                        # the table starts at zero
    with torch.no_grad():
        block.table.weight.copy_(torch.arange(101.0)[:, None].expand(101, 5))
    rows = (block(score) - linear)[:, 0]
    assert torch.allclose(rows, torch.tensor([0.0, 3.0, 3.0, 99.0, 99.0, 0.0, 100.0]), atol=1e-4)
    block.zero_grad()
    block(score).sum().backward()
    touched = torch.nonzero(block.table.weight.grad.abs().sum(1)).flatten().tolist()
    assert touched == [0, 3, 99, 100]                                    # only the rows that were read learn


def test_amount_flags_match_a_slow_loop():
    """Cents, round-amount flags and the small-amount bucket equal a value-by-value computation."""
    train, _ = _tables()
    picked = [0.0, np.nan, 0.99, 1.00, 1.99, 2.0, 4.999, 5.00, 9.99, 10.0, 25.00, 100.00, 12.34, -20.00, 1000.0]
    amounts = np.concatenate([picked, train[settings.AMOUNT_COL].to_numpy(dtype=float)[:300]])
    out = nf.amount_flags(amounts)
    sizes = nf.amount_flag_sizes()
    assert set(out) == set(sizes) == {"amount_cents", "amount_whole_dollar", "amount_round_5", "amount_round_100",
                                      "amount_small_bucket"}
    for i, a in enumerate(amounts):
        cents = 0 if np.isnan(a) else int(round(abs(a) * 100))
        if cents == 0:
            slow = (100, 0, 0, 0, 0)                                     # no amount: its own cents code, no flag
        else:
            bucket = 1 + sum(cents >= int(round(cut * 100)) for cut in nf.SMALL_AMOUNT_EDGES)
            slow = (cents % 100, int(cents % 100 == 0), int(cents % 500 == 0), int(cents % 10_000 == 0), bucket)
        got = tuple(int(out[name][i]) for name in ("amount_cents", "amount_whole_dollar", "amount_round_5",
                                                    "amount_round_100", "amount_small_bucket"))
        assert got == slow
    for name, size in sizes.items():
        assert out[name].dtype == np.int64 and out[name].min() >= 0 and out[name].max() == size - 1


def test_front_end_starts_as_the_plain_linear_token():
    """While the bins and the table are at zero the block gives x * weight + bias, with or without bins."""
    torch.manual_seed(1)
    x = torch.randn(30, 4)
    x[2, 1] = float("nan")
    plain = nf.NumericFrontEnd(4, embed_dim=8)
    filled = torch.where(torch.isnan(x), torch.zeros_like(x), x)        # a missing value reads the centre
    assert torch.equal(plain(x), filled[:, :, None] * plain.weight + plain.bias)
    edges = nf.quantile_edges(filled.numpy(), n_bins=6)
    binned = nf.NumericFrontEnd(4, edges, embed_dim=8)
    with torch.no_grad():
        binned.weight.copy_(plain.weight)
    assert torch.allclose(binned(x), plain(x), atol=1e-7)
    # Once the bins hold weights the token changes, and a batch of sequences gives the same tokens as flat rows.
    with torch.no_grad():
        binned.bins.weight.normal_()
    assert not torch.allclose(binned(x), plain(x))
    assert torch.allclose(binned(x.reshape(5, 6, 4)), binned(x).reshape(5, 6, 4, 8), atol=1e-6)


def test_front_end_on_made_up_rows_has_the_right_shape_and_trains(capsys):
    """Fitted on one table and applied to another, the block gives finite [rows, C, d] tokens and every part learns."""
    train, other = _tables()
    fitted = nf.fit_front_end(train, n_bins=12)
    present = [c for c in settings.NUMERIC_COLS if c in train.columns]
    assert "they are skipped" in capsys.readouterr().out                 # one input of settings is not in the table
    assert fitted["columns"] == present and fitted["edges"].shape == (len(present), 13)
    j = fitted["score_index"]
    assert present[j] == settings.VISA_SCORE_COL
    x = nf.scale_numbers(other, fitted)
    assert x.shape == (len(other), len(present)) and x.dtype == np.float32
    assert np.array_equal(x[:, j], other[settings.VISA_SCORE_COL].to_numpy(dtype=np.float32))   # the score stays raw
    # A row is scaled the same whichever other rows are scored with it: nothing is fitted at scoring.
    assert np.array_equal(nf.scale_numbers(other.iloc[:25], fitted), x[:25])
    front = nf.NumericFrontEnd(len(present), fitted["edges"], embed_dim=8, score_index=j)
    batch = torch.as_tensor(x[:200]).clone()
    batch[0, 0] = float("nan")
    tokens = front(batch)
    assert tokens.shape == (200, len(present), 8) and bool(torch.isfinite(tokens).all())
    assert torch.allclose(tokens[:, j], front.score(batch[:, j]))        # the score field comes from the table
    others = [c for c in range(len(present)) if c != j]
    filled = torch.where(torch.isnan(batch), torch.zeros_like(batch), batch)
    assert torch.allclose(tokens[:, others], (filled[:, :, None] * front.weight + front.bias)[:, others], atol=1e-6)
    tokens.pow(2).sum().backward()
    for grad in (front.weight.grad, front.bins.weight.grad, front.score.table.weight.grad, front.score.weight.grad):
        assert grad is not None and float(grad.abs().sum()) > 0
    # The other choices run too: a quantile scale, label-aware edges, and no score table.
    choice = nf.fit_front_end(train, scale="quantile", edges="tree", n_bins=12, score_col="")
    assert choice["score_index"] is None and choice["edges"].shape == (len(present), 13)
    assert str(choice["scaler"]["kind"]) == "quantile" and np.isfinite(nf.scale_numbers(other, choice)).all()
    assert nf.fit_front_end(train, edges=None)["edges"] is None
    assert "quantile edges are used" in _note(lambda: nf.fit_front_end(train, edges="tree", label_col="absent"), capsys)


def _note(call, capsys):
    """Run `call` and return what it printed."""
    capsys.readouterr()
    call()
    return capsys.readouterr().out


def test_a_saved_unit_quantile_state_rebuilds_its_scale_through_the_loader_of_this_file():
    """scaler_from_state reads the state of UnitQuantileScaler (numeric_encoders.py) as well as its own two kinds, so
    scale_numbers works on the [0, 1] scale; a state of an unknown kind is a plain error that names the kinds."""
    train, other = _tables()
    columns = [c for c in settings.NUMERIC_COLS if c in train.columns]
    raw_train, raw_other = nf._numbers(train, columns), nf._numbers(other, columns)
    unit = ne.UnitQuantileScaler().fit(raw_train)
    again = nf.scaler_from_state(unit.state())
    assert type(again).__name__ == "UnitQuantileScaler"
    assert np.array_equal(again.transform(raw_other), unit.transform(raw_other), equal_nan=True)
    # The whole route of the front end: a fitted dict that carries the unit scale gives values on [0, 1].
    fitted = {"columns": columns, "scaler": unit.state(), "edges": None, "score_index": None}
    scaled = nf.scale_numbers(other, fitted)
    assert np.array_equal(scaled, unit.transform(raw_other), equal_nan=True)
    assert np.nanmin(scaled) >= 0.0 and np.nanmax(scaled) <= 1.0
    with pytest.raises(ValueError, match="unit_quantile"):
        nf.scaler_from_state({"kind": "minmax", "low": np.zeros(2), "high": np.ones(2)})


# Run in a fresh interpreter inside a folder that holds copies of the files: pandas, scipy and scikit-learn are made
# unimportable before anything else is imported, and the folder that holds `additions/` is not on the path.
FLAT_RUN = """
import sys
for name in ("pandas", "scipy", "sklearn"):
    sys.modules[name] = None
import numpy as np
import torch
import numeric_frontend as nf
import numeric_encoders as ne
assert "additions" not in sys.modules, "the package was imported"
edges = nf.quantile_edges(np.random.default_rng(0).random((500, 3)), 8)
block = nf.PiecewiseLinearEmbedding(edges)
print("token width", block.weight.shape[-1])
front = nf.NumericFrontEnd(3, edges, embed_dim=8)
print("front end finite", bool(torch.isfinite(front(torch.rand(4, 3))).all()))
log = nf.LogScaler().fit(np.random.default_rng(1).lognormal(size=(200, 3)))
print("log scale", nf.scaler_from_state(log.state()).transform(np.ones((1, 3))).shape)
unit = ne.UnitQuantileScaler().fit(np.random.default_rng(2).lognormal(size=(200, 3)))
print("unit scale", type(nf.scaler_from_state(unit.state())).__name__)
try:
    nf.QuantileScaler().fit(np.ones((5, 1))).transform(np.ones((2, 1)))
except ImportError:
    print("scipy is read only by the normal curve")
"""


def test_the_module_imports_from_a_folder_of_its_own_without_pandas_scipy_or_sklearn(tmp_path):
    """Copied next to numeric_encoders.py into an empty folder, with no path to the package and with pandas, scipy and
    scikit-learn unimportable, the file imports, its blocks run and its loader reads every scaler state; only the
    normal curve of QuantileScaler asks for scipy, at the moment it is used."""
    here = Path(nf.__file__).parent
    for name in ("numeric_frontend.py", "numeric_encoders.py"):
        shutil.copy(here / name, tmp_path / name)
    env = {name: value for name, value in os.environ.items() if name != "PYTHONPATH"}
    env.update(OMP_NUM_THREADS="1", MKL_NUM_THREADS="1")
    result = subprocess.run([sys.executable, "-c", FLAT_RUN], cwd=tmp_path, env=env, capture_output=True, text=True,
                            timeout=600)
    assert result.returncode == 0, result.stderr
    # Without settings.py the token width is the one of the model in use, FLAT_EMBED_DIM.
    assert f"token width {nf.FLAT_EMBED_DIM}" in result.stdout
    for line in ("front end finite True", "log scale (1, 3)", "unit scale UnitQuantileScaler",
                 "scipy is read only by the normal curve"):
        assert line in result.stdout, result.stdout
