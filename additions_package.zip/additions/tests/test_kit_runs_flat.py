"""The kit of best_model_template.py runs from a flat folder of its twelve files, with torch and numpy alone.

The kit is what is copied next to the model in use: best_model_template.py, the nine modules it and its docstring
need, and the two notes its text sends the reader to. Copied into an empty folder, with no path to the package, and
with pandas, scipy and sklearn blocked, every module must import from that folder, and the template's run must answer
yes to every check of every named configuration. A kit file that reaches into the package by an absolute import, or
that needs pandas, scipy or sklearn when it is imported, fails here.
"""
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

# The ten modules of the kit, by the folder of the package that holds each, and its two notes, which sit at the top of
# the package.
KIT = {
    "model": ("best_model_template.py", "latent_channels.py", "interleaved_reread.py", "masks.py", "attention_bias.py",
              "interleaved_wiring_template.py"),
    "encoding": ("numeric_frontend.py", "numeric_encoders.py", "time_encoders.py"),
    "reads": ("scoring_speed.py",),
}
NOTES = ("CONFIGURATIONS.md", "INTERLEAVED_REREAD.md")

# What runs in the folder. The blocked names stand in sys.modules as None, so that importing one of them stops with
# ImportError, as it does on a machine without it; "additions" is blocked as well, so that no import can reach the
# package even where it is installed. Every module is imported, its file must lie in the folder, and the template's
# run is made at a small size.
RUNNER = """
import importlib
import sys
from pathlib import Path

for name in ("pandas", "scipy", "sklearn", "additions"):
    sys.modules[name] = None
here = Path.cwd().resolve()
names = sys.argv[1:]
for name in names:
    module = importlib.import_module(name)
    assert Path(module.__file__).resolve().parent == here, (name, module.__file__)
    print("imported", name)
import best_model_template
results, table = best_model_template.main(sequences=2, rows=10, repeats=1)
loaded = sorted(name for name in ("pandas", "scipy", "sklearn") if sys.modules.get(name) is not None)
print("loaded from the blocked names:", loaded)
print("named configurations:", " ".join(results))
"""


def test_the_kit_imports_and_answers_yes_from_a_flat_folder(tmp_path):
    """Exactly the twelve files, an empty folder, no PYTHONPATH, pandas, scipy and sklearn blocked: every module imports
    from the folder, and every check of every named configuration of the template's run prints yes."""
    additions = Path(__file__).resolve().parents[1]
    for folder, names in KIT.items():
        for name in names:
            shutil.copy(additions / folder / name, tmp_path / name)
    for name in NOTES:
        shutil.copy(additions / name, tmp_path / name)
    files = sorted([n for names in KIT.values() for n in names] + list(NOTES))
    assert sorted(path.name for path in tmp_path.iterdir()) == files and len(files) == 12
    # The template's own text names the same twelve files, the two notes among them and not marked package only.
    text = (tmp_path / "best_model_template.py").read_text()
    pod = text.split("What to change for the pod")[1].split("PLACEHOLDER")[0]
    assert "twelve files" in pod and all(name in pod for name in files), pod
    assert all(f"{name} (package only)" not in pod for name in NOTES), pod
    modules = [name[:-3] for names in KIT.values() for name in names]
    # No path to the package: the folder itself is the only place the kit can be found.
    env = {name: value for name, value in os.environ.items() if name != "PYTHONPATH"}
    env.update(OMP_NUM_THREADS="1", MKL_NUM_THREADS="1")
    result = subprocess.run([sys.executable, "-c", RUNNER, *modules], cwd=tmp_path, env=env, capture_output=True,
                            text=True, timeout=900)
    assert result.returncode == 0, result.stderr + result.stdout
    out = result.stdout
    for name in modules:
        assert f"imported {name}" in out, name
    checked = [line for line in out.splitlines() if "weights |" in line]
    assert [line.split()[0] for line in checked] == ["TODAY", "WIDE_JOINED", "CANDIDATE", "CANDIDATE_LPM"], out
    for line in checked:
        assert line.count(": yes") == 7 and ": NO" not in line, line
    assert "x TODAY" in out and "loaded from the blocked names: []" in out
    # Nothing was written next to the kit but the cache of the imports.
    assert {path.name for path in tmp_path.iterdir()} - {"__pycache__"} == set(files)


def test_the_test_paths_named_in_the_kit_are_marked_package_only():
    """The tests do not travel with the kit, so every test file that the template, the wiring template and the speed
    card name (a pytest line, or a test file named in the text) is marked package only on the line that names it,
    as the kit marks every other file outside it."""
    additions = Path(__file__).resolve().parents[1]
    for folder, name in (("model", "best_model_template.py"), ("model", "interleaved_wiring_template.py"),
                         ("reads", "scoring_speed.py")):
        text = (additions / folder / name).read_text()
        named = list(re.finditer(r"test_[a-z_]+\.py", text))
        assert named, name
        for found in named:
            end = text.find("\n", found.end())
            assert "package only" in text[found.start():end], (name, text[found.start():end])
