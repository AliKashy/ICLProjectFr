"""Tests of the noise budget.

Every formula is compared with a direct simulation of what it describes: frauds caught at
random, a measured gain made of block noise and seed noise, and a rule that only adopts reads
above a threshold. The measured inputs are compared with plain calls on made-up scores.
"""
import numpy as np
import pytest
from scipy import stats

from additions import settings
from additions.common import ranking, synthetic, tables
from additions.common.bootstrap import paired_bootstrap
from additions.proof import _shared, noise_budget


def test_binomial_errors_match_frauds_caught_at_random():
    """The error of one rate and of a paired difference equal the spread over many simulated sets of frauds."""
    rng = np.random.default_rng(0)
    frauds, rate = 1_400, 0.55
    caught = rng.binomial(frauds, rate, 40_000) / frauds
    assert np.isclose(noise_budget.capture_se(frauds, rate), caught.std(), rtol=0.03)
    assert np.isclose(noise_budget.capture_se(frauds, rate, design_effect=4.0), 2.0 * noise_budget.capture_se(frauds, rate))
    # Every fraud falls in one of four cells: both catch it, only A, only B, neither.
    cells = rng.multinomial(frauds, [0.45, 0.10, 0.07, 0.38], 40_000)
    gain = (cells[:, 1] - cells[:, 2]) / frauds
    expected = noise_budget.paired_se_from_counts(0.10 * frauds, 0.07 * frauds, frauds)
    assert np.isclose(expected, gain.std(), rtol=0.03)
    # The paired difference is sharper than two separate rates, and far sharper for two similar models.
    separate = np.sqrt(2.0) * noise_budget.capture_se(frauds, rate)
    assert expected < separate
    assert noise_budget.paired_se_from_counts(0.03 * frauds, 0.02 * frauds, frauds) < 0.5 * separate
    assert noise_budget.paired_se_from_counts(0, 0, frauds) == 0.0


def test_gain_se_is_the_spread_of_block_noise_plus_seed_noise():
    """A gain simulated as one block draw plus the mean of each arm's seeds has the predicted spread."""
    rng = np.random.default_rng(1)
    sd_pair, sd_run, measured = 0.010, 0.004, 16
    for files, seeds in ((16, 1), (100, 1), (100, 5), (400, 3)):
        block = rng.normal(0.0, sd_pair * np.sqrt(measured / files), 200_000)
        arm = rng.normal(0.0, sd_run, (200_000, seeds)).mean(axis=1)
        control = rng.normal(0.0, sd_run, (200_000, seeds)).mean(axis=1)
        predicted = noise_budget.gain_se(sd_pair, sd_run, files, measured, seeds)
        assert np.isclose(predicted, (block + arm - control).std(), rtol=0.01)
    # Four times the files halve the block part; seeds leave it untouched.
    assert np.isclose(noise_budget.gain_se(sd_pair, 0.0, 64, 16), sd_pair / 2.0)
    assert np.isclose(noise_budget.gain_se(sd_pair, 0.0, 64, 16, seeds=9), sd_pair / 2.0)
    assert np.isclose(noise_budget.gain_se(0.0, sd_run, seeds=8), sd_run / 2.0)
    assert np.isclose(noise_budget.gain_se(sd_pair, sd_run), np.sqrt(sd_pair ** 2 + 2 * sd_run ** 2))
    assert noise_budget.gain_se(sd_pair, sd_run, 400, 16, 5) < noise_budget.gain_se(sd_pair, sd_run, 100, 16, 5)
    assert noise_budget.gain_se(sd_pair, sd_run, 100, 16, 5) < noise_budget.gain_se(sd_pair, sd_run, 100, 16, 1)


def test_pass_chance_and_overstatement_match_a_simulated_rule():
    """Among simulated reads, the share that passes and the mean excess of the passing ones equal the formulas."""
    rng = np.random.default_rng(2)
    for true_gain, se, bar in ((0.01, 0.008, 0.01), (0.01, 0.012, 0.01), (0.03, 0.008, 0.0), (0.0, 0.006, 0.005)):
        threshold = noise_budget.rule_threshold(se, bar)
        assert np.isclose(threshold, max(bar, 1.6449 * se), rtol=1e-4)
        measured = rng.normal(true_gain, se, 400_000)
        passed = measured[measured >= threshold]
        assert np.isclose(noise_budget.pass_chance(true_gain, se, threshold), len(passed) / len(measured), atol=0.004)
        assert np.isclose(noise_budget.overstatement(true_gain, se, threshold), passed.mean() - true_gain, rtol=0.03)
    # A small true gain against a noisy block: adopted about one time in three, and then about doubled.
    threshold = noise_budget.rule_threshold(0.008, 0.01)
    assert np.isclose(noise_budget.pass_chance(0.01, 0.008, threshold), 0.346, atol=0.002)
    assert np.isclose(noise_budget.overstatement(0.01, 0.008, threshold), 0.0085, atol=0.0002)
    # A larger true gain passes more often and is overstated less.
    assert noise_budget.pass_chance(0.03, 0.008, threshold) > noise_budget.pass_chance(0.02, 0.008, threshold) > 0.346
    assert noise_budget.overstatement(0.03, 0.008, threshold) < noise_budget.overstatement(0.02, 0.008, threshold)
    assert noise_budget.pass_chance(0.02, 0.0, 0.01) == 1.0 and noise_budget.pass_chance(0.005, 0.0, 0.01) == 0.0
    assert noise_budget.overstatement(0.02, 0.0, 0.01) == 0.0


def test_thresholds_detectable_gains_and_what_is_needed():
    """A detectable gain passes with the stated chance, and the seeds and files needed are the smallest that suffice."""
    sd_pair, sd_run = 0.010, 0.004
    se = noise_budget.gain_se(sd_pair, sd_run)
    assert np.isclose(noise_budget.single_fit_gain(sd_pair, sd_run), 1.6449 * se, rtol=1e-4)
    assert np.isclose(noise_budget.rule_threshold(se, 0.0, se_multiple=1.0), se)
    assert np.isclose(noise_budget.pass_chance(noise_budget.detectable_gain(se), se, noise_budget.rule_threshold(se)), 0.8)
    assert np.isclose(noise_budget.pass_chance(noise_budget.rule_threshold(se), se, noise_budget.rule_threshold(se)), 0.5)
    assert np.isclose(noise_budget.pass_chance(noise_budget.detectable_gain(se, 0.03, power=0.9), se, 0.03), 0.9)
    # The t value replaces the normal value when the spread comes from a few seeds.
    assert np.isclose(noise_budget.interval_multiple(90.0), 1.645, atol=1e-3)
    assert np.isclose(noise_budget.interval_multiple(90.0, 3), 2.920, atol=1e-3)
    assert np.isclose(noise_budget.interval_multiple(90.0, 5), 2.132, atol=1e-3)

    for target, files in ((0.01, 400), (0.012, 100), (0.02, 16)):
        k = noise_budget.seeds_needed(target, sd_pair, sd_run, files, 16)
        assert noise_budget.rule_threshold(noise_budget.gain_se(sd_pair, sd_run, files, 16, k)) <= target
        assert k == 1 or noise_budget.rule_threshold(noise_budget.gain_se(sd_pair, sd_run, files, 16, k - 1)) > target
    assert noise_budget.seeds_needed(0.01, sd_pair, sd_run, 16, 16) is None      # the block alone is too noisy
    for target, seeds in ((0.01, 3), (0.02, 1)):
        f = noise_budget.files_needed(target, sd_pair, sd_run, 16, seeds)
        assert noise_budget.rule_threshold(noise_budget.gain_se(sd_pair, sd_run, f, 16, seeds)) <= target
        assert noise_budget.rule_threshold(noise_budget.gain_se(sd_pair, sd_run, f - 1, 16, seeds)) > target
    assert noise_budget.files_needed(0.005, sd_pair, sd_run, 16, seeds=1) is None  # the seeds alone are too noisy


def test_ladder_lines_are_the_formulas_for_every_block_and_seed_count(capsys):
    """Each line of the ladder equals the direct formulas, and larger blocks and more seeds resolve more."""
    table = noise_budget.ladder(0.010, 0.004, 16, bar=0.01)
    assert len(table) == len(noise_budget.BLOCK_SIZES) * len(noise_budget.SEEDS)
    for _, line in table.iterrows():
        se = noise_budget.gain_se(0.010, 0.004, line["files"], 16, line["seeds"])
        threshold = max(0.01, 1.6449 * se)
        assert np.isclose(line["se"], se) and np.isclose(line["smallest_gain"], threshold, rtol=1e-4)
        assert np.isclose(line["detectable_gain"], threshold + stats.norm.ppf(0.8) * se, rtol=1e-4)
        assert np.isclose(line["pass_0.005"], noise_budget.pass_chance(0.005, se, line["smallest_gain"]))
        assert np.isclose(line["over_0.03"], noise_budget.overstatement(0.03, se, line["smallest_gain"]))
    by = table.set_index(["files", "seeds"])
    assert by.loc[(400, 5), "se"] < by.loc[(100, 5), "se"] < by.loc[(16, 5), "se"] < by.loc[(16, 1), "se"]
    assert by.loc[(400, 5), "pass_0.02"] > by.loc[(16, 1), "pass_0.02"]
    assert by.loc[(400, 5), "over_0.01"] < by.loc[(16, 1), "over_0.01"]
    assert (table["smallest_gain"] >= 0.01).all()                                 # the bar is never undercut
    own = noise_budget.ladder(0.010, 0.004, 16, block_sizes=(50,), seeds=(2,), true_gains=(0.015,), seeds_behind_spread=3)
    assert list(own.columns) == ["files", "seeds", "se", "smallest_gain", "detectable_gain", "pass_0.015", "over_0.015"]
    assert np.isclose(own["smallest_gain"].iloc[0], 2.920 * own["se"].iloc[0], rtol=1e-3)
    noise_budget.print_ladder(table)
    printed = capsys.readouterr().out
    assert "smallest_gain" in printed and "pass_0.01" in printed and "over_0.03" in printed


@pytest.fixture(scope="module")
def seeds():
    """One made-up table scored four times with different noise, as four seeds of one model would be."""
    df = synthetic.make_transactions(n_accounts=500, seed=41, fraud_account_share=0.12)
    part = df[_shared.ranked_rows(df)].reset_index(drop=True)
    scores = [synthetic.make_scores(part, seed=s, strength=2.0)[settings.SCORE_COL].to_numpy() for s in (1, 2, 3, 4)]
    return {"units": _shared.account_codes(part), "labels": _shared.fraud_flags(part), "scores": scores}


def test_measured_noise_is_the_seed_spread_and_the_paired_error(seeds):
    """The run-to-run figure is the spread of capture over seeds; the paired figure comes from the account bootstrap."""
    noise = noise_budget.measure_noise(seeds["units"], seeds["labels"], seeds["scores"], draws=60, seed=2)
    captures = [ranking.capture(seeds["labels"], s)["udr"] for s in seeds["scores"]]
    assert np.allclose(noise["captures"], captures) and noise["seeds"] == 4
    assert np.isclose(noise["sd_run"], np.std(captures, ddof=1)) and noise["sd_run"] > 0
    errors = [paired_bootstrap(seeds["units"], seeds["labels"], seeds["scores"][i], seeds["scores"][i + 1],
                               draws=60, seed=2)["se"] for i in range(3)]
    assert np.isclose(noise["sd_pair"], np.mean(errors)) and noise["sd_pair"] > 0
    one_pair = noise_budget.measure_noise(seeds["units"], seeds["labels"], seeds["scores"], pairs=[(0, 3)], draws=60, seed=2)
    direct = paired_bootstrap(seeds["units"], seeds["labels"], seeds["scores"][0], seeds["scores"][3], draws=60, seed=2)
    assert np.isclose(one_pair["sd_pair"], direct["se"])
    # Four copies of one fit: no run-to-run noise and no paired noise.
    same = noise_budget.measure_noise(seeds["units"], seeds["labels"], [seeds["scores"][0]] * 4, draws=30)
    assert same["sd_run"] == 0.0 and same["sd_pair"] == 0.0
    # The measured figures feed the ladder directly.
    table = noise_budget.ladder(noise["sd_pair"], noise["sd_run"], files_measured=16)
    assert np.isfinite(table.to_numpy(dtype=float)).all()


def test_tool_prints_the_ladder_and_the_binomial_errors(tmp_path, capsys):
    """The tool prints what it is given enough numbers for, writes the ladder when asked and says when nothing fits."""
    out = str(tmp_path / "ladder.parquet")
    noise_budget.main(["--sd-pair", "0.010", "--sd-run", "0.004", "--files-measured", "16", "--bar", "0.01",
                       "--blocks", "16", "100", "--seeds", "1", "5", "--gains", "0.01", "0.02", "--out", out])
    printed = capsys.readouterr().out
    assert "smallest gain one fit per arm can show" in printed and "What each block size" in printed
    written = tables.read_columns(out)
    assert len(written) == 4 and {"pass_0.01", "over_0.02"} <= set(written.columns)
    noise_budget.main(["--frauds", "1400", "--rate", "0.55", "--only-a", "150", "--only-b", "120"])
    printed = capsys.readouterr().out
    assert "One capture rate" in printed and "Paired difference" in printed and "0.0133" in printed
    noise_budget.main(["--sd-pair", "0.010", "--sd-run", "0.004"])
    assert "no --files-measured" in capsys.readouterr().out
    noise_budget.main([])
    assert "nothing to compute" in capsys.readouterr().out
