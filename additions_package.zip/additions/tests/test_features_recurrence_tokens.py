"""Tests of the recurrence codes.

The main test recomputes all seven codes of sampled rows by walking through the account's
earlier rows inside the look-back. The other tests check what the codes are for: equal ids
mean equal values, and training files give the codes that scoring files give.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, timekeys
from additions.features import lookback, recurrence_tokens

FIELDS = {"merchant": settings.MERCHANT_COL, "mcc": settings.MCC_COL, "country": settings.MERCHANT_COUNTRY_COL}
CODES = recurrence_tokens.CODE_NAMES


def _table(seed=0, n_accounts=25, **kwargs):
    """Made-up rows over three months, with some missing merchant ids."""
    kwargs = {"days": 92, "start": "2024-10-01", **kwargs}
    df = synthetic.make_transactions(n_accounts=n_accounts, seed=seed, **kwargs)
    rng = np.random.default_rng(seed)
    df[settings.MERCHANT_COL] = df[settings.MERCHANT_COL].astype(float)
    df.loc[rng.random(len(df)) < 0.05, settings.MERCHANT_COL] = np.nan
    return df


def _bucket(value, edges):
    """The slow, obvious bucket: count the edges that are at or below the value."""
    return sum(1 for edge in edges if edge <= value)


def _slow_codes(account, secs, value, i, start_i):
    """The seven codes of row i from the account's rows in [start_i, second of row i)."""
    if pd.isna(value[i]):
        return dict.fromkeys(CODES, 0)
    earlier = np.flatnonzero((account == account[i]) & (secs >= start_i) & (secs < secs[i]))
    position = {r: (secs[earlier] < secs[r]).sum() for r in earlier}             # earlier rows of the account
    own_position = len(earlier)
    uses = [r for r in earlier if value[r] == value[i]]
    if not uses:
        local = 1 + len(set(value[earlier][~pd.isna(value[earlier])]))
        return {"local_id": min(local, 64), "new": 1, "count": 1, "count_7": 1, "count_30": 1, "rows_since": 1,
                "secs_since": 1}
    first_second = min(secs[r] for r in uses)
    before_first = earlier[secs[earlier] < first_second]
    local = 1 + len(set(value[before_first][~pd.isna(value[before_first])]))
    last = max(uses, key=lambda r: secs[r])
    among_last_30 = sum(1 for r in uses if own_position - position[r] <= 30)
    return {
        "local_id": min(local, 64),
        "new": 2,
        "count": 1 + _bucket(len(uses), recurrence_tokens.COUNT_EDGES),
        "count_7": 1 + sum(1 for r in uses if own_position - position[r] <= 7),
        "count_30": 1 + _bucket(among_last_30, recurrence_tokens.COUNT_EDGES),
        "rows_since": 2 + _bucket(own_position - position[last], recurrence_tokens.ROWS_SINCE_EDGES),
        "secs_since": 2 + _bucket(secs[i] - secs[last], recurrence_tokens.SECS_SINCE_EDGES),
    }


def test_codes_equal_the_slow_definition():
    """All seven codes of every field match a walk through the account's earlier rows, in both numberings."""
    df = _table()
    account = timekeys.codes(df[settings.ACCOUNT_COL])
    secs = timekeys.seconds(df[settings.TIME_COL])
    for months_back in (1, 0):
        got = recurrence_tokens.build_recurrence_tokens(df, fields=FIELDS, months_back=months_back)
        start = lookback.lookback_start(secs, months_back)
        assert got.shape == (len(df), 7 * len(FIELDS)) and got.index.equals(df.index)
        for name, col in FIELDS.items():
            value = df[col].to_numpy()
            for i in range(0, len(df), 7):
                slow = _slow_codes(account, secs, value, i, start[i])
                assert {code: got[f"recur_{name}_{code}"].iloc[i] for code in CODES} == slow


def test_codes_are_small_integers_inside_their_tables():
    """Every code is a whole number from 0 to its table size minus one, and the tables are small."""
    got = recurrence_tokens.build_recurrence_tokens(_table(seed=1), fields=FIELDS)
    sizes = recurrence_tokens.cardinalities()
    assert sizes["local_id"] == 65 and max(sizes.values()) == 65
    for column in got.columns:
        code = column.split("_", 2)[2]
        assert str(got[column].dtype) == "int16" and got[column].min() >= 0 and got[column].max() < sizes[code]
    # The made-up accounts use many merchants and mostly one country, so both ends of the scales occur.
    assert got["recur_merchant_local_id"].max() > 5 and got["recur_country_count_7"].max() == 8


def test_equal_ids_mean_equal_values_inside_a_month():
    """Within an account and a month, two rows carry the same local id exactly when they hold the same value."""
    df = _table(seed=2, tie_share=0.0)                                           # no two rows share a second
    got = recurrence_tokens.build_recurrence_tokens(df, fields=FIELDS)
    month = pd.to_datetime(df[settings.TIME_COL]).dt.to_period("M")
    for name, col in FIELDS.items():
        frame = pd.DataFrame({"account": df[settings.ACCOUNT_COL], "month": month, "value": df[col],
                              "id": got[f"recur_{name}_local_id"]}).dropna(subset=["value"])
        assert (frame.groupby(["account", "month", "value"])["id"].nunique() == 1).all()
        assert (frame.groupby(["account", "month", "id"])["value"].nunique() == 1).all()


def test_training_files_give_the_codes_that_scoring_files_give():
    """December rows of long files get the codes of files that begin on 1 November, and so does their history."""
    df = _table(seed=3)
    secs = timekeys.seconds(df[settings.TIME_COL])
    cut = secs >= lookback.data_start("2024-11-01")                              # what short files would hold
    december = secs >= lookback.data_start("2024-12-01")
    november = cut & ~december
    long_files = recurrence_tokens.build_recurrence_tokens(df, fields=FIELDS)
    short_files = recurrence_tokens.build_recurrence_tokens(df[cut], fields=FIELDS)
    assert long_files[december].equals(short_files[december[cut]])
    # The history month of the short files is numbered from 1 November. In the long files that numbering
    # is the second call, with months_back=0; the default call numbers November from 1 October instead.
    as_history = recurrence_tokens.build_recurrence_tokens(df, fields=FIELDS, months_back=0)
    assert as_history[november].equals(short_files[november[cut]])
    assert not long_files[november].equals(short_files[november[cut]])


def test_later_rows_do_not_change_earlier_codes():
    """Dropping every row after the middle of the period leaves the codes of the rows before it unchanged."""
    df = _table(seed=4)
    secs = timekeys.seconds(df[settings.TIME_COL])
    keep = secs <= np.median(secs)
    full = recurrence_tokens.build_recurrence_tokens(df, fields=FIELDS)
    assert full[keep].equals(recurrence_tokens.build_recurrence_tokens(df[keep], fields=FIELDS))


def test_rows_of_the_same_second_do_not_see_each_other():
    """Two new merchants in one second both take the next free id; later rows find each under that id."""
    df = pd.DataFrame({
        settings.ACCOUNT_COL: ["a"] * 6,
        settings.TIME_COL: pd.to_datetime(["2025-06-03 10:00:00", "2025-06-03 10:05:00", "2025-06-03 10:05:00",
                                           "2025-06-03 10:06:00", "2025-06-03 10:07:00", "2025-06-03 10:08:00"]),
        settings.MERCHANT_COL: ["m1", "m2", "m3", "m3", "m4", "m2"],
    })
    got = recurrence_tokens.build_recurrence_tokens(df, fields={"merchant": settings.MERCHANT_COL})
    assert got["recur_merchant_new"].tolist() == [1, 1, 1, 2, 1, 2]
    assert got["recur_merchant_local_id"].tolist() == [1, 2, 2, 2, 4, 2]          # m2 and m3 could not see each other
    assert got["recur_merchant_rows_since"].tolist() == [1, 1, 1, 2 + 1, 1, 2 + 3]   # 2 and 4 rows back
    assert got["recur_merchant_count_7"].tolist() == [1, 1, 1, 2, 1, 2]


def test_values_are_compared_for_equality_only_and_missing_values_get_code_zero(capsys):
    """Renaming every merchant changes nothing; a row without a value gets 0; an absent field is skipped."""
    df = _table(seed=5, n_accounts=10)
    renamed = df.copy()
    ids = pd.unique(df[settings.MERCHANT_COL].dropna())
    new_name = dict(zip(ids, [f"merchant {k}" for k in range(len(ids))]))
    renamed[settings.MERCHANT_COL] = df[settings.MERCHANT_COL].map(new_name)
    a = recurrence_tokens.build_recurrence_tokens(df, fields=FIELDS)
    b = recurrence_tokens.build_recurrence_tokens(renamed, fields=FIELDS)
    assert a.equals(b)
    no_value = df[settings.MERCHANT_COL].isna().to_numpy()
    merchant_columns = [c for c in a.columns if c.startswith("recur_merchant_")]
    assert (a.loc[no_value, merchant_columns] == 0).all().all() and (a.loc[~no_value, merchant_columns] > 0).all().all()
    capsys.readouterr()
    fewer = recurrence_tokens.build_recurrence_tokens(df, fields={"merchant": settings.MERCHANT_COL, "device": None})
    assert fewer.shape[1] == 7 and capsys.readouterr().out.count("note:") == 1
    # A row that cannot be placed in time carries the "no value" code everywhere.
    unplaced = df.copy()
    unplaced.loc[unplaced.index[3], settings.TIME_COL] = pd.NaT
    assert (recurrence_tokens.build_recurrence_tokens(unplaced, fields=FIELDS).iloc[3] == 0).all()


def test_the_local_id_is_capped():
    """The 64th distinct merchant of an account, and every later one, shares the overflow id."""
    n = 80
    df = pd.DataFrame({
        settings.ACCOUNT_COL: ["a"] * n,
        settings.TIME_COL: pd.Timestamp("2025-06-03") + pd.to_timedelta(np.arange(n), unit="min"),
        settings.MERCHANT_COL: np.arange(n),
    })
    got = recurrence_tokens.build_recurrence_tokens(df, fields={"merchant": settings.MERCHANT_COL})
    assert got["recur_merchant_local_id"].tolist() == list(range(1, 64)) + [64] * (n - 63)


def test_the_command_line_runs_on_made_up_rows(capsys):
    """The tool prints one summary line per code column."""
    frame = recurrence_tokens.main(["--demo"])
    assert "recur_merchant_local_id" in capsys.readouterr().out and frame.shape[1] == 7 * 5
