"""Tests of the stand-in model that shows how the gated field re-reads are wired in.

The tests run the template end to end with and without a position in front of the rows, and
then make the slips the checks are there for: a time unit that does not fit the mask, a bank
that is not the row's own, and a grown model in which a trained weight was lost. Each slip
must show in the check that is meant to catch it.
"""
import torch

from additions.model import interleaved_wiring_template as template
from additions.model.interleaved_reread import InterleavedReread, start_from


def _trained(front_token=False, steps=10):
    """A briefly trained stand-in and the made-up batch it was trained on."""
    torch.manual_seed(0)
    batch = template.make_batch()
    model = template.StandInModel(front_token=front_token)
    optimiser = torch.optim.AdamW(model.parameters(), lr=3e-3)
    model.train()
    for _ in range(steps):
        optimiser.zero_grad()
        template.row_loss(model, batch).backward()
        optimiser.step()
    return model, batch


def test_every_design_passes_the_four_checks_with_and_without_a_front_position():
    """The run of the template answers yes four times for every design, in both layouts."""
    for front_token in (False, True):
        results = template.main(steps=10, front_token=front_token, quiet=True)
        assert list(results) == list(template.DESIGNS)
        for design, r in results.items():
            assert r["equal"] < 1e-5, design
            assert r["wiring"] == 1.0, design
            assert r["kept"] < 1e-4 and r["later"] > 1e-4, design
            assert r["outside"] == [] and r["inside"] > 0, design


def test_the_sizes_are_those_the_blocks_were_written_for():
    """64 predictors of width 48 go into stage 1 as 10 tokens, and the memory of design AM holds 384 keys."""
    model, batch = _trained()
    assert template.N_SUMMARY + template.N_PRIORITY + template.N_TAIL_GROUPS == 10
    grown = template.grow(model, "AM")
    seen = {}
    grown.interleaved.memory.register_forward_hook(lambda module, inputs, output: seen.update(keys=output[0]))
    grown.eval()
    with torch.no_grad():
        grown(batch)
    B, T = batch["mask"].shape
    assert seen["keys"].shape == (B, T, 64 + 5 * 64, 48)
    assert len(grown.interleaved.rereads) == template.HISTORY_LAYERS
    assert list(template.grow(model, "M").interleaved.rereads) == [str(template.HISTORY_LAYERS)]


def test_a_time_unit_that_does_not_fit_the_mask_shows_in_the_wiring_check_only():
    """With a wrong unit the scores are still equal before training; the look at the wiring is what shows it."""
    model, batch = _trained()
    grown = template.grow(model, "AM")
    grown.interleaved.memory.units_per_second = 1                   # the batch carries nanoseconds
    assert template.equal_scores(model, grown, batch) < 1e-5
    assert template.wiring_agrees(grown, batch) < 1.0
    kept, _ = template.later_rows_change_nothing(grown, batch, template.alter_rows)
    assert kept < 1e-4                                              # later seconds stay out even then
    # What the wrong unit lets in is another row of the same second.
    valid, times = batch["mask"], batch["time_seq"]
    second = torch.div(times, template.TIME_UNITS_PER_SECOND, rounding_mode="floor")
    b, i = next((b, i) for b in range(valid.shape[0]) for i in range(1, int(valid[b].sum()))
                if second[b, i] == second[b, i - 1] and times[b, i] > times[b, i - 1])
    peer = torch.zeros_like(valid)
    peer[b, i - 1] = True
    torch.manual_seed(1)
    with torch.no_grad():
        for reread in grown.interleaved.rereads.values():
            reread.write_back.weight.normal_(std=0.2)
    grown.eval()
    with torch.no_grad():
        before, after = grown(batch), grown(template.alter_rows(batch, peer))
    assert float((before[b, i] - after[b, i]).abs().max()) > 1e-4


def test_a_lost_trained_weight_shows_in_the_equal_scores_check():
    """A grown model that did not take one of the trained weights no longer scores as the trained model."""
    model, batch = _trained()
    weights = {name: w for name, w in model.state_dict().items() if not name.startswith("head.")}
    grown = template.StandInModel(design="A")
    start_from(grown, weights)
    assert template.equal_scores(model, grown, batch) > 1e-3


def test_a_bank_of_another_layout_is_refused_by_the_shapes():
    """A count of front positions that does not fit the model cannot run: the rows and the bank differ in length."""
    model, batch = _trained(front_token=True)
    grown = template.grow(model, "A", front_token=True)
    block = grown.interleaved
    B, T = batch["mask"].shape
    memory = block.prepare(torch.randn(B, T, 64, 48), batch["time_seq"], batch["mask"])
    x = torch.randn(B, T + 1, template.HISTORY_WIDTH)
    assert block.run(grown.history_layers, x, None, memory, n_prefix=1).shape == x.shape
    try:
        block.run(grown.history_layers, x, None, memory, n_prefix=0)
        ran = True
    except RuntimeError:
        ran = False
    assert not ran
    assert isinstance(block, InterleavedReread)


def test_a_reversed_mask_of_real_rows_fails_the_second_and_the_fourth_check():
    """A model that hands the padding mask to the block is wired wrong, and two checks say so."""
    model, batch = _trained()

    class Reversed(template.StandInModel):
        """The stand-in with one slip: the block is given a mask that is True on padding."""

        def forward(self, batch):
            block, real = self.interleaved, batch["mask"].bool()
            prepare, look = block.prepare, block.look_at_wiring
            block.prepare = lambda bank, times, valid: prepare(bank, times, ~real)
            block.look_at_wiring = lambda mask, times, valid, memory, **kw: look(mask, times, ~real, memory, **kw)
            try:
                return super().forward(batch)
            finally:
                block.prepare, block.look_at_wiring = prepare, look

    grown = Reversed(design="AM")
    start_from(grown, model.state_dict())
    assert template.equal_scores(model, grown, batch) < 1e-5        # the scores cannot show it
    assert template.wiring_agrees(grown, batch) < 1.0
    outside, reached = template.only_new_weights_move(grown, batch, template.row_loss)
    assert outside == [] and reached == 0                           # the new blocks get no learning signal


def test_the_third_check_says_why_it_cannot_run(capsys):
    """With no real row on one side of the cut the check prints the reason and gives no passing answer."""
    model, batch = _trained()
    grown = template.grow(model, "A")
    wrong = dict(batch)
    wrong["nothing_real"] = torch.zeros_like(batch["mask"])
    kept, later = template.later_rows_change_nothing(grown, wrong, template.alter_rows, real="nothing_real")
    assert kept != kept and later == 0.0                            # not a number, and no change seen
    assert "no real row on one side of the cut" in capsys.readouterr().out
