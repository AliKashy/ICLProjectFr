"""Tests of the stand-in model that shows how the gated field re-reads are wired in.

The tests run the template end to end with and without a position in front of the rows, and
then make the slips the checks are there for: a time unit that does not fit the mask, a bank
that is not the row's own, and a grown model in which a trained weight was lost. Each slip
must show in the check that is meant to catch it. A grown stand-in takes the rule of
REREAD_TIES for the rows of one earlier second, "whole_seconds" for a model trained from now on,
under which the order of the rows inside a second moves no score; a model trained under "slot"
scores as it was trained only when it is built with "slot" again. Its memory holds zeros where it
holds no earlier row.
"""
import torch

from additions.model import best_model_template as bm
from additions.model import interleaved_wiring_template as template
from additions.model.interleaved_reread import InterleavedReread, start_from


def _trained(front_token=False, steps=10):
    """A briefly trained stand-in and the made-up batch it was trained on."""
    torch.manual_seed(0)
    batch = template.make_batch()
    model = template.StandInModel(front_token=front_token)
    optimiser = torch.optim.AdamW(model.parameters(), lr=3e-3)
    model.train()
    for _ in range(steps):
        optimiser.zero_grad()
        template.row_loss(model, batch).backward()
        optimiser.step()
    return model, batch


def test_every_design_passes_the_four_checks_with_and_without_a_front_position():
    """The run of the template answers yes four times for every design, in both layouts."""
    for front_token in (False, True):
        results = template.main(steps=10, front_token=front_token, quiet=True)
        assert list(results) == list(template.DESIGNS)
        for design, r in results.items():
            assert r["equal"] < 1e-5, design
            assert r["wiring"] == 1.0, design
            assert r["kept"] < 1e-4 and r["later"] > 1e-4, design
            assert r["outside"] == [] and r["inside"] > 0, design
            # A fresh block: only the zero-start write-back layer of each re-read gets a gradient at first.
            assert r["inside"] == len(template.DESIGNS[design][0] or range(template.HISTORY_LAYERS)), design


def test_the_sizes_are_those_the_blocks_were_written_for():
    """64 predictors of width 48 go into stage 1 as 10 tokens, and the memory of design AM holds 384 keys."""
    model, batch = _trained()
    assert template.N_SUMMARY + template.N_PRIORITY + template.N_TAIL_GROUPS == 10
    grown = template.grow(model, "AM")
    seen = {}
    grown.interleaved.memory.register_forward_hook(lambda module, inputs, output: seen.update(keys=output[0]))
    grown.eval()
    with torch.no_grad():
        grown(batch)
    B, T = batch["mask"].shape
    assert seen["keys"].shape == (B, T, 64 + 5 * 64, 48)
    assert len(grown.interleaved.rereads) == template.HISTORY_LAYERS
    assert list(template.grow(model, "M").interleaved.rereads) == [str(template.HISTORY_LAYERS)]


def test_a_time_unit_that_does_not_fit_the_mask_shows_in_the_wiring_check_only():
    """With a wrong unit the scores are still equal before training; the look at the wiring is what shows it."""
    model, batch = _trained()
    grown = template.grow(model, "AM")
    grown.interleaved.memory.units_per_second = 1                   # the batch carries nanoseconds
    assert template.equal_scores(model, grown, batch) < 1e-5
    assert template.wiring_agrees(grown, batch) < 1.0
    kept, _ = template.later_rows_change_nothing(grown, batch, template.alter_rows)
    assert kept < 1e-4                                              # later seconds stay out even then
    # What the wrong unit lets in is another row of the same second.
    valid, times = batch["mask"], batch["time_seq"]
    second = torch.div(times, template.TIME_UNITS_PER_SECOND, rounding_mode="floor")
    b, i = next((b, i) for b in range(valid.shape[0]) for i in range(1, int(valid[b].sum()))
                if second[b, i] == second[b, i - 1] and times[b, i] > times[b, i - 1])
    peer = torch.zeros_like(valid)
    peer[b, i - 1] = True
    torch.manual_seed(1)
    with torch.no_grad():
        for reread in grown.interleaved.rereads.values():
            reread.write_back.weight.normal_(std=0.2)
    grown.eval()
    with torch.no_grad():
        before, after = grown(batch), grown(template.alter_rows(batch, peer))
    assert float((before[b, i] - after[b, i]).abs().max()) > 1e-4


def test_a_lost_trained_weight_shows_in_the_equal_scores_check():
    """A grown model that did not take one of the trained weights no longer scores as the trained model."""
    model, batch = _trained()
    weights = {name: w for name, w in model.state_dict().items() if not name.startswith("head.")}
    grown = template.StandInModel(design="A")
    start_from(grown, weights)
    assert template.equal_scores(model, grown, batch) > 1e-3


def test_a_bank_of_another_layout_is_stopped_by_the_shapes():
    """A count of front positions that does not fit the model cannot run: the rows and the bank differ in length."""
    model, batch = _trained(front_token=True)
    grown = template.grow(model, "A", front_token=True)
    block = grown.interleaved
    B, T = batch["mask"].shape
    memory = block.prepare(torch.randn(B, T, 64, 48), batch["time_seq"], batch["mask"])
    x = torch.randn(B, T + 1, template.HISTORY_WIDTH)
    assert block.run(grown.history_layers, x, None, memory, n_prefix=1).shape == x.shape
    try:
        block.run(grown.history_layers, x, None, memory, n_prefix=0)
        ran = True
    except RuntimeError:
        ran = False
    assert not ran
    assert isinstance(block, InterleavedReread)


def test_a_reversed_mask_of_real_rows_fails_the_second_and_the_fourth_check():
    """A model that hands the padding mask to the block is wired wrong, and two checks say so."""
    model, batch = _trained()

    class Reversed(template.StandInModel):
        """The stand-in with one slip: the block is given a mask that is True on padding."""

        def forward(self, batch):
            block, real = self.interleaved, batch["mask"].bool()
            prepare, look = block.prepare, block.look_at_wiring
            block.prepare = lambda bank, times, valid: prepare(bank, times, ~real)
            block.look_at_wiring = lambda mask, times, valid, memory, **kw: look(mask, times, ~real, memory, **kw)
            try:
                return super().forward(batch)
            finally:
                block.prepare, block.look_at_wiring = prepare, look

    grown = Reversed(design="AM")
    start_from(grown, model.state_dict())
    assert template.equal_scores(model, grown, batch) < 1e-5        # the scores cannot show it
    assert template.wiring_agrees(grown, batch) < 1.0
    outside, reached = template.only_new_weights_move(grown, batch, template.row_loss)
    assert outside == [] and reached == 0                           # the new blocks get no learning signal


def test_the_third_check_says_why_it_cannot_run(capsys):
    """With no real row on one side of the cut the check prints the reason and gives no passing answer."""
    model, batch = _trained()
    grown = template.grow(model, "A")
    wrong = dict(batch)
    wrong["nothing_real"] = torch.zeros_like(batch["mask"])
    kept, later = template.later_rows_change_nothing(grown, wrong, template.alter_rows, real="nothing_real")
    assert kept != kept and later == 0.0                            # not a number, and no change seen
    assert "no real row on one side of the cut" in capsys.readouterr().out


def _switched_on(grown):
    """The grown model with write-back weights that are no longer zero, as after some training."""
    torch.manual_seed(1)
    with torch.no_grad():
        for reread in grown.interleaved.rereads.values():
            reread.write_back.weight.normal_(std=0.2)
    return grown.eval()


def test_the_scored_path_of_the_stand_in_agrees_with_the_full_path():
    """For every design, with and without a front position, several or one scored row per window give the full scores."""
    for front_token in (False, True):
        model, batch = _trained(front_token=front_token)
        valid = batch["mask"]
        g = torch.Generator().manual_seed(4)
        marks = {"last": template.last_real_rows(valid), "several": torch.rand(valid.shape, generator=g) < 0.4}
        assert int(marks["last"].sum()) == valid.shape[0]
        for design in template.DESIGNS:
            grown = template.grow(model, design, front_token=front_token)
            for kind, scored in marks.items():
                assert template.scored_rows_agree(grown, batch, scored) < 1e-5, (front_token, design, kind)


def test_the_fifth_check_runs_in_main_and_says_why_it_cannot_run(capsys):
    """main() reports the fifth check for every design, and a mark without a real row gives no passing answer."""
    results = template.main(steps=2, quiet=True)
    assert all(r["scored"] < 1e-5 for r in results.values())
    model, batch = _trained(steps=2)
    grown = template.grow(model, "M")
    answer = template.scored_rows_agree(grown, batch, ~batch["mask"])
    assert answer != answer
    assert "no scored row is a real row" in capsys.readouterr().out


def test_the_lean_memory_and_the_scored_path_in_the_stand_in():
    """The lean memory set on a built block gives the default scores, alone and with scored rows."""
    model, batch = _trained()
    valid = batch["mask"]
    scored = template.last_real_rows(valid)
    for design in template.DESIGNS:
        grown = _switched_on(template.grow(model, design))
        with torch.no_grad():
            full = grown(batch)
            for rows_per_part in (1, 9, 10_000):
                grown.interleaved.rows_per_part = rows_per_part
                lean = grown(batch)
                both = grown(dict(batch, scored=scored))
                assert torch.allclose(lean[valid], full[valid], atol=1e-5), (design, rows_per_part)
                assert torch.allclose(both[scored], full[scored], atol=1e-5), (design, rows_per_part)
            grown.interleaved.rows_per_part = None


def test_the_wiring_check_reads_the_scored_memory():
    """The look at the wiring gives 1.0 when the model takes the scored path."""
    model, batch = _trained()
    grown = template.grow(model, "M")
    marked = dict(batch, scored=template.last_real_rows(batch["mask"]))
    assert template.wiring_agrees(grown, marked) == 1.0


class _MarkUnderAnotherName(template.StandInModel):
    """The stand-in reading its mark of scored rows from batch["keep"] instead of batch["scored"]."""

    def forward(self, batch):
        batch = {name: value for name, value in batch.items() if name != "scored"}
        if "keep" in batch:
            batch["scored"] = batch.pop("keep")
        return super().forward(batch)


def test_the_fifth_check_reads_the_mark_under_the_name_it_is_given(capsys):
    """A model that reads its mark elsewhere does not take the scored path, and the check says so."""
    model, batch = _trained()
    scored = template.last_real_rows(batch["mask"])
    for design in template.DESIGNS:
        grown = _MarkUnderAnotherName(design=design)
        start_from(grown, model.state_dict())
        capsys.readouterr()
        assert template.scored_rows_agree(grown, batch, scored) == float("inf"), design
        assert "did not take the scored path" in capsys.readouterr().out
        assert template.scored_rows_agree(grown, batch, scored, key="keep") < 1e-5, design


def test_the_fifth_check_sees_a_prepare_without_the_mark(capsys):
    """A model that works out the bank for the scored rows but calls prepare without the mark is caught."""
    model, batch = _trained()
    scored = template.last_real_rows(batch["mask"])

    class NoMarkInPrepare(template.StandInModel):
        """The stand-in with one slip: prepare is not handed the mark."""

        def forward(self, batch):
            block = self.interleaved
            prepare = block.prepare
            block.prepare = lambda bank, times, valid, scored=None: prepare(bank, times, valid)
            try:
                return super().forward(batch)
            finally:
                block.prepare = prepare

    grown = NoMarkInPrepare(design="AM")
    start_from(grown, model.state_dict())
    capsys.readouterr()
    assert template.scored_rows_agree(grown, batch, scored) == float("inf")
    assert "did not take the scored path" in capsys.readouterr().out


def test_the_fourth_check_trains_on_the_batch_without_the_mark(capsys):
    """A batch that carries a mark of scored rows gives check 4 the answer of the batch without it."""
    model, batch = _trained()
    marked = dict(batch, scored=template.last_real_rows(batch["mask"]))
    for design in template.DESIGNS:
        grown = template.grow(model, design)
        plain = template.only_new_weights_move(grown, batch, template.row_loss)
        assert template.only_new_weights_move(grown, marked, template.row_loss) == plain, design
    assert "left unused" not in capsys.readouterr().out


def test_the_work_report_of_the_stand_in_shows_the_saving():
    """Design M with one scored row per window: the last re-read and the bank work out far fewer rows."""
    model, batch = _trained()
    scored = template.last_real_rows(batch["mask"])
    grown = template.grow(model, "M").eval()
    B, T = batch["mask"].shape
    with torch.no_grad():
        grown(batch)
        full = grown.interleaved.work_report(grown.predictor_bank)
        grown(dict(batch, scored=scored))
        part = grown.interleaved.work_report(grown.predictor_bank)
    last = template.HISTORY_LAYERS
    assert full == {"rereads": {last: {"rows": B * T, "memory_rows": B * T}}, "bank_rows": B * T}
    assert part["rereads"] == {last: {"rows": B, "memory_rows": B}}
    assert B < part["bank_rows"] <= B * 6


def test_a_re_read_after_a_layer_the_model_does_not_have_is_seen(capsys):
    """A re-read listed after layer 5 of a four-layer stage 2 never runs; run and check 4 say so, check 5 stops."""
    model, batch = _trained()
    grown = template.grow(model, "M")
    block = grown.interleaved
    block.rereads = torch.nn.ModuleDict({"5": block.rereads[str(template.HISTORY_LAYERS)]})
    block.after_layers = (5,)
    outside, reached = template.only_new_weights_move(grown, batch, template.row_loss)
    assert outside == [] and reached == 0
    # The memory for scored rows only cannot serve a stack whose last layer has no re-read: a plain error.
    try:
        template.scored_rows_agree(grown, batch, template.last_real_rows(batch["mask"]))
        message = ""
    except ValueError as error:
        message = str(error)
    assert "re-read after layer 5" in message and "the stack has 4 layers" in message
    printed = capsys.readouterr().out
    assert "never runs" in printed and "no re-read ran" in printed


def test_the_grown_stand_in_keeps_the_rule_it_was_trained_with_and_empty_places_hold_zeros(monkeypatch):
    """A grown stand-in takes the rule of REREAD_TIES for the rows of an earlier second, "whole_seconds" for a model
    trained from now on, and scores as the trained model; every place of its memory that holds no earlier row holds
    zeros in its keys and its values, never the numbers of another row. The rule is no weight: a model grown and
    trained under "slot", the rule of the re-read models of 24 November, scores as before when it is built again
    from its weights with REREAD_TIES at "slot", and scores otherwise when it is built with "whole_seconds"."""
    model, batch = _trained()
    assert template.REREAD_TIES == "whole_seconds"
    for design in ("M", "AM"):
        grown = template.grow(model, design)
        assert grown.interleaved.memory.ties == template.REREAD_TIES, design
        seen = {}
        grown.interleaved.memory.register_forward_hook(
            lambda module, inputs, output: seen.update(keys=output[0], values=output[1], missing=output[2]))
        grown.eval()
        with torch.no_grad():
            grown(batch)
        missing = seen["missing"]
        assert missing.any() and not seen["keys"][missing].any() and not seen["values"][missing].any(), design
        assert template.equal_scores(model, grown, batch) < 1e-5, design
    # A model of 24 November: grown under "slot" and trained there (write-back weights that are no longer zero).
    monkeypatch.setattr(template, "REREAD_TIES", "slot")
    old = _switched_on(template.grow(model, "M"))
    assert old.interleaved.memory.ties == "slot"
    saved = old.state_dict()
    valid = batch["mask"]
    again = template.StandInModel(design="M")
    again.load_state_dict(saved)
    assert again.interleaved.memory.ties == "slot"
    assert torch.equal(template._scores(again, batch)[valid], template._scores(old, batch)[valid])
    # Built from the same weights under the rule of a new model, it holds other rows after a shared second.
    monkeypatch.setattr(template, "REREAD_TIES", "whole_seconds")
    other = template.StandInModel(design="M")
    other.load_state_dict(saved)
    assert other.interleaved.memory.ties == "whole_seconds"
    assert float((template._scores(other, batch)[valid] - template._scores(old, batch)[valid]).abs().max()) > 1e-4


def test_the_grown_stand_in_passes_the_order_check_of_the_best_model_template(monkeypatch):
    """With REREAD_TIES at "whole_seconds" a stand-in of design M or AM keeps its scores when the rows of a second
    change places, and no row reads another row of its own second, as check 7 of best_model_template.py measures
    them; built under "slot", the shuffle moves its scores far beyond rounding."""
    batch = template.make_batch(seed=0, sequences=8, width=40)
    unit = template.TIME_UNITS_PER_SECOND
    for design in ("M", "AM"):
        torch.manual_seed(0)
        model = template.StandInModel(design=design)
        order, same_second = bm.order_inside_a_second(model, batch, units_per_second=unit, say=lambda line: None)
        assert order <= bm.ORDER_TOLERANCE and same_second == 0.0, (design, order, same_second)
    monkeypatch.setattr(template, "REREAD_TIES", "slot")
    for design in ("M", "AM"):
        torch.manual_seed(0)
        model = template.StandInModel(design=design)
        order, _ = bm.order_inside_a_second(model, batch, units_per_second=unit, say=lambda line: None)
        assert order > 100 * bm.ORDER_TOLERANCE, (design, order)
