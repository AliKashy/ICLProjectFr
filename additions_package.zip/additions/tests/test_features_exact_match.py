"""Tests of the exact-match history columns.

The main test recomputes every column for a sample of rows in the slow, obvious way: take
the rows of the same account in strictly earlier seconds, not before the look-back start,
and count. The other tests check the rules one by one on small tables.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, timekeys
from additions.features import exact_match, lookback

KEYS = {"merchant": settings.MERCHANT_COL, "mcc": settings.MCC_COL, "country": settings.MERCHANT_COUNTRY_COL}
WINDOWS = {"1h": 3_600, "24h": 86_400, "7d": 7 * 86_400, "30d": 30 * 86_400}


def _table(seed=0, n_accounts=30, **kwargs):
    """Made-up rows with some missing merchant ids and amounts, and amounts that repeat exactly."""
    df = synthetic.make_transactions(n_accounts=n_accounts, seed=seed, **kwargs)
    rng = np.random.default_rng(seed)
    df[settings.AMOUNT_COL] = np.round(df[settings.AMOUNT_COL] / 5.0) * 5.0     # coarse amounts repeat often
    df[settings.MERCHANT_COL] = df[settings.MERCHANT_COL].astype(float)
    df.loc[rng.random(len(df)) < 0.05, settings.MERCHANT_COL] = np.nan
    df.loc[rng.random(len(df)) < 0.03, settings.AMOUNT_COL] = np.nan
    return df


def _same(a, b):
    """Equal up to the precision of the output columns, with missing equal to missing."""
    return bool(np.isclose(a, b, rtol=1e-5, atol=1e-5, equal_nan=True))


def _arrays(df):
    account = timekeys.codes(df[settings.ACCOUNT_COL])
    secs = timekeys.seconds(df[settings.TIME_COL])
    return account, secs, lookback.lookback_start(secs), df[settings.AMOUNT_COL].to_numpy(dtype=float)


def _log_gap(secs, i, rows, first=False):
    """log(1 + seconds from the latest (or the first) of the marked rows to row i); missing when none is marked."""
    if not rows.any():
        return np.nan
    return np.log1p(secs[i] - (secs[rows].min() if first else secs[rows].max()))


def _slow_new(account, secs, start, value, present, i, window):
    """Earlier rows inside the window that were the first use of their value since the reader's look-back start."""
    count = 0
    mine = (account == account[i]) & (secs >= start[i]) & present
    for r in np.flatnonzero(mine & (secs < secs[i]) & (secs >= secs[i] - window)):
        count += not (mine & (secs < secs[r]) & (value == value[r])).any()
    return count


def test_columns_equal_the_slow_definition():
    """Every column of every key matches a row-by-row recomputation from the raw rows."""
    df = _table(days=92, start="2024-10-01")                                     # three months: two look-back starts
    got = exact_match.build_exact_match(df, keys=KEYS, file_start="2024-10-01")
    account, secs, start, amount = _arrays(df)
    cents = np.round(amount * 100.0)
    assert got.shape == (len(df), 2 + 19 * len(KEYS)) and got.index.equals(df.index)
    assert np.isfinite(got.to_numpy()[~np.isnan(got.to_numpy())]).all()          # missing is allowed, infinite is not
    for name, col in KEYS.items():
        value = df[col].to_numpy()
        present = ~pd.isna(value)
        p = f"match_{name}_"
        for i in range(0, len(df), 7):
            row = got.iloc[i]
            earlier = (account == account[i]) & (secs < secs[i]) & (secs >= start[i])
            at_key = earlier & present & (value == value[i]) if present[i] else np.zeros(len(df), dtype=bool)
            assert row[p + "seen"] == float(at_key.any())
            assert _same(row[p + "log_secs_since_first"], _log_gap(secs, i, at_key, first=True))
            assert _same(row[p + "log_secs_since_last"], _log_gap(secs, i, at_key))
            for label, window in WINDOWS.items():
                assert row[p + "n_" + label] == (at_key & (secs >= secs[i] - window)).sum()
            assert row[p + "n_lookback"] == at_key.sum()
            assert _same(row[p + "share"], at_key.sum() / earlier.sum() if earlier.any() else np.nan)
            paid = amount[at_key][~np.isnan(amount[at_key])]
            mean = paid.mean() if len(paid) else np.nan
            assert _same(row[p + "amount_mean"], mean)
            assert _same(row[p + "amount_max"], paid.max() if len(paid) else np.nan)
            assert _same(row[p + "amount_ratio"], amount[i] / mean if mean > 0 else np.nan)
            repeat = at_key & (cents == cents[i])
            assert row[p + "same_amount_n"] == repeat.sum()
            assert _same(row[p + "same_amount_log_secs"], _log_gap(secs, i, repeat))
            for label in ("1h", "24h", "7d"):
                assert row[p + "new_" + label] == _slow_new(account, secs, start, value, present, i, WINDOWS[label])
            for label in ("24h", "30d"):
                recent = earlier & (secs >= secs[i] - WINDOWS[label]) & present
                assert row[p + "distinct_" + label] == len(set(value[recent]))
    for i in range(0, len(df), 7):
        earlier = (account == account[i]) & (secs < secs[i]) & (secs >= start[i])
        assert got["match_rows_in_lookback"].iloc[i] == earlier.sum()
    assert np.allclose(got["match_days_in_lookback"], lookback.days_available(secs, "2024-10-01"))


def test_later_rows_do_not_change_earlier_columns():
    """Dropping every row after the middle of the period leaves the columns of the rows before it unchanged."""
    df = _table(seed=1)
    secs = timekeys.seconds(df[settings.TIME_COL])
    keep = secs <= np.median(secs)
    full = exact_match.build_exact_match(df, keys=KEYS, file_start=settings.EVAL_HISTORY_START)
    part = exact_match.build_exact_match(df[keep], keys=KEYS, file_start=settings.EVAL_HISTORY_START)
    assert np.allclose(full[keep].to_numpy(), part.to_numpy(), equal_nan=True)


def test_rows_of_the_same_second_do_not_see_each_other():
    """Two rows in one second at one merchant are both a first use; the next row sees both."""
    df = pd.DataFrame({
        settings.ACCOUNT_COL: ["a", "a", "a", "a"],
        settings.TIME_COL: pd.to_datetime(["2025-06-03 10:00:00", "2025-06-03 10:00:00",
                                           "2025-06-03 10:05:00", "2025-06-03 10:06:00"]),
        settings.MERCHANT_COL: [7, 7, 7, 8],
        settings.AMOUNT_COL: [20.0, 20.0, 20.0, 5.0],
    })
    got = exact_match.build_exact_match(df, keys={"merchant": settings.MERCHANT_COL})
    assert got["match_merchant_seen"].tolist() == [0, 0, 1, 0]
    assert got["match_merchant_n_1h"].tolist() == [0, 0, 2, 0]
    assert got["match_merchant_same_amount_n"].tolist() == [0, 0, 2, 0]
    assert got["match_merchant_new_1h"].tolist() == [0, 0, 2, 2]                 # both same-second rows were first uses
    assert got["match_merchant_distinct_24h"].tolist() == [0, 0, 1, 1]
    assert np.isclose(got["match_merchant_log_secs_since_last"].iloc[2], np.log1p(300))


def test_a_missing_value_matches_nothing():
    """Rows without a merchant id are never "seen" and never count for a row that has one."""
    df = pd.DataFrame({
        settings.ACCOUNT_COL: ["a"] * 5,
        settings.TIME_COL: pd.to_datetime("2025-06-03 10:00:00") + pd.to_timedelta(np.arange(5), unit="min"),
        settings.MERCHANT_COL: [None, None, "m", "", "m"],
        settings.AMOUNT_COL: [1.0, 1.0, 1.0, 1.0, np.nan],
    })
    got = exact_match.build_exact_match(df, keys={"merchant": settings.MERCHANT_COL})
    assert got["match_merchant_seen"].tolist() == [0, 0, 0, 0, 1]
    assert got["match_merchant_n_lookback"].tolist() == [0, 0, 0, 0, 1]
    assert got["match_merchant_distinct_24h"].tolist() == [0, 0, 0, 1, 1]        # missing and blank are not values
    assert got["match_merchant_new_1h"].tolist() == [0, 0, 0, 1, 1]             # only the row with "m" was a first use
    assert got["match_merchant_same_amount_n"].tolist() == [0, 0, 0, 0, 0]      # a missing amount repeats nothing
    assert np.isnan(got["match_merchant_amount_ratio"]).all()


def test_key_values_are_compared_for_equality_only():
    """Renaming every merchant and country leaves all columns unchanged: no value is ever used as a number."""
    df = _table(seed=2)
    renamed = df.copy()
    ids = pd.unique(df[settings.MERCHANT_COL].dropna())
    new_name = dict(zip(ids, np.random.default_rng(0).permutation(len(ids)) + 500_000))
    renamed[settings.MERCHANT_COL] = df[settings.MERCHANT_COL].map(new_name)
    renamed[settings.MERCHANT_COUNTRY_COL] = df[settings.MERCHANT_COUNTRY_COL].map({"840": "zz", "124": "aa"})
    a = exact_match.build_exact_match(df, keys=KEYS)
    b = exact_match.build_exact_match(renamed, keys=KEYS)
    assert np.array_equal(a.to_numpy(), b.to_numpy(), equal_nan=True)


def test_training_rows_get_what_scored_rows_get():
    """A December row in long files gets the columns it would get in files that begin on 1 November."""
    df = _table(seed=3, n_accounts=20, days=92, start="2024-10-01")
    secs = timekeys.seconds(df[settings.TIME_COL])
    december = secs >= lookback.data_start("2024-12-01")
    cut = secs >= lookback.data_start("2024-11-01")
    long_files = exact_match.build_exact_match(df, keys=KEYS, file_start="2024-10-01")
    short_files = exact_match.build_exact_match(df[cut], keys=KEYS, file_start="2024-11-01")
    assert np.allclose(long_files[december].to_numpy(), short_files[december[cut]].to_numpy(), equal_nan=True)
    # Without the calendar rule the two differ: the long files then remember October.
    no_rule = exact_match.build_exact_match(df, keys=KEYS, file_start="2024-10-01", months_back=None)
    column = "match_merchant_n_lookback"
    assert (no_rule.loc[december, column] > long_files.loc[december, column]).any()


def test_absent_keys_and_columns_are_skipped_not_fatal(capsys):
    """A key that is switched off, a key column that is absent and a missing amount column only drop columns."""
    df = _table(seed=4, n_accounts=5).drop(columns=[settings.AMOUNT_COL])
    keys = {"merchant": settings.MERCHANT_COL, "card": None, "ip": "absent_col"}
    got = exact_match.build_exact_match(df, keys=keys)
    assert capsys.readouterr().out.count("note:") == 2
    assert [c for c in got.columns if "card" in c or "ip" in c or "amount" in c] == []
    assert got.shape[1] == 2 + 14
    filled = exact_match.build_exact_match(df, keys={"merchant": settings.MERCHANT_COL}, fill=0.0, prefix="x_")
    assert not filled.isna().any().any() and all(c.startswith("x_") for c in filled.columns)
    # A row that cannot be placed in time has no history: its columns are missing, and nothing else breaks.
    unplaced = df.copy()
    unplaced.loc[unplaced.index[3], settings.TIME_COL] = pd.NaT
    assert exact_match.build_exact_match(unplaced, keys={"merchant": settings.MERCHANT_COL}).iloc[3].isna().all()


def test_the_command_line_runs_on_made_up_rows(tmp_path, capsys):
    """The tool prints one summary line per column and writes the columns with the transaction id."""
    out = tmp_path / "match.parquet"
    frame = exact_match.main(["--demo", "--out", str(out)])
    printed = capsys.readouterr().out
    assert "match_merchant_seen" in printed and "new columns" in printed
    written = pd.read_parquet(out)
    assert list(written.columns) == [settings.ID_COL] + list(frame.columns) and len(written) == len(frame)
