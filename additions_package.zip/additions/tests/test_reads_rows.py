"""Tests of the shared row helpers of the reads folder.

Each test checks a helper against the slow, obvious way of getting the same answer on a small
made-up table, or shows that a missing optional column switches a part off instead of stopping.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.common import ranking, synthetic, tables
from additions.reads import _rows

STANDARD = [settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL, settings.LABEL_COL, settings.AMOUNT_COL,
            settings.SCORE_COL]


def _table(n_accounts=100, seed=0):
    """A small made-up table with a score, plus a few rows of the rarer kinds."""
    df = synthetic.make_scores(synthetic.make_transactions(n_accounts=n_accounts, seed=seed), seed=seed)
    rng = np.random.default_rng(seed)
    plain = (df[settings.REASON_COL] == settings.APPROVED_REASONS[0]) & (df[settings.LABEL_COL] == 0)
    odd = rng.choice(np.flatnonzero(plain.to_numpy()), 60, replace=False)
    df.loc[odd[:20], settings.REASON_COL] = "91"             # a decline code that is in none of the lists
    df.loc[odd[20:40], settings.DECLINE_FLAG_COL] = 1        # flagged as declined although the code says approved
    df.loc[odd[40:], settings.REASON_COL] = None             # no response code at all
    return df


def _slow_row_type(row, with_advice=True):
    """The six row types written as a plain chain of tests on one row."""
    advice = row[settings.ADVICE_COL] if with_advice else None
    if advice is not None and not pd.isna(advice) and str(advice).strip() != "":
        return "advice"
    if row[settings.TYPE_COL] in settings.ZERO_CHECK_TYPES:
        return "zero_check"
    reason = row[settings.REASON_COL]
    if reason in settings.RISK_DECLINE_REASONS:
        return "risk_decline"
    if reason in settings.FUNDS_DECLINE_REASONS:
        return "funds_decline"
    if reason not in settings.APPROVED_REASONS or str(row[settings.DECLINE_FLAG_COL]) in settings.DECLINE_FLAG_VALUES:
        return "other_decline"
    return "approved"


def test_row_type_matches_a_plain_chain_of_tests():
    """Every row gets the first type that fits, in the stated order."""
    df = _table()
    fast = _rows.row_type(df)
    assert fast.tolist() == [_slow_row_type(row) for row in df.to_dict("records")]
    assert set(fast) == set(_rows.ROW_TYPES)                 # the table holds every one of the six types
    assert df.loc[np.isin(fast, _rows.NEVER_LABELLED), settings.LABEL_COL].sum() == 0


def test_a_missing_column_switches_its_test_off(capsys):
    """Without the advice column no row is an advice row, the other tests still run, and one line says so."""
    df = _table()
    fast = _rows.row_type(df.drop(columns=[settings.ADVICE_COL]))
    assert "advice" in capsys.readouterr().out
    assert fast.tolist() == [_slow_row_type(row, with_advice=False) for row in df.to_dict("records")]
    assert "advice" not in set(fast)
    assert (_rows.row_type(df, advice_col="") == fast).all()  # a name the table lacks does the same for one call
    bare = df[[settings.ID_COL, settings.LABEL_COL]]
    assert set(_rows.row_type(bare)) == {"approved"}          # nothing is known: every row falls through


def test_codes_match_text_and_numbers_alike():
    """A code written as text matches a column of text or of numbers; a missing value never matches."""
    assert _rows.has_code(pd.Series(["00", " 51 ", None, "5"]), ("00", "51")).tolist() == [True, True, False, False]
    assert _rows.has_code(pd.Series([0, 51, 5]), ("00", "51")).tolist() == [True, True, False]
    assert _rows.has_code(pd.Series([1.0, 0.0, np.nan]), settings.DECLINE_FLAG_VALUES).tolist() == [True, False, False]
    assert _rows.has_code(pd.Series([True, False]), settings.DECLINE_FLAG_VALUES).tolist() == [True, False]


def test_scored_month_is_start_inclusive_and_end_exclusive():
    """The first second of the month is in, the first second after it is out, a missing time is out."""
    frame = pd.DataFrame({settings.TIME_COL: ["2025-05-31 23:59:59", "2025-06-01 00:00:00", "2025-06-30 23:59:59.900",
                                              "2025-07-01 00:00:00", None]})        # times stored as text
    inside = _rows.in_scored_month(frame, start="2025-06-01", end="2025-07-01")
    assert inside.tolist() == [False, True, True, False, False]
    df = _table()
    t = pd.to_datetime(df[settings.TIME_COL])
    slow = ((t >= pd.Timestamp(settings.TARGET_START)) & (t < pd.Timestamp(settings.TARGET_END))).to_numpy()
    assert (_rows.in_scored_month(df) == slow).all()
    assert 0 < slow.sum() < len(df)                           # the made-up table also holds history rows


def test_raw_columns_are_joined_by_id_in_the_order_of_the_predictions(tmp_path, capsys):
    """Joined columns hold the raw value of the same id; the rows keep their number and their order."""
    df = _table()
    numbers = synthetic.write_files(df, tmp_path / "raw", 3, first_number=11)
    preds = df[STANDARD].sample(frac=0.7, random_state=1).reset_index(drop=True)
    preds.loc[0, settings.ID_COL] = -5                        # an id that is in none of the raw files
    wanted = _rows.descriptor_columns() + ["absent_column", None]
    out = _rows.join_raw_columns(preds, wanted, tmp_path / "raw", numbers)
    assert out[settings.ID_COL].tolist() == preds[settings.ID_COL].tolist()
    assert "absent_column" not in out.columns
    by_id = df.set_index(settings.ID_COL)
    for column in _rows.descriptor_columns():
        expected = by_id[column].reindex(preds[settings.ID_COL])
        got = pd.Series(out[column].to_numpy())
        assert pd.isna(got[0])                                # the unknown id gets a missing value
        want = pd.Series(expected.to_numpy())
        assert got.fillna("none").astype(str).tolist() == want.fillna("none").astype(str).tolist()
    # An id stored as text on one side and as a number on the other still matches.
    as_text = preds.assign(**{settings.ID_COL: preds[settings.ID_COL].astype(str)})
    again = _rows.join_raw_columns(as_text, [settings.SEGMENT_COL], tmp_path / "raw", numbers)
    assert again[settings.SEGMENT_COL].fillna("none").tolist() == out[settings.SEGMENT_COL].fillna("none").tolist()
    # Without raw files the table comes back as it was, with one line that says what is skipped.
    capsys.readouterr()
    assert _rows.join_raw_columns(preds, wanted) is preds
    assert "no raw files were named" in capsys.readouterr().out


def test_several_files_are_lined_up_by_id(tmp_path):
    """Scores of the same transaction end up on the same line, whatever the row order of each file."""
    df = _table()
    paths = []
    for j in range(3):
        part = synthetic.make_scores(df, seed=10 + j)[STANDARD]
        if j == 1:
            part = part.sample(frac=1.0, random_state=3)      # the same rows in another order
        if j == 2:
            part = part.iloc[5:]                              # five rows fewer
        paths.append(tables.write_table(part, str(tmp_path / f"p{j}.parquet")))
    frame, matrix = _rows.load_aligned(paths)
    assert len(frame) == len(df) - 5 and matrix.shape == (len(df) - 5, 3)
    assert frame[settings.ID_COL].tolist() == df[settings.ID_COL].iloc[5:].tolist()   # the order of the first file
    for j in range(3):
        score = synthetic.make_scores(df, seed=10 + j).set_index(settings.ID_COL)[settings.SCORE_COL]
        assert np.allclose(matrix[:, j], score.reindex(frame[settings.ID_COL]).to_numpy())


def test_buckets_and_the_cut_threshold():
    """A value on an edge belongs to the bucket above it; the threshold is the score of the last alert."""
    names = _rows.bucket([10, 3_600, 86_399, 86_400, np.nan], (3_600, 86_400), ("short", "middle", "long"))
    assert names.tolist() == ["short", "middle", "middle", "long", "none"]
    s = np.random.default_rng(0).normal(size=5_000)
    k = ranking.cut_size(len(s))
    threshold = _rows.cut_threshold(s)
    assert threshold == np.sort(s)[-k] and (s >= threshold).sum() == k
    assert _rows.cut_threshold(np.zeros(10)) == np.inf        # ten rows are too few for a single alert


def test_labels_scores_amounts_and_accounts(capsys):
    """The small accessors agree with the plain columns, and a missing amount column is skipped aloud."""
    df = _table()
    is_fraud = (df[settings.LABEL_COL] == settings.POSITIVE_LABEL).to_numpy()
    assert (_rows.fraud_flags(df) == is_fraud).all()
    as_text = df.assign(**{settings.LABEL_COL: df[settings.LABEL_COL].astype(str)})
    assert (_rows.fraud_flags(as_text) == is_fraud).all()     # labels stored as text
    p = df[settings.SCORE_COL].to_numpy()
    assert np.allclose(_rows.logits(df), np.log(p / (1 - p)))
    assert np.array_equal(_rows.logits(df, score_kind="logit"), p)
    line = _rows.capture_line("x", _rows.fraud_flags(df), p, _rows.amounts(df))
    c = ranking.capture(df[settings.LABEL_COL], p, df[settings.AMOUNT_COL])
    assert line["udr"] == c["udr"] and line["vdr"] == c["vdr"] and line["frauds"] == is_fraud.sum()
    capsys.readouterr()
    assert _rows.amounts(df.drop(columns=[settings.AMOUNT_COL])) is None
    assert "amount" in capsys.readouterr().out
    assert np.isnan(_rows.capture_line("x", _rows.fraud_flags(df), p)["vdr"])
    # Two rows without an account are not the same account.
    holes = df.head(6).copy()
    holes.loc[holes.index[:2], settings.ACCOUNT_COL] = None
    codes = _rows.account_codes(holes)
    assert codes[0] != codes[1] and len(set(codes[2:])) == 1 and codes[0] not in set(codes[2:])
