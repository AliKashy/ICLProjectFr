"""Tests of the compromise-point exposure columns.

The blame records and the columns are recomputed the slow way, account by account and row by
row. A hand-made compromise checks the blame split and the time rule (blame is read only from
the day after it is known). Further tests check that later rows change nothing earlier, that
the row's own account never reaches its own columns, and that missing columns are skipped.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, timekeys
from additions.merchant import _panel, exposure

ACCOUNT, MERCHANT, TIME = settings.ACCOUNT_COL, settings.MERCHANT_COL, settings.TIME_COL
OK, RISK = settings.APPROVED_REASONS[0], settings.RISK_DECLINE_REASONS[0]


def _rows(seed=0, n_accounts=80, days=50):
    """Made-up rows squeezed onto 20 merchants, so that a merchant-week has several visitors."""
    df = synthetic.make_transactions(n_accounts=n_accounts, days=days, seed=seed, fraud_account_share=0.5)
    df[MERCHANT] = df[MERCHANT] % 20
    return df


def _slow_blame(df, day, bad, horizon, lag):
    """Blame records the obvious way: [(account, merchant, week, known day, share)]."""
    out = []
    for acct in pd.unique(df[ACCOUNT]):
        mine = (df[ACCOUNT] == acct).to_numpy()
        hit = mine & bad
        if not hit.any():
            continue
        first = day[hit].min()
        places = set(df[MERCHANT].to_numpy()[hit & (day == first)])
        use = mine & (day < first) & (day >= first - horizon) & ~df[MERCHANT].isin(places).to_numpy()
        pairs = set(zip(df[MERCHANT].to_numpy()[use], day[use] // exposure.WEEK_DAYS))
        out += [(acct, m, w, first + lag, 1.0 / len(pairs)) for m, w in pairs]
    return out


def _slow_columns(df, day, i, records, strength):
    """Scores of row i's own visits in each window, computed with plain loops."""
    acct, d = df[ACCOUNT].iloc[i], day[i]
    others = (df[ACCOUNT] != acct).to_numpy() & (day < d)
    seen = set(zip(df[ACCOUNT].to_numpy()[others], df[MERCHANT].to_numpy()[others], day[others] // exposure.WEEK_DAYS))
    known = [r for r in records if r[0] != acct and r[3] < d]
    prior = sum(r[4] for r in known) / len(seen) if seen else np.nan
    mine = (df[ACCOUNT] == acct).to_numpy()
    visits = set(zip(df[MERCHANT].to_numpy()[mine], day[mine]))
    out = {}
    for label, w in exposure.WINDOWS:
        scores = []
        for m, v in visits:
            if not (d - w <= v < d):
                continue
            week = v // exposure.WEEK_DAYS
            n = sum(1 for s in seen if s[1] == m and s[2] == week)
            b = sum(r[4] for r in known if r[1] == m and r[2] == week)
            scores.append((b + strength * prior) / (n + strength) if not np.isnan(prior) else (b / n if n else np.nan))
        out[label] = (max(scores) if scores else np.nan, sum(scores))
    return out


def test_columns_equal_the_slow_definition():
    """Both kinds of exposure match a recomputation from other accounts' visits and known blame."""
    df = _rows()
    day = _panel.days(timekeys.seconds(df[TIME]))
    got = exposure.exposure_features(df, *exposure.build_exposure_tables(df), days_per_chunk=5)
    assert got.index.equals(df.index) and got.shape[1] == 3 * 6
    reason = df[settings.REASON_COL].astype(str).to_numpy()
    proxy = np.isin(reason, settings.RISK_DECLINE_REASONS)
    proxy |= df[settings.VISA_SCORE_COL].to_numpy() >= exposure.HIGH_SCORE
    fraud = (df[settings.LABEL_COL] == 1).to_numpy()
    kinds = {"proxy": _slow_blame(df, day, proxy, exposure.PROXY_BLAME_DAYS, 0),
             "fraud": _slow_blame(df, day, fraud, exposure.FRAUD_BLAME_DAYS, _panel.LABEL_LAG_DAYS)}
    assert len(kinds["proxy"]) > 0 and len(kinds["fraud"]) > 0
    for i in range(0, len(df), 97):
        for kind, records in kinds.items():
            slow = _slow_columns(df, day, i, records, exposure.EXPOSURE_PRIOR_ROWS)
            for label, (top, total) in slow.items():
                assert np.isclose(got[f"exp_{kind}_max_{label}"].iloc[i], top, rtol=1e-4, atol=1e-7, equal_nan=True)
                assert np.isclose(got[f"exp_{kind}_sum_{label}"].iloc[i], total, rtol=1e-4, atol=1e-6)
    assert got["exp_proxy_max_14d"].max() > got["exp_proxy_max_14d"].min()          # the columns are not constant


def _compromise(target_also_bad=False):
    """Ten accounts and a target use merchant 1 on one day; five of the ten are declined for risk elsewhere later."""
    t0 = pd.Timestamp("2025-06-05 10:00:00")             # a Thursday: days since 1970 divisible by 7, a week start
    rows = []
    for k in range(10):
        rows.append((f"o{k}", 1, t0 + pd.Timedelta(minutes=k), OK))
        if k < 5:
            rows.append((f"o{k}", 2, t0 + pd.Timedelta(days=2, minutes=k), RISK))   # the bad outcome, at merchant 2
    rows.append(("o0", 3, t0 + pd.Timedelta(minutes=30), OK))                       # o0 splits its blame over 1 and 3
    for d in range(4):
        rows.append(("t", 1, t0 + pd.Timedelta(days=d, hours=1), OK))
    if target_also_bad:
        rows.append(("t", 2, t0 + pd.Timedelta(days=2, hours=2), RISK))
    df = pd.DataFrame(rows, columns=[ACCOUNT, MERCHANT, TIME, settings.REASON_COL])
    df[settings.VISA_SCORE_COL] = 10.0
    return df


def test_a_compromise_is_read_from_the_day_after_it_is_known_and_split_by_blame():
    """The share at merchant 1 is 4.5 of 10 visitors, and it shows only on the day after the declines."""
    df = _compromise()
    got = exposure.exposure_features(df, *exposure.build_exposure_tables(df), prior_rows=0.0)
    t = (df[ACCOUNT] == "t").to_numpy()
    mine = got[t]
    # The declines on day 2 are unknown until day 3.
    assert mine["exp_proxy_max_14d"].fillna(0).tolist()[:3] == [0.0, 0.0, 0.0]
    # o0 gives half of its blame to merchant 3, so merchant 1 holds 4.5 of 10.
    assert np.isclose(mine["exp_proxy_max_14d"].iloc[3], 0.45)
    assert np.isclose(mine["exp_proxy_sum_14d"].iloc[3], 3 * 0.45)                   # three earlier visit days
    assert np.isclose(mine["exp_proxy_sum_2d"].iloc[3], 2 * 0.45)                    # only the two days before
    assert mine["exp_visitors_14d"].iloc[3] == 10 and mine["exp_visits_14d"].iloc[3] == 3
    # The target's own bad outcome on day 2 (at merchant 2) would blame merchant 1 with a whole unit and
    # lift its share to 5.5 of 11. It is the row's own account, so the share stays at 4.5 of 10.
    bad = _compromise(True)
    again = exposure.exposure_features(bad, *exposure.build_exposure_tables(bad), prior_rows=0.0)
    again = again[(bad[ACCOUNT] == "t").to_numpy()]
    assert np.isclose(again["exp_proxy_max_14d"].iloc[3], 0.45)
    assert again["exp_visitors_14d"].iloc[3] == (10 * 3 + 5) / 4     # merchant 1 three times, merchant 2 once


def test_later_rows_do_not_change_earlier_columns():
    """Dropping every row after the middle of the period changes nothing for the rows before it."""
    df = _rows(seed=1)
    day = _panel.days(timekeys.seconds(df[TIME]))
    keep = day <= np.median(day)
    full = exposure.exposure_features(df, *exposure.build_exposure_tables(df))
    part = exposure.exposure_features(df[keep], *exposure.build_exposure_tables(df[keep]))
    assert np.allclose(full[keep].to_numpy(), part.to_numpy(), rtol=1e-5, atol=1e-7, equal_nan=True)


def test_the_own_account_never_reaches_its_own_columns():
    """An account inside the panel reads what it reads when the panel leaves it out; its own outcomes move nothing."""
    df = _rows(seed=2)
    one = (df[ACCOUNT] == df.loc[df[settings.LABEL_COL] == 1, ACCOUNT].iloc[0]).to_numpy()
    inside = exposure.exposure_features(df[one], *exposure.build_exposure_tables(df))
    alone = exposure.exposure_features(df[one], exposure.build_exposure_tables(df[~one])[0], None)
    assert np.allclose(inside.to_numpy(), alone.to_numpy(), rtol=1e-5, atol=1e-7, equal_nan=True)
    # A per-account table that holds none of the target accounts has nothing to take out.
    without = exposure.exposure_features(df[one], *exposure.build_exposure_tables(df[~one]))
    assert np.allclose(without.to_numpy(), alone.to_numpy(), rtol=1e-5, atol=1e-7, equal_nan=True)
    changed = df.copy()
    changed.loc[one, settings.LABEL_COL] = 0
    changed.loc[one, settings.REASON_COL] = RISK
    again = exposure.exposure_features(changed[one], *exposure.build_exposure_tables(changed))
    assert np.allclose(again.to_numpy(), alone.to_numpy(), rtol=1e-5, atol=1e-7, equal_nan=True)


def test_missing_optional_columns_are_skipped_not_fatal(capsys):
    """Without label, response code and risk score only the visit columns are left, after plain notes."""
    df = _rows(seed=3, n_accounts=20)
    bare = df.drop(columns=[settings.LABEL_COL, settings.REASON_COL, settings.DECLINE_FLAG_COL,
                            settings.VISA_SCORE_COL])
    _panel._SAID.clear()
    got = exposure.exposure_features(bare, *exposure.build_exposure_tables(bare))
    assert list(got.columns) == [f"exp_{n}_{w}" for w, _ in exposure.WINDOWS for n in ("visits", "visitors")]
    assert "note:" in capsys.readouterr().out


def test_the_command_line_runs_on_made_up_files(tmp_path, capsys):
    """The tool prints one summary line per column and writes them with the transaction id."""
    out = tmp_path / "exposure.parquet"
    frame = exposure.main(["--demo", "--out", str(out)])
    assert "exp_fraud_sum_90d" in capsys.readouterr().out and frame.shape[1] == 18
    written = pd.read_parquet(out)
    assert settings.ID_COL in written.columns and len(written) == len(frame)
