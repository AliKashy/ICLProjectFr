"""Tests of the members that share stage 2 (additions/model/members.py).

The model's logits must be the mean of the members' logits, the spread must be zero when the
members agree, one member must be the plain model, and the time rule of stage 2 must hold for
every member.
"""
import torch
import torch.nn.functional as F

from additions.model.history_stage import HistoryStage
from additions.model.members import Members, member_loss

HEADS, WIDTH = 4, 16


def _stage2(seed=0):
    """A small stage 2 with dropout zero."""
    torch.manual_seed(seed)
    return HistoryStage(in_dim=WIDTH, num_heads=HEADS, num_blocks=2, history_len=8, dropout=0.0, attn_dropout=0.0)


def _batch(B=2, T=5, seed=0):
    """Random vectors with strictly increasing and tied seconds, and some padding."""
    g = torch.Generator().manual_seed(seed)
    x = torch.randn(B, T, WIDTH, generator=g)
    times = torch.tensor([[1, 2, 2, 5, 9], [3, 4, 6, 0, 0]])[:B, :T]
    valid = torch.tensor([[True] * 5, [True, True, True, False, False]])[:B, :T]
    return x, times, valid


def test_expand_and_repeat_put_the_copies_of_one_sequence_side_by_side():
    """Rows b * M .. b * M + M - 1 are sequence b, each scaled by its member's vector."""
    members = Members(input_dim=WIDTH, head_dim=WIDTH, num_members=3)
    x, times, _ = _batch()
    out = members.expand(x)
    assert out.shape == (2 * 3, 5, WIDTH)
    for b in range(2):
        for m in range(3):
            assert torch.allclose(out[b * 3 + m], x[b] * members.scale[m])
            assert torch.equal(members.repeat(times)[b * 3 + m], times[b])
    assert members.repeat(None) is None
    # The first member reads the vectors as they are.
    assert torch.equal(members.scale[0], torch.ones(WIDTH))


def test_the_logits_are_the_mean_of_the_members():
    """`combine` returns the average of the members' own logits and each member's head applied to its copy."""
    members = Members(input_dim=WIDTH, head_dim=WIDTH, num_members=4)
    hidden = torch.randn(2 * 4, 5, WIDTH)
    logits, spread, each = members.combine(hidden)
    assert logits.shape == (2, 5, 2) and spread.shape == (2, 5) and each.shape == (2, 4, 5, 2)
    for m in range(4):
        assert torch.allclose(each[:, m], members.heads[m](hidden.view(2, 4, 5, WIDTH)[:, m]))
    assert torch.allclose(logits, each.mean(dim=1))
    log_odds = each[..., 1] - each[..., 0]
    assert torch.allclose(spread, log_odds.std(dim=1, unbiased=False))
    assert torch.isfinite(spread).all() and (spread >= 0).all()


def test_the_spread_is_zero_when_the_members_are_equal():
    """Equal scaling vectors and equal heads give equal members, a zero spread and the one member's logits."""
    members = Members(input_dim=WIDTH, head_dim=WIDTH, num_members=3)
    with torch.no_grad():
        members.scale.copy_(members.scale[0].expand_as(members.scale))
        for head in members.heads[1:]:
            head.load_state_dict(members.heads[0].state_dict())
    stage2 = _stage2()
    x, times, valid = _batch()
    h = stage2(members.expand(x), members.repeat(times), members.repeat(valid))
    logits, spread, each = members.combine(h)
    assert torch.allclose(spread, torch.zeros_like(spread), atol=1e-5)
    assert torch.allclose(logits, each[:, 0], atol=1e-5)


def test_one_member_is_exactly_the_plain_model():
    """With one member the scaling is ones, the spread is zero and the logits equal stage 2 plus a plain head."""
    members = Members(input_dim=WIDTH, head_dim=WIDTH, num_members=1)
    stage2 = _stage2()
    x, times, valid = _batch()
    logits, spread, _ = members.combine(stage2(members.expand(x), members.repeat(times), members.repeat(valid)))
    plain = members.heads[0](stage2(x, times, valid))
    assert torch.allclose(logits, plain, atol=1e-6)
    assert torch.all(spread == 0)


def test_later_rows_do_not_change_earlier_logits_or_spread():
    """Altering the last second of a sequence leaves the averaged logits and the spread of earlier rows as they were."""
    members = Members(input_dim=WIDTH, head_dim=WIDTH, num_members=3)
    stage2 = _stage2(1)
    x, times, valid = _batch()

    def run(v):
        return members.combine(stage2(members.expand(v), members.repeat(times), members.repeat(valid)))[:2]

    logits, spread = run(x)
    x2 = x.clone()
    x2[0, 4] = torch.randn(WIDTH) * 10
    logits2, spread2 = run(x2)
    assert torch.allclose(logits[0, :4], logits2[0, :4], atol=1e-6)
    assert torch.allclose(spread[0, :4], spread2[0, :4], atol=1e-6)
    assert torch.allclose(logits[1], logits2[1], atol=1e-6)
    assert not torch.allclose(logits[0, 4], logits2[0, 4], atol=1e-4)


def test_the_loss_is_the_mean_of_each_members_own_loss_and_reaches_every_weight():
    """`member_loss` equals the average of plain per-member cross-entropies, and every weight gets a gradient."""
    members = Members(input_dim=WIDTH, head_dim=WIDTH, num_members=3)
    stage2 = _stage2(2)
    x, times, valid = _batch()
    targets = torch.tensor([[0, 1, 1, 0, 1], [1, 0, 0, -100, -100]])
    _, _, each = members.combine(stage2(members.expand(x), members.repeat(times), members.repeat(valid)))
    loss = member_loss(each, targets, valid)
    weight = torch.tensor([1.0, 5.0])
    weighted = member_loss(each, targets, valid, class_weight=weight)
    n = int(valid.sum())
    expected, expected_w = [], []
    for m in range(3):
        rows, labels = each[:, m][valid], targets[valid]
        expected.append(F.cross_entropy(rows, labels, reduction="sum") / n)
        expected_w.append(F.cross_entropy(rows, labels, weight=weight, reduction="sum") / n)
    assert torch.allclose(loss, torch.stack(expected).mean(), atol=1e-6)
    assert torch.allclose(weighted, torch.stack(expected_w).mean(), atol=1e-6)
    loss.backward()
    for module in (members, stage2):
        for name, p in module.named_parameters():
            assert p.grad is not None and torch.isfinite(p.grad).all(), name
            assert p.grad.abs().sum() > 0, name
