"""Tests of the re-read after every history layer and of the memory of recent field representations.

The central tests are about the time rule: a row's result must not move when later rows, or
other rows of its own second, are altered, and it must equal the result on a batch cut down
to what the row may use. The other tests check that fresh blocks change nothing, that the
zero start still learns, which earlier rows the memory gathers, empty places, the gate, the
bank of one vector per predictor, the scoring route and the two helpers for starting from a
trained model.
"""
import numpy as np
import torch

from additions.common import synthetic
from additions.model import interleaved_reread as ir
from additions.model import masks
from additions.model._shared import encoder_stack, run_blocks, sequences_from_table
from additions.model.history_stage import HistoryStage
from additions.model.interleaved_reread import (GatedReread, InterleavedReread, PredictorBank, RecentFieldMemory,
                                                 eligible_rows, latest_prior_rows, mask_agreement, start_from,
                                                 train_only)

D, HEADS, WIDTH, FIELDS = 16, 4, 48, 7


def _batch(seed=0, n_accounts=10):
    """A padded batch of made-up transactions with same-second rows, a bank of fields and a vector per slot."""
    df = synthetic.make_transactions(n_accounts=n_accounts, days=15, seed=seed, tie_share=0.2)
    batch, _, _ = sequences_from_table(df, seconds_per_sequence=8)
    torch.manual_seed(seed)
    shape = batch["mask"].shape
    return batch["time_seq"], batch["mask"], torch.randn(*shape, FIELDS, D), torch.randn(*shape, WIDTH)


def _switched_on(block):
    """The same block with write-back layers that are no longer zero, as after some training."""
    torch.manual_seed(1)
    with torch.no_grad():
        for reread in block.rereads.values():
            reread.write_back.weight.normal_(std=0.2)
    return block


def _block(num_back=0, layers=2, after_layers=None, dropout=0.0, gate=True):
    """A small set of gated re-reads with no dropout unless asked, switched on."""
    torch.manual_seed(0)
    return _switched_on(InterleavedReread(WIDTH, history_layers=layers, after_layers=after_layers, field_dim=D,
                                          num_heads=HEADS, num_back=num_back, dropout=dropout, gate=gate,
                                          num_fields=FIELDS))


def _stack(layers=2):
    """A small stage 2 without dropout."""
    torch.manual_seed(2)
    return encoder_stack(WIDTH, HEADS, layers, dropout=0.0, attn_dropout=0.0)


def _run(block, stack, x, fields, times, valid, n_prefix=0):
    """Scoring-mode result of the whole stage 2 with its re-reads, under the strict mask."""
    allowed = masks.strict_visibility(times, valid)
    if n_prefix:
        allowed = masks.with_prefix(allowed, n_prefix)
    mask = masks.to_attention_mask(allowed, HEADS)
    block.eval(), stack.eval()
    with torch.no_grad():
        return block.run(stack, x, mask, block.prepare(fields, times, valid), n_prefix=n_prefix)


# ---------------------------------------------------------------------------------------------- earlier rows

def test_eligible_rows_is_the_rule_of_the_stage_two_mask():
    """The rows a row may gather are exactly the rows the mask of stage 2 lets it read, without itself."""
    times, valid, _, _ = _batch()
    T = valid.shape[1]
    expected = masks.strict_visibility(times, valid) & ~torch.eye(T, dtype=torch.bool)
    assert torch.equal(eligible_rows(times, valid), expected)
    # The time unit is taken into account the same way.
    assert torch.equal(eligible_rows(times * 1000 + 7, valid, units_per_second=1000), expected)


def test_latest_prior_rows_against_a_plain_loop():
    """For every row the slots found are its latest earlier rows by time, latest first, in any slot order."""
    g = torch.Generator().manual_seed(3)
    B, T, K = 5, 9, 4
    times = torch.randint(0, 6, (B, T), generator=g)              # few distinct seconds: many ties, not sorted
    valid = torch.rand(B, T, generator=g) > 0.2
    index, exists = latest_prior_rows(times, valid, K)
    assert index.shape == (B, T, K) and exists.shape == (B, T, K)
    for b in range(B):
        for i in range(T):
            earlier = [j for j in range(T) if valid[b, i] and valid[b, j] and times[b, j] < times[b, i]]
            earlier.sort(key=lambda j: (int(times[b, j]), j), reverse=True)
            want = earlier[:K]
            assert int(exists[b, i].sum()) == len(want)
            assert index[b, i][exists[b, i]].tolist() == want


def test_a_memory_wider_than_the_batch_marks_the_rest_empty():
    """Asking for more earlier rows than the batch has slots gives empty places, not an error."""
    times = torch.tensor([[1, 2, 3]])
    valid = torch.ones(1, 3, dtype=torch.bool)
    index, exists = latest_prior_rows(times, valid, 5)
    assert index.shape == (1, 3, 5)
    assert exists.sum(dim=-1).tolist() == [[0, 1, 2]]
    assert index[0, 2, :2].tolist() == [1, 0]


def test_memory_layout_and_empty_places():
    """Keys and values hold the row's own fields first, then one block per earlier row; missing blocks are marked."""
    times, valid, fields, _ = _batch()
    B, T = valid.shape
    torch.manual_seed(0)
    memory = RecentFieldMemory(field_dim=D, num_back=3, num_fields=FIELDS).eval()
    keys, values, missing, kept = memory(fields, times, valid)
    assert torch.equal(kept, valid)
    assert keys.shape == values.shape == (B, T, 4 * FIELDS, D) and missing.shape == (B, T, 4 * FIELDS)
    assert not missing[..., :FIELDS].any()                          # the row's own block is always there
    n_earlier = eligible_rows(times, valid).sum(dim=-1)             # [B, T]
    filled = (~missing).reshape(B, T, 4, FIELDS)[..., 0].sum(dim=-1) - 1
    assert torch.equal(filled, n_earlier.clamp(max=3))
    assert torch.isfinite(keys).all() and torch.isfinite(values).all()
    # The first earlier block of a row is the own block of the row one back, moved to look-back place 1.
    index, exists = latest_prior_rows(times, valid, 3)
    b, i = [int(v) for v in torch.nonzero(exists[..., 0])[0]]
    own_of_prior = keys[b, int(index[b, i, 0]), :FIELDS] - memory.back_key[0]
    assert torch.allclose(keys[b, i, FIELDS:2 * FIELDS] - memory.back_key[1], own_of_prior, atol=1e-6)


def test_memory_without_times_reads_own_fields_and_says_so_once(capsys):
    """Without times or a mask the memory falls back to the row's own fields and prints one line."""
    _, _, fields, _ = _batch()
    memory = RecentFieldMemory(field_dim=D, num_back=3, num_fields=FIELDS)
    keys, _, missing, kept = memory(fields)
    assert kept is None
    memory(fields)
    assert keys.shape[-2] == FIELDS and missing is None
    assert capsys.readouterr().out.count("note: the memory got no times") == 1


# ---------------------------------------------------------------------------------------------- the no-op start

def test_fresh_blocks_leave_stage_two_unchanged():
    """With zero-initialised write-back layers the run equals the plain stack, in training and in scoring."""
    times, valid, fields, x = _batch()
    stack = _stack()
    torch.manual_seed(0)
    block = InterleavedReread(WIDTH, history_layers=2, field_dim=D, num_heads=HEADS, num_back=3, dropout=0.0,
                              num_fields=FIELDS)
    mask = masks.to_attention_mask(masks.strict_visibility(times, valid), HEADS)
    stack.train(), block.train()
    assert torch.equal(block.run(stack, x, mask, block.prepare(fields, times, valid)), stack(x, mask=mask))
    stack.eval(), block.eval()
    with torch.no_grad():
        assert torch.allclose(block.run(stack, x, mask, block.prepare(fields, times, valid)), stack(x, mask=mask),
                              atol=1e-6)


def test_a_closed_gate_is_a_no_op_even_after_training():
    """A re-read whose gate is shut adds nothing, whatever its other weights are."""
    times, valid, fields, x = _batch()
    block = _block(num_back=2)
    with torch.no_grad():
        for reread in block.rereads.values():
            reread.gate[-1].weight.zero_()
            reread.gate[-1].bias.fill_(-1e4)                       # the gate gives exactly zero
    memory = block.prepare(fields, times, valid)
    out = block.after_layer(1, x, memory)
    assert torch.equal(out, x)
    assert float(block.rereads["1"].last_gate.max()) == 0.0


def test_the_zero_start_still_receives_a_gradient():
    """At the zero start the write-back layers get a gradient; once they have moved, every other part does."""
    times, valid, fields, x = _batch()
    stack = _stack()
    mask = masks.to_attention_mask(masks.strict_visibility(times, valid), HEADS)
    torch.manual_seed(0)
    block = InterleavedReread(WIDTH, history_layers=2, field_dim=D, num_heads=HEADS, num_back=2, dropout=0.1,
                              num_fields=FIELDS).train()
    fields = fields.clone().requires_grad_(True)
    block.run(stack, x, mask, block.prepare(fields, times, valid))[valid].pow(2).mean().backward()
    for reread in block.rereads.values():
        assert reread.write_back.weight.grad.abs().sum() > 0
    block.zero_grad()
    _switched_on(block)
    block.run(stack, x, mask, block.prepare(fields, times, valid))[valid].pow(2).mean().backward()
    for name, weight in block.named_parameters():
        assert weight.grad is not None and torch.isfinite(weight.grad).all(), name
        assert weight.grad.abs().sum() > 0, name
    assert fields.grad.abs().sum() > 0                             # the bank itself is reached as well


# ---------------------------------------------------------------------------------------------- the time rule

def test_later_rows_and_rows_of_the_same_second_never_reach_a_row():
    """Altering every row a row may not use (fields and vector) leaves that row's result unchanged."""
    for num_back in (0, 3):
        times, valid, fields, x = _batch(seed=1)
        block, stack = _block(num_back=num_back), _stack()
        before = _run(block, stack, x, fields, times, valid)
        checked = 0
        for b in range(times.shape[0]):
            real = int(valid[b].sum())
            for i in (real // 2, real - 1):
                hidden = (times[b] >= times[b, i]) & valid[b]
                hidden[i] = False                                  # the row itself keeps its inputs
                if not hidden.any():
                    continue
                altered_f, altered_x = fields.clone(), x.clone()
                altered_f[b, hidden] = torch.randn(int(hidden.sum()), FIELDS, D) * 3
                altered_x[b, hidden] = torch.randn(int(hidden.sum()), WIDTH) * 3
                after = _run(block, stack, altered_x, altered_f, times, valid)
                assert torch.allclose(before[b, i], after[b, i], atol=1e-5), (num_back, b, i)
                checked += 1
        assert checked > 5


def test_a_row_equals_its_result_on_a_batch_cut_down_to_what_it_may_use():
    """Scoring a row inside a long sequence gives what scoring it at the end of its own history gives."""
    times, valid, fields, x = _batch(seed=2)
    block, stack = _block(num_back=3), _stack()
    whole = _run(block, stack, x, fields, times, valid)
    checked = 0
    for b in range(min(4, times.shape[0])):
        real = int(valid[b].sum())
        i = real - 1
        keep = (times[b] < times[b, i]) & valid[b]
        keep[i] = True                                             # the row and its strictly earlier rows
        slots = torch.nonzero(keep).squeeze(1)
        cut = _run(block, stack, x[b:b + 1, slots], fields[b:b + 1, slots], times[b:b + 1, slots], valid[b:b + 1, slots])
        where = int((slots == i).nonzero())
        assert torch.allclose(whole[b, i], cut[0, where], atol=1e-5)
        checked += 1
    assert checked > 0


def test_the_memory_reaches_exactly_the_latest_earlier_rows():
    """One re-read with a memory of 2 moves with the fields of the rows 1 and 2 back and with no other row's."""
    times = torch.arange(1, 9).unsqueeze(0)                         # one sequence, eight rows, no ties
    valid = torch.ones(1, 8, dtype=torch.bool)
    torch.manual_seed(4)
    fields, x = torch.randn(1, 8, FIELDS, D), torch.randn(1, 8, WIDTH)
    block = _block(num_back=2, layers=1).eval()

    def result(f):
        with torch.no_grad():
            return block.after_layer(1, x, block.prepare(f, times, valid))

    before = result(fields)
    for other in range(8):
        altered = fields.clone()
        altered[0, other] = torch.randn(FIELDS, D) * 3
        moved = not torch.allclose(before[0, 5], result(altered)[0, 5], atol=1e-6)
        assert moved == (other in (3, 4, 5)), other                 # row 5 reads itself and the rows 4 and 3


def test_the_first_row_reads_only_itself_whatever_the_memory():
    """A row without earlier rows gets the result of a re-read without a memory."""
    times, valid, fields, x = _batch(seed=3)
    with_memory = _block(num_back=3, layers=1).eval()
    without = _block(num_back=0, layers=1).eval()
    state = {k: v for k, v in with_memory.state_dict().items() if not k.startswith("memory.back_")}
    without.load_state_dict(state, strict=False)
    with torch.no_grad():
        without.memory.back_key.copy_(with_memory.memory.back_key[:1])
        without.memory.back_value.copy_(with_memory.memory.back_value[:1])
        a = with_memory.after_layer(1, x, with_memory.prepare(fields, times, valid))
        b = without.after_layer(1, x, without.prepare(fields, times, valid))
    first = valid & (eligible_rows(times, valid).sum(dim=-1) == 0)
    assert first.any()
    assert torch.allclose(a[first], b[first], atol=1e-5)
    later = valid & (eligible_rows(times, valid).sum(dim=-1) > 0)
    assert not torch.allclose(a[later], b[later], atol=1e-4)


def test_positions_in_front_of_the_rows_are_left_alone():
    """With a prefix the re-read is applied to the rows only, and fresh blocks still equal the plain stack."""
    times, valid, fields, x = _batch()
    B = x.shape[0]
    stack = _stack()
    front = torch.randn(B, 2, WIDTH)
    seq = torch.cat([front, x], dim=1)
    mask = masks.to_attention_mask(masks.with_prefix(masks.strict_visibility(times, valid), 2), HEADS)
    torch.manual_seed(0)
    fresh = InterleavedReread(WIDTH, history_layers=2, field_dim=D, num_heads=HEADS, num_back=2, dropout=0.0,
                              num_fields=FIELDS).train()
    stack.train()
    assert torch.equal(fresh.run(stack, seq, mask, fresh.prepare(fields, times, valid), n_prefix=2),
                       stack(seq, mask=mask))
    on = _run(_block(num_back=2), stack, seq, fields, times, valid, n_prefix=2)
    assert on.shape == seq.shape and torch.isfinite(on).all()


# ---------------------------------------------------------------------------------------------- routes and options

def test_run_agrees_with_the_written_out_block_loop():
    """`run` on the stack and `run_blocks` with `after_layer` give the same rows."""
    times, valid, fields, x = _batch()
    block, stack = _block(num_back=2), _stack()
    mask = masks.to_attention_mask(masks.strict_visibility(times, valid), HEADS)
    block.eval(), stack.eval()
    with torch.no_grad():
        memory = block.prepare(fields, times, valid)
        direct = block.run(stack, x, mask, memory)
        looped = run_blocks(stack, x, mask, after_block=lambda number, rows: block.after_layer(number, rows, memory))
    assert torch.allclose(direct, looped, atol=1e-5)


def test_scoring_route_agrees_with_training_at_dropout_zero():
    """Evaluation mode under torch.no_grad() gives the training-mode result at dropout zero."""
    times, valid, fields, x = _batch()
    block, stack = _block(num_back=2), _stack()
    mask = masks.to_attention_mask(masks.strict_visibility(times, valid), HEADS)
    block.train(), stack.train()
    train_out = block.run(stack, x, mask, block.prepare(fields, times, valid))
    assert torch.allclose(train_out[valid], _run(block, stack, x, fields, times, valid)[valid], atol=1e-5)


def test_mixed_precision_runs_and_stays_finite():
    """Under automatic mixed precision the run gives finite rows close to the full-precision ones."""
    times, valid, fields, x = _batch()
    block, stack = _block(num_back=2), _stack()
    full = _run(block, stack, x, fields, times, valid)
    mask = masks.to_attention_mask(masks.strict_visibility(times, valid), HEADS)
    with torch.no_grad(), torch.autocast("cpu", dtype=torch.bfloat16):
        mixed = block.run(stack, x, mask, block.prepare(fields, times, valid))
    assert torch.isfinite(mixed).all()
    assert torch.allclose(full[valid], mixed.float()[valid], atol=0.25)
    # Training in mixed precision reaches the weights as well.
    block.train(), stack.train()
    with torch.autocast("cpu", dtype=torch.bfloat16):
        out = block.run(stack, x, mask, block.prepare(fields, times, valid))
    out.float()[valid].pow(2).mean().backward()
    assert all(torch.isfinite(w.grad).all() for w in block.parameters())


def test_chosen_layers_shapes_and_the_gate_report():
    """A re-read only after the chosen layers; segments by projection when the width asks for it; gates between 0 and 1."""
    times, valid, fields, x = _batch()
    last_only = _block(num_back=2, layers=3, after_layers=(3,))
    assert list(last_only.rereads) == ["3"]
    memory = last_only.prepare(fields, times, valid)
    assert last_only.after_layer(1, x, memory) is x                  # no re-read after layer 1
    out = last_only.after_layer(3, x, memory)
    assert out.shape == x.shape and not torch.equal(out, x)
    report = last_only.gate_report(valid)
    assert list(report) == [3] and 0.0 < report[3] < 1.0
    assert last_only.rereads["3"].last_gate.shape == (*valid.shape, WIDTH // D)
    # A width that is not a multiple of the field width is brought to segments by a projection.
    odd = GatedReread(40, field_dim=D, num_heads=HEADS, dropout=0.0)
    assert odd.num_segments == 3 and isinstance(odd.to_segments, torch.nn.Linear)
    keys, values, missing, _ = memory
    assert odd(torch.randn(*valid.shape, 40), keys, values, missing).shape == (*valid.shape, 40)
    # Without the gate the read comes in whole and nothing is kept for the report.
    plain = _block(num_back=0, gate=False)
    plain.after_layer(1, x, plain.prepare(fields))
    assert plain.gate_report() == {}


def test_predictor_bank_reads_the_stage_one_outputs():
    """One vector per predictor: unchanged without stage-1 outputs, and a function of the row alone with them."""
    torch.manual_seed(0)
    tokens, stage1 = torch.randn(2, 5, 9, D), torch.randn(2, 5, 4, D)
    bank = PredictorBank(field_dim=D, num_heads=HEADS, dropout=0.0).eval()
    assert bank(tokens) is tokens
    with torch.no_grad():
        out = bank(tokens, stage1)
        other = stage1.clone()
        other[:, 3:] = torch.randn(2, 2, 4, D)
        moved = bank(tokens, other)
    assert out.shape == tokens.shape and not torch.allclose(out, tokens)
    assert torch.allclose(out[:, :3], moved[:, :3], atol=1e-6)       # a row's bank depends on that row only
    assert not torch.allclose(out[:, 3:], moved[:, 3:], atol=1e-4)


def test_the_placeholders_are_the_defaults():
    """Sizes that are not given are read from the PLACEHOLDER values of the module."""
    block = InterleavedReread(3 * ir.FIELD_DIM)
    assert block.after_layers == tuple(range(1, ir.HISTORY_LAYERS + 1))
    assert block.memory.num_back == ir.NUM_BACK
    reread = block.rereads["1"]
    assert (reread.field_dim, reread.num_heads, reread.num_segments) == (ir.FIELD_DIM, ir.NUM_HEADS, 3)
    fields = torch.randn(1, 4, 64, ir.FIELD_DIM)
    keys, _, missing, _ = block.prepare(fields, torch.arange(4).unsqueeze(0), torch.ones(1, 4, dtype=torch.bool))
    assert block.memory.num_fields == ir.NUM_FIELDS == 64
    assert keys.shape == (1, 4, 64 + ir.NUM_BACK * 64, ir.FIELD_DIM)   # 384 places with 5 rows back
    assert int((~missing[0, 3]).sum()) == 4 * 64                      # the fourth row has three rows before it


def test_mask_agreement_sees_a_wrong_unit_a_wrong_prefix_and_swapped_inputs(capsys):
    """The look at the wiring gives 1.0 when memory and mask agree and less when the wiring is off."""
    times, valid, _, _ = _batch()
    ns = times * 1_000_000_000 + torch.arange(times.shape[1])       # nanoseconds; rows of one second differ inside it
    allowed = masks.strict_visibility(ns, valid, units_per_second=1_000_000_000)
    per_head = masks.to_attention_mask(allowed, HEADS)               # float [B * heads, T, T]
    assert mask_agreement(per_head, ns, valid, HEADS, units_per_second=1_000_000_000) == 1.0
    assert mask_agreement(~allowed, ns, valid, units_per_second=1_000_000_000) == 1.0          # bool, True hides
    assert mask_agreement(per_head, ns, valid, HEADS, units_per_second=1) < 1.0                # wrong unit
    front = masks.to_attention_mask(masks.with_prefix(allowed, 2), HEADS)
    assert mask_agreement(front, ns, valid, HEADS, n_prefix=2, units_per_second=1_000_000_000) == 1.0
    assert mask_agreement(front, ns, valid, HEADS, n_prefix=0, units_per_second=1_000_000_000) < 1.0   # wrong prefix
    lines = capsys.readouterr().out.splitlines()
    assert sum("check the time unit" in line for line in lines) == 2
    # One mask for every sequence, as a plain causal model has it.
    plain_times = torch.arange(6).expand(2, 6)
    everyone = torch.ones(2, 6, dtype=torch.bool)
    causal = torch.triu(torch.full((6, 6), float("-inf")), diagonal=1)
    assert mask_agreement(causal, plain_times, everyone) == 1.0


def test_run_passes_a_key_padding_mask_on():
    """A stage 2 that is called with a key padding mask gets the same mask layer by layer."""
    times, valid, fields, x = _batch()
    stack = _stack().train()
    torch.manual_seed(0)
    fresh = InterleavedReread(WIDTH, history_layers=2, field_dim=D, num_heads=HEADS, num_back=0, dropout=0.0,
                              num_fields=FIELDS).train()
    causal = torch.triu(torch.full((x.shape[1], x.shape[1]), float("-inf")), diagonal=1)
    hidden = torch.zeros(valid.shape).masked_fill(~valid, float("-inf"))         # float, as the other mask is
    expected = stack(x, mask=causal, src_key_padding_mask=hidden)
    got = fresh.run(stack, x, causal, fresh.prepare(fields), key_padding=hidden)
    assert torch.allclose(got[valid], expected[valid], atol=1e-6)


# ---------------------------------------------------------------------------------------------- starting from a trained model

class _Small(torch.nn.Module):
    """A stand-in for a trained model: a stack, a head, and optionally the new blocks."""

    def __init__(self, grown=False):
        super().__init__()
        self.stack = encoder_stack(WIDTH, HEADS, 2, dropout=0.0, attn_dropout=0.0)
        self.head = torch.nn.Linear(WIDTH, 2)
        self.interleaved = (InterleavedReread(WIDTH, history_layers=2, field_dim=D, num_heads=HEADS, num_back=2,
                                              dropout=0.0, num_fields=FIELDS) if grown else None)

    def forward(self, x, fields, times, valid):
        mask = masks.to_attention_mask(masks.strict_visibility(times, valid), HEADS)
        if self.interleaved is None:
            return self.head(self.stack(x, mask=mask))
        return self.head(self.interleaved.run(self.stack, x, mask, self.interleaved.prepare(fields, times, valid)))


def test_start_from_and_train_only(capsys):
    """The grown model takes the trained weights, scores alike, and trains nothing but the new blocks."""
    times, valid, fields, x = _batch()
    torch.manual_seed(7)
    trained = _Small().eval()
    torch.manual_seed(8)
    grown = _Small(grown=True).eval()
    taken, fresh, unused = start_from(grown, trained.state_dict())
    assert "start_from:" in capsys.readouterr().out
    assert len(taken) == len(trained.state_dict()) and all(name.startswith("interleaved.") for name in fresh)
    assert unused == []
    with torch.no_grad():
        assert torch.allclose(trained(x, fields, times, valid), grown(x, fields, times, valid), atol=1e-6)
    chosen = train_only(grown, [grown.interleaved])
    assert len(chosen) == len(list(grown.interleaved.parameters()))
    assert not any(w.requires_grad for w in grown.stack.parameters()) and not grown.head.weight.requires_grad
    before = {name: w.detach().clone() for name, w in grown.named_parameters()}
    optimiser = torch.optim.AdamW(chosen, lr=1e-2)
    grown.train()
    for _ in range(3):
        optimiser.zero_grad()
        grown(x, fields, times, valid)[valid].pow(2).mean().backward()
        optimiser.step()
    moved = {name for name, w in grown.named_parameters() if not torch.equal(w, before[name])}
    assert moved and all(name.startswith("interleaved.") for name in moved)
    assert np.isfinite(sum(float(w.detach().abs().sum()) for w in grown.parameters()))


def test_start_from_reads_a_checkpoint_drops_a_wrapper_name_and_reports_what_it_could_not_use(capsys):
    """A whole checkpoint, names with a part in front, and a tensor of another shape are each handled and reported."""
    torch.manual_seed(7)
    trained = _Small()
    weights = trained.state_dict()
    whole = {"epoch": 3, "state_dict": weights}
    taken, fresh, unused = start_from(_Small(grown=True), whole)
    assert len(taken) == len(weights) and unused == []
    wrapped = {"module." + name: tensor for name, tensor in weights.items()}
    taken, fresh, unused = start_from(_Small(grown=True), wrapped)
    assert len(taken) == len(weights) and unused == []
    assert "without their first part" in capsys.readouterr().out
    other = dict(weights)
    other["head.weight"] = torch.zeros(3, WIDTH)                    # another shape than the model's head
    other["gone.weight"] = torch.zeros(2)                           # a name the model does not have
    taken, fresh, unused = start_from(_Small(grown=True), other)
    assert unused == ["gone.weight", "head.weight"] and "head.weight" in fresh
    assert "not used" in capsys.readouterr().out


def test_train_only_clears_what_earlier_steps_left_behind():
    """Weights that are switched off keep no gradient, so an optimiser on every weight cannot move them."""
    times, valid, fields, x = _batch()
    torch.manual_seed(8)
    grown = _Small(grown=True).train()
    grown(x, fields, times, valid)[valid].pow(2).mean().backward()  # every weight has a gradient now
    train_only(grown, [grown.interleaved])
    assert all(w.grad is None for w in grown.stack.parameters()) and grown.head.weight.grad is None
    before = grown.head.weight.detach().clone()
    optimiser = torch.optim.AdamW(grown.parameters(), lr=1e-2, weight_decay=0.1)
    optimiser.zero_grad(set_to_none=False)
    grown(x, fields, times, valid)[valid].pow(2).mean().backward()
    optimiser.step()
    assert torch.equal(grown.head.weight, before)


def test_whatever_a_padded_slot_holds_does_not_reach_a_real_row():
    """Values that are not numbers, infinite or huge in padded slots of the bank leave every real row as it was."""
    times, valid, fields, x = _batch()
    assert not valid.all()
    stage = HistoryStage(in_dim=WIDTH, width=WIDTH, num_heads=HEADS, num_blocks=2, history_len=6, dropout=0.0,
                         attn_dropout=0.0).eval()
    for num_back in (0, 3):
        block = _block(num_back=num_back).eval()

        def rows(bank):
            memory = block.prepare(bank, times, valid)
            with torch.no_grad():
                return stage(x, times, valid, after_block=lambda number, y: block.after_layer(number, y, memory))

        clean = rows(fields)
        assert torch.isfinite(clean).all()
        for filler in (float("nan"), float("inf"), 1e30):
            dirty = fields.clone()
            dirty[~valid] = filler
            out = rows(dirty)
            assert torch.isfinite(out).all(), (num_back, filler)
            assert torch.equal(out[valid], clean[valid]), (num_back, filler)


def test_a_vector_per_field_and_its_switch():
    """With the number of fields given every place gets its own learned vector; with 0 there is none."""
    _, _, fields, _ = _batch()
    torch.manual_seed(0)
    marked = RecentFieldMemory(field_dim=D, num_back=0, num_fields=FIELDS).eval()
    plain = RecentFieldMemory(field_dim=D, num_back=0, num_fields=0).eval()
    assert plain.field_key is None and marked.field_key.shape == (FIELDS, D)
    plain.load_state_dict(marked.state_dict(), strict=False)
    same = fields[:, :, :1].expand_as(fields)                        # every field holds the same representation
    with torch.no_grad():
        with_marks, without = marked(same)[0], plain(same)[0]
    assert torch.allclose(without[:, :, 0], without[:, :, 1], atol=1e-6)      # the fields cannot be told apart
    assert not torch.allclose(with_marks[:, :, 0], with_marks[:, :, 1], atol=1e-4)
    assert torch.allclose(with_marks - marked.field_key, without, atol=1e-5)


def test_mixed_precision_keeps_the_bank_in_the_short_number_type():
    """Under mixed precision keys and values come out in the short type, with and without a memory."""
    times, valid, fields, _ = _batch()
    for num_back in (0, 2):
        memory = RecentFieldMemory(field_dim=D, num_back=num_back, num_fields=FIELDS)
        with torch.no_grad(), torch.autocast("cpu", dtype=torch.bfloat16):
            keys, values, _, _ = memory(fields, times, valid)
        assert keys.dtype == values.dtype == torch.bfloat16, num_back


def test_gate_report_leaves_a_layer_out_when_no_row_is_chosen():
    """An empty choice of rows gives an empty report, not a value that is not a number."""
    times, valid, fields, x = _batch()
    block = _block(num_back=0)
    block.after_layer(1, x, block.prepare(fields, times, valid))
    assert block.gate_report(torch.zeros_like(valid)) == {}
    assert list(block.gate_report(valid)) == [1]


def test_mask_agreement_reads_a_mask_per_head_and_a_key_padding_mask():
    """A mask of [B, heads, L, L] is read as it is, and padded positions named by a key padding mask are left out."""
    times, valid, _, _ = _batch()
    B, T = valid.shape
    allowed = masks.strict_visibility(times, valid)
    per_head = masks.to_attention_mask(allowed, HEADS).view(B, HEADS, T, T)
    assert mask_agreement(per_head, times, valid) == 1.0
    # A plain causal mask lets a padded slot read earlier rows; the key padding mask is what closes it.
    order = torch.arange(T).expand(B, T)
    causal = torch.triu(torch.full((T, T), float("-inf")), diagonal=1)
    assert mask_agreement(causal, order, valid) < 1.0
    assert mask_agreement(causal, order, valid, key_padding=~valid) == 1.0
    hidden = torch.zeros(valid.shape).masked_fill(~valid, float("-inf"))
    assert mask_agreement(causal, order, valid, key_padding=hidden) == 1.0


def test_a_reversed_mask_of_real_rows_shows_in_the_look_at_the_wiring(capsys):
    """Handing the padding mask where the mask of real rows belongs is seen, and the printed line says what it is."""
    times, valid, fields, _ = _batch()
    assert not valid.all()
    mask = masks.to_attention_mask(masks.strict_visibility(times, valid), HEADS)
    block = _block(num_back=2)
    assert block.look_at_wiring(mask, times, valid, block.prepare(fields, times, valid)) == 1.0
    capsys.readouterr()
    reversed_ = ~valid
    assert block.look_at_wiring(mask, times, reversed_, block.prepare(fields, times, reversed_)) < 1.0
    assert "valid looks reversed" in capsys.readouterr().out


def test_a_memory_built_without_times_or_mask_shows_in_the_look_at_the_wiring(capsys):
    """A memory that was not given the times or the mask of real rows is reported as not whole."""
    times, valid, fields, _ = _batch()
    mask = masks.to_attention_mask(masks.strict_visibility(times, valid), HEADS)
    for num_back in (0, 2):
        block = _block(num_back=num_back)
        assert block.look_at_wiring(mask, times, valid, block.prepare(fields)) == 0.0
        assert block.look_at_wiring(mask, times, valid, block.prepare(fields, times, valid)) == 1.0
    assert capsys.readouterr().out.count("the memory is not whole") == 2
    # A bank with another number of fields than the block was built for is not whole either.
    loose = InterleavedReread(WIDTH, history_layers=1, field_dim=D, num_heads=HEADS, num_back=0, num_fields=0)
    loose.memory.num_fields = FIELDS + 1
    assert loose.look_at_wiring(mask, times, valid, loose.prepare(fields, times, valid)) == 0.0


def test_times_and_mask_swapped_in_prepare_show_in_the_look_at_the_wiring(capsys):
    """A memory built with the two tensors swapped holds no earlier row, and the look at the wiring says so."""
    times, valid, fields, _ = _batch()
    mask = masks.to_attention_mask(masks.strict_visibility(times, valid), HEADS)
    block = _block(num_back=2)
    swapped = block.prepare(fields, valid, times)
    assert "times and valid look swapped" in capsys.readouterr().out
    assert block.look_at_wiring(mask, times, valid, swapped) == 0.0
    assert "does not hold the earlier rows" in capsys.readouterr().out
    assert block.look_at_wiring(mask, times, valid, block.prepare(fields, times, valid)) == 1.0
