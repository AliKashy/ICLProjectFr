"""Tests of the two-stage reference model that wires the blocks together (additions/model/reference_model.py).

The central tests run the whole model and check the time rule at the logits: altering
later rows of a sequence leaves the logits of earlier rows unchanged, and rows that share a
second do not read each other, with every switch off, with each switch alone and with all
of them on. The other tests check that every switch off is the original arithmetic, that
scoring agrees with training at dropout zero, that gradients reach every switched-on block,
that a zero-initialised block starts as a no-op, the loss, missing optional inputs and the demo.
"""
from functools import lru_cache

import pytest
import torch
import torch.nn.functional as F

from additions.common import synthetic
from additions.model._shared import sequences_from_table
from additions.model.members import member_loss
from additions.model.reference_model import TwoStageReference, extra_inputs, main

D, HEADS = 16, 4

# One entry per switch, plus every switch off and every switch on. The sizes of the data-dependent blocks
# are filled in from `extra_inputs` by `_model`.
FLAG_SETS = {
    "off": {},
    "summary": {"num_summary": 2},
    "width": {"stage2_width": 24},
    "reread": {"reread": True},
    "outcomes": {"aligned_outcomes": True},
    "bias": {"bias": True},
    "profile": {"profile": True},
    "state": {"state": True},
    "merchant": {"merchant": True},
    "members": {"num_members": 3},
    "interleaved": {"interleaved_reread": True},
    "memory": {"memory_back": 3},
    "interleaved_memory": {"interleaved_reread": True, "memory_back": 3, "field_bank": "predictor"},
    "all": {"num_summary": 2, "stage2_width": 24, "reread": True, "aligned_outcomes": True, "bias": True,
            "profile": True, "state": True, "merchant": True, "num_members": 3, "interleaved_reread": True,
            "memory_back": 2},
}


@lru_cache(maxsize=None)
def _data(seed=0):
    """A padded batch of made-up rows with every optional input, the code table sizes and the block sizes."""
    df = synthetic.make_transactions(n_accounts=8, days=8, seed=seed, tie_share=0.2, fraud_account_share=0.5)
    batch, row_index, cards = sequences_from_table(df, seconds_per_sequence=6)
    extra, sizes = extra_inputs(df, batch, row_index, vector_dim=4, seed=seed)
    return {**batch, **extra}, cards, sizes


def _batch(seed=0):
    """A fresh copy of the cached batch, safe to alter."""
    batch, _, _ = _data(seed)
    return {k: v.clone() for k, v in batch.items()}


def _model(flags, seed=0, dropout=0.0):
    """A small reference model with the given switches, sized to the made-up data."""
    batch, cards, sizes = _data()
    kw = {k: v for k, v in flags.items() if k not in ("bias", "profile", "state", "merchant")}
    if flags.get("bias"):
        kw["bias_fields"] = sizes["bias_fields"]
    if flags.get("profile"):
        kw["profile_numeric"] = sizes["profile_numeric"]
    if flags.get("state"):
        kw["state_vector_dim"], kw["num_states"] = sizes["state_vector_dim"], sizes["num_states"]
    if flags.get("merchant"):
        kw["context_vector_dim"] = sizes["context_vector_dim"]
    torch.manual_seed(seed)
    model = TwoStageReference(batch["continuous"].shape[-1], cards, embed_dim=D, num_heads=HEADS, stage1_blocks=1,
                              stage2_blocks=2, history_len=8, dropout=dropout, **kw)
    if flags.get("aligned_outcomes"):
        # Outcome embeddings large enough to move the outputs, so that a leak of an outcome would show.
        with torch.no_grad():
            model.stage2.first_layer.outcome.weight[1:].normal_(std=1.0)
    if model.interleaved is not None:
        # The gated re-reads start as a no-op. They are switched on here, as after some training, so that a
        # leak through them would show in the logits.
        with torch.no_grad():
            for block in model.interleaved.rereads.values():
                block.write_back.weight.normal_(std=0.2)
    return model


def _alter(batch, rows, seed=0):
    """A copy of `batch` with every per-row input of the slots in `rows` (bool [B, T]) replaced by random values."""
    _, cards, _ = _data()
    g = torch.Generator().manual_seed(seed)
    out = {k: v.clone() for k, v in batch.items()}
    n = int(rows.sum())
    out["continuous"][rows] = torch.randn(n, out["continuous"].shape[-1], generator=g) * 3
    for k, size in enumerate(cards):
        out["categorical"][..., k][rows] = torch.randint(1, max(size, 2), (n,), generator=g)
    out["outcome"][rows] = torch.randint(1, 6, (n,), generator=g)
    out["match_values"][rows] = torch.randint(0, 3, (n, out["match_values"].shape[-1]), generator=g)
    out["context_vectors"][rows] = torch.randn(n, *out["context_vectors"].shape[2:], generator=g) * 3
    out["context_scores"][rows] = torch.randn(n, out["context_scores"].shape[-1], generator=g) * 3
    return out


def _logits(model, batch):
    """Scoring-mode logits."""
    model.eval()
    with torch.no_grad():
        return model(batch)


@pytest.mark.parametrize("name", list(FLAG_SETS))
def test_shape_and_finite_values(name):
    """Every switch setting gives one finite pair of logits per slot."""
    batch = _batch()
    logits = _logits(_model(FLAG_SETS[name]), batch)
    assert logits.shape == (*batch["mask"].shape, 2)
    assert torch.isfinite(logits).all()


@pytest.mark.parametrize("name", list(FLAG_SETS))
def test_later_rows_do_not_change_earlier_logits(name):
    """Altering every input of the rows after a cut second leaves the logits of the rows up to that second unchanged."""
    batch = _batch()
    model = _model(FLAG_SETS[name])
    valid, times = batch["mask"], batch["time_seq"]
    middle = (valid.sum(dim=1) // 2).clamp(min=0)
    cut = times[torch.arange(times.shape[0]), middle].unsqueeze(1)                    # [B, 1]
    later = valid & (times > cut)
    kept = valid & (times <= cut)
    assert later.any() and kept.any()
    before = _logits(model, batch)
    after = _logits(model, _alter(batch, later))
    assert torch.allclose(before[kept], after[kept], atol=1e-5)
    # The later rows themselves did change, so the test can see a change when there is one.
    assert not torch.allclose(before[later], after[later], atol=1e-4)


@pytest.mark.parametrize("name", list(FLAG_SETS))
def test_rows_of_one_second_do_not_read_each_other(name):
    """Altering the other rows of a row's own second (and every later row) leaves that row's logits unchanged."""
    batch = _batch()
    model = _model(FLAG_SETS[name])
    valid, times = batch["mask"], batch["time_seq"]
    before = _logits(model, batch)
    checked = 0
    for b in range(times.shape[0]):
        real = int(valid[b].sum())
        for i in range(real):
            peers = valid[b] & (times[b] == times[b, i])
            if int(peers.sum()) < 2:
                continue
            hidden = torch.zeros_like(valid)
            hidden[b] = valid[b] & (times[b] >= times[b, i])
            hidden[b, i] = False                                   # the row keeps its own inputs
            after = _logits(model, _alter(batch, hidden, seed=i))
            assert torch.allclose(before[b, i], after[b, i], atol=1e-5)
            checked += 1
            break
        if checked >= 4:
            break
    assert checked > 0                                             # the data really has rows that share a second


def test_a_rows_own_outcome_never_reaches_its_logits():
    """With the outcome layer on, a row's own outcome code leaves its logits unchanged and moves later rows."""
    batch = _batch()
    model = _model(FLAG_SETS["all"])
    before = _logits(model, batch)
    valid, times = batch["mask"], batch["time_seq"]
    b = int(valid.sum(dim=1).argmax())
    i = 0
    changed = {k: v.clone() for k, v in batch.items()}
    changed["outcome"][b, i] = 1 + (int(batch["outcome"][b, i]) % 5)
    after = _logits(model, changed)
    assert torch.allclose(before[b, i], after[b, i], atol=1e-5)
    later = valid[b] & (times[b] > times[b, i])
    assert not torch.allclose(before[b, later], after[b, later], atol=1e-4)


def test_every_switch_off_is_the_original_arithmetic():
    """With every switch off, the logits equal the original recipe: CLS stage 1, position by count, a sequence CLS
    that no row reads, the strict float mask through nn.TransformerEncoder, one linear head."""
    batch = _batch()
    model = _model({}).train()                                     # dropout zero: training mode is deterministic
    assert model.stage1.num_summary == 1 and isinstance(model.stage2.project, torch.nn.Identity)
    assert model.members is None and model.reread_block is None and model.attention_bias is None
    valid, times = batch["mask"], batch["time_seq"]
    B, T = valid.shape
    tokens = model.tokenizer(batch["continuous"], batch["categorical"])
    F_ = tokens.shape[2]
    flat = tokens.reshape(B * T, F_, D)
    cls = model.stage1.summary.expand(B * T, 1, D)
    txn = model.stage1.encoder(torch.cat([cls, flat], dim=1))[:, 0].reshape(B, T, D)
    earlier = (times.unsqueeze(1) < times.unsqueeze(2)) & valid.unsqueeze(1)
    seq = txn + model.stage2.position(earlier.sum(-1).clamp(max=model.stage2.position.num_embeddings - 1))
    seq = torch.cat([torch.randn(1, 1, D).expand(B, 1, D), seq], dim=1)            # the sequence CLS in front
    L = 1 + T
    allowed = torch.zeros(B, L, L, dtype=torch.bool)
    allowed[:, 0, :] = True                                                         # the CLS reads everything
    allowed[:, 1:, 1:] = (earlier & valid.unsqueeze(2)) | torch.eye(T, dtype=torch.bool)
    key_padding = torch.cat([torch.zeros(B, 1, dtype=torch.bool), ~valid], dim=1)
    closed = (~allowed | key_padding.unsqueeze(1)) & ~torch.eye(L, dtype=torch.bool)
    mask = torch.zeros(B, L, L).masked_fill(closed, float("-inf")).repeat_interleave(HEADS, dim=0)
    original = model.head(model.stage2.blocks(seq, mask=mask)[:, 1:])
    assert torch.allclose(model(batch)[valid], original[valid], atol=1e-5)


@pytest.mark.parametrize("name", ["off", "all"])
def test_scoring_agrees_with_training_at_dropout_zero(name):
    """Evaluation mode under torch.no_grad() gives the training-mode logits when dropout is zero."""
    batch = _batch()
    model = _model(FLAG_SETS[name])
    train_out = model.train()(batch)
    assert torch.allclose(train_out, _logits(model, batch), atol=1e-5)


def test_gradients_reach_every_switched_on_block():
    """A loss on the real rows sends a finite, non-zero gradient into every block that is switched on."""
    batch = _batch()
    model = _model(FLAG_SETS["all"], dropout=0.1).train()
    model.loss(batch).backward()
    blocks = {"tokenizer": model.tokenizer, "stage1": model.stage1, "stage2": model.stage2,
              "outcome layer": model.stage2.first_layer, "reread": model.reread_block,
              "profile": model.profile_encoder, "state": model.state_prefix, "bias": model.attention_bias,
              "merchant": model.merchant_context, "members": model.members, "interleaved": model.interleaved}
    for name, block in blocks.items():
        grads = [p.grad for p in block.parameters() if p.grad is not None]
        assert grads, name
        assert all(torch.isfinite(g).all() for g in grads), name
        assert sum(float(g.abs().sum()) for g in grads) > 0, name


@pytest.mark.parametrize("flags,own", [({"reread": True}, "reread_block."), ({"bias": True}, "attention_bias."),
                                       ({"reread": True, "bias": True}, ("reread_block.", "attention_bias.")),
                                       ({"interleaved_reread": True}, "interleaved."),
                                       ({"memory_back": 3}, "interleaved."),
                                       ({"interleaved_reread": True, "memory_back": 3, "field_bank": "predictor"},
                                        ("interleaved.", "predictor_bank."))])
def test_a_zero_initialised_block_starts_as_a_no_op(flags, own):
    """A model with a zero-initialised block, given the weights of the model without it, scores exactly alike."""
    batch = _batch()
    plain = _model({}, seed=0)
    grown = _model(flags, seed=5)
    if grown.interleaved is not None:
        # `_model` switches the gated re-reads on for the leak tests; this test is about their fresh start.
        with torch.no_grad():
            for block in grown.interleaved.rereads.values():
                block.write_back.weight.zero_()
    result = grown.load_state_dict(plain.state_dict(), strict=False)
    assert not result.unexpected_keys
    assert result.missing_keys and all(key.startswith(own) for key in result.missing_keys)
    assert torch.allclose(_logits(plain, batch), _logits(grown, batch), atol=1e-6)


def test_the_loss_is_the_original_loss_or_the_member_loss():
    """Without members the loss is summed cross-entropy over real rows divided by their count; with members it is
    the per-member loss."""
    batch = _batch()
    valid, targets = batch["mask"], batch["target_seq"]
    plain = _model({})
    logits = plain(batch)
    expected = F.cross_entropy(logits[valid], targets[valid], reduction="sum") / int(valid.sum())
    assert torch.allclose(plain.loss(batch), expected, atol=1e-6)
    many = _model({"num_members": 3})
    _, details = many(batch, return_details=True)
    assert torch.allclose(many.loss(batch), member_loss(details["member_logits"], targets, valid), atol=1e-6)
    assert details["spread"].shape == valid.shape and (details["spread"] >= 0).all()


def test_missing_optional_inputs_are_skipped_with_one_line(capsys):
    """A batch without the optional inputs still runs with every switch on, and each missing input is named once."""
    batch = _batch()
    base = {k: batch[k] for k in ("continuous", "categorical", "mask", "time_seq", "target_seq")}
    model = _model(FLAG_SETS["all"])
    first = _logits(model, base)
    _logits(model, base)
    lines = capsys.readouterr().out.splitlines()
    assert torch.isfinite(first).all()
    for key in ("'profile_numeric'", "'state_sums'", "'match_values'", "'outcome'", "merchant context"):
        assert sum(key in line for line in lines) == 1, key


def test_demo_trains_and_writes_weights_only_when_asked(tmp_path):
    """The demo runs a few steps with every block on, lowers the loss and writes a file only with --out."""
    target = tmp_path / "weights.pt"
    before, after = main(["--accounts", "8", "--days", "6", "--steps", "4", "--all", "--out", str(target)])
    assert after < before
    assert target.exists()
    main(["--accounts", "6", "--days", "4", "--steps", "1"])
    assert sorted(p.name for p in tmp_path.iterdir()) == ["weights.pt"]
