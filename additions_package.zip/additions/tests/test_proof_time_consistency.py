"""Tests of the time-consistency checks.

The AUC is compared with a slow count over all pairs, the one-column model with a plain
group-by, and the two checks are shown to find columns built to flip, to fade or to drift,
while leaving a steady column and a noise column alone.
"""
import numpy as np
import pandas as pd
import pytest
from sklearn.metrics import roc_auc_score

from additions import settings
from additions.common import synthetic, tables
from additions.proof import _shared, time_consistency

MAY = ("2025-05-01", "2025-06-01")
JUNE = ("2025-06-01", "2025-07-01")


@pytest.fixture(scope="module")
def rows():
    """Two made-up months with a steady, a flipping, a noise, a drifting and a text column."""
    df = synthetic.make_transactions(n_accounts=1200, seed=5, fraud_account_share=0.15)
    rng = np.random.default_rng(5)
    y = _shared.fraud_flags(df)
    late = pd.to_datetime(df[settings.TIME_COL]) >= pd.Timestamp(JUNE[0])
    df["steady"] = rng.normal(size=len(df)) + 1.5 * y
    df["flipping"] = rng.normal(size=len(df)) + np.where(late, -1.5, 1.5) * y
    df["noise"] = rng.normal(size=len(df))
    df["drifting"] = rng.normal(size=len(df)) + 1.0 * late
    df["text_code"] = np.where(rng.random(len(df)) < 0.1, None, rng.choice(["x", "y", "z"], len(df)))
    df.loc[rng.random(len(df)) < 0.05, "steady"] = np.nan
    return {"all": df, "early": time_consistency.in_period(df, MAY), "late": time_consistency.in_period(df, JUNE)}


def test_auc_equals_a_count_over_all_pairs():
    """The AUC equals the share of positive-negative pairs won (ties half), with and without weights."""
    rng = np.random.default_rng(0)
    y = (rng.random(300) < 0.2).astype(int)
    s = np.round(rng.normal(size=300) + y, 1)                         # rounding makes many ties
    pos, neg = s[y == 1], s[y == 0]
    slow = ((pos[:, None] > neg[None, :]).sum() + 0.5 * (pos[:, None] == neg[None, :]).sum()) / (len(pos) * len(neg))
    assert np.isclose(time_consistency.auc(y, s), slow)
    assert np.isclose(time_consistency.auc(y, s), roc_auc_score(y, s))
    # A weight of 2 is the same as the row appearing twice.
    w = rng.integers(0, 3, 300)
    assert np.isclose(time_consistency.auc(y, s, w), roc_auc_score(np.repeat(y, w), np.repeat(s, w)))
    assert np.isnan(time_consistency.auc(np.zeros(5), np.arange(5)))
    units = np.arange(300) // 3
    low, high = time_consistency.auc_interval(y, s, units, draws=200, seed=1)
    assert low < slow < high
    assert np.isnan(time_consistency.auc_interval(y, s, units, draws=0)[0])


def test_rate_model_equals_a_group_by_and_uses_fit_rows_only():
    """Each bin's rate is the pulled-toward-overall rate of a plain group-by; missing and rare codes get own bins."""
    rng = np.random.default_rng(1)
    v = np.where(rng.random(2000) < 0.1, np.nan, rng.normal(size=2000))
    t = (rng.random(2000) < 0.1 + 0.1 * np.nan_to_num(v > 0)).astype(float)
    model = time_consistency.fit_rate_model(v, t, n_bins=5, prior_rows=50)
    idx = time_consistency.bin_index(v, model["bins"])
    assert set(idx[np.isnan(v)].tolist()) == {0} and len(np.unique(idx)) == 6
    overall = t.mean()
    for b, group in pd.Series(t).groupby(idx):
        assert np.isclose(model["rate"][b], (group.sum() + 50 * overall) / (len(group) + 50))
    # The read uses the fit's cut points: a far value lands in the top bin, not a new one.
    assert time_consistency.bin_index(np.array([1e9]), model["bins"])[0] == idx.max()
    codes = np.array(["a", "a", "b", None, "c"], dtype=object)
    text = time_consistency.fit_rate_model(codes, np.array([1, 0, 1, 0, 0.0]), max_codes=2, prior_rows=0)
    read = time_consistency.bin_index(np.array(["a", "b", "c", "new", None], dtype=object), text["bins"])
    assert read.tolist() == [1, 2, 3, 3, 0]                            # rare and unseen codes share the last bin
    assert np.isclose(time_consistency.apply_rate_model(text, np.array(["a"], dtype=object))[0], 0.5)


def test_stability_flags_the_flipping_column_only(rows, capsys):
    """The flipping column is flagged, the steady and noise columns are not, and late rows never touch the fit."""
    columns = ["steady", "flipping", "noise", "text_code", "absent"]
    table = time_consistency.stability_table(rows["early"], rows["late"], columns, draws=40, seed=3)
    assert "absent" in capsys.readouterr().out
    by = table.set_index("column")
    assert bool(by.loc["flipping", "flips"]) and bool(by.loc["flipping", "fades"])
    assert table["column"].iloc[0] == "flipping"
    assert not by.loc["steady", "flips"] and not by.loc["steady", "fades"] and by.loc["steady", "auc_late"] > 0.7
    assert not by.loc["noise", "flips"] and abs(by.loc["noise", "auc_early"] - 0.5) < 0.1
    assert by.loc["steady", "late_low"] < by.loc["steady", "auc_late"] < by.loc["steady", "late_high"]
    # Changing every late value changes the late read only: the early figures come from early rows alone.
    late = rows["late"].copy()
    late["steady"] = -late["steady"]
    again = time_consistency.stability_table(rows["early"], late, ["steady"], draws=0, seed=3).set_index("column")
    assert np.isclose(again.loc["steady", "auc_early"], by.loc["steady", "auc_early"])
    assert np.isclose(again.loc["steady", "auc_fit"], by.loc["steady", "auc_fit"])
    assert again.loc["steady", "auc_late"] < 0.5 and bool(again.loc["steady", "flips"])


def test_classifier_finds_the_drifting_column(rows):
    """The two months are told apart by the drifting column; a random split of the same rows cannot be told apart."""
    columns = ["steady", "noise", "drifting", "text_code"]
    drivers, summary = time_consistency.period_classifier(rows["early"], rows["late"], columns, seed=2, rounds=30)
    assert summary["auc"] > 0.65 and summary["rows_a"] == len(rows["early"])
    assert drivers["column"].iloc[0] == "drifting" and bool(drivers.set_index("column").loc["drifting", "shifted"])
    assert not drivers.set_index("column").loc["noise", "shifted"]
    assert np.isclose(drivers["gain_share"].sum(), 1.0)
    # Two halves of the same accounts' rows (split by account) hold the same values: nothing to find.
    late = rows["late"]
    half = _shared.account_folds(_shared.account_codes(late), 2, seed=9) == 0
    _, same = time_consistency.period_classifier(late[half], late[~half], columns, seed=2, rounds=30)
    assert abs(same["auc"] - 0.5) < 0.05


def test_dates_are_read_as_their_age_at_the_row():
    """A date column becomes days between the date and the row's own time."""
    df = pd.DataFrame({settings.TIME_COL: pd.to_datetime(["2025-05-10", "2025-05-20"]),
                       "opened": pd.to_datetime(["2025-05-01", "2025-05-01"])})
    assert time_consistency.column_values(df, "opened").tolist() == [9.0, 19.0]


def test_tool_reads_files_and_prints_both_checks(rows, tmp_path, capsys):
    """The tool reads numbered files, prints the stability table and the classifier, and writes the table when asked."""
    numbers = synthetic.write_files(rows["all"], tmp_path / "raw", 2, first_number=3)
    base, files, out = str(tmp_path / "raw"), f"{numbers[0]}-{numbers[-1]}", str(tmp_path / "stability.parquet")
    time_consistency.main(["--columns", "steady", "flipping", "drifting", "--base", base, "--files", files,
                           "--late-base", base, "--late-files", files, "--early", *MAY, "--late", *JUNE,
                           "--draws", "20", "--out", out])
    printed = capsys.readouterr().out
    assert "fitted early and read late" in printed and "classifier telling the early period" in printed
    written = tables.read_columns(out)
    assert set(written["column"]) == {"steady", "flipping", "drifting"}
    time_consistency.main(["--columns", "steady", "--base", base, "--files", files, "--late-base", base,
                           "--late-files", files, "--early", *JUNE, "--late", *JUNE,
                           "--shift", "extracts", "--draws", "0"])
    assert "the early files against the late files" in capsys.readouterr().out
    time_consistency.main(["--columns", "steady", "--base", base, "--files", files, "--late-base", base,
                           "--late-files", files, "--early", "2020-01-01", "2020-02-01", "--draws", "0"])
    assert "holds no rows" in capsys.readouterr().out
