"""Tests of the outcome-history columns.

The central test changes the bank's decision on single rows and checks that the columns of
those very rows do not move: a row never reads its own decision. The other tests recompute
the columns the slow way and check the rules on small hand-made tables.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, timekeys
from additions.features import lookback, outcome_history
from additions.features.outcome_history import ADVICE, APPROVED, FUNDS_DECLINE, OTHER_DECLINE, RISK_DECLINE, UNKNOWN

OK, FUNDS, RISK = settings.APPROVED_REASONS[0], settings.FUNDS_DECLINE_REASONS[0], settings.RISK_DECLINE_REASONS[0]
WINDOWS = {"1h": 3_600, "24h": 86_400, "7d": 7 * 86_400, "30d": 30 * 86_400}


def _table(seed=0, n_accounts=30, **kwargs):
    """Made-up rows with a fraud run on most accounts, plus a few unlisted response codes and missing ones."""
    df = synthetic.make_transactions(n_accounts=n_accounts, seed=seed, fraud_account_share=0.8, **kwargs)
    rng = np.random.default_rng(seed)
    df.loc[rng.random(len(df)) < 0.03, settings.REASON_COL] = "91"              # a refusal that is in no list
    df.loc[rng.random(len(df)) < 0.02, [settings.REASON_COL, settings.DECLINE_FLAG_COL]] = [None, 0]
    return df


def _sequence(reasons, minutes=None, merchant=7, advice=None):
    """One account, one row per entry of `reasons`, a minute apart unless `minutes` says otherwise."""
    n = len(reasons)
    minutes = np.arange(n) if minutes is None else np.asarray(minutes)
    return pd.DataFrame({
        settings.ACCOUNT_COL: ["a"] * n,
        settings.TIME_COL: pd.Timestamp("2025-06-03 10:00:00") + pd.to_timedelta(minutes, unit="min"),
        settings.REASON_COL: reasons,
        settings.DECLINE_FLAG_COL: [int(r != OK) for r in reasons],
        settings.ADVICE_COL: advice if advice is not None else [None] * n,
        settings.MERCHANT_COL: merchant,
    })


def _same(a, b):
    return bool(np.isclose(a, b, rtol=1e-5, atol=1e-5, equal_nan=True))


def test_families_follow_the_rules():
    """Each rule of the family mapping gives the family it names, and the later rules win."""
    df = pd.DataFrame({
        settings.REASON_COL: [OK, FUNDS, RISK, "91", OK, FUNDS, None, None, OK],
        settings.DECLINE_FLAG_COL: [0, 1, 1, 1, 1, 0, 1, 0, 0],
        settings.ADVICE_COL: [None, None, None, None, None, None, None, None, "A"],
    })
    expected = [APPROVED, FUNDS_DECLINE, RISK_DECLINE, OTHER_DECLINE, OTHER_DECLINE, FUNDS_DECLINE,
                OTHER_DECLINE, UNKNOWN, ADVICE]
    assert outcome_history.outcome_family(df).tolist() == expected
    # The same codes stored as numbers are found when the lists are written the way the numbers print.
    numbers = pd.DataFrame({settings.REASON_COL: [0.0, 51.0, 5.0], settings.DECLINE_FLAG_COL: [0.0, 1.0, 1.0]})
    got = outcome_history.outcome_family(numbers, advice_col=False, approved_reasons=("0",), risk_reasons=("5",))
    assert got.tolist() == [APPROVED, FUNDS_DECLINE, RISK_DECLINE]


def test_a_row_never_reads_its_own_decision():
    """Changing the decision on a row leaves that row's own columns, and its same-second rows, unchanged."""
    df = _table(seed=1)
    account = timekeys.codes(df[settings.ACCOUNT_COL])
    secs = timekeys.seconds(df[settings.TIME_COL])
    before = outcome_history.build_outcome_history(df)
    # One row per account, somewhere in the middle of its history, so that no changed row precedes another.
    changed = np.array([np.flatnonzero(account == a)[(account == a).sum() // 2] for a in np.unique(account)])
    flipped = df.copy()
    was_approved = (df[settings.REASON_COL].iloc[changed] == OK).to_numpy()
    flipped.iloc[changed, flipped.columns.get_loc(settings.REASON_COL)] = np.where(was_approved, RISK, OK)
    flipped.iloc[changed, flipped.columns.get_loc(settings.DECLINE_FLAG_COL)] = was_approved.astype(int)
    flipped.iloc[changed, flipped.columns.get_loc(settings.ADVICE_COL)] = None
    after = outcome_history.build_outcome_history(flipped)

    same_second = np.zeros(len(df), dtype=bool)
    later = np.zeros(len(df), dtype=bool)
    for j in changed:
        same_second |= (account == account[j]) & (secs == secs[j])               # includes the changed row itself
        later |= (account == account[j]) & (secs > secs[j])
    assert np.array_equal(before[same_second].to_numpy(), after[same_second].to_numpy(), equal_nan=True)
    assert not np.array_equal(before[later].to_numpy(), after[later].to_numpy(), equal_nan=True)   # the test can fail
    untouched = ~(same_second | later)
    assert np.array_equal(before[untouched].to_numpy(), after[untouched].to_numpy(), equal_nan=True)


def test_columns_equal_the_slow_definition():
    """Every column matches a row-by-row recomputation from the strictly earlier rows of the look-back."""
    df = _table(days=92, start="2024-10-01")
    got = outcome_history.build_outcome_history(df)
    family = outcome_history.outcome_family(df)
    account = timekeys.codes(df[settings.ACCOUNT_COL])
    secs = timekeys.seconds(df[settings.TIME_COL])
    start = lookback.lookback_start(secs)
    declined = np.isin(family, [FUNDS_DECLINE, RISK_DECLINE, OTHER_DECLINE])
    approved = family == APPROVED
    zero_check = (df[settings.TYPE_COL] == settings.ZERO_CHECK_TYPES[0]).to_numpy()
    assert got.shape == (len(df), 20 + 3 + 9 * 3) and got.index.equals(df.index)
    assert np.isfinite(got.to_numpy()[~np.isnan(got.to_numpy())]).all()
    assert len(set(family)) == 6                                              # all five families and "unknown" occur
    for i in range(0, len(df), 5):
        row = got.iloc[i]
        earlier = (account == account[i]) & (secs < secs[i]) & (secs >= start[i])
        previous = np.flatnonzero(earlier & (secs == secs[earlier].max()))[-1] if earlier.any() else None
        assert row["outcome_prev_family"] == (family[previous] + 1 if previous is not None else 0)
        for label in ("1h", "24h", "7d"):
            recent = earlier & (secs >= secs[i] - WINDOWS[label])
            for code, name in enumerate(outcome_history.FAMILIES):
                assert row[f"outcome_n_{name}_{label}"] == (recent & (family == code)).sum()
            assert row[f"outcome_n_zero_check_{label}"] == (recent & zero_check).sum()
        for name, mask in (("risk_decline", family == RISK_DECLINE), ("decline", declined)):
            hit = earlier & mask
            gap = np.log1p(secs[i] - secs[hit].max()) if hit.any() else np.nan
            assert row[f"outcome_had_{name}"] == float(hit.any())
            assert _same(row[f"outcome_log_secs_since_{name}"], gap)
        for name, col in outcome_history.default_keys().items():
            at_key = earlier & (df[col].to_numpy() == df[col].iloc[i])
            p = f"outcome_{name}_"
            for label in ("1h", "24h", "30d"):
                recent = at_key & (secs >= secs[i] - WINDOWS[label])
                attempts, refused = (recent & (declined | approved)).sum(), (recent & declined).sum()
                assert row[f"{p}n_declined_{label}"] == refused
                assert _same(row[f"{p}share_declined_{label}"], refused / attempts if attempts else np.nan)
            d, a = secs[at_key & declined], secs[at_key & approved]
            assert row[p + "had_decline"] == float(len(d) > 0)
            assert _same(row[p + "log_secs_since_decline"], np.log1p(secs[i] - d.max()) if len(d) else np.nan)
            assert row[p + "first_approval_after_decline"] == float(len(d) > 0 and (len(a) == 0 or d.max() > a.max()))


def test_first_approval_after_declines_is_a_fact_about_the_past():
    """The flag is raised after declines at the merchant and lowered again once an approval has followed."""
    got = outcome_history.build_outcome_history(_sequence([RISK, RISK, OK, OK, FUNDS, OK]))
    assert got["outcome_merchant_first_approval_after_decline"].tolist() == [0, 1, 1, 0, 0, 1]
    assert got["outcome_merchant_n_declined_1h"].tolist() == [0, 1, 2, 2, 2, 3]
    assert np.allclose(got["outcome_merchant_share_declined_1h"].iloc[1:], [1, 1, 2 / 3, 2 / 4, 3 / 5])
    assert np.isnan(got["outcome_merchant_share_declined_1h"].iloc[0])           # no attempt yet: no share
    assert got["outcome_prev_family"].tolist() == [0, 3, 3, 1, 1, 2]
    # An advice row is a notice, not an attempt: it neither raises the flag nor counts in the share.
    advice = outcome_history.build_outcome_history(_sequence([RISK, OK, OK], advice=[None, "A", None]))
    assert advice["outcome_merchant_first_approval_after_decline"].tolist() == [0, 1, 1]
    assert advice["outcome_merchant_share_declined_1h"].iloc[2] == 1.0
    # At another merchant the declines do not count.
    other = outcome_history.build_outcome_history(_sequence([RISK, RISK, OK], merchant=[7, 7, 8]))
    assert other["outcome_merchant_first_approval_after_decline"].tolist() == [0, 1, 0]
    assert other["outcome_n_risk_decline_1h"].tolist() == [0, 1, 2]              # the account-wide count sees them


def test_rows_of_the_same_second_do_not_see_each_other():
    """A decline and a row in the same second: the row does not know about the decline, the next row does."""
    got = outcome_history.build_outcome_history(_sequence([RISK, OK, OK], minutes=[0, 0, 1]))
    assert got["outcome_n_risk_decline_1h"].tolist() == [0, 0, 1]
    assert got["outcome_had_decline"].tolist() == [0, 0, 1]
    assert got["outcome_prev_family"].tolist() == [0, 0, 1]                      # of two earlier rows, the last listed
    # The decline and the approval of the first second cannot be ordered, so the flag stays down.
    assert got["outcome_merchant_first_approval_after_decline"].tolist() == [0, 0, 0]


def test_later_rows_do_not_change_earlier_columns():
    """Dropping every row after the middle of the period leaves the columns of the rows before it unchanged."""
    df = _table(seed=2)
    secs = timekeys.seconds(df[settings.TIME_COL])
    keep = secs <= np.median(secs)
    full = outcome_history.build_outcome_history(df)
    part = outcome_history.build_outcome_history(df[keep])
    assert np.array_equal(full[keep].to_numpy(), part.to_numpy(), equal_nan=True)


def test_training_rows_get_what_scored_rows_get():
    """A December row in long files gets the columns it would get in files that begin on 1 November."""
    df = _table(seed=3, n_accounts=20, days=92, start="2024-10-01")
    secs = timekeys.seconds(df[settings.TIME_COL])
    december = secs >= lookback.data_start("2024-12-01")
    cut = secs >= lookback.data_start("2024-11-01")
    long_files = outcome_history.build_outcome_history(df)
    short_files = outcome_history.build_outcome_history(df[cut])
    assert np.array_equal(long_files[december].to_numpy(), short_files[december[cut]].to_numpy(), equal_nan=True)


def test_missing_decision_columns_are_skipped_not_fatal(capsys):
    """Without any decision column nothing is built; with the flag alone the builder still runs."""
    df = _table(seed=4, n_accounts=5)
    bare = df.drop(columns=[settings.REASON_COL, settings.DECLINE_FLAG_COL, settings.ADVICE_COL])
    assert outcome_history.build_outcome_history(bare).shape == (len(df), 0)
    assert capsys.readouterr().out.count("note:") == 4
    flag_only = df.drop(columns=[settings.REASON_COL, settings.ADVICE_COL, settings.TYPE_COL])
    got = outcome_history.build_outcome_history(flag_only, keys={"merchant": settings.MERCHANT_COL, "terminal": None})
    assert got.shape == (len(df), 20 + 9)
    assert got["outcome_n_other_decline_7d"].sum() > 0 and got["outcome_n_risk_decline_7d"].sum() == 0
    # A ready-made family array replaces the mapping from raw columns.
    ready = outcome_history.build_outcome_history(bare, family=outcome_history.outcome_family(df), fill=0.0)
    assert not ready.isna().any().any() and ready.shape[1] == 20 + 3 + 9 * 3


def test_the_command_line_runs_on_made_up_rows(capsys):
    """The tool prints one summary line per column."""
    frame = outcome_history.main(["--demo"])
    assert "outcome_prev_family" in capsys.readouterr().out and str(frame["outcome_prev_family"].dtype) == "int16"
