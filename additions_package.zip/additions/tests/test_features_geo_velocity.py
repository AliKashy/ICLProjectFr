"""Tests of the geographic velocity columns.

The tests give every made-up postal code a made-up centre, recompute distance and speed
the slow way with a second distance formula, and check the rules on small tables.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, timekeys
from additions.features import geo_velocity, lookback


def _table(seed=0, n_accounts=25, **kwargs):
    """Made-up rows, a centre for most postal codes, and a few rows without a postal code."""
    df = synthetic.make_transactions(n_accounts=n_accounts, seed=seed, **kwargs)
    rng = np.random.default_rng(seed)
    df[settings.MERCHANT_POSTAL_COL] = df[settings.MERCHANT_POSTAL_COL].astype(float)
    df.loc[rng.random(len(df)) < 0.05, settings.MERCHANT_POSTAL_COL] = np.nan
    postal = np.sort(df[settings.MERCHANT_POSTAL_COL].dropna().unique())[:-3]     # three codes have no centre
    centres = pd.DataFrame({"postal": postal.astype(int).astype(str), "lat": rng.uniform(30, 45, len(postal)),
                            "lon": rng.uniform(-120, -75, len(postal))})
    return df, centres


def _slow_km(lat1, lon1, lat2, lon2):
    """Distance by the spherical law of cosines: another formula for the same great circle."""
    a, b = np.radians([lat1, lat2])
    cosine = np.sin(a) * np.sin(b) + np.cos(a) * np.cos(b) * np.cos(np.radians(lon2 - lon1))
    return geo_velocity.EARTH_RADIUS_KM * np.arccos(np.clip(cosine, -1.0, 1.0))


def test_great_circle_distance_matches_known_distances():
    """A quarter of the equator, a real pair of cities, and a point against itself."""
    quarter = np.pi / 2 * geo_velocity.EARTH_RADIUS_KM
    assert np.isclose(geo_velocity.great_circle_km(0.0, 0.0, 0.0, 90.0), quarter)
    assert abs(geo_velocity.great_circle_km(51.5074, -0.1278, 48.8566, 2.3522) - 343.5) < 1.0   # London to Paris
    assert geo_velocity.great_circle_km(40.0, -100.0, 40.0, -100.0) == 0.0
    assert np.isnan(geo_velocity.great_circle_km(np.nan, 0.0, 0.0, 0.0))


def test_columns_equal_the_slow_definition():
    """Distance, gap and speed match a row-by-row search for the previous card-present row with a centre."""
    df, centres = _table(days=92, start="2024-10-01")
    got = geo_velocity.build_geo_velocity(df, centres=centres)
    account = timekeys.codes(df[settings.ACCOUNT_COL])
    secs = timekeys.seconds(df[settings.TIME_COL])
    start = lookback.lookback_start(secs)
    where = {int(p): (la, lo) for p, la, lo in centres.itertuples(index=False)}
    postal = df[settings.MERCHANT_POSTAL_COL].to_numpy()
    has_centre = np.array([(not np.isnan(p)) and int(p) in where for p in postal])
    located = has_centre & (df[settings.CARD_PRESENT_COL] == "Y").to_numpy()
    assert got.shape == (len(df), 4) and got.index.equals(df.index)
    assert 0.2 < got["geo_has_previous"].mean() < 0.6                            # about half the rows are card-present
    for i in range(0, len(df), 5):
        row = got.iloc[i]
        earlier = np.flatnonzero((account == account[i]) & (secs < secs[i]) & (secs >= start[i]) & located)
        if not located[i] or len(earlier) == 0:
            assert row["geo_has_previous"] == 0 and row[["geo_km", "geo_log_secs", "geo_kmh"]].isna().all()
            continue
        previous = earlier[secs[earlier] == secs[earlier].max()][-1]
        km = _slow_km(*where[int(postal[previous])], *where[int(postal[i])])
        gap = secs[i] - secs[previous]
        assert row["geo_has_previous"] == 1
        assert np.isclose(row["geo_km"], km, rtol=1e-4, atol=1e-2)
        assert np.isclose(row["geo_log_secs"], np.log1p(gap), rtol=1e-5)
        assert np.isclose(row["geo_kmh"], km / (max(gap, 60) / 3600), rtol=1e-4, atol=1e-2)
    values = got.to_numpy()
    assert np.isfinite(values[~np.isnan(values)]).all()


def test_the_gap_has_a_floor_and_same_second_rows_do_not_see_each_other():
    """Two purchases a second apart give the speed of a one-minute gap; two in one second give none."""
    centres = pd.DataFrame({"postal": ["A", "B"], "lat": [40.0, 40.0], "lon": [-100.0, -99.0]})
    df = pd.DataFrame({
        settings.ACCOUNT_COL: ["a"] * 5,
        settings.TIME_COL: pd.to_datetime(["2025-06-03 10:00:00", "2025-06-03 10:00:00", "2025-06-03 10:00:01",
                                           "2025-06-03 12:00:01", "2025-06-03 12:30:01"]),
        settings.MERCHANT_POSTAL_COL: ["A", "B", "B", "A", "B"],
        settings.CARD_PRESENT_COL: ["Y", "Y", "Y", "N", "Y"],
    })
    got = geo_velocity.build_geo_velocity(df, centres=centres)
    km = geo_velocity.great_circle_km(40.0, -100.0, 40.0, -99.0)
    assert got["geo_has_previous"].tolist() == [0, 0, 1, 0, 1]                   # the two rows at 10:00:00 see nothing
    assert got["geo_km"].iloc[2] == 0.0                                          # of two earlier rows, the last listed
    assert got["geo_kmh"].iloc[2] == 0.0
    # The card-not-present row has no place: it gets no value and is skipped as "the previous purchase".
    assert np.isnan(got["geo_km"].iloc[3]) and got["geo_km"].iloc[4] == 0.0
    assert np.isclose(got["geo_log_secs"].iloc[4], np.log1p(2 * 3600 + 30 * 60))
    one_second = df.iloc[[0, 2]]
    fast = geo_velocity.build_geo_velocity(one_second, centres=centres)
    assert np.isclose(fast["geo_kmh"].iloc[1], km * 60.0, rtol=1e-5)             # one minute, not one second


def test_later_rows_do_not_change_earlier_columns_and_long_files_equal_short_files():
    """Later rows change nothing before them, and a December row gets what files beginning on 1 November give."""
    df, centres = _table(seed=1, days=92, start="2024-10-01")
    secs = timekeys.seconds(df[settings.TIME_COL])
    full = geo_velocity.build_geo_velocity(df, centres=centres)
    keep = secs <= np.median(secs)
    assert np.array_equal(full[keep].to_numpy(), geo_velocity.build_geo_velocity(df[keep], centres=centres).to_numpy(),
                          equal_nan=True)
    december = secs >= lookback.data_start("2024-12-01")
    cut = secs >= lookback.data_start("2024-11-01")
    short_files = geo_velocity.build_geo_velocity(df[cut], centres=centres)
    assert np.array_equal(full[december].to_numpy(), short_files[december[cut]].to_numpy(), equal_nan=True)


def test_without_a_table_nothing_is_built_and_one_line_says_so(capsys):
    """The default loader returns no table: the builder prints one line and returns no columns."""
    df, centres = _table(seed=2, n_accounts=5)
    assert geo_velocity.load_postal_centres() is None
    assert geo_velocity.build_geo_velocity(df).shape == (len(df), 0)
    assert capsys.readouterr().out.count("note:") == 1
    no_postal = df.drop(columns=[settings.MERCHANT_POSTAL_COL])
    assert geo_velocity.build_geo_velocity(no_postal, centres=centres).shape[1] == 0
    assert capsys.readouterr().out.count("note:") == 1
    # Without the card-present column every row with a centre takes part, and one line says so.
    everyone = geo_velocity.build_geo_velocity(df.drop(columns=[settings.CARD_PRESENT_COL]), centres=centres, fill=0.0)
    some = geo_velocity.build_geo_velocity(df, centres=centres)
    assert capsys.readouterr().out.count("note:") == 1
    assert everyone["geo_has_previous"].sum() > some["geo_has_previous"].sum() and not everyone.isna().any().any()
    # A table whose keys match nothing gives empty columns and a hint.
    strangers = centres.assign(postal="none")
    assert geo_velocity.build_geo_velocity(df, centres=strangers)["geo_has_previous"].sum() == 0
    assert "postal_key" in capsys.readouterr().out


def test_the_command_line_runs_on_made_up_rows(capsys):
    """The demo invents centres, so the tool can be tried with no table."""
    frame = geo_velocity.main(["--demo"])
    assert "geo_kmh" in capsys.readouterr().out and frame.shape[1] == 4 and frame["geo_has_previous"].sum() > 0
