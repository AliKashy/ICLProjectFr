"""Tests of the blend ladder.

The blends are compared with a slow loop over the folds, the single models with a plain read
of their own score, and the out-of-fold rule is checked directly: changing the labels of one
account must leave the blended scores of that account exactly as they were.
"""
import numpy as np
import pandas as pd
import pytest
from sklearn.linear_model import LogisticRegression

from additions import settings
from additions.common import ranking, synthetic, tables
from additions.proof import _shared, blend_ladder

STANDARD = [settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL, settings.LABEL_COL, settings.AMOUNT_COL,
            settings.SCORE_COL]


@pytest.fixture(scope="module")
def june():
    """Made-up rows of the scored month with two scores that see the truth through their own noise, and one of pure noise."""
    df = synthetic.make_transactions(n_accounts=900, seed=31, fraud_account_share=0.1)
    df = df[_shared.ranked_rows(df)].reset_index(drop=True)
    first = synthetic.make_scores(df, seed=41, strength=2.0, column="s")["s"].to_numpy()
    second = synthetic.make_scores(df, seed=42, strength=2.0, column="s")["s"].to_numpy()
    noise = np.random.default_rng(43).random(len(df))
    return {"frame": df, "labels": _shared.fraud_flags(df), "amounts": df[settings.AMOUNT_COL].to_numpy(),
            "units": _shared.account_codes(df), "scores": {"first": first, "second": second, "noise": noise}}


@pytest.fixture(scope="module")
def result(june):
    """The ladder of the three made-up scores, with the two real ones as the reference."""
    return blend_ladder.blend_ladder(june["labels"], june["scores"], june["units"], june["amounts"],
                                     reference=("first", "second"), draws=200, seed=7)


def test_tables_have_one_line_per_set_and_member(result):
    """Three models make seven sets; every set of two or more has one 'adds' line per member."""
    ladder = result["ladder"]
    assert list(ladder["set"]) == ["first", "second", "noise", "first + second", "first + noise", "second + noise",
                                   "first + second + noise"]
    assert list(ladder["members"]) == [1, 1, 1, 2, 2, 2, 3]
    assert len(result["adds"]) == 3 * 2 + 3
    assert len(result["against_reference"]) == 6 + 1          # six other sets and the control line
    assert (ladder["caught_min"] <= ladder["caught"]).all() and (ladder["caught"] <= ladder["caught_max"]).all()
    assert result["reference"] == "first + second" and set(result["blends"]) == set(ladder["set"])
    for line in ladder.itertuples():
        members = line.set.split(" + ")
        for name in ("first", "second", "noise"):
            weight = getattr(line, f"weight_{name}")
            assert np.isfinite(weight) if name in members else np.isnan(weight)


def test_a_model_alone_keeps_the_capture_of_its_own_score(june, result):
    """A single model is not refitted: its line equals a plain read of its stored score."""
    for name, stored in june["scores"].items():
        plain = ranking.capture(june["labels"], stored, june["amounts"])
        line = result["ladder"].set_index("set").loc[name]
        assert line["caught"] == plain["caught"] and np.isclose(line["udr"], plain["udr"])
        assert np.isclose(line["vdr"], plain["vdr"]) and line[f"weight_{name}"] == 1.0


def test_blend_equals_a_slow_loop_over_the_folds(june):
    """With one shuffle, every fold's scores are the decision values of a fit on the other folds."""
    columns = blend_ladder.blend_columns(june["scores"])
    x = np.column_stack([columns["first"], columns["second"]])
    y = june["labels"] > 0
    blend, weights, bias = blend_ladder.out_of_fold_blend(june["labels"], x, june["units"], n_folds=4, repeats=1, seed=11)
    fold = _shared.account_folds(june["units"], 4, 11)
    slow, slow_weights = np.zeros(len(y)), []
    for k in range(4):                                        # a slow loop: the definition itself
        model = LogisticRegression(C=blend_ladder.BLEND_C, max_iter=1000).fit(x[fold != k], y[fold != k])
        slow[fold == k] = model.decision_function(x[fold == k])
        slow_weights.append(model.coef_[0])
    assert np.allclose(blend, slow) and np.allclose(weights, np.mean(slow_weights, axis=0))
    assert (weights > 0).all()                                # both scores carry signal of their own
    # Whole accounts stay in one fold, so no fit sees an account it is read on.
    assert (pd.Series(fold).groupby(june["units"]).nunique() == 1).all()


def test_an_account_never_shapes_its_own_blended_scores(june):
    """Flipping the labels of one account changes other accounts' blended scores, never its own."""
    columns = blend_ladder.blend_columns(june["scores"])
    x = np.column_stack([columns["first"], columns["second"]])
    fraud_accounts = np.unique(june["units"][june["labels"] > 0])
    mine = june["units"] == fraud_accounts[0]
    flipped = june["labels"].copy()
    flipped[mine] = 1.0 - flipped[mine]
    before, _, _ = blend_ladder.out_of_fold_blend(june["labels"], x, june["units"], n_folds=5, repeats=2, seed=3)
    after, _, _ = blend_ladder.out_of_fold_blend(flipped, x, june["units"], n_folds=5, repeats=2, seed=3)
    assert np.array_equal(before[mine], after[mine])
    assert not np.allclose(before[~mine], after[~mine])


def test_noise_adds_nothing_and_a_real_score_adds_something(result):
    """The leave-one-out line of the noise model sits on zero; the line of a real model is clear of it."""
    adds = result["adds"].set_index(["model", "added_to"])
    noise = adds.loc[("noise", "first + second")]
    assert abs(noise["gain"]) < 0.03 and noise["low"] <= 0.0 <= noise["high"]
    real = adds.loc[("second", "first + noise")]
    assert real["gain"] > 0.05 and real["low"] > 0.0
    # The same gain, read directly: capture with the model minus capture without it.
    ladder = result["ladder"].set_index("set")
    assert np.isclose(real["gain"], ladder.loc["first + second + noise", "udr"] - ladder.loc["first + noise", "udr"])
    assert np.isclose(real["udr"], ladder.loc["first + second + noise", "udr"])
    # Against the reference, the full set with the noise model is no better than the reference itself.
    against = result["against_reference"].set_index("set")
    assert against.loc["first + second + noise", "low"] <= 0.0 <= against.loc["first + second + noise", "high"]
    assert against.loc["first", "gain"] < 0.0


def test_both_forms_keep_the_order_of_every_model(june):
    """Rank log-odds and log-odds are both rising functions of the stored score, infinite values included."""
    stored = {"p": np.array([0.2, 0.9, 0.5, 0.5, 0.01]), "m": np.array([-np.inf, 3.0, 0.5, np.inf, -2.0])}
    for form, kinds in (("rank", None), ("logit", {"p": "probability", "m": "logit"})):
        columns = blend_ladder.blend_columns(stored, form, kinds)
        for name, values in stored.items():
            assert np.isfinite(columns[name]).all()
            order = np.argsort(values, kind="stable")
            assert (np.diff(columns[name][order]) >= 0).all()
    assert blend_ladder.blend_columns(stored, "rank")["p"][2] == blend_ladder.blend_columns(stored, "rank")["p"][3]
    with pytest.raises(ValueError):
        blend_ladder.blend_columns(stored, "something else")


def test_infinite_and_missing_scores_keep_their_place_in_the_ranking():
    """An infinite score stays strictly beyond every finite one; a missing one ranks last with minus infinity."""
    m = np.array([-np.inf, 3.0, 0.5, np.inf, -2.0, np.nan])
    for form in ("rank", "logit"):
        column = blend_ladder.blend_columns({"m": m}, form, {"m": "logit"})["m"]
        assert np.isfinite(column).all()
        assert column[3] > column[1] > column[2] > column[4] > column[0] == column[5]
        # A model alone reads exactly as its stored score does, ties at the cut included.
        stored = np.tile(m, 200)
        alone = blend_ladder.blend_columns({"m": stored}, form, {"m": "logit"})["m"]
        labels = np.tile([1.0, 0.0, 0.0, 1.0, 0.0, 1.0], 200)
        for per_mille in (100, 200, 300, 900):
            assert ranking.capture(labels, alone, per_mille=per_mille)["caught"] == \
                ranking.capture(labels, stored, per_mille=per_mille)["caught"]


def test_swap_table_adds_up(june, result):
    """The four fraud groups hold every fraud and every fraud dollar once; both alert lists have the same length."""
    swaps = result["swaps"].set_index("group")
    frauds = swaps.loc[[g for g in swaps.index if g.startswith("frauds")]]
    assert frauds["rows"].sum() == int(june["labels"].sum())
    assert np.isclose(frauds["dollars"].sum(), (june["amounts"] * june["labels"]).sum())
    first_only = swaps.loc["frauds only the first alerts", "rows"] + swaps.loc["non-frauds only the first alerts", "rows"]
    second_only = (swaps.loc["frauds only the second alerts", "rows"]
                   + swaps.loc["non-frauds only the second alerts", "rows"])
    assert first_only == second_only                          # the same number of rows moves in and out
    assert blend_ladder.swap_table(june["labels"], june["scores"]["first"], june["scores"]["second"])["dollars"].isna().all()


def test_a_fit_with_one_outcome_is_skipped_with_one_line(june, capsys):
    """When a fold's fit rows hold no fraud, nothing is fitted and one line says so."""
    no_fraud = np.zeros(len(june["labels"]))
    assert blend_ladder.blend_ladder(no_fraud, june["scores"], june["units"], draws=10) is None
    assert "only one outcome" in capsys.readouterr().out
    with pytest.raises(ValueError):
        blend_ladder.blend_ladder(june["labels"], {"only": june["scores"]["first"]}, june["units"])


def test_tool_runs_on_files_and_on_made_up_rows(june, tmp_path, capsys):
    """The tool reads three score files, prints the four tables and writes one blended column per set."""
    paths = []
    for name, stored in june["scores"].items():
        part = june["frame"][STANDARD[:-1]].copy()
        part[settings.SCORE_COL] = stored
        paths.append(str(tmp_path / f"{name}.parquet"))
        tables.write_table(part, paths[-1])
    out = str(tmp_path / "blends.parquet")
    blend_ladder.main(["--preds", *paths, "--names", "first", "second", "noise", "--reference", "first", "second",
                       "--draws", "50", "--repeats", "1", "--out", out])
    printed = capsys.readouterr().out
    assert "Ladder" in printed and "What each model adds" in printed and "Swaps at the cut" in printed
    written = pd.read_parquet(out)
    assert len(written) == len(june["frame"]) and written.shape[1] == 1 + 7
    assert "blend__first__second__noise" in written.columns
    blend_ladder.main(["--demo", "--draws", "30", "--repeats", "1", "--folds", "3"])
    assert "tree + other" in capsys.readouterr().out
    # Mistakes on the command line stop at once, before any fit.
    for wrong in (["--names", "first", "second"],                                   # one name short
                  ["--names", "first", "first", "noise"],                           # a name twice
                  ["--names", "first", "second", "noise", "--reference", "third"],  # an unknown reference
                  ["--form", "logit", "--kinds", "probability", "logit"],           # one kind short
                  ["--kinds", "probability", "probability", "probability"],         # kinds without --form logit
                  ["--apply-preds", *paths[:2]]):                                   # one file short
        with pytest.raises(SystemExit):
            blend_ladder.main(["--preds", *paths, *wrong])
    with pytest.raises(SystemExit):
        blend_ladder.main(["--demo", "--apply-preds", *paths])


def test_the_control_of_random_numbers_sits_on_zero(result):
    """The reference plus a column that knows nothing gains nothing: its interval holds zero."""
    against = result["against_reference"].set_index("set")
    control = against.loc["first + second" + blend_ladder.SEPARATOR + blend_ladder.CONTROL_NAME]
    assert abs(control["gain"]) < 0.03 and control["low"] <= 0.0 <= control["high"]
    assert control["reference"] == "first + second"


def test_frozen_weights_are_one_fit_on_all_rows_and_apply_without_refitting(june, tmp_path, capsys):
    """The frozen weights equal a plain fit on every row, and applying them is the weighted sum it defines."""
    stored = {"first": june["scores"]["first"], "second": june["scores"]["second"]}
    kinds = {"first": "probability", "second": "probability"}
    weights = blend_ladder.frozen_weights(june["labels"], stored, "logit", kinds)
    assert list(weights["set"]) == ["first + second"]
    columns = blend_ladder.blend_columns(stored, "logit", kinds)
    x = np.column_stack([columns["first"], columns["second"]])
    plain = LogisticRegression(C=blend_ladder.BLEND_C, max_iter=1000).fit(x, june["labels"] > 0)
    line = weights.iloc[0]
    assert np.allclose([line["weight_first"], line["weight_second"]], plain.coef_[0]) and np.isclose(line["bias"], plain.intercept_[0])
    applied = blend_ladder.apply_frozen(stored, weights, "logit", kinds)["first + second"]
    assert np.allclose(applied, plain.decision_function(x))
    # New rows never change the weights they are read with: half of the rows give the same numbers.
    half = np.arange(len(x)) % 2 == 0
    part = blend_ladder.apply_frozen({name: values[half] for name, values in stored.items()}, weights, "logit", kinds)
    assert np.allclose(part["first + second"], applied[half])

    # The tool: fit on one group of files, apply to a second group, write one score file per set.
    paths = []
    for name, values in stored.items():
        table = june["frame"][STANDARD[:-1]].copy()
        table[settings.SCORE_COL] = values
        paths.append(str(tmp_path / f"{name}.parquet"))
        tables.write_table(table, paths[-1])
    out_dir = tmp_path / "frozen"
    blend_ladder.main(["--preds", *paths, "--names", "first", "second", "--form", "logit", "--kinds", "probability",
                       "probability", "--draws", "30", "--repeats", "1", "--apply-preds", *paths,
                       "--apply-out", str(out_dir)])
    assert "Frozen weights" in capsys.readouterr().out
    written = pd.read_parquet(out_dir / "blend__first__second.parquet")
    assert len(written) == len(june["frame"]) and settings.LABEL_COL in written.columns
    assert np.allclose(written[settings.SCORE_COL].to_numpy(), applied)
    # The written file is a score file like any other: the comparison tools can read it back.
    frame, read, _ = _shared.common_rows([str(out_dir / "blend__first__second.parquet"), paths[0]], ["blend", "first"])
    assert len(frame) == len(june["frame"]) and set(read) == {"blend", "first"}

