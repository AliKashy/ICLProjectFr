"""Tests of the learned attention bias (additions/model/attention_bias.py).

The bias must equal a slow pair-by-pair computation, follow the strict time rule, start as a
no-op, receive gradients, and reach the attention logits in scoring exactly as in training.
"""
import math

import numpy as np
import torch

from additions import settings
from additions.common import synthetic
from additions.model import masks
from additions.model._shared import layout, sequences_from_table
from additions.model.attention_bias import GAP_EDGES, AttentionBias, match_values
from additions.model.history_stage import HistoryStage

HEADS, WIDTH = 4, 16


def _batch(n_accounts=12, seed=0):
    """A small batch from made-up rows, with the match codes laid out like the batch."""
    df = synthetic.make_transactions(n_accounts, days=8, seed=seed, tie_share=0.25)
    batch, row_index, _ = sequences_from_table(df, seconds_per_sequence=8)
    values, names = match_values(df)
    return df, batch, row_index, layout(values, row_index, fill=-1), names


def _randomised(block, seed=0):
    """The same block with every weight set to a random number, so that every part shows."""
    g = torch.Generator().manual_seed(seed)
    with torch.no_grad():
        for p in block.parameters():
            p.copy_(torch.randn(p.shape, generator=g))
    return block


def _slow_bias(block, values, times, valid):
    """The bias computed pair by pair with plain Python loops, straight from the definition."""
    B, T, F = values.shape
    H = block.same_weight.shape[0]
    edges = list(GAP_EDGES)
    out = torch.zeros(B, H, T, T, dtype=torch.float64)
    sw, cw, gw, iw = (p.detach().double() for p in (block.same_weight, block.count_weight, block.gap_weight,
                                                     block.self_weight))
    for b in range(B):
        def may_read(i, k):
            return bool(valid[b, i] and valid[b, k] and times[b, k] < times[b, i])
        for i in range(T):
            for j in range(T):
                if i == j:
                    out[b, :, i, j] = iw
                    continue
                gap = max(int(times[b, i] - times[b, j]), 0)
                bucket = sum(1 for e in edges if gap >= e)
                total = gw[:, bucket].clone()
                for f in range(F):
                    vj = int(values[b, j, f])
                    same = float(vj >= 0 and int(values[b, i, f]) == vj)
                    count = sum(1 for k in range(T) if may_read(i, k) and int(values[b, k, f]) == vj and vj >= 0)
                    total += sw[:, f] * same + cw[:, f] * math.log1p(count)
                out[b, :, i, j] = total
    return out


def test_match_values_codes_equal_values_alike_and_missing_values_never_match():
    """Equal merchants share a code, a missing merchant gets -1, and absent optional fields are left out."""
    df = synthetic.make_transactions(5, days=5, seed=1)
    df.loc[df.index[:3], settings.MERCHANT_COL] = None
    values, names = match_values(df)
    assert values.shape == (len(df), len(names)) and values.dtype == np.int64
    m = values[:, names.index("merchant")]
    assert np.all(m[:3] == -1)
    raw = df[settings.MERCHANT_COL].to_numpy()
    for a in range(3, 30):
        for b in range(3, 30):
            assert (m[a] == m[b]) == (raw[a] == raw[b])
    hours = values[:, names.index("hour_of_week")]
    assert hours.min() >= 0 and hours.max() < 168
    # Optional identity columns that are None in settings are skipped with a printed line, not an error.
    assert "card" not in names or settings.CARD_COL is not None


def test_the_bias_equals_a_slow_pair_by_pair_computation():
    """Every entry of the bias equals the definition computed with plain loops."""
    _, batch, _, values, _ = _batch(n_accounts=4, seed=2)
    values, times, valid = values[:3, :9], batch["time_seq"][:3, :9], batch["mask"][:3, :9]
    block = _randomised(AttentionBias(values.shape[-1], num_heads=HEADS))
    fast = block(values, times, valid).double()
    slow = _slow_bias(block, values, times, valid)
    allowed = masks.strict_visibility(times, valid).unsqueeze(1).expand_as(fast)
    # Only pairs that may read each other matter; the mask closes the others whatever the bias says.
    assert torch.allclose(fast[allowed], slow[allowed], atol=1e-6)


def test_later_rows_do_not_change_the_bias_of_earlier_rows():
    """Changing the values and times of the last second leaves the bias of every earlier row unchanged."""
    _, batch, _, values, _ = _batch(seed=3)
    times, valid = batch["time_seq"], batch["mask"]
    block = _randomised(AttentionBias(values.shape[-1], num_heads=HEADS), seed=1)
    before = block(values, times, valid)
    allowed = masks.strict_visibility(times, valid)
    for b in range(values.shape[0]):
        n = int(valid[b].sum())
        last = times[b, n - 1]
        later = (times[b] == last) & valid[b]
        if later.all() or not later.any():
            continue
        changed = values.clone()
        changed[b, later] = torch.randint(0, 3, changed[b, later].shape)        # new merchants, many matches
        after = block(changed, times, valid)
        keep = ~later
        rows = allowed[b][keep][:, keep]
        lhs = before[b][:, keep][:, :, keep]
        rhs = after[b][:, keep][:, :, keep]
        assert torch.allclose(lhs[:, rows], rhs[:, rows], atol=1e-6)


def test_rows_of_one_second_do_not_count_each_other():
    """Two rows of one second at one merchant: the later row's count holds only strictly earlier rows."""
    values = torch.tensor([[[5], [5], [5], [5]]])
    times = torch.tensor([[10, 20, 20, 30]])
    valid = torch.ones(1, 4, dtype=torch.bool)
    block = AttentionBias(1, num_heads=1, gap_edges=(1_000,))
    with torch.no_grad():
        block.count_weight.fill_(1.0)
    bias = block(values, times, valid)[0, 0].detach()
    # Row 1 (second 20) may read row 0 only: one row with merchant 5, not two.
    assert math.isclose(float(bias[1, 0]), math.log1p(1), rel_tol=1e-6)
    assert math.isclose(float(bias[2, 0]), math.log1p(1), rel_tol=1e-6)
    # Row 3 may read rows 0, 1 and 2.
    assert math.isclose(float(bias[3, 1]), math.log1p(3), rel_tol=1e-6)


def test_a_new_block_is_zero_and_leaves_stage_two_unchanged():
    """With every weight at zero the bias is zero and stage 2 gives exactly its output without a bias."""
    _, batch, _, values, _ = _batch(seed=4)
    times, valid = batch["time_seq"], batch["mask"]
    block = AttentionBias(values.shape[-1], num_heads=HEADS)
    bias = block(values, times, valid)
    assert bias.shape == (values.shape[0], HEADS, values.shape[1], values.shape[1])
    assert torch.all(bias == 0)
    torch.manual_seed(0)
    stage2 = HistoryStage(in_dim=WIDTH, num_heads=HEADS, num_blocks=2, history_len=8, dropout=0.0, attn_dropout=0.0)
    x = torch.randn(values.shape[0], values.shape[1], WIDTH)
    # Equal up to the last bit of float32 rounding: adding a tensor of zeros to the mask changes no value,
    # only the order in which the attention kernel happens to sum.
    assert torch.allclose(stage2(x, times, valid), stage2(x, times, valid, bias=bias), atol=1e-6, rtol=0)


def test_gradients_reach_every_weight_of_the_bias():
    """A loss on stage 2 gives every weight of the bias a finite, non-zero gradient from a zero start."""
    _, batch, _, values, _ = _batch(seed=5)
    times, valid = batch["time_seq"], batch["mask"]
    block = AttentionBias(values.shape[-1], num_heads=HEADS)
    torch.manual_seed(0)
    stage2 = HistoryStage(in_dim=WIDTH, num_heads=HEADS, num_blocks=1, history_len=8, dropout=0.0, attn_dropout=0.0)
    x = torch.randn(values.shape[0], values.shape[1], WIDTH)
    out = stage2(x, times, valid, bias=block(values, times, valid))
    assert torch.isfinite(out).all()
    (out[valid] * torch.randn(out[valid].shape)).sum().backward()
    for name, p in block.named_parameters():
        assert p.grad is not None and torch.isfinite(p.grad).all(), name
        assert p.grad.abs().sum() > 0, name


def test_the_bias_reaches_the_logits_in_scoring_exactly_as_in_training():
    """Under torch.no_grad() in evaluation mode the biased stage 2 equals the training-mode result."""
    _, batch, _, values, _ = _batch(seed=6)
    times, valid = batch["time_seq"], batch["mask"]
    block = _randomised(AttentionBias(values.shape[-1], num_heads=HEADS), seed=2)
    torch.manual_seed(0)
    stage2 = HistoryStage(in_dim=WIDTH, num_heads=HEADS, num_blocks=2, history_len=8, dropout=0.0, attn_dropout=0.0)
    x = torch.randn(values.shape[0], values.shape[1], WIDTH)
    stage2.train()
    trained = stage2(x, times, valid, bias=block(values, times, valid))
    stage2.eval()
    block.eval()
    with torch.no_grad():
        scored = stage2(x, times, valid, bias=block(values, times, valid))
        plain = stage2(x, times, valid)
    assert torch.allclose(trained[valid], scored[valid], atol=1e-5)
    # The bias changes the result of rows that read history, so the equality is not trivial.
    assert not torch.allclose(scored[valid], plain[valid], atol=1e-4)


def test_an_absent_field_is_skipped_with_one_line(capsys):
    """A match field whose column is not in the table is left out and named in one printed line."""
    df = synthetic.make_transactions(3, days=3, seed=7).drop(columns=[settings.MCC_COL])
    values, names = match_values(df, fields={"merchant": settings.MERCHANT_COL, "mcc": settings.MCC_COL})
    assert names[0] == "merchant" and "mcc" not in names
    assert "mcc" in capsys.readouterr().out
    assert values.shape == (len(df), len(names)) and names == ["merchant", "amount_band", "hour_of_week"]


def test_a_unit_written_as_a_float_puts_every_gap_in_its_bucket():
    """Two rows of 2026 in nanoseconds, 61, 127, 129 and 599 seconds apart: with the unit 10**9 or the float 1e9 every
    gap falls in the bucket of one to ten minutes, and the unit is kept as the int 10**9. A division in 32-bit floats
    (the first version with a float unit) moved such gaps into the buckets of under a minute or of an hour."""
    start = 1_795_000_000 * 10 ** 9 + 123_456_789                      # a time of 2026, with nanoseconds
    valid = torch.ones(1, 2, dtype=torch.bool)
    no_codes = torch.zeros(1, 2, 0, dtype=torch.long)
    for unit in (10 ** 9, 1e9):
        block = AttentionBias(0, num_heads=1, units_per_second=unit)
        assert block.units_per_second == 10 ** 9 and type(block.units_per_second) is int
        with torch.no_grad():
            block.gap_weight.copy_(torch.arange(len(GAP_EDGES) + 1, dtype=torch.float32).unsqueeze(0))
            for gap in (61, 127, 129, 599):
                times = torch.tensor([[start, start + gap * 10 ** 9 + 7]])
                bias = block(no_codes, times, valid)[0, 0]
                assert int(bias[1, 0]) == 1, (unit, gap)               # bucket 1: from one minute to ten minutes
    # What the bucket of each gap would be after a division in 32-bit floats: not all of them in bucket 1.
    edges = torch.tensor(GAP_EDGES)
    floats = [torch.div(torch.tensor([start, start + gap * 10 ** 9 + 7]), 1e9, rounding_mode="floor")
              for gap in (61, 127, 129, 599)]
    old = [int(torch.bucketize((s[1] - s[0]).long(), edges, right=True)) for s in floats]
    assert old != [1, 1, 1, 1]


def test_the_how_often_count_with_float_times_counts_whole_seconds():
    """Float times 100.2, 100.7 and 101.5 with one merchant: the row of second 101 counts both rows of second 100,
    and the two rows of second 100 count neither each other nor anything else (the first version counted 100.2 for
    100.7)."""
    values = torch.tensor([[[5], [5], [5]]])
    times = torch.tensor([[100.2, 100.7, 101.5]], dtype=torch.float64)
    valid = torch.ones(1, 3, dtype=torch.bool)
    block = AttentionBias(1, num_heads=1, gap_edges=(1_000,), units_per_second=1)
    with torch.no_grad():
        block.count_weight.fill_(1.0)
        bias = block(values, times, valid)[0, 0]
    assert math.isclose(float(bias[2, 0]), math.log1p(2), rel_tol=1e-6)
    allowed = masks.strict_visibility(times, valid)[0]
    assert not allowed[1, 0] and allowed[2, 0] and allowed[2, 1]
