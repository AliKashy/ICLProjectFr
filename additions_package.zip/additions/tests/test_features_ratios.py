"""Tests of the ratio columns.

The tests recompute the ratios the slow way, check that a zero or missing denominator gives
a missing value and never a large number, and check the mid-rank against a direct count.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, timekeys
from additions.common.history import EarlierRows
from additions.features import lookback, ratios

DAY = 86_400


def _table(seed=0, n_accounts=30, **kwargs):
    """Made-up rows with some missing amounts, empty balances and amounts that repeat exactly."""
    df = synthetic.make_transactions(n_accounts=n_accounts, seed=seed, **kwargs)
    rng = np.random.default_rng(seed)
    df[settings.AMOUNT_COL] = np.round(df[settings.AMOUNT_COL])                  # whole dollars: equal amounts occur
    df.loc[rng.random(len(df)) < 0.03, settings.AMOUNT_COL] = np.nan
    df.loc[rng.random(len(df)) < 0.03, settings.BALANCE_COL] = 0.0
    df.loc[rng.random(len(df)) < 0.03, settings.BALANCE_COL] = np.nan
    df.loc[rng.random(len(df)) < 0.03, settings.CASH_LIMIT_COL] = 0.0
    return df


def _same(a, b):
    return bool(np.isclose(a, b, rtol=1e-5, atol=1e-5, equal_nan=True))


def _over(top, bottom):
    """The slow, obvious guarded division."""
    return top / bottom if bottom > 0 and not np.isnan(top) else np.nan


def test_columns_equal_the_slow_definition():
    """Every ratio matches a row-by-row recomputation from the strictly earlier rows of the look-back."""
    df = _table(days=92, start="2024-10-01")
    got = ratios.build_ratios(df)
    account = timekeys.codes(df[settings.ACCOUNT_COL])
    secs = timekeys.seconds(df[settings.TIME_COL])
    start = lookback.lookback_start(secs)
    amount = df[settings.AMOUNT_COL].to_numpy()
    balance = df[settings.BALANCE_COL].to_numpy()
    assert got.shape == (len(df), 9) and got.index.equals(df.index)
    for i in range(0, len(df), 5):
        row = got.iloc[i]
        earlier = (account == account[i]) & (secs < secs[i]) & (secs >= start[i])
        day = earlier & (secs >= secs[i] - DAY)
        month = amount[earlier & (secs >= secs[i] - 30 * DAY)]
        month = month[~np.isnan(month)]
        assert _same(row["ratio_amount_to_balance"], _over(amount[i], balance[i]))
        assert _same(row["ratio_amount_to_merch_limit"], _over(amount[i], df[settings.MERCH_LIMIT_COL].iloc[i]))
        assert _same(row["ratio_amount_to_cash_limit"], _over(amount[i], df[settings.CASH_LIMIT_COL].iloc[i]))
        assert _same(row["ratio_spent_24h_to_balance"], _over(np.nansum(amount[day]) + amount[i], balance[i]))
        assert row["ratio_n_amounts_30d"] == len(month)
        assert _same(row["ratio_amount_to_mean_30d"], _over(amount[i], month.mean()) if len(month) else np.nan)
        assert _same(row["ratio_amount_to_max_30d"], _over(amount[i], month.max()) if len(month) else np.nan)
        rank = ((month < amount[i]).sum() + 0.5 * (month == amount[i]).sum()) / len(month) if len(month) else np.nan
        assert _same(row["ratio_amount_midrank_30d"], rank if not np.isnan(amount[i]) else np.nan)


def test_a_bad_denominator_gives_a_missing_value_never_a_large_number():
    """Zero, negative and missing balances and limits give missing ratios; nothing is infinite."""
    df = _table(seed=1)
    got = ratios.build_ratios(df)
    values = got.drop(columns=["ratio_headroom_code"]).to_numpy()
    assert np.isfinite(values[~np.isnan(values)]).all()
    empty = (df[settings.BALANCE_COL] <= 0) | df[settings.BALANCE_COL].isna()
    over_balance = ["ratio_amount_to_balance", "ratio_spent_24h_to_balance"]
    assert empty.sum() > 20 and got.loc[empty, over_balance].isna().all().all()
    assert got.loc[df[settings.CASH_LIMIT_COL] == 0, "ratio_amount_to_cash_limit"].isna().all()
    assert got.loc[~empty & df[settings.AMOUNT_COL].notna(), "ratio_amount_to_balance"].notna().all()


def test_headroom_codes_name_each_case():
    """Each case of the headroom code is reached by the amount and balance that define it."""
    amount = np.array([10.0, 50.0, 89.99, 90.0, 99.99, 100.0, 100.01, 5.0, 0.0, 0.0, np.nan, 5.0, 0.1 + 0.2])
    balance = np.array([100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 0.0, 0.0, 100.0, 100.0, np.nan, 0.3])
    names = [ratios.HEADROOM[c] for c in ratios.headroom_code(amount, balance)]
    assert names == ["under_50_percent", "50_to_90_percent", "50_to_90_percent", "90_percent_or_more",
                     "90_percent_or_more", "exact_drain", "overdraw", "overdraw", "under_50_percent",
                     "under_50_percent", "unknown", "unknown", "exact_drain"]


def test_midrank_equals_a_direct_count_whatever_the_chunk_size():
    """The chunked pair comparison gives the same rank as counting smaller and equal earlier values."""
    rng = np.random.default_rng(2)
    n = 1200
    keys = rng.integers(0, 12, n)
    secs = rng.integers(1_700_000_000, 1_700_000_000 + 20 * DAY, n).astype(np.int64)
    secs[rng.random(n) < 0.1] = secs[0]                                         # several rows share a second
    values = np.round(rng.normal(size=n), 1)
    values[rng.random(n) < 0.05] = np.nan
    engine = EarlierRows(keys, secs)
    for window, cap in ((None, 10_000), (5 * DAY, 10_000), (None, 7)):
        got = ratios.midrank_among_earlier(engine, values, window, max_history=cap, pairs_per_chunk=997)
        assert np.allclose(got, ratios.midrank_among_earlier(engine, values, window, max_history=cap), equal_nan=True)
        for i in range(0, n, 9):
            earlier = np.flatnonzero((keys == keys[i]) & (secs < secs[i]) & (secs >= secs[i] - (window or 10 ** 9)))
            earlier = earlier[np.argsort(secs[earlier], kind="stable")][-cap:]    # the latest `cap` earlier rows
            seen = values[earlier][~np.isnan(values[earlier])]
            slow = ((seen < values[i]).sum() + 0.5 * (seen == values[i]).sum()) / len(seen) if len(seen) else np.nan
            assert _same(got[i], slow if not np.isnan(values[i]) else np.nan)


def test_rows_of_the_same_second_do_not_see_each_other():
    """Two purchases in one second: neither counts the other as money already spent."""
    df = pd.DataFrame({
        settings.ACCOUNT_COL: ["a", "a", "a"],
        settings.TIME_COL: pd.to_datetime(["2025-06-03 10:00:00", "2025-06-03 10:00:00", "2025-06-03 10:00:01"]),
        settings.AMOUNT_COL: [40.0, 60.0, 50.0],
        settings.BALANCE_COL: [200.0, 200.0, 200.0],
    })
    got = ratios.build_ratios(df)
    assert np.allclose(got["ratio_spent_24h_to_balance"], [0.2, 0.3, 0.75])
    assert got["ratio_n_amounts_30d"].tolist() == [0, 0, 2]
    assert got["ratio_amount_midrank_30d"].iloc[2] == 0.5 and got["ratio_amount_midrank_30d"].iloc[:2].isna().all()
    assert list(got.columns) == ["ratio_amount_to_balance", "ratio_headroom_code", "ratio_spent_24h_to_balance",
                                 "ratio_n_amounts_30d", "ratio_amount_to_mean_30d", "ratio_amount_to_max_30d",
                                 "ratio_amount_midrank_30d"]                     # the two limit columns were not there


def test_later_rows_do_not_change_earlier_columns():
    """Dropping every row after the middle of the period leaves the columns of the rows before it unchanged."""
    df = _table(seed=3)
    secs = timekeys.seconds(df[settings.TIME_COL])
    keep = secs <= np.median(secs)
    full, part = ratios.build_ratios(df), ratios.build_ratios(df[keep])
    assert np.array_equal(full[keep].to_numpy(), part.to_numpy(), equal_nan=True)


def test_training_rows_get_what_scored_rows_get():
    """A December row in long files gets the columns it would get in files that begin on 1 November."""
    df = _table(seed=4, n_accounts=20, days=92, start="2024-10-01")
    secs = timekeys.seconds(df[settings.TIME_COL])
    december = secs >= lookback.data_start("2024-12-01")
    cut = secs >= lookback.data_start("2024-11-01")
    long_files, short_files = ratios.build_ratios(df), ratios.build_ratios(df[cut])
    assert np.allclose(long_files[december].to_numpy(), short_files[december[cut]].to_numpy(), equal_nan=True)


def test_options_and_missing_columns(capsys, monkeypatch):
    """Rows can be left out of the money spent, the balance can be stored after the row, columns can be absent."""
    df = _table(seed=5, n_accounts=8)
    approved = (df[settings.REASON_COL] == settings.APPROVED_REASONS[0]).to_numpy()
    fewer = ratios.build_ratios(df, spent_rows=approved)["ratio_spent_24h_to_balance"]
    everything = ratios.build_ratios(df)["ratio_spent_24h_to_balance"]
    assert (fewer.fillna(0) <= everything.fillna(0) + 1e-6).all() and (fewer.fillna(0) < everything.fillna(0)).any()
    before = ratios.build_ratios(df)["ratio_amount_to_balance"]
    monkeypatch.setattr(ratios, "BALANCE_IS_BEFORE_THE_ROW", False)
    after = ratios.build_ratios(df)["ratio_amount_to_balance"]
    both = before.notna() & (df[settings.AMOUNT_COL] > 0)
    assert (after.dropna() <= 1.0).all() and (after[both] < before[both]).all()   # amount over (balance + amount)
    capsys.readouterr()
    assert ratios.build_ratios(df.drop(columns=[settings.AMOUNT_COL])).shape == (len(df), 0)
    assert ratios.build_ratios(df.drop(columns=[settings.BALANCE_COL]), fill=0.0).shape == (len(df), 6)
    assert capsys.readouterr().out.count("note:") == 2


def test_the_command_line_runs_on_made_up_rows(capsys):
    """The tool prints one summary line per column."""
    frame = ratios.main(["--demo"])
    assert "ratio_amount_midrank_30d" in capsys.readouterr().out and frame.shape[1] == 9
