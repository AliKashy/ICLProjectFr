"""Tests of the head-to-head comparison.

Every table is compared with a slow, plain count on a small made-up table: the alert cut by
sorting, the tie bounds by trying many tie orders, the discordant frauds by set arithmetic,
and each sensitivity read by running the comparison on the chosen rows directly.
"""
import numpy as np
import pandas as pd
import pytest
from scipy import stats

from additions import settings
from additions.common import ranking, synthetic, tables
from additions.common.bootstrap import paired_bootstrap
from additions.proof import _shared, head_to_head

STANDARD = [settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL, settings.LABEL_COL, settings.AMOUNT_COL,
            settings.SCORE_COL]


@pytest.fixture(scope="module")
def table():
    """Made-up rows with two scores: a strong one in the score column and a weaker one beside it."""
    df = synthetic.make_transactions(n_accounts=600, seed=21, fraud_account_share=0.1, tie_share=0.08)
    df = synthetic.make_scores(df, seed=21, strength=2.5)
    return synthetic.make_scores(df, seed=22, strength=1.5, column="weak")


@pytest.fixture(scope="module")
def june(table):
    """The rows of the scored month with their labels, amounts, accounts and the two scores."""
    part = table[_shared.ranked_rows(table)].reset_index(drop=True)
    return {"frame": part, "labels": _shared.fraud_flags(part), "amounts": part[settings.AMOUNT_COL].to_numpy(),
            "units": _shared.account_codes(part),
            "scores": {"strong": part[settings.SCORE_COL].to_numpy(), "weak": part["weak"].to_numpy()}}


def test_capture_lines_match_a_plain_sort_at_every_budget(june):
    """Alerts follow floor and ceiling of the budget, and the caught frauds equal a count over the sorted rows."""
    lines = head_to_head.capture_lines(june["labels"], june["scores"], june["amounts"])
    n = len(june["labels"])
    assert len(lines) == 2 * 3 * 2 and set(lines["percent"]) == {0.6, 1.0, 5.0}
    for line in lines.itertuples():
        exact = n * int(round(line.percent * 10))
        k = exact // 1000 if line.rounding == "floor" else -(-exact // 1000)
        top = np.argsort(-june["scores"][line.model], kind="stable")[:k]
        assert line.alerts == k and line.tied_rows == 1
        assert np.isclose(line.caught, june["labels"][top].sum()) and line.caught_min == line.caught == line.caught_max
        assert np.isclose(line.udr, june["labels"][top].sum() / june["labels"].sum())
        fraud_dollars = june["amounts"] * june["labels"]
        assert np.isclose(line.vdr, fraud_dollars[top].sum() / fraud_dollars.sum())
        assert np.isclose(line.false_per_true, (k - line.caught) / line.caught)
    wide = lines.pivot_table(index=["model", "percent"], columns="rounding", values="alerts")
    assert ((wide["ceil"] - wide["floor"]).isin([0, 1])).all() and (wide["ceil"] > wide["floor"]).any()
    assert head_to_head.capture_lines(june["labels"], june["scores"])["vdr"].isna().all()      # no amounts, no VDR


def test_tie_bounds_hold_for_every_tie_order(june):
    """With coarse scores, any order of the tied rows gives a count between the two bounds, and the credit is their mean."""
    coarse = {"coarse": np.round(ranking.to_logit(june["scores"]["strong"]))}       # whole log-odds: many ties
    line = head_to_head.capture_lines(june["labels"], coarse, per_milles=(6,), roundings=("floor",)).iloc[0]
    assert line["tied_rows"] > 20 and line["caught_min"] < line["caught"] < line["caught_max"]
    rng = np.random.default_rng(0)
    counts = []
    for _ in range(400):
        jitter = coarse["coarse"] + rng.uniform(0.0, 1e-6, len(june["labels"]))         # a random order inside each tie
        counts.append(june["labels"][np.argsort(-jitter)[: int(line["alerts"])]].sum())
    assert line["caught_min"] <= min(counts) and max(counts) <= line["caught_max"]
    assert abs(np.mean(counts) - line["caught"]) < 0.5
    chance = head_to_head.alert_chance(coarse["coarse"])
    assert np.isclose(chance.sum(), line["alerts"]) and len(np.unique(chance)) == 3
    assert np.isclose(chance[june["labels"] > 0].sum(), line["caught"])
    sharp = head_to_head.alert_chance(june["scores"]["strong"])
    assert np.array_equal(sharp > 0, ranking.alert_mask(june["scores"]["strong"])) and set(np.unique(sharp)) == {0.0, 1.0}


def test_discordant_frauds_are_plain_set_differences(june):
    """Frauds caught by one model only equal the difference of the two caught sets, and the test is the binomial tail."""
    fraud = np.flatnonzero(june["labels"] > 0)
    k = ranking.cut_size(len(june["labels"]))
    caught = {name: set(np.argsort(-s, kind="stable")[:k]) & set(fraud) for name, s in june["scores"].items()}
    d = head_to_head.discordant(june["labels"], june["scores"]["strong"], june["scores"]["weak"])
    assert d["only_a"] == len(caught["strong"] - caught["weak"]) and d["only_b"] == len(caught["weak"] - caught["strong"])
    assert d["both"] == len(caught["strong"] & caught["weak"])
    assert d["both"] + d["only_a"] + d["only_b"] + d["neither"] == len(fraud)
    assert np.isclose(d["p_value"], stats.binomtest(d["only_a"], d["only_a"] + d["only_b"], 0.5).pvalue)
    assert np.isclose(d["only_a_expected"], d["only_a"]) and np.isclose(d["only_b_expected"], d["only_b"])
    assert d["only_a"] > d["only_b"] and d["p_value"] < 0.05                 # the strong score wins clearly
    same = head_to_head.discordant(june["labels"], june["scores"]["weak"], june["scores"]["weak"])
    assert same["only_a"] == same["only_b"] == 0 and same["p_value"] == 1.0


def test_pair_reads_use_the_paired_account_bootstrap(june):
    """The gain of a pair is the difference of the two captures, and a model against itself gains nothing."""
    scores = dict(june["scores"], copy=june["scores"]["strong"].copy())
    pairs = head_to_head.pair_reads(june["units"], june["labels"], scores, june["amounts"], draws=60, seed=3)
    assert [(p.first, p.second) for p in pairs.itertuples()] == [("strong", "weak"), ("strong", "copy"), ("weak", "copy")]
    udr = {name: ranking.capture(june["labels"], s)["udr"] for name, s in scores.items()}
    for p in pairs.itertuples():
        assert np.isclose(p.gain, udr[p.first] - udr[p.second]) and p.low <= p.gain <= p.high
        direct = paired_bootstrap(june["units"], june["labels"], scores[p.first], scores[p.second], draws=60, seed=3)
        assert np.isclose(p.low, direct["low"]) and np.isclose(p.high, direct["high"])
    first = pairs.iloc[0]
    assert first["low"] > 0 and first["share_above_zero"] == 1.0
    vdr = {name: ranking.capture(june["labels"], s, june["amounts"])["vdr"] for name, s in scores.items()}
    assert np.isclose(first["vdr_gain"], vdr["strong"] - vdr["weak"]) and first["vdr_low"] <= first["vdr_gain"] <= first["vdr_high"]
    twin = pairs.iloc[1]
    assert twin["gain"] == 0 and twin["low"] == 0 and twin["high"] == 0 and twin["only_a"] == twin["only_b"] == 0
    assert pairs.iloc[2]["gain"] < 0
    no_dollars = head_to_head.pair_reads(june["units"], june["labels"], june["scores"], draws=20)
    assert no_dollars["vdr_gain"].isna().all() and np.isclose(no_dollars["gain"].iloc[0], first["gain"])


def test_sensitivity_reads_rank_only_their_own_rows(table, june, capsys):
    """Each preset read equals the comparison run directly on its rows, with the cut found again on them."""
    frame = june["frame"]
    approved = _shared.approved_rows(table)[_shared.ranked_rows(table)]
    shared = head_to_head.same_second_rows(table)[_shared.ranked_rows(table)]
    masks = head_to_head.sensitivity_masks(frame, approved, shared)
    stamps = pd.to_datetime(frame[settings.TIME_COL])
    late = pd.Timestamp(settings.TARGET_START) + pd.Timedelta(days=head_to_head.LATE_ROWS_AFTER_DAYS)
    assert list(masks) == ["all ranked rows", "approved rows only", "without same-second rows", f"rows from {late.date()} on"]
    assert masks["all ranked rows"].all() and np.array_equal(masks[f"rows from {late.date()} on"], (stamps >= late).to_numpy())
    slow_approved = frame[settings.REASON_COL].isin(settings.APPROVED_REASONS) & (frame[settings.DECLINE_FLAG_COL] != 1)
    assert np.array_equal(masks["approved rows only"], slow_approved.to_numpy())
    pairs_per_second = frame.groupby([settings.ACCOUNT_COL, settings.TIME_COL])[settings.ID_COL].transform("size")
    assert not masks["without same-second rows"][(pairs_per_second > 1).to_numpy()].any()
    other = head_to_head.sensitivity_masks(frame, from_date="2025-06-20")
    assert list(other) == ["all ranked rows", "rows from 2025-06-20 on"]

    masks["empty read"] = np.zeros(len(frame), dtype=bool)
    reads = head_to_head.sensitivity_reads(june["units"], june["labels"], june["scores"], masks, draws=40, seed=5)
    assert "'empty read' holds no row" in capsys.readouterr().out and "empty read" not in set(reads["read"])
    for line in reads.itertuples():
        m = masks[line.read]
        direct = paired_bootstrap(june["units"][m], june["labels"][m], june["scores"]["strong"][m],
                                  june["scores"]["weak"][m], draws=40, seed=5)
        assert line.rows == m.sum() and line.frauds == june["labels"][m].sum()
        assert line.alerts == ranking.cut_size(int(m.sum()))
        assert np.isclose(line.gain, direct["gain"]) and np.isclose(line.low, direct["low"])
        assert np.isclose(line.udr_first, ranking.capture(june["labels"][m], june["scores"]["strong"][m])["udr"])
    assert reads["same_sign"].all() and reads["rows"].nunique() == 4          # the strong score wins on every read


def test_same_second_neighbours_outside_the_scores_need_the_wider_table(table, capsys):
    """A neighbour that was never scored is only seen when the raw rows are given."""
    truth = pd.Series(head_to_head.same_second_rows(table), index=table[settings.ID_COL].to_numpy())
    assert truth.any()
    scored = table.drop_duplicates([settings.ACCOUNT_COL, settings.TIME_COL]).reset_index(drop=True)   # neighbours removed
    alone = head_to_head.same_second_rows(scored)
    assert not alone.any()
    raw = table[[settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL]]
    wide = head_to_head.same_second_rows(scored, raw)
    assert np.array_equal(wide, truth.reindex(scored[settings.ID_COL].to_numpy()).to_numpy()) and wide.any()
    assert head_to_head.same_second_rows(scored.drop(columns=[settings.TIME_COL])) is None
    assert "read without same-second rows is skipped" in capsys.readouterr().out


def test_compare_does_not_depend_on_row_order_or_on_history_rows(table):
    """History rows take no alert place, and shuffling the rows leaves every figure unchanged."""
    scores = {"strong": table[settings.SCORE_COL].to_numpy(), "weak": table["weak"].to_numpy()}
    result = head_to_head.compare(table, scores, draws=30, seed=1)
    ranked = _shared.ranked_rows(table)
    assert (result["capture"]["rows"] == ranked.sum()).all() and len(result["rows"]) == ranked.sum()
    assert result["rows"]["alerted_strong"].sum() == ranking.cut_size(int(ranked.sum()))
    main_line = result["sensitivity"].iloc[0]
    assert main_line["read"] == "all ranked rows" and np.isclose(main_line["gain"], result["pairs"]["gain"].iloc[0])
    shuffled = table.sample(frac=1.0, random_state=9)
    again = head_to_head.compare(shuffled.reset_index(drop=True),
                                 {"strong": shuffled[settings.SCORE_COL].to_numpy(), "weak": shuffled["weak"].to_numpy()},
                                 draws=30, seed=1)
    assert np.allclose(result["capture"]["caught"], again["capture"]["caught"])
    assert result["pairs"][["both", "only_a", "only_b", "neither"]].equals(again["pairs"][["both", "only_a", "only_b", "neither"]])
    assert np.allclose(result["sensitivity"]["gain"], again["sensitivity"]["gain"])


def test_tool_lines_up_two_and_three_files(table, tmp_path, capsys):
    """The tool compares only common ids, prints its four tables and writes the alert sets when asked."""
    first = tables.write_table(table[STANDARD], str(tmp_path / "strong.parquet"))
    weak = table[[settings.ID_COL, "weak"]].rename(columns={"weak": settings.SCORE_COL})
    second = tables.write_table(weak.iloc[100:].sample(frac=1.0, random_state=4), str(tmp_path / "weak.parquet"))
    out = str(tmp_path / "rows.parquet")
    head_to_head.main(["--preds", first, second, "--names", "strong", "weak", "--draws", "30", "--out", out])
    printed = capsys.readouterr().out
    for title in ("Files (only transactions", "Capture at each budget", "Pairs: paired account bootstrap",
                  "Preset sensitivity reads"):
        assert title in printed
    assert "approved-row part is skipped" in printed                         # the score file has no response code
    written = tables.read_columns(out)
    kept = table.iloc[100:]
    assert len(written) == _shared.ranked_rows(kept).sum()
    assert {"id", "label", "score_strong", "alerted_strong", "score_weak", "alerted_weak"} <= set(written.columns)

    numbers = synthetic.write_files(table, tmp_path / "raw", 2, first_number=60)
    third = tables.write_table(synthetic.make_scores(table, seed=30)[[settings.ID_COL, settings.SCORE_COL]],
                               str(tmp_path / "third.parquet"))
    head_to_head.main(["--preds", first, second, third, "--draws", "20", "--raw-base", str(tmp_path / "raw"),
                       "--raw-files", f"{numbers[0]}-{numbers[-1]}", "--from-date", "2025-06-15", "--per-mille", "10"])
    printed = capsys.readouterr().out
    assert "approved rows only" in printed and "rows from 2025-06-15 on" in printed and "without same-second rows" in printed
    assert "approved-row part is skipped" not in printed
    head_to_head.main(["--preds", first, second, "--start", "2031-01-01", "--end", "2031-02-01"])
    assert "no row falls in the scored month" in capsys.readouterr().out
