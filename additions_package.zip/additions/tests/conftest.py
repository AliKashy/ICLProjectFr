"""Shared setup of the tests: the import path and the number of threads.

The folder that holds `additions/` is put first on the import path, so
`python -m pytest additions/tests` works from that folder and from anywhere else.

The tests run on small made-up tables. On such tables one thread is as fast as many, and on a
shared machine several threads competing for the same cores can be a hundred times slower. The
numeric libraries read their thread settings when they are first imported, so the settings are
made here, before any test module imports those libraries. A value that is already set in the
environment is kept, so `OMP_NUM_THREADS=8 python -m pytest additions/tests` still works.
"""
import os
import sys
from pathlib import Path

for _name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_name, "1")

ROOT = str(Path(__file__).resolve().parents[2])
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
