"""Tests of the helpers shared by the merchant tables.

Each test compares a helper with the slow, obvious way of computing the same thing on a small
made-up table, or checks one of the rules of the folder: a target row never reads its own
period, and a row's own account is taken out of what it reads.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.common.timekeys import MISSING_SECOND
from additions.merchant import _panel


def _toy(seed=0, n_table=600, n_target=250):
    """A random table (merchant, postal code, account, day, two values) and random target rows."""
    rng = np.random.default_rng(seed)
    table = pd.DataFrame({
        "m": rng.integers(0, 12, n_table), "p": rng.integers(0, 3, n_table).astype(float),
        "a": rng.integers(0, 20, n_table), "day": rng.integers(100, 130, n_table),
        "rows": 1.0, "amount": rng.normal(size=n_table)})
    table.loc[rng.random(n_table) < 0.05, "p"] = np.nan                      # some rows have no postal code
    target = pd.DataFrame({
        "m": rng.integers(0, 13, n_target), "p": rng.integers(0, 3, n_target).astype(float),
        "a": rng.integers(0, 25, n_target), "day": rng.integers(98, 134, n_target)})
    target.loc[rng.random(n_target) < 0.05, "p"] = np.nan
    target.loc[:3, "day"] = MISSING_SECOND                                   # a few target rows have no time
    return table, target


def _slow(table, row, keys, edge, value, own=False):
    """The obvious definition: rows of the same key in the `edge` periods before the row's own period."""
    if row["day"] == MISSING_SECOND or any(pd.isna(row[k]) for k in keys):
        return 0.0
    m = table["day"] < row["day"]
    if edge is not None:
        m &= table["day"] >= row["day"] - edge
    for k in keys:
        m &= table[k] == row[k]
    if own:
        m &= table["a"] == row["a"]
    return float(table.loc[m, value].sum())


def test_lookup_sums_match_the_slow_definition():
    """Sums over completed earlier periods equal a row-by-row recomputation, for one key, two keys and no key."""
    table, target = _toy()
    for keys in (["m"], ["m", "p"], []):
        got = _panel.lookup_sums([table[k] for k in keys], table["day"], [table["rows"], table["amount"]],
                                 [target[k] for k in keys], target["day"], [1, 7, None])
        for edge in (1, 7, None):
            assert got[edge].shape == (len(target), 2)
            for i in range(0, len(target), 3):
                row = target.iloc[i]
                assert got[edge][i, 0] == _slow(table, row, keys, edge, "rows")
                assert np.isclose(got[edge][i, 1], _slow(table, row, keys, edge, "amount"))


def test_a_target_row_never_reads_its_own_period_or_a_missing_key():
    """Table rows of the target's own day and of later days are not counted; a missing key matches nothing."""
    table = pd.DataFrame({"m": [5, 5, 5, 5, np.nan], "day": [9, 10, 10, 11, 9]})
    target = pd.DataFrame({"m": [5, 5, np.nan], "day": [10, 12, 10]})
    got = _panel.lookup_sums([table["m"]], table["day"], [np.ones(5)], [target["m"]], target["day"], [1, None])
    assert got[None][:, 0].tolist() == [1.0, 4.0, 0.0]            # day 10 sees day 9 only; the missing key sees nothing
    assert got[1][:, 0].tolist() == [1.0, 1.0, 0.0]               # one day back: day 9 for the first, day 11 for the second


def test_others_sums_take_the_own_account_out():
    """The sum over other accounts equals all rows minus the account's own, inside and outside the panel."""
    table, target = _toy(seed=1)
    by_key = _panel.add_tables([table.drop(columns="a")], ["rows", "amount"])
    got = _panel.others_sums(by_key, table, ["m"], "day", ["rows", "amount"], target, target["day"].to_numpy(), [7], "a")
    for i in range(0, len(target), 3):
        row = target.iloc[i]
        assert got[7][i, 0] == _slow(table, row, ["m"], 7, "rows") - _slow(table, row, ["m"], 7, "rows", own=True)
    # Accounts 20 to 24 are not in the table: nothing is subtracted for them.
    outside = (target["a"] >= 20).to_numpy()
    plain = _panel.others_sums(by_key, None, ["m"], "day", ["rows", "amount"], target, target["day"].to_numpy(), [7], "a")
    assert outside.any() and np.array_equal(got[7][outside], plain[7][outside])
    # Changing an account's own values does not change what that account reads.
    changed = table.copy()
    changed.loc[changed["a"] == 3, "amount"] += 1000.0
    again = _panel.others_sums(_panel.add_tables([changed.drop(columns="a")], ["rows", "amount"]), changed, ["m"], "day",
                               ["rows", "amount"], target, target["day"].to_numpy(), [7], "a")
    mine = (target["a"] == 3).to_numpy()
    assert np.allclose(got[7][mine], again[7][mine]) and not np.allclose(got[7][~mine], again[7][~mine])


def test_tables_of_several_files_add_up():
    """Adding the tables of two halves gives the table of the whole, missing keys included."""
    table, _ = _toy(seed=2)
    whole = _panel.add_tables([table], ["rows", "amount"])
    halves = _panel.add_tables([_panel.add_tables([table.iloc[:300]], ["rows", "amount"]),
                                _panel.add_tables([table.iloc[300:]], ["rows", "amount"])], ["rows", "amount"])
    keys = ["m", "p", "a", "day"]
    a = whole.sort_values(keys).reset_index(drop=True)
    b = halves.sort_values(keys).reset_index(drop=True)
    assert len(a) == len(b) and np.allclose(a[["rows", "amount"]], b[["rows", "amount"]])
    assert a["rows"].sum() == len(table) and a["p"].isna().any()


def test_priors_pull_thin_rates_and_leave_thick_ones():
    """A rate with no rows equals its prior, one with many rows equals the plain ratio, and levels chain."""
    assert np.isclose(_panel.shrunk(0.0, 0.0, 0.3, 20.0), 0.3)
    assert np.isclose(_panel.shrunk(5.0, 20.0, 0.75, 20.0), (5 + 15) / 40)
    assert np.isclose(_panel.shrunk(5e6, 1e7, 0.0, 20.0), 0.5, atol=1e-5)
    assert np.isnan(_panel.shrunk(0.0, 0.0, np.nan)) and _panel.shrunk(1.0, 4.0, np.nan) == 0.25
    broad, narrow = (np.array([30.0]), np.array([100.0])), (np.array([1.0]), np.array([1.0]))
    assert np.isclose(_panel.chain([broad, narrow], 20.0)[0], (1 + 20 * 0.3) / 21)


def test_histogram_percentiles():
    """Quantile and rank are inverse to each other and agree with hand-computed values."""
    counts = np.array([[2.0, 2.0], [0.0, 4.0], [0.0, 0.0]])
    edges = np.array([0.0, 10.0, 20.0])
    assert np.allclose(_panel.histogram_quantile(counts, edges, 0.5)[:2], [10.0, 15.0])
    assert np.isnan(_panel.histogram_quantile(counts, edges, 0.5)[2])
    assert np.allclose(_panel.histogram_rank(counts, edges, [5.0, 15.0, 5.0])[:2], [0.25, 0.5])
    rng = np.random.default_rng(3)
    many = rng.integers(1, 50, (40, 10)).astype(float)
    ten = np.arange(0.0, 101.0, 10.0)
    q = _panel.histogram_quantile(many, ten, 0.9)
    assert np.allclose(_panel.histogram_rank(many, ten, q), 0.9)
    assert np.isnan(_panel.histogram_rank(many, ten, np.full(40, np.nan))).all()
    smooth = _panel.smooth_histogram(np.zeros((1, 10)), many[:1], 20.0)
    assert np.isclose(smooth.sum(), 20.0) and np.allclose(smooth / 20.0, many[:1] / many[:1].sum())


def test_decisions_and_periods():
    """Response codes and the decline flag give the two outcome arrays; seconds fall into the right periods."""
    ok, risk, funds = settings.APPROVED_REASONS[0], settings.RISK_DECLINE_REASONS[0], settings.FUNDS_DECLINE_REASONS[0]
    df = pd.DataFrame({settings.REASON_COL: [ok, risk, funds, None, ok, ""],
                       settings.DECLINE_FLAG_COL: [0, 1, 1, 0, 1, 0]})
    not_approved, declined_for_risk = _panel.decisions(df)
    assert not_approved.tolist() == [0, 1, 1, 0, 1, 0] and declined_for_risk.tolist() == [0, 1, 0, 0, 0, 0]
    flag_only, no_risk = _panel.decisions(df.drop(columns=settings.REASON_COL))
    assert flag_only.tolist() == [0, 1, 1, 0, 1, 0] and no_risk is None
    assert _panel.decisions(pd.DataFrame({"x": [1]})) == (None, None)
    secs = np.array([0, 86_399, 86_400, MISSING_SECOND], dtype=np.int64)
    assert _panel.days(secs).tolist() == [0, 0, 1, MISSING_SECOND]
    assert _panel.days(secs, shift=1).tolist()[:2] == [0, 1]                  # a shifted day boundary
    assert _panel.periods(secs, 3_600).tolist()[:3] == [0, 23, 24]


def test_the_shared_command_line_reads_made_up_files(capsys):
    """With --demo the tool reads four made-up panel files, two of which hold the target rows."""
    held_flags = []

    def of_file(df, held):
        held_flags.append(held)
        return len(df)

    def features(target, part, args):
        return pd.DataFrame({"rows_in_panel": np.full(len(target), float(part))}, index=target.index)

    frame = _panel.run_tool(["--demo"], "a test", [settings.ACCOUNT_COL, settings.ID_COL], of_file, sum, features)
    assert held_flags == [True, True, False, False]
    assert 0 < len(frame) < frame["rows_in_panel"].iloc[0] and "rows_in_panel" in capsys.readouterr().out
