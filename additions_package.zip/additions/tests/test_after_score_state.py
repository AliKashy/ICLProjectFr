"""Tests of the account risk state built from the model's own earlier scores.

Every column is recomputed the slow way, row by row, from the rows of the same account in
strictly earlier seconds. Further tests check the time rule on rows that share a second, that
later rows change nothing, that long files give what short files give, and the latch.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.after_model import _shared, score_state
from additions.common import ranking, synthetic, tables, timekeys
from additions.common.history import EarlierRows

DAY = 86_400


def _export(seed=0, n_accounts=25, **kwargs):
    """Made-up scored rows with fraud runs on most accounts, and a few rows that have no score."""
    df = synthetic.make_scores(synthetic.make_transactions(n_accounts=n_accounts, seed=seed, fraud_account_share=0.8,
                                                           **kwargs), seed=seed)
    df.loc[np.random.default_rng(seed).random(len(df)) < 0.02, settings.SCORE_COL] = np.nan
    return df


def _frame(rows):
    """A tiny table from (account, second, probability) tuples, with the column names of settings."""
    start = pd.Timestamp(settings.TARGET_START)
    return pd.DataFrame({
        settings.ACCOUNT_COL: [r[0] for r in rows],
        settings.TIME_COL: [start + pd.Timedelta(seconds=r[1]) for r in rows],
        settings.SCORE_COL: [r[2] for r in rows],
    })


def _same(a, b):
    return bool(np.isclose(a, b, rtol=1e-4, atol=1e-5, equal_nan=True))


def _slow_latch(times, evidence, half_life, latched_half_life, threshold, release):
    """Walk one account second by second: fade, read, add. Returns {second: (sum, latched)}."""
    total, latched, last, read = 0.0, False, None, {}
    for t in np.unique(times):
        if last is not None:
            gap = float(t - last)
            if latched:
                to_release = latched_half_life * np.log2(total / release)
                if gap <= to_release:
                    total *= 0.5 ** (gap / latched_half_life)
                else:
                    total, latched = release * 0.5 ** ((gap - to_release) / half_life), False
            else:
                total *= 0.5 ** (gap / half_life)
        read[t] = (total, latched)
        total += evidence[times == t].sum()
        latched = latched or total >= threshold
        last = t
    return read


def _slow_state(i, account, secs, logit, cut, baseline, start):
    """The state of row i from the definition: rows of its account in strictly earlier seconds."""
    has = ~np.isnan(logit)
    earlier = (account == account[i]) & (secs < secs[i]) & (secs >= start) & has
    t, s, age = secs[earlier], logit[earlier], secs[i] - secs[earlier]
    out = {"prev_logit": s[t == t.max()].max() if earlier.any() else np.nan,
           "secs_since_prev": age.min() if earlier.any() else np.nan}
    for label, window in score_state.WINDOWS:
        recent = age <= window
        out[f"max_{label}"] = s[recent].max() if recent.any() else np.nan
        out[f"n_high_{label}"] = (s[recent] >= cut).sum()
    month = age <= 30 * DAY
    high = month & (s >= cut)
    out["secs_since_high"] = age[high].min() if high.any() else np.nan
    for label, half in score_state.HALF_LIVES:
        weight = 0.5 ** (age / half)
        out[f"decayed_sum_{label}"], out[f"decayed_n_{label}"] = (s * weight).sum(), weight.sum()
        faded_out = weight.sum() < score_state.FADED_OUT
        out[f"decayed_mean_{label}"] = np.nan if faded_out else (s * weight).sum() / weight.sum()
    out["n_rows_30d"] = month.sum()
    out["minus_mean_30d"] = logit[i] - s[month].mean() if month.any() else np.nan
    below = (s[month] < logit[i]).sum() + 0.5 * (s[month] == logit[i]).sum()
    out["rank_30d"] = below / month.sum() if month.any() and has[i] else np.nan
    own = (account == account[i]) & (secs >= start) & has
    walk = _slow_latch(secs[own | (np.arange(len(secs)) == i)],
                       np.where(own, np.clip(logit - baseline, 0, None), 0.0)[own | (np.arange(len(secs)) == i)],
                       score_state.LATCH_HALF_LIFE, score_state.LATCHED_HALF_LIFE, score_state.LATCH_THRESHOLD,
                       score_state.LATCH_RELEASE)
    out["latch_sum"], out["latched"] = walk[secs[i]]
    return out


def test_columns_equal_the_slow_definition():
    """Every column matches a row-by-row recomputation, with and without the calendar look-back."""
    df = _export(days=75, start="2025-04-20")
    account, secs = _shared.account_and_time(df)
    logit = _shared.logits(df)
    cut = _shared.cut_value(logit, per_mille=50)
    baseline = cut - score_state.LATCH_BASELINE_BELOW_CUT
    for months_back in (None, 1):
        got = score_state.build_score_state(df, cut, months_back=months_back)
        assert got.shape == (len(df), 34) and got.index.equals(df.index)
        assert list(got.columns) == score_state.column_names("state_")
        start = np.full(len(df), secs.min()) if months_back is None else timekeys.month_start_seconds(secs, 1)
        for i in range(0, len(df), 7):
            slow = _slow_state(i, account, secs, logit, cut, baseline, start[i])
            for name, value in slow.items():
                assert _same(got["state_" + name].iloc[i], value), (months_back, i, name)
        assert got["state_latched"].sum() > 0 and got["state_n_high_24h"].max() >= 2   # the table exercises the columns


def test_rows_of_the_same_second_do_not_see_each_other():
    """A high score is invisible to the other row of its second and visible from the next second on."""
    df = _frame([("a", 100, 0.9), ("a", 100, 0.01), ("a", 160, 0.02), ("b", 160, 0.01), ("a", 5_000, 0.01)])
    cut = ranking.to_logit(np.array([0.5]))[0]
    got = score_state.build_score_state(df, cut, months_back=None)
    high, low = ranking.to_logit(np.array([0.9, 0.01]))
    assert got["state_n_high_1h"].tolist() == [0, 0, 1, 0, 0]
    assert got["state_n_high_24h"].tolist() == [0, 0, 1, 0, 1]
    assert got["state_n_rows_30d"].tolist() == [0, 0, 2, 0, 3]
    assert np.isnan(got["state_prev_logit"].iloc[[0, 1, 3]]).all()               # nothing earlier: nothing to read
    assert np.isclose(got["state_prev_logit"].iloc[2], high)                     # the higher of the two rows at second 100
    assert np.isclose(got["state_max_1h"].iloc[2], high) and np.isnan(got["state_max_1h"].iloc[4])
    assert got["state_secs_since_high"].iloc[2] == 60 and got["state_secs_since_high"].iloc[4] == 4_900
    assert np.isclose(got["state_rank_30d"].iloc[2], 0.5)                        # above the low row, below the high one
    assert got["state_latch_sum"].iloc[0] == 0 and got["state_latch_sum"].iloc[1] == 0
    # The high row lies more than the latch threshold above the baseline (the cut minus 2), so one
    # minute later the account is latched and the sum has faded with the long half-life.
    evidence = high - (cut - score_state.LATCH_BASELINE_BELOW_CUT)
    assert evidence >= score_state.LATCH_THRESHOLD and got["state_latched"].tolist() == [0, 0, 1, 0, 1]
    assert np.isclose(got["state_latch_sum"].iloc[2], evidence * 0.5 ** (60 / score_state.LATCHED_HALF_LIFE), rtol=1e-6)
    assert low < cut - score_state.LATCH_BASELINE_BELOW_CUT                      # the low rows add no evidence


def test_later_rows_do_not_change_earlier_columns():
    """Dropping every row after the middle of the period leaves the columns of the rows before it unchanged."""
    df = _export(seed=1)
    secs = timekeys.seconds(df[settings.TIME_COL])
    cut = _shared.cut_value(_shared.logits(df), per_mille=50)
    keep = secs <= np.median(secs)
    full = score_state.build_score_state(df, cut)
    part = score_state.build_score_state(df[keep], cut)
    assert np.allclose(full[keep].to_numpy(), part.to_numpy(), rtol=1e-5, atol=1e-6, equal_nan=True)


def test_long_files_give_what_short_files_give():
    """A December row in long files gets the state it would get in files that begin on 1 November."""
    df = _export(seed=2, n_accounts=20, days=92, start="2024-10-01")
    secs = timekeys.seconds(df[settings.TIME_COL])
    cut = _shared.cut_value(_shared.logits(df), per_mille=50)
    december = secs >= pd.Timestamp("2024-12-01").timestamp()
    short = secs >= pd.Timestamp("2024-11-01").timestamp()
    long_files = score_state.build_score_state(df, cut)
    short_files = score_state.build_score_state(df[short], cut)
    assert np.allclose(long_files[december].to_numpy(), short_files[december[short]].to_numpy(), rtol=1e-5,
                       atol=1e-6, equal_nan=True)
    # Without the look-back cut the long files remember more, which is the difference the cut removes.
    uncut = score_state.build_score_state(df, cut, months_back=None)
    assert not np.allclose(uncut[december].to_numpy(), short_files[december[short]].to_numpy(), rtol=1e-5,
                           atol=1e-6, equal_nan=True)


def test_no_label_is_read_and_the_cut_is_a_fixed_value():
    """The state needs only account, time and score, and counts 'high' rows against the number passed in."""
    df = _export(seed=3)
    cut = _shared.cut_value(_shared.logits(df), per_mille=50)
    full = score_state.build_score_state(df, cut)
    bare = score_state.build_score_state(df[[settings.ACCOUNT_COL, settings.TIME_COL, settings.SCORE_COL]], cut)
    assert np.array_equal(full.to_numpy(), bare.to_numpy(), equal_nan=True)
    lower = score_state.build_score_state(df, cut - 1.0)
    assert lower["state_n_high_30d"].sum() > full["state_n_high_30d"].sum()
    assert np.array_equal(lower["state_max_30d"].to_numpy(), full["state_max_30d"].to_numpy(), equal_nan=True)
    filled = score_state.build_score_state(df, cut, fill=0.0)
    assert not filled.isna().any().any() and str(filled.dtypes.iloc[0]) == "float32"


def test_card_state_is_the_state_of_account_and_card(capsys):
    """With a card column the same columns are built per account and card; without one a line is printed."""
    df = _export(seed=4)
    rng = np.random.default_rng(4)
    df["card"] = np.where(rng.random(len(df)) < 0.05, np.nan, rng.integers(0, 2, len(df)))
    cut = _shared.cut_value(_shared.logits(df), per_mille=50)
    got = score_state.build_score_state(df, cut, card_col="card")
    assert "skipped" not in capsys.readouterr().out and got.shape == (len(df), 68)
    # The same table with "account and card" written into the account column must give the card columns.
    as_account = df.copy()
    as_account[settings.ACCOUNT_COL] = df[settings.ACCOUNT_COL] + "/" + df["card"].astype(str)
    as_account.loc[df["card"].isna(), settings.ACCOUNT_COL] = None
    expected = score_state.build_score_state(as_account, cut)
    card_columns = got[[c for c in got.columns if c.startswith("state_card_")]]
    assert np.allclose(card_columns.to_numpy(), expected.to_numpy(), rtol=1e-5, atol=1e-6, equal_nan=True)
    assert card_columns[df["card"].isna().to_numpy()].isna().all().all()         # no card value: no history at that key
    assert score_state.build_score_state(df, cut).shape == (len(df), 34)          # settings.CARD_COL is None
    assert "card-level state is skipped" in capsys.readouterr().out


def test_latch_keeps_a_strong_alarm_longer_than_a_weak_one():
    """A sum that crossed the threshold fades with the long half-life until it reaches the release level."""
    keys = np.array([0, 0, 0, 1, 1, 0])
    secs = np.array([0, 2 * DAY, 30 * DAY, 0, 2 * DAY, 2 * DAY], dtype=np.int64)
    evidence = np.array([5.0, 0.0, 0.0, 3.0, 0.0, 9.0])
    total, latched = score_state.latched_sum(EarlierRows(keys, secs), evidence, half_life=DAY,
                                             latched_half_life=7 * DAY, threshold=4.0, release=2.0)
    assert total[0] == 0 and total[3] == 0 and not latched[0]
    assert np.isclose(total[1], 5.0 * 0.5 ** (2 / 7)) and latched[1]             # crossed 4: slow fade
    assert np.isclose(total[4], 3.0 * 0.5 ** 2) and not latched[4]               # stayed below 4: fast fade
    assert total[5] == total[1]                                                  # same second: the 9.0 is not seen
    # After two days the sum is 5 * 0.5^(2/7) + 9. It reaches the release level 2 after
    # 7 * log2(sum / 2) days (about 19) and fades fast for the rest of the 28 days to the last row.
    after = 5.0 * 0.5 ** (2 / 7) + 9.0
    days_latched = 7 * np.log2(after / 2.0)
    assert 18 < days_latched < 20
    assert np.isclose(total[2], 2.0 * 0.5 ** (28 - days_latched)) and not latched[2]
    never = score_state.latched_sum(EarlierRows(keys, secs), evidence, DAY, 7 * DAY, threshold=4.0, release=0.0)
    assert np.isclose(never[0][2], after * 0.5 ** (28 / 7)) and never[1][2]      # release 0: the latch never opens


def test_tool_writes_the_state_with_a_frozen_cut(tmp_path, capsys):
    """The tool takes the cut from the fit file, prints it, and writes one line per row with the id."""
    fit, read = _export(seed=5), _export(seed=6)
    fit_path = tables.write_table(fit, str(tmp_path / "fit.parquet"))
    read_path = tables.write_table(read, str(tmp_path / "read.parquet"))
    out = str(tmp_path / "state.parquet")
    frame = score_state.main(["--export", read_path, "--cut-from", fit_path, "--out", out])
    printed = capsys.readouterr().out
    cut = _shared.cut_value(_shared.logits(fit))
    assert f"alert cut (log-odds): {cut:.6f}" in printed and "state_latch_sum" in printed
    written = tables.read_columns(out)
    assert list(written.columns) == [settings.ID_COL] + score_state.column_names("state_")
    assert np.array_equal(written[settings.ID_COL].to_numpy(), read[settings.ID_COL].to_numpy())
    assert np.array_equal(written["state_max_24h"].to_numpy(), frame["state_max_24h"].to_numpy(), equal_nan=True)
    score_state.main(["--demo", "--months-back", "-1"])
    assert "no --cut was given" in capsys.readouterr().out
