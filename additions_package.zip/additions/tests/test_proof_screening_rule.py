"""Tests of the screening rule.

The tree screen is shown to pass a column that carries fraud signal beyond the score, to park
a noise column, to leave the ranking untouched with a constant column and to repeat itself
exactly. The verdict functions are checked case by case against the stated rule, and the
bundle read against direct calls of capture, the paired bootstrap and the noise budget.
"""
import numpy as np
import pandas as pd
import pytest

from additions import settings
from additions.common import ranking, synthetic
from additions.common.bootstrap import paired_bootstrap
from additions.proof import _shared, block_bootstrap, noise_budget, screening_rule
from additions.sweep import promote


@pytest.fixture(scope="module")
def screen_rows():
    """Made-up rows with a model score, a signal column, a noise column, a constant and a text column."""
    df = synthetic.make_transactions(n_accounts=1500, seed=21, fraud_account_share=0.15)
    df = synthetic.make_scores(df, seed=21, strength=2.0)
    rng = np.random.default_rng(99)                              # not the seed of the score's own noise
    y = _shared.fraud_flags(df)
    df["signal"] = rng.normal(size=len(df)) + 2.5 * y
    df["noise"] = rng.normal(size=len(df))
    df["constant"] = 1.0
    df["text_code"] = rng.choice(["a", "b", "c"], len(df))
    accounts = _shared.account_codes(df)
    fold = _shared.account_folds(accounts, 3, seed=4)          # fit on fold 0, read on folds 1 and 2
    return {"frame": df, "labels": y, "score": df[settings.SCORE_COL].to_numpy(), "accounts": accounts,
            "fit": fold == 0, "blocks": np.where(fold == 0, -1, fold)}


def screen(rows, columns, **kwargs):
    """The screen on the made-up rows with the given candidate columns."""
    return screening_rule.residual_screen(rows["labels"], rows["score"], rows["frame"][columns], rows["accounts"],
                                          rows["fit"], rows["blocks"], draws=100, seed=3, **kwargs)


def test_screen_passes_signal_and_parks_noise(screen_rows):
    """A column with signal beyond the score passes on both blocks; noise and text codes alone are parked."""
    reads = screen(screen_rows, ["signal"])
    assert reads["block"].tolist() == [1, 2] and (reads["gain"] > 0.05).all() and (reads["low"] > 0).all()
    assert screening_rule.screen_verdict(reads)["verdict"] == screening_rule.PASS
    for columns in (["noise"], ["text_code"]):
        assert screening_rule.screen_verdict(screen(screen_rows, columns))["verdict"] == screening_rule.PARKED
    # Each line's figures are the plain capture of the base score and the paired bootstrap's gain.
    for line in reads.itertuples():
        read = screen_rows["blocks"] == line.block
        assert line.rows == read.sum() and line.frauds == screen_rows["labels"][read].sum()
        base = ranking.capture(screen_rows["labels"][read], screen_rows["score"][read])["udr"]
        assert np.isclose(line.base_udr, base)
        assert np.isclose(line.gain, line.screened_udr - line.base_udr)


def test_screen_is_deterministic_and_a_constant_changes_nothing(screen_rows, capsys):
    """Two runs give identical reads; a column that cannot split leaves the ranking and the gain at zero."""
    first, second = screen(screen_rows, ["signal", "noise"]), screen(screen_rows, ["signal", "noise"])
    pd.testing.assert_frame_equal(first, second)
    constant = screen(screen_rows, ["constant"])
    assert (constant["gain"] == 0.0).all() and (constant["low"] == 0.0).all()
    assert screening_rule.screen_verdict(constant)["verdict"] == screening_rule.PARKED
    # Fitting on rows that are also read is allowed, with one printed line.
    rows = dict(screen_rows, fit=np.ones(len(screen_rows["labels"]), dtype=bool))
    screen(rows, ["noise"], rounds=5)
    assert "also read" in capsys.readouterr().out


def test_screen_verdict_follows_the_rule():
    """Pass needs the gain and an interval above zero on every needed block; otherwise the idea is parked."""
    g = screening_rule.SCREEN_GAIN
    assert g == promote.MIN_GAIN and screening_rule.BAR == promote.MIN_GAIN
    verdict = lambda reads, **kw: screening_rule.screen_verdict(reads, **kw)["verdict"]
    assert verdict([{"gain": g, "low": 0.001}, {"gain": 0.02, "low": 0.004}]) == screening_rule.PASS
    assert verdict([{"gain": g, "low": 0.001}, {"gain": 0.02, "low": 0.0}]) == screening_rule.PARKED  # at zero
    assert verdict([{"gain": g - 1e-4, "low": 0.001}, {"gain": 0.02, "low": 0.004}]) == screening_rule.PARKED
    assert verdict([{"gain": 0.02, "low": 0.004}]) == screening_rule.PARKED                          # one block only
    assert verdict([{"gain": 0.02, "low": 0.004}], blocks_needed=1) == screening_rule.PASS
    assert verdict([{"gain": 0.003, "low": 0.001}] * 2, min_gain=0.002) == screening_rule.PASS
    out = screening_rule.screen_verdict([{"gain": 0.01, "low": 0.002}, {"gain": -0.01, "low": -0.02}])
    assert out["blocks_passed"] == 1 and out["smallest_gain"] == -0.01 and "1 of 2" in out["reason"]


def test_decide_needs_the_bar_one_se_and_a_positive_lower_end():
    """Each of the three checks can fail on its own; the bar rises with the number of arms."""
    assert screening_rule.decide(0.02, 0.005)["verdict"] == screening_rule.ADOPT
    below_bar = screening_rule.decide(0.004, 0.001)
    assert below_bar["verdict"] == screening_rule.KEEP and not below_bar["at_least_bar"] and below_bar["low_above_zero"]
    noisy = screening_rule.decide(0.02, 0.025, bar=0.0)
    assert not noisy["at_least_one_se"] and not noisy["low_above_zero"]
    edge = screening_rule.decide(0.0105, 0.007, bar=0.005)              # above one se, interval reaches zero
    assert edge["at_least_bar"] and edge["at_least_one_se"] and not edge["low_above_zero"]
    assert np.isclose(edge["low"], 0.0105 - 1.6449 * 0.007, atol=1e-5)
    raised = screening_rule.decide(0.02, 0.005, n_arms=10)
    assert np.isclose(raised["bar"], promote.MIN_GAIN + block_bootstrap.deflated_bar(10, 0.005))
    assert screening_rule.decide(0.011, 0.004, n_arms=10)["verdict"] == screening_rule.KEEP
    assert screening_rule.decide(0.011, 0.004)["verdict"] == screening_rule.ADOPT
    t_value = screening_rule.decide(0.011, 0.004, seeds_behind_spread=3)
    assert np.isclose(t_value["low"], 0.011 - 2.920 * 0.004, atol=1e-5) and t_value["verdict"] == screening_rule.KEEP


def test_bundle_read_matches_direct_calls(screen_rows):
    """The bundle's gain is the difference of mean captures; its error combines the bootstrap and the seed spread."""
    part = screen_rows["frame"][screen_rows["blocks"] == 1].reset_index(drop=True)
    units, y = _shared.account_codes(part), _shared.fraud_flags(part)
    arm = [synthetic.make_scores(part, seed=s, strength=2.6)[settings.SCORE_COL].to_numpy() for s in (1, 2, 3)]
    control = [synthetic.make_scores(part, seed=s, strength=2.0)[settings.SCORE_COL].to_numpy() for s in (4, 5, 6)]
    read = screening_rule.bundle_read(units, y, arm, control, draws=60, seed=2)
    a = [ranking.capture(y, s)["udr"] for s in arm]
    b = [ranking.capture(y, s)["udr"] for s in control]
    assert np.isclose(read["gain"], np.mean(a) - np.mean(b)) and read["seeds"] == 3
    se_block = np.mean([paired_bootstrap(units, y, s, t, draws=60, seed=2)["se"] for s, t in zip(arm, control)])
    pooled = np.sqrt((np.sum((np.array(a) - np.mean(a)) ** 2) + np.sum((np.array(b) - np.mean(b)) ** 2)) / 4)
    assert np.isclose(read["se_block"], se_block) and np.isclose(read["sd_run"], pooled)
    assert np.isclose(read["se"], noise_budget.gain_se(se_block, pooled, seeds=3))
    # One fit repeated as both the bundle and the control: no gain, no noise, not adopted.
    same = screening_rule.bundle_read(units, y, [control[0]] * 3, [control[0]] * 3, draws=30)
    assert same["gain"] == 0.0 and same["se"] == 0.0
    assert screening_rule.decide(same["gain"], same["se"])["verdict"] == screening_rule.KEEP


def test_tool_prints_screen_verdicts_and_the_decision(tmp_path, capsys):
    """The tool judges a CSV of screen reads per idea, writes the verdicts when asked and prints a decision."""
    reads = pd.DataFrame({"id": ["seen_before", "seen_before", "merchant_rate", "merchant_rate"],
                          "block": [1, 2, 1, 2], "gain": [0.009, 0.007, 0.012, 0.001],
                          "low": [0.002, 0.001, 0.004, -0.003]})
    path, out = tmp_path / "reads.csv", tmp_path / "verdicts.csv"
    reads.to_csv(path, index=False)
    screening_rule.main(["--screen", str(path), "--out", str(out), "--gain", "0.012", "--se", "0.004"])
    printed = capsys.readouterr().out
    assert "Screen verdicts" in printed and "Decision on the bundle" in printed
    written = pd.read_csv(out).set_index("id")
    assert written.loc["seen_before", "verdict"] == "pass" and written.loc["merchant_rate", "verdict"] == "parked"
    screening_rule.main([])
    assert "nothing to decide" in capsys.readouterr().out
