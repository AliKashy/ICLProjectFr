"""Tests of the coverage curve and of coverage-conditioned columns.

Nested panels are checked to be prefixes of one shuffled file order whose columns equal the
columns of day_tables.py on the same files. The curve is checked to show counts shrinking with
coverage while rates stay put, and the mixed columns to be exactly one panel's values per row.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic
from additions.merchant import coverage, day_tables

ACCOUNT, TIME = settings.ACCOUNT_COL, settings.TIME_COL


def _files(n_files=8, seed=0):
    """Made-up rows dealt out to files of whole accounts; the first file also holds the target rows."""
    df = synthetic.make_transactions(n_accounts=240, days=61, seed=seed)
    part = pd.factorize(df[ACCOUNT])[0] % n_files
    frames = [df[part == f].reset_index(drop=True) for f in range(n_files)]
    target = frames[0][pd.to_datetime(frames[0][TIME]) >= pd.Timestamp(settings.TARGET_START)].reset_index(drop=True)
    return frames, target


def test_panels_are_nested_and_equal_the_day_tables_on_the_same_files():
    """Each panel holds the first files of one shuffled order and gives the same columns as day_tables.py on them."""
    frames, target = _files()
    parts = [day_tables.build_day_tables(f) for f in frames]
    panels = coverage.nested_panels(parts, shares=(0.25, 0.5, 1.0), all_files=80, seed=3)
    assert sorted(panels) == [2, 4, 8] and panels[2]["coverage"] == 2 / 80
    order = np.random.default_rng(3).permutation(len(parts))
    rows = [panels[n]["tables"][0]["rows"].sum() for n in (2, 4, 8)]
    assert rows == [sum(len(frames[i]) for i in order[:n]) for n in (2, 4, 8)] and rows[0] < rows[1] < rows[2]
    got = coverage.features_by_panel(target, panels)
    for n in (2, 8):
        files = pd.concat([frames[i] for i in order[:n]], ignore_index=True)
        by_merchant, by_account = day_tables.build_day_tables(files)
        if 0 not in order[:n]:
            by_account = None                                   # the target file is not in this panel
        direct = day_tables.day_features(target, by_merchant, by_account)
        assert np.allclose(got[n].to_numpy(), direct.to_numpy(), rtol=1e-5, atol=1e-6, equal_nan=True)


def test_the_curve_shows_counts_shrinking_and_rates_holding():
    """At half the files the evidence count halves, a mean holds its level, and the reference matches itself."""
    frames, target = _files(seed=1)
    parts = [day_tables.build_day_tables(f) for f in frames]
    panels = coverage.nested_panels(parts, shares=(0.5, 1.0), seed=0)
    labels = target[settings.LABEL_COL].to_numpy()
    curve = coverage.compare(coverage.features_by_panel(target, panels), labels,
                             {n: p["coverage"] for n, p in panels.items()})
    row = curve.set_index(["column", "panel_files"])
    assert np.isclose(row.loc[("mday_n_30d", 8), "corr"], 1.0) and row.loc[("mday_n_30d", 8), "mean_abs_diff"] == 0
    assert 0.35 < row.loc[("mday_n_30d", 4), "mean_ratio"] < 0.65
    assert 0.85 < row.loc[("mday_mean_score_30d", 4), "mean_ratio"] < 1.15
    assert curve["ap"].between(0, 1).all()
    assert np.isclose(row.loc[("mday_n_30d", 4), "coverage"], 4 / coverage.ALL_FILES)


def test_mixed_columns_are_one_panels_values_per_row():
    """Every mixed row equals one panel's row and carries that panel's log coverage; a pick per account is shared."""
    frames, target = _files(seed=2)
    parts = [day_tables.build_day_tables(f) for f in frames]
    panels = coverage.nested_panels(parts, shares=(0.25, 0.5, 1.0), seed=0)
    by_panel = coverage.features_by_panel(target, panels)
    covers = {n: p["coverage"] for n, p in panels.items()}
    mixed = coverage.coverage_conditioned(by_panel, covers, seed=5)
    assert mixed.index.equals(target.index) and coverage.COVERAGE_COL in mixed.columns
    columns = [c for c in mixed.columns if c != coverage.COVERAGE_COL]
    picked = np.full(len(target), -1)
    for n, frame in by_panel.items():
        same = np.isclose(mixed[coverage.COVERAGE_COL].to_numpy(), np.log(covers[n]))
        assert np.allclose(mixed.loc[same, columns].to_numpy(), frame.loc[same, columns].to_numpy().astype(np.float32),
                           equal_nan=True)
        picked[same] = n
    assert (picked > 0).all() and len(set(picked)) == 3                       # every panel is used
    again = coverage.coverage_conditioned(by_panel, covers, seed=5)
    assert again.equals(mixed)                                                  # the pick is repeatable
    per_account = coverage.coverage_conditioned(by_panel, covers, accounts=target[ACCOUNT].to_numpy(), seed=5)
    assert per_account.groupby(target[ACCOUNT])[coverage.COVERAGE_COL].nunique().max() == 1
    served = coverage.with_coverage(by_panel[8], covers[8])
    assert np.allclose(served[coverage.COVERAGE_COL], np.log(covers[8]))


def test_the_command_line_runs_on_made_up_files(tmp_path, capsys):
    """The tool prints the curve, writes it, and writes the coverage-conditioned columns."""
    out, curve = tmp_path / "mixed.parquet", tmp_path / "curve.csv"
    frame = coverage.main(["--demo", "--shares", "0.25", "0.5", "1.0", "--per-account", "--out", str(out),
                           "--table-out", str(curve)])
    assert "mean_ratio" in capsys.readouterr().out and coverage.COVERAGE_COL in frame.columns
    assert set(pd.read_csv(curve)["panel_files"]) == {1, 2, 4}
    written = pd.read_parquet(out)
    assert settings.ID_COL in written.columns and len(written) == len(frame)
