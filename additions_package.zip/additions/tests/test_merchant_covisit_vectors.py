"""Tests of the co-visit merchant vectors and the account affinity.

The pair counts and the mutual information are recomputed the slow way. Two made-up crowds of
accounts check that the vectors put merchants of one crowd together. The affinity is checked
against a row-by-row recomputation, for the time rule, and for the fallback keys.
"""
import itertools

import numpy as np
import pandas as pd
from scipy import sparse

from additions import settings
from additions.common import synthetic, timekeys
from additions.merchant import _panel, covisit_vectors as cv

ACCOUNT, MERCHANT, TIME = settings.ACCOUNT_COL, settings.MERCHANT_COL, settings.TIME_COL
MCC, POSTAL = settings.MCC_COL, settings.MERCHANT_POSTAL_COL


def _rows(seed=0, n_accounts=100):
    """Made-up rows over May and June; the table is fitted on May (rows before settings.TARGET_START)."""
    return synthetic.make_transactions(n_accounts=n_accounts, days=61, seed=seed)


def test_pair_counts_equal_the_slow_definition():
    """Each pair of merchants is counted once per account that used both within the pair window."""
    df = _rows()
    pairs, merchants = cv.count_pairs(df)
    end = pd.Timestamp(settings.TARGET_START)
    sub = df[pd.to_datetime(df[TIME]) < end]
    slow = {}
    for acct, g in sub.groupby(ACCOUNT):
        visits = set(zip(g[MERCHANT], _panel.days(timekeys.seconds(g[TIME]))))
        found = set()
        for (m1, d1), (m2, d2) in itertools.combinations(visits, 2):
            if m1 != m2 and abs(d1 - d2) <= cv.PAIR_DAYS:
                found |= {(m1, m2), (m2, m1)}
        for p in found:
            slow[p] = slow.get(p, 0) + 1
    got = dict(zip(zip(pairs["merchant_a"], pairs["merchant_b"]), pairs["accounts"]))
    assert got == slow
    accounts = sub.groupby(MERCHANT)[ACCOUNT].nunique()
    assert dict(zip(merchants[MERCHANT], merchants["accounts"])) == accounts.astype(float).to_dict()
    # Rows after the end of the table and excluded accounts are simply not counted.
    left_out = pd.unique(df[ACCOUNT])[:10]
    by = ["merchant_a", "merchant_b"]
    a = cv.count_pairs(df, exclude_accounts=left_out)[0].sort_values(by).reset_index(drop=True)
    b = cv.count_pairs(sub[~sub[ACCOUNT].isin(left_out)])[0].sort_values(by).reset_index(drop=True)
    assert a.equals(b)


def test_ppmi_equals_the_dense_formula():
    """Positive mutual information matches the formula written out on a dense matrix."""
    rng = np.random.default_rng(1)
    c = rng.integers(0, 4, (8, 8)).astype(float)
    c = c + c.T
    np.fill_diagonal(c, 0)
    got = cv.ppmi(sparse.csr_matrix(c), 0.75).toarray()
    row = c.sum(axis=1)
    context = row ** 0.75 / (row ** 0.75).sum()
    with np.errstate(divide="ignore"):
        dense = np.log(c / c.sum()) - np.log(row / c.sum())[:, None] - np.log(context)[None, :]
    assert np.allclose(got, np.where(c > 0, np.clip(dense, 0, None), 0.0))


def _crowds(seed=2):
    """Two crowds of accounts that shop at two disjoint sets of ten merchants, over four weeks of May."""
    rng = np.random.default_rng(seed)
    t0 = pd.Timestamp("2025-05-01").timestamp()
    rows = []
    for a in range(120):
        crowd = a // 60
        for week in range(4):
            for m in rng.choice(10, 4, replace=False):
                rows.append((f"a{a}", crowd * 10 + int(m), t0 + week * 7 * 86_400 + rng.integers(0, 5 * 86_400)))
    df = pd.DataFrame(rows, columns=[ACCOUNT, MERCHANT, "secs"])
    df[TIME] = pd.to_datetime(df.pop("secs"), unit="s")
    df[MCC], df[POSTAL] = 5411, 10_000
    return df


def test_vectors_put_one_crowds_merchants_together_and_affinity_follows():
    """Merchants shared by one crowd point the same way; a visit to the other crowd's merchant scores lower."""
    df = _crowds()
    table = cv.fit_vectors(*cv.count_pairs(df), dim=4, min_accounts=1)
    v = table.vectors[table.merchant_token.reindex(range(20)).to_numpy()]
    cos = v @ v.T
    within = np.mean([cos[i, j] for i in range(20) for j in range(20) if i != j and i // 10 == j // 10])
    across = np.mean([cos[i, j] for i in range(20) for j in range(20) if i // 10 != j // 10])
    assert within > 0.5 and across < within - 0.5
    late = pd.Timestamp("2025-05-30 12:00:00")
    probe = pd.concat([df[df[ACCOUNT] == "a0"],
                       pd.DataFrame({ACCOUNT: ["a0", "a0"], MERCHANT: [3, 13], TIME: [late, late], MCC: 5411,
                                     POSTAL: 10_000})], ignore_index=True)
    got = cv.covisit_features(probe, table)
    home, away = got["cov_affinity_30d"].iloc[-2], got["cov_affinity_30d"].iloc[-1]
    assert home > 0.5 and away < home - 0.5
    # The two probe rows share a second, so neither counts the other.
    assert got["cov_affinity_n_30d"].iloc[-1] == got["cov_affinity_n_30d"].iloc[-2]


def test_affinity_equals_the_slow_definition_and_ignores_later_rows():
    """The affinity is the cosine with the mean of strictly earlier rows in the window; later rows change nothing."""
    df = _rows(seed=3)
    table = cv.fit_vectors(*cv.count_pairs(df), dim=8, min_accounts=5)
    target = df[pd.to_datetime(df[TIME]) >= pd.Timestamp("2025-05-15")].reset_index(drop=True)
    got = cv.covisit_features(target, table)
    token, level, _ = table.lookup(target)
    vec = np.where((token >= 0)[:, None], table.vectors[np.maximum(token, 0)], np.nan)
    secs = timekeys.seconds(target[TIME])
    acct = target[ACCOUNT].to_numpy()
    for i in range(0, len(target), 37):
        m = (acct == acct[i]) & (secs < secs[i]) & (secs >= secs[i] - 30 * 86_400) & ~np.isnan(vec).any(axis=1)
        assert got["cov_affinity_n_30d"].iloc[i] == m.sum()
        if m.sum() and not np.isnan(vec[i]).any():
            mean = vec[m].mean(axis=0)
            assert np.isclose(got["cov_affinity_30d"].iloc[i], vec[i] @ mean / np.linalg.norm(mean), atol=1e-5)
    keep = secs <= np.median(secs)
    part = cv.covisit_features(target[keep], table)
    assert np.allclose(got[keep].to_numpy(), part.to_numpy(), equal_nan=True)


def test_thin_and_unknown_merchants_fall_back_to_category_and_postal_code():
    """A thin merchant and a merchant missing from the table read the stand-in of their category and postal code."""
    df = _crowds()
    # Merchants 98 and 99 have one account each: thin alone, enough together for a category-by-postal stand-in.
    extra = pd.DataFrame({ACCOUNT: ["a0", "a1"], MERCHANT: [99, 98], MCC: [5411, 5411], POSTAL: [10_000, 10_000],
                          TIME: [pd.Timestamp("2025-05-02 08:00:00"), pd.Timestamp("2025-05-03 08:00:00")]})
    df = pd.concat([df, extra], ignore_index=True)
    table = cv.fit_vectors(*cv.count_pairs(df), dim=4, min_accounts=2)
    assert table.merchant_level[99] == cv.CATEGORY_POSTAL and table.merchant_level[3] == cv.OWN
    probe = pd.DataFrame({ACCOUNT: ["z", "z", "z"], MERCHANT: [99, 555, 556], MCC: [5411, 5411, 7000],
                          POSTAL: [10_000, 10_000, 1], TIME: pd.to_datetime(["2025-06-02"] * 3)})
    token, level, unknown = table.lookup(probe)
    assert token[0] == token[1] and level.tolist() == [cv.CATEGORY_POSTAL, cv.CATEGORY_POSTAL, cv.NONE]
    assert unknown.tolist() == [0.0, 1.0, 1.0]
    got = cv.covisit_features(probe, table)
    assert np.isnan(got["cov_log_share"].iloc[1]) and got["cov_level"].tolist() == [1, 1, 3]


def test_missing_category_columns_are_skipped_not_fatal(capsys):
    """Without category and postal code the table still fits and thin merchants simply get no vector."""
    df = _rows(seed=4, n_accounts=60).drop(columns=[MCC, POSTAL])
    _panel._SAID.clear()
    table = cv.fit_vectors(*cv.count_pairs(df), dim=4, min_accounts=3)
    got = cv.covisit_features(df, table, with_vectors=True)
    assert "note:" in capsys.readouterr().out and got.shape[1] == 5 + table.vectors.shape[1]
    assert set(np.unique(got["cov_level"])) <= {cv.OWN, cv.NONE}


def test_the_command_line_runs_on_made_up_files(tmp_path, capsys):
    """The tool leaves target files out of the counts, prints its columns and writes them and the table."""
    out, table = tmp_path / "cov.parquet", tmp_path / "table.parquet"
    frame = cv.main(["--demo", "--out", str(out), "--save-table", str(table), "--with-vectors"])
    printed = capsys.readouterr().out
    assert "cov_affinity_30d" in printed and "left out" in printed
    written = pd.read_parquet(out)
    assert settings.ID_COL in written.columns and len(written) == len(frame)
    assert {MERCHANT, "level", "log_share", "v_0"} <= set(pd.read_parquet(table).columns)
