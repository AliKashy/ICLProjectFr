"""Tests of the helpers shared by the model blocks (additions/model/_shared.py).

Each test states one rule the helpers keep: the mask of `run_blocks` is added to the attention
logits in scoring exactly as in training, `run_blocks` does what nn.TransformerEncoder does for
an ordinary mask, and the batch builder keeps accounts whole, ordered and uncut inside a second.
"""
import numpy as np
import torch

from additions import settings
from additions.common import synthetic, timekeys
from additions.model import masks
from additions.model._shared import encoder_stack, layout, pick, run_blocks, sequences_from_table

WIDTH, HEADS = 16, 4


def _stack(num_blocks=2, seed=0):
    """A small stack with dropout zero, so training mode and scoring mode do the same arithmetic."""
    torch.manual_seed(seed)
    return encoder_stack(WIDTH, HEADS, num_blocks, dropout=0.0, attn_dropout=0.0)


def _strict_mask(B=3, T=7, seed=0):
    """A strict-time mask of zeros and minus infinity for a small made-up batch, and the batch input."""
    g = torch.Generator().manual_seed(seed)
    times = torch.sort(torch.randint(0, 5, (B, T), generator=g), dim=1).values
    valid = torch.ones(B, T, dtype=torch.bool)
    valid[0, -2:] = False                                       # some padding in the first sequence
    x = torch.randn(B, T, WIDTH, generator=g)
    return x, masks.to_attention_mask(masks.strict_visibility(times, valid), HEADS)


def test_pick_reads_settings_only_when_no_value_is_given():
    """A given value wins; without one the setting of that name is returned at the moment of the call."""
    assert pick(7, "NUM_HEADS") == 7
    assert pick(None, "NUM_HEADS") == settings.NUM_HEADS
    assert encoder_stack(WIDTH, HEADS, 0) is None


def test_a_bias_in_the_mask_is_added_in_scoring_exactly_as_in_training():
    """With dropout zero, a mask holding a learned-looking bias gives the same output in both modes."""
    stack = _stack()
    x, mask = _strict_mask()
    bias = torch.randn(mask.shape, generator=torch.Generator().manual_seed(1))
    biased = mask + bias                                         # finite numbers where reading is allowed
    stack.train()
    trained = run_blocks(stack, x, biased)
    stack.eval()
    with torch.no_grad():
        scored = run_blocks(stack, x, biased)
    assert torch.allclose(trained, scored, atol=1e-5)
    # The bias really changes the result, so the equality above is not the trivial one.
    with torch.no_grad():
        assert not torch.allclose(scored, run_blocks(stack, x, mask), atol=1e-4)


def test_run_blocks_agrees_with_the_transformer_encoder_for_an_ordinary_mask():
    """For a mask of zeros and minus infinity, `run_blocks` equals nn.TransformerEncoder in both modes."""
    stack = _stack()
    x, mask = _strict_mask(seed=3)
    stack.train()
    assert torch.allclose(run_blocks(stack, x, mask), stack(x, mask=mask), atol=1e-5)
    stack.eval()
    with torch.no_grad():
        assert torch.allclose(run_blocks(stack, x, mask), stack(x, mask=mask), atol=1e-5)
        assert torch.allclose(run_blocks(stack, x, None), stack(x), atol=1e-5)
    assert run_blocks(None, x, mask) is x


def test_run_blocks_lets_gradients_reach_every_weight():
    """Every weight of the stack gets a finite, non-zero gradient through `run_blocks`."""
    stack = _stack()
    x, mask = _strict_mask(seed=4)
    run_blocks(stack, x, mask).pow(2).sum().backward()
    for name, p in stack.named_parameters():
        assert p.grad is not None and torch.isfinite(p.grad).all(), name
        assert p.grad.abs().sum() > 0, name


def test_the_batch_keeps_whole_accounts_in_order_and_never_cuts_a_second():
    """Every row sits in one slot; a sequence holds one account in time order; no second is split."""
    df = synthetic.make_transactions(40, days=20, seed=2, tie_share=0.2)
    per = 4
    batch, row_index, cards = sequences_from_table(df, seconds_per_sequence=per)
    B, T = row_index.shape
    real = row_index[row_index >= 0]
    assert sorted(real.tolist()) == list(range(len(df)))         # every row once, none twice

    account = timekeys.codes(df[settings.ACCOUNT_COL])
    secs = timekeys.seconds(df[settings.TIME_COL])
    seen_second = {}
    last_end = {}
    for b in range(B):
        rows = row_index[b][row_index[b] >= 0]
        assert len(set(account[rows].tolist())) == 1               # one account per sequence
        assert np.all(np.diff(secs[rows]) >= 0)                     # in time order
        assert len(np.unique(secs[rows])) <= per                    # at most `per` distinct seconds
        a = int(account[rows[0]])
        # Sequences of one account follow each other in time, and none shares a second with another.
        assert secs[rows[0]] > last_end.get(a, np.iinfo(np.int64).min)
        last_end[a] = secs[rows[-1]]
        for s in np.unique(secs[rows]):
            assert seen_second.setdefault((a, int(s)), b) == b

    # Padding: real rows first, padding after them, and the batch tensors agree with the index.
    mask = batch["mask"].numpy()
    assert np.array_equal(mask, row_index >= 0)
    assert np.all(np.diff(mask.astype(int), axis=1) <= 0)
    assert mask.sum(axis=1).max() == T and (~mask).any()
    assert np.all(batch["target_seq"].numpy()[~mask] == -100)
    assert np.all(batch["time_seq"].numpy()[~mask] == 0)
    assert batch["categorical"].shape[:2] == (B, T) and len(cards) == batch["categorical"].shape[2]
    assert int(batch["categorical"].max()) < max(cards)
    assert torch.isfinite(batch["continuous"]).all()


def test_layout_puts_per_row_values_where_their_rows_sit():
    """`layout` of the row numbers gives back the row index, and the time column lands on its rows."""
    df = synthetic.make_transactions(15, days=10, seed=5)
    batch, row_index, _ = sequences_from_table(df)
    placed = layout(np.arange(len(df)), row_index, fill=-1).numpy()
    assert np.array_equal(placed, row_index)
    secs = timekeys.seconds(df[settings.TIME_COL])
    assert np.array_equal(layout(secs, row_index, fill=0).numpy(), batch["time_seq"].numpy())
    vectors = np.random.default_rng(0).normal(size=(len(df), 3))
    out = layout(vectors, row_index, fill=0.0).numpy()
    assert out.shape == row_index.shape + (3,)
    real = row_index >= 0
    assert np.array_equal(out[real], vectors[row_index[real]]) and np.all(out[~real] == 0.0)


def test_the_time_gap_is_shared_by_rows_of_one_second():
    """The time-gap column says nothing about the order of rows in one second."""
    df = synthetic.make_transactions(30, days=10, seed=6, tie_share=0.3)
    batch, row_index, _ = sequences_from_table(df)
    gap = batch["continuous"][..., -1].numpy()
    times = batch["time_seq"].numpy()
    for b in range(row_index.shape[0]):
        n = int((row_index[b] >= 0).sum())
        assert gap[b, 0] == 0.0
        for i in range(1, n):
            if times[b, i] == times[b, i - 1]:
                assert gap[b, i] == gap[b, i - 1]
