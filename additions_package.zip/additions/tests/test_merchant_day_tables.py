"""Tests of the merchant-by-day tables.

The columns are recomputed row by row from the raw rows of other accounts on completed
earlier days, with the priors applied the slow way. Further tests check that tables of
files add up, that a row's own account never reaches its own columns, that the row's own
day and later days are not read, and that fresh labels stay out of the fraud rate.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, timekeys
from additions.merchant import _panel, day_tables

ACCOUNT, MERCHANT, MCC, POSTAL = (settings.ACCOUNT_COL, settings.MERCHANT_COL, settings.MCC_COL,
                                  settings.MERCHANT_POSTAL_COL)
OK = settings.APPROVED_REASONS[0]
LEVELS = ([], [MCC], [MCC, POSTAL], [MERCHANT])                 # from the broadest key to the narrowest


def _rows(seed=0, n_accounts=120, days=75):
    """Made-up rows; several merchants share a postal code and a few rows have none."""
    df = synthetic.make_transactions(n_accounts=n_accounts, days=days, seed=seed, fraud_account_share=0.5)
    df[POSTAL] = (10_000 + df[MERCHANT] % 7).astype(float)
    df.loc[np.random.default_rng(seed).random(len(df)) < 0.03, POSTAL] = np.nan
    return df


def _day(df):
    return _panel.days(timekeys.seconds(df[settings.TIME_COL]))


def _others(df, day, i, keys, first_age, last_age):
    """Rows of other accounts at the same key on the days `first_age` to `last_age` before row i's day."""
    m = (df[ACCOUNT].to_numpy() != df[ACCOUNT].iloc[i]) & (day <= day[i] - first_age) & (day >= day[i] - last_age)
    for k in keys:
        m &= (df[k] == df[k].iloc[i]).to_numpy()                 # a missing key equals nothing
    return df[m]


def _pulled(parts, top, bottom, strength):
    """The slow chain of priors over the levels: every level is pulled toward the one before it."""
    value = np.nan
    for sub in parts:
        total, count = top(sub), bottom(sub)
        if np.isnan(value):
            value = total / count if count > 0 else np.nan
        else:
            value = (total + strength * value) / (count + strength)
    return value


def _same(a, b):
    return bool(np.isclose(a, b, rtol=2e-4, atol=2e-4, equal_nan=True))


def test_columns_equal_the_slow_definition():
    """Every column matches a recomputation from other accounts' rows of completed earlier days."""
    df = _rows()
    day = _day(df)
    by_merchant, by_account = day_tables.build_day_tables(df)
    got = day_tables.day_features(df, by_merchant, by_account)
    assert got.shape == (len(df), 7 * 3 + 4) and got.index.equals(df.index)
    rows, k = (lambda s: float(len(s))), _panel.PRIOR_ROWS
    for i in range(0, len(df), 211):
        for label, w in day_tables.WINDOWS:
            parts = [_others(df, day, i, keys, 1, w) for keys in LEVELS]
            at_merchant = parts[-1]
            assert got[f"mday_n_{label}"].iloc[i] == len(at_merchant)
            per_account = len(at_merchant) / max(len(set(zip(at_merchant[ACCOUNT], day[at_merchant.index]))), 1)
            assert _same(got[f"mday_rows_per_account_{label}"].iloc[i], per_account if len(at_merchant) else np.nan)
            share = _pulled(parts, lambda s: float((s[settings.REASON_COL] != OK).sum()), rows, k)
            assert _same(got[f"mday_not_approved_share_{label}"].iloc[i], share)
            risk = _pulled(parts, lambda s: float(s[settings.REASON_COL].isin(settings.RISK_DECLINE_REASONS).sum()), rows, k)
            assert _same(got[f"mday_risk_decline_share_{label}"].iloc[i], risk)
            score = _pulled(parts, lambda s: float(s[settings.VISA_SCORE_COL].sum()), rows, k)
            assert _same(got[f"mday_mean_score_{label}"].iloc[i], score)
            mean = _pulled(parts, lambda s: float(s[settings.AMOUNT_COL].sum()), rows, k)
            square = _pulled(parts, lambda s: float((s[settings.AMOUNT_COL] ** 2).sum()), rows, k)
            assert _same(got[f"mday_mean_amount_{label}"].iloc[i], mean)
            z = (df[settings.AMOUNT_COL].iloc[i] - mean) / np.sqrt(square - mean ** 2)
            assert np.isclose(got[f"mday_amount_z_{label}"].iloc[i], z, rtol=1e-2, atol=1e-2, equal_nan=True)
        for label, w in day_tables.LABEL_WINDOWS:
            parts = [_others(df, day, i, keys, 30, 30 + w - 1) for keys in LEVELS]
            assert got[f"mday_fraud_n_{label}"].iloc[i] == len(parts[-1])
            rate = _pulled(parts, lambda s: float((s[settings.LABEL_COL] == 1).sum()), rows, day_tables.LABEL_PRIOR_ROWS)
            assert np.isclose(got[f"mday_fraud_rate_{label}"].iloc[i], rate, rtol=1e-3, atol=1e-7, equal_nan=True)
    assert got["mday_fraud_rate_30d"].max() > 0                                 # the fraud columns are not all empty


def test_tables_of_files_add_up():
    """Tables built file by file and added give the same columns as tables built on all rows at once."""
    df = _rows(seed=1)
    part = pd.factorize(df[ACCOUNT])[0] % 3                                  # three files of whole accounts
    by_merchant, by_account = day_tables.combine([day_tables.build_day_tables(df[part == f]) for f in range(3)])
    whole_merchant, whole_account = day_tables.build_day_tables(df)
    assert len(by_merchant) == len(whole_merchant) and len(by_account) == len(whole_account)
    visits = len(df.assign(day=_day(df)).drop_duplicates([ACCOUNT, MERCHANT, "day"]))
    assert by_merchant["rows"].sum() == len(df) and np.isclose(by_merchant["accounts"].sum(), visits)
    a = day_tables.day_features(df, by_merchant, by_account)
    b = day_tables.day_features(df, whole_merchant, whole_account)
    assert np.allclose(a.to_numpy(), b.to_numpy(), rtol=1e-5, atol=1e-6, equal_nan=True)


def test_the_own_account_never_reaches_its_own_columns():
    """An account inside the panel reads what it would read if its rows were not in the panel at all."""
    df = _rows(seed=2)
    chosen = df[ACCOUNT].isin(pd.unique(df[ACCOUNT])[:15]).to_numpy()
    by_merchant, by_account = day_tables.build_day_tables(df)
    inside = day_tables.day_features(df[chosen], by_merchant, by_account)
    outside = day_tables.day_features(df[chosen], day_tables.build_day_tables(df[~chosen])[0], None)
    # Other chosen accounts are part of the first panel and not of the second, so the comparison is made one
    # account at a time: the panel without that single account.
    one = df[ACCOUNT] == pd.unique(df[ACCOUNT])[0]
    alone = day_tables.day_features(df[one], day_tables.build_day_tables(df[~one])[0], None)
    assert np.allclose(inside[one[chosen].to_numpy()].to_numpy(), alone.to_numpy(), rtol=1e-5, atol=1e-6, equal_nan=True)
    assert not np.allclose(inside.to_numpy(), outside.to_numpy(), equal_nan=True)   # the test can fail
    # Changing the outcome and the label of the account's own rows moves nothing on its own rows.
    changed = df.copy()
    changed.loc[one, settings.REASON_COL] = settings.RISK_DECLINE_REASONS[0]
    changed.loc[one, settings.DECLINE_FLAG_COL] = 1
    changed.loc[one, settings.LABEL_COL] = 1
    again = day_tables.day_features(changed[one], *day_tables.build_day_tables(changed))
    assert np.allclose(again.to_numpy(), alone.to_numpy(), rtol=1e-5, atol=1e-6, equal_nan=True)


def test_the_own_day_and_later_days_are_not_read():
    """A decline at the merchant is invisible on its own day and visible from the next day on."""
    stamp = pd.Timestamp("2025-06-03 09:00:00")
    df = pd.DataFrame({
        ACCOUNT: ["a", "b", "a", "a", "c"], MERCHANT: [7, 7, 7, 7, 7], MCC: [5411] * 5, POSTAL: [10001.0] * 5,
        settings.TIME_COL: [stamp, stamp + pd.Timedelta(hours=1), stamp + pd.Timedelta(hours=2),
                            stamp + pd.Timedelta(days=1), stamp + pd.Timedelta(days=1, hours=1)],
        settings.REASON_COL: [OK, settings.RISK_DECLINE_REASONS[0], OK, OK, OK],
        settings.DECLINE_FLAG_COL: [0, 1, 0, 0, 0], settings.AMOUNT_COL: [10.0, 20.0, 30.0, 40.0, 50.0],
        settings.VISA_SCORE_COL: [10.0, 90.0, 10.0, 10.0, 10.0], settings.LABEL_COL: [0, 0, 0, 0, 0]})
    got = day_tables.day_features(df, *day_tables.build_day_tables(df), prior_rows=0.0)
    assert got["mday_n_1d"].tolist() == [0, 0, 0, 1, 3]              # the same day never counts; b's row counts for a
    assert got["mday_not_approved_share_1d"].iloc[3] == 1.0 and np.isnan(got["mday_not_approved_share_1d"].iloc[2])
    assert np.isclose(got["mday_not_approved_share_1d"].iloc[4], 1 / 3)
    # Dropping every row after the middle of the period changes nothing for the rows before it.
    rows = _rows(seed=3)
    day = _day(rows)
    keep = day <= np.median(day)
    full = day_tables.day_features(rows, *day_tables.build_day_tables(rows))
    part = day_tables.day_features(rows[keep], *day_tables.build_day_tables(rows[keep]))
    assert np.allclose(full[keep].to_numpy(), part.to_numpy(), rtol=1e-5, atol=1e-6, equal_nan=True)


def test_fresh_labels_stay_out_and_a_reporting_curve_weights_the_days():
    """Labels of the last 29 days do not move the fraud rate; a curve counts each day by its reported share."""
    df = _rows(seed=4)
    day = _day(df)
    tabs = day_tables.build_day_tables(df)
    last = df[day == day.max()]
    before = day_tables.day_features(last, *tabs)
    fresh = df.copy()
    fresh.loc[day > day.max() - 30, settings.LABEL_COL] = 1                   # every recent row becomes a fraud
    after = day_tables.day_features(last, *day_tables.build_day_tables(fresh))
    assert np.array_equal(before.to_numpy(), after.to_numpy(), equal_nan=True)
    assert day_tables.label_bands(30) == [(30, 59, 1.0)] and day_tables.label_bands(30, 0) == [(1, 30, 1.0)]
    curve = [(7, 0.4), (30, 0.8), (60, 1.0)]
    assert day_tables.label_bands(30, 30, curve) == [(7, 29, 0.4), (30, 59, 0.8)]
    assert day_tables.label_bands(90, 30, curve) == [(7, 29, 0.4), (30, 59, 0.8), (60, 119, 1.0)]
    got = day_tables.day_features(last, *tabs, reporting_curve=curve, label_prior_rows=0.0)
    for i in range(0, len(last), 9):
        row = int(last.index[i])
        young, old = _others(df, day, row, [MERCHANT], 7, 29), _others(df, day, row, [MERCHANT], 30, 59)
        n = 0.4 * len(young) + 0.8 * len(old)
        frauds = 0.4 * (young[settings.LABEL_COL] == 1).sum() + 0.8 * (old[settings.LABEL_COL] == 1).sum()
        assert _same(got["mday_fraud_n_30d"].iloc[i], n)
        if n > 0:
            assert np.isclose(got["mday_fraud_rate_30d"].iloc[i], frauds / n, rtol=1e-4, atol=1e-7)


def test_missing_optional_columns_are_skipped_not_fatal(capsys):
    """Without category, postal code, score, decisions and label the tables still build, with fewer columns."""
    df = _rows(seed=5, n_accounts=30)
    bare = df.drop(columns=[MCC, POSTAL, settings.VISA_SCORE_COL, settings.LABEL_COL, settings.REASON_COL,
                            settings.DECLINE_FLAG_COL])
    _panel._SAID.clear()
    by_merchant, by_account = day_tables.build_day_tables(bare)
    got = day_tables.day_features(bare, by_merchant, by_account)
    assert list(got.columns) == [f"mday_{name}_{w}" for w in ("1d", "7d", "30d")
                                 for name in ("n", "rows_per_account", "mean_amount", "amount_z")]
    assert capsys.readouterr().out.count("note:") == 9
    assert np.isfinite(got.to_numpy()[~np.isnan(got.to_numpy())]).all()


def test_the_command_line_runs_on_made_up_files(tmp_path, capsys):
    """The tool prints one summary line per column and writes the columns and the merchant table."""
    out, table = tmp_path / "mday.parquet", tmp_path / "table.parquet"
    frame = day_tables.main(["--demo", "--out", str(out), "--save-table", str(table)])
    assert "mday_fraud_rate_90d" in capsys.readouterr().out and frame.shape[1] == 25
    written = pd.read_parquet(out)
    assert settings.ID_COL in written.columns and len(written) == len(frame)
    assert {"day", "rows", "accounts", MERCHANT} <= set(pd.read_parquet(table).columns)
