"""Tests of the hooks that capture the stage-1 vector and the head-input vector.

A tiny two-stage model stands in for the real one: a token encoder with a summary token, a
recurrent second stage that only looks back, and a linear head. The captured vectors are
compared with the same values computed by hand, and the model is checked to be left unchanged.
"""
import numpy as np
import pytest
import torch
from torch import nn

from additions import settings
from additions.exports import _shared, stage1_hook


class TinyTwoStage(nn.Module):
    """A small model with the same shape as the real one: fields, stage 1, stage 2, head."""

    def __init__(self, n_fields=5, width=16, every_position=True):
        super().__init__()
        self.every_position = every_position
        self.field_weight = nn.Parameter(torch.randn(n_fields, width) * 0.3)    # one token per numeric field
        self.txn_cls = nn.Parameter(torch.randn(1, 1, width) * 0.3)
        layer = nn.TransformerEncoderLayer(width, 2, 32, dropout=0.0, batch_first=True)
        self.token_encoder = nn.TransformerEncoder(layer, 1)                    # stage 1: one row's fields
        self.seq_encoder = nn.GRU(width, width, batch_first=True)               # stage 2: earlier rows only
        self.head = nn.Linear(width, 2)

    def tokens(self, continuous):
        """[batch, positions, fields] -> [batch * positions, 1 + fields, width], summary token first."""
        b, t, c = continuous.shape
        fields = continuous.reshape(b * t, c, 1) * self.field_weight
        return torch.cat([self.txn_cls.expand(b * t, 1, -1), fields], dim=1)

    def forward(self, batch):
        b, t, _ = batch["continuous"].shape
        txn = self.token_encoder(self.tokens(batch["continuous"]))[:, 0].reshape(b, t, -1)
        out, _ = self.seq_encoder(txn)
        return self.head(out) if self.every_position else self.head(out[:, -1])


class LastRealRow(TinyTwoStage):
    """The same small model with a head that scores the last real row of every sequence."""

    def forward(self, batch):
        b, t, _ = batch["continuous"].shape
        txn = self.token_encoder(self.tokens(batch["continuous"]))[:, 0].reshape(b, t, -1)
        out, _ = self.seq_encoder(txn)
        last = batch["mask"].long().sum(1) - 1                   # the sequences are padded at the end
        return self.head(out[torch.arange(b), last])


def _batch(b=4, t=7, c=5, seed=0):
    """A made-up batch: numeric fields and a mask whose sequences end in padding."""
    rng = torch.Generator().manual_seed(seed)
    mask = torch.ones(b, t, dtype=torch.bool)
    for i in range(b):
        mask[i, t - i:] = False                                 # sequence i has i padded positions
    return {"continuous": torch.randn(b, t, c, generator=rng), "mask": mask}


@pytest.fixture()
def model():
    torch.manual_seed(0)
    return TinyTwoStage().eval()


def test_captured_vectors_equal_the_values_computed_by_hand(model):
    """The stage-1 capture is the summary token of the encoder, and the head turns the head capture into the output."""
    batch = _batch()
    with torch.no_grad(), stage1_hook.capture_vectors(model) as tap:
        output = model(batch)
        by_hand = model.token_encoder(model.tokens(batch["continuous"]))[:, 0]
    assert torch.equal(tap.stage1[0], by_hand) and tap.stage1[0].shape == (4 * 7, 16)
    assert tap.head_input[0].shape == (4, 7, 16)
    assert torch.allclose(model.head(tap.head_input[0]), output, atol=1e-6)
    stage1, head_input = tap.rows(mask=batch["mask"])
    n_real = int(batch["mask"].sum())
    assert stage1.shape == head_input.shape == (n_real, 16)
    assert torch.equal(stage1, by_hand.reshape(4, 7, 16)[batch["mask"]])       # row i is the same transaction in both
    assert torch.isfinite(stage1).all() and torch.isfinite(head_input).all()
    everything, _ = tap.rows()
    assert everything.shape == (4 * 7, 16)                                      # without a mask padding is kept


def test_hooks_leave_the_model_as_it_was(model):
    """The output is the same with and without hooks, and no hook stays behind, even after an error."""
    batch = _batch(seed=1)
    with torch.no_grad():
        plain = model(batch)
        with stage1_hook.capture_vectors(model):
            hooked = model(batch)
    assert torch.equal(plain, hooked)
    with pytest.raises(RuntimeError):
        with stage1_hook.capture_vectors(model):
            raise RuntimeError("an error inside the block")
    assert len(model.token_encoder._forward_hooks) == 0 and len(model.head._forward_hooks) == 0
    with pytest.raises(AttributeError, match="token_encoder"):                  # the message lists what is there
        with stage1_hook.capture_vectors(model, stage1_attr="no_such_part"):
            pass
    assert len(model.head._forward_hooks) == 0                                  # a wrong name installs nothing


def test_the_stage1_vector_of_a_row_ignores_every_other_row(model):
    """Changing one transaction changes its own stage-1 vector only; the head input of later rows changes too."""
    batch = _batch(seed=2)
    changed = {"continuous": batch["continuous"].clone(), "mask": batch["mask"]}
    changed["continuous"][1, 2] += 1.0                                          # sequence 1, position 2
    with torch.no_grad(), stage1_hook.capture_vectors(model) as tap:
        model(batch)
        model(changed)
    before, after = (tap.stage1[i].reshape(4, 7, 16) for i in (0, 1))
    moved = (before != after).any(dim=-1)
    assert moved[1, 2] and int(moved.sum()) == 1                                # no history in stage 1
    head_moved = (tap.head_input[0] != tap.head_input[1]).any(dim=-1)
    assert head_moved[1, 2:].all() and not head_moved[1, :2].any() and not head_moved[0].any()


def test_a_head_that_scores_one_row_per_sequence():
    """With one head input per sequence the stage-1 vector of the scored position is returned."""
    torch.manual_seed(1)
    single = TinyTwoStage(every_position=False).eval()
    batch = _batch(seed=3)
    with torch.no_grad(), stage1_hook.capture_vectors(single) as tap:
        output = single(batch)
    assert output.shape == (4, 2) and tap.head_input[0].shape == (4, 16)
    per_sequence = tap.stage1[0].reshape(4, 7, 16)
    stage1, head_input = tap.rows()
    assert torch.equal(stage1, per_sequence[:, -1]) and head_input.shape == (4, 16)
    picked, _ = tap.rows(target_index=torch.tensor([0, 3, 6, 2]))
    assert torch.equal(picked, per_sequence[torch.arange(4), torch.tensor([0, 3, 6, 2])])


def test_gradient_reaches_stage_one_only_when_the_graph_is_kept(model):
    """With detach off a loss on the captured stage-1 vector trains stage 1 and nothing after it."""
    batch = _batch(seed=4)
    with stage1_hook.capture_vectors(model, detach=False) as tap:
        model(batch)
        tap.stage1[0].pow(2).sum().backward()
    assert model.field_weight.grad is not None and float(model.field_weight.grad.abs().sum()) > 0
    assert all(p.grad is not None for p in model.token_encoder.parameters())
    assert all(p.grad is None for p in model.seq_encoder.parameters()) and model.head.weight.grad is None
    with stage1_hook.capture_vectors(model) as tap:                             # the default cuts the graph
        model(batch)
    assert not tap.stage1[0].requires_grad and not tap.head_input[0].requires_grad
    tap.clear()
    assert tap.stage1 == [] and tap.head_input == []


def test_collect_gathers_real_rows_and_names_the_columns(model):
    """A pass over batches returns one line per real row, in batch order, with named columns."""
    model.train()                                                               # collect must restore this
    batches = [_batch(seed=5), _batch(b=3, t=6, seed=6)]
    got = stage1_hook.collect(model, batches)
    n_real = sum(int(b["mask"].sum()) for b in batches)
    assert got["stage1"].shape == got["head_input"].shape == (n_real, 16) and got["output"].shape == (n_real, 2)
    assert model.training
    model.eval()
    with torch.no_grad():
        expected = torch.cat([model(b)[b["mask"]] for b in batches]).numpy()
    assert np.allclose(got["output"], expected, atol=1e-6)
    assert np.allclose(model.head(torch.from_numpy(got["head_input"])).detach().numpy(), expected, atol=1e-5)
    frame = stage1_hook.as_frame(got)
    names = [f"{_shared.STAGE1_PREFIX}{j}" for j in range(16)] + [f"{settings.VECTOR_PREFIX}{j}" for j in range(16)]
    assert list(frame.columns) == names and len(frame) == n_real
    assert _shared.vector_columns(frame, _shared.STAGE1_PREFIX) == names[:16]
    assert np.array_equal(frame[names[0]].to_numpy(), got["stage1"][:, 0])


class JoinedSummaries(nn.Module):
    """A stage-1 module that already returns one joined vector per transaction: [batch, positions, k * width]."""

    def __init__(self, n_fields=5, width=8, k=3):
        super().__init__()
        self.mix = nn.Linear(n_fields, k * width)

    def forward(self, continuous):
        return torch.tanh(self.mix(continuous))


class JoinedModel(nn.Module):
    """A model whose stage 1 hands stage 2 the joined summary tokens of every position."""

    def __init__(self, n_fields=5, width=8, k=3):
        super().__init__()
        self.stage1 = JoinedSummaries(n_fields, width, k)
        self.seq_encoder = nn.GRU(k * width, 12, batch_first=True)
        self.head = nn.Linear(12, 2)

    def forward(self, batch):
        out, _ = self.seq_encoder(self.stage1(batch["continuous"]))
        return self.head(out)


def test_several_summary_tokens_are_joined_in_the_given_order(model):
    """Positions (0, 2, 1) of a [rows, tokens, width] output become one vector of three widths per row."""
    batch = _batch()
    with torch.no_grad(), stage1_hook.capture_vectors(model, summary_index=(0, 2, 1)) as tap:
        model(batch)
        tokens = model.token_encoder(model.tokens(batch["continuous"]))
    by_hand = torch.cat([tokens[:, 0], tokens[:, 2], tokens[:, 1]], dim=1)
    assert tap.stage1[0].shape == (4 * 7, 3 * 16) and torch.equal(tap.stage1[0], by_hand)
    stage1, head_input = tap.rows(mask=batch["mask"])
    assert stage1.shape == (int(batch["mask"].sum()), 48) and head_input.shape[1] == 16
    assert torch.equal(stage1, by_hand.reshape(4, 7, 48)[batch["mask"]])


def test_a_stage_one_that_returns_one_vector_per_position_needs_no_summary_index():
    """With None the [batch, positions, width] output is kept as it is, and a wrong setting stops with a plain message."""
    torch.manual_seed(1)
    joined = JoinedModel().eval()
    batch = _batch()
    with torch.no_grad(), stage1_hook.capture_vectors(joined, stage1_attr="stage1", summary_index=None) as tap:
        joined(batch)
        by_hand = joined.stage1(batch["continuous"])
    stage1, head_input = tap.rows(mask=batch["mask"])
    assert stage1.shape == (int(batch["mask"].sum()), 24) and torch.equal(stage1, by_hand[batch["mask"]])
    assert head_input.shape == (int(batch["mask"].sum()), 12)
    # The setting of the original layout (position 0) would pick the first transaction of every
    # sequence here. The row count gives it away, and the message names the setting.
    with torch.no_grad(), stage1_hook.capture_vectors(joined, stage1_attr="stage1", summary_index=0) as tap:
        joined(batch)
    with pytest.raises(ValueError, match="SUMMARY_INDEX"):
        tap.rows(mask=batch["mask"])
    collected = stage1_hook.collect(joined, [batch], stage1_attr="stage1", summary_index=None)
    assert collected["stage1"].shape == (int(batch["mask"].sum()), 24)


class JoinedSingleModel(JoinedModel):
    """The same joined stage 1, with a head that scores only the last position of each sequence."""

    def forward(self, batch):
        out, _ = self.seq_encoder(self.stage1(batch["continuous"]))
        return self.head(out[:, -1])


def test_a_wrong_summary_index_stops_with_a_head_that_scores_one_row_per_sequence():
    """With one head input per sequence a wrong setting no longer returns other rows' vectors in silence."""
    torch.manual_seed(2)
    joined = JoinedSingleModel().eval()
    batch = _batch()
    with torch.no_grad(), stage1_hook.capture_vectors(joined, stage1_attr="stage1", summary_index=None) as tap:
        joined(batch)
        by_hand = joined.stage1(batch["continuous"])
    stage1, head_input = tap.rows(mask=batch["mask"])
    last_real = torch.tensor([6, 5, 4, 3])                     # sequence i ends in i padded positions
    assert torch.equal(stage1, by_hand[torch.arange(4), last_real]) and head_input.shape == (4, 12)
    # Position 0 of a [batch, positions, width] output is the first transaction of every sequence.
    with torch.no_grad(), stage1_hook.capture_vectors(joined, stage1_attr="stage1", summary_index=0) as tap:
        joined(batch)
    with pytest.raises(ValueError, match="SUMMARY_INDEX"):
        tap.rows(mask=batch["mask"])
    with pytest.raises(ValueError, match="SUMMARY_INDEX"):
        stage1_hook.collect(joined, [batch], stage1_attr="stage1", summary_index=0)
    # The original layout read with None keeps every token of every row: also stopped, even without a mask.
    torch.manual_seed(1)
    single = TinyTwoStage(every_position=False).eval()
    with torch.no_grad(), stage1_hook.capture_vectors(single, summary_index=None) as tap:
        single(batch)
    with pytest.raises(ValueError, match="SUMMARY_INDEX"):
        tap.rows()
    collected = stage1_hook.collect(single, [batch])
    assert collected["stage1"].shape == (4, 16) and collected["output"].shape == (4, 2)


def test_the_scored_row_of_a_one_row_head_is_the_last_real_position():
    """Without a target position the mask says which row was scored: the last real one of each sequence."""
    torch.manual_seed(1)
    single = TinyTwoStage(every_position=False).eval()
    batch = _batch(seed=5)                                      # padded at the end: sequence i has 7 - i real rows
    with torch.no_grad(), stage1_hook.capture_vectors(single) as tap:
        single(batch)
    per_sequence = tap.stage1[0].reshape(4, 7, 16)
    at_end, _ = tap.rows(mask=batch["mask"])
    assert torch.equal(at_end, per_sequence[torch.arange(4), torch.tensor([6, 5, 4, 3])])
    # A sequence with no real row at all falls back to its last position.
    nothing, _ = tap.rows(mask=torch.zeros(4, 7, dtype=torch.bool))
    assert torch.equal(nothing, per_sequence[:, -1])
    # A whole scoring pass follows the same rule.
    collected = stage1_hook.collect(single, [batch])
    assert np.allclose(collected["stage1"], at_end.numpy(), atol=1e-6)
    # A head that gathers the last real row: the stage-1 vector and the head input are the same transaction.
    torch.manual_seed(4)
    gathering = LastRealRow(every_position=False).eval()
    with torch.no_grad(), stage1_hook.capture_vectors(gathering) as tap:
        gathering(batch)
    with torch.no_grad():
        by_hand = gathering.token_encoder(gathering.tokens(batch["continuous"]))[:, 0].reshape(4, 7, -1)
        history, _ = gathering.seq_encoder(by_hand)
    last = torch.tensor([6, 5, 4, 3])
    stage1, head_input = tap.rows(mask=batch["mask"])
    assert torch.allclose(stage1, by_hand[torch.arange(4), last], atol=1e-6)
    assert torch.allclose(head_input, history[torch.arange(4), last], atol=1e-6)
    # Windows padded at the front keep the scored row in the last position, as the original ones do.
    front = {"continuous": batch["continuous"], "mask": batch["mask"].flip(1)}
    with torch.no_grad(), stage1_hook.capture_vectors(single) as tap:
        single(front)
    at_front, _ = tap.rows(mask=front["mask"])
    assert torch.equal(at_front, tap.stage1[0].reshape(4, 7, 16)[:, -1])
