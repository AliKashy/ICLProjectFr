"""Tests of additions/after_model/_shared.py on made-up data. They double as usage examples."""
import numpy as np
import pandas as pd

from additions import settings
from additions.after_model import _shared as shared
from additions.common import ranking, synthetic, tables, timekeys
from additions.common.timekeys import MISSING_SECOND


def _three_months(n_accounts=60, seed=1):
    """Made-up rows from the first of April to the first of July, with their seconds and calendar months."""
    df = synthetic.make_transactions(n_accounts=n_accounts, days=92, start="2025-04-01", seed=seed)
    secs = timekeys.seconds(df[settings.TIME_COL])
    month = pd.to_datetime(secs, unit="s").to_period("M")
    return df, secs, month


def test_the_cut_value_is_the_lowest_score_inside_the_cut():
    """The frozen cut equals the k-th highest score, for the alert budget and for a wider band."""
    scores = np.random.default_rng(0).normal(size=5000)
    ranked = np.sort(scores)[::-1]
    assert shared.cut_value(scores) == ranked[ranking.cut_size(len(scores)) - 1]
    assert shared.cut_value(scores, per_mille=50) == ranked[ranking.cut_size(len(scores), per_mille=50) - 1]
    # Ten rows are too few for one alert at 0.6 percent, so no score is inside the cut.
    assert shared.cut_value(np.arange(10.0)) == np.inf


def test_month_blocks_have_the_shape_of_an_evaluation_file():
    """Each block holds one calendar month as targets and the month before it as history."""
    _, secs, month = _three_months()
    seen = []
    for rows, is_target in shared.month_blocks(secs, months_back=1):
        target_months = month[rows[is_target]].unique()
        assert len(target_months) == 1
        m = target_months[0]
        expected = np.flatnonzero(np.asarray((month == m) | (month == m - 1)))
        assert np.array_equal(np.sort(rows), expected)
        assert np.array_equal(is_target, np.asarray(month[rows] == m))
        seen.append(m)
    assert seen == sorted(month.unique())
    # Without a look-back there is one block, and every row with a time is a target in it.
    blocks = list(shared.month_blocks(secs, months_back=None))
    assert len(blocks) == 1 and blocks[0][1].all() and len(blocks[0][0]) == len(secs)


def test_by_month_blocks_gives_each_row_the_value_of_its_own_block():
    """A row keeps what was computed in the block where it is a target, and a row with no time stays missing."""
    _, secs, month = _three_months()

    def build(rows):
        return {"first": np.full(len(rows), float(secs[rows].min())), "size": np.full(len(rows), float(len(rows)))}

    out = shared.by_month_blocks(secs, 1, build, ["first", "size"])
    for m in month.unique():
        block = np.asarray((month == m) | (month == m - 1))
        mine = np.asarray(month == m)
        assert (out["first"][mine] == secs[block].min()).all()
        assert (out["size"][mine] == block.sum()).all()

    holed = secs.copy()
    holed[5] = MISSING_SECOND

    def build_holed(rows):
        return {"size": np.full(len(rows), float(len(rows)))}

    assert np.isnan(shared.by_month_blocks(holed, 1, build_holed, ["size"])["size"][5])


def test_full_lookback_is_false_only_in_the_first_month():
    """Rows of the first month of a table have less history than a scored row and are marked."""
    _, secs, month = _three_months()
    assert np.array_equal(shared.full_lookback(secs, months_back=1), np.asarray(month != month.min()))
    # When the data is known to start a month earlier, every row has its full look-back.
    assert shared.full_lookback(secs, months_back=1, data_start="2025-03-01").all()
    assert shared.full_lookback(secs, months_back=None).all()


def test_held_out_accounts_are_whole_accounts():
    """An account is held out with all of its rows or with none, and the same seed gives the same draw."""
    df, _, _ = _three_months(n_accounts=400)
    accounts = df[settings.ACCOUNT_COL].to_numpy()
    held = shared.held_out_accounts(accounts, share=0.25, seed=0)
    per_account = pd.Series(held).groupby(accounts)
    assert (per_account.nunique() == 1).all()
    assert 0.15 < per_account.first().mean() < 0.35
    assert np.array_equal(held, shared.held_out_accounts(accounts, share=0.25, seed=0))
    assert not np.array_equal(held, shared.held_out_accounts(accounts, share=0.25, seed=1))


def test_base_inputs_number_code_values_by_frequency():
    """The most frequent value of the fit table is 0, a value the fit table never held is missing."""
    fit = pd.DataFrame({settings.SCORE_COL: [0.1, 0.2, 0.3, 0.4], "e_0": [1.0, 2.0, 3.0, 4.0],
                        "e_1": [0.0, 0.0, 1.0, 1.0], "num": ["1.5", "x", "2", "3"], "code": ["a", "b", "a", "a"]})
    read = pd.DataFrame({settings.SCORE_COL: [0.5, 0.6], "e_0": [5.0, 6.0], "e_1": [1.0, 0.0],
                         "num": [1.0, 2.0], "code": ["b", "never seen"]})
    fit_matrix, read_matrix, names = shared.base_inputs(fit, read, numeric_cols=["num"], code_cols=["code", "absent"])
    assert names == ["logit", "e_0", "e_1", "num", "code"]
    np.testing.assert_allclose(fit_matrix[:, 0], shared.logits(fit), rtol=1e-6)
    np.testing.assert_array_equal(fit_matrix[:, 3], np.array([1.5, np.nan, 2.0, 3.0], dtype=np.float32))
    np.testing.assert_array_equal(fit_matrix[:, 4], np.array([0.0, 1.0, 0.0, 0.0], dtype=np.float32))
    np.testing.assert_array_equal(read_matrix[:, 4], np.array([1.0, np.nan], dtype=np.float32))


def test_tree_fits_stop_on_held_out_accounts_and_the_margin_follows_the_tree_count():
    """Trees on a helpful column beat their base margin; with zero trees the base margin comes back."""
    df = shared.demo_export(n_accounts=600, seed=5)
    labels, base = shared.fraud_flags(df), shared.logits(df)
    accounts = df[settings.ACCOUNT_COL].to_numpy()
    rng = np.random.default_rng(0)
    helpful = labels + rng.normal(scale=0.5, size=len(labels))    # knows the label; for this test only
    features = np.column_stack([helpful, rng.normal(size=len(labels))])

    booster, info = shared.fit_trees(features, labels, accounts, base_margin=base, stop_on="logloss",
                                     rounds=60, patience=10)
    assert info["fit_rows"] + info["inner_rows"] == len(labels)
    assert info["trees"] > 0 and info["inner_score"] < info["inner_start"]
    margin = shared.tree_margin(booster, info, features, base)
    assert shared.log_loss(labels, margin) < shared.log_loss(labels, base)
    assert np.array_equal(shared.tree_margin(booster, {"trees": 0}, features, base), base)

    # The same fit stopped on capture at the cut: the held-out value is a share of frauds.
    _, by_capture = shared.fit_trees(features, labels, accounts, base_margin=base, stop_on="capture",
                                     rounds=30, patience=10)
    assert 0.0 <= by_capture["inner_score"] <= 1.0 and 0.0 <= by_capture["inner_start"] <= 1.0

    # One line of a results table: the gain is the arm's capture minus the base's, on the same rows.
    line = shared.arm_line("trees", accounts, labels, margin, base, shared.amounts(df), draws=200)
    arm_udr, base_udr = ranking.capture(labels, margin)["udr"], ranking.capture(labels, base)["udr"]
    assert abs(line["udr"] - arm_udr) < 1e-12 and abs(line["base_udr"] - base_udr) < 1e-12
    assert abs(line["gain"] - (arm_udr - base_udr)) < 1e-12
    assert line["low"] <= line["high"] and line["draws"] == 200
    assert line["gain"] > 0
    empty = shared.arm_line("no fraud", accounts, np.zeros(len(labels)), margin, base)
    assert np.isnan(empty["gain"]) and empty["draws"] == 0


def test_an_export_file_is_read_with_its_vectors_and_small_helpers_agree(tmp_path):
    """load_export keeps the named columns and every vector column; the small helpers read them."""
    df = shared.demo_export(n_accounts=40, seed=2, dim=11)
    path = str(tmp_path / "export.parquet")
    tables.write_table(df, path)
    got = shared.load_export(path, extra_columns=[settings.MCC_COL, "a column the file does not have"])
    names = shared.vector_columns(got.columns)
    assert names == [f"{settings.VECTOR_PREFIX}{k}" for k in range(11)]          # e_0 ... e_10, by number
    for column in (settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL, settings.LABEL_COL,
                   settings.AMOUNT_COL, settings.SCORE_COL, settings.MCC_COL):
        assert column in got.columns
    assert "a column the file does not have" not in got.columns
    assert shared.vectors(got).shape == (len(df), 11) and shared.vectors(got[[settings.ID_COL]]) is None

    assert shared.vector_columns(["e_10", "e_2", "e_0", "ex_1", "e_x", "score"], "e_") == ["e_0", "e_2", "e_10"]
    assert shared.fraud_flags(pd.DataFrame({settings.LABEL_COL: [1, 0, 1.0, 2]})).tolist() == [1.0, 0.0, 1.0, 0.0]
    assert shared.fraud_flags(pd.DataFrame({settings.LABEL_COL: ["1", " 1 ", "0", None]})).tolist() == [1.0, 1.0, 0.0, 0.0]
    times = pd.DataFrame({settings.TIME_COL: pd.to_datetime(
        ["2025-05-31 23:59:59", "2025-06-01 00:00:00", "2025-06-30 23:59:59", "2025-07-01 00:00:00"])})
    assert shared.scored_rows(times, start="2025-06-01", end="2025-07-01").tolist() == [False, True, True, False]

    # A row without an account cannot be placed: it gets the missing-time marker.
    holed = df.head(6).copy()
    holed.loc[holed.index[2], settings.ACCOUNT_COL] = None
    _, secs = shared.account_and_time(holed)
    assert secs[2] == MISSING_SECOND and (np.delete(secs, 2) != MISSING_SECOND).all()
