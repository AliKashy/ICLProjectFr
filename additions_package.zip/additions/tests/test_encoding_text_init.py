"""Tests of the text start of a category table.

The stand-in text encoder is compared with a slow count in plain Python, the projection is
checked for keeping distances and for its spread, and the table start is checked for
writing exactly the described rows, for leaving every other row alone, for placing related
values near each other, and for staying an ordinary trainable table.
"""
import numpy as np
import pandas as pd
import torch

from additions import settings
from additions.common import synthetic
from additions.encoding import text_init as ti
from additions.encoding.capped_vocab import text_keys


def _slow_vector(text, dim, ngram_sizes):
    """The stand-in vector of one text, piece by piece with a dictionary."""
    clean = " " + " ".join("".join(ch if ch.isalnum() and ch.isascii() else " " for ch in text.lower()).split()) + " "
    pieces = ["w:" + w for w in clean.split()]
    for n in ngram_sizes:
        pieces += [clean[i:i + n] for i in range(len(clean) - n + 1)]
    slots = {}
    for piece in pieces:
        key = int(text_keys([piece])[0])
        sign = 1.0 if (key >> 40) & 1 else -1.0
        slots[key % dim] = slots.get(key % dim, 0.0) + sign
    v = np.zeros(dim)
    for slot, count in slots.items():
        v[slot] = np.sign(count) * np.log1p(abs(count))
    length = np.linalg.norm(v)
    return v / length if length > 0 else v


def _codes():
    df = synthetic.make_transactions(n_accounts=40, seed=0)
    return sorted(pd.unique(df[settings.MCC_COL]).tolist())


def test_stand_in_encoder_matches_a_slow_count_and_does_not_depend_on_the_other_texts():
    """Each vector equals the piece-by-piece count, has length one, and is the same whatever texts come with it."""
    texts = ["Grocery stores, supermarkets", "Fuel  dispenser (automated)", "a", "", "Eating places & restaurants"]
    out = ti.embed_texts(texts, dim=64)
    assert out.shape == (5, 64) and np.isfinite(out).all()
    for text, row in zip(texts, out):
        assert np.allclose(row, _slow_vector(text, 64, ti.NGRAM_SIZES))
    lengths = np.linalg.norm(out, axis=1)
    assert np.allclose(lengths[[0, 1, 2, 4]], 1.0) and lengths[3] == 0          # no letters: a zero vector
    assert np.array_equal(ti.embed_texts(texts[::-1], dim=64)[::-1], out)
    assert np.array_equal(ti.embed_texts([texts[1]], dim=64)[0], out[1])


def test_projection_keeps_distances_and_has_the_usual_spread():
    """With fewer texts than the width every distance is kept up to one factor, unused columns are zero."""
    rng = np.random.default_rng(0)
    vectors = rng.normal(size=(10, 64))
    rows, kept = ti.initial_rows(vectors, width=48, std=0.7)
    assert rows.shape == (10, 48) and kept == 9                           # at most n - 1 after centring
    assert np.allclose(rows[:, kept:], 0.0)
    assert np.isclose(np.sqrt((rows ** 2).mean()), 0.7) and np.allclose(rows.mean(axis=0), 0.0, atol=1e-9)
    before = np.linalg.norm(vectors[:, None] - vectors[None], axis=-1)
    after = np.linalg.norm(rows[:, None] - rows[None], axis=-1)
    factor = after[0, 1] / before[0, 1]
    assert np.allclose(after, before * factor)
    # Many texts and a narrow width: only `width` components are kept and the spread still holds.
    wide, kept = ti.initial_rows(rng.normal(size=(200, 64)), width=16, std=1.0)
    assert wide.shape == (200, 16) and kept == 16 and np.isclose(np.sqrt((wide ** 2).mean()), 1.0)


def test_projection_does_not_depend_on_the_order_of_the_texts():
    """Reordering the texts reorders the rows and changes nothing else (the signs of the components are fixed)."""
    texts = list(ti.made_up_descriptions(_codes()).values())
    vectors = ti.embed_texts(texts)
    rows, _ = ti.initial_rows(vectors, width=12, std=1.0)
    order = np.random.default_rng(1).permutation(len(texts))
    again, _ = ti.initial_rows(vectors[order], width=12, std=1.0)
    assert np.allclose(again, rows[order], atol=1e-8)


def test_table_start_writes_described_rows_only_and_places_related_values_together(capsys):
    """Described rows are written, the unknown row and undescribed rows are untouched, and kin are neighbours."""
    torch.manual_seed(0)
    codes = _codes()
    vocab = {code: 1 + i for i, code in enumerate(codes)}                 # row 0 is the unknown row
    descriptions = ti.made_up_descriptions(codes[:-5])                     # the last five have no text
    descriptions["99999"] = "a value that the vocabulary does not hold"
    table = torch.nn.Embedding(len(codes) + 1, 16)
    before = table.weight.detach().clone()
    report = ti.init_embedding_from_text(table, vocab, descriptions)
    written = report["written"]
    assert report["described"] == len(codes) - 4 and report["in_table"] == len(codes) - 5
    assert sorted(written.tolist()) == list(range(1, len(codes) - 4))
    after = table.weight.detach()
    untouched = [r for r in range(len(codes) + 1) if r not in set(written.tolist())]
    assert torch.equal(after[untouched], before[untouched])                # unknown row and undescribed rows
    assert bool(torch.isfinite(after).all())
    spread = float(after[written].pow(2).mean().sqrt())
    assert abs(spread - float(before.std())) < 1e-4                        # the spread the table started with
    # Values of one made-up family share words, so each written row's nearest row is of its own family.
    described = [c for c in codes if ti.code_text(c) in descriptions]
    family = {ti.code_text(c): i % 8 for i, c in enumerate(codes[:-5])}
    near = ti.nearest(after[[vocab[c] for c in described]].numpy(), [ti.code_text(c) for c in described])
    same = np.mean([family[ti.code_text(c)] == family[n] for c, n in zip(described, near)])
    assert same >= 0.9
    # The table is still an ordinary trainable table: one backward pass reaches the rows that were read.
    table.zero_grad()
    table(torch.tensor([0, int(written[0])])).pow(2).sum().backward()
    assert float(table.weight.grad[int(written[0])].abs().sum()) > 0
    # With fewer than two usable descriptions nothing changes and one line says so.
    capsys.readouterr()
    small = torch.nn.Embedding(4, 8)
    kept = small.weight.detach().clone()
    assert len(ti.init_embedding_from_text(small, {"a": 1}, {"a": "only one"})["written"]) == 0
    assert torch.equal(small.weight.detach(), kept) and "keeps its random start" in capsys.readouterr().out


def test_codes_meet_as_text_and_files_and_the_command_line_work(tmp_path, capsys):
    """A code stored as a decimal meets the same code as text; descriptions load from csv; the tool prints and writes."""
    table = torch.nn.Embedding(4, 6)
    rows = np.arange(12.0).reshape(2, 6)
    written = ti.copy_into_table(table, {5411.0: 2, "5812": 3}, ["5411", 5812, "0000"], np.vstack([rows, rows[:1]]))
    assert written.tolist() == [2, 3] and torch.equal(table.weight.detach()[2:], torch.tensor(rows, dtype=torch.float32))
    path = tmp_path / "texts.csv"
    pd.DataFrame({"code": ["5411", "5812", "7011", ""], "description": ["grocery", "eating places", "", "x"]}).to_csv(
        path, index=False)
    assert ti.load_descriptions(str(path)) == {"5411": "grocery", "5812": "eating places"}
    capsys.readouterr()
    assert ti.load_descriptions() == {} and "no description file" in capsys.readouterr().out
    out = str(tmp_path / "rows.npz")
    report = ti.main(["--demo", "--width", "8", "--out", out])
    printed = capsys.readouterr().out
    assert "principal components" in printed and "written" in printed and len(report) > 0
    codes, stored = ti.load_rows(out)
    assert stored.shape == (len(codes), 8) and np.isfinite(stored).all()
