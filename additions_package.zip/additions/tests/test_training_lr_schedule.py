"""Tests of the learning-rate plan: the warm-up, the fall to the end value, and what happens past the plan."""
import math

import pytest
import torch

from additions.training import lr_schedule


def test_planned_steps_round_up_the_last_batch_of_a_pass():
    """Rows over rows per step, rounded up, times the passes."""
    assert lr_schedule.planned_steps(1000, 100) == 10
    assert lr_schedule.planned_steps(1001, 100) == 11           # the last, smaller batch is a step too
    assert lr_schedule.planned_steps(1001, 100, passes=2) == 22
    assert lr_schedule.planned_steps(1000, 100, passes=1.5) == 15
    assert lr_schedule.planned_steps(4096 * 7 + 1, 4096) == 8


def test_factor_rises_in_equal_steps_then_falls_along_half_a_cosine():
    """The warm-up is a straight line that reaches 1 on the first step after it; the fall ends at the end value."""
    total, warm = 1000, 100
    values = [lr_schedule.factor(s, total, warm, 0.0) for s in range(total + 1)]
    rises = [values[s + 1] - values[s] for s in range(warm - 1)]
    assert all(abs(r - rises[0]) < 1e-12 for r in rises) and rises[0] > 0
    assert 0 < values[0] < 0.02 and values[warm] == 1.0
    assert all(values[s + 1] <= values[s] + 1e-12 for s in range(warm, total))     # it never rises after the warm-up
    half_way = warm + (total - warm) // 2
    assert abs(values[half_way] - 0.5) < 1e-9                    # half of the wave is half of the peak
    slow = 0.5 * (1.0 + math.cos(math.pi * (700 - warm) / (total - warm)))
    assert abs(values[700] - slow) < 1e-12
    assert values[total] == 0.0 and min(values) >= 0.0


def test_a_run_longer_than_planned_stays_at_the_end_value():
    """Past the last planned step the factor is the end value: it does not rise again and does not go below it."""
    for final in (0.0, 0.01, 0.1):
        beyond = [lr_schedule.factor(s, 500, 50, final) for s in (500, 501, 5_000, 10 ** 9)]
        assert beyond == [final] * 4
        assert lr_schedule.factor(499, 500, 50, final) >= final
    assert abs(lr_schedule.factor(275, 500, 50, 0.1) - (0.1 + 0.9 * 0.5)) < 1e-9


def test_defaults_and_edge_plans():
    """The default warm-up is a share of the plan; a plan shorter than its warm-up still ends at the end value."""
    assert lr_schedule.warmup_length(10_000) == round(lr_schedule.WARMUP_SHARE * 10_000)
    assert lr_schedule.warmup_length(10_000, 250) == 250
    assert lr_schedule.warmup_length(100, 500) == 99             # always below the plan's end
    assert lr_schedule.factor(0, 0) == 1.0                       # no plan: the rate is left as it is
    assert lr_schedule.factor(0, 1, 0, 0.0) == 1.0 and lr_schedule.factor(1, 1, 0, 0.0) == 0.0
    assert lr_schedule.factor(99, 100, 500, 0.0) == pytest.approx(1.0, abs=0.02)
    assert lr_schedule.factor(100, 100, 500, 0.0) == 0.0


def test_scheduler_moves_the_rate_of_a_torch_optimizer_step_by_step():
    """The optimizer's own rate is the peak; after s steps it is the peak times the factor of step s."""
    weights = torch.nn.Parameter(torch.zeros(3))
    optimizer = torch.optim.AdamW([weights], lr=3e-4)
    scheduler = lr_schedule.schedule(optimizer, total_steps=200, warmup_steps=20, final_ratio=0.0)
    seen = []
    for _ in range(205):
        seen.append(optimizer.param_groups[0]["lr"])
        optimizer.step()
        scheduler.step()
    for step in (0, 5, 19, 20, 110, 199, 200, 204):
        assert seen[step] == pytest.approx(3e-4 * lr_schedule.factor(step, 200, 20, 0.0), rel=1e-9, abs=1e-15)
    assert max(seen) == pytest.approx(3e-4) and seen[204] == 0.0


def test_lightning_entry_asks_for_a_change_at_every_step():
    """The returned dict holds the optimizer and a scheduler with the interval 'step'."""
    weights = torch.nn.Parameter(torch.zeros(2))
    optimizer = torch.optim.AdamW([weights], lr=1e-3)
    entry = lr_schedule.lightning_entry(optimizer, total_steps=50)
    assert entry["optimizer"] is optimizer
    assert entry["lr_scheduler"]["interval"] == "step" and entry["lr_scheduler"]["frequency"] == 1
    assert isinstance(entry["lr_scheduler"]["scheduler"], torch.optim.lr_scheduler.LambdaLR)
