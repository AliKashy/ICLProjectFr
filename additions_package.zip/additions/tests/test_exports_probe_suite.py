"""Tests of the linear probes on frozen export columns.

The targets are compared with a plain look at each account. The probes are checked to be read
only by fits that never saw the row's account, the label curve to read the same rows at every
share, and the two-checkpoint read to say "nothing changed" when the same table is given twice.
"""
import numpy as np
import pandas as pd
import pytest

from additions import settings
from additions.common import ranking, synthetic, tables, timekeys
from additions.exports import _shared, probe_suite


def _table(n_accounts, seed):
    """Made-up whole account histories with a score, and enough fraud accounts for five folds."""
    made = synthetic.make_transactions(n_accounts=n_accounts, seed=seed, fraud_account_share=0.25)
    return synthetic.make_scores(made, seed=seed).reset_index(drop=True)


@pytest.fixture(scope="module")
def planted():
    """A table whose vector holds two signals and whose other columns hold a weaker copy of one of them.

    e_0 follows the fraud label, e_1 follows "another fraud of the account within 24 hours",
    the remaining coordinates are noise. other_0 follows the look-ahead target more weakly.
    """
    df = _table(500, 3)
    rng = np.random.default_rng(11)
    targets = probe_suite.build_targets(df)
    fraud = targets[probe_suite.FRAUD][0].astype(float)
    follows = targets["fraud within 24h"][0].astype(float)
    df[f"{settings.VECTOR_PREFIX}0"] = fraud + rng.normal(size=len(df))
    df[f"{settings.VECTOR_PREFIX}1"] = 2.5 * follows + rng.normal(size=len(df))
    for j in range(2, 6):
        df[f"{settings.VECTOR_PREFIX}{j}"] = rng.normal(size=len(df))
    df["other_0"] = 0.8 * follows + rng.normal(size=len(df))
    df["other_1"] = rng.normal(size=len(df))
    return df


@pytest.fixture(scope="module")
def suite(planted):
    """The whole read of the planted table, with a short label curve and few bootstrap draws."""
    return probe_suite.run_suite(planted, shares=(1.0, 0.5, 0.004), draws=200, other_prefix="other_")


def test_targets_agree_with_a_plain_look_at_each_account():
    """Each target is recomputed row by row from the account's other rows."""
    df = _table(60, 7)
    targets = probe_suite.build_targets(df)
    account = df[settings.ACCOUNT_COL].to_numpy()
    secs = timekeys.seconds(df[settings.TIME_COL])
    fraud = df[settings.LABEL_COL].to_numpy() == settings.POSITIVE_LABEL
    last = secs.max()
    first_slow = np.zeros(len(df), dtype=bool)
    follows_slow = {name: np.zeros(len(df), dtype=bool) for name, _ in probe_suite.AHEAD}
    for i in range(len(df)):
        mine = (account == account[i]) & fraud
        if fraud[i]:
            before = mine & (secs < secs[i]) & (secs >= secs[i] - probe_suite.RUN_GAP)
            first_slow[i] = not before.any()
        for name, window in probe_suite.AHEAD:
            follows_slow[name][i] = (mine & (secs > secs[i]) & (secs <= secs[i] + window)).any()
    event, usable = targets[probe_suite.FRAUD]
    assert (event == fraud).all() and usable.all()
    event, usable = targets[probe_suite.FIRST_OF_RUN]
    past_known = secs >= secs.min() + probe_suite.RUN_GAP                # the look-back stays inside the table
    assert (event == first_slow).all() and (usable == (~fraud | (first_slow & past_known))).all()
    assert 0 < first_slow.sum() < fraud.sum()                   # the made-up frauds come in runs
    for name, window in probe_suite.AHEAD:
        event, usable = targets[name]
        assert (event == follows_slow[name]).all()
        assert (usable == (secs <= last - window)).all()        # a window that runs past the table is unknown
    event, usable = targets[probe_suite.DECLINE]
    reason = df[settings.REASON_COL].astype(str).to_numpy()
    assert (event == ~np.isin(reason, settings.APPROVED_REASONS)).all() and usable.all()


def test_a_table_without_a_response_code_has_no_decline_target(capsys):
    """The decline target is skipped with one printed line; the others stay."""
    df = _table(40, 2).drop(columns=[settings.REASON_COL])
    targets = probe_suite.build_targets(df)
    assert probe_suite.DECLINE not in targets and probe_suite.FRAUD in targets
    assert "skipped" in capsys.readouterr().out


def test_sets_hold_the_columns_they_name_and_never_a_label(planted):
    """The four sets, in order; without the other model's columns only two remain."""
    sets = probe_suite.column_sets(planted, other_prefix="other_")
    assert list(sets) == list(probe_suite.SETS)
    assert sets["score"] == [settings.SCORE_COL] and sets["other"] == ["other_0", "other_1"]
    assert sets["vector"] == [f"{settings.VECTOR_PREFIX}{j}" for j in range(6)]
    assert sets["vector + other"] == sets["vector"] + sets["other"]
    assert all(settings.LABEL_COL not in columns for columns in sets.values())
    assert list(probe_suite.column_sets(planted)) == ["score", "vector"]
    assert probe_suite.column_sets(planted, other_columns=["other_1", "not there"])["other"] == ["other_1"]
    score_input = probe_suite.set_matrix(planted, "score", sets["score"])
    assert score_input.shape == (len(planted), 1)
    assert np.allclose(score_input[:, 0], ranking.to_logit(planted[settings.SCORE_COL].to_numpy(), "probability"))


def test_every_row_is_read_by_a_fit_that_never_saw_its_account():
    """The out-of-fold values equal fold-by-fold fits made by hand, and an account's noise cannot be memorised."""
    rng = np.random.default_rng(5)
    n_accounts, per_account = 60, 40
    account = np.repeat(np.arange(n_accounts), per_account)
    of_account = rng.normal(size=(n_accounts, 30))               # thirty numbers that only name the account
    x = of_account[account] + 0.01 * rng.normal(size=(len(account), 30))
    event = (rng.random(n_accounts) < 0.5)[account]              # a target that is pure chance per account
    fold = probe_suite.account_folds(account, 5, seed=1)
    assert all(len(np.unique(fold[account == a])) == 1 for a in range(n_accounts))
    everything = np.ones(len(account), dtype=bool)
    values, fitted = probe_suite.out_of_fold(x, event, everything, fold, l2=1e-3)
    assert fitted == 5 and np.isfinite(values).all()
    for k in range(5):
        by_hand = _shared.fit_logistic(x[fold != k], event[fold != k], 1e-3)
        assert np.allclose(values[fold == k], _shared.apply_logistic(x[fold == k], by_hand))
    in_sample = _shared.apply_logistic(x, _shared.fit_logistic(x, event, 1e-3))
    assert probe_suite.area_under_curve(event, in_sample) > 0.95     # a fit that sees the account knows it
    assert 0.25 < probe_suite.area_under_curve(event, values) < 0.75  # a fit that does not is left with chance
    # Rows outside the fit rows are still read, but never fitted on.
    half = account % 2 == 0
    values_half, _ = probe_suite.out_of_fold(x, event, half, fold, l2=1e-3)
    by_hand = _shared.fit_logistic(x[half & (fold != 0)], event[half & (fold != 0)], 1e-3)
    assert np.allclose(values_half[fold == 0], _shared.apply_logistic(x[fold == 0], by_hand))


def test_a_fold_that_cannot_be_fitted_gets_missing_values(capsys):
    """When the fit rows of a fold hold one outcome only, its rows get no value and the count says so."""
    x = np.arange(40, dtype=float)[:, None]
    event = np.zeros(40, dtype=bool)
    event[:5] = True                                             # every event sits in fold 0
    fold = np.repeat([0, 1], 20)
    values, fitted = probe_suite.out_of_fold(x, event, np.ones(40, dtype=bool), fold)
    assert fitted == 1 and np.isnan(values[fold == 0]).all() and np.isfinite(values[fold == 1]).all()
    assert "only one outcome" in capsys.readouterr().out


def test_the_accounts_of_a_smaller_share_are_among_those_of_a_larger_one():
    """One draw per account orders the accounts, so the shares are nested and a share of one holds everything."""
    account = np.repeat(np.arange(400), 3)
    masks = {share: probe_suite.account_share(account, share, seed=4) for share in (1.0, 0.5, 0.1, 0.0)}
    assert masks[1.0].all() and not masks[0.0].any()
    assert not (masks[0.1] & ~masks[0.5]).any()
    assert 0.4 < masks[0.5].mean() < 0.6 and 0.05 < masks[0.1].mean() < 0.16
    for share in (0.5, 0.1):
        assert all(len(np.unique(masks[share][account == a])) == 1 for a in range(0, 400, 37))


def test_area_under_curve_and_the_read_agree_with_slow_definitions():
    """The area is the share of (event, other) pairs in the right order, ties as half, missing values last."""
    rng = np.random.default_rng(2)
    values = rng.normal(size=300).round(1)
    values[:6] = np.nan
    event = rng.random(300) < 0.2
    filled = np.where(np.isnan(values), -np.inf, values)
    wins = (filled[event][:, None] > filled[~event][None, :]).sum() + 0.5 * (filled[event][:, None] == filled[~event][None, :]).sum()
    assert np.isclose(probe_suite.area_under_curve(event, values), wins / (event.sum() * (~event).sum()))
    assert probe_suite.area_under_curve(np.zeros(5, dtype=bool), np.arange(5.0)) is None
    read_rows = rng.random(300) < 0.8
    amounts = rng.lognormal(3.0, 1.0, 300)
    line = probe_suite.read_line(event, values, read_rows, amounts, per_mille=50)
    slow = ranking.capture(event[read_rows].astype(float), filled[read_rows], amounts[read_rows], 50)
    assert line["rows"] == read_rows.sum() and line["events"] == event[read_rows].sum()
    assert np.isclose(line["capture"], slow["udr"]) and np.isclose(line["vdr"], slow["vdr"])
    assert np.isclose(line["rate"], event[read_rows].mean())
    assert "vdr" not in probe_suite.read_line(event, values, read_rows, None, per_mille=50)


def test_a_vector_with_a_second_signal_beats_the_score_and_the_other_columns_on_that_target(suite):
    """The planted look-ahead signal shows on its target, with an interval that is clear of zero."""
    table, gains = suite["targets"], suite["gains"]
    assert set(table["target"]) == {probe_suite.FRAUD, probe_suite.FIRST_OF_RUN, "fraud within 24h",
                                    "fraud within 7d", probe_suite.DECLINE}
    assert (table["folds_fitted"] == probe_suite.FOLDS).all()
    ahead = table[table["target"] == "fraud within 24h"].set_index("columns")
    assert ahead.loc["vector", "ap"] > ahead.loc["score", "ap"]
    assert ahead.loc["vector", "ap"] > ahead.loc["other", "ap"]
    assert ahead.loc["vector + other", "ap"] >= ahead.loc["other", "ap"]
    line = gains[(gains["target"] == "fraud within 24h") & (gains["first"] == "vector") & (gains["second"] == "other")].iloc[0]
    assert line["gain"] > 0 and line["low"] > 0
    assert np.isclose(line["gain"], ahead.loc["vector", "capture"] - ahead.loc["other", "capture"])
    assert np.isclose(line["first_capture"], ahead.loc["vector", "capture"])
    # The dollar figure belongs to the fraud target alone.
    assert table.loc[table["target"] == probe_suite.FRAUD, "vdr"].notna().all()
    assert table.loc[table["target"] != probe_suite.FRAUD, "vdr"].isna().all()
    # The first-fraud target is read without the later frauds of a run.
    fraud_rows = table[table["target"] == probe_suite.FRAUD].iloc[0]
    first_rows = table[table["target"] == probe_suite.FIRST_OF_RUN].iloc[0]
    assert first_rows["rows"] == fraud_rows["rows"] - (fraud_rows["events"] - first_rows["events"])


def test_the_written_rows_hold_one_probe_column_per_target_and_set(planted, suite):
    """The out-of-fold values of every probe are kept beside id, account and time, in the table's row order."""
    rows = suite["rows"]
    assert len(rows) == len(planted) and (rows[settings.ID_COL].to_numpy() == planted[settings.ID_COL].to_numpy()).all()
    name = probe_suite.probe_column("fraud within 24h", "vector + other")
    assert name == "probe__fraud_within_24h__vector_and_other" and name in rows.columns
    assert sum(c.startswith("probe__") for c in rows.columns) == 5 * 4
    line = suite["targets"].set_index(["target", "columns"]).loc[(probe_suite.FRAUD, "vector")]
    y = (planted[settings.LABEL_COL].to_numpy() == settings.POSITIVE_LABEL).astype(float)
    again = ranking.capture(y, rows[probe_suite.probe_column(probe_suite.FRAUD, "vector")].to_numpy())
    assert np.isclose(line["capture"], again["udr"])


def test_label_curve_reads_the_same_rows_at_every_share(planted, suite):
    """Fewer accounts to fit on, the same rows to read; a share that cannot be fitted has no figures."""
    curve, gains = suite["curve"], suite["curve_gains"]
    assert set(curve["share"]) == {1.0, 0.5, 0.004}
    assert curve["rows"].nunique() == 1 and curve["events"].nunique() == 1
    by_share = curve.drop_duplicates("share").set_index("share")
    assert by_share.loc[1.0, "fit_events"] > by_share.loc[0.5, "fit_events"] > by_share.loc[0.004, "fit_events"]
    assert by_share.loc[1.0, "fit_accounts"] > by_share.loc[0.5, "fit_accounts"]
    # At a share of one the curve is the fraud line of the first table.
    full = curve[curve["share"] == 1.0].set_index("columns")
    table = suite["targets"][suite["targets"]["target"] == probe_suite.FRAUD].set_index("columns")
    assert np.allclose(full["capture"], table.loc[full.index, "capture"]) and np.allclose(full["ap"], table.loc[full.index, "ap"])
    # Two accounts in a thousand hold no fraud in some fold: the figures are left empty, the sizes stay.
    tiny = curve[curve["share"] == 0.004]
    assert (tiny["folds_fitted"] < probe_suite.FOLDS).all()
    assert tiny["capture"].isna().all() and tiny["ap"].isna().all() and tiny["rows"].notna().all()
    assert set(gains["share"]) == {1.0, 0.5}
    # The fit rows of a smaller share are a subset, so a probe fitted by hand on them gives the curve's values.
    event, usable = probe_suite.build_targets(planted)[probe_suite.FRAUD]
    fold = probe_suite.account_folds(planted[settings.ACCOUNT_COL], None, 0)
    fit_rows = usable & probe_suite.account_share(planted[settings.ACCOUNT_COL], 0.5, 1)
    x = probe_suite.set_matrix(planted, "vector", probe_suite.column_sets(planted)["vector"])
    values, _ = probe_suite.out_of_fold(x, event, fit_rows, fold)
    half = curve[(curve["share"] == 0.5) & (curve["columns"] == "vector")].iloc[0]
    assert np.isclose(half["capture"], probe_suite.read_line(event, values, usable)["capture"])


def test_the_same_table_twice_is_two_checkpoints_that_agree(planted, capsys):
    """Given the same rows in another order, every alert is shared and the carried probe loses nothing."""
    shuffled = planted.sample(frac=1.0, random_state=3).reset_index(drop=True)
    scores, probes, gains = probe_suite.two_checkpoints(planted, shuffled, draws=100)
    line = scores.iloc[0]
    assert line["share_of_alerts_shared"] == 1.0 and line["frauds_first_only"] == 0 and line["frauds_second_only"] == 0
    assert np.isclose(line["rank_correlation"], 1.0) and np.isclose(line["capture_first"], line["capture_second"])
    by_name = probes.set_index("probe")
    assert np.isclose(by_name.loc[probe_suite.SAME, "capture"], by_name.loc[probe_suite.CARRIED, "capture"])
    assert np.isclose(by_name.loc[probe_suite.CARRIED, "ap"], by_name.loc[probe_suite.REFITTED, "ap"])
    assert np.allclose(gains["gain"], 0.0)
    assert "left out" not in capsys.readouterr().out


def test_a_probe_does_not_carry_over_to_a_vector_that_was_turned_around(planted, capsys):
    """A second checkpoint whose coordinates changed sign needs a new fit; rows it lacks are left out."""
    names = _shared.vector_columns(planted, settings.VECTOR_PREFIX)
    turned = planted.copy()
    turned[names] = -turned[names]
    turned = turned.iloc[: len(turned) - 50]                     # the second table lacks the last fifty rows
    turned[settings.ID_COL] = turned[settings.ID_COL].astype(str) if pd.api.types.is_numeric_dtype(
        turned[settings.ID_COL]) else turned[settings.ID_COL]   # and stores its ids in another form
    scores, probes, gains = probe_suite.two_checkpoints(planted, turned, draws=100)
    assert "50 of" in capsys.readouterr().out
    assert scores.iloc[0]["rows"] == len(planted) - 50
    by_name = probes.set_index("probe")
    # Fitted again, the turned vector is worth exactly what the first one was; carried over, it is worth less.
    assert np.isclose(by_name.loc[probe_suite.REFITTED, "ap"], by_name.loc[probe_suite.SAME, "ap"])
    assert by_name.loc[probe_suite.CARRIED, "ap"] < 0.5 * by_name.loc[probe_suite.REFITTED, "ap"]
    lost = gains[(gains["first"] == probe_suite.CARRIED) & (gains["second"] == probe_suite.REFITTED)].iloc[0]
    assert lost["gain"] < 0 and lost["high"] < 0
    # Without vector columns in the second table only the scores are compared.
    scores, probes, gains = probe_suite.two_checkpoints(planted, turned.drop(columns=names), draws=50)
    assert len(scores) == 1 and len(probes) == 0 and len(gains) == 0
    assert "carried probe is skipped" in capsys.readouterr().out


def test_tool_reads_files_and_writes_the_probe_values(planted, tmp_path, capsys):
    """The tool prints one table per read and writes the out-of-fold values; the demo runs end to end."""
    export_path = tables.write_table(planted, str(tmp_path / "export.parquet"))
    second_path = tables.write_table(planted.sample(frac=1.0, random_state=1), str(tmp_path / "second.parquet"))
    out_path = str(tmp_path / "probes.parquet")
    result = probe_suite.main(["--export", export_path, "--second", second_path, "--other-prefix", "other_",
                               "--label-shares", "1", "0.5", "--targets", "fraud", "fraud within 24h",
                               "--folds", "3", "--draws", "50", "--out", out_path])
    printed = capsys.readouterr().out
    for title in ("Several targets", "Fewer labels", "Two checkpoints: the two scores", "what the carried probe loses"):
        assert title in printed
    assert set(result["targets"]["target"]) == {"fraud", "fraud within 24h"}
    assert (result["targets"]["folds_fitted"] == 3).all()
    # Only the scored month is fitted and read; the rows before it only serve the targets.
    secs = timekeys.seconds(planted[settings.TIME_COL])
    in_month = _shared.in_period(secs, settings.TARGET_START, settings.TARGET_END)
    assert result["targets"].iloc[0]["rows"] == in_month.sum() < len(planted)
    saved = tables.read_columns(out_path)
    assert len(saved) == len(planted) and probe_suite.probe_column("fraud", "vector") in saved.columns
    # The curve can be switched off, and a table outside the scored month says so instead of reading nothing.
    quiet = probe_suite.main(["--export", export_path, "--label-shares", "--targets", "fraud", "--draws", "50", "--all-rows"])
    assert len(quiet["curve"]) == 0 and quiet["targets"].iloc[0]["rows"] == len(planted)
    assert probe_suite.main(["--export", export_path, "--start", "2031-01-01", "--end", "2031-02-01"]) is None
    assert "no row of the table falls in the scored month" in capsys.readouterr().out
    demo = probe_suite.main(["--demo", "--draws", "50", "--folds", "3"])
    assert len(demo["targets"]) > 0 and len(demo["checkpoint_probes"]) == 3


def test_a_first_fraud_whose_look_back_leaves_the_table_is_not_read():
    """A fraud in the first RUN_GAP seconds of the table may continue a run the table does not hold."""
    day = 86_400
    no = "N" if settings.POSITIVE_LABEL != "N" else "M"
    df = pd.DataFrame({
        settings.ACCOUNT_COL: ["a", "a", "b", "c", "c"],
        settings.TIME_COL: pd.to_datetime([0, 2 * day, 10 * day, day, 12 * day], unit="s"),
        settings.LABEL_COL: [settings.POSITIVE_LABEL, settings.POSITIVE_LABEL, settings.POSITIVE_LABEL, no, no],
    })
    event, usable = probe_suite.build_targets(df)[probe_suite.FIRST_OF_RUN]
    assert event.tolist() == [True, False, True, False, False]
    # Row 0 opens the table: its past is cut off, so it is neither a first fraud nor a later one.
    assert usable.tolist() == [False, False, True, True, True]


def test_every_set_is_read_on_the_same_rows_when_some_inputs_are_missing(planted, capsys):
    """A row that misses an input of one set is left out of every set, and the pair gains read the same rows."""
    holes = planted.copy()
    gone = np.arange(len(holes)) % 9 == 0
    holes.loc[gone, "other_0"] = np.nan
    result = probe_suite.run_suite(holes, shares=(1.0,), draws=50, other_prefix="other_", target_names=["fraud"])
    assert "miss an input" in capsys.readouterr().out
    table = result["targets"].set_index("columns")
    assert (table["rows"] == len(holes) - gone.sum()).all() and table["capture"].notna().all()
    assert (result["curve"]["rows"] == len(holes) - gone.sum()).all()
    line = result["gains"][(result["gains"]["first"] == "vector") & (result["gains"]["second"] == "other")].iloc[0]
    assert np.isclose(line["gain"], table.loc["vector", "capture"] - table.loc["other", "capture"])


def test_the_command_line_stops_on_a_wrong_name_or_number_before_any_fit(tmp_path):
    """Unknown targets, too few folds and shares outside (0, 1] stop at once."""
    for wrong in (["--targets", "fruad"], ["--curve-target", "nothing"], ["--folds", "1"], ["--label-shares", "0"],
                  ["--label-shares", "2"]):
        with pytest.raises(SystemExit):
            probe_suite.main(["--export", str(tmp_path / "never_read.parquet"), *wrong])
