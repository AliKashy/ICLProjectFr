"""Tests of the history census.

The three counts per row are compared with a loop over the earlier rows of the account, the
time rule is checked on rows that share a second, and the tables are checked against plain shares.
"""
import numpy as np
import pandas as pd
import pytest

from additions import settings
from additions.common import synthetic, tables, timekeys
from additions.reads import _rows, history_census


@pytest.fixture(scope="module")
def table():
    """Made-up rows in which many rows share a second with the row before them."""
    return synthetic.make_transactions(n_accounts=60, seed=5, tie_share=0.2)


def _frame(rows):
    """A tiny table from (account, second) pairs, with the column names of settings; None is a missing time."""
    start = pd.Timestamp(settings.TARGET_START)
    return pd.DataFrame({
        settings.ACCOUNT_COL: [r[0] for r in rows],
        settings.TIME_COL: [pd.NaT if r[1] is None else start + pd.Timedelta(seconds=r[1]) for r in rows],
        settings.LABEL_COL: 0,
    })


def test_counts_match_a_loop_over_the_earlier_rows(table):
    """Earlier rows, distinct earlier seconds and days covered agree with the slow definition."""
    account = table[settings.ACCOUNT_COL].to_numpy()
    secs = timekeys.seconds(table[settings.TIME_COL])
    depth = history_census.history_depth(table)
    assert list(depth.columns) == ["earlier_rows", "earlier_seconds", "days_covered"] and len(depth) == len(table)
    for i in range(0, len(table), 2):
        earlier = secs[(account == account[i]) & (secs < secs[i])]
        assert depth.loc[i, "earlier_rows"] == len(earlier)
        assert depth.loc[i, "earlier_seconds"] == len(set(earlier.tolist()))
        days = (secs[i] - earlier.min()) / 86_400.0 if len(earlier) else 0.0
        assert np.isclose(depth.loc[i, "days_covered"], days)
    assert (depth["earlier_seconds"] <= depth["earlier_rows"]).all()
    assert (depth["earlier_seconds"] < depth["earlier_rows"]).any()   # the ties make the two counts differ


def test_rows_of_the_same_second_do_not_count_for_each_other():
    """Two rows in one second have the same history, and both become one step for the rows after them."""
    df = _frame([("a", 0), ("a", 0), ("a", 10), ("a", 10), ("a", 86_400), ("b", 5), ("a", None)])
    depth = history_census.history_depth(df)
    assert depth["earlier_rows"].tolist() == [0, 0, 2, 2, 4, 0, 0]
    assert depth["earlier_seconds"].tolist() == [0, 0, 1, 1, 2, 0, 0]
    assert np.allclose(depth["days_covered"], [0, 0, 10 / 86_400, 10 / 86_400, 1.0, 0, 0])


def test_later_rows_do_not_change_the_counts_of_earlier_rows(table):
    """Cutting the table off at a point in time leaves the counts of every earlier row as they were."""
    secs = timekeys.seconds(table[settings.TIME_COL])
    keep = secs <= np.median(secs)
    full = history_census.history_depth(table)[keep].reset_index(drop=True)
    part = history_census.history_depth(table[keep].reset_index(drop=True))
    pd.testing.assert_frame_equal(full, part)


def test_tables_are_plain_shares_of_the_scored_rows(table):
    """The share with at least L steps falls as L grows and equals a direct count; the days add up."""
    depth = history_census.history_depth(table)
    scored = _rows.in_scored_month(table)
    fraud = _rows.fraud_flags(table)
    lengths = (1, 20, 40, 80, 400)
    shares = history_census.depth_table(depth, scored, fraud, lengths)
    assert shares["length"].tolist() == list(lengths)
    is_fraud = scored & (fraud > 0)
    for line in shares.to_dict("records"):
        enough = depth["earlier_seconds"].to_numpy() >= line["length"]
        assert np.isclose(line["rows_with_seconds"], enough[scored].mean())
        assert np.isclose(line["frauds_with_seconds"], enough[is_fraud].mean())
        assert np.isclose(line["rows_with_rows"], (depth["earlier_rows"].to_numpy() >= line["length"])[scored].mean())
        assert line["rows_with_rows"] >= line["rows_with_seconds"]   # a second holds at least one row
    assert shares["rows_with_seconds"].is_monotonic_decreasing and shares["rows_with_seconds"].iloc[-1] == 0
    assert 0 < shares["rows_with_seconds"].iloc[2] < 1               # the middle of the table is informative
    assert len(history_census.depth_table(depth, scored, fraud)) == len(history_census.HISTORY_LENGTHS)

    days = history_census.days_table(depth, scored, fraud)
    assert days["rows"].sum() == scored.sum() and days["frauds"].sum() == is_fraud.sum()
    assert np.isclose(days["share_of_rows"].sum(), 1.0)
    covered = depth["days_covered"].to_numpy()[scored]
    assert days.loc[days["days"] == "31 to 45 days", "rows"].iloc[0] == ((covered >= 31) & (covered < 45)).sum()
    # A scored row cannot have more history than the file holds before it.
    span = (pd.Timestamp(settings.TARGET_END) - pd.Timestamp(settings.EVAL_HISTORY_START)).days
    assert covered.max() <= span

    quantiles = history_census.quantile_table(depth, scored).set_index("count")
    median = np.quantile(depth["earlier_seconds"].to_numpy()[scored], 0.5)
    assert np.isclose(quantiles.loc["earlier_seconds", "q50"], median)
    assert quantiles.loc["days_covered", "q10"] <= quantiles.loc["days_covered", "q90"]


def test_tool_runs_on_raw_files_and_on_a_prediction_file(table, tmp_path, capsys):
    """The tool reads four columns, prints the three tables and writes the counts of the scored rows."""
    df = table.assign(extra="x")
    synthetic.write_files(df, tmp_path / "raw", 2, first_number=3)
    out = str(tmp_path / "depth.parquet")
    history_census.main(["--base", str(tmp_path / "raw"), "--files", "3-4", "--lengths", "20", "60", "--out", out])
    printed = capsys.readouterr().out
    for title in ("Share of scored rows and frauds", "Days between the account's first row", "Quantiles"):
        assert title in printed
    written = tables.read_columns(out).set_index(settings.ID_COL)
    scored = _rows.in_scored_month(table)
    expected = history_census.history_depth(table)[scored]
    expected.index = table[settings.ID_COL].to_numpy()[scored]
    assert len(written) == scored.sum()
    assert (written["earlier_seconds"].reindex(expected.index) == expected["earlier_seconds"]).all()
    # The same answer comes from one file that holds every row, such as a prediction file.
    whole = tables.write_table(df, str(tmp_path / "whole.parquet"))
    history_census.main(["--pred", whole, "--lengths", "20", "60"])
    tables_from_raw = printed.split("Share of scored rows")[1].split("wrote")[0]
    assert capsys.readouterr().out.split("Share of scored rows")[1] == tables_from_raw
    history_census.main([])
    assert "nothing to read" in capsys.readouterr().out
    # The label only splits the tables: a file without it still gives the shares of the rows.
    unlabelled = tables.write_table(table.drop(columns=[settings.LABEL_COL]), str(tmp_path / "unlabelled.parquet"))
    history_census.main(["--pred", unlabelled])
    printed = capsys.readouterr().out
    assert "fraud label" in printed and "Share of scored rows and frauds" in printed
