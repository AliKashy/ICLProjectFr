"""Tests of unknown-value dropout.

The swap is checked for its rate per field, for touching nothing but the entries it swaps,
for never running at scoring, and for making the unknown row of a code table learn. The
scoring-side replacement is compared with a slow loop over rows and fields.
"""
import numpy as np
import pandas as pd
import torch

from additions import settings
from additions.common import synthetic, timekeys
from additions.encoding import unknown_dropout as ud


def _codes(n_accounts=150, seed=0):
    """Made-up code fields as whole numbers [rows, K], with 0 kept free as the unknown row of every table."""
    df = synthetic.make_transactions(n_accounts=n_accounts, seed=seed)
    names = [c for c in settings.CODE_COLS if c in df.columns]
    columns = [timekeys.codes(df[c]) + 1 for c in names]                # 1, 2, ... are real values
    month = pd.to_datetime(df[settings.TIME_COL]).dt.month.to_numpy()   # a calendar field with real month numbers
    flag = df[settings.AMOUNT_COL].isna().to_numpy().astype(np.int64)   # a yes/no flag: its code 0 is a real value
    codes = np.column_stack(columns + [month, flag])
    return codes, names + ["month", settings.AMOUNT_COL + "_isna"]


def test_rates_follow_the_field_names():
    """Ordinary fields get the small rate, calendar fields the higher one, flags without an unknown row none."""
    codes, names = _codes(20)
    rates = ud.field_rates(names)
    assert rates.shape == (codes.shape[1],)
    assert (rates[:-2] == ud.DEFAULT_RATE).all() and rates[-2] == ud.CALENDAR_RATE and rates[-1] == 0.0
    changed = ud.field_rates(names, rate=0.1, calendar_rate=0.5, overrides={names[0]: 0.4, names[-1]: 0.2})
    assert changed[0] == 0.4 and changed[1] == 0.1 and changed[-2] == 0.5 and changed[-1] == 0.2
    assert len(ud.field_rates()) == len(settings.CODE_COLS)             # the default list is the one in settings


def test_swap_rate_per_field_and_nothing_else_changes():
    """Each field is swapped at its own rate, every swapped entry is the unknown index, all others are untouched."""
    codes, names = _codes()
    rates = ud.field_rates(names)
    before = codes.copy()
    out = ud.unknown_dropout_numpy(codes, rates, rng=1)
    assert np.array_equal(codes, before)                                # the input is not changed
    assert out.shape == codes.shape and out.dtype == codes.dtype
    changed = out != codes
    assert (out[changed] == ud.UNKNOWN_INDEX).all()
    n = len(codes)
    for k, rate in enumerate(rates):                                    # within four standard errors of the rate
        assert abs(changed[:, k].mean() - rate) <= 4 * np.sqrt(rate * (1 - rate) / n) + 1e-12
    assert not changed[:, -1].any()                                     # the flag has no unknown row
    # Rate 1 swaps every entry, rate 0 none, and the same seed gives the same draw.
    assert (ud.unknown_dropout_numpy(codes, 1.0, rng=0) == ud.UNKNOWN_INDEX).all()
    assert np.array_equal(ud.unknown_dropout_numpy(codes, 0.0, rng=0), codes)
    assert np.array_equal(ud.unknown_dropout_numpy(codes, rates, rng=1), out)
    # The torch version has the same rates and the same guarantees.
    tensor = torch.as_tensor(codes)
    swapped = ud.unknown_dropout_torch(tensor, rates, generator=torch.Generator().manual_seed(1))
    moved = (swapped != tensor).numpy()
    assert swapped.dtype == tensor.dtype and bool((swapped[torch.as_tensor(moved)] == ud.UNKNOWN_INDEX).all())
    for k, rate in enumerate(rates):
        assert abs(moved[:, k].mean() - rate) <= 4 * np.sqrt(rate * (1 - rate) / n) + 1e-12


def test_an_unknown_index_per_field_and_padding_are_respected():
    """Each field can have its own unknown row, and padded positions are never swapped."""
    codes, _ = _codes(40)
    k = codes.shape[1]
    batch = codes[: 6 * 10].reshape(6, 10, k)
    real = np.ones((6, 10), dtype=bool)
    real[:, 7:] = False                                                 # the last three positions are padding
    unknown = 100 + np.arange(k)
    out = ud.unknown_dropout_numpy(batch, 1.0, unknown_index=unknown, real=real, rng=0)
    assert (out[:, :7] == unknown).all() and np.array_equal(out[:, 7:], batch[:, 7:])
    same = ud.unknown_dropout_torch(torch.as_tensor(batch), 1.0, unknown_index=unknown, real=torch.as_tensor(real))
    assert np.array_equal(same.numpy(), out)
    as_numbers = ud.unknown_dropout_torch(torch.as_tensor(batch), 1.0, unknown_index=unknown,
                                          real=torch.as_tensor(real, dtype=torch.float32))   # a 0/1 padding mask
    assert np.array_equal(as_numbers.numpy(), out)


def test_whole_sequence_mode_drops_a_field_for_all_rows_of_a_sequence_together():
    """With one draw per sequence and field, the rows of a sequence are either all swapped or all kept."""
    codes, _ = _codes(120)
    k = codes.shape[1]
    batch = np.maximum(codes[: 200 * 8].reshape(200, 8, k), 1)          # no entry equals the unknown index
    for out in (ud.unknown_dropout_numpy(batch, 0.3, whole_sequence=True, rng=2),
                ud.unknown_dropout_torch(torch.as_tensor(batch), 0.3, whole_sequence=True,
                                         generator=torch.Generator().manual_seed(2)).numpy()):
        swapped = out == ud.UNKNOWN_INDEX
        assert (swapped.all(axis=1) | ~swapped.any(axis=1)).all()       # per sequence and field: all or none
        assert abs(swapped[:, 0].mean() - 0.3) < 0.08                   # still the asked-for rate, per sequence
    by_row = ud.unknown_dropout_numpy(batch, 0.3, rng=2) == ud.UNKNOWN_INDEX
    assert not (by_row.all(axis=1) | ~by_row.any(axis=1)).all()         # the default draws every row on its own


def test_never_applied_at_scoring():
    """In eval mode the module hands back its input, and the functions do so with training=False."""
    codes, names = _codes(30)
    tensor = torch.as_tensor(codes)
    drop = ud.UnknownDropout(np.ones(len(names)))                       # rate 1: in training every entry is swapped
    drop.eval()
    assert drop(tensor) is tensor
    drop.train()
    assert bool((drop(tensor) == ud.UNKNOWN_INDEX).all())
    assert ud.unknown_dropout_numpy(codes, 1.0, training=False) is codes
    assert ud.unknown_dropout_torch(tensor, 1.0, training=False) is tensor
    assert len(drop.state_dict()) == 0                                  # nothing is added to a checkpoint


def test_the_unknown_row_becomes_a_trained_state():
    """Without the swap the unknown row gets no gradient; with it the row is read and learns."""
    torch.manual_seed(0)
    codes, names = _codes(60)
    tensor = torch.as_tensor(codes[:, :-1])                             # the fields that have an unknown row
    tables = torch.nn.ModuleList([torch.nn.Embedding(int(tensor[:, k].max()) + 1, 4) for k in range(tensor.shape[1])])

    def unknown_row_gradients(batch):
        for table in tables:
            table.zero_grad()
        tokens = torch.stack([table(batch[:, k]) for k, table in enumerate(tables)], dim=1)
        assert tokens.shape == (len(batch), len(tables), 4) and bool(torch.isfinite(tokens).all())
        tokens.pow(2).sum().backward()
        return [float(table.weight.grad[ud.UNKNOWN_INDEX].abs().sum()) for table in tables]

    assert max(unknown_row_gradients(tensor)) == 0                      # no training row carries the unknown code
    drop = ud.UnknownDropout(ud.field_rates(names[:-1]))
    assert min(unknown_row_gradients(drop(tensor))) > 0                 # every field's unknown row now learns


def test_unseen_values_are_sent_to_the_unknown_row_at_scoring():
    """A code that the training rows never held is replaced; a trained code is kept; a slow loop agrees."""
    codes, _ = _codes()
    k = codes.shape[1]
    sizes = codes.max(axis=0) + 3                                       # tables with rows that no row uses
    train = codes[codes[:, -2] != 6]                                    # training never sees month 6
    trained = ud.trained_codes(train, sizes)
    assert len(trained) == k and all(len(t) == s for t, s in zip(trained, sizes))
    assert not trained[-2][6] and trained[-2][5]
    score = codes.copy()
    score[::7, 0] = sizes[0] - 1                                        # a value of the vocabulary that was never trained
    score[::11, 1] = sizes[1] + 50                                      # a code outside the table
    out = ud.unseen_to_unknown(score, trained)
    seen = [set(np.unique(train[:, f]).tolist()) for f in range(k)]
    for i in range(0, len(score), 5):
        for f in range(k):
            slow = score[i, f] if score[i, f] in seen[f] else ud.UNKNOWN_INDEX
            assert out[i, f] == slow
    assert (out[codes[:, -2] == 6, -2] == ud.UNKNOWN_INDEX).all()       # the untrained month reads the unknown row
    assert np.array_equal(ud.unseen_to_unknown(torch.as_tensor(score), trained).numpy(), out)
    assert np.array_equal(ud.unseen_to_unknown(train, trained), train)  # training rows are left as they are
    # A floor on the number of training rows turns rare codes into unknown as well.
    floor = ud.trained_codes(train, sizes, min_rows=10**9)
    assert not any(t.any() for t in floor)
