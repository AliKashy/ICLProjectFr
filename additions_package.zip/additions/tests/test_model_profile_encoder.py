"""Tests of the encoder for slow account fields and of its two input helpers.

`days_before` is compared with a slow computation on made-up profile dates. The encoder is
checked for shapes, missing values, gradients and the scoring route, and then wired into
stage 2 as a prefix built from the first row, where altering later rows must leave the
outputs of earlier rows unchanged.
"""
import numpy as np
import pandas as pd
import torch

from additions import settings
from additions.common import synthetic
from additions.model._shared import layout, sequences_from_table
from additions.model.history_stage import HistoryStage
from additions.model.profile_encoder import ProfileEncoder, days_before, first_row_values

WIDTH, HEADS = 16, 4


def _encoder(num_numeric=3, cardinalities=(5, 4), dropout=0.0):
    """A small profile encoder whose output has the width of the small stage 2 below."""
    torch.manual_seed(0)
    return ProfileEncoder(num_numeric, cardinalities, out_dim=WIDTH, token_dim=8, num_heads=2, num_queries=2,
                          dropout=dropout)


def test_days_before_equals_a_slow_computation():
    """log(1 + days before the row), zero for dates at or after the row, missing for missing dates."""
    df = synthetic.make_transactions(n_accounts=8, days=20, seed=0)
    df, names = synthetic.add_profile_dates(df)
    dates = df[names[0]].copy()
    dates.iloc[:3] = pd.NaT
    dates.iloc[3] = pd.Timestamp(df[settings.TIME_COL].iloc[3]) + pd.Timedelta(days=5)     # a date after the row
    got = days_before(dates, df[settings.TIME_COL])
    raw = days_before(dates, df[settings.TIME_COL], log=False)
    for r in range(len(df)):
        if pd.isna(dates.iloc[r]):
            assert np.isnan(got[r]) and np.isnan(raw[r])
            continue
        gap = (pd.Timestamp(df[settings.TIME_COL].iloc[r]).floor("s") - pd.Timestamp(dates.iloc[r]).floor("s"))
        days = max(gap.total_seconds(), 0.0) / 86_400.0
        assert np.isclose(raw[r], days, rtol=1e-5)
        assert np.isclose(got[r], np.log1p(days), rtol=1e-5)
    assert raw[3] == 0.0
    assert got.dtype == np.float32


def test_first_row_values_takes_the_first_real_row():
    """The values come from the first real row of every sequence, wherever it sits."""
    values = torch.arange(2 * 4 * 3, dtype=torch.float32).reshape(2, 4, 3)
    valid = torch.tensor([[True, True, False, False], [False, False, True, True]])
    got = first_row_values(values, valid)
    assert torch.equal(got[0], values[0, 0]) and torch.equal(got[1], values[1, 2])
    assert torch.equal(first_row_values(values[..., 0], valid), torch.tensor([0.0, 18.0]))


def test_shapes_finite_values_and_missing_fields():
    """The encoder gives num_queries vectors per sequence; a missing value uses its own learned vector."""
    encoder = _encoder().eval()
    numeric = torch.randn(4, 3)
    numeric[0, 1] = float("nan")
    codes = torch.randint(0, 4, (4, 2))
    with torch.no_grad():
        out = encoder(numeric, codes)
        assert out.shape == (4, 2, WIDTH) and torch.isfinite(out).all()
        # A missing field reads the same whatever value the slot would have held.
        other = numeric.clone()
        other[1, 1] = float("nan")
        other_out = encoder(other, codes)
    assert torch.allclose(out[0], other_out[0], atol=1e-6)
    assert not torch.allclose(out[1], other_out[1], atol=1e-6)


def test_runs_with_numeric_only_codes_only_or_nothing():
    """Either kind of field may be absent; with none the run goes on with learned constants."""
    assert _encoder(cardinalities=())(torch.randn(3, 3)).shape == (3, 2, WIDTH)
    assert _encoder(num_numeric=0)(None, torch.randint(0, 4, (3, 2))).shape == (3, 2, WIDTH)
    empty = _encoder(num_numeric=0, cardinalities=())
    out = empty(torch.zeros(3, 0))
    assert out.shape == (3, 2, WIDTH) and torch.isfinite(out).all()


def test_gradients_reach_every_part():
    """A loss on the output sends a gradient to the field tokens, the block, the queries and the projection."""
    encoder = _encoder(dropout=0.1).train()
    encoder(torch.randn(4, 3), torch.randint(0, 4, (4, 2))).pow(2).mean().backward()
    for p in (encoder.weight, encoder.shift, encoder.queries, encoder.tables[0].weight, encoder.to_stage2.weight,
              encoder.block.layers[0].linear1.weight):
        assert p.grad is not None and p.grad.abs().sum() > 0


def test_scoring_route_agrees_with_training_at_dropout_zero():
    """Evaluation mode under torch.no_grad() gives the training-mode output at dropout zero."""
    encoder = _encoder(dropout=0.0)
    numeric, codes = torch.randn(4, 3), torch.randint(0, 4, (4, 2))
    train_out = encoder.train()(numeric, codes)
    with torch.no_grad():
        eval_out = encoder.eval()(numeric, codes)
    assert torch.allclose(train_out, eval_out, atol=1e-5)


def test_a_prefix_from_the_first_row_keeps_the_time_rule():
    """With the profile of the first row as prefix, altering later rows leaves earlier outputs unchanged."""
    df = synthetic.make_transactions(n_accounts=8, days=15, seed=3)
    df, names = synthetic.add_profile_dates(df)
    batch, row_index, _ = sequences_from_table(df, seconds_per_sequence=8)
    times, valid = batch["time_seq"], batch["mask"]
    per_row = np.stack([days_before(df[n], df[settings.TIME_COL]) for n in names[:2]], axis=1)
    numeric_rows = layout(per_row, row_index, fill=0.0)                                     # [B, T, 2]
    encoder = ProfileEncoder(2, (), out_dim=WIDTH, token_dim=8, num_heads=2, dropout=0.0).eval()
    torch.manual_seed(1)
    stage = HistoryStage(in_dim=WIDTH, num_heads=HEADS, num_blocks=2, history_len=6, dropout=0.0,
                         attn_dropout=0.0).eval()
    vectors = torch.randn(*valid.shape, WIDTH)

    def run(numeric_rows, vectors):
        prefix = encoder(first_row_values(numeric_rows, valid))
        return stage(vectors, times, valid, prefix=prefix)

    with torch.no_grad():
        before = run(numeric_rows, vectors)
        # Everything from the second row on is altered: its vector and its profile values.
        altered_numeric, altered_vectors = numeric_rows.clone(), vectors.clone()
        later = valid & (times > times[:, :1])
        altered_numeric[later] = torch.randn(int(later.sum()), 2) * 3
        altered_vectors[later] = torch.randn(int(later.sum()), WIDTH)
        after = run(altered_numeric, altered_vectors)
    first_second = valid & ~later
    assert torch.allclose(before[first_second], after[first_second], atol=1e-5)
    assert torch.isfinite(after).all()
