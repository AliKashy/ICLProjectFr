"""Tests of the merchant-by-hour tables and the burst columns.

The columns are recomputed row by row from other accounts' rows in completed earlier slots.
A hand-made attack on one merchant checks the burst scores, the time rule (the running hour
is never read) and the removal of the row's own account.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, timekeys
from additions.merchant import _panel, burst_tables

ACCOUNT, MERCHANT, TIME = settings.ACCOUNT_COL, settings.MERCHANT_COL, settings.TIME_COL
OK, RISK = settings.APPROVED_REASONS[0], settings.RISK_DECLINE_REASONS[0]
WEEK_OF_HOURS = 168


def _rows(seed=0, n_accounts=120, days=45):
    """Made-up rows squeezed onto a dozen merchants, so that a merchant has rows in most hours."""
    df = synthetic.make_transactions(n_accounts=n_accounts, days=days, seed=seed, fraud_account_share=0.5)
    df[MERCHANT] = df[MERCHANT] % 12
    return df


def _sums(df, m):
    """The five sums of the table over the rows picked by the mask `m`."""
    sub = df[m]
    return {"rows": float(len(sub)), "not_approved": float((sub[settings.REASON_COL] != OK).sum()),
            "small": float((sub[settings.AMOUNT_COL] < burst_tables.SMALL_AMOUNT).sum()),
            "score": float(sub[settings.VISA_SCORE_COL].sum()), "score_rows": float(sub[settings.VISA_SCORE_COL].notna().sum()),
            "accounts": float(len(set(zip(sub[ACCOUNT], sub["slot"]))))}


def _slow(df, i, n, first_slot, per_week=WEEK_OF_HOURS, base_weeks=4):
    """Recent sums, usual sums at the merchant and usual sums everywhere for row i, the obvious way."""
    slot = df["slot"].to_numpy()
    others = (df[ACCOUNT] != df[ACCOUNT].iloc[i]).to_numpy()
    here = others & (df[MERCHANT] == df[MERCHANT].iloc[i]).to_numpy()
    weeks = int(np.clip((slot[i] - n - first_slot) // per_week, 0, base_weeks))
    earlier = np.zeros(len(df), dtype=bool)
    for k in range(1, weeks + 1):
        earlier |= (slot >= slot[i] - per_week * k - n) & (slot < slot[i] - per_week * k)
    recent = (slot >= slot[i] - n) & (slot < slot[i])
    return _sums(df, here & recent), _sums(df, here & earlier), _sums(df, others & earlier), weeks


def _pull(total, count, prior, k):
    if np.isnan(prior):
        return total / count if count > 0 else np.nan
    return (total + k * prior) / (count + k)


def _same(a, b):
    return bool(np.isclose(a, b, rtol=2e-4, atol=2e-4, equal_nan=True))


def test_columns_equal_the_slow_definition():
    """Every column matches a recomputation from other accounts' rows in completed earlier hours."""
    df = _rows()
    df["slot"] = _panel.periods(timekeys.seconds(df[TIME]), 3_600)
    by_merchant, by_account = burst_tables.build_burst_tables(df)
    got = burst_tables.burst_features(df, by_merchant, by_account)
    assert got.shape == (len(df), 33) and got.index.equals(df.index)
    k, first = _panel.PRIOR_ROWS, int(df["slot"].min())
    for i in range(0, len(df), 97):
        for label, n in burst_tables.WINDOWS:
            recent, base, base_all, weeks = _slow(df, i, n, first)
            row = got.iloc[i]
            assert row[f"burst_n_{label}"] == recent["rows"]
            assert _same(row[f"burst_rows_per_account_{label}"], recent["rows"] / recent["accounts"] if recent["rows"] else np.nan)
            assert _same(row[f"burst_base_n_{label}"], base["rows"] / weeks if weeks else np.nan)
            assert _same(row[f"burst_volume_chi2_{label}"],
                         burst_tables.burst_score([recent["rows"]], [base["rows"]], [weeks])[0])
            for name, lift, top, bottom in (("not_approved_share", "not_approved_lift", "not_approved", "rows"),
                                            ("small_share", "small_lift", "small", "rows"),
                                            ("mean_score", "score_lift", "score", "score_rows")):
                broad = _pull(base_all[top], base_all[bottom], np.nan, k)
                before = _pull(base[top], base[bottom], broad, k)
                now = _pull(recent[top], recent[bottom], before, k)
                assert _same(row[f"burst_{name}_{label}"], now)
                assert np.isclose(row[f"burst_{lift}_{label}"], now - before, rtol=1e-3, atol=1e-4, equal_nan=True)
    assert got["burst_base_n_24h"].notna().any() and got["burst_base_n_24h"].isna().any()   # both cases occur


def test_the_burst_score_is_the_chi_squared_of_recent_against_usual():
    """The statistic equals the two-cell chi-squared, carries the sign of the change and needs an earlier week."""
    recent, usual, weeks = np.array([12.0, 1.0, 0.0, 5.0]), np.array([8.0, 16.0, 0.0, 3.0]), np.array([4, 4, 4, 0])
    got = burst_tables.burst_score(recent, usual, weeks)
    # The two-cell chi-squared is defined only where there is a count and an earlier week (the first two
    # entries); the last two entries are the edge cases the function settles itself (0 and missing).
    r, u, w = recent[:2], usual[:2], weeks[:2]
    expected = (r + u) / (w + 1.0)
    by_hand = (r - expected) ** 2 / expected + (u - w * expected) ** 2 / (w * expected)
    assert np.isclose(got[0], by_hand[0]) and got[0] == 20.0
    assert np.isclose(got[1], -by_hand[1]) and got[2] == 0.0 and np.isnan(got[3])


def _attack():
    """One merchant: two rows at 10:00 in each of four earlier weeks, then twelve accounts within one hour."""
    start = pd.Timestamp("2025-06-24 10:00:00")
    rows = []
    for week in range(1, 5):
        for a in ("u1", "u2"):
            rows.append((a, start - pd.Timedelta(weeks=week) + pd.Timedelta(minutes=5), OK, 40.0))
    for j in range(12):                                             # the attack: small amounts, most refused
        rows.append((f"v{j}", start + pd.Timedelta(minutes=2 + 4 * j), RISK if j < 9 else OK, 1.0))
    for j in range(5):                                              # the target account retries in the same hour
        rows.append(("t", start + pd.Timedelta(minutes=10 + j), RISK, 1.0))
    rows.append(("t", start + pd.Timedelta(minutes=59), OK, 25.0))             # still inside the attack hour
    rows.append(("t", start + pd.Timedelta(minutes=61), OK, 25.0))             # the next hour
    df = pd.DataFrame(rows, columns=[ACCOUNT, TIME, settings.REASON_COL, settings.AMOUNT_COL])
    df[MERCHANT], df[settings.VISA_SCORE_COL] = 7, 20.0
    df[settings.DECLINE_FLAG_COL] = (df[settings.REASON_COL] != OK).astype(int)
    return df


def test_an_attack_is_seen_one_hour_later_and_never_through_the_own_account():
    """The running hour is invisible; the next hour sees the twelve other accounts and none of the own retries."""
    df = _attack()
    got = burst_tables.burst_features(df, *burst_tables.build_burst_tables(df), prior_rows=0.0)
    inside, after = got.iloc[-2], got.iloc[-1]
    assert inside["burst_n_1h"] == 0                                 # the hour of the attack is not completed yet
    assert after["burst_n_1h"] == 12 and after["burst_rows_per_account_1h"] == 1.0
    assert after["burst_base_n_1h"] == 2.0 and after["burst_volume_chi2_1h"] == 20.0
    assert after["burst_not_approved_share_1h"] == 0.75 and after["burst_not_approved_lift_1h"] == 0.75
    assert after["burst_decline_chi2_1h"] == 36.0 and after["burst_small_share_1h"] == 1.0
    # The 5-minute table sees the last completed slots of the attack while the hour is still running.
    fine = burst_tables.build_burst_tables(df, burst_tables.FINE_SLOT_SECONDS)
    sharp = burst_tables.burst_features(df, *fine, burst_tables.FINE_SLOT_SECONDS, burst_tables.FINE_WINDOWS,
                                        prior_rows=0.0, prefix="burst5_")
    # The row at 10:59 is in the 10:55 slot. The last completed slot (10:50 to 10:55) holds no row of
    # another account (the attack rows fall at minutes 2, 6, ..., 46), the last three slots (10:40 to
    # 10:55) hold the rows at minutes 42 and 46, and the last twelve slots hold the whole attack.
    assert sharp["burst5_n_60m"].iloc[-2] == 12 and sharp["burst5_n_15m"].iloc[-2] == 2
    assert sharp["burst5_n_5m"].iloc[-2] == 0


def test_the_own_account_and_later_slots_are_absent():
    """An account reads what it would read with its rows out of the panel; later rows change nothing earlier."""
    df = _rows(seed=1)
    one = (df[ACCOUNT] == pd.unique(df[ACCOUNT])[3]).to_numpy()
    by_merchant, by_account = burst_tables.build_burst_tables(df)
    first = int(by_merchant["slot"].min())
    inside = burst_tables.burst_features(df[one], by_merchant, by_account)
    alone = burst_tables.burst_features(df[one], burst_tables.build_burst_tables(df[~one])[0], None, first_slot=first)
    assert np.allclose(inside.to_numpy(), alone.to_numpy(), rtol=1e-5, atol=1e-6, equal_nan=True)
    secs = timekeys.seconds(df[TIME])
    keep = secs <= np.median(secs)
    full = burst_tables.burst_features(df, by_merchant, by_account)
    part = burst_tables.burst_features(df[keep], *burst_tables.build_burst_tables(df[keep]))
    assert np.allclose(full[keep].to_numpy(), part.to_numpy(), rtol=1e-5, atol=1e-6, equal_nan=True)


def test_tables_add_up_and_the_fine_table_covers_the_busiest_merchants_only():
    """Per-file tables added equal the table of all rows; rows at other merchants get missing 5-minute columns."""
    df = _rows(seed=2)
    part = pd.factorize(df[ACCOUNT])[0] % 3
    added = burst_tables.combine([burst_tables.build_burst_tables(df[part == f]) for f in range(3)])
    whole = burst_tables.build_burst_tables(df)
    a = burst_tables.burst_features(df, *added)
    b = burst_tables.burst_features(df, *whole)
    assert np.allclose(a.to_numpy(), b.to_numpy(), rtol=1e-5, atol=1e-6, equal_nan=True)
    busiest = burst_tables.busiest_merchants(whole[0], top=4)
    counts = df[MERCHANT].value_counts()
    assert set(busiest) == set(counts.index[:4])
    fine = burst_tables.build_burst_tables(df, burst_tables.FINE_SLOT_SECONDS, merchants=busiest)
    assert set(fine[0][MERCHANT]) == set(busiest)
    sharp = burst_tables.burst_features(df, *fine, burst_tables.FINE_SLOT_SECONDS, burst_tables.FINE_WINDOWS,
                                        only_merchants=busiest, prefix="burst5_")
    covered = df[MERCHANT].isin(busiest).to_numpy()
    assert sharp[~covered].isna().all().all() and sharp.loc[covered, "burst5_n_60m"].notna().all()


def test_missing_optional_columns_and_the_command_line(capsys):
    """Without amount, score and decisions only the volume columns are built; the tool runs on made-up files."""
    df = _rows(seed=3, n_accounts=30)
    bare = df.drop(columns=[settings.AMOUNT_COL, settings.VISA_SCORE_COL, settings.REASON_COL, settings.DECLINE_FLAG_COL])
    got = burst_tables.burst_features(bare, *burst_tables.build_burst_tables(bare))
    assert list(got.columns) == [f"burst_{name}_{w}" for w in ("1h", "6h", "24h")
                                 for name in ("n", "rows_per_account", "base_n", "volume_chi2")]
    frame = burst_tables.main(["--demo", "--busiest", "10"])
    assert frame.shape[1] == 66 and "burst5_volume_chi2_60m" in capsys.readouterr().out
