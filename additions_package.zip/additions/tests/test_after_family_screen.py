"""Tests of the family screen: trees on top of the model's own score, one family at a time.

The tables are made up. A "hint" column carries part of the fraud signal that the made-up
score lacks, so a family built from it must show a gain; a family of noise must not. The
stability check is tested on a column whose relation to fraud turns around between months.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.after_model import _shared, family_screen as fsc
from additions.common import synthetic, tables, timekeys

FAST = {"rounds": 120, "patience": 20, "draws": 100}


def _tables(n_accounts=250, seed=0):
    """A fit table of three months and a read table of two, each with a signal column and two noise columns."""
    rng = np.random.default_rng(seed)
    fit = synthetic.make_transactions(n_accounts=n_accounts, days=92, start=settings.TRAIN_HISTORY_START, seed=seed + 1,
                                      fraud_account_share=0.3)
    read = synthetic.make_transactions(n_accounts=n_accounts, seed=seed + 2, fraud_account_share=0.3)
    out = []
    for df in (fit, read):
        df = synthetic.make_scores(df, seed=seed, strength=1.0)
        y = df[settings.LABEL_COL].to_numpy(dtype=float)
        df["hint_a"] = 2.0 * y + rng.normal(size=len(df))
        df["noise_a"], df["noise_b"] = rng.normal(size=len(df)), rng.normal(size=len(df))
        out.append(df)
    return out[0], out[1]


def test_families_are_resolved_from_names_and_prefixes():
    """Exact names and prefixes ending with '*' select columns; unknown names are left out."""
    names = ["state_a", "state_b", "match_x", "amount"]
    assert fsc.resolve_family(["state_*", "amount", "absent"], names) == ["state_a", "state_b", "amount"]
    assert fsc.resolve_family(["state_a", "state_*"], names) == ["state_a", "state_b"]
    assert fsc.parse_families(["one=a,b_*", "two=c"]) == {"one": ["a", "b_*"], "two": ["c"]}


def test_code_columns_are_numbered_by_frequency_and_infinities_become_missing():
    """A text column becomes 0 for the most frequent fit value; a value unseen in fit and an infinity become NaN."""
    fit = pd.DataFrame({"code": ["x", "y", "y", "z", "y", "x"], "num": [1.0, np.inf, 2.0, 3.0, 4.0, 5.0]})
    read = pd.DataFrame({"code": ["y", "w", "x"], "num": [-np.inf, 7.0, 8.0]})
    x_fit, x_read, used = fsc.family_matrices(fit, read, ["code", "num", "absent"])
    assert used == ["code", "num"] and x_fit.shape == (6, 2) and x_read.shape == (3, 2)
    assert x_fit[:, 0].tolist() == [1.0, 0.0, 0.0, 2.0, 0.0, 1.0]
    assert x_read[0, 0] == 0.0 and np.isnan(x_read[1, 0]) and x_read[2, 0] == 1.0
    assert np.isnan(x_fit[1, 1]) and np.isnan(x_read[0, 1]) and x_read[2, 1] == 8.0


def test_a_signal_family_gains_and_a_noise_family_does_not(capsys):
    """A family with what the score lacks lowers loss and raises capture; noise does not; a missing one is skipped."""
    fit, read = _tables()
    families = {"hint": ["hint_*"], "noise": ["noise_*"], "absent": ["nothing_*"]}
    table, checks = fsc.screen(fit, read, families, **FAST)
    assert list(table.columns) == fsc.COLUMNS and len(table) == 3
    by = table.set_index("family")
    assert by.loc["hint", "loss_drop"] > 0 and by.loc["hint", "inner_loss_drop"] > 0
    assert by.loc["hint", "gain"] > 0 and by.loc["hint", "verdict"] == "pass"
    assert by.loc["hint", "loss_drop"] > by.loc["noise", "loss_drop"] + 0.001
    assert by.loc["noise", "verdict"] == "park"
    if by.loc["noise", "trees"] == 0:
        # No tree means the base score itself: nothing can have changed.
        assert by.loc["noise", "gain"] == 0 and by.loc["noise", "loss_drop"] == 0
    # Every line compares with the same base: the model's own score on the same read rows.
    assert np.isclose(by.loc["hint", "base_udr"], by.loc["noise", "base_udr"])
    assert by.loc["absent", "verdict"] == "missing" and "skipped" in capsys.readouterr().out
    assert set(checks["column"]) == {"hint_a", "noise_a", "noise_b"}


def test_the_base_udr_is_the_capture_of_the_score_on_the_read_rows():
    """The base figure equals the share of frauds of the scored month inside the cut of the model's score."""
    fit, read = _tables(seed=3)
    table, _ = fsc.screen(fit, read, {"hint": ["hint_a"]}, **FAST)
    rows = _shared.scored_rows(read)
    y, logit = _shared.fraud_flags(read)[rows], _shared.logits(read)[rows]
    k = (len(y) * settings.OUTSORT_PER_MILLE) // 1000
    slow = y[np.argsort(-logit, kind="stable")[:k]].sum() / y.sum()               # scores are continuous: no ties
    assert np.isclose(table.loc[0, "base_udr"], slow)


def test_stability_flags_a_column_that_turns_around():
    """A column fitted on early months that ranks the wrong way on late months is unstable; a steady one is stable."""
    fit, _ = _tables(seed=5)
    y = _shared.fraud_flags(fit)
    _, secs = _shared.account_and_time(fit)
    split = fsc.default_split(secs)
    assert split == int(timekeys.seconds(pd.Series([pd.Timestamp("2024-12-01")]))[0])   # Oct, Nov | Dec
    late = secs >= split
    rng = np.random.default_rng(0)
    steady = y + rng.normal(size=len(y))
    turning = np.where(late, -y, y) + rng.normal(size=len(y))
    check = fsc.stability(np.column_stack([steady, turning]), ["steady", "turning"], y, secs, split=split)
    assert check["stable"].tolist() == [True, False]
    assert check.loc[0, "auc_late"] > 0.6 and check.loc[1, "auc_late"] < 0.5
    assert check.loc[0, "early_rows"] == (~late).sum() and check.loc[0, "late_rows"] == late.sum()
    # With one month only, the split falls on the median second.
    one_month = secs[secs < int(timekeys.seconds(pd.Series([pd.Timestamp("2024-11-01")]))[0])]
    assert fsc.default_split(one_month) == int(np.median(one_month))


def test_the_inner_split_holds_out_files_or_accounts(capsys):
    """With split_by='file' the inner split works on the _file column; without that column it falls back to accounts."""
    fit, _ = _tables(n_accounts=40, seed=6)
    fit["_file"] = timekeys.codes(fit[settings.ACCOUNT_COL]) % 4
    assert np.array_equal(fsc.inner_units(fit, "file"), fit["_file"].to_numpy())
    accounts = fsc.inner_units(fit.drop(columns="_file"), "file")
    assert np.array_equal(accounts, fit[settings.ACCOUNT_COL].to_numpy())
    assert "whole accounts instead" in capsys.readouterr().out
    held = _shared.held_out_accounts(fsc.inner_units(fit, "file"), 0.5, seed=1)
    # A file is held out whole: every row of a file is on the same side.
    assert all(len(set(held[fit["_file"].to_numpy() == f])) == 1 for f in range(4))


def test_tool_runs_on_made_up_rows_and_on_files(tmp_path, capsys):
    """The tool prints both tables and writes them to the given paths."""
    fsc.main(["--demo", "--accounts", "150", "--draws", "50", "--rounds", "60", "--patience", "15"])
    printed = capsys.readouterr().out
    assert "earlier_scores" in printed and "Stability" in printed
    fit, read = _tables(n_accounts=120, seed=7)
    fit_path = tables.write_table(fit, str(tmp_path / "fit.parquet"))
    read_path = tables.write_table(read, str(tmp_path / "read.parquet"))
    out, out_check = str(tmp_path / "screen.parquet"), str(tmp_path / "stability.parquet")
    table, _ = fsc.main(["--fit", fit_path, "--read", read_path, "--family", "hint=hint_*", "--family", "noise=noise_a",
                         "--draws", "50", "--rounds", "60", "--patience", "15", "--out", out,
                         "--stability-out", out_check])
    written = tables.read_columns(out)
    assert list(written["family"]) == list(table["family"]) and set(written["family"]) == {"hint", "noise"}
    assert len(tables.read_columns(out_check)) == 2
