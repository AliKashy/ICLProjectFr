"""Tests of the two release checks.

The stability index is compared with a sum written out by hand. The domain check is read on
made-up columns that are the same in both months and on columns where one of them moves.
"""
import numpy as np
import pandas as pd
import pytest

from additions import settings
from additions.common import tables
from additions.exports import release_gates


def _two_months(n_accounts=400, rows_per_account=20, shift=0.0, seed=0):
    """Made-up export columns for May and June; `shift` is added to column x1 in June only."""
    rng = np.random.default_rng(seed)
    n = n_accounts * rows_per_account
    account = np.repeat(np.arange(n_accounts), rows_per_account)
    june = rng.random(n) < 0.5
    start = np.where(june, pd.Timestamp(settings.TARGET_START).value // 10**9,
                     pd.Timestamp(settings.EVAL_HISTORY_START).value // 10**9)
    level = rng.normal(size=n_accounts)[account]                 # a value that belongs to the account
    return pd.DataFrame({
        settings.ID_COL: np.arange(n),
        settings.ACCOUNT_COL: account,
        settings.TIME_COL: pd.to_datetime(start + rng.integers(0, 28 * 86_400, n), unit="s"),
        settings.LABEL_COL: (rng.random(n) < 0.02).astype(int),
        "x0": rng.normal(size=n),
        "x1": rng.normal(size=n) + shift * june,
        "x2": level + 0.1 * rng.normal(size=n),
        "kind": rng.choice(["a", "b", "c"], n),
    })


def test_stability_index_equals_the_sum_written_out():
    """Quantile bins of the first period, a bin for missing values, and the floor on empty bins."""
    before = np.array([1.0, 2.0, 3.0, 4.0, np.nan])
    now = np.array([1.0, 1.0, 4.0, 4.0, 4.0, np.nan, np.nan, 9.0])
    index, used = release_gates.population_stability(before, now, bins=2, floor=1e-4)
    # One inner edge at the median 2.5: bins (< 2.5), (>= 2.5), missing.
    share_before = np.array([2, 2, 1]) / 5
    share_now = np.array([2, 4, 2]) / 8
    assert used == 3 and np.isclose(index, ((share_now - share_before) * np.log(share_now / share_before)).sum())
    same, _ = release_gates.population_stability(before, before)
    assert same == 0.0
    # A bin that empties counts with the floor, so the index stays finite.
    gone, _ = release_gates.population_stability(np.array([0.0, 0.0, 1.0, 1.0]), np.array([1.0, 1.0]), bins=2)
    assert np.isclose(gone, (1e-4 - 0.5) * np.log(1e-4 / 0.5) + 0.5 * np.log(2.0))
    assert np.isnan(release_gates.population_stability(np.array([]), now)[0])
    # A count that is mostly zero keeps its zeros apart from its positive values.
    zeros, used = release_gates.population_stability(np.r_[np.zeros(95), np.ones(5)], np.r_[np.zeros(80), np.ones(20)])
    assert used == 2 and np.isclose(zeros, (0.8 - 0.95) * np.log(0.8 / 0.95) + (0.2 - 0.05) * np.log(0.2 / 0.05))


def test_stability_index_of_a_code_column():
    """A code column uses its values as bins, with one bin for new values and one for missing values."""
    before = pd.Series(["a", "a", "b", "b"])
    now = pd.Series(["a", "b", "z", None])
    index, used = release_gates.population_stability(before, now)
    share_before = np.array([0.5, 0.5, 1e-4, 1e-4])
    share_now = np.array([0.25, 0.25, 0.25, 0.25])
    assert used == 4 and np.isclose(index, ((share_now - share_before) * np.log(share_now / share_before)).sum())


def test_columns_that_look_the_same_pass_and_a_moved_column_is_found():
    """Same columns in both months give an area near 0.5; a shifted column gives a high area and the top index."""
    steady = release_gates.check_release(_two_months(seed=1), ["x0", "x1", "x2", "kind"], rounds=30, quiet=True)
    assert 0.44 < steady["auc"] < 0.56
    assert (steady["stability"]["psi"] < 0.05).all() and (steady["stability"]["verdict"] == "steady").all()
    assert steady["rows"][0] > 3000 and steady["rows"][1] > 3000
    moved = release_gates.check_release(_two_months(seed=2, shift=1.0), ["x0", "x1", "x2", "kind"], rounds=30,
                                        quiet=True)
    assert moved["auc"] > 0.7
    assert moved["stability"]["column"].iloc[0] == "x1" and moved["stability"]["verdict"].iloc[0] == "moved"
    assert moved["importance"]["column"].iloc[0] == "x1"


def test_folds_keep_each_account_whole():
    """Every row of one account is in the same fold, and every fold holds accounts."""
    accounts = np.repeat(np.arange(50), 7)[np.random.default_rng(0).permutation(350)]
    fold = release_gates.account_folds(accounts, folds=3)
    per_account = pd.Series(fold).groupby(accounts).nunique()
    assert (per_account == 1).all() and set(fold) == {0, 1, 2}


def test_keys_label_and_absent_columns_are_not_checked(capsys):
    """The label, the keys and absent names are left out; without a name the numeric columns are taken."""
    df = _two_months(n_accounts=20, seed=3)
    asked = release_gates.gate_columns(df, ["x0", settings.LABEL_COL, settings.ACCOUNT_COL, "absent"])
    assert asked == ["x0"] and "absent" in capsys.readouterr().out
    assert release_gates.gate_columns(df) == ["x0", "x1", "x2"]
    empty = release_gates.check_release(df, ["x0"], first=("2031-01-01", "2031-02-01"), rounds=5, quiet=True)
    assert np.isnan(empty["auc"]) and "skipped" in capsys.readouterr().out


def test_tool_prints_both_checks_and_writes_the_table(tmp_path, capsys):
    """The tool reads a table, prints the domain check and the index table, and writes the table on request."""
    df = _two_months(n_accounts=100, seed=4, shift=0.5)
    path = tables.write_table(df, str(tmp_path / "bundle.parquet"))
    out_path = str(tmp_path / "stability.parquet")
    result = release_gates.main(["--table", path, "--columns", "x0", "x1", "kind", "--rounds", "10", "--out", out_path])
    printed = capsys.readouterr().out
    assert "Domain check" in printed and "Population stability index" in printed
    saved = tables.read_columns(out_path)
    assert saved["column"].tolist() == result["stability"]["column"].tolist() and len(saved) == 3
