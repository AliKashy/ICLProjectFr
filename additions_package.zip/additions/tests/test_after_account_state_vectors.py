"""Tests of the slow account memory.

The batch computation is compared with the plain definition (a loop over the earlier rows of
the account) and with the live update rule applied one row at a time. Further tests check a
late row, a reversal, the forgetting of rows before a start time, and the time rule.
"""
import numpy as np

from additions import settings
from additions.after_model import _shared, account_state_vectors as asv
from additions.common import synthetic, tables, timekeys
from additions.common.timekeys import MISSING_SECOND

HALF = np.array([seconds for _, seconds in asv.HALF_LIVES], dtype=np.float64)


def _toy(n=900, seed=0, dim=4):
    """Random rows of 30 accounts over 40 days, with shared seconds and a few rows that have no time."""
    rng = np.random.default_rng(seed)
    keys = rng.integers(0, 30, n)
    secs = rng.integers(1_700_000_000, 1_700_000_000 + 40 * 86_400, n).astype(np.int64)
    tie = rng.random(n) < 0.15
    secs[tie] = secs[rng.integers(0, n, int(tie.sum()))]
    secs[:3] = MISSING_SECOND
    return rng, keys, secs, rng.normal(size=(n, dim))


def _slow(i, keys, secs, vectors, start=None):
    """The definition: vectors of the account's rows in strictly earlier seconds, each halved per half-life of age."""
    if secs[i] == MISSING_SECOND:
        return np.zeros((len(HALF), vectors.shape[1])), np.zeros(len(HALF))
    earlier = (keys == keys[i]) & (secs < secs[i]) & (secs != MISSING_SECOND)
    if start is not None:
        earlier &= secs >= start[i]
    weight = 0.5 ** ((secs[i] - secs[earlier])[:, None] / HALF[None, :])           # [earlier rows, half-lives]
    return np.einsum("jh,jd->hd", weight, vectors[earlier]), weight.sum(axis=0)


def test_batch_equals_the_definition_with_and_without_a_start():
    """Sums and counts match a loop over the earlier rows; rows before the start time are forgotten exactly."""
    rng, keys, secs, vectors = _toy()
    start = secs - rng.integers(0, 20 * 86_400, len(secs))                         # every row forgets at its own time
    start[secs == MISSING_SECOND] = MISSING_SECOND
    for st in (None, start):
        sums, counts = asv.account_state(vectors, keys, secs, start=st)
        assert sums.shape == (len(keys), 5, 4) and counts.shape == (len(keys), 5) and sums.dtype == np.float32
        assert np.isfinite(sums).all() and (counts >= 0).all()
        for i in range(0, len(keys), 9):
            slow_sums, slow_counts = _slow(i, keys, secs, vectors, st)
            assert np.allclose(sums[i], slow_sums, rtol=1e-4, atol=1e-5)
            assert np.allclose(counts[i], slow_counts, rtol=1e-4, atol=1e-5)
    # Chunks hold whole accounts, so the size of the chunks does not change the answer.
    small = asv.account_state(vectors, keys, secs, start=start, chunk_rows=50)
    assert np.array_equal(small[0], sums) and np.array_equal(small[1], counts)


def test_batch_and_step_by_step_update_agree():
    """For every account the live rule, applied row by row, reads the states the batch computation gives."""
    _, keys, secs, vectors = _toy(seed=1)
    real = secs != MISSING_SECOND
    sums, counts = asv.account_state(vectors, keys, secs)
    for key in np.unique(keys):
        rows = np.flatnonzero((keys == key) & real)
        seen = asv.replay(secs[rows], vectors[rows])                               # [rows, half-lives, dim + 1]
        assert np.allclose(seen[:, :, :-1], sums[rows], rtol=1e-4, atol=1e-5)
        assert np.allclose(seen[:, :, -1], counts[rows], rtol=1e-4, atol=1e-5)
    # The rule itself: fade by the decay since the last update, then add the vector and one row.
    state = asv.update(asv.empty_state(4), None, 100, vectors[5])
    assert np.allclose(state[:, :-1], vectors[5]) and np.allclose(state[:, -1], 1.0)
    later = asv.update(state, 100, 100 + 3_600, vectors[6])
    assert np.allclose(later[0, :-1], 0.5 * vectors[5] + vectors[6]) and np.isclose(later[0, -1], 1.5)
    assert np.allclose(asv.fade(state, 100, 100 + 86_400)[2], 0.5 * state[2])       # one day at the one-day half-life


def test_a_late_row_and_a_reversal_are_exact():
    """Adding a row late gives the state it would have given on time; a reversal removes it without a trace."""
    rng = np.random.default_rng(2)
    times = np.sort(rng.integers(0, 10 * 86_400, 12))
    vectors = rng.normal(size=(12, 3))

    def stored(rows):
        """The state after the given rows were added in time order, faded to the last time of all."""
        state, last = asv.empty_state(3), None
        for k in rows:
            state, last = asv.update(state, last, times[k], vectors[k]), times[k]
        return asv.fade(state, last, times[-1])

    on_time = stored(range(12))
    without_row_4 = stored([k for k in range(12) if k != 4])
    late = asv.add_late(without_row_4, times[-1], times[4], vectors[4])
    assert np.allclose(late, on_time, rtol=1e-12, atol=1e-12)
    reversed_again = asv.subtract_reversal(on_time, times[-1], times[4], vectors[4])
    assert np.allclose(reversed_again, without_row_4, rtol=1e-12, atol=1e-12)
    assert not np.allclose(on_time, without_row_4)                                 # the row does matter


def test_time_rule_same_second_and_later_rows():
    """Rows of one second are not in each other's state, and later rows change no earlier state."""
    keys = np.array([7, 7, 7, 7])
    secs = np.array([100, 200, 200, 300], dtype=np.int64)
    vectors = np.array([[1.0], [10.0], [100.0], [1000.0]])
    sums, counts = asv.account_state(vectors, keys, secs, half_lives=[1e12])        # so slow that nothing fades
    assert np.allclose(sums[:, 0, 0], [0.0, 1.0, 1.0, 111.0]) and np.allclose(counts[:, 0], [0, 1, 1, 3])
    _, keys, secs, vectors = _toy(seed=3)
    keep = secs <= np.median(secs[secs != MISSING_SECOND])
    full = asv.account_state(vectors, keys, secs)
    part = asv.account_state(vectors[keep], keys[keep], secs[keep])
    assert np.allclose(full[0][keep], part[0], atol=1e-6) and np.allclose(full[1][keep], part[1], atol=1e-6)


def test_means_and_the_table_of_columns(capsys):
    """Means are sums over counts and zero for an empty memory; the table has one mean vector and one count per half-life."""
    sums = np.array([[[2.0, 4.0]], [[0.0, 0.0]]], dtype=np.float32)
    counts = np.array([[2.0], [0.0]], dtype=np.float32)
    means, log_counts = asv.state_means(sums, counts)
    assert means.tolist() == [[[1.0, 2.0]], [[0.0, 0.0]]] and np.allclose(log_counts[:, 0], [np.log(3.0), 0.0])

    df = synthetic.make_vectors(synthetic.make_transactions(n_accounts=20, seed=4, days=92, start="2024-10-01"), dim=3)
    frame = asv.build_account_state(df)
    assert frame.shape == (len(df), 5 * (3 + 1)) and frame.index.equals(df.index)
    assert list(frame.columns[:4]) == ["acct_1h_0", "acct_1h_1", "acct_1h_2", "acct_1h_log_n"]
    assert np.isfinite(frame.to_numpy()).all()
    # A December row in long files remembers what it would remember in files that begin on 1 November.
    secs = timekeys.seconds(df[settings.TIME_COL])
    december, short = secs >= 1_733_011_200, secs >= 1_730_419_200                 # 1 December and 1 November 2024
    short_files = asv.build_account_state(df[short])
    assert np.allclose(frame[december].to_numpy(), short_files[december[short]].to_numpy(), atol=1e-5)
    uncut = asv.build_account_state(df, months_back=None)
    assert not np.allclose(uncut[december].to_numpy(), short_files[december[short]].to_numpy(), atol=1e-5)
    # The first row of an account has an empty memory at every half-life.
    account, _ = _shared.account_and_time(df)
    first = np.array([np.flatnonzero(account == a)[np.argmin(secs[account == a])] for a in np.unique(account)])
    assert (frame.iloc[first].to_numpy() == 0).all()
    capsys.readouterr()
    no_vectors = df[[settings.ACCOUNT_COL, settings.TIME_COL]]
    assert asv.build_account_state(no_vectors).shape == (len(df), 0) and "skipped" in capsys.readouterr().out


def test_tool_runs_on_made_up_rows_and_on_a_file(tmp_path, capsys):
    """The tool prints how much each half-life remembers and writes the columns with the id."""
    asv.main(["--demo"])
    assert "acct_30d_log_n" in capsys.readouterr().out
    df = _shared.demo_export(n_accounts=30, seed=5, dim=3)
    path = tables.write_table(df, str(tmp_path / "export.parquet"))
    out = str(tmp_path / "state.parquet")
    frame = asv.main(["--export", path, "--months-back", "-1", "--out", out])
    written = tables.read_columns(out)
    assert list(written.columns) == [settings.ID_COL] + list(frame.columns) and len(written) == len(df)
    assert np.array_equal(written["acct_7d_1"].to_numpy(), frame["acct_7d_1"].to_numpy())


def test_the_stage_one_columns_are_preferred_when_the_export_has_them(capsys):
    """With both vectors in the table the memory is built on the stage-1 columns; without them one line says so."""
    df = _shared.demo_export(n_accounts=30, seed=4, dim=3)
    both = df.copy()
    for j in range(3):
        both[f"{asv.STAGE1_PREFIX}{j}"] = -2.0 * df[f"{settings.VECTOR_PREFIX}{j}"] + j
    stage1_only = both.drop(columns=[f"{settings.VECTOR_PREFIX}{j}" for j in range(3)])
    from_both = asv.build_account_state(both)
    assert "note" not in capsys.readouterr().out
    from_stage1 = asv.build_account_state(stage1_only)
    assert np.allclose(from_both.to_numpy(), from_stage1.to_numpy(), equal_nan=True)
    from_head = asv.build_account_state(df)
    assert "no stage-1 columns" in capsys.readouterr().out
    assert not np.allclose(from_both.to_numpy(), from_head.to_numpy(), equal_nan=True)


def test_the_tool_reads_the_stage_one_columns_of_a_file(tmp_path, capsys):
    """An export file with both vectors gives the memory of the stage-1 columns, not of the head-input columns."""
    df = _shared.demo_export(n_accounts=30, seed=6, dim=3)
    for j in range(3):
        df[f"{asv.STAGE1_PREFIX}{j}"] = -2.0 * df[f"{settings.VECTOR_PREFIX}{j}"] + j
    path = tables.write_table(df, str(tmp_path / "export.parquet"))
    capsys.readouterr()
    frame = asv.main(["--export", path])
    assert "no stage-1 columns" not in capsys.readouterr().out
    expected = asv.build_account_state(df)
    assert np.allclose(frame.to_numpy(), expected.to_numpy(), equal_nan=True)
