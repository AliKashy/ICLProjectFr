"""Tests of the eligible-row reads and of the alert budget.

The fast tables are compared with a walk down the ranking one row at a time, and the two parts
of the tool are tied together: the capture a row type costs is exactly what a "never alert
this type" rule would add.
"""
import numpy as np
import pandas as pd
import pytest

from additions import settings
from additions.common import ranking, synthetic, tables
from additions.reads import _rows, eligible_rows

STANDARD = [settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL, settings.LABEL_COL, settings.AMOUNT_COL,
            settings.SCORE_COL]


@pytest.fixture(scope="module")
def table():
    """Made-up rows with a score that also likes some declined attempts, so that alerts are wasted."""
    df = synthetic.make_transactions(n_accounts=500, seed=0)
    rng = np.random.default_rng(0)
    declined = (df[settings.DECLINE_FLAG_COL] == 1).to_numpy()
    tempting = declined & (rng.random(len(df)) < 0.2)
    logit = -6.0 + 2.0 * df[settings.LABEL_COL].to_numpy() + 2.5 * tempting + rng.normal(size=len(df))
    df[settings.SCORE_COL] = 1.0 / (1.0 + np.exp(-logit))
    return df


def _ranked(table):
    """Labels, scores and amounts of the rows of the scored month."""
    scored = _rows.in_scored_month(table)
    return (scored, table[settings.LABEL_COL].to_numpy()[scored], table[settings.SCORE_COL].to_numpy()[scored],
            table[settings.AMOUNT_COL].to_numpy()[scored])


def test_eligible_rows_match_the_plain_rule(table):
    """A row is eligible unless one of the switched-on rules drops it."""
    excluded = ("3. ATM",)
    fast = eligible_rows.eligible_mask(table, drop_declined=True, drop_advice=True, drop_zero_checks=True,
                                       excluded_segments=excluded)
    slow = []
    for row in table.to_dict("records"):
        declined = str(row[settings.DECLINE_FLAG_COL]) in settings.DECLINE_FLAG_VALUES
        advice = row[settings.ADVICE_COL] is not None
        zero_check = row[settings.TYPE_COL] in settings.ZERO_CHECK_TYPES
        slow.append(not (declined or advice or zero_check or row[settings.SEGMENT_COL] in excluded))
    assert fast.tolist() == slow and 0 < sum(slow) < len(slow)
    # The default mirrors the benchmark: only the rows declined before the fraud engine go.
    assert (eligible_rows.eligible_mask(table) == (table[settings.DECLINE_FLAG_COL] != 1).to_numpy()).all()
    assert eligible_rows.eligible_mask(table, drop_declined=False).all()


def test_a_rule_without_its_column_drops_nothing(table, capsys):
    """A missing decline flag or segment column switches that rule off with one line each."""
    bare = table.drop(columns=[settings.DECLINE_FLAG_COL, settings.SEGMENT_COL])
    assert eligible_rows.eligible_mask(bare, excluded_segments=("3. ATM",)).all()
    out = capsys.readouterr().out
    assert "decline flag" in out and "segment" in out


def test_three_reads_are_capture_on_three_populations(table):
    """Each line equals capture computed directly on its population; history rows play no part."""
    scored, y, s, a = _ranked(table)
    reads = eligible_rows.three_reads(table)
    assert reads["read"].tolist() == ["all scored rows", "eligible rows", "eligible rows, never-labelled types last"]
    everything = ranking.capture(y, s, a)
    keep = (table[settings.DECLINE_FLAG_COL] != 1).to_numpy()[scored]
    eligible = ranking.capture(y[keep], s[keep], a[keep])
    assert reads.loc[0, "rows"] == scored.sum() and reads.loc[1, "rows"] == keep.sum()
    assert np.isclose(reads.loc[0, "udr"], everything["udr"]) and np.isclose(reads.loc[0, "vdr"], everything["vdr"])
    assert np.isclose(reads.loc[1, "udr"], eligible["udr"]) and np.isclose(reads.loc[1, "vdr"], eligible["vdr"])
    # The third read alerts no row that cannot carry a label, and that can only add caught frauds.
    assert reads.loc[2, "never_labelled_alerts"] == 0 < reads.loc[1, "never_labelled_alerts"]
    assert reads.loc[2, "caught"] >= reads.loc[1, "caught"]
    # Rows before the scored month are history only: without them the reads are the same.
    pd.testing.assert_frame_equal(eligible_rows.three_reads(table[scored].reset_index(drop=True)), reads)


def test_forced_rows_rank_below_every_other_row():
    """Rows sent to the bottom end up under the lowest score and the other scores are untouched."""
    s = np.array([0.3, 0.9, 0.1, 0.5])
    out = eligible_rows.force_to_bottom(s, [False, True, False, True])
    assert out[1] == out[3] < s.min() and out[0] == 0.3 and out[2] == 0.1
    assert np.array_equal(eligible_rows.force_to_bottom(s, np.zeros(4, dtype=bool)), s)
    assert s.tolist() == [0.3, 0.9, 0.1, 0.5]                # the input is not changed


def _slow_budget(y, s, groups, k):
    """Walk down the ranking one row at a time and count what each group holds."""
    order = sorted(range(len(s)), key=lambda i: -s[i])       # a stable sort, as in the alert mask
    alerted, below = order[:k], order[k:]
    out = {}
    for g in set(groups):
        places = sum(1 for i in alerted if groups[i] == g)
        taken, next_caught = 0, 0
        for i in below:                                      # the next rows in line that are not of this group
            if taken == places:
                break
            if groups[i] != g:
                taken += 1
                next_caught += y[i]
        out[g] = (groups.count(g), places, sum(y[i] for i in alerted if groups[i] == g), next_caught)
    return out


def test_budget_table_matches_a_walk_down_the_ranking(table):
    """Rows, alerts, caught frauds and the frauds of the next rows in line agree with the slow walk."""
    scored, y, s, _ = _ranked(table)
    k = ranking.cut_size(int(scored.sum()))
    splits = (("row_type", _rows.row_type(table)[scored]), ("segment", table[settings.SEGMENT_COL].to_numpy()[scored]))
    for by, groups in splits:
        fast = eligible_rows.budget_table(table, by).set_index(by)
        slow = _slow_budget(y.tolist(), s.tolist(), groups.tolist(), k)
        assert set(fast.index) == set(slow)
        for g, expected in slow.items():
            assert tuple(fast.loc[g, ["rows", "alerts", "caught", "next_caught"]]) == expected
        assert fast["alerts"].sum() == k and fast["rows"].sum() == scored.sum()
        assert np.isclose(fast["alert_share"].sum(), 1.0) and np.isclose(fast["row_share"].sum(), 1.0)
        assert np.allclose(fast["lost_udr"], fast["next_caught"] / y.sum())
    assert fast["next_caught"].sum() > 0                     # the split by segment has something to lose
    days = eligible_rows.budget_table(table, "day")
    assert days["alerts"].sum() == k and days["day"].is_monotonic_increasing
    assert days["day"].iloc[0] == settings.TARGET_START and len(days) == days["day"].nunique()


def test_lost_capture_is_what_sending_the_group_to_the_bottom_adds(table):
    """Base catch, minus the group's own catch, plus the frauds of the next rows, is the catch without the group."""
    scored, y, s, _ = _ranked(table)
    types = _rows.row_type(table)[scored]
    budget = eligible_rows.budget_table(table, "row_type").set_index("row_type")
    base = y[ranking.alert_mask(s)].sum()
    assert base == budget["caught"].sum()
    with_alerts = 0
    for name in budget.index:
        without = y[ranking.alert_mask(eligible_rows.force_to_bottom(s, types == name))].sum()
        assert without == base - budget.loc[name, "caught"] + budget.loc[name, "next_caught"]
        with_alerts += int(budget.loc[name, "alerts"] > 0)
    assert with_alerts >= 3                                  # several row types hold alerts in this table
    assert budget.loc[list(_rows.NEVER_LABELLED[:4]), "caught"].sum() == 0


def test_budget_on_another_population_and_without_its_column(table, capsys):
    """The audited population is an argument, and a split whose column is missing gives an empty table."""
    scored = _rows.in_scored_month(table)
    eligible = eligible_rows.eligible_mask(table)
    audited = eligible_rows.budget_table(table, "row_type", scored & eligible).set_index("row_type")
    assert audited["rows"].sum() == (scored & eligible).sum()
    assert "funds_decline" not in audited.index and "risk_decline" not in audited.index   # those rows were dropped
    capsys.readouterr()
    assert len(eligible_rows.budget_table(table.drop(columns=[settings.SEGMENT_COL]), "segment")) == 0
    assert "segment" in capsys.readouterr().out


def test_tool_reads_files_and_writes_the_row_types(table, tmp_path, capsys):
    """The tool joins the raw columns by id, prints the three reads and the budget, and writes on request."""
    synthetic.write_files(table, tmp_path / "raw", 2, first_number=31)
    pred = tables.write_table(table[STANDARD].sample(frac=1.0, random_state=0), str(tmp_path / "pred.parquet"))
    out = str(tmp_path / "out.parquet")
    eligible_rows.main(["--pred", pred, "--raw-base", str(tmp_path / "raw"), "--raw-files", "31-32", "--out", out])
    printed = capsys.readouterr().out
    for title in ("Capture at the alert cut on three populations", "Alert budget by row_type", "Alert budget by day",
                  "Alert budget by segment"):
        assert title in printed
    written = tables.read_columns(out).set_index(settings.ID_COL)
    scored = _rows.in_scored_month(table)
    assert len(written) == scored.sum()
    expected = pd.Series(_rows.row_type(table)[scored], index=table[settings.ID_COL].to_numpy()[scored])
    assert (written["row_type"].reindex(expected.index) == expected).all()
    assert written["eligible"].sum() == (scored & eligible_rows.eligible_mask(table)).sum()
    # Without raw files the row types cannot be told apart: the tool says so and still gives the reads.
    eligible_rows.main(["--pred", pred])
    printed = capsys.readouterr().out
    assert "no raw files were named" in printed and "Capture at the alert cut on three populations" in printed
