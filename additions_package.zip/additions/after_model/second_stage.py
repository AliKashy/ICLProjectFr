"""A tree model on top of the network's out-of-sample scores, and a specialist for the top band.

What this file does
-------------------
It fits gradient-boosted trees on rows the network did not train on and reads, on other
rows, what each way of using them catches at the alert cut:

    score        the network's own score (the base every other line is compared with)
    trees_all    XGBoost fitted on all fit rows. Inputs: the network's logit, its exported
                 vector, the raw fields of the row and the account risk state built from
                 the network's own earlier scores (score_state.py)
    specialist   XGBoost fitted only on the fit rows whose logit is at or above a fixed band
                 floor (about the top 5 percent). On the read rows it re-ranks only the rows
                 inside the band; every row below the band keeps the network's order and
                 stays below every band row
    average      inside the band, the mean of the specialist's logit and the network's
                 logit; below the band, the network's order again

Every tree fit stops early on capture at the alert cut of accounts held out of the fit (a
custom evaluation function built on ranking.capture), not on a measure of the whole ranking.
For the specialist the held-out ranking is the composite one (band re-ranked, the rest in
base order), so its trees are stopped on exactly the ranking they will produce. Each line
carries a paired bootstrap over accounts against the network's score.

Why it exists
-------------
The network ends in a linear head and is judged at one global cut. A tree stage can fix what
such a head cannot: a score that is too high in one segment and too low in another, sharp
thresholds on raw numbers, and memory beyond the network's history window through the
account's earlier scores (frauds come in runs on one account, so most frauds follow an
earlier fraud of that account). A monotone recalibration of one score cannot change the
ranking; a tree stage can.

The specialist rests on a second observation: the alert budget is a fixed small share of
rows, so the order that matters is decided among the rows near the top. A model fitted on
every row spends almost all of its effort on rows that never compete for an alert. Fitted
only inside the band, where fraud is much denser and every non-fraud is a look-alike, a
second model learns what separates the two there. Averaging it with the network keeps what
the network already ranks well. Frauds below the band are out of the specialist's reach, so
the share of read frauds inside the band (band_recall) is printed as its ceiling.

The scores used to fit anything here must come from a model that did not train on those
rows. On its own training rows a network is surer than on new rows; trees fitted there
learn to trust its score more than they should. The files hold whole accounts and no account
is in two files, so scoring files that are outside the training list is enough.

Where it goes
-------------
Second stage, after scoring: the network (stage 1 and stage 2 of the network together, up to
the head in `FTTransformerHierModel.forward`) scores every row; this file reads the export
files and puts trees on top. It never feeds back into the network. A served version holds
one small tree model, the band floor as a number, and the per-account numbers of the score
state.

What to change for the pod
--------------------------
settings.py: ACCOUNT_COL, TIME_COL, LABEL_COL, AMOUNT_COL, SCORE_COL, SCORE_KIND,
VECTOR_PREFIX, NUMERIC_COLS and CODE_COLS (the raw fields of the inputs; with 129 input
fields, list them all there), CARD_COL (adds a card-level score state), TARGET_START and
TARGET_END (the rows that are ranked), OUTSORT_PER_MILLE and the bootstrap settings. In
this file: BAND_PER_MILLE (the width of the band). The tree settings are in _shared.py.
The band floor and the alert cut must be frozen as numbers taken once on the fit rows and
passed to every later read, never found again per file.

How to try it
-------------
    python additions/after_model/second_stage.py --demo
    python additions/after_model/second_stage.py --fit fit_export.parquet --read read_export.parquet --out arms.parquet

    result = second_stage(fit_export, read_export)       # result["table"]: one line per arm
    python -m pytest -q additions/tests/test_after_second_stage.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd

from additions import settings
from additions.after_model import _shared, score_state

# PLACEHOLDER: the width of the specialist's band in rows per thousand of the fit rows (50 is the top
# 5 percent); the floor of the band is taken once on the fit rows as a fixed logit value.
BAND_PER_MILLE = 50

ARMS = ("score", "trees_all", "specialist", "average")


def band_order(base_logit, band_score, in_band):
    """A ranking that re-orders only the band rows and keeps the base order below the band, float64 [rows].

    base_logit   the network's logit per row [rows]
    band_score   the score that orders the band rows [rows]; its values outside the band are ignored
    in_band      yes/no per row [rows]: the rows at or above the band floor

    Every band row is placed above every other row, in the order of `band_score`; the other
    rows keep their base logit, so their order is the network's. The result is only a
    ranking (its values are shifted to put the band on top), not a probability. When
    `band_score` orders the band like the base logit, the ranking is the base ranking.
    """
    base = np.asarray(base_logit, dtype=np.float64)
    inside = np.asarray(in_band, dtype=bool)
    out = base.copy()
    if inside.any():
        s = np.asarray(band_score, dtype=np.float64)[inside]
        # The band starts one unit above the highest row outside it. The scores of the band
        # are shifted, not rescaled, so equal scores stay equal and the order inside is kept.
        top_of_rest = base[~inside].max() if (~inside).any() else 0.0
        out[inside] = top_of_rest + 1.0 + (s - s.min())
    return out


def averaged_band(base_logit, specialist_logit, in_band):
    """Inside the band, the mean of the specialist's and the network's logits; below it, the base order.

    Both logits are log-odds, so their mean is a log-odds too. Returns a ranking as from
    `band_order`, float64 [rows].
    """
    base = np.asarray(base_logit, dtype=np.float64)
    return band_order(base, 0.5 * (base + np.asarray(specialist_logit, dtype=np.float64)), in_band)


def stage_inputs(fit, read, cut, with_state=True, months_back=1, numeric_cols=None, code_cols=None,
                 vector_prefix=None, score_col=None, score_kind=None, card_col=None):
    """The inputs of the trees for the fit table and the read table.

    fit, read     export tables (the code fields are numbered from the values of `fit`)
    cut           the alert cut as a fixed logit value: "at or above the cut" in the score state
    with_state    False leaves the score state out (the logit, the vector and the raw fields remain)
    months_back   the look-back of the score state (see `_shared.month_blocks`)

    Returns (fit_matrix, read_matrix, names): float32 [rows, columns] and the column names.
    The score state uses only strictly earlier seconds of the account and no label.
    """
    x_fit, x_read, names = _shared.base_inputs(fit, read, numeric_cols, code_cols, vector_prefix, score_col,
                                               score_kind)
    if not with_state:
        print("note: the score state is switched off; the trees read the logit, the vector and the raw fields")
        return x_fit, x_read, names
    state_fit = score_state.build_score_state(fit, cut, card_col=card_col, score_col=score_col,
                                              score_kind=score_kind, months_back=months_back)
    state_read = score_state.build_score_state(read, cut, card_col=card_col, score_col=score_col,
                                               score_kind=score_kind, months_back=months_back)
    x_fit = np.column_stack([x_fit, state_fit.to_numpy(dtype=np.float32)])
    x_read = np.column_stack([x_read, state_read.to_numpy(dtype=np.float32)])
    return x_fit, x_read, names + list(state_fit.columns)


def second_stage(fit, read, cut=None, band_floor=None, band_per_mille=None, with_state=True, months_back=1,
                 fit_rows=None, read_rows=None, per_mille=None, rounding=None, draws=None, params=None, rounds=None,
                 patience=None, tree_seed=0):
    """Fit the tree arms on `fit`, read them on `read`, and compare each with the network's score.

    fit, read        export tables (id, account, time, label, amount, score, vector columns and the
                     raw fields). Both must be scored by a network that did not train on their rows;
                     no account may be in both.
    cut              the alert cut as a fixed logit value (default: the cut of the fit rows)
    band_floor       the lowest logit inside the specialist's band, a fixed value (default: the
                     floor of the top `band_per_mille` of the fit rows)
    band_per_mille   the width of the band when the floor is found (default: BAND_PER_MILLE)
    with_state       False leaves the score state out of the inputs
    months_back      the look-back of the score state
    fit_rows         yes/no per row of `fit`: rows the trees may be fitted on (default: rows whose
                     look-back is complete)
    read_rows        yes/no per row of `read`: rows that are ranked (default: the scored month)
    per_mille, rounding, draws    the alert budget and the bootstrap draws (default: settings)
    params, rounds, patience, tree_seed   passed to `_shared.fit_trees`

    Returns a dict:
      "table"    DataFrame, one line per arm: arm, trees, udr, vdr, base_udr, gain, low, high,
                 share_above_zero, draws
      "scores"   DataFrame with one column per arm, one row per row of `read` (the arm's ranking value)
      "info"     {arm: the info dict of `_shared.fit_trees`} for the two fitted arms
      "cut", "band_floor", "band_recall"   the two frozen numbers and the share of the ranked
                 frauds of `read` that lie inside the band (the specialist's ceiling)
    """
    band_per_mille = BAND_PER_MILLE if band_per_mille is None else band_per_mille
    y_fit, y_read = _shared.fraud_flags(fit), _shared.fraud_flags(read)
    account_fit, secs_fit = _shared.account_and_time(fit)
    account_read, _ = _shared.account_and_time(read)
    logit_fit, logit_read = _shared.logits(fit), _shared.logits(read)
    fit_rows = _shared.full_lookback(secs_fit, months_back) if fit_rows is None else np.asarray(fit_rows, dtype=bool)
    read_rows = _shared.scored_rows(read) if read_rows is None else np.asarray(read_rows, dtype=bool)
    # Both numbers are taken once, on the fit rows, and then used unchanged on the read rows.
    cut = _shared.cut_value(logit_fit[fit_rows], per_mille, rounding) if cut is None else float(cut)
    band_floor = (_shared.cut_value(logit_fit[fit_rows], band_per_mille, rounding) if band_floor is None
                  else float(band_floor))
    band_fit, band_read = logit_fit >= band_floor, logit_read >= band_floor
    x_fit, x_read, _ = stage_inputs(fit, read, cut, with_state, months_back)
    common = {"per_mille": per_mille, "rounding": rounding, "params": params, "rounds": rounds,
              "patience": patience, "seed": tree_seed}

    # All rows: stopped on capture at the cut of the held-out accounts, ranked by the trees' logit.
    booster, info_all = _shared.fit_trees(x_fit, y_fit, account_fit, fit_rows=fit_rows, stop_on="capture", **common)
    all_read = _shared.tree_margin(booster, info_all, x_read)

    # The specialist: fitted only on band rows. Its held-out accounts are judged on the whole
    # composite ranking (band re-ranked, the rest in base order), because that is what it produces.
    def compose(margin, positions):
        return band_order(logit_fit[positions], margin, band_fit[positions])

    if not (band_fit & fit_rows).any():
        raise ValueError("no fit row lies at or above the band floor; lower the floor or widen the band")
    booster, info_spec = _shared.fit_trees(x_fit, y_fit, account_fit, fit_rows=fit_rows & band_fit, compose=compose,
                                           stop_on="capture", **common)
    if info_spec["trees"] == 0:
        # No tree beat the starting point; a specialist without trees has no opinion, so the
        # band keeps the network's order.
        spec_read = logit_read.copy()
    else:
        spec_read = _shared.tree_margin(booster, info_spec, x_read)

    scores = pd.DataFrame({
        "score": logit_read,
        "trees_all": all_read,
        "specialist": band_order(logit_read, spec_read, band_read),
        "average": averaged_band(logit_read, spec_read, band_read),
    }, index=read.index)
    trees = {"score": 0, "trees_all": info_all["trees"], "specialist": info_spec["trees"],
             "average": info_spec["trees"]}

    # The read: every arm on the same ranked rows, against the network's own score.
    y, units = y_read[read_rows], account_read[read_rows]
    amount = _shared.amounts(read)
    amount = None if amount is None else amount[read_rows]
    lines = []
    for arm in ARMS:
        line = _shared.arm_line(arm, units, y, scores[arm].to_numpy()[read_rows], logit_read[read_rows], amount,
                                per_mille, rounding, draws)
        lines.append({"arm": arm, "trees": trees[arm], **{k: v for k, v in line.items() if k != "arm"}})
    ranked_frauds = y > 0
    band_recall = float(band_read[read_rows][ranked_frauds].mean()) if ranked_frauds.any() else np.nan
    return {"table": pd.DataFrame(lines), "scores": scores, "info": {"trees_all": info_all, "specialist": info_spec},
            "cut": cut, "band_floor": band_floor, "band_recall": band_recall}


def main(argv=None):
    """Command line: fit the tree arms on one export file and read them on another."""
    parser = argparse.ArgumentParser(description="Tree second stage and top-band specialist on the network's "
                                                 "out-of-sample scores.")
    parser.add_argument("--fit", default=None,
                        help="export file the trees are fitted on (not the network's training rows)")
    parser.add_argument("--read", default=None, help="export file the trees are read on")
    parser.add_argument("--cut", type=float, default=None,
                        help="alert cut as a fixed logit value (default: from --fit)")
    parser.add_argument("--band-floor", type=float, default=None,
                        help="lowest logit inside the specialist's band (default: from --fit)")
    parser.add_argument("--band-per-mille", type=int, default=None,
                        help=f"band width in rows per thousand when the floor is found (default: {BAND_PER_MILLE})")
    parser.add_argument("--no-state", action="store_true", help="leave the score state out of the inputs")
    parser.add_argument("--months-back", type=int, default=1,
                        help="whole months before the row's month that the score state may read; -1 reads everything")
    parser.add_argument("--all-rows", action="store_true", help="rank every row of --read, not only the scored month")
    parser.add_argument("--per-mille", type=int, default=None, help="alert budget in rows per thousand")
    parser.add_argument("--draws", type=int, default=None, help="bootstrap draws (default: settings.BOOTSTRAP_DRAWS)")
    parser.add_argument("--rounds", type=int, default=None, help="most trees per fit (default: _shared.TREE_ROUNDS)")
    parser.add_argument("--seed", type=int, default=0, help="seed of the tree fits and of the held-out accounts")
    parser.add_argument("--demo", action="store_true", help="run on made-up rows instead of files")
    parser.add_argument("--out", default=None, help="write the table of arms to this parquet file")
    parser.add_argument("--scores-out", default=None,
                        help="write the id and every arm's ranking value per read row to this parquet file")
    args = parser.parse_args(argv)
    if not args.demo and not (args.fit and args.read):
        parser.error("give --fit FILE and --read FILE, or --demo to run on made-up rows")

    if args.demo:
        fit = _shared.demo_export(seed=1, days=92, start=settings.TRAIN_HISTORY_START)
        read = _shared.demo_export(seed=2)
    else:
        fit, read = _shared.load_export(args.fit), _shared.load_export(args.read)
    result = second_stage(fit, read, cut=args.cut, band_floor=args.band_floor, band_per_mille=args.band_per_mille,
                          with_state=not args.no_state,
                          months_back=None if args.months_back < 0 else args.months_back,
                          read_rows=np.ones(len(read), dtype=bool) if args.all_rows else None,
                          per_mille=args.per_mille, draws=args.draws, rounds=args.rounds, tree_seed=args.seed)
    # The two numbers are printed so that they can be frozen and passed to every later read.
    print(f"alert cut (logit): {result['cut']:.6f}   band floor (logit): {result['band_floor']:.6f}")
    print(f"share of the ranked frauds inside the band (the specialist's ceiling): {result['band_recall']:.4f}")
    _shared.show("Second stage on out-of-sample scores (gain is against the network's own score)", result["table"])
    if args.out:
        _shared.save(result["table"], args.out)
    if args.scores_out:
        out = result["scores"].reset_index(drop=True)
        if settings.ID_COL in read.columns:
            out.insert(0, settings.ID_COL, read[settings.ID_COL].to_numpy())
        else:
            print(f"note: the table has no column '{settings.ID_COL}'; the rows of the output are in input order")
        _shared.save(out, args.scores_out)
    return result


if __name__ == "__main__":
    main()
