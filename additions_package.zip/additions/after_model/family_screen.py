"""Screens one family of candidate columns at a time on top of the model's own score.

What this file does
-------------------
For every family of candidate columns (for example all outcome-history columns, or all
amount-novelty columns) it fits a small XGBoost model whose only inputs are the columns of
that family and whose starting point (base margin) is the model's own logit. The trees can
therefore only add what the family knows and the score does not. Per family it reports:

    loss_drop        how much the log loss of the read rows falls from the score alone to the
                     score plus the family (positive is better)
    inner_loss_drop  the same on the accounts held out of the fit for early stopping
    gain, low, high  the change in the share of frauds inside the alert cut on the read rows,
                     with an interval from a paired bootstrap over accounts
    unstable         columns whose one-column model, fitted on the early months of the fit
                     rows, no longer ranks frauds above other rows on the late months

and a verdict: "pass" when the gain is at least PASS_GAIN and its interval lies above zero,
"park" otherwise. A park is not a verdict against the family: a column can carry something
the network could use in sequence form that a tree on top of the score cannot.

Why it exists
-------------
A training run of the network costs hours of GPU time, and a single run carries seed noise
of the same size as the gains being looked for. A tree on top of the score has no seed
noise and costs minutes of CPU per family, so it answers "is there anything here that the
model does not already know?" before any training run is spent. A family that adds nothing
on top of the score is not worth a training run. A family that adds something is a
candidate input of the network and, at the same time, a column worth exporting for other
models.

Three details keep the screen honest. Early stopping uses an inner split of the fit
accounts (the files hold whole accounts, so held-out accounts are clean), never the read
rows, so the read rows are looked at once per family and not used to choose anything.
Stopping uses the log loss, the smooth measure; capture at the cut moves in jumps on a
small inner split, which is a poor guide for when to stop but the right thing to report.
The stability check catches columns whose meaning drifts over months (a code that is
re-used, a counter that is reset): fitted on early months they rank the wrong way on late
months, and a network trained on months that do not include the scored month would learn
the wrong direction.

The screen cannot see a column that leaks the label. A column built with a look at later
rows, or a snapshot written after the fraud, passes with a large gain. The candidate
columns must be built with the time rule of this package: from rows of strictly earlier
seconds only, never from labels of other rows (additions/features/ builds them that way,
and additions/features/asof_audit.py checks date columns).

Where it goes
-------------
Comparison, on the CPU, after scoring and before a training run. It reads two export tables
(one row per scored transaction with id, account, time, label and score) to which the
candidate columns have been joined. The scores must come from a model that did not train
on those rows: on training rows the score is sharper than on new rows, and every family
would look useless against it. A family that passes becomes an input of the network (a
new field token in FeatureTokenizer, or a column of SequenceBuilder._encode_file) and a
side column in the exports.

A sensible order of work: screen every family on a small block of files, keep the better
half, screen those again on a larger block, and so on; then fit the network once with all
survivors together.

What to change for the pod
--------------------------
FAMILIES below: the candidate families and their columns (exact names, or a prefix that
ends with "*"). PASS_GAIN, STABILITY_FLOOR, STABILITY_PARAMS and STABILITY_ROUNDS.
settings.py: ID_COL, ACCOUNT_COL, TIME_COL, LABEL_COL, POSITIVE_LABEL, AMOUNT_COL, SCORE_COL,
SCORE_KIND, TARGET_START and TARGET_END (the rows that are read), OUTSORT_PER_MILLE and the
bootstrap settings. The tree settings and the inner share are in _shared.py.

How to try it
-------------
    python additions/after_model/family_screen.py --demo
    python additions/after_model/family_screen.py --fit fit_export.parquet --read read_export.parquet \\
        --family outcome='outcome_*' --family novelty='novelty_*' --out screen.parquet

    table, stability_table = screen(fit_export, read_export, {"outcome": ["outcome_*"]})
    python -m pytest -q additions/tests/test_after_family_screen.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.metrics import roc_auc_score

from additions import settings
from additions.after_model import _shared
from additions.common import tables, timekeys
from additions.common.timekeys import MISSING_SECOND

# PLACEHOLDER: the candidate families, as {family name: [column names, or prefixes ending with "*"]}.
# The examples are the prefixes written by the builders in additions/features/ and by score_state.py.
FAMILIES = {
    "outcome_history": ["outcome_*"],
    "amount_novelty": ["novelty_*"],
    "exact_match": ["match_*"],
    "ratios": ["ratio_*"],
    "surprise": ["surprise_*"],
    "score_state": ["state_*"],
}

# PLACEHOLDER: the least gain in the share of frauds caught at the cut for a family to pass.
PASS_GAIN = 0.005

# PLACEHOLDER: a one-column model must score an AUC above this on the late months to be stable.
STABILITY_FLOOR = 0.5

# PLACEHOLDER: settings of the small one-column models of the stability check.
# The small min_child_weight lets a split form on a few hundred rows even when fraud is rare (the
# weight of a row is p * (1 - p), which is tiny when p is small).
STABILITY_PARAMS = {"objective": "binary:logistic", "eta": 0.1, "max_depth": 2, "min_child_weight": 0.5,
                    "tree_method": "hist"}
STABILITY_ROUNDS = 50

COLUMNS = ["family", "columns", "trees", "inner_loss_drop", "loss_drop", "udr", "vdr", "base_udr", "gain", "low",
           "high", "share_above_zero", "draws", "unstable", "worst_auc", "verdict"]
STABILITY_COLUMNS = ["family", "column", "early_rows", "late_rows", "auc_late", "stable"]


# ----------------------------------------------------------------------------------------------
# families and their columns
# ----------------------------------------------------------------------------------------------

def resolve_family(entries, names):
    """The columns of one family that exist, in a stable order.

    entries   column names, or prefixes that end with "*" (a prefix matches every column that
              starts with it)
    names     the column names that are available (a table's columns, or a file's)

    Returns a list of names without repeats. An exact name that is not available is left
    out; the caller says so.
    """
    found = []
    for entry in entries:
        if entry.endswith("*"):
            found += [c for c in names if isinstance(c, str) and c.startswith(entry[:-1])]
        elif entry in names:
            found.append(entry)
    return list(dict.fromkeys(found))


def _numbers(fit_values, read_values):
    """One family column of both tables as float64 arrays. Text or code columns are numbered by frequency.

    A numeric column is used as it is (infinite values become missing). A column of codes
    becomes 0 for the value most frequent in the fit table, 1 for the next, and so on, so that
    a tree can split rare values off with one threshold; a value the fit table never holds
    becomes missing, which the trees route on their own.
    """
    if pd.api.types.is_numeric_dtype(fit_values.dtype) or pd.api.types.is_bool_dtype(fit_values.dtype):
        a = pd.to_numeric(fit_values, errors="coerce").to_numpy(dtype=np.float64)
        b = pd.to_numeric(read_values, errors="coerce").to_numpy(dtype=np.float64)
    else:
        order = fit_values.value_counts().index
        number = pd.Series(np.arange(len(order), dtype=np.float64), index=order)
        a = fit_values.map(number).to_numpy(dtype=np.float64)
        b = read_values.map(number).to_numpy(dtype=np.float64)
    a[~np.isfinite(a)] = np.nan
    b[~np.isfinite(b)] = np.nan
    return a, b


def family_matrices(fit, read, columns):
    """The family's columns of both tables as float32 matrices [rows, columns].

    Only columns that are in both tables are used; the list of those is returned as well.
    Returns (fit_matrix, read_matrix, used_columns); the matrices are None when no column is left.
    """
    used = [c for c in columns if c in fit.columns and c in read.columns]
    if not used:
        return None, None, used
    pairs = [_numbers(fit[c], read[c]) for c in used]
    return (np.column_stack([p[0] for p in pairs]).astype(np.float32),
            np.column_stack([p[1] for p in pairs]).astype(np.float32), used)


# ----------------------------------------------------------------------------------------------
# the stability check
# ----------------------------------------------------------------------------------------------

def default_split(secs):
    """The second that splits rows into early and late months: the start of the middle month.

    With months m1 .. mk present, the late part starts at month number (k + 1) // 2 + 1, so
    three months split into two early and one late, four into two and two. With a single
    month the median second is used and one line says so. Returns an int (seconds).
    """
    secs = np.asarray(secs, dtype=np.int64)
    real = secs[secs != MISSING_SECOND]
    if len(real) == 0:
        return 0
    months = np.unique(timekeys.month_start_seconds(real, 0))
    if len(months) >= 2:
        return int(months[(len(months) + 1) // 2])
    print("note: the fit rows span one month only; the stability check splits them at the median second")
    return int(np.median(real))


def one_column_auc(x_early, y_early, x_late, y_late, params=None, rounds=None):
    """AUC on the late rows of a one-column tree model fitted on the early rows; NaN when it cannot be read.

    x_early, x_late   float [rows]: the column (missing values allowed)
    y_early, y_late   0/1 [rows]

    The model is a few shallow trees, so it can follow a column that is not monotone (a
    risk that is high at both ends, say). An AUC of 0.5 or less means the direction learned
    on early months does not hold on late months. NaN is returned when either part has no
    fraud or no non-fraud row, and when the model gives every late row the same value (the
    early months held no split worth making, so there is no direction to check).
    """
    y_early = np.asarray(y_early, dtype=np.float64)
    y_late = np.asarray(y_late, dtype=np.float64)
    if len(y_early) == 0 or len(y_late) == 0:
        return np.nan
    if y_early.min() == y_early.max() or y_late.min() == y_late.max():
        return np.nan
    setup = {**STABILITY_PARAMS, **(params or {}), "seed": 0}
    booster = xgb.train(setup, xgb.DMatrix(np.asarray(x_early, dtype=np.float32)[:, None], label=y_early),
                        STABILITY_ROUNDS if rounds is None else int(rounds))
    predicted = booster.predict(xgb.DMatrix(np.asarray(x_late, dtype=np.float32)[:, None]))
    if predicted.min() == predicted.max():
        return np.nan
    return float(roc_auc_score(y_late, predicted))


def stability(x_fit, names, labels, secs, rows=None, split=None, family="", floor=None, params=None, rounds=None):
    """The stability check of one family: one line per column. Returns a DataFrame (STABILITY_COLUMNS).

    x_fit    float [rows, columns]: the family on the fit table
    names    the column names, in the order of the matrix
    labels   0/1 per row; secs whole seconds per row
    rows     yes/no per row: the rows the check may use (default: all with a time)
    split    the second at which the late months start (default: `default_split` of those rows)

    Only fit rows are used, so the check takes no extra look at the read rows.
    """
    floor = STABILITY_FLOOR if floor is None else floor
    secs = np.asarray(secs, dtype=np.int64)
    rows = secs != MISSING_SECOND if rows is None else np.asarray(rows, dtype=bool) & (secs != MISSING_SECOND)
    split = default_split(secs[rows]) if split is None else int(split)
    early, late = rows & (secs < split), rows & (secs >= split)
    y = np.asarray(labels, dtype=np.float64)
    lines = []
    for j, name in enumerate(names):
        auc = one_column_auc(x_fit[early, j], y[early], x_fit[late, j], y[late], params, rounds)
        lines.append({"family": family, "column": name, "early_rows": int(early.sum()), "late_rows": int(late.sum()),
                      # A column whose AUC cannot be read is not called unstable: there is no evidence either way.
                      "auc_late": auc, "stable": bool(np.isnan(auc) or auc > floor)})
    return pd.DataFrame(lines, columns=STABILITY_COLUMNS)


# ----------------------------------------------------------------------------------------------
# the screen
# ----------------------------------------------------------------------------------------------

def inner_units(fit, split_by="account", account_col=None):
    """What the inner split of the fit table holds out: whole accounts, or whole files.

    split_by   "account", or "file" to hold out whole fit files (needs the `_file` column that
               additions/common/tables.read_files adds; with few files the inner split may
               hold no fraud, so use it only with ten or more fit files)
    """
    if split_by == "file":
        if "_file" in fit.columns:
            return fit["_file"].to_numpy()
        print("note: the fit table has no '_file' column; the inner split holds out whole accounts instead")
    return fit[_shared.pick(account_col, "ACCOUNT_COL")].to_numpy()


def screen_family(name, x_fit, x_read, y_fit, y_read, logit_fit, logit_read, units_fit, accounts_read, fit_rows,
                  read_rows, amount_values=None, per_mille=None, rounding=None, draws=None, params=None,
                  rounds=None, patience=None, inner_share=None, tree_seed=0):
    """Fit the trees of one family on top of the logit and read them. Returns one result line (a dict).

    x_fit, x_read          float32 [rows, columns]: the family on the fit and on the read table
    y_fit, y_read          0/1 per row; logit_fit, logit_read: the model's own log-odds per row
    units_fit              one value per fit row: what the inner split holds out (accounts or files)
    accounts_read          one value per read row: what the bootstrap resamples
    fit_rows, read_rows    yes/no per row: rows the trees are fitted on, rows that are read
    amount_values          dollars per read row (already cut to `read_rows`), or None

    The trees start from the logit (base margin) and stop on the log loss of the held-out
    part of the fit table. When no number of trees beats the logit there, no tree is used
    and the line shows a gain of exactly zero.
    """
    booster, info = _shared.fit_trees(x_fit, y_fit, units_fit, base_margin=logit_fit, fit_rows=fit_rows,
                                      stop_on="logloss", per_mille=per_mille, rounding=rounding, params=params,
                                      rounds=rounds, patience=patience, inner_share=inner_share, seed=tree_seed)
    margin = _shared.tree_margin(booster, info, x_read, logit_read)
    y, base, screened = y_read[read_rows], logit_read[read_rows], margin[read_rows]
    line = _shared.arm_line(name, accounts_read[read_rows], y, screened, base, amount_values, per_mille, rounding, draws)
    line["trees"] = info["trees"]
    # Positive numbers mean the family lowered the loss. With zero trees both are exactly zero.
    line["inner_loss_drop"] = info["inner_start"] - info["inner_score"] if info["trees"] else 0.0
    line["loss_drop"] = _shared.log_loss(y, base) - _shared.log_loss(y, screened)
    return line


def screen(fit, read, families=None, fit_rows=None, read_rows=None, split_by="account", stability_split=None,
           per_mille=None, rounding=None, draws=None, params=None, rounds=None, patience=None, inner_share=None,
           pass_gain=None, months_back=1, tree_seed=0, account_col=None):
    """Screen every family. Returns (table, stability_table), both DataFrames.

    fit, read        export tables (id, account, time, label, score) with the candidate columns
                     joined. Both must be scored by a model that did not train on their rows,
                     and no account may be in both.
    families         {name: [columns or prefixes ending with "*"]} (default: FAMILIES)
    fit_rows         yes/no per fit row: rows the trees are fitted on (default: rows whose
                     look-back is complete, see `_shared.full_lookback` with `months_back`)
    read_rows        yes/no per read row: rows that are read (default: the scored month)
    split_by         "account" or "file": what the inner split of the fit table holds out
    stability_split  the second (or a date as text) at which the late months start
    pass_gain        the least gain for "pass" (default: PASS_GAIN)
    account_col      the account column (default: settings.ACCOUNT_COL); the other names are
                     read from settings through _shared.py

    `table` has one line per family (COLUMNS), best gain first; `stability_table` has one
    line per column (STABILITY_COLUMNS). A family with no column in both tables gets a line
    with the verdict "missing" and the run goes on.
    """
    families = FAMILIES if families is None else families
    pass_gain = PASS_GAIN if pass_gain is None else pass_gain
    y_fit, y_read = _shared.fraud_flags(fit), _shared.fraud_flags(read)
    _, secs_fit = _shared.account_and_time(fit)
    logit_fit, logit_read = _shared.logits(fit), _shared.logits(read)
    fit_rows = _shared.full_lookback(secs_fit, months_back) if fit_rows is None else np.asarray(fit_rows, dtype=bool)
    read_rows = _shared.scored_rows(read) if read_rows is None else np.asarray(read_rows, dtype=bool)
    if isinstance(stability_split, str):
        stability_split = int(timekeys.seconds(pd.Series([pd.Timestamp(stability_split)]))[0])
    units_fit = inner_units(fit, split_by, account_col)
    accounts_read = read[_shared.pick(account_col, "ACCOUNT_COL")].to_numpy()
    amount = _shared.amounts(read)
    amount = None if amount is None else amount[read_rows]
    lines, checks = [], []
    for name, entries in families.items():
        columns = resolve_family(entries, list(fit.columns))
        x_fit, x_read, used = family_matrices(fit, read, columns)
        if x_fit is None:
            print(f"note: no column of family '{name}' ({entries}) is in both tables; the family is skipped")
            lines.append({"family": name, "columns": 0, "verdict": "missing"})
            continue
        line = screen_family(name, x_fit, x_read, y_fit, y_read, logit_fit, logit_read, units_fit, accounts_read,
                             fit_rows, read_rows, amount, per_mille, rounding, draws, params, rounds, patience,
                             inner_share, tree_seed)
        check = stability(x_fit, used, y_fit, secs_fit, fit_rows, stability_split, name)
        checks.append(check)
        unstable = check.loc[~check["stable"], "column"].tolist()
        line.pop("arm")
        passed = line["gain"] >= pass_gain and line["low"] > 0         # NaN compares as False: no pass
        lines.append({"family": name, "columns": len(used), **line, "unstable": ", ".join(unstable),
                      "worst_auc": float(check["auc_late"].min()) if check["auc_late"].notna().any() else np.nan,
                      "verdict": "pass" if passed else "park"})
    table = pd.DataFrame(lines, columns=COLUMNS).sort_values("gain", ascending=False, na_position="last")
    stability_table = pd.concat(checks, ignore_index=True) if checks else pd.DataFrame(columns=STABILITY_COLUMNS)
    return table.reset_index(drop=True), stability_table


# ----------------------------------------------------------------------------------------------
# made-up families and the command line
# ----------------------------------------------------------------------------------------------

def demo_tables(n_accounts=1500, seed=0):
    """Made-up fit and read tables with three candidate families, and those families.

    earlier_scores   the account risk state from earlier scores (score_state.py): it knows
                     about runs, which the made-up score does not
    network_score    the raw network risk score, which the made-up score already contains in part
    noise            two columns of pure noise

    Returns (fit, read, families). Nothing read on these tables says anything about a real model.
    """
    from additions.after_model import score_state                   # only the demo needs it
    fit = _shared.demo_export(n_accounts=n_accounts, seed=seed + 1, days=92, start=settings.TRAIN_HISTORY_START)
    read = _shared.demo_export(n_accounts=n_accounts, seed=seed + 2)
    _, secs = _shared.account_and_time(fit)
    cut = _shared.cut_value(_shared.logits(fit)[_shared.full_lookback(secs)])
    rng = np.random.default_rng(seed)
    for df in (fit, read):
        state = score_state.build_score_state(df, cut)
        for c in state.columns:
            df[c] = state[c].to_numpy()
        df["noise_0"], df["noise_1"] = rng.normal(size=len(df)), rng.integers(0, 5, len(df)).astype(float)
    families = {"earlier_scores": ["state_*"], "network_score": [settings.VISA_SCORE_COL], "noise": ["noise_*"]}
    return fit, read, families


def parse_families(texts):
    """Turn --family arguments of the form NAME=COL,PREFIX_*,... into a families dict."""
    families = {}
    for text in texts:
        name, _, columns = text.partition("=")
        families[name.strip()] = [c.strip() for c in columns.split(",") if c.strip()]
    return families


def load_for_families(path, families):
    """Read an export file with the columns of every family that the file holds."""
    have = tables.available_columns(path)
    wanted = [c for entries in families.values() for c in resolve_family(entries, have)]
    return _shared.load_export(path, extra_columns=wanted)


def main(argv=None):
    """Command line: screen candidate families on top of the model's score."""
    parser = argparse.ArgumentParser(
        description="Screen families of candidate columns on top of the model's own score.")
    parser.add_argument("--fit", default=None, help="export file with candidate columns; the trees are fitted here")
    parser.add_argument("--read", default=None, help="export file with candidate columns; the trees are read here")
    parser.add_argument("--family", action="append", default=[],
                        help="NAME=COL1,COL2,PREFIX_* (repeat for several families; default: FAMILIES in this file)")
    parser.add_argument("--split-by", choices=("account", "file"), default="account",
                        help="what the inner split of the fit table holds out")
    parser.add_argument("--stability-split", default=None, help="first day of the late months (default: middle month)")
    parser.add_argument("--all-rows", action="store_true", help="read every row of --read, not only the scored month")
    parser.add_argument("--per-mille", type=int, default=None, help="alert budget in rows per thousand")
    parser.add_argument("--draws", type=int, default=None, help="bootstrap draws (default: settings.BOOTSTRAP_DRAWS)")
    parser.add_argument("--rounds", type=int, default=None, help="most trees per family (default: _shared.TREE_ROUNDS)")
    parser.add_argument("--patience", type=int, default=None, help="rounds without improvement that end a fit")
    parser.add_argument("--demo", action="store_true", help="run on made-up rows instead of files")
    parser.add_argument("--accounts", type=int, default=1500, help="accounts per made-up table (with --demo)")
    parser.add_argument("--out", default=None, help="write the table of families to this parquet file")
    parser.add_argument("--stability-out", default=None, help="write the table of the stability check to this file")
    args = parser.parse_args(argv)
    if not args.demo and not (args.fit and args.read):
        parser.error("give --fit FILE and --read FILE, or --demo to run on made-up rows")

    families = parse_families(args.family) if args.family else None
    if args.demo:
        fit, read, demo_families = demo_tables(args.accounts)
        families = families or demo_families
    else:
        families = families or FAMILIES
        fit, read = load_for_families(args.fit, families), load_for_families(args.read, families)
    table, stability_table = screen(fit, read, families, split_by=args.split_by, stability_split=args.stability_split,
                                    read_rows=np.ones(len(read), dtype=bool) if args.all_rows else None,
                                    per_mille=args.per_mille, draws=args.draws, rounds=args.rounds,
                                    patience=args.patience)
    _shared.show("Families on top of the model's score (gain: change in the share of frauds caught at the cut)",
                 table.drop(columns=["unstable"]))
    _shared.show("Stability: one-column models fitted on early months, read on late months", stability_table)
    for _, line in table.iterrows():
        if isinstance(line["unstable"], str) and line["unstable"]:
            print(f"family '{line['family']}': drop before a training run: {line['unstable']}")
    if args.out:
        _shared.save(table, args.out)
    if args.stability_out:
        _shared.save(stability_table, args.stability_out)
    return table, stability_table


if __name__ == "__main__":
    main()
