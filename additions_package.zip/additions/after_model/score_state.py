"""Account risk state from the model's own EARLIER scores.

What this file does
-------------------
For every row it describes what the model itself said about the account's earlier rows.
Everything is built from rows of the same account in strictly earlier seconds, and scores
are log-odds throughout:

    prev_logit, secs_since_prev        the score of the previous row, and how long ago that row was
    max_1h, max_24h, max_7d, max_30d   the highest earlier score inside each window
    n_high_1h ... n_high_30d           earlier rows that scored at or above the alert cut
    secs_since_high                    seconds since the last such row (inside 30 days)
    decayed_sum_<h>, decayed_n_<h>     the sum of the earlier scores and the number of earlier rows, each
                                       row halved for every half-life of age (10m, 1h, 6h, 1d, 7d, 30d)
    decayed_mean_<h>                   the first divided by the second: a mean that favours recent rows
    n_rows_30d                         earlier rows in 30 days (how much there was to look at)
    minus_mean_30d                     the row's own score minus the account's 30-day mean
    rank_30d                           the share of the account's 30-day scores that lie below the row's
    latch_sum, latched                 a running alarm with a latch (below)

Every name carries the prefix `state_`. When a card column is set (settings.CARD_COL) the
same columns are built a second time for the account and card, with the prefix `state_card_`.

The running alarm is a sum, over the earlier rows, of how far each score lay above a
baseline. It fades with a short half-life. Once it has reached a threshold the account is
latched: from then on the sum fades with a long half-life, until it has fallen to a release
level, where the latch opens and the short half-life applies again. One very high score, or
a few raised scores close together, therefore keep an account marked for days, while a
single mildly raised score is forgotten within a day.

The alert cut is a fixed score value that is passed in. It is not found again on every file:
"at or above the cut" has to mean the same score on the fit files, on the scored files and
in live use.

Why it exists
-------------
Frauds come in runs on one account, so most frauds follow an earlier fraud of that account.
Fraud labels arrive weeks after the transaction, so inside a run nobody can tell the model
that the previous row was fraud. What is known at once is the model's own verdict on the
earlier rows. The second stage of the network reads the vectors of a limited number of
earlier rows, but not the score it gave them, and nothing older. One number per earlier row
is the cheapest long memory there is. Day-long means dilute a run of three rows inside an
hour; peaks, counts above the cut and the time since the last high score keep it. A
downstream tree model gains columns it can split on directly, and the network gains a
memory that reaches past its history window.

No label is used anywhere in this file: only the account, the time and the score.

Two cautions. Scores used to fit anything on these columns must come from a model that did
not train on those rows. On its own training rows a model is surer than on new rows, and a
second model fitted there would trust the state more than it deserves; the files hold whole
accounts and no account is in two files, so scoring files outside the training list is
enough. And in production an alert blocks the card, so the later rows of a caught run would
never happen: part of the gain measured offline would not be seen live.

Where it goes
-------------
After scoring (scores), in front of anything that consumes scores: the second stage in
second_stage.py, the measurement in oracle_ladder.py, or an export of columns for other
models. For a second pass of the network the columns become extra numeric inputs of the
scored row: appended where `SequenceBuilder._encode_file` builds the per-row arrays, and
turned into tokens by `FeatureTokenizer`. A served version keeps, per account, two numbers
per half-life, the latch sum and the times and scores of the recent rows.

What to change for the pod
--------------------------
settings.py: ACCOUNT_COL, TIME_COL, SCORE_COL, SCORE_KIND, CARD_COL (None skips the card
state), ID_COL (written with --out), OUTSORT_PER_MILLE (only when the tool takes the cut from
a file). In this file: the latch settings (they are in log-odds, so they depend on the scale
of the model's score), WINDOWS, HALF_LIVES and the two prefixes. `months_back=1` fits
evaluation files that start one month before the scored month; `months_back=None` reads
everything in the table and suits a store that always holds the same number of days.

How to try it
-------------
    python additions/after_model/score_state.py --demo
    python additions/after_model/score_state.py --export read_export.parquet --cut-from fit_export.parquet --out state.parquet

    cut = _shared.cut_value(_shared.logits(fit_export))        # once, on the fit rows; then frozen
    state = build_score_state(read_export, cut)                # one line per row of the export
    python -m pytest -q additions/tests/test_after_score_state.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd

from additions import settings
from additions.after_model import _shared
from additions.common import timekeys
from additions.common.history import EarlierRows
from additions.common.timekeys import MISSING_SECOND

# The windows and the half-lives, as (label, seconds). The longest window is 30 days because a
# scored row always has at least one month of history, so a 30-day window is never cut short.
WINDOWS = (("1h", 3_600), ("24h", 86_400), ("7d", 7 * 86_400), ("30d", 30 * 86_400))
HALF_LIVES = (("10m", 600), ("1h", 3_600), ("6h", 6 * 3_600), ("1d", 86_400), ("7d", 7 * 86_400), ("30d", 30 * 86_400))

# PLACEHOLDER: the latch, in log-odds of the model's score; tune the four numbers on the fit files.
LATCH_BASELINE_BELOW_CUT = 2.0     # the baseline lies this far below the cut: rows near the cut already add evidence
LATCH_THRESHOLD = 4.0              # the sum at which the latch closes (two rows at the cut, or one far above it)
LATCH_RELEASE = 2.0                # the sum at which the latch opens again
LATCH_HALF_LIFE = 86_400           # seconds: how fast the sum fades while the latch is open
LATCHED_HALF_LIFE = 7 * 86_400     # seconds: how fast it fades while the latch is closed

# PLACEHOLDER: the prefixes of the column names written for the account and for the account and card.
STATE_PREFIX = "state_"
CARD_PREFIX = "state_card_"

# A faded count below this is read as "nothing left": the mean of a memory that weak is noise.
FADED_OUT = 1e-9


def column_names(prefix=""):
    """The names of the state columns, in the order in which they are built."""
    longest = WINDOWS[-1][0]
    names = ["prev_logit", "secs_since_prev"]
    names += [f"max_{label}" for label, _ in WINDOWS] + [f"n_high_{label}" for label, _ in WINDOWS]
    names += ["secs_since_high"]
    for kind in ("decayed_sum", "decayed_n", "decayed_mean"):
        names += [f"{kind}_{label}" for label, _ in HALF_LIVES]
    names += [f"n_rows_{longest}", f"minus_mean_{longest}", f"rank_{longest}", "latch_sum", "latched"]
    return [prefix + name for name in names]


def rank_among_earlier(engine, values, window=None):
    """Where a row's value stands among the strictly earlier rows of its key, float64 [rows].

    engine   an `EarlierRows` object for the key
    values   one number per row [rows]; rows with a missing value are not counted
    window   seconds; None means every earlier row

    The result is the share of the earlier rows whose value lies below the row's own value,
    with equal values counted half; missing when there is no earlier row. 1.0 means "higher
    than anything this account showed in the window".

    The comparison depends on the row itself, so prefix sums cannot answer it. The loop below
    walks back one earlier row at a time for all rows at once: step k compares every row with
    the k-th row before it. The number of Python steps is the longest history inside the
    window (in rows), not the number of rows.
    """
    lo, hi = engine.bounds(window)
    v = np.asarray(values, dtype=np.float64)[engine.order]
    counts = engine.valid & ~np.isnan(v)                       # rows that may be compared with
    length = hi - lo                                           # earlier rows inside the window
    below = np.zeros(engine.n)
    seen = np.zeros(engine.n)
    longest = int(length.max()) if engine.n else 0
    # Rows sorted by the length of their history, longest first: the rows that still have a
    # k-th earlier row are then always the first so-many of this order.
    by_length = np.argsort(-length, kind="stable")
    at_least = np.cumsum(np.bincount(length, minlength=longest + 1)[::-1])[::-1]
    for k in range(1, longest + 1):
        rows = by_length[:at_least[k]]
        other = hi[rows] - k                                   # the k-th row back, in sorted order
        ok = counts[other]
        below[rows] += ok * ((v[other] < v[rows]) + 0.5 * (v[other] == v[rows]))
        seen[rows] += ok
    share = np.where((seen > 0) & counts, below / np.maximum(seen, 1.0), np.nan)
    return share[engine.inverse]


def latched_sum(engine, evidence, half_life=None, latched_half_life=None, threshold=None, release=None):
    """The running alarm: a faded sum of `evidence` over strictly earlier seconds, with a latch.

    engine              an `EarlierRows` object for the key (the account, or the account and card)
    evidence            one number per row [rows], zero or more: how far the row's score lay above the baseline
    half_life           seconds; how fast the sum fades while the latch is open
    latched_half_life   seconds; how fast it fades while the latch is closed
    threshold           the latch closes when the sum, right after the rows of a second were added,
                        is at or above this
    release             the latch opens when the fading sum has fallen to this (0 or less: never)

    Returns (total, latched): float64 [rows] and bool [rows], as they stand just before the
    row's own second. Rows of one second are added together after that second, so they never
    see each other. The defaults are the LATCH settings at the top of this file.

    The state can be served as two numbers and a time per account: fade the sum over the gap
    since the last update, read it, then add the new row's evidence. Because the fading
    depends on the sum itself, this is not a plain decayed sum and prefix sums cannot give it:
    an account has to be walked second by second. The loop does that for all accounts at
    once, as `EarlierRows.decayed_sum` does: step r handles the r-th second of every account
    in one vector operation, so the number of Python steps is the longest history in
    seconds, not the number of rows.
    """
    half_life = LATCH_HALF_LIFE if half_life is None else half_life
    latched_half_life = LATCHED_HALF_LIFE if latched_half_life is None else latched_half_life
    threshold = LATCH_THRESHOLD if threshold is None else threshold
    release = LATCH_RELEASE if release is None else release
    n = engine.n
    if n == 0:
        return np.zeros(0), np.zeros(0, dtype=bool)
    e = np.nan_to_num(np.asarray(evidence, dtype=np.float64)[engine.order], nan=0.0) * engine.valid
    # One entry per distinct (key, second): the summed evidence of its rows and its time.
    new_second = np.ones(n, dtype=bool)
    new_second[1:] = engine.comp[1:] != engine.comp[:-1]
    sec_id = np.cumsum(new_second) - 1
    n_sec = int(sec_id[-1]) + 1
    e_sec = np.bincount(sec_id, weights=e, minlength=n_sec)
    t_sec = engine.rel[new_second].astype(np.float64)
    g_sec = engine.group[new_second]
    # Position of each second inside its key: 0 for the key's first second, 1 for the next.
    first = np.ones(n_sec, dtype=bool)
    first[1:] = g_sec[1:] != g_sec[:-1]
    rank = np.arange(n_sec) - np.maximum.accumulate(np.where(first, np.arange(n_sec), 0))
    total = np.zeros(n_sec)                                    # the sum just before each second
    latched = np.zeros(n_sec, dtype=bool)                      # the latch just before each second
    by_rank = np.argsort(rank, kind="stable")
    edges = np.concatenate(([0], np.cumsum(np.bincount(rank))))
    for r in range(1, len(edges) - 1):
        cur = by_rank[edges[r]:edges[r + 1]]
        prev = cur - 1                                         # the previous second of the same key
        gap = t_sec[cur] - t_sec[prev]
        s = total[prev] + e_sec[prev]                          # the sum right after the previous second
        closed = (latched[prev] | (s >= threshold)) & (s >= release)
        # While the latch is closed the sum fades slowly. It reaches the release level after
        # `to_release` seconds; from there on the latch is open and the sum fades fast.
        to_release = (latched_half_life * np.log2(np.maximum(s, release) / release) if release > 0
                      else np.full(len(cur), np.inf))
        held = closed & (gap <= to_release)
        slow = s * np.power(0.5, gap / latched_half_life)
        reopened = release * np.power(0.5, np.maximum(gap - to_release, 0.0) / half_life)
        fast = s * np.power(0.5, gap / half_life)
        total[cur] = np.where(closed, np.where(held, slow, reopened), fast)
        latched[cur] = held
    out_total, out_latched = total[sec_id], latched[sec_id]    # every row reads the state of its second
    out_total[~engine.valid] = 0.0
    out_latched[~engine.valid] = False
    return out_total[engine.inverse], out_latched[engine.inverse]


def key_state(keys, secs, logit, cut, baseline, half_life=None, latched_half_life=None, threshold=None,
              release=None):
    """The state columns for one key, as {name without prefix: float64 [rows]}.

    keys       one integer per row; rows with the same integer share a history
    secs       whole seconds per row (a missing time gives the row no history)
    logit      the model's score per row as log-odds; a row without a score counts as no row
    cut        the alert cut as a fixed log-odds value
    baseline   the log-odds above which a row adds evidence to the latch sum

    Every column uses rows of strictly earlier seconds only. The row's own score enters two
    columns (minus_mean and rank), where it is compared with the earlier scores.
    """
    engine = EarlierRows(keys, secs)
    has = ~np.isnan(logit)
    high = has & (logit >= cut)
    longest_label, longest = WINDOWS[-1]
    out = {}
    # The previous row. When several rows share the latest earlier second, the highest of their
    # scores is taken, so the answer does not depend on the order of the rows in the table.
    second = timekeys.codes(keys, secs)
    top = np.full(int(second.max()) + 1 if len(second) else 0, -np.inf)
    np.maximum.at(top, second[has], logit[has])
    out["prev_logit"] = engine.last(top[second], where=has)
    out["secs_since_prev"] = engine.seconds_since_last(where=has)
    for label, window in WINDOWS:
        out[f"max_{label}"] = engine.maximum(logit, window)
        out[f"n_high_{label}"] = engine.count(window, where=high)
    # The search stops at the longest window, so that a row of a long file and a scored row,
    # which has between one and two months behind it, get the same answer.
    out["secs_since_high"] = engine.seconds_since_last(longest, where=high)
    # Faded sums of the score and of "one per row", in one pass: [rows, half-lives, 2].
    faded = engine.decayed_sum(np.column_stack([np.nan_to_num(logit, nan=0.0), has.astype(np.float64)]),
                               [seconds for _, seconds in HALF_LIVES])
    for j, (label, _) in enumerate(HALF_LIVES):
        total, weight = faded[:, j, 0], faded[:, j, 1]
        out[f"decayed_sum_{label}"] = total
        out[f"decayed_n_{label}"] = weight
        # The sum of log-odds grows with the number of rows as much as with their scores; the
        # mean takes the number of rows out. It is missing when the memory has faded out.
        out[f"decayed_mean_{label}"] = np.where(weight >= FADED_OUT, total / np.maximum(weight, FADED_OUT), np.nan)
    out[f"n_rows_{longest_label}"] = engine.count(longest, where=has)
    out[f"minus_mean_{longest_label}"] = logit - engine.mean(logit, longest)
    out[f"rank_{longest_label}"] = rank_among_earlier(engine, logit, longest)
    # Only the part of a score above the baseline is evidence. An ordinary row adds nothing and
    # takes nothing away, so a harmless purchase in the middle of a run does not reset the alarm.
    evidence = np.clip(np.nan_to_num(logit, nan=-np.inf) - baseline, 0.0, None)
    out["latch_sum"], out["latched"] = latched_sum(engine, evidence, half_life, latched_half_life, threshold, release)
    return out


def build_score_state(df, cut, baseline=None, card_col=None, account_col=None, time_col=None, score_col=None,
                      score_kind=None, months_back=1, prefix=None, card_prefix=None, fill=None,
                      half_life=None, latched_half_life=None, threshold=None, release=None):
    """The score-state columns for every row of an export table.

    df            every scored row of one or more whole files (whole account histories), in any
                  order, with account, time and score. The scores must come from a model that
                  did not train on these rows if anything is fitted on the result.
    cut           the alert cut as a fixed log-odds value (see `_shared.cut_value`): the same
                  number for every table, not a quantile of this table
    baseline      log-odds above which a row adds to the latch sum (default: cut minus
                  LATCH_BASELINE_BELOW_CUT)
    card_col      a card column for a second, narrower state (default: settings.CARD_COL)
    account_col, time_col, score_col, score_kind   names; None reads settings
    months_back   the look-back starts on the first day of the month this many months before the
                  row's month; None reads everything in the table
    prefix, card_prefix   put in front of the column names (default: STATE_PREFIX, CARD_PREFIX)
    fill          None keeps missing values; a number replaces them
    half_life, latched_half_life, threshold, release   the latch (default: the LATCH settings)

    Returns a float32 DataFrame [rows, 34] with the index of `df`, or [rows, 68] with a card
    column. A row without a time has no history and gets missing values. No label is read.
    """
    account, secs = _shared.account_and_time(df, account_col, time_col)
    logit = _shared.logits(df, score_col, score_kind)
    baseline = cut - LATCH_BASELINE_BELOW_CUT if baseline is None else baseline
    histories = [(STATE_PREFIX if prefix is None else prefix, account, secs)]
    card_col = _shared.pick(card_col, "CARD_COL")
    if not card_col or card_col not in df.columns:
        print("note: no card column is set, or the table does not hold it; the card-level state is skipped")
    else:
        card = df[card_col]
        # A row without a card value has no history at this key and is in no other row's history.
        histories.append((CARD_PREFIX if card_prefix is None else card_prefix,
                          timekeys.codes(account, card.to_numpy()),
                          np.where(card.isna().to_numpy(), MISSING_SECOND, secs)))
    names = column_names()
    out = {}
    for key_prefix, keys, clock in histories:
        def build(rows, keys=keys, clock=clock):
            return key_state(keys[rows], clock[rows], logit[rows], cut, baseline, half_life, latched_half_life,
                             threshold, release)
        part = _shared.by_month_blocks(clock, months_back, build, names)
        out.update({key_prefix + name: part[name] for name in names})
    frame = pd.DataFrame(out, index=df.index).astype(np.float32)
    return frame if fill is None else frame.fillna(np.float32(fill))


def summary(frame):
    """One line per column: share of missing values, mean, smallest and largest value."""
    lines = []
    for name in frame.columns:
        values = frame[name].to_numpy(dtype=np.float64)
        have = values[~np.isnan(values)]
        lines.append({"column": name, "missing": 1.0 - len(have) / max(len(values), 1),
                      "mean": have.mean() if len(have) else np.nan,
                      "min": have.min() if len(have) else np.nan, "max": have.max() if len(have) else np.nan})
    return pd.DataFrame(lines, columns=["column", "missing", "mean", "min", "max"])


def main(argv=None):
    """Command line: build the state for one export file (or for made-up rows) and print a summary."""
    parser = argparse.ArgumentParser(description="Account risk state from the model's own earlier scores.")
    parser.add_argument("--export", default=None, help="export file with account, time and score")
    parser.add_argument("--cut", type=float, default=None, help="the alert cut as a fixed log-odds value")
    parser.add_argument("--cut-from", default=None,
                        help="take the cut from the scores of this export file (the fit rows) instead")
    parser.add_argument("--baseline", type=float, default=None,
                        help=f"log-odds above which a row adds to the latch sum "
                             f"(default: the cut minus {LATCH_BASELINE_BELOW_CUT:g})")
    parser.add_argument("--months-back", type=int, default=1,
                        help="whole months before the row's month that may be read; -1 reads everything")
    parser.add_argument("--score-col", default=None, help="name of the score column (default: settings.SCORE_COL)")
    parser.add_argument("--score-kind", default=None, choices=("probability", "logit"),
                        help="what the score column holds (default: settings.SCORE_KIND)")
    parser.add_argument("--per-mille", type=int, default=None,
                        help="alert budget in rows per thousand, used when the cut is taken from a file")
    parser.add_argument("--demo", action="store_true", help="run on made-up rows instead of a file")
    parser.add_argument("--out", default=None, help="write the id and the state columns to this parquet file")
    args = parser.parse_args(argv)
    if not args.demo and not args.export:
        parser.error("give --export FILE, or --demo to run on made-up rows")

    df = _shared.demo_export() if args.demo else _shared.load_export(args.export)
    cut = args.cut
    if cut is None:
        source = _shared.load_export(args.cut_from) if args.cut_from else df
        cut = _shared.cut_value(_shared.logits(source, args.score_col, args.score_kind), args.per_mille)
        if not args.cut_from:
            # The number is printed so that it can be frozen: a cut found again on every file
            # would give "at or above the cut" a different meaning on each of them.
            print(f"note: no --cut was given; the cut of this file is used. Pass --cut {cut:.6f} for every other file")
    print(f"alert cut (log-odds): {cut:.6f}")
    frame = build_score_state(df, cut, baseline=args.baseline, score_col=args.score_col, score_kind=args.score_kind,
                              months_back=None if args.months_back < 0 else args.months_back)
    print(f"{len(frame)} rows, {frame.shape[1]} state columns")
    print(summary(frame).to_string(index=False, float_format=lambda value: f"{value:.4f}"))
    if args.out:
        out = frame.copy()
        if settings.ID_COL in df.columns:
            out.insert(0, settings.ID_COL, df[settings.ID_COL].to_numpy())
        else:
            print(f"note: the table has no column '{settings.ID_COL}'; the rows of the output are in input order")
        _shared.save(out, args.out)
    return frame


if __name__ == "__main__":
    main()
