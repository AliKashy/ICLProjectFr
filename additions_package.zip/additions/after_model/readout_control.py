"""Three small readouts on exported vectors: does the account's history need a recurrent block?

What this file does
-------------------
It trains three small networks on the CPU with torch, on exported vectors, and reads what
each one catches at the alert cut:

    a_vector   a network with two hidden layers that reads only the row's own vector
    b_memory   the same, plus faded means of the account's earlier vectors at five
               half-lives and their faded counts (account_state_vectors.py): a memory that
               ignores the order of the earlier rows
    c_gru      the same as b_memory, plus the state of a small GRU run over the account's
               earlier rows in time order, each step fed the row's vector and the log of the
               time gap to the step before: a memory that knows the order

The three are compared in pairs with a paired bootstrap over accounts: b_memory against
a_vector (does an order-free memory add anything to the vector?), c_gru against b_memory
(does order add anything on top of that?) and c_gru against a_vector (what both memories add
together). a_vector is also compared with the model's own score when the table holds one.

Every memory is read as of the previous second: a row's memory holds the account's rows of
strictly earlier seconds only, and rows of the same second never see each other. No label
of any row is an input; labels are only the training target of each row.

Histories are cut so that training matches the scored rows. The evaluation files start one
month before the scored month, so a scored row has between one and two months of history.
The fit table may hold many more months. In every training epoch each account is cut into
blocks at a random offset; a row that is trained on sees the account's rows from the start
of its block only, which lies between HISTORY_DAYS[0] and HISTORY_DAYS[1] days before it.
The read rows are cut by calendar month, exactly as the evaluation files are.

Why it exists
-------------
Frauds come in runs on one account, so most frauds follow an earlier fraud of that account
and the account's recent past says a lot about the next row. There are two ways to carry
that past: a sum that ignores order (cheap, can be kept as a running state) and a recurrent
state that follows the order (costly to serve and to train). This experiment costs minutes
of CPU and separates three things: a non-linear re-read of the vector, an order-free memory
and an order-dependent memory. If c_gru does not beat b_memory, no recurrent block is needed
anywhere. If b_memory does not beat a_vector, the dense account memory is unlikely to pay.

A null result here is about the vectors that were exported: a vector after stage 2 already
mixes in the earlier rows that stage 2 reads, so it leaves less for any memory to add than
the stage-1 vector would.

Where it goes
-------------
Comparison, on the CPU, after scoring and exporting, before any work on recurrent blocks or
account memories in the network. It reads two export tables (one row per scored transaction
with id, account, time, label and the vector columns). The vectors used to fit the readouts
must come from a model that did not train on those rows: on training rows the vectors are
sharper than they will be on new rows. If the GRU wins, the place for a recurrent memory in
the network is stage 2 (FTTransformerHierModel.forward, next to the history that _step and
_build_causal_mask feed it); if only the order-free memory wins, the faded means of
account_state_vectors.py can be given to stage 2 as extra positions.

What to change for the pod
--------------------------
settings.py: ACCOUNT_COL, TIME_COL, LABEL_COL, POSITIVE_LABEL, SCORE_COL, SCORE_KIND,
VECTOR_PREFIX (the vectors read here), TARGET_START and TARGET_END (the rows that are read),
OUTSORT_PER_MILLE and the bootstrap settings. In this file: HISTORY_DAYS, HIDDEN, GRU_UNITS,
EPOCHS, ROW_BATCH, SEQUENCE_BATCH, LEARNING_RATE, KILL_GAIN and TORCH_THREADS. The half-lives
are those of account_state_vectors.py. On many millions of rows, lower EPOCHS first; a very
busy account makes one long sequence, which only costs time.

How to try it
-------------
    python additions/after_model/readout_control.py --demo
    python additions/after_model/readout_control.py --fit fit_export.parquet --read read_export.parquet

    table = compare(fit_export, read_export)
    python -m pytest -q additions/tests/test_after_readout_control.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd
import torch
from torch import nn

from additions import settings
from additions.after_model import _shared, account_state_vectors
from additions.common import timekeys
from additions.common.timekeys import MISSING_SECOND

# PLACEHOLDER: the shortest and the longest history of a scored row, in days (one to two months
# when the evaluation files start one month before the scored month).
HISTORY_DAYS = (31, 61)

# PLACEHOLDER: width of the hidden layers of every readout, and the number of units of the GRU.
HIDDEN = 64
GRU_UNITS = 64

# PLACEHOLDER: training length and batch sizes (rows per batch for a_vector and b_memory,
# account blocks per batch for c_gru), the learning rate, and the seed.
EPOCHS = 4
ROW_BATCH = 1024
SEQUENCE_BATCH = 64
LEARNING_RATE = 2e-3
TORCH_SEED = 0

# PLACEHOLDER: the weight of a fraud row in the loss. Fraud is rare, so with weight 1 a batch holds
# almost no fraud and the readouts learn slowly; a larger weight speeds learning up. It changes the
# level of the logits, not the order of the rows, and only the order is read here.
POSITIVE_WEIGHT = 20.0

# PLACEHOLDER: the gain in the share of frauds caught below which a memory is judged not to pay.
KILL_GAIN = 0.005

# PLACEHOLDER: CPU threads torch may use; None leaves torch's own choice.
TORCH_THREADS = None

# The half-lives of the order-free memory, the same as the account memory of account_state_vectors.py.
HALF_LIVES = account_state_vectors.HALF_LIVES

ARMS = ("a_vector", "b_memory", "c_gru")
DAY = 86_400


# ----------------------------------------------------------------------------------------------
# rows and their vectors
# ----------------------------------------------------------------------------------------------

def prepare(df, scale=None, vector_prefix=None, account_col=None, time_col=None, label_col=None, positive_label=None):
    """The arrays a readout needs from one export table, as a dict.

    df      an export table with account, time, label and the vector columns
    scale   (mean, std) of the vectors, float [dim] each; None takes them from this table (do
            that for the fit table, then pass its scale on to the read table)

    Returns {"vectors": float32 [rows, dim] (standardised), "account": int64 [rows],
    "secs": int64 [rows], "labels": float32 [rows], "scale": (mean, std)}. A table without
    vector columns cannot be read at all, so that is a plain error.
    """
    values = _shared.vectors(df, vector_prefix)
    if values is None:
        raise ValueError("the table has no vector columns; the readouts have nothing to read")
    values = np.nan_to_num(values.astype(np.float64), nan=0.0)
    if scale is None:
        scale = (values.mean(axis=0), np.maximum(values.std(axis=0), 1e-6))
    account, secs = _shared.account_and_time(df, account_col, time_col)
    return {"vectors": ((values - scale[0]) / scale[1]).astype(np.float32), "account": account, "secs": secs,
            "labels": _shared.fraud_flags(df, label_col, positive_label).astype(np.float32), "scale": scale}


# ----------------------------------------------------------------------------------------------
# blocks: which earlier rows each row may see
# ----------------------------------------------------------------------------------------------
#
# A block is one account's rows over one stretch of time. Its "target" rows are the rows that
# are trained on or scored; all its rows (targets and the rows before them) are the history.
# Blocks are described by memberships: member_row[m] is a row, member_block[m] the block it is
# in, member_target[m] whether it is a target there. Every row is a target in at most one block,
# and hist_start[row] is the first second its block reaches back to.

def _no_blocks(hist_start):
    """The blocks of a table in which no row has a time: no membership at all."""
    empty = np.zeros(0, dtype=np.int64)
    return {"member_row": empty, "member_block": empty, "member_target": empty.astype(bool), "hist_start": hist_start}


def training_blocks(account, secs, rng, history_days=None):
    """Random blocks for one training epoch, so that every trained row has one to two months of history.

    account, secs   int64 [rows]
    rng             a numpy random generator; a new draw gives every account a new offset
    history_days    (shortest, longest) history in days (default: HISTORY_DAYS)

    Every account gets a random offset. Its time line is cut into target windows of
    (longest - shortest) days that start at the first second of the table plus the offset
    plus `shortest` days. A window's block reaches back `shortest` days before the window
    starts, so a target row sees between `shortest` and `longest` days of history. Rows too
    early to have the shortest history are never targets (they still serve as history).

    Returns a dict: member_row, member_block, member_target (arrays [memberships]) and
    hist_start (int64 [rows]; the missing-time marker on rows that are no target).
    """
    shortest, longest = HISTORY_DAYS if history_days is None else history_days
    reach, width = int(shortest * DAY), int((longest - shortest) * DAY)
    secs = np.asarray(secs, dtype=np.int64)
    real = np.flatnonzero(secs != MISSING_SECOND)
    hist_start = np.full(len(secs), MISSING_SECOND, dtype=np.int64)
    if len(real) == 0:
        return _no_blocks(hist_start)
    t0 = int(secs[real].min())
    offset = rng.integers(0, max(width, 1), int(account.max()) + 1)[account[real]]
    # rel is the time after the start of window 0 of the row's account; window k covers
    # rel in [k * width, (k + 1) * width) and its block covers rel in [k * width - reach, (k + 1) * width).
    rel = secs[real] - t0 - offset - reach
    own = np.floor_divide(rel, width)                     # the window in which the row is a target
    rows, blocks, targets = [], [], []
    # A row is history in the later blocks that reach back to it; with reach and width in days
    # that is a handful of blocks, so this loop runs a few times, never once per row.
    for step in range(0, reach // width + 2):
        k = own + step
        inside = (k >= 0) & (k * width <= rel + reach)
        rows.append(real[inside])
        blocks.append(k[inside])
        targets.append(np.full(int(inside.sum()), step == 0))
    member_row = np.concatenate(rows)
    member_block = timekeys.codes(account[member_row], np.concatenate(blocks))
    member_target = np.concatenate(targets)
    is_target = own >= 0
    hist_start[real[is_target]] = (t0 + offset + own * width)[is_target]
    return {"member_row": member_row, "member_block": member_block, "member_target": member_target,
            "hist_start": hist_start}


def calendar_blocks(account, secs, months_back=1):
    """Blocks shaped like the evaluation files: a calendar month of targets and the months before it.

    Every row with a time is a target in the block of its own month, which reaches back to the
    first day of the month `months_back` months earlier. Same dict as `training_blocks`.
    """
    secs = np.asarray(secs, dtype=np.int64)
    rows, blocks, targets = [], [], []
    for number, (block_rows, is_target) in enumerate(_shared.month_blocks(secs, months_back)):
        rows.append(block_rows)
        blocks.append(np.full(len(block_rows), number))
        targets.append(is_target)
    hist_start = np.full(len(secs), MISSING_SECOND, dtype=np.int64)
    real = secs != MISSING_SECOND
    hist_start[real] = timekeys.month_start_seconds(secs[real], months_back) if months_back is not None \
        else int(secs[real].min()) if real.any() else 0
    if not rows:
        return _no_blocks(hist_start)
    member_row = np.concatenate(rows)
    return {"member_row": member_row,
            "member_block": timekeys.codes(account[member_row], np.concatenate(blocks)),
            "member_target": np.concatenate(targets), "hist_start": hist_start}


# ----------------------------------------------------------------------------------------------
# the order-free memory
# ----------------------------------------------------------------------------------------------

def memory_features(data, blocks, half_lives=None):
    """Faded means and log counts of every target row's earlier vectors, float32 [rows, half-lives * (dim + 1)].

    The memory of a row holds the account's rows of strictly earlier seconds from its block's
    start on (account_state_vectors.account_state does the work, with the start per row). Rows
    that are no target get an empty memory: they are not trained on or scored in this draw.
    """
    secs = data["secs"]
    start = np.where(blocks["hist_start"] != MISSING_SECOND, blocks["hist_start"], secs)
    sums, counts = account_state_vectors.account_state(data["vectors"], data["account"], secs, half_lives, start)
    means, log_counts = account_state_vectors.state_means(sums, counts)
    return np.concatenate([means.reshape(len(secs), -1), log_counts], axis=1).astype(np.float32)


# ----------------------------------------------------------------------------------------------
# the ordered memory: sequences for the GRU
# ----------------------------------------------------------------------------------------------

def sequence_layout(data, blocks):
    """Arrange the memberships as sequences for the GRU. Returns a dict of arrays.

    Within every block the members are put in time order (rows of one second keep their
    order in the table). Step m of a block feeds the GRU [vector, log(1 + seconds since the
    previous step of the block)]. For a target row, the state it may read is the GRU output
    after the last member of a strictly earlier second; rows of its own second come after
    that point and are never read. The keys of the result:

        steps        float32 [memberships, dim + 1]: the GRU input of every step, block by block
        block_start, block_length   int64 [blocks]: where each block's steps lie in `steps`
        target_row   int64 [targets]: the row of each target, grouped by block
        target_block int64 [targets]: its block
        target_last  int64 [targets]: position, inside its block, of the step whose output it
                     reads; -1 when no earlier second is in the block (it reads an empty state)
        target_gap   float32 [targets, 2]: log(1 + seconds since that step) and 1, or 0 and 0
        target_start, target_count  int64 [blocks]: where each block's targets lie
    """
    secs, vectors = data["secs"], data["vectors"]
    row, block, target = blocks["member_row"], blocks["member_block"], blocks["member_target"]
    order = np.lexsort((secs[row], block))                 # stable: same-second rows keep table order
    row, block, target = row[order], block[order], target[order]
    t = secs[row]
    m = len(row)
    new_block = np.ones(m, dtype=bool)
    new_block[1:] = block[1:] != block[:-1]
    first_of_block = np.maximum.accumulate(np.where(new_block, np.arange(m), 0)) if m else np.zeros(0, np.int64)
    gap = np.zeros(m)
    gap[1:] = np.where(new_block[1:], 0.0, (t[1:] - t[:-1]).astype(np.float64))
    steps = np.column_stack([vectors[row], np.log1p(gap)]).astype(np.float32)
    # The first step of each second: everything before it (inside the block) is strictly earlier.
    new_second = new_block.copy()
    new_second[1:] |= t[1:] != t[:-1]
    first_of_second = np.maximum.accumulate(np.where(new_second, np.arange(m), 0)) if m else np.zeros(0, np.int64)
    last_earlier = first_of_second - 1
    has = last_earlier >= first_of_block
    block_index = np.cumsum(new_block) - 1
    starts = np.flatnonzero(new_block)
    lengths = np.diff(np.append(starts, m))
    pick = np.flatnonzero(target)
    since = np.where(has, (t - t[np.maximum(last_earlier, 0)]).astype(np.float64), 0.0)
    target_block = block_index[pick]
    n_blocks = len(starts)
    target_count = np.bincount(target_block, minlength=n_blocks)
    return {"steps": steps, "block_start": starts, "block_length": lengths,
            "target_row": row[pick], "target_block": target_block,
            "target_last": np.where(has, last_earlier - first_of_block, -1)[pick],
            "target_gap": np.column_stack([np.log1p(since), has.astype(np.float64)])[pick].astype(np.float32),
            "target_start": np.concatenate(([0], np.cumsum(target_count)[:-1])).astype(np.int64),
            "target_count": target_count.astype(np.int64)}


def _ranges(starts, lengths):
    """The concatenation of ranges [start, start + length), and for every entry its range number and offset."""
    total = int(lengths.sum())
    which = np.repeat(np.arange(len(starts)), lengths)
    offset = np.arange(total) - np.repeat(np.cumsum(lengths) - lengths, lengths)
    return np.repeat(starts, lengths) + offset, which, offset


class Readout(nn.Module):
    """A small network that turns one row's inputs into a fraud logit.

    n_inputs    width of the row input: the vector, plus the memory for b_memory and c_gru
    hidden      width of the two hidden layers
    gru_inputs  width of a GRU step (dim + 1); 0 means no GRU (a_vector, b_memory)
    gru_units   units of the GRU

    forward(x [batch, n_inputs], ordered [batch, gru_units + 2] or None) gives logits [batch].
    The GRU state and the gap to the row enter the first hidden layer through their own
    projection, which starts at zero: at the start of training c_gru computes exactly what a
    readout without the GRU computes, and the GRU has to earn its place.
    """

    def __init__(self, n_inputs, hidden=None, gru_inputs=0, gru_units=None):
        super().__init__()
        hidden = HIDDEN if hidden is None else hidden
        gru_units = GRU_UNITS if gru_units is None else gru_units
        self.first = nn.Linear(n_inputs, hidden)
        self.second = nn.Linear(hidden, hidden)
        self.out = nn.Linear(hidden, 1)
        self.gru = None
        if gru_inputs:
            self.gru = nn.GRU(gru_inputs, gru_units, batch_first=True)
            self.from_gru = nn.Linear(gru_units + 2, hidden, bias=False)
            nn.init.zeros_(self.from_gru.weight)

    def forward(self, x, ordered=None):
        """x [batch, n_inputs] and, for c_gru, ordered [batch, gru_units + 2]; returns logits [batch]."""
        h = self.first(x)
        if ordered is not None:
            h = h + self.from_gru(ordered)
        h = torch.relu(self.second(torch.relu(h)))
        return self.out(h).squeeze(-1)

    def ordered_state(self, layout, block_ids):
        """GRU state of the targets of some blocks. Returns (target positions [t], state [t, gru_units + 2]).

        The blocks are padded to the longest of them and run through the GRU in one call;
        padding sits after the real steps, so it never changes a real step's output. Each
        target reads the output of its last strictly earlier step (zeros when there is none)
        and gets its gap features appended.
        """
        block_ids = np.asarray(block_ids, dtype=np.int64)
        lengths = layout["block_length"][block_ids]
        steps_at, which, position = _ranges(layout["block_start"][block_ids], lengths)
        padded = torch.zeros(len(block_ids), max(int(lengths.max()), 1), layout["steps"].shape[1])
        padded[which, position] = torch.from_numpy(layout["steps"][steps_at])
        outputs, _ = self.gru(padded)                                   # [blocks, longest, units]
        targets, local, _ = _ranges(layout["target_start"][block_ids], layout["target_count"][block_ids])
        last = torch.from_numpy(layout["target_last"][targets])
        read = outputs[torch.from_numpy(local), last.clamp(min=0)]
        read = read * (last >= 0).float().unsqueeze(1)                  # no earlier second: an empty state
        return targets, torch.cat([read, torch.from_numpy(layout["target_gap"][targets])], dim=1)


# ----------------------------------------------------------------------------------------------
# training and scoring
# ----------------------------------------------------------------------------------------------

def _inputs(kind, data, memory, rows):
    """The row input of a readout: the vector, plus the order-free memory for b_memory and c_gru."""
    if kind == "a_vector":
        return torch.from_numpy(data["vectors"][rows])
    return torch.from_numpy(np.concatenate([data["vectors"][rows], memory[rows]], axis=1))


def fit_readout(kind, data, epochs=None, history_days=None, hidden=None, gru_units=None, learning_rate=None,
                row_batch=None, sequence_batch=None, seed=None, half_lives=None, positive_weight=None):
    """Train one readout on the fit rows. Returns the trained `Readout`.

    kind    "a_vector", "b_memory" or "c_gru"
    data    the dict of `prepare` for the fit table

    Every epoch draws new random blocks (`training_blocks`), so a row sees a different
    length of history each time, always between one and two months. The loss is the log
    loss of each target row's label, a fraud row weighted by POSITIVE_WEIGHT. The number of
    epochs is fixed; nothing is chosen on the read rows.
    """
    epochs = EPOCHS if epochs is None else epochs
    seed = TORCH_SEED if seed is None else seed
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)
    dim = data["vectors"].shape[1]
    n_memory = 0 if kind == "a_vector" else len(HALF_LIVES if half_lives is None else half_lives) * (dim + 1)
    model = Readout(dim + n_memory, hidden, dim + 1 if kind == "c_gru" else 0, gru_units)
    optimiser = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE if learning_rate is None else learning_rate)
    loss_of = nn.BCEWithLogitsLoss(pos_weight=torch.tensor(float(POSITIVE_WEIGHT if positive_weight is None
                                                                else positive_weight)))
    labels = torch.from_numpy(data["labels"])
    for _ in range(int(epochs)):
        blocks = training_blocks(data["account"], data["secs"], rng, history_days)
        memory = None if kind == "a_vector" else memory_features(data, blocks, half_lives)
        # The batches are a Python loop: each one is one optimiser step, which cannot be vectorised.
        if kind == "c_gru":
            layout = sequence_layout(data, blocks)
            with_targets = rng.permutation(np.flatnonzero(layout["target_count"] > 0))
            size = SEQUENCE_BATCH if sequence_batch is None else sequence_batch
            for i in range(0, len(with_targets), size):
                targets, ordered = model.ordered_state(layout, with_targets[i:i + size])
                rows = layout["target_row"][targets]
                loss = loss_of(model(_inputs(kind, data, memory, rows), ordered), labels[rows])
                optimiser.zero_grad()
                loss.backward()
                optimiser.step()
        else:
            rows_all = rng.permutation(np.flatnonzero(blocks["hist_start"] != MISSING_SECOND))
            size = ROW_BATCH if row_batch is None else row_batch
            for i in range(0, len(rows_all), size):
                rows = rows_all[i:i + size]
                loss = loss_of(model(_inputs(kind, data, memory, rows)), labels[rows])
                optimiser.zero_grad()
                loss.backward()
                optimiser.step()
    return model


@torch.no_grad()
def score_readout(kind, model, data, months_back=1, sequence_batch=None, half_lives=None):
    """Logits of a trained readout for every row of a table, float64 [rows]; NaN for rows without a time.

    The rows are cut into calendar blocks (`calendar_blocks`), as the evaluation files are,
    so every row sees its account from the first day of the previous month on.
    """
    model.eval()
    blocks = calendar_blocks(data["account"], data["secs"], months_back)
    memory = None if kind == "a_vector" else memory_features(data, blocks, half_lives)
    out = np.full(len(data["secs"]), np.nan)
    if kind == "c_gru":
        layout = sequence_layout(data, blocks)
        with_targets = np.flatnonzero(layout["target_count"] > 0)
        size = SEQUENCE_BATCH if sequence_batch is None else sequence_batch
        for i in range(0, len(with_targets), size):
            targets, ordered = model.ordered_state(layout, with_targets[i:i + size])
            rows = layout["target_row"][targets]
            out[rows] = model(_inputs(kind, data, memory, rows), ordered).numpy()
    else:
        rows = np.flatnonzero(blocks["hist_start"] != MISSING_SECOND)
        for i in range(0, len(rows), ROW_BATCH):
            part = rows[i:i + ROW_BATCH]
            out[part] = model(_inputs(kind, data, memory, part)).numpy()
    model.train()
    return out


def compare(fit, read, read_rows=None, epochs=None, history_days=None, months_back=1, per_mille=None,
            rounding=None, draws=None, hidden=None, gru_units=None, seed=None, vector_prefix=None):
    """Train the three readouts on `fit`, read them on `read`. Returns a DataFrame with one line per comparison.

    fit, read     export tables with account, time, label and the vector columns; both scored
                  by a model that did not train on their rows, no account in both
    read_rows     yes/no per read row: the rows that are ranked (default: the scored month)

    Columns: arm, compared_with, udr, vdr, base_udr, gain (udr minus base_udr), low and high
    (interval of the gain over accounts), share_above_zero, draws.
    """
    if TORCH_THREADS:
        torch.set_num_threads(int(TORCH_THREADS))
    fit_data = prepare(fit, vector_prefix=vector_prefix)
    read_data = prepare(read, fit_data["scale"], vector_prefix=vector_prefix)
    read_rows = _shared.scored_rows(read) if read_rows is None else np.asarray(read_rows, dtype=bool)
    read_rows = read_rows & (read_data["secs"] != MISSING_SECOND)
    scores = {}
    for kind in ARMS:
        model = fit_readout(kind, fit_data, epochs, history_days, hidden, gru_units, seed=seed)
        scores[kind] = score_readout(kind, model, read_data, months_back)
    pairs = [("b_memory", "a_vector"), ("c_gru", "b_memory"), ("c_gru", "a_vector")]
    if _shared.pick(None, "SCORE_COL") in read.columns:
        scores["score"] = _shared.logits(read)
        pairs.insert(0, ("a_vector", "score"))
    else:
        print("note: the read table has no score column; the line against the model's own score is skipped")
    y, units = read_data["labels"][read_rows], read_data["account"][read_rows]
    amount = _shared.amounts(read)
    amount = None if amount is None else amount[read_rows]
    lines = []
    for arm, base in pairs:
        line = _shared.arm_line(arm, units, y, scores[arm][read_rows], scores[base][read_rows], amount, per_mille,
                                rounding, draws)
        lines.append({"arm": arm, "compared_with": base, **{k: v for k, v in line.items() if k != "arm"}})
    return pd.DataFrame(lines)


def verdict(table, kill_gain=None):
    """Two plain sentences that read a comparison table: is a dense memory worth it, and a recurrent one?"""
    kill_gain = KILL_GAIN if kill_gain is None else kill_gain

    def gain(arm, base):
        hit = table[(table["arm"] == arm) & (table["compared_with"] == base)]
        return float(hit["gain"].iloc[0]) if len(hit) else np.nan

    dense, ordered = gain("b_memory", "a_vector"), gain("c_gru", "b_memory")
    lines = []
    for what, value, yes, no in (
            ("order-free memory over the vector", dense, "the dense account memory has room",
             "the dense account memory is unlikely to pay"),
            ("GRU over the order-free memory", ordered, "order adds something; a recurrent block may pay",
             "no recurrent block is needed")):
        if np.isnan(value):
            lines.append(f"The {what} could not be read (no fraud among the ranked rows).")
        else:
            lines.append(f"The {what} adds {value:+.4f}: " + (yes if value >= kill_gain else no) +
                         f" (bar {kill_gain:.4f}).")
    return "\n".join(lines)


def main(argv=None):
    """Command line: train the three readouts on one export file and read them on another."""
    parser = argparse.ArgumentParser(description="Readouts on exported vectors: vector alone, plus an order-free "
                                                 "memory, plus a GRU over earlier rows.")
    parser.add_argument("--fit", default=None,
                        help="export file the readouts are trained on (not the model's training rows)")
    parser.add_argument("--read", default=None, help="export file the readouts are read on")
    parser.add_argument("--epochs", type=int, default=None, help="training epochs per readout (default: EPOCHS)")
    parser.add_argument("--all-rows", action="store_true", help="rank every row of --read, not only the scored month")
    parser.add_argument("--per-mille", type=int, default=None, help="alert budget in rows per thousand")
    parser.add_argument("--draws", type=int, default=None, help="bootstrap draws (default: settings.BOOTSTRAP_DRAWS)")
    parser.add_argument("--demo", action="store_true", help="run on made-up rows instead of files")
    parser.add_argument("--accounts", type=int, default=1500, help="accounts per made-up table (with --demo)")
    parser.add_argument("--out", default=None, help="write the comparison table to this parquet file")
    args = parser.parse_args(argv)
    if not args.demo and not (args.fit and args.read):
        parser.error("give --fit FILE and --read FILE, or --demo to run on made-up rows")

    if args.demo:
        fit = _shared.demo_export(n_accounts=args.accounts, seed=1, days=92, start=settings.TRAIN_HISTORY_START)
        read = _shared.demo_export(n_accounts=args.accounts, seed=2)
    else:
        fit = _shared.load_export(args.fit, extra_columns=())
        read = _shared.load_export(args.read, extra_columns=())
    table = compare(fit, read, read_rows=np.ones(len(read), dtype=bool) if args.all_rows else None,
                    epochs=args.epochs, per_mille=args.per_mille, draws=args.draws)
    _shared.show("Readouts on exported vectors (gain: change in the share of frauds caught at the cut)", table)
    print()
    print(verdict(table))
    if args.out:
        _shared.save(table, args.out)
    return table


if __name__ == "__main__":
    main()
