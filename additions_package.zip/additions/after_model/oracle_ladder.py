"""MEASUREMENT ONLY, never shipped: what the true labels of earlier rows would add (an upper bound).

What this file does
-------------------
It measures how much a model could gain from knowing the state of the account's fraud run,
by handing a tree model that state in three forms and reading what each one catches:

    base                the base columns: the model's logit, its vector, the raw fields
    zero_delay_labels   plus the TRUE labels of the account's earlier rows, known the second
                        after each fraud: the oracle, an upper bound that no model can have
    delayed_labels      plus the same labels, each one known only after a delay drawn from a
                        reporting curve: what label feedback could honestly give
    score_state         plus the state built from the model's own earlier scores
                        (score_state.py): the form that needs no label at all

Each arm is an XGBoost model fitted on a fit table and read on a read table: the share of
frauds inside the alert cut, its gain over the base arm with a paired bootstrap over
accounts, and the same share for first frauds of an account and for later ones.

The label state mirrors the score state: the number of known frauds of the account in the
last hour, day, week and month, the seconds since the last one, and faded sums at six
half-lives. Windows and fading are measured from the fraud's own transaction time, exactly
as in the score state, and a fraud counts only for rows in seconds strictly after the
second in which its label is known. A row therefore never sees its own label or the label
of a row of its own second, and the delayed state is always the zero-delay state with some
labels still hidden: it can never show more than the oracle.

THE LABEL COLUMNS BUILT HERE MUST NEVER REACH A MODEL THAT SHIPS. The zero-delay labels do
not exist when a transaction is scored, and the delayed ones are a simulation. The file
exists to size an idea, and for nothing else.

Why it exists
-------------
Frauds come in runs on one account, so most frauds follow an earlier fraud of that account.
Many ideas try to exploit that: a risk state from the model's own scores, extra training
targets that describe the run, teachers that look ahead. All of them are imperfect ways of
knowing that a run is under way. The oracle knows it perfectly. If even the oracle adds
almost nothing over the base columns, no imperfect version can add more, and run-state work
is not worth doing. If the oracle adds much, the other two arms say how much of it survives:
fraud labels arrive weeks after the transaction, so the delayed arm shows what real label
feedback is worth inside a run (usually little, because the run is over before its first
label arrives), and the score arm shows what the model's own verdicts recover of it.

The first and later split matters because the oracle can only help on later frauds: on the
first fraud of an account there is no earlier label to know.

Where it goes
-------------
Comparison, on the CPU, after scoring and before any run-state work is started. It reads two
export tables. Nothing it builds goes back into the pipeline. The scores in both tables must
come from a model that did not train on those rows; on training rows the scores are sharper
than they will ever be on new rows, and every arm would be judged against a base that is
too good.

What to change for the pod
--------------------------
REPORT_CURVE below: the table of days against the share of labels known by then. The values
in this file are made up; replace them by the bank's own figures. WORTH_DOING: the gain of
the oracle below which run-state work is dropped. settings.py: the column names, NUMERIC_COLS
and CODE_COLS (the raw fields of the base columns, used when the export holds them),
TARGET_START and TARGET_END (the rows that are ranked), OUTSORT_PER_MILLE and the bootstrap
settings. The tree settings are in _shared.py.

How to try it
-------------
    python additions/after_model/oracle_ladder.py --demo
    python additions/after_model/oracle_ladder.py --fit fit_export.parquet --read read_export.parquet

    table = ladder(fit_export, read_export)
    python -m pytest -q additions/tests/test_after_oracle_ladder.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd

from additions import settings
from additions.after_model import _shared, score_state
from additions.common import ranking
from additions.common.history import EarlierRows
from additions.common.timekeys import MISSING_SECOND

# PLACEHOLDER: the reporting curve as (days after the transaction, share of fraud labels known by
# then), with rising days and shares. These numbers are an example only; put the bank's own table here.
# A last share below 1 means that the remaining labels are never known inside the data.
REPORT_CURVE = ((0.0, 0.0), (7.0, 0.25), (14.0, 0.50), (30.0, 0.80), (60.0, 0.95), (90.0, 1.0))

# PLACEHOLDER: the seed of the draws of report delays; any whole number.
REPORT_SEED = 0

# PLACEHOLDER: the gain of the zero-delay arm (share of frauds caught) below which run-state work is
# not worth doing. The tool only prints a sentence that compares the measured gain with it.
WORTH_DOING = 0.01

# PLACEHOLDER: the prefixes of the label columns. The word "oracle" is in the name on purpose, so
# that such a column is recognised if it ever turns up among model inputs.
NOW_PREFIX = "oracle_now_"
LATE_PREFIX = "oracle_late_"

# The same windows and half-lives as the score state, so that the two states can be compared.
WINDOWS = score_state.WINDOWS
HALF_LIVES = score_state.HALF_LIVES
ARMS = ("base", "zero_delay_labels", "delayed_labels", "score_state")


def label_columns(prefix=""):
    """The names of the label-state columns, in the order in which they are built."""
    names = [f"n_known_{label}" for label, _ in WINDOWS] + ["secs_since_known"]
    names += [f"decayed_known_{label}" for label, _ in HALF_LIVES]
    return [prefix + name for name in names]


def draw_report_delays(n, curve=None, seed=None):
    """One report delay per fraud, drawn from the reporting curve. Returns float64 [n] in seconds.

    curve   (days, share known by then) pairs with rising days and shares (default: REPORT_CURVE)
    seed    seed of the draws (default: REPORT_SEED)

    Each fraud gets a random number between 0 and 1 and is reported at the day where the
    curve reaches that share (straight lines between the points of the table). A fraud
    whose number lies above the last share is never reported: its delay is infinite.
    """
    curve = REPORT_CURVE if curve is None else curve
    days = np.array([point[0] for point in curve], dtype=np.float64)
    share = np.array([point[1] for point in curve], dtype=np.float64)
    u = np.random.default_rng(REPORT_SEED if seed is None else seed).random(int(n))
    delay = np.interp(u, share, days) * 86_400.0
    delay[u > share[-1]] = np.inf
    return delay


def known_seconds(secs, fraud, delays=None):
    """The second in which each fraud label is known, int64 [rows]; the missing-time marker where it never is.

    secs     whole seconds per row
    fraud    yes/no per row
    delays   None for zero delay (a label is known in the second of its transaction, and so
             visible from the next second on), or seconds per row as from `draw_report_delays`
    """
    secs = np.asarray(secs, dtype=np.int64)
    known = np.full(len(secs), MISSING_SECOND, dtype=np.int64)
    ok = np.asarray(fraud, dtype=bool) & (secs != MISSING_SECOND)
    if delays is not None:
        ok &= np.isfinite(delays)
        known[ok] = secs[ok] + np.ceil(np.asarray(delays, dtype=np.float64)[ok]).astype(np.int64)
    else:
        known[ok] = secs[ok]
    return known


def label_state(keys, secs, known):
    """The label state for one key, as {name without prefix: float64 [rows]}. MEASUREMENT ONLY.

    keys    one integer per row [rows]; rows with the same integer are one account
    secs    whole seconds per row [rows]
    known   the second in which the row's fraud label is known (from `known_seconds`); the
            missing-time marker on rows that are not fraud or whose label is never known

    A fraud of the account counts for a row when the fraud lies in a strictly earlier second
    and its label was known in a second strictly before the row's second. Windows and fading
    are measured from the fraud's own transaction time. With zero delay the label is known in
    the fraud's own second, so that row and the other rows of that second do not see it.

    Why not the history engine alone: the engine answers "rows of a strictly earlier second
    inside a window", and here a second condition applies to each earlier fraud (is its
    label known yet?) that depends on the row asking. A prefix sum cannot answer that. The
    loop below walks back one earlier fraud at a time for all rows at once: step k looks at
    the k-th latest earlier fraud of every row's account. The number of Python steps is the
    largest number of frauds one account holds, not the number of rows.
    """
    keys = np.asarray(keys, dtype=np.int64)
    secs = np.asarray(secs, dtype=np.int64)
    known = np.asarray(known, dtype=np.int64)
    n = len(keys)
    valid = secs != MISSING_SECOND
    hls = np.array([seconds for _, seconds in HALF_LIVES], dtype=np.float64)
    counts = np.zeros((n, len(WINDOWS)))
    since = np.full(n, np.inf)
    faded = np.zeros((n, len(HALF_LIVES)))
    frauds = np.flatnonzero(valid & (known != MISSING_SECOND))
    if n and len(frauds):
        # One number per (account, second) that grows with both, so that a binary search finds,
        # for every row, the frauds of its account in strictly earlier seconds.
        t_min = int(secs[valid].min())
        span = int(secs[valid].max()) - t_min + 2
        rel = np.where(valid, secs - t_min, 0)
        comp = keys * span + rel
        frauds = frauds[np.argsort(comp[frauds], kind="stable")]
        f_comp, f_secs, f_known = comp[frauds], secs[frauds], known[frauds]
        hi = np.searchsorted(f_comp, comp, side="left")          # the first fraud at or after the row's second
        lo = np.searchsorted(f_comp, keys * span, side="left")   # the first fraud of the row's account
        length = np.where(valid, hi - lo, 0)
        longest = int(length.max())
        # Rows sorted by their number of earlier frauds, most first: the rows that still have a
        # k-th earlier fraud are then always the first so-many rows of this order.
        by_length = np.argsort(-length, kind="stable")
        at_least = np.cumsum(np.bincount(length, minlength=longest + 1)[::-1])[::-1]
        for k in range(1, longest + 1):
            rows = by_length[:at_least[k]]
            j = hi[rows] - k                                     # the k-th latest earlier fraud of the account
            seen = f_known[j] < secs[rows]                       # its label was known before the row's second
            age = (secs[rows] - f_secs[j]).astype(np.float64)
            for w, (_, window) in enumerate(WINDOWS):
                counts[rows, w] += seen & (age <= window)
            recent = seen & (age <= WINDOWS[-1][1])
            since[rows] = np.where(recent, np.minimum(since[rows], age), since[rows])
            faded[rows] += seen[:, None] * np.power(0.5, age[:, None] / hls[None, :])
    out = {}
    for w, (label, _) in enumerate(WINDOWS):
        out[f"n_known_{label}"] = counts[:, w]
    out["secs_since_known"] = np.where(np.isinf(since), np.nan, since)
    for h, (label, _) in enumerate(HALF_LIVES):
        out[f"decayed_known_{label}"] = faded[:, h]
    return out


def build_label_state(df, delayed=False, curve=None, seed=None, months_back=1, prefix=None, account_col=None,
                      time_col=None, label_col=None, positive_label=None):
    """The label-state columns for every row of a table. MEASUREMENT ONLY, never an input of a shipped model.

    df            every row of one or more whole files, with account, time and label
    delayed       False: every label is known at once (the oracle). True: every label is known
                  after a delay drawn from the reporting curve.
    curve, seed   the reporting curve and the seed of the draws (default: REPORT_CURVE, REPORT_SEED)
    months_back   the look-back starts on the first day of the month this many months before the
                  row's month; a label of a fraud before that day does not count, because a
                  scored row has no such rows in its files. None reads everything in the table.
    prefix        put in front of the column names (default: NOW_PREFIX or LATE_PREFIX)

    Returns a float32 DataFrame [rows, 11] with the index of `df`.
    """
    account, secs = _shared.account_and_time(df, account_col, time_col)
    fraud = _shared.fraud_flags(df, label_col, positive_label) > 0
    # The delays are drawn once for the whole table, so that a fraud keeps its report time in
    # every block in which it appears.
    known = known_seconds(secs, fraud, draw_report_delays(len(df), curve, seed) if delayed else None)
    names = label_columns()
    part = _shared.by_month_blocks(secs, months_back, lambda rows: label_state(account[rows], secs[rows], known[rows]),
                                   names)
    prefix = (LATE_PREFIX if delayed else NOW_PREFIX) if prefix is None else prefix
    return pd.DataFrame({prefix + name: part[name] for name in names}, index=df.index).astype(np.float32)


def later_frauds(df, account_col=None, time_col=None, label_col=None, positive_label=None):
    """Yes/no per row: is the row a fraud that follows an earlier fraud of its account in the table?

    "Earlier" means a strictly earlier second. A fraud for which this is False is the first
    fraud of its account that the table holds. Labels are used here to split a result table,
    never as an input.
    """
    account, secs = _shared.account_and_time(df, account_col, time_col)
    fraud = _shared.fraud_flags(df, label_col, positive_label) > 0
    return fraud & (EarlierRows(account, secs).count(where=fraud) > 0)


def ladder(fit, read, cut=None, curve=None, seed=None, months_back=1, fit_rows=None, read_rows=None,
           per_mille=None, rounding=None, draws=None, params=None, rounds=None, patience=None, tree_seed=0):
    """Fit the four arms on `fit` and read them on `read`. Returns a DataFrame with one line per arm.

    fit, read     export tables (id, account, time, label, amount, score, vector columns, and
                  the raw fields when the export holds them). Both must be scored by a model
                  that did not train on their rows; no account may be in both.
    cut           the alert cut as a fixed log-odds value for the score state (default: the cut
                  of the fit rows, found once and used for both tables)
    curve, seed   the reporting curve of the delayed arm and the seed of its draws
    months_back   the look-back of every state (see `_shared.month_blocks`)
    fit_rows      yes/no per row of `fit`: rows the trees are fitted on (default: the rows whose
                  look-back is complete)
    read_rows     yes/no per row of `read`: rows that are ranked (default: the scored month)
    params, rounds, patience, tree_seed   passed to `_shared.fit_trees`

    Columns of the result: arm, trees, udr and vdr (share of frauds and of fraud dollars inside
    the cut), base_udr, gain (udr minus the base arm's), low and high (interval of the gain),
    share_above_zero, draws, udr_first and udr_later (share caught among first frauds of an
    account and among later ones). A first line, "score", reads the model's own score.
    """
    y_fit, y_read = _shared.fraud_flags(fit), _shared.fraud_flags(read)
    account_fit, secs_fit = _shared.account_and_time(fit)
    account_read, _ = _shared.account_and_time(read)
    logit_fit, logit_read = _shared.logits(fit), _shared.logits(read)
    fit_rows = _shared.full_lookback(secs_fit, months_back) if fit_rows is None else np.asarray(fit_rows, dtype=bool)
    read_rows = _shared.scored_rows(read) if read_rows is None else np.asarray(read_rows, dtype=bool)
    cut = _shared.cut_value(logit_fit[fit_rows], per_mille, rounding) if cut is None else cut
    base_fit, base_read, _ = _shared.base_inputs(fit, read)
    seed = REPORT_SEED if seed is None else seed
    extra = {
        "base": None,
        "zero_delay_labels": (build_label_state(fit, False, months_back=months_back),
                              build_label_state(read, False, months_back=months_back)),
        # The two tables get different draws: their frauds are different frauds.
        "delayed_labels": (build_label_state(fit, True, curve, seed, months_back),
                           build_label_state(read, True, curve, seed + 1, months_back)),
        "score_state": (score_state.build_score_state(fit, cut, months_back=months_back),
                        score_state.build_score_state(read, cut, months_back=months_back)),
    }
    scores, trees = {"score": logit_read}, {"score": 0}
    for arm in ARMS:
        x_fit, x_read = base_fit, base_read
        if extra[arm] is not None:
            x_fit = np.column_stack([base_fit, extra[arm][0].to_numpy()])
            x_read = np.column_stack([base_read, extra[arm][1].to_numpy()])
        booster, info = _shared.fit_trees(x_fit, y_fit, account_fit, fit_rows=fit_rows, stop_on="capture",
                                          per_mille=per_mille, rounding=rounding, params=params, rounds=rounds,
                                          patience=patience, seed=tree_seed)
        scores[arm], trees[arm] = _shared.tree_margin(booster, info, x_read), info["trees"]
    # The read: every arm on the same ranked rows, against the base arm.
    y, units = y_read[read_rows], account_read[read_rows]
    amount = _shared.amounts(read)
    amount = None if amount is None else amount[read_rows]
    later = later_frauds(read)[read_rows]
    first = (y > 0) & ~later
    lines = []
    for arm, values in scores.items():
        line = _shared.arm_line(arm, units, y, values[read_rows], scores["base"][read_rows], amount, per_mille,
                                rounding, draws)
        caught = ranking.alert_mask(values[read_rows], per_mille, rounding)
        line["udr_first"] = caught[first].mean() if first.any() else np.nan
        line["udr_later"] = caught[later].mean() if later.any() else np.nan
        lines.append({"arm": arm, "trees": trees[arm], **{k: v for k, v in line.items() if k != "arm"}})
    return pd.DataFrame(lines)


def verdict(table, worth_doing=None):
    """One plain sentence that reads the upper bound of a ladder table."""
    worth_doing = WORTH_DOING if worth_doing is None else worth_doing
    gain = float(table.loc[table["arm"] == "zero_delay_labels", "gain"].iloc[0])
    if np.isnan(gain):
        return "The upper bound could not be read (no fraud among the ranked rows)."
    if gain < worth_doing:
        return (f"The upper bound (true labels with no delay) adds {gain:+.4f}, below {worth_doing:.4f}: "
                "run-state work is not worth doing on this evidence.")
    return (f"The upper bound (true labels with no delay) adds {gain:+.4f}, at or above {worth_doing:.4f}: "
            "run-state work has room; the score_state line says how much of it the model's own scores recover.")


def main(argv=None):
    """Command line: fit the arms on one export file and read them on another."""
    parser = argparse.ArgumentParser(
        description="MEASUREMENT ONLY: what true labels of earlier rows would add, against delayed labels "
                    "and the model's own earlier scores.")
    parser.add_argument("--fit", default=None,
                        help="export file the arms are fitted on (not the model's training rows)")
    parser.add_argument("--read", default=None, help="export file the arms are read on")
    parser.add_argument("--cut", type=float, default=None,
                        help="alert cut as a fixed log-odds value (default: from --fit)")
    parser.add_argument("--months-back", type=int, default=1,
                        help="whole months before the row's month that a state may read; -1 reads everything")
    parser.add_argument("--all-rows", action="store_true", help="rank every row of --read, not only the scored month")
    parser.add_argument("--per-mille", type=int, default=None, help="alert budget in rows per thousand")
    parser.add_argument("--draws", type=int, default=None, help="bootstrap draws (default: settings.BOOTSTRAP_DRAWS)")
    parser.add_argument("--rounds", type=int, default=None, help="most trees per arm (default: _shared.TREE_ROUNDS)")
    parser.add_argument("--demo", action="store_true", help="run on made-up rows instead of files")
    parser.add_argument("--out", default=None, help="write the table of arms to this parquet file")
    args = parser.parse_args(argv)
    if not args.demo and not (args.fit and args.read):
        parser.error("give --fit FILE and --read FILE, or --demo to run on made-up rows")

    if args.demo:
        fit = _shared.demo_export(seed=1, days=92, start=settings.TRAIN_HISTORY_START)
        read = _shared.demo_export(seed=2)
    else:
        fit, read = _shared.load_export(args.fit), _shared.load_export(args.read)
    table = ladder(fit, read, cut=args.cut, months_back=None if args.months_back < 0 else args.months_back,
                   read_rows=np.ones(len(read), dtype=bool) if args.all_rows else None, per_mille=args.per_mille,
                   draws=args.draws, rounds=args.rounds)
    _shared.show("Oracle ladder (measurement only; the label arms can never ship)", table)
    print()
    print(verdict(table))
    if args.out:
        _shared.save(table, args.out)
    return table


if __name__ == "__main__":
    main()
