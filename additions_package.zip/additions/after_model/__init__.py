"""What is built from the model's own scores and vectors after scoring.

account_state_vectors.py  the slow account memory: faded sums of each row's stage-1 vector
family_screen.py          screens one family of candidate columns at a time on top of the model's
                          own score
oracle_ladder.py          MEASUREMENT ONLY, never shipped: what the true labels of earlier rows
                          would add (an upper bound)
readout_control.py        three small readouts on exported vectors: does the account's history need
                          a recurrent block?
score_state.py            account risk state from the model's own EARLIER scores
second_stage.py           a tree model on top of the network's out-of-sample scores, and a
                          specialist for the top band
_shared.py                pieces shared by the tools of this folder: export tables, month blocks,
                          tree fits, result lines
"""
