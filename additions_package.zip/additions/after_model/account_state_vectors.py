"""The slow account memory: faded sums of each row's stage-1 vector.

What this file does
-------------------
For every row it computes what the account's earlier rows looked like to the model, at five
time scales. Per half-life (1 hour, 6 hours, 1 day, 7 days, 30 days) it keeps the sum of
the vectors of the account's rows in strictly earlier seconds, each vector halved for every
half-life of age, and the faded count of those rows. Sum divided by count is a mean that
favours recent rows; the count says how much the mean rests on. The state is "as of the
previous second": rows of the same second never enter each other's state.

The file has two halves that give the same numbers.

The batch half (`account_state`) computes the state of every row of a table at once, for
training and for offline scoring. An optional start time per row makes the state forget
everything before that time, exactly.

The live half is the update rule a service would run. `update(state, last_time, now,
new_vector)` multiplies the stored state by the decay since its last update and adds the new
vector. `add_late` adds a row that arrives after later rows were already added, with the
decay the row would have by now. `subtract_reversal` takes a row out again. Both are exact
because the state is a plain sum: every row's share in it is known at every moment.

Why it exists
-------------
Frauds come in runs on one account, and a run is easier to see against what the account
normally does. The second stage of the network reads a fixed number of earlier rows, so on
a busy account most of the last months lie outside its view. A faded sum covers all of it
at a fixed cost, and five half-lives separate "the last hour looked like this" from "the
last month looked like this". The evaluation files start one month before the scored month,
so a scored row has between one and two months of history; that is why the state is kept
as a mean with its count, which stays meaningful for a short history, and why the batch
half can cut the history of a row of a longer file to the same length.

The state is linear on purpose. A recurrent state must be replayed from a snapshot when a
row arrives late or is reversed, and replayed in full when the model changes. A sum needs
neither: one multiply and one add per half-life on every transaction, and the same function
in training, in offline scoring and in live use. For other models the state is an account
vector that can be read at any moment, which the vector of a single row is not.

No label is used: only the account, the time and the vector.

Where it goes
-------------
Stage 1, then exports, then stage 2. The vector is the one stage 1 makes of the fields of
one transaction (`txn_vec` in `FTTransformerHierModel.forward`, before the position is added
and before stage 2 mixes in other rows), stored per row by the export step. The state built
here can be given to stage 2 as extra positions in front of the history (means and log
counts as of the first row of the window), read by the readouts in readout_control.py, or
exported per account for other models.

What to change for the pod
--------------------------
settings.py: ACCOUNT_COL, TIME_COL, VECTOR_PREFIX and ID_COL (written with --out). In this
file: STAGE1_PREFIX, HALF_LIVES, STATE_PREFIX, and CHUNK_ROWS when memory is short. The
memory is meant to be built on the stage-1 vector, which holds one transaction alone; the
vector after stage 2 already mixes in earlier rows. So the builder reads the columns that
start with STAGE1_PREFIX when the export has them (exports/stage1_hook.py writes them under
that prefix), and only otherwise the columns that start with settings.VECTOR_PREFIX, with one
printed line saying so. A new model checkpoint changes every vector, so every stored state
has to be rebuilt with it.

How to try it
-------------
    python additions/after_model/account_state_vectors.py --demo
    python additions/after_model/account_state_vectors.py --export export.parquet --out account_state.parquet

    sums, counts = account_state(vectors, account, secs)                 # [rows, 5, dim], [rows, 5]
    state = update(state, last_time, now, new_vector)                    # the live rule, per account
    python -m pytest -q additions/tests/test_after_account_state_vectors.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd

from additions import settings
from additions.after_model import _shared
from additions.common import tables, timekeys
from additions.common.history import EarlierRows

# The half-lives of the memory, as (label, seconds).
HALF_LIVES = (("1h", 3_600), ("6h", 6 * 3_600), ("1d", 86_400), ("7d", 7 * 86_400), ("30d", 30 * 86_400))

# PLACEHOLDER: the prefix of the stage-1 (no-history) vector columns in an export file, as
# exports/stage1_hook.py names them (s1_0, s1_1, ...). They are read when the export has them.
STAGE1_PREFIX = "s1_"

# PLACEHOLDER: the prefix of the column names written by `build_account_state`.
STATE_PREFIX = "acct_"

# PLACEHOLDER: how many rows are worked on at once; lower it when memory is short, raise it for speed.
# One chunk needs a few times rows x half-lives x (dim + 1) x 8 bytes.
CHUNK_ROWS = 50_000

# A faded count below this is read as "nothing left": the state is then written as empty.
FADED_OUT = 1e-9


def _seconds(half_lives=None):
    """The half-lives as a float array of seconds. Accepts (label, seconds) pairs or plain numbers."""
    half_lives = HALF_LIVES if half_lives is None else half_lives
    return np.array([h[1] if isinstance(h, (tuple, list)) else h for h in half_lives], dtype=np.float64)


# ----------------------------------------------------------------------------------------------
# the batch half
# ----------------------------------------------------------------------------------------------

def _chunk_state(values, keys, secs, half_lives, start):
    """The state of one chunk of whole accounts, float64 [rows, half-lives, dim + 1] (the last column counts rows)."""
    n = len(keys)
    padded = np.column_stack([values, np.ones(n)])
    if start is None:
        out = EarlierRows(keys, secs).decayed_sum(padded, half_lives)
    else:
        # A state that forgets everything before `start` is the full state minus what the state
        # was at `start`, faded over the time since then. That holds exactly because the state
        # is a plain sum. The state at `start` is read by a "query row": a row with the same
        # key, the time `start` and nothing to add. It sees the rows strictly before `start`,
        # which are exactly the rows to forget.
        start = np.minimum(np.asarray(start, dtype=np.int64), secs)
        both = EarlierRows(np.concatenate([keys, keys]), np.concatenate([secs, start])).decayed_sum(
            np.concatenate([padded, np.zeros_like(padded)]), half_lives)
        age = (secs - start).astype(np.float64)
        out = both[:n] - both[n:] * np.power(0.5, age[:, None] / half_lives[None, :])[:, :, None]
    # A memory that has faded to almost nothing is written as empty. This also removes the
    # rounding residue that the subtraction above leaves where every row was forgotten.
    out[out[:, :, -1] < FADED_OUT] = 0.0
    return out


def account_state(vectors, keys, secs, half_lives=None, start=None, chunk_rows=None):
    """The faded sums and counts of every row's earlier rows, for a whole table at once.

    vectors      float array [rows, dim]: the stage-1 vector of every row
    keys         one integer per row; rows with the same integer are one account
    secs         whole seconds per row (a row with a missing time has no state and adds to none)
    half_lives   seconds, or (label, seconds) pairs (default: HALF_LIVES)
    start        None, or int64 [rows]: the earliest second each row may remember. Rows of the
                 account before it are forgotten exactly, as if the table began there.
    chunk_rows   rows worked on at once (default: CHUNK_ROWS)

    Returns (sums, counts): float32 [rows, half-lives, dim] and float32 [rows, half-lives].
    sums[i, h] is the sum of vectors[j] * 0.5 ** ((secs[i] - secs[j]) / half_lives[h]) over the
    rows j of the same key with start[i] <= secs[j] < secs[i]; counts[i, h] is the same sum
    with 1 in place of the vector. Rows of the same second are not in each other's state.

    The table is worked on in chunks of whole accounts. The loop is there to bound memory
    (the state of one row is half-lives x dim numbers); because a chunk never splits an
    account, the result is the same as in one pass.
    """
    values = np.asarray(vectors)                               # kept as stored; each chunk is widened on its own
    keys = np.asarray(keys)
    secs = np.asarray(secs, dtype=np.int64)
    start = None if start is None else np.asarray(start, dtype=np.int64)
    hl = _seconds(half_lives)
    n, dim = values.shape
    sums = np.zeros((n, len(hl), dim), dtype=np.float32)
    counts = np.zeros((n, len(hl)), dtype=np.float32)
    # Sort by key and give every account the chunk number of its first row, so that a chunk
    # boundary never falls inside an account.
    order = np.argsort(keys, kind="stable")
    new_key = np.ones(n, dtype=bool)
    new_key[1:] = keys[order][1:] != keys[order][:-1]
    first_row = np.maximum.accumulate(np.where(new_key, np.arange(n), 0))
    chunk = first_row // int(CHUNK_ROWS if chunk_rows is None else chunk_rows)
    edges = np.flatnonzero(np.diff(chunk, prepend=-1, append=-1)) if n else np.zeros(0, dtype=np.int64)
    for a, b in zip(edges[:-1], edges[1:]):
        rows = order[a:b]
        part = _chunk_state(values[rows], keys[rows], secs[rows], hl, None if start is None else start[rows])
        sums[rows] = part[:, :, :dim]
        counts[rows] = part[:, :, dim]
    return sums, counts


def state_means(sums, counts):
    """Turn sums and counts into what a model reads: (means, log_counts).

    means        float32 [rows, half-lives, dim]: sums / counts, and zero where the count is zero
    log_counts   float32 [rows, half-lives]: log(1 + count)

    The mean does not shrink when the history is short, which the sum does; the log count
    tells a model how much the mean rests on, so that it can tell "an empty memory" from
    "a memory of rows that looked like zero".
    """
    weight = counts[:, :, None]
    means = np.divide(sums, weight, out=np.zeros_like(sums), where=weight > 0)
    return means, np.log1p(counts)


# ----------------------------------------------------------------------------------------------
# the live half: one account, one row at a time
# ----------------------------------------------------------------------------------------------

def empty_state(dim, half_lives=None):
    """The state of an account with no history: zeros [half-lives, dim + 1] (the last column counts rows)."""
    return np.zeros((len(_seconds(half_lives)), dim + 1))


def fade(state, last_time, now, half_lives=None):
    """The state as it reads at second `now`: every line multiplied by its decay since `last_time`.

    state       float [half-lives, dim + 1], as stored after the update at `last_time`
    last_time   the second of that update (None for an account that was never updated)
    now         the second at which the state is read

    Nothing is added, so this is what a row at `now` may see. Returns a new array.
    """
    gap = 0.0 if last_time is None else float(now - last_time)
    return state * np.power(0.5, gap / _seconds(half_lives))[:, None]


def update(state, last_time, now, new_vector, half_lives=None):
    """The live rule: fade the state from `last_time` to `now`, then add the new row.

    new_vector   float [dim]: the stage-1 vector of the row that happened at `now`

    Returns the new state [half-lives, dim + 1]; the caller stores it together with `now`.
    One multiply and one add per half-life, whatever the length of the history.

    Time rule in live use: a row may read only what was known before its own second. So a
    row first reads (`fade`), is scored, and is added afterwards; when several rows of an
    account share a second, all of them read before any of them is added (see `replay`).
    """
    out = fade(state, last_time, now, half_lives)
    out[:, :-1] += np.asarray(new_vector, dtype=np.float64)
    out[:, -1] += 1.0
    return out


def add_late(state, last_time, row_time, vector, half_lives=None, sign=1.0):
    """Add a row that arrives late: its time lies before the last update of the state.

    state, last_time   the stored state and the second of its last update
    row_time           the second at which the late row really happened (at or before `last_time`)
    vector             float [dim]: its stage-1 vector

    The row is added with the decay it would have by `last_time`, which gives exactly the
    state that would be stored had the row arrived on time. `last_time` does not change.
    Rows that were scored in between did not see the late row; nothing can change that.
    """
    weight = sign * np.power(0.5, float(last_time - row_time) / _seconds(half_lives))     # one weight per half-life
    out = np.array(state, dtype=np.float64)
    out[:, :-1] += weight[:, None] * np.asarray(vector, dtype=np.float64)
    out[:, -1] += weight
    return out


def subtract_reversal(state, last_time, row_time, vector, half_lives=None):
    """Take a row out of the state again (a reversal): the exact opposite of adding it.

    The row's share in the state at `last_time` is its vector times the decay since
    `row_time`; subtracting that share leaves the state as if the row had never happened.
    """
    return add_late(state, last_time, row_time, vector, half_lives, sign=-1.0)


def replay(secs, vectors, half_lives=None):
    """The live rule applied to the rows of ONE account in time order: what every row reads.

    secs      whole seconds of the account's rows, int64 [rows], in any order
    vectors   float [rows, dim]

    Returns float64 [rows, half-lives, dim + 1]: the state each row sees, the count in the
    last column. It shows the order a service has to keep (read, then add; rows of one
    second all read first) and it is what the tests compare the batch half with. It walks
    row by row in Python because that is what it is there to show; `account_state` is the
    tool for whole tables.
    """
    secs = np.asarray(secs, dtype=np.int64)
    vectors = np.asarray(vectors, dtype=np.float64)
    order = np.argsort(secs, kind="stable")
    state, last = empty_state(vectors.shape[1], half_lives), None
    seen = np.zeros((len(secs),) + state.shape)
    i = 0
    while i < len(order):
        j = i
        while j < len(order) and secs[order[j]] == secs[order[i]]:
            j += 1                                             # rows i .. j-1 share one second
        now = secs[order[i]]
        state = fade(state, last, now, half_lives)
        seen[order[i:j]] = state                               # all of them read before any is added
        for k in order[i:j]:
            state = update(state, now, now, vectors[k], half_lives)
        last, i = now, j
    return seen


# ----------------------------------------------------------------------------------------------
# a table of columns, and the command line
# ----------------------------------------------------------------------------------------------

def build_account_state(df, vector_prefix=None, account_col=None, time_col=None, half_lives=None, months_back=1,
                        prefix=None, chunk_rows=None):
    """The account memory of every row of an export table, as columns.

    df            every row of one or more whole files, with account, time and the vector columns
    vector_prefix the prefix of the vector columns to remember. None reads the stage-1 columns
                  (STAGE1_PREFIX) when the table has them, and otherwise the columns under
                  settings.VECTOR_PREFIX, with one printed line
    months_back   the memory starts on the first day of the month this many months before the
                  row's month, as it does for a scored row; None remembers everything in the table
    prefix        put in front of the column names (default: STATE_PREFIX)

    Returns a float32 DataFrame with the index of `df`: per half-life the mean vector
    (`acct_1h_0`, `acct_1h_1`, ...) and the log count (`acct_1h_log_n`). Without vector
    columns it prints one line and returns a DataFrame with no columns.
    """
    if vector_prefix is None and _shared.vector_columns(df.columns, STAGE1_PREFIX):
        vector_prefix = STAGE1_PREFIX                # the vector of one transaction alone
    elif vector_prefix is None:
        print(f"note: the table has no stage-1 columns ('{STAGE1_PREFIX}*'); the memory is built on the "
              f"'{settings.VECTOR_PREFIX}*' columns, which already hold earlier rows if they come from after stage 2")
    values = _shared.vectors(df, vector_prefix)
    if values is None:
        return pd.DataFrame(index=df.index)
    prefix = STATE_PREFIX if prefix is None else prefix
    half_lives = HALF_LIVES if half_lives is None else half_lives
    labels = [h[0] if isinstance(h, (tuple, list)) else f"{int(h)}s" for h in half_lives]
    account, secs = _shared.account_and_time(df, account_col, time_col)
    start = None if months_back is None else timekeys.month_start_seconds(secs, months_back)
    sums, counts = account_state(values, account, secs, half_lives, start, chunk_rows)
    means, log_counts = state_means(sums, counts)
    out = {}
    for h, label in enumerate(labels):
        for j in range(values.shape[1]):
            out[f"{prefix}{label}_{j}"] = means[:, h, j]
        out[f"{prefix}{label}_log_n"] = log_counts[:, h]
    return pd.DataFrame(out, index=df.index)


def main(argv=None):
    """Command line: build the account memory for one export file (or for made-up rows)."""
    parser = argparse.ArgumentParser(description="The slow account memory: faded sums of each row's stage-1 vector.")
    parser.add_argument("--export", default=None, help="export file with account, time and the stage-1 vector columns")
    parser.add_argument("--months-back", type=int, default=1,
                        help="whole months before the row's month that are remembered; -1 remembers everything")
    parser.add_argument("--demo", action="store_true", help="run on made-up rows instead of a file")
    parser.add_argument("--out", default=None, help="write the id and the state columns to this parquet file")
    args = parser.parse_args(argv)
    if not args.demo and not args.export:
        parser.error("give --export FILE, or --demo to run on made-up rows")

    if args.demo:
        df = _shared.demo_export()
    else:
        # The loader reads the settings.VECTOR_PREFIX columns by itself; the stage-1 columns are asked for.
        stage1 = _shared.vector_columns(tables.available_columns(args.export), STAGE1_PREFIX)
        df = _shared.load_export(args.export, extra_columns=stage1)
    frame = build_account_state(df, months_back=None if args.months_back < 0 else args.months_back)
    print(f"{len(frame)} rows, {frame.shape[1]} state columns")
    if frame.shape[1]:
        counts = frame[[c for c in frame.columns if c.endswith("_log_n")]]
        table = pd.DataFrame({"column": counts.columns, "mean_log_count": counts.mean().to_numpy(),
                              "share_empty": (counts == 0).mean().to_numpy()})
        _shared.show("How much each half-life remembers (log of the faded count; empty means no earlier row left)", table)
    if args.out:
        out = frame.copy()
        if settings.ID_COL in df.columns:
            out.insert(0, settings.ID_COL, df[settings.ID_COL].to_numpy())
        else:
            print(f"note: the table has no column '{settings.ID_COL}'; the rows of the output are in input order")
        _shared.save(out, args.out)
    return frame


if __name__ == "__main__":
    main()
