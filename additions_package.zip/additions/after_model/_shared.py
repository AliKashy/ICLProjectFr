"""Pieces shared by the tools of this folder: export tables, month blocks, tree fits, result lines.

What this file does
-------------------
It holds the steps that every tool in `additions/after_model/` repeats. It reads an export
file (one row per scored transaction with id, account, time, label, amount, score and vector
columns) and turns its columns into the arrays the tools work on. It finds the score value
of the alert cut on a set of rows, so that the value can be frozen and passed on. It cuts a
table into calendar blocks, so that every row looks back exactly as far as a scored row
can. It fits gradient-boosted trees with early stopping on accounts that were held out of
the fit, and it writes one line of a results table with a paired bootstrap.

Why it exists
-------------
Everything in this folder is built on the model's own scores and vectors, after scoring.
Three rules hold for all of it, and each is easier to keep when it is written once.

A second model is stopped and judged on accounts it was not fitted on. Frauds come in runs
on one account, so rows of one account are not independent; a split by rows would let the
trees meet the same run on both sides.

The alert budget is a fixed small share of rows, so what counts is the order of the rows at
the very top. A measure of the whole ranking can keep improving while the top gets worse.
The tree fits here can therefore stop on capture at the cut itself.

The evaluation files start one month before the scored month, so a scored row has between
one and two months of history. Rows of longer files are cut to the same look-back before
any state is built on them; otherwise a second model would learn from memories that no
scored row can have.

One rule cannot be written as code and is repeated in every file that fits something:
scores used to fit anything must come from a model that did not train on those rows.

Where it goes
-------------
Nowhere by itself. The tools of this folder import it. They run on the CPU after scoring,
between the exports and the comparison; nothing here is part of the network.

What to change for the pod
--------------------------
settings.py: ID_COL, ACCOUNT_COL, TIME_COL, LABEL_COL, POSITIVE_LABEL, AMOUNT_COL, SCORE_COL,
SCORE_KIND, VECTOR_PREFIX, NUMERIC_COLS, CODE_COLS, TARGET_START, TARGET_END,
OUTSORT_PER_MILLE and the bootstrap settings. In this file: TREE_PARAMS, TREE_ROUNDS,
TREE_PATIENCE and INNER_SHARE. An xgboost older than 1.6 names the argument `custom_metric`
of `xgboost.train` `feval`; change the one call in `fit_trees` if that is what the pod has.

How to try it
-------------
    fit = load_export("fit_export.parquet")
    cut = cut_value(logits(fit))                     # freeze this number; pass it to every build
    booster, info = fit_trees(features, fraud_flags(fit), fit[settings.ACCOUNT_COL])
    python -m pytest -q additions/tests/test_after_shared.py
"""
import numpy as np
import pandas as pd
import xgboost as xgb

from additions import settings
from additions.common import ranking, synthetic, tables, timekeys
from additions.common.bootstrap import paired_bootstrap
from additions.common.timekeys import MISSING_SECOND

# PLACEHOLDER: settings of the tree fits; raise the depth and the rounds for exports of many millions
# of rows, and add "nthread" to use fewer cores than the machine has.
TREE_PARAMS = {"objective": "binary:logistic", "eta": 0.05, "max_depth": 6, "min_child_weight": 5.0,
               "subsample": 0.8, "colsample_bytree": 0.8, "lambda": 1.0, "tree_method": "hist"}

# PLACEHOLDER: the most trees a fit may grow, and how many rounds without a better held-out value end it.
TREE_ROUNDS = 2000
TREE_PATIENCE = 100

# PLACEHOLDER: the share of the fit accounts that is held out of every tree fit for early stopping.
INNER_SHARE = 0.25

DAY = 86_400


# ----------------------------------------------------------------------------------------------
# settings and export tables
# ----------------------------------------------------------------------------------------------

def pick(value, setting_name):
    """`value` when it is given, otherwise what settings.py holds under `setting_name`.

    The setting is read when the function runs, not when the module is imported, so an edit
    of settings.py (or a value set by a test) is seen by every later call.
    """
    return getattr(settings, setting_name) if value is None else value


def vector_columns(names, prefix=None):
    """The vector columns among `names`, in the order of their numbers (e_0, e_1, ..., e_10)."""
    prefix = pick(prefix, "VECTOR_PREFIX")
    found = [c for c in names if isinstance(c, str) and c.startswith(prefix) and c[len(prefix):].isdigit()]
    return sorted(found, key=lambda c: int(c[len(prefix):]))


def load_export(path, extra_columns=None, id_col=None, account_col=None, time_col=None, label_col=None,
                amount_col=None, score_col=None, vector_prefix=None, filesystem=None):
    """Read one export file into a DataFrame.

    path            the parquet file written by the export step
    extra_columns   further columns to read when the file holds them; None means the raw
                    fields named in settings (NUMERIC_COLS, CODE_COLS) and the card column

    The result holds the id, account, time, label, amount and score columns, every vector
    column, and those extra columns that the file has. A column the file does not have is
    simply not in the table; the function that needs it says so when it skips its part.
    """
    if extra_columns is None:
        extra_columns = [*settings.NUMERIC_COLS, *settings.CODE_COLS, settings.CARD_COL]
    have = tables.available_columns(path, filesystem)
    wanted = [pick(id_col, "ID_COL"), pick(account_col, "ACCOUNT_COL"), pick(time_col, "TIME_COL"),
              pick(label_col, "LABEL_COL"), pick(amount_col, "AMOUNT_COL"), pick(score_col, "SCORE_COL")]
    wanted += vector_columns(have, vector_prefix) + [c for c in extra_columns if c is not None]
    return tables.read_columns(path, [c for c in dict.fromkeys(wanted) if c in have], filesystem)


def demo_export(n_accounts=1500, seed=0, days=61, start=None, dim=8, fraud_account_share=0.08, strength=1.5):
    """A made-up export table for the --demo option of the tools: rows, a score and `dim` vector columns.

    The table also keeps the raw fields, as an export that was joined to its raw rows would.
    The score is deliberately mediocre (`strength`), so that there is something left to gain
    at the alert cut. Nothing read on this table says anything about a real model.
    """
    df = synthetic.make_transactions(n_accounts=n_accounts, days=days, start=start, seed=seed,
                                     fraud_account_share=fraud_account_share)
    return synthetic.make_vectors(synthetic.make_scores(df, seed=seed, strength=strength), dim=dim, seed=seed)


def vectors(df, prefix=None):
    """The exported vectors as float32 [rows, dim], or None with one printed line when the table has none."""
    names = vector_columns(df.columns, prefix)
    if not names:
        print(f"note: the table has no vector column that starts with '{pick(prefix, 'VECTOR_PREFIX')}'; "
              "that part is skipped")
        return None
    return df[names].to_numpy(dtype=np.float32)


def account_and_time(df, account_col=None, time_col=None):
    """(account, secs): a small integer per account and the whole second of every row, both int64 [rows].

    A row without an account gets the missing-time marker. The history engine gives such a
    row no history and keeps it out of every other row's history, which is the only safe
    reading of a row that cannot be placed.
    """
    account = df[pick(account_col, "ACCOUNT_COL")]
    secs = timekeys.seconds(df[pick(time_col, "TIME_COL")])
    return timekeys.codes(account), np.where(account.isna().to_numpy(), MISSING_SECOND, secs)


def fraud_flags(df, label_col=None, positive_label=None):
    """1.0 on fraud rows and 0.0 on all other rows, float64 [rows].

    A label column of numbers is compared as numbers and a column of text as stripped text,
    so the label 1 is found whether the file stores 1, 1.0 or "1".
    """
    column = df[pick(label_col, "LABEL_COL")]
    positive = pick(positive_label, "POSITIVE_LABEL")
    if pd.api.types.is_numeric_dtype(column.dtype):
        return (column.to_numpy(dtype=np.float64) == float(positive)).astype(np.float64)
    return (column.astype(str).str.strip() == str(positive).strip()).to_numpy().astype(np.float64)


def logits(df, score_col=None, score_kind=None):
    """The model's score as log-odds, float64 [rows]. `score_kind` says what is stored."""
    return ranking.to_logit(df[pick(score_col, "SCORE_COL")].to_numpy(dtype=np.float64), score_kind)


def amounts(df, amount_col=None):
    """Dollar amounts float64 [rows], or None when the table has no amount column (dollar capture is then skipped)."""
    amount_col = pick(amount_col, "AMOUNT_COL")
    return df[amount_col].to_numpy(dtype=np.float64) if amount_col in df.columns else None


def scored_rows(df, time_col=None, start=None, end=None):
    """Yes/no per row: does the row fall in the scored month (start inclusive, end exclusive)?

    Only these rows are ranked. The other rows stay in the table as history.
    """
    low, high = timekeys.seconds(pd.to_datetime(pd.Series([pick(start, "TARGET_START"), pick(end, "TARGET_END")])))
    secs = timekeys.seconds(df[pick(time_col, "TIME_COL")])
    return (secs >= low) & (secs < high)


def cut_value(row_logits, per_mille=None, rounding=None):
    """The lowest score that is still inside the top `per_mille` of these rows; infinity when that set is empty.

    This is how a cut becomes a fixed number. It is taken once, on rows that stand for the
    population (the fit rows), and the number is then passed to every later build, so that
    "at or above the cut" means the same on every file. The same function gives the floor of
    a wider band, for example per_mille=50 for the top 5 percent.
    """
    s = np.asarray(row_logits, dtype=np.float64)
    inside = ranking.alert_mask(s, per_mille, rounding)
    return float(s[inside].min()) if inside.any() else np.inf


# ----------------------------------------------------------------------------------------------
# the look-back of a scored row, applied to every row
# ----------------------------------------------------------------------------------------------

def month_blocks(secs, months_back=1):
    """Cut the rows into blocks shaped like an evaluation file. Yields (rows, is_target) per calendar month.

    `rows` holds the positions of the rows from the first day of the month `months_back`
    months earlier to the end of the month; `is_target` marks, among them, the rows of the
    month itself. With `months_back=None` there is one block: every row that has a time, all
    of them targets. This is the calendar rule of additions/features/lookback.py.
    """
    secs = np.asarray(secs, dtype=np.int64)
    real = np.flatnonzero(secs != MISSING_SECOND)
    if months_back is None:
        yield real, np.ones(len(real), dtype=bool)
        return
    month = timekeys.month_start_seconds(secs[real], 0)
    for first in np.unique(month):
        block_start = timekeys.month_start_seconds(np.array([first]), months_back)[0]
        month_end = timekeys.month_start_seconds(np.array([first]), -1)[0]      # one month forward
        rows = real[(secs[real] >= block_start) & (secs[real] < month_end)]
        yield rows, secs[rows] >= first


def by_month_blocks(secs, months_back, build, names):
    """Compute columns block by block, so that no row depends on anything before its look-back start.

    build(rows) gets the positions of the rows of one block and returns {name: one value per
    row of the block}, computed as if the block were the whole table. Every row keeps the
    values of the block in which it is a target. Returns {name: float64 [all rows]} for the
    given `names`; a row without a time is in no block and stays missing.

    Why blocks: a running state (a faded sum, a latch) of a row in a long file would hold
    months that a scored row can never have behind it. Cutting the table first gives both
    the same memory. The loop runs once per calendar month, never once per row; every row is
    computed once as a target and once more as the history of the following month.
    """
    out = {name: np.full(len(secs), np.nan) for name in names}
    for rows, is_target in month_blocks(secs, months_back):
        part = build(rows)
        for name in names:
            out[name][rows[is_target]] = np.asarray(part[name], dtype=np.float64)[is_target]
    return out


def full_lookback(secs, months_back=1, data_start=None):
    """Yes/no per row: does the table reach back to the row's look-back start?

    It is False for the rows of the first month(s) of the table: they have less history than
    any scored row, so a second model should not be fitted on them (they stay useful as the
    history of later rows). `data_start` is the first day of data as text or as seconds;
    None means the first day that occurs in `secs`.
    """
    secs = np.asarray(secs, dtype=np.int64)
    real = secs != MISSING_SECOND
    if months_back is None or not real.any():
        return real
    if data_start is None:
        first = int(secs[real].min() // DAY * DAY)
    elif isinstance(data_start, (int, float, np.integer, np.floating)):
        first = int(data_start)
    else:
        first = int(timekeys.seconds(pd.Series([pd.Timestamp(data_start)]))[0])
    out = np.zeros(len(secs), dtype=bool)
    out[real] = timekeys.month_start_seconds(secs[real], months_back) >= first
    return out


# ----------------------------------------------------------------------------------------------
# inputs of a tree model
# ----------------------------------------------------------------------------------------------

def base_inputs(fit, read, numeric_cols=None, code_cols=None, vector_prefix=None, score_col=None, score_kind=None):
    """The base columns of a second model for two tables: the logit, the vector and the raw fields.

    fit, read      export tables; the code fields are numbered from the values of `fit`
    numeric_cols   raw numeric fields (default: settings.NUMERIC_COLS)
    code_cols      raw code fields (default: settings.CODE_COLS)

    Returns (fit_matrix, read_matrix, names): two float32 arrays [rows, columns] and the
    column names. A field that is not in both tables is skipped with one printed line. A
    code field becomes one number per value: 0 for the value most frequent in `fit`, 1 for
    the next, and so on, so that a tree can split rare values off with one threshold. A value
    that `fit` never holds becomes a missing value, which the trees route on their own.
    """
    names = ["logit"]
    parts = [[logits(fit, score_col, score_kind)], [logits(read, score_col, score_kind)]]
    for c in vector_columns(fit.columns, vector_prefix):
        if c in read.columns:
            names.append(c)
            parts[0].append(fit[c].to_numpy(dtype=np.float64))
            parts[1].append(read[c].to_numpy(dtype=np.float64))
    numeric, code = pick(numeric_cols, "NUMERIC_COLS"), pick(code_cols, "CODE_COLS")
    skipped = [c for c in [*numeric, *code] if c not in fit.columns or c not in read.columns]
    if skipped:
        print(f"note: raw field(s) {skipped} are not in both tables; they are skipped")
    for c in numeric:
        if c not in skipped:
            names.append(c)
            parts[0].append(pd.to_numeric(fit[c], errors="coerce").to_numpy(dtype=np.float64))
            parts[1].append(pd.to_numeric(read[c], errors="coerce").to_numpy(dtype=np.float64))
    for c in code:
        if c not in skipped:
            order = fit[c].value_counts().index                # the values of `fit`, most frequent first
            number = pd.Series(np.arange(len(order), dtype=np.float64), index=order)
            names.append(c)
            parts[0].append(fit[c].map(number).to_numpy(dtype=np.float64))
            parts[1].append(read[c].map(number).to_numpy(dtype=np.float64))
    return (np.column_stack(parts[0]).astype(np.float32), np.column_stack(parts[1]).astype(np.float32), names)


# ----------------------------------------------------------------------------------------------
# trees with early stopping on held-out accounts
# ----------------------------------------------------------------------------------------------

def held_out_accounts(accounts, share=None, seed=0):
    """Yes/no per row: does the row belong to an account that is held out of the fit?

    Whole accounts are drawn, never single rows: frauds come in runs on one account, and a
    run that sat on both sides of the split would make the held-out value look too good.
    """
    share = INNER_SHARE if share is None else share
    codes = timekeys.codes(np.asarray(accounts))
    n_accounts = int(codes.max()) + 1 if len(codes) else 0
    # One draw per account, in the order in which the accounts first occur in the rows.
    return (np.random.default_rng(seed).random(n_accounts) < share)[codes]


def log_loss(labels, margin):
    """Mean log loss of log-odds `margin` against 0/1 `labels`, computed without overflow."""
    y = np.asarray(labels, dtype=np.float64)
    m = np.asarray(margin, dtype=np.float64)
    return float(np.mean(np.logaddexp(0.0, m) - y * m)) if len(y) else np.nan


def capture_metric(per_mille=None, rounding=None, compose=None):
    """An evaluation function for xgboost: the share of frauds inside the alert cut.

    per_mille, rounding   the alert budget (default: settings)
    compose               a function that turns the log-odds of the evaluated rows into the
                          score they are ranked by (None: the log-odds themselves). It lets a
                          model that re-ranks only part of the rows be judged on the whole
                          ranking it produces.

    Returns a function(predictions, matrix) that gives ("capture", value); higher is better.
    With a built-in objective xgboost hands over probabilities; they are turned back into
    log-odds first, so that `compose` always receives log-odds.
    """
    def metric(predictions, matrix):
        margin = ranking.to_logit(predictions, "probability")
        scores = margin if compose is None else compose(margin)
        got = ranking.capture(matrix.get_label(), scores, per_mille=per_mille, rounding=rounding)
        return "capture", float(got["udr"] or 0.0)
    return metric


def fit_trees(features, labels, accounts, base_margin=None, fit_rows=None, compose=None, stop_on="capture",
              per_mille=None, rounding=None, params=None, rounds=None, patience=None, inner_share=None, seed=0):
    """Fit gradient-boosted trees and stop them on accounts that were held out of the fit.

    features      float array [rows, columns]; missing values may be NaN
    labels        0/1 [rows]
    accounts      one value per row; whole accounts are held out (see `held_out_accounts`)
    base_margin   log-odds per row that the trees start from (None: they start from scratch)
    fit_rows      yes/no per row: the rows the trees may be fitted on (None: all). The held-out
                  accounts are never fitted on, and ALL their rows are used for stopping.
    compose       function(log-odds of the held-out rows, their positions in the input) that
                  returns the score those rows are ranked by; None ranks by the log-odds
    stop_on       "capture": the share of frauds inside the alert cut of the held-out rows;
                  "logloss": their log loss
    params, rounds, patience, inner_share   override TREE_PARAMS, TREE_ROUNDS, TREE_PATIENCE, INNER_SHARE

    Returns (booster, info). `info` holds "trees" (how many trees to use), "inner_score" (the
    held-out value with that many trees), "inner_start" (the held-out value of the base
    margin alone; NaN without one), "fit_rows" and "inner_rows".

    Why capture: the alert budget is a small fixed share of rows, so only the order at the
    very top matters. A whole-ranking measure can keep falling while the top gets worse.
    Capture moves in jumps on a small held-out set, which is the price; "logloss" is the
    smooth choice for a screen. When a base margin is given and no number of trees beats
    it on the held-out accounts, "trees" is 0: the starting point is the answer.
    """
    x = np.asarray(features, dtype=np.float32)
    y = np.asarray(labels, dtype=np.float32)
    start = None if base_margin is None else np.asarray(base_margin, dtype=np.float32)
    held = held_out_accounts(accounts, inner_share, seed)
    fitted = ~held if fit_rows is None else ~held & np.asarray(fit_rows, dtype=bool)

    def matrix(rows):
        return xgb.DMatrix(x[rows], label=y[rows], base_margin=None if start is None else start[rows])

    setup = {**TREE_PARAMS, **(params or {}), "seed": int(seed)}
    rounds = TREE_ROUNDS if rounds is None else int(rounds)
    patience = TREE_PATIENCE if patience is None else int(patience)
    info = {"stop_on": stop_on, "fit_rows": int(fitted.sum()), "inner_rows": int(held.sum()),
            "inner_score": np.nan, "inner_start": np.nan}
    if y[held].sum() == 0:
        # Without a held-out fraud neither measure can tell a good round from a bad one.
        print("note: the held-out accounts hold no fraud, so there is nothing to stop on; every round is kept")
        info["trees"] = rounds
        return xgb.train(setup, matrix(fitted), rounds), info
    positions = np.flatnonzero(held)
    rank = None if compose is None else (lambda margin: compose(margin, positions))
    if stop_on == "capture":
        metric = capture_metric(per_mille, rounding, rank)
        booster = xgb.train({**setup, "disable_default_eval_metric": 1}, matrix(fitted), rounds,
                            evals=[(matrix(held), "inner")], custom_metric=metric, maximize=True,
                            early_stopping_rounds=patience, verbose_eval=False)
        if start is not None:
            first = start[held].astype(np.float64)
            info["inner_start"] = float(ranking.capture(y[held], first if rank is None else rank(first),
                                                        per_mille=per_mille, rounding=rounding)["udr"] or 0.0)
        better = booster.best_score > info["inner_start"]
    else:
        booster = xgb.train({**setup, "eval_metric": "logloss"}, matrix(fitted), rounds,
                            evals=[(matrix(held), "inner")], early_stopping_rounds=patience, verbose_eval=False)
        if start is not None:
            info["inner_start"] = log_loss(y[held], start[held])
        better = booster.best_score < info["inner_start"]
    info["inner_score"] = float(booster.best_score)
    # A comparison with NaN is False, so without a base margin the best round is always kept.
    info["trees"] = int(booster.best_iteration) + 1 if (start is None or better) else 0
    return booster, info


def tree_margin(booster, info, features, base_margin=None):
    """Log-odds per row from a model fitted by `fit_trees`, float64 [rows].

    `info` is what `fit_trees` returned; only its "trees" entry is used. The base margin must
    be given again for the rows that are scored, exactly as it was given for the fit rows.
    With zero trees the result is the base margin itself.
    """
    if info["trees"] == 0:
        return np.asarray(base_margin, dtype=np.float64).copy()
    x = np.asarray(features, dtype=np.float32)
    start = None if base_margin is None else np.asarray(base_margin, dtype=np.float32)
    matrix = xgb.DMatrix(x, base_margin=start)
    return booster.predict(matrix, output_margin=True, iteration_range=(0, int(info["trees"]))).astype(np.float64)


# ----------------------------------------------------------------------------------------------
# result tables
# ----------------------------------------------------------------------------------------------

def arm_line(name, accounts, labels, scores, base_scores, amount_values=None, per_mille=None, rounding=None,
             draws=None, seed=None, interval=None):
    """One line of a results table: what an arm catches at the cut, and its gain over a base score.

    accounts      one value per row; the bootstrap resamples whole accounts
    scores        the arm's score per row; base_scores the score it is compared with

    Returns a dict: arm, udr and vdr (share of frauds and of fraud dollars inside the cut,
    ties credited in proportion), base_udr, gain (udr minus base_udr on the same rows), low
    and high (the interval of the gain), share_above_zero and draws. Both rankings are read on
    the same draw of accounts, so the noise they share cancels. A figure that cannot be
    computed (no fraud among the rows, no amounts) is NaN.
    """
    y = np.asarray(labels, dtype=np.float64)
    line = {"arm": name, "udr": np.nan, "vdr": np.nan, "base_udr": np.nan, "gain": np.nan, "low": np.nan,
            "high": np.nan, "share_above_zero": np.nan, "draws": 0}
    if len(y) == 0 or y.sum() == 0:
        print(f"note: no fraud among the ranked rows; the line of '{name}' stays empty")
        return line
    got = ranking.capture(y, scores, amount_values, per_mille, rounding)
    r = paired_bootstrap(accounts, y, scores, base_scores, None, per_mille, draws, seed, interval, rounding)
    values = {"udr": got["udr"], "vdr": got["vdr"], "base_udr": r["b"], "gain": r["gain"], "low": r["low"],
              "high": r["high"], "share_above_zero": r["share_above_zero"]}
    line.update({key: np.nan if value is None else float(value) for key, value in values.items()})
    line["draws"] = r["draws"]
    return line


def show(title, table, digits=4):
    """Print a title and a table (a DataFrame or a list of dicts) as plain text."""
    frame = table if isinstance(table, pd.DataFrame) else pd.DataFrame(table)
    print()
    print(title)
    if len(frame) == 0:
        print("  (no rows)")
        return
    print(frame.to_string(index=False, na_rep="-", float_format=lambda value: f"{value:.{digits}f}"))


def save(table, path, filesystem=None):
    """Write a table to a parquet file (an existing file is replaced) and print where it went."""
    tables.write_table(table, path, filesystem)
    print(f"wrote {len(table)} row(s) and {table.shape[1]} column(s) to {path}")
    return path
