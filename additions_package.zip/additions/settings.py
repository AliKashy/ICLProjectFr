"""One place for every name that depends on the data or on the machine.

What this file does
-------------------
It holds plain constants: column names, code values, file locations, dates and sizes. Every
other file in the package reads its defaults from here, and every function also accepts the
same names as arguments, so a single call can use other names without editing this file.

Why it exists
-------------
The pieces in this package were written against one layout of the transaction files. A model
that has since grown (more input fields, other file ranges, other column names) only needs
this file changed for most pieces to run. Keeping the names in one place means the logic in
the other files never has to be searched for a hard-coded column name.

Where it goes
-------------
Nowhere in the pipeline. Every other file of the package imports it for its defaults.

What to change for the pod
--------------------------
Every line marked PLACEHOLDER. A value of None means "this column is not available": the
pieces that need it skip that part and print one line saying so.

How to try it
-------------
    from additions import settings
    print(settings.ACCOUNT_COL, settings.TIME_COL)
Any tool of the package then uses the new names, for example
    python additions/reads/history_census.py --help
"""

# ----------------------------------------------------------------------------------------------
# Columns of the raw transaction files
# ----------------------------------------------------------------------------------------------

# PLACEHOLDER: the column that identifies the account. Histories are built per value of it.
ACCOUNT_COL = "Nmap_account_reference_xid"

# PLACEHOLDER: the transaction timestamp. It is floored to whole seconds everywhere, because the
# rule "a row may only use rows of strictly earlier seconds" is defined on whole seconds.
TIME_COL = "transaction_dttm"

# PLACEHOLDER: a unique id per transaction. It is used to join scores back to raw rows.
ID_COL = "fi_transaction_id"

# PLACEHOLDER: a per-account sequence number that orders rows inside the same second.
# Only the pieces that deliberately let a row see an earlier row of the same second use it.
ORDER_COL = "transaction_order"

# PLACEHOLDER: the fraud label column and the value that means "fraud".
LABEL_COL = "frd_tag"
POSITIVE_LABEL = 1

# PLACEHOLDER: the transaction amount in dollars.
AMOUNT_COL = "transaction_amt"

# PLACEHOLDER: the network risk score on the transaction (an integer from 0 to 99).
VISA_SCORE_COL = "external_1_scr"

# PLACEHOLDER: balance and limit columns, used for ratios such as amount over balance.
BALANCE_COL = "total_available_balance_amt"
MERCH_LIMIT_COL = "remain_day_merchandise_lmt_amt"
CASH_LIMIT_COL = "available_daily_cash_limit_amt"

# PLACEHOLDER: merchant columns. The merchant id is only ever compared for equality or used as
# a join key; it is never embedded with one table row per merchant.
MERCHANT_COL = "Nmap_merchant_xid"
MCC_COL = "merchant_category_xcd"
MERCHANT_POSTAL_COL = "merchant_postal_xcd"
MERCHANT_STATE_COL = "merchant_state_xcd"
MERCHANT_COUNTRY_COL = "merchant_country_xcd"

# PLACEHOLDER: what the bank decided on the transaction. These columns describe the outcome of
# a row, so a row must never read its own value. Earlier rows' values are fair history.
REASON_COL = "processor_reason_xcd"      # response code; one value means "approved"
DECLINE_FLAG_COL = "predecline"          # 1 when the transaction was declined before the fraud engine
ADVICE_COL = "transaction_advice_xcd"    # filled on advice rows (notices, not live requests)

# PLACEHOLDER: other row descriptors used by the reads and the slices.
TYPE_COL = "transaction_type_xcd"
SEGMENT_COL = "segment"
CARD_PRESENT_COL = "cardholder_present_xflg"

# PLACEHOLDER: optional identity columns. None means the column is not in the files.
# When one is available, set its name here and the exact-match features, the recurrence tokens
# and the score state will also be built for it.
CARD_COL = None        # a card or token key, when the account can hold several cards
TERMINAL_COL = None    # terminal id
DEVICE_COL = None      # device id for card-not-present transactions
TOKEN_COL = None       # wallet token requestor or token id
IP_COL = None          # IP address (the first two octets are enough for matching)

# PLACEHOLDER: the model's raw inputs. The two lists below are the original small input set and
# only serve as an example; replace them by the full input list of the model in use.
NUMERIC_COLS = [
    "transaction_amt", "external_1_scr", "avlble_merch_day_cash_lmt_amt",
    "available_daily_cash_limit_amt", "remain_day_merchandise_lmt_amt", "total_available_balance_amt",
]
CODE_COLS = [
    "transaction_type_xcd", "segment", "transaction_category_xcd", "transaction_pos_condition_xcd",
    "avs_request_xcd", "pos_security_xflg", "transaction_pin_verify_xcd", "cardholder_present_xflg",
    "pos_card_capture_xflg", "cvv_verify_xcd", "authzn_rqst_crypto_valid_xflg", "pos_off_premises_xflg",
    "pos_terminal_attend_xflg",
]

# ----------------------------------------------------------------------------------------------
# Code values
# ----------------------------------------------------------------------------------------------

# PLACEHOLDER: the response code(s) that mean the transaction was approved.
APPROVED_REASONS = ("00",)

# PLACEHOLDER: response codes read as declines by the fraud engine. Their meaning should be
# confirmed with the data owner before they are relied on.
RISK_DECLINE_REASONS = ("05", "59", "89")

# PLACEHOLDER: response codes that mean insufficient funds.
FUNDS_DECLINE_REASONS = ("51",)

# PLACEHOLDER: the values of DECLINE_FLAG_COL that mean "declined".
DECLINE_FLAG_VALUES = ("1", "1.0", "Y", "True", "true")

# PLACEHOLDER: transaction types that are zero-dollar checks (address verification only).
ZERO_CHECK_TYPES = ("A",)

# PLACEHOLDER: segment values that the benchmark population leaves out. Empty means none.
EXCLUDED_SEGMENTS = ()

# ----------------------------------------------------------------------------------------------
# Files
# ----------------------------------------------------------------------------------------------

# PLACEHOLDER: folders that hold the raw files, and how one file is named. {n} is the file number.
TRAIN_BASE = "PLACEHOLDER/path/to/training/files"
EVAL_BASE = "PLACEHOLDER/path/to/evaluation/files"
FILE_NAME = "part_{n}.parquet"

# PLACEHOLDER: a filesystem object for remote storage (for example an fsspec or pyarrow
# filesystem). None means the paths are ordinary local paths.
FILESYSTEM = None

# PLACEHOLDER: file numbers of the blocks the examples use. Each file holds whole accounts and
# no account appears in two files, which is what makes "fit on some files, read on others" clean.
TRAIN_FILES = list(range(1, 11))             # files the model is trained on (example)
CONSUMER_FIT_FILES = list(range(4001, 4011))  # files kept out of training; downstream models fit here
CONSUMER_READ_FILES = list(range(8217, 8228))  # evaluation files; downstream models are read here
CHOOSE_FILES = list(range(8228, 8244))        # evaluation files used to choose between variants
DECIDE_FILES = list(range(8244, 8260))        # evaluation files used to confirm a choice

# ----------------------------------------------------------------------------------------------
# Time
# ----------------------------------------------------------------------------------------------

# PLACEHOLDER: the first day of data in the training files and in the evaluation files. A
# history window that would reach before this day is incomplete, which matters for any feature
# that looks back further than the evaluation files go.
TRAIN_HISTORY_START = "2024-10-01"
EVAL_HISTORY_START = "2025-05-01"

# PLACEHOLDER: the month whose rows are scored and compared (start inclusive, end exclusive).
TARGET_START = "2025-06-01"
TARGET_END = "2025-07-01"

# ----------------------------------------------------------------------------------------------
# The measure
# ----------------------------------------------------------------------------------------------

# The share of rows that may be alerted, in units of one per thousand: 6 means the top 0.6%.
OUTSORT_PER_MILLE = 6

# How the number of alerted rows is rounded: "floor" or "ceil".
OUTSORT_ROUNDING = "floor"

# Settings of the paired bootstrap that resamples whole accounts.
BOOTSTRAP_DRAWS = 2000
BOOTSTRAP_SEED = 20261102
INTERVAL_PERCENT = 90.0

# ----------------------------------------------------------------------------------------------
# What the model writes
# ----------------------------------------------------------------------------------------------

# PLACEHOLDER: the column that holds the model's fraud score in a prediction or export file,
# and whether it is a probability ("probability") or a log-odds value ("logit").
SCORE_COL = "score"
SCORE_KIND = "probability"

# PLACEHOLDER: the prefix of the exported vector columns (e_0, e_1, ...).
VECTOR_PREFIX = "e_"

# ----------------------------------------------------------------------------------------------
# Model sizes (only the model blocks and their tests read these)
# ----------------------------------------------------------------------------------------------

# PLACEHOLDER: width of a field token, number of attention heads, blocks in each stage, and the
# number of earlier seconds of history the second stage reads.
EMBED_DIM = 48
NUM_HEADS = 8
STAGE1_BLOCKS = 2
STAGE2_BLOCKS = 4
HISTORY_LEN = 20
