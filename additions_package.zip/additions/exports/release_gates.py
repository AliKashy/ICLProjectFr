"""Two checks on export columns before they go to other models: a domain check and a stability index per column.

What this file does
-------------------
It compares the export columns of two periods (by default the month before the scored month
and the scored month) in two ways:

    domain check     a small XGBoost model is asked to tell the rows of the first period from
                     the rows of the second, using only the export columns. Its area under the
                     ROC curve, read on accounts it did not train on, is near 0.5 when the columns
                     look the same in both periods and rises toward 1.0 as they drift apart. The
                     columns the model leaned on most are listed, so a drift can be traced.
    stability index  per column, the population stability index between the two periods: the
                     values are cut into bins at the first period's quantiles (a missing value is
                     its own bin, and a code column uses its values as bins) and the index is
                     sum over bins of (share now - share before) * log(share now / share before).
                     Common reading: below 0.1 little movement, 0.1 to 0.25 some, above 0.25 a lot.

The results are printed and returned. They do not stop anything and change no file unless an
--out path is given; the numbers can be added to the store's manifest with
feature_store.write_store(..., extra=...).

Why it exists
-------------
A downstream model is fitted on export columns of earlier months and then reads the columns of
a new month. If the columns of the new month are distributed differently for reasons that have
nothing to do with fraud (a calendar input the model never saw in training, a retrain that
moved the scale of a score, a history window that is cut short), the downstream model reads
shifted inputs with thresholds learned on the old ones, and its alerts move with them. The
alert budget is a fixed small share of rows, so a shift that pushes many ordinary rows over a
learned threshold fills the budget with them. A domain check catches drift in any combination
of columns at once; the per-column index says which columns moved.

Two things in the data make a drift appear that is not a fault of the model, and the reading
has to allow for them. The evaluation files start one month before the scored month, so a row
of the first month has a shorter history than a row of the scored month: windows of 7 or 30
days and counts of earlier rows are smaller in the first month for that reason alone. Comparing
two months that both have full history (or leaving the long windows out) separates that from a
real drift. And fraud labels arrive weeks after the transaction, which does not matter here:
neither check reads a label.

Where it goes
-------------
In the exports, after bundle.py (or any builder of per-row columns) and before the columns are
given to consumers. It runs on the CPU on one export table that holds both periods.

What to change for the pod
--------------------------
settings.py: ACCOUNT_COL, TIME_COL, ID_COL, LABEL_COL, EVAL_HISTORY_START, TARGET_START and
TARGET_END (the default periods). The constants below: `AUC_LIMIT` and `PSI_LIMIT` (the levels
at which the printed verdict says "moved"; they are words in a table, nothing more), `PSI_BINS`,
`PSI_FLOOR`, `FOLDS`, `ROUNDS`, `MAX_ROWS_PER_PERIOD`, `THREADS` and `TOP_COLUMNS`. The tree settings come
from `_shared.TREE_PARAMS`. By default the columns checked are the bundle columns of bundle.py
that the table holds, and otherwise every numeric column except the keys and the label.

How to try it
-------------
    python additions/exports/release_gates.py --demo
    python additions/exports/release_gates.py --table bundle.parquet --out stability.parquet
    python additions/exports/release_gates.py --table bundle.parquet \\
        --first 2025-04-01 2025-05-01 --second 2025-05-01 2025-06-01
or, from Python:
    result = check_release(bundle_table)
The tests are in additions/tests/test_exports_release_gates.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

from additions import settings
from additions.common import tables, timekeys
from additions.exports import _shared, bundle

# PLACEHOLDER: the area under the ROC curve of the domain check above which the verdict reads "moved".
AUC_LIMIT = 0.55

# PLACEHOLDER: the stability index above which a column's verdict reads "moved".
PSI_LIMIT = 0.25

# PLACEHOLDER: the number of quantile bins of a numeric column in the stability index.
PSI_BINS = 10

# PLACEHOLDER: the smallest share a bin is given before the logarithm is taken. An empty bin would
# otherwise give an infinite index; with the floor, a bin that empties counts as a large but finite move.
PSI_FLOOR = 1e-4

# PLACEHOLDER: the number of account groups of the domain check. Each group is scored by a model
# trained on the other groups.
FOLDS = 3

# PLACEHOLDER: the number of trees of the domain check. Few are needed: the question is whether any
# difference exists, not how well it can be modelled.
ROUNDS = 60

# PLACEHOLDER: the most rows of each period that enter the domain check; more are drawn at random
# down to this number, which keeps the check quick on millions of rows.
MAX_ROWS_PER_PERIOD = 200_000

# PLACEHOLDER: the processor threads of the domain check. One thread is steady on a shared machine
# and quick enough for a few hundred thousand rows; put the number of free cores here on a machine
# of its own, or None to let XGBoost take all of them.
THREADS = 1

# PLACEHOLDER: how many of the columns the domain check leaned on most are listed.
TOP_COLUMNS = 10


def gate_columns(df, columns=None, id_col=None, account_col=None, time_col=None, label_col=None):
    """The columns to check: those asked for that the table has, else the bundle columns, else every numeric column.

    The keys, the time, the file number and the label are never checked. A label is no export
    column, and its rate differs between months for reasons that are not drift.
    """
    skip = {_shared.pick(id_col, "ID_COL"), _shared.pick(account_col, "ACCOUNT_COL"),
            _shared.pick(time_col, "TIME_COL"), _shared.pick(label_col, "LABEL_COL"), "_file"}
    if columns is None:
        columns = [c for c in bundle.bundle_columns() if c in df.columns]
        if not columns:
            columns = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
    missing = [c for c in columns if c not in df.columns]
    if missing:
        print(f"note: the table has no column(s) {missing}; they are not checked")
    return [c for c in columns if c in df.columns and c not in skip]


def population_stability(before, now, bins=PSI_BINS, floor=PSI_FLOOR):
    """The population stability index of one column between two periods. Returns (index, number of bins).

    before, now   the column's values in the first and in the second period, shape [rows] each

    A numeric column is cut at the quantiles of `before` into at most `bins` bins (equal quantiles
    merge, so a column with few values gets fewer bins). Any other column uses each value seen in
    `before` as a bin and one more bin for values only seen in `now`. A missing value is a bin of
    its own in both cases, so a column that starts or stops being filled is seen as a move. Each
    share is raised to at least `floor` before the logarithm. NaN when either period is empty.
    """
    before = pd.Series(np.asarray(before))
    now = pd.Series(np.asarray(now))
    if len(before) == 0 or len(now) == 0:
        return np.nan, 0
    if pd.api.types.is_numeric_dtype(before.dtype) and pd.api.types.is_numeric_dtype(now.dtype):
        b = before.to_numpy(dtype=np.float64)
        n = now.to_numpy(dtype=np.float64)
        have = b[~np.isnan(b)]
        inner = np.unique(np.quantile(have, np.linspace(0, 1, int(bins) + 1)[1:-1])) if len(have) else np.zeros(0)
        # Bin j holds values in (edge j-1, edge j]; the last bin is "missing". A value equal to an
        # edge goes to the lower bin, so a count column that is mostly zero (all its edges at 0)
        # still keeps its zeros apart from its positive values.
        def bin_of(values):
            out = np.searchsorted(inner, values, side="left")
            out[np.isnan(values)] = len(inner) + 1
            return out
        n_bins = len(inner) + 2
        bin_before, bin_now = bin_of(b), bin_of(n)
    else:
        seen = pd.Index(before.dropna().astype(str).unique())
        def bin_of(values):
            out = seen.get_indexer(values.astype(str)).astype(np.int64)
            out[out < 0] = len(seen)                     # a value never seen before
            out[values.isna().to_numpy()] = len(seen) + 1
            return out
        n_bins = len(seen) + 2
        bin_before, bin_now = bin_of(before), bin_of(now)
    share_before = np.maximum(np.bincount(bin_before, minlength=n_bins) / len(before), floor)
    share_now = np.maximum(np.bincount(bin_now, minlength=n_bins) / len(now), floor)
    used = (np.bincount(bin_before, minlength=n_bins) + np.bincount(bin_now, minlength=n_bins)) > 0
    index = float(((share_now - share_before) * np.log(share_now / share_before))[used].sum())
    return index, int(used.sum())


def stability_table(first, second, columns, bins=PSI_BINS, floor=PSI_FLOOR, limit=PSI_LIMIT):
    """One line per column: stability index, bins, missing shares and means in both periods, and a verdict.

    first, second   the rows of the two periods (DataFrames with the columns)
    Returns a DataFrame sorted from the largest index to the smallest.
    """
    lines = []
    for name in columns:
        index, used = population_stability(first[name], second[name], bins, floor)
        numeric = pd.api.types.is_numeric_dtype(first[name]) and pd.api.types.is_numeric_dtype(second[name])
        lines.append({
            "column": name, "psi": index, "bins": used,
            "missing_first": float(first[name].isna().mean()) if len(first) else np.nan,
            "missing_second": float(second[name].isna().mean()) if len(second) else np.nan,
            "mean_first": float(first[name].mean()) if numeric else np.nan,
            "mean_second": float(second[name].mean()) if numeric else np.nan,
            "verdict": "-" if np.isnan(index) else ("moved" if index > limit else "steady"),
        })
    frame = pd.DataFrame(lines, columns=["column", "psi", "bins", "missing_first", "missing_second",
                                         "mean_first", "mean_second", "verdict"])
    return frame.sort_values("psi", ascending=False, na_position="last").reset_index(drop=True)


def account_folds(accounts, folds=FOLDS, seed=0):
    """A fold number from 0 to folds - 1 per row, the same for every row of one account. Shape [rows].

    Rows of one account are alike in both periods. If the domain check trained on some rows of an
    account and was read on others, it could recognise the account instead of the period; whole
    accounts in one fold keep the read honest.
    """
    codes = timekeys.codes(accounts)
    n_accounts = int(codes.max()) + 1 if len(codes) else 0
    assignment = np.random.default_rng(seed).permutation(n_accounts) % int(folds)
    return assignment[codes]


def domain_check(first, second, columns, account_col=None, folds=FOLDS, rounds=ROUNDS,
                 max_rows=MAX_ROWS_PER_PERIOD, seed=0, threads=THREADS):
    """How well a tree model tells the rows of the second period from those of the first.

    first, second   the rows of the two periods, with the columns and the account column
    columns         the export columns the model may use

    Returns a dict:
        auc          area under the ROC curve of the out-of-fold scores (0.5 means "no difference")
        rows         rows used from the first and the second period, as a pair
        importance   DataFrame of the columns the model used, by total gain, largest first
    The rows of each period are drawn down to `max_rows` at random. Each account fold is scored
    by a model trained on the other folds. A missing value stays missing; the trees learn where
    to send it, so a column that is filled in one period and empty in the other is noticed.
    `threads` is the number of processor threads XGBoost uses (None: all of them).
    """
    account_col = _shared.pick(account_col, "ACCOUNT_COL")
    rng = np.random.default_rng(seed)
    parts = []
    for frame in (first, second):
        if len(frame) > max_rows:
            frame = frame.iloc[np.sort(rng.choice(len(frame), int(max_rows), replace=False))]
        parts.append(frame)
    if min(len(parts[0]), len(parts[1])) == 0 or not columns:
        print("note: a period has no rows or no column is left; the domain check is skipped")
        return {"auc": np.nan, "rows": (len(parts[0]), len(parts[1])),
                "importance": pd.DataFrame(columns=["column", "gain"])}
    both = pd.concat(parts, ignore_index=True)
    x = _shared.numeric_matrix(both, columns)
    is_second = np.r_[np.zeros(len(parts[0])), np.ones(len(parts[1]))]
    fold = account_folds(both[account_col], folds, seed)
    margin = np.full(len(both), np.nan)
    gain = pd.Series(0.0, index=[f"f{j}" for j in range(len(columns))])
    for f in range(int(folds)):
        held = fold == f
        if not held.any() or held.all():
            continue
        model = _shared.fit_trees(x[~held], is_second[~held], rounds=rounds, seed=seed + f,
                                  params=None if threads is None else {"nthread": int(threads)})
        margin[held] = _shared.tree_margin(model, x[held])
        gain = gain.add(pd.Series(model.get_score(importance_type="total_gain")), fill_value=0.0)
    scored = ~np.isnan(margin)
    auc = float(roc_auc_score(is_second[scored], margin[scored])) if len(np.unique(is_second[scored])) == 2 else np.nan
    importance = pd.DataFrame({"column": [columns[int(k[1:])] for k in gain.index], "gain": gain.to_numpy()})
    importance = importance[importance["gain"] > 0].sort_values("gain", ascending=False).reset_index(drop=True)
    return {"auc": auc, "rows": (len(parts[0]), len(parts[1])), "importance": importance}


def check_release(df, columns=None, first=None, second=None, account_col=None, time_col=None, folds=FOLDS,
                  rounds=ROUNDS, max_rows=MAX_ROWS_PER_PERIOD, bins=PSI_BINS, seed=0, threads=THREADS, quiet=False):
    """Both checks on one export table that holds two periods. Prints the results and returns them.

    df       export columns with account and time, shape [rows, ...]
    columns  the columns to check (default: see `gate_columns`)
    first    (start, end) of the first period, start included and end excluded
             (default: settings.EVAL_HISTORY_START to settings.TARGET_START)
    second   (start, end) of the second period (default: settings.TARGET_START to settings.TARGET_END)

    Returns a dict with "auc", "rows", "importance", "stability" (the table of
    `stability_table`) and "columns". Nothing is stopped whatever the numbers are.
    """
    first = first or (settings.EVAL_HISTORY_START, settings.TARGET_START)
    second = second or (settings.TARGET_START, settings.TARGET_END)
    columns = gate_columns(df, columns, account_col=account_col, time_col=time_col)
    secs = timekeys.seconds(df[_shared.pick(time_col, "TIME_COL")])
    rows_first = df[_shared.in_period(secs, *first)]
    rows_second = df[_shared.in_period(secs, *second)]
    stability = stability_table(rows_first, rows_second, columns, bins)
    domain = domain_check(rows_first, rows_second, columns, account_col, folds, rounds, max_rows, seed, threads)
    result = {**domain, "stability": stability, "columns": columns}
    if not quiet:
        verdict = "-" if np.isnan(domain["auc"]) else ("moved" if domain["auc"] > AUC_LIMIT else "steady")
        _shared.show(f"Domain check: {first[0]} to {first[1]} against {second[0]} to {second[1]}",
                     [{"rows_first": domain["rows"][0], "rows_second": domain["rows"][1], "columns": len(columns),
                       "auc": domain["auc"], "limit": AUC_LIMIT, "verdict": verdict}])
        _shared.show("Columns the domain check leaned on most", domain["importance"].head(TOP_COLUMNS))
        _shared.show("Population stability index per column", stability)
    return result


def demo_table(n_accounts=200, seed=1):
    """Made-up bundle columns for two months, from bundle.py's own made-up export tables."""
    fit_table, table = bundle.demo_tables(n_accounts=n_accounts, seed=seed)
    return bundle.build_bundle(table, bundle.fit_bundle(fit_table))


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(description="Check whether export columns look the same in two periods.")
    parser.add_argument("--table", default=None, help="parquet file of export columns with account and time")
    parser.add_argument("--columns", nargs="*", default=None, help="columns to check (default: the bundle columns)")
    parser.add_argument("--first", nargs=2, default=None, metavar=("START", "END"), help="first period")
    parser.add_argument("--second", nargs=2, default=None, metavar=("START", "END"), help="second period")
    parser.add_argument("--rounds", type=int, default=ROUNDS, help="trees of the domain check")
    parser.add_argument("--threads", type=int, default=THREADS, help="processor threads of the domain check (0: all)")
    parser.add_argument("--demo", action="store_true", help="run on made-up bundle columns")
    parser.add_argument("--out", default=None, help="write the stability table to this parquet file")
    args = parser.parse_args(argv)

    if args.demo:
        df = demo_table()
    elif args.table:
        df = tables.read_columns(args.table)
    else:
        parser.error("give --table or --demo")
    result = check_release(df, args.columns, args.first, args.second, rounds=args.rounds,
                           threads=args.threads or None)
    if args.out:
        _shared.save(result["stability"], args.out)
    return result


if __name__ == "__main__":
    main()
