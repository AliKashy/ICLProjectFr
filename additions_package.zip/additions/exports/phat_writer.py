"""Earlier-row scores as columns: the model's score on each of the account's latest earlier rows.

What this file does
-------------------
For every target row it looks up the account's latest rows in strictly earlier seconds and
writes this model's fraud probability on each of them as one column. The default layout is
the one the reading model was written for: its columns run from the oldest position to the
target row, which comes last.

    phat_h18   the reading model's own slot for the target row: written as 0.0, never a score
    phat_h17   the probability the model gave to the most recent earlier row
    phat_h16   the same for the one before it
    ...
    phat_h1    the same for the 17th most recent earlier row
    phat_n     how many earlier rows were found (0 to 17)

A position with no earlier row holds a missing value. On request the transaction id of each
history row is written beside its score, so the reading side can check that a position holds
the row it expects.

Three habits of that reader shape the defaults. It joins this table to its own rows by
position, not by id, and looks for one file per data file (phat_<number>.parquet, the number
taken from the end of the data file's name); so with --target-ids the rows are written in the
order of the target file, one row per target row. It counts the transactions of its window
(n) and reads the last n of phat_h1 .. phat_h18, the last one being the target row. And when
one of those n values is missing it either leaves the row out (its skip_nan_phats option) or
puts 0.0 in every missing place; so the target slot holds 0.0 (the reader hides that position
anyway), and --fill can put a number in the empty history positions as well.

What still has to agree with the reader, and is not checked here: its n - 1 earlier
transactions must be the rows found here. When its window holds an earlier row this file does
not count (a row of the same second, a row before the start of the prediction file, a row
older than MAX_AGE_SECONDS), it reads a missing value or, worse, a score shifted by one or more
positions; phat_n beside the reader's own count shows where. A window of more than 18
transactions is read from phat_h1 onward, so its positions no longer line up at all.

Why it exists
-------------
Another sequence model that reads an account's last transactions can take a soft fraud
probability for each of its history positions. Frauds come in runs on one account, so most
frauds follow an earlier fraud of that account, and a history whose recent rows were scored
high is the plainest sign of a run. The labels of those rows cannot say so: fraud labels
arrive weeks after the transaction, so the recent history of a row being scored is unlabelled.
This model's scores on the same rows exist the moment they are scored. Writing them in the
reading model's own layout makes that model a second consumer with no change to its code.

The scores must be out of sample where they are used. On rows of accounts the scoring model
trained on, its scores have drifted toward the labels; a reader trained on such columns learns
to trust them more than it can at serving time. For the reader's training files, the scores
therefore have to come from a model that did not train on those files.

Where it goes
-------------
After scoring, in the exports. The input is a prediction file with whole account histories;
the output is one row per target row for the other team's dataset builder: in the order of
its target file when one is given, and carrying the transaction id beside the columns.
Nothing in this network changes. A served version keeps the last 17 scores per account.

What to change for the pod
--------------------------
`HISTORY_ROWS` (how many earlier rows the reader takes), `HISTORY_COLUMNS` (the column names it
expects, listed from the most recent earlier row to the oldest; the default names follow a
reader that numbers its positions from the oldest to the target), `EMPTY_COLUMNS` and
`EMPTY_VALUE` (columns of its layout that hold no earlier row, such as its slot for the target
row, and what is written there), `FILL_VALUE` (what an empty history position holds),
`COUNT_COLUMN`, `ID_COLUMNS` and `MAX_AGE_SECONDS`. The file name the reader looks for is its
own matter: the reader this layout was written for wants one file per data file, named after
that file's number. settings.py: ID_COL, ACCOUNT_COL, TIME_COL, ORDER_COL,
SCORE_COL and SCORE_KIND. The rule here is strict: only rows of earlier seconds are history,
and two rows of one second never see each other. A reader that counts same-second rows as
history by a sequence number will have other rows at those positions; either its builder
takes the same strict rule, or the ids written with --with-ids are used to line the two up.
The evaluation files start one month before the scored month, so rows early in a file have
fewer than 17 earlier rows.

How to try it
-------------
    python additions/exports/phat_writer.py --demo
    python additions/exports/phat_writer.py --pred predictions.parquet --out phats.parquet
    python additions/exports/phat_writer.py --pred predictions.parquet --target-ids targets_42.parquet \\
        --fill 0 --with-ids --out phat_42.parquet
or, from Python:
    columns = write_phats(predictions)
    aligned = in_target_order(columns, target_ids)       # row i belongs to row i of the reader's file
The tests are in additions/tests/test_exports_phat_writer.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, tables
from additions.common.history import EarlierRows
from additions.common.timekeys import MISSING_SECOND
from additions.exports import _shared

# PLACEHOLDER: the number of history positions the reading model takes per target row.
HISTORY_ROWS = 17

# PLACEHOLDER: the column names the reading model expects for those positions. Entry 0 is the column
# of the most recent earlier row, entry 1 the one before it, and so on. The reader this layout was
# written for numbers its columns from the oldest position to the target row, so the most recent
# earlier row is phat_h17 and the oldest is phat_h1. For a reader that counts from the most recent
# row, reverse the list.
HISTORY_COLUMNS = tuple(f"phat_h{k}" for k in range(HISTORY_ROWS, 0, -1))

# PLACEHOLDER: columns of the reader's layout that hold no earlier row, for example its slot for the
# target row itself, and the value written into them. Put () when the layout has none. The value
# is a number, not a missing value, because the reader named above leaves out a row with a
# missing value in a column it reads.
EMPTY_COLUMNS = (f"phat_h{HISTORY_ROWS + 1}",)
EMPTY_VALUE = 0.0

# PLACEHOLDER: what is written at a history position that has no earlier row. None writes a
# missing value. A reader that leaves out rows with a missing value needs a number here: 0.0
# says "no sign of fraud", which is also what the reader named above puts there by itself
# unless its skip_nan_phats option is on.
FILL_VALUE = None

# PLACEHOLDER: the column that holds the number of earlier rows found; None leaves it out.
COUNT_COLUMN = "phat_n"

# PLACEHOLDER: the names of the optional columns that hold the transaction id of each history row.
ID_COLUMNS = tuple(f"phat_id_h{k}" for k in range(HISTORY_ROWS, 0, -1))

# PLACEHOLDER: the oldest an earlier row may be, in seconds; None means no limit (the last rows of
# the account, however old they are).
MAX_AGE_SECONDS = None


def earlier_positions(keys, secs, tie=None, n_rows=HISTORY_ROWS, max_age=None):
    """For every row, the table positions of its account's latest rows in strictly earlier seconds.

    keys, secs   account code and whole second of every row (see _shared.account_and_time)
    tie          one value per row that orders rows inside a second (a sequence number or the
                 transaction id); None keeps the order of the table
    n_rows       how many earlier rows are wanted
    max_age      only rows at most this many seconds old count; None means no limit

    Returns an int64 array [rows, n_rows]. Column k holds the row number (position in the
    table) of the (k + 1)-th most recent earlier row of the same account, or -1 when the
    account has fewer earlier rows.

    Time rule: an earlier row lies in a strictly earlier second. Rows of the row's own second
    are never included, whatever `tie` says. `tie` only decides which of two history rows that
    share a second counts as the more recent one, so that the answer does not depend on the
    order of the table. A row without a time has no history and is in no other row's history.
    """
    keys = np.asarray(keys)
    secs = np.asarray(secs, dtype=np.int64)
    out = np.full((len(keys), int(n_rows)), -1, dtype=np.int64)
    placed = np.flatnonzero(secs != MISSING_SECOND)
    if len(placed) == 0:
        return out
    if tie is not None:
        # The engine sorts by account and second and keeps the given order inside a second. Handing
        # it the rows in tie order therefore puts the rows of one second in tie order.
        rank = pd.factorize(pd.Series(np.asarray(tie)[placed]), sort=True)[0]
        placed = placed[np.argsort(rank, kind="stable")]
    engine = EarlierRows(keys[placed], secs[placed])
    # In the engine's sorted order the strictly earlier rows of a row are the stretch lo .. hi - 1,
    # oldest first. The most recent one is at hi - 1, the one before it at hi - 2, and so on.
    lo, hi = engine.bounds(max_age)
    row_of = placed[engine.order]                         # table position of every sorted position
    # The loop runs over the history positions (17 steps over all rows at once), never over rows.
    for k in range(int(n_rows)):
        position = hi - 1 - k
        found = position >= lo
        out[row_of[found], k] = row_of[position[found]]
    return out


def write_phats(df, targets=None, history_columns=None, empty_columns=None, count_column=COUNT_COLUMN,
                with_ids=False, id_columns=None, max_age=MAX_AGE_SECONDS, id_col=None, account_col=None,
                time_col=None, order_col=None, score_col=None, score_kind=None, empty_value=None, fill=FILL_VALUE):
    """The earlier-row score columns for the rows of a prediction table.

    df                predictions of whole accounts: id, account, time and score. Rows that are
                      not targets stay in, because they are the history of the targets.
    targets           yes/no per row: the rows that are written (default: all)
    history_columns   names for the history positions, most recent first (default HISTORY_COLUMNS);
                      their number is the number of earlier rows written
    empty_columns     names of columns that hold no earlier row (default EMPTY_COLUMNS)
    empty_value       what is written into them (default EMPTY_VALUE)
    fill              what is written at a history position with no earlier row; None writes a
                      missing value (default FILL_VALUE)
    count_column      name of the count of earlier rows found; None leaves it out
    with_ids          True also writes the transaction id of each history row
    id_columns        names of those id columns (default ID_COLUMNS)
    max_age           the oldest an earlier row may be, in seconds; None means no limit

    Returns a DataFrame with one row per target row: the id, account and time columns, the
    history columns as float32 probabilities (missing, or `fill`, where there is no earlier
    row), the empty columns, the count and, on request, the id columns. The history columns
    are laid out from the oldest position to the most recent, followed by the empty columns.
    Only scores of earlier rows are written: no label is read, and the target row's own score
    is not included.
    """
    history_columns = list(HISTORY_COLUMNS if history_columns is None else history_columns)
    empty_columns = list(EMPTY_COLUMNS if empty_columns is None else empty_columns)
    keys, secs = _shared.account_and_time(df, account_col, time_col)
    probability = _shared.probabilities(df, score_col, score_kind)
    id_col = _shared.pick(id_col, "ID_COL")
    # Rows of one second are ordered by the sequence number when the table has one, else by the id.
    order_col = _shared.pick(order_col, "ORDER_COL")
    tie_col = order_col if order_col in df.columns else id_col if id_col in df.columns else None
    positions = earlier_positions(keys, secs, None if tie_col is None else df[tie_col].to_numpy(),
                                  len(history_columns), max_age)
    found = positions >= 0
    out = {}
    for name in (id_col, _shared.pick(account_col, "ACCOUNT_COL"), _shared.pick(time_col, "TIME_COL")):
        if name in df.columns:
            out[name] = df[name].to_numpy()
    absent = np.nan if fill is None else float(fill)
    # Entry k of the names is the k-th most recent earlier row; the columns are written oldest first.
    for k in reversed(range(len(history_columns))):
        out[history_columns[k]] = np.where(found[:, k], probability[np.maximum(positions[:, k], 0)],
                                           absent).astype(np.float32)
    for name in empty_columns:
        out[name] = np.full(len(df), EMPTY_VALUE if empty_value is None else float(empty_value), dtype=np.float32)
    if count_column:
        out[count_column] = found.sum(axis=1).astype(np.int16)
    if with_ids and id_col in df.columns:
        ids = df[id_col].to_numpy()
        id_columns = list(ID_COLUMNS if id_columns is None else id_columns)
        for k, name in enumerate(id_columns[:len(history_columns)]):
            # A nullable column keeps whole-number ids whole where some positions are empty.
            column = pd.Series(ids[np.maximum(positions[:, k], 0)]).convert_dtypes()
            out[name] = column.where(found[:, k]).to_numpy(dtype=object, na_value=None)
    elif with_ids:
        print(f"note: the table has no column '{id_col}'; the ids of the history rows are skipped")
    frame = pd.DataFrame(out, index=df.index)
    return frame if targets is None else frame.loc[np.asarray(targets, dtype=bool)]


def _comparable_ids(first, second):
    """Two id columns in a form in which the same id is equal on both sides.

    Two files can store the same transaction ids differently, one as numbers and the other as
    text. A number never equals its text, so every lookup would come back empty without a
    word. When the two columns differ in that way, both are compared as text (a whole number
    stored with a decimal part is written without it).
    """
    first, second = pd.Series(np.asarray(first)), pd.Series(np.asarray(second))
    if pd.api.types.is_numeric_dtype(first) != pd.api.types.is_numeric_dtype(second):
        return pd.Series(tables.id_text(first)), pd.Series(tables.id_text(second))
    return first, second


def in_target_order(frame, target_ids, id_col=None, history_columns=None, empty_columns=None,
                    count_column=COUNT_COLUMN, empty_value=None, fill=FILL_VALUE):
    """The written rows in the order of a list of target ids: one output row per target id.

    frame        what `write_phats` returned
    target_ids   the transaction ids of the reader's rows, in the reader's own row order

    A reader that joins by position needs row i of this table to belong to row i of its own
    file. An id that occurs twice in the list gets its row twice. An id the predictions do not
    hold gets a row with empty history (missing values, or `fill`), the empty columns at their
    value and a count of zero, and one printed line says how many there were.
    """
    id_col = _shared.pick(id_col, "ID_COL")
    wanted = pd.Series(np.asarray(target_ids))
    once = frame.drop_duplicates(id_col).set_index(id_col)
    own, keys = _comparable_ids(once.index, wanted)
    once.index = pd.Index(own.to_numpy())
    out = once.reindex(keys.to_numpy()).reset_index(drop=True)
    out.insert(0, id_col, wanted.to_numpy())                    # the ids as the target file stores them
    missing = ~keys.isin(once.index).to_numpy()
    if missing.any():
        print(f"note: {int(missing.sum())} of {len(wanted)} target ids are not in the predictions; "
              "their history is left empty")
        for name in (EMPTY_COLUMNS if empty_columns is None else empty_columns):
            if name in out.columns:
                out.loc[missing, name] = EMPTY_VALUE if empty_value is None else float(empty_value)
        if count_column and count_column in out.columns:
            out.loc[missing, count_column] = 0
        if fill is not None:
            for name in (HISTORY_COLUMNS if history_columns is None else history_columns):
                if name in out.columns:
                    out.loc[missing, name] = float(fill)
    if count_column and count_column in out.columns:
        out[count_column] = out[count_column].astype(np.int16)
    return out


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(description="Write the model's scores on each row's latest earlier rows as columns.")
    parser.add_argument("--pred", default=None, help="prediction file with whole account histories")
    parser.add_argument("--target-ids", default=None,
                        help="parquet file with the transaction ids of the rows to write, in the reader's row "
                             "order; the output has one row per row of this file, in the same order "
                             "(default: every row of the predictions)")
    parser.add_argument("--fill", type=float, default=None,
                        help="number written at a history position with no earlier row (default: a missing value)")
    parser.add_argument("--with-ids", action="store_true", help="also write the transaction id of each history row")
    parser.add_argument("--max-age-days", type=float, default=None, help="oldest earlier row that counts (default: no limit)")
    parser.add_argument("--demo", action="store_true", help="run on made-up rows instead of a file")
    parser.add_argument("--out", default=None, help="write the columns to this parquet file")
    args = parser.parse_args(argv)

    if args.demo:
        df = synthetic.make_scores(synthetic.make_transactions(n_accounts=200, seed=1), seed=1)
    elif args.pred:
        df = tables.read_columns(args.pred)
    else:
        parser.error("give --pred or --demo")
    targets, wanted = None, None
    if args.target_ids:
        wanted = tables.read_columns(args.target_ids, [settings.ID_COL])[settings.ID_COL]
        own, asked = _comparable_ids(df[settings.ID_COL], wanted)
        targets = own.isin(asked).to_numpy()
        print(f"{int(targets.sum())} of {len(df)} rows are target rows")
    max_age = MAX_AGE_SECONDS if args.max_age_days is None else int(args.max_age_days * 86_400)
    fill = FILL_VALUE if args.fill is None else args.fill
    frame = write_phats(df, targets, with_ids=args.with_ids, max_age=max_age, fill=fill)
    if wanted is not None:
        frame = in_target_order(frame, wanted.to_numpy(), fill=fill)     # row i belongs to row i of the target file
    _shared.show(f"Earlier-row score columns ({len(frame)} target rows)", _shared.summary(
        frame.drop(columns=[c for c in (settings.ID_COL, *ID_COLUMNS) if c in frame.columns])))
    if args.out:
        _shared.save(frame, args.out)
    return frame


if __name__ == "__main__":
    main()
