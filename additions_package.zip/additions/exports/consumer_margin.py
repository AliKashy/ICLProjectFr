"""How a downstream tree model should take two scores: through the margin.

What this file does
-------------------
It fits and reads the set-up in which a tree model that already has a score of its own takes
this model's score as well. The two scores enter as one starting value per row,

    base margin = a * logit(other model) + b * logit(this model) + c

with a, b and c fitted by logistic regression. XGBoost then starts from that margin and learns
corrections to it from the remaining columns. Three arms are fitted on one table and read on
another, with the same tree settings for each:

    other            the other model's score alone (as a * logit + c)
    blend            the two-score margin
    blend + bundle   the two-score margin plus tree corrections learned from the bundle columns

For every arm the tool prints the share of frauds and of fraud dollars inside the alert cut and
the average precision. For each pair of arms it prints a swap table at the cut (frauds and
other rows that moved in and out) and a paired bootstrap that resamples whole accounts.

Why it exists
-------------
The alert budget is a fixed small share of rows, so everything is decided among the highest
scores. A tree model that receives a score as one more column sorts it into a limited number
of bins and has to rebuild the ranking inside the top bin from scratch; where two strong
scores have to be weighed against each other, it approximates a sloped line with steps. A
margin keeps both scores continuous exactly where the cut falls, and three fitted numbers are
enough to weigh them. The trees are then free to spend their splits on what neither score
holds. How a consumer is fitted can move its capture as much as what it is given, so a fair
statement about an export needs the consumer's set-up fixed first and equal for every arm.

Where it goes
-------------
Second stage and comparison: after scoring, after the bundle (bundle.py) is built, on the
consumer's side. Nothing in the network changes. The same three numbers and the same trees
are what a served consumer would apply.

What to change for the pod
--------------------------
`OTHER_SCORE_COL` and `OTHER_SCORE_KIND` (the column of the other model's score and whether it
is a probability or a log-odds value). settings.py: ACCOUNT_COL, TIME_COL, LABEL_COL,
AMOUNT_COL, SCORE_COL, SCORE_KIND, TARGET_START, TARGET_END, OUTSORT_PER_MILLE and the
bootstrap settings. `_shared.TREE_PARAMS` and `_shared.TREE_ROUNDS` are the tree settings of
every arm. The fit table and the read table must hold different accounts, and both scores
and all bundle columns must come from models that did not train on those accounts; a score
that saw the labels of the fit rows gets a weight it does not deserve. The fit rows should
have history behind them (the first days of a file have none, so their window columns are
empty). The other model's score and the bundle columns are joined to the rows by transaction
id beforehand (feature_store.by_id does that). `base_columns` are the consumer's own columns;
they go to the trees of every arm.

How to try it
-------------
    python additions/exports/consumer_margin.py --demo
    python additions/exports/consumer_margin.py --fit consumer_fit.parquet --read consumer_read.parquet \\
        --out arm_scores.parquet
or, from Python:
    result = run_arms(fit_table, read_table)
    print(result["table"]); print(result["swaps"]); print(result["bootstrap"])
The tests are in additions/tests/test_exports_consumer_margin.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd

from additions import settings
from additions.common import ranking, synthetic, tables
from additions.common.bootstrap import paired_bootstrap
from additions.exports import _shared, bundle

# PLACEHOLDER: the column that holds the other model's score, and whether it is a probability
# ("probability") or a log-odds value ("logit").
OTHER_SCORE_COL = "other_score"
OTHER_SCORE_KIND = "probability"

# The arms in the order in which they are reported, and the pairs (candidate, control) that are
# compared by the swap table and the bootstrap.
ARMS = ("other", "blend", "blend + bundle")
PAIRS = (("blend", "other"), ("blend + bundle", "other"), ("blend + bundle", "blend"))


def other_logits(df, other_col=None, other_kind=None):
    """The other model's score as log-odds, shape [rows]. A row without that score gets a missing value."""
    column = df[OTHER_SCORE_COL if other_col is None else other_col]
    values = pd.to_numeric(column, errors="coerce").to_numpy(dtype=np.float64)
    return ranking.to_logit(values, OTHER_SCORE_KIND if other_kind is None else other_kind)


def fit_blend(labels, other_logit, our_logit=None):
    """Fit the margin a * other + b * own + c by logistic regression. Returns {"a", "b", "c"}.

    labels        1 for fraud, 0 otherwise, shape [rows]
    other_logit   the other model's log-odds, shape [rows]
    our_logit     this model's log-odds, shape [rows]; None fits the other score alone (b = 0)

    The fit has no pull toward zero worth the name: three numbers on many rows need none. When
    the rows hold no fraud (or only frauds) nothing can be fitted; one line is printed and the
    scores are simply added (a = 1, b = 1 or 0, c = 0).
    """
    alone = our_logit is None
    x = np.asarray(other_logit)[:, None] if alone else np.column_stack([other_logit, our_logit])
    fitted = _shared.fit_logistic(x, labels, l2=1e-6, what="the blend of the two scores")
    if fitted is None:
        return {"a": 1.0, "b": 0.0 if alone else 1.0, "c": 0.0}
    return {"a": fitted["weights"][0], "b": 0.0 if alone else fitted["weights"][1], "c": fitted["bias"]}


def blend_margin(blend, other_logit, our_logit):
    """a * other + b * own + c for every row, shape [rows]."""
    return blend["a"] * np.asarray(other_logit) + blend["b"] * np.asarray(our_logit) + blend["c"]


def swap_table(labels, control, candidate, amounts=None, per_mille=None, rounding=None):
    """What changes inside the alert cut when the candidate's ranking replaces the control's.

    labels      1 for fraud, 0 otherwise, shape [rows]
    control     scores of the ranking that is replaced, shape [rows]
    candidate   scores of the ranking that replaces it, shape [rows]
    amounts     dollar amounts, shape [rows]; None leaves the dollar line out

    Returns a DataFrame with one line for frauds, one for other rows and, with amounts, one
    for fraud dollars. Columns: in_both (alerted by both rankings), moved_in (alerted by the
    candidate only), moved_out (alerted by the control only) and net (moved_in - moved_out).
    Both rankings alert the same number of rows, so the rows that move in equal the rows that
    move out; the question is how many of each kind are frauds. Ties at the cut are settled by
    row order, which gives every row a definite side.
    """
    y = np.asarray(labels).astype(np.float64)
    new = ranking.alert_mask(candidate, per_mille, rounding)
    old = ranking.alert_mask(control, per_mille, rounding)
    kinds = [("frauds", y), ("other rows", 1.0 - y)]
    if amounts is not None:
        kinds.append(("fraud dollars", y * np.nan_to_num(np.asarray(amounts, dtype=np.float64), nan=0.0)))
    lines = []
    for name, weight in kinds:
        moved_in, moved_out = float(weight[new & ~old].sum()), float(weight[old & ~new].sum())
        lines.append({"rows": name, "in_both": float(weight[new & old].sum()), "moved_in": moved_in,
                      "moved_out": moved_out, "net": moved_in - moved_out})
    return pd.DataFrame(lines)


def arm_scores(fit_df, read_df, bundle_columns, base_columns=(), rounds=None, params=None, seed=0,
               label_col=None, positive_label=None, score_col=None, score_kind=None, other_col=None,
               other_kind=None):
    """Fit the three arms on one table and score another. Returns (scores, blend).

    fit_df           rows the margins and the trees are fitted on (both scores present)
    read_df          rows of other accounts that are scored
    bundle_columns   the export columns the trees of the last arm may read
    base_columns     the consumer's own columns; the trees of every arm read them
    rounds, params, seed   tree settings (default: those of _shared), the same for every arm

    `scores` is {arm name: log-odds per row of read_df}; `blend` holds a, b and c of the
    two-score margin. An arm with no columns for its trees is its margin, unchanged: with no
    base columns the first two arms contain no tree at all.
    """
    y_fit = _shared.fraud_flags(fit_df, label_col, positive_label)
    other_fit, other_read = other_logits(fit_df, other_col, other_kind), other_logits(read_df, other_col, other_kind)
    ours_fit, ours_read = _shared.logits(fit_df, score_col, score_kind), _shared.logits(read_df, score_col, score_kind)
    alone = fit_blend(y_fit, other_fit)
    blend = fit_blend(y_fit, other_fit, ours_fit)

    def with_trees(margin_fit, margin_read, columns):
        """The margin plus what trees learn from `columns` on top of it (the margin itself without columns)."""
        columns = [c for c in dict.fromkeys(columns)]
        if not columns or rounds == 0:
            return margin_read
        model = _shared.fit_trees(_shared.numeric_matrix(fit_df, columns), y_fit, margin_fit, rounds, params, seed)
        return _shared.tree_margin(model, _shared.numeric_matrix(read_df, columns), margin_read)

    margin_fit, margin_read = blend_margin(blend, other_fit, ours_fit), blend_margin(blend, other_read, ours_read)
    scores = {
        "other": with_trees(blend_margin(alone, other_fit, 0.0), blend_margin(alone, other_read, 0.0), base_columns),
        "blend": with_trees(margin_fit, margin_read, base_columns),
        "blend + bundle": with_trees(margin_fit, margin_read, list(base_columns) + list(bundle_columns)),
    }
    return scores, blend


def default_bundle_columns(fit_df, read_df):
    """The bundle columns both tables hold, without s_full (it already is in the margin)."""
    return [c for c in bundle.bundle_columns() if c != "s_full" and c in fit_df.columns and c in read_df.columns]


def run_arms(fit_df, read_df, bundle_columns=None, base_columns=(), rounds=None, params=None, seed=0, draws=None,
             account_col=None, label_col=None, positive_label=None, amount_col=None, score_col=None,
             score_kind=None, other_col=None, other_kind=None, per_mille=None, rounding=None):
    """Fit the arms on `fit_df`, read them on `read_df`, and compare them.

    fit_df, read_df   tables with account, label, amount, both scores and the bundle columns;
                      they must hold different accounts. Every row of `read_df` is ranked, so
                      rows outside the scored month are removed before the call.
    bundle_columns    default: the bundle columns both tables hold, without s_full
    draws             bootstrap draws (default: settings.BOOTSTRAP_DRAWS)

    Rows that lack one of the two scores are left out of both tables with one printed line.
    Returns a dict:
      "blend"       a, b and c of the two-score margin
      "table"       one line per arm: rows, frauds, alerts, caught, udr, vdr, ap
      "swaps"       one swap table for all pairs of arms (columns candidate and control name the pair)
      "bootstrap"   one line per pair and measure: the candidate against the control, paired over accounts
      "read"        the rows of `read_df` that were ranked
      "scores"      {arm name: log-odds per row of "read"}
    """
    other_col = OTHER_SCORE_COL if other_col is None else other_col
    usable = []
    for name, df in (("fit", fit_df), ("read", read_df)):
        both = np.isfinite(other_logits(df, other_col, other_kind)) & np.isfinite(_shared.logits(df, score_col, score_kind))
        if not both.all():
            print(f"note: {int((~both).sum())} of {len(df)} {name} rows lack one of the two scores and are left out")
        usable.append(df.loc[both])
    fit_df, read_df = usable
    if bundle_columns is None:
        bundle_columns = default_bundle_columns(fit_df, read_df)
    scores, blend = arm_scores(fit_df, read_df, bundle_columns, base_columns, rounds, params, seed, label_col,
                               positive_label, score_col, score_kind, other_col, other_kind)
    y = _shared.fraud_flags(read_df, label_col, positive_label)
    amount = _shared.amounts(read_df, amount_col)
    units = read_df[_shared.pick(account_col, "ACCOUNT_COL")].to_numpy()
    table = pd.DataFrame([_shared.capture_line(arm, y, scores[arm], amount, per_mille, rounding) for arm in ARMS])
    swaps, lines = [], []
    for candidate, control in PAIRS:
        swap = swap_table(y, scores[control], scores[candidate], amount, per_mille, rounding)
        swap.insert(0, "control", control)
        swap.insert(0, "candidate", candidate)
        swaps.append(swap)
        # Whole accounts are resampled and both arms are read on the same draw: frauds come in runs
        # on one account, so single rows are not independent pieces of evidence.
        for measure, value in (("udr", False), ("vdr", True)):
            if value and amount is None:
                continue
            r = paired_bootstrap(units, y, scores[candidate], scores[control], amount, per_mille, draws,
                                 rounding=rounding, value=value)
            lines.append({"candidate": candidate, "control": control, "measure": measure,
                          **_shared.bootstrap_line(r, "candidate_capture", "control_capture")})
    return {"blend": blend, "table": table, "swaps": pd.concat(swaps, ignore_index=True),
            "bootstrap": pd.DataFrame(lines), "read": read_df, "scores": scores}


def demo_tables(n_accounts=400, seed=1):
    """Made-up fit and read tables with two scores and the bundle columns, on three sets of accounts."""
    probe_block, fit_table = bundle.demo_tables(n_accounts, seed)
    _, read_table = bundle.demo_tables(n_accounts, seed + 5)
    fitted = bundle.fit_bundle(probe_block)                      # probes and directions come from a third block
    made = []
    for i, (name, table) in enumerate((("fit", fit_table), ("read", read_table))):
        table = synthetic.make_scores(table, seed=seed + 20 + i, strength=2.0, column=OTHER_SCORE_COL)
        table[settings.ACCOUNT_COL] = name + "_" + table[settings.ACCOUNT_COL]   # two sets of accounts
        columns = bundle.build_bundle(table, fitted, keep_keys=False)
        made.append(pd.concat([table, columns], axis=1))
    return made


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(description="Two scores through the margin: other model, blend, blend plus bundle.")
    parser.add_argument("--fit", default=None, help="table the margins and trees are fitted on")
    parser.add_argument("--read", default=None, help="table of other accounts on which the arms are read")
    parser.add_argument("--other-col", default=None, help="column of the other model's score (default: OTHER_SCORE_COL)")
    parser.add_argument("--other-kind", default=None, choices=("probability", "logit"),
                        help="what that column holds (default: OTHER_SCORE_KIND)")
    parser.add_argument("--bundle-columns", nargs="*", default=None,
                        help="export columns for the trees of the last arm (default: the bundle columns found)")
    parser.add_argument("--base-columns", nargs="*", default=(), help="the consumer's own columns, for every arm")
    parser.add_argument("--rounds", type=int, default=None, help="number of trees (default: _shared.TREE_ROUNDS)")
    parser.add_argument("--draws", type=int, default=None, help="bootstrap draws (default: settings.BOOTSTRAP_DRAWS)")
    parser.add_argument("--start", default=None, help="first day of the scored month (default: settings.TARGET_START)")
    parser.add_argument("--end", default=None, help="first day after the scored month (default: settings.TARGET_END)")
    parser.add_argument("--all-rows", action="store_true", help="rank every row of the read table")
    parser.add_argument("--demo", action="store_true", help="run on made-up rows instead of files")
    parser.add_argument("--out", default=None, help="write the ranked rows with the score of every arm to this parquet file")
    args = parser.parse_args(argv)

    if args.demo:
        fit_table, read_table = demo_tables()
    elif args.fit and args.read:
        fit_table, read_table = tables.read_columns(args.fit), tables.read_columns(args.read)
    else:
        parser.error("give --fit and --read, or --demo")
    if not args.all_rows:
        # Only the scored month is ranked. The bundle columns of its rows were built beforehand,
        # with the earlier rows as history, so those rows are not needed here any more.
        secs = _shared.account_and_time(read_table)[1]
        scored = _shared.in_period(secs, args.start or settings.TARGET_START, args.end or settings.TARGET_END)
        if not scored.any():
            print("no row of the read table falls in the scored month; set TARGET_START and TARGET_END in "
                  "settings.py, or pass --start and --end, or pass --all-rows")
            return None
        read_table = read_table.loc[scored]
    result = run_arms(fit_table, read_table, args.bundle_columns, args.base_columns, args.rounds, draws=args.draws,
                      other_col=args.other_col, other_kind=args.other_kind)
    blend = result["blend"]
    print(f"\nbase margin = {blend['a']:.4f} * logit(other) + {blend['b']:.4f} * logit(own) + {blend['c']:.4f}")
    _shared.show("Arms on the read rows", result["table"])
    _shared.show("Swap table at the cut (candidate against control)", result["swaps"], digits=1)
    _shared.show("Paired bootstrap over accounts (candidate minus control)", result["bootstrap"])
    if args.out:
        out = result["read"][[c for c in (settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL)
                              if c in result["read"].columns]].copy()
        for arm in ARMS:
            out["arm_" + arm.replace(" + ", "_")] = result["scores"][arm]
        _shared.save(out, args.out)
    return result


if __name__ == "__main__":
    main()
