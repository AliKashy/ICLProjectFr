"""Soft labels: another team's tree model learns from this model's score without running it.

What this file does
-------------------
It builds a training target that mixes the fraud label with this model's probability,

    target = (1 - w) * label + w * probability          (w = 0.5 unless set otherwise)

trains a tree model (the student) on that target, using the student's own inputs only, and
trains the same model on the plain labels for comparison. Both students are then read on
other accounts against the true labels: share of frauds and of fraud dollars inside the alert
cut, average precision, and a paired bootstrap of the soft student against the hard one. The
model's own score on the read rows is printed beside them as a reference.

Why it exists
-------------
A label says "fraud" or "not fraud". The model's probability says how much a row looked like
fraud given the account's whole sequence, which is knowledge a tree model with single-row
inputs does not have. Training the tree on a mix of the two hands some of that knowledge over
through the target instead of through an input column. Nothing of this model then has to run
when the other model is served: the score is needed once, for the other team's training rows.
It is a second way of exporting, beside columns.

Two limits decide whether it helps. First, the probability has to come from a model that did
not train on those rows. A model's scores on its own training rows have drifted toward the
labels it was shown, so they are no better than the labels: the mix collapses back to the
plain label and nothing is handed over. Second, the student can only gain where the teacher
knows something the student lacks. Where the consumer already beats the teacher, the soft
target also hands over the teacher's mistakes, and the student can get worse. That is why the
comparison with the hard-label student, on rows of other accounts, is part of this file.

Where it goes
-------------
Exports and second stage: after scoring the other team's training rows with a model that
never saw those accounts. The training target of the other team's model changes; its inputs,
its serving and this network stay as they are. XGBoost's binary logistic loss accepts targets
between 0 and 1, so the change on their side is one column.

What to change for the pod
--------------------------
`SOFT_WEIGHT` (w above). settings.py: NUMERIC_COLS and CODE_COLS are used as the student's
inputs unless other lists are passed, and should be replaced by the consumer's real inputs;
LABEL_COL, POSITIVE_LABEL, AMOUNT_COL, ACCOUNT_COL, TIME_COL, SCORE_COL, SCORE_KIND,
TARGET_START, TARGET_END, OUTSORT_PER_MILLE and the bootstrap settings. `_shared.TREE_PARAMS`
and `_shared.TREE_ROUNDS` are the student's settings. The fit table and the read table must
hold different accounts. A student trained on the mix gives probabilities that sit between the
label rate and the teacher's, so a consumer that uses the probability itself, not only the
ranking, has to recalibrate it.

How to try it
-------------
    python additions/exports/soft_labels.py --demo
    python additions/exports/soft_labels.py --fit consumer_fit.parquet --read consumer_read.parquet \\
        --out student_scores.parquet
or, from Python:
    target = soft_targets(labels, probabilities)             # the one column the other team needs
    result = compare(fit_table, read_table)
    print(result["table"]); print(result["bootstrap"])
The tests are in additions/tests/test_exports_soft_labels.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, tables
from additions.common.bootstrap import paired_bootstrap
from additions.exports import _shared

# PLACEHOLDER: put the share of the model's probability in the training target here: 0 means plain
# labels, 1 means the probability alone, and 0.5 is the usual start.
SOFT_WEIGHT = 0.5

# The lines of the comparison, in the order in which they are reported.
TEACHER, HARD, SOFT = "teacher (this model's score)", "student on hard labels", "student on soft labels"


def soft_targets(labels, probabilities, weight=None):
    """The training target (1 - weight) * label + weight * probability, shape [rows].

    labels          1 for fraud, 0 otherwise, shape [rows]
    probabilities   this model's probability of fraud per row, shape [rows]; it must come from a
                    model that did not train on these rows
    weight          the share of the probability (default SOFT_WEIGHT)

    The result lies between 0 and 1. A row without a probability keeps its plain label, so a
    partly scored table can still be used.
    """
    weight = SOFT_WEIGHT if weight is None else float(weight)
    y = np.asarray(labels, dtype=np.float64)
    p = np.clip(np.asarray(probabilities, dtype=np.float64), 0.0, 1.0)
    return np.where(np.isnan(p), y, (1.0 - weight) * y + weight * p)


def _code_text(column):
    """The values of a code column as text; a whole number is written without a decimal part.

    The number 5411, the number 5411.0 and the text "5411" are the same code, and all three
    become "5411", so a column stored as numbers in one table and as text in the other lines
    up. A text with leading zeros ("00") and the number 0 do not line up: nothing in a number
    says how many zeros its text had. A missing value stays missing. The conversion is made
    once per distinct value, not once per row.
    """
    def one(value):
        if isinstance(value, (float, np.floating)) and np.isfinite(value) and float(value).is_integer():
            return str(int(value))
        return str(value).strip()
    return column.map({value: one(value) for value in pd.unique(column.dropna())})


def student_inputs(fit_df, read_df, numeric_cols=None, code_cols=None):
    """The student's own inputs for both tables. Returns (x_fit, x_read, names).

    numeric_cols   number columns (default settings.NUMERIC_COLS)
    code_cols      code columns (default settings.CODE_COLS)

    x_fit and x_read are float32 arrays [rows, len(names)]. A column that one of the tables
    lacks is skipped, and one printed line names all of them. A code column becomes one whole
    number per distinct value of the fit table; a value the fit table never held becomes a
    missing value in the read table, which is all a model can say about a code it never saw.
    """
    numeric = list(_shared.pick(numeric_cols, "NUMERIC_COLS"))
    codes = [c for c in _shared.pick(code_cols, "CODE_COLS") if c not in numeric]
    have = [c for c in numeric + codes if c in fit_df.columns and c in read_df.columns]
    skipped = [c for c in numeric + codes if c not in have]
    if skipped:
        print(f"note: student inputs skipped because a table has no such column: {', '.join(skipped)}")
    numeric = [c for c in numeric if c in have]
    parts_fit, parts_read = [_shared.numeric_matrix(fit_df, numeric)], [_shared.numeric_matrix(read_df, numeric)]
    for c in (c for c in codes if c in have):
        # The loop runs over the code columns, not over rows. The codes are compared as text, so
        # a column stored as numbers in one table and as text in the other still lines up.
        fit_text, read_text = _code_text(fit_df[c]), _code_text(read_df[c])
        known = pd.Index(pd.unique(fit_text.dropna()))
        for parts, text in ((parts_fit, fit_text), (parts_read, read_text)):
            position = known.get_indexer(text).astype(np.float32)
            position[(position < 0) | text.isna().to_numpy()] = np.nan
            parts.append(position[:, None])
    return np.hstack(parts_fit), np.hstack(parts_read), numeric + [c for c in codes if c in have]


def compare(fit_df, read_df, weight=None, numeric_cols=None, code_cols=None, rounds=None, params=None, seed=0,
            draws=None, account_col=None, label_col=None, positive_label=None, amount_col=None, score_col=None,
            score_kind=None, per_mille=None, rounding=None):
    """Train one student on hard labels and one on soft labels, and read both on other accounts.

    fit_df    the student's training rows: its inputs, the label and this model's score, which
              must be out of sample on these rows
    read_df   rows of other accounts with the same columns; every row is ranked
    weight    the share of the probability in the soft target (default SOFT_WEIGHT)
    rounds, params, seed   the student's tree settings, the same for both students

    Returns a dict:
      "table"       three lines (teacher, hard student, soft student): rows, frauds, alerts,
                    caught, udr, vdr, ap, all against the true labels of the read rows
      "bootstrap"   the soft student against the hard student, paired over accounts (udr and vdr)
      "scores"      {line name: log-odds per row of read_df}
      "inputs"      the names of the student's inputs
    """
    x_fit, x_read, names = student_inputs(fit_df, read_df, numeric_cols, code_cols)
    y_fit = _shared.fraud_flags(fit_df, label_col, positive_label)
    target = soft_targets(y_fit, _shared.probabilities(fit_df, score_col, score_kind), weight)
    # Same inputs, same settings, same seed: the two students differ in their target only.
    hard = _shared.fit_trees(x_fit, y_fit, None, rounds, params, seed)
    soft = _shared.fit_trees(x_fit, target, None, rounds, params, seed)
    scores = {TEACHER: _shared.logits(read_df, score_col, score_kind),
              HARD: _shared.tree_margin(hard, x_read), SOFT: _shared.tree_margin(soft, x_read)}
    y = _shared.fraud_flags(read_df, label_col, positive_label)
    amount = _shared.amounts(read_df, amount_col)
    table = pd.DataFrame([_shared.capture_line(name, y, s, amount, per_mille, rounding) for name, s in scores.items()])
    units = read_df[_shared.pick(account_col, "ACCOUNT_COL")].to_numpy()
    lines = []
    for measure, value in (("udr", False), ("vdr", True)):
        if value and amount is None:
            continue
        r = paired_bootstrap(units, y, scores[SOFT], scores[HARD], amount, per_mille, draws, rounding=rounding,
                             value=value)
        lines.append({"measure": measure, **_shared.bootstrap_line(r, "soft", "hard")})
    return {"table": table, "bootstrap": pd.DataFrame(lines), "scores": scores, "inputs": names}


def demo_tables(n_accounts=400, seed=1):
    """Made-up fit and read tables of different accounts, each with a made-up model score."""
    made = []
    for i, name in enumerate(("fit", "read")):
        df = synthetic.make_scores(synthetic.make_transactions(n_accounts=n_accounts, seed=seed + i), seed=seed + i)
        df[settings.ACCOUNT_COL] = name + "_" + df[settings.ACCOUNT_COL]
        made.append(df)
    return made


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(description="Train a tree model on soft labels and compare it with hard labels.")
    parser.add_argument("--fit", default=None, help="the student's training rows, with this model's out-of-sample score")
    parser.add_argument("--read", default=None, help="rows of other accounts on which both students are read")
    parser.add_argument("--weight", type=float, default=None, help="share of the probability in the target (default: SOFT_WEIGHT)")
    parser.add_argument("--numeric-cols", nargs="*", default=None, help="the student's number inputs (default: settings.NUMERIC_COLS)")
    parser.add_argument("--code-cols", nargs="*", default=None, help="the student's code inputs (default: settings.CODE_COLS)")
    parser.add_argument("--rounds", type=int, default=None, help="number of trees (default: _shared.TREE_ROUNDS)")
    parser.add_argument("--draws", type=int, default=None, help="bootstrap draws (default: settings.BOOTSTRAP_DRAWS)")
    parser.add_argument("--start", default=None, help="first day of the scored month (default: settings.TARGET_START)")
    parser.add_argument("--end", default=None, help="first day after the scored month (default: settings.TARGET_END)")
    parser.add_argument("--all-rows", action="store_true", help="rank every row of the read table")
    parser.add_argument("--demo", action="store_true", help="run on made-up rows instead of files")
    parser.add_argument("--out", default=None, help="write the ranked rows with both students' scores to this parquet file")
    args = parser.parse_args(argv)

    if args.demo:
        fit_table, read_table = demo_tables()
    elif args.fit and args.read:
        fit_table, read_table = tables.read_columns(args.fit), tables.read_columns(args.read)
    else:
        parser.error("give --fit and --read, or --demo")
    if not args.all_rows:
        secs = _shared.account_and_time(read_table)[1]
        scored = _shared.in_period(secs, args.start or settings.TARGET_START, args.end or settings.TARGET_END)
        if not scored.any():
            print("no row of the read table falls in the scored month; set TARGET_START and TARGET_END in "
                  "settings.py, or pass --start and --end, or pass --all-rows")
            return None
        read_table = read_table.loc[scored]
    result = compare(fit_table, read_table, args.weight, args.numeric_cols, args.code_cols, args.rounds,
                     draws=args.draws)
    print(f"student inputs: {', '.join(result['inputs'])}")
    _shared.show("Students and teacher on the read rows (true labels)", result["table"])
    _shared.show("Soft-label student against hard-label student (paired bootstrap over accounts)", result["bootstrap"])
    if args.out:
        out = read_table[[c for c in (settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL)
                          if c in read_table.columns]].copy()
        out["student_hard"], out["student_soft"] = result["scores"][HARD], result["scores"][SOFT]
        _shared.save(out, args.out)
    return result


if __name__ == "__main__":
    main()
