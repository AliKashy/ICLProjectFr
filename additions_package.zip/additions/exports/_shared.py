"""Small helpers shared by the export files of this folder.

What this file does
-------------------
It holds the steps that several files of `additions/exports/` repeat: reading a setting at the
moment of the call, turning the account and time columns into the keys of the history engine,
reading the label, the score and the amount of a table as plain arrays, marking the rows of a
period, finding the vector columns of an export file, fitting a small logistic model and a
small tree model, turning a capture or a bootstrap result into one table line, and printing or
writing a table.

Why it exists
-------------
The export files answer different questions but read the same kind of table: one row per
transaction with its id, account, time, label, amount, the model's score and the model's
vector. Two details have to be the same in every file, or their columns stop being comparable.
A row without an account or without a time must enter no history, and a score must be read in
the kind it is stored in (probability or log-odds). Writing both once keeps the files short and
keeps them in step. The file carries no fraud logic of its own.

Where it goes
-------------
Nowhere by itself. The files of this folder import it. Everything here runs on the CPU, after
scoring, on tables of scores, vectors and export columns.

What to change for the pod
--------------------------
`STAGE1_PREFIX` names the columns of the stage-1 vector in an export file. `TREE_PARAMS` and
`TREE_ROUNDS` are the settings of the small tree models used by the comparisons and the
checks; a consumer's own settings belong here when its model is to be imitated. All column
names come from settings.py when a function runs, and every function also takes them as
arguments.

How to try it
-------------
    from additions.exports import _shared
    keys, secs = _shared.account_and_time(df)            # the two arrays the history engine takes
    probe = _shared.fit_logistic(x, y)                   # {"weights": [...], "bias": ...}
    logit = _shared.apply_logistic(x, probe)
    python -m pytest -q additions/tests/test_exports_shared.py
"""
import numpy as np
import pandas as pd
import xgboost as xgb
from scipy.special import expit
from sklearn.linear_model import LogisticRegression

from additions import settings
from additions.common import ranking, tables, timekeys
from additions.common.timekeys import MISSING_SECOND

# PLACEHOLDER: the prefix of the stage-1 (no-history) vector columns in an export file (s1_0, s1_1, ...).
# The columns of the vector that enters the head use settings.VECTOR_PREFIX.
STAGE1_PREFIX = "s1_"

# PLACEHOLDER: the settings of the small tree models, in the names XGBoost uses. Put a consumer's own
# settings here when its model is to be imitated. Every arm of a comparison gets the same settings,
# so no arm wins because it was tuned harder.
TREE_PARAMS = {
    "objective": "binary:logistic",   # also accepts targets between 0 and 1, which the soft labels need
    "max_depth": 4,
    "eta": 0.1,
    "min_child_weight": 5.0,
    "subsample": 0.8,
    "colsample_bytree": 0.8,
    "tree_method": "hist",
}

# PLACEHOLDER: the number of trees of those models.
TREE_ROUNDS = 200

# PLACEHOLDER: the solver of the small logistic fits. "newton-cholesky" is exact and fast when rows
# far outnumber inputs, and needs scikit-learn 1.2 or later; with an older version put "lbfgs" here.
LOGISTIC_SOLVER = "newton-cholesky"


# ----------------------------------------------------------------------------------------------
# settings and columns
# ----------------------------------------------------------------------------------------------

def pick(value, setting_name):
    """`value` when it is given, otherwise what settings.py holds under `setting_name`.

    The setting is read when the function runs, not when the module is imported, so an edit of
    settings.py (or a value set by a test) is seen by every later call.
    """
    return getattr(settings, setting_name) if value is None else value


def optional_column(df, name, what):
    """The column `name` of `df` as a Series, or None with one printed line when it is not available.

    A name of None (the setting is switched off) or a name the table does not have is not an
    error: the caller skips the part that needed the column. `what` names that part in the line.
    """
    if not name or name not in df.columns:
        reason = "no column is set" if not name else f"the table has no column '{name}'"
        print(f"note: {reason} for {what}; that part is skipped")
        return None
    return df[name]


def has_code(values, codes):
    """Yes/no per row: is the value one of `codes`? Shape [rows].

    Codes are written as text or numbers in settings ("00", 1). A column stored as numbers is
    compared as numbers, so the code "00" matches 0 and 1 matches 1.0. A column stored as text
    is compared as text with blanks stripped. A missing value never matches.
    """
    series = pd.Series(np.asarray(values))
    if pd.api.types.is_numeric_dtype(series.dtype):
        numbers = []
        for code in codes:
            try:
                numbers.append(float(code))
            except (TypeError, ValueError):
                pass                                   # a code such as "Y" cannot match a number
        return np.isin(series.to_numpy(dtype=np.float64), numbers)
    text = series.astype(str).str.strip()
    return (series.notna() & text.isin([str(code).strip() for code in codes])).to_numpy()


def account_and_time(df, account_col=None, time_col=None):
    """(keys, secs): one small integer per account and the whole second of every row, both [rows].

    These are the two arrays the history engine (`EarlierRows`) takes. A row without an account
    gets the missing-time marker: the engine then gives it no history and keeps it out of every
    other row's history, which is the only safe reading of a row that cannot be placed.
    """
    account = df[pick(account_col, "ACCOUNT_COL")]
    keys = timekeys.codes(account)
    secs = timekeys.seconds(df[pick(time_col, "TIME_COL")])
    return keys, np.where(account.isna().to_numpy(), MISSING_SECOND, secs)


def fraud_flags(df, label_col=None, positive_label=None):
    """1.0 on fraud rows and 0.0 on all other rows, shape [rows]."""
    return has_code(df[pick(label_col, "LABEL_COL")], (pick(positive_label, "POSITIVE_LABEL"),)).astype(np.float64)


def logits(df, score_col=None, score_kind=None):
    """The model's score as log-odds, shape [rows]. `score_kind` says what is stored."""
    values = df[pick(score_col, "SCORE_COL")].to_numpy(dtype=np.float64)
    return ranking.to_logit(values, pick(score_kind, "SCORE_KIND"))


def probabilities(df, score_col=None, score_kind=None):
    """The model's score as a probability between 0 and 1, shape [rows]."""
    values = df[pick(score_col, "SCORE_COL")].to_numpy(dtype=np.float64)
    return expit(values) if pick(score_kind, "SCORE_KIND") == "logit" else values


def amounts(df, amount_col=None):
    """Dollar amounts as floats [rows], or None with one printed line when there is no amount column."""
    column = optional_column(df, pick(amount_col, "AMOUNT_COL"), "the amount (dollar figures)")
    return None if column is None else pd.to_numeric(column, errors="coerce").to_numpy(dtype=np.float64)


def in_period(secs, start, end):
    """Yes/no per row: does the second fall in [start, end)? `start` and `end` are dates or text.

    The same function that floors the row times turns the two dates into seconds, so both sides
    are cut the same way. A row without a time is in no period.
    """
    low, high = timekeys.seconds(pd.to_datetime(pd.Series([start, end])))
    secs = np.asarray(secs)
    return (secs >= low) & (secs < high) & (secs != MISSING_SECOND)


def vector_columns(df, prefix):
    """The names of the columns `prefix` + a whole number (e_0, e_1, ...), in the order of the numbers."""
    found = []
    for name in df.columns:
        tail = str(name)[len(prefix):]
        if str(name).startswith(prefix) and tail.isdigit():
            found.append((int(tail), name))
    return [name for _, name in sorted(found)]


def numeric_matrix(df, columns):
    """The named columns as one float32 array [rows, len(columns)].

    Anything that is not a number becomes a missing value. The tree models read a missing value
    as "missing" and learn where to send it, so nothing is filled in here.
    """
    if not len(columns):
        return np.zeros((len(df), 0), dtype=np.float32)
    return np.column_stack([pd.to_numeric(df[c], errors="coerce").to_numpy(dtype=np.float32) for c in columns])


# ----------------------------------------------------------------------------------------------
# a small logistic model and a small tree model
# ----------------------------------------------------------------------------------------------

def fit_logistic(x, y, l2=1.0, what="a logistic fit"):
    """Fit log-odds(y) = x . weights + bias and return {"weights": [d numbers], "bias": number}.

    x      inputs, shape [rows, d] (or [rows] for one input)
    y      1 for the event, 0 otherwise, shape [rows]
    l2     strength of the pull of the weights toward zero; a tiny value (1e-6) means "no pull"
    what   a few words naming the fit, for the line printed when it cannot be made

    The inputs are put on a common scale before the fit, so that the pull toward zero treats
    every input alike; the scale is folded back into the weights, so the result applies to the
    inputs as they are. The bias is never pulled toward zero, so the mean fitted probability
    equals the event rate of the rows. Rows with a missing input are left out. When the rows
    hold only one of the two outcomes nothing can be fitted: one line is printed and None is
    returned, and the caller skips the column that needed the fit.
    """
    x = np.asarray(x, dtype=np.float64)
    x = x[:, None] if x.ndim == 1 else x
    y = np.asarray(y, dtype=np.float64)
    ok = np.isfinite(x).all(axis=1) & np.isfinite(y)
    events = int((y[ok] > 0.5).sum())
    if events == 0 or events == int(ok.sum()):
        print(f"note: the rows hold only one outcome for {what}; that part is skipped")
        return None
    mean, sd = x[ok].mean(axis=0), x[ok].std(axis=0)
    sd[sd == 0] = 1.0                                   # a constant input carries nothing; avoid 0 / 0
    # The tolerance is tight on purpose. Fraud is rare, and a fit that stops early can be off by a
    # few percent in the rate it gives, which matters when two fitted scores are subtracted.
    model = LogisticRegression(C=1.0 / l2, solver=LOGISTIC_SOLVER, tol=1e-8, max_iter=1000)
    model.fit((x[ok] - mean) / sd, y[ok] > 0.5)
    weights = model.coef_[0] / sd
    return {"weights": weights.tolist(), "bias": float(model.intercept_[0] - weights @ mean)}


def apply_logistic(x, fitted):
    """The log-odds x . weights + bias of a model from `fit_logistic`, shape [rows].

    A row with a missing input gets a missing value.
    """
    x = np.asarray(x, dtype=np.float64)
    x = x[:, None] if x.ndim == 1 else x
    return x @ np.asarray(fitted["weights"], dtype=np.float64) + float(fitted["bias"])


def fit_trees(x, target, base_margin=None, rounds=None, params=None, seed=0):
    """Train a small XGBoost model and return it.

    x             inputs, shape [rows, columns]; missing values are allowed
    target        the training target per row: 0 or 1, or any number between them
    base_margin   log-odds per row that the trees start from, shape [rows]; None starts from
                  the average rate. With a base margin the trees only learn corrections to it.
    rounds        number of trees (default TREE_ROUNDS); 0 gives a model that changes nothing
    params        XGBoost settings that replace those of TREE_PARAMS
    seed          the seed of the row and column sampling
    """
    settings_used = {**TREE_PARAMS, **(params or {}), "seed": int(seed)}
    data = xgb.DMatrix(np.asarray(x, dtype=np.float32), label=np.asarray(target, dtype=np.float32),
                       base_margin=None if base_margin is None else np.asarray(base_margin, dtype=np.float32))
    return xgb.train(settings_used, data, num_boost_round=TREE_ROUNDS if rounds is None else int(rounds))


def tree_margin(model, x, base_margin=None):
    """The log-odds a model from `fit_trees` gives to every row, shape [rows].

    `base_margin` must be given exactly when the model was trained with one; the answer is
    then the base margin plus the corrections of the trees.
    """
    data = xgb.DMatrix(np.asarray(x, dtype=np.float32),
                       base_margin=None if base_margin is None else np.asarray(base_margin, dtype=np.float32))
    return model.predict(data, output_margin=True).astype(np.float64)


# ----------------------------------------------------------------------------------------------
# small pieces for the tables
# ----------------------------------------------------------------------------------------------

def capture_line(name, labels, score_values, amount_values=None, per_mille=None, rounding=None):
    """One line of a results table: what the alert cut catches for one score column.

    Returns a dict with the name of the read, the sizes (rows, frauds, alerts), the frauds
    caught, the share of frauds caught (udr), the share of fraud dollars caught (vdr) and the
    average precision (ap). A figure that cannot be computed is NaN, so the column stays numeric.
    """
    c = ranking.capture(labels, score_values, amount_values, per_mille, rounding)
    ap = ranking.average_precision(labels, score_values)
    return {"read": name, "rows": c["rows"], "frauds": int(round(c["frauds"])), "alerts": c["alerts"],
            "caught": c["caught"], "udr": np.nan if c["udr"] is None else c["udr"],
            "vdr": np.nan if c["vdr"] is None else c["vdr"], "ap": np.nan if ap is None else ap}


def bootstrap_line(result, first="a", second="b"):
    """One table line from the dict that `bootstrap.paired_bootstrap` returns.

    `first` and `second` name the columns for the candidate's and the control's capture. The
    gain, its interval (low, high), the share of draws above zero and the number of draws keep
    their names. A figure the bootstrap could not give is NaN.
    """
    names = {"a": first, "b": second, "gain": "gain", "low": "low", "high": "high",
             "share_above_zero": "share_above_zero"}
    line = {new: np.nan if result[old] is None else float(result[old]) for old, new in names.items()}
    line["draws"] = result["draws"]
    return line


def summary(frame):
    """One line per numeric column: share of missing values, mean, smallest and largest value."""
    lines = []
    for name in frame.columns:
        if not pd.api.types.is_numeric_dtype(frame[name]):
            continue
        values = frame[name].to_numpy(dtype=np.float64)
        have = values[~np.isnan(values)]
        lines.append({"column": name, "missing": 1.0 - len(have) / max(len(values), 1),
                      "mean": have.mean() if len(have) else np.nan,
                      "min": have.min() if len(have) else np.nan, "max": have.max() if len(have) else np.nan})
    return pd.DataFrame(lines, columns=["column", "missing", "mean", "min", "max"])


def show(title, table, digits=4):
    """Print a title and a table as plain text.

    `table` is a DataFrame or a list of dicts. Decimal numbers are printed with `digits`
    decimals and missing numbers as a dash, so the output can be pasted into a note as is.
    """
    frame = table if isinstance(table, pd.DataFrame) else pd.DataFrame(table)
    print()
    print(title)
    if len(frame) == 0:
        print("  (no rows)")
        return
    print(frame.to_string(index=False, na_rep="-", float_format=lambda value: f"{value:.{digits}f}"))


def save(table, path, filesystem=None):
    """Write a table to a parquet file (an existing file is replaced) and print where it went."""
    tables.write_table(table, path, filesystem)
    print(f"wrote {len(table)} row(s) to {path}")
    return path
