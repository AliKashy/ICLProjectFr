"""Columns and tables for other models to consume.

bundle.py           the export bundle: named scores, supervised directions and account windows of
                    the score
consumer_margin.py  how a downstream tree model should take two scores: through the margin
feature_store.py    a table of export columns with a valid-from time, and the as-of lookup that
                    reads it
phat_writer.py      earlier-row scores as columns: the model's score on each of the account's latest
                    earlier rows
probe_suite.py      one vector, several targets: what the exported columns are worth to consumers
                    that do not exist yet
release_gates.py    two checks on export columns before they go to other models: a domain check and
                    a stability index per column
soft_labels.py      soft labels: another team's tree model learns from this model's score without
                    running it
stage1_hook.py      capturing the stage-1 vector and the head-input vector of a model with forward
                    hooks
_shared.py          small helpers shared by the export files of this folder
"""
