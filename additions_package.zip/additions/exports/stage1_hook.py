"""Capturing the stage-1 vector and the head-input vector of a model with forward hooks.

What this file does
-------------------
It reads two intermediate results out of a two-stage model while the model runs, without
editing the model's code or changing its output:

    the stage-1 vector    what the first stage makes of one transaction's own fields, before
                          any history is read (one vector per row)
    the head input        the vector that enters the linear head, after the second stage has
                          read the account's earlier rows (one vector per scored row)

`capture_vectors` is a context manager that installs one forward hook on the stage-1 encoder
and one on the head, hands back a `VectorTap` that collects what the hooks see, and removes
both hooks when the block ends. `collect` runs a model over batches and returns the two
vectors of every real row; `as_frame` turns them into named columns.

Why it exists
-------------
The head-input vector is what a scoring pass usually writes. The stage-1 vector is not written
anywhere, yet it is what makes the difference between "this transaction looks risky by itself"
and "this transaction looks risky because of what the account did before" visible. A probe on
the stage-1 vector gives a no-history score; the model's own score minus that probe is what
history added. Frauds come in runs on one account, so that difference is the part of the
signal a downstream tree model with single-row features lacks most. A hook gets the vector out
of any checkpoint there is: no retraining, no new forward code, no risk of a
changed model.

Where it goes
-------------
Stage 1, stage 2 and the head are untouched; the hooks sit on them during the scoring pass
that writes scores and vectors (exports). In the original code the stage-1 encoder is the
attribute `token_encoder` of `FTTransformerHierModel` and its summary token is position 0 of
the encoder output; the head is the attribute `head`, which receives one vector per position
when every transaction is scored and one vector per sequence otherwise. The captured vectors
feed `bundle.py` (the no-history probe).

What to change for the pod
--------------------------
`STAGE1_ATTR` and `HEAD_ATTR` (the attribute names of the two submodules; a dotted path such as
"encoder.stage1" also works), `SUMMARY_INDEX` (which token or tokens of the stage-1 output are
the summary of the transaction; None when the encoder already returns one vector per
transaction, as an encoder with several joined summary tokens usually does) and `MASK_KEY`
(the key of the batch that marks real positions). The column prefixes are
`_shared.STAGE1_PREFIX` and `settings.VECTOR_PREFIX`. One stage-1 call and one head call per
forward pass are assumed; a model that calls either more often needs its own pairing of the
collected entries. The second hook keeps the first input of whatever module `HEAD_ATTR` names.
In a model with a block between the history stage and the head (a re-read block, for
example), naming the head gives the vector after that block and naming the block gives the
vector before it; which of the two is exported should be written down with the export.

How to try it
-------------
    with capture_vectors(model) as tap:
        logits = model(batch)
        stage1, head_input = tap.rows(mask=batch["mask"])     # both [real rows, width]
    # or, for a whole scoring pass:
    got = collect(model, loader)
    columns = as_frame(got)                                   # s1_0, s1_1, ..., e_0, e_1, ...
The tests are in additions/tests/test_exports_stage1_hook.py.
"""
import contextlib

import numpy as np
import pandas as pd
import torch

from additions import settings
from additions.exports import _shared

# PLACEHOLDER: the attribute name of the stage-1 encoder inside the model (the module whose output
# holds one summary vector per transaction, computed from that transaction's fields alone).
STAGE1_ATTR = "token_encoder"

# PLACEHOLDER: the attribute name of the head (the module that turns the final vector into logits).
HEAD_ATTR = "head"

# PLACEHOLDER: where the summary sits in the stage-1 output.
#   - The module returns [rows, tokens, width] (one row per transaction, one entry per token, as
#     the original token encoder does): put the position of the summary token, 0 in the original
#     model. With several summary tokens put all their positions, for example (0, 1, 2); their
#     vectors are joined, in that order, into one vector of 3 x width per transaction.
#   - The module already returns one vector per transaction, as [rows, width] or as [batch,
#     positions, width] (the SummaryTokenEncoder of additions/model/summary_tokens.py returns
#     the joined summary tokens this way): put None.
# The two 3-D layouts cannot be told apart from the numbers alone, so this setting has to match
# the model. `VectorTap.rows` stops with a plain message when the row count shows a mismatch.
SUMMARY_INDEX = 0

# PLACEHOLDER: the key of the batch dict that marks real positions (True) against padding (False).
MASK_KEY = "mask"


def find_module(model, name):
    """The submodule of `model` called `name`; a dotted name walks down ("encoder.stage1").

    A name the model does not have raises an AttributeError that lists the model's direct
    submodules, which is usually enough to see what the name should have been.
    """
    module = model
    for part in str(name).split("."):
        if not hasattr(module, part):
            children = ", ".join(child for child, _ in model.named_children())
            raise AttributeError(f"the model has no submodule '{name}'; its direct submodules are: {children}")
        module = getattr(module, part)
    return module


class VectorTap:
    """Collects what the two hooks see, one entry per forward call.

    summary_index   position of the summary token in a stage-1 output of shape [rows, tokens, width],
                    or several positions (a tuple or list) whose vectors are joined in that order;
                    None keeps the stage-1 output as it is (see SUMMARY_INDEX)
    detach          True (the setting for an export) cuts the vectors loose from the graph and
                    moves them to the CPU. False keeps them as the model made them, so that a
                    loss can be built on them and its gradient reaches the model.

    After a forward call:
      stage1[-1]       tensor [rows of the call, width]: every position of every sequence, flattened
      head_input[-1]   tensor [batch, positions, width] or [batch, width]: exactly what the head received
    """

    def __init__(self, summary_index=SUMMARY_INDEX, detach=True):
        self.summary_index = summary_index
        self.detach = detach
        self.stage1 = []
        self.head_input = []

    def _keep(self, tensor):
        return tensor.detach().cpu() if self.detach else tensor

    def on_stage1(self, module, inputs, output):
        """The hook of the stage-1 encoder: keep the summary vector of every row."""
        vectors = output[0] if isinstance(output, (tuple, list)) else output
        if self.summary_index is not None and vectors.dim() == 3:
            if isinstance(self.summary_index, (int, np.integer)):
                vectors = vectors[:, int(self.summary_index)]
            else:
                # Several summary tokens: [rows, K, width] becomes one vector of K x width per row.
                vectors = vectors[:, [int(k) for k in self.summary_index]].flatten(1)
        self.stage1.append(self._keep(vectors))
        # A forward hook that returns nothing leaves the module's output as it is.

    def on_head(self, module, inputs, output):
        """The hook of the head: keep the vector the head was given."""
        self.head_input.append(self._keep(inputs[0]))

    def clear(self):
        """Forget everything collected so far (call it after each batch in a long scoring pass)."""
        self.stage1.clear()
        self.head_input.clear()

    def rows(self, mask=None, target_index=None, call=-1):
        """The two vectors of one forward call, lined up row by row.

        mask           yes/no [batch, positions]: real positions; padding is dropped. None keeps all.
                       With a head that scores one row per sequence it serves to check that
                       stage 1 saw batch x positions rows and to find the scored row.
        target_index   only for a head that scores one row per sequence: the position of that
                       row in each sequence, shape [batch]. None means the last real position
                       of each sequence according to `mask` (the last position when no mask is
                       given). The original single-target windows pad at the front and put the
                       scored row last, and windows padded at the end have it as their last
                       real row, so both are found. A model that scores another row needs
                       its position passed here.
        call           which forward call (default: the latest)

        A stage-1 shape that does not fit the head's shape raises a ValueError naming SUMMARY_INDEX.

        Returns (stage1, head_input), tensors of shape [rows, stage-1 width] and [rows, head
        width]; row i of one is the same transaction as row i of the other. The rows run
        sequence by sequence and, inside a sequence, position by position.
        """
        stage1, head = self.stage1[call], self.head_input[call]
        if head.dim() == 3:
            # The head scores every position. Stage 1 saw the same positions, either as one flat
            # list of rows or already as [batch, positions, width]; both fold into the same shape.
            n_rows = head.shape[0] * head.shape[1]
            per_row = stage1.dim() == 2 and stage1.shape[0] == n_rows
            per_position = stage1.dim() == 3 and tuple(stage1.shape[:2]) == tuple(head.shape[:2])
            if not (per_row or per_position):
                raise ValueError(
                    f"the stage-1 vectors have shape {tuple(stage1.shape)}, but the head scored {head.shape[0]} "
                    f"sequences of {head.shape[1]} positions ({n_rows} rows). SUMMARY_INDEX does not match the "
                    "model: use None when the stage-1 module already returns one vector per transaction "
                    "([rows, width] or [batch, positions, width]), and the position(s) of the summary token(s) "
                    "when it returns [rows, tokens, width].")
            stage1 = stage1.reshape(head.shape[0], head.shape[1], -1)
            if mask is None:
                return stage1.reshape(-1, stage1.shape[-1]), head.reshape(-1, head.shape[-1])
            keep = torch.as_tensor(mask).bool().to(head.device)
            return stage1[keep], head[keep]
        # The head scores one row per sequence. Its stage-1 vector is one position of the sequence.
        # Stage 1 must hold every position of every sequence: a flat list of rows, or [batch,
        # positions, width]. With a mask the number of positions is known and is checked too; without
        # one, a stage-1 output of one vector per sequence cannot be told from sequences of length one.
        n_seq = head.shape[0]
        positions = None if mask is None else int(torch.as_tensor(mask).shape[-1])
        flat_ok = stage1.dim() == 2 and stage1.shape[0] % max(n_seq, 1) == 0 and (
            positions is None or stage1.shape[0] == n_seq * positions)
        grid_ok = stage1.dim() == 3 and stage1.shape[0] == n_seq and (positions is None or stage1.shape[1] == positions)
        if not (flat_ok or grid_ok):
            raise ValueError(
                f"the stage-1 vectors have shape {tuple(stage1.shape)}, but the head scored {n_seq} sequences"
                + ("" if positions is None else f" of {positions} positions") + ". SUMMARY_INDEX does not match "
                "the model: use None when the stage-1 module already returns one vector per transaction "
                "([rows, width] or [batch, positions, width]), and the position(s) of the summary token(s) "
                "when it returns [rows, tokens, width].")
        per_sequence = stage1.reshape(n_seq, -1, stage1.shape[-1])
        if target_index is None and mask is None:
            return per_sequence[:, -1], head
        if target_index is None:
            # The last real position of each sequence: the highest position at which the mask is True.
            # A sequence with no real position at all falls back to its last position.
            real = torch.as_tensor(mask).bool()
            places = torch.arange(real.shape[-1], device=real.device).expand_as(real)
            last_real = (places * real).max(-1).values
            target_index = torch.where(real.any(-1), last_real, torch.full_like(last_real, real.shape[-1] - 1))
        index = torch.as_tensor(target_index).long().to(per_sequence.device)
        return per_sequence[torch.arange(head.shape[0], device=per_sequence.device), index], head


@contextlib.contextmanager
def capture_vectors(model, stage1_attr=None, head_attr=None, summary_index=SUMMARY_INDEX, detach=True):
    """Install the two hooks, hand back a `VectorTap`, and remove the hooks when the block ends.

    model         any torch module that holds a stage-1 encoder and a head as submodules
    stage1_attr   name of the stage-1 encoder (default STAGE1_ATTR)
    head_attr     name of the head (default HEAD_ATTR)
    summary_index, detach   passed to `VectorTap`

    The hooks only read. The model's parameters, its output and its training mode stay as they
    are, and the hooks are removed even when the block ends with an error.
    """
    # Both submodules are found before any hook is installed, so a wrong name leaves no hook behind.
    stage1 = find_module(model, STAGE1_ATTR if stage1_attr is None else stage1_attr)
    head = find_module(model, HEAD_ATTR if head_attr is None else head_attr)
    tap = VectorTap(summary_index, detach)
    handles = [stage1.register_forward_hook(tap.on_stage1), head.register_forward_hook(tap.on_head)]
    try:
        yield tap
    finally:
        for handle in handles:
            handle.remove()


def collect(model, batches, forward=None, mask_key=MASK_KEY, stage1_attr=None, head_attr=None,
            summary_index=SUMMARY_INDEX):
    """Run a model over batches and return the vectors of every real row as arrays.

    model      the model; it is put in evaluation mode for the pass and set back afterwards
    batches    an iterable of batches (for example a DataLoader)
    forward    how one batch is run: a function forward(model, batch); default model(batch)
    mask_key   key of the batch dict that marks real positions; None or an absent key keeps all

    Returns a dict of float32 arrays:
      "stage1"       [rows, stage-1 width]   the no-history vector of every row
      "head_input"   [rows, head width]      the vector that entered the head
      "output"       [rows, ...]             what the model returned for the same rows
    The rows are in the order of the batches. Transaction ids have to be gathered by the caller
    in the same order (same batches, same mask), so that the columns can be joined to raw rows.
    With a two-class head the fraud logit is output[:, 1] - output[:, 0]. The whole result is
    held in memory; for a long pass, use `capture_vectors` directly and write after every batch.
    """
    forward = (lambda m, batch: m(batch)) if forward is None else forward
    was_training = model.training
    model.eval()                                   # dropout off: an export must be repeatable
    parts = {"stage1": [], "head_input": [], "output": []}
    try:
        with torch.no_grad(), capture_vectors(model, stage1_attr, head_attr, summary_index) as tap:
            for batch in batches:
                output = forward(model, batch).detach().cpu()
                mask = batch.get(mask_key) if mask_key and isinstance(batch, dict) else None
                stage1, head_input = tap.rows(mask=mask)
                if mask is not None and output.dim() == 3:
                    output = output[torch.as_tensor(mask).bool().cpu()]
                elif output.dim() == 3:
                    output = output.reshape(-1, output.shape[-1])
                parts["stage1"].append(stage1.numpy())
                parts["head_input"].append(head_input.numpy())
                parts["output"].append(output.numpy())
                tap.clear()                        # nothing is kept from one batch to the next
    finally:
        model.train(was_training)
    return {name: np.concatenate(chunks).astype(np.float32) if chunks else np.zeros((0, 0), dtype=np.float32)
            for name, chunks in parts.items()}


def as_frame(collected, stage1_prefix=None, vector_prefix=None):
    """Name the two vectors as columns: one DataFrame [rows, stage-1 width + head width].

    collected       what `collect` returned (or any dict with "stage1" and "head_input" arrays)
    stage1_prefix   prefix of the stage-1 columns (default _shared.STAGE1_PREFIX: s1_0, s1_1, ...)
    vector_prefix   prefix of the head-input columns (default settings.VECTOR_PREFIX: e_0, e_1, ...)
    """
    stage1_prefix = _shared.STAGE1_PREFIX if stage1_prefix is None else stage1_prefix
    vector_prefix = settings.VECTOR_PREFIX if vector_prefix is None else vector_prefix
    columns = {}
    for prefix, values in ((stage1_prefix, collected["stage1"]), (vector_prefix, collected["head_input"])):
        values = np.asarray(values)
        for j in range(values.shape[1] if values.ndim == 2 else 0):
            columns[f"{prefix}{j}"] = values[:, j]
    return pd.DataFrame(columns)
