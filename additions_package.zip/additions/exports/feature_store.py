"""A table of export columns with a valid-from time, and the as-of lookup that reads it.

What this file does
-------------------
It stores the export columns of every transaction (the named scores and windows of
bundle.py, the earlier-row scores of phat_writer.py, or any other per-row columns) in one
table keyed by transaction id, with the account and a valid-from time:

    fi_transaction_id   the transaction the values were computed on (settings.ID_COL)
    account             the account of that transaction (settings.ACCOUNT_COL)
    valid_from          the moment the values may be used: the transaction time plus a lag
    <export columns>    one column per exported value

and it answers the question another model asks of such a table: "for this account at this
moment, what were the latest values?" The as-of lookup returns, for a query (account, time),
the store row of that account with the latest valid-from second strictly earlier than the
query second. A plain-text JSON manifest written beside the table names the model, the version,
the columns and the lookup rule.

Why it exists
-------------
Frauds come in runs on one account, so the most useful thing another model can know about an
account is what this model last said about it. A model that does not see a card transaction
(a login check, a payment to a new payee, a case queue) can read the account's latest scores
and windows from the store at its own moment in time. Two things decide whether that reading
is fair. First, the time rule: the query must see only rows of strictly earlier seconds, the
same rule every history feature of this package keeps, so that a value computed on the query's
own transaction (or on one in the same second, whose order cannot be trusted) never answers the
query. Second, the valid-from time: values are not available the instant a transaction happens;
the lag says how long scoring and writing take, and a lookup that ignores it would read values
before they exist. Keeping both rules in one tested function is safer than letting every
consumer write its own join.

Where it goes
-------------
In the exports, after the export columns are built: bundle.py or phat_writer.py write per-row
columns, `build_store` turns them into the store, `write_store` saves it with its manifest,
and a consumer calls `asof_lookup` with its own (account, time) pairs. Nothing in the network
changes. A served version keeps, per account, only the latest row; the full table is what lets
a consumer build training rows at any past moment.

What to change for the pod
--------------------------
settings.py: ID_COL, ACCOUNT_COL, TIME_COL, ORDER_COL (orders rows inside one second), LABEL_COL
(never stored). The constants below: `VALID_FROM_COL` (the name of the valid-from column),
`LAG_SECONDS` (how long after a transaction its values can be read), `STORE_VERSION` and
`MODEL_NAME` (plain text in the manifest), `MANIFEST_SUFFIX`. The manifest is written with an
ordinary local file open; with remote storage (settings.FILESYSTEM) that line is changed to the
storage's own way of writing a small text file.

How to try it
-------------
    python additions/exports/feature_store.py --demo
    python additions/exports/feature_store.py --table bundle.parquet --version v1 --out store.parquet
    python additions/exports/feature_store.py --store store.parquet --queries queries.parquet --out answers.parquet
or, from Python:
    store = build_store(bundle_columns)
    write_store(store, "store.parquet", version="v1")
    answers = asof_lookup(store, queries)
The tests are in additions/tests/test_exports_feature_store.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse
import json

import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, tables, timekeys
from additions.common.history import EarlierRows
from additions.common.timekeys import MISSING_SECOND
from additions.exports import _shared

# PLACEHOLDER: the name of the valid-from column in the store.
VALID_FROM_COL = "valid_from"

# PLACEHOLDER: seconds between a transaction and the moment its export values can be read (the time
# scoring and writing take in serving). 0 means "from the next second on".
LAG_SECONDS = 0

# PLACEHOLDER: the version text written in the manifest.
STORE_VERSION = "v0"

# PLACEHOLDER: the model name written in the manifest.
MODEL_NAME = "PLACEHOLDER-model-name"

# PLACEHOLDER: what is added to the table's file name (without its extension) to name the manifest.
MANIFEST_SUFFIX = ".manifest.json"

# The names of the two columns `asof_lookup` adds beside the looked-up values: which store row
# answered the query and from when its values were valid.
ASOF_ID_COL = "asof_id"
ASOF_VALID_FROM_COL = "asof_valid_from"

# The lookup rule, written into the manifest in words so that a consumer reads it with the table.
LOOKUP_RULE = ("for a query (account, time): the store row of the same account with the latest valid-from second "
               "strictly earlier than the query second; rows of one second in table order; "
               "none when there is no such row")


def export_columns(df, columns=None, id_col=None, account_col=None, time_col=None, label_col=None,
                   order_col=None):
    """The names of the columns to store.

    With `columns` given, those of them that the table has (absent ones are named in one printed
    line). Without, every column except the keys, the time, the sequence number, the file number
    and the label. The label is never stored even when asked for: a store is read by models at
    serving time, and a label is not known then.
    """
    label_col = _shared.pick(label_col, "LABEL_COL")
    if columns is None:
        skip = {_shared.pick(id_col, "ID_COL"), _shared.pick(account_col, "ACCOUNT_COL"),
                _shared.pick(time_col, "TIME_COL"), _shared.pick(order_col, "ORDER_COL"), "_file", VALID_FROM_COL}
        columns = [c for c in df.columns if c not in skip]
    missing = [c for c in columns if c not in df.columns]
    if missing:
        print(f"note: the table has no column(s) {missing}; they are not stored")
    if label_col in columns:
        print(f"note: the label column '{label_col}' is not stored; a label is not known at serving time")
    return [c for c in columns if c in df.columns and c != label_col]


def build_store(df, columns=None, lag_seconds=None, id_col=None, account_col=None, time_col=None,
                label_col=None, order_col=None):
    """The store table: id, account, valid-from time and the export columns, one row per transaction.

    df            per-row export columns with the id, account and time of every row, shape [rows, ...]
    columns       the export columns to keep (default: see `export_columns`)
    lag_seconds   seconds added to the transaction time to give the valid-from time (default LAG_SECONDS)

    Returns a DataFrame with [rows] rows, sorted by account, valid-from time and, inside one second,
    by the sequence number when the table has one. That order matters: when several rows of an
    account share the latest earlier second, the lookup answers with the last of them in table
    order. The valid-from column holds whole seconds as datetimes; a row without a time has no
    valid-from time and never answers a query.
    """
    id_col = _shared.pick(id_col, "ID_COL")
    account_col = _shared.pick(account_col, "ACCOUNT_COL")
    time_col = _shared.pick(time_col, "TIME_COL")
    order_col = _shared.pick(order_col, "ORDER_COL")
    lag = int(LAG_SECONDS if lag_seconds is None else lag_seconds)
    keep = export_columns(df, columns, id_col, account_col, time_col, label_col, order_col)
    secs = timekeys.seconds(df[time_col])
    valid = np.where(secs == MISSING_SECOND, MISSING_SECOND, secs + lag)
    # Sort so that the table order is the order inside one second: the sequence number when there is
    # one, else the order the rows came in. A stable sort keeps the incoming order for equal values.
    tie = df[order_col].to_numpy() if order_col in df.columns else np.arange(len(df))
    order = np.lexsort((pd.factorize(pd.Series(tie), sort=True)[0], valid, timekeys.codes(df[account_col])))
    stamps = pd.to_datetime(pd.Series(np.where(valid == MISSING_SECOND, np.nan, valid.astype(np.float64))), unit="s")
    out = pd.DataFrame({
        id_col: df[id_col].to_numpy()[order] if id_col in df.columns else order,
        account_col: df[account_col].to_numpy()[order],
        VALID_FROM_COL: stamps.to_numpy()[order],
    })
    for name in keep:
        out[name] = df[name].to_numpy()[order]
    return out


def asof_lookup(store, queries, columns=None, id_col=None, account_col=None, time_col=None, valid_from_col=None):
    """For every query (account, time), the store's latest values of that account from strictly earlier seconds.

    store            a table from `build_store` (or any table with id, account and valid-from columns)
    queries          a table with an account column and a time column, shape [queries, ...]
    columns          the store columns to return (default: every column except the keys)
    valid_from_col   the store's valid-from column (default VALID_FROM_COL)

    Returns a DataFrame with the index of `queries` and the columns ASOF_ID_COL (the id of the
    store row that answered), ASOF_VALID_FROM_COL and the requested columns. A query with no
    earlier store row of its account, without an account or without a time gets missing values.

    Time rule: a store row answers a query only when its valid-from second is strictly earlier
    than the query second. A store row of the query's own second is never used, because inside
    one second the order of two events cannot be trusted; this also keeps a transaction's own
    values from answering a query made at that transaction. Rows of other accounts never answer.
    """
    id_col = _shared.pick(id_col, "ID_COL")
    account_col = _shared.pick(account_col, "ACCOUNT_COL")
    time_col = _shared.pick(time_col, "TIME_COL")
    valid_from_col = valid_from_col or VALID_FROM_COL
    if columns is None:
        columns = [c for c in store.columns if c not in (id_col, account_col, valid_from_col)]
    n_store, n_query = len(store), len(queries)
    # Store rows and queries go into one history engine: store rows first (in table order, which is
    # the order inside a second), then queries. Both keys are coded together, so the same account
    # gets the same code on both sides.
    account = pd.concat([store[account_col], queries[account_col]], ignore_index=True)
    keys = timekeys.codes(account)
    secs = np.concatenate([timekeys.seconds(store[valid_from_col]), timekeys.seconds(queries[time_col])])
    secs = np.where(account.isna().to_numpy(), MISSING_SECOND, secs)     # a row without an account is never placed
    is_store = np.arange(n_store + n_query) < n_store
    engine = EarlierRows(keys, secs)
    # The latest strictly earlier store row of every query, as a store position (or -1). Queries are
    # never history of anything because only store rows are allowed to count.
    position = engine.last(np.arange(n_store + n_query), where=is_store, default=-1)[n_store:].astype(np.int64)
    found = position >= 0
    take = np.maximum(position, 0)
    out = pd.DataFrame(index=queries.index)
    for name, source in [(ASOF_ID_COL, id_col), (ASOF_VALID_FROM_COL, valid_from_col)] + [(c, c) for c in columns]:
        if source not in store.columns:
            print(f"note: the store has no column '{source}'; it is not returned")
            continue
        values = store[source].iloc[take].reset_index(drop=True) if n_store else pd.Series([np.nan] * n_query)
        if pd.api.types.is_integer_dtype(values.dtype):
            # A nullable whole-number column keeps long ids exact where some queries find nothing;
            # a plain float column would round ids of more than 15 digits.
            values = values.astype("Int64")
        out[name] = values.where(pd.Series(found)).set_axis(queries.index)
    return out


def manifest_path(path):
    """Where the manifest of the table at `path` goes: beside it, with MANIFEST_SUFFIX in place of the extension."""
    path = str(path)
    stem = path[:-len(".parquet")] if path.endswith(".parquet") else path
    return stem + MANIFEST_SUFFIX


def make_manifest(store, version=None, model_name=None, lag_seconds=None, id_col=None, account_col=None,
                  valid_from_col=None, extra=None):
    """A plain dict describing the store: model, version, keys, columns, size, time span and lookup rule.

    `extra` is any further dict of plain values to add (for example the results of release_gates.py).
    Nothing in the manifest is checked when the store is read; it is there to be read by people.
    """
    id_col = _shared.pick(id_col, "ID_COL")
    account_col = _shared.pick(account_col, "ACCOUNT_COL")
    valid_from_col = valid_from_col or VALID_FROM_COL
    keys = [id_col, account_col, valid_from_col]
    if valid_from_col in store.columns:
        stamps = pd.to_datetime(store[valid_from_col])
    else:
        stamps = pd.Series([], dtype="datetime64[ns]")
    manifest = {
        "model_name": str(MODEL_NAME if model_name is None else model_name),
        "version": str(STORE_VERSION if version is None else version),
        "key_columns": {"id": id_col, "account": account_col, "valid_from": valid_from_col},
        "columns": {c: str(store[c].dtype) for c in store.columns if c not in keys},
        "rows": int(len(store)),
        "accounts": int(store[account_col].nunique()) if account_col in store.columns else 0,
        "valid_from_first": None if stamps.isna().all() else str(stamps.min()),
        "valid_from_last": None if stamps.isna().all() else str(stamps.max()),
        "lag_seconds": int(LAG_SECONDS if lag_seconds is None else lag_seconds),
        "lookup_rule": LOOKUP_RULE,
    }
    manifest.update(extra or {})
    return manifest


def write_store(store, path, version=None, model_name=None, lag_seconds=None, extra=None, filesystem=None):
    """Write the store to a parquet file and its manifest beside it. Existing files are replaced.

    Returns (table path, manifest path).
    """
    _shared.save(store, path, filesystem)
    manifest = make_manifest(store, version, model_name, lag_seconds, extra=extra)
    target = manifest_path(path)
    # PLACEHOLDER: with remote storage, write this small text file the way that storage writes files.
    with open(target, "w", encoding="ascii") as handle:
        json.dump(manifest, handle, indent=2, default=str)
    print(f"wrote the manifest to {target}")
    return path, target


def read_store(path, filesystem=None):
    """Read a store and, when it exists, its manifest. Returns (table, manifest dict or None)."""
    table = tables.read_columns(path, filesystem=filesystem)
    target = manifest_path(path)
    if not Path(target).exists():
        print(f"note: no manifest at {target}")
        return table, None
    with open(target, "r", encoding="ascii") as handle:
        return table, json.load(handle)


def demo_table(n_accounts=150, seed=4):
    """Made-up export columns: the score, two vector columns and the account's earlier maximum score."""
    df = synthetic.make_vectors(synthetic.make_scores(synthetic.make_transactions(n_accounts=n_accounts, seed=seed),
                                                      seed=seed), dim=2, seed=seed)
    keys, secs = _shared.account_and_time(df)
    df["w_max_24h"] = EarlierRows(keys, secs).maximum(_shared.logits(df), window=86_400)
    return df[[settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL, settings.ORDER_COL, settings.LABEL_COL,
               settings.SCORE_COL, f"{settings.VECTOR_PREFIX}0", f"{settings.VECTOR_PREFIX}1", "w_max_24h"]]


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(
        description="Build a store of export columns, or look values up in one as of a time.")
    parser.add_argument("--table", default=None, help="parquet file of per-row export columns to turn into a store")
    parser.add_argument("--columns", nargs="*", default=None,
                        help="export columns to store (default: all but keys and label)")
    parser.add_argument("--lag-seconds", type=int, default=None,
                        help="seconds until values can be read (default LAG_SECONDS)")
    parser.add_argument("--version", default=None, help="version text for the manifest")
    parser.add_argument("--model-name", default=None, help="model name for the manifest")
    parser.add_argument("--store", default=None, help="an existing store to look values up in")
    parser.add_argument("--queries", default=None, help="parquet file with account and time columns to look up")
    parser.add_argument("--demo", action="store_true", help="build a store from made-up rows and look up a few queries")
    parser.add_argument("--out", default=None,
                        help="write the store (with its manifest) or the answers to this parquet file")
    args = parser.parse_args(argv)

    if args.store:
        store, manifest = read_store(args.store)
        if manifest:
            print(f"store of {manifest.get('model_name')} version {manifest.get('version')}: "
                  f"{manifest.get('rows')} rows")
        if not args.queries:
            parser.error("give --queries with --store")
        queries = tables.read_columns(args.queries)
        answers = asof_lookup(store, queries)
        print(f"{int(answers[ASOF_ID_COL].notna().sum())} of {len(answers)} queries found an earlier row")
        _shared.show("Looked-up values", _shared.summary(answers.drop(columns=[ASOF_ID_COL])))
        if args.out:
            _shared.save(answers, args.out)
        return answers

    if args.demo:
        table = demo_table()
    elif args.table:
        table = tables.read_columns(args.table)
    else:
        parser.error("give --table, --store with --queries, or --demo")
    store = build_store(table, args.columns, args.lag_seconds)
    manifest = make_manifest(store, args.version, args.model_name, args.lag_seconds)
    print(f"store of {manifest['model_name']} version {manifest['version']}: {manifest['rows']} rows, "
          f"{manifest['accounts']} accounts, "
          f"valid from {manifest['valid_from_first']} to {manifest['valid_from_last']}")
    _shared.show("Stored columns", _shared.summary(store.drop(columns=[settings.ID_COL])))
    if args.demo:
        # A few queries one hour after made-up transactions show the lookup at work.
        queries = table[[settings.ACCOUNT_COL, settings.TIME_COL]].iloc[::400].copy()
        queries[settings.TIME_COL] = pd.to_datetime(queries[settings.TIME_COL]) + pd.Timedelta(hours=1)
        answers = asof_lookup(store, queries)
        _shared.show("Demo lookups, one hour after a transaction", pd.concat([queries, answers], axis=1).head(10))
    if args.out:
        write_store(store, args.out, args.version, args.model_name, args.lag_seconds)
    return store


if __name__ == "__main__":
    main()
