"""The export bundle: named scores, supervised directions and account windows of the score.

What this file does
-------------------
It turns what the model writes for every transaction (its fraud score, the vector that enters
the head and the stage-1 vector) into up to 29 named columns for other models to consume.

Seven scores (a name with s_ is a log-odds value, a name with p_ is a probability):
    s_full       the model's fraud logit, with history
    s_txn        the logit of a logistic probe on the stage-1 vector: the row judged by its own fields
    s_ctx        s_full minus s_txn, both as log-odds of fraud on the same rows: what history added
    p_acct_24h   a probe on the vector: will another fraud follow on this account within 24 hours?
    p_acct_7d    the same within 7 days
    s_val        s_full + k * log(1 + amount): a ranking for the dollar measure
    p_decline    a probe on the vector: does the bank decline this row? (optional)
Eight supervised directions, dir_1 to dir_8: the directions of the vector that carry the most
    fraud signal beyond the score, found by partial least squares on the residual of the label
    after the score, each with unit spread, ordered by how much of that residual they explain.
Fourteen windows of s_full over the account's strictly earlier seconds:
    w_max_1h, w_max_24h, w_max_7d, w_max_30d      the largest earlier score in the window
    w_mean_1h, w_mean_24h, w_mean_7d, w_mean_30d  the mean earlier score in the window
    w_last               the score in the latest earlier second (the highest, if rows share it)
    w_secs_since_alert   seconds since the last earlier row at or above the alert cut
    w_alerts_30d         number of such rows in 30 days
    w_minus_mean_30d     s_full minus w_mean_30d
    w_cos_30d            cosine of the row's vector to the account's mean vector of 30 days
    w_rows_30d           number of earlier rows in 30 days

`fit_bundle` fits the probes, the directions and the alert cut on one block of rows and returns
plain numbers. `build_bundle` applies them to any table and returns the columns.

Why it exists
-------------
Tree models split on one column at a time, so they can only use what lies along an axis. The
axes of the model's vector are arbitrary: the fraud signal lies across many of them, and a
retrain can rotate them, so column 7 of one model means nothing in the next. A named score is
an axis by construction and keeps its meaning at every retrain: "the fraud logit", "the logit
without history", "the chance of another fraud within a day". The directions put what the
vector still holds beyond the score on a few ordered axes instead of all of them.

The windows carry the run. Frauds come in runs on one account, so most frauds follow an
earlier fraud of that account, but fraud labels arrive weeks after the transaction, so inside
a run no label exists yet. The model's own earlier scores exist at once. "The highest score on
this account in the last 24 hours" tells a downstream model that the account is in a run,
without any label.

The two look-ahead probes and the decline probe have targets that are not known when a row is
scored (later frauds of the account, the bank's decision on the row). Those targets are used
to FIT the probes only, on a separate block of rows. What is exported is the probe's reading of
the vector, which was computed from the past alone. The probes are outputs: they are never
inputs to the network, and no label of any row enters any column built here.

Where it goes
-------------
After scoring (scores and vectors), before a second stage or another team's model (exports).
Nothing in the network changes. The stage-1 vector is not written by a usual scoring pass;
stage1_hook.py captures it (in the original model it is the summary token of `token_encoder`
in `FTTransformerHierModel.forward`). A served version needs, per account, the time, score and
vector of the rows of the last 30 days: every window reads at most that far back.

What to change for the pod
--------------------------
settings.py: ID_COL, ACCOUNT_COL, TIME_COL, LABEL_COL, POSITIVE_LABEL, AMOUNT_COL, SCORE_COL,
SCORE_KIND, VECTOR_PREFIX, REASON_COL and APPROVED_REASONS (for p_decline; None skips it) and
OUTSORT_PER_MILLE. `_shared.STAGE1_PREFIX` names the stage-1 columns; without them s_txn and
s_ctx are skipped. `VALUE_TILT` is k; reads/amount_tilt.py measures which k suits the data.
The block the probes and directions are fitted on must hold accounts that neither the encoder
nor the consumer trains on, and rows old enough for their labels to have arrived; the last
7 days of the block are left out of the look-ahead fits because their future is cut off. The
table given to `build_bundle` must hold whole account histories (the month before the scored
month included), with scores from a model that did not train on those accounts. After a
retrain the first 30 days of windows would mix scores of two models; score those days again
with the new model first. The directions are refitted at every retrain: dir_1 stays "the most
useful direction", not the same direction.

How to try it
-------------
    python additions/exports/bundle.py --demo
    python additions/exports/bundle.py --fit-export probe_block.parquet --save-fitted bundle_fit.json \\
        --export scored_block.parquet --out bundle.parquet
or, from Python:
    fitted = fit_bundle(probe_block)
    columns = build_bundle(scored_block, fitted)
The tests are in additions/tests/test_exports_bundle.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse
import json

import numpy as np
import pandas as pd
from scipy.special import expit

from additions import settings
from additions.common import ranking, synthetic, tables, timekeys
from additions.common.history import EarlierRows, later_rows
from additions.common.timekeys import MISSING_SECOND
from additions.exports import _shared

# The seven scores, in the order in which they are written.
SCORE_COLUMNS = ("s_full", "s_txn", "s_ctx", "p_acct_24h", "p_acct_7d", "s_val", "p_decline")

# How many supervised directions are kept.
N_DIRECTIONS = 8

# The windows of the maxima and the means, as (label, seconds). The longest one is also the horizon
# of every other window column, so a store of the last 30 days per account can serve all fourteen.
WINDOWS = (("1h", 3_600), ("24h", 86_400), ("7d", 7 * 86_400), ("30d", 30 * 86_400))
HORIZON = WINDOWS[-1][1]

# The look-ahead probes, as (column, seconds ahead). Their targets look forward in time and are
# used for fitting only.
AHEAD = (("p_acct_24h", 86_400), ("p_acct_7d", 7 * 86_400))

# PLACEHOLDER: k of the value score s_val = s_full + k * log(1 + amount). With a logit that is a true
# log-odds value, 1.0 is close to ranking by expected fraud dollars; put the k chosen for the data here.
VALUE_TILT = 1.0

# PLACEHOLDER: the pull toward zero of the probe weights (larger means smaller weights).
PROBE_L2 = 1.0

# The number type of the bundle columns: half the size of float64 and precise enough for scores.
FLOAT = np.float32


def direction_columns(n_directions=N_DIRECTIONS):
    """The names dir_1 .. dir_n of the supervised directions."""
    return [f"dir_{k}" for k in range(1, int(n_directions) + 1)]


def window_columns():
    """The names of the fourteen window columns, in the order in which they are written."""
    return ([f"w_max_{label}" for label, _ in WINDOWS] + [f"w_mean_{label}" for label, _ in WINDOWS]
            + ["w_last", "w_secs_since_alert", "w_alerts_30d", "w_minus_mean_30d", "w_cos_30d", "w_rows_30d"])


def bundle_columns(n_directions=N_DIRECTIONS):
    """All bundle column names: 7 scores, the directions, 14 windows (29 with 8 directions)."""
    return list(SCORE_COLUMNS) + direction_columns(n_directions) + window_columns()


# ----------------------------------------------------------------------------------------------
# the supervised directions
# ----------------------------------------------------------------------------------------------

def fit_directions(z, residual, n_directions=N_DIRECTIONS, chunk=200_000):
    """Partial least squares of the standardised vector against what the score leaves unexplained.

    z          the vector, shape [rows, d], every column centred and scaled on these rows
    residual   shape [rows]: the label minus the probability the score already gives
    chunk      rows per block when the sums are accumulated

    Returns (rotation, gain): `rotation` has shape [d, k] and `z @ rotation` are the k directions;
    `gain` has shape [k] and holds the share of the residual's spread each direction explains.
    The directions are uncorrelated with each other on these rows, have unit spread, point the
    way of more fraud (a higher value means more fraud than the score says) and are ordered by
    gain, largest first. k is `n_directions`, or fewer when the vector has fewer independent
    columns.

    How it works. The first direction is the weighting of the columns whose values move most
    together with the residual. Its part is then taken out of the columns, and the next
    direction is found in what is left, so each direction adds something the earlier ones do
    not have. Only two sums over the rows are needed, the products of the columns with each
    other [d, d] and with the residual [d]; everything after that works on those small arrays,
    which is why millions of rows cost one pass.
    """
    z = np.asarray(z)
    residual = np.asarray(residual, dtype=np.float64)
    residual = residual - residual.mean() if len(residual) else residual
    n, d = z.shape
    cross, pull = np.zeros((d, d)), np.zeros(d)
    # The loop runs over blocks of rows, never over single rows: each block is turned into float64
    # for exact sums, and a block at a time keeps that copy small.
    for start in range(0, n, int(chunk)):
        block = np.asarray(z[start:start + chunk], dtype=np.float64)
        cross += block.T @ block
        pull += block.T @ residual[start:start + chunk]
    spread = float(residual @ residual)
    first_strength = float(np.linalg.norm(pull))
    weights, loadings, sizes, gains = [], [], [], []
    for _ in range(min(int(n_directions), d)):
        strength = float(np.linalg.norm(pull))
        if strength <= 1e-10 * max(first_strength, 1e-300):
            break                                         # nothing is left that moves with the residual
        w = pull / strength                               # the weighting of the columns
        cw = cross @ w
        size = float(w @ cw)                              # sum of squares of this direction over the rows
        if size <= 1e-12 * n:
            break
        p = cw / size                                     # how each column moves with the direction
        weights.append(w)
        loadings.append(p)
        sizes.append(size)
        gains.append(strength * strength / size / spread if spread > 0 else 0.0)
        cross = cross - size * np.outer(p, p)             # take the direction out of the columns ...
        pull = pull - p * strength                        # ... and out of their products with the residual
    if not weights:
        return np.zeros((d, 0)), np.zeros(0)
    w_all, p_all = np.array(weights).T, np.array(loadings).T                 # both [d, k]
    # Each weighting was found on columns that had earlier directions taken out. This step turns
    # them into weightings of the columns as they are, so that new rows need one product only.
    rotation = w_all @ np.linalg.inv(p_all.T @ w_all)
    rotation = rotation / np.sqrt(np.array(sizes) / n)                        # unit spread on these rows
    order = np.argsort(-np.array(gains), kind="stable")                       # most useful first
    return rotation[:, order], np.array(gains)[order]


# ----------------------------------------------------------------------------------------------
# the account windows
# ----------------------------------------------------------------------------------------------

def _highest_in_second(keys, secs, values):
    """For every row, the largest value among the rows of its account and second. Shape [rows].

    Rows of one account in one second cannot be put in order, so "the last score" of an account
    is taken per second: every row of a second carries the highest score of that second.
    """
    if not len(values):
        return np.zeros(0)
    second = timekeys.codes(keys, secs)                   # one code per (account, second)
    order = np.argsort(second, kind="stable")
    starts = np.flatnonzero(np.r_[True, second[order][1:] != second[order][:-1]])
    top = np.fmax.reduceat(np.asarray(values, dtype=np.float64)[order], starts)   # fmax skips missing scores
    out = np.empty(len(values))
    out[order] = np.repeat(top, np.diff(np.r_[starts, len(values)]))
    return out


def _cosine_to_earlier_mean(earlier, z, window):
    """Cosine between each row's vector and the mean vector of the account's earlier rows. Shape [rows].

    The mean and the sum over the window differ by a positive factor only, and a cosine ignores
    such a factor, so the sum is used. The loop runs over the columns of the vector (tens of
    steps, each over all rows at once), never over rows; it keeps the memory at a few arrays of
    one number per row instead of a second copy of the whole vector table.
    """
    n = z.shape[0]
    dot, size_mean, size_row = np.zeros(n), np.zeros(n), np.zeros(n)
    for j in range(z.shape[1]):
        column = np.asarray(z[:, j], dtype=np.float64)
        total = earlier.total(column, window)
        dot += column * total
        size_mean += total * total
        size_row += column * column
    with np.errstate(invalid="ignore", divide="ignore"):
        cosine = dot / np.sqrt(size_mean * size_row)
    # No earlier row (or an all-zero vector) has no direction to compare with.
    cosine[(size_mean <= 0) | (size_row <= 0)] = np.nan
    return cosine


def score_windows(keys, secs, logit, z=None, alert_logit=None):
    """The fourteen window columns of the score, as {column name: array [rows]}.

    keys, secs    account code and whole second of every row (see _shared.account_and_time)
    logit         the model's fraud logit of every row
    z             the standardised vector, shape [rows, d]; None skips w_cos_30d
    alert_logit   the logit at or above which a row counts as an alert; None means no row does

    Time rule: a row uses only rows of its account in strictly earlier seconds, at most 30 days
    back. Rows of the same second never see each other, and the row's own score enters only
    w_minus_mean_30d, as the value the earlier mean is taken from. Maxima, means and the last
    score are missing when the window holds no earlier row; the two counts are then 0.
    """
    logit = np.asarray(logit, dtype=np.float64)
    earlier = EarlierRows(keys, secs)
    out = {}
    for label, window in WINDOWS:
        out[f"w_max_{label}"] = earlier.maximum(logit, window)
    for label, window in WINDOWS:
        out[f"w_mean_{label}"] = earlier.mean(logit, window)
    out["w_last"] = earlier.last(_highest_in_second(keys, secs, logit), window=HORIZON)
    # The cut is a fixed number about scores (found once, on the fit block). No label is involved.
    is_alert = logit >= alert_logit if alert_logit is not None else np.zeros(len(logit), dtype=bool)
    out["w_secs_since_alert"] = earlier.seconds_since_last(window=HORIZON, where=is_alert)
    out["w_alerts_30d"] = earlier.count(HORIZON, where=is_alert)
    out["w_minus_mean_30d"] = logit - out["w_mean_30d"]
    if z is not None:
        out["w_cos_30d"] = _cosine_to_earlier_mean(earlier, z, HORIZON)
    out["w_rows_30d"] = earlier.count(HORIZON)
    return out


# ----------------------------------------------------------------------------------------------
# fitting and building
# ----------------------------------------------------------------------------------------------

def fraud_follows(keys, secs, is_fraud, window):
    """The look-ahead target: does a fraud of the same account follow within `window` seconds?

    keys, secs   account code and whole second of every row
    is_fraud     yes/no per row: the fraud label
    window       how far ahead to look, in seconds

    Returns (follows, known), both yes/no arrays [rows]. `follows` is True when a fraud row of
    the account lies in a strictly later second, at most `window` seconds ahead. `known` is
    False on rows whose window runs past the last second of the table (and on rows without a
    time): their future is cut off, not empty, so they must not be fitted on.

    This looks forward in time. It is a fitting target for the probes and nothing else: it is
    never an input to the network and never an export column.
    """
    secs = np.asarray(secs)
    has_time = secs != MISSING_SECOND
    follows = later_rows(keys, secs).count(window, where=np.asarray(is_fraud, dtype=bool)) > 0
    last_second = int(secs[has_time].max()) if has_time.any() else 0
    return follows, has_time & (secs <= last_second - int(window))


def fit_bundle(df, fit_rows=None, n_directions=N_DIRECTIONS, value_tilt=None, l2=None, account_col=None,
               time_col=None, label_col=None, positive_label=None, score_col=None, score_kind=None,
               vector_prefix=None, stage1_prefix=None, reason_col=None, approved_reasons=None, per_mille=None,
               rounding=None):
    """Fit the probes, the directions and the alert cut on one block of rows.

    df         an export table of whole accounts that neither the encoder nor the consumer trains
               on: account, time, label, score, the vector columns and, when available, the
               stage-1 columns and the response code
    fit_rows   yes/no per row: the rows the fits may use (default: all). The look-ahead targets
               are still computed from every row of the table.

    Returns a plain dict of numbers and names (it can be written with `save_fitted`):
      vector_columns, stage1_columns   the column names the fits read
      alert_logit      the lowest logit inside the alert cut of this block
      calibration      slope and bias that turn s_full into log-odds of fraud on this block
      probes           weights and bias of s_txn, p_acct_24h, p_acct_7d and p_decline (None when skipped)
      vector_mean, vector_sd, rotation, direction_gain   what makes the directions
      value_tilt, rows, frauds
    A part whose columns are not available is skipped with one printed line.
    """
    l2 = PROBE_L2 if l2 is None else l2
    keys, secs = _shared.account_and_time(df, account_col, time_col)
    y = _shared.fraud_flags(df, label_col, positive_label)
    s_full = _shared.logits(df, score_col, score_kind)
    use = np.ones(len(df), dtype=bool) if fit_rows is None else np.asarray(fit_rows, dtype=bool)
    vector_names = _shared.vector_columns(df, _shared.pick(vector_prefix, "VECTOR_PREFIX"))
    stage1_names = _shared.vector_columns(df, _shared.STAGE1_PREFIX if stage1_prefix is None else stage1_prefix)
    inside = ranking.alert_mask(s_full[use], per_mille, rounding)
    fitted = {"vector_columns": vector_names, "stage1_columns": stage1_names,
              "alert_logit": float(s_full[use][inside].min()) if inside.any() else None,
              "value_tilt": float(VALUE_TILT if value_tilt is None else value_tilt),
              "rows": int(use.sum()), "frauds": int(y[use].sum())}

    # The model's logit can be shifted or stretched (class weights, sampled training rows). One slope
    # and one bias put it on the scale of log-odds of fraud on these rows. s_ctx needs that, because
    # it subtracts a probe that is on that scale; the residual of the directions needs it too.
    fitted["calibration"] = _shared.fit_logistic(s_full[use], y[use], l2=1e-6, what="the scale of the score")

    probes = {name: None for name in ("s_txn", "p_acct_24h", "p_acct_7d", "p_decline")}
    if stage1_names:
        stage1 = _shared.numeric_matrix(df, stage1_names)
        probes["s_txn"] = _shared.fit_logistic(stage1[use], y[use], l2, "the no-history probe (s_txn)")
    else:
        print("note: the table has no stage-1 vector columns; s_txn and s_ctx are skipped")
    if not vector_names:
        print("note: the table has no vector columns; the probes on the vector, the directions and "
              "w_cos_30d are skipped")
        fitted.update(probes=probes, vector_mean=None, vector_sd=None, rotation=None, direction_gain=None)
        return fitted
    vectors = _shared.numeric_matrix(df, vector_names)

    # Look-ahead probes. The target reads the future of the account, so it is used for this fit only;
    # what is exported later is the probe's reading of a vector that was computed from the past.
    for name, window in AHEAD:
        follows, known = fraud_follows(keys, secs, y > 0, window)
        known &= use
        probes[name] = _shared.fit_logistic(vectors[known], follows[known], l2, f"the look-ahead probe ({name})")
    # The bank's decision on the row itself. It is an outcome of the row, so it is a target only.
    reason = _shared.optional_column(df, _shared.pick(reason_col, "REASON_COL"), "the decline probe (p_decline)")
    if reason is not None:
        declined = reason.notna().to_numpy() & ~_shared.has_code(reason, _shared.pick(approved_reasons, "APPROVED_REASONS"))
        probes["p_decline"] = _shared.fit_logistic(vectors[use], declined[use], l2, "the decline probe (p_decline)")
    fitted["probes"] = probes

    # Directions: what the vector says about the label beyond the score. The residual is the label
    # minus the probability the calibrated score gives; the vector is standardised on these rows.
    mean, sd = vectors[use].mean(axis=0, dtype=np.float64), vectors[use].std(axis=0, dtype=np.float64)
    sd[sd == 0] = 1.0                                     # a constant column carries nothing; avoid 0 / 0
    calibration = fitted["calibration"]
    expected = expit(_shared.apply_logistic(s_full, calibration)) if calibration else np.full(len(df), y[use].mean())
    z = (vectors - mean.astype(np.float32)) / sd.astype(np.float32)
    rotation, gain = fit_directions(z[use], (y - expected)[use], n_directions)
    fitted.update(vector_mean=mean.tolist(), vector_sd=sd.tolist(), rotation=rotation.tolist(),
                  direction_gain=gain.tolist())
    return fitted


def build_bundle(df, fitted, keep_keys=True, id_col=None, account_col=None, time_col=None, amount_col=None,
                 score_col=None, score_kind=None):
    """The bundle columns for every row of a table.

    df          an export table of whole account histories: account, time, score, amount, the
                vector columns and the stage-1 columns named in `fitted`
    fitted      what `fit_bundle` returned (or `load_fitted` read)
    keep_keys   True puts the id, account and time columns in front, so the result can be joined

    Returns a DataFrame with the index of `df`: the key columns, then those of the 29 bundle
    columns that could be built, as float32, in the order of `bundle_columns`. A part whose
    inputs are missing is skipped with one printed line. No label is read here.
    """
    keys, secs = _shared.account_and_time(df, account_col, time_col)
    s_full = _shared.logits(df, score_col, score_kind)
    probes = fitted.get("probes") or {}
    out = {"s_full": s_full}

    # s_txn and s_ctx: the row by its own fields, and what the account's history added to that.
    stage1_names = fitted.get("stage1_columns") or []
    if probes.get("s_txn") and all(c in df.columns for c in stage1_names):
        out["s_txn"] = _shared.apply_logistic(_shared.numeric_matrix(df, stage1_names), probes["s_txn"])
        if fitted.get("calibration"):
            out["s_ctx"] = _shared.apply_logistic(s_full, fitted["calibration"]) - out["s_txn"]
    else:
        print("note: no stage-1 probe or no stage-1 columns; s_txn and s_ctx are skipped")

    # The probes on the vector, and the directions: the standardised vector times the fitted rotation.
    vector_names = fitted.get("vector_columns") or []
    z, n_directions = None, 0
    if vector_names and fitted.get("rotation") is not None and all(c in df.columns for c in vector_names):
        vectors = _shared.numeric_matrix(df, vector_names)
        for name in ("p_acct_24h", "p_acct_7d", "p_decline"):
            if probes.get(name):
                out[name] = expit(_shared.apply_logistic(vectors, probes[name]))
        mean = np.asarray(fitted["vector_mean"], dtype=np.float32)
        sd = np.asarray(fitted["vector_sd"], dtype=np.float32)
        z = (vectors - mean) / sd
        directions = z @ np.asarray(fitted["rotation"], dtype=np.float32).reshape(len(vector_names), -1)
        n_directions = directions.shape[1]
        for k, name in enumerate(direction_columns(n_directions)):
            out[name] = directions[:, k]
    else:
        print("note: no fitted directions or no vector columns; the probes on the vector, the directions "
              "and w_cos_30d are skipped")

    amount = _shared.amounts(df, amount_col)
    if amount is not None:
        # A missing or negative amount counts as zero, so such a row gets no tilt.
        out["s_val"] = s_full + fitted["value_tilt"] * np.log1p(np.clip(np.nan_to_num(amount, nan=0.0), 0.0, None))

    out.update(score_windows(keys, secs, s_full, z, fitted.get("alert_logit")))
    frame = pd.DataFrame({name: np.asarray(out[name], dtype=FLOAT) for name in bundle_columns(n_directions)
                          if name in out}, index=df.index)
    if keep_keys:
        key_names = (_shared.pick(id_col, "ID_COL"), _shared.pick(account_col, "ACCOUNT_COL"),
                     _shared.pick(time_col, "TIME_COL"))
        for position, name in enumerate(c for c in key_names if c in df.columns):
            frame.insert(position, name, df[name])
    return frame


def save_fitted(fitted, path):
    """Write the fitted parts to a JSON file (plain text; an existing file is replaced)."""
    with open(path, "w", encoding="ascii") as handle:
        json.dump(fitted, handle)
    return path


def load_fitted(path):
    """Read fitted parts written by `save_fitted`."""
    with open(path, "r", encoding="ascii") as handle:
        return json.load(handle)


def demo_tables(n_accounts=300, seed=1):
    """Two made-up export tables (one to fit on, one to build for) with score, vector and stage-1 vector."""
    made = []
    for i in range(2):
        df = synthetic.make_vectors(synthetic.make_scores(
            synthetic.make_transactions(n_accounts=n_accounts, seed=seed + i), seed=seed + i), dim=8, seed=seed + i)
        # The made-up stage-1 vector is a second, narrower vector with its own noise.
        stage1 = synthetic.make_vectors(df[[settings.LABEL_COL]], dim=4, seed=seed + 10 + i)
        for j in range(4):
            df[f"{_shared.STAGE1_PREFIX}{j}"] = stage1[f"{settings.VECTOR_PREFIX}{j}"].to_numpy()
        made.append(df)
    return made


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(description="Build the export bundle: named scores, directions and score windows.")
    parser.add_argument("--fit-export", default=None, help="export file of the block the probes and directions are fitted on")
    parser.add_argument("--fitted", default=None, help="read the fitted parts from this JSON file instead of fitting")
    parser.add_argument("--save-fitted", default=None, help="write the fitted parts to this JSON file")
    parser.add_argument("--export", default=None, help="export file (whole account histories) that gets the bundle columns")
    parser.add_argument("--value-tilt", type=float, default=None, help="k of s_val (default: VALUE_TILT)")
    parser.add_argument("--demo", action="store_true", help="run on made-up rows instead of files")
    parser.add_argument("--out", default=None, help="write the bundle columns to this parquet file")
    args = parser.parse_args(argv)

    fit_table, table = demo_tables() if args.demo else (None, None)
    if args.fitted:
        fitted = load_fitted(args.fitted)
    else:
        if fit_table is None:
            if not args.fit_export:
                parser.error("give --fit-export, --fitted or --demo")
            fit_table = tables.read_columns(args.fit_export)
        fitted = fit_bundle(fit_table, value_tilt=args.value_tilt)
    if args.save_fitted:
        save_fitted(fitted, args.save_fitted)
        print(f"wrote the fitted parts to {args.save_fitted}")
    print(f"fitted on {fitted['rows']} rows with {fitted['frauds']} frauds; alert logit {fitted['alert_logit']}")
    if fitted.get("direction_gain"):
        _shared.show("Share of the label residual explained by each direction",
                     pd.DataFrame({"direction": direction_columns(len(fitted["direction_gain"])),
                                   "gain": fitted["direction_gain"]}), digits=6)
    if table is None and args.export:
        table = tables.read_columns(args.export)
    if table is None:
        return fitted
    frame = build_bundle(table, fitted)
    _shared.show(f"Bundle columns ({len(frame)} rows)", _shared.summary(frame.drop(
        columns=[c for c in (settings.ID_COL,) if c in frame.columns])))
    if args.out:
        _shared.save(frame, args.out)
    return frame


if __name__ == "__main__":
    main()
