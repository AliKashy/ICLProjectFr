"""One vector, several targets: what the exported columns are worth to consumers that do not exist yet.

What this file does
-------------------
It reads one table of exported rows (this model's score and vector and, when the table has
them, the columns of another model) and fits small linear probes on them. A probe is a
logistic regression on frozen columns: the columns are read as they are and never changed.
Every probe is fitted on some accounts and read on the others. Three questions are answered:

    several targets    one probe per target and per set of columns. The targets are a fraud
                       now, the first fraud of a run, another fraud of the same account within
                       24 hours and within 7 days, and the bank's own decline. One table says
                       how well each set of columns ranks each target; a paired bootstrap over
                       accounts says what one set has over another.
    fewer labels       the probes of one target are fitted again on a shrinking share of the
                       fit accounts and read on the same rows every time: how many labelled
                       events a new consumer needs with one set of columns and with another.
    two checkpoints    with a second table (the same rows exported from another checkpoint):
                       how many alerts the two scores share, and what a probe fitted on the
                       first checkpoint's vector still catches when it reads the second
                       checkpoint's vector without being fitted again.

The sets of columns are "score" (this model's score alone, as log-odds), "vector" (this
model's vector), "other" (the other model's columns) and "vector + other".

Why it exists
-------------
A model that is meant to feed other models is judged by more than its own fraud score. Three
properties decide whether its columns are worth keeping in a store. They serve targets the
model was not trained on, so one export pays for several consumers. A consumer that starts
with few labels gets further with them than without. And a consumer does not have to be
fitted again each time the model is retrained. Each property can be measured with frozen
columns and a linear probe, which is cheap, has almost nothing to tune and treats every
provider of columns alike. The lines of the score alone show what the vector holds beyond the
score. The lines of the other model's columns are the like-for-like comparison: same rows,
same folds, same probe. On the fraud target the vector and the score are expected to be
close when the head of the model is one linear layer, because that head already is a linear
probe on the vector; the other targets are where a vector can show more than its score.

Where it goes
-------------
After the scoring pass that writes scores and vectors (exports), on rows that no model in the
comparison trained on. Nothing in the network changes. The probes are a measuring device and
are not exported; the probes that are exported are those of bundle.py.

What to change for the pod
--------------------------
settings.py: ID_COL, ACCOUNT_COL, TIME_COL, LABEL_COL, POSITIVE_LABEL, AMOUNT_COL, SCORE_COL,
SCORE_KIND, VECTOR_PREFIX, REASON_COL and APPROVED_REASONS (for the decline target; None skips
it), TARGET_START, TARGET_END, OUTSORT_PER_MILLE and the bootstrap settings. In this file:
`OTHER_PREFIX` (the prefix of the other model's columns), `FOLDS`, `PROBE_L2`, `LABEL_SHARES`,
`CURVE_TARGET` and `RUN_GAP`. The table must hold whole account histories: the look-ahead
targets read the account's later rows, and the first-fraud target reads its earlier frauds.
Rows whose look-ahead window runs past the end of the table are left out of that target,
because their future is cut off, not empty. The other model's columns are joined to the
table by transaction id beforehand. Every label here is the target of a probe and nothing
else; none is an input to anything. A linear probe says what is easy to read from the
columns; a tree consumer can find more, and consumer_margin.py measures that. Each fit is a
small logistic regression on one CPU core; a whole run makes one fit per fold for every target
and set of columns, and as many again per share of the label curve.

How to try it
-------------
    python additions/exports/probe_suite.py --demo
    python additions/exports/probe_suite.py --export export.parquet --other-prefix other_ \\
        --label-shares 1 0.3 0.1 0.03 --second export_next_checkpoint.parquet --out probes.parquet
or, from Python:
    result = run_suite(export_table)
    result["targets"]                                  # one line per target and set of columns
The tests are in additions/tests/test_exports_probe_suite.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd

from additions import settings
from additions.common import ranking, synthetic, tables, timekeys
from additions.common.bootstrap import paired_bootstrap
from additions.common.history import EarlierRows
from additions.common.timekeys import MISSING_SECOND
from additions.exports import _shared, bundle

# PLACEHOLDER: the prefix of the other model's columns in the table (other_0, other_1, ...).
# None means "the table holds no second set of columns"; the comparison is then skipped.
OTHER_PREFIX = None

# PLACEHOLDER: the number of account folds. Each row is read by a probe fitted on the other folds.
FOLDS = 5

# PLACEHOLDER: the pull toward zero of the probe weights (larger means smaller weights). It is the
# same for every set of columns, so that no set is tuned more than another.
PROBE_L2 = 1.0

# PLACEHOLDER: the shares of the fit accounts on which the label curve is fitted, largest first.
LABEL_SHARES = (1.0, 0.3, 0.1, 0.03, 0.01)

# PLACEHOLDER: the target of the label curve (one of the target names below).
CURVE_TARGET = "fraud"

# PLACEHOLDER: two frauds of one account belong to the same run when at most this many seconds
# lie between them. Seven days keeps a burst of a few hours and a series of weekly charges together.
RUN_GAP = 7 * 86_400

# The look-ahead targets, as (name, seconds ahead).
AHEAD = (("fraud within 24h", 86_400), ("fraud within 7d", 7 * 86_400))

# The names of the other targets.
FRAUD, FIRST_OF_RUN, DECLINE = "fraud", "first fraud of a run", "bank decline"

# The sets of columns, in the order in which they are reported.
SETS = ("score", "vector", "other", "vector + other")

# The pairs that are compared with a bootstrap, as (first, second): the gain is first minus second.
PAIRS = (("vector", "score"), ("vector", "other"), ("vector + other", "other"))

# The three reads of the probe that is carried from one checkpoint to the next.
SAME, CARRIED, REFITTED = ("fitted on the first, read on the first", "fitted on the first, read on the second",
                           "fitted on the second, read on the second")


# ----------------------------------------------------------------------------------------------
# columns and targets
# ----------------------------------------------------------------------------------------------

def column_sets(df, vector_prefix=None, other_prefix=None, other_columns=None, score_col=None):
    """The sets of columns the table can supply, as {set name: [column names]} in the order of SETS.

    vector_prefix   prefix of this model's vector columns (default settings.VECTOR_PREFIX)
    other_prefix    prefix of the other model's columns (default OTHER_PREFIX)
    other_columns   the other model's columns by name; when given, the prefix is not used

    A set whose columns the table lacks is left out. The set "score" holds the name of the
    score column; its one input is that score as log-odds (see `set_matrix`).
    """
    score_col = _shared.pick(score_col, "SCORE_COL")
    vector = _shared.vector_columns(df, _shared.pick(vector_prefix, "VECTOR_PREFIX"))
    other_prefix = OTHER_PREFIX if other_prefix is None else other_prefix
    if other_columns:
        other = [c for c in dict.fromkeys(other_columns) if c in df.columns]
    else:
        other = _shared.vector_columns(df, other_prefix) if other_prefix else []
    found = {"score": [score_col] if score_col in df.columns else [], "vector": vector, "other": other,
             "vector + other": vector + other if vector and other else []}
    return {name: found[name] for name in SETS if found[name]}


def set_matrix(df, name, columns, score_col=None, score_kind=None):
    """The inputs of one set as a float array [rows, inputs]. The score enters as log-odds."""
    if name == "score":
        return _shared.logits(df, score_col, score_kind)[:, None]
    return _shared.numeric_matrix(df, columns).astype(np.float64)


def build_targets(df, account_col=None, time_col=None, label_col=None, positive_label=None, reason_col=None,
                  approved_reasons=None, run_gap=None, ahead=AHEAD):
    """Every target of the table, as {name: (event, usable)}: two yes/no arrays of shape [rows].

    event    True on the rows where the target happened
    usable   True on the rows on which the target can be fitted and read

    The targets:
      "fraud"                  the row is a fraud; every row is usable.
      "first fraud of a run"   the row is a fraud with no fraud of its account in the RUN_GAP
                               seconds before it (strictly earlier seconds). The later frauds
                               of a run are left out: they are neither a first fraud nor a
                               clean row. So is a first fraud whose RUN_GAP seconds reach back
                               past the first second of the table: its past is cut off, and the
                               run may have begun before the table. This is the fraud a model
                               cannot find by following an alarm that is already ringing.
      "fraud within 24h" / "fraud within 7d"
                               a fraud of the same account follows in a strictly later second
                               inside the window. Rows whose window runs past the last second
                               of the table are left out.
      "bank decline"           the response code is not an approval (skipped with one printed
                               line when the table has no response code).

    All of these come from labels or from what happened later, so they are targets only.
    """
    run_gap = RUN_GAP if run_gap is None else run_gap
    keys, secs = _shared.account_and_time(df, account_col, time_col)
    fraud = _shared.fraud_flags(df, label_col, positive_label) > 0
    everything = np.ones(len(df), dtype=bool)
    targets = {FRAUD: (fraud, everything)}

    # The first fraud of a run. Among the fraud rows alone, the previous fraud of a fraud is its
    # latest earlier row, so one pass over those rows gives the gap. A fraud without a time cannot
    # be placed in a run and is left out.
    placed = np.flatnonzero(fraud & (secs != MISSING_SECOND))
    first = np.zeros(len(df), dtype=bool)
    if len(placed):
        since = EarlierRows(keys[placed], secs[placed]).seconds_since_last()
        first[placed] = np.isnan(since) | (since > run_gap)
    # The same rule as for the look-ahead targets, turned around: a first fraud is only known to be
    # one when the table reaches back a whole RUN_GAP before it.
    has_time = secs != MISSING_SECOND
    first_second = int(secs[has_time].min()) if has_time.any() else 0
    past_known = has_time & (secs >= first_second + int(run_gap))
    targets[FIRST_OF_RUN] = (first, ~fraud | (first & past_known))

    for name, window in ahead:
        follows, known = bundle.fraud_follows(keys, secs, fraud, window)
        targets[name] = (follows, known)

    reason = _shared.optional_column(df, _shared.pick(reason_col, "REASON_COL"), f"the target '{DECLINE}'")
    if reason is not None:
        declined = reason.notna().to_numpy() & ~_shared.has_code(reason, _shared.pick(approved_reasons, "APPROVED_REASONS"))
        targets[DECLINE] = (declined, everything)
    return targets


def account_folds(accounts, folds=None, seed=0):
    """A fold number from 0 to folds - 1 per row, the same for every row of one account. Shape [rows].

    Frauds come in runs on one account. A probe fitted on some frauds of a run and read on the
    others would recognise the run, so whole accounts go into one fold.
    """
    folds = FOLDS if folds is None else folds
    codes = timekeys.codes(accounts)
    n_accounts = int(codes.max()) + 1 if len(codes) else 0
    assignment = np.random.default_rng(seed).permutation(n_accounts) % int(folds)
    return assignment[codes]


def account_share(accounts, share, seed=0):
    """Yes/no per row: does the row's account belong to the given share of the accounts?

    Every account draws one number between 0 and 1 from the seed, and belongs to a share when
    its number is below it. The draw does not depend on the share, so the accounts of a
    smaller share are a subset of those of a larger one, and a share of 1 holds all of them.
    """
    codes = timekeys.codes(accounts)
    n_accounts = int(codes.max()) + 1 if len(codes) else 0
    draw = np.random.default_rng(seed).random(n_accounts)
    return (draw < float(share))[codes]


# ----------------------------------------------------------------------------------------------
# fitting and reading a probe
# ----------------------------------------------------------------------------------------------

def out_of_fold(x, event, fit_rows, fold, l2=None, what="a probe"):
    """Probe log-odds of every row from a fit that never saw the row's account.

    x          the inputs of one set of columns, shape [rows, inputs]
    event      yes/no [rows]: the target
    fit_rows   yes/no [rows]: the rows a fit may use (usable for the target, inside the period,
               and inside the share of accounts when a label curve is drawn)
    fold       the fold number of every row; whole accounts share one

    Returns (values, fitted): float64 [rows] and the number of folds for which a fit could be
    made. For every fold the probe is fitted on the fit rows of the other folds and applied to
    all rows of the fold. A fold whose fit rows hold only one outcome gets missing values.
    """
    l2 = PROBE_L2 if l2 is None else l2
    values = np.full(len(x), np.nan)
    fitted_folds = 0
    for k in np.unique(fold):
        fit = fit_rows & (fold != k)
        fitted = _shared.fit_logistic(x[fit], event[fit], l2, what)
        if fitted is None:
            continue
        read = fold == k
        values[read] = _shared.apply_logistic(x[read], fitted)
        fitted_folds += 1
    return values, fitted_folds


def area_under_curve(event, values):
    """The chance that a row with the event ranks above a row without it; ties count as half.

    Returns None when the rows hold only one of the two outcomes. A missing value ranks last.
    """
    event = np.asarray(event, dtype=bool)
    n_events, n_others = int(event.sum()), int((~event).sum())
    if n_events == 0 or n_others == 0:
        return None
    ranks = ranking.average_ranks(values)
    return float((ranks[event].sum() - n_events * (n_events + 1) / 2.0) / (n_events * n_others))


def read_line(event, values, read_rows, amounts=None, per_mille=None, rounding=None):
    """How well one column of probe values ranks one target on the rows that are read.

    Returns a dict: rows, events, rate (events / rows), ap (average precision), auc, alerts,
    caught and capture (the share of the events inside the alert cut of these rows; for the
    fraud target this is the udr) and, when amounts are given, vdr (the share of the events'
    dollars inside the cut). A missing value ranks last, so every set of columns is read on
    the same rows. For a frequent target the cut is too small to hold many of its events, and
    ap and auc are the figures to read.
    """
    y = np.asarray(event, dtype=np.float64)[read_rows]
    v = np.asarray(values, dtype=np.float64)[read_rows]
    v = np.where(np.isnan(v), -np.inf, v)
    amount = None if amounts is None else np.asarray(amounts, dtype=np.float64)[read_rows]
    c = ranking.capture(y, v, amount, per_mille, rounding)
    ap, auc = ranking.average_precision(y, v), area_under_curve(y > 0, v)
    line = {"rows": int(read_rows.sum()), "events": int(round(c["frauds"])),
            "rate": float(y.mean()) if len(y) else np.nan, "ap": np.nan if ap is None else ap,
            "auc": np.nan if auc is None else auc, "alerts": c["alerts"], "caught": c["caught"],
            "capture": np.nan if c["udr"] is None else c["udr"]}
    if amount is not None:
        line["vdr"] = np.nan if c["vdr"] is None else c["vdr"]
    return line


def _sizes_only(line):
    """The line of a read whose probe could not be fitted in every fold: the sizes stay, the figures go."""
    return {key: (value if key in ("rows", "events", "rate") else np.nan) for key, value in line.items()}


def gain_line(units, event, first, second, read_rows, per_mille=None, rounding=None, draws=None):
    """The capture of one column of values minus that of another on the same rows, with an interval.

    Whole accounts are resampled and both columns are read on the same draw. The dict holds
    first_capture, second_capture, gain, low, high, share_above_zero and draws.
    """
    y = np.asarray(event, dtype=np.float64)[read_rows]
    a = np.asarray(first, dtype=np.float64)[read_rows]
    b = np.asarray(second, dtype=np.float64)[read_rows]
    a, b = np.where(np.isnan(a), -np.inf, a), np.where(np.isnan(b), -np.inf, b)
    result = paired_bootstrap(np.asarray(units)[read_rows], y, a, b, per_mille=per_mille, draws=draws, rounding=rounding)
    return _shared.bootstrap_line(result, "first_capture", "second_capture")


# ----------------------------------------------------------------------------------------------
# the three reads
# ----------------------------------------------------------------------------------------------

def _complete_inputs(matrices, n_rows):
    """Yes/no per row: does every set of columns have all its inputs on the row?

    A probe gives no value to a row with a missing input. Such a row would rank last for one
    set of columns and normally for another, so the two would not be read on the same footing;
    it is left out of the fits and the reads of every set instead.
    """
    ok = np.ones(n_rows, dtype=bool)
    for x in matrices.values():
        ok &= np.isfinite(x).all(axis=1)
    return ok


def _period_rows(df, rows=None):
    """The rows that are fitted and read, as a yes/no array: `rows` when given, else every row."""
    return np.ones(len(df), dtype=bool) if rows is None else np.asarray(rows, dtype=bool)


def several_targets(df, sets, targets, fold, rows=None, l2=None, draws=None, account_col=None, amount_col=None,
                    score_col=None, score_kind=None, per_mille=None, rounding=None):
    """One out-of-fold probe per target and set of columns, and the pairs of sets compared.

    df        the export table
    sets      what `column_sets` returned
    targets   what `build_targets` returned (or a part of it)
    fold      the fold number of every row (see `account_folds`)
    rows      yes/no per row: the rows that are fitted and read (default: all). Rows that miss an
              input of any set are left out, with one printed line, so that every set of
              columns is read on the same rows.

    Returns (table, gains, values):
      table    one line per target and set: inputs, folds_fitted, rows, events, rate, ap, auc,
               alerts, caught, capture. The figures are missing when a fold could not be fitted.
      gains    one line per target and pair of sets that are both there: first minus second
      values   {(target, set): float64 [rows]} the out-of-fold probe log-odds of every row
    """
    inside = _period_rows(df, rows)
    units = df[_shared.pick(account_col, "ACCOUNT_COL")].to_numpy()
    amount = _shared.amounts(df, amount_col)
    matrices = {name: set_matrix(df, name, columns, score_col, score_kind) for name, columns in sets.items()}
    complete_inputs = _complete_inputs(matrices, len(df))
    if (inside & ~complete_inputs).any():
        print(f"note: {int((inside & ~complete_inputs).sum())} rows miss an input of some set of columns; they "
              "are left out of every fit and read, so that all sets are read on the same rows")
    inside = inside & complete_inputs
    n_folds = len(np.unique(fold))
    lines, gains, values = [], [], {}
    for target, (event, usable) in targets.items():
        read_rows = usable & inside
        complete = set()
        for name, x in matrices.items():
            got, fitted_folds = out_of_fold(x, event, read_rows, fold, l2, f"the probe '{target}' on '{name}'")
            values[(target, name)] = got
            line = {"target": target, "columns": name, "inputs": x.shape[1], "folds_fitted": fitted_folds}
            read = read_line(event, got, read_rows, amount if target == FRAUD else None, per_mille, rounding)
            if fitted_folds == n_folds:
                complete.add(name)
            else:
                # Rows of a fold without a fit have no value at all, so the figures would mix two things.
                read = _sizes_only(read)
            lines.append({**line, **read})
        for first, second in PAIRS:
            if first in complete and second in complete:
                gains.append({"target": target, "first": first, "second": second,
                              **gain_line(units, event, values[(target, first)], values[(target, second)],
                                          read_rows, per_mille, rounding, draws)})
    return pd.DataFrame(lines), pd.DataFrame(gains), values


def label_curve(df, sets, target, fold, shares=None, rows=None, l2=None, draws=None, seed=0, account_col=None,
                score_col=None, score_kind=None, per_mille=None, rounding=None):
    """The probes of one target, fitted on a shrinking share of the fit accounts.

    target   (event, usable) of the target, as `build_targets` gives it
    shares   the shares of the accounts (default LABEL_SHARES); each smaller share is a subset
             of the larger ones
    seed     the seed of the draw that orders the accounts

    Returns (curve, gains):
      curve   one line per share and set of columns: share, fit_accounts and fit_events (the
              accounts and the events a fit had, averaged over the folds), folds_fitted, and
              the figures of `read_line`. Every share is read on the same rows: all usable rows
              of the period that have every input of every set, each by a probe that never saw
              its account.
      gains   one line per share and pair of sets: first minus second at that share
    A share at which a fold holds no event cannot be fitted; its figures are missing.
    """
    shares = LABEL_SHARES if shares is None else shares
    event, usable = target
    inside = _period_rows(df, rows)
    matrices = {name: set_matrix(df, name, columns, score_col, score_kind) for name, columns in sets.items()}
    read_rows = usable & inside & _complete_inputs(matrices, len(df))      # the same rows as `several_targets`
    accounts = df[_shared.pick(account_col, "ACCOUNT_COL")]
    units, account_codes = accounts.to_numpy(), timekeys.codes(accounts)
    folds = np.unique(fold)
    lines, gains = [], []
    for share in shares:
        fit_rows = read_rows & account_share(accounts, share, seed)
        # What a fit of this share had: the fit rows of the other folds, averaged over the folds.
        fit_accounts = np.mean([len(np.unique(account_codes[fit_rows & (fold != k)])) for k in folds])
        fit_events = np.mean([int(event[fit_rows & (fold != k)].sum()) for k in folds])
        values = {}
        for name, x in matrices.items():
            got, fitted_folds = out_of_fold(x, event, fit_rows, fold, l2, f"the probe on '{name}' at share {share:g}")
            read = read_line(event, got, read_rows, None, per_mille, rounding)
            if fitted_folds == len(folds):
                values[name] = got
            else:
                read = _sizes_only(read)
            lines.append({"share": float(share), "columns": name, "fit_accounts": float(fit_accounts),
                          "fit_events": float(fit_events), "folds_fitted": fitted_folds, **read})
        for first, second in PAIRS:
            if first in values and second in values:
                gains.append({"share": float(share), "first": first, "second": second,
                              **gain_line(units, event, values[first], values[second], read_rows, per_mille, rounding, draws)})
    return pd.DataFrame(lines), pd.DataFrame(gains)


def _same_rows(first, second, id_col):
    """The rows of `second` in the order of `first`, matched by transaction id; None where `second` lacks the id."""
    lookup = second.drop_duplicates(id_col).set_index(id_col)
    keys = first[id_col]
    if pd.api.types.is_numeric_dtype(keys) != pd.api.types.is_numeric_dtype(lookup.index):
        # One table stores the id as a number and the other as text: both are compared as text.
        lookup.index, keys = pd.Index(tables.id_text(lookup.index)), pd.Series(tables.id_text(keys))
    found = keys.isin(lookup.index).to_numpy()
    return lookup.reindex(keys.to_numpy()).reset_index(drop=True), found


def two_checkpoints(first, second, fold=None, rows=None, l2=None, draws=None, seed=0, id_col=None, account_col=None,
                    amount_col=None, label_col=None, positive_label=None, score_col=None, score_kind=None,
                    vector_prefix=None, per_mille=None, rounding=None):
    """The same rows exported from two checkpoints: how alike the scores are, and whether a probe carries over.

    first, second   two export tables with the same transaction ids; `second` may hold them in
                    another order. Labels, accounts and amounts are taken from `first`.
    fold            the fold number of every row of `first` (default: `account_folds` with `seed`)

    Returns (scores, probes, gains):
      scores   one line: the capture of each checkpoint's score, the alerts they share as a
               share of all alerts, the frauds caught by both, by the first only and by the
               second only, and the rank correlation of the two scores
      probes   the fraud probe on the vector, read three ways on the same rows: fitted and
               read on the first checkpoint, fitted on the first and read on the second
               without fitting again, and fitted and read on the second
      gains    the carried probe minus the refitted one (what fitting again would have
               brought) and the carried probe minus the probe on the first checkpoint
    A part whose columns one of the tables lacks is skipped with one printed line; rows that
    `second` lacks are left out of every read with one printed line.
    """
    id_col = _shared.pick(id_col, "ID_COL")
    score_col = _shared.pick(score_col, "SCORE_COL")
    aligned, found = _same_rows(first, second, id_col)
    if not found.all():
        print(f"note: {int((~found).sum())} of {len(first)} rows are not in the second table and are left out")
    inside = _period_rows(first, rows) & found
    y = _shared.fraud_flags(first, label_col, positive_label)
    units = first[_shared.pick(account_col, "ACCOUNT_COL")].to_numpy()
    amount = _shared.amounts(first, amount_col)
    fold = account_folds(first[_shared.pick(account_col, "ACCOUNT_COL")], None, seed) if fold is None else fold
    scores, probes, gains = pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    if score_col in first.columns and score_col in aligned.columns:
        one = np.asarray(_shared.logits(first, score_col, score_kind), dtype=np.float64)[inside]
        two = np.asarray(_shared.logits(aligned, score_col, score_kind), dtype=np.float64)[inside]
        labels = y[inside]
        amounts_inside = None if amount is None else amount[inside]
        alerts_one, alerts_two = ranking.alert_mask(one, per_mille, rounding), ranking.alert_mask(two, per_mille, rounding)
        capture_one = ranking.capture(labels, one, amounts_inside, per_mille, rounding)
        capture_two = ranking.capture(labels, two, amounts_inside, per_mille, rounding)
        n_alerts = int(alerts_one.sum())
        fraud = labels > 0
        ranks_one, ranks_two = ranking.average_ranks(one), ranking.average_ranks(two)
        spread = ranks_one.std() * ranks_two.std()
        scores = pd.DataFrame([{
            "rows": int(inside.sum()), "frauds": int(fraud.sum()), "alerts": n_alerts,
            "capture_first": np.nan if capture_one["udr"] is None else capture_one["udr"],
            "capture_second": np.nan if capture_two["udr"] is None else capture_two["udr"],
            "alerts_shared": int((alerts_one & alerts_two).sum()),
            "share_of_alerts_shared": float((alerts_one & alerts_two).sum() / n_alerts) if n_alerts else np.nan,
            "frauds_both": int((fraud & alerts_one & alerts_two).sum()),
            "frauds_first_only": int((fraud & alerts_one & ~alerts_two).sum()),
            "frauds_second_only": int((fraud & ~alerts_one & alerts_two).sum()),
            "rank_correlation": float(np.mean((ranks_one - ranks_one.mean()) * (ranks_two - ranks_two.mean())) / spread)
            if spread > 0 else np.nan}])
    else:
        print("note: one of the two tables has no score column; the comparison of the scores is skipped")

    names = _shared.vector_columns(first, _shared.pick(vector_prefix, "VECTOR_PREFIX"))
    if not names or any(name not in aligned.columns for name in names):
        print("note: the two tables do not hold the same vector columns; the carried probe is skipped")
        return scores, probes, gains
    x_one = _shared.numeric_matrix(first, names).astype(np.float64)
    x_two = _shared.numeric_matrix(aligned, names).astype(np.float64)
    # The three probes are fitted and read on the rows where both vectors are complete.
    inside = inside & np.isfinite(x_one).all(axis=1) & np.isfinite(x_two).all(axis=1)
    l2 = PROBE_L2 if l2 is None else l2
    event = y > 0
    values = {name: np.full(len(first), np.nan) for name in (SAME, CARRIED, REFITTED)}
    folds, fitted_folds = np.unique(fold), 0
    for k in folds:
        fit, read = inside & (fold != k), fold == k
        on_first = _shared.fit_logistic(x_one[fit], event[fit], l2, "the fraud probe on the first checkpoint")
        on_second = _shared.fit_logistic(x_two[fit], event[fit], l2, "the fraud probe on the second checkpoint")
        if on_first is None or on_second is None:
            continue
        values[SAME][read] = _shared.apply_logistic(x_one[read], on_first)
        # The probe of the first checkpoint reads the second checkpoint's vector as it is: this is
        # what a consumer does that keeps its weights when the model behind the columns is replaced.
        values[CARRIED][read] = _shared.apply_logistic(x_two[read], on_first)
        values[REFITTED][read] = _shared.apply_logistic(x_two[read], on_second)
        fitted_folds += 1
    if fitted_folds < len(folds):
        print("note: a fold holds only one outcome; the carried probe is skipped")
        return scores, probes, gains
    probes = pd.DataFrame([{"probe": name, **read_line(event, values[name], inside, amount, per_mille, rounding)}
                           for name in (SAME, CARRIED, REFITTED)])
    gains = pd.DataFrame([{"first": a, "second": b,
                           **gain_line(units, event, values[a], values[b], inside, per_mille, rounding, draws)}
                          for a, b in ((CARRIED, REFITTED), (CARRIED, SAME))])
    return scores, probes, gains


def run_suite(df, second=None, rows=None, target_names=None, shares=None, curve_target=None, folds=None, l2=None,
              draws=None, seed=0, vector_prefix=None, other_prefix=None, other_columns=None, account_col=None,
              per_mille=None, rounding=None):
    """The three reads on one export table (and a second one for the two checkpoints).

    df             the export table: whole account histories with id, account, time, label,
                   score, the vector columns and, when available, the other model's columns
    second         the same rows exported from another checkpoint (None skips that read)
    rows           yes/no per row of `df`: the rows that are fitted and read, usually those of
                   the scored month (default: all). The targets are always built from every row.
    target_names   the targets to read (default: all that the table can give)
    shares         the shares of the label curve (default LABEL_SHARES; an empty list skips it)
    curve_target   the target of the label curve (default CURVE_TARGET)

    Returns a dict of tables: "targets" and "gains" (see `several_targets`), "curve" and
    "curve_gains" (see `label_curve`), "checkpoint_scores", "checkpoint_probes" and
    "checkpoint_gains" (see `two_checkpoints`), "sets" (the columns of every set) and "rows"
    (id, account and time of every row with its out-of-fold probe values, one column per
    target and set).
    """
    sets = column_sets(df, vector_prefix, other_prefix, other_columns)
    if (other_columns or other_prefix or OTHER_PREFIX) and "other" not in sets:
        print("note: none of the other model's columns that were named is in the table; that comparison is skipped")
    if "vector" not in sets:
        print("note: the table has no vector columns; only the sets that are there are read")
    targets = build_targets(df, account_col)
    if target_names:
        targets = {name: targets[name] for name in target_names if name in targets}
    fold = account_folds(df[_shared.pick(account_col, "ACCOUNT_COL")], folds, seed)
    table, gains, values = several_targets(df, sets, targets, fold, rows, l2, draws, account_col,
                                           per_mille=per_mille, rounding=rounding)
    curve_target = CURVE_TARGET if curve_target is None else curve_target
    shares = LABEL_SHARES if shares is None else shares
    curve, curve_gains = pd.DataFrame(), pd.DataFrame()
    if len(shares) and curve_target in targets:
        curve, curve_gains = label_curve(df, sets, targets[curve_target], fold, shares, rows, l2, draws, seed + 1,
                                         account_col, per_mille=per_mille, rounding=rounding)
    elif len(shares):
        print(f"note: the target '{curve_target}' is not among the targets; the label curve is skipped")
    result = {"sets": sets, "targets": table, "gains": gains, "curve": curve, "curve_gains": curve_gains,
              "checkpoint_scores": pd.DataFrame(), "checkpoint_probes": pd.DataFrame(),
              "checkpoint_gains": pd.DataFrame()}
    if second is not None:
        scores, probes, carried = two_checkpoints(df, second, fold, rows, l2, draws, seed, account_col=account_col,
                                                  vector_prefix=vector_prefix, per_mille=per_mille, rounding=rounding)
        result.update(checkpoint_scores=scores, checkpoint_probes=probes, checkpoint_gains=carried)
    keep = [c for c in (settings.ID_COL, _shared.pick(account_col, "ACCOUNT_COL"), settings.TIME_COL) if c in df.columns]
    out = df[keep].reset_index(drop=True).copy()
    for (target, name), got in values.items():
        out[probe_column(target, name)] = got
    result["rows"] = out
    return result


def probe_column(target, name):
    """The column name of one probe in the written table, for example probe__fraud_within_24h__vector."""
    return "probe__" + target.replace(" ", "_") + "__" + name.replace(" + ", "_and_")


# ----------------------------------------------------------------------------------------------
# made-up rows and the tool
# ----------------------------------------------------------------------------------------------

def demo_tables(n_accounts=600, seed=1):
    """Two made-up export tables of the same rows: a first checkpoint with another model's columns, and a second.

    The other model's columns are a narrower made-up vector with its own noise. The second
    checkpoint's vector is the first one with a little noise added and its score likewise, as
    two fits of one model would be.
    """
    rng = np.random.default_rng(seed + 100)
    first = synthetic.make_vectors(synthetic.make_scores(
        synthetic.make_transactions(n_accounts=n_accounts, seed=seed, fraud_account_share=0.25), seed=seed), dim=8, seed=seed)
    other = synthetic.make_vectors(first[[settings.LABEL_COL]], dim=4, seed=seed + 10)
    for j in range(4):
        first[f"other_{j}"] = other[f"{settings.VECTOR_PREFIX}{j}"].to_numpy()
    second = first.sample(frac=1.0, random_state=seed).reset_index(drop=True)     # the same rows in another order
    for name in _shared.vector_columns(second, settings.VECTOR_PREFIX):
        second[name] = second[name] + 0.3 * rng.normal(size=len(second))
    logit = ranking.to_logit(second[settings.SCORE_COL].to_numpy(), "probability") + 0.5 * rng.normal(size=len(second))
    second[settings.SCORE_COL] = 1.0 / (1.0 + np.exp(-logit))
    return first, second


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(description="Linear probes on frozen export columns: several targets, fewer "
                                                 "labels, two checkpoints.")
    parser.add_argument("--export", default=None, help="export table with whole account histories")
    parser.add_argument("--second", default=None, help="the same rows exported from another checkpoint")
    parser.add_argument("--other-prefix", default=None,
                        help="prefix of the other model's columns in the table (default: OTHER_PREFIX)")
    parser.add_argument("--other-columns", nargs="*", default=None, help="the other model's columns by name")
    parser.add_argument("--targets", nargs="*", default=None,
                        help="targets to read, by name (default: all that the table can give); a name with "
                             "spaces goes in quotes, for example \"fraud within 24h\"")
    parser.add_argument("--label-shares", nargs="*", type=float, default=None,
                        help="shares of the fit accounts for the label curve (default: LABEL_SHARES); "
                             "give the option without a number to skip the curve")
    parser.add_argument("--curve-target", default=None, help="target of the label curve (default: CURVE_TARGET)")
    parser.add_argument("--folds", type=int, default=None, help="number of account folds (default: FOLDS)")
    parser.add_argument("--draws", type=int, default=None, help="bootstrap draws (default: settings.BOOTSTRAP_DRAWS)")
    parser.add_argument("--seed", type=int, default=0, help="seed of the folds and of the order of the accounts")
    parser.add_argument("--start", default=None, help="first day of the scored month (default: settings.TARGET_START)")
    parser.add_argument("--end", default=None, help="first day after the scored month (default: settings.TARGET_END)")
    parser.add_argument("--all-rows", action="store_true", help="fit and read on every row of the table")
    parser.add_argument("--demo", action="store_true", help="run on made-up rows instead of files")
    parser.add_argument("--out", default=None, help="write every row's out-of-fold probe values to this parquet file")
    args = parser.parse_args(argv)

    # What can be checked from the command line alone is checked before any fit.
    known = [FRAUD, FIRST_OF_RUN, *(name for name, _ in AHEAD), DECLINE]
    for name in (args.targets or []) + ([args.curve_target] if args.curve_target else []):
        if name not in known:
            parser.error(f"unknown target '{name}'; the targets are: " + ", ".join(f"'{k}'" for k in known))
    if args.folds is not None and args.folds < 2:
        parser.error("--folds needs at least 2 folds, so that every fit leaves accounts out")
    if args.label_shares and not all(0.0 < share <= 1.0 for share in args.label_shares):
        parser.error("--label-shares takes shares above 0 and at most 1")

    if args.demo:
        table, second = demo_tables()
        other_prefix = args.other_prefix or "other_"
    elif args.export:
        table = tables.read_columns(args.export)
        second = tables.read_columns(args.second) if args.second else None
        other_prefix = args.other_prefix
    else:
        parser.error("give --export or --demo")
    rows = None
    if not args.all_rows:
        # Only the scored month is fitted and read. The rows before it stay in the table, because the
        # first-fraud target looks back at them and the look-ahead targets look past the month's end.
        secs = _shared.account_and_time(table)[1]
        rows = _shared.in_period(secs, args.start or settings.TARGET_START, args.end or settings.TARGET_END)
        if not rows.any():
            print("no row of the table falls in the scored month; set TARGET_START and TARGET_END in "
                  "settings.py, or pass --start and --end, or pass --all-rows")
            return None
    shares = args.label_shares
    if args.demo and shares is None:
        shares = (1.0, 0.5, 0.25)                     # the made-up table is too small for the smaller shares
    result = run_suite(table, second, rows, args.targets, shares, args.curve_target, args.folds,
                       draws=args.draws, seed=args.seed, other_prefix=other_prefix, other_columns=args.other_columns)
    print("\nsets of columns: " + "; ".join(f"{name} ({len(columns)} inputs)" for name, columns in result["sets"].items()))
    _shared.show("Several targets: each set of columns read by a probe that never saw the row's account", result["targets"])
    _shared.show("What one set has over another (capture at the cut, first minus second)", result["gains"])
    if len(result["curve"]):
        _shared.show("Fewer labels: the same rows read by probes fitted on a share of the accounts", result["curve"])
        _shared.show("What one set has over another at each share", result["curve_gains"])
    if second is not None:
        _shared.show("Two checkpoints: the two scores on the same rows", result["checkpoint_scores"])
        _shared.show("Two checkpoints: the fraud probe on the vector", result["checkpoint_probes"])
        _shared.show("Two checkpoints: what the carried probe loses", result["checkpoint_gains"])
    if args.out:
        _shared.save(result["rows"], args.out)
    return result


if __name__ == "__main__":
    main()
