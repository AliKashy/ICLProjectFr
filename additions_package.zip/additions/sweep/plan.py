"""The sweep as an ordered list of steps, with its cost.

What this file does
-------------------
It turns the list of arms into a plan: which arms run in which order, how many training runs
that is, and how many GPU hours and days it comes to for a given time per run and number of
GPUs. It can leave arms out, print the plan and write it to a file.

Why it exists
-------------
The testing plan has two stages. Stage one is a complete sweep at a small scale (for example
250 training files): every arm is tried once against the same control. Stage two takes what
held up in stage one to the full scale (for example 1,000 files). A complete sweep is only
affordable if its cost is known before it starts and if the cheap arms run first: the reads
and the CPU screens cost no training at all, and they decide which of the input arms are
worth a training run. This file makes that order and that cost explicit.

Where it goes
-------------
At the start of the sweep. Its output is the checklist to run; promote.py reads the results.

What to change for the pod
--------------------------
SWEEP_FILES and FULL_FILES (the two scales), HOURS_PER_RUN (the time of one control run at
the sweep scale: fill it in from a real run), GPUS (how many runs can train at once), and the
arms in arms.py.

How to try it
-------------
    python additions/sweep/plan.py --list
    python additions/sweep/plan.py --hours-per-run 20 --gpus 2 --out sweep_plan.csv
    python additions/sweep/plan.py --skip same_second_order members
The test is additions/tests/test_sweep_plan.py.
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import pandas as pd

from additions.sweep.arms import ARMS, TIERS

# PLACEHOLDER: the number of training files of the sweep and of the full-scale run.
SWEEP_FILES = 250
FULL_FILES = 1000

# PLACEHOLDER: hours one control training run takes at the sweep scale, start to finish. None
# means "not measured yet": the plan then reports runs only, not hours.
HOURS_PER_RUN = None

# PLACEHOLDER: how many training runs can run at the same time.
GPUS = 1


def sweep_plan(skip=(), only_tiers=None, hours_per_run=None, gpus=None):
    """The sweep as a DataFrame, one row per arm, in running order.

    skip           ids of arms to leave out
    only_tiers     tier names to keep (None keeps all)
    hours_per_run  hours of one control run at the sweep scale (None: the module's setting)
    gpus           runs that can train at once (None: the module's setting)

    Columns: step, tier, id, title, kind, runs, time_factor, run_equivalents (runs times the
    time factor), gpu_hours and cumulative_gpu_hours (missing when no time per run is known),
    free, needs, how_to_switch_on.
    """
    hours_per_run = HOURS_PER_RUN if hours_per_run is None else hours_per_run
    order = {name: i for i, (name, _) in enumerate(TIERS)}
    rows = []
    for arm in sorted(ARMS, key=lambda a: order[a["tier"]]):      # the sort is stable: list order inside a tier
        if arm["id"] in skip or (only_tiers is not None and arm["tier"] not in only_tiers):
            continue
        equivalents = arm["runs"] * arm["time_factor"]
        rows.append({
            "tier": arm["tier"], "id": arm["id"], "title": arm["title"], "kind": arm["kind"], "runs": arm["runs"],
            "time_factor": arm["time_factor"], "run_equivalents": equivalents,
            "gpu_hours": None if hours_per_run is None else equivalents * float(hours_per_run),
            "free": arm["free"], "needs": "; ".join(arm["needs"]), "how_to_switch_on": arm["how_to_switch_on"],
        })
    plan = pd.DataFrame(rows)
    plan.insert(0, "step", range(1, len(plan) + 1))
    if hours_per_run is not None and len(plan):
        plan["cumulative_gpu_hours"] = plan["gpu_hours"].cumsum()
    return plan


def cost_summary(plan, hours_per_run=None, gpus=None):
    """Totals per tier and overall: arms, training runs, run equivalents, GPU hours and days.

    Days are wall-clock days when `gpus` runs train at once: GPU hours / gpus / 24. That is
    the best case; it assumes runs can always be packed onto the free GPUs.
    """
    hours_per_run = HOURS_PER_RUN if hours_per_run is None else hours_per_run
    gpus = GPUS if gpus is None else gpus
    g = plan.groupby("tier", sort=False).agg(arms=("id", "count"), runs=("runs", "sum"),
                                             run_equivalents=("run_equivalents", "sum")).reset_index()
    total = pd.DataFrame([{"tier": "all", "arms": int(g["arms"].sum()), "runs": int(g["runs"].sum()),
                           "run_equivalents": float(g["run_equivalents"].sum())}])
    out = pd.concat([g, total], ignore_index=True)
    if hours_per_run is not None:
        out["gpu_hours"] = out["run_equivalents"] * float(hours_per_run)
        out["days_on_the_gpus"] = out["gpu_hours"] / float(gpus) / 24.0
    return out


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    ap = argparse.ArgumentParser(description="print the sweep plan and its cost")
    ap.add_argument("--list", action="store_true", help="print every arm with what turns it on")
    ap.add_argument("--skip", nargs="*", default=(), help="ids of arms to leave out")
    ap.add_argument("--tiers", nargs="*", default=None, help="only these tiers")
    ap.add_argument("--hours-per-run", type=float, default=None, help="hours of one control run at the sweep scale")
    ap.add_argument("--gpus", type=int, default=None, help="training runs that can run at once")
    ap.add_argument("--out", help="write the plan to this CSV file")
    a = ap.parse_args(argv)
    plan = sweep_plan(a.skip, a.tiers, a.hours_per_run, a.gpus)
    print(f"sweep at {SWEEP_FILES} training files; what holds goes on to {FULL_FILES} files\n")
    with pd.option_context("display.max_rows", None, "display.max_colwidth", 70, "display.width", 220):
        columns = ["step", "tier", "id", "kind", "runs", "time_factor", "title"]
        if a.list:
            columns += ["needs", "how_to_switch_on"]
        print(plan[columns].to_string(index=False))
        print()
        print(cost_summary(plan, a.hours_per_run, a.gpus).round(1).to_string(index=False))
    if a.hours_per_run is None and HOURS_PER_RUN is None:
        print("\nno time per run was given: pass --hours-per-run (hours of one control run at the sweep scale) to see hours and days")
    if a.out:
        plan.to_csv(a.out, index=False)
        print(f"wrote {a.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
