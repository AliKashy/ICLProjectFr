"""The testing plan: one complete sweep at a small scale, then the survivors at full scale.

arms.py     every experiment as one entry: what it changes, what it costs, what it needs
plan.py     the sweep as an ordered list of steps with the number of training runs and hours
promote.py  the rule for "it holds", and the list of what goes on to the full-scale run
"""
