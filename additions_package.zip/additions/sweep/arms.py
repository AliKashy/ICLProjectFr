"""Every experiment of the sweep, one entry each.

What this file does
-------------------
It holds a plain list, ARMS. Each entry names one experiment (an "arm"): what it changes
against the control, which files of this package it uses, whether it needs a training run on
a GPU or only the CPU, how much longer than the control a run takes, and what it depends on.
Nothing is run from here; the list is read by plan.py and promote.py.

Why it exists
-------------
A complete sweep has dozens of arms that differ greatly in cost. Some are reads of scores
that already exist and take minutes. Some are screens on the CPU. Some need a full training
run. Writing every arm down once, with its cost and its dependencies, makes it possible to
order the sweep so that cheap arms run first and decide which costly arms are worth running,
and to add up the GPU time before anything starts.

Where it goes
-------------
Before the sweep: it is the menu. After the sweep: its ids are the keys of the results table
that promote.py reads.

What to change for the pod
--------------------------
The entries themselves. Remove arms that will not be run, add new ones, and correct
`time_factor` (how long one training run takes compared with the control) once a real run
has been timed. `how_to_switch_on` is plain text: it says which option, config key or code
change turns the arm on, in the words of this package; the exact command depends on the
training script in use.

The configurations of model/best_model_template.py are arms of the "model" tier, one for every entry
of its ARMS, under the name of the entry in lower case ("candidate", "width_48", ...). Its TODAY is
the model in use, so the control is that entry. Their `time_factor` is the training step of the
configuration against TODAY's, measured on a CPU (16 sequences of 121 rows, 4 threads, the mean of
two runs of the best of 3; section 7 of CONFIGURATIONS.md gives every number): a GPU gives other
ratios, and `compare` of the template, run on the GPU, replaces them before the sweep is scheduled.
They need the candidate first, because CONFIGURATIONS.md runs the changes of one entry on the
winner of the head-to-head of the wide joined model and the candidate.

How to try it
-------------
    python additions/sweep/plan.py --list
The test is additions/tests/test_sweep_plan.py.

Fields of an entry
------------------
id               short name, used as the key in every table
tier             where it sits in the order (see TIERS below)
title            one line saying what the arm is
changes          what differs from the control
files            the files of this package that hold the code
kind             "read" (existing scores only), "cpu" (CPU work on exported scores or raw rows)
                 or "gpu" (a training run)
runs             training runs the arm needs at the sweep scale (0 for reads and CPU arms)
time_factor      time of one run relative to one control run (1.0 = the same)
free             True when adopting the arm costs nothing at serving or training time, so that
                 any gain above zero is worth keeping
needs            ids of arms that must finish first, or plain words for something to be delivered
how_to_switch_on what turns the arm on
"""

# The order of the sweep. Cheap tiers come first because their results decide what is worth
# running in the costly tiers.
TIERS = [
    ("control", "The current recipe at the sweep scale. Every arm is compared with it."),
    ("reads", "Reads on the control's scores. No training."),
    ("cpu", "Screens and tables on the CPU, from the control's export and the raw rows."),
    ("switches", "Training runs that change a setting, not the model or its inputs."),
    ("inputs", "Training runs that add inputs. Only the families that passed their CPU screen."),
    ("model", "Training runs that change the network."),
    ("training", "Training runs that change the loss or add a teacher."),
    ("waiting", "Arms that need something delivered first."),
]


def _arm(id, tier, title, changes, files, kind="gpu", runs=1, time_factor=1.0, free=False, needs=(), how=""):
    return {"id": id, "tier": tier, "title": title, "changes": changes, "files": tuple(files), "kind": kind,
            "runs": runs if kind == "gpu" else 0, "time_factor": time_factor, "free": free, "needs": tuple(needs),
            "how_to_switch_on": how}


ARMS = [
    # ------------------------------------------------------------------------------------------ control
    _arm("control", "control", "The current recipe, three seeds",
         "Nothing. Three seeds give the run-to-run spread, without which no single run can be judged. The model "
         "is TODAY of model/best_model_template.py, which every configuration arm is set against in the end.",
         [], runs=3, how="The training command in use, with seeds 42, 43 and 44; the model is ARMS[\"TODAY\"] of "
                         "model/best_model_template.py."),

    # ------------------------------------------------------------------------------------------ reads
    _arm("eligible_rows", "reads", "Capture on the benchmark's own rows, and where the alerts go",
         "Reads the control on eligible rows only and counts alerts spent on rows that can never carry a label.",
         ["reads/eligible_rows.py"], kind="read", needs=["control"], how="Run the tool on the control's prediction file."),
    _arm("lock_on", "reads", "Lock-on table and the sticky-alert rule",
         "Adds a bonus to rows that follow a high-scoring row of the same account; no retraining.",
         ["reads/lock_on.py"], kind="read", free=True, needs=["control"], how="Run the tool on two prediction files (choose, confirm)."),
    _arm("seed_average", "reads", "Average of the three control seeds",
         "Averages the three seeds' scores. Shows how much of the noise at the cut an average removes.",
         ["reads/seed_average.py"], kind="read", needs=["control"], how="Run the tool on the three prediction files."),
    _arm("month_token", "reads", "The scored month's calendar value set to the last trained month",
         "Scores the control again with the unseen month replaced. No retraining.",
         ["reads/month_token.py"], kind="read", free=True, needs=["control"], how="One more scoring pass with the month clamped."),
    _arm("amount_tilt", "reads", "Frauds caught against dollars caught",
         "Ranks by score plus a multiple of log amount. A choice of operating point, not a gain in frauds caught.",
         ["reads/amount_tilt.py"], kind="read", free=True, needs=["control"], how="Run the tool on the control's prediction file."),
    _arm("run_census", "reads", "Fraud runs: first frauds against follow-ons",
         "A census; it sizes every idea that aims at follow-on frauds.",
         ["reads/run_census.py"], kind="read", needs=["control"], how="Run the tool on the control's prediction file."),
    _arm("history_census", "reads", "How much history the scored rows have",
         "A census; it says whether a longer history can help on the scored month at all.",
         ["reads/history_census.py"], kind="read", how="Run the tool on the evaluation files."),
    _arm("file_inventory", "reads", "Inventory of unused evaluation files and fresh blocks",
         "Counts frauds per file and cuts fresh blocks for choosing, deciding and confirming.",
         ["reads/file_inventory.py"], kind="read", how="Run the tool on the unused file range."),
    _arm("multi_history_average", "reads", "One checkpoint scored at several history lengths, averaged",
         "Averages scoring passes of the same checkpoint with different history lengths.",
         ["reads/multi_history_average.py"], kind="read", free=True, needs=["control"], how="Several scoring passes, then the tool."),

    _arm("blend_ladder", "reads", "What this model adds to a blend with the models that run today",
         "An out-of-fold blend of every set of the models' scores, with the gain of each model over the rest. "
         "No retraining.", ["proof/blend_ladder.py"], kind="read",
         needs=["control", "row-level scores of the other models on the same rows"],
         how="Run the tool on the score files, with the models that run today as the reference."),
    _arm("probe_suite", "reads", "What the exported vector is worth to consumers that are still to come",
         "Linear probes on the frozen export columns, read by account folds: several targets, fewer labels, "
         "and a probe carried from one checkpoint to the next. No retraining.", ["exports/probe_suite.py"], kind="read",
         needs=["control", "the vector export of the scored rows"],
         how="Run the tool on the export table; name the other model's columns for the comparison."),

    # ------------------------------------------------------------------------------------------ cpu
    _arm("screen_possible_features", "cpu", "Screen of the catalogue of possible features",
         "Each family of the catalogue is given to a tree model on top of the control's score.",
         ["features/possible_features.py", "after_model/family_screen.py"], kind="cpu", needs=["control"],
         how="Build the columns, then run the family screen."),
    _arm("screen_exact_match", "cpu", "Screen of the exact-match columns",
         "Seen-before, age, recency and counts for merchant, category, place and other keys.",
         ["features/exact_match.py", "features/lookback.py", "after_model/family_screen.py"], kind="cpu", needs=["control"],
         how="Build the columns, then run the family screen."),
    _arm("screen_outcome_history", "cpu", "Screen of the bank's decisions on earlier rows",
         "Declines by kind and at the same merchant, on earlier rows only.",
         ["features/outcome_history.py", "after_model/family_screen.py"], kind="cpu", needs=["control"],
         how="Build the columns, then run the family screen."),
    _arm("screen_surprise", "cpu", "Screen of surprise, code-template rarity and amount patterns",
         "How unlikely the row is for this account, from counts.",
         ["features/surprise.py", "features/novelty_amount.py", "features/ratios.py", "after_model/family_screen.py"], kind="cpu",
         needs=["control"], how="Build the columns, then run the family screen."),
    _arm("asof_audit", "cpu", "Audit of date and profile columns",
         "Finds which columns were stamped at the transaction and which were written later.",
         ["features/asof_audit.py"], kind="cpu", how="Run the tool on one training file and one evaluation file."),
    _arm("score_state", "cpu", "Account risk state from the model's own earlier scores",
         "Highest score, faded sums and time since the last high score, per account.",
         ["after_model/score_state.py", "after_model/oracle_ladder.py"], kind="cpu", needs=["control"],
         how="Build the state on the control's export; read it with the tree arms."),
    _arm("second_stage", "cpu", "A tree stage on top of the score",
         "A tree model on the score, the vector, raw fields and the score state; and a specialist on the top rows.",
         ["after_model/second_stage.py"], kind="cpu", needs=["control", "score_state"],
         how="Fit on files the model did not train on; read on evaluation files."),
    _arm("merchant_tables", "cpu", "What other accounts did at the same merchant",
         "Daily tables, bursts within the day, the network score by merchant, heat from the model's scores.",
         ["merchant/day_tables.py", "merchant/burst_tables.py", "merchant/visa_view.py", "merchant/heat.py", "merchant/coverage.py"],
         kind="cpu", needs=["control"], how="Build the tables from a separate panel of files; screen the columns."),
    _arm("exposure", "cpu", "Compromise-point exposure",
         "Whether the account used a place whose other customers later turned bad.",
         ["merchant/exposure.py"], kind="cpu", how="Census on the training files, then the screen."),
    _arm("covisit_vectors", "cpu", "Merchant vectors from co-visits",
         "How well a merchant fits the account's usual merchants.",
         ["merchant/covisit_vectors.py"], kind="cpu", how="Train the vectors on training files; screen the affinity column."),
    _arm("readout_control", "cpu", "Is a recurrent block needed anywhere",
         "Three small readouts on exported vectors: plain, with faded means, with a recurrent state.",
         ["after_model/readout_control.py"], kind="cpu", needs=["control"], how="Run on the control's export."),
    _arm("export_bundle", "cpu", "The export bundle and how a consumer should take it",
         "Named scores, supervised directions and account windows; entered through the consumer's margin.",
         ["exports/stage1_hook.py", "exports/bundle.py", "exports/consumer_margin.py", "exports/soft_labels.py",
          "exports/phat_writer.py", "exports/feature_store.py", "exports/release_gates.py"], kind="cpu",
         needs=["control"], how="Build the bundle on the control's export; run the consumer arms."),

    # ------------------------------------------------------------------------------------------ switches
    _arm("loss_mask", "switches", "Rows that can never carry a label leave the loss",
         "Declined and advice rows stay as history and stop counting as 'not fraud'.",
         ["training/loss_masks.py"], how="Give the loss the row weights from loss_masks.py."),
    _arm("loss_mask_risk_only", "switches", "Only the risk-decline codes leave the loss",
         "The narrow version of the mask.", ["training/loss_masks.py"], needs=["loss_mask"],
         how="The same, with only the risk-decline codes masked."),
    _arm("weight_averaging", "switches", "Averaged weights",
         "Keeps a running average of the weights and reads it at its own best checkpoint.",
         ["training/weight_averaging.py"], runs=0, kind="gpu", free=True, needs=["control"],
         how="Keep the averaged weights during the control runs; it needs no run of its own."),
    _arm("precision_32bit", "switches", "32-bit training", "Full precision instead of 16-bit arithmetic.",
         [], time_factor=1.3, how="The precision setting of the trainer."),
    _arm("unknown_dropout", "switches", "A trained 'unknown' value for every code field",
         "Codes are swapped for the unknown value at a small rate during training.",
         ["encoding/unknown_dropout.py"], free=True, how="Apply unknown_dropout.py to the code inputs in training."),
    _arm("account_sampling", "switches", "Fewer clean accounts, more files, same hours",
         "Keeps every fraud account and a share of the others, and reads more files in the same time.",
         ["training/account_sampling.py"], how="Sample accounts with account_sampling.py; train on 3 to 4 times the files."),
    _arm("context_prefix", "switches", "Training rows see as much history as scored rows",
         "Each training chunk gets the rows before it as context.", [], how="The context-prefix option of the trainer."),
    _arm("lookback_cut", "switches", "History limited to what the scored month can see",
         "During training a row may read back only as far as a scored row can.",
         ["training/lookback_cut.py"], how="Use the visibility mask from lookback_cut.py."),
    _arm("same_second_order", "switches", "An earlier row of the same second becomes visible",
         "Uses the per-account sequence number to order rows inside a second.",
         [], needs=["a decision on whether the order inside a second is known when a transaction is scored"],
         how="The time-order setting of the sequence builder."),

    # ------------------------------------------------------------------------------------------ inputs
    _arm("inputs_exact_match", "inputs", "Exact-match columns as inputs",
         "The columns that passed the screen become numeric inputs.", ["features/exact_match.py"],
         needs=["screen_exact_match"], time_factor=1.2, how="Add the surviving columns to the list of predictors."),
    _arm("inputs_outcome_history", "inputs", "Earlier bank decisions as inputs",
         "The columns that passed the screen become numeric inputs.", ["features/outcome_history.py"],
         needs=["screen_outcome_history"], time_factor=1.1, how="Add the surviving columns to the list of predictors."),
    _arm("inputs_possible_features", "inputs", "Survivors of the catalogue as inputs",
         "One run with every catalogue family that passed its screen.", ["features/possible_features.py"],
         needs=["screen_possible_features"], time_factor=1.3, how="Add the surviving columns to the list of predictors."),
    _arm("inputs_surprise", "inputs", "Surprise and novelty columns as inputs",
         "The columns that passed the screen become numeric inputs.", ["features/surprise.py", "features/novelty_amount.py"],
         needs=["screen_surprise"], time_factor=1.1, how="Add the surviving columns to the list of predictors."),
    _arm("inputs_score_state", "inputs", "The model's own earlier scores as inputs (second pass)",
         "A second pass reads the account risk state built from a first pass's scores.",
         ["after_model/score_state.py"], needs=["score_state"], runs=2,
         how="Scores must come from a model fitted on other files: fit two halves, score across, then train."),
    _arm("inputs_merchant_tables", "inputs", "Merchant-side columns as inputs",
         "The columns that passed the screen become numeric inputs.", ["merchant/day_tables.py", "merchant/visa_view.py"],
         needs=["merchant_tables"], time_factor=1.2, how="Join the table columns to the rows; add them to the predictors."),
    _arm("numeric_frontend", "inputs", "Numbers on a log scale with learned bins",
         "Replaces the plain scaling of numeric inputs.", ["encoding/numeric_frontend.py"],
         how="Swap the numeric half of the field tokenizer for NumericFrontEnd."),
    _arm("recurrence_tokens", "inputs", "Repeat markers on every row",
         "Small codes that mark repeats of the same merchant inside the account's history.",
         ["features/recurrence_tokens.py"], time_factor=1.2, how="Add the codes as extra code fields."),
    _arm("capped_merchant_token", "inputs", "A capped merchant-id token",
         "The busiest merchants get their own row; the rest share rows.", ["encoding/capped_vocab.py"],
         time_factor=1.1, how="Add the merchant id as a code field through TieredEmbedding."),
    _arm("text_init", "inputs", "The category table started from its descriptions",
         "The rows of a category embedding table start from text vectors of the category descriptions, "
         "so that related categories start as neighbours.", ["encoding/text_init.py"],
         needs=["a table with one description per category code"],
         how="Call init_embedding_from_text on the category table before the first training step."),

    # ------------------------------------------------------------------------------------------ model
    _arm("summary_tokens", "model", "Three summary tokens and a wider history stage",
         "The vector handed from stage 1 to stage 2 grows from one token's width to three.",
         ["model/summary_tokens.py", "model/history_stage.py"], time_factor=1.5,
         how="Replace the single summary token and widen stage 2."),
    _arm("reread_block", "model", "The scored row re-reads its own fields after history",
         "One cross-attention block after stage 2.", ["model/reread_block.py"], time_factor=1.15,
         how="Insert the block between stage 2 and the head."),
    _arm("interleaved_reread", "model", "A gated re-read of the fields after every history layer",
         "One gated cross-attention block after each stage-2 layer, on one representation per predictor.",
         ["model/interleaved_reread.py", "model/interleaved_wiring_template.py"], time_factor=1.3,
         how="Follow INTERLEAVED_REREAD.md: keep the predictor tokens, prepare the memory, run the layers with the re-reads."),
    _arm("recent_field_memory", "model", "A memory of the latest earlier rows' field representations",
         "The gated re-reads also query the fields of the row's latest five eligible earlier transactions.",
         ["model/interleaved_reread.py"], time_factor=1.4,
         how="The same block with num_back=5; after the last layer only, or after every layer."),
    _arm("aligned_outcomes", "model", "Earlier rows' bank decisions inside the network",
         "Later rows read an earlier row's decision; no row reads its own.", ["model/aligned_outcomes.py"],
         time_factor=1.2, needs=["screen_outcome_history"], how="Use the custom first layer of stage 2."),
    _arm("attention_bias", "model", "Attention bias for 'same value' and time gap",
         "A learned bias on stage-2 attention.", ["model/attention_bias.py"], time_factor=1.1,
         how="Add the bias to the attention mask."),
    _arm("profile_encoder", "model", "A small encoder for slow account fields",
         "Two extra positions in front of the history.", ["model/profile_encoder.py"], time_factor=1.05,
         needs=["asof_audit"], how="Feed the profile fields that passed the audit."),
    _arm("state_prefix", "model", "A stored account memory in front of the history",
         "Faded sums of earlier transaction vectors as extra positions.",
         ["model/state_prefix.py", "after_model/account_state_vectors.py"], needs=["control"], time_factor=0.6,
         how="Export stage-1 vectors, build the state, train stage 2 on stored vectors."),
    _arm("merchant_context", "model", "Other accounts' vectors at the merchant",
         "One attention block over the last rows of other accounts at the same merchant.",
         ["model/merchant_context.py"], needs=["merchant_tables"], time_factor=1.2,
         how="Export a first pass on the panel files; build the per-merchant lists; train the block."),
    _arm("members", "model", "Several members inside one model",
         "Members share stage 2 and are averaged.", ["model/members.py"], time_factor=1.3, how="Wrap stage 2's input and head."),

    # ------------------------------------------------------------------------------------------ model: configurations
    # One arm for every entry of ARMS in model/best_model_template.py, under its name in lower case; TODAY is the
    # control above. time_factor is the training step of the arm against TODAY's on a CPU (16 sequences of 121
    # rows, 4 threads, the mean of two runs of the best of 3, CONFIGURATIONS.md section 7); a GPU gives other
    # ratios, and `compare` on the GPU replaces them before the sweep is scheduled.
    _arm("wide_joined", "model", "WIDE_JOINED: today's model with tokens of 96, three summary outputs joined into 288",
         "Against TODAY: token_dim: 48 -> 96, stage1_heads: 8 -> 4, history_heads: 8 -> 4. Do tokens twice as "
         "wide, with the summary outputs still joined (288 numbers into the history), beat the model in use?",
         ["model/best_model_template.py"],
         runs=2, time_factor=1.7, needs=["control"],
         how="BestModel(ARMS[\"WIDE_JOINED\"].config) of model/best_model_template.py; its edits carry the change "
             "into the model in use, and run_checks on that model comes first."),
    _arm("candidate", "model", "CANDIDATE: six channels of 96 kept apart through four interleaved pairs",
         "Against WIDE_JOINED: n_bins: 16 -> 32, num_summary: 3 -> 6, history: joined -> channels, num_back: 0 ->"
         " 5, final_intra: False -> True, bank: predictor_bank -> predictor, gap_encoder: scalar -> ple, "
         "time_bias: False -> True. Does the candidate as a whole (six channels of 96 kept apart through four "
         "interleaved pairs, with 32 bins, the gap in bins and the time bias) beat the joined model of the same "
         "token width, by enough to pay for its cost?",
         ["model/best_model_template.py", "model/latent_channels.py",
          "encoding/numeric_encoders.py", "encoding/time_encoders.py", "model/attention_bias.py"],
         runs=2, time_factor=11.9, needs=["control"],
         how="BestModel(ARMS[\"CANDIDATE\"].config) of model/best_model_template.py; its edits carry the change "
             "into the model in use, and run_checks on that model comes first."),
    _arm("candidate_lpm", "model", "CANDIDATE_LPM: the candidate in the form closest to the Large Payments Model",
         "Against CANDIDATE: numeric_encoder: ple -> hybrid, stage1: summary -> pooler, final_intra: True -> "
         "False, readout: concat -> attention. Does the form closest to the Large Payments Model (a pooler in "
         "place of stage 1, its numeric encoder, no last read of the fields, its attention readout) beat the "
         "candidate?",
         ["model/best_model_template.py", "model/latent_channels.py", "encoding/numeric_encoders.py"],
         runs=1, time_factor=9.4, needs=["candidate"],
         how="BestModel(ARMS[\"CANDIDATE_LPM\"].config) of model/best_model_template.py; its edits carry the change"
             " into the model in use, and run_checks on that model comes first."),
    _arm("width_48", "model", "WIDTH_48: token_dim: 96 -> 48",
         "Against CANDIDATE: token_dim: 96 -> 48. With the channels kept apart, does the candidate need tokens "
         "wider than today's 48?",
         ["model/best_model_template.py"],
         runs=1, time_factor=6.4, needs=["candidate"],
         how="BestModel(ARMS[\"WIDTH_48\"].config) of model/best_model_template.py; its edits carry the change into"
             " the model in use, and run_checks on that model comes first."),
    _arm("width_144", "model", "WIDTH_144: token_dim: 96 -> 144",
         "Against CANDIDATE: token_dim: 96 -> 144. Do tokens of 144 gain over 96 in the candidate?",
         ["model/best_model_template.py"],
         runs=1, time_factor=19.3, needs=["candidate"],
         how="BestModel(ARMS[\"WIDTH_144\"].config) of model/best_model_template.py; its edits carry the change "
             "into the model in use, and run_checks on that model comes first."),
    _arm("numbers_ple16", "model", "NUMBERS_PLE16: n_bins: 32 -> 16",
         "Against CANDIDATE: n_bins: 32 -> 16. Does the candidate lose anything with today's 16 bins in place of "
         "32?",
         ["model/best_model_template.py", "encoding/numeric_encoders.py"],
         runs=1, time_factor=11.6, needs=["candidate"],
         how="BestModel(ARMS[\"NUMBERS_PLE16\"].config) of model/best_model_template.py; its edits carry the change"
             " into the model in use, and run_checks on that model comes first."),
    _arm("numbers_learned_ple", "model", "NUMBERS_LEARNED_PLE: numeric_encoder: ple -> learned_ple",
         "Against CANDIDATE: numeric_encoder: ple -> learned_ple. Do 33 learned centres (32 intervals, a branch "
         "of 32) beat 32 fixed bins?",
         ["model/best_model_template.py", "encoding/numeric_encoders.py"],
         runs=1, time_factor=11.9, needs=["candidate"],
         how="BestModel(ARMS[\"NUMBERS_LEARNED_PLE\"].config) of model/best_model_template.py; its edits carry the "
             "change into the model in use, and run_checks on that model comes first."),
    _arm("numbers_frozen_centres", "model", "NUMBERS_FROZEN_CENTRES: learn_centres: True -> False",
         "Against NUMBERS_LEARNED_PLE: learn_centres: True -> False. Held where they start, do the centres of "
         "learned_ple keep its gain over ple, which would put that gain on its parametrization and not on moving "
         "centres?",
         ["model/best_model_template.py", "encoding/numeric_encoders.py"],
         runs=1, time_factor=11.3, needs=["candidate"],
         how="BestModel(ARMS[\"NUMBERS_FROZEN_CENTRES\"].config) of model/best_model_template.py; its edits carry "
             "the change into the model in use, and run_checks on that model comes first."),
    _arm("numbers_periodic", "model", "NUMBERS_PERIODIC: numeric_encoder: ple -> periodic",
         "Against CANDIDATE: numeric_encoder: ple -> periodic. Do the value and the sines and cosines of 16 "
         "learned frequencies beat 32 fixed bins?",
         ["model/best_model_template.py", "encoding/numeric_encoders.py"],
         runs=1, time_factor=12.1, needs=["candidate"],
         how="BestModel(ARMS[\"NUMBERS_PERIODIC\"].config) of model/best_model_template.py; its edits carry the "
             "change into the model in use, and run_checks on that model comes first."),
    _arm("numbers_hybrid", "model", "NUMBERS_HYBRID: numeric_encoder: ple -> hybrid",
         "Against CANDIDATE: numeric_encoder: ple -> hybrid. Does the numeric encoder of the Large Payments Model"
         " (raw, Fourier and piecewise branches side by side) beat 32 fixed bins?",
         ["model/best_model_template.py", "encoding/numeric_encoders.py"],
         runs=1, time_factor=11.7, needs=["candidate"],
         how="BestModel(ARMS[\"NUMBERS_HYBRID\"].config) of model/best_model_template.py; its edits carry the "
             "change into the model in use, and run_checks on that model comes first."),
    _arm("missing_learned", "model", "MISSING_LEARNED: missing: zero -> learned",
         "Against CANDIDATE: missing: zero -> learned. Does a learned vector for a missing number beat the field "
         "identity alone, a question only when the real numbers are ever missing?",
         ["model/best_model_template.py", "encoding/numeric_encoders.py"],
         runs=1, time_factor=11.2, needs=["candidate"],
         how="BestModel(ARMS[\"MISSING_LEARNED\"].config) of model/best_model_template.py; its edits carry the "
             "change into the model in use, and run_checks on that model comes first."),
    _arm("stage1_all", "model", "STAGE1_ALL: stage1_fields: grouped -> all",
         "Against CANDIDATE: stage1_fields: grouped -> all. Does stage 1 gain from reading all 64 predictor "
         "tokens instead of 4 kept alone and 3 averaged groups?",
         ["model/best_model_template.py"],
         runs=1, time_factor=22.6, needs=["candidate"],
         how="BestModel(ARMS[\"STAGE1_ALL\"].config) of model/best_model_template.py; its edits carry the change "
             "into the model in use, and run_checks on that model comes first."),
    _arm("stage1_pooler", "model", "STAGE1_POOLER: stage1: summary -> pooler",
         "Against CANDIDATE: stage1: summary -> pooler. Does a pooler of six learned queries over the 64 "
         "predictor tokens, in place of stage 1, do as well at less cost?",
         ["model/best_model_template.py", "model/latent_channels.py"],
         runs=1, time_factor=10.4, needs=["candidate"],
         how="BestModel(ARMS[\"STAGE1_POOLER\"].config) of model/best_model_template.py; its edits carry the change"
             " into the model in use, and run_checks on that model comes first."),
    _arm("stage1_layers_3", "model", "STAGE1_LAYERS_3: stage1_layers: 2 -> 3",
         "Against CANDIDATE: stage1_layers: 2 -> 3. Does a third layer in stage 1 gain?",
         ["model/best_model_template.py"],
         runs=1, time_factor=11.6, needs=["candidate"],
         how="BestModel(ARMS[\"STAGE1_LAYERS_3\"].config) of model/best_model_template.py; its edits carry the "
             "change into the model in use, and run_checks on that model comes first."),
    _arm("stage1_heads_8", "model", "STAGE1_HEADS_8: stage1_heads: 4 -> 8",
         "Against CANDIDATE: stage1_heads: 4 -> 8. Do eight heads of 12 in stage 1 beat four of 24?",
         ["model/best_model_template.py"],
         runs=1, time_factor=11.1, needs=["candidate"],
         how="BestModel(ARMS[\"STAGE1_HEADS_8\"].config) of model/best_model_template.py; its edits carry the "
             "change into the model in use, and run_checks on that model comes first."),
    _arm("channels_3", "model", "CHANNELS_3: num_summary: 6 -> 3",
         "Against CANDIDATE: num_summary: 6 -> 3. Are three channels, today's number of summary outputs, enough "
         "once they are kept apart?",
         ["model/best_model_template.py", "model/latent_channels.py"],
         runs=1, time_factor=8.0, needs=["candidate"],
         how="BestModel(ARMS[\"CHANNELS_3\"].config) of model/best_model_template.py; its edits carry the change "
             "into the model in use, and run_checks on that model comes first."),
    _arm("channels_12", "model", "CHANNELS_12: num_summary: 6 -> 12",
         "Against CANDIDATE: num_summary: 6 -> 12. Do twelve channels, near the fifth of the fields the Large "
         "Payments Model uses, gain over six?",
         ["model/best_model_template.py", "model/latent_channels.py"],
         runs=1, time_factor=21.3, needs=["candidate"],
         how="BestModel(ARMS[\"CHANNELS_12\"].config) of model/best_model_template.py; its edits carry the change "
             "into the model in use, and run_checks on that model comes first."),
    _arm("pairs_6", "model", "PAIRS_6: history_layers: 4 -> 6",
         "Against CANDIDATE: history_layers: 4 -> 6. Do six interleaved pairs gain over four?",
         ["model/best_model_template.py", "model/latent_channels.py"],
         runs=1, time_factor=16.9, needs=["candidate"],
         how="BestModel(ARMS[\"PAIRS_6\"].config) of model/best_model_template.py; its edits carry the change into "
             "the model in use, and run_checks on that model comes first."),
    _arm("history_heads_3", "model", "HISTORY_HEADS_3: history_heads: 4 -> 3",
         "Against CANDIDATE: history_heads: 4 -> 3. Do three heads of 32 in the stage beat four of 24?",
         ["model/best_model_template.py", "model/latent_channels.py"],
         runs=1, time_factor=9.4, needs=["candidate"],
         how="BestModel(ARMS[\"HISTORY_HEADS_3\"].config) of model/best_model_template.py; its edits carry the "
             "change into the model in use, and run_checks on that model comes first."),
    _arm("layout_staged", "model", "LAYOUT_STAGED: layout: interleaved -> staged",
         "Against CANDIDATE: layout: interleaved -> staged. Does reading the fields only after the through-time "
         "blocks (the staged order of ViViT) do as well as reading them between them?",
         ["model/best_model_template.py", "model/latent_channels.py"],
         runs=1, time_factor=6.1, needs=["candidate"],
         how="BestModel(ARMS[\"LAYOUT_STAGED\"].config) of model/best_model_template.py; its edits carry the change"
             " into the model in use, and run_checks on that model comes first."),
    _arm("layout_temporal_only", "model", "LAYOUT_TEMPORAL_ONLY: layout: interleaved -> temporal_only",
         "Against CANDIDATE: layout: interleaved -> temporal_only. With final_intra kept, so that the fields are "
         "read once at the end, do the within-transaction blocks between the through-time blocks earn their cost?",
         ["model/best_model_template.py", "model/latent_channels.py"],
         runs=1, time_factor=4.8, needs=["candidate"],
         how="BestModel(ARMS[\"LAYOUT_TEMPORAL_ONLY\"].config) of model/best_model_template.py; its edits carry the"
             " change into the model in use, and run_checks on that model comes first."),
    _arm("memory_0", "model", "MEMORY_0: num_back: 5 -> 0",
         "Against CANDIDATE: num_back: 5 -> 0. Does the memory of the fields of the 5 latest earlier rows gain "
         "over the row's own fields alone?",
         ["model/best_model_template.py", "model/interleaved_reread.py"],
         runs=1, time_factor=5.1, needs=["candidate"],
         how="BestModel(ARMS[\"MEMORY_0\"].config) of model/best_model_template.py; its edits carry the change into"
             " the model in use, and run_checks on that model comes first."),
    _arm("memory_10", "model", "MEMORY_10: num_back: 5 -> 10",
         "Against CANDIDATE: num_back: 5 -> 10. Does a memory of 10 earlier rows gain over 5?",
         ["model/best_model_template.py", "model/interleaved_reread.py"],
         runs=1, time_factor=20.9, needs=["candidate"],
         how="BestModel(ARMS[\"MEMORY_10\"].config) of model/best_model_template.py; its edits carry the change "
             "into the model in use, and run_checks on that model comes first."),
    _arm("memory_slot", "model", "MEMORY_SLOT: memory_ties: whole_seconds -> slot",
         "Against CANDIDATE: memory_ties: whole_seconds -> slot. Does taking the rows of an earlier second by "
         "their slots, the rule of the re-read of 24 November that the order inside a second can move, score "
         "otherwise than taking whole seconds?",
         ["model/best_model_template.py", "model/interleaved_reread.py"],
         runs=1, time_factor=11.8, needs=["candidate"],
         how="BestModel(ARMS[\"MEMORY_SLOT\"].config) of model/best_model_template.py; its edits carry the change "
             "into the model in use, and run_checks on that model comes first."),
    _arm("bank_predictor_bank", "model", "BANK_PREDICTOR_BANK: bank: predictor -> predictor_bank",
         "Against CANDIDATE: bank: predictor -> predictor_bank. Do predictor tokens that have read stage 1 once "
         "(PredictorBank) make a better bank than the predictor tokens as they are?",
         ["model/best_model_template.py", "model/interleaved_reread.py"],
         runs=1, time_factor=12.2, needs=["candidate"],
         how="BestModel(ARMS[\"BANK_PREDICTOR_BANK\"].config) of model/best_model_template.py; its edits carry the "
             "change into the model in use, and run_checks on that model comes first."),
    _arm("intra_self_off", "model", "INTRA_SELF_OFF: intra_self_attention: True -> False",
         "Against CANDIDATE: intra_self_attention: True -> False. Do the channels of a transaction gain from "
         "reading one another?",
         ["model/best_model_template.py", "model/latent_channels.py"],
         runs=1, time_factor=10.4, needs=["candidate"],
         how="BestModel(ARMS[\"INTRA_SELF_OFF\"].config) of model/best_model_template.py; its edits carry the "
             "change into the model in use, and run_checks on that model comes first."),
    _arm("intra_cross_off", "model", "INTRA_CROSS_OFF: intra_cross_attention: True -> False",
         "Against CANDIDATE: intra_cross_attention: True -> False. Does reading the fields and the memory in "
         "every pair gain over channels that never read them again after stage 1?",
         ["model/best_model_template.py", "model/latent_channels.py"],
         runs=1, time_factor=3.8, needs=["candidate"],
         how="BestModel(ARMS[\"INTRA_CROSS_OFF\"].config) of model/best_model_template.py; its edits carry the "
             "change into the model in use, and run_checks on that model comes first."),
    _arm("intra_self_first", "model", "INTRA_SELF_FIRST: intra_order: cross_first -> self_first",
         "Against CANDIDATE: intra_order: cross_first -> self_first. Does it matter that the channels read one "
         "another before the fields, the order of the first version, rather than after them?",
         ["model/best_model_template.py", "model/latent_channels.py"],
         runs=1, time_factor=12.0, needs=["candidate"],
         how="BestModel(ARMS[\"INTRA_SELF_FIRST\"].config) of model/best_model_template.py; its edits carry the "
             "change into the model in use, and run_checks on that model comes first."),
    _arm("share_temporal_off", "model", "SHARE_TEMPORAL_OFF: share_temporal: True -> False",
         "Against CANDIDATE: share_temporal: True -> False. Does a through-time layer per channel beat one layer "
         "shared by every channel?",
         ["model/best_model_template.py", "model/latent_channels.py"],
         runs=1, time_factor=12.6, needs=["candidate"],
         how="BestModel(ARMS[\"SHARE_TEMPORAL_OFF\"].config) of model/best_model_template.py; its edits carry the "
             "change into the model in use, and run_checks on that model comes first."),
    _arm("channel_identity_off", "model", "CHANNEL_IDENTITY_OFF: channel_identity: True -> False",
         "Against CANDIDATE: channel_identity: True -> False. Do the shared through-time layers need a learned "
         "vector that tells the channels apart?",
         ["model/best_model_template.py", "model/latent_channels.py"],
         runs=1, time_factor=12.9, needs=["candidate"],
         how="BestModel(ARMS[\"CHANNEL_IDENTITY_OFF\"].config) of model/best_model_template.py; its edits carry the"
             " change into the model in use, and run_checks on that model comes first."),
    _arm("channel_projections_on", "model", "CHANNEL_PROJECTIONS_ON: channel_projections: False -> True",
         "Against CANDIDATE: channel_projections: False -> True. Does a learned map per channel at the start of "
         "the stage gain?",
         ["model/best_model_template.py", "model/latent_channels.py"],
         runs=1, time_factor=12.8, needs=["candidate"],
         how="BestModel(ARMS[\"CHANNEL_PROJECTIONS_ON\"].config) of model/best_model_template.py; its edits carry "
             "the change into the model in use, and run_checks on that model comes first."),
    _arm("final_intra_off", "model", "FINAL_INTRA_OFF: final_intra: True -> False",
         "Against CANDIDATE: final_intra: True -> False. Does the last read of the fields after the last through-"
         "time block gain, as the re-read after stage 2 gained today?",
         ["model/best_model_template.py", "model/latent_channels.py"],
         runs=1, time_factor=9.6, needs=["candidate"],
         how="BestModel(ARMS[\"FINAL_INTRA_OFF\"].config) of model/best_model_template.py; its edits carry the "
             "change into the model in use, and run_checks on that model comes first."),
    _arm("readout_attention", "model", "READOUT_ATTENTION: readout: concat -> attention",
         "Against CANDIDATE: readout: concat -> attention. Does a learned task query over the six channels (96 "
         "numbers to the head) do as well as the channels side by side (576)?",
         ["model/best_model_template.py", "model/latent_channels.py"],
         runs=1, time_factor=11.8, needs=["candidate"],
         how="BestModel(ARMS[\"READOUT_ATTENTION\"].config) of model/best_model_template.py; its edits carry the "
             "change into the model in use, and run_checks on that model comes first."),
    _arm("readout_mean", "model", "READOUT_MEAN: readout: concat -> mean",
         "Against CANDIDATE: readout: concat -> mean. Does the plain average of the six channels do as well as "
         "the channels side by side?",
         ["model/best_model_template.py", "model/latent_channels.py"],
         runs=1, time_factor=12.6, needs=["candidate"],
         how="BestModel(ARMS[\"READOUT_MEAN\"].config) of model/best_model_template.py; its edits carry the change "
             "into the model in use, and run_checks on that model comes first."),
    _arm("gap_scalar", "model", "GAP_SCALAR: gap_encoder: ple -> scalar",
         "Against CANDIDATE: gap_encoder: ple -> scalar. Does the gap through bins on its soft log beat today's "
         "single number log(1 + gap)?",
         ["model/best_model_template.py", "encoding/time_encoders.py"],
         runs=1, time_factor=12.1, needs=["candidate"],
         how="BestModel(ARMS[\"GAP_SCALAR\"].config) of model/best_model_template.py; its edits carry the change "
             "into the model in use, and run_checks on that model comes first."),
    _arm("gap_sinusoid", "model", "GAP_SINUSOID: gap_encoder: ple -> sinusoid",
         "Against CANDIDATE: gap_encoder: ple -> sinusoid. Do the sines of FraudTransformer as the paper runs "
         "them (milliseconds, base 1e7) beat the gap in bins?",
         ["model/best_model_template.py", "encoding/time_encoders.py"],
         runs=1, time_factor=12.2, needs=["candidate"],
         how="BestModel(ARMS[\"GAP_SINUSOID\"].config) of model/best_model_template.py; its edits carry the change "
             "into the model in use, and run_checks on that model comes first."),
    _arm("gap_sinusoid_seconds", "model", "GAP_SINUSOID_SECONDS: gap_ticks_per_second: paper (1,000 a second) -> 1.0",
         "Against GAP_SINUSOID: gap_ticks_per_second: paper (1,000 a second) -> 1.0. Do the same sines counted in"
         " whole seconds (periods of 6.3 seconds to a year) beat the paper's milliseconds on gaps of seconds to "
         "months?",
         ["model/best_model_template.py", "encoding/time_encoders.py"],
         runs=1, time_factor=11.9, needs=["candidate"],
         how="BestModel(ARMS[\"GAP_SINUSOID_SECONDS\"].config) of model/best_model_template.py; its edits carry the"
             " change into the model in use, and run_checks on that model comes first."),
    _arm("time_bias_off", "model", "TIME_BIAS_OFF: time_bias: True -> False",
         "Against CANDIDATE: time_bias: True -> False. Does the learned bias by time gap on every through-time "
         "block gain?",
         ["model/best_model_template.py", "model/attention_bias.py"],
         runs=1, time_factor=11.0, needs=["candidate"],
         how="BestModel(ARMS[\"TIME_BIAS_OFF\"].config) of model/best_model_template.py; its edits carry the change"
             " into the model in use, and run_checks on that model comes first."),
    _arm("calendar", "model", "CALENDAR: calendar: False -> True",
         "Against CANDIDATE: calendar: False -> True. Do the hour of the day and the day of the week as sines and"
         " cosines add anything, a question only when they are not among the 64 predictors?",
         ["model/best_model_template.py", "encoding/time_encoders.py"],
         runs=1, time_factor=11.4, needs=["candidate"],
         how="BestModel(ARMS[\"CALENDAR\"].config) of model/best_model_template.py; its edits carry the change into"
             " the model in use, and run_checks on that model comes first."),

    # ------------------------------------------------------------------------------------------ training
    _arm("hindsight_heads", "training", "Extra heads for run state",
         "Heads predict whether the account had a fraud recently and whether one follows soon.",
         ["training/auxiliary_heads.py"], how="Add the heads and the capped loss."),
    _arm("decline_head", "training", "A head that predicts the bank's decline",
         "A training target only; never an input.", ["training/auxiliary_heads.py"], how="Add the head and the capped loss."),
    _arm("next_transaction_heads", "training", "Heads that predict the next transaction",
         "Trained beside the fraud loss under a cap; the surprise is exported.",
         ["training/next_transaction_heads.py", "training/auxiliary_heads.py"], time_factor=1.1,
         how="Add the heads and the capped loss."),
    _arm("pairwise_top", "training", "A small pairwise term at the top of the ranking",
         "Added late and kept small.", ["training/pairwise_top.py"], how="Add the term to the loss after a warm-up."),
    _arm("distillation", "training", "Three seeds into one model",
         "One model learns from the average of three, on files they did not train on.",
         ["training/distillation.py"], needs=["control"], runs=1,
         how="Score other files with the three control seeds; train a student on labels and soft targets."),
    _arm("lookahead_teacher", "training", "A teacher that sees the next rows",
         "A training-only teacher; the shipped model stays causal.", ["training/lookahead_teacher.py", "training/distillation.py"],
         runs=2, how="Train the teacher with the look-ahead mask, score other files, train the student."),

    # ------------------------------------------------------------------------------------------ waiting
    _arm("offset_head", "waiting", "A head trained on top of the incumbent model's score",
         "Its gradient comes only from what the incumbent gets wrong.", ["training/offset_head.py"],
         needs=["the incumbent model's scores on the training rows"], how="Add the second head and the offset column."),
    _arm("other_model_teacher", "waiting", "Another model's scores as soft targets",
         "Soft targets on non-fraud rows.", ["training/distillation.py"],
         needs=["the other model's scores on a transfer set", "a decision that a taught model may be the challenger"],
         how="Join the scores by transaction id; use the soft-target loss."),
]


def by_id():
    """The arms as a dict keyed by id."""
    return {a["id"]: a for a in ARMS}
