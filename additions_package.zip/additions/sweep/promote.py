"""Which arms held up in the sweep, and what goes on to the full-scale run.

What this file does
-------------------
It reads a table of sweep results (one row per arm: the gain in capture over the control and
its interval, on the block used to choose and, when available, on a second block used to
confirm), gives each arm a verdict, and writes the plan of the full-scale stage: the control,
one run with every arm that held, and a run without each costly arm so its share can be told.

Why it exists
-------------
"Whatever holds goes on to the full scale" needs a rule that is fixed before the results
are seen. Without one, the arm that looks best among dozens is often only the luckiest: with
many arms read on the same rows, the best of them shows a gain by chance. The rule here asks
for a gain of a minimum size whose interval stays above zero, and for the same direction on
a second block of rows that played no part in choosing. An arm that costs nothing to adopt
only has to be above zero on both blocks. Arms that pass are then trained together once,
because gains that reach the same frauds do not add.

Where it goes
-------------
After the sweep's reads. The gains and intervals come from the paired bootstrap that
resamples accounts (additions/common/bootstrap.py); each arm is read against the control on
the same rows.

What to change for the pod
--------------------------
MIN_GAIN (the smallest gain that counts), REQUIRE_CONFIRM (whether a second block is
required), COSTLY_FACTOR (above which time factor an arm gets its own leave-one-out run), and
the column names of the results file if they differ.

How to try it
-------------
    python additions/sweep/promote.py --results sweep_results.csv --out full_scale_plan.csv

The results file has the columns: id, gain, low, high, and optionally gain_confirm,
low_confirm (the same read on the confirm block).
The test is additions/tests/test_sweep_promote.py.
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import pandas as pd

from additions.sweep.arms import by_id
from additions.sweep.plan import FULL_FILES, SWEEP_FILES

# PLACEHOLDER: the smallest gain in capture (as a share of all frauds; 0.005 is half a point)
# that an arm with a cost must show on the choose block.
MIN_GAIN = 0.005

# PLACEHOLDER: whether an arm must also be above zero on a second block that was not used to
# choose. With True, an arm with no confirm read is "unclear", not "holds".
REQUIRE_CONFIRM = True

# PLACEHOLDER: an arm whose training run takes at least this many times the control's time is
# "costly": at full scale it also gets a run without it, to show what it adds on its own.
COSTLY_FACTOR = 1.25

HOLDS, NOT, UNCLEAR = "holds", "does not hold", "unclear"


def verdict(gain, low, gain_confirm=None, free=False, min_gain=None, require_confirm=None):
    """One arm's verdict and the reason, as (verdict, reason).

    gain          gain over the control on the choose block
    low           lower end of that gain's interval
    gain_confirm  gain on the confirm block, or None when it was not read
    free          True for an arm that costs nothing to adopt
    """
    min_gain = MIN_GAIN if min_gain is None else min_gain
    require_confirm = REQUIRE_CONFIRM if require_confirm is None else require_confirm
    if gain is None or pd.isna(gain):
        return UNCLEAR, "no result"
    confirmed = gain_confirm is not None and not pd.isna(gain_confirm)
    if free:
        # Nothing is paid for adopting it, so any gain above zero is worth keeping, as long as
        # the second block agrees.
        if gain <= 0:
            return NOT, "no gain"
        if confirmed and gain_confirm <= 0:
            return NOT, "the gain did not repeat on the confirm block"
        if require_confirm and not confirmed:
            return UNCLEAR, "above zero, not yet read on the confirm block"
        return HOLDS, "free to adopt and above zero" + (" on both blocks" if confirmed else "")
    if gain < min_gain:
        return NOT, f"gain below {min_gain:g}"
    if low is None or pd.isna(low) or low <= 0:
        return UNCLEAR, "gain large enough, but its interval reaches zero: repeat with more seeds or more rows"
    if confirmed and gain_confirm <= 0:
        return NOT, "the gain did not repeat on the confirm block"
    if require_confirm and not confirmed:
        return UNCLEAR, "passes on the choose block, not yet read on the confirm block"
    return HOLDS, "gain large enough, interval above zero" + (", confirmed" if confirmed else "")


def judge(results, min_gain=None, require_confirm=None):
    """Add `verdict` and `reason` columns to a results table (one row per arm id)."""
    arms = by_id()
    out = results.copy()
    verdicts = []
    for row in out.itertuples(index=False):
        arm = arms.get(row.id, {})
        verdicts.append(verdict(row.gain, getattr(row, "low", None), getattr(row, "gain_confirm", None),
                                bool(arm.get("free", False)), min_gain, require_confirm))
    out["verdict"] = [v for v, _ in verdicts]
    out["reason"] = [r for _, r in verdicts]
    return out


def full_scale_plan(judged, costly_factor=None):
    """The runs of the full-scale stage as a DataFrame.

    1. the control at full scale (the same seeds as the sweep's control);
    2. one run with every arm that holds, switched on together;
    3. for each costly arm that holds, the same run without it.
    Reads and CPU arms need no run of their own: they are applied to the scores of run 2.
    """
    costly_factor = COSTLY_FACTOR if costly_factor is None else costly_factor
    arms = by_id()
    holders = [i for i in judged.loc[judged["verdict"] == HOLDS, "id"] if i in arms and i != "control"]
    trained = [i for i in holders if arms[i]["kind"] == "gpu"]
    applied = [i for i in holders if arms[i]["kind"] != "gpu"]
    rows = [{"run": "control", "files": FULL_FILES, "switched_on": "", "purpose": "the baseline at full scale"}]
    if trained:
        rows.append({"run": "all_that_held", "files": FULL_FILES, "switched_on": ", ".join(trained),
                     "purpose": "every trained arm that held, together"})
        for i in trained:
            if arms[i]["time_factor"] >= costly_factor or arms[i]["runs"] > 1:
                rows.append({"run": f"without_{i}", "files": FULL_FILES,
                             "switched_on": ", ".join(t for t in trained if t != i),
                             "purpose": f"what {i} adds on its own (it is costly to train)"})
    if applied:
        rows.append({"run": "applied_after_scoring", "files": FULL_FILES, "switched_on": ", ".join(applied),
                     "purpose": "no training: applied to the scores of the best run above"})
    return pd.DataFrame(rows)


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    ap = argparse.ArgumentParser(description="judge the sweep and plan the full-scale stage")
    ap.add_argument("--results", required=True, help="CSV with columns id, gain, low, high and optionally gain_confirm")
    ap.add_argument("--min-gain", type=float, default=None)
    ap.add_argument("--no-confirm", action="store_true", help="do not require a second block")
    ap.add_argument("--out", help="write the full-scale plan to this CSV file")
    a = ap.parse_args(argv)
    judged = judge(pd.read_csv(a.results), a.min_gain, False if a.no_confirm else None)
    with pd.option_context("display.max_rows", None, "display.max_colwidth", 80, "display.width", 200):
        print(f"sweep at {SWEEP_FILES} files\n")
        print(judged.to_string(index=False))
        plan = full_scale_plan(judged)
        print(f"\nfull-scale stage at {FULL_FILES} files\n")
        print(plan.to_string(index=False))
    if a.out:
        plan.to_csv(a.out, index=False)
        print(f"wrote {a.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
