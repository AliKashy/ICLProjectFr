"""Additions for a two-stage transaction fraud model.

What this package is
--------------------
A set of small, independent pieces that can be added to a card-fraud model that reads each
account as a sequence of transactions. Each piece lives in one file. Each file says, in its
own docstring, what it does, why it exists, where it goes in the pipeline and what has to be
changed to fit another code base.

How the folders are laid out
----------------------------
settings.py   every name that depends on the data or the machine (columns, paths, code values)
common/       shared helpers: reading files, time keys, "strictly earlier" history, ranking, bootstrap
reads/        reads on scores and files that need no training
features/     new per-row input columns built from raw transactions
encoding/     how numbers and codes are turned into tokens
model/        blocks for the network itself
training/     loss terms, row weights, sampling, teachers
after_model/  what is built from the model's own scores and vectors
merchant/     tables that carry what other accounts did at the same merchant
exports/      columns and tables for other models to consume
proof/        tools for comparing models fairly
sweep/        the testing plan: every arm at a small scale, and what goes on to full scale
tests/        small tests on made-up data; they double as usage examples
README.md     the index of every file, the placeholders and where to start
SWEEP.md      the testing plan in words

Nothing in this package checks where it runs or what version of anything it runs against.
Every file can be edited freely.
"""
