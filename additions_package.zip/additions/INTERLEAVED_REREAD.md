# A re-read after every history layer, and a memory of recent fields

This note travels with two files and is written for whoever fits them into a model that the
files have never seen:

| File | What it is |
|---|---|
| `interleaved_reread.py` | The blocks. Plain PyTorch, no other imports. It is used as it is. |
| `interleaved_wiring_template.py` | A small complete stand-in model with the blocks wired in. The five edits are marked `EDIT n of 5` (and `EDIT 3b`, one line for the second check), every name that belongs to the real model is marked `PLACEHOLDER W1` to `W14` (and `W15` for the optional scored path of scoring), four checks say whether a wiring is right, and a fifth says whether the optional scored path gives the scores of the full path. It runs by itself: `python interleaved_wiring_template.py`. |

Sizes in this note are those of the model the blocks were written for: 64 predictors, a field
width of 48, a stage 1 that runs on 10 tokens (3 summary tokens and 7 field-level inputs made
from the 64 predictor tokens), a stage 2 of width 144 with 4 layers and 8 heads.

## 1. What it adds

Stage 1 squeezes every transaction into one vector, and stage 2 reasons over those vectors. A
single re-read after the last history layer gives field detail back to the head only. The
blocks restore field-level evidence while the history is still being read.

| Design | What it is | Keys per row | New weights | With the bank |
|---|---|---|---|---|
| A | A gated re-read of the row's own fields after every history layer | 64 | 207,076 | 216,676 |
| M | One gated re-read after the last layer, with a memory of the latest 5 earlier rows | 384 | 60,529 | 70,129 |
| AM | Both: a re-read after every layer, each with that memory | 384 | 207,556 | 217,156 |

- **The bank.** Every re-read queries a bank of field representations, 48 numbers each, one
  per predictor. `PredictorBank` makes it from the tokenizer's predictor tokens, kept before
  they are grouped for stage 1: every predictor token reads the 10 stage-1 outputs of its own
  transaction once. Stage 1 itself is not touched. The bank adds 9,600 weights.
- **The memory.** With 5 rows back, a row's bank holds its own 64 representations and those of
  its latest 5 eligible earlier transactions: 64 + 5 x 64 = 384 keys. Eligible means a real row
  of the same sequence in a strictly earlier second, which is the rule of the stage-2 mask.
  Every key carries a learned vector for its look-back position (0 for the row itself, 1 to 5
  for the earlier rows) and one for its place among the 64 fields.
- **The gate.** Every layer has a re-read of its own, with its own weights, and its question
  comes from a vector that the layers before it have changed. The gate sees the question and
  the answer and gives each of the three segments a number between 0 and 1, so a re-read that
  brings nothing new can be shut out. `gate_report()` gives the average gate per layer.
- **The start.** The layer that writes a re-read back starts at zero. A trained model that is
  given the blocks scores exactly as before until training moves them.

The keys are representations, so the memory compares by meaning. A test of exact equality,
such as "the merchant was seen in the last five rows", is better added as an input column.

## 2. The task

Given: the two files, this note, and the code of the model in use.

Wanted:

1. The model's constructor and `forward` with the five edits of section 4 made in them (and
   edit 3b, which only serves the second check), and nothing else changed.
2. The table of section 3 filled in: for each placeholder, the name or value it has in the
   model in use.
3. The output of the four checks of section 6, run on the model in use with one of its own
   batches.

Three rules hold throughout:

- `interleaved_reread.py` is not edited, apart from the six `PLACEHOLDER` values at its top.
- What the trained model computes is not changed. Tensors are kept and one call is replaced;
  no existing layer, input or mask is altered.
- A row uses only itself and real rows of its own sequence in strictly earlier seconds. The
  blocks keep that rule when they are given the times and the mask of real rows that the mask
  of stage 2 is built from.

## 3. The placeholders

Each line is something that has to be found in the model in use, or decided. The stand-in
shows every one of them in place.

| Mark | What belongs there | Where to find it | In the stand-in |
|---|---|---|---|
| W1 | The predictor tokens: one token of width 48 per predictor, before they are grouped for stage 1. Brought to `[B, T, 64, 48]`. | The result of the tokenizer call in `forward`, before the step that turns 64 tokens into 7 field-level inputs. | `predictor_tokens` |
| W2 | The output sequence of stage 1 for the same transactions (summary tokens and field-level tokens, any order). Brought to `[B, T, 10, 48]`. | The result of the stage-1 encoder call, before the summary outputs are picked out of it. | `stage1_tokens` |
| W3 | The times of the rows, `[B, T]`, integers. | The batch entry the stage-2 mask is built from. | `batch["time_seq"]` |
| W4 | The mask of real rows, `[B, T]`, True on real rows. A mask that is True on padding is handed over as `~mask`. | The batch entry that marks real rows or padding. | `batch["mask"]` |
| W5 | How many units of the times make one second: 1 for whole seconds, 1_000_000_000 for nanoseconds. It must be the unit the stage-2 mask is built with. | The line that builds the stage-2 mask: whether and by what the times are divided. | `TIME_UNITS_PER_SECOND` |
| W6 | The history layers: an `nn.TransformerEncoder`, a list of its layers, or the model's own loop over its layers. | What the stage-2 part of `forward` runs. | `self.history_layers` |
| W7 | What goes into the history layers and the mask they take: float (zero or a learned bias where reading is allowed, minus infinity where it is not) or bool (True where it is not), of shape `[L, L]`, `[B, L, L]`, `[B * heads, L, L]` or `[B, heads, L, L]`. | The arguments of the stage-2 call. | `x`, `mask` |
| W8 | How many positions in front of the rows are not transactions: 1 when a learned summary position sits in front, else 0. | Whether anything is joined in front of the transaction vectors before stage 2. | `n_prefix` |
| W9 | The key padding mask, when stage 2 is called with one. | A `src_key_padding_mask=` argument in that call. | none |
| W10 | Four sizes: field width, width of stage 2, heads, number of history layers. | The stage-1 and stage-2 layer definitions. | 48, 144, 8, 4 |
| W11 | The saved weights of the trained model. | The checkpoint file; its weights are usually under `"state_dict"`. | `trained.state_dict()` |
| W12 | Where the optimiser is built. | The model's own method for it, or the training script. It can stay as it is. | `torch.optim.AdamW` in the check |
| W13 | The design: which layers get a re-read, and how many earlier rows the memory holds. | A decision: A, M or AM of section 1. | `DESIGNS` |
| W14 | The number of predictors per transaction (`num_fields`, the 64 of W1), and the dropout of the new blocks. | The tokenizer's output; the dropout the model's own layers use. | 64, the model's dropout |
| W15 | Optional, for scoring only: the mark of the rows whose score is kept, `[B, T]`, True on them (the last real row of every window when one window is scored per transaction), and the name of the batch entry the model reads it from. That name is handed to the fifth check as `key`. | The scoring script: which row of each window it keeps. | `batch["scored"]` |

The six values at the top of `interleaved_reread.py` repeat W5, W10, W13 and W14 as defaults:
`FIELD_DIM` 48, `NUM_HEADS` 8, `HISTORY_LAYERS` 4, `NUM_BACK` 5, `NUM_FIELDS` 64 and
`TIME_UNITS_PER_SECOND`. Every one of them can also be given in the constructor call, as the
stand-in does.

## 4. The five edits

1. **Constructor.** Build the blocks (W10, W14, W5, W13):

       from interleaved_reread import InterleavedReread, PredictorBank
       # inside the package: from additions.model.interleaved_reread import ...

       self.predictor_bank = PredictorBank(field_dim=48, num_heads=8, dropout=0.1)
       self.interleaved = InterleavedReread(width=144, history_layers=4, after_layers=None,
                                            field_dim=48, num_heads=8, num_back=5, dropout=0.1,
                                            units_per_second=TIME_UNIT, num_fields=64)

   `TIME_UNIT` is W5 and is looked up, not copied: the unit the mask of stage 2 is built
   with, 1 for whole seconds and 1_000_000_000 for nanoseconds. One value of the times shows
   which: about 1.7e9 is seconds, about 1.7e18 is nanoseconds. `after_layers=None` puts a
   re-read after every layer; `after_layers=(4,)` after the last only. Design A is
   `num_back=0`. `history_layers` is the model's own number of history layers: `run` counts
   the layers of the stack it is handed, but a model that runs its own loop (edit 4) is not
   seen by the block, and there a wrong number is shown only by the fifth check (section 8).

2. **Keep two tensors that already exist** (W1, W2), brought to `[B, T, ...]` with `reshape`
   when the model holds them as `[B * T, ...]`:

       predictor_tokens = tokens.reshape(B, T, 64, 48)            # before the grouping step
       stage1_tokens = stage1_out.reshape(B, T, 10, 48)           # the whole stage-1 output

3. **Once per batch, before stage 2** (W3, W4):

       bank = self.predictor_bank(predictor_tokens, stage1_tokens)       # [B, T, 64, 48]
       memory = self.interleaved.prepare(bank, times, valid)

   `prepare` always gets all three: the bank, the times and the mask of real rows.

   **3b, for the second check only.** Two attributes in the constructor and one line after
   `prepare`; it does nothing while the switch is off:

       self.look_at_wiring, self.wiring_share = False, None                      # constructor

       if self.look_at_wiring:                                                   # after prepare
           self.wiring_share = self.interleaved.look_at_wiring(mask, times, valid, memory,
                                                               n_prefix=0)

   It is handed exactly what stage 2 and the block are handed (W7, W3, W4, W8), and
   `key_padding=...` as well when stage 2 is called with one (W9).

4. **Replace the one call that runs the history layers** (W6, W7, W8, W9):

       x = self.history_layers(x, mask=mask)                                         # before
       x = self.interleaved.run(self.history_layers, x, mask, memory, n_prefix=0)    # after

   A stage 2 that is called with a `src_key_padding_mask` hands it to `run` as
   `key_padding=...`.

   A stage 2 that runs its layers in a loop of its own keeps that loop, and so does one whose
   mask carries a learned bias. It calls

       rows = self.interleaved.after_layer(number, rows, memory)

   after each layer, with `number` counting from 1 and `rows` holding the transactions only,
   `[B, T, 144]` (without any position in front). A final norm after the loop stays after the
   loop: the re-read of the last layer goes before it, as `run` does. Such a model must build
   the block with `history_layers` equal to its own number of history layers, since the block
   cannot see the loop; the fifth check shows a wrong number.

5. **Nothing after stage 2 changes.** The re-read the model already has and the head stay.

## 5. Slips that leave no trace in the scores

A freshly grown model scores exactly as the trained model whatever the block is handed, so
these slips cannot be seen in the scores. The second check of section 6 is there for them.

| Slip | What it does | What shows it |
|---|---|---|
| A time unit that is not the one of the stage-2 mask | The memory puts rows of one second in an order and lets one read the other, or gathers nothing. | Check 2 below 100%. |
| A mask of real rows of the wrong polarity (True on padding) | Real rows get no re-read at all; the blocks work on padding and learn nothing. | Check 2 below 100%, with the line "valid looks reversed"; check 4 counts zero new weights with a gradient. |
| `prepare` without the times or without the mask of real rows | The memory holds the row's own fields only, and padded slots are not kept out. | Check 2 gives 0 and prints "the memory is not whole"; `prepare` prints a note. |
| The times and the mask of real rows swapped in `prepare` | The memory holds no earlier row at all. | Check 2 gives 0 and prints that the memory does not hold the earlier rows the times imply; `prepare` prints a note. |
| A count of front positions (W8) that is not the model's | The rows and their bank no longer line up. | With `run`: an error about sizes at the first call. With a loop of its own: an error about sizes in check 2, or check 2 below 100% when the rows passed to `after_layer` still include the front position. |
| `times` or `valid` of another layout than the mask | The memory gathers rows the mask does not allow. | Check 2 below 100%. |
| The grouped 7 tokens handed over as the bank | Nothing is restored that stage 1 did not already have. | An error about sizes (7 against 64). |
| A checkpoint whose names do not match the model | Trained weights are lost. | `start_from` lists them as not used; check 1 is not zero. |

Two more things belong to the history layers themselves and are not changed by the blocks.
What goes into stage 2 has to be finite on padded slots (zero is the usual choice). And the
masks together must leave every position at least itself to read.

## 6. The four checks

`interleaved_wiring_template.py` holds them as functions that take a model and a batch. They
are run on the stand-in by `python interleaved_wiring_template.py`, which must print "yes"
five times for each design (the fifth is the check of the optional scored path, section 8). On the model in use:

| Check | Call | Must give |
|---|---|---|
| 1. Equal scores before training | `equal_scores(trained, grown, batch, real=...)` | below 1e-5 |
| 2. The block is wired the way the mask implies | `wiring_agrees(grown, batch)`, which needs edit 3b | 1.0, printed as 100% |
| 3. Later rows change nothing earlier | `later_rows_change_nothing(grown, batch, alter, real=..., time=...)` | first number below 1e-4, second above it |
| 4. Only the new weights move | `only_new_weights_move(grown, batch, loss)` | an empty list, and a count above zero |

- Every check scores in evaluation mode and without gradients.
- Check 2 says that the memory and the mask of stage 2 follow the same rule. It does not say
  that the rule is right: a mask built with the wrong time unit agrees with a memory built
  with the same wrong unit. Design A does not read the times; the check still compares the
  unit, because the same block is given a memory in designs M and AM.
- `real` and `time` are the names of the batch entries of W4 and W3; they default to the
  stand-in's `"mask"` and `"time_seq"`. `real` must be True on real rows. A batch that marks
  padding gets such an entry first, `batch["valid"] = ~batch["pad"]`, and `real="valid"`.
  A padding mask passed as `real` makes check 1 compare padding only.
- `alter(batch, rows)` returns a copy of the batch in which the feature inputs of the slots
  in `rows` are replaced by other values. The times, the mask of real rows and the labels
  stay as they are.
- `loss(model, batch)` returns the training loss of the model in use.
- The count of check 4 is the number of weight tensors of the new parts that got a gradient
  in the first step. A fresh block gives one per re-read (1 for design M, 4 for A and AM with
  four history layers): only the zero-start write-back layer of each re-read gets a gradient at
  first, because everything before it is reached through its zero weights. Zero means the new
  blocks get no learning signal.
- Check 4 trains on the batch without the mark of scored rows: an entry under `key`
  (`"scored"` by default) is left out, since training takes the full path.
- The stand-in has an `alter` and a `loss` for its own batch (`alter_rows`, `row_loss`); the
  model in use needs its own two.

## 7. Growing the trained model and a first run

    from interleaved_reread import start_from, train_only

    model = TheModel(...)                                  # with the blocks of edit 1
    taken, fresh, unused = start_from(model, torch.load(path, map_location="cpu"))
    train_only(model, [model.interleaved, model.predictor_bank])

`start_from` copies every trained tensor with the same name and shape and prints what went
where. `fresh` must hold the new blocks only and `unused` must be empty; a trained tensor in
`unused` is a part of the trained model that was lost. The trained model for check 1 is built
the same way, without the blocks: `trained = TheModel(...)`, then `start_from(trained, ...)`,
which must report nothing fresh and nothing unused.

`train_only` holds the rest of the model still, so any change in the scores comes from the
new blocks alone and the trained model itself is the comparison: no second control run is
needed. The number of weights it returns is the "With the bank" figure of section 1. A model
with batch normalisation layers puts those in evaluation mode as well.

- **Arms.** With three GPUs: A, M and AM, one each. With two: A and AM. With one: AM.
- **Learning rate.** 1e-3 for the new blocks is a starting value: they begin at zero and are
  small. A warm-up over a few hundred updates and a fall to zero by the end of the run keep
  the last updates from being the noisiest.
- **Data and loss.** Those the model was trained with. Whatever part of the files fits the
  hours available is enough for a first reading.
- **Scoring.** Exactly as the trained model was scored, on the same rows, counted at the same
  alert cut, and on rows the new blocks were not trained on: some 200,000 new weights can fit
  the rows they saw and still score worse elsewhere. With about 1,400 frauds in a read, a difference of a few frauds is inside the
  noise; a paired interval that resamples whole accounts says whether a difference is resolved.
- **The gates.** After a scoring batch, `model.interleaved.gate_report(rows)` gives the
  average gate per layer over the rows chosen: the mask of real rows, the fraud rows, or,
  when scoring reads only one row of each window, the mask of those scored rows.

A run of a few hours on a held-still model is a first reading. It shows whether the blocks
find usable evidence. It understates what they can do, because the layers around them were
trained without them and cannot adapt.

## 8. Memory and speed

The keys and the values are the large tensors. Each holds rows x keys x 48 numbers and stays
alive for the backward pass.

| Keys per row | Per thousand rows, keys | Per thousand rows, values |
|---|---|---|
| 64 | 12.3 MB | 12.3 MB |
| 384 | 73.7 MB | 73.7 MB |

Figures are for 32-bit numbers; in mixed precision keys and values take half. When the GPU
runs out of memory, halve the batch size or lower the number of rows back.

At scoring the blocks are heavy. This was measured on a CPU (4 threads) with the stand-in
model of `interleaved_wiring_template.py` at these shapes: 64 windows of 121 rows, every row
scored, no gradients. The ratio on a GPU has to be measured.

| Model | Milliseconds per batch | Against the model without the blocks |
|---|---|---|
| without the blocks | 372 | 1.00 |
| A | 868 | 2.33 |
| M | 1,064 | 2.86 |
| AM | 1,350 | 3.63 |

Of the time of AM, the bank (`PredictorBank`) takes 21%, building the memory (gathering the
keys and values, two tensors of `[B, T, 384, 48]`) 23%, the re-reads 26%, stage 1 13% and the
history layers 10%. The keys and values take about 147 KB per row at 384 keys.

Two options cut this at scoring. Both are off by default. In evaluation mode the scores they
give are equal to those of the full path up to rounding (below 1e-5). In training mode the mark
of scored rows is left unused, and one printed line says so: training always takes the full
path.

- **Scored rows.** `prepare(bank, times, valid, scored=...)` with a mark of the rows whose
  score is kept (W15). The re-read after the last history layer then runs on those rows only,
  since nothing reads the other rows after it. In design M, where no re-read follows an earlier
  layer, the memory is gathered for the scored rows only, and the bank is needed only for the
  rows `interleaved.rows_read(times, valid, scored)` names: the scored rows and their latest
  5 eligible earlier rows. That mark is handed to `predictor_bank(..., rows=...)`, which works
  out those rows only. The stand-in shows the lines, marked OPTIONAL, in edit 3. After stage 2
  the rows that are not scored may hold anything; only the scored rows are read.
  `run` takes the last layer from the stack it is handed, not from `history_layers`. In design
  M the memory for scored rows serves only a re-read after the stack's last layer, and any
  other stack gets a plain error that names both numbers and says how to build the block. A
  re-read listed after a layer the stack does not have never runs, and one printed line says
  so. A model with its own loop calls `after_layer`, which takes the last layer from
  `history_layers`, so that number must be the model's own.
  It helps only when rows are scored one window at a time (one window per scored transaction,
  only its last row kept): a great deal for design M, and about a quarter of the re-read cost
  for A and AM, whose earlier re-reads still need every row. In all-position scoring, where
  every row of a chunk is scored, it does nothing.
- **Lean memory.** `interleaved.rows_per_part = 1024` (or `rows_per_part=1024` in the
  constructor). The memory then keeps only the projected bank `[B, T, 64, 48]` and the slots of
  the earlier rows, and every re-read gathers its keys and values for 1,024 rows at a time. It
  bounds the peak memory of scoring without gradients, so that the batch does not have to
  shrink. It gathers once per re-read and so costs time (four gatherings in AM instead of one).
  It helps only when memory forces the batch down. For design A, whose memory is the bank
  itself, it saves nothing and costs a little time; leave it off there. With gradients switched
  on it saves little, since every part is kept for the backward pass.

Measured the same way, with each path's largest held tensors (the memory, and with the lean
memory the keys and values of one part), and with one scored row per window (the last real one):

| Design | Full path | Scored path | Lean memory, 1,024 rows a part |
|---|---|---|---|
| A | 919 ms, memory 190 MB | 835 ms, memory 190 MB | 953 ms, memory 190 MB + 25 MB a part |
| M | 1,204 ms, memory 1,142 MB | 533 ms, memory 9 MB | 1,174 ms, memory 190 MB + 151 MB a part |
| AM | 1,353 ms, memory 1,142 MB | 1,286 ms, memory 1,142 MB | 2,134 ms, memory 190 MB + 151 MB a part |

The model without the blocks took 361 ms in that run. The bank itself holds 95 MB on every path.

Times on a shared machine are noisy. Counts are not: `interleaved.work_report(bank)` says, for
the latest call, how many rows every re-read worked out (`rows`), how many rows its memory was
gathered for (`memory_rows`), and how many rows the bank worked out (`bank_rows`, the count that
`PredictorBank` keeps). Rows are counted as slots, padded slots included. For the stand-in in
design M on 64 windows of 121 rows, every row real, with the last row of each window scored:

| Path | Last re-read, rows | Memory, rows | Bank, rows |
|---|---|---|---|
| Full | 7,744 | 7,744 | 7,744 |
| Scored | 64 | 64 | 384 |

384 is the 64 scored rows and their 5 earlier rows each. In A and AM the scored path brings
the last re-read down to 64 rows; the earlier re-reads, the memory and the bank stay at 7,744.
A last re-read that still works out 7,744 rows says that the scored path was not taken; in
design M a bank at 7,744 says that it was called without `rows=`.

A model that takes the scored path runs the fifth check on one of its own batches:

| Check | Call | Must give |
|---|---|---|
| 5. The scored path gives the scores of the full path | `scored_rows_agree(grown, batch, scored, real=..., key=...)` | below 1e-5 |

`scored` is the mark of W15; `last_real_rows(batch["mask"])` in the template makes the mark of
the last real row of every window. The check compares the scored rows only.

- The check puts the mark into the batch under `key` (`"scored"` by default). The model must
  read its mark from its batch under that same name, or the marked pass is the full pass.
- When not every real row is scored and the last re-read of the marked pass still worked out
  every real row (or no re-read ran), the model did not take the scored path: one line says so
  and the answer is infinity. That catches a mark read under another name, a `prepare` called
  without `scored=`, and a `history_layers` that is not the model's own number of layers.
- It does not see a bank called without `rows=`: the scores stay right, only the time is lost.
  The work report shows it (`bank_rows` at every slot).
- It assumes that checks 2 and 4 pass. A mask of real rows of the wrong polarity, for one,
  gives a passing answer here and is caught by those two.
