# The testing plan: a complete sweep at a small scale, then the survivors at full scale

This file describes how the additions in this package are meant to be tested. The plan has
two stages.

1. **The sweep.** Every addition is tried once against the same control, at a scale that is
   large enough to be believed and small enough to afford (250 training files by default).
2. **The full-scale stage.** Whatever held up in the sweep is trained together at full scale
   (1,000 training files by default) and compared with the control at that scale.

The code for both stages is in `additions/sweep/`. Nothing in it starts a training run: it
produces the list of runs, their cost, and afterwards the verdicts.

## The pieces

| File | What it holds |
|---|---|
| `sweep/arms.py` | Every experiment ("arm") as one entry: what it changes, which files hold its code, whether it needs a training run, how long that run takes compared with the control, and what it depends on. |
| `sweep/plan.py` | The sweep as an ordered list, with the number of training runs and the GPU hours and days. |
| `sweep/promote.py` | The rule that decides whether an arm "holds", and the list of runs for the full-scale stage. |

## The order of the sweep

Cheap arms run first, because their results decide which costly arms are worth running.

| Tier | What it is | Training runs |
|---|---|---|
| control | The current recipe at the sweep scale, three seeds. Three seeds give the run-to-run spread; without it a single run cannot be judged. | 3 |
| reads | Reads on the control's scores: which rows the alerts go to, how sticky alerts should be, the average of the seeds, the amount tilt, the censuses, what the model adds to a blend with other models' scores where those exist, and what its exported vector is worth on several targets. | none |
| cpu | Screens on the CPU from the control's export: every family of the feature catalogue, the exact-match and outcome-history columns, the account risk state, a tree stage, the merchant tables, the export bundle. | none |
| switches | A setting changes: which rows count in the loss, precision, account sampling, how much history training rows see. | one each (none for averaged weights, which are kept during the control runs) |
| inputs | New inputs. Only the families that passed their CPU screen get a run. | one each (two for the model's own earlier scores, which need a first pass) |
| model | The network changes: summary tokens and a wider history stage, the re-read block, a gated re-read after every history layer, a memory of recent field representations, earlier bank decisions inside the network, and others. | one each |
| training | The loss changes: extra heads, a pairwise term, a student of three seeds, a look-ahead teacher. | one or two each |
| waiting | Arms that need something delivered first (another model's scores). | one each |

`python additions/sweep/plan.py --list` prints every arm with what turns it on.

## What the sweep costs

The cost is the number of training runs times the time of one run. The plan knows the
number of runs and how much longer than the control each one takes; the time of one control
run at the sweep scale has to be measured and filled in:

    python additions/sweep/plan.py --hours-per-run 20 --gpus 2

With every arm switched on, the sweep is 41 training runs, which take as long as 44.4
control runs. At 20 hours per run on one GPU that is 888 GPU hours, or 37 days; on four
GPUs it is 9.25 days when the runs divide evenly. Those figures are an example: the real
time per run must come from a real run.

Three ways to bring the cost down, in order of how much they save:

1. Run the reads and the CPU screens first and give a training run only to the input
   families that passed. A family that adds nothing to a tree model on top of the model's
   own score rarely adds anything to the network.
2. Leave out arms with `--skip`, or shorten every run to a fixed number of updates (the
   number at which the control was best, plus a margin), since the best checkpoint has
   usually come early.
3. Use more GPUs: the runs of one tier do not depend on each other.

## How each arm is read

Every arm is compared with the control on the same rows, with the same measure:

- the share of all frauds inside the top 0.6 percent of rows by score
  (`additions/common/ranking.py`);
- only the rows of the scored month, and only the rows the benchmark keeps
  (`additions/reads/eligible_rows.py`);
- the difference between arm and control with an interval from the paired bootstrap that
  resamples whole accounts (`additions/common/bootstrap.py`);
- on two separate blocks of evaluation files: one to choose, one to confirm. A block of
  about 100 files or more keeps the interval narrow enough to see half a point.

The reads produce one results file with the columns `id, gain, low, high, gain_confirm`.

## What "holds" means

The rule is fixed before the results are seen. With dozens of arms read on the same rows,
the best-looking arm is often only the luckiest, so the rule asks for more than "it was
above the control once":

- An arm that costs something (a slower model, a new input, a new training step) holds when
  its gain on the choose block is at least 0.005, the lower end of its interval is above
  zero, and its gain on the confirm block is above zero.
- An arm that costs nothing to adopt (a scoring rule, a setting) holds when its gain is
  above zero on both blocks.
- An arm whose gain is large enough but whose interval reaches zero is "unclear": repeat it
  with two more seeds or on more rows before deciding.

The three numbers are constants at the top of `sweep/promote.py`.

    python additions/sweep/promote.py --results sweep_results.csv --out full_scale_plan.csv

## The full-scale stage

Gains that reach the same frauds do not add, so the arms that held are not taken to full
scale one by one. The full-scale stage is:

1. the control at full scale;
2. one run with every trained arm that held, switched on together;
3. for each arm that is costly to train, the same run without it, to show what it adds;
4. the reads and scoring rules that held, applied to the scores of the best run.

The comparison that matters is run 2 against run 1, on rows that were not used in the
sweep.
