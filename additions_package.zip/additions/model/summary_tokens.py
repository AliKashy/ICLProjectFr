"""Stage 1 with several summary tokens per transaction.

What this file does
-------------------
`SummaryTokenEncoder` is the first stage of the two-stage model. It takes the field tokens
of one transaction (one token per input field), puts K learned summary tokens in front of
them, runs a small transformer over the lot, and joins the K summary outputs into one vector
of width K * d for that transaction. With K = 1 it is the original stage 1. It can also
return the outputs of the field tokens, which the block in reread_block.py reads again
after history.

Why it exists
-------------
Stage 2 never sees the fields of a transaction. It sees only the vector that stage 1 hands
over. With one summary token that vector is as wide as a single field token, and everything
about the row has to pass through it: the amount, where and how the card was used, which
checks passed, how long ago the previous row was. One narrow vector between the two stages
limits what history can use. Whatever stage 1 did not keep is gone, and stage 1 has to decide
what to keep before it knows anything about the account.

Fraud is often visible only as a pattern across the rows of a run: the same odd amount
three times, a first card-not-present row after months of card-present ones, a check that
used to pass and now fails. Stage 2 can compare the rows of an account only on what their
vectors carry. Several summary tokens let stage 1 keep several views of one row, and stage 2
then runs at the larger width. The extra cost is modest, because most of the arithmetic of
the model is spent in stage 1 on the field tokens, and their width does not change.

A downstream tree model gains as well. The joined vector splits back into K parts that
describe the transaction without any history, which is a different thing from the
history-aware vector that stage 2 produces, and both can be exported.

Where it goes
-------------
Preprocessing and tokenizer, then this block, then stage 2. In the original code it takes
the place of the `txn_cls` token and the `token_encoder` call at the top of
`FTTransformerHierModel.forward`; the field tokens come from `FeatureTokenizer`. Its output
goes to history_stage.py, whose width is then K * d (or anything else, through the
projection there).

What to change for the pod
--------------------------
`settings.EMBED_DIM` (width of a field token), `settings.NUM_HEADS`, `settings.STAGE1_BLOCKS`,
and `NUM_SUMMARY` below. With more input fields the cost of stage 1 grows with the square
of the number of tokens per transaction; the number of summary tokens adds little to that.
A stored or exported transaction vector becomes K times as wide, so whatever consumes it has
to be fitted again.

How to try it
-------------
    stage1 = SummaryTokenEncoder(num_summary=3)
    vectors = stage1(tokens)                                   # tokens [B, T, F, 48] -> [B, T, 144]
    vectors, fields = stage1(tokens, return_fields=True)       # fields [B, T, F, 48]
    python -m pytest -q additions/tests/test_model_summary_tokens.py
"""
import torch
import torch.nn as nn

from additions.model._shared import encoder_stack, pick, run_blocks

# PLACEHOLDER: how many summary tokens a transaction gets when the caller does not say; 1 is the
# original design, 3 makes the transaction vector three field tokens wide.
NUM_SUMMARY = 3


class SummaryTokenEncoder(nn.Module):
    """Encodes every transaction by itself into one vector made of K summary outputs.

    embed_dim      width d of a field token; None reads settings.EMBED_DIM
    num_summary    number K of summary tokens; None reads NUM_SUMMARY
    num_heads      attention heads; None reads settings.NUM_HEADS
    num_blocks     transformer blocks; None reads settings.STAGE1_BLOCKS
    ff_multiplier, dropout, attn_dropout   as in _shared.encoder_stack

    `out_dim` is the width of the vector it returns: K * d.
    """

    def __init__(self, embed_dim=None, num_summary=None, num_heads=None, num_blocks=None, ff_multiplier=4,
                 dropout=0.1, attn_dropout=0.1):
        super().__init__()
        self.embed_dim = pick(embed_dim, "EMBED_DIM")
        self.num_summary = NUM_SUMMARY if num_summary is None else int(num_summary)
        self.out_dim = self.num_summary * self.embed_dim
        # The summary tokens are learned vectors, the same for every transaction. They carry no input of
        # their own: what they hold at the end is what they gathered from the field tokens. Each starts
        # from its own small random vector, which is what lets them grow into different views.
        self.summary = nn.Parameter(torch.zeros(1, self.num_summary, self.embed_dim))
        nn.init.normal_(self.summary, std=0.02)
        self.encoder = encoder_stack(self.embed_dim, pick(num_heads, "NUM_HEADS"), pick(num_blocks, "STAGE1_BLOCKS"),
                                     ff_multiplier, dropout, attn_dropout)

    def forward(self, tokens, return_fields=False):
        """Encode the field tokens of every transaction.

        tokens          float [..., F, d]: F field tokens per transaction; the leading dimensions are free,
                        usually [B, T] (sequences and rows) or [N] (transactions)
        return_fields   also return what the field tokens look like after the blocks

        Returns float [..., K * d], the K summary outputs side by side. With `return_fields` it
        returns the pair (that vector, float [..., F, d]).

        Every transaction is encoded by itself. No transaction reads another one here, so the
        time rule has nothing to guard in this stage: a row's vector depends on that row's own
        fields and on nothing else. Padded slots are encoded too (their fields are all zero)
        and their vectors are ignored later.
        """
        lead = tokens.shape[:-2]
        n_fields, d = tokens.shape[-2:]
        flat = tokens.reshape(-1, n_fields, d)                                    # [N, F, d]
        # Summary tokens first, field tokens after them. All of them read each other freely: they all
        # belong to the same transaction.
        x = torch.cat([self.summary.expand(flat.shape[0], -1, -1), flat], dim=1)  # [N, K + F, d]
        # `run_blocks` runs the stack block by block. It also returns `x` unchanged when the stage has
        # zero blocks, and it computes the same thing in training and in scoring, so a row scored under
        # torch.no_grad() gets the vector it got in training (at dropout zero).
        out = run_blocks(self.encoder, x)
        k = self.num_summary
        # Joining the K outputs side by side (not adding or averaging them) is the point: the hand-off to
        # stage 2 becomes K times as wide.
        vectors = out[:, :k].reshape(*lead, k * d)
        if return_fields:
            return vectors, out[:, k:].reshape(*lead, n_fields, d)
        return vectors
