"""A small encoder for slow account fields, run once per sequence.

What this file does
-------------------
`ProfileEncoder` turns the slow fields of an account (how long it has existed, its limit,
its product, when the card was issued, when the address last changed) into two vectors.
Each field becomes one narrow token, one transformer block lets the tokens read each other,
and two learned queries pool them. The two vectors are put in front of the rows of stage 2
as two extra positions that every row may read. Two helpers prepare the inputs:

    days_before        a date as "how long before the row", never negative
    first_row_values   the values on the first real row of every sequence

Why it exists
-------------
Who the account is changes what a transaction means. A card issued last week, an address
or a phone number changed a few days before a run of unusual purchases, a limit raised
just before it is used up: these are the usual traces of an account that has been taken
over or was opened to be abused. The fields that say so change rarely, so they are the
same on almost every row of a sequence.

Giving each of them a token on every transaction would be the costly way to use them. The
attention of stage 1 grows with the square of the number of tokens per transaction, and
the same values would be encoded again for every row. Here they are encoded once per
sequence, with narrow tokens, and handed to stage 2 as context. Every row then reads its
own fields and its history against the background of the account. A downstream tree model
gains the two vectors as an account-level description that changes rarely and is cheap to
store.

Where it goes
-------------
Raw files, then the profile values of the FIRST row of every sequence, then this encoder,
then stage 2 as a `prefix` (history_stage.py puts it in front of the rows and
masks.with_prefix opens it to every row). In the original code the values would be
collected where the sequences are built (`SequenceBuilder._encode_file` and the builder of
the all-position sequences) and the two positions would be added in
`FTTransformerHierModel.forward` in front of the transaction vectors.

The values come from the first row because of the time rule: they were stamped in the first
second of the sequence, so no row reads a value that was written after its own second. A
row that shares that first second reads values stamped in its own second on its own
account, which for slow fields are the values it carries itself. Later rows read values
that are a little out of date, by at most the span of one sequence, which costs little for
fields that change rarely.

What to change for the pod
--------------------------
Which columns go in: only fields stamped at the time of the transaction. A column that was
written when the file was extracted lies after the fraud on accounts with fraud and gives
the label away; additions/features/asof_audit.py tells the two kinds apart, and a column
that fails it must stay out. `days_before` does not repair such a column: a date at or
after the row comes out as zero, and that zero is itself the giveaway. Numeric fields need
the same frozen scaling as the other numeric inputs. `PROFILE_TOKEN_DIM`, `PROFILE_HEADS`
and `PROFILE_QUERIES` below set the size; `out_dim` must be the width of stage 2.

How to try it
-------------
    encoder = ProfileEncoder(num_numeric=4, cardinalities=[6, 3], out_dim=144)
    numeric = first_row_values(per_row_numeric, batch["mask"])        # [B, T, 4] -> [B, 4]
    prefix = encoder(numeric, codes)                                  # [B, 2, 144]
    history = stage2(vectors, batch["time_seq"], batch["mask"], prefix=prefix)
    python -m pytest -q additions/tests/test_model_profile_encoder.py
"""
import numpy as np
import torch
import torch.nn as nn

from additions.common import timekeys
from additions.common.timekeys import MISSING_SECOND
from additions.model._shared import encoder_stack, pick, run_blocks

# PLACEHOLDER: width of a profile token; narrow on purpose, because a slow field carries little.
PROFILE_TOKEN_DIM = 16

# PLACEHOLDER: attention heads inside the encoder; PROFILE_TOKEN_DIM must be a multiple of it.
PROFILE_HEADS = 4

# PLACEHOLDER: how many vectors the encoder hands to stage 2 (each becomes one position in front of the rows).
PROFILE_QUERIES = 2


def days_before(dates, row_times, log=True):
    """How long before the row a date lies.

    dates       one date per row: datetimes, text that pandas can parse, or seconds [rows]
    row_times   the time of the row itself, in the same forms [rows]
    log         True returns log(1 + days), which keeps a date of twenty years ago and one of last week
                on one scale; False returns days

    Returns float32 [rows]; a missing date gives a missing value.

    A date at or after the row gives 0, never a negative number. A date field that is honest
    (stamped at the transaction) is never after the row, so nothing is lost. The clamp only
    stops the network from reading how far into the future a dishonest date lies; it does
    not make such a column safe to use.
    """
    date_secs, row_secs = timekeys.seconds(dates), timekeys.seconds(row_times)
    known = (date_secs != MISSING_SECOND) & (row_secs != MISSING_SECOND)
    # Unknown times are replaced by 0 before the subtraction so that the marker for "missing" (the
    # smallest integer) never takes part in arithmetic.
    seconds = np.maximum(np.where(known, row_secs, 0) - np.where(known, date_secs, 0), 0)
    days = np.where(known, seconds / 86_400.0, np.nan)
    return (np.log1p(days) if log else days).astype(np.float32)


def first_row_values(values, valid):
    """The values that the first real row of every sequence carries.

    values   tensor [B, T, ...]: a per-row quantity laid out like the batch
    valid    bool [B, T]: True on real rows

    Returns tensor [B, ...]. A sequence without any real row gives the values of slot 0.

    The first real row is the earliest row of the sequence. Taking the profile from it, and
    not from a later row or from the latest known state of the account, is what makes it
    lawful for every row of the sequence to read the result.
    """
    first = valid.to(torch.int64).argmax(dim=1)                   # the first True of every sequence
    return values[torch.arange(values.shape[0], device=values.device), first]


class ProfileEncoder(nn.Module):
    """Slow account fields in, a few context vectors for stage 2 out.

    num_numeric     number P of numeric profile fields (0 for none)
    cardinalities   table size of each of the Q code fields (empty for none)
    out_dim         width of the vectors handed to stage 2; None reads settings.EMBED_DIM
    token_dim       width of a profile token; None reads PROFILE_TOKEN_DIM
    num_heads       attention heads; None reads PROFILE_HEADS
    num_queries     vectors handed to stage 2; None reads PROFILE_QUERIES
    ff_multiplier, dropout   as in _shared.encoder_stack
    """

    def __init__(self, num_numeric, cardinalities=(), out_dim=None, token_dim=None, num_heads=None, num_queries=None,
                 ff_multiplier=4, dropout=0.1):
        super().__init__()
        d = PROFILE_TOKEN_DIM if token_dim is None else token_dim
        heads = PROFILE_HEADS if num_heads is None else num_heads
        self.num_queries = PROFILE_QUERIES if num_queries is None else num_queries
        # A numeric field becomes a token as in the field tokenizer of the model: value times a learned
        # vector, plus a learned vector. A field without a value gets a learned vector of its own, so
        # "not known" is not mistaken for the value zero.
        self.weight = nn.Parameter(torch.empty(num_numeric, d))
        self.shift = nn.Parameter(torch.zeros(num_numeric, d))
        self.missing = nn.Parameter(torch.zeros(num_numeric, d))
        nn.init.normal_(self.weight, std=0.02)
        self.tables = nn.ModuleList([nn.Embedding(size, d) for size in cardinalities])
        self.block = encoder_stack(d, heads, 1, ff_multiplier, dropout, dropout)
        # Learned queries pool the tokens. Two queries can hold two different summaries of the account.
        self.queries = nn.Parameter(torch.zeros(1, self.num_queries, d))
        nn.init.normal_(self.queries, std=0.02)
        self.pool = nn.MultiheadAttention(d, heads, dropout=dropout, batch_first=True)
        self.norm = nn.LayerNorm(d)
        self.to_stage2 = nn.Linear(d, pick(out_dim, "EMBED_DIM"))

    def forward(self, numeric=None, codes=None):
        """Encode the profile of every sequence.

        numeric   None, or float [B, P]: scaled numeric fields; NaN marks a field without a value
        codes     None, or int [B, Q]: one small integer per code field

        Returns float [B, num_queries, out_dim], ready to be the `prefix` of HistoryStage.

        The encoder sees one set of values per sequence and no row of the sequence, so it
        cannot carry anything from a later row to an earlier one as long as the values are
        those of the first row.
        """
        tokens = []
        if numeric is not None and self.weight.shape[0]:
            unknown = torch.isnan(numeric)
            known_token = torch.nan_to_num(numeric, nan=0.0).unsqueeze(-1) * self.weight + self.shift
            tokens.append(torch.where(unknown.unsqueeze(-1), self.missing, known_token))       # [B, P, d]
        if codes is not None and len(self.tables):
            tokens.append(torch.stack([table(codes[:, q]) for q, table in enumerate(self.tables)], dim=1))
        if not tokens:
            # No profile field is available (no column given, or every column absent from the data). The
            # run goes on: the learned queries themselves become the context vectors, the same for every
            # sequence, so stage 2 gets positions that carry no account information and nothing breaks.
            print("note: no profile field is available; the profile positions carry learned constants only")
            batch_size = numeric.shape[0] if numeric is not None else (codes.shape[0] if codes is not None else 1)
            return self.to_stage2(self.norm(self.queries.expand(batch_size, -1, -1)))
        # One block in which the profile tokens of one sequence read each other freely: they all describe
        # the same account at the same moment (the first row of the sequence).
        tokens = run_blocks(self.block, torch.cat(tokens, dim=1))                          # [B, P + Q, d]
        queries = self.queries.expand(tokens.shape[0], -1, -1)
        pooled, _ = self.pool(queries, tokens, tokens, need_weights=False)                     # [B, queries, d]
        return self.to_stage2(self.norm(pooled))
