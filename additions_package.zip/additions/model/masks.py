"""Who may read whom: the strict time rule as an attention mask.

What this file does
-------------------
It answers one question for every pair of rows of a padded batch: may row i read row j?

    whole_seconds        the times of the batch floored to whole seconds, whatever their unit and
                         whatever their number type (integer or 64-bit float)
    strict_visibility    yes when j is i itself, or when both are real rows and j lies in a
                         strictly earlier second than i
    to_attention_mask    turns the yes/no answers into the float mask (zero where yes, minus
                         infinity where no) that attention layers take
    with_prefix          adds positions in front of the rows (an account profile, a stored account
                         state) that every row may read and that read only themselves

Why it exists
-------------
Every row of a sequence gets a score, so every row is at once a row to be scored and
history for the rows after it. The score has to come from what was known at the moment of
the transaction. If a row could read a later row, the network would learn from facts that
do not exist yet when a transaction is scored, and its results in training would be better
than anything it can deliver in use. Frauds come in runs on one account, so the rows that
matter most lie close together in time, often seconds apart. That is exactly where a loose
rule leaks.

Timestamps are whole seconds. Two rows of one second cannot be put in a trustworthy order,
so neither may read the other: letting the one that happens to be sorted first into the
history of the other would use an order that the scoring system may not have. Writing the
rule once, in one tested place, means that stage 2, the layer that carries the bank's
decisions and the attention bias cannot disagree about it.

The whole second of a time follows one rule here, in `_whole_seconds` of interleaved_reread.py
and in attention_bias.py, so that the mask, the memory of earlier rows and the bias always
agree on which rows share a second:

    a unit that is a whole number, also when it is written as a float (1e9), divides as an
    integer, exactly; any other unit divides in 64-bit floats and the result is floored;
    times in 64-bit floats are floored to whole seconds, also with a unit of 1, so that rows a
    fraction of a second apart share their second;
    times in 32-bit or 16-bit floats stop with a plain error: their steps near the times of
    today (1.7e9 seconds) are 128 seconds wide or more, so they cannot say which second a row
    lies in. The builder's int64 times are the ones to pass.

Where it goes
-------------
Stage 2, the attention over the rows of one account. In the original code the same rule is
built inside `FTTransformerHierModel._build_causal_mask` (the strict time policy of the
all-position mode). history_stage.py (package only), aligned_outcomes.py (package only) and
attention_bias.py call the functions of this file.

What to change for the pod
--------------------------
`TIME_UNITS_PER_SECOND` below, when the batch carries times in another unit than whole
seconds. It must be the unit the mask of stage 2 is built with, and every other piece that
reads the times (the memory of interleaved_reread.py, the channel stage, the attention bias)
must be handed the same unit. Nothing else: the functions take plain tensors.

How to try it
-------------
    allowed = strict_visibility(batch["time_seq"], batch["mask"])     # bool [B, T, T]
    allowed = with_prefix(allowed, 2)                                  # bool [B, 2 + T, 2 + T]
    mask = to_attention_mask(allowed, num_heads=8)                     # float [B * 8, 2 + T, 2 + T]
    seconds = whole_seconds(batch["time_seq"], 1_000_000_000)          # nanoseconds to whole seconds
    python -m pytest -q additions/tests/test_model_masks.py            # package only
"""
import math
import numbers

import torch

# PLACEHOLDER: how many units of the batch's time values make one second: 1 when the builder writes
# whole seconds, 1_000_000_000 when it writes nanoseconds (the original SequenceBuilder does).
TIME_UNITS_PER_SECOND = 1

# Number types that cannot hold the times of today to the second. A 32-bit float keeps 24 bits of a number, so near
# 1.7e9 seconds its steps are 128 seconds wide (and about 1.4e11 nanoseconds wide near 1.7e18); the 16-bit types are
# coarser still. Rows in one step would fall into one second, and rows of one second into two.
SHORT_FLOATS = (torch.float16, torch.bfloat16, torch.float32)


def _unit(units):
    """The number of time units in one second: an int when it is a whole number (1e9 included), a float otherwise.

    A unit that is zero, negative or not a finite number cannot divide the times and stops with a plain error.
    """
    # A whole number becomes an int, so that integer times divide exactly; written as a float (1e9) it would make
    # the division run in floats.
    value = int(units) if isinstance(units, numbers.Integral) else float(units)
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    if not (value > 0 and math.isfinite(value)):
        raise ValueError(f"units_per_second must be a positive number of time units per second (1 for whole "
                         f"seconds, 1_000_000_000 for nanoseconds); got {units!r}")
    return value


def whole_seconds(times, units_per_second=None):
    """The times of a batch as whole seconds.

    times             integer or 64-bit float [B, T], in any unit
    units_per_second  how many units of `times` make one second; None reads TIME_UNITS_PER_SECOND

    Returns integer [B, T] for integer times and a whole unit, 64-bit floats holding whole
    numbers otherwise (a unit with a fraction, or float times). The rule is defined on whole
    seconds, so two rows that differ only by a fraction of a second count as the same second.
    Every division floors (it does not truncate), which keeps times before 1970 in the right
    second. Times in 32-bit or 16-bit floats stop with a plain error: they cannot hold the
    second of a time of today, and the builder's int64 times are the ones to pass.
    """
    units = _unit(TIME_UNITS_PER_SECOND if units_per_second is None else units_per_second)
    if times.dtype in SHORT_FLOATS:
        raise ValueError(f"times are {times.dtype}, which cannot hold the times of today to the second (its steps "
                         f"near 1.7e9 seconds are 128 seconds wide or more); pass the times as int64, as the "
                         f"builder writes them")
    if times.is_floating_point():
        # Float times are floored even with a unit of 1: rows a fraction of a second apart share their second, as
        # they do when the builder writes nanoseconds and the unit says so.
        return torch.floor(times if units == 1 else times / units)
    if isinstance(units, int):
        # Integer times and a whole unit: the integer division of the first version, exact at any size.
        return times if units == 1 else torch.div(times, units, rounding_mode="floor")
    # A unit with a fraction cannot divide as an integer. 64-bit floats keep the second of times of today in seconds or
    # milliseconds; nanoseconds are better given with a whole unit, which takes the exact line above.
    return torch.floor(times.to(torch.float64) / units)


def strict_visibility(times, valid, units_per_second=None):
    """Which rows each row may read under the strict time rule.

    times             integer [B, T]: the time of every slot (any value on padding)
    valid             bool [B, T]: True on real rows, False on padding
    units_per_second  how many units of `times` make one second; None reads TIME_UNITS_PER_SECOND

    Returns bool [B, T, T]. Entry [b, i, j] is True when row i of sequence b may read row j:
    j is i itself, or i and j are both real and j lies in a strictly earlier second. A padded
    slot therefore reads only itself and is read by no other row.
    """
    secs = whole_seconds(times, units_per_second)
    valid = valid.bool()
    T = secs.shape[1]
    # [b, i, j]: the second of row j lies before the second of row i. Rows of one second fail the test in
    # both directions, which is what keeps them invisible to each other.
    earlier = secs.unsqueeze(1) < secs.unsqueeze(2)
    # Padding carries a made-up time (usually 0), which would count as "earlier" than every real row.
    # Requiring both rows to be real keeps padding out of every history.
    both_real = valid.unsqueeze(1) & valid.unsqueeze(2)
    itself = torch.eye(T, dtype=torch.bool, device=secs.device)
    return (earlier & both_real) | itself


def with_prefix(allowed, n_prefix):
    """The same answers with `n_prefix` extra positions in front of the rows.

    allowed    bool [B, T, T] from `strict_visibility`
    n_prefix   number of positions put in front

    Returns bool [B, n_prefix + T, n_prefix + T]. Every row, padded or not, may read every
    prefix position. A prefix position reads only itself. The answers of the rows among
    themselves are unchanged.

    The prefix is meant for content that is older than every row of the sequence: an account
    profile as of the first row, or a stored account state built from rows before the first
    row. That is what makes it lawful for every row to read it. A prefix position must not
    read a row, because a row is newer than the prefix: once a prefix position had read a
    row, an earlier row reading that position would be reading a later row through it.
    """
    B, T, _ = allowed.shape
    L = n_prefix + T
    out = torch.zeros(B, L, L, dtype=torch.bool, device=allowed.device)
    out[:, n_prefix:, n_prefix:] = allowed                        # rows among themselves: as before
    out[:, n_prefix:, :n_prefix] = True                           # every row may read the whole prefix
    spot = torch.arange(n_prefix, device=allowed.device)
    # Each prefix position reads itself and nothing else. Letting the prefix positions read each other
    # would also respect the time rule (all of them are older than every row); this line is the place
    # to open that up.
    out[:, spot, spot] = True
    return out


def to_attention_mask(allowed, num_heads):
    """The float mask that attention layers add to their logits before the softmax.

    allowed     bool [B, L, L]: [b, i, j] says whether position i may read position j
    num_heads   attention heads of the layer that will take the mask

    Returns float32 [B * num_heads, L, L]: zero where reading is allowed and minus infinity
    where it is not. Rows b * num_heads to (b + 1) * num_heads - 1 belong to sequence b, one
    copy per head, which is the order nn.MultiheadAttention and nn.TransformerEncoder expect
    for a mask that differs from sequence to sequence.

    The diagonal is always open. A row whose every entry is minus infinity would make the
    softmax divide zero by zero, and the resulting NaN would spread to the whole batch through
    the gradient. A padded slot has nothing it may read, so it reads itself; its output is
    never used.
    """
    B, L, _ = allowed.shape
    itself = torch.eye(L, dtype=torch.bool, device=allowed.device)
    mask = torch.zeros(B, L, L, dtype=torch.float32, device=allowed.device)
    mask.masked_fill_(~(allowed | itself), float("-inf"))
    # A learned bias can be added to this mask (attention_bias.py). The sum must then be handed to
    # attention that really adds it: see `run_blocks` in _shared.py (package only) for the route that does not.
    return mask.repeat_interleave(num_heads, dim=0)
