"""A field re-read after every history layer, and a short memory of recent field representations.

What this file does
-------------------
It holds two additions to stage 2 of the two-stage model, and the small parts they share.

    InterleavedReread    one gated re-read after each chosen history layer. After a history layer has
                         run, every row's history-aware vector is cut into segments as wide as a field
                         representation, the segments query a bank of field representations, and what
                         they find is added back to the vector before the next history layer runs.
    RecentFieldMemory    the bank those re-reads query. It always holds the row's own field
                         representations. With `num_back` above zero it also holds those of the row's
                         latest `num_back` eligible earlier transactions, each marked with how far
                         back it lies. With 64 predictors and 5 transactions back that is
                         64 + 5 x 64 = 384 keys per row.
    GatedReread          one such re-read. A learned gate decides, for every row and every segment,
                         how much of what was read is let in.
    PredictorBank        makes the bank of one representation per predictor when stage 1 itself runs
                         on a shorter sequence: every predictor token reads the stage-1 outputs once.
    latest_prior_rows    for every row, which rows are its latest eligible earlier transactions.
    mask_agreement       says whether the memory gathers exactly the rows the mask of stage 2 lets a row read;
                         `InterleavedReread.look_at_wiring` calls it with the block's own settings.
    start_from           copies the weights of a trained model into a model that has these blocks.
    train_only           leaves only the chosen parts trainable.

A fresh block changes nothing. The layer that writes a re-read back into the history vector starts at
zero, so a trained model that is given these blocks scores exactly as before until training moves them.

Why it exists
-------------
Stage 1 squeezes every transaction into one vector before the model knows anything about the account.
Stage 2 then reasons over those vectors only. Whatever stage 1 did not keep is gone for every history
layer, and stage 1 had to choose what to keep without knowing what would matter. The single re-read
after the last history layer gives some of that detail back, but only to the head: no history layer
can use what it found.

A re-read after every history layer restores field-level evidence while the history is still being
read. After the first layer a row knows a little about its account and can already ask its fields a
better question; the answer travels on to later rows through the next layer, and those rows ask again
with what they have learned. Frauds come in runs on one account, and inside a run the rows look
ordinary one by one. What sets them apart is detail measured against the account's own past, which is
exactly what a compressed transaction vector tends to lose.

The memory adds a second thing. A row can compare itself with the actual fields of its last few
transactions, not only with their compressed vectors: three small card-not-present amounts at three
merchants within two minutes are visible as such. The keys are field representations, so the
comparison is one of meaning. A test of exact equality (the same merchant as one of the last five
rows) is better added as an input column of its own.

The gate answers one worry about repeating the same read four times. Every layer has its own re-read
with its own weights, and its question comes from a vector that the layers before it have changed. The
gate then sees both the question and the answer, and can close where the answer brings nothing new.
The average gate per layer is a reading of where the model uses the field evidence.

Where it goes
-------------
Stage 2, between its layers. Three calls replace the one call that runs the history layers:

    bank   = predictor_bank(predictor_tokens, stage1_tokens)     # [B, T, P, d]; or any [B, T, F, d]
    memory = interleaved.prepare(bank, times, valid)             # once per batch
    x      = interleaved.run(history_layers, x, mask, memory, n_prefix=0)

`history_layers` is the stack of stage 2 (an nn.TransformerEncoder, or a list of its layers), `x` is
what goes into it and `mask` is the float mask it already takes. `n_prefix` is the number of positions
in front of the rows that are not transactions (1 when a sequence summary token sits in front, 0
otherwise). Whatever follows stage 2 (a last re-read, the head) stays as it is.

A stage 2 that runs its layers in a loop of its own keeps that loop, and so does one whose mask
carries a learned bias. It calls `rows = interleaved.after_layer(number, rows, memory)` after each
layer, with `number` counting from 1 and `rows` holding the transactions only. A final norm after the
loop stays after the loop: the re-read of the last layer goes before it, as `run` does.

The bank can come from three places, and the blocks take any of them:

    one vector per predictor     `PredictorBank` on the tokenizer's predictor tokens, kept before they
                                 are grouped for stage 1, together with the stage-1 output sequence
    stage 1 on every predictor   the field outputs of stage 1 themselves
    the grouped field inputs     the field-level outputs that stage 1 already produces, however few

interleaved_wiring_template.py shows the three calls in a complete small model, with every name
that belongs to the model in use marked, and holds four checks that say whether a wiring is right.
Inside the additions package only: history_stage.py takes `after_layer` as its `after_block`,
summary_tokens.py returns the field outputs of stage 1 with `return_fields=True`, and
reference_model.py wires the block with the switches `interleaved_reread` and `memory_back`.

What to change for the pod
--------------------------
The six PLACEHOLDER values below. `TIME_UNITS_PER_SECOND` must say in what unit the batch carries its
times, and it must be the unit that the mask of stage 2 was built with. `NUM_FIELDS` is the number of
field representations a transaction has in the bank. `n_prefix` must match the
model. When the mask of stage 2 carries a learned bias, the loop that already adds that mask to the
attention logits is kept and `after_layer` is called in it; `run` is for a plain stack.

Memory grows with rows times keys. With 384 keys the two gathered tensors (keys and values) hold
rows x 384 x 48 numbers each, about 74 MB per thousand rows in 32-bit numbers, and they stay alive for
the backward pass. When the GPU runs out of memory, halve the batch size or lower `NUM_BACK`.

How to try it
-------------
    interleaved = InterleavedReread(width=144, num_back=5)             # 4 layers, 3 segments of 48
    memory = interleaved.prepare(fields, times, valid)                 # fields [B, T, 64, 48]
    out = interleaved.run(stack, x, mask, memory)                      # x [B, T, 144] -> [B, T, 144]
    print(interleaved.gate_report())                                   # the average gate per layer
    python interleaved_wiring_template.py                              # the blocks in a complete small model
    python -m pytest -q additions/tests/test_model_interleaved_reread.py   # inside the additions package
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

# PLACEHOLDER: width of one field representation; it is the width of a stage-1 token.
FIELD_DIM = 48

# PLACEHOLDER: attention heads of a re-read; FIELD_DIM must be a multiple of it.
NUM_HEADS = 8

# PLACEHOLDER: how many history layers stage 2 has; a re-read is placed after each of them by default.
HISTORY_LAYERS = 4

# PLACEHOLDER: how many of a row's latest eligible earlier transactions the memory holds besides the row
# itself; 0 keeps only the row's own fields.
NUM_BACK = 5

# PLACEHOLDER: how many field representations one transaction has in the bank (64 when the bank holds one
# vector per predictor); 0 when the bank is not given a learned vector per field.
NUM_FIELDS = 64

# PLACEHOLDER: how many units of the batch's time values make one second: 1 when the builder writes whole
# seconds, 1_000_000_000 when it writes nanoseconds.
TIME_UNITS_PER_SECOND = 1


# ----------------------------------------------------------------------------------------------
# which earlier rows a row may use
# ----------------------------------------------------------------------------------------------

def _whole_seconds(times, units_per_second=None):
    """The times of a batch as whole seconds (the division floors, so times before 1970 stay in their second)."""
    units = TIME_UNITS_PER_SECOND if units_per_second is None else units_per_second
    return times if units == 1 else torch.div(times, units, rounding_mode="floor")


def eligible_rows(times, valid, units_per_second=None):
    """Which earlier rows each row may use: the same rule as the mask of stage 2, without the row itself.

    times             integer [B, T]: the time of every slot (any value on padding)
    valid             bool [B, T]: True on real rows
    units_per_second  how many units of `times` make one second; None reads TIME_UNITS_PER_SECOND

    Returns bool [B, T, T]. Entry [b, i, j] is True when both rows are real and row j lies in a
    strictly earlier second than row i. Two rows of one second cannot be put in a trustworthy
    order, so neither is eligible for the other.
    """
    secs = _whole_seconds(times, units_per_second)
    valid = valid.bool()
    earlier = secs.unsqueeze(1) < secs.unsqueeze(2)               # [b, i, j]: j lies before i
    return earlier & valid.unsqueeze(1) & valid.unsqueeze(2)


def latest_prior_rows(times, valid, num_back, units_per_second=None):
    """For every row, the slots of its latest `num_back` eligible earlier rows.

    times, valid, units_per_second   as in `eligible_rows`
    num_back                         how many earlier rows to find

    Returns (index, exists):
      index    int64 [B, T, num_back]: the slot of the row 1 back, 2 back, ... (any slot where none exists)
      exists   bool [B, T, num_back]: False where a row has fewer eligible earlier rows than that

    "Latest" follows the time, not the slot, so the batch does not have to be sorted. Rows of one
    second are taken in the order of their slots, latest slot first. That order decides only
    which of them is called 1 back and which 2 back for a LATER row; it never lets a row see
    another row of its own second.
    """
    eligible = eligible_rows(times, valid, units_per_second)       # [B, T, T]
    B, T = valid.shape
    secs = _whole_seconds(times, units_per_second)
    # The place of every slot in time order (0 is the earliest). The stable sort keeps slot order inside a second.
    order = torch.argsort(secs, dim=1, stable=True)
    place = torch.empty_like(order)
    place.scatter_(1, order, torch.arange(T, device=order.device).expand(B, T))
    # A row that is not eligible gets -1, so the largest values of a line are its latest eligible rows.
    score = place.unsqueeze(1).expand(B, T, T).masked_fill(~eligible, -1)
    found = min(int(num_back), T)
    top, index = torch.topk(score, found, dim=-1)                  # latest first
    exists = top >= 0
    if found < num_back:
        # A batch narrower than the memory: the places beyond its width hold nothing.
        pad = (0, int(num_back) - found)
        index, exists = F.pad(index, pad, value=0), F.pad(exists, pad, value=False)
    return index, exists


# ----------------------------------------------------------------------------------------------
# the bank of field representations
# ----------------------------------------------------------------------------------------------

class PredictorBank(nn.Module):
    """One representation per predictor, for a model whose stage 1 runs on a shorter sequence.

    field_dim   width d of a predictor token; None reads FIELD_DIM
    num_heads   attention heads; None reads NUM_HEADS
    dropout     dropout on the attention weights and on the residual branch

    The tokenizer makes one token per predictor. When stage 1 groups those tokens into a few
    field-level inputs, the single predictors are no longer there to be read again. This block
    keeps them: every predictor token reads the output sequence of stage 1 once, so that it
    carries what the transaction looks like as a whole, and the result is stored next to the
    stage-1 sequence. Stage 1 itself is not touched and costs what it cost before.
    """

    def __init__(self, field_dim=None, num_heads=None, dropout=0.1):
        super().__init__()
        d = FIELD_DIM if field_dim is None else int(field_dim)
        heads = NUM_HEADS if num_heads is None else int(num_heads)
        self.norm_tokens = nn.LayerNorm(d)
        self.norm_context = nn.LayerNorm(d)
        self.read = nn.MultiheadAttention(d, heads, dropout=dropout, batch_first=True)
        self.drop = nn.Dropout(dropout)

    def forward(self, predictor_tokens, stage1_tokens=None):
        """The bank of one transaction's predictors.

        predictor_tokens   float [..., P, d]: one token per predictor, as the tokenizer returns them;
                           the leading dimensions are free, usually [B, T]
        stage1_tokens      None, or float [..., L, d]: the output sequence of stage 1 for the same
                           transaction (summary tokens and field-level tokens), same leading dimensions

        Returns float [..., P, d]. Without `stage1_tokens` the predictor tokens are returned as
        they are. Every transaction is handled by itself: no transaction reads another one here.
        """
        if stage1_tokens is None:
            return predictor_tokens
        lead = predictor_tokens.shape[:-2]
        n_predictors, d = predictor_tokens.shape[-2:]
        tokens = predictor_tokens.reshape(-1, n_predictors, d)
        context = self.norm_context(stage1_tokens.reshape(-1, stage1_tokens.shape[-2], d))
        # Each predictor asks the stage-1 outputs of its own transaction; the answer is added to the token.
        seen, _ = self.read(self.norm_tokens(tokens), context, context, need_weights=False)
        return (tokens + self.drop(seen)).reshape(*lead, n_predictors, d)


class RecentFieldMemory(nn.Module):
    """The keys and values that the re-reads query: a row's own fields and those of its latest earlier rows.

    field_dim          width d of a field representation; None reads FIELD_DIM
    num_back           how many latest eligible earlier transactions are held besides the row itself;
                       None reads NUM_BACK, 0 keeps only the row's own fields
    units_per_second   unit of the batch's times; None reads TIME_UNITS_PER_SECOND
    num_fields         how many field representations F a transaction has in the bank; None reads
                       NUM_FIELDS, 0 leaves the learned vector per field out

    The bank is normalised and projected into keys and values once per batch, and every re-read
    of every layer uses that one projection. Each re-read still asks its own question. This
    keeps the cost of a re-read after every layer close to the cost of a single one.

    Every key and value also gets two learned vectors. One is for its look-back position: 0 for
    the row's own fields, 1 for the latest earlier transaction, and so on; without it the fields
    of the current transaction and those of an old one would look alike. The other is for its
    place among the F fields; it lets a question go to one particular field even when the
    representations themselves do not say which field they belong to.
    """

    def __init__(self, field_dim=None, num_back=None, units_per_second=None, num_fields=None):
        super().__init__()
        d = FIELD_DIM if field_dim is None else int(field_dim)
        self.num_back = NUM_BACK if num_back is None else int(num_back)
        self.num_fields = NUM_FIELDS if num_fields is None else int(num_fields)
        self.units_per_second = units_per_second
        self.norm_fields = nn.LayerNorm(d)
        self.key = nn.Linear(d, d)
        self.value = nn.Linear(d, d)
        # One vector per look-back position, added after the projection. Adding it after is the same as
        # adding a vector before a linear projection, and it lets the bank be projected only once.
        self.back_key = nn.Parameter(torch.zeros(self.num_back + 1, d))
        self.back_value = nn.Parameter(torch.zeros(self.num_back + 1, d))
        nn.init.normal_(self.back_key, std=0.02)
        nn.init.normal_(self.back_value, std=0.02)
        # One vector per field, the same for every look-back position, when the number of fields is given.
        self.field_key = self.field_value = None
        if self.num_fields:
            self.field_key = nn.Parameter(torch.zeros(self.num_fields, d))
            self.field_value = nn.Parameter(torch.zeros(self.num_fields, d))
            nn.init.normal_(self.field_key, std=0.02)
            nn.init.normal_(self.field_value, std=0.02)
        self._noted = False

    def forward(self, fields, times=None, valid=None):
        """Keys, values and the mark of empty places for every row of a batch.

        fields   float [B, T, F, d]: F field representations per row
        times    integer [B, T]: the time of every slot; it decides which earlier rows a row gathers
        valid    bool [B, T]: True on real rows. It keeps padding out of every memory, and it lets the
                 re-reads leave padded slots as they are, so that whatever a padded slot holds
                 (anything, also a value that is not a number) cannot spread

        Returns (keys, values, missing, valid):
          keys, values   float [B, T, M, d] with M = (num_back + 1) x F: the row's own F fields first,
                         then those of the row 1 back, 2 back, ...
          missing        None, or bool [B, T, M]: True on the places of an earlier row that does not
                         exist (the row has fewer eligible earlier rows than `num_back`)
          valid          the mask that was given, as bool, or None

        `times` and `valid` belong to every call. Without them the memory holds the row's own
        fields only, padding is not kept out, and one printed line says so.

        Only strictly earlier rows of the same sequence are gathered, by the rule of
        `eligible_rows`, which is the rule of the mask of stage 2. A row therefore never holds a
        later row or another row of its own second in its memory.
        """
        B, T, n_fields, d = fields.shape
        if valid is not None:
            # A padded slot can hold anything. No real row gathers it, but zero keeps it finite.
            fields = fields.masked_fill(~valid.bool()[:, :, None, None], 0.0)
            valid = valid.bool()
        normed = self.norm_fields(fields)
        keys, values = self.key(normed), self.value(normed)        # [B, T, F, d], projected once
        if self.field_key is not None:
            # In place: `keys` and `values` are fresh results of the projection, so nothing else holds them.
            keys = keys.add_(self.field_key.to(keys.dtype))
            values = values.add_(self.field_value.to(values.dtype))
        back = self.num_back
        if times is None or valid is None:
            if not self._noted:
                self._noted = True
                print("note: the memory got no times or no mask; every row reads only its own fields, "
                      "and padded slots are not kept out")
            back = 0
        elif times.dtype == torch.bool and not self._noted:
            self._noted = True
            print("note: the times handed to the memory are a yes/no tensor; times and valid look swapped")
        if back == 0:
            # The look-back vectors take the number type of the keys, so that mixed precision stays mixed.
            return (keys.add_(self.back_key[0].to(keys.dtype)), values.add_(self.back_value[0].to(values.dtype)),
                    None, valid)
        index, exists = latest_prior_rows(times, valid, back, self.units_per_second)    # [B, T, back]
        sequence = torch.arange(B, device=fields.device)[:, None, None]
        # The row's own slot goes first, then the slots of its earlier rows, so that one gathering step
        # builds [B, T, 1 + back, F, d]. These two tensors are the large ones of this file; the look-back
        # vectors are added to them in place so that no third copy is made.
        own = torch.arange(T, device=fields.device).expand(B, T).unsqueeze(-1)
        places = torch.cat([own, index], dim=-1)                                        # [B, T, 1 + back]
        keys = keys[sequence, places].add_(self.back_key[:, None, :].to(keys.dtype))
        values = values[sequence, places].add_(self.back_value[:, None, :].to(values.dtype))
        # The row's own block is always there; a block of an earlier row that does not exist is marked.
        missing = torch.cat([torch.zeros(B, T, 1, dtype=torch.bool, device=fields.device), ~exists], dim=2)
        missing = missing.unsqueeze(-1).expand(B, T, back + 1, n_fields)
        shape = (B, T, (back + 1) * n_fields)
        return keys.reshape(*shape, d), values.reshape(*shape, d), missing.reshape(shape), valid


# ----------------------------------------------------------------------------------------------
# one gated re-read
# ----------------------------------------------------------------------------------------------

class GatedReread(nn.Module):
    """One re-read: a row's history-aware vector queries the bank, and a gate decides how much comes in.

    width          width W of the history-aware vector (the width of stage 2)
    field_dim      width d of a field representation; None reads FIELD_DIM
    num_segments   number S of queries the vector is cut into; None means W / d, rounded up when W is
                   not a multiple of d
    num_heads      attention heads; None reads NUM_HEADS
    ff_multiplier  the feed-forward layer is this many times as wide as a segment
    dropout        dropout on the attention weights and on the two branches
    gate           True for the learned gate, False to let every read in whole
    """

    def __init__(self, width, field_dim=None, num_segments=None, num_heads=None, ff_multiplier=4, dropout=0.1,
                 gate=True):
        super().__init__()
        d = self.field_dim = FIELD_DIM if field_dim is None else int(field_dim)
        self.num_heads = NUM_HEADS if num_heads is None else int(num_heads)
        # By default the vector is cut into as many segments as fit; a width of 144 gives three of 48.
        s = self.num_segments = -(-width // d) if num_segments is None else int(num_segments)
        # When the vector already is S segments side by side it is only cut. Otherwise a learned
        # projection makes S segments out of it.
        self.to_segments = nn.Identity() if width == s * d else nn.Linear(width, s * d)
        self.norm_query = nn.LayerNorm(d)
        self.query = nn.Linear(d, d)
        self.out = nn.Linear(d, d)
        self.norm_ff = nn.LayerNorm(d)
        self.feed_forward = nn.Sequential(nn.Linear(d, d * ff_multiplier), nn.GELU(), nn.Dropout(dropout),
                                          nn.Linear(d * ff_multiplier, d))
        self.drop = nn.Dropout(dropout)
        self.attn_dropout = float(dropout)
        # The gate reads the question and the answer side by side and gives one number between 0 and 1
        # for every segment. It starts near one half.
        self.gate = nn.Sequential(nn.Linear(2 * d, d), nn.GELU(), nn.Linear(d, 1)) if gate else None
        # The layer that writes the result back starts at zero and has no constant term. A fresh block is
        # therefore exactly a no-op, and a block whose gate is close to zero adds close to nothing. Its
        # weights still receive a
        # gradient from the first step on (the gradient of a weight is its input times the error signal,
        # and the input is not zero), so the block leaves the no-op state as soon as that helps the loss.
        self.write_back = nn.Linear(s * d, width, bias=False)
        nn.init.zeros_(self.write_back.weight)
        # The gate values of the latest call, [..., S], kept for reading; they are not part of the weights.
        self.last_gate = None

    def forward(self, history, keys, values, missing=None):
        """Add to every row's history-aware vector what it reads from the bank.

        history   float [..., W]: one history-aware vector per row; the leading dimensions are free,
                  usually [B, T]
        keys      float [..., M, d]: the keys of the row's bank, from `RecentFieldMemory`
        values    float [..., M, d]: the values of the same places
        missing   None, or bool [..., M]: True on places that hold nothing

        Returns float [..., W]. A row reads only the M places of its own bank.
        """
        lead = history.shape[:-1]
        s, d, heads = self.num_segments, self.field_dim, self.num_heads
        n_places = keys.shape[-2]
        segments = self.to_segments(history).reshape(-1, s, d)                    # [N, S, d]
        asked = self.norm_query(segments)
        # Attention written out, so that the keys and values projected once by the memory can be used as
        # they are. Each segment asks its own question; segments are cut, not averaged, so the parts of
        # the history vector can each look for something else.
        q = self.query(asked).view(-1, s, heads, d // heads).transpose(1, 2)      # [N, heads, S, d / heads]
        # Keys and values are brought to the number type of the question, which matters only when the
        # model runs in mixed precision and the two were made in different types.
        k = keys.to(q.dtype).reshape(-1, n_places, heads, d // heads).transpose(1, 2)    # [N, heads, M, d / heads]
        v = values.to(q.dtype).reshape(-1, n_places, heads, d // heads).transpose(1, 2)
        # True lets a place take part. The row's own places are never missing, so no question is left
        # without anything to read.
        allowed = None if missing is None else ~missing.reshape(-1, 1, 1, n_places)
        drop = self.attn_dropout if self.training else 0.0
        read = F.scaled_dot_product_attention(q, k, v, attn_mask=allowed, dropout_p=drop)
        read = self.out(read.transpose(1, 2).reshape(-1, s, d))                   # [N, S, d]
        # What the re-read found: the answer, and a small network's working of the answer in the light
        # of the question. The segment itself is not part of it, so a gate near zero adds next to nothing.
        found = self.drop(read)
        found = found + self.drop(self.feed_forward(self.norm_ff(segments + found)))
        if self.gate is not None:
            opened = torch.sigmoid(self.gate(torch.cat([asked, read], dim=-1)))   # [N, S, 1]
            self.last_gate = opened.detach().reshape(*lead, s)
            found = opened * found
        # Join the segments again and add the result to the vector that came in. With the zero start of
        # `write_back` this line returns `history` itself at first.
        return history + self.write_back(found.reshape(*lead, s * d))


# ----------------------------------------------------------------------------------------------
# a re-read after every history layer
# ----------------------------------------------------------------------------------------------

class InterleavedReread(nn.Module):
    """The memory and one gated re-read for each chosen history layer.

    width            width W of stage 2
    history_layers   how many history layers stage 2 has; None reads HISTORY_LAYERS
    after_layers     the layers (1 is the first) that are followed by a re-read; None means every layer
    field_dim, num_segments, num_heads, ff_multiplier, dropout, gate   as in `GatedReread`
    num_back         as in `RecentFieldMemory`; None reads NUM_BACK
    units_per_second unit of the batch's times; None reads TIME_UNITS_PER_SECOND
    num_fields       as in `RecentFieldMemory`; None reads NUM_FIELDS

    Three settings cover the designs:
      after every layer, own fields only        InterleavedReread(width, num_back=0)
      memory of recent fields, one re-read      InterleavedReread(width, after_layers=(4,), num_back=5)
      both                                      InterleavedReread(width, num_back=5)
    """

    def __init__(self, width, history_layers=None, after_layers=None, field_dim=None, num_segments=None,
                 num_heads=None, num_back=None, ff_multiplier=4, dropout=0.1, gate=True, units_per_second=None,
                 num_fields=None):
        super().__init__()
        n_layers = HISTORY_LAYERS if history_layers is None else int(history_layers)
        chosen = range(1, n_layers + 1) if after_layers is None else sorted(int(n) for n in after_layers)
        self.after_layers = tuple(chosen)
        self.memory = RecentFieldMemory(field_dim=field_dim, num_back=num_back, units_per_second=units_per_second,
                                        num_fields=num_fields)
        # Every layer gets a re-read of its own. Their weights are not shared: the question a row can ask
        # after the first layer is not the question it can ask after the last.
        self.rereads = nn.ModuleDict({str(n): GatedReread(width, field_dim=field_dim, num_segments=num_segments,
                                                          num_heads=num_heads, ff_multiplier=ff_multiplier,
                                                          dropout=dropout, gate=gate)
                                      for n in self.after_layers})

    def prepare(self, fields, times=None, valid=None):
        """The memory of one batch, built once and used by every re-read: see `RecentFieldMemory.forward`."""
        return self.memory(fields, times, valid)

    def after_layer(self, number, history, memory):
        """What the rows hold after history layer `number` and its re-read.

        number    the history layer that has just run (1 is the first)
        history   float [B, T, W]: the rows only, without any position put in front of them
        memory    the result of `prepare` for the same batch

        Returns float [B, T, W]; `history` itself when the layer has no re-read. A padded slot keeps
        what it held: its re-read is not written back, so nothing a padded slot carries can spread.
        """
        if str(number) not in self.rereads:
            return history
        keys, values, missing, valid = memory
        read = self.rereads[str(number)](history, keys, values, missing)
        return read if valid is None else torch.where(valid.unsqueeze(-1), read, history)

    def run(self, stack, x, mask, memory, n_prefix=0, key_padding=None):
        """Run the history layers one by one, with the re-read after each chosen layer.

        stack         stage 2: an nn.TransformerEncoder, or a list of its layers
        x             float [B, n_prefix + T, W]: what goes into stage 2
        mask          the mask that stage 2 already takes (zero where reading is allowed, minus infinity
                      where it is not), or None
        memory        the result of `prepare` for the same batch
        n_prefix      positions in front of the rows that are not transactions; they are left as they are
        key_padding   None, or the `src_key_padding_mask` that stage 2 is called with today, when it is
                      called with one

        Returns float [B, n_prefix + T, W], as `stack(x, mask=mask)` does. With fresh re-reads the
        two results are equal.

        A row's re-read uses the row's own fields and, with a memory, the fields of strictly
        earlier rows. The next history layer then reads the rows under the same mask as before,
        so nothing reaches a row that the mask does not let it read.

        Two things are those of the layers themselves and are not changed here. `x` has to be
        finite on padded slots (zero is the usual choice): a value that is not a number spreads
        through attention even at a weight of zero. And a position that the masks leave with
        nothing to read gives a result that is not a number, so `mask` and `key_padding`
        together must leave every position at least itself.
        """
        layers = stack.layers if hasattr(stack, "layers") else stack
        for number, layer in enumerate(layers, start=1):
            x = layer(x, src_mask=mask, src_key_padding_mask=key_padding)
            if str(number) in self.rereads:
                rows = self.after_layer(number, x[:, n_prefix:], memory)
                x = rows if n_prefix == 0 else torch.cat([x[:, :n_prefix], rows], dim=1)
        last = getattr(stack, "norm", None)
        return x if last is None else last(x)

    def look_at_wiring(self, mask, times, valid, memory, n_prefix=0, key_padding=None):
        """One look that says whether this block is wired to the model the way the mask of stage 2 implies.

        mask, key_padding   what stage 2 is called with for this batch
        times, valid        what was handed to `prepare`
        memory              what `prepare` returned
        n_prefix            what is handed to `run`

        Returns the share of `mask_agreement`, with the time unit this block was built with; 0.0
        when the memory itself is not whole. It prints one or two lines. The memory is whole when
        it was given the times and the mask of real rows, holds as many places per row as the
        block was built for ((rows back + 1) x fields), and holds for every real row the earlier
        rows that the times handed to this look imply. 1.0 is the only good answer.

        1.0 says that the memory and the mask of stage 2 follow the same rule. It does not say
        that the rule is right: a mask built with the wrong time unit agrees with a memory built
        with the same wrong unit. One value of the times settles that: about 1.7e9 is seconds,
        about 1.7e18 is nanoseconds.
        """
        keys, _, missing, kept = memory
        back = self.memory.num_back
        whole = kept is not None and (back == 0 or missing is not None)
        if self.memory.num_fields:
            whole = whole and keys.shape[-2] == (back + 1) * self.memory.num_fields
        if not whole:
            print(f"look_at_wiring: the memory is not whole: it holds {keys.shape[-2]} places per row, "
                  f"built for {back} rows back; prepare needs the bank, the times and the mask "
                  f"of real rows")
        elif back:
            # The memory itself is read: every real row must hold as many earlier rows as the times and
            # the mask of real rows handed to this look say it has, up to the size of the memory.
            B, T = valid.shape
            real = valid.bool()
            held = (~missing).reshape(B, T, back + 1, -1)[..., 0].sum(dim=-1) - 1
            due = eligible_rows(times, real, self.memory.units_per_second).sum(dim=-1).clamp(max=back)
            if not torch.equal(held[real], due[real]):
                whole = False
                print("look_at_wiring: the memory does not hold the earlier rows that these times imply; "
                      "prepare was handed other times or another mask of real rows (or the two swapped)")
        share = mask_agreement(mask, times, valid, n_prefix=n_prefix, key_padding=key_padding,
                               units_per_second=self.memory.units_per_second)
        return share if whole else 0.0

    def gate_report(self, rows=None):
        """The average gate of every re-read in its latest call.

        rows   None for every slot, or bool [B, T]: the slots to average over (real rows, frauds, ...)

        Returns {layer number: average gate}. A value near 0 says the layer's re-read is mostly
        shut out; a value near 1 says it is mostly let in. Layers without a gate are left out,
        and so is every layer when `rows` selects nothing.

        `rows` has the layout the re-reads saw in that call: [B, T] without any position in front
        of the rows, and repeated the same way when the batch was repeated before stage 2.
        """
        report = {}
        for number in self.after_layers:
            opened = self.rereads[str(number)].last_gate
            if opened is None:
                continue
            chosen = opened if rows is None else opened[rows.bool()]
            if chosen.numel():
                report[number] = float(chosen.mean())
        return report


# ----------------------------------------------------------------------------------------------
# a look at the wiring
# ----------------------------------------------------------------------------------------------

def mask_agreement(mask, times, valid, num_heads=None, n_prefix=0, units_per_second=None, key_padding=None):
    """The share of row pairs on which the memory and the mask of stage 2 agree about who may read whom.

    mask              the mask stage 2 takes for this batch: float (minus infinity where reading is not
                      allowed) or bool (True where it is not allowed); [L, L], [B, L, L],
                      [B * heads, L, L] or [B, heads, L, L], with L = n_prefix + T
    times, valid      the [B, T] times and mask of real rows that are handed to `prepare`
    num_heads         heads of stage 2 for a mask of [B * heads, L, L]; None works it out from the mask
    n_prefix          positions in front of the rows that are not transactions
    units_per_second  the unit handed to the memory; None reads TIME_UNITS_PER_SECOND
    key_padding       None, or the key padding mask stage 2 is called with, [B, L]: bool (True on
                      padding) or float (minus infinity on padding). A padded position then neither
                      reads nor is read, as far as this look is concerned.

    Returns a number between 0 and 1 and prints one line. The pairs looked at are every pair of
    different rows that `valid` calls real, and every pair the mask opens. On each of them the
    memory may gather row j for row i exactly when the mask lets row i read row j, or the pair
    counts against the share. 1.0 means the two agree everywhere.

    Anything below 1.0 points at the wiring: another time unit than the mask was built with,
    another `n_prefix`, `times` and `valid` that belong to another layout, or a `valid` that is
    True on padding where it should be True on real rows. A fresh block changes no score, so
    equal scores cannot show such a slip; this call can.
    """
    B, T = valid.shape
    open_ = ~mask if mask.dtype == torch.bool else torch.isfinite(mask)
    if open_.dim() == 4:
        open_ = open_[:, 0]                                         # [B, heads, L, L]: keep the first head
    if open_.dim() == 2:
        open_ = open_.unsqueeze(0).expand(B, -1, -1)
    elif open_.shape[0] != B:
        heads = open_.shape[0] // B if num_heads is None else int(num_heads)
        open_ = open_[::heads]                                      # one copy per head: keep the first of each
    if key_padding is not None:
        padded = key_padding if key_padding.dtype == torch.bool else ~torch.isfinite(key_padding)
        open_ = open_ & ~padded.unsqueeze(1) & ~padded.unsqueeze(2)
    open_ = open_[:, n_prefix:n_prefix + T, n_prefix:n_prefix + T].to(valid.device)
    gathers = eligible_rows(times, valid, units_per_second)
    real = valid.bool()
    different = ~torch.eye(T, dtype=torch.bool, device=valid.device)
    pairs = ((real.unsqueeze(1) & real.unsqueeze(2)) | open_ | gathers) & different
    same = (open_ == gathers) & pairs
    share = float(same.sum()) / max(int(pairs.sum()), 1)
    # How many of the pairs the mask opens lie between rows that `valid` calls real. None of them does
    # when `valid` is True on padding.
    opened = open_ & different
    among_real = int((opened & real.unsqueeze(1) & real.unsqueeze(2)).sum())
    hint = ""
    if share < 1.0:
        hint = "; check the time unit, n_prefix, and that times and valid match the mask"
        if int(opened.sum()) and among_real == 0:
            hint = "; none of the pairs the mask opens lies between rows that valid calls real: valid looks reversed"
    print(f"mask_agreement: the memory and the mask agree on {share:.4%} of {int(pairs.sum())} row pairs" + hint)
    return share


# ----------------------------------------------------------------------------------------------
# starting from a trained model
# ----------------------------------------------------------------------------------------------

def start_from(model, weights):
    """Copy into `model` every tensor of `weights` that has the same name and the same shape.

    model     the model with the new blocks
    weights   the weights of the trained model without them: a name-to-tensor table (the result of
              `trained.state_dict()`), or a saved checkpoint that holds such a table under "state_dict"

    Returns (taken, fresh, unused): the names that were copied, the names of `model` that keep their
    fresh start, and the names of `weights` that went nowhere. Two printed lines say how many
    tensors went where and name what needs a look.

    The grown model scores as the trained model did when `fresh` holds the new blocks only and
    `unused` is empty. A trained tensor in `unused` (another shape, or a name the model does not
    have) is a part of the trained model that was lost. When no name matches at all, the names
    are tried once more without their first part, which is how a wrapper around the model shows
    ("module.head.weight" for "head.weight").
    """
    if "state_dict" in weights and not torch.is_tensor(weights["state_dict"]):
        weights = weights["state_dict"]
    tensors = {name: tensor for name, tensor in weights.items() if torch.is_tensor(tensor)}
    own = model.state_dict()

    def matching(table):
        return {name: tensor for name, tensor in table.items() if name in own and own[name].shape == tensor.shape}

    taken = matching(tensors)
    if not taken:
        without_first = {name.split(".", 1)[1]: tensor for name, tensor in tensors.items() if "." in name}
        if matching(without_first):
            tensors, taken = without_first, matching(without_first)
            print("start_from: the names matched only without their first part; that part was dropped")
    model.load_state_dict(taken, strict=False)
    fresh = sorted(set(own) - set(taken))
    unused = sorted(set(tensors) - set(taken))
    print(f"start_from: {len(taken)} tensors taken from the trained model, {len(fresh)} keep their fresh start, "
          f"{len(unused)} trained tensors were not used")
    if unused:
        print("start_from: not used (another shape, or no such name): " + ", ".join(unused[:8])
              + (" ..." if len(unused) > 8 else ""))
    return sorted(taken), fresh, unused


def train_only(model, parts):
    """Leave only the weights of `parts` trainable and switch every other weight of `model` off.

    model   the whole model
    parts   the modules that are to be trained, for example [model.interleaved, model.predictor_bank]

    Returns the list of trainable weights, ready for an optimiser. With the rest of the model
    held still, any change in the scores comes from the new blocks alone, and the trained
    model itself is the comparison.

    An optimiser built on the returned list touches nothing else. An optimiser built on all the
    weights of the model also leaves the others where they are, because a weight without a
    gradient is skipped; the gradients left over from earlier steps are cleared here for that.
    Layers that keep running statistics of their inputs (batch normalisation) are not held
    still by this; a model that has such layers puts them in evaluation mode as well.
    """
    for weight in model.parameters():
        weight.requires_grad_(False)
        weight.grad = None
    chosen = []
    for part in parts:
        for weight in part.parameters():
            weight.requires_grad_(True)
            chosen.append(weight)
    return chosen
