"""A field re-read after every history layer, and a short memory of recent field representations.

What this file does
-------------------
It holds two additions to stage 2 of the two-stage model, and the small parts they share.

    InterleavedReread    one gated re-read after each chosen history layer. After a history layer has
                         run, every row's history-aware vector is cut into segments as wide as a field
                         representation, the segments query a bank of field representations, and what
                         they find is added back to the vector before the next history layer runs.
    RecentFieldMemory    the bank those re-reads query. It always holds the row's own field
                         representations. With `num_back` above zero it also holds those of the row's
                         latest `num_back` eligible earlier transactions, each marked with how far
                         back it lies. With 64 predictors and 5 transactions back that is
                         64 + 5 x 64 = 384 keys per row.
    GatedReread          one such re-read. A learned gate decides, for every row and every segment,
                         how much of what was read is let in.
    PredictorBank        makes the bank of one representation per predictor when stage 1 itself runs
                         on a shorter sequence: every predictor token reads the stage-1 outputs once.
    latest_prior_rows    for every row, which rows are its latest eligible earlier transactions.
    mask_agreement       says whether the memory gathers exactly the rows the mask of stage 2 lets a row read;
                         `InterleavedReread.look_at_wiring` calls it with the block's own settings.
    start_from           copies the weights of a trained model into a model that has these blocks.
    train_only           leaves only the chosen parts trainable.

A fresh block changes nothing. The layer that writes a re-read back into the history vector starts at
zero, so a trained model that is given these blocks scores exactly as before until training moves them.

Why it exists
-------------
Stage 1 squeezes every transaction into one vector before the model knows anything about the account.
Stage 2 then reasons over those vectors only. Whatever stage 1 did not keep is gone for every history
layer, and stage 1 had to choose what to keep without knowing what would matter. The single re-read
after the last history layer gives some of that detail back, but only to the head: no history layer
can use what it found.

A re-read after every history layer restores field-level evidence while the history is still being
read. After the first layer a row knows a little about its account and can already ask its fields a
better question; the answer travels on to later rows through the next layer, and those rows ask again
with what they have learned. Frauds come in runs on one account, and inside a run the rows look
ordinary one by one. What sets them apart is detail measured against the account's own past, which is
exactly what a compressed transaction vector tends to lose.

The memory adds a second thing. A row can compare itself with the actual fields of its last few
transactions, not only with their compressed vectors: three small card-not-present amounts at three
merchants within two minutes are visible as such. The keys are field representations, so the
comparison is one of meaning. A test of exact equality (the same merchant as one of the last five
rows) is better added as an input column of its own.

The gate answers one worry about repeating the same read four times. Every layer has its own re-read
with its own weights, and its question comes from a vector that the layers before it have changed. The
gate then sees both the question and the answer, and can close where the answer brings nothing new.
The average gate per layer is a reading of where the model uses the field evidence.

Where it goes
-------------
Stage 2, between its layers. Three calls replace the one call that runs the history layers:

    bank   = predictor_bank(predictor_tokens, stage1_tokens)     # [B, T, P, d]; or any [B, T, F, d]
    memory = interleaved.prepare(bank, times, valid)             # once per batch
    x      = interleaved.run(history_layers, x, mask, memory, n_prefix=0)

`history_layers` is the stack of stage 2 (an nn.TransformerEncoder, or a list of its layers), `x` is
what goes into it and `mask` is the float mask it already takes. `n_prefix` is the number of positions
in front of the rows that are not transactions (1 when a sequence summary token sits in front, 0
otherwise). Whatever follows stage 2 (a last re-read, the head) stays as it is.

A stage 2 that runs its layers in a loop of its own keeps that loop, and so does one whose mask
carries a learned bias. It calls `rows = interleaved.after_layer(number, rows, memory)` after each
layer, with `number` counting from 1 and `rows` holding the transactions only. A final norm after the
loop stays after the loop: the re-read of the last layer goes before it, as `run` does.

The bank can come from three places, and the blocks take any of them:

    one vector per predictor     `PredictorBank` on the tokenizer's predictor tokens, kept before they
                                 are grouped for stage 1, together with the stage-1 output sequence
    stage 1 on every predictor   the field outputs of stage 1 themselves
    the grouped field inputs     the field-level outputs that stage 1 already produces, however few

interleaved_wiring_template.py shows the three calls in a complete small model, with every name
that belongs to the model in use marked, and holds four checks that say whether a wiring is right.
Inside the additions package only: history_stage.py takes `after_layer` as its `after_block`,
summary_tokens.py returns the field outputs of stage 1 with `return_fields=True`, and
reference_model.py wires the block with the switches `interleaved_reread` and `memory_back`.

What to change for the pod
--------------------------
The six PLACEHOLDER values below. `TIME_UNITS_PER_SECOND` must say in what unit the batch carries its
times, and it must be the unit that the mask of stage 2 was built with. `NUM_FIELDS` is the number of
field representations a transaction has in the bank. `n_prefix` must match the
model. When the mask of stage 2 carries a learned bias, the loop that already adds that mask to the
attention logits is kept and `after_layer` is called in it; `run` is for a plain stack.

Memory grows with rows times keys. With 384 keys the two gathered tensors (keys and values) hold
rows x 384 x 48 numbers each, about 74 MB per thousand rows in 32-bit numbers, and they stay alive for
the backward pass. When the GPU runs out of memory, halve the batch size or lower `NUM_BACK`.

Scoring has two options of its own, both off by default (see `InterleavedReread`). In evaluation
mode the scores they give are equal to those of the full path up to rounding (below 1e-5).
`prepare(..., scored=...)` works out the last re-read, and in design M the memory and the bank, for
the scored rows only; it helps when one window is scored per transaction. In training mode the mark
is left unused, so training always takes the full path. `rows_per_part` keeps the gathered keys and
values of all rows from being held at once; it helps when memory forces the batch down, and costs
time. `work_report` says how many rows the latest call worked out, which shows whether the saving
is real.

How to try it
-------------
    interleaved = InterleavedReread(width=144, num_back=5)             # 4 layers, 3 segments of 48
    memory = interleaved.prepare(fields, times, valid)                 # fields [B, T, 64, 48]
    out = interleaved.run(stack, x, mask, memory)                      # x [B, T, 144] -> [B, T, 144]
    print(interleaved.gate_report())                                   # the average gate per layer
    rows = interleaved.rows_read(times, valid, scored)                 # scoring: the rows whose bank is read
    memory = interleaved.prepare(fields, times, valid, scored=scored)  # scoring: only `scored` rows are kept
    interleaved.rows_per_part = 1024                                   # scoring: the lean memory
    print(interleaved.work_report(bank))                               # scoring: rows worked out per re-read
    python interleaved_wiring_template.py                              # the blocks in a complete small model
    python -m pytest -q additions/tests/test_model_interleaved_reread.py   # inside the additions package
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

# PLACEHOLDER: width of one field representation; it is the width of a stage-1 token.
FIELD_DIM = 48

# PLACEHOLDER: attention heads of a re-read; FIELD_DIM must be a multiple of it.
NUM_HEADS = 8

# PLACEHOLDER: how many history layers stage 2 has; a re-read is placed after each of them by default.
HISTORY_LAYERS = 4

# PLACEHOLDER: how many of a row's latest eligible earlier transactions the memory holds besides the row
# itself; 0 keeps only the row's own fields.
NUM_BACK = 5

# PLACEHOLDER: how many field representations one transaction has in the bank (64 when the bank holds one
# vector per predictor); 0 when the bank is not given a learned vector per field.
NUM_FIELDS = 64

# PLACEHOLDER: how many units of the batch's time values make one second: 1 when the builder writes whole
# seconds, 1_000_000_000 when it writes nanoseconds.
TIME_UNITS_PER_SECOND = 1


# ----------------------------------------------------------------------------------------------
# which earlier rows a row may use
# ----------------------------------------------------------------------------------------------

def _whole_seconds(times, units_per_second=None):
    """The times of a batch as whole seconds (the division floors, so times before 1970 stay in their second)."""
    units = TIME_UNITS_PER_SECOND if units_per_second is None else units_per_second
    return times if units == 1 else torch.div(times, units, rounding_mode="floor")


def eligible_rows(times, valid, units_per_second=None):
    """Which earlier rows each row may use: the same rule as the mask of stage 2, without the row itself.

    times             integer [B, T]: the time of every slot (any value on padding)
    valid             bool [B, T]: True on real rows
    units_per_second  how many units of `times` make one second; None reads TIME_UNITS_PER_SECOND

    Returns bool [B, T, T]. Entry [b, i, j] is True when both rows are real and row j lies in a
    strictly earlier second than row i. Two rows of one second cannot be put in a trustworthy
    order, so neither is eligible for the other.
    """
    secs = _whole_seconds(times, units_per_second)
    valid = valid.bool()
    earlier = secs.unsqueeze(1) < secs.unsqueeze(2)               # [b, i, j]: j lies before i
    return earlier & valid.unsqueeze(1) & valid.unsqueeze(2)


def latest_prior_rows(times, valid, num_back, units_per_second=None):
    """For every row, the slots of its latest `num_back` eligible earlier rows.

    times, valid, units_per_second   as in `eligible_rows`
    num_back                         how many earlier rows to find

    Returns (index, exists):
      index    int64 [B, T, num_back]: the slot of the row 1 back, 2 back, ... (any slot where none exists)
      exists   bool [B, T, num_back]: False where a row has fewer eligible earlier rows than that

    "Latest" follows the time, not the slot, so the batch does not have to be sorted. Rows of one
    second are taken in the order of their slots, latest slot first. That order decides only
    which of them is called 1 back and which 2 back for a LATER row; it never lets a row see
    another row of its own second.
    """
    eligible = eligible_rows(times, valid, units_per_second)       # [B, T, T]
    B, T = valid.shape
    secs = _whole_seconds(times, units_per_second)
    # The place of every slot in time order (0 is the earliest). The stable sort keeps slot order inside a second.
    order = torch.argsort(secs, dim=1, stable=True)
    place = torch.empty_like(order)
    place.scatter_(1, order, torch.arange(T, device=order.device).expand(B, T))
    # A row that is not eligible gets -1, so the largest values of a line are its latest eligible rows.
    score = place.unsqueeze(1).expand(B, T, T).masked_fill(~eligible, -1)
    found = min(int(num_back), T)
    top, index = torch.topk(score, found, dim=-1)                  # latest first
    exists = top >= 0
    if found < num_back:
        # A batch narrower than the memory: the places beyond its width hold nothing.
        pad = (0, int(num_back) - found)
        index, exists = F.pad(index, pad, value=0), F.pad(exists, pad, value=False)
    return index, exists


# ----------------------------------------------------------------------------------------------
# the bank of field representations
# ----------------------------------------------------------------------------------------------

class PredictorBank(nn.Module):
    """One representation per predictor, for a model whose stage 1 runs on a shorter sequence.

    field_dim   width d of a predictor token; None reads FIELD_DIM
    num_heads   attention heads; None reads NUM_HEADS
    dropout     dropout on the attention weights and on the residual branch

    The tokenizer makes one token per predictor. When stage 1 groups those tokens into a few
    field-level inputs, the single predictors are no longer there to be read again. This block
    keeps them: every predictor token reads the output sequence of stage 1 once, so that it
    carries what the transaction looks like as a whole, and the result is stored next to the
    stage-1 sequence. Stage 1 itself is not touched and costs what it cost before.
    """

    def __init__(self, field_dim=None, num_heads=None, dropout=0.1):
        super().__init__()
        d = FIELD_DIM if field_dim is None else int(field_dim)
        heads = NUM_HEADS if num_heads is None else int(num_heads)
        self.norm_tokens = nn.LayerNorm(d)
        self.norm_context = nn.LayerNorm(d)
        self.read = nn.MultiheadAttention(d, heads, dropout=dropout, batch_first=True)
        self.drop = nn.Dropout(dropout)
        # How many transactions the latest call handed back a bank for; a plain count, not a weight.
        # `InterleavedReread.work_report` shows it, so that a bank called without `rows=` can be seen.
        self.rows_worked = None

    def forward(self, predictor_tokens, stage1_tokens=None, rows=None):
        """The bank of one transaction's predictors.

        predictor_tokens   float [..., P, d]: one token per predictor, as the tokenizer returns them;
                           the leading dimensions are free, usually [B, T]
        stage1_tokens      None, or float [..., L, d]: the output sequence of stage 1 for the same
                           transaction (summary tokens and field-level tokens), same leading dimensions
        rows               None, or bool over the leading dimensions (usually [B, T]): only these
                           transactions are worked out, and the others come back as zeros. It is
                           meant for scoring with `InterleavedReread.rows_read`, whose answer names
                           every row whose bank is read; nothing reads the zeros.

        Returns float [..., P, d]. Without `stage1_tokens` the predictor tokens are returned as
        they are (with `rows`, zero on the other transactions). Every transaction is handled by
        itself: no transaction reads another one here, so the chosen transactions get the numbers
        they get without `rows`, up to rounding.

        `rows_worked` then holds the number of transactions handed back: all of them without
        `rows`, the chosen ones with it.
        """
        if rows is not None:
            rows = rows.bool()
            # The count of the chosen transactions, kept for `InterleavedReread.work_report`.
            self.rows_worked = int(rows.sum())
            if stage1_tokens is None:
                # Nothing is worked out here; the other transactions are set to zero to keep the one rule.
                return predictor_tokens.masked_fill(~rows[..., None, None], 0.0)
            # Only the chosen transactions go through the read, and they are put back in their places.
            out = predictor_tokens.new_zeros(predictor_tokens.shape)
            if rows.any():
                # An empty choice leaves the zero bank as it is, so no layer is handed an empty batch.
                out[rows] = self(predictor_tokens[rows], stage1_tokens[rows])
            return out
        # Without `rows` every transaction is handed back; the count is kept for the work report.
        self.rows_worked = predictor_tokens.shape[:-2].numel()
        if stage1_tokens is None:
            return predictor_tokens
        lead = predictor_tokens.shape[:-2]
        n_predictors, d = predictor_tokens.shape[-2:]
        tokens = predictor_tokens.reshape(-1, n_predictors, d)
        context = self.norm_context(stage1_tokens.reshape(-1, stage1_tokens.shape[-2], d))
        # Each predictor asks the stage-1 outputs of its own transaction; the answer is added to the token.
        seen, _ = self.read(self.norm_tokens(tokens), context, context, need_weights=False)
        return (tokens + self.drop(seen)).reshape(*lead, n_predictors, d)


class RecentFieldMemory(nn.Module):
    """The keys and values that the re-reads query: a row's own fields and those of its latest earlier rows.

    field_dim          width d of a field representation; None reads FIELD_DIM
    num_back           how many latest eligible earlier transactions are held besides the row itself;
                       None reads NUM_BACK, 0 keeps only the row's own fields
    units_per_second   unit of the batch's times; None reads TIME_UNITS_PER_SECOND
    num_fields         how many field representations F a transaction has in the bank; None reads
                       NUM_FIELDS, 0 leaves the learned vector per field out

    The bank is normalised and projected into keys and values once per batch, and every re-read
    of every layer uses that one projection. Each re-read still asks its own question. This
    keeps the cost of a re-read after every layer close to the cost of a single one.

    Every key and value also gets two learned vectors. One is for its look-back position: 0 for
    the row's own fields, 1 for the latest earlier transaction, and so on; without it the fields
    of the current transaction and those of an old one would look alike. The other is for its
    place among the F fields; it lets a question go to one particular field even when the
    representations themselves do not say which field they belong to.
    """

    def __init__(self, field_dim=None, num_back=None, units_per_second=None, num_fields=None):
        super().__init__()
        d = FIELD_DIM if field_dim is None else int(field_dim)
        self.num_back = NUM_BACK if num_back is None else int(num_back)
        self.num_fields = NUM_FIELDS if num_fields is None else int(num_fields)
        self.units_per_second = units_per_second
        self.norm_fields = nn.LayerNorm(d)
        self.key = nn.Linear(d, d)
        self.value = nn.Linear(d, d)
        # One vector per look-back position, added after the projection. Adding it after is the same as
        # adding a vector before a linear projection, and it lets the bank be projected only once.
        self.back_key = nn.Parameter(torch.zeros(self.num_back + 1, d))
        self.back_value = nn.Parameter(torch.zeros(self.num_back + 1, d))
        nn.init.normal_(self.back_key, std=0.02)
        nn.init.normal_(self.back_value, std=0.02)
        # One vector per field, the same for every look-back position, when the number of fields is given.
        self.field_key = self.field_value = None
        if self.num_fields:
            self.field_key = nn.Parameter(torch.zeros(self.num_fields, d))
            self.field_value = nn.Parameter(torch.zeros(self.num_fields, d))
            nn.init.normal_(self.field_key, std=0.02)
            nn.init.normal_(self.field_value, std=0.02)
        self._noted = False

    def forward(self, fields, times=None, valid=None):
        """Keys, values and the mark of empty places for every row of a batch.

        fields   float [B, T, F, d]: F field representations per row
        times    integer [B, T]: the time of every slot; it decides which earlier rows a row gathers
        valid    bool [B, T]: True on real rows. It keeps padding out of every memory, and it lets the
                 re-reads leave padded slots as they are, so that whatever a padded slot holds
                 (anything, also a value that is not a number) cannot spread

        Returns (keys, values, missing, valid):
          keys, values   float [B, T, M, d] with M = (num_back + 1) x F: the row's own F fields first,
                         then those of the row 1 back, 2 back, ...
          missing        None, or bool [B, T, M]: True on the places of an earlier row that does not
                         exist (the row has fewer eligible earlier rows than `num_back`)
          valid          the mask that was given, as bool, or None

        `times` and `valid` belong to every call. Without them the memory holds the row's own
        fields only, padding is not kept out, and one printed line says so.

        Only strictly earlier rows of the same sequence are gathered, by the rule of
        `eligible_rows`, which is the rule of the mask of stage 2. A row therefore never holds a
        later row or another row of its own second in its memory.

        This gathers the keys and values of every row at once. `parts` and `gather` below do the
        same work in two steps, for the two scoring options of `InterleavedReread`.
        """
        B, T, n_fields, d = fields.shape
        keys, values, valid, back = self._project(fields, times, valid)
        if back == 0:
            # The look-back vectors take the number type of the keys, so that mixed precision stays mixed.
            return (keys.add_(self.back_key[0].to(keys.dtype)), values.add_(self.back_value[0].to(values.dtype)),
                    None, valid)
        index, exists = latest_prior_rows(times, valid, back, self.units_per_second)    # [B, T, back]
        sequence = torch.arange(B, device=fields.device)[:, None, None]
        # The row's own slot goes first, then the slots of its earlier rows, so that one gathering step
        # builds [B, T, 1 + back, F, d]. These two tensors are the large ones of this file; the look-back
        # vectors are added to them in place so that no third copy is made.
        own = torch.arange(T, device=fields.device).expand(B, T).unsqueeze(-1)
        places = torch.cat([own, index], dim=-1)                                        # [B, T, 1 + back]
        keys = keys[sequence, places].add_(self.back_key[:, None, :].to(keys.dtype))
        values = values[sequence, places].add_(self.back_value[:, None, :].to(values.dtype))
        # The row's own block is always there; a block of an earlier row that does not exist is marked.
        missing = torch.cat([torch.zeros(B, T, 1, dtype=torch.bool, device=fields.device), ~exists], dim=2)
        missing = missing.unsqueeze(-1).expand(B, T, back + 1, n_fields)
        shape = (B, T, (back + 1) * n_fields)
        return keys.reshape(*shape, d), values.reshape(*shape, d), missing.reshape(shape), valid

    def _project(self, fields, times=None, valid=None, rows=None):
        """The bank normalised and projected into keys and values, once per batch, before any gathering.

        fields, times, valid   as in `forward`
        rows                   None, or bool [B, T]: only these rows are projected, the others hold zeros.
                               Used when only some rows' banks are read at all; such rows are real rows.

        Returns (keys, values, valid, back): keys and values [B, T, F, d] with the vector per field
        already added, `valid` as bool or None, and the number of earlier rows that will be
        gathered (0 when the times or the mask of real rows are missing).
        """
        B, T, n_fields, d = fields.shape
        if valid is not None:
            if rows is None:
                # A padded slot can hold anything. No real row gathers it, but zero keeps it finite.
                fields = fields.masked_fill(~valid.bool()[:, :, None, None], 0.0)
            valid = valid.bool()
        # With `rows` only the chosen rows go through the norm and the two projections; the slots of the
        # others stay zero, since nothing reads them. Without `rows` the lines are those of the first version.
        chosen = fields if rows is None else fields[rows]
        normed = self.norm_fields(chosen)
        keys, values = self.key(normed), self.value(normed)        # [B, T, F, d], projected once
        if self.field_key is not None:
            # In place: `keys` and `values` are fresh results of the projection, so nothing else holds them.
            keys = keys.add_(self.field_key.to(keys.dtype))
            values = values.add_(self.field_value.to(values.dtype))
        if rows is not None:
            # The chosen rows are put back in their slots of a zero bank of the full layout.
            whole_keys, whole_values = keys.new_zeros(B, T, n_fields, d), values.new_zeros(B, T, n_fields, d)
            whole_keys[rows], whole_values[rows] = keys, values
            keys, values = whole_keys, whole_values
        back = self.num_back
        if times is None or valid is None:
            if not self._noted:
                self._noted = True
                print("note: the memory got no times or no mask; every row reads only its own fields, "
                      "and padded slots are not kept out")
            back = 0
        elif times.dtype == torch.bool and not self._noted:
            self._noted = True
            print("note: the times handed to the memory are a yes/no tensor; times and valid look swapped")
        return keys, values, valid, back

    def parts(self, fields, times=None, valid=None, rows=None):
        """The memory before gathering: the projected bank and, for every row, the slots it would gather.

        fields, times, valid   as in `forward`
        rows                   None, or bool [B, T]: only the banks of these rows are projected (see
                               `InterleavedReread.rows_read`); the slots of the others hold zeros

        Returns (keys, values, places, missing, valid):
          keys, values   float [B, T, F, d]: the projected bank, without the look-back vectors
          places         int64 [B, T, 1 + back]: the row's own slot, then the slots of its earlier rows
          missing        None, or bool [B, T, 1 + back]: True where an earlier row does not exist
          valid          the mask that was given, as bool, or None

        `back` is `num_back`, or 0 without times or without the mask of real rows. `gather` turns
        these into the keys and values that `forward` returns, for any choice of rows. The bank is
        (1 + back) times smaller than the gathered keys: [B, T, F, d] here against
        [B, T, (1 + back) F, d] after gathering, 6 times smaller with 5 rows back.
        """
        B, T = fields.shape[:2]
        keys, values, valid, back = self._project(fields, times, valid, rows)
        own = torch.arange(T, device=fields.device).expand(B, T).unsqueeze(-1)
        if back == 0:
            return keys, values, own, None, valid
        index, exists = latest_prior_rows(times, valid, back, self.units_per_second)    # [B, T, back]
        places = torch.cat([own, index], dim=-1)                                        # [B, T, 1 + back]
        # The row's own block is always there; a block of an earlier row that does not exist is marked.
        missing = torch.cat([torch.zeros(B, T, 1, dtype=torch.bool, device=fields.device), ~exists], dim=2)
        return keys, values, places, missing, valid

    def gather(self, keys, values, places, missing, b, t):
        """The keys, values and empty places of the rows (b, t), as `forward` holds them for those rows.

        keys, values, places, missing   what `parts` returns
        b, t                            int64 [n]: the sequence and the slot of every chosen row

        Returns (keys [n, M, d], values [n, M, d], missing [n, M] or None), M = (1 + back) x F, in the
        order of the chosen rows. The numbers are those of `forward` for the same rows.
        """
        slots = places[b, t]                                                            # [n, 1 + back]
        blocks = slots.shape[-1]
        n, n_fields, d = slots.shape[0], keys.shape[-2], keys.shape[-1]
        # One gathering step per tensor, [n, 1 + back, F, d], and the look-back vectors added in place, the
        # same two steps `forward` takes, so the numbers agree with it.
        sequence = b.unsqueeze(-1)
        k = keys[sequence, slots].add_(self.back_key[:blocks, None, :].to(keys.dtype))
        v = values[sequence, slots].add_(self.back_value[:blocks, None, :].to(values.dtype))
        m = None
        if missing is not None:
            m = missing[b, t].unsqueeze(-1).expand(n, blocks, n_fields).reshape(n, blocks * n_fields)
        return k.reshape(n, blocks * n_fields, d), v.reshape(n, blocks * n_fields, d), m


# ----------------------------------------------------------------------------------------------
# one gated re-read
# ----------------------------------------------------------------------------------------------

class GatedReread(nn.Module):
    """One re-read: a row's history-aware vector queries the bank, and a gate decides how much comes in.

    width          width W of the history-aware vector (the width of stage 2)
    field_dim      width d of a field representation; None reads FIELD_DIM
    num_segments   number S of queries the vector is cut into; None means W / d, rounded up when W is
                   not a multiple of d
    num_heads      attention heads; None reads NUM_HEADS
    ff_multiplier  the feed-forward layer is this many times as wide as a segment
    dropout        dropout on the attention weights and on the two branches
    gate           True for the learned gate, False to let every read in whole
    """

    def __init__(self, width, field_dim=None, num_segments=None, num_heads=None, ff_multiplier=4, dropout=0.1,
                 gate=True):
        super().__init__()
        d = self.field_dim = FIELD_DIM if field_dim is None else int(field_dim)
        self.num_heads = NUM_HEADS if num_heads is None else int(num_heads)
        # By default the vector is cut into as many segments as fit; a width of 144 gives three of 48.
        s = self.num_segments = -(-width // d) if num_segments is None else int(num_segments)
        # When the vector already is S segments side by side it is only cut. Otherwise a learned
        # projection makes S segments out of it.
        self.to_segments = nn.Identity() if width == s * d else nn.Linear(width, s * d)
        self.norm_query = nn.LayerNorm(d)
        self.query = nn.Linear(d, d)
        self.out = nn.Linear(d, d)
        self.norm_ff = nn.LayerNorm(d)
        self.feed_forward = nn.Sequential(nn.Linear(d, d * ff_multiplier), nn.GELU(), nn.Dropout(dropout),
                                          nn.Linear(d * ff_multiplier, d))
        self.drop = nn.Dropout(dropout)
        self.attn_dropout = float(dropout)
        # The gate reads the question and the answer side by side and gives one number between 0 and 1
        # for every segment. It starts near one half.
        self.gate = nn.Sequential(nn.Linear(2 * d, d), nn.GELU(), nn.Linear(d, 1)) if gate else None
        # The layer that writes the result back starts at zero and has no constant term. A fresh block is
        # therefore exactly a no-op, and a block whose gate is close to zero adds close to nothing. Its
        # weights still receive a
        # gradient from the first step on (the gradient of a weight is its input times the error signal,
        # and the input is not zero), so the block leaves the no-op state as soon as that helps the loss.
        self.write_back = nn.Linear(s * d, width, bias=False)
        nn.init.zeros_(self.write_back.weight)
        # The gate values of the latest call, [..., S], kept for reading; they are not part of the weights.
        self.last_gate = None

    def forward(self, history, keys, values, missing=None):
        """Add to every row's history-aware vector what it reads from the bank.

        history   float [..., W]: one history-aware vector per row; the leading dimensions are free,
                  usually [B, T]
        keys      float [..., M, d]: the keys of the row's bank, from `RecentFieldMemory`
        values    float [..., M, d]: the values of the same places
        missing   None, or bool [..., M]: True on places that hold nothing

        Returns float [..., W]. A row reads only the M places of its own bank.
        """
        lead = history.shape[:-1]
        s, d, heads = self.num_segments, self.field_dim, self.num_heads
        n_places = keys.shape[-2]
        segments = self.to_segments(history).reshape(-1, s, d)                    # [N, S, d]
        asked = self.norm_query(segments)
        # Attention written out, so that the keys and values projected once by the memory can be used as
        # they are. Each segment asks its own question; segments are cut, not averaged, so the parts of
        # the history vector can each look for something else.
        q = self.query(asked).view(-1, s, heads, d // heads).transpose(1, 2)      # [N, heads, S, d / heads]
        # Keys and values are brought to the number type of the question, which matters only when the
        # model runs in mixed precision and the two were made in different types.
        k = keys.to(q.dtype).reshape(-1, n_places, heads, d // heads).transpose(1, 2)    # [N, heads, M, d / heads]
        v = values.to(q.dtype).reshape(-1, n_places, heads, d // heads).transpose(1, 2)
        # True lets a place take part. The row's own places are never missing, so no question is left
        # without anything to read.
        allowed = None if missing is None else ~missing.reshape(-1, 1, 1, n_places)
        drop = self.attn_dropout if self.training else 0.0
        read = F.scaled_dot_product_attention(q, k, v, attn_mask=allowed, dropout_p=drop)
        read = self.out(read.transpose(1, 2).reshape(-1, s, d))                   # [N, S, d]
        # What the re-read found: the answer, and a small network's working of the answer in the light
        # of the question. The segment itself is not part of it, so a gate near zero adds next to nothing.
        found = self.drop(read)
        found = found + self.drop(self.feed_forward(self.norm_ff(segments + found)))
        if self.gate is not None:
            opened = torch.sigmoid(self.gate(torch.cat([asked, read], dim=-1)))   # [N, S, 1]
            self.last_gate = opened.detach().reshape(*lead, s)
            found = opened * found
        # Join the segments again and add the result to the vector that came in. With the zero start of
        # `write_back` this line returns `history` itself at first.
        return history + self.write_back(found.reshape(*lead, s * d))


# ----------------------------------------------------------------------------------------------
# a re-read after every history layer
# ----------------------------------------------------------------------------------------------

class InterleavedReread(nn.Module):
    """The memory and one gated re-read for each chosen history layer.

    width            width W of stage 2
    history_layers   how many history layers stage 2 has; None reads HISTORY_LAYERS. `run` sees the
                     stack and goes by the stack's own number of layers instead. A model that runs its
                     own loop and calls `after_layer` must give its own number of history layers here:
                     the block cannot see that loop, and the fifth check of the template shows a
                     wrong number.
    after_layers     the layers (1 is the first) that are followed by a re-read; None means every layer
    field_dim, num_segments, num_heads, ff_multiplier, dropout, gate   as in `GatedReread`
    num_back         as in `RecentFieldMemory`; None reads NUM_BACK
    units_per_second unit of the batch's times; None reads TIME_UNITS_PER_SECOND
    num_fields       as in `RecentFieldMemory`; None reads NUM_FIELDS

    rows_per_part    None (the default) gathers the keys and values of every row once, in `prepare`.
                     A number turns on the lean memory: `prepare` keeps only the projected bank
                     [B, T, F, d] and the slots of the earlier rows, and every re-read gathers its keys
                     and values for this many rows at a time. See "Two options for scoring" below.

    Three settings cover the designs:
      after every layer, own fields only        InterleavedReread(width, num_back=0)
      memory of recent fields, one re-read      InterleavedReread(width, after_layers=(4,), num_back=5)
      both                                      InterleavedReread(width, num_back=5)

    Two options for scoring, both off by default. In evaluation mode the scores they give are
    equal to those of the full path up to rounding (below 1e-5). In training mode the mark of
    scored rows is left unused (one printed line says so), so training always takes the full path.

      scored rows   `prepare(fields, times, valid, scored=...)` with a bool [B, T] that is True on
                    the rows whose result is wanted, for example the last real row of every window
                    when one window is scored per transaction. The re-read after the last history
                    layer is then worked out for those rows only, since nothing reads the other
                    rows after it. `run` takes the last layer from the stack it is handed;
                    `after_layer` takes it from `history_layers`. When no re-read follows an
                    earlier layer (design M), the memory is gathered for the scored rows only, and
                    the bank is needed only for the rows `rows_read` names; `run` then stops with
                    a plain error on a stack whose last layer is not the one that re-read follows,
                    since such a memory cannot give the right scores there. After the last
                    layer the rows that are not scored may hold anything; only the scored rows are
                    to be read. Re-reads after earlier layers still run on every row, because the
                    later history layers read every row.

      lean memory   `rows_per_part` in the constructor, or set on a built block
                    (`block.rows_per_part = 1024`). It belongs to the block and not to `prepare`
                    because it is a setting of the machine that scores, not of a batch: a scoring
                    script switches it on for a model whose own forward pass then stays exactly as
                    it is, and it is not a weight, so the saved weights do not change. The memory
                    then never holds the gathered keys and values of all rows at once, which bounds
                    the peak memory at scoring so that the batch does not have to shrink. It
                    gathers once per re-read (four times in design AM instead of once) and so costs
                    time. With gradients switched on it saves little, because every part's gathered
                    keys and values are kept for the backward pass all the same. For design A it
                    saves nothing and costs a little time; leave it off there.

    `work_report` says, for the latest call, how many rows every re-read worked out and how many
    rows its memory was gathered for, and how many rows the bank worked out. It is the way to see
    that the scored path saves what it should.
    """

    def __init__(self, width, history_layers=None, after_layers=None, field_dim=None, num_segments=None,
                 num_heads=None, num_back=None, ff_multiplier=4, dropout=0.1, gate=True, units_per_second=None,
                 num_fields=None, rows_per_part=None):
        super().__init__()
        n_layers = HISTORY_LAYERS if history_layers is None else int(history_layers)
        chosen = range(1, n_layers + 1) if after_layers is None else sorted(int(n) for n in after_layers)
        self.after_layers = tuple(chosen)
        # The number of the last history layer for a model that calls `after_layer` in its own loop; `run`
        # counts the layers of the stack it is handed instead.
        self.history_layers = n_layers
        # A plain setting, not a weight; None keeps the memory as it always was.
        self.rows_per_part = rows_per_part
        self.memory = RecentFieldMemory(field_dim=field_dim, num_back=num_back, units_per_second=units_per_second,
                                        num_fields=num_fields)
        # Every layer gets a re-read of its own. Their weights are not shared: the question a row can ask
        # after the first layer is not the question it can ask after the last.
        self.rereads = nn.ModuleDict({str(n): GatedReread(width, field_dim=field_dim, num_segments=num_segments,
                                                          num_heads=num_heads, ff_multiplier=ff_multiplier,
                                                          dropout=dropout, gate=gate)
                                      for n in self.after_layers})
        # What the latest call worked out, per re-read: (rows worked out, rows the memory was gathered for).
        # Plain bookkeeping for `work_report`; it is not a weight and changes no result.
        self._work = {}
        # Per re-read, the rows a scored pass worked out (bool [B, T]), or None for a pass over every row.
        # `gate_report` leaves out only the rows a scored pass did not work out.
        self._worked = {}
        # Each of the two notes below is printed once per block, so that a loop over batches stays readable.
        self._noted_training = False
        self._noted_unrun = False

    def prepare(self, fields, times=None, valid=None, scored=None):
        """The memory of one batch, built once and used by every re-read.

        fields, times, valid   as in `RecentFieldMemory.forward`
        scored                 None, or bool [B, T]: True on the rows whose result is wanted. With it the
                               re-read after the last history layer is worked out for those rows only,
                               and rows that are not scored may hold anything after the last layer.
                               In training mode it is left unused, and one line says so (once per block):
                               training always takes the full path.

        With `scored` left out (or unused) and no `rows_per_part`, the result is the one of
        `RecentFieldMemory.forward`, the four entries (keys, values, missing, valid), exactly as in
        the first version. Otherwise two entries follow them, (keys, values, missing, valid, scored,
        places), and the first three take one of three forms:
          gathered for every row   keys, values [B, T, M, d], missing [B, T, M]; places is None.
                                   This is the form when a re-read follows an earlier layer.
          gathered for scored rows keys, values [N, M, d], missing [N, M], one line per real scored
                                   row in the order of torch.nonzero; places is None. This is the
                                   form of design M with `scored`.
          lean                     keys, values [B, T, F, d] (the projected bank), places
                                   [B, T, 1 + back] and missing [B, T, 1 + back] by block (or
                                   None); the re-reads gather for themselves. This is the form
                                   whenever `rows_per_part` is set.
        Code that hands the result on to `run` or `after_layer` as an opaque value works with all
        of them. In the form for scored rows the bank of a row outside `rows_read` is not read, so
        such a bank may hold anything (zeros from `PredictorBank(..., rows=...)`).
        """
        # A new batch: the counts of the latest call start again, so `work_report` never mixes two batches.
        self._work, self._worked = {}, {}
        if scored is not None and self.training:
            # The scored path is for scoring. In training every row's result feeds the loss through the
            # later layers, so the mark is dropped and the full path is taken.
            if not self._noted_training:
                self._noted_training = True
                print("note: prepare was given scored rows in training mode; the mark is left unused and the "
                      "full path is taken (the scored path is for evaluation mode only)")
            scored = None
        if scored is None and self.rows_per_part is None:
            # The first version, line for line: keys and values of every row, gathered once.
            return self.memory(fields, times, valid)
        if scored is not None:
            scored = scored.bool()
        # Without a re-read before the last one, only the scored rows' memory is ever read.
        compact = scored is not None and not self._reread_before_last()
        if not compact and self.rows_per_part is None:
            return (*self.memory(fields, times, valid), scored, None)
        rows = self.rows_read(times, valid, scored) if compact else None
        keys, values, places, missing, kept = self.memory.parts(fields, times, valid, rows=rows)
        if self.rows_per_part is not None:
            return keys, values, missing, kept, scored, places
        b, t = torch.nonzero(self._rows_to_work(scored, kept), as_tuple=True)
        keys, values, missing = self.memory.gather(keys, values, places, missing, b, t)
        return keys, values, missing, kept, scored, None

    def _reread_before_last(self):
        """True when a re-read follows a history layer before the last one; that re-read needs every row."""
        return any(number < self.history_layers for number in self.after_layers)

    def _compact(self, memory):
        """True when `memory` was built for the scored rows only (design M with `scored`, gathered or lean).

        It is the same test `prepare` made: a mark of scored rows, and no re-read before layer
        `history_layers`. Such a memory serves only a re-read after the stack's last layer.
        """
        return len(memory) == 6 and memory[4] is not None and not self._reread_before_last()

    @staticmethod
    def _rows_to_work(scored, valid):
        """The rows whose last re-read is worked out: scored real rows (every scored row without a mask)."""
        return scored if valid is None else scored & valid

    def rows_read(self, times, valid, scored=None):
        """The rows whose bank is read at all, as bool [B, T].

        times, valid   what is handed to `prepare` (either may be None, as there)
        scored         what is handed to `prepare`

        Every real row (every row without `valid`) when `scored` is None, when a re-read follows
        an earlier layer, or in training mode (where `prepare` leaves the mark unused). Otherwise
        the scored real rows and their latest `num_back` eligible earlier rows, the rows whose
        fields their memory holds. A model hands this to `PredictorBank(..., rows=...)` so that the
        bank of no other row is worked out.
        """
        if valid is not None:
            real = valid.bool()
        else:
            real = torch.ones(scored.shape if scored is not None else times.shape, dtype=torch.bool,
                              device=(scored if scored is not None else times).device)
        # In training mode `prepare` takes the full path, so every real row's bank is needed.
        if scored is None or self.training or self._reread_before_last():
            return real
        work = self._rows_to_work(scored.bool(), None if valid is None else real)
        if times is None or valid is None or self.memory.num_back == 0:
            # The memory then holds the row's own fields only (see `RecentFieldMemory.forward`).
            return work
        index, exists = latest_prior_rows(times, real, self.memory.num_back, self.memory.units_per_second)
        out = work.clone()
        b, t = torch.nonzero(work, as_tuple=True)
        found = exists[b, t]                                                    # [n, num_back]
        # Every earlier row that a scored row's memory holds is marked; empty places are left out.
        out[b.unsqueeze(-1).expand_as(found)[found], index[b, t][found]] = True
        return out

    def after_layer(self, number, history, memory, last_layer=None):
        """What the rows hold after history layer `number` and its re-read.

        number       the history layer that has just run (1 is the first)
        history      float [B, T, W]: the rows only, without any position put in front of them
        memory       the result of `prepare` for the same batch
        last_layer   the number of the last history layer. `run` hands the stack's own count; None
                     reads `history_layers`, which must then be the model's own number of history
                     layers (the block cannot see a loop of the model's own)

        Returns float [B, T, W]; `history` itself when the layer has no re-read. A padded slot keeps
        what it held: its re-read is not written back, so nothing a padded slot carries can spread.
        When `prepare` was given `scored`, the re-read after the last history layer is worked out
        for the scored real rows only, and every other row keeps what it held before it: such
        rows may hold anything after the last layer and are not to be read.
        """
        if str(number) not in self.rereads:
            return history
        last = self.history_layers if last_layer is None else int(last_layer)
        # Every slot of the rows is worked out unless a scored pass below says otherwise.
        every = history.shape[:-1].numel()
        self._worked[number] = None
        if len(memory) == 4:
            # The first version, line for line; the count only notes what was worked out.
            keys, values, missing, valid = memory
            self._work[number] = (every, keys.shape[:-2].numel())
            read = self.rereads[str(number)](history, keys, values, missing)
            return read if valid is None else torch.where(valid.unsqueeze(-1), read, history)
        reread = self.rereads[str(number)]
        keys, values, missing, valid, scored, places = memory
        if self._compact(memory) and number != last:
            # The memory holds only the scored rows' banks, which this re-read cannot use for every row.
            raise ValueError(f"after_layer: the memory was built for scored rows only, which serves only a re-read "
                             f"after the last history layer ({last}), but layer {number} was called. Give the "
                             f"block history_layers equal to the model's own number of history layers, or "
                             f"call prepare without scored.")
        if scored is not None and number == last:
            work = self._rows_to_work(scored, valid)
            n_work = int(work.sum())
            # The memory rows: one line per scored row when gathered for them, every slot when gathered for
            # every row, and the rows worked out when the lean memory gathers part by part.
            self._work[number] = (n_work, keys.shape[:-2].numel() if places is None else n_work)
            self._worked[number] = work
            return self._read_rows(reread, history, memory, work)
        self._work[number] = (every, keys.shape[:-2].numel() if places is None else every)
        if places is None:
            read = reread(history, keys, values, missing)
        else:
            # Lean memory on a layer that every row needs: every slot is worked out, part by part, so that
            # the result and the gates are those of the first version.
            read = self._read_rows(reread, history, memory, torch.ones(history.shape[:-1], dtype=torch.bool,
                                                                         device=history.device))
        return read if valid is None else torch.where(valid.unsqueeze(-1), read, history)

    def _read_rows(self, reread, history, memory, work):
        """`history` with the rows of `work` (bool [B, T]) replaced by their re-read; the others as they were.

        The gates of the call are kept as [B, T, S] with not-a-number on the rows that were not
        worked out; `gate_report` leaves those rows out.
        """
        keys, values, missing, _, _, places = memory
        b, t = torch.nonzero(work, as_tuple=True)
        if b.numel() == 0:
            # No row to work out; the gates say so by being empty.
            if reread.gate is not None:
                reread.last_gate = history.new_full((*history.shape[:-1], reread.num_segments), float("nan"))
            return history
        reads, gates = [], []
        if places is None:
            if keys.dim() == history.dim() + 1:
                # Gathered for every row: the chosen rows are picked out.
                keys, values = keys[b, t], values[b, t]
                missing = None if missing is None else missing[b, t]
            # Otherwise the memory was gathered for exactly these rows, in this order.
            reads.append(reread(history[b, t], keys, values, missing))
            gates.append(reread.last_gate)
        else:
            step = max(1, int(self.rows_per_part))
            for start in range(0, b.numel(), step):
                # One part: its keys and values are gathered, read, and let go before the next part.
                bb, tt = b[start:start + step], t[start:start + step]
                k, v, m = self.memory.gather(keys, values, places, missing, bb, tt)
                reads.append(reread(history[bb, tt], k, v, m))
                gates.append(reread.last_gate)
        out = history.clone()
        out[b, t] = torch.cat(reads) if len(reads) > 1 else reads[0]
        if reread.gate is not None:
            whole = history.new_full((*history.shape[:-1], reread.num_segments), float("nan"))
            whole[b, t] = torch.cat(gates) if len(gates) > 1 else gates[0]
            reread.last_gate = whole
        return out

    def run(self, stack, x, mask, memory, n_prefix=0, key_padding=None):
        """Run the history layers one by one, with the re-read after each chosen layer.

        stack         stage 2: an nn.TransformerEncoder, or a list of its layers
        x             float [B, n_prefix + T, W]: what goes into stage 2
        mask          the mask that stage 2 already takes (zero where reading is allowed, minus infinity
                      where it is not), or None
        memory        the result of `prepare` for the same batch
        n_prefix      positions in front of the rows that are not transactions; they are left as they are
        key_padding   None, or the `src_key_padding_mask` that stage 2 is called with today, when it is
                      called with one

        Returns float [B, n_prefix + T, W], as `stack(x, mask=mask)` does. With fresh re-reads the
        two results are equal.

        The stack's own number of layers decides which layer is the last one; `history_layers`
        is not used here. A re-read listed after a layer the stack does not have never runs, and
        one printed line says so (once per block). A memory built for scored rows only (design M
        with `scored`) serves only a re-read after the stack's last layer; any other stack gets a
        plain error that names both numbers.

        A row's re-read uses the row's own fields and, with a memory, the fields of strictly
        earlier rows. The next history layer then reads the rows under the same mask as before,
        so nothing reaches a row that the mask does not let it read.

        Two things are those of the layers themselves and are not changed here. `x` has to be
        finite on padded slots (zero is the usual choice): a value that is not a number spreads
        through attention even at a weight of zero. And a position that the masks leave with
        nothing to read gives a result that is not a number, so `mask` and `key_padding`
        together must leave every position at least itself.
        """
        layers = stack.layers if hasattr(stack, "layers") else stack
        n_layers = len(layers)
        unrun = [number for number in self.after_layers if number > n_layers]
        if unrun and not self._noted_unrun:
            # Said once per block: a loop over batches would otherwise repeat it for every batch.
            self._noted_unrun = True
            print(f"note: the stack has {n_layers} history layers; the re-read after layer "
                  f"{', '.join(str(n) for n in unrun)} never runs")
        if self._compact(memory) and (n_layers not in self.after_layers
                                      or any(number < n_layers for number in self.after_layers)):
            # The memory holds the scored rows' banks only; a re-read that is not the stack's last would read
            # every row from it, and the stack's last layer would not be followed by the scored re-read.
            listed = ", ".join(str(number) for number in self.after_layers)
            raise ValueError(f"run: the memory was built for scored rows only, which serves only a re-read after "
                             f"the stack's last layer, but the block has its re-read after layer {listed} and "
                             f"the stack has {n_layers} layers. Build the block with history_layers={n_layers} "
                             f"(design M: after_layers=({n_layers},)), or call prepare without scored.")
        for number, layer in enumerate(layers, start=1):
            x = layer(x, src_mask=mask, src_key_padding_mask=key_padding)
            if str(number) in self.rereads:
                rows = self.after_layer(number, x[:, n_prefix:], memory, last_layer=n_layers)
                x = rows if n_prefix == 0 else torch.cat([x[:, :n_prefix], rows], dim=1)
        last = getattr(stack, "norm", None)
        return x if last is None else last(x)

    def work_report(self, bank=None):
        """What the latest call worked out, to see that the scored path saves what it should.

        bank   None, or the `PredictorBank` the model called for the same batch

        Returns {"rereads": {layer number: {"rows": rows worked out, "memory_rows": rows the memory
        was gathered for}}, "bank_rows": transactions the bank handed back, or None without `bank`}.
        Only re-reads that ran since the latest `prepare` are listed. Rows are counted as slots,
        padded slots included, since the full path works those out too.

        On the full path every re-read works out every slot (B x T), and the memory is gathered for
        every slot. On the scored path the last re-read works out the scored real rows only; in
        design M the memory is gathered for them only, and a bank called with `rows=rows_read(...)`
        works out the scored rows and their earlier rows only. A last re-read that still works out
        every slot says that the scored path was not taken; a bank count of B x T says that the
        bank was called without `rows=` (the scores stay right, only the time is lost).
        """
        rereads = {number: {"rows": rows, "memory_rows": memory_rows}
                   for number, (rows, memory_rows) in sorted(self._work.items())}
        return {"rereads": rereads, "bank_rows": None if bank is None else bank.rows_worked}

    def look_at_wiring(self, mask, times, valid, memory, n_prefix=0, key_padding=None):
        """One look that says whether this block is wired to the model the way the mask of stage 2 implies.

        mask, key_padding   what stage 2 is called with for this batch
        times, valid        what was handed to `prepare`
        memory              what `prepare` returned
        n_prefix            what is handed to `run`

        Returns the share of `mask_agreement`, with the time unit this block was built with; 0.0
        when the memory itself is not whole. It prints one or two lines. The memory is whole when
        it was given the times and the mask of real rows, holds as many places per row as the
        block was built for ((rows back + 1) x fields), and holds for every real row the earlier
        rows that the times handed to this look imply. 1.0 is the only good answer.

        1.0 says that the memory and the mask of stage 2 follow the same rule. It does not say
        that the rule is right: a mask built with the wrong time unit agrees with a memory built
        with the same wrong unit. One value of the times settles that: about 1.7e9 is seconds,
        about 1.7e18 is nanoseconds.
        """
        keys, _, missing, kept = memory[:4]
        # The two scoring options add (scored, places) to the memory; the first version has neither.
        scored, places = memory[4:] if len(memory) == 6 else (None, None)
        back = self.memory.num_back
        # Places per row: the gathered keys hold them side by side; the lean memory holds the bank and the
        # slots of the earlier rows, and gathers (1 + back) blocks of F fields for a row.
        n_places = keys.shape[-2] if places is None else places.shape[-1] * keys.shape[-2]
        # The memory for scored rows only holds one line per scored real row, not [B, T].
        compact = places is None and scored is not None and keys.dim() == 3
        whole = kept is not None and (back == 0 or missing is not None)
        if self.memory.num_fields:
            whole = whole and n_places == (back + 1) * self.memory.num_fields
        if not whole:
            print(f"look_at_wiring: the memory is not whole: it holds {n_places} places per row, "
                  f"built for {back} rows back; prepare needs the bank, the times and the mask "
                  f"of real rows")
        elif back:
            # The memory itself is read: every real row must hold as many earlier rows as the times and
            # the mask of real rows handed to this look say it has, up to the size of the memory.
            B, T = valid.shape
            real = valid.bool()
            if places is not None:
                blocks = ~missing                                                  # [B, T, 1 + back]
            else:
                blocks = (~missing).reshape(*missing.shape[:-1], back + 1, -1)[..., 0]
            held = blocks.sum(dim=-1) - 1
            due = eligible_rows(times, real, self.memory.units_per_second).sum(dim=-1).clamp(max=back)
            # For scored rows only the scored real rows have a memory; their lines follow torch.nonzero.
            due_rows = due[self._rows_to_work(scored, kept)] if compact else due[real]
            held_rows = held if compact else held[real]
            if not torch.equal(held_rows, due_rows):
                whole = False
                print("look_at_wiring: the memory does not hold the earlier rows that these times imply; "
                      "prepare was handed other times or another mask of real rows (or the two swapped)")
        share = mask_agreement(mask, times, valid, n_prefix=n_prefix, key_padding=key_padding,
                               units_per_second=self.memory.units_per_second)
        return share if whole else 0.0

    def gate_report(self, rows=None):
        """The average gate of every re-read in its latest call.

        rows   None for every slot, or bool [B, T]: the slots to average over (real rows, frauds, ...)

        Returns {layer number: average gate}. A value near 0 says the layer's re-read is mostly
        shut out; a value near 1 says it is mostly let in. Layers without a gate are left out,
        and so is every layer when `rows` selects nothing.

        `rows` has the layout the re-reads saw in that call: [B, T] without any position in front
        of the rows, and repeated the same way when the batch was repeated before stage 2.

        When `prepare` was given `scored` (in evaluation mode), the re-read after the last history
        layer was worked out for the scored real rows only, and its gates exist for those rows only.
        The value of that layer is then the average over the scored rows among `rows`, and the
        layer is left out when `rows` holds no scored row. Every other layer, and every call
        without `scored`, is averaged over `rows` exactly as before, a gate that is not a number
        included. A report over the real rows of a scoring batch therefore gives, for the last
        layer, the average over the scored rows.
        """
        report = {}
        for number in self.after_layers:
            opened = self.rereads[str(number)].last_gate
            if opened is None:
                continue
            chosen = opened if rows is None else opened[rows.bool()]
            worked = self._worked.get(number)
            if worked is not None and worked.shape == opened.shape[:-1]:
                # A scored pass: only the rows it worked out carry a gate, so the others are left out.
                chosen = opened[worked if rows is None else worked & rows.bool()]
            if chosen.numel():
                report[number] = float(chosen.mean())
        return report


# ----------------------------------------------------------------------------------------------
# a look at the wiring
# ----------------------------------------------------------------------------------------------

def mask_agreement(mask, times, valid, num_heads=None, n_prefix=0, units_per_second=None, key_padding=None):
    """The share of row pairs on which the memory and the mask of stage 2 agree about who may read whom.

    mask              the mask stage 2 takes for this batch: float (minus infinity where reading is not
                      allowed) or bool (True where it is not allowed); [L, L], [B, L, L],
                      [B * heads, L, L] or [B, heads, L, L], with L = n_prefix + T
    times, valid      the [B, T] times and mask of real rows that are handed to `prepare`
    num_heads         heads of stage 2 for a mask of [B * heads, L, L]; None works it out from the mask
    n_prefix          positions in front of the rows that are not transactions
    units_per_second  the unit handed to the memory; None reads TIME_UNITS_PER_SECOND
    key_padding       None, or the key padding mask stage 2 is called with, [B, L]: bool (True on
                      padding) or float (minus infinity on padding). A padded position then neither
                      reads nor is read, as far as this look is concerned.

    Returns a number between 0 and 1 and prints one line. The pairs looked at are every pair of
    different rows that `valid` calls real, and every pair the mask opens. On each of them the
    memory may gather row j for row i exactly when the mask lets row i read row j, or the pair
    counts against the share. 1.0 means the two agree everywhere.

    Anything below 1.0 points at the wiring: another time unit than the mask was built with,
    another `n_prefix`, `times` and `valid` that belong to another layout, or a `valid` that is
    True on padding where it should be True on real rows. A fresh block changes no score, so
    equal scores cannot show such a slip; this call can.
    """
    B, T = valid.shape
    open_ = ~mask if mask.dtype == torch.bool else torch.isfinite(mask)
    if open_.dim() == 4:
        open_ = open_[:, 0]                                         # [B, heads, L, L]: keep the first head
    if open_.dim() == 2:
        open_ = open_.unsqueeze(0).expand(B, -1, -1)
    elif open_.shape[0] != B:
        heads = open_.shape[0] // B if num_heads is None else int(num_heads)
        open_ = open_[::heads]                                      # one copy per head: keep the first of each
    if key_padding is not None:
        padded = key_padding if key_padding.dtype == torch.bool else ~torch.isfinite(key_padding)
        open_ = open_ & ~padded.unsqueeze(1) & ~padded.unsqueeze(2)
    open_ = open_[:, n_prefix:n_prefix + T, n_prefix:n_prefix + T].to(valid.device)
    gathers = eligible_rows(times, valid, units_per_second)
    real = valid.bool()
    different = ~torch.eye(T, dtype=torch.bool, device=valid.device)
    pairs = ((real.unsqueeze(1) & real.unsqueeze(2)) | open_ | gathers) & different
    same = (open_ == gathers) & pairs
    share = float(same.sum()) / max(int(pairs.sum()), 1)
    # How many of the pairs the mask opens lie between rows that `valid` calls real. None of them does
    # when `valid` is True on padding.
    opened = open_ & different
    among_real = int((opened & real.unsqueeze(1) & real.unsqueeze(2)).sum())
    hint = ""
    if share < 1.0:
        hint = "; check the time unit, n_prefix, and that times and valid match the mask"
        if int(opened.sum()) and among_real == 0:
            hint = "; none of the pairs the mask opens lies between rows that valid calls real: valid looks reversed"
    print(f"mask_agreement: the memory and the mask agree on {share:.4%} of {int(pairs.sum())} row pairs" + hint)
    return share


# ----------------------------------------------------------------------------------------------
# starting from a trained model
# ----------------------------------------------------------------------------------------------

def start_from(model, weights):
    """Copy into `model` every tensor of `weights` that has the same name and the same shape.

    model     the model with the new blocks
    weights   the weights of the trained model without them: a name-to-tensor table (the result of
              `trained.state_dict()`), or a saved checkpoint that holds such a table under "state_dict"

    Returns (taken, fresh, unused): the names that were copied, the names of `model` that keep their
    fresh start, and the names of `weights` that went nowhere. Two printed lines say how many
    tensors went where and name what needs a look.

    The grown model scores as the trained model did when `fresh` holds the new blocks only and
    `unused` is empty. A trained tensor in `unused` (another shape, or a name the model does not
    have) is a part of the trained model that was lost. When no name matches at all, the names
    are tried once more without their first part, which is how a wrapper around the model shows
    ("module.head.weight" for "head.weight").
    """
    if "state_dict" in weights and not torch.is_tensor(weights["state_dict"]):
        weights = weights["state_dict"]
    tensors = {name: tensor for name, tensor in weights.items() if torch.is_tensor(tensor)}
    own = model.state_dict()

    def matching(table):
        return {name: tensor for name, tensor in table.items() if name in own and own[name].shape == tensor.shape}

    taken = matching(tensors)
    if not taken:
        without_first = {name.split(".", 1)[1]: tensor for name, tensor in tensors.items() if "." in name}
        if matching(without_first):
            tensors, taken = without_first, matching(without_first)
            print("start_from: the names matched only without their first part; that part was dropped")
    model.load_state_dict(taken, strict=False)
    fresh = sorted(set(own) - set(taken))
    unused = sorted(set(tensors) - set(taken))
    print(f"start_from: {len(taken)} tensors taken from the trained model, {len(fresh)} keep their fresh start, "
          f"{len(unused)} trained tensors were not used")
    if unused:
        print("start_from: not used (another shape, or no such name): " + ", ".join(unused[:8])
              + (" ..." if len(unused) > 8 else ""))
    return sorted(taken), fresh, unused


def train_only(model, parts):
    """Leave only the weights of `parts` trainable and switch every other weight of `model` off.

    model   the whole model
    parts   the modules that are to be trained, for example [model.interleaved, model.predictor_bank]

    Returns the list of trainable weights, ready for an optimiser. With the rest of the model
    held still, any change in the scores comes from the new blocks alone, and the trained
    model itself is the comparison.

    An optimiser built on the returned list touches nothing else. An optimiser built on all the
    weights of the model also leaves the others where they are, because a weight without a
    gradient is skipped; the gradients left over from earlier steps are cleared here for that.
    Layers that keep running statistics of their inputs (batch normalisation) are not held
    still by this; a model that has such layers puts them in evaluation mode as well.
    """
    for weight in model.parameters():
        weight.requires_grad_(False)
        weight.grad = None
    chosen = []
    for part in parts:
        for weight in part.parameters():
            weight.requires_grad_(True)
            chosen.append(weight)
    return chosen
