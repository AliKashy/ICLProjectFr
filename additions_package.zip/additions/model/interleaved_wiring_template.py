"""A stand-in two-stage model with the gated field re-reads wired in, and the checks that say a wiring is right.

What this file does
-------------------
It is a template for fitting interleaved_reread.py into a model that this file cannot see. It holds:

    StandInModel         a small complete model with the layout the blocks were written for: a tokenizer
                         that makes one token per predictor, a grouping step that turns those tokens into
                         a few field-level inputs, stage 1 over summary tokens and field-level inputs,
                         stage 2 over one vector per transaction under the strict time rule, the re-read
                         the model already has after stage 2, and a linear head
    the five edits       the places where the new blocks go in, each marked "EDIT n of 5"; one more
                         line, marked "EDIT 3b", is there for the second check only
    the placeholders     every name or value that belongs to the model in use, each marked
                         "PLACEHOLDER W1" to "PLACEHOLDER W14" with what belongs there and where to
                         find it, and "PLACEHOLDER W15" for the OPTIONAL scored path of scoring
    four checks          equal_scores, wiring_agrees, later_rows_change_nothing, only_new_weights_move:
                         each takes a model and a batch, so they run on the real model as they are
    a fifth check        scored_rows_agree: the OPTIONAL scored path gives the scores of the full path
                         on the scored rows, and the marked pass really did less work; it is needed
                         only by a model that takes that path
    main                 builds made-up rows, trains the stand-in briefly, grows it with each design,
                         runs the five checks and prints one line per design

Why it exists
-------------
The blocks take plain tensors, so fitting them in is a matter of finding five places in a forward
pass. Those places have other names in every code base, and three slips leave no trace in the
scores of a freshly grown model: a wrong time unit, a wrong count of positions in front of the rows,
and a bank that belongs to another layout than the rows. A complete model that runs, with the edits
marked in place and with checks that catch those slips, is quicker to follow than a description.

Where it goes
-------------
Nowhere in the pipeline. It is read next to the model in use, the five edits are copied into that
model's own file, and the four checks are then run on that model with one of its own batches.

What to change for the pod
--------------------------
Nothing in this file has to change for it to run. In the model in use, every "PLACEHOLDER W" below
names what has to be found or decided there. The list, in the order of the forward pass:

    W1   the predictor tokens: one token per predictor, before they are grouped
    W2   the output sequence of stage 1 for the same transactions
    W3   the times of the rows
    W4   the mask of real rows, and which of its two values means "real"
    W5   the unit of the times: how many units make one second
    W6   the stack of history layers (stage 2)
    W7   what goes into that stack, and the mask it takes
    W8   how many positions in front of the rows are not transactions
    W9   the key padding mask of stage 2, when it is called with one
    W10  the four sizes: field width, width of stage 2, heads, number of history layers
    W11  the saved weights of the trained model
    W12  where the optimiser is built
    W13  the design: which layers get a re-read and how many earlier rows the memory holds
    W14  the number of predictors per transaction, and the dropout of the new blocks
    W15  OPTIONAL, for scoring only: the mark of the rows whose score is kept, when only some rows are
         scored (one window per scored transaction)

How to try it
-------------
    python interleaved_wiring_template.py                 # prints one line per design; every answer must be "yes"
    model.interleaved.rows_per_part = 1024                # scoring only: the lean memory (see interleaved_reread.py)
    model.interleaved.work_report(model.predictor_bank)   # scoring only: rows worked out by the latest call
    python -m pytest -q additions/tests/test_model_interleaved_wiring_template.py
"""
import copy

import torch
import torch.nn as nn
import torch.nn.functional as F

try:                                    # inside the package
    from additions.model.interleaved_reread import InterleavedReread, PredictorBank, start_from, train_only
except ImportError:                     # the two files side by side in one folder
    from interleaved_reread import InterleavedReread, PredictorBank, start_from, train_only

# PLACEHOLDER W10: the four sizes of the model in use. The stand-in uses the sizes the blocks were written
# for: a field width of 48 (the width of a stage-1 token), a stage 2 of width 144 (three summary tokens of
# 48 side by side), 8 heads and 4 history layers. They are read off the model in use: the width and the
# heads of its stage-1 and stage-2 layers and the number of layers of its stage 2.
FIELD_DIM = 48
HISTORY_WIDTH = 144
NUM_HEADS = 8
HISTORY_LAYERS = 4

# PLACEHOLDER W5: how many units of the batch's times make one second. The stand-in's batch carries
# nanoseconds. A batch that carries whole seconds has 1 here. The value must be the one the mask of
# stage 2 is built with.
TIME_UNITS_PER_SECOND = 1_000_000_000

# PLACEHOLDER W13: the design. Each entry is (layers that are followed by a re-read, earlier rows in memory).
# None means every history layer. A is the re-read after every layer on the row's own fields, M is one
# re-read after the last layer with a memory of the latest 5 earlier rows, AM is both.
DESIGNS = {
    "A": (None, 0),
    "M": ((HISTORY_LAYERS,), 5),
    "AM": (None, 5),
}

# PLACEHOLDER W14: the number of predictors per transaction, which is the number of field representations
# in the bank (`num_fields`), and the dropout of the new blocks (the dropout the model's own layers use).
N_PREDICTORS = 64

# Sizes of the stand-in only. The model in use has its own tokenizer, grouping and stage 1.
N_NUMERIC = 40             # how many of them are numbers; the rest are codes
CODE_SIZE = 12             # table size of every code predictor
N_PRIORITY = 4             # predictors that go into stage 1 as a token of their own
N_TAIL_GROUPS = 3          # the remaining predictors are averaged in this many groups
N_SUMMARY = 3              # summary tokens of stage 1
STAGE1_LAYERS = 2
HISTORY_LEN = 12           # the position table has HISTORY_LEN + 1 entries


def _stack(width, layers, dropout):
    """Standard pre-norm transformer layers with GELU, as both stages of the model use them."""
    layer = nn.TransformerEncoderLayer(d_model=width, nhead=NUM_HEADS, dim_feedforward=4 * width, dropout=dropout,
                                       activation="gelu", batch_first=True, norm_first=True)
    return nn.TransformerEncoder(layer, num_layers=layers, enable_nested_tensor=False)


class LastReread(nn.Module):
    """A stand-in for the re-read the model already has after stage 2: the row reads its field-level outputs once."""

    def __init__(self, dropout):
        super().__init__()
        self.norm_query, self.norm_fields = nn.LayerNorm(FIELD_DIM), nn.LayerNorm(FIELD_DIM)
        self.attend = nn.MultiheadAttention(FIELD_DIM, NUM_HEADS, dropout=dropout, batch_first=True)
        self.write_back = nn.Linear(HISTORY_WIDTH, HISTORY_WIDTH)

    def forward(self, history, fields):
        lead = history.shape[:-1]
        segments = history.reshape(-1, HISTORY_WIDTH // FIELD_DIM, FIELD_DIM)
        own = self.norm_fields(fields.reshape(-1, fields.shape[-2], FIELD_DIM))
        read, _ = self.attend(self.norm_query(segments), own, own, need_weights=False)
        return history + self.write_back((segments + read).reshape(*lead, HISTORY_WIDTH))


class StandInModel(nn.Module):
    """A small two-stage model with the layout of the model in use.

    design        None for the model as it is trained today; "A", "M" or "AM" for the grown model (DESIGNS)
    front_token   True puts one learned position in front of the rows of stage 2, as some models do for a
                  summary of the whole sequence; the rows then start at position 1
    dropout       one dropout for every part (0 makes training and scoring agree)

    forward(batch) takes a dict with
        continuous    float [B, T, N_NUMERIC]
        categorical   int64 [B, T, N_PREDICTORS - N_NUMERIC]
        mask          bool [B, T], True on real rows
        time_seq      int64 [B, T], in the unit of TIME_UNITS_PER_SECOND
        scored        OPTIONAL, bool [B, T], True on the rows whose score is wanted (PLACEHOLDER W15);
                      with the new blocks it turns on the scored path, and only those rows' logits
                      are then to be read
    and returns one pair of logits per row, [B, T, 2].
    """

    def __init__(self, design=None, front_token=False, dropout=0.0):
        super().__init__()
        d = FIELD_DIM
        # The tokenizer: one token per predictor.
        self.number_weight = nn.Parameter(torch.randn(N_NUMERIC, d) * 0.02)
        self.number_shift = nn.Parameter(torch.zeros(N_NUMERIC, d))
        self.code_tables = nn.ModuleList([nn.Embedding(CODE_SIZE, d) for _ in range(N_PREDICTORS - N_NUMERIC)])
        # Stage 1 on a short sequence: summary tokens, then the field-level inputs.
        self.summary = nn.Parameter(torch.randn(1, N_SUMMARY, d) * 0.02)
        self.stage1 = _stack(d, STAGE1_LAYERS, dropout)
        # Stage 2 on one vector per transaction.
        self.position = nn.Embedding(HISTORY_LEN + 1, HISTORY_WIDTH)
        self.front = nn.Parameter(torch.randn(1, 1, HISTORY_WIDTH) * 0.02) if front_token else None
        self.history_layers = _stack(HISTORY_WIDTH, HISTORY_LAYERS, dropout)
        self.last_reread = LastReread(dropout)
        self.head = nn.Linear(HISTORY_WIDTH, 2)

        # >>> EDIT 1 of 5: build the new blocks in the constructor.
        # The sizes are PLACEHOLDER W10 and W14, the time unit is PLACEHOLDER W5, the design is PLACEHOLDER W13.
        # `PredictorBank` is needed only when the bank is made from the predictor tokens (the usual case).
        self.interleaved, self.predictor_bank = None, None
        if design is not None:
            after_layers, num_back = DESIGNS[design]
            self.predictor_bank = PredictorBank(field_dim=FIELD_DIM, num_heads=NUM_HEADS, dropout=dropout)
            self.interleaved = InterleavedReread(width=HISTORY_WIDTH, history_layers=HISTORY_LAYERS,
                                                 after_layers=after_layers, field_dim=FIELD_DIM, num_heads=NUM_HEADS,
                                                 num_back=num_back, dropout=dropout,
                                                 units_per_second=TIME_UNITS_PER_SECOND, num_fields=N_PREDICTORS)
        # <<< end of EDIT 1

        # >>> EDIT 3b, first half (for the second check only): a switch and a place for its answer. Set to
        # True for one forward call, the model prints whether the block is wired the way the mask implies.
        self.look_at_wiring = False
        self.wiring_share = None
        # <<< end of EDIT 3b, first half

    def _tokens(self, continuous, categorical):
        """One token per predictor, [N, N_PREDICTORS, d]: numbers first, then codes."""
        numbers = continuous.unsqueeze(-1) * self.number_weight + self.number_shift
        codes = torch.stack([table(categorical[:, k]) for k, table in enumerate(self.code_tables)], dim=1)
        return torch.cat([numbers, codes], dim=1)

    def _grouped(self, tokens):
        """The field-level inputs of stage 1, [N, N_PRIORITY + N_TAIL_GROUPS, d].

        The first N_PRIORITY predictors keep a token each. The others are averaged in N_TAIL_GROUPS
        groups. After this step the single predictors of a group can no longer be told apart.
        """
        priority = tokens[:, :N_PRIORITY]
        tail = tokens[:, N_PRIORITY:].reshape(tokens.shape[0], N_TAIL_GROUPS, -1, FIELD_DIM).mean(dim=2)
        return torch.cat([priority, tail], dim=1)

    def forward(self, batch):
        continuous, categorical = batch["continuous"], batch["categorical"]
        # PLACEHOLDER W4: the mask of real rows. Here True means a real row. A model whose mask says True on
        # padding hands `~mask` to the new blocks.
        valid = batch["mask"].bool()
        # PLACEHOLDER W3: the times of the rows, [B, T], the tensor the mask of stage 2 is built from.
        times = batch["time_seq"]
        B, T = valid.shape
        d = FIELD_DIM

        tokens = self._tokens(continuous.reshape(B * T, -1), categorical.reshape(B * T, -1))     # [B * T, 64, d]

        # >>> EDIT 2 of 5: keep two tensors that already exist.
        # PLACEHOLDER W1: the predictor tokens as the tokenizer returns them, BEFORE they are grouped: one
        # token of width d per predictor. Brought to [B, T, P, d] here; P is 64.
        predictor_tokens = tokens.reshape(B, T, N_PREDICTORS, d)
        # <<< (the second tensor follows stage 1)

        grouped = self._grouped(tokens)                                                          # [B * T, 7, d]
        stage1_out = self.stage1(torch.cat([self.summary.expand(B * T, -1, -1), grouped], dim=1))  # [B * T, 10, d]
        vectors = stage1_out[:, :N_SUMMARY].reshape(B, T, HISTORY_WIDTH)        # the summary outputs, side by side
        field_outputs = stage1_out[:, N_SUMMARY:].reshape(B, T, -1, d)          # what the last re-read reads today

        # >>> EDIT 2 of 5, second tensor.
        # PLACEHOLDER W2: the whole output sequence of stage 1 for the same transactions (summary tokens and
        # field-level tokens, in any order), brought to [B, T, L, d]; L is 10 here.
        stage1_tokens = stage1_out.reshape(B, T, -1, d)
        # <<< end of EDIT 2

        # The strict time rule of stage 2: a row reads itself and real rows of strictly earlier seconds.
        secs = torch.div(times, TIME_UNITS_PER_SECOND, rounding_mode="floor")
        earlier = (secs.unsqueeze(1) < secs.unsqueeze(2)) & valid.unsqueeze(1) & valid.unsqueeze(2)
        allowed = earlier | torch.eye(T, dtype=torch.bool, device=valid.device)
        x = vectors.masked_fill(~valid.unsqueeze(-1), 0.0) + self.position(earlier.sum(-1).clamp(max=HISTORY_LEN))
        # PLACEHOLDER W8: positions in front of the rows that are not transactions. The stand-in has 1 with
        # `front_token` and 0 without. The front position reads only itself, and every row may read it.
        n_prefix = 0
        if self.front is not None:
            n_prefix = 1
            x = torch.cat([self.front.expand(B, -1, -1), x], dim=1)
            wider = torch.zeros(B, T + 1, T + 1, dtype=torch.bool, device=valid.device)
            wider[:, 1:, 1:], wider[:, 1:, 0], wider[:, 0, 0] = allowed, True, True
            allowed = wider
        # PLACEHOLDER W7: what goes into the history layers (`x`) and the mask they take (`mask`): zero where
        # reading is allowed, minus infinity where it is not, one copy per head.
        mask = torch.zeros(allowed.shape, device=x.device).masked_fill(~allowed, float("-inf"))
        mask = mask.repeat_interleave(NUM_HEADS, dim=0)

        if self.interleaved is None:
            # The model as it is today. PLACEHOLDER W6: the stack of history layers and the one call that runs it.
            history = self.history_layers(x, mask=mask)
        else:
            # >>> EDIT 3 of 5: the bank and the memory, once per batch.
            # PLACEHOLDER W15 (OPTIONAL, for scoring only): the mark of the scored rows, bool [B, T], True on
            # the rows whose score is kept (the last real row of every window when one window is scored per
            # transaction). The stand-in takes it from batch["scored"] when the batch has that entry.
            # The name of the entry is the one handed to the fifth check as `key` ("scored" by default).
            scored = batch.get("scored")
            if scored is None:
                bank = self.predictor_bank(predictor_tokens, stage1_tokens)                      # [B, T, 64, d]
                memory = self.interleaved.prepare(bank, times, valid)
            else:
                # >>> OPTIONAL, for scoring only: the scored path. In training mode the block leaves the mark
                # unused and prints one line, so training takes the full path; check 4 drops the entry.
                # The bank is worked out only for the rows whose bank is read, and the last re-read only for
                # the scored rows; the scores of the scored rows are those of the lines above. Every other
                # row may hold anything after stage 2 and its score is not to be read.
                rows = self.interleaved.rows_read(times, valid, scored)
                bank = self.predictor_bank(predictor_tokens, stage1_tokens, rows=rows)
                memory = self.interleaved.prepare(bank, times, valid, scored=scored)
                # <<< end of the OPTIONAL lines
            # <<< end of EDIT 3

            # >>> EDIT 3b, second half (for the second check only): one look at the wiring. It is handed
            # exactly what stage 2 and the block are handed: the mask (W7), the times (W3), the mask of real
            # rows (W4), the memory, the count of front positions (W8), and the key padding mask (W9) when
            # stage 2 is called with one. It does nothing while the switch is off.
            if self.look_at_wiring:
                self.wiring_share = self.interleaved.look_at_wiring(mask, times, valid, memory, n_prefix=n_prefix)
            # <<< end of EDIT 3b

            # >>> EDIT 4 of 5: the one call that runs the history layers is replaced by this one.
            # PLACEHOLDER W9: a stage 2 that is called with a `src_key_padding_mask` hands the same mask to
            # `run` as `key_padding=...`; the stand-in has none.
            history = self.interleaved.run(self.history_layers, x, mask, memory, n_prefix=n_prefix)
            # <<< end of EDIT 4

        # >>> EDIT 5 of 5: nothing after stage 2 changes. The re-read the model already has and the head
        # stay exactly as they are.
        history = history[:, n_prefix:]
        history = self.last_reread(history, field_outputs)
        return self.head(history)


# ----------------------------------------------------------------------------------------------
# growing a trained model
# ----------------------------------------------------------------------------------------------

def grow(trained, design, front_token=False):
    """The stand-in with the new blocks of `design`, carrying the weights of `trained`.

    In the model in use this is three lines:
        model = TheModel(..., with the new blocks switched on)
        start_from(model, saved["state_dict"])         # PLACEHOLDER W11: the saved weights of the trained model
        train_only(model, [model.interleaved, model.predictor_bank])
    A checkpoint file is read with torch.load; its weights are usually under the entry "state_dict".
    """
    model = StandInModel(design=design, front_token=front_token)
    start_from(model, trained.state_dict())
    return model


def new_parts(model):
    """The modules that are trained in the first run: the re-reads with their memory, and the bank."""
    return [model.interleaved, model.predictor_bank]


# ----------------------------------------------------------------------------------------------
# four checks; each takes a model and a batch, so they run on the model in use as they are
# ----------------------------------------------------------------------------------------------

def _scores(model, batch):
    """Scoring-mode logits."""
    model.eval()
    with torch.no_grad():
        return model(batch)


def equal_scores(trained, grown, batch, real="mask"):
    """Check 1: before any training the grown model must score as the trained model does.

    real   the batch entry that is True on real rows (PLACEHOLDER W4). A batch that marks padding
           gets such an entry first, for example batch["valid"] = ~batch["pad"]; an entry that is
           True on padding must never be passed here, or the check compares padding only.

    Returns the largest difference between the two models' logits on real rows. It must be zero up
    to rounding (below 1e-5). A larger value says an edit changed something besides adding the blocks.
    """
    rows = batch[real].bool()
    return float((_scores(trained, batch)[rows] - _scores(grown, batch)[rows]).abs().max())


def wiring_agrees(grown, batch):
    """Check 2: the block must be wired the way the mask of stage 2 implies.

    Returns the share from `InterleavedReread.look_at_wiring`; it must be 1.0. It is below 1.0 for a
    time unit that is not the mask's, a count of front positions that is not the model's, a mask of
    real rows that is True on padding, and a memory that was built without the times or without the
    mask of real rows. None of these shows in the scores of a freshly grown model, because fresh
    blocks change no score. The model needs EDIT 3b for this check.
    """
    grown.wiring_share = None
    grown.look_at_wiring = True
    try:
        _scores(grown, batch)
    finally:
        grown.look_at_wiring = False
    return grown.wiring_share


def later_rows_change_nothing(grown, batch, alter, real="mask", time="time_seq"):
    """Check 3: the time rule at the scores, with the new blocks switched on.

    grown   the grown model; a copy of it gets write-back weights that are no longer zero, as after
            some training, so that a leak through the new blocks would show
    alter   a function (batch, rows) -> batch that returns a copy of the batch in which the feature
            inputs of the slots in `rows` (bool [B, T]) are replaced by other values. The times, the
            mask of real rows and the labels stay as they are.
    real    the batch entry that is True on real rows (PLACEHOLDER W4), as in `equal_scores`
    time    the batch entry that holds the times (PLACEHOLDER W3)

    Returns (largest change of a row at or before the cut, largest change of a later row). The first
    must be zero up to rounding; the second must not be, or the check could not see a leak. When
    one side of the cut holds no real row the check cannot run: it prints why and returns
    (not a number, 0.0).
    """
    model = copy.deepcopy(grown)
    torch.manual_seed(1)
    with torch.no_grad():
        for reread in model.interleaved.rereads.values():
            reread.write_back.weight.normal_(std=0.2)
    valid, times = batch[real].bool(), batch[time]
    middle = valid.sum(dim=1) // 2
    cut = times[torch.arange(times.shape[0]), middle].unsqueeze(1)
    units = model.interleaved.memory.units_per_second or 1
    cut_second = torch.div(cut, units, rounding_mode="floor")
    second = torch.div(times, units, rounding_mode="floor")
    later, kept = valid & (second > cut_second), valid & (second <= cut_second)
    if not later.any() or not kept.any():
        print("later_rows_change_nothing: no real row on one side of the cut; check the time unit of the block "
              "and that `real` is True on real rows")
        return float("nan"), 0.0
    before, after = _scores(model, batch), _scores(model, alter(batch, later))
    return float((before[kept] - after[kept]).abs().max()), float((before[later] - after[later]).abs().max())


def only_new_weights_move(grown, batch, loss, steps=3, lr=1e-3, key="scored"):
    """Check 4: with `train_only`, a few training steps move the new blocks and nothing else.

    loss   a function (model, batch) -> scalar: the training loss of the model in use
    key    the batch entry that carries the mark of scored rows (PLACEHOLDER W15), when the batch has
           one; it is left out of the batch trained on here, since training takes the full path

    Returns (names that moved outside the new parts, number of weight tensors that got a gradient
    in the first step). The first must be empty. The second must be above zero: zero means the
    new blocks get no learning signal at all, which is what a mask of real rows of the wrong
    polarity leads to. A fresh block gives one per re-read (1 for design M, 4 for A and AM with
    four history layers): only the zero-start write-back layer of each re-read gets a gradient
    in the first step, because the layers before it are reached only through its zero weights.
    When the loss reaches no trainable weight at all (no re-read ran), one printed line says so
    and the count is zero.

    PLACEHOLDER W12: in the model in use the optimiser is built in the model's own method. It can stay
    as it is: weights that `train_only` switched off get no gradient, and an optimiser leaves a
    weight without a gradient where it is. A learning rate of 1e-3 for the new parts is a starting
    value.
    """
    # The mark of scored rows is for scoring; the training batch here is the batch without it.
    batch = {name: value for name, value in batch.items() if name != key}
    model = copy.deepcopy(grown)
    chosen = train_only(model, new_parts(model))
    inside = {id(w) for w in chosen}
    before = {name: w.detach().clone() for name, w in model.named_parameters()}
    # No weight decay here, so that a weight moves only when it got a gradient.
    optimiser = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.0)
    model.train()
    reached = 0
    for step in range(steps):
        optimiser.zero_grad()
        value = loss(model, batch)
        if not value.requires_grad:
            # No trainable weight reaches the loss: no re-read ran (a re-read listed after a layer the model
            # does not have, for one). The count stays zero, which fails the check, and the reason is printed.
            print("only_new_weights_move: the loss reaches no trainable weight; no re-read ran. Check that "
                  "history_layers and after_layers name layers the model has")
            break
        value.backward()
        if step == 0:
            reached = sum(1 for w in chosen if w.grad is not None and float(w.grad.abs().sum()) > 0)
        optimiser.step()
    outside = [name for name, w in model.named_parameters()
               if id(w) not in inside and not torch.equal(w, before[name])]
    return outside, reached


def last_real_rows(valid):
    """The mark of the last real row of every sequence, bool [B, T]: one scored row per window."""
    valid = valid.bool()
    last = torch.zeros_like(valid)
    # The slot of the last real row is the largest slot that is real; a sequence without one gets none.
    slots = torch.arange(valid.shape[1], device=valid.device).expand_as(valid).masked_fill(~valid, -1)
    top = slots.max(dim=1).values
    has = top >= 0
    last[torch.nonzero(has).squeeze(1), top[has]] = True
    return last


def scored_rows_agree(grown, batch, scored, real="mask", key="scored"):
    """Check 5 (OPTIONAL, for a model that takes the scored path): it gives the scores of the full path.

    grown    the grown model; a copy of it gets write-back weights that are no longer zero, as after
             some training, since with fresh blocks the two paths would agree whatever they did
    scored   bool [B, T], True on the rows whose score is kept (PLACEHOLDER W15)
    real     the batch entry that is True on real rows (PLACEHOLDER W4), as in `equal_scores`
    key      the batch entry under which the model reads the mark of scored rows (PLACEHOLDER W15);
             the marked pass puts `scored` there. The model must read its mark from that entry.

    Returns the largest difference between the logits of the scored path and those of the full
    path on the scored real rows. It must be zero up to rounding (below 1e-5). A larger value says
    that the scored path reads something it should not, or that the mark of the scored rows does
    not have the layout of the rows ([B, T], without any position in front). The rows that are
    not scored are not compared: on the scored path they may hold anything.

    Equal scores alone would also come from a marked pass that did the work of the full pass (a
    model that reads its mark under another name, a `history_layers` that is not the model's own
    number of layers, a `prepare` called without `scored`). So when not every real row is scored
    and the last re-read of the marked pass still worked out every real row (or no re-read ran),
    one printed line says that the model did not take the scored path, and the answer is
    infinity. The check does not see a bank called without `rows=`: the scores stay right and only
    the time is lost; `work_report(model.predictor_bank)` shows it. It assumes that checks 2 and 4
    pass: a mask of real rows of the wrong polarity, for one, is not seen here.
    """
    model = copy.deepcopy(grown)
    torch.manual_seed(1)
    with torch.no_grad():
        for reread in model.interleaved.rereads.values():
            reread.write_back.weight.normal_(std=0.2)
    valid = batch[real].bool()
    rows = scored.bool() & valid
    if not rows.any():
        print("scored_rows_agree: no scored row is a real row; nothing to compare")
        return float("nan")
    full = _scores(model, batch)
    marked = dict(batch)
    marked[key] = scored
    answer = float((full[rows] - _scores(model, marked)[rows]).abs().max())
    # The work of the marked pass: the re-reads that ran in it, the last of them by layer number.
    done = model.interleaved.work_report()["rereads"]
    n_real = int(valid.sum())
    if int(rows.sum()) < n_real and (not done or done[max(done)]["rows"] >= n_real):
        print(f"scored_rows_agree: the model did not take the scored path: the last re-read worked out "
              f"{done[max(done)]['rows'] if done else 0} rows for {int(rows.sum())} scored of {n_real} real rows; "
              f"check that the model reads the mark from batch[{key!r}], that prepare is given scored=, and "
              f"that history_layers is the model's own number of history layers")
        return float("inf")
    return answer


# ----------------------------------------------------------------------------------------------
# made-up rows and the run of everything
# ----------------------------------------------------------------------------------------------

def make_batch(seed=0, sequences=6, width=14):
    """A padded batch of made-up rows: several rows per second, times in nanoseconds, padding at the end."""
    g = torch.Generator().manual_seed(seed)
    lengths = torch.randint(width // 2, width + 1, (sequences,), generator=g)
    valid = torch.arange(width).unsqueeze(0) < lengths.unsqueeze(1)
    # Gaps of 0 to 3 seconds: a gap of 0 puts a row in the second of the row before it.
    seconds = torch.cumsum(torch.randint(0, 4, (sequences, width), generator=g), dim=1) + 1_700_000_000
    # Rows of one second differ inside the second, so a wrong time unit would put them in an order.
    times = seconds * TIME_UNITS_PER_SECOND + torch.randint(0, 1000, (sequences, width), generator=g)
    times = times.masked_fill(~valid, 0)
    batch = {
        "continuous": torch.randn(sequences, width, N_NUMERIC, generator=g),
        "categorical": torch.randint(0, CODE_SIZE, (sequences, width, N_PREDICTORS - N_NUMERIC), generator=g),
        "mask": valid,
        "time_seq": times,
    }
    # A label that depends on single predictors, so the made-up task has something to learn.
    signal = batch["continuous"][..., 7] + batch["continuous"][..., 21] * (batch["categorical"][..., 3] > 5)
    batch["target_seq"] = torch.where(valid, (signal > 0.8).long(), torch.full_like(lengths.unsqueeze(1), -100))
    return batch


def alter_rows(batch, rows, seed=3):
    """A copy of the made-up batch with every per-row input of the slots in `rows` replaced."""
    g = torch.Generator().manual_seed(seed)
    out = {k: v.clone() for k, v in batch.items()}
    n = int(rows.sum())
    out["continuous"][rows] = torch.randn(n, N_NUMERIC, generator=g) * 3
    out["categorical"][rows] = torch.randint(0, CODE_SIZE, (n, N_PREDICTORS - N_NUMERIC), generator=g)
    return out


def row_loss(model, batch):
    """Cross-entropy over the real rows, one prediction per row."""
    valid = batch["mask"]
    return F.cross_entropy(model(batch)[valid], batch["target_seq"][valid])


def main(steps=30, front_token=False, quiet=False):
    """Train the stand-in briefly, grow it with every design, run the five checks and print one line per design.

    Returns {design: {"new_weights", "equal", "wiring", "kept", "later", "outside", "inside", "scored"}};
    "inside" is the number of weight tensors of the new parts that got a gradient (one per re-read
    for a fresh block), and "scored" is the result of the fifth check with the last real row of
    every window scored.
    """
    torch.manual_seed(0)
    batch = make_batch()
    trained = StandInModel(front_token=front_token)
    optimiser = torch.optim.AdamW(trained.parameters(), lr=3e-3)
    trained.train()
    for _ in range(steps):
        optimiser.zero_grad()
        row_loss(trained, batch).backward()
        optimiser.step()
    say = (lambda *a: None) if quiet else print
    say(f"trained stand-in: {sum(w.numel() for w in trained.parameters()):,} weights, front token: {front_token}")
    results = {}
    for design in DESIGNS:
        torch.manual_seed(5)
        grown = grow(trained, design, front_token=front_token)
        new = sum(w.numel() for part in new_parts(grown) for w in part.parameters())
        kept, later = later_rows_change_nothing(grown, batch, alter_rows)
        outside, inside = only_new_weights_move(grown, batch, row_loss)
        results[design] = {"new_weights": new, "equal": equal_scores(trained, grown, batch),
                           "wiring": wiring_agrees(grown, batch), "kept": kept, "later": later,
                           "outside": outside, "inside": inside,
                           # The fifth check scores one row per window, the last real one, as scoring does.
                           "scored": scored_rows_agree(grown, batch, last_real_rows(batch["mask"]))}
        r = results[design]
        yes = lambda ok: "yes" if ok else "NO"
        say(f"design {design:2s}: {new:,} new weights | scores equal before training: {yes(r['equal'] < 1e-5)} "
            f"| memory and mask agree: {yes(r['wiring'] == 1.0)} | earlier rows untouched by later rows: "
            f"{yes(r['kept'] < 1e-4 and r['later'] > 1e-4)} | only the new weights move: "
            f"{yes(not r['outside'] and r['inside'] > 0)} | scored path agrees: {yes(r['scored'] < 1e-5)}")
    return results


if __name__ == "__main__":
    main()
    main(front_token=True)
