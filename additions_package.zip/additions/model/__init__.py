"""Blocks for the network itself, and a compact reference model that wires them together.

aligned_outcomes.py             later rows read what the bank decided on an earlier row; no row
                                reads its own decision
attention_bias.py               a learned bias on stage-2 attention: same value, time gap, how often
history_stage.py                stage 2 at its own width, under the strict time rule
interleaved_reread.py           a field re-read after every history layer, and a short memory of
                                recent field representations
interleaved_wiring_template.py  a stand-in two-stage model with the gated field re-reads wired in,
                                and the checks that say a wiring is right
masks.py                        who may read whom: the strict time rule as an attention mask
members.py                      several members inside one model: shared stage 2, own scaling
                                vector, own head
merchant_context.py             what other accounts just did at the row's merchant, pooled into one
                                vector for the head
profile_encoder.py              a small encoder for slow account fields, run once per sequence
reference_model.py              a compact two-stage model that wires every block of this folder
                                together
reread_block.py                 after history, a row reads its own fields once more
state_prefix.py                 a stored account memory as extra positions in front of the history
summary_tokens.py               stage 1 with several summary tokens per transaction
_shared.py                      small helpers shared by the model blocks of this folder
"""
