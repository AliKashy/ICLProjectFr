"""After history, a row reads its own fields once more.

What this file does
-------------------
`RereadBlock` sits between stage 2 and the head. For every row it cuts the history-aware
vector into segments as wide as a field token, lets those segments query the row's own
field tokens (as they came out of stage 1) through one cross-attention block, and adds the
result back to the history-aware vector. The layer that writes the result back starts at
zero, so a freshly added block changes nothing until training moves it.

Why it exists
-------------
In the two-stage design a row's fields are squeezed into one vector before the model has
seen the account. Stage 1 must decide what to keep without knowing what will matter. Yet
what matters depends on the account: a failed address check says little on an account that
always shops online and fails it, and a great deal on an account that never did; a
card-not-present row is routine for one customer and a first for another. After stage 2
the model knows the account's habits, but by then the detail of the row is gone.

The re-read gives history the last word. The history-aware vector asks the row's fields a
question that it could only form after reading the account, and the answer goes straight
to the head. This matters most inside a fraud run, where the rows of the run look ordinary
one by one and stand out only against the account's own past. Only the row's own fields
and its own history vector are involved, so nothing new can leak: the row reads no other
row here. A downstream tree model gains a second vector per row, the one after the
re-read, which is the most specific to the scored transaction.

Where it goes
-------------
Stage 1 (field-token outputs kept), stage 2, then this block, then the head. In the
original code it would sit in `FTTransformerHierModel.forward` between the `seq_encoder`
call and `self.head`, and stage 1 would have to keep `token_encoder`'s outputs for the
field tokens instead of only the summary position (summary_tokens.py returns them with
`return_fields=True`).

What to change for the pod
--------------------------
`settings.EMBED_DIM` (width of a field token) and `settings.NUM_HEADS`. The width of the
history vector is an argument. When it is not a multiple of the field-token width, a learned
projection makes the segments, and `num_segments` says how many. An export has to say which
vector it carries: the one before the re-read or the one after it.

How to try it
-------------
    reread = RereadBlock(width=144)                       # three segments of 48
    final = reread(history, fields)                       # history [B, T, 144], fields [B, T, F, 48] -> [B, T, 144]
    python -m pytest -q additions/tests/test_model_reread_block.py
"""
import torch.nn as nn

from additions.model._shared import pick


class RereadBlock(nn.Module):
    """One cross-attention block from a row's history-aware vector to that row's own field tokens.

    width          width W of the history-aware vector (the width of stage 2)
    field_dim      width d of a field token; None reads settings.EMBED_DIM
    num_segments   number S of queries the vector is cut into; None means W / d, rounded up when W is not
                   a multiple of d
    num_heads      attention heads; None reads settings.NUM_HEADS
    ff_multiplier  the feed-forward layer is this many times as wide as a segment
    dropout        dropout on the attention weights and on the two residual branches
    """

    def __init__(self, width, field_dim=None, num_segments=None, num_heads=None, ff_multiplier=4, dropout=0.1):
        super().__init__()
        d = self.field_dim = pick(field_dim, "EMBED_DIM")
        # By default the vector is cut into as many segments as fit; a width of 144 gives three of 48.
        s = self.num_segments = -(-width // d) if num_segments is None else int(num_segments)
        # When the vector already is S segments side by side it is only cut. Otherwise a learned
        # projection makes S segments out of it.
        self.to_segments = nn.Identity() if width == s * d else nn.Linear(width, s * d)
        self.norm_query = nn.LayerNorm(d)
        self.norm_fields = nn.LayerNorm(d)
        self.attend = nn.MultiheadAttention(d, pick(num_heads, "NUM_HEADS"), dropout=dropout, batch_first=True)
        self.norm_ff = nn.LayerNorm(d)
        self.feed_forward = nn.Sequential(nn.Linear(d, d * ff_multiplier), nn.GELU(), nn.Dropout(dropout),
                                          nn.Linear(d * ff_multiplier, d))
        self.drop = nn.Dropout(dropout)
        # The layer that writes the result back starts at zero. The block is then exactly a no-op when it
        # is added to a trained model, and the model's scores do not jump. Its weights still receive a
        # gradient from the first step on (the gradient of a weight is its input times the error signal,
        # and the input is not zero), so the block leaves the no-op state as soon as that helps the loss.
        self.write_back = nn.Linear(s * d, width)
        nn.init.zeros_(self.write_back.weight)
        nn.init.zeros_(self.write_back.bias)

    def forward(self, history, fields):
        """Add to every row's history-aware vector what it reads from its own fields.

        history   float [..., W]: one history-aware vector per row; the leading dimensions are free,
                  usually [B, T]
        fields    float [..., F, d]: the row's own field tokens after stage 1, same leading dimensions

        Returns float [..., W].

        A row reads only its own F field tokens. No row reads another row, so the strict time
        rule is untouched and a padded slot needs no mask.
        """
        lead = history.shape[:-1]
        n_fields, d = fields.shape[-2:]
        s = self.num_segments
        segments = self.to_segments(history).reshape(-1, s, d)                    # [N, S, d]: the queries
        own_fields = self.norm_fields(fields.reshape(-1, n_fields, d))            # [N, F, d]: keys and values
        # Each segment asks its own question of the row's fields. Segments are cut, not averaged: the
        # parts of the history vector can each look for something else.
        read, _ = self.attend(self.norm_query(segments), own_fields, own_fields, need_weights=False)
        segments = segments + self.drop(read)
        segments = segments + self.drop(self.feed_forward(self.norm_ff(segments)))
        # Join the segments again and add the result to the vector that came in. With the zero start of
        # `write_back` this line returns `history` itself at first.
        return history + self.write_back(segments.reshape(*lead, s * d))
