"""A compact two-stage model that wires every block of this folder together.

What this file does
-------------------
`TwoStageReference` is a complete, small two-stage fraud model with one switch per block of
`additions/model/`. It holds:

    FieldTokenizer          a plain tokenizer: one token per numeric input (value times a learned
                            vector plus a learned vector) and one embedding per code input
    stage 1                 summary_tokens.SummaryTokenEncoder (K summary tokens, K = 1 by default)
    profile positions       profile_encoder.ProfileEncoder            (switch: profile_numeric > 0)
    state positions         state_prefix.StatePrefix                  (switch: state_vector_dim > 0)
    attention bias          attention_bias.AttentionBias              (switch: bias_fields > 0)
    stage 2                 history_stage.HistoryStage at its own width (switch: stage2_width)
    outcome layer           aligned_outcomes.AlignedOutcomeLayer as the first stage-2 layer
                                                                      (switch: aligned_outcomes)
    re-read                 reread_block.RereadBlock                  (switch: reread)
    re-read after layers    interleaved_reread.InterleavedReread      (switch: interleaved_reread)
    recent field memory     interleaved_reread.RecentFieldMemory      (switch: memory_back > 0)
    merchant context        merchant_context.MerchantContext          (switch: context_vector_dim > 0)
    members and heads       members.Members                           (switch: num_members > 1)

`forward(batch)` returns one pair of logits per row, [B, T, 2]. `loss(batch)` returns the
training loss of the original model (or the per-member loss when there are members).
`extra_inputs` builds, from a table of made-up rows, every per-row and per-sequence input
that the optional blocks read, and `main` trains the model for a few steps on such rows.

With every switch off the model is the original design: one summary token, one width for
both stages, the strict time mask, position by the count of strictly earlier rows, one
linear head. The original model also puts a sequence summary token in front of stage 2. In
the all-position layout no row reads that token, so it changes no row's logits and is left
out here; a test rebuilds the original arithmetic with that token and shows the rows agree.

Why it exists
-------------
Each block of this folder is tested by itself. What a block test cannot show is that the
blocks still keep the time rule once they are joined: that a prefix added in front does not
shift what an outcome layer closes, that members repeat the bias and the outcome codes in
the same order as the vectors, that a re-read after members reads the field tokens of the
right row. A row may read only rows of strictly earlier seconds of its account. Frauds come
in runs on one account, so most frauds follow an earlier fraud of that account, and a model
that leaks even one later row of a run learns to read the run instead of detecting it. The
tests of this file therefore run the whole model and check the rule at the logits, with
every switch off, with each switch alone, and with all of them on.

The model also shows the wiring in one readable place. A team that adds one block to its
own model can copy the few lines that block needs from `forward`.

Where it goes
-------------
This is a model of its own, not a part of the pipeline. Its `forward` follows
`FTTransformerHierModel.forward` of the original code step by step (tokenizer, stage 1,
stage 2, head), and `loss` follows `FTTransformerHierModel._step` in the all-position mode.
The tokenizer stands in for `FeatureTokenizer`. Each block's own file says where in the
original code that block would sit.

What to change for the pod
--------------------------
`settings.EMBED_DIM`, `NUM_HEADS`, `STAGE1_BLOCKS`, `STAGE2_BLOCKS` and `HISTORY_LEN` are the
default sizes. The number of continuous and code inputs comes from the batch builder (129
input fields means 129 tokens per transaction, plus the time gap). The batch keys of the
optional inputs are listed in `TwoStageReference.forward`; a builder that delivers them
under other names needs them renamed there. `DEMO_VECTOR_DIM` and `DEMO_PROFILE_COLS` below
only serve the demo. The batch builder of the demo (`_shared.sequences_from_table`) is a
stand-in for the real one.

How to try it
-------------
    batch, row_index, cards = sequences_from_table(df)
    extra, sizes = extra_inputs(df, batch, row_index)
    model = TwoStageReference(batch["continuous"].shape[-1], cards, reread=True, **sizes)
    logits = model({**batch, **extra})                                  # [B, T, 2]
    python additions/model/reference_model.py --all --steps 20
    python -m pytest -q additions/tests/test_model_reference_model.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from additions import settings
from additions.common import synthetic, timekeys
from additions.model import masks
from additions.model._shared import layout, pick, sequences_from_table
from additions.model.aligned_outcomes import AlignedOutcomeLayer, outcome_codes
from additions.model.attention_bias import AttentionBias, match_values
from additions.model.history_stage import HistoryStage
from additions.model.interleaved_reread import InterleavedReread, PredictorBank
from additions.model.members import Members, member_loss
from additions.model.merchant_context import MerchantContext, context_index, gather_context
from additions.model.profile_encoder import ProfileEncoder, days_before, first_row_values
from additions.model.reread_block import RereadBlock
from additions.model.state_prefix import StatePrefix, account_state
from additions.model.summary_tokens import SummaryTokenEncoder

# PLACEHOLDER: width of the stored per-row vectors that the demo makes up for the state and merchant blocks;
# in a real run it is the width of the vectors exported from a frozen first model.
DEMO_VECTOR_DIM = 8

# PLACEHOLDER: the slow account date columns the demo turns into profile fields (made up by
# synthetic.add_profile_dates); in a real run, the profile columns that pass additions/features/asof_audit.py.
DEMO_PROFILE_COLS = ("profile_asof_dt", "profile_static_dt")


class FieldTokenizer(nn.Module):
    """One token per input field, as the original FeatureTokenizer does in its linear mode.

    continuous_dim   number C of numeric inputs (the time gap included)
    cardinalities    table size of each of the K code inputs
    embed_dim        width d of a token

    forward(continuous [..., C], categorical [..., K]) returns float [..., C + K, d].
    """

    def __init__(self, continuous_dim, cardinalities, embed_dim):
        super().__init__()
        self.weight = nn.Parameter(torch.empty(continuous_dim, embed_dim))
        self.shift = nn.Parameter(torch.zeros(continuous_dim, embed_dim))
        nn.init.normal_(self.weight, std=0.02)
        self.tables = nn.ModuleList([nn.Embedding(int(size), embed_dim) for size in cardinalities])

    def forward(self, continuous, categorical):
        """Tokens of every transaction; the leading dimensions are free (usually [B, T])."""
        tokens = [continuous.unsqueeze(-1) * self.weight + self.shift]                    # [..., C, d]
        if len(self.tables):
            tokens.append(torch.stack([table(categorical[..., k]) for k, table in enumerate(self.tables)], dim=-2))
        return torch.cat(tokens, dim=-2)


class TwoStageReference(nn.Module):
    """A two-stage model with one switch per block; every switch off is the original design.

    continuous_dim, cardinalities   inputs as delivered by the batch builder
    embed_dim, num_heads            token width and attention heads; None reads settings
    stage1_blocks, stage2_blocks    depth of the two stages; None reads settings
    history_len                     size of the position table minus one; None reads settings.HISTORY_LEN
    num_summary                     summary tokens of stage 1 (1 is the original design)
    stage2_width                    width of stage 2; None keeps the width of the transaction vector
    reread                          add the re-read block after stage 2
    interleaved_reread              add a gated re-read of the row's fields after every stage-2 block
    memory_back                     how many latest earlier transactions those re-reads also see; above 0
                                    without `interleaved_reread` it adds one gated re-read with that memory
                                    after the last stage-2 block
    field_bank                      what the gated re-reads query: "stage1" for the field outputs of
                                    stage 1, "predictor" for one vector per input made by PredictorBank
                                    from the tokenizer's tokens and the summary outputs
    aligned_outcomes                make the first stage-2 layer the outcome layer
    bias_fields                     number of match fields of the attention bias; 0 switches it off
    profile_numeric                 number of numeric profile fields; 0 switches the profile positions off
    state_vector_dim, num_states    width of the stored vectors and number of half-lives of the stored
                                    account state; 0 switches the state positions off
    context_vector_dim              width of the stored vectors of the merchant context; 0 switches it off
    num_members                     members sharing stage 2; 1 is a single plain head
    dropout                         one dropout for every block (0 makes training and scoring agree)
    units_per_second                unit of `time_seq`; None reads masks.TIME_UNITS_PER_SECOND
    """

    def __init__(self, continuous_dim, cardinalities, embed_dim=None, num_heads=None, stage1_blocks=None,
                 stage2_blocks=None, history_len=None, num_summary=1, stage2_width=None, reread=False,
                 aligned_outcomes=False, bias_fields=0, profile_numeric=0, state_vector_dim=0, num_states=None,
                 context_vector_dim=0, num_members=1, dropout=0.1, units_per_second=None,
                 interleaved_reread=False, memory_back=0, field_bank="stage1"):
        super().__init__()
        d = pick(embed_dim, "EMBED_DIM")
        heads = pick(num_heads, "NUM_HEADS")
        self._noted = set()
        self.tokenizer = FieldTokenizer(continuous_dim, cardinalities, d)
        self.stage1 = SummaryTokenEncoder(embed_dim=d, num_summary=num_summary, num_heads=heads,
                                          num_blocks=stage1_blocks, dropout=dropout, attn_dropout=dropout)
        vector_dim = self.stage1.out_dim                          # K * d: what stage 1 hands to stage 2
        width = vector_dim if stage2_width is None else int(stage2_width)

        # Blocks that are switched off are None, so the names of the shared parts (tokenizer, stage1, stage2,
        # head) are the same whatever is switched on. A model with a zero-initialised block switched on can
        # therefore load the weights of a model without it, which is how a block is added to a trained model.
        self.profile_encoder = (ProfileEncoder(profile_numeric, (), out_dim=width, dropout=dropout)
                                if profile_numeric else None)
        self.state_prefix = (StatePrefix(vector_dim=state_vector_dim, out_dim=width, num_states=num_states)
                             if state_vector_dim else None)
        self.attention_bias = (AttentionBias(bias_fields, num_heads=heads, units_per_second=units_per_second)
                               if bias_fields else None)
        first_layer = (AlignedOutcomeLayer(width=width, num_heads=heads, dropout=dropout, attn_dropout=dropout)
                       if aligned_outcomes else None)
        self.stage2 = HistoryStage(in_dim=vector_dim, width=width, num_heads=heads, num_blocks=stage2_blocks,
                                   history_len=history_len, first_layer=first_layer,
                                   units_per_second=units_per_second, dropout=dropout, attn_dropout=dropout)
        self.reread_block = (RereadBlock(width, field_dim=d, num_heads=heads, dropout=dropout) if reread else None)
        # The gated re-reads between the stage-2 blocks. They take the time unit of stage 2, so that the
        # memory gathers earlier rows by the very rule the mask of stage 2 is built with.
        self.interleaved, self.predictor_bank = None, None
        if interleaved_reread or memory_back:
            n_blocks = pick(stage2_blocks, "STAGE2_BLOCKS")
            units = masks.TIME_UNITS_PER_SECOND if units_per_second is None else units_per_second
            self.interleaved = InterleavedReread(width, history_layers=n_blocks,
                                                 after_layers=None if interleaved_reread else (n_blocks,),
                                                 field_dim=d, num_heads=heads, num_back=int(memory_back),
                                                 dropout=dropout, units_per_second=units,
                                                 num_fields=continuous_dim + len(cardinalities))
            if field_bank == "predictor":
                self.predictor_bank = PredictorBank(field_dim=d, num_heads=heads, dropout=dropout)
        self.merchant_context = (MerchantContext(context_vector_dim, context_dim=d, num_heads=heads, dropout=dropout)
                                 if context_vector_dim else None)
        # The head reads the history-aware vector, with the merchant context joined to it when there is one.
        head_dim = width + (d if self.merchant_context is not None else 0)
        self.members = Members(vector_dim, head_dim, num_members=num_members) if num_members > 1 else None
        self.head = nn.Linear(head_dim, 2) if self.members is None else None

    def _note(self, message):
        """Print a plain line once per model, so that a missing optional input is said once and not every batch."""
        if message not in self._noted:
            self._noted.add(message)
            print(f"note: {message}")

    def _prefix(self, batch):
        """The positions put in front of the rows: profile first, then the stored state. None when there are none.

        Both kinds hold content that is older than every row of the sequence (the profile of the first row,
        the state from strictly before the first row), which is what makes it lawful for every row to read them.
        """
        parts = []
        if self.profile_encoder is not None:
            if batch.get("profile_numeric") is None:
                self._note("the batch has no 'profile_numeric'; the profile positions are left out")
            else:
                parts.append(self.profile_encoder(batch["profile_numeric"]))                     # [B, 2, W]
        if self.state_prefix is not None:
            if batch.get("state_sums") is None or batch.get("state_counts") is None:
                self._note("the batch has no 'state_sums'/'state_counts'; the state positions are left out")
            else:
                parts.append(self.state_prefix(batch["state_sums"], batch["state_counts"]))       # [B, H, W]
        return torch.cat(parts, dim=1) if parts else None

    def _context(self, batch, valid):
        """The merchant context of every row, [B, T, d]. A batch without it gives every row the 'no context' vector."""
        if batch.get("context_present") is None:
            self._note("the batch has no merchant context; every row gets the 'no context' vector")
            B, T = valid.shape
            dim = self.merchant_context.embed.in_features - 2
            zeros = torch.zeros(B, T, 1, device=valid.device)
            return self.merchant_context(zeros.unsqueeze(-1).expand(B, T, 1, dim), zeros, zeros,
                                         torch.zeros(B, T, 1, dtype=torch.bool, device=valid.device))
        return self.merchant_context(batch["context_vectors"], batch["context_scores"], batch["context_ages"],
                                     batch["context_present"])

    def forward(self, batch, return_details=False):
        """One pair of logits per row.

        batch   a dict with the keys of the original model:
                  continuous [B, T, C] float, categorical [B, T, K] int, mask [B, T] bool (True on real
                  rows), time_seq [B, T] int (whole seconds)
                and, read only when the block that needs it is switched on:
                  outcome [B, T] int                       the row's own bank outcome code (outcome layer)
                  match_values [B, T, F] int               codes whose equality the attention bias tests
                  profile_numeric [B, P] float             profile fields of the first row of each sequence
                  state_sums [B, H, v], state_counts [B, H]   stored account state as of the first row
                  context_vectors [B, T, N, v], context_scores, context_ages [B, T, N] float,
                  context_present [B, T, N] bool           stored rows of other accounts at the merchant
        return_details   also return a dict with the spread across members, each member's logits,
                         the transaction vectors and the vector the head reads

        Returns float [B, T, 2], or (logits, details) with `return_details`.
        """
        valid, times = batch["mask"].bool(), batch["time_seq"]
        B, T = valid.shape

        # Stage 1: every transaction by itself. The field tokens after stage 1 are kept only for the re-read.
        tokens = self.tokenizer(batch["continuous"], batch["categorical"])                       # [B, T, F, d]
        if self.reread_block is not None or self.interleaved is not None:
            vectors, fields = self.stage1(tokens, return_fields=True)                            # [B, T, K*d]
        else:
            vectors, fields = self.stage1(tokens), None

        # Inputs of the optional blocks. Each is built once per sequence, before any repetition for members.
        prefix = self._prefix(batch)
        bias = None
        if self.attention_bias is not None:
            if batch.get("match_values") is None:
                self._note("the batch has no 'match_values'; stage 2 runs without the attention bias")
            else:
                bias = self.attention_bias(batch["match_values"], times, valid)                  # [B, heads, T, T]
        outcome = None
        if self.stage2.first_layer is not None:
            outcome = batch.get("outcome")
            if outcome is None:
                self._note("the batch has no 'outcome'; the outcome layer shows no outcome to later rows")
        context = self._context(batch, valid) if self.merchant_context is not None else None

        # Members: every per-sequence input is repeated in the order of `expand`, so that copy m of sequence b
        # gets the times, mask, prefix, bias, outcome codes and field tokens of sequence b.
        stage2_in, rep = vectors, (lambda x: x)
        if self.members is not None:
            stage2_in, rep = self.members.expand(vectors), self.members.repeat

        # The gated re-reads between the stage-2 blocks: the bank they query is built once per batch.
        after_block = None
        if self.interleaved is not None:
            bank = fields
            if self.predictor_bank is not None:
                # One vector per input: every tokenizer token reads the summary outputs of its own row.
                bank = self.predictor_bank(tokens, vectors.reshape(B, T, self.stage1.num_summary, -1))
            memory = self.interleaved.prepare(rep(bank), rep(times), rep(valid))

            def after_block(number, rows):
                return self.interleaved.after_layer(number, rows, memory)

        # Stage 2 under the strict time rule; the prefix, the bias and the outcome codes go in here.
        history = self.stage2(stage2_in, rep(times), rep(valid), prefix=rep(prefix), bias=rep(bias),
                              outcome=rep(outcome), after_block=after_block)                   # [B(*M), T, W]
        if self.reread_block is not None:
            # The row reads its own field tokens once more; no other row is involved.
            history = self.reread_block(history, rep(fields))
        if context is not None:
            history = torch.cat([history, rep(context)], dim=-1)

        if self.members is not None:
            logits, spread, each = self.members.combine(history)
        else:
            logits = self.head(history)
            spread, each = torch.zeros(B, T, device=logits.device), logits.unsqueeze(1)
        if return_details:
            return logits, {"spread": spread, "member_logits": each, "vectors": vectors, "head_input": history}
        return logits

    def loss(self, batch, class_weight=None):
        """The training loss over the real rows of a batch.

        batch          as for `forward`, plus target_seq [B, T] int (1 fraud, 0 not, -100 on padding)
        class_weight   None, or float [2]: the weight of each class

        Returns a scalar: the summed weighted cross-entropy over real rows divided by their
        number, as in the original all-position mode; with members, each member's own loss,
        averaged over the members (members.member_loss).
        """
        valid = batch["mask"].bool()
        logits, details = self(batch, return_details=True)
        targets = batch["target_seq"]
        if self.members is not None:
            return member_loss(details["member_logits"], targets, valid, class_weight)
        labels = targets[valid]
        return F.cross_entropy(logits[valid], labels, weight=class_weight, reduction="sum") / max(labels.numel(), 1)


def extra_inputs(df, batch, row_index, vector_dim=None, profile_cols=None, seed=0):
    """Every optional input of the model, built from a table of rows, in the layout of `batch`.

    df            the table the batch was built from (one row per transaction)
    batch, row_index   from _shared.sequences_from_table(df)
    vector_dim    width of the made-up stored vectors; None reads DEMO_VECTOR_DIM
    profile_cols  date columns used as profile fields; None reads DEMO_PROFILE_COLS (made up when absent)
    seed          seed of the made-up stored vectors and scores

    Returns (extra, sizes): `extra` holds the batch keys listed in TwoStageReference.forward,
    `sizes` the constructor arguments that switch every optional block on with matching sizes.

    The stored vectors and scores are made up here (synthetic.make_vectors and make_scores);
    in a real run they come from a frozen first model. Everything respects the time rule:
    the state and the profile are those of the first row of each sequence (strictly earlier
    rows only, and values stamped at that row), the merchant context lists rows of other
    accounts in strictly earlier seconds.
    """
    vector_dim = DEMO_VECTOR_DIM if vector_dim is None else int(vector_dim)
    profile_cols = list(DEMO_PROFILE_COLS if profile_cols is None else profile_cols)
    valid = batch["mask"]
    first = row_index[:, 0]                                       # real rows come first, so slot 0 is real
    secs = timekeys.seconds(df[settings.TIME_COL])
    extra = {}

    extra["outcome"] = layout(outcome_codes(df), row_index, fill=0)
    values, names = match_values(df)
    extra["match_values"] = layout(values, row_index, fill=-1)

    if any(c not in df.columns for c in profile_cols):
        df = synthetic.add_profile_dates(df, seed=seed)[0]
    profile = [days_before(df[c], df[settings.TIME_COL]) for c in profile_cols if c in df.columns]
    if profile:
        per_row = layout(np.stack(profile, axis=1), row_index, fill=0.0)                       # [B, T, P]
        extra["profile_numeric"] = first_row_values(per_row, valid)                            # [B, P]
    else:
        print("note: no profile column is available; the profile positions stay off")

    # Made-up stored vectors and scores stand in for the exports of a frozen first model.
    stored = synthetic.make_scores(synthetic.make_vectors(df, dim=vector_dim, seed=seed), seed=seed)
    vectors = stored[[f"{settings.VECTOR_PREFIX}{j}" for j in range(vector_dim)]].to_numpy(dtype=np.float32)
    accounts = timekeys.codes(df[settings.ACCOUNT_COL])
    sums, counts = account_state(accounts, secs, vectors)
    extra["state_sums"] = torch.as_tensor(sums[first], dtype=torch.float32)                   # [B, H, v]
    extra["state_counts"] = torch.as_tensor(counts[first], dtype=torch.float32)               # [B, H]

    context = gather_context(context_index(df), vectors, stored[settings.SCORE_COL], secs, rows=row_index)
    for key in ("vectors", "scores", "ages", "present"):
        extra[f"context_{key}"] = torch.as_tensor(context[key])

    sizes = {"bias_fields": len(names), "profile_numeric": len(profile), "state_vector_dim": vector_dim,
             "num_states": sums.shape[1], "context_vector_dim": vector_dim}
    return extra, sizes


def main(argv=None):
    """Command line: train the reference model for a few steps on made-up rows and print the loss before and after."""
    parser = argparse.ArgumentParser(description="Train the two-stage reference model on made-up rows.")
    parser.add_argument("--accounts", type=int, default=60, help="made-up accounts")
    parser.add_argument("--days", type=int, default=20, help="days of made-up activity")
    parser.add_argument("--steps", type=int, default=20, help="optimiser steps")
    parser.add_argument("--lr", type=float, default=1e-3, help="learning rate")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--summary", type=int, default=1, help="summary tokens of stage 1")
    parser.add_argument("--width", type=int, default=None, help="width of stage 2 (default: that of stage 1)")
    parser.add_argument("--members", type=int, default=1, help="members sharing stage 2")
    parser.add_argument("--interleaved", action="store_true", help="a gated re-read after every stage-2 block")
    parser.add_argument("--memory", type=int, default=0, help="latest earlier transactions the re-reads also see")
    for flag in ("reread", "outcomes", "bias", "profile", "state", "merchant"):
        parser.add_argument(f"--{flag}", action="store_true", help=f"switch the {flag} block on")
    parser.add_argument("--all", action="store_true", help="switch every block on (3 summary tokens, 3 members)")
    parser.add_argument("--out", default=None, help="save the trained weights to this file")
    args = parser.parse_args(argv)
    if args.all:
        args.reread = args.outcomes = args.bias = args.profile = args.state = args.merchant = True
        args.summary, args.members = max(args.summary, 3), max(args.members, 3)
        args.interleaved, args.memory = True, max(args.memory, 2)

    torch.manual_seed(args.seed)
    df = synthetic.make_transactions(n_accounts=args.accounts, days=args.days, seed=args.seed,
                                     fraud_account_share=0.3, tie_share=0.1)
    batch, row_index, cards = sequences_from_table(df)
    extra, sizes = extra_inputs(df, batch, row_index, seed=args.seed)
    batch = {**batch, **extra}
    model = TwoStageReference(
        batch["continuous"].shape[-1], cards, num_summary=args.summary, stage2_width=args.width,
        reread=args.reread, aligned_outcomes=args.outcomes, num_members=args.members,
        interleaved_reread=args.interleaved, memory_back=args.memory,
        bias_fields=sizes["bias_fields"] if args.bias else 0,
        profile_numeric=sizes["profile_numeric"] if args.profile else 0,
        state_vector_dim=sizes["state_vector_dim"] if args.state else 0, num_states=sizes["num_states"],
        context_vector_dim=sizes["context_vector_dim"] if args.merchant else 0)
    n_rows, n_fraud = int(batch["mask"].sum()), int((batch["target_seq"] == 1).sum())
    n_weights = sum(p.numel() for p in model.parameters())
    print(f"{batch['mask'].shape[0]} sequences, {n_rows} rows, {n_fraud} frauds, {n_weights} weights")

    def evaluate():
        model.eval()
        with torch.no_grad():
            return float(model.loss(batch))

    before = evaluate()
    optimiser = torch.optim.AdamW(model.parameters(), lr=args.lr)
    print(f"{'step':>5}  {'train loss':>10}")
    # One full batch per step: the made-up table is small, and the point is to show that the wiring trains.
    for step in range(1, args.steps + 1):
        model.train()
        optimiser.zero_grad()
        loss = model.loss(batch)
        loss.backward()
        optimiser.step()
        if step == 1 or step % 5 == 0 or step == args.steps:
            print(f"{step:>5}  {loss.item():>10.4f}")
    after = evaluate()
    print(f"loss before: {before:.4f}   loss after: {after:.4f}")
    if args.out:
        torch.save(model.state_dict(), args.out)
        print(f"written: {args.out}")
    return before, after


if __name__ == "__main__":
    main()
