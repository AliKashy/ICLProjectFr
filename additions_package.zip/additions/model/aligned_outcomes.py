"""Later rows read what the bank decided on an earlier row; no row reads its own decision.

What this file does
-------------------
`AlignedOutcomeLayer` is a first layer for stage 2 that carries the bank's decision on each
row (approved, declined for funds, declined for risk, another refusal, an advice) into the
history of the rows after it. It is one attention layer with three differences from a
standard block:

    the query of a row       is the row's vector WITHOUT its outcome
    the keys and values      of the earlier rows are their vectors PLUS an embedding of their outcome
    a row does not read itself in this layer; its own content passes through the residual path

`outcome_codes` makes the code per row from the raw decision columns.

The result: the vector of row i depends on the outcomes of the rows in strictly earlier
seconds and never on the outcome of row i. The layers after this one read vectors that
hold no row's own outcome, so the property survives to the logit. The test changes the
outcome code of single rows and checks exactly that: the row's own output does not move,
the outputs of later rows do.

Why it exists
-------------
A fraud label sits only on approved rows, so declined attempts are never labelled, and
fraud labels arrive weeks after the transaction. Inside a fraud run the model therefore
cannot be told that the previous row was fraud. What is known at once is what the bank
did: a risk decline two minutes ago, three refusals followed by a smaller amount that went
through. Frauds come in runs on one account, so most frauds follow an earlier fraud of
that account, and the bank's reaction to the earlier rows of the run is the nearest thing
to label feedback that exists at scoring time.

The decision on a row is an outcome of that row. It does not exist yet at the moment the
row has to be scored, and it is tied to the label (a declined row never carries one), so a
row that could read it would be reading part of its own answer. Every row of a sequence is
scored, so the same row is a target and, a moment later, history.
The usual way out is to shift outcomes by one row, which puts the outcome of row t-1 on
row t. That breaks on rows of one second, and it ties each outcome to the one next row
instead of to the row it belongs to. Here every outcome stays on its own row, where the
attention of later rows finds it together with that row's amount, merchant and time.

Where it goes
-------------
Raw files, then `outcome_codes` (or the family column of additions/features/outcome_history.py),
then stage 2: the layer is the `first_layer` of history_stage.py and takes the place of
its first block. In the original code it would be called in `FTTransformerHierModel.forward`
just before `seq_encoder`, with one block fewer in that encoder, and the sequence builder
would deliver one outcome code per row next to `time_seq`.

What to change for the pod
--------------------------
`NUM_OUTCOME_CODES` below. The raw columns and code lists are in settings.py
(`REASON_COL`, `DECLINE_FLAG_COL`, `ADVICE_COL`, `APPROVED_REASONS`, `RISK_DECLINE_REASONS`,
`FUNDS_DECLINE_REASONS`, `DECLINE_FLAG_VALUES`). Two points to confirm with the data owner:
that the decision columns are final at the time of the transaction (a reversal written
back onto the original row would be knowledge of the future), and that advice rows are
known at their own timestamp. The stored history at scoring time must keep declined rows
with their codes.

How to try it
-------------
    layer = AlignedOutcomeLayer(width=144)
    stage2 = HistoryStage(in_dim=144, first_layer=layer)
    codes = layout(outcome_codes(df), row_index)                 # int [B, T], 0 on padding
    history = stage2(vectors, batch["time_seq"], batch["mask"], outcome=codes)
    python -m pytest -q additions/tests/test_model_aligned_outcomes.py
"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from additions.model._shared import pick

# PLACEHOLDER: the number of outcome codes, counting code 0 ("not known"); 6 fits the five families of
# additions/features/outcome_history.py (approved, funds decline, risk decline, other decline, advice).
NUM_OUTCOME_CODES = 6


def outcome_codes(df, family=None, **columns):
    """One outcome code per row, for the embedding of `AlignedOutcomeLayer`.

    df         raw rows, one per transaction
    family     a ready-made family per row (int [rows], -1 for unknown); None builds it from the
               decision columns named in settings
    columns    passed on to features.outcome_history.outcome_family (other column names or code lists)

    Returns int64 [rows]: 0 for "not known", then 1 + family (1 approved, 2 funds decline,
    3 risk decline, 4 other decline, 5 advice). When no decision column is available the
    function prints one line and returns zeros; the layer then adds nothing to any key.

    The code describes the row's OWN outcome. The only lawful reader is a later row, which
    is what the layer below guarantees.
    """
    if family is None:
        # Imported here, so that the layer itself needs nothing from the features folder.
        from additions.features.outcome_history import outcome_family
        family = outcome_family(df, **columns)
    if family is None:
        print("note: no decision column is available; every outcome code is 0 and the layer adds nothing")
        return np.zeros(len(df), dtype=np.int64)
    return np.asarray(family, dtype=np.int64) + 1


class AlignedOutcomeLayer(nn.Module):
    """A first layer for stage 2 in which earlier rows show their outcome and no row reads itself.

    width          width of stage 2; None reads settings.EMBED_DIM
    num_heads      attention heads; None reads settings.NUM_HEADS
    num_outcomes   number of outcome codes, counting 0 for "not known"; None reads NUM_OUTCOME_CODES
    ff_multiplier  the feed-forward layer is this many times as wide as the layer
    dropout, attn_dropout   on the residual branches and on the attention weights
    """

    def __init__(self, width=None, num_heads=None, num_outcomes=None, ff_multiplier=4, dropout=0.1, attn_dropout=0.1):
        super().__init__()
        width = pick(width, "EMBED_DIM")
        self.num_heads = pick(num_heads, "NUM_HEADS")
        num_outcomes = NUM_OUTCOME_CODES if num_outcomes is None else num_outcomes
        # Code 0 ("not known", and padding) always embeds to zeros: it adds nothing to a key.
        self.outcome = nn.Embedding(num_outcomes, width, padding_idx=0)
        nn.init.normal_(self.outcome.weight, std=0.02)
        with torch.no_grad():
            self.outcome.weight[0].zero_()
        # A learned key that every row may always read. A row with no earlier row would otherwise have
        # nothing to read in this layer (it may not read itself here), and a softmax over nothing is NaN.
        # The key also gives the network a way to say "no earlier row is worth reading".
        self.nothing = nn.Parameter(torch.zeros(1, 1, width))
        nn.init.normal_(self.nothing, std=0.02)
        self.norm_attention = nn.LayerNorm(width)
        self.attend = nn.MultiheadAttention(width, self.num_heads, dropout=attn_dropout, batch_first=True)
        self.norm_ff = nn.LayerNorm(width)
        self.feed_forward = nn.Sequential(nn.Linear(width, width * ff_multiplier), nn.GELU(), nn.Dropout(dropout),
                                          nn.Linear(width * ff_multiplier, width))
        self.drop = nn.Dropout(dropout)

    def forward(self, x, allowed, outcome=None, bias=None):
        """One layer of stage 2.

        x         float [B, L, width]: the positions of stage 2 (rows, with prefix positions in front if any)
        allowed   bool [B, L, L]: [b, i, j] says whether position i may read position j
                  (masks.strict_visibility, with masks.with_prefix when there is a prefix)
        outcome   None, or int [B, L]: the outcome code of every position; 0 on prefix and padding
        bias      None, or float [B, heads, L, L]: a learned bias on the attention logits (attention_bias.py)

        Returns float [B, L, width].

        What reaches the output of position i: its own vector (through the residual path),
        and the vectors plus outcome embeddings of the positions it may read, itself excluded.
        Its own outcome is added to its key and value only, and its key and value are read
        by later rows only.
        """
        B, L, W = x.shape
        normed = self.norm_attention(x)
        # Queries: the vectors as they are. Keys and values: the same vectors plus the outcome embedding.
        # The outcome is added on this side only, which is the whole point of the layer.
        shown = normed if outcome is None else normed + self.outcome(outcome)
        keys = torch.cat([self.nothing.expand(B, 1, W), shown], dim=1)                    # [B, 1 + L, width]

        # Who may be read: the learned "nothing" key always; an earlier position when `allowed` says so;
        # never the position itself. Closing the diagonal is what keeps a row's outcome away from the row.
        itself = torch.eye(L, dtype=torch.bool, device=x.device)
        readable = torch.cat([torch.ones(B, L, 1, dtype=torch.bool, device=x.device), allowed & ~itself], dim=2)
        mask = torch.zeros(B, 1, L, 1 + L, dtype=x.dtype, device=x.device)
        mask = mask.masked_fill(~readable.unsqueeze(1), float("-inf")).repeat(1, self.num_heads, 1, 1)
        if bias is not None:
            mask = mask + F.pad(bias, (1, 0))                                             # no bias on the "nothing" key
        mask = mask.reshape(B * self.num_heads, L, 1 + L)

        # Query and keys are different tensors, so this call always adds the float mask to the logits.
        read, _ = self.attend(normed, keys, keys, attn_mask=mask, need_weights=False)
        x = x + self.drop(read)
        return x + self.drop(self.feed_forward(self.norm_ff(x)))
