"""Stage 2 at its own width, under the strict time rule.

What this file does
-------------------
`HistoryStage` is the second stage of the two-stage model. It takes one vector per
transaction (from stage 1), lets every row read the rows of its account that lie in
strictly earlier seconds, and returns one history-aware vector per row. Three things set it
apart from a plain stack of transformer blocks:

    its own width         the blocks run at any width, for example 3 * 48 = 144; when the vectors
                          that come in have another width, a learned projection brings them to it
    position by count     a row's position is the number of real rows in strictly earlier seconds,
                          not its slot in the batch
    three optional hooks  positions in front of the rows (`prefix`), a learned bias on the attention
                          logits (`bias`), and a first layer of another kind (`first_layer`)

Why it exists
-------------
What a transaction means depends on what the account did before it. A purchase at a
merchant the account never used, a burst of rows after a quiet week, a decline a minute
ago: none of that is visible in the row itself. Frauds come in runs on one account, so most
frauds follow an earlier fraud of that account, and stage 2 is the only place where a row
meets the rows before it. How much it can make of them is bounded by its width. Most of
the arithmetic of the model is spent in stage 1, so a wider stage 2 buys more room for
history at a small price.

The position of a row is counted, not read off its slot, for the same reason that rows of
one second may not see each other. Rows of one second sit in neighbouring slots in an order
that means nothing. If the position came from the slot, a row would be told how many rows
of its own second happen to be sorted before it, which is information about rows it must
not see. The count of strictly earlier rows is the same for all rows of a second.

Where it goes
-------------
After stage 1, before the head. In the original code it takes the place of `txn_position`,
`seq_encoder` and the mask from `_build_causal_mask` in `FTTransformerHierModel.forward`.
The original also puts one extra summary position in front of the rows; in the all-position
mode no row may read it and its output is not used, so it is left out here without changing
any row's result. summary_tokens.py feeds this stage; profile_encoder.py and state_prefix.py
make a `prefix`, attention_bias.py makes a `bias`, aligned_outcomes.py is a `first_layer`.

What to change for the pod
--------------------------
`settings.EMBED_DIM` (the default width of the incoming vectors), `settings.NUM_HEADS`,
`settings.STAGE2_BLOCKS` and `settings.HISTORY_LEN` (the position table has HISTORY_LEN + 1
entries; rows with more earlier rows than that share the last entry). The width must be a
multiple of the number of heads. `masks.TIME_UNITS_PER_SECOND` says in what unit the batch
carries its times. If the model in use runs stage 2 through nn.TransformerEncoder and a
bias is to be added to its mask, the blocks have to be run the way `run_blocks` in
_shared.py runs them; that file explains why.

How to try it
-------------
    stage2 = HistoryStage(in_dim=144, width=144)
    history = stage2(vectors, batch["time_seq"], batch["mask"])          # [B, T, 144] -> [B, T, 144]
    python -m pytest -q additions/tests/test_model_history_stage.py
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from additions.model import masks
from additions.model._shared import encoder_stack, pick, run_blocks


class HistoryStage(nn.Module):
    """Lets every row read the strictly earlier rows of its sequence.

    in_dim        width of the incoming transaction vectors; None reads settings.EMBED_DIM
    width         width of the blocks; None means the same as `in_dim`
    num_heads     attention heads; None reads settings.NUM_HEADS
    num_blocks    blocks in the stage, counting `first_layer` when there is one; None reads
                  settings.STAGE2_BLOCKS
    history_len   the position table has history_len + 1 entries; None reads settings.HISTORY_LEN
    first_layer   an optional module that stands in for the first block. It is called as
                  first_layer(x, allowed, outcome, bias) with x [B, L, width], allowed bool [B, L, L],
                  outcome None or int [B, L], bias None or float [B, heads, L, L], and returns
                  [B, L, width] (see aligned_outcomes.AlignedOutcomeLayer)
    units_per_second   unit of the times in the batch; None reads masks.TIME_UNITS_PER_SECOND
    ff_multiplier, dropout, attn_dropout   as in _shared.encoder_stack
    """

    def __init__(self, in_dim=None, width=None, num_heads=None, num_blocks=None, history_len=None, first_layer=None,
                 units_per_second=None, ff_multiplier=4, dropout=0.1, attn_dropout=0.1):
        super().__init__()
        in_dim = pick(in_dim, "EMBED_DIM")
        self.width = in_dim if width is None else width
        self.num_heads = pick(num_heads, "NUM_HEADS")
        self.units_per_second = units_per_second
        # The projection exists only when the two widths differ. With equal widths the vectors pass
        # through untouched, which keeps the stage equal to the original design.
        self.project = nn.Identity() if in_dim == self.width else nn.Linear(in_dim, self.width)
        self.position = nn.Embedding(pick(history_len, "HISTORY_LEN") + 1, self.width)
        self.first_layer = first_layer
        # A custom first layer takes the place of one block, so the depth of the stage does not change.
        n_standard = pick(num_blocks, "STAGE2_BLOCKS") - (1 if first_layer is not None else 0)
        self.blocks = encoder_stack(self.width, self.num_heads, n_standard, ff_multiplier, dropout, attn_dropout)

    def forward(self, vectors, times, valid, prefix=None, bias=None, outcome=None):
        """One history-aware vector per row.

        vectors   float [B, T, in_dim]: one vector per transaction, from stage 1
        times     integer [B, T]: the time of every slot (any value on padding)
        valid     bool [B, T]: True on real rows
        prefix    None, or float [B, P, width]: positions put in front of the rows. Every row may read
                  them, so their content must be older than every row of the sequence
        bias      None, or float [B, heads, T, T]: added to the attention logits of row i reading row j
        outcome   None, or int [B, T]: handed to `first_layer`, which alone decides what to do with it

        Returns float [B, T, width]. The outputs of prefix positions are dropped. The output of
        a padded slot is finite and means nothing, whatever the padded slot held on the way in.
        """
        allowed = masks.strict_visibility(times, valid, self.units_per_second)       # bool [B, T, T]
        # Padded slots are set to zero first. No row reads them, but attention multiplies every value by
        # its weight, and a weight of zero times a missing value (NaN) is still NaN. Zeroing the padding
        # means that whatever the builder leaves there can never turn a real row's output into NaN.
        vectors = vectors.masked_fill(~valid.bool().unsqueeze(-1), 0.0)
        # Position: how many rows the row may read besides itself. The diagonal of `allowed` is always
        # True, hence the "- 1". Rows of one second get the same number, and a padded slot gets 0.
        # Rows with more earlier rows than the table has entries share the last entry.
        n_earlier = allowed.sum(dim=-1) - 1
        x = self.project(vectors) + self.position(n_earlier.clamp(max=self.position.num_embeddings - 1))

        n_prefix = 0
        if prefix is not None:
            n_prefix = prefix.shape[1]
            x = torch.cat([prefix, x], dim=1)                                        # [B, P + T, width]
            allowed = masks.with_prefix(allowed, n_prefix)
            # The bias and the outcome say nothing about the prefix positions: zeros there.
            if bias is not None:
                bias = F.pad(bias, (n_prefix, 0, n_prefix, 0))
            if outcome is not None:
                outcome = F.pad(outcome, (n_prefix, 0))

        if self.first_layer is not None:
            x = self.first_layer(x, allowed, outcome, bias)
        # The mask is built in float32; it is brought to the number type of the vectors, so that a model run
        # in another precision gets a mask that attention accepts.
        mask = masks.to_attention_mask(allowed, self.num_heads).to(x.dtype)         # float [B * heads, L, L]
        if bias is not None:
            # Minus infinity plus any bias stays minus infinity: the bias can change how much a row reads
            # of what it may read, never what it may read.
            mask = mask + bias.reshape(mask.shape)
        # `run_blocks`, not `self.blocks(x, mask=mask)`: the mask must be ADDED to the logits in scoring
        # as well as in training (see _shared.py).
        x = run_blocks(self.blocks, x, mask)
        return x[:, n_prefix:]
