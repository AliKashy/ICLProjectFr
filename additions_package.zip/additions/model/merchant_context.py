"""What other accounts just did at the row's merchant, pooled into one vector for the head.

What this file does
-------------------
For every row it finds the last N rows at the same merchant that belong to OTHER accounts
and lie in strictly earlier seconds, takes what a frozen first pass of the model stored
for those rows (their vector and their score) together with their age, and pools them into
one context vector with one attention block and a learned query. A row whose merchant has
no such rows gets a learned "no context" vector. The context is concatenated to the row's
own vector before the head.

    last_other_rows   the row numbers of those N rows, for every row (arrays in, array out)
    context_index     the same, reading the merchant, account and time columns named in settings
    gather_context    the stored vectors, scores and ages of the listed rows, for the rows of a batch
    MerchantContext   the pooling block

Why it exists
-------------
A model that reads one account at a time cannot see what makes a merchant dangerous today:
a terminal that is being used to test stolen cards, a shop whose customers' cards are being
drained one after the other. From inside one account such a row looks like an ordinary
purchase. From the merchant's side it is the tenth unusual row in an hour, each on a
different account. The rows of the other accounts carry that, and the first pass has
already summarised each of them, with its own history, in a vector and a score. Pooling
them is one round of message passing in which every message is itself a summary of an
account's history.

The row's own account is removed because its rows are already in the row's history, and
because the point is evidence that is independent of the account. Only strictly earlier
seconds are used: a row of the same second, on any account, may not be known yet.

One limit has to be kept in mind. The files hold whole accounts and no account is in two
files, so a merchant's rows are present only for the accounts in the files that were read.
The context is therefore thin for all but the busiest merchants unless many files are
read, and the learned "no context" vector will be the common case.

Where it goes
-------------
A first pass of the model scores every row and exports its vector and score (exports).
`context_index` runs once per table on the CPU; `gather_context` runs per batch in the
loader; `MerchantContext` sits between stage 2 and the head. In the original code its
output would be concatenated to the row's vector just before `self.head` in
`FTTransformerHierModel.forward`, and the head would become that much wider. In production
the same content is a small per-merchant store that is written after each scored
transaction and read by merchant at scoring time.

What to change for the pod
--------------------------
`settings.MERCHANT_COL`, `ACCOUNT_COL`, `TIME_COL`; `settings.SCORE_KIND` (the stored score is
turned into log-odds); `N_LAST` and `STORE_DELAY_SECONDS` below. The stored vectors and
scores must come from a model that is kept fixed: if the first pass is trained further,
every stored vector is out of date. They should also come from a model that did not train
on those rows, or the stored scores of training rows are better than the scores of new rows
will be. Labels are never part of the context.

How to try it
-------------
    index = context_index(df)                                           # int [rows, 16], -1 where fewer
    ctx = gather_context(index, vectors, df[settings.SCORE_COL], secs, rows=row_index)
    block = MerchantContext(vector_dim=vectors.shape[1])
    context = block(*(torch.as_tensor(ctx[k]) for k in ("vectors", "scores", "ages", "present")))   # [B, T, 48]
    logits = head(torch.cat([history, context], dim=-1))
    python -m pytest -q additions/tests/test_model_merchant_context.py
"""
import numpy as np
import torch
import torch.nn as nn

from additions.common import ranking, timekeys
from additions.common.history import EarlierRows
from additions.common.timekeys import MISSING_SECOND
from additions.model._shared import pick

# PLACEHOLDER: how many rows of other accounts are kept per row.
N_LAST = 16

# PLACEHOLDER: how many seconds old a row must be before another row may read it; 1 means "from the next
# second on". A store that needs longer to make a scored row readable needs a larger number here.
STORE_DELAY_SECONDS = 1


def last_other_rows(merchants, accounts, secs, n_last=None, min_age=None, max_age=None):
    """For every row, the last rows of OTHER accounts at the same merchant.

    merchants   one integer per row; a negative number means "no merchant" [rows]
    accounts    one integer per row [rows]
    secs        whole seconds of every row [rows]
    n_last      how many rows to keep per row; None reads N_LAST
    min_age     a listed row is at least this many seconds older; None reads STORE_DELAY_SECONDS
    max_age     a listed row is at most this many seconds older; None means no limit

    Returns int64 [rows, n_last]: row numbers, the latest first, -1 where there are fewer.

    Three rules hold for every listed row: it is at the same merchant, it lies in a strictly
    earlier second (at least `min_age` seconds back), and it belongs to another account. Rows
    without a merchant or without a time list nothing and are listed by nobody.

    How it works. Rows are sorted by merchant and second, so the earlier rows at a merchant
    are a stretch of positions that ends just before the row's own second. Walking back
    through that stretch and skipping the row's own account would be simple but slow for an
    account that returns to one merchant thousands of times. The skipping is done by
    arithmetic instead. Number an account's rows at a merchant 1, 2, 3, ... in sorted order.
    For such a row, (position - number) never decreases along the stretch, so a binary
    search tells how many of the account's own rows lie behind the k-th last row of the
    other accounts, and the position of that row follows.
    """
    merchants, accounts = np.asarray(merchants), np.asarray(accounts)
    secs = np.asarray(secs, dtype=np.int64)
    n_last = N_LAST if n_last is None else int(n_last)
    min_age = max(int(STORE_DELAY_SECONDS if min_age is None else min_age), 1)
    out = np.full((len(secs), n_last), -1, dtype=np.int64)
    usable = np.flatnonzero((merchants >= 0) & (secs != MISSING_SECOND))
    if len(usable) == 0:
        return out
    engine = EarlierRows(merchants[usable], secs[usable])
    m = len(usable)
    row_of = usable[engine.order]                       # sorted position -> row number in the caller's table
    # lo .. hi - 1 are the sorted positions of the rows at the same merchant in strictly earlier seconds.
    lo, hi = engine.bounds(max_age)
    if min_age > 1:
        # Rows younger than `min_age` are cut off the end of the stretch: `hi` moves back to the first
        # position whose second is too recent.
        newest = engine.group * engine.span + np.maximum(engine.rel - (min_age - 1), 0)
        hi = np.minimum(hi, np.searchsorted(engine.comp, newest, side="left"))
        lo = np.minimum(lo, hi)

    # One number per (merchant, account) pair, and the sorted positions of each pair, in ascending order.
    pair = timekeys.codes(engine.group, accounts[row_of])
    by_pair = np.argsort(pair, kind="stable")
    pair_grouped = pair[by_pair]
    first = np.r_[True, pair_grouped[1:] != pair_grouped[:-1]]
    start = np.maximum.accumulate(np.where(first, np.arange(m), 0))
    number = np.arange(m) - start + 1                   # 1 for the pair's first row at the merchant, then 2, 3, ...
    big = m + n_last + 3                                # larger than any position or slack, so pairs do not mix
    own_position = pair_grouped * big + by_pair                   # ascending: by pair, then by position
    own_slack = pair_grouped * big + (by_pair - number + 1)       # ascending too: position minus number never decreases
    pair_start = np.searchsorted(pair_grouped, pair, side="left")
    # How many rows of the row's own account lie before `hi` at this merchant.
    n_own = np.searchsorted(own_position, pair * big + hi, side="left") - pair_start

    # One pass per kept row (n_last passes, each over all rows at once). The k-th last row of the other
    # accounts sits at position hi - k - (own rows behind it), and an own row lies behind it exactly
    # when its (position - number) is at least hi - k - n_own.
    for k in range(1, n_last + 1):
        wanted = np.clip(hi - k - n_own + 1, 0, big - 1)
        in_front = np.searchsorted(own_slack, pair * big + wanted, side="left") - pair_start
        behind = n_own - np.minimum(in_front, n_own)
        spot = hi - k - behind
        found = spot >= lo
        out[row_of[found], k - 1] = row_of[spot[found]]
    return out


def context_index(df, merchant_col=None, account_col=None, time_col=None, n_last=None, min_age=None, max_age=None):
    """`last_other_rows` for a table, with the column names read from settings.

    df   raw rows of every file that was read; the more files, the more of a merchant's rows are present
    Returns int64 [rows, n_last]. Without a merchant column the function prints one line and
    returns a table of -1, so every row gets the "no context" vector.
    """
    merchant_col = pick(merchant_col, "MERCHANT_COL")
    n_last = N_LAST if n_last is None else int(n_last)
    if not merchant_col or merchant_col not in df.columns:
        print("note: no merchant column is available; every row gets the 'no context' vector")
        return np.full((len(df), n_last), -1, dtype=np.int64)
    merchants = timekeys.codes(df[merchant_col])
    merchants[df[merchant_col].isna().to_numpy()] = -1            # rows without a merchant share nothing
    accounts = timekeys.codes(df[pick(account_col, "ACCOUNT_COL")])
    secs = timekeys.seconds(df[pick(time_col, "TIME_COL")])
    return last_other_rows(merchants, accounts, secs, n_last, min_age, max_age)


def gather_context(index, vectors, scores, secs, rows=None, score_kind=None):
    """What the first pass stored for the listed rows, for a set of rows such as one batch.

    index        int [n, N] from `last_other_rows`
    vectors      float [n, d]: the stored vector of every row of the table
    scores       float [n]: the stored score of every row
    secs         int [n]: whole seconds of every row
    rows         the rows to gather for, as row numbers in any shape (for example the [B, T] row index
                 of a batch, with -1 on padding); None means every row
    score_kind   "probability" or "logit"; None reads settings.SCORE_KIND

    Returns a dict of numpy arrays, with S the shape of `rows`:
      vectors [S, N, d] float32, scores [S, N] float32 (log-odds), ages [S, N] float32 (seconds
      between the listed row and the row itself), present [S, N] bool. Places without a listed
      row hold zeros and present = False.

    The index table is small and can be kept for a whole table; the vectors are large, which
    is why they are gathered for one batch at a time.
    """
    index, secs = np.asarray(index), np.asarray(secs, dtype=np.int64)
    rows = np.arange(len(index)) if rows is None else np.asarray(rows)
    listed = np.where(rows[..., None] >= 0, index[np.maximum(rows, 0)], -1)                # [S, N]
    present = listed >= 0
    at = np.maximum(listed, 0)
    log_odds = ranking.to_logit(np.asarray(scores, dtype=np.float64), score_kind)
    age = secs[np.maximum(rows, 0)][..., None] - secs[at]
    return {"vectors": np.where(present[..., None], np.asarray(vectors)[at], 0.0).astype(np.float32),
            "scores": np.where(present, log_odds[at], 0.0).astype(np.float32),
            "ages": np.where(present, age, 0).astype(np.float32),
            "present": present}


class MerchantContext(nn.Module):
    """Pools the stored rows of other accounts at the merchant into one context vector.

    vector_dim    width d of the stored vectors
    context_dim   width of the context vector; None reads settings.EMBED_DIM
    num_heads     attention heads; None reads settings.NUM_HEADS
    ff_multiplier, dropout   size of the feed-forward layer and dropout of the block
    """

    def __init__(self, vector_dim, context_dim=None, num_heads=None, ff_multiplier=2, dropout=0.1):
        super().__init__()
        c = self.context_dim = pick(context_dim, "EMBED_DIM")
        # A listed row enters as its stored vector, its score as log-odds and the logarithm of its age.
        self.embed = nn.Linear(vector_dim + 2, c)
        self.norm_items = nn.LayerNorm(c)
        self.query = nn.Parameter(torch.zeros(1, 1, c))
        nn.init.normal_(self.query, std=0.02)
        self.pool = nn.MultiheadAttention(c, pick(num_heads, "NUM_HEADS"), dropout=dropout, batch_first=True)
        self.norm_ff = nn.LayerNorm(c)
        self.feed_forward = nn.Sequential(nn.Linear(c, c * ff_multiplier), nn.GELU(), nn.Linear(c * ff_multiplier, c))
        # What a row gets when no other account was at its merchant before. A learned vector, not zeros:
        # "nobody else was here" is information, and the head can learn what it means.
        self.no_context = nn.Parameter(torch.zeros(c))
        nn.init.normal_(self.no_context, std=0.02)

    def forward(self, vectors, scores, ages, present):
        """One context vector per row.

        vectors   float [..., N, d]: stored vectors of the listed rows; the leading dimensions are free
        scores    float [..., N]: their stored scores as log-odds
        ages      float [..., N]: seconds between each listed row and the row itself
        present   bool [..., N]: False where there is no listed row

        Returns float [..., context_dim]. The order of the listed rows does not matter (their
        age is an input, not a position), and a place with present = False has no influence.
        """
        lead, n = present.shape[:-1], present.shape[-1]
        facts = torch.cat([vectors, scores.unsqueeze(-1), torch.log1p(ages.clamp(min=0)).unsqueeze(-1)], dim=-1)
        items = self.norm_items(self.embed(facts.reshape(-1, n, facts.shape[-1])))            # [R, N, c]
        present = present.reshape(-1, n)
        has_context = present.any(dim=1)
        # Attention must have at least one key to read. A row with nothing listed keeps its first place
        # open; what it reads there is thrown away two lines further down.
        closed = ~present
        closed[:, 0] = closed[:, 0] & has_context
        query = self.query.expand(items.shape[0], -1, -1)
        pooled = self.pool(query, items, items, key_padding_mask=closed, need_weights=False)[0][:, 0]
        pooled = pooled + self.feed_forward(self.norm_ff(pooled))
        context = torch.where(has_context.unsqueeze(-1), pooled, self.no_context.to(pooled.dtype))
        return context.reshape(*lead, self.context_dim)
