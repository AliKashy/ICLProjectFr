"""Stage 2 over latent channels: every transaction carried as M channels that stay apart until the end.

What this file does
-------------------
It holds a history stage in which every transaction is carried as M latent channels of width d,
not as one joined vector, and the parts that stage is built from.

    LatentChannelStage       the stage. It takes M channels per row; in the model in use they are the
                             stage-1 summary outputs kept apart instead of joined. Every channel reads
                             the same channel of the strictly earlier rows of its account, the channels
                             of one transaction read the transaction's field tokens and one another,
                             and the channels are joined only at the end (delayed concatenation). It
                             takes an attention bias for its through-time blocks (`bias`, in the layout
                             of attention_bias.py) or builds the time-gap bias itself (`time_bias`), and
                             `final_intra` adds one more within-transaction block after the last
                             through-time block
    WithinTransactionBlock   one block inside a row: the channels read the bank of field tokens (the
                             row's own and, with `num_back`, those of its latest earlier rows), then
                             attend to one another, then a feed-forward layer; `intra_order` can put the
                             two attention parts the other way round. Each part has its own residual
    ThroughTimeBlock         one pre-norm transformer layer through time, run on every channel as a
                             sequence of its own under the strict time rule
    ChannelPooler            M learned queries that make M channels out of the field tokens of one
                             transaction, for a model whose stage 1 has no summary tokens
    count_weights            the number of weights of a module
    describe                 one line per switch of a stage with its value, the first and last real row
                             of the latest call read as dates, and the number of weights

The stage follows the layout of the Large Payments Model (JPMorgan, arXiv 2611.15814, Eq. 7 and 8):

    Z0 = Pool_in(E);   for each of L blocks:  Z = CrossIntra(Z, E),  then  Z = CausalInter(Z);   H = Pool_out(Z)

E holds the field tokens of every transaction and Z its M channels. Pool_in is stage 1 with M summary
tokens (or `ChannelPooler`), CrossIntra is `WithinTransactionBlock`, CausalInter is `ThroughTimeBlock`
under the time rule of this package, and Pool_out is the readout of the stage. Inside CrossIntra the
channels read the fields first, then one another, then the feed-forward layer, the order Figure 4 of the
paper draws (`intra_order="cross_first"`, the default); "self_first" is the order of the first version of
this file. `bias` is added to the attention logits of every CausalInter, and `final_intra` runs one more
CrossIntra(Z, E) after the last CausalInter, just before Pool_out.

Why it exists
-------------
Today stage 1 hands three summary outputs to stage 2 joined into one vector of 144 numbers. Every
history layer treats that vector as one token: each head has one way of looking back for the whole
row, and every weight of the layer spans all 144 numbers. Kept apart, the summary outputs become
channels that each read the history on their own. A row can then look back in M ways at once: one
channel can follow the amounts of the account, another its merchants, another its timing, each with
attention of its own, and none has to share its view of the past with the others until the end.

Keeping the channels apart is also what makes a wider model affordable. The weights of a through-time
layer grow with the square of the channel width d, and one layer serves every channel. Six channels of
96 carry 576 numbers per row with about the weights of today's stage 2 at 144 (about one million); one
layer at 576 would have sixteen times the weights of today's layer at 144. What grows is the
arithmetic, since every channel runs its own attention through time and its own within-transaction
block. On 4 CPU cores six channels of 96 took five to six times as long as today's stage 2 to score
a batch of 32 sequences of 121 rows, and twelve channels eleven to fourteen times; a training step
took about ten and twenty times as long.

The within-transaction blocks are where the channels meet. Before each through-time block the channels
of a row read the row's field tokens again (cross-attention to the bank) and exchange what they found
(self-attention among the M channels). Field evidence read again while the history is read is what the
gated re-read and the memory of the fields of the 5 latest earlier rows brought on 23 November (about 2
points of AP); here it is part of every pair. With `num_back` the bank also holds the fields of the
row's latest earlier transactions, through `RecentFieldMemory` of interleaved_reread.py.

The time rule is the one of interleaved_reread.py, which is the rule of the mask of stage 2: a row
reads itself and the real rows of strictly earlier whole seconds. Rows of one second never see each
other, and no later row reaches an earlier row's result. The same window with its later slots marked
as padding gives the earlier rows bit for bit; the window cut after a row, or scored in groups, gives
them to rounding (about 1e-6), since the arithmetic then runs over another length. That is what keeps
all-position training on disjoint chunks and grouped scoring correct. The memory of earlier fields
takes the rows of an earlier second all or none (`ties="whole_seconds"`, the default here), so the
order of the rows inside a second, which the time does not fix and the scorer may not have, changes no
result beyond rounding.

Two additions sit on top of that layout, each behind a switch of its own so that each can be tested.
The first is a bias on the attention logits of the through-time blocks. Attention finds earlier rows
by comparing vectors, and a channel cannot hold an exact merchant id; the bias of attention_bias.py
hands every head the exact matches (the same merchant, the same merchant category, ...), how often a
value came back and how long ago a row was, as numbers added to the logits. It is added to every
channel alike. The time rule still decides which pairs exist: the bias can change how much a row reads
of what it may read, never what it may read. The second is one more within-transaction block after
the last through-time block (`final_intra`). In the layout "interleaved" every within-transaction block
comes before a through-time block, so what the last through-time block finds never meets the fields
again. The model in use gained from its re-read of the field outputs after the history layers, and
this block gives the channels that read at the end of the stage.

Where it goes
-------------
Stage 2. It takes the place of the joining step at the end of stage 1, of the position table and of
the stack of history layers. The head stays, at the width the stage hands back:

    vectors, fields = stage1(tokens, return_fields=True)            # [B, T, M * d] and [B, T, F, d]
    channels = vectors.view(B, T, M, d)                             # the M summary outputs, kept apart
    rows = stage(channels, fields, times, valid, row_extra=gap)     # [B, T, stage.out_dim]
    logits = head(rows)                                             # head = nn.Linear(stage.out_dim, 2)

The .view is right only when `vectors` is the M summary outputs side by side in channel-major order
(the d numbers of output 0, then the d numbers of output 1, ...) with nothing applied after the join:
no norm, no linear layer, no other order. A model that does anything to the joined vector hands the
summary outputs over from before the join.

`gap` is the time-gap input the model already has (the log of the gap to the latest strictly earlier
row), brought to width d by a linear layer of the caller; it is added to every channel of the row.
summary_tokens.py (package only) gives the channels and the fields (`return_fields=True`); a stage 1
without summary tokens gets its channels from `ChannelPooler`. Every within-transaction block re-reads
the fields already, so the interleaved re-read of interleaved_reread.py is not added on top.
final_intra takes the place of the model's re-read after stage 2; keep only one of the two.

The stage has no positions in front of the rows. A learned position that the model in use puts in
front of the rows (a sequence summary token, an account profile) is dropped when the stage replaces
stage 2: kept as a made-up row it would count as an earlier row of every row, change the gap of the
first row, and enter the memory of the first rows.

The time-gap bias of attention_bias.py is best made by the stage itself. `time_bias=True` builds an
AttentionBias(num_fields=0, num_heads=stage.num_heads, units_per_second=stage.units_per_second) into
the stage, and every call makes the bias from its own times. It starts at zero, so switching it on
changes nothing until it learns. A bias that needs match codes is made outside and goes in as one
more argument:

    attention_bias = AttentionBias(num_fields=len(names), num_heads=stage.num_heads,
                                   units_per_second=stage.units_per_second)
    bias = attention_bias(codes, times, valid)                      # float [B, heads, T, T]
    rows = stage(channels, fields, times, valid, row_extra=gap, bias=bias)

`codes` are the match codes of `match_values` laid out like the batch ([B, T, F], -1 on padding,
`layout` of _shared.py (package only) does it). A bias handed in must be built from the same batch in
the same call, with the heads of the stage and with its time unit. The stage cannot see how a bias was
made: a bias kept from an earlier call, or built from another batch of the same shape, is taken without
a word; under another unit its how-often count would cover rows that the rule of the stage keeps apart;
and a bias whose entries on open pairs were worked out from later rows would carry those rows in. A
bias [B, 1, T, T] serves every head alike. A stage built with time_bias=True takes no `bias` (it would
be a second time-gap bias), and says so.

What to change for the pod
--------------------------
The six PLACEHOLDER values below. CHANNEL_DIM is the width of a stage-1 token, so stage 1, the
tokenizer and the field tokens move to that width with it (48 today); NUM_CHANNELS is the number of
summary tokens of stage 1. TIME_UNITS_PER_SECOND must be the unit the mask of stage 2 is built with
today. describe(stage) prints the first and last real row of the latest call as dates in that unit, so
a unit that does not fit the times shows at a glance: nanoseconds read as seconds give a year in the
billions, seconds read as nanoseconds the year 1970. `num_fields` is the number F of field tokens per
transaction in the bank (7 field-level outputs of stage 1 today, 64 with a `PredictorBank`); it is
given when the bank is to carry a learned vector per field.

On a GPU in 16-bit numbers the fused attention kernels of PyTorch ask for a head width (d / heads)
that is a multiple of 8, and attention under a mask otherwise takes the plain, slower path. 96 with
8 heads gives 12; 96 with 12 heads (8 each) or 128 with 8 heads (16 each) meets it. The profiler of
one training step shows which kernel runs.

Memory grows with rows times keys. With `num_back` the bank of every row holds (1 + num_back) x F
keys and as many values, built once per batch and kept for the backward pass: with F = 7,
num_back = 5 and d = 96 about 16 MB per thousand rows each in 32-bit numbers, with F = 64 about
150 MB. When the GPU runs out of memory, the batch size or `num_back` goes down.

A bias with one value per head is laid out once per batch for every channel, since attention takes
one mask over channels and heads together: B x M x heads x T x T numbers, about 90 MB in 32-bit
numbers for 32 sequences of 121 rows with 6 channels and 8 heads. A bias [B, 1, T, T] needs no such
copy. On the CPU the fused attention kernel of PyTorch does not take a mask that needs a gradient,
so while a learned bias trains, the through-time blocks take the plain attention path.

This file runs from a flat folder next to interleaved_reread.py, attention_bias.py and masks.py, with
torch and numpy alone installed; inside the package it imports them from the package.

How to try it
-------------
    stage = LatentChannelStage(channel_dim=96, num_channels=6, num_back=5, num_fields=7)
    rows = stage(channels, fields, times, valid, row_extra=gap)   # channels [B, T, 6, 96] -> [B, T, 576]
    rows = stage(channels, fields, times, valid, row_extra=gap, bias=bias)   # bias [B, 8, T, T] or [B, 1, T, T]
    stage = LatentChannelStage(channel_dim=96, num_channels=6, time_bias=True)    # the time-gap bias, made inside
    stage = LatentChannelStage(channel_dim=96, num_channels=6, final_intra=True)   # one more field read at the end
    stage = LatentChannelStage(channel_dim=96, num_channels=6, intra_order="self_first")   # the first version's order
    stage = LatentChannelStage(num_back=5, ties="slot")           # rows of an earlier second taken by their slots
    exported = stage.last_channels                                # [B, T, 6, 96], the final channels
    print(describe(stage))                                        # every switch, the dates, the number of weights
    channels = ChannelPooler(channel_dim=96, num_channels=6)(fields)   # [B, T, F, 96] -> [B, T, 6, 96]
    python latent_channels.py                                     # the default stage on made-up rows
    python -m pytest -q additions/tests/test_model_latent_channels.py   # package only
"""
import datetime
import math

import torch
import torch.nn as nn
import torch.nn.functional as F

try:                                    # inside the package
    from .attention_bias import AttentionBias
    from .interleaved_reread import TIES, RecentFieldMemory, _unit, eligible_rows
except ImportError:
    try:                                # the package on the import path
        from additions.model.attention_bias import AttentionBias
        from additions.model.interleaved_reread import TIES, RecentFieldMemory, _unit, eligible_rows
    except ImportError:                 # the files side by side in one folder
        from attention_bias import AttentionBias
        from interleaved_reread import TIES, RecentFieldMemory, _unit, eligible_rows

# PLACEHOLDER: width d of one latent channel; it is the width of a stage-1 token, so stage 1 runs at it too.
CHANNEL_DIM = 96

# PLACEHOLDER: number M of latent channels per transaction; it is the number of summary tokens of stage 1.
NUM_CHANNELS = 6

# PLACEHOLDER: attention heads of every block of the stage; CHANNEL_DIM must be a multiple of it.
NUM_HEADS = 8

# PLACEHOLDER: number L of through-time blocks, each with a within-transaction block before it in the
# layout "interleaved"; today's stage 2 has 4 history layers.
NUM_PAIRS = 4

# PLACEHOLDER: the largest count of earlier rows the position table tells apart (120 for windows of up to
# 121 transactions); the table has HISTORY_LEN + 1 entries.
HISTORY_LEN = 120

# PLACEHOLDER: how many units of the batch's time values make one second: 1 when the builder writes whole
# seconds, 1_000_000_000 when it writes nanoseconds; it must be the unit of the mask of stage 2 today.
TIME_UNITS_PER_SECOND = 1

# The values the switches that take a name accept.
LAYOUTS = ("interleaved", "staged", "temporal_only")
READOUTS = ("concat", "attention", "mean")
INTRA_ORDERS = ("cross_first", "self_first")

# The mean length of a year of the calendar in seconds, to give the year of a time that no date can hold.
SECONDS_PER_YEAR = 31_556_952

# The largest size of an input number that the stage reads as it is. The layer norms square their inputs, and 1e15
# squared times any width below 1e8 stays inside the range of 32-bit numbers (about 3.4e38). A real row with a larger
# number in what the stage reads is set aside like a row whose inputs are not finite: from about 3e20 the statistics
# of a layer norm overflow, and attention then multiplies a weight of zero by a value that is not a number, which would
# reach every row of the sequence, the earlier ones included.
LARGEST_INPUT = 1e15


def _attention_start(in_proj, out_proj):
    """Start the projections of one attention the way nn.MultiheadAttention starts its own.

    The input projection is drawn uniformly at the scale that keeps the variance of its output
    close to that of its input, and both constant terms start at zero. Matching the standard
    layer keeps a stage of this file as easy to train as the stage 2 it replaces.
    """
    nn.init.xavier_uniform_(in_proj.weight)
    nn.init.zeros_(in_proj.bias)
    nn.init.zeros_(out_proj.bias)


def _for_channels(rule, num_channels, num_heads):
    """A float time rule with one value per head, laid out for channels folded next to the heads.

    rule           float [B, 1, T, T], [B, heads, T, T] or [B, C * heads, T, T]: minus infinity on
                   closed pairs and the bias on open ones
    num_channels   number C of channels that one attention call carries
    num_heads      heads of every channel

    Returns `rule` itself when it is [B, 1, T, T] (it reaches every channel and head by
    broadcasting) or already [B, C * heads, T, T]; otherwise [B, C * heads, T, T] with entry
    [b, c * heads + h] equal to the value of head h, for every channel c. That is the order in
    which ThroughTimeBlock folds the channels next to the heads.
    """
    if rule.shape[1] in (1, num_channels * num_heads):
        return rule
    # A copy per channel cannot be avoided: attention takes a mask broadcast over whole dimensions only, and
    # channels and heads share one dimension here. The stage makes this copy once per batch, not once per block.
    return rule.repeat(1, num_channels, 1, 1)


# ----------------------------------------------------------------------------------------------
# the two kinds of block
# ----------------------------------------------------------------------------------------------

class ThroughTimeBlock(nn.Module):
    """One pre-norm transformer layer through time, run on every channel as a sequence of its own.

    channel_dim     width d of a channel
    num_heads       attention heads; d must be a multiple of it
    ff_multiplier   the feed-forward layer is this many times as wide as a channel
    dropout         dropout on the attention weights, on both residual branches and inside the
                    feed-forward layer

    The arithmetic is that of nn.TransformerEncoderLayer(norm_first=True, batch_first=True,
    activation="gelu"). The parts carry its names (norm1, norm2, linear1, linear2), and the
    attention keeps its query, key and value side by side in `in_proj`, in the order that
    nn.MultiheadAttention packs them, so that the weights of a standard layer can be copied
    across one to one.
    """

    def __init__(self, channel_dim, num_heads, ff_multiplier=4, dropout=0.1):
        super().__init__()
        d = int(channel_dim)
        self.num_heads = int(num_heads)
        self.norm1 = nn.LayerNorm(d)
        self.in_proj = nn.Linear(d, 3 * d)
        self.out_proj = nn.Linear(d, d)
        self.norm2 = nn.LayerNorm(d)
        self.linear1 = nn.Linear(d, d * ff_multiplier)
        self.linear2 = nn.Linear(d * ff_multiplier, d)
        # Three dropouts as in the standard layer: inside the feed-forward layer and on each residual branch.
        self.dropout = nn.Dropout(dropout)
        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)
        self.attn_dropout = float(dropout)
        _attention_start(self.in_proj, self.out_proj)

    def forward(self, x, allowed):
        """Every channel reads the same channel of the rows its time rule lets it read.

        x         float [B, T, C, d]: C channels per row, each read through time on its own
        allowed   the time rule, in one of two forms. bool [B, 1, T, T]: entry [b, 0, i, j] is True
                  when row i may read row j; the same mask serves every channel and every head, so
                  it is built once per batch. Or float [B, 1, T, T], [B, heads, T, T] or
                  [B, C * heads, T, T]: the rule and an attention bias in one mask, minus infinity
                  where row i may not read row j and the bias where it may, added to the attention
                  logits of every channel alike (LatentChannelStage builds it once per batch)

        Returns float [B, T, C, d].
        """
        B, T, C, d = x.shape
        H = self.num_heads
        qkv = self.in_proj(self.norm1(x)).view(B, T, C, 3, H, d // H)
        # The channels are folded in next to the heads: [B, C * H, T, d / H]. Attention treats the heads as batch
        # dimensions too, so this is the fold of the channels into the batch: a channel with shared weights is
        # just more heads of one attention call and there is no Python loop over channels. Next to the heads,
        # the time mask [B, 1, T, T] reaches every channel and head by broadcasting, without a copy per channel.
        q, k, v = qkv.permute(3, 0, 2, 4, 1, 5).reshape(3, B, C * H, T, d // H).unbind(0)
        drop = self.attn_dropout if self.training else 0.0
        mask = allowed
        if allowed.dtype != torch.bool:
            # The float form carries a bias. It is laid out for the folded channels when it holds one value per
            # head, and it takes the number type of the logits, which attention asks for; in plain 32-bit numbers
            # with a mask the stage laid out already, both steps hand back the same tensor without a copy.
            mask = _for_channels(allowed, C, H).to(q.dtype)
        read = F.scaled_dot_product_attention(q, k, v, attn_mask=mask, dropout_p=drop)
        # Back to rows, channels and the heads side by side, the order in which nn.MultiheadAttention joins heads.
        read = read.reshape(B, C, H, T, d // H).permute(0, 3, 1, 2, 4).reshape(B, T, C, d)
        x = x + self.dropout1(self.out_proj(read))
        # The feed-forward layer works on every channel of every row by itself.
        return x + self.dropout2(self.linear2(self.dropout(F.gelu(self.linear1(self.norm2(x))))))


class WithinTransactionBlock(nn.Module):
    """One block inside a row: the channels read the bank and one another, then a feed-forward layer.

    channel_dim       width d of a channel
    num_heads         attention heads; d must be a multiple of it
    ff_multiplier     the feed-forward layer is this many times as wide as a channel
    dropout           dropout on the attention weights, on every residual branch and inside the
                      feed-forward layer
    self_attention    the M channels of one row attend to one another (in both directions)
    cross_attention   the channels read the bank of field tokens
    intra_order       "cross_first": the channels read the bank, then one another, then the
                      feed-forward layer, as Figure 4 of the Large Payments Model draws it;
                      "self_first": one another first, then the bank (the first version of this file)

    Each part normalises its input first and adds its result to what came in. A row is worked on by
    itself: nothing here reads another row, except the fields of earlier rows that the bank holds.
    With both attention parts off the block is its feed-forward layer alone, which works on every
    channel by itself, so the channels then stay apart. The weights are made in the same order
    whatever `intra_order` says (the part that reads the channels, the part that reads the bank, the
    feed-forward layer), so two blocks built with the same seed hold the same weights in either
    order and differ only in the order of the calls.
    """

    def __init__(self, channel_dim, num_heads, ff_multiplier=4, dropout=0.1, self_attention=True,
                 cross_attention=True, intra_order="cross_first"):
        super().__init__()
        if intra_order not in INTRA_ORDERS:
            raise ValueError(f"intra_order must be one of {INTRA_ORDERS}; got {intra_order!r}")
        d = int(channel_dim)
        self.num_heads = int(num_heads)
        self.intra_order = intra_order
        self.attn_dropout = float(dropout)
        # One dropout module serves all three branches; it holds no state, so sharing it changes nothing.
        self.drop = nn.Dropout(dropout)
        self.norm_self = self.self_in = self.self_out = None
        if self_attention:
            self.norm_self = nn.LayerNorm(d)
            self.self_in = nn.Linear(d, 3 * d)
            self.self_out = nn.Linear(d, d)
            _attention_start(self.self_in, self.self_out)
        self.norm_cross = self.cross_query = self.cross_out = None
        if cross_attention:
            # Only the question and the way back are the block's own. The keys and values of the bank are made
            # once per batch by the stage and read by every block, which keeps a read of the bank in every
            # block close to the cost of one (the design of interleaved_reread.py).
            self.norm_cross = nn.LayerNorm(d)
            self.cross_query = nn.Linear(d, d)
            self.cross_out = nn.Linear(d, d)
            _attention_start(self.cross_query, self.cross_out)
        self.norm_ff = nn.LayerNorm(d)
        self.feed_forward = nn.Sequential(nn.Linear(d, d * ff_multiplier), nn.GELU(), nn.Dropout(dropout),
                                          nn.Linear(d * ff_multiplier, d))

    def forward(self, z, keys=None, values=None, allowed=None):
        """The channels of every row after one block.

        z        float [N, M, d]: the M channels of N rows (every slot of a batch, side by side)
        keys     float [N, heads, P, d / heads]: the bank of every row, P places, split into heads;
                 needed when the block reads the bank
        values   float [N, heads, P, d / heads]: the values of the same places
        allowed  None, or bool [N, 1, 1, P]: True on the places that hold something

        Returns float [N, M, d].
        """
        drop = self.attn_dropout if self.training else 0.0
        if self.intra_order == "cross_first":
            # Figure 4 of the paper: what the fields hold comes in first, and the channels then share it.
            z = self._read_bank(z, keys, values, allowed, drop)
            z = self._read_one_another(z, drop)
        else:
            # The order of the first version: the channels share what they hold, then read the fields.
            z = self._read_one_another(z, drop)
            z = self._read_bank(z, keys, values, allowed, drop)
        return z + self.drop(self.feed_forward(self.norm_ff(z)))

    def _read_one_another(self, z, drop):
        """The channels of every row after they read one another; `z` itself when the part is off."""
        if self.self_in is None:
            return z
        N, M, d = z.shape
        H = self.num_heads
        # Every channel reads every channel of its own row, itself included; there is no order among them.
        q, k, v = self.self_in(self.norm_self(z)).view(N, M, 3, H, d // H).permute(2, 0, 3, 1, 4).unbind(0)
        read = F.scaled_dot_product_attention(q, k, v, dropout_p=drop)
        return z + self.drop(self.self_out(read.transpose(1, 2).reshape(N, M, d)))

    def _read_bank(self, z, keys, values, allowed, drop):
        """The channels of every row after they read the row's bank; `z` itself when the part is off."""
        if self.cross_query is None:
            return z
        if keys is None:
            raise ValueError("this block reads the bank of field tokens: pass its keys and values, or build "
                             "the block with cross_attention=False")
        N, M, d = z.shape
        H = self.num_heads
        q = self.cross_query(self.norm_cross(z)).view(N, M, H, d // H).transpose(1, 2)
        # The bank is brought to the number type of the question, which matters only in mixed precision.
        read = F.scaled_dot_product_attention(q, keys.to(q.dtype), values.to(q.dtype), attn_mask=allowed,
                                              dropout_p=drop)
        return z + self.drop(self.cross_out(read.transpose(1, 2).reshape(N, M, d)))


# ----------------------------------------------------------------------------------------------
# the stage
# ----------------------------------------------------------------------------------------------

class LatentChannelStage(nn.Module):
    """Stage 2 over M latent channels per transaction, joined only at the end.

    channel_dim            width d of a channel; None reads CHANNEL_DIM
    num_channels           number M of channels per transaction; None reads NUM_CHANNELS
    num_heads              attention heads of every block; None reads NUM_HEADS
    num_pairs              number L of through-time blocks; None reads NUM_PAIRS
    layout                 "interleaved": every pair is a within-transaction block, then a through-time
                           block (Eq. 8 of the paper); "staged": all through-time blocks first, one
                           within-transaction block at the end; "temporal_only": no within-transaction
                           block at all
    channel_identity       a learned vector per channel, added once at the start, so that shared
                           through-time weights know which channel they carry
    channel_projections    a learned map per channel applied once at the start; it starts as the
                           identity, so switching it on changes nothing at first
    share_temporal         True: one through-time layer per pair serves every channel; False: one per
                           channel
    intra_self_attention   the channels of one transaction attend to one another
    intra_cross_attention  the channels read the transaction's field tokens (the bank)
    num_back               the bank also holds the fields of the row's latest eligible earlier rows,
                           at most `num_back` of them (the memory of interleaved_reread.py); 0 keeps the
                           row's own fields only
    num_fields             fields F per transaction; a number gives the bank a learned vector per field,
                           None or 0 leaves that vector out
    readout                "concat": the M channels joined side by side (delayed concatenation), then a
                           layer norm; "attention": a learned task query reads the M channels of the row;
                           "mean": the average channel
    out_dim                width of the row representation; None keeps M * d for "concat" and d otherwise,
                           a number adds a linear map to that width
    history_len            the position table has history_len + 1 entries; None reads HISTORY_LEN
    ff_multiplier          the feed-forward layers are this many times as wide as a channel
    dropout                dropout on the attention weights, on every residual branch and inside the
                           feed-forward layers
    units_per_second       how many units of the batch's times make one second; None reads
                           TIME_UNITS_PER_SECOND when the stage is built. A whole number is kept as an
                           int (1e9 becomes 1_000_000_000), so integer times divide exactly
    final_intra            one more within-transaction block (weights of its own, the same two attention
                           switches) after the last through-time block, just before the readout, so that
                           the last update through time can read the fields again. In the layout "staged"
                           it follows the block that layout ends with; in "temporal_only" it is the only
                           one, which gives the blocks of "staged". False, the default, adds nothing.
                           final_intra takes the place of the model's re-read after stage 2; keep only
                           one of the two
    ties                   how the memory takes the rows of an earlier second, as in latest_prior_rows of
                           interleaved_reread.py. "whole_seconds", the default: the latest earlier whole
                           seconds, all rows of a second or none, while the total stays at or below
                           `num_back`, so the slot order inside a second changes nothing beyond rounding.
                           A burst ends the memory: a second with more rows than `num_back` is never
                           held by a later row, and neither is any row before it. With num_back 5, a
                           burst of 8 rows in one second leaves the five rows after it holding 0, 1, 2, 3
                           and 4 earlier rows, where "slot" holds 5 each; on the made-up batch
                           make_batch(0) of best_model_template.py (16 x 121), 343 of 1,409 real rows
                           hold fewer, 4.50 against 4.82 on average. The cost on the label is not
                           measured; the MEMORY_SLOT arm of best_model_template.py measures it. "slot":
                           rows taken by their slots, the rule of the re-read models of 24 November,
                           under which a score depends on the order of the rows inside an earlier second
    time_bias              True: the stage owns an AttentionBias(num_fields=0, num_heads, units_per_second)
                           of attention_bias.py, made after every other weight, and every call builds the
                           time-gap bias from its own times. It starts at zero, so switching it on changes
                           nothing until it learns. A `bias` handed to such a stage stops with a plain error
    intra_order            "cross_first", the default: inside every within-transaction block the channels
                           read the fields, then one another (Figure 4 of the paper); "self_first": the
                           order of the first version. The weights are made in the same order either way

    `settings` holds every switch with the value it was built with; `describe` prints them.
    `out_dim` is the width of the row representation the stage returns. `last_bias` says whether
    the latest call had an attention bias and in which layout, and `last_times` holds the times of
    its first and last real row; `describe` prints both.
    """

    def __init__(self, channel_dim=None, num_channels=None, num_heads=None, num_pairs=None, layout="interleaved",
                 channel_identity=True, channel_projections=False, share_temporal=True, intra_self_attention=True,
                 intra_cross_attention=True, num_back=0, num_fields=None, readout="concat", out_dim=None,
                 history_len=None, ff_multiplier=4, dropout=0.1, units_per_second=None, final_intra=False,
                 ties="whole_seconds", time_bias=False, intra_order="cross_first"):
        super().__init__()
        d = self.channel_dim = CHANNEL_DIM if channel_dim is None else int(channel_dim)
        M = self.num_channels = NUM_CHANNELS if num_channels is None else int(num_channels)
        H = self.num_heads = NUM_HEADS if num_heads is None else int(num_heads)
        L = self.num_pairs = NUM_PAIRS if num_pairs is None else int(num_pairs)
        history_len = HISTORY_LEN if history_len is None else int(history_len)
        # The unit is fixed when the stage is built and handed to the memory and to the time bias as a number, so that
        # the mask of the stage, the memory and the bias always use one unit, whatever the constants of the other files
        # say. The rule of masks.py keeps a whole number as an int (1e9 included), so integer times divide exactly here
        # and wherever a caller hands `stage.units_per_second` on.
        units = _unit(TIME_UNITS_PER_SECOND if units_per_second is None else units_per_second)
        if layout not in LAYOUTS:
            raise ValueError(f"layout must be one of {LAYOUTS}; got {layout!r}")
        if readout not in READOUTS:
            raise ValueError(f"readout must be one of {READOUTS}; got {readout!r}")
        if ties not in TIES:
            raise ValueError(f"ties must be one of {TIES}; got {ties!r}")
        if intra_order not in INTRA_ORDERS:
            raise ValueError(f"intra_order must be one of {INTRA_ORDERS}; got {intra_order!r}")
        if d % H:
            raise ValueError(f"channel_dim ({d}) must be a multiple of num_heads ({H}); change one of the two")
        if int(num_back) < 0:
            raise ValueError(f"num_back counts earlier rows and cannot be negative; got {num_back}")
        self.layout, self.readout = layout, readout
        self.share_temporal = bool(share_temporal)
        self.units_per_second = units
        self.num_fields = int(num_fields) if num_fields else 0
        self.attn_dropout = float(dropout)
        self.ties, self.intra_order = ties, intra_order

        # The position of a row: the count of its eligible earlier rows, one table for every channel.
        self.position = nn.Embedding(history_len + 1, d)
        # One small random vector per channel, so that shared through-time weights can treat channels apart.
        self.identity = None
        if channel_identity:
            self.identity = nn.Parameter(torch.zeros(M, d))
            nn.init.normal_(self.identity, std=0.02)
        # One map per channel, written as plain tensors that start as the identity and zero. They draw no random
        # numbers, so a stage built with the same seed has the same other weights with this switch on or off.
        self.projection_weight = self.projection_bias = None
        if channel_projections:
            self.projection_weight = nn.Parameter(torch.eye(d).repeat(M, 1, 1))
            self.projection_bias = nn.Parameter(torch.zeros(M, d))

        # How many within-transaction blocks each layout has, and whether any of them reads the bank.
        n_within = {"interleaved": L, "staged": 1, "temporal_only": 0}[layout]
        reads_bank = bool(intra_cross_attention) and n_within > 0
        # The order of the two attention parts is a setting of the calls only; the weights are made alike.
        self.within = nn.ModuleList([WithinTransactionBlock(d, H, ff_multiplier, dropout, bool(intra_self_attention),
                                                            reads_bank, intra_order) for _ in range(n_within)])
        if self.share_temporal:
            self.through_time = nn.ModuleList([ThroughTimeBlock(d, H, ff_multiplier, dropout) for _ in range(L)])
        else:
            # One layer per channel and pair; the forward pass loops over the channels in this case only.
            self.through_time = nn.ModuleList([nn.ModuleList([ThroughTimeBlock(d, H, ff_multiplier, dropout)
                                                              for _ in range(M)]) for _ in range(L)])
        # The bank of field tokens: the row's own fields and, with `num_back`, those of its latest eligible earlier
        # rows, normalised and projected once per batch. It is the memory of interleaved_reread.py, so that the
        # rows it gathers follow the one time rule of the package.
        self.bank = None
        if reads_bank:
            self.bank = RecentFieldMemory(field_dim=d, num_back=int(num_back), units_per_second=units,
                                          num_fields=self.num_fields, ties=ties)

        # The readout: how the M final channels of a row become one representation.
        natural = M * d if readout == "concat" else d
        self.out_norm = nn.LayerNorm(M * d) if readout == "concat" else None
        self.read_query = self.read_norm = self.read_kv = self.read_out = None
        if readout == "attention":
            # A learned question in the space of the keys; it starts small, so the first read is close to an average.
            self.read_query = nn.Parameter(torch.zeros(d))
            nn.init.normal_(self.read_query, std=0.02)
            self.read_norm = nn.LayerNorm(d)
            self.read_kv = nn.Linear(d, 2 * d)
            self.read_out = nn.Linear(d, d)
        self.to_out = None if out_dim is None else nn.Linear(natural, int(out_dim))
        self.out_dim = natural if out_dim is None else int(out_dim)

        # The final within-transaction block is made after every other weight, so that a stage built with the same
        # seed has the same other weights with `final_intra` on or off, and a run with the block can be compared
        # with a run without it from the same start.
        self.final_within = None
        if final_intra:
            self.final_within = WithinTransactionBlock(d, H, ff_multiplier, dropout, bool(intra_self_attention),
                                                       bool(intra_cross_attention), intra_order)
            if self.bank is None and intra_cross_attention:
                # In the layout "temporal_only" this block is the only one that reads the fields, so the bank is
                # made here, after every other weight as well, for the same reason.
                self.bank = RecentFieldMemory(field_dim=d, num_back=int(num_back), units_per_second=units,
                                              num_fields=self.num_fields, ties=ties)

        # The time-gap bias of the stage comes last of all, for the same reason: with the same seed every other
        # weight is the one of a stage without it. Its weights start at zero, so the bias is zero at first, and
        # it is built with the heads and the unit of the stage, so its rule is the rule of the stage.
        self.time_bias = None
        if time_bias:
            self.time_bias = AttentionBias(num_fields=0, num_heads=H, units_per_second=units)

        # The order in which the blocks run, as (kind, number) pairs; Eq. 8 of the paper is the first layout.
        if layout == "interleaved":
            self.order = tuple(step for n in range(L) for step in (("within", n), ("time", n)))
        elif layout == "staged":
            self.order = tuple(("time", n) for n in range(L)) + (("within", 0),)
        else:
            self.order = tuple(("time", n) for n in range(L))
        if final_intra:
            # The extra block runs after everything the layout runs, so the last through-time block comes before it.
            self.order = self.order + (("final", 0),)
        self.settings = {
            "layout": layout, "channel_dim": d, "num_channels": M, "num_heads": H, "num_pairs": L,
            "channel_identity": bool(channel_identity), "channel_projections": bool(channel_projections),
            "share_temporal": self.share_temporal, "intra_self_attention": bool(intra_self_attention),
            "intra_cross_attention": bool(intra_cross_attention), "intra_order": intra_order,
            "final_intra": bool(final_intra), "time_bias": bool(time_bias), "num_back": int(num_back), "ties": ties,
            "num_fields": num_fields, "readout": readout, "out_dim": self.out_dim, "history_len": history_len,
            "ff_multiplier": ff_multiplier, "dropout": dropout, "units_per_second": units,
        }
        # The final channels of the latest call, [B, T, M, d], detached; kept for export, not a weight.
        self.last_channels = None
        # Whether the latest call had an attention bias, in words for `describe`; plain bookkeeping, not a weight.
        self.last_bias = "no call yet"
        # The times of the first and the last real row of the latest call, as two numbers kept on the device of the
        # batch (no pause to read them); `describe` reads them as dates. Plain bookkeeping, not a weight.
        self.last_times = None

    def forward(self, channels, fields=None, times=None, valid=None, row_extra=None, bias=None):
        """One representation per row, from the M channels of the row and of its eligible earlier rows.

        channels    float [B, T, M, d]: the M channels of every slot (the stage-1 summary outputs kept
                    apart). A joined vector [B, T, M * d] is split with .view(B, T, M, d) only when it
                    is the M summary outputs side by side in channel-major order with nothing applied
                    after the join; otherwise the summary outputs are handed over from before the join
        fields      float [B, T, F, d]: the field tokens of every slot; needed when the stage reads the
                    bank (intra_cross_attention on and at least one within-transaction block)
        times       integer or 64-bit float [B, T]: the time of every slot (any value on padding), in
                    the unit of the stage; 32-bit or 16-bit float times stop with a plain error, since
                    they cannot hold the second of a time of today
        valid       bool [B, T]: True on real rows; None means every slot is a real row
        row_extra   None, or float [B, T, d]: added to every channel of a row at the start (the
                    time-gap encoding of the caller, for example)
        bias        None, or float [B, heads, T, T] or [B, 1, T, T], heads being `num_heads`: added
                    to the attention logits of every through-time block, the same for every channel.
                    Entry [b, h, i, j] goes to row i reading row j in head h, which is the layout of
                    AttentionBias in attention_bias.py (see "Where it goes" at the top of this file).
                    It must be built from this batch in this call. The time rule still decides which
                    pairs exist: a pair it closes stays closed whatever the bias holds there, and a
                    bias of zero gives the result without one. A stage built with time_bias=True
                    makes its own and takes none here

        Returns float [B, T, out_dim]. The final channels [B, T, M, d] are kept, detached, in
        `self.last_channels` for export.

        A row's result depends on the row itself and on its eligible earlier rows only: the real rows
        of the same sequence in strictly earlier whole seconds. Rows of one second never see each
        other, and changing a later row never moves an earlier row's result. The same batch with the
        later slots marked as padding gives the earlier rows bit for bit; a window cut after a row, or
        scored in groups, gives them to rounding (about 1e-6), since the arithmetic then runs over
        another length. A padded slot reads only itself; its inputs are set to zero before anything
        reads them, so whatever it holds (a value that is not a number included) reaches no real row,
        and its own result stays finite and means nothing. A real row whose inputs hold a value that is
        not a finite number, or one larger in size than LARGEST_INPUT (1e15), is set aside the same way:
        its result, and the result of every row that may read it, is not a number, and every other row
        keeps its result bit for bit. With a bias this holds as long as the bias keeps the same rule, as
        the one of attention_bias.py does when it is built from the same batch with the time unit of the
        stage: the stage keeps every closed pair closed, but it cannot see what the bias of an open pair
        was made from.
        """
        B, T, M, d = self._check(channels, fields, times, valid, row_extra, bias)
        valid = torch.ones(B, T, dtype=torch.bool, device=channels.device) if valid is None else valid.bool()
        padded = ~valid
        # A real row whose inputs are not all finite numbers is set aside like a padded slot: attention multiplies
        # every value by its weight, and a weight of zero times a value that is not a number is still not a number,
        # so such a row would reach every row of its sequence, the earlier ones included. A row with a number larger in
        # size than LARGEST_INPUT is set aside too: its numbers could overflow a layer norm, which then gives values
        # that are not numbers in the same way. Its result is marked below.
        broken = self._broken(channels, fields, row_extra, valid)
        quiet = padded | broken
        # Padded slots (and set-aside rows) are set to zero first, before anything reads them.
        z = channels.masked_fill(quiet[:, :, None, None], 0.0)
        # The time rule, built once per batch and used by every through-time block and every channel.
        eligible = eligible_rows(times, valid, self.units_per_second)                     # [B, T, T]
        allowed = (eligible | torch.eye(T, dtype=torch.bool, device=eligible.device)).unsqueeze(1)
        # The position counts the eligible earlier rows, so rows of one second share it and a padded slot gets 0.
        # Rows with more earlier rows than the table has entries share its last entry.
        n_earlier = eligible.sum(dim=-1).clamp(max=self.position.num_embeddings - 1)
        # The first and the last real time of this call, for `describe`; two reductions, no pause.
        self.last_times = self._first_and_last(times, valid)
        if self.projection_weight is not None:
            # Channel m is mapped by its own matrix: out[..., m, o] = sum_i z[..., m, i] W[m, o, i] + b[m, o].
            z = torch.einsum("btmi,moi->btmo", z, self.projection_weight) + self.projection_bias
        if self.identity is not None:
            z = z + self.identity
        start = self.position(n_earlier)                                                  # [B, T, d]
        if row_extra is not None:
            start = start + row_extra.masked_fill(quiet.unsqueeze(-1), 0.0)
        # What belongs to the row as a whole (its position, the caller's extra) is added to every channel.
        z = z + start.unsqueeze(2)

        if self.time_bias is not None:
            # The stage's own time-gap bias, from the times of this very call, with the heads and the unit of the stage.
            # No match field: an empty tensor of codes leaves the time-gap part alone.
            no_codes = torch.zeros(B, T, 0, dtype=torch.long, device=times.device)
            bias = self.time_bias(no_codes, times, valid)                                  # [B, heads, T, T]
        # The rule every through-time block takes: the yes/no rule as before, or with a bias the rule and the bias
        # in one float mask. Both are made once per batch; for shared through-time layers the float mask is also
        # laid out for every channel once here, so that no block copies it again.
        rule = allowed
        if bias is not None:
            rule = self._biased_rule(allowed, bias, valid, channels.dtype)
            if self.share_temporal:
                rule = _for_channels(rule, M, self.num_heads)
        # What the latest call had, in words; `describe` shows it, so that a run with a bias is listed as one.
        if self.time_bias is not None:
            self.last_bias = f"[B, {self.num_heads}, T, T] built by the stage from the times of the latest call"
        else:
            self.last_bias = ("not given in the latest call" if bias is None else
                              f"[{'B' if bias.shape[0] == B else bias.shape[0]}, {bias.shape[1]}, T, T] in the latest "
                              f"call")

        keys = values = places = None
        if self.bank is not None:
            keys, values, places = self._bank(fields, times, valid, quiet)
        for kind, number in self.order:
            if kind == "time" and self.share_temporal:
                z = self.through_time[number](z, rule)
            elif kind == "time":
                # A layer of its own for every channel; each channel is read through time by its layer alone. A
                # layer sees one channel at a time, so a bias with one value per head fits it as it is.
                z = torch.cat([layer(z[:, :, m:m + 1], rule) for m, layer in enumerate(self.through_time[number])],
                              dim=2)
            else:
                # A row at a time: the slots of the batch are laid side by side, which is a view, not a copy. The
                # block of `final_intra` ("final") runs the same way, after the last through-time block.
                block = self.within[number] if kind == "within" else self.final_within
                z = block(z.reshape(B * T, M, d), keys, values, places).reshape(B, T, M, d)
        # A set-aside row, and every row that may read it, has no result that means anything; it is marked as not a
        # number, as it would have been without the setting aside. Every other row keeps its numbers to the bit.
        tainted = broken | (eligible & broken.unsqueeze(1)).any(dim=-1)
        z = z.masked_fill(tainted[:, :, None, None], float("nan"))
        self.last_channels = z.detach()
        return self._read(z)

    def _biased_rule(self, allowed, bias, valid, dtype):
        """The time rule and the attention bias in one float mask, made once per batch.

        allowed   bool [B, 1, T, T]: the time rule, the row itself included
        bias      float [B or 1, heads or 1, T, T], as `forward` takes it
        valid     bool [B, T]: True on real rows
        dtype     the number type of the channels, which the mask takes

        Returns float [B, heads or 1, T, T]: the bias on every pair the rule opens, minus infinity
        on every other pair.
        """
        # The bias row of a padded slot is set to zero. Such a slot reads only itself, so its result is then the
        # one without a bias, and it stays finite whatever the bias holds on padding.
        bias = torch.where(valid[:, None, :, None], bias.to(dtype), 0.0)
        # A choice, not a sum: a closed pair gets minus infinity whatever the bias holds there (an infinite value or
        # one that is not a number included), so the bias changes how much a row reads of what it may read and
        # never what it may read. Attention turns the yes/no rule into zero and minus infinity in the same way, so
        # a bias of zero gives the numbers of the call without a bias.
        return torch.where(allowed, bias, float("-inf"))

    def _broken(self, channels, fields, row_extra, valid):
        """bool [B, T]: the real rows with an input that is not a finite number or is larger in size than LARGEST_INPUT.

        The inputs that count are those the stage reads: the channels, the fields when the stage
        reads the bank, and `row_extra`. Padded slots are never counted; they are set aside anyway.
        """
        def unfit(x):
            # Per slot, True when a number of x is not finite or is larger in size than LARGEST_INPUT; x is [B, T, ...].
            x = x.flatten(2)
            return (~torch.isfinite(x) | (x.abs() > LARGEST_INPUT)).any(dim=-1)

        bad = unfit(channels)
        if fields is not None and self.bank is not None:
            bad = bad | unfit(fields)
        if row_extra is not None:
            bad = bad | unfit(row_extra)
        return bad & valid

    @staticmethod
    def _first_and_last(times, valid):
        """The time of the earliest and of the latest real row, as two detached numbers on the batch's device.

        A call without a real row gives the largest number first and the smallest last, which
        `describe` reads as "no real row". The two reductions need no pause of the device.
        """
        # A yes/no tensor in place of the times (the two arguments swapped) is read as numbers, so that nothing stops.
        t = times.long() if times.dtype == torch.bool else times
        if t.is_floating_point():
            high, low = float("inf"), float("-inf")
        else:
            info = torch.iinfo(t.dtype)
            high, low = info.max, info.min
        return (torch.where(valid, t, high).amin().detach(), torch.where(valid, t, low).amax().detach())

    def _check(self, channels, fields, times, valid, row_extra, bias=None):
        """The sizes B, T, M, d of the batch, after a plain error for any input whose shape cannot work."""
        if channels.dim() != 4:
            raise ValueError(f"channels must be [B, T, M, d]; got shape {tuple(channels.shape)}. A joined summary "
                             f"vector [B, T, M * d] is split with .view(B, T, M, d) only when it is the M summary "
                             f"outputs side by side in channel-major order (the d numbers of output 0, then those of "
                             f"output 1, ...) with nothing applied after the join; otherwise hand over the summary "
                             f"outputs from before the join")
        B, T, M, d = channels.shape
        if (M, d) != (self.num_channels, self.channel_dim):
            raise ValueError(f"the stage was built for {self.num_channels} channels of width {self.channel_dim}, but "
                             f"the channels are [B, T, {M}, {d}]; build it with num_channels={M} and channel_dim={d}, "
                             f"or bring the channels to that shape")
        if times is None or tuple(times.shape) != (B, T):
            got = None if times is None else tuple(times.shape)
            raise ValueError(f"times must be integer (or 64-bit float) [B, T] = [{B}, {T}], the time of every slot, "
                             f"since the time rule is built from them; got {got}")
        if valid is not None and tuple(valid.shape) != (B, T):
            raise ValueError(f"valid must be bool [B, T] = [{B}, {T}], True on real rows; got {tuple(valid.shape)}")
        if row_extra is not None and tuple(row_extra.shape) != (B, T, d):
            raise ValueError(f"row_extra must be [B, T, d] = [{B}, {T}, {d}]; got {tuple(row_extra.shape)}. A "
                             f"time-gap column is brought to width d by a linear layer of the caller")
        if bias is not None and self.time_bias is not None:
            raise ValueError("this stage was built with time_bias=True and makes its own time-gap bias from the times "
                             "of every call; pass bias=None, or build the stage with time_bias=False to hand in a "
                             "bias made outside (one that needs match codes, built from this batch in this call)")
        if bias is not None:
            H = self.num_heads
            shape = tuple(bias.shape)
            # One number per head (or one for every head) and per pair of rows; a batch dimension of 1 is taken too,
            # since it reaches every sequence by broadcasting.
            fits = (torch.is_floating_point(bias) and bias.dim() == 4 and shape[0] in (1, B) and shape[1] in (1, H)
                    and shape[2:] == (T, T))
            if not fits:
                raise ValueError(f"bias must be float [B, heads, T, T] = [{B}, {H}, {T}, {T}] or [{B}, 1, {T}, {T}], "
                                 f"one number per pair of rows for the attention logits of the through-time blocks; "
                                 f"got {bias.dtype} {shape}. AttentionBias of attention_bias.py built with "
                                 f"num_heads={H} gives that layout, and a bias [B, T, T] for every head is passed as "
                                 f"bias.unsqueeze(1)")
        if self.bank is not None:
            if fields is None:
                raise ValueError("this stage reads the field tokens (intra_cross_attention is on): pass fields "
                                 "[B, T, F, d], or build the stage with intra_cross_attention=False")
            if fields.dim() != 4 or tuple(fields.shape[:2]) != (B, T) or fields.shape[-1] != d:
                raise ValueError(f"fields must be [B, T, F, d] = [{B}, {T}, F, {d}]; got {tuple(fields.shape)}. "
                                 f"Field tokens of another width are brought to width d by a linear layer of the "
                                 f"caller")
            if self.num_fields and fields.shape[2] != self.num_fields:
                raise ValueError(f"the stage was built with num_fields={self.num_fields}, but the fields hold "
                                 f"{fields.shape[2]} per row; build it with num_fields={fields.shape[2]} (or 0 to "
                                 f"leave the learned vector per field out)")
        return B, T, M, d

    def _bank(self, fields, times, valid, quiet):
        """The keys and values of every row's bank split into heads, and the mask of its places, once per batch.

        quiet   bool [B, T]: the padded slots and the set-aside rows, whose fields are set to zero first

        Returns (keys, values, allowed): keys and values float [B * T, heads, P, d / heads] with
        P = (1 + num_back) x F, and allowed None (every place holds something) or bool
        [B * T, 1, 1, P], False on the places of an earlier row that the memory does not hold. Those
        places hold zeros, never another row.
        """
        B, T = valid.shape
        d, H = self.channel_dim, self.num_heads
        # The memory sets padded fields to zero as well; doing it here keeps the promise of this stage by itself, and
        # sets aside the fields of a row whose inputs are not all finite numbers or hold one larger than LARGEST_INPUT.
        fields = fields.masked_fill(quiet[:, :, None, None], 0.0)
        keys, values, missing, _ = self.bank(fields, times, valid)                         # [B, T, P, d]
        n_places = keys.shape[2]
        # Split into heads here, once, instead of in every block that reads the bank.
        keys = keys.reshape(B * T, n_places, H, d // H).transpose(1, 2)
        values = values.reshape(B * T, n_places, H, d // H).transpose(1, 2)
        # The row's own fields are always there, so no row is left without a place to read.
        allowed = None if missing is None else ~missing.reshape(B * T, 1, 1, n_places)
        return keys, values, allowed

    def _read(self, z):
        """The representation of every row from its M final channels: joined, read by a task query, or averaged."""
        B, T, M, d = z.shape
        if self.readout == "concat":
            # The channels side by side, then one layer norm over the whole row: delayed concatenation.
            out = self.out_norm(z.reshape(B, T, M * d))
        elif self.readout == "mean":
            # No norm here: with one channel the stage is then exactly a plain stack of standard layers.
            out = z.mean(dim=2)
        else:
            H = self.num_heads
            k, v = self.read_kv(self.read_norm(z)).view(B * T, M, 2, H, d // H).permute(2, 0, 3, 1, 4).unbind(0)
            # The same learned question for every row; the answer is a weighted mix of the row's own channels.
            q = self.read_query.to(k.dtype).view(1, H, 1, d // H).expand(B * T, H, 1, d // H)
            drop = self.attn_dropout if self.training else 0.0
            read = F.scaled_dot_product_attention(q, k, v, dropout_p=drop)               # [B * T, H, 1, d / H]
            out = self.read_out(read.reshape(B, T, d))
        return out if self.to_out is None else self.to_out(out)


# ----------------------------------------------------------------------------------------------
# channels for a stage 1 without summary tokens
# ----------------------------------------------------------------------------------------------

class ChannelPooler(nn.Module):
    """M learned queries read the field tokens of one transaction: [..., F, d] -> [..., M, d].

    channel_dim     width d of a field token and of a channel; None reads CHANNEL_DIM
    num_channels    number M of channels to make; None reads NUM_CHANNELS
    num_heads       attention heads; None reads NUM_HEADS
    ff_multiplier   the feed-forward layer is this many times as wide as a channel
    dropout         dropout on the attention weights, on both residual branches and inside the
                    feed-forward layer

    It is Pool_in of the paper for a model whose stage 1 has no summary tokens. Every channel
    starts as a learned vector, reads the transaction's field tokens once and goes through a
    feed-forward layer; each part has its own residual. Every transaction is handled by itself,
    so the time rule has nothing to guard here.
    """

    def __init__(self, channel_dim=None, num_channels=None, num_heads=None, ff_multiplier=4, dropout=0.1):
        super().__init__()
        d = self.channel_dim = CHANNEL_DIM if channel_dim is None else int(channel_dim)
        self.num_channels = NUM_CHANNELS if num_channels is None else int(num_channels)
        self.num_heads = NUM_HEADS if num_heads is None else int(num_heads)
        if d % self.num_heads:
            raise ValueError(f"channel_dim ({d}) must be a multiple of num_heads ({self.num_heads})")
        # Each channel starts from its own small random vector, which is what lets the channels grow apart.
        self.queries = nn.Parameter(torch.zeros(self.num_channels, d))
        nn.init.normal_(self.queries, std=0.02)
        self.norm_queries = nn.LayerNorm(d)
        self.norm_fields = nn.LayerNorm(d)
        self.query = nn.Linear(d, d)
        self.key_value = nn.Linear(d, 2 * d)
        self.out = nn.Linear(d, d)
        self.norm_ff = nn.LayerNorm(d)
        self.feed_forward = nn.Sequential(nn.Linear(d, d * ff_multiplier), nn.GELU(), nn.Dropout(dropout),
                                          nn.Linear(d * ff_multiplier, d))
        self.drop = nn.Dropout(dropout)
        self.attn_dropout = float(dropout)

    def forward(self, fields):
        """The M channels of every transaction.

        fields   float [..., F, d]: the field tokens of every transaction; the leading dimensions are
                 free, usually [B, T]

        Returns float [..., M, d]. A transaction's channels depend on its own fields only.
        """
        lead = fields.shape[:-2]
        n_fields, d = fields.shape[-2:]
        if d != self.channel_dim:
            raise ValueError(f"the field tokens are {d} wide, but the pooler was built for {self.channel_dim}; "
                             f"build it with channel_dim={d}")
        H, M = self.num_heads, self.num_channels
        x = fields.reshape(-1, n_fields, d)
        N = x.shape[0]
        k, v = self.key_value(self.norm_fields(x)).view(N, n_fields, 2, H, d // H).permute(2, 0, 3, 1, 4).unbind(0)
        # The questions are the same for every transaction, so they are worked out once and shared by all.
        q = self.query(self.norm_queries(self.queries)).to(k.dtype).view(M, H, d // H).transpose(0, 1)
        drop = self.attn_dropout if self.training else 0.0
        read = F.scaled_dot_product_attention(q.unsqueeze(0).expand(N, H, M, d // H), k, v, dropout_p=drop)
        z = self.queries + self.drop(self.out(read.transpose(1, 2).reshape(N, M, d)))
        z = z + self.drop(self.feed_forward(self.norm_ff(z)))
        return z.reshape(*lead, M, d)


# ----------------------------------------------------------------------------------------------
# counting and describing
# ----------------------------------------------------------------------------------------------

def count_weights(module):
    """The number of weights of `module`: every number in its parameters, a shared parameter counted once."""
    return sum(weight.numel() for weight in module.parameters())


def _unused(settings):
    """The switches that have no effect in a setting, each with the reason, for `describe`.

    Two notes are not about a switch without effect: `final_intra` on in the layouts "staged" and
    "temporal_only", where the block it adds meets a block of the layout or stands in for one.
    """
    notes = {}
    layout, final = settings["layout"], settings.get("final_intra", False)
    # Within-transaction blocks of the stage: those of the layout and the one `final_intra` adds.
    n_within = {"interleaved": settings["num_pairs"], "staged": 1, "temporal_only": 0}[layout] + int(final)
    read_self, read_bank = settings["intra_self_attention"], settings["intra_cross_attention"]
    if n_within == 0:
        for name in ("intra_self_attention", "intra_cross_attention", "intra_order", "num_back", "ties", "num_fields"):
            notes[name] = "unused: the layout has no within-transaction block"
    else:
        if not read_bank:
            for name in ("num_back", "ties", "num_fields"):
                notes[name] = "unused: nothing reads the field tokens"
        elif not settings["num_back"]:
            # Said so that a run with these settings is not listed as a test of the rule for rows of one second.
            notes["ties"] = "unused: the bank holds the row's own fields only (num_back is 0)"
        if not (read_self and read_bank):
            notes["intra_order"] = "unused: a within-transaction block has one attention part or none"
    # Said so that a run listed with these settings is read as what it is, not as a setting of its own.
    if final and layout == "staged":
        notes["final_intra"] = "on: a second within-transaction block follows the one the layout ends with"
    elif final and layout == "temporal_only":
        notes["final_intra"] = "on: the only within-transaction block, so the blocks are those of layout staged"
    if not settings["channel_identity"] and settings["share_temporal"] and settings["num_channels"] > 1:
        # Not an error: the channels still differ by their content, but the shared layers cannot tell them apart.
        notes["channel_identity"] = "off: the shared through-time layers see every channel alike"
    return notes


def _date(value, unit):
    """A time of a batch read as a date in UTC with `unit` units per second; the year alone when no date holds it."""
    try:
        # Whole numbers divide exactly; a float time or unit divides in floats and floors, as the time rule does.
        seconds = value // unit if isinstance(value, int) and isinstance(unit, int) else math.floor(value / unit)
        return datetime.datetime.fromtimestamp(seconds, tz=datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    except (OverflowError, OSError, ValueError):
        # Past the years a date can hold (1 to 9999): the year alone says how far off the unit is.
        if value != value:
            return "not a number"
        if math.isinf(value):
            return "infinite"
        return f"year {1970 + value / unit / SECONDS_PER_YEAR:,.0f}"


def _times_line(stage, settings):
    """The first and last real row of the latest call, read as dates with the stage's unit, for `describe`."""
    first_last = getattr(stage, "last_times", None)
    if first_last is None:
        return "no call yet"
    first, last = (number.item() for number in first_last)
    if first > last:
        return "no real row in the latest call"
    unit = settings["units_per_second"]
    return (f"{_date(first, unit)} to {_date(last, unit)}   (first and last real row at {unit} units per second; "
            f"the year 1970 or a year far from today says the unit does not fit the times)")


def describe(stage):
    """One line per switch of `stage` with its value, the times of the latest call, the weights, as one string.

    A switch that has no effect in the stage's setting says so, with the reason, so that a run
    listed with that switch is not taken for a run that tested it. The attention bias is an
    argument of `forward`, not a switch of the stage, so its line says what the latest call had
    and which layout `forward` takes. The times line reads the first and the last real row of the
    latest call as dates in UTC with the stage's unit, so a unit that does not fit the times shows
    at a glance (the year 1970, or a year in the millions or billions). A module without switches
    gets its name and its number of weights.
    """
    settings = getattr(stage, "settings", None)
    if settings is None:
        return f"{type(stage).__name__}\n  {'weights':<23} {count_weights(stage):,}"
    notes = _unused(settings)
    head = (f"{type(stage).__name__}: {settings['num_channels']} channels of {settings['channel_dim']}, "
            f"{settings['num_pairs']} through-time blocks, layout {settings['layout']}")
    lines = [head]
    for name, value in settings.items():
        note = f"   ({notes[name]})" if name in notes else ""
        lines.append(f"  {name:<23} {value}{note}")
    # The bias adds no weight to the stage beyond the few of time_bias; the line is there so that a run with a bias
    # is listed as one.
    used = getattr(stage, "last_bias", "no call yet")
    takes = (f"forward takes [B, {settings['num_heads']}, T, T] or [B, 1, T, T] for the through-time blocks"
             if not settings.get("time_bias") else "time_bias is on: the stage builds it, forward takes none")
    lines.append(f"  {'bias (forward)':<23} {used}   ({takes})")
    lines.append(f"  {'times (latest call)':<23} {_times_line(stage, settings)}")
    lines.append(f"  {'weights':<23} {count_weights(stage):,}")
    return "\n".join(lines)


# ----------------------------------------------------------------------------------------------
# a look at the default stage
# ----------------------------------------------------------------------------------------------

def _demo():
    """Builds the default stage with a memory and its own time bias, runs it on made-up rows and prints what it is."""
    torch.manual_seed(0)
    n_fields = 7
    stage = LatentChannelStage(num_back=5, num_fields=n_fields, time_bias=True).eval()
    # Two sequences in whole seconds of November 2026: ties in time in the first, three padded slots at the end of
    # the second.
    start = 1_795_000_000
    times = start + torch.tensor([[0, 5, 5, 9, 20, 20, 21, 40, 41], [3, 3, 4, 8, 9, 12, 0, 0, 0]])
    valid = torch.tensor([[True] * 9, [True] * 6 + [False] * 3])
    times = times.masked_fill(~valid, 0)
    B, T = times.shape
    channels = torch.randn(B, T, stage.num_channels, stage.channel_dim)
    fields = torch.randn(B, T, n_fields, stage.channel_dim)
    with torch.no_grad():
        rows = stage(channels, fields, times, valid)
    print(describe(stage))
    print(f"rows {tuple(rows.shape)}, final channels {tuple(stage.last_channels.shape)}, "
          f"finite: {bool(torch.isfinite(rows).all())}")


if __name__ == "__main__":
    _demo()
