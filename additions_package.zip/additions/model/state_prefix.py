"""A stored account memory as extra positions in front of the history.

What this file does
-------------------
It connects stage 2 to a memory of the account that reaches further back than the
sequence. The memory is a set of faded sums: for several half-lives (an hour, six hours, a
day, a week, a month) the sum of the account's earlier transaction vectors, each halved for
every half-life of age, together with the faded count of those rows.

    account_state    builds that memory for every row from stored transaction vectors
    state_features   turns sums and counts into what the network reads: the mean vector per
                     half-life, with the logarithm of the count appended
    StatePrefix      projects those features to the width of stage 2, one position per half-life

The positions are put in front of the rows of a sequence. They hold the state as of the
first row of the sequence, and every row may read them.

Why it exists
-------------
A sequence holds a limited number of rows. Whatever the account did before the first row
of its sequence is invisible to stage 2, and the first rows of a sequence have almost no
history at all. Yet the question that separates a fraud from an unusual purchase is
usually "is this like the account?", and that needs the account's habits over weeks, not
its last few rows. Frauds come in runs on one account, so the short half-lives matter as
well: a run that began before the sequence was cut is still in the hour and six-hour sums
when the next sequence starts.

Faded sums are a memory of fixed size, however long the account has existed. They can be
kept as a running state: multiply by the fading since the last update, add the new vector.
The same arithmetic therefore serves training, scoring and a production store. No label is
involved anywhere. A downstream tree model gains a per-account vector at every time scale
that can be read at any moment, which the per-row vector cannot offer.

Where it goes
-------------
Stage 1 vectors of a frozen first model are stored for every row (exports); `account_state`
turns them into the state (after the model); the state as of the first row of each sequence
travels with the batch; `StatePrefix` makes the positions; stage 2 takes them as `prefix`
(history_stage.py, masks.with_prefix). In the original code the positions would be added in
`FTTransformerHierModel.forward` in front of the transaction vectors, and the builder of the
all-position sequences would deliver sums and counts per sequence.

What to change for the pod
--------------------------
`HALF_LIVES` below must be the half-lives the stored state was built with. `MIN_COUNT` is
the faded count below which a time scale is treated as empty. The vectors must come from a
model whose stage 1 no longer changes: once stage 1 is trained further, every stored state
is out of date and has to be built again. The count tells how much history an account has.
The evaluation files start one month before the scored month, so a scored row has between
one and two months of history, while training files reach back further; the state should be
built with the same look-back in both (`month_blocks` in additions/features/lookback.py
cuts a long table into pieces shaped like an evaluation file), or the counts at the long
half-lives would mark the month. `settings.EMBED_DIM` is the default width on both sides.

How to try it
-------------
    sums, counts = account_state(accounts, secs, vectors)       # [rows, 5, d], [rows, 5]
    first = row_index[:, 0]                                      # the first row of every sequence
    prefix = StatePrefix(vector_dim=d, out_dim=144)(torch.as_tensor(sums[first]).float(),
                                                    torch.as_tensor(counts[first]).float())
    history = stage2(vectors_in, batch["time_seq"], batch["mask"], prefix=prefix)
    python -m pytest -q additions/tests/test_model_state_prefix.py
"""
import numpy as np
import torch
import torch.nn as nn

from additions.common.history import EarlierRows
from additions.model._shared import pick

# PLACEHOLDER: the half-lives of the stored state, in seconds; they must be the ones the state was built with.
HALF_LIVES = (3_600, 6 * 3_600, 86_400, 7 * 86_400, 30 * 86_400)

# A time scale whose faded count is below this is treated as empty: its mean would be the quotient of
# two numbers that are both nearly zero.
MIN_COUNT = 1e-6


def account_state(accounts, secs, vectors, half_lives=None):
    """The faded memory of every account, as of every row.

    accounts     one integer per row; rows with the same integer are one account [rows]
    secs         whole seconds of every row [rows]
    vectors      one stored vector per row, from a frozen stage 1 [rows, d]
    half_lives   lengths in seconds; None reads HALF_LIVES

    Returns (sums, counts): float64 [rows, H, d] and float64 [rows, H], with H half-lives.
    sums[r, h] is the sum of the vectors of the account's rows in strictly earlier seconds
    than row r, each halved for every half-life h of age; counts[r, h] is the same sum with
    1 in place of the vector.

    Time rule: the state of a row holds strictly earlier seconds only. Rows of the row's own
    second are not in it, and the row itself never is. The state handed to a sequence is the
    state of its first row, which is therefore older than every row of the sequence.
    """
    # A single half-life given as a plain number is treated as a list of one, so the shapes stay [rows, H, ...].
    half_lives = [float(h) for h in np.atleast_1d(HALF_LIVES if half_lives is None else half_lives)]
    earlier = EarlierRows(accounts, secs)
    sums = earlier.decayed_sum(np.asarray(vectors, dtype=np.float64), half_lives)
    counts = earlier.decayed_sum(np.ones(len(np.asarray(secs))), half_lives)
    return sums, counts


def state_features(sums, counts, min_count=None):
    """What the network reads from a stored state.

    sums     float [..., H, d], a tensor or a numpy array
    counts   float [..., H], a tensor or a numpy array

    Returns a float tensor [..., H, d + 1]: the mean vector of each half-life, then log(1 + count).

    Dividing the sum by the count gives a mean, and the mean does not depend on the moment
    the state is read: as time passes, sum and count fade by the same factor. That is what
    lets the last row of a sequence read a state that was taken at the first row. How much
    history there is, and how fresh it is, is told separately by the logarithm of the count.
    A time scale with a count below `min_count` gives zeros.
    """
    min_count = MIN_COUNT if min_count is None else min_count
    # Arrays straight from `account_state` are accepted as well as tensors.
    sums, counts = torch.as_tensor(sums), torch.as_tensor(counts)
    has_history = counts > min_count
    mean = sums / counts.clamp(min=min_count).unsqueeze(-1)
    mean = torch.where(has_history.unsqueeze(-1), mean, torch.zeros_like(mean))
    amount = torch.where(has_history, torch.log1p(counts), torch.zeros_like(counts))
    return torch.cat([mean, amount.unsqueeze(-1)], dim=-1)


class StatePrefix(nn.Module):
    """Turns a stored account state into positions that stage 2 can read.

    vector_dim   width d of the stored vectors; None reads settings.EMBED_DIM
    out_dim      width of stage 2; None reads settings.EMBED_DIM
    num_states   number H of half-lives; None reads len(HALF_LIVES)
    """

    def __init__(self, vector_dim=None, out_dim=None, num_states=None):
        super().__init__()
        vector_dim, out_dim = pick(vector_dim, "EMBED_DIM"), pick(out_dim, "EMBED_DIM")
        num_states = len(HALF_LIVES) if num_states is None else num_states
        # One projection for all half-lives: a mean vector means the same thing at every time scale.
        self.project = nn.Linear(vector_dim + 1, out_dim)
        # One learned vector per half-life tells the positions apart, as a position embedding would.
        self.scale = nn.Parameter(torch.zeros(num_states, out_dim))
        nn.init.normal_(self.scale, std=0.02)

    def forward(self, sums, counts):
        """Positions for the front of a sequence.

        sums     float [B, H, d]: the faded sums as of the first row of each sequence
        counts   float [B, H]: the faded counts at the same moment

        Returns float [B, H, out_dim], ready to be the `prefix` of HistoryStage. An account
        without earlier rows reads zero features, so it gives the bias of the projection plus
        the learned vector of each time scale.
        """
        return self.project(state_features(sums, counts)) + self.scale
