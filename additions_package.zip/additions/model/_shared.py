"""Small helpers shared by the model blocks of this folder.

What this file does
-------------------
It holds what several blocks of `additions/model/` need:

    pick                   a model size read from settings.py at the moment of the call
    encoder_stack          a stack of standard transformer blocks, the same recipe as the original model
    run_blocks             runs such a stack with a mask that is ADDED to the attention logits
    sequences_from_table   turns a table of transactions into the padded batch the blocks take
    layout                 puts any other per-row array into the same [B, T] layout

Why it exists
-------------
Stage 1, stage 2 and the profile encoder are built from the same kind of block. Writing the
recipe once keeps the blocks of this folder equal to their counterparts in the original
model, so that one of them can replace its counterpart without any other change in behaviour.

`run_blocks` exists because of one trap. nn.TransformerEncoder has a quick route, taken in
evaluation mode when no gradients are recorded, which is exactly how a model is scored. On
that route a float mask is not added to the attention logits. It is read as yes/no: every
entry that is not zero hides its key. A mask that holds only zero and minus infinity gives
the same result either way. A learned bias does not: it would shape attention during
training and hide keys during scoring, and no error would say so. `run_blocks` writes the
attention of each block out, so the mask is added in training and in scoring alike.

The batch builder exists because no real data ships with this package. Every block still
needs sequences to run on, with the properties that matter for the time rule: whole
accounts, several rows in one second, padding, and sequences that are cut only between two
seconds.

Where it goes
-------------
Nowhere by itself. The blocks import the first three helpers. The batch builder stands in
for the sequence builder of the real pipeline (`SequenceBuilder` in the original code, with
its all-position layout of disjoint sequences) in the tests and in the demo of
reference_model.py only.

What to change for the pod
--------------------------
`settings.EMBED_DIM`, `NUM_HEADS`, `STAGE1_BLOCKS`, `STAGE2_BLOCKS` and `HISTORY_LEN` are the
defaults that `pick` hands to the blocks. `encoder_stack` must stay equal to the block
recipe of the model in use (pre-norm, GELU, feed-forward width of four times the block
width). `sequences_from_table` is for made-up rows: the real pipeline keeps its own builder
and its frozen preprocessing.

How to try it
-------------
    batch, row_index, cardinalities = sequences_from_table(synthetic.make_transactions(50))
    stack = encoder_stack(width=48, num_heads=8, num_blocks=4)
    out = run_blocks(stack, x, mask)                # x [B, L, 48], mask [B * 8, L, L]
    python -m pytest -q additions/tests/test_model_history_stage.py additions/tests/test_model_attention_bias.py
"""
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F

try:                                    # inside the package
    from .. import settings
    from ..common import timekeys
    from ..common.history import EarlierRows
    from ..common.timekeys import MISSING_SECOND
except ImportError:
    try:                                # the package on the import path
        from additions import settings
        from additions.common import timekeys
        from additions.common.history import EarlierRows
        from additions.common.timekeys import MISSING_SECOND
    except ImportError:                 # the files side by side in one folder
        import settings
        import timekeys
        from history import EarlierRows
        from timekeys import MISSING_SECOND


def pick(value, setting_name):
    """`value` when it is given, otherwise what settings.py holds under `setting_name`.

    The setting is read when the function runs, not when the module is imported, so an edit
    of settings.py (or a value set by a test) is seen by every block built afterwards.
    """
    return getattr(settings, setting_name) if value is None else value


# ----------------------------------------------------------------------------------------------
# transformer blocks
# ----------------------------------------------------------------------------------------------

def encoder_stack(width, num_heads, num_blocks, ff_multiplier=4, dropout=0.1, attn_dropout=0.1):
    """`num_blocks` standard transformer blocks of the given width, or None for zero blocks.

    width          size of every position's vector
    num_heads      attention heads; `width` must be a multiple of it
    ff_multiplier  the feed-forward layer inside a block is this many times as wide as the block
    dropout        dropout on the two residual branches and inside the feed-forward layer
    attn_dropout   dropout on the attention weights

    Each block normalises before attention and before the feed-forward layer (pre-norm) and
    uses GELU, exactly as the two stages of the original model do. The result is an
    nn.TransformerEncoder that maps [N, L, width] to [N, L, width].
    """
    if num_blocks <= 0:
        return None
    block = nn.TransformerEncoderLayer(d_model=width, nhead=num_heads, dim_feedforward=width * ff_multiplier,
                                       dropout=dropout, activation="gelu", batch_first=True, norm_first=True)
    # The attention dropout is a setting of its own. It is set on the one block before the stack copies it.
    block.self_attn.dropout = attn_dropout
    # The nested-tensor shortcut only pays for padding masks, which this package never passes.
    return nn.TransformerEncoder(block, num_layers=num_blocks, enable_nested_tensor=False)


def _self_attention(attention, x, mask=None):
    """Self-attention with the weights of an nn.MultiheadAttention, written out.

    attention   the `self_attn` of one block
    x           float [B, L, width], already normalised
    mask        None or float [B * heads, L, L]; it is added to the attention logits
    Returns float [B, L, width].
    """
    B, L, W = x.shape
    H = attention.num_heads
    # One linear layer gives query, key and value side by side; each is then cut into its heads.
    q, k, v = F.linear(x, attention.in_proj_weight, attention.in_proj_bias).view(B, L, 3, H, W // H).permute(2, 0, 3, 1, 4)
    if mask is not None:
        mask = mask.view(B, H, L, L)                 # rows b * H .. b * H + H - 1 are the heads of sequence b
    drop = attention.dropout if attention.training else 0.0
    # A float mask is added to the logits before the softmax. That is the documented behaviour of this
    # function, in training and in scoring.
    out = F.scaled_dot_product_attention(q, k, v, attn_mask=mask, dropout_p=drop)      # [B, H, L, W / H]
    return attention.out_proj(out.transpose(1, 2).reshape(B, L, W))


def run_blocks(stack, x, mask=None, after_block=None, first_number=1):
    """Run a stack from `encoder_stack` block by block, with `mask` added to the attention logits.

    stack          the result of `encoder_stack`; None runs nothing and returns `x`
    x              float [B, L, width]
    mask           None, or float [B * heads, L, L] as masks.to_attention_mask returns it, with or
                   without a learned bias added to it
    after_block    None, or a function called as after_block(number, x) after every block; what it
                   returns goes into the next block (interleaved_reread.py puts a re-read there)
    first_number   the number `after_block` is given for the first block of this stack; 1 unless a
                   layer of another kind ran before the stack
    Returns float [B, L, width].

    The arithmetic is that of `stack(x, mask=mask)` on its ordinary route. The difference is
    that there is no second route here: see the module docstring for what the quick route of
    nn.TransformerEncoder does to a float mask whose entries are not all zero or minus infinity.
    """
    if stack is None:
        return x
    for number, block in enumerate(stack.layers, start=first_number):
        # First half of a block: every position reads the positions its mask row leaves open.
        x = x + block.dropout1(_self_attention(block.self_attn, block.norm1(x), mask))
        # Second half: a small feed-forward network on every position by itself.
        x = x + block.dropout2(block.linear2(block.dropout(block.activation(block.linear1(block.norm2(x))))))
        if after_block is not None:
            x = after_block(number, x)
    return x if stack.norm is None else stack.norm(x)


# ----------------------------------------------------------------------------------------------
# batches from a table (tests and demo)
# ----------------------------------------------------------------------------------------------

def _present(df, names, what):
    """The names that are columns of `df`; the others are named in one printed line."""
    found = [c for c in names if c is not None and c in df.columns]
    skipped = [c for c in names if c is not None and c not in df.columns]
    if skipped:
        print(f"note: the table has no column(s) {skipped}; they are left out of the {what}")
    return found


def sequences_from_table(df, numeric_cols=None, code_cols=None, account_col=None, time_col=None, label_col=None,
                         positive_label=None, seconds_per_sequence=None):
    """Padded sequences of one table, in the layout the blocks of this folder take.

    df                    whole accounts, one row per transaction, in any order
    numeric_cols          numeric inputs; None reads settings.NUMERIC_COLS
    code_cols             code inputs; None reads settings.CODE_COLS
    account_col, time_col, label_col, positive_label   None reads them from settings
    seconds_per_sequence  distinct seconds one sequence may hold; None means settings.HISTORY_LEN + 1

    Returns (batch, row_index, cardinalities):
      batch["continuous"]    float32 [B, T, C]: the numeric inputs, then the time gap as the last column
      batch["categorical"]   int64 [B, T, K]: one small integer per code input, 0 for "no value"
      batch["mask"]          bool [B, T]: True on real rows; real rows come first, padding after them
      batch["time_seq"]      int64 [B, T]: whole seconds, 0 on padding
      batch["target_seq"]    int64 [B, T]: 1 fraud, 0 not, -100 on padding; a target, never an input
      row_index              int64 numpy [B, T]: the row of `df` that sits in each slot, -1 on padding
      cardinalities          list of K table sizes for the code inputs

    Sequences are disjoint: every row sits in exactly one. An account's rows are sorted by
    time and cut into sequences only between two seconds, so rows of one second are never
    split and a sequence can hold more rows than seconds. The time gap of a row is
    log(1 + seconds since the latest strictly earlier second of its sequence), 0 when there
    is none; rows of one second share it, so it says nothing about how they are ordered.
    """
    account_col, time_col = pick(account_col, "ACCOUNT_COL"), pick(time_col, "TIME_COL")
    label_col, positive_label = pick(label_col, "LABEL_COL"), pick(positive_label, "POSITIVE_LABEL")
    per = pick(seconds_per_sequence, "HISTORY_LEN") + 1 if seconds_per_sequence is None else int(seconds_per_sequence)
    numeric_cols = _present(df, pick(numeric_cols, "NUMERIC_COLS"), "numeric inputs")
    code_cols = _present(df, pick(code_cols, "CODE_COLS"), "code inputs")

    account = timekeys.codes(df[account_col])
    secs = timekeys.seconds(df[time_col])
    rows = np.flatnonzero(secs != MISSING_SECOND)                 # a row without a time cannot be placed
    order = rows[timekeys.stable_order(account[rows], secs[rows])]
    a, s = account[order], secs[order]
    n = len(order)

    # Number the distinct seconds of each account 0, 1, 2, ... and start a new sequence every `per`
    # of them. Cutting by seconds, not by rows, keeps rows of one second together.
    first_of_account = np.r_[True, a[1:] != a[:-1]]
    new_second = first_of_account | np.r_[True, s[1:] != s[:-1]]
    second_no = np.cumsum(new_second) - 1
    second_in_account = second_no - np.maximum.accumulate(np.where(first_of_account, second_no, 0))
    part = second_in_account // per
    first_of_sequence = first_of_account | np.r_[False, part[1:] != part[:-1]]
    sequence = np.cumsum(first_of_sequence) - 1                   # which sequence each row sits in
    slot = np.arange(n) - np.maximum.accumulate(np.where(first_of_sequence, np.arange(n), 0))
    B, T = int(sequence[-1]) + 1, int(slot.max()) + 1
    row_index = np.full((B, T), -1, dtype=np.int64)
    row_index[sequence, slot] = order

    # PLACEHOLDER: the real pipeline applies its frozen preprocessing here; this stand-in takes a signed
    # logarithm and then scales every numeric column with the mean and spread of the table itself.
    continuous = np.zeros((B, T, len(numeric_cols) + 1), dtype=np.float32)
    for c, name in enumerate(numeric_cols):
        x = pd.to_numeric(df[name], errors="coerce").to_numpy(dtype=np.float64)
        x = np.sign(x) * np.log1p(np.abs(x))
        spread = np.nanstd(x)
        x = (x - np.nanmean(x)) / (spread if spread > 0 else 1.0)
        continuous[sequence, slot, c] = np.nan_to_num(x[order], nan=0.0)
    # The time gap, from the history engine keyed by sequence: seconds since the latest strictly earlier row.
    gap = EarlierRows(sequence, s).seconds_since_last()
    continuous[sequence, slot, -1] = np.log1p(np.nan_to_num(gap, nan=0.0))

    categorical = np.zeros((B, T, len(code_cols)), dtype=np.int64)
    cardinalities = []
    for k, name in enumerate(code_cols):
        codes, distinct = pd.factorize(df[name])                  # -1 marks a missing value
        categorical[sequence, slot, k] = codes[order] + 1         # 0 is kept for "no value" and for padding
        cardinalities.append(len(distinct) + 1)

    target = (df[label_col].to_numpy() == positive_label).astype(np.int64)
    batch = {
        "continuous": torch.from_numpy(continuous),
        "categorical": torch.from_numpy(categorical),
        "mask": torch.from_numpy(row_index >= 0),
        "time_seq": layout(secs, row_index, fill=0),
        "target_seq": layout(target, row_index, fill=-100),
    }
    return batch, row_index, cardinalities


def layout(values, row_index, fill=0):
    """A per-row array put into the layout of a batch.

    values      array [rows, ...] aligned with the table the batch was built from
    row_index   int [B, T] from `sequences_from_table` (-1 on padding)
    fill        the value written on padding
    Returns a tensor [B, T, ...] of the same number type as `values`.
    """
    values = np.asarray(values)
    out = values[np.maximum(row_index, 0)]
    out[row_index < 0] = fill
    return torch.from_numpy(out)
