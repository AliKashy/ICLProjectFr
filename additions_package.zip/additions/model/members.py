"""Several members inside one model: shared stage 2, own scaling vector, own head.

What this file does
-------------------
`Members` turns one two-stage model into a small committee without training several
models. Stage 1 runs once. Every member then gets its own copy of the transaction vectors,
multiplied by a scaling vector that only that member has, and all copies go through the
same stage 2 with the same weights. Every member has its own head. The model's logits are
the average of the members' logits, and the spread across members is returned as well.

    Members.expand    [B, T, D] vectors -> [B * M, T, D], one scaled copy per member
    Members.repeat    repeats any other per-sequence tensor M times to match
    Members.combine   [B * M, T, W] stage-2 outputs -> averaged logits, spread, each member's logits
    member_loss       the training loss: every member is fitted by itself, then the losses are averaged

Why it exists
-------------
The alert budget is a fixed small share of rows, so what counts is the order of the rows
near the cut. Two trainings of the same model that differ only in their random start agree
on most rows and disagree on some of the rows around the cut, and that disagreement is
noise: neither run is right about it. Averaging several runs removes part of the noise,
but several models cost several times the training and the scoring. Members get part of
the effect for much less: stage 1, where most of the arithmetic is spent, runs once, and
the members share every weight of stage 2.

The members would be copies of each other if they started alike. The scaling vector is what
makes them differ: each member reads the transaction vector with its own signs, so the
shared weights have to serve several views of the same history at once. Training each member
on its own loss (and not the averaged logit) keeps them from leaning on each other.

The spread is worth exporting. A row on which the members disagree is a row the model is
unsure about, which is a different thing from a row with a middling score. A downstream
tree model can use it as a column of its own.

Where it goes
-------------
Between stage 1 and stage 2 (`expand`), and at the head (`combine`); the loss changes with
it (`member_loss`). In the original code: `expand` just before `txn_vec` gets its position
and enters `seq_encoder` in `FTTransformerHierModel.forward`, `combine` in place of
`self.head`, and `member_loss` in place of the cross-entropy in `_step`. Everything that is
per sequence (the mask, `time_seq`, a prefix, an attention bias) is repeated with `repeat`.

What to change for the pod
--------------------------
`NUM_MEMBERS` below. Stage 2 runs on M times as many sequences, so memory and time of
stage 2 grow with M while stage 1 is unchanged. A model with members is one file and one
forward pass; where a single production model is required, it should be confirmed that
such a model counts as one. An export that relied on the score being one direction of the
vector has M heads to deal with.

How to try it
-------------
    members = Members(input_dim=144, head_dim=144, num_members=4)
    x = members.expand(vectors)                                          # [B, T, 144] -> [B * 4, T, 144]
    h = stage2(x, members.repeat(batch["time_seq"]), members.repeat(batch["mask"]))
    logits, spread, each = members.combine(h)                            # [B, T, 2], [B, T], [B, 4, T, 2]
    loss = member_loss(each, batch["target_seq"], batch["mask"])
    python -m pytest -q additions/tests/test_model_members.py
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

# PLACEHOLDER: how many members the model holds when the caller does not say; 1 is the plain model.
NUM_MEMBERS = 4


class Members(nn.Module):
    """Members that share stage 2 and differ in a scaling vector and a head.

    input_dim     width D of the transaction vectors that enter stage 2
    head_dim      width W of what the head reads (the output of stage 2, or of what follows it)
    num_members   number M of members; None reads NUM_MEMBERS
    num_outputs   logits per row (2: not fraud, fraud)
    """

    def __init__(self, input_dim, head_dim, num_members=None, num_outputs=2):
        super().__init__()
        self.num_members = m = NUM_MEMBERS if num_members is None else int(num_members)
        # The first member keeps a scaling vector of ones, so a model with one member is exactly the plain
        # model. Every other member starts with random signs: +1 or -1 per coordinate. Signs (and not
        # small random numbers around one) make the members read the same vector in clearly different ways
        # from the first step, while leaving the size of every coordinate as it is.
        scale = torch.ones(m, input_dim)
        if m > 1:
            scale[1:] = torch.randint(0, 2, (m - 1, input_dim)).float() * 2.0 - 1.0
        self.scale = nn.Parameter(scale)
        self.heads = nn.ModuleList([nn.Linear(head_dim, num_outputs) for _ in range(m)])

    def expand(self, vectors):
        """One scaled copy of the transaction vectors per member.

        vectors   float [B, T, D]
        Returns float [B * M, T, D]. Rows b * M to b * M + M - 1 are the M members of sequence b.
        """
        B, T, D = vectors.shape
        return (vectors.unsqueeze(1) * self.scale.view(1, self.num_members, 1, D)).reshape(B * self.num_members, T, D)

    def repeat(self, tensor):
        """Any per-sequence tensor [B, ...] repeated for the members: [B * M, ...]. None stays None.

        The order matches `expand`: the M copies of sequence b sit next to each other.
        """
        return None if tensor is None else tensor.repeat_interleave(self.num_members, dim=0)

    def combine(self, hidden):
        """The members' heads, their average and their spread.

        hidden   float [B * M, T, W]: what the head reads, in the order `expand` made

        Returns (logits, spread, member_logits):
          logits          float [B, T, 2]: the average of the members' logits; this is the model's output
          spread          float [B, T]: the standard deviation across members of the fraud log-odds
                          (logit of "fraud" minus logit of "not fraud"); 0 with one member
          member_logits   float [B, M, T, 2]: each member's own logits, for the training loss
        """
        m = self.num_members
        hidden = hidden.reshape(hidden.shape[0] // m, m, *hidden.shape[1:])                # [B, M, T, W]
        # A plain loop: there are only a few members, and each head is an ordinary linear layer.
        member_logits = torch.stack([head(hidden[:, i]) for i, head in enumerate(self.heads)], dim=1)
        log_odds = member_logits[..., 1] - member_logits[..., 0]                           # [B, M, T]
        spread = log_odds.std(dim=1, unbiased=False)
        return member_logits.mean(dim=1), spread, member_logits


def member_loss(member_logits, targets, valid, class_weight=None):
    """The training loss with members: each member's own cross-entropy, averaged over the members.

    member_logits   float [B, M, T, 2] from `Members.combine`
    targets         int [B, T]: 1 fraud, 0 not; anything on padding
    valid           bool [B, T]: True on real rows; only these count
    class_weight    None, or float [2]: the weight of each class, as in the plain loss

    Returns a scalar: the sum of the weighted terms over real rows, divided by the number of
    real rows, averaged over the members.

    Each member is fitted to the labels by itself. If the loss were taken on the averaged
    logits instead, a member could leave rows to the others and the members would stop being
    separate opinions, which is what the average and the spread rely on.
    """
    logits = member_logits.transpose(1, 2)[valid]                                          # [rows, M, 2]
    labels = targets[valid]
    m = logits.shape[1]
    per_member = [F.cross_entropy(logits[:, i], labels, weight=class_weight, reduction="sum") for i in range(m)]
    return torch.stack(per_member).mean() / max(int(labels.numel()), 1)
