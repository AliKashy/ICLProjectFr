"""A learned bias on stage-2 attention: same value, time gap, how often.

What this file does
-------------------
`AttentionBias` computes, for every attention head and every pair of rows of a sequence, a
number that is added to the attention logit of row i reading row j, before the softmax.
The number is the sum of three learned parts:

    same value   per head and per field, a weight times "row i and row j carry the same value"
                 (the same merchant, the same merchant category, the same postal code, ...)
    time gap     per head, a weight for the bucket that the time from row j to row i falls into
    how often    per head and per field, a weight times log(1 + the number of rows that row i may
                 read and that carry row j's value)

Every weight starts at zero. The bias is then zero, and a model that gains this block
starts with exactly the attention it had. `match_values` makes, from the raw rows, the
integer codes whose equality is tested.

Why it exists
-------------
"Has this account been here before, and what happened then?" is one of the most telling
questions about a card transaction. Legitimate spending keeps returning to the same few
places; fraud happens where the account has never been, and inside a fraud run the same
merchant or the same kind of merchant is tried again and again within minutes.

Attention finds earlier rows by comparing vectors, and a transaction vector cannot hold an
exact merchant id: there are far too many merchants, and most occur a handful of times. So
stage 2 is good at "rows that look like this one" and poor at "the rows at exactly this
merchant". The same-value part hands it the exact match as a pointer. A head that follows
the pointer reads the content of those earlier rows with it: their amounts, how the card
was used, what the bank decided. No table over merchants is needed, so the match works for
a merchant that was never seen in training.

The other two parts mend what a softmax cannot do. It turns logits into shares that add up
to one, so three earlier visits and one earlier visit can produce the same reading; the
how-often part gives the count back. And nothing in a row's vector says how long ago the row
was relative to the row that reads it; the time-gap part lets a head prefer the last minutes
or the last weeks whatever the rows contain.

Where it goes
-------------
Raw files, then `match_values` (one integer per row and field, laid out like the batch),
then this block, then stage 2: history_stage.py takes the result as `bias` and adds it to
the float mask of masks.to_attention_mask. In the original code the codes would be carried
per row by `SequenceBuilder._encode_file` (raw values, compared before any vocabulary), and
the bias would be added in `FTTransformerHierModel.forward` to the mask that
`_build_causal_mask` returns. One trap sits exactly there: `seq_encoder(seq, mask=...)`
reads a float mask as yes/no when the model is scored, so a mask with a bias in it must be
run the way `run_blocks` in _shared.py runs it.

What to change for the pod
--------------------------
The match fields: `settings.MERCHANT_COL`, `MCC_COL`, `MERCHANT_POSTAL_COL`,
`MERCHANT_COUNTRY_COL` and the optional `CARD_COL`, `TERMINAL_COL` and `DEVICE_COL`, or pass
`fields={"short name": "column"}`. `settings.AMOUNT_COL` and `settings.TIME_COL` give the
two derived fields (amount band, hour of the week). `GAP_EDGES` below sets the time-gap
buckets and `settings.NUM_HEADS` the number of heads, which must be that of stage 2. The
block needs [B, fields, T, T] numbers per batch; with long sequences and many fields that
is the cost to watch.

How to try it
-------------
    values, names = match_values(df)                              # int [rows, F]; negative = no value
    block = AttentionBias(num_fields=len(names))
    bias = block(layout(values, row_index, fill=-1), batch["time_seq"], batch["mask"])    # [B, heads, T, T]
    history = stage2(vectors, batch["time_seq"], batch["mask"], bias=bias)
    python -m pytest -q additions/tests/test_model_attention_bias.py
"""
import numpy as np
import pandas as pd
import torch
import torch.nn as nn

from additions import settings
from additions.common import timekeys
from additions.common.timekeys import MISSING_SECOND
from additions.model import masks
from additions.model._shared import pick

# Edges of the time-gap buckets, in seconds: under a minute, under ten minutes, under an hour, under six
# hours, under a day, under three days, under a week, under two weeks, under thirty days, and longer.
GAP_EDGES = (60, 600, 3_600, 21_600, 86_400, 259_200, 604_800, 1_209_600, 2_592_000)


def default_match_fields():
    """The fields whose equality is tested, as {short name: column name read from settings.py}.

    A column name of None means the field is not available; `match_values` leaves it out.
    """
    return {"merchant": settings.MERCHANT_COL, "mcc": settings.MCC_COL, "postal": settings.MERCHANT_POSTAL_COL,
            "country": settings.MERCHANT_COUNTRY_COL, "card": settings.CARD_COL, "terminal": settings.TERMINAL_COL,
            "device": settings.DEVICE_COL}


def match_values(df, fields=None, amount_col=None, time_col=None, amount_band=True, hour_of_week=True):
    """Integer codes per row whose equality the bias tests.

    df            raw rows, one per transaction
    fields        {short name: column name}; None reads `default_match_fields`
    amount_col, time_col   None reads settings.AMOUNT_COL and settings.TIME_COL
    amount_band   add a field that is equal for amounts of the same size (each band is twice as wide
                  as the one before it)
    hour_of_week  add a field that is equal for rows in the same hour of the week

    Returns (values, names): int64 [rows, F] and the F field names in column order. Equal
    codes mean equal raw values; a negative code means "no value" and never matches, not even
    another missing value. Fields that are switched off or absent are left out, and one
    printed line names them.

    The codes are only ever compared inside one sequence, so it does not matter that two
    files may give the same merchant different numbers.
    """
    fields = default_match_fields() if fields is None else fields
    columns, names, skipped = [], [], []
    for name, col in fields.items():
        if not col or col not in df.columns:
            skipped.append(name)
            continue
        codes = timekeys.codes(df[col])
        codes[pd.isna(df[col]).to_numpy()] = -1          # two rows without a merchant were not at the same merchant
        columns.append(codes)
        names.append(name)
    if skipped:
        print(f"note: no column for the match field(s) {skipped}; they are left out of the attention bias")
    amount_col, time_col = pick(amount_col, "AMOUNT_COL"), pick(time_col, "TIME_COL")
    if amount_band and amount_col in df.columns:
        amount = pd.to_numeric(df[amount_col], errors="coerce").to_numpy(dtype=np.float64)
        band = np.floor(np.log2(1.0 + np.abs(np.nan_to_num(amount, nan=0.0))))       # under 1, 1-3, 3-7, 7-15, ...
        columns.append(np.where(np.isnan(amount), -1, band).astype(np.int64))
        names.append("amount_band")
    if hour_of_week and time_col in df.columns:
        secs = timekeys.seconds(df[time_col])
        known = secs != MISSING_SECOND
        columns.append(np.where(known, (np.where(known, secs, 0) // 3_600) % 168, -1).astype(np.int64))
        names.append("hour_of_week")
    values = np.stack(columns, axis=1) if columns else np.zeros((len(df), 0), dtype=np.int64)
    return values, names


class AttentionBias(nn.Module):
    """A zero-initialised bias for the attention of stage 2.

    num_fields        number F of match fields (the second dimension of `match_values`)
    num_heads         attention heads of stage 2; None reads settings.NUM_HEADS
    gap_edges         bucket edges for the time gap, in seconds; None reads GAP_EDGES
    units_per_second  unit of the times in the batch; None reads masks.TIME_UNITS_PER_SECOND

    The match path has its own few weights (heads times fields, twice, plus heads times
    buckets). They are separate from the embeddings that describe a row's content, so
    learning where to look cannot disturb what a row's vector says.
    """

    def __init__(self, num_fields, num_heads=None, gap_edges=None, units_per_second=None):
        super().__init__()
        heads = pick(num_heads, "NUM_HEADS")
        edges = GAP_EDGES if gap_edges is None else gap_edges
        self.units_per_second = units_per_second
        self.register_buffer("gap_edges", torch.tensor(edges, dtype=torch.int64))
        # All four start at zero: the bias is then exactly zero and the attention is the one without it.
        # The weights still get a gradient from the first step, because the gradient of a weight is the
        # quantity it multiplies (same or not, the log count), and that is not zero.
        self.same_weight = nn.Parameter(torch.zeros(heads, num_fields))       # on "the two rows share the value"
        self.count_weight = nn.Parameter(torch.zeros(heads, num_fields))      # on log(1 + readable rows sharing it)
        self.gap_weight = nn.Parameter(torch.zeros(heads, len(edges) + 1))    # one per time-gap bucket
        self.self_weight = nn.Parameter(torch.zeros(heads))                   # on a row reading itself

    def forward(self, values, times, valid):
        """The bias of every head for every pair of rows.

        values   int [B, T, F]: match codes per row; negative = no value (padding may hold anything)
        times    integer [B, T]: the time of every slot
        valid    bool [B, T]: True on real rows

        Returns float [B, heads, T, T]; entry [b, h, i, j] is added to the logit of row i
        reading row j in head h. Entries of pairs that may not read each other mean nothing:
        the mask closes those pairs whatever the bias says.

        Time rule: for a pair that may read each other (j in a strictly earlier second than
        i), every part is built from row i, row j and the rows i may read. The how-often count
        in particular covers only rows that i may read. A count over the whole sequence would
        tell row i how many later rows return to the same merchant.
        """
        allowed = masks.strict_visibility(times, valid, self.units_per_second)            # bool [B, T, T]
        itself = torch.eye(times.shape[1], dtype=torch.bool, device=times.device)
        readable = (allowed & ~itself).to(self.same_weight.dtype)                         # [B, T, T], i reads k

        # same[b, f, j, k]: rows j and k carry the same value of field f, and both have a value.
        codes = values.permute(0, 2, 1)                                                   # [B, F, T]
        has_value = codes >= 0
        same = (codes.unsqueeze(3) == codes.unsqueeze(2)) & has_value.unsqueeze(3) & has_value.unsqueeze(2)
        same = same.to(readable.dtype)                                                    # [B, F, T, T]

        # count[b, f, i, j]: among the rows that i may read, how many carry row j's value. Row j counts
        # itself when i may read it, so a readable row with a value has a count of at least one.
        count = readable.unsqueeze(1) @ same                                              # [B, F, T, T]

        # The time from row j to row i, in seconds, and the bucket it falls into.
        secs = masks.whole_seconds(times, self.units_per_second)
        gap = (secs.unsqueeze(2) - secs.unsqueeze(1)).clamp(min=0)                        # [B, T, T]
        bucket = torch.bucketize(gap, self.gap_edges, right=True)                         # 0 .. len(edges)

        bias = (torch.einsum("bfij,hf->bhij", same, self.same_weight)
                + torch.einsum("bfij,hf->bhij", torch.log1p(count), self.count_weight)
                + self.gap_weight[:, bucket].permute(1, 0, 2, 3))                         # [B, heads, T, T]
        # A row always carries its own values, so "same value" says nothing on the diagonal. A row reading
        # itself gets one weight of its own per head instead.
        return torch.where(itself, self.self_weight.view(1, -1, 1, 1), bias)
