"""Tables that carry what other accounts did at the same merchant.

burst_tables.py     merchant-by-hour tables: is this merchant under attack right now, seen through
                    OTHER accounts?
coverage.py         how merchant columns depend on the share of accounts sampled, and one model for
                    thin and full tables
covisit_vectors.py  merchant vectors learned from inside accounts, and how well a merchant fits the
                    account's habits
day_tables.py       merchant-by-day tables: what OTHER accounts did at this merchant yesterday, last
                    week, last month
exposure.py         compromise-point exposure: did this account recently shop where other accounts
                    later went bad?
heat.py             merchant heat: how the model's own scores ran on OTHER accounts' earlier rows at
                    this merchant
visa_view.py        the network's view of a merchant: the network risk score averaged over OTHER
                    accounts there
_panel.py           shared steps of the merchant tables: periods, adding tables, sums over other
                    accounts, priors
"""
