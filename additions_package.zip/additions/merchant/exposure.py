"""Compromise-point exposure: did this account recently shop where other accounts later went bad?

What this file does
-------------------
Step one, per file (`build_exposure_tables`): for every merchant and week, two kinds of record
are kept. A visitor record says that an account used the merchant in that week. A blame record
says that an account which used the merchant in that week later showed a bad outcome, and on
which day that outcome became known. Each bad account splits one unit of blame evenly over
the merchant-weeks it used in the days before its bad outcome, so an account that shopped in
ten places blames each of them by a tenth. Two definitions of "bad" are kept side by side:

    proxy   label-free: a row declined for risk, or a row with a very high network risk score.
            It is known on the day it happens. The merchant of that row is not blamed, because
            it is where the card was used, not where it was exposed.
    fraud   the account's first reported fraud, taken as known `LABEL_LAG_DAYS` after the
            transaction (fraud labels arrive weeks late; the files hold no report date).

Step two, per target row (`exposure_features`): the exposure score of a merchant-week as of the
row's day is the blame known before that day divided by the visitors seen before that day,
both without the row's own account, pulled toward the same share over all merchants. The
columns are the maximum and the sum of those scores over the account's own visits in the last
2, 14 and 90 completed days:

    exp_visits_<w>               the account's own visits (distinct merchant and day) in the window
    exp_visitors_<w>             mean number of other visitors behind the scores (the evidence)
    exp_proxy_max_<w>, exp_proxy_sum_<w>    exposure under the label-free definition
    exp_fraud_max_<w>, exp_fraud_sum_<w>    exposure under the reported-fraud definition

Why it exists
-------------
Frauds come in runs on one account, so most frauds follow an earlier fraud of that account and
an account history catches them. The first fraud of a run is different: nothing on the account
anticipates it. What often precedes it is a compromise somewhere else: a skimmed terminal, a
breached online shop, a site where stolen cards are tested. Other cards that passed through
the same place go bad in the following days and weeks. This file carries that evidence from
other accounts into every later transaction of an account that passed through the same place,
wherever the later transaction happens. It aims at first frauds, which no account history can
anticipate. A network or a downstream tree model gains a view of the account's exposure.

The rules of this folder hold here too. The tables come from a panel of files that is separate
from the rows a model is fitted on; the files hold whole accounts, so a merchant's visitors are
a sample, and the score is a share (blame per visitor), which keeps its expected value under
sampling. The row's own account is removed, both as a visitor and as a source of blame, so an
account's own later fraud never reaches its own earlier rows. Only completed days are read:
visits on days before the row's day, blame known on days before the row's day. The score of a
past visit changes as reports arrive, so it is recomputed as of each target day; it cannot be
stored once per visit. Shares are pulled toward the share over all merchants, so a merchant-week
with two visitors, one of them bad, does not read as a hot spot. The maximum here is taken over
the account's own visits of an already pulled share, not over other accounts' values.

Where it goes
-------------
Raw files, then these tables, then feature columns. For the network the columns join the
numeric inputs before preprocessing (the per-file step `SequenceBuilder._encode_file` in the
original code; each column becomes one more numeric token of `FeatureTokenizer`). Because the
value of a past visit changes with the target day, it is a per-target-row input, not a column
that can be stored on the history rows that stage 2 reads. For a second-stage tree model the
columns are joined by transaction id.

What to change for the pod
--------------------------
settings.py: ACCOUNT_COL, TIME_COL, MERCHANT_COL, VISA_SCORE_COL, LABEL_COL, POSITIVE_LABEL,
REASON_COL, RISK_DECLINE_REASONS. In _panel.py: PANEL_BASE, PANEL_FILES, DAY_SHIFT_SECONDS and
LABEL_LAG_DAYS. Here: WINDOWS, PROXY_BLAME_DAYS, FRAUD_BLAME_DAYS, HIGH_SCORE, EXPOSURE_PRIOR_ROWS,
WEEK_DAYS and DAYS_PER_CHUNK. If a terminal id is available, using it in place of the merchant
id (MERCHANT_COL) sharpens the compromise point. The panel must reach back as far as the
longest window plus a week before the first target day.

How to try it
-------------
    python additions/merchant/exposure.py --demo
    python additions/merchant/exposure.py --panel-files 8000 8001 8002 --files 8217 --out exposure.parquet

    by_merchant, by_account = combine([build_exposure_tables(df) for df in panel_frames])
    columns = exposure_features(target, by_merchant, by_account)
    python -m pytest -q additions/tests/test_merchant_exposure.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np
import pandas as pd

from additions import settings
from additions.common import timekeys
from additions.common.timekeys import MISSING_SECOND
from additions.merchant import _panel

# Names of the period columns of the tables: whole days and whole weeks since 1970-01-01.
DAY_COL = "day"
WEEK_COL = "week"

# The sums a table can hold: visitors, and blame under each definition of "bad".
VALUE_COLS = ("visitors", "proxy", "fraud")

# Windows of the account's own visits as (label, completed days ending the day before the row).
WINDOWS = (("2d", 2), ("14d", 14), ("90d", 90))

# PLACEHOLDER: the length of the merchant period in days. 7 groups visits by week; 1 gives
# merchant-days, which suits small test amounts at card-testing sites.
WEEK_DAYS = 7

# PLACEHOLDER: how many days before a label-free bad outcome the account's visits are blamed.
PROXY_BLAME_DAYS = 5

# PLACEHOLDER: how many days before the first reported fraud the account's visits are blamed.
FRAUD_BLAME_DAYS = 30

# PLACEHOLDER: the network risk score at or above which a row counts as a label-free bad outcome
# (the scale of settings.VISA_SCORE_COL runs from 0 to 99; put its top-decile value here).
HIGH_SCORE = 90.0

# PLACEHOLDER: made-up visitors at the prior's share that every merchant-week starts with. Bad
# outcomes are rare, so the prior has to weigh well above a typical merchant-week's visitors.
EXPOSURE_PRIOR_ROWS = 50.0

# How many distinct target days are answered in one pass. Fewer keeps memory small, more is faster.
DAYS_PER_CHUNK = 14


def needed_columns():
    """The raw columns the tables read (None entries are optional columns that are switched off)."""
    return [settings.ACCOUNT_COL, settings.TIME_COL, settings.ID_COL, settings.MERCHANT_COL,
            settings.VISA_SCORE_COL, settings.LABEL_COL, settings.REASON_COL, settings.DECLINE_FLAG_COL]


def _blame(rows, bad, horizon, lag, account_col, merchant_col):
    """Blame records of one definition of "bad": DataFrame [account, merchant, week, day, share].

    rows      visits with the account, merchant, day and week columns (rows with a time and a merchant)
    bad       yes/no per row of `rows`: is the row a bad outcome?
    horizon   days before the first bad outcome whose visits are blamed
    lag       days after the bad outcome at which it is taken as known

    Only the account's first bad outcome counts: it is the moment the card is known to be
    compromised, and later outcomes of the same run add nothing about where that happened.
    The merchants of the bad rows on that day are left out of the blame. The blamed visits
    are on days strictly before the bad outcome. The record's day is the day the outcome is
    known, so `exposure_features` hands it only to target rows of later days.
    """
    columns = [account_col, merchant_col, WEEK_COL, DAY_COL, "share"]
    if bad is None or not bad.any():
        return pd.DataFrame(columns=columns)
    hits = rows[bad]
    first = hits.groupby(account_col, sort=False)[DAY_COL].min().rename("bad_day")
    hits = hits.join(first, on=account_col)
    places = hits.loc[hits[DAY_COL] == hits["bad_day"], [account_col, merchant_col]].drop_duplicates()
    cand = rows[rows[account_col].isin(first.index)].join(first, on=account_col)
    cand = cand[(cand[DAY_COL] < cand["bad_day"]) & (cand[DAY_COL] >= cand["bad_day"] - int(horizon))]
    cand = cand.merge(places.assign(_place=True), on=[account_col, merchant_col], how="left")
    cand = cand[cand["_place"].isna()]
    pairs = cand.drop_duplicates([account_col, merchant_col, WEEK_COL])
    pairs = pairs[[account_col, merchant_col, WEEK_COL, "bad_day"]]
    # One unit of blame per bad account, split evenly over the merchant-weeks it used. A popular
    # merchant is therefore not blamed in full by every bad account that happened to shop there.
    share = 1.0 / pairs.groupby(account_col, sort=False)[merchant_col].transform("size")
    return pd.DataFrame({account_col: pairs[account_col].to_numpy(), merchant_col: pairs[merchant_col].to_numpy(),
                         WEEK_COL: pairs[WEEK_COL].to_numpy(), DAY_COL: pairs["bad_day"].to_numpy() + int(lag),
                         "share": share.to_numpy(dtype=np.float64)}, columns=columns)


def build_exposure_tables(df, account_col=None, time_col=None, merchant_col=None, score_col=None, label_col=None,
                          positive_label=None, reason_col=None, high_score=None, proxy_days=None, fraud_days=None,
                          label_lag_days=None, week_days=None, day_shift=None):
    """Step one: the visitor and blame records of one file (or of any table that holds whole accounts).

    df    raw rows; the column names default to settings.py and can be passed one by one

    Returns (by_merchant, by_account):
      by_merchant   one row per merchant, week and day with the sums of `VALUE_COLS`
      by_account    the same per account as well, for taking an account's own part out again

    A visitor record sits on the first day the account used the merchant in that week. A blame
    record sits on the day its bad outcome is known. A definition of "bad" whose columns are
    None in settings or absent from `df` is left out after one printed line.
    """
    account_col, merchant_col = _panel.pick(account_col, "ACCOUNT_COL"), _panel.pick(merchant_col, "MERCHANT_COL")
    week_days = WEEK_DAYS if week_days is None else int(week_days)
    day = _panel.days(timekeys.seconds(df[_panel.pick(time_col, "TIME_COL")]), day_shift)
    merchant = df[merchant_col].to_numpy()
    ok = (day != MISSING_SECOND) & ~np.asarray(pd.isna(merchant), dtype=bool)     # a row needs a time and a place
    rows = pd.DataFrame({account_col: df[account_col].to_numpy()[ok], merchant_col: merchant[ok], DAY_COL: day[ok]})
    rows[WEEK_COL] = rows[DAY_COL] // week_days

    visits = rows.groupby([account_col, merchant_col, WEEK_COL], sort=False, as_index=False)[DAY_COL].min()
    parts = [visits.assign(visitors=1.0)]

    # The label-free definition: a risk decline or a very high network risk score.
    _, risk = _panel.decisions(df, reason_col=reason_col)
    score = _panel.optional(df, _panel.pick(score_col, "VISA_SCORE_COL"), "the high-score part of the proxy",
                            numeric=True)
    proxy = None
    if risk is not None or score is not None:
        proxy = np.zeros(len(df), dtype=bool)
        if risk is not None:
            proxy |= risk > 0
        if score is not None:
            proxy |= score >= (HIGH_SCORE if high_score is None else high_score)     # a missing score is never high
    else:
        _panel.say_once("neither a response code nor a risk score is available; the proxy columns are skipped")
    if proxy is not None:
        blamed = _blame(rows, proxy[ok], PROXY_BLAME_DAYS if proxy_days is None else proxy_days, 0,
                        account_col, merchant_col)
        parts.append(blamed.rename(columns={"share": "proxy"}))

    # The reported-fraud definition: the first fraud, known a fixed lag after the transaction.
    label = _panel.optional(df, _panel.pick(label_col, "LABEL_COL"), "the reported-fraud exposure")
    if label is not None:
        fraud = _panel.is_one_of(label, (_panel.pick(positive_label, "POSITIVE_LABEL"),))
        lag = max(int(_panel.LABEL_LAG_DAYS if label_lag_days is None else label_lag_days), 0)
        blamed = _blame(rows, fraud[ok], FRAUD_BLAME_DAYS if fraud_days is None else fraud_days, lag,
                        account_col, merchant_col)
        parts.append(blamed.rename(columns={"share": "fraud"}))

    values = ["visitors"] + [name for name in ("proxy", "fraud") if any(name in p.columns for p in parts)]
    by_account = pd.concat(parts, ignore_index=True)
    by_account[values] = by_account[values].fillna(0.0).astype(np.float64)
    by_account = by_account[[account_col, merchant_col, WEEK_COL, DAY_COL] + values]
    by_merchant = _panel.add_tables([by_account.drop(columns=account_col)], values)
    return by_merchant, by_account


def combine(parts):
    """Add the tables of several files: a list of (by_merchant, by_account) in, one such pair out.

    The merchant tables are summed key by key. The per-account tables are stacked, because no
    account is in two files. An entry whose second part is None adds only its merchant table.
    """
    own = [part[1] for part in parts if part[1] is not None]
    return (_panel.add_tables([part[0] for part in parts], VALUE_COLS),
            pd.concat(own, ignore_index=True) if own else None)


def exposure_features(target, by_merchant, by_account=None, windows=None, prior_rows=None, account_col=None,
                      time_col=None, merchant_col=None, week_days=None, day_shift=None, days_per_chunk=None,
                      prefix="exp_"):
    """Step two: the exposure columns of every target row.

    target        raw rows with the account, time and merchant columns. The target files hold whole
                  accounts, so the account's own earlier visits are read from these rows.
    by_merchant   the added merchant table of the panel
    by_account    the per-account table of the panel files that hold accounts of `target`; None
                  when no target account is in the panel
    windows       ((label, days), ...) of the account's own visits (default: WINDOWS)
    prior_rows    strength of the prior (default: EXPOSURE_PRIOR_ROWS)

    Returns a DataFrame [targets, columns] with the index of `target`; see the top of the file.
    A maximum is missing when the account has no visit in the window; a sum is then 0.

    Time rule: a row on day d uses its account's visits on days before d, visitors seen on days
    before d and blame known on days before d. Rows of the same day never see each other. The
    row's own account is subtracted as a visitor and as a source of blame.
    """
    account_col, merchant_col = _panel.pick(account_col, "ACCOUNT_COL"), _panel.pick(merchant_col, "MERCHANT_COL")
    windows = WINDOWS if windows is None else windows
    prior_rows = EXPOSURE_PRIOR_ROWS if prior_rows is None else prior_rows
    week_days = WEEK_DAYS if week_days is None else int(week_days)
    days_per_chunk = DAYS_PER_CHUNK if days_per_chunk is None else int(days_per_chunk)
    values = [c for c in VALUE_COLS if c in by_merchant.columns]
    kinds = [c for c in ("proxy", "fraud") if c in values]
    longest = max(days for _, days in windows)

    day = _panel.days(timekeys.seconds(target[_panel.pick(time_col, "TIME_COL")]), day_shift)
    account = target[account_col].to_numpy()
    merchant = target[merchant_col].to_numpy()
    timed = day != MISSING_SECOND
    # The account's own visits: one per merchant and day. Repeats on the same day add nothing new.
    own = pd.DataFrame({account_col: account, merchant_col: merchant, "visit_day": day})
    own = own[timed & ~np.asarray(pd.isna(merchant), dtype=bool)].drop_duplicates()
    # The questions: one per account and day, because every value here changes only from day to day.
    asks = pd.DataFrame({account_col: account[timed], "ask_day": day[timed]}).drop_duplicates().reset_index(drop=True)

    names = []
    for label, _ in windows:
        names += [f"{prefix}visits_{label}", f"{prefix}visitors_{label}"]
        names += [f"{prefix}{kind}_{stat}_{label}" for kind in kinds for stat in ("max", "sum")]
    answers = np.full((len(asks), len(names)), np.nan)
    col = {name: j for j, name in enumerate(names)}

    # A loop over chunks of target days, never over rows: each chunk is one vectorised pass. The
    # chunks only bound memory, because every question pairs an account-day with each of the
    # account's visits in the longest window.
    all_days = np.sort(asks["ask_day"].unique())
    for start in range(0, len(all_days), max(days_per_chunk, 1)):
        chunk = asks[asks["ask_day"].isin(all_days[start:start + days_per_chunk])]
        q = chunk.reset_index().rename(columns={"index": "ask"}).merge(own, on=account_col)
        q = q[(q["visit_day"] < q["ask_day"]) & (q["visit_day"] >= q["ask_day"] - longest)].reset_index(drop=True)
        q[WEEK_COL] = q["visit_day"] // week_days
        ask_index = chunk.index.to_numpy()
        for label, _ in windows:
            answers[ask_index, col[f"{prefix}visits_{label}"]] = 0.0
            for kind in kinds:
                answers[ask_index, col[f"{prefix}{kind}_sum_{label}"]] = 0.0
        if len(q) == 0:
            continue
        ask_day = q["ask_day"].to_numpy(dtype=np.int64)
        # When no account of this chunk is in the panel there is nothing to take out, and the
        # per-account table is passed as None (an empty selection of it cannot be read by key).
        own_part = by_account
        if own_part is not None and not own_part[account_col].isin(pd.unique(q[account_col])).any():
            own_part = None
        # Visitors and blame at the visit's merchant-week, and over all merchants, without the own account.
        here = _panel.others_sums(by_merchant, own_part, [merchant_col, WEEK_COL], DAY_COL, values, q, ask_day,
                                  [None], account_col)[None]
        everywhere = _panel.others_sums(by_merchant, own_part, [], DAY_COL, values, q, ask_day, [None],
                                        account_col)[None]
        visitors = here[:, 0]
        scores = {kind: _panel.chain([(everywhere[:, j], everywhere[:, 0]), (here[:, j], here[:, 0])], prior_rows)
                  for j, kind in enumerate(values) if kind in kinds}
        who = q["ask"].to_numpy()
        for label, days in windows:
            inside = q["visit_day"].to_numpy() >= ask_day - days
            w = who[inside]
            n = np.bincount(w, minlength=len(asks)).astype(np.float64)
            answers[ask_index, col[f"{prefix}visits_{label}"]] = n[ask_index]
            total_visitors = np.bincount(w, weights=visitors[inside], minlength=len(asks))
            answers[ask_index, col[f"{prefix}visitors_{label}"]] = np.where(
                n[ask_index] > 0, total_visitors[ask_index] / np.maximum(n[ask_index], 1), np.nan)
            for kind, score in scores.items():
                s = np.nan_to_num(score[inside], nan=0.0)
                total = np.bincount(w, weights=s, minlength=len(asks))
                answers[ask_index, col[f"{prefix}{kind}_sum_{label}"]] = total[ask_index]
                # The largest score over the account's own visits; missing when there is no visit.
                top = np.full(len(asks), -np.inf)
                np.maximum.at(top, w, s)
                top = top[ask_index]
                answers[ask_index, col[f"{prefix}{kind}_max_{label}"]] = np.where(np.isfinite(top), top, np.nan)

    # Every row reads the answer of its account and day.
    found = pd.DataFrame({account_col: account, "ask_day": day}).merge(
        asks.reset_index().rename(columns={"index": "ask"}), on=[account_col, "ask_day"], how="left")["ask"].to_numpy()
    out = {}
    for name, j in col.items():
        values_of_rows = np.full(len(target), np.nan)
        hit = ~np.isnan(found)
        values_of_rows[hit] = answers[found[hit].astype(np.int64), j]
        out[name] = values_of_rows
    return _panel.as_frame(out, target.index)


def main(argv=None):
    """Command line: add the exposure tables of the panel files and print the columns of the target rows."""
    def of_file(df, held):
        # The per-account table is kept only for files that hold target rows: only their accounts
        # ever have to be taken out.
        by_merchant, by_account = build_exposure_tables(df)
        return by_merchant, (by_account if held else None)

    def features(target, part, args):
        return exposure_features(target, part[0], part[1])

    return _panel.run_tool(
        argv, "Compromise-point exposure from a panel of files, as columns of the target rows.",
        needed_columns(), of_file, combine, features)


if __name__ == "__main__":
    main()
