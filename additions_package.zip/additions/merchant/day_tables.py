"""Merchant-by-day tables: what OTHER accounts did at this merchant yesterday, last week, last month.

What this file does
-------------------
Step one, per file (`build_day_tables`): rows are grouped by merchant and calendar day. Each
group keeps plain sums: rows, distinct accounts, amount and amount squared, rows that were
not approved, rows declined for risk, the network risk score, and frauds by transaction day.
The same sums are kept per merchant, day and account, so that an account's own rows can be
subtracted later. Tables of many files are simply added (`combine`).

Step two, per target row (`day_features`): windows of 1, 7 and 30 completed days that end
the day before the row, minus what the row's own account did in the same window.

Step three: rates and means pulled toward broader keys, each with the count behind it:

    mday_n_<w>                    rows of other accounts at the merchant in the window (the evidence)
    mday_rows_per_account_<w>     their rows per account and day
    mday_not_approved_share_<w>   share of their rows that were not approved
    mday_risk_decline_share_<w>   share of their rows that were declined for risk
    mday_mean_score_<w>           mean network risk score of their rows
    mday_mean_amount_<w>          mean amount of their rows
    mday_amount_z_<w>             the row's own amount against that mean, in units of the spread
    mday_fraud_n_<w>, mday_fraud_rate_<w>    rows and fraud rate in a window that ends 30 days before the row

A rate is pulled first toward all merchants, then toward the merchant's category, then
toward its category in its postal code, then stands at the merchant itself. A merchant
with few rows therefore reads like its category by postal code, and like its category when
that is thin too: these are the fallback keys.

Why it exists
-------------
A merchant where other customers' transactions are being refused, where the network risk
score runs high, or where frauds were reported is a riskier place for the row at hand,
whatever the account's own history says. No field of the row and no history of the account
carries that; it lives in other accounts' rows. A network or a downstream tree model gains
a merchant view that changes from day to day.

The files hold whole accounts and no account is in two files, so a merchant's rows are
present only for the accounts in the files that were read. The tables are a sample, and
four rules keep the sample usable. They are built from a panel of files that is separate
from, and much larger than, the files a model is fitted on. The row's own account is taken
out, because frauds come in runs on one account and the merchant value would otherwise
hand the account its own run back. Only completed days are read, because a day that is
still running is not known. And only rates and means are offered, each with its count and
pulled toward a prior: a rate keeps its expected value when fewer accounts are sampled,
while a maximum, a number of distinct accounts, a first-seen flag and a raw count all move
with the share of accounts sampled. The count columns say how much evidence a rate rests
on; they are comparable only between panels of the same share.

Fraud labels arrive weeks after the transaction. A fraud of last week is mostly not
reported yet, so the fraud-rate columns read a window that ends 30 days before the row.
The files hold no report date, so that lag is a stand-in; `REPORTING_CURVE` can replace it.

Where it goes
-------------
Raw files, then these tables, then feature columns. For the network the columns join the
numeric inputs before preprocessing (the per-file step `SequenceBuilder._encode_file` in the
original code; each column becomes one more numeric token of `FeatureTokenizer`). For a
second-stage tree model they are joined by transaction id. The merchant-by-day table itself
is an export: other models can join it by merchant id and day, reading days before their row.

What to change for the pod
--------------------------
settings.py: ACCOUNT_COL, TIME_COL, MERCHANT_COL, MCC_COL, MERCHANT_POSTAL_COL, AMOUNT_COL,
VISA_SCORE_COL, LABEL_COL, POSITIVE_LABEL, REASON_COL, DECLINE_FLAG_COL and the code lists
APPROVED_REASONS, RISK_DECLINE_REASONS, DECLINE_FLAG_VALUES. In _panel.py: PANEL_BASE,
PANEL_FILES, DAY_SHIFT_SECONDS, LABEL_LAG_DAYS, PRIOR_ROWS. Here: WINDOWS, LABEL_WINDOWS,
LABEL_PRIOR_ROWS, REPORTING_CURVE. The panel has to hold the days right before the target
rows: for a scored month that is the evaluation files, which start one month before the
scored month, so the 30-day window is complete there. The label windows lie one to four
months back; when another set of files reaches that far, pass its tables as `label_tables`.
Train and score with panels of the same share of accounts, or see coverage.py.

How to try it
-------------
    python additions/merchant/day_tables.py --demo
    python additions/merchant/day_tables.py --panel-files 8000 8001 8002 --files 8217 --out mday.parquet

    by_merchant, by_account = combine([build_day_tables(df) for df in panel_frames])
    columns = day_features(target, by_merchant, by_account)
    python -m pytest -q additions/tests/test_merchant_day_tables.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np
import pandas as pd

from additions import settings
from additions.common import tables, timekeys
from additions.common.timekeys import MISSING_SECOND
from additions.merchant import _panel

# The name of the day column of the tables: whole days since 1970-01-01.
DAY_COL = "day"

# The sums a table can hold. A sum whose raw column is not available is simply absent.
VALUE_COLS = ("rows", "accounts", "amount", "amount_sq", "not_approved", "risk_declined", "score", "score_rows",
              "frauds")

# Windows of the label-free columns as (label, completed days ending the day before the row).
WINDOWS = (("1d", 1), ("7d", 7), ("30d", 30))

# Windows of the fraud-rate columns as (label, days); each ends `LABEL_LAG_DAYS` before the row.
LABEL_WINDOWS = (("30d", 30), ("90d", 90))

# PLACEHOLDER: made-up rows at the prior's value for the fraud rate. Fraud is rare, so the prior
# has to weigh far more than for the other rates, or one fraud at a small merchant reads as a hot spot.
LABEL_PRIOR_ROWS = 1000.0

# PLACEHOLDER: a measured reporting curve, to replace the fixed label lag. None keeps the fixed lag.
# The form is a list of (age in days, share of frauds reported by that age), for example
# [(7, s7), (14, s14), (30, s30), (60, s60)] with the measured shares in place of s7 ... s60.
REPORTING_CURVE = None


def needed_columns():
    """The raw columns the tables read (None entries are optional columns that are switched off)."""
    return [settings.ACCOUNT_COL, settings.TIME_COL, settings.ID_COL, settings.MERCHANT_COL, settings.MCC_COL,
            settings.MERCHANT_POSTAL_COL, settings.AMOUNT_COL, settings.VISA_SCORE_COL, settings.LABEL_COL,
            settings.REASON_COL, settings.DECLINE_FLAG_COL]


def build_day_tables(df, account_col=None, time_col=None, merchant_col=None, mcc_col=None, postal_col=None,
                     amount_col=None, score_col=None, label_col=None, positive_label=None, reason_col=None,
                     decline_flag_col=None, day_shift=None):
    """Step one: the merchant-by-day sums of one file (or of any table that holds whole accounts).

    df    raw rows; the column names default to settings.py and can be passed one by one

    Returns (by_merchant, by_account):
      by_merchant   one row per merchant, category, postal code and day with the sums of `VALUE_COLS`
      by_account    the same per account as well, for taking an account's own rows out again

    The category and the postal code ride along as key columns, so the same two tables also
    answer for the fallback keys. A sum whose raw column is None in settings or absent from
    `df` is left out, after one printed line, and the columns built on it are skipped later.
    """
    account_col, merchant_col = _panel.pick(account_col, "ACCOUNT_COL"), _panel.pick(merchant_col, "MERCHANT_COL")
    day = _panel.days(timekeys.seconds(df[_panel.pick(time_col, "TIME_COL")]), day_shift)
    cells = {merchant_col: df[merchant_col].to_numpy()}
    for name, what in ((_panel.pick(mcc_col, "MCC_COL"), "the category fallback"),
                       (_panel.pick(postal_col, "MERCHANT_POSTAL_COL"), "the category-by-postal-code fallback")):
        values = _panel.optional(df, name, what)
        if values is not None:
            cells[name] = values
    keys = list(cells) + [DAY_COL]
    cells.update({DAY_COL: day, account_col: df[account_col].to_numpy(), "rows": 1.0})
    amount = _panel.optional(df, _panel.pick(amount_col, "AMOUNT_COL"), "the mean amount", numeric=True)
    if amount is not None:
        # PLACEHOLDER: wrap the amount in np.log1p here to keep its mean and spread on a log scale.
        amount = np.nan_to_num(amount, nan=0.0)
        cells["amount"], cells["amount_sq"] = amount, amount ** 2
    not_approved, risk_declined = _panel.decisions(df, reason_col, decline_flag_col)
    if not_approved is not None:
        cells["not_approved"] = not_approved
    if risk_declined is not None:
        cells["risk_declined"] = risk_declined
    score = _panel.optional(df, _panel.pick(score_col, "VISA_SCORE_COL"), "the mean risk score", numeric=True)
    if score is not None:
        # A row without a score adds nothing to the sum and is not counted in its denominator.
        cells["score"], cells["score_rows"] = np.nan_to_num(score, nan=0.0), (~np.isnan(score)).astype(np.float64)
    label = _panel.optional(df, _panel.pick(label_col, "LABEL_COL"), "the fraud-rate columns")
    if label is not None:
        # Frauds are counted on the day of the transaction. When the label became known is decided
        # later, in `day_features`, by the lag or the reporting curve.
        cells["frauds"] = _panel.is_one_of(label, (_panel.pick(positive_label, "POSITIVE_LABEL"),)).astype(np.float64)
    frame = pd.DataFrame(cells)
    frame = frame[day != MISSING_SECOND]                           # a row without a time is in no day
    by_account = frame.groupby(keys + [account_col], dropna=False, sort=False, as_index=False).sum()
    # One account on one day at one merchant counts once. If its rows there carry two categories or postal
    # codes, the unit is split between them, so that the merchant's sum is still one.
    same_visit = by_account.groupby([merchant_col, DAY_COL, account_col], dropna=False)["rows"].transform("size")
    by_account["accounts"] = 1.0 / same_visit
    by_merchant = by_account.drop(columns=account_col).groupby(keys, dropna=False, sort=False, as_index=False).sum()
    return by_merchant, by_account


def combine(parts):
    """Add the tables of several files: a list of (by_merchant, by_account) in, one such pair out.

    The merchant tables are summed key by key. The per-account tables are stacked, because no
    account is in two files. An entry whose second part is None (a file whose accounts never
    need to be taken out) adds only its merchant table.
    """
    own = [part[1] for part in parts if part[1] is not None]
    return (_panel.add_tables([part[0] for part in parts], VALUE_COLS),
            pd.concat(own, ignore_index=True) if own else None)


def label_bands(window_days, lag_days=None, curve=None):
    """Which days count for a fraud rate, and how much: a list of (first age, last age, weight).

    The age of a day is the number of days it lies before the row's day (yesterday is 1).
    With the fixed lag, the days from `lag_days` to `lag_days + window_days - 1` back count
    fully and newer days not at all. With a reporting curve the span starts at the curve's
    first age instead (newer days than the fixed lag allows) and ends at the same far age,
    and each day counts with the share of its frauds that is reported by the row's day (the
    share at the curve point at or before its age): the newest days count a little and the
    old ones almost fully. Days younger than the curve's first age do not count. Frauds and rows get the same
    weight, so the rate stays a rate. Either way the knowledge time of a label is modelled,
    not observed, because the files hold no report date.
    """
    lag_days = max(int(_panel.LABEL_LAG_DAYS if lag_days is None else lag_days), 1)    # never the row's own day
    curve = REPORTING_CURVE if curve is None else curve
    last = lag_days + window_days - 1
    if not curve:
        return [(lag_days, last, 1.0)]
    points = sorted(curve)
    bands = []
    for i, (age, share) in enumerate(points):
        end = min(int(points[i + 1][0]) - 1, last) if i + 1 < len(points) else last
        if max(int(age), 1) <= end and share > 0:
            bands.append((max(int(age), 1), end, float(share)))
    return bands


def _levels(table, target, merchant_col, mcc_col, postal_col):
    """The keys a rate is pulled along, from the broadest to the narrowest, as [(name, key columns)]."""
    def usable(cols):
        return all(c and c in table.columns and c in target.columns for c in cols)

    levels = [("all", [])]
    for name, cols in (("category", [mcc_col]), ("category_postal", [mcc_col, postal_col])):
        if usable(cols):
            levels.append((name, cols))
        else:
            _panel.say_once(f"the {name} level is skipped: its columns are not in the table and the target rows")
    return levels + [("merchant", [merchant_col])]


def day_features(target, by_merchant, by_account=None, label_tables=None, windows=None, label_windows=None,
                 label_lag_days=None, reporting_curve=None, prior_rows=None, label_prior_rows=None,
                 account_col=None, time_col=None, merchant_col=None, mcc_col=None, postal_col=None,
                 amount_col=None, day_shift=None, prefix="mday_"):
    """Steps two and three: the merchant columns of every target row.

    target            raw rows to build columns for (account, time, merchant; category, postal code, amount)
    by_merchant       the added merchant-by-day table of the panel
    by_account        the per-account table of the panel files that hold accounts of `target`; None
                      when no target account is in the panel (then nothing has to be taken out)
    label_tables      (by_merchant, by_account) of another panel for the fraud-rate columns, when
                      a panel that reaches further back is at hand; None uses the same tables
    windows           ((label, days), ...) of the label-free columns (default: WINDOWS)
    label_windows     ((label, days), ...) of the fraud-rate columns (default: LABEL_WINDOWS)
    label_lag_days, reporting_curve   see `label_bands`; pass reporting_curve=() to force the fixed lag
    prior_rows, label_prior_rows      strength of the priors (default: _panel.PRIOR_ROWS, LABEL_PRIOR_ROWS)

    Returns a DataFrame [targets, columns] with the index of `target`; see the top of the
    file for the columns. A rate is missing only when no key at any level holds a row.

    Time rule: a row on day d reads days d-1 and before, never its own day. Rows of the same
    day therefore never see each other. The row's own account is subtracted at every level.
    """
    account_col, merchant_col = _panel.pick(account_col, "ACCOUNT_COL"), _panel.pick(merchant_col, "MERCHANT_COL")
    mcc_col, postal_col = _panel.pick(mcc_col, "MCC_COL"), _panel.pick(postal_col, "MERCHANT_POSTAL_COL")
    amount_col = _panel.pick(amount_col, "AMOUNT_COL")
    windows = WINDOWS if windows is None else windows
    label_windows = LABEL_WINDOWS if label_windows is None else label_windows
    label_prior_rows = LABEL_PRIOR_ROWS if label_prior_rows is None else label_prior_rows
    day = _panel.days(timekeys.seconds(target[_panel.pick(time_col, "TIME_COL")]), day_shift)
    levels = _levels(by_merchant, target, merchant_col, mcc_col, postal_col)
    values = [c for c in VALUE_COLS if c in by_merchant.columns and c != "frauds"]
    col = {name: j for j, name in enumerate(values)}

    # Step two: for every level, the sums of other accounts over the 1, 7 and 30 days before the row's day.
    edges = sorted({days for _, days in windows})
    sums = {name: _panel.others_sums(by_merchant, by_account, keys, DAY_COL, values, target, day, edges, account_col)
            for name, keys in levels}

    def rate(top, bottom, edge):
        """top / bottom at the merchant, pulled toward the broader levels."""
        return _panel.chain([(sums[name][edge][:, col[top]], sums[name][edge][:, col[bottom]]) for name, _ in levels],
                            prior_rows)

    out = {}
    own_amount = None
    if amount_col in target.columns:
        own_amount = pd.to_numeric(target[amount_col], errors="coerce").to_numpy(dtype=np.float64)
    for label, days in windows:
        at_merchant = sums["merchant"][days]
        out[f"{prefix}n_{label}"] = at_merchant[:, col["rows"]]
        # A plain ratio (no prior): rows per account and day, missing when no other account was there.
        out[f"{prefix}rows_per_account_{label}"] = _panel.shrunk(at_merchant[:, col["rows"]],
                                                                 at_merchant[:, col["accounts"]], np.nan)
        for name, top, bottom in (("not_approved_share", "not_approved", "rows"),
                                  ("risk_decline_share", "risk_declined", "rows"),
                                  ("mean_score", "score", "score_rows"), ("mean_amount", "amount", "rows")):
            if top in col:
                out[f"{prefix}{name}_{label}"] = rate(top, bottom, days)
        if "amount" in col and own_amount is not None:
            # The spread comes from the pulled mean of the squares. Both means use the same weights,
            # so they are the two moments of one mixed set of rows and the variance cannot be negative.
            mean = out[f"{prefix}mean_amount_{label}"]
            spread = np.sqrt(np.clip(rate("amount_sq", "rows", days) - mean ** 2, 0.0, None))
            out[f"{prefix}amount_z_{label}"] = _panel.shrunk(own_amount - mean, spread, np.nan)

    # The fraud-rate columns: the same subtraction of the own account, on days old enough for labels.
    label_merchant, label_account = (by_merchant, by_account) if label_tables is None else label_tables
    if "frauds" not in label_merchant.columns:
        _panel.say_once("the table holds no fraud counts; the fraud-rate columns are skipped")
        return _panel.as_frame(out, target.index)
    bands = {label: label_bands(days, label_lag_days, reporting_curve) for label, days in label_windows}
    edges = sorted({edge for parts in bands.values() for first, last, _ in parts for edge in (first - 1, last)})
    label_sums = {name: _panel.others_sums(label_merchant, label_account, keys, DAY_COL, ["frauds", "rows"], target,
                                           day, edges, account_col) for name, keys in levels}
    for label, _ in label_windows:
        # Days between two ages: everything up to the far age minus everything up to the near one.
        weighted = {name: sum(weight * (label_sums[name][last] - label_sums[name][first - 1])
                              for first, last, weight in bands[label]) for name, _ in levels}
        out[f"{prefix}fraud_n_{label}"] = weighted["merchant"][:, 1]
        out[f"{prefix}fraud_rate_{label}"] = _panel.chain([(weighted[name][:, 0], weighted[name][:, 1])
                                                           for name, _ in levels], label_prior_rows)
    return _panel.as_frame(out, target.index)


def main(argv=None):
    """Command line: add the day tables of the panel files and print the columns of the target rows."""
    def of_file(df, held):
        # The per-account table is kept only for files that hold target rows: only their accounts
        # ever have to be taken out, and that table is as long as the file itself.
        by_merchant, by_account = build_day_tables(df)
        return by_merchant, (by_account if held else None)

    def features(target, part, args):
        if args.save_table:
            tables.write_table(part[0], args.save_table)
            print(f"written: {args.save_table}")
        return day_features(target, part[0], part[1])

    return _panel.run_tool(
        argv, "Merchant-by-day tables from a panel of files, and the merchant columns of the target rows.",
        needed_columns(), of_file, combine, features,
        lambda parser: parser.add_argument("--save-table", default=None,
                                           help="also write the added merchant-by-day table to this parquet file"))


if __name__ == "__main__":
    main()
