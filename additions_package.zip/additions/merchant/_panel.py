"""Shared steps of the merchant tables: periods, adding tables, sums over other accounts, priors.

What this file does
-------------------
It holds the steps that every file of `additions/merchant/` repeats:

    periods, days                  cut whole seconds into periods (days, hours, 5-minute slots)
    decisions                      which rows were not approved, and which were declined for risk
    add_tables                     add the tables of many files: rows with the same key are summed
    lookup_sums                    for target rows, sums of table columns over strictly earlier
                                   periods of the same key (the last 7 completed days, for example)
    others_sums                    the same with the target row's own account taken out again
    shrunk, chain                  a rate or a mean pulled toward a prior, level after level
    smooth_histogram, histogram_quantile, histogram_rank    percentiles from binned counts
    run_tool, report               the command line that the tools of this folder share

Why it exists
-------------
The files hold whole accounts and no account is in two files, so a merchant's rows are
present only for the accounts in the files that were read. Every table in this folder is
therefore a sample of what happened at a merchant. Four rules keep such a sample usable,
and each is easier to keep when it is written once.

1. The panel is separate from the rows a model is fitted on. The panel is the set of files
   whose rows fill a table. A model is fitted on few files, which hold far too few accounts
   to give a merchant more than a handful of rows, so the panel has to be much larger.
2. The row's own account is removed. Frauds come in runs on one account, so most frauds
   follow an earlier fraud of that account. A merchant value that still held the account's
   own rows would repeat the account's own run back to it, and it would do so only for
   accounts that happen to be inside the panel. `others_sums` subtracts the account's own
   part, which also makes a row inside the panel and a row outside it read the same thing.
3. Only completed earlier periods are used. A row may use only what was known before it. A
   day or an hour that is still running is not known, so a row reads yesterday and before
   (or the last completed hour and before). The history engine of the package enforces it:
   the period number is used as its clock, and it never hands a row its own period.
4. Rates and means are reported with their counts and pulled toward a prior. Under account
   sampling a mean or a rate keeps its expected value and only becomes noisier. A raw
   count, a number of distinct accounts and a maximum all change with the share of accounts
   sampled, and "never seen before" fires for merchants that are merely unsampled. Such
   values are therefore not offered as signals. The count that stands beside a rate says how
   much evidence the rate rests on; it is comparable between two tables only when both come
   from panels of the same share (coverage.py gives a model the share as an input).

Where it goes
-------------
Nowhere by itself. The files of this folder import it. It runs on the CPU, between the raw
files and the feature columns, before preprocessing and before the tokenizer.

What to change for the pod
--------------------------
`PANEL_BASE` and `PANEL_FILES` (which files fill the tables), `DAY_SHIFT_SECONDS` (where the
bank's day begins), `LABEL_LAG_DAYS` (how late a fraud label is taken as known) and
`PRIOR_ROWS` (how strongly a thin rate is pulled toward its prior). Keys are compared by
value: an id column should have the same type in a table and in the target rows (an id
that is a whole number in one and a decimal number in the other is compared as a decimal
number, which is exact only below 2**53).

How to try it
-------------
    sums = _panel.lookup_sums([table["m"]], table["day"], [table["rows"]], [target["m"]], target_day, [1, 7])
    sums[7][:, 0]          # rows at the same merchant in the 7 completed days before each target row
    python -m pytest -q additions/tests/test_merchant_panel.py
"""
import argparse
import tempfile

import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, tables, timekeys
from additions.common.history import EarlierRows
from additions.common.timekeys import MISSING_SECOND

DAY = 86_400
HOUR = 3_600
WEEK = 7 * DAY

# PLACEHOLDER: the folder and the numbers of the panel files, the files whose rows fill the tables.
# None for the folder means settings.EVAL_BASE. The list is an example.
PANEL_BASE = None
PANEL_FILES = list(range(8000, 8200))

# PLACEHOLDER: seconds added to every timestamp before it is cut into calendar days. 0 cuts at
# midnight of the clock the timestamps are written in; put the offset of the bank's processing day here.
DAY_SHIFT_SECONDS = 0

# PLACEHOLDER: the number of days after which a fraud label is taken as known. The files hold no
# report date, so this lag stands in for it; a measured reporting curve can replace it (day_tables.py).
LABEL_LAG_DAYS = 30

# PLACEHOLDER: how many made-up rows at the prior's value every rate and mean starts with. With 20,
# a merchant with 20 rows of its own sits halfway between its own value and the prior.
PRIOR_ROWS = 20.0

# How many per-file tables the command line lets pile up before it adds them into one.
FILES_PER_BATCH = 25

# The number type of the output columns. Half the size of float64 and precise enough for rates,
# means and counts up to 16 million. Use np.float64 if a consumer needs it.
FLOAT = np.float32

_SAID = set()


# ----------------------------------------------------------------------------------------------
# settings, optional columns, decisions
# ----------------------------------------------------------------------------------------------

def pick(value, setting_name):
    """`value` when it is given, otherwise what settings.py holds under `setting_name` right now."""
    return getattr(settings, setting_name) if value is None else value


def say_once(message):
    """Print a note the first time it comes up and stay silent after that.

    The table builders run once per file, so a missing optional column would otherwise print
    the same line thousands of times.
    """
    if message not in _SAID:
        _SAID.add(message)
        print(f"note: {message}")


def optional(df, name, what, numeric=False):
    """The values of column `name` as an array [rows], or None when the column is not available.

    A name of None (the setting is switched off) or a name the table does not have makes the
    function say so once and return None; the caller then skips the part named by `what`.
    With `numeric=True` the values are float64 and anything that is not a number is missing.
    """
    if not name or name not in df.columns:
        reason = "no column is set" if not name else f"the table has no column '{name}'"
        say_once(f"{reason} for {what}; that part is skipped")
        return None
    if numeric:
        return pd.to_numeric(df[name], errors="coerce").to_numpy(dtype=np.float64)
    return df[name].to_numpy()


def as_text(value):
    """One value as text; a whole number is written without a decimal point (5.0 becomes "5")."""
    if isinstance(value, (float, np.floating)) and float(value).is_integer():
        return str(int(value))
    return str(value).strip()


def is_one_of(values, wanted):
    """Yes/no per row [rows]: is the row's value one of `wanted`? A missing value is never one.

    Values are compared as text, so the number 1 and the text "1" are the same. The text is
    built once per distinct value, never once per row.
    """
    codes, distinct = pd.factorize(np.asarray(values, dtype=object))
    hit = np.isin([as_text(v) for v in distinct], [as_text(w) for w in wanted])
    out = np.zeros(len(codes), dtype=bool)
    out[codes >= 0] = hit[codes[codes >= 0]]
    return out


def decisions(df, reason_col=None, decline_flag_col=None, approved_reasons=None, risk_reasons=None,
              decline_flag_values=None):
    """(not_approved, risk_declined): two float arrays [rows] of 0 and 1; None for a part that cannot be built.

    A row is "not approved" when it holds a response code outside the approved list, or when
    its decline flag is set. It is "declined for risk" when its response code is in the risk
    list. A row without a response code and without a set flag counts as approved. These are
    outcomes of the rows themselves: they may only ever be read from OTHER rows of EARLIER
    periods, which is what the tables of this folder do.
    """
    reason = optional(df, pick(reason_col, "REASON_COL"), "the response code")
    flag = optional(df, pick(decline_flag_col, "DECLINE_FLAG_COL"), "the decline flag")
    if reason is None and flag is None:
        return None, None
    not_approved = np.zeros(len(df), dtype=bool)
    risk = None
    if reason is not None:
        known = ~np.asarray(pd.isna(reason), dtype=bool) & ~is_one_of(reason, ("",))    # a blank code is no code
        not_approved |= known & ~is_one_of(reason, pick(approved_reasons, "APPROVED_REASONS"))
        risk = is_one_of(reason, pick(risk_reasons, "RISK_DECLINE_REASONS")).astype(np.float64)
    if flag is not None:
        not_approved |= is_one_of(flag, pick(decline_flag_values, "DECLINE_FLAG_VALUES"))
    return not_approved.astype(np.float64), risk


# ----------------------------------------------------------------------------------------------
# periods and tables
# ----------------------------------------------------------------------------------------------

def periods(secs, length, shift=0):
    """The number of the period each second falls in: floor((second + shift) / length), int64 [rows].

    `length` is the period in seconds (86_400 for days, 3_600 for hours, 300 for 5-minute
    slots). A missing time stays missing, so such a row is in no period at all.
    """
    secs = np.asarray(secs, dtype=np.int64)
    missing = secs == MISSING_SECOND
    return np.where(missing, MISSING_SECOND, (np.where(missing, 0, secs) + int(shift)) // int(length))


def days(secs, shift=None):
    """The calendar day of each second, counted from 1970-01-01, with the day shift of this file."""
    return periods(secs, DAY, DAY_SHIFT_SECONDS if shift is None else shift)


def add_tables(frames, values):
    """Add tables: rows that agree on every key column are summed into one row.

    frames   a list of DataFrames with the same columns
    values   the names of the columns that are summed; every other column is a key

    This is all it takes to combine the tables of many files, because every value column is a
    plain sum over rows. A missing key value is kept as a key of its own (a row without a
    postal code still counts for its merchant and its category). Returns one DataFrame.
    """
    frames = [f for f in frames if f is not None and len(f)]
    if not frames:
        return pd.DataFrame(columns=list(values))
    stacked = frames[0] if len(frames) == 1 else pd.concat(frames, ignore_index=True)
    keys = [c for c in stacked.columns if c not in values]
    if not keys:
        return stacked[list(values)].sum().to_frame().T
    return stacked.groupby(keys, dropna=False, sort=False, as_index=False).sum()


# ----------------------------------------------------------------------------------------------
# sums over strictly earlier periods
# ----------------------------------------------------------------------------------------------

def window_totals(engine, columns, edges, rows=None):
    """Sums of several columns over the strictly earlier rows of one history engine, for several windows.

    engine    an `EarlierRows` object (its clock may count seconds, days or any other period)
    columns   a list of arrays; each is summed separately. An array shorter than the engine is
              read as "zero on the remaining rows" (target rows stacked behind table rows carry no value)
    edges     window lengths in units of the engine's clock: an edge k means the k units before the
              row, and None means every earlier unit
    rows      positions of the rows that need an answer (default: every row)

    Returns {edge: float64 [len(rows), len(columns)]}. The search for the two ends of a window
    is the costly step; it is done once per edge and shared by all columns.
    """
    where = engine.inverse if rows is None else engine.inverse[rows]
    ends = {}
    for edge in edges:
        lo, hi = engine.bounds(edge)
        ends[edge] = (lo[where], hi[where])
    out = {edge: np.zeros((len(where), len(columns))) for edge in edges}
    for j, column in enumerate(columns):
        values = np.zeros(engine.n)
        values[:len(column)] = np.nan_to_num(np.asarray(column, dtype=np.float64), nan=0.0)
        # Sorted like the engine; a row without a time counts for nobody.
        prefix = np.concatenate(([0.0], np.cumsum(values[engine.order] * engine.valid)))
        for edge, (lo, hi) in ends.items():
            out[edge][:, j] = prefix[hi] - prefix[lo]
    return out


def lookup_sums(table_keys, table_periods, columns, target_keys, target_periods, edges):
    """For every target row, sums of table columns over strictly earlier periods of the same key.

    table_keys      list of arrays [table rows]: the key columns (an empty list means one key for all)
    table_periods   int64 [table rows]: the period of each table row
    columns         list of arrays [table rows]: the values to sum
    target_keys     list of arrays [targets]: the same key columns for the target rows
    target_periods  int64 [targets]: the period each target row is in
    edges           an edge k asks for the k periods before the target's own period; None asks
                    for every earlier period

    Returns {edge: float64 [targets, len(columns)]}.

    Time rule: the table rows and the target rows are stacked and given to the history engine
    with the period as its clock. The engine only ever hands a row the rows of strictly
    earlier clock values, so a target row never reads its own period, let alone a later one.
    A row whose key is missing is given no period: it matches nothing and nothing matches it.
    """
    n_table, n_target = len(table_periods), len(target_periods)
    clock = np.concatenate([np.asarray(table_periods, dtype=np.int64), np.asarray(target_periods, dtype=np.int64)])
    if len(table_keys) == 0:
        codes = np.zeros(n_table + n_target, dtype=np.int64)
    else:
        stacked = [np.concatenate([np.asarray(a), np.asarray(b)]) for a, b in zip(table_keys, target_keys)]
        present = np.ones(n_table + n_target, dtype=bool)
        for part in stacked:
            present &= ~np.asarray(pd.isna(part), dtype=bool)
        clock = np.where(present, clock, MISSING_SECOND)
        codes = timekeys.codes(*stacked)
    engine = EarlierRows(codes, clock)
    return window_totals(engine, columns, edges, rows=np.arange(n_table, n_table + n_target))


def others_sums(by_key, by_account, keys, period, values, target, target_periods, edges, account):
    """Sums over what OTHER accounts did at the target row's key in strictly earlier periods.

    by_key          table with the key columns, the period column and the value columns, all accounts together
    by_account      the same split by account (it also holds the `account` column); None when
                    no account of the target rows is in the table
    keys            names of the key columns, read from the tables and from `target` ([] means one key for all)
    period          name of the period column of the tables
    values          names of the value columns
    target          DataFrame of target rows with the key columns (and the account column)
    target_periods  int64 [targets]: the period each target row is in
    edges           as in `lookup_sums`
    account         name of the account column

    Returns {edge: float64 [targets, len(values)]}: the sum over all accounts minus the sum
    over the target row's own account. An account that is not in `by_account` has nothing to
    subtract, so the same call serves target rows inside and outside the panel.
    """
    keys, values = list(keys), list(values)

    def read(table, key_cols):
        small = add_tables([table[key_cols + [period] + values]], values)       # one row per key and period
        return lookup_sums([small[k].to_numpy() for k in key_cols], small[period].to_numpy(),
                           [small[v].to_numpy() for v in values],
                           [target[k].to_numpy() for k in key_cols], target_periods, edges)

    sums = read(by_key, keys)
    if by_account is not None:
        # Only the accounts that are asked about can have rows to take out.
        mine = by_account[by_account[account].isin(pd.unique(target[account]))]
        own = read(mine, keys + [account])
        sums = {edge: sums[edge] - own[edge] for edge in edges}
    return sums


# ----------------------------------------------------------------------------------------------
# priors and histograms
# ----------------------------------------------------------------------------------------------

def shrunk(total, count, prior, strength=None):
    """A rate or a mean pulled toward a prior: (total + strength * prior) / (count + strength).

    total, count   float [rows]: the sum and the number of rows it was summed over
    prior          float [rows] or one number: the value to fall back on; NaN means "no prior known"
    strength       how many made-up rows at the prior's value are added (default: PRIOR_ROWS)

    With many rows the result is the plain ratio; with none it is the prior. Without a prior
    the plain ratio is returned, and NaN where there is no row either. For a share this is the
    mean of a Beta prior updated by the rows seen.
    """
    strength = PRIOR_ROWS if strength is None else strength
    total = np.asarray(total, dtype=np.float64)
    count = np.asarray(count, dtype=np.float64)
    prior = np.broadcast_to(np.asarray(prior, dtype=np.float64), total.shape)
    weight = np.where(np.isnan(prior), 0.0, strength)
    bottom = count + weight
    out = np.full(total.shape, np.nan)
    np.divide(total + weight * np.nan_to_num(prior, nan=0.0), bottom, out=out, where=bottom > 0)
    return out


def chain(levels, strength=None):
    """A rate pulled toward ever broader keys: `levels` lists (total, count) from the broadest key to the narrowest.

    The broadest level stands by itself, the next is pulled toward it, and so on down to the
    narrowest. A merchant with few rows therefore reads close to its category by postal code,
    and that reads close to its category when it is thin too: the fallback keys need no
    special case. Returns float [rows].
    """
    value = np.nan
    for total, count in levels:
        value = shrunk(total, count, value, strength)
    return value


def smooth_histogram(counts, prior, strength=None):
    """Binned counts [rows, bins] plus `strength` made-up rows spread like the `prior` histogram."""
    strength = PRIOR_ROWS if strength is None else strength
    prior = np.asarray(prior, dtype=np.float64)
    mass = prior.sum(axis=1, keepdims=True)
    shape = np.divide(prior, mass, out=np.zeros_like(prior), where=mass > 0)
    return np.asarray(counts, dtype=np.float64) + strength * shape


def histogram_quantile(counts, edges, q):
    """The q-quantile of binned counts: float [rows], NaN where a histogram is empty.

    counts [rows, bins], edges [bins + 1]. The mass is taken as spread evenly inside a bin, so
    the answer moves along a straight line between the two edges of the bin it falls in.
    """
    counts, edges = np.asarray(counts, dtype=np.float64), np.asarray(edges, dtype=np.float64)
    cum = np.cumsum(counts, axis=1)
    total = cum[:, -1]
    want = q * total
    b = np.minimum((cum < want[:, None]).sum(axis=1), counts.shape[1] - 1)     # the bin in which `want` is reached
    r = np.arange(len(counts))
    below = np.where(b > 0, cum[r, np.maximum(b - 1, 0)], 0.0)
    part = np.divide(want - below, counts[r, b], out=np.zeros(len(counts)), where=counts[r, b] > 0)
    return np.where(total > 0, edges[b] + np.clip(part, 0.0, 1.0) * (edges[b + 1] - edges[b]), np.nan)


def histogram_rank(counts, edges, values):
    """The share of a histogram's mass that lies below each value: float [rows] between 0 and 1.

    counts [rows, bins], edges [bins + 1], values [rows]. Inside the value's own bin the mass
    is taken as spread evenly. NaN where the histogram is empty or the value is missing.
    """
    counts, edges = np.asarray(counts, dtype=np.float64), np.asarray(edges, dtype=np.float64)
    v = np.asarray(values, dtype=np.float64)
    b = np.clip(np.searchsorted(edges, np.nan_to_num(v, nan=edges[0]), side="right") - 1, 0, counts.shape[1] - 1)
    cum = np.cumsum(counts, axis=1)
    total = cum[:, -1]
    r = np.arange(len(counts))
    below = np.where(b > 0, cum[r, np.maximum(b - 1, 0)], 0.0)
    part = np.clip((v - edges[b]) / (edges[b + 1] - edges[b]), 0.0, 1.0)
    rank = np.divide(below + part * counts[r, b], total, out=np.full(len(counts), np.nan), where=total > 0)
    return np.where(np.isnan(v), np.nan, rank)


# ----------------------------------------------------------------------------------------------
# the command line shared by the tools of this folder
# ----------------------------------------------------------------------------------------------

def as_frame(named, index):
    """Turn {column name: one value per row} into a DataFrame of `FLOAT` aligned to the target rows."""
    return pd.DataFrame({name: np.asarray(values, dtype=FLOAT) for name, values in named.items()}, index=index)


def summary(frame):
    """One line per column: share of missing values, mean, smallest and largest value."""
    lines = []
    for name in frame.columns:
        values = frame[name].to_numpy(dtype=np.float64)
        have = values[~np.isnan(values)]
        lines.append({"column": name, "missing": 1.0 - len(have) / max(len(values), 1),
                      "mean": have.mean() if len(have) else np.nan,
                      "min": have.min() if len(have) else np.nan, "max": have.max() if len(have) else np.nan})
    return pd.DataFrame(lines, columns=["column", "missing", "mean", "min", "max"])


def report(frame, target=None, out=None, id_col=None):
    """Print a summary of new columns and, with `out`, write them (an existing file is replaced).

    The transaction id of the target rows is written beside the columns when the target table
    has one, so that the file can be joined back to the raw rows. A name ending in .csv gives
    comma-separated text, anything else parquet.
    """
    print(f"{len(frame)} rows, {frame.shape[1]} columns")
    if frame.shape[1]:
        print(summary(frame).to_string(index=False, float_format=lambda x: f"{x:.4f}"))
    if out:
        id_col = pick(id_col, "ID_COL")
        table = frame.reset_index(drop=True)
        if target is not None and id_col in target.columns:
            table.insert(0, id_col, target[id_col].to_numpy())
        if str(out).lower().endswith(".csv"):
            table.to_csv(out, index=False)
        else:
            tables.write_table(table, out)
        print(f"written: {out}")
    return frame


def run_tool(argv, description, columns, of_file, combine, features, more_arguments=None):
    """The command line of a table tool: read the panel file by file, then build columns for the target rows.

    argv            the command-line arguments (None reads them from the shell)
    description     one sentence for the help text
    columns         the raw columns to read (None entries and names a file lacks are skipped)
    of_file         a function of_file(df, held) that returns what one panel file adds to the tables;
                    `held` says whether the file also holds target rows (its accounts then have to
                    be taken out of their own values later, so their per-account part is kept)
    combine         a function combine(parts) that adds what several files returned into one part
    features        a function features(target, part, args) that returns the DataFrame of new columns
    more_arguments  a function that adds further arguments to the parser

    With --demo the files are made up, so the tool can be tried with no data at all: four
    files form the panel and two of them hold the target rows. Returns the DataFrame.
    """
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("--panel-base", default=None,
                        help="folder of the panel files (default: PANEL_BASE in _panel.py, else settings.EVAL_BASE)")
    parser.add_argument("--panel-files", type=int, nargs="+", default=None,
                        help="panel file numbers (default: PANEL_FILES in _panel.py)")
    parser.add_argument("--base", default=None, help="folder of the files with the target rows (default: the panel folder)")
    parser.add_argument("--files", type=int, nargs="+", default=None,
                        help="file numbers of the target rows (default: settings.CONSUMER_READ_FILES)")
    parser.add_argument("--demo", action="store_true", help="run on made-up files instead")
    parser.add_argument("--out", default=None, help="write the new columns here (.csv, otherwise parquet)")
    if more_arguments is not None:
        more_arguments(parser)
    args = parser.parse_args(argv)
    demo = tempfile.TemporaryDirectory() if args.demo else None
    try:
        if demo is not None:
            panel_base = base = demo.name
            panel_numbers = synthetic.write_files(synthetic.make_transactions(n_accounts=240, seed=1), demo.name, 4)
            numbers = panel_numbers[:2]
        else:
            panel_base = args.panel_base or PANEL_BASE or settings.EVAL_BASE
            panel_numbers = args.panel_files or PANEL_FILES
            base = args.base or panel_base
            numbers = args.files or settings.CONSUMER_READ_FILES
        pile, targets = [], {}
        # A loop over files, never over rows: each file is read once and reduced to its tables.
        for i, number in enumerate(panel_numbers):
            df = tables.read_columns(tables.file_path(panel_base, number), columns, quiet=i > 0)
            held = base == panel_base and number in numbers
            pile.append(of_file(df, held))
            if held:
                targets[number] = df                    # a target file inside the panel is read only once
            if len(pile) >= FILES_PER_BATCH:
                pile = [combine(pile)]                  # adding as the files come in keeps the memory bounded
        for number in numbers:
            if number not in targets:
                targets[number] = tables.read_columns(tables.file_path(base, number), columns, quiet=True)
        target = pd.concat([targets[n] for n in numbers], ignore_index=True)
        frame = features(target, combine(pile), args)
    finally:
        if demo is not None:
            demo.cleanup()
    return report(frame, target, args.out)
