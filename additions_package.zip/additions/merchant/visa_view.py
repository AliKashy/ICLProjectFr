"""The network's view of a merchant: the network risk score averaged over OTHER accounts there.

What this file does
-------------------
Per file (`build_visa_tables`) rows are grouped by merchant and calendar day, and each group
keeps the number of rows with a network risk score, the sum of the scores and a histogram of
them in 10 bins. The same sums are kept per merchant, day and account, so that an account's
own rows can be subtracted later. Tables of many files are simply added (`combine`).

For a target row (`visa_features`) the scores of other accounts at the merchant are read over
two windows of completed days that end the day before the row: the last 30 days (the
baseline) and the last day (the recent value). The columns are:

    visa_n_30d, visa_n_1d               rows with a score behind each value (the evidence)
    visa_mean_30d, visa_mean_1d         mean score of other accounts at the merchant
    visa_p90_30d, visa_p90_1d           90th percentile of their scores, read from the histogram
    visa_recent_minus_base_mean         recent mean minus baseline mean
    visa_recent_minus_base_p90          recent 90th percentile minus baseline 90th percentile
    visa_own_minus_base                 the row's own score minus the baseline mean
    visa_own_pct_30d                    where the row's own score lies inside the baseline histogram (0 to 1)

Means are pulled toward broader keys (all merchants, then the merchant's category, then the
merchant), and histograms are smoothed the same way, so a merchant with few rows reads like
its category. No fraud label is used anywhere in this file.

Why it exists
-------------
The network computes its risk score on the traffic of many banks. One row's score mixes a
part that belongs to the card and a part that belongs to the merchant. Averaging the score
over many other accounts at one merchant cancels most of the card part and leaves the
network's view of the merchant. The relative columns then tell a model whether a score of 40
is normal for this merchant or unusual for it, which no field of the row and no history of
the account can say. A downstream tree model gains the same: a merchant baseline and the
row's distance from it. Fraud labels arrive weeks after the transaction; the network score
is known at once, so these columns have no reporting delay.

The rules of this folder hold here too. The files hold whole accounts and no account is in
two files, so a merchant's rows are present only for the accounts in the files that were
read: the tables are a sample, built from a panel of files that is separate from the rows a
model is fitted on. The row's own account is taken out, because frauds come in runs on one
account and a merchant value that still held the account's own high scores would hand the
run back to it. Only completed days are read: a row on day d reads days d-1 and before.
Only means and percentiles are offered, each with its count and pulled toward a prior: they
keep their expected value when fewer accounts are sampled, while a maximum or a raw count
would move with the share of accounts sampled. A percentile read from a thin histogram is
noisy, which is why the histogram is smoothed toward the category before it is read.

Where it goes
-------------
Raw files, then these tables, then feature columns. For the network the columns join the
numeric inputs before preprocessing (the per-file step `SequenceBuilder._encode_file` in the
original code; each column becomes one more numeric token of `FeatureTokenizer`). For a
second-stage tree model they are joined by transaction id. The table rides well beside the
merchant-by-day tables of day_tables.py, which already keep the score sum.

What to change for the pod
--------------------------
settings.py: ACCOUNT_COL, TIME_COL, MERCHANT_COL, MCC_COL, VISA_SCORE_COL. In _panel.py:
PANEL_BASE, PANEL_FILES, DAY_SHIFT_SECONDS, PRIOR_ROWS. Here: SCORE_EDGES (the bins of the
histogram; the default assumes a score from 0 to 99), BASE_DAYS, RECENT_DAYS and QUANTILE.
Pass `keys=[MERCHANT_COL, CARD_PRESENT_COL]` to split very large merchants by card presence.
The score is assumed to be known before the decision on the row; if it is not, the own-score
columns fall with it. The panel must hold the 30 days before the target rows; evaluation
files that start one month before the scored month do.

How to try it
-------------
    python additions/merchant/visa_view.py --demo
    python additions/merchant/visa_view.py --panel-files 8000 8001 8002 --files 8217 --out visa.parquet

    by_merchant, by_account = combine([build_visa_tables(df) for df in panel_frames])
    columns = visa_features(target, by_merchant, by_account)
    python -m pytest -q additions/tests/test_merchant_visa_view.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np
import pandas as pd

from additions import settings
from additions.common import timekeys
from additions.common.timekeys import MISSING_SECOND
from additions.merchant import _panel

# The name of the day column of the tables: whole days since 1970-01-01.
DAY_COL = "day"

# PLACEHOLDER: the edges of the score histogram; the default gives 10 bins of width 10 for a score from 0 to 99.
SCORE_EDGES = np.linspace(0.0, 100.0, 11)

# PLACEHOLDER: completed days in the baseline window and in the recent window, both ending the day before the row.
BASE_DAYS = 30
RECENT_DAYS = 1

# The percentile read from the histograms (0.9 is the 90th percentile).
QUANTILE = 0.9


def bin_names(edges=None):
    """The names of the histogram columns of the tables: h0, h1, ... one per bin."""
    edges = SCORE_EDGES if edges is None else edges
    return [f"h{j}" for j in range(len(edges) - 1)]


def value_cols(edges=None):
    """All value columns of the tables: rows with a score, the score sum and the histogram bins."""
    return ["score_rows", "score"] + bin_names(edges)


def needed_columns():
    """The raw columns the tables read (None entries are optional columns that are switched off)."""
    return [settings.ACCOUNT_COL, settings.TIME_COL, settings.ID_COL, settings.MERCHANT_COL, settings.MCC_COL,
            settings.VISA_SCORE_COL, settings.CARD_PRESENT_COL]


def bin_of(values, edges):
    """The bin of each value: int64 [rows]. A value below the first edge falls in the first bin and a
    value at or above the last edge in the last bin, so a score of exactly 100 is still counted."""
    v = np.asarray(values, dtype=np.float64)
    return np.clip(np.searchsorted(edges, v, side="right") - 1, 0, len(edges) - 2)


def build_visa_tables(df, keys=None, edges=None, account_col=None, time_col=None, merchant_col=None, mcc_col=None,
                      score_col=None, day_shift=None):
    """The merchant-by-day score sums and histograms of one file (or of any table of whole accounts).

    df      raw rows; the column names default to settings.py
    keys    the key columns of the merchant (default: [MERCHANT_COL]); the category rides along as a key
    edges   the histogram edges (default: SCORE_EDGES)

    Returns (by_merchant, by_account): one row per key, category and day with the columns of
    `value_cols`, and the same per account as well. A row without a score adds nothing. When
    the score column is None in settings or absent, one line is printed and (None, None) is
    returned, because nothing in this file can be built without it.
    """
    edges = SCORE_EDGES if edges is None else np.asarray(edges, dtype=np.float64)
    account_col = _panel.pick(account_col, "ACCOUNT_COL")
    keys = [_panel.pick(merchant_col, "MERCHANT_COL")] if keys is None else list(keys)
    score = _panel.optional(df, _panel.pick(score_col, "VISA_SCORE_COL"), "the network score view", numeric=True)
    if score is None:
        return None, None
    day = _panel.days(timekeys.seconds(df[_panel.pick(time_col, "TIME_COL")]), day_shift)
    cells = {k: df[k].to_numpy() for k in keys}
    mcc_col = _panel.pick(mcc_col, "MCC_COL")
    mcc = _panel.optional(df, mcc_col, "the category level of the prior")
    if mcc is not None and mcc_col not in cells:
        cells[mcc_col] = mcc
    group_keys = list(cells) + [DAY_COL]
    has = ~np.isnan(score)
    cells.update({DAY_COL: day, account_col: df[account_col].to_numpy(), "score_rows": has.astype(np.float64),
                  "score": np.nan_to_num(score, nan=0.0)})
    # One indicator column per bin: a row adds 1 to the bin its score falls in, and nothing when it has no score.
    which = bin_of(np.nan_to_num(score, nan=edges[0]), edges)
    for j, name in enumerate(bin_names(edges)):
        cells[name] = ((which == j) & has).astype(np.float64)
    frame = pd.DataFrame(cells)
    frame = frame[(day != MISSING_SECOND) & has]                    # rows in no day or with no score add nothing
    by_account = frame.groupby(group_keys + [account_col], dropna=False, sort=False, as_index=False).sum()
    by_merchant = by_account.drop(columns=account_col).groupby(group_keys, dropna=False, sort=False,
                                                               as_index=False).sum()
    return by_merchant, by_account


def combine(parts):
    """Add the tables of several files: a list of (by_merchant, by_account) in, one such pair out.

    The merchant tables are summed key by key; the per-account tables are stacked, because no
    account is in two files. An entry whose second part is None adds only its merchant table.
    """
    merchant = [part[0] for part in parts if part[0] is not None]
    own = [part[1] for part in parts if part[1] is not None]
    values = [c for c in (merchant[0].columns if merchant else []) if c == "score_rows" or c == "score"
              or (c.startswith("h") and c[1:].isdigit())]
    return (_panel.add_tables(merchant, values) if merchant else None,
            pd.concat(own, ignore_index=True) if own else None)


def visa_features(target, by_merchant, by_account=None, keys=None, edges=None, base_days=None, recent_days=None,
                  quantile=None, prior_rows=None, account_col=None, time_col=None, merchant_col=None, mcc_col=None,
                  score_col=None, day_shift=None, prefix="visa_"):
    """The network-score columns of every target row.

    target        raw rows to build columns for (account, time, merchant; category and own score when present)
    by_merchant   the added merchant-by-day table of the panel (from `build_visa_tables` and `combine`)
    by_account    the per-account table of the panel files that hold accounts of `target`; None when
                  no target account is in the panel
    keys          the merchant key columns the tables were built with (default: [MERCHANT_COL])
    base_days, recent_days   completed days in the two windows (default: BASE_DAYS, RECENT_DAYS)
    quantile      the percentile to read (default: QUANTILE)
    prior_rows    how many made-up rows of the broader level a mean or histogram starts with

    Returns a DataFrame [targets, 10 columns] with the index of `target` (fewer when the row's own
    score is not available). A value is missing only when no level at all holds a row.

    Time rule: a row on day d reads days d-1 and before, never its own day, so rows of the same
    day never see each other. The row's own account is subtracted at every level.
    """
    edges = SCORE_EDGES if edges is None else np.asarray(edges, dtype=np.float64)
    account_col = _panel.pick(account_col, "ACCOUNT_COL")
    keys = [_panel.pick(merchant_col, "MERCHANT_COL")] if keys is None else list(keys)
    mcc_col = _panel.pick(mcc_col, "MCC_COL")
    base_days = BASE_DAYS if base_days is None else int(base_days)
    recent_days = RECENT_DAYS if recent_days is None else int(recent_days)
    quantile = QUANTILE if quantile is None else quantile
    strength = _panel.PRIOR_ROWS if prior_rows is None else prior_rows
    if by_merchant is None:
        _panel.say_once("there is no score table; the network score view is skipped")
        return pd.DataFrame(index=target.index)
    day = _panel.days(timekeys.seconds(target[_panel.pick(time_col, "TIME_COL")]), day_shift)

    # The levels a value is pulled along, from the broadest to the narrowest.
    levels = [[]]
    if mcc_col and mcc_col not in keys and mcc_col in by_merchant.columns and mcc_col in target.columns:
        levels.append([mcc_col])
    else:
        _panel.say_once("the category level is skipped: its column is not in the table and the target rows")
    levels.append(keys)

    values = value_cols(edges)
    bins = slice(2, len(values))
    edge_list = sorted({base_days, recent_days})
    sums = [_panel.others_sums(by_merchant, by_account, level, DAY_COL, values, target, day, edge_list, account_col)
            for level in levels]

    out, mean, p90, hist = {}, {}, {}, {}
    for label, days in (("30d" if base_days == 30 else f"{base_days}d", base_days),
                        ("1d" if recent_days == 1 else f"{recent_days}d", recent_days)):
        at_key = sums[-1][days]
        out[f"{prefix}n_{label}"] = at_key[:, 0]
        mean[label] = _panel.chain([(s[days][:, 1], s[days][:, 0]) for s in sums], strength)
        # The histogram is smoothed level by level, like the mean: a thin merchant borrows the shape
        # of its category, which borrows the shape of all merchants. The broadest level stands alone.
        h = sums[0][days][:, bins]
        for s in sums[1:]:
            h = _panel.smooth_histogram(s[days][:, bins], h, strength)
        hist[label] = h
        p90[label] = _panel.histogram_quantile(h, edges, quantile)
        out[f"{prefix}mean_{label}"] = mean[label]
        out[f"{prefix}p90_{label}"] = p90[label]
    base, recent = list(mean)
    out[f"{prefix}recent_minus_base_mean"] = mean[recent] - mean[base]
    out[f"{prefix}recent_minus_base_p90"] = p90[recent] - p90[base]

    own = _panel.optional(target, _panel.pick(score_col, "VISA_SCORE_COL"), "the row's own score against the merchant",
                          numeric=True)
    if own is not None:
        out[f"{prefix}own_minus_base"] = own - mean[base]
        out[f"{prefix}own_pct_{base}"] = _panel.histogram_rank(hist[base], edges, own)
    return _panel.as_frame(out, target.index)


def main(argv=None):
    """Command line: add the score tables of the panel files and print the columns of the target rows."""
    def of_file(df, held):
        # The per-account table is kept only for files that hold target rows: only their accounts
        # ever have to be taken out.
        by_merchant, by_account = build_visa_tables(df)
        return by_merchant, (by_account if held else None)

    def features(target, part, args):
        return visa_features(target, part[0], part[1])

    return _panel.run_tool(argv, "The network risk score averaged over other accounts at the merchant.",
                           needed_columns(), of_file, combine, features)


if __name__ == "__main__":
    main()
