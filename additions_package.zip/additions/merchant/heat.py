"""Merchant heat: how the model's own scores ran on OTHER accounts' earlier rows at this merchant.

What this file does
-------------------
Per file of scored rows (`build_heat_tables`) rows are grouped by merchant and calendar day,
and each group keeps the number of scored rows, the sum of their scores in log-odds, the
number of rows at or above the alert cut and a histogram of the log-odds. The same sums are
kept per merchant, day and account, so that an account's own rows can be subtracted. Tables
of many files are simply added (`combine`).

For a target row (`heat_features`) and each window of 1, 7 and 30 completed days that ends
the day before the row:

    heat_n_<w>             scored rows of other accounts at the merchant (the evidence)
    heat_mean_<w>          their mean score, in log-odds
    heat_p90_<w>           the 90th percentile of their scores, in log-odds, read from the histogram
    heat_alert_share_<w>   the share of their rows at or above the alert cut
    heat_prev_mean_<w>, heat_prev_alert_share_<w>
                           the same two values of the account's previous row: the heat of the
                           merchant the account used just before, in its latest strictly earlier
                           second (averaged when that second holds several rows)

Means, shares and histograms are pulled toward broader keys by the number of rows seen: all
merchants, the merchant's category, its category in its state, then the merchant itself.

Why it exists
-------------
A merchant where cards are being tested, or whose card data has leaked, shows up in the
scores of other accounts long before any fraud there is reported: fraud labels arrive weeks
after the transaction, while a score exists the moment a row is scored. The model already
reads each account's own history; it cannot read what happened to other accounts at the
same place. Heat hands it that view, and gives a downstream tree model a label-free
merchant risk value that moves within a day. The heat of the previous merchant covers the
common case in which an account is used at a compromised place and then elsewhere.

The scores must come from a model that did not train on the panel rows. A model's score on
its own training rows is pulled toward their labels, so heat built from such scores would
carry labels of other accounts into the input, which the time rule forbids. Score the
panel with a model fitted on other files (the files hold whole accounts, so a file split is
clean). Labels themselves are never read here.

The rules of this folder hold here too. A merchant's rows are present only for the
accounts in the files that were read, so the tables are a sample, built from a panel that
is separate from the rows a model is fitted on. The row's own account is taken out, because
frauds come in runs on one account and the account's own high scores would otherwise come
back to it as merchant heat. Only completed days are read. Only means, shares and
percentiles are offered, each with its count; a maximum, a number of distinct accounts or a
raw count would move with the share of accounts sampled.

Where it goes
-------------
After scores. A first scoring pass writes scores for the panel files (an export keyed by
transaction id); this file turns them into columns for the second stage: a downstream tree
model joins them by transaction id. Fed back into the network they become numeric inputs
(appended in `SequenceBuilder._encode_file` in the original code, one numeric token each in
`FeatureTokenizer`); that is a second training round and needs the same out-of-sample rule.

What to change for the pod
--------------------------
settings.py: ACCOUNT_COL, TIME_COL, ID_COL, MERCHANT_COL, MCC_COL, MERCHANT_STATE_COL,
SCORE_COL, SCORE_KIND, OUTSORT_PER_MILLE. In _panel.py: PANEL_BASE, PANEL_FILES,
DAY_SHIFT_SECONDS, PRIOR_ROWS. Here: ALERT_CUT_LOGIT (the alert cut as one fixed number),
HEAT_EDGES (histogram bins in log-odds), WINDOWS and QUANTILE. On the command line `--scores`
names the score export of the panel files.

How to try it
-------------
    python additions/merchant/heat.py --demo
    python additions/merchant/heat.py --panel-files 8000 8001 --files 8217 \
        --scores panel_scores.parquet --out heat.parquet

    cut = alert_cut(scored_panel[settings.SCORE_COL])
    by_merchant, by_account = combine([build_heat_tables(df, cut) for df in scored_panel_frames])
    columns = heat_features(target, by_merchant, by_account)
    python -m pytest -q additions/tests/test_merchant_heat.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd

from additions import settings
from additions.common import ranking, synthetic, tables, timekeys
from additions.common.history import EarlierRows
from additions.common.timekeys import MISSING_SECOND
from additions.merchant import _panel

# The name of the day column of the tables: whole days since 1970-01-01.
DAY_COL = "day"

# Windows as (label, completed days ending the day before the row).
WINDOWS = (("1d", 1), ("7d", 7), ("30d", 30))

# PLACEHOLDER: the alert cut in log-odds as one fixed number (the cut used in production, or the cut
# measured on an earlier month). None takes it from the scores of the first panel file.
ALERT_CUT_LOGIT = None

# PLACEHOLDER: the edges of the score histogram in log-odds; scores outside fall into the end bins.
HEAT_EDGES = np.linspace(-12.0, 6.0, 25)

# The percentile read from the histograms (0.9 is the 90th percentile).
QUANTILE = 0.9


def bin_names(edges=None):
    """The names of the histogram columns of the tables: h0, h1, ... one per bin."""
    edges = HEAT_EDGES if edges is None else edges
    return [f"h{j}" for j in range(len(edges) - 1)]


def value_cols(edges=None):
    """All value columns of the tables: scored rows, the log-odds sum, rows above the cut and the bins."""
    return ["rows", "logit", "above"] + bin_names(edges)


def needed_columns():
    """The raw columns the tables read; the score column may also come from a separate export."""
    return [settings.ACCOUNT_COL, settings.TIME_COL, settings.ID_COL, settings.MERCHANT_COL, settings.MCC_COL,
            settings.MERCHANT_STATE_COL, settings.SCORE_COL]


def alert_cut(scores, kind=None, per_mille=None):
    """The alert cut in log-odds: the score of the last row inside the top share of `scores`.

    scores   float [rows]: model scores of some rows (a probability or log-odds, see `kind`)

    The cut is meant to be computed once and then held fixed for every table, so that a share
    "above the cut" means the same thing at every merchant and on every day.
    """
    logit = ranking.to_logit(np.asarray(scores, dtype=np.float64)[~pd.isna(scores)], kind)
    k = max(ranking.cut_size(len(logit), per_mille), 1)
    return float(np.sort(logit)[::-1][min(k, len(logit)) - 1]) if len(logit) else np.inf


def build_heat_tables(df, cut_logit=None, edges=None, account_col=None, time_col=None, merchant_col=None,
                      mcc_col=None, state_col=None, score_col=None, score_kind=None, day_shift=None):
    """The merchant-by-day heat sums of one file of scored rows (or of any table of whole accounts).

    df          raw rows with a model score; the column names default to settings.py
    cut_logit   the alert cut in log-odds (default: ALERT_CUT_LOGIT, else the cut of `df` itself)
    edges       the histogram edges in log-odds (default: HEAT_EDGES)

    Returns (by_merchant, by_account): one row per merchant, category, state and day with the
    columns of `value_cols`, and the same per account as well. A row without a score adds
    nothing. Without a score column one line is printed and (None, None) is returned.
    """
    edges = HEAT_EDGES if edges is None else np.asarray(edges, dtype=np.float64)
    account_col, merchant_col = _panel.pick(account_col, "ACCOUNT_COL"), _panel.pick(merchant_col, "MERCHANT_COL")
    score = _panel.optional(df, _panel.pick(score_col, "SCORE_COL"), "the merchant heat", numeric=True)
    if score is None:
        return None, None
    has = ~np.isnan(score)
    logit = np.where(has, ranking.to_logit(np.nan_to_num(score, nan=0.5), score_kind), 0.0)
    if cut_logit is None:
        cut_logit = ALERT_CUT_LOGIT if ALERT_CUT_LOGIT is not None else alert_cut(score[has], score_kind)
    day = _panel.days(timekeys.seconds(df[_panel.pick(time_col, "TIME_COL")]), day_shift)
    cells = {merchant_col: df[merchant_col].to_numpy()}
    for name, what in ((_panel.pick(mcc_col, "MCC_COL"), "the category level of the prior"),
                       (_panel.pick(state_col, "MERCHANT_STATE_COL"), "the category-by-state level of the prior")):
        values = _panel.optional(df, name, what)
        if values is not None:
            cells[name] = values
    keys = list(cells) + [DAY_COL]
    cells.update({DAY_COL: day, account_col: df[account_col].to_numpy(), "rows": has.astype(np.float64),
                  "logit": logit, "above": (has & (logit >= cut_logit)).astype(np.float64)})
    which = np.clip(np.searchsorted(edges, logit, side="right") - 1, 0, len(edges) - 2)
    for j, name in enumerate(bin_names(edges)):
        cells[name] = ((which == j) & has).astype(np.float64)
    frame = pd.DataFrame(cells)
    frame = frame[(day != MISSING_SECOND) & has]                    # rows in no day or with no score add nothing
    by_account = frame.groupby(keys + [account_col], dropna=False, sort=False, as_index=False).sum()
    by_merchant = by_account.drop(columns=account_col).groupby(keys, dropna=False, sort=False, as_index=False).sum()
    return by_merchant, by_account


def combine(parts):
    """Add the tables of several files: a list of (by_merchant, by_account) in, one such pair out.

    The merchant tables are summed key by key; the per-account tables are stacked, because no
    account is in two files. An entry whose second part is None adds only its merchant table.
    """
    merchant = [part[0] for part in parts if part[0] is not None]
    own = [part[1] for part in parts if part[1] is not None]
    if not merchant:
        return None, None
    values = ["rows", "logit", "above"] + [c for c in merchant[0].columns if c.startswith("h") and c[1:].isdigit()]
    return _panel.add_tables(merchant, values), (pd.concat(own, ignore_index=True) if own else None)


def _levels(table, target, merchant_col, mcc_col, state_col):
    """The keys a value is pulled along, from the broadest to the narrowest, as a list of key-column lists."""
    def usable(cols):
        return all(c and c in table.columns and c in target.columns for c in cols)

    levels = [[]]
    for name, cols in (("category", [mcc_col]), ("category-by-state", [mcc_col, state_col])):
        if usable(cols):
            levels.append(cols)
        else:
            _panel.say_once(f"the {name} level is skipped: its columns are not in the table and the target rows")
    return levels + [[merchant_col]]


def heat_features(target, by_merchant, by_account=None, edges=None, windows=None, quantile=None, prior_rows=None,
                  account_col=None, time_col=None, merchant_col=None, mcc_col=None, state_col=None, day_shift=None,
                  prefix="heat_"):
    """The heat columns of every target row.

    target        raw rows to build columns for (account, time, merchant; category and state when present).
                  For the previous-merchant columns it should hold every row of its accounts, including the
                  month before the scored month, so that the first scored row has a previous row
    by_merchant   the added merchant-by-day heat table of the scored panel
    by_account    the per-account table of the panel files that hold accounts of `target`; None when
                  no target account is in the panel
    windows       ((label, days), ...) (default: WINDOWS)
    quantile      the percentile to read (default: QUANTILE)
    prior_rows    how many made-up rows of the broader level a mean, share or histogram starts with

    Returns a DataFrame [targets, 6 columns per window] with the index of `target`.

    Time rule: a row on day d reads days d-1 and before at the merchant, never its own day, and
    the previous-merchant columns come from the account's rows of its latest strictly earlier
    second, read as they stood for those rows. The row's own account is subtracted at every level.
    """
    edges = HEAT_EDGES if edges is None else np.asarray(edges, dtype=np.float64)
    account_col, merchant_col = _panel.pick(account_col, "ACCOUNT_COL"), _panel.pick(merchant_col, "MERCHANT_COL")
    windows = WINDOWS if windows is None else windows
    quantile = QUANTILE if quantile is None else quantile
    strength = _panel.PRIOR_ROWS if prior_rows is None else prior_rows
    if by_merchant is None:
        _panel.say_once("there is no heat table; the merchant heat is skipped")
        return pd.DataFrame(index=target.index)
    secs = timekeys.seconds(target[_panel.pick(time_col, "TIME_COL")])
    day = _panel.days(secs, day_shift)
    levels = _levels(by_merchant, target, merchant_col, _panel.pick(mcc_col, "MCC_COL"),
                     _panel.pick(state_col, "MERCHANT_STATE_COL"))
    values = value_cols(edges)
    bins = slice(3, len(values))
    edge_list = sorted({days for _, days in windows})
    sums = [_panel.others_sums(by_merchant, by_account, level, DAY_COL, values, target, day, edge_list, account_col)
            for level in levels]

    out = {}
    for label, days in windows:
        out[f"{prefix}n_{label}"] = sums[-1][days][:, 0]
        out[f"{prefix}mean_{label}"] = _panel.chain([(s[days][:, 1], s[days][:, 0]) for s in sums], strength)
        # The histogram is smoothed level by level like the mean: a thin merchant borrows the shape of
        # its category in its state, which borrows from the category, which borrows from all merchants.
        hist = sums[0][days][:, bins]
        for s in sums[1:]:
            hist = _panel.smooth_histogram(s[days][:, bins], hist, strength)
        out[f"{prefix}p90_{label}"] = _panel.histogram_quantile(hist, edges, quantile)
        out[f"{prefix}alert_share_{label}"] = _panel.chain([(s[days][:, 2], s[days][:, 0]) for s in sums], strength)

    # The heat of the previous row's merchant: the account's rows in its latest strictly earlier second.
    # Rows of the same second are never each other's previous row, because their order is unknown. For
    # the same reason, when the latest earlier second holds several rows, their values are averaged
    # instead of one of them being picked by an order that the timestamps cannot support.
    account_codes = timekeys.codes(target[account_col].to_numpy())
    gap = EarlierRows(account_codes, secs).seconds_since_last()
    # The second of the previous row; a row without one starts its look-back at its own second, so it reads nothing.
    previous_second = np.where(np.isnan(gap), secs, secs - np.nan_to_num(gap).astype(np.int64))
    previous = EarlierRows(account_codes, secs, start=previous_second)
    for label, _ in windows:
        for name in ("mean", "alert_share"):
            out[f"{prefix}prev_{name}_{label}"] = previous.mean(out[f"{prefix}{name}_{label}"])
    order = [f"{prefix}{name}_{label}" for label, _ in windows
             for name in ("n", "mean", "p90", "alert_share", "prev_mean", "prev_alert_share")]
    return _panel.as_frame({name: out[name] for name in order}, target.index)


def main(argv=None):
    """Command line: heat tables from the scored panel files, and the heat columns of the target rows."""
    def more(parser):
        parser.add_argument("--scores", nargs="+", default=None,
                            help="parquet file(s) with the transaction id and the score of the panel rows")
        parser.add_argument("--cut", type=float, default=None,
                            help="the alert cut in log-odds (default: ALERT_CUT_LOGIT, else from the first panel file)")

    first = argparse.ArgumentParser(add_help=False)
    more(first)
    first.add_argument("--demo", action="store_true")
    known, _ = first.parse_known_args(argv)
    id_col, score_col = settings.ID_COL, settings.SCORE_COL
    scores = None
    if known.scores:
        # The score export is read once and joined to each panel file by transaction id.
        frames = [tables.read_columns(path, [id_col, score_col]) for path in known.scores]
        scores = pd.concat(frames, ignore_index=True).drop_duplicates(id_col).set_index(id_col)[score_col]
    state = {"cut": known.cut if known.cut is not None else ALERT_CUT_LOGIT}

    def of_file(df, held):
        if scores is not None:
            df[score_col] = df[id_col].map(scores).to_numpy()
        elif known.demo and score_col not in df.columns:
            # Made-up scores for the demo only. They are drawn from the label, which is read for this alone
            # and dropped at once, so that nothing below can read a label.
            df[score_col] = synthetic.make_scores(df)[score_col].to_numpy()
            df.drop(columns=[settings.LABEL_COL], inplace=True)
        if state["cut"] is None and score_col in df.columns:
            state["cut"] = alert_cut(df[score_col].to_numpy(dtype=np.float64))
            print(f"alert cut in log-odds, from the first panel file: {state['cut']:.4f}")
        by_merchant, by_account = build_heat_tables(df, state["cut"])
        return by_merchant, (by_account if held else None)

    def features(target, part, args):
        return heat_features(target, part[0], part[1])

    columns = needed_columns() + ([settings.LABEL_COL, settings.VISA_SCORE_COL] if known.demo else [])
    return _panel.run_tool(argv, "Merchant heat from the model's scores on other accounts' earlier rows.",
                           columns, of_file, combine, features, more)


if __name__ == "__main__":
    main()
