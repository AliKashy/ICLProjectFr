"""How merchant columns depend on the share of accounts sampled, and one model for thin and full tables.

What this file does
-------------------
Part one measures the coverage curve. The merchant-by-day table of day_tables.py is built from
nested panels: the first 5, 10, 20 and 50 percent of a shuffled list of panel files, and all of
them. Each smaller panel is part of every larger one, so the panels differ only in how many
accounts they sampled. The merchant columns of the same target rows are computed from each
panel and compared with the columns of the largest panel (`compare`):

    panel_files, coverage   the number of files in the panel and the share of all accounts it holds
    missing                 share of target rows where the column is missing
    mean, mean_ratio        the column's mean, and that mean over the largest panel's mean
    corr                    correlation with the largest panel's column on rows where both are present
    mean_abs_diff           mean absolute difference from the largest panel's column
    ap                      average precision of the column alone (the better of its two directions),
                            when the target rows carry labels

Part two is coverage-conditioned training (`coverage_conditioned`). Each merchant column is
computed from several panels; for every row one panel is picked at random and the row gets that
panel's columns together with the log of the panel's coverage. A model trained this way has
seen thin and full tables and knows which one it is reading, so it can be served with a table
of another coverage by giving it that coverage (`with_coverage`).

Why it exists
-------------
The files hold whole accounts and only some accounts are in the files read, so every merchant
table is a sample. A rate keeps its expected value when fewer accounts are sampled but becomes
noisier, the counts beside it shrink in proportion, and merchants with few rows drop out
altogether. How much of a merchant column's value survives a thin panel is therefore not known
in advance: the curve says whether a larger panel, or a full table from the data owner, would
be worth more than any modelling change. A model trained on columns from one coverage and served
with another reads sharper or blurrier columns than it learned; the coverage input is meant to
absorb that difference.

The rules of this folder carry over unchanged, because every panel is turned into columns by
day_tables.py: the row's own account is removed, only completed earlier days are read, and
rates are pulled toward a prior. The count columns are the ones expected to move with coverage
(`mean_ratio` close to the ratio of the coverages); the rates should not.

Where it goes
-------------
Raw files, then nested merchant tables, then feature columns. The comparison table is a
measurement read before deciding how large a panel to build. The coverage-conditioned columns
replace the plain merchant columns as numeric inputs of the network (added in
`SequenceBuilder._encode_file` in the original code, one numeric token each in
`FeatureTokenizer`) or as columns of a second-stage tree model, joined by transaction id.

What to change for the pod
--------------------------
settings.py: the columns read by day_tables.py and LABEL_COL, POSITIVE_LABEL. In _panel.py:
PANEL_BASE, PANEL_FILES. Here: ALL_FILES (how many files the whole account population is split
into), SHARES, SEED and COVERAGE_COL. The comparison reads labels of the target rows only as a
measurement; they never enter a column. To measure the curve on training months, pass target
rows from those months and a panel that covers the days before them.

How to try it
-------------
    python additions/merchant/coverage.py --demo
    python additions/merchant/coverage.py --panel-files 8000 8001 8002 8003 --files 8217 \
        --table-out curve.csv --out mixed.parquet

    parts = [day_tables.build_day_tables(df) for df in panel_frames]
    panels = nested_panels(parts)
    frames = features_by_panel(target, panels)
    print(compare(frames, labels))
    mixed = coverage_conditioned(frames, {n: panel["coverage"] for n, panel in panels.items()})
    python -m pytest -q additions/tests/test_merchant_coverage.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np
import pandas as pd

from additions import settings
from additions.common import ranking
from additions.merchant import _panel, day_tables

# PLACEHOLDER: the number of files the whole account population is split into. The coverage of a
# panel is its number of files over this number.
ALL_FILES = 10_000

# Shares of the panel files that form the nested panels. 1.0 is the whole panel and serves as the reference.
SHARES = (0.05, 0.1, 0.2, 0.5, 1.0)

# The seed of the shuffle of the panel files and of the random pick of a panel per row.
SEED = 0

# PLACEHOLDER: the name of the column that tells the model the log of the coverage of its merchant columns.
COVERAGE_COL = "merchant_log_coverage"


def nested_panels(parts, shares=None, all_files=None, seed=None):
    """Nested panels from per-file tables: {number of files: {"coverage": share, "tables": (by_merchant, by_account)}}.

    parts      a list with one (by_merchant, by_account) per panel file, as `day_tables.build_day_tables`
               returns it; by_account may be None for a file that holds no target account
    shares     shares of the files in each panel (default: SHARES); each gives at least one file
    all_files  the number of files of the whole population (default: ALL_FILES)

    The files are shuffled once, and a panel of n files takes the first n of that order, so
    every panel is part of every larger one. Shares that give the same number of files give
    one panel. The tables are added with `day_tables.combine`, exactly as for a single panel.
    """
    shares = SHARES if shares is None else shares
    all_files = ALL_FILES if all_files is None else all_files
    order = np.random.default_rng(SEED if seed is None else seed).permutation(len(parts))
    panels = {}
    for share in sorted(shares):
        n = int(min(max(round(float(share) * len(parts)), 1), len(parts)))
        if n not in panels:
            panels[n] = {"coverage": n / float(all_files), "tables": day_tables.combine([parts[i] for i in order[:n]])}
    return panels


def features_by_panel(target, panels, **options):
    """The merchant-by-day columns of the target rows from every panel: {number of files: DataFrame}.

    options are passed on to `day_tables.day_features` (windows, priors, column names). Each
    frame has the index of `target` and the same columns.

    A small panel often holds none of the target accounts. Its per-account table then has
    nothing to take out and is passed as None, which is what `day_features` expects in that case.
    """
    account_col = options.get("account_col") or settings.ACCOUNT_COL
    accounts = pd.unique(target[account_col])
    frames = {}
    for n, panel in panels.items():
        by_merchant, by_account = panel["tables"]
        if by_account is not None and not by_account[account_col].isin(accounts).any():
            by_account = None
        frames[n] = day_tables.day_features(target, by_merchant, by_account, **options)
    return frames


def _best_ap(labels, values):
    """Average precision of one column read in its better direction; a missing value ranks last."""
    v = np.asarray(values, dtype=np.float64)
    if np.isnan(v).all():
        return np.nan
    low, high = np.nanmin(v), np.nanmax(v)
    up = ranking.average_precision(labels, np.where(np.isnan(v), low - 1.0, v))
    down = ranking.average_precision(labels, np.where(np.isnan(v), -high - 1.0, -v))
    return max(a for a in (up, down) if a is not None) if (up is not None or down is not None) else np.nan


def compare(frames, labels=None, coverages=None):
    """The coverage curve as a table: one row per column and panel (see the top of the file).

    frames      {number of files: DataFrame of merchant columns}, all for the same target rows
    labels      optional 1/0 per target row; it is used only to measure each column's signal
    coverages   optional {number of files: coverage} to print beside the number of files

    The largest panel is the reference. Returns a DataFrame sorted by column and panel size.
    """
    reference_n = max(frames)
    reference = frames[reference_n]
    y = None if labels is None else np.asarray(labels, dtype=np.float64)
    rows = []
    for n in sorted(frames):
        frame = frames[n]
        for name in frame.columns:
            v = frame[name].to_numpy(dtype=np.float64)
            r = reference[name].to_numpy(dtype=np.float64)
            both = ~np.isnan(v) & ~np.isnan(r)
            ref_mean = np.nanmean(r) if (~np.isnan(r)).any() else np.nan
            mean = np.nanmean(v) if (~np.isnan(v)).any() else np.nan
            corr = np.nan
            if both.sum() > 2 and v[both].std() > 0 and r[both].std() > 0:
                corr = float(np.corrcoef(v[both], r[both])[0, 1])
            row = {"column": name, "panel_files": n, "coverage": (coverages or {}).get(n, np.nan),
                   "missing": float(np.isnan(v).mean()), "mean": mean,
                   "mean_ratio": mean / ref_mean if ref_mean not in (0.0,) and not np.isnan(ref_mean) else np.nan,
                   "corr": corr, "mean_abs_diff": float(np.abs(v[both] - r[both]).mean()) if both.any() else np.nan}
            if y is not None:
                row["ap"] = _best_ap(y, v)
            rows.append(row)
    return pd.DataFrame(rows).sort_values(["column", "panel_files"], kind="stable").reset_index(drop=True)


def coverage_conditioned(frames, coverages, accounts=None, seed=None, coverage_col=None):
    """Columns from a randomly picked panel per row, plus the log of that panel's coverage.

    frames      {key: DataFrame}, the same columns and index for every key (from `features_by_panel`)
    coverages   {key: coverage share} for the same keys
    accounts    optional account per row: then one pick is made per account instead of per row,
                so that all rows of an account read the same panel
    seed        the seed of the pick (default: SEED)

    Returns a DataFrame [rows, columns + 1] with the index of the frames. Every row's values are
    exactly those of one panel; the added column holds the log of that panel's coverage.
    """
    coverage_col = COVERAGE_COL if coverage_col is None else coverage_col
    keys = sorted(frames)
    first = frames[keys[0]]
    stack = np.stack([frames[k][first.columns].to_numpy(dtype=np.float64) for k in keys])   # [panels, rows, columns]
    rng = np.random.default_rng(SEED if seed is None else seed)
    if accounts is None:
        pick = rng.integers(0, len(keys), len(first))
    else:
        unit = pd.factorize(pd.Series(np.asarray(accounts)))[0]
        pick = rng.integers(0, len(keys), unit.max() + 1 if len(unit) else 0)[unit]
    out = pd.DataFrame(stack[pick, np.arange(len(first))], columns=first.columns, index=first.index)
    log_coverage = np.log(np.array([coverages[k] for k in keys], dtype=np.float64))
    out[coverage_col] = log_coverage[pick]
    return out.astype(_panel.FLOAT)


def with_coverage(frame, coverage, coverage_col=None):
    """The serving side: the merchant columns of one panel with its log coverage added as a constant column."""
    out = frame.copy()
    out[COVERAGE_COL if coverage_col is None else coverage_col] = np.log(float(coverage))
    return out.astype(_panel.FLOAT)


def main(argv=None):
    """Command line: nested panels from the panel files, the coverage curve, and coverage-conditioned columns."""
    def of_file(df, held):
        # Each file's tables are kept apart (in a one-item list) until the panels are cut. The
        # per-account table is kept only for files that hold target rows.
        by_merchant, by_account = day_tables.build_day_tables(df)
        return [(by_merchant, by_account if held else None)]

    def keep_apart(parts):
        # The shared command line adds parts as they come in; here "adding" only gathers the
        # per-file tables into one list, because the panels are cut from them afterwards.
        return [p for part in parts for p in part]

    def features(target, parts, args):
        panels = nested_panels(parts, args.shares, args.all_files, args.seed)
        frames = features_by_panel(target, panels)
        labels = None
        label_col = settings.LABEL_COL
        if label_col and label_col in target.columns:
            labels = _panel.is_one_of(target[label_col].to_numpy(), (settings.POSITIVE_LABEL,)).astype(float)
        curve = compare(frames, labels, {n: p["coverage"] for n, p in panels.items()})
        print(curve.to_string(index=False, float_format=lambda x: f"{x:.4f}"))
        if args.table_out:
            curve.to_csv(args.table_out, index=False)
            print(f"written: {args.table_out}")
        accounts = target[settings.ACCOUNT_COL].to_numpy() if args.per_account else None
        return coverage_conditioned(frames, {n: p["coverage"] for n, p in panels.items()}, accounts, args.seed)

    def more(parser):
        parser.add_argument("--shares", type=float, nargs="+", default=None,
                            help="shares of the panel files in the nested panels (default: SHARES)")
        parser.add_argument("--all-files", type=int, default=None,
                            help="files of the whole account population (default: ALL_FILES)")
        parser.add_argument("--seed", type=int, default=None,
                            help="seed of the shuffle and of the pick (default: SEED)")
        parser.add_argument("--per-account", action="store_true", help="pick one panel per account instead of per row")
        parser.add_argument("--table-out", default=None, help="write the coverage curve to this csv file")

    return _panel.run_tool(argv,
                           "Merchant columns from nested panels: the coverage curve and coverage-conditioned columns.",
                           day_tables.needed_columns(), of_file, keep_apart, features, more)


if __name__ == "__main__":
    main()
