"""Merchant vectors learned from inside accounts, and how well a merchant fits the account's habits.

What this file does
-------------------
Step one, per file (`count_pairs`): for every account, every pair of different merchants it
used within 7 days of each other is counted once. The pair table holds, for each pair of
merchants, the number of accounts that used both close together. A small merchant table holds
each merchant's number of accounts, its category and its postal code.

Step two, once for the whole panel (`fit_vectors`): merchants with few accounts are replaced by
a stand-in for their category and postal code, or for their category when that is thin too.
The pair counts are turned into positive pointwise mutual information (how much more often two
merchants share customers than their popularity alone would give) and a truncated singular
value decomposition (scipy sparse) compresses that matrix to 32 numbers per merchant.

Step three, per target row (`covisit_features`):

    cov_affinity_30d     cosine between the merchant's vector and the mean vector of the merchants
                         the account used in the last 30 days (strictly earlier seconds): a graded
                         "would this account shop here"
    cov_affinity_n_30d   the number of earlier rows of the account behind that mean (the evidence)
    cov_log_share        log of the merchant's share of all account visits in the table (popularity)
    cov_unknown          1 when the merchant has no token of its own or of a stand-in: it is not in
                         the table, or it is thin and has no category to fall back on
    cov_level            which vector was used: 0 the merchant's own, 1 its category by postal code,
                         2 its category, 3 none
    cov_v_<j>            the vector itself, when asked for (`with_vectors=True`)

Why it exists
-------------
A first visit to a merchant whose customers resemble the account's usual merchants is
ordinary; a first visit to a merchant from an unrelated crowd is not. An exact "seen before"
flag cannot tell these apart, and a merchant category is too coarse to: two grocery stores
in different towns or price ranges serve different crowds. The vectors carry merchant
identity beyond the category (price point, area, kind of customer), learned without labels.
Stolen cards are used where the thief shops, not where the cardholder does, so a low
affinity on an otherwise ordinary row is a useful signal for a network or a tree model.

Unlike the other tables of this folder, these counts are not thinned by account sampling. The
files hold whole accounts, and each pair comes from inside one account, so a panel of a fifth
of the accounts sees each pair in about a fifth of the accounts that made it: the pointwise
mutual information keeps its expected value. Only the popularity is offered as a share, never
as a raw count, for the same reason. The unknown flag does depend on the panel (an unsampled
merchant looks unknown), so a model should be trained and served with tables of the same size.

The table is cross-account information, so the rules of this folder apply. It is built from
rows before `TABLE_END`, which lies before the target rows, and from panel files that hold no
target account (the command line leaves such files out of the counts, and `count_pairs` takes
a list of accounts to leave out). The affinity itself reads only the account's own rows of
strictly earlier seconds; rows of the same second never see each other.

Where it goes
-------------
Raw files, then this table, then feature columns. For the network the columns join the
numeric inputs before preprocessing (the per-file step `SequenceBuilder._encode_file` in the
original code, one numeric token each in `FeatureTokenizer`); the vector can also be a frozen
input token for the current merchant in stage 1. For a second-stage tree model the columns
are joined by transaction id. The vector table itself is an export other models can join by
merchant id; its coordinates change from one fit to the next, so a model must be served with
the table it was trained with.

What to change for the pod
--------------------------
settings.py: ACCOUNT_COL, TIME_COL, MERCHANT_COL, MCC_COL, MERCHANT_POSTAL_COL. In _panel.py:
PANEL_BASE, PANEL_FILES, DAY_SHIFT_SECONDS. Here: TABLE_END, PAIR_DAYS, MAX_LAG, MIN_ACCOUNTS,
DIM, CONTEXT_POWER and AFFINITY_DAYS. The merchant id must be one stable mapping across files
and months, or the table is noise. Online and card-present merchants can be given separate
tables by filtering the rows before `count_pairs`.

How to try it
-------------
    python additions/merchant/covisit_vectors.py --demo
    python additions/merchant/covisit_vectors.py --panel-files 8000 8001 8002 --files 8217 --out covisit.parquet

    pairs, merchants = combine([count_pairs(df) for df in panel_frames])
    table = fit_vectors(pairs, merchants)
    columns = covisit_features(target, table)
    python -m pytest -q additions/tests/test_merchant_covisit_vectors.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np
import pandas as pd
from scipy import sparse
from scipy.sparse.linalg import svds

from additions import settings
from additions.common import tables, timekeys
from additions.common.history import EarlierRows
from additions.common.timekeys import MISSING_SECOND
from additions.merchant import _panel

# PLACEHOLDER: the first day NOT counted into the table (text). None means settings.TARGET_START,
# so the table is fitted on rows before the scored month. When the columns are built for
# training rows of earlier months, put the first day of the earliest of those rows here, so
# that the table never holds visits made after a row it is used on.
TABLE_END = None

# PLACEHOLDER: two visits of one account form a pair when their days are at most this far apart.
PAIR_DAYS = 7

# PLACEHOLDER: how many later visits of the same account each visit is paired with at most. It
# bounds the work for very busy accounts; with 200 it is rarely reached.
MAX_LAG = 200

# PLACEHOLDER: a merchant with fewer accounts than this gets the vector of its category by postal
# code (or of its category) instead of its own.
MIN_ACCOUNTS = 20

# PLACEHOLDER: the number of numbers per merchant.
DIM = 32

# How strongly the popularity of the second merchant of a pair is flattened before the mutual
# information is computed. 0.75 is the usual value; it keeps rare merchants from scoring too high.
CONTEXT_POWER = 0.75

# Window of the account's own earlier rows for the affinity, in days.
AFFINITY_DAYS = 30

# Codes of `cov_level`.
OWN, CATEGORY_POSTAL, CATEGORY, NONE = 0, 1, 2, 3


def needed_columns():
    """The raw columns the table reads (None entries are optional columns that are switched off)."""
    return [settings.ACCOUNT_COL, settings.TIME_COL, settings.ID_COL, settings.MERCHANT_COL, settings.MCC_COL,
            settings.MERCHANT_POSTAL_COL]


def count_pairs(df, end=None, exclude_accounts=None, account_col=None, time_col=None, merchant_col=None,
                mcc_col=None, postal_col=None, pair_days=None, max_lag=None, day_shift=None):
    """Step one: the merchant pairs and the merchant table of one file (or any table of whole accounts).

    df                raw rows; the column names default to settings.py and can be passed one by one
    end               rows at or after this day (text) are not counted (default: TABLE_END)
    exclude_accounts  accounts whose rows are not counted, for example the accounts of the target rows

    Returns (pairs, merchants):
      pairs       DataFrame [merchant_a, merchant_b, accounts]: accounts that used both merchants
                  within `pair_days` days. Both orders of a pair are stored, so the table is symmetric.
      merchants   DataFrame [merchant, category, postal code, accounts]: accounts per merchant
    """
    account_col, merchant_col = _panel.pick(account_col, "ACCOUNT_COL"), _panel.pick(merchant_col, "MERCHANT_COL")
    pair_days = PAIR_DAYS if pair_days is None else int(pair_days)
    max_lag = MAX_LAG if max_lag is None else int(max_lag)
    end = TABLE_END if end is None else end
    end = settings.TARGET_START if end is None else end
    secs = timekeys.seconds(df[_panel.pick(time_col, "TIME_COL")])
    merchant = df[merchant_col].to_numpy()
    keep = (secs != MISSING_SECOND) & ~np.asarray(pd.isna(merchant), dtype=bool)
    keep &= secs < int(pd.Timestamp(end).timestamp())          # only rows before the table's end
    if exclude_accounts is not None:
        keep &= ~df[account_col].isin(list(exclude_accounts)).to_numpy()
    cells = {account_col: df[account_col].to_numpy()[keep], merchant_col: merchant[keep],
             "day": _panel.days(secs[keep], day_shift)}
    extra = []
    for name, what in ((_panel.pick(mcc_col, "MCC_COL"), "the category fallback of the merchant vectors"),
                       (_panel.pick(postal_col, "MERCHANT_POSTAL_COL"),
                        "the postal-code fallback of the merchant vectors")):
        values = _panel.optional(df, name, what)
        if values is not None:
            cells[name] = values[keep]
            extra.append(name)
    rows = pd.DataFrame(cells)

    merchants = rows.drop_duplicates([account_col, merchant_col])
    merchants = merchants.groupby(merchant_col, sort=False, dropna=False).agg(
        **{name: (name, "first") for name in extra}, accounts=(account_col, "size")).reset_index()

    # One visit per account, merchant and day, ordered by account and day.
    visits = rows[[account_col, merchant_col, "day"]].drop_duplicates()
    order = timekeys.stable_order(timekeys.codes(visits[account_col].to_numpy()), visits["day"].to_numpy())
    acct = timekeys.codes(visits[account_col].to_numpy())[order]
    merch = visits[merchant_col].to_numpy()[order]
    day = visits["day"].to_numpy()[order]
    found_a, found_b, found_acct = [], [], []
    # A loop over the lag (the visit 1, 2, 3, ... places later), not over rows: each step pairs all
    # visits with their k-th successor at once. Visits are sorted by day inside each account, so once
    # no visit has a k-th successor of the same account within the window, no larger lag has one.
    for lag in range(1, max_lag + 1):
        close = (acct[lag:] == acct[:-lag]) & (day[lag:] - day[:-lag] <= pair_days)
        if not close.any():
            break
        differ = close & (merch[lag:] != merch[:-lag])
        found_a.append(merch[:-lag][differ])
        found_b.append(merch[lag:][differ])
        found_acct.append(acct[:-lag][differ])
    if found_a:
        a, b, who = np.concatenate(found_a), np.concatenate(found_b), np.concatenate(found_acct)
    else:
        a = b = np.array([], dtype=merch.dtype)
        who = np.array([], dtype=np.int64)
    both = pd.DataFrame({"merchant_a": np.concatenate([a, b]), "merchant_b": np.concatenate([b, a]),
                         "who": np.concatenate([who, who])})
    # An account counts once per pair however often it repeats it: one busy account cannot make a pair.
    both = both.drop_duplicates()
    pairs = both.groupby(["merchant_a", "merchant_b"], sort=False).size().rename("accounts").reset_index()
    pairs["accounts"] = pairs["accounts"].astype(np.float64)
    merchants["accounts"] = merchants["accounts"].astype(np.float64)
    return pairs, merchants


def combine(parts):
    """Add the tables of several files: a list of (pairs, merchants) in, one such pair out.

    No account is in two files, so every count is a plain sum. An entry of None (a file that was
    left out) is skipped.
    """
    parts = [p for p in parts if p is not None]
    return (_panel.add_tables([p[0] for p in parts], ["accounts"]),
            _panel.add_tables([p[1] for p in parts], ["accounts"]))


class MerchantVectors:
    """The fitted table: one unit vector per token, and the rules that give a merchant its token.

    vectors          float64 [tokens, dim], each row of length 1 (NaN for a token without pairs)
    merchant_token   Series merchant -> token; merchant_level Series merchant -> OWN, CATEGORY_POSTAL or CATEGORY
    postal_token     DataFrame [category, postal code, token] for merchants that are not in the table
    category_token   Series category -> token
    log_share        Series merchant -> log of its share of all account visits
    """

    def __init__(self, vectors, merchant_token, merchant_level, postal_token, category_token, log_share,
                 merchant_col, mcc_col, postal_col):
        self.vectors, self.merchant_token, self.merchant_level = vectors, merchant_token, merchant_level
        self.postal_token, self.category_token, self.log_share = postal_token, category_token, log_share
        self.merchant_col, self.mcc_col, self.postal_col = merchant_col, mcc_col, postal_col

    def lookup(self, rows):
        """(token, level, unknown) for the rows of a DataFrame: token -1 where there is no vector."""
        n = len(rows)
        merchant = pd.Series(rows[self.merchant_col].to_numpy())
        token = merchant.map(self.merchant_token).to_numpy(dtype=np.float64)
        level = merchant.map(self.merchant_level).to_numpy(dtype=np.float64)
        unknown = np.isnan(token)
        # A merchant that is not in the table falls back to its category by postal code, then its category.
        if self.postal_token is not None and self.postal_col in rows.columns and self.mcc_col in rows.columns:
            asked = pd.DataFrame({self.mcc_col: rows[self.mcc_col].to_numpy(),
                                  self.postal_col: rows[self.postal_col].to_numpy()})
            hit = asked.merge(self.postal_token, on=[self.mcc_col, self.postal_col], how="left")["token"]
            hit = hit.to_numpy(dtype=np.float64)
            use = np.isnan(token) & ~np.isnan(hit)
            token[use], level[use] = hit[use], CATEGORY_POSTAL
        if self.category_token is not None and self.mcc_col in rows.columns:
            hit = pd.Series(rows[self.mcc_col].to_numpy()).map(self.category_token).to_numpy(dtype=np.float64)
            use = np.isnan(token) & ~np.isnan(hit)
            token[use], level[use] = hit[use], CATEGORY
        level[np.isnan(token)] = NONE
        return np.where(np.isnan(token), -1, token).astype(np.int64), level, unknown.astype(np.float64)

    def to_frame(self):
        """The table as one row per merchant: merchant, level, log share and the vector (for export)."""
        token = self.merchant_token.to_numpy(dtype=np.int64)
        frame = pd.DataFrame({self.merchant_col: self.merchant_token.index, "level": self.merchant_level.to_numpy(),
                              "log_share": self.log_share.reindex(self.merchant_token.index).to_numpy()})
        for j in range(self.vectors.shape[1]):
            frame[f"v_{j}"] = self.vectors[token, j]
        return frame


def ppmi(counts, power=None):
    """Positive pointwise mutual information of a symmetric sparse count matrix [tokens, tokens].

    PMI(i, j) = log( P(i, j) / (P(i) * Pc(j)) ), where Pc flattens popularity by `power`.
    Negative values are set to zero: "shares fewer customers than chance" is mostly noise at
    these counts. Returns a sparse matrix of the same shape.
    """
    power = CONTEXT_POWER if power is None else power
    counts = sparse.csr_matrix(counts, dtype=np.float64)
    total = counts.sum()
    row = np.asarray(counts.sum(axis=1)).ravel()
    context = row ** power
    context = context / context.sum() if context.sum() > 0 else context
    coo = counts.tocoo()
    pmi = np.log(coo.data / total) - np.log(row[coo.row] / total) - np.log(context[coo.col])
    keep = pmi > 0
    return sparse.csr_matrix((pmi[keep], (coo.row[keep], coo.col[keep])), shape=counts.shape)


def factorise(matrix, dim):
    """Truncated singular value decomposition: float64 [tokens, k] = U * sqrt(S), rows scaled to length 1.

    k is `dim` or less when there are fewer tokens. A small matrix is decomposed in full (svds
    needs k below the size). Each component's sign is fixed so that its largest entry is
    positive, which makes the result repeatable. Rows without any pair are NaN.
    """
    n = matrix.shape[0]
    k = max(min(int(dim), n - 1), 1)
    if n <= 2 * k + 2:
        u, s, _ = np.linalg.svd(matrix.toarray())
        u, s = u[:, :k], s[:k]
    else:
        # A fixed start vector makes the iterative solver give the same answer on every run.
        u, s, _ = svds(matrix.astype(np.float64), k=k, v0=np.ones(n) / np.sqrt(n))
        order = np.argsort(-s)
        u, s = u[:, order], s[order]
    biggest = u[np.abs(u).argmax(axis=0), np.arange(u.shape[1])]
    u = u * np.where(biggest < 0, -1.0, 1.0)
    vectors = u * np.sqrt(np.clip(s, 0.0, None))
    length = np.linalg.norm(vectors, axis=1, keepdims=True)
    return np.divide(vectors, length, out=np.full_like(vectors, np.nan), where=length > 0)


def fit_vectors(pairs, merchants, dim=None, min_accounts=None, power=None, merchant_col=None, mcc_col=None,
                postal_col=None):
    """Step two: the merchant vectors of the added tables. Returns a `MerchantVectors`.

    pairs, merchants   the added tables of `count_pairs`
    dim                numbers per merchant (default: DIM)
    min_accounts       merchants with fewer accounts get a stand-in token (default: MIN_ACCOUNTS)

    Token rules: a merchant with enough accounts is its own token. The rest of a category in one
    postal code share one token when they hold enough accounts together; the remaining ones
    share one token per category. Without a category column a thin merchant has no token.
    """
    merchant_col = _panel.pick(merchant_col, "MERCHANT_COL")
    mcc_col, postal_col = _panel.pick(mcc_col, "MCC_COL"), _panel.pick(postal_col, "MERCHANT_POSTAL_COL")
    dim = DIM if dim is None else int(dim)
    min_accounts = MIN_ACCOUNTS if min_accounts is None else min_accounts
    has_mcc = bool(mcc_col) and mcc_col in merchants.columns
    has_postal = has_mcc and bool(postal_col) and postal_col in merchants.columns
    extra = [c for c in (mcc_col if has_mcc else None, postal_col if has_postal else None) if c]
    # One row per merchant: the first category and postal code seen, the accounts summed over files.
    m = merchants.groupby(merchant_col, sort=False, dropna=False).agg(
        **{c: (c, "first") for c in extra}, accounts=("accounts", "sum")).reset_index()
    own = (m["accounts"] >= min_accounts).to_numpy()
    token = np.full(len(m), -1, dtype=np.int64)
    level = np.full(len(m), NONE, dtype=np.int64)
    token[own], level[own] = np.arange(own.sum()), OWN
    next_token = int(own.sum())
    postal_token = category_token = None
    if has_postal:
        thin = ~own & m[mcc_col].notna().to_numpy() & m[postal_col].notna().to_numpy()
        group = timekeys.codes(m[mcc_col].to_numpy(), m[postal_col].to_numpy())
        weight = np.bincount(group[thin], weights=m["accounts"].to_numpy()[thin], minlength=group.max() + 1)
        good = thin & (weight[group] >= min_accounts)
        ids = pd.factorize(group[good])[0]
        token[good], level[good] = next_token + ids, CATEGORY_POSTAL
        next_token += int(ids.max()) + 1 if len(ids) else 0
        postal_token = pd.DataFrame({mcc_col: m[mcc_col].to_numpy()[good], postal_col: m[postal_col].to_numpy()[good],
                                     "token": token[good]}).drop_duplicates([mcc_col, postal_col])
    elif has_mcc:
        _panel.say_once("no postal code column; merchant vectors fall back to the category only")
    if has_mcc:
        rest = (token < 0) & m[mcc_col].notna().to_numpy()
        ids, cats = pd.factorize(m[mcc_col].to_numpy()[rest])
        token[rest], level[rest] = next_token + ids, CATEGORY
        next_token += len(cats)
        category_token = pd.Series(next_token - len(cats) + np.arange(len(cats)), index=cats)
    else:
        _panel.say_once("no category column; merchants with few accounts get no vector")

    # Pairs of merchants become pairs of tokens. Pairs inside one stand-in token say nothing and are dropped.
    to_token = pd.Series(token, index=m[merchant_col].to_numpy())
    ta = pd.Series(pairs["merchant_a"].to_numpy()).map(to_token).to_numpy(dtype=np.float64)
    tb = pd.Series(pairs["merchant_b"].to_numpy()).map(to_token).to_numpy(dtype=np.float64)
    ok = ~np.isnan(ta) & ~np.isnan(tb) & (ta >= 0) & (tb >= 0) & (ta != tb)
    n_tokens = max(next_token, 1)
    counts = sparse.coo_matrix((pairs["accounts"].to_numpy(dtype=np.float64)[ok],
                                (ta[ok].astype(np.int64), tb[ok].astype(np.int64))), shape=(n_tokens, n_tokens)).tocsr()
    vectors = factorise(ppmi(counts, power), dim) if counts.nnz else np.full((n_tokens, 1), np.nan)

    total = m["accounts"].sum()
    known = token >= 0
    index = m[merchant_col].to_numpy()[known]
    return MerchantVectors(
        vectors, pd.Series(token[known], index=index), pd.Series(level[known], index=index), postal_token,
        category_token, pd.Series(np.log(m["accounts"].to_numpy() / max(total, 1.0)), index=m[merchant_col].to_numpy()),
        merchant_col, mcc_col, postal_col)


def covisit_features(target, table, window_days=None, with_vectors=False, account_col=None, time_col=None,
                     prefix="cov_"):
    """Step three: the affinity and the table columns of every target row.

    target         raw rows with the account, time and merchant columns (category and postal code
                   for the fallback); the rows of an account are its own history
    table          a `MerchantVectors` from `fit_vectors`
    window_days    the window of the account's earlier rows (default: AFFINITY_DAYS)
    with_vectors   also return the merchant's vector as columns cov_v_0 ... cov_v_<k-1>

    Returns a DataFrame [targets, columns] with the index of `target`; see the top of the file.

    Time rule: the mean vector of a row is taken over its account's rows in strictly earlier
    seconds within the window; rows of the same second never see each other. The table itself
    must be fitted on earlier rows of other accounts (see `count_pairs`).
    """
    account_col = _panel.pick(account_col, "ACCOUNT_COL")
    window_days = AFFINITY_DAYS if window_days is None else window_days
    token, level, unknown = table.lookup(target)
    has = token >= 0
    vec = np.where(has[:, None], table.vectors[np.maximum(token, 0)], np.nan)
    has &= ~np.isnan(vec).any(axis=1)                         # a token without pairs has no vector
    filled = np.where(has[:, None], vec, 0.0)

    secs = timekeys.seconds(target[_panel.pick(time_col, "TIME_COL")])
    engine = EarlierRows(timekeys.codes(target[account_col].to_numpy()), secs)
    # One search for the window ends, shared by every coordinate and by the count.
    sums = _panel.window_totals(engine, [filled[:, j] for j in range(filled.shape[1])] + [has.astype(np.float64)],
                                [int(window_days) * _panel.DAY])[int(window_days) * _panel.DAY]
    count = sums[:, -1]
    mean = sums[:, :-1] / np.maximum(count, 1.0)[:, None]
    length = np.linalg.norm(mean, axis=1)
    # The row's own vector has length 1, so the cosine is the dot product over the mean's length.
    affinity = np.divide((filled * mean).sum(axis=1), length, out=np.full(len(target), np.nan),
                         where=has & (count > 0) & (length > 0))

    label = f"{int(window_days)}d"
    share = pd.Series(target[table.merchant_col].to_numpy()).map(table.log_share).to_numpy(dtype=np.float64)
    out = {f"{prefix}affinity_{label}": affinity, f"{prefix}affinity_n_{label}": count,
           f"{prefix}log_share": share,
           f"{prefix}unknown": unknown, f"{prefix}level": level}
    if with_vectors:
        for j in range(vec.shape[1]):
            out[f"{prefix}v_{j}"] = np.where(has, vec[:, j], np.nan)
    return _panel.as_frame(out, target.index)


def main(argv=None):
    """Command line: count pairs over the panel files, fit the vectors and print the columns of the target rows."""
    def of_file(df, held):
        if held:
            # The file holds target rows: it is left out of the counts, so that no target account's
            # own pairs shape the vectors it is then compared with.
            _panel.say_once("panel files that hold target rows are left out of the merchant vectors")
            return None
        return count_pairs(df)

    def combine_parts(parts):
        return combine(parts)

    def features(target, part, args):
        table = fit_vectors(*part)
        if args.save_table:
            tables.write_table(table.to_frame(), args.save_table)
            print(f"written: {args.save_table}")
        return covisit_features(target, table, with_vectors=args.with_vectors)

    def more(parser):
        parser.add_argument("--save-table", default=None,
                            help="also write the merchant vector table to this parquet file")
        parser.add_argument("--with-vectors", action="store_true", help="also return the merchant's vector as columns")

    return _panel.run_tool(argv, "Merchant vectors from within-account co-visits, and the affinity of the target rows.",
                           needed_columns(), of_file, combine_parts, features, more)


if __name__ == "__main__":
    main()
