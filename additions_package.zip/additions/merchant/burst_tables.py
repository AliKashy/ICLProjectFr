"""Merchant-by-hour tables: is this merchant under attack right now, seen through OTHER accounts?

What this file does
-------------------
It is the idea of day_tables.py within the day. Per file (`build_burst_tables`) rows are
grouped by merchant and hour, and by 5-minute slot for the busiest merchants: authorisations,
accounts, rows that were not approved, rows under 5 dollars, and the network risk score.
The same sums are kept per account, so that an account's own rows can be subtracted.

For a target row (`burst_features`) and each window of the last completed 1, 6 and 24 hours:

    burst_n_<w>                    authorisations of other accounts at the merchant (the evidence)
    burst_rows_per_account_<w>     their authorisations per account and hour
    burst_base_n_<w>               the usual number: the same hours of the week over the prior 28 days
    burst_volume_chi2_<w>          burst score of the authorisations: recent against usual
    burst_not_approved_share_<w>   share of their rows that were not approved
    burst_not_approved_lift_<w>    that share minus the usual share
    burst_decline_chi2_<w>         burst score of the rows that were not approved
    burst_small_share_<w>, burst_small_lift_<w>    the same for rows under 5 dollars
    burst_mean_score_<w>, burst_score_lift_<w>     the same for the mean network risk score

The burst score is a chi-squared statistic with a sign: how far the recent count lies from
the count that the usual level would give, positive for a burst and negative for a lull.
The 5-minute table gives the same columns over the last 5, 15 and 60 minutes with the
prefix `burst5_`, for rows at the busiest merchants only.

Why it exists
-------------
Card testing hits many accounts at one merchant within minutes. On each single account the
transaction looks ordinary: a small amount at an everyday merchant. What gives it away is
the merchant's last hour, in which far more authorisations than usual arrive, from many
accounts, many of them small and many refused. A fraud label sits only on approved rows, so
declined attempts are never labelled, and fraud labels arrive weeks after the transaction;
the refusals of other accounts are known at once. The day tables are a day behind and
cannot see an attack that starts and ends within hours.

The rules of this folder hold here too. The tables come from a panel of files that is
separate from the rows a model is fitted on. The row's own account is taken out, so a
customer who retries a purchase does not look like an attack on the merchant. Only
completed hours (or 5-minute slots) are read, never the running one, so the newest minutes
are given up for the sake of the time rule. Shares and means are pulled toward a prior:
the recent value toward the merchant's usual value at this hour of the week, and that
toward the usual value of all merchants. No maximum, no number of distinct accounts and no
first-seen flag is offered, because they change with the share of accounts sampled. Two
kinds of column do depend on that share and are marked as evidence: the counts, and the
burst scores, which are counts in disguise (the same attack gives a score that grows in
proportion to the share of accounts in the panel). Train and score with panels of the same
share, or give the model the share as coverage.py does. The lifts are free of it.

Where it goes
-------------
Raw files, then these tables, then feature columns: extra numeric inputs of the network
(appended in `SequenceBuilder._encode_file` in the original code, one numeric token each in
`FeatureTokenizer`) or columns of a second-stage tree model, joined by transaction id.
Served live, the tables are a store keyed by merchant that is updated as authorisations
arrive and read at the last completed slot.

What to change for the pod
--------------------------
settings.py: ACCOUNT_COL, TIME_COL, MERCHANT_COL, AMOUNT_COL, VISA_SCORE_COL, REASON_COL,
DECLINE_FLAG_COL, APPROVED_REASONS, DECLINE_FLAG_VALUES. In _panel.py: PANEL_BASE, PANEL_FILES,
PRIOR_ROWS. Here: SLOT_SECONDS, FINE_SLOT_SECONDS, WINDOWS, FINE_WINDOWS, BASE_WEEKS,
SMALL_AMOUNT and BUSIEST. The files must hold the declined attempts for the refusal columns
to mean anything. The usual level needs four earlier weeks: on files that start one month
before the scored month it is complete only for the later part of the scored month, and
`burst_base_n` is missing where no whole earlier week is in the table.

How to try it
-------------
    python additions/merchant/burst_tables.py --demo
    python additions/merchant/burst_tables.py --panel-files 8000 8001 8002 --files 8217 --out burst.parquet

    by_merchant, by_account = combine([build_burst_tables(df) for df in panel_frames])
    columns = burst_features(target, by_merchant, by_account)
    python -m pytest -q additions/tests/test_merchant_burst_tables.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np
import pandas as pd

from additions import settings
from additions.common import timekeys
from additions.common.timekeys import MISSING_SECOND
from additions.merchant import _panel

# The name of the slot column of the tables: whole slots since 1970-01-01.
SLOT_COL = "slot"

# The sums a table can hold. A sum whose raw column is not available is simply absent.
VALUE_COLS = ("rows", "accounts", "not_approved", "small", "score", "score_rows")

# The length of a slot in seconds for the hour table and for the table of the busiest merchants.
SLOT_SECONDS = 3_600
FINE_SLOT_SECONDS = 300

# Windows as (label, completed slots before the row's slot), for the hour table and the 5-minute table.
WINDOWS = (("1h", 1), ("6h", 6), ("24h", 24))
FINE_WINDOWS = (("5m", 1), ("15m", 3), ("60m", 12))

# The usual level is taken from the same slots of the week in this many earlier weeks (4 weeks = 28 days).
BASE_WEEKS = 4

# PLACEHOLDER: the amount in dollars under which an authorisation counts as small (a typical test amount).
SMALL_AMOUNT = 5.0

# PLACEHOLDER: how many merchants get the 5-minute table: the ones with the most rows in the hour table.
BUSIEST = 50_000


def needed_columns():
    """The raw columns the tables read (None entries are optional columns that are switched off)."""
    return [settings.ACCOUNT_COL, settings.TIME_COL, settings.ID_COL, settings.MERCHANT_COL, settings.AMOUNT_COL,
            settings.VISA_SCORE_COL, settings.REASON_COL, settings.DECLINE_FLAG_COL]


def build_burst_tables(df, slot_seconds=None, merchants=None, account_col=None, time_col=None, merchant_col=None,
                       amount_col=None, score_col=None, reason_col=None, decline_flag_col=None, small_amount=None):
    """The merchant-by-slot sums of one file (or of any table that holds whole accounts).

    df             raw rows; the column names default to settings.py
    slot_seconds   length of a slot: 3_600 for the hour table (default), 300 for the 5-minute table
    merchants      when given, only rows at these merchant ids are kept (the busiest merchants)

    Returns (by_merchant, by_account): one row per merchant and slot with the sums of
    `VALUE_COLS`, and the same per account for taking an account's own rows out again. A sum
    whose raw column is None in settings or absent from `df` is left out after one printed line.
    """
    account_col, merchant_col = _panel.pick(account_col, "ACCOUNT_COL"), _panel.pick(merchant_col, "MERCHANT_COL")
    slot = _panel.periods(timekeys.seconds(df[_panel.pick(time_col, "TIME_COL")]),
                          SLOT_SECONDS if slot_seconds is None else slot_seconds)
    cells = {merchant_col: df[merchant_col].to_numpy(), SLOT_COL: slot, account_col: df[account_col].to_numpy(),
             "rows": 1.0}
    not_approved, _ = _panel.decisions(df, reason_col, decline_flag_col)
    if not_approved is not None:
        cells["not_approved"] = not_approved
    amount = _panel.optional(df, _panel.pick(amount_col, "AMOUNT_COL"), "the share of small amounts", numeric=True)
    if amount is not None:
        # A missing amount is not small: NaN compares as "no".
        cells["small"] = (amount < (SMALL_AMOUNT if small_amount is None else small_amount)).astype(np.float64)
    score = _panel.optional(df, _panel.pick(score_col, "VISA_SCORE_COL"), "the mean risk score", numeric=True)
    if score is not None:
        cells["score"], cells["score_rows"] = np.nan_to_num(score, nan=0.0), (~np.isnan(score)).astype(np.float64)
    frame = pd.DataFrame(cells)
    keep = slot != MISSING_SECOND                                   # a row without a time is in no slot
    if merchants is not None:
        keep &= frame[merchant_col].isin(merchants).to_numpy()
    by_account = frame[keep].groupby([merchant_col, SLOT_COL, account_col], dropna=False, sort=False,
                                     as_index=False).sum()
    by_account["accounts"] = 1.0                                    # one account in one slot at one merchant
    by_merchant = by_account.drop(columns=account_col).groupby([merchant_col, SLOT_COL], dropna=False, sort=False,
                                                               as_index=False).sum()
    return by_merchant, by_account


def combine(parts):
    """Add the tables of several files: a list of (by_merchant, by_account) in, one such pair out.

    The merchant tables are summed key by key; the per-account tables are stacked, because no
    account is in two files. An entry whose second part is None adds only its merchant table.
    """
    own = [part[1] for part in parts if part[1] is not None]
    return (_panel.add_tables([part[0] for part in parts], VALUE_COLS),
            pd.concat(own, ignore_index=True) if own else None)


def busiest_merchants(by_merchant, top=None, merchant_col=None):
    """The ids of the `top` merchants with the most rows in a table: the ones worth a 5-minute table.

    The row count is used here to choose merchants, not as a model input, so its dependence on
    the share of accounts sampled does no harm: the ranking of merchants hardly depends on it.
    """
    merchant_col = _panel.pick(merchant_col, "MERCHANT_COL")
    rows = by_merchant.groupby(merchant_col)["rows"].sum()
    return rows.nlargest(BUSIEST if top is None else top).index.to_numpy()


def burst_score(recent, usual_total, weeks):
    """A signed chi-squared statistic: how far a recent count lies from what the usual level would give.

    recent        float [rows]: the count in the recent window
    usual_total   float [rows]: the count in the same window of the week, summed over `weeks` earlier weeks
    weeks         float [rows]: how many earlier weeks that sum covers

    The recent window and the earlier weeks are `weeks + 1` equal stretches. If the level had
    not changed, each would hold the same share of the total count. The statistic compares
    the recent stretch with that: (recent - expected)^2 * stretches^2 / (total * (stretches - 1)).
    It is positive for a burst and negative for a lull, 0 when there is no count at all and
    missing when no earlier week is available. It grows with the size of the counts, so it
    measures evidence and depends on the share of accounts in the panel.
    """
    recent, usual_total = np.asarray(recent, dtype=np.float64), np.asarray(usual_total, dtype=np.float64)
    stretches = np.asarray(weeks, dtype=np.float64) + 1.0
    total = recent + usual_total
    gap = recent - total / stretches
    stat = np.zeros(len(recent))
    np.divide(gap ** 2 * stretches ** 2, total * (stretches - 1.0), out=stat, where=(total > 0) & (stretches > 1))
    return np.where(stretches > 1, np.sign(gap) * stat, np.nan)


def burst_features(target, by_merchant, by_account=None, slot_seconds=None, windows=None, base_weeks=None,
                   first_slot=None, only_merchants=None, prior_rows=None, account_col=None, time_col=None,
                   merchant_col=None, prefix="burst_"):
    """The burst columns of every target row.

    target           raw rows to build columns for (account, time, merchant)
    by_merchant      the added merchant-by-slot table of the panel
    by_account       the per-account table of the panel files that hold accounts of `target`; None
                     when no target account is in the panel
    slot_seconds     the slot length the tables were built with (default: SLOT_SECONDS)
    windows          ((label, slots), ...) (default: WINDOWS; use FINE_WINDOWS with the 5-minute table)
    base_weeks       how many earlier weeks make up the usual level (default: BASE_WEEKS)
    first_slot       the first slot the panel covers; default: the first slot found in the table. A
                     week counts toward the usual level only when its whole window lies in the table
    only_merchants   merchant ids the table was restricted to; rows at other merchants get missing values
    prior_rows       strength of the priors (default: _panel.PRIOR_ROWS)

    Returns a DataFrame [targets, 11 columns per window] with the index of `target`.

    Time rule: a row in slot s reads slots s-1 and before, never its own slot. Rows of the
    same slot therefore never see each other. The row's own account is subtracted everywhere.
    """
    account_col, merchant_col = _panel.pick(account_col, "ACCOUNT_COL"), _panel.pick(merchant_col, "MERCHANT_COL")
    slot_seconds = SLOT_SECONDS if slot_seconds is None else slot_seconds
    windows = WINDOWS if windows is None else windows
    base_weeks = BASE_WEEKS if base_weeks is None else base_weeks
    slot = _panel.periods(timekeys.seconds(target[_panel.pick(time_col, "TIME_COL")]), slot_seconds)
    placed = slot != MISSING_SECOND
    per_week = _panel.WEEK // slot_seconds                          # the same slot of the week, one week earlier
    if first_slot is None:
        first_slot = int(by_merchant[SLOT_COL].min()) if len(by_merchant) else 0
    values = [c for c in VALUE_COLS if c in by_merchant.columns]
    col = {name: j for j, name in enumerate(values)}
    lengths = sorted({n for _, n in windows})
    # Everything is read as "the sum over the k slots before the row's slot". A recent window is such
    # a sum; a window of an earlier week is the difference of two of them.
    edges = sorted(set(lengths) | {per_week * k + e for k in range(1, base_weeks + 1) for e in [0] + lengths})
    at_merchant = _panel.others_sums(by_merchant, by_account, [merchant_col], SLOT_COL, values, target, slot, edges,
                                     account_col)
    everywhere = _panel.others_sums(by_merchant, by_account, [], SLOT_COL, values, target, slot, edges, account_col)

    out = {}
    for label, n in windows:
        # How many earlier weeks hold the whole window. A window that starts before the table does
        # would look quiet for the wrong reason, so such a week is left out.
        weeks = np.where(placed, np.clip((np.where(placed, slot, 0) - n - first_slot) // per_week, 0, base_weeks), 0)

        def usual(sums):
            total = np.zeros_like(sums[n])
            for k in range(1, base_weeks + 1):                      # a loop over four weeks, not over rows
                total += (weeks >= k)[:, None] * (sums[per_week * k + n] - sums[per_week * k])
            return total

        recent, base, base_all = at_merchant[n], usual(at_merchant), usual(everywhere)
        rows = recent[:, col["rows"]]
        out[f"{prefix}n_{label}"] = rows
        # Plain ratios (no prior): missing when there is nothing to divide by.
        out[f"{prefix}rows_per_account_{label}"] = _panel.shrunk(rows, recent[:, col["accounts"]], np.nan)
        out[f"{prefix}base_n_{label}"] = _panel.shrunk(base[:, col["rows"]], weeks, np.nan)
        out[f"{prefix}volume_chi2_{label}"] = burst_score(rows, base[:, col["rows"]], weeks)
        for name, lift, top, bottom in (("not_approved_share", "not_approved_lift", "not_approved", "rows"),
                                        ("small_share", "small_lift", "small", "rows"),
                                        ("mean_score", "score_lift", "score", "score_rows")):
            if top not in col:
                continue
            # The usual value of all merchants, then the merchant's usual value pulled toward it, then
            # the merchant's recent value pulled toward its usual one.
            broad = _panel.shrunk(base_all[:, col[top]], base_all[:, col[bottom]], np.nan)
            before = _panel.shrunk(base[:, col[top]], base[:, col[bottom]], broad, prior_rows)
            now = _panel.shrunk(recent[:, col[top]], recent[:, col[bottom]], before, prior_rows)
            out[f"{prefix}{name}_{label}"], out[f"{prefix}{lift}_{label}"] = now, now - before
            if top == "not_approved":
                out[f"{prefix}decline_chi2_{label}"] = burst_score(recent[:, col[top]], base[:, col[top]], weeks)
    frame = _panel.as_frame(out, target.index)
    if only_merchants is not None:
        # A merchant outside the table is not quiet; nothing is known about it at this grain.
        frame[~target[merchant_col].isin(only_merchants).to_numpy()] = np.nan
    return frame


def main(argv=None):
    """Command line: add the hour and 5-minute tables of the panel files and print the columns of the target rows."""
    def of_file(df, held):
        # The 5-minute table is built for every merchant here and cut down to the busiest ones once
        # the whole panel is added, because only then is it known which merchants are the busiest.
        hour, hour_own = build_burst_tables(df)
        fine, fine_own = build_burst_tables(df, FINE_SLOT_SECONDS)
        return (hour, hour_own if held else None), (fine, fine_own if held else None)

    def combine_both(parts):
        return combine([part[0] for part in parts]), combine([part[1] for part in parts])

    def features(target, part, args):
        (hour, hour_own), (fine, fine_own) = part
        busiest = busiest_merchants(hour, args.busiest)
        fine = fine[fine[settings.MERCHANT_COL].isin(busiest)]
        if fine_own is not None:
            fine_own = fine_own[fine_own[settings.MERCHANT_COL].isin(busiest)]
        coarse = burst_features(target, hour, hour_own)
        sharp = burst_features(target, fine, fine_own, FINE_SLOT_SECONDS, FINE_WINDOWS, only_merchants=busiest,
                               prefix="burst5_")
        return pd.concat([coarse, sharp], axis=1)

    return _panel.run_tool(
        argv, "Merchant-by-hour tables from a panel of files, and the burst columns of the target rows.",
        needed_columns(), of_file, combine_both, features,
        lambda parser: parser.add_argument("--busiest", type=int, default=None,
                                           help="how many merchants get the 5-minute table (default: BUSIEST)"))


if __name__ == "__main__":
    main()
