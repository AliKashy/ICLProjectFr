# Every configuration of the model, and which to switch on

This note lists every setting of the model that is being decided: what the model in use has
today, what the candidate for the strongest model has, what it is tested against, the
evidence, and the code that holds it. It was written on 26 November 2026, after a research
run that read the Large Payments Model (JPMorgan, arXiv 2611.15814) in full and the published
work on numeric encodings, time encodings and history designs, and revised the same day after
three independent checks of the code: one for leaks through time, one for the encoders, one
that fitted the kit into another model. It was revised again on 27 November, after a fourth
check built models that leak and still passed the checks of the template, and once more the same
day, after a fifth found leaks the checks still missed and batches of the model in use that they
could not run on; section 1 says what the checks do now.

Evidence is marked **read** when a source says it (with the source and the table or section),
**measured** when it was measured in this package (with the place and what was run), and
**judgement** when neither is the case. Most of what follows is judgement: no published study
tests these choices on a card-fraud model trained on its labels alone at this scale, and the
Large Payments Model itself reports no ablation of its encoders, of its number of channels, of
interleaving, or of channels kept apart against one joined vector.

`model/best_model_template.py` builds every configuration named here from one set of switches,
runs the checks on each and prints their cost side by side. Every arm is one entry of its
`ARMS`: a configuration, the arm it is compared with, and the one question that comparison
answers. Every arm but the four named configurations changes one entry of the arm it is
compared with. The names in capitals below are those entries; `python best_model_template.py
--list` prints them all with their change, their question and their weights. `RECIPE.md` holds
the training recipe and the order of the runs that come before these; this note does not repeat
it except where a setting belongs to the model itself.

## 1. The candidate in one paragraph

Tokens 96 wide where they are 48. Numbers through the piecewise-linear encoding of today with
32 bins where there are 16, read on the [0, 1] scale of the quantile scaler fitted on training
rows, since no trained edges exist at 32 bins. A missing number gives its field identity alone,
as today, because it is not known whether the real numbers are ever missing; a learned vector
for it is an arm. Stage 1 as today (two layers over the grouped inputs) but with six summary
tokens and four heads of 24. The six summary outputs are not joined: each stays a channel of 96
through the history. The history stage has four interleaved pairs: in each, the channels of a
transaction read that transaction's 64 field tokens and the fields of its five latest earlier
transactions, then read one another (the order Figure 4 of the Large Payments Model draws),
then each channel attends through time on its own under today's time rule, with one set of
weights shared by all channels. The memory of earlier fields takes the rows of an earlier second
all or none, so that the order of the rows inside a second, which the scorer may not have,
moves no score. A last read of the fields after the last pair takes the place of today's re-read
after stage 2. A learned position table and the time gap as today, the gap encoded like the other
numbers, and a learned bias on attention by time gap that the stage builds itself from the times
of every call. At the end the six channels are joined (576 numbers) and a linear head scores the
row. The same 576 numbers are the exported vector.

Against it stand today's model with the new training schedule (the control, `TODAY`) and a wide
joined model (`WIDE_JOINED`: tokens 96 wide, three summary outputs joined into 288, stage 1
with 4 heads of 24 and the history with 4 heads of 72, everything else as today), which asks
whether width alone gives what the candidate gives. The candidate also has 32 bins, the gap in
bins and the time bias, which act on a joined history as well, so the head-to-head tests the
candidate as a whole; section 8 says which runs then narrow it down to the channels. Two arms stand
beside another arm rather than beside the candidate: learned centres held where they start
(`NUMBERS_FROZEN_CENTRES`) beside learned centres (`NUMBERS_LEARNED_PLE`), which tells a gain of
moving centres from a gain of their parametrization, and the sines of the gap counted in whole
seconds (`GAP_SINUSOID_SECONDS`) beside the sines as the paper runs them, in milliseconds
(`GAP_SINUSOID`).

Before any run the seven checks of the template run on the model in use, with one of its own
batches and the time unit its builder writes, named by whoever runs them and never read from
the model. One of them reads the times of the real rows with that unit and requires them to fall
between 2000 and 2100: nanoseconds read as seconds give a year in the billions and seconds read
as nanoseconds the year 1970, so a unit that is wrong in the model and in the checks alike can no
longer pass unseen. The checks also take what they cannot know of the model in use: which entry
holds the mask of real rows (`real="~is_pad"` for a mask True on padding), which entries hold each
row's answer (`labels`), a function that writes again what the builder works out from other rows,
from the slots or from the whole window (`rebuild`: a gap column, a slot index, a window's
length), a function that builds a new instance never called (`build`), and the side on which
the builder pads (`pads="left"`), which a batch of full windows does not show. Every batch a
check makes from a batch in time order by whole second is in time order by whole
second too, so a model that takes only such batches, as the model in use does, takes them; only
the shuffle of the seventh check changes the order of the rows inside a second, and a model that
stops on that is shuffled only among rows that share their time to the last unit, with a line.
What the others do:

- The first check changes the rows a probe may not read and requires the earlier rows not to
  move, bit for bit, in scoring mode and again in training mode with gradients on. The training
  pass runs each call on a fresh copy with the same dropout masks (torch, Python's random module
  and numpy seeded alike), so that a part that reads the whole batch in training only, a batch
  norm for instance, fails it, with a line that names that cause. The probes lie at another
  place in every sequence (1/2, 1/4, 3/4, 1/8 and so on of the way through its real rows), each
  in a second shared with another real row when one lies near, so that a row that reads the
  other rows of its own second moves; and the comparison runs once more with every probe at the
  second-to-last real row, so that a leak from the last seconds into any earlier row moves a
  kept row. A leak between two rows elsewhere in the window shows where a probe, or a cut of the
  third check, falls between them; `cut=range(1, T)` cuts after every slot. The rows of later
  seconds move later by whole seconds, each keeping its part inside the second, and no kept
  row's time changes, so a row that reads its own time to the nanosecond, which the rule allows,
  passes. In scoring mode the kept rows are compared three ways: under `torch.no_grad()`, under
  `torch.inference_mode()` and in evaluation mode with gradients on, since a model may take a
  path in one of them alone. The answers of the changed rows and of the probe are redrawn (a
  class moves to the next class, a quantity such as an outcome time by its spread), so a row
  that reads its own label fails; an entry that tells an answer by its presence (a chargeback
  amount that is not a number where there was none, days to it that are -1) has that presence
  turned over in one more pass. The check also changes the earlier rows (their inputs, their
  answers, and their seconds an hour earlier) and requires the later rows to move: a mask of
  real rows handed over True on padding, or a model that reads no history, fails it with a line
  that says so, and it returns three numbers (kept, changed, read).
- The second check fills the padded slots with values that are not numbers and with 1e30 (65504
  for numbers in float16), and their times with any time at all, in scoring and in training mode,
  and no real row may move in either.
  A batch of full windows is checked on a copy in which the last real row of its fullest
  sequence is made padding (the first, when the builder pads on the left or the model stops on
  the last).
- The third check puts the real rows of every sequence in time order among their own slots, a
  stable sort by whole second that leaves the padded slots where they are, before it cuts the
  window, and says so when it moved a row. Unless the caller names the cuts, it cuts inside a
  second shared by two real rows, in as many sequences as one cut can, so that a row that reads
  how many rows share its second (a position counted with <= in place of <, the size of a burst)
  sees fewer of them and moves; and near the first slot, near every eighth of the width and near
  the last slot, each cut leaving real rows on both sides in some sequence. `cut=range(1, T)`
  cuts after every slot, through `run_checks` as well. The cut window is sliced to its first
  slots and, when the builder pads on the left, also written at the full width with the kept
  rows at its end, so that a row that reads how much padding lies in front of it, which holds
  the length of the whole window, moves too; a window with real rows but none before the cut
  keeps its earliest real row, not compared, so that no window is empty. A batch of full windows
  does not say on which side its builder pads: it is cut as slices, with a line, unless
  `pads="left"` says so. Every cut is compared in scoring mode and again in training mode on a
  copy whose dropout is off, so a part that reads its share of the window in training mode alone
  moves too. Last, the model as handed over, in its own number type, scores the window with its
  slots from every cut on made padding in place, on whichever side the batch pads and in each of
  the three ways of scoring. The rows before the cut may not move at all there, and a move fails
  the check with a line: a part that reads the window only in 16 bits, or only under
  `torch.inference_mode()`, moves there. With a function `real` and no `pad` this pass does not
  run, and a line says so.
- The sixth check builds its own second batch from the sequences rolled by one place, with new
  inputs on every real row and every real row 30 days, 5 hours and 7 seconds later
  (`OTHER_SHIFT_SECONDS`; integer times in a unit that is not a whole number of units per
  second, whole minutes say, move by the nearest whole number of units), and scores it after the
  first batch and the first after it, each against a new instance, in scoring and in training
  mode: nothing may be kept between calls, such as a bias built once or an origin of time fixed
  on the first call. One instance also scores the first batch a third time, after the second,
  and one scores after a training call against a new instance holding the weights and buffers
  that call left, so that what is fixed on a second call, or kept from a training call outside
  the weights, shows; the scoring comparisons run once more under `torch.inference_mode()`. With
  `build`, the new instance has never been called, so an origin fixed on a call before the
  checks shows as well, and a line names an attribute that an earlier batch fixed (an origin, a
  scale); one that every call rewrites, a counter or a memory of the latest batch, shows in
  two_batches alone. With `build`, the other checks run on such a new instance too, holding the
  model's weights and buffers, so that what the model kept on its instance before the checks (a
  memo by transaction) does not answer the windows they change. A model compiled with
  `torch.compile` is checked through the module it wraps, which holds what the model keeps.
  Last, every sequence is scored alone, as grouped scoring may batch it, and in training mode
  half the sequences change while the other half keep their rows: a row
  that reads the other sequences of its batch (their earliest time, their number, a batch norm
  across them) fails. A batch of one sequence is checked too. It returns two numbers
  (two_batches, alone).
- The seventh check shuffles the rows of every second that holds two real rows among their
  slots, which may move no score beyond rounding; a model that takes the rows of a second only
  in the order of their times is shuffled only among rows that share their time to the last
  unit. Then, around one row of each such second, the witness, the other rows of the second
  change while the witness may not move: in one pass, with the first slot as witness, they get
  new inputs and move into the next second of their sequence, every row staying real, in scoring
  and in training mode; in the other, with the last slot as witness, they leave the window,
  which is written again from the rows that are left on the side the builder pads, the slots
  they leave holding padding with a time in no real second, so that a row that finds the rows
  of its second by their times alone, without the mask, finds them gone. At most eight
  such passes run, spread over the shared seconds of a sequence. The answers of every row of the
  second are redrawn in both, and the first pass is scored in each of the three ways of scoring.
  The shuffle and the rows taken out are compared in training mode as well, on a copy whose
  dropout is off. A row that reads the other rows of its own second fails, whether it reads
  their values, their order, their times inside the second or only how many there are, and so
  does a row that reads its own answer. The witnesses are the first and the last slot of a
  second: a read confined to a row with rows of its second on both sides of it is left to the
  third check's cut inside a second. A batch without a shared second is checked on a copy that
  makes one. It returns two numbers (order, same_second).
- Checks 3 and 7 and the lone sequences of check 6 compare scores to rounding, each score as a
  share of itself, so that a large score beside a small one widens nothing. They run on a copy
  in 64-bit numbers with autocast off, where rounding is about 1e-14 of a score, when the model
  runs there and scores the whole batch as it does in 32 bits. Inside that copy every narrower
  float that a torch function takes or hands back is widened, so a mask or a tensor the model
  builds in float32, or a cast it makes inside, keeps it in 64 bits. The model in use builds
  its attention mask in float32, which torch on the CPU reads otherwise beside float64 weights
  in training mode; widened, it is compared in 64 bits (1.6e-14 at a joined width of 576, where
  32 bits gave 1.0e-5 to 1.5e-5 and failed). Otherwise, with a line, the copy is in 32-bit
  numbers with float32 products at full precision, whose rounding reaches the tolerance of 1e-5
  from about 300 numbers of joined width. When a comparison moves beyond the tolerance in 64
  bits and not in 32, the 32-bit one stands, with a line. A model in 16 bits is compared the
  same way, a cast to 16 bits inside it included, and products in TF32 pass as full ones do.
- Every call of the checks hands the model a batch of its own: a new dict, the tensors cloned,
  anything else copied. A model that keeps an entry in its batch (a length worked out once)
  works it out afresh in each call, and `run_checks` names what the model adds, replaces or
  writes in place there.
- Where the checks make padding (a batch of full windows, a cut window, rows taken out of a
  second) they write it as a builder does unless `pad` is handed over: the mask, a time in no
  second of a real row, and on every other entry the value the padded slots of the batch hold
  (0 when they hold no one value). A `pad` of the caller's writes the times and inputs too.
- A check that cannot make a batch it needs gives not a number, which fails it, with a line:
  checks 3 and 7 need `pad` to make padding when `real` is a function, and the model must take
  the window they write on one side or the other. `pads` other than "left", "right" or None
  stops with a plain error.

What the checks cannot see is what the builder works out before the model: a column that counts
or orders the rows of a second, or a window's length, moves with its row in every check unless
`rebuild` writes it again, and run_checks names, for that reason, every entry not laid out per
row (per window, or one value for the batch of any type: a number, a string, a dict, a tensor)
that no `rebuild` writes again, every entry per row that `alter` leaves as it is, and every name
in `labels` the batch does not hold. Nor do they run a model in training mode under
torch.no_grad(), so a part that leaks only there is not seen. A part that runs only while a
dropout drops something, or only while a rate is above zero, runs with the window as it is and
is not compared against a changed window. The copies in 64 or 32 bits do not run a path the
model takes only in its own number type; the third check's pass in place covers a read of
later rows there (it needs `pad` when `real` is a function), not a read of the rows of a
second. The second check, the cut windows the third writes anew and the shuffle and second pass
of the seventh are scored under `torch.no_grad()` and in training mode only. Without `build`,
every check runs on copies of the model as handed over, so what it kept on its instance from
calls made before the checks answers their changed windows. A state kept outside the model's
instances is shared by every copy and every new instance, so no check fails on it; run_checks
names what of it changes while the checks run, read where the code of the model reads it: an
attribute of a class of the model, a module variable its code names, the defaults and the
closure of a function it calls, a store that a deep copy hands back as itself. What the code
reaches another way (`globals()[...]`, a name made up at run time, a store behind an object of
a library) is not named, and nothing the code does not name is read or copied. The checks'
copies run the model's own hooks, so a hook that writes into a store it holds outside the
model writes there from every copy.

Beside the seven, `channels_stay_apart` reads the hand-off from the summary outputs of stage 1
to the channels of the stage and says whether every output reaches one channel of its own. A
hand-off that is a module, or a method of one such as `model.hand_off`, runs with its weights
moved a little, as the checks run a model, so that a mixing part that starts at zero (a gate or
a low-rank factor at 0) shows as well; a plain function (a lambda) runs as it is, and a line says
so. A linear layer or a layer norm over the joined vector before `.view`, or the numbers of the
outputs joined in the other order, keep the time rule and pass the seven checks; they fail this
one, which is run once on the hand-off of the model in use. When stage 1 of the model in use
returns the joined vector itself, the hand-off handed over starts at the summary outputs inside
stage 1 and holds its joining line, or stage 1 returns its outputs before the join. Numbers that
lie mostly outside [0, 1], having skipped the scaler, stop a training step of the checks with a
plain error, since the template builds its numeric encoder with `unscaled="raise"` (the default
of the encoder, `"warn"`, gives one warning for the fields it names in a batch); the encoder
counts the values of every field over
its first training batches, so a sparse field is judged on many values, and the numbers of padded
slots count as missing there, so that the encoder judges those of real rows only and nothing a
padded slot holds reaches it. Numbers that skipped the quantile scaler but lie on [0, 1]
(min-max scaled, say) pass that look and crowd into the first bins: `interval_use` on scaled
training rows says how many bins of each field hold rows.

## 2. Inputs and field tokens

| Setting | Today | Candidate | Test against | Evidence | Code |
|---|---|---|---|---|---|
| Token width | 48 | 96 | 48 (`WIDTH_48`); 144 (`WIDTH_144`) | **read**: a head narrower than the sequence it reads cannot form every attention pattern (arXiv 2002.07028, Theorem 1); today a stage-1 head is 6 numbers over 10 tokens. Every transaction model read is wider: 72 per field (UniTTab), 192 (PRAGMA small), 256 (TREASURE), 384 to 1,024 (Large Payments Model). The Large Payments Model's history model beat its single-transaction model on fraud only once it was wide: +27.6 against +26.8 percent AP at width 384, +49.1 against +36.0 at 768 (Fig. 8). **judgement**: 96 as the first step | `encoding/numeric_encoders.py`, `model/best_model_template.py` |
| Numeric encoding | piecewise-linear, 16 bins, a linear map per field, a bias per field | the same with 32 bins (no trained edges exist at 32: the numbers are read on the [0, 1] scale of `UnitQuantileScaler`, or `fit_edges` gives edges on that scale) | 16 bins (`NUMBERS_PLE16`); the Large Payments Model's encoding, raw value, Fourier terms with learned frequencies and piecewise-linear with learned centres joined and projected per field (`NUMBERS_HYBRID`); Fourier terms alone (`NUMBERS_PERIODIC`); learned centres alone (`NUMBERS_LEARNED_PLE`), beside the same with the centres held still (`NUMBERS_FROZEN_CENTRES`) | **read**: at millions of rows the choice of encoder moves results little: on 36.67 million rows with an attention model, piecewise-linear 0.8108 AUC, linear 0.8088, periodic 0.8086 (NumEmbBench, arXiv 2611.01090, Table 2); on an 11-million-row bank fraud table piecewise-linear gave +0.0027 AP with one optimiser and -0.0004 with another (arXiv 2610.26794). With a transformer, average ranks over 11 datasets: linear 5.9, periodic with a linear layer and ReLU 3.9, tree-binned piecewise 3.7 (arXiv 2203.05556, Table 6). A ReLU after the piecewise map hurt (rank 12.48 against 5.30). The Large Payments Model uses its combined encoding and reports no ablation of it. **measured** (`encoding/numeric_encoders.py`, a synthetic check of one field, three seeds): learned centres differ from fixed bins in their parametrization as well as in moving; under an MLP head a staircase of 32 steps gave a mean error of 0.0749 for fixed bins, 0.0388 for learned centres and 0.0315 with the centres held still, so the frozen arm is what tells the two apart. **judgement**: keep today's encoding, raise the bins, and test the combined one as an arm, since its gain is unmeasured | `encoding/numeric_encoders.py` (`NumericEncoder(kind=...)`: `ple`, `learned_ple`, `periodic`, `hybrid`; `learn_centres`) |
| Learned centres where they start | none | none (fixed bins) | in the arms with learned centres: 33 centres evenly on [0, 1] (32 intervals) and branches 32 wide, so 32 intervals keep 32 directions | **read**: on the scale of a quantile scaler the q-quantile of a field without ties sits at q (the Large Payments Model scales every field by its quantiles, section 3.1). **measured** (`interval_use` of `encoding/numeric_encoders.py` on 200,000 rows, 60 percent of them zero and the rest lognormal): 16 even intervals left 8 without a row, and the centres of `fit_centres` on the scaled rows left 1 | `encoding/numeric_encoders.py` (`fit_centres`, `interval_use`) |
| Input scaling for numbers | per field, before the bins | to [0, 1] by the field's own quantiles; numbers that skipped the scaler and lie mostly outside [0, 1] stop a training step with a plain error (`unscaled="raise"`, as the template builds the encoder; the default, `"warn"`, gives one warning for the fields it names in a batch); numbers that skipped it but lie on [0, 1] are seen by `interval_use`, not by that look | robust scaling with soft clipping | **read**: the Large Payments Model scales each field to [0, 1] by its quantiles (section 3.1); Fourier terms are meaningful only on scaled inputs | `encoding/numeric_encoders.py` (`unscaled`), `encoding/numeric_frontend.py` |
| Field identity | a bias per field | the same | none | **read**: the Large Payments Model keeps a learned identifier per field, also when the value is masked (section 3.1); a per-feature bias mattered in FT-Transformer (0.970 against 0.964 accuracy, arXiv 2106.11959) | in the tokenizer |
| Missing values | not known here; the stand-in's tokenizer has no vector for a missing number | as today: a missing number gives its field identity alone (`missing="zero"`, the default of `NumericEncoder`); the numbers of a padded slot count as missing too; separate rows for unseen, missing and not-applicable codes | a learned vector per field for a missing number (`MISSING_LEARNED`) | **read**: the Large Payments Model uses distinct learned tokens for out-of-vocabulary, missing and not-applicable values (section 3.1). **judgement**: whether the real numbers are ever missing is not known, and a learned vector that no batch uses gets no gradient, so the candidate keeps today's form | `encoding/numeric_encoders.py` (`missing`), `encoding/unknown_dropout.py` |
| Codes with very many values | merchant id left out on purpose | as today | if added: frequent values with rows of their own and the rare tail folded into shared rows, or four frequency partitions with narrower vectors for rarer values | **read**: four partitions in the Large Payments Model (section 3.1, Raman et al. 2024 with B = 4, alpha_v = -3, alpha_d = 2.25); on synthetic data the partitioned table reconstructed ids worse than a full table (54.5 against 58.7) with half the weights | `encoding/capped_vocab.py` |
| Card, device and account ids | not inputs | as today | recurrence columns in the account's history (first time seen, count so far, rows since last seen) | **read**: on 100 million sequences, ids as learned embeddings cost 5.87 percent AUC and recurrence features gained 1.11 percent (ID2Pattern) | `features/exact_match.py` |
| Merchant category | a table | a table started from text descriptions of the categories | a table from random values | **read**: TransactionGPT, +19.2 to +22.5 percent on its anomaly measure (Table 4) | `encoding/text_init.py` |
| Counts and amounts over 7, 30 and 90 days | not known here | as screened | as inputs, each family screened on the CPU first | **read**: the Large Payments Model feeds aggregates over 7 days, 30 days, a year and three years to both its variants (section 5.1); sequence models with engineered aggregates beat either alone in nuFormer and the Sber paper | `features/possible_features.py`, `after_model/family_screen.py` |
| Hour of day and day of week | not known whether among the 64 | added if absent | the calendar as sines and cosines of its fixed periods (`CALENDAR`) | **read**: no study isolates them in a fraud model; splitting the timestamp into calendar codes raised F1 from 0.829 to 0.840 on synthetic card data (UniTTab) | `encoding/time_encoders.py` (`CalendarEncoder`) |

## 3. The transaction stage

| Setting | Today | Candidate | Test against | Evidence | Code |
|---|---|---|---|---|---|
| What stage 1 reads | 4 predictors alone and 60 averaged in 3 groups | as today | every predictor as a token of its own (`STAGE1_ALL`); no stage 1 at all, a pooler of learned queries over the 64 field tokens, the Large Payments Model's way (`STAGE1_POOLER`, and within `CANDIDATE_LPM`) | **read**: the Large Payments Model keeps every field a token and builds its channels with an attention pooler (section 3.3). **judgement**: in the candidate every field still reaches the channels, through the cross-attention to the 64 field tokens in every pair, so the grouped inputs are kept for cost | `model/best_model_template.py` (`stage1`, `stage1_fields`), `model/latent_channels.py` (`ChannelPooler`) |
| Summary tokens (channels) | 3 | 6 | 3 (`CHANNELS_3`); 12 (`CHANNELS_12`) | **read**: the Large Payments Model sets the channels to about a fifth of the fields (section 5.1), which is about 13 here; at equal compute more and narrower latents helped until they stopped helping (Perceiver IO: 128 of 1,920 wide 75.84, 256 of 1,280 80.95, 512 of 896 80.92, Table 15) | `model/best_model_template.py` |
| Layers in stage 1 | 2 | 2 | 3 (`STAGE1_LAYERS_3`) | **read**: PRAGMA puts more depth in its per-event encoder than in its history (5 against 2 in the small model, Table 1). **judgement**: one more layer is a cheap arm | `model/best_model_template.py` |
| Heads in stage 1 | 8 of 6 numbers | 4 of 24 | 8 of 12 (`STAGE1_HEADS_8`) | **read**: arXiv 2002.07028 (above) | `model/best_model_template.py` |

## 4. The history stage

| Setting | Today | Candidate | Test against | Evidence | Code |
|---|---|---|---|---|---|
| Hand-off to the history | 3 summary outputs joined into 144 | 6 channels of 96 kept apart, joined only at the end | the wide joined model: 3 summary outputs of 96 joined into 288 (`WIDE_JOINED`) | **read**: in TransactionGPT the best variant kept several virtual tokens per transaction inside the history (+19.2 against +14.6 and +7.3 percent, Table 4), and more bandwidth into the history helped. No study compares channels kept apart with one joined vector at equal compute; the Large Payments Model's comparison point is one channel per field. **judgement**: the candidate, to be kept only if it wins the head-to-head. A joined vector of the model in use is split with `.view` only when it is the summary outputs side by side in channel-major order with nothing applied after the join; `channels_stay_apart` of the template says whether a hand-off keeps every output in one channel of its own | `model/latent_channels.py` (`LatentChannelStage`), `model/best_model_template.py` (`hand_off`, `channels_stay_apart`) |
| Order of the blocks | staged: stage 1, then 4 history layers (with the re-read after each layer, which made it partly interleaved) | interleaved: 4 pairs of a within-transaction block and a through-time block | staged (`LAYOUT_STAGED`); through-time blocks alone with one read of the fields at the end (`LAYOUT_TEMPORAL_ONLY`) | **read**: the Large Payments Model interleaves and argues for it, without a test (section 3.3); Latte's interleaved variant was best (a figure only); reading the input again through depth gave 78.0 against 73.7 when all reads came first (Perceiver, Table 6). Against: in ViViT the staged encoder beat the interleaved one (78.8 against 77.4 and 43.7 against 39.1, Table 2). In this model the re-read after every history layer gained about 2 AP points | `model/latent_channels.py` (`layout`) |
| Within a transaction: reading the fields | the re-read block, when it is on | on: the 64 field tokens and the memory of the 5 latest earlier rows | the fields of the row alone (`MEMORY_0`); a memory of 10 rows (`MEMORY_10`); the bank through `PredictorBank` (`BANK_PREDICTOR_BANK`); no reading of the fields after stage 1 (`INTRA_CROSS_OFF`) | **read**: the Large Payments Model's channels read the original field embeddings in every block (section 3.3); the memory of earlier rows goes beyond it | `model/latent_channels.py` (`intra_cross_attention`, `num_back`) |
| Rows of an earlier second in the memory | no memory (the re-read of 24 November took them by their slots) | whole seconds: all the rows of an earlier second or none (`memory_ties="whole_seconds"`) | by their slots (`MEMORY_SLOT`) | **measured** (the order check of `model/best_model_template.py`, weights moved by noise, two made-up batches of 4 sequences of 30 rows): shuffling the rows of each second among their slots moved scores by 1.1e-2 and 1.6e-2 of the largest score with the rows taken by slot, and by 4e-7 and 5e-7, rounding, with whole seconds. **measured** (`latest_prior_rows` of `model/interleaved_reread.py`): whole seconds leave the memory short after a burst. With `num_back` 5, a burst of 8 rows in one second leaves the next five rows holding 0, 1, 2, 3 and 4 earlier rows, where the slot rule holds 5 each; on `make_batch(0)` at 16 x 121, 343 of the 1,409 real rows hold fewer earlier rows than under the slot rule (4.50 on average against 4.82). What that costs in labels is not measured; `MEMORY_SLOT` measures it. **judgement**: the time does not order the rows of one second and the scorer may not write them in the builder's order, so the candidate takes whole seconds; the slot rule stays only to reproduce the re-read of 24 November | `model/interleaved_reread.py` (`ties`), `model/latent_channels.py` |
| Within a transaction: channels reading one another | none | on | off (`INTRA_SELF_OFF`) | **read**: with few channels, mixing them gained little or hurt in forecasting (iTransformer, Table 3); the Large Payments Model has it. **judgement**: on, and tested off | `model/latent_channels.py` (`intra_self_attention`) |
| Order inside a within-transaction block | none | the fields first, then one another (`intra_order="cross_first"`) | one another first, the order of the first version of the stage (`INTRA_SELF_FIRST`) | **read**: Figure 4 of the Large Payments Model draws the read of the fields before the channels read one another; its text fixes no order (section 3.3) | `model/latent_channels.py` (`intra_order`) |
| Through time | one attention over the joined vectors | each channel on its own, one set of weights for all channels | a set of weights per channel (`SHARE_TEMPORAL_OFF`) | **read**: separate time and space weights beat joint attention (TimeSformer 78.0 and 59.5 against 77.4 and 58.5, Table 1); channels kept apart with shared weights beat mixing them in forecasting (PatchTST, Traffic 0.367 against 0.595 MSE, Table 7) | `model/latent_channels.py` (`share_temporal`) |
| Channel identity | none | a learned vector per channel | none (`CHANNEL_IDENTITY_OFF`) | **judgement**: shared weights cannot tell channels apart without it; the Large Payments Model does not say | `model/latent_channels.py` (`channel_identity`) |
| A map per channel | none | off | on (`CHANNEL_PROJECTIONS_ON`) | **read**: a projection per row type raised F1 from 0.526 to 0.536 (UniTTab, Table 11) | `model/latent_channels.py` (`channel_projections`) |
| A last read of the fields | the re-read after stage 2 | on; final_intra takes the place of the model's re-read after stage 2; keep only one of the two | off, the Large Payments Model's order (`FINAL_INTRA_OFF`) | **read**: this model's gain came from re-reads after the history layers. **judgement**: on | `model/latent_channels.py` (`final_intra`) |
| Pairs | 4 layers | 4 pairs | 6 pairs (`PAIRS_6`) | **read**: in ViViT the temporal depth stopped mattering after 1 to 4 layers (78.6, 78.8, 78.8, 78.9, Table 3) | `model/latent_channels.py` (`num_pairs`) |
| Heads through time | 8 of 18 numbers | 4 of 24 | 3 of 32 (`HISTORY_HEADS_3`) | **read**: arXiv 2002.07028; on a GPU, 16-bit attention kernels want a head width that is a multiple of 8 | `model/latent_channels.py` |
| Position | a learned table by the count of strictly earlier rows | as today; a position the model in use puts in front of the rows is dropped, since the stage has none | none | **read**: in FraudTransformer learned positions gave most of the gain (PR-AUC 0.92038 without, 0.94689 with, Table 4) | inside the stage |
| Time gap | log1p of the gap as an input number | the gap through the same piecewise-linear encoding as other numbers, after a soft log, added to the row | today's number (`GAP_SCALAR`); sines of the gap as FraudTransformer runs them, a base of 1e7 on milliseconds, a layer norm and a gain of 0.01 (`GAP_SINUSOID`); the same sines counted in whole seconds, beside it (`GAP_SINUSOID_SECONDS`) | **read**: FraudTransformer's sines of the time between events, added to learned positions, raised PR-AUC from 0.94689 to 0.95816; absolute time added almost nothing (0.94713, Table 4). The soft log 8 ln(1 + t / 8) is PRAGMA's. **measured** (`encoding/time_encoders.py`, a synthetic check on whole-second gaps of seconds to 90 days, three seeds): the sines in milliseconds were the weakest gap encoder, 0.072 against 0.059 for the number and 0.037 for the bins at a learning rate of 0.01, while the sines counted in seconds gave 0.043. **judgement**: encode the gap like other numbers first | `encoding/time_encoders.py` (`GapEncoder`, `ticks_per_second`) |
| A learned bias on attention by time gap | none | on, built by the stage itself from the times of every call, with its own heads and unit | off (`TIME_BIAS_OFF`) | **read**: removing the relative time and position bias cost 0.0043 in normalised entropy where 0.001 counts as significant (HSTU, Table 5). **judgement**: built by the stage, a bias cannot come from another batch or another time unit | `model/attention_bias.py` (`AttentionBias`), `model/latent_channels.py` (`time_bias`) |
| History length | 120 earlier seconds | 120 | longer, only when a count and a full-history training arm say that more helps | **read**: in the Large Payments Model fraud AP was still rising at 32 transactions (58, 86 and about 94 percent of the value at 32 for 1, 8 and 24); in a fraud GRU the best cut-off lay between 150 and 400 earlier transactions | `RECIPE.md` |
| Masks | a row reads itself and real rows of strictly earlier whole seconds; padding reads only itself | as today, with one time unit, an integer, in every piece | none | needed for training and scoring to agree. The checks of the template take the unit from whoever runs them and require the real rows' times read with it to lie between 2000-01-01 and 2100-01-01 | every module; `model/best_model_template.py` (`run_checks`, `time_unit_fits`) |

## 5. Readout, head and exported vector

| Setting | Today | Candidate | Test against | Evidence | Code |
|---|---|---|---|---|---|
| Readout | the re-read, then the head on 144 | the 6 channels joined (576) with a layer norm, then a linear head | a learned fraud query over the channels (`READOUT_ATTENTION`), with a generic query beside it (the Large Payments Model's output pooler); the average of the channels (`READOUT_MEAN`) | **read**: an attention decoder beat averaging by 0.4 to 5.1 points (Perceiver IO, Table 7); reading one token out beat reading two (TransactionGPT, +19.2 against +15.5) | `model/latent_channels.py` (`readout`) |
| Exported vector | the head's input | the 576 numbers the head reads | the generic query's vector | **read**: in the Large Payments Model a frozen generic vector with a small head came within about 2 percent AP of a dedicated model on a new target (-2.1 percent for a linear probe, -1.3 for attention pooling, Table 3) | `model/best_model_template.py` (`export`) |

## 6. Training settings that belong to the model

The training recipe and the order of runs are in `RECIPE.md`. Six settings depend on the
architecture and are listed here.

| Setting | Today | Candidate | Test against | Evidence |
|---|---|---|---|---|
| Learning rate of the through-time blocks | as the rest | as the rest | half | **read**: the Large Payments Model gave its temporal modules a slightly lower rate, with a small benefit and no factor stated (section 5.1) |
| Learning rate of learned centres | no learned centres | no learned centres | in the arms with them: a tenth of the rate (`CENTRE_LR_FACTOR`, `param_groups`) | **measured** (`encoding/numeric_encoders.py`, five heavy-tailed fields, Adam at a rate of 0.1, three seeds): 42 to 68 percent of the centres ended outside [0, 1]; at a tenth of the rate every centre stayed between -0.09 and 1.19 |
| Weight decay by kind of weight | not known here | decay on every map; none on norms, biases, embedding tables and learned vectors that are added as they are | | **judgement**: decay pulls a bias or a row of a table toward zero, which changes what it says rather than how large a map may grow (`param_groups` of the template) |
| Number type | mixed 16-bit | as today; cast to 16 bits, the numeric encoder keeps its frequencies, centres and edges in 32 bits, and its matrices and vectors take the 16-bit type | 32-bit, one paired arm | **read**: the Large Payments Model found 32-bit better, with a larger gap for its sequence model (section 5.1); TransactionGPT found 32-bit kept the gains of more data |
| Peak learning rate | 3e-4, never lowered | swept for every architecture (three values at 5 percent of the budget) | | `RECIPE.md` |
| Extra losses | none | none | next-transaction heads, scaled against the fraud loss | **read**: in TREASURE next-transaction losses raised its measure from 1.9606 to 2.1171 with the losses rescaled, and lowered it to 1.8768 when they were simply added |

## 7. Cost

The candidate costs more than today's model, mostly in activations rather than weights: six
channels of 96 carry 576 numbers per row through every pair, where today's history carries 144,
and every channel reads a bank of 64 field tokens and those of its 5 latest earlier rows in
every pair. The table is measured with the whole stand-in of `best_model_template.py`
(`cost`, through `compare`) on a CPU: 16 sequences of up to 121 rows (1,409 real rows), 4
threads, the best of 3 calls after one to warm up, every arm in two runs, the second in the
reverse order of the first. No other job ran (the one-minute load average was 0.1 before the
first arm and at most 3.9 while the measurement kept the 4 cores busy). Inside a run the
slowest of the three calls was up to 42 percent above the best for scoring and up to 30
percent for a training step, and the two runs differ by about as much: the candidate's step
took 13.6 and 10.1 times today's. A ratio is therefore good to about a quarter, and a GPU will
give other ratios: run `compare` on the GPU for every arm before any run is scheduled, and
budget the runs in GPU hours from it. The time factors of the configuration arms in
`sweep/arms.py` are the means of the two step ratios below.

What the table says, on this CPU:

- The memory of earlier fields is most of the candidate's cost: without it (`MEMORY_0`) a
  training step took 2.0 to 2.7 times less time, and a memory of 10 rows (`MEMORY_10`) took
  1.6 to 2.0 times more. Without any read of the fields after stage 1 (`INTRA_CROSS_OFF`) the
  step took 2.7 to 3.7 times less.
- Against the wide joined model, the candidate scored a batch 4.6 to 5.0 times slower and took
  6.3 to 7.9 times as long for a training step, with a third of its weights: 1,529,998
  against 4,472,354 (`TODAY` has 1,155,602).
- The channels add width without adding weights: 3, 6 and 12 channels have 1,528,270,
  1,529,998 and 1,533,454 weights, and their steps took 7.8 to 8.2, 10.1 to 13.6 and 20.9 to
  21.8 times today's.
- Stage 1 over every predictor (`STAGE1_ALL`) was the costliest arm, 21.2 to 24.0 times
  today's step, since stage 1 then reads 70 tokens per row where it reads 13.

| Arm | Weights | Scoring a batch, s (run 1 / run 2) | x TODAY | Training step, s (run 1 / run 2) | x TODAY |
|---|---|---|---|---|---|
| `TODAY` | 1,155,602 | 0.068 / 0.070 | 1.0 / 1.0 | 0.44 / 0.43 | 1.0 / 1.0 |
| `WIDE_JOINED` | 4,472,354 | 0.108 / 0.095 | 1.6 / 1.4 | 0.75 / 0.69 | 1.7 / 1.6 |
| `CANDIDATE` | 1,529,998 | 0.496 / 0.473 | 7.3 / 6.8 | 5.97 / 4.33 | 13.6 / 10.1 |
| `CANDIDATE_LPM` | 1,647,286 | 0.370 / 0.385 | 5.4 / 5.5 | 4.16 / 3.97 | 9.5 / 9.3 |
| `WIDTH_48` | 433,246 | 0.237 / 0.236 | 3.5 / 3.4 | 2.62 / 2.88 | 6.0 / 6.7 |
| `WIDTH_144` | 3,290,302 | 0.623 / 0.655 | 9.2 / 9.4 | 8.29 / 8.41 | 18.9 / 19.6 |
| `NUMBERS_PLE16` | 1,468,558 | 0.488 / 0.445 | 7.2 / 6.4 | 5.69 / 4.36 | 13.0 / 10.2 |
| `NUMBERS_LEARNED_PLE` | 1,573,558 | 0.493 / 0.492 | 7.2 / 7.1 | 5.66 / 4.68 | 12.9 / 10.9 |
| `NUMBERS_FROZEN_CENTRES` | 1,573,558 | 0.437 / 0.423 | 6.4 / 6.1 | 4.62 / 5.19 | 10.6 / 12.1 |
| `NUMBERS_PERIODIC` | 1,534,478 | 0.467 / 0.447 | 6.9 / 6.4 | 5.47 / 5.04 | 12.5 / 11.8 |
| `NUMBERS_HYBRID` | 1,863,478 | 0.477 / 0.500 | 7.0 / 7.2 | 5.13 / 4.98 | 11.7 / 11.6 |
| `MISSING_LEARNED` | 1,533,838 | 0.433 / 0.448 | 6.4 / 6.4 | 4.98 / 4.69 | 11.4 / 10.9 |
| `STAGE1_ALL` | 1,529,998 | 0.719 / 0.652 | 10.6 / 9.4 | 10.49 / 9.09 | 24.0 / 21.2 |
| `STAGE1_POOLER` | 1,418,350 | 0.472 / 0.421 | 6.9 / 6.0 | 4.78 / 4.24 | 10.9 / 9.9 |
| `STAGE1_LAYERS_3` | 1,641,838 | 0.460 / 0.461 | 6.8 / 6.6 | 4.99 / 5.04 | 11.4 / 11.7 |
| `STAGE1_HEADS_8` | 1,529,998 | 0.427 / 0.427 | 6.3 / 6.1 | 4.71 / 4.95 | 10.7 / 11.5 |
| `CHANNELS_3` | 1,528,270 | 0.377 / 0.343 | 5.5 / 4.9 | 3.41 / 3.52 | 7.8 / 8.2 |
| `CHANNELS_12` | 1,533,454 | 0.701 / 0.590 | 10.3 / 8.5 | 9.55 / 8.95 | 21.8 / 20.9 |
| `PAIRS_6` | 2,014,990 | 0.567 / 0.553 | 8.3 / 7.9 | 7.27 / 7.37 | 16.6 / 17.2 |
| `HISTORY_HEADS_3` | 1,529,987 | 0.416 / 0.396 | 6.1 / 5.7 | 3.87 / 4.32 | 8.8 / 10.1 |
| `LAYOUT_STAGED` | 1,138,030 | 0.354 / 0.328 | 5.2 / 4.7 | 2.73 / 2.58 | 6.2 / 6.0 |
| `LAYOUT_TEMPORAL_ONLY` | 1,007,374 | 0.300 / 0.317 | 4.4 / 4.6 | 2.11 / 2.02 | 4.8 / 4.7 |
| `MEMORY_0` | 1,529,038 | 0.246 / 0.268 | 3.6 / 3.8 | 2.19 / 2.20 | 5.0 / 5.1 |
| `MEMORY_10` | 1,530,958 | 0.696 / 0.690 | 10.2 / 9.9 | 9.43 / 8.70 | 21.5 / 20.3 |
| `MEMORY_SLOT` | 1,529,998 | 0.429 / 0.441 | 6.3 / 6.3 | 5.47 / 4.75 | 12.5 / 11.1 |
| `BANK_PREDICTOR_BANK` | 1,567,630 | 0.507 / 0.584 | 7.5 / 8.4 | 5.12 / 5.43 | 11.7 / 12.7 |
| `INTRA_SELF_OFF` | 1,342,798 | 0.414 / 0.450 | 6.1 / 6.5 | 4.78 / 4.26 | 10.9 / 9.9 |
| `INTRA_CROSS_OFF` | 1,403,662 | 0.182 / 0.180 | 2.7 / 2.6 | 1.64 / 1.63 | 3.7 / 3.8 |
| `INTRA_SELF_FIRST` | 1,529,998 | 0.463 / 0.545 | 6.8 / 7.8 | 5.08 / 5.29 | 11.6 / 12.3 |
| `SHARE_TEMPORAL_OFF` | 3,766,798 | 0.474 / 0.528 | 7.0 / 7.6 | 5.28 / 5.61 | 12.1 / 13.1 |
| `CHANNEL_IDENTITY_OFF` | 1,529,422 | 0.459 / 0.490 | 6.8 / 7.0 | 5.46 / 5.73 | 12.5 / 13.4 |
| `CHANNEL_PROJECTIONS_ON` | 1,585,870 | 0.502 / 0.598 | 7.4 / 8.6 | 5.14 / 5.95 | 11.7 / 13.9 |
| `FINAL_INTRA_OFF` | 1,399,342 | 0.405 / 0.421 | 6.0 / 6.0 | 3.88 / 4.47 | 8.9 / 10.4 |
| `READOUT_ATTENTION` | 1,556,110 | 0.420 / 0.700 | 6.2 / 10.1 | 5.12 / 5.09 | 11.7 / 11.9 |
| `READOUT_MEAN` | 1,527,886 | 0.450 / 0.604 | 6.6 / 8.7 | 5.31 / 5.58 | 12.1 / 13.0 |
| `GAP_SCALAR` | 1,528,558 | 0.471 / 0.455 | 6.9 / 6.5 | 5.08 / 5.40 | 11.6 / 12.6 |
| `GAP_SINUSOID` | 1,528,558 | 0.488 / 0.462 | 7.2 / 6.6 | 5.25 / 5.28 | 12.0 / 12.3 |
| `GAP_SINUSOID_SECONDS` | 1,528,558 | 0.443 / 0.438 | 6.5 / 6.3 | 4.82 / 5.49 | 11.0 / 12.8 |
| `TIME_BIAS_OFF` | 1,529,954 | 0.423 / 0.435 | 6.2 / 6.3 | 4.80 / 4.76 | 11.0 / 11.1 |
| `CALENDAR` | 1,533,582 | 0.412 / 0.439 | 6.1 / 6.3 | 4.86 / 4.98 | 11.1 / 11.6 |

## 8. The order

1. On the GPU, before anything else: `run_checks` on the model in use with one of its own
   batches and the time unit its builder writes, and `channels_stay_apart` on its hand-off when
   the channel stage is fitted in. Then the cost: `compare(list(ARMS), batch, repeats=50)` of
   `best_model_template.py` builds the stand-in of every arm, so it takes a batch of the
   stand-in at the model's sizes (`make_batch(sequences=B, rows=T)` with the PLACEHOLDER sizes of
   the template set to the model's), and the edited model in use itself is timed with
   `cost(model, batch, loss)` on one of its own batches. Every run below is then budgeted from a
   measurement.
2. The control: `TODAY` with the schedule of `RECIPE.md`, three seeds, at the reduced scale.
3. The head-to-head: `WIDE_JOINED` against `CANDIDATE`, two seeds each, each at its own best
   learning rate, at the reduced scale. This tests the candidate as a whole: besides keeping the
   channels apart, it has six summary outputs in place of three, 32 bins, the gap in bins and the
   time bias, four entries that also act on a joined history. If `WIDE_JOINED` wins, the arms of
   the channel stage below do not apply, and the numbers and the time inputs are tried on it with
   the same entries. If `CANDIDATE` wins, `WIDE_JOINED` with the three encodings set as in the
   candidate (`replace(WIDE_JOINED, n_bins=32, gap_encoder="ple", time_bias=True)`, 4,538,158
   weights) says how much of the gain the channel stage as a whole brings against its cost: six
   outputs kept apart against three joined, and the stage's reads of the 64 predictor tokens in
   every pair, of the fields of the 5 latest earlier rows and of the fields once more at the end.
   With `interleaved_reread="AM", bank="predictor"` as well (5,349,554 weights) the joined
   history also re-reads, after every layer, the predictor tokens of the row and those of its 5
   latest earlier rows, so that what is left to differ is the outputs kept apart and the shape
   of those reads; with `num_summary=6` too, it reads the same six outputs at 576 wide
   (18,593,522 weights; 16,786,798 without the re-reads), which sets the channels against the
   same outputs joined.
4. On the winner, one change at a time, in this order:
   - the arms that make the candidate cheaper if they hold, which are also among the quickest
     to run: `MEMORY_0`, `INTRA_CROSS_OFF`, `LAYOUT_TEMPORAL_ONLY`, `LAYOUT_STAGED`,
     `CHANNELS_3`, `WIDTH_48`, `FINAL_INTRA_OFF`, `STAGE1_POOLER`;
   - the encodings: `NUMBERS_HYBRID`, `NUMBERS_PERIODIC`, `NUMBERS_LEARNED_PLE` with
     `NUMBERS_FROZEN_CENTRES` beside it, `NUMBERS_PLE16`, `GAP_SCALAR`, `GAP_SINUSOID` with
     `GAP_SINUSOID_SECONDS` beside it, `TIME_BIAS_OFF`; `MISSING_LEARNED` only when the real
     numbers are ever missing, and `CALENDAR` only when the hour and the weekday are not
     among the predictors;
   - the shape of the stage: `INTRA_SELF_OFF`, `INTRA_SELF_FIRST`, `READOUT_ATTENTION`,
     `READOUT_MEAN`, `CHANNEL_IDENTITY_OFF`, `CHANNEL_PROJECTIONS_ON`, `SHARE_TEMPORAL_OFF`,
     `HISTORY_HEADS_3`, `STAGE1_HEADS_8`, `STAGE1_LAYERS_3`, `BANK_PREDICTOR_BANK`, and
     `MEMORY_SLOT`, which says whether the slot rule of the re-read of 24 November gains or
     loses anything against whole seconds;
   - the arms that cost the most, 16.6 to 24.0 times today's step on the CPU: `PAIRS_6`,
     `WIDTH_144`, `MEMORY_10`, `CHANNELS_12`, `STAGE1_ALL`;
   - `CANDIDATE_LPM`, the four entries of the Large Payments Model together, once the single
     entries above have been read;
   - beside them, the training settings of section 6: half the learning rate through time,
     32-bit numbers, next-transaction heads, full-history training rows.
5. Everything that held, together, on the whole pool of files, three seeds, read once on the
   confirm block.

## 9. Not built

- Rotary encodings by time in the through-time attention (a published alternative to the
  time bias in recommendation models).
- Joint attention over channels and rows together (TransactionGPT's layout).
- Partitioned tables for ids with many values (`encoding/capped_vocab.py` has a capped,
  tiered table instead).
- Self-supervised pretraining by masked fields (the Large Payments Model's objective);
  next-transaction heads are built (`training/next_transaction_heads.py`).
