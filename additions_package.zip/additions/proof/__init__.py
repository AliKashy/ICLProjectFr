"""Tools for comparing models fairly.

blend_ladder.py      blend ladder: what each model adds to a blend of several scores, read out of
                     fold
block_bootstrap.py   other ways to resample: by calendar day and by cluster, and a bar raised for
                     many arms
diagnosis.py         diagnosis: where two or three models win and lose, read on the same rows at
                     each model's own cut
head_to_head.py      head-to-head: two or three models compared on the same transactions, counted
                     one way
noise_budget.py      noise budget: what a block of files and a number of seeds can show, before any
                     arm is read
run_scorecard.py     run-level scorecard: how early a model enters a fraud run, and what lies after
                     its first alert
screening_rule.py    the order in which ideas are decided: a cheap tree screen first, then one
                     decision for the bundle
time_consistency.py  time consistency of candidate columns: does a column rank fraud the same way
                     later, and does it drift?
_shared.py           shared pieces of the comparison tools: score files lined up by id, per-row
                     arrays, fraud runs
"""
