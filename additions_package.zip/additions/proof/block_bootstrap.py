"""Other ways to resample: by calendar day and by cluster, and a bar raised for many arms.

What this file does
-------------------
It reads the gain of a candidate over a control at the alert cut several times, each time
with another unit of resampling: whole accounts (the standard read), whole calendar days,
blocks of several days, and whole clusters of a chosen column (the merchant, for example). It
prints every interval, marks the widest, and counts on how many days each model is ahead. It
also computes how much the best of several arms with no real effect is expected to gain by
chance, which is the amount to add to the bar when many arms were read on the same rows.

Why it exists
-------------
Frauds come in runs on one account, which is why the standard bootstrap resamples accounts.
Fraud also arrives in waves: one compromised merchant or one attack produces frauds on many
accounts within the same days. An account bootstrap treats those accounts as independent
pieces of evidence, although they are one event. Resampling days, or merchants, keeps such an
event together. When waves matter, these intervals are wider than the account interval, and
the widest one is the honest statement of what the block can show. When they are all alike,
the account interval can be trusted as it is. A narrower interval from another unit is no
reason to prefer it: resampling merchants, for example, splits the run of an account over
several clusters and so treats its frauds as more independent than they are.

The second half answers a different source of false wins. The alert budget is a fixed small
share of rows, so a few rows moving across the cut change the capture. Among many arms that
do nothing, the luckiest one therefore shows a gain. The expected size of that gain grows
with the number of arms, and a bar that ignores it adopts noise.

Two cautions. The files hold whole accounts and no account is in two files, so a merchant's
rows are present only for the accounts in the files that were read: the clusters seen here
are thinner than the real ones, and the cluster interval is if anything too narrow. And an
interval drawn from a handful of units (a month has about thirty days) is itself rough; the
number of units is printed beside each interval for that reason.

Where it goes
-------------
Comparison: after scoring, beside every paired read of a candidate against its control
(additions/common/bootstrap.py does the resampling; this file only supplies other units).
The cluster column is used as a grouping key only, never as a model input.

What to change for the pod
--------------------------
settings.py: ID_COL, ACCOUNT_COL, TIME_COL, LABEL_COL, AMOUNT_COL, SCORE_COL, MERCHANT_COL (the
default cluster column), TARGET_START, TARGET_END, OUTSORT_PER_MILLE and the bootstrap
settings; EVAL_BASE when the cluster column is joined from raw files. BLOCK_DAYS below. The
calendar day is taken from the timestamps as they are stored; shift the times first if the
business day starts at another hour.

How to try it
-------------
    python additions/proof/block_bootstrap.py --preds candidate.parquet control.parquet --arms 12 --bar 0.005
    (add --raw-base and --raw-files when the cluster column is not in the score files)
or, from Python:
    table = all_intervals(labels, scores_a, scores_b, accounts, secs, clusters)
    print(table); print(widest(table))
    print(deflated_bar(n_arms=10, se=0.006))        # the numbers are examples
The tests are in additions/tests/test_proof_block_bootstrap.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd
from scipy import stats

from additions import settings
from additions.common import ranking, timekeys
from additions.common.bootstrap import paired_bootstrap
from additions.common.timekeys import MISSING_SECOND
from additions.proof import _shared

DAY = 86_400

# The lengths, in days, of the time blocks that are resampled. One day follows a wave that
# lasts a day; three days keep a longer wave together at the price of fewer blocks.
BLOCK_DAYS = (1, 3)


def day_units(secs, block_days=1):
    """A block number per row: its calendar day, or a block of several consecutive days.

    secs         whole seconds per row, shape [rows]
    block_days   the length of a block in days

    Returns an integer array [rows]. Rows of the same block share a number. Rows without a
    time are put together in one block of their own.
    """
    secs = np.asarray(secs, dtype=np.int64)
    units = secs // (DAY * int(block_days))
    units[secs == MISSING_SECOND] = -1
    return units


def cluster_units(values):
    """A cluster number per row: rows with the same value share a number.

    values   one value per row (a merchant id, for example), shape [rows]

    A row without a value becomes a cluster of its own. Putting all such rows into one large
    cluster would tie together rows that have nothing in common.
    """
    series = pd.Series(np.asarray(values))
    units = timekeys.codes(series)
    missing = series.isna().to_numpy()
    if missing.any():
        units[missing] = int(units.max()) + 1 + np.arange(int(missing.sum()))
    return units


def all_intervals(labels, scores_a, scores_b, accounts, secs=None, clusters=None, amounts=None, block_days=None,
                  per_mille=None, draws=None, seed=None, interval=None, rounding=None, value=False):
    """The gain of A over B with one interval per way of resampling.

    labels     1 for fraud, 0 otherwise, shape [rows]
    scores_a   the candidate's scores; scores_b the control's scores, shape [rows]
    accounts   the account of every row, shape [rows]
    secs       whole seconds per row, or None to skip the day blocks
    clusters   one value per row of the cluster column, or None to skip the cluster read
    value      False compares the share of frauds caught; True the share of fraud dollars
               (then `amounts` is needed)

    Returns a DataFrame with one line per way of resampling: resampled ("account", "day",
    "3-day block", "cluster"), units (how many there are), gain (the same on every line: it is
    the gain on the full data), low, high, width, se, share_above_zero, and widest (True on the
    line with the widest interval). The decision should rest on the widest line.
    """
    block_days = BLOCK_DAYS if block_days is None else block_days
    ways = [("account", np.asarray(accounts))]
    if secs is not None:
        for days in block_days:
            ways.append(("day" if int(days) == 1 else f"{int(days)}-day block", day_units(secs, days)))
    if clusters is not None:
        ways.append(("cluster", cluster_units(clusters)))
    lines = []
    for name, units in ways:
        # The same function as the standard read; only the unit that is drawn changes.
        boot = paired_bootstrap(units, labels, scores_a, scores_b, amounts, per_mille, draws, seed, interval,
                                rounding, value)
        line = {"resampled": name, "units": len(np.unique(units))}
        for key in ("gain", "low", "high", "se", "share_above_zero"):
            line[key] = np.nan if boot[key] is None else float(boot[key])
        line["width"] = line["high"] - line["low"]
        lines.append(line)
    table = pd.DataFrame(lines)[["resampled", "units", "gain", "low", "high", "width", "se", "share_above_zero"]]
    table["widest"] = table["width"] == table["width"].max()
    return table


def widest(table):
    """The line of `all_intervals` with the widest interval, as a dict.

    When no interval could be drawn at all (no fraud in the rows), the first line is returned.
    """
    if table["width"].notna().any():
        return table.loc[table["width"].idxmax()].to_dict()
    return table.iloc[0].to_dict()


def daily_wins(labels, scores_a, scores_b, secs, per_mille=None, rounding=None):
    """On how many days each model catches more frauds, at the one cut over all rows.

    Returns (summary, days). `days` has one line per calendar day with a fraud: day, frauds,
    caught_a, caught_b. `summary` is a dict: days, a_ahead, b_ahead, level, share_a_ahead (of
    the days on which one model is ahead) and p_value (the exact test on a_ahead against
    b_ahead). A gain that comes from two or three days is a different finding from a gain
    that shows on most days, and one capture figure cannot tell them apart.
    """
    fraud = np.asarray(labels).astype(np.float64) > 0
    secs = np.asarray(secs, dtype=np.int64)
    in_a = ranking.alert_mask(scores_a, per_mille, rounding)
    in_b = ranking.alert_mask(scores_b, per_mille, rounding)
    keep = fraud & (secs != MISSING_SECOND)
    day, code = np.unique(secs[keep] // DAY, return_inverse=True)
    days = pd.DataFrame({"day": day.astype("datetime64[D]").astype(str),
                         "frauds": np.bincount(code, minlength=len(day)),
                         "caught_a": np.bincount(code, weights=in_a[keep], minlength=len(day)).astype(np.int64),
                         "caught_b": np.bincount(code, weights=in_b[keep], minlength=len(day)).astype(np.int64)})
    a_ahead = int((days["caught_a"] > days["caught_b"]).sum())
    b_ahead = int((days["caught_b"] > days["caught_a"]).sum())
    summary = {"days": len(days), "a_ahead": a_ahead, "b_ahead": b_ahead, "level": len(days) - a_ahead - b_ahead,
               "share_a_ahead": a_ahead / (a_ahead + b_ahead) if a_ahead + b_ahead else np.nan,
               "p_value": _shared.exact_test(a_ahead, b_ahead)}
    return summary, days


def expected_best_of(n_arms, correlation=0.0):
    """The expected maximum of `n_arms` standard normal draws, in standard errors.

    n_arms        how many arms were read on the same rows
    correlation   the correlation between the gains of two arms, between 0 and 1. Arms read on
                  the same rows against the same control share part of their noise; with a
                  correlation r the expected maximum shrinks by the factor sqrt(1 - r). The
                  default 0 treats the arms as independent, which is the careful figure.

    One arm gives 0, two give 0.56, ten give 1.54 and thirty give 2.04. The value is the
    integral of x times the density of the largest of n draws, taken on a fine grid.
    """
    n = int(n_arms)
    if n <= 1:
        return 0.0
    x = np.linspace(-10.0, 15.0, 25_001)
    # Density of the maximum: n * pdf(x) * cdf(x)^(n-1), written with logs so large n stays finite.
    density = n * np.exp(stats.norm.logpdf(x) + (n - 1) * stats.norm.logcdf(x))
    y = x * density
    integral = float(((y[1:] + y[:-1]) / 2.0).sum() * (x[1] - x[0]))
    return integral * float(np.sqrt(max(0.0, 1.0 - float(correlation))))


def deflated_bar(n_arms, se, correlation=0.0):
    """How much the best of `n_arms` arms with no real effect is expected to gain by chance.

    n_arms   how many arms were read on the same rows (count every arm that was looked at,
             not only the ones that are reported)
    se       the standard error of one arm's paired gain (the `se` of the paired bootstrap)

    Returns a gain in the unit of `se`: the expected maximum of n standard normal draws times
    the standard error. Add it to the bar an arm has to clear. The best of the arms then has
    to beat what luck alone would give the best of that many arms.
    """
    return expected_best_of(n_arms, correlation) * float(se)


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(
        description="Paired gain of a candidate over a control, resampled by account, by day and by cluster.")
    parser.add_argument("--preds", nargs=2, required=True, metavar=("CANDIDATE", "CONTROL"),
                        help="two score files (parquet) of the same transactions")
    _shared.add_score_arguments(parser)
    parser.add_argument("--cluster-col", default=None, help="cluster column (default: settings.MERCHANT_COL)")
    parser.add_argument("--block-days", type=int, nargs="+", default=None, help="lengths of the day blocks (default: 1 3)")
    parser.add_argument("--value", action="store_true", help="compare fraud dollars caught instead of frauds caught")
    parser.add_argument("--arms", type=int, default=None, help="number of arms read on these rows, to raise the bar")
    parser.add_argument("--bar", type=float, default=0.0, help="the bar before it is raised (a gain in capture)")
    parser.add_argument("--draws", type=int, default=None, help="bootstrap draws (default: settings.BOOTSTRAP_DRAWS)")
    parser.add_argument("--seed", type=int, default=None, help="bootstrap seed (default: settings.BOOTSTRAP_SEED)")
    parser.add_argument("--out", default=None, help="write the table of intervals to this parquet file")
    args = parser.parse_args(argv)

    cluster_col = settings.MERCHANT_COL if args.cluster_col is None else args.cluster_col
    frame, scores, files = _shared.common_rows(args.preds, ["candidate", "control"],
                                               extra_columns=[c for c in (cluster_col,) if c], score_col=args.score_col)
    _shared.show("Files (only transactions that both files score are compared)", files)
    numbers = _shared.file_numbers(args.raw_files)
    if numbers:
        frame = _shared.join_raw_columns(frame, [cluster_col], args.raw_base, numbers)
    ranked = _shared.ranked_rows(frame, args.all_rows, None, args.start, args.end)
    if not ranked.any():
        print("no row falls in the scored month; set TARGET_START and TARGET_END in settings.py, "
              "or pass --start and --end, or pass --all-rows")
        return
    part = frame[ranked].reset_index(drop=True)
    labels = _shared.fraud_flags(part)
    a, b = scores["candidate"][ranked], scores["control"][ranked]
    secs = _shared.row_seconds(part) if settings.TIME_COL in part.columns else None
    clusters = part[cluster_col].to_numpy() if cluster_col in part.columns else None
    if clusters is None and not numbers:
        print(f"note: no cluster column '{cluster_col}' in the score file; the cluster read is skipped")
    dollars = _shared.amounts(part) if args.value else None
    if args.value and dollars is None:
        return
    table = all_intervals(labels, a, b, _shared.account_codes(part), secs, clusters, dollars, args.block_days,
                          args.per_mille, args.draws, args.seed, value=args.value)
    _shared.show("Gain of the candidate over the control, one interval per way of resampling", table)
    wide = widest(table)
    print(f"\nwidest interval: resampling by {wide['resampled']} ({wide['units']} units), "
          f"{wide['low']:+.4f} to {wide['high']:+.4f}")
    if secs is not None:
        summary, _ = daily_wins(labels, a, b, secs, args.per_mille)
        _shared.show("Days on which each model catches more frauds (a = candidate, b = control)", [summary])
    if args.arms:
        se = float(table["se"].max())
        extra = deflated_bar(args.arms, se)
        _shared.show(f"Bar raised for {args.arms} arms read on the same rows (largest standard error above)",
                     [{"arms": args.arms, "se": se, "expected_best_in_se": expected_best_of(args.arms),
                       "chance_gain": extra, "bar": args.bar, "raised_bar": args.bar + extra,
                       "gain": float(table["gain"].iloc[0]), "clears_raised_bar": bool(table["gain"].iloc[0] >= args.bar + extra)}])
    if args.out:
        _shared.save(table, args.out)


if __name__ == "__main__":
    main()
