"""Head-to-head: two or three models compared on the same transactions, counted one way.

What this file does
-------------------
It takes two or three score files, keeps the transaction ids common to all of them, and ranks
the rows of the scored month with each model's own score. It prints four tables:
  1. the files: rows, repeated ids, rows without a score, common rows, labels that differ;
  2. capture at 0.6, 1 and 5 percent of the rows, with the cut rounded down and rounded up:
     frauds caught with ties credited in proportion, the lowest and the highest count a tie
     order could give, the share of frauds caught (UDR), the share of fraud dollars caught
     (VDR) and the number of non-fraud alerts per fraud alert;
  3. for each pair of models: the paired bootstrap that resamples whole accounts (the gain in
     UDR and in VDR with an interval), the frauds that only one of the two catches, and an
     exact binomial test on those two counts;
  4. preset sensitivity reads: the same pairs on approved rows only, without the rows that
     share a second with another row of the account, and on the rows from a given date on.

Why it exists
-------------
The alert budget is a fixed small share of rows, and good models differ by a few frauds at
the cut. Each detail below can move the count by that much, so a comparison is only worth
quoting when all of them are fixed before the files are read.
  - Common ids. A row that one file lacks changes the number of rows, so the number of
    alerts, so which row is the last one alerted. A fraud that only one file holds counts for
    one model only.
  - Floor or ceiling. The budget times the row count is rarely a whole number. Rounding up
    alerts one row more, and that row can be a fraud. Both counts are printed side by side.
  - Ties. A model whose scores are coarse has many rows that share the score at the cut.
    Which of them are alerted is then decided by the sort order, that is, by chance. Crediting
    the frauds among them in proportion to the free places removes the luck; the lowest and
    the highest possible count show how large the luck could have been.
  - Approved rows. A fraud label sits only on approved rows, so declined attempts are never
    labelled. A declined attempt inside a fraud run still looks like fraud and can take an
    alert place that can never count. Whether such rows are ranked changes the row count, the
    cut and the places left for real frauds, and it does so differently for each model.
  - Same-second rows. Two rows of one account in the same second cannot be put in a
    trustworthy order. A model that lets a row see its same-second neighbour knows more on
    exactly these rows than a model that keeps the strict time rule.
  - Rows from a later date on. The evaluation files start one month before the scored month,
    so a row scored early in the month has about one month of history behind it and a row
    scored late has nearly two. Models that lean on history to different degrees can differ
    between the first days and the rest.
  - Accounts, not rows. Frauds come in runs on one account, so the frauds are not independent
    pieces of evidence. The interval therefore comes from resampling whole accounts, and both
    models are read on the same draw.
  - The exact test. Frauds that both models catch, or both miss, say nothing about which is
    better. Only the frauds caught by exactly one of them do, and their split is tested.
A result that keeps its sign on every sensitivity read does not hang on one of these choices.

Where it goes
-------------
Comparison: after scoring, on score files of the same transactions. The scores are what the
linear head of each model gives per row (in the original code `FTTransformerHierModel.forward`);
a score file of any other model works the same way, as long as it carries the transaction id.
The outcome of a row (approved or not) is used only to choose the rows that are ranked.

What to change for the pod
--------------------------
settings.py: ID_COL, ACCOUNT_COL, TIME_COL, LABEL_COL, POSITIVE_LABEL, AMOUNT_COL, SCORE_COL,
TARGET_START, TARGET_END, OUTSORT_ROUNDING and the bootstrap settings; REASON_COL,
APPROVED_REASONS, DECLINE_FLAG_COL and DECLINE_FLAG_VALUES for the approved-row read; EVAL_BASE
when raw columns are joined by id. PER_MILLES and LATE_ROWS_AFTER_DAYS below. The score files
may be stored as probabilities or as log-odds: only the order of the values is used.

How to try it
-------------
    python additions/proof/head_to_head.py --preds model_a.parquet model_b.parquet --names a b
    (add --raw-base and --raw-files to join the response code and to see same-second rows
     that are not in the score files; add --out rows.parquet to write the alert sets)
or, from Python:
    frame, scores, files = _shared.common_rows(paths, names)
    result = compare(frame, scores)
    print(result["capture"]); print(result["pairs"]); print(result["sensitivity"])
The tests are in additions/tests/test_proof_head_to_head.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd

from additions import settings
from additions.common import ranking, tables, timekeys
from additions.common.bootstrap import paired_bootstrap
from additions.proof import _shared

# The alert budgets that are reported, in rows per thousand: 0.6, 1 and 5 percent.
PER_MILLES = (6, 10, 50)

# Both ways of rounding the number of alerted rows are reported side by side.
ROUNDINGS = ("floor", "ceil")

# PLACEHOLDER: the number of days after the start of the scored month from which the "rows from
# a given date on" read starts; by then every row has more than a month of history behind it.
LATE_ROWS_AFTER_DAYS = 7


def _number(value):
    """A float, with NaN for a figure that could not be computed (keeps table columns numeric)."""
    return np.nan if value is None else float(value)


def capture_lines(labels, scores, amounts=None, per_milles=None, roundings=None):
    """Capture of every model at every budget, with the cut rounded down and rounded up.

    labels    1 for fraud, 0 otherwise, shape [rows]
    scores    a dict from model name to its scores on the same rows, shape [rows]
    amounts   dollar amounts, shape [rows], or None (then VDR stays empty)

    Returns a DataFrame with one line per model, budget and rounding: percent, rounding, rows,
    frauds, alerts, tied_rows (rows that share the score at the cut; 1 means no tie), caught
    (ties credited in proportion, so it can be a fraction), caught_min and caught_max (the
    fewest and the most frauds a tie order could give), udr with udr_min and udr_max, vdr, and
    false_per_true (non-fraud alerts per fraud alert).
    """
    per_milles = PER_MILLES if per_milles is None else per_milles
    roundings = ROUNDINGS if roundings is None else roundings
    lines = []
    for name, values in scores.items():
        for per_mille in per_milles:
            for rounding in roundings:
                c = ranking.capture(labels, values, amounts, per_mille, rounding)
                line = {"model": name, "percent": per_mille / 10.0, "rounding": rounding, "rows": c["rows"],
                        "frauds": int(round(c["frauds"])), "alerts": c["alerts"], "tied_rows": c["tied_rows"]}
                for key in ("caught", "caught_min", "caught_max", "udr", "udr_min", "udr_max", "vdr", "false_per_true"):
                    line[key] = _number(c[key])
                lines.append(line)
    return pd.DataFrame(lines)


def alert_chance(scores, per_mille=None, rounding=None):
    """The chance of every row to be alerted when rows that tie at the cut are ordered at random.

    Returns an array [rows]: 1.0 for a row above the score at the cut, 0.0 for a row below it,
    and (free places) / (tied rows) for a row that shares the score at the cut. Without ties
    every value is 0 or 1 and the array equals the alert set.
    """
    s = np.asarray(scores, dtype=np.float64)
    k = ranking.cut_size(len(s), per_mille, rounding)
    chance = np.zeros(len(s))
    if k <= 0:
        return chance
    threshold = np.partition(s, len(s) - k)[len(s) - k]           # the score of the last alerted row
    above, tied = s > threshold, s == threshold
    chance[above] = 1.0
    chance[tied] = (k - int(above.sum())) / int(tied.sum())
    return chance


def discordant(labels, scores_a, scores_b, per_mille=None, rounding=None):
    """The frauds that only one of two models catches, and the exact test on their split.

    Returns a dict:
      both, only_a, only_b, neither     counts of frauds by who catches them, on each model's
                                        definite alert set (ties at the cut settled by row order)
      only_a_expected, only_b_expected  the same two counts with ties credited in proportion
                                        (they equal the definite counts when no fraud is on a tie)
      p_value                           two-sided exact binomial test on only_a against only_b

    When the expected counts differ visibly from the definite ones, many frauds sit on a tie
    and the test hangs on the tie order; the tie-credited gain of the bootstrap is then the
    figure to trust.
    """
    fraud = np.asarray(labels).astype(np.float64) > 0
    in_a = ranking.alert_mask(scores_a, per_mille, rounding)
    in_b = ranking.alert_mask(scores_b, per_mille, rounding)
    chance_a = alert_chance(scores_a, per_mille, rounding)
    chance_b = alert_chance(scores_b, per_mille, rounding)
    only_a = int((fraud & in_a & ~in_b).sum())
    only_b = int((fraud & in_b & ~in_a).sum())
    return {"both": int((fraud & in_a & in_b).sum()), "only_a": only_a, "only_b": only_b,
            "neither": int((fraud & ~in_a & ~in_b).sum()),
            "only_a_expected": float((chance_a * (1.0 - chance_b))[fraud].sum()),
            "only_b_expected": float((chance_b * (1.0 - chance_a))[fraud].sum()),
            "p_value": _shared.exact_test(only_a, only_b)}


def pair_reads(units, labels, scores, amounts=None, per_mille=None, rounding=None, draws=None, seed=None,
               interval=None):
    """Every pair of models: the paired account bootstrap and the test on the discordant frauds.

    units    the account of every row (the unit that is resampled), shape [rows]
    scores   a dict from model name to scores; pairs are formed in the order of the dict, and
             the gain of a pair is the first model's capture minus the second's

    Returns a DataFrame with one line per pair: first, second, udr_first, udr_second, gain, low,
    high, se, share_above_zero (the bootstrap on the share of frauds caught), vdr_gain, vdr_low,
    vdr_high (the same on fraud dollars; empty without amounts), and the columns of `discordant`.
    """
    names = list(scores)
    lines = []
    for i, first in enumerate(names):
        for second in names[i + 1:]:
            boot = paired_bootstrap(units, labels, scores[first], scores[second], None, per_mille, draws, seed,
                                    interval, rounding)
            line = {"first": first, "second": second, "udr_first": _number(boot["a"]), "udr_second": _number(boot["b"])}
            for key in ("gain", "low", "high", "se", "share_above_zero"):
                line[key] = _number(boot[key])
            line.update(vdr_gain=np.nan, vdr_low=np.nan, vdr_high=np.nan)
            if amounts is not None:
                value = paired_bootstrap(units, labels, scores[first], scores[second], amounts, per_mille, draws,
                                         seed, interval, rounding, value=True)
                line.update(vdr_gain=_number(value["gain"]), vdr_low=_number(value["low"]),
                            vdr_high=_number(value["high"]))
            line.update(discordant(labels, scores[first], scores[second], per_mille, rounding))
            lines.append(line)
    return pd.DataFrame(lines)


def sensitivity_masks(frame, approved=None, same_second=None, from_date=None, time_col=None, start=None,
                      late_after_days=None):
    """The preset sensitivity reads as a dict from the name of a read to a yes/no array over the rows.

    frame         the rows that are ranked
    approved      yes/no per row: the approved rows, or None when that is not known
    same_second   yes/no per row: rows that share a second with another row of the account, or None
    from_date     the first day of the late read (default: `late_after_days` days after the start
                  of the scored month)

    The reads are fixed here, before any result is seen: all ranked rows, approved rows only,
    without same-second rows, and rows from the given date on. A read whose input is missing is
    left out (the function that would have supplied it has already printed one line).
    """
    time_col = settings.TIME_COL if time_col is None else time_col
    masks = {"all ranked rows": np.ones(len(frame), dtype=bool)}
    if approved is not None:
        masks["approved rows only"] = np.asarray(approved, dtype=bool)
    if same_second is not None:
        masks["without same-second rows"] = ~np.asarray(same_second, dtype=bool)
    if time_col in frame.columns:
        if from_date is None:
            days = LATE_ROWS_AFTER_DAYS if late_after_days is None else late_after_days
            from_date = pd.Timestamp(settings.TARGET_START if start is None else start) + pd.Timedelta(days=days)
        first_second = int(timekeys.seconds(pd.Series([pd.Timestamp(from_date)]))[0])
        masks[f"rows from {pd.Timestamp(from_date).date()} on"] = _shared.row_seconds(frame, time_col) >= first_second
    return masks


def sensitivity_reads(units, labels, scores, masks, per_mille=None, rounding=None, draws=None, seed=None,
                      interval=None):
    """Every pair of models on every preset population.

    masks   what `sensitivity_masks` returned: a dict from the name of a read to a yes/no array

    Each read ranks only its own rows, so the number of alerts is found again on the smaller
    set. Returns a DataFrame with one line per read and pair: read, rows, frauds, alerts, first,
    second, udr_first, udr_second, gain, low, high, and same_sign: whether the gain has the
    sign it has on the first read (the first read is the reference, so the column is True there).
    """
    labels = np.asarray(labels).astype(np.float64)
    units = np.asarray(units)
    names = list(scores)
    lines, reference = [], {}
    for read, mask in masks.items():
        mask = np.asarray(mask, dtype=bool)
        if not mask.any():
            print(f"note: the read '{read}' holds no row and is skipped")
            continue
        for i, first in enumerate(names):
            for second in names[i + 1:]:
                boot = paired_bootstrap(units[mask], labels[mask], scores[first][mask], scores[second][mask], None,
                                        per_mille, draws, seed, interval, rounding)
                gain = _number(boot["gain"])
                reference.setdefault((first, second), gain)
                lines.append({"read": read, "rows": int(mask.sum()), "frauds": int(labels[mask].sum()),
                              "alerts": ranking.cut_size(int(mask.sum()), per_mille, rounding),
                              "first": first, "second": second, "udr_first": _number(boot["a"]),
                              "udr_second": _number(boot["b"]), "gain": gain, "low": _number(boot["low"]),
                              "high": _number(boot["high"]),
                              "same_sign": bool(np.sign(gain) == np.sign(reference[(first, second)]))})
    return pd.DataFrame(lines)


def same_second_rows(frame, raw=None, id_col=None, account_col=None, time_col=None):
    """Yes/no per row of `frame`: does another row of the account fall in the same second?

    frame   the scored rows
    raw     an optional wider table with id, account and time (all rows of the raw files, for
            example). A neighbour that was never scored is only seen when `raw` is given.

    Returns None, with one printed line, when `frame` has no account or no time column.
    """
    id_col = settings.ID_COL if id_col is None else id_col
    account_col = settings.ACCOUNT_COL if account_col is None else account_col
    time_col = settings.TIME_COL if time_col is None else time_col
    if account_col not in frame.columns or time_col not in frame.columns:
        print("note: no account or no time column; the read without same-second rows is skipped")
        return None
    shared = _shared.shares_second(_shared.account_codes(frame, account_col), _shared.row_seconds(frame, time_col))
    if raw is not None and all(c in raw.columns for c in (id_col, account_col, time_col)):
        wide = _shared.shares_second(_shared.account_codes(raw, account_col), _shared.row_seconds(raw, time_col))
        raw_ids, own_ids = raw[id_col], frame[id_col]
        if pd.api.types.is_numeric_dtype(raw_ids) != pd.api.types.is_numeric_dtype(own_ids):
            # One file stores the id as a number and the other as text: both are compared as text.
            raw_ids, own_ids = raw_ids.astype(str), own_ids.astype(str)
        by_id = pd.Series(wide, index=raw_ids.to_numpy())
        by_id = by_id[~by_id.index.duplicated()]
        shared = shared | by_id.reindex(own_ids.to_numpy()).fillna(False).to_numpy(dtype=bool)
    return shared


def compare(frame, scores, ranked=None, approved=None, same_second=None, from_date=None, per_mille=None,
            rounding=None, draws=None, seed=None, interval=None, account_col=None, label_col=None,
            positive_label=None, amount_col=None, time_col=None, id_col=None, start=None):
    """All tables of the head-to-head for rows that are already lined up.

    frame         the common rows (what `_shared.common_rows` returned)
    scores        a dict from model name to scores on those rows, shape [rows]
    ranked        yes/no per row: the rows that are ranked (default: the scored month)
    approved      yes/no per row, or None to read it from the columns of `frame` when they are there
    same_second   yes/no per row, or None to find it among the rows of `frame`
    from_date     first day of the late-rows read (default: LATE_ROWS_AFTER_DAYS after `start`)
    start         first day of the scored month (default: settings.TARGET_START)

    Returns a dict of DataFrames: "capture" (`capture_lines`), "pairs" (`pair_reads`) and
    "sensitivity" (`sensitivity_reads`), and "rows": id, label, and per model its score and
    whether the row is inside that model's alert set.
    """
    id_col = settings.ID_COL if id_col is None else id_col
    if ranked is None:
        ranked = _shared.ranked_rows(frame, time_col=time_col, start=start)
    ranked = np.asarray(ranked, dtype=bool)
    if approved is None:
        approved = _shared.approved_rows(frame)
    if same_second is None:
        same_second = same_second_rows(frame, account_col=account_col, time_col=time_col)
    part = frame[ranked].reset_index(drop=True)
    part_scores = {name: np.asarray(values, dtype=np.float64)[ranked] for name, values in scores.items()}
    labels = _shared.fraud_flags(part, label_col, positive_label)
    dollars = _shared.amounts(part, amount_col)
    units = _shared.account_codes(part, account_col)
    masks = sensitivity_masks(part, None if approved is None else np.asarray(approved)[ranked],
                              None if same_second is None else np.asarray(same_second)[ranked], from_date, time_col,
                              start)
    rows = pd.DataFrame({"label": labels})
    if id_col in part.columns:
        rows.insert(0, "id", part[id_col].to_numpy())
    for name, mask in _shared.alert_sets(part_scores, per_mille, rounding).items():
        rows[f"score_{name}"] = part_scores[name]
        rows[f"alerted_{name}"] = mask
    return {
        "capture": capture_lines(labels, part_scores, dollars),
        "pairs": pair_reads(units, labels, part_scores, dollars, per_mille, rounding, draws, seed, interval),
        "sensitivity": sensitivity_reads(units, labels, part_scores, masks, per_mille, rounding, draws, seed, interval),
        "rows": rows,
    }


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(
        description="Compare two or three score files on their common transactions, with every counting rule fixed.")
    parser.add_argument("--preds", nargs="+", required=True, help="two or three score files (parquet)")
    parser.add_argument("--names", nargs="+", default=None, help="one short name per file (default: a b c)")
    _shared.add_score_arguments(parser)
    parser.add_argument("--from-date", default=None,
                        help="first day of the late-rows read (default: LATE_ROWS_AFTER_DAYS after the scored month starts)")
    parser.add_argument("--draws", type=int, default=None, help="bootstrap draws (default: settings.BOOTSTRAP_DRAWS)")
    parser.add_argument("--seed", type=int, default=None, help="bootstrap seed (default: settings.BOOTSTRAP_SEED)")
    parser.add_argument("--out", default=None, help="write the per-row scores and alert sets to this parquet file")
    args = parser.parse_args(argv)

    outcome = [settings.REASON_COL, settings.DECLINE_FLAG_COL]
    frame, scores, files = _shared.common_rows(args.preds, args.names, extra_columns=[c for c in outcome if c],
                                               score_col=args.score_col)
    _shared.show("Files (only transactions that every file scores are compared)", files)
    numbers = _shared.file_numbers(args.raw_files)
    raw = None
    if numbers:
        frame = _shared.join_raw_columns(frame, outcome, args.raw_base, numbers)
        # All rows of the raw files, so that a same-second neighbour that was never scored is seen.
        base = settings.EVAL_BASE if args.raw_base is None else args.raw_base
        raw = tables.read_files(base, numbers, [settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL],
                                add_file_number=False)
    ranked = _shared.ranked_rows(frame, args.all_rows, None, args.start, args.end)
    if not ranked.any():
        print("no row falls in the scored month; set TARGET_START and TARGET_END in settings.py, "
              "or pass --start and --end, or pass --all-rows")
        return
    result = compare(frame, scores, ranked, same_second=same_second_rows(frame, raw), from_date=args.from_date,
                     per_mille=args.per_mille, draws=args.draws, seed=args.seed, start=args.start)
    _shared.show("Capture at each budget (ties credited in proportion; lowest and highest count beside it)",
                 result["capture"])
    _shared.show("Pairs: paired account bootstrap, discordant frauds and the exact test (gain = first minus second)",
                 result["pairs"])
    _shared.show("Preset sensitivity reads (each read ranks only its own rows)", result["sensitivity"])
    if args.out:
        _shared.save(result["rows"], args.out)


if __name__ == "__main__":
    main()
