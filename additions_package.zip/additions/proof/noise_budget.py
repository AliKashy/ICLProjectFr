"""Noise budget: what a block of files and a number of seeds can show, before any arm is read.

What this file does
-------------------
It turns two measured numbers into a plan. The first is the paired standard error between
two models on a block of files: the noise from which accounts happen to be in the block. The
second is the run-to-run standard deviation of capture between seeds: the noise from which
fit happened to come out. From the two it computes the standard error of a measured gain for
any number of files and seeds, the smallest gain a single fit can show, how that shrinks with
more files and more seeds, the chance that a true gain of a given size passes a given rule,
and by how much the gains that do pass are overstated. A table printer lays this out as a
ladder over block sizes. The file also holds the binomial arithmetic for the case where only
counts are known: the standard error of one capture rate from the number of frauds, and of a
paired difference from the number of frauds that only one of two models catches.

Why it exists
-------------
The alert budget is a fixed small share of rows, so capture is decided by the few rows around
the cut. Frauds come in runs on one account, so a block holds fewer independent pieces of
evidence than it holds frauds. And two fits that differ only in the seed do not alert the
same rows. A gain that looks clear can therefore sit inside the noise. Working out in advance
what a block can resolve prevents two errors: adopting a change that did nothing, and
dropping a change that works because one read came out low. It also shows when an idea is
too small to be decided on its own and has to be bundled with others or read on a larger
block. A rule that adopts only what clears a bar keeps the lucky reads, so adopted gains come
out too large; the ladder says by how much, so that a sum of adopted gains is not taken at
face value.

Where it goes
-------------
Comparison: before the reads, when blocks and seeds are chosen, and again beside every
decision. The two inputs come from scoring the control at several seeds on one block: the
paired bootstrap of a seed pair (additions/common/bootstrap.py) and the spread of capture
over the seeds (`measure_noise` below does both; additions/reads/seed_average.py prints the
spread as well). Nothing here touches the model.

What to change for the pod
--------------------------
The two noise figures must be measured on the pod's own model and files; no default is given
for them. BLOCK_SIZES, SEEDS and TRUE_GAINS below set the lines and columns of the ladder.
settings.INTERVAL_PERCENT sets the interval behind every rule, and the bootstrap settings are
used by `measure_noise`. Seed noise can change with the amount of training data, so it should
be measured again at the scale at which the arms are trained.

How to try it
-------------
    python additions/proof/noise_budget.py --sd-pair 0.010 --sd-run 0.004 --files-measured 16 --bar 0.01
    python additions/proof/noise_budget.py --frauds 1400 --rate 0.55 --only-a 150 --only-b 120
    (the numbers are examples of the format, not measurements)
or, from Python:
    noise = measure_noise(accounts, labels, [scores_seed_1, scores_seed_2, scores_seed_3])
    print_ladder(ladder(noise["sd_pair"], noise["sd_run"], files_measured=16, bar=0.01))
The tests are in additions/tests/test_proof_noise_budget.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse
import math

import numpy as np
import pandas as pd
from scipy import stats

from additions import settings
from additions.common import ranking
from additions.common.bootstrap import paired_bootstrap
from additions.proof import _shared

# PLACEHOLDER: the block sizes, in numbers of files, for which the ladder is printed; put here
# the sizes of the blocks that can actually be read.
BLOCK_SIZES = (16, 100, 400)

# The numbers of seeds per arm for which the ladder is printed.
SEEDS = (1, 3, 5)

# The true gains (in capture, as a share of all frauds) whose fate under the rule is shown.
TRUE_GAINS = (0.005, 0.01, 0.02, 0.03)

# The chance with which a "detectable" gain passes the rule.
POWER = 0.8


# ----------------------------------------------------------------------------------------------
# binomial arithmetic: when only counts are known
# ----------------------------------------------------------------------------------------------

def capture_se(frauds, rate, design_effect=1.0):
    """Standard error of one capture rate, from the number of frauds alone.

    frauds          number of frauds in the ranked rows
    rate            the capture rate (the share of frauds inside the cut)
    design_effect   how many times larger the variance is than for independent frauds. Frauds
                    of one run are caught or missed together more often than chance, so the
                    true value is above 1; the default 1 gives the smallest the error can be.

    Returns sqrt(rate * (1 - rate) / frauds), times sqrt(design_effect).
    """
    return math.sqrt(rate * (1.0 - rate) / frauds * design_effect)


def paired_se_from_counts(only_a, only_b, frauds, design_effect=1.0):
    """Standard error of the difference in capture between two models, from the discordant frauds.

    only_a   frauds caught by model A and missed by model B
    only_b   frauds caught by model B and missed by model A
    frauds   all frauds in the ranked rows

    The difference in frauds caught is only_a - only_b; frauds that both models catch or both
    miss cancel. Its variance for independent frauds is only_a + only_b - (only_a - only_b)^2 /
    frauds. Returns the square root of that, divided by `frauds`, times sqrt(design_effect).
    Two similar models disagree on few frauds, which is why a paired read is so much sharper
    than the difference of two separate capture rates.
    """
    variance = only_a + only_b - (only_a - only_b) ** 2 / frauds
    return math.sqrt(max(variance, 0.0) * design_effect) / frauds


# ----------------------------------------------------------------------------------------------
# the standard error of a measured gain, and what it lets a block show
# ----------------------------------------------------------------------------------------------

def gain_se(sd_pair, sd_run, files=None, files_measured=None, seeds=1):
    """Standard error of a measured gain (arm minus control) for a block size and a number of seeds.

    sd_pair          paired standard error between two models on the block where it was measured
    sd_run           standard deviation of capture between seeds of one model on one block
    files            size of the block the gain will be read on (None: the measured block)
    files_measured   size of the block on which `sd_pair` was measured
    seeds            fits per arm; the gain is the mean of the arm's seeds minus the mean of the
                     control's seeds

    The variance has two parts:
      block part   sd_pair^2 * files_measured / files. Files hold whole accounts and accounts
                   are independent, so this part falls in proportion to the number of files.
                   More seeds do not remove it: every seed is read on the same accounts.
      seed part    2 * sd_run^2 / seeds. Each arm contributes sd_run^2 / seeds, and there are
                   two arms. More files are not assumed to remove it.
    Part of the seed spread is itself tied to the block and would fall with more files, so the
    formula errs on the careful side.
    """
    block = sd_pair ** 2
    if files is not None and files_measured is not None:
        block *= files_measured / files
    return math.sqrt(block + 2.0 * sd_run ** 2 / seeds)


def interval_multiple(interval=None, seeds_behind_spread=None):
    """How many standard errors a gain must be above zero for its interval to stay above zero.

    interval              width of the two-sided interval in percent (default: settings.INTERVAL_PERCENT)
    seeds_behind_spread   the number of seeds from which the seed spread was estimated, or None

    With a known standard error this is the normal value (1.645 for a 90% interval). A spread
    estimated from a few seeds is itself uncertain; passing their number replaces the normal
    value by the t value with (seeds - 1) degrees of freedom, which is larger for few seeds.
    """
    if seeds_behind_spread is None or seeds_behind_spread < 2:
        return _shared.interval_z(interval)
    interval = settings.INTERVAL_PERCENT if interval is None else interval
    return float(stats.t.ppf(0.5 + interval / 200.0, seeds_behind_spread - 1))


def rule_threshold(se, bar=0.0, se_multiple=None, interval=None):
    """The measured gain a rule asks for: the larger of the bar and a number of standard errors.

    se            standard error of the measured gain
    bar           the smallest gain worth adopting
    se_multiple   standard errors the gain must reach (default: the interval rule, so that the
                  lower end of the interval is above zero)
    """
    multiple = _shared.interval_z(interval) if se_multiple is None else se_multiple
    return max(float(bar), multiple * se)


def single_fit_gain(sd_pair, sd_run, interval=None):
    """The smallest gain one fit per arm can show on the measured block: its interval just clears zero."""
    return rule_threshold(gain_se(sd_pair, sd_run, seeds=1), 0.0, None, interval)


def detectable_gain(se, threshold=None, power=None, interval=None):
    """The true gain that passes the rule with the chance `power` (0.8 by default).

    It is the threshold plus the number of standard errors that leaves the wanted chance above
    it. A true gain equal to the threshold itself passes only half the time.
    """
    power = POWER if power is None else power
    threshold = rule_threshold(se, 0.0, None, interval) if threshold is None else threshold
    return threshold + float(stats.norm.ppf(power)) * se


def pass_chance(true_gain, se, threshold):
    """The chance that the measured gain reaches `threshold` when the true gain is `true_gain`.

    The measured gain is taken as normal around the true gain with standard deviation `se`.
    """
    if se <= 0:
        return 1.0 if true_gain >= threshold else 0.0
    return float(stats.norm.sf((threshold - true_gain) / se))


def overstatement(true_gain, se, threshold):
    """By how much the gains that pass the rule exceed the true gain, on average.

    Only reads at or above the threshold are adopted, so the adopted reads are the lucky ones.
    Returns the mean of a normal measured gain given that it passed, minus the true gain. The
    smaller the true gain is against the threshold, the larger this is; it is why the total of
    several adopted gains should be read once more on a fresh block.
    """
    if se <= 0:
        return 0.0
    alpha = (threshold - true_gain) / se
    # Mean excess of a normal value above a cut: se * density(alpha) / chance(above alpha).
    return float(se * math.exp(stats.norm.logpdf(alpha) - stats.norm.logsf(alpha)))


def seeds_needed(target_gain, sd_pair, sd_run, files=None, files_measured=None, interval=None):
    """The fewest seeds per arm for which a measured gain of `target_gain` clears the interval rule.

    Returns None when no number of seeds is enough: the block part of the noise alone is then
    too large, and only more files help.
    """
    room = (target_gain / _shared.interval_z(interval)) ** 2 - gain_se(sd_pair, 0.0, files, files_measured) ** 2
    if room <= 0:
        return None
    return max(1, math.ceil(2.0 * sd_run ** 2 / room - 1e-12))


def files_needed(target_gain, sd_pair, sd_run, files_measured, seeds=1, interval=None):
    """The smallest block, in files, on which a measured gain of `target_gain` clears the interval rule.

    Returns None when no block is large enough: the seed part of the noise alone is then too
    large, and only more seeds help.
    """
    room = (target_gain / _shared.interval_z(interval)) ** 2 - 2.0 * sd_run ** 2 / seeds
    if room <= 0:
        return None
    return max(1, math.ceil(files_measured * sd_pair ** 2 / room - 1e-12))


# ----------------------------------------------------------------------------------------------
# the ladder
# ----------------------------------------------------------------------------------------------

def ladder(sd_pair, sd_run, files_measured, block_sizes=None, seeds=None, true_gains=None, bar=0.0, interval=None,
           power=None, seeds_behind_spread=None):
    """What each block size and number of seeds can show, as a table.

    sd_pair, sd_run, files_measured   the measured noise figures (see `gain_se`)
    bar                               the smallest gain worth adopting
    seeds_behind_spread               the number of seeds `sd_run` was estimated from; when
                                      given, the interval uses the t value (`interval_multiple`)

    The rule is: adopt when the measured gain is at least `bar` and its interval is above zero.
    Returns a DataFrame with one line per block size and number of seeds:
      files, seeds         the block size and the fits per arm
      se                   standard error of the measured gain (`gain_se`)
      smallest_gain        the smallest measured gain that passes the rule
      detectable_gain      the true gain that passes with the chance `power`
      pass_<g>, over_<g>   for each true gain g: the chance that it passes, and by how much it
                           is overstated on average when it does
    """
    block_sizes = BLOCK_SIZES if block_sizes is None else block_sizes
    seeds = SEEDS if seeds is None else seeds
    true_gains = TRUE_GAINS if true_gains is None else true_gains
    lines = []
    for files in block_sizes:
        for k in seeds:
            se = gain_se(sd_pair, sd_run, files, files_measured, k)
            threshold = rule_threshold(se, bar, interval_multiple(interval, seeds_behind_spread))
            whole = float(files).is_integer()                 # a whole number of files is printed as one
            line = {"files": int(files) if whole else float(files), "seeds": int(k), "se": se, "smallest_gain": threshold,
                    "detectable_gain": detectable_gain(se, threshold, power)}
            for gain in true_gains:
                line[f"pass_{gain:g}"] = pass_chance(gain, se, threshold)
                line[f"over_{gain:g}"] = overstatement(gain, se, threshold)
            lines.append(line)
    return pd.DataFrame(lines)


def print_ladder(table, title="What each block size and number of seeds can show"):
    """Print the ladder as plain text; the columns are explained in `ladder`."""
    _shared.show(title, table)
    print("  se: standard error of a measured gain; smallest_gain: the least a measured gain must be to pass;")
    print("  detectable_gain: the true gain that passes 8 times in 10 (at the default power);")
    print("  pass_g: chance that a true gain g passes; over_g: mean overstatement of g when it passes")


# ----------------------------------------------------------------------------------------------
# measuring the two inputs
# ----------------------------------------------------------------------------------------------

def measure_noise(units, labels, seed_scores, pairs=None, per_mille=None, draws=None, seed=None, interval=None,
                  rounding=None):
    """The two inputs of the budget, measured from several seeds of one model on one block.

    units         the account of every row, shape [rows]
    labels        1 for fraud, 0 otherwise, shape [rows]
    seed_scores   a list of score arrays [rows], one per seed, all on the same rows
    pairs         which seeds are compared by the paired bootstrap, as index pairs (default:
                  each seed with the next one)

    Returns a dict: captures (capture of every seed), sd_run (their standard deviation), sd_pair
    (the mean paired standard error over the compared pairs) and seeds. The paired standard
    error between an arm and its control is measured the same way and is usually somewhat
    larger than between two seeds; it should replace `sd_pair` once it is known.
    """
    seed_scores = [np.asarray(s, dtype=np.float64) for s in seed_scores]
    captures = [ranking.capture(labels, s, None, per_mille, rounding)["udr"] for s in seed_scores]
    pairs = [(i, i + 1) for i in range(len(seed_scores) - 1)] if pairs is None else pairs
    errors = []
    for first, second in pairs:
        boot = paired_bootstrap(units, labels, seed_scores[first], seed_scores[second], None, per_mille, draws,
                                seed, interval, rounding)
        if boot["se"] is not None:
            errors.append(boot["se"])
    return {"captures": [np.nan if c is None else float(c) for c in captures],
            "sd_run": float(np.std(captures, ddof=1)) if len(captures) > 1 and None not in captures else np.nan,
            "sd_pair": float(np.mean(errors)) if errors else np.nan, "seeds": len(seed_scores)}


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(
        description="What a block of files and a number of seeds can show, from two measured noise figures.")
    parser.add_argument("--sd-pair", type=float, default=None, help="paired standard error between two models on the measured block")
    parser.add_argument("--sd-run", type=float, default=None, help="standard deviation of capture between seeds")
    parser.add_argument("--files-measured", type=float, default=None, help="size, in files, of the block on which --sd-pair was measured")
    parser.add_argument("--blocks", type=float, nargs="+", default=None, help="block sizes of the ladder, in files")
    parser.add_argument("--seeds", type=int, nargs="+", default=None, help="numbers of seeds per arm of the ladder")
    parser.add_argument("--gains", type=float, nargs="+", default=None, help="true gains whose fate under the rule is shown")
    parser.add_argument("--bar", type=float, default=0.0, help="the smallest gain worth adopting")
    parser.add_argument("--frauds", type=float, default=None, help="number of frauds, for the binomial standard errors")
    parser.add_argument("--rate", type=float, default=None, help="a capture rate, for its binomial standard error")
    parser.add_argument("--only-a", type=float, default=None, help="frauds only the first model catches")
    parser.add_argument("--only-b", type=float, default=None, help="frauds only the second model catches")
    parser.add_argument("--out", default=None, help="write the ladder to this parquet file")
    args = parser.parse_args(argv)

    printed = False
    if args.frauds and args.rate is not None:
        se = capture_se(args.frauds, args.rate)
        _shared.show("One capture rate, frauds taken as independent (runs on accounts make the true error larger)",
                     [{"frauds": args.frauds, "rate": args.rate, "se": se, "se_in_frauds": se * args.frauds}])
        printed = True
    if args.frauds and args.only_a is not None and args.only_b is not None:
        se = paired_se_from_counts(args.only_a, args.only_b, args.frauds)
        _shared.show("Paired difference from the frauds only one model catches",
                     [{"only_a": args.only_a, "only_b": args.only_b, "gain": (args.only_a - args.only_b) / args.frauds,
                       "se": se, "smallest_gain": rule_threshold(se), "p_value": _shared.exact_test(args.only_a, args.only_b)}])
        printed = True
    if args.sd_pair is not None and args.sd_run is not None:
        if args.files_measured:
            measured, blocks = args.files_measured, args.blocks
        else:
            # Without the size of the measured block nothing can be scaled to other block sizes.
            print("note: no --files-measured; the ladder has one line per number of seeds, for the measured block")
            measured, blocks = 1.0, (1.0,)
        table = ladder(args.sd_pair, args.sd_run, measured, blocks, args.seeds, args.gains, args.bar)
        print(f"\nsmallest gain one fit per arm can show on the measured block: {single_fit_gain(args.sd_pair, args.sd_run):.4f}")
        print_ladder(table)
        if args.out:
            _shared.save(table, args.out)
        printed = True
    if not printed:
        print("nothing to compute: give --sd-pair and --sd-run (with --files-measured), or --frauds with --rate, "
              "or --frauds with --only-a and --only-b")


if __name__ == "__main__":
    main()
