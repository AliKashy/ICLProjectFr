"""Blend ladder: what each model adds to a blend of several scores, read out of fold.

What this file does
-------------------
It takes two to five score files of the same transactions (for example a tree model, another
sequence model and this model) and answers one question per model: at the fixed alert budget,
what does it add to the others?

For every set of the models (each model alone, every pair, and so on up to all of them) it
builds one blended score: a logistic regression on the models' scores, fitted on some accounts
and read on the other accounts, so that every row is scored by a fit that never saw its
account. On those out-of-fold scores it prints four tables:
  1. the ladder: for every set, the share of frauds and of fraud dollars inside the cut, and
     the weight the blend gave each member;
  2. what each model adds: the capture of a set minus the capture of the same set without one
     member, with an interval from the paired account bootstrap. The lines of the full set are
     the leave-one-out value of every model;
  3. every set against a reference set named on the command line (for example the models that
     run today), again with an interval. One more line is a control: the reference with a
     column of random numbers added. It shows what one more weight and the breaking of tied
     scores are worth when the added column knows nothing;
  4. the swap table at the cut for the full set against the reference: the frauds, the fraud
     dollars and the alerted non-frauds that move in and out of the alerted rows.
With --apply-preds it also fits every blend of two or more models once on all the rows read,
applies those frozen weights to a second group of score files, and writes one blended score
file per such set into the --apply-out folder, so that a choice made on one group of rows can
be read once on rows that played no part in it.

Why it exists
-------------
A blend of several scores nearly always catches more than each of its members, so "the blend
scores well" says little about any one member. For an organisation that already runs some
models, the value of one more is the blend with it against the best blend without it, at the
same alert budget. That is the reference line and the leave-one-out line of this file.

Three things make a blend look better than it is, and the file handles each of them:
  - fitting and reading on the same rows. Here the blend is fitted on folds of whole accounts
    and read on the accounts left out. Frauds come in runs on one account, so most frauds
    follow an earlier fraud of that account; a fit that saw one fraud of a run and is read on
    the next would look better than it is;
  - comparing the blend with one member instead of with the best set that lacks the new model;
  - reading a small gain on few frauds. Every gain comes with an interval that resamples whole
    accounts and reads both scores on the same draw.

One thing no arithmetic here can check: every member's scores must come from a model that did
not train on these rows. A model scored on its own training rows looks sharper than it is, the
blend then leans on it, and the lean does not carry over to new rows. Fraud labels also arrive
weeks after the transaction, so the rows read here should be old enough for their labels to
have settled; that holds for every member alike.

The interval treats the blended scores as given. It covers the luck of which accounts are
read, not the small extra noise of fitting a handful of weights; with a few weights and
thousands of frauds that noise is small, and the repeats below average it down further.

Where it goes
-------------
Comparison, after scoring, on score files of whole accounts that share transaction ids. It
stands beside head_to_head.py (which compares the models one against one) and diagnosis.py
(which says where each model wins). The --out file holds the id and one out-of-fold blended
column per set (blend__tree__other, ...); it is not a score file by itself. The files written
into the --apply-out folder are score files (the key columns of the first file of the second
group and the blend, a log-odds value, as the score) and can be given to head_to_head.py,
run_scorecard.py and diagnosis.py like any other. Nothing here changes a model. A
blend that is to be used on new rows is fitted once on all the rows read here; the weights
printed in the ladder show what that fit will look like.

What to change for the pod
--------------------------
settings.py: ID_COL, ACCOUNT_COL, TIME_COL, LABEL_COL, POSITIVE_LABEL, AMOUNT_COL, SCORE_COL,
SCORE_KIND, TARGET_START, TARGET_END, OUTSORT_PER_MILLE, OUTSORT_ROUNDING and the bootstrap
settings. Below: FOLDS, REPEATS, FORM, BLEND_C, MAX_MODELS and CONTROL_NAME. A table without
an amount column gives no dollar figures; one line says so. Frozen weights (--apply-preds)
are best fitted with --form logit: a rank is taken among the rows of one group of files, so
with --form rank the same score can get another input value in the second group.

How to try it
-------------
    python additions/proof/blend_ladder.py --demo
    python additions/proof/blend_ladder.py --preds tree.parquet other.parquet this.parquet \\
        --names tree other this --reference tree other --out blends.parquet
    python additions/proof/blend_ladder.py --preds tree.parquet other.parquet this.parquet \\
        --names tree other this --reference tree other --form logit --kinds logit logit logit \\
        --apply-preds tree_new.parquet other_new.parquet this_new.parquet --apply-out frozen_blends
or, from Python:
    result = blend_ladder(labels, {"tree": s1, "other": s2, "this": s3}, accounts, amounts,
                          reference=("tree", "other"))
    print(result["ladder"]); print(result["adds"]); print(result["against_reference"]); print(result["swaps"])
The tests are in additions/tests/test_proof_blend_ladder.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse
import itertools

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression

from additions import settings
from additions.common import ranking, synthetic
from additions.common.bootstrap import paired_bootstrap
from additions.proof import _shared

# PLACEHOLDER: into how many groups of accounts the rows are dealt. Each group is scored by a
# blend fitted on the other groups. Five keeps four fifths of the frauds in every fit.
FOLDS = 5

# PLACEHOLDER: how many times the dealing is repeated with another shuffle. The out-of-fold
# scores of the repeats are averaged, which removes most of the noise of one particular deal.
REPEATS = 3

# PLACEHOLDER: what the blend reads from each model. "rank": the log-odds of the row's rank share,
# the same scale for every model whatever it stores (a probability, a margin, a raw score).
# "logit": the model's own log-odds, which keeps how far apart two scores are; it needs to
# know what each file stores (see --kinds).
FORM = "rank"

# PLACEHOLDER: the inverse strength of the pull of the blend weights toward zero. A large value
# means almost no pull, which suits a fit of a few weights on many rows.
BLEND_C = 1.0e4

# PLACEHOLDER: the most models read at once. Five models already make 31 sets.
MAX_MODELS = 5

# PLACEHOLDER: the name of the control column of random numbers in the printed tables.
CONTROL_NAME = "(random numbers)"

SEPARATOR = " + "


def _number(value):
    """A float, with a missing figure as NaN, so that table columns stay numeric."""
    return np.nan if value is None else float(value)


def rank_log_odds(values):
    """Log-odds of each row's rank share (ties averaged), float64 [rows]: one scale for any kind of score.

    A missing value ranks last, tied with minus infinity, as `ranking.capture` reads it.
    """
    values = np.asarray(values, dtype=np.float64)
    # Dividing by rows + 1 keeps every share strictly between 0 and 1, so the log-odds stay finite.
    share = ranking.average_ranks(values) / (len(values) + 1.0)
    return np.log(share) - np.log1p(-share)


def blend_columns(scores, form=None, kinds=None):
    """The column each model contributes to the blend.

    scores   a dict from model name to the stored score of every row, shape [rows]
    form     "rank" or "logit" (default: FORM)
    kinds    for form "logit": a dict from model name to "probability" or "logit", saying what
             the stored score is; a model that is not named is read as settings.SCORE_KIND

    Returns a dict from model name to float64 [rows]. Both forms keep the order of the rows of
    every model, so a model alone ranks exactly as its stored score does. With form "logit" an
    infinite log-odds value is moved one step beyond the largest (or below the smallest) finite
    value of its model, and a missing value goes with minus infinity, so that the fit stays
    finite and every row keeps its place in the ranking, ties included.
    """
    form = FORM if form is None else form
    if form not in ("rank", "logit"):
        raise ValueError(f"form must be 'rank' or 'logit', not {form!r}")
    columns = {}
    for name, values in scores.items():
        values = np.asarray(values, dtype=np.float64)
        if form == "rank":
            columns[name] = rank_log_odds(values)
            continue
        kind = (kinds or {}).get(name, settings.SCORE_KIND)
        logit = np.asarray(ranking.to_logit(values, kind), dtype=np.float64)
        finite = np.isfinite(logit)
        if not finite.all():
            # One step beyond the finite values keeps an infinite value strictly at its end of the
            # ranking (moved onto the largest finite value it would tie with that row). A missing
            # value ties with minus infinity, as ranking.capture reads it.
            low = logit[finite].min() if finite.any() else 0.0
            high = logit[finite].max() if finite.any() else 0.0
            logit = np.where(np.isnan(logit), low - 1.0, np.clip(logit, low - 1.0, high + 1.0))
        columns[name] = logit
    return columns


def all_sets(names):
    """Every non-empty set of the models as a tuple of names: singles first, then pairs, up to all of them."""
    names = list(names)
    return [models for size in range(1, len(names) + 1) for models in itertools.combinations(names, size)]


def set_name(models):
    """The printed name of a set: its members joined by ' + ' in the order of the command line."""
    return SEPARATOR.join(models)


def out_of_fold_blend(labels, columns, units, n_folds=None, repeats=None, seed=None, c=None):
    """The blended log-odds of every row, from fits that never saw the row's account.

    labels    1 for fraud, 0 otherwise, shape [rows]
    columns   float array [rows, members]: one column per member of the set (see `blend_columns`)
    units     the account of every row, shape [rows]; whole accounts are kept in one fold
    n_folds   groups of accounts (default: FOLDS); repeats: shuffles averaged (default: REPEATS)
    seed      seed of the first shuffle (default: settings.BOOTSTRAP_SEED); repeat r uses seed + r
    c         inverse strength of the pull toward zero (default: BLEND_C)

    Returns (blend [rows], weights [members], bias): the out-of-fold log-odds averaged over the
    repeats, and the mean weights and bias over all fits. With one member there is nothing to
    fit: the column itself comes back with a weight of one. Returns None, with one printed
    line, when some fit would see only frauds or only non-frauds.

    Each fold is scored by its own fit, so the scores of two folds come from slightly different
    weights. With a few weights fitted on most of the rows the difference is small, and
    averaging over repeats makes it smaller still.
    """
    x = np.asarray(columns, dtype=np.float64)
    x = x[:, None] if x.ndim == 1 else x
    if x.shape[1] == 1:
        return x[:, 0].copy(), np.ones(1), 0.0
    y = np.asarray(labels).astype(np.float64) > 0
    n_folds = FOLDS if n_folds is None else int(n_folds)
    repeats = REPEATS if repeats is None else int(repeats)
    seed = settings.BOOTSTRAP_SEED if seed is None else int(seed)
    c = BLEND_C if c is None else float(c)
    blend = np.zeros(len(y))
    weights, biases = [], []
    for r in range(repeats):
        fold = _shared.account_folds(units, n_folds, seed + r)
        for k in range(n_folds):
            fit, read = fold != k, fold == k
            if y[fit].sum() == 0 or (~y[fit]).sum() == 0:
                print("note: a fold's fit rows hold only one outcome; the blends are skipped "
                      "(use fewer folds or more rows)")
                return None
            model = LogisticRegression(C=c, max_iter=1000).fit(x[fit], y[fit])
            blend[read] += model.decision_function(x[read])
            weights.append(model.coef_[0])
            biases.append(float(model.intercept_[0]))
    return blend / repeats, np.mean(weights, axis=0), float(np.mean(biases))


def _gain_line(units, labels, with_scores, without_scores, amounts, per_mille, rounding, draws, seed, interval):
    """The paired read of two scores: capture of each, the gain and its interval, in frauds and in dollars."""
    boot = paired_bootstrap(units, labels, with_scores, without_scores, None, per_mille, draws, seed, interval,
                            rounding)
    line = {"udr": _number(boot["a"]), "udr_without": _number(boot["b"]), "gain": _number(boot["gain"]),
            "low": _number(boot["low"]), "high": _number(boot["high"]),
            "share_above_zero": _number(boot["share_above_zero"]), "vdr_gain": np.nan, "vdr_low": np.nan,
            "vdr_high": np.nan}
    if amounts is not None:
        value = paired_bootstrap(units, labels, with_scores, without_scores, amounts, per_mille, draws, seed,
                                 interval, rounding, value=True)
        line.update(vdr_gain=_number(value["gain"]), vdr_low=_number(value["low"]), vdr_high=_number(value["high"]))
    return line


def swap_table(labels, scores_first, scores_second, amounts=None, per_mille=None, rounding=None):
    """Who moves in and out of the alerted rows when the first score replaces the second.

    Returns a DataFrame with one line per group of rows: frauds both alert, frauds only the
    first alerts, frauds only the second alerts, frauds neither alerts, and the alerted
    non-frauds only the first or only the second holds. Columns: rows (the count) and dollars
    (the amounts of those rows; empty without amounts). Ties at the cut are settled by row
    order here, as in an alert list; the tie-credited figures are in the other tables.
    """
    fraud = np.asarray(labels).astype(np.float64) > 0
    first = ranking.alert_mask(scores_first, per_mille, rounding)
    second = ranking.alert_mask(scores_second, per_mille, rounding)
    money = None if amounts is None else np.nan_to_num(np.asarray(amounts, dtype=np.float64))
    groups = [("frauds both alert", fraud & first & second),
              ("frauds only the first alerts", fraud & first & ~second),
              ("frauds only the second alerts", fraud & second & ~first),
              ("frauds neither alerts", fraud & ~first & ~second),
              ("non-frauds only the first alerts", ~fraud & first & ~second),
              ("non-frauds only the second alerts", ~fraud & second & ~first)]
    return pd.DataFrame([{"group": name, "rows": int(mask.sum()),
                          "dollars": np.nan if money is None else float(money[mask].sum())} for name, mask in groups])


def blend_ladder(labels, scores, units, amounts=None, reference=None, form=None, kinds=None, n_folds=None,
                 repeats=None, per_mille=None, rounding=None, draws=None, seed=None, interval=None):
    """Every set of the models as an out-of-fold blend, and what each model adds.

    labels      1 for fraud, 0 otherwise, shape [rows]
    scores      a dict from model name to the stored score of every row (two to MAX_MODELS models)
    units       the account of every row, shape [rows]
    amounts     dollar amounts [rows], or None for no dollar figures
    reference   names of the models of the reference set (for example the models that run today);
                None takes the best single model by its share of frauds caught
    form, kinds          see `blend_columns`
    n_folds, repeats     see `out_of_fold_blend`
    per_mille, rounding  the alert budget (default: settings)
    draws, seed, interval   the paired account bootstrap (default: settings)

    Returns a dict, or None when a blend could not be fitted:
      "ladder"             one line per set: set, members, alerts, caught (ties at the cut credited in
                           proportion), caught_min and caught_max (the fewest and the most frauds any
                           order of the tied rows could give), udr, vdr and weight_<model> (empty for a
                           model that is not in the set)
      "adds"               one line per set of two or more and per member: model, added_to (the set
                           without it), udr (with), udr_without, gain, low, high, share_above_zero,
                           vdr_gain, vdr_low, vdr_high
      "against_reference"  one line per set other than the reference, with the same gain columns, and
                           a last line for the control: the reference plus a column of random numbers
      "swaps"              `swap_table` of the full set against the reference
      "blends"             a dict from set name to the out-of-fold blended scores [rows]
      "reference"          the name of the reference set
    """
    names = list(scores)
    if not 2 <= len(names) <= MAX_MODELS:
        raise ValueError(f"the ladder reads 2 to {MAX_MODELS} models, not {len(names)}")
    y = np.asarray(labels).astype(np.float64)
    columns = blend_columns(scores, form, kinds)
    blends, lines = {}, []
    for models in all_sets(names):
        got = out_of_fold_blend(y, np.column_stack([columns[m] for m in models]), units, n_folds, repeats, seed)
        if got is None:
            return None
        blend, weights, _ = got
        blends[set_name(models)] = blend
        read = ranking.capture(y, blend, amounts, per_mille, rounding)
        line = {"set": set_name(models), "members": len(models), "alerts": read["alerts"], "caught": read["caught"],
                "caught_min": read["caught_min"], "caught_max": read["caught_max"],
                "udr": _number(read["udr"]), "vdr": _number(read["vdr"])}
        line.update({f"weight_{m}": np.nan for m in names})
        line.update({f"weight_{m}": float(w) for m, w in zip(models, weights)})
        lines.append(line)
    ladder = pd.DataFrame(lines)

    if reference is None:
        singles = ladder[ladder["members"] == 1]
        reference_name = singles.loc[singles["udr"].idxmax(), "set"]
    else:
        unknown = [m for m in reference if m not in names]
        if unknown:
            raise ValueError(f"the reference names models that were not given: {unknown}")
        reference_name = set_name([m for m in names if m in reference])

    arguments = (amounts, per_mille, rounding, draws, seed, interval)
    adds = []
    for models in all_sets(names):
        for member in models if len(models) > 1 else ():
            without = set_name([m for m in models if m != member])
            line = {"model": member, "added_to": without}
            line.update(_gain_line(units, y, blends[set_name(models)], blends[without], *arguments))
            adds.append(line)
    against = []
    for name, blend in blends.items():
        if name != reference_name:
            line = {"set": name, "reference": reference_name}
            line.update(_gain_line(units, y, blend, blends[reference_name], *arguments))
            against.append(line)
    # The control: the reference with a column that knows nothing. Its gain is what one more weight
    # and the breaking of tied scores are worth by themselves; a real model has to add more than that.
    members = reference_name.split(SEPARATOR)
    draw_seed = (settings.BOOTSTRAP_SEED if seed is None else int(seed)) + 999
    noise = rank_log_odds(np.random.default_rng(draw_seed).random(len(y)))
    control = out_of_fold_blend(y, np.column_stack([columns[m] for m in members] + [noise]), units, n_folds,
                                repeats, seed)
    if control is not None:
        line = {"set": reference_name + SEPARATOR + CONTROL_NAME, "reference": reference_name}
        line.update(_gain_line(units, y, control[0], blends[reference_name], *arguments))
        against.append(line)
    swaps = swap_table(y, blends[set_name(names)], blends[reference_name], amounts, per_mille, rounding)
    return {"ladder": ladder, "adds": pd.DataFrame(adds), "against_reference": pd.DataFrame(against), "swaps": swaps,
            "blends": blends, "reference": reference_name}


def frozen_weights(labels, scores, form=None, kinds=None, c=None):
    """The weights of every set of two or more models, fitted once on all the rows given.

    Returns a DataFrame with one line per set: set, members, bias and weight_<model> (empty
    for a model that is not in the set). These are the weights a blend would be used with on
    new rows. They are fitted on every row, so their capture on these same rows is not an
    out-of-fold figure; the ladder gives that.
    """
    names = list(scores)
    y = np.asarray(labels).astype(np.float64) > 0
    columns = blend_columns(scores, form, kinds)
    lines = []
    for models in all_sets(names):
        if len(models) < 2:
            continue
        x = np.column_stack([columns[m] for m in models])
        model = LogisticRegression(C=BLEND_C if c is None else float(c), max_iter=1000).fit(x, y)
        line = {"set": set_name(models), "members": len(models), "bias": float(model.intercept_[0])}
        line.update({f"weight_{m}": np.nan for m in names})
        line.update({f"weight_{m}": float(w) for m, w in zip(models, model.coef_[0])})
        lines.append(line)
    return pd.DataFrame(lines)


def apply_frozen(scores, weights, form=None, kinds=None):
    """Blend rows with weights that were fitted elsewhere.

    scores    a dict from model name to the stored score of every new row (the same names)
    weights   what `frozen_weights` returned
    form, kinds   as they were when the weights were fitted

    Returns a dict from set name to the blended log-odds of the new rows, shape [rows].
    Nothing is fitted here, so the new rows play no part in the weights they are read with.
    """
    columns = blend_columns(scores, form, kinds)
    out = {}
    for line in weights.to_dict("records"):
        blend = np.full(len(next(iter(columns.values()))), float(line["bias"]))
        for name in scores:
            weight = line.get(f"weight_{name}", np.nan)
            if not np.isnan(weight):
                blend = blend + float(weight) * columns[name]
        out[line["set"]] = blend
    return out


def demo_scores(n_accounts=1500, seed=0):
    """Made-up rows of the scored month with three made-up scores, for the --demo option.

    Returns (frame, scores): the rows, and a dict of three scores that each see part of the
    truth through noise of their own, so that a blend has something to gain. Nothing read on
    them says anything about a real model.
    """
    df = synthetic.make_transactions(n_accounts=n_accounts, seed=seed, fraud_account_share=0.1)
    df = df[_shared.ranked_rows(df)].reset_index(drop=True)
    made = {}
    for k, (name, strength) in enumerate((("tree", 2.0), ("other", 2.0), ("this", 2.3))):
        made[name] = synthetic.make_scores(df, seed=seed + 10 + k, strength=strength,
                                           column="made_up")["made_up"].to_numpy()
    return df, made


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(
        description="What each model adds to an out-of-fold blend of two to five scores on the same rows.")
    parser.add_argument("--preds", nargs="+", default=None, help="two to five score files (parquet) of whole accounts")
    parser.add_argument("--names", nargs="+", default=None, help="one short name per file (default: a b c ...)")
    parser.add_argument("--reference", nargs="+", default=None,
                        help="names of the models of the reference set (default: the best single model)")
    parser.add_argument("--form", choices=("rank", "logit"), default=None,
                        help=f"what the blend reads from each model (default: {FORM})")
    parser.add_argument("--kinds", nargs="+", default=None, choices=("probability", "logit"),
                        help="with --form logit: what each file stores, one value per file")
    parser.add_argument("--folds", type=int, default=None, help=f"groups of accounts (default: {FOLDS})")
    parser.add_argument("--repeats", type=int, default=None, help=f"shuffles averaged (default: {REPEATS})")
    parser.add_argument("--score-col", default=None, help="name of the score column (default: settings.SCORE_COL)")
    parser.add_argument("--start", default=None, help="first day of the scored month (default: settings.TARGET_START)")
    parser.add_argument("--end", default=None, help="first day after the scored month (default: settings.TARGET_END)")
    parser.add_argument("--all-rows", action="store_true",
                        help="rank every row of the files instead of the rows of the scored month")
    parser.add_argument("--per-mille", type=int, default=None,
                        help="alert budget in rows per thousand (default: settings.OUTSORT_PER_MILLE)")
    parser.add_argument("--draws", type=int, default=None, help="bootstrap draws (default: settings.BOOTSTRAP_DRAWS)")
    parser.add_argument("--seed", type=int, default=None, help="seed of the folds and draws")
    parser.add_argument("--demo", action="store_true", help="run on made-up rows and three made-up scores")
    parser.add_argument("--out", default=None,
                        help="write the out-of-fold blended score of every set to this parquet file")
    parser.add_argument("--apply-preds", nargs="+", default=None,
                        help="a second group of score files, one per model in the same order: the blends are "
                             "fitted once on all rows of --preds and applied to these rows without refitting")
    parser.add_argument("--apply-out", default=None,
                        help="folder for the blended score files of the second group (one file per set)")
    args = parser.parse_args(argv)

    # Everything that can be checked from the command line alone is checked before the slow fits.
    if args.preds and not args.demo:
        if not 2 <= len(args.preds) <= MAX_MODELS:
            parser.error(f"--preds needs two to {MAX_MODELS} score files, not {len(args.preds)}")
        if args.names is not None and len(args.names) != len(args.preds):
            parser.error("--names needs exactly one name per file of --preds")
    if args.kinds and (FORM if args.form is None else args.form) != "logit":
        parser.error("--kinds is read only with --form logit")
    if args.apply_preds and (args.demo or not args.preds or len(args.apply_preds) != len(args.preds)):
        parser.error("--apply-preds needs --preds and one file per model, in the same order")

    if args.demo:
        frame, scores = demo_scores()
        ranked = np.ones(len(frame), dtype=bool)
        if args.reference is None:
            args.reference = ["tree", "other"]          # as if these two already ran and "this" were new
    elif args.preds:
        frame, scores, files = _shared.common_rows(args.preds, args.names, score_col=args.score_col)
        _shared.show("Files (only transactions that every file scores are read)", files)
        ranked = _shared.ranked_rows(frame, args.all_rows, None, args.start, args.end)
    else:
        parser.error("give --preds with two to five score files, or --demo")
    if not ranked.any():
        print("no row falls in the scored month; set TARGET_START and TARGET_END in settings.py, "
              "or pass --start and --end, or pass --all-rows")
        return
    if len(scores) != (3 if args.demo else len(args.preds)):
        parser.error("--names must not repeat a name")
    if args.kinds and len(args.kinds) != len(scores):
        parser.error("--kinds needs exactly one value per model")
    if args.reference and [m for m in args.reference if m not in scores]:
        parser.error(f"--reference names models that are not among {list(scores)}")
    frame = frame[ranked].reset_index(drop=True)
    scores = {name: values[ranked] for name, values in scores.items()}
    kinds = dict(zip(scores, args.kinds)) if args.kinds else None
    amounts = _shared.amounts(frame)
    if amounts is None:
        print("note: no amount column; the dollar figures are left empty")
    result = blend_ladder(_shared.fraud_flags(frame), scores, _shared.account_codes(frame), amounts,
                          reference=args.reference, form=args.form, kinds=kinds, n_folds=args.folds,
                          repeats=args.repeats, per_mille=args.per_mille, draws=args.draws, seed=args.seed)
    if result is None:
        return
    _shared.show("Ladder: every set of models as an out-of-fold blend (weights are means over the fits)",
                 result["ladder"])
    _shared.show("What each model adds: a set against the same set without one member", result["adds"])
    _shared.show(f"Every set against the reference ({result['reference']})", result["against_reference"])
    _shared.show(f"Swaps at the cut: all models (first) against the reference (second: {result['reference']})",
                 result["swaps"])
    if args.out:
        table = pd.DataFrame({settings.ID_COL: frame[settings.ID_COL].to_numpy()})
        for name, blend in result["blends"].items():
            table["blend__" + name.replace(SEPARATOR, "__")] = blend
        _shared.save(table, args.out)
    if args.apply_preds:
        if (FORM if args.form is None else args.form) == "rank":
            print("note: with --form rank a score's input value depends on the other rows of its group, so the "
                  "frozen weights read the second group on a slightly different scale; --form logit avoids that")
        weights = frozen_weights(_shared.fraud_flags(frame), scores, args.form, kinds)
        _shared.show("Frozen weights: every blend fitted once on all the rows read above", weights)
        new_frame, new_scores, new_files = _shared.common_rows(args.apply_preds, list(scores),
                                                               score_col=args.score_col)
        _shared.show("Second group of files (only transactions that every file scores are read)", new_files)
        blended = apply_frozen(new_scores, weights, args.form, kinds)
        if args.apply_out:
            score_col = settings.SCORE_COL if args.score_col is None else args.score_col
            for name, blend in blended.items():
                # A score file like any other: the keys of the first file and the blend as the score
                # (a log-odds value; tools that ask what the score is should be told "logit").
                table = new_frame.drop(columns=[score_col], errors="ignore").copy()
                table[score_col] = blend
                path = str(Path(args.apply_out) / ("blend__" + name.replace(SEPARATOR, "__") + ".parquet"))
                _shared.save(table, path)
        else:
            print("note: no --apply-out folder was given; the frozen blends were computed but not written")


if __name__ == "__main__":
    main()
