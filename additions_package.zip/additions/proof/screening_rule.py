"""The order in which ideas are decided: a cheap tree screen first, then one decision for the bundle.

What this file does
-------------------
It holds the rule that decides ideas, as plain functions that return a verdict and the
numbers behind it.

1. The screen. An idea that can be written as columns (or as a rule on the scores) is first
   tried in a tree model that starts from the model's own score: XGBoost with the model's
   log-odds as the starting margin and only the candidate columns as inputs, fitted on one
   set of accounts and read on two other blocks. The tree can only add what the columns hold
   beyond the score. The idea passes when, on both blocks, the screened score catches at
   least SCREEN_GAIN more of the frauds than the score alone and the account-bootstrap
   interval of that gain is above zero. An idea that fails is parked, not thrown away.
2. The bundle. Ideas that passed the screen get a training arm in the sweep, and the sweep's
   own rule (additions/sweep/promote.py) says which arms held. Everything that held is then
   trained together, at several seeds, and decided once, on a block of files that played no
   part in any earlier choice.
3. The decision. The bundle is adopted when its mean gain over the control is at least the
   bar, at least one paired standard error, and the lower end of its interval is above zero.

How this fits with the sweep: additions/SWEEP.md runs cheap tiers first and gives an input
family a training run only when it passed its CPU screen; `residual_screen` and
`screen_verdict` are that screen. promote.py judges each arm on a choose block and a confirm
block and plans the full-scale stage, whose run with every arm that held is the bundle;
`bundle_read` and `decide` are the single decision on that run. The bar and the screen gain
default to promote.MIN_GAIN, so the two files ask for the same size of gain, and leave-one-out
runs for costly arms stay with promote.full_scale_plan. Nothing here keeps a state or refuses
anything.

Why it exists
-------------
The alert budget is a fixed small share of rows, so capture moves with the few rows around
the cut, and two fits that differ only in the seed already disagree by more than most single
ideas gain. A tree screen has no seed noise: it is deterministic, so it can see a small gain
that a single training fit cannot, and it costs no GPU time. It is a gate, not a ranker: a
column that adds nothing on top of the score in a tree rarely adds anything to the network,
but the network may use a column in sequence form that a tree cannot, which is why a fail
parks the idea instead of ending it. Bundling turns many small questions that no block can
resolve into one larger question that a block can. Deciding once per fresh block avoids the
bias of reading the same rows again and again: among many looks the luckiest one wins. Frauds
come in runs on one account, so every interval resamples whole accounts.

Where it goes
-------------
Comparison. The screen runs after scoring, on exported scores of the control and candidate
columns built in features/ (or merchant/, after_model/); fit and read rows must come from
different files, which hold whole accounts. The decision runs after the bundle and the
control are scored at several seeds on the fresh decide block. Architecture, loss and
training ideas cannot be screened and go straight to a training arm.

What to change for the pod
--------------------------
settings.py: OUTSORT_PER_MILLE, SCORE_KIND (whether the base score is a probability or a
log-odds value) and the bootstrap settings; CONSUMER_FIT_FILES, CHOOSE_FILES and
DECIDE_FILES name the usual fit block, read blocks and decide block. SCREEN_GAIN,
SCREEN_BLOCKS, BAR and the tree settings below; the defaults of SCREEN_GAIN and BAR come from
additions/sweep/promote.py.

How to try it
-------------
    python additions/proof/screening_rule.py --screen screen_reads.csv --out verdicts.csv
    python additions/proof/screening_rule.py --gain 0.012 --se 0.004 --arms 6 --seeds-behind-spread 5
    (screen_reads.csv has the columns id, block, gain, low; the numbers are examples)
or, from Python:
    reads = residual_screen(labels, base_scores, frame[["new_col"]], accounts, fit_rows, block_of_row)
    print(screen_verdict(reads))
    bundle = bundle_read(accounts, labels, arm_seeds, control_seeds)
    print(decide(bundle["gain"], bundle["se"]))
The tests are in additions/tests/test_proof_screening_rule.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd
import xgboost as xgb

from additions import settings
from additions.common import ranking
from additions.common.bootstrap import paired_bootstrap
from additions.proof import _shared, block_bootstrap, noise_budget
from additions.sweep import promote

# The smallest gain in capture (a share of all frauds) the screen asks for on every read block.
SCREEN_GAIN = promote.MIN_GAIN

# On how many blocks the screen must pass.
SCREEN_BLOCKS = 2

# The smallest mean gain the bundle must show on the decide block.
BAR = promote.MIN_GAIN

# PLACEHOLDER: settings of the screen's tree model; deeper trees or more rounds suit blocks with
# many more frauds than the made-up data.
TREE_ROUNDS = 100
TREE_DEPTH = 3
TREE_RATE = 0.1

PASS, PARKED, ADOPT, KEEP = "pass", "parked", "adopt", "keep the control"


# ----------------------------------------------------------------------------------------------
# step 1: the tree screen on top of the model's score
# ----------------------------------------------------------------------------------------------

def _inputs(candidates):
    """The candidate columns as numbers for the tree; text codes become integers, missing stays missing."""
    out = {}
    for column in candidates.columns:
        series = candidates[column]
        if pd.api.types.is_bool_dtype(series) or pd.api.types.is_numeric_dtype(series):
            out[column] = series.to_numpy(dtype=np.float64)
        else:
            codes = pd.factorize(series)[0].astype(np.float64)
            codes[codes < 0] = np.nan
            out[column] = codes
    return pd.DataFrame(out)


def residual_screen(labels, base_scores, candidates, units, fit, blocks, kind=None, rounds=None, depth=None,
                    rate=None, per_mille=None, draws=None, seed=None, interval=None, rounding=None):
    """Read what candidate columns add on top of the model's score, on each read block.

    labels        1 for fraud, 0 otherwise, shape [rows]
    base_scores   the model's score, shape [rows] (a probability or a log-odds value, see `kind`)
    candidates    DataFrame [rows, columns] with only the candidate columns; each must already
                  obey the time rule (only strictly earlier seconds of the same key)
    units         the account of every row, shape [rows]: the unit of the bootstrap
    fit           yes/no per row: the rows the tree is fitted on
    blocks        a block number per row, shape [rows]; rows with a negative number are not read

    The tree starts from the model's log-odds (its base margin) and may only correct it with
    the candidate columns, so a column that repeats what the score knows gains nothing. The
    fit is deterministic: a fixed seed, no sampling and one thread. Returns a DataFrame with
    one line per block: block, rows, frauds, base_udr, screened_udr, gain, low, high, se.
    """
    rounds = TREE_ROUNDS if rounds is None else rounds
    depth = TREE_DEPTH if depth is None else depth
    rate = TREE_RATE if rate is None else rate
    y = np.asarray(labels).astype(np.float64)
    margin = ranking.to_logit(base_scores, kind)
    fit = np.asarray(fit, dtype=bool)
    blocks = np.asarray(blocks)
    units = np.asarray(units)
    if (fit & (blocks >= 0)).any():
        print("note: some fit rows are also read; the screen is then flattered on those rows")
    x = _inputs(candidates)
    train = xgb.DMatrix(x[fit], label=y[fit], base_margin=margin[fit])
    params = {"objective": "binary:logistic", "max_depth": int(depth), "eta": float(rate), "tree_method": "hist",
              "seed": 0, "nthread": 1}
    booster = xgb.train(params, train, num_boost_round=int(rounds))
    lines = []
    for block in sorted(set(blocks[blocks >= 0].tolist())):
        read = blocks == block
        # The screened score is the corrected margin; only its order matters for capture.
        screened = booster.predict(xgb.DMatrix(x[read], base_margin=margin[read]), output_margin=True)
        boot = paired_bootstrap(units[read], y[read], screened, margin[read], None, per_mille, draws, seed, interval,
                                rounding)
        line = {"block": block, "rows": int(read.sum()), "frauds": int(y[read].sum()),
                "base_udr": boot["b"], "screened_udr": boot["a"]}
        for key in ("gain", "low", "high", "se"):
            line[key] = np.nan if boot[key] is None else float(boot[key])
        lines.append(line)
    return pd.DataFrame(lines)


def screen_verdict(reads, min_gain=None, blocks_needed=None):
    """The screen's verdict on one idea from its reads on the blocks.

    reads           a DataFrame or a list of dicts with gain and low, one per read block
    min_gain        the gain each block must show (default: SCREEN_GAIN)
    blocks_needed   on how many blocks it must pass (default: SCREEN_BLOCKS)

    A block passes when its gain is at least `min_gain` and the lower end of its interval is
    above zero. Returns a dict: verdict ("pass" or "parked"), reason, blocks_read, blocks_passed
    and the smallest gain over the blocks. A parked idea is not dropped: it waits for more
    rows, another form of the same columns, or a training arm if the network is expected to
    use it in sequence form.
    """
    min_gain = SCREEN_GAIN if min_gain is None else min_gain
    blocks_needed = SCREEN_BLOCKS if blocks_needed is None else blocks_needed
    table = pd.DataFrame(reads)
    gains = table["gain"].astype(float) if len(table) else pd.Series(dtype=float)
    lows = table["low"].astype(float) if len(table) else pd.Series(dtype=float)
    passed = int(((gains >= min_gain) & (lows > 0)).sum())
    out = {"blocks_read": len(table), "blocks_passed": passed,
           "smallest_gain": float(gains.min()) if len(gains) else np.nan}
    if len(table) < blocks_needed:
        out.update(verdict=PARKED, reason=f"read on {len(table)} block(s); {blocks_needed} are needed")
    elif passed < blocks_needed:
        out.update(verdict=PARKED, reason=f"gain of at least {min_gain:g} with the interval above zero on "
                                          f"{passed} of {len(table)} block(s)")
    else:
        out.update(verdict=PASS,
                   reason=f"gain of at least {min_gain:g} with the interval above zero on {passed} blocks")
    return out


# ----------------------------------------------------------------------------------------------
# steps 2 and 3: the bundle at several seeds, decided once on a fresh block
# ----------------------------------------------------------------------------------------------

def bundle_read(units, labels, arm_seed_scores, control_seed_scores, per_mille=None, draws=None, seed=None,
                interval=None, rounding=None):
    """The bundle's gain over the control on the decide block, with its standard error.

    units                 the account of every row, shape [rows]
    labels                1 for fraud, 0 otherwise, shape [rows]
    arm_seed_scores       a list of score arrays [rows], one per seed of the bundle
    control_seed_scores   a list of score arrays [rows], one per seed of the control

    gain is the mean capture of the bundle's seeds minus the mean capture of the control's.
    Its noise has the two parts of additions/proof/noise_budget.py: the block part, measured
    as the mean paired-bootstrap standard error of seed i of the bundle against seed i of the
    control (se_block), and the seed part, from the spread of capture between seeds pooled
    over both arms (sd_run). se combines them with noise_budget.gain_se for this many seeds.
    Returns a dict: gain, se, se_block, sd_run, seeds, arm_captures, control_captures.
    """
    arm = [np.asarray(s, dtype=np.float64) for s in arm_seed_scores]
    control = [np.asarray(s, dtype=np.float64) for s in control_seed_scores]
    capture = lambda s: ranking.capture(labels, s, None, per_mille, rounding)["udr"]
    arm_captures = np.array([capture(s) for s in arm], dtype=np.float64)
    control_captures = np.array([capture(s) for s in control], dtype=np.float64)
    errors = []
    for a, b in zip(arm, control):
        boot = paired_bootstrap(units, labels, a, b, None, per_mille, draws, seed, interval, rounding)
        if boot["se"] is not None:
            errors.append(boot["se"])
    # The spread between seeds, pooled over the two arms: each arm's deviations from its own mean.
    deviations = np.r_[arm_captures - arm_captures.mean(), control_captures - control_captures.mean()]
    dof = len(deviations) - 2
    sd_run = float(np.sqrt((deviations ** 2).sum() / dof)) if dof > 0 else 0.0
    se_block = float(np.mean(errors)) if errors else 0.0
    seeds = min(len(arm), len(control))
    return {"gain": float(arm_captures.mean() - control_captures.mean()),
            "se": noise_budget.gain_se(se_block, sd_run, seeds=max(seeds, 1)), "se_block": se_block, "sd_run": sd_run,
            "seeds": seeds, "arm_captures": arm_captures.tolist(), "control_captures": control_captures.tolist()}


def decide(gain, se, bar=None, n_arms=None, interval=None, seeds_behind_spread=None):
    """The single decision on the bundle: adopt it, or keep the control.

    gain                  mean gain of the bundle over the control on the fresh decide block
    se                    its paired standard error (see `bundle_read`)
    bar                   the smallest gain worth adopting (default: BAR, which is promote.MIN_GAIN)
    n_arms                when several bundles or arms were read on this block, their number; the
                          bar is then raised by block_bootstrap.deflated_bar, what the best of that
                          many arms with no real effect gains by chance
    seeds_behind_spread   the number of seeds the seed spread came from; the interval then uses
                          the t value instead of the normal value (noise_budget.interval_multiple)

    Adopt when all three hold: gain at least the bar, gain at least one standard error, and the
    lower end of the interval (gain minus the interval multiple times se) above zero. Returns a
    dict: verdict, reason, gain, se, bar (as used), low, and the three checks.
    """
    bar = BAR if bar is None else bar
    if n_arms and n_arms > 1:
        bar = bar + block_bootstrap.deflated_bar(n_arms, se)
    low = gain - noise_budget.interval_multiple(interval, seeds_behind_spread) * se
    checks = {"at_least_bar": bool(gain >= bar), "at_least_one_se": bool(gain >= se), "low_above_zero": bool(low > 0)}
    failed = [name for name, ok in checks.items() if not ok]
    verdict = ADOPT if not failed else KEEP
    reason = "all three checks hold" if not failed else "fails: " + ", ".join(failed).replace("_", " ")
    return {"verdict": verdict, "reason": reason, "gain": float(gain), "se": float(se), "bar": float(bar),
            "low": float(low), **checks}


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(
        description="Verdicts of the screening rule: the tree screen and the bundle decision.")
    parser.add_argument("--screen", default=None, help="CSV of screen reads with the columns id, block, gain, low")
    parser.add_argument("--min-gain", type=float, default=None, help="gain the screen asks for (default: SCREEN_GAIN)")
    parser.add_argument("--blocks-needed", type=int, default=None,
                        help="blocks the screen must pass (default: SCREEN_BLOCKS)")
    parser.add_argument("--gain", type=float, default=None, help="the bundle's mean gain on the decide block")
    parser.add_argument("--se", type=float, default=None, help="its paired standard error")
    parser.add_argument("--bar", type=float, default=None, help="the bar (default: BAR)")
    parser.add_argument("--arms", type=int, default=None, help="arms read on the decide block, to raise the bar")
    parser.add_argument("--seeds-behind-spread", type=int, default=None, help="seeds behind the seed spread")
    parser.add_argument("--out", default=None, help="write the screen verdicts to this CSV file")
    args = parser.parse_args(argv)

    printed = False
    if args.screen:
        reads = pd.read_csv(args.screen)
        lines = [{"id": idea, **screen_verdict(group, args.min_gain, args.blocks_needed)}
                 for idea, group in reads.groupby("id", sort=False)]
        verdicts = pd.DataFrame(lines)
        _shared.show("Screen verdicts (a parked idea waits; it is not dropped)", verdicts)
        if args.out:
            verdicts.to_csv(args.out, index=False)
            print(f"wrote {len(verdicts)} row(s) to {args.out}")
        printed = True
    if args.gain is not None and args.se is not None:
        result = decide(args.gain, args.se, args.bar, args.arms, None, args.seeds_behind_spread)
        _shared.show("Decision on the bundle", [result])
        printed = True
    if not printed:
        print("nothing to decide: give --screen with a CSV of screen reads, or --gain with --se")


if __name__ == "__main__":
    main()
