"""Diagnosis: where two or three models win and lose, read on the same rows at each model's own cut.

What this file does
-------------------
Every model gets its own alert cut over the whole set of ranked rows (the top 0.6 percent by
its own score). On those cuts the file builds four tables:
  1. the catch matrix: for every pattern of caught and missed across the models, the number of
     frauds and of alerted non-frauds, and per pair of models the frauds both catch, only one
     catches, neither catches, their overlap (Jaccard) and the exact test on the split;
  2. headroom: each model alone, the union of the alert sets (an upper bound, since the union
     spends more alerts than the budget), the average of the models' ranks, and a logistic
     stack on the models' rank log-odds fitted on half of the accounts and read on the other
     half (two folds, so every row gets a score from a fit that never saw its account);
  3. capture by slice at the global cut: the position of the fraud in its run, the time since
     the account's previous fraud, the amount band, card present or not, the number of earlier
     rows of the account, same-second rows, the network risk-score band and a decline in the
     previous 24 hours. Per slice and model: frauds caught, capture, the model's share of all
     its alerts that falls in the slice, and precision; for one pair the capture gap with an
     account bootstrap interval and a false-discovery q-value over all slice lines;
  4. an honest disagreement tree: among the frauds caught by exactly one of two models, a
     depth-3 tree grown on half of the accounts separates "only A caught" from "only B caught";
     the gap in each leaf is then estimated on the other half of the accounts.

Why it exists
-------------
Two models with the same capture can catch quite different frauds. A row count says which
model is ahead; it does not say where. Frauds come in runs on one account, so most frauds
follow an earlier fraud of that account: a model that is good at follow-up frauds and one
that is good at first frauds can tie on the count and still be worth combining. The union and
the stack say how much a combination could add before anyone builds one. The slices name the
mechanism behind a gap: first frauds or follow-ups, small or large amounts, short or long
history (the evaluation files start one month before the scored month, so a scored row has
between one and two months of history), a declined attempt just before (a fraud label sits
only on approved rows, so the declined attempts of a run are never labelled, yet a model can
read them as history). Each slice reads the global cut, so the alert share shows where each
model spends its fixed budget, which a capture measured inside a slice cannot show. The tree
finds combinations of conditions that a fixed slice list misses. It is grown on one half of
the accounts and judged on the other because a tree fitted and read on the same frauds always
finds leaves that look like gaps.

Where it goes
-------------
Comparison: after scoring, on score files of whole accounts that share transaction ids (read
with `_shared.common_rows`, as in head_to_head.py). The slice columns come from the raw files
by id when the score files do not carry them. The run position and the time since the previous
fraud come from labels in hindsight; they and every leaf are for measurement only. A leaf that
looks useful must be rebuilt as a column that uses only strictly earlier rows before it can
become a model input (in the original code, a new field for `FeatureTokenizer` or a history
feature built in `SequenceBuilder._encode_file`). Diagnosis should run on a set that is not
the one the final claim is read on, or the claim becomes a post-hoc one.

What to change for the pod
--------------------------
settings.py: ID_COL, ACCOUNT_COL, TIME_COL, LABEL_COL, POSITIVE_LABEL, AMOUNT_COL, SCORE_COL,
VISA_SCORE_COL, CARD_PRESENT_COL, REASON_COL, APPROVED_REASONS, DECLINE_FLAG_COL,
DECLINE_FLAG_VALUES, TARGET_START, TARGET_END, OUTSORT_PER_MILLE, OUTSORT_ROUNDING, the
bootstrap settings and EVAL_BASE. Below: AMOUNT_EDGES, RISK_EDGES, CARD_PRESENT_YES and the
other band edges, HEADROOM_PER_MILLES, TREE_DEPTH and TREE_MIN_LEAF. A slice whose column is
None in settings or missing from the table is skipped with one printed line.

How to try it
-------------
    python additions/proof/diagnosis.py --preds model_a.parquet model_b.parquet --names a b \\
        --raw-base /path/to/raw --raw-files 8228-8243
or, from Python:
    result = diagnose(frame, scores)
    print(result["matrix"]); print(result["headroom"]); print(result["slices"]); print(result["tree"])
The tests are in additions/tests/test_proof_diagnosis.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse
import itertools

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier

from additions import settings
from additions.common import ranking
from additions.common.history import EarlierRows
from additions.proof import _shared
from additions.proof.head_to_head import alert_chance, discordant

HOUR, DAY = 3_600, 86_400

# PLACEHOLDER: dollar edges of the amount bands; set them to the currency and spread of the data.
AMOUNT_EDGES = (10.0, 50.0, 200.0, 1_000.0)
# PLACEHOLDER: edges of the network risk-score bands (the score runs from 0 to 99 in the original data).
RISK_EDGES = (10.0, 30.0, 60.0)
# PLACEHOLDER: the values of CARD_PRESENT_COL that mean "the card was present".
CARD_PRESENT_YES = ("Y", "1", "1.0", "True", "true")
# Edges of the earlier-row count, the run position and the hours since the previous fraud.
EARLIER_EDGES = (1, 10, 50, 100)
POSITION_EDGES = (2, 3, 6, 11)
SINCE_FRAUD_EDGES = (1.0, 24.0, 168.0)
# The alert budgets of the headroom table, in rows per thousand (0.6, 1 and 5 percent).
HEADROOM_PER_MILLES = (6, 10, 50)
# The disagreement tree: its depth and the fewest frauds a leaf may hold on the half it is grown on.
TREE_DEPTH = 3
TREE_MIN_LEAF = 40


def _band(values, edges, labels):
    """Text band per row: labels[i] for values between edges[i-1] and edges[i]; "missing" for NaN."""
    v = np.asarray(values, dtype=np.float64)
    out = np.asarray(labels, dtype=object)[np.digitize(np.nan_to_num(v, nan=-np.inf), edges)]
    out[np.isnan(v)] = "missing"
    return out


def slice_inputs(frame, account_col=None, time_col=None, label_col=None, positive_label=None, amount_col=None,
                 risk_col=None, card_present_col=None, run_gap=None):
    """The raw values behind the slices, one line per row of `frame` (history rows included).

    frame   every row of the accounts; history rows before the scored month must be present,
            because the earlier-row count, the declines and the fraud runs look back on them

    Returns a DataFrame [rows] of numbers (NaN where a value is unknown or its column is absent):
      run_position, hours_since_previous_fraud   hindsight, from labels: NaN on non-fraud rows
      amount, risk_score, card_present (1 or 0)  the row's own raw values
      earlier_rows        rows of the account in strictly earlier seconds
      same_second         1 when another row of the account falls in the same second
      decline_24h         1 when a row of the account in the 24 hours strictly before was not approved
      hours_since_previous_row, hour_of_day
    Every look-back uses strictly earlier seconds of the same account, so rows that share a
    second never count for each other.
    """
    risk_col = settings.VISA_SCORE_COL if risk_col is None else risk_col
    card_present_col = settings.CARD_PRESENT_COL if card_present_col is None else card_present_col
    keys = _shared.account_codes(frame, account_col)
    secs = _shared.row_seconds(frame, time_col)
    fraud = _shared.fraud_flags(frame, label_col, positive_label) > 0
    runs = _shared.fraud_runs(keys, secs, fraud, run_gap)
    history = EarlierRows(keys, secs)
    out = pd.DataFrame(index=range(len(frame)))
    out["run_position"] = np.where(fraud & (runs["position"] > 0), runs["position"], np.nan)
    out["hours_since_previous_fraud"] = np.where(fraud, runs["since_previous"] / HOUR, np.nan)
    dollars = _shared.amounts(frame, amount_col)
    out["amount"] = np.nan if dollars is None else dollars
    if risk_col is not None and risk_col in frame.columns:
        out["risk_score"] = pd.to_numeric(frame[risk_col], errors="coerce").to_numpy(dtype=np.float64)
    else:
        print("note: no network risk-score column; the risk-score slice is skipped")
    if card_present_col is not None and card_present_col in frame.columns:
        present = frame[card_present_col]
        out["card_present"] = np.where(present.isna(), np.nan, _shared.has_code(present, CARD_PRESENT_YES))
    else:
        print("note: no card-present column; the card-present slice is skipped")
    out["earlier_rows"] = history.count().astype(np.float64)
    out["same_second"] = _shared.shares_second(keys, secs).astype(np.float64)
    approved = _shared.approved_rows(frame)
    if approved is not None:
        # The outcome of earlier rows is fair history; the row's own outcome is never read here.
        out["decline_24h"] = (history.count(window=DAY, where=~approved) > 0).astype(np.float64)
    out["hours_since_previous_row"] = history.seconds_since_last() / HOUR
    known = secs != np.iinfo(np.int64).min
    out["hour_of_day"] = np.where(known, (secs % DAY) // HOUR, np.nan)
    return out


def slice_bands(inputs):
    """The slice of every row as text, one column per slice, from what `slice_inputs` returned."""
    bands = pd.DataFrame(index=inputs.index)
    no_fraud = inputs["run_position"].isna()
    bands["run position"] = np.where(no_fraud, "no fraud",
                                     _band(inputs["run_position"], POSITION_EDGES, ["1", "2", "3-5", "6-10", "11+"]))
    since = _band(inputs["hours_since_previous_fraud"], SINCE_FRAUD_EDGES, ["under 1h", "1-24h", "1-7d", "over 7d"])
    bands["since previous fraud"] = np.where(no_fraud, "no fraud", np.where(since == "missing", "first fraud", since))
    middle = [f"{a:g}-{b:g}" for a, b in zip(AMOUNT_EDGES, AMOUNT_EDGES[1:])]
    bands["amount band"] = _band(inputs["amount"], AMOUNT_EDGES,
                                 [f"under {AMOUNT_EDGES[0]:g}"] + middle + [f"{AMOUNT_EDGES[-1]:g}+"])
    if "card_present" in inputs:
        bands["card present"] = np.where(inputs["card_present"].isna(), "missing",
                                         np.where(inputs["card_present"] > 0, "yes", "no"))
    bands["earlier rows"] = _band(inputs["earlier_rows"], EARLIER_EDGES, ["0", "1-9", "10-49", "50-99", "100+"])
    bands["same second"] = np.where(inputs["same_second"] > 0, "yes", "no")
    if "risk_score" in inputs:
        bands["risk-score band"] = _band(inputs["risk_score"], RISK_EDGES, ["0-9", "10-29", "30-59", "60+"])
    if "decline_24h" in inputs:
        bands["decline in previous 24h"] = np.where(inputs["decline_24h"] > 0, "yes", "no")
    return bands


def catch_matrix(labels, scores, per_mille=None, rounding=None):
    """Who catches what, on each model's own definite alert set.

    labels   1 for fraud, 0 otherwise, shape [rows]; scores: a dict from name to scores [rows]

    Returns (patterns, pairs). patterns: one line per pattern of caught (1) and missed (0)
    across the models, with the number of frauds and of alerted non-frauds; the line of all
    zeros counts the frauds that every model misses. pairs: per pair the counts of
    head_to_head.discordant and the Jaccard overlap of the two sets of caught frauds.
    """
    fraud = np.asarray(labels).astype(np.float64) > 0
    sets = _shared.alert_sets(scores, per_mille, rounding)
    names = list(scores)
    lines = []
    for pattern in itertools.product((1, 0), repeat=len(names)):
        here = np.ones(len(fraud), dtype=bool)
        for name, bit in zip(names, pattern):
            here &= sets[name] if bit else ~sets[name]
        line = {name: bit for name, bit in zip(names, pattern)}
        line["frauds"] = int((here & fraud).sum())
        # Rows that no model alerts are not alerts, so the all-missed pattern has no alerted non-frauds.
        line["alerted_non_frauds"] = int((here & ~fraud).sum()) if any(pattern) else np.nan
        lines.append(line)
    pairs = []
    for a, b in itertools.combinations(names, 2):
        d = discordant(labels, scores[a], scores[b], per_mille, rounding)
        caught_any = d["both"] + d["only_a"] + d["only_b"]
        pairs.append(dict(first=a, second=b, **d, jaccard=d["both"] / caught_any if caught_any else np.nan))
    return pd.DataFrame(lines), pd.DataFrame(pairs)


def rank_logits(values):
    """Log-odds of each row's rank share (ties averaged), shape [rows]: the same scale for any score kind.

    A missing score ranks last, as `ranking.capture` reads it.
    """
    share = ranking.average_ranks(values) / (len(values) + 1.0)
    return np.log(share) - np.log1p(-share)


def stack_scores(labels, scores, units, seed=None):
    """A logistic stack on the models' rank log-odds, fitted on one half of the accounts and read on the other.

    Returns an array [rows] of out-of-fold stack log-odds, or None with one printed line when a
    half holds no fraud. Folds by account keep the frauds of one run in one half, so no fit sees
    the run it is read on. The two halves are scored by two fits; their scales are close
    because both fit the same three or fewer weights on similar rows.
    """
    y = np.asarray(labels).astype(np.float64) > 0
    x = np.column_stack([rank_logits(v) for v in scores.values()])
    fold = _shared.account_folds(units, 2, seed)
    out = np.zeros(len(y))
    for k in (0, 1):
        fit, read = fold != k, fold == k
        if y[fit].sum() == 0 or (~y[fit]).sum() == 0:
            print("note: one half of the accounts holds no fraud; the stack is skipped")
            return None
        model = LogisticRegression(C=1.0, max_iter=1000).fit(x[fit], y[fit])
        out[read] = model.decision_function(x[read])
    return out


def headroom(labels, scores, units, amounts=None, per_milles=None, rounding=None, seed=None):
    """Capture of each model, of the union of their alert sets, of the rank average and of the stack.

    Returns a DataFrame with one line per budget and reader: percent, reader, alerts, caught
    (ties credited in proportion) and udr. The union line alerts every row that any model
    alerts, so it spends more than the budget: it is an upper bound on what a combination could
    reach, not a model.
    """
    per_milles = HEADROOM_PER_MILLES if per_milles is None else per_milles
    y = np.asarray(labels).astype(np.float64)
    readers = dict(scores)
    readers["rank average"] = np.mean([ranking.average_ranks(v) for v in scores.values()], axis=0)
    stacked = stack_scores(labels, scores, units, seed)
    if stacked is not None:
        readers["stack (two folds by account)"] = stacked
    lines = []
    for per_mille in per_milles:
        for name, values in readers.items():
            c = ranking.capture(y, values, amounts, per_mille, rounding)
            lines.append({"percent": per_mille / 10.0, "reader": name, "alerts": c["alerts"], "caught": c["caught"],
                          "udr": np.nan if c["udr"] is None else c["udr"]})
        union = np.zeros(len(y), dtype=bool)
        for values in scores.values():
            union |= ranking.alert_mask(values, per_mille, rounding)
        lines.append({"percent": per_mille / 10.0, "reader": "union (upper bound)", "alerts": int(union.sum()),
                      "caught": float(y[union].sum()), "udr": float(y[union].sum() / y.sum()) if y.sum() else np.nan})
    return pd.DataFrame(lines)


def _gap_interval(units, gaps, draws, rng, interval):
    """Account bootstrap of a mean gap over frauds: (low, high, se) of the mean of `gaps`.

    units [frauds] and gaps [frauds]. Only the accounts that hold these frauds are resampled,
    with replacement, and the cut stays where it is: the read asks how sure the gap inside the
    slice is, not how the cut would move. Draws are done in blocks to keep memory small.
    """
    codes = pd.factorize(units)[0]
    total = np.bincount(codes, weights=gaps)
    count = np.bincount(codes).astype(np.float64)
    means = []
    for start in range(0, draws, 250):
        pick = rng.integers(0, len(total), size=(min(250, draws - start), len(total)))
        means.append(total[pick].sum(axis=1) / count[pick].sum(axis=1))
    means = np.concatenate(means)
    tail = (100.0 - interval) / 2.0
    return float(np.percentile(means, tail)), float(np.percentile(means, 100.0 - tail)), float(means.std(ddof=1))


def _q_values(p):
    """Benjamini-Hochberg q-values, so that a list of many slices can be read at a fixed false-discovery rate."""
    p = np.asarray(p, dtype=np.float64)
    q = np.full(len(p), np.nan)
    ok = np.flatnonzero(~np.isnan(p))
    if len(ok) == 0:
        return q
    order = ok[np.argsort(p[ok])]
    scaled = p[order] * len(ok) / (np.arange(len(ok)) + 1.0)
    q[order] = np.minimum(1.0, np.minimum.accumulate(scaled[::-1])[::-1])
    return q


def slice_table(bands, labels, scores, units, pair=None, per_mille=None, rounding=None, draws=None, seed=None,
                interval=None):
    """Capture by slice at each model's global cut, with each model's share of its alerts per slice.

    bands    what `slice_bands` returned for the ranked rows, shape [rows, slices]
    pair     the two model names whose capture gap gets an interval (default: the first two)

    Returns a DataFrame with one line per slice value: slice, value, rows, frauds and per model
    caught_<m> (ties credited in proportion), capture_<m>, alert_share_<m> (share of all the
    model's alerts that fall here) and precision_<m>; then gap (capture of the first of the pair
    minus the second), low, high, se, p_value and q_value (over all lines of the table).
    """
    draws = settings.BOOTSTRAP_DRAWS if draws is None else draws
    interval = settings.INTERVAL_PERCENT if interval is None else interval
    rng = np.random.default_rng(settings.BOOTSTRAP_SEED if seed is None else seed)
    names = list(scores)
    pair = tuple(names[:2]) if pair is None else tuple(pair)
    y = np.asarray(labels).astype(np.float64) > 0
    units = np.asarray(units)
    chance = {name: alert_chance(values, per_mille, rounding) for name, values in scores.items()}
    lines = []
    # A loop over slices and values: there are a few dozen of them, and each needs its own bootstrap.
    for column in bands.columns:
        values = bands[column].to_numpy()
        for value in pd.unique(values):
            here = values == value
            frauds = int((here & y).sum())
            line = {"slice": column, "value": value, "rows": int(here.sum()), "frauds": frauds}
            for name in names:
                caught = float(chance[name][here & y].sum())
                alerts = float(chance[name][here].sum())
                line[f"caught_{name}"] = caught
                line[f"capture_{name}"] = caught / frauds if frauds else np.nan
                line[f"alert_share_{name}"] = alerts / chance[name].sum() if chance[name].sum() else np.nan
                line[f"precision_{name}"] = caught / alerts if alerts else np.nan
            line.update(gap=np.nan, low=np.nan, high=np.nan, se=np.nan, p_value=np.nan)
            if len(pair) == 2 and frauds:
                f = here & y
                gaps = chance[pair[0]][f] - chance[pair[1]][f]
                low, high, se = _gap_interval(units[f], gaps, int(draws), rng, interval)
                gap = float(gaps.mean())
                # With no spread over the draws (one account, or every draw alike) a gap cannot be judged.
                p = 1.0 if gap == 0 else (np.nan if se == 0 else float(2.0 * stats.norm.sf(abs(gap) / se)))
                line.update(gap=gap, low=low, high=high, se=se, p_value=p)
            lines.append(line)
    table = pd.DataFrame(lines)
    table["q_value"] = _q_values(table["p_value"]) if len(table) else []
    return table


def _leaf_rules(tree, columns):
    """The path of conditions to every leaf of a fitted tree, as text keyed by leaf id."""
    t = tree.tree_
    rules = {}

    def walk(node, path):
        if t.children_left[node] == t.children_right[node]:
            rules[node] = " and ".join(path) if path else "all"
            return
        name, cut = columns[t.feature[node]], t.threshold[node]
        walk(t.children_left[node], path + [f"{name} <= {cut:.4g}"])
        walk(t.children_right[node], path + [f"{name} > {cut:.4g}"])

    walk(0, [])
    return rules


def disagreement_tree(inputs, only_a, only_b, units, depth=None, min_leaf=None, seed=None):
    """An honest tree on the frauds caught by exactly one of two models.

    inputs   numeric columns per fraud row (what `slice_inputs` returned, for these rows), [frauds, columns]
    only_a   yes/no per fraud row: caught by A and missed by B; only_b the other way round
    units    the account of every fraud row

    The tree is grown on the accounts of one half to tell "only A" from "only B"; every leaf
    is then counted on the accounts of the other half, which the tree never saw. A missing
    value is set to -1 (every input is zero or more), which lets the tree split it off.
    Returns a DataFrame with one line per leaf: rule, grown_only_a, grown_only_b, held_only_a,
    held_only_b, held_share_a, held_gap ((only A - only B) / frauds in the leaf), p_value (exact
    test on the held half) and q_value. None, with one printed line, when either half has too
    few discordant frauds for one split.
    """
    depth = TREE_DEPTH if depth is None else depth
    min_leaf = TREE_MIN_LEAF if min_leaf is None else min_leaf
    keep = np.asarray(only_a, dtype=bool) | np.asarray(only_b, dtype=bool)
    x = inputs[keep].fillna(-1.0)
    target = np.asarray(only_a, dtype=bool)[keep]
    half = _shared.account_folds(np.asarray(units)[keep], 2, seed)
    grow, held = half == 0, half == 1
    if grow.sum() < 2 * min_leaf or held.sum() == 0 or len(np.unique(target[grow])) < 2:
        print("note: too few frauds caught by only one model for a disagreement tree; it is skipped")
        return None
    tree = DecisionTreeClassifier(max_depth=depth, min_samples_leaf=min_leaf, random_state=0)
    tree.fit(x[grow], target[grow])
    leaf = tree.apply(x)
    rules = _leaf_rules(tree, list(x.columns))
    lines = []
    for node in sorted(rules):
        g, h = grow & (leaf == node), held & (leaf == node)
        a, b = int((h & target).sum()), int((h & ~target).sum())
        lines.append({"leaf": node, "rule": rules[node], "grown_only_a": int((g & target).sum()),
                      "grown_only_b": int((g & ~target).sum()), "held_only_a": a, "held_only_b": b,
                      "held_share_a": a / (a + b) if a + b else np.nan,
                      "held_gap": (a - b) / (a + b) if a + b else np.nan,
                      "p_value": _shared.exact_test(a, b) if a + b else np.nan})
    table = pd.DataFrame(lines)
    table["q_value"] = _q_values(table["p_value"])
    return table


def diagnose(frame, scores, ranked=None, pair=None, per_mille=None, rounding=None, draws=None, seed=None,
             interval=None, tree_min_leaf=None, account_col=None, time_col=None, label_col=None, positive_label=None,
             amount_col=None):
    """All four tables for two or three models on rows that are already lined up.

    frame    every row of the accounts (history rows too); scores: a dict from name to scores [rows]
    ranked   yes/no per row: the rows that are ranked (default: the scored month)

    Returns a dict: "patterns" and "pairs" (`catch_matrix`), "headroom", "slices" and "tree"
    (None when skipped), all on the ranked rows only.
    """
    ranked = _shared.ranked_rows(frame, time_col=time_col) if ranked is None else np.asarray(ranked, dtype=bool)
    inputs = slice_inputs(frame, account_col, time_col, label_col, positive_label, amount_col)
    inputs = inputs[ranked].reset_index(drop=True)
    part = frame[ranked].reset_index(drop=True)
    part_scores = {name: np.asarray(values, dtype=np.float64)[ranked] for name, values in scores.items()}
    labels = _shared.fraud_flags(part, label_col, positive_label)
    units = _shared.account_codes(part, account_col)
    patterns, pairs = catch_matrix(labels, part_scores, per_mille, rounding)
    names = list(part_scores)
    pair = tuple(names[:2]) if pair is None else tuple(pair)
    fraud = labels > 0
    sets = _shared.alert_sets(part_scores, per_mille, rounding)
    only_a = (sets[pair[0]] & ~sets[pair[1]])[fraud]
    only_b = (sets[pair[1]] & ~sets[pair[0]])[fraud]
    return {"patterns": patterns, "pairs": pairs,
            "headroom": headroom(labels, part_scores, units, None, None, rounding, seed),
            "slices": slice_table(slice_bands(inputs), labels, part_scores, units, pair, per_mille, rounding, draws,
                                  seed, interval),
            "tree": disagreement_tree(inputs[fraud].reset_index(drop=True), only_a, only_b, units[fraud],
                                      min_leaf=tree_min_leaf, seed=seed)}


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(
        description="Diagnose two or three models on the same rows: catch matrix, headroom, slices and a "
                    "disagreement tree.")
    parser.add_argument("--preds", nargs="+", required=True,
                        help="two or three score files (parquet) of whole accounts")
    parser.add_argument("--names", nargs="+", default=None, help="one short name per file (default: a b c)")
    _shared.add_score_arguments(parser)
    parser.add_argument("--draws", type=int, default=None,
                        help="bootstrap draws per slice (default: settings.BOOTSTRAP_DRAWS)")
    parser.add_argument("--seed", type=int, default=None,
                        help="seed of the folds and draws (default: settings.BOOTSTRAP_SEED)")
    parser.add_argument("--min-leaf", type=int, default=None,
                        help=f"fewest frauds per tree leaf (default: {TREE_MIN_LEAF})")
    parser.add_argument("--out", default=None, help="write the slice table to this parquet file")
    args = parser.parse_args(argv)

    wanted = [settings.VISA_SCORE_COL, settings.CARD_PRESENT_COL, settings.REASON_COL, settings.DECLINE_FLAG_COL]
    wanted = [c for c in wanted if c]
    frame, scores, files = _shared.common_rows(args.preds, args.names, extra_columns=wanted, score_col=args.score_col)
    _shared.show("Files (only transactions that every file scores are read)", files)
    numbers = _shared.file_numbers(args.raw_files)
    if numbers:
        frame = _shared.join_raw_columns(frame, wanted, args.raw_base, numbers)
    ranked = _shared.ranked_rows(frame, args.all_rows, None, args.start, args.end)
    if not ranked.any():
        print("no row falls in the scored month; set TARGET_START and TARGET_END in settings.py, "
              "or pass --start and --end, or pass --all-rows")
        return
    result = diagnose(frame, scores, ranked, per_mille=args.per_mille, draws=args.draws, seed=args.seed,
                      tree_min_leaf=args.min_leaf)
    _shared.show("Catch matrix: frauds and alerted non-frauds per pattern (1 caught, 0 missed)", result["patterns"])
    _shared.show("Pairs: frauds by who catches them, exact test and overlap", result["pairs"])
    _shared.show("Headroom (the union spends more alerts than the budget: an upper bound only)", result["headroom"])
    _shared.show("Capture by slice at each model's global cut (gap: first minus second of the pair)", result["slices"])
    if result["tree"] is not None:
        _shared.show("Disagreement tree: grown on half of the accounts, leaves counted on the other half",
                     result["tree"])
    if args.out:
        _shared.save(result["slices"], args.out)


if __name__ == "__main__":
    main()
