"""Time consistency of candidate columns: does a column rank fraud the same way later, and does it drift?

What this file does
-------------------
It runs two checks on a list of candidate columns.

1. A one-column model per column, fitted on early months and read on late months. The model
   is a table of fraud rates by bin of the column (quantile bins for numbers, one bin per
   frequent code for text, one bin for a missing value). Its ranking is read three times as
   an AUC: on early accounts it was fitted on (in-sample, for reference only), on other early
   accounts (the honest early read) and on the late rows. A column whose early ranking is
   reversed late is flagged "flips"; one whose late AUC falls far below its early AUC is
   flagged "fades". The late AUC carries an interval from a bootstrap of whole accounts.
2. A classifier that tells two sets of rows apart: two periods of the same files, or two
   extracts of the same period. It is a tree model fitted on half of the accounts and read on
   the other half, and the columns that drive it are listed with their share of the trees'
   gain and their own one-column AUC between the two sets. It needs no labels.

Why it exists
-------------
The scored month lies after every training month. A column whose link to fraud changes over
time earns its weight in training and then costs most at the top of the ranking, where a few
rows decide the count of frauds caught. Profile columns that were stored when the file was
extracted carry the future: what the bank did after learning of a fraud (fraud labels arrive
weeks after the transaction) lands in them, so they look strong on old months and stop
working on recent ones. The first check catches both with labels. The second check finds
columns whose values themselves move between periods or between extracts, for example a
column filled more often in one extract than in the other. Such a shift is worth knowing
before a model that uses the column is compared with one that does not. A classifier that
tells two periods apart very well can also reflect changing customers rather than changing
fraud, so the second check only points at columns to inspect (for example by blanking them
at scoring); the label-aware first check is the one that decides.

Where it goes
-------------
Raw files and feature columns, before a column becomes a model input or an export column
(features/ and the tokenizer, FeatureTokenizer in the original code), and again as a
monitoring read. It runs on the CPU and touches no model. Labels are used only to measure a
column; nothing this file produces is a model input. The test of whether a date column was
written after its transaction is in additions/features/asof_audit.py.

What to change for the pod
--------------------------
settings.py: ACCOUNT_COL, TIME_COL, LABEL_COL, POSITIVE_LABEL, TRAIN_BASE, TRAIN_FILES,
EVAL_BASE, CHOOSE_FILES, TRAIN_HISTORY_START, EVAL_HISTORY_START, TARGET_START and the
bootstrap settings. EARLY_PERIOD and LATE_PERIOD below set the two periods; the default late
period is the history month of the evaluation files, so the scored month stays untouched.
N_BINS, MAX_CODES, PRIOR_ROWS, FLIP_MARGIN, FADE_DROP and SHIFT_AUC set the bins and the
flags. The candidate columns are named on the command line or in the call.

How to try it
-------------
    python additions/proof/time_consistency.py --columns colA colB --files 1-10 --late-files 8228-8243
    python additions/proof/time_consistency.py --columns colA colB --shift periods --files 8228-8243
or, from Python:
    table = stability_table(early_rows, late_rows, ["colA", "colB"])
    drivers, summary = period_classifier(rows_a, rows_b, ["colA", "colB"])
The tests are in additions/tests/test_proof_time_consistency.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd
import xgboost as xgb

from additions import settings
from additions.common import tables, timekeys
from additions.proof import _shared

# PLACEHOLDER: the early period (start inclusive, end exclusive) on which each one-column model is
# fitted; put here the months of the training files.
EARLY_PERIOD = (settings.TRAIN_HISTORY_START, settings.EVAL_HISTORY_START)

# PLACEHOLDER: the late period on which the models are read; the default is the month before the
# scored month, so that the scored month plays no part in choosing columns.
LATE_PERIOD = (settings.EVAL_HISTORY_START, settings.TARGET_START)

# Quantile bins per numeric column, and frequent codes kept per text column (the rest share a bin).
N_BINS = 20
MAX_CODES = 50

# A bin's fraud rate is pulled toward the overall rate as if this many rows at the overall rate
# had been added. Fraud is rare, so a bin of a few rows would otherwise get a wild rate.
PRIOR_ROWS = 200.0

# A column "flips" when its honest early AUC is above 0.5 + FLIP_MARGIN and its late AUC is
# below 0.5; it "fades" when the late AUC is lower than the early AUC by more than FADE_DROP.
FLIP_MARGIN = 0.02
FADE_DROP = 0.05

# A column whose own AUC between the two sets of rows is above this is listed as shifted.
SHIFT_AUC = 0.55


# ----------------------------------------------------------------------------------------------
# AUC, with weights so that whole accounts can be resampled
# ----------------------------------------------------------------------------------------------

def auc(labels, scores, weights=None):
    """Area under the ROC curve: the chance that a positive row outranks a negative one.

    labels    1 for positive, 0 otherwise, shape [rows]
    scores    one number per row, shape [rows]; tied scores count one half
    weights   an optional weight per row, shape [rows] (a row drawn twice counts twice)

    Returns a float, or NaN when one of the two classes is empty.
    """
    y = np.asarray(labels).astype(bool)
    s = np.asarray(scores, dtype=np.float64)
    w = np.ones(len(s)) if weights is None else np.asarray(weights, dtype=np.float64)
    # Rows with the same score form one group; within it a positive beats half of the negatives.
    _, group = np.unique(s, return_inverse=True)
    pos = np.bincount(group, weights=w * y)
    neg = np.bincount(group, weights=w * ~y)
    total_pos, total_neg = pos.sum(), neg.sum()
    if total_pos <= 0 or total_neg <= 0:
        return np.nan
    neg_below = np.cumsum(neg) - neg                  # negatives in strictly lower score groups
    return float((pos * (neg_below + 0.5 * neg)).sum() / (total_pos * total_neg))


def auc_interval(labels, scores, units, draws=None, seed=None, interval=None):
    """An interval for the AUC from a bootstrap that draws whole units (accounts) with replacement.

    units   the account of every row, shape [rows]. Frauds come in runs on one account, so an
            interval that treats rows as independent would be far too narrow.

    Returns (low, high); both NaN when no draw had both classes or `draws` is 0.
    """
    draws = settings.BOOTSTRAP_DRAWS if draws is None else draws
    seed = settings.BOOTSTRAP_SEED if seed is None else seed
    interval = settings.INTERVAL_PERCENT if interval is None else interval
    u = timekeys.codes(np.asarray(units))
    n_units = int(u.max()) + 1 if len(u) else 0
    rng = np.random.default_rng(seed)
    values = []
    # One draw is one weighted AUC over all rows, which is vectorised; the loop runs over draws only.
    for _ in range(int(draws)):
        mult = rng.multinomial(n_units, np.full(n_units, 1.0 / n_units)).astype(np.float64)
        value = auc(labels, scores, mult[u])
        if not np.isnan(value):
            values.append(value)
    if not values:
        return np.nan, np.nan
    tail = (100.0 - interval) / 2.0
    return float(np.percentile(values, tail)), float(np.percentile(values, 100.0 - tail))


# ----------------------------------------------------------------------------------------------
# the one-column model: a table of rates by bin
# ----------------------------------------------------------------------------------------------

def column_values(df, column, time_col=None):
    """One column as values a bin table or a tree can use, shape [rows].

    Numbers stay numbers. A date column becomes its age in days at the row's own time (row time
    minus the date), because a date matters by how long ago it was, not by its calendar value.
    Anything else is kept as text. A missing value stays missing.
    """
    time_col = settings.TIME_COL if time_col is None else time_col
    series = df[column]
    if pd.api.types.is_datetime64_any_dtype(series) and time_col in df.columns:
        age = pd.to_datetime(df[time_col]) - pd.to_datetime(series)
        return (age.dt.total_seconds() / 86_400.0).to_numpy(dtype=np.float64)
    if pd.api.types.is_bool_dtype(series) or pd.api.types.is_numeric_dtype(series):
        return series.to_numpy(dtype=np.float64)
    return series.astype(object).where(series.notna(), None).to_numpy()


def fit_bins(values, n_bins=None, max_codes=None):
    """The bins of one column, learned from the rows a model is fitted on.

    Returns a dict: kind ("number" or "code") and either the inner edges of quantile bins or
    the list of frequent codes. Bins come from the fit rows only, so a read on other rows uses
    exactly the cut points the model was built with.
    """
    n_bins = N_BINS if n_bins is None else n_bins
    max_codes = MAX_CODES if max_codes is None else max_codes
    v = np.asarray(values)
    if v.dtype.kind == "f":
        present = v[~np.isnan(v)]
        edges = np.unique(np.quantile(present, np.linspace(0, 1, n_bins + 1)[1:-1])) if len(present) else np.zeros(0)
        return {"kind": "number", "edges": edges}
    text = pd.Series(v).dropna().astype(str)
    return {"kind": "code", "codes": text.value_counts().index[:max_codes].tolist()}


def bin_index(values, bins):
    """The bin of every row, shape [rows]. Bin 0 holds missing values; the last bin holds rare codes."""
    v = np.asarray(values)
    if bins["kind"] == "number":
        x = v.astype(np.float64)
        out = np.searchsorted(bins["edges"], x, side="right") + 1
        out[np.isnan(x)] = 0
        return out.astype(np.int64)
    lookup = {code: i + 1 for i, code in enumerate(bins["codes"])}
    other = len(bins["codes"]) + 1
    series = pd.Series(v)
    out = series.astype(str).map(lookup).fillna(other).to_numpy(dtype=np.int64)
    out[series.isna().to_numpy()] = 0
    return out


def fit_rate_model(values, target, n_bins=None, max_codes=None, prior_rows=None):
    """Fit a one-column model: the rate of `target` in each bin of the column.

    values   the column on the fit rows, shape [rows]
    target   1 or 0 per fit row (fraud, or "belongs to the second set"), shape [rows]

    Each bin's rate is pulled toward the overall rate by `prior_rows` rows at that rate, so a
    small bin cannot claim an extreme rate from a handful of rows. Returns the model as a dict.
    """
    prior_rows = PRIOR_ROWS if prior_rows is None else prior_rows
    bins = fit_bins(values, n_bins, max_codes)
    idx = bin_index(values, bins)
    t = np.asarray(target, dtype=np.float64)
    size = (len(bins["edges"]) + 2) if bins["kind"] == "number" else (len(bins["codes"]) + 2)
    rows = np.bincount(idx, minlength=size).astype(np.float64)
    hits = np.bincount(idx, weights=t, minlength=size)
    overall = float(t.mean()) if len(t) else 0.0
    rate = (hits + prior_rows * overall) / (rows + prior_rows)
    return {"bins": bins, "rate": rate, "overall": overall}


def apply_rate_model(model, values):
    """Score rows with a fitted one-column model: the rate of each row's bin, shape [rows]."""
    return model["rate"][bin_index(values, model["bins"])]


# ----------------------------------------------------------------------------------------------
# check 1: fitted early, read late
# ----------------------------------------------------------------------------------------------

def stability_table(early, late, columns, label_col=None, positive_label=None, account_col=None, time_col=None,
                    draws=None, seed=None, interval=None, flip_margin=None, fade_drop=None):
    """One line per candidate column: how its one-column model ranks fraud early and late.

    early, late   raw rows of the early and the late period (DataFrames with the label, the
                  account and the candidate columns)
    columns       the candidate columns; a name absent from either table is skipped with a line

    Early accounts are split in two by account: the model is fitted on one half and read on the
    other (auc_early), so the early figure is not flattered by the fit. It is then read on the
    late rows (auc_late, with low and high from an account bootstrap; draws=0 skips it). The
    in-sample figure (auc_fit) is shown for reference. Flags: flips (early above 0.5 +
    flip_margin, late below 0.5) and fades (late lower than early by more than fade_drop).
    Returns a DataFrame sorted with flipping and fading columns first.
    """
    label_col = settings.LABEL_COL if label_col is None else label_col
    flip_margin = FLIP_MARGIN if flip_margin is None else flip_margin
    fade_drop = FADE_DROP if fade_drop is None else fade_drop
    y_early = _shared.fraud_flags(early, label_col, positive_label)
    y_late = _shared.fraud_flags(late, label_col, positive_label)
    keys_early = _shared.account_codes(early, account_col)
    keys_late = _shared.account_codes(late, account_col)
    fold = _shared.account_folds(keys_early, 2, seed)              # whole accounts on either side
    lines = []
    for column in columns:
        if column not in early.columns or column not in late.columns:
            print(f"note: column '{column}' is not in both periods; it is skipped")
            continue
        v_early = column_values(early, column, time_col)
        v_late = column_values(late, column, time_col)
        fit = fold == 0
        model = fit_rate_model(v_early[fit], y_early[fit])
        late_scores = apply_rate_model(model, v_late)
        low, high = np.nan, np.nan
        if draws != 0:
            low, high = auc_interval(y_late, late_scores, keys_late, draws, seed, interval)
        line = {"column": column,
                "filled_early": float(pd.notna(early[column]).mean()),
                "filled_late": float(pd.notna(late[column]).mean()),
                "auc_fit": auc(y_early[fit], apply_rate_model(model, v_early[fit])),
                "auc_early": auc(y_early[~fit], apply_rate_model(model, v_early[~fit])),
                "auc_late": auc(y_late, late_scores), "late_low": low, "late_high": high}
        line["flips"] = bool(line["auc_early"] > 0.5 + flip_margin and line["auc_late"] < 0.5)
        line["fades"] = bool(line["auc_early"] - line["auc_late"] > fade_drop)
        lines.append(line)
    table = pd.DataFrame(lines)
    if len(table):
        table = table.sort_values(["flips", "fades", "auc_late"], ascending=[False, False, True]).reset_index(drop=True)
    return table


# ----------------------------------------------------------------------------------------------
# check 2: can two sets of rows be told apart, and by which columns?
# ----------------------------------------------------------------------------------------------

def _tree_inputs(df, columns, time_col=None):
    """The candidate columns as a numeric matrix for the tree model; text codes become integers."""
    out = {}
    for column in columns:
        v = column_values(df, column, time_col)
        if v.dtype.kind != "f":
            codes = pd.factorize(pd.Series(v))[0].astype(np.float64)
            codes[codes < 0] = np.nan                      # a missing code stays missing for the tree
            v = codes
        out[column] = v
    return pd.DataFrame(out)


def period_classifier(rows_a, rows_b, columns, account_col=None, time_col=None, seed=None, rounds=60, max_depth=4,
                      shift_auc=None):
    """How well two sets of rows can be told apart, and which columns do it.

    rows_a, rows_b   two DataFrames: two periods of the same files, or the same period from two
                     extracts. No labels are read.
    columns          the candidate columns; names absent from either table are skipped

    The rows are stacked with a target of 0 for set A and 1 for set B, and the accounts are
    split in two (an account seen in both sets lands on one side as a whole). A tree model is
    fitted on each half and read on the other, which gives an honest AUC. Each column is also
    tested alone with the one-column model, fitted and read the same way.

    Returns (drivers, summary). drivers: one line per column with gain_share (its share of
    the trees' total gain), auc_alone (its own AUC between the sets) and shifted (auc_alone
    above shift_auc), sorted by gain_share. summary: a dict with rows_a, rows_b and auc (the
    AUC of the whole classifier; 0.5 means the sets cannot be told apart).
    """
    shift_auc = SHIFT_AUC if shift_auc is None else shift_auc
    account_col = settings.ACCOUNT_COL if account_col is None else account_col
    time_col = settings.TIME_COL if time_col is None else time_col
    missing = [c for c in columns if c not in rows_a.columns or c not in rows_b.columns]
    if missing:
        print(f"note: column(s) {missing} are not in both sets of rows; they are skipped")
    columns = [c for c in columns if c not in missing]
    # Only the candidates, the account (for the split) and the time (for the age of a date) are kept.
    shared = [c for c in (account_col, time_col) if c in rows_a.columns and c in rows_b.columns]
    keep = list(dict.fromkeys(columns + shared))
    both = pd.concat([rows_a[keep], rows_b[keep]], ignore_index=True)
    target = np.r_[np.zeros(len(rows_a)), np.ones(len(rows_b))]
    fold = _shared.account_folds(_shared.account_codes(both, account_col), 2, seed)
    x = _tree_inputs(both, columns, time_col)
    out_of_fold = np.zeros(len(both))
    gains = pd.Series(0.0, index=columns)
    for side in (0, 1):
        fit, read = fold == side, fold != side
        # A fixed seed, no row or column sampling and one thread make the fit repeatable.
        model = xgb.XGBClassifier(n_estimators=rounds, max_depth=max_depth, learning_rate=0.1, tree_method="hist",
                                  random_state=0, n_jobs=1)
        model.fit(x[fit], target[fit])
        out_of_fold[read] = model.predict_proba(x[read])[:, 1]
        gains = gains.add(pd.Series(model.get_booster().get_score(importance_type="total_gain"), dtype=float),
                          fill_value=0.0)
    lines = []
    for column in columns:
        v = column_values(both, column, time_col)
        scores = np.zeros(len(both))
        for side in (0, 1):
            fit, read = fold == side, fold != side
            scores[read] = apply_rate_model(fit_rate_model(v[fit], target[fit]), v[read])
        alone = auc(target, scores)
        share = float(gains.get(column, 0.0) / gains.sum()) if gains.sum() > 0 else 0.0
        lines.append({"column": column, "gain_share": share,
                      "auc_alone": alone, "shifted": bool(alone > shift_auc)})
    drivers = pd.DataFrame(lines)
    if len(drivers):
        drivers = drivers.sort_values("gain_share", ascending=False).reset_index(drop=True)
    return drivers, {"rows_a": len(rows_a), "rows_b": len(rows_b), "auc": auc(target, out_of_fold)}


def in_period(df, period, time_col=None):
    """The rows of `df` whose time falls in `period` (start inclusive, end exclusive)."""
    time_col = settings.TIME_COL if time_col is None else time_col
    low, high = timekeys.seconds(pd.to_datetime(pd.Series(list(period))))
    secs = timekeys.seconds(df[time_col])
    return df[(secs >= low) & (secs < high)].reset_index(drop=True)


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(
        description="Time consistency of candidate columns: early against late, and drift.")
    parser.add_argument("--columns", nargs="+", required=True, help="the candidate columns")
    parser.add_argument("--base", default=None, help="folder of the early files (default: settings.TRAIN_BASE)")
    parser.add_argument("--files", default=None,
                        help='early file numbers, for example "1-10" (default: settings.TRAIN_FILES)')
    parser.add_argument("--late-base", default=None, help="folder of the late files (default: settings.EVAL_BASE)")
    parser.add_argument("--late-files", default=None, help="late file numbers (default: settings.CHOOSE_FILES)")
    parser.add_argument("--early", nargs=2, default=None, metavar=("START", "END"), help="the early period")
    parser.add_argument("--late", nargs=2, default=None, metavar=("START", "END"), help="the late period")
    parser.add_argument("--shift", choices=("periods", "extracts", "none"), default="periods",
                        help="periods: early rows against late rows; extracts: the early files against the late "
                             "files over the late period; none: skip the classifier")
    parser.add_argument("--draws", type=int, default=200, help="account bootstrap draws for the late AUC (0 skips it)")
    parser.add_argument("--seed", type=int, default=None, help="seed of the account split and the bootstrap")
    parser.add_argument("--out", default=None, help="write the stability table to this parquet file")
    args = parser.parse_args(argv)

    early_period = EARLY_PERIOD if args.early is None else tuple(args.early)
    late_period = LATE_PERIOD if args.late is None else tuple(args.late)
    wanted = [settings.ACCOUNT_COL, settings.TIME_COL, settings.LABEL_COL] + list(args.columns)
    early_numbers = settings.TRAIN_FILES if args.files is None else _shared.file_numbers(args.files)
    late_numbers = settings.CHOOSE_FILES if args.late_files is None else _shared.file_numbers(args.late_files)
    early_raw = tables.read_files(args.base or settings.TRAIN_BASE, early_numbers, wanted)
    late_raw = tables.read_files(args.late_base or settings.EVAL_BASE, late_numbers, wanted)
    early, late = in_period(early_raw, early_period), in_period(late_raw, late_period)
    print(f"early rows {len(early)} ({early_period[0]} to {early_period[1]}), late rows {len(late)} "
          f"({late_period[0]} to {late_period[1]})")
    if len(early) == 0 or len(late) == 0:
        print("one of the two periods holds no rows; set EARLY_PERIOD and LATE_PERIOD, or pass --early and --late")
        return
    table = stability_table(early, late, args.columns, draws=args.draws, seed=args.seed)
    _shared.show("One-column models fitted early and read late (flips and fades first)", table)
    if args.shift != "none":
        if args.shift == "periods":
            rows_a, rows_b, what = early, late, "the early period against the late period"
        else:
            rows_a, rows_b, what = in_period(early_raw, late_period), late, "the early files against the late files"
        if len(rows_a) and len(rows_b):
            drivers, summary = period_classifier(rows_a, rows_b, args.columns, seed=args.seed)
            print(f"\nclassifier telling {what} apart: AUC {summary['auc']:.4f} "
                  f"on {summary['rows_a']} and {summary['rows_b']} rows (0.5 means no difference)")
            _shared.show("Columns that drive it", drivers)
        else:
            print(f"note: no rows for {what}; the classifier is skipped")
    if args.out:
        _shared.save(table, args.out)


if __name__ == "__main__":
    main()
