"""Run-level scorecard: how early a model enters a fraud run, and what lies after its first alert.

What this file does
-------------------
It groups the frauds of each account into runs (a run is a stretch of the account's frauds in
which the gap between one fraud and the next is at most G, 7 days by default) and reads a
model at its alert cut run by run. For every run it finds the first caught fraud. From that
it reports:
  - runs caught at all, and capture of the first fraud of a run;
  - runs caught within their first N frauds, for N in 1, 2, 3, 5 and 10;
  - frauds at or after the first catch of their run, over all frauds ("prevented" frauds);
  - fraud dollars at or after the first catch, with a response lag of 0, 1 hour and 24 hours;
  - alerted accounts per account in which a fraud was caught;
  - a type per run (single; burst: two or more frauds within 24 hours; series: three or more
    frauds at one merchant over more than 7 days; other), and the same figures by type.

Why it exists
-------------
The row measure counts every fraud alike. Frauds come in runs on one account, so most frauds
follow an earlier fraud of that account, and a model can earn most of its capture by staying
on runs it has already found. The row measure cannot tell a model that enters a run at its
second fraud from one that joins at the tenth. What an alert is worth to the bank is what
happens after it: the card is blocked and the rest of the run does not take place. The
scorecard measures exactly that: how early a run is entered, and how many frauds and dollars
lie after the first alert once a response lag is allowed for. The run types say which
mechanism holds the frauds that are still missed. Bursts point at takeover-like signals inside
the account; series at one merchant point at merchant-side signals.

Three cautions belong with the figures. The "prevented" counts assume that an alert stops the
run; the replay cannot know what would have happened after a block. Fraud labels arrive weeks
after the transaction and may mark a whole series after one claim, which makes long series
look harder to stop in real time than they are. And the gap G changes every figure, so it
should be fixed before the scores are read.

Where it goes
-------------
Comparison: after scoring, as a second table beside the row measure. It needs scores for
every row of the accounts in the ranked month: on a sample of rows the first caught fraud of
a run cannot be known. Runs, positions and run types come from labels in hindsight, so they
are for measurement only and must never become model inputs.

What to change for the pod
--------------------------
settings.py: ID_COL, ACCOUNT_COL, TIME_COL, LABEL_COL, POSITIVE_LABEL, AMOUNT_COL, SCORE_COL,
MERCHANT_COL (None switches the series type off), TARGET_START, TARGET_END, OUTSORT_PER_MILLE
and EVAL_BASE when the merchant is joined from raw files. WITHIN, LAGS, BURST_SPAN,
SERIES_FRAUDS and SERIES_SPAN below; the run gap is `_shared.RUN_GAP` or --gap-days.

How to try it
-------------
    python additions/proof/run_scorecard.py --preds model_a.parquet model_b.parquet --names a b
    (add --raw-base and --raw-files when the merchant column is not in the score files)
or, from Python:
    result = score_one(df, df[settings.SCORE_COL].to_numpy())
    print(result["card"]); print(result["types"])
The tests are in additions/tests/test_proof_run_scorecard.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd

from additions import settings
from additions.common import ranking, timekeys
from additions.proof import _shared

# "Caught within the first N frauds of the run" is reported for these N.
WITHIN = (1, 2, 3, 5, 10)

# Response lags in seconds, with their names: the time between the first alert and the moment
# the run is stopped. With no lag the alerted transaction itself is stopped.
LAGS = ((0, "no lag"), (3_600, "lag 1 hour"), (86_400, "lag 24 hours"))

# A burst is a run of two or more frauds that all fall within this many seconds.
BURST_SPAN = 86_400

# A series is a run with at least SERIES_FRAUDS frauds at one merchant spread over more than
# SERIES_SPAN seconds.
SERIES_FRAUDS = 3
SERIES_SPAN = 7 * 86_400

RUN_TYPES = ("single", "burst", "series", "other")


def fraud_lines(df, alerted, ranked=None, run_gap=None, account_col=None, time_col=None, label_col=None,
                positive_label=None, amount_col=None, merchant_col=None):
    """One line per fraud: its run, its place in the run and whether the model caught it.

    df        every row of the accounts (history rows included, so that a run that began before
              the ranked month is seen whole)
    alerted   yes/no per row: the rows inside the model's alert cut
    ranked    yes/no per row: the rows that are ranked (default: the scored month)

    Returns a DataFrame with the columns account (code), second, run, position (1 for the first
    fraud of a run; frauds of one second share a position), amount, merchant (a code, -1 when
    unknown; only when the merchant column is available), ranked and caught (alerted and
    ranked). Frauds without a time are left out.
    """
    merchant_col = settings.MERCHANT_COL if merchant_col is None else merchant_col
    amount_col = settings.AMOUNT_COL if amount_col is None else amount_col
    ranked = _shared.ranked_rows(df, time_col=time_col) if ranked is None else np.asarray(ranked, dtype=bool)
    keys = _shared.account_codes(df, account_col)
    secs = _shared.row_seconds(df, time_col)
    fraud = _shared.fraud_flags(df, label_col, positive_label) > 0
    runs = _shared.fraud_runs(keys, secs, fraud, run_gap)
    f = np.flatnonzero(runs["run"] >= 0)
    # Without an amount column the dollar lines stay empty; `_shared.amounts` prints one line saying so.
    dollars = _shared.amounts(df, amount_col)
    out = pd.DataFrame({
        "account": keys[f], "second": secs[f], "run": runs["run"][f], "position": runs["position"][f],
        "amount": np.nan if dollars is None else dollars[f],
        "ranked": ranked[f], "caught": np.asarray(alerted, dtype=bool)[f] & ranked[f],
    })
    if merchant_col is not None and merchant_col in df.columns:
        merchant = df[merchant_col]
        codes = timekeys.codes(merchant)
        codes[merchant.isna().to_numpy()] = -1                   # an unknown merchant matches no other
        out["merchant"] = codes[f]
    else:
        print("note: no merchant column; the run type 'series' is skipped and such runs count as 'other'")
    return out


def run_lines(frauds, burst_span=None, series_frauds=None, series_span=None):
    """One line per run: its size, where it starts, its first caught fraud and its type.

    frauds   what `fraud_lines` returned

    Returns a DataFrame with the columns run, account, frauds, ranked_frauds, first_second,
    last_second, starts_ranked (the first fraud of the run is a ranked row), caught_frauds,
    first_catch_position and first_catch_second (NaN when no fraud of the run was caught) and
    run_type. The frauds are a small share of all rows, so a group-by over them is cheap.
    """
    burst_span = BURST_SPAN if burst_span is None else burst_span
    series_frauds = SERIES_FRAUDS if series_frauds is None else series_frauds
    series_span = SERIES_SPAN if series_span is None else series_span
    grouped = frauds.groupby("run")
    runs = grouped.agg(account=("account", "first"), frauds=("second", "size"), ranked_frauds=("ranked", "sum"),
                       first_second=("second", "min"), last_second=("second", "max"),
                       caught_frauds=("caught", "sum")).reset_index()
    # The first fraud of a run has position 1 (several frauds when they share its second).
    first = frauds[frauds["position"] == 1].groupby("run")["ranked"].max()
    runs["starts_ranked"] = first.reindex(runs["run"]).to_numpy(dtype=bool)
    caught = frauds[frauds["caught"]].groupby("run").agg(position=("position", "min"), second=("second", "min"))
    runs["first_catch_position"] = runs["run"].map(caught["position"])
    runs["first_catch_second"] = runs["run"].map(caught["second"])
    single = runs["frauds"] == 1
    burst = ~single & (runs["last_second"] - runs["first_second"] <= burst_span)
    series = np.zeros(len(runs), dtype=bool)
    if "merchant" in frauds.columns:
        known = frauds[frauds["merchant"] >= 0]
        at_one = known.groupby(["run", "merchant"])["second"].agg(["size", "min", "max"])
        long_enough = (at_one["size"] >= series_frauds) & (at_one["max"] - at_one["min"] > series_span)
        series = runs["run"].isin(at_one.index.get_level_values("run")[long_enough]).to_numpy()
    # The first type that fits wins; a burst lasts a day at most, so it can never be a series too.
    runs["run_type"] = np.select([single, burst, series & ~single & ~burst], RUN_TYPES[:3], default=RUN_TYPES[3])
    return runs


def _share(part, whole):
    """A share, or NaN when the whole is empty."""
    return float(part) / float(whole) if whole else np.nan


def _prevented(frauds, runs, lag):
    """Yes/no per fraud line: is the fraud ranked and at or after its run's first catch plus the lag?"""
    first_catch = frauds["run"].map(runs.set_index("run")["first_catch_second"]).to_numpy(dtype=np.float64)
    # A run without a catch has NaN here, and a comparison with NaN is False: nothing is prevented.
    return frauds["ranked"].to_numpy() & (frauds["second"].to_numpy() >= first_catch + lag)


def scorecard(frauds, runs, alerted_accounts=None, within=None, lags=None):
    """The run-level measures of one model, as a table of (measure, value).

    frauds             what `fraud_lines` returned
    runs               what `run_lines` returned
    alerted_accounts   number of accounts with at least one alerted row (None leaves the workload empty)

    Run measures are shares of the runs whose first fraud is a ranked row: a run that began
    before the ranked month cannot have its first frauds alerted, so it is counted on a line
    of its own. Fraud and dollar measures are shares of all ranked frauds and of their dollars,
    whatever run they belong to, so they stand beside the row measure on the same base.
    """
    within = WITHIN if within is None else within
    lags = LAGS if lags is None else lags
    ranked = frauds[frauds["ranked"]]
    own = runs[runs["starts_ranked"]]
    position = own["first_catch_position"]
    lines = [
        ("ranked frauds", len(ranked)),
        ("frauds inside the cut", int(ranked["caught"].sum())),
        ("row capture", _share(ranked["caught"].sum(), len(ranked))),
        ("runs that start in the ranked rows", len(own)),
        ("runs that began earlier", int(((runs["ranked_frauds"] > 0) & ~runs["starts_ranked"]).sum())),
        ("runs caught at all", _share(position.notna().sum(), len(own))),
        ("first fraud of the run caught", _share((position == 1).sum(), len(own))),
    ]
    for n in within:
        if n > 1:
            lines.append((f"runs caught within their first {n} frauds", _share((position <= n).sum(), len(own))))
    dollars = ranked["amount"].sum(min_count=1)
    for lag, name in lags:
        saved = frauds[_prevented(frauds, runs, lag)]
        lines.append((f"frauds at or after the first catch, {name}", _share(len(saved), len(ranked))))
        lines.append((f"fraud dollars at or after the first catch, {name}",
                      np.nan if np.isnan(dollars) else _share(saved["amount"].sum(), dollars)))
    fraud_accounts = int(ranked.loc[ranked["caught"], "account"].nunique())
    lines.append(("alerted accounts", np.nan if alerted_accounts is None else int(alerted_accounts)))
    lines.append(("accounts with a caught fraud", fraud_accounts))
    lines.append(("alerted accounts per account with a caught fraud",
                  np.nan if alerted_accounts is None else _share(alerted_accounts, fraud_accounts)))
    return pd.DataFrame(lines, columns=["measure", "value"])


def run_type_table(frauds, runs):
    """The frauds and the runs by run type, with what the model catches in each.

    Returns a DataFrame with one line per run type and a line "all": runs (those that start in
    the ranked rows), frauds (ranked frauds in runs of the type), share_of_frauds, caught,
    capture, share_of_missed (the type's share of all ranked frauds that were not caught),
    runs_caught and first_caught (shares of the type's runs). The share of missed frauds says
    where the remaining frauds sit.
    """
    kind = frauds["run"].map(runs.set_index("run")["run_type"])
    ranked = frauds["ranked"].to_numpy()
    caught = frauds["caught"].to_numpy()
    missed_all = int((ranked & ~caught).sum())
    lines = []
    for name in RUN_TYPES + ("all",):
        here = ranked if name == "all" else ranked & (kind == name).to_numpy()
        own = runs[runs["starts_ranked"] & ((runs["run_type"] == name) | (name == "all"))]
        lines.append({"run_type": name, "runs": len(own), "frauds": int(here.sum()),
                      "share_of_frauds": _share(here.sum(), ranked.sum()), "caught": int((here & caught).sum()),
                      "capture": _share((here & caught).sum(), here.sum()),
                      "share_of_missed": _share((here & ~caught).sum(), missed_all),
                      "runs_caught": _share(own["first_catch_position"].notna().sum(), len(own)),
                      "first_caught": _share((own["first_catch_position"] == 1).sum(), len(own))})
    return pd.DataFrame(lines)


def score_one(df, scores, ranked=None, per_mille=None, rounding=None, run_gap=None, account_col=None,
              time_col=None, label_col=None, positive_label=None, amount_col=None, merchant_col=None):
    """The whole scorecard of one model.

    df       every row of the accounts, with account, time, label and (optionally) amount and merchant
    scores   the model's score per row of `df`, shape [rows]
    ranked   yes/no per row: the rows that are ranked (default: the scored month)

    The alert cut is taken over the ranked rows only; ties at the cut are settled by row order.
    Returns a dict: "card" (`scorecard`), "types" (`run_type_table`), "frauds" (`fraud_lines`)
    and "runs" (`run_lines`).
    """
    ranked = _shared.ranked_rows(df, time_col=time_col) if ranked is None else np.asarray(ranked, dtype=bool)
    alerted = np.zeros(len(df), dtype=bool)
    alerted[ranked] = ranking.alert_mask(np.asarray(scores, dtype=np.float64)[ranked], per_mille, rounding)
    frauds = fraud_lines(df, alerted, ranked, run_gap, account_col, time_col, label_col, positive_label, amount_col,
                         merchant_col)
    runs = run_lines(frauds)
    alerted_accounts = len(np.unique(_shared.account_codes(df, account_col)[alerted]))
    return {"card": scorecard(frauds, runs, alerted_accounts), "types": run_type_table(frauds, runs),
            "frauds": frauds, "runs": runs}


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(
        description="Run-level scorecard: how early each model enters a fraud run and what lies after its first alert.")
    parser.add_argument("--preds", nargs="+", required=True, help="one or more score files (parquet) of whole accounts")
    parser.add_argument("--names", nargs="+", default=None, help="one short name per file (default: a b c)")
    _shared.add_score_arguments(parser)
    parser.add_argument("--gap-days", type=float, default=_shared.RUN_GAP / 86_400.0,
                        help="largest gap in days between two frauds of one run (default: 7)")
    parser.add_argument("--out", default=None, help="write the per-run table of the first model to this parquet file")
    args = parser.parse_args(argv)

    merchant = [settings.MERCHANT_COL] if settings.MERCHANT_COL else []
    frame, scores, files = _shared.common_rows(args.preds, args.names, extra_columns=merchant, score_col=args.score_col)
    if len(args.preds) > 1:
        _shared.show("Files (only transactions that every file scores are read)", files)
    numbers = _shared.file_numbers(args.raw_files)
    if numbers:
        frame = _shared.join_raw_columns(frame, merchant, args.raw_base, numbers)
    ranked = _shared.ranked_rows(frame, args.all_rows, None, args.start, args.end)
    if not ranked.any():
        print("no row falls in the scored month; set TARGET_START and TARGET_END in settings.py, "
              "or pass --start and --end, or pass --all-rows")
        return
    card, first = None, None
    for name, values in scores.items():
        result = score_one(frame, values, ranked, args.per_mille, run_gap=int(args.gap_days * 86_400))
        first = result if first is None else first
        column = result["card"].rename(columns={"value": name})
        card = column if card is None else card.merge(column, on="measure", sort=False)
        _shared.show(f"Run types for {name} (runs with gaps of at most {args.gap_days:g} days)", result["types"])
    _shared.show("Run-level scorecard (run measures: runs that start in the ranked rows; fraud measures: all ranked frauds)",
                 card)
    if args.out:
        _shared.save(first["runs"], args.out)


if __name__ == "__main__":
    main()
