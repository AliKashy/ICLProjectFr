"""Shared pieces of the comparison tools: score files lined up by id, per-row arrays, fraud runs.

What this file does
-------------------
It reads score files (one row per transaction with its id, account, time, label, amount and
score), keeps the transactions that every file scores, and puts their scores side by side. It
turns the columns of such a table into plain arrays (fraud flags, amounts, account codes, whole
seconds), marks the rows of the scored month, and fetches further raw columns by transaction
id. It answers three questions that several tools of this folder ask: does a row share its
second with another row of the account, was a row approved, and which run of frauds does a
fraud belong to. It also holds each model's alert set, the exact test on the frauds that only
one of two models catches, the split of accounts into folds, and the printing and writing of
tables.

Why it exists
-------------
Two models can only be compared on the same transactions, counted in the same way. The alert
budget is a fixed small share of rows, so a handful of rows that one file has and the other
lacks changes the size of the cut and with it the count of frauds caught. Frauds come in runs
on one account, so the unit of every resampling and of every split is the account, never the
row. Keeping these rules in one place means every tool of this folder lines files up, counts
and splits in the same way, and a change to a column name is made once.

Where it goes
-------------
After scoring, in front of every tool of this folder (comparison). Nothing here is part of
the network or of training. The run of a fraud and its place in the run are known only in
hindsight, from the labels, so they serve measurement only and must never become model inputs.

What to change for the pod
--------------------------
The names in settings.py: ID_COL, ACCOUNT_COL, TIME_COL, LABEL_COL, POSITIVE_LABEL, AMOUNT_COL
and SCORE_COL for the score files; REASON_COL, APPROVED_REASONS, DECLINE_FLAG_COL and
DECLINE_FLAG_VALUES for the approved-row rule; TARGET_START and TARGET_END for the scored
month; EVAL_BASE for the raw files. RUN_GAP below is the largest gap inside one run of frauds.
Every function also takes these names as arguments.

How to try it
-------------
    frame, scores, files = common_rows(["model_a.parquet", "model_b.parquet"], names=["a", "b"])
    ranked = ranked_rows(frame)                       # the rows of the scored month
    alerts = alert_sets({name: s[ranked] for name, s in scores.items()})
The tests are in additions/tests/test_proof_shared.py.
"""
import numpy as np
import pandas as pd
from scipy import stats

from additions import settings
from additions.common import ranking, tables, timekeys
from additions.common.history import EarlierRows
from additions.common.timekeys import MISSING_SECOND

# Two frauds of one account belong to the same run when at most this many seconds lie between
# them. Seven days keeps a burst of a few hours and a slower series of weekly charges together.
RUN_GAP = 7 * 86_400


# ----------------------------------------------------------------------------------------------
# reading score files and lining them up
# ----------------------------------------------------------------------------------------------

def file_numbers(text):
    """Turn text such as "1-10,25,40-42" into the list [1, ..., 10, 25, 40, 41, 42].

    Ranges include both ends. Blanks are ignored. None or empty text gives an empty list.
    """
    numbers = []
    for part in str(text or "").replace(" ", "").split(","):
        if not part:
            continue
        if "-" in part:
            first, last = part.split("-", 1)
            numbers.extend(range(int(first), int(last) + 1))
        else:
            numbers.append(int(part))
    return numbers


def load_scores(path, extra_columns=(), id_col=None, account_col=None, time_col=None, label_col=None,
                amount_col=None, score_col=None, filesystem=None):
    """Read one score file.

    path            the parquet file written by the scoring step
    extra_columns   further columns to read when the file holds them (raw descriptors, for example)

    Returns a DataFrame with the id, account, time, label, amount and score columns, followed
    by those of `extra_columns` that the file also holds. A column the file does not have is
    simply not in the table; the function that needs it says so when it skips its part.
    """
    wanted = [
        settings.ID_COL if id_col is None else id_col,
        settings.ACCOUNT_COL if account_col is None else account_col,
        settings.TIME_COL if time_col is None else time_col,
        settings.LABEL_COL if label_col is None else label_col,
        settings.AMOUNT_COL if amount_col is None else amount_col,
        settings.SCORE_COL if score_col is None else score_col,
    ]
    have = set(tables.available_columns(path, filesystem))
    return tables.read_columns(path, [c for c in wanted + list(extra_columns) if c in have], filesystem)


def _id_keys(ids, as_text):
    """The id column as an index that can be compared across files (as text when the files disagree)."""
    return pd.Index(tables.id_text(ids) if as_text else ids)


def common_rows(paths, names=None, extra_columns=(), id_col=None, account_col=None, time_col=None,
                label_col=None, amount_col=None, score_col=None, positive_label=None, filesystem=None):
    """Read several score files and keep the transactions that every file scores.

    paths   the score files; the first one supplies account, time, label and amount
    names   one short name per file (default: "a", "b", "c", ...)

    Returns (frame, scores, files):
      frame    the columns of the first file for the common transactions, in the first file's order
      scores   a dict from name to an array [rows]: the score each file gives to those transactions,
               exactly as stored (probability or log-odds; only the order of the values is used)
      files    one line per file: rows, repeated ids, rows without a score, common rows, and the
               number of common rows whose label differs from the first file's label

    Why the common ids: a row that one file lacks changes the number of rows, so the number of
    alerts, so the last alerted row; and a fraud that only one file holds would count for one
    model only. A repeated id is kept once (its first row). Nothing is turned away: every count is
    reported so that the caller can see how much the files differ.
    """
    id_col = settings.ID_COL if id_col is None else id_col
    score_col = settings.SCORE_COL if score_col is None else score_col
    label_col = settings.LABEL_COL if label_col is None else label_col
    names = [chr(ord("a") + i) for i in range(len(paths))] if names is None else list(names)
    loaded = [load_scores(paths[0], extra_columns, id_col, account_col, time_col, label_col, amount_col,
                          score_col, filesystem)]
    for path in paths[1:]:
        # Only the id, the score and (when present) the label of the other files are needed.
        have = set(tables.available_columns(path, filesystem))
        loaded.append(tables.read_columns(path, [c for c in (id_col, score_col, label_col) if c in have], filesystem))
    # When one file stores the id as a number and another as text, every id is compared as text.
    numeric = [pd.api.types.is_numeric_dtype(t[id_col]) for t in loaded]
    as_text = len(set(numeric)) > 1
    lines, kept = [], []
    for name, table in zip(names, loaded):
        once = table.drop_duplicates(id_col)                      # a repeated id is kept once
        scored = once[once[score_col].notna()]                    # a row without a score cannot be ranked
        lines.append({"file": name, "rows": len(table), "repeated_ids": len(table) - len(once),
                      "without_score": len(once) - len(scored)})
        kept.append(scored.set_index(_id_keys(scored[id_col], as_text)))
    common = kept[0].index
    for other in kept[1:]:
        common = common[common.isin(other.index)]                 # keeps the order of the first file
    frame = kept[0].loc[common].reset_index(drop=True)
    scores = {}
    for name, line, table in zip(names, lines, kept):
        part = table.loc[common]
        scores[name] = part[score_col].to_numpy(dtype=np.float64)
        line["common_rows"] = len(common)
        # The labels of the first file are the ones every model is judged on. When another file
        # carries labels too, the number of rows on which they differ is worth knowing.
        if label_col in part.columns and label_col in frame.columns:
            differs = fraud_flags(part, label_col, positive_label) != fraud_flags(frame, label_col, positive_label)
            line["label_differs"] = int(differs.sum())
        else:
            line["label_differs"] = np.nan
    return frame, scores, pd.DataFrame(lines)


def join_raw_columns(df, columns, base=None, numbers=None, id_col=None, filesystem=None, file_name=None):
    """Add raw columns to a table of scores, matched by transaction id.

    df        the scored rows; the table must hold the id column
    columns   names of the raw columns wanted; None entries and columns `df` already has are ignored
    base      folder of the numbered raw files (default: settings.EVAL_BASE)
    numbers   the file numbers to read; None or an empty list means "no raw files"

    Returns a table with the same rows in the same order plus the columns that were found. A
    row whose id is in none of the raw files gets a missing value. When no raw files are named,
    or a wanted column is in none of them, the table comes back without that column and one
    line is printed; the tools then skip the part that needs it.
    """
    id_col = settings.ID_COL if id_col is None else id_col
    wanted = [c for c in dict.fromkeys(columns) if c is not None and c not in df.columns]
    if not wanted:
        return df
    if numbers is None or len(numbers) == 0:
        print(f"note: column(s) {wanted} are not in the score file and no raw files were named; they are skipped")
        return df
    base = settings.EVAL_BASE if base is None else base
    raw = tables.read_files(base, numbers, [id_col] + wanted, filesystem, file_name, add_file_number=False)
    found = [c for c in wanted if c in raw.columns]
    if id_col not in raw.columns or not found:
        print(f"note: the raw files hold no usable id or none of {wanted}; they are skipped")
        return df
    raw = raw.drop_duplicates(id_col)                             # one raw row per id
    as_text = pd.api.types.is_numeric_dtype(df[id_col]) != pd.api.types.is_numeric_dtype(raw[id_col])
    lookup = raw.set_index(_id_keys(raw[id_col], as_text))
    keys = _id_keys(df[id_col], as_text)
    out = df.copy()
    for c in found:
        # Looking each id up keeps the row count and the row order of the scored rows exactly.
        out[c] = lookup[c].reindex(keys).to_numpy()
    return out


# ----------------------------------------------------------------------------------------------
# per-row arrays
# ----------------------------------------------------------------------------------------------

def has_code(values, codes):
    """Yes/no per row: is the value one of `codes`?

    The codes are written as text in settings ("00", "51", "A"). A column stored as text is
    compared as text with blanks stripped. A column stored as numbers is compared as numbers,
    so the code "00" matches 0 and "1" matches 1.0. A missing value never matches.
    """
    series = pd.Series(np.asarray(values))
    if pd.api.types.is_numeric_dtype(series.dtype):
        numbers = []
        for code in codes:
            try:
                numbers.append(float(code))
            except (TypeError, ValueError):
                pass                                   # a code such as "Y" cannot match a number
        return np.isin(series.to_numpy(dtype=np.float64), numbers)
    text = series.astype(str).str.strip()
    return (series.notna() & text.isin([str(code).strip() for code in codes])).to_numpy()


def fraud_flags(df, label_col=None, positive_label=None):
    """1.0 on fraud rows and 0.0 on all other rows, one number per row."""
    label_col = settings.LABEL_COL if label_col is None else label_col
    positive_label = settings.POSITIVE_LABEL if positive_label is None else positive_label
    return has_code(df[label_col], (positive_label,)).astype(np.float64)


def amounts(df, amount_col=None):
    """Dollar amounts per row, or None with one printed line when the table has no amount column."""
    amount_col = settings.AMOUNT_COL if amount_col is None else amount_col
    if amount_col is None or amount_col not in df.columns:
        print("note: no amount column; the dollar figures are skipped")
        return None
    return df[amount_col].to_numpy(dtype=np.float64)


def account_codes(df, account_col=None):
    """One small integer per account: the key of every history and the unit of every resampling.

    A row without an account gets a code of its own, so that it enters no history and two such
    rows are never taken for the same account.
    """
    account = df[settings.ACCOUNT_COL if account_col is None else account_col]
    codes = timekeys.codes(account)
    missing = account.isna().to_numpy()
    if missing.any():
        codes[missing] = int(codes.max()) + 1 + np.arange(int(missing.sum()))
    return codes


def row_seconds(df, time_col=None):
    """Whole seconds of every row (a missing time becomes timekeys.MISSING_SECOND)."""
    return timekeys.seconds(df[settings.TIME_COL if time_col is None else time_col])


def ranked_rows(df, all_rows=False, time_col=None, start=None, end=None):
    """Yes/no per row: is the row ranked, that is, does it fall in the scored month?

    all_rows     True ranks every row of the table
    start, end   the scored month, start inclusive and end exclusive (default: TARGET_START and
                 TARGET_END in settings)

    The evaluation files start one month before the scored month. Those earlier rows are
    history: later rows may look back on them, but they take no alert place and count no
    fraud. A row without a time is never ranked. A table without a time column is ranked
    whole, with one printed line.
    """
    time_col = settings.TIME_COL if time_col is None else time_col
    if all_rows:
        return np.ones(len(df), dtype=bool)
    if time_col not in df.columns:
        print("note: no time column; every row is ranked")
        return np.ones(len(df), dtype=bool)
    start = settings.TARGET_START if start is None else start
    end = settings.TARGET_END if end is None else end
    # The same function that floors the row times is used, so both sides are cut the same way.
    low, high = timekeys.seconds(pd.to_datetime(pd.Series([start, end])))
    secs = row_seconds(df, time_col)
    return (secs >= low) & (secs < high)


def alert_sets(scores, per_mille=None, rounding=None):
    """Each model's own alert set: a dict from name to a yes/no array over the rows.

    scores   a dict from name to the scores of the ranked rows (shape [rows])

    Every model gets its own cut over the whole set of ranked rows: the top share by its own
    score. Rows that tie at the cut are settled by row order, which gives one definite set per
    model. Capture figures that are reported should still come from `ranking.capture`, which
    credits ties in proportion; the definite sets are for tables that need to say which rows
    a model alerts.
    """
    return {name: ranking.alert_mask(values, per_mille, rounding) for name, values in scores.items()}


# ----------------------------------------------------------------------------------------------
# three questions about the rows of an account
# ----------------------------------------------------------------------------------------------

def shares_second(keys, secs):
    """Yes/no per row: does another row of the same account fall in the same whole second?

    keys   one integer per row (the account code), shape [rows]
    secs   whole seconds per row, shape [rows]

    Two rows of one account in the same second cannot be put in a trustworthy order, so under
    the time rule neither sees the other. A model that does let such a row see its neighbour
    knows more on exactly these rows, which is why they are a preset sensitivity read. The
    answer is only as complete as the table: a neighbour that is not in the table is not seen.
    A row without a time shares its second with nobody.
    """
    keys = np.asarray(keys)
    secs = np.asarray(secs, dtype=np.int64)
    order = timekeys.stable_order(keys, secs)
    k, t = keys[order], secs[order]
    same_as_previous = np.zeros(len(order), dtype=bool)
    if len(order) > 1:
        same_as_previous[1:] = (k[1:] == k[:-1]) & (t[1:] == t[:-1]) & (t[1:] != MISSING_SECOND)
    same_as_next = np.zeros(len(order), dtype=bool)
    same_as_next[:-1] = same_as_previous[1:]
    out = np.zeros(len(order), dtype=bool)
    out[order] = same_as_previous | same_as_next
    return out


def approved_rows(df, reason_col=None, approved_reasons=None, decline_flag_col=None, decline_flag_values=None):
    """Yes/no per row: was the transaction approved? None when the table holds neither column.

    A row counts as approved when its response code is one of the approval codes and the
    decline flag is not set. A row with no response code is counted as not approved, because
    a fraud label sits only on rows whose code says "approved". When only one of the two
    columns is in the table, that one decides. The bank's decision on a row describes the
    outcome of that row, so it is used here only to sort rows into groups after scoring.
    """
    reason_col = settings.REASON_COL if reason_col is None else reason_col
    decline_flag_col = settings.DECLINE_FLAG_COL if decline_flag_col is None else decline_flag_col
    approved = None
    if reason_col is not None and reason_col in df.columns:
        codes = settings.APPROVED_REASONS if approved_reasons is None else approved_reasons
        approved = has_code(df[reason_col], codes)
    if decline_flag_col is not None and decline_flag_col in df.columns:
        values = settings.DECLINE_FLAG_VALUES if decline_flag_values is None else decline_flag_values
        not_flagged = ~has_code(df[decline_flag_col], values)
        approved = not_flagged if approved is None else approved & not_flagged
    if approved is None:
        print("note: no response code and no decline flag in the table; the approved-row part is skipped")
    return approved


def fraud_runs(keys, secs, fraud, run_gap=None):
    """The run of every fraud, its place in the run and the time since the account's previous fraud.

    keys      one integer per row (the account code), shape [rows]
    secs      whole seconds per row, shape [rows]
    fraud     yes/no per row: the fraud rows
    run_gap   the largest gap, in seconds, between two frauds of one run (default: RUN_GAP)

    Returns a dict of three arrays over all rows (shape [rows]):
      run              a number shared by the frauds of one run; -1 on rows that are no fraud
      position         1 for the first fraud of a run, 2 for the next, and so on; 0 on other rows
      since_previous   seconds since the account's previous fraud; NaN when there is none

    Time rule: the previous fraud is the latest fraud of the account in a strictly earlier
    second. Frauds of one account in the same second cannot be put in order, so they share one
    position and one gap. A fraud without a time belongs to no run. All of this is hindsight:
    the columns come from labels, so they are for measurement only and never model inputs.
    """
    run_gap = RUN_GAP if run_gap is None else run_gap
    keys = np.asarray(keys)
    secs = np.asarray(secs, dtype=np.int64)
    n = len(keys)
    out = {"run": np.full(n, -1, dtype=np.int64), "position": np.zeros(n, dtype=np.int64),
           "since_previous": np.full(n, np.nan)}
    f = np.flatnonzero(np.asarray(fraud, dtype=bool) & (secs != MISSING_SECOND))
    if len(f) == 0:
        return out
    keys_f, secs_f = keys[f], secs[f]
    # Within the fraud rows alone, the "previous fraud" of a fraud is simply its latest earlier row.
    since = EarlierRows(keys_f, secs_f).seconds_since_last()
    opens_run = np.isnan(since) | (since > run_gap)
    # Number the runs along the account-and-time order. Frauds of one second share their gap,
    # so they open a run together or continue one together; only the first of them adds a run.
    order = timekeys.stable_order(keys_f, secs_f)
    k, t = keys_f[order], secs_f[order]
    first_of_second = np.ones(len(order), dtype=bool)
    first_of_second[1:] = (k[1:] != k[:-1]) | (t[1:] != t[:-1])
    run = np.empty(len(order), dtype=np.int64)
    run[order] = np.cumsum(first_of_second & opens_run[order]) - 1
    out["run"][f] = run
    # Position: the frauds of the same run in strictly earlier seconds, plus one.
    out["position"][f] = EarlierRows(run, secs_f).count() + 1
    out["since_previous"][f] = since
    return out


# ----------------------------------------------------------------------------------------------
# splitting accounts, testing a pair, sizing an interval
# ----------------------------------------------------------------------------------------------

def account_folds(keys, n_folds=2, seed=None):
    """A fold number per row, dealt out by account: all rows of an account land in one fold.

    keys   the account of every row (codes or names), shape [rows]
    seed   seed of the shuffle (default: settings.BOOTSTRAP_SEED)

    Accounts are shuffled and dealt to the folds in turn, so the folds hold nearly the same
    number of accounts. Whole accounts are kept together because frauds come in runs on one
    account: a model fitted on some frauds of a run and read on the others would look better
    than it is.
    """
    seed = settings.BOOTSTRAP_SEED if seed is None else seed
    codes = timekeys.codes(np.asarray(keys))
    n_accounts = int(codes.max()) + 1 if len(codes) else 0
    fold_of_account = np.random.default_rng(seed).permutation(n_accounts) % int(n_folds)
    return fold_of_account[codes]


def exact_test(only_a, only_b):
    """Two-sided exact binomial test on the frauds that only one of two models catches.

    only_a   frauds caught by model A and missed by model B
    only_b   frauds caught by model B and missed by model A

    Returns the p-value: the chance of a split at least this uneven when each of these frauds
    is as likely to fall to one model as to the other. Frauds that both models catch, or both
    miss, say nothing about the difference, so only these two counts enter. The test treats
    the frauds as independent. Frauds of one run are not, so the p-value is on the small side
    when the counts are dominated by a few long runs; the account bootstrap is the main read
    and this test is the cross-check.
    """
    only_a, only_b = int(round(only_a)), int(round(only_b))
    if only_a == only_b:
        return 1.0
    # With equal chances the two tails are mirror images, so the two-sided value is twice one tail.
    return float(min(1.0, 2.0 * stats.binom.cdf(min(only_a, only_b), only_a + only_b, 0.5)))


def interval_z(interval=None):
    """Standard errors between the middle and either end of a two-sided interval (1.645 for 90%).

    interval   the width of the interval in percent (default: settings.INTERVAL_PERCENT)
    """
    interval = settings.INTERVAL_PERCENT if interval is None else interval
    return float(stats.norm.ppf(0.5 + interval / 200.0))


# ----------------------------------------------------------------------------------------------
# the command line, printing and writing
# ----------------------------------------------------------------------------------------------

def add_score_arguments(parser):
    """Add the arguments that say how score files are read and ranked.

    Every default is None, which means "use the value in settings.py"; the functions of the
    tools resolve it when they run.
    """
    parser.add_argument("--score-col", default=None, help="name of the score column (default: settings.SCORE_COL)")
    parser.add_argument("--start", default=None, help="first day of the scored month (default: settings.TARGET_START)")
    parser.add_argument("--end", default=None, help="first day after the scored month (default: settings.TARGET_END)")
    parser.add_argument("--all-rows", action="store_true",
                        help="rank every row of the files instead of the rows of the scored month")
    parser.add_argument("--per-mille", type=int, default=None,
                        help="alert budget in rows per thousand (default: settings.OUTSORT_PER_MILLE)")
    parser.add_argument("--raw-base", default=None,
                        help="folder of the numbered raw files (default: settings.EVAL_BASE)")
    parser.add_argument("--raw-files", default=None,
                        help='raw file numbers from which missing columns are joined by id, for example "8228-8243"')
    return parser


def show(title, table, digits=4):
    """Print a title and a table as plain text.

    `table` is a DataFrame or a list of dicts. Decimal numbers are printed with `digits`
    decimals and missing numbers as a dash, so the output can be pasted into a note as is.
    """
    frame = table if isinstance(table, pd.DataFrame) else pd.DataFrame(table)
    print()
    print(title)
    if len(frame) == 0:
        print("  (no rows)")
        return
    with pd.option_context("display.width", 250, "display.max_columns", None, "display.max_colwidth", 90):
        print(frame.to_string(index=False, na_rep="-", float_format=lambda value: f"{value:.{digits}f}"))


def save(table, path, filesystem=None):
    """Write a table to a parquet file (an existing file is replaced) and print where it went."""
    tables.write_table(table, path, filesystem)
    print(f"wrote {len(table)} row(s) to {path}")
    return path
