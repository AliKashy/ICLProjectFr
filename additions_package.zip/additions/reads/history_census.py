"""History census: how much history the scored rows really have.

What this file does
-------------------
For every row it counts the strictly earlier rows of the same account in the file, the
distinct earlier seconds among them, and the days between the account's first row in the file
and the row. For the rows of the scored month it then prints three tables: the share of rows
and of frauds that have at least 20, 40, 80 and 120 earlier seconds (and earlier rows); the
distribution of the days covered; and a few quantiles of the three counts.

Why it exists
-------------
A longer history window in the second stage costs memory and time, and it can only help a
scored row that has that much history. The evaluation files start one month before the scored
month, so a scored row has between one and two months of history, however long the window is.
When the training files cover a longer stretch of time, most training rows see a full window.
A model trained on full windows and judged on rows whose windows are partly empty is trained
on one task and judged on another, and a gain measured on long validation histories overstates
what the scored rows can use. This census gives the facts first: if only a small share of scored
rows has 80 earlier seconds, a history of 120 changes little there, and training can cap the
history it shows at what the scored rows have. The split by frauds matters because fraud
accounts can be busier or newer than the rest.

Where it goes
-------------
On raw files or on a prediction file, before the history length of stage 2 is changed (in the
original code the `history_len` given to `SequenceBuilder` and to `FTTransformerHierModel`).
It needs account and time; the label is used only to split the tables by fraud. No score is
needed. The counts follow the same time rule as the model's history: strictly earlier seconds
only. The per-row counts could also serve as an input ("how much history is available"),
because they use nothing but earlier rows.

What to change for the pod
--------------------------
settings.py: ACCOUNT_COL, TIME_COL, LABEL_COL, POSITIVE_LABEL, ID_COL, TARGET_START,
TARGET_END, and EVAL_BASE when raw files are read. HISTORY_LENGTHS and the day buckets below.
The census must be given every row of the files (the month before the scored month too),
otherwise the counts are too low.

How to try it
-------------
    python additions/reads/history_census.py --base /path/to/evaluation/files --files 8228-8243
    python additions/reads/history_census.py --pred predictions.parquet --lengths 20 40 80 120
or, from Python:
    depth = history_depth(df)
    print(depth_table(depth, _rows.in_scored_month(df), _rows.fraud_flags(df)))
The tests are in additions/tests/test_reads_history_census.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd

from additions import settings
from additions.common import tables
from additions.common.history import EarlierRows
from additions.common.timekeys import MISSING_SECOND
from additions.reads import _cli, _rows

# PLACEHOLDER: the history lengths under consideration, in earlier seconds read by stage 2.
# Put the current length first and the candidates after it.
HISTORY_LENGTHS = (20, 40, 80, 120)

# The split of the days between the account's first row in the file and the row.
DAY_EDGES = (7, 14, 31, 45, 61)
DAY_LABELS = ("under 7 days", "7 to 14 days", "14 to 31 days", "31 to 45 days", "45 to 61 days", "61 days or more")

# The quantiles shown in the summary table.
QUANTILES = (0.10, 0.25, 0.50, 0.75, 0.90)


def history_depth(df, account_col=None, time_col=None):
    """Three counts per row that say how much history of its account lies before it in the file.

    df   rows with account and time. Every row of the files must be there, the month before
         the scored month too, or the counts come out too low.

    Returns a DataFrame in the row order of `df` with the columns:
      earlier_rows      rows of the same account in strictly earlier seconds
      earlier_seconds   distinct seconds among those rows. Rows that share a second become
                        visible together, so this is the number of history steps a model that
                        works on whole seconds can read.
      days_covered      days between the account's first row in the file and the row; 0 for a
                        row with no earlier row

    Time rule: rows of the same second do not count for each other, exactly as they do not see
    each other in the model. A row without a time has no history and is in no one's history.
    """
    keys = _rows.account_codes(df, account_col)
    secs = _rows.row_seconds(df, time_col)
    earlier = EarlierRows(keys, secs)
    has_time = secs != MISSING_SECOND
    # The second itself is used as the "value" whose distinct earlier occurrences are counted.
    # It is shifted to start at zero because the engine reads negative values as "no value".
    second_value = np.where(has_time, secs - (secs[has_time].min() if has_time.any() else 0), -1)
    return pd.DataFrame({
        "earlier_rows": earlier.count(),
        "earlier_seconds": earlier.distinct(second_value),
        "days_covered": np.nan_to_num(earlier.seconds_since_first(), nan=0.0) / 86_400.0,
    })


def depth_table(depth, scored, fraud, lengths=None):
    """Share of the scored rows, and of the scored frauds, that have at least L steps of history.

    depth     what `history_depth` returned
    scored    yes/no per row: the rows that are ranked
    fraud     1 on fraud rows, 0 elsewhere (used only to split the table)
    lengths   the history lengths L to test (default: HISTORY_LENGTHS)

    Returns a DataFrame with one line per L: length, rows_with_seconds and frauds_with_seconds
    (share with at least L distinct earlier seconds), rows_with_rows and frauds_with_rows (share
    with at least L earlier rows). A history length is only useful on the scored rows to the
    extent that the first two shares are high.
    """
    lengths = HISTORY_LENGTHS if lengths is None else lengths
    scored = np.asarray(scored, dtype=bool)
    is_fraud = scored & (np.asarray(fraud) > 0)
    seconds, rows = depth["earlier_seconds"].to_numpy(), depth["earlier_rows"].to_numpy()

    def share(counts, part, length):
        return float((counts[part] >= length).mean()) if part.any() else np.nan

    return pd.DataFrame([{"length": int(length),
                          "rows_with_seconds": share(seconds, scored, length),
                          "frauds_with_seconds": share(seconds, is_fraud, length),
                          "rows_with_rows": share(rows, scored, length),
                          "frauds_with_rows": share(rows, is_fraud, length)} for length in lengths])


def days_table(depth, scored, fraud):
    """Distribution of the days covered, for the scored rows and for the scored frauds.

    depth, scored, fraud   as in `depth_table`

    Returns a DataFrame with one line per bucket of `days_covered`: days, rows, share_of_rows,
    frauds, share_of_frauds. The days covered are bounded by the length of the file before the
    row, which is why no window can show a scored row more than the file holds.
    """
    scored = np.asarray(scored, dtype=bool)
    is_fraud = (np.asarray(fraud) > 0)[scored]
    names = _rows.bucket(depth["days_covered"].to_numpy()[scored], DAY_EDGES, DAY_LABELS)
    lines = []
    for name in DAY_LABELS:
        rows, frauds = int((names == name).sum()), int(((names == name) & is_fraud).sum())
        lines.append({"days": name, "rows": rows, "share_of_rows": rows / max(len(names), 1),
                      "frauds": frauds, "share_of_frauds": frauds / max(int(is_fraud.sum()), 1)})
    return pd.DataFrame(lines)


def quantile_table(depth, scored):
    """A few quantiles of the three counts over the scored rows.

    depth    what `history_depth` returned
    scored   yes/no per row: the rows that are ranked

    Returns a DataFrame with one line per count and one column per quantile (q10 ... q90).
    """
    part = depth[np.asarray(scored, dtype=bool)]
    lines = []
    for column in ("earlier_rows", "earlier_seconds", "days_covered"):
        line = {"count": column}
        for q in QUANTILES:
            line[f"q{int(round(q * 100)):02d}"] = float(part[column].quantile(q)) if len(part) else np.nan
        lines.append(line)
    return pd.DataFrame(lines)


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(
        description="How many earlier rows, earlier seconds and days of history the scored rows have.")
    parser.add_argument("--pred", default=None, help="prediction file (parquet) that holds every row of its files")
    parser.add_argument("--base", default=None,
                        help="folder of raw files, used when no --pred is given (default: settings.EVAL_BASE)")
    parser.add_argument("--files", default=None, help='raw file numbers, for example "8228-8243"')
    parser.add_argument("--lengths", nargs="*", type=int, default=None,
                        help="history lengths to test (default: 20 40 80 120)")
    parser.add_argument("--start", default=None, help="first day of the scored month (default: settings.TARGET_START)")
    parser.add_argument("--end", default=None, help="first day after the scored month (default: settings.TARGET_END)")
    parser.add_argument("--all-rows", action="store_true",
                        help="report on every row instead of the rows of the scored month")
    parser.add_argument("--out", default=None,
                        help="write id and the three counts of the reported rows to this parquet file")
    args = parser.parse_args(argv)

    wanted = [settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL, settings.LABEL_COL]
    if args.pred:
        df = tables.read_columns(args.pred, wanted)
    elif args.files:
        base = settings.EVAL_BASE if args.base is None else args.base
        df = tables.read_files(base, _cli.file_numbers(args.files), wanted)
    else:
        print("nothing to read: give --pred, or --files (with --base)")
        return
    scored = _cli.scored_rows(df, args)
    if _cli.nothing_to_rank(scored):
        return
    depth = history_depth(df)
    # The label only splits the tables by fraud. Without it the fraud columns stay empty.
    label = _rows.optional_column(df, settings.LABEL_COL, "the fraud label (the split by fraud)")
    fraud = np.zeros(len(df)) if label is None else _rows.fraud_flags(df)
    _cli.show("Share of scored rows and frauds with at least this much history",
              depth_table(depth, scored, fraud, args.lengths or None))
    _cli.show("Days between the account's first row in the file and the row (scored rows)",
              days_table(depth, scored, fraud))
    _cli.show("Quantiles over the scored rows", quantile_table(depth, scored), digits=1)
    if args.out:
        out = depth[scored].reset_index(drop=True)
        if settings.ID_COL in df.columns:
            out.insert(0, settings.ID_COL, df[settings.ID_COL].to_numpy()[scored])
        _cli.save(out, args.out)


if __name__ == "__main__":
    main()
