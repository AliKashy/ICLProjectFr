"""Rows of a prediction file: loading, raw columns by id, the scored month and the row type.

What this file does
-------------------
It reads a prediction file (one row per transaction with its id, account, time, label, amount
and score), fetches further raw columns for the same transactions from the numbered raw files
by transaction id, marks the rows of the scored month, and gives every row one of six row
types: advice, zero-dollar check, risk decline, funds decline, other decline or approved. It
also lines up several prediction files of the same rows so that their scores sit side by side,
and holds the small accessors (labels, scores, amounts, account keys, whole seconds) that the
tools of this folder share.

Why it exists
-------------
A fraud label sits only on approved rows, so declined attempts, advice rows and zero-dollar
checks are never labelled. Whether such rows are ranked, and what type each row is, can move a
capture figure by as much as the difference between two good models, so every read has to make
these choices in the same way. The evaluation files also start one month before the scored
month: the earlier rows are history that later rows may look back on, but they are not ranked.
Keeping the rule "rank the scored month, keep the rest as history" in one place stops a tool
from quietly ranking history rows or from throwing the history away.

Where it goes
-------------
After scoring, in front of every tool of this folder: a prediction file and raw files in, one
table and a few arrays out. Nothing here is part of the network or of training.

What to change for the pod
--------------------------
The names in settings.py: ID_COL, ACCOUNT_COL, TIME_COL, LABEL_COL, POSITIVE_LABEL, AMOUNT_COL,
SCORE_COL and SCORE_KIND for the prediction file; REASON_COL, DECLINE_FLAG_COL, ADVICE_COL,
TYPE_COL and SEGMENT_COL for the raw columns; APPROVED_REASONS, RISK_DECLINE_REASONS,
FUNDS_DECLINE_REASONS, DECLINE_FLAG_VALUES and ZERO_CHECK_TYPES for the code values;
TARGET_START and TARGET_END for the scored month. ADVICE_EMPTY_VALUES below lists the values
of the advice column that mean "not an advice row". Every function also takes these names as
arguments. To switch an optional column off for one call, pass a name the table does not have
(for example "").

How to try it
-------------
    df = load_predictions("predictions.parquet")
    df = join_raw_columns(df, descriptor_columns(), base=settings.EVAL_BASE, numbers=settings.CHOOSE_FILES)
    scored = in_scored_month(df)          # yes/no per row; the other rows stay as history
    types = row_type(df)                  # "approved", "advice", "risk_decline", ...
The tests are in additions/tests/test_reads_rows.py.
"""
import numpy as np
import pandas as pd

from additions import settings
from additions.common import ranking, tables, timekeys

# The six row types in the order in which they are tested: the first one that fits a row wins.
ROW_TYPES = ("advice", "zero_check", "risk_decline", "funds_decline", "other_decline", "approved")

# The row types that can never carry a fraud label: every type except an approved live request.
NEVER_LABELLED = ROW_TYPES[:-1]

# PLACEHOLDER: put here the values of the advice column that mean "this is not an advice row";
# a missing value always means that. For a 0/1 flag use ("", "0"), for a Y/N flag ("", "N").
ADVICE_EMPTY_VALUES = ("",)


# ----------------------------------------------------------------------------------------------
# reading
# ----------------------------------------------------------------------------------------------

def load_predictions(path, extra_columns=(), id_col=None, account_col=None, time_col=None, label_col=None,
                     amount_col=None, score_col=None, filesystem=None):
    """Read one prediction file.

    path            the parquet file written by the scoring step
    extra_columns   further columns to read when the file holds them (raw descriptors, for example)

    Returns a DataFrame with the id, account, time, label, amount and score columns, followed
    by those of `extra_columns` that the file also holds. A column the file does not have is
    simply not in the table, so a prediction file without amounts still loads. Nothing is
    printed here: the function that needs a missing column says so when it skips its part
    (`amounts` for the dollar figures, `row_type` for the raw descriptors), and
    `join_raw_columns` can fetch the raw descriptors from the raw files.
    """
    wanted = [
        settings.ID_COL if id_col is None else id_col,
        settings.ACCOUNT_COL if account_col is None else account_col,
        settings.TIME_COL if time_col is None else time_col,
        settings.LABEL_COL if label_col is None else label_col,
        settings.AMOUNT_COL if amount_col is None else amount_col,
        settings.SCORE_COL if score_col is None else score_col,
    ]
    have = set(tables.available_columns(path, filesystem))
    return tables.read_columns(path, [c for c in wanted + list(extra_columns) if c in have], filesystem)


def descriptor_columns(reason_col=None, decline_flag_col=None, advice_col=None, type_col=None, segment_col=None):
    """The raw columns that say what kind of row a transaction is, without those switched off.

    These are the columns the row type, the eligible-row rule and the segment split need. They
    describe the outcome or the kind of a row, so they are used here only to sort rows into
    groups after scoring; none of them is a model input.
    """
    names = [
        settings.REASON_COL if reason_col is None else reason_col,
        settings.DECLINE_FLAG_COL if decline_flag_col is None else decline_flag_col,
        settings.ADVICE_COL if advice_col is None else advice_col,
        settings.TYPE_COL if type_col is None else type_col,
        settings.SEGMENT_COL if segment_col is None else segment_col,
    ]
    return [name for name in names if name is not None]


def join_raw_columns(df, columns, base=None, numbers=None, id_col=None, filesystem=None, file_name=None):
    """Add raw columns to a table of predictions, matched by transaction id.

    df        the predictions; it must hold the id column
    columns   names of the raw columns wanted; None entries and columns `df` already has are ignored
    base      folder of the numbered raw files (default: settings.EVAL_BASE)
    numbers   the file numbers to read; None or an empty list means "no raw files"

    Returns a table with the same rows in the same order plus the columns that were found. A
    row whose id is in none of the raw files gets a missing value. When no raw files are named,
    or a wanted column is in none of them, the table comes back without that column and one
    line is printed; the tools then skip the part that needs it.
    """
    id_col = settings.ID_COL if id_col is None else id_col
    wanted = [c for c in dict.fromkeys(columns) if c is not None and c not in df.columns]
    if not wanted:
        return df
    if numbers is None or len(numbers) == 0:
        print(f"note: column(s) {wanted} are not in the predictions and no raw files were named; they are skipped")
        return df
    base = settings.EVAL_BASE if base is None else base
    raw = tables.read_files(base, numbers, [id_col] + wanted, filesystem, file_name, add_file_number=False)
    found = [c for c in wanted if c in raw.columns]
    if id_col not in raw.columns or not found:
        print(f"note: the raw files hold no usable id or none of {wanted}; they are skipped")
        return df
    # One raw row per id. A repeated id would otherwise have no single answer.
    lookup = raw[[id_col] + found].drop_duplicates(id_col).set_index(id_col)
    keys = df[id_col]
    if pd.api.types.is_numeric_dtype(keys) != pd.api.types.is_numeric_dtype(lookup.index):
        # One side stores the id as a number and the other as text: both are compared as text.
        lookup.index = pd.Index(tables.id_text(lookup.index))
        keys = tables.id_text(keys)
    out = df.copy()
    for c in found:
        # Looking each id up keeps the row count and the row order of the predictions exactly.
        out[c] = lookup[c].reindex(keys).to_numpy()
    return out


def load_aligned(paths, extra_columns=(), id_col=None, account_col=None, time_col=None, label_col=None,
                 amount_col=None, score_col=None, filesystem=None):
    """Read several prediction files of the same rows and line them up by transaction id.

    Returns (frame, matrix). `frame` holds the columns of the first file for the rows that
    every file has, in the order of the first file. `matrix` has shape [rows, files]: column j
    is the score that file j gives to the row. Rows that are missing from a file, or have no
    score in it, are left out with one printed line; the files do not have to be in the same
    row order.
    """
    id_col = settings.ID_COL if id_col is None else id_col
    score_col = settings.SCORE_COL if score_col is None else score_col
    first = load_predictions(paths[0], extra_columns, id_col, account_col, time_col, label_col, amount_col,
                             score_col, filesystem)
    # One line per id, so that looking an id up in another file has a single answer.
    first = first.drop_duplicates(id_col).reset_index(drop=True)
    columns = [first[score_col].to_numpy(dtype=np.float64)]
    for path in paths[1:]:
        # Only the id and the score of the other files are needed. Each score is looked up by
        # the ids of the first file, which puts it on the right line whatever the row order.
        other = tables.read_columns(path, [id_col, score_col], filesystem).drop_duplicates(id_col)
        lookup, keys = other.set_index(id_col)[score_col], first[id_col]
        if pd.api.types.is_numeric_dtype(keys) != pd.api.types.is_numeric_dtype(lookup.index):
            # One file stores the id as a number and the other as text: both are compared as text.
            lookup.index, keys = pd.Index(tables.id_text(lookup.index)), tables.id_text(keys)
        columns.append(lookup.reindex(keys).to_numpy(dtype=np.float64))
    matrix = np.column_stack(columns)
    # A row that some file does not score cannot be compared across the files, so it is dropped.
    keep = ~np.isnan(matrix).any(axis=1)
    if not keep.all():
        print(f"note: {int((~keep).sum())} of {len(keep)} rows are not scored in every file and are left out")
    return first.loc[keep].reset_index(drop=True), matrix[keep]


# ----------------------------------------------------------------------------------------------
# per-row arrays
# ----------------------------------------------------------------------------------------------

def optional_column(df, name, purpose):
    """The column `name` of `df`, or None with one printed line when it is switched off or absent."""
    if name is None or name not in df.columns:
        print(f"note: no column for {purpose}; that part is skipped")
        return None
    return df[name]


def has_code(values, codes):
    """Yes/no per row: is the value one of `codes`?

    The codes are written as text in settings ("00", "51", "A"). A column stored as text is
    compared as text with blanks stripped. A column stored as numbers is compared as numbers,
    so the code "00" matches 0 and "1" matches 1.0. A missing value never matches.
    """
    series = pd.Series(np.asarray(values))
    if pd.api.types.is_numeric_dtype(series.dtype):
        # A column of numbers: the codes that can be read as numbers are compared as numbers.
        numbers = []
        for code in codes:
            try:
                numbers.append(float(code))
            except (TypeError, ValueError):
                pass                                   # a code such as "Y" cannot match a number
        return np.isin(series.to_numpy(dtype=np.float64), numbers)
    # A column of text (or of mixed values): everything is compared as stripped text.
    text = series.astype(str).str.strip()
    return (series.notna() & text.isin([str(code).strip() for code in codes])).to_numpy()


def fraud_flags(df, label_col=None, positive_label=None):
    """1.0 on fraud rows and 0.0 on all other rows, one number per row."""
    label_col = settings.LABEL_COL if label_col is None else label_col
    positive_label = settings.POSITIVE_LABEL if positive_label is None else positive_label
    return has_code(df[label_col], (positive_label,)).astype(np.float64)


def scores(df, score_col=None):
    """The score column as floats, exactly as stored (probability or log-odds)."""
    return df[settings.SCORE_COL if score_col is None else score_col].to_numpy(dtype=np.float64)


def logits(df, score_col=None, score_kind=None):
    """The score as log-odds. `score_kind` says what is stored: "probability" or "logit"."""
    return ranking.to_logit(scores(df, score_col), score_kind)


def amounts(df, amount_col=None):
    """Dollar amounts per row, or None with one printed line when the table has no amount column."""
    amount_col = settings.AMOUNT_COL if amount_col is None else amount_col
    column = optional_column(df, amount_col, "the amount (dollar capture)")
    return None if column is None else column.to_numpy(dtype=np.float64)


def account_codes(df, account_col=None):
    """One small integer per account: the key of every history and the unit of the bootstrap.

    A row without an account gets a code of its own, so that it enters no history and two such
    rows are never taken for the same account.
    """
    account = df[settings.ACCOUNT_COL if account_col is None else account_col]
    codes = timekeys.codes(account)
    missing = account.isna().to_numpy()
    if missing.any():
        codes[missing] = int(codes.max()) + 1 + np.arange(int(missing.sum()))
    return codes


def row_seconds(df, time_col=None):
    """Whole seconds of every row (a missing time becomes timekeys.MISSING_SECOND)."""
    return timekeys.seconds(df[settings.TIME_COL if time_col is None else time_col])


# ----------------------------------------------------------------------------------------------
# the scored month
# ----------------------------------------------------------------------------------------------

def scored_window(start=None, end=None):
    """The scored month as two whole seconds: the first second inside it and the first second after it."""
    start = settings.TARGET_START if start is None else start
    end = settings.TARGET_END if end is None else end
    # The same function that floors the row times is used, so both sides are cut the same way.
    low, high = timekeys.seconds(pd.to_datetime(pd.Series([start, end])))
    return int(low), int(high)


def in_scored_month(df, time_col=None, start=None, end=None):
    """Yes/no per row: does the row fall in the scored month (start inclusive, end exclusive)?

    Only these rows are ranked. The other rows are not dropped: they stay in the table as
    history for anything that looks back from a scored row. A row without a time is never in
    the scored month.
    """
    low, high = scored_window(start, end)
    secs = row_seconds(df, time_col)
    return (secs >= low) & (secs < high)


# ----------------------------------------------------------------------------------------------
# the row type
# ----------------------------------------------------------------------------------------------

def is_advice(df, advice_col=None, empty_values=None):
    """Yes/no per row: is the advice column filled? None when the table has no such column."""
    advice_col = settings.ADVICE_COL if advice_col is None else advice_col
    column = optional_column(df, advice_col, "the advice flag")
    if column is None:
        return None
    empty = ADVICE_EMPTY_VALUES if empty_values is None else empty_values
    return column.notna().to_numpy() & ~has_code(column, empty)


def is_zero_check(df, type_col=None, zero_check_types=None):
    """Yes/no per row: is the row a zero-dollar check? None when the table has no type column."""
    type_col = settings.TYPE_COL if type_col is None else type_col
    column = optional_column(df, type_col, "the transaction type")
    if column is None:
        return None
    return has_code(column, settings.ZERO_CHECK_TYPES if zero_check_types is None else zero_check_types)


def has_decline_flag(df, decline_flag_col=None, decline_flag_values=None):
    """Yes/no per row: was the row declined before the fraud engine? None without the flag column."""
    decline_flag_col = settings.DECLINE_FLAG_COL if decline_flag_col is None else decline_flag_col
    column = optional_column(df, decline_flag_col, "the decline flag")
    if column is None:
        return None
    return has_code(column, settings.DECLINE_FLAG_VALUES if decline_flag_values is None else decline_flag_values)


def row_type(df, advice_col=None, type_col=None, reason_col=None, decline_flag_col=None, zero_check_types=None,
             risk_decline_reasons=None, funds_decline_reasons=None, approved_reasons=None, decline_flag_values=None):
    """One of the six row types for every row, as an array of text in the row order of `df`.

    The types are tested in this order and the first that fits wins:
      advice          the advice column is filled (a notice, not a live request)
      zero_check      the transaction type is a zero-dollar check
      risk_decline    the response code is one of the risk-decline codes
      funds_decline   the response code is one of the insufficient-funds codes
      other_decline   the response code is not an approval code, or the decline flag is set
      approved        everything else

    Only an approved row can carry a fraud label. The order matters for rows that fit several
    types: an advice row with a decline code counts as advice, because it would be unlabelled
    even if it had been approved. A column that is not available switches its test off (one
    line is printed), and the rows it would have caught fall through to the later types.
    """
    reason_col = settings.REASON_COL if reason_col is None else reason_col
    risk_codes = settings.RISK_DECLINE_REASONS if risk_decline_reasons is None else risk_decline_reasons
    funds_codes = settings.FUNDS_DECLINE_REASONS if funds_decline_reasons is None else funds_decline_reasons
    approved_codes = settings.APPROVED_REASONS if approved_reasons is None else approved_reasons
    never = np.zeros(len(df), dtype=bool)
    advice = is_advice(df, advice_col)
    zero_check = is_zero_check(df, type_col, zero_check_types)
    flagged = has_decline_flag(df, decline_flag_col, decline_flag_values)
    reason = optional_column(df, reason_col, "the response code")
    if reason is None:
        risk = funds = not_approved = never
    else:
        risk = has_code(reason, risk_codes)
        funds = has_code(reason, funds_codes)
        # A label sits only on a row whose code says "approved", so a row with any other code,
        # or with no code at all, is counted as not approved.
        not_approved = ~has_code(reason, approved_codes)
    tests = [
        never if advice is None else advice,
        never if zero_check is None else zero_check,
        risk,
        funds,
        not_approved | (never if flagged is None else flagged),
    ]
    # The first test that holds names the row; a row for which none holds is approved.
    return np.select(tests, ROW_TYPES[:-1], default=ROW_TYPES[-1])


# ----------------------------------------------------------------------------------------------
# small pieces for the tables
# ----------------------------------------------------------------------------------------------

def cut_threshold(ranked_scores, per_mille=None, rounding=None):
    """The lowest score that is still inside the alert cut; infinity when the cut holds no row.

    `ranked_scores` are the scores of the ranked rows only. A row then counts as "inside the
    cut" when its score is at or above this value, which also gives an answer for rows outside
    the ranked set (an earlier row of the account, for example). Rows that tie with the value
    all count as inside; that matters only for scores so coarse that many rows share one value.
    """
    s = np.asarray(ranked_scores, dtype=np.float64)
    inside = ranking.alert_mask(s, per_mille, rounding)
    return float(s[inside].min()) if inside.any() else np.inf


def capture_line(name, labels, score_values, amount_values=None, per_mille=None, rounding=None):
    """One line of a results table: what the alert cut catches for one score column.

    Returns a dict with the name of the read, the sizes (rows, frauds, alerts), the frauds
    caught with ties credited in proportion (so it can be a fraction), the share of frauds
    caught (udr) with its lowest and highest value over tie orders, and the share of fraud
    dollars caught (vdr). A figure that cannot be computed (no fraud, no amounts) is NaN, so
    the column stays numeric.
    """
    c = ranking.capture(labels, score_values, amount_values, per_mille, rounding)
    line = {"read": name, "rows": c["rows"], "frauds": int(round(c["frauds"])), "alerts": c["alerts"],
            "caught": c["caught"]}
    for key in ("udr", "udr_min", "udr_max", "vdr"):
        line[key] = np.nan if c[key] is None else c[key]
    return line


def bootstrap_line(result, first="a", second="b", gain="gain"):
    """One table line from the dict that `bootstrap.paired_bootstrap` returns.

    `first`, `second` and `gain` name the columns for the candidate's capture, the control's
    capture and their difference. The interval (low, high), the share of draws above zero and
    the number of draws keep their names. A figure the bootstrap could not give is NaN.
    """
    names = {"a": first, "b": second, "gain": gain, "low": "low", "high": "high",
             "share_above_zero": "share_above_zero"}
    line = {new: np.nan if result[old] is None else float(result[old]) for old, new in names.items()}
    line["draws"] = result["draws"]
    return line


def bucket(values, edges, labels, missing="none"):
    """The name of the bucket each value falls in.

    edges     increasing cut points; a value equal to a cut point belongs to the bucket above it
    labels    one name more than there are edges (below the first edge, between edges, above the last)
    missing   the name given to a missing value

    Example: edges (3600, 86400) with labels ("under 1 hour", "1 to 24 hours", "longer").
    """
    values = np.asarray(values, dtype=np.float64)
    index = np.searchsorted(np.asarray(edges, dtype=np.float64), values, side="right")
    names = np.asarray(list(labels) + [missing], dtype=object)
    index[np.isnan(values)] = len(labels)
    return names[index]
