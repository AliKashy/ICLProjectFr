"""A calendar input whose scored value was never trained: clamp it, or give it the mean row.

What this file does
-------------------
It holds two small fixes for a calendar field (here the month) that takes a value in the
scored month that no training row ever had, and a reader that compares them.
`clamp_month` replaces every month later than the last trained month by that last trained
month, before the field is turned into codes. `mean_row` returns a copy of the field's
embedding table in which the row an unseen month lands on is the mean of the rows that training
did update; `patch_embedding` writes that copy into a loaded model. The reader takes several
prediction files of the same rows (month as is, month clamped, mean row, no month) and reports
capture of each on the rows of the scored month only, with a paired bootstrap of every variant
against the first.

Why it exists
-------------
When the scored month comes after the last month of the training files, a month-of-year field
has a value on every scored row that training never saw. Its row of the embedding table still
holds the random numbers it started with, or the value falls back on a row for unknown values
that was never trained either. The model then adds an untrained vector to exactly the rows it
is judged on. The exported vector of every scored row carries that direction too, so a
downstream tree model fitted on earlier months reads shifted columns in the scored month. With
about a year of data a month of the year can never be trained for the month being scored, so
no encoding repairs this. The choice is between treating the month as the last trained one
(persistence), giving it a neutral row (the mean of the trained rows), or dropping the field.
The evaluation files start one month before the scored month, and that earlier month is a
trained value: a read that mixes both months hides the problem. That is why the reader keeps
the rows of the scored month only.

Where it goes
-------------
Preprocessing and tokenizer, at scoring time only. `clamp_month` goes where the calendar
fields are derived from the timestamp, before they are encoded as codes (in the original code
inside `SequenceBuilder._encode_file`, right after the calendar fields are derived).
`mean_row` and `patch_embedding` act on the loaded checkpoint before scoring: the table is the
entry of `FeatureTokenizer.cat_embeddings` that belongs to the month field. Training is not
changed by either. The reader runs after scoring, on the prediction files of the variants.

What to change for the pod
--------------------------
CALENDAR_FIELD, TRAINED_ROWS and TARGET_ROW below: the name of the calendar field, which rows
of its table training updated, and which row an unseen value lands on. The last trained month
is an argument of `clamp_month`; its default is the month before settings.TARGET_START.
settings.py: ID_COL, ACCOUNT_COL, TIME_COL, LABEL_COL, AMOUNT_COL, SCORE_COL, SCORE_KIND,
TARGET_START, TARGET_END, OUTSORT_PER_MILLE and the bootstrap settings for the reader.

How to try it
-------------
    df[CALENDAR_FIELD] = clamp_month(df[settings.TIME_COL], "2025-05")       # before encoding
    patch_embedding(model.embedding.cat_embeddings[position_of_month])       # on a loaded model
    python additions/reads/month_token.py --pred as_is=a.parquet clamped=b.parquet mean_row=c.parquet
The tests are in additions/tests/test_reads_month_token.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd
import torch

from additions import settings
from additions.common import ranking, timekeys
from additions.common.bootstrap import paired_bootstrap
from additions.reads import _cli, _rows

# PLACEHOLDER: the name of the calendar input field whose value in the scored month was never
# trained. It is the column that `clamp_month` overwrites and the field whose table is patched.
CALENDAR_FIELD = "month"

# PLACEHOLDER: the rows of that field's embedding table that training updated. The example fits
# a table whose rows 0 and 1 are kept for "unknown" and "missing" and whose rows 2 to 9 hold
# eight trained months; list the rows of the months that occur in the training files.
TRAINED_ROWS = tuple(range(2, 10))

# PLACEHOLDER: the row an unseen month lands on at scoring time. In a table with a row for
# unknown values that is this row; in a table with one row per month it is the row of the
# scored month. A list of rows is allowed.
TARGET_ROW = 0


def clamp_month(month_values, last_trained=None, first_trained=None):
    """Replace every month that is later than the last trained month by that month.

    month_values    one value per row, in one of two forms:
                    - timestamps (datetime values, or text that pandas can parse). The answer is
                      then the month of the year, 1 to 12, that the calendar field should carry.
                    - whole numbers. Without `first_trained` they are read as a scale that grows
                      with time (202506 for June 2025, or year * 12 + month) and the answer is on
                      the same scale. With `first_trained` they are read as months of the year.
    last_trained    the last month training saw: a date-like value such as "2025-05" for
                    timestamps (default: the month before settings.TARGET_START), or a number on
                    the scale of `month_values`
    first_trained   only for months of the year: the first trained month. The trained months
                    then run from first_trained to last_trained, round the year end if needed
                    (10 and 5 mean October to May), and every other month is replaced.

    Returns an array with one value per row. A missing value stays missing.

    Timestamps are the safe form. Plain months of the year cannot tell a month that lies after
    training from one that lies before it, which is why `first_trained` is needed for them.
    """
    values = np.asarray(month_values)
    if np.issubdtype(values.dtype, np.number):
        if last_trained is None:
            raise ValueError("clamp_month needs last_trained when the months are given as numbers")
        if first_trained is None:
            # A scale that grows with time: a later month is simply a larger number.
            return np.where(values > last_trained, last_trained, values)
        # Months of the year: a month is trained when it lies in the stretch first .. last.
        if first_trained <= last_trained:
            trained = (values >= first_trained) & (values <= last_trained)
        else:
            trained = (values >= first_trained) | (values <= last_trained)   # the stretch crosses the year end
        return np.where(trained | np.isnan(values), values, last_trained)
    # Timestamps: the comparison is made in calendar time, and the answer is the month of the year.
    stamps = timekeys.timestamps(values)             # datetimes or text; a value that is no time becomes missing
    last = pd.Period(settings.TARGET_START, "M") - 1 if last_trained is None else pd.Period(last_trained, "M")
    month = stamps.dt.month.to_numpy(dtype=np.float64)
    # year * 12 + month grows by one with every calendar month, so "later" is a plain comparison.
    later = ((stamps.dt.year * 12 + stamps.dt.month) > (last.year * 12 + last.month)).to_numpy()
    out = np.where(later, float(last.month), month)
    return out if np.isnan(out).any() else out.astype(np.int64)


def mean_row(embedding_weight, trained_rows=None, target_row=None):
    """A copy of an embedding table whose target row is the mean of the trained rows.

    embedding_weight   the table, shape [rows, width]: a torch tensor or a numpy array
    trained_rows       the rows training updated (default: TRAINED_ROWS)
    target_row         the row, or list of rows, to overwrite (default: TARGET_ROW)

    Returns a new table of the same type and shape; the input is not changed. Every row other
    than the target keeps its values. The mean of the trained rows is the vector the model saw
    "on average" for this field, so a row scored with it gets no push in any one month's
    direction. Passing all rows as the target makes the field say nothing at all, which is a
    scoring-time stand-in for a model trained without the field.
    """
    trained = list(TRAINED_ROWS if trained_rows is None else trained_rows)
    target = TARGET_ROW if target_row is None else target_row
    target = target if isinstance(target, (int, np.integer)) else list(target)
    if torch.is_tensor(embedding_weight):
        out = embedding_weight.detach().clone()
        out[target] = out[trained].mean(dim=0)
        return out
    out = np.array(embedding_weight)                       # a copy; a float table keeps its precision
    if not np.issubdtype(out.dtype, np.floating):
        out = out.astype(np.float64)
    out[target] = out[trained].mean(axis=0)
    return out


def patch_embedding(embedding, trained_rows=None, target_row=None):
    """Write the mean row into an embedding layer of a loaded model, in place.

    embedding   a `torch.nn.Embedding` (the table of the calendar field)

    Returns the same layer. Only the target row changes. It is meant for a checkpoint that is
    about to score; the saved checkpoint on disk is not touched.
    """
    with torch.no_grad():
        embedding.weight.copy_(mean_row(embedding.weight, trained_rows, target_row))
    return embedding


def compare_files(paths, names=None, all_rows=False, start=None, end=None, id_col=None, account_col=None,
                  time_col=None, label_col=None, positive_label=None, amount_col=None, score_col=None,
                  score_kind=None, per_mille=None, rounding=None, draws=None, seed=None, interval=None,
                  filesystem=None):
    """Capture of several prediction files of the same rows, each compared with the first.

    paths      the prediction files; the first is the control (the month as the model was trained)
    names      one name per file for the table (default: file 1, file 2, ...)
    all_rows   False (the default) reads the rows of the scored month only, which is the point
               of this reader; True reads every row the files share

    Returns a DataFrame with one line per file: read, rows (the number of ranked rows), udr,
    vdr, ap, caught, and for every file after the first the paired gain in udr over the first
    file with its interval (gain, low, high, share_above_zero). The bootstrap resamples whole
    accounts. Several variants read on the same rows are a small multiple comparison, so the
    winner should be read once more on rows that did not choose it.
    """
    frame, matrix = _rows.load_aligned(paths, (), id_col, account_col, time_col, label_col, amount_col, score_col,
                                       filesystem)
    names = [f"file {j + 1}" for j in range(matrix.shape[1])] if names is None else list(names)
    ranked = np.ones(len(frame), dtype=bool) if all_rows else _rows.in_scored_month(frame, time_col, start, end)
    logit = ranking.to_logit(matrix, score_kind)[ranked]
    y = _rows.fraud_flags(frame, label_col, positive_label)[ranked]
    a = _rows.amounts(frame, amount_col)
    a = None if a is None else a[ranked]
    units = _rows.account_codes(frame, account_col)[ranked]
    lines = []
    for j, name in enumerate(names):
        # Every file is ranked on the same rows; the files after the first are also compared
        # with the first on the same draws of accounts.
        c = _rows.capture_line(str(name), y, logit[:, j], a, per_mille, rounding)
        ap = ranking.average_precision(y, logit[:, j])
        line = {"read": c["read"], "rows": c["rows"], "udr": c["udr"], "vdr": c["vdr"],
                "ap": np.nan if ap is None else ap, "caught": c["caught"],
                "gain": np.nan, "low": np.nan, "high": np.nan, "share_above_zero": np.nan}
        if j > 0 and ranked.any():
            r = paired_bootstrap(units, y, logit[:, j], logit[:, 0], a, per_mille, draws, seed, interval, rounding)
            paired = _rows.bootstrap_line(r)
            line.update({key: paired[key] for key in ("gain", "low", "high", "share_above_zero")})
        lines.append(line)
    return pd.DataFrame(lines)


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(
        description="Compare prediction files that treat the untrained month in different ways.")
    parser.add_argument("--pred", nargs="+", required=True,
                        help="prediction files as name=path, the control first: as_is=a.parquet clamped=b.parquet")
    parser.add_argument("--draws", type=int, default=None, help="bootstrap draws (default: settings.BOOTSTRAP_DRAWS)")
    _cli.add_score_arguments(parser)
    parser.add_argument("--out", default=None, help="write the comparison table to this parquet file")
    args = parser.parse_args(argv)
    # "name=path" gives the line its name; a bare path is named after the file.
    pairs = [item.split("=", 1) if "=" in item else (Path(item).stem, item) for item in args.pred]
    table = compare_files([path for _, path in pairs], [name for name, _ in pairs], args.all_rows, args.start,
                          args.end, score_col=args.score_col, score_kind=args.score_kind, per_mille=args.per_mille,
                          draws=args.draws)
    if _cli.nothing_to_rank(table["rows"] > 0):
        return
    where = "all rows" if args.all_rows else "rows of the scored month only"
    _cli.show(f"Treatments of the calendar field '{CALENDAR_FIELD}' ({where}); gains are against the first file", table)
    if args.out:
        _cli.save(table, args.out)


if __name__ == "__main__":
    main()
