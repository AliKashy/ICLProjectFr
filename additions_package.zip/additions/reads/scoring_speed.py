"""Speed card: where the time of a scoring loop goes, read off about thirty batches.

What this file does
-------------------
`SpeedCard` is wrapped around an existing PyTorch scoring loop, best as a context manager
(`with SpeedCard(model) as card:`), so that its hooks come off again also after an error. The
loop calls `card.batch_arrived(rows)` as soon as the loader hands a batch over, and
`card.batch_done()` after the last line that belongs to scoring that batch. The model must be
called as `model(batch)`: hooks on the model and on its parts do the rest, and they fire only
through that call, not through `model.forward(batch)` or a method that wraps it. After about
thirty batches `report()` prints a short card in plain lines:
  - rows per second over the measured batches, and how long one million rows would take at
    that pace;
  - the share of the wall time spent outside the batch (from `batch_done` to the next
    `batch_arrived`: the loader and whatever the loop does after `batch_done`) against the
    share spent between `batch_arrived` and `batch_done`, and the share spent inside the
    model's own forward call;
  - the device of the model's weights, whether a GPU is there at all, whether the model was in
    training mode during its calls, whether gradients were being recorded during its calls
    (both read inside a forward pre-hook on the model itself, and only for calls made while a
    batch is open), and the number type of the weights ("mixed" when the weights differ);
  - rows per batch (smallest, middle, largest);
  - peak GPU memory from the first batch to the last `batch_done`, when the model is on a GPU;
  - for every watched part: calls, milliseconds per batch, and share of the time inside the
    model;
  - a last block, "what stands out", made by plain rules, each line only when its rule fires.
The first batch is reported apart and left out of the averages, because it carries start-up
cost (memory allocation, kernel selection, lazy loading of files by the loader).
`numbers()` gives the same values as a dict, and `close()` takes the hooks off again.

Why it exists
-------------
Scoring about one million rows with a small transformer took more than nine hours on a GPU
machine, which is slower than a 4-core CPU manages for the same model. The scoring loop cannot
be seen from here, so the cause has to be read off on the machine itself. The usual causes
leave clear marks on the card: a loader that cannot keep up shows as a large share outside the
batch; a model left on the CPU shows as "cpu" next to "GPU there: yes"; a loop without
`torch.no_grad()` or a model left in `train()` shows in the gradient and training-mode lines;
tiny batches on a GPU show in the rows per batch; one slow part shows in the table of parts.
Thirty batches and two minutes are enough to tell these apart.

Timing details that matter when the card is read:
  - On a GPU the hooks, `batch_arrived` and `batch_done` call `torch.cuda.synchronize()` before
    they read the clock. GPU work runs behind the Python code, and without the wait its time is
    charged to whichever later line happens to wait for it. The waits make the measured loop
    slower than the real one, because the GPU can no longer run ahead of Python while the card
    is on; how much slower has not been measured on a GPU, so the rates on the card are a lower
    bound there.
  - Set `sync_parts=False` when many small parts are watched on a loop whose GPU time goes into
    starting many small pieces of work: the GPU is then waited for only at `batch_arrived`,
    `batch_done` and around the model, and the part times become rough.
  - Time spent after `batch_done` (moving scores to the CPU, writing them, logging) counts as
    outside the batch, together with the loader. Calling `batch_done` after the last line that
    belongs to scoring a batch keeps that work inside the batch.
  - Parts are timed inclusively: a part that contains another watched part includes that
    part's time. With the default (the direct children of the model) no part contains another.
  - A part that is called several times per batch has all its calls added up.

Where it goes
-------------
Around the loop that scores the rows, for about thirty batches, and nowhere else. It reads no
file and writes no file. It changes no result: the hooks only read the clock and the flags,
and return nothing, so the model's outputs are the same with the card on and off.

What to change for the pod
--------------------------
SMALL_BATCH_ROWS and BIG_PART_SHARE below, which depend on the model in use. The loop itself:
    with SpeedCard(model) as card:           # or SpeedCard(model, parts={"encoder": model.encoder})
        for batch in loader:
            card.batch_arrived(len(batch))   # how many real rows this batch holds
            with torch.no_grad():
                scores = model(batch)        # model(...), not model.forward(...)
            card.batch_done()                # after the last line that scores this batch
            if card.batches >= 30:
                break
        print(card.report())
When the loop moves the batch to the GPU, that copy falls between `batch_arrived` and
`batch_done` and is charged to the batch, not to the time outside it.

How to try it
-------------
    python additions/reads/scoring_speed.py
builds a tiny model and a slow made-up loader and prints a card. The tests are in
additions/tests/test_reads_scoring_speed.py (package only).
"""
import itertools
import statistics
import time

import torch

# PLACEHOLDER: below this many rows per batch a GPU spends most of its time starting small
# pieces of work rather than doing them; the right value depends on the model's width and depth.
SMALL_BATCH_ROWS = 2_000

# PLACEHOLDER: one part above this share of the time inside the model is pointed out; with many
# parts a lower value can make sense, with two or three parts a higher one.
BIG_PART_SHARE = 0.5

# Above this share of the wall time spent outside the batch, the loader and the work after
# batch_done are pointed out.
WAIT_SHARE_LIMIT = 0.5

# Part shares that add up to more than this point to parts that overlap; the margin above 1
# leaves room for clock noise between the model's hooks and the parts' hooks.
PART_SUM_LIMIT = 1.05

# The size of one million rows, used for the "one million rows would take" line.
MILLION = 1_000_000

# The words used on the card and in its rule for the time between batch_done and the next
# batch_arrived; kept in one place so that the line and the rule say the same thing.
OUTSIDE_WORDS = "outside the batch: the loader and whatever the loop does after batch_done"


def _clock():
    """The clock every timing on the card reads; perf_counter is the finest steady clock Python has."""
    return time.perf_counter()


def _as_duration(seconds):
    """A number of seconds as plain text in hours, minutes and seconds, so long runs read easily."""
    # A missing value stays visible as such instead of turning into a made-up number.
    if seconds is None:
        return "not known"
    total = int(round(seconds))
    hours, rest = divmod(total, 3600)
    minutes, secs = divmod(rest, 60)
    # Hours are left out for short durations, which keeps the line short.
    if hours:
        return f"{hours} h {minutes:02d} min {secs:02d} s"
    return f"{minutes} min {secs:02d} s"


def _share(value):
    """A share between 0 and 1 as a percentage with one decimal, or "not known"."""
    return "not known" if value is None else f"{100.0 * value:.1f}%"


def _ms(value):
    """Seconds as milliseconds with two decimals, or "not known"."""
    return "not known" if value is None else f"{1000.0 * value:.2f} ms"


def _one_or_mixed(texts):
    """One value as itself, several as "mixed (a, b)", none as "no weights"."""
    # A model without parameters or buffers has neither a device nor a number type.
    if not texts:
        return "no weights"
    # Sorting keeps the text the same from run to run, whatever order the weights come in.
    names = sorted(texts)
    return names[0] if len(names) == 1 else f"mixed ({', '.join(names)})"


class SpeedCard:
    """Watches a scoring loop for a few batches and says where the time goes.

    model       the PyTorch module that scores a batch; a forward pre-hook and a forward hook
                are put on it to time its calls and to read the training mode and the gradient
                flag; the loop must call it as model(batch) for these hooks to fire
    parts       None to watch the model's direct child modules by name, or a dict
                {name: module} to watch other modules (any depth; a part that contains another
                includes its time); every entry must be a torch.nn.Module
    sync_parts  True (the default) to wait for the GPU in every part's hooks as well, so that
                each part's time is exact; False to wait only at batch_arrived, batch_done and
                around the model, for a loop with many small parts where the waits themselves
                would slow the GPU down; on the CPU it changes nothing

    The loop calls `batch_arrived(rows)` as soon as the loader hands a batch over and
    `batch_done()` after the last line that belongs to scoring that batch. `batches` counts the
    finished batches. `report()` and `numbers()` can be called at any time, also with zero or
    one batch. `close()` removes every hook; used as a context manager the card calls it on
    leaving the block, also after an error.
    """

    def __init__(self, model, parts=None, sync_parts=True):
        # The model is checked first: without a module there is nothing to put a hook on.
        if not isinstance(model, torch.nn.Module):
            raise TypeError(f"SpeedCard: the model is a {type(model).__name__}, not a torch.nn.Module; "
                            "give the module that scores a batch")
        # The model is kept so that the device and number type of its weights can be read later.
        self.model = model
        # By default the direct children are watched, which splits the model time without overlap.
        if parts is None:
            parts = dict(model.named_children())
        self.parts = dict(parts)
        # Every part is checked before any hook goes on, so that a wrong entry leaves no hook behind.
        for name, module in self.parts.items():
            if not isinstance(module, torch.nn.Module):
                raise TypeError(f"SpeedCard: the part '{name}' is a {type(module).__name__}, not a "
                                "torch.nn.Module; give a module of the model (such as model.encoder) "
                                "or leave that entry out")
        # Whether the part hooks wait for the GPU as well; the model hooks always do.
        self.sync_parts = bool(sync_parts)
        # Finished batches; the loop reads this to know when to stop.
        self.batches = 0
        # One record per finished batch: rows, waiting time, batch time, model time, part times.
        self._records = []
        # The batch now between batch_arrived and batch_done, or None between batches.
        self._open = None
        # The clock at the last batch_done, from which the wait for the next batch is measured.
        self._last_done = None
        # Batches closed by the next batch_arrived rather than by batch_done; their loader time
        # falls inside the batch, so the share outside the batch cannot be read.
        self._closed_by_arrival = 0
        # Counts of the model's calls made while a batch is open, and of those calls in training
        # mode and with gradients recorded; calls outside the batches (a warm-up, for example)
        # are counted apart so that they cannot set off the rules.
        self._calls = 0
        self._calls_training = 0
        self._calls_grad = 0
        self._calls_outside = 0
        # Start times of calls in progress; a list per watched module so that nested or repeated
        # calls of the same module are each matched with their own end.
        self._model_starts = []
        self._part_starts = {name: [] for name in self.parts}
        # Each plain note is printed once, so that a loop of thousands of batches is not flooded.
        self._noted = set()
        # Whether the GPU memory peak was reset at the first batch, so that it covers the batches.
        self._peak_reset = False
        # The GPU memory peak, read when each batch closes, so that the last read is at the last batch.
        self._peak = None
        # The devices and number types of the weights, read now and again at every batch_arrived,
        # so that the hooks do not walk every weight on every call.
        self._read_weights()
        # Every hook handle, so that close() can take each one off again.
        self._handles = []
        try:
            self._handles.append(model.register_forward_pre_hook(self._model_before))
            self._handles.append(model.register_forward_hook(self._model_after))
            for name, module in self.parts.items():
                self._handles.append(module.register_forward_pre_hook(self._part_before(name)))
                self._handles.append(module.register_forward_hook(self._part_after(name)))
        except Exception:
            # A failure halfway would leave hooks that nothing could reach; they come off first.
            self.close()
            raise

    # ----- the card as a context manager -----------------------------------------------------

    def __enter__(self):
        """Gives the card itself to the `with` block; the hooks are already on."""
        return self

    def __exit__(self, kind, value, trace):
        """Takes the hooks off on leaving the block, also after an error, and lets the error through."""
        self.close()
        # False lets an error raised inside the block reach the caller unchanged.
        return False

    # ----- facts about the model -------------------------------------------------------------

    def _read_weights(self):
        """Reads the device and number type of every parameter and buffer of the model."""
        devices = {}
        dtypes = set()
        # Parameters and buffers both hold weights; a model made of buffers only still has a device.
        for tensor in itertools.chain(self.model.parameters(), self.model.buffers()):
            devices.setdefault(str(tensor.device), tensor.device)
            dtypes.add(str(tensor.dtype).replace("torch.", ""))
        self._devices = devices
        self._dtypes = dtypes
        # The GPUs among the devices are the ones the clock has to wait for.
        self._gpus = [device for device in devices.values() if device.type == "cuda"]

    def _device(self):
        """The device of the model's weights as text, "mixed (...)" when they differ, or "no weights"."""
        return _one_or_mixed(self._devices)

    def _dtype(self):
        """The number type of the model's weights as text, "mixed (...)" when they differ, or "no weights"."""
        return _one_or_mixed(self._dtypes)

    def _on_gpu(self):
        """True when some weight of the model is on a GPU, which decides whether the clock waits for the GPU."""
        return bool(self._gpus)

    def _sync(self):
        """Waits for the GPU's queued work before the clock is read, so that its time lands on the right line."""
        # On the CPU the work is already done when Python gets the result, so there is nothing to wait for.
        # Every GPU that holds a weight is waited for, since work on any of them belongs to the batch.
        for device in self._gpus:
            torch.cuda.synchronize(device)

    def _asks_for_gradient(self):
        """True when some weight of the model asks for a gradient, so that a graph would be recorded."""
        # any() stops at the first weight that asks, which is usually the first one.
        return any(weight.requires_grad for weight in self.model.parameters())

    def _note(self, key, text):
        """Prints one plain note once and carries on; nothing on the card ever stops the loop."""
        if key not in self._noted:
            self._noted.add(key)
            print(f"speed card: {text}")

    # ----- hooks -----------------------------------------------------------------------------

    def _model_before(self, module, args):
        """Forward pre-hook on the model: reads the training mode and the gradient flag, starts the clock."""
        # Calls outside an open batch (a warm-up, a check) are counted apart and set off no rule.
        if self._open is None:
            self._calls_outside += 1
        else:
            # Both flags are read here, inside the call, because that is where they take effect.
            self._calls += 1
            self._open["model_calls"] += 1
            self._calls_training += int(module.training)
            # Gradients are recorded only when the switch is on and some weight asks for one.
            self._calls_grad += int(torch.is_grad_enabled() and self._asks_for_gradient())
        self._sync()
        self._model_starts.append(_clock())

    def _model_after(self, module, args, output):
        """Forward hook on the model: stops the clock and adds the call's time to the open batch."""
        self._sync()
        now = _clock()
        # A call whose start was lost (for example after an error inside the model) is skipped.
        if not self._model_starts:
            return
        start = self._model_starts.pop()
        # Calls outside batch_arrived/batch_done count for neither the times nor the flags.
        if self._open is not None:
            self._open["model"] += now - start

    def _part_before(self, name):
        """Forward pre-hook for one watched part: starts the clock for this call of the part."""
        def hook(module, args):
            # With sync_parts off the part's GPU work is not waited for, which keeps the GPU busy.
            if self.sync_parts:
                self._sync()
            self._part_starts[name].append(_clock())
        return hook

    def _part_after(self, name):
        """Forward hook for one watched part: stops the clock and counts the call in the open batch."""
        def hook(module, args, output):
            # The same choice as in the pre-hook, so that both ends of a part are read alike.
            if self.sync_parts:
                self._sync()
            now = _clock()
            # A call whose start was lost is skipped rather than given a made-up time.
            if not self._part_starts[name]:
                return
            start = self._part_starts[name].pop()
            if self._open is not None:
                self._open["part_time"][name] += now - start
                self._open["part_calls"][name] += 1
        return hook

    # ----- the two calls of the loop ---------------------------------------------------------

    def batch_arrived(self, rows):
        """Called as soon as the loader hands a batch over; rows: how many real rows it holds."""
        # The weights are read again here, outside the hooks, in case the model moved since the last batch.
        self._read_weights()
        # The GPU is waited for first, so that work left over from before is not charged to this batch.
        self._sync()
        now = _clock()
        # A batch that arrives while the previous one is still open closes the previous one here.
        if self._open is not None:
            self._note("arrived_twice", "batch_arrived came twice without batch_done; "
                                        "the earlier batch is counted as done at the second call")
            self._closed_by_arrival += 1
            self._finish(now)
        # The peak of GPU memory is reset once, at the first batch, so that it covers the batches.
        if not self._peak_reset and self._on_gpu():
            for device in self._gpus:
                torch.cuda.reset_peak_memory_stats(device)
            self._peak_reset = True
        # The wait is the time since the last batch was done; the first batch has none to measure.
        wait = None if self._last_done is None else now - self._last_done
        self._open = {"rows": int(rows), "wait": wait, "start": now, "model": 0.0, "model_calls": 0,
                      "part_time": {name: 0.0 for name in self.parts},
                      "part_calls": {name: 0 for name in self.parts}}

    def batch_done(self):
        """Called after the last line that belongs to scoring the open batch."""
        # On a GPU the scores may still be on their way; the wait charges that work to this batch.
        self._sync()
        now = _clock()
        # A batch_done without batch_arrived has no batch to close, so it is noted and left out.
        if self._open is None:
            self._note("done_alone", "batch_done came without batch_arrived; that call is left out")
            return
        self._finish(now)

    def _finish(self, now):
        """Closes the open batch at clock `now` and keeps its record."""
        record = self._open
        record["busy"] = now - record.pop("start")
        self._records.append(record)
        self._open = None
        self._last_done = now
        self.batches += 1
        # The peak is read as each batch closes, so the value kept is the one at the last batch;
        # GPU work after the loop (a report, a later step) does not reach it. The largest peak
        # over the GPUs that hold weights is kept.
        if self._peak_reset and self._on_gpu():
            self._peak = max(torch.cuda.max_memory_allocated(device) for device in self._gpus)

    # ----- the card --------------------------------------------------------------------------

    def numbers(self):
        """The card as a dict of plain values; `report()` prints exactly these values.

        Times are in seconds, shares between 0 and 1. A value that cannot be known (for
        example with zero batches, with no measured wait, or when the model's own hooks never
        fired) is None. "averaged_over" says which batches the averages cover: the batches after
        the first, or the first batch alone when there is no other.
        """
        records = self._records
        # The devices are read again so that a model moved after the last batch shows where it is.
        self._read_weights()
        # The first batch carries start-up cost and is kept out of the averages when others exist.
        measured = records[1:] if len(records) > 1 else records
        averaged_over = ("none" if not records else
                         "batches after the first" if len(records) > 1 else "the first batch only")
        first = records[0] if records else None
        # The wall time of a measured batch is its wait plus its own time; the first has no wait.
        known_waits = [r["wait"] for r in measured if r["wait"] is not None]
        waited = sum(known_waits)
        busies = [r["busy"] for r in measured]
        models = [r["model"] for r in measured]
        wall = waited + sum(busies)
        rows = sum(r["rows"] for r in measured)
        rows_per_second = rows / wall if wall > 0 else None
        model_time = sum(models)
        # The model's time is known only when its hooks fired in the measured batches; otherwise
        # a 0 would read as a measured value.
        model_seen = any(r["model_calls"] for r in measured)
        # The share outside the batch is known only when some wait was measured and no batch was
        # closed by the next batch_arrived (whose loader time then sits inside a batch).
        split_known = bool(known_waits) and wall > 0 and self._closed_by_arrival == 0
        # Rows per batch are taken over every batch, the first too, because the start-up cost
        # does not change how many rows a batch holds.
        all_rows = [r["rows"] for r in records]
        on_gpu = self._on_gpu()
        parts = {}
        for name in self.parts:
            part_time = sum(r["part_time"][name] for r in measured)
            calls = sum(r["part_calls"][name] for r in measured)
            parts[name] = {
                "calls": calls,
                "calls_per_batch": calls / len(measured) if measured else None,
                "seconds_per_batch": part_time / len(measured) if measured else None,
                # The share is of the time inside the model, which is what the parts split up.
                "share_of_model": part_time / model_time if model_seen and model_time > 0 else None,
            }
        n = {
            "batches": len(records),
            "averaged_over": averaged_over,
            "measured_batches": len(measured),
            "rows": sum(all_rows),
            "measured_rows": rows,
            "rows_per_second": rows_per_second,
            "seconds_per_million_rows": MILLION / rows_per_second if rows_per_second else None,
            "wall_seconds": wall if measured else None,
            "waiting_share": waited / wall if split_known else None,
            "batch_share": sum(busies) / wall if split_known else None,
            "model_share": model_time / wall if model_seen and wall > 0 else None,
            "seconds_per_batch": wall / len(measured) if measured else None,
            "model_seconds_per_batch": model_time / len(measured) if model_seen else None,
            "first_batch_seconds": first["busy"] if first else None,
            "first_batch_model_seconds": first["model"] if first and first["model_calls"] else None,
            "batches_closed_by_next_arrival": self._closed_by_arrival,
            "device": self._device(),
            "gpu_there": torch.cuda.is_available(),
            "on_gpu": on_gpu,
            "dtype": self._dtype(),
            "parts_synced": self.sync_parts or not on_gpu,
            "model_calls": self._calls,
            "calls_in_training_mode": self._calls_training,
            "calls_with_gradients": self._calls_grad,
            "model_calls_outside_batches": self._calls_outside,
            "rows_per_batch_smallest": min(all_rows) if all_rows else None,
            "rows_per_batch_middle": statistics.median(all_rows) if all_rows else None,
            "rows_per_batch_largest": max(all_rows) if all_rows else None,
            "peak_gpu_bytes": self._peak if on_gpu else None,
            "parts": parts,
        }
        n["stands_out"] = self._stands_out(n, all_rows)
        return n

    def _stands_out(self, n, all_rows):
        """The lines of "what stands out", each present only when its plain rule fires."""
        lines = []
        # Rule 0: batches were seen but the model's hooks never fired inside them, so every share
        # of the model is unknown and the training and gradient rules cannot see anything.
        if n["batches"] > 0 and self._calls == 0:
            lines.append("batches were seen but the model's own hooks never fired: the loop calls "
                         "model.forward or a method that wraps it; call model(...) for the hooks to fire "
                         "(the model's share, the part shares and the training and gradient counts are "
                         "then not known)")
        # Rule 1: most of the wall time is outside the batch, so a faster model would not help.
        if n["waiting_share"] is not None and n["waiting_share"] > WAIT_SHARE_LIMIT:
            lines.append(f"more than {WAIT_SHARE_LIMIT:.0%} of the wall time is spent {OUTSIDE_WORDS} "
                         "(waiting for the next batch): that, not the model, sets the pace; if the loop "
                         "does little after batch_done, the loader is slow (more workers, pinned memory, "
                         "larger batches, or data prepared ahead)")
        # Rule 1b: batches closed by the next batch_arrived hide the loader's time inside a batch.
        if self._closed_by_arrival:
            lines.append(f"{self._closed_by_arrival} batches were closed by the next batch_arrived "
                         "instead of batch_done: the loader's time then sits inside a batch, so the share "
                         "outside the batch is not known; call batch_done after the last line that "
                         "belongs to scoring a batch")
        # Rule 2: the weights stayed on the CPU although a GPU is there to use.
        if not n["on_gpu"] and n["gpu_there"] and self._devices:
            lines.append("the model is on the CPU while a GPU is there: model.to('cuda') and the batch too")
        # Rule 2b: weights on more than one device make data move between them on every call.
        if len(self._devices) > 1:
            lines.append(f"the weights are on more than one device ({n['device']}): data moves between "
                         "them on every call; check that this is meant")
        # Rule 3: gradients were recorded, which keeps every activation and slows every call.
        if self._calls_grad:
            lines.append(f"gradients were being recorded in {self._calls_grad} of {self._calls} model calls: "
                         "wrap the loop in torch.no_grad() or torch.inference_mode()")
        # Rule 4: training mode keeps dropout on, which changes the scores and costs time.
        if self._calls_training:
            lines.append(f"the model was in training mode in {self._calls_training} of {self._calls} "
                         "model calls: call model.eval() before scoring")
        # Rule 5: small batches leave most of a GPU idle.
        if n["on_gpu"] and all_rows and statistics.median(all_rows) < SMALL_BATCH_ROWS:
            lines.append(f"batches hold {statistics.median(all_rows):g} rows in the middle, fewer than "
                         f"{SMALL_BATCH_ROWS:,} on a GPU: larger batches use the GPU better")
        parts = n["parts"]
        # Rule 6: one part takes most of the model time, so that part is where to look first. With
        # one watched part (a wrapper around the real network, say) that part always takes it all.
        if len(parts) > 1:
            for name, part in parts.items():
                if part["share_of_model"] is not None and part["share_of_model"] > BIG_PART_SHARE:
                    lines.append(f"the part '{name}' takes {_share(part['share_of_model'])} of the time "
                                 "inside the model: look there first")
        # Rule 7: the same module under two names is timed twice, so the shares overlap.
        names_by_module = {}
        for name, module in self.parts.items():
            names_by_module.setdefault(id(module), []).append(name)
        for names in names_by_module.values():
            if len(names) > 1:
                listed = ", ".join(f"'{name}'" for name in names)
                lines.append(f"the same module is listed more than once (as {listed}): its time is "
                             "counted once per name")
        # Rule 8: shares above the limit mean parts overlap, so they cannot be added up.
        shares = [part["share_of_model"] for part in parts.values() if part["share_of_model"] is not None]
        if sum(shares) > PART_SUM_LIMIT:
            lines.append(f"the part shares add up to {_share(sum(shares))}, more than "
                         f"{PART_SUM_LIMIT:.0%}: some parts contain others or are listed twice, so the "
                         "shares overlap and do not add up")
        return lines

    def report(self):
        """The card as plain text lines, built from `numbers()` so that the two always agree."""
        n = self.numbers()
        out = ["Speed card", "=========="]
        out.append(f"batches seen: {n['batches']}   rows seen: {n['rows']:,}   "
                   f"averages over: {n['averaged_over']} ({n['measured_batches']} batches, "
                   f"{n['measured_rows']:,} rows)")
        rate = n["rows_per_second"]
        out.append(f"rows per second: {'not known' if rate is None else f'{rate:,.0f}'}   "
                   f"one million rows would take: {_as_duration(n['seconds_per_million_rows'])}")
        out.append(f"per batch: {_ms(n['seconds_per_batch'])} wall, of which {_ms(n['model_seconds_per_batch'])} "
                   "inside the model")
        # The old label "waiting for the next batch" is kept in front of the plain words, so that
        # the line still reads the same where it was read before.
        out.append(f"waiting for the next batch: {_share(n['waiting_share'])} ({OUTSIDE_WORDS})")
        out.append(f"between batch_arrived and batch_done: {_share(n['batch_share'])}   "
                   f"inside the model: {_share(n['model_share'])}")
        out.append(f"first batch (left out of the averages): {_ms(n['first_batch_seconds'])}, of which "
                   f"{_ms(n['first_batch_model_seconds'])} inside the model")
        out.append("")
        out.append(f"device of the weights: {n['device']}   GPU there: {'yes' if n['gpu_there'] else 'no'}   "
                   f"number type: {n['dtype']}")
        out.append(f"model calls during the batches: {n['model_calls']}   in training mode: "
                   f"{n['calls_in_training_mode']}   with gradients recorded: {n['calls_with_gradients']}   "
                   f"(calls outside the batches, not counted: {n['model_calls_outside_batches']})")
        out.append(f"rows per batch: smallest {n['rows_per_batch_smallest']}, "
                   f"middle {n['rows_per_batch_middle']}, largest {n['rows_per_batch_largest']}")
        # The memory line appears only on a GPU, where the peak can be read.
        if n["peak_gpu_bytes"] is not None:
            out.append(f"peak GPU memory from the first batch to the last batch_done: "
                       f"{n['peak_gpu_bytes'] / 2 ** 20:,.1f} MiB")
        out.append("")
        if n["parts"]:
            # Without the GPU waits in the part hooks the part times are rough, and the header says so.
            rough = "" if n["parts_synced"] else "; rough, since sync_parts is off"
            out.append(f"watched parts (timed inclusively; averages over the measured batches{rough}):")
            width = max(len(name) for name in n["parts"])
            for name, part in n["parts"].items():
                calls = part["calls_per_batch"]
                out.append(f"  {name:<{width}}  calls {part['calls']:>5} "
                           f"({'not known' if calls is None else f'{calls:g}'} per batch)   "
                           f"{_ms(part['seconds_per_batch'])} per batch   "
                           f"{_share(part['share_of_model'])} of the model time")
        else:
            out.append("watched parts: none (the model has no child modules and no parts were given)")
        out.append("")
        out.append("what stands out:")
        if n["stands_out"]:
            out.extend(f"  - {line}" for line in n["stands_out"])
        else:
            out.append("  nothing by the plain rules")
        return "\n".join(out)

    def close(self):
        """Takes every hook off the model and its parts again; the card's numbers stay readable."""
        for handle in self._handles:
            handle.remove()
        self._handles = []


class _TinyScorer(torch.nn.Module):
    """A small transformer scorer with three named parts, standing in for the real model in main()."""

    def __init__(self, fields=16, width=64):
        super().__init__()
        # One vector per field, so that the encoder has a short sequence to read.
        self.embed = torch.nn.Linear(1, width)
        layer = torch.nn.TransformerEncoderLayer(width, nhead=4, dim_feedforward=2 * width, batch_first=True)
        self.encoder = torch.nn.TransformerEncoder(layer, num_layers=2)
        self.head = torch.nn.Linear(width, 1)
        self.fields = fields

    def forward(self, x):
        """x [N, fields] to one score per row, [N]."""
        # x holds one number per field; each becomes a token, and the mean token is scored.
        tokens = self.embed(x.unsqueeze(-1))
        return self.head(self.encoder(tokens).mean(dim=1)).squeeze(-1)


def _slow_loader(batches, rows, fields, pause):
    """Made-up batches that each take `pause` seconds to arrive, like a loader that reads slowly."""
    for _ in range(batches):
        time.sleep(pause)
        yield torch.randn(rows, fields)


def main():
    """Builds a tiny model and a slow made-up loader, runs the card for 30 batches and prints it."""
    torch.manual_seed(0)
    model = _TinyScorer().eval()
    # The card is used as a context manager, so that its hooks come off also after an error.
    with SpeedCard(model) as card:
        for batch in _slow_loader(batches=40, rows=256, fields=model.fields, pause=0.02):
            card.batch_arrived(len(batch))
            with torch.no_grad():
                model(batch)
            card.batch_done()
            # Thirty batches are enough to read the card; the rest of the loader is not needed.
            if card.batches >= 30:
                break
        print(card.report())


if __name__ == "__main__":
    main()
