"""File inventory: what each raw file holds, and fresh blocks of unused files.

What this file does
-------------------
For each numbered raw file it counts the rows, the accounts, the frauds, the accounts with a
fraud, the months present and the frauds of the scored month. It prints that table, the
running totals over the files, and then splits the files into fresh blocks of a given size
(named choose, decide and confirm by default) and prints the list of file numbers of each
block with what the block holds. It reads only the id, account, time and label columns.

Why it exists
-------------
A comparison of two variants is only as sharp as the rows it is read on. Frauds come in runs
on one account, so the number that matters for the noise is the number of fraud accounts, not
the number of rows; a block with few fraud accounts cannot tell a small gain from chance. A
block that has already been used to choose between variants is also no longer a fair judge of
the variant it chose. The files hold whole accounts and no account is in two files, so files
that were never read are fresh accounts: a clean block for every decision. This tool says how
much each unused file holds (and whether it covers the scored month at all) and deals the
unused files into blocks, so each decision can be given a block of its own that is large
enough for the size of gain in question.

Where it goes
-------------
On the raw files, before any scoring: it plans which files are scored for choosing between
variants, which for the decision, and which are kept back to confirm. The lists it prints are
the values for CHOOSE_FILES and DECIDE_FILES in settings.py.

What to change for the pod
--------------------------
settings.py: EVAL_BASE (or pass --base), FILE_NAME, FILESYSTEM, ID_COL, ACCOUNT_COL, TIME_COL,
LABEL_COL, POSITIVE_LABEL, TARGET_START and TARGET_END. BLOCK_NAMES below; the block size and
the range of unused files are arguments.

How to try it
-------------
    python additions/reads/file_inventory.py --files 8301-10000 --block-size 100 --out inventory.parquet
or, from Python:
    table = inventory(settings.EVAL_BASE, range(8301, 8401))
    blocks = split_blocks(usable_files(table), block_size=25)
    print(block_summary(table, blocks))
The tests are in additions/tests/test_reads_file_inventory.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd
import pyarrow as pa

from additions import settings
from additions.common import tables
from additions.common.timekeys import MISSING_SECOND
from additions.reads import _cli, _rows

# The names of the blocks, in the order in which they are filled: one block to choose between
# variants, one to decide, one to confirm the decision. More names give more blocks.
BLOCK_NAMES = ("choose", "decide", "confirm")


def file_line(df, number, id_col=None, account_col=None, time_col=None, label_col=None, positive_label=None,
              start=None, end=None):
    """The inventory line of one file, as a dict.

    df       the id, account, time and label columns of the file
    number   the file number

    Keys: file, rows, repeated_ids (rows whose id occurs earlier in the file; 0 without an id
    column), accounts, frauds, fraud_accounts, months (the calendar months that occur, as text
    such as "2025-05 2025-06"), scored_rows, scored_frauds and scored_fraud_accounts (the same
    counts inside the scored month). Only the account column is needed; a missing time or
    label column leaves its counts at zero.
    """
    id_col = settings.ID_COL if id_col is None else id_col
    time_col = settings.TIME_COL if time_col is None else time_col
    label_col = settings.LABEL_COL if label_col is None else label_col
    account = df[settings.ACCOUNT_COL if account_col is None else account_col]
    # A file without a time or a label column is still counted: it then shows no month and no
    # fraud (the reader has already said which column is missing).
    secs = _rows.row_seconds(df, time_col) if time_col in df.columns else np.full(len(df), MISSING_SECOND)
    fraud = _rows.fraud_flags(df, label_col, positive_label) > 0 if label_col in df.columns else np.zeros(len(df), bool)
    low, high = _rows.scored_window(start, end)
    scored = (secs >= low) & (secs < high)
    months = np.unique(secs[secs != MISSING_SECOND].astype("datetime64[s]").astype("datetime64[M]"))
    return {
        "file": int(number), "rows": len(df),
        "repeated_ids": int(df[id_col].duplicated().sum()) if id_col in df.columns else 0,
        "accounts": int(account.nunique()), "frauds": int(fraud.sum()),
        "fraud_accounts": int(account[fraud].nunique()), "months": " ".join(months.astype(str)),
        "scored_rows": int(scored.sum()), "scored_frauds": int((fraud & scored).sum()),
        "scored_fraud_accounts": int(account[fraud & scored].nunique()),
    }


def inventory(base=None, numbers=(), check_accounts=False, id_col=None, account_col=None, time_col=None,
              label_col=None, positive_label=None, start=None, end=None, filesystem=None, file_name=None):
    """One line per file: rows, accounts, frauds, fraud accounts, months present, scored-month frauds.

    base             folder of the numbered files (default: settings.EVAL_BASE)
    numbers          the file numbers to look at
    check_accounts   also count, per file, the accounts that were already seen in an earlier
                     file of the list (column `accounts_seen_before`). The files are meant to
                     share no account; this shows whether that holds. It keeps every account id
                     in memory, so it is best used on a few hundred files at a time.

    Returns a DataFrame with the columns of `file_line`. A file that cannot be read is reported
    with one printed line and left out; the inventory goes on.

    The files are read one after the other, in a plain loop, because each is a separate read
    and only one file is then in memory at a time. Only four columns are read.
    """
    base = settings.EVAL_BASE if base is None else base
    account_col = settings.ACCOUNT_COL if account_col is None else account_col
    # The only four columns that are read: id, account, time and label.
    wanted = [
        settings.ID_COL if id_col is None else id_col,
        account_col,
        settings.TIME_COL if time_col is None else time_col,
        settings.LABEL_COL if label_col is None else label_col,
    ]
    seen = set()
    lines = []
    for number in numbers:
        try:
            df = tables.read_columns(tables.file_path(base, number, file_name), wanted, filesystem, quiet=bool(lines))
        except (OSError, pa.ArrowException) as problem:
            print(f"file {number}: could not be read ({problem}); it is left out")
            continue
        line = file_line(df, number, id_col, account_col, time_col, label_col, positive_label, start, end)
        if check_accounts:
            accounts = set(df[account_col].unique())
            line["accounts_seen_before"] = len(accounts & seen)
            seen |= accounts
        lines.append(line)
    return pd.DataFrame(lines)


def cumulative(table):
    """Running totals of the inventory over the files, in the order of the table.

    table   what `inventory` returned

    Returns a DataFrame: file, files, rows, accounts, frauds, fraud_accounts, scored_frauds and
    scored_fraud_accounts, each summed up to and including that file. The account totals are
    plain sums, which is right as long as no account is in two files.
    """
    if len(table) == 0:
        return pd.DataFrame()
    columns = ["rows", "accounts", "frauds", "fraud_accounts", "scored_frauds", "scored_fraud_accounts"]
    out = table[columns].cumsum()
    out.insert(0, "files", np.arange(1, len(table) + 1))
    out.insert(0, "file", table["file"].to_numpy())
    return out


def usable_files(table):
    """The file numbers of the inventory that hold rows of the scored month.

    table   what `inventory` returned

    Returns a list of file numbers in the order of the table. A file without rows of the
    scored month cannot be ranked, so it is kept out of the blocks.
    """
    if len(table) == 0:
        return []
    return [int(n) for n in table.loc[table["scored_rows"] > 0, "file"]]


def split_blocks(numbers, block_size, names=None, seed=None):
    """Deal unused file numbers into fresh blocks of `block_size` files.

    numbers      the unused file numbers
    block_size   files per block
    names        the names of the blocks, filled in this order (default: BLOCK_NAMES)
    seed         None takes the files in the order given, so each block is a stretch of
                 neighbouring files. A whole number shuffles the files first with that seed,
                 which spreads every block over the whole range; use it when neighbouring files
                 could be alike.

    Returns a dict from block name to its sorted list of file numbers, plus the key "left over"
    for the files that fit in no block. When there are too few files, the later blocks are
    short or empty; nothing stops. No file is in two blocks.
    """
    names = BLOCK_NAMES if names is None else names
    numbers = [int(n) for n in numbers]
    if seed is not None:
        numbers = [numbers[i] for i in np.random.default_rng(seed).permutation(len(numbers))]
    size = max(int(block_size), 0)
    # The list is cut into consecutive pieces, so a file can only fall into one block.
    blocks = {name: sorted(numbers[i * size:(i + 1) * size]) for i, name in enumerate(names)}
    blocks["left over"] = sorted(numbers[len(names) * size:])
    return blocks


def block_summary(table, blocks):
    """What each block holds, summed from the inventory lines of its files.

    table    what `inventory` returned
    blocks   what `split_blocks` returned: a dict from block name to file numbers

    Returns a DataFrame with one line per block: block, files, rows, accounts, frauds,
    fraud_accounts, scored_frauds, scored_fraud_accounts. The last column is the one to look
    at when judging whether a block is large enough: it counts the independent fraud stories.
    """
    columns = ["rows", "accounts", "frauds", "fraud_accounts", "scored_frauds", "scored_fraud_accounts"]
    lines = []
    for name, numbers in blocks.items():
        part = table[table["file"].isin(numbers)] if len(table) else table
        line = {"block": name, "files": len(numbers)}
        line.update({column: int(part[column].sum()) if len(part) else 0 for column in columns})
        lines.append(line)
    return pd.DataFrame(lines)


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(
        description="Inventory of raw files and a split of unused files into fresh blocks.")
    parser.add_argument("--base", default=None, help="folder of the numbered raw files (default: settings.EVAL_BASE)")
    parser.add_argument("--files", required=True, help='the unused file numbers, for example "8301-10000"')
    parser.add_argument("--block-size", type=int, default=100, help="files per block (default: 100)")
    parser.add_argument("--block-names", nargs="*", default=None,
                        help="names of the blocks (default: choose decide confirm)")
    parser.add_argument("--seed", type=int, default=None,
                        help="shuffle the files with this seed before dealing them into blocks")
    parser.add_argument("--check-accounts", action="store_true", help="count accounts that occur in more than one file")
    parser.add_argument("--start", default=None, help="first day of the scored month (default: settings.TARGET_START)")
    parser.add_argument("--end", default=None, help="first day after the scored month (default: settings.TARGET_END)")
    parser.add_argument("--out", default=None,
                        help="write the per-file table, with the block of each file, to this parquet file")
    args = parser.parse_args(argv)

    table = inventory(args.base, _cli.file_numbers(args.files), args.check_accounts, start=args.start, end=args.end)
    if len(table) == 0:
        print("no file could be read; check --base, --files and FILE_NAME in settings.py")
        return
    _cli.show("Inventory by file", table)
    _cli.show("Running totals", cumulative(table))
    usable = usable_files(table)
    if len(usable) < len(table):
        print(f"\n{len(table) - len(usable)} file(s) hold no row of the scored month and are kept out of the blocks")
    blocks = split_blocks(usable, args.block_size, args.block_names or None, args.seed)
    _cli.show("What each block holds", block_summary(table, blocks))
    print()
    for name, numbers in blocks.items():
        print(f"{name}: {len(numbers)} files: {_cli.number_ranges(numbers) or '(none)'}")
    if args.out:
        block_of = {number: name for name, numbers in blocks.items() for number in numbers}
        out = table.copy()
        out["block"] = [block_of.get(int(number), "not used") for number in out["file"]]
        _cli.save(out, args.out)


if __name__ == "__main__":
    main()
