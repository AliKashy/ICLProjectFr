"""Capture on the rows the benchmark keeps, and where the alert budget goes.

What this file does
-------------------
It reads capture at the alert cut three ways: on all rows of the scored month, on the eligible
rows only (the rows the benchmark population keeps), and on the eligible rows with the row
types that can never carry a fraud label moved to the bottom of the ranking. It then prints
the alert budget: of the alerted rows, how many are of each row type, fall on each day and
belong to each segment, and how much capture those places would have brought had they gone to
the next rows in line.

Why it exists
-------------
The alert budget is a fixed small share of rows. A fraud label sits only on approved rows, so
declined attempts are never labelled, and neither are advice rows or zero-dollar checks. A
declined attempt often sits inside a fraud run and looks like fraud, so a model can rank it
high; every alert it takes is a place that can never count as a caught fraud. The benchmark
population also drops some rows altogether: rows declined before the fraud engine saw them,
and an excluded segment. A capture figure read on all rows and one read on the benchmark's rows
are figures on two populations and cannot be set side by side. This tool puts the three reads
next to each other and shows which rows take the places, so the model's capture can be stated
on the benchmark's population, and the share of the budget spent on rows that can never count
is known before any training is changed.

Where it goes
-------------
After scoring (scores), before any comparison with another model. It needs a prediction file
and, for the row types and the segment, raw columns joined by transaction id from the raw
files. The same eligible-row rule can later serve as a mask on the loss (in the original code
the loss is computed in `FTTransformerHierModel._step`), but nothing here changes training.
The outcome of a row is used only to sort rows into groups after scoring, never as an input.

What to change for the pod
--------------------------
settings.py: DECLINE_FLAG_COL and DECLINE_FLAG_VALUES (the benchmark's decline rule),
SEGMENT_COL and EXCLUDED_SEGMENTS (the segment the benchmark leaves out; the text must match
the data exactly), ADVICE_COL, TYPE_COL, ZERO_CHECK_TYPES, REASON_COL and the three lists of
response codes, TARGET_START, TARGET_END and OUTSORT_PER_MILLE. Whether the benchmark also
drops advice rows and zero-dollar checks is a fact about the benchmark: pass --drop-advice and
--drop-zero-checks to match it.

How to try it
-------------
    python additions/reads/eligible_rows.py --pred predictions.parquet --raw-base /path/to/files --raw-files 8228-8243
or, from Python:
    df = _rows.join_raw_columns(_rows.load_predictions(path), _rows.descriptor_columns(), base, numbers)
    print(three_reads(df))
    print(budget_table(df, by="row_type"))
The tests are in additions/tests/test_reads_eligible_rows.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd

from additions import settings
from additions.common import ranking
from additions.common.timekeys import MISSING_SECOND
from additions.reads import _cli, _rows


def eligible_mask(df, drop_declined=True, drop_advice=False, drop_zero_checks=False, excluded_segments=None,
                  decline_flag_col=None, decline_flag_values=None, advice_col=None, type_col=None,
                  zero_check_types=None, segment_col=None):
    """Yes/no per row: does the benchmark population keep the row?

    drop_declined       leave out rows declined before the fraud engine saw them (the decline flag)
    drop_advice         leave out advice rows
    drop_zero_checks    leave out zero-dollar checks
    excluded_segments   segment values that are left out (default: settings.EXCLUDED_SEGMENTS)

    A row that is not eligible is only taken out of the ranking. It stays in the table, so it
    still serves as history for the rows after it. When a column a rule needs is not available,
    that rule is skipped with one printed line and drops nothing. To mirror a benchmark whose
    rule is written on response codes instead of a flag, build the mask from `_rows.row_type`.
    """
    keep = np.ones(len(df), dtype=bool)
    if drop_declined:
        flagged = _rows.has_decline_flag(df, decline_flag_col, decline_flag_values)
        if flagged is not None:
            keep &= ~flagged
    if drop_advice:
        advice = _rows.is_advice(df, advice_col)
        if advice is not None:
            keep &= ~advice
    if drop_zero_checks:
        zero_check = _rows.is_zero_check(df, type_col, zero_check_types)
        if zero_check is not None:
            keep &= ~zero_check
    excluded = settings.EXCLUDED_SEGMENTS if excluded_segments is None else excluded_segments
    if len(excluded):
        segment = _rows.optional_column(df, settings.SEGMENT_COL if segment_col is None else segment_col, "the segment")
        if segment is not None:
            keep &= ~_rows.has_code(segment, excluded)
    return keep


def force_to_bottom(score_values, rows):
    """A copy of the scores in which the marked rows rank below every other row.

    score_values   one score per row
    rows           yes/no per row: the rows to send to the bottom

    The marked rows all get the same value, one below the lowest score, so they tie with each
    other at the very end. This is the rule "never alert a row that cannot be fraud", applied
    after scoring. The input is not changed.
    """
    out = np.array(score_values, dtype=np.float64)
    rows = np.asarray(rows, dtype=bool)
    if rows.any():
        finite = out[np.isfinite(out)]
        out[rows] = (finite.min() if len(finite) else 0.0) - 1.0
    return out


def three_reads(df, scored=None, eligible=None, row_types=None, time_col=None, label_col=None, positive_label=None,
                score_col=None, amount_col=None, per_mille=None, rounding=None):
    """Capture at the alert cut on three populations, one line each.

    scored      yes/no per row: the rows that are ranked (default: the scored month in settings)
    eligible    yes/no per row: the rows the benchmark keeps (default: `eligible_mask(df)`)
    row_types   the row type of every row (default: `_rows.row_type(df)`)

    The three lines are:
      all scored rows                             every row of the scored month competes for the alerts
      eligible rows                               only the benchmark's rows compete
      eligible rows, never-labelled types last    as before, and the eligible rows that can never carry
                                                  a label (advice, zero-dollar checks, declines that the
                                                  benchmark keeps) are ranked below all other rows

    Returns a DataFrame with the columns of `_rows.capture_line` plus `never_labelled_alerts`,
    the number of alerts that fall on rows of a never-labelled type. The gap between the first
    and the second line is a difference of population, not of model. The gap between the second
    and the third is what a "do not alert these rows" rule is worth.
    """
    scored = _rows.in_scored_month(df, time_col) if scored is None else np.asarray(scored, dtype=bool)
    eligible = eligible_mask(df) if eligible is None else np.asarray(eligible, dtype=bool)
    row_types = _rows.row_type(df) if row_types is None else np.asarray(row_types)
    y = _rows.fraud_flags(df, label_col, positive_label)
    s = _rows.scores(df, score_col)
    a = _rows.amounts(df, amount_col)
    never = np.isin(row_types, _rows.NEVER_LABELLED)
    reads = [
        ("all scored rows", scored, s),
        ("eligible rows", scored & eligible, s),
        ("eligible rows, never-labelled types last", scored & eligible, force_to_bottom(s, never)),
    ]
    lines = []
    for name, rows, values in reads:
        # Each read ranks its own population, so the cut is the budgeted share of that
        # population: when fewer rows compete, fewer alerts are handed out.
        line = _rows.capture_line(name, y[rows], values[rows], None if a is None else a[rows], per_mille, rounding)
        alerted = ranking.alert_mask(values[rows], per_mille, rounding)
        line["never_labelled_alerts"] = int((alerted & never[rows]).sum())
        lines.append(line)
    return pd.DataFrame(lines)


def _next_caught(labels_below, allowed, places):
    """Frauds among the first `places` allowed rows below the cut.

    `labels_below` and `allowed` are in ranking order, best first, and start just under the
    cut. The first `places` rows that are allowed are the rows that would have been alerted if
    a group had given up its places. Only as much of the ranking as is needed is scanned.
    """
    head = min(len(allowed), 4 * places + 1000)
    while True:
        filled = np.cumsum(allowed[:head])
        if head >= len(allowed) or (len(filled) and filled[-1] >= places):
            break
        head = min(len(allowed), head * 2)
    stop = min(int(np.searchsorted(filled, places, side="left")) + 1, head)   # rows 0 .. stop-1 fill the places
    return int((labels_below[:stop] * allowed[:stop]).sum())


def budget_table(df, by="row_type", scored=None, row_types=None, label_col=None, positive_label=None,
                 score_col=None, time_col=None, segment_col=None, per_mille=None, rounding=None):
    """Who takes the alerts: counts and shares by group, and what the places would have caught.

    by         "row_type", "day" (calendar day of the row), "segment", or the name of any column of `df`
    scored     yes/no per row: the population whose budget is audited (default: the scored month).
               Pass `scored & eligible_mask(df)` to audit the eligible rows.
    row_types  the row type of every row, used when by="row_type" (default: `_rows.row_type(df)`)

    Returns a DataFrame with one row per group:
      rows, row_share        size of the group in the population
      alerts, alert_share    alerted rows of the group, and their share of all alerts
      frauds, caught         frauds in the group, and those of them that are alerted
      next_caught            frauds among the rows just below the cut that would have taken the
                             group's places (rows of the same group cannot take them)
      lost_udr               next_caught as a share of all frauds: the capture given up by
                             spending these places on this group

    For a group that can never carry a label, `caught` is zero and `lost_udr` is the capture
    that a rule "never alert this group" would add. For any other group, compare caught / frauds
    of the population with lost_udr to see whether its places are well spent. The alerted set is
    the definite one of `ranking.alert_mask` (ties at the cut go to the earlier row).
    """
    scored = _rows.in_scored_month(df, time_col) if scored is None else np.asarray(scored, dtype=bool)
    if by == "row_type":
        groups = _rows.row_type(df) if row_types is None else np.asarray(row_types)
    elif by == "day":
        secs = _rows.row_seconds(df, time_col)
        days = np.where(secs == MISSING_SECOND, 0, secs) // 86_400
        groups = np.where(secs == MISSING_SECOND, "no time", days.astype("datetime64[D]").astype(str))
    else:
        name = (settings.SEGMENT_COL if segment_col is None else segment_col) if by == "segment" else by
        column = _rows.optional_column(df, name, f"the split by {by}")
        if column is None:
            return pd.DataFrame()
        groups = column.to_numpy()
    y = _rows.fraud_flags(df, label_col, positive_label)[scored]
    s = _rows.scores(df, score_col)[scored]
    names, codes = np.unique(np.asarray(groups)[scored].astype(str), return_inverse=True)
    n_groups = len(names)
    alerted = ranking.alert_mask(s, per_mille, rounding)
    k = int(alerted.sum())
    # The same stable order that the alert mask uses: the rows after position k are "next in line".
    below = np.argsort(-s, kind="stable")[k:]
    labels_below, codes_below = y[below], codes[below]
    rows = np.bincount(codes, minlength=n_groups)
    alerts = np.bincount(codes[alerted], minlength=n_groups)
    frauds = np.bincount(codes, weights=y, minlength=n_groups).astype(np.int64)
    caught = np.bincount(codes[alerted], weights=y[alerted], minlength=n_groups).astype(np.int64)
    next_caught = np.zeros(n_groups, dtype=np.int64)
    # One pass per group that holds alerts. The loop is over group values (a handful of row
    # types, the days of a month, a few segments), never over rows.
    for g in np.flatnonzero(alerts):
        next_caught[g] = _next_caught(labels_below, codes_below != g, int(alerts[g]))
    total = float(y.sum())
    table = pd.DataFrame({
        by: names, "rows": rows, "row_share": rows / max(len(s), 1),
        "alerts": alerts, "alert_share": alerts / max(k, 1),
        "frauds": frauds, "caught": caught, "next_caught": next_caught,
        "lost_udr": next_caught / total if total > 0 else np.nan,
    })
    if by == "row_type":
        # Show the types in the order in which they are tested instead of by alphabet.
        rank = {name: i for i, name in enumerate(_rows.ROW_TYPES)}
        table = table.sort_values(by, key=lambda col: col.map(rank)).reset_index(drop=True)
    return table


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(
        description="Capture on eligible rows, and the alert budget by row type, day and segment.")
    parser.add_argument("--pred", required=True, help="prediction file (parquet)")
    _cli.add_raw_arguments(parser)
    _cli.add_score_arguments(parser)
    parser.add_argument("--keep-declined", action="store_true",
                        help="keep rows declined before the fraud engine among the eligible rows")
    parser.add_argument("--drop-advice", action="store_true", help="leave advice rows out of the eligible rows")
    parser.add_argument("--drop-zero-checks", action="store_true",
                        help="leave zero-dollar checks out of the eligible rows")
    parser.add_argument("--excluded-segments", nargs="*", default=None,
                        help="segment values the benchmark leaves out (default: settings.EXCLUDED_SEGMENTS)")
    parser.add_argument("--budget-on", choices=("all", "eligible"), default="all",
                        help="population whose alert budget is printed: all scored rows or the eligible rows")
    parser.add_argument("--out", default=None,
                        help="write id, row type and eligible flag of the scored rows to this parquet file")
    args = parser.parse_args(argv)

    wanted = _rows.descriptor_columns()
    df = _rows.load_predictions(args.pred, wanted, score_col=args.score_col)
    df = _rows.join_raw_columns(df, wanted, args.raw_base, _cli.file_numbers(args.raw_files))
    scored = _cli.scored_rows(df, args)
    if _cli.nothing_to_rank(scored):
        return
    types = _rows.row_type(df)
    eligible = eligible_mask(df, not args.keep_declined, args.drop_advice, args.drop_zero_checks,
                             args.excluded_segments)

    reads = three_reads(df, scored, eligible, types, score_col=args.score_col, per_mille=args.per_mille)
    _cli.show("Capture at the alert cut on three populations", reads)
    never = np.isin(types, _rows.NEVER_LABELLED)
    stray = int(_rows.fraud_flags(df)[scored & never].sum())
    if stray:
        # Not an error: it says that the code lists in settings.py do not describe this data yet.
        print(f"note: {stray} frauds of the scored month sit on row types treated as never labelled; "
              "check the code lists in settings.py")

    audited = scored & eligible if args.budget_on == "eligible" else scored
    label = "eligible rows" if args.budget_on == "eligible" else "all scored rows"
    for by in ("row_type", "day", "segment"):
        table = budget_table(df, by, audited, types, score_col=args.score_col, per_mille=args.per_mille)
        if len(table):
            _cli.show(f"Alert budget by {by} ({label})", table)
    if args.out:
        out = pd.DataFrame({settings.ID_COL: df[settings.ID_COL].to_numpy()[scored],
                            "row_type": types[scored], "eligible": eligible[scored]})
        _cli.save(out, args.out)


if __name__ == "__main__":
    main()
