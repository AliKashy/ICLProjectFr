"""Command-line pieces shared by the tools of this folder.

What this file does
-------------------
It holds the few things every runnable tool of this folder needs: turning text such as
"8228-8243,8250" into a list of file numbers and back, the arguments that say how a prediction
file is read (score column, score kind, scored month, alert budget), the choice of the rows
that are ranked, printing a table as plain text, and writing a table to a parquet file.

Why it exists
-------------
The tools answer different questions but are driven the same way. With the shared arguments in
one place, a flag such as --all-rows or --per-mille means the same in every tool, and a change
to how tables are printed is made once. It carries no fraud logic of its own.

Where it goes
-------------
Only inside the `main` function of each tool in this folder, after scoring. The functions of
the tools themselves do not use it, so they can be called from a notebook or from other code
without any command line.

What to change for the pod
--------------------------
Nothing in most cases. The defaults of the arguments are read from settings.py when a tool
runs (SCORE_COL, SCORE_KIND, TARGET_START, TARGET_END, OUTSORT_PER_MILLE, EVAL_BASE), so
editing settings.py changes every tool at once. Add an argument here when all tools should
have it.

How to try it
-------------
    parser = argparse.ArgumentParser()
    add_score_arguments(parser)
    args = parser.parse_args(["--per-mille", "10", "--all-rows"])
    show("a title", pandas.DataFrame({"g": [0.0, 0.5], "udr": [0.61234, 0.6]}))
The tests are in additions/tests/test_reads_cli.py.
"""
import numpy as np
import pandas as pd

from additions.common import tables
from additions.reads import _rows


def file_numbers(text):
    """Turn text such as "1-10,25,40-42" into the list [1, ..., 10, 25, 40, 41, 42].

    Ranges include both ends. Blanks are ignored. None or empty text gives an empty list.
    """
    numbers = []
    for part in str(text or "").replace(" ", "").split(","):
        if not part:
            continue
        if "-" in part:
            first, last = part.split("-", 1)
            numbers.extend(range(int(first), int(last) + 1))
        else:
            numbers.append(int(part))
    return numbers


def number_ranges(numbers):
    """The reverse of `file_numbers`: [1, 2, 3, 7, 9, 10] becomes the text "1-3,7,9-10".

    The numbers are sorted first, so the text names the same files whatever their order was.
    """
    parts = []
    run = []                                   # the stretch of neighbouring numbers being collected
    for number in sorted(int(n) for n in numbers):
        if run and number == run[-1] + 1:
            run.append(number)
            continue
        if run:
            parts.append(str(run[0]) if len(run) == 1 else f"{run[0]}-{run[-1]}")
        run = [number]
    if run:
        parts.append(str(run[0]) if len(run) == 1 else f"{run[0]}-{run[-1]}")
    return ",".join(parts)


def add_score_arguments(parser):
    """Add the arguments that say how a prediction file is read and ranked.

    Every default is None, which means "use the value in settings.py"; the functions of the
    tools resolve it when they run.
    """
    parser.add_argument("--score-col", default=None, help="name of the score column (default: settings.SCORE_COL)")
    parser.add_argument("--score-kind", default=None, choices=("probability", "logit"),
                        help="what the score column holds (default: settings.SCORE_KIND)")
    parser.add_argument("--start", default=None, help="first day of the scored month (default: settings.TARGET_START)")
    parser.add_argument("--end", default=None, help="first day after the scored month (default: settings.TARGET_END)")
    parser.add_argument("--all-rows", action="store_true",
                        help="rank every row of the file instead of the rows of the scored month")
    parser.add_argument("--per-mille", type=int, default=None,
                        help="alert budget in rows per thousand (default: settings.OUTSORT_PER_MILLE)")
    return parser


def add_raw_arguments(parser):
    """Add the arguments that name the raw files from which extra columns are joined by id."""
    parser.add_argument("--raw-base", default=None,
                        help="folder of the numbered raw files (default: settings.EVAL_BASE)")
    parser.add_argument("--raw-files", default=None, help='raw file numbers, for example "8228-8243" or "1-10,25"')
    return parser


def scored_rows(df, args, time_col=None):
    """The yes/no array of the rows that are ranked, as the command line asked for it.

    With --all-rows every row is ranked. Otherwise only the rows of the scored month are, and
    the remaining rows stay in the table as history.
    """
    if args.all_rows:
        return np.ones(len(df), dtype=bool)
    return _rows.in_scored_month(df, time_col, args.start, args.end)


def nothing_to_rank(scored):
    """True, with one printed line, when no row is left to rank."""
    if np.asarray(scored).any():
        return False
    print("no row falls in the scored month; set TARGET_START and TARGET_END in settings.py, "
          "or pass --start and --end, or pass --all-rows")
    return True


def show(title, table, digits=4):
    """Print a title and a table as plain text.

    `table` is a DataFrame or a list of dicts. Decimal numbers are printed with `digits`
    decimals and missing numbers as a dash, so the output can be pasted into a note as is.
    """
    frame = table if isinstance(table, pd.DataFrame) else pd.DataFrame(table)
    print()
    print(title)
    if len(frame) == 0:
        print("  (no rows)")
        return
    print(frame.to_string(index=False, na_rep="-", float_format=lambda value: f"{value:.{digits}f}"))


def save(table, path, filesystem=None):
    """Write a table to a parquet file (an existing file is replaced) and print where it went."""
    tables.write_table(table, path, filesystem)
    print(f"wrote {len(table)} row(s) to {path}")
    return path
