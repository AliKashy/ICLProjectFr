"""Run census: how frauds cluster on accounts, how they are caught, and how labels arrive.

What this file does
-------------------
It groups the frauds of each account into runs: a run is a stretch of the account's frauds in
which the gap between one fraud and the next is at most G (7 days by default). For every fraud
it records its position in its run, the seconds since the account's previous fraud, and
whether it is inside the alert cut. From that it prints five tables: capture of first frauds
against follow-on frauds; the share of frauds by the gap to the previous fraud; the
distribution of run sizes; the share of frauds whose previous fraud is more than 30 days old;
and the fraud rate by calendar day.

Why it exists
-------------
Frauds come in runs on one account, so most frauds follow an earlier fraud of that account.
The capture measure counts every fraud, so a model can score well by staying on runs it has
found, or badly by finding runs late, and one capture figure does not say which. The first
table separates the two skills: finding a run (first frauds) and following it (follow-ons).
The gap and run-size tables say how much of the measure sits in long runs. Fraud labels arrive
weeks after the transaction, so the label of a fraud can only help with a later fraud of the
same account when the gap between them is long; the fourth table counts how often that is, and
so bounds what any use of earlier labels could add. The last table watches the labels
themselves: a fraud rate that falls through the last weeks of the data suggests labels that
have not all arrived, and rows from those weeks would then be read as cleaner than they are.

Where it goes
-------------
On raw files or on scores, before design decisions: it is a read that sizes ideas (a memory of
the model's own alerts, the use of matured labels, weights by recency). It needs account, time
and label; with a score column it also gives capture. Everything it computes from labels is
for measurement only. A fraud's position in its run and the time since the previous fraud are
known only in hindsight, so none of these columns may become a model input.

What to change for the pod
--------------------------
settings.py: ACCOUNT_COL, TIME_COL, LABEL_COL, POSITIVE_LABEL, ID_COL, SCORE_COL, SCORE_KIND,
TARGET_START, TARGET_END, OUTSORT_PER_MILLE, and EVAL_BASE or TRAIN_BASE when raw files are
read. RUN_GAP, the gap buckets, the run-size buckets and OLD_GAP below.

How to try it
-------------
    python additions/reads/run_census.py --pred predictions.parquet
    python additions/reads/run_census.py --base /path/to/files --files 8228-8243     # labels only
or, from Python:
    runs = fraud_runs(df)
    print(first_and_follow_on(runs)); print(gap_table(runs)); print(run_sizes(runs))
The tests are in additions/tests/test_reads_run_census.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd

from additions import settings
from additions.common import tables, timekeys
from additions.common.history import EarlierRows
from additions.common.timekeys import MISSING_SECOND
from additions.reads import _cli, _rows

# Two frauds of one account belong to the same run when at most this many seconds lie between them.
RUN_GAP = 7 * 86_400

# The split of the time since the account's previous fraud (seconds), and the names of the parts.
GAP_EDGES = (3_600, 86_400, 7 * 86_400, 30 * 86_400)
GAP_LABELS = ("under 1 hour", "1 to 24 hours", "1 to 7 days", "7 to 30 days", "over 30 days")

# The split of the run sizes (number of frauds in a run).
SIZE_EDGES = (2, 3, 5, 10)
SIZE_LABELS = ("1", "2", "3 to 4", "5 to 9", "10 or more")

# A previous fraud older than this could have had its label by the time of the next fraud.
OLD_GAP = 30 * 86_400


def fraud_runs(df, run_gap=None, scored=None, id_col=None, account_col=None, time_col=None, label_col=None,
               positive_label=None, score_col=None, score_kind=None, per_mille=None, rounding=None):
    """One line per fraud: its run, its place in the run, the time since the previous fraud.

    df        rows with account, time and label; a score column is optional. All rows of the
              files should be given, not only the scored month, so that a run that began earlier
              is seen whole.
    run_gap   the largest gap, in seconds, between two frauds of one run (default: RUN_GAP)
    scored    yes/no per row: the rows that are ranked (default: the scored month in settings)

    Returns a DataFrame with the columns:
      id, account               as in `df` (the id only when `df` has it)
      second                    whole second of the fraud
      scored                    whether the fraud lies in the ranked rows
      run                       a number shared by the frauds of one run
      position                  1 for the first fraud of a run, 2 for the next, and so on
      run_size                  frauds in the run, as far as the file shows them
      seconds_since_previous    seconds since the account's previous fraud; NaN when there is none
      inside_cut                1.0 when the fraud is inside the alert cut, 0.0 when not; NaN without a score

    Time rule: the previous fraud is the latest fraud of the account in a strictly earlier
    second. Frauds of one account in the same second cannot be put in order, so they share one
    position and one gap. Fraud rows without a time are left out with one printed line.
    """
    run_gap = RUN_GAP if run_gap is None else run_gap
    id_col = settings.ID_COL if id_col is None else id_col
    account_col = settings.ACCOUNT_COL if account_col is None else account_col
    score_col = settings.SCORE_COL if score_col is None else score_col
    scored = _rows.in_scored_month(df, time_col) if scored is None else np.asarray(scored, dtype=bool)
    keys = _rows.account_codes(df, account_col)
    secs = _rows.row_seconds(df, time_col)
    fraud = _rows.fraud_flags(df, label_col, positive_label) > 0
    no_time = fraud & (secs == MISSING_SECOND)
    if no_time.any():
        print(f"note: {int(no_time.sum())} fraud rows have no time and are left out")
    f = np.flatnonzero(fraud & ~no_time)
    keys_f, secs_f = keys[f], secs[f]
    # Within the fraud rows alone, the "previous fraud" of a fraud is simply its latest earlier row.
    since = EarlierRows(keys_f, secs_f).seconds_since_last()
    opens_run = np.isnan(since) | (since > run_gap)
    # Number the runs along the account-and-time order. Frauds of one second share their gap,
    # so they open a run together or continue one together; only the first of them adds a run.
    order = timekeys.stable_order(keys_f, secs_f)
    k, t = keys_f[order], secs_f[order]
    first_of_second = np.ones(len(order), dtype=bool)
    first_of_second[1:] = (k[1:] != k[:-1]) | (t[1:] != t[:-1])
    run = np.empty(len(order), dtype=np.int64)
    run[order] = np.cumsum(first_of_second & opens_run[order]) - 1
    # Position: the frauds of the same run in strictly earlier seconds, plus one.
    position = EarlierRows(run, secs_f).count() + 1
    out = pd.DataFrame({
        "account": df[account_col].to_numpy()[f], "second": secs_f, "scored": scored[f], "run": run,
        "position": position, "run_size": np.bincount(run, minlength=1)[run] if len(run) else run,
        "seconds_since_previous": since, "inside_cut": np.nan,
    })
    if id_col in df.columns:
        out.insert(0, "id", df[id_col].to_numpy()[f])
    if score_col in df.columns and scored.any():
        s = _rows.logits(df, score_col, score_kind)
        out["inside_cut"] = (s[f] >= _rows.cut_threshold(s[scored], per_mille, rounding)).astype(np.float64)
    else:
        print("note: no score column (or no ranked row); the capture columns are left empty")
    return out


def _capture_lines(runs, names, order):
    """Frauds, their share, and capture for each named part of the scored frauds.

    `names` gives the part of every fraud line and `order` the parts to report. Capture is the
    share of a part's frauds that are inside the alert cut; it is empty without a score.
    """
    part = runs[runs["scored"].to_numpy()]
    names = np.asarray(names, dtype=object)[runs["scored"].to_numpy()]
    lines = []
    for name in order:
        rows = part[names == name]
        lines.append({"part": name, "frauds": len(rows), "share_of_frauds": len(rows) / max(len(part), 1),
                      "caught": rows["inside_cut"].sum(min_count=1), "capture": rows["inside_cut"].mean()})
    lines.append({"part": "all", "frauds": len(part), "share_of_frauds": 1.0 if len(part) else np.nan,
                  "caught": part["inside_cut"].sum(min_count=1), "capture": part["inside_cut"].mean()})
    return pd.DataFrame(lines)


def first_and_follow_on(runs):
    """Capture of the first fraud of each run against the frauds that follow it.

    runs   what `fraud_runs` returned

    Returns a DataFrame with the lines "first of its run", "follow-on" and "all", and the columns
    part, frauds, share_of_frauds, caught, capture. Only frauds of the ranked rows are counted.
    The first line measures how well runs are found, the second how well they are followed.
    """
    names = np.where(runs["position"].to_numpy() == 1, "first of its run", "follow-on")
    return _capture_lines(runs, names, ("first of its run", "follow-on"))


def gap_table(runs):
    """Share of the ranked frauds, and their capture, by the time since the account's previous fraud.

    runs   what `fraud_runs` returned

    Returns a DataFrame with one line per gap bucket ("no earlier fraud" first, "all" last) and
    the columns part, frauds, share_of_frauds, caught, capture.
    """
    names = _rows.bucket(runs["seconds_since_previous"].to_numpy(), GAP_EDGES, GAP_LABELS, missing="no earlier fraud")
    return _capture_lines(runs, names, ("no earlier fraud",) + GAP_LABELS)


def run_sizes(runs):
    """How many runs have 1, 2, 3 to 4, ... frauds, and the share of all frauds they hold.

    runs   what `fraud_runs` returned

    Returns a DataFrame with one line per size bucket: run_size, runs, share_of_runs, frauds,
    share_of_frauds. Every run of the file is counted, also those before the scored month. A
    run that is cut by the first or the last day of the file is counted at the size the file
    shows.
    """
    size = runs.groupby("run")["run_size"].first().to_numpy()
    names = _rows.bucket(size, SIZE_EDGES, SIZE_LABELS)
    lines = []
    for name in SIZE_LABELS:
        frauds = int(size[names == name].sum())
        lines.append({"run_size": name, "runs": int((names == name).sum()),
                      "share_of_runs": float((names == name).mean()) if len(size) else np.nan,
                      "frauds": frauds, "share_of_frauds": frauds / max(int(size.sum()), 1)})
    return pd.DataFrame(lines)


def old_previous_share(runs, old_gap=None):
    """How many ranked frauds have a previous fraud that is more than `old_gap` seconds old.

    runs      what `fraud_runs` returned
    old_gap   the age in seconds from which a label can be taken to have arrived (default: OLD_GAP)

    Returns a one-line DataFrame: frauds, with_previous_fraud, previous_older_than_limit,
    limit_days, share_of_frauds and share_of_follow_ups. Only for these frauds could the label
    of the previous fraud have arrived in time to help. The file shows a limited stretch of
    time, so a previous fraud from before its first day is not seen and the count is a lower
    bound.
    """
    old_gap = OLD_GAP if old_gap is None else old_gap
    since = runs["seconds_since_previous"].to_numpy()[runs["scored"].to_numpy()]
    has_previous, old = ~np.isnan(since), since > old_gap
    return pd.DataFrame([{
        "frauds": len(since), "with_previous_fraud": int(has_previous.sum()),
        "previous_older_than_limit": int(old.sum()), "limit_days": old_gap / 86_400.0,
        "share_of_frauds": float(old.mean()) if len(since) else np.nan,
        "share_of_follow_ups": float(old.sum() / has_previous.sum()) if has_previous.any() else np.nan,
    }])


def daily_fraud_rate(df, time_col=None, label_col=None, positive_label=None):
    """Rows, frauds and frauds per 10,000 rows for every calendar day of the table.

    df   rows with time and label; every row counts, not only the scored month

    Returns a DataFrame with one line per day in time order: day (text such as "2025-06-01"),
    rows, frauds, frauds_per_10000. A rate that falls through the last weeks of the data, while
    the earlier weeks are level, suggests fraud labels that have not all arrived yet. Rows
    without a time are left out.
    """
    secs = _rows.row_seconds(df, time_col)
    has_time = secs != MISSING_SECOND
    day = secs[has_time] // 86_400
    y = _rows.fraud_flags(df, label_col, positive_label)[has_time]
    days, codes = np.unique(day, return_inverse=True)
    rows = np.bincount(codes, minlength=len(days))
    frauds = np.bincount(codes, weights=y, minlength=len(days))
    return pd.DataFrame({"day": days.astype("datetime64[D]").astype(str), "rows": rows,
                         "frauds": frauds.astype(np.int64),
                         "frauds_per_10000": 10_000.0 * frauds / np.maximum(rows, 1)})


def rate_trend(daily, start=None, end=None, days=7):
    """The fraud rate of the first and of the last `days` days of the scored month, side by side.

    daily        what `daily_fraud_rate` returned
    start, end   the scored month (default: TARGET_START and TARGET_END in settings)

    Returns a one-line DataFrame: days, first_days_rate, last_days_rate (frauds per 10,000 rows)
    and their ratio. A ratio well below 1 points at late labels; it can also be a real change
    in fraud, so it is a prompt to ask when the labels were extracted, not a verdict.
    """
    low, high = _rows.scored_window(start, end)
    day = timekeys.seconds(daily["day"]) if len(daily) else np.zeros(0, dtype=np.int64)
    month = daily[(day >= low) & (day < high)]

    def rate(part):
        return 10_000.0 * float(part["frauds"].sum()) / max(float(part["rows"].sum()), 1.0)

    first, last = rate(month.head(days)), rate(month.tail(days))
    return pd.DataFrame([{"days": min(days, len(month)), "first_days_rate": first, "last_days_rate": last,
                          "ratio": last / first if first > 0 else np.nan}])


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(
        description="Fraud runs per account, capture of first and follow-on frauds, and the daily fraud rate.")
    parser.add_argument("--pred", default=None, help="prediction file (parquet); gives capture as well")
    parser.add_argument("--base", default=None,
                        help="folder of raw files, used when no --pred is given (default: settings.EVAL_BASE)")
    parser.add_argument("--files", default=None, help='raw file numbers, for example "8228-8243"')
    parser.add_argument("--gap-days", type=float, default=RUN_GAP / 86_400.0,
                        help="largest gap in days between two frauds of one run (default: 7)")
    _cli.add_score_arguments(parser)
    parser.add_argument("--out", default=None,
                        help="write the per-fraud table to this parquet file (for measurement only)")
    args = parser.parse_args(argv)

    if args.pred:
        df = _rows.load_predictions(args.pred, score_col=args.score_col)
    elif args.files:
        wanted = [settings.ID_COL, settings.ACCOUNT_COL, settings.TIME_COL, settings.LABEL_COL]
        base = settings.EVAL_BASE if args.base is None else args.base
        df = tables.read_files(base, _cli.file_numbers(args.files), wanted)
    else:
        print("nothing to read: give --pred, or --files (with --base)")
        return
    scored = _cli.scored_rows(df, args)
    # Without ranked rows the capture tables are empty, but the run sizes and the daily rate
    # are still worth printing, so the tool says what is missing and goes on.
    _cli.nothing_to_rank(scored)
    runs = fraud_runs(df, int(args.gap_days * 86_400), scored, score_col=args.score_col, score_kind=args.score_kind,
                      per_mille=args.per_mille)
    _cli.show(f"First frauds against follow-ons (runs with gaps of at most {args.gap_days:g} days; ranked frauds)",
              first_and_follow_on(runs))
    _cli.show("Frauds by the time since the account's previous fraud (ranked frauds)", gap_table(runs))
    _cli.show("Run sizes (every run of the file)", run_sizes(runs))
    _cli.show("Frauds whose previous fraud is old enough for its label to have arrived", old_previous_share(runs))
    daily = daily_fraud_rate(df)
    _cli.show("Fraud rate by calendar day", daily)
    _cli.show("Fraud rate at the start and at the end of the scored month", rate_trend(daily, args.start, args.end))
    if args.out:
        _cli.save(runs, args.out)


if __name__ == "__main__":
    main()
