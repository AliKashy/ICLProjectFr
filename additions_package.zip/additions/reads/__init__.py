"""Reads on scores and files that already exist. No training is needed.

amount_tilt.py            the amount tilt: one ranking, moved between frauds caught and dollars
                          caught
eligible_rows.py          capture on the rows the benchmark keeps, and where the alert budget goes
file_inventory.py         file inventory: what each raw file holds, and fresh blocks of unused files
history_census.py         history census: how much history the scored rows really have
lock_on.py                lock-on: does the model stay on an account after its first alert, and a
                          sticky-alert rule
month_token.py            a calendar input whose scored value was never trained: clamp it, or give
                          it the mean row
multi_history_average.py  several views of each row from one model: score with different history
                          lengths, then average
run_census.py             run census: how frauds cluster on accounts, how they are caught, and how
                          labels arrive
seed_average.py           seed spread, and score averages over several trainings of the same model
_cli.py                   command-line pieces shared by the tools of this folder
_rows.py                  rows of a prediction file: loading, raw columns by id, the scored month
                          and the row type
"""
