"""Lock-on: does the model stay on an account after its first alert, and a sticky-alert rule.

What this file does
-------------------
Part one prints the lock-on table. It takes the frauds of each account in time order and asks
two things of every fraud of the scored month: was the previous fraud of this account inside
the alert cut, and is this one? The table gives the capture of follow-on frauds after a caught
fraud and after a missed fraud, split by the time since the previous fraud (under 1 hour, 1 to
24 hours, 1 to 7 days, longer).

Part two tries the sticky-alert rule. A row's logit gets a bonus `beta` when an earlier row of
the same account, in a strictly earlier second and at most `W` seconds back, scored at or
above the alert cut. The bonus changes which rows are above the cut, so the cut is found again
on the new scores and the number of alerts stays the same. The rule is tried on a grid of W
(1 hour, 6 hours, 24 hours, 72 hours, 7 days) and beta (0.5, 1, 2, 4). The tool chooses the
best cell on one prediction file and reports that one cell on a second file, with a paired
bootstrap that resamples whole accounts.

Why it exists
-------------
Frauds come in runs on one account, so most frauds follow an earlier fraud of that account,
and the capture measure counts every one of them. Fraud labels arrive weeks after the
transaction, so inside a run the label of the first fraud is not there yet. What is there at
once is the model's own verdict on the earlier rows. A model that scores a row from its fields
and its history sees the fields of the earlier rows, but not the scores it gave them. The
lock-on table shows whether the model already stays on a run once it has caught one fraud. The
sticky rule measures, without any training, how much capture a memory of the model's own alerts
adds. If the rule gains, the same memory is worth building properly, as inputs of a second
stage or as columns for a downstream tree model: the largest earlier score of the account in
the last hour, day and week, and the time since its last alert.

Caveat: this is an offline replay. In live use an alert usually leads to a block on the card,
and the follow-on frauds then never happen. The replay still counts them as caught, so it
credits the rule with follow-on frauds that a block after the first alert would have prevented.
The gain says how well the ranking follows a run, not how many frauds the rule would stop.

Where it goes
-------------
After scoring (scores), before a second stage is built. The rule needs only a prediction file
with account, time and score; rows of the month before the scored month supply the earlier
scores for the first days of the scored month. A served version keeps, per account, the time
and score of its recent rows. The lock-on table uses fraud labels to describe the model; the
rule itself reads no label, only the model's own earlier scores.

What to change for the pod
--------------------------
settings.py: ACCOUNT_COL, TIME_COL, LABEL_COL, AMOUNT_COL, SCORE_COL, SCORE_KIND, TARGET_START,
TARGET_END, OUTSORT_PER_MILLE and the bootstrap settings. CHOOSE_FILES and DECIDE_FILES name
the two blocks of files the two prediction files should come from. WINDOWS and BETAS below
are the grid; STICKY_COL and EARLIER_MAX_COL name the columns written with --out.

How to try it
-------------
    python additions/reads/lock_on.py --choose choose_predictions.parquet --report decide_predictions.parquet
or, from Python:
    print(lock_on_table(df))
    window, beta = choose_cell(grid(df))
    print(read_cell(other_df, window, beta))
The tests are in additions/tests/test_reads_lock_on.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd

from additions.common import timekeys
from additions.common.bootstrap import paired_bootstrap
from additions.common.history import EarlierRows
from additions.common.timekeys import MISSING_SECOND
from additions.reads import _cli, _rows

# The grid of the sticky rule: how far back an earlier alert still counts (seconds), and the
# bonus added to the logit. Twenty cells are tried, so the best one must be confirmed on rows
# that did not choose it.
WINDOWS = (3_600, 6 * 3_600, 24 * 3_600, 72 * 3_600, 7 * 86_400)
BETAS = (0.5, 1.0, 2.0, 4.0)

# The split of the time since the previous fraud used by the lock-on table (seconds).
GAP_EDGES = (3_600, 86_400, 7 * 86_400)
GAP_LABELS = ("under 1 hour", "1 to 24 hours", "1 to 7 days", "longer")

# PLACEHOLDER: the names of the two columns written with --out: the logit after the bonus, and
# the largest earlier logit of the account inside the chosen window.
STICKY_COL = "score_sticky"
EARLIER_MAX_COL = "earlier_max_logit"


def _engine(df, account_col=None, time_col=None):
    """The history engine of the table: one history per account, ordered by whole seconds."""
    return EarlierRows(_rows.account_codes(df, account_col), _rows.row_seconds(df, time_col))


def lock_on_table(df, scored=None, account_col=None, time_col=None, label_col=None, positive_label=None,
                  score_col=None, score_kind=None, per_mille=None, rounding=None):
    """Capture of each fraud of the scored month, given what happened to the account's previous fraud.

    df       predictions with account, time, label and score; rows before the scored month are
             kept, because the previous fraud of an early fraud lies there
    scored   yes/no per row: the rows that are ranked (default: the scored month in settings)

    Returns a DataFrame with one line per (previous, gap):
      previous   "none": the account has no earlier fraud in the file; "caught" or "missed": its
                 latest fraud in a strictly earlier second was inside or outside the cut
      gap        time since that previous fraud ("all" sums over the gaps)
      frauds, share_of_frauds, caught, capture

    Frauds of one account in the same second cannot be put in order, so none of them is the
    "previous fraud" of another, and that second counts as caught when any of its frauds is
    inside the cut. The table uses labels to describe the model. It is a read, not a feature:
    a previous fraud's label is not known when the next fraud is scored.
    """
    scored = _rows.in_scored_month(df, time_col) if scored is None else np.asarray(scored, dtype=bool)
    keys = _rows.account_codes(df, account_col)
    secs = _rows.row_seconds(df, time_col)
    s = _rows.logits(df, score_col, score_kind)
    inside = s >= _rows.cut_threshold(s[scored], per_mille, rounding)
    # Only fraud rows with a time matter from here on. They are few, and within this subset the
    # "previous fraud" of a fraud is simply its latest earlier row.
    f = np.flatnonzero((_rows.fraud_flags(df, label_col, positive_label) > 0) & (secs != MISSING_SECOND))
    keys_f, secs_f, inside_f = keys[f], secs[f], inside[f].astype(np.float64)
    # Frauds of one account in the same second share one answer: that second counts as caught
    # when any of its frauds is inside the cut. The answer is spread to each of its rows.
    second = timekeys.codes(keys_f, secs_f)                    # one code per (account, second)
    any_inside = np.zeros(int(second.max()) + 1 if len(second) else 0)
    np.maximum.at(any_inside, second, inside_f)
    earlier = EarlierRows(keys_f, secs_f)
    gap = earlier.seconds_since_last()                         # NaN: no earlier fraud of the account
    # What happened to the latest fraud second before this one (same-second frauds are not "before").
    previous_inside = earlier.last(any_inside[second], default=np.nan)
    previous = np.where(np.isnan(gap), "none", np.where(previous_inside > 0, "caught", "missed"))
    gap_name = _rows.bucket(gap, GAP_EDGES, GAP_LABELS, missing="all")
    keep = scored[f]                                           # the frauds that the measure counts
    previous, gap_name, caught = previous[keep], gap_name[keep], inside_f[keep]
    lines = []

    def add(name, gap_label, rows):
        n = int(rows.sum())
        lines.append({"previous": name, "gap": gap_label, "frauds": n, "share_of_frauds": n / max(len(caught), 1),
                      "caught": float(caught[rows].sum()), "capture": float(caught[rows].mean()) if n else np.nan})

    add("none", "all", previous == "none")
    for name in ("caught", "missed"):
        add(name, "all", previous == name)
        for label in GAP_LABELS:
            add(name, label, (previous == name) & (gap_name == label))
    return pd.DataFrame(lines)


def sticky_logits(df, window, beta, scored=None, threshold=None, account_col=None, time_col=None,
                  score_col=None, score_kind=None, per_mille=None, rounding=None, engine=None):
    """The logit of every row after the sticky-alert bonus.

    df          predictions with account, time and score; rows before the scored month are kept,
                because they hold the earlier scores of the first scored rows
    window      how far back an earlier row still counts, in seconds
    beta        the bonus added to the logit of a row that has such an earlier row
    scored      yes/no per row: the ranked rows, used to find the cut (default: the scored month)
    threshold   the logit at or above which an earlier row counts as an alert; the default is
                the alert cut of the ranked rows on the scores as they are. It is a number about
                the scores, not about labels, and a served rule would hold it fixed.
    engine      an `EarlierRows` object for this table, to save the sort when many cells are tried

    Returns (new_logit, earlier_max, boosted), each with one value per row of `df`:
    `earlier_max` is the largest logit among the account's rows in the `window` seconds before
    the row (NaN when there is none) and `boosted` marks the rows that got the bonus.

    Time rule: only rows of strictly earlier seconds count. Two rows of one account in the same
    second never see each other, because their order cannot be trusted. The bonus is driven by
    the scores as the model gave them, never by scores that already hold a bonus, so one alert
    does not keep an account boosted for longer than `window`.
    """
    logit = _rows.logits(df, score_col, score_kind)
    if threshold is None:
        scored = _rows.in_scored_month(df, time_col) if scored is None else np.asarray(scored, dtype=bool)
        threshold = _rows.cut_threshold(logit[scored], per_mille, rounding)
    engine = _engine(df, account_col, time_col) if engine is None else engine
    earlier_max = engine.maximum(logit, window=window)
    boosted = earlier_max >= threshold                         # NaN (no earlier row) compares as "no"
    return logit + beta * boosted, earlier_max, boosted


def grid(df, windows=None, betas=None, scored=None, account_col=None, time_col=None, label_col=None,
         positive_label=None, amount_col=None, score_col=None, score_kind=None, per_mille=None, rounding=None):
    """Capture of the sticky rule for every window and bonus of the grid.

    df        predictions with account, time, label, amount and score (history rows included)
    windows   the windows to try, in seconds (default: WINDOWS)
    betas     the bonuses to try (default: BETAS)
    scored    yes/no per row: the rows that are ranked (default: the scored month in settings)

    Returns a DataFrame with one line per cell: window_seconds, window_hours, beta,
    boosted_share (the share of ranked rows that get the bonus), udr and vdr after the bonus,
    and udr_gain and vdr_gain against the scores as they are. The cut is found again for every
    cell, so each line spends the same number of alerts.
    """
    windows = WINDOWS if windows is None else windows
    betas = BETAS if betas is None else betas
    scored = _rows.in_scored_month(df, time_col) if scored is None else np.asarray(scored, dtype=bool)
    y = _rows.fraud_flags(df, label_col, positive_label)[scored]
    a = _rows.amounts(df, amount_col)
    a = None if a is None else a[scored]
    logit = _rows.logits(df, score_col, score_kind)
    base = _rows.capture_line("base", y, logit[scored], a, per_mille, rounding)
    threshold = _rows.cut_threshold(logit[scored], per_mille, rounding)
    engine = _engine(df, account_col, time_col)
    lines = []
    for window in windows:
        # The search for an earlier alert depends on the window only, so it runs once per window.
        boosted = engine.maximum(logit, window=window) >= threshold
        for beta in betas:
            cell = _rows.capture_line("cell", y, (logit + beta * boosted)[scored], a, per_mille, rounding)
            lines.append({"window_seconds": int(window), "window_hours": window / 3_600.0, "beta": float(beta),
                          "boosted_share": float(boosted[scored].mean()) if scored.any() else np.nan,
                          "udr": cell["udr"], "udr_gain": cell["udr"] - base["udr"],
                          "vdr": cell["vdr"], "vdr_gain": cell["vdr"] - base["vdr"]})
    return pd.DataFrame(lines)


def choose_cell(table):
    """The (window in seconds, beta) of the grid line with the highest udr.

    table   what `grid` returned

    Among lines with the same udr the smallest bonus wins, then the shortest window: the
    mildest rule that does the job. The best of many cells is too good on the rows that chose
    it, so its gain should be read with `read_cell` on other rows.
    """
    best = table.sort_values(["udr", "beta", "window_seconds"], ascending=[False, True, True]).iloc[0]
    return int(best["window_seconds"]), float(best["beta"])


def read_cell(df, window, beta, scored=None, threshold=None, account_col=None, time_col=None, label_col=None,
              positive_label=None, amount_col=None, score_col=None, score_kind=None, per_mille=None, rounding=None,
              draws=None, seed=None, interval=None):
    """One cell of the grid read on a table, against the scores as they are, with an interval.

    df             predictions with account, time, label, amount and score (history rows included)
    window, beta   the cell: the window in seconds and the bonus
    scored         yes/no per row: the rows that are ranked (default: the scored month in settings)
    threshold      the logit at or above which an earlier row counts as an alert. The default is
                   the alert cut of this table's own scores; pass the value found on the file
                   that chose the cell to hold every part of the rule fixed.

    The comparison is paired and resamples whole accounts: both rankings are read on the same
    draw of accounts, so the noise they share cancels. Returns a DataFrame with one line for the
    share of frauds caught and, when amounts are available, one for the share of fraud dollars:
    measure, sticky, base, gain, low, high, share_above_zero, draws.
    """
    scored = _rows.in_scored_month(df, time_col) if scored is None else np.asarray(scored, dtype=bool)
    new_logit, _, _ = sticky_logits(df, window, beta, scored, threshold, account_col, time_col, score_col,
                                    score_kind, per_mille, rounding)
    base = _rows.logits(df, score_col, score_kind)
    units = _rows.account_codes(df, account_col)[scored]
    y = _rows.fraud_flags(df, label_col, positive_label)[scored]
    a = _rows.amounts(df, amount_col)
    lines = []
    # The same draws of accounts are used for both measures: first the share of frauds caught,
    # then the share of fraud dollars (skipped when the table has no amounts).
    for measure, value in (("udr", False), ("vdr", True)):
        if value and a is None:
            continue
        r = paired_bootstrap(units, y, new_logit[scored], base[scored], None if a is None else a[scored],
                             per_mille, draws, seed, interval, rounding, value)
        lines.append({"measure": measure, **_rows.bootstrap_line(r, "sticky", "base")})
    return pd.DataFrame(lines)


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(
        description="Lock-on table and the sticky-alert rule on the model's own earlier scores.")
    parser.add_argument("--choose", required=True, help="prediction file on which the grid cell is chosen")
    parser.add_argument("--report", default=None, help="second prediction file on which the chosen cell is reported")
    parser.add_argument("--windows-hours", nargs="*", type=float, default=None,
                        help="windows of the grid in hours (default: 1 6 24 72 168)")
    parser.add_argument("--betas", nargs="*", type=float, default=None, help="bonuses of the grid (default: 0.5 1 2 4)")
    parser.add_argument("--draws", type=int, default=None, help="bootstrap draws (default: settings.BOOTSTRAP_DRAWS)")
    _cli.add_score_arguments(parser)
    parser.add_argument("--out", default=None,
                        help="write the rows of the last file read, with the sticky logit, to this parquet file")
    args = parser.parse_args(argv)
    windows = WINDOWS if not args.windows_hours else [int(round(h * 3_600)) for h in args.windows_hours]
    names = dict(score_col=args.score_col, score_kind=args.score_kind, per_mille=args.per_mille)

    df = _rows.load_predictions(args.choose, score_col=args.score_col)
    scored = _cli.scored_rows(df, args)
    if _cli.nothing_to_rank(scored):
        return
    _cli.show("Lock-on table (file used to choose)", lock_on_table(df, scored, **names))
    table = grid(df, windows, args.betas or None, scored, **names)
    _cli.show("Sticky-alert grid (file used to choose)", table.drop(columns="window_seconds"))
    window, beta = choose_cell(table)
    print(f"\nchosen cell: window {window / 3_600.0:g} hours, beta {beta:g}")

    if args.report:
        df = _rows.load_predictions(args.report, score_col=args.score_col)
        scored = _cli.scored_rows(df, args)
        if _cli.nothing_to_rank(scored):
            return
        _cli.show("Chosen cell on the second file (paired bootstrap over accounts)",
                  read_cell(df, window, beta, scored, draws=args.draws, **names))
    else:
        # The best of many cells looks better than it is on the rows that chose it.
        print("no --report file was given: the gain of the chosen cell above is the best of the grid "
              "on the same rows and is too high; read it on a second file before it is trusted")
    if args.out:
        new_logit, earlier_max, _ = sticky_logits(df, window, beta, scored, **names)
        out = df.copy()
        out[STICKY_COL], out[EARLIER_MAX_COL] = new_logit, earlier_max
        _cli.save(out, args.out)


if __name__ == "__main__":
    main()
