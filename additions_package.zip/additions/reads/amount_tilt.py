"""The amount tilt: one ranking, moved between frauds caught and dollars caught.

What this file does
-------------------
It ranks rows by `logit + g * log(1 + amount)` for a grid of g and prints, for each g, the
share of frauds caught (UDR) and the share of fraud dollars caught (VDR) at the alert cut. The
lines together are the frontier between the two measures. It picks the largest g whose loss of
UDR against g = 0 stays inside a given limit, reads that g against the untilted ranking with a
paired bootstrap, and can write the tilted score.

Why it exists
-------------
The alert budget is a fixed small share of rows, and both measures are read from the same
alerted rows. With probabilities that are right, a ranking by the probability of fraud alone
catches the most frauds and a ranking by probability times amount catches the most dollars.
The tilt trades frauds caught for dollars caught. One ranking serves both measures, so where a
model sits between the two is a choice, not a property of the model, and the tilt makes that
choice explicit without any training: it is one addition at scoring time. It also keeps
comparisons fair. A model trained with amount weights already sits at a tilted point, and
comparing its dollar capture with the dollar capture of an untilted model compares two
different choices. The same tilt should therefore be applied to every model being compared,
and the points that are reported (g = 0 and the chosen g) should be fixed before the final
rows are read. A downstream user who works in dollars can take the tilted score as a second
ranking column.

Where it goes
-------------
After scoring (scores). It needs a prediction file with score and amount, nothing else. In
serving it is one line after the head: the logit plus g times log(1 + amount). No part of the
network or of training changes.

What to change for the pod
--------------------------
settings.py: AMOUNT_COL (it must be the amount the dollar measure is computed with),
SCORE_COL, SCORE_KIND, LABEL_COL, ACCOUNT_COL, TIME_COL, TARGET_START, TARGET_END,
OUTSORT_PER_MILLE and the bootstrap settings. GRID below is the list of g that is tried;
TILTED_COL names the column written with --out. A missing or negative amount is treated as
zero, so such a row gets no tilt; change `tilted_logit` if the data needs another rule.

How to try it
-------------
    python additions/reads/amount_tilt.py --pred choose.parquet --report decide.parquet --max-udr-loss 0.01
    python additions/reads/amount_tilt.py --pred predictions.parquet --g 0.3 --out tilted.parquet
or, from Python:
    table = frontier(df)
    g = pick_g(table, max_udr_loss=0.01)
    print(read_g(other_df, g))
The tests are in additions/tests/test_reads_amount_tilt.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd

from additions.common.bootstrap import paired_bootstrap
from additions.reads import _cli, _rows

# The values of g that are tried: 0.0, 0.1, ..., 1.0. With a logit that is a true log-odds value,
# g = 1 is close to ranking by expected fraud dollars, because the odds of a rare event are
# close to its probability. A logit that is too spread out or too flat just moves the useful g
# up or down, so the grid may have to be widened.
GRID = tuple(round(0.1 * i, 1) for i in range(11))

# PLACEHOLDER: the name of the column that holds the tilted score in the file written with --out.
TILTED_COL = "score_tilted"


def tilted_logit(logit, amount, g):
    """logit + g * log(1 + amount), one value per row.

    logit    log-odds of fraud per row
    amount   dollar amount per row; a missing or negative amount counts as zero (no tilt)
    g        the strength of the tilt; 0 returns the logit unchanged

    The logarithm keeps one very large amount from swamping the score: doubling the amount
    adds the same step whatever its size.
    """
    amount = np.clip(np.nan_to_num(np.asarray(amount, dtype=np.float64), nan=0.0), 0.0, None)
    return np.asarray(logit, dtype=np.float64) + g * np.log1p(amount)


def frontier(df, grid=None, scored=None, time_col=None, label_col=None, positive_label=None, amount_col=None,
             score_col=None, score_kind=None, per_mille=None, rounding=None):
    """UDR and VDR at the alert cut for every g of the grid.

    df       predictions with label, amount and score
    grid     the values of g (default: GRID)
    scored   yes/no per row: the rows that are ranked (default: the scored month in settings)

    Returns a DataFrame with one line per g: g, udr, vdr, caught, and udr_change and vdr_change
    against the untilted ranking (g = 0, which is always computed even when the grid leaves it
    out). Without an amount column the table is empty and one line is printed.
    """
    grid = GRID if grid is None else grid
    scored = _rows.in_scored_month(df, time_col) if scored is None else np.asarray(scored, dtype=bool)
    a = _rows.amounts(df, amount_col)
    if a is None:
        return pd.DataFrame()
    y = _rows.fraud_flags(df, label_col, positive_label)[scored]
    logit, a = _rows.logits(df, score_col, score_kind)[scored], a[scored]
    # The untilted ranking is the reference for every line, whether or not the grid holds g = 0.
    base = _rows.capture_line("g = 0", y, logit, a, per_mille, rounding)
    lines = []
    for g in grid:
        c = _rows.capture_line("tilted", y, tilted_logit(logit, a, g), a, per_mille, rounding)
        lines.append({"g": float(g), "udr": c["udr"], "vdr": c["vdr"], "caught": c["caught"],
                      "udr_change": c["udr"] - base["udr"], "vdr_change": c["vdr"] - base["vdr"]})
    return pd.DataFrame(lines)


def pick_g(table, max_udr_loss=0.01):
    """The largest g of the frontier whose udr is at most `max_udr_loss` below the untilted udr.

    table          what `frontier` returned (the columns g and udr_change are used)
    max_udr_loss   the largest share of frauds that may be given up, for example 0.01

    The limit is a choice about how many frauds may be traded for dollars; it is not found
    from the data. Each g is judged by its own loss, so a g beyond a worse one can still be
    picked. Returns 0.0 when no g of the table stays inside the limit.
    """
    inside = table[table["udr_change"] >= -float(max_udr_loss) - 1e-12]
    return float(inside["g"].max()) if len(inside) else 0.0


def read_g(df, g, scored=None, account_col=None, time_col=None, label_col=None, positive_label=None,
           amount_col=None, score_col=None, score_kind=None, per_mille=None, rounding=None,
           draws=None, seed=None, interval=None):
    """One value of g against the untilted ranking on the same rows, with intervals.

    df       predictions with account, label, amount and score
    g        the strength of the tilt
    scored   yes/no per row: the rows that are ranked (default: the scored month in settings)

    Returns a DataFrame with a line for udr and a line for vdr: measure, tilted, untilted,
    change, low, high, share_above_zero, draws. The bootstrap is paired and resamples whole
    accounts. The picture to expect is a loss on the first line and a gain on the second;
    whether that trade is wanted is the choice the tilt exists for. Without an amount column
    the table is empty.
    """
    scored = _rows.in_scored_month(df, time_col) if scored is None else np.asarray(scored, dtype=bool)
    a = _rows.amounts(df, amount_col)
    if a is None:
        return pd.DataFrame()
    y = _rows.fraud_flags(df, label_col, positive_label)[scored]
    logit, a = _rows.logits(df, score_col, score_kind)[scored], a[scored]
    units = _rows.account_codes(df, account_col)[scored]
    tilted = tilted_logit(logit, a, g)
    lines = []
    # Candidate: the tilted ranking. Control: the untilted one. First frauds, then fraud dollars.
    for measure, value in (("udr", False), ("vdr", True)):
        r = paired_bootstrap(units, y, tilted, logit, a, per_mille, draws, seed, interval, rounding, value)
        lines.append({"measure": measure, **_rows.bootstrap_line(r, "tilted", "untilted", "change")})
    return pd.DataFrame(lines)


def tilted_frame(df, g, amount_col=None, score_col=None, score_kind=None, tilted_col=None):
    """The table with one more column: the tilted score of every row (history rows included).

    The new column is on the log-odds scale and is meant for ranking only; after the tilt it is
    no longer the log-odds of fraud. The original score column is left as it was.
    """
    a = _rows.amounts(df, amount_col)
    out = df.copy()
    out[TILTED_COL if tilted_col is None else tilted_col] = tilted_logit(
        _rows.logits(df, score_col, score_kind), np.zeros(len(df)) if a is None else a, g)
    return out


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(
        description="Frontier between frauds caught and dollars caught under an amount tilt.")
    parser.add_argument("--pred", required=True, help="prediction file on which the frontier is read and g is picked")
    parser.add_argument("--report", default=None, help="second prediction file on which the picked g is read")
    parser.add_argument("--grid", nargs="*", type=float, default=None, help="values of g (default: 0.0 0.1 ... 1.0)")
    parser.add_argument("--max-udr-loss", type=float, default=0.01,
                        help="largest loss of udr against g = 0 that is accepted (default: 0.01)")
    parser.add_argument("--g", type=float, default=None, help="use this g instead of picking one")
    parser.add_argument("--draws", type=int, default=None, help="bootstrap draws (default: settings.BOOTSTRAP_DRAWS)")
    _cli.add_score_arguments(parser)
    parser.add_argument("--out", default=None,
                        help="write the rows of the last file read, with the tilted score, to this parquet file")
    args = parser.parse_args(argv)
    names = dict(score_col=args.score_col, score_kind=args.score_kind, per_mille=args.per_mille)

    df = _rows.load_predictions(args.pred, score_col=args.score_col)
    scored = _cli.scored_rows(df, args)
    if _cli.nothing_to_rank(scored):
        return
    table = frontier(df, args.grid or None, scored, **names)
    if len(table) == 0:
        print("the tilt needs the amount column; nothing was read")
        return
    _cli.show("Frontier: capture at the alert cut for each g", table)
    if args.g is None:
        g = pick_g(table, args.max_udr_loss)
        print(f"\ng used from here on: {g:g} (the largest g with a udr loss of at most {args.max_udr_loss:g})")
    else:
        g = args.g
        print(f"\ng used from here on: {g:g} (given on the command line)")

    if args.report:
        df = _rows.load_predictions(args.report, score_col=args.score_col)
        scored = _cli.scored_rows(df, args)
        if _cli.nothing_to_rank(scored):
            return
    elif args.g is None:
        # A g picked on these rows looks a little better on them than it will elsewhere.
        print("no --report file was given: the read below is on the rows that picked g")
    _cli.show(f"g = {g:g} against the untilted ranking (paired bootstrap over accounts)",
              read_g(df, g, scored, draws=args.draws, **names))
    if args.out:
        _cli.save(tilted_frame(df, g, score_col=args.score_col, score_kind=args.score_kind), args.out)


if __name__ == "__main__":
    main()
