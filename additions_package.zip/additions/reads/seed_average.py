"""Seed spread, and score averages over several trainings of the same model.

What this file does
-------------------
It takes K prediction files that hold the same rows, scored by K trainings of one model that
differ only in the random seed. It reports capture at the alert cut for each file, the mean and
the standard deviation of those captures (the seed spread), and the capture of three averages
of the K scores: the mean of the logits, the mean of the probabilities and the mean of the
ranks. It compares the logit average with the first file by a paired bootstrap that resamples
whole accounts, shows how many alerts each file shares with the first, and writes the averaged
score when an output path is given.

Why it exists
-------------
Two trainings that differ only in the seed do not alert the same rows. The alert budget is a
fixed small share of rows, so a few rows moving across the cut change the capture, and one
seed's figure carries noise that has nothing to do with the idea being tested. The seed spread
says how large a difference between two variants must be before it means anything. The
averages show how much of that noise an ensemble removes: an average of several seeds is as a
rule a steadier ranking than any one of them. The average is also the natural teacher when
several trainings are to be folded into one model by training a student on their averaged
score. A student can at best inherit the gain of the average over a single seed, so that gain
is measured first, on the CPU, before any teacher-student training is paid for.

Where it goes
-------------
After scoring (scores), on prediction files of several seeds; before any decision that
compares two variants, and before a teacher-student training. The averaged score written by
this tool can serve as the soft target of such a training; the extra loss term would sit next
to the label loss (in the original code the loss is computed in `FTTransformerHierModel._step`).
Only scores are averaged, never exported vectors: two seeds do not share coordinate axes.

What to change for the pod
--------------------------
settings.py: ID_COL (the files are lined up by it), ACCOUNT_COL, TIME_COL, LABEL_COL,
AMOUNT_COL, SCORE_COL, SCORE_KIND, TARGET_START, TARGET_END, OUTSORT_PER_MILLE and the
bootstrap settings. Every file must come from scoring the same rows. A soft target must come
from rows the teachers did not train on, so the files should be scored on files outside every
teacher's training list.

How to try it
-------------
    python additions/reads/seed_average.py --preds seed42.parquet seed43.parquet seed44.parquet --names 42 43 44
    (add --out averaged.parquet to write the averaged score)
or, from Python:
    result = read_files(["seed42.parquet", "seed43.parquet", "seed44.parquet"])
    print(result["table"]); print(result["overlap"]); print(result["bootstrap"])
The tests are in additions/tests/test_reads_seed_average.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd
from scipy.special import expit
from scipy.stats import rankdata

from additions import settings
from additions.common import ranking
from additions.common.bootstrap import paired_bootstrap
from additions.reads import _cli, _rows

# The three ways of averaging, in the order in which they are reported, and their table names.
AVERAGES = ("logit", "probability", "rank")
AVERAGE_NAMES = {"logit": "average of logits", "probability": "average of probabilities", "rank": "average of ranks"}


def averages(logit_matrix):
    """Three averages of K score columns of the same rows.

    logit_matrix   shape [rows, K]: column j holds the log-odds that file j gives to each row

    Returns a dict of three arrays of shape [rows]:
      "logit"         the mean of the logits (a log-odds value). It is the geometric mean of
                      the odds, so a row ranks high only when the files agree on it.
      "probability"   the mean of the probabilities (a probability). Among rare events one
                      alarmed file is enough to lift a row, whatever the others say.
      "rank"          the mean, over the files, of the row's rank divided by the number of rows
                      (a value in (0, 1], higher is more suspicious). It ignores how the scores
                      are scaled and depends on the set of rows that is ranked, so it cannot be
                      served one row at a time.
    """
    matrix = np.asarray(logit_matrix, dtype=np.float64)
    n = max(len(matrix), 1)
    return {
        "logit": matrix.mean(axis=1),
        "probability": expit(matrix).mean(axis=1),
        "rank": (rankdata(matrix, method="average", axis=0) / n).mean(axis=1) if len(matrix) else np.zeros(0),
    }


def score_table(labels, logit_matrix, amount_values=None, names=None, per_mille=None, rounding=None):
    """Capture of every file, their mean and spread, and capture of the three averages.

    labels         1 for fraud, 0 otherwise, shape [rows]
    logit_matrix   shape [rows, K]
    names          K names for the files (default: file 1, file 2, ...)

    Returns a DataFrame with the columns read, udr, vdr, ap (average precision) and caught.
    After one line per file come "mean of files" and "sd of files" (the seed spread, with K - 1
    in the denominator; empty when there is one file), then one line per average. The column
    `gain_over_mean` on the average lines is their udr minus the mean udr of the single files.
    """
    matrix = np.asarray(logit_matrix, dtype=np.float64)
    names = [f"file {j + 1}" for j in range(matrix.shape[1])] if names is None else list(names)

    def line(name, values):
        c = _rows.capture_line(name, labels, values, amount_values, per_mille, rounding)
        ap = ranking.average_precision(labels, values)
        return {"read": name, "udr": c["udr"], "vdr": c["vdr"], "ap": np.nan if ap is None else ap,
                "caught": c["caught"]}

    lines = [line(str(name), matrix[:, j]) for j, name in enumerate(names)]
    # Mean and spread are taken over the single files only, before any average is added.
    singles = pd.DataFrame(lines)[["udr", "vdr", "ap", "caught"]]
    mean = singles.mean()
    lines.append({"read": "mean of files", **mean.to_dict()})
    lines.append({"read": "sd of files", **singles.std(ddof=1).to_dict()})
    for how, values in averages(matrix).items():
        row = line(AVERAGE_NAMES[how], values)
        row["gain_over_mean"] = row["udr"] - mean["udr"]
        lines.append(row)
    return pd.DataFrame(lines)


def alert_overlap(logit_matrix, names=None, per_mille=None, rounding=None):
    """How many alerts each file, and the logit average, share with the first file.

    Returns a DataFrame: read, alerts, shared_with_first, share. A share well below 1 between
    two seeds of one recipe says that the top of the ranking is unstable, which is the case in
    which an average helps most.
    """
    matrix = np.asarray(logit_matrix, dtype=np.float64)
    names = [f"file {j + 1}" for j in range(matrix.shape[1])] if names is None else list(names)
    columns = [(str(name), matrix[:, j]) for j, name in enumerate(names)]
    columns.append((AVERAGE_NAMES["logit"], averages(matrix)["logit"]))
    first = ranking.alert_mask(matrix[:, 0], per_mille, rounding)
    lines = []
    for name, values in columns:
        mask = ranking.alert_mask(values, per_mille, rounding)
        shared = int((mask & first).sum())
        lines.append({"read": name, "alerts": int(mask.sum()), "shared_with_first": shared,
                      "share": shared / max(int(first.sum()), 1)})
    return pd.DataFrame(lines)


def as_score_kind(values, how, score_kind=None):
    """Express an average in the kind of score the prediction files hold.

    The logit average is a log-odds value; the probability and rank averages lie between 0 and
    1. `score_kind` ("probability" or "logit", default settings.SCORE_KIND) is the kind wanted.
    """
    score_kind = settings.SCORE_KIND if score_kind is None else score_kind
    if how == "logit":
        return values if score_kind == "logit" else expit(values)
    return ranking.to_logit(values, "probability") if score_kind == "logit" else values


def read_files(paths, names=None, all_rows=False, start=None, end=None, id_col=None, account_col=None,
               time_col=None, label_col=None, positive_label=None, amount_col=None, score_col=None,
               score_kind=None, per_mille=None, rounding=None, draws=None, seed=None, interval=None,
               filesystem=None):
    """Load K prediction files of the same rows and read them singly and averaged.

    paths      the K prediction files; the first is the one the logit average is compared with
    names      K names for the lines of the tables (default: file 1, file 2, ...)
    all_rows   False ranks the rows of the scored month (`start` and `end` override the month
               in settings); True ranks every row the files share

    Returns a dict:
      "frame"       the columns of the first file for the rows all files share (history rows included)
      "logits"      the log-odds of those rows, shape [rows, K]
      "ranked"      yes/no per row of the frame: the rows that were ranked
      "table"       `score_table` on the ranked rows
      "overlap"     `alert_overlap` on the ranked rows
      "bootstrap"   one line: the logit average against the first file, paired over accounts
    """
    frame, matrix = _rows.load_aligned(paths, (), id_col, account_col, time_col, label_col, amount_col, score_col,
                                       filesystem)
    # All averaging is done on log-odds, whatever kind of score the files hold.
    logit_matrix = ranking.to_logit(matrix, score_kind)
    ranked = np.ones(len(frame), dtype=bool) if all_rows else _rows.in_scored_month(frame, time_col, start, end)
    y = _rows.fraud_flags(frame, label_col, positive_label)[ranked]
    a = _rows.amounts(frame, amount_col)
    a = None if a is None else a[ranked]
    part = logit_matrix[ranked]
    out = {"frame": frame, "logits": logit_matrix, "ranked": ranked,
           "table": score_table(y, part, a, names, per_mille, rounding),
           "overlap": alert_overlap(part, names, per_mille, rounding), "bootstrap": pd.DataFrame()}
    if ranked.any():
        # Candidate: the logit average. Control: the first file. Whole accounts are resampled.
        r = paired_bootstrap(_rows.account_codes(frame, account_col)[ranked], y, averages(part)["logit"], part[:, 0],
                             a, per_mille, draws, seed, interval, rounding)
        out["bootstrap"] = pd.DataFrame([_rows.bootstrap_line(r, "average_of_logits", "first_file")])
    return out


def averaged_frame(result, how="logit", score_col=None, score_kind=None):
    """The rows all files share, with the averaged score in the score column.

    result   what `read_files` returned
    how      "logit", "probability" or "rank"

    The average covers every shared row, history rows included, so the file that is written
    can be read by the other tools of this folder like any prediction file. The score is stored
    in the same kind as the input files. A rank average is taken over the rows that are written.
    """
    score_col = settings.SCORE_COL if score_col is None else score_col
    out = result["frame"].copy()
    out[score_col] = as_score_kind(averages(result["logits"])[how], how, score_kind)
    return out


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(
        description="Seed spread and score averages over several prediction files of the same rows.")
    parser.add_argument("--preds", nargs="+", required=True,
                        help="prediction files of the same rows; the first is the reference")
    parser.add_argument("--names", nargs="*", default=None,
                        help="one name per file for the tables, for example the seeds")
    parser.add_argument("--average", choices=AVERAGES, default="logit",
                        help="the average written with --out (default: logit)")
    parser.add_argument("--draws", type=int, default=None, help="bootstrap draws (default: settings.BOOTSTRAP_DRAWS)")
    _cli.add_score_arguments(parser)
    parser.add_argument("--out", default=None,
                        help="write the shared rows with the averaged score to this parquet file")
    args = parser.parse_args(argv)
    names = args.names if args.names and len(args.names) == len(args.preds) else None
    if args.names and names is None:
        print("note: the number of names differs from the number of files; the files are numbered instead")
    result = read_files(args.preds, names, args.all_rows, args.start, args.end, score_col=args.score_col,
                        score_kind=args.score_kind, per_mille=args.per_mille, draws=args.draws)
    if _cli.nothing_to_rank(result["ranked"]):
        return
    _cli.show("Capture of each file, their spread, and the three averages", result["table"])
    _cli.show("Alerts shared with the first file", result["overlap"])
    _cli.show("Average of logits against the first file (paired bootstrap over accounts)", result["bootstrap"])
    if args.out:
        _cli.save(averaged_frame(result, args.average, args.score_col, args.score_kind), args.out)


if __name__ == "__main__":
    main()
