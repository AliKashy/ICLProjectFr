"""Several views of each row from one model: score with different history lengths, then average.

What this file does
-------------------
It takes prediction files of the same rows that were all scored by one checkpoint, each with a
different history length (for example 20, 40 and 80 earlier seconds). It reports capture at
the alert cut for each history length and for three averages of the scores (mean of logits,
mean of probabilities, mean of ranks), shows how many alerts each view shares with the first,
compares the logit average with the first file by a paired bootstrap over accounts, and writes
the averaged score when an output path is given. The averaging code is the one in
seed_average.py; this file only adds the history lengths as names and the reasoning below.

Why it exists
-------------
A model trained on chunks of rows learns to score with every amount of history at once. A
chunk is a stretch of consecutive rows of one account, and every row of the chunk is a
training target that sees only the rows before it in the chunk. The first row is scored with
no history, the next with one earlier step, and the last with a full window. So the same
weights have been trained to give a sound score from a short history and from a long one.
At scoring time the history length is then a free choice, and each choice is a different view
of the same row: a short history keeps the model on the last minutes, where a fraud run shows;
a long history adds the habits of the account, against which an odd transaction stands out.
The views disagree on some rows, partly from what they see and partly from chance. Averaging
them removes part of the chance, in the way an average over training seeds does, but with one
set of weights and one training. The price is one scoring pass per view. If the average gains,
the same effect can be sought in one pass by training a student on the averaged score.

Two limits apply. A scored row has between one and two months of history, because the
evaluation files start one month before the scored month; history lengths beyond what the
rows have give the same view twice (history_census.py counts this). And a model trained on
windows of one fixed length has seen few short histories, so its scores from a shortened
history cannot be relied on; the method is meant for chunk-trained models.

Where it goes
-------------
After scoring (scores): the same checkpoint is scored several times, each time with another
history length, and the prediction files are given to this tool. In the original code the
history length of a scoring pass is the `history_len` handed to `SequenceBuilder`; the lengths
should stay within what training covered. Nothing in the network or in training changes.

What to change for the pod
--------------------------
settings.py: ID_COL (the files are lined up by it), ACCOUNT_COL, TIME_COL, LABEL_COL,
AMOUNT_COL, SCORE_COL, SCORE_KIND, TARGET_START, TARGET_END, OUTSORT_PER_MILLE and the
bootstrap settings. The first file should be the history length in use today
(settings.HISTORY_LEN), because the gain is reported against it.

How to try it
-------------
    python additions/reads/multi_history_average.py --preds h20.parquet h40.parquet h80.parquet --lengths 20 40 80
    (add --out averaged.parquet to write the averaged score)
or, from Python:
    result = read_views(["h20.parquet", "h40.parquet", "h80.parquet"], lengths=[20, 40, 80])
    print(result["table"]); print(result["overlap"]); print(result["bootstrap"])
The tests are in additions/tests/test_reads_multi_history_average.py.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

from additions.reads import _cli, seed_average


def view_names(n_files, lengths=None):
    """The names of the views for the tables: "history 20", "history 40", ...

    n_files   the number of prediction files
    lengths   the history length each file was scored with, in the order of the files. When it
              is missing, or its count differs from the number of files, the views are numbered
              instead and one line is printed.
    """
    if lengths is not None and len(lengths) == n_files:
        return [f"history {length}" for length in lengths]
    if lengths:
        print("note: the number of history lengths differs from the number of files; the views are numbered instead")
    return [f"view {j + 1}" for j in range(n_files)]


def read_views(paths, lengths=None, all_rows=False, start=None, end=None, id_col=None, account_col=None,
               time_col=None, label_col=None, positive_label=None, amount_col=None, score_col=None,
               score_kind=None, per_mille=None, rounding=None, draws=None, seed=None, interval=None,
               filesystem=None):
    """Read prediction files of one checkpoint scored with several history lengths, singly and averaged.

    paths     the prediction files, the history length in use today first
    lengths   the history length of each file, used to name the lines of the tables

    Every other argument, and the dict that is returned, are those of `seed_average.read_files`:
    "table" holds the capture of each view, their mean and spread and the three averages;
    "overlap" the alerts each view shares with the first; "bootstrap" the logit average against
    the first view. The spread between views is not a seed spread: the views share their
    weights, so they can be expected to differ less than two trainings do.
    """
    return seed_average.read_files(paths, view_names(len(paths), lengths), all_rows, start, end, id_col, account_col,
                                   time_col, label_col, positive_label, amount_col, score_col, score_kind, per_mille,
                                   rounding, draws, seed, interval, filesystem)


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    parser = argparse.ArgumentParser(
        description="Average prediction files of one checkpoint scored with different history lengths.")
    parser.add_argument("--preds", nargs="+", required=True,
                        help="prediction files of the same rows, the history length in use today first")
    parser.add_argument("--lengths", nargs="*", type=int, default=None,
                        help="the history length of each file, in the same order")
    parser.add_argument("--average", choices=seed_average.AVERAGES, default="logit",
                        help="the average written with --out (default: logit)")
    parser.add_argument("--draws", type=int, default=None, help="bootstrap draws (default: settings.BOOTSTRAP_DRAWS)")
    _cli.add_score_arguments(parser)
    parser.add_argument("--out", default=None,
                        help="write the shared rows with the averaged score to this parquet file")
    args = parser.parse_args(argv)
    result = read_views(args.preds, args.lengths, args.all_rows, args.start, args.end, score_col=args.score_col,
                        score_kind=args.score_kind, per_mille=args.per_mille, draws=args.draws)
    if _cli.nothing_to_rank(result["ranked"]):
        return
    _cli.show("Capture of each history length, their spread, and the three averages", result["table"])
    _cli.show("Alerts shared with the first view", result["overlap"])
    _cli.show("Average of logits against the first view (paired bootstrap over accounts)", result["bootstrap"])
    if args.out:
        _cli.save(seed_average.averaged_frame(result, args.average, args.score_col, args.score_kind), args.out)


if __name__ == "__main__":
    main()
