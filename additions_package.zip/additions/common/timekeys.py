"""Whole-second time keys and stable ordering of rows.

What this file does
-------------------
It turns timestamps into whole seconds, gives every distinct key (an account, or an account
together with a merchant) a small integer, and sorts rows by key and time in a stable way.

Why it exists
-------------
The central rule of this package is that a row may only use rows of strictly earlier seconds
of the same key. Two rows in the same second cannot be put in a trustworthy order from the
timestamp alone, so neither may see the other. That rule is easiest to keep when every tool
uses the same whole-second key, which is what this file provides.

Where it goes
-------------
Every history feature, every score state and every sequence of rows starts by calling these
functions.

What to change for the pod
--------------------------
Nothing, as long as the timestamp column can be parsed by pandas. If the timestamps are text
in an unusual format, parse them before calling `seconds`.

How to try it
-------------
    secs = seconds(df[settings.TIME_COL])            # whole seconds, one per row
    keys = codes(df[settings.ACCOUNT_COL])           # a small integer per account
    order = stable_order(keys, secs)                 # rows sorted by account, then time
The test is additions/tests/test_common.py.
"""
import warnings

import numpy as np
import pandas as pd

# The value used for a missing time. It sorts before every real time, so a row with a missing
# time is never "later" than a real row and never enters anyone's history window by accident.
MISSING_SECOND = np.iinfo(np.int64).min


def timestamps(values):
    """The values as pandas timestamps: a Series of datetime64[ns], with NaT where there is no time.

    Accepts a pandas Series, an array or a list of datetimes, or of text that pandas can parse.
    A value that cannot be read becomes NaT. A time that carries a time zone is read as its
    UTC time.
    """
    arr = np.asarray(values)
    series = pd.Series(arr)
    if np.issubdtype(arr.dtype, np.datetime64):
        stamps = pd.to_datetime(series, errors="coerce")
    else:
        # Text timestamps: some rows may carry fractions of a second and others not, so each
        # value is parsed on its own instead of assuming the format of the first one. A recent
        # pandas does that when it is given format="mixed". An older pandas parses each value on
        # its own without being told and does not know the word: it then returns no time at
        # all, which is noticed here, and the column is parsed again the older way.
        stamps = pd.to_datetime(series, errors="coerce", format="mixed")
        if stamps.isna().all() and series.notna().any():
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")       # the older way warns when it has to work out a format
                stamps = pd.to_datetime(series, errors="coerce")
    if getattr(stamps.dt, "tz", None) is not None:
        stamps = stamps.dt.tz_convert("UTC").dt.tz_localize(None)   # a time zone is read as its UTC second
    return stamps.astype("datetime64[ns]")


def seconds(values):
    """Whole seconds since 1970-01-01 as int64, floored.

    Accepts a pandas Series or array of datetimes, of text that pandas can parse, or of
    numbers that already are seconds. Missing values become the smallest int64, which sorts
    first and is never "later" than a real row.
    """
    arr = np.asarray(values)
    if np.issubdtype(arr.dtype, np.integer):
        return arr.astype(np.int64)
    if np.issubdtype(arr.dtype, np.floating):
        out = np.full(arr.shape, MISSING_SECOND, dtype=np.int64)
        ok = np.isfinite(arr)
        out[ok] = np.floor(arr[ok]).astype(np.int64)
        return out
    stamps = timestamps(arr)
    ns = stamps.astype("int64").to_numpy()            # a missing time becomes the smallest int64
    out = np.full(len(ns), MISSING_SECOND, dtype=np.int64)
    ok = stamps.notna().to_numpy()
    out[ok] = ns[ok] // 1_000_000_000
    return out


def codes(*columns):
    """One small integer per distinct combination of the given columns.

    Rows with the same values in every column get the same integer. A missing value is its
    own value here (two missing values match each other); callers that must not match on
    missing values mask those rows themselves. The integers run from 0 to (number of distinct
    combinations - 1).
    """
    if len(columns) == 1:
        series = pd.Series(np.asarray(columns[0]))
        try:
            found = pd.factorize(series, use_na_sentinel=False)[0]
        except TypeError:
            found = pd.factorize(series, na_sentinel=None)[0]    # how a pandas before 1.5 spells the same request
        return found.astype(np.int64)
    frame = pd.DataFrame({i: np.asarray(c) for i, c in enumerate(columns)})
    return frame.groupby(list(frame.columns), sort=False, dropna=False).ngroup().to_numpy().astype(np.int64)


def stable_order(keys, secs, tie=None):
    """The order that sorts rows by key, then by second, then by an optional tie-break value.

    The sort is stable, so rows that are equal on all three keep their original order. The
    result is an index array `order` such that `keys[order]` is sorted.
    """
    keys = np.asarray(keys)
    secs = np.asarray(secs)
    if tie is None:
        return np.lexsort((secs, keys))
    return np.lexsort((np.asarray(tie), secs, keys))


def month_start_seconds(secs, months_back=0):
    """For each time, the first second of its calendar month, shifted back by whole months.

    `months_back=1` gives the first second of the previous month. This is the building block
    of a look-back window that starts at a calendar boundary instead of a fixed number of days.
    """
    secs = np.asarray(secs, dtype=np.int64)
    out = np.full(secs.shape, MISSING_SECOND, dtype=np.int64)
    ok = secs != MISSING_SECOND                      # a missing time has no month
    stamps = pd.to_datetime(secs[ok], unit="s")
    periods = stamps.to_period("M") - int(months_back)
    out[ok] = (periods.to_timestamp().astype("datetime64[ns]").astype("int64") // 1_000_000_000)
    return out
