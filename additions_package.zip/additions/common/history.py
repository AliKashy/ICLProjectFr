"""The "strictly earlier rows" engine.

What this file does
-------------------
For every row it answers questions about the rows of the same key (the same account, or the
same account and merchant, or the same merchant) that happened in strictly earlier seconds:
how many there were, what their values summed to, what the largest was, how long ago the
last one was, and what a sum that fades with age would be. Optional time windows ("within the
last 24 hours") and an optional earliest allowed time ("not before the start of the look-back")
narrow the rows that count.

Why it exists
-------------
Every history feature, every account risk state and every cross-account table in this package
has to obey one rule: a row may use only what was known before it. With timestamps in whole
seconds, "before" means a strictly earlier second. Two rows in the same second cannot be put
in a trustworthy order, so neither may see the other. Writing that rule once, in one tested
class, is safer than repeating it in every feature. The class is also fast: it sorts once and
then answers each question with prefix sums and binary searches, so millions of rows take
seconds, not hours.

Where it goes
-------------
It is a building block. The feature builders, the score state, the merchant tables and the
export windows all create an `EarlierRows` object and ask it questions. It runs on the CPU
before training or after scoring; nothing here is part of the network.

What to change for the pod
--------------------------
Nothing. The class takes plain arrays. `timekeys.codes` makes the key array and
`timekeys.seconds` makes the time array.

How to try it
-------------
    keys = timekeys.codes(df[settings.ACCOUNT_COL])
    secs = timekeys.seconds(df[settings.TIME_COL])
    earlier = EarlierRows(keys, secs)
    n_last_day = earlier.count(window=86_400)                 # earlier rows in the last 24 hours
    spent_last_day = earlier.total(df[settings.AMOUNT_COL], window=86_400)
"""
import numpy as np

from additions.common.timekeys import MISSING_SECOND


class EarlierRows:
    """Answers questions about the rows of the same key in strictly earlier seconds.

    Parameters
    ----------
    keys : array of integers
        One integer per row; rows with the same integer belong to the same history.
    secs : array of int64
        Whole seconds of each row. A row whose time is missing has no history and is never
        part of another row's history.
    start : int, array of int64 or None
        The earliest second that may be used, for all rows (a number) or per row (an array).
        None means no limit. This is how a look-back that begins at a calendar boundary is
        expressed: rows before `start` are ignored even when the window would reach them.

    All answers come back in the original row order.
    """

    def __init__(self, keys, secs, start=None):
        keys = np.asarray(keys)
        secs = np.asarray(secs, dtype=np.int64)
        self.n = n = len(keys)
        # Sort once by key, then by second. The sort is stable, so rows of the same key and
        # second keep their original relative order (the order never matters for the answers,
        # because same-second rows never count for each other).
        order = np.lexsort((secs, keys))
        self.order = order
        self.inverse = np.empty(n, dtype=np.int64)
        self.inverse[order] = np.arange(n)
        k = keys[order]
        t = secs[order]
        self.valid = t != MISSING_SECOND                 # rows with a real time
        # Dense group number in sorted order: 0 for the first key, 1 for the next, and so on.
        new_group = np.ones(n, dtype=bool)
        if n:
            new_group[1:] = k[1:] != k[:-1]
        self.group = np.cumsum(new_group) - 1
        # Times relative to the earliest real time keep the numbers small.
        t_min = int(t[self.valid].min()) if self.valid.any() else 0
        self.t_min = t_min
        rel = np.where(self.valid, t - t_min, 0).astype(np.int64)
        self.rel = rel
        self.t = t
        # One number per row that grows with (group, time). A binary search on it finds, for
        # any group and any time, the first row of that group at or after that time.
        self.span = int(rel.max()) + 2 if n else 2
        self.comp = self.group * self.span + rel
        # hi: the first row of the same key and the same second. Everything before it (down
        # to lo) is strictly earlier. Rows of the same second are therefore never included.
        self.hi = np.searchsorted(self.comp, self.comp, side="left")
        # The first row of each row's group, used when there is no window.
        first_of_group = np.zeros(n, dtype=np.int64)
        if n:
            idx = np.where(new_group, np.arange(n), 0)
            first_of_group = np.maximum.accumulate(idx)
        self.first_of_group = first_of_group
        # The earliest allowed second per row, in relative time (or None).
        if start is None:
            self.start_rel = None
        else:
            s = np.broadcast_to(np.asarray(start, dtype=np.int64), (n,))[order]
            self.start_rel = np.clip(s - t_min, 0, None)

    # ------------------------------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------------------------------

    def bounds(self, window=None):
        """(lo, hi) in sorted order: rows lo .. hi-1 are the strictly earlier rows that count.

        `window` is a length in seconds. A row at time t then uses rows with time in
        [t - window, t). Without a window all earlier rows of the key count. The earliest
        allowed second (`start`) is applied on top of either.
        """
        if window is None and self.start_rel is None:
            return self.first_of_group, self.hi
        floor = np.zeros(self.n, dtype=np.int64)
        if window is not None:
            floor = np.maximum(floor, self.rel - int(window))
        if self.start_rel is not None:
            floor = np.maximum(floor, self.start_rel)
        lo = np.searchsorted(self.comp, self.group * self.span + floor, side="left")
        return np.minimum(lo, self.hi), self.hi

    def _sorted(self, values, dtype=None):
        """Bring a per-row array from the original order into the sorted order."""
        arr = np.asarray(values)
        if dtype is not None:
            arr = arr.astype(dtype)
        return arr[self.order]

    def _back(self, sorted_values):
        """Bring a result from the sorted order back to the original row order."""
        return sorted_values[self.inverse]

    def _mask(self, where):
        """The rows that may count as history: real time, and `where` when it is given."""
        if where is None:
            return self.valid
        return self.valid & self._sorted(where, bool)

    # ------------------------------------------------------------------------------------------
    # counts, sums, means
    # ------------------------------------------------------------------------------------------

    def count(self, window=None, where=None):
        """Number of strictly earlier rows of the key (inside the window, matching `where`)."""
        lo, hi = self.bounds(window)
        prefix = np.concatenate(([0], np.cumsum(self._mask(where))))
        out = (prefix[hi] - prefix[lo]).astype(np.int64)
        out[~self.valid] = 0
        return self._back(out)

    def total(self, values, window=None, where=None):
        """Sum of `values` over the strictly earlier rows. Missing values count as zero."""
        lo, hi = self.bounds(window)
        v = np.nan_to_num(self._sorted(values, np.float64), nan=0.0) * self._mask(where)
        prefix = np.concatenate(([0.0], np.cumsum(v)))
        out = prefix[hi] - prefix[lo]
        out[~self.valid] = 0.0
        return self._back(out)

    def mean(self, values, window=None, where=None):
        """Mean of `values` over the strictly earlier rows that hold a value; NaN when none do."""
        present = ~np.isnan(np.asarray(values, dtype=np.float64))
        if where is not None:
            present = present & np.asarray(where, dtype=bool)
        n = self.count(window, present)
        s = self.total(values, window, present)
        return np.where(n > 0, s / np.maximum(n, 1), np.nan)

    # ------------------------------------------------------------------------------------------
    # extremes
    # ------------------------------------------------------------------------------------------

    def maximum(self, values, window=None, where=None):
        """Largest of `values` over the strictly earlier rows; NaN when there are none.

        The answer for a range of rows comes from a table of maxima over blocks of 1, 2, 4, 8,
        ... rows. Only as many levels are built as the longest range needs, so short windows
        cost little memory.
        """
        lo, hi = self.bounds(window)
        v = self._sorted(values, np.float64).copy()
        v[~self._mask(where)] = -np.inf
        v[np.isnan(v)] = -np.inf
        length = hi - lo
        longest = int(length.max()) if self.n else 0
        out = np.full(self.n, -np.inf)
        if longest > 0:
            levels = [v]
            width = 1
            while width * 2 <= longest:
                prev = levels[-1]
                nxt = prev.copy()
                nxt[:-width] = np.maximum(prev[:-width], prev[width:])
                levels.append(nxt)
                width *= 2
            has = length > 0
            # The largest power of two that fits in each range; two overlapping blocks of that
            # size cover the whole range.
            level = np.zeros(self.n, dtype=np.int64)
            level[has] = np.floor(np.log2(length[has])).astype(np.int64)
            for j, table in enumerate(levels):
                sel = has & (level == j)
                if sel.any():
                    a = table[lo[sel]]
                    b = table[hi[sel] - (1 << j)]
                    out[sel] = np.maximum(a, b)
        out[np.isneginf(out)] = np.nan
        out[~self.valid] = np.nan
        return self._back(out)

    def minimum(self, values, window=None, where=None):
        """Smallest of `values` over the strictly earlier rows; NaN when there are none."""
        return -self.maximum(-np.asarray(values, dtype=np.float64), window, where)

    # ------------------------------------------------------------------------------------------
    # the last and the first earlier row
    # ------------------------------------------------------------------------------------------

    def _last_index(self, window=None, where=None):
        """Sorted position of the latest strictly earlier row that counts, or -1."""
        lo, hi = self.bounds(window)
        ok = self._mask(where)
        seen = np.maximum.accumulate(np.where(ok, np.arange(self.n), -1)) if self.n else np.zeros(0, np.int64)
        cand = np.where(hi > 0, seen[np.maximum(hi - 1, 0)], -1)
        cand[cand < lo] = -1
        cand[~self.valid] = -1
        return cand

    def _first_index(self, window=None, where=None):
        """Sorted position of the earliest strictly earlier row that counts, or -1."""
        lo, hi = self.bounds(window)
        ok = self._mask(where)
        nxt = np.where(ok, np.arange(self.n), self.n)
        nxt = np.minimum.accumulate(nxt[::-1])[::-1] if self.n else nxt
        cand = np.where(lo < self.n, nxt[np.minimum(lo, max(self.n - 1, 0))], self.n) if self.n else nxt
        cand = np.where(cand < hi, cand, -1)
        cand[~self.valid] = -1
        return cand

    def last(self, values, window=None, where=None, default=np.nan):
        """Value on the latest strictly earlier row that counts; `default` when there is none."""
        idx = self._last_index(window, where)
        v = self._sorted(values)
        out = np.where(idx >= 0, v[np.maximum(idx, 0)], default)
        return self._back(out)

    def seconds_since_last(self, window=None, where=None):
        """Seconds from the latest strictly earlier row that counts to this row; NaN when none."""
        idx = self._last_index(window, where)
        out = np.where(idx >= 0, (self.rel - self.rel[np.maximum(idx, 0)]).astype(np.float64), np.nan)
        return self._back(out)

    def seconds_since_first(self, window=None, where=None):
        """Seconds from the earliest strictly earlier row that counts to this row; NaN when none."""
        idx = self._first_index(window, where)
        out = np.where(idx >= 0, (self.rel - self.rel[np.maximum(idx, 0)]).astype(np.float64), np.nan)
        return self._back(out)

    # ------------------------------------------------------------------------------------------
    # sums that fade with age
    # ------------------------------------------------------------------------------------------

    def decayed_sum(self, values, half_lives):
        """Sum of `values` over strictly earlier rows, each halved for every half-life of age.

        `values` is one number per row (shape [n]) or one vector per row (shape [n, d]).
        `half_lives` is one length in seconds or a list of them. The result has one more
        dimension than `values` when a list is given: [n, len(half_lives)] or
        [n, len(half_lives), d].

        A faded sum is a memory with no window edge: a row from an hour ago still counts
        almost fully under a one-day half-life and hardly at all under a ten-minute one. The
        sum can be kept as a running state (multiply by the decay since the last update, then
        add the new value), which is how it would be served. Here it is computed for all rows
        at once. Rows of the same second are added together first, because they all become
        visible at the same moment: the next second. The earliest allowed second (`start`) is
        not applied here; the fading already makes old rows negligible.
        """
        single = np.isscalar(half_lives)
        hl = np.atleast_1d(np.asarray(half_lives, dtype=np.float64))
        v = np.nan_to_num(self._sorted(values, np.float64), nan=0.0)
        vector = v.ndim == 2
        if not vector:
            v = v[:, None]
        v = v * self.valid[:, None]
        n, d = v.shape
        if n == 0:
            shape = (0,) + (() if single else (len(hl),)) + ((d,) if vector else ())
            return np.zeros(shape)
        # One entry per distinct (key, second): the summed value of its rows and its time.
        new_second = np.ones(n, dtype=bool)
        new_second[1:] = self.comp[1:] != self.comp[:-1]
        sec_id = np.cumsum(new_second) - 1
        n_sec = int(sec_id[-1]) + 1
        v_sec = np.zeros((n_sec, d))
        np.add.at(v_sec, sec_id, v)
        t_sec = self.rel[new_second].astype(np.float64)
        g_sec = self.group[new_second]
        # Position of each second inside its key: 0 for the key's first second, 1 for the next.
        first = np.ones(n_sec, dtype=bool)
        first[1:] = g_sec[1:] != g_sec[:-1]
        start_of_key = np.maximum.accumulate(np.where(first, np.arange(n_sec), 0))
        rank = np.arange(n_sec) - start_of_key
        # state[s, h, :] is the faded sum of everything strictly before second s.
        state = np.zeros((n_sec, len(hl), d))
        # Seconds are processed by their position in the key: all "second" seconds, then all
        # "third" seconds, and so on. Each step is one vector operation over many keys, so the
        # number of Python steps is the length of the longest history, not the number of rows.
        by_rank = np.argsort(rank, kind="stable")
        counts = np.bincount(rank)
        edges = np.concatenate(([0], np.cumsum(counts)))
        for r in range(1, len(counts)):
            cur = by_rank[edges[r]:edges[r + 1]]
            prev = cur - 1                                    # the previous second of the same key
            gap = (t_sec[cur] - t_sec[prev])[:, None]         # seconds between the two
            decay = np.power(0.5, gap / hl[None, :])          # [entries, half-lives]
            state[cur] = (state[prev] + v_sec[prev][:, None, :]) * decay[:, :, None]
        out = state[sec_id]                                    # every row reads its second's state
        out[~self.valid] = 0.0
        out = out[self.inverse]
        if not vector:
            out = out[:, :, 0]
        if single:
            out = out[:, 0]
        return out

    # ------------------------------------------------------------------------------------------
    # distinct values
    # ------------------------------------------------------------------------------------------

    def distinct(self, value_codes, window=None):
        """Number of different values of another code among the strictly earlier rows.

        `value_codes` holds one integer per row (for example a merchant code); negative codes
        mean "no value" and are ignored. With a window the count covers [t - window, t);
        without one it covers every earlier row of the key. The earliest allowed second
        (`start`) is not applied here.

        How it works: each occurrence of a value is "the first one inside the window" for a
        stretch of query times. Counting, for a query time, how many occurrences are in that
        stretch gives the number of distinct values, and both ends of the stretch can be
        counted with a binary search.
        """
        codes = self._sorted(value_codes, np.int64)
        ok = self.valid & (codes >= 0)
        pos = np.flatnonzero(ok)
        if len(pos) == 0:
            return np.zeros(self.n, dtype=np.int64)
        g, c, t = self.group[pos], codes[pos], self.rel[pos]
        # Collapse repeats of the same (key, value, second): they are one occurrence.
        o = np.lexsort((t, c, g))
        g, c, t = g[o], c[o], t[o]
        keep = np.ones(len(g), dtype=bool)
        keep[1:] = (g[1:] != g[:-1]) | (c[1:] != c[:-1]) | (t[1:] != t[:-1])
        g, c, t = g[keep], c[keep], t[keep]
        same_pair = np.zeros(len(g), dtype=bool)
        same_pair[1:] = (g[1:] == g[:-1]) & (c[1:] == c[:-1])
        prev_t = np.where(same_pair, np.concatenate(([0], t[:-1])), -1)   # -1: no earlier occurrence
        big = self.span + (int(window) if window is not None else 0) + 2
        if window is None:
            # Without a window a value counts once: at its first occurrence.
            first = ~same_pair
            start_key = np.sort(g[first] * big + t[first])
            q = self.group * big + self.rel
            out = np.searchsorted(start_key, q, side="left")
            out = out - np.searchsorted(start_key, self.group * big, side="left")
        else:
            w = int(window)
            # An occurrence at time s (previous one at p) is the first inside the window for
            # query times in (max(s, p + w), s + w].
            lo_t = np.where(prev_t >= 0, np.maximum(t, prev_t + w), t)
            hi_t = t + w
            lo_key = np.sort(g * big + lo_t)
            hi_key = np.sort(g * big + hi_t)
            q = self.group * big + self.rel
            base = self.group * big
            started = np.searchsorted(lo_key, q, side="left") - np.searchsorted(lo_key, base, side="left")
            ended = np.searchsorted(hi_key, q, side="left") - np.searchsorted(hi_key, base, side="left")
            out = started - ended
        out = out.astype(np.int64)
        out[~self.valid] = 0
        return self._back(out)


def later_rows(keys, secs):
    """An engine that looks forward instead of back: rows of strictly LATER seconds.

    It is the same class with time reversed. A window then means "within the next N seconds".
    Looking forward uses information that does not exist when a transaction is scored, so the
    result must never be a model input. Its legitimate uses are training targets ("does a
    fraud follow within 24 hours?"), teachers that are only used during training, and
    measurement.
    """
    secs = np.asarray(secs, dtype=np.int64)
    flipped = np.where(secs == MISSING_SECOND, MISSING_SECOND, -secs)
    return EarlierRows(keys, flipped)
