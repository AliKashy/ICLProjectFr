"""Made-up transactions for the tests and the examples.

What this file does
-------------------
It builds a small table that looks like the raw transaction files: accounts with their whole
history, merchants that an account returns to, amounts, a network risk score, bank decisions
(approved, declined for funds, declined for risk), advice rows, zero-dollar checks and fraud
runs. It can also invent a model score, exported vectors and a few profile dates, and it can
write the table as numbered files that each hold whole accounts.

Why it exists
-------------
No real data ships with this package. Every piece still needs something to run on, both to
prove that it works and to show how it is called. The made-up data copies the properties
that matter for the logic: frauds come in runs on the same account, a fraud label sits only
on approved rows, several rows can share one second, and files never share an account.

Where it goes
-------------
Only in the tests and in the examples. Nothing here should be used to judge a model.

What to change for the pod
--------------------------
Nothing. The column names come from settings, so a test that passes here uses the same
names as the real files.

How to try it
-------------
    df = make_transactions(n_accounts=300, seed=0)   # whole accounts, with frauds in runs
    df = make_scores(df)                             # adds a made-up model score
    numbers = write_files(df, "some/folder", n_files=4)   # numbered files, whole accounts in each
The test is additions/tests/test_common.py.
"""
from pathlib import Path

import numpy as np
import pandas as pd

from additions import settings
from additions.common import tables


def make_transactions(n_accounts=300, days=61, start=None, seed=0, fraud_account_share=0.08,
                      rows_per_day=1.3, tie_share=0.03):
    """A made-up transaction table with one row per transaction.

    n_accounts            number of accounts
    days                  length of the period, counted from `start`
    start                 first day (text); the default is the first day of the evaluation files
    fraud_account_share   share of accounts that get one fraud run
    rows_per_day          average number of transactions per account and day
    tie_share             share of rows that are moved onto the second of the row before them

    The columns are the ones named in settings (optional columns set to None are left out).
    """
    rng = np.random.default_rng(seed)
    start = pd.Timestamp(start or settings.EVAL_HISTORY_START)
    t0 = int(start.timestamp())
    span = int(days) * 86_400
    rows = []
    n_merchants = max(50, n_accounts // 2)
    merchant_mcc = rng.integers(1000, 1040, n_merchants)          # every merchant has one category
    merchant_state = rng.integers(0, 12, n_merchants)
    for a in range(n_accounts):
        n = max(3, rng.poisson(rows_per_day * days))
        t = np.sort(rng.integers(t0, t0 + span, n))
        # An account keeps going back to a few "home" merchants and sometimes tries a new one.
        home = rng.integers(0, n_merchants, 5)
        merchant = np.where(rng.random(n) < 0.8, home[rng.integers(0, 5, n)], rng.integers(0, n_merchants, n))
        amount = np.round(rng.lognormal(3.0, 1.0, n), 2)
        score = np.clip(rng.normal(12, 8, n), 0, 99)
        reason = np.where(rng.random(n) < 0.04, settings.FUNDS_DECLINE_REASONS[0], settings.APPROVED_REASONS[0]).astype(object)
        label = np.zeros(n, dtype=np.int64)
        if rng.random() < fraud_account_share and n > 8:
            # A fraud run: several transactions close together at merchants the account never
            # used, with a higher risk score. Some attempts are declined for risk; those rows
            # never carry the fraud label, exactly as in real files.
            k = int(rng.integers(2, 9))
            first = int(rng.integers(n // 3, n - 1))
            run_t = t[first] + np.sort(rng.integers(30, 6 * 3600, k))
            run_merchant = rng.integers(0, n_merchants, k)
            run_amount = np.round(rng.lognormal(4.0, 1.2, k), 2)
            run_score = np.clip(rng.normal(55, 20, k), 0, 99)
            declined = rng.random(k) < 0.25
            run_reason = np.where(declined, rng.choice(settings.RISK_DECLINE_REASONS, k), settings.APPROVED_REASONS[0]).astype(object)
            t = np.concatenate([t, run_t])
            merchant = np.concatenate([merchant, run_merchant])
            amount = np.concatenate([amount, run_amount])
            score = np.concatenate([score, run_score])
            reason = np.concatenate([reason, run_reason])
            label = np.concatenate([label, (~declined).astype(np.int64)])
        order = np.argsort(t, kind="stable")
        t, merchant, amount, score, reason, label = (x[order] for x in (t, merchant, amount, score, reason, label))
        n = len(t)
        # Put some rows on the second of the row before them, to create same-second ties.
        tie = rng.random(n) < tie_share
        tie[0] = False
        for i in np.flatnonzero(tie):
            t[i] = t[i - 1]
        advice = rng.random(n) < 0.04
        zero_check = rng.random(n) < 0.01
        label[advice | zero_check] = 0                              # these row types never carry the label
        amount[zero_check] = 0.0
        balance = np.round(np.abs(rng.normal(1500, 900, n)) + 5, 2)
        frame = {
            settings.ACCOUNT_COL: np.full(n, f"acct{a:05d}"),
            settings.TIME_COL: pd.to_datetime(t, unit="s"),
            settings.ORDER_COL: np.arange(n),
            settings.LABEL_COL: label,
            settings.AMOUNT_COL: amount,
            settings.VISA_SCORE_COL: np.round(score),
            settings.BALANCE_COL: balance,
            settings.MERCH_LIMIT_COL: np.round(np.abs(rng.normal(2500, 500, n)), 2),
            settings.CASH_LIMIT_COL: np.round(np.abs(rng.normal(500, 100, n)), 2),
            settings.MERCHANT_COL: merchant,
            settings.MCC_COL: merchant_mcc[merchant],
            settings.MERCHANT_POSTAL_COL: 10000 + merchant,
            settings.MERCHANT_STATE_COL: merchant_state[merchant],
            settings.MERCHANT_COUNTRY_COL: np.where(rng.random(n) < 0.97, "840", "124"),
            settings.REASON_COL: reason,
            settings.DECLINE_FLAG_COL: (reason != settings.APPROVED_REASONS[0]).astype(np.int64),
            settings.ADVICE_COL: np.where(advice, "A", None),
            settings.TYPE_COL: np.where(zero_check, settings.ZERO_CHECK_TYPES[0], rng.choice(["P", "C", "W"], n)),
            settings.SEGMENT_COL: rng.choice(["1. POS", "2. ECOM", "3. ATM"], n),
            settings.CARD_PRESENT_COL: rng.choice(["Y", "N"], n),
        }
        for optional in (settings.CARD_COL, settings.TERMINAL_COL, settings.DEVICE_COL, settings.TOKEN_COL, settings.IP_COL):
            if optional is not None:
                frame[optional] = rng.integers(0, 6, n)
        rows.append(pd.DataFrame(frame))
    df = pd.concat(rows, ignore_index=True)
    # Declined rows can never be fraud-tagged; make sure the made-up data keeps that property.
    df.loc[df[settings.DECLINE_FLAG_COL] == 1, settings.LABEL_COL] = 0
    df[settings.ID_COL] = np.arange(len(df)) + 1_000_000
    return df


def make_scores(df, seed=0, strength=2.5, noise=1.0, column=None):
    """A made-up model score: a probability that is higher on fraud rows and inside fraud runs.

    The score is not meant to be realistic, only to rank frauds above most other rows, so
    that tools which read a score have something sensible to work with. `strength` moves the
    fraud rows up; `noise` is the spread of all rows.
    """
    rng = np.random.default_rng(seed)
    y = df[settings.LABEL_COL].to_numpy()
    visa = df[settings.VISA_SCORE_COL].to_numpy(dtype=float)
    logit = -6.0 + strength * y + 0.03 * (visa - 12) + noise * rng.normal(size=len(df))
    out = df.copy()
    out[column or settings.SCORE_COL] = 1.0 / (1.0 + np.exp(-logit))
    return out


def make_vectors(df, dim=8, seed=0):
    """Made-up exported vectors: `dim` columns named with the vector prefix from settings.

    The first coordinate carries most of the fraud signal and the others carry noise and a
    little signal, which is enough for tools that fit something on the vectors.
    """
    rng = np.random.default_rng(seed)
    y = df[settings.LABEL_COL].to_numpy(dtype=float)
    out = df.copy()
    for j in range(dim):
        out[f"{settings.VECTOR_PREFIX}{j}"] = rng.normal(size=len(df)) + (1.5 if j == 0 else 0.2) * y
    return out


def add_profile_dates(df, seed=0):
    """Three made-up date columns that behave in three different ways.

    profile_asof_dt       a date that is always before the transaction and changes over time
                          inside an account (it was stamped when the transaction happened)
    profile_static_dt     a date that never changes inside an account (for example an opening date)
    profile_snapshot_dt   a date written when the file was extracted: on accounts with fraud it
                          lies after the fraud, so it gives the label away

    Returns the table with the three columns and the list of their names. A tool that audits
    date columns should tell these three apart.
    """
    rng = np.random.default_rng(seed)
    out = df.copy()
    t = pd.to_datetime(out[settings.TIME_COL])
    account = out[settings.ACCOUNT_COL]
    out["profile_asof_dt"] = (t - pd.to_timedelta(rng.integers(1, 40, len(out)), unit="D")).dt.floor("D")
    opened = {a: pd.Timestamp("2020-01-01") + pd.Timedelta(days=int(rng.integers(0, 1500))) for a in account.unique()}
    out["profile_static_dt"] = account.map(opened)
    last = t.groupby(account).transform("max")
    has_fraud = out.groupby(settings.ACCOUNT_COL)[settings.LABEL_COL].transform("max") == 1
    # Series.where keeps the column a date column in every pandas version (numpy.where would mix types).
    out["profile_snapshot_dt"] = (last + pd.Timedelta(days=3)).where(has_fraud, pd.Timestamp("2021-06-01"))
    return out, ["profile_asof_dt", "profile_static_dt", "profile_snapshot_dt"]


def write_files(df, folder, n_files=4, first_number=1):
    """Write the table as numbered parquet files that each hold whole accounts.

    Accounts are dealt out to the files in turn, so no account appears in two files. Returns
    the list of file numbers written.
    """
    Path(folder).mkdir(parents=True, exist_ok=True)
    accounts = pd.unique(df[settings.ACCOUNT_COL])
    which = {a: i % n_files for i, a in enumerate(accounts)}
    part = df[settings.ACCOUNT_COL].map(which).to_numpy()
    numbers = []
    for i in range(n_files):
        number = first_number + i
        tables.write_table(df.loc[part == i].reset_index(drop=True), tables.file_path(folder, number))
        numbers.append(number)
    return numbers
