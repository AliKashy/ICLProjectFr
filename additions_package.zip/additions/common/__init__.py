"""Shared helpers used by the other folders.

tables.py     reading and writing parquet files, a few columns at a time
timekeys.py   whole-second time keys and stable sorting of rows by account and time
history.py    the "strictly earlier rows" engine: counts, sums, maxima and decayed sums
ranking.py    the alert cut, capture of frauds and dollars at the cut, average precision
bootstrap.py  paired bootstrap that resamples whole accounts (or days, or clusters)
synthetic.py  made-up transactions for the tests and the examples
"""
