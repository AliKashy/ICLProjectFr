"""Paired bootstrap that resamples whole units (accounts, days or clusters).

What this file does
-------------------
It compares two score columns on the same rows and says how far apart their capture at the
alert cut is, with an interval. Rows are not resampled one by one: whole accounts are drawn
with replacement, and both models are read on the same draw.

Why it exists
-------------
Frauds come in runs on the same account, so rows of one account are not independent pieces
of evidence. Resampling single rows would make intervals look much narrower than they are.
Resampling accounts keeps each run together. Reading both models on the same draw (a paired
read) removes the part of the noise that the two models share, which is most of it when the
models are similar. The same function can resample days or merchant clusters instead, which
is a harder test when fraud arrives in waves.

Where it goes
-------------
After scoring, whenever two variants are compared: a new feature against the control, an
export arm against its base, one model against another.

What to change for the pod
--------------------------
The defaults come from settings (number of draws, seed, interval, cut size).

Speed
-----
Only the top of each ranking can ever be inside the cut, so each draw works on a few times
the cut size instead of on all rows. If a draw would need more rows than that head, the head
grows and the draw is repeated, so the answer is always exact.

How to try it
-------------
    units = timekeys.codes(df[settings.ACCOUNT_COL])
    result = paired_bootstrap(units, labels, scores_a, scores_b)
    print(result["gain"], result["low"], result["high"])
The test is additions/tests/test_common.py.
"""
import numpy as np

from additions import settings
from additions.common.timekeys import codes


def _order(scores):
    """Row positions from the highest score to the lowest (stable for equal scores).

    The sort is done once per score column. Each draw then only looks at the first rows of
    this order, which is what keeps thousands of draws cheap.
    """
    return np.argsort(-np.asarray(scores, dtype=np.float64), kind="stable")


def _caught(weights_head, gain_head, scores_head, target, complete):
    """Weighted gain of the rows needed to fill `target` weight, ties at the cut credited evenly.

    The rows that share the score at the cut are credited in proportion to the places left
    for them, exactly as `ranking.capture` does, so the full-data figure equals its "caught".
    Returns None when the head does not hold enough weight to reach the target, or when the
    tie at the cut may continue past the end of the head (`complete` is False).
    """
    cum = np.cumsum(weights_head)
    if len(cum) == 0 or cum[-1] < target:
        return None
    last = int(np.searchsorted(cum, target, side="left"))   # first row at which the target is reached
    threshold = scores_head[last]
    same = (scores_head == threshold) | (np.isnan(scores_head) & np.isnan(threshold))
    if same[-1] and not complete:
        return None                                          # the tie may go on beyond the head
    above = np.zeros(len(same), dtype=bool)
    above[:last] = ~same[:last]                              # sorted from high to low: before the tie
    w_tied = float(weights_head[same].sum())
    share = (target - float(weights_head[above].sum())) / w_tied if w_tied > 0 else 0.0
    weighted = weights_head * gain_head
    return float(weighted[above].sum() + share * weighted[same].sum())


def paired_bootstrap(units, labels, scores_a, scores_b, amounts=None, per_mille=None, draws=None,
                     seed=None, interval=None, rounding=None, value=False):
    """Difference in capture at the cut between score A and score B, with an interval.

    units      one value per row naming what is resampled (the account, or a day, or a cluster)
    labels     1 for fraud, 0 otherwise
    scores_a   the candidate's score; scores_b the control's score
    value      False compares the share of frauds caught; True compares the share of fraud
               dollars caught (then `amounts` is needed)

    Returns a dict: a and b (capture of each on the full data), gain (a minus b), low and high
    (the interval of the gain over the draws), se (its standard deviation over the draws),
    share_above_zero (how often the gain was positive) and draws (the number used).
    """
    per_mille = settings.OUTSORT_PER_MILLE if per_mille is None else per_mille
    rounding = settings.OUTSORT_ROUNDING if rounding is None else rounding
    draws = settings.BOOTSTRAP_DRAWS if draws is None else draws
    seed = settings.BOOTSTRAP_SEED if seed is None else seed
    interval = settings.INTERVAL_PERCENT if interval is None else interval
    y = np.asarray(labels).astype(np.float64)
    gain_per_row = y if not value else y * np.nan_to_num(np.asarray(amounts, dtype=np.float64), nan=0.0)
    u = codes(np.asarray(units))
    n, n_units = len(y), int(u.max()) + 1 if len(u) else 0
    rows_per_unit = np.bincount(u, minlength=n_units).astype(np.float64)
    gain_per_unit = np.bincount(u, weights=gain_per_row, minlength=n_units)
    k = (n * per_mille) // 1000 if rounding == "floor" else -(-(n * per_mille) // 1000)
    head_size = min(n, 4 * k + 1000)
    rng = np.random.default_rng(seed)

    order_a, order_b = _order(scores_a), _order(scores_b)
    sorted_a = np.asarray(scores_a, dtype=np.float64)[order_a]
    sorted_b = np.asarray(scores_b, dtype=np.float64)[order_b]

    def one(order, mult, target, size):
        ranked = sorted_a if order is order_a else sorted_b
        while True:
            head = order[:size]
            got = _caught(mult[u[head]], gain_per_row[head], ranked[:size], target, size >= n)
            if got is not None or size >= n:
                return got if got is not None else float((mult[u] * gain_per_row).sum()), size
            size = min(n, size * 2)

    full = np.ones(n_units)
    total_full = float(gain_per_row.sum())
    a_full, _ = one(order_a, full, float(k), head_size)
    b_full, _ = one(order_b, full, float(k), head_size)
    gains = []
    size_a = size_b = head_size
    for _ in range(int(draws)):
        mult = rng.multinomial(n_units, np.full(n_units, 1.0 / n_units)).astype(np.float64)
        total = float((mult * gain_per_unit).sum())
        if total <= 0:
            continue                                   # a draw with no fraud says nothing
        rows = float((mult * rows_per_unit).sum())
        target = float(int(rows * per_mille) // 1000) if rounding == "floor" else float(-(-int(rows * per_mille) // 1000))
        if target <= 0:
            continue
        ca, size_a = one(order_a, mult, target, size_a)
        cb, size_b = one(order_b, mult, target, size_b)
        gains.append((ca - cb) / total)
    gains = np.asarray(gains)
    tail = (100.0 - interval) / 2.0
    out = {"a": a_full / total_full if total_full > 0 else None,
           "b": b_full / total_full if total_full > 0 else None,
           "gain": (a_full - b_full) / total_full if total_full > 0 else None,
           "low": None, "high": None, "se": None, "share_above_zero": None, "draws": int(len(gains))}
    if len(gains):
        out.update(low=float(np.percentile(gains, tail)), high=float(np.percentile(gains, 100.0 - tail)),
                   se=float(gains.std(ddof=1)) if len(gains) > 1 else None,
                   share_above_zero=float((gains > 0).mean()))
    return out
