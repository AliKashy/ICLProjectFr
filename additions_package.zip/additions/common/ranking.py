"""The alert cut and what it catches.

What this file does
-------------------
Given a score per transaction it finds the top share of rows (0.6% by default), and reports
how many frauds and how many fraud dollars fall inside it. It also computes average precision,
turns probabilities into log-odds and gives every row its rank.

Why it exists
-------------
The decision measure is "of all frauds, what share is inside the alerted rows". The measure
is simple, but three details change the count by a few frauds, which is as much as the
difference between good models: how the number of alerted rows is rounded, what happens when
several rows share the score at the cut, and which rows are in the population. This file
makes the first two explicit. When rows tie at the cut, the frauds among them are credited
in proportion to the free places, and the lowest and highest possible counts are reported
beside that figure.

Where it goes
-------------
After scoring. Every read, every downstream comparison and the head-to-head tool use these
functions so that all of them count in the same way.

What to change for the pod
--------------------------
`settings.OUTSORT_PER_MILLE` (6 means the top 0.6%) and `settings.OUTSORT_ROUNDING`.

How to try it
-------------
    read = capture(labels, scores, amounts)        # frauds and fraud dollars inside the cut
    alerted = alert_mask(scores)                   # True for the rows inside the cut
    rows = capture_table(labels, scores, amounts)  # the same read at 0.6, 1 and 5 percent
    ranks = average_ranks(scores)                  # 1 for the lowest score, ties share a rank
The test is additions/tests/test_common.py.
"""
import numpy as np

from additions import settings


def cut_size(n_rows, per_mille=None, rounding=None):
    """Number of rows that may be alerted out of `n_rows`.

    The share is given in units of one per thousand, so 6 means 0.6%. Integer arithmetic is
    used on purpose: 0.006 * n in floating point can land just below a whole number.
    """
    per_mille = settings.OUTSORT_PER_MILLE if per_mille is None else per_mille
    rounding = settings.OUTSORT_ROUNDING if rounding is None else rounding
    exact = int(n_rows) * int(per_mille)
    return exact // 1000 if rounding == "floor" else -(-exact // 1000)


def to_logit(scores, kind=None):
    """Log-odds of a score. Probabilities are clipped away from 0 and 1 first."""
    kind = settings.SCORE_KIND if kind is None else kind
    s = np.asarray(scores, dtype=np.float64)
    if kind == "logit":
        return s
    p = np.clip(s, 1e-12, 1.0 - 1e-12)
    return np.log(p) - np.log1p(-p)


def average_ranks(values):
    """The rank of every row among all rows: 1 for the lowest score, and tied rows share the mean of their ranks.

    values   scores of shape [rows], or a matrix [rows, K] that is ranked column by column

    Returns float64 of the same shape. A missing score ranks last and missing scores tie with
    each other and with minus infinity, as in `capture`. The ranks are read off one sort of the
    values, so plus and minus infinity keep their places at the two ends; a library routine
    that first sums the values to look for missing ones loses every rank of a column that
    holds both.
    """
    v = np.asarray(values, dtype=np.float64)
    v = np.where(np.isnan(v), -np.inf, v)
    if v.ndim == 2:
        out = np.empty(v.shape, dtype=np.float64)
        for j in range(v.shape[1]):
            out[:, j] = average_ranks(v[:, j])
        return out
    n = len(v)
    if n == 0:
        return np.zeros(0, dtype=np.float64)
    order = np.argsort(v, kind="stable")
    ordered = v[order]
    starts_group = np.r_[True, ordered[1:] != ordered[:-1]]     # True where a new score begins in the sorted rows
    first = np.flatnonzero(starts_group)                         # sorted position (from 0) of the first row of each tie
    after = np.r_[first[1:], n]                                  # sorted position just after its last row
    shared = (first + 1 + after) / 2.0                           # mean of the ranks first + 1 ... after
    ranks = np.empty(n, dtype=np.float64)
    ranks[order] = shared[np.cumsum(starts_group) - 1]
    return ranks


def capture(labels, scores, amounts=None, per_mille=None, rounding=None):
    """What the top share of rows catches.

    Returns a dict with:
      rows, frauds, alerts          sizes of the population, of the fraud set and of the cut
      threshold                     the score of the last alerted row
      tied_rows                     rows that share that score (1 means no tie)
      caught, caught_min, caught_max   frauds inside the cut: with ties credited in proportion,
                                    and the fewest and the most that a tie order could give
      udr, udr_min, udr_max         the same three as a share of all frauds
      vdr                           share of fraud dollars inside the cut (None without amounts)
      false_per_true                non-fraud alerts per fraud alert
    """
    y = np.asarray(labels).astype(np.float64)
    s = np.asarray(scores, dtype=np.float64)
    s = np.where(np.isnan(s), -np.inf, s)      # a missing score ranks last; missing scores tie with each other
    n = len(s)
    k = cut_size(n, per_mille, rounding)
    frauds = float(y.sum())
    out = {"rows": n, "frauds": frauds, "alerts": k, "threshold": None, "tied_rows": 0,
           "caught": 0.0, "caught_min": 0.0, "caught_max": 0.0,
           "udr": None, "udr_min": None, "udr_max": None, "vdr": None, "false_per_true": None}
    if k <= 0 or n == 0:
        return out
    order = np.argsort(-s, kind="stable")
    threshold = s[order[k - 1]]
    above = s > threshold                      # rows that are inside the cut whatever the tie order
    tied = s == threshold                      # rows that share the score at the cut
    free = k - int(above.sum())                # places left for the tied rows
    n_tied = int(tied.sum())
    share = free / n_tied                      # each tied row's chance of being alerted
    caught_above = float(y[above].sum())
    tied_frauds = float(y[tied].sum())
    out.update(
        threshold=float(threshold), tied_rows=n_tied,
        caught=caught_above + tied_frauds * share,
        caught_min=caught_above + max(0.0, tied_frauds - (n_tied - free)),
        caught_max=caught_above + min(tied_frauds, float(free)),
    )
    if frauds > 0:
        out["udr"] = out["caught"] / frauds
        out["udr_min"] = out["caught_min"] / frauds
        out["udr_max"] = out["caught_max"] / frauds
    if out["caught"] > 0:
        out["false_per_true"] = (k - out["caught"]) / out["caught"]
    if amounts is not None:
        a = np.nan_to_num(np.asarray(amounts, dtype=np.float64), nan=0.0) * y   # fraud dollars per row
        total = float(a.sum())
        if total > 0:
            out["vdr"] = (float(a[above].sum()) + float(a[tied].sum()) * share) / total
    return out


def alert_mask(scores, per_mille=None, rounding=None):
    """A yes/no array marking exactly the alerted rows.

    Ties at the cut are settled by row order (the earlier row wins), which makes the mask
    repeatable. It is meant for tables that need a definite set of alerts, such as "which row
    types fill the cut". Reported capture figures should come from `capture`, which credits
    ties evenly.
    """
    s = np.asarray(scores, dtype=np.float64)
    k = cut_size(len(s), per_mille, rounding)
    mask = np.zeros(len(s), dtype=bool)
    if k > 0:
        mask[np.argsort(-s, kind="stable")[:k]] = True
    return mask


def average_precision(labels, scores):
    """Average precision (the area under the precision-recall curve), with tied scores grouped."""
    y = np.asarray(labels).astype(np.float64)
    s = np.asarray(scores, dtype=np.float64)
    total = y.sum()
    if total <= 0:
        return None
    order = np.argsort(-s, kind="stable")
    y, s = y[order], s[order]
    last_of_tie = np.r_[s[1:] != s[:-1], True]           # precision is read at the end of each tie
    tp = np.cumsum(y)[last_of_tie]
    seen = (np.arange(len(y)) + 1)[last_of_tie]
    gained = np.diff(np.concatenate(([0.0], tp)))        # frauds added by each group of tied rows
    return float((gained * tp / seen).sum() / total)


def capture_table(labels, scores, amounts=None, per_milles=(6, 10, 50), rounding=None):
    """`capture` at several cut sizes, as a list of dicts (one per cut size)."""
    rows = []
    for pm in per_milles:
        r = capture(labels, scores, amounts, pm, rounding)
        r["per_mille"] = pm
        rows.append(r)
    return rows
