"""Reading and writing parquet files.

What this file does
-------------------
It reads chosen columns of one file or of many numbered files into a pandas DataFrame, and
writes a DataFrame back to parquet. A column that is asked for but absent is skipped with a
printed line, so one script can serve file layouts that differ in their optional columns.

Why it exists
-------------
The raw files are wide (hundreds of columns) and long. Every tool in this package needs only
a handful of columns, and reading just those keeps memory and time small. Having one reader
also means the file naming and the remote-storage handle are set in a single place.

Where it goes
-------------
It is the first step of every CPU tool: raw rows in, a DataFrame out.

What to change for the pod
--------------------------
`settings.FILE_NAME` (how a file is named), `settings.FILESYSTEM` (a filesystem object for
remote storage, or None for local paths) and the base folders in settings.

How to try it
-------------
    df = read_files(settings.EVAL_BASE, range(8217, 8220), columns=[settings.ID_COL, settings.ACCOUNT_COL])
    write_table(df, "some/folder/out.parquet")
The test is additions/tests/test_common.py.
"""
from pathlib import Path

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

from additions import settings


def file_path(base, number, file_name=None):
    """The path of file `number` under `base`, built from the naming pattern in settings."""
    name = (file_name or settings.FILE_NAME).format(n=int(number))
    return str(base).rstrip("/") + "/" + name


def file_paths(base, numbers, file_name=None):
    """Paths of several numbered files, in the order given."""
    return [file_path(base, n, file_name) for n in numbers]


def available_columns(path, filesystem=None):
    """The column names stored in one parquet file (only the footer is read)."""
    fs = filesystem if filesystem is not None else settings.FILESYSTEM
    return list(pq.ParquetFile(path, filesystem=fs).schema_arrow.names)


def read_columns(path, columns=None, filesystem=None, quiet=False):
    """Read some columns of one parquet file.

    `columns` may hold None entries and names that the file does not have. Both are dropped:
    None entries silently (they stand for optional settings that are switched off), unknown
    names with one printed line. The result keeps the order of the request.
    """
    fs = filesystem if filesystem is not None else settings.FILESYSTEM
    if columns is None:
        return pq.read_table(path, filesystem=fs).to_pandas()
    wanted = [c for c in dict.fromkeys(columns) if c is not None]
    have = set(available_columns(path, fs))
    missing = [c for c in wanted if c not in have]
    if missing and not quiet:
        print(f"note: {path} has no column(s) {missing}; they are skipped")
    keep = [c for c in wanted if c in have]
    return pq.read_table(path, columns=keep, filesystem=fs).to_pandas()


def read_files(base, numbers, columns=None, filesystem=None, file_name=None, add_file_number=True):
    """Read the same columns from several numbered files and stack them.

    The file number of each row is kept in a column named `_file`, because many tools need to
    know which file a row came from (files hold whole accounts, so the file is also a clean
    unit for splitting data between fitting and reading).
    """
    frames = []
    for n in numbers:
        df = read_columns(file_path(base, n, file_name), columns, filesystem, quiet=bool(frames))
        if add_file_number:
            df["_file"] = int(n)
        frames.append(df)
    if not frames:
        return pd.DataFrame(columns=[c for c in (columns or []) if c is not None])
    return pd.concat(frames, ignore_index=True)


def write_table(df, path, filesystem=None):
    """Write a DataFrame to one parquet file. An existing file at the path is replaced."""
    fs = filesystem if filesystem is not None else settings.FILESYSTEM
    if fs is None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
    pq.write_table(pa.Table.from_pandas(df, preserve_index=False), path, filesystem=fs)
    return path
