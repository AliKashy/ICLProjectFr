"""Count-based surprise: how unusual is each value of a row, for this account and for everyone?

What this file does
-------------------
It scores the surprise of a row field by field. The fields are the chosen code columns plus
three made from the row: the amount bin, the hour of the day and the bin of the time gap to
the account's previous row. For each field it writes (names carry the prefix `surprise_`):

    <field>_account        -log of the smoothed share of the row's value among the account's strictly
                           earlier rows inside the look-back
    <field>_population     -log of the value's share in a population table fitted on training rows
    <field>_diff           the first minus the second: "unusual for this account" with "rare for
                           everyone" taken out
    <field>_given_previous for two fields only: -log P(value | value on the account's previous row),
                           from a population table of transitions

and over all fields: `account_sum`, `account_max`, `population_sum`, `diff_sum`, `diff_max`,
`fields_used` (how many fields had a value), and `account_z` and `diff_z`, the two sums
standardised by the mean and the spread of the same sum on the account's own earlier rows.
All surprises are in natural-log units; 0.69 more means half as likely.

The smoothed share pulls an account's share toward the population share:

    share_account = (earlier rows with this value + prior_rows * share_population)
                    / (earlier rows with any value + prior_rows)

An account with two earlier rows has not shown a habit yet, and without the pull a value it
has not used would get a share of zero and an infinite surprise. With the pull, an account
with no history gets exactly the population share, so its `diff` is 0: there is no evidence
either way. As history grows the account's own counts take over.

`fit_surprise_tables` builds the population tables; `build_surprise` applies them.

Why it exists
-------------
A fraud run rarely looks impossible in general; it looks unlike the account. A cash
withdrawal at 3 a.m. is common enough across all accounts and still a break of pattern for
an account that only ever shops online in the afternoon. A tree model cannot work out "how
often has this account shown this value" from the raw fields of one row, and a network that
reads a short window of history sees too few rows to count over weeks. The surprise columns
hand both a ready measure.

The difference column matters because raw surprise is dominated by values that are rare
for everyone, which a supervised model already knows from the field itself. Taking the
population surprise out leaves the part that is about this account. The standardised sum
adds the account's own yardstick: an account whose rows are always varied is less alarming
at a given surprise than an account that never varies. Because standardising rests on few
rows early in an account's history, the raw sum and the standardised sum are both written
and the standardised one is missing until enough earlier rows exist.

No label is read anywhere, so the tables can be fitted on the newest files and label delay
does not matter. The files hold whole accounts, so an account's own counts are complete
however few accounts were read.

Where it goes
-------------
Raw files, then these feature columns, then the network (extra numeric inputs, appended in
the per-file step that is `SequenceBuilder._encode_file` in the original code, each one a
numeric token of `FeatureTokenizer`) or a second-stage tree model. The columns keep their
meaning and their unit when the network is retrained, which makes them suitable for an
export. The population tables are fitted once, saved, and loaded at scoring.

What to change for the pod
--------------------------
`settings.CODE_COLS` is the default list of code fields: replace it by the code inputs of
the model in use, or pass `code_cols`. A surprise column reads the field's own value, so
only fields that are inputs anyway belong in the list; decision fields of the row itself
(response code, decline flag) must stay out. `AMOUNT_BIN_EDGES` below depends on the
currency. `TRANSITION_FIELDS` names the two fields that get the given-the-previous-value
column. Fit the tables on training rows (`settings.TRAIN_BASE`, `TRAIN_FILES`), which lie
before the scored month, never on the rows being scored. When the tables are applied to the
very rows they were fitted on, pass `remove_own_account=True` (on the command line,
--remove-own-account): each row is then compared with other accounts only, as it will be on
new files. If the mix of values drifts from month to month, fit the tables on the months
that were complete before the rows they are applied to.

How to try it
-------------
    python additions/features/surprise.py --demo
    python additions/features/surprise.py --fit-base /train --fit-files 1 2 3 --base /eval --files 8217 8218

Add `--save-tables surprise.json` to keep the fitted tables, `--tables surprise.json` to load
them next time in place of fitting, and `--out surprise.parquet` to write the columns.

    fitted = fit_surprise_tables(train_df)
    columns = build_surprise(df, fitted)                     # df: whole files
    python -m pytest -q additions/tests/test_features_surprise.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np

from additions import settings
from additions.common.history import EarlierRows
from additions.common.timekeys import MISSING_SECOND
from additions.features import _shared

# PLACEHOLDER: upper edges of the amount bins, in the currency of the files. The first bin holds zero
# and negative amounts (zero-dollar checks, refunds); the last one everything above the last edge.
AMOUNT_BIN_EDGES = (0.0, 1.0, 5.0, 10.0, 25.0, 50.0, 100.0, 250.0, 500.0, 1_000.0, 2_500.0, 5_000.0, 10_000.0)

# Upper edges of the time-gap bins, in seconds: one minute, ten minutes, one hour, six hours, one day,
# three days, one week, two weeks, thirty days.
GAP_BIN_EDGES = (60, 600, 3_600, 21_600, 86_400, 259_200, 604_800, 1_209_600, 2_592_000)

# PLACEHOLDER: the two code fields that get the "given the previous value" column. The second name is
# not in settings.py; put the column that holds the transaction category here.
TRANSITION_FIELDS = (settings.TYPE_COL, "transaction_category_xcd")

# A spread below this is treated as "the account never varies": no standardised value is written.
MIN_SPREAD = 1e-3


def needed_columns():
    """The raw columns this builder reads."""
    return [settings.ACCOUNT_COL, settings.TIME_COL, settings.ID_COL, settings.AMOUNT_COL, *settings.CODE_COLS]


def _binned(values, edges):
    """A number per row turned into a bin: (codes, texts), codes int64 [rows] with -1 for a missing number.

    Bin k holds the values up to and including edges[k] (and above the edge before it); one
    more bin holds everything above the last edge. The texts name the bins.
    """
    values = np.asarray(values, dtype=np.float64)
    have = ~np.isnan(values)
    codes = np.full(len(values), -1, dtype=np.int64)
    codes[have] = np.searchsorted(np.asarray(edges, dtype=np.float64), values[have], side="left")
    texts = np.array([f"up to {edge:g}" for edge in edges] + [f"over {edges[-1]:g}"], dtype=object)
    return codes, texts


def _prepare(df, code_cols, account_col, time_col, amount_col, months_back, amount_edges, gap_edges):
    """Everything fit and build share: (account, secs, engine, fields).

    `engine` is the account's history inside the look-back. `fields` is {name: (codes, texts)}
    with one code per row (-1: the row has no value for the field). The gap bin of a row is the
    bin of the seconds since the account's previous row inside the look-back; the account's
    first row there has no gap and so no value for that field.
    """
    account, secs = _shared.account_and_time(df, account_col, time_col)
    engine = EarlierRows(account, secs, start=_shared.history_start(secs, months_back))
    wanted = {name: name for name in (settings.CODE_COLS if code_cols is None else code_cols)}
    fields = {name: _shared.coded_text(values)
              for name, values in _shared.columns(df, wanted, "surprise fields").items()}
    amount = _shared.column(df, _shared.pick(amount_col, "AMOUNT_COL"), "the amount-bin field", numeric=True)
    if amount is not None:
        fields["amount_bin"] = _binned(amount, amount_edges)
    hour = np.where(secs == MISSING_SECOND, -1, (secs // 3_600) % 24)
    fields["hour"] = (hour.astype(np.int64), np.array([str(h) for h in range(24)], dtype=object))
    fields["gap_bin"] = _binned(engine.seconds_since_last(), gap_edges)
    return account, secs, engine, fields


def fit_surprise_tables(df, code_cols=None, transition_fields=None, account_col=None, time_col=None,
                        amount_col=None, months_back=1, amount_edges=None, gap_edges=None):
    """Count how often each value of each field occurs, and how often each value follows each other value.

    df   the rows the tables are fitted on: training rows, never the rows that will be scored.
         The other arguments are as in `build_surprise`; `amount_edges` and `gap_edges` default
         to the constants at the top of this file.

    Returns a plain dictionary that `_shared.save_tables` can write to a file:
        "fields"        {field: {"counts": {value: rows}, "rows": rows with a value}}
        "transitions"   {field: {"pairs": table of "previous > current", "previous": table of previous values}}
        "amount_edges", "gap_edges"   the bin edges, kept so that scoring bins the same way
    The tables hold frequencies of values. They hold no label and no account.
    """
    amount_edges = [float(e) for e in (AMOUNT_BIN_EDGES if amount_edges is None else amount_edges)]
    gap_edges = [float(e) for e in (GAP_BIN_EDGES if gap_edges is None else gap_edges)]
    _, _, engine, fields = _prepare(df, code_cols, account_col, time_col, amount_col, months_back,
                                    amount_edges, gap_edges)
    fitted = {"fields": {}, "transitions": {}, "amount_edges": amount_edges, "gap_edges": gap_edges}
    for name, (codes, texts) in fields.items():
        fitted["fields"][name] = _shared.count_table(codes, texts)
    for name in (TRANSITION_FIELDS if transition_fields is None else transition_fields):
        if name not in fields:
            print(f"note: no field '{name}' in the table; its transition table is skipped")
            continue
        codes, texts = fields[name]
        pair, pair_texts, previous = _shared.previous_pairs(engine, codes, texts)
        fitted["transitions"][name] = {"pairs": _shared.count_table(pair, pair_texts),
                                       "previous": _shared.count_table(previous, texts)}
    return fitted


def _standardised(by_account, values, min_rows):
    """(value - mean of the account's earlier values) / their spread; missing where that is not defined.

    The mean and the mean of squares come from the account's strictly earlier rows, so the
    yardstick of a row never contains the row. Fewer than `min_rows` earlier values, or a
    spread of nearly zero, give a missing value: a yardstick made of three rows is noise.
    """
    mean = by_account.mean(values)
    spread = np.sqrt(np.clip(by_account.mean(values ** 2) - mean ** 2, 0.0, None))
    enough = by_account.count(where=~np.isnan(values)) >= min_rows
    z = _shared.ratio(values - mean, np.where(spread > MIN_SPREAD, spread, np.nan))
    return np.where(enough, z, np.nan)


def build_surprise(df, fitted, code_cols=None, transition_fields=None, account_col=None, time_col=None,
                   amount_col=None, months_back=1, prior_rows=5.0, min_rows_for_z=20, remove_own_account=False,
                   prefix="surprise_", fill=None):
    """Surprise columns for every row of `df`.

    df            every row of one or more whole files (whole account histories), in any order
    fitted        the tables from `fit_surprise_tables`
    code_cols     the code fields to score; None reads settings.CODE_COLS. A field that is not in the
                  table of rows or not in the fitted tables is skipped with one printed line
    transition_fields   the fields that get the given-the-previous-value column; None reads `TRANSITION_FIELDS`
    account_col, time_col, amount_col   column names; None reads them from settings
    months_back   the look-back starts on the first day of the month this many months before the row's
                  month; None means no limit
    prior_rows    strength of the pull toward the population share, in imaginary earlier rows
    min_rows_for_z      earlier rows an account needs before the standardised sums are written
    remove_own_account  True when `df` holds the rows the tables were fitted on: the row's own account
                  is then taken out of every population count
    prefix        put in front of every column name
    fill          None keeps missing values; a number replaces them

    Returns a float DataFrame [rows, 3 per field + 8 + 1 per transition field] with the index
    of `df`. A field without a value on a row gives missing values there and adds nothing to
    the sums; a row without a time or an account gets missing values.

    Time rule: the account's counts use rows of the same account in strictly earlier seconds,
    not before the look-back start; rows of the same second never see each other. The
    population tables come from other rows altogether. The columns are computed block by
    block (see _shared.blockwise), because the standardised sums rest on the sums of earlier
    rows, and an earlier row must not remember more than the row that reads it.
    """
    account, secs, engine, fields = _prepare(df, code_cols, account_col, time_col, amount_col, months_back,
                                             fitted["amount_edges"], fitted["gap_edges"])
    # The population share of every row's value, once for the whole table.
    shares = {}
    for name, (codes, texts) in fields.items():
        if name in fitted["fields"]:
            own, own_rows = _shared.own_counts(account, codes) if remove_own_account else (None, None)
            shares[name] = _shared.table_share(codes, texts, fitted["fields"][name], own, own_rows)
    unfitted = [name for name in fields if name not in shares]
    if unfitted:
        print(f"note: the fitted tables have no field(s) {unfitted}; they are skipped")

    def one_block(rows):
        """The columns of the rows of one block, computed as if the block were the whole table."""
        by_account = EarlierRows(account[rows], secs[rows])
        has_gap = ~np.isnan(by_account.seconds_since_last())
        n = len(rows)
        out = {}
        used = np.zeros(n)
        total = {kind: np.zeros(n) for kind in ("account", "population", "diff")}
        largest = {kind: np.full(n, -np.inf) for kind in ("account", "diff")}
        for name, share_of_all_rows in shares.items():
            codes, share = fields[name][0][rows], share_of_all_rows[rows]
            if name == "gap_bin":
                # The account's first row inside the block has no earlier row here, so it has no gap.
                codes, share = np.where(has_gap, codes, -1), np.where(has_gap, share, np.nan)
            n_same = _shared.key_engine(account[rows], codes, secs[rows]).count()
            n_any = by_account.count(where=codes >= 0)
            surprise = {"account": -np.log((n_same + prior_rows * share) / (n_any + prior_rows)),
                        "population": -np.log(share)}
            surprise["diff"] = surprise["account"] - surprise["population"]
            has_value = codes >= 0
            used += has_value
            for kind, values in surprise.items():
                out[f"{prefix}{name}_{kind}"] = values
                total[kind][has_value] += values[has_value]
                if kind in largest:
                    largest[kind] = np.fmax(largest[kind], values)       # fmax skips the missing ones
        nothing = used == 0
        for kind in total:
            total[kind][nothing] = np.nan
            out[f"{prefix}{kind}_sum"] = total[kind]
        for kind in largest:
            out[f"{prefix}{kind}_max"] = np.where(nothing, np.nan, largest[kind])
        out[prefix + "fields_used"] = used
        out[prefix + "account_z"] = _standardised(by_account, total["account"], min_rows_for_z)
        out[prefix + "diff_z"] = _standardised(by_account, total["diff"], min_rows_for_z)
        return out

    out = _shared.blockwise(secs, months_back, one_block)

    # The first-order version: how likely is this value right after the value on the account's previous row?
    # The conditional share is pulled toward the unconditional one in the same way as above, so a previous
    # value that was rare in the fitted rows does not produce a wild estimate.
    for name in (TRANSITION_FIELDS if transition_fields is None else transition_fields):
        if name not in shares or name not in fitted["transitions"]:
            print(f"note: no field or no fitted transition table for '{name}'; its given-previous column is skipped")
            continue
        codes, texts = fields[name]
        pair, pair_texts, previous = _shared.previous_pairs(engine, codes, texts)
        own_pair = _shared.own_counts(account, pair)[0] if remove_own_account else None
        own_previous = _shared.own_counts(account, previous)[0] if remove_own_account else None
        n_pair = _shared.table_counts(pair, pair_texts, fitted["transitions"][name]["pairs"], own_pair)
        n_previous = _shared.table_counts(previous, texts, fitted["transitions"][name]["previous"], own_previous)
        conditional = (n_pair + prior_rows * shares[name]) / (n_previous + prior_rows)
        out[f"{prefix}{name}_given_previous"] = np.where(pair >= 0, -np.log(conditional), np.nan)
    return _shared.as_frame(out, df.index, fill)


def main(argv=None):
    """Command line: fit or load the tables, build the columns for some files and print a summary."""
    return _shared.run_builder(
        argv, "Count-based surprise of each row, for its account and for the population.", needed_columns(),
        build=lambda df, args, fitted: build_surprise(df, fitted, remove_own_account=args.remove_own_account),
        fit=lambda df, args: fit_surprise_tables(df))


if __name__ == "__main__":
    main()
