"""Outcome history: what the bank decided on the account's EARLIER rows.

What this file does
-------------------
It sorts every row into one outcome family from the bank's decision columns: approved,
funds_decline (insufficient funds), risk_decline (declined by the fraud engine),
other_decline (any other refusal) or advice (a notice, not a live request). Then, for every
row, it describes the outcomes of the account's strictly earlier rows inside the look-back:

    prev_family                     family of the previous row (0 none, 1 approved, 2 funds_decline,
                                    3 risk_decline, 4 other_decline, 5 advice)
    n_<family>_1h, _24h, _7d        earlier rows of each family inside each window
    had_risk_decline, log_secs_since_risk_decline    the last risk decline: was there one, how long ago
    had_decline, log_secs_since_decline              the last decline of any kind
    n_zero_check_1h, _24h, _7d      earlier zero-dollar checks (when the type column is there)

and, at the same merchant, the same merchant category and the same country:

    <key>_n_declined_1h, _24h, _30d        earlier declined rows at this value
    <key>_share_declined_1h, _24h, _30d    the same as a share of the earlier attempts at this value
    <key>_had_decline, <key>_log_secs_since_decline   the last decline at this value
    <key>_first_approval_after_decline     1 when the latest earlier attempt at this value was declined:
                                           if this row is approved, it is the first approval there
                                           after one or more declines

Every column name carries the prefix `outcome_`. Durations are log(1 + seconds) and missing
when there was no such earlier row; the `had_` flags tell that case apart.

A row never reads its own decision. The decision columns of a row enter only two places:
the yes/no masks that say which EARLIER rows count, and the values read from EARLIER rows.
The history engine hands a row nothing from its own second, so neither the row's own
decision nor the decision on a row of the same second can reach it. The test proves it the
direct way: it changes the decision on one row per account (approved becomes a risk
decline, and the other way round), rebuilds everything, and checks that the columns of
those very rows are unchanged to the last digit, while the columns of later rows of the
same accounts do change.

Why it exists
-------------
A fraud label sits only on approved rows, so declined attempts are never labelled, and
fraud labels arrive weeks after the transaction. Inside a fraud run the model therefore
cannot be told "the previous row was fraud": nobody knows yet. What is known at once is
what the bank did. A risk decline ten minutes ago, three declines at one merchant followed
by an attempt at a lower amount, a zero-dollar check just before a large purchase: these are
facts of the past at the moment the next transaction is scored, and they are the lawful
substitute for label feedback. Frauds come in runs on one account, so most frauds follow
an earlier fraud of that account, and the bank's reaction to the earlier rows of the run is
the nearest thing to knowing that a run is under way.

The columns at the same merchant, category and country add what an account-wide count
cannot say. A mistyped PIN at the grocer and three refusals at the merchant that is being
charged right now are both "declines in the last hour"; only the second is card testing.
A first approval after declines at one place is the moment a card-testing run succeeds.

Where it goes
-------------
Raw files, then these feature columns, then the network (extra numeric inputs, appended in
the per-file step that is `SequenceBuilder._encode_file` in the original code, each one a
numeric token of `FeatureTokenizer`) or a second-stage tree model. `prev_family` is a code:
for the network it belongs with the categorical inputs (six values). `outcome_family` is
also meant for a model block that lets later rows read each row's outcome inside stage 2;
there, too, a row's own outcome must stay out of its own score.

What to change for the pod
--------------------------
`settings.REASON_COL` with `APPROVED_REASONS`, `RISK_DECLINE_REASONS` and `FUNDS_DECLINE_REASONS`;
`settings.DECLINE_FLAG_COL` with `DECLINE_FLAG_VALUES`; `settings.ADVICE_COL`; `settings.TYPE_COL`
with `ZERO_CHECK_TYPES`. Codes are compared as text, written exactly as the files store
them (a code stored as the number 5 is the text "5", not "05"). The mapping from raw
columns to families is the function `outcome_family`; replace it, or pass a ready-made
`family` array, if the pod tells outcomes apart in another way. Two points to confirm with
the data owner: that the decision columns are final at the time of the transaction (a
reversal reason written back onto the original row would be knowledge of the future), and
that advice rows are known at their own timestamp. The keys for the at-the-same-place
columns are `settings.MERCHANT_COL`, `MCC_COL` and `MERCHANT_COUNTRY_COL`; pass `keys` to
add a terminal column.

How to try it
-------------
    python additions/features/outcome_history.py --demo
    python additions/features/outcome_history.py --base /path/to/files --files 8217 8218 --out outcome.parquet

    columns = build_outcome_history(df)                      # df: whole files
    python -m pytest -q additions/tests/test_features_outcome_history.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np
import pandas as pd

from additions import settings
from additions.common.history import EarlierRows
from additions.features import _shared

# The outcome families and their codes. -1 means the outcome of a row is not known.
FAMILIES = ("approved", "funds_decline", "risk_decline", "other_decline", "advice")
APPROVED, FUNDS_DECLINE, RISK_DECLINE, OTHER_DECLINE, ADVICE = range(5)
UNKNOWN = -1

# Windows as (label, seconds): for the account-wide counts and for the counts at the same key.
FAMILY_WINDOWS = (("1h", 3_600), ("24h", 86_400), ("7d", 7 * 86_400))
KEY_WINDOWS = (("1h", 3_600), ("24h", 86_400), ("30d", 30 * 86_400))


def needed_columns():
    """The raw columns this builder reads (None entries are optional columns that are switched off)."""
    return [settings.ACCOUNT_COL, settings.TIME_COL, settings.ID_COL, settings.REASON_COL,
            settings.DECLINE_FLAG_COL, settings.ADVICE_COL, settings.TYPE_COL, *default_keys().values()]


def default_keys():
    """The keys of the at-the-same-place columns, as {short name: column name read from settings.py}."""
    return {"merchant": settings.MERCHANT_COL, "mcc": settings.MCC_COL, "country": settings.MERCHANT_COUNTRY_COL}


def _is_one_of(values, wanted):
    """(hit, known), both bool [rows]: is the row's value one of `wanted`, and does the row hold a value at all.

    Values are compared as text, so the number 1 and the text "1" are the same. A row with no
    value is never a hit.
    """
    codes, texts = _shared.coded_text(values)
    in_list = np.isin(texts.astype(str), [str(w).strip() for w in wanted])
    known = codes >= 0
    hit = np.zeros(len(codes), dtype=bool)
    hit[known] = in_list[codes[known]]
    return hit, known


# PLACEHOLDER: the rules that turn the raw decision columns into a family; change them here if the pod
# tells outcomes apart in another way (more families can be added to `FAMILIES`).
def outcome_family(df, reason_col=None, decline_flag_col=None, advice_col=None, approved_reasons=None,
                   risk_reasons=None, funds_reasons=None, decline_flag_values=None):
    """The outcome family of every row: int8 [rows] with 0..4 as in `FAMILIES` and -1 for unknown.

    The rules, the later ones overriding the earlier ones:
      1. a response code that is in none of the lists:     other_decline
      2. a response code from the approved list:           approved
      3. the decline flag is set:                          other_decline (declined before the fraud engine)
      4. a response code from the funds or the risk list:  funds_decline or risk_decline
      5. the advice column is filled:                      advice
    A row with no response code and no decline flag stays unknown and counts in no family.

    This is the row's OWN outcome. It may be shown to later rows only; it must never be joined
    to the row itself as an input. Returns None (after one printed line per missing column)
    when neither the response code nor the decline flag is available.
    """
    reason = _shared.column(df, _shared.pick(reason_col, "REASON_COL"),
                            "the response code (rows then count as approved unless the decline flag is set)")
    flag = _shared.column(df, _shared.pick(decline_flag_col, "DECLINE_FLAG_COL"), "the decline flag")
    advice = _shared.column(df, _shared.pick(advice_col, "ADVICE_COL"), "the advice family")
    if reason is None and flag is None:
        return None
    family = np.full(len(df), UNKNOWN, dtype=np.int8)
    if reason is None:
        family[:] = APPROVED
    else:
        approved, known = _is_one_of(reason, _shared.pick(approved_reasons, "APPROVED_REASONS"))
        family[known] = OTHER_DECLINE
        family[approved] = APPROVED
    if flag is not None:
        family[_is_one_of(flag, _shared.pick(decline_flag_values, "DECLINE_FLAG_VALUES"))[0]] = OTHER_DECLINE
    if reason is not None:
        # The response code says more than the flag, so it wins: a flagged row with the insufficient-funds
        # code is a funds decline.
        family[_is_one_of(reason, _shared.pick(funds_reasons, "FUNDS_DECLINE_REASONS"))[0]] = FUNDS_DECLINE
        family[_is_one_of(reason, _shared.pick(risk_reasons, "RISK_DECLINE_REASONS"))[0]] = RISK_DECLINE
    if advice is not None:
        family[_shared.value_codes(advice)[0] >= 0] = ADVICE
    return family


def build_outcome_history(df, keys=None, family=None, account_col=None, time_col=None, type_col=None,
                          zero_check_types=None, reason_col=None, decline_flag_col=None, advice_col=None,
                          months_back=1, prefix="outcome_", fill=None):
    """Outcome-history columns for every row of `df`.

    df           every row of one or more whole files (whole account histories), in any order
    keys         {short name: column name} for the at-the-same-place columns; None reads merchant,
                 merchant category and country from settings
    family       a ready-made outcome family per row (int [rows], -1 unknown, 0..4 as in `FAMILIES`);
                 None builds it with `outcome_family` from the three decision columns and the code
                 lists in settings. For other code lists, call `outcome_family` with them and pass
                 its result here
    account_col, time_col, type_col, reason_col, decline_flag_col, advice_col   column names; None reads settings
    zero_check_types   the values of the type column that mean a zero-dollar check; None reads settings
    months_back  the look-back starts on the first day of the month this many months before the row's
                 month; None means no limit
    prefix       put in front of every column name
    fill         None keeps missing values; a number replaces them

    Returns a DataFrame [rows, 20 + 3 with a type column + 9 per key] with the index of `df`;
    `prev_family` is a small integer, the rest are floats. With no decision column at all
    the function prints one line per column and returns a DataFrame with no columns.

    Time rule: every column is built from rows of the same account in strictly earlier
    seconds, not before the look-back start. The row's own decision, and the decisions on
    rows of the same second, are never read.
    """
    if family is None:
        family = outcome_family(df, reason_col, decline_flag_col, advice_col)
    if family is None:
        print("note: no decision column is available; no outcome-history columns are built")
        return pd.DataFrame(index=df.index)
    family = np.asarray(family)
    keys = default_keys() if keys is None else keys
    account, secs = _shared.account_and_time(df, account_col, time_col)
    start = _shared.history_start(secs, months_back)
    by_account = EarlierRows(account, secs, start=start)

    # One yes/no array per family. They are used only as `where=`: they pick which EARLIER rows count.
    in_family = [family == code for code in range(len(FAMILIES))]
    declined = in_family[FUNDS_DECLINE] | in_family[RISK_DECLINE] | in_family[OTHER_DECLINE]
    approved = in_family[APPROVED]
    attempt = declined | approved                 # advice rows and rows of unknown outcome are not attempts

    out = {}
    # The family of the latest strictly earlier row. When several rows share that second, the one that
    # comes last in the table is taken. 0 stands for "no earlier row" and for an earlier row of unknown outcome.
    out[prefix + "prev_family"] = np.asarray(by_account.last(family, default=UNKNOWN), dtype=np.int64) + 1
    for code, name in enumerate(FAMILIES):
        for label, window in FAMILY_WINDOWS:
            out[f"{prefix}n_{name}_{label}"] = by_account.count(window, where=in_family[code])
    for name, mask in (("risk_decline", in_family[RISK_DECLINE]), ("decline", declined)):
        since = by_account.seconds_since_last(where=mask)
        out[f"{prefix}had_{name}"] = ~np.isnan(since)
        out[f"{prefix}log_secs_since_{name}"] = np.log1p(since)

    # Zero-dollar checks are not a decision of the bank, but they belong to the same picture: a card being
    # tried out is often verified with a zero amount first. Only earlier rows are counted.
    kind = _shared.column(df, _shared.pick(type_col, "TYPE_COL"), "the zero-dollar check counts")
    if kind is not None:
        zero_check = _is_one_of(kind, _shared.pick(zero_check_types, "ZERO_CHECK_TYPES"))[0]
        for label, window in FAMILY_WINDOWS:
            out[f"{prefix}n_zero_check_{label}"] = by_account.count(window, where=zero_check)

    for name, values in _shared.columns(df, keys, "outcome columns at the same key").items():
        codes, _ = _shared.value_codes(values, _shared.KEY_TRANSFORMS.get(name))
        at_key = _shared.key_engine(account, codes, secs, start)
        p = f"{prefix}{name}_"
        for label, window in KEY_WINDOWS:
            n_declined = at_key.count(window, where=declined)
            out[f"{p}n_declined_{label}"] = n_declined
            # Declined attempts over all attempts at this value; missing when there was no attempt.
            out[f"{p}share_declined_{label}"] = _shared.ratio(n_declined, at_key.count(window, where=attempt))
        since_decline = at_key.seconds_since_last(where=declined)
        since_approval = at_key.seconds_since_last(where=approved)
        had_decline = ~np.isnan(since_decline)
        out[p + "had_decline"] = had_decline
        out[p + "log_secs_since_decline"] = np.log1p(since_decline)
        # "First approved attempt after one or more declines" cannot use the row's own outcome, so it is
        # written as a fact about the past: the latest earlier attempt at this value was a decline (there is
        # a decline, and no approval after it). If the row is then approved, it is that first approval. A
        # decline and an approval in the same earlier second cannot be ordered and do not raise the flag.
        no_later_approval = np.isnan(since_approval) | (since_decline < np.nan_to_num(since_approval, nan=np.inf))
        out[p + "first_approval_after_decline"] = had_decline & no_later_approval
    return _shared.as_frame(out, df.index, fill, codes=(prefix + "prev_family",))


def main(argv=None):
    """Command line: build the columns for some files (or for made-up rows) and print a summary."""
    return _shared.run_builder(
        argv, "Outcome history: the bank's decisions on the earlier rows of each account.", needed_columns(),
        build=lambda df, args: build_outcome_history(df))


if __name__ == "__main__":
    main()
