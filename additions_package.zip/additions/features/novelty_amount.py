"""Exact-value novelty: the joint template of the code fields, and the fine structure of the amount.

What this file does
-------------------
A template is the combination of all code fields of a row taken together: one code per
distinct combination. Two rows share a template when every code field is equal. For every
row the file writes three groups of columns (all names carry the prefix `novelty_`).

The template, from the population table and from the account's strictly earlier rows:

    template_pop_log_share          log of the template's share among the rows the table was fitted on
    template_seen                   1 when the account used this template before, inside the look-back
    template_n_30d, template_share_30d   the account's earlier uses in 30 days, as a count and as a share
    template_log_secs_since_first   log(1 + seconds since the account first used it)
    template_log_lift               log(account share / population share): how much more this account
                                    uses the template than everyone does
    template_distinct_30d           different templates the account used in 30 days

The pair (template of the account's previous row, template of this row), the same way:

    pair_pop_log_share, pair_seen, pair_n_30d, pair_share_30d, pair_log_secs_since_first

The amount:

    amount_cents                    the cents part, 0 to 99
    amount_whole, amount_multiple_5, amount_multiple_10, amount_multiple_100   round-amount flags
    amount_pop_log_share            log of the share of this exact amount in the population table
    amount_n_same_30d               the account's earlier rows with exactly this amount in 30 days
    amount_equals_previous          1 when the account's previous amount was exactly the same

and `has_earlier_row`, which tells "no earlier row" apart from "earlier rows, none alike".

`fit_novelty_tables` builds the three population tables (templates, pairs, exact amounts);
`build_novelty_amount` applies them.

Why it exists
-------------
A model that turns each row into one vector and reads a short stretch of history cannot
count exact joint matches over weeks: it sees that two rows are similar, not that this
exact way of paying (this channel, this entry mode, this verification result, together)
has never occurred on the account. Single-field novelty misses it too, because a fraud can
combine values that are each familiar into a combination that is not. The template columns
count exactly that. The lift says whether a template that is rare in general is usual for
this account, which is the benign reading of rarity. The pair adds order: the same two
templates in an unusual sequence.

Amounts carry structure that bins destroy. A card that is being tried out is often charged
small or round amounts; a subscription repeats the same amount to the cent; shopping
amounts end in arbitrary cents. The cents part, the round-amount flags, how common the
exact amount is and whether the account has paid exactly this before put that structure
into columns that both a tree model and a network can use.

The population tables hold frequencies of values, not fraud rates: no label is read, so
label delay does not matter, and a table fitted on a sample of accounts is only noisier
for rare values, not biased. The account's own counts are complete because the files hold
whole accounts.

Where it goes
-------------
Raw files, then these feature columns, then the network (extra numeric inputs, appended in
the per-file step that is `SequenceBuilder._encode_file` in the original code, each one a
numeric token of `FeatureTokenizer`) or a second-stage tree model. The columns are plain,
named and stable, so they also suit an export to other models. The tables are fitted
once on training rows, saved, and loaded at scoring.

What to change for the pod
--------------------------
`settings.CODE_COLS` is the default list of fields that make the template: replace it by the
code inputs of the model in use, or pass `code_cols`. Fields with very many values (a
merchant id) do not belong in a template; they would make every row its own template.
`MAX_TEMPLATES`, `MAX_PAIRS` and `MAX_AMOUNTS` bound the tables. `settings.AMOUNT_COL` is the
amount; the round-amount flags (`ROUND_AMOUNTS`) assume a currency with two decimals. Fit
the tables on training rows, which lie before the scored month, never on the rows being
scored. When the tables are applied to the rows they were fitted on, pass
`remove_own_account=True` (on the command line, --remove-own-account), or every rare amount
will look more common in training than it will at scoring, because each row counts itself.
Windows are 30 days because a scored row has between one and two months of history.

How to try it
-------------
    python additions/features/novelty_amount.py --demo
    python additions/features/novelty_amount.py --fit-base /train --fit-files 1 2 3 --base /eval --files 8217 8218

Add `--save-tables novelty.json` to keep the fitted tables, `--tables novelty.json` to load
them next time in place of fitting, and `--out novelty.parquet` to write the columns.

    fitted = fit_novelty_tables(train_df)
    columns = build_novelty_amount(df, fitted)               # df: whole files
    python -m pytest -q additions/tests/test_features_novelty_amount.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np

from additions import settings
from additions.common import timekeys
from additions.common.history import EarlierRows
from additions.features import _shared

# What joins the code values of one template into one text, as in "P|2. ECOM|N".
TEMPLATE_SEPARATOR = "|"

# The most frequent templates, pairs and exact amounts that are kept in the population tables. Anything
# outside a table is read as "never seen", which is nearly true for what was dropped.
MAX_TEMPLATES = 5_000
MAX_PAIRS = 20_000
MAX_AMOUNTS = 20_000

# PLACEHOLDER: the round-amount flags, as (name, step in cents), for a currency with two decimals.
ROUND_AMOUNTS = (("whole", 100), ("multiple_5", 500), ("multiple_10", 1_000), ("multiple_100", 10_000))

# The window of the account's own counts: 30 days, in seconds.
WINDOW = 30 * 86_400


def needed_columns():
    """The raw columns this builder reads."""
    return [settings.ACCOUNT_COL, settings.TIME_COL, settings.ID_COL, settings.AMOUNT_COL, *settings.CODE_COLS]


def _templates(df, code_cols):
    """The template of every row: (codes, texts), or None when the table holds none of the code fields.

    codes is int64 [rows], one integer per distinct combination of the code fields. Inside a
    template a missing code is a value of its own: which fields are empty is part of the
    shape of a transaction (a field that only card-present rows fill, say). Only a row with
    no code at all has no template (-1) and matches nothing. The text of a template is its
    code values joined by `TEMPLATE_SEPARATOR`; it is built once per distinct template, not
    once per row, and it is what the population table is keyed by.
    """
    wanted = {name: name for name in (settings.CODE_COLS if code_cols is None else code_cols)}
    parts = [_shared.coded_text(values) for values in _shared.columns(df, wanted, "template fields").values()]
    if not parts:
        return None
    combo = timekeys.codes(*[codes for codes, _ in parts])
    _, example = np.unique(combo, return_index=True)             # one example row for each template

    def text_of(row):
        """The code values of one row joined into one text; a missing code leaves its place empty."""
        return TEMPLATE_SEPARATOR.join(str(field_texts[field_codes[row]]) if field_codes[row] >= 0 else ""
                                       for field_codes, field_texts in parts)

    texts = np.array([text_of(row) for row in example], dtype=object)
    no_code_at_all = np.all([codes < 0 for codes, _ in parts], axis=0)
    return np.where(no_code_at_all, -1, combo), texts


def _prepare(df, code_cols, account_col, time_col, amount_col, months_back):
    """Everything fit and build share: (account, secs, template, pair, cents, amount).

    `template`, `pair` and `cents` are (codes, texts) pairs, or None when their columns are
    not there. The pair of a row joins the template of the account's previous row inside the
    look-back with the row's own template.
    """
    account, secs = _shared.account_and_time(df, account_col, time_col)
    template = _templates(df, code_cols)
    pair = None
    if template is not None:
        engine = EarlierRows(account, secs, start=_shared.history_start(secs, months_back))
        pair = _shared.previous_pairs(engine, template[0], template[1])[:2]
    amount = _shared.column(df, _shared.pick(amount_col, "AMOUNT_COL"), "the amount columns", numeric=True)
    # The amount in whole cents: exact comparison of amounts needs whole numbers, not decimals.
    cents = None if amount is None else _shared.coded_text(np.round(amount * 100.0))
    return account, secs, template, pair, cents, amount


def fit_novelty_tables(df, code_cols=None, account_col=None, time_col=None, amount_col=None, months_back=1,
                       max_templates=None, max_pairs=None, max_amounts=None):
    """Count how often each template, each pair of templates and each exact amount occurs.

    df   the rows the tables are fitted on: training rows, never the rows that will be scored.
         The other arguments are as in `build_novelty_amount`; the three `max_` arguments default
         to the constants at the top of this file.

    Returns a plain dictionary that `_shared.save_tables` can write to a file, with up to
    three tables ("templates", "pairs", "amounts"), each of the form
    {"counts": {text: rows}, "rows": rows with a value}. The amount table is keyed by the
    amount in whole cents. The tables hold frequencies of values, no label and no account.
    """
    _, _, template, pair, cents, _ = _prepare(df, code_cols, account_col, time_col, amount_col, months_back)
    max_templates = MAX_TEMPLATES if max_templates is None else max_templates
    max_pairs = MAX_PAIRS if max_pairs is None else max_pairs
    max_amounts = MAX_AMOUNTS if max_amounts is None else max_amounts
    fitted = {}
    if template is not None:
        fitted["templates"] = _shared.count_table(*template, top=max_templates)
        fitted["pairs"] = _shared.count_table(*pair, top=max_pairs)
    if cents is not None:
        fitted["amounts"] = _shared.count_table(*cents, top=max_amounts)
    return fitted


def _log_share(account, coded, table, remove_own_account):
    """log of the smoothed population share of every row's value; missing where the row has no value."""
    codes, texts = coded
    own, own_rows = _shared.own_counts(account, codes) if remove_own_account else (None, None)
    return np.log(_shared.table_share(codes, texts, table, own, own_rows))


def _account_side(out, name, account, secs, by_account, rows_30d, codes, log_share=None, prior_rows=5.0):
    """Add the account's own history of one coded value (a template or a pair) to `out`, for one block."""
    at_value = _shared.key_engine(account, codes, secs)
    n_30d = at_value.count(WINDOW)
    out[name + "seen"] = at_value.count() > 0
    out[name + "n_30d"] = n_30d
    out[name + "share_30d"] = _shared.ratio(n_30d, rows_30d)           # missing when the account has no earlier row
    out[name + "log_secs_since_first"] = np.log1p(at_value.seconds_since_first())
    if log_share is not None:
        # The lift compares the account's share with the population's. The account's share is pulled toward
        # the population share by `prior_rows` imaginary rows: after two earlier rows an account has no
        # habits yet, and an account with no history gets a lift of exactly 1 (a logarithm of 0).
        share = (n_30d + prior_rows * np.exp(log_share)) / (rows_30d + prior_rows)
        out[name + "log_lift"] = np.log(share) - log_share


def build_novelty_amount(df, fitted, code_cols=None, account_col=None, time_col=None, amount_col=None,
                         months_back=1, prior_rows=5.0, remove_own_account=False, prefix="novelty_", fill=None):
    """Template, pair and amount novelty columns for every row of `df`.

    df            every row of one or more whole files (whole account histories), in any order
    fitted        the tables from `fit_novelty_tables`
    code_cols     the code fields that make the template; None reads settings.CODE_COLS
    account_col, time_col, amount_col   column names; None reads them from settings
    months_back   the look-back starts on the first day of the month this many months before the row's
                  month; None means no limit
    prior_rows    strength of the pull toward the population share in the lift, in imaginary earlier rows
    remove_own_account  True when `df` holds the rows the tables were fitted on: the row's own account
                  is then taken out of every population count
    prefix        put in front of every column name
    fill          None keeps missing values; a number replaces them

    Returns a float DataFrame [rows, 21] with the index of `df`: 7 template columns, 5 pair
    columns, 8 amount columns and `has_earlier_row`. Without any code field the template and
    pair columns are skipped; without an amount column the amount columns are skipped; each
    with one printed line.

    Time rule: the account's counts use rows of the same account in strictly earlier seconds,
    not before the look-back start; rows of the same second never see each other. The
    population tables come from other rows altogether. The account's side is computed block
    by block (see _shared.blockwise), because the pair of an earlier row depends on what that
    earlier row could see.
    """
    account, secs, template, pair, cents, amount = _prepare(
        df, code_cols, account_col, time_col, amount_col, months_back)
    have_templates = template is not None and "templates" in fitted
    have_amounts = cents is not None and "amounts" in fitted
    if (template is not None and not have_templates) or (cents is not None and not have_amounts):
        print("note: the fitted tables lack the template or the amount table; those columns are skipped")

    # Population side, once for the whole table: how common is the row's template, pair and exact amount?
    static = {}
    if have_templates:
        static[prefix + "template_pop_log_share"] = _log_share(
            account, template, fitted["templates"], remove_own_account)
        static[prefix + "pair_pop_log_share"] = _log_share(account, pair, fitted["pairs"], remove_own_account)
    if have_amounts:
        whole_cents = np.round(amount * 100.0)
        bought = amount > 0                        # a zero-dollar check is not a purchase of a round amount
        static[prefix + "amount_cents"] = np.mod(np.abs(whole_cents), 100.0)
        for name, step in ROUND_AMOUNTS:
            is_round = bought & (np.mod(whole_cents, step) == 0)
            static[f"{prefix}amount_{name}"] = np.where(np.isnan(amount), np.nan, is_round)
        static[prefix + "amount_pop_log_share"] = _log_share(account, cents, fitted["amounts"], remove_own_account)

    def one_block(rows):
        """The account's side for the rows of one block, computed as if the block were the whole table."""
        a, t = account[rows], secs[rows]
        by_account = EarlierRows(a, t)
        rows_30d = by_account.count(WINDOW)
        out = {prefix + "has_earlier_row": by_account.count() > 0}
        if have_templates:
            codes = template[0][rows]
            _account_side(out, prefix + "template_", a, t, by_account, rows_30d, codes,
                          static[prefix + "template_pop_log_share"][rows], prior_rows)
            out[prefix + "template_distinct_30d"] = by_account.distinct(codes, WINDOW)
            # The pair is formed again inside the block: the block's first row of an account has no
            # previous row here, whatever came before the block.
            pair_codes = _shared.previous_pairs(by_account, codes)[0]
            _account_side(out, prefix + "pair_", a, t, by_account, rows_30d, pair_codes)
        if have_amounts:
            value = whole_cents[rows]
            out[prefix + "amount_n_same_30d"] = _shared.key_engine(a, cents[0][rows], t).count(WINDOW)
            # The previous amount is that of the latest earlier row that has an amount. No earlier amount, or a
            # missing amount on this row, gives 0; `has_earlier_row` tells the first case apart.
            out[prefix + "amount_equals_previous"] = by_account.last(value, where=~np.isnan(value)) == value
        return out

    built = _shared.blockwise(secs, months_back, one_block)
    # Put the columns in a readable order: the template, the pair, the amount, then the flag.
    order = [prefix + name for name in (
        "template_pop_log_share", "template_seen", "template_n_30d", "template_share_30d",
        "template_log_secs_since_first", "template_log_lift", "template_distinct_30d",
        "pair_pop_log_share", "pair_seen", "pair_n_30d", "pair_share_30d", "pair_log_secs_since_first",
        "amount_cents", "amount_whole", "amount_multiple_5", "amount_multiple_10", "amount_multiple_100",
        "amount_pop_log_share", "amount_n_same_30d", "amount_equals_previous", "has_earlier_row")]
    both = {**static, **built}
    return _shared.as_frame({name: both[name] for name in order if name in both}, df.index, fill)


def main(argv=None):
    """Command line: fit or load the tables, build the columns for some files and print a summary."""
    return _shared.run_builder(
        argv, "Novelty of the joint code template and of the exact amount.", needed_columns(),
        build=lambda df, args, fitted: build_novelty_amount(df, fitted, remove_own_account=args.remove_own_account),
        fit=lambda df, args: fit_novelty_tables(df))


if __name__ == "__main__":
    main()
