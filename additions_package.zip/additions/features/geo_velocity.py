"""Geographic velocity: how far, and how fast, between consecutive card-present purchases.

What this file does
-------------------
For every card-present row whose merchant postal code has a known centre, it finds the
account's previous such row (strictly earlier, inside the look-back) and writes (names
carry the prefix `geo_`):

    has_previous   1 when there is such a previous row, else 0
    km             great-circle distance between the two merchants, in kilometres
    log_secs       log(1 + seconds between the two rows)
    kmh            distance over the gap in hours, the gap counted as at least one minute

The distance comes from a table of postal-code centres (latitude and longitude). The
package ships no such table: `load_postal_centres` is a placeholder that returns None, and
with no table the builder prints one line and returns no columns. Rows that are not
card-present, or whose postal code has no centre, get missing values and do not serve as
"the previous purchase" for later rows.

Why it exists
-------------
A physical card can only be in one place. Two card-present purchases a few hundred
kilometres apart within the hour cannot both have been made by the cardholder, so one of
them was made with a copy of the card. Neither purchase looks odd by itself: the amount,
the merchant category and the time of day can all be ordinary. The signal exists only
between the two rows, as a speed, and a speed is a division of a distance by a time that
neither a tree model nor a field-by-field tokenizer can form from postal codes.

Only card-present rows take part, because a card-not-present purchase has no place: the
merchant's address says where the shop is registered, not where the buyer is. The gap is
counted as at least one minute because timestamps of two authorisations can be seconds
apart for reasons that have nothing to do with travel (a split payment, a retry), and a
distance of two kilometres over one second would otherwise read as an absurd speed.

Where it goes
-------------
Raw files, then these feature columns, then the network (extra numeric inputs, appended in
the per-file step that is `SequenceBuilder._encode_file` in the original code, each one a
numeric token of `FeatureTokenizer`) or a second-stage tree model.

What to change for the pod
--------------------------
`load_postal_centres` must be filled in: it should return a table with one line per postal
code and the columns named in `CENTRE_POSTAL`, `CENTRE_LAT` and `CENTRE_LON` (degrees). A
table can also be passed straight to `build_geo_velocity(df, centres=...)`. `postal_key`
decides how a postal code is written before it is looked up; if the table covers several
countries, build the key from country and postal code there and in the table.
`settings.MERCHANT_POSTAL_COL` and `settings.CARD_PRESENT_COL` name the two columns, and
`CARD_PRESENT_VALUES` lists the values that mean the card was physically present.
`MIN_GAP_SECONDS` is the floor of the gap.

How to try it
-------------
    python additions/features/geo_velocity.py --demo         # the demo invents a centre for every postal code

    centres = pandas.DataFrame({"postal": [...], "lat": [...], "lon": [...]})
    columns = build_geo_velocity(df, centres=centres)        # df: whole files
    python -m pytest -q additions/tests/test_features_geo_velocity.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np
import pandas as pd

from additions import settings
from additions.common.history import EarlierRows
from additions.common.timekeys import MISSING_SECOND
from additions.features import _shared

# PLACEHOLDER: the column names of the table of postal-code centres.
CENTRE_POSTAL = "postal"
CENTRE_LAT = "lat"
CENTRE_LON = "lon"

# PLACEHOLDER: the values of settings.CARD_PRESENT_COL that mean the card was physically present.
CARD_PRESENT_VALUES = ("Y",)

EARTH_RADIUS_KM = 6_371.0
MIN_GAP_SECONDS = 60


# PLACEHOLDER: read the table of postal-code centres of the pod here and return it.
def load_postal_centres():
    """The table of postal-code centres, or None when there is none.

    Expected: a DataFrame with one line per postal code and the columns `CENTRE_POSTAL`,
    `CENTRE_LAT` and `CENTRE_LON` (latitude and longitude in degrees). Returning None makes
    the builder skip its columns.
    """
    return None


# PLACEHOLDER: how a postal code is written before it is looked up in the table of centres.
def postal_key(distinct):
    """One lookup key per distinct postal code: text without surrounding blanks, in upper case.

    A code stored as the number 10001.0 becomes "10001". Cut the text here if the files
    carry longer codes than the table (nine-digit codes against five-digit centres).
    """
    return np.array([_shared.as_text(v).upper() for v in distinct], dtype=object)


def needed_columns():
    """The raw columns this builder reads."""
    return [settings.ACCOUNT_COL, settings.TIME_COL, settings.ID_COL, settings.MERCHANT_POSTAL_COL,
            settings.CARD_PRESENT_COL]


def great_circle_km(lat1, lon1, lat2, lon2):
    """Great-circle distance in kilometres between two points given in degrees (arrays of equal shape).

    The haversine form is used because it stays accurate for points that are close together,
    which is the common case here. A missing coordinate gives a missing distance.
    """
    lat1, lon1, lat2, lon2 = (np.radians(np.asarray(x, dtype=np.float64)) for x in (lat1, lon1, lat2, lon2))
    half_chord = np.sin((lat2 - lat1) / 2.0) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin((lon2 - lon1) / 2.0) ** 2
    return 2.0 * EARTH_RADIUS_KM * np.arcsin(np.sqrt(np.clip(half_chord, 0.0, 1.0)))


def _coordinates(postal, centres):
    """(lat, lon) per row, float [rows], missing where the row's postal code has no centre."""
    codes, keys = _shared.value_codes(postal, transform=postal_key)
    table_keys = postal_key(centres[CENTRE_POSTAL].to_numpy())
    where = dict(zip(table_keys, zip(centres[CENTRE_LAT].to_numpy(dtype=np.float64),
                                     centres[CENTRE_LON].to_numpy(dtype=np.float64))))
    per_key = np.array([where.get(key, (np.nan, np.nan)) for key in keys], dtype=np.float64).reshape(-1, 2)
    lat, lon = np.full(len(codes), np.nan), np.full(len(codes), np.nan)
    has = codes >= 0
    lat[has], lon[has] = per_key[codes[has], 0], per_key[codes[has], 1]
    return lat, lon


def build_geo_velocity(df, centres=None, account_col=None, time_col=None, postal_col=None, card_present_col=None,
                       card_present_values=None, months_back=1, prefix="geo_", fill=None):
    """Distance and speed from the account's previous card-present purchase, for every row of `df`.

    df           every row of one or more whole files (whole account histories), in any order
    centres      the table of postal-code centres; None calls `load_postal_centres()`
    account_col, time_col, postal_col, card_present_col   column names; None reads them from settings
    card_present_values   the values that mean "card present"; None reads `CARD_PRESENT_VALUES`
    months_back  the look-back starts on the first day of the month this many months before the row's
                 month; None means no limit
    prefix       put in front of every column name
    fill         None keeps missing values; a number replaces them

    Returns a float DataFrame [rows, 4] with the index of `df`: has_previous, km, log_secs,
    kmh. With no table of centres, or no postal column, one line is printed and the
    DataFrame has no columns. Without a card-present column one line is printed and every
    row with a centre takes part.

    Time rule: the previous purchase is the latest row of the same account in a strictly
    earlier second, not before the look-back start, that is itself card-present with a known
    centre. Rows of the same second never see each other.
    """
    if centres is None:
        centres = load_postal_centres()
    if centres is None:
        print("note: no table of postal-code centres (load_postal_centres returned None); the geo columns are skipped")
        return _shared.as_frame({}, df.index)
    postal = _shared.column(df, _shared.pick(postal_col, "MERCHANT_POSTAL_COL"), "the geo columns")
    if postal is None:
        return _shared.as_frame({}, df.index)
    account, secs = _shared.account_and_time(df, account_col, time_col)
    lat, lon = _coordinates(postal, centres)
    located = ~np.isnan(lat) & ~np.isnan(lon) & (secs != MISSING_SECOND)
    if not located.any():
        print("note: no postal code of the rows was found in the table of centres; `postal_key` may need a change")
    present = _shared.column(df, _shared.pick(card_present_col, "CARD_PRESENT_COL"),
                             "the card-present filter (every row with a centre then takes part)")
    if present is not None:
        wanted = [str(v).strip() for v in (CARD_PRESENT_VALUES if card_present_values is None else card_present_values)]
        codes, texts = _shared.coded_text(present)
        is_present = np.zeros(len(codes), dtype=bool)
        is_present[codes >= 0] = np.isin(texts.astype(str), wanted)[codes[codes >= 0]]
        located &= is_present

    # The previous located purchase of the account: its coordinates and how long ago it was. The same
    # `where` is used for all three questions, so they are answered by the same earlier row.
    by_account = EarlierRows(account, secs, start=_shared.history_start(secs, months_back))
    gap = by_account.seconds_since_last(where=located)
    has_previous = located & ~np.isnan(gap)
    km = great_circle_km(by_account.last(lat, where=located), by_account.last(lon, where=located), lat, lon)
    km = np.where(has_previous, km, np.nan)
    gap = np.where(has_previous, gap, np.nan)
    hours = np.maximum(gap, MIN_GAP_SECONDS) / 3_600.0             # the floor keeps a one-second gap from exploding
    out = {prefix + "has_previous": has_previous, prefix + "km": km, prefix + "log_secs": np.log1p(gap),
           prefix + "kmh": km / hours}
    return _shared.as_frame(out, df.index, fill)


def _made_up_centres(df):
    """A centre for every postal code of a table, at made-up coordinates. For the demo only."""
    postal = pd.unique(df[settings.MERCHANT_POSTAL_COL].dropna())
    rng = np.random.default_rng(0)
    return pd.DataFrame({CENTRE_POSTAL: postal, CENTRE_LAT: rng.uniform(30.0, 45.0, len(postal)),
                         CENTRE_LON: rng.uniform(-120.0, -75.0, len(postal))})


def main(argv=None):
    """Command line: build the columns for some files (or for made-up rows) and print a summary."""
    return _shared.run_builder(
        argv, "Distance and speed between consecutive card-present purchases of an account.", needed_columns(),
        build=lambda df, args: build_geo_velocity(df, centres=_made_up_centres(df) if args.demo else None))


if __name__ == "__main__":
    main()
