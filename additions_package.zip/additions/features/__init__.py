"""New per-row input columns built from raw transactions, and the catalogue of possible features.

asof_audit.py         as-of audit: was a date or profile column known at the transaction, or written
                      later?
exact_match.py        exact-match history columns: has this account been at this merchant (category,
                      place) before?
geo_velocity.py       geographic velocity: how far, and how fast, between consecutive card-present
                      purchases
lookback.py           the look-back start that keeps training rows and scored rows alike
novelty_amount.py     exact-value novelty: the joint template of the code fields, and the fine
                      structure of the amount
outcome_history.py    outcome history: what the bank decided on the account's EARLIER rows
possible_features.py  a catalogue of possible features, in addition to the inputs the model already
                      has
ratios.py             ratio columns: the amount against what the account holds and against what it
                      usually spends
recurrence_tokens.py  recurrence tokens: small codes that let the network see "the same merchant as
                      before"
surprise.py           count-based surprise: how unusual is each value of a row, for this account and
                      for everyone?
_shared.py            small helpers shared by the feature builders of this folder
"""
