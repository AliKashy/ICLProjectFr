"""The look-back start that keeps training rows and scored rows alike.

What this file does
-------------------
It answers one question for every row: from which second on may this row read history? The
answer is the first second of the calendar month before the row's own month, so a row on
17 June may read from 1 May 00:00:00 on. Around that answer the file offers four things:
the number of days of history the rule leaves a row (an exposure column), a yes/no for
"do the files reach back far enough for this row", the same count for a fixed window such
as 90 days (to show how far it is cut), and a list of two-month blocks that cut a long
table into pieces shaped like an evaluation file.

Why it exists
-------------
The evaluation files start one month before the scored month, so a scored row has between
one and two months of history and never more. Training files are longer, so a training row
can have many months behind it. A history feature with a fixed 90-day window is therefore
full on most training rows and cut short on every scored row. "Not seen in the last 90
days" then has two meanings: on a training row it is 90 days without a visit, on a scored
row it may be five weeks without a visit, because the files hold nothing older. A model
that learns the first meaning and is scored on the second is misled exactly on the rows
that look new, which are the rows a fraud model cares about most.

The calendar rule removes the difference. A row in month M reads from the first day of
month M-1 in every file. A scored row then has its whole look-back, because the files begin
on that very day, and a training row is held to the same one to two months. What still
differs between rows is the day of the month: a row on the 2nd has about a month behind it
and a row on the 30th about two. That is why the days available are a column of their own:
with it a model can tell "few earlier rows because the window is short" from "few earlier
rows because the account is quiet". A training row in the first month of its files has no
earlier month at all; `has_full_lookback` marks such rows so that they can be left out as
training targets (they stay useful as history for the month after).

Where it goes
-------------
Between the raw files and the feature columns. The builders of this folder use it in one
of two ways. A column that looks straight at the earlier rows (a count, a sum, the time
since the last such row) passes `lookback_start` to the history engine as the earliest
second it may use. A column that is built on something computed for the earlier rows
themselves ("was that earlier row a first use?") is computed on the blocks of
`month_blocks`, so that an earlier row cannot remember more than the row that reads it;
`_shared.blockwise` does that.

The same start can also be given to the network. In the original code the rows a
transaction may attend to are decided in `FTTransformerHierModel._build_causal_mask`; one
more time condition there ("not before the look-back start of the reading row") makes
stage 2 follow the same rule. `month_blocks` also serves a sequence builder that wants
training sequences cut exactly as an evaluation file is cut.

What to change for the pod
--------------------------
`settings.TRAIN_HISTORY_START` and `settings.EVAL_HISTORY_START` are the first day of data in
the training files and in the evaluation files; pass the one that fits the rows as
`file_start`. With no `file_start` the first day found in the rows is used, which is right
when whole files were read. `months_back=1` fits evaluation files that start one month
before the scored month; if they start two months before it, use 2 everywhere. A store
that always holds a fixed number of days needs no calendar rule: pass `months_back=None`
to the builders and use fixed windows.

How to try it
-------------
    python additions/features/lookback.py --demo
    python additions/features/lookback.py --base /path/to/files --files 1 2 3 --file-start 2024-10-01

    start = lookback_start(secs)                           # per row, whole seconds
    earlier = EarlierRows(account, secs, start=start)      # history that never reaches before it
    python -m pytest -q additions/tests/test_features_lookback.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, tables, timekeys
from additions.common.timekeys import MISSING_SECOND

DAY = 86_400


def lookback_start(secs, months_back=1):
    """The first second each row may read: the start of the month `months_back` months before its own.

    secs         whole seconds per row, int64 [rows] (from `timekeys.seconds`)
    months_back  1 gives the first day of the previous month; 0 gives the first day of the
                 row's own month

    Returns int64 [rows]. A row with a missing time keeps the missing-time marker.
    """
    return timekeys.month_start_seconds(secs, months_back)


def data_start(file_start=None, secs=None):
    """The first second of data in the files, as one whole number of seconds.

    `file_start` may be a date as text ("2025-05-01"), a pandas Timestamp or a number of
    seconds. None means "not given": the first day that occurs in `secs` is used. That is
    exact when whole files were read and an estimate when only a sample of rows is at hand.
    """
    if file_start is None:
        secs = np.asarray(secs, dtype=np.int64)
        real = secs[secs != MISSING_SECOND]
        return int(real.min() // DAY * DAY) if len(real) else 0
    if isinstance(file_start, (int, float, np.integer, np.floating)):
        return int(file_start)
    return int(timekeys.seconds(pd.Series([pd.Timestamp(file_start)]))[0])


def days_available(secs, file_start=None, months_back=1):
    """Days of history a row can have: from the later of its look-back start and the file start to the row.

    Returns float [rows]; missing where the row has no time. This is the exposure column: it
    says how long the window behind the row is, so that a low count can be read against it.
    With `months_back=None` there is no calendar rule and the days are counted from the file
    start alone.
    """
    secs = np.asarray(secs, dtype=np.int64)
    real = secs != MISSING_SECOND
    start = np.full(secs.shape, data_start(file_start, secs), dtype=np.int64)
    if months_back is not None:
        start[real] = np.maximum(start[real], lookback_start(secs[real], months_back))
    days = np.full(secs.shape, np.nan)
    days[real] = np.clip((secs[real] - start[real]) / DAY, 0.0, None)
    return days


def has_full_lookback(secs, file_start=None, months_back=1):
    """True where the files reach back to the row's look-back start, bool [rows].

    It is False for every row in the first month(s) of its files: a row in the first month
    has no earlier month to read, so its history columns mean less than on other rows. Such
    rows are best left out as training targets. In evaluation files this marks the month
    before the scored month, which is history only.
    """
    secs = np.asarray(secs, dtype=np.int64)
    real = secs != MISSING_SECOND
    full = np.zeros(secs.shape, dtype=bool)
    full[real] = lookback_start(secs[real], months_back) >= data_start(file_start, secs)
    return full


def fixed_window_days(secs, file_start=None, window_days=90):
    """Days of a fixed window that the files can actually fill, float [rows].

    A row that sits 40 days after the file start can fill only 40 days of a 90-day window.
    The function exists to show the problem the calendar rule solves; see `coverage_by_month`.
    """
    secs = np.asarray(secs, dtype=np.int64)
    real = secs != MISSING_SECOND
    days = np.full(secs.shape, np.nan)
    days[real] = np.clip((secs[real] - data_start(file_start, secs)) / DAY, 0.0, float(window_days))
    return days


def coverage_by_month(secs, file_start=None, months_back=1, window_days=90):
    """One line per calendar month: how much history its rows have under each rule.

    Columns: month, rows, full_lookback (share of rows whose calendar look-back is complete),
    days_calendar (mean days available under the calendar rule), days_fixed (mean days a fixed
    window of `window_days` can fill) and fixed_cut_short (share of rows whose fixed window
    reaches back before the first day of data). In evaluation files the scored month shows
    fixed_cut_short = 1: every scored row has less than the fixed window. In long training
    files the later months show 0. The calendar columns are the same in both.
    """
    secs = np.asarray(secs, dtype=np.int64)
    real = secs != MISSING_SECOND
    fixed = fixed_window_days(secs, file_start, window_days)[real]
    frame = pd.DataFrame({
        "month_start": lookback_start(secs[real], 0),
        "full_lookback": has_full_lookback(secs, file_start, months_back)[real],
        "days_calendar": days_available(secs, file_start, months_back)[real],
        "days_fixed": fixed,
        "fixed_cut_short": fixed < window_days,
    })
    out = frame.groupby("month_start").mean()
    out.insert(0, "rows", frame.groupby("month_start").size())
    out = out.reset_index()
    # The month is written as text only now, once per month and not once per row.
    out.insert(0, "month", pd.to_datetime(out.pop("month_start"), unit="s").dt.strftime("%Y-%m"))
    return out


def month_blocks(secs, months_back=1):
    """The two-month blocks of a table: for every calendar month, the stretch its rows may read.

    Returns a DataFrame with one line per calendar month that holds rows, and the columns
    month (text), block_start, target_start and target_end (whole seconds). The rows with
    target_start <= time < target_end are the rows of that month; the rows with
    block_start <= time < target_end are everything they may read. With `months_back=1` a
    block is the month before plus the month itself, which is exactly the shape of an
    evaluation file (history month, then scored month).

    A sequence builder that cuts training sequences block by block, and takes training
    targets only from the last month of each block, shows the network the same amount of
    history in training as in scoring.
    """
    secs = np.asarray(secs, dtype=np.int64)
    target_start = np.unique(lookback_start(secs[secs != MISSING_SECOND], 0))
    return pd.DataFrame({
        "month": pd.to_datetime(target_start, unit="s").strftime("%Y-%m"),
        "block_start": lookback_start(target_start, months_back),
        "target_start": target_start,
        "target_end": lookback_start(target_start, -1),       # one month forward: the start of the next month
    })


def main(argv=None):
    """Command line: print, month by month, how much history the rows have under each rule."""
    parser = argparse.ArgumentParser(
        description="History available per month: the calendar look-back against a fixed window.")
    parser.add_argument("--base", default=settings.EVAL_BASE, help="folder that holds the numbered files")
    parser.add_argument("--files", type=int, nargs="+", default=None,
                        help="file numbers to read (default: settings.CONSUMER_READ_FILES)")
    parser.add_argument("--file-start", default=None,
                        help="first day of data in these files, for example 2025-05-01 (default: the first day found)")
    parser.add_argument("--months-back", type=int, default=1,
                        help="whole months before the row's month that may be read")
    parser.add_argument("--window-days", type=int, default=90, help="the fixed window to compare with")
    parser.add_argument("--time-col", default=settings.TIME_COL, help="the transaction timestamp column")
    parser.add_argument("--demo", action="store_true", help="run on made-up rows instead of files")
    parser.add_argument("--out", default=None, help="write the table here (.csv, otherwise parquet)")
    args = parser.parse_args(argv)

    if args.demo:
        df = synthetic.make_transactions(n_accounts=200, seed=1)
    else:
        df = tables.read_files(args.base, args.files or settings.CONSUMER_READ_FILES, [args.time_col])
    secs = timekeys.seconds(df[args.time_col])
    table = coverage_by_month(secs, args.file_start, args.months_back, args.window_days)
    print(table.to_string(index=False, float_format=lambda x: f"{x:.3f}"))
    if args.out:
        if str(args.out).lower().endswith(".csv"):
            table.to_csv(args.out, index=False)
        else:
            tables.write_table(table, args.out)
        print(f"written: {args.out}")
    return table


if __name__ == "__main__":
    main()
