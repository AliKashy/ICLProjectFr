"""As-of audit: was a date or profile column known at the transaction, or written later?

What this file does
-------------------
For each date or profile column it is given, it measures four things and prints a verdict:

    share_later                 share of rows whose date is later than the transaction it sits on
                                (overall, and month by month in a second table)
    share_accounts_changing     share of accounts that show more than one distinct value
    share_changes_at_month_start   among the value changes inside accounts, the share that fall on
                                a month start: the row with the old value and the row with the new
                                value lie in different calendar months
    share_pairs_across_months   the same share over all consecutive row pairs: what the previous
                                number would be if changes had nothing to do with the calendar
    auc_later_fraud             with labels: how well "days from the date to the transaction" tells
                                accounts that later have a fraud from accounts that never do,
                                measured only on rows at least 30 days before the account's first
                                fraud, and comparing only rows of the same calendar day

The verdict is one of three, with the evidence in words:

    static                        the value never changes inside an account (an opening date)
    stamped at the transaction    the value changes inside accounts at any time and no date lies
                                  after its transaction: it was written when the transaction happened
    later snapshot                the value was written after the transaction: a date lies after it,
                                  or the value changes only at month starts, or it tells a month
                                  ahead which accounts will have a fraud

Labels are read here only to measure a column. Nothing this file produces is a model input.

Why it exists
-------------
Profile columns (status dates, last-change dates, flags) are tempting inputs, and some of
them are written when the file is extracted, not when the transaction happens. Fraud
labels arrive weeks after the transaction, and what the bank does on learning of a fraud
(blocking the card, reissuing it, changing a status) lands in such columns. A column like
that hands the model the answer: it looks excellent in every offline test and is worth
nothing in production, where the value does not exist yet when the transaction is scored.
It also spoils a comparison between two models when only one of them uses the column.

Clipping does not rescue such a column. If dates later than the transaction are set to
missing, then "missing" itself means "something happened later". So a later snapshot is
kept out of the inputs altogether; where it encodes a compromise it can still serve as a
training target, which is a legitimate use of knowledge about the future.

The three label-free checks need nothing but the rows. The labelled check asks a question
an honest column should fail: a month before the first fraud, an account that will be
defrauded looks like any other, so a value known at that time separates the two groups
weakly at best. A column that separates them well is far more likely to have been written
after the fraud than to foresee it.

Where it goes
-------------
Before any new column becomes an input: raw files in, one table of verdicts out. It is a
read on the files and needs no model. The verdict table is also worth handing to whoever
serves the features later: only static and stamped columns can be served at the moment of
the transaction.

What to change for the pod
--------------------------
The columns to audit are given on the command line or as a list. `settings.ACCOUNT_COL`,
`TIME_COL`, `LABEL_COL` and `POSITIVE_LABEL` name the rest. `to_days` below decides how a
column is read as a date. The four limits below the imports set where a verdict flips.
Scheduled dates that are meant to lie in the future (an expiry date) should be listed in
`future_ok`; the first check is then not held against them. Files hold whole accounts, so
the audit works inside any one file; run it on one training file and one evaluation file,
because a column can be stamped in one extract and a snapshot in the other.

How to try it
-------------
    python additions/features/asof_audit.py --demo
    python additions/features/asof_audit.py --base /files --files 1 --columns date_col other_col --out audit.csv
    python additions/features/asof_audit.py --base /files --files 1 --columns expiry_dt --future-ok expiry_dt

    summary, by_month = audit_columns(df, ["some_date_col", "other_col"])
    python -m pytest -q additions/tests/test_features_asof_audit.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import argparse

import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, tables, timekeys
from additions.common.timekeys import MISSING_SECOND
from additions.features import _shared, lookback

STATIC = "static"
STAMPED = "stamped at the transaction"
SNAPSHOT = "later snapshot"

# Where a verdict flips. They are judgment calls and can be moved.
LATER_SHARE_LIMIT = 0.001       # more than this share of dates after the transaction: a later snapshot
CHANGING_SHARE_LIMIT = 0.001    # at most this share of accounts with more than one value: static
MONTH_START_SHARE = 0.9         # at least this share of changes at a month start: a monthly snapshot
AUC_ALARM = 0.75                # an AUC at least this far toward 0 or 1, a month ahead: written after the fraud

DAY = 86_400

# The columns of the two tables that `audit_columns` returns.
SUMMARY_COLUMNS = ["column", "kind", "rows_with_value", "share_later", "share_accounts_changing", "changes",
                   "share_changes_at_month_start", "share_pairs_across_months", "auc_later_fraud", "auc_rows_fraud",
                   "auc_rows_clean", "verdict", "evidence"]
BY_MONTH_COLUMNS = ["column", "month", "rows", "share_later"]


# PLACEHOLDER: how a column is read as a date; return whole days per row, or None when it is not a date.
def to_days(values):
    """Whole days since 1970-01-01 per row (float, missing where there is no date), or None for a non-date.

    Datetime columns are dates. Whole numbers that look like 20250617 are read as year, month,
    day. Text is a date column when at least nine in ten of its values parse as dates. Any
    other column (a status code, an amount) is not a date and is audited as a plain value.
    """
    array = np.asarray(values)
    if np.issubdtype(array.dtype, np.number):
        numbers = pd.to_numeric(pd.Series(array), errors="coerce")
        have = numbers.notna()
        in_range = numbers[have].between(19_000_101, 21_001_231) & (numbers[have] % 1 == 0)
        if not have.any() or not in_range.all():
            return None
        text = numbers.astype("Int64").astype(str).where(have)
        stamps = pd.to_datetime(text, format="%Y%m%d", errors="coerce")
        return ((stamps - pd.Timestamp("1970-01-01")) / pd.Timedelta(days=1)).to_numpy(dtype=np.float64)
    secs = timekeys.seconds(pd.Series(array))
    parsed = secs != MISSING_SECOND
    filled = ~pd.isna(array)
    if not filled.any() or parsed.sum() < 0.9 * filled.sum():
        return None
    return np.where(parsed, secs // DAY, np.nan).astype(np.float64)


def _later_than_transaction(column_days, txn_secs):
    """(overall share, table by month) of rows whose date is later than the day of their transaction.

    Days are compared, not seconds: a profile date has no time of day, and a date equal to the
    transaction's day is not "later".
    """
    dated = ~np.isnan(column_days) & (txn_secs != MISSING_SECOND)
    later = column_days[dated] > txn_secs[dated] // DAY
    month_start = lookback.lookback_start(txn_secs[dated], 0)
    by_month = pd.DataFrame({"start": month_start, "later": later}).groupby("start")["later"].agg(
        rows="size", share_later="mean").reset_index()
    by_month.insert(0, "month", pd.to_datetime(by_month.pop("start"), unit="s").dt.strftime("%Y-%m"))
    return (float(later.mean()) if len(later) else np.nan), by_month


def _changing_accounts(account, codes):
    """Share of accounts that show more than one distinct value, among accounts with two or more valued rows."""
    has = codes >= 0
    rows_per_account = np.bincount(account[has])
    n_values = int(codes.max()) + 1 if has.any() else 1
    pairs = np.unique(account[has] * n_values + codes[has])                      # each (account, value) once
    values_per_account = np.bincount(pairs // n_values, minlength=len(rows_per_account))
    could_change = rows_per_account >= 2
    return float((values_per_account[could_change] > 1).mean()) if could_change.any() else np.nan


def _changes(account, secs, codes):
    """(number of value changes, share of them at a month start, share of all consecutive pairs across months).

    The valued rows of each account are put in time order. A change is a row whose value
    differs from the value of the row before it. It "falls on a month start" when the two
    rows lie in different calendar months, so that the change can have happened at the turn
    of the month. A column refreshed once a month changes only there; a column stamped at
    the transaction changes anywhere, and then the share is close to the share of all row
    pairs that happen to straddle a month.
    """
    keep = (codes >= 0) & (secs != MISSING_SECOND)
    account, secs, codes = account[keep], secs[keep], codes[keep]
    order = timekeys.stable_order(account, secs)
    account, secs, codes = account[order], secs[order], codes[order]
    same_account = account[1:] == account[:-1]
    month = lookback.lookback_start(secs, 0)
    across = (month[1:] != month[:-1])[same_account]
    changed = (codes[1:] != codes[:-1])[same_account]
    n_changes = int(changed.sum())
    return (n_changes, float(across[changed].mean()) if n_changes else np.nan,
            float(across.mean()) if len(across) else np.nan)


def _auc_before_fraud(measure, account, secs, is_fraud, days_before):
    """(AUC, rows of accounts with a later fraud, rows of accounts with none) for one measure per row.

    The rows of an account with a fraud are used only when they lie at least `days_before`
    days before its first fraud; the rows of accounts without any fraud are all used. The
    AUC is the chance that the measure ranks a row of the first group above a row of the
    second. 0.5 means the measure knows nothing about what is to come; values near 0 or 1
    mean it does. Missing when no calendar day holds rows of both groups.

    Rows are compared only with rows of the same calendar day, and the days are pooled. The
    reason: the early rows of fraud accounts all sit early in the files, while the rows of
    clean accounts cover the whole period. A measure that simply grows with time, as "days
    from the date to the transaction" does for any fixed date, would otherwise separate the
    two groups without knowing anything. Inside one day that effect is gone.
    """
    never = np.iinfo(np.int64).max
    first_fraud = np.full(int(account.max()) + 1 if len(account) else 0, never)
    np.minimum.at(first_fraud, account[is_fraud], secs[is_fraud])       # the first fraud second of every account
    has_fraud = first_fraud[account] != never
    usable = ~np.isnan(measure) & (secs != MISSING_SECOND)
    early = usable & has_fraud & (secs <= first_fraud[account] - days_before * DAY)
    clean = usable & ~has_fraud
    use = early | clean
    frame = pd.DataFrame({"day": secs[use] // DAY, "early": early[use].astype(np.float64)})
    # Rank the measure inside each day (ties share the mean rank). The rank sum of one group, less the
    # smallest value it could have, counts the pairs in which that group ranks higher: the same sum that
    # the area under the ROC curve is made of.
    rank = pd.Series(measure[use]).groupby(frame["day"]).rank(method="average")
    frame["rank_if_early"] = rank * frame["early"]
    per_day = frame.groupby("day").agg(n=("early", "size"), n_early=("early", "sum"),
                                       rank_sum=("rank_if_early", "sum"))
    wins = (per_day["rank_sum"] - per_day["n_early"] * (per_day["n_early"] + 1) / 2).sum()
    pairs = (per_day["n_early"] * (per_day["n"] - per_day["n_early"])).sum()
    return (float(wins / pairs) if pairs > 0 else np.nan), int(early.sum()), int(clean.sum())


def _verdict(row, future_ok, days_before):
    """(verdict, evidence in words) for one line of the summary. The first rule that applies decides."""
    auc, changing = row["auc_later_fraud"], row["share_accounts_changing"]
    is_date = row["kind"] == "date"
    if is_date and row["column"] not in future_ok and row["share_later"] > LATER_SHARE_LIMIT:
        return SNAPSHOT, f"{row['share_later']:.1%} of its dates lie after the transaction they sit on"
    if not np.isnan(auc) and max(auc, 1.0 - auc) >= AUC_ALARM:
        return SNAPSHOT, (f"{days_before} days before the first fraud it already tells such accounts apart "
                          f"(AUC {auc:.2f}); a value known at the transaction rarely can")
    if np.isnan(changing):
        return STATIC, "no account has two rows with a value, so no change can be seen"
    if changing <= CHANGING_SHARE_LIMIT:
        return STATIC, f"{changing:.2%} of accounts show more than one value"
    at_month_start, base = row["share_changes_at_month_start"], row["share_pairs_across_months"]
    if row["changes"] > 0 and at_month_start >= MONTH_START_SHARE and at_month_start > base:
        return SNAPSHOT, (f"{at_month_start:.0%} of its changes fall on a month start, against {base:.0%} of all "
                          "row pairs: a monthly snapshot, which can hold values from later in the month")
    ending = "and no date lies after its transaction" if is_date else "so it changes at any time of the month"
    return STAMPED, (f"{changing:.0%} of accounts show several values, {at_month_start:.0%} of the changes "
                     f"fall on a month start, {ending}")


def audit_columns(df, columns, account_col=None, time_col=None, label_col=None, positive_label=None,
                  future_ok=(), days_before=30):
    """Audit date and profile columns: was each known at the transaction?

    df           rows of one or more whole files (whole account histories)
    columns      names of the columns to audit; a name the table does not have is skipped with one line
    account_col, time_col, label_col   column names; None reads them from settings. Without a label
                 column the labelled check is skipped with one printed line
    positive_label   the label value that means fraud; None reads settings.POSITIVE_LABEL
    future_ok    names of columns whose dates are meant to lie in the future (an expiry date)
    days_before  the labelled check uses rows at least this many days before the account's first fraud

    Returns (summary, by_month). `summary` has one line per audited column: column, kind
    ("date" or "value"), rows_with_value, share_later, share_accounts_changing, changes,
    share_changes_at_month_start, share_pairs_across_months, auc_later_fraud, auc_rows_fraud,
    auc_rows_clean, verdict and evidence. `by_month` has one line per date column and
    calendar month: column, month, rows, share_later.

    For a column that is not a date, the first check does not apply and the labelled check
    uses the value itself when it is a number.
    """
    account, secs = _shared.account_and_time(df, account_col, time_col)
    labels = _shared.column(df, _shared.pick(label_col, "LABEL_COL"), "the labelled check")
    is_fraud = None
    if labels is not None:
        is_fraud = (labels == _shared.pick(positive_label, "POSITIVE_LABEL")) & (secs != MISSING_SECOND)
    lines, months = [], []
    for name in columns:
        values = _shared.column(df, name, f"the audit of '{name}'")
        if values is None:
            continue
        days = to_days(values)
        codes, _ = _shared.value_codes(values if days is None else days)
        line = {"column": name, "kind": "value" if days is None else "date",
                "rows_with_value": int((codes >= 0).sum()), "share_later": np.nan}
        if days is not None:
            line["share_later"], by_month = _later_than_transaction(days, secs)
            months.append(by_month.assign(column=name)[BY_MONTH_COLUMNS])
            # The measure of the labelled check: days from the date to the transaction.
            measure = np.where(secs == MISSING_SECOND, np.nan, secs // DAY - days)
        else:
            measure = pd.to_numeric(pd.Series(values), errors="coerce").to_numpy(dtype=np.float64)
        line["share_accounts_changing"] = _changing_accounts(account, codes)
        n_changes, at_month_start, across_months = _changes(account, secs, codes)
        line.update(changes=n_changes, share_changes_at_month_start=at_month_start,
                    share_pairs_across_months=across_months, auc_later_fraud=np.nan, auc_rows_fraud=0, auc_rows_clean=0)
        if is_fraud is not None:
            auc, n_fraud, n_clean = _auc_before_fraud(measure, account, secs, is_fraud, days_before)
            line.update(auc_later_fraud=auc, auc_rows_fraud=n_fraud, auc_rows_clean=n_clean)
        line["verdict"], line["evidence"] = _verdict(line, future_ok, days_before)
        lines.append(line)
    summary = pd.DataFrame(lines, columns=SUMMARY_COLUMNS)
    by_month = pd.concat(months, ignore_index=True) if months else pd.DataFrame(columns=BY_MONTH_COLUMNS)
    return summary, by_month


def main(argv=None):
    """Command line: audit columns of some files (or of made-up rows) and print the verdicts."""
    parser = argparse.ArgumentParser(description="As-of audit of date and profile columns.")
    parser.add_argument("--base", default=settings.TRAIN_BASE, help="folder that holds the numbered files")
    parser.add_argument("--files", type=int, nargs="+", default=None,
                        help="file numbers to read (default: the first of settings.TRAIN_FILES)")
    parser.add_argument("--columns", nargs="+", default=None, help="the columns to audit")
    parser.add_argument("--future-ok", nargs="*", default=[], help="columns whose dates are meant to lie in the future")
    parser.add_argument("--days-before", type=int, default=30,
                        help="the labelled check uses rows at least this many days before the first fraud")
    parser.add_argument("--demo", action="store_true", help="run on made-up rows with three made-up date columns")
    parser.add_argument("--out", default=None, help="write the summary here (.csv, otherwise parquet)")
    args = parser.parse_args(argv)

    if args.demo:
        df, columns = synthetic.add_profile_dates(synthetic.make_transactions(n_accounts=300, seed=1))
    else:
        columns = args.columns or []
        needed = [settings.ACCOUNT_COL, settings.TIME_COL, settings.LABEL_COL, *columns]
        df = tables.read_files(args.base, args.files or settings.TRAIN_FILES[:1], needed)
    if not columns:
        print("note: no column was named with --columns; nothing is audited")
    summary, by_month = audit_columns(df, columns, future_ok=args.future_ok, days_before=args.days_before)
    numbers = summary.drop(columns=["evidence"])
    print(numbers.to_string(index=False, float_format=lambda x: f"{x:.3f}"))
    print()
    for line in summary.itertuples(index=False):
        print(f"{line.column}: {line.verdict}. Evidence: {line.evidence}.")
    if len(by_month):
        print()
        print(by_month.to_string(index=False, float_format=lambda x: f"{x:.3f}"))
    if args.out:
        _shared.write_out(summary, args.out)
        print(f"written: {args.out}")
    return summary


if __name__ == "__main__":
    main()
