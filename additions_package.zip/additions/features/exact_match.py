"""Exact-match history columns: has this account been at this merchant (category, place) before?

What this file does
-------------------
For every row and every matching key that the files hold (merchant id, merchant category,
postal code, state, country, and the optional card, terminal, device, token and IP columns)
it looks at the account's strictly earlier rows inside the look-back and writes:

    <key>_seen                      1 when the account used this value before, else 0
    <key>_log_secs_since_first      age of the relationship: log(1 + seconds since the first use)
    <key>_log_secs_since_last       log(1 + seconds since the last use)
    <key>_n_1h, _n_24h, _n_7d, _n_30d, _n_lookback   earlier uses inside each window
    <key>_share                     share of the account's earlier rows that were at this value
    <key>_amount_mean, _amount_max  mean and largest amount of the earlier uses
    <key>_amount_ratio              this amount over that mean
    <key>_same_amount_n             earlier uses with exactly this amount, to the cent
    <key>_same_amount_log_secs      log(1 + seconds since the last of them): a recurring charge
    <key>_new_1h, _new_24h, _new_7d how many earlier rows of the account were themselves a first use
                                    of a value of this key (novelty velocity)
    <key>_distinct_24h, _distinct_30d   different values of this key the account used

and two exposure columns: `rows_in_lookback` (earlier rows of the account) and
`days_in_lookback` (days since the look-back start). Every column name carries the prefix
`match_`. Durations and means are missing when there is no earlier use; `<key>_seen` and
the counts tell "no earlier use" apart from a small value.

Why it exists
-------------
Frauds come in runs on one account, so most frauds follow an earlier fraud of that account,
and a run usually plays out at merchants the account never used, minutes apart. A purchase
at a merchant the account has used for weeks is the opposite picture. Telling the two apart
needs an exact comparison of identities ("the same merchant as on an earlier row"), which a
network without a merchant input cannot make and which a tree model cannot derive from the
raw fields of a single row.

The age of the relationship is the column that separates a habit from a run: a merchant
first seen seven weeks ago and visited a dozen times is a habit, a merchant first seen ten
minutes ago and now used for the third time is a run. Novelty velocity counts how many
never-used merchants (or categories, or countries) appeared in the last hour, day and
week; several in an hour is the mark of a stolen card being tried out. The
exact-amount repeat marks the benign case of a subscription: the same amount at the same
merchant about a month apart.

The key values themselves are only compared for equality. No value is written out,
averaged against labels or given an embedding row, so nothing here grows with the number
of merchants and nothing depends on a merchant having been seen in training. No label is
read, so label delay does not matter. Because the files hold whole accounts, an account's
own history is complete however few accounts were read.

Where it goes
-------------
Raw files, then these feature columns, then either the network or a tree model. For the
network the columns join the numeric inputs before preprocessing: in the original code
that is the per-file step `SequenceBuilder._encode_file`, and each new column becomes one
more numeric token in `FeatureTokenizer` (its `continuous_dim` grows by the number of
columns). For a second-stage tree model the columns are joined to the raw fields, the
model's score and its vector by transaction id.

What to change for the pod
--------------------------
The key columns: `settings.MERCHANT_COL`, `MCC_COL`, `MERCHANT_POSTAL_COL`, `MERCHANT_STATE_COL`,
`MERCHANT_COUNTRY_COL` and the optional `CARD_COL`, `TERMINAL_COL`, `DEVICE_COL`, `TOKEN_COL`,
`IP_COL` (None switches a key off); or pass `keys={"short name": "column"}`. Also
`settings.ACCOUNT_COL`, `TIME_COL` and `AMOUNT_COL`. Pass `file_start` (settings.TRAIN_HISTORY_START
or settings.EVAL_HISTORY_START) so that `days_in_lookback` is exact. The windows are the
constants below. A column with very few distinct values, such as the country, makes some of
its columns nearly constant; drop those after a first look. Counts are raw counts; a network
input usually wants log(1 + count), which the preprocessing step can apply. Rows in the
first month of their files have no earlier month (see lookback.has_full_lookback) and are
best left out as training targets.

How to try it
-------------
    python additions/features/exact_match.py --demo
    python additions/features/exact_match.py --base /path/to/files --files 8217 8218 --out match.parquet

    columns = build_exact_match(df, file_start=settings.EVAL_HISTORY_START)   # df: whole files
    python -m pytest -q additions/tests/test_features_exact_match.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np

from additions import settings
from additions.common.history import EarlierRows
from additions.features import _shared, lookback

# Windows of the plain counts, of the novelty velocity and of the distinct counts, as (label, seconds).
# All of them fit inside the look-back, which is at least four weeks long.
COUNT_WINDOWS = (("1h", 3_600), ("24h", 86_400), ("7d", 7 * 86_400), ("30d", 30 * 86_400))
NOVELTY_WINDOWS = (("1h", 3_600), ("24h", 86_400), ("7d", 7 * 86_400))
DISTINCT_WINDOWS = (("24h", 86_400), ("30d", 30 * 86_400))


def needed_columns():
    """The raw columns this builder reads (None entries are optional columns that are switched off)."""
    return [settings.ACCOUNT_COL, settings.TIME_COL, settings.ID_COL, settings.AMOUNT_COL,
            *_shared.default_keys().values()]


def _one_key(out, name, account, secs, by_account, rows_before, codes, amount, cents):
    """Add the columns of one matching key to `out`, for the rows of one block.

    `codes` holds one integer per distinct value of the key and -1 where the row has no value.
    `at_key` below answers questions about the earlier rows of the same account at the same
    value; `by_account` answers questions about all earlier rows of the account. The block is
    already cut at the look-back start, so "all earlier rows" means "inside the look-back".
    """
    at_key = _shared.key_engine(account, codes, secs)
    n_lookback = at_key.count()
    seen = n_lookback > 0
    out[name + "seen"] = seen
    # Durations are written as log(1 + seconds): a gap of ten minutes and a gap of ten weeks are both
    # informative, and the logarithm keeps them on one readable scale. No earlier use gives a missing value.
    out[name + "log_secs_since_first"] = np.log1p(at_key.seconds_since_first())
    out[name + "log_secs_since_last"] = np.log1p(at_key.seconds_since_last())
    for label, window in COUNT_WINDOWS:
        out[name + "n_" + label] = at_key.count(window)
    out[name + "n_lookback"] = n_lookback
    # Share of the account's earlier activity at this value. Missing when the account has no earlier
    # row at all: nothing divided by nothing is not zero.
    out[name + "share"] = _shared.ratio(n_lookback, rows_before)

    if amount is not None:
        mean = at_key.mean(amount)
        out[name + "amount_mean"] = mean
        out[name + "amount_max"] = at_key.maximum(amount)
        out[name + "amount_ratio"] = _shared.ratio(amount, mean)
        # A recurring charge: an earlier row at the same value with exactly the same amount. The engine is
        # keyed by account, value and amount in cents together, so only exact repeats count. A row without
        # an amount matches nothing. Two zero-dollar checks at one merchant do match: that repeat is worth
        # seeing too.
        same_amount = _shared.key_engine(account, [codes, cents], secs)
        out[name + "same_amount_n"] = same_amount.count()
        out[name + "same_amount_log_secs"] = np.log1p(same_amount.seconds_since_last())

    # Novelty velocity. A row is a "first use" when it holds a value that the account had not used before
    # inside the look-back. The count below runs over the account's earlier rows, so it asks: how many
    # first uses happened just before this row? The current row's own flag is not included; it is the
    # `seen` column above. Two rows of the same second at the same new value both count, because neither
    # can see the other.
    first_use = (codes >= 0) & ~seen
    for label, window in NOVELTY_WINDOWS:
        out[name + "new_" + label] = by_account.count(window, where=first_use)
    # Different values of this key among the account's earlier rows.
    for label, window in DISTINCT_WINDOWS:
        out[name + "distinct_" + label] = by_account.distinct(codes, window)


def build_exact_match(df, keys=None, account_col=None, time_col=None, amount_col=None, months_back=1,
                      file_start=None, prefix="match_", fill=None):
    """Exact-match history columns for every row of `df`.

    df           every row of one or more whole files (whole account histories), in any order
    keys         {short name: column name}; None reads the keys from settings (see _shared.default_keys)
    account_col, time_col, amount_col   column names; None reads them from settings
    months_back  the look-back starts on the first day of the month this many months before the row's
                 month; None means no limit (every earlier row in the table may be read)
    file_start   first day of data in the files (text, Timestamp or seconds); None uses the first day found
    prefix       put in front of every column name
    fill         None keeps missing values; a number replaces them

    Returns a float DataFrame [rows, 2 + 19 per key] with the index of `df`. A key that is
    switched off or absent is skipped with one printed line. Without an amount column the
    five amount columns of every key are skipped. A row without a time or an account cannot
    be placed in any history and gets missing values.

    Time rule: a row uses only rows of the same account in strictly earlier seconds and not
    before its look-back start. Rows of the same second never see each other. A row without
    a value for a key matches nothing at that key and is in no other row's history there.

    The columns are computed block by block (see _shared.blockwise): the rows of each month
    are computed on a table cut at their look-back start. The novelty velocity needs that,
    because it is built on the "first use" flags of earlier rows, and an earlier row must not
    remember more than the row that reads it.
    """
    keys = _shared.default_keys() if keys is None else keys
    account, secs = _shared.account_and_time(df, account_col, time_col)
    amount = _shared.column(df, _shared.pick(amount_col, "AMOUNT_COL"), "the amount columns of every key", numeric=True)
    # The amount in whole cents, as a code, so that "the same amount" is an exact comparison.
    cents = None if amount is None else _shared.value_codes(np.round(amount * 100.0))[0]
    codes = {name: _shared.value_codes(values, _shared.KEY_TRANSFORMS.get(name))[0]
             for name, values in _shared.columns(df, keys, "exact-match keys").items()}

    def one_block(rows):
        """The columns of the rows of one block, computed as if the block were the whole table."""
        by_account = EarlierRows(account[rows], secs[rows])
        rows_before = by_account.count()
        out = {prefix + "rows_in_lookback": rows_before}
        for name, key_codes in codes.items():
            _one_key(out, f"{prefix}{name}_", account[rows], secs[rows], by_account, rows_before, key_codes[rows],
                     None if amount is None else amount[rows], None if cents is None else cents[rows])
        return out

    built = _shared.blockwise(secs, months_back, one_block)
    # Exposure: how many earlier rows the account has in its look-back and how long that look-back is.
    # A count of two earlier visits reads differently after 30 days of history than after 60.
    out = {prefix + "rows_in_lookback": built.pop(prefix + "rows_in_lookback", np.full(len(df), np.nan)),
           prefix + "days_in_lookback": lookback.days_available(secs, file_start, months_back)}
    out.update(built)
    return _shared.as_frame(out, df.index, fill)


def main(argv=None):
    """Command line: build the columns for some files (or for made-up rows) and print a summary."""
    return _shared.run_builder(
        argv, "Exact-match history columns per account (seen before, how long ago, how often).", needed_columns(),
        build=lambda df, args: build_exact_match(df, file_start=args.file_start))


if __name__ == "__main__":
    main()
