"""Ratio columns: the amount against what the account holds and against what it usually spends.

What this file does
-------------------
For every row it writes (all names carry the prefix `ratio_`):

    amount_to_balance        amount over the available balance
    amount_to_merch_limit    amount over the remaining daily merchandise limit
    amount_to_cash_limit     amount over the remaining daily cash limit
    headroom_code            what the amount does to the balance: 0 unknown, 1 under 50 percent,
                             2 from 50 to 90 percent, 3 90 percent or more, 4 exact drain (the amount
                             equals the balance to the cent), 5 overdraw (the amount exceeds the balance)
    spent_24h_to_balance     the amounts of the account's earlier rows of the last 24 hours plus this
                             amount, over the balance
    n_amounts_30d            how many earlier amounts of the last 30 days the next three columns rest on
    amount_to_mean_30d       amount over the mean of those earlier amounts
    amount_to_max_30d        amount over the largest of them
    amount_midrank_30d       where the amount stands among them, from 0 (smaller than all) to 1 (larger
                             than all); equal amounts count half

A ratio whose denominator is zero, negative or missing is a missing value. It is never a
large stand-in number: a made-up 999999 would be read by a model as a real measurement, and
it would sit in the same place as the most extreme true ratios.

Why it exists
-------------
A thief who has a card does not know how long it will work, so the typical move is to take
as much as possible quickly: an amount close to everything the account holds, or a series
of purchases that empties it within hours. The raw amount cannot show that, because 400
dollars is routine on one account and the whole balance on another. The ratios put the
amount on the account's own scale, in two ways: against what is available right now
(balance and daily limits) and against what the account usually spends (mean, maximum and
rank over the last 30 days). The headroom code names the cases a ratio blurs: an amount
exactly equal to the balance is a different event from an amount of 97 percent of it.

A tree model can only cut on single columns; it cannot divide two of them, so it cannot
build these ratios from the raw fields. A network with one token per field has to learn
division from examples, which costs capacity that a ready ratio saves.

Where it goes
-------------
Raw files, then these feature columns, then the network (extra numeric inputs, appended in
the per-file step that is `SequenceBuilder._encode_file` in the original code, each one a
numeric token of `FeatureTokenizer`) or a second-stage tree model. `headroom_code` is a
code with six values: for the network it belongs with the categorical inputs.

What to change for the pod
--------------------------
`settings.AMOUNT_COL`, `BALANCE_COL`, `MERCH_LIMIT_COL`, `CASH_LIMIT_COL`, `ACCOUNT_COL` and
`TIME_COL`. `BALANCE_IS_BEFORE_THE_ROW` below says whether the balance column shows the
balance before the transaction (the usual case) or after it. Whether earlier declined rows
should count as money spent is a choice: by default every earlier row counts, because a
refused attempt still shows what the card was asked for; pass `spent_rows` (for example
the approved rows) to count fewer. Ratios are heavy-tailed; a network input usually wants
log(1 + ratio), which the preprocessing step can apply.

How to try it
-------------
    python additions/features/ratios.py --demo
    python additions/features/ratios.py --base /path/to/files --files 8217 8218 --out ratios.parquet

    columns = build_ratios(df)                               # df: whole files
    python -m pytest -q additions/tests/test_features_ratios.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np

from additions import settings
from additions.common.history import EarlierRows
from additions.features import _shared

# PLACEHOLDER: True when the balance column holds the balance BEFORE the row's amount is taken off.
# Set it to False if the files store the balance after the transaction; the amount is then added back.
BALANCE_IS_BEFORE_THE_ROW = True

DAY = 86_400
HEADROOM = ("unknown", "under_50_percent", "50_to_90_percent", "90_percent_or_more", "exact_drain", "overdraw")


def needed_columns():
    """The raw columns this builder reads (None entries are optional columns that are switched off)."""
    return [settings.ACCOUNT_COL, settings.TIME_COL, settings.ID_COL, settings.AMOUNT_COL, settings.BALANCE_COL,
            settings.MERCH_LIMIT_COL, settings.CASH_LIMIT_COL]


def headroom_code(amount, balance):
    """What the amount does to the balance, as a small integer per row (see `HEADROOM` for the names).

    amount, balance   float [rows]; the balance is the one before the row
    Returns int8 [rows]: 0 when either number is missing, otherwise 1 to 5 in rising order of
    how much of the balance the amount takes. Amounts are compared in whole cents, so that
    "exactly the balance" does not depend on the last binary digit of a decimal number.
    """
    amount = np.asarray(amount, dtype=np.float64)
    balance = np.asarray(balance, dtype=np.float64)
    known = ~np.isnan(amount) & ~np.isnan(balance)
    cents = np.round(np.nan_to_num(amount) * 100.0)
    balance_cents = np.round(np.nan_to_num(balance) * 100.0)
    spending = known & (cents > 0)                     # a zero amount takes nothing, whatever the balance is
    code = np.zeros(len(amount), dtype=np.int8)
    code[known] = 1
    code[spending & (cents * 2 >= balance_cents)] = 2  # half of the balance or more
    code[spending & (cents * 10 >= balance_cents * 9)] = 3
    code[spending & (cents == balance_cents)] = 4
    code[spending & (cents > balance_cents)] = 5       # also every spending row on an empty or negative balance
    return code


def _per_row(slot, size, flags):
    """Add up one yes/no per pair into one number per asking row (`slot` says which row a pair belongs to)."""
    return np.bincount(slot, weights=flags.astype(np.float64), minlength=size)


def midrank_among_earlier(engine, values, window=None, max_history=500, pairs_per_chunk=2_000_000):
    """Where each row's value stands among the earlier values of the same key, from 0 to 1.

    engine       an `EarlierRows` object (it defines "the earlier rows of the same key")
    values       float [rows]; missing values are neither ranked nor ranked against
    window       seconds; only earlier rows this recent are used (None: all the engine allows)
    max_history  at most this many of the latest earlier rows are used per row

    Returns float [rows]: (earlier values that are smaller + half of those that are equal)
    divided by the number of earlier values; missing when there is none. 0.5 means "in the
    middle of what was seen before", 1.0 means "larger than anything before".

    The engine cannot count "earlier rows with a smaller value" from prefix sums, because
    the answer depends on both time and value. So each row is compared with its earlier rows
    directly, as pairs. The pairs are built in chunks of a few million, so memory stays flat;
    the loop below runs once per chunk, not once per row. `max_history` bounds the work for
    the rare account with thousands of rows a month.
    """
    v = np.asarray(values, dtype=np.float64)[engine.order]       # the engine's own order: by key, then by time
    lo, hi = engine.bounds(window)                               # rows lo .. hi-1 are the earlier rows of each row
    lo = np.maximum(lo, hi - int(max_history))
    usable = engine.valid & ~np.isnan(v)
    n = len(v)
    smaller, equal, have = np.zeros(n), np.zeros(n), np.zeros(n)
    length = hi - lo
    pairs_done = np.cumsum(length)
    begin = 0
    while begin < n:
        budget = (pairs_done[begin - 1] if begin else 0) + pairs_per_chunk
        stop = max(begin + 1, int(np.searchsorted(pairs_done, budget, side="right")))
        reps = length[begin:stop]
        asking = np.repeat(np.arange(begin, stop), reps)         # the row that asks, once per earlier row
        first_pair = np.cumsum(reps) - reps
        other = lo[asking] + np.arange(len(asking)) - np.repeat(first_pair, reps)   # the earlier row
        ok = usable[other]
        slot, size = asking - begin, stop - begin
        smaller[begin:stop] = _per_row(slot, size, ok & (v[other] < v[asking]))
        equal[begin:stop] = _per_row(slot, size, ok & (v[other] == v[asking]))
        have[begin:stop] = _per_row(slot, size, ok)
        begin = stop
    rank = _shared.ratio(smaller + 0.5 * equal, have)
    rank[~usable] = np.nan
    return rank[engine.inverse]


def build_ratios(df, account_col=None, time_col=None, amount_col=None, balance_col=None, merch_limit_col=None,
                 cash_limit_col=None, balance_is_before=None, spent_rows=None, months_back=1, max_history=500,
                 prefix="ratio_", fill=None):
    """Ratio columns for every row of `df`.

    df           every row of one or more whole files (whole account histories), in any order
    account_col, time_col, amount_col, balance_col, merch_limit_col, cash_limit_col
                 column names; None reads them from settings
    balance_is_before   whether the balance column shows the balance before the row; None reads
                 `BALANCE_IS_BEFORE_THE_ROW`
    spent_rows   bool [rows] marking the rows whose amount counts as money spent when they are
                 history; None counts every row
    months_back  the look-back starts on the first day of the month this many months before the row's
                 month; None means no limit
    max_history  the mid-rank uses at most this many of the latest earlier amounts
    prefix       put in front of every column name
    fill         None keeps missing values; a number replaces them

    Returns a DataFrame [rows, up to 9] with the index of `df`; `headroom_code` is a small
    integer, the rest are floats. Without an amount column nothing can be built: one line
    is printed and the DataFrame has no columns. A missing balance or limit column only
    drops the columns that need it.

    Time rule: the columns that use history read rows of the same account in strictly
    earlier seconds, not before the look-back start. The balance and the limits are the
    row's own fields; they are known when the transaction arrives.
    """
    amount = _shared.column(df, _shared.pick(amount_col, "AMOUNT_COL"), "the ratio columns", numeric=True)
    if amount is None:
        return _shared.as_frame({}, df.index)
    balance = _shared.column(df, _shared.pick(balance_col, "BALANCE_COL"), "the balance ratios", numeric=True)
    limits = {
        "merch": _shared.column(df, _shared.pick(merch_limit_col, "MERCH_LIMIT_COL"),
                                "the merchandise-limit ratio", numeric=True),
        "cash": _shared.column(df, _shared.pick(cash_limit_col, "CASH_LIMIT_COL"),
                               "the cash-limit ratio", numeric=True),
    }
    account, secs = _shared.account_and_time(df, account_col, time_col)
    by_account = EarlierRows(account, secs, start=_shared.history_start(secs, months_back))

    out = {}
    if balance is not None:
        if not (BALANCE_IS_BEFORE_THE_ROW if balance_is_before is None else balance_is_before):
            balance = balance + np.nan_to_num(amount)        # put the row's own amount back
        out[prefix + "amount_to_balance"] = _shared.ratio(amount, balance)
    for name, limit in limits.items():
        if limit is not None:
            out[f"{prefix}amount_to_{name}_limit"] = _shared.ratio(amount, limit)
    if balance is not None:
        out[prefix + "headroom_code"] = headroom_code(amount, balance)
        # Everything the account was asked for in the last 24 hours, this row included, against what it
        # holds now. One purchase of a tenth of the balance is ordinary; the tenth such purchase today is not.
        earlier_spend = by_account.total(amount, DAY, where=spent_rows)
        out[prefix + "spent_24h_to_balance"] = _shared.ratio(earlier_spend + amount, balance)

    # The amount against the account's own last 30 days. The count comes first: a ratio to the mean of two
    # earlier amounts is a much weaker statement than a ratio to the mean of forty.
    out[prefix + "n_amounts_30d"] = by_account.count(30 * DAY, where=~np.isnan(amount))
    out[prefix + "amount_to_mean_30d"] = _shared.ratio(amount, by_account.mean(amount, 30 * DAY))
    out[prefix + "amount_to_max_30d"] = _shared.ratio(amount, by_account.maximum(amount, 30 * DAY))
    out[prefix + "amount_midrank_30d"] = midrank_among_earlier(by_account, amount, 30 * DAY, max_history)
    return _shared.as_frame(out, df.index, fill, codes=(prefix + "headroom_code",))


def main(argv=None):
    """Command line: build the columns for some files (or for made-up rows) and print a summary."""
    return _shared.run_builder(
        argv, "Ratio columns: the amount against balance, limits and the account's own spending.", needed_columns(),
        build=lambda df, args: build_ratios(df))


if __name__ == "__main__":
    main()
