"""Small helpers shared by the feature builders of this folder.

What this file does
-------------------
It holds the steps that every builder in `additions/features/` repeats: reading a setting at
the moment of the call, fetching an optional column (and saying so in one line when it is
not there), giving every distinct value a small integer with a marker for "no value",
building the history engine for "the same account and the same value", dividing without
ever producing an infinite number, counting how often values occur in a population, turning
a set of per-row arrays into a DataFrame aligned to the input rows, and one small command
line that all builders share.

Why it exists
-------------
Three rules hold for every column this folder produces, and each is easier to keep when it
is written once. A missing raw value never matches anything, not even another missing
value: two rows without a merchant id did not happen at the same merchant. A division whose
denominator is zero or missing gives a missing value, never a huge number that a model
would read as a real measurement. Column names come from settings.py at the moment a
function is called, so one call can use other names and an edit of settings.py reaches
every builder.

Where it goes
-------------
Nowhere by itself. The builders of this folder import it. It runs on the CPU, on the table
of raw rows, between the raw files and the feature columns, before preprocessing and
before the tokenizer.

What to change for the pod
--------------------------
`MISSING_TEXT` lists the text values that mean "no value" in the raw files. `ip_prefix`
decides how much of an IP address is compared. `default_keys` lists the matching keys and
reads their column names from settings.py. `FLOAT` is the number type of the output columns.

How to try it
-------------
    from additions.features import _shared
    codes, distinct = _shared.value_codes(df[settings.MERCHANT_COL])   # -1 marks "no value"
    at_merchant = _shared.key_engine(account, codes, secs)             # history per account and merchant
    python -m pytest -q additions/tests/test_features_shared.py
"""
import argparse
import json

import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, tables, timekeys
from additions.common.history import EarlierRows
from additions.common.timekeys import MISSING_SECOND
from additions.features import lookback

# PLACEHOLDER: text values that stand for "no value" in the raw files, besides real missing values.
# A blank text is the usual one; add markers such as "NA" or "UNKNOWN" if the files use them.
MISSING_TEXT = ("",)

# The number type of the numeric output columns. Half the size of float64, and precise enough for
# counts, ratios and logarithms. Use np.float64 if a consumer needs it.
FLOAT = np.float32

# What separates the two halves of a pair of values written as one text, as in "previous > current".
PAIR_SEPARATOR = " > "


# ----------------------------------------------------------------------------------------------
# settings and columns
# ----------------------------------------------------------------------------------------------

def pick(value, setting_name):
    """`value` when it is given, otherwise what settings.py holds under `setting_name`.

    The setting is read when the function runs, not when the module is imported, so an edit
    of settings.py (or a value set by a test) is seen by every later call.
    """
    return getattr(settings, setting_name) if value is None else value


def column(df, name, what, numeric=False):
    """The values of column `name` as an array [rows], or None when the column is not available.

    A name of None (the setting is switched off) or a name the table does not have makes the
    function print one line and return None; the caller then skips whatever needed it. `what`
    is a few words naming the skipped part, for that line. With `numeric=True` the values
    come back as float64 and anything that is not a number becomes a missing value.
    """
    if not name or name not in df.columns:
        reason = "no column is set" if not name else f"the table has no column '{name}'"
        print(f"note: {reason} for {what}; that part is skipped")
        return None
    if numeric:
        return pd.to_numeric(df[name], errors="coerce").to_numpy(dtype=np.float64)
    return df[name].to_numpy()


def columns(df, named, what):
    """The values of several optional columns, as {short name: array [rows]}.

    `named` maps a short name to a column name (or to None). Columns that are switched off or
    absent are left out of the result, and one printed line names all of them.
    """
    found, skipped = {}, []
    for name, col in named.items():
        if col and col in df.columns:
            found[name] = df[col].to_numpy()
        else:
            skipped.append(name if not col or col == name else f"{name} ('{col}')")
    if skipped:
        print(f"note: {what} skipped because the column is not set or not in the table: {', '.join(skipped)}")
    return found


# PLACEHOLDER: how much of an IP address is compared; return one text per distinct address.
def ip_prefix(distinct):
    """The part of an IP address that is compared: the first two of its four parts ("10.20").

    An address changes inside one network from day to day, so the whole address is too strict
    a key and the first two parts are enough to tell networks apart. The function gets the
    array of distinct values of the column and returns one text per value.
    """
    return np.array([".".join(str(v).split(".")[:2]) for v in distinct], dtype=object)


# Changes applied to the distinct values of a key before they are compared, by short key name.
KEY_TRANSFORMS = {"ip": ip_prefix}


def default_keys():
    """The matching keys, as {short name: column name read from settings.py}.

    The short name becomes part of the output column names. A column name of None means the
    key is not available; the builders skip it. A caller that wants other keys passes its own
    dict in the same form.
    """
    return {
        "merchant": settings.MERCHANT_COL,
        "mcc": settings.MCC_COL,
        "postal": settings.MERCHANT_POSTAL_COL,
        "state": settings.MERCHANT_STATE_COL,
        "country": settings.MERCHANT_COUNTRY_COL,
        "card": settings.CARD_COL,
        "terminal": settings.TERMINAL_COL,
        "device": settings.DEVICE_COL,
        "token": settings.TOKEN_COL,
        "ip": settings.IP_COL,
    }


# ----------------------------------------------------------------------------------------------
# values as small integers, with "no value" marked
# ----------------------------------------------------------------------------------------------

def _no_value(distinct):
    """Which of the distinct values mean "no value": real missing values and blank text."""
    gone = np.asarray(pd.isna(distinct), dtype=bool)
    if distinct.dtype.kind in "OU":
        text = pd.Series(distinct, dtype=object).astype(str).str.strip()
        gone |= text.isin(MISSING_TEXT).to_numpy()
    return gone


def value_codes(values, transform=None):
    """One small integer per distinct value, and -1 on every row that holds no value.

    Returns (codes, distinct). `codes` is int64 [rows]. `distinct` holds the distinct values,
    so `distinct[codes[i]]` is the value of row i wherever `codes[i] >= 0`.

    The values are only ever compared for equality, which is all an exact-match feature needs:
    the integers say "same value" or "different value" and nothing about the value itself.
    The -1 marker is what lets every later step keep the rule that a missing value never
    matches anything. `transform`, when given, is applied to the array of distinct values
    (not to every row, which keeps it cheap); values that become equal share one code.
    """
    values = np.asarray(values)
    codes = timekeys.codes(values)                         # a missing value is one more code at this point
    _, example = np.unique(codes, return_index=True)       # one example row for each code
    distinct = values[example]
    keep = ~_no_value(distinct)                            # decided on the raw values, before any change
    if transform is not None and keep.any():
        changed = distinct.astype(object)
        changed[keep] = transform(distinct[keep])
        distinct = changed
        keep &= ~_no_value(distinct)                       # a value that the change left blank is no value either
    final = np.full(len(distinct), -1, dtype=np.int64)     # -1 stays on every code that means "no value"
    kept = distinct[:0]
    if keep.any():
        final[keep] = timekeys.codes(distinct[keep])       # values made equal by `transform` share a code
        _, example = np.unique(final[keep], return_index=True)
        kept = distinct[keep][example]
    return final[codes], kept


def as_text(value):
    """One value as text. A whole number is written without a decimal point (5.0 becomes "5")."""
    if isinstance(value, (float, np.floating)) and float(value).is_integer():
        return str(int(value))
    return str(value).strip()


def coded_text(values):
    """Like `value_codes`, with every distinct value written as text.

    Returns (codes, texts): int64 [rows] with -1 for "no value", and the array of distinct
    texts. Text is what a population table is keyed by, because a table fitted on one set of
    files must find the same value in another set even when a column is stored as whole
    numbers in one and as decimals in the other. The conversion loops over the distinct
    values only, never over the rows.
    """
    return value_codes(values, transform=lambda distinct: np.array([as_text(v) for v in distinct], dtype=object))


# ----------------------------------------------------------------------------------------------
# accounts, time and the history engines
# ----------------------------------------------------------------------------------------------

def account_and_time(df, account_col=None, time_col=None):
    """(account, secs): a small integer per account and the whole second of every row, both [rows].

    A row with no account or no time gets the missing-time marker. The history engine gives
    such a row no history and keeps it out of every other row's history, which is the only
    safe reading of a row that cannot be placed.
    """
    account, _ = value_codes(df[pick(account_col, "ACCOUNT_COL")])
    secs = timekeys.seconds(df[pick(time_col, "TIME_COL")])
    placed = account >= 0
    secs = np.where(placed, secs, MISSING_SECOND)
    account = np.where(placed, account, account.max() + 1 if len(account) else 0)
    return account, secs


def history_start(secs, months_back=1):
    """The earliest second each row may read, in the form the history engine takes.

    `months_back=1` is the calendar rule of lookback.py: the first day of the month before the
    row's month. None means no limit (every earlier row in the table may be read). Rows with a
    missing time get 0; they have no history whatever the start is.
    """
    if months_back is None:
        return None
    start = lookback.lookback_start(secs, months_back)
    return np.where(np.asarray(secs) == MISSING_SECOND, 0, start)


def blocks(secs, months_back=1):
    """Cut the rows into blocks shaped like an evaluation file. Yields (rows, is_target) per calendar month.

    `rows` holds the positions of the rows from the look-back start of a month to the end of
    that month; `is_target` marks, among them, the rows of the month itself. With
    `months_back=None` there is one block: every row with a time, all of them targets.
    """
    secs = np.asarray(secs)
    if months_back is None:
        rows = np.flatnonzero(secs != MISSING_SECOND)
        yield rows, np.ones(len(rows), dtype=bool)
        return
    for block in lookback.month_blocks(secs, months_back).itertuples(index=False):
        rows = np.flatnonzero((secs >= block.block_start) & (secs < block.target_end))
        yield rows, secs[rows] >= block.target_start


def blockwise(secs, months_back, build_block):
    """Compute columns block by block, so that a row depends on nothing before its look-back start.

    `build_block(rows)` gets the positions of the rows of one block and returns {column: one
    value per row of the block}, computed as if the block were the whole table. Each row keeps
    the values from the block in which it is a target. Returns {column: `FLOAT` [all rows]};
    rows without a time are in no block and stay missing.

    Why blocks and not only a start time for the engine: some columns are built on quantities
    of the earlier rows themselves ("was that earlier row a first use?", "how surprising was
    that earlier row?"). Those quantities depend on how far back the EARLIER row could see. In
    short evaluation files an earlier row of the history month sees little; in long training
    files it sees a month more. Cutting the table first makes both see the same, and the
    columns of a training row equal those of a scored row. The loop runs once per calendar
    month, never once per row; every row is computed in one block as a target and in the next
    as history.
    """
    out = None
    for rows, is_target in blocks(secs, months_back):
        part = build_block(rows)
        if out is None:
            out = {name: np.full(len(secs), np.nan, dtype=FLOAT) for name in part}
        for name, values in part.items():
            out[name][rows[is_target]] = np.asarray(values)[is_target]
    return out or {}


def key_engine(account, codes, secs, start=None):
    """The history engine for "the same account and the same value".

    `codes` is one code array from `value_codes`, or a list of them when several values have
    to be equal at once (for example the merchant and the amount in cents). A row with a
    negative code holds no value: its clock is set to the missing-time marker, so it has no
    history at the key and is never part of another row's history. That is how "a missing
    value never matches anything" is kept without a special case in every question.
    """
    parts = list(codes) if isinstance(codes, (list, tuple)) else [codes]
    present = np.ones(len(account), dtype=bool)
    for part in parts:
        present &= np.asarray(part) >= 0
    key = timekeys.codes(account, *parts)
    clock = np.where(present, secs, MISSING_SECOND)
    return EarlierRows(key, clock, start=start)


def previous_pairs(by_account, codes, texts=None):
    """The pair (value of the account's previous row, value of this row), coded like a value.

    `by_account` is the history engine of the account, `codes` and `texts` come from
    `coded_text`. The previous row is the latest strictly earlier row of the account that
    holds a value. Returns (pair_codes, pair_texts, previous_codes): codes are int64 [rows]
    with -1 where there is no pair (no earlier row, or no value on this row), and the text of
    a pair is "previous > current". The texts are built once per distinct pair, not per row;
    without `texts` they are not built at all and None is returned in their place.
    """
    codes = np.asarray(codes, dtype=np.int64)
    has = codes >= 0
    previous = np.asarray(by_account.last(codes, where=has, default=-1), dtype=np.int64)
    paired = has & (previous >= 0)
    combo = timekeys.codes(previous, codes)
    pair_texts = None
    if texts is not None:
        _, example = np.unique(combo, return_index=True)
        pair_texts = np.array(
            [f"{texts[previous[i]]}{PAIR_SEPARATOR}{texts[codes[i]]}" if paired[i] else "" for i in example],
            dtype=object)
    return np.where(paired, combo, -1), pair_texts, np.where(paired, previous, -1)


# ----------------------------------------------------------------------------------------------
# numbers
# ----------------------------------------------------------------------------------------------

def ratio(top, bottom):
    """top / bottom where the bottom is positive, and a missing value everywhere else.

    A zero, negative or missing denominator means the ratio does not exist. Writing a large
    number there instead would hand the model a measurement that was never made.
    """
    top = np.asarray(top, dtype=np.float64)
    bottom = np.asarray(bottom, dtype=np.float64)
    out = np.full(np.broadcast(top, bottom).shape, np.nan)
    np.divide(top, bottom, out=out, where=bottom > 0)
    return out


def as_frame(named, index, fill=None, codes=()):
    """Turn {column name: one value per row} into a DataFrame aligned to the input rows.

    Flags and numbers become `FLOAT`; the columns listed in `codes` are small integers (codes
    for an embedding table or a tree) and stay integers. `fill`, when it is a number, replaces
    the missing values of the numeric columns, for a consumer that cannot take missing values;
    the flag columns of each builder still say where a value did not exist.
    """
    out = {}
    for name, values in named.items():
        values = np.asarray(values)
        if name in codes:
            out[name] = values.astype(np.int16)
            continue
        values = values.astype(FLOAT, copy=False)
        if fill is not None:
            values = np.where(np.isnan(values), FLOAT(fill), values)
        out[name] = values
    return pd.DataFrame(out, index=index)


# ----------------------------------------------------------------------------------------------
# population tables: how often each value occurs
# ----------------------------------------------------------------------------------------------

def count_table(codes, texts, top=None):
    """How often each value occurs: {"counts": {text: rows}, "rows": rows that hold a value}.

    `top` keeps only that many of the most frequent values, which bounds the size of a table
    over a field with very many values. A value outside the table is later read as "never
    seen", which is nearly true for the rare values that were dropped.
    """
    codes = np.asarray(codes)
    counts = np.bincount(codes[codes >= 0], minlength=len(texts))
    order = np.argsort(-counts, kind="stable")
    if top is not None:
        order = order[: int(top)]
    return {"counts": {str(texts[i]): int(counts[i]) for i in order if counts[i] > 0}, "rows": int(counts.sum())}


def table_counts(codes, texts, table, own=None):
    """For every row, how often its value occurs in a population table (float [rows]).

    Values that are not in the table, and rows with no value, get 0. `own` is the number of
    those occurrences that come from the row's own account (see `own_counts`); it is taken
    off, so the row is compared with other accounts only.
    """
    codes = np.asarray(codes)
    per_value = np.array([table["counts"].get(str(t), 0) for t in texts], dtype=np.float64)
    out = np.zeros(len(codes))
    has = codes >= 0
    out[has] = per_value[codes[has]]
    if own is not None:
        out = np.clip(out - own, 0.0, None)
    return out


def table_share(codes, texts, table, own=None, own_rows=None, prior=1.0):
    """The smoothed share of every row's value in a population table; missing where the row has no value.

        share = (count + prior) / (rows + prior * (distinct values + 1))

    The `prior` adds one imaginary row to every value, and one for "a value never seen". That
    keeps the share of an unseen value small but above zero, so its logarithm exists. `own`
    and `own_rows` remove the row's own account from the count and from the total.
    """
    count = table_counts(codes, texts, table, own)
    rows = float(table["rows"]) - (0.0 if own_rows is None else own_rows)
    share = (count + prior) / (np.clip(rows, 0.0, None) + prior * (len(table["counts"]) + 1.0))
    return np.where(np.asarray(codes) >= 0, share, np.nan)


def own_counts(account, codes):
    """How much of a count comes from the row's own account: (same value, any value), both float [rows].

    `same value` is the number of rows of the account that hold the row's value (the row
    itself included); `any value` is the number of rows of the account that hold a value.
    Taking these off a population table that was fitted on the same rows leaves what other
    accounts did. Without that step a rare value would look less rare on the rows the table
    was fitted on than on new rows, simply because each row counts itself.
    """
    codes = np.asarray(codes)
    has = codes >= 0
    pair = timekeys.codes(account, codes)
    same = np.bincount(pair)[pair].astype(np.float64)
    same[~has] = 0.0
    rows = np.bincount(account, weights=has.astype(np.float64))[account]
    return same, rows


def save_tables(fitted, path):
    """Write fitted population tables to a JSON file (plain text; an existing file is replaced)."""
    with open(path, "w", encoding="ascii") as handle:
        json.dump(fitted, handle)
    return path


def load_tables(path):
    """Read population tables written by `save_tables`."""
    with open(path, "r", encoding="ascii") as handle:
        return json.load(handle)


# ----------------------------------------------------------------------------------------------
# the command line shared by the builders
# ----------------------------------------------------------------------------------------------

def summary(frame):
    """One line per output column: share of missing values, mean, smallest and largest value."""
    lines = []
    for name in frame.columns:
        values = frame[name].to_numpy(dtype=np.float64)
        have = values[~np.isnan(values)]
        lines.append({
            "column": name,
            "missing": 1.0 - len(have) / len(values) if len(values) else np.nan,
            "mean": have.mean() if len(have) else np.nan,
            "min": have.min() if len(have) else np.nan,
            "max": have.max() if len(have) else np.nan,
        })
    return pd.DataFrame(lines, columns=["column", "missing", "mean", "min", "max"])


def write_out(frame, path):
    """Write a table to `path`: comma-separated text when the name ends in .csv, parquet otherwise."""
    if str(path).lower().endswith(".csv"):
        frame.to_csv(path, index=False)
        return path
    return tables.write_table(frame, path)


def run_builder(argv, description, needed, build, fit=None):
    """The command line of a feature builder: read rows, build the columns, print a summary.

    argv         the command-line arguments (None reads them from the shell)
    description  one sentence for the help text
    needed       the raw columns to read from the files (None entries, and names a file lacks, are skipped)
    build        a function build(df, args) that returns the DataFrame of new columns; with `fit` it
                 is called as build(df, args, fitted)
    fit          a function fit(df, args) that returns population tables, for the builders that
                 need them. Such a builder also gets the options --fit-base, --fit-files, --tables,
                 --save-tables and --remove-own-account

    With --demo the rows are made up, so the builder can be tried with no data at all. With
    --out the new columns are written to a file, together with the transaction id when the
    table has one, so that they can be joined back to the raw rows. Returns the DataFrame.
    """
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("--base", default=settings.EVAL_BASE, help="folder that holds the numbered files")
    parser.add_argument("--files", type=int, nargs="+", default=None,
                        help="file numbers to read (default: settings.CONSUMER_READ_FILES)")
    parser.add_argument("--file-start", default=None,
                        help="first day of data in these files, for example 2025-05-01 (default: the first day found)")
    parser.add_argument("--demo", action="store_true", help="run on made-up rows instead of files")
    parser.add_argument("--out", default=None, help="write the new columns here (.csv, otherwise parquet)")
    parser.add_argument("--id-col", default=settings.ID_COL,
                        help="the transaction id column that is written next to the new columns")
    if fit is not None:
        parser.add_argument("--fit-base", default=settings.TRAIN_BASE,
                            help="folder of the files the population tables are fitted on")
        parser.add_argument("--fit-files", type=int, nargs="+", default=None,
                            help="file numbers the tables are fitted on (default: settings.TRAIN_FILES)")
        parser.add_argument("--tables", default=None, help="read fitted tables from this JSON file instead of fitting")
        parser.add_argument("--save-tables", default=None, help="write the fitted tables to this JSON file")
        parser.add_argument("--remove-own-account", action="store_true",
                            help="set when the rows are the ones the tables were fitted on: "
                                 "each row is then compared with other accounts only")
    args = parser.parse_args(argv)

    if args.demo:
        df = synthetic.make_transactions(n_accounts=200, seed=1)
    else:
        df = tables.read_files(args.base, args.files or settings.CONSUMER_READ_FILES, needed)
    if fit is None:
        frame = build(df, args)
    else:
        if args.tables:
            fitted = load_tables(args.tables)
        elif args.demo:
            fitted = fit(synthetic.make_transactions(n_accounts=200, seed=2), args)
        else:
            fitted = fit(tables.read_files(args.fit_base, args.fit_files or settings.TRAIN_FILES, needed), args)
        if args.save_tables:
            save_tables(fitted, args.save_tables)
        frame = build(df, args, fitted)

    print(f"{len(frame)} rows, {frame.shape[1]} new columns")
    if frame.shape[1]:
        print(summary(frame).to_string(index=False, float_format=lambda x: f"{x:.4f}"))
    if args.out:
        out = frame.copy()
        if args.id_col in df.columns:
            out.insert(0, args.id_col, df[args.id_col].to_numpy())
        else:
            print(f"note: the table has no column '{args.id_col}'; the rows of the output are in input order")
        write_out(out, args.out)
        print(f"written: {args.out}")
    return frame
