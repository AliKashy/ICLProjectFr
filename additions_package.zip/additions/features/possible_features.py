"""A catalogue of possible features, in addition to the inputs the model already has.

What this file does
-------------------
It lists candidate per-row features, one entry each, and builds the ones that can be computed
from the raw transaction columns. Every entry says what the feature measures, why it could
help, what it needs, and where it is built: here, in another file of this package, or nowhere
yet because a column is needed first. Calling `build_possible_features` returns the columns
that can be built as a table aligned to the input rows; `list_features` prints the catalogue.

Why it exists
-------------
The model in use already reads many fields. The features in this file are offered on top of
those: each one is a possible addition, to be skipped where the model already holds the same
information. A catalogue in one place, with a working builder behind most entries, lets every
candidate be screened quickly (for example with a tree model on top of the model's own score)
before any of them costs a training run. The entries are grouped by what they describe:
how fast the account is transacting, how the amount compares with the account's habits, where
and how the card is being used, what the bank decided on earlier transactions, and how the
network risk score has moved.

Where it goes
-------------
On the CPU, before training: raw rows in, feature columns out. A column that survives the
screen becomes one more numeric input of the model (one more row in the list of predictors)
or one more column for a downstream tree model. In the original code the per-row inputs are
encoded in `SequenceBuilder._encode_file` and tokenised by `FeatureTokenizer`.

What to change for the pod
--------------------------
The column names in settings.py, the optional column names in OPTIONAL_COLUMNS below, and the
code values in the PLACEHOLDER constants below. To add a feature, add one entry to CATALOGUE:
the builder needs no other change for the operations it already knows (count, sum, mean, max,
min, since_last, since_first, distinct, previous value, faded sum, row expression, derived).

How to try it
-------------
    python additions/features/possible_features.py --list
    python additions/features/possible_features.py --demo                  # build on made-up rows
    python additions/features/possible_features.py --build raw_rows.parquet --out features.parquet

    from additions.features.possible_features import build_possible_features
    columns = build_possible_features(raw_rows, families=["velocity", "amount"])

The test is additions/tests/test_features_possible_features.py.

The time rule
-------------
Every history feature uses only rows of strictly earlier seconds of the same account. Rows in
the same second never see each other. A feature about the bank's decisions reads the decisions
on earlier rows only; a row never reads its own decision. No feature here reads the fraud label.
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np
import pandas as pd

from additions import settings
from additions.common import synthetic, tables, timekeys
from additions.common.history import EarlierRows
from additions.common.timekeys import MISSING_SECOND
from additions.features import _shared as shared
from additions.features import outcome_history

# Window lengths in seconds, named so the catalogue reads easily.
M5, M15, H1, H6, D1, D2, D7, D30 = 300, 900, 3_600, 21_600, 86_400, 172_800, 604_800, 2_592_000

# PLACEHOLDER: the value(s) of the card-present column that mean the card was NOT present.
CARD_NOT_PRESENT_VALUES = ("N",)

# PLACEHOLDER: an amount below this many dollars counts as a "small" amount. Card testing often
# shows as a few very small purchases before a large one.
SMALL_AMOUNT = 5.0

# PLACEHOLDER: a network risk score at or above this value counts as "high".
HIGH_SCORE = 50.0

# PLACEHOLDER: columns that some extracts hold and that have no entry in settings.py. Each value
# is the column's name in the files, or None when the files do not have it. A feature whose
# column is None or absent is left out and one line says so.
OPTIONAL_COLUMNS = {
    # Counters and scores that the bank's own systems put on the transaction.
    "bank_minutes_since_last_auth": "user_data_1_strg_mins_since_last_auth",
    "bank_pos_count_15m": "cprsrvc__dbt_pos_15minct",
    "bank_purchase_count_5m": "cprsrvc__dbt_pp_5minct",
    "bank_merchant_cardholder_distance": "geodist_merchantzip_cardholderzip",
    "bank_wallet_risk_score": None,           # for example the risk score a wallet provider sends
    "bank_terminal_other_cards_15m": None,    # for example a same-terminal, different-card count
    # Dates on the account or the card. Each should pass the audit in asof_audit.py first: a date
    # written after the transaction would give the answer away.
    "date_card_issued": None,
    "date_card_expiry": "card_expiration_dt",
    "date_pin_changed": None,
    "date_address_changed": None,
    "date_email_changed": None,
    "date_phone_changed": None,
    "date_last_login": None,
    "date_account_opened": None,
    # Results of verification checks on the transaction, when stored as their own columns.
    "pin_check_failed_flag": None,
    "cvv_check_failed_flag": None,
    "address_check_failed_flag": None,
}


def _entry(name, family, what, why, how=None, status="here", needs=(), caution=""):
    """One catalogue entry as a dict. `how` is the recipe the builder follows (None when the
    feature is built in another file or needs a column first)."""
    return {"name": name, "family": family, "what": what, "why": why, "how": how, "status": status,
            "needs": tuple(needs), "caution": caution}


def _count(window, where=None, same=None):
    return {"op": "count", "window": window, "where": where, "same": same}


def _agg(op, value, window, where=None, same=None):
    return {"op": op, "value": value, "window": window, "where": where, "same": same}


def _since(op, where=None, same=None, window=None):
    return {"op": op, "where": where, "same": same, "window": window}


def _row(fn):
    return {"op": "row", "fn": fn}


def _derived(fn, uses):
    return {"op": "derived", "fn": fn, "uses": tuple(uses)}


def _ratio(a, b):
    """a / b with a missing value wherever b is zero or missing (never a huge number)."""
    a, b = np.broadcast_arrays(np.asarray(a, dtype=np.float64), np.asarray(b, dtype=np.float64))
    out = np.full(a.shape, np.nan)
    ok = np.isfinite(b) & (b != 0)
    out[ok] = a[ok] / b[ok]
    return out


def _z_score(value, mean, mean_of_squares):
    """(value - mean) / standard deviation, from a mean and a mean of squares.

    The result is missing when the spread is zero or too small to trust (all earlier amounts
    equal, or only one earlier amount). Dividing by a spread of almost zero would turn a
    rounding error into an enormous number.
    """
    variance = np.asarray(mean_of_squares, dtype=np.float64) - np.asarray(mean, dtype=np.float64) ** 2
    spread = np.sqrt(np.clip(variance, 0, None))
    return _ratio(np.asarray(value, dtype=np.float64) - mean, np.where(spread > 0.01, spread, np.nan))


# ----------------------------------------------------------------------------------------------
# The catalogue. Order matters only for derived features, which must come after what they use.
# ----------------------------------------------------------------------------------------------
CATALOGUE = []
_add = CATALOGUE.append

# ---- velocity: how fast the account is transacting -------------------------------------------
for _label, _w in (("5m", M5), ("15m", M15), ("1h", H1), ("6h", H6), ("24h", D1), ("48h", D2), ("7d", D7), ("30d", D30)):
    _add(_entry(f"n_rows_{_label}", "velocity", f"Number of earlier transactions of the account in the last {_label}.",
                "A burst of transactions is the plainest sign of a card being drained or tested. Several window "
                "lengths let a model tell a busy shopper from a sudden burst.", _count(_w)))
for _label, _w in (("1h", H1), ("24h", D1), ("7d", D7), ("30d", D30)):
    _add(_entry(f"amount_sum_{_label}", "velocity", f"Dollars the account moved in the last {_label} (earlier rows only).",
                "Money moved recently measures the size of a burst, where a count measures only its length.",
                _agg("sum", "amount", _w)))
_add(_entry("n_approved_1h", "velocity", "Earlier approved transactions in the last hour.",
            "Approved rows are the ones that cost money; a count of them separates a burst that is getting "
            "through from one that is being declined.", _count(H1, "approved")))
_add(_entry("burst_ratio", "velocity", "Transactions in the last hour over the account's usual hourly rate in 30 days.",
            "The same count means different things for different accounts; the ratio compares the account with itself.",
            _derived(lambda c: _ratio(c["n_rows_1h"], c["n_rows_30d"] / 720.0), ["n_rows_1h", "n_rows_30d"])))
_add(_entry("gap_seconds_log", "velocity", "Log of seconds since the account's previous transaction.",
            "Very short gaps are typical of scripted use.", _since("since_last")))
_add(_entry("gap_over_usual", "velocity", "The gap to the previous transaction over the account's mean gap in 30 days.",
            "A gap far shorter than usual for this account is more telling than a short gap as such.",
            _derived(lambda c: _ratio(np.expm1(c["gap_seconds_log"]), _ratio(float(D30), c["n_rows_30d"])),
                     ["gap_seconds_log", "n_rows_30d"])))

# ---- amount: how this amount compares with the account's habits ------------------------------
_add(_entry("amount_log", "amount", "Log of one plus the amount.",
            "Amounts span several orders of magnitude; on a log scale one dollar and five dollars are far apart, "
            "as they should be.", _row(lambda x: np.log1p(np.clip(x["amount"], 0, None)))))
_add(_entry("amount_cents", "amount", "The cents part of the amount (0 to 99).",
            "Test purchases and some fraud tools use round or repeated cents patterns.",
            _row(lambda x: np.round(np.abs(x["amount"]) * 100) % 100)))
_add(_entry("amount_is_whole_dollars", "amount", "1 when the amount has no cents.",
            "Whole-dollar amounts are common for cash-like purchases and gift cards.",
            _row(lambda x: (np.round(np.abs(x["amount"]) * 100) % 100 == 0).astype(float))))
_add(_entry("amount_is_multiple_of_100", "amount", "1 when the amount is a multiple of 100 dollars.",
            "Large round amounts are typical of cash withdrawal and of buying stored value.",
            _row(lambda x: ((np.round(np.abs(x["amount"]) * 100) % 10_000 == 0) & (x["amount"] > 0)).astype(float))))
_add(_entry("amount_is_small", "amount", f"1 when the amount is under {SMALL_AMOUNT:g} dollars.",
            "Very small purchases are used to check that a stolen card works.",
            _row(lambda x: (x["amount"] < SMALL_AMOUNT).astype(float))))
_add(_entry("amount_mean_30d", "amount", "Mean amount of the account's earlier transactions in 30 days.",
            "The account's usual amount is the yardstick for the current one.", _agg("mean", "amount", D30)))
_add(_entry("amount_max_30d", "amount", "Largest amount of the account's earlier transactions in 30 days.",
            "An amount above anything the account spent recently is unusual for it.", _agg("max", "amount", D30)))
_add(_entry("amount_over_mean_30d", "amount", "The amount over the account's 30-day mean amount.",
            "A ratio to the account's own mean compares the account with itself.",
            _derived(lambda c: _ratio(c["_amount"], c["amount_mean_30d"]), ["amount_mean_30d"])))
_add(_entry("amount_over_max_30d", "amount", "The amount over the account's 30-day largest amount.",
            "Above 1 means the largest purchase in a month.",
            _derived(lambda c: _ratio(c["_amount"], c["amount_max_30d"]), ["amount_max_30d"])))
_add(_entry("amount_squared_mean_30d", "amount", "Mean of the squared amount over 30 days (a helper for the z-score).",
            "Needed to compute the spread of the account's amounts.", _agg("mean", "amount_sq", D30)))
_add(_entry("amount_z_30d", "amount", "How many of the account's own standard deviations the amount is above its 30-day mean.",
            "It scales the surprise of an amount by how variable the account's spending is.",
            _derived(lambda c: _z_score(c["_amount"], c["amount_mean_30d"], c["amount_squared_mean_30d"]),
                     ["amount_mean_30d", "amount_squared_mean_30d"]),
            caution="Missing when the account's earlier amounts are all the same, because the spread is then zero."))
_add(_entry("amount_previous", "amount", "The amount of the account's previous transaction.",
            "Lets a model see steps in the sequence of amounts.", {"op": "last", "value": "amount"}))
_add(_entry("amount_same_as_previous", "amount", "1 when the amount equals the previous transaction's amount.",
            "Repeating the same amount is a pattern of scripted purchases.",
            _derived(lambda c: np.where(np.isnan(c["amount_previous"]), np.nan, (c["_amount"] == c["amount_previous"]).astype(float)),
                     ["amount_previous"])))
_add(_entry("amount_above_previous", "amount", "1 when the amount is larger than the previous transaction's amount.",
            "A small test purchase followed by larger ones is a classic run.",
            _derived(lambda c: np.where(np.isnan(c["amount_previous"]), np.nan, (c["_amount"] > c["amount_previous"]).astype(float)),
                     ["amount_previous"])))
_add(_entry("n_small_amounts_1h", "amount", "Earlier small-amount transactions in the last hour.",
            "Several small purchases shortly before a large one suggest card testing.", _count(H1, "small_amount")))
_add(_entry("n_same_amount_30d", "amount", "Earlier transactions with exactly this amount in 30 days.",
            "A recurring charge repeats its amount; a count of earlier matches marks it as habitual.",
            _count(D30, same="amount_cents")))

# ---- balance and limits ----------------------------------------------------------------------
_add(_entry("amount_over_balance", "balance_and_limits", "The amount over the available balance before the transaction.",
            "A purchase that takes most of the balance is how an account is emptied.",
            _row(lambda x: _ratio(x["amount"], x["balance"])), needs=["BALANCE_COL"]))
_add(_entry("amount_over_merchandise_limit", "balance_and_limits", "The amount over the remaining daily purchase limit.",
            "Fraud tends to run up against the daily limit.", _row(lambda x: _ratio(x["amount"], x["merch_limit"])),
            needs=["MERCH_LIMIT_COL"]))
_add(_entry("amount_over_cash_limit", "balance_and_limits", "The amount over the remaining daily cash limit.",
            "The same, for cash withdrawals.", _row(lambda x: _ratio(x["amount"], x["cash_limit"])), needs=["CASH_LIMIT_COL"]))
_add(_entry("spent_24h_over_balance", "balance_and_limits", "Dollars moved in the last 24 hours plus this amount, over the balance.",
            "It measures a drain that is spread over several transactions.",
            _derived(lambda c: _ratio(c["amount_sum_24h"] + c["_amount"], c["_balance"]), ["amount_sum_24h"]),
            needs=["BALANCE_COL"]))
_add(_entry("balance_previous", "balance_and_limits", "The available balance on the account's previous transaction.",
            "A helper for the change in balance.", {"op": "last", "value": "balance"}, needs=["BALANCE_COL"]))
_add(_entry("balance_change", "balance_and_limits", "The available balance now minus the balance on the previous transaction.",
            "A sharp fall between two transactions shows money leaving through another channel.",
            _derived(lambda c: c["_balance"] - c["balance_previous"], ["balance_previous"]), needs=["BALANCE_COL"]))
_add(_entry("n_funds_declines_7d", "balance_and_limits", "Earlier declines for insufficient funds in 7 days.",
            "Repeated attempts beyond the balance show someone probing for what is left.", _count(D7, "funds_decline")))

# ---- time: when the account is being used ----------------------------------------------------
_add(_entry("is_weekend", "time", "1 on Saturday and Sunday.", "Spending habits differ at the weekend.",
            _row(lambda x: (x["weekday"] >= 5).astype(float))))
_add(_entry("is_night", "time", "1 between midnight and 5 in the morning (by the timestamp's own clock).",
            "Night-time use is unusual for most accounts.", _row(lambda x: (x["hour"] < 5).astype(float)),
            caution="The meaning depends on whether the timestamp is in local time."))
_add(_entry("n_rows_same_hour_block_30d", "time", "Earlier transactions in 30 days that fell in the same 4-hour block of the day.",
            "A helper for the share below.", _count(D30, same="hour_block")))
_add(_entry("hour_block_share_30d", "time", "Share of the account's 30-day transactions in the same 4-hour block of the day.",
            "A transaction at a time of day the account never uses is unusual for it.",
            _derived(lambda c: _ratio(c["n_rows_same_hour_block_30d"], c["n_rows_30d"]), ["n_rows_same_hour_block_30d", "n_rows_30d"])))
_add(_entry("n_rows_same_weekday_30d", "time", "Earlier transactions in 30 days on the same day of the week.",
            "A helper for the share below.", _count(D30, same="weekday")))
_add(_entry("weekday_share_30d", "time", "Share of the account's 30-day transactions on the same day of the week.",
            "The weekly rhythm of an account is part of its habits.",
            _derived(lambda c: _ratio(c["n_rows_same_weekday_30d"], c["n_rows_30d"]), ["n_rows_same_weekday_30d", "n_rows_30d"])))
_add(_entry("days_in_file", "time", "Days since the account's first transaction in the files read (or since "
            "its first one after the look-back start, when a look-back start is given).",
            "It says how much history the other features could see, so a model can discount features on thin history.",
            {"op": "since_first", "where": None, "same": None, "window": None, "unit": 86_400.0, "log": False}))

# ---- merchant and place: has the account done exactly this before ----------------------------
for _key, _col in (("merchant", "MERCHANT_COL"), ("category", "MCC_COL"), ("country", "MERCHANT_COUNTRY_COL"),
                   ("state", "MERCHANT_STATE_COL"), ("postal", "MERCHANT_POSTAL_COL")):
    _add(_entry(f"{_key}_n_30d", "merchant_and_place", f"Earlier transactions of the account at the same {_key} in 30 days.",
                "Attention over a short window cannot count exact repeats over weeks; this column can.",
                _count(D30, same=_col), needs=[_col]))
    _add(_entry(f"{_key}_seen_30d", "merchant_and_place", f"1 when the account used the same {_key} in the last 30 days.",
                "A first use is the most common trait of a fraud transaction; a repeat is the most common trait of a normal one.",
                _derived(lambda c, k=_key: (c[f"{k}_n_30d"] > 0).astype(float), [f"{_key}_n_30d"]), needs=[_col]))
    _add(_entry(f"{_key}_seconds_since_last_log", "merchant_and_place", f"Log of seconds since the account last used the same {_key}.",
                "A repeat within minutes at a new place belongs to a run; a repeat after weeks is a habit.",
                _since("since_last", same=_col), needs=[_col]))
_add(_entry("merchant_age_log", "merchant_and_place", "Log of seconds since the account first used this merchant (within the files read).",
            "The age of the relationship separates a habitual merchant from one first seen ten minutes ago.",
            _since("since_first", same="MERCHANT_COL"), needs=["MERCHANT_COL"],
            caution="Limited by how far back the files go; use the same look-back in training and scoring."))
_add(_entry("category_share_30d", "merchant_and_place", "Share of the account's 30-day transactions in this merchant category.",
            "A graded version of 'seen before' for categories.",
            _derived(lambda c: _ratio(c["category_n_30d"], c["n_rows_30d"]), ["category_n_30d", "n_rows_30d"]), needs=["MCC_COL"]))
for _key, _col, _label, _w in (("merchants", "MERCHANT_COL", "24h", D1), ("merchants", "MERCHANT_COL", "7d", D7),
                               ("categories", "MCC_COL", "7d", D7), ("countries", "MERCHANT_COUNTRY_COL", "7d", D7),
                               ("states", "MERCHANT_STATE_COL", "24h", D1)):
    _add(_entry(f"n_distinct_{_key}_{_label}", "merchant_and_place", f"Number of different {_key} the account used in the last {_label}.",
                "Many different places in a short time is the shape of a shopping spree on a stolen card.",
                {"op": "distinct", "of": _col, "window": _w}, needs=[_col]))
_add(_entry("n_new_merchants_24h", "merchant_and_place", "Earlier transactions in 24 hours that were the account's first at their merchant.",
            "One new merchant is ordinary; several new merchants in a row is not.", _count(D1, "merchant_first_use"),
            needs=["MERCHANT_COL"]))
_add(_entry("n_new_merchants_1h", "merchant_and_place", "The same count over the last hour.",
            "The short window catches a run while it is happening.", _count(H1, "merchant_first_use"), needs=["MERCHANT_COL"]))
for _key, _col in (("country", "MERCHANT_COUNTRY_COL"), ("state", "MERCHANT_STATE_COL")):
    _add(_entry(f"{_key}_changed", "merchant_and_place", f"1 when the merchant {_key} differs from the previous transaction's.",
                "A jump between places from one transaction to the next can be physically impossible.",
                {"op": "changed", "of": _col}, needs=[_col]))
_add(_entry("exact_match_full_set", "merchant_and_place", "The full set of exact-match columns for every available key, with a "
            "look-back that starts at a calendar boundary, novelty counts and recurring-charge matches.",
            "The entries above are the short list; the full builder covers more keys and windows.",
            status="built in additions/features/exact_match.py"))

# ---- channel and verification ----------------------------------------------------------------
_add(_entry("card_presence_changed", "channel_and_verification", "1 when card-present differs from the previous transaction.",
            "A card that was always swiped and is suddenly used online has probably been copied.",
            {"op": "changed", "of": "CARD_PRESENT_COL"}, needs=["CARD_PRESENT_COL"]))
_add(_entry("n_card_not_present_24h", "channel_and_verification", "Earlier card-not-present transactions in 24 hours.",
            "Online bursts are the main form of fraud on stolen card numbers.", _count(D1, "card_not_present"),
            needs=["CARD_PRESENT_COL"]))
_add(_entry("n_card_not_present_30d", "channel_and_verification", "Earlier card-not-present transactions in 30 days.",
            "A helper for the share below.", _count(D30, "card_not_present"), needs=["CARD_PRESENT_COL"]))
_add(_entry("card_not_present_share_30d", "channel_and_verification", "Share of the account's 30-day transactions with the card not present.",
            "It tells whether online use is normal for this account.",
            _derived(lambda c: _ratio(c["n_card_not_present_30d"], c["n_rows_30d"]), ["n_card_not_present_30d", "n_rows_30d"]),
            needs=["CARD_PRESENT_COL"]))
_add(_entry("type_n_30d", "channel_and_verification", "Earlier transactions of the same transaction type in 30 days.",
            "A type the account never uses (for example a cash advance) is unusual for it.", _count(D30, same="TYPE_COL"),
            needs=["TYPE_COL"]))
_add(_entry("segment_changed", "channel_and_verification", "1 when the segment differs from the previous transaction's.",
            "A change of channel between consecutive transactions marks a change in how the card is used.",
            {"op": "changed", "of": "SEGMENT_COL"}, needs=["SEGMENT_COL"]))
_add(_entry("n_zero_checks_24h", "channel_and_verification", "Earlier zero-dollar checks in 24 hours.",
            "A zero-dollar check verifies a card without buying anything; several in a day look like card testing.",
            _count(D1, "zero_check")))
for _name, _what in (("pin_check_failed_flag", "PIN"), ("cvv_check_failed_flag", "card code"), ("address_check_failed_flag", "address")):
    _add(_entry(f"n_{_name.replace('_flag', '')}_24h", "channel_and_verification",
                f"Earlier transactions in 24 hours whose {_what} check failed.",
                "Failed checks on earlier attempts show someone guessing.", {"op": "count_optional", "column": _name, "window": D1},
                status="needs a column", needs=[f"OPTIONAL_COLUMNS['{_name}']"]))

# ---- outcomes: what the bank decided on EARLIER transactions ---------------------------------
for _label, _w in (("1h", H1), ("24h", D1), ("7d", D7)):
    _add(_entry(f"n_declines_{_label}", "outcomes", f"Earlier declined transactions of the account in the last {_label}.",
                "Declines are known the moment they happen, long before any fraud report. Inside a run they are "
                "the earliest sign that something is wrong.", _count(_w, "declined")))
for _label, _w in (("24h", D1), ("7d", D7)):
    _add(_entry(f"n_risk_declines_{_label}", "outcomes", f"Earlier declines for risk in the last {_label}.",
                "A decline by the bank's own fraud checks is the strongest prior warning short of a report.",
                _count(_w, "risk_decline"),
                caution="Depends on which response codes mean a risk decline; see settings.RISK_DECLINE_REASONS."))
_add(_entry("decline_share_24h", "outcomes", "Share of the account's earlier transactions in 24 hours that were declined.",
            "A share separates one mistyped PIN from an account that is mostly being refused.",
            _derived(lambda c: _ratio(c["n_declines_24h"], c["n_rows_24h"]), ["n_declines_24h", "n_rows_24h"])))
_add(_entry("seconds_since_decline_log", "outcomes", "Log of seconds since the account's last declined transaction.",
            "An approval minutes after a decline is the shape of a retry that got through.", _since("since_last", "declined")))
_add(_entry("seconds_since_risk_decline_log", "outcomes", "Log of seconds since the account's last decline for risk.",
            "The same, for the bank's fraud checks.", _since("since_last", "risk_decline")))
_add(_entry("previous_was_declined", "outcomes", "1 when the account's previous transaction was declined.",
            "The simplest form of 'a retry after a decline'.", {"op": "last", "value": "declined_flag"}))
_add(_entry("merchant_n_declines_24h", "outcomes", "Earlier declined transactions of the account at this merchant in 24 hours.",
            "Declines at the merchant now being charged mean more than declines somewhere else.",
            _count(D1, "declined", same="MERCHANT_COL"), needs=["MERCHANT_COL"]))
_add(_entry("outcome_history_full_set", "outcomes", "The full set: counts by kind of decline, declines at the same merchant, "
            "category and country, and 'first approval at this place after declines'.",
            "The entries above are the short list.", status="built in additions/features/outcome_history.py"))

# ---- network score: how the risk score has moved on this account -----------------------------
_add(_entry("score_max_24h", "network_score", "Highest network risk score on the account's earlier transactions in 24 hours.",
            "A high score on an earlier transaction says the account may already be compromised, which the score "
            "of the current transaction alone does not show.", _agg("max", "score", D1), needs=["VISA_SCORE_COL"]))
_add(_entry("score_mean_7d", "network_score", "Mean network risk score on the account's earlier transactions in 7 days.",
            "The account's usual level of score.", _agg("mean", "score", D7), needs=["VISA_SCORE_COL"]))
_add(_entry("score_mean_30d", "network_score", "Mean network risk score over 30 days.", "A longer baseline.",
            _agg("mean", "score", D30), needs=["VISA_SCORE_COL"]))
_add(_entry("score_minus_mean_30d", "network_score", "The current score minus the account's 30-day mean score.",
            "Some accounts always score high; the difference shows a rise for this account.",
            _derived(lambda c: c["_score"] - c["score_mean_30d"], ["score_mean_30d"]), needs=["VISA_SCORE_COL"]))
_add(_entry("n_high_scores_24h", "network_score", f"Earlier transactions in 24 hours with a score of {HIGH_SCORE:g} or more.",
            "A count of risky-looking earlier transactions.", _count(D1, "high_score"), needs=["VISA_SCORE_COL"]))
_add(_entry("seconds_since_high_score_log", "network_score", "Log of seconds since the account's last high-score transaction.",
            "How long ago the account last looked risky.", _since("since_last", "high_score"), needs=["VISA_SCORE_COL"]))
_add(_entry("score_previous", "network_score", "The network risk score of the previous transaction.",
            "A helper for the change in score.", {"op": "last", "value": "score"}, needs=["VISA_SCORE_COL"]))
_add(_entry("score_change", "network_score", "The current score minus the previous transaction's score.",
            "A jump in score between two transactions.", _derived(lambda c: c["_score"] - c["score_previous"], ["score_previous"]),
            needs=["VISA_SCORE_COL"]))
_add(_entry("score_faded_1h", "network_score", "Sum of earlier scores, each halved for every hour of age.",
            "A memory of recent risk with no window edge: it rises during a run and fades after it.",
            {"op": "decayed", "value": "score", "half_life": float(H1)}, needs=["VISA_SCORE_COL"]))
_add(_entry("score_faded_1d", "network_score", "The same with a one-day half-life.", "A slower memory of the same thing.",
            {"op": "decayed", "value": "score", "half_life": float(D1)}, needs=["VISA_SCORE_COL"]))

# ---- columns the bank already computes (used as they are) ------------------------------------
for _name, _what in (("bank_minutes_since_last_auth", "minutes since the last authorisation, as computed by the bank"),
                     ("bank_pos_count_15m", "the bank's count of point-of-sale transactions in 15 minutes"),
                     ("bank_purchase_count_5m", "the bank's count of purchases in 5 minutes"),
                     ("bank_merchant_cardholder_distance", "the distance between the merchant and the cardholder's home"),
                     ("bank_wallet_risk_score", "the risk score sent by a wallet provider"),
                     ("bank_terminal_other_cards_15m", "other cards seen at the same terminal in 15 minutes")):
    _add(_entry(_name, "bank_computed", f"The column that holds {_what}.",
                "These values are computed on all of the bank's traffic, which no sample of files can reproduce.",
                {"op": "optional", "column": _name}, status="needs a column", needs=[f"OPTIONAL_COLUMNS['{_name}']"],
                caution="Check whether the bank's count includes the current transaction."))

# ---- dates on the account and the card -------------------------------------------------------
for _name, _what in (("date_card_issued", "the card was issued"), ("date_pin_changed", "the PIN was last changed"),
                     ("date_address_changed", "the address was last changed"), ("date_email_changed", "the e-mail was last changed"),
                     ("date_phone_changed", "the phone number was last changed"), ("date_last_login", "the customer last logged in"),
                     ("date_account_opened", "the account was opened")):
    _add(_entry(_name.replace("date_", "days_since_"), "profile_dates", f"Log of days since {_what}; missing when the date is not before the transaction.",
                "A change of contact details shortly before a transaction is a mark of account takeover; a new card or "
                "a new account behaves differently from an old one.", {"op": "days_before", "column": _name},
                status="needs a column", needs=[f"OPTIONAL_COLUMNS['{_name}']"],
                caution="Only a date stamped when the transaction happened is safe. Run asof_audit.py on the column first."))
_add(_entry("days_until_card_expiry", "profile_dates", "Days from the transaction to the card's expiry date.",
            "Cards close to expiry and freshly reissued cards behave differently.", {"op": "days_until", "column": "date_card_expiry"},
            status="needs a column", needs=["OPTIONAL_COLUMNS['date_card_expiry']"]))

# ---- built in other files of this package ----------------------------------------------------
for _name, _family, _what, _file in (
    ("ratios_full_set", "balance_and_limits", "Headroom code, money drained in 24 hours, and the amount's rank among the account's 30-day amounts.", "additions/features/ratios.py"),
    ("surprise_columns", "surprise", "How unlikely each field's value is for this account, from counts.", "additions/features/surprise.py"),
    ("template_and_amount_novelty", "surprise", "Rarity of the combination of code fields, and exact-amount repeats.", "additions/features/novelty_amount.py"),
    ("recurrence_tokens", "merchant_and_place", "Small integer codes on every row that mark repeats of the same merchant, for the network itself.", "additions/features/recurrence_tokens.py"),
    ("travel_speed", "merchant_and_place", "Distance and speed between consecutive merchants.", "additions/features/geo_velocity.py"),
    ("merchant_day_rates", "other_accounts", "What other accounts did at the same merchant over the last days: decline share, mean risk score, volume.", "additions/merchant/day_tables.py"),
    ("merchant_burst_score", "other_accounts", "A burst of attempts at the merchant within the last hours.", "additions/merchant/burst_tables.py"),
    ("merchant_score_view", "other_accounts", "The network risk score averaged over other accounts at the merchant.", "additions/merchant/visa_view.py"),
    ("merchant_heat", "other_accounts", "The model's own scores on other accounts at the merchant.", "additions/merchant/heat.py"),
    ("compromise_exposure", "other_accounts", "Whether the account recently used a place whose other customers later turned bad.", "additions/merchant/exposure.py"),
    ("merchant_affinity", "other_accounts", "How well the merchant fits the account's usual merchants.", "additions/merchant/covisit_vectors.py"),
    ("own_score_state", "model_scores", "The account's risk state from the model's own earlier scores.", "additions/after_model/score_state.py"),
):
    _add(_entry(_name, _family, _what, "See the file for the reasoning.", status=f"built in {_file}"))

# A recipe that plainly reads the amount names the amount column among its needs, so that the
# listing shows it. (The builder leaves a feature out whenever it reads something the table
# lacks, whether or not the entry says so.)
for _e in CATALOGUE:
    _h = _e["how"] or {}
    _reads_amount = (_h.get("value") in ("amount", "amount_sq") or _h.get("same") == "amount_cents"
                     or _h.get("where") == "small_amount")
    if _reads_amount and "AMOUNT_COL" not in _e["needs"]:
        _e["needs"] = _e["needs"] + ("AMOUNT_COL",)


# ----------------------------------------------------------------------------------------------
# The builder
# ----------------------------------------------------------------------------------------------

def _column(df, name):
    """A raw column by its settings attribute (for example 'MERCHANT_COL'), or None when the
    setting is None or the table does not hold the column."""
    col = getattr(settings, name, None)
    return df[col].to_numpy() if col is not None and col in df.columns else None


def _numeric(df, name):
    col = _column(df, name)
    return None if col is None else pd.to_numeric(pd.Series(col), errors="coerce").to_numpy(dtype=np.float64)


class _Absent(Exception):
    """Raised when a recipe asks for a value or a row mask that the table cannot supply."""


class _Available(dict):
    """A dict of arrays in which None stands for "the table has no column for this".

    Reading such an entry with [] raises _Absent, and the feature that asked for it is left out
    of the result. So a feature is never built from made-up values. `get` still returns None,
    for the callers that test for it themselves.
    """

    def __getitem__(self, name):
        value = dict.__getitem__(self, name)
        if value is None:
            raise _Absent(name)
        return value


class _Context:
    """Everything a recipe may need, computed once: times, row masks, value arrays and the
    history engines (one per key the recipes match on)."""

    def __init__(self, df, lookback_start=None):
        self.df = df
        self.n = len(df)
        self.secs = timekeys.seconds(df[settings.TIME_COL])
        self.account = timekeys.codes(df[settings.ACCOUNT_COL].to_numpy())
        # The clock of the history engines. A row without an account cannot be placed in any history,
        # so it gets the missing-time marker there: rows with no account never see each other.
        self.clock = np.where(pd.notna(df[settings.ACCOUNT_COL]).to_numpy(), self.secs, MISSING_SECOND)
        self.start = lookback_start
        stamps = pd.to_datetime(pd.Series(self.secs.astype("float64")).where(self.secs != MISSING_SECOND), unit="s")
        hour = stamps.dt.hour.to_numpy(dtype=np.float64)
        weekday = stamps.dt.dayofweek.to_numpy(dtype=np.float64)
        # A value the table has no column for is kept as None. A recipe that asks for it is left
        # out of the result (see _Available), so no feature is built from made-up zeros.
        amount = _numeric(df, "AMOUNT_COL")
        score = _numeric(df, "VISA_SCORE_COL")
        self.values = _Available({
            "amount": amount, "amount_sq": None if amount is None else amount ** 2, "hour": hour, "weekday": weekday,
            "score": score, "balance": _numeric(df, "BALANCE_COL"),
            "merch_limit": _numeric(df, "MERCH_LIMIT_COL"), "cash_limit": _numeric(df, "CASH_LIMIT_COL"),
        })
        # What the bank decided on each row, sorted into families by the rules of outcome_history.py,
        # so that "declined" means the same in both files: a row with no response code and no decline
        # flag is unknown, and an advice row is not a decline. The result is None when the table has
        # neither decision column. These masks are only ever applied to EARLIER rows.
        family = outcome_history.outcome_family(df)
        declines = (outcome_history.FUNDS_DECLINE, outcome_history.RISK_DECLINE, outcome_history.OTHER_DECLINE)
        declined = None if family is None else np.isin(family, declines)
        kind = _column(df, "TYPE_COL")
        present = _column(df, "CARD_PRESENT_COL")
        self.masks = _Available({
            "approved": None if family is None else family == outcome_history.APPROVED,
            "declined": declined,
            "risk_decline": None if family is None else family == outcome_history.RISK_DECLINE,
            "funds_decline": None if family is None else family == outcome_history.FUNDS_DECLINE,
            "zero_check": None if kind is None else np.isin(pd.Series(kind).astype(str).to_numpy(), settings.ZERO_CHECK_TYPES),
            "card_not_present": (None if present is None
                                 else np.isin(pd.Series(present).astype(str).to_numpy(), CARD_NOT_PRESENT_VALUES)),
            "small_amount": None if amount is None else amount < SMALL_AMOUNT,
            "high_score": None if score is None else score >= HIGH_SCORE,
        })
        self.values["declined_flag"] = None if declined is None else declined.astype(np.float64)
        self._engines = {}

    def key(self, same):
        """(values, present) of the column a recipe matches on. Besides raw columns, three
        derived keys exist: the amount in cents, the 4-hour block of the day and the weekday."""
        if same == "amount_cents":
            v = np.round(self.values["amount"] * 100)
            return v, np.isfinite(v)
        if same == "hour_block":
            v = np.floor(self.values["hour"] / 4.0)
            return v, np.isfinite(v)
        if same == "weekday":
            v = self.values["weekday"]
            return v, np.isfinite(v)
        col = _column(self.df, same)
        if col is None:
            return None, None
        # A missing value or a blank text is no value, as everywhere in this folder: it matches nothing.
        return col, shared.value_codes(col)[0] >= 0

    def engine(self, same=None):
        """The history engine for the account (same=None) or for the account together with
        another column. Rows whose matching value is missing get no time, so they have no
        history and are never part of another row's history: a missing value matches nothing."""
        if same not in self._engines:
            if same is None:
                self._engines[same] = EarlierRows(self.account, self.clock, start=self.start)
            else:
                values, present = self.key(same)
                if values is None:
                    self._engines[same] = None
                else:
                    keys = timekeys.codes(self.account, pd.Series(values).astype(str).to_numpy())
                    secs = np.where(present, self.clock, MISSING_SECOND)
                    self._engines[same] = EarlierRows(keys, secs, start=self.start)
        return self._engines[same]

    def mask(self, where):
        """A named yes/no array over rows. 'merchant_first_use' is built on demand: the rows
        that were the account's first at their merchant."""
        if where is None:
            return None
        if where == "merchant_first_use" and where not in self.masks:
            eng = self.engine("MERCHANT_COL")
            self.masks[where] = (eng.count() == 0) & self.key("MERCHANT_COL")[1] if eng is not None else np.zeros(self.n, bool)
        return self.masks[where]


def _build_one(entry, ctx, built):
    """Compute one catalogue entry. Returns an array, or None when something it needs is absent."""
    try:
        return _compute(entry, ctx, built)
    except _Absent:
        return None                           # the recipe asked for a value or a mask the table lacks


def _compute(entry, ctx, built):
    """The recipe of one entry. Raises _Absent when it reads a value or a mask the table lacks."""
    # A feature that names a settings column it needs is left out when that column is absent.
    for need in entry["needs"]:
        if need.endswith("_COL") and _column(ctx.df, need) is None:
            return None
    how = entry["how"]
    op = how["op"]
    if op == "row":
        return np.asarray(how["fn"](ctx.values), dtype=np.float64)
    if op == "derived":
        if any(u not in built for u in how["uses"]):
            return None                       # something this feature is computed from was left out
        cols = _Available({u: built[u] for u in how["uses"]})
        # The current row's own amount, score and balance, for recipes that compare with history. One
        # that the table lacks stays None here, and only a recipe that reads it is left out.
        cols["_amount"], cols["_score"], cols["_balance"] = (ctx.values.get("amount"), ctx.values.get("score"),
                                                             ctx.values.get("balance"))
        return np.asarray(how["fn"](cols), dtype=np.float64)
    if op in ("optional", "days_before", "days_until", "count_optional"):
        name = OPTIONAL_COLUMNS.get(how["column"])
        if name is None or name not in ctx.df.columns:
            return None
        raw = ctx.df[name]
        if op == "optional":
            return pd.to_numeric(raw, errors="coerce").to_numpy(dtype=np.float64)
        if op == "count_optional":
            failed = pd.to_numeric(raw, errors="coerce").fillna(0).to_numpy() > 0
            return ctx.engine(None).count(how["window"], failed).astype(np.float64)
        date = timekeys.seconds(raw)
        ok = (date != MISSING_SECOND) & (ctx.secs != MISSING_SECOND)
        days = np.where(ok, (ctx.secs - date) / 86_400.0, np.nan)
        if op == "days_before":
            # Only a date strictly before the transaction is usable; anything else is missing.
            return np.where(days > 0, np.log1p(np.clip(days, 0, None)), np.nan)
        return -days
    same = how.get("same")
    eng = ctx.engine(same)
    if eng is None:
        return None
    where = ctx.mask(how.get("where"))
    window = how.get("window")
    if op == "count":
        return eng.count(window, where).astype(np.float64)
    if op in ("sum", "mean", "max", "min"):
        value = ctx.values.get(how["value"])
        if value is None:
            return None
        method = {"sum": eng.total, "mean": eng.mean, "max": eng.maximum, "min": eng.minimum}[op]
        return method(value, window, where)
    if op in ("since_last", "since_first"):
        secs = (eng.seconds_since_last if op == "since_last" else eng.seconds_since_first)(window, where)
        if how.get("log", True):
            return np.log1p(secs)
        return secs / how.get("unit", 1.0)
    if op == "last":
        value = ctx.values.get(how["value"])
        return None if value is None else eng.last(value).astype(np.float64)
    if op == "decayed":
        value = ctx.values.get(how["value"])
        return None if value is None else eng.decayed_sum(value, how["half_life"])
    if op == "distinct":
        values, present = ctx.key(how["of"])
        if values is None:
            return None
        codes = np.where(present, timekeys.codes(pd.Series(values).astype(str).to_numpy()), -1)
        return ctx.engine(None).distinct(codes, window).astype(np.float64)
    if op == "changed":
        values, present = ctx.key(how["of"])
        if values is None:
            return None
        codes = np.where(present, timekeys.codes(pd.Series(values).astype(str).to_numpy()), -1).astype(np.float64)
        previous = ctx.engine(None).last(codes)
        # Missing when there is no previous row or either value is missing; otherwise 0 or 1.
        return np.where(np.isnan(previous) | (previous < 0) | (codes < 0), np.nan, (previous != codes).astype(np.float64))
    return None


def build_possible_features(df, names=None, families=None, lookback_start=None, quiet=False):
    """Build the catalogue's features that can be computed from the table.

    df              raw rows of whole accounts (every row of each account that is in the files)
    names           feature names to build; None means all
    families        families to build (for example ["velocity", "amount"]); None means all
    lookback_start  earliest second that history may use: a number for all rows, an array for
                    one value per row, or None for no limit
    Returns a DataFrame with one float column per feature built, aligned to df's rows. Features
    that need a column the table lacks are left out; one line lists them unless quiet is set.
    Features used by a requested derived feature are built too, and kept.
    """
    ctx = _Context(df, lookback_start)
    wanted = [e for e in CATALOGUE if e["how"] is not None
              and (names is None or e["name"] in names) and (families is None or e["family"] in families)]
    by_name = {e["name"]: e for e in CATALOGUE}
    built, skipped = {}, []

    def ensure(entry):
        if entry["name"] in built or entry["how"] is None:
            return
        for dep in entry["how"].get("uses", ()):
            if dep in by_name:
                ensure(by_name[dep])
        col = _build_one(entry, ctx, built)
        if col is None:
            skipped.append(entry["name"])
        else:
            built[entry["name"]] = col

    for entry in wanted:
        ensure(entry)
    if skipped and not quiet:
        print("note: left out (a column they need is not available): " + ", ".join(skipped))
    return pd.DataFrame({k: v.astype(np.float32) for k, v in built.items()}, index=df.index)


def list_features(families=None):
    """The catalogue as a DataFrame: name, family, status, what it measures, why, what it needs."""
    rows = [{"name": e["name"], "family": e["family"], "status": e["status"], "what": e["what"], "why": e["why"],
             "needs": ", ".join(e["needs"]), "caution": e["caution"]}
            for e in CATALOGUE if families is None or e["family"] in families]
    return pd.DataFrame(rows)


def main(argv=None):
    """Runs the tool from the command line; `argv` stands in for the command-line arguments when given."""
    ap = argparse.ArgumentParser(description="list or build the catalogue of possible features")
    ap.add_argument("--list", action="store_true", help="print the catalogue")
    ap.add_argument("--build", help="a parquet file of raw rows (whole accounts) to build the features for")
    ap.add_argument("--demo", action="store_true", help="build the features on made-up rows instead of a file")
    ap.add_argument("--families", nargs="+", default=None, help="only these families")
    ap.add_argument("--out", help="where to write the feature columns (parquet); the id column is kept beside them")
    a = ap.parse_args(argv)
    if a.list or not (a.build or a.demo):
        table = list_features(a.families)
        with pd.option_context("display.max_rows", None, "display.max_colwidth", 90, "display.width", 200):
            print(table[["name", "family", "status", "what"]].to_string(index=False))
        print(f"\n{len(table)} entries; {int((table['status'] == 'here').sum())} are built by this file")
    if a.build or a.demo:
        raw = synthetic.make_transactions(n_accounts=200, seed=1) if a.demo else tables.read_columns(a.build)
        cols = build_possible_features(raw, families=a.families)
        print(cols.describe().T[["count", "mean", "min", "max"]].to_string())
        if a.out:
            if settings.ID_COL in raw.columns:
                cols.insert(0, settings.ID_COL, raw[settings.ID_COL].to_numpy())
            tables.write_table(cols, a.out)
            print(f"wrote {a.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
