"""Recurrence tokens: small codes that let the network see "the same merchant as before".

What this file does
-------------------
For every identity field that the files hold (merchant id, merchant category, postal code,
state, country, and the optional card, terminal, device, token and IP columns) and for
EVERY row, history rows included, it writes seven small integers, all computed from the
account's strictly earlier rows inside the look-back (names carry the prefix `recur_`):

    <field>_local_id     the account's own number for the value: 1 for the first value the account
                         used inside the look-back, 2 for the second, and so on; 64 for the 64th
                         value or later
    <field>_new          1 the value was not used before inside the look-back, 2 it was
    <field>_count        how often it was used before, in buckets: 0, 1, 2, 3, 4-5, 6-9, 10-19, 20-49, 50+
    <field>_count_7      how often among the account's last 7 rows
    <field>_count_30     how often among the account's last 30 rows, in the same buckets
    <field>_rows_since   rows since the last use, in buckets: 1, 2, 3, 4-5, 6-10, 11-20, 21-50, 51+
    <field>_secs_since   seconds since the last use, in buckets from under a minute to over 30 days

Code 0 always means "the row has no value for this field" (or cannot be placed in time);
in the last two columns code 1 means "never used before". `cardinalities()` gives the
size of the embedding table each code needs.

Why it exists
-------------
A merchant id has far too many values for an embedding table with one row per merchant:
most merchants occur a handful of times, so most rows of such a table would never be
trained, and a merchant that first appears after training would have no row at all. Yet
what a fraud model needs from the merchant id is rarely who the merchant is. It is whether
this account has been there before, how often and how recently.

The local id answers that without any table over merchants. Each account's values are
renamed 1, 2, 3 in the order the account first used them. The same merchant then carries
the same small number on every row of the account, so the network can compare the token of
the scored row with the tokens of the history rows: equal numbers mean equal merchants.
That is exact matching, learned by attention over at most 65 embedding rows however many
merchants exist. Because every row carries the codes, stage 2 can also see patterns among
the history rows themselves, such as three never-used merchants in a row, which columns on
the scored row alone cannot express. Nothing about the merchant leaves the account: the
codes are the same if every merchant id is replaced by another.

The codes must be computed with the same look-back in training and in scoring. A local id
is a number relative to where the numbering starts, and the counts depend on how far back
they reach. If training numbered an account's merchants over many months and scoring over
the one to two months the evaluation files hold, the same merchant would carry different
numbers, "new" would mean two different things, and the high numbers would be common in
training and absent in scoring. The calendar look-back of lookback.py is used here for that
reason: the rows of a month are numbered from the first day of the month before, in every
file. The block-by-block computation makes it exact: the codes of a month are computed on
the table cut at that day, which is what an evaluation file is.

Where it goes
-------------
Raw files, then these codes, then the tokenizer. The codes are categorical inputs: in the
original code they would be appended to the categorical matrix in
`SequenceBuilder._encode_file`, and `FeatureTokenizer` would get their table sizes in
`categorical_cardinality`. Seven tokens per field make stage 1 slow, so the usual form is
one extra token per identity field: embed the seven codes in small tables, add them up and
project the sum to the token width. Start with the two to four fields whose exact-match
columns help most.

One point needs care in the sequence builder. All rows of a calendar month are numbered
from the same day, so inside a month equal ids mean equal values. A row of the month before
was numbered from a day one month earlier, so its ids do not line up with this month's. A
second call with `months_back=0` numbers every row from the first day of its own month,
which is the day the following month's rows are numbered from. A sequence for a target in
month M therefore takes the default codes for its rows of month M and the `months_back=0`
codes for its rows of month M-1 (lookback.month_blocks lists these blocks). In evaluation
files (a history month, then the scored month) both calls give the history month the same
codes, because the files begin on that first day, so one default call is enough for scoring.

What to change for the pod
--------------------------
The identity columns in settings.py (`MERCHANT_COL`, `MCC_COL`, `MERCHANT_POSTAL_COL`,
`MERCHANT_STATE_COL`, `MERCHANT_COUNTRY_COL` and the optional `CARD_COL`, `TERMINAL_COL`,
`DEVICE_COL`, `TOKEN_COL`, `IP_COL`), or pass `fields={"short name": "column"}`.
`LOCAL_ID_CAP` (63) is the number of distinct values per account and look-back that get
their own id; raise it if many accounts use more merchants than that in two months. The
bucket edges below can be changed freely; call `cardinalities()` afterwards for the new
table sizes. `months_back` must be the same number in training and in scoring.

How to try it
-------------
    python additions/features/recurrence_tokens.py --demo
    python additions/features/recurrence_tokens.py --base /path/to/files --files 8217 8218 --out tokens.parquet

    codes = build_recurrence_tokens(df)                      # df: whole files; small integers [rows, 7 per field]
    sizes = cardinalities()                                  # {"local_id": 65, "new": 3, ...}
    python -m pytest -q additions/tests/test_features_recurrence_tokens.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np

from additions import settings
from additions.common.history import EarlierRows
from additions.features import _shared

# Distinct values per account and look-back that get an id of their own; the next id means "more".
LOCAL_ID_CAP = 63

# Bucket edges. A value falls into the bucket numbered by how many edges are at or below it.
COUNT_EDGES = (1, 2, 3, 4, 6, 10, 20, 50)                   # buckets 0, 1, 2, 3, 4-5, 6-9, 10-19, 20-49, 50+
ROWS_SINCE_EDGES = (2, 3, 4, 6, 11, 21, 51)                 # buckets 1, 2, 3, 4-5, 6-10, 11-20, 21-50, 51+
SECS_SINCE_EDGES = (60, 600, 3_600, 21_600, 86_400, 259_200, 604_800, 1_209_600, 2_592_000)

# The two short scales, in rows of the account.
SHORT_ROWS = 7
LONG_ROWS = 30

# The seven codes of a field, in the order of the output columns (each is named <prefix><field>_<code>).
CODE_NAMES = ("local_id", "new", "count", "count_7", "count_30", "rows_since", "secs_since")


def needed_columns():
    """The raw columns this builder reads (None entries are optional columns that are switched off)."""
    return [settings.ACCOUNT_COL, settings.TIME_COL, settings.ID_COL, *_shared.default_keys().values()]


def cardinalities():
    """The number of values each code can take, as {code name: size of its embedding table}."""
    return {
        "local_id": LOCAL_ID_CAP + 2,                        # 0 no value, 1..cap, cap + 1 for "more"
        "new": 3,                                            # 0 no value, 1 new, 2 used before
        "count": len(COUNT_EDGES) + 2,
        "count_7": SHORT_ROWS + 2,                           # 0 no value, then 0 to 7 uses
        "count_30": len(COUNT_EDGES) + 2,
        "rows_since": len(ROWS_SINCE_EDGES) + 3,             # 0 no value, 1 never, then the buckets
        "secs_since": len(SECS_SINCE_EDGES) + 3,
    }


def _bucket(values, edges):
    """The bucket number of each value: how many edges are at or below it."""
    return np.searchsorted(np.asarray(edges, dtype=np.float64), values, side="right")


def _codes_of_block(by_account, position, account, secs, codes):
    """The seven codes of one identity field for the rows of one block: {code name: int [rows of the block]}.

    by_account   the history engine of the account inside the block
    position     for every row, the number of strictly earlier rows of its account in the block
    codes        one integer per distinct value of the field, -1 where the row has no value
    """
    has = codes >= 0
    # The history engine does not care what its clock counts. Here the clock is the row's position in the
    # account instead of the second, so a "window" of 7 means "among the last 7 rows". Rows of one second
    # share a position, so they still never see each other, exactly as with a clock in seconds.
    at_value = _shared.key_engine(account, codes, position)
    n_before = at_value.count()
    new = n_before == 0
    rows_since = at_value.seconds_since_last()                  # in rows, because the clock counts rows
    secs_since = secs - at_value.last(secs)                     # the second of the last use, then the gap

    # Local id. A value that is new takes the next free number: one more than the number of different
    # values the account used before. A value that was used before keeps the number it took at its first
    # use, which is read from the row of that first use: same account, at the position of the first use.
    # Two different values first used in the same second get the same number, because neither row could
    # see the other; that is the price of the same-second rule and it is rare.
    distinct_before = by_account.distinct(codes)
    local = distinct_before + 1
    used = has & ~new
    span = int(position.max()) + 1 if len(position) else 1
    slot = account * span + position                            # one number per account and position
    by_slot = np.argsort(slot, kind="stable")
    first_position = (position[used] - at_value.seconds_since_first()[used]).astype(np.int64)
    first_use = by_slot[np.searchsorted(slot[by_slot], account[used] * span + first_position)]
    local[used] = distinct_before[first_use] + 1
    local = np.minimum(local, LOCAL_ID_CAP + 1)

    return {
        "local_id": np.where(has, local, 0),
        "new": np.where(has, np.where(new, 1, 2), 0),
        "count": np.where(has, 1 + _bucket(n_before, COUNT_EDGES), 0),
        "count_7": np.where(has, 1 + np.minimum(at_value.count(SHORT_ROWS), SHORT_ROWS), 0),
        "count_30": np.where(has, 1 + _bucket(at_value.count(LONG_ROWS), COUNT_EDGES), 0),
        "rows_since": np.where(has, np.where(new, 1, 2 + _bucket(rows_since, ROWS_SINCE_EDGES)), 0),
        "secs_since": np.where(has, np.where(new, 1, 2 + _bucket(secs_since, SECS_SINCE_EDGES)), 0),
    }


def build_recurrence_tokens(df, fields=None, account_col=None, time_col=None, months_back=1, prefix="recur_"):
    """Recurrence codes for every row of `df`.

    df           every row of one or more whole files (whole account histories), in any order
    fields       {short name: column name} of the identity fields; None reads them from settings
                 (see _shared.default_keys). A field that is switched off or absent is skipped
                 with one printed line
    account_col, time_col   column names; None reads them from settings
    months_back  where the numbering starts: 1 (the default) is the first day of the month before the
                 row's month, 0 is the first day of the row's own month (the codes a row carries when a
                 row of the following month reads it), None is the start of the table
    prefix       put in front of every column name

    Returns an int16 DataFrame [rows, 7 per field] with the index of `df`. Every value lies
    between 0 and the size given by `cardinalities()` minus one. A row with no time or no
    account gets 0 everywhere.

    Time rule: the codes of a row are computed from rows of the same account in strictly
    earlier seconds, not before the start of the numbering. Rows of the same second never
    see each other. The values of the field are only compared for equality.

    The codes are computed block by block (see _shared.blockwise): the rows of a month on a
    table cut at the day their numbering starts. Within a block every row is numbered from
    the same day, which is what makes ids comparable between the scored row and its history.
    """
    fields = _shared.default_keys() if fields is None else fields
    account, secs = _shared.account_and_time(df, account_col, time_col)
    codes = {name: _shared.value_codes(values, _shared.KEY_TRANSFORMS.get(name))[0]
             for name, values in _shared.columns(df, fields, "recurrence fields").items()}

    def one_block(rows):
        """The codes of the rows of one block, computed as if the block were the whole table."""
        by_account = EarlierRows(account[rows], secs[rows])
        position = by_account.count()
        out = {}
        for name, field_codes in codes.items():
            block = _codes_of_block(by_account, position, account[rows], secs[rows], field_codes[rows])
            out.update({f"{prefix}{name}_{code_name}": values for code_name, values in block.items()})
        return out

    built = _shared.blockwise(secs, months_back, one_block)
    # A row that is in no block (it has no time) keeps the "no value" code 0 in every column.
    filled = {name: np.nan_to_num(values, nan=0.0) for name, values in built.items()}
    return _shared.as_frame(filled, df.index, codes=tuple(filled))


def main(argv=None):
    """Command line: build the codes for some files (or for made-up rows) and print a summary."""
    return _shared.run_builder(
        argv, "Recurrence codes per identity field, ready for small embedding tables.", needed_columns(),
        build=lambda df, args: build_recurrence_tokens(df))


if __name__ == "__main__":
    main()
