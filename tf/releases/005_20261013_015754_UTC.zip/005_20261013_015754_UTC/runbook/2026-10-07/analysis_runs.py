#!/usr/bin/env python3
# Written by reviewer (2026-10-12), V1 stage 5 (bridge/plans/review/2026-10-12-v1-design/DESIGN_V1_AFTER_RUN001.md on main:
# section 3, the analysis plan; section 4 rows B12 and B13). Read-only on the ledger and attempt folders it inspects.
# It writes paths, statuses and names only: no prediction row, identifier or score.
"""Build paired_report.py's run table from the run ledger (stage 5, analysis.sh).

    python3 runbook/2026-10-07/analysis_runs.py --ledger runs/run_log.csv --out <folder>

For each of the 15 V1 runs (V1_RUNS: its spec's output folder and run name) it takes the latest ledger revision of
every attempt of that run, keeps those with status ok, and uses the newest (finished_utc). Its evaluation predictions
are the ledger row's predictions_path (the runner scored 8000 to 8010), else the newest post-score folder
<attempt>/<run>/post_score/<id>/ whose post_score_manifest.json says status ok, no evaluation range override and the
ledger row's checkpoint (batch 2 step 2.0). V1 has no validation
scoring, so validation_path stays empty and each run's best validation AP (valid_ap, from its results.csv through the
ledger) gives paired_report.py the validation sign. A run with no ok attempt or no evaluation predictions is named with
the reason, and the contrasts that need it are left out of the run table.

Writes into --out: run_table.csv (paired_report.py --runs), paired_args.txt (its other arguments, one per line) and
RUNS.txt (which attempt fed each run, then the contrasts left out and why).
"""
import argparse
import csv
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

# The 15 V1 runs (owner, OWNER_QA thirty-first message: seed 42 only): name, the spec's output_root, the runner's run
# name (run_ablations._expand_runs: "<axis>-<option>"; YAML reads the option key "off" as False, so the gap-off runs
# are "time_delta-False"), spec file. tests/test_analysis_stage.py checks them against the spec files.
V1_RUNS = [
    ("A-H00", "ablations/arch_a_flat/history_h0_vs_h5", "history-h0", "YOUR_PACKAGE/phase4a/configs/ft_decisions_h0.yaml"),
    ("A-H05", "ablations/arch_a_flat/history_h0_vs_h5", "history-h5", "YOUR_PACKAGE/phase4a/configs/ft_decisions_h0.yaml"),
    ("B-H05", "ablations/arch_b_hier/history_h5_h10", "history-h5", "YOUR_PACKAGE/phase4b/configs/ft_decisions_hier.yaml"),
    ("B-H10", "ablations/arch_b_hier/history_h5_h10", "history-h10", "YOUR_PACKAGE/phase4b/configs/ft_decisions_hier.yaml"),
    ("A-H10", "ablations/arch_a_flat/history_h10", "history-h10", "YOUR_PACKAGE/phase4a/configs/ft_decisions_flat_h10.yaml"),
    ("A-GAP10-OFF", "ablations/arch_a_flat/time_delta_on_vs_off_h10", "time_delta-False",
     "YOUR_PACKAGE/phase4a/configs/ft_decisions_timedelta.yaml"),
    ("REF-SINGLE", "ablations/ref_single/ref_single_seeds", "seed-s42", "YOUR_PACKAGE/base/configs/ref_single.yaml"),
    ("B-H00", "ablations/arch_b_hier/history_h0_scored", "history-h0",
     "YOUR_PACKAGE/phase4b/configs/ft_decisions_hier_h0_scored.yaml"),
    ("A-MASK05-C", "ablations/arch_a_flat/mask_causal_h5", "mask-causal",
     "YOUR_PACKAGE/phase4a/configs/ft_decisions_mask_causal.yaml"),
    ("A-GAP05-OFF", "ablations/arch_a_flat/time_delta_off_h5", "time_delta-False",
     "YOUR_PACKAGE/phase4a/configs/ft_decisions_gap05_off.yaml"),
    ("A-H15", "ablations/arch_a_flat/history_h15", "history-h15", "YOUR_PACKAGE/phase4a/configs/ft_decisions_flat_h15.yaml"),
    ("B-H15", "ablations/arch_b_hier/history_h15_h20", "history-h15", "YOUR_PACKAGE/phase4b/configs/ft_decisions_hier_long.yaml"),
    ("B-H20", "ablations/arch_b_hier/history_h15_h20", "history-h20", "YOUR_PACKAGE/phase4b/configs/ft_decisions_hier_long.yaml"),
    ("A-H20", "ablations/arch_a_flat/history_h20", "history-h20", "YOUR_PACKAGE/phase4a/configs/ft_decisions_flat_h20.yaml"),
    ("B-ALLPOS-H5", "ablations/arch_b_hier/allposition_strict_h5", "history-h5",
     "YOUR_PACKAGE/phase4b/configs/ft_decisions_hier_allpos.yaml"),
]


def qualify(path):
    """Every V1 scorer records predictions_path as S3 bucket/key with the scheme stripped (strip_scheme in
    score_sequential.py and score_streaming.py: A and B one file, REF-SINGLE a folder of per-file parquet, post-hoc
    scores included). paired_report.py reads a bare path as local, so the s3:// goes back on."""
    path = str(path or "").strip()
    return f"s3://{path}" if path else ""


def in_output_root(attempt_dir, output_root):
    """Is the attempt folder <...>/<output_root>/<attempt>? (the sandbox puts a prefix before output_root)."""
    parent = os.path.normpath(attempt_dir).split(os.sep)[:-1]
    root = os.path.normpath(output_root).split(os.sep)
    return parent[-len(root):] == root


def post_scored(row):
    """(post-score id, predictions path) of the newest ok post-score of this checkpoint, or None."""
    root = os.path.join(row["attempt_dir"], row["run_name"], "post_score")
    for name in sorted(os.listdir(root), reverse=True) if os.path.isdir(root) else []:
        try:
            with open(os.path.join(root, name, "post_score_manifest.json"), encoding="utf-8") as f:
                man = json.load(f)
        except (OSError, ValueError):
            continue
        path = qualify((man.get("metrics") or {}).get("predictions_path"))
        if (man.get("status") == "ok" and path and man.get("eval_range_override") is None and man.get("checkpoint_sha256") == row["checkpoint_sha256"]):
            return name, path
    return None


def find_runs(ledger):
    """{run: record} for the 15 V1 runs; a record has status "found" or the reason it is not."""
    sys.path.insert(0, HERE)
    from collect_returns import current_rows
    rows = list(current_rows(ledger).values())
    found = {}
    for name, output_root, run_name, _ in V1_RUNS:
        mine = [r for r in rows if r["run_name"] == run_name and in_output_root(r["attempt_dir"], output_root)]
        ok = [r for r in mine if r["status"] == "ok"]
        if not ok:
            why = ", ".join(sorted(r["status"] for r in mine)) or "no ledger row"
            found[name] = {"status": f"no attempt with status ok ({why})"}
            continue
        row = max(ok, key=lambda r: (r["finished_utc"], r["attempt_dir"]))
        rec = {"status": "found", "attempt_dir": row["attempt_dir"], "seed": row["seed"] or "42",
               "valid_ap": row["valid_ap"], "other_attempts": len(mine) - 1}
        evaluation = post_scored(row)
        if row["predictions_path"]:
            rec.update(evaluation="runner", prediction_path=qualify(row["predictions_path"]))
        elif evaluation:
            rec.update(evaluation=f"post-hoc scoring {evaluation[0]}", prediction_path=evaluation[1])
        else:
            rec["status"] = "no evaluation predictions (no runner scoring, no ok post-hoc scoring of this checkpoint)"
        found[name] = rec
    return found


def build(ledger, contrasts_csv, out):
    with open(contrasts_csv, newline="", encoding="utf-8") as f:
        contrasts = list(csv.DictReader(f))
    runs = find_runs(ledger)
    ok = {n for n, r in runs.items() if r["status"] == "found"}

    def missing(c):
        """The runs (for a difference: the contrasts) a row of v1_contrasts.csv needs and does not have."""
        if c["kind"] == "difference":
            return [s for s in (c["side_a_run"], c["side_b_run"])
                    if missing(next(x for x in contrasts if x["name"] == s))]
        sides = [c["side_a_run"]] + ([c["side_b_run"]] if c["kind"] != "own line" else [])
        return [s for s in sides if s not in ok]

    table, listed, args, left_out = [], set(), [], []
    for c in contrasts:
        gone = missing(c)
        if gone:
            left_out.append(f"  {c['name']}: not available ({', '.join(gone)} not found)")
        elif c["kind"] == "contrast":
            table += [(c["name"], "x", c["side_a_run"]), (c["name"], "y", c["side_b_run"])]
            listed |= {c["side_a_run"], c["side_b_run"]}
        elif c["kind"] == "difference":
            args += ["--difference", c["side_a_run"], c["side_b_run"]]
    depth = [c for c in contrasts if c["kind"] == "depth-matched" and not missing(c)]
    if depth:
        args += ["--depth-matched", depth[0]["side_a_run"] + ":" + ",".join(c["side_b_run"] for c in depth)]
    # A found run in no contrast (all-position B) gets a row of its own: its own line and the depth-matched reading.
    table += [("", "", name) for name, *_ in V1_RUNS if name in ok and name not in listed]

    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "run_table.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["contrast", "side", "run", "seed", "prediction_path", "validation_path", "valid_ap"])
        for contrast, side, run in table:
            r = runs[run]
            w.writerow([contrast, side, run, r["seed"], r["prediction_path"], "", r["valid_ap"]])
    with open(os.path.join(out, "paired_args.txt"), "w", encoding="utf-8") as f:
        f.write("".join(a + "\n" for a in args))
    lines = [f"V1 runs found in {ledger}: {len(ok)} of {len(V1_RUNS)}"]
    for name, *_ in V1_RUNS:
        r = runs[name]
        lines.append(f"  {name}: attempt {r['attempt_dir']}; evaluation from {r['evaluation']}; valid_ap "
                     f"{r['valid_ap'] or 'missing'}; other attempts of this run not used: {r['other_attempts']}"
                     if r["status"] == "found" else f"  {name}: NOT FOUND: {r['status']}")
    lines.append(f"contrasts and readings not available: {len(left_out)}")
    lines += left_out
    with open(os.path.join(out, "RUNS.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\n".join(lines))
    return runs, table, args


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    p.add_argument("--ledger", required=True)
    p.add_argument("--contrasts", default=os.path.join(HERE, "v1_contrasts.csv"))
    p.add_argument("--out", required=True)
    a = p.parse_args()
    build(a.ledger, a.contrasts, a.out)
