#!/usr/bin/env bash
# Stage 5 of the V1 study: the paired analysis on the pod (reviewer, 2026-10-12; design
# bridge/plans/review/2026-10-12-v1-design/DESIGN_V1_AFTER_RUN001.md on main, section 3 and section 4 rows B12 and B13).
# Released only after batch 2 has ended and its return has been read. Run it from the folder batch 2 ran in, in the
# activated Python environment the batches ran in:
#     bash runbook/2026-10-07/analysis.sh                   (PYTHON=<interpreter> to name it; default python3)
#     bash runbook/2026-10-07/analysis.sh --ledger runs/returns/parallel_v1_001_all/run_log_all.csv
# --ledger selects only that study's return ledger; relative paths are from the project root.
# The prediction files stay on the pod (the owner's answer to OQ-24), so the comparison runs here.
# reviewer's test harness only (stops the launch unless RUNBOOK_BANK_OVERRIDES=1 is set; the pre-flight records that):
#     RUNBOOK_SANDBOX=<folder>, PREFLIGHT_ARGS="<pre-flight flags>".
# Order: the quick pre-flight (--skip-tests: batch 1 of the same package ran the repository tests; RESULT PASS
# required; anything else stops before any prediction file is read), then
#   1. analysis_runs.py finds each V1 run's prediction files in runs/run_log.csv and names any run it does not find;
#   2. paired_report.py compares the runs found (runbook/2026-10-07/v1_contrasts.csv) on whole-account draws.
#      CPU only; runtime not measured.
# The return folder runs/returns/analysis_<time>/ exists from the start and holds ANALYSIS_STATUS.txt (one line per
# event), preflight_<time>/ (the complete pre-flight copy), runs/ (RUNS.txt: which attempt fed each run and what is not
# available; run_table.csv; paired_args.txt), report/ (paired_report.txt and its aggregate CSV files) and logs/.
# Aggregates only: no prediction file (*.parquet) and no checkpoint (*.ckpt). Send that folder.
set -uo pipefail
cd "$(dirname "$0")/../.."
HERE=runbook/2026-10-07
PY="${PYTHON:-python3}"

# Inherited harness state: in a bank shell these variables are a mistake unless said otherwise.
if [ "${RUNBOOK_BANK_OVERRIDES:-}" != "1" ]; then
  present=""
  for v in RUNBOOK_SANDBOX PREFLIGHT_ARGS; do [ -n "${!v:-}" ] && present="$present $v"; done
  if [ -n "$present" ]; then
    echo "STOPPED BEFORE START: set in this shell:$present. These belong to reviewer's test harness, not to a bank run."
    echo "Unset them and start again. Only on review advice, set RUNBOOK_BANK_OVERRIDES=1 to keep them;"
    echo "the pre-flight records that as an override. Nothing was run."
    exit 1
  fi
fi
SB="${RUNBOOK_SANDBOX:-}"
PF=runs/preflight; LEDGER=runs/run_log.csv; RET=runs/returns
[ -n "$SB" ] && { PF="$SB/preflight"; LEDGER="$SB/runs/run_log.csv"; RET="$SB/returns"; }
while [ "$#" -gt 0 ]; do
  case "$1" in
    --ledger)
      if [ "$#" -lt 2 ] || [ -z "$2" ]; then echo "--ledger requires a file path" >&2; exit 2; fi
      LEDGER="$2"; shift 2 ;;
    *) echo "Unknown argument: $1 (usage: analysis.sh [--ledger FILE])" >&2; exit 2 ;;
  esac
done
OUT="$RET/analysis_$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$OUT/logs" || { echo "cannot create the return folder $OUT; nothing was run"; exit 1; }
status() { echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) $*" >> "$OUT/ANALYSIS_STATUS.txt"; }
status "analysis started: interpreter $PY; ledger $LEDGER"
echo "analysis return folder: $OUT (send this folder when the analysis ends or stops)"

# Pre-flight: exit 0, a RESULT PASS line in SUMMARY.txt and a data contract, or no prediction file is read.
pfout=$("$PY" "$HERE/preflight_pod.py" --out-root "$PF" --skip-tests ${PREFLIGHT_ARGS:-} | tee >(cat >&2)); pfrc=$?
PFDIR=$(printf '%s\n' "$pfout" | sed -n 's/^PREFLIGHT_DIR=//p' | tail -1)
RESULT=""
if [ -n "$PFDIR" ] && [ -d "$PFDIR" ]; then
  PFCOPY="$OUT/preflight_$(basename "$PFDIR")"; mkdir -p "$PFCOPY"
  cp -rp "$PFDIR/." "$PFCOPY/"
  echo "pre-flight folder for this analysis: $PFDIR (copied into $PFCOPY)"
  [ -f "$PFDIR/SUMMARY.txt" ] && RESULT=$(grep -E '^RESULT:? (PASS|FAIL)' "$PFDIR/SUMMARY.txt" | tail -1 | sed -E 's/^RESULT:? (PASS|FAIL).*/\1/')
fi
if [ $pfrc -ne 0 ] || [ "$RESULT" != "PASS" ] || [ ! -f "$PFDIR/data_contract.json" ]; then
  status "stopped at the pre-flight: exit $pfrc, RESULT ${RESULT:-line missing}, folder ${PFDIR:-not found}"
  echo "PRE-FLIGHT FAILED (exit $pfrc, RESULT ${RESULT:-line missing}): nothing was analysed. Send the folder $OUT/ (it holds the complete pre-flight copy)."
  exit 1
fi
echo "pre-flight RESULT PASS: the analysis runs now"

# 1. The prediction files of each V1 run, from the ledger.
"$PY" "$HERE/analysis_runs.py" --ledger "$LEDGER" --out "$OUT/runs" 2>&1 | tee "$OUT/logs/analysis_runs.log"
rtrc=${PIPESTATUS[0]}
status "finished the run table: exit $rtrc"
found=$(sed -n 's/^V1 runs found in .*: \([0-9]*\) of 15$/\1/p' "$OUT/runs/RUNS.txt" 2>/dev/null)

# 2. The paired analysis of the runs found.
prc=1
if [ $rtrc -eq 0 ]; then
  mapfile -t PARGS < "$OUT/runs/paired_args.txt"
  "$PY" "$HERE/paired_report.py" --runs "$OUT/runs/run_table.csv" --out-dir "$OUT/report" "${PARGS[@]}" \
    2>&1 | tee "$OUT/logs/paired_report.log"
  prc=${PIPESTATUS[0]}
  status "finished paired_report.py: exit $prc"
fi
verdict=$([ $prc -eq 0 ] && echo "${found:-0} of 15 runs found and compared" || echo "THE COMPARISON DID NOT FINISH (see logs/)")
status "analysis finished: $verdict"
echo "Analysis finished: $verdict; send $OUT/"
exit $prc
