#!/usr/bin/env python3
# Written by reviewer (2026-10-07) for owner to run on the bank pod. Read-only: it trains nothing, writes
# nothing outside its own output folder, and exports aggregates only (counts, ranges, hashes), never
# transaction records, account ids or credentials.
"""Pod pre-flight and data-contract probe.

Run from the repository root on the pod:

    python runbook/2026-10-07/preflight_pod.py                 # static + data checks (several minutes)
    python runbook/2026-10-07/preflight_pod.py --skip-data     # no S3 reads (still several minutes: the trainer
                                                               # imports and the repository tests)
    python runbook/2026-10-07/preflight_pod.py --skip-tests    # do not run the repository tests
    python runbook/2026-10-07/preflight_pod.py --allow-warn-only <check>   # one named required check may only
                                                               # WARN (only on review advice; recorded)

It writes runs/preflight/<UTC time>/ with:
    SUMMARY.txt           one short report (about 2 to 3 screens); send the whole folder;
                          its last line is "RESULT PASS ..." or "RESULT FAIL ..." (see below); right before it come
                          three fixed lines saying what this return measures, what only the data owner can define
                          (OQ-13 part 1, OQ-14, OQ-15, OQ-20) and what only the comparisons establish
    source_diff.txt       every source file whose content differs from GitHub, or exists on one side only
    config_identity.json  manifest digest and the digests of the batch's own configuration files (specs, base
                          configs, predictor list); the collector copies the digests into the ledger
    environment.txt       the interpreter, the torch version and whether torch sees CUDA, lightning and the other
                          packages (a record for reading the return; nothing in it is checked)
    runtime_modules.txt   interpreter path and version; every third-party package the batch's own modules import,
                          with its version and origin; the optional packages (test suite and reference path only)
    pip_freeze.txt        installed packages
    specs.txt             every sweep cell resolved exactly as run_ablations.py resolves it
    data_contract.json    per-file rows and positives, time ranges, history depth (preceding rows and strictly
                          earlier rows), ties at the exact timestamp and at whole seconds, timestamp precision counts,
                          account overlap and composite-id overlap between splits (counts only)
    schema.txt            column names and stored types of the first file of each split, and any that differ
    feature_coverage.json missing rate per predictor and unknown-category rate per categorical (first 3 files per split)
    artifacts.txt         for each artifact prefix found: one sha256 line per file the runtime loader reads (manifest.json
                          and every feature file the manifest names) and one combined content digest over the feature files
    errors.txt            tracebacks of checks that failed (only when one failed)
    pytest.txt            the repository test output
    label_values.txt      the observed label values with their counts

Required checks (ST01, RUN-03, RUN-10) FAIL instead of WARN: pytest missing; a spec named by batch1.sh or batch2.sh
missing; a module of the batch's own runtime closure missing; drift in the batch's own YAML or spec files, in batch1.sh or batch2.sh (the spec list is read
from them) or in the runbook's own scripts preflight_pod.py, run_step.py, collect_returns.py, score_attempt.py,
batch_tools.py, smoke.sh and smoke_checks.py (they decide what runs and what is ACCEPTED). A batch
step is a quoted "<phase> <spec file>" pair with phase phase4a, phase4b or base; a base step (REF-SINGLE, a spec under
YOUR_PACKAGE/base/configs/) is resolved and compared like the others. The single-transaction reference path's packages
(pytorch_tabular, requests, pytorch_tabnet) stay WARN with their pip line even when a base step is listed. --allow-warn-only <check>
(check: pytest, spec, module, config; repeatable) turns exactly that check into WARN and records the override in
SUMMARY.txt; --accept-source-diff does the same for package-owned runtime .py drift. Original fraud/ differences
are recorded as WARN without an override; their actual bytes still enter every run's source identity.
There is no GPU check (owner, 2026-10-12, twenty-eighth message): no line about GPUs and no GPU condition changes RESULT.
Harness variables (RUNBOOK_SANDBOX, BATCH1_SKIP, BATCH2_SKIP, A_H10_COMPARATOR, PREFLIGHT_ARGS) set in the bank
profile FAIL unless RUNBOOK_BANK_OVERRIDES=1 is set, which is itself recorded as an override. The synthetic harness profile
(RUNBOOK_SANDBOX set together with RUNBOOK_BANK_OVERRIDES=1) does not need the credential file.

Contract for the batch scripts: exit code 0 = RESULT PASS (no FAIL; WARNs and recorded overrides allowed),
1 = RESULT FAIL, 2 = the pre-flight itself could not run (bad arguments, or a crash; SUMMARY.txt then ends with
RESULT FAIL and names the crash). The last stdout line is PREFLIGHT_DIR=<folder>. SUMMARY.txt's last line is
"RESULT PASS|FAIL | <n> FAIL, <n> WARN | overrides: none|<names> | exit <code>".
"""
import argparse
import ast
import csv
import datetime as _dt
import getpass
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import operator
import os
import platform
import posixpath
import re
import subprocess
import sys
import traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
from YOUR_PACKAGE.source_identity import excluded_source_path, runtime_source_path

RUNBOOK_DIR = "runbook/2026-10-07"
MANIFEST_NAME = "github_source_manifest.csv"
BATCH_SCRIPTS = ("batch1.sh", "batch2.sh")
# The runbook's own scripts: drift in them is a required check like the batch scripts (S1-F04), since they decide what
# runs, what is ACCEPTED and how the post-hoc scores are made.
RUNBOOK_SCRIPTS = ("preflight_pod.py", "run_step.py", "collect_returns.py", "score_attempt.py", "batch_tools.py",
                   "smoke.sh", "smoke_checks.py")
# Smoke specs (one cell each, two training files): their ranges differ from the batch cohort by design, so they are
# resolved and recorded but their range keys are not compared with PROBE_RANGES.
SMOKE_SPECS = {"phase4a": ["ft_decisions_smoke.yaml"], "phase4b": ["ft_decisions_hier_smoke.yaml"]}
RANGE_KEYS = ("data.train_start", "data.train_end", "data.val_start", "data.val_end", "eval.file_start", "eval.file_end")
REQUIREMENTS_POD = os.path.join(ROOT, "YOUR_PACKAGE", "requirements-pod.txt")  # the pod package list (one pip line each)
# Needed only by the test suite and the single-transaction reference path, never by the batch's own trainers.
OPTIONAL_PACKAGES = ("pytorch_tabular", "requests", "pytorch_tabnet")
# Import name -> distribution name where they differ (for the pip line lookup).
MODULE_DIST = {"yaml": "pyyaml", "sklearn": "scikit-learn", "PIL": "pillow", "pytorch_tabnet": "pytorch-tabnet",
               "pytorch_lightning": "pytorch-lightning", "dateutil": "python-dateutil", "attr": "attrs"}
HARNESS_VARS = ("RUNBOOK_SANDBOX", "BATCH1_SKIP", "BATCH2_SKIP", "A_H10_COMPARATOR", "PREFLIGHT_ARGS")  # one list with the batch scripts
OVERRIDE_CHECKS = ("pytest", "spec", "module", "config")
ALLOW_WARN_ONLY = set()   # --allow-warn-only names
OVERRIDES_USED = []       # every override that actually turned a FAIL into a WARN, listed in SUMMARY.txt
OPTIONAL_MISSING = {}     # missing optional module -> pip line (filled by check_imports, read by check_tests)
# Test folders the pre-flight runs: batch 1's own (YOUR_PACKAGE/tests, the runbook tests) are required; a missing folder or a
# failing or uncollectable file there is FAIL. A file that cannot be collected only because an OPTIONAL package is
# missing is named as WARN and never counted as passed.
TEST_SUITES = (("YOUR_PACKAGE/tests", "required"), (RUNBOOK_DIR + "/tests", "required"), ("tests", "optional"))
# Three fixed closing lines of SUMMARY.txt, right before RESULT (S1-04): what the return measures, what no check here
# can settle because only the data owner can define it, and what only the comparisons themselves establish.
CLOSING_LINES = (
    "Measured in this return: cohort counts and rates, ties and frauds in ties, timestamp granularity, strict depth, "
    "overlap, environment and packages, source and config and artifact identity, each only where its step ran",
    "Needs a definition from the data owner, never a PASS from code: OQ-13 part 1 (do ids follow arrival order within a "
    "second), OQ-14 (inputs available before the decision), OQ-15 (label maturity), OQ-20 (advice rows)",
    "Established only by the comparisons themselves, not by any check here: whether history and the other settings "
    "help, the matched reference and cohorts, the protected final evaluation",
)


# A step of a batch script is a quoted "<phase> <spec file>" pair. V1 build item B8 part 5 (RECONCILIATION C12) widened
# the pattern from "phase4a|phase4b ft_decisions*.yaml" to the base phase and any spec file name, so a
# "base ref_single.yaml" step is checked like the others instead of being skipped silently.
BATCH_STEP_PATTERN = r'"(phase4[ab]|base) ([A-Za-z0-9][\w.-]*\.yaml)"'
SPEC_PHASES = ("phase4a", "phase4b", "base")


def specs_in_batch_scripts(here=None):
    """{phase: [spec names]} in launch order, read from batch1.sh and batch2.sh: the one list of batch specs."""
    found = {phase: [] for phase in SPEC_PHASES}
    for script in BATCH_SCRIPTS:
        path = os.path.join(here or HERE, script)
        if not os.path.exists(path):
            continue
        with open(path) as f:
            text = f.read()
        for phase, name in re.findall(BATCH_STEP_PATTERN, text):
            if name not in found[phase]:
                found[phase].append(name)
    return found


SPECS = specs_in_batch_scripts()
# The batch cohort: file ranges the data probe reads, merged onto the base config by probe_config(). check_specs
# FAILs any spec cell whose effective value of a PROBED_KEYS entry differs, so the files, columns, artifacts and
# predictor list checked here are exactly the ones the sweeps launch with.
PROBE_RANGES = {"data.train_start": 1, "data.train_end": 10, "data.val_start": 4950, "data.val_end": 4954,
                "eval.file_start": 8000, "eval.file_end": 8010}
PROBED_KEYS = ("data.train_base", "data.train_start", "data.train_end", "data.val_base", "data.val_start",
               "data.val_end", "eval.base", "eval.file_start", "eval.file_end", "data.account_col", "data.order_col",
               "data.target_col", "data.tie_break_col", "data.positive_label", "artifacts.base", "artifacts.version",
               "predictors.csv_path", "predictors.version")
SOURCE_DIRS = ["fraud", "YOUR_PACKAGE", RUNBOOK_DIR]
RUNTIME_PREFIXES = ("YOUR_PACKAGE/base/", "YOUR_PACKAGE/phase4a/", "YOUR_PACKAGE/phase4b/", "YOUR_PACKAGE/source_identity.py")
ACCEPT_SOURCE_DIFF = False
LINES, FAILS, WARNS = [], [], []


def source_class(rel):
    """Manifest class of a repository file by its path (the `class` column of github_source_manifest.csv), or None
    when the manifest does not track it:
      python   .py under fraud/ or YOUR_PACKAGE/        shell   .sh under fraud/ or YOUR_PACKAGE/      data   .csv (predictor list)
      spec     ft_decisions*.yaml under YOUR_PACKAGE/phase4a/configs or YOUR_PACKAGE/phase4b/configs (sweep and smoke specs)
      config   every other .yaml/.yml under fraud/ or YOUR_PACKAGE/ (base configs, tuner, preprocessing)
      runbook  .py and .sh in runbook/2026-10-07 (launch harness); the manifest itself is excluded
    Development tests, synthetic fixtures and parked future experiments are excluded by the shared source rule."""
    rel = rel.replace(os.sep, "/")
    if excluded_source_path(rel):
        return None
    name, ext = os.path.basename(rel), os.path.splitext(rel)[1]
    if rel.startswith(RUNBOOK_DIR + "/"):
        return "runbook" if ext in (".py", ".sh") and name != MANIFEST_NAME else None
    if not rel.startswith(("fraud/", "YOUR_PACKAGE/")):
        return None
    if ext == ".py":
        return "python"
    if ext == ".sh":
        return "shell"
    if ext == ".csv":
        return "data"
    if ext in (".yaml", ".yml"):
        in_phase_configs = os.path.dirname(rel) in ("YOUR_PACKAGE/phase4a/configs", "YOUR_PACKAGE/phase4b/configs")
        return "spec" if in_phase_configs and name.startswith("ft_decisions") else "config"
    return None


def say(tag, msg):
    line = f"{tag:<5} {msg}"
    LINES.append(line)
    print(line)
    if tag == "FAIL":
        FAILS.append(msg)
    elif tag == "WARN":
        WARNS.append(msg)


def bank_overrides():
    return os.environ.get("RUNBOOK_BANK_OVERRIDES") == "1"


def synthetic_profile():
    """reviewer's CPU harness: RUNBOOK_SANDBOX set together with the explicit bank-side flag. No credential file."""
    return bool(os.environ.get("RUNBOOK_SANDBOX")) and bank_overrides()


def required(check, msg):
    """A required check that did not pass: FAIL, or WARN when --allow-warn-only <check> was given (the override is
    recorded so the reviewers see it; an override is never presented as a passing check)."""
    if check in ALLOW_WARN_ONLY:
        OVERRIDES_USED.append(check)
        say("WARN", f"OVERRIDE --allow-warn-only {check}: {msg}")
    else:
        say("FAIL", msg)


def guarded(title):
    """Run one check; on error report only the check name, the exception TYPE and a reference number.
    Exception messages can contain data values or request details, so they never reach SUMMARY.txt; the full
    traceback goes to errors.txt."""
    def wrap(fn):
        def run(*a, **k):
            try:
                return fn(*a, **k)
            except Exception as exc:  # every check is independent; report and continue
                ref = len(FAILS) + 1
                say("FAIL", f"{title}: {type(exc).__name__} (reference E{ref} in errors.txt)")
                with open(os.path.join(a[0], "errors.txt"), "a") as f:
                    f.write(f"== E{ref} {title}\n{traceback.format_exc()}\n")
        return run
    return wrap


def masked_first_line(exc, limit=200):
    """The first line of an exception message with every token holding a path separator (file paths, URLs, S3 keys)
    replaced by <path>, every key or token shaped run of 16 or more letters, digits, + or = by <redacted>, and every
    remaining run of four or more digits by # signs (an errno, an HTTP status or a port stays readable); cut at `limit`
    characters. For errors.txt, where the class name alone would
    leave a permissions, endpoint or bucket error without any detail (S1-F03)."""
    line = (str(exc).strip().splitlines() or [""])[0]
    line = re.sub(r"\S*[/\\]\S*", "<path>", line)
    line = re.sub(r"[A-Za-z0-9+=]{16,}", "<redacted>", line)
    line = re.sub(r"\d{4,}", lambda m: "#" * len(m.group()), line)
    return line[:limit]


def norm_sha(path):
    with open(path, "rb") as f:
        data = f.read().replace(b"\r\n", b"\n")
    return hashlib.sha256(data).hexdigest()


def pip_freeze_text():
    """(content for pip_freeze.txt, note). The note is None when `python -m pip freeze` worked and the content is its
    output with URL credentials redacted. Otherwise the content is one line saying why there is no package list, and
    the same line is the note for environment.txt and the environment INFO line: pip is not importable in this
    interpreter (a uv environment, say), the command exited non-zero (exit code and its first stderr line, masked like
    masked_first_line), or it did not run (the exception class). J-S1-F06: the file used to be written empty."""
    if importlib.util.find_spec("pip") is None:
        note = f"pip freeze unavailable: pip is not importable in {sys.executable}"
        return note + "\n", note
    try:
        p = subprocess.run([sys.executable, "-m", "pip", "freeze"], capture_output=True, text=True, timeout=120)
    except Exception as exc:  # TimeoutExpired, or the interpreter could not be started
        note = f"pip freeze unavailable: python -m pip freeze did not run ({type(exc).__name__})"
        return note + "\n", note
    if p.returncode != 0:
        note = (f"pip freeze unavailable: python -m pip freeze exited {p.returncode}: "
                + (masked_first_line(p.stderr) or "(no stderr)"))
        return note + "\n", note
    # Remove credentials embedded in VCS or index URLs (user:token@host) before writing.
    return re.sub(r"//[^/\s@]+@", "//<redacted>@", p.stdout), None


@guarded("environment")
def check_environment(out):
    """environment.txt and pip_freeze.txt: a record for reading the return, not a check. It holds the interpreter, the
    torch version and whether torch sees CUDA (torch.cuda.is_available(), plain data), and the package versions."""
    import torch
    lines = [f"python {platform.python_version()} ({sys.executable})"]
    lines.append(f"torch {torch.__version__}; cuda available {torch.cuda.is_available()}; cuda {torch.version.cuda}")
    try:
        import pytorch_lightning as pl
        lines.append(f"pytorch_lightning {pl.__version__}")
    except Exception as exc:
        lines.append(f"pytorch_lightning import error {exc}")
    for mod in ("pyarrow", "pandas", "numpy", "s3fs", "omegaconf", "sklearn", "torchmetrics"):
        try:
            m = __import__(mod)
            lines.append(f"{mod} {getattr(m, '__version__', '?')}")
        except Exception as exc:
            lines.append(f"{mod} import error {exc}")
    freeze, freeze_note = pip_freeze_text()
    if freeze_note:
        lines.append(freeze_note)
    with open(os.path.join(out, "environment.txt"), "w") as f:
        f.write("\n".join(lines) + "\n")
    with open(os.path.join(out, "pip_freeze.txt"), "w") as f:
        f.write(freeze)
    pt = subprocess.run([sys.executable, "-c", "import pytorch_tabular, os; print(os.path.dirname(pytorch_tabular.__file__))"],
                        cwd=ROOT, capture_output=True, text=True)
    if pt.returncode == 0:
        say("INFO", f"pytorch_tabular importable from {os.path.relpath(pt.stdout.strip(), ROOT)}")
    else:
        say("INFO", "pytorch_tabular not importable without src/ on PYTHONPATH (scripts add src/ when needed)")
    say("INFO", lines[0] + " | " + lines[1])  # interpreter path included (RG-F12)
    say("INFO", " | ".join(l for l in lines[2:] if l.startswith(("pytorch_lightning", "pyarrow", "pandas")))
                + (f" | {freeze_note}" if freeze_note else ""))


@guarded("profile")
def check_profile(out):
    """Harness variables must be unset in the bank profile; RUNBOOK_BANK_OVERRIDES=1 allows them and is recorded."""
    present = [v for v in HARNESS_VARS if os.environ.get(v)]
    profile = "synthetic harness" if synthetic_profile() else "bank"
    if not present:
        say("PASS", f"profile {profile}: none of {', '.join(HARNESS_VARS)} is set")
    elif bank_overrides():
        OVERRIDES_USED.append("RUNBOOK_BANK_OVERRIDES")
        say("WARN", f"OVERRIDE RUNBOOK_BANK_OVERRIDES=1: harness variable(s) set: {', '.join(present)} ({profile} "
                    "profile)")
    else:
        say("FAIL", f"harness variable(s) set in the bank profile: {', '.join(present)}; unset them, or set "
                    "RUNBOOK_BANK_OVERRIDES=1 only on review advice")


def batch_base_configs():
    """{base config path: [specs that name it]} for the batch and smoke specs present on disk, plus the probe base."""
    from omegaconf import OmegaConf
    bases = {"YOUR_PACKAGE/phase4a/configs/sequential.yaml": []}
    for phase in SPEC_PHASES:
        for name in SPECS.get(phase, []) + SMOKE_SPECS.get(phase, []):
            rel = f"YOUR_PACKAGE/{phase}/configs/{name}"
            if not os.path.isfile(os.path.join(ROOT, rel)):
                continue
            try:
                base = str(OmegaConf.load(os.path.join(ROOT, rel)).get("base_config", "") or "")
            except Exception:
                continue
            if base:
                bases.setdefault(base.replace(os.sep, "/"), []).append(rel)
    return bases


def batch_config_files():
    """The batch's own configuration files, derived from the specs the batch scripts name (and the smoke specs when
    present): every such spec path, each base config a present spec names, and the predictor list each base config
    names when it is a repository file. Drift in any of these is a required check (override name `config`)."""
    from omegaconf import OmegaConf
    files = {f"YOUR_PACKAGE/{phase}/configs/{name}" for phase, names in SPECS.items() for name in names}
    files |= {f"YOUR_PACKAGE/{phase}/configs/{name}" for phase, names in SMOKE_SPECS.items() for name in names
              if os.path.isfile(os.path.join(ROOT, "YOUR_PACKAGE", phase, "configs", name))}
    for base in batch_base_configs():
        files.add(base)
        try:
            csv_path = str(OmegaConf.load(os.path.join(ROOT, base)).predictors.csv_path)
        except Exception:
            continue
        if not csv_path.startswith(("s3://", "s3a://")) and not os.path.isabs(csv_path):
            files.add(csv_path.replace(os.sep, "/"))
    return sorted(files)


def credential_paths():
    """{s3.cred_path: [configs naming it]} over the batch's base configs."""
    from omegaconf import OmegaConf
    paths = {}
    for base, _ in sorted(batch_base_configs().items()):
        try:
            cred = str(OmegaConf.load(os.path.join(ROOT, base)).s3.cred_path)
        except Exception:
            continue
        paths.setdefault(cred, []).append(base)
    return paths


@guarded("credential file")
def check_credentials(out):
    """The credential file the base configs name must exist and be readable by this user. Nothing from it is read
    into the report, printed or copied: one byte is read to prove readability and discarded."""
    if synthetic_profile():
        say("INFO", "credential file: not required in the synthetic harness profile (fake S3)")
        return
    for path, configs in credential_paths().items():
        try:
            with open(path, "rb") as f:
                f.read(1)
            readable = True
        except OSError:
            readable = False
        if readable:
            say("PASS", f"credential file {path} (s3.cred_path in {', '.join(configs)}) exists and is readable; its "
                        "contents are not read into this report")
        else:
            say("FAIL", f"credential file {path} (s3.cred_path in {', '.join(configs)}) does not exist or is not "
                        "readable by this user: the batch cannot reach S3")


_OPS = {">=": operator.ge, "<=": operator.le, ">": operator.gt, "<": operator.lt, "==": operator.eq, "!=": operator.ne}


def in_declared_range(installed, spec):
    """True when an installed version satisfies a specifier such as '>=1.1.5,<3.0.0'."""
    try:
        from packaging.specifiers import SpecifierSet
    except ImportError:  # minimal fallback for the plain comparison operators pyproject.toml uses
        def release(v):
            return [int(x) for x in re.match(r"\s*(\d+(?:\.\d+)*)", v).group(1).split(".")]
        for clause in spec.split(","):
            op, ver = re.fullmatch(r"\s*(>=|<=|==|!=|>|<)\s*(\S+)\s*", clause).groups()
            a, b = release(installed), release(ver)
            n = max(len(a), len(b))
            if not _OPS[op](a + [0] * (n - len(a)), b + [0] * (n - len(b))):
                return False
        return True
    return SpecifierSet(spec).contains(installed, prereleases=True)


@guarded("dependency ranges")
def check_dependencies(out):
    """Installed runtime dependencies must lie inside the ranges [project].dependencies declares in pyproject.toml."""
    from importlib.metadata import PackageNotFoundError, version
    with open(os.path.join(ROOT, "pyproject.toml")) as f:
        text = f.read()
    try:
        import tomllib
        reqs = list(tomllib.loads(text)["project"]["dependencies"])
    except ImportError:  # Python 3.10: the dependencies entry is a plain array of quoted strings
        reqs = re.findall(r'"([^"]+)"', re.search(r"^dependencies\s*=\s*\[(.*?)\]", text, re.S | re.M).group(1))
    outside = 0
    for req in reqs:
        name, spec = re.match(r"\s*([A-Za-z0-9_.\-]+)\s*(.*)", req).groups()
        try:
            installed = version(name)
        except PackageNotFoundError:
            say("WARN", f"dependency {name} not installed (declared {spec or 'any version'})")
            continue
        if spec and not in_declared_range(installed, spec):
            outside += 1
            say("FAIL", f"dependency {name} {installed} is outside the declared range {spec} (pyproject.toml)")
    if not outside:
        say("PASS", f"dependency versions: every installed one of the {len(reqs)} declared in pyproject.toml is in range")


@guarded("source identity")
def check_source(out):
    ref_path = os.path.join(HERE, MANIFEST_NAME)
    ref = {}
    with open(ref_path) as f:
        for row in csv.DictReader(f):  # the `class` column (make_source_manifest.py) is optional for older manifests
            ref[row["path"]] = row["sha256_lf"]
    here = {}
    for d in SOURCE_DIRS:
        for dp, dns, fns in os.walk(os.path.join(ROOT, d)):
            dns[:] = [x for x in dns if x != "__pycache__" and not x.startswith(".")]
            for fn in fns:
                p = os.path.join(dp, fn)
                rel = os.path.relpath(p, ROOT).replace(os.sep, "/")
                if source_class(rel) is not None:
                    here[rel] = norm_sha(p)
    differ = sorted(p for p in here if p in ref and here[p] != ref[p])
    only_pod = sorted(p for p in here if p not in ref)
    only_gh = sorted(p for p in ref if p not in here)
    ref_sha = norm_sha(ref_path)
    with open(os.path.join(out, "source_diff.txt"), "w") as f:
        f.write(f"reference: {os.path.basename(ref_path)} ({len(ref)} files, sha256 {ref_sha} with CRLF normalized "
                f"to LF)\n")
        for title, items in (("DIFFERS", differ), ("ONLY ON POD", only_pod), ("ONLY ON GITHUB", only_gh)):
            f.write(f"\n{title} ({len(items)})\n" + "".join(f"  {p}\n" for p in items))
        f.write("\nPOD HASHES (path, sha256 of content with CRLF normalized to LF)\n")
        f.write("".join(f"{p},{here[p]}\n" for p in sorted(here)))
    same = len(here) - len(differ) - len(only_pod)
    # Changed, missing AND unreviewed extra runtime modules (an extra module can shadow or change imports).
    kind = {**{p: "differs" for p in differ}, **{p: "only on pod" for p in only_pod}, **{p: "only on GitHub" for p in only_gh}}
    runtime = [p for p in differ + only_pod + only_gh if runtime_source_path(p)]
    # The installed fraud/ tree is reference's untouched original, not code this package ships.
    # Record its actual bytes without treating the photo transcription as its authority.
    original_drift = [p for p in kind if p.startswith("fraud/")]
    owned_runtime = [p for p in runtime if not p.startswith("fraud/")
                     and (p in ref or p.startswith(RUNTIME_PREFIXES))]
    msg = (f"source vs reviewed manifest (sha256 {ref_sha}): {same} same, {len(differ)} differ, "
           f"{len(only_pod)} only on pod, {len(only_gh)} only on GitHub; runtime .py differences {len(runtime)} "
           f"({len(owned_runtime)} package-owned, {len(original_drift)} original-source differences; "
           f"list: source_diff.txt)")
    if owned_runtime and ACCEPT_SOURCE_DIFF:  # recorded override for shipped/owned code only
        OVERRIDES_USED.append("accept-source-diff")
        say("WARN", f"OVERRIDE --accept-source-diff: {msg}")
    elif owned_runtime:
        say("FAIL", msg)
    elif differ or only_pod or only_gh:
        say("WARN", msg)
    else:
        say("PASS", msg)
    for p in (owned_runtime or runtime or differ)[:12]:
        say("    ", f"{kind[p]}: {p}")
    if len(owned_runtime or runtime or differ) > 12:
        say("    ", f"... {len(owned_runtime or runtime or differ) - 12} more in source_diff.txt")
    if owned_runtime and not ACCEPT_SOURCE_DIFF:
        say("    ", "the pod's package-owned runtime code is not the reviewed code: send the runtime .py paths in source_diff.txt, or rerun "
                   "with --accept-source-diff only after reviewers have looked at the list")
    # RUN-10: the batch's own configuration files (specs, their base configs, the predictor list) must be the
    # reviewed ones, and so must batch1.sh and batch2.sh, since the spec list is read from them (F6), and the runbook's
    # own scripts (S1-F04); other YAML drift and drift in the runbook's tests stay WARN above.
    batch = batch_config_files()
    watched = sorted(set(batch + [f"{RUNBOOK_DIR}/{s}" for s in BATCH_SCRIPTS + RUNBOOK_SCRIPTS]
                         + [p for p in ref if source_class(p) == "runbook"]))
    owned_watched = [p for p in watched if not p.startswith("fraud/")]
    original_config_drift = [p for p in watched if p in kind and p.startswith("fraud/")]
    drift = [p for p in owned_watched if p in kind]
    if original_config_drift:
        say("WARN", "original dependency configuration differs from the transcription (preserved, recorded in "
                    "source_diff.txt): " + "; ".join(f"{kind[p]}: {p}" for p in original_config_drift))
    if drift:
        required("config", f"configuration drift in {len(drift)} of the batch's own {len(owned_watched)} files (specs, base "
                           "configs, predictor list, batch scripts, runbook scripts): "
                           + "; ".join(f"{kind[p]}: {p}" for p in drift[:8])
                           + (f"; ... {len(drift) - 8} more" if len(drift) > 8 else ""))
    else:
        say("PASS", f"the package-owned {len(owned_watched)} files (specs, base configs, batch scripts, runbook "
                    "scripts) match the manifest")
    h = hashlib.sha256()
    for p in batch:
        h.update(f"{p},{here.get(p, 'missing')}\n".encode())
    identity = {"manifest_sha256": ref_sha, "active_configs_sha256": h.hexdigest(),
                "active_configs_digest_note": "sha256 over 'path,sha256_lf' lines of batch_config_files in sorted "
                                              "order; 'missing' for a file absent on the pod",
                "batch_config_files": {p: here.get(p) for p in batch}, "config_drift": drift,
                "runtime_py_drift": owned_runtime, "observed_runtime_py_drift": runtime,
                "original_source_drift": original_drift, "original_config_drift": original_config_drift,
                "runbook_drift": [p for p in kind if source_class(p) == "runbook"]}
    with open(os.path.join(out, "config_identity.json"), "w") as f:
        json.dump(identity, f, indent=2)
    say("INFO", f"active configuration identity {h.hexdigest()[:12]} over {len(batch)} files (config_identity.json)")


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def norm_dist(name):
    return re.sub(r"[-_.]+", "-", name).lower()


def pip_line(module):
    """The exact line of YOUR_PACKAGE/requirements-pod.txt that installs `module`, as a pip command; or what is missing.
    pytorch_tabular has no pip line: it is bundled under src/, so a missing copy means the folder is incomplete."""
    if module == "pytorch_tabular":
        return "the bundled copy under src/pytorch_tabular is missing from this folder; unzip the release again"
    dist = MODULE_DIST.get(module, module)
    rel = os.path.relpath(REQUIREMENTS_POD, ROOT)
    if not os.path.isfile(REQUIREMENTS_POD):
        return f"pip line unknown: {rel} is missing"
    with open(REQUIREMENTS_POD) as f:
        for line in f:
            req = line.split("#")[0].strip()
            m = re.match(r"([A-Za-z0-9][A-Za-z0-9_.\-]*)", req)
            if m and norm_dist(m.group(1)) == norm_dist(dist):
                return f'pip install "{req}"'
    return f"no line in {rel} names {dist}: add one"


def imported_top_levels(path):
    """Top-level names of every absolute import statement in a source file, at module level and inside functions
    (so lazy imports such as s3fs count), excluding imports guarded by try/except ImportError."""
    with open(path, "rb") as f:
        tree = ast.parse(f.read(), filename=path)
    guarded_nodes = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Try) and any(
                isinstance(h.type, ast.Name) and h.type.id in ("ImportError", "ModuleNotFoundError", "Exception")
                for h in node.handlers):
            for sub in node.body:
                guarded_nodes.update(id(x) for x in ast.walk(sub))
    names = set()
    for node in ast.walk(tree):
        if id(node) in guarded_nodes:
            continue
        if isinstance(node, ast.Import):
            names.update(a.name.split(".")[0] for a in node.names)
        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            names.add(node.module.split(".")[0])
    return names


def owned_module_files(name):
    """Source files an owned module name (fraud.x.y or YOUR_PACKAGE.x.y) executes under ROOT: the module and its packages."""
    parts = name.split(".")
    files = []
    for n in range(1, len(parts) + 1):
        base = os.path.join(ROOT, *parts[:n])
        if os.path.isfile(os.path.join(base, "__init__.py")):
            files.append(os.path.join(base, "__init__.py"))
        elif os.path.isfile(base + ".py"):
            files.append(base + ".py")
            break
    return files


def runtime_closure(start_files):
    """(owned source files, third-party top-level import names) reachable from start_files through fraud.* and
    YOUR_PACKAGE.* imports, read from the code (so the list is derived, not hand kept)."""
    stdlib = set(getattr(sys, "stdlib_module_names", ())) | {"__future__"}
    owned, third, todo = set(), set(), [os.path.abspath(p) for p in start_files if os.path.isfile(p)]
    while todo:
        path = todo.pop()
        if path in owned:
            continue
        owned.add(path)
        with open(path, "rb") as f:
            tree = ast.parse(f.read(), filename=path)
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                names = [a.name for a in node.names]
            elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
                names = [node.module]
            else:
                continue
            for name in names:
                if name.split(".")[0] in ("fraud", "YOUR_PACKAGE"):
                    todo += [p for p in owned_module_files(name) if p not in owned]
        third |= {t for t in imported_top_levels(path) if t not in stdlib and t not in ("fraud", "YOUR_PACKAGE")}
    return sorted(owned), sorted(third)


def optional_missing(pkg):
    """None when the optional package imports in this interpreter (pytorch_tabular also from the bundled src/ when
    no installed copy exists); otherwise the name of the module that is missing."""
    if pkg != "pytorch_tabular":
        return None if importlib.util.find_spec(pkg) is not None else pkg
    code = "import pytorch_tabular, os; print(os.path.dirname(pytorch_tabular.__file__))"
    for env in (None, {**os.environ, "PYTHONPATH": os.pathsep.join([os.path.join(ROOT, "src"), ROOT]
                                                                 + ([os.environ["PYTHONPATH"]] if os.environ.get("PYTHONPATH") else []))}):
        p = subprocess.run([sys.executable, "-c", code], cwd=ROOT, capture_output=True, text=True, env=env)
        if p.returncode == 0:
            return None
    m = re.search(r"No module named '([\w.]+)'", p.stderr)
    return m.group(1).split(".")[0] if m else pkg


@guarded("runtime imports")
def check_imports(out):
    """RUN-03: in this interpreter, load the two owned trainers and runners; derive the runtime closure (owned
    modules and every third-party package they import, lazily or not) from the code; a missing module of that
    closure is a required check (override name `module`) named with its pip line from YOUR_PACKAGE/requirements-pod.txt.
    Optional packages (test suite and reference path only) missing are WARN with the pip line. Interpreter and
    package versions go to runtime_modules.txt and SUMMARY.txt."""
    rel_req = os.path.relpath(REQUIREMENTS_POD, ROOT)
    if not os.path.isfile(REQUIREMENTS_POD):
        say("FAIL", f"{rel_req} is missing: the pod package list of this release is not in the folder")
    starts, missing = [], {}
    for phase in ("phase4a", "phase4b"):
        for script in ("train_sequential.py", "run_ablations.py"):
            path = os.path.join(ROOT, "YOUR_PACKAGE", phase, "scripts", script)
            starts.append(path)
            try:
                mod = load_module(f"{script[:-3]}_{phase}", path)
            except ModuleNotFoundError as exc:
                top = (exc.name or "?").split(".")[0]
                missing[top] = f"{phase}/{script}"
                continue
            if script == "train_sequential.py":
                got = mod.SequenceBuilder.__module__
                say("PASS" if got == f"YOUR_PACKAGE.{phase}.sequence_builder" else "FAIL", f"{phase} trainer uses builder {got}")
    starts += [os.path.join(HERE, fn) for fn in ("run_step.py", "collect_returns.py", "score_attempt.py")]
    owned, third = runtime_closure(starts)
    dists = importlib.metadata.packages_distributions()
    lines = [f"interpreter {sys.executable} python {platform.python_version()}", f"owned modules {len(owned)}",
             "third-party packages the batch's own modules import (module, distribution, version, location):"]
    versions = []
    for top in third:
        spec = importlib.util.find_spec(top)
        if spec is None:
            missing.setdefault(top, "import statement in the owned modules")
            lines.append(f"  {top}: MISSING")
            continue
        dist = (dists.get(top) or [MODULE_DIST.get(top, top)])[0]
        try:
            ver = importlib.metadata.version(dist)
        except importlib.metadata.PackageNotFoundError:
            ver = "?"
        where = os.path.dirname(spec.origin) if spec.origin and spec.origin != "built-in" else (spec.origin or "?")
        lines.append(f"  {top}: {dist} {ver} ({where})")
        versions.append(f"{top} {ver}")
    for top, where in sorted(missing.items()):
        required("module", f"runtime module {top} is missing (needed by {where}); {pip_line(top)}")
    if not missing:
        say("PASS", f"runtime closure: {len(owned)} owned modules and {len(third)} third-party packages all import in "
                    f"{sys.executable}")
    say("INFO", "runtime packages: " + ", ".join(versions))
    lines.append("optional packages (test suite and single-transaction reference path only):")
    for pkg in OPTIONAL_PACKAGES:
        miss = optional_missing(pkg)
        if miss is None:
            lines.append(f"  {pkg}: importable")
            continue
        OPTIONAL_MISSING[miss] = pip_line(miss)
        lines.append(f"  {pkg}: MISSING {miss}")
        say("WARN", f"optional package {pkg} (test suite and reference path only, not batch 1) cannot import: missing "
                    f"{miss}; {pip_line(miss)}")
    with open(os.path.join(out, "runtime_modules.txt"), "w") as f:
        f.write("\n".join(lines) + "\n")


def probe_config():
    """Base config with the batch file ranges: exactly what the data, artifact and coverage probes read (no S3)."""
    from omegaconf import OmegaConf
    base = OmegaConf.load(os.path.join(ROOT, "YOUR_PACKAGE", "phase4a", "configs", "sequential.yaml"))
    return OmegaConf.merge(base, OmegaConf.from_dotlist([f"{k}={v}" for k, v in PROBE_RANGES.items()]))


def probed_value(cfg, key):
    from omegaconf import OmegaConf
    v = OmegaConf.select(cfg, key)
    return v.rstrip("/") if isinstance(v, str) and key.endswith(".base") else v  # build_file_list strips "/"


@guarded("sweep specs")
def check_specs(out):
    """Resolve every cell as run_ablations.py does; FAIL a cell whose data, artifact or predictor settings differ
    from what this pre-flight probes, so the checked cohort is the launched cohort."""
    from omegaconf import OmegaConf
    probe = probe_config()
    lines = []
    for phase in SPEC_PHASES:
        cells = [(n, False) for n in SPECS.get(phase, [])] + [(n, True) for n in SMOKE_SPECS.get(phase, [])]
        if not cells:
            continue
        runner = load_module(f"runner_{phase}", os.path.join(ROOT, "YOUR_PACKAGE", phase, "scripts", "run_ablations.py"))
        for name, smoke in cells:
            sp = os.path.join(ROOT, "YOUR_PACKAGE", phase, "configs", name)
            if not os.path.exists(sp):
                if smoke:
                    say("INFO", f"{phase}/{name}: smoke spec not present (optional for this pre-flight)")
                else:
                    required("spec", f"{phase}/{name}: a spec named by {' or '.join(BATCH_SCRIPTS)} is missing")
                continue
            spec = OmegaConf.load(sp)
            base = OmegaConf.load(os.path.join(ROOT, str(spec.base_config)))
            common = [str(o) for o in spec.get("common_overrides", [])]
            _, runs = runner._expand_runs(spec)
            root = str(spec.get("output_root", "ablations"))
            exists = os.path.exists(os.path.join(ROOT, root))
            bad = []
            for run_name, ov, _ in runs:
                eff = OmegaConf.merge(base, OmegaConf.from_dotlist(common + ov))
                bs, acc = int(eff.training.batch_size), int(eff.training.get("accumulate_grad_batches", 1))
                ranges = (f"train {eff.data.train_start}-{eff.data.train_end} val {eff.data.val_start}-"
                          f"{eff.data.val_end} eval {eff.eval.file_start}-{eff.eval.file_end}")
                if phase == "base":  # REF-SINGLE: one transaction, no sequence settings (B8 part 5)
                    h = 0
                    row = (f"{phase}/{name}:{run_name} | single transaction batch {bs}x{acc} | {ranges} | model "
                           f"d{eff.model.input_embed_dim} blocks {eff.model.num_attn_blocks} heads {eff.model.num_heads} "
                           f"lr {eff.training.learning_rate} epochs {eff.training.max_epochs} seed {eff.training.seed} "
                           f"artifacts {eff.artifacts.base}/{eff.artifacts.version}")
                else:
                    h = int(eff.sequence.history_len)
                    row = (f"{phase}/{name}:{run_name} | h{h} batch {bs}x{acc} | {ranges} | emb "
                           f"{eff.model.continuous_embedding} mask {eff.sequence.attention_mask} "
                           f"opt {eff.training.optimizer} ema {eff.training.get('ema', False)} seed {eff.training.seed} "
                           f"td {eff.sequence.get('time_delta', True)} artifacts {eff.artifacts.base}/{eff.artifacts.version}")
                lines.append(row)
                for key in PROBED_KEYS:
                    if smoke and key in RANGE_KEYS:
                        continue  # smoke cells use their own small ranges by design: recorded in specs.txt, not compared
                    got, probed = probed_value(eff, key), probed_value(probe, key)
                    if got != probed:
                        bad.append(f"{run_name}: {key} {got} but pre-flight probes {probed}")
                if bool(eff.training.get("ema", False)):
                    bad.append(f"{run_name}: ema on")
                if phase == "phase4a" and h >= 10 and bs > 1024:
                    bad.append(f"{run_name}: h{h} at batch {bs}")
            say("FAIL" if bad else "PASS",
                f"{phase}/{name}: {len(runs)} cells; output_root {'EXISTS' if exists else 'new'}"
                + ("; smoke spec: ranges recorded, not compared with the batch cohort" if smoke else "")
                + (f"; problems: {'; '.join(bad)}" if bad else ""))
    with open(os.path.join(out, "specs.txt"), "w") as f:
        f.write("\n".join(lines) + "\n")


def run_pytest(args, env):
    proc = subprocess.run([sys.executable, "-m", "pytest", *args], cwd=ROOT, capture_output=True, text=True,
                          timeout=3600, env=env)
    return proc.returncode, proc.stdout, proc.stderr


def collection_errors(stdout):
    """{test file: missing module name or None} from pytest's 'ERROR collecting <file>' blocks."""
    parts = re.split(r"\n_+ ERROR collecting (\S+) _+\n", "\n" + stdout)  # one underscore each side when the path is long
    found = {}
    for i in range(1, len(parts) - 1, 2):
        body = parts[i + 1].split("\n====")[0]
        m = re.search(r"No module named '([\w.]+)'", body)
        found[parts[i]] = m.group(1) if m else None
    return found


@guarded("repository tests")
def check_tests(out):
    """Run the test folders in TEST_SUITES. A file not collected because an OPTIONAL package is missing is WARN by
    name and never counted as passed; any other failure or collection error is FAIL (a required suite that cannot
    import cannot be counted as passed or skipped into readiness)."""
    if importlib.util.find_spec("pytest") is None:
        required("pytest", f"pytest is not installed: the repository tests cannot run; {pip_line('pytest')}")
        return
    suites = []
    for rel, kind in TEST_SUITES:
        if os.path.isdir(os.path.join(ROOT, rel)):
            suites.append(rel)
        else:
            say("FAIL" if kind == "required" else "WARN", f"test folder {rel} is missing")
    if not suites:
        return
    env = dict(os.environ)
    if subprocess.run([sys.executable, "-c", "import pytorch_tabular"], cwd=ROOT, capture_output=True).returncode:
        env["PYTHONPATH"] = os.pathsep.join([os.path.join(ROOT, "src"), ROOT] + ([env["PYTHONPATH"]] if env.get("PYTHONPATH") else []))
    rc, stdout, stderr = run_pytest(["-q", "-rfs", "-p", "no:cacheprovider", "--continue-on-collection-errors", *suites], env)
    with open(os.path.join(out, "pytest.txt"), "w") as f:  # the full test output
        f.write(stdout[-20000:] + "\n" + stderr[-5000:])
    not_collected = 0
    for file, missing in sorted(collection_errors(stdout).items()):
        top = (missing or "").split(".")[0]
        if top and (top in OPTIONAL_MISSING or top in OPTIONAL_PACKAGES):
            not_collected += 1
            say("WARN", f"not collected: {file}, needs {top} ({OPTIONAL_MISSING.get(top) or pip_line(top)}); its tests "
                        "are not counted as passed")
        else:
            say("FAIL", f"not collected: {file}" + (f", missing module {missing}" if missing
                                                     else " (collection error; details in pytest.txt)"))
    tail = [l for l in stdout.strip().splitlines() if re.search(r"\d+ (passed|failed|error|skipped)", l)]
    summary = tail[-1] if tail else ""
    counts = {k.rstrip("s"): int(n) for n, k in re.findall(r"(\d+) (passed|failed|skipped|errors?)\b", summary)}
    failed, errors = counts.get("failed", 0), counts.get("error", 0)
    ok = bool(summary) and not failed and errors == not_collected and (rc == 0 or errors)
    say("PASS" if ok else "FAIL",
        f"repository tests ({', '.join(suites)}): {summary or 'no summary (pytest exit ' + str(rc) + ')'}"
        + (f"; {not_collected} file(s) not collected for a missing optional package (WARN above), not counted as "
           f"passed" if not_collected else ""))


def predictor_list(cfg, fs):
    from fraud.data.feature_list import load_feature_list
    csv_path = str(cfg.predictors.csv_path)
    return load_feature_list(csv_path if csv_path.startswith(("s3://", "s3a://")) else os.path.join(ROOT, csv_path),
                             version=cfg.predictors.get("version"), filesystem=fs)


@guarded("feature coverage")
def check_feature_coverage(out, fs, cfg, splits, max_files=3):
    """Per split (first max_files files): missing rate of every predictor's raw source and, for categorical
    predictors, the share of values the frozen vocabulary does not know (UNK). Aggregates only."""
    import numpy as np
    import pyarrow.parquet as pq
    from fraud.data.datetime_features import DatetimeConfig, derive_datetime_features
    from fraud.data.preprocessing import PreprocessingArtifacts
    from fraud.data.s3_utils import strip_scheme
    feats = predictor_list(cfg, fs)
    arts = PreprocessingArtifacts.load(f"{str(cfg.artifacts.base).rstrip('/')}/{cfg.artifacts.version}", filesystem=fs)
    dt = DatetimeConfig(order_col=cfg.data.order_col, fields=list(cfg.datetime.fields),
                        encoding=cfg.datetime.encoding, is_weekend=cfg.datetime.is_weekend)
    cols = list(feats.raw_source_columns())
    # Like the runtime loaders: calendar fields only when a selected predictor is derived, from the configured column.
    if feats.derived and dt.order_col not in cols:
        cols.append(dt.order_col)
    recorded = getattr(arts, "fit_files", None)
    fit_names = {posixpath.basename(x.strip().rstrip("/")) for x in recorded
                 if isinstance(x, str) and x.strip()} if isinstance(recorded, list) else set()
    samples = {}
    for split, files in splits.items():
        samples[split] = files[:max_files]
        if split.startswith("train_"):
            outside = [p for p in files if posixpath.basename(p) not in fit_names] if fit_names else []
            if outside:  # the last files outside the fit subset: values the vocabularies were not fit on
                samples[f"{split}_outside_fit"] = outside[-max_files:]
            else:
                say("INFO", f"{split}: no training file outside the artifacts' recorded fit files"
                            + ("" if fit_names else " could be identified (fit files not recorded)"))
    report = {"sample_scope": f"first {max_files} file(s) of each split, plus the last {max_files} training file(s) "
                              "outside the artifacts' recorded fit files when they can be identified; counts are over "
                              "those files only, not the whole split"}
    for split, files in samples.items():
        n, miss, unk = 0, {}, {}
        for path in files:
            df = pq.ParquetDataset(strip_scheme(path), filesystem=fs).read(columns=cols).to_pandas()
            if feats.derived:
                df, _, _ = derive_datetime_features(df, dt)
            n += len(df)
            for c in feats.continuous:
                miss[c] = miss.get(c, 0) + int(df[c].isna().sum())
            for c in feats.categorical:
                miss[c] = miss.get(c, 0) + int(df[c].isna().sum())
                codes = arts.encode_categorical(c, df[c])
                unk[c] = unk.get(c, 0) + int((codes == 0).sum())
        report[split] = {"rows_checked": n, "files_checked": len(files),
                         "missing_rate": {c: v / max(n, 1) for c, v in miss.items()},
                         "unknown_category_rate": {c: v / max(n, 1) for c, v in unk.items()}}
        top = sorted(report[split]["unknown_category_rate"].items(), key=lambda kv: -kv[1])[:3]
        topm = sorted(report[split]["missing_rate"].items(), key=lambda kv: -kv[1])[:3]
        say("INFO", f"{split} ({report[split]['files_checked']} files): highest UNK " +
            ", ".join(f"{k} {100 * v:.2f}%" for k, v in top) + "; highest missing " +
            ", ".join(f"{k} {100 * v:.2f}%" for k, v in topm))
    with open(os.path.join(out, "feature_coverage.json"), "w") as f:
        json.dump(report, f, indent=2)


def s3_and_files():
    from fraud.data.s3_utils import build_file_list, make_s3_filesystem
    cfg = probe_config()
    fs = make_s3_filesystem(cfg.s3.cred_path)
    d, e = cfg.data, cfg.eval
    splits = {
        f"train_{d.train_start}_{d.train_end}": build_file_list(d.train_base, d.train_start, d.train_end),
        f"valid_{d.val_start}_{d.val_end}": build_file_list(d.val_base, d.val_start, d.val_end),
        f"eval_{e.file_start}_{e.file_end}": build_file_list(e.base, e.file_start, e.file_end),
    }
    return cfg, fs, splits


def runtime_ready(entry, ftype):
    """The fields the runtime reads for one predictor exist with usable values (preprocessing.py standardize /
    encode, parquet_loader.py cardinality): finite mean/median and positive std, or category indices < cardinality."""
    if not isinstance(entry, dict) or entry.get("type") != ftype:
        return False
    if ftype == "continuous":
        stats = [entry.get(k) for k in ("mean", "std", "median")]
        return all(isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) for v in stats) \
            and stats[1] > 0
    card, vocab = entry.get("cardinality"), entry.get("vocab")
    idx = [entry.get("unk_index"), entry.get("missing_index")] + (list(vocab.values()) if isinstance(vocab, dict) else [None])
    return isinstance(card, int) and all(isinstance(i, int) and 0 <= i < card for i in idx)


def fit_provenance(fit_files, held_out):
    """Compare recorded artifact fit files with held-out files after normalizing scheme and path syntax.
    Returns (overlap, unresolved): fit entries that ARE held-out files, and entries that cannot be told apart
    from one because the record lacks the prefix (a bare file name or partial path matching a held-out path's
    tail). Nothing is inferred from part numbers."""
    from fraud.data.s3_utils import strip_scheme

    def norm(p):
        return posixpath.normpath(strip_scheme(str(p).strip()))
    held = {norm(p) for p in held_out}
    overlap, unresolved = [], []
    for f in fit_files:
        p = norm(f)
        if not str(f).strip() or p in (".", "/") or str(f).strip().endswith("/") or any(h.startswith(p + "/") for h in held):
            unresolved.append(p)  # names no file, or a folder that holds held-out files
        elif p in held:
            overlap.append(p)
        elif any(h.endswith("/" + p) or p.endswith("/" + h) for h in held):
            unresolved.append(p)
    return overlap, unresolved


@guarded("artifacts")
def check_artifacts(out, fs, cfg):
    """The configured (active) artifact version must load through the runtime loader, hold every predictor with
    the type and statistics the runtime reads, and not be fit on this cohort's validation or evaluation files.
    The REFERENCE_ID copy is optional and only compared."""
    from fraud.data.preprocessing import PreprocessingArtifacts
    from fraud.data.s3_utils import build_file_list, strip_scheme
    base = str(cfg.artifacts.base).rstrip("/")
    active = f"{base}/{cfg.artifacts.version}"
    other = base.replace("YOUR_ID", "REFERENCE_ID")
    predictors = predictor_list(cfg, fs)
    lines = ["per-file sha256 with CRLF normalized to LF; the content sha256 of a prefix is one combined digest over the "
             "feature files the manifest names, in sorted order; manifest.json is outside it and listed with its own digest"]
    digests = {}
    for b in dict.fromkeys([base, other]):
        root = f"{strip_scheme(b)}/{cfg.artifacts.version}"
        is_active = b == base
        try:
            with fs.open(f"{root}/manifest.json", "rb") as f:
                man_bytes = f.read().replace(b"\r\n", b"\n")
            man = json.loads(man_bytes)
            arts = PreprocessingArtifacts.load(active, filesystem=fs) if is_active else None
        except Exception as exc:
            if is_active:
                say("FAIL", f"active artifacts {active}: not loadable by the runtime loader ({type(exc).__name__})")
            else:
                lines.append(f"{b}/{cfg.artifacts.version}: not readable ({type(exc).__name__}); comparison skipped")
            continue
        feats = list(man.get("features", []))
        h = hashlib.sha256()
        unreadable = []
        # One digest line per file the runtime loader reads, beside the combined digest (S1-03). manifest.json stays
        # outside the combined digest so its created date does not change the artifact identity.
        per_file = [f"  manifest.json sha256 {hashlib.sha256(man_bytes).hexdigest()} ({len(man_bytes)} bytes)"]
        for name in sorted(feats):
            try:
                with fs.open(f"{root}/feature__{name}.json", "rb") as f:
                    data = f.read().replace(b"\r\n", b"\n")
                h.update(len(name).to_bytes(4, "big") + name.encode() + len(data).to_bytes(8, "big") + data)
                per_file.append(f"  feature__{name}.json sha256 {hashlib.sha256(data).hexdigest()} ({len(data)} bytes)")
            except Exception as exc:
                unreadable.append(f"{name}:{type(exc).__name__}")
                per_file.append(f"  feature__{name}.json unreadable ({type(exc).__name__})")
        digests[b] = h.hexdigest()
        lines.append(f"{b}/{cfg.artifacts.version}: {len(feats)} features, fit_files {man.get('fit_files')}, "
                     f"created {man.get('created')}, artifact_version {man.get('artifact_version')}, "
                     f"content sha256 {digests[b]}")
        lines += per_file
        if is_active:
            # Every predictor, in the runtime's input order, with the type and statistics the runtime reads.
            expected = [(c, "continuous") for c in predictors.continuous] + [(c, "categorical") for c in predictors.categorical]
            bad = [c for c, t in expected if not runtime_ready(arts.features.get(c), t)]
            say("FAIL" if bad or unreadable else "PASS",
                f"active artifacts {active}: loaded by the runtime loader; {len(expected)} predictors, {len(bad)} "
                f"missing or unusable{' (' + ', '.join(bad[:5]) + ')' if bad else ''}, sha256 {digests[b][:12]}")
            fit = man.get("fit_files")
            held = (build_file_list(cfg.data.val_base, cfg.data.val_start, cfg.data.val_end)
                    + build_file_list(cfg.eval.base, cfg.eval.file_start, cfg.eval.file_end))
            if not isinstance(fit, list) or not fit or not all(isinstance(x, str) for x in fit):
                say("WARN", "active artifacts: unresolved fit provenance (manifest fit_files missing or not a list of files)")
            else:
                overlap, unresolved = fit_provenance(fit, held)
                if overlap:
                    say("FAIL", f"active artifacts were fit on {len(overlap)} of this cohort's validation/evaluation files")
                elif unresolved:
                    say("WARN", f"active artifacts: unresolved fit provenance ({len(unresolved)} of {len(fit)} fit "
                                "entries are blank, a folder, or a validation/evaluation file name without its prefix)")
                else:
                    say("PASS", f"active artifacts fit on {len(fit)} files, none of them this cohort's "
                                f"{len(held)} validation/evaluation files")
        else:
            say("INFO", f"comparison artifacts {b}/{cfg.artifacts.version}: {len(feats)} features, sha256 {digests[b][:12]}")
    with open(os.path.join(out, "artifacts.txt"), "w") as f:
        f.write("\n".join(lines) + "\n")
    if len(digests) == 2:
        same = len(set(digests.values())) == 1
        say("INFO", f"YOUR_ID and REFERENCE_ID artifact contents are {'identical' if same else 'DIFFERENT'}")


def inexact_float_ids(ids):
    """Rows whose float transaction id cannot carry an exact integer identity: fractional, or at/above 2**53
    (where neighbouring integers share one float). Missing ids are counted separately."""
    import numpy as np
    import pandas as pd
    if pd.api.types.is_float_dtype(ids.dtype):
        v = ids.dropna().to_numpy(dtype=float)
    elif pd.api.types.is_object_dtype(ids.dtype):
        v = np.array([x for x in ids.dropna() if isinstance(x, (float, np.floating))], dtype=float)
    else:
        return 0
    return int(((np.abs(v) >= 2.0 ** 53) | (v != np.floor(v))).sum())


@guarded("data contract")
def check_data(out, fs, cfg, splits, hist_lens=(5, 10, 15, 20)):
    import numpy as np
    import pandas as pd
    import pyarrow.parquet as pq
    from YOUR_PACKAGE.base.data.input_contracts import encode_binary_target, parse_required_timestamps, require_account_ids
    from fraud.data.s3_utils import strip_scheme
    acct, tcol, ycol, idcol = cfg.data.account_col, cfg.data.order_col, cfg.data.target_col, cfg.data.tie_break_col
    pos_label = cfg.data.get("positive_label", 1)
    result, acct_sets, id_sets = {}, {}, {}
    schemas = {}  # split -> (file name, ["column: type", ...]) of the split's first file
    for split, files in splits.items():
        per_file, acct_file_counts = [], {}
        tmin, tmax, ties, rows_total, pos_total = None, None, 0, 0, 0
        labels, label_dtypes, observed = {"positive": 0, "other": 0, "missing": 0}, set(), {}
        rejected, null_accts, id_hashes = {}, 0, []
        fraud_per_acct = {}
        depth = {h: 0 for h in hist_lens}
        strict_depth = {h: 0 for h in hist_lens}
        ties_whole_second, pos_in_ties = 0, 0
        precision = {"rows_with_time": 0, "rows_with_nonzero_sub_second": 0, "rows_with_nonzero_seconds": 0,
                     "rows_with_nonzero_minutes": 0}
        id_hash = hashlib.sha256()

        def reject(check, rows=None):  # counts only: the runtime's messages can quote data values
            r = rejected.setdefault(check, {"files": 0, "rows": None if rows is None else 0})
            r["files"] += 1
            if rows is not None:
                r["rows"] += rows

        for path in files:
            p = strip_scheme(path)
            if split not in schemas:
                sch = pq.read_schema(fs.open(p, "rb"))
                schemas[split] = (os.path.basename(p), [(n, str(t)) for n, t in zip(sch.names, sch.types)])
            df = pq.ParquetDataset(p, filesystem=fs).read(columns=[acct, tcol, ycol, idcol]).to_pandas()
            # Required inputs, checked BEFORE ids are turned into strings and hashed, with the runtime loaders' own
            # contracts (YOUR_PACKAGE/base/data/input_contracts.py): a file the runtime would reject FAILs here too.
            n = int(df[idcol].isna().sum())
            if n:
                reject("missing transaction ids", n)
            n = inexact_float_ids(df[idcol])
            if n:
                reject("inexact float transaction ids (fractional or >= 2**53)", n)
            try:  # declared positive class versus every other observed, nonmissing label; one-class files are valid
                y = encode_binary_target(df[ycol], pos_label, ycol).astype(bool)
            except ValueError:
                reject("missing labels", int(df[ycol].isna().sum()))
                y = df[ycol].eq(pos_label).to_numpy(dtype=bool)
            try:
                require_account_ids(df[acct], acct)
            except ValueError:
                reject("missing account ids", int(df[acct].isna().sum()))
            try:  # rejects missing, unparseable and mixed-timezone times, and numbers without an explicit unit
                t = parse_required_timestamps(df[tcol], tcol)
            except ValueError:
                reject("event times the runtime parser rejects")
                t = pd.Series(pd.NaT, index=df.index, dtype="datetime64[ns]")
            npos, nmiss = int(y.sum()), int(df[ycol].isna().sum())
            labels["positive"] += npos
            labels["missing"] += nmiss
            labels["other"] += len(df) - npos - nmiss
            label_dtypes.add(str(df[ycol].dtype))
            for v, c in df[ycol].value_counts(dropna=True).items():
                observed[v] = observed.get(v, 0) + int(c)
            null_accts += int(df[acct].isna().sum())
            for a, c in df.loc[y, acct].value_counts().items():
                fraud_per_acct[a] = fraud_per_acct.get(a, 0) + int(c)
            # 64-bit row hashes of the composite identity (account, transaction id), framed by pandas per column
            id_hashes.append(pd.util.hash_pandas_object(df[[acct, idcol]].astype(str), index=False).to_numpy())
            n, nat = len(df), int(t.isna().sum())
            rows_total += n
            pos_total += npos
            fmin, fmax = t.min(), t.max()
            if nat < n:
                tmin = fmin if tmin is None or fmin < tmin else tmin
                tmax = fmax if tmax is None or fmax > tmax else tmax
            g = df.assign(_t=t, _y=y).sort_values([acct, "_t", idcol], kind="stable")
            pos_in_acct = g.groupby(acct, sort=False).cumcount().to_numpy()
            # Strictly earlier rows: the preceding rows minus those sharing the target's own timestamp (what the
            # strict history rule admits; the preceding-row count may include equal timestamps).
            in_tie_group = g.groupby([acct, "_t"], sort=False, dropna=False).cumcount().to_numpy()
            strictly_earlier = pos_in_acct - in_tie_group
            for h in hist_lens:
                depth[h] += int((pos_in_acct >= h).sum())
                strict_depth[h] += int((strictly_earlier >= h).sum())
            tied = g.duplicated([acct, "_t"], keep=False)
            ties += int(tied.sum())
            pos_in_ties += int(g.loc[tied, "_y"].sum())  # frauds inside equal-time groups (R-007: the tie rate alone does not settle it)
            # OQ-13 part 2, the observed granularity of the stored times, read from the data: how many parsed times carry a nonzero
            # sub-second, seconds or minutes part, and the tie count at whole seconds, the resolution the A and B
            # builders cut time to for the gap feature (datetime64[s] in sequence_builder.py). Counts only.
            tv = t[t.notna()]
            precision["rows_with_time"] += int(len(tv))
            precision["rows_with_nonzero_sub_second"] += int(((tv.dt.microsecond != 0) | (tv.dt.nanosecond != 0)).sum())
            precision["rows_with_nonzero_seconds"] += int((tv.dt.second != 0).sum())
            precision["rows_with_nonzero_minutes"] += int((tv.dt.minute != 0).sum())
            ties_whole_second += int(g.assign(_s=g["_t"].dt.floor("s")).duplicated([acct, "_s"], keep=False).sum())
            for a in pd.unique(df[acct]):
                acct_file_counts[a] = acct_file_counts.get(a, 0) + 1
            per_file.append({"file": os.path.basename(p), "rows": n, "positives": npos, "nat_times": nat,
                             "accounts": int(df[acct].nunique()), "min_time": str(fmin), "max_time": str(fmax)})
        acct_sets[split] = set(acct_file_counts)
        multi = sum(1 for c in acct_file_counts.values() if c > 1)
        all_ids = np.sort(np.concatenate(id_hashes)) if id_hashes else np.array([], dtype=np.uint64)
        id_sets[split] = np.unique(all_ids)
        dup_ids = int(len(all_ids) - len(np.unique(all_ids)))
        # Canonical multiset digest: independent of file order and partitioning, keeps multiplicity.
        id_hash.update(b"composite-id-uint64-multiset-v1" + len(all_ids).to_bytes(8, "big") + all_ids.astype(">u8").tobytes())
        other_classes = sum(1 for v in observed if not v == pos_label)
        # Observed label values with counts go to their own file, not to SUMMARY.txt or the JSON.
        with open(os.path.join(out, "label_values.txt"), "a") as f:
            f.write("".join(f"{split}\t{v!r}\t{c}\n" for v, c in sorted(observed.items(), key=lambda kv: -kv[1])))
        result[split] = {
            "files": per_file, "rows": rows_total, "positives": pos_total,
            "fraud_rate": pos_total / max(rows_total, 1), "min_time": str(tmin), "max_time": str(tmax),
            "accounts": len(acct_file_counts), "accounts_in_more_than_one_file": multi,
            "rows_in_equal_time_groups_within_account": ties,
            "positives_in_equal_time_groups_within_account": pos_in_ties,
            "rows_in_equal_whole_second_groups_within_account": ties_whole_second,
            "timestamp_precision": precision,
            "timestamp_precision_note": "counts over rows with a parsed time (OQ-13 part 2); no nonzero sub-second part "
                                        "means the stored times are at whole seconds, no nonzero seconds part and no "
                                        "nonzero sub-second part means whole minutes, which inflates ties, and so on: "
                                        "the observed granularity of the stored values, not the source clock and not "
                                        "arrival order; the whole-second "
                                        "tie count is at the resolution the builders cut time to for the gap feature",
            "rows_with_at_least_h_prior_rows_in_same_file": depth,
            "rows_with_at_least_h_strictly_earlier_rows_in_same_file": strict_depth,
            "history_depth_note": "prior rows = preceding rows of the same account in the same file in (time, id) "
                                  "order, which may include equal timestamps; strictly earlier = rows of the same "
                                  "account with time strictly before the target's, what the strict history rule "
                                  "admits; both capped at each configured history length",
            "composite_id_multiset_sha256": id_hash.hexdigest(),
            "composite_id_digest_version": 1,
            "composite_id_digest_note": "sha256 over the sorted multiset of 64-bit pandas row hashes of (account, "
                                        "transaction id) as strings; independent of file order and partitioning; "
                                        "duplicates kept; 64-bit row hashes can collide, so equal digests are strong "
                                        "evidence, not proof, of the same cohort",
            "label_counts": labels, "label_other_classes": other_classes, "label_dtypes": sorted(label_dtypes),
            "positive_label_type": type(pos_label).__name__, "input_contract_rejections": rejected,
            "null_account_rows": null_accts, "duplicate_transaction_ids": dup_ids,
            "accounts_with_fraud": len(fraud_per_acct),
            "frauds_per_fraud_account": ({"median": float(np.median(list(fraud_per_acct.values()))),
                                          "p90": float(np.percentile(list(fraud_per_acct.values()), 90)),
                                          "max": int(max(fraud_per_acct.values()))} if fraud_per_acct else None),
        }
        r = result[split]
        say("INFO", f"{split}: {r['rows']:,} rows, {r['positives']:,} pos ({100 * r['fraud_rate']:.4f}%), "
                    f"{r['accounts']:,} accts, {r['min_time'][:16]} to {r['max_time'][:16]}, id digest "
                    f"{r['composite_id_multiset_sha256'][:12]}")
        fpa = r["frauds_per_fraud_account"] or {}
        say("INFO", f"   fraud accounts {r['accounts_with_fraud']:,} (frauds per fraud account median "
                    f"{fpa.get('median', '-')}, p90 {fpa.get('p90', '-')}, max {fpa.get('max', '-')})")
        say("INFO", f"   accts in >1 file {multi:,}; equal-time rows {ties:,} (exact; {pos_in_ties:,} of them positive), "
                    f"{ties_whole_second:,} at whole seconds; full history h5/h10/h15/h20: "
                    + "/".join(f"{100 * depth[h] / max(rows_total, 1):.1f}%" for h in hist_lens)
                    + " (preceding rows, may include equal timestamps); strictly earlier: "
                    + "/".join(f"{100 * strict_depth[h] / max(rows_total, 1):.1f}%" for h in hist_lens)
                    + " (what the strict rule admits)")
        p = r["timestamp_precision"]
        say("INFO", f"   timestamp precision (OQ-13 part 2), of {p['rows_with_time']:,} timed rows: nonzero sub-second part "
                    f"{p['rows_with_nonzero_sub_second']:,}, nonzero seconds part {p['rows_with_nonzero_seconds']:,}, "
                    f"nonzero minutes part {p['rows_with_nonzero_minutes']:,}; none with a sub-second part means the stored "
                    "times are at whole seconds, none with a seconds or sub-second part means whole minutes, which "
                    "inflates ties "
                    "(observed granularity of the stored values, not the source clock and not arrival order)")
        if rejected:
            say("FAIL", f"   {split} inputs the runtime loaders reject: " + "; ".join(
                f"{k} in {v['files']} file(s)" + (f", {v['rows']:,} rows" if v["rows"] is not None else "")
                for k, v in rejected.items()))
        if dup_ids and split.startswith("eval_"):
            # The A and B scorers reject duplicate (transaction id, account) pairs among their predictions, so a
            # duplicated evaluation pair would stop scoring. 64-bit row hashes: a false alarm needs a hash collision.
            say("FAIL", f"   {split}: {dup_ids:,} duplicate (account, transaction id) rows; the scorers reject these")
        say("WARN" if (other_classes > 1 or dup_ids) else "PASS",
            f"   labels (dtype {'/'.join(sorted(label_dtypes))}, positive label {type(pos_label).__name__}): positive "
            f"{labels['positive']:,}, other {labels['other']:,} in {other_classes} class(es), missing "
            f"{labels['missing']:,}; null accounts {null_accts:,}; duplicate ids {dup_ids:,}")
        no_pos = [x["file"] for x in per_file if x["positives"] == 0]
        if no_pos:
            say("WARN", f"   files with no positives: {', '.join(no_pos)}")
    if schemas:  # column names and stored types only, no values: one file per split, compared across splits
        typed = {split: dict(cols) for split, (_, cols) in schemas.items()}
        every = sorted(set().union(*typed.values()))
        differ = [c for c in every if len({typed[s].get(c, "(absent)") for s in typed}) > 1]
        with open(os.path.join(out, "schema.txt"), "w") as f:
            for split, (fname, cols) in schemas.items():
                f.write(f"[{split}] {fname}: {len(cols)} columns\n" + "".join(f"  {n}: {t}\n" for n, t in cols))
            f.write(f"\nCOLUMNS WHOSE TYPE OR PRESENCE DIFFERS BETWEEN SPLITS ({len(differ)})\n")
            f.write("".join(f"  {c}: " + ", ".join(f"{s}={typed[s].get(c, '(absent)')}" for s in typed) + "\n"
                            for c in differ))
        result["schema"] = {s: {"file": fname, "columns": len(cols)} for s, (fname, cols) in schemas.items()}
        result["schema"]["differing_columns"] = differ
        say("WARN" if differ else "PASS", f"column schema of one file per split ({len(schemas)} splits): "
            + (f"{len(differ)} column(s) differ in type or presence (schema.txt)" if differ
               else f"identical, {len(every)} columns (schema.txt)"))
        for c in differ[:8]:
            say("    ", f"{c}: " + ", ".join(f"{s}={typed[s].get(c, '(absent)')}" for s in typed))
        if len(differ) > 8:
            say("    ", f"... {len(differ) - 8} more in schema.txt")
    names = list(acct_sets)
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            ov = len(acct_sets[names[i]] & acct_sets[names[j]])
            result.setdefault("account_overlap", {})[f"{names[i]}&{names[j]}"] = ov
            # Composite transaction identities (account, transaction id) present in both splits: a repeated target
            # transaction, which account overlap alone does not show. Distinct identities, 64-bit row hashes.
            shared = int(len(np.intersect1d(id_sets[names[i]], id_sets[names[j]], assume_unique=True)))
            result.setdefault("composite_id_overlap", {})[f"{names[i]}&{names[j]}"] = shared
            say("INFO", f"accounts shared by {names[i]} and {names[j]}: {ov:,}; composite transaction identities "
                        f"(account, transaction id) in both: {shared:,}")
    if "composite_id_overlap" in result:
        result["composite_id_overlap_note"] = ("distinct (account, transaction id) identities present in both splits, "
                                               "counted over 64-bit row hashes; account overlap is a different property; "
                                               "the count depends on the account and transaction id columns having the "
                                               "same stored type in both splits (compare with schema.txt): differing "
                                               "stored id types undercount the overlap")
    with open(os.path.join(out, "data_contract.json"), "w") as f:
        json.dump(result, f, indent=2, default=str)


def current_user():
    """The login name for the SUMMARY header; getpass reads the environment and then the password database (F9)."""
    try:
        return getpass.getuser()
    except Exception:
        return "?"


def write_summary(out, code):
    """SUMMARY.txt with the RESULT line last; written even after a crash so the folder can always be sent."""
    overrides = ", ".join(dict.fromkeys(OVERRIDES_USED)) or "none"
    verdict = "PASS" if code == 0 else "FAIL"
    say("INFO", f"result: {len(FAILS)} FAIL, {len(WARNS)} WARN | overrides used: {overrides} | folder "
                f"{os.path.relpath(out, ROOT)}")
    for line in CLOSING_LINES:  # fixed wording, no check behind them; the RESULT line stays last
        say("INFO", line)
    LINES.append(f"RESULT {verdict} | {len(FAILS)} FAIL, {len(WARNS)} WARN | overrides: {overrides} | exit {code}")
    with open(os.path.join(out, "SUMMARY.txt"), "w") as f:
        f.write("\n".join(LINES) + "\n")
    print(LINES[-1])
    print(f"PREFLIGHT_DIR={out}")


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-data", action="store_true", help="static checks only; no S3 reads")
    ap.add_argument("--skip-tests", action="store_true", help="do not run the repository tests")
    ap.add_argument("--accept-source-diff", action="store_true",
                    help="report runtime source differences as WARN instead of FAIL (only after review; recorded in "
                         "SUMMARY.txt as the override accept-source-diff)")
    ap.add_argument("--allow-warn-only", action="append", default=[], choices=OVERRIDE_CHECKS, metavar="CHECK",
                    help="let this required check WARN instead of FAIL (one of: " + ", ".join(OVERRIDE_CHECKS)
                         + "; repeatable; only on review advice; recorded in SUMMARY.txt)")
    ap.add_argument("--out-root", default=os.path.join(ROOT, "runs", "preflight"))
    args = ap.parse_args(argv)
    global ACCEPT_SOURCE_DIFF
    ACCEPT_SOURCE_DIFF = args.accept_source_diff
    ALLOW_WARN_ONLY.clear()
    ALLOW_WARN_ONLY.update(args.allow_warn_only)
    stamp = _dt.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    out = os.path.abspath(os.path.join(args.out_root, stamp))  # PREFLIGHT_DIR is absolute whatever --out-root is (F4)
    try:
        os.makedirs(out, exist_ok=True)
    except OSError as exc:  # no folder, so no SUMMARY.txt and no RESULT line: exit 2, "could not run" (F10)
        print(f"FAIL  cannot create the output folder {out}: {type(exc).__name__}", file=sys.stderr)
        sys.exit(2)
    code = 2
    try:
        profile = "synthetic harness" if synthetic_profile() else "bank"
        say("INFO", f"pre-flight {stamp} | repo {ROOT} | user {current_user()} | profile {profile} | "
                    f"flags {' '.join(sys.argv[1:] if argv is None else argv) or '(none)'}")
        requested = [f"--allow-warn-only {', '.join(sorted(ALLOW_WARN_ONLY))}"] if ALLOW_WARN_ONLY else []
        if ACCEPT_SOURCE_DIFF:
            requested.append("--accept-source-diff")
        if requested:
            say("WARN", f"overrides requested: {', '.join(requested)} (each use is listed below as OVERRIDE)")
        check_environment(out)
        check_profile(out)
        check_dependencies(out)
        check_source(out)
        check_imports(out)
        check_credentials(out)
        check_specs(out)
        if not args.skip_tests:
            check_tests(out)
        if not args.skip_data:
            try:
                cfg, fs, splits = s3_and_files()
            except Exception as exc:
                with open(os.path.join(out, "errors.txt"), "a") as f:  # class and masked first line only
                    f.write(f"== S3 setup\n{type(exc).__name__}: {masked_first_line(exc)}\n")
                say("FAIL", f"S3 setup: {type(exc).__name__} (the exception class and the first line of its message, "
                            "with paths and long numbers masked, are in errors.txt)")
            else:
                check_artifacts(out, fs, cfg)
                check_data(out, fs, cfg, splits)
                check_feature_coverage(out, fs, cfg, splits)
        code = 1 if FAILS else 0
    except Exception as exc:  # a crash outside the guarded checks: still leave a complete folder with RESULT FAIL
        say("FAIL", f"pre-flight crashed: {type(exc).__name__} (traceback in errors.txt)")
        with open(os.path.join(out, "errors.txt"), "a") as f:
            f.write(f"== CRASH\n{traceback.format_exc()}\n")
        code = 2
    finally:
        write_summary(out, code)
    sys.exit(code)


if __name__ == "__main__":
    main()
