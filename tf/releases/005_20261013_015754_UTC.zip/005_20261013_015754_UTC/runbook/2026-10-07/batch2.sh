#!/usr/bin/env bash
# Batch 2 of the V1 study, one stage (reviewer, 2026-10-07; first release 2026-10-11; V1 rewrite 2026-10-12, build item
# B5 of bridge/plans/review/2026-10-12-v1-design/DESIGN_V1_AFTER_RUN001.md, section 2, stage 2 rows 2.0 to 2.11, cut to
# seed 42 by the owner's thirty-first message and numbered 2.0 to 2.8 here).
# Released only after reviewers have read batch 1's return with you. Run it from the batch 1 folder:
#     bash runbook/2026-10-07/batch2.sh                     (PYTHON=<interpreter> to name it; default python3)
# Only when the release note says so (batch 2 unzipped into a new folder), name batch 1's ledger and return folder:
#     BATCH1_LEDGER=<batch 1 folder>/runs/run_log.csv      default runs/run_log.csv
#     BATCH1_RETURN=<batch 1 folder>/runs/returns/batch1_<time>   default the newest runs/returns/batch1_*/
# Resume after a stop:   BATCH2_RESUME=runs/returns/batch2_<time> bash runbook/2026-10-07/batch2.sh
#     Steps whose RETURN.txt in that folder says ACCEPTED are skipped; an interrupted step is recorded (its attempt
#     folder is collected into the ledger, never reused) and runs again in a new attempt folder; the post-hoc scoring
#     is skipped when POST_SCORE.txt is already there; the same return folder keeps filling up.
# reviewer's test harness only (stops the launch unless RUNBOOK_BANK_OVERRIDES=1 is set; the pre-flight records that):
#     RUNBOOK_SANDBOX=<folder>, BATCH2_SKIP="<spec names>", PREFLIGHT_ARGS="<pre-flight flags>".
# Order: the batch 1 ledger check (R-009: the file exists and holds batch 1's runs, else nothing runs), the quick
# pre-flight without the repository tests (RESULT PASS required; anything else stops the batch before training), then the steps below, one GPU, one run at a
# time. Every run uses seed 42, reference's seed (owner, OWNER_QA thirty-first message: every V1 run uses seed 42 only;
# the seeds 43 and 44 files are kept for later and not run). Every sweep writes a NEW attempt folder
# <output_root>/<UTC>-<id>/ and never overwrites. Every step is scored on 8000-8010. GPU hours are assumed (design
# section 2, per run), except where marked measured; about 47.5 h in all, about 2 days on one GPU. 9 runs.
#   2.0  post-hoc scoring of batch 1's 3 validation-only checkpoints (A h0, A h5, A h10 gap off) on 8000-8010   0.3 h
#   2.1  ref_single.yaml                  REF-SINGLE: reference's single-transaction model, retrained on the same files  0.5 h
#   2.2  ft_decisions_hier_h0_scored.yaml B-H00: B at history 0                                                  0.5 h
#   2.3  ft_decisions_mask_causal.yaml    A-MASK05-C: A at history 5, causal attention mask                      2.0 h
#   2.4  ft_decisions_gap05_off.yaml      A-GAP05-OFF: A at history 5, time gap off                              2.0 h
#   2.5  ft_decisions_flat_h15.yaml       A-H15: A at history 15 (256 x 16) (measured 2026-10-06, older code)    9.7 h
#   2.6  ft_decisions_hier_long.yaml      B-H15 and B-H20 (2048 x 2)                                            12.5 h
#   2.7  ft_decisions_flat_h20.yaml       A-H20: A at history 20 (128 x 32)                                     17.0 h
#   2.8  ft_decisions_hier_allpos.yaml    B-ALLPOS-H5: all-position B, strict contract (own line)                3.0 h
# Not run in V1 (dropped from the design's stage 2 by the owner's thirty-first message): the A h5 same-seed repeat (it
# only measured run-to-run noise), B h5 seeds 43 and 44, A h10 seeds 43 and 44 with the gap on and off.
# Why this order: the cheapest and most-needed steps first, so the core comparisons arrive early: 2.0 to 2.4 (5.3 h)
# give the matched controls (reference parity, history 0 against 5 for B, the attention mask and the time gap at h5);
# then the long-history screens from the cheapest to the dearest (2.5, 2.6, 2.7). All-position B (2.8) runs last
# although it is cheap: it is its own line in no matched contrast, its chunk width is not yet measured on bank data,
# and running it last means it can be held or removed without moving any other step.
# The REF-SINGLE line (2.1) runs through run_step.py --phase base, built in lane L1 (build item B8).
# The A-H10 record (R-033): batch 1's comparator recorded in its return folder is checked again here and written to
# SHARED_COMPARATOR.txt and comparator_source_files.csv as a record only. No step of batch 2 depends on it; it shows
# whether the A and default-B code is unchanged between batch 1 and batch 2, which the contrasts spanning both
# batches need. Nothing is skipped or stopped because of it.
# The batch return folder runs/returns/batch2_<time>/ exists from the start and holds: BATCH_STATUS.txt (one line per
# event), preflight_<time>/ (the complete pre-flight copy), POST_SCORE.txt, post_score_results.csv and post_score/
# (step 2.0), steps/<spec>_<time>/ (every file of each step's return folder, its runner log and its memory samples),
# attempts/<attempt>/ (every file of each attempt folder but checkpoints and predictions), SHARED_COMPARATOR.txt and
# comparator_source_files.csv, and at the end RETURN.txt (every attempt of this batch, steps finished before a resume
# included) and run_log_batch2.csv (the batch's ledger rows). After an early stop it holds everything finished so far.
# Send: that folder, runs/run_log.csv and the console log. Only checkpoints (*.ckpt) and predictions (*.parquet) stay
# on the pod (the owner's answer to OQ-24).
set -uo pipefail
cd "$(dirname "$0")/../.."
HERE=runbook/2026-10-07
PY="${PYTHON:-python3}"

# Every file a step makes goes into the return, except model checkpoints (*.ckpt) and prediction files (*.parquet),
# which stay on the pod (the owner's answer to OQ-24, OWNER_QA thirtieth message).
copy_tree() {  # copy_tree <source folder> <destination folder>
  [ -d "$1" ] || return 0
  mkdir -p "$2"
  (cd "$1" && find . -type f ! -name '*.ckpt' ! -name '*.parquet' -print0) | while IFS= read -r -d '' f; do
    mkdir -p "$2/$(dirname "$f")" && cp -p "$1/$f" "$2/$f"
  done
}
copy_step_files() {  # copy_step_files <step return dir> <attempt dir or empty> <return folder>
  local ret="$1" dir="$2" out="$3" name runs
  [ -n "$ret" ] && [ -d "$ret" ] || return 0
  name=$(basename "$ret"); runs=$(dirname "$(dirname "$ret")")
  copy_tree "$ret" "$out/steps/$name"
  for f in "$runs/logs/$name.runner.log" "$runs/gpu/$name.csv" "$runs/gpu/$name.host_rss.csv"; do
    [ -f "$f" ] && cp -p "$f" "$out/steps/$name/"
  done
  [ -n "$dir" ] && copy_tree "$dir" "$out/attempts/$(basename "$dir")"
}

# Inherited harness state: these variables shrink or skip runs; in a bank shell they are a mistake unless said otherwise.
if [ "${RUNBOOK_BANK_OVERRIDES:-}" != "1" ]; then
  present=""
  for v in RUNBOOK_SANDBOX BATCH2_SKIP PREFLIGHT_ARGS; do [ -n "${!v:-}" ] && present="$present $v"; done
  if [ -n "$present" ]; then
    echo "STOPPED BEFORE START: set in this shell:$present. These belong to reviewer's test harness, not to a bank run (the sandbox"
    echo "setting shrinks every run to a one-epoch CPU model). Unset them and start again. Only on reviewer's or reviewer's"
    echo "advice, set RUNBOOK_BANK_OVERRIDES=1 to keep them; the pre-flight records that as an override. Nothing was run."
    exit 1
  fi
fi
SB="${RUNBOOK_SANDBOX:-}"
PF=runs/preflight; LEDGER=runs/run_log.csv; RET=runs/returns
[ -n "$SB" ] && { PF="$SB/preflight"; LEDGER="$SB/runs/run_log.csv"; RET="$SB/returns"; }
B1LEDGER="${BATCH1_LEDGER:-$LEDGER}"
SKIP=" ${BATCH2_SKIP:-} "
RESUME="${BATCH2_RESUME:-}"

# The batch return folder exists from the start (RG-F02), so "send the return folder" always works.
if [ -n "$RESUME" ]; then
  OUT="$RESUME"
  [ -f "$OUT/BATCH_STATUS.txt" ] || { echo "RESUME REFUSED: $OUT is not a batch 2 return folder (no BATCH_STATUS.txt). Nothing was run."; exit 1; }
else
  OUT=runs/returns/batch2_$(date -u +%Y%m%dT%H%M%SZ); [ -n "$SB" ] && OUT="$SB/returns/batch2_summary"
fi
mkdir -p "$OUT/steps" || { echo "cannot create the return folder $OUT; nothing was run"; exit 1; }
status() { echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) $*" >> "$OUT/BATCH_STATUS.txt"; }
status "batch 2 started: interpreter $PY; resume ${RESUME:-none}; batch 1 ledger $B1LEDGER; BATCH2_SKIP '${BATCH2_SKIP:-}'"
echo "batch return folder: $OUT (send this folder and $LEDGER when the batch ends or stops)"

# The batch 1 ledger first (R-009): step 2.0 scores batch 1's runs from it, so without it nothing starts.
if ! "$PY" "$HERE/batch_tools.py" batch1-ledger --ledger "$B1LEDGER"; then
  status "stopped: batch 1 ledger $B1LEDGER missing or without batch 1 runs"
  echo "BATCH 1 LEDGER NOT FOUND: nothing was run. Start batch 2 from the folder batch 1 ran in, or, if the release note"
  echo "says so, set BATCH1_LEDGER to batch 1's runs/run_log.csv. Send the folder $OUT/ if this is unexpected."
  exit 1
fi

# Pre-flight: exit 0, a RESULT PASS line in SUMMARY.txt and a data contract, or nothing is trained.
# The quick pre-flight, without the repository tests (owner, OWNER_QA forty-first and forty-second messages): batch 1
# of the same package folder ran them.
pfout=$("$PY" "$HERE/preflight_pod.py" --out-root "$PF" --skip-tests ${PREFLIGHT_ARGS:-} | tee >(cat >&2)); pfrc=$?
PFDIR=$(printf '%s\n' "$pfout" | sed -n 's/^PREFLIGHT_DIR=//p' | tail -1)
RESULT=""
if [ -n "$PFDIR" ] && [ -d "$PFDIR" ]; then
  PFCOPY="$OUT/preflight_$(basename "$PFDIR")"; mkdir -p "$PFCOPY"
  cp -rp "$PFDIR/." "$PFCOPY/"
  echo "pre-flight folder for this batch: $PFDIR (copied into $PFCOPY)"
  [ -f "$PFDIR/SUMMARY.txt" ] && RESULT=$(grep -E '^RESULT:? (PASS|FAIL)' "$PFDIR/SUMMARY.txt" | tail -1 | sed -E 's/^RESULT:? (PASS|FAIL).*/\1/')
fi
if [ $pfrc -ne 0 ] || [ "$RESULT" != "PASS" ] || [ ! -f "$PFDIR/data_contract.json" ]; then
  status "stopped at the pre-flight: exit $pfrc, RESULT ${RESULT:-line missing}, folder ${PFDIR:-not found}"
  echo "PRE-FLIGHT FAILED (exit $pfrc, RESULT ${RESULT:-line missing}): nothing was run. Send the folder $OUT/ (it holds the complete pre-flight copy)."
  exit 1
fi
echo "pre-flight RESULT PASS: scored runs are checked against its evaluation cohort"

failed=0; ATTEMPTS=()
# Step 2.0: post-hoc scoring of batch 1's validation-only checkpoints. On a resume it is skipped once a POST_SCORE.txt of
# this batch (in the return folder or a post_score_resume_* subfolder) ends with the scorer's clean line "no failures";
# an earlier start that failed or stopped half-way leaves files the scorer never overwrites, so it writes into a new
# subfolder instead (checkpoints scored and validated before are reused, not scored again).
PSDIR="$OUT"
ps_done=""
for f in "$OUT/POST_SCORE.txt" "$OUT"/post_score_resume_*/POST_SCORE.txt; do
  [ -f "$f" ] && [ "$(tail -1 "$f")" = "no failures" ] && ps_done="$f"
done
if [ -n "$RESUME" ] && [ -n "$ps_done" ]; then
  echo "== skipped the post-hoc scoring (step 2.0): finished without failures earlier in this batch ($ps_done)"
  status "resume: skipped the post-hoc scoring ($ps_done ends with no failures)"
else
  if [ -e "$OUT/POST_SCORE.txt" ] || [ -e "$OUT/post_score_results.csv" ] || [ -e "$OUT/post_score" ]; then
    PSDIR="$OUT/post_score_resume_$(date -u +%Y%m%dT%H%M%SZ)"
  fi
  echo "== step 2.0: post-hoc scoring of the validation-only runs in $B1LEDGER (return copy: $PSDIR)"
  status "started the post-hoc scoring into $PSDIR"
  "$PY" "$HERE/score_attempt.py" --from-ledger "$B1LEDGER" --preflight "$PFDIR" --return-dir "$PSDIR"; psrc=$?
  status "finished the post-hoc scoring: exit $psrc"
  [ $psrc -ne 0 ] && { echo "post-hoc scoring reported a problem; continuing"; failed=1; }
fi

# The A-H10 record (R-033), a record only: batch 1's comparator checked again against this checkout.
B1="${BATCH1_RETURN:-}"
if [ -z "$B1" ]; then
  if [ -n "$SB" ]; then B1="$SB/returns/batch1_summary"; else B1=$(ls -td "$RET"/batch1_*/ 2>/dev/null | head -1); B1="${B1%/}"; fi
fi
CAND=$([ -f "$B1/SHARED_COMPARATOR.txt" ] && sed -n 's/^A_H10_COMPARATOR=//p' "$B1/SHARED_COMPARATOR.txt" | head -1)
if [ -z "$CAND" ]; then
  echo "== record only: ${B1:-no batch 1 return folder} has no SHARED_COMPARATOR.txt, so no A-H10 source record is written"
  status "A-H10 record: none found in ${B1:-no batch 1 return folder} (record only; nothing depends on it)"
elif "$PY" "$HERE/batch_tools.py" comparator --attempt "$CAND" --phase phase4a --spec ft_decisions_flat_h10.yaml \
       ${SB:+--spec-file "$SB/specs/phase4a_ft_decisions_flat_h10.yaml"} --ledger "$B1LEDGER" \
       --record "$OUT/SHARED_COMPARATOR.txt" --files-out "$OUT/comparator_source_files.csv" \
       --origin batch1_return --batch-preflight "$PFDIR" \
       --used-by "record only (batch 2): whether the A and default-B code is unchanged since batch 1"; then
  status "A-H10 record: $CAND matches this checkout (from $B1; record only)"
else
  echo "== record only: batch 1's A-H10 differs from this checkout in the checks above; nothing is skipped because of it"
  status "A-H10 record: $CAND differs from this checkout (from $B1; record only; see SHARED_COMPARATOR.txt)"
fi

# One line per step, run in this order on one GPU. Each line is "<phase> <spec file>" and nothing else, so removing a
# step is deleting its line.
STEPS=(
  "base ref_single.yaml"                         # 2.1  REF-SINGLE
  "phase4b ft_decisions_hier_h0_scored.yaml"     # 2.2  B-H00
  "phase4a ft_decisions_mask_causal.yaml"        # 2.3  A-MASK05-C
  "phase4a ft_decisions_gap05_off.yaml"          # 2.4  A-GAP05-OFF
  "phase4a ft_decisions_flat_h15.yaml"           # 2.5  A-H15
  "phase4b ft_decisions_hier_long.yaml"          # 2.6  B-H15 and B-H20
  "phase4a ft_decisions_flat_h20.yaml"           # 2.7  A-H20
  "phase4b ft_decisions_hier_allpos.yaml"        # 2.8  B-ALLPOS-H5
)
for step in "${STEPS[@]}"; do
  set -- $step
  if [[ "$SKIP" == *" $2 "* ]]; then echo "== skipped $2 (BATCH2_SKIP)"; status "skipped $2 (BATCH2_SKIP)"; continue; fi
  if [ -n "$RESUME" ]; then
    state=$("$PY" "$HERE/batch_tools.py" resume-state --batch-dir "$OUT" --spec "$2")
    done_in=$(printf '%s\n' "$state" | sed -n 's/^finished_ok //p' | head -1)
    if [ -n "$done_in" ]; then
      echo "== skipped $2: finished and ACCEPTED earlier in this batch ($done_in)"; status "resume: skipped $2 (finished in $done_in)"
      a=$(sed -n 's/^attempt_dir: //p' "$done_in/STEP.txt" | tail -1); [ -n "$a" ] && [ -d "$a" ] && ATTEMPTS+=("$a")
      continue
    fi
    printf '%s\n' "$state" | sed -n 's/^interrupted //p' | while read -r att folder; do
      echo "== $2: an earlier start of this step was interrupted. Its attempt folder $att is recorded now and never reused;"
      echo "   the step runs again in a new attempt folder."
      # The interrupted run never reached the normal return-copy call. Recover its diagnostics before marking it collected.
      copy_step_files "$(dirname "$LEDGER")/returns/$(basename "$folder")" "$att" "$OUT"
      "$PY" "$HERE/collect_returns.py" "$att" --ledger "$LEDGER" --preflight "$PFDIR" --out "$folder/interrupted_collect"
      echo "interrupted_collected: $(date -u +%Y-%m-%dT%H:%M:%SZ) (interrupted_collect/RETURN.txt)" >> "$folder/STEP.txt"
      status "resume: interrupted attempt $att of $2 collected into the ledger (not reused)"
    done
  fi
  status "started $2"
  # Echo the step's output through the inherited stderr descriptor. `tee /dev/stderr` would reopen the console log and
  # truncate it on Linux, erasing everything printed before this step.
  out=$("$PY" "$HERE/run_step.py" --phase "$1" --spec "$2" --preflight "$PFDIR" --batch-dir "$OUT" | tee >(cat >&2)); rc=$?
  dir=$(printf '%s\n' "$out" | sed -n 's/^ATTEMPT_DIR=//p' | tail -1)
  ret=$(printf '%s\n' "$out" | sed -n 's/^RETURN_DIR=//p' | tail -1)
  [ -n "$dir" ] && ATTEMPTS+=("$dir")
  copy_step_files "$ret" "$dir" "$OUT"
  status "finished $2: run_step exit $rc; attempt ${dir:-none}; return ${ret:-none}"
  [ $rc -ne 0 ] && { echo "STEP $2: not all runs are ok (see its RETURN block above); continuing"; failed=1; }
done

echo; echo "===== BATCH 2 SUMMARY (send $OUT/ and $LEDGER) ====="
if [ ${#ATTEMPTS[@]} -gt 0 ]; then
  "$PY" "$HERE/collect_returns.py" --no-ledger --preflight "$PFDIR" --out "$OUT" "${ATTEMPTS[@]}" || failed=1
elif [ -z "$RESUME" ]; then
  echo "no attempt folders were created"; failed=1
else
  echo "no new attempt folders in this resume; the per-step RETURN.txt files under $OUT/steps/ are the record"
fi
"$PY" "$HERE/batch_tools.py" ledger-rows --ledger "$LEDGER" --out "$OUT/run_log_batch2.csv" --batch-dir "$OUT" ${ATTEMPTS[@]+"${ATTEMPTS[@]}"}
verdict=$([ $failed -eq 0 ] && echo 'all runs ok' || echo 'SOME RUNS NEED ATTENTION')
status "batch 2 finished: $verdict"
echo "Batch 2 finished: $verdict"
exit $failed
