#!/usr/bin/env python3
# Written by reviewer (2026-10-12), V1 build item B12 (bridge/plans/review/2026-10-12-v1-design/DESIGN_V1_AFTER_RUN001.md
# on main: section 3, the analysis plan, and section 4 row B12). CPU only. It reads prediction files where they are
# (on the pod) and writes aggregates only: no row, no identifier and no score of a single row is written.
"""Paired analysis of the V1 contrasts on whole-account draws (build item B12).

Usage on the pod after batch 2 (one command, from the repository root):

    PYTHONPATH=src:. python3 runbook/2026-10-07/paired_report.py --runs runs/paired_runs.csv \\
        --out-dir runs/paired_report --depth-matched B-ALLPOS-H5:B-H05,A-H05 --difference GAP-H10 GAP-H05

  V1 has no validation prediction files; the label reads each run's valid_ap (results.csv).
  Upload runs/paired_report/ (CSV files and paired_report.txt only).

The run table (CSV, one row per scored run and seed; the run table is assembled from the returned post-score folders):
    contrast,side,run,seed,prediction_path[,validation_path][,valid_ap]
    H05-VS-H00,x,A-H05,42,runs/.../post_score/<id>/predictions/part_0.parquet
    H05-VS-H00,y,A-H00,42,...
  contrast  the contrast name; side x or y (the contrast is X minus Y; one run name per side, any number of seeds).
            A row with an empty contrast and side loads a run used only by --depth-matched (all-position B).
  run, seed the model (run name) and its training seed; the same (run, seed) may appear in several contrasts.
  prediction_path  evaluation predictions (fi_transaction_id, Nmap_account_reference_xid, frd_tag, score), as written
            by YOUR_PACKAGE/phase4a/scripts/score_sequential.py and the phase4b one.
  validation_path  optional: the same columns scored on the validation files (score_attempt.py --split validation).
  valid_ap  optional: the run's best validation AP (results.csv); used for the validation seed signs only when the
            contrast has no validation predictions.

What it computes (DESIGN_V1 section 3; every number is an aggregate):
- Rows join the raw files on the composite id (transaction id plus account id) with temporal_eval's functions,
  which also give each target row's strictly-earlier same-account row count per file (history availability).
  Every run must hold exactly the same composite ids (the cohort) with the same labels. Duplicate ids, ids absent
  from the raw files, ids missing or extra against the cohort and label mismatches are counted per run; a contrast
  with any of them is marked "join mismatch" and gets no numbers. It is never dropped and the rows are never
  intersected away.
- Draws: whole accounts resampled with replacement, --draws draws from --seed, one joint set per split shared by
  every model, every contrast and every line (the draw sequence of leaderboard._paired_bootstrap_ci). A draw is a
  vector of account multiplicities; AP on a draw is AP with those row weights (equal to AP on the duplicated rows).
  95% percentile intervals; draws where a line has one class only are counted as undefined and left out.
- Per contrast, on all evaluation rows (and on validation when scored): rows, frauds, fraud rate, accounts, fraud
  accounts, the share of rows with at least H strictly-earlier rows, AP and AUROC per side
  (mean over seeds, and per seed), the difference (mean of X seeds minus mean of Y seeds, which is the mean of the
  per-seed differences when the seeds match) and its interval.
- Labels, reviewer's S1 rule: "consistent positive" when every validation seed difference is above zero and the
  overall evaluation interval (shared draws) lies wholly above zero, and the overall validation interval too when
  validation is scored; "consistent negative" mirrored; otherwise "not resolved", named "not resolved: direction
  disagreement" when every validation seed points one way and the evaluation interval excludes zero on the other
  side; "not resolved (no validation)" when there are neither validation predictions nor valid_ap, and "not
  resolved (validation incomplete)" when only part of the contrast's runs have validation predictions. A zero
  difference has neither sign. V1 runs seed 42 only (owner, OWNER_QA thirty-first message): a
  contrast is one run against one run, the rule reads its one validation difference, and direction disagreement
  is reported as not applicable (that case reads "not resolved"). The multi-seed path stays for a later version.
- Seed rule (seeds 45 and 46), per contrast with at least two seeds per side (otherwise "one seed: not computed"):
  v_s, v_mean, the variance of the per-seed differences s_d^2, g = n/(n-1) x (mean v_s^2 - v_mean^2) (1.5 at
  three seeds), v_sh^2, 2 sigma^2 and the projected gain
  2.80 x [sqrt(v_sh^2 + (g + 2 sigma^2)/3) - sqrt(v_sh^2 + (g + 2 sigma^2)/5)]; the rule fires when the gain
  exceeds 0.003 AP. The design reads it for A h5 minus A h0, on validation when scored. Beside it, the
  rates of the labels with no true difference under the measured noise (probes/review_rules.py part 1).
- --depth-matched ALLPOS:R1,R2: all-position B against R1 and R2 on the rows at chunk position --depth-position
  (strictly-earlier rows in the chunk, chunks cut by the phase4b builder's own rule), paired by account. A reading,
  never a contrast: it gets no label.
- --difference C1 C2: the interval of (C1 difference minus C2 difference) on the joint draws (the time-gap
  crossing question); no label.
Every interval covers account sampling only, for fixed trained models, and holds for its own line only (pointwise).

Outputs in --out-dir: paired_lines.csv, paired_contrasts.csv, paired_seed_rule.csv, paired_runs.csv,
paired_cohort.csv and paired_report.txt.
"""
import argparse
import csv
import hashlib
import os
import sys
from collections import Counter
from types import SimpleNamespace

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from fraud.data.s3_utils import build_file_list, make_s3_filesystem
from YOUR_PACKAGE.base.data.input_contracts import parse_required_timestamps
from YOUR_PACKAGE.scoring import temporal_eval
from YOUR_PACKAGE.scoring._prediction_utils import prediction_path, validate_ids
from YOUR_PACKAGE.scoring.leaderboard import _bootstrap_blocks

SPLITS = ("evaluation", "validation")
RUN_COLUMNS = ["contrast", "side", "run", "seed", "prediction_path"]
GATE = 0.003       # DESIGN_V1 section 3: seeds 45 and 46 come back when the projected gain exceeds 0.003 AP
DETECT = 2.80      # detectable difference = 2.80 x SE (80% power, two-sided 5%), as in probes/mde_v2.py
OK = "ok"
DIRECTION_DISAGREEMENT = "not resolved: direction disagreement"


# --------------------------------------------------------------------------------------------------------------- #
# Run table
# --------------------------------------------------------------------------------------------------------------- #
def read_run_table(path):
    """Models keyed by (run, seed) and contrasts as {name: {"x": [keys], "y": [keys]}}, in table order."""
    table = pd.read_csv(path, dtype=str, keep_default_na=False)
    missing = set(RUN_COLUMNS) - set(table.columns)
    if missing:
        raise ValueError(f"run table: missing columns {sorted(missing)}")
    models, contrasts = {}, {}
    for line, row in enumerate(table.to_dict("records"), start=2):
        contrast, side = row["contrast"].strip(), row["side"].strip().lower()
        run = row["run"].strip()
        if not run:
            raise ValueError(f"run table line {line}: empty run name")
        try:
            seed = int(row["seed"])
        except ValueError:
            raise ValueError(f"run table line {line}: seed must be an integer") from None
        if contrast and side not in ("x", "y"):
            raise ValueError(f"run table line {line}: side must be x or y")
        if not contrast and side:
            raise ValueError(f"run table line {line}: a side needs a contrast")
        valid_ap = row.get("valid_ap", "").strip()
        entry = {
            "evaluation": prediction_path(row["prediction_path"].strip()),
            "validation": prediction_path(row["validation_path"].strip())
            if row.get("validation_path", "").strip() else None,
            "valid_ap": float(valid_ap) if valid_ap else None,
        }
        key = (run, seed)
        if key in models and models[key] != entry:
            raise ValueError(f"run table line {line}: {run} seed {seed} is listed twice with different paths")
        models[key] = entry
        if not contrast:
            continue
        sides = contrasts.setdefault(contrast, {"x": [], "y": []})
        if key in sides[side]:
            raise ValueError(f"run table line {line}: {run} seed {seed} is listed twice in {contrast} side {side}")
        sides[side].append(key)
    for name, sides in contrasts.items():
        for side in ("x", "y"):
            if not sides[side]:
                raise ValueError(f"contrast {name}: side {side} has no run")
            if len({run for run, _ in sides[side]}) != 1:
                raise ValueError(f"contrast {name}: side {side} must hold one run name (its seeds as rows)")
    return models, contrasts


# --------------------------------------------------------------------------------------------------------------- #
# Raw files: history counts and all-position chunk positions
# --------------------------------------------------------------------------------------------------------------- #
def chunk_positions(raw, account_col, order_col, chunk_seconds):
    """Strictly-earlier rows of each row inside its all-position chunk (one raw file).

    The chunk cut is the phase4b builder's own rule (SequenceBuilder._chunk_spans under 'strict': cut only between
    whole seconds, chunk_seconds distinct seconds per chunk, per account and per file); 'earlier' compares the parsed
    instant, as the builder's mask does. Under that cut, position 5 sees exactly the 5 most recent strictly-earlier
    rows of its account (DESIGN_V1 section 3, depth-matched subset).
    """
    from YOUR_PACKAGE.phase4b.sequence_builder import SequenceBuilder

    rule = SimpleNamespace(T=int(chunk_seconds), history_time_order="strict")
    instants = parse_required_timestamps(raw[order_col], order_col)
    order_key = instants.to_numpy(dtype="datetime64[ns]").astype("int64")
    seconds = instants.to_numpy(dtype="datetime64[s]").astype("int64")
    accounts, _ = pd.factorize(validate_ids(raw[account_col], "raw rows: account IDs", unique=False), sort=False)
    order = np.lexsort((order_key, accounts))
    bounds = np.flatnonzero(np.r_[True, accounts[order][1:] != accounts[order][:-1], True])
    position = np.empty(len(raw), dtype=np.int64)
    for start, end in zip(bounds[:-1], bounds[1:]):
        rows = order[start:end]
        for lo, hi in SequenceBuilder._chunk_spans(rule, seconds[rows]):
            chunk = rows[lo:hi]
            keys = order_key[chunk]
            position[chunk] = np.searchsorted(keys, keys, side="left")
    return position


def load_raw(files, fs, args, need_positions):
    """Composite ids, history count (and chunk position) of every raw row, file by file."""
    frames = []
    for number, path in enumerate(files):
        raw = temporal_eval._read(path, fs, columns=[args.id, args.account, args.order_col])
        counted = temporal_eval._history_counts(raw, args.id, args.account, args.order_col)
        if need_positions:
            counted["_position"] = chunk_positions(counted, args.account, args.order_col, args.chunk_seconds)
        counted["_file"] = number
        frames.append(counted)
    raw = pd.concat(frames, ignore_index=True)
    out = pd.DataFrame({
        "_id": validate_ids(raw[args.id], "raw rows: IDs", unique=False).to_numpy(),
        "_acct": validate_ids(raw[args.account], "raw rows: account IDs", unique=False).to_numpy(),
        "_history": raw[temporal_eval.HISTORY_COL].to_numpy(),
        "_file": raw["_file"].to_numpy(),
    })
    if need_positions:
        out["_position"] = raw["_position"].to_numpy()
    return out


# --------------------------------------------------------------------------------------------------------------- #
# Joining one run to the raw rows (counted, never silently intersected)
# --------------------------------------------------------------------------------------------------------------- #
def map_run(path, fs, raw_keys, n_raw, args, label):
    """Scores and labels of one prediction file placed on raw row positions, with its join counts."""
    pred = temporal_eval._read(path, fs, columns=[args.id, args.account, args.target, args.score_col])
    keys = pd.DataFrame({
        "_id": validate_ids(pred[args.id], f"{label}: IDs", unique=False).to_numpy(),
        "_acct": validate_ids(pred[args.account], f"{label}: account IDs", unique=False).to_numpy(),
    })
    placed = keys.merge(raw_keys, on=["_id", "_acct"], how="left", sort=False)["_pos"].to_numpy(dtype=float)
    matched = ~np.isnan(placed)
    target = pd.to_numeric(pred[args.target], errors="coerce").to_numpy(dtype=float)
    score = pd.to_numeric(pred[args.score_col], errors="coerce").to_numpy(dtype=float)
    binary = np.isin(target, [0.0, 1.0])
    finite = np.isfinite(score)
    positions = placed[matched].astype(np.int64)
    cover = np.zeros(n_raw, dtype=bool)
    cover[positions] = True
    scores = np.full(n_raw, np.nan)
    scores[positions] = score[matched]
    labels = np.full(n_raw, -1, dtype=np.int8)
    labels[positions] = np.where(binary[matched], target[matched], -2).astype(np.int8)
    counts = {
        "rows": len(pred), "frauds": int(np.sum(target == 1)),
        "duplicate_ids": int(keys.duplicated().sum()),
        "unmatched_raw_ids": int((~matched).sum()),
        "nonbinary_targets": int((~binary).sum()),
        "nonfinite_scores": int((~finite).sum()),
    }
    fingerprint = hashlib.sha256(np.packbits(cover).tobytes()).hexdigest()
    return {"cover": cover, "scores": scores, "labels": labels, "counts": counts, "fingerprint": fingerprint}


# --------------------------------------------------------------------------------------------------------------- #
# Joint account draws and weighted AP
# --------------------------------------------------------------------------------------------------------------- #
def draw_multiplicities(groups, n_draws, seed):
    """Account code per row and the [draws, accounts] multiplicity matrix of one joint draw set.

    Blocks come from leaderboard._bootstrap_blocks and each draw consumes rng.integers(0, accounts, accounts), as
    leaderboard._draw_indices does, so the draws are those of leaderboard._paired_bootstrap_ci for the same seed and
    row order. Passing one group per row gives row resampling (used by the tests to show the difference).
    """
    blocks = _bootstrap_blocks(np.asarray(groups, dtype=object), len(groups))
    codes = np.empty(len(groups), dtype=np.int64)
    for code, rows in enumerate(blocks):
        codes[rows] = code
    rng = np.random.default_rng(seed)
    mult = np.empty((n_draws, len(blocks)), dtype=np.int32)
    for d in range(n_draws):
        mult[d] = np.bincount(rng.integers(0, len(blocks), len(blocks)), minlength=len(blocks))
    return codes, mult


def sorted_line(scores, y, codes):
    """Rows sorted by descending score once, with the last index of the tied-score groups that matter.

    Only a group holding a positive moves recall, so only those groups' ends (and the last row, for the totals)
    are kept; dropping the others leaves AP unchanged and makes each draw cheaper.
    """
    order = np.argsort(-np.asarray(scores, dtype=float), kind="stable")
    s = np.asarray(scores, dtype=float)[order]
    ys = np.asarray(y, dtype=np.int64)[order]
    if not len(s):
        return ys, np.asarray(codes)[order], np.empty(0, dtype=np.int64)
    ends = np.flatnonzero(np.r_[s[1:] != s[:-1], True])
    positives_before = np.r_[0, np.cumsum(ys)][ends + 1]
    keep = np.diff(positives_before, prepend=0) > 0
    keep[-1] = True
    return ys, np.asarray(codes)[order], ends[keep]


def weighted_ap(y_sorted, weights, ends):
    """sklearn's average precision with integer row weights (a weight k counts the row k times).

    Precision and recall are taken at each distinct score, as precision_recall_curve does, so ties are handled as
    sklearn handles them. Undefined (NaN) when the weighted rows hold one class only.
    """
    if not len(ends):
        return float("nan")
    tp = np.cumsum(weights * y_sorted, dtype=np.int64)[ends]
    total = np.cumsum(weights, dtype=np.int64)[ends]
    positives = tp[-1]
    if positives == 0 or positives == total[-1]:
        return float("nan")
    precision = tp / np.maximum(total, 1)
    return float(np.dot(np.diff(tp, prepend=0), precision) / positives)


def line_aps(scores, y, codes, mult):
    """Point AP (every row once) and AP on every draw, for one model on one line."""
    ys, cs, ends = sorted_line(scores, y, codes)
    point = weighted_ap(ys, np.ones(len(ys), dtype=np.int64), ends)
    draws = np.array([weighted_ap(ys, mult[d][cs], ends) for d in range(len(mult))])
    return point, draws


def percentile_ci(values):
    """95% percentile interval of the defined draws, with the counts of defined and undefined draws."""
    values = np.asarray(values, dtype=float)
    valid = values[np.isfinite(values)]
    out = {"draws_valid": len(valid), "draws_undefined": int(len(values) - len(valid)),
           "ci_low": float("nan"), "ci_high": float("nan")}
    if len(valid) >= 2:
        out["ci_low"], out["ci_high"] = float(np.percentile(valid, 2.5)), float(np.percentile(valid, 97.5))
    return out


# --------------------------------------------------------------------------------------------------------------- #
# Reading rules (DESIGN_V1 section 3; probes/review_rules.py)
# --------------------------------------------------------------------------------------------------------------- #
def s1_label(validation_seed_differences, evaluation_ci, validation_ci=None):
    """reviewer's S1 label for X minus Y; returns (label, reason).

    validation_ci is None when validation is not scored; then only the validation seed signs and the evaluation
    interval decide. A zero difference has neither sign.
    """
    diffs = [d for d in (validation_seed_differences or []) if d is not None]
    if not diffs or len(diffs) != len(validation_seed_differences or []):
        return "not resolved (no validation)", "no validation predictions and no valid_ap"
    lo, hi = evaluation_ci
    if not (np.isfinite(lo) and np.isfinite(hi)):
        return "not resolved", "evaluation interval undefined"
    vpos, vneg = all(d > 0 for d in diffs), all(d < 0 for d in diffs)
    epos, eneg = lo > 0, hi < 0
    if validation_ci is None:
        wpos = wneg = True
    else:
        wlo, whi = validation_ci
        wpos = bool(np.isfinite(wlo) and wlo > 0)
        wneg = bool(np.isfinite(whi) and whi < 0)
    if vpos and epos and wpos:
        return "consistent positive", "every validation seed above zero; interval(s) wholly above zero"
    if vneg and eneg and wneg:
        return "consistent negative", "every validation seed below zero; interval(s) wholly below zero"
    if (vpos and eneg) or (vneg and epos):
        return DIRECTION_DISAGREEMENT, "validation seeds and the evaluation interval point opposite ways"
    reasons = []
    if not (vpos or vneg):
        reasons.append("validation seeds do not share one sign")
    if not (epos or eneg):
        reasons.append("evaluation interval includes zero")
    if validation_ci is not None and not (wpos or wneg):
        reasons.append("validation interval includes zero")
    if not reasons:
        reasons.append("validation interval points the other way")
    return "not resolved", "; ".join(reasons)


def seed_rule(per_seed_draws, mean_draws, per_seed_points):
    """The stage 1 seed-rule quantities (DESIGN_V1 section 3, seeds 45 and 46) for n >= 2 paired seeds.

    per_seed_draws [n, draws]: each seed's paired difference on the joint draws; mean_draws: the n-seed mean
    difference on the same draws; per_seed_points: the n point differences.
    """
    n = len(per_seed_points)
    if n < 2:
        return None
    per_seed_draws = np.asarray(per_seed_draws, dtype=float)
    keep = np.all(np.isfinite(per_seed_draws), axis=0) & np.isfinite(mean_draws)
    if keep.sum() < 2:
        return None
    v_s = per_seed_draws[:, keep].std(axis=1, ddof=1)
    v_mean = float(np.asarray(mean_draws)[keep].std(ddof=1))
    s_d2 = float(np.var(per_seed_points, ddof=1))
    mean_v_s2 = float(np.mean(v_s ** 2))
    g = n / (n - 1) * (mean_v_s2 - v_mean ** 2)
    v_sh2 = mean_v_s2 - g
    two_sigma2 = max(0.0, s_d2 - g)

    def detectable(seeds):
        return DETECT * np.sqrt(max(0.0, v_sh2 + (g + two_sigma2) / seeds))

    gain = float(detectable(3) - detectable(5))
    return {"n_paired_seeds": n, "v_s": [float(v) for v in v_s], "v_mean": v_mean, "s_d2": s_d2,
            "g": float(g), "v_sh2": float(v_sh2), "two_sigma2": float(two_sigma2),
            "projected_gain": gain, "rule_fires": gain > GATE, "draws_used": int(keep.sum())}


def null_label_rates(v_eval, v_valid, two_sigma2, n_seeds, validation_interval, draws=400_000, seed=20261012):
    """Label rates with no true difference under the measured noise (probes/review_rules.py part 1, delta 0).

    Per-seed difference = F + S_s, F ~ N(0, v) shared by the seeds of one split, S_s ~ N(0, sqrt(2) sigma);
    'shared' uses the same seed terms on validation and evaluation, 'indep' independent ones.
    """
    rng = np.random.default_rng(seed)
    sd_seed = np.sqrt(max(0.0, two_sigma2))
    out = {}
    for shared in (True, False):
        sv = rng.normal(0, sd_seed, (draws, n_seeds))
        se = sv if shared else rng.normal(0, sd_seed, (draws, n_seeds))
        dv = rng.normal(0, v_valid, (draws, 1)) + sv
        de = rng.normal(0, v_eval, (draws, 1)) + se
        me, mv = de.mean(1), dv.mean(1)
        vpos, vneg = np.all(dv > 0, 1), np.all(dv < 0, 1)
        epos, eneg = me > 1.96 * v_eval, me < -1.96 * v_eval
        if validation_interval:
            vpos_i, vneg_i = mv > 1.96 * v_valid, mv < -1.96 * v_valid
        else:
            vpos_i = vneg_i = np.ones(draws, dtype=bool)
        tag = "shared" if shared else "indep"
        out[f"null_consistent_positive_{tag}"] = float((vpos & epos & vpos_i).mean())
        out[f"null_consistent_negative_{tag}"] = float((vneg & eneg & vneg_i).mean())
        out[f"null_direction_disagreement_{tag}"] = float(((vpos & eneg) | (vneg & epos)).mean())
    return out


def seed_pairs(x_keys, y_keys):
    """(x, y) pairs for the per-seed differences and how they were paired."""
    x_seeds, y_seeds = [k[1] for k in x_keys], [k[1] for k in y_keys]
    if sorted(x_seeds) == sorted(y_seeds):
        y_by_seed = {k[1]: k for k in y_keys}
        return [(x, y_by_seed[x[1]]) for x in x_keys], "by seed"
    if len(y_keys) == 1:
        return [(x, y_keys[0]) for x in x_keys], "each x seed minus the single y run"
    if len(x_keys) == 1:
        return [(x_keys[0], y) for y in y_keys], "the single x run minus each y seed"
    return [], "unpaired seeds (different seed sets)"


# --------------------------------------------------------------------------------------------------------------- #
# One split: cohort, draws, lines and per-model APs
# --------------------------------------------------------------------------------------------------------------- #
class Split:
    def __init__(self, name, raw, runs, args, fs=None, files=0):
        self.name, self.args, self.files = name, args, files
        n_raw = len(raw)
        dup = raw.duplicated(["_id", "_acct"])
        self.raw_rows, self.raw_duplicates = n_raw, int(dup.sum())
        raw_keys = raw.loc[~dup, ["_id", "_acct"]].assign(_pos=np.flatnonzero(~dup.to_numpy()))
        self.runs = {}
        for key, path in runs.items():
            self.runs[key] = map_run(path, fs, raw_keys, n_raw, args, f"{name} {key[0]} seed {key[1]}")
        # The cohort is the composite-id set most runs share (first in table order on a tie); every run is
        # compared with it, so one broken run is named instead of shifting every other run.
        tally = Counter(r["fingerprint"] for r in self.runs.values())
        best = max(tally.values())
        reference = next(k for k, r in self.runs.items() if tally[r["fingerprint"]] == best)
        self.reference = reference
        cover = self.runs[reference]["cover"]
        ref_labels = self.runs[reference]["labels"]
        self.cohort = np.flatnonzero(cover)
        for key, r in self.runs.items():
            c = r["counts"]
            c["missing_vs_cohort"] = int(np.sum(cover & ~r["cover"]))
            c["extra_vs_cohort"] = int(np.sum(r["cover"] & ~cover))
            both = cover & r["cover"]
            c["label_mismatch"] = int(np.sum(r["labels"][both] != ref_labels[both]))
            problems = [f"{field} {c[field]}" for field in
                        ("duplicate_ids", "unmatched_raw_ids", "missing_vs_cohort", "extra_vs_cohort",
                         "label_mismatch", "nonbinary_targets", "nonfinite_scores") if c[field]]
            if self.raw_duplicates:
                problems.append(f"raw_duplicate_ids {self.raw_duplicates}")
            r["status"] = OK if not problems else "join mismatch: " + ", ".join(problems)
        self.scored_by_every_run = int(np.sum(np.logical_and.reduce([r["cover"] for r in self.runs.values()])
                                              & ~dup.to_numpy()))
        self.y = ref_labels[self.cohort].astype(np.int64)
        # A nonbinary label (-2) marks its run as a join mismatch above; it is set to 0 only so the arrays stay
        # binary, and no contrast with that run is computed.
        self.y = np.where(self.y < 0, 0, self.y)
        cohort_raw = raw.iloc[self.cohort]
        self.accounts = cohort_raw["_acct"].to_numpy()
        self.history = cohort_raw["_history"].to_numpy()
        self.position = cohort_raw["_position"].to_numpy() if "_position" in cohort_raw else None
        self.lines = {"overall": np.ones(len(self.cohort), dtype=bool)}
        if self.position is not None:
            self.lines[f"position:{args.depth_position}"] = self.position == args.depth_position
        self.codes, self.mult = draw_multiplicities(self.accounts, args.draws, args.seed)
        self.n_accounts = self.mult.shape[1]
        self._cache = {}

    def ap(self, key, line):
        """(point AP, AP per draw, AUROC) of one run on one line; cached."""
        if (key, line) not in self._cache:
            mask = self.lines[line]
            scores = self.runs[key]["scores"][self.cohort][mask]
            y = self.y[mask]
            point, draws = line_aps(scores, y, self.codes[mask], self.mult)
            auroc = float(roc_auc_score(y, scores)) if 0 < y.sum() < len(y) else float("nan")
            self._cache[(key, line)] = (point, draws, auroc)
        return self._cache[(key, line)]

    def line_counts(self, line):
        mask = self.lines[line]
        y, accounts = self.y[mask], self.accounts[mask]
        rows, frauds = int(mask.sum()), int(y.sum())
        out = {"rows": rows, "frauds": frauds, "fraud_rate": frauds / rows if rows else float("nan"),
               "accounts": int(pd.unique(accounts).size), "fraud_accounts": int(pd.unique(accounts[y == 1]).size)}
        for h in self.args.history_lengths:
            out[f"full_history_share_h{h}"] = float(np.mean(self.history[mask] >= h)) if rows else float("nan")
        return out


def _problems(run):
    return run["status"].removeprefix("join mismatch: ")


def compare(split, x_keys, y_keys, line):
    """Paired X minus Y on one line: per-side APs, the difference, per-seed differences and the interval."""
    x = [split.ap(k, line) for k in x_keys]
    y = [split.ap(k, line) for k in y_keys]
    ap_x, ap_y = float(np.mean([p for p, _, _ in x])), float(np.mean([p for p, _, _ in y]))
    draws = np.mean([d for _, d, _ in x], axis=0) - np.mean([d for _, d, _ in y], axis=0)
    pairs, pairing = seed_pairs(x_keys, y_keys)
    per_seed_points = [split.ap(a, line)[0] - split.ap(b, line)[0] for a, b in pairs]
    per_seed_draws = [split.ap(a, line)[1] - split.ap(b, line)[1] for a, b in pairs]
    out = {"ap_x": ap_x, "ap_y": ap_y,
           "ap_x_per_seed": ";".join(f"{k[1]}:{p:.6f}" for k, (p, _, _) in zip(x_keys, x)),
           "ap_y_per_seed": ";".join(f"{k[1]}:{p:.6f}" for k, (p, _, _) in zip(y_keys, y)),
           "auroc_x": float(np.mean([a for _, _, a in x])), "auroc_y": float(np.mean([a for _, _, a in y])),
           "difference": ap_x - ap_y,
           "difference_per_seed": ";".join(f"{a[1]}-{b[1]}:{d:+.6f}" for (a, b), d in zip(pairs, per_seed_points)),
           "seed_pairing": pairing, "draws_requested": len(draws)}
    out.update(percentile_ci(draws))
    return out, draws, per_seed_points, per_seed_draws


# --------------------------------------------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------------------------------------------- #
def parse_args(argv=None):
    p = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    p.add_argument("--runs", required=True, help="run-to-contrast table (CSV; see the usage block)")
    p.add_argument("--out-dir", required=True, help="folder for the aggregate CSV files and paired_report.txt")
    p.add_argument("--raw-base", default="s3://DATA_BUCKET/tfm_EVAL_raw_data")
    p.add_argument("--file-start", type=int, default=8000)
    p.add_argument("--file-end", type=int, default=8010)
    p.add_argument("--valid-raw-base", default=None, help="raw base of the validation files (needed only when "
                                                          "the run table has validation_path entries)")
    p.add_argument("--valid-file-start", type=int, default=4950)
    p.add_argument("--valid-file-end", type=int, default=4954)
    p.add_argument("--id", default="fi_transaction_id")
    p.add_argument("--account", default="Nmap_account_reference_xid")
    p.add_argument("--target", default="frd_tag")
    p.add_argument("--score-col", default="score")
    p.add_argument("--order-col", default="transaction_dttm")
    p.add_argument("--draws", type=int, default=1000)
    p.add_argument("--seed", type=int, default=0, help="seed of the joint account draws (default 0, as leaderboard)")
    p.add_argument("--history-lengths", default="5,10,15,20",
                   help="H values for the share of rows with at least H strictly-earlier rows, per line")
    p.add_argument("--depth-matched", default=None, metavar="ALLPOS:RUN1,RUN2",
                   help="all-position B run name, then the run names it is read against on the position subset")
    p.add_argument("--depth-position", type=int, default=5)
    p.add_argument("--chunk-seconds", type=int, default=6,
                   help="distinct seconds per all-position chunk (history_len + 1 of the all-position config)")
    p.add_argument("--difference", nargs=2, action="append", default=[], metavar=("C1", "C2"),
                   help="also report (C1 difference minus C2 difference) on the joint draws; repeatable")
    p.add_argument("--cred", default="/home/jovyan/your_id/tabular_fraud/test.yaml")
    args = p.parse_args(argv)
    if args.id == args.account:
        p.error("--id and --account must name different columns (composite identity)")
    if args.draws < 2:
        p.error("--draws must be at least 2")
    args.history_lengths = [int(h) for h in str(args.history_lengths).split(",") if h.strip()]
    if args.depth_matched:
        allpos, _, others = args.depth_matched.partition(":")
        args.depth_matched = (allpos.strip(), [o.strip() for o in others.split(",") if o.strip()])
        if not args.depth_matched[0] or not args.depth_matched[1]:
            p.error("--depth-matched takes ALLPOS:RUN1[,RUN2...]")
    return args


def _fmt(value, digits=4):
    if isinstance(value, float):
        return "undefined" if not np.isfinite(value) else f"{value:.{digits}f}"
    return str(value)


def analyse(args):
    models, contrasts = read_run_table(args.runs)
    for c1, c2 in args.difference:
        for c in (c1, c2):
            if c not in contrasts:
                raise ValueError(f"--difference names an unknown contrast: {c}")
    depth_runs = []
    if args.depth_matched:
        allpos, others = args.depth_matched
        for run in [allpos, *others]:
            if not any(k[0] == run for k in models):
                raise ValueError(f"--depth-matched names a run that is not in the run table: {run}")
        depth_runs = [allpos, *others]

    paths = [m["evaluation"] for m in models.values()] + [m["validation"] for m in models.values() if m["validation"]]
    paths += [args.raw_base] + ([args.valid_raw_base] if args.valid_raw_base else [])
    fs = make_s3_filesystem(args.cred) if any(str(p).startswith("s3://") for p in paths) else None
    splits = {}
    for name in SPLITS:
        runs = {k: m[name] for k, m in models.items() if m[name]}
        if not runs:
            continue
        if name == "validation" and not args.valid_raw_base:
            raise ValueError("the run table has validation_path entries; give --valid-raw-base")
        base = prediction_path(args.raw_base if name == "evaluation" else args.valid_raw_base)
        start, end = ((args.file_start, args.file_end) if name == "evaluation"
                      else (args.valid_file_start, args.valid_file_end))
        files = build_file_list(base, start, end)
        raw = load_raw(files, fs, args, need_positions=bool(depth_runs))
        splits[name] = Split(name, raw, runs, args, fs=fs, files=len(files))

    line_rows, contrast_rows, seed_rows = [], [], []
    results = {}  # (split, contrast) -> {"status", line -> (summary, draws)}
    for cname, sides in contrasts.items():
        xk, yk = sides["x"], sides["y"]
        for sname, split in splits.items():
            if not all(k in split.runs for k in xk + yk):
                continue
            bad = [f"{k[0]} seed {k[1]}: {_problems(split.runs[k])}" for k in xk + yk if split.runs[k]["status"] != OK]
            status = OK if not bad else "join mismatch (" + "; ".join(bad) + ")"
            res = {"status": status, "lines": {}}
            results[(sname, cname)] = res
            for line in [ln for ln in split.lines if not ln.startswith("position:")]:
                row = {"split": sname, "kind": "contrast", "contrast": cname, "line": line, "status": status,
                       "x_model": xk[0][0], "y_model": yk[0][0],
                       "x_seeds": ";".join(str(k[1]) for k in xk), "y_seeds": ";".join(str(k[1]) for k in yk)}
                row.update(split.line_counts(line))
                if status == OK:
                    summary, draws, points, seed_draws = compare(split, xk, yk, line)
                    row.update(summary)
                    res["lines"][line] = (summary, draws, points, seed_draws)
                line_rows.append(row)

        # Contrast-level reading: labels and seed rule
        ev, va = results.get(("evaluation", cname)), results.get(("validation", cname))
        crow = {"contrast": cname, "x_model": xk[0][0], "y_model": yk[0][0],
                "x_seeds": ";".join(str(k[1]) for k in xk), "y_seeds": ";".join(str(k[1]) for k in yk),
                "status_evaluation": ev["status"] if ev else "not scored",
                "status_validation": va["status"] if va else "not scored"}
        val_ok = va is not None and va["status"] == OK
        one_seed = len(xk) == 1 and len(yk) == 1
        if val_ok:
            seed_diffs = va["lines"]["overall"][2]
            seed_source = "validation predictions"
        else:
            pairs, _ = seed_pairs(xk, yk)
            vals = [(models[a]["valid_ap"], models[b]["valid_ap"]) for a, b in pairs]
            if pairs and all(a is not None and b is not None for a, b in vals):
                seed_diffs, seed_source = [a - b for a, b in vals], "valid_ap column"
            else:
                seed_diffs, seed_source = [], "none"
        crow["validation_seed_source"] = seed_source
        crow["validation_seed_differences"] = ";".join(f"{d:+.6f}" for d in seed_diffs)
        ev_ok = ev is not None and ev["status"] == OK
        if ev_ok:
            ev_sum = ev["lines"]["overall"][0]
            crow.update({"evaluation_difference": ev_sum["difference"], "evaluation_ci_low": ev_sum["ci_low"],
                         "evaluation_ci_high": ev_sum["ci_high"]})
        val_ci = None
        if val_ok:
            va_sum = va["lines"]["overall"][0]
            val_ci = (va_sum["ci_low"], va_sum["ci_high"])
            crow.update({"validation_difference": va_sum["difference"], "validation_ci_low": va_sum["ci_low"],
                         "validation_ci_high": va_sum["ci_high"]})
        if not ev_ok:
            crow["label"] = "not computed: join mismatch" if ev else "not computed: no evaluation predictions"
            crow["label_detail"] = crow["status_evaluation"]
        elif 0 < sum(models[k]["validation"] is not None for k in xk + yk) < len(xk + yk):
            # Validation predictions for only part of the contrast: neither its interval nor the valid_ap sign
            # stands in for the missing side (reviewer review of bd15a2b).
            crow["label"] = "not resolved (validation incomplete)"
            crow["label_detail"] = "validation predictions exist for only part of the contrast's runs"
        elif va is not None and not val_ok:
            # Validation was scored, so its interval is part of the rule; a broken validation join is not skipped.
            crow["label"] = "not computed: validation join mismatch"
            crow["label_detail"] = crow["status_validation"]
        else:
            crow["label"], crow["label_detail"] = s1_label(seed_diffs, (ev_sum["ci_low"], ev_sum["ci_high"]), val_ci)
            if one_seed and crow["label"] == DIRECTION_DISAGREEMENT:
                # One seed: direction disagreement does not apply (owner, thirty-first message); the label is
                # plain "not resolved", with the reason kept.
                crow["label"] = "not resolved"
        if one_seed:
            crow["direction_disagreement"] = "not applicable (one seed)"
        elif "label" in crow and not crow["label"].startswith("not computed"):
            crow["direction_disagreement"] = "yes" if crow["label"] == DIRECTION_DISAGREEMENT else "no"
        contrast_rows.append(crow)

        rule_split = {}
        if len(xk) < 2 or len(yk) < 2:
            for sname in SPLITS:
                if (sname, cname) in results:
                    seed_rows.append({"contrast": cname, "split": sname,
                                      "seed_rule": "one seed: not computed" if one_seed
                                      else "fewer than two seeds per side: not computed"})
        for sname in SPLITS:
            res = results.get((sname, cname))
            if len(xk) < 2 or len(yk) < 2 or not res or res["status"] != OK:
                continue
            summary, draws, points, seed_draws = res["lines"]["overall"]
            rule = seed_rule(seed_draws, draws, points)
            if rule is not None:
                rule_split[sname] = rule
        for sname, rule in rule_split.items():
            v_eval = np.sqrt(np.mean(np.square(rule_split.get("evaluation", rule)["v_s"])))
            v_valid = np.sqrt(np.mean(np.square(rule_split["validation"]["v_s"]))) \
                if "validation" in rule_split else v_eval
            srow = {"contrast": cname, "split": sname, "seed_rule": "computed",
                    "rule_split": "validation" if "validation" in rule_split else "evaluation",
                    **{k: v for k, v in rule.items() if k != "v_s"},
                    "v_s": ";".join(f"{v:.6f}" for v in rule["v_s"])}
            srow.update(null_label_rates(float(v_eval), float(v_valid), rule["two_sigma2"],
                                         rule["n_paired_seeds"], "validation" in rule_split))
            seed_rows.append(srow)

    for c1, c2 in args.difference:
        for sname, split in splits.items():
            r1, r2 = results.get((sname, c1)), results.get((sname, c2))
            if not r1 or not r2:
                continue
            status = OK if r1["status"] == OK and r2["status"] == OK else "join mismatch in a part"
            for line in [ln for ln in split.lines if not ln.startswith("position:")]:
                row = {"split": sname, "kind": "difference of contrasts", "contrast": f"({c1}) minus ({c2})",
                       "line": line, "status": status}
                row.update(split.line_counts(line))
                if status == OK:
                    s1, d1 = r1["lines"][line][:2]
                    s2, d2 = r2["lines"][line][:2]
                    row.update({"difference": s1["difference"] - s2["difference"], "draws_requested": len(d1)})
                    row.update(percentile_ci(d1 - d2))
                line_rows.append(row)

    if depth_runs:
        allpos, others = args.depth_matched
        line = f"position:{args.depth_position}"
        for sname, split in splits.items():
            xk = [k for k in split.runs if k[0] == allpos]
            for other in others:
                yk = [k for k in split.runs if k[0] == other]
                if not xk or not yk:
                    continue
                bad = [f"{k[0]} seed {k[1]}: {_problems(split.runs[k])}" for k in xk + yk
                       if split.runs[k]["status"] != OK]
                status = OK if not bad else "join mismatch (" + "; ".join(bad) + ")"
                row = {"split": sname, "kind": "depth-matched reading (no label)",
                       "contrast": f"{allpos} minus {other} (depth-matched subset)", "line": line,
                       "status": status, "x_model": allpos, "y_model": other,
                       "x_seeds": ";".join(str(k[1]) for k in xk), "y_seeds": ";".join(str(k[1]) for k in yk)}
                row.update(split.line_counts(line))
                if status == OK and row["rows"]:
                    row.update(compare(split, xk, yk, line)[0])
                line_rows.append(row)

    run_rows, cohort_rows = [], []
    for sname, split in splits.items():
        cohort_rows.append({
            "split": sname, "raw_files": split.files, "raw_rows": split.raw_rows,
            "raw_duplicate_ids": split.raw_duplicates, "cohort_rows": len(split.cohort),
            "cohort_frauds": int(split.y.sum()), "cohort_accounts": split.n_accounts,
            "raw_rows_not_in_cohort": split.raw_rows - len(split.cohort),
            "raw_rows_scored_by_every_run": split.scored_by_every_run,
            "cohort_reference_run": f"{split.reference[0]} seed {split.reference[1]}",
            "runs_on_cohort": sum(r["status"] == OK for r in split.runs.values()), "runs": len(split.runs),
            "draws": args.draws, "draw_seed": args.seed,
            "resampling_unit": f"account ({args.account})"})
        for key, r in split.runs.items():
            row = {"split": sname, "run": key[0], "seed": key[1], **r["counts"], "join_status": r["status"]}
            if r["status"] == OK:
                for line in split.lines:
                    if line.startswith("position:") and key[0] not in depth_runs:
                        continue
                    point, _, auroc = split.ap(key, line)
                    row[f"ap_{line}"], row[f"auroc_{line}"] = point, auroc
            run_rows.append(row)

    return {"lines": line_rows, "contrasts": contrast_rows, "seed_rule": seed_rows, "runs": run_rows,
            "cohort": cohort_rows}


def _write_csv(path, rows):
    fields = []
    for row in rows:
        fields += [k for k in row if k not in fields]
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields or ["empty"])
        writer.writeheader()
        writer.writerows(rows)


def render_report(out, args):
    """The plain-text report: aggregates only."""
    w = []
    w.append("Paired analysis report (V1 build item B12)")
    w.append("Every interval: whole accounts resampled with replacement, "
             f"{args.draws} joint draws from seed {args.seed}, 95% percentile; it covers account sampling only, "
             "for fixed trained models (not training seeds), and holds for its own line only (pointwise).")
    w.append("Difference = mean AP of the X seeds minus mean AP of the Y seeds (the mean of the per-seed "
             "differences when the seeds match), never the AP of averaged predictions.")
    w.append("Label rule (X minus Y): 'consistent positive' needs the overall evaluation interval wholly above zero "
             "AND the validation direction positive: with validation predictions, the overall validation interval "
             "wholly above zero (and each validation seed difference above zero); without them, the difference of "
             "the runs' "
             "training valid_ap above zero. 'consistent negative' is the mirror. Anything else is 'not resolved'; "
             "with neither validation predictions nor valid_ap it is 'not resolved (no validation)', and with "
             "validation predictions for only part of the contrast it is 'not resolved (validation incomplete)'. "
             "With one seed per side, direction disagreement does not apply.")
    for c in out["cohort"]:
        w.append(f"{c['split']} rows in the raw files: {c['raw_rows']}; scored by every run: "
                 f"{c['raw_rows_scored_by_every_run']}")
    w.append("")
    w.append("Cohorts")
    for c in out["cohort"]:
        w.append(f"  {c['split']}: {c['raw_files']} raw files, {c['raw_rows']} raw rows "
                 f"({c['raw_duplicate_ids']} duplicate raw ids); cohort {c['cohort_rows']} rows, "
                 f"{c['cohort_frauds']} frauds, {c['cohort_accounts']} accounts; "
                 f"{c['runs_on_cohort']} of {c['runs']} runs join cleanly")
    bad = [r for r in out["runs"] if r["join_status"] != OK]
    w.append("")
    w.append("Join check (composite id: transaction id plus account id)")
    if not bad:
        w.append("  every run holds exactly the cohort ids with the same labels; no duplicate or unmatched id")
    for r in bad:
        w.append(f"  {r['split']} {r['run']} seed {r['seed']}: {r['join_status']}")
    w.append("")
    w.append("Contrasts (X minus Y)")
    for c in out["contrasts"]:
        w.append(f"  {c['contrast']}: {c['x_model']} [{c['x_seeds']}] minus {c['y_model']} [{c['y_seeds']}]")
        w.append(f"    label: {c['label']} ({c.get('label_detail', '')}); direction disagreement: "
                 f"{c.get('direction_disagreement', 'not computed')}")
        w.append(f"    validation seed differences ({c['validation_seed_source']}): "
                 f"{c['validation_seed_differences'] or 'none'}")
        for ln in out["lines"]:
            if ln["kind"] != "contrast" or ln["contrast"] != c["contrast"]:
                continue
            hist = ", ".join(f"h{h} {_fmt(ln[f'full_history_share_h{h}'], 3)}" for h in args.history_lengths)
            head = (f"    {ln['split']:<10} {ln['line']:<14} rows {ln['rows']}, frauds {ln['frauds']}, "
                    f"fraud rate {_fmt(ln['fraud_rate'], 5)}, accounts {ln['accounts']}, "
                    f"fraud accounts {ln['fraud_accounts']}; full history {hist}")
            w.append(head)
            if ln["status"] == OK:
                w.append(f"      AP {_fmt(ln['ap_x'])} minus {_fmt(ln['ap_y'])} = {ln['difference']:+.4f} "
                         f"[{_fmt(ln['ci_low'])}, {_fmt(ln['ci_high'])}]; per seed {ln['difference_per_seed']} "
                         f"({ln['seed_pairing']}); AUROC {_fmt(ln['auroc_x'])} vs {_fmt(ln['auroc_y'])}; "
                         f"undefined draws {ln['draws_undefined']}")
            else:
                w.append(f"      not computed: {ln['status']}")
    other = [ln for ln in out["lines"] if ln["kind"] != "contrast"]
    if other:
        w.append("")
        w.append("Readings without a label (difference of contrasts; depth-matched all-position subset)")
        for ln in other:
            w.append(f"  {ln['split']} {ln['contrast']} on {ln['line']}: rows {ln['rows']}, frauds {ln['frauds']}, "
                     f"fraud rate {_fmt(ln['fraud_rate'], 5)}, fraud accounts {ln['fraud_accounts']}")
            if ln["status"] == OK and "ci_low" in ln:
                w.append(f"    difference {ln['difference']:+.4f} [{_fmt(ln['ci_low'])}, {_fmt(ln['ci_high'])}]"
                         + (f"; AP {_fmt(ln['ap_x'])} vs {_fmt(ln['ap_y'])}" if "ap_x" in ln else ""))
            else:
                w.append(f"    not computed: {ln['status'] if ln['status'] != OK else 'no rows'}")
    w.append("")
    w.append("Seed rule for seeds 45 and 46 (the design reads it for A h5 minus A h0; validation when scored)")
    if not out["seed_rule"]:
        w.append("  no contrast has two or more paired seeds")
    for s in out["seed_rule"]:
        if s["seed_rule"] != "computed":
            w.append(f"  {s['contrast']} on {s['split']}: {s['seed_rule']}")
            continue
        w.append(f"  {s['contrast']} on {s['split']} (rule read on {s['rule_split']}): v_s {s['v_s']}, "
                 f"v_mean {s['v_mean']:.6f}, s_d^2 {s['s_d2']:.3e}, g {s['g']:.3e}, v_sh^2 {s['v_sh2']:.3e}, "
                 f"2 sigma^2 {s['two_sigma2']:.3e}; projected gain {s['projected_gain']:.4f} -> "
                 f"{'fires' if s['rule_fires'] else 'does not fire'} (gate {GATE})")
        w.append(f"    labels with no true difference under this noise (shared / independent seed terms): "
                 f"consistent positive {s['null_consistent_positive_shared']:.3f} / "
                 f"{s['null_consistent_positive_indep']:.3f}, consistent negative "
                 f"{s['null_consistent_negative_shared']:.3f} / {s['null_consistent_negative_indep']:.3f}, "
                 f"direction disagreement {s['null_direction_disagreement_shared']:.3f} / "
                 f"{s['null_direction_disagreement_indep']:.3f}")
    return "\n".join(w) + "\n"


def main(argv=None):
    args = parse_args(argv)
    out = analyse(args)
    os.makedirs(args.out_dir, exist_ok=True)
    for name in ("lines", "contrasts", "seed_rule", "runs", "cohort"):
        _write_csv(os.path.join(args.out_dir, f"paired_{name}.csv"), out[name])
    report = render_report(out, args)
    with open(os.path.join(args.out_dir, "paired_report.txt"), "w") as f:
        f.write(report)
    print(report, end="")
    return out


if __name__ == "__main__":
    main()
