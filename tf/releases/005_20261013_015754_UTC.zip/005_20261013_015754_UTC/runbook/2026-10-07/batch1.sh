#!/usr/bin/env bash
# Batch 1 of the bare-minimum study (reviewer, 2026-10-07, v2; first-release changes 2026-10-11: return folder from the
# start, pre-flight gate, comparator validation, inherited harness state, PYTHON, resume). Requires the runners of PR #5.
# Run from the new code folder, in the activated Python environment the pre-flight ran in:
#     bash runbook/2026-10-07/batch1.sh                     (PYTHON=<interpreter> to name it; default python3)
# Resume after a stop:   BATCH1_RESUME=runs/returns/batch1_<time> bash runbook/2026-10-07/batch1.sh
#     Steps whose RETURN.txt in that folder says ACCEPTED are skipped; an interrupted step is recorded (its attempt
#     folder is collected into the ledger, never reused) and runs again in a new attempt folder; the same return folder
#     keeps filling up; the A-H10 comparator recorded there is validated before it is used.
# reviewer's test harness only (stops the launch unless RUNBOOK_BANK_OVERRIDES=1 is set; the pre-flight records that):
#     RUNBOOK_SANDBOX=<folder>, BATCH1_SKIP="<spec names>", PREFLIGHT_ARGS="<pre-flight flags>".
# Order: pre-flight (RESULT PASS required; anything else stops the batch before training), then four sweeps, six runs,
# every one at seed 42 (reference's seed; owner, OWNER_QA thirty-first message: every V1 run uses seed 42 only; the seeds
# 43 and 44 file ft_decisions_h0_seeds.yaml is kept for later and not run). Every sweep writes a NEW attempt folder
# <output_root>/<UTC>-<id>/ and never overwrites. Expected GPU time: about 17.8 hours in all on one GPU, assumed; only
# A at h10 is measured (4.9 h on 2026-10-06, on older code); h0 is minutes, h5 and B are not yet measured.
#   1. ft_decisions_h0.yaml        2 runs: history 0 and 5, seed 42 (your file)                      about 2.5 h
#   2. ft_decisions_hier.yaml      2 runs: Architecture B at h5 and h10 (matched to A's h5 and h10)   about 5.5 h
#   3. ft_decisions_flat_h10.yaml  1 run: A at h10 (1024 x 4), scored: plan row A-H10, also the shared partner of
#      the time-gap control (owner, 2026-10-08: A at h10 runs once)                                  about 4.9 h
#   4. ft_decisions_timedelta.yaml 1 run: h10 with the time-gap field off (its "on" partner is step 3)  about 4.9 h
# Steps 1 and 4 are validation-only by design (batch 2 scores them on 8000-8010); steps 2 and 3 also score 8000-8010.
# A-H10 (step 3) is the shared comparator: once its run is ok and validated (batch_tools.py comparator: run_log status
# ok, source digest equal to this checkout's and the release manifest, data range, artifacts and settings equal to the
# spec, checked against a pre-flight cohort), it is recorded in <return folder>/SHARED_COMPARATOR.txt and step 4 runs.
# A_H10_COMPARATOR=<attempt folder> names an earlier ok attempt instead, only when step 3 does not run in this batch;
# it is validated the same way and the batch refuses to start when it fails (RUN-05, R-033).
# A_H10_COMPARATOR is a harness variable: the pre-flight FAILs it unless RUNBOOK_BANK_OVERRIDES=1 is set (only on
# review advice).
# The batch return folder runs/returns/batch1_<time>/ exists from the start and holds: BATCH_STATUS.txt (one line per
# event), preflight_<time>/ (the complete pre-flight copy), steps/<spec>_<time>/ (each step's
# STEP.txt and RETURN.txt with its ledger line and any CONFLICT lines, every other file of the step's return, its runner
# log and memory samples, copied as the step ends), attempts/<attempt>/ (each attempt folder), SHARED_COMPARATOR.txt
# and comparator_source_files.csv, and at the end RETURN.txt (every attempt of this batch, steps finished before a
# resume included) and run_log_batch1.csv (the batch's ledger rows). After an early stop it holds everything finished so far.
# Send: that folder and runs/run_log.csv. Only model checkpoints (*.ckpt) and prediction files (*.parquet) stay on the
# pod (the owner's answer to OQ-24).
set -uo pipefail
cd "$(dirname "$0")/../.."
HERE=runbook/2026-10-07
PY="${PYTHON:-python3}"

# Inherited harness state: these variables shrink or skip runs; in a bank shell they are a mistake unless said otherwise.
if [ "${RUNBOOK_BANK_OVERRIDES:-}" != "1" ]; then
  present=""
  for v in RUNBOOK_SANDBOX BATCH1_SKIP PREFLIGHT_ARGS; do [ -n "${!v:-}" ] && present="$present $v"; done
  if [ -n "$present" ]; then
    echo "STOPPED BEFORE START: set in this shell:$present. These belong to reviewer's test harness, not to a bank run (the sandbox"
    echo "setting shrinks every run to a one-epoch CPU model). Unset them and start again. Only on reviewer's or reviewer's"
    echo "advice, set RUNBOOK_BANK_OVERRIDES=1 to keep them; the pre-flight records that as an override. Nothing was run."
    exit 1
  fi
fi
SB="${RUNBOOK_SANDBOX:-}"
PF=runs/preflight; LEDGER=runs/run_log.csv; RET=runs/returns
[ -n "$SB" ] && { PF="$SB/preflight"; LEDGER="$SB/runs/run_log.csv"; RET="$SB/returns"; }
SKIP=" ${BATCH1_SKIP:-} "
RESUME="${BATCH1_RESUME:-}"

# The batch return folder exists from the start (RG-F02), so "send the return folder" always works.
if [ -n "$RESUME" ]; then
  OUT="$RESUME"
  [ -f "$OUT/BATCH_STATUS.txt" ] || { echo "RESUME REFUSED: $OUT is not a batch 1 return folder (no BATCH_STATUS.txt). Nothing was run."; exit 1; }
else
  OUT=runs/returns/batch1_$(date -u +%Y%m%dT%H%M%SZ); [ -n "$SB" ] && OUT="$SB/returns/batch1_summary"
fi
mkdir -p "$OUT/steps" || { echo "cannot create the return folder $OUT; nothing was run"; exit 1; }
status() { echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) $*" >> "$OUT/BATCH_STATUS.txt"; }
# Every file a step makes goes into the return, except model checkpoints (*.ckpt) and prediction files (*.parquet),
# which stay on the pod (the owner's answer to OQ-24, OWNER_QA thirtieth message).
copy_tree() {  # copy_tree <source folder> <destination folder>
  [ -d "$1" ] || return 0
  mkdir -p "$2"
  (cd "$1" && find . -type f ! -name '*.ckpt' ! -name '*.parquet' -print0) | while IFS= read -r -d '' f; do
    mkdir -p "$2/$(dirname "$f")" && cp -p "$1/$f" "$2/$f"
  done
}
copy_step_files() {  # copy_step_files <step return dir> <attempt dir or empty> <return folder>
  local ret="$1" dir="$2" out="$3" name runs
  [ -n "$ret" ] && [ -d "$ret" ] || return 0
  name=$(basename "$ret"); runs=$(dirname "$(dirname "$ret")")
  copy_tree "$ret" "$out/steps/$name"
  for f in "$runs/logs/$name.runner.log" "$runs/gpu/$name.csv" "$runs/gpu/$name.host_rss.csv"; do
    [ -f "$f" ] && cp -p "$f" "$out/steps/$name/"
  done
  [ -n "$dir" ] && copy_tree "$dir" "$out/attempts/$(basename "$dir")"
}
status "batch 1 started: interpreter $PY; resume ${RESUME:-none}; BATCH1_SKIP '${BATCH1_SKIP:-}'"
echo "batch return folder: $OUT (send this folder and $LEDGER when the batch ends or stops)"

# Pre-flight: exit 0, a RESULT PASS line in SUMMARY.txt and a data contract, or nothing is trained.
pfout=$("$PY" "$HERE/preflight_pod.py" --out-root "$PF" ${PREFLIGHT_ARGS:-} | tee >(cat >&2)); pfrc=$?
PFDIR=$(printf '%s\n' "$pfout" | sed -n 's/^PREFLIGHT_DIR=//p' | tail -1)
RESULT=""
if [ -n "$PFDIR" ] && [ -d "$PFDIR" ]; then
  PFCOPY="$OUT/preflight_$(basename "$PFDIR")"; mkdir -p "$PFCOPY"
  cp -rp "$PFDIR/." "$PFCOPY/"
  echo "pre-flight folder for this batch: $PFDIR (copied into $PFCOPY)"
  [ -f "$PFDIR/SUMMARY.txt" ] && RESULT=$(grep -E '^RESULT:? (PASS|FAIL)' "$PFDIR/SUMMARY.txt" | tail -1 | sed -E 's/^RESULT:? (PASS|FAIL).*/\1/')
fi
if [ $pfrc -ne 0 ] || [ "$RESULT" != "PASS" ] || [ ! -f "$PFDIR/data_contract.json" ]; then
  status "stopped at the pre-flight: exit $pfrc, RESULT ${RESULT:-line missing}, folder ${PFDIR:-not found}"
  echo "PRE-FLIGHT FAILED (exit $pfrc, RESULT ${RESULT:-line missing}): nothing was trained. Send the folder $OUT/ (it holds the complete pre-flight copy)."
  exit 1
fi
echo "pre-flight RESULT PASS: scored runs are checked against its evaluation cohort"

failed=0; ATTEMPTS=()
# The shared A-H10 comparator (RUN_PROTOCOL v2.2 Section 3). H10_RUNS_HERE=1: step 3 runs in this batch and its fresh
# ok attempt is the comparator; an A_H10_COMPARATOR override is then ignored. H10_RUNS_HERE=0: step 3 is skipped
# (BATCH1_SKIP) or already finished (resume), and the comparator must be a validated earlier attempt.
# In the sandbox the runs train on run_step.py's reduced copy of the spec, so the comparator is checked against it.
H10_DIR=""; H10_RUNS_HERE=1
[[ "$SKIP" == *" ft_decisions_flat_h10.yaml "* ]] && H10_RUNS_HERE=0
H10_DONE=""
if [ -n "$RESUME" ]; then
  H10_DONE=$("$PY" "$HERE/batch_tools.py" resume-state --batch-dir "$OUT" --spec ft_decisions_flat_h10.yaml | sed -n 's/^finished_ok //p' | head -1)
  [ -n "$H10_DONE" ] && H10_RUNS_HERE=0
fi
CAND="${A_H10_COMPARATOR:-}"; ORIGIN=override
if [ -z "$CAND" ] && [ -n "$RESUME" ] && [ -f "$OUT/SHARED_COMPARATOR.txt" ] && grep -q '^valid=yes$' "$OUT/SHARED_COMPARATOR.txt"; then
  CAND=$(sed -n 's/^A_H10_COMPARATOR=//p' "$OUT/SHARED_COMPARATOR.txt" | head -1); ORIGIN=batch1_return
fi
# Step 4 finished ACCEPTED in this return folder but no valid comparator was recorded (for example the batch stopped
# before the check): its own attempt is checked now, so step 4 is not held for good.
if [ -z "$CAND" ] && [ -n "$H10_DONE" ]; then
  CAND=$(sed -n 's/^attempt_dir: //p' "$H10_DONE/STEP.txt" | tail -1); ORIGIN=own
fi
if [ -n "$CAND" ]; then
  if [ $H10_RUNS_HERE -eq 1 ]; then
    echo "== A_H10_COMPARATOR is set but ft_decisions_flat_h10.yaml runs in this batch: the fresh run is the comparator;"
    echo "   the named attempt $CAND is not used (owner, 2026-10-08: A at h10 runs once)."
    status "A_H10_COMPARATOR ignored: step 3 runs in this batch"
  elif "$PY" "$HERE/batch_tools.py" comparator --attempt "$CAND" --phase phase4a --spec ft_decisions_flat_h10.yaml \
         ${SB:+--spec-file "$SB/specs/phase4a_ft_decisions_flat_h10.yaml"} --ledger "$LEDGER" \
         --record "$OUT/SHARED_COMPARATOR.txt" --files-out "$OUT/comparator_source_files.csv" --origin "$ORIGIN" --batch-preflight "$PFDIR"; then
    H10_DIR="$CAND"; status "comparator $CAND accepted ($ORIGIN)"
  else
    status "stopped: comparator $CAND rejected ($ORIGIN); see SHARED_COMPARATOR.txt"
    if [ "$ORIGIN" = override ]; then
      echo "COMPARATOR REFUSED: $CAND cannot be used as the A-H10 comparator (the reasons are above and in $OUT/SHARED_COMPARATOR.txt)."
      echo "Unset A_H10_COMPARATOR and start again. Nothing was trained."
    else
      echo "COMPARATOR REFUSED: the A-H10 result recorded in $OUT no longer passes the check (reasons above and in $OUT/SHARED_COMPARATOR.txt). Nothing was trained. Send this folder."
    fi
    exit 1
  fi
fi

for step in "phase4a ft_decisions_h0.yaml" "phase4b ft_decisions_hier.yaml" \
            "phase4a ft_decisions_flat_h10.yaml" "phase4a ft_decisions_timedelta.yaml"; do
  set -- $step
  if [[ "$SKIP" == *" $2 "* ]]; then echo "== skipped $2 (BATCH1_SKIP)"; status "skipped $2 (BATCH1_SKIP)"; continue; fi
  if [ -n "$RESUME" ]; then
    state=$("$PY" "$HERE/batch_tools.py" resume-state --batch-dir "$OUT" --spec "$2")
    done_in=$(printf '%s\n' "$state" | sed -n 's/^finished_ok //p' | head -1)
    if [ -n "$done_in" ]; then
      echo "== skipped $2: finished and ACCEPTED earlier in this batch ($done_in)"; status "resume: skipped $2 (finished in $done_in)"
      a=$(sed -n 's/^attempt_dir: //p' "$done_in/STEP.txt" | tail -1); [ -n "$a" ] && [ -d "$a" ] && ATTEMPTS+=("$a")
      continue
    fi
    printf '%s\n' "$state" | sed -n 's/^interrupted //p' | while read -r att folder; do
      echo "== $2: an earlier start of this step was interrupted. Its attempt folder $att is recorded now and never reused;"
      echo "   the step runs again in a new attempt folder."
      # The interrupted run never reached the normal return-copy call. Recover its diagnostics before marking it collected.
      copy_step_files "$(dirname "$LEDGER")/returns/$(basename "$folder")" "$att" "$OUT"
      "$PY" "$HERE/collect_returns.py" "$att" --ledger "$LEDGER" --preflight "$PFDIR" --out "$folder/interrupted_collect"
      echo "interrupted_collected: $(date -u +%Y-%m-%dT%H:%M:%SZ) (interrupted_collect/RETURN.txt)" >> "$folder/STEP.txt"
      status "resume: interrupted attempt $att of $2 collected into the ledger (not reused)"
    done
  fi
  if [ "$2" = "ft_decisions_timedelta.yaml" ] && [ -z "$H10_DIR" ]; then
    echo "== skipped $2: the A-H10 run (ft_decisions_flat_h10.yaml) has no checked result in this batch, so the time-gap run has nothing to compare with. Send the return folder; reviewers will say what to run next."
    status "skipped $2: no validated A-H10 comparator"; failed=1; continue
  fi
  status "started $2"
  # Echo the step's output through the inherited stderr descriptor. `tee /dev/stderr` would reopen the console log and
  # truncate it on Linux, erasing everything printed before this step.
  out=$("$PY" "$HERE/run_step.py" --phase "$1" --spec "$2" --preflight "$PFDIR" --batch-dir "$OUT" | tee >(cat >&2)); rc=$?
  dir=$(printf '%s\n' "$out" | sed -n 's/^ATTEMPT_DIR=//p' | tail -1)
  ret=$(printf '%s\n' "$out" | sed -n 's/^RETURN_DIR=//p' | tail -1)
  [ -n "$dir" ] && ATTEMPTS+=("$dir")
  copy_step_files "$ret" "$dir" "$OUT"
  status "finished $2: run_step exit $rc; attempt ${dir:-none}; return ${ret:-none}"
  if [ "$2" = "ft_decisions_flat_h10.yaml" ]; then
    if [ $rc -eq 0 ] && [ -n "$dir" ] && "$PY" "$HERE/batch_tools.py" comparator --attempt "$dir" --phase phase4a \
         --spec ft_decisions_flat_h10.yaml ${SB:+--spec-file "$SB/specs/phase4a_ft_decisions_flat_h10.yaml"} \
         --ledger "$LEDGER" --record "$OUT/SHARED_COMPARATOR.txt" --files-out "$OUT/comparator_source_files.csv" \
         --origin own --batch-preflight "$PFDIR"; then
      H10_DIR="$dir"; status "comparator: this batch's A-H10 $dir accepted"
    else
      H10_DIR=""; status "comparator: this batch's A-H10 failed the check (run_step exit $rc; see SHARED_COMPARATOR.txt)"
      echo "== A-H10 of this batch is not usable as the comparator (see above); no earlier attempt is used in its place"
    fi
  fi
  [ $rc -ne 0 ] && { echo "STEP $2: not all runs are ok (see its RETURN block above); continuing"; failed=1; }
done

echo; echo "===== BATCH 1 SUMMARY (send $OUT/ and $LEDGER) ====="
if [ ${#ATTEMPTS[@]} -gt 0 ]; then
  "$PY" "$HERE/collect_returns.py" --no-ledger --preflight "$PFDIR" --out "$OUT" "${ATTEMPTS[@]}" || failed=1
elif [ -z "$RESUME" ]; then
  echo "no attempt folders were created"; failed=1
else
  echo "no new attempt folders in this resume; the per-step RETURN.txt files under $OUT/steps/ are the record"
fi
"$PY" "$HERE/batch_tools.py" ledger-rows --ledger "$LEDGER" --out "$OUT/run_log_batch1.csv" --batch-dir "$OUT" ${ATTEMPTS[@]+"${ATTEMPTS[@]}"}
if [ -n "$H10_DIR" ]; then
  echo "shared A-H10 comparator: $H10_DIR (validated; recorded in $OUT/SHARED_COMPARATOR.txt)"
else
  echo "no shared A-H10 comparator in this batch"
fi
verdict=$([ $failed -eq 0 ] && echo 'all runs ok' || echo 'SOME RUNS NEED ATTENTION')
status "batch 1 finished: $verdict"
echo "Batch 1 finished: $verdict"
exit $failed
