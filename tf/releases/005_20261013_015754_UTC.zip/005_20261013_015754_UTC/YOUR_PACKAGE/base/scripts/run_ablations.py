"""Run the single-transaction reference (REF-SINGLE) grid: train, score, and collect metrics.

Copy of YOUR_PACKAGE/phase4a/scripts/run_ablations.py (reviewer, 2026-10-12, V1 build item B8 part 2) with three changes,
so the run system treats the reference model like A and B:
  - it trains with YOUR_PACKAGE/base/scripts/train_streaming.py and scores with YOUR_PACKAGE/base/scripts/score_streaming.py;
  - every run gets its own eval.predictions_base, <configured predictions_base>/<output_root name>/<attempt>/<run>,
    because the streaming scorer writes per-file parquet named after the input files (part_8000.parquet, ...) and
    refuses a destination that already exists; eval.metrics_output is injected at scoring time, as for A and B
    (<run dir>/score_metrics.json);
  - nothing else: attempts, provenance, checkpoint pairing, metrics validation and results.csv are the A runner's.

Reads a spec of named axes of dotlist overrides and executes their cartesian
product. Each invocation creates a new ``<output_root>/<attempt>/`` containing
per-run checkpoints/logs and its own ``results.csv``. The configured
``results_csv`` remains a latest-attempt view; any existing CSV is preserved as
``previous_results.csv`` inside the new attempt before that view is replaced.
Relative output paths are resolved against the repository root.

An optional spec ``attempt_tag`` names the attempt; an existing directory is
refused rather than reused. The default is a UTC timestamp plus a random ID.
Resolved configs, source hashes and checkpoint hashes are recorded per run.
The legacy ``best_valid_*`` CSV columns now both describe the saved checkpoint
epoch; they are never independent maxima. Scoring uses full-precision JSON.
Failed or incomplete runs are recorded, excluded from ranking, and make the
runner exit nonzero after the remaining cells have been attempted.

Usage:
    python YOUR_PACKAGE/base/scripts/run_ablations.py --config YOUR_PACKAGE/base/configs/ref_single.yaml
    python YOUR_PACKAGE/base/scripts/run_ablations.py --config YOUR_PACKAGE/base/configs/ref_single.yaml --dry-run
"""

import argparse
import csv
import datetime
import hashlib
from importlib.metadata import PackageNotFoundError, version
import itertools
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import uuid

from omegaconf import OmegaConf

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
sys.path.insert(0, ROOT)

from fraud.log_utils import setup_logging
from YOUR_PACKAGE.source_identity import runtime_source_files

log = setup_logging()

TRAIN_SCRIPT = os.path.join(ROOT, "YOUR_PACKAGE", "base", "scripts", "train_streaming.py")
SCORE_SCRIPT = os.path.join(ROOT, "YOUR_PACKAGE", "base", "scripts", "score_streaming.py")


def _predictions_base(configured, output_root, attempt, run_name):
    """This run's own prediction folder under the configured root (B8 part 2): unique per attempt and run."""
    return f"{str(configured).rstrip('/')}/{os.path.basename(output_root)}/{attempt}/{run_name}"


def _expand_runs(spec):
    """Cartesian product of all axes -> list of (run_name, overrides, axis_choice)."""
    axes = spec.get("axes", {})
    axis_names = list(axes.keys())
    option_lists = [list(axes[name].keys()) for name in axis_names]
    runs = []
    for combo in itertools.product(*option_lists):
        choice = dict(zip(axis_names, combo))
        overrides = []
        for axis_name, option in choice.items():
            overrides.extend(list(axes[axis_name][option]))
        run_name = "__".join(f"{a}-{o}" for a, o in choice.items()) or "default"
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", run_name):
            raise ValueError(f"Unsafe axis/run name: {run_name!r}")
        runs.append((run_name, overrides, choice))
    return axis_names, runs


def _sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _source_provenance():
    """Record exact runtime source hashes, including uncommitted source edits."""
    files = runtime_source_files(ROOT)
    hashes = {str(path.relative_to(ROOT)): _sha256(path) for path in sorted(files)}
    try:
        proc = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT,
                              capture_output=True, text=True)
        revision = proc.stdout.strip() if proc.returncode == 0 else None
    except FileNotFoundError:
        revision = None  # Source exports remain traceable through per-file hashes.
    digest = hashlib.sha256(json.dumps(hashes, sort_keys=True).encode()).hexdigest()
    return {"git_revision": revision, "source_sha256": digest, "files": hashes}


def _environment():
    packages = {}
    for name in ("torch", "pytorch-lightning", "numpy", "pandas", "pyarrow", "omegaconf", "scikit-learn"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    return {"python": sys.version, "executable": sys.executable, "packages": packages}


def _write_json(path, value):
    temp_path = f"{path}.{uuid.uuid4().hex}.tmp"
    try:
        with open(temp_path, "x", encoding="utf-8") as stream:
            json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
            stream.write("\n")
        os.replace(temp_path, path)
    finally:
        if os.path.exists(temp_path):
            os.unlink(temp_path)


def _checkpoint_metrics(checkpoint, csv_path, monitor):
    """Pair AP and AUROC with the checkpoint's epoch, never separate maxima.

    The local checkpoint was just produced by this run. CSV metrics retain the
    training callback's six-decimal precision; the monitor score is also stored
    at the checkpoint's native precision when available.
    """
    import torch
    payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
    epoch, step = int(payload["epoch"]), int(payload["global_step"])
    with open(csv_path, newline="") as stream:
        rows = [row for row in csv.DictReader(stream)
                if int(row["epoch"]) == epoch and int(row["step"]) == step]
    if len(rows) != 1:
        raise ValueError(f"Expected one CSV row for checkpoint epoch={epoch}, step={step}")
    row = rows[0]
    ap, auroc = float(row["valid_ap"]), float(row["valid_auroc"])
    if not all(math.isfinite(v) and 0 <= v <= 1 for v in (ap, auroc)):
        raise ValueError("Checkpoint validation AP/AUROC must be finite probabilities")
    score = None
    for state in payload.get("callbacks", {}).values():
        if isinstance(state, dict) and state.get("monitor") == monitor:
            raw = state.get("best_model_score")
            if raw is not None:
                score = float(raw)
    if score is not None and not math.isfinite(score):
        raise ValueError("Checkpoint monitor score is not finite")
    return {"best_valid_ap": ap, "best_valid_auroc": auroc,
            "checkpoint_epoch": epoch, "checkpoint_step": step,
            "checkpoint_monitor": monitor, "checkpoint_monitor_score": score}


def _score_metrics(path, checkpoint, checkpoint_sha256, require_metrics):
    with open(path, encoding="utf-8") as stream:
        metrics = json.load(stream)
    if not isinstance(metrics, dict) or type(metrics.get("schema_version")) is not int or metrics["schema_version"] != 1:
        raise ValueError("Unknown scorer metrics schema")
    if metrics.get("checkpoint_path") != os.path.abspath(checkpoint):
        raise ValueError("Scorer checkpoint path does not match this attempt")
    if metrics.get("checkpoint_sha256") != checkpoint_sha256 or _sha256(checkpoint) != checkpoint_sha256:
        raise ValueError("Scorer checkpoint hash does not match this attempt")
    n, positives = metrics["n_predictions"], metrics["n_positives"]
    if type(n) is not int or type(positives) is not int or n <= 0 or not 0 <= positives <= n:
        raise ValueError("Invalid scorer cohort counts")
    if not isinstance(metrics.get("predictions_path"), str) or not metrics["predictions_path"].strip():
        raise ValueError("Scorer did not identify its prediction output")
    if require_metrics and not 0 < positives < n:
        raise ValueError("Scoring metrics require both target classes")
    for key in ("average_precision", "auroc"):
        if key not in metrics:
            raise ValueError(f"Missing scorer metric field {key}")
        value = metrics[key]
        if require_metrics:
            if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 1:
                raise ValueError(f"Invalid scorer metric {key}")
        elif value is not None:
            raise ValueError(f"Disabled scorer metric {key} must be null")
    return metrics


def _write_run_summary(ckpt_dir, config_path, axis_names, choice, common, overrides,
                       row, run_score):
    """Plain-text, human-first summary dropped into the run's own folder -- so
    anyone opening ckpt_dir/run_summary.txt immediately sees what ran and what
    it scored, without having to cross-reference the aggregate results_csv,
    train.log, or the ablation config."""
    def fmt(v):
        return f"{v:.4f}" if isinstance(v, float) else "-"

    lines = [
        f"RUN SUMMARY -- {row['run_name']}",
        "=" * 60,
        f"Ablation config: {config_path}",
        f"Axis choice(s):  " + ", ".join(f"{a}={choice[a]}" for a in axis_names),
        f"Attempt:         {row['attempt']}",
        "",
        "Overrides applied (common + this run's axis overrides):",
        "  " + " ".join(common + overrides),
        "",
        f"Train exit code: {row['train_rc']} ({'OK' if row['train_rc'] == 0 else 'FAILED -- see train.log'})",
        f"Run status:      {row['status']}"
        + ("" if row["status"] == "ok" else " -- not ranked; the reason is in run_manifest.json"),
        "",
        "RESULTS",
        f"  best_valid_ap:    {fmt(row['best_valid_ap'])}",
        f"  best_valid_auroc: {fmt(row['best_valid_auroc'])}",
        "  (both validation numbers are from the saved best.ckpt's epoch)",
    ]
    if run_score:
        lines += [
            f"  eval_ap:          {fmt(row['eval_ap'])}",
            f"  eval_auroc:       {fmt(row['eval_auroc'])}",
        ]
    else:
        lines.append("  eval_ap / eval_auroc: not computed (run_score: false in this config -- smoke stage)")
    lines += [
        "",
        "Files in this folder:",
        "  best.ckpt / last.ckpt -- model checkpoints",
        "  train.log             -- full training stdout/stderr",
        "  training_metrics.csv  -- per-epoch valid_ap/valid_auroc/train_loss",
        "  resolved_train.yaml   -- the exact training configuration",
        "  run_manifest.json     -- source and checkpoint hashes, commands, status",
    ]
    if run_score:
        lines.append("  score.log             -- full eval-scoring stdout/stderr")
        lines.append("  resolved_score.yaml / score_metrics.json -- scoring configuration and metrics")
    lines += [
        "",
        f"Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
    ]
    with open(os.path.join(ckpt_dir, "run_summary.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def _run(cmd, log_path):
    """Stream subprocess output directly to disk, without retaining full GPU logs."""
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    log.info("$ %s", " ".join(cmd))
    with open(log_path, "w", encoding="utf-8") as f:
        proc = subprocess.run(cmd, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT,
                              env={**os.environ, "PYTHONUNBUFFERED": "1"})
    if proc.returncode != 0:
        log.error("command failed (rc=%d); see %s", proc.returncode, log_path)
    return proc.returncode, ""


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--dry-run", action="store_true",
                        help="Resolve and validate the planned runs without creating artifacts or executing them.")
    args = parser.parse_args()

    try:
        spec = OmegaConf.load(args.config)
        base_config = os.path.join(ROOT, str(spec.base_config))
        base = OmegaConf.load(base_config)
        output_root = os.path.abspath(os.path.join(ROOT, str(spec.get("output_root", "ablations"))))
        results_csv = os.path.abspath(os.path.join(
            ROOT, str(spec.get("results_csv", os.path.join(output_root, "results.csv")))
        ))
        common = [str(o) for o in spec.get("common_overrides", [])]
        run_score = bool(spec.get("run_score", True))

        axis_names, runs = _expand_runs(spec)
    except Exception as exc:
        parser.error(f"invalid ablation specification: {exc}")
    log.info("Planned %d run(s) across axes %s", len(runs), axis_names)

    if not runs:
        parser.error("the ablation spec expands to zero runs")

    attempt = spec.get("attempt_tag")
    if attempt is None:
        attempt = f"{time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())}-{uuid.uuid4().hex}"
    if not isinstance(attempt, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", attempt):
        parser.error("attempt_tag must be a nonempty string using letters, digits, '.', '_' or '-'")
    attempt_dir = os.path.join(output_root, attempt)
    if os.path.exists(attempt_dir):
        parser.error(f"attempt directory already exists: {attempt_dir}; choose a new attempt_tag")

    # Resolve every cell before starting any training (also for --dry-run).
    # Inject run paths before resolution so interpolations bind to this attempt.
    resolved_configs = {}
    for run_name, overrides, _ in runs:
        run_dir = os.path.join(attempt_dir, run_name)
        prediction_name = f"{os.path.basename(output_root)}__{attempt}__{run_name}"
        try:
            configured = OmegaConf.merge(base, OmegaConf.from_dotlist(common + overrides)).eval.predictions_base
            effective = OmegaConf.merge(base, OmegaConf.from_dotlist(common + overrides + [
                f"output.checkpoint_dir={run_dir}",
                f"experiment.run_name={prediction_name}",
                f"eval.predictions_base={_predictions_base(configured, output_root, attempt, run_name)}",
            ]))
            resolved_configs[run_name] = OmegaConf.create(
                OmegaConf.to_container(effective, resolve=True, throw_on_missing=True)
            )
        except Exception as exc:
            parser.error(f"invalid resolved configuration for {run_name}: {exc}")
    if args.dry_run:
        for run_name, overrides, _ in runs:
            print(run_name, "::", " ".join(common + overrides))
        return 0
    try:
        os.makedirs(attempt_dir, exist_ok=False)
    except FileExistsError:
        parser.error(f"attempt directory already exists: {attempt_dir}; choose a new attempt_tag")
    attempt_results_csv = os.path.join(attempt_dir, "results.csv")
    if os.path.isfile(results_csv):
        shutil.copyfile(results_csv, os.path.join(attempt_dir, "previous_results.csv"))
    OmegaConf.save(spec, os.path.join(attempt_dir, "ablation_spec.yaml"), resolve=True)
    OmegaConf.save(base, os.path.join(attempt_dir, "base_config.yaml"), resolve=True)
    log.info("Attempt %s: artifacts -> %s; latest results -> %s",
             attempt, attempt_dir, results_csv)

    results = []
    for i, (run_name, overrides, choice) in enumerate(runs, 1):
        run_dir = os.path.join(attempt_dir, run_name)
        os.makedirs(run_dir, exist_ok=False)
        log.info("=== [%d/%d] %s ===", i, len(runs), run_name)
        effective = resolved_configs[run_name]
        resolved_train = os.path.join(run_dir, "resolved_train.yaml")
        OmegaConf.save(effective, resolved_train, resolve=True)
        source_before = _source_provenance()
        train_cmd = [sys.executable, TRAIN_SCRIPT, "--config", resolved_train]
        provenance = {"schema_version": 1, "attempt": attempt, "run_name": run_name,
                      "source_before": source_before,
                      "environment": _environment(),
                      "resolved_train_sha256": _sha256(resolved_train),
                      "train_command": train_cmd, "score_command": None,
                      "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
        manifest_path = os.path.join(run_dir, "run_manifest.json")
        _write_json(manifest_path, provenance)
        rc, _ = _run(train_cmd, os.path.join(run_dir, "train.log"))

        row = {
            "run_name": run_name,
            **{a: choice[a] for a in axis_names},
            "train_rc": rc,
            "best_valid_ap": None,
            "best_valid_auroc": None,
            "eval_ap": None,
            "eval_auroc": None,
            "attempt": attempt,
            "run_dir": run_dir,
            "score_rc": None,
            "status": "train_failed" if rc else "ok",
            "predictions_path": None,
            "n_predictions": None,
            "n_positives": None,
            "checkpoint_epoch": None,
            "checkpoint_step": None,
            "checkpoint_monitor": str(effective.get("training", {}).get("monitor", "valid_ap")),
            "checkpoint_monitor_score": None,
            "checkpoint_sha256": None,
            "resolved_train_sha256": provenance["resolved_train_sha256"],
            "source_sha256": source_before["source_sha256"],
            "manifest_path": manifest_path,
            "error": None,
        }
        ckpt = os.path.join(run_dir, "best.ckpt")
        # Never promote partial or previous training metrics after a failed process.
        if rc == 0:
            metrics_csv = os.path.join(run_dir, "training_metrics.csv")
            if not os.path.isfile(ckpt):
                row["status"] = "checkpoint_missing"
            elif not os.path.isfile(metrics_csv):
                row["status"] = "train_metrics_missing"
            else:
                row["checkpoint_sha256"] = _sha256(ckpt)
                try:
                    row.update(_checkpoint_metrics(ckpt, metrics_csv, row["checkpoint_monitor"]))
                except Exception as exc:
                    row["status"] = "train_metrics_invalid"
                    row["error"] = str(exc)
        source_after_train = _source_provenance()
        provenance["source_after_train"] = source_after_train
        if row["status"] == "ok" and source_after_train["source_sha256"] != source_before["source_sha256"]:
            row["status"] = "source_changed"
            row["error"] = "Runtime source files changed during training"

        if run_score and row["status"] == "ok":
            # Score the exact frozen training configuration, with only scoring outputs changed.
            score_metrics_path = os.path.join(run_dir, "score_metrics.json")
            score_config = OmegaConf.merge(effective, {"eval": {
                "checkpoint": ckpt, "metrics_output": score_metrics_path}})
            resolved_score = os.path.join(run_dir, "resolved_score.yaml")
            OmegaConf.save(score_config, resolved_score, resolve=True)
            score_cmd = [sys.executable, SCORE_SCRIPT, "--config", resolved_score]
            provenance["score_command"] = score_cmd
            provenance["resolved_score_sha256"] = _sha256(resolved_score)
            _write_json(manifest_path, provenance)
            s_rc, _ = _run(score_cmd, os.path.join(run_dir, "score.log"))
            row["score_rc"] = s_rc
            if s_rc != 0:
                row["status"] = "score_failed"
            elif not os.path.isfile(score_metrics_path):
                row["status"] = "score_metrics_missing"
            else:
                try:
                    metrics = _score_metrics(score_metrics_path, ckpt, row["checkpoint_sha256"],
                                             bool(effective.eval.get("compute_metrics", False)))
                    row["predictions_path"] = metrics["predictions_path"]
                    row["n_predictions"] = metrics["n_predictions"]
                    row["n_positives"] = metrics["n_positives"]
                    row["eval_ap"] = metrics.get("average_precision")
                    row["eval_auroc"] = metrics.get("auroc")
                except Exception as exc:
                    row["status"] = "score_metrics_invalid"
                    row["error"] = str(exc)
            provenance["source_after_score"] = _source_provenance()
            if row["status"] == "ok" and provenance["source_after_score"]["source_sha256"] != source_before["source_sha256"]:
                row["status"] = "source_changed"
                row["error"] = "Runtime source files changed during scoring"

        if row["status"] != "ok":
            log.error("%s: %s", run_name, row["status"])
        provenance["result"] = row
        provenance["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        _write_json(manifest_path, provenance)
        try:
            _write_run_summary(run_dir, args.config, axis_names, choice, common, overrides,
                               row, run_score)
        except OSError as exc:  # a convenience file must not stop the remaining runs
            log.warning("%s: run_summary.txt not written: %s", run_name, exc)
        results.append(row)
        # Preserve every invocation; publish the conventional CSV only as a latest view.
        _write_results(attempt_results_csv, results)
        _write_results(results_csv, results)

    _print_summary(results)
    failures = sum(row["status"] != "ok" for row in results)
    log.info("Ablation complete: %d failed run(s). Attempt results -> %s; latest -> %s",
             failures, attempt_results_csv, results_csv)
    return 1 if failures else 0


def _write_results(path, results):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    temp_path = f"{path}.{uuid.uuid4().hex}.tmp"
    try:
        with open(temp_path, "x", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(results[0].keys()))
            writer.writeheader()
            writer.writerows(results)
        # Readers (including concurrent runners archiving the latest view) see a whole CSV.
        os.replace(temp_path, path)
    finally:
        if os.path.exists(temp_path):
            os.unlink(temp_path)


def _print_summary(results):
    ranked = sorted(
        (r for r in results if r["status"] == "ok"),
        key=lambda r: (r["best_valid_ap"] is None, -(r["best_valid_ap"] or 0.0)),
    )
    print("\n=== Successful ablations (ranked by checkpoint valid_ap) ===")
    print(f"{'run_name':<40} {'valid_ap':>10} {'valid_auroc':>12} {'eval_ap':>9} {'eval_auroc':>11}")
    for r in ranked:
        def fmt(v):
            return f"{v:.4f}" if isinstance(v, float) else "-"
        print(f"{r['run_name']:<40} {fmt(r['best_valid_ap']):>10} "
              f"{fmt(r['best_valid_auroc']):>12} {fmt(r['eval_ap']):>9} {fmt(r['eval_auroc']):>11}")
    failed = [r for r in results if r["status"] != "ok"]
    if failed:
        print("\n=== Failed/incomplete ablations (not ranked) ===")
        for r in failed:
            print(f"{r['run_name']}: {r['status']} "
                  f"(train_rc={r['train_rc']}, score_rc={r['score_rc']})")


if __name__ == "__main__":
    raise SystemExit(main())
