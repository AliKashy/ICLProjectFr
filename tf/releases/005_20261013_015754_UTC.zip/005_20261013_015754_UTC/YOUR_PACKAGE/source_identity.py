"""The V1 runtime source boundary used by run receipts and release checks.

Development tests and parked experiments can remain in an existing checkout;
changing them does not change the code that V1 executes. Files are discovered
from the actual tree, not an allowlist, so an unknown runtime module is recorded.
"""
from pathlib import Path


EXCLUDED_SOURCE_PREFIXES = (
    "tests/",
    "YOUR_PACKAGE/tests/",
    "YOUR_PACKAGE/future_experiments/",
    "YOUR_PACKAGE/phase5_pretrain/",  # Original pod path before parked-code reorganization.
    "runbook/2026-10-07/tests/",
    "runbook/2026-10-07/synthetic/",
)


def excluded_source_path(relative_path):
    """Exclude development/parked directories, hidden path components and caches."""
    relative_path = str(relative_path).replace("\\", "/")
    parts = relative_path.split("/")
    return ("__pycache__" in parts or any(part.startswith(".") for part in parts)
            or relative_path.startswith(EXCLUDED_SOURCE_PREFIXES))


def runtime_source_path(relative_path):
    """Whether a relative path belongs to the fraud/owner runtime Python tree."""
    relative_path = str(relative_path).replace("\\", "/")
    return (relative_path.startswith(("fraud/", "YOUR_PACKAGE/"))
            and relative_path.endswith(".py")
            and not excluded_source_path(relative_path))


def runtime_source_files(root):
    """Enumerate current files, including unknown runtime modules and dependencies."""
    root = Path(root)
    files = [path for folder in ("fraud", "YOUR_PACKAGE")
             for path in (root / folder).rglob("*.py")
             if path.is_file() and runtime_source_path(path.relative_to(root).as_posix())]
    files.extend(path for name in ("pyproject.toml", "requirements.txt")
                 if (path := root / name).is_file())
    return sorted(files)
