#!/usr/bin/env python3
"""Install only the verified package files into the existing project root."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import keyword
import os
from pathlib import Path, PurePosixPath
import tempfile
import zipfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def safe_path(root, rel):
    if not isinstance(rel, str):
        raise ValueError("invalid package path: " + str(rel))
    path = PurePosixPath(rel)
    if not rel or "\\" in rel or ":" in rel or path.is_absolute() or path.as_posix() != rel or any(p in (".", "..") for p in path.parts):
        raise ValueError("invalid package path: " + str(rel))
    current = root
    for index, part in enumerate(path.parts):
        current /= part
        if current.is_symlink():
            raise ValueError("symlink is not supported: " + str(current))
        if current.exists() and index < len(path.parts) - 1 and not current.is_dir():
            raise ValueError("parent is not a directory: " + str(current))
    return current


def write_file(path, data, mode=0o644):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix=".package-install-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temp, mode)
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def install(root, target):
    root = Path(root).resolve()
    raw_target = Path(os.path.abspath(Path(target).expanduser()))
    for parent in (raw_target, *raw_target.parents):
        if parent.is_symlink():
            raise ValueError("target path contains a symlink: " + str(parent))
    target = raw_target.resolve()
    if target == root or target.is_relative_to(root):
        raise ValueError("target must be the existing project root, outside the extracted package")
    if not target.is_dir() or not all(safe_path(target, name).is_dir() for name in ("fraud", "src")):
        raise ValueError("target must be an existing project root containing fraud/ and src/")
    meta = json.loads(safe_path(root, "PACKAGE.json").read_text())
    receipt = json.loads(safe_path(root, "PERSONALIZATION.json").read_text())
    if (receipt.get("package"), receipt.get("source_commit")) != (meta["package"], meta["source_commit"]):
        raise ValueError("personalization receipt does not match this package")
    name = receipt["replacements"]["YOUR_PACKAGE"]
    if not isinstance(name, str) or not name.isidentifier() or keyword.iskeyword(name) or name in {"YOUR_PACKAGE", "fraud", "src", "runbook"}:
        raise ValueError("invalid personalized package name")
    expected_paths = {rel.replace("YOUR_PACKAGE", name) for rel in meta["files_sha256"]} | {"PACKAGE.json"}
    if set(receipt["files_sha256"]) != expected_paths:
        raise ValueError("personalized file list does not match this package")
    pending = []
    for rel, expected in receipt["files_sha256"].items():
        if rel.startswith(("fraud/", "src/")) or rel in {"pyproject.toml", "requirements.txt"}:
            raise ValueError("original dependency must not be installed or replaced: " + rel)
        source = safe_path(root, rel)
        if not source.is_file():
            raise ValueError("personalized file is missing: " + rel)
        data = source.read_bytes()
        if digest(data) != expected:
            raise ValueError("personalized file changed: " + rel)
        pending.append((rel, data))
    pending.append(("PERSONALIZATION.json", safe_path(root, "PERSONALIZATION.json").read_bytes()))
    dependencies = []
    for rel, expected in meta.get("existing_dependency_files_sha256_lf", {}).items():
        path = safe_path(target, rel)
        actual = digest(path.read_bytes().replace(b"\r\n", b"\n")) if path.is_file() else None
        dependencies.append({"path": rel, "expected_sha256_lf": expected, "observed_sha256_lf": actual,
                             "matches_source_snapshot": actual == expected, "action": "not_modified"})
    for rel in meta.get("existing_dependency_files_observed_only", {}):  # expected hashes held privately (they would reveal names)
        path = safe_path(target, rel)
        actual = digest(path.read_bytes().replace(b"\r\n", b"\n")) if path.is_file() else None
        dependencies.append({"path": rel, "expected_sha256_lf": None, "observed_sha256_lf": actual,
                             "matches_source_snapshot": None, "action": "not_modified",
                             "note": "compared privately after this receipt is returned"})
    records = []
    # Validate every destination before changing any file.
    for rel, data in pending:
        destination = safe_path(target, rel)
        if destination.exists() and not destination.is_file():
            raise ValueError("destination is not a regular file: " + rel)
        records.append({"path": rel, "before_sha256": digest(destination.read_bytes()) if destination.exists() else None,
                        "after_sha256": digest(data), "action": "replace" if destination.exists() else "add"})
    history = safe_path(target, "runs/install")
    if history.exists() and not history.is_dir():
        raise ValueError("installation history path is not a directory")
    if not isinstance(meta["package"], str) or not meta["package"] or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-" for c in meta["package"]):
        raise ValueError("invalid package identifier")
    history.mkdir(parents=True, exist_ok=True)
    record_dir = Path(tempfile.mkdtemp(prefix=meta["package"] + "_", dir=history))
    receipt_path = record_dir / "INSTALLATION.json"
    backup_path = record_dir / "REPLACED_FILES.zip"
    with zipfile.ZipFile(backup_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for row in records:
            if row["before_sha256"] is not None and row["before_sha256"] != row["after_sha256"]:
                destination = safe_path(target, row["path"])
                archive.write(destination, row["path"])
    record = {"package": meta["package"], "source_commit": meta["source_commit"], "status": "installation_started",
              "installed_at_utc": datetime.now(timezone.utc).isoformat(), "target": str(target),
              "unlisted_files": "preserved", "files": records, "receipt": str(receipt_path),
              "existing_dependencies": dependencies,
              "replaced_files_backup": str(backup_path), "backup_sha256": digest(backup_path.read_bytes())}
    write_file(receipt_path, (json.dumps(record, indent=2) + "\n").encode())
    for rel, data in pending:
        write_file(safe_path(target, rel), data, 0o755 if rel.endswith(".sh") else 0o644)
    for row in records:
        if digest(safe_path(target, row["path"]).read_bytes()) != row["after_sha256"]:
            raise ValueError("installed file verification failed: " + row["path"])
    record["status"] = "installed_and_verified"
    write_file(receipt_path, (json.dumps(record, indent=2) + "\n").encode())
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", type=Path, required=True)
    args = parser.parse_args()
    try:
        result = install(Path(__file__).parent, args.target)
    except (ValueError, KeyError, OSError, UnicodeError) as error:
        parser.exit(1, "Installation stopped: " + str(error) + "\n")
    print("Installed and verified:", result["package"])
    print("Project root:", result["target"])
    print("Receipt:", result["receipt"])
    print("Previous changed code:", result["replaced_files_backup"])
    print("Unlisted files were preserved.")


if __name__ == "__main__":
    main()
