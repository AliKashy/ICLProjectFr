#!/usr/bin/env python3
# Written 2026-10-19 for the owner's public question 19. Read-only: it reads ledgers, run folders,
# checkpoints' epoch counters, account ids and saved predictions, and writes aggregates only (counts, scores per
# epoch, AP per subset) into one new return folder. No row, identifier or single-row score is written there.
"""Quick checks for the V1 record and the V2 plan (2026-10-19).

Checks (letters as in the public question 19):
  a  every V1 run's validation AP, AUROC and loss at every epoch, and the epoch/step of its best.ckpt and last.ckpt.
     Shows whether B-H05 (best epoch 0) went wrong. CPU, seconds.
  b  whether the training folder and the evaluation folder share accounts: file numbers in each folder, then the
     account overlap of one file number present in both, and of V1's own split files. Counts only. CPU, minutes.
  c  the batch settings each V1 run actually trained with (resolved_train.yaml). CPU, seconds.
  e  paired_report.py again on the saved V1 predictions, with B-ALLPOS-H5 read against REF-SINGLE, B-H00, B-H10,
     B-H15, B-H20 and A-H15 on the rows at chunk position 5, then 4, 3, 2, 1, 0. CPU; the longest step.
  f  CPU (required at step 1): same-second rows in training files 1-10 and evaluation files 8000-8010 (research note 4 of 2026-10-19 test 2,
     with audit findings 21 and 22 of 2026-10-19): how many rows and frauds have an earlier same-time row of their account in the
     original author's order, split by advice code / same amount / neither, and whether the balance and limit
     fields show the earlier row applied first. Counts only.
  g  CPU (required at step 1): whether the balance and limit fields are really "before this transaction" (feature review note 1 of 2026-10-19):
     for adjacent rows of one account in training files 1-10, whether the later row's value equals the earlier
     value minus the earlier amount (before), minus its own amount (after), or is unchanged; plus rows whose amount
     exceeds or exactly uses what is left, by label. Counts only.
  d  GPU, no training, only on the owner's word: score the last.ckpt of B-H05 and A-H05 on the evaluation files. Writes one new
     prediction file per run under a new storage prefix (nothing existing is touched); only the score summaries
     enter the return folder.

From the project root, in the project's Python environment (runbook/v2/RUNBOOK.md step 1b gives the exact lines):
    python runbook/2026-10-19/quick_checks.py                       # a, b, c, e, f, g (every CPU check; question 19 decided (a))
    python runbook/2026-10-19/quick_checks.py --only a,b,c          # the quick part only
    python runbook/2026-10-19/quick_checks.py --only d              # the GPU check, on the owner's word
    python runbook/2026-10-19/quick_checks.py --dry-run             # print what would run, read nothing large
Send back the folder it prints: runs/returns/quick_checks_<UTC time>/.
"""
import argparse
import csv
import datetime as _dt
import glob
import hashlib
import json
import os
import re
import subprocess
import sys
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
V1_RUNBOOK = os.path.join(ROOT, "runbook", "2026-10-07")
for p in (ROOT, os.path.join(ROOT, "src"), V1_RUNBOOK):
    if p not in sys.path:
        sys.path.insert(0, p)

# B-H15 and B-H20 were retrained by hand; their ledger rows read train_failed. Same cells and stamps as the owner's
# runbook/2026-10-07/build_run_table_v1.py (MANUAL_OVERRIDES), used only to find their run folders.
MANUAL_RUNS = {
    "B-H15": ("ablations/arch_b_hier/history_h15_h20/B-H15-4d71f33d0e9644b4be7211290b2fb50f", "history-h15"),
    "B-H20": ("ablations/arch_b_hier/history_h15_h20/B-H20-1dfa4d00fd924637950e7c6f02c3f887", "history-h20"),
}
# audit finding 20 of 2026-10-19: these folders also hold the killed runner's files, so their resolved_train.yaml may be the
# killed run's (the retrain is recorded as using the same config).
MANUAL_SOURCE = "manual retrain (build_run_table_v1.py); config file may predate the retrain"
DEPTH_ALLPOS = "B-ALLPOS-H5"
DEPTH_OTHERS = ["REF-SINGLE", "B-H00", "B-H10", "B-H15", "B-H20", "A-H15"]
DEFAULT_LEDGERS = ["runs/run_log.csv", "runs/returns/parallel_v1_005_all/run_log_all.csv"]
DEFAULT_RUN_TABLE = "reviewer_update_v1_20261013/analysis_outputs/run_table.csv"


def package_versions():
    from importlib import metadata
    out = []
    modules = {"pytorch-lightning": "pytorch_lightning"}
    for name in ("pandas", "numpy", "pyarrow", "torch", "pytorch-lightning", "xgboost"):  # xgboost: lean plan D8
        try:
            out.append(f"{name} {metadata.version(name)}")
        except metadata.PackageNotFoundError:
            try:  # a differently named wheel (xgboost-cpu ships the xgboost module): ask the module itself, as data_look does
                out.append(f"{name} {getattr(__import__(modules.get(name, name)), '__version__', 'installed')}")
            except Exception:  # noqa: BLE001
                out.append(f"{name} not installed")
    return ", ".join(out)


def utc_stamp():
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")


class Return:
    """The return folder: STATUS.txt (one line per event) and the files of each check."""

    def __init__(self, root, dry_run):
        self.dry_run = dry_run
        self.path = os.path.join(root, f"quick_checks_{utc_stamp()}")
        if not dry_run:
            os.makedirs(self.path, exist_ok=False)

    def status(self, line):
        line = f"{_dt.datetime.now(_dt.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')} {line}"
        print(line, flush=True)
        if not self.dry_run:
            with open(os.path.join(self.path, "STATUS.txt"), "a", encoding="utf-8") as f:
                f.write(line + "\n")

    def file(self, *parts):
        path = os.path.join(self.path, *parts)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        return path

    def write_json(self, name, obj):
        with open(self.file(name), "w", encoding="utf-8") as f:
            json.dump(obj, f, indent=2, sort_keys=True, default=str)
            f.write("\n")

    def write_csv(self, name, rows, fields):
        with open(self.file(name), "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
            w.writeheader()
            w.writerows(rows)


# --------------------------------------------------------------------------------------------------------------- #
# Finding the V1 run folders
# --------------------------------------------------------------------------------------------------------------- #
def pick_ledger(arg):
    candidates = [arg] if arg else DEFAULT_LEDGERS
    for c in candidates:
        path = c if os.path.isabs(c) else os.path.join(ROOT, c)
        if os.path.isfile(path):
            return path
    raise FileNotFoundError(f"no ledger found (tried {candidates}); pass --ledger <run_log.csv>")


def find_run_dirs(ledger):
    """{cell: {"run_dir", "source"}} for the 15 V1 cells, or {"missing": reason}."""
    import analysis_runs  # runbook/2026-10-07

    try:
        found = analysis_runs.find_runs(ledger)
    except SystemExit as exc:  # collect_returns stops on a malformed ledger with SystemExit; report it, do not exit
        raise RuntimeError(f"the ledger reader refused {ledger}: {exc}") from None
    run_names = {name: run_name for name, _root, run_name, _cfg in analysis_runs.V1_RUNS}
    out = {}
    for cell, rec in found.items():
        if rec.get("attempt_dir"):
            run_dir = os.path.join(rec["attempt_dir"], run_names[cell])
            out[cell] = ({"run_dir": run_dir, "source": "ledger (status ok)"} if os.path.isdir(run_dir)
                         else {"missing": f"ledger run folder not found: {run_dir}"})
        else:
            out[cell] = {"missing": rec.get("status", "not found")}
    for cell, (attempt, run_name) in MANUAL_RUNS.items():
        if "run_dir" not in out.get(cell, {}):
            run_dir = os.path.join(ROOT, attempt, run_name)
            out[cell] = ({"run_dir": run_dir, "source": MANUAL_SOURCE}
                         if os.path.isdir(run_dir) else {"missing": f"manual run folder not found: {run_dir}"})
    return out


def checkpoint_counters(path):
    """(epoch, global_step) stored in a Lightning checkpoint, or (None, None). Loads on CPU; writes nothing."""
    if not os.path.isfile(path):
        return None, None
    import torch

    ckpt = torch.load(path, map_location="cpu", weights_only=False)
    epoch, step = ckpt.get("epoch"), ckpt.get("global_step")
    del ckpt
    return (int(epoch) if epoch is not None else None), (int(step) if step is not None else None)


# --------------------------------------------------------------------------------------------------------------- #
# a: per-epoch validation curves
# --------------------------------------------------------------------------------------------------------------- #
PIN_CELLS = {"B-H05": "R05", "B-H15": "R15", "B-H20": "R20"}  # the three V1 checkpoints V2 pins (RUNBOOK step 1d)


def check_a(ret, runs):
    rows, summary, fields = [], [], ["cell", "run_dir", "epoch", "step"]
    for cell in sorted(runs):
        info = runs[cell]
        if "run_dir" not in info:
            summary.append(f"{cell}: run folder not found ({info['missing']})")
            continue
        run_dir = info["run_dir"]
        best = checkpoint_counters(os.path.join(run_dir, "best.ckpt"))
        last = checkpoint_counters(os.path.join(run_dir, "last.ckpt"))
        metrics_path = os.path.join(run_dir, "training_metrics.csv")
        if not os.path.isfile(metrics_path):
            summary.append(f"{cell}: no training_metrics.csv in {run_dir}")
            continue
        with open(metrics_path, newline="", encoding="utf-8") as f:
            table = list(csv.DictReader(f))
        for r in table:
            for k in r:
                if k not in fields:
                    fields.append(k)
            r = dict(r, cell=cell, run_dir=run_dir)
            r["is_best_ckpt"] = str(best[0] is not None and str(best[0]) == str(r.get("epoch")))
            r["is_last_ckpt"] = str(last[0] is not None and str(last[0]) == str(r.get("epoch")))
            rows.append(r)
        aps = [(int(r["epoch"]), float(r["valid_ap"])) for r in table if r.get("valid_ap") not in (None, "")]
        if aps:
            peak = max(aps, key=lambda t: t[1])
            trail = ", ".join(f"e{e}={ap:.4f}" for e, ap in aps)
            summary.append(f"{cell}: best.ckpt epoch {best[0]} step {best[1]}; last.ckpt epoch {last[0]} step "
                           f"{last[1]}; peak valid AP {peak[1]:.4f} at epoch {peak[0]}; valid AP by epoch: {trail}")
        else:
            summary.append(f"{cell}: training_metrics.csv has no valid_ap column")
    for extra in ("is_best_ckpt", "is_last_ckpt"):
        fields.append(extra)
    ret.write_csv("a_epochs.csv", rows, fields)
    # the three pin folders as export lines, so step 1d types nothing by hand (RUNBOOK: cat env_additions.sh >> runs/v2/env.sh)
    exports = [f"export {var}={runs[cell]['run_dir']}" for cell, var in PIN_CELLS.items() if "run_dir" in runs.get(cell, {})]
    missing_pins = [cell for cell in PIN_CELLS if "run_dir" not in runs.get(cell, {})]
    summary += exports + [f"pin folder not found for {cell}" for cell in missing_pins]
    with open(ret.file("a_summary.txt"), "w", encoding="utf-8") as f:
        f.write("Per-epoch validation of every V1 run (read from each run's training_metrics.csv).\n\n")
        f.write("\n".join(summary) + "\n")
    with open(ret.file("env_additions.sh"), "w", encoding="utf-8") as f:
        f.write("# from quick check a; RUNBOOK step 1d appends this to runs/v2/env.sh\n" + "\n".join(exports) + "\n")
    if exports:  # the exact line RUNBOOK step 1d pastes, so no folder name is typed by hand
        ret.status(f"for runs/v2/env.sh: cat {os.path.abspath(ret.file('env_additions.sh'))} >> runs/v2/env.sh; source runs/v2/env.sh")
    return summary


# --------------------------------------------------------------------------------------------------------------- #
# b: account overlap between the two data folders
# --------------------------------------------------------------------------------------------------------------- #
def resolved(run_dir, name):
    from omegaconf import OmegaConf

    return OmegaConf.load(os.path.join(run_dir, name))


def folder_numbers(fs, base):
    """Sorted part_<n> numbers in a folder (S3 through fs, or a local folder)."""
    from fraud.data.s3_utils import strip_scheme

    if fs is not None:
        names = fs.glob(strip_scheme(base).rstrip("/") + "/part_*.parquet")
    else:
        names = glob.glob(os.path.join(base, "part_*.parquet"))
    nums = []
    for n in names:
        m = re.search(r"part_(\d+)\.parquet$", str(n))
        if m:
            nums.append(int(m.group(1)))
    return sorted(set(nums))


def account_key(v):
    """One text key per account, so int64 101, 101.0, "101" and "000101" match (audit finding 17 of 2026-10-19)."""
    if v is None or (isinstance(v, float) and v != v):
        return None
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    if isinstance(v, bytes):
        v = v.decode("utf-8", "replace")
    k = str(v).strip()
    return (k.lstrip("0") or "0") if k.isdigit() else k


def account_set(fs, path, account_col, types):
    """Normalised account keys of one file; adds the column's stored type to `types`."""
    import pyarrow.parquet as pq
    from fraud.data.s3_utils import strip_scheme

    table = pq.ParquetDataset(strip_scheme(path) if fs is not None else path, filesystem=fs).read(
        columns=[account_col])
    types.add(str(table.schema.field(account_col).type))
    return {k for k in map(account_key, table.column(account_col).to_pylist()) if k is not None}


def check_b(ret, runs, probe_number):
    from YOUR_PACKAGE.v2.storage import thin_read_filesystem

    ref = runs.get("B-H05", {}).get("run_dir") or next(v["run_dir"] for v in runs.values() if "run_dir" in v)
    # resolved_train.yaml holds the eval section too; validation-only runs (A-H00, A-H05) have no resolved_score.yaml.
    train_cfg = score_cfg = resolved(ref, "resolved_train.yaml")
    train_base, eval_base = str(train_cfg.data.train_base), str(score_cfg.eval.base)
    account_col = str(train_cfg.data.account_col)
    fs = thin_read_filesystem(str(train_cfg.s3.cred_path)) if train_base.startswith("s3") else None
    result = {"training_folder": train_base, "evaluation_folder": eval_base, "account_column": account_col}

    t_nums, e_nums = folder_numbers(fs, train_base), folder_numbers(fs, eval_base)
    common = sorted(set(t_nums) & set(e_nums))
    result["training_folder_files"] = {"count": len(t_nums), "min": t_nums[0] if t_nums else None,
                                       "max": t_nums[-1] if t_nums else None}
    result["evaluation_folder_files"] = {"count": len(e_nums), "min": e_nums[0] if e_nums else None,
                                         "max": e_nums[-1] if e_nums else None}
    result["file_numbers_in_both_folders"] = len(common)
    types = {train_base: set(), eval_base: set()}

    if common:
        n = probe_number if probe_number in common else common[0]
        a = account_set(fs, f"{train_base.rstrip('/')}/part_{n}.parquet", account_col, types[train_base])
        b = account_set(fs, f"{eval_base.rstrip('/')}/part_{n}.parquet", account_col, types[eval_base])
        result["same_number_probe"] = {"file_number": n, "training_file_accounts": len(a),
                                       "evaluation_file_accounts": len(b), "accounts_in_both": len(a & b)}
        del a, b

    # V1's own split files: training 1-10 and validation 4950-4954 against evaluation 8000-8010.
    v1 = {"train": (train_base, int(train_cfg.data.train_start), int(train_cfg.data.train_end)),
          "validation": (str(train_cfg.data.val_base), int(train_cfg.data.val_start), int(train_cfg.data.val_end)),
          "evaluation": (eval_base, int(score_cfg.eval.file_start), int(score_cfg.eval.file_end))}
    sets = {}
    for split, (base, start, end) in v1.items():
        acc = set()
        for i in range(start, end + 1):
            acc |= account_set(fs, f"{base.rstrip('/')}/part_{i}.parquet", account_col, types.setdefault(base, set()))
        sets[split] = acc
    result["v1_splits"] = {
        "files": {k: f"{v[1]}-{v[2]}" for k, v in v1.items()},
        "accounts": {k: len(v) for k, v in sets.items()},
        "train_and_validation": len(sets["train"] & sets["validation"]),
        "train_and_evaluation": len(sets["train"] & sets["evaluation"]),
        "validation_and_evaluation": len(sets["validation"] & sets["evaluation"]),
    }
    del sets
    result["account_column_types"] = {k: sorted(v) for k, v in types.items()}
    result["account_key"] = "text, surrounding spaces and leading zeros of all-digit values removed"
    probe = result.get("same_number_probe")
    v1_line = (f" V1's own files: training and evaluation share {result['v1_splits']['train_and_evaluation']} "
               f"accounts, validation and evaluation {result['v1_splits']['validation_and_evaluation']}.")
    if probe is None:
        reading = ("No file number exists in both folders, so there is no same-number probe; the V1-split counts "
                   "are the evidence of shared accounts.")
    elif probe["accounts_in_both"] > 0:
        reading = (f"File {probe['file_number']} in both folders shares {probe['accounts_in_both']} of "
                   f"{probe['training_file_accounts']} and {probe['evaluation_file_accounts']} accounts: at least this "
                   "file number holds the same accounts in both folders. A V2 split must never use one file number in "
                   "both, and the full overlap check across every selected block still decides (plan review item 19-3).")
    else:
        reading = (f"File {probe['file_number']} in both folders shares no account: same file numbers do not "
                   "mean same accounts.")
    reading += v1_line
    if len({t for v in types.values() for t in v}) > 1:
        reading += (f" The account column is stored as {result['account_column_types']}; the comparison used "
                    "normalised text keys.")
    result["reading"] = reading
    ret.write_json("b_folder_overlap.json", result)
    return [reading, f"V1 splits, accounts in two splits: {result['v1_splits']}"]


# --------------------------------------------------------------------------------------------------------------- #
# c: batch settings each run trained with
# --------------------------------------------------------------------------------------------------------------- #
def check_c(ret, runs):
    rows, lines = [], []
    for cell in sorted(runs):
        info = runs[cell]
        if "run_dir" not in info or not os.path.isfile(os.path.join(info["run_dir"], "resolved_train.yaml")):
            lines.append(f"{cell}: no resolved_train.yaml found")
            continue
        cfg = resolved(info["run_dir"], "resolved_train.yaml")
        bs, acc = cfg.training.get("batch_size"), cfg.training.get("accumulate_grad_batches", 1)
        data = cfg.get("data", {})
        rows.append({"cell": cell, "batch_size": bs, "accumulate_grad_batches": acc,
                     "effective_batch": (int(bs) * int(acc)) if bs is not None else "",
                     "history_len": cfg.get("sequence", {}).get("history_len", "") if "sequence" in cfg else "",
                     # the V2 validity gate compares EPOCH_VAL (4950-4954) with these runs' validation AP: the
                     # files each run validated on must be the same (end-to-end review 2026-10-20, DA-38)
                     "val_start": data.get("val_start", ""), "val_end": data.get("val_end", ""),
                     "train_start": data.get("train_start", ""), "train_end": data.get("train_end", ""),
                     "artifact_version": cfg.get("artifacts", {}).get("version", ""),
                     "source": info["source"]})
        lines.append(f"{cell}: {bs} x {acc}; validation files {data.get('val_start')}-{data.get('val_end')}"
                     + (" (config file may predate the retrain)" if info["source"] == MANUAL_SOURCE else ""))
    ret.write_csv("c_batch_settings.csv", rows,
                  ["cell", "batch_size", "accumulate_grad_batches", "effective_batch", "history_len", "val_start", "val_end",
                   "train_start", "train_end", "artifact_version", "source"])
    return lines


# --------------------------------------------------------------------------------------------------------------- #
# e: depth-matched paired_report re-run
# --------------------------------------------------------------------------------------------------------------- #
def run_table_runs(path):
    with open(path, newline="", encoding="utf-8") as f:
        return {r.get("run", "").strip() for r in csv.DictReader(f)}


def child_env():
    env = dict(os.environ)
    env["PYTHONPATH"] = os.pathsep.join([os.path.join(ROOT, "src"), ROOT, env.get("PYTHONPATH", "")]).rstrip(os.pathsep)
    return env


E_NOTE = ("Each position_<k> folder compares B-ALLPOS-H5 with the other runs on the same rows: the rows at chunk "
          "position k. Only position 0 against REF-SINGLE and B-H00 is depth-matched (none of them sees history). "
          "Against B-H10, B-H15, B-H20 and A-H15 the other model sees up to 10-20 earlier rows while B-ALLPOS-H5 "
          "sees k. Each of those lines is the AP difference between two differently trained models on the same rows: "
          "it mixes that history gap with every other difference between the runs (all-position loss, batches, the "
          "epoch picked, and architecture A for A-H15). It is neither the effect of history alone nor an estimate of "
          "what sliding would recover. Rows differ from one position to the next, so do not compare lines across "
          "positions. 6 positions x 6 runs = 36 intervals, none corrected for multiple comparisons; read them as "
          "exploratory (audit finding 18 of 2026-10-19).")


def check_e(ret, run_table, positions, cred, extra_args, dry_run):
    path = run_table if os.path.isabs(run_table) else os.path.join(ROOT, run_table)
    if not os.path.isfile(path):
        raise FileNotFoundError(f"run table not found: {path}; pass --run-table <the V1 finalist run_table.csv>")
    missing = sorted({DEPTH_ALLPOS, *DEPTH_OTHERS} - run_table_runs(path))
    if missing:
        raise ValueError(f"the run table lacks {missing}; pass the V1 finalist run table with --run-table")
    lines = []
    if not dry_run:
        os.makedirs(os.path.join(ret.path, "e_depth_matched"), exist_ok=False)
        with open(os.path.join(ret.path, "e_depth_matched", "READ_FIRST.txt"), "w", encoding="utf-8") as f:
            f.write(E_NOTE + "\n")
    for k in positions:
        out = os.path.join(ret.path, "e_depth_matched", f"position_{k}")
        cmd = [sys.executable, os.path.join(V1_RUNBOOK, "paired_report.py"), "--runs", path, "--out-dir", out,
               "--depth-matched", f"{DEPTH_ALLPOS}:{','.join(DEPTH_OTHERS)}", "--depth-position", str(k)]
        if cred:
            cmd += ["--cred", cred]
        cmd += extra_args
        ret.status(f"e: position {k}: {' '.join(cmd)}")
        if dry_run:
            continue
        os.makedirs(out, exist_ok=False)
        with open(os.path.join(out, "paired_report.log"), "w", encoding="utf-8") as log:
            rc = subprocess.call(cmd, cwd=ROOT, env=child_env(), stdout=log, stderr=subprocess.STDOUT)
        lines.append(f"position {k}: paired_report exit {rc}")
        ret.status(f"e: position {k} finished, exit {rc}")
    bad = [x for x in lines if not x.endswith(" exit 0")]
    if bad:  # every position still ran; the check fails so the last line and e_error.txt say so
        raise RuntimeError(f"paired_report failed ({'; '.join(bad)}); see e_depth_matched/position_<k>/paired_report.log")
    return [E_NOTE] + lines


# --------------------------------------------------------------------------------------------------------------- #
# d: score B-H05's and A-H05's last.ckpt (GPU, optional)
# --------------------------------------------------------------------------------------------------------------- #
def check_d(ret, runs, cells, dry_run):
    lines = []
    for cell in cells:
        try:
            lines += score_last_ckpt(ret, runs, cell, dry_run)
        except Exception as exc:  # noqa: BLE001 - one missing run must not stop the other
            lines.append(f"d: {cell}: not scored: {exc}")
            ret.status(f"d: {cell}: not scored: {exc}")
    if any("not scored" in x or "scoring failed" in x for x in lines):
        raise RuntimeError("; ".join(lines))
    return lines


def best_ckpt_ap(run_dir):
    """(evaluation AP of best.ckpt, where it came from): the runner's score_metrics.json, else the newest ok post-score
    of this exact best.ckpt with the frozen evaluation range (analysis_runs.post_scored's rule)."""
    path = os.path.join(run_dir, "score_metrics.json")
    if os.path.isfile(path):
        with open(path, encoding="utf-8") as f:
            return json.load(f).get("average_precision"), "runner score"
    best = os.path.join(run_dir, "best.ckpt")
    if not os.path.isfile(best):
        return None, "no best.ckpt"
    h = hashlib.sha256()
    with open(best, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    root = os.path.join(run_dir, "post_score")
    for name in sorted(os.listdir(root), reverse=True) if os.path.isdir(root) else []:
        try:
            with open(os.path.join(root, name, "post_score_manifest.json"), encoding="utf-8") as f:
                man = json.load(f)
        except (OSError, ValueError):
            continue
        if (man.get("status") == "ok" and man.get("eval_range_override") is None
                and man.get("checkpoint_sha256") == h.hexdigest()):
            return (man.get("metrics") or {}).get("average_precision"), f"post-score {name}"
    return None, "no runner score or matching post-score found"


def score_last_ckpt(ret, runs, cell, dry_run):
    info = runs.get(cell, {})
    if "run_dir" not in info:
        raise FileNotFoundError(f"{cell} run folder not found ({info.get('missing')})")
    run_dir = info["run_dir"]
    last = os.path.join(run_dir, "last.ckpt")
    if not os.path.isfile(last):
        raise FileNotFoundError(f"no last.ckpt in {run_dir}")
    epoch, step = checkpoint_counters(last)
    best_epoch, _ = checkpoint_counters(os.path.join(run_dir, "best.ckpt"))
    # The runner's resolved_score.yaml is resolved_train.yaml plus eval.checkpoint and eval.metrics_output, both
    # overridden below; A-H05 (validation-only, scored post hoc) has only resolved_train.yaml.
    score_cfg = resolved(run_dir, "resolved_train.yaml")
    stamp = os.path.basename(ret.path)
    predictions_base = f"{str(score_cfg.eval.predictions_base).rstrip('/')}/{stamp}_last_ckpt"
    out_dir = os.path.join(ret.path, "d_last_ckpt", cell)
    metrics = os.path.join(out_dir, "score_metrics.json")
    phase = "phase4a" if cell.startswith("A-") else "phase4b"  # the runner each family was trained and scored with
    cmd = [sys.executable, os.path.join(ROOT, "YOUR_PACKAGE", phase, "scripts", "score_sequential.py"),
           "--config", os.path.join(run_dir, "resolved_train.yaml"),
           f"eval.checkpoint={last}", f"eval.predictions_base={predictions_base}", f"eval.metrics_output={metrics}",
           "eval.compute_metrics=true"]
    ret.status(f"d: {cell} last.ckpt is epoch {epoch}, step {step}; {' '.join(cmd)}")
    if dry_run:
        return [f"d: would score {cell} last.ckpt (epoch {epoch}, step {step})"]
    try:
        import torch
        if not torch.cuda.is_available():
            ret.status("d: WARNING no GPU visible; scoring runs on the CPU and will be slow")
    except ImportError:
        pass
    os.makedirs(out_dir, exist_ok=False)
    with open(os.path.join(out_dir, "score.log"), "w", encoding="utf-8") as log:
        rc = subprocess.call(cmd, cwd=ROOT, env=child_env(), stdout=log, stderr=subprocess.STDOUT)
    if rc != 0 or not os.path.isfile(metrics):
        return [f"d: {cell}: scoring failed, exit {rc} (see d_last_ckpt/{cell}/score.log)"]
    with open(metrics, encoding="utf-8") as f:
        m = json.load(f)
    best_ap, best_source = best_ckpt_ap(run_dir)
    line = (f"d: {cell} last.ckpt (epoch {epoch}) evaluation AP {m.get('average_precision')}, AUROC {m.get('auroc')}, "
            f"rows {m.get('n_predictions')}; its best.ckpt (epoch {best_epoch}) scored AP {best_ap} ({best_source})")
    with open(os.path.join(out_dir, "summary.txt"), "w", encoding="utf-8") as f:
        f.write(line + "\nDiagnostic only: an epoch picked by evaluation AP is never a result.\n")
    return [line]


# --------------------------------------------------------------------------------------------------------------- #
# f: same-second rows (research note 4 of 2026-10-19 test 2, with audit findings 21 and 22 of 2026-10-19 and T3-T6)
# --------------------------------------------------------------------------------------------------------------- #
# Three of these are defined as "before this transaction" in fraud/configs/predictors.csv; the fourth only as
# "Available daily merchandise limit", so it is reported apart and labelled unconfirmed.
STATE_FIELDS = {"total_available_balance_amt": "before", "available_daily_cash_limit_amt": "before",
                "remain_day_merchandise_lmt_amt": "before", "avlble_merch_day_cash_lmt_amt": "unconfirmed"}
ADVICE_COL = "transaction_advice_xcd"
CENT = 0.01


def _counter():
    return {"rows": 0, "frauds": 0, "fraud_accounts": set()}


def _add(c, is_fraud, acct):
    c["rows"] += int(is_fraud.size)
    f = is_fraud.astype(bool)
    c["frauds"] += int(f.sum())
    c["fraud_accounts"].update(acct[f].tolist())


def _close(c):
    return {"rows": c["rows"], "frauds": c["frauds"], "fraud_accounts": len(c["fraud_accounts"])}


def same_second_file(df, cols, positive, acc):
    """Adds one file's counts to `acc` and returns the file's account keys. Only counts and account-key sets are
    kept, in memory; no row leaves this function."""
    import numpy as np
    import pandas as pd

    a_col, t_col, tie_col, y_col, amt_col = cols
    acc["rows"] += len(df)
    t = pd.to_datetime(df[t_col], errors="coerce")
    acc["unparseable_time"] += int(t.isna().sum())
    # Nanoseconds whatever the stored unit: a parquet timestamp[us] stays [us] in pandas, so astype("int64") would give
    # microseconds (feature review note 6 of 2026-10-19). Same conversion as V1's order_key (YOUR_PACKAGE/phase4b/sequence_builder.py:378).
    ns = t.to_numpy(dtype="datetime64[ns]").astype("int64")
    acc["rows_with_subsecond_part"] += int(((ns % 1_000_000_000) != 0)[t.notna().to_numpy()].sum())
    # The original author's exact order: the stored columns, stable sort (fraud/data/sequence_builder.py:171-178).
    df = df.reset_index(drop=True)
    order = df.sort_values([a_col, t_col, tie_col], kind="stable").index.to_numpy()
    d = df.iloc[order].reset_index(drop=True)
    tt = t.iloc[order].reset_index(drop=True)
    valid = tt.notna().to_numpy()
    acct = d[a_col].map(account_key).to_numpy(dtype=object)
    y = (pd.to_numeric(d[y_col], errors="coerce").to_numpy() == positive)
    amt = pd.to_numeric(d[amt_col], errors="coerce").to_numpy(dtype=float)
    if ADVICE_COL in d.columns:  # blank text counts as no advice code (audit finding 24 of 2026-10-19)
        adv = d[ADVICE_COL]
        advice = (adv.notna() & (adv.astype(str).str.strip() != "")).to_numpy()
        acc["rows_with_advice_value"] = (acc["rows_with_advice_value"] or 0) + int(advice.sum())
    else:
        advice = None
    state = {f: pd.to_numeric(d[f], errors="coerce").to_numpy(dtype=float) for f in STATE_FIELDS if f in d.columns}
    tns = tt.to_numpy(dtype="datetime64[ns]").astype("int64")
    for gran, key in (("same_instant", tns), ("same_floor_second", tns // 1_000_000_000)):
        g = acc[gran]
        same_prev = np.zeros(len(d), dtype=bool)
        same_prev[1:] = (acct[1:] == acct[:-1]) & (key[1:] == key[:-1]) & valid[1:] & valid[:-1]
        same_next = np.zeros(len(d), dtype=bool)
        same_next[:-1] = same_prev[1:]
        in_group = same_prev | same_next  # order-free: shares its time with another row of its account
        _add(g["rows_with_any_sibling"], y[in_group], acct[in_group])
        _add(g["rows_with_earlier_sibling_author_order"], y[same_prev], acct[same_prev])
        # A fraud whose group (contiguous in sort order) holds another fraud.
        grp = np.cumsum(~same_prev)
        frauds_per_grp = np.bincount(grp, weights=y.astype(float))
        both = y & in_group & (frauds_per_grp[grp] >= 2)
        _add(g["frauds_whose_group_has_another_fraud"], y[both], acct[both])
        # Pairs: each row with its immediate predecessor in the author's order (audit finding 21 split, audit finding 22 state).
        b = np.flatnonzero(same_prev)
        a = b - 1
        if advice is not None:
            kind_adv = advice[a] | advice[b]
        else:
            kind_adv = np.zeros(len(b), dtype=bool)
        same_amt = ~kind_adv & (np.abs(amt[a] - amt[b]) < CENT)
        neither = ~kind_adv & ~same_amt
        for name, m in (("advice_code_on_either_row", kind_adv), ("same_amount", same_amt), ("neither", neither)):
            _add(g["pairs_by_kind"][name], y[b][m], acct[b][m])
        # State order per pair kind: a purchase and its own advice or repeat message say nothing about two
        # separate purchases, so OQ-13 is read from the "neither" block only (audit finding 23 of 2026-10-19).
        kinds = (("advice_code_on_either_row", kind_adv), ("same_amount", same_amt), ("neither", neither))
        for f, v in state.items():
            na = np.isnan(v[a]) | np.isnan(v[b]) | np.isnan(amt[a]) | np.isnan(amt[b])
            fwd = ~na & (np.abs(v[b] - (v[a] - amt[a])) < CENT)
            rev = ~na & (np.abs(v[a] - (v[b] - amt[b])) < CENT)
            unch = ~na & ~fwd & ~rev & (np.abs(v[a] - v[b]) < CENT)
            cats = {"consistent_with_author_order": fwd & ~rev, "reverse": rev & ~fwd, "both": fwd & rev,
                    "unchanged": unch, "neither": ~na & ~fwd & ~rev & ~unch, "not_applicable": na}
            for kind, km in kinds:
                res = g["state_order_by_pair_kind"].setdefault(kind, {}).setdefault(f, {c: {
                    "pairs": 0, "pairs_later_row_fraud": 0} for c in cats})
                for c, m in cats.items():
                    res[c]["pairs"] += int((m & km).sum())
                    res[c]["pairs_later_row_fraud"] += int((m & km & y[b]).sum())
    acc["frauds"] += int(y.sum())
    acc["fraud_accounts"].update(acct[y].tolist())
    return set(acct.tolist())


def _split_acc():
    gran = lambda: {"rows_with_any_sibling": _counter(), "rows_with_earlier_sibling_author_order": _counter(),
                    "frauds_whose_group_has_another_fraud": _counter(),
                    "pairs_by_kind": {k: _counter() for k in ("advice_code_on_either_row", "same_amount", "neither")},
                    "state_order_by_pair_kind": {}}
    return {"files": 0, "rows": 0, "frauds": 0, "fraud_accounts": set(), "accounts": set(),
            "rows_with_advice_value": None,
            "accounts_in_more_than_one_file": 0, "unparseable_time": 0, "rows_with_subsecond_part": 0,
            "time_types": set(), "missing_columns": set(), "same_instant": gran(), "same_floor_second": gran()}


def _split_out(acc):
    def close_g(g):
        return {"rows_with_any_sibling": _close(g["rows_with_any_sibling"]),
                "rows_with_earlier_sibling_author_order": _close(g["rows_with_earlier_sibling_author_order"]),
                "frauds_whose_group_has_another_fraud": _close(g["frauds_whose_group_has_another_fraud"]),
                "pairs_by_kind": {k: _close(v) for k, v in g["pairs_by_kind"].items()},
                "state_order_by_pair_kind": {kind: {f: {"definition": STATE_FIELDS[f], **v} for f, v in fields.items()}
                                             for kind, fields in g["state_order_by_pair_kind"].items()}}
    return {"files": acc["files"], "rows": acc["rows"], "frauds": acc["frauds"],
            "fraud_accounts": len(acc["fraud_accounts"]), "accounts": len(acc["accounts"]),
            "accounts_in_more_than_one_file": acc["accounts_in_more_than_one_file"],
            "rows_with_advice_value": acc["rows_with_advice_value"],
            "unparseable_time": acc["unparseable_time"], "rows_with_subsecond_part": acc["rows_with_subsecond_part"],
            "time_column_types": sorted(acc["time_types"]), "missing_columns": sorted(acc["missing_columns"]),
            "same_instant": close_g(acc["same_instant"]), "same_floor_second": close_g(acc["same_floor_second"])}


def check_f(ret, runs):
    import pyarrow.parquet as pq
    from fraud.data.s3_utils import strip_scheme
    from YOUR_PACKAGE.v2.storage import thin_read_filesystem

    ref = runs.get("B-H05", {}).get("run_dir") or next(v["run_dir"] for v in runs.values() if "run_dir" in v)
    train_cfg = resolved(ref, "resolved_train.yaml")
    dc = train_cfg.data
    cols = (str(dc.account_col), str(dc.order_col), str(dc.get("tie_break_col") or "fi_transaction_id"),
            str(dc.target_col), str(dc.get("amount_col") or "transaction_amt"))
    positive = int(dc.get("positive_label", 1))
    wanted = list(dict.fromkeys(list(cols) + [ADVICE_COL] + list(STATE_FIELDS)))
    train_base, eval_base = str(dc.train_base), str(train_cfg.eval.base)
    fs = thin_read_filesystem(str(train_cfg.s3.cred_path)) if train_base.startswith("s3") else None
    splits = {"training": (train_base, int(dc.train_start), int(dc.train_end)),
              "evaluation": (eval_base, int(train_cfg.eval.file_start), int(train_cfg.eval.file_end))}
    out = {"columns": {"account": cols[0], "time": cols[1], "tie": cols[2], "label": cols[3], "amount": cols[4],
                       "advice": ADVICE_COL, "state_fields": STATE_FIELDS},
           "order": "the original author's: stable sort on the stored account, time and tie columns",
           "pair": "each row with its immediate predecessor in that order, inside its same-time group",
           "state_rule": f"consistent: later value = earlier value - earlier amount, within {CENT}; reverse: the "
                         "same with the rows swapped; unchanged: equal values",
           "how_to_read": "Read same-second availability and order (OQ-13) from state_order_by_pair_kind.neither "
                          "only: consistent against reverse. Advice and same-amount pairs may be one purchase in two "
                          "messages. 'unchanged' is not evidence that the earlier row was unavailable: a declined "
                          "purchase or the other limit type leaves the value unchanged (audit finding 25 of 2026-10-19).",
           "splits": {}}
    for split, (base, start, end) in splits.items():
        acc = _split_acc()
        seen = set()
        for i in range(start, end + 1):
            path = f"{base.rstrip('/')}/part_{i}.parquet"
            ds = pq.ParquetDataset(strip_scheme(path) if fs is not None else path, filesystem=fs)
            names = set(ds.schema.names)
            missing = [c for c in cols if c not in names]
            if missing:
                raise KeyError(f"{path} lacks {missing}")
            acc["missing_columns"].update(c for c in wanted if c not in names)
            table = ds.read(columns=[c for c in wanted if c in names])
            acc["time_types"].add(str(table.schema.field(cols[1]).type))
            df = table.to_pandas()
            del table
            file_accounts = same_second_file(df, cols, positive, acc)
            del df
            acc["files"] += 1
            # Groups are formed inside one file, so the counts are exact only if no account spans two files.
            acc["accounts_in_more_than_one_file"] += len(file_accounts & seen)
            seen |= file_accounts
        acc["accounts"] = seen
        out["splits"][split] = _split_out(acc)
        ret.status(f"f: {split} done ({acc['files']} files)")
    ret.write_json("f_same_second.json", out)
    lines = []
    for split, s in out["splits"].items():
        g = s["same_floor_second"]
        line = (f"{split}: {g['rows_with_earlier_sibling_author_order']['frauds']} of {s['frauds']} frauds "
                f"({g['rows_with_earlier_sibling_author_order']['fraud_accounts']} accounts) have an earlier "
                f"same-second row in the original author's order; pairs by kind (frauds): "
                + ", ".join(f"{k} {v['frauds']}" for k, v in g["pairs_by_kind"].items())
                + f"; rows with an advice code: {s['rows_with_advice_value']} of {s['rows']}")
        sep = g["state_order_by_pair_kind"].get("neither", {}).get("total_available_balance_amt")
        if sep:
            line += (f"; separate purchases, balance order: consistent {sep['consistent_with_author_order']['pairs']}, "
                     f"reverse {sep['reverse']['pairs']}, unchanged {sep['unchanged']['pairs']}")
        if any("timestamp" not in t for t in s["time_column_types"]):  # audit finding 26 of 2026-10-19
            line += (f". Time is stored as {s['time_column_types']}: if it does not sort in time order, same-second "
                     "groups can split, so these counts are lower bounds")
        lines.append(line)
    return lines


# --------------------------------------------------------------------------------------------------------------- #
# g: are the balance and limit fields really "before this transaction"? (feature review note 1 of 2026-10-19, tests T1 and T2)
# --------------------------------------------------------------------------------------------------------------- #
# If a stored value were taken after the bank's decision, approved rows would carry value - amount and declined rows
# the value itself, so the field would encode the decision: a leak for the raw inputs and for any ratio built on them.
G_FIELDS = {"total_available_balance_amt": "any_pair", "remain_day_merchandise_lmt_amt": "same_day",
            "available_daily_cash_limit_amt": "same_day"}
G_BUCKETS = ("before", "after", "unchanged", "ambiguous", "other", "different_day", "not_applicable")
G_TOP_TYPES = 30
G_MIN_TYPE_PAIRS = 10  # codes with fewer pairs are pooled (audit finding 29 of 2026-10-19)
G_GAPS = (("same_second", None), ("under_1_minute", 60), ("under_1_hour", 3600), ("1_hour_or_more", None))
TYPE_COL = "transaction_type_xcd"


def _g_acc():
    return {"files": 0, "rows": 0, "pairs": 0, "missing_columns": set(), "fields": {}, "by_type": {},
            "by_type_b": {}, "over_capacity": {}, "limit": {}}


def state_semantics_file(df, cols, positive, acc):
    """Adds one file's consecutive-pair and single-row counts to `acc`. No row leaves this function."""
    import numpy as np
    import pandas as pd

    a_col, t_col, tie_col, y_col, amt_col = cols
    acc["rows"] += len(df)
    d = df.reset_index(drop=True)
    d = d.iloc[d.sort_values([a_col, t_col, tie_col], kind="stable").index.to_numpy()].reset_index(drop=True)
    t = pd.to_datetime(d[t_col], errors="coerce")
    tns = t.to_numpy(dtype="datetime64[ns]").astype("int64")  # nanoseconds whatever the stored unit (feature review note 6 of 2026-10-19)
    valid = t.notna().to_numpy()
    day = t.dt.floor("D").to_numpy(dtype="datetime64[ns]").astype("int64")  # calendar day of the stored time; the reset clock is CQ-02
    acct = d[a_col].map(account_key).to_numpy(dtype=object)
    y = pd.to_numeric(d[y_col], errors="coerce").to_numpy() == positive
    x = pd.to_numeric(d[amt_col], errors="coerce").to_numpy(dtype=float)
    if ADVICE_COL in d.columns:
        adv = d[ADVICE_COL]
        advice = (adv.notna() & (adv.astype(str).str.strip() != "")).to_numpy()
    else:
        advice = np.zeros(len(d), dtype=bool)
    # pandas 3 keeps a missing value as NaN through astype(str), so fill it first (feature review of check g, G-1)
    types = (d[TYPE_COL].astype(object).where(d[TYPE_COL].notna(), "<missing>").astype(str).to_numpy(dtype=object)
             if TYPE_COL in d.columns else None)
    b = np.flatnonzero((acct[1:] == acct[:-1]) & valid[1:] & valid[:-1]) + 1  # later row of each adjacent pair
    a = b - 1
    acc["pairs"] += len(b)
    same_sec = (tns[a] // 1_000_000_000) == (tns[b] // 1_000_000_000)
    gap_s = (tns[b] - tns[a]) / 1e9
    gap = {"same_second": same_sec, "under_1_minute": ~same_sec & (gap_s < 60),
           "under_1_hour": ~same_sec & (gap_s >= 60) & (gap_s < 3600), "1_hour_or_more": ~same_sec & (gap_s >= 3600)}
    adv_either = advice[a] | advice[b]
    for f, scope in G_FIELDS.items():
        if f not in d.columns:
            continue
        v = pd.to_numeric(d[f], errors="coerce").to_numpy(dtype=float)
        na = np.isnan(v[a]) | np.isnan(v[b]) | np.isnan(x[a]) | np.isnan(x[b])
        other_day = ~na & (day[a] != day[b]) if scope == "same_day" else np.zeros(len(b), dtype=bool)
        live = ~na & ~other_day
        bef = live & (np.abs(v[b] - (v[a] - x[a])) < CENT)
        aft = live & (np.abs(v[b] - (v[a] - x[b])) < CENT)
        unc = live & (np.abs(v[b] - v[a]) < CENT)
        hits = bef.astype(int) + aft.astype(int) + unc.astype(int)
        cats = {"before": bef & (hits == 1), "after": aft & (hits == 1), "unchanged": unc & (hits == 1),
                "ambiguous": hits >= 2, "other": live & (hits == 0), "different_day": other_day, "not_applicable": na}
        # The leak signature is "unchanged" depending on the later row's own label (audit finding 27 of 2026-10-19), so both
        # rows' labels are split out; time gaps separate posting delays from deposits (audit finding 28 of 2026-10-19).
        fd = acc["fields"].setdefault(f, {})
        for gname, gm in gap.items():
            for ad in (False, True):
                for fa in (False, True):
                    for fb in (False, True):
                        key = (f"{gname},advice_{'yes' if ad else 'no'},row_a_{'fraud' if fa else 'not_fraud'},"
                               f"row_b_{'fraud' if fb else 'not_fraud'}")
                        m = gm & (adv_either == ad) & (y[a] == fa) & (y[b] == fb)
                        cell = fd.setdefault(key, {c: 0 for c in G_BUCKETS})
                        for c, cm in cats.items():
                            cell[c] += int((cm & m).sum())
        if types is not None:  # row a's type answers CQ-A; row b's catches an after-leak limited to some types
            for store, idx in ((acc["by_type"], a), (acc["by_type_b"], b)):
                bt = store.setdefault(f, {})
                for ty in np.unique(types[idx]):
                    m = types[idx] == ty
                    cell = bt.setdefault(str(ty), {c: 0 for c in G_BUCKETS})
                    for c, cm in cats.items():
                        cell[c] += int((cm & m).sum())
        # Pairs whose earlier row asked for more than was left: under before-semantics with an enforced limit they are
        # "unchanged" (row a declined); their fraud split shows whether declined attempts carry the fraud label
        # (feature review of check g, addendum Q3; public question 21).
        over = ~na & (v[a] > 0) & (x[a] - v[a] >= CENT)
        oc = acc["over_capacity"].setdefault(f, {})
        for fa in (False, True):
            cell = oc.setdefault(f"row_a_{'fraud' if fa else 'not_fraud'}", {c: 0 for c in G_BUCKETS})
            for c, cm in cats.items():
                cell[c] += int((cm & over & (y[a] == fa)).sum())
    # T2: single rows whose amount exceeds or exactly uses what is left, by label.
    for f in ("total_available_balance_amt", "remain_day_merchandise_lmt_amt", "available_daily_cash_limit_amt"):
        if f not in d.columns:
            continue
        v = pd.to_numeric(d[f], errors="coerce").to_numpy(dtype=float)
        ok = ~np.isnan(v) & ~np.isnan(x)
        lim = acc["limit"].setdefault(f, {k: {"rows": 0, "frauds": 0} for k in (
            "amount_above_value", "amount_equals_value", "value_zero_or_below", "other", "missing")})
        cats = {"amount_above_value": ok & (v > 0) & (x - v >= CENT), "amount_equals_value": ok & (v > 0) & (np.abs(x - v) < CENT),
                "value_zero_or_below": ok & (v <= 0), "missing": ~ok}
        cats["other"] = ~(cats["amount_above_value"] | cats["amount_equals_value"] | cats["value_zero_or_below"] | cats["missing"])
        for k, m in cats.items():
            lim[k]["rows"] += int(m.sum())
            lim[k]["frauds"] += int((m & y).sum())


def _g_pool(store):
    by_type = {}
    for f, bt in store.items():
        top = sorted(bt.items(), key=lambda kv: -sum(kv[1].values()))
        big = [kv for kv in top if sum(kv[1].values()) >= G_MIN_TYPE_PAIRS]
        kept, rest = dict(big[:G_TOP_TYPES]), {c: 0 for c in G_BUCKETS}
        for ty, cell in top:
            if ty not in kept:
                for c in G_BUCKETS:
                    rest[c] += cell[c]
        if len(kept) < len(top):
            kept["all_other_types"] = rest
        by_type[f] = kept
    return by_type


def _g_out(acc):
    by_type = _g_pool(acc["by_type"])
    totals = {f: {c: sum(cell[c] for cell in fd.values()) for c in G_BUCKETS} for f, fd in acc["fields"].items()}
    return {"files": acc["files"], "rows": acc["rows"], "adjacent_pairs": acc["pairs"],
            "missing_columns": sorted(acc["missing_columns"]), "totals": totals, "by_split": acc["fields"],
            "by_type_of_row_a": by_type, "by_type_of_row_b": _g_pool(acc["by_type_b"]),
            "row_a_over_capacity": acc["over_capacity"], "single_row_limits": acc["limit"]}


def check_g(ret, runs):
    import pyarrow.parquet as pq
    from fraud.data.s3_utils import strip_scheme
    from YOUR_PACKAGE.v2.storage import thin_read_filesystem

    ref = runs.get("B-H05", {}).get("run_dir") or next(v["run_dir"] for v in runs.values() if "run_dir" in v)
    train_cfg = resolved(ref, "resolved_train.yaml")
    dc = train_cfg.data
    cols = (str(dc.account_col), str(dc.order_col), str(dc.get("tie_break_col") or "fi_transaction_id"),
            str(dc.target_col), str(dc.get("amount_col") or "transaction_amt"))
    positive = int(dc.get("positive_label", 1))
    wanted = list(dict.fromkeys(list(cols) + [ADVICE_COL, TYPE_COL] + list(G_FIELDS)))
    train_base = str(dc.train_base)
    fs = thin_read_filesystem(str(train_cfg.s3.cred_path)) if train_base.startswith("s3") else None
    acc = _g_acc()
    for i in range(int(dc.train_start), int(dc.train_end) + 1):
        path = f"{train_base.rstrip('/')}/part_{i}.parquet"
        ds = pq.ParquetDataset(strip_scheme(path) if fs is not None else path, filesystem=fs)
        names = set(ds.schema.names)
        missing = [c for c in cols if c not in names]
        if missing:
            raise KeyError(f"{path} lacks {missing}")
        acc["missing_columns"].update(c for c in wanted if c not in names)
        df = ds.read(columns=[c for c in wanted if c in names]).to_pandas()
        state_semantics_file(df, cols, positive, acc)
        del df
        acc["files"] += 1
    out = {"files": f"training {dc.train_start}-{dc.train_end}",
           "order": "the original author's: stable sort on the stored account, time and tie columns",
           "rule": (f"for each adjacent pair (a, b) of one account, within {CENT}: before = v_b equals v_a - amount_a; "
                    "after = v_b equals v_a - amount_b; unchanged = v_b equals v_a; ambiguous = two or more hold "
                    "(for example equal or zero amounts); other = none holds (deposits, holds, resets). Daily limits "
                    "are compared only within one calendar day of the stored time (the reset clock is CQ-02)."),
           "how_to_read": ("Before-semantics, as the dictionary says, shows as 'before' far above 'after' on pairs in a "
                           "later second. If 'after' dominates, the stored values include the row's own amount and can "
                           "encode the decision: neither these fields nor ratios built on them can be trusted. Second "
                           "reading: hold row a's label fixed. In the row_a_not_fraud cells, compare the 'unchanged' rate "
                           "between row_b_fraud and row_b_not_fraud; under before-semantics they match, and a difference is "
                           "the leak signature (audit finding 27 of 2026-10-19). The pooled row_b split is confounded by fraud bursts "
                           "(feature review of check g, G-2). Long gaps put balance pairs into 'other' through "
                           "deposits and holds, so read the short-gap cells first. Transaction-type codes are schema values; "
                           "codes with fewer than 10 pairs are pooled."),
           "result": _g_out(acc)}
    ret.write_json("g_state_semantics.json", out)
    lines = []
    for f, tot in out["result"]["totals"].items():
        later = {c: sum(cell[c] for k, cell in out["result"]["by_split"][f].items() if not k.startswith("same_second"))
                 for c in ("before", "after", "unchanged", "ambiguous", "other")}
        lines.append(f"{f}: later-second pairs before {later['before']}, after {later['after']}, unchanged "
                     f"{later['unchanged']}, ambiguous {later['ambiguous']}, other {later['other']} "
                     f"(all pairs: {tot})")
    return lines


# --------------------------------------------------------------------------------------------------------------- #
def parse_args(argv=None):
    p = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    p.add_argument("--only", default="a,b,c,e,f,g", help="comma list of checks: a-g (default a,b,c,e,f,g: every CPU check; d is the GPU check)")
    p.add_argument("--ledger", default=None, help=f"V1 ledger (default: first found of {DEFAULT_LEDGERS})")
    p.add_argument("--run-table", default=DEFAULT_RUN_TABLE,
                   help="the V1 finalist run table paired_report.py used (for check e)")
    p.add_argument("--positions", default="5,4,3,2,1,0", help="chunk positions for check e, in run order")
    p.add_argument("--probe-file", type=int, default=8000, help="file number compared across folders (check b)")
    p.add_argument("--d-runs", default="B-H05,A-H05", help="runs whose last.ckpt check d scores (default B-H05,A-H05)")
    p.add_argument("--cred", default=None, help="credentials file for paired_report.py (default: its own default)")
    p.add_argument("--returns", default=os.path.join(ROOT, "runs", "returns"), help="where the return folder goes")
    p.add_argument("--dry-run", action="store_true", help="print the plan and commands; read nothing large")
    p.add_argument("--paired-args", nargs=argparse.REMAINDER, default=[],
                   help="extra arguments passed to paired_report.py (local testing only)")
    args = p.parse_args(argv)
    args.only = [c.strip() for c in args.only.split(",") if c.strip()]
    bad = set(args.only) - set("abcdefg")
    if bad:
        p.error(f"unknown checks: {sorted(bad)}")
    args.positions = [int(x) for x in args.positions.split(",") if x.strip()]
    args.d_runs = [c.strip() for c in args.d_runs.split(",") if c.strip()]
    return args


def main(argv=None):
    args = parse_args(argv)
    ret = Return(args.returns, args.dry_run)
    ret.status(f"quick checks started: {','.join(args.only)}; project root {ROOT}; python {sys.executable}")
    ret.status(f"packages: {package_versions()}")
    summary, failed = [], []
    try:
        ledger = pick_ledger(args.ledger)
        runs = find_run_dirs(ledger)
        ret.status(f"ledger {ledger}: {sum('run_dir' in v for v in runs.values())} of {len(runs)} run folders found")
        if not args.dry_run:
            ret.write_json("runs_found.json", {"ledger": ledger, "runs": runs})
    except Exception as exc:  # noqa: BLE001 - every failure is reported, nothing else can run
        ret.status(f"cannot locate the V1 runs: {exc}")
        return 1
    steps = {
        "a": lambda: check_a(ret, runs),
        "c": lambda: check_c(ret, runs),
        "b": lambda: check_b(ret, runs, args.probe_file),
        "e": lambda: check_e(ret, args.run_table, args.positions, args.cred, args.paired_args, args.dry_run),
        "f": lambda: check_f(ret, runs),
        "g": lambda: check_g(ret, runs),
        "d": lambda: check_d(ret, runs, args.d_runs, args.dry_run),
    }
    for name in [s for s in "acbefgd" if s in args.only]:
        if args.dry_run and name in "abcfg":
            ret.status(f"{name}: would run")
            continue
        try:
            ret.status(f"{name}: started")
            lines = steps[name]() or []
            summary += [f"[{name}] {x}" for x in lines]
            ret.status(f"{name}: done")
        except Exception as exc:  # noqa: BLE001 - one failed check must not stop the others
            failed.append(name)
            ret.status(f"{name}: FAILED: {exc}")
            if not args.dry_run:
                with open(ret.file(f"{name}_error.txt"), "w", encoding="utf-8") as f:
                    f.write(traceback.format_exc())
    if not args.dry_run:
        with open(ret.file("SUMMARY.txt"), "w", encoding="utf-8") as f:
            f.write("Quick checks (2026-10-19). Aggregates only.\n\n" + "\n".join(summary) + "\n")
            f.write(f"\nFailed checks: {', '.join(failed) or 'none'}\n")
    ret.status(f"finished; failed: {', '.join(failed) or 'none'}; send the folder {ret.path}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
