"""L5: align existing scores by transaction ID; compare only an actually pinned freeze.

All files may be local or S3. This CPU consumer never loads a bank model or trains it.
See USAGE_CONSUMERS.md for the JSON schema and descriptive business-metric grid.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import re
from pathlib import Path

import fsspec
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score

from YOUR_PACKAGE.scoring._prediction_utils import id_kind, validate_ids
from YOUR_PACKAGE.v2.analysis.business_metrics import business_report, POLICY_NOTE

from YOUR_PACKAGE.v2.analysis.embedding_diagnostics import (
    benchmark_embedding_diagnostics, validate_benchmark_embedding_inputs)


DEFAULT_EXPECTED_COUNTS = {"rows": 952905, "accounts": 317672, "frauds": None}


def open_file(path, mode="rb", filesystem=None):
    if filesystem is not None and str(path).startswith(("s3://", "s3a://")):
        return filesystem.open(str(path).split("://", 1)[1], mode)
    return fsspec.open(str(path), mode).open()


def digest(path, filesystem=None):
    h = hashlib.sha256()
    with open_file(path, filesystem=filesystem) as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_json(path, filesystem=None):
    with open_file(path, "r", filesystem) as f:
        return json.load(f)


def read_table(paths, filesystem=None, source_column=None, columns=None):
    """Concatenate parquet files; with `columns`, read only those the file has (memory: the bank files hold
    about 224 columns and the consumers need about 30)."""
    paths = [paths] if isinstance(paths, str) else paths
    if not paths:
        raise ValueError("An explicit nonempty file list is required")
    frames = []
    for path in paths:
        if str(path).startswith(("s3://", "s3a://")) and filesystem is not None:
            fs, inner = filesystem, str(path).split("://", 1)[1]
        else:
            fs, inner = fsspec.core.url_to_fs(str(path))
        if fs.isdir(inner):
            files = sorted(p for p in fs.find(inner) if p.endswith(".parquet"))
        elif any(char in inner for char in "*?["):
            files = sorted(fs.glob(inner))
        else:
            files = [inner]
        if not files:
            raise ValueError(f"No parquet files found at {path}")
        for file in files:
            with fs.open(file, "rb") as f:
                if columns is None:
                    frame = pd.read_parquet(f)
                else:
                    import pyarrow.parquet as pq
                    have = set(pq.ParquetFile(f).schema_arrow.names)
                    f.seek(0)
                    frame = pd.read_parquet(f, columns=[c for c in columns if c in have])
                if source_column is not None:
                    if source_column in frame:
                        raise ValueError(f"Reserved file-provenance column already exists: {source_column}")
                    frame[source_column] = str(file)
                frames.append(frame)
    return pd.concat(frames, ignore_index=True)


def write_json(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, sort_keys=True, allow_nan=False) + "\n")


def file_pin(pin, filesystem=None):
    if not isinstance(pin, dict) or not pin.get("path") or not re.fullmatch(r"[a-f0-9]{64}", pin.get("sha256", "")):
        raise ValueError("Every freeze pin needs path and lowercase sha256")
    if digest(pin["path"], filesystem) != pin["sha256"]:
        raise ValueError(f"Frozen file hash differs: {pin['path']}")


def verify_freeze(path, filesystem=None, require_downstream=False):
    """Read and verify the files, not just the existence of FROZEN_MODEL.json."""
    if not path:
        raise ValueError("Comparison/FINAL requires FROZEN_MODEL.json")
    frozen = read_json(path, filesystem)
    if frozen.get("schema_version") != 1:
        raise ValueError("Unsupported freeze schema_version")
    encoder = frozen.get("encoder", {})
    for pin in (encoder.get("checkpoint"), encoder.get("config"), frozen.get("split"), frozen.get("code")):
        file_pin(pin, filesystem)
    artifacts = encoder.get("artifacts", {})
    if artifacts.get("version") is None or not artifacts.get("files") or "scoring_policy" not in encoder:
        raise ValueError("Freeze needs artifact version/files and scoring_policy (null for default B)")
    for pin in artifacts["files"]:
        file_pin(pin, filesystem)
    if require_downstream:
        consumer = frozen.get("downstream", {})
        file_pin(consumer.get("bundle"), filesystem)
        if not consumer.get("arm"):
            raise ValueError("Freeze must name the selected downstream arm")
    return frozen


def canonical_ids(series, label):
    """Lossless identity keys for joins and set comparisons, through the validator the inventory and
    paired_v2 use. Text stays text (leading zeros kept), integers stay integers, and a whole-number float such
    as 12345678.0 (how the bank stores `Nmap_account_reference_xid`) becomes the integer 12345678, so the int
    and float spellings of one id compare equal. Unsafe floats (beyond 2**53) and nulls are refused.
    Returns (keys, kind) where kind is 'numeric', 'str' or 'bytes' (None for an empty column)."""
    ids = validate_ids(series, label, unique=False)
    kind = id_kind(ids) if len(ids) else None
    keys = ids.map(lambda v: int(v) if isinstance(v, float) and v.is_integer() else v)
    return keys, kind


def exposure_record(population, purpose, inputs, completed, **extra):
    """One attempt-local record per labelled read (lean plan L2.4, DECISIONS section 3), written in `finally`
    so failed attempts are recorded too."""
    return {"utc": datetime.now(timezone.utc).isoformat(), "population": population, "purpose": purpose,
            "inputs": inputs, "completed": bool(completed), **extra}


def exact_unique(df, key, name, audit):
    """Compare ALL non-key fields for EVERY duplicated ID; discard only exact rows."""
    keys = [key] if isinstance(key, str) else list(key)
    if not keys or any(k not in df for k in keys) or df[keys].isna().any().any():
        raise ValueError(f"{name}: missing/null transaction IDs")
    if not df.columns.is_unique:
        raise ValueError(f"{name}: duplicate column names")
    df = df.copy()
    # Canonical identifiers as text: whole-number floats become integers first (lossless), so the bank's
    # float64 account ids match their integer or text spelling; unsafe floats are refused by canonical_ids.
    for k in keys:
        df[k] = canonical_ids(df[k], f"{name} {k}")[0].astype(str)
    duplicated = df[df.duplicated(keys, keep=False)]
    for identifier, group in duplicated.groupby(keys, sort=False):
        conflicts = [c for c in df if c not in keys and group[c].nunique(dropna=False) > 1]
        audit.append({"source": name, "id": identifier, "copies": len(group),
                      "exact": not conflicts, "conflicting_columns": ",".join(conflicts)})
    if any(r["source"] == name and not r["exact"] for r in audit):
        raise ValueError(f"{name}: conflicting duplicate IDs; see duplicate_audit.csv")
    return df.drop_duplicates(keys).reset_index(drop=True)


def duplicate_summary(audit):
    """Returnable aggregate; the separate row audit retains transaction IDs on the pod."""
    return {"duplicate_groups": len(audit), "conflicting_groups": sum(not r["exact"] for r in audit),
            "extra_exact_rows": sum(r["copies"] - 1 for r in audit if r["exact"])}


def binary_labels(s):
    if s.isna().any() or not s.isin([0, 1]).all():
        raise ValueError("Labels must be explicitly encoded 0/1, with no nulls")
    return s.to_numpy(dtype=np.int8)


def finite_scores(s):
    a = s.to_numpy(dtype=float)
    if not np.isfinite(a).all():
        raise ValueError("Scores must all be finite")
    return a


def metrics(y, scores, weights=None):
    active = np.ones(len(y), dtype=bool) if weights is None else weights > 0
    if len(np.unique(y[active])) < 2:
        return {"ap": None, "auroc": None}
    return {"ap": float(average_precision_score(y, scores, sample_weight=weights)),
            "auroc": float(roc_auc_score(y, scores, sample_weight=weights))}


def paired_interval(y, a, b, accounts, draws=1000, seed=42):
    """Paired account bootstrap conditional on these fitted models, not training-run variance."""
    if int(draws) < 2:
        raise ValueError("bootstrap_draws must be >=2")
    accounts = pd.Series(accounts)
    if accounts.isna().any():
        raise ValueError("Bootstrap requires nonnull account IDs")
    codes, unique = pd.factorize(accounts.astype(str), sort=True)
    if len(unique) < 2:
        return {"delta_ap": None, "ci95": None, "valid_draws": 0, "reason": "fewer than two accounts"}
    point = metrics(y, a)["ap"]
    if point is None:
        return {"delta_ap": None, "ci95": None, "valid_draws": 0, "reason": "single-class population"}
    rng = np.random.default_rng(seed)
    deltas = []
    for _ in range(draws):
        weights = rng.multinomial(len(unique), np.full(len(unique), 1 / len(unique)))[codes]
        if len(np.unique(y[weights > 0])) == 2:
            deltas.append(float(average_precision_score(y, a, sample_weight=weights)
                                - average_precision_score(y, b, sample_weight=weights)))
    return {"delta_ap": point - metrics(y, b)["ap"],
            "ci95": np.quantile(deltas, [.025, .975]).tolist() if len(deltas) >= 2 else None,
            "valid_draws": len(deltas), "requested_draws": draws,
            "interpretation": "paired account bootstrap, fitted-model uncertainty; not selection-adjusted"}


def depth_report(frame, label, score_cols, depth):
    if depth not in frame:
        raise ValueError(f"Actual history-depth column absent: {depth}; no substitute row order is inferred")
    d = frame[depth].to_numpy(dtype=float)
    if not np.isfinite(d).all() or (d < 0).any() or (d != np.floor(d)).any():
        raise ValueError("History depths must be finite nonnegative integer counts")
    rows = []
    for name, low, high in (("0", 0, 1), ("1-4", 1, 5), ("5-9", 5, 10), ("10-19", 10, 20), ("20+", 20, np.inf)):
        sub = frame[(d >= low) & (d < high)]
        rows.append({"band": name, "rows": len(sub), "frauds": int(sub[label].sum()),
                     "metrics": {c: metrics(sub[label].to_numpy(), sub[c].to_numpy()) for c in score_cols}})
    return rows


def benchmark_counts(raw, config, allow_count_mismatch=False):
    """Check the unique benchmark target population before score-coverage filtering.

    The positive-label count remains unverified until an explicit expected value
    is supplied from a stated source. If unset, the observed count is reported
    as unverified; no expected count is inferred from this read. The data look
    does not count BENCH labels.
    """
    configured = config.get("expected_counts", {})
    if not isinstance(configured, dict) or set(configured) - set(DEFAULT_EXPECTED_COUNTS):
        raise ValueError("expected_counts accepts rows, accounts and frauds only")
    expected = {**DEFAULT_EXPECTED_COUNTS, **configured}
    for name, value in expected.items():
        if value is None and name == "frauds":
            continue
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError("Expected benchmark counts must be nonnegative integers; only frauds may be null")
    observed = {"rows": len(raw), "accounts": int(raw["_acct_key"].nunique()),
                "frauds": int(binary_labels(raw[config["label"]]).sum())}
    mismatches = {name: {"expected": value, "observed": observed[name]}
                  for name, value in expected.items() if value is not None and value != observed[name]}
    return {"population": "unique benchmark targets before score intersection", "expected": expected,
            "observed": observed, "mismatches": mismatches,
            "unverified": [name for name, value in expected.items() if value is None],
            "frauds_definition": "number of targets with label 1", "override_requested": bool(allow_count_mismatch),
            "override_applied": bool(mismatches and allow_count_mismatch)}


def run(config, out, compare=False, frozen_path=None, filesystem=None, allow_count_mismatch=False):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=False)
    audit = []
    key, account = config["key"], config["account"]
    label, amount = config["label"], config["amount"]
    completed = False
    count_check = None
    try:
        target_rows = read_table(config["targets"], filesystem, source_column="_business_input_file")
        raw = exact_unique(target_rows.drop(columns="_business_input_file"), key, "targets", audit)
        source_column = config.get("business_metrics", {}).get("source_file")
        if source_column is not None and source_column not in raw:
            raise ValueError("Configured business-metric source-file column is absent")
        if source_column is None:
            source_keys = canonical_ids(target_rows[key], "target source IDs")[0].astype(str)
            provenance = pd.DataFrame({"_key": source_keys, "_source": target_rows["_business_input_file"]})
            sources = provenance.drop_duplicates("_key").set_index("_key")["_source"]
            repeated = provenance[provenance.duplicated("_key", keep=False)]
            if not repeated.empty:
                grouped = repeated.groupby("_key")["_source"].agg(
                    lambda values: sorted(set(values)))
                sources.loc[grouped.index] = grouped.map(lambda values: values[0] if len(values) == 1 else json.dumps(values))
            raw["_business_input_file"] = raw[key].map(sources)
            source_column = "_business_input_file"
        binary_labels(raw[label])
        if raw[account].isna().any() or not np.isfinite(raw[amount].to_numpy(dtype=float)).all():
            raise ValueError("Targets need nonnull accounts and finite amounts")
        raw["_acct_key"], target_kind = canonical_ids(raw[account], "targets account")
        count_check = benchmark_counts(raw, config, allow_count_mismatch)
        if count_check["mismatches"] and not allow_count_mismatch:
            raise ValueError("Benchmark count mismatch: " + ", ".join(sorted(count_check["mismatches"]))
                             + "; use --allow-count-mismatch only for an explicitly qualified reading")
        aligned, coverage = raw.copy(), {}
        for name, spec in config["scores"].items():
            src = exact_unique(read_table(spec["paths"], filesystem), key, name, audit)
            finite_scores(src[spec["score"]])
            provided_amount = spec.get("amount") in src
            if name != "ft" and not provided_amount:
                raise ValueError(f"{name}: external score artifact must provide amounts")
            check = pd.DataFrame({key: src[key], "_score_label": src[spec["label"]]})
            if provided_amount:
                check["_score_amount"] = src[spec["amount"]]
            if name == "ft":
                if account not in src or src[account].isna().any():
                    raise ValueError("Native FT scores need account IDs for the composite-key check")
                check["_score_account"], ft_kind = canonical_ids(src[account], "ft accounts")
                if ft_kind != target_kind:
                    raise ValueError(f"ft: account-ID representation ({ft_kind}) differs from the targets ({target_kind})")
            joined = raw[[key, label, amount, account, "_acct_key"]].merge(check, on=key, how="inner", validate="one_to_one")
            pairs = [(label, "_score_label")]
            if provided_amount:
                pairs.append((amount, "_score_amount"))
            for left, right in pairs:
                if joined[right].isna().any() or not (joined[left].to_numpy() == joined[right].to_numpy()).all():
                    raise ValueError(f"{name}: label/amount disagreement on matched IDs ({left})")
            if name == "ft" and not (joined["_acct_key"] == joined["_score_account"]).all():
                raise ValueError("FT account IDs disagree with benchmark targets")
            coverage[name] = {"targets": len(raw), "matched": len(joined), "source_rows": len(src),
                              "amount_source": "score artifact verified against targets" if provided_amount else "authoritative target amount after composite-ID/label match"}
            aligned = aligned.merge(src[[key, spec["score"]]].rename(columns={spec["score"]: f"score_{name}"}),
                                    on=key, how="inner", validate="one_to_one")
        overlaps, exposed_accounts = {}, {}
        for role, paths in config.get("other_roles", {}).items():
            other = read_table(paths, filesystem, columns=[key, account])
            role_acc, role_kind = canonical_ids(other[account], f"{role} accounts")
            if role_kind != target_kind:
                raise ValueError(f"{role}: account-ID representation ({role_kind}) differs from the targets ({target_kind}); "
                                 "reconcile the identity file before the overlap and SELECT-excluded views")
            role_key = canonical_ids(other[key], f"{role} {key}")[0].astype(str)
            exposed_accounts[role] = set(role_acc)
            overlaps[role] = {"transactions": len(set(raw[key]) & set(role_key)),
                              "accounts": len(set(raw["_acct_key"]) & exposed_accounts[role])}
        result = {"mode": "comparison" if compare else "plumbing_only", "coverage": coverage,
                  "common_valid_rows": len(aligned), "overlaps": overlaps,
                  "duplicates": duplicate_summary(audit), "benchmark_counts": count_check,
                  "business_metrics": {"status": "not_available", "reason": "plumbing-only mode; comparison not requested",
                                       "alert_policy": POLICY_NOTE}}
        if compare:
            frozen = verify_freeze(frozen_path, filesystem)
            receipt = read_json(config["ft_receipt"], filesystem)
            if receipt.get("checkpoint_sha256") != frozen["encoder"]["checkpoint"]["sha256"]:
                raise ValueError("Benchmark FT scores are not from the frozen encoder")
            prediction_pin = receipt.get("predictions_sha256")
            ft_paths = config["scores"]["ft"]["paths"]
            ft_paths = [ft_paths] if isinstance(ft_paths, str) else ft_paths
            if len(ft_paths) != 1 or prediction_pin != digest(ft_paths[0], filesystem):
                raise ValueError("Benchmark FT receipt must pin the actual score parquet")
            if "SELECT" not in exposed_accounts:
                raise ValueError("Supply the SELECT account population for the required SELECT-excluded benchmark view")
            if coverage["ft"]["matched"] != len(raw):
                raise ValueError("FT scoring must cover every benchmark target")
            if not len(aligned):
                raise ValueError("No common valid targets across the declared scores")
            if receipt.get("validation_policy") != frozen["encoder"]["scoring_policy"]:
                raise ValueError("Benchmark score policy differs from frozen encoder")
            validated_embeddings = (
                validate_benchmark_embedding_inputs(config, raw, aligned, frozen, audit, filesystem)
                if config.get("ft_embedding_export") else None)
            y = binary_labels(aligned[label])
            cols = [f"score_{name}" for name in config["scores"]]
            result["metrics"] = {c: metrics(y, finite_scores(aligned[c])) for c in cols}
            business_config = config.get("business_metrics", {})
            amount_bins_path = business_config.get("amount_bins")
            amount_bins = read_json(amount_bins_path, filesystem) if amount_bins_path else None
            result["business_metrics"] = {
                "status": "available", "alert_policy": POLICY_NOTE, "population": "common valid BENCH targets",
                "selection_overlap": "This grid includes accounts overlapping SELECT. The SELECT-excluded "
                    "view reports AP/AUROC and paired AP intervals only; it has no separate business-metric grid.",
                "amount_bins_sha256": digest(amount_bins_path, filesystem) if amount_bins_path else None,
                "source_file_provenance": "configured original source column" if business_config.get("source_file")
                    else "input parquet file reference(s); a prepared input may combine original raw files",
                "scores": {c: business_report(y, finite_scores(aligned[c]), aligned[account],
                    amounts=aligned[amount], row_keys=aligned[key],
                    depth=aligned[config["depth"]] if config.get("depth") in aligned else None,
                    source_files=aligned[source_column], amount_bins=amount_bins,
                    score_is_probability=(c == "score_ft" or config["scores"][c.removeprefix("score_")].get("score_is_probability") is True),
                    draws=config.get("bootstrap_draws", 1000), seed=config.get("bootstrap_seed", 42)) for c in cols}}
            result["ft_vs"] = {c: paired_interval(y, aligned["score_ft"].to_numpy(), aligned[c].to_numpy(),
                                                 aligned[account], config.get("bootstrap_draws", 1000))
                               for c in cols if c != "score_ft"}
            if not config.get("depth"):
                raise ValueError("L8 comparison requires an actual full-history depth column (amendment 2: every L8 "
                                 "reading by depth band)")
            result["depth"] = depth_report(aligned, label, cols, config["depth"])
            correlation = aligned[cols].corr()
            result["score_correlations"] = {a: {b: float(correlation.loc[a, b]) if np.isfinite(correlation.loc[a, b]) else None
                                                for b in cols} for a in cols}
            excluded = aligned[~aligned["_acct_key"].isin(exposed_accounts["SELECT"])]
            result["select_excluded"] = {
                "rows": len(excluded), "excluded_rows": len(aligned) - len(excluded),
                "metrics": {c: metrics(excluded[label].to_numpy(), excluded[c].to_numpy()) for c in cols},
                "ft_vs": {c: paired_interval(excluded[label].to_numpy(), excluded["score_ft"].to_numpy(),
                                             excluded[c].to_numpy(), excluded[account], config.get("bootstrap_draws", 1000))
                          for c in cols if c != "score_ft"}}
            result["interpretation"] = "Descriptive common-valid comparison; SELECT-excluded view reported separately. Training/development overlaps remain qualified."
            result["incumbent_training_provenance"] = config.get("incumbent_training_provenance", "unknown; no held-out incumbent claim")
            result["embedding_diagnostics"] = (
                benchmark_embedding_diagnostics(validated_embeddings)
                if validated_embeddings is not None else
                {"status": "unavailable", "reason": "ft_embedding_export not configured", "fit_called": False})
            result["duplicates"] = duplicate_summary(audit)
        aligned.drop(columns=["_acct_key", "_business_input_file"], errors="ignore").to_parquet(out / "aligned.parquet", index=False)
        write_json(out / "report.json", result)
        completed = True
        return result
    finally:
        pd.DataFrame(audit, columns=["source", "id", "copies", "exact", "conflicting_columns"]).to_csv(out / "duplicate_audit.csv", index=False)
        write_json(out / "duplicate_summary.json", duplicate_summary(audit))
        write_json(out / "exposure.json", exposure_record(
            "BENCH", "benchmark_scoring",
            {"targets": config["targets"], "scores": {n: s["paths"] for n, s in config.get("scores", {}).items()},
             "other_roles": config.get("other_roles", {}), "ft_embedding_export": config.get("ft_embedding_export")},
            completed, mode="comparison" if compare else "plumbing_only", labels_read=True,
            freeze_sha256=_safe_digest(frozen_path, filesystem) if compare else None,
            count_mismatch_override_requested=bool(allow_count_mismatch), benchmark_counts=count_check))


def _safe_digest(path, filesystem=None):
    try:
        return digest(path, filesystem) if path else None
    except Exception:  # noqa: BLE001 - the record must not mask the run's own error
        return None


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--compare", action="store_true")
    p.add_argument("--frozen")
    p.add_argument("--allow-count-mismatch", action="store_true", help="record and permit a benchmark count mismatch")
    args = p.parse_args(argv)
    cfg = read_json(args.config)
    fs = None
    if cfg.get("s3_cred_path"):
        from YOUR_PACKAGE.v2.storage import thin_read_filesystem
        fs = thin_read_filesystem(cfg["s3_cred_path"])
    run(cfg, args.out, args.compare, args.frozen, fs, args.allow_count_mismatch)


if __name__ == "__main__":
    main()
