"""Print V2 data-size YAML for the corrected REF/A/B runners; never run it.

The input is a selected V1 run's resolved config, not an ablation grid. Only
training file count and, for A/B, the explicitly chosen training stride can
change. The single-transaction reference always keeps every training row.
"""

import argparse
import hashlib
from pathlib import Path

from omegaconf import OmegaConf
from omegaconf.errors import OmegaConfBaseException
from yaml import YAMLError


def _integer(value, name):
    if type(value) is not int or value < 1:
        raise ValueError(f"{name} must be a positive integer")
    return value


def _range(cfg, base_key, start_key, end_key):
    base = OmegaConf.select(cfg, base_key, throw_on_missing=True)
    if not isinstance(base, str) or not base.strip():
        raise ValueError(f"{base_key} must name the existing input location")
    start = _integer(OmegaConf.select(cfg, start_key), start_key)
    end = _integer(OmegaConf.select(cfg, end_key), end_key)
    if start > end:
        raise ValueError(f"{start_key} must not exceed {end_key}")
    # S3 object keys are literal; do not normalize '..' inside a bucket prefix.
    identity = base.rstrip("/") if "://" in base else str(Path(base).resolve())
    return identity, start, end


def _overlaps(left, right):
    return left[0] == right[0] and max(left[1], right[1]) <= min(left[2], right[2])


def build_spec(base_config, *, train_ends, stride, output_root="ablations/v2/data_size"):
    """Build one declared stride condition without reading data or artifacts.

    File numbers are inclusive: end 100 means part_1 through part_100 (100
    total). Additional endpoints are deliberate proposals, not inferred runs.
    """
    path = Path(base_config).resolve()
    raw = path.read_bytes()
    cfg = OmegaConf.create(raw.decode("utf-8"))
    # Fail on unresolved required values rather than inventing a winner's settings.
    resolved = OmegaConf.to_container(cfg, resolve=True, throw_on_missing=True)
    if OmegaConf.to_container(cfg, resolve=False) != resolved:
        raise ValueError("base_config must be fully resolved; use the run's resolved_train.yaml")
    train = _range(cfg, "data.train_base", "data.train_start", "data.train_end")
    validation = _range(cfg, "data.val_base", "data.val_start", "data.val_end")
    evaluation = _range(cfg, "eval.base", "eval.file_start", "eval.file_end")
    if train[1:] != (1, 10):
        raise ValueError("base_config must be the selected V1 part_1..10 run")
    if validation[1:] != (4950, 4954) or evaluation[1:] != (8000, 8010):
        raise ValueError("preserve V1 validation 4950..4954 and evaluation 8000..8010")
    model_type = OmegaConf.select(cfg, "model.type")
    runners = {
        "FTTransformer": "YOUR_PACKAGE/base/scripts/run_ablations.py",
        "FTTransformerSeq": "YOUR_PACKAGE/phase4a/scripts/run_ablations.py",
        "FTTransformerHier": "YOUR_PACKAGE/phase4b/scripts/run_ablations.py",
    }
    if not isinstance(model_type, str) or model_type not in runners:
        raise ValueError("base_config must identify the selected REF, A or B model")
    is_reference = model_type == "FTTransformer"
    if _integer(OmegaConf.select(cfg, "training.seed"), "training.seed") != 42:
        raise ValueError("this V2 spec preserves seed 42; extra seeds are not allocated")
    if type(stride) is not int or stride not in (1, 10):
        raise ValueError("declare stride 1 (all rows) or 10 (fraud plus every tenth position)")
    if is_reference:
        # train_streaming.py has no sequence settings or stride control.
        if stride != 1:
            raise ValueError("REF-SINGLE supports stride 1 only; its loader keeps every row")
    else:
        if OmegaConf.select(cfg, "sequence.history_time_order") != "strict":
            raise ValueError("base_config must explicitly use sequence.history_time_order=strict")
        if any(_integer(OmegaConf.select(cfg, key), key) != 1
               for key in ("sequence.train_stride", "sequence.eval_stride")):
            raise ValueError("base_config must retain V1 train/evaluation stride 1")
        if stride != 1 and OmegaConf.select(cfg, "sequence.predict_every_transaction", default=False):
            raise ValueError("all-position B supports stride 1 only; do not subsample its outputs")
    for key in ("artifacts.base", "artifacts.version", "predictors.csv_path"):
        if OmegaConf.select(cfg, key) in (None, ""):
            raise ValueError(f"base_config must retain the frozen {key}")
    if _integer(OmegaConf.select(cfg, "artifacts.version"), "artifacts.version") != 1:
        raise ValueError("base_config must retain frozen artifacts.version=1")

    ends = list(train_ends)
    if not ends:
        raise ValueError("declare at least one training endpoint")
    for end in ends:
        _integer(end, "training endpoint")
        if end not in (10, 100) and end <= 100:
            raise ValueError("use 10, 100, or an explicitly selected endpoint above 100")
        proposed = (train[0], 1, end)
        for label, held_out in (("validation", validation), ("evaluation", evaluation)):
            if _overlaps(proposed, held_out):
                raise ValueError(f"training part_1..{end} overlaps {label} file identity")
    if ends != sorted(set(ends)):
        raise ValueError("training endpoints must be unique and increasing")
    root = str(output_root).rstrip("/")
    if not root:
        raise ValueError("output_root must name a V2 output directory")
    root = f"{root}/stride{stride}"
    return {
        "base_config": str(path),
        "output_root": root,
        "results_csv": f"{root}/results.csv",
        "run_score": True,
        "common_overrides": [] if is_reference else [f"sequence.train_stride={stride}"],
        "axes": {"train_files": {f"n{end}": [f"data.train_end={end}"] for end in ends}},
        "v2_data_size": {
            "base_config_sha256": hashlib.sha256(raw).hexdigest(),
            "runner": runners[model_type],
            "condition": "all_rows" if stride == 1 else "all_fraud_plus_positions_mod_10",
            "status": "declared_spec_only_not_run",
        },
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-config", required=True, help="selected V1 run's resolved YAML")
    parser.add_argument("--train-ends", required=True, type=int, nargs="+",
                        help="explicit inclusive endpoints, e.g. 10 100; 200/500 are later choices")
    parser.add_argument("--stride", required=True, type=int, choices=(1, 10))
    parser.add_argument("--output-root", default="ablations/v2/data_size")
    args = parser.parse_args(argv)
    try:
        spec = build_spec(args.base_config, train_ends=args.train_ends,
                          stride=args.stride, output_root=args.output_root)
    except (OSError, ValueError, OmegaConfBaseException, YAMLError) as exc:
        parser.error(str(exc))
    print(OmegaConf.to_yaml(OmegaConf.create(spec)), end="")


if __name__ == "__main__":
    main()
