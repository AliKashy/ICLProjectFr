"""V2 model wrappers. 2026-10-19. V1's model class is subclassed, never edited."""
import torch
from torch import nn

from YOUR_PACKAGE.phase4b.sequential_hier import FTTransformerHierModel

TARGET_ENDING_POLICY = "target_ending_v1"


def target_slot_outputs(logits, target_seq):
    """(logits, labels) of the one target slot of each target-ending window."""
    selected = target_seq != -100
    if not torch.equal(selected.sum(1), torch.ones(selected.shape[0], dtype=torch.long, device=selected.device)):
        raise ValueError("Each target-ending window must carry exactly one target")
    return logits[selected], target_seq[selected]


class FTTransformerHierTargetEnding(FTTransformerHierModel):
    """Strict all-position B: trained on V1 chunks, validated on target-ending windows (one target each).

    Training, the checkpoint contract and the forward pass are V1's. Only validation changes: the loss and
    the metrics (V1's StreamingBinaryMetrics) use the target slot of each window, so epoch selection uses the
    same policy as scoring on SELECT, FINAL and in production.

    The checkpoint records that policy and the window cap outside V1's sequence contract
    (audit finding 40 of 2026-10-19), so the V2 scorer and exporter can refuse a checkpoint validated another way."""

    max_window_rows = None  # set by train_v2 from sequence.max_window_rows
    validation_precision = None  # set by train_v2: validation runs under the training precision (audit finding 50)

    def validation_policy(self):
        return {"name": TARGET_ENDING_POLICY, "max_window_rows": self.max_window_rows,
                "validation_precision": self.validation_precision}

    def on_save_checkpoint(self, checkpoint):
        super().on_save_checkpoint(checkpoint)
        if self.hparams.predict_every_transaction:
            checkpoint["validation_policy"] = self.validation_policy()

    def validation_step(self, batch, batch_idx):
        if not self.hparams.predict_every_transaction:
            return super().validation_step(batch, batch_idx)
        logits, y = target_slot_outputs(self(batch), batch["target_seq"])
        # V1's all-position normalisation (weighted sum over targets, audit finding 41 of 2026-10-19), so valid_loss, which
        # drives ReduceLROnPlateau, is the quantity V1 reported.
        loss = nn.functional.cross_entropy(logits, y, weight=self.loss_fn.weight, reduction="sum") / y.numel()
        self.log("valid_loss", loss, on_epoch=True, on_step=False, prog_bar=True, sync_dist=True,
                 batch_size=int(y.numel()))
        return logits, y
