"""Prepare, run and collect the matched 100-file REF / default-B H15 experiment.

Preparation reads local V1 resolved configs only; it never reads bank data,
artifacts, credentials or remote predictor contents. Native ablation runners do
the training and scoring. Each session is new, with sequential execution by
default; ``--only ref`` / ``--only b15`` permit independent single-GPU processes.
Failed or interrupted lanes require a new prepared session, preserving evidence.
"""

import argparse
from contextlib import contextmanager
import csv
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import traceback
import uuid
import zipfile

from omegaconf import OmegaConf
from omegaconf.errors import OmegaConfBaseException
from yaml import YAMLError

from .data_size_specs import build_spec


ROOT = Path(__file__).resolve().parents[2]
LANES = {
    "ref": ("ablations/ref_single/ref_single_seeds", "seed-s42", "FTTransformer"),
    "b15": ("ablations/arch_b_hier/history_h15_h20", "history-h15", "FTTransformerHier"),
}
# These fields identify prior output destinations, not training/input settings.
OUTPUT_FIELDS = ("output.checkpoint_dir", "experiment.run_name", "experiment.project_name",
                 "eval.checkpoint", "eval.predictions_base", "eval.metrics_output")
MATCH_FIELDS = ("predictors", "artifacts", "datetime", "preprocess", "data.train_base",
                "data.val_base", "data.target_col", "data.positive_label", "data.order_col",
                "data.id_cols", "data.amount_col",
                "eval.base", "eval.file_start", "eval.file_end", "training.seed")
RUN_NAME = "train_files-n100"
WEIGHT_OR_DATA_SUFFIXES = {".ckpt", ".pt", ".pth", ".safetensors", ".onnx", ".bin",
                           ".parquet", ".arrow", ".feather", ".npy", ".npz", ".pkl", ".pickle"}
# Exact credential names also used by the H5 return reader. Do not filter
# arbitrary diagnostic filenames merely because they contain one of these words.
SECRET_NAMES = {"test.yaml", "credentials", "credential", "secrets", "secret",
                ".env", ".env.local", ".aws", ".ssh", "aws_credentials",
                "access_token", "refresh_token", "private_key", "access_key", "password",
                "credentials.json", "credentials.yaml", "credentials.yml", "credential.json",
                "secrets.json", "secrets.yaml", "secrets.yml", "secret.json", "secret.yaml",
                "secret.yml", "password.json", "password.yaml", "access_token.json",
                "refresh_token.json", "private_key.json", "access_key.json"}


def _now():
    return datetime.now(timezone.utc).isoformat()


def _unique():
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:12]


def _sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _json(path, value):
    path = Path(path)
    temp = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        temp.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def _load(path):
    return json.loads(Path(path).read_text())


def _config(path, lane):
    # Reuse the bounded metadata checks and model-family routing in the generator.
    build_spec(path, train_ends=[100], stride=1)
    cfg = OmegaConf.load(path)
    if cfg.model.type != LANES[lane][2]:
        raise ValueError(f"{lane} needs model.type={LANES[lane][2]}")
    if lane == "b15":
        required = {"sequence.history_len": 15, "sequence.attention_mask": "bidirectional",
                    "model.continuous_embedding": "linear", "training.optimizer": "adamw"}
        for key, value in required.items():
            if OmegaConf.select(cfg, key) != value:
                raise ValueError(f"default B H15 needs {key}={value}")
        if OmegaConf.select(cfg, "sequence.predict_every_transaction", default=False):
            raise ValueError("b15 must be default B, not all-position B")
        for key in ("data.account_col", "data.tie_break_col"):
            if OmegaConf.select(cfg, key) not in list(OmegaConf.select(cfg, "data.id_cols") or []):
                raise ValueError(f"default B H15 needs {key} in the shared data.id_cols")
    if OmegaConf.select(cfg, "eval.compute_metrics") is not True:
        raise ValueError("selected V1 config must enable eval.compute_metrics")
    if not OmegaConf.select(cfg, "eval.predictions_base"):
        raise ValueError("selected V1 config must retain eval.predictions_base")
    return cfg


def _settings_digest(cfg):
    normalized = OmegaConf.to_container(cfg, resolve=True)
    for key in OUTPUT_FIELDS:
        parent, _, name = key.partition(".")
        if isinstance(normalized.get(parent), dict):
            normalized[parent].pop(name, None)
    return hashlib.sha256(json.dumps(normalized, sort_keys=True).encode()).hexdigest()


def select_config(root, lane, explicit=None):
    """Select only equivalent discovered settings; record all candidates/rejections."""
    root = Path(root).resolve()
    if explicit is not None:
        paths = [Path(explicit) if Path(explicit).is_absolute() else root / explicit]
    else:
        output, run, _ = LANES[lane]
        paths = sorted((root / output).glob(f"*/{run}/resolved_train.yaml"))
    valid, candidates = [], []
    for path in paths:
        path = path.resolve()
        item = {"path": str(path)}
        try:
            cfg = _config(path, lane)
            item.update(sha256=_sha(path), settings_sha256=_settings_digest(cfg), status="eligible")
            # Prior checkpoint/result lineage is diagnostic, never a readiness gate.
            manifest = path.parent / "run_manifest.json"
            item["prior_manifest_path"] = str(manifest) if manifest.is_file() else None
            valid.append((path, cfg, item))
        except (OSError, ValueError, OmegaConfBaseException, YAMLError) as exc:
            item.update(status="rejected", reason=str(exc))
        candidates.append(item)
    choice_flag = "--reference-config" if lane == "ref" else "--b15-config"
    if not valid or len({item[2]["settings_sha256"] for item in valid}) != 1:
        detail = "\n".join(f"  {c['path']}: {c.get('reason', c.get('settings_sha256'))}"
                           for c in candidates) or "  no standard attempt configs found"
        problem = "no eligible selected V1 configuration" if not valid else "materially different configurations"
        raise ValueError(f"{lane}: {problem}; provide {choice_flag} PATH explicitly.\n{detail}")
    path, cfg, item = valid[0]  # Sorted path, not a guessed latest or best run.
    return path, cfg, {"selected_path": str(path), "selected_sha256": item["sha256"],
                       "selection": "explicit" if explicit else "lexical_first_equivalent_settings",
                       "candidates": candidates, "settings_sha256": item["settings_sha256"]}


def prepare(*, root=ROOT, name=None, reference_config=None, b15_config=None):
    root = Path(root).resolve()
    name = name or _unique()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", name) or name in (".", ".."):
        raise ValueError("session name must use letters, digits, '.', '_' or '-'")
    session = root / "ablations/v2/data_size" / name
    if session.exists():
        raise FileExistsError(f"session exists; choose a new --name: {session}")
    selected = {lane: select_config(root, lane, explicit)
                for lane, explicit in (("ref", reference_config), ("b15", b15_config))}
    ref, b15 = selected["ref"][1], selected["b15"][1]
    mismatches = [key for key in MATCH_FIELDS if OmegaConf.select(ref, key) != OmegaConf.select(b15, key)]
    if mismatches:
        raise ValueError("REF/B15 configured inputs differ: " + ", ".join(mismatches))
    # All validation happens before the exclusive session creation.
    session.mkdir(parents=True, exist_ok=False)
    plan = {"schema_version": 1, "status": "preparing", "created_utc": _now(), "root": str(root), "session": str(session),
            "name": name, "train_files": [1, 100], "validation_files": [4950, 4954],
            "evaluation_files": [8000, 8010], "seed": 42, "artifact_version": 1,
            "input_verification": "Configured V1 inputs preserved and matched; data, predictor contents, "
                                  "artifact bytes, credentials and prior checkpoints were not read.",
            "settings_policy": "Retain each selected installed V1 recipe, including its batch size, "
                               "accumulation, epoch budget, precision and worker count. Only training "
                               "file count and isolated output destinations change.", "jobs": {}}
    try:
        for lane, (source, cfg, selection) in selected.items():
            folder = session / lane
            folder.mkdir()
            base = folder / "selected_v1.yaml"
            base.write_bytes(source.read_bytes())
            if _sha(base) != selection["selected_sha256"]:
                raise ValueError(f"selected {lane} configuration changed during preparation; use a new session")
            spec = build_spec(base, train_ends=[100], stride=1, output_root=folder / "native")
            # Override only output destinations. Preserve the source snapshot byte-for-byte.
            prediction_base = str(cfg.eval.predictions_base).rstrip("/") + f"/v2_006/{name}/{lane}"
            spec["common_overrides"].extend([
                f"eval.predictions_base={prediction_base}",
                f"experiment.project_name={folder / 'tensorboard'}",
            ])
            spec["attempt_tag"] = name
            attempt = Path(spec["output_root"]) / name
            spec["results_csv"] = str(attempt / "results.csv")
            spec["v2_data_size"]["status"] = "prepared_not_run"
            spec_file = folder / "spec.yaml"
            OmegaConf.save(OmegaConf.create(spec), spec_file)
            runner = spec["v2_data_size"]["runner"]
            plan["jobs"][lane] = {"folder": str(folder), "base_config": str(base),
                                  "base_sha256": _sha(base), "spec": str(spec_file),
                                  "spec_sha256": _sha(spec_file), "runner": runner,
                                  "attempt": str(attempt), "selection": selection}
        plan["status"] = "prepared"
        _json(session / "plan.json", plan)
    except BaseException:
        (session / "prepare_error.log").write_text(traceback.format_exc())
        plan["status"] = "prepare_failed"
        _json(session / "plan.json", plan)
        raise
    return session


def _read_plan(session, *, allow_failed=False):
    session = Path(session).resolve()
    plan = _load(session / "plan.json")
    if plan.get("schema_version") != 1 or plan.get("session") != str(session):
        raise ValueError("unknown or relocated scale session; prepare in the installed project")
    if plan.get("status") != "prepared" and not allow_failed:
        raise ValueError("incomplete preparation; collect its diagnostics and prepare a new session")
    return session, plan


@contextmanager
def _lane_lock(folder):
    with (Path(folder) / ".run.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise ValueError(f"lane already running: {folder}") from exc
        try:
            yield
        finally:
            fcntl.flock(lock, fcntl.LOCK_UN)


def _native_result(job, returncode):
    if returncode != 0:
        return "runner_failed", None
    attempt = Path(job["attempt"])
    try:
        with (attempt / "results.csv").open(newline="") as stream:
            rows = list(csv.DictReader(stream))
        if len(rows) != 1:
            raise ValueError("expected exactly one native result")
        row = rows[0]
        if (row["run_name"] != RUN_NAME or row["attempt"] != attempt.name
                or Path(row["run_dir"]).resolve() != attempt / RUN_NAME
                or row["status"] != "ok" or row["train_rc"] != "0" or row["score_rc"] != "0"):
            raise ValueError("native result did not finish training and scoring successfully")
        manifest = _load(attempt / RUN_NAME / "run_manifest.json")
        result = manifest["result"]
        if any(str(result.get(key)) != row[key]
               for key in ("run_name", "attempt", "run_dir", "status", "train_rc", "score_rc")):
            raise ValueError("native manifest/result identity or status differs")
        return "ok", row
    except (OSError, ValueError, KeyError, TypeError) as exc:
        return "native_result_incomplete", {"error": str(exc)}


def run(session, *, only=None):
    session, plan = _read_plan(session)
    failed = False
    for lane in ([only] if only else list(LANES)):
        job = plan["jobs"][lane]
        folder = Path(job["folder"])
        with _lane_lock(folder):
            state_path = folder / "state.json"
            if state_path.exists() or Path(job["attempt"]).exists():
                raise ValueError(f"{lane} was already started; outputs are preserved. "
                                 "Use --only for an unstarted lane or prepare a new session.")
            for key, digest in (("base_config", "base_sha256"), ("spec", "spec_sha256")):
                if _sha(job[key]) != job[digest]:
                    raise ValueError(f"prepared {lane} {key} changed; prepare a new session")
            command = [sys.executable, str(Path(plan["root"]) / job["runner"]), "--config", job["spec"]]
            state = {"status": "running", "started_utc": _now(), "command": command,
                     "attempt": job["attempt"], "CUDA_VISIBLE_DEVICES": os.environ.get("CUDA_VISIBLE_DEVICES"),
                     "runner_rc": None}
            _json(state_path, state)
            try:
                with (folder / "runner.log").open("x") as stream:
                    process = subprocess.run(command, cwd=plan["root"], stdout=stream,
                                             stderr=subprocess.STDOUT,
                                             env={**os.environ, "PYTHONUNBUFFERED": "1"})
                state["runner_rc"] = process.returncode
                state["status"], state["result"] = _native_result(job, process.returncode)
            except BaseException as exc:
                state["status"] = "interrupted" if isinstance(exc, (KeyboardInterrupt, SystemExit)) else "launch_failed"
                (folder / "launcher_error.log").write_text(traceback.format_exc())
                if isinstance(exc, (KeyboardInterrupt, SystemExit)):
                    raise
            finally:
                state["finished_utc"] = _now()
                _json(state_path, state)
            print(f"{lane}: {state['status']} ({folder / 'runner.log'})", flush=True)
            failed |= state["status"] != "ok"
    return 1 if failed else 0


def _excluded(path, session):
    parts = path.relative_to(session).parts
    name, suffix = path.name.lower(), path.suffix.lower()
    if path.is_symlink():
        return "symlink_not_followed"
    if any(part.lower() in SECRET_NAMES for part in parts) or suffix in {".pem", ".key"}:
        return "credential_or_secret_file"
    if suffix in WEIGHT_OR_DATA_SUFFIXES:
        return "checkpoint_or_prediction_data"
    if any(part.lower() in ("predictions", "prediction") for part in parts[:-1]):
        return "prediction_directory"
    if suffix in {".csv", ".jsonl", ".ndjson"} and (
        "prediction_rows" in name or "predictions_rows" in name
        or path.stem.lower().endswith("_preds")
        or (name.startswith("prediction") and name not in {
            "prediction_metrics.csv", "predictions_metrics.csv"})
    ):
        return "prediction_data"
    if path.name == ".run.lock":
        return "runtime_lock"
    return None


def collect(session, *, destination=None):
    """Archive every session diagnostic, even on failure; leave weights/data on pod."""
    session, plan = _read_plan(session, allow_failed=True)
    destination = Path(destination) if destination else Path(plan["root"]) / "runs/returns/v2_006"
    destination = destination.resolve()
    if destination == session or session in destination.parents:
        raise ValueError("return destination must be outside the source session")
    destination.mkdir(parents=True, exist_ok=True)
    archive = destination / f"{session.name}__{_unique()}.zip"
    included, excluded = [], []
    states = {lane: _load(Path(job["folder"]) / "state.json")
              if (Path(job["folder"]) / "state.json").is_file() else {"status": "not_started"}
              for lane, job in plan["jobs"].items()}
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as bundle:
        for path in sorted(session.rglob("*")):
            if path.is_dir() and not path.is_symlink():
                continue
            relative = path.relative_to(session).as_posix()
            reason = _excluded(path, session)
            if reason:
                excluded.append({"path": relative, "reason": reason})
                continue
            # Hash exactly the archived bytes, even if a live log grows during collection.
            digest = hashlib.sha256()
            with path.open("rb") as source, bundle.open(f"{session.name}/{relative}", "w") as target:
                for block in iter(lambda: source.read(1024 * 1024), b""):
                    target.write(block)
                    digest.update(block)
            included.append({"path": relative, "sha256": digest.hexdigest()})
        receipt = {"schema_version": 1, "collected_utc": _now(), "session": str(session),
                   "preparation_status": plan["status"],
                   "states": states, "included": included, "excluded": excluded,
                   "note": "Diagnostic snapshot; collection success does not mean training succeeded. "
                           "Collect after all workers finish for a complete return. Checkpoints and "
                           "prediction data remain on the pod; their native manifests remain included."}
        bundle.writestr(f"{session.name}/COLLECTION.json", json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    return archive


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    prepare_parser = commands.add_parser("prepare", help="derive new specs from selected local V1 resolved configs")
    prepare_parser.add_argument("--name", help="unique session name; default UTC timestamp plus random suffix")
    prepare_parser.add_argument("--reference-config", help="explicit selected REF resolved_train.yaml")
    prepare_parser.add_argument("--b15-config", help="explicit selected default-B H15 resolved_train.yaml")
    run_parser = commands.add_parser("run", help="train and score sequentially with existing native runners")
    run_parser.add_argument("--session", required=True, help="prepared session directory")
    run_parser.add_argument("--only", choices=list(LANES), help="run one lane on this process's visible GPU")
    collect_parser = commands.add_parser("collect", help="archive session diagnostics, including failures")
    collect_parser.add_argument("--session", required=True)
    collect_parser.add_argument("--destination", help="return ZIP directory; defaults to runs/returns/v2_006")
    args = parser.parse_args(argv)
    try:
        if args.command == "prepare":
            session = prepare(name=args.name, reference_config=args.reference_config, b15_config=args.b15_config)
            print(f"SCALE_SESSION={session}")
            print(f"Configured inputs only; review {session / 'plan.json'} before the owner starts run.")
        elif args.command == "run":
            return run(args.session, only=args.only)
        else:
            print(f"SCALE_RETURN={collect(args.session, destination=args.destination)}")
    except (OSError, ValueError, KeyError, OmegaConfBaseException, YAMLError) as exc:
        parser.error(str(exc))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
