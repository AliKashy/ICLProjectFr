"""V2 per-account strictly-earlier window primitives (transaction-time features).

V2 only. Nothing in V1 imports this module.

The rule (RECONCILIATION.md R-1 to R-3 in the features reconciliation record of 2026-10-12):

- A value for row i uses only rows of the same account whose time key is
  STRICTLY earlier than row i's, inside ``t_i - w <= e_j < t_i``. A row exactly
  w earlier is inside; a row with the same time key is outside. Same-time
  siblings therefore never see each other and share one eligible past; a row's
  values never change when a same-time sibling is added.
- The time key is the parsed timestamp at its stored precision
  (``datetime64[ns]`` as int64), the same key the V1 strict rule compares in
  ``YOUR_PACKAGE/phase4a/sequence_builder.py`` (``order_key``, history_time_order
  'strict'). It is never rounded to whole seconds.
- A window that reaches before the declared extract start
  (``t_i - w < extract_start``) is CENSORED: the primitives return NaN for it,
  never an empty-window zero. The extract start is a documented constant per
  split (training and validation 2024-10-01, evaluation 2025-05-01), passed in,
  never computed from the data.
- The frame must hold the account's whole in-extract history (all files of the
  split concatenated, or files confirmed to partition accounts; R-3 (b)).

Every primitive takes eligibility masks for the earlier rows (``where``) so that
missing raw values add nothing and are never counted as zero. Values are
returned in the caller's row order.

Most primitives are prefix sums over a (group, time) sort plus one
``searchsorted`` per window. Distinct counts, mid-ranks and medians expand the
(row, earlier row) pairs of each window in bounded chunks; they cost the sum of
the window sizes.
"""

from typing import Dict, Iterator, Optional, Tuple, Union

import numpy as np
import pandas as pd

from YOUR_PACKAGE.base.data.input_contracts import parse_required_timestamps, require_account_ids

NS_PER_SECOND = 1_000_000_000
DAY_SECONDS = 86_400

# The joint window set, declared once (E01 change; JD rank 1).
WINDOWS: Dict[str, int] = {
    "5m": 300,
    "1h": 3_600,
    "24h": DAY_SECONDS,
    "7d": 7 * DAY_SECONDS,
    "30d": 30 * DAY_SECONDS,
}

# Documented split extract starts (JD:281; DECISIONS.md:20).
EXTRACT_START = {
    "train": "2024-10-01",
    "validation": "2024-10-01",
    "evaluation": "2025-05-01",
}

_PAIR_CHUNK = 4_000_000

Window = Union[str, int]


def window_ns(w: Window) -> int:
    """A window label from ``WINDOWS`` or a width in whole seconds, as nanoseconds."""
    if isinstance(w, str):
        if w not in WINDOWS:
            raise ValueError(f"unknown window {w!r}; declared windows are {sorted(WINDOWS)}")
        seconds = WINDOWS[w]
    else:
        seconds = int(w)
    if seconds <= 0:
        raise ValueError("a window must be a positive number of seconds")
    return seconds * NS_PER_SECOND


def time_key(values, column: str = "transaction_dttm") -> np.ndarray:
    """The stored-precision time key: parsed timestamps as int64 nanoseconds.

    Same parsing and conversion as the V1 strict rule (``parse_required_timestamps``
    then ``to_numpy(dtype='datetime64[ns]')``): missing or unparseable times fail.
    """
    parsed = parse_required_timestamps(values, column)
    return parsed.to_numpy(dtype="datetime64[ns]").astype(np.int64)


def extract_start_key(value) -> int:
    """A declared extract start (date text, Timestamp or a split name) as int64 ns."""
    if isinstance(value, str) and value in EXTRACT_START:
        value = EXTRACT_START[value]
    return int(pd.Timestamp(value).to_datetime64().astype("datetime64[ns]").astype(np.int64))


def codes(*arrays) -> np.ndarray:
    """Integer codes of the tuple of raw values; -1 when any part is missing.

    Values are compared as stored (raw codes, before any vocabulary or UNK
    collapse). A missing part never matches anything.
    """
    n = len(arrays[0])
    missing = np.zeros(n, dtype=bool)
    parts = []
    for a in arrays:
        c, _ = pd.factorize(pd.Series(a, copy=False), use_na_sentinel=True)
        missing |= c < 0
        parts.append(c.astype(np.int64))
    if len(parts) == 1:
        out = parts[0]
    else:
        _, out = np.unique(np.stack(parts, axis=1), axis=0, return_inverse=True)
        out = out.reshape(-1).astype(np.int64)
    return np.where(missing, -1, out)


class _Index:
    """Rows sorted by (group, time) with strictly-earlier and window bounds."""

    def __init__(self, group: np.ndarray, t: np.ndarray):
        self.n = len(t)
        self.order = np.lexsort((t, group))
        self.g_s = group[self.order].astype(np.int64)
        self.t_s = t[self.order]
        self.start_s = np.searchsorted(self.g_s, self.g_s, side="left")
        self.left_s = self.bound(self.t_s)  # first same-group row at or after t: strictly earlier end
        self._lo: Dict[int, np.ndarray] = {}

    def bound(self, q_s: np.ndarray) -> np.ndarray:
        """First sorted position in the row's group whose time is >= q (per sorted row)."""
        uniq, inv = np.unique(np.concatenate([self.t_s, q_s]), return_inverse=True)
        m = np.int64(len(uniq))
        key = self.g_s * m + inv[: self.n]
        query = self.g_s * m + inv[self.n:]
        return np.searchsorted(key, query, side="left")

    def lo(self, w: int) -> np.ndarray:
        if w not in self._lo:
            self._lo[w] = self.bound(self.t_s - w)
        return self._lo[w]

    def to_original(self, values_s: np.ndarray) -> np.ndarray:
        out = np.empty_like(values_s)
        out[self.order] = values_s
        return out

    def sorted_(self, values: np.ndarray) -> np.ndarray:
        return np.asarray(values)[self.order]


def _pairs(lo: np.ndarray, hi: np.ndarray) -> Iterator[Tuple[np.ndarray, np.ndarray]]:
    """Chunks of (row, earlier row) pairs for every row's range [lo, hi)."""
    lens = (hi - lo).astype(np.int64)
    cum = np.cumsum(lens)
    n = len(lens)
    start = 0
    while start < n:
        base = cum[start - 1] if start else 0
        stop = int(np.searchsorted(cum, base + _PAIR_CHUNK, side="right"))
        stop = max(stop, start + 1)
        rows = np.arange(start, stop)
        rep = lens[start:stop]
        seg = np.repeat(rows, rep)
        offs = np.arange(len(seg)) - np.repeat(np.cumsum(rep) - rep, rep)
        yield seg, lo[seg] + offs
        start = stop


class StrictWindows:
    """Strictly-earlier windows of each row's own account.

    Args:
        account: account key per row (``Nmap_account_reference_xid``); no missing values.
        t: stored-precision time key per row (``time_key``), int64 nanoseconds.
        extract_start: declared extract start as int64 ns (``extract_start_key``);
            ``None`` disables censoring (tests only).
    """

    def __init__(self, account, t, extract_start):
        require_account_ids(pd.Series(account, copy=False), "account")
        self.t = np.asarray(t, dtype=np.int64)
        self.n = len(self.t)
        self.account = codes(np.asarray(account, dtype=object))
        self.extract_start = None if extract_start is None else np.int64(extract_start)
        self._acct = _Index(self.account, self.t)

    # -- coverage ---------------------------------------------------------- #
    def censored(self, w: Window) -> np.ndarray:
        """True where the window reaches before the extract start."""
        if self.extract_start is None:
            return np.zeros(self.n, dtype=bool)
        return (self.t - window_ns(w)) < self.extract_start

    def first_time(self) -> np.ndarray:
        """Time key of the account's first row in the frame (at or before each row)."""
        ix = self._acct
        return ix.to_original(ix.t_s[ix.start_s])

    def _censor(self, values: np.ndarray, w: Window) -> np.ndarray:
        values = values.astype(float)
        values[self.censored(w)] = np.nan
        return values

    def _index(self, by: Optional[np.ndarray]) -> _Index:
        if by is None:
            return self._acct
        return _Index(codes(self.account, by), self.t)

    # -- counts and sums --------------------------------------------------- #
    def count(self, w: Window, where=None) -> np.ndarray:
        """#{j strictly earlier, same account, in [t - w, t), where_j}."""
        ix = self._acct
        ok = np.ones(self.n, dtype=bool) if where is None else np.asarray(where, dtype=bool)
        cs = np.concatenate([[0], np.cumsum(ix.sorted_(ok).astype(np.int64))])
        lo = ix.lo(window_ns(w))
        return self._censor(ix.to_original(cs[ix.left_s] - cs[lo]), w)

    def sum(self, w: Window, values, where=None) -> np.ndarray:
        """Sum of ``values_j`` over eligible earlier rows of the window.

        Rows with ``where`` false, or with a non-finite value, add nothing. Each
        window is summed on its own, in (time, value) order, so the result does
        not depend on the input row order or on other accounts' rows.
        """
        ix = self._acct
        v = np.asarray(values, dtype=float)
        ok = np.isfinite(v) if where is None else (np.asarray(where, dtype=bool) & np.isfinite(v))
        v0 = np.where(ok, v, 0.0)
        # Rows of one (account, time) share every window bound, so ordering them
        # by value inside the tie keeps the bounds and fixes the summation order.
        order = np.lexsort((v0, self.t, self.account))
        v_s = v0[order]
        lo = ix.lo(window_ns(w))
        out_s = np.zeros(self.n)
        for seg, j in _pairs(lo, ix.left_s):
            out_s += np.bincount(seg, weights=v_s[j], minlength=self.n)
        out = np.empty(self.n)
        out[order] = out_s
        return self._censor(out, w)

    def match_count(self, w: Window, values, where=None) -> np.ndarray:
        """#{eligible earlier rows of the window whose raw value equals the row's own}.

        A missing value (own or earlier) never matches. Where the row's own value
        is missing the result is 0 here; the feature group decides its meaning.
        """
        c = codes(values)
        ix = self._index(c)
        ok = c >= 0 if where is None else (c >= 0) & np.asarray(where, dtype=bool)
        cs = np.concatenate([[0], np.cumsum(ix.sorted_(ok).astype(np.int64))])
        lo = ix.lo(window_ns(w))
        out = ix.to_original(cs[ix.left_s] - cs[lo])
        return self._censor(np.where(c >= 0, out, 0), w)

    # -- pair-based statistics --------------------------------------------- #
    def _window_pairs(self, ix: _Index, w: Window, ok_s: np.ndarray):
        lo = ix.lo(window_ns(w))
        for seg, j in _pairs(lo, ix.left_s):
            keep = ok_s[j]
            yield seg[keep], j[keep]

    def distinct_count(self, w: Window, values, where=None) -> np.ndarray:
        """Number of distinct observed raw values among eligible earlier rows of the window."""
        c = codes(values)
        ix = self._acct
        ok = c >= 0 if where is None else (c >= 0) & np.asarray(where, dtype=bool)
        c_s = ix.sorted_(c)
        out_s = np.zeros(self.n, dtype=np.int64)
        k = np.int64(max(int(c.max(initial=0)) + 1, 1))
        for seg, j in self._window_pairs(ix, w, ix.sorted_(ok)):
            u = np.unique(seg.astype(np.int64) * k + c_s[j])
            out_s += np.bincount(u // k, minlength=self.n)
        return self._censor(ix.to_original(out_s), w)

    def mid_rank(self, w: Window, values, where=None, by=None):
        """(#{x_j < x_i} + 0.5 #{x_j = x_i}) / |Q| and |Q|.

        Q is the eligible earlier rows of the window with a finite value and, when
        ``by`` is given, the same ``by`` value as row i (a missing ``by`` matches
        nothing). The rank is NaN where Q is empty or x_i is not finite.
        Returns (rank, support).
        """
        x = np.asarray(values, dtype=float)
        ix = self._index(by)
        ok = np.isfinite(x) if where is None else np.isfinite(x) & np.asarray(where, dtype=bool)
        if by is not None:
            ok &= codes(by) >= 0
        x_s = ix.sorted_(x)
        less = np.zeros(self.n)
        equal = np.zeros(self.n)
        support = np.zeros(self.n)
        for seg, j in self._window_pairs(ix, w, ix.sorted_(ok)):
            xi, xj = x_s[seg], x_s[j]
            less += np.bincount(seg, weights=(xj < xi), minlength=self.n)
            equal += np.bincount(seg, weights=(xj == xi), minlength=self.n)
            support += np.bincount(seg, minlength=self.n)
        with np.errstate(invalid="ignore", divide="ignore"):
            rank_s = np.where((support > 0) & np.isfinite(x_s), (less + 0.5 * equal) / support, np.nan)
        if by is not None:
            # a row whose own comparable key is missing has no comparable set
            bad = ix.sorted_(codes(by) < 0)
            rank_s[bad] = np.nan
            support[bad] = np.nan
        rank = self._censor(ix.to_original(rank_s), w)
        return rank, self._censor(ix.to_original(support), w)

    def median(self, w: Window, values, where=None, by=None):
        """Median of Q (as in ``mid_rank``) and |Q|; NaN where Q is empty."""
        x = np.asarray(values, dtype=float)
        ix = self._index(by)
        ok = np.isfinite(x) if where is None else np.isfinite(x) & np.asarray(where, dtype=bool)
        if by is not None:
            ok &= codes(by) >= 0
        x_s = ix.sorted_(x)
        med_s = np.full(self.n, np.nan)
        support = np.zeros(self.n)
        for seg, j in self._window_pairs(ix, w, ix.sorted_(ok)):
            if len(seg) == 0:
                continue
            xj = x_s[j]
            o = np.lexsort((xj, seg))
            seg, xj = seg[o], xj[o]
            rows, first, cnt = np.unique(seg, return_index=True, return_counts=True)
            lo_mid = xj[first + (cnt - 1) // 2]
            hi_mid = xj[first + cnt // 2]
            med_s[rows] = (lo_mid + hi_mid) / 2.0
            support[rows] = cnt
        if by is not None:
            bad = ix.sorted_(codes(by) < 0)
            med_s[bad] = np.nan
            support[bad] = np.nan
        med = self._censor(ix.to_original(med_s), w)
        return med, self._censor(ix.to_original(support), w)


def from_frame(df: pd.DataFrame, extract_start, account_col: str = "Nmap_account_reference_xid",
               time_col: str = "transaction_dttm") -> StrictWindows:
    """``StrictWindows`` on a raw frame's account key and stored-precision time key."""
    es = None if extract_start is None else extract_start_key(extract_start)
    return StrictWindows(df[account_col].to_numpy(), time_key(df[time_col], time_col), es)
