"""V2 transaction-time feature groups.

V2 only. Nothing in V1 imports this module.

Each function implements one row of
the features reconciliation record of 2026-10-12 (CANDIDATES.csv) whose
verdict is "agree" or "agree with a change" and whose data is in the
23-predictor raw schema, with the row's "change" column as the specification.
Every value uses only the row's own fields and strictly earlier rows of the
same account (``strict_window``). A missing value is NaN (or "missing" in a
status column); a zero is always a measured zero; a censored window (one that
reaches before the declared extract start) is always missing. No function
reads a label column.

Amounts: until CQ-01 (currency, refunds) is answered all amounts are taken as
one currency (gate Q1 on E10 to E13).
"""

import numpy as np
import pandas as pd

from YOUR_PACKAGE.v2.features.strict_window import DAY_SECONDS, NS_PER_SECOND, codes, from_frame

AMOUNT = "transaction_amt"
TYPE = "transaction_type_xcd"
COUNT_WINDOWS = ("5m", "1h", "24h", "7d", "30d")


def _num(df, col):
    return pd.to_numeric(df[col], errors="coerce").to_numpy(dtype=float)


def velocity(sw, df):
    """E01: log1p(#P_w) for the joint windows. Missing if censored; an empty complete window is 0."""
    return {f"cnt_{w}_log1p": np.log1p(sw.count(w)) for w in COUNT_WINDOWS}


def coverage(sw, df):
    """C5: no_prior_30d = 1[P_30d empty]; obs_days_30 = min(days since the account's first row, 30).

    Both missing while the 30-day window is censored.
    """
    cnt30 = sw.count("30d")
    days = (sw.t - sw.first_time()) / (DAY_SECONDS * NS_PER_SECOND)
    return {
        "no_prior_30d": np.where(np.isnan(cnt30), np.nan, (cnt30 == 0).astype(float)),
        "obs_days_30": np.where(sw.censored("30d"), np.nan, np.minimum(days, 30.0)),
    }


def acceleration(sw, df):
    """E02: log1p(n_1h / 1) - log1p((n_24h - n_1h) / 23), events per hour. Missing if 24 h is censored."""
    n1, n24 = sw.count("1h"), sw.count("24h")
    return {"accel_1h_vs_23h": np.log1p(n1) - np.log1p((n24 - n1) / 23.0)}


def type_familiarity(sw, df):
    """E08: |{j in Q: type_j = type_i}| / |Q|, Q = earlier rows in 30 d with an observed type.

    Fraction missing if censored, current type missing or Q empty; 0 if Q never
    matches. Support |Q| missing only if censored.
    """
    typ = df[TYPE].to_numpy(dtype=object)
    observed = ~pd.isna(typ)
    support = sw.count("30d", where=observed)
    match = sw.match_count("30d", typ, where=observed)
    with np.errstate(invalid="ignore", divide="ignore"):
        frac = np.where(observed & (support > 0), match / support, np.nan)
    return {"type_frac_30d": frac, "type_support_30d": support}


def _comparable(df):
    """Amounts, which are finite, and the comparable key (same type and same sign)."""
    x = _num(df, AMOUNT)
    finite = np.isfinite(x)
    sign = np.where(finite, np.where(x < 0, "neg", "nonneg"), None).astype(object)
    key = codes(df[TYPE].to_numpy(dtype=object), sign)
    return x, finite, np.where(key < 0, np.nan, key.astype(float))


def amount_vs_median(sw, df):
    """E10: x_i - median(Q), Q = finite earlier amounts in 30 d with the same type and sign.

    Missing if censored, current amount or type missing, or Q empty. Support |Q|
    missing if censored or current amount or type missing.
    """
    x, finite, key = _comparable(df)
    med, support = sw.median("30d", x, where=finite, by=key)
    return {"amt_minus_med_30d": np.where(finite, x - med, np.nan), "amt_med_support_30d": support}


def amount_midrank(sw, df):
    """E11: (#{x_j < x_i} + 0.5 #{x_j = x_i}) / |Q|, Q as E10; a constant history equal to x_i gives 0.5."""
    x, finite, key = _comparable(df)
    rank, support = sw.mid_rank("30d", x, where=finite, by=key)
    return {"amt_midrank_30d": rank, "amt_rank_support_30d": support}


def spend_24h(sw, df):
    """E12: sum and count of observed non-negative earlier amounts in 24 h.

    Missing if censored; the sum is missing when the count is 0; 0 only for
    observed zero amounts.
    """
    x = _num(df, AMOUNT)
    ok = np.isfinite(x) & (x >= 0)
    n = sw.count("24h", where=ok)
    return {"spend_24h": np.where(n > 0, sw.sum("24h", x, where=ok), np.nan), "spend_n_24h": n}


def _ratio(x, b):
    status = np.select([~np.isfinite(b), b > 0, b == 0], ["missing", "positive", "zero"],
                       default="negative").astype(object)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(np.isfinite(x) & (status == "positive"), x / b, np.nan), status


def amount_over_capacity(sw, df):
    """E13: x_i / b_i for the available balance and the remaining merchandise limit (current row).

    Ratio missing unless the amount is observed and b_i > 0 (no epsilon). Status
    is always set: positive, zero, negative or missing.
    """
    x = _num(df, AMOUNT)
    r_bal, s_bal = _ratio(x, _num(df, "total_available_balance_amt"))
    r_lim, s_lim = _ratio(x, _num(df, "remain_day_merchandise_lmt_amt"))
    return {"amt_over_balance": r_bal, "amt_over_balance_status": s_bal,
            "amt_over_merch_lmt": r_lim, "amt_over_merch_lmt_status": s_lim}


def cash_limit_observed(sw, df):
    """E14: #{j in P_30d: cash limit observed} / |P_30d|. Missing if censored or P_30d empty.

    Observed means a finite number after numeric coercion; missing, non-numeric
    and infinite values are unobserved until the sentinels are documented.
    """
    observed = np.isfinite(_num(df, "available_daily_cash_limit_amt"))
    support = sw.count("30d")
    with np.errstate(invalid="ignore", divide="ignore"):
        frac = np.where(support > 0, sw.count("30d", where=observed) / support, np.nan)
    return {"cash_lmt_obs_frac_30d": frac, "cash_lmt_support_30d": support}


# The agreed groups: (name, CANDIDATES.csv row, function).
GROUPS = [
    ("velocity", "E01", velocity),
    ("coverage", "C5", coverage),
    ("acceleration", "E02", acceleration),
    ("type_familiarity", "E08", type_familiarity),
    ("amount_vs_median", "E10", amount_vs_median),
    ("amount_midrank", "E11", amount_midrank),
    ("spend_24h", "E12", spend_24h),
    ("amount_over_capacity", "E13", amount_over_capacity),
    ("cash_limit_observed", "E14", cash_limit_observed),
]


def compute_groups(df: pd.DataFrame, extract_start) -> pd.DataFrame:
    """Every group's columns for every row of ``df``, aligned to ``df.index``.

    ``df`` must hold each account's whole in-extract history for the split.
    ``extract_start`` is the split's declared start: a split name ("train",
    "validation", "evaluation") or a date; ``None`` only in tests.
    """
    sw = from_frame(df, extract_start)
    out = {}
    for _, _, func in GROUPS:
        out.update(func(sw, df))
    return pd.DataFrame(out, index=df.index)
