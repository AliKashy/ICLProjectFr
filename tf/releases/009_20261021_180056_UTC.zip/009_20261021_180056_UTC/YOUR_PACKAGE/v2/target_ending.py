"""Target-ending windows for strict all-position (chunk-trained) B models.

2026-10-19. Governing plan `bridge/plans/2026-10-19-v2-one-gpu/PLAN.md` section 8 item 3: a chunk model
is trained on V1's disjoint chunks, but validated, scored and exported the way a live system scores, one
window per transaction ending at that transaction.

The window of row r holds every row of r's account (in its file) whose whole second is one of the H distinct
whole seconds before r's second, the rows of r's own second whose timestamp is strictly earlier than r's,
and r itself as the last real slot. Under the strict time mask (V1 B9) a row can only be influenced by rows
with a strictly earlier timestamp, so the rows left out (same-time peers of r, later rows) cannot change r's
output. r therefore gets exactly the score it gets inside a V1 chunk that ends at its second with H full
earlier seconds. Gaps, positions and ``time_seq`` follow V1's chunk rules, with the window playing the chunk:
the gap of the window's opening group is 0, as at a chunk edge.

Labels are -100 everywhere except r's slot, so V1's batching (``SequenceBuilder._emit_batches``) is reused
unchanged and each window carries exactly one target.

``max_window_rows`` is the serving cap (audit finding 31 of 2026-10-19): a window holding more rows keeps its most recent
``max_window_rows`` rows, r included. The cut is a window edge like any other, so the rows of the first kept
second open with gap 0. Validation, scoring and export use the same cap, so the validated policy is the one
that can be served; without a cap (None) every window is complete.
"""
import numpy as np

from YOUR_PACKAGE.phase4b.sequence_builder import SequenceBuilder


NATURAL_ROWS = "_window_natural_rows"  # meta key: the window's rows before any cap (scoring and export only)


def window_bounds(seconds, order_key, history_len, max_window_rows=None):
    """(lo, group_start) per row of one account's sorted rows: row p's window is rows lo[p] .. group_start[p] - 1
    plus p itself, so it holds group_start[p] - lo[p] + 1 rows."""
    n = len(seconds)
    if n and ((np.diff(seconds) < 0).any() or (np.diff(order_key) < 0).any()):
        raise ValueError("Account rows are not chronological")
    if not n:
        return np.zeros(0, np.int64), np.zeros(0, np.int64)
    second_index = np.cumsum(np.r_[True, seconds[1:] != seconds[:-1]]) - 1
    key_start = np.r_[True, order_key[1:] != order_key[:-1]]
    group_start = np.maximum.accumulate(np.where(key_start, np.arange(n), 0))
    lo = np.searchsorted(second_index, np.maximum(second_index - history_len, 0), side="left")
    if max_window_rows is not None:
        lo = np.maximum(lo, group_start - (max_window_rows - 1))  # r plus the latest cap - 1 earlier rows
    return lo, group_start


class TargetEndingBuilder(SequenceBuilder):
    """V1's strict all-position builder, emitting one target-ending window per row instead of chunks."""

    def __init__(self, max_window_rows=None, **kwargs):
        super().__init__(**kwargs)
        if max_window_rows is not None and int(max_window_rows) < 1:
            raise ValueError("max_window_rows must be a positive row count or None")
        self.max_window_rows = None if max_window_rows is None else int(max_window_rows)
        if not self.emit_target_seq or self.history_time_order != "strict":
            raise ValueError("Target-ending windows serve strict all-position models only "
                             "(emit_target_seq=True, history_time_order='strict')")
        if self.stride != 1:
            raise ValueError("Target-ending windows score every row: stride must be 1")

    def window_rows(self, seconds, order_key):
        """Row positions (into one account's sorted rows) of every target's window, in order.

        ``seconds`` are the account's sorted whole seconds and ``order_key`` its sorted timestamps (ns)."""
        lo, group_start = window_bounds(seconds, order_key, self.history_len, self.max_window_rows)
        return [np.r_[np.arange(lo[p], group_start[p]), p] for p in range(len(seconds))]

    def _chunks_for_file(self, cont, cat, target, times, df, meta):
        n_cont, K = cont.shape[1], cat.shape[1]
        C = n_cont + int(self.time_delta)
        order_key = df[self.order_col].to_numpy(dtype="datetime64[ns]").astype("int64")
        for rows in self._account_groups(df).values():
            rows = np.asarray(rows)
            natural = None
            if meta is not None:  # scoring and export report the uncapped size beside the capped one
                lo, gs = window_bounds(times[rows], order_key[rows], self.history_len)
                natural = gs - lo + 1
            for p, picks in enumerate(self.window_rows(times[rows], order_key[rows])):
                window = rows[picks]
                n = len(window)
                if self.max_window_rows is None and self.max_chunk_rows is not None and n > self.max_chunk_rows:
                    # Without a cap, refuse a window wider than the widest chunk (V1's raise-never-truncate rule).
                    # With a cap, the cap governs: a window may be wider than any chunk (audit finding 46 of 2026-10-19).
                    raise ValueError(
                        f"target-ending window of account {df[self.account_col].iloc[window[0]]!r} holds {n} rows > "
                        f"max_chunk_rows={self.max_chunk_rows}; no row is dropped, raise the cap or measure the data")
                width = max(self.T, n)
                w_cont = np.zeros((width, C), dtype=np.float32)
                w_cat = np.zeros((width, K), dtype=np.int64)
                w_mask = np.zeros(width, dtype=bool)
                labels = np.full(width, -100, dtype=np.int64)
                w_cont[:n, :n_cont] = cont[window]
                w_cat[:n] = cat[window]
                w_mask[:n] = True
                labels[n - 1] = target[window[-1]]
                w_time = np.zeros(width, dtype=np.int64)
                w_time[:n] = order_key[window]
                if self.time_delta and n > 1:
                    w_cont[1:n, n_cont] = np.log1p(self._chunk_gaps(times[window], w_time[:n]))
                seq_meta = None
                if meta is not None:
                    seq_meta = {key: np.full(width, None, dtype=object) for key in meta}
                    for key in meta:
                        seq_meta[key][:n] = meta[key][window]
                    seq_meta[NATURAL_ROWS] = np.full(width, int(natural[p]), dtype=object)
                yield w_cont, w_cat, w_mask, None, seq_meta, labels, w_time


class LabelFreeMixin:
    """A builder that never reads the label column (plan review item V4-C4): it is dropped from the columns read, and a constant
    placeholder stands in so V1's window code runs. Every row is kept; the target position comes from the window
    structure (the last real slot), never from a label. Used by the exporter only."""

    PLACEHOLDER = 0

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._read_cols = [c for c in self._read_cols if c != self.target_col]

    def _encode_file(self, df):
        if self.target_col in df.columns:
            raise ValueError(f"label-free reader was given the label column {self.target_col!r}")
        return super()._encode_file(df.assign(**{self.target_col: self.PLACEHOLDER}))


class LabelFreeSequenceBuilder(LabelFreeMixin, SequenceBuilder):
    """V1's single-target builder without the label column."""


class LabelFreeTargetEndingBuilder(LabelFreeMixin, TargetEndingBuilder):
    """The target-ending builder without the label column."""
