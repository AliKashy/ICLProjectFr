"""L2 count-only inventory, one process and one ephemeral salt for both folders.

Reads four columns per selected parquet. No row identifiers, account digests or
salt are written. Positive account intersections are stored sparsely; every
pair of scanned files is checked, including differently numbered cross-folder
files. Separate invocations cannot be joined to establish disjointness.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import secrets
import sys

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from fraud.data.s3_utils import strip_scheme  # noqa: E402
from YOUR_PACKAGE.v2.storage import thin_read_filesystem  # noqa: E402
from YOUR_PACKAGE.base.data.input_contracts import encode_binary_target, parse_required_timestamps  # noqa: E402
from YOUR_PACKAGE.scoring._prediction_utils import id_kind, validate_ids  # noqa: E402

SCHEMA = "tf-v2-inventory-1"
ID, ACCOUNT, TIME, LABEL = "fi_transaction_id", "Nmap_account_reference_xid", "transaction_dttm", "frd_tag"
DEPTH_BANDS = ("0", "1-4", "5-9", "10-19", "20+")


def json_bytes(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()


def write_frozen(path, content):
    """A repeated identical invocation is harmless; never silently replace a frozen result."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != content:
            raise FileExistsError(f"{path} exists with different contents; use a new output path")
        return
    with path.open("xb") as f:
        f.write(content)


def parse_ranges(values):
    numbers = set()
    for value in values or []:
        sides = value.split(":")
        if len(sides) not in (1, 2):
            raise ValueError("ranges must be integer N or inclusive START:END")
        start, end = int(sides[0]), int(sides[-1])
        if start < 1 or end < start:
            raise ValueError("range endpoints must be positive and ordered")
        numbers.update(range(start, end + 1))
    return sorted(numbers)


def is_remote(path):
    return str(path).startswith(("s3://", "s3a://"))


def listing(base, filesystem=None):
    """List all objects, not merely requested part files. No credentials enter the result."""
    if is_remote(base):
        if filesystem is None:
            raise ValueError("S3 paths require --cred-path")
        found = filesystem.find(strip_scheme(base), detail=True)
        if not isinstance(found, dict):
            found = {name: filesystem.info(name) for name in found}
        rows = []
        for name, info in sorted(found.items()):
            if info.get("type") == "directory":
                continue
            row = {"path": "s3://" + strip_scheme(name), "size_bytes": int(info.get("size", info.get("Size", 0)))}
            for key in ("ETag", "VersionId", "LastModified"):
                if info.get(key) is not None:
                    row[key] = str(info[key])
            rows.append(row)
        return rows
    root = Path(base).expanduser().resolve()
    if not root.is_dir():
        raise FileNotFoundError(f"Data directory not found: {root}")
    return [{"path": str(p), "size_bytes": p.stat().st_size, "mtime_ns": p.stat().st_mtime_ns}
            for p in sorted(root.rglob("*")) if p.is_file()]


def parquet(path, columns, filesystem=None):
    path = str(path)
    fs = filesystem if is_remote(path) else None
    return pq.ParquetFile(strip_scheme(path), filesystem=fs).read(columns=columns).to_pandas()


def _digest(value, salt):
    # validate_ids preserves leading zeros and refuses unsafe floats. Numeric
    # 1 and 1.0 must hash identically, while string "1" remains a different kind.
    if isinstance(value, str):
        payload = b"s:" + value.encode("utf-8")
    elif isinstance(value, bytes):
        payload = b"b:" + value
    elif isinstance(value, (int, np.integer)):
        payload = f"n:{int(value)}/1".encode()
    else:
        numerator, denominator = float(value).as_integer_ratio()
        payload = f"n:{numerator}/{denominator}".encode()
    return hashlib.sha256(salt + payload).digest()


def _keys(values, label, salt):
    ids = validate_ids(values, label, unique=False)
    return ids, {_digest(value, salt) for value in ids.unique()}


def _depth(accounts, stamps):
    # Count history before filtering targets to June; ties never become history.
    instants = stamps.to_numpy(dtype="datetime64[ns]").astype(np.int64)
    return (pd.Series(instants).groupby(accounts.to_numpy(), sort=False).rank(method="min") - 1).to_numpy(np.int64)


def _counts(mask, fraud, accounts, depth):
    selected = fraud[mask]
    depths = depth[mask]
    bounds = ((0, 1), (1, 5), (5, 10), (10, 20), (20, math.inf))
    return {
        "rows": int(mask.sum()), "frauds": int(selected.sum()),
        "accounts": int(accounts[mask].nunique()), "fraud_accounts": int(accounts[mask & fraud].nunique()),
        "depth_at_least": {str(h): int((depths >= h).sum()) for h in (0, 1, 5, 10, 20)},
        "depth_bands": {name: {"rows": int(((depths >= lo) & (depths < hi)).sum()),
                                "frauds": int(selected[(depths >= lo) & (depths < hi)].sum())}
                        for name, (lo, hi) in zip(DEPTH_BANDS, bounds)},
    }


def inspect_frame(frame, salt, *, columns=None, positive_label=1):
    """Return aggregate metadata and ephemeral account/transaction keys, never row-level output."""
    cols = columns or {"id": ID, "account": ACCOUNT, "time": TIME, "label": LABEL}
    missing = sorted(set(cols.values()) - set(frame.columns))
    if missing:
        raise ValueError(f"Missing inventory columns: {missing}")
    nulls = {c: int(frame[c].isna().sum()) for c in cols.values()}
    record = {"rows": len(frame), "nulls": nulls,
              "timestamp_dtype": str(frame[cols["time"]].dtype),
              "duplicate_transaction_ids": int(frame[cols["id"]].duplicated().sum()),
              "duplicate_composite_ids": int(frame[[cols["id"], cols["account"]]].duplicated().sum())}
    if any(nulls.values()):
        record["errors"] = ["Required identity, time or label columns contain nulls"]
        return record, set(), set(), None
    try:
        account_values, account_keys = _keys(frame[cols["account"]], "account IDs", salt)
        id_values, txn_keys = _keys(frame[cols["id"]], "transaction IDs", salt)
        stamps = parse_required_timestamps(frame[cols["time"]], cols["time"])
        # Exactly the training encoder's equality contract: do not turn raw
        # string "1" into numeric 1 when the trainer would not do so.
        labels = frame[cols["label"]]
        if not labels.isin([0, 1]).all() or positive_label not in (0, 1):
            raise ValueError("The inventory requires numeric binary 0/1 labels matching the training encoder; "
                             "string labels require source-contract reconciliation")
        fraud = encode_binary_target(labels, positive_label, cols["label"]).astype(bool)
        depth = _depth(account_values, stamps)
    except ValueError as exc:
        record["errors"] = [str(exc)]
        return record, set(), set(), None
    record.update(account_kind=id_kind(account_values) if len(frame) else None,
                  transaction_id_kind=id_kind(id_values) if len(frame) else None,
                  timestamp_timezone=str(stamps.dt.tz) if stamps.dt.tz is not None else None,
                  min_time=stamps.min().isoformat() if len(frame) else None,
                  max_time=stamps.max().isoformat() if len(frame) else None,
                  all=_counts(np.ones(len(frame), dtype=bool), fraud, account_values, depth))
    # Calendar slices follow the supplied calendar, like V1 temporal_eval; no
    # timezone is invented for naive bank times. Ordering above uses instants.
    month = stamps.dt.strftime("%Y-%m").to_numpy()
    record["months"] = {m: _counts(month == m, fraud, account_values, depth) for m in sorted(set(month))}
    return record, account_keys, txn_keys, (account_values, id_values)


def inventory(train_base, eval_base, train_numbers, eval_numbers, *, filesystem=None,
              benchmark_path=None, columns=None, benchmark_id_col=ID, benchmark_account_col=ACCOUNT,
              positive_label=1, list_only=False):
    """Scan all selected roles in one call. Random salt affects no persisted bytes."""
    bases = {"train": str(train_base).rstrip("/"), "eval": str(eval_base).rstrip("/")}
    lists = {source: listing(base, filesystem) for source, base in bases.items()}
    result = {"schema": SCHEMA, "bases": bases, "listings": lists, "files": [],
              "columns": columns or {"id": ID, "account": ACCOUNT, "time": TIME, "label": LABEL},
              "positive_label": positive_label, "list_only": bool(list_only),
              "identity_policy": "lossless typed IDs; numeric int/float equivalent; string/bytes preserved",
              "calendar_policy": "supplied calendar; strict history orders actual instants",
              "implementation_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    if list_only:
        return result
    if not train_numbers or not eval_numbers:
        raise ValueError("One invocation must scan declared train and eval ranges")
    salt = secrets.token_bytes(32)
    bench_accounts = bench_ids = None
    benchmark = {"provided": benchmark_path is not None}
    if benchmark_path:
        fs = filesystem if is_remote(benchmark_path) else None
        pf = pq.ParquetFile(strip_scheme(str(benchmark_path)), filesystem=fs)
        names = pf.schema_arrow.names
        if benchmark_id_col not in names:
            raise ValueError("Benchmark transaction ID column is absent")
        bcols = [benchmark_id_col] + ([benchmark_account_col] if benchmark_account_col in names else [])
        bench_frame = pf.read(columns=bcols).to_pandas()
        bids, bench_ids = _keys(bench_frame[benchmark_id_col], "benchmark transaction IDs", salt)
        benchmark.update(path=str(benchmark_path), rows=len(bench_frame), transaction_ids=len(bench_ids),
                         transaction_id_kind=id_kind(bids) if len(bids) else None,
                         account_overlap_verified=False)
        if benchmark_account_col in bench_frame:
            baccounts, bench_accounts = _keys(bench_frame[benchmark_account_col], "benchmark account IDs", salt)
            benchmark.update(accounts=len(bench_accounts), account_kind=id_kind(baccounts) if len(baccounts) else None,
                             account_overlap_verified=True)
        else:
            benchmark["qualification"] = "Benchmark account column absent; account overlap is unverified, not zero"
    result["benchmark"] = benchmark
    account_files = defaultdict(list)
    pair_counts = Counter()
    errors = []

    def normal_path(source, number):
        path = f"{bases[source]}/part_{number}.parquet"
        return "s3://" + strip_scheme(path) if is_remote(path) else str(Path(path).expanduser().resolve())

    # Every requested file is resolved against the listings first: a gap fails in seconds, with the whole list, not hours in
    absent = [f"{source}:{number}" for source, numbers in (("train", train_numbers), ("eval", eval_numbers))
              for number in sorted(set(numbers)) if normal_path(source, number) not in {row["path"] for row in lists[source]}]
    if absent:
        raise FileNotFoundError(f"{len(absent)} requested files are absent from the recorded listings: {absent[:40]}"
                                f"{' ...' if len(absent) > 40 else ''}; nothing was read")
    for source, numbers in (("train", train_numbers), ("eval", eval_numbers)):
        listed = {row["path"]: row for row in lists[source]}
        for number in sorted(set(numbers)):
            normal = normal_path(source, number)
            frame = parquet(normal, list(result["columns"].values()), filesystem)
            row, accounts, ids, _ = inspect_frame(frame, salt, columns=result["columns"], positive_label=positive_label)
            key = f"{source}:{number}"
            row.update(file_key=key, source=source, number=int(number), **listed[normal])
            if row.get("errors"):
                errors.append(key)
            for account in accounts:
                for old_key in account_files[account]:
                    pair_counts[tuple(sorted((old_key, key)))] += 1
                account_files[account].append(key)
            if benchmark_path:
                same_id_kind = row.get("transaction_id_kind") == benchmark.get("transaction_id_kind")
                same_account_kind = row.get("account_kind") == benchmark.get("account_kind")
                row["benchmark"] = {
                    "transaction_ids": len(ids & bench_ids) if same_id_kind else None,
                    "accounts": len(accounts & bench_accounts) if bench_accounts is not None and same_account_kind else None,
                    "transaction_id_representation_matches": same_id_kind,
                    "account_representation_matches": same_account_kind if bench_accounts is not None else None,
                }
            result["files"].append(row)
    if benchmark_path and benchmark.get("account_overlap_verified"):
        if any(row["benchmark"]["accounts"] is None for row in result["files"]):
            benchmark["account_overlap_verified"] = False
            benchmark["qualification"] = "Benchmark account representations are not comparable for every inspected file; missing intersections are unverified, not zero"
    n = len(result["files"])
    result["overlap"] = {
        "scope": "one invocation; all inspected files; one ephemeral salt; sparse positive intersections",
        "checked_file_keys": sorted(r["file_key"] for r in result["files"]),
        "pair_count": n * (n - 1) // 2, "complete": not errors,
        "pairs": [{"left": a, "right": b, "accounts": count} for (a, b), count in sorted(pair_counts.items())],
        "accounts_in_multiple_files": sum(len(files) > 1 for files in account_files.values()),
        "invalid_files": errors,
    }
    probe = next((p["accounts"] for p in result["overlap"]["pairs"]
                  if {p["left"], p["right"]} == {"train:8000", "eval:8000"}), 0)
    has_probe = {"train:8000", "eval:8000"} <= set(result["overlap"]["checked_file_keys"])
    result["bucket_probe"] = {"measured": has_probe, "shared_accounts": probe if has_probe else None,
                              "qualification": "One matching number does not prove a global bucket mapping"}
    return result


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--train-base", required=True)
    p.add_argument("--eval-base", required=True)
    p.add_argument("--train-ranges", nargs="+", help="inclusive N or START:END; include every prospective train role")
    p.add_argument("--eval-ranges", nargs="+", help="include DEV_OOT and enough later files for all three June roles")
    p.add_argument("--out", required=True, help="inventory output directory")
    p.add_argument("--list-only", action="store_true", help="list both roots without reading rows")
    p.add_argument("--cred-path")
    p.add_argument("--benchmark-ids")
    p.add_argument("--benchmark-id-col", default=ID)
    p.add_argument("--benchmark-account-col", default=ACCOUNT)
    for name, default in (("id", ID), ("account", ACCOUNT), ("time", TIME), ("label", LABEL)):
        p.add_argument(f"--{name}-col", default=default)
    p.add_argument("--positive-label", type=int, choices=[0, 1], default=1)
    args = p.parse_args(argv)
    if not args.list_only and (not args.train_ranges or not args.eval_ranges):
        p.error("scanning requires both --train-ranges and --eval-ranges in the same invocation")
    fs = thin_read_filesystem(args.cred_path)
    report = inventory(args.train_base, args.eval_base, parse_ranges(args.train_ranges), parse_ranges(args.eval_ranges),
                       filesystem=fs, benchmark_path=args.benchmark_ids,
                       benchmark_id_col=args.benchmark_id_col, benchmark_account_col=args.benchmark_account_col,
                       columns={name: getattr(args, name + "_col") for name in ("id", "account", "time", "label")},
                       positive_label=args.positive_label, list_only=args.list_only)
    out = Path(args.out)
    name = "listings.json" if args.list_only else "inventory.json"
    write_frozen(out / name, json_bytes(report))
    if not args.list_only:  # the pre-selection label reads of the evaluation pool, on the same trail as the scorings (deterministic,
        exposure = {"operation": "data_inventory", "inventory": name, "inventory_sha256": hashlib.sha256(json_bytes(report)).hexdigest(),
                    "train_ranges": args.train_ranges, "eval_ranges": args.eval_ranges, "files": len(report["files"]),
                    "labels_read": "per-file and per-month counts only; no model, no row-level value written",
                    "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}  # so an identical rerun is refused by nothing)
        write_frozen(out / "exposure.json", json_bytes(exposure))
    print(f"INVENTORY={out / name}")
    if not args.list_only and not report["overlap"]["complete"]:
        print("INVENTORY_STATUS=INCOMPLETE; see per-file errors; no split can be frozen")
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
