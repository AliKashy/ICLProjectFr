"""Rows per target-ending window at each history length (governing plan section 8 item 3; step 1). 2026-10-19.

CPU only; reads account and time, plus the label on training files (``--target-col``), never features. For every
row it counts the rows of its target-ending window (YOUR_PACKAGE/v2/target_ending.py: the row, the rows of its second
with an earlier timestamp, and every row of up to H earlier whole seconds of its account in the same file) and
reports, per H, the distribution over all windows and over fraud windows, and the cap the plan's rule gives: the
larger of the all-window p99.9 and the fraud-window p99, rounded up to a multiple of 8 (audit finding 44 of 2026-10-19),
with the share of all and of fraud windows above it.

Usage:
    python -m YOUR_PACKAGE.v2.scripts.measure_window_rows --base <data base> --start 1 --end 10 --history 5 20 \
        --target-col frd_tag --out <new json> [--cred-path <file>] [--account-col ...] [--order-col ...]
"""
import argparse
import json
import math
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))

from fraud.data.s3_utils import build_file_list, strip_scheme  # noqa: E402
from YOUR_PACKAGE.v2.storage import thin_read_filesystem  # noqa: E402

PERCENTILES = (50, 90, 99, 99.9)


def window_sizes(accounts, order_key, history_len):
    """Rows in each row's target-ending window (no cap), in the input row order.

    One vectorised pass over a file: rows are sorted by account and timestamp; a global running index of whole
    seconds lets one searchsorted find each window's first row, clamped at the account's first row."""
    accounts = pd.factorize(np.asarray(accounts), sort=False)[0]
    order_key = np.asarray(order_key, dtype=np.int64)
    n = len(order_key)
    if not n:
        return np.zeros(0, np.int64)
    order = np.lexsort((order_key, accounts))
    acct, key = accounts[order], order_key[order]
    sec = np.floor_divide(key, 10**9)
    new_acct = np.r_[True, acct[1:] != acct[:-1]]
    second_index = np.cumsum(new_acct | np.r_[True, sec[1:] != sec[:-1]]) - 1
    group_start = np.maximum.accumulate(np.where(new_acct | np.r_[True, key[1:] != key[:-1]], np.arange(n), 0))
    acct_start = np.maximum.accumulate(np.where(new_acct, np.arange(n), 0))
    lo = np.maximum(np.searchsorted(second_index, second_index - history_len, side="left"), acct_start)
    sizes = np.empty(n, np.int64)
    sizes[order] = group_start - lo + 1
    return sizes


def distribution(sizes):
    return {"rows": int(len(sizes)), "mean": float(sizes.mean()),
            **{f"p{q}": float(np.percentile(sizes, q)) for q in PERCENTILES}, "max": int(sizes.max())}


def summarise(sizes, fraud=None):
    """Distribution, the cap rule and the shares above the cap; ``fraud`` marks fraud windows (optional)."""
    out = {"all": distribution(sizes)}
    level = out["all"]["p99.9"]
    if fraud is not None and fraud.any():
        out["fraud"] = distribution(sizes[fraud])
        level = max(level, out["fraud"]["p99"])
    cap = int(math.ceil(level / 8) * 8)
    out["cap_rule"] = "max(all p99.9, fraud p99), up to a multiple of 8" if "fraud" in out else "all p99.9, up to 8"
    out["cap"] = cap
    out["share_all_above_cap"] = float(np.mean(sizes > cap))
    if "fraud" in out:
        out["share_fraud_above_cap"] = float(np.mean(sizes[fraud] > cap))
    return out


def chunk_batch_plan(mean_chunk_rows, max_chunk_rows, cap, history_len, targets=4096, limit=65535):
    """Step 3 settings for a chunk model (plan section 2): about ``targets`` targets per update.

    Accumulation is the smallest A >= 1 for which B = round(targets / (A x mean rows per chunk)) chunks keep
    B x widest chunk under the stage 1 limit; the eval batch is the most windows of the cap's width under it."""
    for accumulate in range(1, 1025):
        batch = max(1, round(targets / (accumulate * mean_chunk_rows)))
        if batch * max_chunk_rows < limit:
            break
    else:
        raise ValueError("no accumulation keeps one chunk batch under the stage 1 limit")
    eval_batch = (limit - 1) // max(int(cap), int(history_len) + 1)
    return {"training.batch_size": int(batch), "training.accumulate_grad_batches": int(accumulate),
            "training.eval_batch_size": int(eval_batch), "sequence.max_chunk_rows": int(max_chunk_rows),
            "sequence.max_window_rows": int(cap),
            "targets_per_update": float(batch * accumulate * mean_chunk_rows)}


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--start", type=int, required=True)
    parser.add_argument("--end", type=int, required=True)
    parser.add_argument("--history", type=int, nargs="+", default=[5, 20])
    parser.add_argument("--out", required=True)
    parser.add_argument("--cred-path", default=None)
    parser.add_argument("--account-col", default="Nmap_account_reference_xid")
    parser.add_argument("--order-col", default="transaction_dttm")
    parser.add_argument("--target-col", default=None, help="label column (training files only) for fraud windows")
    parser.add_argument("--positive-label", default=1)
    args = parser.parse_args(argv)
    if os.path.exists(args.out):
        raise FileExistsError(f"{args.out} exists")
    fs = thin_read_filesystem(args.cred_path)
    sizes, fraud = {h: [] for h in args.history}, []
    files = build_file_list(args.base, args.start, args.end)
    columns = [args.account_col, args.order_col] + ([args.target_col] if args.target_col else [])
    for path in files:
        frame = pq.ParquetDataset(strip_scheme(path) if fs is not None else path, filesystem=fs).read(
            columns=columns).to_pandas()
        if args.target_col:
            labels = pd.to_numeric(frame[args.target_col], errors="coerce")
            fraud.append((labels == float(args.positive_label)).to_numpy())  # 1, 1.0 and "1" alike
        stamps = pd.to_datetime(frame[args.order_col], utc=True).dt.tz_localize(None)
        key = stamps.to_numpy(dtype="datetime64[ns]").astype("int64")  # explicit ns: a [us] column stays [us]
        for h in args.history:
            sizes[h].append(window_sizes(frame[args.account_col].to_numpy(), key, h))
    report = {"base": args.base, "files": [args.start, args.end], "n_files": len(files),
              "history": {str(h): summarise(np.concatenate(v), np.concatenate(fraud) if fraud else None)
                          for h, v in sizes.items()}}
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
