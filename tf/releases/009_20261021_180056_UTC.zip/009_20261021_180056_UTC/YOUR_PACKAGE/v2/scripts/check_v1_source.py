"""Do this package's V1 model-path files match what V1's runs used? (audit finding 34 of 2026-10-19; step 1.) 2026-10-19.

V2's default B reuses V1's builder, model and factory, and "default B through train_v2 equals V1" is tested on
this package's copies. The V1 run manifests record what those runs executed, so they are the reference (package 005
produced them; comparing with the package as well would add nothing). That carries over to R05, R15 and R20 only if those copies are byte-identical to the
files V1's runs recorded. For each V1 run manifest given, this compares the SHA-256 of every model-path file
here with the manifest's ``source_after_train`` and ``source_after_score`` entries. Any difference is listed
and must be diffed before the step 0 build is trusted. A hand-retrained run's manifest (B-H15, B-H20) may belong
to the stopped run; the report says which manifest each comparison used.

Usage:
    python -m YOUR_PACKAGE.v2.scripts.check_v1_source --manifests <attempt>/run_manifest.json ... --out <new json>
"""
import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]

# Every fraud/ and YOUR_PACKAGE/ file that V1's train_sequential.py and score_sequential.py import, directly or through
# a package __init__ (their import closure; test_check_v1_source.py recomputes it and checks this list covers it).
MODEL_PATH_FILES = [
    "fraud/__init__.py", "fraud/callbacks.py", "fraud/data/__init__.py", "fraud/data/datetime_features.py",
    "fraud/data/feature_list.py", "fraud/data/parquet_loader.py", "fraud/data/preprocessing.py",
    "fraud/data/s3_utils.py", "fraud/data/sequence_builder.py", "fraud/log_utils.py",
    "YOUR_PACKAGE/base/__init__.py", "YOUR_PACKAGE/base/data/__init__.py", "YOUR_PACKAGE/base/data/contracts.py",
    "YOUR_PACKAGE/base/data/input_contracts.py",
    "YOUR_PACKAGE/phase4b/__init__.py", "YOUR_PACKAGE/phase4b/callbacks.py", "YOUR_PACKAGE/phase4b/factory.py",
    "YOUR_PACKAGE/phase4b/numerical_embeddings.py", "YOUR_PACKAGE/phase4b/optim.py", "YOUR_PACKAGE/phase4b/scripts/__init__.py",
    "YOUR_PACKAGE/phase4b/scripts/score_sequential.py", "YOUR_PACKAGE/phase4b/scripts/train_sequential.py",
    "YOUR_PACKAGE/phase4b/sequence_builder.py", "YOUR_PACKAGE/phase4b/sequential_hier.py", "YOUR_PACKAGE/phase4b/tokenizer.py",
]


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def compare(manifest, root=ROOT):
    here = {rel: sha256(root / rel) if (root / rel).is_file() else None for rel in MODEL_PATH_FILES}
    out = {}
    for stage in ("source_after_train", "source_after_score"):
        recorded = (manifest.get(stage) or {}).get("files", {})
        out[stage] = {
            "differ": {rel: {"v1": recorded[rel], "here": here[rel]}
                       for rel in MODEL_PATH_FILES if rel in recorded and recorded[rel] != here[rel]},
            "not_recorded": [rel for rel in MODEL_PATH_FILES if rel not in recorded],
        }
    # Fail closed: the training-time record must exist and list every file; a scoring-time record is compared
    # when present (a hand-retrained run's manifest may stop at training).
    trained = (manifest.get("source_after_train") or {}).get("files")
    out["matches"] = bool(trained) and not out["source_after_train"]["not_recorded"] and not any(
        out[s]["differ"] for s in ("source_after_train", "source_after_score"))
    return out


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifests", nargs="+", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args(argv)
    if os.path.exists(args.out):
        raise FileExistsError(f"{args.out} exists")
    report = {}
    for path in args.manifests:
        with open(path, encoding="utf-8") as f:
            report[path] = compare(json.load(f))
    report["all_match"] = all(r["matches"] for r in report.values() if isinstance(r, dict))
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    print(json.dumps({p: r["matches"] for p, r in report.items() if isinstance(r, dict)}, indent=2))
    if not report["all_match"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
