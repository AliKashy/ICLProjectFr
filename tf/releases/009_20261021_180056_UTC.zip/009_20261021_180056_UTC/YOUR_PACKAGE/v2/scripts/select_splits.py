"""Freeze V2 L2 populations from one complete, count-only inventory.

No raw data is read and no model score participates. Fixed train/validation/
continuity ranges follow the governing plan. June blocks are selected greedily
and reproducibly from contiguous inspected eval files after 8010, preferring
the least measured benchmark-ID overlap, then fewest files, then earliest start.
Missing coverage or account overlap stops selection rather than weakening it.
"""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import sys

import yaml

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from YOUR_PACKAGE.v2.scripts.data_inventory import SCHEMA, json_bytes, write_frozen  # noqa: E402

EXPECTED_MONTHS = {
    "train": ["2024-10", "2024-11", "2024-12", "2025-01", "2025-02", "2025-03", "2025-04", "2025-05"],
    "eval": ["2025-05", "2025-06"],
}
MIN_FRAUDS = {"SELECT": 2000, "DS_SELECT": 2000, "FINAL": 3000}
EXPOSURES = ("epoch_selection", "design_selection", "continuity", "downstream_training", "downstream_selection",
             "artifact_fit", "pca_fit", "final_evaluation", "benchmark_scoring")


def _role(files, month=None):
    counts = [row["months"].get(month, {"rows": 0, "frauds": 0, "accounts": 0, "fraud_accounts": 0})
              if month else row["all"] for row in files]
    result = {"source": files[0]["source"], "file_start": files[0]["number"], "file_end": files[-1]["number"],
            "files": [row["file_key"] for row in files], "paths": [row["path"] for row in files],
            "target_month": month, "history": "all rows in each file before target-month filtering",
            "counts": {key: sum(row[key] for row in counts) for key in ("rows", "frauds", "accounts", "fraud_accounts")}}
    if all("depth_at_least" in row for row in counts):
        result["counts"]["depth_at_least"] = {str(h): sum(row["depth_at_least"][str(h)] for row in counts)
                                               for h in (0, 1, 5, 10, 20)}
    if all("depth_bands" in row for row in counts):
        bands = sorted({band for row in counts for band in row["depth_bands"]})
        result["counts"]["depth_bands"] = {
            band: {key: sum(row["depth_bands"].get(band, {}).get(key, 0) for row in counts) for key in ("rows", "frauds")}
            for band in bands}
    return result


def _checked_inventory(inv):
    if inv.get("schema") != SCHEMA or inv.get("list_only"):
        raise ValueError("A complete tf-v2-inventory-1 scan is required, not listings or concatenated inventories")
    if set(inv.get("listings", {})) != {"train", "eval"}:
        raise ValueError("Both folder listings must be recorded")
    records = inv.get("files", [])
    by_key = {row["file_key"]: row for row in records}
    overlap = inv.get("overlap", {})
    if len(by_key) != len(records) or not records:
        raise ValueError("Inventory file keys are missing or duplicated")
    if (not overlap.get("complete") or overlap.get("invalid_files")
            or set(overlap.get("checked_file_keys", [])) != set(by_key)
            or overlap.get("pair_count") != len(records) * (len(records) - 1) // 2):
        raise ValueError("Account intersections must be complete for all files in one invocation")
    for source in ("train", "eval"):
        if not inv["listings"][source]:
            raise ValueError(f"The {source} folder listing is empty")
        observed = sorted({m for row in records if row["source"] == source for m in row.get("months", {})})
        if observed != EXPECTED_MONTHS[source]:
            raise ValueError(f"{source} month coverage {observed} differs from {EXPECTED_MONTHS[source]}; "
                             "reconcile the data coverage before automatic selection")
    kinds = {r.get("account_kind") for r in records if r.get("rows")}
    if len(kinds) != 1 or None in kinds:
        raise ValueError("Compared account-ID representations differ; reconcile before treating intersections as complete")
    pair_seen = set()
    for pair in overlap.get("pairs", []):
        a, b = pair["left"], pair["right"]
        key = tuple(sorted((a, b)))
        if a == b or a not in by_key or b not in by_key or key in pair_seen or pair["accounts"] <= 0:
            raise ValueError("Malformed sparse account-overlap evidence")
        pair_seen.add(key)
    return by_key


def _required(by_key, source, start, end):
    keys = [f"{source}:{n}" for n in range(start, end + 1)]
    missing = [key for key in keys if key not in by_key]
    if missing:
        raise ValueError(f"Required population files were not inspected: {', '.join(missing)}")
    return [by_key[key] for key in keys]


def _block(candidates, threshold, role, benchmark_provided):
    """For each start consider its shortest sufficient contiguous block.

    Longer blocks from that same start cannot improve either benchmark overlap
    count or file count. No fraud-rate/score optimization enters the ranking.
    """
    best = None
    for i, row in enumerate(candidates):
        frauds = overlap = 0
        block = []
        for current in candidates[i:]:
            if block and current["number"] != block[-1]["number"] + 1:
                break
            block.append(current)
            frauds += current["months"].get("2025-06", {}).get("frauds", 0)
            if benchmark_provided:
                count = current.get("benchmark", {}).get("transaction_ids")
                if count is None:
                    raise ValueError("Benchmark transaction overlap is unverified for a candidate file")
                overlap += count
            if frauds >= threshold:
                key = (overlap, len(block), row["number"])
                if best is None or key < best[0]:
                    best = (key, block)
                break
    if best is None:
        raise ValueError(f"No remaining contiguous {role} block reaches {threshold} measured June frauds; "
                         "enlarge the inventory before any model run")
    return best[1]


def _benchmark_counts(files, benchmark):
    if not benchmark.get("provided"):
        return {"status": "unverified", "reason": "No benchmark IDs supplied", "transaction_ids": None, "accounts": None}
    txns = [row.get("benchmark", {}).get("transaction_ids") for row in files]
    accounts = [row.get("benchmark", {}).get("accounts") for row in files]
    return {"status": "verified" if all(v is not None for v in accounts + txns) else "qualified",
            "transaction_ids": sum(txns) if all(v is not None for v in txns) else None,
            "accounts": sum(accounts) if all(v is not None for v in accounts) else None,
            "qualification": "Transaction-ID matches are not one-to-one row matches; account counts require a benchmark account column"}


def select_splits(inv, ds_train_start, ds_train_end, *, thresholds=None, inventory_sha256=None):
    """Return split config, role-exposure table and aggregate selection report.

    Thresholds may be raised before results; the CLI cannot lower 2000/2000/3000.
    Tests use real default thresholds on small count-only synthetic inventories.
    """
    by_key = _checked_inventory(inv)
    if not 5001 <= ds_train_start <= ds_train_end <= 7999:
        raise ValueError("DS_TRAIN must be an explicitly sized contiguous block inside 5001-7999")
    thresholds = dict(MIN_FRAUDS if thresholds is None else thresholds)
    if set(thresholds) != set(MIN_FRAUDS) or any(type(thresholds[k]) is not int or thresholds[k] < v
                                               for k, v in MIN_FRAUDS.items()):
        raise ValueError("June fraud thresholds may be raised but not lowered below 2000/2000/3000")
    role_files = {
        "ENC_TRAIN_10": _required(by_key, "train", 1, 10),
        "ENC_TRAIN_100": _required(by_key, "train", 1, 100),
        "EPOCH_VAL": _required(by_key, "train", 4950, 4954),
        "DS_TRAIN": _required(by_key, "train", ds_train_start, ds_train_end),
        "DEV_OOT": _required(by_key, "eval", 8000, 8010),
    }
    candidates = sorted((r for r in by_key.values() if r["source"] == "eval" and r["number"] > 8010),
                        key=lambda r: r["number"])
    bench = inv.get("benchmark", {})
    for role in ("SELECT", "DS_SELECT", "FINAL"):
        block = _block(candidates, thresholds[role], role, bench.get("provided", False))
        role_files[role] = block
        used = {r["file_key"] for r in block}
        candidates = [r for r in candidates if r["file_key"] not in used]
    selected = {r["file_key"] for rows in role_files.values() for r in rows}
    for key in sorted(selected):
        row = by_key[key]
        if row.get("errors") or any(row["nulls"].values()) or row.get("rows", 0) == 0:
            raise ValueError(f"Selected file {key} contains invalid/missing required data or is empty")
        if row.get("duplicate_composite_ids", 0):
            raise ValueError(f"Selected file {key} has duplicate composite transaction identities")
    collisions = [p for p in inv["overlap"]["pairs"] if p["left"] in selected and p["right"] in selected]
    if collisions:
        first = collisions[0]
        raise ValueError(f"File-contained-account gate failed: {first['left']} and {first['right']} share "
                         f"{first['accounts']} accounts; revise history construction before training")
    # ENC10 intentionally reuses the same files as ENC100; this is not an
    # account occurring in two different files. All other population pairs must
    # be distinct. No numerical bucket assumption replaces the account check.
    probe = inv.get("bucket_probe", {})
    if probe.get("measured") and probe.get("shared_accounts", 0) > 0:
        train_nums = {by_key[k]["number"] for k in selected if by_key[k]["source"] == "train"}
        eval_nums = {by_key[k]["number"] for k in selected if by_key[k]["source"] == "eval"}
        if train_nums & eval_nums:
            raise ValueError("The measured 8000 probe shares accounts; do not reuse a bucket number across folders")
    populations = {}
    for role, files in role_files.items():
        month = "2025-06" if role in ("SELECT", "DS_SELECT", "FINAL", "DEV_OOT") else None
        populations[role] = _role(files, month)
        populations[role]["base"] = inv["bases"][files[0]["source"]]
        if role == "DEV_OOT":
            populations[role]["full_view_counts"] = _role(files)["counts"]
        populations[role]["benchmark_overlap"] = _benchmark_counts(files, bench)
    populations["BENCH"] = {"path": bench.get("path"), "target_month": "2025-06",
                             "status": "provided" if bench.get("provided") else "not_supplied",
                             "rows": bench.get("rows"), "account_overlap_verified": bench.get("account_overlap_verified", False),
                             "selection_overlaps_to_exclude": ["SELECT", "DS_SELECT"],
                             "qualification": "Inventory counts are not a frozen benchmark comparison or row-level cohort export"}
    overlap_rows = []
    for left, right in itertools.combinations(role_files, 2):
        shared_files = set(populations[left]["files"]) & set(populations[right]["files"])
        shared_accounts = sum(by_key[key]["all"]["accounts"] for key in shared_files)
        intentional = {left, right} == {"ENC_TRAIN_10", "ENC_TRAIN_100"}
        if shared_files and not intentional:
            raise ValueError(f"Unexpected shared population files: {left}, {right}")
        overlap_rows.append({"left": left, "right": right, "accounts": shared_accounts,
                             "intentional_nesting": intentional, "distinct_file_account_overlap": 0})
    for role in role_files:
        overlap_rows.append({"left": role, "right": "BENCH", **populations[role]["benchmark_overlap"]})
    warnings = []
    for source in ("train", "eval"):
        month_counts = {}
        # Every inspected file once, not ENC10 counted a second time in ENC100.
        for row in by_key.values():
            if row["source"] != source:
                continue
            for month, counts in row["months"].items():
                total = month_counts.setdefault(month, [0, 0])
                total[0] += counts["rows"]
                total[1] += counts["frauds"]
        months = sorted(month_counts)
        previous, latest = (month_counts[m] for m in months[-2:])
        previous_rate = previous[1] / previous[0]
        latest_rate = latest[1] / latest[0]
        if previous_rate > 0 and latest_rate < 0.5 * previous_rate:
            warnings.append({"source": source, "kind": "possible_label_immaturity", "previous_month": months[-2],
                             "latest_month": months[-1], "previous_fraud_rate": previous_rate, "latest_fraud_rate": latest_rate,
                             "reason": "latest observed month fraud rate below half the previous month; descriptive flag, ask data owner"})
    if not bench.get("provided") or not bench.get("account_overlap_verified"):
        warnings.append({"kind": "benchmark_overlap_unverified",
                         "reason": "Benchmark account overlap remains unverified; do not interpret missing counts as zero"})
    exposures = {}
    role_allowed = {
        "ENC_TRAIN_10": ["artifact_fit"], "ENC_TRAIN_100": [], "EPOCH_VAL": ["epoch_selection"],
        "SELECT": ["design_selection", "continuity"], "DS_TRAIN": ["downstream_training", "pca_fit"],
        "DS_SELECT": ["downstream_selection"], "DEV_OOT": [], "FINAL": ["final_evaluation"],
        "BENCH": ["benchmark_scoring"],
    }
    for role, uses in role_allowed.items():
        exposures[role] = {purpose: purpose in uses for purpose in EXPOSURES}
    exposure_table = {"schema": "tf-v2-population-roles-1", "populations": exposures,
                      "artifact_fit_scope": "frozen V1 fit files 1-5 only; ENC_TRAIN_100 never refits artifacts",
                      "run_exposure_rule": "each attempt writes its own exposure.json; collect after the stage, no parallel shared writes",
                      "final_rule": "FINAL only after model/configuration freeze; DEV_OOT descriptive only",
                      "benchmark_rule": "one label-free plumbing (alignment) check after the freeze with the final encoder's scores; the comparison once, after it"}
    split = {"schema": "tf-v2-splits-1", "inventory_sha256": inventory_sha256,
             "selector_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             "selection_policy": "SELECT then DS_SELECT then FINAL; contiguous; least benchmark-ID overlap, fewest files, earliest start",
             "june_fraud_thresholds": thresholds, "populations": populations,
             "gates": {"both_listings": "PASS", "expected_month_coverage": "PASS", "file_contained_accounts": "PASS",
                       "june_fraud_thresholds": "PASS", "benchmark_account_overlap": "MEASURED" if bench.get("account_overlap_verified") else "UNVERIFIED"}}
    report = {"schema": "tf-v2-selection-report-1", "inventory_sha256": inventory_sha256,
              "selected_distinct_files": len(selected), "population_pair_overlaps": overlap_rows,
              "bucket_probe": probe, "warnings": warnings,
              "qualification": "Disjointness is measured on inspected accounts; no current pod run or training result is inferred"}
    return split, exposure_table, report


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--inventory", required=True, help="inventory.json or its output directory")
    p.add_argument("--ds-train-start", required=True, type=int)
    p.add_argument("--ds-train-end", required=True, type=int)
    p.add_argument("--select-min-frauds", type=int, default=2000)
    p.add_argument("--ds-select-min-frauds", type=int, default=2000)
    p.add_argument("--final-min-frauds", type=int, default=3000)
    p.add_argument("--out", required=True, help="new split_v2.yaml path")
    args = p.parse_args(argv)
    path = Path(args.inventory)
    if path.is_dir():
        path = path / "inventory.json"
    blob = path.read_bytes()
    inventory_hash = hashlib.sha256(blob).hexdigest()
    split, roles, report = select_splits(json.loads(blob), args.ds_train_start, args.ds_train_end,
                                         thresholds={"SELECT": args.select_min_frauds, "DS_SELECT": args.ds_select_min_frauds,
                                                     "FINAL": args.final_min_frauds}, inventory_sha256=inventory_hash)
    out = Path(args.out)
    split_blob = yaml.safe_dump(split, sort_keys=True, allow_unicode=True).encode()
    files = {
        out: split_blob,
        out.with_suffix(out.suffix + ".sha256"): (hashlib.sha256(split_blob).hexdigest() + "  " + out.name + "\n").encode(),
        out.parent / "population_roles_v2.yaml": yaml.safe_dump(roles, sort_keys=True).encode(),
        out.parent / "selection_report.json": json_bytes(report),
    }
    # Detect an incompatible frozen output before writing any companion file.
    for target, contents in files.items():
        if target.exists() and target.read_bytes() != contents:
            raise FileExistsError(f"{target} exists with different contents; use a new output directory")
    for target, contents in files.items():
        write_frozen(target, contents)
    print(f"SPLIT={out}")
    print(f"SPLIT_SHA256={hashlib.sha256(split_blob).hexdigest()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
