"""Facts about checkpoints, for the DECISIONS pins and the no-month check, counts and hashes only (end-to-end
review 2026-10-20, EMB-19, EMB-21). 2026-10-20.

For every checkpoint given: its SHA-256 and size; hyper_parameters history_len and embed_dim; whether a
sequence_contract is stored and, if so, the input columns (with "month" flagged), the artifacts digest and the
history rule; validation_policy (chunk models); the epoch and global step; and, beside each, the SHA-256 of a
resolved config when one is given as CHECKPOINT=CONFIG. With --config and --cred-path the artifacts digest is
recomputed from the artifact folder the config names and compared with the checkpoint's. No data is read.

    $PY -m YOUR_PACKAGE.v2.scripts.checkpoint_facts --out runs/v2/step2/pins.json \\
        <B-H05 run folder>/best.ckpt=<B-H05 run folder>/resolved_train.yaml ...
    $PY -m YOUR_PACKAGE.v2.scripts.checkpoint_facts --out runs/v2/B05/checkpoint_facts.json --config runs/v2/B05/resolved_train_v2.yaml \\
        --cred-path $CRED runs/v2/B05/best.ckpt
"""
import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from YOUR_PACKAGE.v2.benchmark_v2 import digest  # noqa: E402
from YOUR_PACKAGE.v2.scripts.make_v2_contracts import artifact_payload_sha256, load_checkpoint, write_new_json  # noqa: E402


def facts(checkpoint, config=None, cred_path=None):
    ckpt = load_checkpoint(checkpoint)
    hp = ckpt.get("hyper_parameters") or {}
    contract = ckpt.get("sequence_contract") or {}
    inputs = contract.get("input_contract") or {}
    out = {"checkpoint": os.path.abspath(checkpoint), "sha256": digest(checkpoint), "size_bytes": os.path.getsize(checkpoint),
           "epoch": ckpt.get("epoch"), "global_step": ckpt.get("global_step"),
           "hyper_parameters": {k: hp.get(k) for k in ("history_len", "embed_dim", "input_embed_dim", "num_heads", "num_seq_blocks")},
           "sequence_contract_present": bool(contract),
           "input_contract": {"continuous_columns": inputs.get("continuous_columns"), "categorical_columns": inputs.get("categorical_columns"),
                              "month_present": "month" in (inputs.get("categorical_columns") or []),
                              "artifacts_sha256": inputs.get("artifacts_sha256"), "history_time_order": inputs.get("history_time_order"),
                              "datetime_fields": (inputs.get("datetime") or {}).get("fields")},
           "all_position_time_policy": contract.get("all_position_time_policy"),
           "validation_policy": ckpt.get("validation_policy"),
           "top_level_keys": sorted(k for k in ckpt.keys() if k != "state_dict" and not k.startswith("optimizer"))}
    if config:
        out["config"] = {"path": os.path.abspath(config), "sha256": digest(config)}
        try:
            from omegaconf import OmegaConf
            from fraud.data.feature_list import load_feature_list
            from fraud.data.preprocessing import PreprocessingArtifacts
            from YOUR_PACKAGE.v2.storage import thin_read_filesystem
            cfg = OmegaConf.load(config)
            fs = thin_read_filesystem(cred_path)
            features = load_feature_list(cfg.predictors.csv_path, version=cfg.predictors.version, filesystem=fs)
            artifacts = PreprocessingArtifacts.load(f"{str(cfg.artifacts.base).rstrip('/')}/{cfg.artifacts.version}", filesystem=fs)
            recomputed = artifact_payload_sha256(artifacts, list(features.all_features))
            out["config"].update(artifacts_version=cfg.artifacts.version, predictors_csv=str(cfg.predictors.csv_path),
                                 predictors_sha256=digest(str(cfg.predictors.csv_path)) if os.path.isfile(str(cfg.predictors.csv_path)) else None,
                                 artifacts_sha256_recomputed=recomputed,
                                 artifacts_sha256_matches_checkpoint=recomputed == inputs.get("artifacts_sha256"),
                                 month_in_datetime_fields="month" in list(cfg.datetime.fields))
        except Exception as exc:  # noqa: BLE001 - recorded, not raised: the pins must still be written
            out["config"]["artifacts_check_error"] = repr(exc)
    return out


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("checkpoints", nargs="+", help="CHECKPOINT or CHECKPOINT=RESOLVED_CONFIG")
    p.add_argument("--config", default=None, help="one resolved config for every checkpoint (recomputes the artifacts digest)")
    p.add_argument("--cred-path", default=None)
    p.add_argument("--out", required=True)
    a = p.parse_args(argv)
    report = {}
    for item in a.checkpoints:
        checkpoint, _, config = item.partition("=")
        report[checkpoint] = facts(checkpoint, config or a.config, a.cred_path)
    write_new_json(a.out, report)
    for checkpoint, rec in report.items():
        print(f"{checkpoint}: sha256 {rec['sha256'][:16]} history_len {rec['hyper_parameters'].get('history_len')} "
              f"month_present {rec['input_contract']['month_present']} policy {rec['validation_policy']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
