"""L4 engineering check on real data: does V2's export path give V1's scores for the same checkpoint on the same
rows? (lean plan L4.1 check 3, PLAN v6 section 9; end-to-end review 2026-10-20, EMB-09.) 2026-10-20.

Joins an export_v2 folder's embeddings.parquet (score per row) with a V1 prediction parquet on (transaction id,
account id), through the same lossless id canonicalisation the consumers use, and writes counts only: matched
rows, unmatched on each side, and the max, p99 and mean of |score_v2 - score_v1|. Two export folders can also be
compared with each other (the same checkpoint at two eval batch sizes, EMB-05): the same statistics on the vectors.

    $PY -m YOUR_PACKAGE.v2.scripts.l4_check --export runs/v2/step2/l4_export_8000 --v1-predictions <B-H15 prediction parquet> \\
        --out runs/v2/step2/l4_check.json [--cred-path $CRED] [--v1-score-col score]
    $PY -m YOUR_PACKAGE.v2.scripts.l4_check --export runs/v2/step2/l4_export_8000 --other-export runs/v2/step2/l4_export_8000_b \\
        --out runs/v2/step2/l4_batch_check.json
"""
import argparse
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from YOUR_PACKAGE.v2.benchmark_v2 import canonical_ids, read_json, read_table  # noqa: E402
from YOUR_PACKAGE.v2.scripts.make_v2_contracts import write_new_json  # noqa: E402

ID, ACCOUNT = "fi_transaction_id", "Nmap_account_reference_xid"


def _keyed(frame, name, key=ID, account=ACCOUNT):
    frame = frame.copy()
    frame["_id"] = canonical_ids(frame[key], f"{name} {key}")[0].astype(str)
    frame["_acct"] = canonical_ids(frame[account], f"{name} {account}")[0].astype(str)
    if frame.duplicated(["_id", "_acct"]).any():
        raise ValueError(f"{name}: duplicate (id, account) rows")
    return frame


def _stats(diff):
    diff = np.abs(np.asarray(diff, dtype="float64"))
    return {"rows": int(diff.size), "max": float(diff.max()) if diff.size else None,
            "p99": float(np.percentile(diff, 99)) if diff.size else None, "mean": float(diff.mean()) if diff.size else None,
            "within_1e-4": int((diff <= 1e-4).sum()), "within_1e-6": int((diff <= 1e-6).sum())}


def compare_scores(export, v1_predictions, fs=None, v1_score_col="score", key=ID, account=ACCOUNT):
    folder = str(export).rstrip("/")
    manifest = read_json(folder + "/manifest.json", fs)
    left = _keyed(read_table(folder + "/embeddings.parquet", fs, columns=[key, account, "score"]), "export", key, account)
    right = _keyed(read_table(v1_predictions, fs, columns=[key, account, v1_score_col]), "v1", key, account)
    right = right.rename(columns={v1_score_col: "_v1_score"})  # V1 also calls its column "score"
    joined = left.merge(right[["_id", "_acct", "_v1_score"]], on=["_id", "_acct"], how="outer", indicator=True)
    both = joined["_merge"] == "both"
    diff = (joined.loc[both, "score"] - joined.loc[both, "_v1_score"]).to_numpy()
    return {"export": folder, "export_checkpoint_sha256": manifest.get("checkpoint_sha256"), "export_files": manifest.get("files"),
            "v1_predictions": str(v1_predictions), "export_rows": int(len(left)), "v1_rows": int(len(right)),
            "matched": int(both.sum()), "export_only": int((joined["_merge"] == "left_only").sum()),
            "v1_only": int((joined["_merge"] == "right_only").sum()), "abs_score_difference": _stats(diff)}


def compare_exports(export, other, fs=None, key=ID, account=ACCOUNT):
    a, b = (read_json(str(f).rstrip("/") + "/manifest.json", fs) for f in (export, other))
    left = _keyed(read_table(str(export).rstrip("/") + "/embeddings.parquet", fs), "export", key, account)
    right = _keyed(read_table(str(other).rstrip("/") + "/embeddings.parquet", fs), "other", key, account)
    cols = sorted(c for c in left.columns if c.startswith("e_"))
    joined = left.merge(right[["_id", "_acct", "score", *cols]], on=["_id", "_acct"], suffixes=("", "_other"), how="outer", indicator=True)
    both = joined["_merge"] == "both"
    vec = (joined.loc[both, cols].to_numpy(dtype="float64") - joined.loc[both, [c + "_other" for c in cols]].to_numpy(dtype="float64")).ravel()
    return {"export": str(export), "other": str(other), "same_checkpoint": a.get("checkpoint_sha256") == b.get("checkpoint_sha256"),
            "eval_batch_sizes": [a.get("eval_batch_size"), b.get("eval_batch_size")], "devices": [a.get("device"), b.get("device")],
            "matched": int(both.sum()), "export_only": int((joined["_merge"] == "left_only").sum()),
            "other_only": int((joined["_merge"] == "right_only").sum()),
            "abs_score_difference": _stats((joined.loc[both, "score"] - joined.loc[both, "score_other"]).to_numpy()),
            "abs_vector_difference": _stats(vec), "embedding_width": len(cols)}


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--export", required=True)
    p.add_argument("--v1-predictions", default=None)
    p.add_argument("--v1-score-col", default="score")
    p.add_argument("--other-export", default=None)
    p.add_argument("--cred-path", default=None)
    p.add_argument("--out", required=True)
    a = p.parse_args(argv)
    if bool(a.v1_predictions) == bool(a.other_export):
        p.error("give exactly one of --v1-predictions and --other-export")
    fs = None
    if a.cred_path:
        from YOUR_PACKAGE.v2.storage import thin_read_filesystem
        fs = thin_read_filesystem(a.cred_path)
    report = compare_scores(a.export, a.v1_predictions, fs, a.v1_score_col) if a.v1_predictions else compare_exports(a.export, a.other_export, fs)
    write_new_json(a.out, report)
    print(report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
