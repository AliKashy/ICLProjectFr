"""V2 scorer (governing plan section 8 item 3; step 0 module 4). 2026-10-19.

Scores one checkpoint on one file range under the policy it was validated with, and writes one prediction per
row in the format ``paired_report.map_run`` reads (the id columns, the target and ``score``), plus
``window_rows``, the real rows in the row's window, for the rows-per-window and cap reports.

- Default B (single target) uses V1's builder and selection, exactly as V1's ``score_sequential.py``. Its
  checkpoint must not carry a V2 validation policy.
- A chunk model (all-position B) is scored on target-ending windows (YOUR_PACKAGE/v2/target_ending.py), capped as its
  checkpoint records. It needs ``validation_policy`` = target_ending_v1 in the checkpoint: a V1 chunk checkpoint,
  validated on chunks, is refused, so no model is rescored under a policy it was not validated with.
- The checkpoint's SHA-256 is read before and after scoring; the output path must not exist.

Usage:
    python -m YOUR_PACKAGE.v2.scripts.score_v2 --config <resolved yaml> --checkpoint <ckpt> --out <predictions.parquet>
        [--metrics <receipt.json>] [dotlist overrides, e.g. eval.base=... eval.file_start=... eval.file_end=...]
"""
import argparse
from contextlib import contextmanager
import json
import os
import sys
import uuid
from pathlib import Path

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import torch
from omegaconf import OmegaConf
from sklearn.metrics import average_precision_score, roc_auc_score
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))

from fraud.data.datetime_features import DatetimeConfig  # noqa: E402
from fraud.data.feature_list import load_feature_list  # noqa: E402
from fraud.data.preprocessing import PreprocessingArtifacts  # noqa: E402
from fraud.data.s3_utils import build_file_list, make_s3_filesystem  # noqa: E402
from fraud.log_utils import setup_logging  # noqa: E402
from YOUR_PACKAGE.phase4b.factory import build_sequential_model, sequence_dataset_options  # noqa: E402
from YOUR_PACKAGE.phase4b.scripts.score_sequential import _model_inputs, _select_predictions, _validate_predictions  # noqa: E402
from YOUR_PACKAGE.phase4b.sequence_builder import SequenceBuilder  # noqa: E402
from YOUR_PACKAGE.v2.models import TARGET_ENDING_POLICY  # noqa: E402
from YOUR_PACKAGE.v2.scripts.train_v2 import MAX_STAGE1_ROWS, eval_batch_size, sha256, utc_now, write_json  # noqa: E402
from YOUR_PACKAGE.v2.target_ending import (NATURAL_ROWS, LabelFreeSequenceBuilder, LabelFreeTargetEndingBuilder,  # noqa: E402
                                    TargetEndingBuilder)

log = setup_logging()


def checkpoint_policy(ckpt, cfg):
    """The window cap a checkpoint was validated with, or a refusal when the policy does not fit the model."""
    chunk = bool(cfg.sequence.get("predict_every_transaction", False))
    policy = ckpt.get("validation_policy")
    if not chunk:
        if policy is not None:
            raise ValueError(f"A default-B config cannot score a checkpoint validated as {policy}")
        if cfg.sequence.get("max_window_rows", None) is not None:
            raise ValueError("sequence.max_window_rows applies to chunk models only")
        return None
    if not policy or policy.get("name") != TARGET_ENDING_POLICY:
        raise ValueError(f"Chunk checkpoint was not validated on target-ending windows (validation_policy={policy}); "
                         "V2 does not rescore a model under a policy it was not validated with")
    cap = policy.get("max_window_rows")
    asked = cfg.sequence.get("max_window_rows", None)
    if asked is not None and int(asked) != cap:
        raise ValueError(f"Config cap {asked} differs from the checkpoint's validated cap {cap}")
    return cap


def target_slot_predictions(logits, batch):
    """Probability, label and metadata of each target-ending window's single target slot."""
    labels = batch["target_seq"]
    selected = labels != -100
    if not torch.equal(selected.sum(1), torch.ones(labels.shape[0], dtype=torch.long)):
        raise ValueError("Each target-ending window must carry exactly one target")
    slot = selected.float().argmax(1)
    if not torch.equal(slot, batch["mask"].sum(1) - 1):
        raise ValueError("The target must be the last real row of its window")
    rows = torch.arange(labels.shape[0])
    prob = torch.softmax(logits[rows, slot], dim=-1)[:, 1].detach().cpu().numpy()
    y = labels[rows, slot].cpu().numpy()
    k = slot.numpy()
    meta = {key: np.asarray(values)[np.arange(len(k)), k] for key, values in batch.get("meta_seq", {}).items()}
    return prob, y, meta


def load_for_scoring(cfg, checkpoint_path, label_free=False):
    """Checkpoint, model and dataset under the checkpoint's validated policy (shared with the exporter, which
    passes ``label_free=True``: its builders never read the label column)."""
    options = sequence_dataset_options(cfg)
    checkpoint_hash = sha256(checkpoint_path)
    ckpt = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    cap = checkpoint_policy(ckpt, cfg)
    chunk = bool(options["emit_target_seq"])

    fs = make_s3_filesystem(cfg.s3.cred_path) if cfg.s3.get("cred_path") else None
    features = load_feature_list(cfg.predictors.csv_path, version=cfg.predictors.version, filesystem=fs)
    artifacts = PreprocessingArtifacts.load(f"{cfg.artifacts.base.rstrip('/')}/{cfg.artifacts.version}", filesystem=fs)
    dt_config = DatetimeConfig(order_col=cfg.data.order_col, fields=list(cfg.datetime.fields),
                               encoding=cfg.datetime.encoding, is_weekend=cfg.datetime.is_weekend)
    id_cols = list(cfg.data.get("id_cols", []))
    if not id_cols:
        raise ValueError("Scoring needs data.id_cols, the keys paired_v2.py joins on")
    amount_col = cfg.data.get("amount_col", None)
    files = build_file_list(cfg.eval.base, cfg.eval.file_start, cfg.eval.file_end)
    common = dict(
        file_list=files, artifacts=artifacts, features=features, datetime_config=dt_config,
        target_col=cfg.data.target_col, account_col=cfg.data.account_col, order_col=cfg.data.order_col,
        history_len=int(cfg.sequence.history_len), stride=int(cfg.sequence.get("eval_stride", 1)),
        positive_label=cfg.data.get("positive_label", 1), add_missing_flag=cfg.preprocess.add_missing_flag,
        time_delta=bool(cfg.sequence.get("time_delta", True)), batch_size=eval_batch_size(cfg),
        shuffle=False, tie_break_col=cfg.data.get("tie_break_col", None), id_cols=id_cols, amount_col=amount_col,
        s3_cred_path=cfg.s3.cred_path, max_chunk_rows=cfg.sequence.get("max_chunk_rows", None), **options)
    if chunk and cap is not None and eval_batch_size(cfg) * max(cap, int(cfg.sequence.history_len) + 1) >= MAX_STAGE1_ROWS:
        raise ValueError("eval batch x window width >= 65,535 (lean plan F15); set training.eval_batch_size")
    if chunk:
        builder = LabelFreeTargetEndingBuilder if label_free else TargetEndingBuilder
        dataset = builder(max_window_rows=cap, **common)
    else:
        dataset = (LabelFreeSequenceBuilder if label_free else SequenceBuilder)(**common)
    loader = DataLoader(dataset, batch_size=None, num_workers=int(cfg.training.get("num_workers", 0)))

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = build_sequential_model(cfg, dataset)
    model.on_load_checkpoint(ckpt)
    model.load_state_dict(ckpt["state_dict"])
    model.eval().to(device)
    return dict(ckpt=ckpt, checkpoint_hash=checkpoint_hash, cap=cap, chunk=chunk, loader=loader, model=model,
                device=device, id_cols=id_cols, amount_col=amount_col)


def natural_rows(batch, chunk):
    """Rows each scored row's window would hold without a cap (default B: its rows, which are never capped)."""
    if not chunk:
        return batch["mask"].sum(1).numpy()
    slot = (batch["mask"].sum(1) - 1).numpy()
    return np.asarray(batch["meta_seq"][NATURAL_ROWS])[np.arange(len(slot)), slot].astype(np.int64)


def record_scoring(checkpoint, receipt, key="scored"):
    """Keep scoring attempts (or exports) on the run so train_v2 refuses to resume it.

    Updating an attempt preserves its entry even if scoring or receipt writing failed.
    """
    path = os.path.join(os.path.dirname(os.path.abspath(checkpoint)), "run_manifest_v2.json")
    if not os.path.isfile(path):
        return  # a V1 checkpoint (R05, R15, R20) has no V2 run manifest
    with open(path, encoding="utf-8") as f:
        manifest = json.load(f)
    records = manifest.setdefault(key, [])
    for index, previous in enumerate(records):
        if receipt.get("attempt_id") and previous.get("attempt_id") == receipt["attempt_id"]:
            records[index] = receipt
            break
    else:
        records.append(receipt)
    write_json(path, manifest)


@contextmanager
def scoring_attempt(checkpoint, exposure_path, exposure):
    """Persist the attempted read before iterating the labelled loader; retain it on failure."""
    read_started = False
    try:
        write_json(exposure_path, exposure)
        record_scoring(checkpoint, exposure)
        read_started = True
        yield
        exposure.update(status="completed", completed=True, ended_utc=utc_now())
        write_json(exposure_path, exposure)
        record_scoring(checkpoint, exposure)
    except BaseException as error:
        exposure.update(status="failed", completed=False, ended_utc=utc_now(), error_type=type(error).__name__)
        if not read_started:
            exposure["labels_read"] = False
        # Either durable initial record still identifies the attempt if an outcome write fails.
        updates = [lambda: write_json(exposure_path, exposure)]
        if read_started:
            updates.append(lambda: record_scoring(checkpoint, exposure))
        for persist in updates:
            try:
                persist()
            except Exception as receipt_error:
                log.error("Could not update failed scoring record (%s)", type(receipt_error).__name__)
        raise


def select(logits, batch, chunk):
    """(probability, label, metadata) per scored row: the target slot of a window, or V1's single target."""
    return target_slot_predictions(logits, batch) if chunk else _select_predictions(logits, batch, False)


POPULATIONS = ("SELECT", "EPOCH_VAL", "DS_SELECT", "DEV_OOT", "FINAL", "BENCH", "OTHER")


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--out", required=True, help="local prediction parquet; refused if it exists")
    parser.add_argument("--metrics", default=None, help="receipt JSON; defaults to <out>.json")
    parser.add_argument("--population", required=True, choices=POPULATIONS,
                        help="the population this file range is (DECISIONS section 3); goes into the exposure record")
    parser.add_argument("--purpose", required=True,
                        help="why it is scored (e.g. architecture_decision, continuity, s1, final_evaluation)")
    parser.add_argument("overrides", nargs="*")
    args = parser.parse_args(argv)

    cfg = OmegaConf.load(args.config)
    if args.overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(args.overrides))
    metrics_path = args.metrics or f"{args.out}.json"
    exposure_path = f"{args.out}.exposure.json"
    for path in (args.out, metrics_path, exposure_path):
        if os.path.exists(path):
            raise FileExistsError(f"{path} exists; every score writes a new file")
    run = load_for_scoring(cfg, args.checkpoint)
    exposure = {
        "attempt_id": uuid.uuid4().hex, "utc": utc_now(), "operation": "score_v2",
        "population": args.population, "purpose": args.purpose,
        "run": os.path.basename(os.path.dirname(os.path.abspath(args.checkpoint))),
        "checkpoint": os.path.abspath(args.checkpoint), "checkpoint_sha256": run["checkpoint_hash"],
        "files": {"base": cfg.eval.base, "start": int(cfg.eval.file_start), "end": int(cfg.eval.file_end)},
        "predictions": os.path.abspath(args.out), "status": "started", "completed": False,
        "labels_read": None,  # Unknown until a batch returns; the loader may fail after reading labels.
        "note": "the receipt's average_precision covers every scored row in the file range (history months "
                "included); decision APs come from paired_v2",
    }
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with scoring_attempt(args.checkpoint, exposure_path, exposure):
        _score(args, cfg, run, metrics_path, exposure)
    log.info("Wrote %d predictions (%d positives) -> %s", exposure["n_predictions"], exposure["n_positives"], args.out)


def _score(args, cfg, run, metrics_path, exposure):
    model, loader, device, chunk, cap = run["model"], run["loader"], run["device"], run["chunk"], run["cap"]
    ckpt, checkpoint_hash, id_cols, amount_col = run["ckpt"], run["checkpoint_hash"], run["id_cols"], run["amount_col"]

    keep = id_cols + ([amount_col] if amount_col else [])
    scores, labels, widths, naturals, meta = [], [], [], [], {c: [] for c in keep}
    for batch in loader:
        exposure["labels_read"] = True
        with torch.no_grad():
            logits = model(_model_inputs(batch, device)).cpu()
        prob, y, m = select(logits, batch, chunk)
        scores.append(prob)
        labels.append(y)
        widths.append(batch["mask"].sum(1).numpy())
        naturals.append(natural_rows(batch, chunk))
        for c in keep:
            meta[c].append(np.asarray(m[c]))
    if not scores:
        raise ValueError("The file range produced no transactions")
    if sha256(args.checkpoint) != checkpoint_hash:
        raise ValueError("Checkpoint changed during scoring; refusing to attribute these predictions")

    score, y_true = np.concatenate(scores), np.concatenate(labels)
    out = {c: np.concatenate(v) for c, v in meta.items()}
    _validate_predictions(score, y_true, out, id_cols)
    window_rows = np.concatenate(widths).astype(np.int64)
    natural = np.concatenate(naturals).astype(np.int64)
    out[cfg.data.target_col] = y_true
    out["score"] = score
    out["window_rows"] = window_rows
    out["window_natural_rows"] = natural
    out["window_truncated"] = natural > window_rows
    pq.write_table(pa.table(out), args.out)

    exposure.update(n_predictions=int(len(score)), n_positives=int(y_true.sum()), predictions_sha256=sha256(args.out))
    both = np.unique(y_true).size == 2
    write_json(metrics_path, {
        "utc": utc_now(), "predictions": os.path.abspath(args.out), "predictions_sha256": exposure["predictions_sha256"],
        "checkpoint": os.path.abspath(args.checkpoint), "checkpoint_sha256": checkpoint_hash,
        "validation_policy": ckpt.get("validation_policy"), "scoring": "target-ending" if chunk else "single-target",
        "max_window_rows": cap, "files": {"base": cfg.eval.base, "start": int(cfg.eval.file_start),
                                          "end": int(cfg.eval.file_end)},
        "n_predictions": int(len(score)), "n_positives": int(y_true.sum()),
        "average_precision": float(average_precision_score(y_true, score)) if both else None,
        "auroc": float(roc_auc_score(y_true, score)) if both else None,
        "metrics_scope": "every scored row in the file range, history months included; decision APs come from "
                         "paired_v2 on the target window",
        "window_rows": {"mean": float(window_rows.mean()), "p50": float(np.percentile(window_rows, 50)),
                        "p99": float(np.percentile(window_rows, 99)), "max": int(window_rows.max()),
                        "share_at_cap": None if cap is None else float(np.mean(window_rows == cap)),
                        "share_truncated": float(np.mean(natural > window_rows)),
                        "natural_p99": float(np.percentile(natural, 99)), "natural_max": int(natural.max())},
        "scoring_precision": "float32, no autocast (as V1's score_sequential.py)",
        "eval_batch_size": eval_batch_size(cfg),
        "sequence_contract": model.sequence_contract,
    })


if __name__ == "__main__":
    main()
