"""Guarded build of the V2 no-month preprocessing artifact (plan v5 section 2, step 1). 2026-10-19.

Runs V1's builder (fraud/scripts/build_preprocessing_artifacts.py, unchanged) only after checking that:
- V1's predictors.csv has the hash recorded in the lean plan (F22), and the no-month list is it minus the
  ``month`` row, nothing else;
- ``month`` is not a datetime field;
- the target version does not exist yet (V1's builder would overwrite it).

Usage:
    python -m YOUR_PACKAGE.v2.scripts.build_nomonth_artifact --config YOUR_PACKAGE/v2/configs/preprocessing_nomonth.yaml
"""
import argparse
import os
import sys
from pathlib import Path

from omegaconf import OmegaConf

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))

from fraud.data.s3_utils import make_s3_filesystem, strip_scheme  # noqa: E402
from YOUR_PACKAGE.v2.scripts.train_v2 import sha256  # noqa: E402

V1_PREDICTORS_SHA256 = "635153390b266201651303e65e3b9222b77450a5523de81afa88a682c6f69bce"  # lean plan F22


def check(cfg, v1_predictors, fs):
    """Refuse unless the list, the datetime fields and the target version are as the plan says."""
    if sha256(v1_predictors) != V1_PREDICTORS_SHA256:
        raise ValueError(f"{v1_predictors} does not have V1's recorded SHA-256 (F22); diff it before building")
    with open(v1_predictors, encoding="utf-8") as f:
        expected = [line for line in f.read().splitlines() if not line.startswith("month,")]
    with open(cfg.predictors.csv_path, encoding="utf-8") as f:
        got = f.read().splitlines()
    if got != expected:
        raise ValueError(f"{cfg.predictors.csv_path} is not V1's predictors.csv minus the month row")
    if "month" in list(cfg.datetime.fields):
        raise ValueError("datetime.fields must not include month")
    target = f"{cfg.build.output_base.rstrip('/')}/{cfg.build.artifact_version}/manifest.json"
    exists = fs.exists(strip_scheme(target)) if fs is not None else os.path.exists(target)
    if exists:
        raise FileExistsError(f"{target} exists; V1's builder would overwrite it. Choose a new version id")
    return target


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--v1-predictors", default=str(ROOT / "fraud/configs/predictors.csv"))
    parser.add_argument("overrides", nargs="*")
    args = parser.parse_args(argv)
    cfg = OmegaConf.load(args.config)
    if args.overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(args.overrides))
    fs = make_s3_filesystem(cfg.s3.cred_path) if cfg.s3.get("cred_path") else None
    target = check(cfg, args.v1_predictors, fs)
    from fraud.scripts import build_preprocessing_artifacts as v1

    sys.argv = ["build_preprocessing_artifacts.py", "--config", args.config, *args.overrides]
    v1.main()
    print(f"Built {target}")


if __name__ == "__main__":
    main()
