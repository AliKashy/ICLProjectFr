"""Check that the no-month artifact is V1's version 1 minus month (audit finding 42 of 2026-10-19; step 1). 2026-10-19.

Every per-feature entry (vocabularies, mean, std, median, missing share) and the fit files must be identical;
the only difference allowed is that ``month`` is absent. Writes a JSON report; exits non-zero on any difference.

Usage:
    python -m YOUR_PACKAGE.v2.scripts.check_nomonth_artifact --v1 <artifacts base>/1 --nomonth <artifacts base>/20261019 \
        --out <new json> [--cred-path <file>]
"""
import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))

from fraud.data.preprocessing import PreprocessingArtifacts  # noqa: E402
from YOUR_PACKAGE.v2.storage import thin_read_filesystem  # noqa: E402


def compare(v1, nomonth, dropped=("month",)):
    report = {"missing_in_nomonth": sorted(set(v1.features) - set(nomonth.features) - set(dropped)),
              "extra_in_nomonth": sorted(set(nomonth.features) - set(v1.features)),
              "dropped_still_present": sorted(set(dropped) & set(nomonth.features)),
              "different_entries": sorted(k for k in set(v1.features) & set(nomonth.features)
                                          if v1.features[k] != nomonth.features[k]),
              "fit_files_equal": v1.fit_files == nomonth.fit_files,
              "features_compared": len(set(v1.features) & set(nomonth.features))}
    report["passed"] = (report["fit_files_equal"] and not report["missing_in_nomonth"]
                        and not report["extra_in_nomonth"] and not report["dropped_still_present"]
                        and not report["different_entries"])
    return report


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--v1", required=True)
    parser.add_argument("--nomonth", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--cred-path", default=None)
    args = parser.parse_args(argv)
    if os.path.exists(args.out):
        raise FileExistsError(f"{args.out} exists")
    fs = thin_read_filesystem(args.cred_path)
    report = compare(PreprocessingArtifacts.load(args.v1, filesystem=fs),
                     PreprocessingArtifacts.load(args.nomonth, filesystem=fs))
    report.update(v1=args.v1, nomonth=args.nomonth)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    print(json.dumps(report, indent=2))
    if not report["passed"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
