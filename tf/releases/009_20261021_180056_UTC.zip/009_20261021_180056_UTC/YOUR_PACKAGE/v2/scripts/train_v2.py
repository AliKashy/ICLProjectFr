"""V2 training entry point (governing plan bridge/plans/2026-10-19-v2-one-gpu/PLAN.md section 8). 2026-10-19.

It runs every V2 fit: B05, B05r, C05, B20, C20, S1 and M3 (plan v5 section 2). On top of V1's trainer
(YOUR_PACKAGE/phase4b/scripts/train_sequential.py, unchanged), it adds:
1. resume from the last completed epoch (``--resume``), with model, optimizer, scheduler, loop counters and the
   python, numpy, torch and CUDA random states restored, so a resumed run continues the uninterrupted one
   (tested), and the metrics CSV keeps the earlier epochs. A run that ends at its epoch budget is
   ``budget_reached`` and continues with a larger ``training.max_epochs`` (the timed first epoch, plan 8.5); an
   early-stopped run is ``finished``; a run whose checkpoint was scored (score_v2 records it) is final. Neither
   of the last two is resumed (plan review item V4-C1);
2. chunk models (all-position B) validated on target-ending windows (YOUR_PACKAGE/v2/target_ending.py), capped at
   ``sequence.max_window_rows`` rows when set, the serving cap recorded in the checkpoint;
3. a batch check for chunk models: batch (chunks) x the widest chunk must stay under 65,535 (lean plan F15);
4. ``max_epochs`` and patience applied after a resume (Lightning would restore the old patience); a resume with
   any other configuration change, a different source, predictor list or artifact, or a checkpoint whose
   validation policy differs is refused before anything is written (audit finding 47 of 2026-10-19, plan review item V4-C2);
5. a run manifest: config, source and checkpoint SHA-256, seeds, the determinism state in force, workers and
   window buffer (both change the streamed data order), resume events;
6. the file-shuffle seed follows ``training.seed``;
7. ``training.deterministic`` (default true; "warn" allowed) with ``CUBLAS_WORKSPACE_CONFIG`` set.

EMA is outside V2 (plan section 1) and its state is not checkpointed, so ``training.ema`` is refused.

Default B goes through V1's builder, model and Trainer settings, so with the same seed and determinism off it
trains exactly as V1 (tested).

Usage:
    python -m YOUR_PACKAGE.v2.scripts.train_v2 --config <resolved yaml> [dotlist overrides] [--resume]
"""
import argparse
import csv
import datetime as _dt
import hashlib
import json
import os
import random
import socket
import sys
import uuid
from pathlib import Path

os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")  # before torch initialises CUDA

import numpy as np  # noqa: E402
import pytorch_lightning as pl  # noqa: E402
import torch  # noqa: E402
from omegaconf import OmegaConf  # noqa: E402
from pytorch_lightning.callbacks import Callback, EarlyStopping, ModelCheckpoint  # noqa: E402
from torch.utils.data import DataLoader  # noqa: E402

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))

from fraud.callbacks import CSVMetricsCallback, StreamingBinaryMetrics  # noqa: E402
from fraud.data.datetime_features import DatetimeConfig  # noqa: E402
from fraud.data.feature_list import load_feature_list  # noqa: E402
from fraud.data.preprocessing import PreprocessingArtifacts  # noqa: E402
from fraud.data.s3_utils import build_file_list, make_s3_filesystem  # noqa: E402
from fraud.log_utils import setup_logging  # noqa: E402
from YOUR_PACKAGE.phase4b.factory import build_sequential_model, sequence_dataset_options  # noqa: E402
from YOUR_PACKAGE.phase4b.sequence_builder import SequenceBuilder  # noqa: E402
from YOUR_PACKAGE.v2.models import FTTransformerHierTargetEnding  # noqa: E402
from YOUR_PACKAGE.v2.target_ending import TargetEndingBuilder  # noqa: E402

log = setup_logging()
MANIFEST = "run_manifest_v2.json"
MAX_STAGE1_ROWS = 65535  # lean plan F15: stage 1 runs batch x width rows in one CUDA launch


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def source_files():
    """Every runtime source file with its hash (fraud/ and YOUR_PACKAGE/ Python files, tests excluded); recorded in the run
    manifest so the handover can name the files that changed after the fit."""
    from YOUR_PACKAGE.source_identity import runtime_source_files

    files = [p for p in runtime_source_files(ROOT) if "/tests/" not in p.relative_to(ROOT).as_posix()]
    return {p.relative_to(ROOT).as_posix(): sha256(p) for p in files}


def source_sha256():
    """Hash of the runtime sources (fraud/ and YOUR_PACKAGE/ Python files, tests excluded)."""
    return hashlib.sha256(json.dumps(source_files(), sort_keys=True).encode()).hexdigest()


LOCK = "RUNNING.lock.json"


def pid_alive(pid):
    try:
        os.kill(int(pid), 0)
    except (OSError, TypeError, ValueError):
        return False
    return True


def acquire_run_lock(save_path):
    """One trainer per run folder. A start or resume while another trainer of this folder runs on this host (a pasted
    line run twice, a terminal reopened) is refused; a lock left by a dead process is recorded and replaced."""
    path = os.path.join(save_path, LOCK)
    stale = None
    if os.path.isfile(path):
        with open(path, encoding="utf-8") as f:
            held = json.load(f)
        if held.get("hostname") == socket.gethostname() and pid_alive(held.get("pid")):
            raise RuntimeError(f"{save_path} has a trainer running (pid {held.get('pid')} since {held.get('utc')}); wait for its "
                               "status line in the .out file and never start a second one in the same folder")
        stale = held
    write_json(path, {"pid": os.getpid(), "hostname": socket.gethostname(), "utc": utc_now()})
    return path, stale


def release_run_lock(path):
    try:
        os.remove(path)
    except OSError:
        pass


def write_json(path, value):
    tmp = f"{path}.{uuid.uuid4().hex}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(value, f, indent=2, sort_keys=True, default=str)
    os.replace(tmp, path)


def utc_now():
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class RandomStateCallback(Callback):
    """Saves and restores python, numpy, torch and CUDA random states with every checkpoint, so that the data
    stream (V1's builder shuffles with numpy) and dropout continue after a resume as they would have. The numpy
    state is kept as plain python values so that the checkpoint still loads with torch's weights_only default."""

    def state_dict(self):
        name, keys, pos, has_gauss, cached = np.random.get_state()
        state = {"python": random.getstate(),
                 "numpy": (name, keys.tolist(), int(pos), int(has_gauss), float(cached)),
                 "torch": torch.get_rng_state()}
        if torch.cuda.is_available():
            state["cuda"] = torch.cuda.get_rng_state_all()
        return state

    def load_state_dict(self, state_dict):
        random.setstate(state_dict["python"])
        name, keys, pos, has_gauss, cached = state_dict["numpy"]
        np.random.set_state((name, np.asarray(keys, dtype=np.uint32), pos, has_gauss, cached))
        torch.set_rng_state(state_dict["torch"])
        if "cuda" in state_dict and torch.cuda.is_available():
            torch.cuda.set_rng_state_all(state_dict["cuda"])


class ResumableCSVMetrics(CSVMetricsCallback):
    """V1's metrics CSV, which a resumed run continues: it keeps the rows of the epochs already completed and
    drops any row of the epoch being rerun (V1's callback would rewrite the file from its header)."""

    def on_train_start(self, trainer, pl_module):
        if not os.path.isfile(self.path):
            return
        with open(self.path, newline="") as f:
            reader = csv.DictReader(f)
            self.fieldnames = reader.fieldnames
            kept = [row for row in reader if int(row["epoch"]) < trainer.current_epoch]
        with open(self.path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=self.fieldnames)
            writer.writeheader()
            writer.writerows(kept)


class PlateauResumeCallback(Callback):
    """Restores the ReduceLROnPlateau step a resume would otherwise lose.

    Checkpoints are written at the end of each training epoch, before Lightning steps the epoch-level plateau
    scheduler (V1's ReduceLROnPlateau on valid_loss), and a resumed fit does not repeat that step. The
    checkpointed epoch's valid_loss is therefore saved here and the missing step is taken once when training
    resumes, so the learning-rate schedule continues as in the uninterrupted run (PR #21 review)."""

    def __init__(self):
        self._trainer = None
        self._pending = None

    def setup(self, trainer, pl_module, stage):
        self._trainer = trainer

    def state_dict(self):
        value = self._trainer.callback_metrics.get("valid_loss") if self._trainer is not None else None
        return {"plateau_metric": None if value is None else float(value)}

    def load_state_dict(self, state_dict):
        self._pending = state_dict.get("plateau_metric")

    def on_train_start(self, trainer, pl_module):
        if self._pending is not None:
            for config in trainer.lr_scheduler_configs:
                scheduler = config.scheduler
                if (isinstance(scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau)
                        and scheduler.last_epoch < trainer.current_epoch):
                    scheduler.step(self._pending)
        self._pending = None


class ConfiguredEarlyStopping(EarlyStopping):
    """EarlyStopping whose patience is the configured value even after a resume (Lightning restores the saved
    patience from the checkpoint)."""

    def load_state_dict(self, state_dict):
        configured = self.patience
        super().load_state_dict(state_dict)
        self.patience = configured


def is_chunk_model(cfg):
    return bool(cfg.sequence.get("predict_every_transaction", False))


def make_dataset(cfg, files, artifacts, features, dt_config, shuffle, stride, builder_cls=SequenceBuilder,
                 batch_size=None, **extra):
    return builder_cls(
        file_list=files, artifacts=artifacts, features=features, datetime_config=dt_config,
        target_col=cfg.data.target_col, account_col=cfg.data.account_col,
        order_col=cfg.data.order_col, history_len=int(cfg.sequence.history_len),
        stride=int(stride), positive_label=cfg.data.get("positive_label", 1),
        add_missing_flag=cfg.preprocess.add_missing_flag,
        time_delta=bool(cfg.sequence.get("time_delta", True)),
        batch_size=int(batch_size or cfg.training.batch_size), shuffle=shuffle,
        buffer_windows=int(cfg.training.get("buffer_windows", 65536)),
        tie_break_col=cfg.data.get("tie_break_col", None), s3_cred_path=cfg.s3.cred_path,
        max_chunk_rows=cfg.sequence.get("max_chunk_rows", None),
        shard_seed=int(cfg.training.seed),
        **sequence_dataset_options(cfg), **extra,
    )


def eval_batch_size(cfg):
    """Windows per validation and scoring batch: ``training.eval_batch_size``, else the training batch (V1)."""
    return int(cfg.training.get("eval_batch_size", None) or cfg.training.batch_size)


def check_batch_plan(cfg):
    """Chunk models: the widest training chunk and the window cap are required, and both batch x width products
    must stay under the 65,535-row stage 1 limit (lean plan F15; validation too, audit finding 46 of 2026-10-19)."""
    cap = cfg.sequence.get("max_window_rows", None)
    if not is_chunk_model(cfg):
        if cap is not None:
            raise ValueError("sequence.max_window_rows applies to chunk models only (default B holds history_len rows)")
        return None
    widest = cfg.sequence.get("max_chunk_rows", None)
    if widest is None:
        raise ValueError("Chunk models need sequence.max_chunk_rows from measure_chunk_widths (the widest chunk), "
                         "so the batch can be checked against the 65,535-row stage 1 limit")
    if cap is None:
        raise ValueError("Chunk models need sequence.max_window_rows, the serving cap from measure_window_rows "
                         "(plan section 8 item 3)")
    batch, eval_batch = int(cfg.training.batch_size), eval_batch_size(cfg)
    width = max(int(cap), int(cfg.sequence.history_len) + 1)
    if batch * int(widest) >= MAX_STAGE1_ROWS:
        raise ValueError(f"batch {batch} x widest chunk {widest} >= {MAX_STAGE1_ROWS} (lean plan F15)")
    if eval_batch * width >= MAX_STAGE1_ROWS:
        raise ValueError(f"validation: eval batch {eval_batch} x window width {width} >= {MAX_STAGE1_ROWS}; "
                         "set training.eval_batch_size")
    return {"batch_chunks": batch, "max_chunk_rows": int(widest), "max_window_rows": int(cap),
            "eval_batch_windows": eval_batch,
            "accumulate_grad_batches": int(cfg.training.get("accumulate_grad_batches", 1)),
            "targets_per_update_note": "about batch x mean chunk rows x accumulation; set from measure_chunk_widths"}


RESUME_MAY_CHANGE = ("training.max_epochs", "training.early_stopping_patience")


def _flat(tree, prefix=""):
    if isinstance(tree, dict):
        out = {}
        for k, v in tree.items():
            out.update(_flat(v, f"{prefix}{k}."))
        return out
    return {prefix.rstrip("."): tree}


def check_resume_config(cfg, start_config_path):
    """A resume continues one run: only max_epochs and patience may differ from the start config (plan 8.5)."""
    before = _flat(OmegaConf.to_container(OmegaConf.load(start_config_path), resolve=True))
    after = _flat(OmegaConf.to_container(cfg, resolve=True))
    changed = sorted(k for k in set(before) | set(after)
                     if k not in RESUME_MAY_CHANGE and before.get(k, "<absent>") != after.get(k, "<absent>"))
    if changed:
        raise ValueError(f"--resume refuses a changed configuration: {changed} (only {list(RESUME_MAY_CHANGE)} "
                         "may change); start a new run folder instead")


def run_identity(cfg, artifacts):
    """What one run must keep across resumes besides its configuration: code, predictor list and artifact."""
    csv_path = Path(cfg.predictors.csv_path)
    csv_path = csv_path if csv_path.is_absolute() else ROOT / csv_path
    artifact = {"version": artifacts.artifact_version, "fit_files": artifacts.fit_files, "features": artifacts.features}
    return {"source_sha256": source_sha256(),
            "predictors_sha256": sha256(csv_path) if csv_path.is_file() else None,
            "artifacts_sha256": hashlib.sha256(json.dumps(artifact, sort_keys=True, default=str).encode()).hexdigest()}


def check_resume_identity(identity, manifest, last, expected_policy):
    """Refuse a resume whose code, predictor list, artifact or checkpoint validation policy differ from the start."""
    started = manifest["start"].get("identity", {})
    changed = sorted(k for k in identity if started.get(k) != identity[k])
    if changed:
        raise ValueError(f"--resume refuses a changed run identity: {changed}; start a new run folder instead")
    saved = torch.load(last, map_location="cpu", weights_only=False).get("validation_policy")
    if saved != expected_policy:
        raise ValueError(f"--resume: last.ckpt validation_policy {saved} differs from the configured {expected_policy}")


def final_status(epochs_run, max_epochs, early_stopped=False):
    """``finished`` when early stopping ended the run (on any epoch, the last included) or it stopped short of
    its budget; ``budget_reached`` when it used the whole budget without stopping (it may continue)."""
    return "finished" if early_stopped or int(epochs_run) < int(max_epochs) else "budget_reached"


def build_trainer(cfg, callbacks):
    det = cfg.training.get("deterministic", True)
    if det not in (True, False, "warn"):
        raise ValueError("training.deterministic must be true, false or 'warn'")
    return pl.Trainer(
        max_epochs=int(cfg.training.max_epochs), accelerator=cfg.training.accelerator,
        devices=1,
        precision=cfg.training.get("precision", "bf16-mixed"),
        accumulate_grad_batches=int(cfg.training.get("accumulate_grad_batches", 1)),
        callbacks=callbacks, logger=False,
        log_every_n_steps=int(cfg.training.get("log_every_n_steps", 50)),
        enable_progress_bar=True,
        deterministic=det,
    )


def main(argv=None):
    if int(os.environ.get("WORLD_SIZE", "1")) > 1:
        raise RuntimeError("V2 supports one device only")
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("--resume", action="store_true", help="continue from <checkpoint_dir>/last.ckpt")
    parser.add_argument("overrides", nargs="*")
    args = parser.parse_args(argv)

    cfg = OmegaConf.load(args.config)
    if args.overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(args.overrides))
    sequence_dataset_options(cfg)
    batch_plan = check_batch_plan(cfg)
    if cfg.training.get("seed") is None:
        raise ValueError("Every V2 fit sets an explicit training.seed (plan section 8 item 7)")
    if bool(cfg.training.get("ema", False)):
        raise ValueError("EMA is outside V2 (plan section 1); its state is not saved in checkpoints")
    pl.seed_everything(int(cfg.training.seed), workers=True)

    save_path = cfg.output.checkpoint_dir
    manifest_path = os.path.join(save_path, MANIFEST)
    last = os.path.join(save_path, "last.ckpt")
    if args.resume:
        if not os.path.isfile(last) or not os.path.isfile(manifest_path):
            raise FileNotFoundError(f"--resume needs {last} and {manifest_path}")
        with open(manifest_path, encoding="utf-8") as f:
            manifest = json.load(f)
        if manifest.get("status") == "finished":
            raise RuntimeError(f"{save_path} holds a finished (early-stopped) run; start a new run folder instead")
        if manifest.get("scored") or manifest.get("exported"):
            raise RuntimeError(f"{save_path} holds a run whose checkpoint was scored or exported; it is final")
        if manifest.get("status") == "budget_reached" and int(cfg.training.max_epochs) <= int(manifest["epochs_run"]):
            raise ValueError(f"--resume of a run that used its budget needs training.max_epochs above "
                             f"{manifest['epochs_run']}")
        check_resume_config(cfg, manifest["start"]["config"])
    else:
        failed_starts = []
        if os.path.exists(last) or os.path.exists(os.path.join(save_path, "best.ckpt")):
            raise FileExistsError(f"{save_path} already holds a run; use --resume or a new folder")
        if os.path.exists(manifest_path):
            with open(manifest_path, encoding="utf-8") as f:
                old = json.load(f)
            if old.get("status") != "running":
                raise FileExistsError(f"{save_path} already holds a run; use --resume or a new folder")
            # A start that failed before its first checkpoint: the same command starts again, and the
            # earlier attempt stays on record.
            failed_starts = old.get("failed_starts", []) + [old.get("start")]
        manifest = {"created_utc": utc_now(), "resume_events": [], "failed_starts": failed_starts}
    os.makedirs(save_path, exist_ok=True)
    lock_path, stale_lock = acquire_run_lock(save_path)
    print(f"train_v2 pid {os.getpid()} in {save_path}; lock {lock_path}", flush=True)
    try:
        _fit(args, cfg, save_path, manifest, manifest_path, last, batch_plan, stale_lock)
    finally:
        release_run_lock(lock_path)


def _fit(args, cfg, save_path, manifest, manifest_path, last, batch_plan, stale_lock):
    fs = make_s3_filesystem(cfg.s3.cred_path) if cfg.s3.get("cred_path") else None
    features = load_feature_list(cfg.predictors.csv_path, version=cfg.predictors.version, filesystem=fs)
    artifacts_path = f"{cfg.artifacts.base.rstrip('/')}/{cfg.artifacts.version}"
    artifacts = PreprocessingArtifacts.load(artifacts_path, filesystem=fs)
    dt_config = DatetimeConfig(order_col=cfg.data.order_col, fields=list(cfg.datetime.fields),
                               encoding=cfg.datetime.encoding, is_weekend=cfg.datetime.is_weekend)

    train_files = build_file_list(cfg.data.train_base, cfg.data.train_start, cfg.data.train_end)
    val_files = build_file_list(cfg.data.val_base, cfg.data.val_start, cfg.data.val_end)
    num_workers = int(cfg.training.get("num_workers", 0))
    train_ds = make_dataset(cfg, train_files, artifacts, features, dt_config, True,
                            cfg.sequence.get("train_stride", 1))
    cap = cfg.sequence.get("max_window_rows", None)
    if is_chunk_model(cfg):
        val_ds = make_dataset(cfg, val_files, artifacts, features, dt_config, False, cfg.sequence.get("eval_stride", 1),
                              builder_cls=TargetEndingBuilder, batch_size=eval_batch_size(cfg), max_window_rows=cap)
    else:
        val_ds = make_dataset(cfg, val_files, artifacts, features, dt_config, False, cfg.sequence.get("eval_stride", 1),
                              batch_size=eval_batch_size(cfg))
    train_loader = DataLoader(train_ds, batch_size=None, num_workers=num_workers)
    val_loader = DataLoader(val_ds, batch_size=None, num_workers=num_workers)

    model = build_sequential_model(cfg, train_ds)
    if is_chunk_model(cfg):
        # Same object, V2 validation step: swapping the class keeps every parameter and RNG draw identical.
        model.__class__ = FTTransformerHierTargetEnding
        model.max_window_rows = val_ds.max_window_rows
        model.validation_precision = str(cfg.training.get("precision", "bf16-mixed"))
    identity = run_identity(cfg, artifacts)
    if args.resume:
        check_resume_identity(identity, manifest, last, model.validation_policy() if is_chunk_model(cfg) else None)

    monitor, mode = cfg.training.monitor, cfg.training.monitor_mode
    callbacks = [StreamingBinaryMetrics(pos_index=1),
                 ResumableCSVMetrics(os.path.join(save_path, "training_metrics.csv")),
                 RandomStateCallback(),
                 PlateauResumeCallback()]
    early_stopping = ConfiguredEarlyStopping(monitor=monitor, mode=mode,
                                             patience=int(cfg.training.early_stopping_patience))
    callbacks += [early_stopping,
                  ModelCheckpoint(dirpath=save_path, filename="best", monitor=monitor, mode=mode,
                                  enable_version_counter=False),
                  # last.ckpt at the end of every epoch, improving or not, so a resume starts from the last
                  # completed epoch (V1's save_last kept only the last improving one; PR #21 review)
                  ModelCheckpoint(dirpath=save_path, filename="last", monitor=None, save_top_k=1,
                                  enable_version_counter=False)]
    trainer = build_trainer(cfg, callbacks)

    resolved = os.path.join(save_path, "resolved_train_v2.yaml" if not args.resume
                            else f"resolved_train_v2.resume{len(manifest['resume_events']) + 1}.yaml")
    OmegaConf.save(cfg, resolved, resolve=True)
    sources = source_files()
    event = {"utc": utc_now(), "resumed": bool(args.resume), "config": resolved, "config_sha256": sha256(resolved),
             "source_sha256": hashlib.sha256(json.dumps(sources, sort_keys=True).encode()).hexdigest(), "source_files": sources,
             "seed": int(cfg.training.seed),
             "shard_seed": train_ds.shard_seed, "deterministic": cfg.training.get("deterministic", True),
             "deterministic_in_force": torch.are_deterministic_algorithms_enabled(),
             "deterministic_warn_only": torch.is_deterministic_algorithms_warn_only_enabled(),
             "cublas_workspace_config": os.environ.get("CUBLAS_WORKSPACE_CONFIG"),
             "num_workers": num_workers, "buffer_windows": int(cfg.training.get("buffer_windows", 65536)),
             "max_window_rows": cap,
             "max_epochs": int(cfg.training.max_epochs), "patience": int(cfg.training.early_stopping_patience),
             "batch_plan": batch_plan, "validation": "target-ending" if is_chunk_model(cfg) else "single-target",
             "precision": str(cfg.training.get("precision", "bf16-mixed")), "identity": identity,
             "torch": torch.__version__, "lightning": pl.__version__, "pid": os.getpid(), "hostname": socket.gethostname(),
             "stale_lock_replaced": stale_lock}
    if args.resume:
        event["from_checkpoint"] = {"path": last, "sha256": sha256(last)}
        manifest["resume_events"].append(event)
    else:
        manifest["start"] = event
    manifest["status"] = "running"
    write_json(manifest_path, manifest)

    log.info("V2 fit: %s, validation %s, seed %s, deterministic %s", cfg.model.get("type"), event["validation"],
             event["seed"], event["deterministic"])
    trainer.fit(model, train_loader, val_loader, ckpt_path=last if args.resume else None)

    for name in ("best.ckpt", "last.ckpt"):
        p = os.path.join(save_path, name)
        if os.path.isfile(p):
            manifest.setdefault("checkpoints", {})[name] = {"sha256": sha256(p)}
    manifest["epochs_run"] = int(trainer.current_epoch)
    manifest["optimizer_steps"] = int(trainer.global_step)
    manifest["status"] = final_status(manifest["epochs_run"], cfg.training.max_epochs,
                                      early_stopped=bool(trainer.should_stop))
    manifest["ended_utc"] = utc_now()
    with open(manifest_path, encoding="utf-8") as f:  # keep any scoring or export recorded while this fit ran
        on_disk = json.load(f)
    for key in ("scored", "exported"):
        if on_disk.get(key):
            manifest[key] = on_disk[key]
    write_json(manifest_path, manifest)
    log.info("V2 fit %s after %d epochs (%d optimizer steps). Checkpoints in %s", manifest["status"],
             manifest["epochs_run"], manifest["optimizer_steps"], save_path)


if __name__ == "__main__":
    main()
