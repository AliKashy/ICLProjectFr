"""Read native V1 learning evidence without training or accessing bank data.

Run from the installed project root::

    python -m YOUR_PACKAGE.v2.h5_diagnostics
    python -m YOUR_PACKAGE.v2.h5_diagnostics --inspect-checkpoints

The opt-in checkpoint inspection unpickles trusted, locally produced best.ckpt
files on CPU. Checkpoints and prediction rows are never copied to the return.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import traceback
import uuid
import zipfile


SEARCH_ROOTS = (
    "ablations/arch_a_flat/history_h0_vs_h5",
    "ablations/arch_b_hier/history_h0_scored",
    "ablations/arch_b_hier/history_h5_h10",
    "ablations/arch_b_hier/history_h15_h20",
    "ablations/ref_single/ref_single_seeds",
)
MARKERS = {"training_metrics.csv", "resolved_train.yaml", "resolved_score.yaml",
           "best.ckpt", "run_manifest.json", "provenance.json", "state.json",
           "score_metrics.json", "train.log", "score.log", "run_summary.txt"}
METRIC_COLUMNS = ("epoch", "step", "train_loss", "valid_loss", "valid_ap", "valid_auroc")
SECRET_NAMES = {"test.yaml", "credentials", "credential", "secrets", "secret",
                ".env", ".env.local", ".aws", ".ssh",
                "aws_credentials", "access_token", "refresh_token", "private_key",
                "access_key", "password", "credentials.json", "credentials.yaml",
                "credentials.yml", "credential.json", "secrets.json", "secrets.yaml",
                "secrets.yml", "secret.json", "secret.yaml", "secret.yml",
                "password.json", "password.yaml", "access_token.json", "refresh_token.json",
                "private_key.json", "access_key.json"}
CACHE_NAMES = {"__pycache__", ".git", ".ipynb_checkpoints", ".pytest_cache", ".ruff_cache", ".cache"}
BLOCKED_SUFFIXES = {".ckpt", ".pt", ".pth", ".bin", ".safetensors", ".parquet",
                    ".arrow", ".feather", ".pkl", ".pickle", ".npy", ".npz",
                    ".zip", ".pem", ".key", ".pyc"}


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def finite(value):
    try:
        value = float(value)
        return value if math.isfinite(value) else None
    except (TypeError, ValueError):
        return None


def json_native(value):
    """Export plain contract metadata only; never stringify tensor contents."""
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, dict):
        return {str(k): json_native(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_native(v) for v in value]
    return "<non-JSON metadata omitted>"


def write_json(path, value):
    path.write_text(json.dumps(json_native(value), indent=2, sort_keys=True,
                               allow_nan=False) + "\n", encoding="utf-8")


def excluded_reason(path):
    """Keep generated evidence regardless of extension or size (OQ-24)."""
    name = path.name.lower()
    parts = [p.lower() for p in path.parts]
    if path.is_symlink():
        return "symlink (not followed)"
    if any(p in CACHE_NAMES or p in {"data", "raw", "predictions"}
           for p in parts):
        return "non-diagnostic directory"
    if any(part in SECRET_NAMES for part in parts):
        return "credential or secret file"
    if path.suffix.lower() in BLOCKED_SUFFIXES:
        return "weights, predictions, binary or archive (stays on pod)"
    if any(word in name for word in ("raw_rows", "raw_data", "prediction_rows")) or (
        path.suffix.lower() in {".csv", ".jsonl", ".ndjson"}
        and (name.startswith(("prediction", "predictions")) or name in {"transactions.csv", "transactions.jsonl"})
    ):
        return "possible row-level data"
    return None


def load_config(path, issues):
    if not path.exists() or path.is_symlink():
        issues.append(f"UNKNOWN: missing {path.name}")
        return None
    try:
        import yaml
        value = yaml.safe_load(path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("expected a configuration mapping")
        return value
    except Exception as exc:
        issues.append(f"UNKNOWN: {path.name}: {type(exc).__name__}: {exc}")
        return None


def flatten(mapping, prefix=""):
    result = {}
    for key, value in mapping.items():
        key = f"{prefix}.{key}" if prefix else str(key)
        if isinstance(value, dict):
            result.update(flatten(value, key))
        else:
            result[key] = value
    return result


def config_contract(train, score, issues):
    if train is None:
        return {"status": "UNKNOWN", "train": None, "score": None}
    # Retain all settings for comparison, omitting only output destinations and
    # scorer-only eval overrides; these are the native runner's permitted edits.
    ignored = {"eval.checkpoint", "eval.metrics_output", "eval.predictions_base",
               "eval.compute_metrics"}
    t = flatten(train)
    s = flatten(score) if score is not None else None
    differences = []
    if s is not None:
        for key in sorted(set(t) | set(s)):
            if key in ignored or key.startswith("output."):
                continue
            if (key in t) != (key in s) or t.get(key) != s.get(key):
                differences.append({"key": key, "train": t.get(key), "score": s.get(key)})
        if differences:
            issues.append("MISMATCH: training/scoring config: " + ", ".join(x["key"] for x in differences))
    return {"status": "MISMATCH" if differences else ("MATCH" if s is not None else "UNKNOWN"),
            "differences": differences, "train": t, "score": s}


def read_curve(path, issues):
    if not path.exists():
        issues.append("UNKNOWN: missing training_metrics.csv")
        return {"rows": [], "best_valid_ap": None, "best_rows": []}
    try:
        with path.open(newline="", encoding="utf-8-sig") as stream:
            reader = csv.DictReader(stream)
            missing = sorted(set(METRIC_COLUMNS) - set(reader.fieldnames or []))
            if missing:
                issues.append("UNKNOWN: metrics columns absent: " + ", ".join(missing))
            rows = [{"csv_line": line, **{key: finite(row.get(key)) for key in METRIC_COLUMNS}}
                    for line, row in enumerate(reader, 2)]
    except Exception as exc:
        issues.append(f"UNKNOWN: metrics read failed: {type(exc).__name__}: {exc}")
        return {"rows": [], "best_valid_ap": None, "best_rows": []}
    valid = [r for r in rows if r["valid_ap"] is not None]
    best = max((r["valid_ap"] for r in valid), default=None)
    best_rows = [r for r in valid if r["valid_ap"] == best]
    if len(valid) != len(rows):
        issues.append("UNKNOWN: some validation AP values are missing/non-finite; maximum uses finite rows only")
    if not valid:
        issues.append("UNKNOWN: no finite validation AP observations")
    pairs = [(r["epoch"], r["step"]) for r in rows]
    from collections import Counter
    duplicates = sorted((p for p, count in Counter(pairs).items() if count > 1), key=str)
    if duplicates:
        issues.append("AMBIGUOUS: duplicate epoch/step observations retained")
    # Preserve file order and all tied maxima. There is no invented smoothing,
    # early-peak threshold, or assertion of overfitting from an epoch number.
    return {"rows": rows, "best_valid_ap": best, "best_rows": best_rows,
            "duplicate_epoch_steps": duplicates, "nonfinite_ap_rows": len(rows) - len(valid),
            "last_recorded_row": rows[-1] if rows else None}


def inspect_checkpoint(path, enabled, issues):
    if not path.exists() or path.is_symlink():
        issues.append("UNKNOWN: local best.ckpt absent")
        return {"status": "UNKNOWN", "reason": "best.ckpt absent"}
    result = {"path": str(path), "status": "UNKNOWN", "sha256": sha256(path),
              "size_bytes": path.stat().st_size}
    if not enabled:
        result["reason"] = "metadata inspection not requested; use --inspect-checkpoints for trusted local files"
        issues.append("UNKNOWN: checkpoint epoch/step/contract not inspected")
        return result
    try:
        import torch
        payload = torch.load(path, map_location="cpu", weights_only=False)
        if not isinstance(payload, dict):
            raise ValueError("checkpoint is not a mapping")
        result.update(status="READ", epoch=json_native(payload.get("epoch")),
                      global_step=json_native(payload.get("global_step")),
                      sequence_contract=json_native(payload.get("sequence_contract")),
                      input_contract=json_native(payload.get("fraud_input_contract")))
        del payload
        if result["epoch"] is None or result["global_step"] is None:
            issues.append("UNKNOWN: checkpoint epoch or global_step absent")
    except Exception as exc:
        result["reason"] = f"{type(exc).__name__}: {exc}"
        issues.append("UNKNOWN: checkpoint inspection: " + result["reason"])
    return result


def checkpoint_checks(checkpoint, curve, contract, metadata, issues):
    checks = {"selection": "UNKNOWN", "scoring_hash": "UNKNOWN", "sequence_contract": "UNKNOWN"}
    epoch, step = finite(checkpoint.get("epoch")), finite(checkpoint.get("global_step"))
    if epoch is not None and step is not None:
        matches = [r for r in curve["rows"] if r["epoch"] == epoch and r["step"] == step]
        checks["matched_metric_rows"] = matches
        if len(matches) != 1:
            issues.append(f"AMBIGUOUS: checkpoint epoch/step matches {len(matches)} metric rows")
        elif matches[0]["valid_ap"] is not None and curve["best_valid_ap"] is not None:
            checks["selection"] = "MATCH" if matches[0]["valid_ap"] == curve["best_valid_ap"] else "MISMATCH"
            if checks["selection"] == "MISMATCH":
                issues.append("MISMATCH: saved checkpoint AP is below maximum finite validation AP")
            elif curve.get("nonfinite_ap_rows"):
                checks["selection"] = "UNKNOWN"
    recorded = []
    for source, value in metadata.items():
        if isinstance(value, dict) and value.get("checkpoint_sha256"):
            recorded.append({"source": source, "sha256": value["checkpoint_sha256"]})
    checks["recorded_checkpoint_hashes"] = recorded
    if recorded and checkpoint.get("sha256"):
        mismatches = [r for r in recorded if r["sha256"] != checkpoint["sha256"]]
        checks["scoring_hash"] = "MISMATCH" if mismatches else "MATCH"
        if mismatches:
            issues.append("MISMATCH: recorded checkpoint hash differs from local best.ckpt: " +
                          ", ".join(r["source"] for r in mismatches))
    else:
        issues.append("UNKNOWN: no recorded checkpoint hash/local file pair for scoring linkage")
    seq = checkpoint.get("sequence_contract")
    train = contract.get("train") or {}
    if isinstance(seq, dict):
        differences = []
        for ck_key, cfg_key in (("history_len", "sequence.history_len"),
                                ("attention_mask", "sequence.attention_mask"),
                                ("predict_every_transaction", "sequence.predict_every_transaction")):
            if ck_key in seq and cfg_key in train and seq[ck_key] != train[cfg_key]:
                differences.append(cfg_key)
        architecture = seq.get("architecture")
        if isinstance(architecture, dict):
            for ck_key, cfg_key in (("embed_dim", "model.input_embed_dim"),
                                    ("num_heads", "model.num_heads"),
                                    ("num_attn_blocks", "model.num_attn_blocks"),
                                    ("num_txn_blocks", "model.num_txn_blocks"),
                                    ("num_seq_blocks", "model.num_seq_blocks"),
                                    ("attn_dropout", "model.attn_dropout"),
                                    ("ff_dropout", "model.ff_dropout"),
                                    ("continuous_embedding", "model.continuous_embedding"),
                                    ("num_frequencies", "model.num_frequencies")):
                if ck_key in architecture and cfg_key in train and architecture[ck_key] != train[cfg_key]:
                    differences.append(cfg_key)
        checks["sequence_contract"] = "MISMATCH" if differences else "PARTIAL"
        checks["sequence_contract_differences"] = differences
        if differences:
            issues.append("MISMATCH: checkpoint/config sequence contract: " + ", ".join(differences))
        issues.append("UNKNOWN: frozen input/artifact identity requires original native input contract evidence; partial config comparison only")
    elif checkpoint.get("input_contract") is None:
        issues.append("UNKNOWN: checkpoint sequence/input contract absent or uninspected")
    return checks


def analyze_run(run, root, inspect):
    issues = []
    curve = read_curve(run / "training_metrics.csv", issues)
    train = load_config(run / "resolved_train.yaml", issues)
    score = load_config(run / "resolved_score.yaml", issues)
    contract = config_contract(train, score, issues)
    metadata = {}
    for path in sorted(run.glob("*.json")):
        if path.is_symlink() or excluded_reason(path.relative_to(root)):
            continue
        try:
            metadata[path.name] = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            issues.append(f"UNKNOWN: {path.name}: {type(exc).__name__}: {exc}")
    # The native runner stores checkpoint epoch/step/AP in the attempt-level
    # results.csv. Never let a later sweep-level results.csv replace this row.
    results = run.parent / "results.csv"
    if results.is_file() and not results.is_symlink():
        try:
            with results.open(newline="", encoding="utf-8-sig") as stream:
                records = [r for r in csv.DictReader(stream) if r.get("run_name") == run.name]
            for index, record in enumerate(records):
                metadata[f"../results.csv:row{index}"] = record
        except Exception as exc:
            issues.append(f"UNKNOWN: attempt results.csv: {type(exc).__name__}: {exc}")
    checkpoint = inspect_checkpoint(run / "best.ckpt", inspect, issues)
    checks = checkpoint_checks(checkpoint, curve, contract, metadata, issues)
    for source, value in metadata.items():
        if not isinstance(value, dict):
            continue
        for kind in ("train", "score"):
            recorded = value.get(f"resolved_{kind}_sha256")
            path = run / f"resolved_{kind}.yaml"
            if recorded and path.is_file() and not path.is_symlink() and sha256(path) != recorded:
                issues.append(f"MISMATCH: {source} resolved_{kind}_sha256 differs from native config")
        for recorded_key, checkpoint_key in (("checkpoint_epoch", "epoch"), ("checkpoint_step", "global_step")):
            recorded, actual = finite(value.get(recorded_key)), finite(checkpoint.get(checkpoint_key))
            if recorded is not None and actual is not None and recorded != actual:
                issues.append(f"MISMATCH: {source} {recorded_key} differs from local checkpoint")
        for rc_key in ("train_rc", "score_rc", "returncode", "return_code"):
            rc = finite(value.get(rc_key))
            if rc is not None and rc != 0:
                issues.append(f"NATIVE FAILURE: {source} {rc_key}={rc}")
        if value.get("error"):
            issues.append(f"NATIVE ERROR: {source}: {value['error']}")
    cfg = contract.get("train") or {}
    family = "REF" if "ref_single" in run.relative_to(root).parts else (
        "A" if "arch_a_flat" in run.relative_to(root).parts else "B")
    return {"path": run.relative_to(root).as_posix(), "family": family,
            "history_len": cfg.get("sequence.history_len", 0 if family == "REF" else None),
            "curve": curve, "config": contract, "checkpoint": checkpoint,
            "checks": checks, "native_metadata": metadata, "issues": issues}


def comparisons(runs):
    """All H5/control pairs, with no attempt promotion or pooled seed claim."""
    result = []
    for h5 in runs:
        if h5["history_len"] != 5:
            continue
        for control in runs:
            if not (control["family"] == "REF" or
                    (control["family"] == h5["family"] and control["history_len"] == 0)):
                continue
            left, right = h5["curve"]["best_valid_ap"], control["curve"]["best_valid_ap"]
            a, b = h5["config"].get("train") or {}, control["config"].get("train") or {}
            keys = sorted(k for k in set(a) | set(b)
                          if k.startswith(("data.", "artifacts.", "predictors.", "preprocess.", "datetime."))
                          or k == "training.seed"
                          or (control["family"] == h5["family"] and k == "sequence.history_time_order"))
            differences = [k for k in keys if k not in a or k not in b or a[k] != b[k]]
            required = ("data.train_base", "data.train_start", "data.train_end", "data.val_base",
                        "data.val_start", "data.val_end", "training.seed", "artifacts.base",
                        "artifacts.version", "predictors.csv_path", "predictors.version")
            missing = [k for k in required if k not in a or k not in b]
            result.append({"h5": h5["path"], "control": control["path"],
                           "max_valid_ap_delta": left - right if left is not None and right is not None else None,
                           "recorded_cohort_config": "MISMATCH" if differences else ("UNKNOWN" if missing else "MATCH"),
                           "different_fields": differences, "missing_fields": missing})
    return result


def summary_text(report):
    lines = ["# H5 native V1 evidence", "", "Every discovered attempt is retained; none is selected as official.",
             "Epoch 0 is the first training epoch. An early AP peak alone does not establish overfitting.",
             "Validation AP comparisons below are descriptive, not evidence of superiority or a new run gate.",
             "Checkpoints/predictions stay on the pod (OQ-24). No training or bank data access is performed.",
             "", "| Attempt/run | Model | History | Max finite validation AP | Peak epoch(s) | Checkpoint selection | Config |",
             "| --- | --- | --- | --- | --- | --- | --- |"]
    for run in report["runs"]:
        peaks = ", ".join(str(r["epoch"]) for r in run["curve"]["best_rows"]) or "unknown"
        lines.append(f"| {run['path']} | {run['family']} | {run['history_len']} | "
                     f"{run['curve']['best_valid_ap']} | {peaks} | {run['checks']['selection']} | {run['config']['status']} |")
    if not report["runs"]:
        lines += ["", "UNKNOWN: no native run evidence found in the configured V1 directories."]
    lines += ["", "## H5 versus H0/REF", "", "All cross-attempt pairs are descriptive; matching recorded settings does not prove cohort or artifact identity.",
              "", "| H5 | Control | Difference in max validation AP | Recorded cohort config | Config details |",
              "| --- | --- | --- | --- | --- |"]
    for pair in report.get("comparisons", []):
        details = []
        if pair["different_fields"]:
            details.append("different: " + ", ".join(pair["different_fields"]))
        if pair["missing_fields"]:
            details.append("missing: " + ", ".join(pair["missing_fields"]))
        lines.append(f"| {pair['h5']} | {pair['control']} | {pair['max_valid_ap_delta']} | {pair['recorded_cohort_config']} | {'; '.join(details)} |")
    if not report.get("comparisons"):
        lines += ["", "UNKNOWN: no H5/control pair with identifiable history settings."]
    for run in report["runs"]:
        lines += ["", f"## {run['path']}", "", "Curve (all rows, in recorded order):",
                  "", "| Epoch | Step | Train loss | Valid loss | Valid AP | Valid AUROC |",
                  "| --- | --- | --- | --- | --- | --- |"]
        for row in run["curve"]["rows"]:
            lines.append("| " + " | ".join(str(row.get(k)) for k in METRIC_COLUMNS) + " |")
        lines += ["", f"Checkpoint hash linkage: {run['checks']['scoring_hash']}; "
                  f"sequence contract: {run['checks']['sequence_contract']}.", ""]
        lines += ["- " + issue for issue in run["issues"]]
    lines += ["", "## Collection", "", f"Copied {len(report['files'])} diagnostic files without size cutoffs.",
              "All copies and hashes are listed in evidence.json; native errors and logs are included even for failed runs."]
    lines += ["", *["- " + error for error in report["errors"]]]
    return "\n".join(lines) + "\n"


def collect(root, output=None, inspect=False):
    root = Path(root).resolve()
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    output = Path(output).resolve() if output else root / "runs/returns/v2_006" / f"h5_{stamp}_{uuid.uuid4().hex[:8]}"
    if output.exists() or output.with_name(output.name + ".zip").exists():
        raise FileExistsError(f"refusing to overwrite existing evidence: {output}")
    # Do not allow the return to become input during recursive discovery.
    for rel in SEARCH_ROOTS:
        if output == root / rel or (root / rel) in output.parents:
            raise ValueError("output must be outside native evidence directories")
    output.mkdir(parents=True)
    report = {"schema_version": 1, "captured_utc": stamp, "root": str(root),
              "inspect_checkpoints": inspect, "runs": [], "files": [], "excluded": [], "errors": []}
    run_paths = set()
    try:
        for rel in SEARCH_ROOTS:
            base = root / rel
            if not base.is_dir() or base.is_symlink():
                report["errors"].append(f"UNKNOWN: missing/native directory unavailable: {rel}")
                continue
            for folder, dirs, names in os.walk(base, followlinks=False):
                dirs[:] = sorted(d for d in dirs if d not in CACHE_NAMES and d not in {"data", "raw", "predictions"}
                                 and d.lower() not in SECRET_NAMES
                                 and not (Path(folder) / d).is_symlink())
                folder = Path(folder)
                if MARKERS.intersection(names) or any(
                    ("train" in name.lower() or "score" in name.lower())
                    and Path(name).suffix.lower() in {".log", ".err", ".out"} for name in names
                ):
                    run_paths.add(folder)
                for name in sorted(names):
                    path = folder / name
                    relative = path.relative_to(root)
                    reason = excluded_reason(relative)
                    if path.is_symlink():
                        reason = "symlink (not followed)"
                    if reason:
                        report["excluded"].append({"path": relative.as_posix(), "reason": reason})
                        continue
                    try:
                        destination = output / "native" / relative
                        destination.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copyfile(path, destination)
                        report["files"].append({"path": relative.as_posix(), "sha256": sha256(destination),
                                                "size_bytes": destination.stat().st_size})
                    except Exception as exc:
                        report["errors"].append(f"{relative}: {type(exc).__name__}: {exc}")
        for run in sorted(run_paths):
            try:
                report["runs"].append(analyze_run(run, root, inspect))
            except Exception:
                report["errors"].append(f"Run analysis failed: {run.relative_to(root)}\n{traceback.format_exc()}")
    except Exception:
        report["errors"].append("Collection failed:\n" + traceback.format_exc())
    finally:
        report["comparisons"] = comparisons(report["runs"])
        write_json(output / "evidence.json", report)
        (output / "summary.md").write_text(summary_text(report), encoding="utf-8")
        (output / "errors.log").write_text("\n".join(report["errors"]) + "\n", encoding="utf-8")
        zip_path = output.with_name(output.name + ".zip")
        with zipfile.ZipFile(zip_path, "x", zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(output.rglob("*")):
                if path.is_file():
                    archive.write(path, Path(output.name) / path.relative_to(output))
    return output, zip_path, report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--root", type=Path, default=Path.cwd(), help="installed project root (default: current directory)")
    parser.add_argument("--output", type=Path, help="new return directory; an adjacent .zip is also written")
    parser.add_argument("--inspect-checkpoints", action="store_true",
                        help="unpickle only your trusted locally produced best.ckpt files on CPU; export metadata only")
    args = parser.parse_args(argv)
    output, archive, report = collect(args.root, args.output, args.inspect_checkpoints)
    print(f"Summary: {output / 'summary.md'}\nEvidence: {output / 'evidence.json'}\nReturn ZIP: {archive}")
    print(f"{len(report['runs'])} native run directories; {len(report['errors'])} collection notices. "
          "UNKNOWN and MISMATCH details are in the summary; this reader does not gate training.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
