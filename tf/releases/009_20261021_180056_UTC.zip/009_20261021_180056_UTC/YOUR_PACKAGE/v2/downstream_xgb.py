"""L6 CPU downstream experiment: identical rows/budget; raw, score and embedding arms.

The fitting path sees DS_TRAIN only. FINAL loads a hash-pinned, selected consumer and
never calls fit. Export manifests must identify the very same actual encoder.
"""
import argparse
import hashlib
import json
import posixpath
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import yaml
from sklearn.compose import ColumnTransformer
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from xgboost import XGBClassifier  # imported here, not inside new_model, so a missing package fails before any data is read

from YOUR_PACKAGE.base.data.input_contracts import parse_required_timestamps
from YOUR_PACKAGE.scoring.temporal_eval import HISTORY_COL, _history_counts, _parse_timestamps

from YOUR_PACKAGE.v2.benchmark_v2 import (binary_labels, canonical_ids, depth_report, digest, duplicate_summary, exact_unique,
                                  exposure_record, file_pin, finite_scores, metrics, open_file, paired_interval,
                                  read_json, read_table, verify_freeze, write_json)

from YOUR_PACKAGE.v2.analysis.embedding_diagnostics import embedding_diagnostics

ARM_PARTS = {"raw": (False, False), "raw_score": (True, False),
             "raw_embedding": (False, True), "raw_score_embedding": (True, True)}
FROZEN_ARM_CANDIDATES = ("raw_score_embedding", "raw_score")
DEFAULT_BUDGET = dict(n_estimators=200, max_depth=4, learning_rate=.05, min_child_weight=1,
                      reg_lambda=1., reg_alpha=0.)


def config_hash(cfg):
    return hashlib.sha256(json.dumps(cfg, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def identity(manifest):
    required = ("checkpoint_sha256", "artifacts", "validation_policy", "max_window_rows", "extraction")
    if any(k not in manifest for k in required):
        raise ValueError("Export manifest is missing encoder/policy identity")
    return {k: manifest[k] for k in required}


def encoder_pin_identity(contract, filesystem=None):
    """Bind consumer training to the concrete model/config/preprocessing files used."""
    for pin in (contract.get("checkpoint"), contract.get("config")):
        file_pin(pin, filesystem)
    artifacts = contract.get("artifacts", {})
    if artifacts.get("version") is None or not artifacts.get("files") or "scoring_policy" not in contract:
        raise ValueError("encoder_contract needs artifact version/files and scoring_policy")
    for pin in artifacts["files"]:
        file_pin(pin, filesystem)
    return {"checkpoint_sha256": contract["checkpoint"]["sha256"], "config_sha256": contract["config"]["sha256"],
            "artifact_version": artifacts["version"], "artifact_sha256": sorted(p["sha256"] for p in artifacts["files"]),
            "scoring_policy": contract["scoring_policy"]}


def verify_export_inputs(manifest, contract, filesystem=None):
    """Connect native export configuration/artifact locations to verified selected inputs.

    Cohort ranges and eval batch sizes may differ; model/input definitions may not.
    """
    root = str(manifest["artifacts"]["base"]).rstrip("/") + "/" + str(manifest["artifacts"]["version"])
    def normalized(path):
        if "://" in str(path):
            scheme, rest = str(path).split("://", 1)
            return scheme + "://" + posixpath.normpath(rest)
        return str(Path(path).resolve())
    root = normalized(root)
    for pin in contract["artifacts"]["files"]:
        if not normalized(pin["path"]).startswith(root + "/"):
            raise ValueError("Pinned artifact file is outside the export's actual artifact base/version")
    artifact_manifest = read_json(root + "/manifest.json", filesystem)
    expected = {root + "/manifest.json", *[root + f"/feature__{name}.json" for name in artifact_manifest["features"]]}
    supplied = [normalized(pin["path"]) for pin in contract["artifacts"]["files"]]
    if set(supplied) != expected or len(supplied) != len(expected):
        raise ValueError("Artifact pins must cover exactly manifest.json and every model-read feature file")
    file_pin({"path": manifest.get("config"), "sha256": manifest.get("config_sha256", "")}, filesystem)
    with open_file(manifest["config"], "r", filesystem) as f:
        exported = yaml.safe_load(f)
    with open_file(contract["config"]["path"], "r", filesystem) as f:
        selected = yaml.safe_load(f)
    if not isinstance(exported, dict) or not isinstance(selected, dict):
        raise ValueError("Selected and export configurations must be mappings")
    for section in ("model", "sequence", "predictors", "preprocess", "datetime"):
        if exported.get(section) != selected.get(section):
            raise ValueError(f"Export differs from selected encoder configuration: {section}")
    for field in ("account_col", "order_col", "target_col", "positive_label", "id_cols", "tie_break_col"):
        if exported.get("data", {}).get(field) != selected.get("data", {}).get(field):
            raise ValueError(f"Export differs from selected encoder input definition: {field}")
    if exported.get("artifacts") != selected.get("artifacts") or exported.get("artifacts") != manifest["artifacts"]:
        raise ValueError("Export artifact identity disagrees with its actual/selected config")


def full_history_depth(raw, key, account, time, depth):
    """Count strictly earlier exact-timestamp raw rows before any target/month filter.

    This is available history, not capped model-window width or dataframe row order.
    Input files must be the population's complete account buckets (as L2 records).
    """
    raw = raw.copy()
    if depth in raw:
        values = pd.to_numeric(raw[depth], errors="raise").to_numpy()
        if not np.isfinite(values).all() or (values < 0).any() or (values != np.floor(values)).any():
            raise ValueError("Supplied history depth must be nonnegative integer counts")
        return raw
    raw[depth] = _history_counts(raw, key, account, time)[HISTORY_COL].to_numpy()
    return raw


def row_keys(frame, cfg):
    return set(map(tuple, frame[[cfg["key"], cfg["account"]]].astype(str).to_numpy()))


def needed_columns(cfg, filesystem=None):
    """The raw columns the consumer reads: keys, label, time, depth and every predictor's source column. The
    bank files hold about 224 columns; reading only these keeps DS_TRAIN in memory."""
    with open_file(cfg["predictors"], "rb", filesystem) as f:
        definitions = pd.read_csv(f)
    sources = [str(row.source).split(":", 1)[1] if str(row.source).startswith("derived:") else row.feature
               for row in definitions.itertuples()]
    return list(dict.fromkeys([cfg["key"], cfg["account"], cfg["label"], cfg["time"], cfg["depth"], *sources]))


def load_population(spec, cfg, name, audit, filesystem=None):
    """Join by actual keys, filter only targets AFTER their history/export was computed."""
    key, account = cfg["key"], cfg["account"]
    keys = [key, account]
    raw = read_table(spec["raw"], filesystem, source_column="_consumer_raw_file",
                     columns=needed_columns(cfg, filesystem) if "predictors" in cfg else None)
    if raw.groupby(account, dropna=False)["_consumer_raw_file"].nunique().gt(1).any():
        raise ValueError("Account appears in multiple raw files; inventory must resolve file-contained history before use")
    raw = raw.drop(columns="_consumer_raw_file")
    # The bank stores the account id as float64 (e.g. 12345678.0) and the exporter copies that dtype: canonicalise
    # both sides losslessly (whole-number floats become integers) instead of refusing floats.
    kinds = {}
    for k in keys:
        raw[k], kinds[k] = canonical_ids(raw[k], f"{name} raw {k}")
    raw = exact_unique(raw, keys, name + "_raw", audit)
    raw = full_history_depth(raw, key, account, cfg["time"], cfg["depth"])
    folder = spec["export"].rstrip("/")
    manifest = read_json(folder + "/manifest.json", filesystem)
    validation = read_json(folder + "/validation.json", filesystem)
    if validation.get("passed") is not True or manifest.get("labels_read") is not False:
        raise ValueError("Consumer requires a passing label-free embedding export")
    parquet = folder + "/embeddings.parquet"
    if digest(parquet, filesystem) != manifest.get("embeddings_sha256"):
        raise ValueError("Export bytes do not match its manifest")
    emb = read_table(parquet, filesystem)
    for k in keys:
        emb[k], kind = canonical_ids(emb[k], f"{name} export {k}")
        if kind != kinds[k]:
            raise ValueError(f"{name}: {k} representation differs between the raw rows ({kinds[k]}) and the export ({kind})")
    emb = exact_unique(emb, keys, name + "_export", audit)
    width = int(validation["embedding_width"])
    cols = [f"e_{i}" for i in range(width)]
    if set(c for c in emb if c.startswith("e_")) != set(cols) or width != validation["expected_width"]:
        raise ValueError("Embedding columns do not match the actual export width")
    if not np.isfinite(emb[cols].to_numpy(dtype=float)).all():
        raise ValueError("Nonfinite embedding values")
    finite_scores(emb["score"])
    reserved = {"score", "window_rows", *cols} & set(raw)
    if reserved:
        raise ValueError(f"Raw rows contain reserved export columns: {sorted(reserved)}")
    if cfg["time"] not in raw:
        raise ValueError("Raw target timestamps are required")
    times = _parse_timestamps(raw[cfg["time"]], "raw target month selection")
    if name in ("select", "final"):
        start, end = pd.Timestamp(spec["target_start"]), pd.Timestamp(spec["target_end"])
        if start.month != 6 or start.day != 1 or end != start + pd.offsets.MonthBegin(1):
            raise ValueError("DS_SELECT/FINAL must explicitly select one complete June [June 1, July 1)")
        raw = raw[(times >= start) & (times < end)].copy()
    elif "target_start" in spec or "target_end" in spec:
        if not ("target_start" in spec and "target_end" in spec):
            raise ValueError("Both target_start and target_end are required")
        raw = raw[(times >= pd.Timestamp(spec["target_start"])) & (times < pd.Timestamp(spec["target_end"]))].copy()
    frame = raw.merge(emb[[*keys, "score", "window_rows", *cols]], on=keys, how="left", validate="one_to_one", indicator=True)
    if frame.empty or not frame["_merge"].eq("both").all():
        raise ValueError(f"{name}: export must cover every selected target")
    frame = frame.drop(columns="_merge")
    binary_labels(frame[cfg["label"]])
    if cfg["depth"] not in frame:
        raise ValueError("Supply actual full-history depth from inventory; window_rows is not its substitute")
    return frame, manifest, cols


def raw_features(frame, predictor_path, version, filesystem=None):
    with open_file(predictor_path, "rb", filesystem) as f:
        definitions = pd.read_csv(f)
    definitions = definitions[definitions["version"] <= version]
    definitions = definitions[definitions["feature"] != "month"].copy()
    if definitions.empty or definitions["feature"].duplicated().any():
        raise ValueError("Predictor definitions must name each feature once")
    output = pd.DataFrame(index=frame.index)
    numeric, categorical = [], []
    for row in definitions.itertuples():
        name, source = row.feature, str(row.source)
        if source.startswith("derived:"):
            timestamp = parse_required_timestamps(frame[source.split(":", 1)[1]], source)
            attrs = {"day": "day", "hour": "hour", "day_of_week": "dayofweek"}
            if name not in attrs:
                raise ValueError(f"Unimplemented derived predictor {name}; do not silently substitute")
            values = getattr(timestamp.dt, attrs[name])
        else:
            values = frame[name]
        if row.type == "continuous":
            output[name] = pd.to_numeric(values, errors="raise").astype(float)
            if np.isinf(output[name]).any():
                raise ValueError(f"Infinite raw predictor {name}")
            numeric.append(name)
        elif row.type == "categorical":
            # Deliberate tagged strings distinguish actual categories from missingness.
            output[name] = values.map(lambda x: "missing:" if pd.isna(x) else "value:" + str(x))
            categorical.append(name)
        else:
            raise ValueError(f"Unknown predictor type {row.type}")
    return output, numeric, categorical


def arm_matrix(raw, score, embedding, arm):
    base = arm.split("_pca")[0]
    use_score, use_embedding = ARM_PARTS[base]
    parts = [raw]
    if use_score:
        parts.append(np.asarray(score).reshape(-1, 1))
    if use_embedding:
        parts.append(embedding)
    return np.column_stack([np.asarray(p, dtype=np.float32) for p in parts])  # XGBoost is float32 internally


def new_model(budget, seed):
    if set(budget) - set(DEFAULT_BUDGET):
        raise ValueError("Only fixed tree budget parameters are configurable; no subsampling/device/seed overrides")
    return XGBClassifier(**{**DEFAULT_BUDGET, **budget}, objective="binary:logistic", tree_method="hist",
                         device="cpu", n_jobs=1, random_state=seed, subsample=1., colsample_bytree=1.,
                         colsample_bylevel=1., colsample_bynode=1., eval_metric="logloss")


def report_predictions(frame, pred, cfg):
    y = binary_labels(frame[cfg["label"]])
    result = {"rows": len(frame), "scope": "Incremental value over our raw fields; not the incumbent feature set",
              "frozen_arm_candidates": list(FROZEN_ARM_CANDIDATES),
              "metrics": {arm: metrics(y, scores) for arm, scores in pred.items()}}
    if {"raw_score_embedding", "raw_score"} <= set(pred):
        primary = paired_interval(
            y, pred["raw_score_embedding"], pred["raw_score"], frame[cfg["account"]],
            cfg.get("bootstrap_draws", 1000), cfg.get("seed", 42))
        interval = primary["ci95"]
        if interval is not None and interval[0] > 0:
            primary["label"] = "resolved_improvement"
            primary["decision_note"] = "Arm 4 shows a resolved improvement over arm 2 on DS_SELECT."
        elif interval is not None and interval[1] < 0:
            primary["label"] = "resolved_degradation"
            primary["decision_note"] = "The vector is not helping the consumer on DS_SELECT; arm 2 is recommended."
        else:
            primary["label"] = "not_resolved"
            primary["decision_note"] = (
                "The benefit or harm remains unresolved; retaining arm 4 is provisional and does not "
                "demonstrate equivalence, no harm or added value from the vector.")
        result["primary_arm4_minus_arm2"] = primary
        result["recommended_arm"] = "raw_score" if primary["label"] == "resolved_degradation" else "raw_score_embedding"
    tagged = frame.assign(**{"prediction_" + k: v for k, v in pred.items()})
    result["depth"] = depth_report(tagged, cfg["label"], ["prediction_" + k for k in pred], cfg["depth"])
    # Conditional per-band intervals preserve the account sampling unit; no per-row iid intervals.
    if {"raw_score_embedding", "raw_score"} <= set(pred):
        d = frame[cfg["depth"]].to_numpy()
        for row, (lo, hi) in zip(result["depth"], ((0, 1), (1, 5), (5, 10), (10, 20), (20, np.inf))):
            keep = (d >= lo) & (d < hi)
            row["arm4_minus_arm2"] = paired_interval(y[keep], pred["raw_score_embedding"][keep],
                                                       pred["raw_score"][keep], frame.loc[keep, cfg["account"]],
                                                       cfg.get("bootstrap_draws", 1000), cfg.get("seed", 42))
    return result


def run(cfg, out, final=False, frozen_path=None, filesystem=None):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=False)
    audit = []
    completed, encoder_sha = False, None
    try:
        if final:
            frozen = verify_freeze(frozen_path, filesystem, require_downstream=True)
            arm = frozen["downstream"]["arm"]
            if arm not in FROZEN_ARM_CANDIDATES:
                raise ValueError("Frozen arm must be raw_score_embedding or raw_score")
            # Only load the locally produced bundle whose bytes have just been hash verified.
            with open_file(frozen["downstream"]["bundle"]["path"], "rb", filesystem) as f:
                bundle = joblib.load(f)
            if bundle["encoder"]["checkpoint_sha256"] != frozen["encoder"]["checkpoint"]["sha256"]:
                raise ValueError("Frozen consumer was not fitted with the selected final encoder")
            if encoder_pin_identity(frozen["encoder"], filesystem) != bundle["encoder_pins"]:
                raise ValueError("Frozen configuration/artifact pins differ from the consumer's actual training inputs")
            frame, manifest, cols = load_population(cfg["final"], cfg, "final", audit, filesystem)
            encoder_sha = manifest.get("checkpoint_sha256")
            verify_export_inputs(manifest, frozen["encoder"], filesystem)
            if identity(manifest) != bundle["encoder"] or cols != bundle["embedding_columns"]:
                raise ValueError("FINAL exports do not use the fitted consumer's actual encoder/policy")
            if manifest["validation_policy"] != frozen["encoder"]["scoring_policy"]:
                raise ValueError("Frozen scoring policy disagrees with the actual export")
            for field in ("key", "account", "label", "time", "depth"):
                if cfg[field] != bundle["config"][field]:
                    raise ValueError(f"FINAL schema differs from fitted consumer: {field}")
            if row_keys(frame, cfg) & bundle["development_ids"] or set(frame[cfg["account"]]) & bundle["development_accounts"]:
                raise ValueError("FINAL overlaps DS_TRAIN or DS_SELECT")
            if digest(cfg["predictors"], filesystem) != bundle["predictors_sha256"] or cfg["predictor_version"] != bundle["config"]["predictor_version"]:
                raise ValueError("FINAL predictor definitions differ from the fitted consumer")
            raw, _, _ = raw_features(frame, cfg["predictors"], cfg["predictor_version"], filesystem)
            x = bundle["raw_transform"].transform(raw).astype(np.float32, copy=False)
            e = bundle["embedding_scaler"].transform(frame[cols]).astype(np.float32, copy=False)
            if arm not in bundle["models"]:
                raise ValueError("Frozen arm is absent from the fitted consumer")
            scores = bundle["models"][arm].predict_proba(arm_matrix(x, frame["score"], e, arm))[:, 1]
            pred = {arm: scores}
            report = report_predictions(frame, pred, cfg)
            report.update(mode="FINAL", selected_arm=arm, fit_called=False, freeze_sha256=digest(frozen_path, filesystem))
            report["embedding_diagnostics"] = {"fit_population": "DS_TRAIN", "FINAL": embedding_diagnostics(
                frame, cols, bundle["embedding_scaler"], bundle["pcas"], {"ft": frame["score"]})}
        else:
            pins = encoder_pin_identity(cfg["encoder_contract"], filesystem)
            train, train_manifest, cols = load_population(cfg["train"], cfg, "train", audit, filesystem)
            frame, manifest, select_cols = load_population(cfg["select"], cfg, "select", audit, filesystem)
            encoder_sha = manifest.get("checkpoint_sha256")
            verify_export_inputs(train_manifest, cfg["encoder_contract"], filesystem)
            verify_export_inputs(manifest, cfg["encoder_contract"], filesystem)
            if identity(train_manifest) != identity(manifest) or cols != select_cols:
                raise ValueError("DS_TRAIN and DS_SELECT must use the identical encoder/policy/embedding width")
            if (pins["checkpoint_sha256"] != manifest["checkpoint_sha256"]
                    or pins["scoring_policy"] != manifest["validation_policy"]
                    or str(pins["artifact_version"]) != str(manifest["artifacts"]["version"])):
                raise ValueError("Actual encoder export does not match encoder_contract")
            if set(train[cfg["account"]]) & set(frame[cfg["account"]]) or row_keys(train, cfg) & row_keys(frame, cfg):
                raise ValueError("DS_TRAIN and DS_SELECT must have disjoint accounts and transaction IDs")
            y = binary_labels(train[cfg["label"]])
            if len(np.unique(y)) != 2:
                raise ValueError("DS_TRAIN needs both classes")
            train_raw, num, cat = raw_features(train, cfg["predictors"], cfg["predictor_version"], filesystem)
            select_raw, _, _ = raw_features(frame, cfg["predictors"], cfg["predictor_version"], filesystem)
            transforms = []
            if num:
                transforms.append(("numeric", Pipeline([("imputer", SimpleImputer(strategy="median", keep_empty_features=True)),
                                                         ("scaler", StandardScaler())]), num))
            if cat:
                transforms.append(("categorical", OneHotEncoder(handle_unknown="ignore", sparse_output=False, dtype=np.float32), cat))
            raw_transform = ColumnTransformer(transforms, remainder="drop", sparse_threshold=0)
            # float32 design matrices: XGBoost converts to float32 anyway, so fits are unchanged and DS_TRAIN at
            # about 8.4M rows needs half the memory.
            xtrain = raw_transform.fit_transform(train_raw).astype(np.float32, copy=False)
            xselect = raw_transform.transform(select_raw).astype(np.float32, copy=False)
            scaler = StandardScaler().fit(train[cols])
            etrain = scaler.transform(train[cols]).astype(np.float32, copy=False)
            eselect = scaler.transform(frame[cols]).astype(np.float32, copy=False)
            pcas, skipped = {}, []
            for k in cfg.get("pca_components", [8, 16]):
                if k not in (8, 16):
                    raise ValueError("Only preregistered secondary PCA8/PCA16 are supported")
                if k > min(etrain.shape):
                    skipped.append({"pca": k, "reason": "exceeds actual embedding width or DS_TRAIN row count"})
                else:
                    pcas[k] = PCA(n_components=k, svd_solver="full").fit(etrain)
            models, pred = {}, {}
            for arm in [*ARM_PARTS, *[f"raw_score_embedding_pca{k}" for k in pcas]]:
                a, b = etrain, eselect
                if "_pca" in arm:
                    pca = pcas[int(arm.rsplit("_pca", 1)[1])]
                    a, b = pca.transform(a), pca.transform(b)
                models[arm] = new_model(cfg.get("budget", {}), cfg.get("seed", 42))
                models[arm].fit(arm_matrix(xtrain, train["score"], a, arm), y)
                pred[arm] = models[arm].predict_proba(arm_matrix(xselect, frame["score"], b, arm))[:, 1]
            repeat = new_model(cfg.get("budget", {}), cfg.get("seed", 42))
            repeat.fit(arm_matrix(xtrain, train["score"], etrain, "raw_score"), y)
            repeated = repeat.predict_proba(arm_matrix(xselect, frame["score"], eselect, "raw_score"))[:, 1]
            if not np.array_equal(repeated, pred["raw_score"]):
                raise ValueError("Fixed-seed CPU consumer failed exact repeatability; inspect before interpreting")
            report = report_predictions(frame, pred, cfg)
            report.update(mode="DS_SELECT", repeated_arm="raw_score", repeat_identical=True, secondary_pca_skipped=skipped,
                          encoder=identity(manifest), embedding_width=len(cols), fit_population="DS_TRAIN only",
                          raw_features=list(train_raw), budget={**DEFAULT_BUDGET, **cfg.get("budget", {})})
            report["embedding_diagnostics"] = {"fit_population": "DS_TRAIN",
                "DS_TRAIN": embedding_diagnostics(train, cols, scaler, pcas, {"ft": train["score"]}),
                "DS_SELECT": embedding_diagnostics(frame, cols, scaler, pcas, {"ft": frame["score"]})}
            bundle = dict(config=cfg, config_sha256=config_hash(cfg), encoder=identity(manifest), fit_population="DS_TRAIN",
                          encoder_pins=pins,
                          embedding_columns=cols, raw_transform=raw_transform, embedding_scaler=scaler,
                          pcas=pcas, models=models, predictors_sha256=digest(cfg["predictors"], filesystem),
                          development_ids=row_keys(train, cfg) | row_keys(frame, cfg),
                          development_accounts=set(train[cfg["account"]]) | set(frame[cfg["account"]]))
            if encoder_pin_identity(cfg["encoder_contract"], filesystem) != pins:
                raise ValueError("Encoder contract files changed during consumer fitting")
            joblib.dump(bundle, out / "consumer.joblib")
            report["consumer_sha256"] = digest(out / "consumer.joblib")
        kept = frame[[cfg["key"], cfg["account"], cfg["label"], cfg["depth"]]].copy()
        for name, scores in pred.items():
            kept[name] = scores
        kept.to_parquet(out / "predictions.parquet", index=False)
        report["duplicates"] = duplicate_summary(audit)
        write_json(out / "report.json", report)
        completed = True
        return report
    finally:
        pd.DataFrame(audit, columns=["source", "id", "copies", "exact", "conflicting_columns"]).to_csv(out / "duplicate_audit.csv", index=False)
        write_json(out / "duplicate_summary.json", duplicate_summary(audit))
        roles = ("final",) if final else ("train", "select")
        freeze_sha = None
        if final and frozen_path:
            try:
                freeze_sha = digest(frozen_path, filesystem)
            except Exception:  # noqa: BLE001 - the record must not mask the run's own error
                freeze_sha = None
        write_json(out / "exposure.json", exposure_record(
            "FINAL" if final else "DS_TRAIN+DS_SELECT", "final_evaluation" if final else "downstream_selection",
            {"raw": {r: cfg[r]["raw"] for r in roles if r in cfg}, "export": {r: cfg[r]["export"] for r in roles if r in cfg}},
            completed, labels_read=True, encoder_checkpoint_sha256=encoder_sha, freeze_sha256=freeze_sha))


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--final", action="store_true")
    p.add_argument("--frozen")
    args = p.parse_args(argv)
    cfg = read_json(args.config)
    fs = None
    if cfg.get("s3_cred_path"):
        from YOUR_PACKAGE.v2.storage import thin_read_filesystem
        fs = thin_read_filesystem(cfg["s3_cred_path"])
    run(cfg, args.out, args.final, args.frozen, fs)


if __name__ == "__main__":
    main()
