"""Account-paired V2 comparisons, with full-file history before target-date selection.

The five-fit architecture rule uses C05 - mean(AP(B05), AP(B05r)), not an
average prediction. Its H5 deployment nominee is C05 or B05 seed42. Intervals
describe account sampling conditional on fitted models; the separate training
noise screen is an explicit scenario policy, not a calibrated error guarantee.
See ANALYSIS.md for the run CSV, CLI and returned aggregate contract.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

from fraud.data.s3_utils import build_file_list
from YOUR_PACKAGE.v2.storage import thin_read_filesystem
from YOUR_PACKAGE.base.data.input_contracts import encode_binary_target
from YOUR_PACKAGE.scoring import temporal_eval
from YOUR_PACKAGE.scoring._prediction_utils import prediction_path, validate_ids
from YOUR_PACKAGE.v2.scripts.select_splits import EXPOSURES
from YOUR_PACKAGE.v2.analysis.business_metrics import DEPTH_BANDS, business_report, validate_amount_bins

SD_RUN_FLOOR = 0.013  # DECISIONS section 6

ROOT = Path(__file__).resolve().parents[3]
_spec = importlib.util.spec_from_file_location("_v1_paired_report", ROOT / "runbook/2026-10-07/paired_report.py")
v1 = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(v1)
ARCH_SEEDS = {"B05": 42, "B05r": 43, "C05": 42, "B20": 42, "C20": 42}


def defaults(**overrides):
    values = dict(id="fi_transaction_id", account="Nmap_account_reference_xid", order_col="transaction_dttm",
                  target="frd_tag", score_col="score", positive_label=1, draws=1000, seed=0,
                  target_start="2025-06-01", target_end="2025-07-01", history_lengths=[5, 20], exclude_col=None)
    values.update(overrides)
    return SimpleNamespace(**values)


def load_raw(files, fs, args):
    """Retain labels/times and count strict prior rows inside each entire raw file."""
    frames = []
    exclude_col = getattr(args, "exclude_col", None)
    for number, path in enumerate(files):
        columns = [args.id, args.account, args.order_col, args.target] + ([exclude_col] if exclude_col else [])
        amount_col = getattr(args, "amount_col", None)
        if amount_col:
            columns = list(dict.fromkeys([*columns, amount_col]))
            # Optional value metadata may be absent from older raw exports.
            from YOUR_PACKAGE.v2.benchmark_v2 import read_table
            raw = read_table([path], fs, columns=columns)
        else:
            raw = temporal_eval._read(path, fs, columns=columns)
        counted = temporal_eval._history_counts(raw, args.id, args.account, args.order_col)
        frame = pd.DataFrame({
            "_id": validate_ids(raw[args.id], "raw IDs", unique=False).to_numpy(),
            "_acct": validate_ids(raw[args.account], "raw accounts", unique=False).to_numpy(),
            "_history": counted[temporal_eval.HISTORY_COL].to_numpy(), "_file": number, "_source_file": str(path),
            "_time": temporal_eval._parse_timestamps(raw[args.order_col], "raw rows").to_numpy(),
            "_label": encode_binary_target(raw[args.target], args.positive_label, args.target),
        })
        if amount_col:
            frame["_amount"] = raw[amount_col].to_numpy() if amount_col in raw else np.nan
        if exclude_col:
            # PLAN step 8: FINAL is also read without advice rows. Such rows stay history (they are in the raw
            # file and in every window); they are only removed from the set of scored targets.
            if exclude_col not in raw.columns:
                raise ValueError(f"{path} has no column {exclude_col!r} to exclude rows by")
            values = raw[exclude_col]
            frame["_excluded"] = (values.notna() & values.map(lambda v: str(v).strip() != "" if not pd.isna(v) else False)).to_numpy()
        frames.append(frame)
    if not frames:
        raise ValueError("No raw files supplied")
    result = pd.concat(frames, ignore_index=True)
    if result.empty or result.duplicated(["_id", "_acct"]).any():
        raise ValueError("Raw cohort must be nonempty with unique composite IDs")
    if result.groupby("_acct", sort=False)["_file"].nunique().gt(1).any():
        raise ValueError("Accounts cross raw files; file-contained history contract is not satisfied")
    return result


def target_mask(raw, start=None, end=None):
    """Calendar window [start,end) on targets, after full-file history construction."""
    if start is not None and end is not None and pd.Timestamp(start) >= pd.Timestamp(end):
        raise ValueError("target_start must precede target_end")
    mask = np.ones(len(raw), dtype=bool)
    if start is not None:
        mask &= raw["_time"].ge(pd.Timestamp(start)).to_numpy()
    if end is not None:
        mask &= raw["_time"].lt(pd.Timestamp(end)).to_numpy()
    if not mask.any():
        raise ValueError("Target window is empty")
    return mask


def digest(path, fs=None):
    path = prediction_path(path)
    handle = fs.open(path.removeprefix("s3://"), "rb") if path.startswith("s3://") else open(path, "rb")
    h = hashlib.sha256()
    with handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_json(path, fs=None):
    path = prediction_path(path)
    handle = fs.open(path.removeprefix("s3://"), "r") if path.startswith("s3://") else open(path)
    with handle:
        return json.load(handle)


def load_models(table, raw, args, fs=None):
    """Require complete coverage and unchanged scorer receipts; no intersect-and-drop."""
    required = {"run", "seed", "prediction_path", "receipt_path"}
    if not required.issubset(table.columns) or table.empty:
        raise ValueError(f"Run CSV needs {sorted(required)} and at least one row")
    raw_keys = raw[["_id", "_acct"]].assign(_pos=np.arange(len(raw)))
    models = {}
    for row in table.to_dict("records"):
        name = str(row["run"])
        if not name.strip() or name in models:
            raise ValueError("Run names must be nonempty and unique")
        path = prediction_path(row["prediction_path"])
        receipt = read_json(row["receipt_path"], fs)
        if receipt.get("predictions_sha256") != digest(path, fs):
            raise ValueError(f"{name}: prediction SHA does not match the scorer receipt")
        if not receipt.get("checkpoint_sha256"):
            raise ValueError(f"{name}: scorer receipt lacks checkpoint identity")
        mapped = v1.map_run(path, fs, raw_keys, len(raw), args, name)
        bad = {key: value for key, value in mapped["counts"].items()
               if key not in ("rows", "frauds") and value}
        if bad or not mapped["cover"].all():
            raise ValueError(f"{name}: prediction/raw coverage mismatch {bad}, "
                             f"missing={int((~mapped['cover']).sum())}")
        if not np.array_equal(mapped["labels"], raw["_label"].to_numpy()):
            raise ValueError(f"{name}: prediction labels disagree with raw targets")
        if ((mapped["scores"] < 0) | (mapped["scores"] > 1)).any():
            raise ValueError(f"{name}: scores must be fraud probabilities in [0,1]")
        # Optional diagnostics from V2 scorer: align using the exact same composite key.
        pred = temporal_eval._read(path, fs)
        pred["_id"] = validate_ids(pred[args.id], f"{name} IDs", unique=False)
        pred["_acct"] = validate_ids(pred[args.account], f"{name} accounts", unique=False)
        extra = [c for c in ("window_rows", "window_natural_rows", "window_truncated") if c in pred]
        diagnostics = raw_keys.merge(pred[["_id", "_acct", *extra]], on=["_id", "_acct"],
                                     how="left", validate="one_to_one").sort_values("_pos")
        if "window_rows" in diagnostics:
            widths = diagnostics.window_rows.to_numpy(float)
            if not np.isfinite(widths).all() or (widths < 1).any() or (widths != np.floor(widths)).any():
                raise ValueError(f"{name}: invalid window_rows")
            if "window_natural_rows" in diagnostics:
                natural = diagnostics.window_natural_rows.to_numpy(float)
                if not np.isfinite(natural).all() or (natural < widths).any() or (natural != np.floor(natural)).any():
                    raise ValueError(f"{name}: invalid natural window sizes")
                if "window_truncated" in diagnostics and not np.array_equal(
                        diagnostics.window_truncated.to_numpy(), natural > widths):
                    raise ValueError(f"{name}: inconsistent truncation flag")
        mapped.update(seed=int(row["seed"]), receipt=receipt, diagnostics=diagnostics)
        models[name] = mapped
    return models


class Comparison:
    """Small adapter to V1's weighted AP/compare code, retaining its joint draws."""
    def __init__(self, raw, models, args):
        selected = target_mask(raw, args.target_start, args.target_end)
        if "_excluded" in raw.columns:
            selected &= ~raw["_excluded"].to_numpy()
            if not selected.any():
                raise ValueError("Every target is excluded")
        self.positions = np.flatnonzero(selected)
        self.raw = raw.iloc[self.positions].reset_index(drop=True)
        self.models, self.args = models, args
        self.y = self.raw._label.to_numpy(int)
        self.codes, self.mult = v1.draw_multiplicities(self.raw._acct.to_numpy(), args.draws, args.seed)
        self.lines = {"overall": np.ones(len(self.raw), dtype=bool)}
        for name, lo, hi in DEPTH_BANDS:
            self.lines[name] = self.raw._history.ge(lo).to_numpy() & (
                self.raw._history.lt(hi).to_numpy() if hi is not None else True)
        self.cache = {}

    def key(self, name):
        if name not in self.models:
            raise ValueError(f"Missing run {name}")
        return name, self.models[name]["seed"]

    def ap(self, key, line):
        if (key, line) not in self.cache:
            name, _ = key
            mask = self.lines[line]
            y = self.y[mask]
            scores = self.models[name]["scores"][self.positions][mask]
            point, draws = v1.line_aps(scores, y, self.codes[mask], self.mult)
            auc = float(roc_auc_score(y, scores)) if 0 < y.sum() < len(y) else float("nan")
            self.cache[key, line] = point, draws, auc
        return self.cache[key, line]

    def counts(self, line):
        mask = self.lines[line]
        y, accounts = self.y[mask], self.raw._acct.to_numpy()[mask]
        return {"rows": int(mask.sum()), "frauds": int(y.sum()), "accounts": int(pd.unique(accounts).size),
                "fraud_accounts": int(pd.unique(accounts[y == 1]).size)}

    def report(self, x, line="overall"):
        """One run's AP, AUROC and account-bootstrap interval on one depth line (the FINAL reading): no contrast."""
        point, draws, auc = self.ap(self.key(x[0]), line)
        return dict(ap=float(point), auroc=float(auc), draws_requested=len(draws), **v1.percentile_ci(draws), **self.counts(line),
                    inference="pointwise account sampling conditional on the fitted model; no seed-robust claim")

    def contrast(self, x, y, line="overall", sd_run=0.013):
        result, draws, _, _ = v1.compare(self, [self.key(k) for k in x], [self.key(k) for k in y], line)
        defined = draws[np.isfinite(draws)]
        sd_pair = float(defined.std(ddof=1)) if len(defined) >= 2 else float("nan")
        variance_factor = 1 / len(x) + 1 / len(y)
        threshold = 1.645 * np.sqrt(sd_pair ** 2 + variance_factor * sd_run ** 2)
        lo, hi = result["ci_low"], result["ci_high"]
        label = "resolved improvement" if lo > 0 else "resolved degradation" if hi < 0 else "not resolved"
        if not np.isfinite(result["difference"]) or not np.isfinite(lo):
            label = "undefined"
        scenario_label = ("undefined" if not np.isfinite(threshold) or not np.isfinite(result["difference"])
                          else "resolved improvement" if result["difference"] > threshold
                          else "resolved degradation" if result["difference"] < -threshold
                          else "not resolved")
        return dict(result, **self.counts(line), sd_pair=sd_pair, sd_run_scenario=sd_run,
                    variance_factor=variance_factor, scenario_threshold=float(threshold), label=label,
                    scenario_label=scenario_label,
                    inference="pointwise account sampling conditional on fitted models; no seed-robust claim")


def architecture_decision(comparison):
    """Predeclared asymmetric Rule A, then actual nominated checkpoints under Rule B."""
    for name, seed in ARCH_SEEDS.items():
        if comparison.key(name)[1] != seed:
            raise ValueError(f"{name} requires the predeclared seed {seed}")
    ap = {name: comparison.ap(comparison.key(name), "overall")[0] for name in ARCH_SEEDS}
    if not all(np.isfinite(list(ap.values()))):
        raise ValueError("Architecture selection requires two target classes")
    sd_run = max(0.013, abs(ap["B05"] - ap["B05r"]) / np.sqrt(2))
    c5 = comparison.contrast(["C05"], ["B05", "B05r"], sd_run=sd_run)
    c20 = comparison.contrast(["C20"], ["B20"], sd_run=sd_run)
    if not all(np.isfinite(c["scenario_threshold"]) for c in (c5, c20)):
        raise ValueError("Not enough defined bootstrap draws for architecture selection")
    h5 = "C05" if c5["difference"] > c5["scenario_threshold"] else "B05"
    h20 = "C20" if c20["difference"] > c20["scenario_threshold"] else "B20"
    # Stable tie rule: retain H5, the lower requested history. Never pick B05r.
    nominee = h20 if ap[h20] > ap[h5] else h5
    return {"sd_run_scenario": float(sd_run), "H5": h5, "H20": h20, "base_run": nominee,
            "base_checkpoint_sha256": comparison.models[nominee]["receipt"]["checkpoint_sha256"],
            "base_seed": comparison.models[nominee]["seed"], "rule_A_h5": c5, "rule_A_h20": c20,
            "rule_B_actual_nominees": comparison.contrast([h20], [h5], sd_run=sd_run),
            "tie_rule": "H5 on exact AP equality", "status": "provisional engineering selection",
            "qualification": "Rule B interval is descriptive after selection; neither rule is a calibrated overall 5% guarantee"}


def window_summary(model, comparison, line):
    d = model["diagnostics"].iloc[comparison.positions].loc[comparison.lines[line]]
    result = {"rows": len(d), "window_metrics_available": "window_rows" in d}
    if not len(d) or "window_rows" not in d:
        return result
    cap = model["receipt"].get("max_window_rows")
    for column in ("window_rows", "window_natural_rows"):
        if column in d:
            result[column] = {"mean": float(d[column].mean()), "p99": float(d[column].quantile(.99)),
                              "max": int(d[column].max())}
    result["share_at_cap"] = None if cap is None else float(d.window_rows.eq(cap).mean())
    result["share_truncated"] = (float((d.window_natural_rows > d.window_rows).mean())
                                  if "window_natural_rows" in d else None)
    return result


def clean_json(value):
    if isinstance(value, dict):
        return {str(k): clean_json(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean_json(v) for v in value]
    if isinstance(value, (float, np.floating)):
        return float(value) if np.isfinite(value) else None
    if isinstance(value, np.integer):
        return int(value)
    return value


def analyse(raw, models, args, contrasts=None):
    if args.draws < 2:
        raise ValueError("At least two bootstrap draws are required")
    comparison = Comparison(raw, models, args)
    architecture = contrasts is None
    if architecture and (getattr(args, "population", "SELECT") != "SELECT"
                         or args.target_start is None or args.target_end is None):
        raise ValueError("the five-fit architecture decision is defined on SELECT's June target window (DECISIONS "
                         "sections 3 and 7); pass --comparisons for any other population or window")
    decision = architecture_decision(comparison) if architecture else None
    # a contrast with an empty y side is a single run's reading (FINAL): its AP and interval per line, no screen
    needs_sd_run = architecture or any(sides.get("y") for sides in contrasts.values())
    if decision:
        sd_run = decision["sd_run_scenario"]
        sd_run_source = "max(0.013, |AP(B05) - AP(B05r)| / sqrt 2) measured on this SELECT pass"
    elif needs_sd_run:
        sd_run = getattr(args, "sd_run", None)
        if sd_run is None:
            raise ValueError("custom contrasts need sd_run: the SELECT architecture pass's sd_run_scenario "
                             "(--architecture-result) or an explicit --sd-run (DECISIONS section 6)")
        sd_run_source = getattr(args, "sd_run_source", "--sd-run")
    else:
        sd_run, sd_run_source = None, "not needed: single-run readings only"
    if needs_sd_run and (not np.isfinite(sd_run) or sd_run < SD_RUN_FLOOR):
        raise ValueError(f"sd_run must be finite and at least the {SD_RUN_FLOOR} floor (DECISIONS section 6)")
    if architecture:
        contrasts = {"C05_minus_B05_mean": {"x": ["C05"], "y": ["B05", "B05r"]},
                     "C05_minus_B05": {"x": ["C05"], "y": ["B05"]},
                     "C05_minus_B05r": {"x": ["C05"], "y": ["B05r"]},
                     "C20_minus_B20": {"x": ["C20"], "y": ["B20"]},
                     "B05r_minus_B05": {"x": ["B05r"], "y": ["B05"]}}
    results, business = {}, {}
    for name, sides in contrasts.items():
        x, y = list(sides.get("x") or []), list(sides.get("y") or [])
        if not x or len(set(x)) != len(x) or len(set(y)) != len(y):
            raise ValueError("Each contrast needs distinct run names and a nonempty x side")
        if not y:
            if len(x) != 1:
                raise ValueError(f"{name}: a single-run reading (empty y side) names exactly one run")
            results[name] = {line: comparison.report(x, line) for line in comparison.lines}
            if getattr(args, "population", None) == "FINAL":
                targets = comparison.raw
                business[name] = business_report(comparison.y, models[x[0]]["scores"][comparison.positions],
                    targets["_acct"], amounts=targets.get("_amount"),
                    row_keys=[json.dumps([str(a), str(i)]) for a, i in zip(targets["_acct"], targets["_id"])],
                    depth=targets["_history"], source_files=targets.get("_source_file", targets.get("_file")),
                    amount_bins=getattr(args, "amount_bins_artifact", None), draws=args.draws, seed=args.seed,
                    score_is_probability=True)
            continue
        if set(x) & set(y):
            raise ValueError("Contrast sides must be disjoint (variance factor assumes different fits)")
        results[name] = {line: comparison.contrast(x, y, line, sd_run) for line in comparison.lines}
    return clean_json({"target_start": args.target_start, "target_end": args.target_end,
                       "raw_rows_for_history": len(raw), "selected_rows": len(comparison.raw),
                       "excluded_targets": int((raw["_excluded"] & target_mask(raw, args.target_start, args.target_end)).sum())
                       if "_excluded" in raw.columns else 0, "exclude_col": getattr(args, "exclude_col", None),
                       "bootstrap_draws": args.draws, "bootstrap_seed": args.seed,
                       "sd_run_scenario": None if sd_run is None else float(sd_run), "sd_run_source": sd_run_source,
                       "contrasts": results, "architecture_decision": decision, "business_metrics": business,
                       "windows": {name: {line: window_summary(model, comparison, line) for line in comparison.lines}
                                   for name, model in models.items()},
                       "models": {name: {"seed": m["seed"], "scorer_receipt": m["receipt"]}
                                  for name, m in models.items()},
                       "limits": ["Depth is prior rows available in the file, not the chunk model's occupied seconds.",
                                  "Depth0 does not validate genuinely new accounts.",
                                  "Mean AP is a contrast statistic, not an ensemble or a deployable encoder.",
                                  "All intervals are pointwise account sampling; SELECT is development selection."]})


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--runs", required=True, help="CSV: run,seed,prediction_path,receipt_path")
    p.add_argument("--raw-base", required=True)
    p.add_argument("--file-start", type=int, required=True)
    p.add_argument("--file-end", type=int, required=True)
    p.add_argument("--out", required=True, help="new aggregate result directory")
    p.add_argument("--comparisons", help="JSON {name: {x:[run],y:[run]}}; absent selects the five-fit study")
    p.add_argument("--target-start", default="2025-06-01")
    p.add_argument("--target-end", default="2025-07-01")
    p.add_argument("--all-targets", action="store_true", help="predeclared full-period analysis, e.g. EPOCH_VAL")
    p.add_argument("--population", default="SELECT", choices=("SELECT", "EPOCH_VAL", "DS_SELECT", "DEV_OOT", "FINAL", "BENCH"))
    p.add_argument("--purpose", required=True, choices=EXPOSURES,
                   help="why this labelled population is read (population_roles_v2.yaml); goes into exposure.json")
    p.add_argument("--draws", type=int, default=1000)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--sd-run", type=float, default=None,
                   help="scenario SD for custom comparisons; DECISIONS section 6 (at least 0.013). Prefer --architecture-result")
    p.add_argument("--architecture-result", default=None,
                   help="paired_v2.json of the SELECT architecture pass; its sd_run_scenario is used for custom comparisons")
    p.add_argument("--cred", default=None)
    p.add_argument("--amount-col", help="raw transaction amount column for FINAL slices and value metrics")
    p.add_argument("--amount-bins", help="JSON amount-quintile artifact fitted on TRAIN/DS_TRAIN before evaluation")
    p.add_argument("--exclude-rows-with-value-in", dest="exclude_col", default=None,
                   help="exclude targets whose value in this column is present and non-blank (e.g. transaction_advice_xcd); "
                        "they stay history. PLAN step 8: FINAL also without advice rows")
    for field in ("id", "account", "order_col", "target", "score_col"):
        p.add_argument("--" + field.replace("_", "-"), default=getattr(defaults(), field))
    p.add_argument("--positive-label", type=json.loads, default=1, help='JSON scalar, e.g. 1 or \'"Y"\'')
    args = p.parse_args(argv)
    if args.all_targets:
        args.target_start = args.target_end = None
    if args.draws < 2 or args.file_start > args.file_end or args.id == args.account:
        p.error("Need draws>=2, ordered file bounds and distinct identity columns")
    if args.comparisons is None and (args.population != "SELECT" or args.all_targets):
        p.error("the five-fit architecture decision runs on SELECT's June window only; use --comparisons for "
                "any other population or window")
    contrasts = read_json(args.comparisons) if args.comparisons else None
    architecture_result_sha = None
    if args.comparisons is not None:
        if args.architecture_result:
            prior = read_json(args.architecture_result)
            args.sd_run = float(prior["architecture_decision"]["sd_run_scenario"])
            architecture_result_sha = digest(args.architecture_result)
            args.sd_run_source = f"architecture_decision.sd_run_scenario of {args.architecture_result} (sha256 {architecture_result_sha})"
        elif args.sd_run is None and any(sides.get("y") for sides in contrasts.values()):
            p.error("--comparisons needs --architecture-result <paired_v2.json of the SELECT architecture pass> or --sd-run")
    out = Path(args.out)
    if out.exists():
        raise FileExistsError(out)
    fs = thin_read_filesystem(args.cred)
    files = build_file_list(args.raw_base, args.file_start, args.file_end)
    run_table = pd.read_csv(args.runs, dtype=str, keep_default_na=False)
    args.amount_bins_artifact = read_json(args.amount_bins, fs) if args.amount_bins else None
    if args.amount_bins_artifact is not None:
        validate_amount_bins(args.amount_bins_artifact)
    raw = load_raw(files, fs, args)
    models = load_models(run_table, raw, args, fs)
    result = analyse(raw, models, args, contrasts)
    result["input_identity"] = {"run_table_sha256": digest(args.runs), "raw_files": files,
                                "comparison_spec_sha256": digest(args.comparisons) if args.comparisons else None,
                                "architecture_result_sha256": architecture_result_sha,
                                "source_sha256": digest(__file__),
                                "amount_bins_sha256": digest(args.amount_bins, fs) if args.amount_bins else None}
    out.mkdir(parents=True, exist_ok=False)
    (out / "paired_v2.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    (out / "exposure.json").write_text(json.dumps({
        "utc": datetime.now(timezone.utc).isoformat(), "population": args.population, "purpose": args.purpose,
        "operation": "paired analysis of existing predictions", "target_start": args.target_start,
        "target_end": args.target_end, "selected_rows": result["selected_rows"],
        "checkpoint_sha256": {k: m["receipt"]["checkpoint_sha256"] for k, m in models.items()},
        "input_identity": result["input_identity"],
        "selection_adjusted": False,
    }, indent=2, allow_nan=False) + "\n")
    rows = [dict(contrast=name, depth=line, **r) for name, lines in result["contrasts"].items() for line, r in lines.items()]
    pd.DataFrame(rows).to_csv(out / "paired_v2.csv", index=False)
    print(f"PAIRED_DIR={out.resolve()}")
    return result


if __name__ == "__main__":
    main()
