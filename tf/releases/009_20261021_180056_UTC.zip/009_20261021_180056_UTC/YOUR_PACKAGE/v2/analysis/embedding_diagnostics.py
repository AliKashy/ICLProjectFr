"""Aggregate embedding diagnostics using only the consumer's train-fitted transforms."""

import numpy as np


NEAR_CONSTANT_STD = 1e-8
# Match the export/scorer agreement threshold in RUNBOOK step 2; FP32 batches need not be bitwise identical.
BENCH_FT_SCORE_ATOL = 1e-4


def _finite_or_null(values):
    return [float(x) if np.isfinite(x) else None for x in values]


def embedding_diagnostics(frame, columns, scaler, pcas, scores):
    """Summarise this population; the caller supplies transforms fitted on DS_TRAIN.

    Standard deviation uses ddof=0. A raw dimension is near constant when its
    standard deviation is at most 1e-8 in the unscaled embedding's units.
    Correlations are Pearson coefficients; constant inputs return null.
    """
    if not len(frame) or not columns:
        raise ValueError("Embedding diagnostics require nonempty finite vectors")
    dimensions = []
    # Summarise one column at a time rather than copy the entire training matrix to float64.
    for col in columns:
        values = frame[col].to_numpy(dtype=np.float64)
        if not np.isfinite(values).all():
            raise ValueError("Embedding diagnostics require nonempty finite vectors")
        mean, std = values.mean(), values.std()
        dimensions.append({"dimension": col, "mean": float(mean), "std": float(std),
                           "near_constant": bool(std <= NEAR_CONSTANT_STD)})
    transformed = scaler.transform(frame[columns]).astype(np.float32, copy=False)
    result = {"rows": len(frame), "embedding_width": len(columns), "std_ddof": 0,
              "near_constant_std_threshold": NEAR_CONSTANT_STD, "dimensions": dimensions, "pca": {}}
    checked_scores = {}
    for name, score in scores.items():
        values = np.asarray(score, dtype=np.float64)
        if values.shape != (len(frame),) or not np.isfinite(values).all():
            raise ValueError("Embedding correlation scores must match rows and be finite")
        checked_scores[name] = values - values.mean()
    for k, pca in sorted(pcas.items()):
        components = pca.transform(transformed).astype(np.float64)
        centered = components - components.mean(axis=0)
        component_norm = np.linalg.norm(centered, axis=0)
        correlations = {}
        for name, score in checked_scores.items():
            denominator = component_norm * np.linalg.norm(score)
            corr = np.full(centered.shape[1], np.nan)
            np.divide(centered.T @ score, denominator, out=corr, where=denominator > 0)
            correlations[name] = _finite_or_null(np.clip(corr, -1., 1.))
        result["pca"][str(k)] = {
            "fit_population": "DS_TRAIN", "components": list(range(1, int(k) + 1)),
            "explained_variance": _finite_or_null(pca.explained_variance_),
            "explained_variance_ratio": _finite_or_null(pca.explained_variance_ratio_),
            "cumulative_explained_variance_ratio": _finite_or_null(np.cumsum(pca.explained_variance_ratio_)),
            "score_correlations": correlations}
    return result


def validate_benchmark_embedding_inputs(config, raw, aligned, frozen, audit, filesystem=None):
    """Validate label-free export/consumer inputs before any labelled metric is computed."""
    import joblib
    from YOUR_PACKAGE.v2.benchmark_v2 import canonical_ids, digest, exact_unique, file_pin, open_file, read_json, read_table
    from YOUR_PACKAGE.v2.downstream_xgb import encoder_pin_identity, identity, verify_export_inputs

    folder = str(config["ft_embedding_export"]).rstrip("/")
    bundle_pin = frozen.get("downstream", {}).get("bundle")
    file_pin(bundle_pin, filesystem)
    with open_file(bundle_pin["path"], "rb", filesystem) as stream:
        bundle = joblib.load(stream)
    if bundle["encoder_pins"] != encoder_pin_identity(frozen["encoder"], filesystem):
        raise ValueError("PCA consumer encoder pins differ from the frozen encoder")
    manifest = read_json(folder + "/manifest.json", filesystem)
    validation = read_json(folder + "/validation.json", filesystem)
    if validation.get("passed") is not True or manifest.get("labels_read") is not False:
        raise ValueError("BENCH diagnostics require a passing label-free embedding export")
    verify_export_inputs(manifest, frozen["encoder"], filesystem)
    if identity(manifest) != bundle["encoder"]:
        raise ValueError("BENCH export differs from the PCA consumer encoder/policy")
    parquet = folder + "/embeddings.parquet"
    if digest(parquet, filesystem) != manifest.get("embeddings_sha256"):
        raise ValueError("BENCH embedding bytes differ from their export manifest")
    emb = read_table(parquet, filesystem)
    key, account = config["key"], config["account"]
    for field in ("key", "account"):
        if config[field] != bundle["config"][field]:
            raise ValueError("BENCH embedding keys differ from the PCA consumer schema")
    for column in (key, account):
        emb[column], kind = canonical_ids(emb[column], "BENCH embedding " + column)
        target_kind = canonical_ids(raw[column], "BENCH target " + column)[1]
        # Benchmark transaction keys were already canonicalised to text by exact_unique.
        if column != key and kind != target_kind:
            raise ValueError("BENCH embedding account representation differs from targets")
        emb[column] = emb[column].astype(str)
    emb = exact_unique(emb, [key, account], "bench_embedding", audit)
    columns = bundle["embedding_columns"]
    if (set(c for c in emb if c.startswith("e_")) != set(columns)
            or validation.get("embedding_width") != len(columns)
            or validation.get("expected_width") != len(columns)):
        raise ValueError("BENCH embedding width differs from the fitted PCA consumer")
    if not np.isfinite(emb[[*columns, "score"]].to_numpy(dtype=float)).all():
        raise ValueError("BENCH embeddings and scores must be finite")
    targets = raw[[key, account]].copy()
    targets[account] = canonical_ids(targets[account], "BENCH target account")[0].astype(str)
    coverage = targets.merge(emb[[key, account]], on=[key, account], how="left", validate="one_to_one", indicator=True)
    if not coverage["_merge"].eq("both").all():
        raise ValueError("BENCH export must cover every benchmark target composite key")
    rows = aligned.copy()
    rows[account] = canonical_ids(rows[account], "BENCH aligned account")[0].astype(str)
    rows = rows.merge(emb[[key, account, "score", *columns]].rename(columns={"score": "_embedding_ft_score"}),
                      on=[key, account], how="left", validate="one_to_one")
    ft_scores = rows["score_ft"].to_numpy(dtype=np.float64)
    export_scores = rows["_embedding_ft_score"].to_numpy(dtype=np.float64)
    if not np.isfinite(ft_scores).all() or not np.isfinite(export_scores).all():
        raise ValueError("BENCH embedding and aligned FT scores must be finite")
    differences = np.abs(ft_scores - export_scores)
    score_agreement = {"rows": len(rows), "absolute_tolerance": BENCH_FT_SCORE_ATOL,
                       "relative_tolerance": 0., "max_absolute_difference": float(differences.max()),
                       "nonidentical_rows": int(np.count_nonzero(differences)),
                       "rows_exceeding_tolerance": int(np.count_nonzero(differences > BENCH_FT_SCORE_ATOL))}
    if score_agreement["rows_exceeding_tolerance"]:
        raise ValueError("BENCH embedding FT scores disagree with the aligned frozen FT scores: "
                         f"{score_agreement['rows_exceeding_tolerance']} rows exceed absolute tolerance "
                         f"{BENCH_FT_SCORE_ATOL}; maximum absolute difference "
                         f"{score_agreement['max_absolute_difference']}")
    return {"rows": rows, "columns": columns, "bundle": bundle, "ft_score_agreement": score_agreement,
            "consumer_sha256": bundle_pin["sha256"], "embeddings_sha256": manifest["embeddings_sha256"]}


def benchmark_embedding_diagnostics(validated):
    """Transform validated BENCH rows with the frozen consumer; never fit transforms."""
    rows, columns, bundle = validated["rows"], validated["columns"], validated["bundle"]
    report = embedding_diagnostics(rows, columns, bundle["embedding_scaler"], bundle["pcas"],
                                   {name: rows["score_" + name] for name in ("ft", "fl", "tfm")
                                    if "score_" + name in rows})
    report.update(population="BENCH common-valid rows", fit_population="DS_TRAIN", fit_called=False,
                  ft_score_agreement=validated["ft_score_agreement"],
                  consumer_sha256=validated["consumer_sha256"], embeddings_sha256=validated["embeddings_sha256"])
    return report
