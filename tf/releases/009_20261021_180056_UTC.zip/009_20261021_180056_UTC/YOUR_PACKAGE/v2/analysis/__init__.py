"""V2 analysis; frozen V1 helpers are imported without modification."""
