"""TRUST.md stage 3 "history-lite" arm and stage 4 stability checks.

history_lite: the previous K rows of the account with a strictly earlier time key (same-time rows excluded,
    as in V1's strict rule): amount, log gap to the target, balance and type. A stand-in for what the history
    model already sees, so a family's gain can be read on top of it.
temporal_screen: train on targets before a split time, test on targets at or after it, with account-grouped
    folds on top, so no account is in both the training and the test part of a fold.
feature_drift: population stability (PSI) of each feature between training rows and June rows, deciles fixed
    on the training rows, missing values as their own bin. Uses no labels.
"""

import numpy as np
import pandas as pd

from usefulness import DEFAULT_PARAMS, _design, _fit_predict, account_folds, bootstrap_delta, weighted_ap

LAG_FIELDS = {"transaction_amt": "amt", "total_available_balance_amt": "bal"}
LAG_TYPE = "transaction_type_xcd"


def history_lite(df, k=5, account="Nmap_account_reference_xid", time="transaction_dttm", tie="fi_transaction_id"):
    """Lag columns lag{j}_amt, lag{j}_bal, lag{j}_gap_log, lag{j}_type for j = 1..k (missing when absent).

    Rows are ordered by account, time and the tie column (the original author's order); lag 1 is the last
    row whose time key is strictly earlier, so same-time rows never see each other."""
    keys = [pd.to_datetime(df[time]).to_numpy(dtype="datetime64[ns]").astype(np.int64), df[account].astype(str).to_numpy()]
    if tie in df.columns:
        keys.insert(0, df[tie].astype(str).to_numpy())
    order = np.lexsort(tuple(keys))
    d = df.iloc[order]
    acct = d[account].astype(str).to_numpy()
    t = pd.to_datetime(d[time]).to_numpy(dtype="datetime64[ns]").astype(np.int64)  # ns whatever the stored unit
    n = len(d)
    new_acct = np.r_[True, acct[1:] != acct[:-1]]
    new_grp = new_acct | np.r_[True, t[1:] != t[:-1]]
    grp_start = np.maximum.accumulate(np.where(new_grp, np.arange(n), 0))
    acct_start = np.maximum.accumulate(np.where(new_acct, np.arange(n), 0))
    last_earlier = grp_start - 1  # last row with a strictly earlier time key in the same account
    out = {}
    for j in range(1, k + 1):
        idx = last_earlier - (j - 1)
        ok = idx >= acct_start
        safe = np.where(ok, idx, 0)
        for col, short in LAG_FIELDS.items():
            if col in d.columns:
                v = pd.to_numeric(d[col], errors="coerce").to_numpy(dtype=float)[safe]
                out[f"lag{j}_{short}"] = np.where(ok, v, np.nan)
        with np.errstate(invalid="ignore"):
            out[f"lag{j}_gap_log"] = np.where(ok, np.log1p((t - t[safe]) / 1e9), np.nan)
        if LAG_TYPE in d.columns:
            ty = d[LAG_TYPE].astype(object).to_numpy()[safe]
            out[f"lag{j}_type"] = np.where(ok, ty, None)
    res = pd.DataFrame(out, index=d.index)
    return res.loc[df.index]


def history_lite_columns(k=5):
    num = [f"lag{j}_{s}" for j in range(1, k + 1) for s in ("amt", "bal", "gap_log")]
    return num + [f"lag{j}_type" for j in range(1, k + 1)], [f"lag{j}_type" for j in range(1, k + 1)]


def temporal_screen(df, base_cols, family_cols, split_time, cat_cols=(), label="frd_tag",
                    account="Nmap_account_reference_xid", time="transaction_dttm", k=5, seed=42, params=None,
                    n_boot=500, train_neg_rate=1.0):
    """Paired screen with training targets before `split_time` and test targets at or after it, inside
    account-grouped folds. Passes when the bootstrap interval of the pooled difference is above 0."""
    params = {**DEFAULT_PARAMS, **(params or {})}
    cat_cols = set(cat_cols)
    y = (pd.to_numeric(df[label], errors="coerce").to_numpy() == 1).astype(int)
    acc = df[account].astype(str).to_numpy()
    late = (pd.to_datetime(df[time]) >= pd.Timestamp(split_time)).to_numpy()
    fold = account_folds(acc, k)
    keep_neg = np.random.default_rng(seed + 1).random(len(df))
    Xb = _design(df, list(base_cols), cat_cols)
    Xw = _design(df, list(base_cols) + list(family_cols), cat_cols)
    pb, pw = np.full(len(df), np.nan), np.full(len(df), np.nan)
    for f in range(k):
        te = (fold == f) & late
        tr = (fold != f) & ~late & ((y == 1) | (keep_neg < train_neg_rate))
        if y[te].sum() == 0 or y[tr].sum() == 0:
            continue
        _, pb[te] = _fit_predict(Xb[tr], y[tr], Xb[te], params, seed)
        _, pw[te] = _fit_predict(Xw[tr], y[tr], Xw[te], params, seed)
    ok = ~np.isnan(pb)
    if not ok.any() or y[ok].sum() == 0:
        return {"split_time": str(split_time), "skipped": "no test frauds after the split"}
    ap_b, ap_w = weighted_ap(y[ok], pb[ok]), weighted_ap(y[ok], pw[ok])
    ci, se = bootstrap_delta(y[ok], pb[ok], pw[ok], acc[ok], n_boot, seed)
    return {"split_time": str(split_time), "test_rows": int(ok.sum()), "test_frauds": int(y[ok].sum()),
            "train_rows_max": int(((~late) & (fold != 0)).sum()), "ap_base": ap_b, "ap_with": ap_w,
            "delta": ap_w - ap_b, "delta_ci95_account_bootstrap": ci, "delta_bootstrap_se": se,
            "passed": bool(ci[0] > 0)}


def psi(ref, other, categorical=False, bins=10, eps=1e-6):
    """PSI of `other` against `ref`. Numeric: decile edges of the finite reference values; categorical: the
    reference categories plus one bin for unseen values. Missing values are always their own bin."""
    ref, other = pd.Series(ref), pd.Series(other)
    if categorical:
        r, o = ref.astype(object), other.astype(object)
        cats = sorted(set(r.dropna().astype(str)))
        def counts(s):
            s2 = s.dropna().astype(str)
            c = [int((s2 == v).sum()) for v in cats] + [int((~s2.isin(cats)).sum())]
            return np.array(c + [int(s.isna().sum())], dtype=float)
    else:
        r = pd.to_numeric(ref, errors="coerce").astype(float)
        o = pd.to_numeric(other, errors="coerce").astype(float)
        fin = r[np.isfinite(r)]
        edges = np.unique(np.quantile(fin, np.linspace(0, 1, bins + 1)[1:-1])) if len(fin) else np.array([])
        def counts(s):
            v = s.to_numpy()
            f = np.isfinite(v)
            c = np.bincount(np.searchsorted(edges, v[f], side="right"), minlength=len(edges) + 1)
            return np.r_[c, (~f).sum()].astype(float)
    pr, po = counts(r), counts(o)
    pr, po = pr / max(pr.sum(), 1) + eps, po / max(po.sum(), 1) + eps
    return float(np.sum((po - pr) * np.log(po / pr)))


def feature_drift(train_feats, june_feats, cols, cat_cols=(), threshold=0.25):
    """PSI and missing rates per column; `flag` when PSI exceeds `threshold` (a rule of thumb)."""
    out = {}
    for c in cols:
        if c not in train_feats.columns or c not in june_feats.columns:
            continue
        p = psi(train_feats[c], june_feats[c], categorical=c in cat_cols)
        out[c] = {"psi": p, "missing_train": float(pd.isna(train_feats[c]).mean()),
                  "missing_june": float(pd.isna(june_feats[c]).mean()), "flag": bool(p > threshold)}
    return {"threshold": threshold, "columns": out, "flagged": sorted(c for c, v in out.items() if v["flag"])}
