"""New candidate columns for the CPU screen (the feature catalogue F03, F04, F05, F06, F09, F10, F11).

Builds only what PR #11 does not have, on PR #11's own primitives (`YOUR_PACKAGE.v2.features`, branch
the features branch of 2026-10-12 at a204078): the point-in-time rule, censoring and missing-versus-zero
conventions are PR #11's (strictly earlier rows of the account, same-time rows excluded). F01/F02 are
PR #11's E13 (`groups.amount_over_capacity`) and are not rebuilt here. No function reads a label.
"""

import re

import numpy as np
import pandas as pd

from YOUR_PACKAGE.v2.features.groups import amount_over_capacity  # noqa: F401  (E13 = F01, F02; re-exported)
from YOUR_PACKAGE.v2.features.strict_window import extract_start_key, from_frame

AMOUNT = "transaction_amt"
BALANCE = "total_available_balance_amt"
MERCH_LIMIT = "remain_day_merchandise_lmt_amt"
CASH_LIMIT = "available_daily_cash_limit_amt"
CENT = 0.01
HEADROOM_CODES = ("missing", "cap_le_0", "exact_drain", "overdraw", "ge90", "50_90", "lt50")


def _num(df, col):
    return pd.to_numeric(df[col], errors="coerce").to_numpy(dtype=float)


def code_text(values):
    """Stored codes as text for equality tests: whole numbers in any type (1, 1.0, "1") become "1", other text
    is stripped, missing stays None. A code typed on the command line ("1") then matches a numeric column."""
    s = pd.Series(values, dtype=object, copy=False)
    num = pd.to_numeric(s, errors="coerce").to_numpy(dtype=float)
    whole = np.isfinite(num) & (num == np.floor(num))
    out = s.astype(str).str.strip().to_numpy(dtype=object)
    out[whole] = num[whole].astype(np.int64).astype(str)
    out[s.isna().to_numpy()] = None
    return out


def flag_hits(df, col, value):
    """Rows whose stored `col` equals `value`, compared as code text (see code_text). Missing never matches."""
    return code_text(df[col].to_numpy(dtype=object)) == code_text([value])[0]


def headroom_code(x, b):
    """F04: one categorical per capacity. exact_drain (|b - x| < 1 cent) is tested before overdraw."""
    x, b = np.asarray(x, dtype=float), np.asarray(b, dtype=float)
    ok = np.isfinite(x) & np.isfinite(b)
    with np.errstate(invalid="ignore", divide="ignore"):
        r = np.where(ok & (b > 0), x / b, np.nan)
    return np.select(
        [~ok, b <= 0, np.abs(b - x) < CENT, x > b, r >= 0.9, r >= 0.5],
        ["missing", "cap_le_0", "exact_drain", "overdraw", "ge90", "50_90"], default="lt50").astype(object)


def capacity_extras(df, cash_rows=None):
    """F03 amt_over_cash_lmt (cash rows only; all rows while CQ-A is open), F04 headroom codes, F05 log_bal_after."""
    x, b, lm, lc = (_num(df, c) for c in (AMOUNT, BALANCE, MERCH_LIMIT, CASH_LIMIT))
    cash = np.ones(len(df), dtype=bool) if cash_rows is None else np.asarray(cash_rows, dtype=bool)
    with np.errstate(invalid="ignore", divide="ignore"):
        r_cash = np.where(cash & np.isfinite(x) & (lc > 0), x / lc, np.nan)
        after = b - x
        log_after = np.where(np.isfinite(after), np.sign(after) * np.log1p(np.abs(after)), np.nan)
    return {"amt_over_cash_lmt": r_cash,
            "headroom_balance": headroom_code(x, b),
            "headroom_merch_lmt": headroom_code(x, lm),
            "log_bal_after": log_after}


def drain_24h(sw, df):
    """F06: (S24 + x) / (B + S24), S24 = sum of strictly earlier observed non-negative amounts in 24 h.

    An empty complete window gives S24 = 0. Missing if censored, x missing or negative, B missing, or
    B + S24 <= 0. Uses earlier rows' amounts only, never a later row's balance (memo L3).
    """
    x, b = _num(df, AMOUNT), _num(df, BALANCE)
    ok = np.isfinite(x) & (x >= 0)
    n = sw.count("24h", where=ok)
    s = np.where(n > 0, sw.sum("24h", x, where=ok), np.where(np.isnan(n), np.nan, 0.0))
    den = b + s
    with np.errstate(invalid="ignore", divide="ignore"):
        return {"drain_24h": np.where(ok & np.isfinite(den) & (den > 0), (s + x) / den, np.nan)}


def flag_window(sw, df, col, value, w, name):
    """F09/F10: count and sum of strictly earlier rows in window w whose `col` equals `value`.

    `value` must be stated by the caller (the flag codes' meanings are not documented). Count missing if
    censored; sum missing when the count is 0 (PR #11 E12 rule).
    """
    hit = flag_hits(df, col, value)
    x = _num(df, AMOUNT)
    n = sw.count(w, where=hit)
    s = sw.sum(w, x, where=hit & np.isfinite(x) & (x >= 0))
    return {f"{name}_cnt_{w}_log1p": np.log1p(n), f"{name}_sum_{w}": np.where(n > 0, s, np.nan)}


def mcc_novelty(sw, df, col="merchant_category_xcd"):
    """F11: mcc_new_30d = 1[no strictly earlier row in 30 d with the same raw MCC]; same_mcc_24h count.

    Missing if censored or the current MCC is missing. Raw values, before any vocabulary collapse.
    """
    mcc = df[col].astype(object).to_numpy()
    own = ~pd.isna(mcc)
    m30 = sw.match_count("30d", mcc)
    m24 = sw.match_count("24h", mcc)
    return {"mcc_new_30d": np.where(own & ~np.isnan(m30), (m30 == 0).astype(float), np.nan),
            "same_mcc_24h_log1p": np.where(own, np.log1p(m24), np.nan)}


def compute_new(df, extract_start, cash_rows=None, present_value=None, absent_value=None, centroids=None):
    """All feature-catalogue candidate columns for every row of `df` (whole in-extract account histories).

    Location features (F20-F23) are built only when a centroid table and `present_value` are given."""
    sw = from_frame(df, extract_start)
    out = dict(capacity_extras(df, cash_rows))
    out.update(drain_24h(sw, df))
    if present_value is not None:
        out.update(flag_window(sw, df, "cardholder_present_xflg", present_value, "5m", "cp"))
    if absent_value is not None:
        out.update(flag_window(sw, df, "cardholder_present_xflg", absent_value, "24h", "cnp"))
    if "merchant_category_xcd" in df.columns:
        out.update(mcc_novelty(sw, df))
    if centroids is not None and present_value is not None and "merchant_postal_xcd" in df.columns:
        cp = flag_hits(df, "cardholder_present_xflg", present_value)
        out.update(travel(df, centroids, cp, extract_start))
        out.update(dist_usual(sw, df, centroids, cp))
        if "cprsrvc__pisinfo_cardholder_postal_xcd" in df.columns:
            out.update(dist_home(df, centroids, cp_rows=cp))
    return pd.DataFrame(out, index=df.index)


# --------------------------------------------------------------------------------------------------------------- #
# F20-F23: distance and travel (the owner, 2026-10-19). Locations are postal-code centroids from a table the caller
# supplies ({normalised postal: (lat, lon)}); none is shipped here. Card-not-present rows carry the merchant's
# registered address, not the card's location, so only rows marked card-present (`cp_rows`) are location
# evidence, for the current row and for the earlier row alike. Every earlier row is strictly earlier in time.
EARTH_KM = 6371.0
LOC_STATUS = ("ok", "not_card_present", "unknown_location", "no_prior_location", "censored")


def normalise_postal(values):
    """US ZIP. Text: the first 5 characters when they are digits (ZIP+4 and 9-digit forms collapse). Numbers (a
    numeric column, or text such as "2134.0" written from one) have lost their leading zeros, so they are padded:
    up to 99999 to 5 digits, larger values as a 9-digit ZIP+4. Anything else (foreign formats, blanks, 1-4 digit
    text) becomes None, so it never matches a centroid."""
    out = []
    for v in values:
        if v is None or isinstance(v, bool) or (isinstance(v, (float, np.floating)) and np.isnan(v)):
            out.append(None)
            continue
        if isinstance(v, (int, np.integer, float, np.floating)):
            n = int(v) if float(v).is_integer() and v >= 0 else None
        else:
            s = str(v).strip()
            if not re.fullmatch(r"\d+\.0+", s):
                out.append(s[:5] if len(s) >= 5 and s[:5].isdigit() else None)
                continue
            n = int(s.split(".")[0])
        z = None if n is None or n > 999999999 else str(n).zfill(9 if n > 99999 else 5)
        out.append(None if z is None else z[:5])
    return np.array(out, dtype=object)


def haversine_km(lat1, lon1, lat2, lon2):
    p1, p2 = np.radians(lat1), np.radians(lat2)
    dp, dl = p2 - p1, np.radians(np.asarray(lon2, dtype=float) - np.asarray(lon1, dtype=float))
    a = np.sin(dp / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dl / 2) ** 2
    return 2 * EARTH_KM * np.arcsin(np.sqrt(np.clip(a, 0.0, 1.0)))


def _latlon(postal, centroids):
    lat = np.array([centroids[p][0] if p in centroids else np.nan for p in postal], dtype=float)
    lon = np.array([centroids[p][1] if p in centroids else np.nan for p in postal], dtype=float)
    return lat, lon


def _last_earlier(df, eligible, account="Nmap_account_reference_xid", time="transaction_dttm",
                  tie="fi_transaction_id"):
    """Position (in df's row order) of the latest eligible row of the same account with a strictly earlier time
    key, or -1. Same-time rows never count, whatever the tie order."""
    t = pd.to_datetime(df[time]).to_numpy(dtype="datetime64[ns]").astype(np.int64)
    acct = df[account].astype(str).to_numpy()
    keys = [t, acct] if tie not in df.columns else [df[tie].astype(str).to_numpy(), t, acct]
    order = np.lexsort(tuple(keys))
    a_s, t_s, e_s = acct[order], t[order], np.asarray(eligible, dtype=bool)[order]
    idx = np.arange(len(order))
    new_acct = np.r_[True, a_s[1:] != a_s[:-1]]
    acct_start = np.maximum.accumulate(np.where(new_acct, idx, 0))
    grp_start = np.maximum.accumulate(np.where(new_acct | np.r_[True, t_s[1:] != t_s[:-1]], idx, 0))
    last_elig = np.maximum.accumulate(np.where(e_s, idx, -1))  # latest eligible position at or before i
    p = grp_start - 1  # the last row with a strictly earlier time key, if it is in the same account
    cand = np.where(p >= acct_start, last_elig[np.maximum(p, 0)], -1)
    cand = np.where(cand >= acct_start, cand, -1)
    out = np.full(len(order), -1)
    out[order] = np.where(cand >= 0, order[np.maximum(cand, 0)], -1)
    return out


def travel(df, centroids, cp_rows, extract_start=None, postal_col="merchant_postal_xcd",
           speed_kmh=900.0, min_km=50.0, min_gap_s=60.0, lookback_days=30):
    """F20 dist_prev_km_log1p and F21 speed_kmh_log1p, impossible_travel, with loc_prev_status.

    Previous = the latest strictly earlier card-present row of the account with a known centroid, at most
    `lookback_days` earlier (bounded state, and censoring as in PR #11). Status: not_card_present (current
    row), unknown_location (current centroid missing), censored (no previous location and the lookback reaches
    before the extract start), no_prior_location, ok.
    impossible_travel = 1[speed > speed_kmh and distance > min_km]; speed uses max(gap, min_gap_s).
    """
    post = normalise_postal(df[postal_col].to_numpy(dtype=object))
    lat, lon = _latlon(post, centroids)
    known = np.isfinite(lat)
    cp = np.asarray(cp_rows, dtype=bool)
    j = _last_earlier(df, cp & known)
    t = pd.to_datetime(df["transaction_dttm"]).to_numpy(dtype="datetime64[ns]").astype(np.int64)
    look = lookback_days * 86400 * 10**9
    jj = np.maximum(j, 0)
    has = (j >= 0) & (t - t[jj] <= look)
    d = np.where(has & cp & known, haversine_km(lat, lon, lat[jj], lon[jj]), np.nan)
    gap = np.where(has, (t - t[jj]) / 1e9, np.nan)
    with np.errstate(invalid="ignore", divide="ignore"):
        v = d / (np.maximum(gap, min_gap_s) / 3600.0)
    status = np.select([~cp, ~known, ~has], ["not_card_present", "unknown_location", "no_prior_location"],
                       default="ok").astype(object)
    if extract_start is not None:
        es = extract_start_key(extract_start)
        status = np.where((status == "no_prior_location") & (t - look < es), "censored", status)
    return {"dist_prev_km_log1p": np.log1p(d), "speed_kmh_log1p": np.log1p(v),
            "impossible_travel": np.where(np.isfinite(v), ((v > speed_kmh) & (d > min_km)).astype(float), np.nan),
            "loc_prev_status": status}


def dist_home(df, centroids, postal_col="merchant_postal_xcd", home_col="cprsrvc__pisinfo_cardholder_postal_xcd",
              cp_rows=None):
    """F22: distance from the merchant centroid to the cardholder's home postal centroid (current row only).

    The home postal code is a profile field; if the extract holds today's address, a later move leaks (CQ-09).
    Card-not-present rows are missing (the merchant postal code is then a registered address).
    """
    lat, lon = _latlon(normalise_postal(df[postal_col].to_numpy(dtype=object)), centroids)
    hlat, hlon = _latlon(normalise_postal(df[home_col].to_numpy(dtype=object)), centroids)
    cp = np.ones(len(df), dtype=bool) if cp_rows is None else np.asarray(cp_rows, dtype=bool)
    d = np.where(cp, haversine_km(lat, lon, hlat, hlon), np.nan)
    return {"dist_home_km_log1p": np.log1p(d)}


def dist_usual(sw, df, centroids, cp_rows, postal_col="merchant_postal_xcd"):
    """F23: distance from the mean centroid of strictly earlier card-present located rows in 30 days, the
    radius of gyration of those rows (km), their count, and whether the current postal code was seen among them.

    Means, squares and counts are window sums (PR #11 primitives), so production state is five running sums
    and a 30-day postal set. Lat/lon are averaged directly (valid away from the antimeridian; US data). Missing
    if censored, the current row is not card-present or not located, or no earlier located row exists.
    """
    post = normalise_postal(df[postal_col].to_numpy(dtype=object))
    lat, lon = _latlon(post, centroids)
    cp = np.asarray(cp_rows, dtype=bool)
    ok = cp & np.isfinite(lat)
    n = sw.count("30d", where=ok)
    with np.errstate(invalid="ignore", divide="ignore"):
        mlat = sw.sum("30d", lat, where=ok) / n
        mlon = sw.sum("30d", lon, where=ok) / n
        # radius of gyration on a local flat projection at the window's mean latitude
        k = np.radians(1.0) * EARTH_KM
        y2 = sw.sum("30d", lat * lat, where=ok) / n - mlat ** 2
        x2 = (sw.sum("30d", lon * lon, where=ok) / n - mlon ** 2) * np.cos(np.radians(mlat)) ** 2
        rog = k * np.sqrt(np.clip(x2 + y2, 0.0, None))
    use = ok & (n > 0)
    d = np.where(use, haversine_km(lat, lon, mlat, mlon), np.nan)
    seen = sw.match_count("30d", np.where(ok, post, None), where=ok)
    return {"dist_usual_km_log1p": np.log1p(d), "loc_rog_30d_km_log1p": np.where(use, np.log1p(rog), np.nan),
            "loc_support_30d": n, "postal_seen_30d": np.where(use, (seen > 0).astype(float), np.nan)}
