"""CLI packaged as a CPU pod job. Reads parquet files of ONE split whose
accounts each sit in one file (all files are concatenated, so whole account histories are present), builds
PR #11's groups plus the feature-catalogue columns, runs T1/T2 and the screen for each requested family, and writes one
JSON of aggregates. No row-level output.

  PYTHONPATH=<this folder>:<PR #11 checkout> python3 run_screen.py --files part_1.parquet ... \
      --extract-start 2024-10-01 --out screen_result.json [--present CAR1 --absent CAR0] [--k 5]

Pod package (YOUR_PACKAGE/v2/screen/, module 10): instead of --files, --base/--start/--end with --cred-path read the
files from S3 the way V1's builder does (fraud.data.s3_utils); --drift-base/--drift-start/--drift-end likewise.
Everything else is the feature review's code as copied (SOURCE.md lists the source commit and hashes).
"""

import argparse
import json
import platform

import numpy as np
import pandas as pd

import features_new
import probes
import stability
import state_test
from usefulness import FINAL_RULE, PASS_RULE, base_refit_aps, final_decision, noise_floor, run_screen

BASE_NUM = ["transaction_amt", "external_1_scr", "avlble_merch_day_cash_lmt_amt", "available_daily_cash_limit_amt",
            "remain_day_merchandise_lmt_amt", "total_available_balance_amt"]
BASE_CAT = ["transaction_type_xcd", "segment", "transaction_category_xcd", "transaction_pos_condition_xcd",
            "avs_request_xcd", "pos_security_xflg", "transaction_pin_verify_xcd", "cardholder_present_xflg",
            "pos_card_capture_xflg", "cvv_verify_xcd", "authzn_rqst_crypto_valid_xflg", "pos_off_premises_xflg",
            "pos_terminal_attend_xflg"]
# month is left out (unseen in June); day, hour and day_of_week are derived below as in predictors.csv.
FAMILIES = {
    "capacity_E13": ["amt_over_balance", "amt_over_merch_lmt"],
    "capacity_E13_headroom": ["amt_over_balance", "amt_over_merch_lmt", "headroom_balance", "headroom_merch_lmt"],
    "drain_24h": ["drain_24h"],
    "velocity_E01_C5": ["cnt_5m_log1p", "cnt_1h_log1p", "cnt_24h_log1p", "cnt_7d_log1p", "cnt_30d_log1p",
                        "no_prior_30d", "obs_days_30"],
    "type_familiarity_E08": ["type_frac_30d", "type_support_30d"],
    "amount_midrank_E11": ["amt_midrank_30d", "amt_rank_support_30d"],
    "mcc_novelty": ["mcc_new_30d", "same_mcc_24h_log1p"],
    "travel_F20_F21": ["dist_prev_km_log1p", "speed_kmh_log1p", "impossible_travel", "loc_prev_status"],
    "dist_usual_F23": ["dist_usual_km_log1p", "loc_rog_30d_km_log1p", "loc_support_30d", "postal_seen_30d"],
    "dist_home_F22": ["dist_home_km_log1p"],  # profile field: read only after CQ-09 (tier 1 until certified)
    "null_noise": ["null_noise"],  # calibration: a column of pure noise; its result is the screen's noise floor
}
CAT_NEW = ["headroom_balance", "headroom_merch_lmt", "loc_prev_status"]
WAVE1 = ("capacity_E13", "capacity_E13_headroom", "drain_24h", "velocity_E01_C5", "type_familiarity_E08",
         "amount_midrank_E11", "mcc_novelty")


ID_COLS = ["transaction_dttm", "Nmap_account_reference_xid", "fi_transaction_id", "frd_tag", "transaction_advice_xcd"]
EXTRA_RAW = ["merchant_category_xcd", "merchant_postal_xcd"]
HOME_POSTAL = "cprsrvc__pisinfo_cardholder_postal_xcd"


def screen_columns(families):
    """The raw columns the screen reads: its inputs, the ids, the label and the extra raw fields its features use.
    Reading only these keeps files 1-10 near 30 GB instead of about 120 GB with all 224 columns. The home postal
    code is read only when dist_home_F22 is requested (held until the home address is certified)."""
    cols = BASE_NUM + BASE_CAT + ID_COLS + EXTRA_RAW
    return cols + [HOME_POSTAL] if "dist_home_F22" in families else cols


def read_columns(path, columns):
    """One local parquet file, only the listed columns that it has."""
    import pyarrow.parquet as pq
    have = set(pq.read_schema(path).names)
    return pd.read_parquet(path, columns=[c for c in columns if c in have])


def read_frame(path, fs=None, columns=None):
    """One parquet file, local or on S3 (fs from fraud.data.s3_utils.make_s3_filesystem), only `columns`."""
    columns = columns or screen_columns(())
    if fs is None:
        return read_columns(path, columns)
    import pyarrow.parquet as pq
    from fraud.data.s3_utils import strip_scheme
    ds = pq.ParquetDataset(strip_scheme(path), filesystem=fs)
    have = set(ds.schema.names)
    return ds.read(columns=[c for c in columns if c in have]).to_pandas()


def file_list(files, base, start, end):
    """--files as given, or <base>/part_<start..end>.parquet."""
    if files:
        if base is not None:
            raise ValueError("give --files or --base/--start/--end, not both")
        return list(files)
    if base is None or start is None or end is None:
        raise ValueError("give --files, or --base with --start and --end")
    from fraud.data.s3_utils import build_file_list
    return build_file_list(base, start, end)


def load_centroids(path):
    """CSV with columns postal, lat, lon (for example the public US Census ZCTA Gazetteer, reduced)."""
    c = pd.read_csv(path, dtype={"postal": str})
    return {str(p).zfill(5): (float(a), float(b)) for p, a, b in zip(c["postal"], c["lat"], c["lon"])}


def build(files, extract_start, present=None, absent=None, centroids=None, fs=None, columns=None):
    from YOUR_PACKAGE.v2.features.groups import compute_groups
    df = pd.concat([read_frame(f, fs, columns) for f in files], ignore_index=True)
    t = pd.to_datetime(df["transaction_dttm"])
    df["day"], df["hour"], df["day_of_week"] = t.dt.day.astype(str), t.dt.hour.astype(str), t.dt.dayofweek.astype(str)
    feats = pd.concat([compute_groups(df, extract_start),
                       features_new.compute_new(df, extract_start, present_value=present, absent_value=absent,
                                                centroids=centroids)], axis=1)
    return df, feats


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--files", nargs="+", default=None)
    p.add_argument("--base", default=None, help="file base (local or s3://); with --start and --end")
    p.add_argument("--start", type=int, default=None)
    p.add_argument("--end", type=int, default=None)
    p.add_argument("--cred-path", default=None, help="S3 credentials file (fraud.data.s3_utils); never copied")
    p.add_argument("--extract-start", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--families", nargs="*", default=list(WAVE1),
                   help="families to screen (default: the seven wave-1 families); the distance families run only "
                        "when named, and dist_home_F22 stays held until the home address is certified; null_noise "
                        "and the base-arm refits always run first (the floor)")
    p.add_argument("--extra-seeds", nargs="*", type=int, default=[43, 44],
                   help="extra XGBoost seeds for the base arm (refit spread); default two")
    p.add_argument("--present", default=None, help="cardholder_present_xflg value meaning present (if known)")
    p.add_argument("--absent", default=None, help="cardholder_present_xflg value meaning not present (if known)")
    p.add_argument("--centroids", default=None,
                   help="postal centroid CSV (postal, lat, lon); with --present it enables F20-F23")
    p.add_argument("--k", type=int, default=5)
    p.add_argument("--n-boot", type=int, default=500)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--history-lite", action="store_true",
                   help="also screen each family on top of the previous 5 rows (TRUST.md stage 3)")
    p.add_argument("--temporal-split", default=None, help="stage 4: train before this time, test after (e.g. 2025-04-01)")
    p.add_argument("--drift-files", nargs="*", default=None, help="stage 4: evaluation-split files for the June PSI")
    p.add_argument("--drift-base", default=None, help="DEV_OOT base (8000-8010 only); with --drift-start/--drift-end")
    p.add_argument("--drift-start", type=int, default=None)
    p.add_argument("--drift-end", type=int, default=None)
    p.add_argument("--drift-extract-start", default="2025-05-01")
    p.add_argument("--drift-month", default="2025-06")
    p.add_argument("--train-neg-rate", type=float, default=1.0, help="share of non-fraud rows kept for training")
    a = p.parse_args(argv)
    fs = None
    if a.cred_path:
        from YOUR_PACKAGE.v2.storage import thin_read_filesystem
        fs = thin_read_filesystem(a.cred_path)
    files = file_list(a.files, a.base, a.start, a.end)
    drift_files = (file_list(a.drift_files, a.drift_base, a.drift_start, a.drift_end)
                   if (a.drift_files or a.drift_base) else None)
    cents = load_centroids(a.centroids) if a.centroids else None
    cols = screen_columns(a.families)
    df, feats = build(files, a.extract_start, a.present, a.absent, cents, fs, cols)
    data = pd.concat([df, feats.drop(columns=[c for c in feats.columns if c in df.columns])], axis=1)
    data["null_noise"] = np.random.default_rng(a.seed + 7).normal(size=len(data))
    base = [c for c in BASE_NUM + BASE_CAT + ["day", "hour", "day_of_week"] if c in data.columns]
    cats = [c for c in BASE_CAT + ["day", "hour", "day_of_week"] + CAT_NEW if c in data.columns]
    out = {"versions": {"python": platform.python_version(), "pandas": pd.__version__, "numpy": np.__version__},
           "files": len(files), "rows": len(df), "pass_rule": PASS_RULE, "final_rule": FINAL_RULE,
           "T1": state_test.consecutive_pairs(df), "T2": state_test.over_capacity_counts(df), "families": {}}
    # Which inputs actually ran (audit finding 54): a missing base input weakens the base arm and inflates every family's
    # gain, so DECISIONS section 10 does not read a result whose missing_columns is not empty.
    out["base_columns_used"] = base
    out["missing_columns"] = [c for c in BASE_NUM + BASE_CAT if c not in data.columns]
    out["T1_verdict"] = {f: state_test.verdict(v) for f, v in out["T1"].items()}
    out["future_invariance"] = probes.future_invariance(
        df, lambda d: features_new.compute_new(d, a.extract_start, present_value=a.present, absent_value=a.absent,
                                               centroids=cents))
    hl_cols, hl_cats = stability.history_lite_columns()
    if a.history_lite:
        data = pd.concat([data, stability.history_lite(df)], axis=1)
    # The floor first (decided 2026-10-19 under the owner's delegation): the null family and the base-arm refits.
    null = run_screen(data, base, ["null_noise"], cats, k=a.k, seed=a.seed, n_boot=a.n_boot,
                      train_neg_rate=a.train_neg_rate, permute=False)
    base_aps = {a.seed: null["pooled_ap_base"]}
    base_aps.update(base_refit_aps(data, base, cats, k=a.k, seed=a.seed, model_seeds=a.extra_seeds,
                                   train_neg_rate=a.train_neg_rate))
    floor = noise_floor(null, base_aps)
    out["null_noise"] = null
    out["base_ap_by_model_seed"] = {str(s_): v for s_, v in base_aps.items()}
    out["noise_floor"] = floor
    for name in a.families:
        fam = [c for c in FAMILIES[name] if c in data.columns]
        if not fam:
            out["families"][name] = {"skipped": "columns not built"}
            continue
        r = run_screen(data, base, fam, cats, k=a.k, seed=a.seed, n_boot=a.n_boot,
                       train_neg_rate=a.train_neg_rate,
                       by_group="headroom_balance" if "headroom_balance" in data.columns else None)
        r["columns_used"] = fam
        r["missing_columns"] = [c for c in FAMILIES[name] if c not in data.columns]
        r["single_feature_ap"] = probes.single_feature_ap(
            data, [c for c in fam if c not in cats], r["pooled_ap_base"])
        if a.history_lite:
            r["on_history_lite"] = run_screen(data, base + hl_cols, fam, cats + hl_cats, k=a.k, seed=a.seed,
                                              n_boot=a.n_boot, train_neg_rate=a.train_neg_rate, permute=False)
        if a.temporal_split:
            r["temporal"] = stability.temporal_screen(data, base, fam, a.temporal_split, cats, k=a.k, seed=a.seed,
                                                      n_boot=a.n_boot, train_neg_rate=a.train_neg_rate)
        r["final_pass"] = final_decision(r, floor["floor"])
        out["families"][name] = r
    if drift_files:
        # Labels are dropped on read: the drift check must not touch the evaluation labels.
        ev = pd.concat([read_frame(f, fs, [c for c in cols if c != "frd_tag"]) for f in drift_files],
                       ignore_index=True)
        from YOUR_PACKAGE.v2.features.groups import compute_groups
        ev_feats = pd.concat([compute_groups(ev, a.drift_extract_start),
                              features_new.compute_new(ev, a.drift_extract_start, present_value=a.present,
                                                       absent_value=a.absent, centroids=cents)], axis=1)
        june = (pd.to_datetime(ev["transaction_dttm"]).dt.to_period("M").astype(str) == a.drift_month).to_numpy()
        cols = sorted({c for fam in FAMILIES.values() for c in fam})
        out["drift"] = {"month": a.drift_month, "june_rows": int(june.sum()),
                        **stability.feature_drift(feats, ev_feats.loc[june], cols, CAT_NEW)}
    with open(a.out, "w") as fh:
        json.dump(out, fh, indent=1, default=str)


if __name__ == "__main__":
    main()
