"""T1 and T2 (feature review note 1 of 2026-10-19 section 4): are the stored balance and limits "before" this transaction?

Counts only; no row leaves these functions. T1 extends PR #20 check f from same-second pairs to every pair of
adjacent rows of an account, and adds the "after" hypothesis that check f does not test:
  before:    v_b = v_a - x_a   (stored value is before each row; row a was posted)
  after:     v_b = v_a - x_b   (stored value already includes the row's own amount)
  unchanged: v_b = v_a         (row a declined or not counted, or row b repeats row a)
  both:      more than one of the above holds (for example x_a = x_b)
  other:     none holds (deposits, released holds, resets)
Daily limits are compared only inside one stored calendar day (the reset clock is CQ-02).
"""

import numpy as np
import pandas as pd

CENT = 0.01
STATE = {"total_available_balance_amt": False, "remain_day_merchandise_lmt_amt": True,
         "available_daily_cash_limit_amt": True}  # field -> compare inside one stored day only
BUCKETS = ("before", "after", "unchanged", "both", "other", "not_applicable")


def _gap_class(dt_ns):
    s = dt_ns / 1e9
    return np.select([s < 1, s < 3600], ["same_second", "under_1h"], default="1h_or_more")


def consecutive_pairs(df, account="Nmap_account_reference_xid", time="transaction_dttm",
                      tie="fi_transaction_id", label="frd_tag", amount="transaction_amt",
                      advice="transaction_advice_xcd", type_col="transaction_type_xcd"):
    """T1 counts: {field: {split: {key: {bucket: pairs}}}} with split in (all, by_pair_kind, by_label_a,
    by_gap, by_type_a). The order is the original author's: stable sort on account, time, tie."""
    d = df.sort_values([account, time, tie], kind="stable").reset_index(drop=True)
    acct = d[account].astype(str).to_numpy()
    # Nanoseconds whatever the stored unit: under pandas 3 (and pyarrow with pandas 2) a timestamp[us] column
    # keeps its unit, so astype("int64") alone would give microseconds (feature review note 6 of 2026-10-19).
    t = pd.to_datetime(d[time]).to_numpy(dtype="datetime64[ns]").astype(np.int64)
    same = np.zeros(len(d), dtype=bool)
    same[1:] = acct[1:] == acct[:-1]
    b = np.flatnonzero(same)
    a = b - 1
    x = pd.to_numeric(d[amount], errors="coerce").to_numpy(dtype=float)
    y = pd.to_numeric(d[label], errors="coerce").to_numpy() == 1
    day = (pd.to_datetime(d[time]).dt.normalize().astype("int64")).to_numpy()
    if advice in d.columns:
        adv = d[advice]
        is_adv = (adv.notna() & (adv.astype(str).str.strip() != "")).to_numpy()
        kind_adv = is_adv[a] | is_adv[b]
    else:
        kind_adv = np.zeros(len(b), dtype=bool)
    same_amt = ~kind_adv & (np.abs(x[a] - x[b]) < CENT)
    kind = np.where(kind_adv, "advice_on_either", np.where(same_amt, "same_amount", "neither"))
    splits = {"all": np.full(len(b), "all"), "by_pair_kind": kind,
              "by_label_a": np.where(y[a], "a_fraud", "a_not_fraud"), "by_gap": _gap_class(t[b] - t[a])}
    if type_col in d.columns:
        splits["by_type_a"] = d[type_col].astype(object).fillna("<missing>").astype(str).to_numpy()[a]
    out = {}
    for f, same_day in STATE.items():
        if f not in d.columns:
            continue
        v = pd.to_numeric(d[f], errors="coerce").to_numpy(dtype=float)
        na = ~(np.isfinite(v[a]) & np.isfinite(v[b]) & np.isfinite(x[a]) & np.isfinite(x[b]))
        if same_day:
            na |= day[a] != day[b]
        hyp = np.stack([np.abs(v[b] - (v[a] - x[a])) < CENT, np.abs(v[b] - (v[a] - x[b])) < CENT,
                        np.abs(v[b] - v[a]) < CENT])
        k = hyp.sum(axis=0)
        bucket = np.select([na, k > 1, hyp[0], hyp[1], hyp[2]],
                           ["not_applicable", "both", "before", "after", "unchanged"], default="other")
        out[f] = {name: {str(key): {bk: int(((keys == key) & (bucket == bk)).sum()) for bk in BUCKETS}
                         for key in np.unique(keys)} for name, keys in splits.items()}
    return out


def over_capacity_counts(df, label="frd_tag", amount="transaction_amt"):
    """T2 counts: rows with x > capacity, and with |capacity - x| < 1 cent, by label."""
    x = pd.to_numeric(df[amount], errors="coerce").to_numpy(dtype=float)
    y = pd.to_numeric(df[label], errors="coerce").to_numpy() == 1
    out = {}
    for f in ("total_available_balance_amt", "remain_day_merchandise_lmt_amt", "available_daily_cash_limit_amt"):
        if f not in df.columns:
            continue
        c = pd.to_numeric(df[f], errors="coerce").to_numpy(dtype=float)
        ok = np.isfinite(x) & np.isfinite(c)
        cells = {"rows_observed": ok, "x_over_cap": ok & (x > c + CENT), "exact_drain": ok & (np.abs(c - x) < CENT),
                 "cap_le_0": ok & (c <= 0)}
        out[f] = {k: {"rows": int(m.sum()), "frauds": int((m & y).sum())} for k, m in cells.items()}
    return out


def verdict(t1_field_all):
    """Plain reading of T1's 'all' split for one field: which hypothesis the data favour."""
    c = t1_field_all["all"]["all"]
    bef, aft = c["before"], c["after"]
    if bef + aft == 0:
        return "no informative pairs"
    if bef >= 10 * max(aft, 1):
        return "before-semantics supported"
    if aft >= 10 * max(bef, 1):
        return "AFTER-semantics: stored values include the row's own amount; decision information may leak"
    return "mixed: investigate by pair kind and type before trusting capacity features"
