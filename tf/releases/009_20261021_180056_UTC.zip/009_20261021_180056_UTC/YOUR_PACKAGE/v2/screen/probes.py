"""Leakage probes (TRUST.md stage 2). Each returns a small dict with `ok` and the evidence.

future_invariance: change every row after a per-account cutoff; no feature value at or before the cutoff
    may move. Catches look-ahead (full-window aggregates, next-row state, closure effects).
single_feature_ap: AP of each new column alone, in its better direction; "too good" when it reaches the
    base model's AP. Catches post-decision proxies and label echoes.
label_shuffle: rerun the screen with labels permuted across accounts; the family must not "help".
    Catches a pipeline that lets the label into a feature (for example a target encoding).
"""

import numpy as np
import pandas as pd

from usefulness import run_screen, weighted_ap


def future_invariance(df, feature_fn, account="Nmap_account_reference_xid", time="transaction_dttm",
                      numeric_cols=("transaction_amt", "total_available_balance_amt",
                                    "remain_day_merchandise_lmt_amt", "available_daily_cash_limit_amt"),
                      seed=0, drop_frac=0.3, shuffle_cols=("merchant_postal_xcd", "cardholder_present_xflg",
                                                           "merchant_category_xcd", "transaction_type_xcd")):
    """`feature_fn(frame) -> DataFrame aligned to frame.index`. Rows strictly after a random per-account
    cutoff are rescaled and partly deleted; rows at or before it must keep identical feature values."""
    rng = np.random.default_rng(seed)
    t = pd.to_datetime(df[time])
    g = df[account].astype(str)
    lo, hi = t.groupby(g).transform("min"), t.groupby(g).transform("max")
    u = pd.Series(rng.random(g.nunique()), index=sorted(g.unique()))
    cut = lo + (hi - lo) * g.map(u).to_numpy()
    later = (t > cut).to_numpy()
    pert = df.copy()
    for c in numeric_cols:
        if c in pert.columns:
            v = pd.to_numeric(pert[c], errors="coerce")
            pert.loc[later, c] = v[later] * rng.uniform(0.1, 10.0, later.sum())
    for c in shuffle_cols:  # categorical fields of later rows are permuted among those rows
        if c in pert.columns and later.any():
            pert.loc[later, c] = rng.permutation(pert.loc[later, c].to_numpy())
    drop = later & (rng.random(len(df)) < drop_frac)
    pert = pert.loc[~drop]
    keep = ~later
    a = feature_fn(df).loc[keep]
    b = feature_fn(pert).loc[df.index[keep]]
    changed = {}
    for c in a.columns:
        x, z = a[c].to_numpy(), b[c].to_numpy()
        if x.dtype == object or z.dtype == object:
            same = (x == z) | (pd.isna(x) & pd.isna(z))
        else:
            same = np.isclose(x.astype(float), z.astype(float), rtol=1e-9, atol=1e-12, equal_nan=True)
        if (~same).any():
            changed[c] = int((~same).sum())
    return {"ok": not changed, "rows_checked": int(keep.sum()), "rows_perturbed": int(later.sum()),
            "rows_deleted": int(drop.sum()), "changed_columns": changed}


def single_feature_ap(df, cols, base_ap, label="frd_tag"):
    """AP of each numeric column alone (missing ranked last), better of the two directions."""
    y = (pd.to_numeric(df[label], errors="coerce").to_numpy() == 1).astype(int)
    out = {}
    for c in cols:
        v = pd.to_numeric(df[c], errors="coerce").to_numpy(dtype=float)
        if not np.isfinite(v).any():
            continue
        lo = np.nanmin(v) - 1.0
        hi = np.nanmax(v) + 1.0
        ap = max(weighted_ap(y, np.where(np.isfinite(v), v, lo)), weighted_ap(y, np.where(np.isfinite(v), -v, -hi)))
        out[c] = {"ap": ap, "too_good": bool(ap >= base_ap)}
    return {"ok": not any(r["too_good"] for r in out.values()), "base_ap": base_ap,
            "prevalence": float(y.mean()), "columns": out}


def label_shuffle(df, base_cols, family_cols, cat_cols=(), label="frd_tag",
                  account="Nmap_account_reference_xid", seed=7, **kw):
    """Labels permuted across rows (folds stay account-grouped); the family must not pass the screen."""
    rng = np.random.default_rng(seed)
    d = df.copy()
    d[label] = rng.permutation(d[label].to_numpy())
    r = run_screen(d, base_cols, family_cols, cat_cols, label=label, account=account, permute=False, **kw)
    return {"ok": not r["passed"], "pooled_delta": r["pooled_delta"],
            "delta_ci95_account_bootstrap": r["delta_ci95_account_bootstrap"], "passed_under_shuffle": r["passed"]}
