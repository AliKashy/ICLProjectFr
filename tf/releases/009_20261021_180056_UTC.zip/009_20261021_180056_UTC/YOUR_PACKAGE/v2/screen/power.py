"""Power of PASS_RULE on synthetic out-of-fold scores (CPU only, no model fitting).

Simulates what the screen sees after fitting: pooled out-of-fold scores for the base arm and the with-family
arm, for rows clustered in accounts, in K account-grouped folds and M months. Applies the three parts of
`usefulness.PASS_RULE` exactly (account-cluster bootstrap interval of the pooled AP difference above 0; at
least K-1 folds positive; at least two thirds of months with >= 50 frauds positive).

Score model (binormal, an assumption): base score s_b = z + u_acct, with z ~ N(mu, 1) for frauds and N(0, 1)
otherwise, u_acct an account effect. The family adds gamma * f, with f ~ N(1, 1) for frauds and N(0, 1)
otherwise. Each arm also gets its own tau * e (independent noise per arm), a stand-in for refitting
differences, so with gamma = 0 the difference is centred on 0 and the pass rate is the false-pass rate.
Non-fraud rows are subsampled at `neg_rate` and weighted 1/neg_rate, so AP is at the full prevalence.
"""

import numpy as np

from usefulness import _ap_sorted

MIN_MONTH_FRAUDS = 50


def _wap(y, s, w):
    o = np.argsort(-s, kind="mergesort")
    return _ap_sorted(y[o], s[o], w[o])


def simulate_once(rng, gamma, tau=0.0, mu=2.0, n_frauds=12750, prevalence=0.00148, neg_rate=0.02,
                  k=5, months=8, n_boot=200, acct_sd=0.3, frauds_per_acct=3.0, rows_per_neg_acct=200):
    n_neg = int(round(n_frauds * (1 - prevalence) / prevalence))
    m_neg = rng.binomial(n_neg, neg_rate)
    # Accounts: fraud accounts hold 1 + Poisson(frauds_per_acct - 1) frauds; non-fraud rows are spread over
    # accounts of about rows_per_neg_acct rows before subsampling.
    sizes = 1 + rng.poisson(frauds_per_acct - 1, int(n_frauds / frauds_per_acct) + 50)
    sizes = sizes[np.cumsum(sizes) <= n_frauds]
    fr_acct = np.repeat(np.arange(len(sizes)), sizes)
    n_fr = len(fr_acct)
    n_neg_acct = max(1, n_neg // rows_per_neg_acct)
    neg_acct = len(sizes) + rng.integers(0, n_neg_acct, m_neg)
    acct = np.r_[fr_acct, neg_acct]
    y = np.r_[np.ones(n_fr), np.zeros(m_neg)]
    w = np.r_[np.ones(n_fr), np.full(m_neg, 1.0 / neg_rate)]
    n_acct = len(sizes) + n_neg_acct
    u = rng.normal(0, acct_sd, n_acct)[acct]
    z = rng.normal(0, 1, len(y)) + mu * y
    f = rng.normal(0, 1, len(y)) + y
    s_b = z + u + tau * rng.normal(0, 1, len(y))
    s_w = z + u + gamma * f + tau * rng.normal(0, 1, len(y))
    fold = rng.integers(0, k, n_acct)[acct]
    month = rng.integers(0, months, len(y))
    # Rule part 1: pooled difference, account-cluster bootstrap (Poisson weights per account).
    ob, ow = np.argsort(-s_b, kind="mergesort"), np.argsort(-s_w, kind="mergesort")
    yb, yw, wb, ww = y[ob], y[ow], w[ob], w[ow]
    delta = _ap_sorted(yw, s_w[ow], ww) - _ap_sorted(yb, s_b[ob], wb)
    reps = np.empty(n_boot)
    for r in range(n_boot):
        pa = rng.poisson(1.0, n_acct).astype(float)[acct]
        reps[r] = _ap_sorted(yw, s_w[ow], ww * pa[ow]) - _ap_sorted(yb, s_b[ob], wb * pa[ob])
    lo = np.percentile(reps, 2.5)
    # Parts 2 and 3: folds and months.
    fold_pos = sum(_wap(y[fold == j], s_w[fold == j], w[fold == j]) > _wap(y[fold == j], s_b[fold == j], w[fold == j])
                   for j in range(k))
    big = [m for m in range(months) if y[month == m].sum() >= MIN_MONTH_FRAUDS]
    mon_pos = sum(_wap(y[month == m], s_w[month == m], w[month == m]) > _wap(y[month == m], s_b[month == m], w[month == m])
                  for m in big)
    ap_b = _ap_sorted(yb, s_b[ob], wb)
    passed = bool(lo > 0 and fold_pos >= k - 1 and (not big or mon_pos >= (2 / 3) * len(big)))
    return {"ap_base": ap_b, "delta": delta, "ci_lo": lo, "fold_pos": int(fold_pos), "passed": passed}


def power_curve(gammas, reps=60, seed=0, **kw):
    rng = np.random.default_rng(seed)
    out = []
    for g in gammas:
        rs = [simulate_once(rng, g, **kw) for _ in range(reps)]
        out.append({"gamma": g, "reps": reps, "ap_base_mean": float(np.mean([r["ap_base"] for r in rs])),
                    "delta_mean": float(np.mean([r["delta"] for r in rs])),
                    "delta_sd": float(np.std([r["delta"] for r in rs])),
                    "power": float(np.mean([r["passed"] for r in rs])),
                    "power_ci_only": float(np.mean([r["ci_lo"] > 0 for r in rs]))})
    return out
