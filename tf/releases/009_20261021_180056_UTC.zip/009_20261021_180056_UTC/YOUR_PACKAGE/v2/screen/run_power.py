"""Runs the PASS_RULE power study and writes power_result.json (synthetic only)."""

import json
import sys
from multiprocessing import Pool

import power

GAMMAS = [0.0, 0.02, 0.04, 0.06, 0.08, 0.12]
CONFIGS = [{"mu": 2.15, "tau": 0.0}, {"mu": 2.15, "tau": 0.2}, {"mu": 2.6, "tau": 0.0}, {"mu": 2.6, "tau": 0.2}]


def job(args):
    ci, gi, cfg, g, reps = args
    return ci, power.power_curve([g], reps=reps, seed=1000 * ci + gi, **cfg)[0]


if __name__ == "__main__":
    reps = int(sys.argv[1]) if len(sys.argv) > 1 else 40
    tasks = [(ci, gi, cfg, g, reps) for ci, cfg in enumerate(CONFIGS) for gi, g in enumerate(GAMMAS)]
    with Pool(4) as p:
        res = p.map(job, tasks)
    out = [{"config": CONFIGS[ci], "curve": sorted([r for c, r in res if c == ci], key=lambda r: r["gamma"])}
           for ci in range(len(CONFIGS))]
    json.dump({"reps_per_point": reps, "n_boot": 200, "frauds": 12750, "folds": 5, "results": out},
              open("power_result.json", "w"), indent=1)
    for o in out:
        print(o["config"])
        for r in o["curve"]:
            print("  gamma %.2f  AP_base %.3f  dAP %.4f (sd %.4f)  power %.2f  ci-only %.2f" % (
                r["gamma"], r["ap_base_mean"], r["delta_mean"], r["delta_sd"], r["power"], r["power_ci_only"]))
