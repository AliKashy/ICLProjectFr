"""The S3 filesystem for the V2 CPU tools, which read a few columns of many large parquet files.

s3fs's defaults (a 50 MiB read-ahead block) fetch about half a file for one thin column read; with a 1 MiB block a
three-column pass over a file reads close to the bytes it needs. The V1 helper creates the filesystem (credentials
from the YAML file, never copied); this only sets the block size on the instance it returns. The model path
(train_v2, score_v2, export_v2) keeps V1's reader untouched.
"""
from fraud.data.s3_utils import make_s3_filesystem

THIN_READ_BLOCK_SIZE = 1 << 20


def thin_read_filesystem(cred_path, block_size=THIN_READ_BLOCK_SIZE):
    """V1's s3fs filesystem with a small read-ahead block (``None`` without a credentials path: local files)."""
    if not cred_path:
        return None
    fs = make_s3_filesystem(str(cred_path))
    fs.default_block_size = int(block_size)
    fs.default_cache_type = "readahead"
    return fs
