# V2 code (governing plan bridge/plans/2026-10-19-v2-one-gpu/PLAN.md). V1 model files are never edited.
