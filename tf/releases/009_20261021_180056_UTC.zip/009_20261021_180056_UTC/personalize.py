#!/usr/bin/env python3
"""Fill the package placeholders and record the exact configured file hashes (package 006's script; the V1 manifest step is
skipped when the package carries no manifest). The configured bytes are compared with the repository privately, from the hashes
the installed tools report: the public package names no hash of bytes that carry a real name or id."""
import argparse
import csv
import hashlib
import io
import json
import keyword
from pathlib import Path, PurePosixPath
import re


def digest(data):
    return hashlib.sha256(data).hexdigest()


def checked_path(root, rel):
    if not isinstance(rel, str):
        raise ValueError("invalid package path: " + str(rel))
    path = PurePosixPath(rel)
    if not rel or "\\" in rel or ":" in rel or path.is_absolute() or path.as_posix() != rel or any(p in (".", "..") for p in path.parts):
        raise ValueError("invalid package path: " + str(rel))
    current = root
    for part in path.parts:
        current /= part
        if current.is_symlink():
            raise ValueError("package symlink is not supported: " + rel)
    return current


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", required=True)
    parser.add_argument("--id", required=True)
    parser.add_argument("--reference-id", required=True)
    parser.add_argument("--data-bucket", required=True)
    parser.add_argument("--artifact-bucket", required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    try:
        if not args.package.isidentifier() or keyword.iskeyword(args.package) or args.package in {"YOUR_PACKAGE", "fraud", "src", "runbook"}:
            raise ValueError("--package must be the original Python package directory name")
        for value in (args.id, args.reference_id):
            if not re.fullmatch(r"[Kk][0-9]{6}", value):
                raise ValueError("each ID must be k followed by six digits")
        for value in (args.data_bucket, args.artifact_bucket):
            if not re.fullmatch(r"[a-z0-9][a-z0-9.-]+", value):
                raise ValueError("bucket arguments are names, without s3:// or a path")
        if (root / "PERSONALIZATION.json").exists():
            raise ValueError("this copy is already configured; extract a fresh copy to change settings")
        if (root / args.package).exists():
            raise ValueError("the destination package directory already exists")
        meta = json.loads((root / "PACKAGE.json").read_text())
        for rel, expected in meta["files_sha256"].items():
            path = checked_path(root, rel)
            if not path.is_file() or digest(path.read_bytes()) != expected:
                raise ValueError("package file changed or missing before setup: " + rel)
        replacements = {"YOUR_PACKAGE": args.package, "YOUR_ID": args.id.upper(), "your_id": args.id.lower(),
                        "REFERENCE_ID": args.reference_id.upper(), "reference_id": args.reference_id.lower(),
                        "DATA_BUCKET": args.data_bucket, "ARTIFACT_BUCKET": args.artifact_bucket}
        changes = {}
        for rel in meta["personalize_files"]:
            if rel not in meta["files_sha256"]:
                raise ValueError("unlisted personalization file: " + rel)
            text = checked_path(root, rel).read_text()
            for before, after in replacements.items():
                text = text.replace(before, after)
            changes[rel] = text.encode()
        for rel, data in changes.items():
            checked_path(root, rel).write_bytes(data)
        (root / "YOUR_PACKAGE").rename(root / args.package)
        for key in ("existing_dependency_files_sha256_lf", "existing_dependency_files_observed_only"):  # the package name back into PACKAGE.json's paths
            if isinstance(meta.get(key), dict):
                meta[key] = {rel.replace("YOUR_PACKAGE", args.package): value for rel, value in meta[key].items()}
        (root / "PACKAGE.json").write_text(json.dumps(meta, indent=2) + "\n")
        manifest = root / "runbook/2026-10-07/github_source_manifest.csv"
        manifest_sha256 = None
        if manifest.is_file():  # the V1 source manifest ships only with a V1 package; this package leaves the pod's copy alone
            rows = list(csv.DictReader(io.StringIO(manifest.read_text())))
            packaged_paths = {rel.replace("YOUR_PACKAGE", args.package) for rel in meta["files_sha256"]}
            existing_dependencies = meta.get("existing_dependency_files_sha256_lf", {})
            for row in rows:
                row["path"] = row["path"].replace("YOUR_PACKAGE", args.package)
                if row["path"] in packaged_paths:
                    row["sha256_lf"] = digest(checked_path(root, row["path"]).read_bytes().replace(b"\r\n", b"\n"))
                elif existing_dependencies.get(row["path"]) != row["sha256_lf"]:
                    raise ValueError("manifest path is neither packaged nor an unchanged existing dependency: " + row["path"])
            with manifest.open("w", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=["path", "sha256_lf", "class"], lineterminator="\n")
                writer.writeheader()
                writer.writerows(rows)
            manifest_sha256 = digest(manifest.read_bytes())
        paths = [rel.replace("YOUR_PACKAGE", args.package) for rel in meta["files_sha256"]] + ["PACKAGE.json"]
        record = {"package": meta["package"], "source_commit": meta["source_commit"], "replacements": replacements,
                  "personalized_source_manifest_sha256": manifest_sha256,
                  "files_sha256": {rel: digest(checked_path(root, rel).read_bytes()) for rel in sorted(paths)}}
        (root / "PERSONALIZATION.json").write_text(json.dumps(record, indent=2) + "\n")
        print("Configured:", meta["package"])
        print("Next: python install.py --target /path/to/existing/project")
    except (ValueError, KeyError, OSError, UnicodeError) as error:
        parser.exit(1, "Setup stopped: " + str(error) + "\n")


if __name__ == "__main__":
    main()
