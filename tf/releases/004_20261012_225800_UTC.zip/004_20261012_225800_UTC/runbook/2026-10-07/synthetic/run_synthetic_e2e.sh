#!/usr/bin/env bash
# reviewer's CPU harness (2026-10-07, v2), never for the pod. Generates synthetic parquet with the real schema in a fake
# S3 folder, builds artifacts with the real build script, runs batch1.sh and then batch2.sh unchanged except for the
# sandbox flag (tiny model, 1 epoch, batch / 32, no workers), then resumes batch2.sh once. Exit 0 only if every stage
# passed; the one accepted failure (named in the output) is batch 2's REF-SINGLE step until run_step.py accepts
# --phase base (lane L1, build item B8).
#     bash runbook/2026-10-07/synthetic/run_synthetic_e2e.sh <new sandbox folder> [accounts_per_file]
set -uo pipefail
SB="$(realpath -m "${1:?sandbox folder}")"; ACC="${2:-40}"
REPO="$(cd "$(dirname "$0")/../../.." && pwd)"
[ -e "$SB" ] && { echo "sandbox $SB exists; give a new folder"; exit 2; }
mkdir -p "$SB"
# RUNBOOK_BANK_OVERRIDES=1 is the explicit flag the batch scripts and the pre-flight require before they accept the
# harness variable RUNBOOK_SANDBOX (first release, inherited harness state); the pre-flight records it as an override.
export FAKE_S3_ROOT="$SB/fake_s3" TF_REPO_ROOT="$REPO" RUNBOOK_SANDBOX="$SB" RUNBOOK_BANK_OVERRIDES=1
# EXTRA_PYTHONPATH (optional) goes first, e.g. a folder with pandas 2.x to test the supported dependency range.
export PYTHONPATH="${EXTRA_PYTHONPATH:+$EXTRA_PYTHONPATH:}$REPO/runbook/2026-10-07/synthetic:$REPO/src:$REPO"
python3 -c "import pandas, torch, pytorch_lightning as pl; print('harness env: pandas', pandas.__version__, '| torch', torch.__version__, '| lightning', pl.__version__)"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-2}"
cd "$REPO"
# Refuse to run unless the fake-S3 redirect is active: every later step writes to the real YOUR_ID paths, and only
# the redirect keeps them inside the sandbox.
python3 -c "import sys, fraud.data.s3_utils as s; sys.exit(0 if getattr(s.make_s3_filesystem, '__name__', '') == '_fake_make_s3_filesystem' else 3)" \
  || { echo "HARNESS REFUSED: the fake-S3 redirect is not active; nothing was run"; exit 1; }
python3 runbook/2026-10-07/synthetic/make_synthetic_data.py --accounts "$ACC" > "$SB/data_summary.txt" \
  || { echo "HARNESS FAILED: data generation"; exit 1; }
cat "$SB/data_summary.txt"
python3 fraud/scripts/build_preprocessing_artifacts.py --config fraud/configs/preprocessing.yaml \
  build.output_base=s3://ARTIFACT_BUCKET/YOUR_ID/tabular_fraud/artifacts > "$SB/build_artifacts.log" 2>&1 \
  || { echo "HARNESS FAILED: artifact build"; tail -20 "$SB/build_artifacts.log"; exit 1; }
echo "== batch1.sh (sandbox)"
bash runbook/2026-10-07/batch1.sh; b1=$?
if [ $b1 -ne 0 ]; then echo "HARNESS FAILED: batch1 exit $b1 (remaining specs not run)"; exit 1; fi
echo "== batch2.sh (sandbox): batch 1 ledger check, post-hoc scoring of batch 1 into the return folder, then every"
echo "   batch 2 step (V1 stage 2 at seed 42, steps 2.1 to 2.8)"
bash runbook/2026-10-07/batch2.sh; b2=$?
RET="$SB/returns/batch2_summary"
for f in POST_SCORE.txt post_score_results.csv RETURN.txt run_log_batch2.csv; do
  [ -s "$RET/$f" ] || { echo "HARNESS FAILED: batch 2 return folder is missing $f"; b2=99; }
done
ST="$RET/BATCH_STATUS.txt"
grep -q "finished the post-hoc scoring: exit 0" "$ST" || { echo "HARNESS FAILED: batch 2 post-hoc scoring did not finish with exit 0"; b2=99; }
# Every step line of batch2.sh must have run and finished; the one accepted failure is the REF-SINGLE step while
# run_step.py does not accept --phase base yet (lane L1, build item B8). Any other failed step fails the harness.
steps=$(sed -n 's/^ *"\(base\|phase4[ab]\) \([A-Za-z0-9_.]*\.yaml\)".*/\2/p' runbook/2026-10-07/batch2.sh)
bad=""; accepted=""
for s in $steps; do
  line=$(grep " finished $s: run_step exit " "$ST" | tail -1)
  if [ -z "$line" ]; then bad="$bad $s(not_run)"; continue; fi
  case "$line" in *"run_step exit 0;"*) continue ;; esac
  if [ "$s" = ref_single.yaml ] && ! python3 runbook/2026-10-07/run_step.py --phase base --help >/dev/null 2>&1; then
    accepted="$s"; continue
  fi
  bad="$bad $s"
done
[ -n "$accepted" ] && echo "HARNESS ACCEPTED FAILURE: $accepted (run_step.py --phase base is refused until lane L1, build item B8, lands)"
[ -n "$bad" ] && { echo "HARNESS FAILED: batch 2 steps not ok:$bad"; b2=99; }
if [ $b2 -eq 1 ] && [ -n "$accepted" ] && [ -z "$bad" ]; then b2=0; fi
# Resume: every finished step and the post-hoc scoring are skipped; only a step that did not finish ACCEPTED runs again.
echo "== batch2.sh resume (sandbox)"
BATCH2_RESUME="$RET" bash runbook/2026-10-07/batch2.sh > "$SB/batch2_resume.log" 2>&1; b2r=$?
cat "$SB/batch2_resume.log"
grep -q "resume: skipped the post-hoc scoring" "$ST" || { echo "HARNESS FAILED: the resume did not skip the post-hoc scoring"; b2=99; }
for s in $steps; do
  [ "$s" = "$accepted" ] && continue
  grep -q "resume: skipped $s " "$ST" || { echo "HARNESS FAILED: the resume did not skip the finished step $s"; b2=99; }
done
echo "HARNESS DONE: batch1 exit $b1, batch2 exit $b2 (resume exit $b2r); ledger $SB/runs/run_log.csv; batch 2 return $RET"
exit $b2
