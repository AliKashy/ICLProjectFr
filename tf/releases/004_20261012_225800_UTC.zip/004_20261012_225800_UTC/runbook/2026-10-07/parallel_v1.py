#!/usr/bin/env python3
"""Run the existing V1 cells on two pods sharing this checkout and output folder.

prepare runs the existing stage checks once; run starts only the named pod's
queues; finish collects both pods' returns. No training setting is changed.
Stage all puts the 15 V1 cells in one plan (owner, 2026-10-12): the full
pre-flight at prepare, and batch 2's step 2.0 (scoring the three
validation-only cells) at finish, after the job ledgers are merged.
Use --pod all to continue both pods' unfinished queues serially on one GPU.
Completed jobs are skipped. --retry-failed starts failed/interrupted jobs in new
attempts; their old diagnostics remain. Stage 5 is still started separately.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
from contextlib import ExitStack
import csv
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import signal
import subprocess
import threading
import sys
import time
import traceback
import uuid

from omegaconf import OmegaConf

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
from analysis_runs import V1_RUNS
from run_step import HostSampler, child_env, inherited_state_message, sandbox_spec

QUEUES = {
    "batch1": {
        "four": [["A-H10", "A-GAP10-OFF"], ["A-H00"], ["A-H05"], ["B-H05"]],
        "one": [["B-H10"]],
    },
    "batch2": {
        "four": [["A-H20"], ["A-H15"], ["B-H20"], ["B-H15", "B-ALLPOS-H5"]],
        "one": [["REF-SINGLE", "B-H00", "A-MASK05-C", "A-GAP05-OFF"]],
    },
    # All 15 V1 cells in one plan. The four-GPU pod is temporary: its queues run the longest cells first, so the big
    # runs end while it exists; the longest cell (A-H20) is on the pod that stays. A-H10 precedes A-GAP10-OFF (the
    # comparator gate). What the four-GPU pod leaves unfinished continues with run --pod all --retry-failed.
    "all": {
        "four": [["A-H15", "A-H00", "A-H05"], ["B-H20", "B-H15"], ["A-H10", "A-GAP10-OFF", "REF-SINGLE", "B-H00"],
                 ["B-ALLPOS-H5", "B-H05", "B-H10", "A-MASK05-C", "A-GAP05-OFF"]],
        "one": [["A-H20"]],
    },
}
CELLS = {row[0]: row for row in V1_RUNS}
STOP = threading.Event()


def sandbox():
    """reviewer's CPU harness only (RUNBOOK_SANDBOX, accepted only with RUNBOOK_BANK_OVERRIDES=1): its folder, else None."""
    sb = os.environ.get("RUNBOOK_SANDBOX")
    return Path(sb).resolve() if sb else None


def runs_base():
    """Where runs/returns and runs/run_log.csv live: the checkout, or the sandbox as in the batch scripts."""
    return sandbox() or ROOT


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    tmp.write_text(json.dumps(value, indent=2) + "\n")
    tmp.replace(path)


def read_json(path):
    return json.loads(Path(path).read_text())


def copy_diagnostics(source, target):
    """Keep all existing diagnostic files; checkpoints and row predictions stay put."""
    source, target = Path(source), Path(target)
    if not source.is_dir():
        return
    for path in source.rglob("*"):
        if path.is_file() and path.suffix not in (".ckpt", ".parquet"):
            dest = target / path.relative_to(source)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, dest)


def native_runner(phase):
    path = ROOT / "YOUR_PACKAGE" / phase / "scripts" / "run_ablations.py"
    spec = importlib.util.spec_from_file_location("parallel_native_" + phase, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def single_cell(name, attempt_tag):
    """Select a native axis choice, retaining its names, settings and output_root."""
    _, output_root, run_name, spec_file = CELLS[name]
    original = OmegaConf.load(ROOT / spec_file)
    phase = Path(spec_file).parts[1]
    matches = [r for r in native_runner(phase)._expand_runs(original)[1] if r[0] == run_name]
    if len(matches) != 1:
        raise ValueError(f"{name}: expected one native cell named {run_name}")
    choice = matches[0][2]
    derived = OmegaConf.create(OmegaConf.to_container(original, resolve=False))
    derived.axes = {axis: {option: original.axes[axis][option]} for axis, option in choice.items()}
    derived.attempt_tag = attempt_tag
    attempt = ROOT / output_root / attempt_tag
    if sandbox():
        attempt = Path(sandbox_spec(derived, sandbox())) / attempt_tag
    # The native runner writes its attempt CSV and latest-view CSV atomically.
    # Point both at this attempt so independent cells never replace a shared view.
    derived.results_csv = str(attempt / "results.csv")
    return phase, derived, attempt


def new_attempt(job, tag=None):
    tag = tag or (job["name"] + "-" + uuid.uuid4().hex)
    phase, spec, attempt = single_cell(job["name"], tag)
    folder = Path(job["folder"]) / "attempts" / tag
    folder.mkdir(parents=True, exist_ok=False)
    spec_path = folder / "spec.yaml"
    OmegaConf.save(spec, spec_path)
    return {"tag": tag, "attempt": str(attempt), "folder": str(folder),
            "spec": str(spec_path), "phase": phase}


def command(args, log, env=None):
    with open(log, "w") as stream:
        return subprocess.run([sys.executable, *map(str, args)], cwd=ROOT,
                              stdout=stream, stderr=subprocess.STDOUT,
                              env=env if env is not None else child_env()).returncode



def record_batch1_comparator(out, session, ledger, preflight):
    """Preserve batch2.sh's record-only check; no batch 2 cell depends on it."""
    record = runs_base() / "runs" / "returns" / f"parallel_{session}_batch1" / "SHARED_COMPARATOR.txt"
    lines = record.read_text().splitlines() if record.is_file() else []
    attempts = [line.partition("=")[2] for line in lines if line.startswith("A_H10_COMPARATOR=")]
    attempt = attempts[-1] if attempts else ""
    if not attempt:
        (out / "SHARED_COMPARATOR.txt").write_text(
            "record_only=yes\nA_H10_COMPARATOR=\nNo batch 1 comparator record found; nothing is stopped.\n")
        return
    command([HERE / "batch_tools.py", "comparator", "--attempt", attempt,
             "--phase", "phase4a", "--spec", "ft_decisions_flat_h10.yaml", "--ledger", ledger,
             "--record", out / "SHARED_COMPARATOR.txt", "--files-out", out / "comparator_source_files.csv",
             "--origin", "batch1_return", "--batch-preflight", preflight,
             "--used-by", "record only (batch 2): source and settings since batch 1"],
            out / "comparator.log")


def prepare(stage, session):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", session):
        raise ValueError("session must contain only letters, numbers, dots, underscores or hyphens")
    stop = inherited_state_message()
    if stop:
        raise ValueError(stop)
    out = runs_base() / "runs" / "returns" / f"parallel_{session}_{stage}"
    out.mkdir(parents=True, exist_ok=False)
    ledger = runs_base() / "runs" / "run_log.csv"
    if stage == "batch2":
        if command([HERE / "batch_tools.py", "batch1-ledger", "--ledger", ledger],
                   out / "batch1_ledger.log"):
            raise RuntimeError(f"existing batch 1 ledger check failed; see {out}")
    # PREFLIGHT_ARGS as the batch scripts pass it (reviewer's harness only; on the pod inherited_state_message refuses it).
    pf_args = [HERE / "preflight_pod.py", "--out-root", out / "preflight", *shlex.split(os.environ.get("PREFLIGHT_ARGS", ""))]
    if stage == "batch2":
        pf_args.append("--skip-tests")
    rc = command(pf_args, out / "preflight.log")
    lines = (out / "preflight.log").read_text().splitlines()
    paths = [line.partition("=")[2] for line in lines if line.startswith("PREFLIGHT_DIR=")]
    preflight = Path(paths[-1]).resolve() if paths else out / "missing_preflight"
    summary = (preflight / "SUMMARY.txt").read_text() if (preflight / "SUMMARY.txt").is_file() else ""
    if rc or not re.search(r"^RESULT:? PASS\b", summary, re.M) or not (preflight / "data_contract.json").is_file():
        raise RuntimeError(f"existing pre-flight did not pass; see {out}")
    if stage == "batch2":
        # Same batch 2 step 2.0: evaluation scoring of batch 1's three validation-only cells.
        rc = command([HERE / "score_attempt.py", "--from-ledger", ledger, "--preflight", preflight,
                      "--return-dir", out / "post_score"], out / "post_score.log")
        # As in batch2.sh, a scoring failure is reported while later cells may still run.
        (out / "POST_SCORE_EXIT.txt").write_text(str(rc) + "\n")
        record_batch1_comparator(out, session, ledger, preflight)
    jobs = {}
    for pod, queues in QUEUES[stage].items():
        for slot, names in enumerate(queues):
            for name in names:
                job = {"name": name, "pod": pod, "slot": slot, "folder": str(out / "jobs" / name)}
                job["initial"] = new_attempt(job)
                jobs[name] = job
    plan = {"schema": 1, "stage": stage, "session": session, "root": str(ROOT),
            "folder": str(out), "ledger": str(ledger), "preflight": str(preflight),
            "queues": QUEUES[stage], "jobs": jobs}
    write_json(out / "PLAN.json", plan)
    print(f"PLAN={out / 'PLAN.json'}", flush=True)
    return out / "PLAN.json"


def gpu_devices(count, environ=None):
    """Map queue slots through an inherited CUDA mask; never inspect availability."""
    environ = os.environ if environ is None else environ
    if "CUDA_VISIBLE_DEVICES" not in environ:
        return [str(n) for n in range(count)]
    visible = [v.strip() for v in environ["CUDA_VISIBLE_DEVICES"].split(",") if v.strip()]
    if len(visible) < count or len(set(visible)) != len(visible) or "-1" in visible:
        raise ValueError(f"CUDA_VISIBLE_DEVICES must name {count} distinct queue devices for this pod")
    return visible[:count]


def job_environment(device):
    env = child_env()
    env["CUDA_VISIBLE_DEVICES"] = device
    return env


def check_comparator(plan, env, log):
    state_path = Path(plan["jobs"]["A-H10"]["folder"]) / "STATE.json"
    if not state_path.is_file():
        Path(log).write_text("A-H10 has not finished.\n")
        return 1
    state = read_json(state_path)
    if state["status"] != "completed":
        Path(log).write_text("A-H10 has no completed accepted attempt.\n")
        return 1
    spec_file = []
    if sandbox():  # check against the reduced copy the sandbox trained on, as batch1.sh does with --spec-file
        reduced = OmegaConf.load(ROOT / "YOUR_PACKAGE/phase4a/configs/ft_decisions_flat_h10.yaml")
        sandbox_spec(reduced, sandbox())
        path = Path(plan["folder"]) / "sandbox_specs" / "phase4a_ft_decisions_flat_h10.yaml"
        path.parent.mkdir(parents=True, exist_ok=True)
        OmegaConf.save(reduced, path)
        spec_file = ["--spec-file", path]
    return command([HERE / "batch_tools.py", "comparator", "--attempt", state["current"]["attempt"],
                    "--phase", "phase4a", "--spec", "ft_decisions_flat_h10.yaml", *spec_file,
                    "--ledger", Path(plan["jobs"]["A-H10"]["folder"]) / "run_log.csv", "--record", Path(plan["folder"]) / "SHARED_COMPARATOR.txt",
                    "--files-out", Path(plan["folder"]) / "comparator_source_files.csv", "--origin", "own",
                    "--batch-preflight", plan["preflight"]], log, env)


def execute_attempt(plan, job, current, env):
    folder, attempt = Path(current["folder"]), Path(current["attempt"])
    gpu = host = proc = None
    gpu_stream = None
    runner_rc, collector_rc = 1, 1
    try:
        with open(folder / "runner.log", "w") as log:
            proc = subprocess.Popen([sys.executable, str(ROOT / "YOUR_PACKAGE" / current["phase"] / "scripts" /
                                                       "run_ablations.py"), "--config", current["spec"]],
                                    cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
            host = HostSampler(proc.pid, str(folder / "host_rss.csv"), 30)
            host.start()
            if shutil.which("nvidia-smi"):
                device = env["CUDA_VISIBLE_DEVICES"]
                is_uuid = device.startswith("GPU-")
                gpu_name = "gpu.csv" if is_uuid else "gpu_pod.csv"
                gpu_stream = open(folder / gpu_name, "w")
                (folder / "GPU_SCOPE.txt").write_text(
                    "Selected GPU UUID only.\n" if is_uuid else
                    "Pod-wide samples; numeric CUDA order is not assumed to match nvidia-smi.\n")
                selection = ["--id=" + device] if is_uuid else []
                gpu = subprocess.Popen(["nvidia-smi", *selection,
                                        "--query-gpu=timestamp,memory.used,utilization.gpu", "--format=csv", "-l", "30"],
                                       stdout=gpu_stream, stderr=subprocess.DEVNULL)
            while True:
                try:
                    runner_rc = proc.wait(timeout=0.5)
                    break
                except subprocess.TimeoutExpired:
                    if STOP.is_set():
                        os.killpg(proc.pid, 15)
                        runner_rc = proc.wait()
                        break
    finally:
        if proc is not None and proc.poll() is None:
            os.killpg(proc.pid, 15)
            proc.wait()
        if host is not None:
            host.stop()
        if gpu is not None:
            gpu.terminate()
            gpu.wait()
        if gpu_stream is not None:
            gpu_stream.close()
        if attempt.is_dir():
            for src, dest in (("gpu.csv", "gpu_sweep.csv"), ("host_rss.csv", "host_rss_sweep.csv")):
                if (folder / src).is_file():
                    shutil.copy2(folder / src, attempt / dest)
            collector_rc = command([HERE / "collect_returns.py", attempt, "--ledger", Path(job["folder"]) / "run_log.csv",
                                    "--preflight", plan["preflight"], "--out", folder], folder / "collector.log", env)
            copy_diagnostics(attempt, folder / "native")
        else:
            (folder / "RETURN.txt").write_text("NOT ACCEPTED: native runner created no attempt; see runner.log.\n")
    return runner_rc, collector_rc


def run_job(plan, name, device, retry_failed=False):
    if STOP.is_set():
        return 1
    job = plan["jobs"][name]
    folder = Path(job["folder"])
    state_path = folder / "STATE.json"
    with open(folder / "CLAIM.lock", "a+") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print(f"{name}: already running in another invocation", flush=True)
            return 1
        previous = read_json(state_path) if state_path.is_file() else None
        if previous and previous["status"] == "completed":
            print(f"{name}: completed; skipped", flush=True)
            return 0
        if previous and not retry_failed:
            print(f"{name}: {previous['status']}; use --retry-failed for a new attempt", flush=True)
            return 1
        if previous:
            old = previous["current"]
            old_attempt, old_folder = Path(old["attempt"]), Path(old["folder"])
            if old_attempt.is_dir():
                if previous["status"] == "running":
                    command([HERE / "collect_returns.py", old_attempt, "--ledger", folder / "run_log.csv",
                             "--preflight", plan["preflight"], "--out", old_folder / "interrupted_collect"],
                            old_folder / "interrupted_collect.log")
                copy_diagnostics(old_attempt, old_folder / "native")
        current = new_attempt(job) if previous else job["initial"]
        attempts = (previous["attempts"] if previous else []) + [current]
        state = {"status": "running", "current": current, "attempts": attempts,
                 "device": device, "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
        write_json(state_path, state)
        Path(current["folder"], "STEP.txt").write_text(
            f"cell: {name}\nattempt_dir: {current['attempt']}\nCUDA_VISIBLE_DEVICES: {device}\n")
        try:
            env = job_environment(device)
            if name == "A-GAP10-OFF" and check_comparator(plan, env, Path(current["folder"]) / "comparator.log"):
                state["status"] = "blocked: A-H10 comparator"
            else:
                print(f"{name}: starting on visible device {device}", flush=True)
                runner_rc, collector_rc = execute_attempt(plan, job, current, env)
                state.update(runner_exit=runner_rc, collector_exit=collector_rc,
                             status="completed" if runner_rc == collector_rc == 0 else "failed")
        except Exception:
            state["status"] = "failed"
            Path(current["folder"], "error.txt").write_text(traceback.format_exc())
        state["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        write_json(state_path, state)
        print(f"{name}: {state['status']}", flush=True)
        return int(state["status"] != "completed")


def run_pod(plan, pod, retry_failed=False):
    # Serial continuation owns both queues; it must not overlap either pod.
    owners = ("four", "one") if pod == "all" else (pod,)
    with ExitStack() as locks:
        for owner in owners:
            lock = locks.enter_context(open(Path(plan["folder"]) / (owner + ".lock"), "a+"))
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                print(f"{owner}: this plan is already running on this pod", flush=True)
                return 1
        return _run_pod(plan, pod, retry_failed)


def _run_pod(plan, pod, retry_failed=False):
    stop = inherited_state_message()
    if stop:
        raise ValueError(stop)
    queues = ([[name for owner in ("four", "one")
                for queue in plan["queues"][owner] for name in queue]]
              if pod == "all" else plan["queues"][pod])
    devices = gpu_devices(len(queues))

    def queue(slot):
        failed = 0
        for name in queues[slot]:
            failed |= run_job(plan, name, devices[slot], retry_failed)
        return failed

    STOP.clear()
    pool = ThreadPoolExecutor(max_workers=len(queues))
    try:
        results = list(pool.map(queue, range(len(queues))))
    except KeyboardInterrupt:
        STOP.set()
        raise
    finally:
        pool.shutdown(wait=True)
    return int(any(results))


def retry_score(plan):
    """Retry only batch 2 step 2.0, using native reuse of previously scored checkpoints."""
    if plan["stage"] != "batch2":
        raise ValueError("retry-score applies only to batch2")
    out = Path(plan["folder"])
    # Run this command on the four-GPU pod, before starting or after finishing
    # its queues. It must not compete with that pod's training on GPU 0.
    with open(out / "four.lock", "a+") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print("four: training is running; retry scoring after its queues finish", flush=True)
            return 1
        if (out / "POST_SCORE_EXIT.txt").read_text().strip() == "0":
            print("Batch 2 step 2.0 already completed; skipped", flush=True)
            return 0
        target = out / ("post_score_retry_" + uuid.uuid4().hex)
        rc = command([HERE / "score_attempt.py", "--from-ledger", plan["ledger"],
                      "--preflight", plan["preflight"], "--return-dir", target],
                     out / (target.name + ".log"))
        (out / "POST_SCORE_EXIT.txt").write_text(str(rc) + "\n")
        return rc


def score_validation_only_cells(plan):
    """Stage all: batch 2's step 2.0 on the merged ledger, scoring the three validation-only cells (A-H00, A-H05,
    A-GAP10-OFF) on the evaluation files. It runs at every finish, so a cell completed by a later --retry-failed is
    scored too; after the first run it writes a new folder (the scorer never overwrites, and reuses checkpoints it
    already scored and validated). POST_SCORE_EXIT.txt records the latest run."""
    out = Path(plan["folder"])
    exit_file = out / "POST_SCORE_EXIT.txt"
    target = out / "post_score" if not (out / "post_score").exists() else out / ("post_score_retry_" + uuid.uuid4().hex)
    rc = command([HERE / "score_attempt.py", "--from-ledger", plan["ledger"], "--preflight", plan["preflight"],
                  "--return-dir", target], out / (target.name + ".log"))
    exit_file.write_text(str(rc) + "\n")
    return rc


def finish(plan):
    out = Path(plan["folder"])
    states = {name: read_json(Path(job["folder"]) / "STATE.json")
              if (Path(job["folder"]) / "STATE.json").is_file() else {"status": "not started"}
              for name, job in plan["jobs"].items()}
    lines = [f"{name}: {state['status']}" for name, state in states.items()]
    (out / "FINISH.txt").write_text("\n".join(lines) + "\n")
    print("\n".join(lines), flush=True)
    if any(s["status"] in ("running", "not started") for s in states.values()):
        print("Both pod queues must finish before collecting the batch return.", flush=True)
        return 1
    # Only this finish command writes the shared ledger. Job collectors used
    # separate ledgers, so concurrent pods do not need a shared append lock.
    from collect_returns import append_ledger
    conflicts = []
    shared = Path(plan["ledger"])
    with open(shared, newline="") if shared.is_file() else open(os.devnull) as stream:
        recorded = {(r["attempt_dir"], r["run_name"], r["evidence_sha256"]) for r in csv.DictReader(stream)}
    for job in plan["jobs"].values():
        ledger = Path(job["folder"]) / "run_log.csv"
        if not ledger.is_file():
            continue
        with open(ledger, newline="") as stream:
            rows = [r for r in csv.DictReader(stream)
                    if (r["attempt_dir"], r["run_name"], r["evidence_sha256"]) not in recorded]
        _, _, found = append_ledger(plan["ledger"], rows, time.strftime("%Y%m%dT%H%M%SZ", time.gmtime()))
        conflicts.extend(found)
        recorded.update((r["attempt_dir"], r["run_name"], r["evidence_sha256"]) for r in rows)
    write_json(out / "LEDGER_CONFLICTS.json", conflicts)
    if plan["stage"] == "all":
        score_validation_only_cells(plan)
    current = [s["current"]["attempt"] for s in states.values() if Path(s["current"]["attempt"]).is_dir()]
    all_attempts = [a["attempt"] for s in states.values() for a in s.get("attempts", [])]
    rc = command([HERE / "collect_returns.py", "--no-ledger", "--preflight", plan["preflight"], "--out", out,
                  *current], out / "collect.log") if current else 1
    ledger_rc = command([HERE / "batch_tools.py", "ledger-rows", "--ledger", plan["ledger"],
             "--out", out / ("run_log_" + plan["stage"] + ".csv"), *all_attempts], out / "ledger.log")
    post_rc = int((out / "POST_SCORE_EXIT.txt").read_text()) if (out / "POST_SCORE_EXIT.txt").is_file() else 0
    return int(bool(rc or ledger_rc or post_rc or conflicts or any(s["status"] != "completed" for s in states.values())))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("prepare")
    p.add_argument("--stage", choices=tuple(QUEUES), required=True)
    p.add_argument("--session", required=True)
    for action in ("run", "finish", "retry-score"):
        p = sub.add_parser(action)
        p.add_argument("--plan", required=True)
        if action == "run":
            p.add_argument("--pod", choices=("four", "one", "all"), required=True)
            p.add_argument("--retry-failed", action="store_true")
    args = parser.parse_args(argv)
    try:
        if args.command == "prepare":
            prepare(args.stage, args.session)
            return 0
        plan = read_json(args.plan)
        if plan.get("root") != str(ROOT):
            raise ValueError("run from the same shared checkout path that prepared this plan")
        if args.command == "run":
            def interrupt(signum, frame):
                raise KeyboardInterrupt
            signal.signal(signal.SIGTERM, interrupt)
            if signal.getsignal(signal.SIGHUP) is not signal.SIG_IGN:  # under nohup a closed terminal stops nothing
                signal.signal(signal.SIGHUP, interrupt)
            return run_pod(plan, args.pod, args.retry_failed)
        return retry_score(plan) if args.command == "retry-score" else finish(plan)
    except KeyboardInterrupt:
        return 130
    except (ValueError, RuntimeError, OSError) as exc:
        print(str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
