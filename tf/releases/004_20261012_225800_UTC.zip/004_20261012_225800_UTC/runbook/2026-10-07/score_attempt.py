#!/usr/bin/env python3
# Written by reviewer (2026-10-07), v3 after review's delta review of e8832fd (D1-D3 in
# bridge/reviews/review/2026-10-07-PR3-a987168/latest_delta_review.md). Scores the validation-only runs of a finished
# attempt on the evaluation files their frozen config names, with the project's own score_sequential.py. Every
# scoring is a new, isolated, never-overwritten folder <run_dir>/post_score/<UTC time>-<uuid4 hex>/; one
# short summary table is printed.
"""Score an attempt's validation-only checkpoints after the fact.

    python runbook/2026-10-07/score_attempt.py <attempt dir> [<attempt dir> ...]
    python runbook/2026-10-07/score_attempt.py --from-ledger runs/run_log.csv
    python runbook/2026-10-07/score_attempt.py <attempt dir> --override-eval-files 8000-8005   (recorded as override)

REF-SINGLE attempts (base config under YOUR_PACKAGE/base/, V1 build item B8) are scored with score_streaming.py.
Prediction files and checkpoints stay on the pod (the owner's answer to OQ-24); --return-dir copies every other file.

Per run whose runner status is ok, in this order (the first failing check names the status):
  ckpt_changed      best.ckpt is missing or its SHA-256 differs from the results row.
  config_changed    resolved_train.yaml's recomputed SHA-256 differs from the results row's or run_manifest.json's
                    resolved_train_sha256 (or one of them is missing). The child is not launched.
  skipped:valid_exists  a previous post_score/<id>/ for the same checkpoint SHA-256, the same resolved_train SHA-256
                    and the same evaluation range passes the full validation below. Invalid previous folders are
                    listed as prior_invalid and do not count; a new folder is made.
  ok / score_failed / invalid_output / source_changed   the result of a new scoring.
Scoring writes into its folder: resolved_score.yaml (the effective config passed to the child, every override
included), post_score_metrics.json (the child's output), score.log and post_score_manifest.json (checkpoint path and
SHA-256, resolved_train SHA-256 recorded and recomputed, the exact command, return code, UTC start/end, Python and
package versions, runtime source SHA-256 before/after and versus the training run).
The child's metrics must satisfy exactly the A/B runner's contract (_score_metrics in
YOUR_PACKAGE/phase4a/scripts/run_ablations.py, with metrics required). The evaluation file range comes from the frozen
config unless --override-eval-files is given. Selection is untouched: these eval numbers are for reporting the
already-chosen checkpoints. Exit 0 only if no checked run failed or produced invalid output.
"""
import argparse
import csv
import datetime as _dt
import hashlib
from importlib.metadata import PackageNotFoundError, version
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import uuid

from omegaconf import OmegaConf

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
POST_SCHEMA = "tf-post-score-v1"
LEDGER_V2, LEDGER_V3, LEDGER_V4 = "tf-runbook-ledger-v2", "tf-runbook-ledger-v3", "tf-runbook-ledger-v4"
LEDGER_V5 = "tf-runbook-ledger-v5"
# Same revision semantics; v4 adds the cohort_check column, v5 the configuration-identity columns (RUN-10).
REVISIONED = (LEDGER_V3, LEDGER_V4, LEDGER_V5)
# Same file set and digest as run_ablations._source_provenance (phase4a == phase4b), so the post-score value is
# directly comparable with the results row's source_sha256 of the training run.
SOURCE_CONVENTION = ("run_ablations._source_provenance: sha256 of json.dumps({path relative to repo: sha256(bytes)}, "
                     "sort_keys=True) over fraud/**/*.py, YOUR_PACKAGE/**/*.py, pyproject.toml, requirements.txt")
PACKAGES = ("torch", "pytorch-lightning", "numpy", "pandas", "pyarrow", "omegaconf", "scikit-learn")
FAILURES = {"ckpt_changed", "config_changed", "scored_invalid", "score_failed", "invalid_output", "source_changed",
            "launch_failed", "not_in_results", "attempt_unreadable", "cohort_mismatch"}


SCORERS = {"phase4a": "score_sequential.py", "phase4b": "score_sequential.py", "base": "score_streaming.py"}


def spec_phase(spec):
    """The runner family of a spec, from its base config: base (REF-SINGLE, YOUR_PACKAGE/base/), phase4b or phase4a.
    Same rule as collect_returns.spec_phase."""
    base = str(spec.base_config).replace(os.sep, "/")
    return "base" if base.startswith("YOUR_PACKAGE/base/") else "phase4b" if "phase4b" in base else "phase4a"


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def utc_now():
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def child_env():
    env = dict(os.environ)
    if subprocess.run([sys.executable, "-c", "import pytorch_tabular"], cwd=ROOT, capture_output=True).returncode:
        env["PYTHONPATH"] = os.pathsep.join([os.path.join(ROOT, "src"), ROOT] + ([env["PYTHONPATH"]] if env.get("PYTHONPATH") else []))
    return env


def score_metrics(path, checkpoint, checkpoint_sha256, require_metrics=True):
    """Faithful copy of run_ablations._score_metrics (phase4a and phase4b are identical).

    Copied, not imported: importing the runner inserts the repository into sys.path and configures root logging.
    tests/test_score_attempt_v3.py checks that both accept and reject the same cases.
    """
    with open(path, encoding="utf-8") as stream:
        metrics = json.load(stream)
    if not isinstance(metrics, dict) or type(metrics.get("schema_version")) is not int or metrics["schema_version"] != 1:
        raise ValueError("Unknown scorer metrics schema")
    if metrics.get("checkpoint_path") != os.path.abspath(checkpoint):
        raise ValueError("Scorer checkpoint path does not match this attempt")
    if metrics.get("checkpoint_sha256") != checkpoint_sha256 or sha256(checkpoint) != checkpoint_sha256:
        raise ValueError("Scorer checkpoint hash does not match this attempt")
    n, positives = metrics["n_predictions"], metrics["n_positives"]
    if type(n) is not int or type(positives) is not int or n <= 0 or not 0 <= positives <= n:
        raise ValueError("Invalid scorer cohort counts")
    if not isinstance(metrics.get("predictions_path"), str) or not metrics["predictions_path"].strip():
        raise ValueError("Scorer did not identify its prediction output")
    if require_metrics and not 0 < positives < n:
        raise ValueError("Scoring metrics require both target classes")
    for key in ("average_precision", "auroc"):
        if key not in metrics:
            raise ValueError(f"Missing scorer metric field {key}")
        value = metrics[key]
        if require_metrics:
            if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 1:
                raise ValueError(f"Invalid scorer metric {key}")
        elif value is not None:
            raise ValueError(f"Disabled scorer metric {key} must be null")
    return metrics


def source_provenance():
    """Runtime source identity with the runner's convention (see SOURCE_CONVENTION)."""
    files = []
    for folder in ("fraud", "YOUR_PACKAGE"):
        files.extend(Path(ROOT, folder).rglob("*.py"))
    files.extend(p for name in ("pyproject.toml", "requirements.txt") if (p := Path(ROOT, name)).is_file())
    hashes = {str(path.relative_to(ROOT)): sha256(path) for path in sorted(files)}
    digest = hashlib.sha256(json.dumps(hashes, sort_keys=True).encode()).hexdigest()
    return {"convention": SOURCE_CONVENTION, "source_sha256": digest, "files": hashes}


def environment():
    packages = {}
    for name in PACKAGES:
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    return {"python": sys.version, "executable": sys.executable, "packages": packages}


def write_json(path, value):
    temp = f"{path}.{uuid.uuid4().hex}.tmp"
    try:
        with open(temp, "x", encoding="utf-8") as f:
            json.dump(value, f, indent=2, sort_keys=True, allow_nan=False)
            f.write("\n")
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def describe(exc):
    """Validator messages are fixed strings; other exceptions are named with their (path/key-only) message."""
    text = str(exc) if isinstance(exc, ValueError) and not isinstance(exc, json.JSONDecodeError) \
        else f"{type(exc).__name__}: {exc}"
    return text.strip().splitlines()[0] if text.strip() else type(exc).__name__


def canonical(path):
    return os.path.realpath(os.path.abspath(str(path).strip()))


def ledger_selection(path):
    """{canonical attempt_dir: {run_name}} of validation-only ok runs, judged by each key's latest ledger row.

    v3 (tf-runbook-ledger-v3, columns revision/transition/evidence_sha256): the highest integer revision per
    (canonical attempt_dir, run_name) wins, ties by file order. v2 (no revision column): the last row per key wins.
    Only a latest row with status ok and run_score false selects its run.
    """
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        header = reader.fieldnames or []
        missing = {"ledger_schema", "attempt_dir", "run_name", "status", "run_score"} - set(header)
        if missing:
            raise ValueError(f"ledger {path} lacks columns {sorted(missing)}")
        has_revision = "revision" in header
        latest = {}
        for i, row in enumerate(reader):
            schema = (row.get("ledger_schema") or "").strip()
            if schema not in (LEDGER_V2, *REVISIONED):
                raise ValueError(f"ledger {path} row {i + 2}: unknown ledger_schema {schema!r}")
            raw = (row.get("revision") or "").strip() if has_revision else ""
            if schema in REVISIONED and not re.fullmatch(r"-?\d+", raw):
                raise ValueError(f"ledger {path} row {i + 2}: v3 row without an integer revision")
            revision = int(raw) if raw else -1  # v2 rows: file order alone decides
            key = (canonical(row["attempt_dir"]), (row.get("run_name") or "").strip())
            if key not in latest or (revision, i) >= latest[key][0]:
                latest[key] = ((revision, i), row)
    chosen = {}
    for (att, name), (_, row) in latest.items():
        if (row.get("status") or "").strip() == "ok" and str(row.get("run_score")).strip().lower() == "false":
            chosen.setdefault(att, set()).add(name)
    return chosen


def eval_scope(cfg, override):
    """The evaluation cohort as configured (recorded as found; the scorer itself rejects an unusable config)."""
    return {"base": OmegaConf.select(cfg, "eval.base"), "file_start": OmegaConf.select(cfg, "eval.file_start"),
            "file_end": OmegaConf.select(cfg, "eval.file_end"), "source": "override" if override else "frozen_config"}


ACCEPTANCE_SCHEMA = "tf-post-score-cohort-acceptance-v1"


def acceptance_records(folder, contract_id):
    """This folder's cohort checks against one pre-flight contract, oldest first. Append-only: each check that
    changes the verdict adds cohort_acceptance_<contract sha prefix>_<NNNN>.json; nothing is rewritten."""
    prefix = f"cohort_acceptance_{contract_id['sha256'][:16]}_"
    names = sorted(n for n in os.listdir(folder) if n.startswith(prefix) and n.endswith(".json")
                   and n[len(prefix):-5].isdigit()) if os.path.isdir(folder) else []
    return [os.path.join(folder, n) for n in names]


def check_prior(folder, ck, ck_sha, train_sha, override, contract_id=None):
    """('valid' | 'other_range' | 'invalid', reason, manifest) for one existing post_score/<id>/ folder."""
    try:
        with open(os.path.join(folder, "post_score_manifest.json"), encoding="utf-8") as f:
            man = json.load(f)
    except Exception as exc:
        return "invalid", f"manifest unreadable ({type(exc).__name__})", None
    if not isinstance(man, dict) or man.get("schema") != POST_SCHEMA:
        return "invalid", "manifest schema", None
    if man.get("status") != "ok" or man.get("returncode") != 0:
        return "invalid", f"recorded status {man.get('status')} rc {man.get('returncode')}", None
    if man.get("checkpoint_path") != os.path.abspath(ck) or man.get("checkpoint_sha256") != ck_sha:
        return "invalid", "different checkpoint identity", None
    if man.get("resolved_train_sha256_recorded") != train_sha or man.get("resolved_train_sha256_recomputed") != train_sha:
        return "invalid", "different resolved_train identity", None
    try:
        if sha256(os.path.join(folder, "resolved_score.yaml")) != man.get("resolved_score_sha256"):
            return "invalid", "resolved_score.yaml changed", None
        metrics_path = os.path.join(folder, "post_score_metrics.json")
        if sha256(metrics_path) != man.get("metrics_sha256"):
            return "invalid", "post_score_metrics.json changed", None
        metrics = score_metrics(metrics_path, ck, ck_sha, True)
    except Exception as exc:
        return "invalid", f"metrics invalid: {describe(exc)}", None
    if man.get("eval_range_override") != override:
        return "other_range", "valid, but for a different evaluation range", None
    if contract_id is not None:  # acceptance is relative to the requested pre-flight contract
        records = acceptance_records(folder, contract_id)
        rec = load_acceptance(records[-1]) if records else None  # the latest check decides
        if rec is not None and rec.get("verdict") != "ok":
            return "invalid", (f"rejected for pre-flight {contract_id['name']} "
                               f"({'+'.join(rec.get('failed_checks') or ['unknown'])}); kept as evidence"), None
    man["_metrics"] = metrics
    return "valid", "", man


def load_acceptance(path):
    try:
        with open(path, encoding="utf-8") as f:
            rec = json.load(f)
        return rec if isinstance(rec, dict) and rec.get("schema") == ACCEPTANCE_SCHEMA else {"verdict": "unreadable",
                                                                                           "failed_checks": ["record"]}
    except FileNotFoundError:
        return None
    except Exception:
        return {"verdict": "unreadable", "failed_checks": ["record"]}


def score_run(att, name, r, scorer, override, lines, contract_id=None, info=None, phase="phase4a"):
    """Check one results row, maybe score it; append table/detail lines; return (status, metrics or None).
    info (optional dict) receives post_dir: the post_score folder this check used or created.
    phase base gives REF-SINGLE's per-file scorer a fresh prediction folder of its own."""
    info = {} if info is None else info
    run_dir = os.path.join(att, name)
    ck = os.path.join(run_dir, "best.ckpt")
    resolved_train = os.path.join(run_dir, "resolved_train.yaml")
    if r.get("status") != "ok":
        return "skipped:not_ok", None
    rec_ck = (r.get("checkpoint_sha256") or "").strip()
    if not os.path.isfile(ck) or sha256(ck) != rec_ck:
        return "ckpt_changed", None
    # D2: the frozen training config must still be byte-identical to what the runner recorded.
    rec_row = (r.get("resolved_train_sha256") or "").strip()
    try:
        with open(os.path.join(run_dir, "run_manifest.json"), encoding="utf-8") as f:
            rec_manifest = json.load(f).get("resolved_train_sha256")
    except Exception as exc:
        rec_manifest = None
        lines.append(f"   reason: run_manifest.json unreadable ({type(exc).__name__})")
    actual = sha256(resolved_train) if os.path.isfile(resolved_train) else None
    if not (len(rec_row) == 64 and actual == rec_row == rec_manifest):
        lines.append(f"   reason: resolved_train.yaml sha256 now {str(actual)[:12]}, results row {rec_row[:12] or '-'}, "
                     f"run_manifest {str(rec_manifest)[:12]}; child not launched")
        return "config_changed", None

    if os.path.isfile(os.path.join(run_dir, "score_metrics.json")) and not override:
        # Scored by the runner itself, on its frozen config's range (checked above): valid only under the runner's
        # own contract. With an explicit override the runner's result does not apply and a fresh scoring follows.
        try:
            need = bool(OmegaConf.load(resolved_train).eval.get("compute_metrics", False))
            m = score_metrics(os.path.join(run_dir, "score_metrics.json"), ck, rec_ck, need)
        except Exception as exc:
            lines.append(f"   reason: runner score_metrics.json: {describe(exc)}")
            return "scored_invalid", None
        if need:
            m["_score_yaml"] = os.path.join(run_dir, "resolved_score.yaml")
        return "skipped:scored", m if need else None

    # D1: an earlier valid post-score of this exact checkpoint, config and evaluation range is reused; nothing
    # earlier is trusted without the full check, and nothing is overwritten.
    post_root = os.path.join(run_dir, "post_score")
    if os.path.exists(os.path.join(run_dir, "post_score_metrics.json")):
        lines.append("   note: legacy fixed-path post_score_metrics.json (score_attempt v2) ignored: never validated")
    priors = sorted(d for d in os.listdir(post_root) if os.path.isdir(os.path.join(post_root, d))) \
        if os.path.isdir(post_root) else []
    considered, valid = [], None
    for d in priors:
        verdict, reason, man = check_prior(os.path.join(post_root, d), ck, rec_ck, actual, override, contract_id)
        considered.append({"folder": d, "verdict": verdict, "reason": reason})
        if verdict == "valid":
            valid = (d, man)
        elif verdict == "invalid":
            lines.append(f"   prior_invalid post_score/{d}: {reason} (not counted)")
    if valid:
        info["post_dir"] = os.path.join(post_root, valid[0])
        lines.append(f"   -> post_score/{valid[0]} (existing, revalidated)")
        valid[1]["_metrics"]["_score_yaml"] = os.path.join(post_root, valid[0], "resolved_score.yaml")
        return "skipped:valid_exists", valid[1]["_metrics"]

    manifest = None
    try:
        frozen = OmegaConf.load(resolved_train)
        post_dir = os.path.join(post_root, f"{_dt.datetime.now(_dt.timezone.utc):%Y%m%dT%H%M%SZ}-{uuid.uuid4().hex}")
        metrics_path = os.path.join(post_dir, "post_score_metrics.json")
        label = f"{os.path.basename(os.path.dirname(att))}__{os.path.basename(att)}__{name}__post"
        overrides = [f"eval.checkpoint={ck}", f"eval.metrics_output={metrics_path}", f"experiment.run_name={label}",
                     "eval.compute_metrics=true"]
        if override:
            overrides += [f"eval.file_start={override['file_start']}", f"eval.file_end={override['file_end']}"]
        if phase == "base":  # the per-file scorer refuses an existing destination: one folder per post-score,
            # beside the run's own prediction folder, never inside it (that folder is read whole by the cohort check)
            overrides += [f"eval.predictions_base={str(frozen.eval.predictions_base).rstrip('/')}__post_score/"
                          f"{os.path.basename(post_dir)}"]
        effective = OmegaConf.merge(frozen, OmegaConf.from_dotlist(overrides))
        os.makedirs(post_root, exist_ok=True)
        os.makedirs(post_dir, exist_ok=False)  # new and unique: an earlier folder is never reused or overwritten
        info["post_dir"] = post_dir
        resolved_score = os.path.join(post_dir, "resolved_score.yaml")
        OmegaConf.save(effective, resolved_score, resolve=True)
        # The child gets the effective config file; the same overrides are repeated on its command line so the
        # recorded command alone shows every change from the frozen config (merging them again is a no-op).
        cmd = [sys.executable, scorer, "--config", resolved_score] + overrides
        source_before = source_provenance()
        manifest = {
            "schema": POST_SCHEMA, "status": "running", "attempt_dir": att, "run_name": name, "post_score_dir": post_dir,
            "checkpoint_path": os.path.abspath(ck), "checkpoint_sha256": rec_ck,
            "resolved_train_path": resolved_train, "resolved_train_sha256_recorded": rec_row,
            "resolved_train_sha256_run_manifest": rec_manifest, "resolved_train_sha256_recomputed": actual,
            "resolved_score_path": resolved_score, "resolved_score_sha256": sha256(resolved_score),
            "overrides": overrides, "eval_range": eval_scope(effective, override),
            "frozen_eval_range": eval_scope(frozen, None), "eval_range_override": override,
            "scorer": scorer, "command": cmd, "cwd": ROOT, "returncode": None,
            "started_utc": utc_now(), "finished_utc": None, "environment": environment(),
            "source_before": source_before, "training_source_sha256": r.get("source_sha256"),
            "source_matches_training_run": source_before["source_sha256"] == (r.get("source_sha256") or "").strip(),
            "metrics_path": metrics_path, "log_path": os.path.join(post_dir, "score.log"),
            "prior_attempts_considered": considered,
        }
        write_json(os.path.join(post_dir, "post_score_manifest.json"), manifest)
        with open(manifest["log_path"], "w") as log:
            rc = subprocess.run(cmd, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, env=child_env()).returncode
    except Exception as exc:
        lines.append(f"   reason: could not prepare or launch the scorer ({describe(exc)})")
        if manifest is not None:  # the folder stays, marked failed, and never counts as a valid prior
            manifest.update(status="launch_failed", error=describe(exc), finished_utc=utc_now())
            try:
                write_json(os.path.join(manifest["post_score_dir"], "post_score_manifest.json"), manifest)
            except Exception:
                pass
        return "launch_failed", None

    manifest.update(returncode=rc, finished_utc=utc_now())
    m, error = None, None
    if rc != 0:
        status, error = "score_failed", f"scorer exit {rc}"
    elif not os.path.isfile(metrics_path):
        status, error = "invalid_output", "post_score_metrics.json missing"
    else:
        try:
            m = score_metrics(metrics_path, ck, rec_ck, True)  # also recomputes the checkpoint hash from disk
            status = "ok"
        except Exception as exc:
            status, error = "invalid_output", describe(exc)
    manifest["source_after"] = source_provenance()
    if status == "ok" and manifest["source_after"]["source_sha256"] != source_before["source_sha256"]:
        status, error, m = "source_changed", "runtime source files changed during scoring", None
    manifest.update(status=status, error=error)
    if os.path.isfile(metrics_path):
        manifest["metrics_sha256"] = sha256(metrics_path)
    if m is not None:
        manifest["metrics"] = {k: m[k] for k in ("average_precision", "auroc", "n_predictions", "n_positives",
                                                 "predictions_path")}
    write_json(os.path.join(post_dir, "post_score_manifest.json"), manifest)
    if m is not None:
        m["_score_yaml"] = resolved_score
    if error:
        lines.append(f"   reason: {error}")
    lines.append(f"   -> post_score/{os.path.basename(post_dir)}")
    if status == "ok" and not manifest["source_matches_training_run"]:
        lines.append("   note: runtime source differs from the training run's source_sha256 (recorded; assess it)")
    return status, m


def prediction_digest(predictions_path, score_yaml):
    """The pre-flight's composite-id digest (version 1) over one prediction file; same framing as preflight_pod.py
    and collect_returns.py (tested to agree)."""
    import numpy as np
    import pandas as pd
    import pyarrow.parquet as pq
    if ROOT not in sys.path:  # scripts run from the runbook folder; the scorer's helpers live in the repo
        sys.path.insert(0, ROOT)
    from fraud.data.s3_utils import make_s3_filesystem, strip_scheme
    cfg = OmegaConf.load(score_yaml)
    acct, idcol = str(cfg.data.account_col), str(cfg.data.tie_break_col)
    fs = make_s3_filesystem(cfg.s3.cred_path)
    # A folder (REF-SINGLE's per-file parquet) is read as one table, as in collect_returns.py.
    df = pq.read_table(strip_scheme(str(predictions_path)), filesystem=fs, columns=[acct, idcol]).to_pandas()
    h = np.sort(pd.util.hash_pandas_object(df[[acct, idcol]].astype(str), index=False).to_numpy())
    return hashlib.sha256(b"composite-id-uint64-multiset-v1" + len(h).to_bytes(8, "big")
                          + h.astype(">u8").tobytes()).hexdigest()


def per_file_counts(m, score_yaml):
    """{file name: [rows, positives]} of a per-file prediction folder (REF-SINGLE). Copy of
    collect_returns.per_file_counts (tests/test_ref_single_b8.py checks that both agree)."""
    import pyarrow.compute as pc
    import pyarrow.parquet as pq
    if ROOT not in sys.path:
        sys.path.insert(0, ROOT)
    from fraud.data.s3_utils import make_s3_filesystem, strip_scheme
    cfg = OmegaConf.load(score_yaml)
    target = str(cfg.data.target_col)
    counts, fs = {}, make_s3_filesystem(cfg.s3.cred_path)
    for path in m["prediction_files"]:
        t = pq.read_table(strip_scheme(str(path)), filesystem=fs, columns=[target])
        counts[os.path.basename(path)] = [t.num_rows, int(pc.sum(t[target]).as_py() or 0)]
    return counts


def check_per_file(split, m, score_yaml):
    """Failed checks (names only) for a per-file prediction folder: the pre-flight's file names and, per file, its
    row and positive counts (B8 part 6). A run with a single prediction file passes. Copy of collect_returns'."""
    if "prediction_files" not in m:
        return []
    try:
        got = per_file_counts(m, score_yaml)
    except Exception:
        return ["cohort_files_unreadable"]
    want = {f.get("file"): [f.get("rows"), f.get("positives")] for f in split.get("files") or [] if isinstance(f, dict)}
    return [] if got == want else ["cohort_files"]


def check_cohort(contract, m):
    """Failed checks (names only): the scored run against the pre-flight's evaluation split of the same range."""
    try:
        e = OmegaConf.load(m["_score_yaml"]).eval
        split = contract.get(f"eval_{e.file_start}_{e.file_end}")
    except Exception:
        return ["cohort_score_config_unreadable"]
    if not isinstance(split, dict):
        return ["cohort_not_in_preflight"]
    bad = []
    if m.get("n_predictions") != split.get("rows") or m.get("n_positives") != split.get("positives"):
        bad.append("cohort_counts")
    bad += check_per_file(split, m, m["_score_yaml"])
    if split.get("composite_id_digest_version") != 1:
        return bad + ["cohort_digest_version"]
    try:
        if prediction_digest(m["predictions_path"], m["_score_yaml"]) != split.get("composite_id_multiset_sha256"):
            bad.append("cohort_ids")
    except Exception:
        bad.append("cohort_predictions_unreadable")
    return bad


def record_acceptance(m, contract_id, failed):
    """Append the cohort verdict for a post-score folder and this pre-flight contract when it differs from the
    latest one; earlier records (including a historical acceptance) are never rewritten.
    Runner-scored results (no post_score folder) are reported only: their acceptance is the collector's."""
    folder = os.path.dirname(m.get("_score_yaml") or "")
    if os.path.basename(os.path.dirname(folder)) != "post_score":
        return
    records = acceptance_records(folder, contract_id)
    latest = load_acceptance(records[-1]) if records else None
    verdict = "failed" if failed else "ok"
    if latest is not None and latest.get("verdict") == verdict and latest.get("failed_checks") == list(failed):
        return  # same outcome as the latest record: nothing new to append
    path = os.path.join(folder, f"cohort_acceptance_{contract_id['sha256'][:16]}_{len(records) + 1:04d}.json")
    write_json(path, {"schema": ACCEPTANCE_SCHEMA, "preflight_name": contract_id["name"],
                      "preflight_dir": contract_id["dir"], "data_contract_sha256": contract_id["sha256"],
                      "verdict": verdict, "failed_checks": list(failed), "sequence": len(records) + 1,
                      "n_predictions": m.get("n_predictions"), "n_positives": m.get("n_positives"),
                      "checked_utc": utc_now()})


# Prediction files and checkpoints stay on the pod (the owner's answer to OQ-24); every other file a scoring writes
# (manifest, metrics, resolved config, score.log, cohort acceptance records) goes into the return copy.
STAYS_ON_POD = (".parquet", ".ckpt")
RETURN_COLUMNS = ["attempt", "attempt_dir", "run_name", "status", "post_score_id", "checkpoint_sha256",
                  "resolved_train_sha256", "eval_file_start", "eval_file_end", "eval_range_override", "best_valid_ap",
                  "eval_ap", "eval_auroc", "n_predictions", "n_positives", "cohort_preflight", "cohort_verdict",
                  "cohort_failed_checks", "cohort_acceptance_record"]


def export_returns(return_dir, report, records):
    """The owner's return copy of post-hoc scoring: POST_SCORE.txt (the printed table), post_score_results.csv (one
    row per checked run, with attempt/run identity and the cohort verdict) and, per post-score folder, its manifest,
    metrics, resolved config, score.log and every cohort acceptance record under post_score/<attempt>/<run>/<post id>/:
    every file of the folder, sub-folders included, except *.parquet and *.ckpt. Prediction files and checkpoints stay
    on the pod (the owner's answer to OQ-24). Nothing existing is overwritten."""
    import shutil
    os.makedirs(return_dir, exist_ok=True)
    with open(os.path.join(return_dir, "POST_SCORE.txt"), "x") as f:
        f.write(report)
    with open(os.path.join(return_dir, "post_score_results.csv"), "x", newline="") as f:
        w = csv.DictWriter(f, fieldnames=RETURN_COLUMNS)
        w.writeheader()
        for rec in records:
            w.writerow({k: rec.get(k, "") for k in RETURN_COLUMNS})
    for rec in records:
        src = rec.get("_post_dir")
        if not src or not os.path.isdir(src):
            continue
        dst = os.path.join(return_dir, "post_score", rec["attempt"], rec["run_name"], os.path.basename(src))
        os.makedirs(dst, exist_ok=False)
        for here, _, names in os.walk(src):
            for n in sorted(names):
                if n.endswith(STAYS_ON_POD):
                    continue
                target = os.path.join(dst, os.path.relpath(os.path.join(here, n), src))
                os.makedirs(os.path.dirname(target), exist_ok=True)
                shutil.copy2(os.path.join(here, n), target)


def return_record(att, name, r, status, m, post_dir, contract_id, checked, failed):
    """One post_score_results.csv row: identity, status and, when available, the scores and cohort verdict."""
    rec = {"attempt": os.path.basename(os.path.normpath(att)), "attempt_dir": att, "run_name": name,
           "status": status, "best_valid_ap": r.get("best_valid_ap", ""),
           "checkpoint_sha256": r.get("checkpoint_sha256", ""), "resolved_train_sha256": r.get("resolved_train_sha256", ""),
           "post_score_id": os.path.basename(post_dir) if post_dir else "", "_post_dir": post_dir}
    if m is not None:
        rec.update(eval_ap=m.get("average_precision"), eval_auroc=m.get("auroc"),
                   n_predictions=m.get("n_predictions"), n_positives=m.get("n_positives"))
        try:
            e = OmegaConf.load(m["_score_yaml"]).eval
            rec.update(eval_file_start=e.file_start, eval_file_end=e.file_end)
        except Exception:
            pass
    if post_dir:
        try:
            with open(os.path.join(post_dir, "post_score_manifest.json"), encoding="utf-8") as f:
                rec["eval_range_override"] = json.dumps(json.load(f).get("eval_range_override"))
        except Exception:
            rec["eval_range_override"] = "unreadable"
    if contract_id is not None:
        rec["cohort_preflight"] = contract_id["name"]
        if checked:
            rec["cohort_verdict"] = "failed" if failed else "ok"
            rec["cohort_failed_checks"] = "+".join(failed)
            if post_dir:
                recs = acceptance_records(post_dir, contract_id)
                rec["cohort_acceptance_record"] = os.path.basename(recs[-1]) if recs else ""
        else:
            rec["cohort_verdict"] = "not_checked"
    return rec


def parse_range(text):
    m = re.fullmatch(r"\s*(\d+)\s*-\s*(\d+)\s*", text or "")
    if not m or int(m.group(1)) > int(m.group(2)):
        raise argparse.ArgumentTypeError("expected START-END with START <= END, e.g. 8000-8010")
    return {"file_start": int(m.group(1)), "file_end": int(m.group(2))}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("attempts", nargs="*")
    ap.add_argument("--from-ledger", default=None,
                    help="also score the validation-only runs whose latest ledger row (v2 or v3) is ok")
    ap.add_argument("--override-eval-files", type=parse_range, default=None, metavar="START-END",
                    help="score on these evaluation files instead of the frozen config's range (recorded as override)")
    ap.add_argument("--preflight", default=None,
                    help="pre-flight output folder: scored results must match its evaluation cohort (counts and ids)")
    ap.add_argument("--return-dir", default=None,
                    help="also write the owner's return copy here: POST_SCORE.txt, post_score_results.csv and the "
                         "post-score folders' other files (manifests, metrics, resolved configs, logs, acceptance "
                         "records; prediction files and checkpoints stay on the pod, the owner's answer to OQ-24); "
                         "existing files are never overwritten")
    args = ap.parse_args(argv)
    if args.return_dir and any(os.path.exists(os.path.join(args.return_dir, n))
                               for n in ("POST_SCORE.txt", "post_score_results.csv", "post_score")):
        ap.error(f"--return-dir {args.return_dir} already holds post-score returns; choose a new folder")
    contract, contract_id = None, None
    if args.preflight:
        cpath = os.path.join(args.preflight, "data_contract.json")
        try:
            with open(cpath, encoding="utf-8") as f:
                contract = json.load(f)
        except Exception as exc:
            ap.error(f"--preflight {args.preflight}: data_contract.json unreadable ({type(exc).__name__})")
        contract_id = {"name": os.path.basename(os.path.normpath(args.preflight)),
                       "dir": os.path.abspath(args.preflight), "sha256": sha256(cpath)}
    targets = {canonical(a): None for a in args.attempts}  # None: every run of an explicitly named attempt
    if args.from_ledger:
        try:
            chosen = ledger_selection(args.from_ledger)
        except (OSError, ValueError, KeyError) as exc:
            ap.error(f"cannot read the ledger: {exc}")
        for att, names in chosen.items():
            if att not in targets:
                targets[att] = names
            elif targets[att] is not None:
                targets[att] |= names
    if not targets:
        ap.error("no attempt folders given or found in the ledger")
    override = args.override_eval_files
    lines = [f"{'attempt/run':<44} {'status':<20} {'vAP':>7} {'eAP':>7} {'eAUC':>7} {'rows':>9} {'pos':>5}"]
    failures, records = 0, []
    for att, wanted in targets.items():
        try:
            spec = OmegaConf.load(os.path.join(att, "ablation_spec.yaml"))
            phase = spec_phase(spec)
            with open(os.path.join(att, "results.csv"), newline="") as f:
                rows = list(csv.DictReader(f))
        except Exception as exc:
            lines.append(f"{os.path.basename(att)[:44]:<44} {'attempt_unreadable':<20}")
            lines.append(f"   reason: {type(exc).__name__} reading ablation_spec.yaml/results.csv")
            failures += 1
            for name in sorted(wanted) if wanted else ["(all runs)"]:
                records.append(return_record(att, name, {}, "attempt_unreadable", None, None, contract_id, False, []))
            continue
        scorer = os.path.join(ROOT, "YOUR_PACKAGE", phase, "scripts", SCORERS[phase])
        present = {r.get("run_name") for r in rows}
        for name in sorted(wanted - present) if wanted else []:
            lines.append(f"{(os.path.basename(att)[:16] + '/' + name)[-44:]:<44} {'not_in_results':<20}")
            failures += 1
            records.append(return_record(att, name, {}, "not_in_results", None, None, contract_id, False, []))
        for r in rows:
            name = r.get("run_name") or ""
            if wanted is not None and name not in wanted:
                continue
            tag = f"{os.path.basename(att)[:16]}/{name}"[-44:]
            detail, info, cbad, checked = [], {}, [], False
            if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", name):
                status, m = "attempt_unreadable", None
                detail.append("   reason: unsafe run_name in results.csv")
            else:
                status, m = score_run(att, name, r, scorer, override, detail, contract_id, info, phase)
                if contract is not None and m is not None and status in ("ok", "skipped:valid_exists", "skipped:scored"):
                    cbad, checked = check_cohort(contract, m), True
                    record_acceptance(m, contract_id, cbad)
                    if cbad:
                        detail.append(f"   reason: evaluation cohort differs from the pre-flight's ({'+'.join(cbad)})")
                        if status != "skipped:scored":
                            detail.append("   note: this post-score stays as evidence; a retry with the same pre-flight "
                                          "scores afresh in a new folder")
                        status = "cohort_mismatch"
            failures += status in FAILURES
            if m is not None and m.get("average_precision") is not None:
                try:
                    vap = f"{float(r.get('best_valid_ap')):>7.4f}"
                except (TypeError, ValueError):
                    vap = f"{'-':>7}"
                lines.append(f"{tag:<44} {status:<20} {vap} {m['average_precision']:>7.4f} "
                             f"{m['auroc']:>7.4f} {m['n_predictions']:>9} {m['n_positives']:>5}")
            else:
                lines.append(f"{tag:<44} {status:<20}")
            lines.extend(detail)
            records.append(return_record(att, name, r, status, m, info.get("post_dir"), contract_id, checked, cbad))
    report = ["POST-HOC EVAL SCORING (selection already done on validation)",
              f"evaluation cohort checked against pre-flight {os.path.basename(os.path.normpath(args.preflight))} "
              "(counts and id digest)" if contract is not None else "evaluation cohort NOT checked against a pre-flight"]
    if override:
        report.append(f"EVAL RANGE OVERRIDE: files {override['file_start']}-{override['file_end']} instead of each "
                      "frozen config's range (recorded in post_score_manifest.json)")
    report += lines + [f"{failures} run(s) failed or produced invalid output" if failures else "no failures"]
    print("\n".join(report))
    if args.return_dir:
        try:
            export_returns(args.return_dir, "\n".join(report) + "\n", records)
            print(f"return copy written to {args.return_dir} (POST_SCORE.txt, post_score_results.csv, post_score/)")
        except Exception as exc:
            print(f"RETURN COPY FAILED ({describe(exc)}): send the post_score folders listed above instead")
            failures += 1
    sys.exit(1 if failures else 0)


if __name__ == "__main__":
    main()
