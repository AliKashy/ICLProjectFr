"""Interrupted batch diagnostics must return with the recovered ledger summary."""
import importlib.util
from pathlib import Path


_spec = importlib.util.spec_from_file_location(
    "batch_return_resume_fixtures", Path(__file__).with_name("test_batch_fr1.py"))
fixtures = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(fixtures)


def test_batch1_resume_returns_interrupted_step_diagnostics(tmp_path):
    """Use the existing stub runner and collector fixtures; no training or external data."""
    out = fixtures.return_folder(tmp_path)
    step_name = "ft_decisions_hier_20261011T000000Z_1"
    step = out / "steps" / step_name
    step.mkdir(parents=True)
    (out / "BATCH_STATUS.txt").write_text("batch 1 started\n")
    attempt = fixtures.contracts.make_attempt(tmp_path / "interrupted", rows="none")
    train_log = attempt / "mask-bidir" / "train.log"
    train_log.write_text("interrupted trainer diagnostic\n")
    (attempt / "mask-bidir" / "best.ckpt").write_text("checkpoint stays on pod\n")
    (attempt / "mask-bidir" / "predictions.parquet").write_text("predictions stay on pod\n")
    step_text = ("spec: phase4b/ft_decisions_hier.yaml\ninterpreter: stub\nstarted_utc: t\n"
                 f"attempt_dir: {attempt}\n")
    (step / "STEP.txt").write_text(step_text)  # run_step's mirror, saved before the interruption
    runs = tmp_path / "sb" / "runs"
    source_return = runs / "returns" / step_name
    source_return.mkdir(parents=True)
    (source_return / "STEP.txt").write_text(step_text)
    (source_return / "nested").mkdir()
    (source_return / "nested" / "detail.log").write_text("interrupted step diagnostic\n")
    expected_logs = {
        "logs": {".runner.log": "interrupted runner diagnostic\n"},
        "gpu": {".csv": "timestamp,memory.used [MiB]\nt,100 MiB\n",
                ".host_rss.csv": "timestamp_utc,rss_mib_process_tree\nt,1\n"},
    }
    for directory, files in expected_logs.items():
        (runs / directory).mkdir(parents=True, exist_ok=True)
        for suffix, content in files.items():
            (runs / directory / f"{step_name}{suffix}").write_text(content)

    process = fixtures.run_batch("batch1.sh", fixtures.batch_env(
        tmp_path, BATCH1_RESUME=str(out), FAKE_ATTEMPT_FILES="1"))
    assert "an earlier start of this step was interrupted" in process.stdout
    assert "MARK step ft_decisions_hier.yaml" in process.stdout  # rerun gets a new attempt
    assert (step / "interrupted_collect" / "RETURN.txt").is_file()
    assert "interrupted_collected:" in (step / "STEP.txt").read_text()
    for files in expected_logs.values():
        for suffix, content in files.items():
            assert (step / f"{step_name}{suffix}").read_text() == content
    assert (step / "nested" / "detail.log").read_text() == "interrupted step diagnostic\n"
    copied_attempt = out / "attempts" / attempt.name
    assert (copied_attempt / "mask-bidir" / "train.log").read_text() == train_log.read_text()
    assert (copied_attempt / "ablation_spec.yaml").is_file()
    assert not list(out.rglob("*.ckpt")) and not list(out.rglob("*.parquet"))
    assert (attempt / "mask-bidir" / "best.ckpt").is_file()
    assert (attempt / "mask-bidir" / "predictions.parquet").is_file()
    rows = fixtures.collector.current_rows(str(runs / "run_log.csv"))
    assert rows[(str(attempt.resolve()), "mask-bidir")]["status"] == "not_run"


def test_batch2_resume_returns_interrupted_step_diagnostics(tmp_path):
    """The same for batch2.sh (L2-SCRIPT-04): the interrupted step's return folder, runner log, memory samples and
    attempt files go into the batch 2 return; checkpoints and predictions stay."""
    fixtures.b1_ledger(tmp_path / "sb" / "runs" / "run_log.csv")
    out = fixtures.b2_folder(tmp_path)
    step_name = "ft_decisions_gap05_off_20261012T000000Z_1"
    step = out / "steps" / step_name
    step.mkdir(parents=True)
    (out / "BATCH_STATUS.txt").write_text("batch 2 started\n")
    (out / "POST_SCORE.txt").write_text("POST-HOC EVAL SCORING\nno failures\n")
    attempt = fixtures.contracts.make_attempt(tmp_path / "interrupted", rows="none")
    train_log = attempt / "mask-bidir" / "train.log"
    train_log.write_text("interrupted trainer diagnostic\n")
    (attempt / "mask-bidir" / "best.ckpt").write_text("checkpoint stays on pod\n")
    (attempt / "mask-bidir" / "predictions.parquet").write_text("predictions stay on pod\n")
    step_text = ("spec: phase4a/ft_decisions_gap05_off.yaml\ninterpreter: stub\nstarted_utc: t\n"
                 f"attempt_dir: {attempt}\n")
    (step / "STEP.txt").write_text(step_text)
    runs = tmp_path / "sb" / "runs"
    source_return = runs / "returns" / step_name
    source_return.mkdir(parents=True)
    (source_return / "STEP.txt").write_text(step_text)
    (runs / "logs").mkdir(exist_ok=True)
    (runs / "logs" / f"{step_name}.runner.log").write_text("interrupted runner diagnostic\n")
    others = " ".join(spec for _, spec in fixtures.ALL_B2 if spec != "ft_decisions_gap05_off.yaml")
    process = fixtures.run_batch("batch2.sh", fixtures.batch_env(tmp_path, BATCH2_RESUME=str(out), BATCH2_SKIP=others))
    assert "an earlier start of this step was interrupted" in process.stdout
    assert "MARK step ft_decisions_gap05_off.yaml" in process.stdout
    assert "interrupted_collected:" in (step / "STEP.txt").read_text()
    assert (step / f"{step_name}.runner.log").read_text() == "interrupted runner diagnostic\n"
    copied_attempt = out / "attempts" / attempt.name
    assert (copied_attempt / "mask-bidir" / "train.log").read_text() == train_log.read_text()
    assert not list(out.rglob("*.ckpt")) and not list(out.rglob("*.parquet"))
