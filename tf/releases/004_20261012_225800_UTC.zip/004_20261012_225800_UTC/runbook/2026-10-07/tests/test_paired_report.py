# reviewer, 2026-10-12. Synthetic tests for paired_report.py (V1 build item B12): account against row resampling, the
# zero-width interval of identical models, the S1 labels, the join counts, the depth-matched
# positions, the seed rule and the aggregates-only outputs. Synthetic data only; CPU; runs in seconds.
#     PYTHONPATH=src:. python3 -m pytest -q runbook/2026-10-07/tests/test_paired_report.py
import csv
import importlib.util
import os
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from sklearn.metrics import average_precision_score

HERE = Path(__file__).resolve().parents[1]
ID, ACCT, TIME, TARGET = "fi_transaction_id", "Nmap_account_reference_xid", "transaction_dttm", "frd_tag"


def load(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return m


pr = load("paired_report_under_test", HERE / "paired_report.py")
lb = load("leaderboard_under_test", HERE.parents[1] / "YOUR_PACKAGE" / "scoring" / "leaderboard.py")


def clustered(seed=7, accounts=300, rows=20, fraud_accounts=30):
    """Rows of accounts whose frauds come in bursts, with an account-level score effect."""
    rng = np.random.default_rng(seed)
    acct = np.repeat(np.arange(accounts), rows)
    y = np.zeros(len(acct), dtype=int)
    for a in rng.choice(accounts, fraud_accounts, replace=False):
        idx = np.flatnonzero(acct == a)
        y[rng.choice(idx, rng.integers(3, rows), replace=False)] = 1
    effect = rng.normal(0, 1.0, accounts)[acct]
    return acct, y, effect, rng


# ------------------------------------------------------------------------------------------------------------------ #
# Weighted AP and the joint draws
# ------------------------------------------------------------------------------------------------------------------ #
def test_weighted_ap_equals_sklearn_with_ties_and_duplicated_rows():
    rng = np.random.default_rng(1)
    y = rng.integers(0, 2, 500)
    s = np.round(rng.random(500), 1)  # many ties
    ys, cs, ends = pr.sorted_line(s, y, np.arange(500))
    assert pr.weighted_ap(ys, np.ones(500, dtype=np.int64), ends) == pytest.approx(average_precision_score(y, s),
                                                                                  rel=1e-12)
    w = rng.integers(0, 4, 500)
    expected = average_precision_score(np.repeat(y, w), np.repeat(s, w))
    assert pr.weighted_ap(ys, w[cs], ends) == pytest.approx(expected, rel=1e-12)


def test_joint_draws_match_leaderboard_paired_interval():
    acct, y, effect, rng = clustered()
    a = effect + 1.5 * y + rng.normal(0, 1, len(y))
    b = effect + 1.0 * y + rng.normal(0, 1, len(y))
    codes, mult = pr.draw_multiplicities(acct, 100, seed=3)
    _, da = pr.line_aps(a, y, codes, mult)
    _, db = pr.line_aps(b, y, codes, mult)
    ref = lb._paired_bootstrap_ci(y, a, b, average_precision_score, 100, seed=3, groups=acct, return_details=True)
    assert ref["single_class"] == 0
    np.testing.assert_allclose(da - db, ref["values"], rtol=0, atol=1e-12)


def test_account_and_row_resampling_give_different_intervals_on_clustered_data():
    acct, y, effect, rng = clustered()
    gain = rng.normal(0, 1.0, 300)[acct]  # the better model's gain varies by account
    a = effect + 1.0 * y + rng.normal(0, 1, len(y))
    b = a + 0.8 * y + 0.8 * gain * y
    widths = {}
    for unit, groups in (("account", acct), ("row", np.arange(len(y)))):
        codes, mult = pr.draw_multiplicities(groups, 400, seed=11)
        _, da = pr.line_aps(b, y, codes, mult)
        _, db = pr.line_aps(a, y, codes, mult)
        ci = pr.percentile_ci(da - db)
        widths[unit] = ci["ci_high"] - ci["ci_low"]
    assert widths["account"] > 1.5 * widths["row"]


# ------------------------------------------------------------------------------------------------------------------ #
# Reading rules
# ------------------------------------------------------------------------------------------------------------------ #
def test_s1_labels():
    assert pr.s1_label([0.01, 0.02, 0.01], (0.001, 0.02))[0] == "consistent positive"
    assert pr.s1_label([-0.01, -0.02], (-0.03, -0.001))[0] == "consistent negative"
    assert pr.s1_label([0.01, 0.02], (-0.03, -0.001))[0] == "not resolved: direction disagreement"
    assert pr.s1_label([-0.01, -0.02], (0.001, 0.02))[0] == "not resolved: direction disagreement"
    assert pr.s1_label([0.01, -0.02], (0.001, 0.02))[0] == "not resolved"
    assert pr.s1_label([0.01, 0.02], (-0.001, 0.02))[0] == "not resolved"
    assert pr.s1_label([0.0, 0.0], (0.0, 0.0))[0] == "not resolved"  # a zero difference has neither sign
    assert pr.s1_label([], (0.001, 0.02))[0] == "not resolved (no validation)"
    # With validation scored (decision 3), the validation interval must lie on the same side too.
    assert pr.s1_label([0.01, 0.02], (0.001, 0.02), (-0.001, 0.03))[0] == "not resolved"
    assert pr.s1_label([0.01, 0.02], (0.001, 0.02), (0.0005, 0.03))[0] == "consistent positive"


def test_seed_rule_quantities():
    rng = np.random.default_rng(5)
    shared = rng.normal(0, 0.006, 1000)
    per_seed = np.vstack([shared, shared, shared])  # the account term is the same for every seed
    rule = pr.seed_rule(per_seed, per_seed.mean(0), [0.010, 0.020, 0.030])
    assert rule["g"] == pytest.approx(0.0, abs=1e-12)
    assert rule["two_sigma2"] == pytest.approx(1e-4)
    v2 = rule["v_mean"] ** 2
    expected = 2.80 * (np.sqrt(v2 + 1e-4 / 3) - np.sqrt(v2 + 1e-4 / 5))
    assert rule["projected_gain"] == pytest.approx(expected)
    assert rule["rule_fires"] == (expected > 0.003)
    independent = rng.normal(0, 0.006, (3, 1000))
    rule = pr.seed_rule(independent, independent.mean(0), [0.01, 0.01, 0.01])
    assert rule["g"] > 0 and rule["two_sigma2"] == 0.0
    assert pr.seed_rule(independent[:1], independent[0], [0.01]) is None
    rates = pr.null_label_rates(0.006, 0.006, 2 * 0.003 ** 2, 3, False, draws=20_000)
    assert all(0.0 <= v <= 0.1 for v in rates.values())


def test_chunk_positions_follow_the_builder_cut():
    seconds = [0, 0, 1, 2, 3, 4, 5, 6, 6, 7]
    raw = pd.DataFrame({ACCT: ["a"] * 10, TIME: pd.Timestamp("2025-05-01") + pd.to_timedelta(seconds, unit="s")})
    raw = raw.iloc[::-1].reset_index(drop=True)  # file order does not matter
    pos = pr.chunk_positions(raw, ACCT, TIME, 3)
    # chunks by distinct seconds {0,1,2} {3,4,5} {6,7}; same-second rows are not earlier than each other
    assert list(pos[::-1]) == [0, 0, 2, 3, 0, 1, 2, 0, 0, 2]


# ------------------------------------------------------------------------------------------------------------------ #
# End to end on synthetic files
# ------------------------------------------------------------------------------------------------------------------ #
def make_raw(folder, file_numbers, accounts_per_file, rows, seed, tag):
    rng = np.random.default_rng(seed)
    frames = []
    folder.mkdir(parents=True, exist_ok=True)
    for f in file_numbers:
        acct = np.repeat([f"{tag}acct-{f}-{a:04d}" for a in range(accounts_per_file)], rows)
        n = len(acct)
        # rows spread over two months, half of every account in each; whole-second times
        offsets = np.concatenate([np.sort(np.r_[rng.integers(0, 30 * 86400, rows // 2),
                                                rng.integers(31 * 86400, 60 * 86400, rows - rows // 2)])
                                  for _ in range(accounts_per_file)])
        df = pd.DataFrame({ID: [f"{tag}tx-{f}-{i:06d}" for i in range(n)], ACCT: acct,
                           TIME: pd.Timestamp("2025-05-01") + pd.to_timedelta(offsets, unit="s"), "_f": f})
        frames.append(df)
    raw = pd.concat(frames, ignore_index=True)
    fraud_acct = rng.random(raw[ACCT].nunique()) < 0.25
    acct_codes, _ = pd.factorize(raw[ACCT])
    y = (fraud_acct[acct_codes] & (rng.random(len(raw)) < 0.5)).astype(int)
    raw[TARGET] = y
    raw["late"] = raw[TIME] >= pd.Timestamp("2025-06-01")
    raw["effect"] = rng.normal(0, 1, raw[ACCT].nunique())[acct_codes]
    for f in file_numbers:  # the raw files carry the label, as the real ones do
        raw.loc[raw["_f"] == f, [ID, ACCT, TIME, TARGET]].to_parquet(folder / f"part_{f}.parquet", index=False)
    return raw


def write_pred(path, raw, score, drop=0, duplicate=0, foreign=0):
    df = pd.DataFrame({ID: raw[ID], ACCT: raw[ACCT], TARGET: raw[TARGET], "score": score})
    if drop:
        df = df.iloc[drop:]
    if duplicate:
        df = pd.concat([df, df.iloc[:duplicate]], ignore_index=True)
    if foreign:
        extra = df.iloc[:foreign].copy()
        extra[ID] = [f"unknown-{i}" for i in range(foreign)]
        df = pd.concat([df, extra], ignore_index=True)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(path)
    return str(path)


def sigmoid(x):
    return 1 / (1 + np.exp(-x))


@pytest.fixture(scope="module")
def e2e(tmp_path_factory):
    tmp = tmp_path_factory.mktemp("paired")
    ev = make_raw(tmp / "eval_raw", [8000, 8001], 120, 20, seed=1, tag="E")
    va = make_raw(tmp / "valid_raw", [4950], 150, 20, seed=2, tag="V")
    rows = []

    def add(contrast, side, run, seed, ev_score, va_score, valid_broken=None, **broken):
        p = write_pred(tmp / "pred" / f"{run}_{seed}_eval.parquet", ev, ev_score, **broken)
        v = write_pred(tmp / "pred" / f"{run}_{seed}_valid.parquet", va, va_score, **(valid_broken or {}))
        rows.append({"contrast": contrast, "side": side, "run": run, "seed": seed, "prediction_path": p,
                     "validation_path": v})

    def base(raw, s):
        return sigmoid(raw["effect"] + 0.6 * raw[TARGET] + np.random.default_rng(s).normal(0, 1, len(raw)))

    for seed in (42, 43, 44):
        y_ev, y_va = base(ev, seed), base(va, seed + 100)
        better_ev = sigmoid(np.log(y_ev / (1 - y_ev)) + 2.0 * ev[TARGET])
        better_va = sigmoid(np.log(y_va / (1 - y_va)) + 2.0 * va[TARGET])
        add("CLEAR", "x", "A-H5", seed, better_ev, better_va)
        add("CLEAR", "y", "A-H0", seed, y_ev, y_va)
    same_ev, same_va = base(ev, 7), base(va, 8)
    add("SAME", "x", "SAME-X", 42, same_ev, same_va)
    add("SAME", "y", "SAME-Y", 42, same_ev, same_va)
    part_ev = np.where(ev["late"], sigmoid(np.log(same_ev / (1 - same_ev)) + 2.0 * ev[TARGET]), same_ev)
    add("PART", "x", "PART-X", 42, part_ev, same_va)
    add("PART", "y", "SAME-Y", 42, same_ev, same_va)
    add("BROKEN", "x", "BROKEN-X", 42, same_ev, same_va, drop=5, duplicate=2, foreign=1)
    add("BROKEN", "y", "SAME-Y", 42, same_ev, same_va)
    add("VBROKEN", "x", "VBROKEN-X", 42, part_ev, same_va, valid_broken={"drop": 3})
    add("VBROKEN", "y", "SAME-Y", 42, same_ev, same_va)
    add("", "", "B-ALLPOS", 42, base(ev, 9), base(va, 10))
    table = tmp / "runs.csv"
    pd.DataFrame(rows).to_csv(table, index=False)
    out_dir = tmp / "out"
    out = pr.main(["--runs", str(table), "--out-dir", str(out_dir),
                   "--raw-base", str(tmp / "eval_raw"), "--file-start", "8000", "--file-end", "8001",
                   "--valid-raw-base", str(tmp / "valid_raw"), "--valid-file-start", "4950",
                   "--valid-file-end", "4950", "--draws", "200", "--seed", "1",
                   "--depth-matched", "B-ALLPOS:A-H5,A-H0", "--difference", "CLEAR", "PART"])
    return {"out": out, "dir": out_dir, "ev": ev, "va": va, "tmp": tmp}


def contrast(e2e, name):
    return next(c for c in e2e["out"]["contrasts"] if c["contrast"] == name)


def line(e2e, name, ln, split="evaluation"):
    return next(r for r in e2e["out"]["lines"]
                if r["contrast"] == name and r["line"] == ln and r["split"] == split)


def test_identical_models_give_zero_width_interval_and_not_resolved(e2e):
    for split in ("evaluation", "validation"):
        r = line(e2e, "SAME", "overall", split)
        assert r["difference"] == 0.0 and r["ci_low"] == 0.0 and r["ci_high"] == 0.0
    c = contrast(e2e, "SAME")
    assert c["label"] == "not resolved"


def test_clear_difference_is_consistent_positive(e2e):
    c = contrast(e2e, "CLEAR")
    assert c["validation_seed_source"] == "validation predictions"
    assert c["label"] == "consistent positive"
    assert c["evaluation_ci_low"] > 0 and c["validation_ci_low"] > 0
    r = line(e2e, "CLEAR", "overall")
    assert r["seed_pairing"] == "by seed" and r["difference_per_seed"].count(":") == 3
    # the overall AP is the AP over every evaluation row
    ev = e2e["ev"]
    s = pd.read_parquet(e2e["tmp"] / "pred" / "A-H0_42_eval.parquet")["score"].to_numpy()
    assert f"42:{average_precision_score(ev[TARGET], s):.6f}" in r["ap_y_per_seed"]


def test_join_mismatches_are_counted_and_the_contrast_is_marked_not_dropped(e2e):
    run = next(r for r in e2e["out"]["runs"] if r["run"] == "BROKEN-X" and r["split"] == "evaluation")
    assert run["missing_vs_cohort"] == 5
    assert run["duplicate_ids"] == 2
    assert run["unmatched_raw_ids"] == 1
    assert run["join_status"].startswith("join mismatch")
    c = contrast(e2e, "BROKEN")
    assert c["status_evaluation"].startswith("join mismatch")
    assert c["label"] == "not computed: join mismatch"
    marked = [r for r in e2e["out"]["lines"] if r["contrast"] == "BROKEN" and r["split"] == "evaluation"]
    assert marked and all(r["status"].startswith("join mismatch") and "difference" not in r for r in marked)
    overall = next(r for r in marked if r["line"] == "overall")
    assert overall["rows"] == len(e2e["ev"])  # the cohort is not shrunk to the broken run
    # a broken validation join stops the label (its interval is part of the rule)
    v = contrast(e2e, "VBROKEN")
    assert v["status_evaluation"] == "ok" and v["status_validation"].startswith("join mismatch")
    assert v["label"] == "not computed: validation join mismatch"
    # the other contrasts are unaffected
    assert contrast(e2e, "CLEAR")["status_evaluation"] == "ok"
    cohort = next(c for c in e2e["out"]["cohort"] if c["split"] == "evaluation")
    assert cohort["cohort_rows"] == len(e2e["ev"]) and cohort["runs_on_cohort"] == cohort["runs"] - 1
    vcohort = next(c for c in e2e["out"]["cohort"] if c["split"] == "validation")
    assert vcohort["cohort_rows"] == len(e2e["va"]) and vcohort["runs_on_cohort"] == vcohort["runs"] - 1


def test_lines_carry_counts_and_history_availability(e2e):
    ev = e2e["ev"]
    o = line(e2e, "CLEAR", "overall")
    assert o["rows"] == len(ev) and o["frauds"] == int(ev[TARGET].sum())
    assert o["accounts"] == ev[ACCT].nunique()
    assert o["fraud_accounts"] == ev.loc[ev[TARGET] == 1, ACCT].nunique()
    assert o["full_history_share_h5"] == pytest.approx(15 / 20)  # 20 rows per account: 15 have 5 earlier rows
    assert {r["line"] for r in e2e["out"]["lines"] if r["kind"] != "depth-matched reading (no label)"} == {"overall"}
    assert o["draws_valid"] + o["draws_undefined"] == 200


def test_depth_matched_subset_and_difference_of_contrasts(e2e):
    rows = [r for r in e2e["out"]["lines"] if r["kind"].startswith("depth-matched")]
    assert {r["contrast"] for r in rows} == {"B-ALLPOS minus A-H5 (depth-matched subset)",
                                             "B-ALLPOS minus A-H0 (depth-matched subset)"}
    ev = rows[0]
    assert ev["line"] == "position:5" and 0 < ev["rows"] < len(e2e["ev"]) and "label" not in ev
    assert np.isfinite(ev["ci_low"]) and ev["x_seeds"] == "42" and ev["y_seeds"] == "42;43;44"
    diff = [r for r in e2e["out"]["lines"] if r["kind"] == "difference of contrasts"]
    assert diff and all(r["contrast"] == "(CLEAR) minus (PART)" for r in diff)
    o = next(r for r in diff if r["line"] == "overall" and r["split"] == "evaluation")
    assert o["difference"] == pytest.approx(line(e2e, "CLEAR", "overall")["difference"]
                                            - line(e2e, "PART", "overall")["difference"])


def test_seed_rule_reported_for_three_seed_contrast(e2e):
    rows = [s for s in e2e["out"]["seed_rule"] if s["contrast"] == "CLEAR"]
    assert {s["split"] for s in rows} == {"evaluation", "validation"}
    assert all(s["n_paired_seeds"] == 3 and s["rule_split"] == "validation" for s in rows)
    assert all(isinstance(s["rule_fires"], bool) and len(s["v_s"].split(";")) == 3 for s in rows)


def test_outputs_hold_aggregates_only(e2e):
    files = sorted(p.name for p in e2e["dir"].iterdir())
    assert files == ["paired_cohort.csv", "paired_contrasts.csv", "paired_lines.csv", "paired_report.txt",
                     "paired_runs.csv", "paired_seed_rule.csv"]
    text = "\n".join((e2e["dir"] / f).read_text() for f in files)
    ev, va = e2e["ev"], e2e["va"]
    for value in pd.concat([ev[ID], ev[ACCT], va[ID], va[ACCT]]).unique():
        assert value not in text
    assert "unknown-" not in text
    assert str(e2e["tmp"]) not in text  # no prediction paths either
    with open(e2e["dir"] / "paired_lines.csv") as f:
        lines = list(csv.DictReader(f))
    assert len(lines) == len(e2e["out"]["lines"]) < 80
    assert not {ID, ACCT, TARGET, "score"} & set(lines[0])
    report = (e2e["dir"] / "paired_report.txt").read_text()
    assert "consistent positive" in report and "month" not in text.lower()


# ------------------------------------------------------------------------------------------------------------------ #
# One seed per side (owner, OWNER_QA thirty-first message: seed 42 only)
# ------------------------------------------------------------------------------------------------------------------ #
def small_case(tmp, rows):
    """A run table on fresh synthetic files; rows are (contrast, side, run, eval score, drop, valid_ap)."""
    ev = make_raw(tmp / "raw", [8000], 80, 20, seed=4, tag="S")
    table = []
    for contrast, side, run, score, drop, valid_ap in rows:
        path = write_pred(tmp / f"{run}.parquet", ev, score(ev), drop=drop)
        table.append({"contrast": contrast, "side": side, "run": run, "seed": 42, "prediction_path": path,
                      "valid_ap": valid_ap})
    pd.DataFrame(table).to_csv(tmp / "runs.csv", index=False)
    return pr.main(["--runs", str(tmp / "runs.csv"), "--out-dir", str(tmp / "out"), "--raw-base", str(tmp / "raw"),
                    "--file-start", "8000", "--file-end", "8000", "--draws", "100"])


def strong(ev):
    return sigmoid(ev["effect"] + 3.0 * ev[TARGET])


def weak(ev):
    return sigmoid(ev["effect"] + 0.2 * ev[TARGET] + np.random.default_rng(1).normal(0, 1, len(ev)))


def test_report_counts_raw_rows_scored_by_every_run(tmp_path):
    out = small_case(tmp_path, [("C", "x", "X", strong, 1, 0.3), ("C", "y", "Y", weak, 1, 0.1)])
    assert out["cohort"][0]["raw_rows"] == 1600 and out["cohort"][0]["raw_rows_scored_by_every_run"] == 1599
    text = (tmp_path / "out" / "paired_report.txt").read_text()
    assert "evaluation rows in the raw files: 1600; scored by every run: 1599" in text


def test_validation_on_one_side_only_is_incomplete(tmp_path):
    ev = make_raw(tmp_path / "raw", [8000], 80, 20, seed=4, tag="S")
    va = make_raw(tmp_path / "vraw", [4950], 80, 20, seed=5, tag="W")
    rows = [{"contrast": "C", "side": "x", "run": "X", "seed": 42, "valid_ap": 0.3,
             "prediction_path": write_pred(tmp_path / "X.parquet", ev, strong(ev)),
             "validation_path": write_pred(tmp_path / "Xv.parquet", va, strong(va))},
            {"contrast": "C", "side": "y", "run": "Y", "seed": 42, "valid_ap": 0.1,
             "prediction_path": write_pred(tmp_path / "Y.parquet", ev, weak(ev)), "validation_path": ""}]
    pd.DataFrame(rows).to_csv(tmp_path / "runs.csv", index=False)
    out = pr.main(["--runs", str(tmp_path / "runs.csv"), "--out-dir", str(tmp_path / "out"),
                   "--raw-base", str(tmp_path / "raw"), "--file-start", "8000", "--file-end", "8000",
                   "--valid-raw-base", str(tmp_path / "vraw"), "--valid-file-start", "4950",
                   "--valid-file-end", "4950", "--draws", "100"])
    c = out["contrasts"][0]
    assert c["evaluation_ci_low"] > 0  # the valid_ap sign alone would have given "consistent positive"
    assert c["label"] == "not resolved (validation incomplete)"
    assert {r["line"] for r in out["lines"] if r["split"] == "evaluation" and "difference" in r} == {"overall"}


def test_one_seed_label_needs_its_validation_difference(tmp_path):
    out = small_case(tmp_path, [("C", "x", "X", strong, 0, 0.1), ("C", "y", "Y", weak, 0, 0.2)])
    c = out["contrasts"][0]
    assert c["evaluation_ci_low"] > 0 and c["validation_seed_differences"] == "-0.100000"
    assert c["label"] == "not resolved"  # the S1 direction-disagreement case, read as not resolved with one seed
    assert c["direction_disagreement"] == "not applicable (one seed)"
    out = small_case(tmp_path / "b", [("C", "x", "X", strong, 0, 0.2), ("C", "y", "Y", weak, 0, 0.1)])
    assert out["contrasts"][0]["label"] == "consistent positive"
    out = small_case(tmp_path / "c", [("C", "x", "X", strong, 0, ""), ("C", "y", "Y", weak, 0, "")])
    assert out["contrasts"][0]["label"] == "not resolved (no validation)"


def test_one_seed_contrasts_skip_direction_disagreement_and_seed_rule(e2e):
    c = contrast(e2e, "SAME")
    assert c["direction_disagreement"] == "not applicable (one seed)"
    assert contrast(e2e, "CLEAR")["direction_disagreement"] == "no"
    rows = [s for s in e2e["out"]["seed_rule"] if s["contrast"] == "SAME"]
    assert {s["split"] for s in rows} == {"evaluation", "validation"}
    assert all(s["seed_rule"] == "one seed: not computed" for s in rows)
    assert "SAME on evaluation: one seed: not computed" in (e2e["dir"] / "paired_report.txt").read_text()


# ------------------------------------------------------------------------------------------------------------------ #
# The shared V1 fake-data fixture (branch reviewer/v1-fake-data-2026-10-12), the same data every lane tests on
# ------------------------------------------------------------------------------------------------------------------ #
FIXTURE = Path(os.environ.get("V1_FIXTURE", "/tmp/v1fix"))
# The design's V1 contrasts (DESIGN_V1 section 3), X minus Y, all at seed 42. C3 is the time-gap family.
V1_CONTRASTS = [
    ("C1-AH05-AH00", "A-H05", "A-H00"), ("C2-AH10-AH05", "A-H10", "A-H05"),
    ("C3-GAP-H05", "A-H05", "A-GAP05-OFF"), ("C3-GAP-H10", "A-H10", "A-GAP10-OFF"),
    ("C4-AH05-REF", "A-H05", "REF-SINGLE"), ("C5-BH05-AH05", "B-H05", "A-H05"),
    ("X-MASK-AH05", "A-H05", "A-MASK05-C"), ("X-BH05-BH00", "B-H05", "B-H00"),
    ("X-AH15-AH10", "A-H15", "A-H10"), ("X-AH20-AH15", "A-H20", "A-H15"),
    ("X-BH10-BH05", "B-H10", "B-H05"), ("X-BH15-BH10", "B-H15", "B-H10"), ("X-BH20-BH15", "B-H20", "B-H15"),
]


def fixture_run_table(fix, folder):
    runs = pd.read_csv(fix / "runs.csv")
    path = {(r.run, r.split): str(fix / r.prediction_path) for r in runs.itertuples()}
    rows = []
    for name, x, y in V1_CONTRASTS:
        for side, run in (("x", x), ("y", y)):
            rows.append({"contrast": name, "side": side, "run": run, "seed": 42,
                         "prediction_path": path[(run, "eval")], "validation_path": path[(run, "valid")]})
    rows.append({"contrast": "", "side": "", "run": "B-ALLPOS-H5", "seed": 42,
                 "prediction_path": path[("B-ALLPOS-H5", "eval")],
                 "validation_path": path[("B-ALLPOS-H5", "valid")]})
    table = folder / "v1_runs.csv"
    pd.DataFrame(rows).to_csv(table, index=False)
    return table


@pytest.mark.skipif(not (FIXTURE / "CHECKSUMS.json").is_file(),
                    reason="shared fixture not checked out: git worktree add /tmp/v1fix "
                           "origin/reviewer/v1-fake-data-2026-10-12 (or set V1_FIXTURE)")
def test_v1_contrasts_on_the_shared_fixture(tmp_path):
    fix = tmp_path / "fixture"
    for part in ("fake_s3", "predictions"):
        shutil.copytree(FIXTURE / part, fix / part)
    for name in ("runs.csv", "CHECKSUMS.json", "verify_fixture.py"):
        shutil.copy2(FIXTURE / name, fix / name)
    check = subprocess.run([sys.executable, str(fix / "verify_fixture.py"), str(fix), str(fix / "fake_s3")],
                           capture_output=True, text=True, check=False)
    assert check.returncode == 0, check.stdout + check.stderr
    raw = fix / "fake_s3" / "DATA_BUCKET"
    out = pr.main(["--runs", str(fixture_run_table(fix, tmp_path)), "--out-dir", str(tmp_path / "out"),
                   "--raw-base", str(raw / "tfm_EVAL_raw_data"), "--valid-raw-base", str(raw / "tfm_raw_data"),
                   "--depth-matched", "B-ALLPOS-H5:B-H05,A-H05", "--difference", "C3-GAP-H10", "C3-GAP-H05"])
    cohorts = {c["split"]: c for c in out["cohort"]}
    assert cohorts["evaluation"]["cohort_rows"] == 7477 and cohorts["evaluation"]["cohort_frauds"] == 312
    assert cohorts["validation"]["cohort_rows"] == 4230 and cohorts["validation"]["cohort_frauds"] == 146
    assert all(c["runs_on_cohort"] == c["runs"] == 15 for c in cohorts.values())
    assert {r["line"] for r in out["lines"] if r["kind"] == "contrast"} == {"overall"}
    for c in out["contrasts"]:
        assert c["status_evaluation"] == c["status_validation"] == "ok"
        assert c["direction_disagreement"] == "not applicable (one seed)"
    labels = {c["contrast"]: c["label"] for c in out["contrasts"]}
    positive = {"C1-AH05-AH00", "C3-GAP-H05", "C4-AH05-REF", "X-BH05-BH00"}
    assert {k for k, v in labels.items() if v == "consistent positive"} == positive
    assert {k for k, v in labels.items() if v == "consistent negative"} == {"C5-BH05-AH05"}
    assert all(v == "not resolved" for k, v in labels.items() if k not in positive | {"C5-BH05-AH05"})
    assert {s["seed_rule"] for s in out["seed_rule"]} == {"one seed: not computed"}
    depth = [r for r in out["lines"] if r["kind"].startswith("depth-matched")]
    assert len(depth) == 4 and all(r["status"] == "ok" and r["rows"] > 0 for r in depth)
