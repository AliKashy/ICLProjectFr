# reviewer, 2026-10-11. First-release regression tests for the batch scripts (FIRST_RELEASE_SCOPE v2.8 section 2):
# RUN-05 (R-033) comparator validation, inherited harness state (RG-F16), the pre-flight gate and the return folder
# (RG-F02; R-035, R-063), the interpreter (RG-F12), ST13 host memory, the smoke hooks and resume. Synthetic only: a
# stand-in `python` replaces the pre-flight, run_step.py and the scorer in the batch scripts; a stand-in runner replaces
# run_ablations.py under run_step.py. Nothing trains, nothing reaches storage. 2026-10-12 (V1 build item B5): batch 2
# as one stage: its step list, no capacity step, the batch 1 ledger check (R-009), the A-H10 record kept as a record
# (R-033), resume, and its spec files (B6).
#     PYTHONPATH=src:. python -m pytest -q -p no:cacheprovider runbook/2026-10-07/tests/test_batch_fr1.py
import csv
import hashlib
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import uuid
from pathlib import Path

import pytest
from omegaconf import OmegaConf

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[1]


def load(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return m


collector = load("fr1_collector", HERE / "collect_returns.py")
tools = load("fr1_batch_tools", HERE / "batch_tools.py")
contracts = load("fr1_contracts_helpers", HERE / "tests" / "test_runbook_contracts.py")
H10_SPEC = "ft_decisions_flat_h10.yaml"
# Every V1 run uses seed 42 only (owner, OWNER_QA thirty-first message): batch 1 has four steps, six runs.
ALL_B1 = ["ft_decisions_h0.yaml", "ft_decisions_hier.yaml", H10_SPEC, "ft_decisions_timedelta.yaml"]
# Batch 2, design section 2, stage 2 at seed 42 (owner's thirty-first message), in batch2.sh's run order (steps 2.1 to
# 2.8; step 2.0 is the post-hoc scoring).
ALL_B2 = [("base", "ref_single.yaml"), ("phase4b", "ft_decisions_hier_h0_scored.yaml"),
          ("phase4a", "ft_decisions_mask_causal.yaml"), ("phase4a", "ft_decisions_gap05_off.yaml"),
          ("phase4a", "ft_decisions_flat_h15.yaml"), ("phase4b", "ft_decisions_hier_long.yaml"),
          ("phase4a", "ft_decisions_flat_h20.yaml"), ("phase4b", "ft_decisions_hier_allpos.yaml")]
# Kept in the tree for a later seed study, never run in V1.
SEED_SPECS = [("phase4a", "ft_decisions_h0_seeds.yaml"), ("phase4b", "ft_decisions_hier_seeds.yaml"),
              ("phase4a", "ft_decisions_h10_seeds.yaml"), ("phase4a", "ft_decisions_h10_seeds_off.yaml")]

# ---------------------------------------------------------------- the stand-in `python` for batch1.sh and batch2.sh
FAKE_PY = r"""#!/bin/sh
# Stand-in for the interpreter in batch1.sh/batch2.sh: pre-flight, run_step.py and score_attempt.py are replaced by
# recognisable lines and the files the scripts expect; everything else (batch_tools.py, collect_returns.py) is real.
REAL="__REAL__"
case "$1" in
  *preflight_pod.py) shift; while [ $# -gt 0 ]; do [ "$1" = --out-root ] && root="$2"; shift; done
     if [ "${FAKE_PF_CRASH:-}" = 1 ]; then echo "Traceback: stopped before creating its folder"; exit 2; fi
     d="$root/20261008T000000Z"; mkdir -p "$d"; echo '{}' > "$d/data_contract.json"
     echo "SENTINEL_VALUE" > "$d/errors.txt"; echo "checks" > "$d/checks.txt"
     if [ "${FAKE_PF_NO_RESULT:-}" = 1 ]; then echo "pre-flight without a verdict line" > "$d/SUMMARY.txt"
     else printf 'pre-flight\nRESULT %s | 0 FAIL, 0 WARN | overrides: none | exit %s\n' "${FAKE_PF_RESULT:-PASS}" "${FAKE_PF_RC:-0}" > "$d/SUMMARY.txt"; fi
     echo "MARK pre-flight"; echo "PREFLIGHT_DIR=$d"; exit "${FAKE_PF_RC:-0}" ;;
  *run_step.py) prev=""; bd=""; for a in "$@"; do case "$a" in *.yaml) spec="$a" ;; esac; [ "$prev" = --batch-dir ] && bd="$a"; prev="$a"; done
     ret="$RUNBOOK_SANDBOX/runs/returns/${spec%.yaml}_$(date -u +%Y%m%dT%H%M%SZ)_$$"; mkdir -p "$ret"
     mkdir -p "$RUNBOOK_SANDBOX/runs/logs"; echo "runner log of $spec" > "$RUNBOOK_SANDBOX/runs/logs/$(basename "$ret").runner.log"
     att="${FAKE_ATTEMPT_DIR:-$RUNBOOK_SANDBOX/att_$spec}"
     printf 'spec: phase4a/%s\ninterpreter: %s\nattempt_dir: %s\nrunner_exit: 0\nfinished_utc: now\n' "$spec" "$REAL" "$att" > "$ret/STEP.txt"
     printf 'RETURN fake | 1 run(s)\nledger run_log.csv: +1 appended, 0 unchanged, 0 conflict(s)\nACCEPTED: every run ok\n' > "$ret/RETURN.txt"
     if [ -n "$bd" ]; then mkdir -p "$bd/steps/$(basename "$ret")"; cp "$ret/STEP.txt" "$bd/steps/$(basename "$ret")/"; fi
     n=$(basename "$ret"); mkdir -p "$RUNBOOK_SANDBOX/runs/logs" "$RUNBOOK_SANDBOX/runs/gpu"
     echo "trainer output" > "$RUNBOOK_SANDBOX/runs/logs/$n.runner.log"; echo "utc,rss_mib" > "$RUNBOOK_SANDBOX/runs/gpu/$n.host_rss.csv"
     echo "other step file" > "$ret/notes.log"
     if [ "${FAKE_ATTEMPT_FILES:-}" = 1 ]; then mkdir -p "$att/run1/predictions"; echo "log" > "$att/run1/train.log"
       echo "ckpt" > "$att/run1/best.ckpt"; echo "rows" > "$att/run1/predictions/part_8000.parquet"; fi
     echo "MARK step $spec"; echo "RETURN_DIR=$ret"; echo "ATTEMPT_DIR=$att"; exit 0 ;;
  *score_attempt.py) echo "MARK post-hoc scoring"; exit "${FAKE_SCORE_RC:-0}" ;;
  *) exec "$REAL" "$@" ;;
esac
"""


def fake_python(tmp):
    fake = tmp / "bin"
    fake.mkdir(exist_ok=True)
    p = fake / "python"
    p.write_text(FAKE_PY.replace("__REAL__", sys.executable))
    p.chmod(0o755)
    return p


def batch_env(tmp, **extra):
    env = {k: v for k, v in os.environ.items()
           if k not in ("RUNBOOK_SANDBOX", "BATCH1_SKIP", "BATCH2_SKIP", "PREFLIGHT_ARGS", "A_H10_COMPARATOR",
                        "BATCH1_RESUME", "BATCH1_RETURN", "BATCH1_LEDGER", "BATCH2_RESUME", "RUNBOOK_BANK_OVERRIDES",
                        "PYTHON")}
    env.update(PYTHON=str(fake_python(tmp)), RUNBOOK_SANDBOX=str(tmp / "sb"), RUNBOOK_BANK_OVERRIDES="1")
    env.update({k: v for k, v in extra.items() if v is not None})
    for k, v in extra.items():
        if v is None:
            env.pop(k, None)
    return env


def b1_ledger(path, attempt_dirs=None, status="ok", run_score="false"):
    """A minimal valid ledger (the collector's schema) with one row per attempt folder; by default one validation-only
    ok run of a batch 1 attempt, the rows batch2.sh's ledger check (R-009) looks for."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    attempt_dirs = attempt_dirs or [path.parent.parent / "ablations" / "arch_a_flat" / "history_h0_vs_h5" /
                                    "20261011T000000Z-a1"]
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=collector.LEDGER_COLS, lineterminator="\n")
        w.writeheader()
        for att in attempt_dirs:
            row = {c: "" for c in collector.LEDGER_COLS}
            row.update(ledger_schema=collector.LEDGER_SCHEMA, attempt_dir=str(att), attempt=Path(att).name,
                       run_name="history-h0", status=status, run_score=run_score, revision="1")
            w.writerow(row)
    return path


def run_batch(script, env):
    """The batch as MORNING.md runs it: stdout and stderr into one console log (the step output is tee'd to stderr)."""
    return subprocess.run(["bash", str(HERE / script)], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                          env=env, timeout=300)


# ---------------------------------------------------------------- inherited harness state
@pytest.mark.parametrize("var", ["RUNBOOK_SANDBOX", "BATCH1_SKIP", "PREFLIGHT_ARGS"])
def test_batch1_stops_on_inherited_harness_state(tmp_path, var):
    env = batch_env(tmp_path, RUNBOOK_BANK_OVERRIDES=None, RUNBOOK_SANDBOX=None)
    env[var] = str(tmp_path / "sb") if var == "RUNBOOK_SANDBOX" else "x"
    p = run_batch("batch1.sh", env)
    assert p.returncode == 1 and "STOPPED BEFORE START" in p.stdout and var in p.stdout
    assert "MARK" not in p.stdout and not (tmp_path / "sb").exists()


def test_batch_stop_message_names_every_variable_in_one_sentence(tmp_path):
    env = batch_env(tmp_path, RUNBOOK_BANK_OVERRIDES=None, BATCH1_SKIP="x", BATCH2_SKIP="x")
    for script, skip in (("batch1.sh", "BATCH1_SKIP"), ("batch2.sh", "BATCH2_SKIP")):
        p = run_batch(script, env)
        assert p.returncode == 1 and f"STOPPED BEFORE START: set in this shell: RUNBOOK_SANDBOX {skip}. These belong" in p.stdout


def test_batch2_stops_on_inherited_harness_state(tmp_path):
    p = run_batch("batch2.sh", batch_env(tmp_path, RUNBOOK_BANK_OVERRIDES=None))
    assert p.returncode == 1 and "STOPPED BEFORE START" in p.stdout and "MARK" not in p.stdout


@pytest.mark.parametrize("var", ["RUNBOOK_SANDBOX", "BATCH1_SKIP", "PREFLIGHT_ARGS"])
def test_run_step_stops_on_inherited_harness_state(tmp_path, var):
    env = {k: v for k, v in os.environ.items() if k not in ("RUNBOOK_SANDBOX", "BATCH1_SKIP", "PREFLIGHT_ARGS",
                                                            "RUNBOOK_BANK_OVERRIDES")}
    env[var] = str(tmp_path / "sb") if var == "RUNBOOK_SANDBOX" else "x"
    cmd = [sys.executable, str(HERE / "run_step.py"), "--phase", "phase4a", "--spec", "no_such_spec.yaml"]
    p = subprocess.run(cmd, capture_output=True, text=True, env=env, timeout=120)
    assert p.returncode == 3 and "STOPPED BEFORE START" in p.stdout and var in p.stdout
    # With the explicit bank-side flag the guard is off: the script goes on (and fails later on the missing spec).
    p = subprocess.run(cmd, capture_output=True, text=True, env={**env, "RUNBOOK_BANK_OVERRIDES": "1"}, timeout=120)
    assert p.returncode != 3 and "STOPPED BEFORE START" not in p.stdout


def test_harness_entry_point_sets_the_bank_override_flag():
    text = (HERE / "synthetic" / "run_synthetic_e2e.sh").read_text()
    assert "RUNBOOK_BANK_OVERRIDES=1" in text and text.index("RUNBOOK_BANK_OVERRIDES=1") < text.index("bash runbook/2026-10-07/batch1.sh")


# ---------------------------------------------------------------- the pre-flight gate and the return folder (RG-F02)
def return_folder(tmp):
    return tmp / "sb" / "returns" / "batch1_summary"


@pytest.mark.parametrize("script,case,extra", [
    ("batch1.sh", "result_fail", {"FAKE_PF_RESULT": "FAIL"}),
    ("batch1.sh", "no_result_line", {"FAKE_PF_NO_RESULT": "1"}),
    ("batch1.sh", "nonzero_exit", {"FAKE_PF_RC": "1"}),
    ("batch2.sh", "result_fail", {"FAKE_PF_RESULT": "FAIL"}),
])
def test_batch_refuses_to_train_unless_the_preflight_result_is_pass(tmp_path, script, case, extra):
    if script == "batch2.sh":
        b1_ledger(tmp_path / "sb" / "runs" / "run_log.csv")
    p = run_batch(script, batch_env(tmp_path, **extra))
    assert p.returncode == 1 and "PRE-FLIGHT FAILED" in p.stdout and "MARK step" not in p.stdout
    assert "MARK post-hoc" not in p.stdout
    out = tmp_path / "sb" / "returns" / ("batch1_summary" if script == "batch1.sh" else "batch2_summary")
    assert "stopped at the pre-flight" in (out / "BATCH_STATUS.txt").read_text()
    [pf] = [d for d in out.iterdir() if d.name.startswith("preflight_")]
    assert (pf / "SUMMARY.txt").is_file() and (pf / "data_contract.json").is_file() and (pf / "checks.txt").is_file()
    assert (pf / "errors.txt").is_file()  # OWNER_QA twenty-sixth: every file is sent


def test_batch1_never_takes_an_older_preflight_folder(tmp_path):
    """n1: a pre-flight that stopped before creating its folder (exit 2, no PREFLIGHT_DIR line) is not replaced by an
    older pre-flight folder in the status line or the copy."""
    (tmp_path / "sb" / "preflight" / "20261001T000000Z").mkdir(parents=True)
    p = run_batch("batch1.sh", batch_env(tmp_path, FAKE_PF_CRASH="1"))
    assert p.returncode == 1 and "PRE-FLIGHT FAILED (exit 2" in p.stdout and "MARK step" not in p.stdout
    out = return_folder(tmp_path)
    assert "folder not found" in (out / "BATCH_STATUS.txt").read_text() and "20261001T000000Z" not in p.stdout
    assert not [d for d in out.iterdir() if d.name.startswith("preflight_")]


def test_batch1_return_folder_is_filled_step_by_step(tmp_path):
    p = run_batch("batch1.sh", batch_env(tmp_path))
    out = return_folder(tmp_path)
    assert p.stdout.count("MARK step ") == 3  # the fake A-H10 attempt fails validation, so the time-gap control is held
    assert "skipped ft_decisions_timedelta.yaml" in p.stdout and "COMPARATOR REJECTED" in p.stdout
    assert "skipped ft_decisions_timedelta.yaml: the A-H10 run (ft_decisions_flat_h10.yaml) has no checked result in this " \
        "batch" in p.stdout and "Send the return folder" in p.stdout and "A_H10_COMPARATOR=<attempt folder>" not in p.stdout
    steps = sorted(d.name for d in (out / "steps").iterdir())
    assert [s.rsplit("_", 2)[0] for s in steps] == sorted(s[:-5] for s in ALL_B1 if s != "ft_decisions_timedelta.yaml")
    for d in (out / "steps").iterdir():
        assert (d / "RETURN.txt").is_file() and (d / "STEP.txt").is_file()
        assert "ACCEPTED" in (d / "RETURN.txt").read_text()
    status = (out / "BATCH_STATUS.txt").read_text()
    assert status.count("started ft_decisions") == 3 and status.count("finished ft_decisions") == 3
    assert "batch 1 finished" in status
    assert "comparator: this batch's A-H10 failed the check (run_step exit 0; see SHARED_COMPARATOR.txt)" in status
    assert (out / "RETURN.txt").is_file() and (out / "run_log_batch1.csv").is_file()
    assert (out / "SHARED_COMPARATOR.txt").read_text().startswith("A_H10_COMPARATOR=") \
        and "valid=no" in (out / "SHARED_COMPARATOR.txt").read_text()
    [pf] = [d for d in out.iterdir() if d.name.startswith("preflight_")]
    assert (pf / "errors.txt").is_file()  # OWNER_QA twenty-sixth: every file is sent


def test_batch1_return_holds_every_step_file_except_checkpoints_and_predictions(tmp_path):
    """OWNER_QA twenty-sixth ("Yes. No local only") and reviewer 6130441861: each step's whole return, its runner log and
    memory samples, and its attempt folder go into the batch return; checkpoints and prediction files stay on the pod
    (the owner's answer to OQ-24)."""
    run_batch("batch1.sh", batch_env(tmp_path, FAKE_ATTEMPT_FILES="1"))
    out = return_folder(tmp_path)
    steps = list((out / "steps").iterdir())
    assert steps
    for d in steps:
        assert (d / f"{d.name}.runner.log").read_text() == "trainer output\n"
        assert (d / f"{d.name}.host_rss.csv").is_file() and (d / "notes.log").is_file()
    attempts = list((out / "attempts").iterdir())
    assert attempts and all((a / "run1" / "train.log").is_file() for a in attempts)
    assert not list(out.rglob("*.ckpt")) and not list(out.rglob("*.parquet"))


def test_batch1_ignores_an_override_when_a_h10_runs_in_the_batch(tmp_path):
    p = run_batch("batch1.sh", batch_env(tmp_path, A_H10_COMPARATOR=str(tmp_path / "nowhere")))
    assert "the fresh run is the comparator" in p.stdout and "COMPARATOR REFUSED" not in p.stdout
    assert p.stdout.count("MARK step ") == 3


def test_batch1_refuses_an_invalid_override_before_training(tmp_path):
    p = run_batch("batch1.sh", batch_env(tmp_path, A_H10_COMPARATOR=str(tmp_path / "nowhere"), BATCH1_SKIP=H10_SPEC))
    assert p.returncode == 1 and "COMPARATOR REFUSED" in p.stdout and "MARK step" not in p.stdout
    assert "Unset A_H10_COMPARATOR and start again. Nothing was trained." in p.stdout
    rec = (return_folder(tmp_path) / "SHARED_COMPARATOR.txt").read_text()
    assert "valid=no" in rec and "does not exist" in rec and "origin=override" in rec


def test_batch1_resume_refuses_a_recorded_comparator_that_no_longer_passes(tmp_path):
    """m2: the refusal for a comparator recorded in the return folder asks for the folder, not for a variable."""
    out = return_folder(tmp_path)
    step = out / "steps" / "ft_decisions_flat_h10_20261011T000000Z"
    step.mkdir(parents=True)
    (out / "BATCH_STATUS.txt").write_text("started\n")
    (step / "STEP.txt").write_text(f"spec: phase4a/{H10_SPEC}\nattempt_dir: {tmp_path / 'gone'}\nfinished_utc: t\n")
    (step / "RETURN.txt").write_text("ACCEPTED: every run ok\n")
    (out / "SHARED_COMPARATOR.txt").write_text(f"A_H10_COMPARATOR={tmp_path / 'gone'}\nvalid=yes\n")
    p = run_batch("batch1.sh", batch_env(tmp_path, BATCH1_RESUME=str(out)))
    assert p.returncode == 1 and "MARK step" not in p.stdout
    assert f"COMPARATOR REFUSED: the A-H10 result recorded in {out} no longer passes the check" in p.stdout
    assert "Send this folder." in p.stdout and "Unset A_H10_COMPARATOR" not in p.stdout


def test_batch1_accepts_a_valid_override_when_a_h10_is_skipped_and_runs_the_control(tmp_path):
    att = h10_attempt(tmp_path)
    (tmp_path / "sb" / "runs").mkdir(parents=True)
    ledger_with(tmp_path / "sb" / "runs", att)  # the sandbox ledger batch1.sh reads
    (tmp_path / "sb" / "specs").mkdir()  # the sandbox's spec copy (run_step.py writes it), which the comparator reads
    shutil.copyfile(ROOT / "YOUR_PACKAGE/phase4a/configs" / H10_SPEC, tmp_path / "sb" / "specs" / f"phase4a_{H10_SPEC}")
    env = batch_env(tmp_path, A_H10_COMPARATOR=str(att), BATCH1_SKIP=H10_SPEC)
    p = run_batch("batch1.sh", env)
    assert "COMPARATOR OK" in p.stdout and "COMPARATOR REFUSED" not in p.stdout
    assert p.stdout.count("MARK step ") == 3 and "MARK step ft_decisions_timedelta.yaml" in p.stdout
    rec = (return_folder(tmp_path) / "SHARED_COMPARATOR.txt").read_text()
    assert f"A_H10_COMPARATOR={os.path.realpath(att)}" in rec and "valid=yes" in rec and "origin=override" in rec
    assert f"shared A-H10 comparator: {att} (validated" in p.stdout
    assert (return_folder(tmp_path) / "comparator_source_files.csv").is_file()


def b2_folder(tmp):
    return tmp / "sb" / "returns" / "batch2_summary"


def b2_steps():
    """The (phase, spec) step lines of batch2.sh's STEPS list, in order."""
    text = (HERE / "batch2.sh").read_text()
    block = text[text.index("STEPS=(") + len("STEPS=("):]
    block = block[:block.index("\n)\n")]
    return re.findall(r'^\s*"(base|phase4[ab]) ([\w.]+\.yaml)"', block, flags=re.M)


def test_batch2_runs_every_design_step_in_order_and_keeps_the_comparator_as_a_record(tmp_path):
    env = batch_env(tmp_path)
    assert run_batch("batch1.sh", env).stdout.count("MARK step ") == 3
    b1_ledger(tmp_path / "sb" / "runs" / "run_log.csv")
    p = run_batch("batch2.sh", env)
    marks = [line.split("MARK step ", 1)[1] for line in p.stdout.splitlines() if line.startswith("MARK step ")]
    assert marks == [spec for _, spec in ALL_B2], p.stdout
    assert p.stdout.index("BATCH 1 LEDGER OK") < p.stdout.index("MARK pre-flight") < p.stdout.index("MARK post-hoc scoring")
    assert p.stdout.index("MARK post-hoc scoring") < p.stdout.index("MARK step ")
    assert "capacity" not in p.stdout
    # batch 1's A-H10 (the stand-in attempt fails the check) is recorded, and nothing is skipped because of it.
    assert "record only: batch 1's A-H10 differs from this checkout" in p.stdout
    out = b2_folder(tmp_path)
    rec = (out / "SHARED_COMPARATOR.txt").read_text()
    assert "origin=batch1_return" in rec and "used_by=record only (batch 2)" in rec
    assert (out / "comparator_source_files.csv").exists() or "valid=no" in rec
    status = (out / "BATCH_STATUS.txt").read_text()
    assert status.count("started ft_decisions") + status.count("started ref_single") == len(ALL_B2)
    assert "finished the post-hoc scoring: exit 0" in status and "A-H10 record:" in status and "record only" in status
    assert (out / "run_log_batch2.csv").is_file() and (out / "RETURN.txt").is_file()
    [pf] = [d for d in out.iterdir() if d.name.startswith("preflight_")]
    assert (pf / "errors.txt").is_file() and (pf / "SUMMARY.txt").is_file()  # the whole pre-flight folder


def test_batch2_without_a_batch1_comparator_still_runs_every_step(tmp_path):
    b1_ledger(tmp_path / "sb" / "runs" / "run_log.csv")
    p = run_batch("batch2.sh", batch_env(tmp_path))
    assert p.stdout.count("MARK step ") == len(ALL_B2)
    assert "has no SHARED_COMPARATOR.txt, so no A-H10 source record is written" in p.stdout
    assert not (b2_folder(tmp_path) / "SHARED_COMPARATOR.txt").exists()


# ---------------------------------------------------------------- R-009: the batch 1 ledger is checked first
@pytest.mark.parametrize("case", ["missing", "no_batch1_rows", "no_columns"])
def test_batch2_refuses_to_start_without_batch1_ledger(tmp_path, case):
    ledger = tmp_path / "sb" / "runs" / "run_log.csv"
    if case == "no_batch1_rows":
        b1_ledger(ledger, [tmp_path / "sb" / "ablations" / "arch_a_flat" / "history_h15" / "20261011T000000Z-a1"])
    elif case == "no_columns":
        ledger.parent.mkdir(parents=True)
        ledger.write_text("a,b\n1,2\n")
    p = run_batch("batch2.sh", batch_env(tmp_path))
    assert p.returncode == 1 and "BATCH 1 LEDGER NOT FOUND: nothing was run" in p.stdout
    assert "MARK" not in p.stdout  # neither the pre-flight nor any step nor the scoring ran
    assert "BATCH1_LEDGER" in p.stdout
    status = (b2_folder(tmp_path) / "BATCH_STATUS.txt").read_text()
    assert "stopped: batch 1 ledger" in status


def test_batch2_reads_batch1_ledger_named_by_batch1_ledger(tmp_path):
    """The release note's line for a new folder: BATCH1_LEDGER names batch 1's ledger; the scorer reads that file."""
    other = b1_ledger(tmp_path / "old_folder" / "runs" / "run_log.csv")
    p = run_batch("batch2.sh", batch_env(tmp_path, BATCH1_LEDGER=str(other)))
    assert "BATCH 1 LEDGER OK: " + str(other) in p.stdout and p.stdout.count("MARK step ") == len(ALL_B2)
    assert f"batch 1 ledger {other}" in (b2_folder(tmp_path) / "BATCH_STATUS.txt").read_text()


def test_batch1_ledger_check_counts_rows_by_batch1_output_roots(tmp_path):
    roots = tools.batch1_roots()
    assert set(roots.values()) == set(ALL_B1) and "ablations/arch_a_flat/history_h0_vs_h5" in roots
    code = tmp_path / "code"
    ledger = b1_ledger(tmp_path / "run_log.csv", [code / "ablations/arch_a_flat/history_h0_vs_h5/a1",
                                                   code / "ablations/arch_a_flat/history_h10/a2",
                                                   code / "ablations/arch_a_flat/history_h15/a3"])
    cmd = [sys.executable, str(HERE / "batch_tools.py"), "batch1-ledger", "--ledger", str(ledger)]
    env = {k: v for k, v in os.environ.items() if k != "RUNBOOK_SANDBOX"}
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=120, env=env)
    assert p.returncode == 0 and "2 batch 1 run(s) in 2 attempt folder(s); 2 ok, 2 of them validation-only" in p.stdout


def test_batch1_ledger_check_matches_the_whole_output_root(tmp_path):
    """L2-SCRIPT-06: phase4b ft_decisions_hier_h0.yaml's folder ends in the same name (history_h0_vs_h5) as batch 1's
    A h0 spec; a ledger holding only its rows is not batch 1's ledger."""
    code = tmp_path / "code"
    ledger = b1_ledger(tmp_path / "run_log.csv", [code / "ablations/arch_b_hier/history_h0_vs_h5/a1"])
    cmd = [sys.executable, str(HERE / "batch_tools.py"), "batch1-ledger", "--ledger", str(ledger)]
    env = {k: v for k, v in os.environ.items() if k != "RUNBOOK_SANDBOX"}
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=120, env=env)
    assert p.returncode == 1 and "BATCH 1 LEDGER HAS NO BATCH 1 RUNS" in p.stdout
    assert tools.is_batch1_attempt(str(code / "ablations/arch_a_flat/history_h0_vs_h5/a1"), tools.batch1_roots())
    assert not tools.is_batch1_attempt(str(code / "ablations/arch_b_hier/history_h0_vs_h5/a1"), tools.batch1_roots())


# ---------------------------------------------------------------- the step list and its spec files (B5, B6)
def test_batch2_step_list_is_the_design_stage_2():
    assert b2_steps() == ALL_B2
    text = (HERE / "batch2.sh").read_text()
    code = "\n".join(line.split("#", 1)[0] for line in text.splitlines() if not line.lstrip().startswith("#"))
    assert "capacity" not in code and "H10_DIR" not in code  # capacity and its comparator branch are V2
    # Seed 42 only (owner's thirty-first message): no seeds file is a step of either batch.
    for script in ("batch1.sh", "batch2.sh"):
        steps = re.findall(r'"(?:base|phase4[ab]) ([\w.]+\.yaml)"', (HERE / script).read_text())
        assert not [s for s in steps if "seeds" in s], script
    header = text[:text.index("set -uo pipefail")]
    assert "Why this order" in header and "one GPU" in header and "seed 42" in header and "47.5 h" in header
    # REF-SINGLE is called exactly like the other steps (lane L1's fixed interface).
    assert '"base ref_single.yaml"' in text
    assert 'run_step.py" --phase "$1" --spec "$2" --preflight "$PFDIR" --batch-dir "$OUT"' in text
    assert 'BATCH2_RESUME' in text and 'resume-state --batch-dir "$OUT" --spec "$2"' in text


def _spec_path(phase, name):
    return ROOT / "YOUR_PACKAGE" / phase / "configs" / name


def test_every_batch2_spec_exists_is_scored_and_has_its_own_output_root():
    roots = {}
    for phase in ("phase4a", "phase4b"):
        for p in sorted((ROOT / "YOUR_PACKAGE" / phase / "configs").glob("ft_decisions*.yaml")):
            roots.setdefault(str(OmegaConf.load(p).output_root).rstrip("/"), []).append(f"{phase}/{p.name}")
    for phase, name in ALL_B2:
        path = _spec_path(phase, name)
        if phase == "base":
            # Lane L1 writes YOUR_PACKAGE/base/configs/ref_single.yaml (build item B8); checked here once it is there.
            assert name == "ref_single.yaml"
            if not path.is_file():
                continue
        assert path.is_file(), f"{phase}/{name} is named by batch2.sh but does not exist"
        spec = OmegaConf.load(path)
        root = str(spec.output_root).rstrip("/")
        if phase != "base":
            assert roots[root] == [f"{phase}/{name}"], f"{name} shares its output_root with {roots[root]}"
            assert bool(spec.run_score) is True, f"{name}: every batch 2 cell is scored on 8000-8010"
            assert str(spec.results_csv) == root + "/results.csv"
    # Prediction names start with the output_root's folder name (under each phase's own predictions folder), so a
    # batch 2 spec's folder name is unique within its phase too.
    for phase, name in ALL_B2:
        if phase == "base":
            continue
        mine = os.path.basename(str(OmegaConf.load(_spec_path(phase, name)).output_root).rstrip("/"))
        same = [s for r, ss in roots.items() for s in ss if os.path.basename(r) == mine and s.startswith(phase + "/")]
        assert same == [f"{phase}/{name}"], f"{name}: folder name {mine} also used by {same}"


DATA_KEYS = ("data.train_base", "data.train_start", "data.train_end", "data.val_base", "data.val_start",
             "data.val_end", "eval.base", "eval.file_start", "eval.file_end", "data.account_col", "data.order_col",
             "data.target_col", "data.tie_break_col", "artifacts.base", "artifacts.version", "predictors.csv_path",
             "predictors.version")


def _cells(phase, name):
    spec = OmegaConf.load(_spec_path(phase, name))
    return {n: tools.flat_config(tools.spec_effective(phase, name, n))
            for n, _, _ in tools.runner(phase)._expand_runs(spec)[1]}


def test_batch2_specs_use_batch1_files_and_the_strict_history_rule():
    ref = _cells("phase4a", "ft_decisions_h0.yaml")["history-h5"]
    ref_b = _cells("phase4b", "ft_decisions_hier.yaml")["history-h5"]
    for phase, name in ALL_B2 + SEED_SPECS:
        if phase == "base":
            continue
        for run, cell in _cells(phase, name).items():
            want = ref if phase == "phase4a" else ref_b
            for k in DATA_KEYS:
                assert cell.get(k) == want.get(k), f"{name} {run}: {k} is {cell.get(k)}, batch 1 uses {want.get(k)}"
            assert cell["sequence.history_time_order"] == "strict", f"{name} {run}"
            assert cell["training.max_epochs"] == 10 and cell["training.optimizer"] == "adamw"
            assert cell["model.continuous_embedding"] == "linear"


def _without(cell, *keys):
    return {k: v for k, v in cell.items() if k not in keys}


def test_new_batch2_specs_change_one_axis_of_an_existing_spec():
    seed = "training.seed"
    h5_a = _cells("phase4a", "ft_decisions_h0.yaml")["history-h5"]
    h5_b = _cells("phase4b", "ft_decisions_hier.yaml")["history-h5"]
    expect = {
        ("phase4b", "ft_decisions_hier_h0_scored.yaml"): (h5_b, "sequence.history_len", 0),
        ("phase4a", "ft_decisions_gap05_off.yaml"): (h5_a, "sequence.time_delta", False),
        ("phase4a", "ft_decisions_mask_causal.yaml"): (h5_a, "sequence.attention_mask", "causal"),
    }
    for (phase, name), (base, axis, value) in expect.items():
        [cell] = _cells(phase, name).values()
        assert cell[seed] == 42 and cell[axis] == value, name
        assert _without(cell, axis) == _without(base, axis), name
    # The causal cell is exactly ft_decisions.yaml's causal cell.
    assert _cells("phase4a", "ft_decisions_mask_causal.yaml")["mask-causal"] == \
        _cells("phase4a", "ft_decisions.yaml")["mask-causal"]
    # All-position B: the strict-contract base config, history 5 (chunks of up to 6 distinct seconds), seed 42.
    allpos = _cells("phase4b", "ft_decisions_hier_allpos.yaml")
    assert list(allpos) == ["history-h5"]
    cell = allpos["history-h5"]
    assert cell["sequence.predict_every_transaction"] is True and cell["sequence.history_len"] == 5
    assert cell["sequence.history_time_order"] == "strict" and cell["sequence.attention_mask"] == "causal"
    assert cell["sequence.all_position_layout"] == "nonoverlapping_chunks" and cell[seed] == 42
    assert str(OmegaConf.load(_spec_path("phase4b", "ft_decisions_hier_allpos.yaml")).base_config) == \
        "YOUR_PACKAGE/phase4b/configs/sequential_hier_allposition.yaml"
    # Every V1 run of both batches uses seed 42 only.
    for phase, name in [("phase4a" if s != "ft_decisions_hier.yaml" else "phase4b", s) for s in ALL_B1] + ALL_B2:
        if phase != "base":
            assert {c[seed] for c in _cells(phase, name).values()} == {42}, name


def test_seed_specs_change_only_the_seed():
    """The seeds 43 and 44 files stay in the tree for later; each changes only the seed of a V1 cell."""
    seed = "training.seed"
    base = {"ft_decisions_hier_seeds.yaml": _cells("phase4b", "ft_decisions_hier.yaml")["history-h5"],
            "ft_decisions_h10_seeds.yaml": _cells("phase4a", H10_SPEC)["history-h10"],
            "ft_decisions_h10_seeds_off.yaml": _cells("phase4a", "ft_decisions_timedelta.yaml")["time_delta-False"]}
    assert {n for _, n in SEED_SPECS} == set(base) | {"ft_decisions_h0_seeds.yaml"}
    for phase, name in SEED_SPECS:
        if name not in base:
            continue  # ft_decisions_h0_seeds.yaml: batch 1's earlier seeds file, unchanged
        want = base[name]
        cells = _cells(phase, name)
        assert sorted(c[seed] for c in cells.values()) == [43, 44], name
        for cell in cells.values():
            assert _without(cell, seed) == _without(want, seed), name
        assert "Not run in V1" in _spec_path(phase, name).read_text()


# ---------------------------------------------------------------- RUN-05 (R-033): comparator validation
def h10_attempt(tmp, history=10, status="ok", source_sha=None, files=None, spec_axes=None):
    """A synthetic ft_decisions_flat_h10.yaml attempt: the resolved h10 config, a results row, a manifest with the
    runner's source provenance (this checkout's by default) and scoring files."""
    runner = tools.runner("phase4a")
    prov = runner._source_provenance()
    source_sha = source_sha or prov["source_sha256"]
    files = prov["files"] if files is None else files
    spec = OmegaConf.load(ROOT / "YOUR_PACKAGE/phase4a/configs" / H10_SPEC)
    att = tmp / "root" / f"20261011T000000Z-{uuid.uuid4().hex[:6]}"
    run_name = "history-h10"
    run = att / run_name
    run.mkdir(parents=True)
    axes = spec_axes or OmegaConf.to_container(spec.axes)
    att_spec = {"base_config": str(spec.base_config), "output_root": str(tmp / "root"), "run_score": True,
                "common_overrides": list(spec.common_overrides), "axes": axes}
    OmegaConf.save(OmegaConf.create(att_spec), att / "ablation_spec.yaml")
    base = OmegaConf.load(ROOT / str(spec.base_config))
    overrides = [str(o) for o in spec.common_overrides] + list(axes["history"]["h10"])
    overrides = [f"sequence.history_len={history}" if o.startswith("sequence.history_len=") else o for o in overrides]
    eff = OmegaConf.merge(base, OmegaConf.from_dotlist(overrides + [f"output.checkpoint_dir={run}", "experiment.run_name=t"]))
    OmegaConf.save(OmegaConf.create(OmegaConf.to_container(eff, resolve=True)), run / "resolved_train.yaml")
    shutil.copyfile(run / "resolved_train.yaml", run / "resolved_score.yaml")
    (run / "best.ckpt").write_bytes(b"CKPT")
    sha = hashlib.sha256(b"CKPT").hexdigest()
    train_sha = hashlib.sha256((run / "resolved_train.yaml").read_bytes()).hexdigest()
    sm = {"schema_version": 1, "predictions_path": "bucket/p.parquet", "checkpoint_path": str(run / "best.ckpt"),
          "checkpoint_sha256": sha, "n_predictions": 1000, "n_positives": 10, "average_precision": 0.1, "auroc": 0.9}
    (run / "score_metrics.json").write_text(json.dumps(sm))
    row = {c: "" for c in contracts.RESULT_COLS}
    row.pop("mask")
    row["history"] = "h10"
    row.update({"run_name": run_name, "train_rc": 0, "best_valid_ap": 0.2, "best_valid_auroc": 0.9, "attempt": att.name,
                "run_dir": str(run), "status": status, "checkpoint_epoch": 3, "checkpoint_step": 40, "checkpoint_sha256": sha,
                "score_rc": 0, "resolved_train_sha256": train_sha, "source_sha256": source_sha,
                "manifest_path": str(run / "run_manifest.json"), "eval_ap": 0.1, "eval_auroc": 0.9, "n_predictions": 1000,
                "n_positives": 10, "predictions_path": "bucket/p.parquet"})
    manifest = {"attempt": att.name, "run_name": run_name, "resolved_train_sha256": train_sha,
                "resolved_score_sha256": hashlib.sha256((run / "resolved_score.yaml").read_bytes()).hexdigest(),
                "source_before": {"git_revision": None, "source_sha256": source_sha, "files": files},
                "started_utc": "2026-10-11T00:00:00Z", "finished_utc": "2026-10-11T04:54:00Z", "result": row}
    (run / "run_manifest.json").write_text(json.dumps(manifest))
    with open(att / "results.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(row))
        w.writeheader()
        w.writerow(row)
    return att


def ledger_with(tmp, att, cohort="ok:20261011T000000Z"):
    """A real v4 ledger holding the attempt's rows as the collector produces them, with the cohort check recorded."""
    rows = collector.collect_attempt(str(att))
    for r in rows:
        if r["status"] == "ok":
            r["cohort_check"] = cohort
    path = tmp / "run_log.csv"
    collector.append_ledger(str(path), rows, "20261011T050000Z")
    return path


def check(att, ledger, tmp):
    return tools.check_comparator(str(att), "phase4a", H10_SPEC, str(ledger), str(tmp / "files.csv"))


def test_comparator_accepts_a_matching_ok_attempt(tmp_path):
    att = h10_attempt(tmp_path)
    ledger = ledger_with(tmp_path, att)
    ok, failed, facts = check(att, ledger, tmp_path)
    assert ok and failed == [], failed
    assert facts["comparator_preflight"] == "20261011T000000Z" and facts["runs"] == "history-h10"
    assert facts["train_files"] == "1-10" and facts["source_files_compared"] > 100
    with open(tmp_path / "files.csv") as f:
        rows = list(csv.DictReader(f))
    assert rows and all(r["run_matches_checkout"] == "yes" and r["checkout_matches_release_lf"] == "yes" for r in rows)
    assert all(r["path"].endswith(".py") for r in rows) and len({r["path"] for r in rows}) == len(rows)
    rec = tmp_path / "SHARED_COMPARATOR.txt"
    p = subprocess.run([sys.executable, str(HERE / "batch_tools.py"), "comparator", "--attempt", str(att), "--phase",
                        "phase4a", "--spec", H10_SPEC, "--ledger", str(ledger), "--record", str(rec), "--origin", "own",
                        "--batch-preflight", "pf_batch"], capture_output=True, text=True)
    assert p.returncode == 0 and "COMPARATOR OK" in p.stdout
    text = rec.read_text()
    assert f"A_H10_COMPARATOR={os.path.realpath(att)}" in text and "valid=yes" in text and "checks_failed=none" in text
    assert "comparator_preflight=20261011T000000Z" in text and "preflight=pf_batch" in text and "origin=own" in text
    assert "config_identity_sha256=" in text and "release_manifest_sha256=" in text


def test_comparator_rejects_missing_folder_and_non_ok_status(tmp_path):
    ok, failed, _ = check(tmp_path / "nowhere", tmp_path / "run_log.csv", tmp_path)
    assert not ok and "does not exist" in failed[0]
    att = h10_attempt(tmp_path, status="train_failed")
    ledger = ledger_with(tmp_path, att)
    ok, failed, _ = check(att, ledger, tmp_path)
    assert not ok and any("status is train_failed, not ok" in t for t in failed)
    att2 = h10_attempt(tmp_path / "other")
    ok, failed, _ = check(att2, ledger, tmp_path)  # ok attempt, but no row in this ledger
    assert not ok and any("has no row" in t for t in failed)


def test_comparator_rejects_a_different_source(tmp_path):
    att = h10_attempt(tmp_path, source_sha="0" * 64)
    ok, failed, facts = check(att, ledger_with(tmp_path, att), tmp_path)
    assert not ok and any("source digest differs from this checkout" in t for t in failed)
    files = dict(tools.runner("phase4a")._source_provenance()["files"])
    changed = next(k for k in files if k.startswith("YOUR_PACKAGE/phase4a/") and k.endswith(".py"))
    files[changed] = "f" * 64
    files["YOUR_PACKAGE/not_in_release.py"] = "e" * 64
    att = h10_attempt(tmp_path / "b", files=files)
    ok, failed, facts = check(att, ledger_with(tmp_path / "b", att), tmp_path / "b")
    assert not ok and any("1 .py file(s) differ between the run and this checkout, 1 recorded by the run are not in this "
                          "checkout" in t for t in failed)
    with open(tmp_path / "b" / "files.csv") as f:
        by_path = {r["path"]: r["run_matches_checkout"] for r in csv.DictReader(f)}
    assert by_path[changed] == "no" and by_path["YOUR_PACKAGE/not_in_release.py"] == "not_in_checkout"


def test_comparator_rejects_a_different_configuration_or_spec(tmp_path):
    att = h10_attempt(tmp_path, history=15)
    ok, failed, _ = check(att, ledger_with(tmp_path, att), tmp_path)
    assert not ok and any("differs from this checkout's ft_decisions_flat_h10.yaml in history_len" in t for t in failed)
    other = h10_attempt(tmp_path / "s", spec_axes={"history": {"h10": ["sequence.history_len=10"], "h5": ["sequence.history_len=5"]}})
    ok, failed, _ = check(other, tmp_path / "s" / "run_log.csv", tmp_path / "s")
    assert not ok and "is not a ft_decisions_flat_h10.yaml attempt" in failed[0]


def test_comparator_rejects_a_setting_outside_the_ledger_columns(tmp_path):
    """M1: a run whose resolved configuration differs from the spec only in a key the ledger does not record (here
    the equal-time history rule, RUN-02) is not accepted as the comparator."""
    h10 = list(OmegaConf.load(ROOT / "YOUR_PACKAGE/phase4a/configs" / H10_SPEC).axes.history.h10)
    att = h10_attempt(tmp_path, spec_axes={"history": {"h10": h10 + ["sequence.history_time_order=tiebreak"]}})
    ok, failed, _ = check(att, ledger_with(tmp_path, att), tmp_path)
    assert not ok and any("differs from this checkout's ft_decisions_flat_h10.yaml in sequence.history_time_order" in t
                          for t in failed), failed


def test_comparator_checks_against_the_spec_file_it_is_given(tmp_path):
    """B1: the sandbox trains on a reduced copy of the spec; --spec-file checks the attempt against that copy."""
    reduced = ["sequence.history_len=10", "training.batch_size=32", "training.accumulate_grad_batches=1"]
    att = h10_attempt(tmp_path, spec_axes={"history": {"h10": reduced}})
    ledger = ledger_with(tmp_path, att)
    ok, failed, _ = check(att, ledger, tmp_path)
    assert not ok and any("in batch_x_accum" in t for t in failed)
    copy = OmegaConf.load(ROOT / "YOUR_PACKAGE/phase4a/configs" / H10_SPEC)
    copy.axes = {"history": {"h10": reduced}}
    spec_file = tmp_path / f"phase4a_{H10_SPEC}"
    OmegaConf.save(copy, spec_file)
    ok, failed, _ = tools.check_comparator(str(att), "phase4a", H10_SPEC, str(ledger), None, str(spec_file))
    assert ok and failed == [], failed
    p = subprocess.run([sys.executable, str(HERE / "batch_tools.py"), "comparator", "--attempt", str(att), "--phase",
                        "phase4a", "--spec", H10_SPEC, "--ledger", str(ledger), "--spec-file", str(spec_file)],
                       capture_output=True, text=True)
    assert p.returncode == 0 and "COMPARATOR OK" in p.stdout, p.stdout + p.stderr


def test_comparator_requires_the_cohort_check(tmp_path):
    att = h10_attempt(tmp_path)
    ok, failed, _ = check(att, ledger_with(tmp_path, att, cohort="not_requested"), tmp_path)
    assert not ok and any("not checked against a pre-flight cohort" in t for t in failed)


# ---------------------------------------------------------------- run_step.py: STEP.txt, host RSS, interpreter, smoke lines
FAKE_RUNNER = """
import os, shutil, sys, time
spec, staged, root = sys.argv[sys.argv.index("--config") + 1], sys.argv[-2], sys.argv[-1]
time.sleep(float(os.environ.get("FAKE_RUNNER_SLEEP", "2.5")))
shutil.copytree(staged, os.path.join(root, os.path.basename(staged)))
sys.exit(0)
"""


def run_step_with_fake_runner(tmp_path, monkeypatch, spec_name, staged, extra_argv=()):
    """run_step.py's main() against a stand-in runner that copies a staged attempt into the output root."""
    rs = load(f"fr1_run_step_{uuid.uuid4().hex[:6]}", HERE / "run_step.py")
    fake_root = tmp_path / "repo"
    (fake_root / "YOUR_PACKAGE/phase4a/configs").mkdir(parents=True)
    out_root = tmp_path / "out_root"
    OmegaConf.save(OmegaConf.create({"base_config": "YOUR_PACKAGE/phase4a/configs/sequential.yaml", "output_root": str(out_root),
                                     "run_score": True, "axes": {}}), fake_root / "YOUR_PACKAGE/phase4a/configs" / spec_name)
    runner = tmp_path / "fake_runner.py"
    runner.write_text(FAKE_RUNNER)
    monkeypatch.setattr(rs, "ROOT", str(fake_root))
    monkeypatch.setattr(rs, "runner_path", lambda phase: str(runner))
    monkeypatch.setattr(rs.shutil, "which", lambda name: None)  # no nvidia-smi in the test
    real_popen = rs.subprocess.Popen

    def popen(cmd, **kw):  # hand the staged attempt and the output root to the stand-in runner only
        extra = [str(staged), str(out_root)] if len(cmd) > 1 and cmd[1] == str(runner) else []
        return real_popen(list(cmd) + extra, **kw)
    monkeypatch.setattr(rs.subprocess, "Popen", popen)
    batch_dir = tmp_path / "batch"
    monkeypatch.setattr(sys, "argv", ["run_step.py", "--phase", "phase4a", "--spec", spec_name, "--batch-dir",
                                      str(batch_dir), "--sample-seconds", "1", "--ledger", str(tmp_path / "run_log.csv"),
                                      *extra_argv])
    monkeypatch.setenv("RUNBOOK_BANK_OVERRIDES", "1")
    monkeypatch.delenv("RUNBOOK_SANDBOX", raising=False)
    with pytest.raises(SystemExit) as e:
        rs.main()
    [ret] = list((fake_root / "runs/returns").iterdir())
    return e.value.code, ret, batch_dir, out_root


def test_run_step_records_interpreter_host_rss_and_attempt_in_the_step_return(tmp_path, monkeypatch):
    staged = contracts.make_attempt(tmp_path / "stage")
    rc, ret, batch_dir, out_root = run_step_with_fake_runner(tmp_path, monkeypatch, "ft_decisions_h0.yaml", staged)
    assert rc == 0
    text = (ret / "RETURN.txt").read_text()
    assert "ACCEPTED: every run ok" in text and f"step interpreter: {sys.executable}" in text
    assert "step host peak RSS: " in text and " MiB summed over the runner process tree (shared pages counted once " \
        "per process, so an upper bound); " in text and "sample(s) every 1 s" in text
    assert "step GPU peak: no samples" in text and f"step attempt: {out_root / staged.name}" in text
    step = (ret / "STEP.txt").read_text()
    assert f"attempt_dir: {out_root / staged.name}" in step and "finished_utc: " in step and "host_peak_rss_mib: " in step
    mirrored = batch_dir / "steps" / ret.name / "STEP.txt"
    assert mirrored.read_text() == step
    assert (tmp_path / "run_log.csv").is_file() and "ledger run_log.csv: +1 appended" in text  # the ledger line is in the step's return
    host_csv = out_root / staged.name / "host_rss_sweep.csv"
    rows = list(csv.DictReader(open(host_csv)))
    assert rows[0]["timestamp_utc"] and len(rows) >= 2 and any(float(r["rss_mib_process_tree"]) > 0 for r in rows)
    gpu_dir = Path(str(ret).replace("/returns/", "/gpu/"))
    assert gpu_dir.with_name(ret.name + ".host_rss.csv").is_file()


def test_run_step_smoke_spec_writes_per_epoch_metrics_into_the_return(tmp_path, monkeypatch):
    staged = contracts.make_attempt(tmp_path / "stage")
    (staged / "mask-bidir" / "training_metrics.csv").write_text(
        "epoch,step,train_loss,valid_ap,valid_auroc\n0,10,0.70,0.10,0.60\n1,20,0.50,0.15,0.70\n")
    rc, ret, _, _ = run_step_with_fake_runner(tmp_path, monkeypatch, "ft_smoke_a.yaml", staged)
    text = (ret / "RETURN.txt").read_text()
    assert "smoke mask-bidir: 2 epoch row(s); columns epoch step train_loss valid_ap valid_auroc" in text
    assert "smoke mask-bidir epoch 0 step 10 train_loss=0.70 valid_ap=0.10 valid_auroc=0.60" in text
    assert "smoke mask-bidir epoch 1 step 20 train_loss=0.50 valid_ap=0.15 valid_auroc=0.70" in text
    assert ret.name.startswith("ft_smoke_a_")


def test_smoke_checks_reads_the_memory_files_run_step_leaves(tmp_path, monkeypatch):
    """Integration (smoke row): smoke_checks.py reads host_rss_sweep.csv and gpu_sweep.csv from the attempt folder that
    run_step.py fills, with the same column and the same nvidia-smi line format, so the smoke return's peaks are the
    step's own peaks, never UNKNOWN for a file name or column mismatch."""
    sc = load(f"fr1_smoke_checks_{uuid.uuid4().hex[:6]}", HERE / "smoke_checks.py")
    rs = load(f"fr1_run_step_gpu_{uuid.uuid4().hex[:6]}", HERE / "run_step.py")
    staged = contracts.make_attempt(tmp_path / "stage")
    _, _, _, out_root = run_step_with_fake_runner(tmp_path, monkeypatch, "ft_smoke_a.yaml", staged)
    attempt = out_root / staged.name
    rows = list(csv.DictReader(open(attempt / "host_rss_sweep.csv")))
    peak, n, _ = sc.host_peak(str(attempt))
    assert n >= 2 and peak == max(float(r["rss_mib_process_tree"]) for r in rows if r["rss_mib_process_tree"])
    gpu = tmp_path / "gpu.csv"
    gpu.write_text("timestamp, memory.used [MiB], utilization.gpu [%]\n"
                   "2026/10/11 00:00:00.000, 9000 MiB, 90 %\n2026/10/11 00:00:00.000, 12000 MiB, 95 %\n")
    shutil.copyfile(gpu, attempt / "gpu_sweep.csv")  # the copy run_step.py makes when nvidia-smi sampled
    assert rs.gpu_peak_mib(str(gpu)) == 12000 and sc.gpu_peak(str(attempt))[0] == 12000.0


def test_run_step_non_smoke_spec_has_no_epoch_lines(tmp_path, monkeypatch):
    staged = contracts.make_attempt(tmp_path / "stage")
    (staged / "mask-bidir" / "training_metrics.csv").write_text("epoch,step,train_loss\n0,10,0.7\n")
    _, ret, _, _ = run_step_with_fake_runner(tmp_path, monkeypatch, "ft_decisions_h0.yaml", staged)
    assert "smoke " not in (ret / "RETURN.txt").read_text()


def test_process_tree_rss_sums_children():
    """The child starts a grandchild; the reading must count both. The test waits (up to 60 s) for the grandchild to
    appear instead of a fixed sleep, so a loaded machine (the pre-flight's own test step) cannot make it fail."""
    import os
    import signal
    import time
    rs = load("fr1_run_step_rss", HERE / "run_step.py")
    child = subprocess.Popen([sys.executable, "-c", "import subprocess, sys, time; "
                              "p = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(120)']); "
                              "time.sleep(120)"], start_new_session=True)
    try:
        deadline = time.monotonic() + 60.0
        reading = rs.process_tree_rss_kib(child.pid)
        while (reading is None or reading[1] < 2) and time.monotonic() < deadline:
            time.sleep(0.2)
            reading = rs.process_tree_rss_kib(child.pid)
        assert reading is not None
        total, count = reading
        assert count >= 2 and total > 0
    finally:
        try:
            os.killpg(child.pid, signal.SIGKILL)  # the child and the grandchild
        except OSError:
            child.kill()
        child.wait()
    assert rs.process_tree_rss_kib(2 ** 22 - 1) is None


# ---------------------------------------------------------------- stop and resume (R-063)
def test_batch1_resume_skips_finished_steps_and_records_an_interrupted_attempt(tmp_path):
    env = batch_env(tmp_path, BATCH1_SKIP="ft_decisions_hier.yaml ft_decisions_flat_h10.yaml ft_decisions_timedelta.yaml")
    p = run_batch("batch1.sh", env)
    assert p.stdout.count("MARK step ") == 1
    out = return_folder(tmp_path)
    # An interrupted start of step 2: STEP.txt names a real (half-written) attempt folder and never finished.
    att = contracts.make_attempt(tmp_path / "half", rows="none")  # header only: the runner was killed mid-way
    folder = out / "steps" / "ft_decisions_hier_20261011T000000Z_1"
    folder.mkdir()
    (folder / "STEP.txt").write_text(f"spec: phase4b/ft_decisions_hier.yaml\ninterpreter: x\nstarted_utc: t\nattempt_dir: {att}\n")
    (tmp_path / "sb" / "runs" / "returns" / folder.name).mkdir(parents=True)  # run_step.py makes it before training
    for spec in ALL_B1:  # the stand-in steps' attempt folders
        (tmp_path / "sb" / f"att_{spec}").mkdir()
    env2 = batch_env(tmp_path, BATCH1_RESUME=str(out))
    p = run_batch("batch1.sh", env2)
    assert p.stdout.count("MARK step ") == 2, p.stdout  # hier and flat_h10 run; h0 is skipped
    # The combined return keeps the h0 attempt finished before the resume: 2 new + 1 earlier.
    assert "| 3 run(s) |" in (out / "RETURN.txt").read_text()
    assert "skipped ft_decisions_h0.yaml: finished and ACCEPTED earlier" in p.stdout
    assert "an earlier start of this step was interrupted" in p.stdout
    assert "interrupted_collected: " in (folder / "STEP.txt").read_text()
    assert (folder / "interrupted_collect" / "RETURN.txt").is_file()
    copied = out / "attempts" / att.name  # L2-SCRIPT-04: the interrupted attempt's files are in the return too
    assert copied.is_dir() and {f.name for f in copied.rglob("*") if f.is_file()} >= {"ablation_spec.yaml"}
    assert not list(copied.rglob("*.ckpt")) and not list(copied.rglob("*.parquet"))
    ledger = tmp_path / "sb" / "runs" / "run_log.csv"
    rows = collector.current_rows(str(ledger))
    assert rows[(os.path.realpath(att), "mask-bidir")]["status"] == "not_run"  # recorded as unfinished, never reused
    with open(out / "run_log_batch1.csv") as f:
        batch_rows = list(csv.DictReader(f))
    assert any(os.path.realpath(r["attempt_dir"]) == os.path.realpath(att) for r in batch_rows)
    status = (out / "BATCH_STATUS.txt").read_text()
    assert status.count("batch 1 started") == 2 and "resume: skipped ft_decisions_h0.yaml" in status
    # A third resume: every step but the time-gap control is recorded as finished; the finished A-H10 has no valid
    # comparator record (valid=no), so its own attempt is checked again (origin own), fails, and nothing is trained.
    p = run_batch("batch1.sh", env2)
    assert p.returncode == 1 and p.stdout.count("MARK step ") == 0
    assert f"COMPARATOR REFUSED: the A-H10 result recorded in {out} no longer passes the check" in p.stdout
    assert "origin=own" in (out / "SHARED_COMPARATOR.txt").read_text()
    assert "| 3 run(s) |" in (out / "RETURN.txt").read_text()  # the combined return still lists every finished step


def test_batch1_resume_checks_a_finished_a_h10_that_has_no_comparator_record(tmp_path):
    """m3: A-H10 finished ACCEPTED but the batch stopped before its comparator check; a resume checks that attempt
    and, when it passes, runs the time-gap control instead of holding it for good."""
    att = h10_attempt(tmp_path)
    (tmp_path / "sb" / "runs").mkdir(parents=True)
    ledger_with(tmp_path / "sb" / "runs", att)
    (tmp_path / "sb" / "specs").mkdir()
    shutil.copyfile(ROOT / "YOUR_PACKAGE/phase4a/configs" / H10_SPEC, tmp_path / "sb" / "specs" / f"phase4a_{H10_SPEC}")
    out = return_folder(tmp_path)
    (out / "steps").mkdir(parents=True)
    (out / "BATCH_STATUS.txt").write_text("started\n")
    for spec in ALL_B1[:-1]:
        step = out / "steps" / f"{spec[:-5]}_20261011T000000Z"
        step.mkdir()
        a = att if spec == H10_SPEC else tmp_path / "sb" / f"att_{spec}"
        (step / "STEP.txt").write_text(f"spec: phase4a/{spec}\nattempt_dir: {a}\nfinished_utc: t\n")
        (step / "RETURN.txt").write_text("ACCEPTED: every run ok\n")
    p = run_batch("batch1.sh", batch_env(tmp_path, BATCH1_RESUME=str(out)))
    assert "COMPARATOR OK" in p.stdout and "COMPARATOR REFUSED" not in p.stdout, p.stdout
    assert p.stdout.count("MARK step ") == 1 and "MARK step ft_decisions_timedelta.yaml" in p.stdout
    rec = (out / "SHARED_COMPARATOR.txt").read_text()
    assert "valid=yes" in rec and "origin=own" in rec and f"A_H10_COMPARATOR={os.path.realpath(att)}" in rec


def test_resume_refuses_a_folder_that_is_not_a_batch_return(tmp_path):
    p = run_batch("batch1.sh", batch_env(tmp_path, BATCH1_RESUME=str(tmp_path / "x")))
    assert p.returncode == 1 and "RESUME REFUSED" in p.stdout and "MARK" not in p.stdout


# ---------------------------------------------------------------- batch 2 stop and resume (B5, as batch 1's R-063)
def test_batch2_resume_skips_finished_steps_and_the_post_hoc_scoring(tmp_path):
    b1_ledger(tmp_path / "sb" / "runs" / "run_log.csv")
    env = batch_env(tmp_path, BATCH2_SKIP=" ".join(spec for _, spec in ALL_B2[3:]))
    p = run_batch("batch2.sh", env)
    assert p.stdout.count("MARK step ") == 3 and "MARK post-hoc scoring" in p.stdout
    out = b2_folder(tmp_path)
    (out / "POST_SCORE.txt").write_text("scored\nno failures\n")  # the stand-in scorer writes no return copy
    # An interrupted start of step 2.4: STEP.txt names a real (half-written) attempt folder and never finished.
    att = contracts.make_attempt(tmp_path / "half", rows="none")
    folder = out / "steps" / "ft_decisions_gap05_off_20261012T000000Z_1"
    folder.mkdir()
    (folder / "STEP.txt").write_text(f"spec: phase4a/ft_decisions_gap05_off.yaml\ninterpreter: x\nstarted_utc: t\n"
                                     f"attempt_dir: {att}\n")
    (tmp_path / "sb" / "runs" / "returns" / folder.name).mkdir(parents=True)  # run_step.py makes it before training
    for _, spec in ALL_B2:
        (tmp_path / "sb" / f"att_{spec}").mkdir(exist_ok=True)
    p = run_batch("batch2.sh", batch_env(tmp_path, BATCH2_RESUME=str(out)))
    marks = [line.split("MARK step ", 1)[1] for line in p.stdout.splitlines() if line.startswith("MARK step ")]
    assert marks == [spec for _, spec in ALL_B2[3:]], p.stdout
    assert "MARK post-hoc scoring" not in p.stdout and "skipped the post-hoc scoring (step 2.0)" in p.stdout
    for _, spec in ALL_B2[:3]:
        assert f"skipped {spec}: finished and ACCEPTED earlier" in p.stdout
    assert "an earlier start of this step was interrupted" in p.stdout
    assert "interrupted_collected: " in (folder / "STEP.txt").read_text()
    copied = out / "attempts" / att.name  # L2-SCRIPT-04: the interrupted attempt's files are in the return too
    assert copied.is_dir() and "ablation_spec.yaml" in {f.name for f in copied.rglob("*") if f.is_file()}
    status = (out / "BATCH_STATUS.txt").read_text()
    assert status.count("batch 2 started") == 2 and "resume: skipped the post-hoc scoring" in status


def test_batch2_resume_scores_into_a_new_subfolder_after_a_half_written_post_hoc_scoring(tmp_path):
    b1_ledger(tmp_path / "sb" / "runs" / "run_log.csv")
    out = b2_folder(tmp_path)
    (out / "steps").mkdir(parents=True)
    (out / "BATCH_STATUS.txt").write_text("started\n")
    (out / "post_score_results.csv").write_text("attempt\n")  # stopped before POST_SCORE.txt was written
    p = run_batch("batch2.sh", batch_env(tmp_path, BATCH2_RESUME=str(out)))
    assert "MARK post-hoc scoring" in p.stdout and f"(return copy: {out}/post_score_resume_" in p.stdout


def test_batch2_resume_refuses_a_folder_that_is_not_a_batch_return(tmp_path):
    b1_ledger(tmp_path / "sb" / "runs" / "run_log.csv")
    p = run_batch("batch2.sh", batch_env(tmp_path, BATCH2_RESUME=str(tmp_path / "x")))
    assert p.returncode == 1 and "RESUME REFUSED" in p.stdout and "MARK" not in p.stdout


# ---------------------------------------------------------------- every file is sent (owner's twenty-sixth message, OQ-24)
def test_batch2_return_holds_every_step_file_but_checkpoints_and_predictions(tmp_path):
    b1_ledger(tmp_path / "sb" / "runs" / "run_log.csv")
    att = tmp_path / "sb" / "ablations" / "arch_a_flat" / "time_delta_off_h5" / "20261012T000000Z-ab"
    (att / "time_delta-False").mkdir(parents=True)
    for name in ("results.csv", "ablation_spec.yaml", "time_delta-False/training_metrics.csv", "time_delta-False/run_summary.txt",
                 "time_delta-False/resolved_train.yaml", "time_delta-False/best.ckpt", "time_delta-False/predictions.parquet"):
        (att / name).write_text("x\n")
    env = batch_env(tmp_path, FAKE_ATTEMPT_DIR=str(att),
                    BATCH2_SKIP=" ".join(spec for _, spec in ALL_B2 if spec != "ft_decisions_gap05_off.yaml"))
    p = run_batch("batch2.sh", env)
    assert p.stdout.count("MARK step ") == 1
    out = b2_folder(tmp_path)
    [step] = list((out / "steps").iterdir())
    assert {"STEP.txt", "RETURN.txt", f"{step.name}.runner.log"} <= {f.name for f in step.iterdir()}
    copied = out / "attempts" / att.name
    got = {str(f.relative_to(copied)) for f in copied.rglob("*") if f.is_file()}
    assert got == {"results.csv", "ablation_spec.yaml", "time_delta-False/training_metrics.csv", "time_delta-False/run_summary.txt",
                   "time_delta-False/resolved_train.yaml"}
    assert not list(out.rglob("*.ckpt")) and not list(out.rglob("*.parquet"))
    [pf] = [d for d in out.iterdir() if d.name.startswith("preflight_")]
    assert {"errors.txt", "checks.txt", "SUMMARY.txt", "data_contract.json"} <= {f.name for f in pf.iterdir()}


def test_batch2_resume_scores_again_after_a_failed_post_hoc_scoring(tmp_path):
    """L2-SCRIPT-03: a POST_SCORE.txt that does not end with "no failures" is not a finished step 2.0; a resume runs
    the scoring again (into a new subfolder) and the batch ends with exit 1 when it fails again."""
    b1_ledger(tmp_path / "sb" / "runs" / "run_log.csv")
    out = b2_folder(tmp_path)
    (out / "steps").mkdir(parents=True)
    (out / "BATCH_STATUS.txt").write_text("started\n")
    (out / "POST_SCORE.txt").write_text("POST-HOC EVAL SCORING\n1 run(s) failed or produced invalid output\n")
    env = batch_env(tmp_path, BATCH2_RESUME=str(out), FAKE_SCORE_RC="1",
                    BATCH2_SKIP=" ".join(spec for _, spec in ALL_B2))
    p = run_batch("batch2.sh", env)
    assert "MARK post-hoc scoring" in p.stdout and "skipped the post-hoc scoring" not in p.stdout
    assert f"(return copy: {out}/post_score_resume_" in p.stdout and p.returncode == 1
    # A later resume finds the clean POST_SCORE.txt in the resume subfolder and skips step 2.0.
    [sub] = [d for d in out.iterdir() if d.name.startswith("post_score_resume_")] or [out / "post_score_resume_x"]
    sub.mkdir(exist_ok=True)
    (sub / "POST_SCORE.txt").write_text("POST-HOC EVAL SCORING\nno failures\n")
    p = run_batch("batch2.sh", env)
    assert "MARK post-hoc scoring" not in p.stdout and f"skipped the post-hoc scoring (step 2.0): finished without " \
        f"failures earlier in this batch ({sub}/POST_SCORE.txt)" in p.stdout


def test_batch2_runs_the_quick_preflight_and_batch1_the_full_one():
    """Owner, OWNER_QA forty-first and forty-second messages: the full test suite runs once, in batch 1's pre-flight;
    batch 2 of the same package folder runs the quick pre-flight, hard-coded (the owner sets no variables)."""
    line = {s: next(l for l in (HERE / s).read_text().splitlines() if "preflight_pod.py" in l and "--out-root" in l)
            for s in ("batch1.sh", "batch2.sh")}
    assert "--skip-tests" in line["batch2.sh"] and "--skip-tests" not in line["batch1.sh"]
