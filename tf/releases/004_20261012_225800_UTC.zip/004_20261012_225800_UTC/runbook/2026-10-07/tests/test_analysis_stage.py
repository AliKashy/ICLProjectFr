# reviewer, 2026-10-12. V1 stage 5 (analysis.sh, analysis_runs.py, v1_contrasts.csv); design
# bridge/plans/review/2026-10-12-v1-design/DESIGN_V1_AFTER_RUN001.md on main, section 3 and section 4 rows B12 and B13.
# Synthetic only: ledgers and attempt folders are written here; the end-to-end test reads the shared V1 fake-data
# fixture (branch reviewer/v1-fake-data-2026-10-12) through a synthetic ledger.
#     PYTHONPATH=src:. python -m pytest -q -p no:cacheprovider runbook/2026-10-07/tests/test_analysis_stage.py
import csv
import importlib.util
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pandas as pd
import pytest
from omegaconf import OmegaConf

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def load(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return m


ar = load("cl_analysis_runs", HERE / "analysis_runs.py")
cr = load("cl_collect_returns_t", HERE / "collect_returns.py")
RUNS = {r[0]: r for r in ar.V1_RUNS}
CONTRASTS = HERE / "v1_contrasts.csv"
VALIDATION_ONLY = ("A-H00", "A-H05", "A-GAP10-OFF")  # batch 1's validation-only runs, scored by batch 2 step 2.0
FIXTURE_REF = "origin/reviewer/v1-fake-data-2026-10-12"
CK = "c" * 64


def rows_of(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


# -- a synthetic ledger and its attempt folders ------------------------------------------------------------------
def attempt(root, run, name="20261013T000000Z-aaaa", status="ok", runner=None, post=(), finished="2026-10-13T01:00",
            revision=1):
    """One ledger row (and its attempt folder) for a V1 run. post: (predictions path, status, checkpoint, override)
    per post-score folder, oldest first."""
    _, output_root, run_name, _ = RUNS[run]
    att = Path(root) / output_root / name
    for i, p in enumerate(post):
        path, pstatus, pck, override = (list(p) + [None] * 4)[:4]
        folder = att / run_name / "post_score" / f"20261014T00000{i}Z-{i:032x}"
        folder.mkdir(parents=True)
        man = {"status": pstatus or "ok", "checkpoint_sha256": pck or CK, "eval_range_override": override,
               "metrics": {"predictions_path": str(path)}}
        (folder / "post_score_manifest.json").write_text(json.dumps(man))
    row = {c: "" for c in cr.LEDGER_COLS}
    row.update(ledger_schema=cr.LEDGER_SCHEMA, attempt_dir=str(att), attempt=name, run_name=run_name, status=status,
               seed="42", valid_ap="0.1", checkpoint_sha256=CK, finished_utc=finished, predictions_path=runner or "",
               revision=str(revision), transition="new")
    return row


def write_ledger(path, rows):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(cr.LEDGER_COLS)
        w.writerows([r[c] for c in cr.LEDGER_COLS] for r in rows)
    return str(path)


def full_ledger(tmp, skip=(), override=None):
    """Every V1 run ok: the runner's predictions (S3 bucket/key, as the scorers record them), or for the
    validation-only runs a post-hoc evaluation scoring."""
    rows = []
    for run, *_ in ar.V1_RUNS:
        if run in skip:
            continue
        if override and run in override:
            rows.append(override[run])
            continue
        post = [(f"bucket/preds/{run}_post.parquet",)] if run in VALIDATION_ONLY else []
        runner = None if run in VALIDATION_ONLY else f"bucket/preds/{run}.parquet"
        rows.append(attempt(Path(tmp) / "pod", run, runner=runner, post=post))
    return write_ledger(Path(tmp) / "runs" / "run_log.csv", rows)


def build(tmp, ledger):
    runs, _, args = ar.build(ledger, str(CONTRASTS), str(tmp / "out"))
    return runs, rows_of(tmp / "out" / "run_table.csv"), args, (tmp / "out" / "RUNS.txt").read_text()


# -- the contrasts file --------------------------------------------------------------------------------------------
def test_contrasts_file_holds_the_design_contrasts_and_every_v1_run():
    rows = rows_of(CONTRASTS)
    by = {r["name"]: r for r in rows}
    with open(CONTRASTS, newline="") as f:
        assert all(len(r) == 6 for r in csv.reader(f))  # no stray comma in a description
    assert len(by) == len(rows)
    pairs = {n: (r["side_a_run"], r["side_b_run"], r["kind"]) for n, r in by.items()}
    # The five primary contrasts of section 3 (contrast 3: the time gap at h5 and h10, plus their difference).
    assert pairs["H05-VS-H00"] == ("A-H05", "A-H00", "contrast")
    assert pairs["H10-VS-H05"] == ("A-H10", "A-H05", "contrast")
    assert pairs["GAP-H05"] == ("A-H05", "A-GAP05-OFF", "contrast")
    assert pairs["GAP-H10"] == ("A-H10", "A-GAP10-OFF", "contrast")
    assert pairs["GAP-CROSSING"] == ("GAP-H10", "GAP-H05", "difference")
    assert pairs["H05-VS-REF"] == ("A-H05", "REF-SINGLE", "contrast")
    assert pairs["B-VS-A-H05"] == ("B-H05", "A-H05", "contrast")
    assert {r["name"] for r in rows if r["family"].startswith("primary")} == {
        "H05-VS-H00", "H10-VS-H05", "GAP-H05", "GAP-H10", "GAP-CROSSING", "H05-VS-REF", "B-VS-A-H05"}
    # History 0 against 5 for B, the mask, the two ladders, all-position B on its own line and depth-matched.
    assert pairs["B-H05-VS-H00"] == ("B-H05", "B-H00", "contrast")
    assert pairs["MASK-H05"] == ("A-H05", "A-MASK05-C", "contrast")
    assert {(r["side_a_run"], r["side_b_run"]) for r in rows if "ladder" in r["family"]} == {
        ("A-H10", "A-H05"), ("A-H15", "A-H10"), ("A-H20", "A-H15"),
        ("B-H10", "B-H05"), ("B-H15", "B-H10"), ("B-H20", "B-H15")}
    assert pairs["ALLPOS-LINE"] == ("B-ALLPOS-H5", "", "own line")
    assert {r["side_b_run"] for r in rows if r["kind"] == "depth-matched"} == {"B-H05", "A-H05"}
    # Every side names a V1 run (a difference: a contrast), and every V1 run is read somewhere.
    for r in rows:
        known = {x["name"] for x in rows if x["kind"] == "contrast"} if r["kind"] == "difference" else set(RUNS)
        assert r["side_a_run"] in known and (r["side_b_run"] in known or r["kind"] == "own line"), r["name"]
    assert set(RUNS) <= {r["side_a_run"] for r in rows} | {r["side_b_run"] for r in rows}
    assert set(by) == {"H05-VS-H00", "H10-VS-H05", "GAP-H05", "GAP-H10", "GAP-CROSSING", "H05-VS-REF", "B-VS-A-H05",
                       "B-H05-VS-H00", "MASK-H05", "H15-VS-H10", "H20-VS-H15", "B-H10-VS-H05", "B-H15-VS-H10",
                       "B-H20-VS-H15", "B-VS-A-H00", "B-VS-A-H10", "B-VS-A-H15", "B-VS-A-H20", "ALLPOS-LINE",
                       "ALLPOS-DEPTH-B-H05", "ALLPOS-DEPTH-A-H05"}
    # B against A at every history (owner, forty-first and forty-second messages); B h5 stays primary 5.
    for h in ("00", "10", "15", "20"):
        assert pairs[f"B-VS-A-H{h}"] == (f"B-H{h}", f"A-H{h}", "contrast")
        assert by[f"B-VS-A-H{h}"]["family"] == "B against A at the other histories"


# -- the V1 run map agrees with the spec files ----------------------------------------------------------------------
@pytest.mark.parametrize("run", list(RUNS))
def test_v1_run_map_matches_its_spec_file(run):
    _, output_root, run_name, spec = RUNS[run]
    if not (ROOT / spec).is_file():
        pytest.skip(f"{spec} is built in V1 lane L1 or L2; checked once integrated")
    s = OmegaConf.load(ROOT / spec)
    runner = load("cl_runner_t", ROOT / "YOUR_PACKAGE" / "phase4a" / "scripts" / "run_ablations.py")  # same _expand_runs
    assert str(s.output_root) == output_root
    assert run_name in [r[0] for r in runner._expand_runs(s)[1]]


def test_paths_and_output_folders():
    # A and B: one file; REF-SINGLE: a folder (its post-hoc scores in "<base>__post_score/<id>"); all scheme-stripped.
    assert ar.qualify("bucket/preds/sequential/x__abc_preds.parquet") == "s3://bucket/preds/sequential/x__abc_preds.parquet"
    assert ar.qualify("bucket/preds/ref_single__post_score/20261014T0Z-a") == "s3://bucket/preds/ref_single__post_score/20261014T0Z-a"
    assert ar.qualify("") == "" and ar.qualify(None) == ""
    root = "ablations/arch_a_flat/history_h10"
    assert ar.in_output_root(f"/sandbox/{root}/20261013T000000Z-a", root)
    assert not ar.in_output_root("/pod/ablations/arch_a_flat/history_h10x/2026-a", root)
    assert not ar.in_output_root(f"/pod/{root}/2026-a/deeper", root)


# -- the run-table builder -----------------------------------------------------------------------------------------
def test_all_fifteen_runs(tmp_path):
    runs, table, args, text = build(tmp_path, full_ledger(tmp_path))
    assert all(r["status"] == "found" for r in runs.values())
    assert runs["A-H05"]["evaluation"].startswith("post-hoc scoring ")
    assert runs["A-H05"]["prediction_path"] == "s3://bucket/preds/A-H05_post.parquet"
    assert runs["A-H10"]["evaluation"] == "runner" and runs["A-H10"]["prediction_path"] == "s3://bucket/preds/A-H10.parquet"
    assert args == ["--difference", "GAP-H10", "GAP-H05", "--depth-matched", "B-ALLPOS-H5:B-H05,A-H05"]
    n = sum(r["kind"] == "contrast" for r in rows_of(CONTRASTS))
    assert len(table) == 2 * n + 1 and table[-1]["run"] == "B-ALLPOS-H5" and table[-1]["contrast"] == ""
    # V1 has no validation scoring: no validation predictions; valid_ap (results.csv, via the ledger) gives the sign.
    assert all(t["validation_path"] == "" and t["valid_ap"] == "0.1" and t["seed"] == "42" for t in table)
    assert "V1 runs found in" in text and "15 of 15" in text and "contrasts and readings not available: 0" in text
    pr = load("cl_paired_report_t", HERE / "paired_report.py")  # paired_report.py accepts the table as it is
    models, contrasts = pr.read_run_table(str(tmp_path / "out" / "run_table.csv"))
    assert len(models) == 15 and len(contrasts) == n


def test_missing_run_is_named_and_its_contrasts_are_left_out(tmp_path):
    runs, table, args, text = build(tmp_path, full_ledger(tmp_path, skip=("A-GAP05-OFF",)))
    assert runs["A-GAP05-OFF"]["status"] == "no attempt with status ok (no ledger row)"
    assert not any(t["run"] == "A-GAP05-OFF" or t["contrast"] == "GAP-H05" for t in table)
    assert "--difference" not in args and any(t["contrast"] == "GAP-H10" for t in table)
    assert "14 of 15" in text and "  A-GAP05-OFF: NOT FOUND: no attempt with status ok (no ledger row)" in text
    assert "  GAP-H05: not available (A-GAP05-OFF not found)" in text
    assert "  GAP-CROSSING: not available (GAP-H05 not found)" in text


def test_failed_run_is_named_with_its_status(tmp_path):
    bad = attempt(tmp_path / "pod", "B-ALLPOS-H5", status="train_failed")
    runs, table, args, text = build(tmp_path, full_ledger(tmp_path, override={"B-ALLPOS-H5": bad}))
    assert runs["B-ALLPOS-H5"]["status"] == "no attempt with status ok (train_failed)"
    assert "--depth-matched" not in args and not any(t["run"] == "B-ALLPOS-H5" for t in table)
    for name in ("ALLPOS-LINE", "ALLPOS-DEPTH-B-H05", "ALLPOS-DEPTH-A-H05"):
        assert f"  {name}: not available (B-ALLPOS-H5 not found)" in text


def test_two_attempts_of_one_run(tmp_path):
    failed = attempt(tmp_path / "pod", "B-H10", "20261013T000000Z-old", status="train_failed", finished="2026-10-13T00")
    ok = attempt(tmp_path / "pod", "B-H10", "20261013T050000Z-new", runner="bucket/new.parquet", finished="2026-10-13T06")
    ledger = full_ledger(tmp_path, override={"B-H10": failed})
    rows = rows_of(ledger)
    write_ledger(ledger, [*rows, ok])
    runs, *_ = build(tmp_path, ledger)
    assert runs["B-H10"]["attempt_dir"].endswith("20261013T050000Z-new") and runs["B-H10"]["other_attempts"] == 1
    newer = attempt(tmp_path / "pod", "B-H10", "20261013T090000Z-newer", runner="bucket/newer.parquet",
                    finished="2026-10-13T10")
    write_ledger(ledger, [*rows, ok, newer])
    runs, *_ = build(tmp_path, ledger)  # two ok attempts: the newest
    assert runs["B-H10"]["prediction_path"] == "s3://bucket/newer.parquet" and runs["B-H10"]["other_attempts"] == 2


def test_latest_ledger_revision_decides(tmp_path):
    first = attempt(tmp_path / "pod", "A-H10", status="not_run", revision=1)
    ledger = full_ledger(tmp_path, override={"A-H10": first})
    rows = rows_of(ledger)
    write_ledger(ledger, [*rows, dict(first, status="ok", revision="2", predictions_path="bucket/a.parquet")])
    assert build(tmp_path, ledger)[0]["A-H10"]["status"] == "found"
    write_ledger(ledger, [*rows, dict(first, status="ok", revision="2", predictions_path="bucket/a.parquet"),
                          dict(first, status="evidence_mismatch:x", revision="3")])
    assert build(tmp_path, ledger)[0]["A-H10"]["status"] == "no attempt with status ok (evidence_mismatch:x)"


@pytest.mark.parametrize("post,found", [
    ([("bucket/p.parquet", "score_failed")], False),
    ([("bucket/p.parquet", "ok", "d" * 64)], False),                             # another checkpoint
    ([("bucket/p.parquet", "ok", None, {"file_start": 8000, "file_end": 8005})], False),
    ([("bucket/p.parquet",)], True),
    ([("bucket/old.parquet",), ("bucket/p.parquet",), ("bucket/x.parquet", "score_failed")], True),  # the newest ok one
])
def test_post_hoc_scoring_must_be_ok_on_this_checkpoint_and_range(tmp_path, post, found):
    row = attempt(tmp_path / "pod", "A-H00", post=post)
    runs, _, _, text = build(tmp_path, full_ledger(tmp_path, override={"A-H00": row}))
    if found:
        assert runs["A-H00"]["prediction_path"] == "s3://bucket/p.parquet"
    else:
        assert runs["A-H00"]["status"].startswith("no evaluation predictions")
        assert "  H05-VS-H00: not available (A-H00 not found)" in text


# -- analysis.sh and its page --------------------------------------------------------------------------------------
STUB_PREFLIGHT = r'''#!/usr/bin/env python3
import os, sys
mode = os.environ.get("STUB_PREFLIGHT", "pass")
out = os.path.join(sys.argv[sys.argv.index("--out-root") + 1], "20261015T000000Z"); os.makedirs(out, exist_ok=True)
open(os.path.join(out, "SUMMARY.txt"), "w").write("RESULT " + ("PASS" if mode == "pass" else "FAIL") + " | stub\n")
open(os.path.join(out, "data_contract.json"), "w").write("{}")
print("PREFLIGHT_DIR=" + out)
sys.exit(0 if mode == "pass" else 1)
'''
# Stands in for paired_report.py where only the shell contract is under test.
STUB_PAIRED = r'''#!/usr/bin/env python3
import os, sys
out = sys.argv[sys.argv.index("--out-dir") + 1]; os.makedirs(out, exist_ok=True)
open(os.path.join(out, "paired_report.txt"), "w").write("stub report " + " ".join(sys.argv[1:]) + "\n")
print("stub paired report")
sys.exit(int(os.environ.get("STUB_PAIRED_EXIT", "0")))
'''


def shell_layout(tmp_path, paired_stub=None):
    """A repository with analysis.sh, the real analysis_runs.py, collect_returns.py, paired_report.py (or a stub) and
    v1_contrasts.csv, a stub pre-flight, and links to the fraud and YOUR_PACKAGE packages."""
    repo = tmp_path / "repo"
    rb = repo / "runbook" / "2026-10-07"
    rb.mkdir(parents=True)
    for name in ("analysis.sh", "analysis_runs.py", "collect_returns.py", "paired_report.py", "v1_contrasts.csv"):
        shutil.copyfile(HERE / name, rb / name)
    if paired_stub:
        (rb / "paired_report.py").write_text(paired_stub)
    (rb / "preflight_pod.py").write_text(STUB_PREFLIGHT)
    for pkg in ("fraud", "YOUR_PACKAGE"):
        (repo / pkg).symlink_to(ROOT / pkg)
    return repo


def run_analysis(repo, env_extra=None, cwd=None):
    env = {k: v for k, v in os.environ.items() if k not in ("RUNBOOK_SANDBOX", "PREFLIGHT_ARGS", "RUNBOOK_BANK_OVERRIDES")}
    env.update({"PYTHON": sys.executable, "PYTHONPATH": os.pathsep.join([str(ROOT / "src"), str(ROOT)])})
    env.update(env_extra or {})
    p = subprocess.run(["bash", str(repo / "runbook" / "2026-10-07" / "analysis.sh")], cwd=cwd or str(repo), env=env,
                       capture_output=True, text=True, check=False)
    returns = Path(env.get("RUNBOOK_SANDBOX") or repo / "runs") / "returns"
    return p, sorted(returns.glob("analysis_*"))


def test_analysis_sh_names_the_return_first_and_a_missing_run_does_not_stop_it(tmp_path):
    repo = shell_layout(tmp_path, STUB_PAIRED)
    full_ledger(repo, skip=("A-H20",))  # repo/runs/run_log.csv
    p, folders = run_analysis(repo, cwd="/")
    assert p.returncode == 0, p.stdout + p.stderr
    out = folders[0]
    rel = f"runs/returns/{out.name}"
    assert p.stdout.splitlines()[0] == f"analysis return folder: {rel} (send this folder when the analysis ends or stops)"
    assert p.stdout.rstrip().splitlines()[-1] == f"Analysis finished: 14 of 15 runs found and compared; send {rel}/"
    assert (out / "preflight_20261015T000000Z" / "SUMMARY.txt").is_file()
    assert "  A-H20: NOT FOUND" in (out / "runs" / "RUNS.txt").read_text()
    for f in ("runs/run_table.csv", "runs/paired_args.txt", "report/paired_report.txt", "logs/analysis_runs.log",
              "logs/paired_report.log", "ANALYSIS_STATUS.txt"):
        assert (out / f).is_file(), f
    assert "--depth-matched B-ALLPOS-H5:B-H05,A-H05" in (out / "report" / "paired_report.txt").read_text()


def test_analysis_sh_reports_a_comparison_that_did_not_finish(tmp_path):
    repo = shell_layout(tmp_path, STUB_PAIRED)
    full_ledger(repo)
    p, _ = run_analysis(repo, {"STUB_PAIRED_EXIT": "2"})
    assert p.returncode == 2
    assert p.stdout.rstrip().splitlines()[-1].startswith("Analysis finished: THE COMPARISON DID NOT FINISH (see logs/)")


def test_analysis_sh_stops_at_a_failed_preflight_and_reads_nothing(tmp_path):
    repo = shell_layout(tmp_path, STUB_PAIRED)
    full_ledger(repo)
    p, folders = run_analysis(repo, {"STUB_PREFLIGHT": "fail"})
    assert p.returncode == 1 and "PRE-FLIGHT FAILED" in p.stdout
    assert (folders[0] / "preflight_20261015T000000Z" / "SUMMARY.txt").is_file()
    assert not (folders[0] / "runs").exists() and not (folders[0] / "report").exists()


@pytest.mark.parametrize("var", ["RUNBOOK_SANDBOX", "PREFLIGHT_ARGS"])
def test_analysis_sh_stops_on_harness_variables_unless_the_bank_flag_is_set(tmp_path, var):
    repo = shell_layout(tmp_path, STUB_PAIRED)
    full_ledger(repo)
    p, folders = run_analysis(repo, {var: "x"})
    assert p.returncode == 1 and folders == []
    assert p.stdout.startswith(f"STOPPED BEFORE START: set in this shell: {var}.") and "Nothing was run" in p.stdout
    sb = tmp_path / "sb"
    full_ledger(sb)
    p, folders = run_analysis(repo, {var: str(sb) if var == "RUNBOOK_SANDBOX" else "x", "RUNBOOK_BANK_OVERRIDES": "1"})
    assert p.returncode == 0 and len(folders) == 1, p.stdout + p.stderr


def test_analysis_script_contract():
    script = (HERE / "analysis.sh").read_text()
    assert 'echo "analysis return folder: $OUT (send this folder when the analysis ends or stops)"' in script
    for verdict in ("of 15 runs found and compared", "THE COMPARISON DID NOT FINISH (see logs/)"):
        assert verdict in script
    assert script.split("for v in ", 1)[1].split(";", 1)[0].split() == ["RUNBOOK_SANDBOX", "PREFLIGHT_ARGS"]
    assert '"$PY" "$HERE/preflight_pod.py" --out-root "$PF" --skip-tests ${PREFLIGHT_ARGS:-}' in script


# -- end to end on the shared fixture ------------------------------------------------------------------------------
def fixture_dir(tmp_path):
    """The shared V1 fixture: $V1_FIXTURE or /tmp/v1fix (as test_paired_report.py), else the fixture branch."""
    named = Path(os.environ.get("V1_FIXTURE", "/tmp/v1fix"))
    if (named / "CHECKSUMS.json").is_file():
        return named
    if subprocess.run(["git", "-C", str(ROOT), "rev-parse", "-q", "--verify", FIXTURE_REF + "^{commit}"],
                      capture_output=True, check=False).returncode:
        pytest.skip(f"shared fixture not here: fetch {FIXTURE_REF[7:]} or set V1_FIXTURE")
    fix = tmp_path / "fixture"
    fix.mkdir()
    archive = subprocess.run(["git", "-C", str(ROOT), "archive", FIXTURE_REF], capture_output=True, check=True).stdout
    subprocess.run(["tar", "-x", "-C", str(fix)], input=archive, check=True)
    return fix


def fixture_ledger(fix, sb, drop=()):
    """A synthetic ledger over the fixture's fake predictions, laid out as on the pod: evaluation predictions in (fake)
    S3 recorded without s3:// as the scorers record them (the validation-only runs through a post-hoc scoring), and
    each run's valid_ap as its results.csv would give it (here: the AP of the fixture's validation predictions)."""
    from sklearn.metrics import average_precision_score
    key = "ARTIFACT_BUCKET/YOUR_ID/tabular_fraud/predictions/fixture"
    rows = []
    for run, *_ in ar.V1_RUNS:
        if run in drop:
            continue
        (Path(sb) / "fake_s3" / key).mkdir(parents=True, exist_ok=True)
        shutil.copyfile(fix / "predictions" / "eval" / f"{run}.parquet", Path(sb) / "fake_s3" / key / f"{run}.parquet")
        valid = pd.read_parquet(fix / "predictions" / "valid" / f"{run}.parquet", columns=["frd_tag", "score"])
        post = [(f"{key}/{run}.parquet",)] if run in VALIDATION_ONLY else []
        row = attempt(Path(sb) / "pod", run, "20261013T000000Z-fix", post=post,
                      runner=None if run in VALIDATION_ONLY else f"{key}/{run}.parquet")
        row["valid_ap"] = repr(float(average_precision_score(valid["frd_tag"], valid["score"])))
        rows.append(row)
    return write_ledger(Path(sb) / "runs" / "run_log.csv", rows)


def test_end_to_end_on_the_shared_fixture(tmp_path):
    fix = fixture_dir(tmp_path)
    repo = shell_layout(tmp_path)  # the real analysis_runs.py and paired_report.py; only the pre-flight is a stub
    sb = tmp_path / "sb"
    shutil.copytree(fix / "fake_s3", sb / "fake_s3")
    fixture_ledger(fix, sb, drop=("B-H15",))
    env = {"FAKE_S3_ROOT": str(sb / "fake_s3"), "TF_REPO_ROOT": str(ROOT), "RUNBOOK_SANDBOX": str(sb),
           "RUNBOOK_BANK_OVERRIDES": "1", "OMP_NUM_THREADS": "2",
           "PYTHONPATH": os.pathsep.join([str(HERE / "synthetic"), str(ROOT / "src"), str(ROOT)])}
    p, folders = run_analysis(repo, env)
    assert p.returncode == 0, p.stdout + p.stderr
    out = folders[0]
    assert "Analysis finished: 14 of 15 runs found and compared" in p.stdout
    report = (out / "report" / "paired_report.txt").read_text()
    assert "evaluation: 11 raw files, 7477 raw rows" in report and "validation:" not in report.split("Join check")[0]
    assert "every run holds exactly the cohort ids with the same labels" in report
    labels = {r["contrast"]: r["label"] for r in rows_of(out / "report" / "paired_contrasts.csv")}
    assert "B-H15-VS-H10" not in labels and labels["H05-VS-H00"] == "consistent positive"
    lines = rows_of(out / "report" / "paired_lines.csv")
    assert "overall" in {ln["line"] for ln in lines if ln["kind"] == "contrast" and ln["split"] == "evaluation"}
    assert any(ln["kind"] == "difference of contrasts" for ln in lines)
    assert any(ln["kind"].startswith("depth-matched") for ln in lines)
    assert "  B-H15: NOT FOUND" in (out / "runs" / "RUNS.txt").read_text()
    # Aggregates only: no prediction file, no checkpoint, and no transaction or account id of the fixture anywhere.
    assert not list(out.rglob("*.parquet")) and not list(out.rglob("*.ckpt"))
    ids = pd.read_parquet(fix / "predictions" / "eval" / "A-H05.parquet", columns=["fi_transaction_id",
                                                                                  "Nmap_account_reference_xid"])
    ids = set(ids["fi_transaction_id"].astype(str)) | set(ids["Nmap_account_reference_xid"].astype(str))
    for f in out.rglob("*"):
        if f.is_file():
            text = f.read_text(errors="replace")
            assert not [i for i in ids if i in text], f"{f.relative_to(out)} holds row-level ids"
