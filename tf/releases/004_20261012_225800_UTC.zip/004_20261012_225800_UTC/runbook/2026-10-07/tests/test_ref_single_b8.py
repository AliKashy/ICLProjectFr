# reviewer, 2026-10-12. V1 build item B8: REF-SINGLE (reference's single-transaction model) in the run system, the seven
# parts of RECONCILIATION v1.2 line 64, and the fixed prediction interface shared with A and B (lane L1).
#   part 1  run_step.py --phase base --spec ref_single.yaml is accepted
#   part 2  YOUR_PACKAGE/base/scripts/run_ablations.py gives every run its own eval.predictions_base (existing refused)
#   part 3  score_streaming.py writes the schema-1 metrics JSON with the checkpoint hash
#   part 4  collect_returns.py and score_attempt.py handle a base attempt without sequence.* settings
#   part 5  the pre-flight reads a "base ref_single.yaml" batch step and checks the spec (C12)
#   part 6  the cohort check reads the per-file prediction parquet, file by file
#   part 7  these tests, and one synthetic path that trains and scores REF-SINGLE end to end (CPU, fake S3)
# Synthetic data only (runbook/2026-10-07/synthetic/make_synthetic_data.py); no bank data, no GPU, no network.
#     PYTHONPATH=src:. python -m pytest -q -p no:cacheprovider runbook/2026-10-07/tests/test_ref_single_b8.py
import contextlib
import csv
import glob
import hashlib
import importlib.util
import io
import json
import os
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
import pytest
from omegaconf import OmegaConf

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[1]
REF = "YOUR_PACKAGE/base/configs/ref_single.yaml"
# FIXED INTERFACE 1: the prediction parquet columns of A, B and REF-SINGLE, in this order: the composite id
# (transaction id, account id), the amount, the target and the score.
PREDICTION_COLUMNS = ["fi_transaction_id", "Nmap_account_reference_xid", "transaction_amt", "frd_tag", "score"]


def load(name, path):
    s = importlib.util.spec_from_file_location(f"{name}_{os.urandom(4).hex()}", path)
    m = importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return m


def quiet(fn, *a, **k):
    with contextlib.redirect_stdout(io.StringIO()):
        return fn(*a, **k)


def effective(spec_rel, run_index=0):
    """A spec cell resolved the way the runners resolve it (base config + common + axis overrides)."""
    spec = OmegaConf.load(ROOT / spec_rel)
    phase = Path(spec_rel).parts[1]
    runner = load("runner", ROOT / "YOUR_PACKAGE" / phase / "scripts" / "run_ablations.py")
    _, runs = runner._expand_runs(spec)
    base = OmegaConf.load(ROOT / str(spec.base_config))
    return OmegaConf.merge(base, OmegaConf.from_dotlist([str(o) for o in spec.common_overrides] + runs[run_index][1]))


# ---------------------------------------------------------------- part 1: run_step.py accepts the base phase
def test_run_step_accepts_phase_base_and_finds_its_runner():
    env = {**os.environ, "RUNBOOK_SANDBOX": "/nonexistent"}
    env.pop("RUNBOOK_BANK_OVERRIDES", None)
    # The inherited-state stop (exit 3) comes after argument parsing: --phase base was accepted.
    p = subprocess.run([sys.executable, str(HERE / "run_step.py"), "--phase", "base", "--spec", "ref_single.yaml"],
                       cwd=ROOT, env=env, capture_output=True, text=True, timeout=60)
    assert p.returncode == 3 and "STOPPED BEFORE START" in p.stdout
    p = subprocess.run([sys.executable, str(HERE / "run_step.py"), "--phase", "phase9", "--spec", "x.yaml"],
                       cwd=ROOT, env=env, capture_output=True, text=True, timeout=60)
    assert p.returncode == 2 and "invalid choice" in p.stderr
    rs = load("run_step", HERE / "run_step.py")
    assert Path(rs.runner_path("base")) == ROOT / "YOUR_PACKAGE/base/scripts/run_ablations.py"
    assert (ROOT / "YOUR_PACKAGE/base/configs/ref_single.yaml").is_file()


# ---------------------------------------------------------------- the spec: reference's recipe on the A and B cohort
def test_ref_single_is_reference_recipe_on_the_batch_cohort_with_his_seed():
    spec = OmegaConf.load(ROOT / REF)
    assert str(spec.base_config) == "YOUR_PACKAGE/base/configs/streaming.yaml" and spec.run_score is True
    runner = load("runner_base", ROOT / "YOUR_PACKAGE/base/scripts/run_ablations.py")
    _, runs = runner._expand_runs(spec)
    assert [r[0] for r in runs] == ["seed-s42"]   # reference's seed only (owner, thirty-first message)
    reference = OmegaConf.load(ROOT / "YOUR_PACKAGE/base/configs/streaming.yaml")
    a_cell = effective("YOUR_PACKAGE/phase4a/configs/ft_decisions_h0_seeds.yaml")
    for i, seed in enumerate((42,)):
        e = effective(REF, i)
        assert e.training.seed == seed
        # His recipe, unchanged: model, optimizer settings, batch, early stopping, artifacts, predictors, features.
        for key in ("model", "artifacts", "predictors", "datetime", "preprocess"):
            assert e[key] == reference[key], key
        for key in ("batch_size", "learning_rate", "weight_decay", "early_stopping_patience", "monitor", "pos_weight"):
            assert e.training[key] == reference.training[key], key
        assert (e.model.input_embed_dim, e.model.num_attn_blocks, e.training.batch_size) == (32, 3, 8192)
        # The cohort of the A and B batch cells: training 1 to 10, validation 4950 to 4954, 10 epochs; scored 8000-8010.
        for key in ("train_base", "train_start", "train_end", "val_base", "val_start", "val_end", "account_col",
                    "tie_break_col", "id_cols", "amount_col", "target_col", "order_col"):
            assert e.data[key] == a_cell.data[key], key
        assert e.training.max_epochs == a_cell.training.max_epochs == 10
        assert (e.eval.base, e.eval.file_start, e.eval.file_end) == (a_cell.eval.base, 8000, 8010)
    # Its own output_root, shared with no other spec.
    roots = [str(OmegaConf.load(p).get("output_root")) for p in glob.glob(str(ROOT / "YOUR_PACKAGE/*/configs/*.yaml"))
             if "output_root" in OmegaConf.load(p)]
    assert roots.count(str(spec.output_root)) == 1


# ---------------------------------------------------------------- part 2: the base runner's prediction folder
def test_base_runner_differs_from_the_a_runner_only_in_the_named_places():
    a = (ROOT / "YOUR_PACKAGE/phase4a/scripts/run_ablations.py").read_text().replace("\r\n", "\n")
    b = (ROOT / "YOUR_PACKAGE/base/scripts/run_ablations.py").read_text()
    body = lambda text: text[text.index("import argparse"):]
    a_body = body(a).replace('"phase4a", "scripts", "train_sequential.py"', '"base", "scripts", "train_streaming.py"')
    a_body = a_body.replace('"phase4a", "scripts", "score_sequential.py"', '"base", "scripts", "score_streaming.py"')
    added = [l for l in body(b).splitlines() if l not in set(a_body.splitlines())]
    assert all("predictions_base" in l or "This run's own prediction folder" in l or "configured" in l
               or "def _predictions_base" in l or not l.strip() for l in added), added
    runner = load("runner_base", ROOT / "YOUR_PACKAGE/base/scripts/run_ablations.py")
    assert runner._predictions_base("s3://b/preds/", "/x/ablations/ref_single/ref_single_seeds", "ATT", "seed-s42") \
        == "s3://b/preds/ref_single_seeds/ATT/seed-s42"


# ---------------------------------------------------------------- part 4: collector settings for a base run
def test_collector_settings_and_phase_for_a_base_run(tmp_path):
    cr = load("collect_returns", HERE / "collect_returns.py")
    sa = load("score_attempt", HERE / "score_attempt.py")
    for mod in (cr, sa):
        assert mod.spec_phase(OmegaConf.create({"base_config": "YOUR_PACKAGE/base/configs/streaming.yaml"})) == "base"
        assert mod.spec_phase(OmegaConf.create({"base_config": "YOUR_PACKAGE/phase4b/configs/sequential_hier.yaml"})) == "phase4b"
        assert mod.spec_phase(OmegaConf.create({"base_config": "YOUR_PACKAGE/phase4a/configs/sequential.yaml"})) == "phase4a"
    assert sa.SCORERS["base"] == "score_streaming.py"
    run = tmp_path / "seed-s42"
    run.mkdir()
    OmegaConf.save(effective(REF, 0), run / "resolved_train.yaml")
    st = cr.settings(str(run), "base")
    assert st["seed"] == 42 and st["train_files"] == "1-10" and st["val_files"] == "4950-4954"
    assert st["eval_files"] == "8000-8010" and st["model"] == "base d32 blocks 3 heads 8"
    assert st["batch_x_accum"] == "8192x1" and st["_compute_metrics"] is True
    assert not {"history_len", "mask", "time_delta", "embedding", "optimizer"} & set(st)


# ---------------------------------------------------------------- part 5: the pre-flight reads and checks the step
def fresh_pf():
    return load("pf_b8", HERE / "preflight_pod.py")


def test_preflight_reads_a_base_step_line_from_a_batch_script(tmp_path):
    pf = fresh_pf()
    (tmp_path / "batch2.sh").write_text('for step in "phase4a ft_decisions.yaml" "base ref_single.yaml" \\\n'
                                        '            "phase4b ft_decisions_hier_long.yaml"; do\n')
    assert pf.specs_in_batch_scripts(str(tmp_path)) == {
        "phase4a": ["ft_decisions.yaml"], "phase4b": ["ft_decisions_hier_long.yaml"], "base": ["ref_single.yaml"]}
    # The old pattern matched only "phase4a|phase4b ft_decisions*.yaml": this line was skipped silently (C12).
    import re
    assert re.findall(r'"(phase4[ab]) (ft_decisions\w*\.yaml)"', '"base ref_single.yaml"') == []


def test_preflight_checks_the_ref_single_spec_and_fails_it_off_the_cohort(tmp_path):
    pf = fresh_pf()
    pf.SPECS = {"phase4a": [], "phase4b": [], "base": ["ref_single.yaml"]}
    pf.SMOKE_SPECS = {"phase4a": [], "phase4b": []}
    quiet(pf.check_specs, str(tmp_path))
    assert pf.FAILS == [] and any(l.startswith("PASS  base/ref_single.yaml: 1 cells") for l in pf.LINES)
    text = (tmp_path / "specs.txt").read_text()
    assert "base/ref_single.yaml:seed-s42 | single transaction batch 8192x1 | train 1-10 val 4950-4954 eval 8000-8010" in text
    pf = fresh_pf()
    pf.SPECS = {"phase4a": [], "phase4b": [], "base": ["ref_single.yaml"]}
    pf.SMOKE_SPECS = {"phase4a": [], "phase4b": []}
    original = OmegaConf.load

    def changed(path, *a, **k):
        cfg = original(path, *a, **k)
        if str(path).endswith("/configs/ref_single.yaml"):
            cfg.common_overrides = list(cfg.common_overrides) + ["data.train_end=100"]
        return cfg
    with patch.object(OmegaConf, "load", side_effect=changed):
        quiet(pf.check_specs, str(tmp_path))
    assert len(pf.FAILS) == 1 and pf.FAILS[0].startswith("base/ref_single.yaml") and "data.train_end 100" in pf.FAILS[0]
    pf = fresh_pf()
    pf.SPECS = {"phase4a": [], "phase4b": [], "base": ["ref_missing.yaml"]}
    pf.SMOKE_SPECS = {"phase4a": [], "phase4b": []}
    quiet(pf.check_specs, str(tmp_path))
    assert pf.FAILS and "base/ref_missing.yaml: a spec named by" in pf.FAILS[0]


def test_preflight_base_spec_files_join_the_batch_configuration(tmp_path):
    pf = fresh_pf()
    pf.SPECS = {"phase4a": [], "phase4b": [], "base": ["ref_single.yaml"]}
    pf.SMOKE_SPECS = {"phase4a": [], "phase4b": []}
    files = pf.batch_config_files()
    assert {"YOUR_PACKAGE/base/configs/ref_single.yaml", "YOUR_PACKAGE/base/configs/streaming.yaml",
            "fraud/configs/predictors.csv"} <= set(files)


def test_reference_path_packages_stay_warn_when_a_base_step_is_listed(tmp_path):
    """A missing pytorch_tabnet is WARN with its pip line, not FAIL, even with a base step listed: the pre-flight reads
    the specs of both batch scripts, so a FAIL would also stop the smoke and batch 1, which never use it (owner's
    no-guard rule; supersedes RECONCILIATION line 64's WARN-to-FAIL note). REF-SINGLE's own step fails if it is missing."""
    pf = fresh_pf()
    req = tmp_path / "requirements-pod.txt"
    req.write_text("torch>=2.0\npytest\nrequests\npytorch-tabnet\n")
    pf.REQUIREMENTS_POD = str(req)
    pf.SPECS = {"phase4a": [], "phase4b": [], "base": ["ref_single.yaml"]}
    pf.optional_missing = lambda pkg: "pytorch_tabnet" if pkg == "pytorch_tabnet" else None
    quiet(pf.check_imports, str(tmp_path))
    assert not [f for f in pf.FAILS if "tabnet" in f]
    assert any("pytorch_tabnet" in w and 'pip install "pytorch-tabnet"' in w for w in pf.WARNS)


# ---------------------------------------------------------------- part 6: per-file cohort check (unit)
def write_preds(folder, files):
    folder.mkdir(parents=True, exist_ok=True)
    paths = []
    for name, targets in files.items():
        n = len(targets)
        pd.DataFrame({"fi_transaction_id": [f"{name}-{i}" for i in range(n)], "Nmap_account_reference_xid": ["a"] * n,
                      "transaction_amt": [1.0] * n, "frd_tag": targets, "score": [0.5] * n}).to_parquet(folder / name)
        paths.append(str(folder / name))
    return paths


@pytest.mark.parametrize("module", ["collect_returns", "score_attempt"])
def test_per_file_cohort_check_compares_every_file(tmp_path, module, monkeypatch):
    import fraud.data.s3_utils as s3_utils
    monkeypatch.setattr(s3_utils, "make_s3_filesystem", lambda *a, **k: None)   # local files stand in for S3
    mod = load(module, HERE / f"{module}.py")
    yaml = tmp_path / "resolved_score.yaml"
    OmegaConf.save(OmegaConf.create({"data": {"target_col": "frd_tag"}, "s3": {"cred_path": "unused"}}), yaml)
    paths = write_preds(tmp_path / "p", {"part_8000.parquet": [0, 1, 0], "part_8001.parquet": [1, 1]})
    sm = {"prediction_files": paths}
    split = {"files": [{"file": "part_8000.parquet", "rows": 3, "positives": 1},
                       {"file": "part_8001.parquet", "rows": 2, "positives": 2}]}
    assert mod.per_file_counts(sm, str(yaml)) == {"part_8000.parquet": [3, 1], "part_8001.parquet": [2, 2]}
    assert mod.check_per_file(split, sm, str(yaml)) == []
    moved = {"files": [{"file": "part_8000.parquet", "rows": 2, "positives": 1},
                       {"file": "part_8001.parquet", "rows": 3, "positives": 2}]}   # same totals, other files
    assert mod.check_per_file(moved, sm, str(yaml)) == ["cohort_files"]
    missing = {"files": split["files"] + [{"file": "part_8002.parquet", "rows": 1, "positives": 0}]}
    assert mod.check_per_file(missing, sm, str(yaml)) == ["cohort_files"]
    assert mod.check_per_file(split, {"prediction_files": [str(tmp_path / "gone.parquet")]}, str(yaml)) \
        == ["cohort_files_unreadable"]
    assert mod.check_per_file(split, {"predictions_path": "x"}, str(yaml)) == []   # A and B: one file, not per file


# ---------------------------------------------------------------- part 7: synthetic end to end (train and score)
def composite_digest(frames):
    df = pd.concat(frames, ignore_index=True)
    h = np.sort(pd.util.hash_pandas_object(df[["Nmap_account_reference_xid", "fi_transaction_id"]].astype(str),
                                           index=False).to_numpy())
    return hashlib.sha256(b"composite-id-uint64-multiset-v1" + len(h).to_bytes(8, "big")
                          + h.astype(">u8").tobytes()).hexdigest()


def split_contract(folder, ids):
    frames, files = [], []
    for i in ids:
        df = pd.read_parquet(Path(folder) / f"part_{i}.parquet")
        frames.append(df)
        files.append({"file": f"part_{i}.parquet", "rows": len(df), "positives": int(df.frd_tag.sum())})
    return {"rows": sum(f["rows"] for f in files), "positives": sum(f["positives"] for f in files), "files": files,
            "composite_id_digest_version": 1, "composite_id_multiset_sha256": composite_digest(frames)}


@pytest.fixture(scope="module")
def ref_sandbox(tmp_path_factory):
    """Synthetic data and artifacts, a pre-flight-style data contract, and one REF-SINGLE step through run_step.py in
    the sandbox (seed 42, 1 epoch, tiny model), as the harness runs it."""
    sb = tmp_path_factory.mktemp("ref_sb")
    env = {**os.environ, "FAKE_S3_ROOT": str(sb / "fake_s3"), "TF_REPO_ROOT": str(ROOT), "RUNBOOK_SANDBOX": str(sb),
           "RUNBOOK_BANK_OVERRIDES": "1", "OMP_NUM_THREADS": "2",
           "PYTHONPATH": os.pathsep.join([str(HERE / "synthetic"), str(ROOT / "src"), str(ROOT)])}
    run = lambda cmd, **k: subprocess.run(cmd, cwd=ROOT, env=env, capture_output=True, text=True, timeout=1800, **k)
    p = run([sys.executable, str(HERE / "synthetic/make_synthetic_data.py"), "--accounts", "6"])
    assert p.returncode == 0, p.stderr
    p = run([sys.executable, "fraud/scripts/build_preprocessing_artifacts.py", "--config",
             "fraud/configs/preprocessing.yaml",
             "build.output_base=s3://ARTIFACT_BUCKET/YOUR_ID/tabular_fraud/artifacts"])
    assert p.returncode == 0, p.stdout[-2000:] + p.stderr[-2000:]
    raw = sb / "fake_s3/DATA_BUCKET"
    pf = sb / "preflight_fake"
    pf.mkdir()
    (pf / "data_contract.json").write_text(json.dumps({
        "eval_8000_8010": split_contract(raw / "tfm_EVAL_raw_data", range(8000, 8011)),
        "valid_4950_4954": split_contract(raw / "tfm_raw_data", range(4950, 4955))}))
    p = run([sys.executable, str(HERE / "run_step.py"), "--phase", "base", "--spec", "ref_single.yaml",
             "--preflight", str(pf), "--sample-seconds", "5"])
    attempt = next((l.split("=", 1)[1] for l in p.stdout.splitlines() if l.startswith("ATTEMPT_DIR=")), "")
    ret = next((l.split("=", 1)[1] for l in p.stdout.splitlines() if l.startswith("RETURN_DIR=")), "")
    return {"sb": sb, "env": env, "run": run, "pf": pf, "raw": raw, "step": p, "attempt": Path(attempt),
            "ret": Path(ret)}


def test_ref_single_trains_scores_and_is_accepted_with_its_cohort(ref_sandbox):
    p = ref_sandbox["step"]
    assert p.returncode == 0, p.stdout[-4000:] + p.stderr[-4000:]
    text = (ref_sandbox["ret"] / "RETURN.txt").read_text()
    assert "ACCEPTED: every run ok and recorded" in text and "1 of 1 ok" in text
    with open(ref_sandbox["sb"] / "runs/run_log.csv", newline="") as f:
        rows = [r for r in csv.DictReader(f) if r["attempt_dir"] == str(ref_sandbox["attempt"].resolve())]
    assert sorted(r["run_name"] for r in rows) == ["seed-s42"]
    for r in rows:
        assert r["status"] == "ok" and r["cohort_check"] == "ok:preflight_fake" and r["run_score"] == "True"
        assert r["history_len"] == "" and r["model"].startswith("base d16 blocks 1 heads 8")
        assert (r["train_files"], r["val_files"], r["eval_files"]) == ("1-10", "4950-4954", "8000-8010")


def test_ref_single_predictions_folder_metrics_json_and_refusal(ref_sandbox):
    att = ref_sandbox["attempt"]
    bases = set()
    for run in ("seed-s42",):
        cfg = OmegaConf.load(att / run / "resolved_train.yaml")
        assert cfg.eval.predictions_base == (f"s3://ARTIFACT_BUCKET/YOUR_ID/tabular_fraud/predictions/"
                                             f"ref_single/ref_single_seeds/{att.name}/{run}")
        bases.add(cfg.eval.predictions_base)
        sm = json.loads((att / run / "score_metrics.json").read_text())
        assert sm["schema_version"] == 1 and sm["checkpoint_path"] == str(att / run / "best.ckpt")
        assert sm["checkpoint_sha256"] == hashlib.sha256((att / run / "best.ckpt").read_bytes()).hexdigest()
        assert [os.path.basename(f) for f in sm["prediction_files"]] == [f"part_{i}.parquet" for i in range(8000, 8011)]
        assert 0 < sm["n_positives"] < sm["n_predictions"] and 0 <= sm["average_precision"] <= 1
        folder = ref_sandbox["sb"] / "fake_s3" / sm["predictions_path"]
        table = pq.read_table(str(folder))
        # FIXED INTERFACE 1: same column names and order as the A and B scorers' parquet.
        assert table.column_names == PREDICTION_COLUMNS and table.num_rows == sm["n_predictions"]
        for f in sm["prediction_files"]:
            assert pq.read_schema(str(ref_sandbox["sb"] / "fake_s3" / f)).names == PREDICTION_COLUMNS
    assert len(bases) == 1
    # Existing predictions are refused: scoring the same resolved config again fails and changes nothing.
    first = ref_sandbox["sb"] / "fake_s3" / json.loads((att / "seed-s42/score_metrics.json").read_text())["prediction_files"][0]
    before = first.read_bytes()
    p = ref_sandbox["run"]([sys.executable, "YOUR_PACKAGE/base/scripts/score_streaming.py", "--config",
                            str(att / "seed-s42/resolved_score.yaml"), f"eval.metrics_output={att}/ignored.json"])
    assert p.returncode != 0 and "Prediction destination already exists" in p.stdout + p.stderr
    assert first.read_bytes() == before and not (att / "ignored.json").exists()


def test_temporal_eval_reads_the_ref_single_prediction_folder(ref_sandbox, tmp_path):
    """temporal_eval.py reads REF-SINGLE's per-file folder by the composite id, as it reads A's and B's single file;
    its overall AP is the scorer's AP."""
    sm = json.loads((ref_sandbox["attempt"] / "seed-s42/score_metrics.json").read_text())
    p = ref_sandbox["run"]([sys.executable, "YOUR_PACKAGE/scoring/temporal_eval.py", "--pred",
                            str(ref_sandbox["sb"] / "fake_s3" / sm["predictions_path"]), "--raw-base",
                            str(ref_sandbox["raw"] / "tfm_EVAL_raw_data"), "--file-start", "8000", "--file-end", "8010",
                            "--out", str(tmp_path / "t.csv"), "--summary-out", str(tmp_path / "s.csv")])
    assert p.returncode == 0, p.stdout[-3000:] + p.stderr[-3000:]
    with open(tmp_path / "s.csv", newline="") as f:
        overall = next(r for r in csv.DictReader(f) if r["slice"] == "overall")
    assert int(overall["n"]) == sm["n_predictions"] and abs(float(overall["pr_auc"]) - sm["average_precision"]) < 1e-9


@pytest.fixture(scope="module")
def ab_attempts(ref_sandbox):
    """One A cell and one B cell (the one-cell smoke specs) on the same synthetic data, through run_step.py."""
    attempts = {}
    for phase, spec in (("phase4a", "ft_decisions_smoke.yaml"), ("phase4b", "ft_decisions_hier_smoke.yaml")):
        p = ref_sandbox["run"]([sys.executable, str(HERE / "run_step.py"), "--phase", phase, "--spec", spec,
                                "--sample-seconds", "5"])
        attempts[phase] = (p, next((l.split("=", 1)[1] for l in p.stdout.splitlines()
                                    if l.startswith("ATTEMPT_DIR=")), ""))
    return attempts


def test_fixed_interface_1_a_b_and_ref_single_write_the_same_prediction_columns(ref_sandbox, ab_attempts, tmp_path):
    """FIXED INTERFACE 1: the A, B and REF-SINGLE scorers' parquet carry the same column names in the same order,
    with the composite id (transaction id, account id), so temporal_eval.py and the paired tool read all three alike."""
    found = {}
    for phase, (p, attempt) in ab_attempts.items():
        assert p.returncode == 0 and attempt, p.stdout[-3000:] + p.stderr[-3000:]
        out = tmp_path / phase   # the smoke cells are validation only: score them on evaluation after the fact
        s = ref_sandbox["run"]([sys.executable, str(HERE / "score_attempt.py"), attempt, "--return-dir", str(out)])
        assert s.returncode == 0, s.stdout[-3000:] + s.stderr[-3000:]
        [row] = list(csv.DictReader(open(out / "post_score_results.csv", newline="")))
        post = Path(attempt) / row["run_name"] / "post_score" / row["post_score_id"]
        preds = json.loads((post / "post_score_metrics.json").read_text())["predictions_path"]
        found[phase] = pq.read_schema(str(ref_sandbox["sb"] / "fake_s3" / preds)).names
    sm = json.loads((ref_sandbox["attempt"] / "seed-s42/score_metrics.json").read_text())
    found["base"] = pq.read_schema(str(ref_sandbox["sb"] / "fake_s3" / sm["prediction_files"][0])).names
    assert found == {"phase4a": PREDICTION_COLUMNS, "phase4b": PREDICTION_COLUMNS, "base": PREDICTION_COLUMNS}


def test_ref_single_override_post_score_leaves_the_run_accepted(ref_sandbox, tmp_path):
    """REF-02: an evaluation post-score of a REF-SINGLE run writes beside the run's prediction folder, so the run's
    own folder (read whole by the cohort check) still holds exactly its 11 files and the run still collects ok."""
    att, run = ref_sandbox["attempt"], ref_sandbox["run"]
    p = run([sys.executable, str(HERE / "score_attempt.py"), str(att), "--override-eval-files", "8000-8005"])
    assert p.returncode == 0, p.stdout[-3000:] + p.stderr[-3000:]
    p = run([sys.executable, str(HERE / "collect_returns.py"), str(att), "--no-ledger", "--preflight",
             str(ref_sandbox["pf"]), "--out", str(tmp_path / "collect")])
    assert p.returncode == 0 and "ACCEPTED: every run ok" in p.stdout, p.stdout[-3000:]
