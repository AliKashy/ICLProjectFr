"""The V1 run list, checked against the batch scripts themselves (owner, OWNER_QA thirty-first and thirty-second
messages: reference's seed 42 only, every run trained fresh; V1 design d2a7351).

Every step a batch script runs is expanded the way run_ablations.py expands it, its settings are resolved against
its base config, and the resulting runs must be exactly the V1 list below: no run missing (for example A h15), none
extra, none twice, all at seed 42 under the strict history rule on the same files, each spec with its own output
folder."""
import itertools
import os
import re
from collections import Counter

import pytest
from omegaconf import OmegaConf

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROOT = os.path.dirname(os.path.dirname(HERE))
STEP = re.compile(r'"(phase4a|phase4b|base) ([\w.]+\.yaml)"')

# (architecture, history, time gap on, attention mask, seed); all-position B and REF-SINGLE have no mask entry.
BATCH1 = Counter([
    ("A", 0, True, "bidirectional", 42),       # A-H00
    ("A", 5, True, "bidirectional", 42),       # A-H05
    ("B", 5, True, "bidirectional", 42),       # B-H05
    ("B", 10, True, "bidirectional", 42),      # B-H10
    ("A", 10, True, "bidirectional", 42),      # A-H10, the shared comparator
    ("A", 10, False, "bidirectional", 42),     # A-GAP10-OFF
])
BATCH2 = Counter([
    ("REF", None, None, None, 42),             # REF-SINGLE, reference's single-transaction model
    ("B", 0, True, "bidirectional", 42),       # B-H00
    ("A", 5, True, "causal", 42),              # A-MASK05-C
    ("A", 5, False, "bidirectional", 42),      # A-GAP05-OFF
    ("A", 15, True, "bidirectional", 42),      # A-H15
    ("B", 15, True, "bidirectional", 42),      # B-H15
    ("B", 20, True, "bidirectional", 42),      # B-H20
    ("A", 20, True, "bidirectional", 42),      # A-H20
    ("B-ALLPOS", 5, True, None, 42),           # B-ALLPOS-H5, its own line
])


def steps(script):
    text = open(os.path.join(HERE, script), encoding="utf-8").read()
    return STEP.findall(text)


def expand(spec):
    axes = spec.get("axes", {}) or {}
    names = list(axes.keys())
    runs = []
    for combo in itertools.product(*[list(axes[n].keys()) for n in names]):
        overrides = []
        for name, option in zip(names, combo):
            overrides.extend(str(o) for o in axes[name][option])
        runs.append(("__".join(f"{a}-{o}" for a, o in zip(names, combo)) or "default", overrides))
    return runs


def spec_path(phase, name):
    return os.path.join(ROOT, "YOUR_PACKAGE", phase, "configs", name)


def cells(script):
    out = []
    for phase, name in steps(script):
        spec = OmegaConf.load(spec_path(phase, name))
        base = OmegaConf.load(os.path.join(ROOT, str(spec.base_config)))
        common = [str(o) for o in spec.get("common_overrides", [])]
        for run_name, ov in expand(spec):
            eff = OmegaConf.merge(base, OmegaConf.from_dotlist(common + ov))
            seed = int(eff.training.seed)
            if phase == "base":
                key = ("REF", None, None, None, seed)
            else:
                allpos = bool(OmegaConf.select(eff, "sequence.predict_every_transaction", default=False))
                arch = "A" if phase == "phase4a" else ("B-ALLPOS" if allpos else "B")
                mask = None if allpos else str(eff.sequence.attention_mask)
                key = (arch, int(eff.sequence.history_len), bool(eff.sequence.get("time_delta", True)), mask, seed)
            out.append((key, phase, name, run_name, spec, eff))
    return out


@pytest.mark.parametrize("script,expected", [("batch1.sh", BATCH1), ("batch2.sh", BATCH2)])
def test_the_batch_runs_exactly_the_v1_list(script, expected):
    got = Counter(c[0] for c in cells(script))
    missing, extra = expected - got, got - expected
    assert not missing and not extra, f"{script}: missing {sorted(missing.elements(), key=str)}; extra {sorted(extra.elements(), key=str)}"


def test_v1_is_fifteen_runs_with_no_run_in_both_batches():
    b1, b2 = [c[0] for c in cells("batch1.sh")], [c[0] for c in cells("batch2.sh")]
    assert len(b1) == 6 and len(b2) == 9
    assert not set(b1) & set(b2)


@pytest.mark.parametrize("script", ["batch1.sh", "batch2.sh"])
def test_every_v1_run_uses_seed_42_the_strict_rule_and_the_same_files(script):
    for key, phase, name, run_name, spec, eff in cells(script):
        where = f"{script} {phase}/{name}:{run_name}"
        assert int(eff.training.seed) == 42, where
        if phase == "base":
            continue
        assert str(eff.sequence.history_time_order) == "strict", where
        assert (int(eff.data.train_start), int(eff.data.train_end)) == (1, 10), where
        assert (int(eff.data.val_start), int(eff.data.val_end)) == (4950, 4954), where
        assert (int(eff.eval.file_start), int(eff.eval.file_end)) == (8000, 8010), where


def test_every_spec_in_v1_has_its_own_output_folder_and_no_smoke_spec_is_a_batch_step():
    roots = []
    for script in ("batch1.sh", "batch2.sh"):
        for phase, name in steps(script):
            assert "smoke" not in name, f"{script}: {phase}/{name}"
            roots.append(str(OmegaConf.load(spec_path(phase, name)).get("output_root", "")))
    dup = [r for r, n in Counter(roots).items() if n > 1]
    assert not dup and all(roots), f"shared or empty output_root: {dup}"
