"""Bounded tests of the additive launcher; no GPU, S3 or bank-data execution."""
import csv
import importlib.util
import json
import os
from pathlib import Path
import sys
import threading
import time

from omegaconf import OmegaConf
import pytest

HERE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("parallel_v1_tested", HERE / "parallel_v1.py")
pv = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pv)


def test_partition_has_the_exact_six_plus_nine_cells():
    sets = []
    for stage, count in (("batch1", 6), ("batch2", 9)):
        names = [n for queues in pv.QUEUES[stage].values() for queue in queues for n in queue]
        assert len(names) == len(set(names)) == count
        sets.append(set(names))
    assert not sets[0] & sets[1]
    assert sets[0] | sets[1] == set(pv.CELLS)
    assert pv.QUEUES["batch1"]["four"][0] == ["A-H10", "A-GAP10-OFF"]
    assert pv.QUEUES["batch1"]["one"] == [["B-H10"]]


def test_every_derived_cell_has_identical_native_settings_and_analysis_identity(monkeypatch):
    # Check the bank configuration even when pytest runs inside the CPU fixture.
    # The sandbox transform is exercised separately below.
    monkeypatch.delenv("RUNBOOK_SANDBOX", raising=False)
    from analysis_runs import in_output_root
    roots = set()
    for name, (_, output_root, run_name, spec_file) in pv.CELLS.items():
        phase, derived, attempt = pv.single_cell(name, name + "-test")
        native = pv.native_runner(phase)
        original = OmegaConf.load(pv.ROOT / spec_file)
        expected = next(r for r in native._expand_runs(original)[1] if r[0] == run_name)
        got = native._expand_runs(derived)[1]
        assert got == [expected]
        assert derived.run_score == original.run_score
        assert derived.base_config == original.base_config
        assert derived.common_overrides == original.common_overrides
        assert derived.output_root == original.output_root == output_root
        base = OmegaConf.load(pv.ROOT / original.base_config)
        old_cfg = OmegaConf.merge(base, OmegaConf.from_dotlist(list(original.common_overrides) + expected[1]))
        new_cfg = OmegaConf.merge(base, OmegaConf.from_dotlist(list(derived.common_overrides) + got[0][1]))
        assert OmegaConf.to_container(new_cfg, resolve=True) == OmegaConf.to_container(old_cfg, resolve=True)
        assert new_cfg.training.seed == 42
        assert in_output_root(str(attempt), output_root)
        assert derived.results_csv == str(attempt / "results.csv")
        roots.add(str(attempt))
    assert len(roots) == 15


def test_cuda_masks_map_each_child_without_changing_the_parent(monkeypatch):
    monkeypatch.setattr(pv, "child_env", lambda: {"CUDA_VISIBLE_DEVICES": "GPU-a,GPU-b,GPU-c,GPU-d", "MARKER": "keep"})
    devices = pv.gpu_devices(4, {"CUDA_VISIBLE_DEVICES": "GPU-a,GPU-b,GPU-c,GPU-d"})
    assert devices == ["GPU-a", "GPU-b", "GPU-c", "GPU-d"]
    assert pv.gpu_devices(4, {"CUDA_VISIBLE_DEVICES": "3,1,7,2"}) == ["3", "1", "7", "2"]
    children = [pv.job_environment(d) for d in devices]
    assert [e["CUDA_VISIBLE_DEVICES"] for e in children] == devices
    assert all(e["MARKER"] == "keep" for e in children)
    assert pv.child_env()["CUDA_VISIBLE_DEVICES"] == "GPU-a,GPU-b,GPU-c,GPU-d"
    assert pv.gpu_devices(1, {}) == ["0"]
    with pytest.raises(ValueError):
        pv.gpu_devices(4, {"CUDA_VISIBLE_DEVICES": "0,1"})


def fake_plan(tmp_path, stage="batch2", pod="four"):
    out = tmp_path / "return"
    out.mkdir()
    jobs = {}
    for queues in pv.QUEUES[stage].values():
        for queue in queues:
            for name in queue:
                folder = out / "jobs" / name
                diag = folder / "attempts" / "first"
                diag.mkdir(parents=True)
                attempt = tmp_path / "ablations" / name / "first"
                current = {"attempt": str(attempt), "folder": str(diag), "tag": "first",
                           "spec": str(diag / "spec.json"), "phase": "phase4a"}
                jobs[name] = {"name": name, "folder": str(folder), "initial": current}
    return {"root": str(pv.ROOT), "folder": str(out), "stage": stage, "jobs": jobs,
            "queues": pv.QUEUES[stage], "preflight": str(tmp_path / "preflight"),
            "ledger": str(tmp_path / "runs" / "run_log.csv")}


def test_four_queues_overlap_but_a_queue_is_sequential_and_duplicate_invocation_stops(tmp_path, monkeypatch):
    plan = fake_plan(tmp_path)
    monkeypatch.delenv("CUDA_VISIBLE_DEVICES", raising=False)
    monkeypatch.setattr(pv, "job_environment", lambda device: {"CUDA_VISIBLE_DEVICES": device})
    entered, release = threading.Event(), threading.Event()
    mutex = threading.Lock()
    active, maximum, observations = set(), [0], []

    def execute(plan, job, current, env):
        device = env["CUDA_VISIBLE_DEVICES"]
        with mutex:
            assert device not in active
            active.add(device)
            maximum[0] = max(maximum[0], len(active))
            observations.append((job["name"], device))
            if len(active) == 4:
                entered.set()
        assert release.wait(5)
        with mutex:
            active.remove(device)
        return (1, 1) if job["name"] == "B-H15" else (0, 0)

    monkeypatch.setattr(pv, "execute_attempt", execute)
    result = []
    thread = threading.Thread(target=lambda: result.append(pv.run_pod(plan, "four")))
    thread.start()
    try:
        assert entered.wait(5)
        assert pv.run_pod(plan, "four") == 1  # no next cell launched on occupied device 3
        assert len(observations) == 4
    finally:
        release.set()
        thread.join(5)
    assert not thread.is_alive()
    assert maximum[0] == 4 and result == [1]
    assert observations[-1] == ("B-ALLPOS-H5", "3")
    assert pv.read_json(Path(plan["jobs"]["B-H15"]["folder"]) / "STATE.json")["status"] == "failed"
    # Completed cells skip; failed cells require explicit retry and do not auto-repeat.
    assert pv.run_pod(plan, "four") == 1
    assert len(observations) == 5


def test_actual_child_failure_preserves_diagnostics_and_filters_prediction_files(tmp_path, monkeypatch):
    plan = fake_plan(tmp_path)
    job = plan["jobs"]["A-H20"]
    current = job["initial"]
    root = tmp_path / "code"
    scripts = root / "YOUR_PACKAGE" / "phase4a" / "scripts"
    scripts.mkdir(parents=True)
    (scripts / "run_ablations.py").write_text('''import json, pathlib, sys
cfg = json.loads(pathlib.Path(sys.argv[2]).read_text())
p = pathlib.Path(cfg['attempt']); p.mkdir(parents=True)
(p / 'train.log').write_text('training failed with a retained diagnostic')
(p / 'best.ckpt').write_bytes(b'checkpoint')
(p / 'prediction.parquet').write_bytes(b'rows')
print('fake runner failure', flush=True)
sys.exit(7)
''')
    Path(current["spec"]).write_text(json.dumps(current))
    monkeypatch.setattr(pv, "ROOT", root)
    monkeypatch.setattr(pv.shutil, "which", lambda _: None)
    calls = []

    def collect(args, log, env=None):
        calls.append(list(map(str, args)))
        Path(log).write_text("collector failure\n")
        dest = Path(args[args.index("--out") + 1])
        (dest / "RETURN.txt").write_text("NOT ACCEPTED: failed native run\n")
        return 1

    monkeypatch.setattr(pv, "command", collect)
    assert pv.execute_attempt(plan, job, current, dict(os.environ, CUDA_VISIBLE_DEVICES="2")) == (7, 1)
    folder = Path(current["folder"])
    assert "fake runner failure" in (folder / "runner.log").read_text()
    assert (folder / "native" / "train.log").is_file()
    assert (folder / "native" / "host_rss_sweep.csv").is_file()
    assert not (folder / "native" / "best.ckpt").exists()
    assert not (folder / "native" / "prediction.parquet").exists()
    assert str(Path(job["folder"]) / "run_log.csv") in calls[0]


def test_interrupted_retry_recovers_old_attempt_before_new_attempt(tmp_path, monkeypatch):
    plan = fake_plan(tmp_path)
    job = plan["jobs"]["A-H20"]
    old = job["initial"]
    Path(old["attempt"]).mkdir(parents=True)
    Path(old["attempt"], "train.log").write_text("before interruption")
    pv.write_json(Path(job["folder"]) / "STATE.json", {"status": "running", "current": old, "attempts": [old]})
    events = []
    monkeypatch.setattr(pv, "job_environment", lambda device: {"CUDA_VISIBLE_DEVICES": device})

    def command(args, log, env=None):
        events.append("recover")
        Path(log).write_text("old attempt recovered")
        return 1  # an interrupted attempt may be incomplete; it remains evidence

    def new_attempt(job):
        events.append("new")
        assert Path(old["folder"], "native", "train.log").read_text() == "before interruption"
        current = dict(old, tag="second", folder=str(Path(job["folder"]) / "attempts" / "second"),
                       attempt=str(tmp_path / "ablations" / "second"))
        Path(current["folder"]).mkdir()
        return current

    monkeypatch.setattr(pv, "command", command)
    monkeypatch.setattr(pv, "new_attempt", new_attempt)
    monkeypatch.setattr(pv, "execute_attempt", lambda *args: (0, 0))
    assert pv.run_job(plan, "A-H20", "0") == 1
    assert not events
    assert pv.run_job(plan, "A-H20", "0", retry_failed=True) == 0
    assert events == ["recover", "new"]
    state = pv.read_json(Path(job["folder"]) / "STATE.json")
    assert len(state["attempts"]) == 2 and state["status"] == "completed"


def test_gap_control_waits_for_existing_comparator(tmp_path, monkeypatch):
    plan = fake_plan(tmp_path, stage="batch1")
    monkeypatch.setattr(pv, "job_environment", lambda device: {"CUDA_VISIBLE_DEVICES": device})
    monkeypatch.setattr(pv, "execute_attempt", lambda *args: pytest.fail("gap must not train without comparator"))
    assert pv.run_job(plan, "A-GAP10-OFF", "0") == 1
    state = pv.read_json(Path(plan["jobs"]["A-GAP10-OFF"]["folder"]) / "STATE.json")
    assert state["status"] == "blocked: A-H10 comparator"


def test_prepare_runs_existing_checks_and_batch2_postscore_once(tmp_path, monkeypatch):
    monkeypatch.setattr(pv, "ROOT", tmp_path)
    calls = []

    def command(args, log, env=None):
        args = list(map(str, args))
        calls.append(args)
        if args[0].endswith("preflight_pod.py"):
            pf = Path(args[args.index("--out-root") + 1]) / "stamp"
            pf.mkdir(parents=True)
            (pf / "SUMMARY.txt").write_text("RESULT PASS\n")
            (pf / "data_contract.json").write_text("{}")
            Path(log).write_text(f"PREFLIGHT_DIR={pf}\n")
        else:
            Path(log).write_text("ok\n")
        return 1 if "comparator" in args else 0

    def attempt(job):
        folder = Path(job["folder"])
        folder.mkdir(parents=True)
        return {"attempt": str(folder / "native"), "folder": str(folder), "tag": job["name"]}

    monkeypatch.setattr(pv, "command", command)
    monkeypatch.setattr(pv, "new_attempt", attempt)
    first = pv.prepare("batch1", "unit")
    assert len(calls) == 1 and "--skip-tests" not in calls[0]
    (first.parent / "SHARED_COMPARATOR.txt").write_text("A_H10_COMPARATOR=/shared/earlier_attempt\n")
    second = pv.prepare("batch2", "unit")
    assert len(calls) == 5
    assert "--skip-tests" in calls[2]
    assert calls[3][0].endswith("score_attempt.py") and "--split" not in calls[3]
    assert calls[4][1] == "comparator"  # its failure is record-only; the plan is still created
    assert len(pv.read_json(first)["jobs"]) == 6
    assert len(pv.read_json(second)["jobs"]) == 9
    with pytest.raises(FileExistsError):
        pv.prepare("batch2", "unit")
    assert len(calls) == 5


def test_finish_merges_job_ledgers_only_after_both_pods_finish(tmp_path, monkeypatch):
    import collect_returns as cr
    plan = fake_plan(tmp_path, stage="batch1")
    calls = []
    monkeypatch.setattr(pv, "command", lambda args, log, env=None: calls.append(list(map(str, args))) or 0)
    assert pv.finish(plan) == 1
    assert not calls and not Path(plan["ledger"]).exists()
    for name, job in plan["jobs"].items():
        current = job["initial"]
        Path(current["attempt"]).mkdir(parents=True)
        pv.write_json(Path(job["folder"]) / "STATE.json",
                      {"status": "completed", "current": current, "attempts": [current]})
        row = {c: "" for c in cr.EVIDENCE_COLS}
        row.update(attempt_dir=current["attempt"], attempt="first", run_name=name, status="ok", seed="42")
        job_ledger = str(Path(job["folder"]) / "run_log.csv")
        cr.append_ledger(job_ledger, [dict(row, status=cr.PROVISIONAL)], "stamp0")
        cr.append_ledger(job_ledger, [row], "stamp1")
    assert pv.finish(plan) == 0
    assert len(cr.current_rows(plan["ledger"])) == 6
    assert all(r["revision"] == "2" for r in cr.current_rows(plan["ledger"]).values())
    with open(plan["ledger"], newline="") as stream:
        assert len(list(csv.DictReader(stream))) == 12
    assert pv.finish(plan) == 0  # replaying old provisional revisions is not a new conflict
    assert calls[0][0].endswith("collect_returns.py") and "--no-ledger" in calls[0]
    assert calls[1][1] == "ledger-rows"


def test_retry_score_is_explicit_reuses_native_scorer_and_retains_prior_return(tmp_path, monkeypatch):
    import fcntl
    plan = fake_plan(tmp_path)
    out = Path(plan["folder"])
    (out / "POST_SCORE_EXIT.txt").write_text("1\n")
    (out / "post_score").mkdir()
    (out / "post_score" / "POST_SCORE.txt").write_text("original failed score")
    calls = []
    monkeypatch.setattr(pv, "command", lambda args, log, env=None: calls.append(list(map(str, args))) or 0)
    with open(out / "four.lock", "a+") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert pv.retry_score(plan) == 1
    assert not calls
    assert pv.retry_score(plan) == 0
    assert len(calls) == 1
    assert calls[0][0].endswith("score_attempt.py") and "--from-ledger" in calls[0]
    assert calls[0][-1].startswith(str(out / "post_score_retry_"))
    assert (out / "post_score" / "POST_SCORE.txt").read_text() == "original failed score"
    assert (out / "POST_SCORE_EXIT.txt").read_text().strip() == "0"
    assert pv.retry_score(plan) == 0 and len(calls) == 1


def test_sigterm_stops_the_native_process_group_and_retains_state(tmp_path):
    import subprocess
    plan = fake_plan(tmp_path)
    root = tmp_path / "fake_code"
    scripts = root / "YOUR_PACKAGE" / "phase4a" / "scripts"
    scripts.mkdir(parents=True)
    pidfile = tmp_path / "native_pid"
    childfile = tmp_path / "child_pid"
    (scripts / "run_ablations.py").write_text(
        "import os, pathlib, subprocess, sys, time\n"
        "child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(30)'])\n"
        f"pathlib.Path({str(childfile)!r}).write_text(str(child.pid))\n"
        f"pathlib.Path({str(pidfile)!r}).write_text(str(os.getpid()))\n"
        "time.sleep(30)\n")
    plan["root"] = str(root)
    plan["queues"] = {"one": [["A-H20"]]}
    planpath = tmp_path / "PLAN.json"
    pv.write_json(planpath, plan)
    bootstrap = (
        "import importlib.util, os, pathlib\n"
        f"s=importlib.util.spec_from_file_location('candidate', {str(HERE / 'parallel_v1.py')!r})\n"
        "m=importlib.util.module_from_spec(s); s.loader.exec_module(m)\n"
        f"m.ROOT=pathlib.Path({str(root)!r})\n"
        "m.child_env=lambda: dict(os.environ)\n"
        "m.shutil.which=lambda _: None\n"
        f"raise SystemExit(m.main(['run','--plan',{str(planpath)!r},'--pod','one']))\n")
    with open(tmp_path / "wrapper.log", "w") as stream:
        proc = subprocess.Popen([sys.executable, "-c", bootstrap], stdout=stream, stderr=subprocess.STDOUT)
        try:
            deadline = time.monotonic() + 5
            while not pidfile.exists() and time.monotonic() < deadline:
                time.sleep(0.02)
            assert pidfile.exists()
            native_pid = int(pidfile.read_text())
            proc.terminate()
            assert proc.wait(timeout=5) == 130
            with pytest.raises(ProcessLookupError):
                os.kill(native_pid, 0)
            # A killed descendant can briefly remain a zombie until init reaps it;
            # it must not be a live training process.
            child_stat = Path('/proc') / childfile.read_text() / 'stat'
            if child_stat.exists():
                assert child_stat.read_text().rsplit(')', 1)[1].split()[0] == 'Z'
            state = pv.read_json(Path(plan["jobs"]["A-H20"]["folder"]) / "STATE.json")
            assert state["status"] == "failed"
        finally:
            if proc.poll() is None:
                proc.kill()
                proc.wait()
            if pidfile.exists():
                try:
                    os.killpg(int(pidfile.read_text()), 9)
                except ProcessLookupError:
                    pass


@pytest.mark.parametrize("stage", ["batch1", "batch2"])
def test_one_gpu_continues_both_queues_without_repeating_completed_cells(tmp_path, monkeypatch, stage):
    plan = fake_plan(tmp_path, stage=stage)
    completed = {pv.QUEUES[stage]["four"][1][0], pv.QUEUES[stage]["one"][0][-1]}
    for name in completed:
        job = plan["jobs"][name]
        pv.write_json(Path(job["folder"]) / "STATE.json",
                      {"status": "completed", "current": job["initial"], "attempts": [job["initial"]]})
    monkeypatch.setenv("CUDA_VISIBLE_DEVICES", "GPU-permanent")
    monkeypatch.setattr(pv, "job_environment", lambda device: {"CUDA_VISIBLE_DEVICES": device})
    observed = []
    def execute(plan, job, current, env):
        observed.append((job["name"], env["CUDA_VISIBLE_DEVICES"]))
        return 0, 0
    def comparator(plan, env, log):
        state = pv.read_json(Path(plan["jobs"]["A-H10"]["folder"]) / "STATE.json")
        assert state["status"] == "completed"
        return 0
    monkeypatch.setattr(pv, "execute_attempt", execute)
    monkeypatch.setattr(pv, "check_comparator", comparator)
    assert pv.run_pod(plan, "all") == 0
    expected = [n for pod in ("four", "one") for queue in plan["queues"][pod] for n in queue if n not in completed]
    assert observed == [(name, "GPU-permanent") for name in expected]
    assert pv.run_pod(plan, "all") == 0  # same shared plan, nothing repeats
    assert len(observed) == len(expected)


@pytest.mark.parametrize("busy_pod", ["four", "one"])
def test_serial_continuation_excludes_both_active_pods_and_releases_partial_lock(tmp_path, monkeypatch, busy_pod):
    import fcntl
    plan = fake_plan(tmp_path)
    monkeypatch.setattr(pv, "_run_pod", lambda *args: pytest.fail("active pod must not overlap serial run"))
    with open(Path(plan["folder"]) / (busy_pod + ".lock"), "a+") as busy:
        fcntl.flock(busy, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert pv.run_pod(plan, "all") == 1
    # A failed acquisition must not leave the other queue locked.
    with open(Path(plan["folder"]) / "four.lock", "a+") as four:
        fcntl.flock(four, fcntl.LOCK_EX | fcntl.LOCK_NB)
    with open(Path(plan["folder"]) / "one.lock", "a+") as one:
        fcntl.flock(one, fcntl.LOCK_EX | fcntl.LOCK_NB)


def test_all_cli_routes_the_existing_plan_without_preparing_again(tmp_path, monkeypatch):
    plan = fake_plan(tmp_path)
    path = tmp_path / "plan.json"
    pv.write_json(path, plan)
    seen = []
    monkeypatch.setattr(pv.signal, "signal", lambda *args: None)
    monkeypatch.setattr(pv, "run_pod", lambda plan, pod, retry: seen.append((pod, retry)) or 0)
    assert pv.main(["run", "--plan", str(path), "--pod", "all", "--retry-failed"]) == 0
    assert seen == [("all", True)]


# ---------------------------------------------------------------- stage all: the 15 V1 cells in one plan (2026-10-12)
def test_all_stage_queues_hold_each_v1_cell_once_longest_first():
    queues = pv.QUEUES["all"]
    names = [n for pod in ("four", "one") for queue in queues[pod] for n in queue]
    assert len(names) == len(set(names)) == 15 and set(names) == set(pv.CELLS)
    assert queues["four"] == [["A-H15", "A-H00", "A-H05"], ["B-H20", "B-H15"],
                              ["A-H10", "A-GAP10-OFF", "REF-SINGLE", "B-H00"],
                              ["B-ALLPOS-H5", "B-H05", "B-H10", "A-MASK05-C", "A-GAP05-OFF"]]
    assert queues["one"] == [["A-H20"]]  # the longest cell, on the pod that stays
    serial = [n for pod in ("four", "one") for queue in queues[pod] for n in queue]  # run --pod all order
    assert serial.index("A-H10") < serial.index("A-GAP10-OFF")


def test_prepare_all_runs_only_the_full_preflight(tmp_path, monkeypatch):
    monkeypatch.setattr(pv, "ROOT", tmp_path)
    monkeypatch.delenv("RUNBOOK_SANDBOX", raising=False)
    calls = []

    def command(args, log, env=None):
        args = list(map(str, args))
        calls.append(args)
        pf = Path(args[args.index("--out-root") + 1]) / "stamp"
        pf.mkdir(parents=True)
        (pf / "SUMMARY.txt").write_text("RESULT PASS\n")
        (pf / "data_contract.json").write_text("{}")
        Path(log).write_text(f"PREFLIGHT_DIR={pf}\n")
        return 0

    def attempt(job):
        folder = Path(job["folder"])
        folder.mkdir(parents=True)
        return {"attempt": str(folder / "native"), "folder": str(folder), "tag": job["name"]}

    monkeypatch.setattr(pv, "command", command)
    monkeypatch.setattr(pv, "new_attempt", attempt)
    plan = pv.read_json(pv.prepare("all", "unit"))
    # No batch 1 ledger check and no step 2.0 at prepare: one call, the pre-flight with its tests.
    assert len(calls) == 1 and calls[0][0].endswith("preflight_pod.py") and "--skip-tests" not in calls[0]
    assert len(plan["jobs"]) == 15 and plan["stage"] == "all"
    assert plan["folder"] == str(tmp_path / "runs" / "returns" / "parallel_unit_all")


def test_finish_all_merges_the_ledgers_then_scores_the_validation_only_cells(tmp_path, monkeypatch):
    import collect_returns as cr
    plan = fake_plan(tmp_path, stage="all")
    out = Path(plan["folder"])
    calls = []

    def command(args, log, env=None):
        args = list(map(str, args))
        if args[0].endswith("score_attempt.py"):
            # The merged ledger holds every job's rows before step 2.0 reads it.
            assert len(cr.current_rows(plan["ledger"])) == 15
        calls.append(args)
        return rc[0] if args[0].endswith("score_attempt.py") else 0

    monkeypatch.setattr(pv, "command", command)
    for name, job in plan["jobs"].items():
        current = job["initial"]
        Path(current["attempt"]).mkdir(parents=True)
        pv.write_json(Path(job["folder"]) / "STATE.json",
                      {"status": "completed", "current": current, "attempts": [current]})
        row = {c: "" for c in cr.EVIDENCE_COLS}
        row.update(attempt_dir=current["attempt"], attempt="first", run_name=name, status="ok", seed="42")
        cr.append_ledger(str(Path(job["folder"]) / "run_log.csv"), [row], "stamp1")
    rc = [1]
    assert pv.finish(plan) == 1  # a failed step 2.0 is in the finish result, as in batch2.sh
    score = [c for c in calls if c[0].endswith("score_attempt.py")]
    assert len(score) == 1 and calls[0] == score[0]
    assert score[0][score[0].index("--from-ledger") + 1] == plan["ledger"]
    assert score[0][score[0].index("--preflight") + 1] == plan["preflight"]
    assert score[0][score[0].index("--return-dir") + 1] == str(out / "post_score")
    assert (out / "POST_SCORE_EXIT.txt").read_text().strip() == "1"
    (out / "post_score").mkdir()
    rc[0] = 0
    assert pv.finish(plan) == 0  # finish again: a new folder, the failed one is kept
    score = [c for c in calls if c[0].endswith("score_attempt.py")]
    assert len(score) == 2 and score[1][score[1].index("--return-dir") + 1].startswith(str(out / "post_score_retry_"))
    assert pv.finish(plan) == 0 and len([c for c in calls if c[0].endswith("score_attempt.py")]) == 3  # every finish


def test_finish_all_scores_a_validation_only_cell_completed_by_a_later_retry(tmp_path, monkeypatch):
    """R-L2: A-H05 fails at the first finish; the others are scored (exit 0). After --retry-failed completes it, the
    next finish scores again, so A-H05's checkpoint is scored on the evaluation files too."""
    import collect_returns as cr
    plan = fake_plan(tmp_path, stage="all")
    out = Path(plan["folder"])
    scored = []

    def command(args, log, env=None):
        args = list(map(str, args))
        if args[0].endswith("score_attempt.py"):
            # What the scorer would pick: the validation-only cells whose latest ledger row is ok.
            rows = cr.current_rows(plan["ledger"])
            scored.append(sorted({k[1] for k, r in rows.items() if r["status"] == "ok" and k[1] in
                                  ("A-H00", "A-H05", "A-GAP10-OFF")}))
        return 0

    monkeypatch.setattr(pv, "command", command)

    def settle(name, status, revision_stamp, retry=False):
        job = plan["jobs"][name]
        current = dict(job["initial"])
        if retry:  # --retry-failed makes a new attempt folder
            current["attempt"] = str(Path(current["attempt"]).parent / "retry")
        Path(current["attempt"]).mkdir(parents=True, exist_ok=True)
        pv.write_json(Path(job["folder"]) / "STATE.json",
                      {"status": "completed" if status == "ok" else "failed", "current": current,
                       "attempts": [current]})
        row = {c: "" for c in cr.EVIDENCE_COLS}
        row.update(attempt_dir=current["attempt"], attempt=Path(current["attempt"]).name, run_name=name,
                   status=status, seed="42")
        cr.append_ledger(str(Path(job["folder"]) / "run_log.csv"), [row], revision_stamp)

    for name in plan["jobs"]:
        settle(name, "failed" if name == "A-H05" else "ok", "s1")
    pv.finish(plan)
    assert scored == [["A-GAP10-OFF", "A-H00"]] and (out / "POST_SCORE_EXIT.txt").read_text().strip() == "0"
    settle("A-H05", "ok", "s2", retry=True)  # run --pod all --retry-failed completed it
    assert pv.finish(plan) == 0
    assert scored[-1] == ["A-GAP10-OFF", "A-H00", "A-H05"]


def test_batch_stages_do_not_score_at_finish(tmp_path, monkeypatch):
    plan = fake_plan(tmp_path, stage="batch2")
    for job in plan["jobs"].values():
        Path(job["initial"]["attempt"]).mkdir(parents=True)
        pv.write_json(Path(job["folder"]) / "STATE.json",
                      {"status": "completed", "current": job["initial"], "attempts": [job["initial"]]})
    calls = []
    monkeypatch.setattr(pv, "command", lambda args, log, env=None: calls.append(list(map(str, args))) or 0)
    pv.finish(plan)
    assert not [c for c in calls if c[0].endswith("score_attempt.py")]


def test_sandbox_moves_outputs_and_shrinks_the_cell_as_run_step_does(tmp_path, monkeypatch):
    import run_step
    monkeypatch.setenv("RUNBOOK_SANDBOX", str(tmp_path / "sb"))
    phase, derived, attempt = pv.single_cell("A-H10", "tag")
    assert attempt == (tmp_path / "sb" / "ablations/arch_a_flat/history_h10" / "tag").resolve()
    assert derived.output_root == str((tmp_path / "sb" / "ablations/arch_a_flat/history_h10").resolve())
    assert derived.results_csv == str(attempt / "results.csv")
    assert all(o in list(derived.common_overrides) for o in run_step.SANDBOX_OVERRIDES)
    assert "training.batch_size=32" in list(derived.axes.history.h10)  # 1024 / 32
    assert pv.runs_base() == (tmp_path / "sb").resolve()
    # run_step.py uses the same transform: the whole output_root under the sandbox.
    spec = OmegaConf.load(pv.ROOT / "YOUR_PACKAGE/phase4a/configs/ft_decisions_flat_h10.yaml")
    assert run_step.sandbox_spec(spec, str(tmp_path / "sb")) == str((tmp_path / "sb").resolve() / "ablations/arch_a_flat/history_h10")
    monkeypatch.delenv("RUNBOOK_SANDBOX")
    _, derived, attempt = pv.single_cell("A-H10", "tag")
    assert attempt == pv.ROOT / "ablations/arch_a_flat/history_h10" / "tag" and pv.runs_base() == pv.ROOT
    assert "training.max_epochs=1" not in list(derived.common_overrides)


def test_sighup_under_nohup_leaves_the_run_alone(tmp_path):
    """L4's finding: with SIGHUP ignored (nohup), a closed terminal must not stop the launcher or its runner."""
    import signal
    import subprocess
    plan = fake_plan(tmp_path)
    root = tmp_path / "fake_code"
    scripts = root / "YOUR_PACKAGE" / "phase4a" / "scripts"
    scripts.mkdir(parents=True)
    pidfile = tmp_path / "native_pid"
    (scripts / "run_ablations.py").write_text(
        "import os, pathlib, time\n"
        f"pathlib.Path({str(pidfile)!r}).write_text(str(os.getpid()))\n"
        "time.sleep(30)\n")
    plan["root"] = str(root)
    plan["queues"] = {"one": [["A-H20"]]}
    planpath = tmp_path / "PLAN.json"
    pv.write_json(planpath, plan)
    bootstrap = (
        "import importlib.util, os, pathlib, signal\n"
        "signal.signal(signal.SIGHUP, signal.SIG_IGN)\n"  # what nohup does before exec
        f"s=importlib.util.spec_from_file_location('candidate', {str(HERE / 'parallel_v1.py')!r})\n"
        "m=importlib.util.module_from_spec(s); s.loader.exec_module(m)\n"
        f"m.ROOT=pathlib.Path({str(root)!r})\n"
        "m.child_env=lambda: dict(os.environ)\n"
        "m.shutil.which=lambda _: None\n"
        f"raise SystemExit(m.main(['run','--plan',{str(planpath)!r},'--pod','one']))\n")
    with open(tmp_path / "wrapper.log", "w") as stream:
        proc = subprocess.Popen([sys.executable, "-c", bootstrap], stdout=stream, stderr=subprocess.STDOUT)
        try:
            deadline = time.monotonic() + 5
            while not pidfile.exists() and time.monotonic() < deadline:
                time.sleep(0.02)
            assert pidfile.exists()
            native_pid = int(pidfile.read_text())
            proc.send_signal(signal.SIGHUP)
            time.sleep(1)
            assert proc.poll() is None
            os.kill(native_pid, 0)  # the runner is still alive
            proc.terminate()  # SIGTERM still stops it
            assert proc.wait(timeout=5) == 130
        finally:
            if proc.poll() is None:
                proc.kill()
                proc.wait()
            if pidfile.exists():
                try:
                    os.killpg(int(pidfile.read_text()), 9)
                except ProcessLookupError:
                    pass


def test_prepare_passes_preflight_args_like_the_batch_scripts(tmp_path, monkeypatch):
    monkeypatch.setattr(pv, "ROOT", tmp_path)
    monkeypatch.delenv("RUNBOOK_SANDBOX", raising=False)
    monkeypatch.setattr(pv, "inherited_state_message", lambda: None)
    monkeypatch.setenv("PREFLIGHT_ARGS", "--skip-tests --allow-warn-only config")
    calls = []

    def command(args, log, env=None):
        args = list(map(str, args))
        calls.append(args)
        pf = Path(args[args.index("--out-root") + 1]) / "stamp"
        pf.mkdir(parents=True)
        (pf / "SUMMARY.txt").write_text("RESULT PASS\n")
        (pf / "data_contract.json").write_text("{}")
        Path(log).write_text(f"PREFLIGHT_DIR={pf}\n")
        return 0

    monkeypatch.setattr(pv, "command", command)
    monkeypatch.setattr(pv, "new_attempt", lambda job: {"attempt": "", "folder": "", "tag": job["name"]})
    pv.prepare("all", "unit")
    assert calls[0][-3:] == ["--skip-tests", "--allow-warn-only", "config"]


def test_sandbox_comparator_checks_against_the_reduced_spec(tmp_path, monkeypatch):
    """Scenario A on the fixture: in the sandbox A-H10 trains on the reduced copy, so the comparator must be checked
    against that copy (batch1.sh passes --spec-file the same way); without a sandbox nothing changes."""
    import run_step
    plan = fake_plan(tmp_path, stage="all")
    job = plan["jobs"]["A-H10"]
    pv.write_json(Path(job["folder"]) / "STATE.json", {"status": "completed", "current": job["initial"]})
    calls = []
    monkeypatch.setattr(pv, "command", lambda args, log, env=None: calls.append(list(map(str, args))) or 0)
    monkeypatch.setenv("RUNBOOK_SANDBOX", str(tmp_path / "sb"))
    assert pv.check_comparator(plan, {}, tmp_path / "c.log") == 0
    spec_file = Path(calls[0][calls[0].index("--spec-file") + 1])
    reduced = OmegaConf.load(spec_file)
    assert all(o in list(reduced.common_overrides) for o in run_step.SANDBOX_OVERRIDES)
    monkeypatch.delenv("RUNBOOK_SANDBOX")
    pv.check_comparator(plan, {}, tmp_path / "c.log")
    assert "--spec-file" not in calls[1]
