"""CPU usefulness screen (TRUST.md stage 3): XGBoost with and without one feature family.

Account-grouped K-fold inside the training files; the same folds for both arms, so every comparison is
paired. Outputs aggregates only: AP per fold, pooled out-of-fold AP, an account-cluster bootstrap interval
for the AP difference, the difference by month, and grouped permutation importance of the family.
The pass rule (PASS_RULE) is fixed here, before any bank run.
"""

import hashlib

import numpy as np
import pandas as pd

PASS_RULE = ("pooled out-of-fold AP(with) - AP(base) has a 95% account-bootstrap interval above 0; "
             "AND the paired fold difference is positive in at least K-1 of K folds; "
             "AND the difference is positive in at least two thirds of months that hold >= 50 frauds")

DEFAULT_PARAMS = {"tree_method": "hist", "max_depth": 6, "learning_rate": 0.1, "n_estimators": 300,
                  "subsample": 0.8, "colsample_bytree": 0.8, "min_child_weight": 1.0,
                  "max_cat_to_onehot": 1, "eval_metric": "aucpr", "n_jobs": 0}


def account_folds(accounts, k=5, salt="fe-cl"):
    """Deterministic account -> fold in [0, k); every row of one account lands in one fold."""
    u, inv = np.unique(np.asarray(accounts).astype(str), return_inverse=True)
    f = np.array([int(hashlib.sha256((salt + a).encode()).hexdigest()[:8], 16) % k for a in u])
    return f[inv]


def weighted_ap(y, s, w=None):
    """Average precision as sklearn defines it (step-wise, ties grouped), with optional row weights."""
    y = np.asarray(y, dtype=float)
    s = np.asarray(s, dtype=float)
    w = np.ones_like(y) if w is None else np.asarray(w, dtype=float)
    o = np.argsort(-s, kind="mergesort")
    return _ap_sorted(y[o], s[o], w[o])


def _ap_sorted(y, s, w):
    tp = np.cumsum(w * y)
    fp = np.cumsum(w * (1 - y))
    last = np.r_[np.flatnonzero(np.diff(s) != 0), len(s) - 1]
    tp, fp = tp[last], fp[last]
    if tp[-1] <= 0:
        return float("nan")
    prec = tp / np.maximum(tp + fp, 1e-300)
    rec = tp / tp[-1]
    return float(np.sum(np.diff(np.r_[0.0, rec]) * prec))


def bootstrap_delta(y, s_base, s_with, accounts, n_boot=500, seed=0):
    """Account-cluster bootstrap (Poisson(1) weight per account) of AP(with) - AP(base). Each arm is
    sorted once; a replicate only reweights, so 500 replicates are cheap on millions of rows."""
    rng = np.random.default_rng(seed)
    _, inv = np.unique(np.asarray(accounts).astype(str), return_inverse=True)
    y = np.asarray(y, dtype=float)
    ob, ow = np.argsort(-s_base, kind="mergesort"), np.argsort(-s_with, kind="mergesort")
    deltas = np.empty(n_boot)
    for r in range(n_boot):
        wa = rng.poisson(1.0, inv.max() + 1).astype(float)[inv]
        deltas[r] = (_ap_sorted(y[ow], s_with[ow], wa[ow]) - _ap_sorted(y[ob], s_base[ob], wa[ob]))
    return np.nanpercentile(deltas, [2.5, 97.5]).tolist(), float(np.nanstd(deltas))


def _design(df, cols, cat_cols):
    X = df[cols].copy()
    for c in cols:
        if c in cat_cols:
            X[c] = X[c].astype("category")
        else:
            X[c] = pd.to_numeric(X[c], errors="coerce")
    return X


def _fit_predict(X_tr, y_tr, X_te, params, seed):
    import xgboost as xgb
    m = xgb.XGBClassifier(**params, enable_categorical=True, random_state=seed)
    m.fit(X_tr, y_tr)
    return m, m.predict_proba(X_te)[:, 1]


def run_screen(df, base_cols, family_cols, cat_cols=(), label="frd_tag",
               account="Nmap_account_reference_xid", time="transaction_dttm", k=5, seed=42,
               params=None, n_boot=500, min_month_frauds=50, permute=True, train_neg_rate=1.0, by_group=None):
    """Paired screen of `family_cols` on top of `base_cols`. Returns a JSON-ready dict of aggregates.

    `train_neg_rate` < 1 keeps that share of non-fraud rows in each training part only (features are already
    computed on the full stream, so this is target sampling after feature replay); held-out folds keep
    every row, so AP is at natural prevalence. `by_group` (a column name) adds the pooled AP difference per
    value of that column, for example the headroom code (TRUST.md stage 2, decline split)."""
    params = {**DEFAULT_PARAMS, **(params or {})}
    cat_cols = set(cat_cols)
    y = (pd.to_numeric(df[label], errors="coerce").to_numpy() == 1).astype(int)
    acc = df[account].astype(str).to_numpy()
    fold = account_folds(acc, k)
    Xb = _design(df, list(base_cols), cat_cols)
    Xw = _design(df, list(base_cols) + list(family_cols), cat_cols)
    oof_b, oof_w = np.full(len(df), np.nan), np.full(len(df), np.nan)
    per_fold, perm = [], []
    rng = np.random.default_rng(seed)
    keep_neg = np.random.default_rng(seed + 1).random(len(df))
    for f in range(k):
        te = fold == f
        tr = ~te & ((y == 1) | (keep_neg < train_neg_rate))
        if y[te].sum() == 0 or y[tr].sum() == 0:
            continue
        _, oof_b[te] = _fit_predict(Xb[tr], y[tr], Xb[te], params, seed)
        m_w, oof_w[te] = _fit_predict(Xw[tr], y[tr], Xw[te], params, seed)
        ap_b, ap_w = weighted_ap(y[te], oof_b[te]), weighted_ap(y[te], oof_w[te])
        per_fold.append({"fold": f, "rows": int(te.sum()), "frauds": int(y[te].sum()),
                         "ap_base": ap_b, "ap_with": ap_w, "delta": ap_w - ap_b})
        if permute:  # family permuted jointly (rows shuffled together) on the held-out fold
            Xp = Xw[te].copy()
            idx = rng.permutation(len(Xp))
            for c in family_cols:
                Xp[c] = Xp[c].to_numpy()[idx]
                if c in cat_cols:
                    Xp[c] = pd.Categorical(Xp[c], categories=Xw[c].cat.categories)
            perm.append(ap_w - weighted_ap(y[te], m_w.predict_proba(Xp)[:, 1]))
    ok = ~np.isnan(oof_b)
    pooled_b, pooled_w = weighted_ap(y[ok], oof_b[ok]), weighted_ap(y[ok], oof_w[ok])
    ci, se = bootstrap_delta(y[ok], oof_b[ok], oof_w[ok], acc[ok], n_boot, seed)
    month = pd.to_datetime(df[time]).dt.to_period("M").astype(str).to_numpy()
    by_month = []
    for mth in sorted(set(month[ok])):
        m = ok & (month == mth)
        if y[m].sum() == 0:
            continue
        by_month.append({"month": mth, "rows": int(m.sum()), "frauds": int(y[m].sum()),
                         "ap_base": weighted_ap(y[m], oof_b[m]), "ap_with": weighted_ap(y[m], oof_w[m])})
        by_month[-1]["delta"] = by_month[-1]["ap_with"] - by_month[-1]["ap_base"]
    groups = []
    if by_group is not None:
        gv = df[by_group].astype(object).fillna("<missing>").astype(str).to_numpy()
        for v in sorted(set(gv[ok])):
            m = ok & (gv == v)
            if y[m].sum() == 0:
                continue
            groups.append({"group": v, "rows": int(m.sum()), "frauds": int(y[m].sum()),
                           "delta": weighted_ap(y[m], oof_w[m]) - weighted_ap(y[m], oof_b[m])})
    big = [r for r in by_month if r["frauds"] >= min_month_frauds]
    folds_pos = sum(r["delta"] > 0 for r in per_fold)
    months_ok = (not big) or (sum(r["delta"] > 0 for r in big) >= (2 / 3) * len(big))
    passed = bool(ci[0] > 0 and folds_pos >= len(per_fold) - 1 and months_ok)
    return {"family": list(family_cols), "base": list(base_cols), "k": k, "seed": seed, "params": params,
            "train_neg_rate": train_neg_rate,
            "rows": int(ok.sum()), "frauds": int(y[ok].sum()), "accounts": int(len(set(acc[ok]))),
            "pooled_ap_base": pooled_b, "pooled_ap_with": pooled_w, "pooled_delta": pooled_w - pooled_b,
            "delta_ci95_account_bootstrap": ci, "delta_bootstrap_se": se, "n_boot": n_boot,
            "per_fold": per_fold, "folds_positive": folds_pos, "by_month": by_month,
            "months_rule_ok": bool(months_ok), "by_group": {"column": by_group, "rows": groups},
            "permutation_ap_drop_mean": float(np.mean(perm)) if perm else None,
            "pass_rule": PASS_RULE, "passed": passed}


def base_refit_aps(df, base_cols, cat_cols=(), label="frd_tag", account="Nmap_account_reference_xid", k=5,
                   seed=42, model_seeds=(43, 44), params=None, train_neg_rate=1.0):
    """Pooled out-of-fold AP of the base arm refitted with other XGBoost seeds, on the same folds and the
    same training rows as `run_screen(seed=seed)`. Only the model's random state changes."""
    params = {**DEFAULT_PARAMS, **(params or {})}
    y = (pd.to_numeric(df[label], errors="coerce").to_numpy() == 1).astype(int)
    fold = account_folds(df[account].astype(str).to_numpy(), k)
    keep_neg = np.random.default_rng(seed + 1).random(len(df))
    Xb = _design(df, list(base_cols), set(cat_cols))
    out = {}
    for ms in model_seeds:
        oof = np.full(len(df), np.nan)
        for f in range(k):
            te = fold == f
            tr = ~te & ((y == 1) | (keep_neg < train_neg_rate))
            if y[te].sum() == 0 or y[tr].sum() == 0:
                continue
            _, oof[te] = _fit_predict(Xb[tr], y[tr], Xb[te], params, ms)
        ok = ~np.isnan(oof)
        out[int(ms)] = weighted_ap(y[ok], oof[ok])
    return out


FINAL_RULE = ("PASS_RULE with its threshold raised from 0 to the noise floor: the 95% interval's lower end must "
              "exceed max(0, floor), floor = the larger of |null_noise pooled delta| and the largest pairwise "
              "difference in pooled base-arm AP across XGBoost seeds (refit spread)")


def noise_floor(null_result, base_aps):
    """The floor of FINAL_RULE from the null family's result and the base arm's AP per model seed."""
    aps = list(base_aps.values())
    spread = max((abs(a - b) for i, a in enumerate(aps) for b in aps[i + 1:]), default=0.0)
    return {"null_abs_delta": abs(null_result["pooled_delta"]), "refit_spread": spread,
            "floor": max(0.0, abs(null_result["pooled_delta"]), spread)}


def final_decision(result, floor):
    """True when the family passes PASS_RULE and its interval clears the floor."""
    return bool(result.get("passed") and result["delta_ci95_account_bootstrap"][0] > floor)
