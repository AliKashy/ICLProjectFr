"""V2 data look: one CPU, read-only, counts-only pass over the pod, the environment, the storage and the bank
files, before anything else in runbook/v2/RUNBOOK.md runs. 2026-10-20 (the owner, 2026-10-20: "if u wanna see
what the data looks like or anything, u make a script, i upload, run it, give u results").

It answers, with counts, types and names only, the facts every later step assumes (the end-to-end review record of 2026-10-20,
2026-10-20-end-to-end/ASSUMPTIONS.md, items marked "data look"):
  pod          memory, CPUs, disk, the GPU's name and memory (nvidia-smi only; nothing runs on the GPU)
  environment  the python, package versions, where fraud/ and YOUR_PACKAGE/ import from
  package      SHA-256 of every V2 package file and of the V1 model-path files (what the pod actually runs)
  credentials  that the credentials file exists and has the three key names (names only, never values)
  listings     every object under both data folders; which file numbers exist; EVAL_LAST, EVAL_END, TRAIN_HAS_8000
  storage      the benchmark file (both spellings), the V1 artifacts (manifest fields, vocabulary sizes), whether
               version 20261019 exists, the prediction folders (names and sizes), the bucket's top-level folders
  schema       every requested file's parquet footer: rows, column names and types, per-column null counts and
               byte sizes (no rows are read); files grouped by identical schema
  profile      one file per population (training 1, validation 4950, downstream-training 5001, DEV_OOT 8000; the
               evaluation files after 8010, which become SELECT, DS_SELECT and FINAL, are only counted in
               "months", as the inventory counts them), rows read in column batches: identity, time, label,
               month, hour and clock-change profiles, every predictor's values (codes against the V1
               vocabularies), postal-code formats, advice rows, limit fields, and a counts-only profile of every
               other column
  months       every requested file: rows, frauds, accounts, min and max time, rows and frauds per month,
               sub-second stamps, label values; cumulative June frauds after file 8010

Nothing is written to S3. Nothing trains. No GPU is used. The output folder holds aggregates only: no account or
transaction identifier, no postal code, no row-level value. No minimum or maximum of any column is written (each is one
row's value); amounts, balances, limits and time gaps are described by counts and by quantiles from p1 to p99. Column
*values* are printed only for code columns: codes of at most 4 characters, never for an identifier-like column (by name,
or any whole-number column with 7 or more digits), at most 30 codes per column with the rest pooled, and codes with fewer
than 10 rows pooled. The one exception is the event time: a file's first and last transaction time is a file-level fact
(the stage 1 pre-flight already returned it) and is written to the second. The folder's own privacy check
(privacy_check.json) scans every file written; SUMMARY.txt and STATUS.txt say when it flagged anything.

Usage (from the project root, with the V1 venv's python):
    $PY -m YOUR_PACKAGE.v2.scripts.data_look --cred-path $CRED --out runs/v2/data_look
    $PY -m YOUR_PACKAGE.v2.scripts.data_look --cred-path $CRED --out runs/v2/data_look --only pod,environment,package
    $PY -m YOUR_PACKAGE.v2.scripts.data_look --dry-run --out runs/v2/data_look
It prints the folder it wrote; send that folder back.
"""
import argparse
import datetime as _dt
import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import traceback
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from fraud.data.s3_utils import strip_scheme  # noqa: E402
from YOUR_PACKAGE.v2.storage import thin_read_filesystem  # noqa: E402
from YOUR_PACKAGE.scoring._prediction_utils import id_kind, validate_ids  # noqa: E402

SECTIONS = ("pod", "environment", "package", "credentials", "listings", "storage", "schema", "profile", "months")
ID, ACCOUNT, TIME, LABEL = "fi_transaction_id", "Nmap_account_reference_xid", "transaction_dttm", "frd_tag"
AMOUNT, ADVICE, TYPE, CATEGORY = "transaction_amt", "transaction_advice_xcd", "transaction_type_xcd", "transaction_category_xcd"
PRESENT, ATTEND = "cardholder_present_xflg", "pos_terminal_attend_xflg"
MERCH_POSTAL, HOME_POSTAL, MERCH_STATE = "merchant_postal_xcd", "cprsrvc__pisinfo_cardholder_postal_xcd", "merchant_state_xcd"
MERCH_LIMIT, CASH_LIMIT, BALANCE, OTHER_LIMIT = ("remain_day_merchandise_lmt_amt", "available_daily_cash_limit_amt",
                                                 "total_available_balance_amt", "avlble_merch_day_cash_lmt_amt")
PREDICTORS_CSV = ROOT / "YOUR_PACKAGE/v2/configs/predictors_nomonth.csv"
V1_PREDICTORS_CSV = ROOT / "fraud/configs/predictors.csv"

DEFAULT_TRAIN = "s3://DATA_BUCKET/tfm_raw_data"
DEFAULT_EVAL = "s3://DATA_BUCKET/tfm_EVAL_raw_data"
DEFAULT_ARTIFACTS = "s3://ARTIFACT_BUCKET/YOUR_ID/tabular_fraud/artifacts"
DEFAULT_REFERENCE_ARTIFACTS = "s3://ARTIFACT_BUCKET/REFERENCE_ID/tabular_fraud/artifacts"  # the reference author's (fraud/configs)
DEFAULT_PREDICTIONS = "s3://ARTIFACT_BUCKET/YOUR_ID/tabular_fraud/predictions"
# Two owner documents spell the benchmark folder differently; both are probed (runbook/v2/RUNBOOK.md).
DEFAULT_BENCH = ["s3://DATA_BUCKET/tfm_v22b_dropcpr_falcondecline/eval/cross-file-8000-8200-seed-42_1.parquet",
                 "s3://DATA_BUCKET/tfm_v22b_dropcpr_falcondeline/eval/cross-file-8000-8200-seed-42_1.parquet"]
DEFAULT_TRAIN_RANGES = ["1:100", "4950:4954", "5001:5010", "8000"]
NOMONTH_ARTIFACT_VERSION = "20261019"
TRAIN_MONTHS = ["2024-10", "2024-11", "2024-12", "2025-01", "2025-02", "2025-03", "2025-04", "2025-05"]
EVAL_MONTHS = ["2025-05", "2025-06"]
JUNE_TARGETS = (("SELECT", 2000), ("DS_SELECT", 2000), ("FINAL", 3000))  # DECISIONS section 3, select_splits
CLOCK_CHANGES = ("2024-11-03", "2025-03-09")  # US clock changes inside the data's months
PACKAGE_DIRS = ("YOUR_PACKAGE/v2", "runbook/v2", "runbook/2026-10-19")
PACKAGES = ("pandas", "numpy", "pyarrow", "torch", "pytorch-lightning", "torchmetrics", "omegaconf", "s3fs", "fsspec",
            "scikit-learn", "xgboost", "joblib", "PyYAML", "boto3", "botocore", "aiobotocore")
CODE_DISTINCT, CODE_LENGTH = 12, 4  # a column's values are printed only under this rule (and never for ids)
SCREEN_GB, DOWNSTREAM_GB, DISK_NEED_GB = 30, 32, 15  # USAGE_CONSUMERS' estimates and the exports' footprint, read against pod.json
SELECTION_POOL_START = 8011  # evaluation files after DEV_OOT become SELECT, DS_SELECT and FINAL: counted, never profiled by default
CODE_TOP, MIN_CODE_ROWS, MIN_VALUE_ROWS = 30, 10, 50  # codes printed per column; a code with fewer rows is pooled; rows a per-code amount statistic needs
ID_DIGITS = 7  # a whole-number column whose largest value has this many digits is treated as an identifier whatever its name
LABEL_OK = {"0", "1", "0.0", "1.0", "True", "False", "true", "false"}
# By name: whole tokens between underscores, the _xid/_id suffixes, and stems the bank's concatenated names carry
# (outletzipcd, ddaacctkey, outletlatitudenum, currtermid, achearlypayername). An over-match only hides a harmless
# column's quantiles and values; an under-match would print an identifier, so the list is wide.
IDENTIFIER = re.compile(r"(^|_)(x?id|acct|account|postal|zip|phone|ssn|tax|dob|birth|name|nm|addr|address|email|card|pan"
                        r"|token|tokn|ip|plastic|key|nbr|num|no|lat|lon|lng|geo|cif|imei|hash|device|term|mobile|tel)(_|$)"
                        r"|_xid$|_id$|zip|postal|pstl|latitude|longitude|phone|ssn|imei|acctkey|custkey|termid|payername|birth"
                        r"|email|street", re.I)
URL_OR_DIGITS = re.compile(r"[A-Za-z][A-Za-z0-9+.-]*://\S+|\d{7,}")
NAME_HINTS = {
    "decline_or_response": r"decl|resp|rspn|reason|rsn|action|actn|dispos|approv|result|rslt",
    "currency": r"curr|ccy|iso_cur",
    "label_or_case": r"frd|fraud|case|report|rprt|confirm|cnfrm|label|tag|dispute|chrgbk|chargeback",
    "date_or_time": r"_dt$|_dttm|_date|_ts$|time|_tm$|tmstmp",
    "profile": r"cprsrvc|pisinfo|profile|open_dt|status|stat",
    "card_key": r"card|pan|token|tokn|primary_acct|plastic",
    "counter": r"atc|cntr|counter|count|_cnt",
    "device": r"device|dvc|ip_|_ip|browser|brwsr|agent",
    "age": r"(^|_)age(_|$)|dob|birth",
    "score": r"scr|score",
    "location": r"postal|zip|state|cntry|country|city|lat|lon|geo",
    "limit_or_balance": r"lmt|limit|bal",
}
US_STATES = set("AL AK AZ AR CA CO CT DE FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND OH OK "
                "OR PA RI SC SD TN TX UT VT VA WA WV WI WY DC PR VI GU AS MP".split())
PART = re.compile(r"part_(\d+)\.parquet$")


# --------------------------------------------------------------------------------------------------------------- #
# Small helpers
# --------------------------------------------------------------------------------------------------------------- #
def utc_stamp():
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def utc_now():
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def is_remote(path):
    return str(path).startswith(("s3://", "s3a://"))


def gb(n_bytes):
    return None if n_bytes is None else round(n_bytes / 1e9, 2)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def redact(text):
    """Exception text without URLs (the endpoint from the credentials file) or long digit runs (an identifier)."""
    return URL_OR_DIGITS.sub(lambda m: "<url>" if "://" in m.group(0) else "<digits>", str(text))


def fraud_mask(label):
    """True where the label says fraud, whatever its storage: 1, 1.0, True or the text "1". The stored type is reported
    separately; no count here may silently become zero for a text label."""
    numeric = pd.to_numeric(label, errors="coerce").eq(1)
    text = label.map(lambda v: isinstance(v, str) and v.strip().lower() in ("1", "1.0", "true"))
    return (numeric | text).astype(bool)


def parse_ranges(values):
    numbers = set()
    for value in values or []:
        sides = str(value).split(":")
        start, end = int(sides[0]), int(sides[-1])
        if start < 1 or end < start:
            raise ValueError(f"bad range {value!r}: N or START:END with 1 <= START <= END")
        numbers.update(range(start, end + 1))
    return sorted(numbers)


def part_number(path):
    m = PART.search(str(path))
    return int(m.group(1)) if m else None


def jsonable(value):
    if isinstance(value, dict):
        return {str(k): jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [jsonable(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return None if not np.isfinite(value) else float(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if isinstance(value, (pd.Timestamp, _dt.datetime, _dt.date)):
        return value.isoformat()
    if isinstance(value, Path):
        return str(value)
    return value


class Store:
    """The fs-aware reader: S3 through the V1 helper, or local paths."""

    def __init__(self, cred_path):
        self.cred_path = cred_path
        self.fs = thin_read_filesystem(cred_path)  # a 1 MiB read-ahead block: thin column reads stay thin

    def _fs_for(self, path):
        if is_remote(path):
            if self.fs is None:
                raise ValueError(f"{path} is on S3; pass --cred-path")
            return self.fs
        return None

    def exists(self, path):
        fs = self._fs_for(path)
        return fs.exists(strip_scheme(path)) if fs is not None else Path(path).exists()

    def listing(self, base):
        """Every object under a prefix: path, size, last modified. Names only; nothing is opened."""
        fs = self._fs_for(base)
        rows = []
        if fs is not None:
            found = fs.find(strip_scheme(base), detail=True)
            if not isinstance(found, dict):
                found = {name: fs.info(name) for name in found}
            for name, info in sorted(found.items()):
                if info.get("type") == "directory":
                    continue
                row = {"path": "s3://" + strip_scheme(name), "size_bytes": int(info.get("size", info.get("Size", 0)) or 0)}
                if info.get("LastModified") is not None:
                    row["last_modified"] = str(info["LastModified"])
                rows.append(row)
            return rows
        root = Path(base).expanduser()
        if not root.is_dir():
            raise FileNotFoundError(f"{root} is not a folder")
        for p in sorted(root.rglob("*")):
            if p.is_file():
                rows.append({"path": str(p), "size_bytes": p.stat().st_size,
                             "last_modified": _dt.datetime.fromtimestamp(p.stat().st_mtime, _dt.timezone.utc).isoformat()})
        return rows

    def ls(self, base):
        """Immediate children of a prefix (names only)."""
        fs = self._fs_for(base)
        if fs is not None:
            return sorted("s3://" + strip_scheme(e["name"] if isinstance(e, dict) else e)
                          for e in fs.ls(strip_scheme(base), detail=True))
        return sorted(str(p) for p in Path(base).iterdir())

    def parquet(self, path):
        return pq.ParquetFile(strip_scheme(path), filesystem=self._fs_for(path))

    def open_text(self, path):
        fs = self._fs_for(path)
        return fs.open(strip_scheme(path), "r") if fs is not None else open(path, "r", encoding="utf-8")


def part_paths(base, numbers):
    base = str(base).rstrip("/")
    return {n: f"{base}/part_{n}.parquet" for n in numbers}


def normal(path):
    return "s3://" + strip_scheme(path) if is_remote(path) else str(Path(path))


# --------------------------------------------------------------------------------------------------------------- #
# pod, environment, package, credentials
# --------------------------------------------------------------------------------------------------------------- #
def read_first(*paths):
    for p in paths:
        try:
            return Path(p).read_text().strip()
        except OSError:
            continue
    return None


def pod_facts(root):
    out = {"platform": platform.platform(), "python": sys.version.split()[0], "utc": utc_now()}
    mem = {}
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            key, _, rest = line.partition(":")
            if key in ("MemTotal", "MemAvailable", "SwapTotal"):
                mem[key + "_gb"] = round(int(rest.split()[0]) * 1024 / 1e9, 2)
    except OSError:
        pass
    out["memory"] = mem
    limit = read_first("/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory/memory.limit_in_bytes")
    # cgroup v1 reports about 2**63 for "no limit"; cgroup v2 says "max"
    out["cgroup_memory_limit_gb"] = None if limit in (None, "max") or not limit.isdigit() or int(limit) >= 2 ** 62 else gb(int(limit))
    cpu_max = read_first("/sys/fs/cgroup/cpu.max")
    if cpu_max and cpu_max.split()[0].isdigit():
        quota, period = cpu_max.split()[:2]
        out["cgroup_cpu_limit"] = round(int(quota) / int(period), 2)
    else:
        quota, period = read_first("/sys/fs/cgroup/cpu/cpu.cfs_quota_us"), read_first("/sys/fs/cgroup/cpu/cpu.cfs_period_us")
        out["cgroup_cpu_limit"] = round(int(quota) / int(period), 2) if quota and period and int(quota) > 0 else None
    out["cpu_count"] = os.cpu_count()
    try:
        out["cpu_affinity"] = len(os.sched_getaffinity(0))
    except (AttributeError, OSError):
        out["cpu_affinity"] = None
    disks = {}
    for name, path in (("project_root", root), ("home", Path.home()), ("temp", tempfile.gettempdir())):
        try:
            u = shutil.disk_usage(path)
            disks[name] = {"path": str(path), "total_gb": gb(u.total), "free_gb": gb(u.free)}
        except OSError as exc:
            disks[name] = {"path": str(path), "error": redact(str(exc))}
    out["disk"] = disks
    runs = Path(root) / "runs"
    if runs.is_dir():
        total, files = 0, 0
        for dirpath, _, names in os.walk(runs):
            for n in names:
                try:
                    total += os.stat(os.path.join(dirpath, n)).st_size
                    files += 1
                except OSError:
                    pass
        out["runs_folder"] = {"path": str(runs), "files": files, "size_gb": gb(total)}
    try:
        r = subprocess.run(["nvidia-smi", "--query-gpu=index,name,memory.total,memory.used,driver_version",
                            "--format=csv,noheader"], capture_output=True, text=True, timeout=30)
        out["gpu"] = {"nvidia_smi": r.stdout.strip().splitlines(), "returncode": r.returncode,
                      "stderr": r.stderr.strip()[:300]}
    except (OSError, subprocess.SubprocessError) as exc:
        out["gpu"] = {"nvidia_smi": None, "error": redact(str(exc))}
    return out


def environment_facts(root):
    from importlib import metadata
    out = {"executable": sys.executable, "prefix": sys.prefix, "python": sys.version, "cwd": os.getcwd(),
           "project_root": str(root), "packages": {}}
    modules = {"pytorch-lightning": "pytorch_lightning", "scikit-learn": "sklearn", "PyYAML": "yaml"}
    for name in PACKAGES:
        try:
            out["packages"][name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            # a differently named wheel (xgboost-cpu ships the xgboost module): ask the module itself
            try:
                out["packages"][name] = getattr(__import__(modules.get(name, name.replace("-", "_"))), "__version__", "installed")
            except Exception:  # noqa: BLE001
                out["packages"][name] = None
    for mod in ("fraud", "YOUR_PACKAGE"):
        try:
            m = __import__(mod)
            path = Path(getattr(m, "__file__", "") or "").resolve()
            out[mod] = {"file": str(path), "under_project_root": str(root) in str(path)}
        except Exception as exc:  # noqa: BLE001 - recorded, not raised
            out[mod] = {"error": redact(repr(exc))}
    try:
        import torch
        out["torch"] = {"version": torch.__version__, "cuda_build": torch.version.cuda,
                        "note": "torch.cuda was not initialised; no GPU test here"}
    except Exception as exc:  # noqa: BLE001
        out["torch"] = {"error": redact(repr(exc))}
    return out


def package_facts(root):
    from YOUR_PACKAGE.v2.scripts.check_v1_source import MODEL_PATH_FILES
    files = {}
    for rel in PACKAGE_DIRS:
        folder = Path(root) / rel
        if folder.is_dir():
            for p in sorted(folder.rglob("*")):
                if p.is_file() and "__pycache__" not in p.parts:
                    files[p.relative_to(root).as_posix()] = sha256_file(p)
    for rel in MODEL_PATH_FILES + ["fraud/configs/predictors.csv", "YOUR_PACKAGE/v2/configs/predictors_nomonth.csv"]:
        p = Path(root) / rel
        files[rel] = sha256_file(p) if p.is_file() else None
    digest = hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest()
    return {"root": str(root), "files": files, "missing": sorted(k for k, v in files.items() if v is None),
            "combined_sha256": digest, "count": len(files)}


def credentials_facts(cred_path):
    out = {"path": cred_path, "exists": False, "readable": False, "keys": None, "missing_keys": None}
    if not cred_path:
        return out
    p = Path(cred_path)
    out["exists"] = p.is_file()
    if not out["exists"]:
        return out
    try:
        import yaml
        with open(p, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        out["readable"] = True
        keys = sorted(data.keys()) if isinstance(data, dict) else []
        out["keys"] = keys  # names only
        out["missing_keys"] = sorted({"AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_ENDPOINT_URL"} - set(keys))
    except Exception as exc:  # noqa: BLE001 - the class only: a decode error's message carries the file's bytes
        out["error"] = type(exc).__name__
    return out


# --------------------------------------------------------------------------------------------------------------- #
# listings and storage
# --------------------------------------------------------------------------------------------------------------- #
def listings_facts(store, train_base, eval_base, train_ranges, eval_end):
    out = {"bases": {"train": train_base, "eval": eval_base}, "folders": {}}
    numbers = {}
    for name, base in out["bases"].items():
        try:
            rows = store.listing(base)
        except Exception as exc:  # noqa: BLE001 - one folder's failure keeps the other folder's facts
            out["folders"][name] = {"error": redact(repr(exc)), "objects": 0, "total_gb": None, "part_files": 0, "first": None,
                                    "last": None, "gaps_between_first_and_last": [], "other_objects": [], "other_objects_count": 0,
                                    "listing": []}
            numbers[name] = set()
            continue
        nums = sorted(n for n in (part_number(r["path"]) for r in rows) if n is not None)
        numbers[name] = set(nums)
        other = [r["path"] for r in rows if part_number(r["path"]) is None]
        out["folders"][name] = {"objects": len(rows), "total_gb": gb(sum(r["size_bytes"] for r in rows)),
                                "part_files": len(nums), "first": nums[0] if nums else None, "last": nums[-1] if nums else None,
                                "gaps_between_first_and_last": sorted(set(range(nums[0], nums[-1] + 1)) - set(nums)) if nums else [],
                                "other_objects": other[:50], "other_objects_count": len(other), "listing": rows}
    wanted = parse_ranges([r for r in train_ranges if str(r) != "8000"])
    out["train"] = {"requested_ranges": list(train_ranges),
                    "present": [n for n in wanted if n in numbers["train"]],
                    "missing": [n for n in wanted if n not in numbers["train"]],
                    "TRAIN_HAS_8000": int(8000 in numbers["train"])}
    ev = sorted(numbers["eval"])
    first_after_8010 = next((n for n in ev if n > 8010), None)
    # EVAL_END stops before the first gap after 8010: the inventory refuses a missing file, so a gap inside its range would
    # cost the whole scan
    gap_free_end = first_after_8010
    while gap_free_end is not None and gap_free_end + 1 in numbers["eval"]:
        gap_free_end += 1
    candidate = min(ev[-1], eval_end) if ev else None
    out["eval"] = {"EVAL_FIRST": ev[0] if ev else None, "EVAL_LAST": ev[-1] if ev else None,
                   "EVAL_END": min(gap_free_end, eval_end) if gap_free_end is not None else candidate, "eval_end_argument": eval_end,
                   "first_gap_after_8010": gap_free_end + 1 if gap_free_end is not None and gap_free_end < (candidate or 0) else None,
                   "dev_oot_8000_8010_present": [n for n in range(8000, 8011) if n in numbers["eval"]],
                   "dev_oot_8000_8010_missing": [n for n in range(8000, 8011) if n not in numbers["eval"]],
                   "first_after_8010": first_after_8010}
    return out


def artifact_facts(store, artifacts_base):
    out = {"base": artifacts_base}
    try:
        out["listing"] = [{"path": r["path"], "size_bytes": r["size_bytes"]} for r in store.listing(artifacts_base)]
    except Exception as exc:  # noqa: BLE001
        out["listing_error"] = redact(repr(exc))
        out["listing"] = []
    versions = sorted({strip_scheme(r["path"])[len(strip_scheme(artifacts_base).rstrip("/")) + 1:].split("/")[0]
                       for r in out["listing"]})
    out["versions"] = versions
    try:
        out["nomonth_version_exists"] = store.exists(f"{artifacts_base.rstrip('/')}/{NOMONTH_ARTIFACT_VERSION}/manifest.json")
    except Exception as exc:  # noqa: BLE001
        out["nomonth_version_exists"], out["nomonth_version_error"] = None, redact(repr(exc))
    v1 = f"{artifacts_base.rstrip('/')}/1"
    try:
        with store.open_text(f"{v1}/manifest.json") as f:
            manifest = json.load(f)
        features = {}
        for name in manifest.get("features", []):
            with store.open_text(f"{v1}/feature__{name}.json") as f:
                entry = json.load(f)
            rec = {"keys": sorted(entry.keys())}
            if "vocab" in entry:
                rec["vocab_size"] = len(entry["vocab"])
                rec["unk_index"], rec["missing_index"] = entry.get("unk_index"), entry.get("missing_index")
                rec["vocab"] = entry["vocab"]  # kept in memory for the profile's UNK rates; not written
            features[name] = rec
        out["version_1"] = {"artifact_version": manifest.get("artifact_version"), "predictor_version": manifest.get("predictor_version"),
                            "created": manifest.get("created"), "fit_files": manifest.get("fit_files"),
                            "feature_count": len(manifest.get("features", [])), "features": sorted(manifest.get("features", [])),
                            "feature_entries": {k: {kk: vv for kk, vv in v.items() if kk != "vocab"} for k, v in features.items()}}
        out["_vocabs"] = {k: v["vocab"] for k, v in features.items() if "vocab" in v}
    except Exception as exc:  # noqa: BLE001
        out["version_1"] = {"error": redact(repr(exc))}
        out["_vocabs"] = {}
    return out


def reference_artifact_comparison(store, artifacts_base, reference_base):
    """Is the owner's version-1 artifact a byte copy of the reference author's (public question 2)? Hashes of the
    manifest and every feature file, compared when the reference folder is readable; otherwise the error is recorded."""
    out = {"base": reference_base, "readable": False}
    mine, ref = f"{artifacts_base.rstrip('/')}/1", f"{reference_base.rstrip('/')}/1"
    try:
        listing = store.listing(ref)
        out["readable"], out["objects"] = True, len(listing)
        with store.open_text(f"{mine}/manifest.json") as f:
            names = ["manifest.json"] + [f"feature__{n}.json" for n in json.load(f).get("features", [])]
        identical, differing, missing = [], [], []
        for name in names:
            with store.open_text(f"{mine}/{name}") as f:
                own = hashlib.sha256(f.read().encode("utf-8")).hexdigest()
            if not store.exists(f"{ref}/{name}"):
                missing.append(name)
                continue
            with store.open_text(f"{ref}/{name}") as f:
                other = hashlib.sha256(f.read().encode("utf-8")).hexdigest()
            (identical if own == other else differing).append(name)
        out.update(files_compared=len(names), identical=len(identical), differing=differing, missing_in_reference=missing,
                   byte_copy=bool(names) and not differing and not missing)
    except Exception as exc:  # noqa: BLE001 - a folder another user owns may not be readable; that is a fact, not a failure
        out["error"] = redact(repr(exc))
    return out


def prefix_summary(store, base):
    """Immediate children of a prefix with the object count and size under each (names only)."""
    out = {"base": base, "children": []}
    try:
        for child in store.ls(base):
            try:
                rows = store.listing(child)
            except Exception:  # noqa: BLE001 - a single object, not a folder
                rows = [{"path": child, "size_bytes": None}]
            out["children"].append({"path": child, "objects": len(rows),
                                    "total_gb": gb(sum(r["size_bytes"] or 0 for r in rows))})
    except Exception as exc:  # noqa: BLE001
        out["error"] = redact(repr(exc))
    return out


def storage_facts(store, artifacts_base, predictions_base, bench_paths, train_base, reference_artifacts_base=None):
    out = {"benchmark": {"candidates": []}}
    for path in bench_paths:
        rec = {"path": path, "exists": False}
        try:
            rec["exists"] = bool(store.exists(path))
            folder = path.rsplit("/eval/", 1)[0] if "/eval/" in path else path.rsplit("/", 1)[0]
            rec["folder"] = folder
            rec["folder_objects"] = [{"path": r["path"], "size_bytes": r["size_bytes"]} for r in store.listing(folder)] \
                if store.exists(folder) else []
            if rec["exists"]:  # the footer only: rows and column names and types, so the score, label and amount columns can be named
                pf = store.parquet(path)
                rec["rows"] = pf.metadata.num_rows
                rec["columns"] = [(f.name, str(f.type)) for f in pf.schema_arrow]
                rec["score_like_columns"] = [f.name for f in pf.schema_arrow if re.search(r"score|scr|prob|tfm|falcon|fl_|_fl", f.name, re.I)]
                rec["identifier_like_columns"] = [f.name for f in pf.schema_arrow if is_identifier_name(f.name)]
        except Exception as exc:  # noqa: BLE001
            rec["error"] = redact(repr(exc))
        out["benchmark"]["candidates"].append(rec)
    existing = [c["path"] for c in out["benchmark"]["candidates"] if c.get("exists")]
    out["benchmark"]["existing"] = existing
    out["benchmark"]["BENCH"] = existing[0] if len(existing) == 1 else None
    out["artifacts"] = artifact_facts(store, artifacts_base)
    if reference_artifacts_base:
        out["artifacts"]["reference_comparison"] = reference_artifact_comparison(store, artifacts_base, reference_artifacts_base)
    out["predictions"] = prefix_summary(store, predictions_base)
    bucket = "s3://" + strip_scheme(train_base).split("/")[0] if is_remote(train_base) else str(Path(train_base).parent)
    out["data_bucket_top_level"] = {"bucket": bucket}
    try:
        out["data_bucket_top_level"]["entries"] = store.ls(bucket)
    except Exception as exc:  # noqa: BLE001
        out["data_bucket_top_level"]["error"] = redact(repr(exc))
    return out


# --------------------------------------------------------------------------------------------------------------- #
# schema (footer metadata only)
# --------------------------------------------------------------------------------------------------------------- #
def footer_facts(pf):
    md = pf.metadata
    schema = pf.schema_arrow
    columns = [(f.name, str(f.type)) for f in schema]
    per_column = {name: {"null_count": 0, "null_count_known": True, "num_values": 0, "uncompressed_bytes": 0,
                         "compressed_bytes": 0} for name, _ in columns}
    for i in range(md.num_row_groups):
        rg = md.row_group(i)
        for j in range(rg.num_columns):
            c = rg.column(j)
            name = c.path_in_schema
            rec = per_column.get(name)
            if rec is None:  # nested field; keep the top-level name
                name = name.split(".")[0]
                rec = per_column.setdefault(name, {"null_count": 0, "null_count_known": True, "num_values": 0,
                                                   "uncompressed_bytes": 0, "compressed_bytes": 0})
            rec["num_values"] += c.num_values
            rec["uncompressed_bytes"] += c.total_uncompressed_size
            rec["compressed_bytes"] += c.total_compressed_size
            stats = c.statistics
            if stats is not None and stats.has_null_count:
                rec["null_count"] += stats.null_count
            else:
                rec["null_count_known"] = False
    fingerprint = hashlib.sha256(json.dumps(columns).encode()).hexdigest()[:16]
    return {"num_rows": md.num_rows, "num_row_groups": md.num_row_groups, "created_by": md.created_by,
            "num_columns": len(columns), "schema_fingerprint": fingerprint, "columns": columns, "per_column": per_column,
            "uncompressed_bytes": sum(v["uncompressed_bytes"] for v in per_column.values()),
            "compressed_bytes": sum(v["compressed_bytes"] for v in per_column.values())}


def name_hints(names):
    hints = {}
    for name in names:
        low = name.lower()
        tags = [tag for tag, pattern in NAME_HINTS.items() if re.search(pattern, low)]
        if tags:
            hints[name] = tags
    return hints


def predictor_columns():
    frame = pd.read_csv(PREDICTORS_CSV)
    raw = [r.feature for r in frame.itertuples() if not str(r.source).startswith("derived:")]
    kinds = {r.feature: r.type for r in frame.itertuples()}
    return raw, kinds


def schema_facts(store, files, profile_keys, column_csv_path):
    """files: {key: path}. Footer only. Writes the per-column CSV for every file; returns the summary."""
    raw_predictors, _ = predictor_columns()
    sys.path.insert(0, str(ROOT / "YOUR_PACKAGE/v2/screen"))
    try:
        import run_screen
        screen_cols = run_screen.screen_columns(run_screen.WAVE1)
    except Exception:  # noqa: BLE001 - the screen folder may be absent from a trimmed package
        screen_cols = None
    core = [ID, ACCOUNT, TIME, LABEL] + raw_predictors
    out = {"files": {}, "schemas": {}, "errors": {}}
    rows_csv = []
    for key, path in files.items():
        try:
            facts = footer_facts(store.parquet(path))
        except Exception as exc:  # noqa: BLE001
            out["errors"][key] = redact(repr(exc))
            continue
        fp = facts["schema_fingerprint"]
        out["schemas"].setdefault(fp, {"columns": facts["columns"], "files": []})["files"].append(key)
        rec = {"path": normal(path), "num_rows": facts["num_rows"], "num_row_groups": facts["num_row_groups"],
               "schema_fingerprint": fp, "num_columns": facts["num_columns"], "created_by": facts["created_by"],
               "uncompressed_gb": gb(facts["uncompressed_bytes"]), "compressed_gb": gb(facts["compressed_bytes"]),
               "uncompressed_bytes_per_row": round(facts["uncompressed_bytes"] / max(facts["num_rows"], 1), 1)}
        names = set(n for n, _ in facts["columns"])
        pc = facts["per_column"]
        rec["footprint_bytes_per_row"] = {
            "all_columns": rec["uncompressed_bytes_per_row"],
            "core_and_predictors": round(sum(pc[c]["uncompressed_bytes"] for c in core if c in pc) / max(facts["num_rows"], 1), 1),
            "screen_columns": None if screen_cols is None else
            round(sum(pc[c]["uncompressed_bytes"] for c in screen_cols if c in pc) / max(facts["num_rows"], 1), 1)}
        rec["missing_core_columns"] = [c for c in core if c not in names]
        rec["duplicate_column_names"] = sorted({n for n, c in Counter(n for n, _ in facts["columns"]).items() if c > 1})
        if key in profile_keys:
            rec["per_column"] = pc
        out["files"][key] = rec
        for name, v in pc.items():
            rows_csv.append({"file_key": key, "column": name, "num_values": v["num_values"],
                             "null_count": v["null_count"] if v["null_count_known"] else "",
                             "uncompressed_bytes": v["uncompressed_bytes"], "compressed_bytes": v["compressed_bytes"]})
    for fp, rec in out["schemas"].items():
        rec["name_hints"] = name_hints([n for n, _ in rec["columns"]])
        rec["identifier_like_columns"] = [n for n, _ in rec["columns"] if IDENTIFIER.search(n)]
    pd.DataFrame(rows_csv).to_csv(column_csv_path, index=False)
    out["distinct_schemas"] = len(out["schemas"])
    return out


# --------------------------------------------------------------------------------------------------------------- #
# profile (rows of one file, in column batches)
# --------------------------------------------------------------------------------------------------------------- #
def ns_values(stamps):
    return pd.Series(stamps).to_numpy(dtype="datetime64[ns]").astype("int64")


def quantiles(values, qs=(0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99)):
    """Interior quantiles only: a minimum or a maximum is one row's value and is never written."""
    arr = np.asarray(values, dtype="float64")
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        return None
    return {f"p{int(round(q * 100))}": float(v) for q, v in zip(qs, np.quantile(arr, qs))}


def code_counts(series, labels=None, top=CODE_TOP):
    """Value counts of a code column as strings, with frauds per code when labels are given. Codes only: a code longer
    than CODE_LENGTH characters, one with fewer than MIN_CODE_ROWS rows, or one beyond the ``top`` most frequent is
    pooled into _long_codes, _rare_codes or _other_codes (how many codes, rows and frauds), never printed."""
    s = series.dropna()
    if s.empty:
        return {}
    text = s.map(lambda v: str(v))
    counts = text.value_counts()
    per_code_frauds = labels.loc[text.index].groupby(text.to_numpy()).sum() if labels is not None else None
    out, pooled = {}, {"_long_codes": Counter(), "_rare_codes": Counter(), "_other_codes": Counter()}
    for rank, (code, n) in enumerate(counts.items()):
        frauds = int(per_code_frauds.get(code, 0)) if per_code_frauds is not None else None
        bucket = ("_long_codes" if len(code) > CODE_LENGTH else "_rare_codes" if n < MIN_CODE_ROWS
                  else "_other_codes" if rank >= top else None)
        if bucket is None:
            out[code] = {"rows": int(n)} if frauds is None else {"rows": int(n), "frauds": frauds}
            continue
        pooled[bucket]["codes"] += 1
        pooled[bucket]["rows"] += int(n)
        if frauds is not None:
            pooled[bucket]["frauds"] += frauds
    for bucket, c in pooled.items():
        if c["codes"]:
            out[bucket] = dict(c)
    return out


def is_identifier_name(name):
    return bool(IDENTIFIER.search(name))


def column_profile(name, series, arrow_type):
    """Counts-only profile of one column; values only under the code rule and never for identifier-like names."""
    rec = {"arrow_type": arrow_type, "pandas_dtype": str(series.dtype), "nulls": int(series.isna().sum()),
           "identifier_like": is_identifier_name(name)}
    non = series.dropna()
    rec["non_null"] = int(len(non))
    if non.empty:
        rec["distinct"] = 0
        return rec
    if pd.api.types.is_bool_dtype(non.dtype):
        rec["distinct"] = int(non.nunique())
        rec["values"] = {str(k): int(v) for k, v in non.value_counts().items()}
        return rec
    if pd.api.types.is_datetime64_any_dtype(non.dtype):
        ns = ns_values(non)
        rec.update(distinct=int(non.nunique()), tz=str(getattr(non.dt, "tz", None)),
                   span_days=int((ns.max() - ns.min()) // 86_400_000_000_000),
                   rows_with_sub_second=int((ns % 1_000_000_000 != 0).sum()),
                   rows_with_nonzero_seconds=int(((ns // 1_000_000_000) % 60 != 0).sum()))
        if not rec["identifier_like"]:  # the month of the earliest and latest value; never a date of birth or an account date
            rec.update(min_month=pd.Timestamp(ns.min()).strftime("%Y-%m"), max_month=pd.Timestamp(ns.max()).strftime("%Y-%m"))
        return rec
    if pd.api.types.is_numeric_dtype(non.dtype):
        vals = non.to_numpy(dtype="float64")
        finite = vals[np.isfinite(vals)]
        rec.update(distinct=int(non.nunique()), non_finite=int(len(vals) - len(finite)),
                   negative=int((finite < 0).sum()), zero=int((finite == 0).sum()), positive=int((finite > 0).sum()),
                   integral_share=round(float(np.mean(finite == np.floor(finite))), 6) if finite.size else None,
                   digits_of_max_abs=int(len(str(int(np.max(np.abs(finite)))))) if finite.size else None)
        if finite.size and not rec["identifier_like"] and rec["digits_of_max_abs"] >= ID_DIGITS and bool(np.all(finite == np.floor(finite))):
            rec["identifier_like"] = True  # whole numbers with 7+ digits under any name: an account, card, merchant or phone number
            rec["identifier_rule"] = f"whole numbers with {rec['digits_of_max_abs']} digits"
        if not rec["identifier_like"] and finite.size:
            rec["quantiles"] = quantiles(finite)
            rec["mean"] = float(np.mean(finite))
        if not rec["identifier_like"] and rec["distinct"] <= CODE_DISTINCT and \
                all(len(str(v).rstrip("0").rstrip(".") if isinstance(v, float) else str(v)) <= CODE_LENGTH for v in non.unique()):
            rec["values"] = code_counts(non, top=CODE_DISTINCT)
        return rec
    text = non.map(lambda v: v if isinstance(v, str) else str(v))
    lengths = text.str.len()
    rec.update(distinct=int(text.nunique()), length_min=int(lengths.min()), length_max=int(lengths.max()),
               length_mean=round(float(lengths.mean()), 2),
               digits_only=int(text.str.fullmatch(r"\d+").sum()), blank=int((text.str.strip() == "").sum()))
    if not rec["identifier_like"] and rec["distinct"] <= CODE_DISTINCT and rec["length_max"] <= CODE_LENGTH:
        rec["values"] = code_counts(text, top=CODE_DISTINCT)
    return rec


def postal_format_profile(series):
    s = series.dropna()
    out = {"non_null": int(len(s)), "nulls": int(series.isna().sum()), "pandas_dtype": str(series.dtype)}
    if s.empty:
        return out
    if pd.api.types.is_numeric_dtype(s.dtype):
        vals = s.to_numpy(dtype="float64")
        out["numeric_integral_share"] = round(float(np.mean(vals == np.floor(vals))), 6)
        text = pd.Series(np.where(vals == np.floor(vals), vals.astype("int64").astype(str), vals.astype(str)))
    else:
        text = s.map(lambda v: v if isinstance(v, str) else str(v)).str.strip()
    classes = {
        "5_digits": r"\d{5}", "9_digits": r"\d{9}", "zip_plus_4": r"\d{5}-\d{4}", "digits_dot_zero": r"\d+\.0",
        "1_to_4_digits": r"\d{1,4}", "6_to_8_digits": r"\d{6,8}", "10_or_more_digits": r"\d{10,}", "blank": r"\s*",
    }
    counts, rest = {}, pd.Series(True, index=text.index)
    for cls, pattern in classes.items():
        hit = text.str.fullmatch(pattern) & rest
        counts[cls] = int(hit.sum())
        rest &= ~hit
    counts["alphanumeric_or_other"] = int(rest.sum())
    out["format_classes"] = counts
    five = text[text.str.fullmatch(r"\d{5}")]
    out["5_digits_with_leading_zero"] = int(five.str.startswith("0").sum())
    out["distinct"] = int(text.nunique())
    return out


def hour_histogram(ns):
    hours = ((ns // 3_600_000_000_000) % 24).astype("int64")
    return [int(c) for c in np.bincount(hours, minlength=24)]


def clock_profiles(ns):
    """Hour-of-day counts for the 14 days before and after each clock change inside the file's range."""
    out = {}
    lo, hi = ns.min(), ns.max()
    for day in CLOCK_CHANGES:
        t = pd.Timestamp(day).value
        before, after = t - 14 * 86_400_000_000_000, t + 14 * 86_400_000_000_000
        if before < lo or after > hi:
            continue
        out[day] = {"14_days_before": hour_histogram(ns[(ns >= before) & (ns < t)]),
                    "14_days_after": hour_histogram(ns[(ns >= t) & (ns < after)])}
    return out


def key_profile(df, arrow_types):
    out = {}
    acct, txn, stamps, label = df[ACCOUNT], df[ID], df[TIME], df[LABEL]
    rec = {"arrow_type": arrow_types.get(ACCOUNT), "pandas_dtype": str(acct.dtype), "nulls": int(acct.isna().sum()),
           "distinct": int(acct.nunique())}
    try:
        ids = validate_ids(acct, "account IDs", unique=False)
        rec["kind"] = id_kind(ids)
        if pd.api.types.is_float_dtype(acct.dtype):
            vals = acct.dropna().to_numpy(dtype="float64")
            rec["float_integral_share"] = round(float(np.mean(vals == np.floor(vals))), 6)
            rec["max_abs_below_2_pow_53"] = bool(np.max(np.abs(vals)) < 2 ** 53)
            rec["digits_of_max_abs"] = int(len(str(int(np.max(np.abs(vals))))))
    except (ValueError, IndexError) as exc:  # IndexError: a file without rows
        rec["validate_ids_error"] = redact(str(exc))
    out["account"] = rec
    rec = {"arrow_type": arrow_types.get(ID), "pandas_dtype": str(txn.dtype), "nulls": int(txn.isna().sum()),
           "distinct": int(txn.nunique()), "duplicates": int(txn.duplicated().sum()),
           "composite_duplicates": int(df[[ID, ACCOUNT]].duplicated().sum())}
    try:
        rec["kind"] = id_kind(validate_ids(txn, "transaction IDs", unique=False))
    except (ValueError, IndexError) as exc:
        rec["validate_ids_error"] = redact(str(exc))
    non = txn.dropna()
    if not non.empty and not pd.api.types.is_numeric_dtype(non.dtype):
        text = non.map(lambda v: v if isinstance(v, str) else str(v))
        rec.update(length_min=int(text.str.len().min()), length_max=int(text.str.len().max()),
                   digits_only=int(text.str.fullmatch(r"\d+").sum()))
    out["transaction_id"] = rec
    rec = {"arrow_type": arrow_types.get(TIME), "pandas_dtype": str(stamps.dtype), "nulls": int(stamps.isna().sum())}
    if pd.api.types.is_datetime64_any_dtype(stamps.dtype) and stamps.notna().any():
        ns = ns_values(stamps.dropna())
        rec.update(tz=str(getattr(stamps.dt, "tz", None)), min=pd.Timestamp(ns.min()).isoformat(),
                   max=pd.Timestamp(ns.max()).isoformat(), rows_with_sub_second=int((ns % 1_000_000_000 != 0).sum()),
                   rows_with_nonzero_seconds=int(((ns // 1_000_000_000) % 60 != 0).sum()),
                   rows_with_nonzero_minutes=int(((ns // 60_000_000_000) % 60 != 0).sum()),
                   hour_of_day_all=hour_histogram(ns), clock_changes=clock_profiles(ns))
        weekday = (ns.astype("datetime64[ns]").astype("datetime64[D]").astype("int64") + 3) % 7  # 1970-01-01 was a Thursday
        rec["hour_of_day_weekday"] = hour_histogram(ns[weekday < 5])
        rec["hour_of_day_weekend"] = hour_histogram(ns[weekday >= 5])
    else:
        rec["note"] = "not a timestamp column"
    out["time"] = rec
    counts = {str(k): int(v) for k, v in label.value_counts(dropna=True).items()}
    rec = {"arrow_type": arrow_types.get(LABEL), "pandas_dtype": str(label.dtype), "nulls": int(label.isna().sum()),
           "distinct": len(counts), "only_0_and_1": set(counts) <= LABEL_OK and not int(label.isna().sum()),
           "stored_as_number": bool(pd.api.types.is_numeric_dtype(label.dtype) or pd.api.types.is_bool_dtype(label.dtype)),
           "frauds": int(fraud_mask(label).sum())}
    if len(counts) <= CODE_DISTINCT and all(len(k) <= CODE_LENGTH for k in counts):  # the code rule applies to the label too
        rec["values"] = counts
    else:
        rec["length_max"] = max(len(k) for k in counts) if counts else 0
    out["label"] = rec
    return out


def month_profile(df):
    stamps = pd.to_datetime(df[TIME])
    fraud = fraud_mask(df[LABEL])
    months = stamps.dt.strftime("%Y-%m")
    ns = ns_values(stamps)
    out = {}
    for m in sorted(months.dropna().unique()):
        mask = (months == m).to_numpy()
        out[m] = {"rows": int(mask.sum()), "frauds": int(fraud[mask].sum()), "accounts": int(df.loc[mask, ACCOUNT].nunique()),
                  "fraud_accounts": int(df.loc[mask & fraud.to_numpy(), ACCOUNT].nunique()),
                  "hour_of_day": hour_histogram(ns[mask])}
    weeks = stamps.dt.strftime("%G-W%V")
    out_weeks = {}
    for w in sorted(weeks.dropna().unique()):
        mask = (weeks == w).to_numpy()
        out_weeks[w] = {"rows": int(mask.sum()), "frauds": int(fraud[mask].sum())}
    return {"months": out, "iso_weeks": out_weeks}


def predictor_profile(df, arrow_types, vocabs, raw, kinds):
    out = {}
    label = fraud_mask(df[LABEL]).astype("int64")
    for col in raw:  # the raw predictor columns; day, hour and day_of_week are derived from the time column
        kind = kinds[col]
        if col not in df.columns:
            out[col] = {"present": False, "type": kind}
            continue
        s = df[col]
        rec = {"present": True, "type": kind, "arrow_type": arrow_types.get(col), "pandas_dtype": str(s.dtype),
               "nulls": int(s.isna().sum()), "null_share": round(float(s.isna().mean()), 6)}
        non = s.dropna()
        if kind == "categorical":
            text = non.map(lambda v: str(v))
            rec["distinct_codes"] = int(text.nunique())
            rec["codes"] = code_counts(non, label)
            rec["codes_stored_as_float_text"] = int(text.str.fullmatch(r"-?\d+\.0").sum())
            vocab = vocabs.get(col)
            if vocab is not None:
                hit = text.isin(set(vocab.keys()))
                rec["v1_vocab"] = {"size": len(vocab), "rows_not_in_vocab": int((~hit).sum()),
                                   "share_not_in_vocab": round(float((~hit).mean()), 6) if len(text) else None,
                                   "distinct_codes_not_in_vocab": int(text[~hit].nunique())}
        else:
            vals = pd.to_numeric(non, errors="coerce").to_numpy(dtype="float64")
            finite = vals[np.isfinite(vals)]
            rec.update(non_numeric=int(len(vals) - len(finite)), negative=int((finite < 0).sum()), zero=int((finite == 0).sum()),
                       integral_share=round(float(np.mean(finite == np.floor(finite))), 6) if finite.size else None,
                       quantiles=quantiles(finite), distinct=int(non.nunique()))
        out[col] = rec
    return out


def amount_by_type(df):
    if AMOUNT not in df.columns:
        return {"present": False}
    amt = pd.to_numeric(df[AMOUNT], errors="coerce")
    out = {"present": True, "negative": int((amt < 0).sum()), "zero": int((amt == 0).sum()), "positive": int((amt > 0).sum()),
           "nulls": int(amt.isna().sum()), "non_cent_values": int((((amt * 100).round(6) % 1 != 0) & amt.notna()).sum()),
           "quantiles": quantiles(amt.to_numpy(dtype="float64"))}
    label = fraud_mask(df[LABEL])
    for col in (TYPE, CATEGORY):
        if col in df.columns:
            by = {}
            codes = df[col].map(lambda v: None if pd.isna(v) else str(v))
            pooled = Counter()
            for code, n in codes.value_counts().items():
                mask = (codes == code).to_numpy()
                if len(code) > CODE_LENGTH or n < MIN_CODE_ROWS or len(by) >= CODE_TOP:
                    pooled.update(codes=1, rows=int(n), frauds=int(label[mask].sum()))
                    continue
                a = amt[mask]
                by[code] = {"rows": int(n), "frauds": int(label[mask].sum()), "negative": int((a < 0).sum()), "zero": int((a == 0).sum()),
                            # one amount statistic per code, over at least MIN_VALUE_ROWS rows: never a single row's amount
                            "amount_p50": float(a.median()) if int(a.notna().sum()) >= MIN_VALUE_ROWS else None}
            if pooled:
                by["_pooled_codes"] = dict(pooled)
            out[f"by_{col}"] = by
    return out


def advice_profile(df):
    if ADVICE not in df.columns:
        return {"present": False}
    adv = df[ADVICE]
    has = adv.notna() & (adv.map(lambda v: str(v).strip() if not pd.isna(v) else "") != "")
    label = fraud_mask(df[LABEL])
    out = {"present": True, "rows_with_code": int(has.sum()), "share_with_code": round(float(has.mean()), 6),
           "frauds_with_code": int(label[has].sum()), "codes": code_counts(adv[has], label.astype("int64"))}
    if has.any() and AMOUNT in df.columns:
        cents = (pd.to_numeric(df[AMOUNT], errors="coerce") * 100).round().astype("Int64")
        base = pd.DataFrame({"a": df[ACCOUNT].to_numpy(), "c": cents.to_numpy(), "t": pd.to_datetime(df[TIME]).to_numpy(dtype="datetime64[ns]")})
        base = base[base["c"].notna() & base["t"].notna()]
        left = base[has.to_numpy()[base.index]].sort_values("t").reset_index(drop=True)
        right = base[~has.to_numpy()[base.index]].sort_values("t").reset_index(drop=True)
        left["c"], right["c"] = left["c"].astype("int64"), right["c"].astype("int64")
        twins = pd.merge_asof(left, right.rename(columns={"t": "t_other"}), left_on="t", right_on="t_other", by=["a", "c"],
                              direction="nearest", tolerance=pd.Timedelta(days=7))
        gap = (twins["t"] - twins["t_other"]).dt.total_seconds()
        out["twins_same_account_same_amount"] = {
            "advice_rows": int(len(left)), "no_twin_within_7_days": int(gap.isna().sum()),
            "twin_within_1_hour": int((gap.abs() <= 3600).sum()), "twin_within_24_hours": int((gap.abs() <= 86400).sum()),
            "twin_within_7_days": int(gap.notna().sum()), "advice_after_twin": int((gap > 0).sum()),
            "advice_before_twin": int((gap < 0).sum()), "same_second": int((gap == 0).sum()),
            "gap_seconds_quantiles_advice_minus_twin": quantiles(gap.dropna().to_numpy())}
    return out


def present_flag_profile(df):
    if PRESENT not in df.columns:
        return {"present": False}
    codes = df[PRESENT].map(lambda v: "null" if pd.isna(v) else str(v))
    label = fraud_mask(df[LABEL])
    out = {"present": True, "codes": {}}
    merch = df[MERCH_POSTAL].notna() if MERCH_POSTAL in df.columns else None
    attend = df[ATTEND].map(lambda v: "null" if pd.isna(v) else str(v)) if ATTEND in df.columns else None
    pooled = Counter()
    for code, n in codes.value_counts().items():
        mask = (codes == code).to_numpy()
        if len(code) > CODE_LENGTH or n < MIN_CODE_ROWS or len(out["codes"]) >= CODE_DISTINCT:
            pooled.update(codes=1, rows=int(n), frauds=int(label[mask].sum()))
            continue
        rec = {"rows": int(n), "frauds": int(label[mask].sum())}
        if merch is not None:
            rec["merchant_postal_present"] = int(merch[mask].sum())
        if attend is not None:
            rec["by_" + ATTEND] = code_counts(attend[mask], top=CODE_DISTINCT)
        out["codes"][code] = rec
    if pooled:
        out["codes"]["_pooled_codes"] = dict(pooled)
    return out


def location_profile(df):
    out = {}
    for col in (MERCH_POSTAL, HOME_POSTAL):
        out[col] = postal_format_profile(df[col]) if col in df.columns else {"present": False}
    if HOME_POSTAL in df.columns:
        s = df[[ACCOUNT, TIME, HOME_POSTAL]].sort_values([ACCOUNT, TIME], kind="stable")
        per = s.groupby(ACCOUNT, sort=False)[HOME_POSTAL].nunique(dropna=True)
        first = s.groupby(ACCOUNT, sort=False)[HOME_POSTAL].transform("first")
        changed = s[HOME_POSTAL].notna() & first.notna() & (s[HOME_POSTAL] != first)
        out["home_postal_per_account"] = {"accounts": int(len(per)), "one_value": int((per <= 1).sum()),
                                          "two_values": int((per == 2).sum()), "three_or_more": int((per >= 3).sum()),
                                          "rows_differing_from_accounts_first_value": int(changed.sum())}
    merchant_col = next((c for c in df.columns if re.search(r"merchant.*xid$|merch.*_id$", c, re.I)), None)
    if merchant_col and MERCH_POSTAL in df.columns:
        per = df.dropna(subset=[MERCH_POSTAL]).groupby(merchant_col, sort=False)[MERCH_POSTAL].agg(["nunique", "size"])
        multi = per[per["size"] >= 2]
        out["merchant_postal_per_merchant"] = {"column": merchant_col, "merchants": int(len(per)),
                                               "merchants_with_2_or_more_rows": int(len(multi)),
                                               "one_postal": int((multi["nunique"] == 1).sum()), "two": int((multi["nunique"] == 2).sum()),
                                               "three_to_five": int(multi["nunique"].between(3, 5).sum()),
                                               "six_or_more": int((multi["nunique"] >= 6).sum())}
    if MERCH_POSTAL in df.columns and HOME_POSTAL in df.columns:
        def prefix3(series):
            t = series.map(lambda v: None if pd.isna(v) else str(v).strip())
            return t.where(t.str.fullmatch(r"\d{5}(-\d{4})?|\d{9}").eq(True), None).str[:3]
        a, b = prefix3(df[MERCH_POSTAL]), prefix3(df[HOME_POSTAL])
        both = a.notna() & b.notna()
        rec = {"rows_with_both_5_digit_codes": int(both.sum()), "same_3_digit_prefix": int((a[both] == b[both]).sum())}
        if PRESENT in df.columns:
            codes = df[PRESENT].map(lambda v: "null" if pd.isna(v) else str(v))
            rec["same_prefix_by_" + PRESENT] = {str(c): {"rows": int((both & (codes == c)).sum()),
                                                        "same_prefix": int(((a == b) & both & (codes == c)).sum())}
                                                for c, n in codes.value_counts().head(CODE_DISTINCT).items()
                                                if len(str(c)) <= CODE_LENGTH and n >= MIN_CODE_ROWS}
        out["merchant_vs_cardholder_postal_prefix"] = rec
    if MERCH_STATE in df.columns:
        t = df[MERCH_STATE].map(lambda v: None if pd.isna(v) else str(v).strip().upper())
        us = t.isin(US_STATES)
        out[MERCH_STATE] = {"nulls": int(t.isna().sum()), "us_state_codes": int(us.sum()), "other_codes": int((~us & t.notna()).sum()),
                            "distinct": int(t.nunique()), "top_other_codes": code_counts(t[~us & t.notna()], top=CODE_DISTINCT)}
    return out


def limits_profile(df):
    out = {}
    for col in (BALANCE, MERCH_LIMIT, CASH_LIMIT, OTHER_LIMIT):
        if col in df.columns:
            vals = pd.to_numeric(df[col], errors="coerce")
            out[col] = {"nulls": int(vals.isna().sum()), "quantiles": quantiles(vals.to_numpy(dtype="float64")),
                        "negative": int((vals < 0).sum()), "zero": int((vals == 0).sum())}
    if OTHER_LIMIT in df.columns and MERCH_LIMIT in df.columns:
        a, b = pd.to_numeric(df[OTHER_LIMIT], errors="coerce"), pd.to_numeric(df[MERCH_LIMIT], errors="coerce")
        both = a.notna() & b.notna()
        out["other_limit_vs_merchandise_limit"] = {"both_present": int(both.sum()), "equal": int((a[both] == b[both]).sum()),
                                                   "other_greater": int((a[both] > b[both]).sum()), "other_smaller": int((a[both] < b[both]).sum()),
                                                   "either_missing": int((~both).sum())}
        per = df.groupby(ACCOUNT, sort=False)[OTHER_LIMIT].nunique(dropna=True)
        out["other_limit_per_account"] = {"accounts": int(len(per)), "constant": int((per <= 1).sum()), "varies": int((per > 1).sum())}
        sample = df[[OTHER_LIMIT, MERCH_LIMIT, CASH_LIMIT] if CASH_LIMIT in df.columns else [OTHER_LIMIT, MERCH_LIMIT]].dropna()
        if len(sample) > 200_000:
            sample = sample.sample(200_000, random_state=0)
        if len(sample) > 10:
            corr = sample.rank().corr()
            out["rank_correlation_sample"] = {"rows": int(len(sample)),
                                              "values": {f"{a_}~{b_}": round(float(corr.loc[a_, b_]), 4)
                                                         for i, a_ in enumerate(sample.columns) for b_ in sample.columns[i + 1:]}}
    # consecutive rows of one account: limit rises (reset signature) by stored hour, and the gap profile
    s = df[[ACCOUNT, TIME, LABEL] + [c for c in (MERCH_LIMIT, CASH_LIMIT) if c in df.columns]]
    s = s[s[TIME].notna()].sort_values([ACCOUNT, TIME], kind="stable")
    same = s[ACCOUNT].to_numpy()[1:] == s[ACCOUNT].to_numpy()[:-1]
    ns = ns_values(s[TIME])
    gap = (ns[1:] - ns[:-1])[same] / 1e9
    later_label = fraud_mask(s[LABEL]).to_numpy()[1:][same]
    out["consecutive_pairs"] = {"pairs": int(same.sum()), "zero_gap": int((gap == 0).sum()),
                                "gap_seconds_quantiles": quantiles(gap), "gap_seconds_quantiles_later_row_fraud": quantiles(gap[later_label]),
                                "gap_seconds_quantiles_later_row_not_fraud": quantiles(gap[~later_label])}
    for col in (MERCH_LIMIT, CASH_LIMIT):
        if col not in s.columns:
            continue
        v = pd.to_numeric(s[col], errors="coerce").to_numpy(dtype="float64")
        earlier, later = v[:-1][same], v[1:][same]
        ok = np.isfinite(earlier) & np.isfinite(later)
        rise, fall = ok & (later > earlier + 0.005), ok & (later < earlier - 0.005)
        later_ns = ns[1:][same]
        day_earlier, day_later = (ns[:-1][same] // 86_400_000_000_000), (later_ns // 86_400_000_000_000)
        out[f"{col}_between_consecutive_rows"] = {
            "pairs_with_both_values": int(ok.sum()), "rises": int(rise.sum()), "falls": int(fall.sum()),
            "unchanged": int((ok & ~rise & ~fall).sum()),
            "rises_by_stored_hour_of_later_row": hour_histogram(later_ns[rise]) if rise.any() else [0] * 24,
            "rises_crossing_stored_midnight": int((rise & (day_later != day_earlier)).sum()),
            "rises_within_one_stored_day": int((rise & (day_later == day_earlier)).sum())}
    return out


def other_datetime_profile(df, extra):
    """Date columns other than the event time: future-dated relative to the row (profile snapshots), and range."""
    out = {}
    try:
        base = pd.to_datetime(df[TIME], errors="coerce")
    except (TypeError, ValueError) as exc:  # the event time is not a time at all; the key profile says so
        return {"error": redact(repr(exc))}
    for col in extra.columns:
        if col == TIME or not pd.api.types.is_datetime64_any_dtype(extra[col].dtype):
            continue
        try:
            s = pd.to_datetime(extra[col])
            both = s.notna() & base.notna()
            rec = {"nulls": int(s.isna().sum()), "identifier_like": is_identifier_name(col),
                   "later_than_transaction_time": int((s[both] > base[both]).sum()),
                   "earlier_than_transaction_time": int((s[both] < base[both]).sum()),
                   "equal_to_transaction_time": int((s[both] == base[both]).sum())}
            if s.notna().any() and not rec["identifier_like"]:  # months only, and never for a date of birth or an account date
                rec.update(min_month=s.min().strftime("%Y-%m"), max_month=s.max().strftime("%Y-%m"))
            out[col] = rec
        except (TypeError, ValueError) as exc:  # a different time zone or unit than the event time
            out[col] = {"error": redact(str(exc))}
    return out


def profile_file(store, key, path, vocabs, column_batch):
    pf = store.parquet(path)
    all_names = pf.schema_arrow.names
    duplicates = sorted({n for n, c in Counter(all_names).items() if c > 1})
    names = [n for n in dict.fromkeys(all_names) if n not in duplicates]  # a duplicated name cannot be read by name; it is recorded
    arrow_types = {f.name: str(f.type) for f in pf.schema_arrow}
    raw_predictors, kinds = predictor_columns()
    core = [c for c in [ID, ACCOUNT, TIME, LABEL, AMOUNT, ADVICE, PRESENT, ATTEND, MERCH_POSTAL, HOME_POSTAL, MERCH_STATE,
                        OTHER_LIMIT] + raw_predictors if c in names]
    core += [c for c in names if re.search(r"merchant.*xid$|merch.*_id$", c, re.I) and c not in core]
    missing_keys = [c for c in (ID, ACCOUNT, TIME, LABEL) if c not in names]
    out = {"file_key": key, "path": normal(path), "rows": pf.metadata.num_rows, "columns": len(all_names), "columns_read_in_core": core,
           "missing_key_columns": missing_keys, "duplicate_column_names": duplicates, "utc": utc_now()}
    if pf.metadata.num_rows == 0:
        out["note"] = "no rows"
        return out
    if missing_keys:
        out["note"] = "key columns missing; only the generic column profile is produced"
        core = [c for c in core if c not in (ID, ACCOUNT, TIME, LABEL)]
    df = pf.read(columns=list(dict.fromkeys(core))).to_pandas()

    def sub(name, fn):  # one sub-profile's failure is recorded; the others still run
        try:
            out[name] = fn()
        except Exception as exc:  # noqa: BLE001
            out[name] = {"error": redact(repr(exc))}
            out.setdefault("sub_profile_errors", []).append(name)

    if not missing_keys:
        out["keys"] = key_profile(df, arrow_types)
        if out["keys"]["time"].get("min") is not None and out["keys"]["label"]["only_0_and_1"]:
            sub("calendar", lambda: month_profile(df))
            sub("predictors", lambda: predictor_profile(df, arrow_types, vocabs, raw_predictors, kinds))
            sub("amount", lambda: amount_by_type(df))
            sub("advice", lambda: advice_profile(df))
            sub(PRESENT, lambda: present_flag_profile(df))
            sub("location", lambda: location_profile(df))
            sub("limits", lambda: limits_profile(df))
        else:
            out["note"] = "time or label column not as expected; calendar, predictor and state profiles skipped"
    # every other column, in batches, counts only
    others = [c for c in names if c not in df.columns]
    out["other_columns"] = {}
    out["other_datetime_columns"] = {}
    for start in range(0, len(others), column_batch):
        batch = others[start:start + column_batch]
        extra = pf.read(columns=batch).to_pandas()
        for col in batch:
            try:
                out["other_columns"][col] = column_profile(col, extra[col], arrow_types.get(col))
            except Exception as exc:  # noqa: BLE001 - one odd column does not lose the batch
                out["other_columns"][col] = {"error": redact(repr(exc))}
                out.setdefault("sub_profile_errors", []).append(col)
        if not missing_keys:
            out["other_datetime_columns"].update(other_datetime_profile(df, extra))
        del extra
    for col in df.columns:
        if col not in (ID, ACCOUNT, TIME, LABEL) and col not in (out.get("predictors") or {}):
            out["other_columns"][col] = column_profile(col, df[col], arrow_types.get(col))
    out["name_hints"] = name_hints(names)
    return out


# --------------------------------------------------------------------------------------------------------------- #
# months (every requested file, three columns)
# --------------------------------------------------------------------------------------------------------------- #
def months_facts(store, files, roles):
    """files: {key: path}; roles: {key: 'train'|'eval'}."""
    out = {"files": {}, "errors": {}}
    for key, path in files.items():
        try:
            pf = store.parquet(path)
            names = set(pf.schema_arrow.names)
            cols = [c for c in (TIME, LABEL, ACCOUNT) if c in names]
            if TIME not in names or LABEL not in names:
                out["errors"][key] = f"missing {[c for c in (TIME, LABEL) if c not in names]}"
                continue
            df = pf.read(columns=cols).to_pandas()
            stamps = pd.to_datetime(df[TIME])
            ns = ns_values(stamps.dropna())
            fraud = fraud_mask(df[LABEL])
            months = stamps.dt.strftime("%Y-%m")
            label_values = sorted(str(v) for v in df[LABEL].dropna().unique())
            rec = {"role": roles[key], "rows": int(len(df)), "frauds": int(fraud.sum()),
                   "accounts": int(df[ACCOUNT].nunique()) if ACCOUNT in df.columns else None,
                   "time_arrow_type": str(pf.schema_arrow.field(TIME).type), "time_nulls": int(stamps.isna().sum()),
                   "min_time": pd.Timestamp(ns.min()).isoformat() if ns.size else None,
                   "max_time": pd.Timestamp(ns.max()).isoformat() if ns.size else None,
                   "rows_with_sub_second": int((ns % 1_000_000_000 != 0).sum()),
                   "label_values": label_values if len(label_values) <= CODE_DISTINCT and all(len(v) <= CODE_LENGTH for v in label_values) else None,
                   "label_distinct": len(label_values), "label_nulls": int(df[LABEL].isna().sum()),
                   "months": {m: {"rows": int((months == m).sum()), "frauds": int(fraud[months == m].sum())}
                              for m in sorted(months.dropna().unique())}}
            expected = TRAIN_MONTHS if roles[key] == "train" else EVAL_MONTHS
            rec["months_outside_expected"] = sorted(set(rec["months"]) - set(expected))
            out["files"][key] = rec
        except Exception as exc:  # noqa: BLE001
            out["errors"][key] = redact(repr(exc))
    june = []
    cumulative = 0
    for key in sorted((k for k in out["files"] if roles[k] == "eval"), key=lambda k: int(k.split(":")[1])):
        n = int(key.split(":")[1])
        if n <= 8010:
            continue
        frauds = out["files"][key]["months"].get("2025-06", {}).get("frauds", 0)
        cumulative += frauds
        june.append({"file": n, "june_frauds": frauds, "cumulative_june_frauds": cumulative})
    out["june_after_8010"] = {"files": june, "total_june_frauds": cumulative}
    need, reached = 0, {}
    for role, minimum in JUNE_TARGETS:
        need += minimum
        reached[role] = next((j["file"] for j in june if j["cumulative_june_frauds"] >= need), None)
    out["june_after_8010"]["file_at_which_cumulative_reaches"] = {"SELECT_2000": reached["SELECT"], "SELECT_plus_DS_SELECT_4000": reached["DS_SELECT"],
                                                                   "SELECT_plus_DS_SELECT_plus_FINAL_7000": reached["FINAL"]}
    out["june_after_8010"]["note"] = ("contiguous blocks are chosen by select_splits; these cumulative counts only show whether the "
                                      "scanned range holds enough June frauds in total")
    train_union = sorted({m for k, r in out["files"].items() if roles[k] == "train" for m in r["months"]})
    eval_union = sorted({m for k, r in out["files"].items() if roles[k] == "eval" for m in r["months"]})
    out["month_union"] = {"train": train_union, "train_equals_expected": train_union == TRAIN_MONTHS,
                          "eval": eval_union, "eval_equals_expected": eval_union == EVAL_MONTHS}
    return out


# --------------------------------------------------------------------------------------------------------------- #
# summary and privacy check
# --------------------------------------------------------------------------------------------------------------- #
def summary_lines(results):
    lines, attention = [], []
    pod = results.get("pod") or {}
    if pod:
        mem = pod.get("memory", {})
        lines.append(f"pod: MemTotal {mem.get('MemTotal_gb')} GB, MemAvailable {mem.get('MemAvailable_gb')} GB, cgroup limit "
                     f"{pod.get('cgroup_memory_limit_gb')} GB, cpus {pod.get('cpu_count')} (affinity {pod.get('cpu_affinity')}, "
                     f"cgroup {pod.get('cgroup_cpu_limit')}), gpu {pod.get('gpu', {}).get('nvidia_smi')}")
        for name, d in pod.get("disk", {}).items():
            lines.append(f"pod: disk {name} {d.get('path')}: free {d.get('free_gb')} of {d.get('total_gb')} GB")
        total = mem.get("MemTotal_gb")
        limit = pod.get("cgroup_memory_limit_gb")
        usable = min(x for x in (total, limit) if x is not None) if (total or limit) else None
        if usable is not None and usable < SCREEN_GB + DOWNSTREAM_GB:
            attention.append(f"memory {usable} GB is below the screen's about {SCREEN_GB} GB plus the downstream fit's about {DOWNSTREAM_GB} GB "
                             "(USAGE_CONSUMERS): run the screen, the inventory and the downstream fit one at a time, never together")
        if usable is not None and usable < 40:
            attention.append(f"memory {usable} GB is below 40 GB: the screen (about {SCREEN_GB} GB) or the downstream fit (about {DOWNSTREAM_GB} GB) "
                             "may need fewer files; the next value is decided from this number")
        free = (pod.get("disk", {}).get("project_root") or {}).get("free_gb")
        if free is not None and free < DISK_NEED_GB:
            attention.append(f"disk free at the project root is {free} GB, below the about {DISK_NEED_GB} GB the exports and score files of "
                             "steps 2-8 need (about 8 GB of new files plus headroom)")
    env = results.get("environment") or {}
    if env:
        lines.append(f"environment: {env.get('executable')} ({env.get('packages', {}).get('pandas')} pandas, "
                     f"{env.get('packages', {}).get('torch')} torch, {env.get('packages', {}).get('xgboost')} xgboost, "
                     f"{env.get('packages', {}).get('scikit-learn')} scikit-learn); fraud from {env.get('fraud', {}).get('file')}")
        for name in ("xgboost", "scikit-learn", "joblib", "s3fs", "pyarrow", "omegaconf", "pytorch-lightning"):
            if env.get("packages", {}).get(name) is None:
                attention.append(f"package {name} is not installed in this environment")
        for mod in ("fraud", "YOUR_PACKAGE"):
            if env.get(mod, {}).get("under_project_root") is False:
                attention.append(f"{mod} imports from outside the project root: {env[mod].get('file')}")
    pkg = results.get("package") or {}
    if pkg:
        lines.append(f"package: {pkg.get('count')} files hashed, combined {pkg.get('combined_sha256')}, missing {pkg.get('missing')}")
    cred = results.get("credentials") or {}
    if cred.get("path"):
        lines.append(f"credentials: exists {cred.get('exists')}, readable {cred.get('readable')}, missing keys {cred.get('missing_keys')}")
        if not cred.get("exists") or cred.get("missing_keys"):
            attention.append("the credentials file is missing or lacks a key name")
    lst = results.get("listings") or {}
    if lst:
        for name, f in lst.get("folders", {}).items():
            lines.append(f"listing {name}: {f['part_files']} part files {f['first']}-{f['last']}, {f['other_objects_count']} other objects, "
                         f"{f['total_gb']} GB, gaps {len(f['gaps_between_first_and_last'])}")
            if f.get("error"):
                attention.append(f"listing {name} failed: {f['error']}")
        t, e = lst.get("train", {}), lst.get("eval", {})
        lines.append(f"export TRAIN_HAS_8000={t.get('TRAIN_HAS_8000')}")
        lines.append(f"export EVAL_LAST={e.get('EVAL_LAST')}")
        lines.append(f"export EVAL_END={e.get('EVAL_END')}")
        if t.get("missing"):
            attention.append(f"training files missing from the folder: {t['missing'][:20]}{' ...' if len(t['missing']) > 20 else ''}")
        if e.get("dev_oot_8000_8010_missing"):
            attention.append(f"evaluation files missing in 8000-8010: {e['dev_oot_8000_8010_missing']}")
        if e.get("first_gap_after_8010"):
            attention.append(f"evaluation files after 8010 have a gap at {e['first_gap_after_8010']}; EVAL_END stops before it "
                             f"(the inventory refuses a missing file)")
    sto = results.get("storage") or {}
    if sto:
        b = sto.get("benchmark", {})
        lines.append(f"export BENCH={b.get('BENCH')}")
        if b.get("BENCH") is None:
            attention.append(f"benchmark file: {len(b.get('existing', []))} of the two spellings exist ({b.get('existing')})")
        for c in b.get("candidates", []):
            if c.get("exists"):
                lines.append(f"benchmark {c['path']}: {c.get('rows')} rows, {len(c.get('columns', []))} columns; score-like columns "
                             f"{c.get('score_like_columns')}; identifier-like columns {c.get('identifier_like_columns')}")
        a = sto.get("artifacts", {})
        lines.append(f"artifacts: versions {a.get('versions')}, 20261019 exists {a.get('nomonth_version_exists')}, "
                     f"version 1 fit_files {a.get('version_1', {}).get('fit_files')}, features {a.get('version_1', {}).get('feature_count')}")
        if a.get("nomonth_version_exists"):
            attention.append("artifact version 20261019 already exists; build_nomonth_artifact will refuse (it must not be overwritten)")
        if a.get("version_1", {}).get("error"):
            attention.append(f"V1 artifacts could not be read: {a['version_1']['error']}")
        ref = a.get("reference_comparison")
        if ref is not None:
            lines.append(f"artifacts: reference folder {ref.get('base')} readable {ref.get('readable')}; byte copy of version 1: {ref.get('byte_copy')} "
                         f"({ref.get('identical')} of {ref.get('files_compared')} files identical; differing {ref.get('differing')}; "
                         f"missing {ref.get('missing_in_reference')}; error {ref.get('error')})")
            if ref.get("readable") and not ref.get("byte_copy"):
                attention.append("the owner's version 1 artifact is not a byte copy of the reference author's (public question 2)")
        lines.append(f"predictions: {len(sto.get('predictions', {}).get('children', []))} folders under {sto.get('predictions', {}).get('base')}")
    sch = results.get("schema") or {}
    if sch:
        lines.append(f"schema: {len(sch.get('files', {}))} files read (footers only), {sch.get('distinct_schemas')} distinct schemas, "
                     f"errors {len(sch.get('errors', {}))}")
        if sch.get("distinct_schemas", 0) > 1:
            attention.append("files do not all share one schema: " + "; ".join(
                f"{fp}: {len(v['files'])} files, {len(v['columns'])} columns" for fp, v in sch["schemas"].items()))
        for key, f in sch.get("files", {}).items():
            if f.get("missing_core_columns"):
                attention.append(f"{key} lacks core columns {f['missing_core_columns']}")
        rows = [f["num_rows"] for f in sch.get("files", {}).values()]
        if rows:
            lines.append(f"schema: rows per file min {min(rows)}, max {max(rows)}, total {sum(rows)}")
    for key, prof in (results.get("profile") or {}).items():
        k = prof.get("keys", {})
        acct, txn, tm, lab = k.get("account", {}), k.get("transaction_id", {}), k.get("time", {}), k.get("label", {})
        lines.append(f"profile {key}: {prof.get('rows')} rows, {prof.get('columns')} columns; account {acct.get('arrow_type')} "
                     f"kind {acct.get('kind')} integral {acct.get('float_integral_share')}; id {txn.get('arrow_type')} duplicates "
                     f"{txn.get('duplicates')}; time {tm.get('arrow_type')} {tm.get('min')}..{tm.get('max')} sub-second "
                     f"{tm.get('rows_with_sub_second')}; label {lab.get('values')}")
        if acct.get("validate_ids_error") or txn.get("validate_ids_error"):
            attention.append(f"{key}: identifier column refused by validate_ids: {acct.get('validate_ids_error') or txn.get('validate_ids_error')}")
        if acct.get("float_integral_share") not in (None, 1.0):
            attention.append(f"{key}: account ids are floats and not all whole numbers (integral share {acct.get('float_integral_share')})")
        if lab and not lab.get("only_0_and_1"):
            attention.append(f"{key}: label values are not exactly 0/1: {lab.get('values')}, nulls {lab.get('nulls')}")
        if lab and lab.get("stored_as_number") is False:
            attention.append(f"{key}: the label is stored as {lab.get('arrow_type')} (text), not as a number; frauds were counted by value "
                             f"({lab.get('frauds')}); every later step assumes a numeric 0/1 label")
        if tm.get("note"):
            attention.append(f"{key}: the time column is not a timestamp ({tm.get('arrow_type')}); calendar, predictor and state profiles skipped")
        for name in prof.get("sub_profile_errors", []):
            attention.append(f"{key}: sub-profile {name} failed: {(prof.get(name) or prof.get('other_columns', {}).get(name) or {}).get('error')}")
        if prof.get("duplicate_column_names"):
            attention.append(f"{key}: duplicated column names, not profiled: {prof['duplicate_column_names']}")
        if tm.get("rows_with_sub_second"):
            attention.append(f"{key}: {tm['rows_with_sub_second']} rows carry a sub-second timestamp (PLAN section 7: the reviewers decide before step 3)")
        if txn.get("duplicates"):
            attention.append(f"{key}: {txn['duplicates']} duplicate transaction ids")
        for col, p in prof.get("predictors", {}).items():
            if not p.get("present"):
                attention.append(f"{key}: predictor column {col} is absent")
            elif p.get("v1_vocab", {}).get("rows_not_in_vocab"):
                attention.append(f"{key}: {col}: {p['v1_vocab']['rows_not_in_vocab']} rows ({p['v1_vocab']['share_not_in_vocab']}) carry codes not "
                                 f"in the V1 vocabulary ({p['v1_vocab']['distinct_codes_not_in_vocab']} codes)")
            if p.get("codes_stored_as_float_text"):
                attention.append(f"{key}: {col}: {p['codes_stored_as_float_text']} codes stringify as '<n>.0' (float-stored codes)")
    mon = results.get("months") or {}
    if mon:
        files = mon.get("files", {})
        lines.append(f"months: {len(files)} files read (time, label, account), errors {len(mon.get('errors', {}))}; "
                     f"train months {mon.get('month_union', {}).get('train')} (expected {mon.get('month_union', {}).get('train_equals_expected')}); "
                     f"eval months {mon.get('month_union', {}).get('eval')} (expected {mon.get('month_union', {}).get('eval_equals_expected')})")
        j = mon.get("june_after_8010", {})
        lines.append(f"months: June frauds in evaluation files after 8010: {j.get('total_june_frauds')} over {len(j.get('files', []))} files; "
                     f"cumulative reaches 2000/4000/7000 at files {j.get('file_at_which_cumulative_reaches')}")
        if j.get("files") and j.get("file_at_which_cumulative_reaches", {}).get("SELECT_plus_DS_SELECT_plus_FINAL_7000") is None:
            attention.append("the scanned evaluation files after 8010 hold fewer than 7,000 June frauds in total; select_splits may need "
                             "EVAL_END=EVAL_LAST")
        for key, f in files.items():
            if f.get("months_outside_expected"):
                attention.append(f"{key}: months outside the expected set: {f['months_outside_expected']}")
            if f.get("rows_with_sub_second"):
                attention.append(f"{key}: {f['rows_with_sub_second']} rows with a sub-second timestamp")
            if f.get("label_values") is None or set(f["label_values"]) - LABEL_OK or f.get("label_nulls"):
                attention.append(f"{key}: label values {f.get('label_values')} ({f.get('label_distinct')} distinct), nulls {f.get('label_nulls')}")
            if f.get("time_nulls"):
                attention.append(f"{key}: {f['time_nulls']} null timestamps")
    return lines, attention


LONG_DIGITS = re.compile(r"\d{16,}")
SOME_DIGITS = re.compile(r"\d{7,}")
HEX_STRING = re.compile(r"(?=[0-9a-f]*[a-f])[0-9a-f]{16,}")  # a digest or a schema fingerprint: hex with at least one letter
TIMESTAMP_TEXT = re.compile(r"\d{4}-\d{2}-\d{2}[T ][\d:.+Z-]*")
# Keys (or their parent key) under which a whole number of 7+ digits is a count, a size or an aggregate, not a value
COUNT_KEY = re.compile(r"rows|count|null|bytes|size|accounts|frauds|distinct|duplicat|objects|positive|negative|zero|pairs|values"
                       r"|codes|merchants|columns|cpu|memory|total|cumulative|same|twin|hist|hour|before|after|later|earlier|equal"
                       r"|present|blank|digits|unchanged|rises|falls|both|either|other|one_|two|three|six|sub_second|nonzero|n_|num_"
                       r"|_n$|share|mean|quantiles|^p\d+$|_gb$|files|first|last|end|start|part|version|seed|epoch|limit|span|length"
                       r"|advice|non_|integral|known|kind|reached|returncode|errors|missing|requested|affinity|constant|varies"
                       r"|prefix|postal|flag|us_state|differing|greater|smaller|within|no_twin|crossing|_known", re.I)


def privacy_scan(folder):
    """Scan every file written: JSON structurally (keys, strings and numbers), CSV text fields, text files as text.
    Counts and key paths only are reported; a flagged item is a place to look, never the value itself."""
    flagged = []

    def flag(where, why):
        flagged.append({"where": [str(w)[:40] for w in where], "why": why})

    def walk(value, trail):
        if isinstance(value, dict):
            for k, v in value.items():
                if SOME_DIGITS.search(str(k)) and not HEX_STRING.fullmatch(str(k)):
                    flag(trail + [str(k)[:10] + "..."], "key with a 7+ digit run")
                walk(v, trail + [k])
        elif isinstance(value, list):
            for i, v in enumerate(value):
                walk(v, trail + [f"[{i}]"])
        elif isinstance(value, str):
            if HEX_STRING.fullmatch(value) or value.startswith(("s3://", "/")) or TIMESTAMP_TEXT.fullmatch(value):
                return  # a digest, a path or a time stamp
            if LONG_DIGITS.search(value):
                flag(trail, "16+ digit run")
            elif SOME_DIGITS.search(value):
                flag(trail, "7+ digit run in text")
            elif len(value) > 160:
                flag(trail, f"string of {len(value)} characters")
        elif isinstance(value, bool) or value is None:
            return
        elif isinstance(value, (int, float)):
            if abs(value) >= 10 ** (ID_DIGITS - 1) and float(value).is_integer() and not any(COUNT_KEY.search(str(t)) for t in trail[-2:]):
                flag(trail, "whole number with 7+ digits under a key that is not a count")

    for p in sorted(Path(folder).iterdir()):
        if p.name == "privacy_check.json" or not p.is_file():
            continue
        try:
            if p.suffix == ".json":
                walk(json.loads(p.read_text(encoding="utf-8")), [p.name])
            elif p.suffix == ".csv":
                frame = pd.read_csv(p, dtype=str, keep_default_na=False)
                for col in frame.columns:  # text fields only; the count columns are numbers by construction
                    if not frame[col].str.fullmatch(r"-?\d*\.?\d*").all():
                        hits = int(frame[col].str.contains(SOME_DIGITS.pattern, regex=True).sum())
                        if hits:
                            flag([p.name, col], f"{hits} text fields with a 7+ digit run")
            else:
                text = p.read_text(encoding="utf-8", errors="replace")
                if LONG_DIGITS.search(text):
                    flag([p.name], "16+ digit run")
                runs = len(re.findall(r"(?<![0-9A-Za-z])\d{9,}(?![0-9A-Za-z])", text))  # a run inside a hex digest does not count
                if runs:
                    flag([p.name], f"{runs} runs of 9+ digits")
        except (OSError, ValueError) as exc:
            flag([p.name], f"unreadable: {type(exc).__name__}")
    return {"flagged": flagged[:200], "flagged_count": len(flagged),
            "rule": "JSON: no 16+ digit run; no 7+ digit run in text or keys except digests, paths and time stamps; no whole number "
                    "with 7+ digits under a key that is not a count; no string over 160 characters. Text files: no 16+ digit run and "
                    "no 9+ digit run. CSV: no 7+ digit run in a text field. Column values are printed only under the code rule (at "
                    f"most {CODE_LENGTH} characters, at most {CODE_TOP} codes, at least {MIN_CODE_ROWS} rows, never an identifier); "
                    "no minimum or maximum of any column except each file's first and last event time."}


# --------------------------------------------------------------------------------------------------------------- #
# main
# --------------------------------------------------------------------------------------------------------------- #
class Return:
    def __init__(self, parent, dry_run):
        self.dry_run = dry_run
        self.path = Path(parent) / f"data_look_{utc_stamp()}"
        if not dry_run:
            self.path.mkdir(parents=True, exist_ok=False)

    def status(self, line):
        line = f"{utc_now()} {line}"
        print(line, flush=True)
        if not self.dry_run:
            with open(self.path / "STATUS.txt", "a", encoding="utf-8") as f:
                f.write(line + "\n")

    def write_json(self, name, value):
        if self.dry_run:
            return
        with open(self.path / name, "w", encoding="utf-8") as f:
            json.dump(jsonable(value), f, indent=1, sort_keys=True, default=str)
            f.write("\n")

    def write_text(self, name, text):
        if not self.dry_run:
            (self.path / name).write_text(text, encoding="utf-8")


def run_section(ret, name, fn, results, failed, key=None):
    """Run one section; its result goes under ``key`` (default ``name``). A failure is recorded, not raised."""
    key = key or name
    ret.status(f"{name}: started")
    try:
        results[key] = fn()
        ret.status(f"{name}: finished")
    except Exception as exc:  # noqa: BLE001 - one failed section does not stop the others
        failed.append(name)
        results[key] = None
        ret.status(f"{name}: FAILED {redact(repr(exc))}")
        ret.write_text(f"{name.replace(' ', '_').replace(':', '_')}_error.txt", redact(traceback.format_exc()))


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--out", required=True, help="parent folder; a new data_look_<UTC> folder is created inside")
    p.add_argument("--cred-path", default=None, help="S3 credentials file (fraud.data.s3_utils); read, never copied")
    p.add_argument("--train-base", default=DEFAULT_TRAIN)
    p.add_argument("--eval-base", default=DEFAULT_EVAL)
    p.add_argument("--artifacts-base", default=DEFAULT_ARTIFACTS)
    p.add_argument("--reference-artifacts-base", default=DEFAULT_REFERENCE_ARTIFACTS,
                   help="the reference author's artifacts; version 1 is compared file by file when readable (public question 2); '' skips")
    p.add_argument("--predictions-base", default=DEFAULT_PREDICTIONS)
    p.add_argument("--bench-paths", nargs="*", default=DEFAULT_BENCH, help="candidate benchmark files; both spellings by default")
    p.add_argument("--train-ranges", nargs="*", default=DEFAULT_TRAIN_RANGES, help="N or START:END; 8000 only if listed")
    p.add_argument("--eval-end", type=int, default=8300, help="last evaluation file read (audit finding 53); EVAL_END = min(last listed, this)")
    p.add_argument("--profile-files", nargs="*", default=None,
                   help="role:N keys for the row profile (default train:1 train:4950 train:5001 eval:8000; files after 8010 are "
                        "counted in months only, so the SELECT, DS_SELECT and FINAL candidates get no profile)")
    p.add_argument("--only", default=",".join(SECTIONS), help=f"comma list of sections (default all): {','.join(SECTIONS)}")
    p.add_argument("--allow-selection-pool-profile", action="store_true",
                   help=f"permit --profile-files eval:N with N >= {SELECTION_POOL_START} (a prospective SELECT, DS_SELECT or FINAL file); recorded in exposure.json")
    p.add_argument("--column-batch", type=int, default=16, help="columns read at once in the profile")
    p.add_argument("--dry-run", action="store_true", help="print the plan; read and write nothing")
    args = p.parse_args(argv)

    sections = [s.strip() for s in args.only.split(",") if s.strip()]
    unknown = sorted(set(sections) - set(SECTIONS))
    if unknown:
        p.error(f"unknown sections {unknown}; choose from {SECTIONS}")
    try:  # a bad range or profile key fails here, in the dry run too, not inside the listings section at run time
        parse_ranges(args.train_ranges)
        for key in args.profile_files or []:
            role, _, number = key.partition(":")
            if role not in ("train", "eval") or not number.isdigit():
                raise ValueError(f"bad --profile-files entry {key!r}: train:N or eval:N")
            if role == "eval" and int(number) >= SELECTION_POOL_START and not args.allow_selection_pool_profile:
                raise ValueError(f"{key} is in the selection pool (evaluation files from {SELECTION_POOL_START}); a profile prints per-code "
                                 "fraud counts of a prospective SELECT, DS_SELECT or FINAL file; pass --allow-selection-pool-profile to insist")
    except ValueError as exc:
        p.error(redact(str(exc)))
    ret = Return(args.out, args.dry_run)
    ret.status(f"data_look {sha256_file(__file__)[:16]} sections {sections}; python {sys.executable}; cwd {os.getcwd()}; root {ROOT}")
    if args.dry_run:
        print(f"dry run: would write {ret.path}; train {args.train_base} ranges {args.train_ranges}; eval {args.eval_base} to "
              f"{args.eval_end}; artifacts {args.artifacts_base}; bench {args.bench_paths}; nothing read")
        return 0

    results, failed = {}, []
    s3_sections = [s for s in ("listings", "storage", "schema", "profile", "months") if s in sections]

    def skip(names, reason):
        for name in names:
            failed.append(f"{name} (skipped: {reason})")
            ret.status(f"{name}: SKIPPED ({reason})")

    store = None
    if s3_sections:
        try:  # a missing or malformed credentials file must not stop the local sections or the summary
            store = Store(args.cred_path)
        except Exception as exc:  # noqa: BLE001
            ret.status(f"s3 connection: FAILED {redact(repr(exc))}")
            ret.write_text("s3_connection_error.txt", redact(traceback.format_exc()))
            failed.append("s3 connection")
            skip(s3_sections, "no S3 connection")
            s3_sections = []
    if "pod" in sections:
        run_section(ret, "pod", lambda: pod_facts(ROOT), results, failed)
    if "environment" in sections:
        run_section(ret, "environment", lambda: environment_facts(ROOT), results, failed)
    if "package" in sections:
        run_section(ret, "package", lambda: package_facts(ROOT), results, failed)
    if "credentials" in sections:
        run_section(ret, "credentials", lambda: credentials_facts(args.cred_path), results, failed)
    for name in ("pod", "environment", "package", "credentials"):
        if results.get(name) is not None:
            ret.write_json(f"{name}.json", results[name])

    listing = None
    if any(s in s3_sections for s in ("listings", "schema", "profile", "months")):
        run_section(ret, "listings", lambda: listings_facts(store, args.train_base, args.eval_base, args.train_ranges, args.eval_end),
                    results, failed)
        listing = results.get("listings")
        if listing is not None:
            ret.write_json("listings.json", listing)
        else:
            skip([s for s in ("schema", "profile", "months") if s in s3_sections], "no listing")
    if "storage" in s3_sections:
        run_section(ret, "storage", lambda: storage_facts(store, args.artifacts_base, args.predictions_base, args.bench_paths,
                                                          args.train_base, args.reference_artifacts_base or None), results, failed)
        if results.get("storage") is not None:
            vocabs = results["storage"]["artifacts"].pop("_vocabs", {})
            ret.write_json("storage.json", results["storage"])
        else:
            vocabs = {}
    else:
        vocabs = {}

    files, roles = {}, {}
    if listing is not None:
        train_numbers = listing["train"]["present"] + ([8000] if listing["train"]["TRAIN_HAS_8000"] else [])
        eval_present = {part_number(r["path"]) for r in listing["folders"]["eval"]["listing"]}
        eval_numbers = [n for n in range(8000, (listing["eval"]["EVAL_END"] or 7999) + 1) if n in eval_present]
        for n, path in part_paths(args.train_base, train_numbers).items():
            files[f"train:{n}"], roles[f"train:{n}"] = path, "train"
        for n, path in part_paths(args.eval_base, eval_numbers).items():
            files[f"eval:{n}"], roles[f"eval:{n}"] = path, "eval"
        profile_keys = args.profile_files
        if profile_keys is None:
            profile_keys = [k for k in ("train:1", "train:4950", "train:5001", "eval:8000") if k in files]
        profile_keys = [k for k in profile_keys if k in files]
        ret.status(f"files: {len(files)} requested ({sum(r == 'train' for r in roles.values())} train, "
                   f"{sum(r == 'eval' for r in roles.values())} eval); profile {profile_keys}")
        if not files:
            skip([s for s in ("schema", "profile", "months") if s in s3_sections], "no part files listed")
    else:
        profile_keys = []

    if "schema" in sections and files:
        run_section(ret, "schema", lambda: schema_facts(store, files, set(profile_keys), ret.path / "schema_columns.csv"), results, failed)
        if results.get("schema") is not None:
            ret.write_json("schema.json", results["schema"])
    if "profile" in sections and files:
        results["profile"] = {}
        for key in profile_keys:
            run_section(ret, f"profile {key}", lambda k=key: profile_file(store, k, files[k], vocabs, args.column_batch),
                        results["profile"], failed, key=key)
            if results["profile"].get(key) is not None:
                ret.write_json(f"profile_{key.replace(':', '_')}.json", results["profile"][key])
        results["profile"] = {k: v for k, v in results["profile"].items() if v is not None}
    if "months" in sections and files:
        run_section(ret, "months", lambda: months_facts(store, files, roles), results, failed)
        if results.get("months") is not None:
            ret.write_json("months.json", results["months"])

    lines, attention = summary_lines(results)
    text = ["# Data look summary (counts, types and names only)", f"written {utc_now()} to {ret.path}", ""]
    text += ["## Facts"] + [f"- {ln}" for ln in lines] + ["", "## Attention (descriptive; read these before the next step)"]
    text += [f"- {ln}" for ln in attention] if attention else ["- none"]
    text += ["", f"## Failed sections: {failed or 'none'}"]
    ret.write_text("SUMMARY.txt", "\n".join(text) + "\n")
    exports = [ln for ln in lines if ln.startswith("export ") and not ln.endswith("=None")]  # a value the look could not settle is left out
    ret.write_text("env_additions.sh", "# from the data look; RUNBOOK step 1c appends this to runs/v2/env.sh\n" + "\n".join(exports) + "\n")
    try:
        import resource
        peak_gb = round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024 / 1e9, 2)  # Linux reports kilobytes
    except (ImportError, AttributeError):  # pragma: no cover - not Linux
        peak_gb = None
    ret.write_json("exposure.json", {  # the pre-selection label reads of the evaluation pool, on the same trail as the scorings
        "operation": "data_look", "utc": utc_now(), "script_sha256": sha256_file(__file__), "files_read": sorted(files),
        "profiled": profile_keys, "selection_pool_profiled": [k for k in profile_keys if k.startswith("eval:") and int(k.split(":")[1]) >= SELECTION_POOL_START],
        "labels_read": "per-file and per-month counts only in months; per-code counts in the profiled files; no model, no row-level value written",
        "peak_memory_gb": peak_gb})
    ret.write_json("data_look_manifest.json", {
        "utc": utc_now(), "script_sha256": sha256_file(__file__), "argv": sys.argv[1:] if argv is None else list(argv),
        "sections": sections, "failed": failed, "files_requested": len(files), "profile_files": profile_keys,
        "python": sys.version.split()[0], "pandas": pd.__version__, "pyarrow": pq.__version__ if hasattr(pq, "__version__") else None})
    privacy = privacy_scan(ret.path)  # every file written so far, SUMMARY.txt included
    ret.write_json("privacy_check.json", privacy)
    if privacy["flagged_count"]:
        text += ["", f"## Privacy check: {privacy['flagged_count']} item(s) flagged in privacy_check.json (key paths only). Send "
                     "STATUS.txt and privacy_check.json first and hold the rest of the folder until the flagged places have been read."]
    else:
        text += ["", "## Privacy check: nothing flagged"]
    ret.write_text("SUMMARY.txt", "\n".join(text) + "\n")
    print("\n".join(text))
    ret.status(f"finished; failed: {failed or 'none'}; privacy check flagged {privacy['flagged_count']}; peak memory {peak_gb} GB; send back {ret.path}")
    if exports:  # the exact line RUNBOOK step 1c pastes, so no folder name is typed by hand
        ret.status(f"for runs/v2/env.sh: cat {ret.path.resolve() / 'env_additions.sh'} >> runs/v2/env.sh; source runs/v2/env.sh")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
