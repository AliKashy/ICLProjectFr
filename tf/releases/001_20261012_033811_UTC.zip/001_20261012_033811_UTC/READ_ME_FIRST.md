# Package 001_20261012_033811_UTC

This is the first diagnostic package. It reads existing data and preprocessing artifacts, checks the environment and source/configuration identity, and writes a report. It does not rebuild preprocessing or start A/B training. The other source files are included because the diagnostic imports and tests them; their presence does not release the later experiments.

## 1. Extract

Upload `001_20261012_033811_UTC.zip` to the pod. Open a terminal in the directory containing that ZIP, using the Python environment you normally use for the project. Type:

```bash
python -m zipfile -e 001_20261012_033811_UTC.zip .
cd 001_20261012_033811_UTC
```

## 2. Restore the placeholders once

Use the exact private setup command supplied with this package. It starts with `python personalize.py` and supplies these five values:

| Argument | What to enter |
|---|---|
| `--package` | Original Python package folder name |
| `--id` | Your ID, starting with k |
| `--reference-id` | Reference configuration owner's ID, starting with k |
| `--data-bucket` | Existing raw-data bucket name, without s3:// |
| `--artifact-bucket` | Existing artifact bucket name, without s3:// |

The helper changes only the documented placeholders in the extracted source/config files, renames `YOUR_PACKAGE` back to the original directory name, and updates the fixed source manifest after checking the distributed file hashes. It records the substitutions in `PERSONALIZATION.json`. No credential contents are requested, copied or embedded. Your existing credential file stays at its existing location.

| Public placeholder | Restored value |
|---|---|
| `YOUR_PACKAGE` | `--package` |
| `YOUR_ID` / `your_id` | `--id`, uppercase / lowercase |
| `REFERENCE_ID` / `reference_id` | `--reference-id`, uppercase / lowercase |
| `DATA_BUCKET` | `--data-bucket` |
| `ARTIFACT_BUCKET` | `--artifact-bucket` |

## 3. Run the diagnostic

```bash
set -o pipefail
python runbook/2026-10-07/preflight_pod.py 2>&1 | tee diagnostic_console.txt
```

Send the results even if the report says FAIL. FAIL records a fact for the next step; it does not mean the return was unsuccessful. The printed `PREFLIGHT_DIR=...` identifies the generated folder.

## 4. Package the complete return

From the same extracted package directory, type:

```bash
python -m zipfile -c ../001_20261012_033811_UTC_return.zip runs/preflight diagnostic_console.txt PERSONALIZATION.json
```

If the diagnostic stopped before creating `runs/preflight`, use:

```bash
python -m zipfile -c ../001_20261012_033811_UTC_return.zip diagnostic_console.txt PERSONALIZATION.json
```

Send that return ZIP through the same private handoff used for this project. Keep every generated file, including `errors.txt`, `pytest.txt` and `label_values.txt` when present. No output is labelled local-only. The package ID links the outbound ZIP to its return. Use the private release's `returns/run-001/` location identified in the accompanying private instructions. No training command is part of this stage.

## Contents and notices

Model formulas, thresholds, data ranges and experimental settings are preserved. Changes are identity placeholders, neutral labels, complete-return filenames/instructions and package setup/identity files. The bundled library's original third-party license and author notices are retained in `src/pytorch_tabular/`. Other future-study files remain only because existing tests import them. They are not instructions to run those studies.
