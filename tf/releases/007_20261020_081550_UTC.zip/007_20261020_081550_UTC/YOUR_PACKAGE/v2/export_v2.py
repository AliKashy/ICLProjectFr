"""V2 embedding export (lean plan L4.1 under governing plan section 9; step 0 module 5). 2026-10-19.

Exports, per scored row, exactly the vector the fraud head consumes, through the scorer's windows and policy
(YOUR_PACKAGE/v2/scripts/score_v2.py): seq_CLS for default B; for a chunk model, the target slot of its target-ending
window only (amendment 9), with the checkpoint's window cap. The vector is captured with a forward pre-hook on
``model.head``. The label column is never read (label-free builders, plan review item V4-C4): the target position is the last
real slot of each window. The export holds ids, the score, ``window_rows`` and ``e_0 ... e_{d-1}``.

Checks written to ``validation.json``: one row per scored row, unique ids, finite values, the embedding width,
and same-pass reconstruction (softmax(head(e))[:, 1] against the pass's own score, at most 1e-6). Repeat
extraction and batch-composition invariance (a different eval batch for both model kinds) are tested on fake
data (YOUR_PACKAGE/v2/tests/test_export_v2.py). The manifest records absolute paths, the device, the checkpoint's
sequence contract and the predictor list's hash, and the export is appended to the run's ``run_manifest_v2.json``
(``exported``), which makes that run final like a scored one (end-to-end review 2026-10-20, EMB-05, EMB-06).

Usage:
    python -m YOUR_PACKAGE.v2.export_v2 --config <resolved yaml> --checkpoint <ckpt> --out <new folder>
        [dotlist overrides, e.g. eval.base=... eval.file_start=... eval.file_end=...]
"""
import argparse
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import torch
from omegaconf import OmegaConf

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from YOUR_PACKAGE.v2.scripts.score_v2 import load_for_scoring, record_scoring  # noqa: E402
from YOUR_PACKAGE.v2.scripts.train_v2 import eval_batch_size, sha256, source_sha256, utc_now, write_json  # noqa: E402

RECONSTRUCTION_TOLERANCE = 1e-6


def target_slots(batch, chunk):
    """Each window's target position from its structure alone: the last real slot (no label is consulted)."""
    return None if not chunk else batch["mask"].sum(1) - 1


def head_input_rows(head_input, batch, chunk):
    """The head input of each scored row: seq_CLS [B, d], or the target slot of each window."""
    if not chunk:
        return head_input
    slot = target_slots(batch, chunk)
    return head_input[torch.arange(head_input.shape[0]), slot.to(head_input.device)]


def rows_out(logits, batch, chunk, id_cols):
    """(probability, ids) of each scored row, selected by window structure."""
    if not chunk:
        prob = torch.softmax(logits, dim=-1)[:, 1].numpy()
        return prob, {c: np.asarray(batch["meta"][c]) for c in id_cols}
    slot = target_slots(batch, chunk)
    rows = torch.arange(logits.shape[0])
    prob = torch.softmax(logits[rows, slot], dim=-1)[:, 1].numpy()
    k = slot.numpy()
    return prob, {c: np.asarray(batch["meta_seq"][c])[np.arange(len(k)), k] for c in id_cols}


def export(cfg, checkpoint, out):
    """Write ``out``/embeddings.parquet, manifest.json and validation.json; returns the validation dict."""
    if os.path.exists(out):
        raise FileExistsError(f"{out} exists; every export writes a new folder")
    run = load_for_scoring(cfg, checkpoint, label_free=True)
    model, loader, device, chunk = run["model"], run["loader"], run["device"], run["chunk"]
    captured = {}
    handle = model.head.register_forward_pre_hook(lambda module, inputs: captured.__setitem__("x", inputs[0]))
    ids = {c: [] for c in run["id_cols"]}
    scores, vectors, widths, recon = [], [], [], 0.0
    try:
        for batch in loader:
            with torch.no_grad():
                inputs = {k: batch[k].to(device) for k in ("continuous", "categorical", "mask")}
                if "time_seq" in batch:
                    inputs["time_seq"] = batch["time_seq"].to(device)
                logits = model(inputs).cpu()
                e = head_input_rows(captured["x"], batch, chunk)
                again = torch.softmax(model.head(e), dim=-1)[:, 1].cpu().numpy()
            prob, meta = rows_out(logits, batch, chunk, run["id_cols"])
            recon = max(recon, float(np.max(np.abs(again - prob))))
            scores.append(prob)
            vectors.append(e.float().cpu().numpy())
            widths.append(batch["mask"].sum(1).numpy())
            for c in ids:
                ids[c].append(np.asarray(meta[c]))
    finally:
        handle.remove()
    if not scores:
        raise ValueError("The file range produced no transactions")
    if sha256(checkpoint) != run["checkpoint_hash"]:
        raise ValueError("Checkpoint changed during export; refusing to attribute these vectors")

    emb = np.concatenate(vectors).astype(np.float32)
    table = {c: np.concatenate(v) for c, v in ids.items()}
    table["score"] = np.concatenate(scores)
    table["window_rows"] = np.concatenate(widths).astype(np.int64)
    for j in range(emb.shape[1]):
        table[f"e_{j}"] = emb[:, j]
    width = int(model.hparams.embed_dim)
    keys = pd.DataFrame({c: table[c] for c in run["id_cols"]})
    validation = {
        "rows": int(len(emb)), "embedding_width": int(emb.shape[1]), "expected_width": width,
        "unique_ids": bool(not keys.isna().any().any() and not keys.duplicated().any()),
        "finite": bool(np.isfinite(emb).all()),
        "same_pass_reconstruction_max_abs": recon, "reconstruction_tolerance": RECONSTRUCTION_TOLERANCE,
    }
    validation["passed"] = bool(validation["unique_ids"] and validation["finite"] and emb.shape[1] == width
                                and recon <= RECONSTRUCTION_TOLERANCE)
    os.makedirs(out)
    pq.write_table(pa.table(table), os.path.join(out, "embeddings.parquet"))
    resolved = os.path.abspath(os.path.join(out, "resolved_export_v2.yaml"))  # absolute: the consumer hashes it from any cwd
    OmegaConf.save(cfg, resolved, resolve=True)
    predictors = cfg.predictors.csv_path
    manifest = {
        "utc": utc_now(), "checkpoint": os.path.abspath(checkpoint), "checkpoint_sha256": run["checkpoint_hash"],
        "config": resolved, "config_sha256": sha256(resolved), "source_sha256": source_sha256(),
        "artifacts": {"base": cfg.artifacts.base, "version": cfg.artifacts.version},
        "predictors_csv": predictors, "predictors_sha256": sha256(predictors) if os.path.isfile(predictors) else None,
        "validation_policy": run["ckpt"].get("validation_policy"), "max_window_rows": run["cap"],
        "sequence_contract": run["ckpt"].get("sequence_contract"), "history_len": int(cfg.sequence.history_len),
        "extraction": "target slot of each target-ending window" if chunk else "seq_CLS (single target)",
        "files": {"base": cfg.eval.base, "start": int(cfg.eval.file_start), "end": int(cfg.eval.file_end)},
        "rows": int(len(emb)), "embedding_width": int(emb.shape[1]),
        "id_columns": {c: str(keys[c].dtype) for c in run["id_cols"]},
        "eval_batch_size": eval_batch_size(cfg), "torch": torch.__version__, "cuda": torch.version.cuda,
        "device": torch.cuda.get_device_name(device) if str(device).startswith("cuda") else "cpu",
        "embeddings_sha256": sha256(os.path.join(out, "embeddings.parquet")), "labels_written": False,
        "labels_read": False, "precision": "float32, no autocast",
        "vector": "the input to model.head: the residual-stream output of the last sequence block, float32, not normalised",
    }
    write_json(os.path.join(out, "manifest.json"), manifest)
    write_json(os.path.join(out, "validation.json"), validation)
    if not validation["passed"]:
        raise ValueError(f"Export validation failed: {validation}")
    # The run whose checkpoint was exported is final, like a scored one (train_v2 refuses to resume it).
    record_scoring(checkpoint, {"kind": "export", "utc": manifest["utc"], "out": os.path.abspath(out),
                                "embeddings_sha256": manifest["embeddings_sha256"], "files": manifest["files"]},
                   key="exported")
    return validation


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("overrides", nargs="*")
    args = parser.parse_args(argv)
    cfg = OmegaConf.load(args.config)
    if args.overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(args.overrides))
    export(cfg, args.checkpoint, args.out)


if __name__ == "__main__":
    main()
