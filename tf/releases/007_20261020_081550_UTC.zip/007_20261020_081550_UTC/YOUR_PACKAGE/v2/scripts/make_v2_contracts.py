"""Writes the JSON and identity files the V2 consumers need, from the files the runs produced, so none of it is
typed by hand (end-to-end review 2026-10-20, EMB-13, EMB-14, EMB-16). 2026-10-20.

Every hash is the SHA-256 of file bytes, read through the same S3 helper the consumers use. Nothing here reads a
label or a score; nothing trains. Each subcommand writes one new file (an existing path is refused).

    encoder        encoder_contract.json for one run folder: checkpoint and resolved-config pins, artifact version with
                   manifest.json and every feature__*.json pinned, scoring_policy from the checkpoint (null for default B)
    identity       identity_rows_<ROLE>.parquet: the id and account columns of a split role's raw files, raw dtypes kept
    downstream     downstream.json from split_v2.yaml, the encoder contract and the export folders
    code-manifest  code_manifest.json: path and SHA-256 of every runtime source file (YOUR_PACKAGE.source_identity)
    freeze         FROZEN_MODEL.json from the encoder contract, the split, the code manifest and the selected consumer;
                   verified with benchmark_v2.verify_freeze before it is written
    bench-targets  the benchmark cohort with its history depth: the bank's benchmark parquet joined, on (id, account),
                   to the strictly-earlier-row count computed over the raw evaluation files (row-level; stays on the pod)
    benchmark      benchmark.json for benchmark_v2 (plumbing first; --compare later with the freeze)
    handover       handover_manifest.json: every file the bank receives, with SHA-256 and the cross-links checked

Usage (from the project root, with the V1 venv's python; the runbook gives each line with its real paths):
    $PY -m YOUR_PACKAGE.v2.scripts.make_v2_contracts encoder --run-dir runs/v2/B05 --cred-path $CRED --out runs/v2/contracts/encoder_contract.json
    $PY -m YOUR_PACKAGE.v2.scripts.make_v2_contracts identity --split runs/v2/step1/L2_selected/split_v2.yaml --role SELECT \\
        --cred-path $CRED --out runs/v2/contracts/identity_rows_SELECT.parquet
"""
import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq
import yaml
from omegaconf import OmegaConf

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from fraud.data.s3_utils import strip_scheme  # noqa: E402
from YOUR_PACKAGE.v2.storage import thin_read_filesystem  # noqa: E402
from YOUR_PACKAGE.source_identity import runtime_source_files  # noqa: E402
from YOUR_PACKAGE.v2.benchmark_v2 import digest, read_json, verify_freeze  # noqa: E402
from YOUR_PACKAGE.v2.downstream_xgb import encoder_pin_identity, verify_export_inputs  # noqa: E402
from YOUR_PACKAGE.v2.scripts.check_v1_source import MODEL_PATH_FILES  # noqa: E402

ID, ACCOUNT, TIME, LABEL, AMOUNT, DEPTH = ("fi_transaction_id", "Nmap_account_reference_xid", "transaction_dttm", "frd_tag",
                                          "transaction_amt", "prior_rows")
PREDICTORS = "YOUR_PACKAGE/v2/configs/predictors_nomonth.csv"
RUN_MANIFEST = "run_manifest_v2.json"
# The files whose change would change the model's numbers: V1's model path plus the V2 wrappers and entry points, the
# import closure of train_v2, score_v2 and export_v2 (test_contracts_and_facts recomputes it and checks this list covers it).
MODEL_PATH_FILES_V2 = MODEL_PATH_FILES + [
    "YOUR_PACKAGE/source_identity.py", "YOUR_PACKAGE/v2/__init__.py", "YOUR_PACKAGE/v2/export_v2.py", "YOUR_PACKAGE/v2/models.py",
    "YOUR_PACKAGE/v2/scripts/__init__.py", "YOUR_PACKAGE/v2/scripts/score_v2.py", "YOUR_PACKAGE/v2/scripts/train_v2.py", "YOUR_PACKAGE/v2/target_ending.py"]


def is_remote(path):
    return str(path).startswith(("s3://", "s3a://"))


def write_new_json(path, obj):
    path = Path(path)
    if path.exists():
        raise FileExistsError(f"{path} exists; every contract is a new file")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")
    return str(path)


def pin(path, fs=None):
    return {"path": str(path), "sha256": digest(str(path), fs)}


def load_checkpoint(path):
    import torch
    return torch.load(path, map_location="cpu", weights_only=False)


def artifact_files(base, version, fs=None):
    """manifest.json and every feature file the model reads, in the order verify_export_inputs expects them."""
    root = f"{str(base).rstrip('/')}/{version}"
    manifest = read_json(f"{root}/manifest.json", fs)
    return [f"{root}/manifest.json"] + [f"{root}/feature__{name}.json" for name in manifest["features"]]


def run_facts(run_dir):
    run_dir = Path(run_dir)
    manifest = json.loads((run_dir / RUN_MANIFEST).read_text(encoding="utf-8"))
    config = manifest["start"]["config"]
    own = run_dir / Path(config).name  # the run folder's own copy first: the recorded path is relative to the cwd the run had
    if own.is_file():
        config = str(own)
    elif not Path(config).is_file():
        raise FileNotFoundError(f"{config} (recorded in {run_dir / RUN_MANIFEST}) is not a file and the run folder holds no {own.name}")
    return run_dir, manifest, os.path.abspath(config)


def encoder_contract(run_dir, cred_path=None, checkpoint=None, expect_checkpoint_sha256=None):
    fs = thin_read_filesystem(cred_path)
    run_dir, manifest, config_path = run_facts(run_dir)
    checkpoint = os.path.abspath(checkpoint or run_dir / "best.ckpt")
    cfg = OmegaConf.load(config_path)
    ckpt = load_checkpoint(checkpoint)
    recorded = (manifest.get("checkpoints") or {}).get("best.ckpt", {}).get("sha256")
    actual = digest(checkpoint)
    if expect_checkpoint_sha256 and actual != expect_checkpoint_sha256.lower():  # a wrong run name (B05 for C05) is refused here
        raise ValueError(f"{checkpoint} has SHA-256 {actual[:12]}..., not the {expect_checkpoint_sha256[:12]}... DECISIONS names for the base")
    if recorded and recorded != actual and os.path.basename(checkpoint) == "best.ckpt":
        raise ValueError(f"{checkpoint} differs from the run manifest's recorded best.ckpt ({recorded[:12]}...)")
    files = artifact_files(cfg.artifacts.base, cfg.artifacts.version, fs)
    contract = {"checkpoint": {"path": checkpoint, "sha256": actual}, "config": pin(config_path),
                "artifacts": {"version": cfg.artifacts.version, "files": [pin(p, fs) for p in files]},
                "scoring_policy": ckpt.get("validation_policy"),
                "run": {"dir": str(run_dir), "status": manifest.get("status"), "epochs_run": manifest.get("epochs_run"),
                        "seed": manifest["start"].get("seed"), "source_sha256": manifest["start"].get("source_sha256"),
                        "history_len": int(cfg.sequence.history_len), "model": cfg.model.get("type")}}
    encoder_pin_identity(contract, fs)  # every pin is re-read and hashed before the file is written
    return contract


def role(split, name):
    pops = split["populations"]
    if name not in pops or not pops[name].get("paths"):
        raise ValueError(f"split_v2.yaml has no file list for {name}; choose from {sorted(pops)}")
    return pops[name]


def june_bounds(population):
    month = population.get("target_month")
    if not month:
        raise ValueError("the role has no target month")
    year, mon = int(month[:4]), int(month[5:7])
    nxt = f"{year + 1}-01-01" if mon == 12 else f"{year}-{mon + 1:02d}-01"
    return f"{month}-01", nxt


def identity_rows(split_path, role_name, out, cred_path=None, key=ID, account=ACCOUNT):
    """The id and account columns of every raw file of a role, raw dtypes kept, so benchmark_v2 can compare
    representations (a downstream predictions file holds text ids and cannot serve, EMB-14)."""
    fs = thin_read_filesystem(cred_path)
    split = yaml.safe_load(Path(split_path).read_text(encoding="utf-8"))
    paths = role(split, role_name)["paths"]
    tables, drift = [], []
    for path in paths:
        pf = pq.ParquetFile(strip_scheme(path), filesystem=fs if is_remote(path) else None)
        missing = [c for c in (key, account) if c not in pf.schema_arrow.names]
        if missing:
            raise ValueError(f"{path} lacks {missing}")
        table = pf.read(columns=[key, account])
        if tables and table.schema != tables[0].schema:  # per-file dtype drift: cast to the first file's types, losslessly or not at all
            found = [str(f.type) for f in table.schema]
            try:
                table = table.cast(tables[0].schema)
            except (pa.ArrowInvalid, pa.ArrowNotImplementedError, pa.ArrowTypeError) as exc:
                raise ValueError(f"{path} stores the id columns as {found} where {paths[0]} has "
                                 f"{[str(f.type) for f in tables[0].schema]}; the cast would lose information") from exc
            drift.append({"path": str(path), "types": found})
        tables.append(table)
    table = pa.concat_tables(tables)
    out = Path(out)
    if out.exists():
        raise FileExistsError(f"{out} exists")
    out.parent.mkdir(parents=True, exist_ok=True)
    pq.write_table(table, out)
    return {"role": role_name, "rows": table.num_rows, "files": len(paths), "columns": {c: str(table.schema.field(c).type) for c in (key, account)},
            "dtype_drift_cast_to_first_file": drift, "out": str(out)}


def downstream_config(split_path, contract_path, export_train, export_select, export_final=None, cred_path=None,
                      predictors=PREDICTORS, seed=42, bootstrap_draws=1000):
    fs = thin_read_filesystem(cred_path)
    split = yaml.safe_load(Path(split_path).read_text(encoding="utf-8"))
    contract = read_json(contract_path)
    cfg = {"key": ID, "account": ACCOUNT, "label": LABEL, "time": TIME, "depth": DEPTH,
           "predictors": str(predictors), "predictor_version": 1, "seed": seed, "bootstrap_draws": bootstrap_draws,
           "pca_components": [8, 16],
           "train": {"raw": list(role(split, "DS_TRAIN")["paths"]), "export": str(export_train)},
           "select": {"raw": list(role(split, "DS_SELECT")["paths"]), "export": str(export_select)},
           "encoder_contract": {k: contract[k] for k in ("checkpoint", "config", "artifacts", "scoring_policy")},
           "split": pin(split_path)}
    cfg["select"]["target_start"], cfg["select"]["target_end"] = june_bounds(role(split, "DS_SELECT"))
    if export_final:
        cfg["final"] = {"raw": list(role(split, "FINAL")["paths"]), "export": str(export_final)}
        cfg["final"]["target_start"], cfg["final"]["target_end"] = june_bounds(role(split, "FINAL"))
    if cred_path:
        cfg["s3_cred_path"] = cred_path
    for folder in [export_train, export_select] + ([export_final] if export_final else []):
        manifest = read_json(str(folder).rstrip("/") + "/manifest.json", fs)
        verify_export_inputs(manifest, cfg["encoder_contract"], fs)  # the exports really come from this encoder
        if manifest["checkpoint_sha256"] != contract["checkpoint"]["sha256"]:
            raise ValueError(f"{folder}: export checkpoint differs from the encoder contract")
    return cfg


def code_manifest():
    """The same file set and digest as train_v2.source_sha256 (recorded in every run manifest), so the freeze's
    code pin can be checked against the code the run executed."""
    files = {p.relative_to(ROOT).as_posix(): digest(str(p)) for p in runtime_source_files(ROOT)
             if "/tests/" not in p.relative_to(ROOT).as_posix()}
    combined = hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest()
    return {"root": str(ROOT), "files": files, "count": len(files), "combined_sha256": combined,
            "rule": "YOUR_PACKAGE.source_identity.runtime_source_files without tests: fraud/ and YOUR_PACKAGE/ Python files, pyproject.toml, "
                    "requirements.txt; equals train_v2.source_sha256()"}


def freeze(contract_path, split_path, code_manifest_path, bundle_path, arm, out, cred_path=None):
    fs = thin_read_filesystem(cred_path)
    contract = read_json(contract_path)
    frozen = {"schema_version": 1,
              "encoder": {k: contract[k] for k in ("checkpoint", "config", "artifacts", "scoring_policy")},
              "split": pin(split_path), "code": pin(code_manifest_path),
              "downstream": {"bundle": pin(bundle_path), "arm": arm},
              "run": contract.get("run")}
    # written under a temporary name, verified (every pin re-read and re-hashed), then given its name: a failed
    # verification leaves nothing behind, so the next attempt is not refused as "exists"
    out = Path(out)
    if out.exists():
        raise FileExistsError(f"{out} exists")
    temp = out.with_name(out.name + ".unverified")
    if temp.exists():
        temp.unlink()
    path = write_new_json(temp, frozen)
    try:
        verify_freeze(path, fs, require_downstream=True)
    except Exception:
        temp.unlink(missing_ok=True)
        raise
    temp.replace(out)
    return frozen


def benchmark_config(bench_targets, ft_scores, ft_receipt, out_identity, other_scores=(), label=LABEL, amount=AMOUNT,
                     depth=DEPTH, cred_path=None, provenance="unknown; no held-out incumbent claim", bootstrap_draws=1000):
    """other_scores: NAME=PATH:SCORE_COLUMN[:LABEL_COLUMN[:AMOUNT_COLUMN]]; out_identity: ROLE=identity parquet."""
    cfg = {"key": ID, "account": ACCOUNT, "label": label, "amount": amount, "depth": depth,
           "targets": str(bench_targets), "bootstrap_draws": bootstrap_draws,
           "scores": {"ft": {"paths": str(ft_scores), "score": "score", "label": label, "amount": amount}},
           "ft_receipt": str(ft_receipt), "other_roles": {}, "incumbent_training_provenance": provenance}
    for spec in other_scores:
        name, _, rest = spec.partition("=")
        head, sep, tail = rest.partition("://")  # an s3:// path keeps its scheme; only what follows it is split on ':'
        parts = (tail if sep else rest).split(":")
        if not name or not sep and not head or len(parts) < 2 or not parts[0] or not parts[1]:
            raise ValueError(f"--other-score {spec!r}: expected NAME=PATH:SCORE_COLUMN[:LABEL_COLUMN[:AMOUNT_COLUMN]]")
        cfg["scores"][name] = {"paths": (head + sep + parts[0]) if sep else parts[0], "score": parts[1],
                               "label": parts[2] if len(parts) > 2 else label, "amount": parts[3] if len(parts) > 3 else amount}
    for spec in out_identity:
        role_name, path = spec.split("=", 1)
        cfg["other_roles"][role_name] = path
    if cred_path:
        cfg["s3_cred_path"] = cred_path
    return cfg


def bench_targets(bench_path, raw_base, start, end, out, cred_path=None, key=ID, account=ACCOUNT, time=TIME, depth=DEPTH):
    """benchmark_v2's comparison needs each target's full-history depth (amendment 2). It is counted the way the
    consumers count it (V1's _history_counts: strictly earlier timestamps of the account inside its raw file) over
    the raw evaluation files, and joined to the bank's benchmark rows on the lossless (id, account) keys. Duplicates
    follow the consumers' rule (benchmark_v2.exact_unique): an exact copy of a row is dropped and counted, a conflicting
    copy is refused. Writes the joined parquet (row-level, pod only) and a counts-only JSON beside it."""
    import pandas as pd
    from fraud.data.s3_utils import build_file_list
    from YOUR_PACKAGE.scoring.temporal_eval import HISTORY_COL, _history_counts
    from YOUR_PACKAGE.v2.benchmark_v2 import canonical_ids, duplicate_summary, exact_unique, read_table

    fs = thin_read_filesystem(cred_path)
    out = Path(out)
    if out.exists():
        raise FileExistsError(f"{out} exists")
    bench = read_table(str(bench_path), fs)
    if depth in bench.columns:
        raise ValueError(f"{bench_path} already has a {depth} column")
    bench["_id"] = canonical_ids(bench[key], "benchmark ids")[0].astype(str)
    bench["_acct"] = canonical_ids(bench[account], "benchmark accounts")[0].astype(str)
    audit, targets_read = [], int(len(bench))
    bench = exact_unique(bench, ["_id", "_acct"], "benchmark", audit)  # exact duplicate target rows dropped and audited; conflicting ones refused
    pieces, within_file = [], 0
    for path in build_file_list(str(raw_base), int(start), int(end)):
        pf = pq.ParquetFile(strip_scheme(path), filesystem=fs if is_remote(path) else None)
        raw = pf.read(columns=[key, account, time]).to_pandas()
        raw["_id"] = canonical_ids(raw[key], "raw ids")[0].astype(str)
        raw["_acct"] = canonical_ids(raw[account], "raw accounts")[0].astype(str)
        dup = raw.duplicated(["_id", "_acct"], keep=False)
        if dup.any():
            stamps = raw[dup].groupby(["_id", "_acct"], sort=False)[time].nunique(dropna=False)
            if (stamps > 1).any():
                raise ValueError(f"{path}: {int((stamps > 1).sum())} (id, account) pairs occur more than once with different timestamps; "
                                 "their depth is ambiguous, and the consumers refuse conflicting copies")
            within_file += int(dup.sum()) - int(len(stamps))
            raw = raw.drop_duplicates(["_id", "_acct"]).reset_index(drop=True)  # exact copies: the consumers keep one row
        counted = _history_counts(raw, key, account, time)
        pieces.append(pd.DataFrame({"_id": raw["_id"].to_numpy(), "_acct": raw["_acct"].to_numpy(),
                                    depth: counted[HISTORY_COL].to_numpy(), "_file": str(path)}))
    history = pd.concat(pieces, ignore_index=True)
    across = history.duplicated(["_id", "_acct"], keep=False)
    if across.any():
        raise ValueError(f"{int(across.sum()) // 2} (id, account) pairs occur in two scanned raw files; one target cannot carry two depths")
    accounts_in_two_files = int((history.groupby("_acct", sort=False)["_file"].nunique() > 1).sum())
    joined = bench.merge(history.drop(columns=["_file"]), on=["_id", "_acct"], how="left", validate="one_to_one")
    matched = int(joined[depth].notna().sum())
    joined = joined.drop(columns=["_id", "_acct"])
    out.parent.mkdir(parents=True, exist_ok=True)
    joined.to_parquet(out, index=False)
    summary = {"benchmark": str(bench_path), "raw_base": str(raw_base), "files": [int(start), int(end)], "targets_read": targets_read,
               "targets": int(len(bench)), "benchmark_exact_duplicate_rows_dropped": targets_read - int(len(bench)),
               "raw_within_file_exact_duplicates_dropped": within_file, "accounts_in_more_than_one_scanned_file": accounts_in_two_files,
               "duplicates": duplicate_summary(audit), "with_depth": matched, "without_depth": int(len(bench) - matched),
               "note": "rows without depth are benchmark targets whose raw row is not in the scanned files; benchmark_v2 "
                       "needs every target's depth, so widen --end or stop and send. An account seen in more than one scanned "
                       "file has its depth counted inside each file, as the consumers count it"}
    write_new_json(str(out) + ".json", summary)
    return summary


def artifact_payload_sha256(artifacts, feature_names):
    """The same digest YOUR_PACKAGE/base/data/contracts.build_input_contract stores in the checkpoint: the active
    feature entries' JSON, not file bytes."""
    payload = {name: artifacts.features[name] for name in feature_names}
    encoder = json.JSONEncoder(sort_keys=True, separators=(",", ":"), allow_nan=False)
    h = hashlib.sha256()
    for part in encoder.iterencode(payload):
        h.update(part.encode("utf-8"))
    return h.hexdigest()


def handover(frozen_path, run_dir, exports, out, cred_path=None, downstream_report=None):
    """One record of everything the bank receives, with every cross-link checked (EMB-16)."""
    from fraud.data.feature_list import load_feature_list
    from fraud.data.preprocessing import PreprocessingArtifacts

    fs = thin_read_filesystem(cred_path)
    frozen = verify_freeze(frozen_path, fs, require_downstream=True)
    run_dir, run_manifest, config_path = run_facts(run_dir)
    cfg = OmegaConf.load(config_path)
    checkpoint = frozen["encoder"]["checkpoint"]["path"]
    ckpt = load_checkpoint(checkpoint)
    contract = ckpt.get("sequence_contract") or {}
    inputs = contract.get("input_contract", {})
    checks = {}
    checks["checkpoint_sha_equals_run_manifest"] = (run_manifest.get("checkpoints", {}).get(os.path.basename(checkpoint), {}).get("sha256")
                                                     == frozen["encoder"]["checkpoint"]["sha256"])
    checks["config_sha_equals_frozen"] = digest(config_path) == frozen["encoder"]["config"]["sha256"]
    features = load_feature_list(cfg.predictors.csv_path, version=cfg.predictors.version, filesystem=fs)
    artifacts = PreprocessingArtifacts.load(f"{str(cfg.artifacts.base).rstrip('/')}/{cfg.artifacts.version}", filesystem=fs)
    recomputed = artifact_payload_sha256(artifacts, list(features.all_features))
    checks["artifacts_sha256_recomputed_equals_checkpoint"] = recomputed == inputs.get("artifacts_sha256")
    checks["month_absent_from_model_inputs"] = "month" not in inputs.get("categorical_columns", []) and "month" not in list(cfg.datetime.fields)
    checks["frozen_artifact_version_equals_config"] = str(frozen["encoder"]["artifacts"]["version"]) == str(cfg.artifacts.version)
    checks["scoring_policy_equals_checkpoint"] = frozen["encoder"]["scoring_policy"] == ckpt.get("validation_policy")
    code_pin = read_json(frozen["code"]["path"], fs)
    current = code_manifest()
    fit_files = run_manifest["start"].get("source_files") or {}
    pinned_files = code_pin.get("files") or {}
    # The hard check: the files that decide the model's numbers are the ones the fit ran (the handover's tree and the freeze's
    # pin both). The two whole-tree digests are informational: a package update after the final fit changes them by design.
    checks["model_path_unchanged_since_fit"] = bool(fit_files) and all(
        fit_files.get(f) is not None and fit_files.get(f) == current["files"].get(f) for f in MODEL_PATH_FILES_V2)
    checks["frozen_code_manifest_model_path_equals_fit"] = bool(fit_files) and all(
        pinned_files.get(f) == fit_files.get(f) for f in MODEL_PATH_FILES_V2)
    code_information = {
        "model_path_files": MODEL_PATH_FILES_V2, "run_recorded_source_files": bool(fit_files),
        "code_manifest_equals_run_source_sha256": code_pin.get("combined_sha256") == run_manifest["start"].get("source_sha256"),
        "code_manifest_equals_current_tree": code_pin.get("combined_sha256") == current["combined_sha256"],
        "files_changed_since_fit": sorted(f for f in set(fit_files) | set(current["files"]) if fit_files.get(f) != current["files"].get(f)),
        "files_changed_since_freeze": sorted(f for f in set(pinned_files) | set(current["files"]) if pinned_files.get(f) != current["files"].get(f)),
        "note": "a package update after the final fit changes the two digests by design; the model-path files are the ones that must not change"}
    export_records = []
    for folder in exports:
        folder = str(folder).rstrip("/")
        manifest = read_json(folder + "/manifest.json", fs)
        validation = read_json(folder + "/validation.json", fs)
        export_records.append({
            "folder": folder, "manifest_sha256": digest(folder + "/manifest.json", fs),
            "embeddings_sha256": manifest["embeddings_sha256"], "rows": validation.get("rows"),
            "embedding_width": validation.get("embedding_width"), "files": manifest.get("files"),
            "checkpoint_sha256_matches_frozen": manifest["checkpoint_sha256"] == frozen["encoder"]["checkpoint"]["sha256"],
            "policy_matches_frozen": manifest.get("validation_policy") == frozen["encoder"]["scoring_policy"],
            "validation_passed": validation.get("passed") is True, "device": manifest.get("device"),
            "eval_batch_size": manifest.get("eval_batch_size")})
    checks["every_export_from_frozen_encoder"] = all(r["checkpoint_sha256_matches_frozen"] and r["policy_matches_frozen"]
                                                     and r["validation_passed"] for r in export_records)
    predictors_path = str(cfg.predictors.csv_path)
    record = {
        "frozen": pin(frozen_path), "encoder": {
            "checkpoint": {**frozen["encoder"]["checkpoint"], "size_bytes": os.path.getsize(checkpoint)},
            "config": frozen["encoder"]["config"], "artifacts": frozen["encoder"]["artifacts"],
            "scoring_policy": frozen["encoder"]["scoring_policy"],
            "predictors": pin(predictors_path, fs) if os.path.isfile(predictors_path) else {"path": predictors_path},
            "hyper_parameters": {k: ckpt.get("hyper_parameters", {}).get(k) for k in ("history_len", "embed_dim", "input_embed_dim")},
            "sequence_contract": {"architecture": contract.get("architecture", {}).get("name") if isinstance(contract.get("architecture"), dict) else None,
                                  "continuous_columns": inputs.get("continuous_columns"), "categorical_columns": inputs.get("categorical_columns"),
                                  "history_time_order": inputs.get("history_time_order"), "artifacts_sha256": inputs.get("artifacts_sha256"),
                                  "datetime": inputs.get("datetime"), "all_position_time_policy": contract.get("all_position_time_policy")},
            "run_manifest": {"path": str(run_dir / RUN_MANIFEST), "status": run_manifest.get("status"), "epochs_run": run_manifest.get("epochs_run"),
                             "optimizer_steps": run_manifest.get("optimizer_steps"), "seed": run_manifest["start"].get("seed"),
                             "deterministic_in_force": run_manifest["start"].get("deterministic_in_force"),
                             "source_sha256": run_manifest["start"].get("source_sha256"), "scored": len(run_manifest.get("scored", [])),
                             "exported": len(run_manifest.get("exported", []))}},
        "exports": export_records, "downstream": {**frozen["downstream"], "report": pin(downstream_report) if downstream_report else None},
        "split": frozen["split"], "code": frozen["code"],
        "serving_contract": {
            "model": cfg.model.get("type"), "history": f"up to {int(cfg.sequence.history_len)} earlier "
            + ("occupied whole seconds of the account (every row of those seconds), window capped at "
               f"{(ckpt.get('validation_policy') or {}).get('max_window_rows')} rows, most recent rows kept"
               if ckpt.get("validation_policy") else "rows of the account (exactly that many, padded when fewer)"),
            "same_second_rule": "a transaction with the same timestamp as the scored one is never its history "
                                f"(history_time_order={inputs.get('history_time_order')})",
            "ordering": f"{cfg.data.order_col}, then {cfg.data.get('tie_break_col')}",
            "raw_inputs": [c for c in inputs.get("continuous_columns", []) if c != "time_delta"] + [c for c in inputs.get("categorical_columns", [])
                                                                                                    if not c.endswith("_isna") and c not in ("day", "hour", "day_of_week")],
            "derived_inputs": {"from_time": [f for f in cfg.datetime.fields], "time_gap": "log1p(seconds since the previous history row)",
                               "missing_flags": [c for c in inputs.get("categorical_columns", []) if c.endswith("_isna")]},
            "preprocessing": f"artifact version {cfg.artifacts.version}: median imputation and standardisation of continuous fields, "
                             "vocabularies for categorical fields (unknown code -> UNK, missing -> MISSING), fit on training files 1-5",
            "scoring_precision": "float32, no autocast", "score": "softmax(head(vector))[fraud]",
            "vector": "float32, the input to the fraud head (residual stream of the last sequence block), not normalised; "
                      "the downstream consumer applies its own scaler fit on DS_TRAIN",
            "id_columns": list(cfg.data.get("id_cols", [])),
            "not_validated": ["depth 0 for genuinely new accounts (audit finding 36)", "same-second visibility at authorisation (public question 11)",
                              "the clock behind transaction_dttm (public question 15)"]},
        "code_information": code_information, "checks": checks, "all_checks_pass": all(checks.values())}
    write_new_json(out, record)
    return record


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="command", required=True)
    s = sub.add_parser("encoder")
    s.add_argument("--run-dir", required=True)
    s.add_argument("--checkpoint", default=None, help="default <run-dir>/best.ckpt")
    s.add_argument("--expect-checkpoint-sha256", default=None, help="the base checkpoint's SHA-256 from DECISIONS section 15; a different file is refused")
    s.add_argument("--cred-path", default=None)
    s.add_argument("--out", required=True)
    s = sub.add_parser("identity")
    s.add_argument("--split", required=True)
    s.add_argument("--role", required=True)
    s.add_argument("--cred-path", default=None)
    s.add_argument("--out", required=True)
    s = sub.add_parser("downstream")
    s.add_argument("--split", required=True)
    s.add_argument("--contract", required=True)
    s.add_argument("--export-train", required=True)
    s.add_argument("--export-select", required=True)
    s.add_argument("--export-final", default=None)
    s.add_argument("--cred-path", default=None)
    s.add_argument("--predictors", default=PREDICTORS)
    s.add_argument("--out", required=True)
    s = sub.add_parser("code-manifest")
    s.add_argument("--out", required=True)
    s = sub.add_parser("freeze")
    s.add_argument("--contract", required=True)
    s.add_argument("--split", required=True)
    s.add_argument("--code-manifest", required=True)
    s.add_argument("--bundle", required=True, help="the selected consumer.joblib")
    s.add_argument("--arm", required=True)
    s.add_argument("--cred-path", default=None)
    s.add_argument("--out", required=True)
    s = sub.add_parser("bench-targets")
    s.add_argument("--bench", required=True, help="the bank's benchmark parquet (BENCH)")
    s.add_argument("--raw-base", required=True)
    s.add_argument("--start", type=int, required=True)
    s.add_argument("--end", type=int, required=True)
    s.add_argument("--cred-path", default=None)
    s.add_argument("--out", required=True)
    s = sub.add_parser("benchmark")
    s.add_argument("--targets", required=True, help="the benchmark cohort with depth (bench-targets output)")
    s.add_argument("--ft-scores", required=True, help="score_v2's prediction parquet on BENCH")
    s.add_argument("--ft-receipt", required=True)
    s.add_argument("--other-score", action="append", default=[], help="NAME=PATH:SCORE_COLUMN[:LABEL[:AMOUNT]]")
    s.add_argument("--identity", action="append", default=[], help="ROLE=identity_rows_ROLE.parquet")
    s.add_argument("--label", default=LABEL)
    s.add_argument("--amount", default=AMOUNT)
    s.add_argument("--depth", default=DEPTH)
    s.add_argument("--provenance", default="unknown; no held-out incumbent claim")
    s.add_argument("--cred-path", default=None)
    s.add_argument("--out", required=True)
    s = sub.add_parser("handover")
    s.add_argument("--frozen", required=True)
    s.add_argument("--run-dir", required=True)
    s.add_argument("--export", action="append", default=[], help="an export folder (repeat)")
    s.add_argument("--downstream-report", default=None)
    s.add_argument("--cred-path", default=None)
    s.add_argument("--out", required=True)
    a = p.parse_args(argv)
    if a.command == "encoder":
        print(write_new_json(a.out, encoder_contract(a.run_dir, a.cred_path, a.checkpoint, a.expect_checkpoint_sha256)))
    elif a.command == "identity":
        print(json.dumps(identity_rows(a.split, a.role, a.out, a.cred_path)))
    elif a.command == "downstream":
        print(write_new_json(a.out, downstream_config(a.split, a.contract, a.export_train, a.export_select, a.export_final,
                                                      a.cred_path, a.predictors)))
    elif a.command == "code-manifest":
        print(write_new_json(a.out, code_manifest()))
    elif a.command == "freeze":
        freeze(a.contract, a.split, a.code_manifest, a.bundle, a.arm, a.out, a.cred_path)
        print(a.out)
    elif a.command == "bench-targets":
        print(json.dumps(bench_targets(a.bench, a.raw_base, a.start, a.end, a.out, a.cred_path)))
    elif a.command == "benchmark":
        print(write_new_json(a.out, benchmark_config(a.targets, a.ft_scores, a.ft_receipt, a.identity, a.other_score, a.label,
                                                     a.amount, a.depth, a.cred_path, a.provenance)))
    elif a.command == "handover":
        record = handover(a.frozen, a.run_dir, a.export, a.out, a.cred_path, a.downstream_report)
        print(json.dumps({"out": a.out, "all_checks_pass": record["all_checks_pass"], "checks": record["checks"]}, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
