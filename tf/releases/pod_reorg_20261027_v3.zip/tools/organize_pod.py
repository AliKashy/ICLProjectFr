"""Reorganize the tabular_fraud project folder on the pod: one folder per model, one per seed, latest results only.

Run from the project root (the folder that holds fraud/ and your package folder), with the script saved as
tools/organize_pod.py:

    python tools/organize_pod.py plan     # read-only: writes shared/reorg/PLAN.csv, HASHES.csv and REPORT.txt
    python tools/organize_pod.py apply    # moves exactly what PLAN.csv lists; never deletes a file
    python tools/organize_pod.py verify   # re-hashes every checkpoint and prediction at its new path

Target layout (owner rules of 2026-10-27):

    models/<model>/seed<NN>/   that model and seed: its run folder (checkpoint, config, metrics, manifest),
                               launch_config.yaml and scores/ (its latest score receipts and predictions)
    shared/                    things several models use: populations, data look, measurements, comparisons, logs,
                               code history (pod patches, install receipts), env.sh, and this reorganization's records
    tools/                     the hand-run pod scripts
    archive/<original path>    everything superseded: earlier attempts, failed retries, package copies
    code (your package folder, fraud/, src/, runbook/, tests/ and the package files) stays exactly where it is

Your package folder is found by itself: the one folder at the root holding v2/ beside phase4b/ or scoring/.
If more than one qualifies, name it: POD_PACKAGE=<folder> python tools/organize_pod.py plan

Safety:
- Before its first move, "apply" checks everything: no training, scoring or export process running; REPORT.txt free
  of conflicts and belonging to this PLAN.csv; the pod exactly as it was at "plan" (same rows, same sizes, file counts
  and file times, nothing new); every destination free; every move on the same disk with write access. If any check
  fails, nothing moves. Every move is a rename on the same disk, so file contents never change.
- Nothing is deleted. The only folders removed are ones left empty by the moves. The owner deletes archive/ when satisfied.
- Every move is appended to shared/reorg/MOVES.csv as it happens. If "apply" is interrupted, running it again carries
  on from MOVES.csv; "plan" refuses to run once moves have started, so the first PLAN.csv and HASHES.csv are kept.
- The checkpoint and prediction hashes taken during "plan" are kept in shared/reorg/HASHES.csv; "verify" fails unless
  every planned move is logged, every hash matches at its new path and the old folders are gone.
- Original configs, manifests and receipts keep their bytes. Paths written inside them are the old ones; MOVES.csv maps
  them. Old hand-run readers that hard-code old paths (quick checks, V1 analysis, cpu_reads.sh) are retired.
"""
import csv
import datetime as dt
import hashlib
import json
import os
import re
import subprocess
import sys

def find_package():
    """The owner's package folder at the project root: the one folder holding v2/ beside phase4b/ or scoring/."""
    try:
        names = sorted(os.listdir("."))
    except OSError:
        return None
    hits = [d for d in names if os.path.isdir(os.path.join(d, "v2"))
            and (os.path.isdir(os.path.join(d, "phase4b")) or os.path.isdir(os.path.join(d, "scoring")))]
    return hits[0] if len(hits) == 1 else None


PKG = os.environ.get("POD_PACKAGE") or find_package() or "YOUR_PACKAGE"
PLAN_DIR = os.path.join("shared", "reorg")
PLAN_CSV = os.path.join(PLAN_DIR, "PLAN.csv")
REPORT = os.path.join(PLAN_DIR, "REPORT.txt")
MOVES_CSV = os.path.join(PLAN_DIR, "MOVES.csv")
HASHES_CSV = os.path.join(PLAN_DIR, "HASHES.csv")
FIELDS = ["step", "order", "kind", "old_path", "new_path", "bytes", "files", "newest", "note"]

# The 15 V1 attempts that produced the reported V1 numbers (the V1 report, Appendix A), all seed 42.
V1_RUNS = {
    "ablations/arch_a_flat/history_h0_vs_h5/A-H00-985f76d541644b5fbc5e9267a03f03b9": "arch_a_h0",
    "ablations/arch_a_flat/history_h0_vs_h5/A-H05-d836626fbe0a4d77b0e6f577c5effc49": "arch_a_h5",
    "ablations/arch_a_flat/history_h10/A-H10-33a2d72e1b174d09bcb7465f73a976eb": "arch_a_h10",
    "ablations/arch_a_flat/history_h15/20261013T044303Z-4bcdf2ddbdf940dfa8638239d2c791ab": "arch_a_h15",
    "ablations/arch_a_flat/history_h20/20261013T044636Z-57c3b2c82fc04518b4a1cf4815c40ce3": "arch_a_h20",
    "ablations/arch_a_flat/time_delta_off_h5/A-GAP05-OFF-2f38276bb039427394da7f423626008a": "arch_a_h5_no_time_gap",
    "ablations/arch_a_flat/time_delta_on_vs_off_h10/20261013T050127Z-0416d54e27ce4212a9dbbbc4fef46e17":
        "arch_a_h10_no_time_gap",
    "ablations/arch_a_flat/mask_causal_h5/A-MASK05-C-b398041fd010460782382cde19821a17": "arch_a_h5_causal",
    "ablations/arch_b_hier/history_h0_scored/B-H00-7815ffe1c5164981a37aa0482353ee46": "arch_b_h0_sliding",
    "ablations/arch_b_hier/history_h5_h10/B-H05-e5ea866430004b9c90161d3a48ddc87e": "arch_b_h5_sliding",
    "ablations/arch_b_hier/history_h5_h10/B-H10-8a5832ccf8834b5c96c3bdb600063d47": "arch_b_h10_sliding",
    "ablations/arch_b_hier/history_h15_h20/B-H15-4d71f33d0e9644b4be7211290b2fb50f": "arch_b_h15_sliding",
    "ablations/arch_b_hier/history_h15_h20/B-H20-1dfa4d00fd924637950e7c6f02c3f887": "arch_b_h20_sliding",
    "ablations/arch_b_hier/allposition_strict_h5/B-ALLPOS-H5-8e61fcd6c0c842a3b8e3e9925e995118": "arch_b_h5_chunk",
    "ablations/ref_single/ref_single_seeds/REF-SINGLE-53e82983c61845d7b0544e83d5c3768f": "ref_single",
}
# The score folder each V1 number came from when it was not the runner's own (the V1 run index, "Evaluation source").
# Other folders under post_score/ or manual_score/ in these runs are tries the record did not use.
V1_SCORED_BY = {
    "arch_a_h0": "20261013T142729Z-3e623b2737ec4a8788c658cc128b7330",
    "arch_a_h5": "20261013T142809Z-2632432f71714f19b96c2146a7c6de55",
    "arch_a_h10_no_time_gap": "20261013T142924Z-e83716f0a7904462a90654f888ba642c",
    "arch_b_h15_sliding": "20261013T142741Z",
    "arch_b_h20_sliding": "20261013T142910Z",
}
HAND_SCORED = {"arch_b_h15_sliding", "arch_b_h20_sliding"}  # V1 B-H15 and B-H20: scored outside the run wrapper

# V2 run folders and their launch configs (the 23 October results and the seed results).
V2_RUNS = {
    "runs/v2/L3/ALLPOS_H20_CHUNK": ("arch_b_h20_chunk", "seed42", "runs/v2/L3/allpos_h20_chunk.yaml"),
    "runs/v2/L3/ALLPOS_H20_SLIDE": ("arch_b_h20_chunk_design_trained_sliding", "seed42",
                                    "runs/v2/L3/allpos_h20_slide.yaml"),
    "runs/v2/L3/ALLPOS_H5_SLIDE": ("arch_b_h5_chunk_design_trained_sliding", "seed42",
                                   "runs/v2/L3/allpos_h5_slide.yaml"),
    "runs/v2/seed_robustness/ALLPOS_H20_CHUNK_seed43": ("arch_b_h20_chunk", "seed43", None),
    "runs/v2/seed_robustness/ALLPOS_H20_CHUNK_seed44": ("arch_b_h20_chunk", "seed44", None),
    "runs/v2/seed_robustness/B_H20_seed43": ("arch_b_h20_sliding", "seed43", None),
    "runs/v2/seed_robustness/B_H20_seed44": ("arch_b_h20_sliding", "seed44", None),
}

# Folders that hold the scores of several models: each receipt naming a checkpoint goes to that model's scores/.
SCORE_FOLDERS = {
    "runs/v2/L3/scores_slide": "shared/comparisons/v2_scores_other",
    "runs/v2/arch_a_scores_retry3": "shared/comparisons/arch_a_rescore",
}
# The V1 chunk model's sliding rescore (allpos_sliding_experiment.py): run folders <UTC>_<id> beside LATEST_RUN.
SLIDING_RESCORE = (os.path.join(PKG, "scoring", "allpos_sliding_h5"), "arch_b_h5_chunk", "seed42")

# Shared material, moved whole: (old path, new path).
SHARED = [
    ("runs/v2/step1/L2_selected", "shared/populations/selected"),
    ("runs/v2/L2_inventory", "shared/populations/inventory"),
    ("runs/v2/L3/measure", "shared/measurements"),
    ("runs/v2/L3/paired_inputs_followup", "shared/comparisons/v2_paired_inputs"),
    ("runs/v2/L3/paired_SELECT_followup", "shared/comparisons/v2_paired_holdout"),
    ("runs/v2/L3/paired_DEV_OOT_followup", "shared/comparisons/v2_paired_test1"),
    ("runs/v2/L3/logs", "shared/logs/v2_l3"),
    ("runs/v2/step0_logs", "shared/logs/v2_step0"),
    ("runs/v2/patches", "shared/code_history/pod_patches"),
    ("runs/install", "shared/code_history/installs"),
    ("runs/v2/env.sh", "shared/env.sh"),
    ("runs/run_log.csv", "shared/logs/v1/run_log.csv"),
    ("runs/returns/parallel_v1_005_all", "shared/logs/v1/parallel_v1_005_all"),
    ("runs/paired_report", "shared/comparisons/v1/paired_report"),
    ("runs/paired_report_v1", "shared/comparisons/v1/paired_report_v1"),
    ("runs/paired_report_finalist", "shared/comparisons/v1/paired_report_finalist"),
    ("v1_analysis_outputs", "shared/comparisons/v1/run_table"),
]
# Folder families where only the newest copy is current (names end in a UTC stamp, so sorting by name is by time).
# Families with the same destination compete together: the data look sits in one of three places.
NEWEST_ONLY = [
    ("runs/v2/data_look", "data_look_", "shared/data_look"),
    ("runs/v2/step0", "data_look_", "shared/data_look"),
    ("runs/v2/step1", "data_look_", "shared/data_look"),
    ("runs/returns", "analysis_", "shared/logs/v1/analysis"),
]
STAMP = re.compile(r"\d{8}T\d{6}Z$")  # only real folders named <prefix><UTC stamp> compete; anything else is reported
QUICK_CHECKS = ("runs/returns", "quick_checks_", "shared/logs/v2_quick_checks")  # complementary: keep all
UTC_RETURNS = ("runs/returns", re.compile(r"^\d{8}T\d{6}Z$"), "shared/logs/v1/returns")  # V1 ledger collections
CONSOLE_LOG = re.compile(r".*\.(out|log)$|^nohup\.out$")  # console logs (the seed DONE markers live in one)

# Hand-run pod scripts recorded at the project root; any other loose .py/.sh there also goes to tools/.
TOOLS = ["13_h20_sliding.py", "13_followup.py", "l3_followup.py", "patch_train_v2_sliding.py",
         "patch_target_ending_training.py", "patch_chunk_training_route.py", "score_arch_a_manifest.py",
         "arch_a_holdout.yaml", "merge_model_score_tables.py", "seed_robustness.py", "cpu_reads.sh",
         "seed_fits_block.sh", "verify_remaining.py", "organize_pod.py"]
# The code and package files stay where they are (plus anything git tracks at the root, if the root is a checkout).
KEEP_AT_ROOT = {PKG, "fraud", "src", "runbook", "tests", "docs", "notebooks", "scripts", "pyproject.toml",
                "requirements.txt", "requirements-pod.txt", "README.md", "PACKAGE.json", "PERSONALIZATION.json",
                "install.py", "personalize.py", "test.yaml", "models", "shared", "tools", "archive", "ablations",
                "runs", "__pycache__"}
# Known clutter at the root: package copies, extraction folders, delivery bundles and return zips.
ROOT_CLUTTER = [re.compile(p) for p in (
    r"^\d{3}_\d{8}_\d{6}_UTC(\.zip)?$", r"^\d{3}_personalized\.zip$", r"^tf_packages?$", r"^\.tf_install$",
    r"^L3F_return_.*\.zip$", r"^" + re.escape(PKG) + r"_upload_.*\.zip$", r"^send_reviewer$", r"^v1_full_review_.*\.zip$",
    r"^reviewer_packages$", r"^ALLPOS_H5_SLIDING_PACKAGE\.zip$", r"^pod_reorg_\d{8}(_v\d+)?\.zip$")]
# Processes that must not be running during "apply".
BUSY = (PKG + ".v2", "train_v2", "score_v2", "export_v2", "run_ablations", "train_sequential", "score_sequential",
        "seed_robustness", "parallel_v1", "downstream_xgb", PKG + "/phase4", "allpos_sliding_experiment")
TEXT_LIMIT = 2_000_000  # receipts and operational files are read only below this size


def utc():
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def size(path):
    if os.path.islink(path) or os.path.isfile(path):
        return os.lstat(path).st_size
    total = 0
    for base, _, files in os.walk(path):
        for name in files:
            try:
                total += os.lstat(os.path.join(base, name)).st_size
            except OSError:
                pass
    return total


def measure(path, exclude=()):
    """(bytes, files, newest file time in ns) of a path, leaving out the paths in `exclude` (moved by their own rows)."""
    exclude = set(exclude)
    if os.path.islink(path) or not os.path.isdir(path):
        try:
            st = os.lstat(path)
        except OSError:
            return 0, 0, 0
        return st.st_size, 1, st.st_mtime_ns
    total = count = newest = 0
    for base, dirs, files in os.walk(path):
        dirs[:] = sorted(d for d in dirs if os.path.normpath(os.path.join(base, d)) not in exclude)
        for name in files:
            p = os.path.normpath(os.path.join(base, name))
            if p in exclude:
                continue
            try:
                st = os.lstat(p)
            except OSError:
                continue
            total += st.st_size
            count += 1
            newest = max(newest, st.st_mtime_ns)
    return total, count, newest


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def files_under(path):
    if not os.path.isdir(path) or os.path.islink(path):
        yield os.path.normpath(path)
        return
    for base, dirs, files in os.walk(path):
        dirs.sort()
        for name in sorted(files):
            yield os.path.normpath(os.path.join(base, name))


def read_json(path):
    try:
        if os.path.getsize(path) > TEXT_LIMIT:
            return None
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError, UnicodeDecodeError):
        return None
    return data if isinstance(data, dict) else None


def json_items(data, key=""):
    """Every (key, string value) pair anywhere in a JSON document."""
    if isinstance(data, dict):
        for k, v in data.items():
            yield from json_items(v, str(k))
    elif isinstance(data, list):
        for v in data:
            yield from json_items(v, key)
    elif isinstance(data, str):
        yield key, data


def receipt_checkpoint(data):
    ckpt = (data or {}).get("checkpoint") or (data or {}).get("checkpoint_path")
    return ckpt if isinstance(ckpt, str) else None


def under_root(path):
    """A recorded path (absolute on the pod, or relative) as a path below the project root, when it is one."""
    root = os.getcwd()
    path = os.path.normpath(path)
    if os.path.isabs(path):
        return os.path.relpath(path, root) if path.startswith(root + os.sep) else path
    return path


def owner_of(ckpt, run_dirs):
    """(old run folder, model, seed) whose folder contains this checkpoint path, matched on the path below the root."""
    path = under_root(ckpt)
    for old, (model, seed) in run_dirs.items():
        if path == old or path.startswith(old + os.sep) or ("/" + old + "/") in ("/" + path):
            return old, model, seed
    return None


def ancestors(path):
    p = os.path.dirname(path)
    while p not in ("", ".", os.sep):
        yield p
        p = os.path.dirname(p)


class Plan:
    """Planned moves. Each row has a step: a move into a folder that another row moves runs after that row
    (scores into a run folder's new place), and the last.ckpt rows run last. Within a step, rows run in order, and a
    child is always planned before its parent, so a parent move never carries a child that goes elsewhere."""

    def __init__(self):
        self.rows, self.notes, self.by_old, self.by_after = [], [], {}, {}
        self._ordered = None

    def claimed(self, path):
        """The planned row that moves this path or one of its parents, if any (moves of the original tree only)."""
        p = os.path.normpath(path)
        for q in [p, *ancestors(p)]:
            if q in self.by_old:
                return self.by_old[q]
        return None

    def add(self, kind, old, new, note=""):
        old, new = os.path.normpath(old), os.path.normpath(new)
        if old == new or self.claimed(old):
            return False
        inner = [o for o in self.by_old if o.startswith(old + os.sep)]  # children planned earlier move on their own
        b, n, t = measure(old, inner)
        row = {"order": len(self.rows) + 1, "kind": kind, "old_path": old, "new_path": new, "bytes": b, "files": n,
               "newest": t, "note": note}
        self.rows.append(row)
        self.by_old[old] = row
        self._ordered = None
        return True

    def add_after(self, kind, original, old, new, note=""):
        """A move of something that an earlier move has already carried to `old` (its original path: `original`)."""
        b, n, t = measure(original)
        row = {"order": len(self.rows) + 1, "kind": kind, "old_path": os.path.normpath(old),
               "new_path": os.path.normpath(new), "bytes": b, "files": n, "newest": t, "note": note}
        self.rows.append(row)
        self.by_after[row["old_path"]] = row
        self._ordered = None

    def ordered(self):
        if self._ordered is None:
            dests = {r["new_path"] for r in self.rows}
            for r in self.rows:
                r["step"] = 9 if r["kind"] == "archive_after" else 1 + sum(a in dests for a in ancestors(r["new_path"]))
            self._ordered = sorted(self.rows, key=lambda r: (r["step"], r["order"]))
        return self._ordered

    def final(self, path):
        """Where a path of the original tree ends up after every move: its own move, then any later ones."""
        def moved(p, r):
            return r["new_path"] if p == r["old_path"] else os.path.join(r["new_path"], os.path.relpath(p, r["old_path"]))
        p = os.path.normpath(path)
        r = self.claimed(p)
        if r is not None:
            p = moved(p, r)
        used = set()
        while True:
            r = next((self.by_after[q] for q in [p, *ancestors(p)] if q in self.by_after and q not in used), None)
            if r is None:
                return p
            used.add(r["old_path"])
            p = moved(p, r)

    def note(self, text):
        self.notes.append(text)


def plan_score_folder(plan, folder, leftover_dest, run_dirs):
    """Split a cross-model score folder: each receipt (with its predictions and exposure record) to its model."""
    if not os.path.isdir(folder):
        plan.note(f"absent: {folder}")
        return
    files = list(files_under(folder))
    by_dir = {}
    for p in files:
        by_dir.setdefault(os.path.dirname(p), []).append(os.path.basename(p))
    assigned = {}
    for d, names in by_dir.items():
        for name in names:
            if not name.endswith(".json") or name.endswith(".exposure.json"):
                continue
            data = read_json(os.path.join(d, name))
            owner = owner_of(receipt_checkpoint(data) or "", run_dirs)
            if not owner:
                continue
            stem = name[: -len(".json")]
            for sibling in names:  # the receipt, its predictions and its exposure record travel together
                if sibling == name or sibling == stem or sibling.startswith(stem + "."):
                    assigned[os.path.join(d, sibling)] = owner
            pred = data.get("predictions")
            if isinstance(pred, str) and not pred.startswith("s3:"):
                pred = under_root(pred)
                if pred in files:
                    assigned[pred] = owner
    for p in files:
        sub = os.path.relpath(p, folder)
        if p in assigned:
            _, model, seed = assigned[p]
            plan.add("model", p, os.path.join("models", model, seed, "scores", sub), "score")
        else:
            plan.add("shared", p, os.path.join(leftover_dest, sub), "cross-model or unattributed file")


def plan_v1_score_tries(plan, old, model):
    """In a V1 run, keep the score folder the V1 record used; other post_score/manual_score folders go to the archive."""
    used = V1_SCORED_BY.get(model)
    for base, dirs, _ in os.walk(old):
        dirs.sort()
        if os.path.basename(base) in ("post_score", "manual_score"):
            for d in dirs:
                if d != used:
                    p = os.path.join(base, d)
                    plan.add("archive", p, os.path.join("archive", p), "score try the V1 record did not use")
            dirs[:] = []


def plan_v2_scores(plan, old, model, seed):
    """V2 seed folders hold their own score files (score_*): after the folder moves, gather them in scores/."""
    top = os.path.join("models", model, seed)
    for p in files_under(old):
        if os.path.basename(p).startswith("score_") and not os.path.relpath(p, old).startswith("scores" + os.sep):
            plan.add_after("model", p, os.path.join(top, os.path.relpath(p, old)),
                           os.path.join(top, "scores", os.path.basename(p)), "score")


def plan_sliding_rescore(plan):
    root, model, seed = SLIDING_RESCORE
    if not os.path.isdir(root):
        plan.note(f"absent: {root}")
        return
    runs = sorted(n for n in os.listdir(root) if os.path.isdir(os.path.join(root, n)))
    complete = [n for n in runs if os.path.exists(os.path.join(root, n, "REPORT_COMPLETE"))]
    scored = [n for n in runs if os.path.exists(os.path.join(root, n, "SCORE_COMPLETE"))]
    keep = (complete or scored or runs or [None])[-1]
    pointer = ""
    try:
        with open(os.path.join(root, "LATEST_RUN"), encoding="utf-8") as f:
            pointer = os.path.basename(f.read().strip().rstrip("/"))
    except OSError:
        pass
    if keep:
        status = "report complete" if keep in complete else "score complete only" if keep in scored else "INCOMPLETE"
        plan.note(f"sliding rescore of arch_b_h5_chunk: kept run {keep} ({status}); LATEST_RUN names {pointer or '-'}"
                  + ("" if pointer in ("", keep) else "  CHECK: they differ"))
        plan.add("model", os.path.join(root, keep), os.path.join("models", model, seed, "sliding_rescore"),
                 "sliding rescore, newest complete run")
    for n in sorted(os.listdir(root)):
        p = os.path.join(root, n)
        plan.add("archive", p, os.path.join("archive", p),
                 "pointer to the stamped run folder" if n.startswith("LATEST_RUN") else "earlier or incomplete run")


def plan_hand_scored(plan, folder, model, hashes):
    """V1 B-H15/B-H20: the separate score receipt's checkpoint hash must match this folder's best.ckpt."""
    receipts = [p for p in files_under(folder)
                if os.sep + "manual_score" + os.sep + V1_SCORED_BY[model] + os.sep in p
                and p.endswith("score_metrics.json")]
    if not receipts:
        plan.note(f"{model}: no manual_score/{V1_SCORED_BY[model]}/score_metrics.json found; last.ckpt kept")
        return False
    ckpts = {p: hashes.get(p) or sha256(p) for p in files_under(folder) if p.endswith(".ckpt")}
    ok = True
    for r in receipts:
        want = (read_json(r) or {}).get("checkpoint_sha256")
        hits = [p for p, h in ckpts.items() if want and h == want]
        verdict = ("MATCH " + ", ".join(hits) if hits else "NO MATCH among "
                   + ", ".join(f"{p}={h[:12]}" for p, h in ckpts.items()))
        plan.note(f"{model}: receipt {r} checkpoint_sha256={str(want)[:12]}: {verdict}")
        ok = ok and bool(hits) and all(os.path.basename(p) != "last.ckpt" for p in hits)
    if not ok:
        plan.note(f"{model}: last.ckpt kept with the model (the receipt does not point at best.ckpt alone)")
    return ok


def root_keep():
    keep = set(KEEP_AT_ROOT)
    if os.path.isdir(".git"):
        try:
            out = subprocess.run(["git", "ls-tree", "--name-only", "HEAD"], capture_output=True, text=True,
                                 check=True).stdout
            keep |= {line.strip() for line in out.splitlines() if line.strip()}
        except (OSError, subprocess.CalledProcessError):
            pass
    return keep


def build_plan(hash_files=True):
    plan = Plan()
    hashes = {}
    run_dirs = {}
    for old, model in V1_RUNS.items():
        run_dirs[old] = (model, "seed42")
    for old, (model, seed, _) in V2_RUNS.items():
        run_dirs[old] = (model, seed)
    for name in ("models", "tools", "archive", "shared"):
        present = [n for n in os.listdir(name) if n not in ("organize_pod.py", "reorg")] if os.path.isdir(name) else []
        if present:
            plan.note(f"{name}/ already exists with {len(present)} entries; moves into it must not collide")

    # 1. Scores first: they are moved out of folders that move later or go to the archive.
    for folder, leftover in SCORE_FOLDERS.items():
        plan_score_folder(plan, folder, leftover, run_dirs)
    for old, (model, seed) in run_dirs.items():
        if not os.path.isdir(old):
            plan.note(f"absent: {old} ({model} {seed})")
            continue
        if old in V1_RUNS:
            plan_v1_score_tries(plan, old, model)
    plan_sliding_rescore(plan)

    # 2. The run folders, then their launch configs, to models/<model>/seed<NN>/.
    for old, (model, seed) in run_dirs.items():
        if os.path.isdir(old):
            plan.add("model", old, os.path.join("models", model, seed), "run folder")
            if old not in V1_RUNS:
                plan_v2_scores(plan, old, model, seed)
    for old, (model, seed, config) in V2_RUNS.items():
        if config and os.path.isfile(config):
            plan.add("model", config, os.path.join("models", model, seed, "launch_config.yaml"), "launch config")
    sr = "runs/v2/seed_robustness"  # per-seed configs to their seed, the rest of the seed check shared
    if os.path.isdir(sr):
        for name in sorted(os.listdir(sr)):
            src = os.path.join(sr, name)
            if src in run_dirs:
                continue
            low = name.lower()
            seed = "seed43" if "43" in low else "seed44" if "44" in low else None
            model = ("arch_b_h20_chunk" if "allpos" in low or "chunk" in low
                     else "arch_b_h20_sliding" if re.search(r"(^|[^a-z])b_?h20", low) else None)
            if os.path.isfile(src) and seed and model and low.endswith((".yaml", ".yml")):
                plan.add("model", src, os.path.join("models", model, seed, "launch_config.yaml"), "launch config")
            else:
                plan.add("shared", src, os.path.join("shared", "studies", "seed_check", name), "seed check")

    # 3. Shared material.
    for old, new in SHARED:
        if os.path.lexists(old):
            plan.add("shared", old, new)
        else:
            plan.note(f"absent: {old}")
    families = {}
    for parent, prefix, dest in NEWEST_ONLY:
        if os.path.isdir(parent):
            families.setdefault(dest, []).extend(
                (n, os.path.join(parent, n)) for n in os.listdir(parent)
                if n.startswith(prefix) and STAMP.fullmatch(n[len(prefix):])
                and os.path.isdir(os.path.join(parent, n)) and not os.path.islink(os.path.join(parent, n)))
    for dest, found in families.items():
        found.sort()
        for _, p in found[:-1]:
            plan.add("archive", p, os.path.join("archive", p), "superseded copy")
        if found:
            plan.add("shared", found[-1][1], dest, "newest copy")
            plan.note(f"{dest}: kept {found[-1][1]}; archived {', '.join(p for _, p in found[:-1]) or 'none'}")
    parent, prefix, dest = QUICK_CHECKS
    if os.path.isdir(parent):
        for n in sorted(os.listdir(parent)):
            if n.startswith(prefix):
                plan.add("shared", os.path.join(parent, n), os.path.join(dest, n), "complementary checks")
    parent, pattern, dest = UTC_RETURNS
    if os.path.isdir(parent):
        for n in sorted(os.listdir(parent)):
            if pattern.match(n):
                plan.add("shared", os.path.join(parent, n), os.path.join(dest, n), "V1 ledger collection")

    # 4. Hashes of every checkpoint and prediction file that stays out of the archive.
    for r in list(plan.rows):
        if r["kind"] in ("model", "shared") and os.path.lexists(r["old_path"]):
            for p in files_under(r["old_path"]):
                if (hash_files and p.endswith((".ckpt", ".parquet")) and os.path.isfile(p) and not os.path.islink(p)
                        and not plan.final(p).startswith("archive" + os.sep)):
                    try:
                        hashes[p] = sha256(p)
                    except OSError as e:
                        plan.note(f"CONFLICT: cannot read {p}: {e}")

    # 5. last.ckpt goes to the archive when it is not the scored checkpoint: in all 15 V1 runs it is the same epoch and
    #    step as best.ckpt (quick check a); in V2 runs it is the end-of-training state. Kept when any kept receipt
    #    names it, and for the two hand-scored V1 runs only after their receipt's hash matches best.ckpt.
    named = set()
    for r in plan.rows:
        if r["kind"] == "model" and os.path.lexists(r["old_path"]):
            for p in files_under(r["old_path"]):
                if p.endswith(".json") and plan.final(p).startswith("models" + os.sep):
                    ck = receipt_checkpoint(read_json(p))
                    if ck and os.path.basename(ck) == "last.ckpt":
                        named.add(under_root(ck))
    for old, (model, seed) in run_dirs.items():
        if not os.path.isdir(old):
            continue
        if model in HAND_SCORED and seed == "seed42" and not plan_hand_scored(plan, old, model, hashes):
            continue
        for p in files_under(old):
            if os.path.basename(p) != "last.ckpt" or not plan.final(p).startswith("models" + os.sep):
                continue
            if any(n == p or n.endswith(os.sep + p) for n in named):
                plan.note(f"{model} {seed}: a kept receipt names {p}; it stays with the model")
                continue
            plan.add_after("archive_after", p, plan.final(p), os.path.join("archive", p),
                           "not the scored checkpoint (best.ckpt is)")

    # 6. The root: scripts to tools/, console logs to shared/logs/console/, known clutter to the archive.
    keep = root_keep()
    for name in sorted(os.listdir(".")):
        if name in keep or plan.claimed(name) or (name.startswith(".") and name != ".tf_install"):
            continue
        if name in TOOLS or (os.path.isfile(name) and name.endswith((".py", ".sh"))):
            plan.add("tool", name, os.path.join("tools", name))
        elif os.path.isfile(name) and CONSOLE_LOG.match(name):
            plan.add("shared", name, os.path.join("shared", "logs", "console", "root", name), "console log")
        elif any(p.match(name) for p in ROOT_CLUTTER):
            plan.add("archive", name, os.path.join("archive", "root", name), "package copy, extraction or bundle")
        else:
            plan.note(f"UNKNOWN at the root, left in place: {name} ({size(name) / 1e6:.1f} MB)")

    # 7. Everything else under ablations/ and runs/: console logs to shared/logs/console/, the rest to the archive.
    for top in ("ablations", "runs"):
        if not os.path.isdir(top):
            continue
        for base, dirs, files in os.walk(top, topdown=True):
            nb = os.path.normpath(base)
            descend = []
            for d in sorted(dirs):
                p = os.path.join(nb, d)
                if plan.claimed(p):
                    continue
                if any(o.startswith(p + os.sep) for o in plan.by_old):
                    descend.append(d)  # part of this folder is planned elsewhere
                elif top == "runs" and any(os.path.basename(f) == "paired_v2.json" for f in files_under(p)):
                    plan.add("shared", p, os.path.join("shared", "comparisons", "other", os.path.relpath(p, "runs")),
                             "paired comparison")
                else:
                    plan.add("archive", p, os.path.join("archive", p), "superseded or unrecorded: check before deleting")
            dirs[:] = descend
            for f in sorted(files):
                p = os.path.join(nb, f)
                if plan.claimed(p):
                    continue
                if top == "runs" and CONSOLE_LOG.match(f):
                    plan.add("shared", p, os.path.join("shared", "logs", "console", os.path.relpath(p, "runs")),
                             "console log")
                else:
                    plan.add("archive", p, os.path.join("archive", p), "superseded or unrecorded: check before deleting")

    # 8. Checks: nothing running; destinations free and unique; no kept model's result hidden in the archive.
    for proc in busy():
        plan.note(f"CONFLICT: running while planning (run plan again when it ends): {proc}")
    seen = set()
    for r in plan.rows:
        if r["new_path"] in seen:
            plan.note(f"CONFLICT: two moves target {r['new_path']}")
        seen.add(r["new_path"])
        if os.path.lexists(r["new_path"]):
            plan.note(f"CONFLICT: destination exists: {r['new_path']}")
    landed = {}  # where the files inside each first-step folder move land, to catch a later move into a taken name
    for r in plan.ordered():
        if r["step"] == 1 and os.path.isdir(r["old_path"]):
            for p in files_under(r["old_path"]):
                landed[os.path.join(r["new_path"], os.path.relpath(p, r["old_path"]))] = p
    moved_on = {r["old_path"] for r in plan.rows}
    for r in plan.rows:
        if r["step"] > 1 and r["new_path"] in landed and r["new_path"] not in moved_on:
            plan.note(f"CONFLICT: {r['new_path']} is already taken by {landed[r['new_path']]}")
    kept_ckpt = {}
    for p, h in hashes.items():
        if p.endswith(".ckpt") and plan.final(p).startswith("models" + os.sep):
            owner = owner_of(p, run_dirs)
            if owner:
                kept_ckpt[h] = owner
    for r in plan.rows:
        if r["kind"] != "archive":
            continue
        hits = {}
        for p in files_under(r["old_path"]):
            if not p.endswith(".json"):
                continue
            for key, value in json_items(read_json(p)):
                k = key.lower()
                owner = None
                if "checkpoint" in k and "sha" not in k:
                    owner = owner_of(value, run_dirs)
                elif "sha256" in k and "checkpoint" in k:
                    owner = kept_ckpt.get(value.lower())
                if owner:
                    hits.setdefault(f"{owner[1]} {owner[2]}", set()).add(p)
        for who, ps in sorted(hits.items()):
            ps = sorted(ps)
            plan.note(f"CHECK: {r['old_path']} (to the archive) holds {len(ps)} receipt(s) naming {who}, "
                      f"e.g. {ps[0]}")
    return plan, hashes, run_dirs


def operational_refs(plan):
    """Lines in files people still run or source that name a moved path (env.sh, launch configs, tools, run tables)."""
    olds = sorted({r["old_path"] for r in plan.rows if r["kind"] in ("model", "shared") and "/" in r["old_path"]},
                  key=len, reverse=True)
    out = []
    for r in plan.rows:
        if not (r["note"] == "launch config" or r["kind"] == "tool" or r["old_path"] == "runs/v2/env.sh"
                or r["new_path"] == "shared/comparisons/v2_paired_inputs"):
            continue
        for p in files_under(r["old_path"]):
            try:
                if not p.endswith((".sh", ".py", ".yaml", ".yml", ".csv", ".json")) or os.path.getsize(p) > TEXT_LIMIT:
                    continue
                with open(p, encoding="utf-8") as f:
                    text = f.read()
            except (OSError, UnicodeDecodeError):
                continue
            found = [o for o in olds if o in text]
            if found:
                out.append(f"{plan.final(p)}: names {len(found)} moved path(s): " + ", ".join(found[:6])
                           + (" ..." if len(found) > 6 else ""))
    return out


def write_plan(plan, hashes, run_dirs):
    """PLAN.csv, HASHES.csv and REPORT.txt are written to temporary names and put in place together at the end;
    REPORT.txt carries PLAN.csv's hash, so "apply" never runs a plan its report does not describe."""
    os.makedirs(PLAN_DIR, exist_ok=True)
    with open(PLAN_CSV + ".tmp", "w", newline="", encoding="utf-8", errors="surrogateescape") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(plan.ordered())
    with open(HASHES_CSV + ".tmp", "w", newline="", encoding="utf-8", errors="surrogateescape") as f:
        w = csv.writer(f)
        w.writerow(["old_path", "new_path", "sha256", "bytes"])
        for p, h in sorted(hashes.items()):
            w.writerow([p, plan.final(p), h, os.path.getsize(p)])
    by_kind = {}
    for r in plan.rows:
        k = by_kind.setdefault(r["kind"], [0, 0])
        k[0] += 1
        k[1] += int(r["bytes"])
    lines = [f"Reorganization plan, {utc()}, project root {os.getcwd()}",
             f"PLAN_SHA256: {sha256(PLAN_CSV + '.tmp')}", ""]
    for kind in ("model", "shared", "tool", "archive", "archive_after"):
        n, b = by_kind.get(kind, (0, 0))
        lines.append(f"{kind:14s} {n:5d} moves {b / 1e9:10.2f} GB")
    archive_bytes = sum(by_kind.get(k, (0, 0))[1] for k in ("archive", "archive_after"))
    lines += ["", f"Deleting archive/ later would free about {archive_bytes / 1e9:.2f} GB.", "", "Notes:"]
    lines += [f"- {n}" for n in plan.notes] or ["- none"]

    lines += ["", "Models after the moves (top of each seed folder):"]
    tops = {}
    for r in plan.rows:
        if r["kind"] == "model" and os.path.lexists(r["old_path"]):
            for p in files_under(r["old_path"]):
                parts = plan.final(p).split(os.sep)
                if parts[0] == "models" and len(parts) > 3:
                    tops.setdefault(os.sep.join(parts[:3]), set()).add(parts[3] + ("/" if len(parts) > 4 else ""))
    for model in sorted({m for m, _ in run_dirs.values()}):
        for seed in sorted({s for (m, s) in run_dirs.values() if m == model}):
            top = os.path.join("models", model, seed)
            lines.append(f"  {top}/  " + (" ".join(sorted(tops.get(top, ()))) or "(absent)"))
    n_last = sum(r["kind"] == "archive_after" for r in plan.rows)
    lines.append(f"  ({n_last} last.ckpt files go to the archive after the moves)")

    lines += ["", "Files people run or source that still name old paths (MOVES.csv maps them):"]
    lines += [f"- {x}" for x in operational_refs(plan)] or ["- none"]
    lines += ["", "Going to the archive (check before it is deleted):"]
    for r in plan.rows:
        if r["kind"] in ("archive", "archive_after"):
            was = r["new_path"][len("archive" + os.sep):] if r["kind"] == "archive_after" else r["old_path"]
            lines.append(f"  {int(r['bytes']) / 1e6:10.1f} MB  {was}  ({r['note']})")
    with open(REPORT + ".tmp", "w", encoding="utf-8", errors="surrogateescape") as f:
        f.write("\n".join(lines) + "\n")
    for name in (PLAN_CSV, HASHES_CSV, REPORT):
        os.replace(name + ".tmp", name)
    print("\n".join(lines))
    print(f"\nWrote {PLAN_CSV}, {HASHES_CSV} and {REPORT}. Nothing was moved.")


def busy():
    try:
        out = subprocess.run(["ps", "-eo", "pid,args"], capture_output=True, text=True, check=True).stdout
    except (OSError, subprocess.CalledProcessError):
        return ["(could not list processes)"]
    return [line.strip() for line in out.splitlines()[1:]
            if any(b in line for b in BUSY) and "organize_pod" not in line]


def read_csv(path):
    with open(path, newline="", encoding="utf-8", errors="surrogateescape") as f:
        return list(csv.DictReader(f))


def logged_moves():
    return read_csv(MOVES_CSV) if os.path.isfile(MOVES_CSV) else []


def nearest_existing(path):
    for q in [path, *ancestors(path)]:
        if os.path.lexists(q):
            return q
    return "."


def preflight(rows, done):
    """Every problem that would stop "apply" partway, found before the first move."""
    problems, earlier_new, root_dev = [], {}, os.stat(".").st_dev
    pending_new, moved_away = {}, {r["old_path"] for r in rows}
    for r in rows:
        old, new = r["old_path"], r["new_path"]
        if (old, new) in done:
            earlier_new[new] = r
            continue
        if new in pending_new:
            problems.append(f"two moves target {new}")
        pending_new[new] = r
        carried = next((earlier_new[q] for q in [old, *ancestors(old)] if q in earlier_new), None)
        if carried is None:  # its source is in today's tree, not brought there by an earlier move
            if not os.path.lexists(old):
                if not os.path.lexists(new) and r["kind"] not in ("archive", "archive_after"):
                    problems.append(f"missing: {old} (planned to {new})")
            else:
                if os.lstat(old).st_dev != root_dev:
                    problems.append(f"on another disk (a rename would copy): {old}")
                if not os.access(os.path.dirname(old) or ".", os.W_OK):
                    problems.append(f"no write access to the folder holding {old}")
                if os.path.isdir(old) and not os.path.islink(old) and not os.access(old, os.W_OK):
                    problems.append(f"no write access to {old}")
                if os.path.lexists(new):
                    problems.append(f"destination exists: {new}")
        elif os.path.lexists(old) and os.path.lexists(new):
            problems.append(f"destination exists: {new}")
        # A destination inside a folder an earlier move brings: the same name must be free in that folder's contents.
        parent = next((earlier_new[q] for q in ancestors(new) if q in earlier_new), None)
        if parent is not None:
            twin = os.path.join(parent["old_path"], os.path.relpath(new, parent["new_path"]))
            if twin != old and os.path.lexists(twin) and twin not in moved_away:
                problems.append(f"{new} would already be taken by {twin}")
        base = nearest_existing(os.path.dirname(new) or ".")
        if os.path.lexists(base) and not os.path.isdir(base):
            problems.append(f"a file sits where a folder is needed: {base} (for {new})")
        elif os.stat(base).st_dev != root_dev:
            problems.append(f"destination on another disk: {base} (for {new})")
        elif not os.access(base, os.W_OK):
            problems.append(f"no write access to {base} (for {new})")
        earlier_new[new] = r
    return problems


def apply():
    for name in (PLAN_CSV, REPORT):
        if not os.path.isfile(name):
            sys.exit(f"No {name}: run 'plan' first.")
    done_rows = logged_moves()
    started = bool(done_rows)
    help_line = ("Nothing was moved. Fix it, run 'plan' again and send the new REPORT.txt." if not started else
                 "Moves have already started: do not run 'plan' again. Send this output back.")
    with open(REPORT, encoding="utf-8", errors="surrogateescape") as f:
        report = f.read()
    m = re.search(r"^PLAN_SHA256: ([0-9a-f]{64})$", report, re.M)
    if not m or m.group(1) != sha256(PLAN_CSV):
        sys.exit(f"{REPORT} does not belong to {PLAN_CSV}. " + help_line)
    if "CONFLICT" in report:
        sys.exit(f"{REPORT} lists conflicts. " + help_line)
    running = busy()
    if running:
        sys.exit("Refusing to move while these are running:\n  " + "\n  ".join(running)
                 + "\nWhen they end: " + help_line)
    rows = sorted(read_csv(PLAN_CSV), key=lambda r: (int(r["step"]), int(r["order"])))
    done = {(r["old_path"], r["new_path"]) for r in done_rows}
    if not started:  # the pod must be exactly as it was when the plan was made
        print("Checking that nothing changed since 'plan' ...")
        now, _, _ = build_plan(hash_files=False)
        key = ("step", "order", "kind", "old_path", "new_path", "bytes", "files", "newest")
        want = [tuple(str(r[k]) for k in key) for r in rows]
        have = [tuple(str(r[k]) for k in key) for r in now.ordered()]
        if want != have:
            was = {(r["old_path"], r["new_path"]): r for r in rows}
            now_rows = {(r["old_path"], r["new_path"]): r for r in now.ordered()}
            diff = [f"no longer there: {o}" for (o, n) in was if (o, n) not in now_rows]
            diff += [f"new since plan: {o}" for (o, n) in now_rows if (o, n) not in was]
            diff += [f"changed since plan: {k[0]}" for k in was if k in now_rows and
                     any(str(was[k][c]) != str(now_rows[k][c]) for c in ("bytes", "files", "newest"))]
            sys.exit("The pod changed since 'plan':\n  " + "\n  ".join(diff[:20] or ["the order of the moves"])
                     + "\n" + help_line)
    problems = preflight(rows, done)
    if problems:
        sys.exit("Refusing to start:\n  " + "\n  ".join(problems[:30]) + "\n" + help_line)
    moved = gone = already = 0
    new_log = not os.path.isfile(MOVES_CSV)
    with open(MOVES_CSV, "a", newline="", encoding="utf-8", errors="surrogateescape") as log:
        w = csv.writer(log)
        if new_log:
            w.writerow(["utc", "kind", "old_path", "new_path", "bytes", "result"])
        for r in rows:
            old, new = r["old_path"], r["new_path"]
            if (old, new) in done:
                already += 1
                continue
            if not os.path.lexists(old) and os.path.lexists(new):
                result = "found already moved"
                already += 1
            elif not os.path.lexists(old) and r["kind"] in ("archive", "archive_after"):
                result = "already gone, nothing to archive"
                gone += 1
            elif not os.path.lexists(old):
                sys.exit(f"Stopped: {old} is missing and {new} does not exist. Nothing was overwritten. "
                         "Do not run 'plan' again. Send this output back.")
            elif os.path.lexists(new):
                sys.exit(f"Stopped: destination exists: {new}. Nothing was overwritten. "
                         "Do not run 'plan' again. Send this output back.")
            else:
                os.makedirs(os.path.dirname(new) or ".", exist_ok=True)
                os.rename(old, new)
                result = "moved"
                moved += 1
            w.writerow([utc(), r["kind"], old, new, r["bytes"], result])
            log.flush()
    removed = 0
    for top in ("ablations", "runs", SLIDING_RESCORE[0]):
        for base, _, _ in os.walk(top, topdown=False):
            if not os.listdir(base):
                os.rmdir(base)  # only empty folders
                removed += 1
    print(f"Moved {moved}, already done {already}, already gone {gone}, empty folders removed {removed}. "
          f"Log: {MOVES_CSV}")
    leftovers = [p for p in ("ablations", "runs", SLIDING_RESCORE[0]) if os.path.exists(p)]
    if leftovers:
        print("Still present (not empty): " + ", ".join(leftovers) + ". Do not run 'plan' again. "
              "Send this output back.")
    print(f"Next: python {sys.argv[0]} verify")


def verify():
    for name in (PLAN_CSV, HASHES_CSV):
        if not os.path.isfile(name):
            sys.exit(f"No {name}: run 'plan' first.")
    hashes, plan_rows = read_csv(HASHES_CSV), read_csv(PLAN_CSV)
    logged = {(r["old_path"], r["new_path"]) for r in logged_moves()}
    bad = []
    if not hashes:
        bad.append(f"{HASHES_CSV} lists no files")
    for r in hashes:
        if not os.path.isfile(r["new_path"]):
            bad.append(f"MISSING {r['new_path']} (was {r['old_path']})")
        elif sha256(r["new_path"]) != r["sha256"]:
            bad.append(f"HASH DIFFERS {r['new_path']}")
    pending = [r for r in plan_rows if (r["old_path"], r["new_path"]) not in logged]
    if pending:
        bad.append(f"{len(pending)} planned moves are not in {MOVES_CSV}, e.g. {pending[0]['old_path']}")
    left = [p for p in ("ablations", "runs", SLIDING_RESCORE[0]) if os.path.exists(p)]
    if left:
        bad.append("old folders still present: " + ", ".join(left))
    matched = sum(1 for r in hashes if os.path.isfile(r["new_path"])) - sum(b.startswith("HASH") for b in bad)
    print(f"Checked {len(hashes)} checkpoints and prediction files at their new paths: {matched} match. "
          f"Planned moves logged: {len(plan_rows) - len(pending)} of {len(plan_rows)}.")
    for b in bad:
        print("  " + b)
    print("VERIFY FAILED: send this output back." if bad else "VERIFY PASSED.")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    if len(sys.argv) != 2 or sys.argv[1] not in ("plan", "apply", "verify"):
        sys.exit(__doc__)
    if not (os.path.isdir("fraud") and os.path.isdir(PKG)):
        sys.exit("Run this from the project root (the folder that holds fraud/ and your package folder). If you are "
                 "there and several folders hold v2/, name yours: POD_PACKAGE=<folder> python tools/organize_pod.py "
                 + sys.argv[1])
    if sys.argv[1] == "plan":
        if logged_moves():
            sys.exit(f"Moves have already started ({MOVES_CSV}). Do not run 'plan' again: run 'apply' to carry on, "
                     "or send its output back.")
        write_plan(*build_plan())
    elif sys.argv[1] == "apply":
        apply()
    else:
        verify()
