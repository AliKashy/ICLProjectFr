"""Descriptive calendar-period metrics for an existing prediction cohort.

Reads predictions (transaction id, account id, target, score), requires one raw
timestamp per prediction, and reports every month/week/day between the cohort's
first and last periods. Predictions join the raw files on the composite identity
(transaction id and account id), never on the transaction id alone, so a
transaction id reused by another account cannot borrow that account's time.
Raw files may contain extra IDs; requested predictions are never silently dropped.

V1 slice summary: one overall line over every supplied prediction (pooled AP,
never an average of month APs), then one line per calendar month of the target
rows, cut from the same full-history predictions (a month is never rescored
from its own extract). Each line carries rows, frauds, fraud rate and accounts
beside AP/AUROC. With --min-history H, every line also counts the targets with
at least H strictly-earlier rows of the same account in the same raw file (the
history the sequence builders can use under the strict rule; same-second rows
are not earlier), and one more line gives AP on exactly those targets.
This is the per-file history used by A and default B; all-position B sees only
its chunk (0 to 5 strictly earlier rows), so this line is not its available context.
Empty and single-class periods retain counts, with discrimination metrics left
undefined by this reporting policy. Buckets use the supplied consistent calendar
timezone (or naive timestamps); numeric units and mixed timezones are not guessed.

Regrouping predictions does not create a temporal holdout or establish drift.
Actual held-out validation additionally needs training/split provenance and cutoffs.

The legacy pr_auc / PR-AUC label denotes sklearn average precision (AP), not
trapezoidal integration of a precision-recall curve.

Usage:
    python YOUR_PACKAGE/scoring/temporal_eval.py \
        --pred s3://.../predictions/sequential \
        --raw-base s3://.../tfm_EVAL_raw_data --file-start 8000 --file-end 8010 \
        --period month --out temporal_metrics.csv \
        --min-history 20 --summary-out temporal_slices.csv
"""

import argparse
import csv
import os
import sys
from numbers import Number

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from fraud.data.s3_utils import build_file_list, make_s3_filesystem
from fraud.log_utils import setup_logging
from YOUR_PACKAGE.base.data.input_contracts import parse_required_timestamps
from YOUR_PACKAGE.scoring._prediction_utils import (
    add_path_argument,
    prediction_path,
    read_predictions,
    validate_ids,
)

log = setup_logging()


def _read(path, fs, columns=None):
    return read_predictions(path, fs, columns=columns)


HISTORY_COL = "_strictly_earlier_rows"


def _parse_timestamps(values, what):
    """Parse one timestamp column, refusing numeric units, invalid values and mixed zones."""
    numeric_time = pd.api.types.is_numeric_dtype(values.dtype)
    if pd.api.types.is_object_dtype(values.dtype):
        # Concatenated files can mix Timestamp and numeric scalars in an object
        # column; pandas would otherwise silently interpret those numbers as ns.
        numeric_time = numeric_time or values.map(lambda value: isinstance(value, Number)).any()
    if numeric_time:
        raise ValueError("Numeric timestamps require an explicit unit conversion before reporting")
    try:
        timestamps = pd.to_datetime(values, errors="coerce")
    except (TypeError, ValueError) as exc:
        raise ValueError("Timestamps must be parseable with one consistent timezone or all naive") from exc
    invalid = int(timestamps.isna().sum())
    if invalid:
        raise ValueError(f"Invalid or missing timestamps for {invalid} {what}")
    if not pd.api.types.is_datetime64_any_dtype(timestamps.dtype):
        raise ValueError("Timestamps must use one consistent timezone or all be naive")
    if timestamps.dt.tz is not None:
        # Preserve the supplied local calendar; do not silently convert it to UTC.
        timestamps = timestamps.dt.tz_localize(None)
    return timestamps


def _history_counts(raw, id_col, account_col, order_col):
    """Count, for every row of ONE raw file, the strictly-earlier rows of its account.

    This mirrors the strict history rule of both sequence builders: history is
    built inside one file and per account, rows are ordered by their actual
    instant (UTC for tz-aware times, not local wall-clock time), and a row whose
    parsed timestamp equals the target's (a same-second row) is not earlier. Every row of the
    file must therefore carry a valid account id and timestamp.
    """
    missing = {id_col, account_col, order_col} - set(raw.columns)
    if missing:
        raise ValueError(f"raw history rows: missing columns {sorted(missing)}")
    raw = raw[[id_col, account_col, order_col]].copy()
    accounts = validate_ids(raw[account_col], "raw history rows: account IDs", unique=False)
    # Keep the reporting refusals (numeric units, invalid or mixed-zone times),
    # but rank on the actual instant, as the builders do: tz-aware times become
    # UTC nanoseconds, so a DST fall-back hour keeps its true order. Month
    # slicing elsewhere still uses the supplied local calendar.
    _parse_timestamps(raw[order_col], "raw rows used for history counts")
    instants = parse_required_timestamps(raw[order_col], order_col)
    order_key = pd.Series(instants.to_numpy(dtype="datetime64[ns]").astype("int64"), index=raw.index)
    ranks = order_key.groupby(accounts.to_numpy(), sort=False).rank(method="min")
    raw[HISTORY_COL] = (ranks - 1).astype("int64").to_numpy()
    return raw


def _prepare_predictions(preds, times, id_col, target_col, score_col, order_col, *, account_col,
                         extra_cols=()):
    """Require full prediction coverage and a one-to-one composite-ID/timestamp join.

    The join key is (transaction id, account id), the scorers' composite
    identity; a single transaction id is never used on its own. account_col is
    keyword-only and required, so a caller using the older positional form
    (without the account) fails with a clear missing-keyword TypeError.
    """
    if id_col == account_col:
        raise ValueError("The composite identity needs distinct transaction and account columns")
    key = [id_col, account_col]
    extra_cols = list(extra_cols)
    original_ids = preds[key].copy() if set(key) <= set(preds.columns) else None
    preds, times = preds.copy(), times.copy()
    for name, frame, columns in [
        ("predictions", preds, [*key, target_col, score_col]),
        ("raw timestamps", times, [*key, order_col, *extra_cols]),
    ]:
        missing = set(columns) - set(frame.columns)
        if missing:
            raise ValueError(f"{name}: missing columns {sorted(missing)}")
        frame[id_col] = validate_ids(frame[id_col], f"{name}: IDs", unique=False)
        frame[account_col] = validate_ids(frame[account_col], f"{name}: account IDs ({account_col})",
                                          unique=False)
        duplicates = int(frame.duplicated(key).sum())
        if duplicates:
            raise ValueError(f"{name}: IDs ({id_col}, {account_col}) must be non-null and unique "
                             f"as a composite key; {duplicates} duplicate rows")
    if preds.empty:
        raise ValueError("Prediction cohort is empty; its calendar range is undefined")
    if not preds[target_col].isin([0, 1]).all():
        raise ValueError("Prediction targets must be non-null binary values")
    try:
        scores = preds[score_col].to_numpy(float)
    except (TypeError, ValueError) as exc:
        raise ValueError("Prediction scores must be finite numeric values") from exc
    if not np.isfinite(scores).all():
        raise ValueError("Prediction scores must be finite numeric values")

    df = preds[[*key, target_col, score_col]].merge(
        times[[*key, order_col, *extra_cols]], on=key, how="left", sort=False,
        validate="one_to_one", indicator="_timestamp_match",
    )
    unmatched = int(df["_timestamp_match"].ne("both").sum())
    if unmatched:
        raise ValueError(f"Raw files lack timestamps for {unmatched} prediction IDs "
                         f"(matched on {id_col} and {account_col})")
    df[order_col] = _parse_timestamps(df[order_col], "requested predictions")
    for column in key:
        df[column] = original_ids[column].to_numpy()
    return df.drop(columns="_timestamp_match")


def _period_metrics(df, period, order_col, target_col, score_col):
    """Retain all calendar periods spanned by the requested prediction timestamps."""
    freq = {"month": "M", "week": "W", "day": "D"}[period]
    buckets = df[order_col].dt.to_period(freq)
    grouped = df.groupby(buckets, sort=True)
    rows = []
    for bucket in pd.period_range(buckets.min(), buckets.max(), freq=freq):
        g = grouped.get_group(bucket) if bucket in grouped.groups else df.iloc[:0]
        y = g[target_col].to_numpy(int)
        n, positives = len(y), int(y.sum())
        status = "empty" if n == 0 else "single_class" if positives in (0, n) else "ok"
        row = {
            "bucket": str(bucket), "n": n, "positives": positives,
            "fraud_rate": float(positives / n) if n else None,
            "pr_auc": None, "roc_auc": None, "status": status,
        }
        if status == "ok":
            s = g[score_col].to_numpy(float)
            row["pr_auc"] = float(average_precision_score(y, s))
            row["roc_auc"] = float(roc_auc_score(y, s))
        rows.append(row)
    return rows


def _trend(rows, metric):
    """Fit defined metrics against actual calendar-period offsets, including gaps."""
    points = [(i, row[metric]) for i, row in enumerate(rows) if row[metric] is not None]
    if len(points) < 2:
        return None
    x, y = np.asarray(points, dtype=float).T
    return {
        "first_bucket": rows[int(x[0])]["bucket"],
        "last_bucket": rows[int(x[-1])]["bucket"],
        "first": float(y[0]), "last": float(y[-1]),
        "delta": float(y[-1] - y[0]),
        "slope": float(np.polyfit(x, y, 1)[0]),
    }


SUMMARY_FIELDS = ["slice", "n", "positives", "fraud_rate", "accounts", "fraud_accounts",
                  "pr_auc", "roc_auc", "status"]
HISTORY_FIELDS = ["min_history", "full_history_rows", "full_history_share"]


def _slice_line(label, g, target_col, score_col, account_col, min_history=None):
    """Counts and metrics for one slice of the supplied (already pooled) predictions."""
    y = g[target_col].to_numpy(int)
    n, positives = len(y), int(y.sum())
    status = "empty" if n == 0 else "single_class" if positives in (0, n) else "ok"
    row = {
        "slice": label, "n": n, "positives": positives,
        "fraud_rate": float(positives / n) if n else None,
        "accounts": int(g[account_col].nunique()),
        "fraud_accounts": int(g.loc[y == 1, account_col].nunique()),
        "pr_auc": None, "roc_auc": None, "status": status,
    }
    if status == "ok":
        s = g[score_col].to_numpy(float)
        row["pr_auc"] = float(average_precision_score(y, s))
        row["roc_auc"] = float(roc_auc_score(y, s))
    if min_history is not None:
        full = int((g[HISTORY_COL] >= min_history).sum())
        row.update({"min_history": int(min_history), "full_history_rows": full,
                    "full_history_share": float(full / n) if n else None})
    return row


def _slice_summary(df, order_col, target_col, score_col, account_col, min_history=None):
    """Overall line, then one line per target month, all cut from the same predictions.

    The overall metric is computed on every supplied prediction at once; it is
    never an average of the month lines. Month lines select target rows by
    their own timestamp; the scores (made with full available history, May
    history included for a June target) are not recomputed. With min_history,
    a last line restricts to targets with at least that many strictly-earlier
    rows of the same account in the same file.
    """
    if min_history is not None and HISTORY_COL not in df.columns:
        raise ValueError("History counts are missing; they come from the raw files")
    lines = [_slice_line("overall", df, target_col, score_col, account_col, min_history)]
    months = df[order_col].dt.to_period("M")
    for month in pd.period_range(months.min(), months.max(), freq="M"):
        lines.append(_slice_line(f"month:{month}", df[months == month], target_col, score_col,
                                 account_col, min_history))
    if min_history is not None:
        lines.append(_slice_line(f"history>={int(min_history)}", df[df[HISTORY_COL] >= min_history],
                                 target_col, score_col, account_col, min_history))
    return lines


def _cell(value):
    if value is None:
        return "undefined"
    return f"{value:.6f}" if isinstance(value, float) else str(value)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pred", required=True, help="predictions parquet (file or dir)")
    parser.add_argument("--raw-base", required=True, help="raw parquet base for timestamps")
    parser.add_argument("--file-start", type=int, required=True)
    parser.add_argument("--file-end", type=int, required=True)
    parser.add_argument("--order-col", default="transaction_dttm")
    parser.add_argument("--id", default="fi_transaction_id")
    parser.add_argument("--account", default="Nmap_account_reference_xid",
                        help="account ID column; with --id it forms the composite join key")
    parser.add_argument("--target", default="frd_tag")
    parser.add_argument("--score-col", default="score")
    parser.add_argument("--period", choices=["month", "week", "day"], default="month")
    parser.add_argument("--cred", default="/home/jovyan/your_id/tabular_fraud/test.yaml")
    parser.add_argument("--out", default="temporal_metrics.csv")
    parser.add_argument("--min-history", type=int, default=None, metavar="H",
                        help="also report targets with at least H strictly-earlier same-account rows "
                             "(counted per raw file; every raw row then needs a valid account and time)")
    parser.add_argument("--summary-out", default=None,
                        help="optional CSV of the overall, month and history slice lines")
    add_path_argument(parser)
    args = parser.parse_args()
    if args.file_end < args.file_start:
        parser.error("file-end must be at least file-start")
    if args.id == args.account:
        parser.error("--id and --account must name different columns (composite identity)")
    if args.min_history is not None and args.min_history < 0:
        parser.error("--min-history must be a non-negative integer")

    args.pred = prediction_path(args.pred, args.legacy_s3_paths)
    args.raw_base = prediction_path(args.raw_base, args.legacy_s3_paths)
    fs = make_s3_filesystem(args.cred) if any(
        p.startswith("s3://") for p in (args.pred, args.raw_base)
    ) else None
    frame = _read(args.pred, fs)
    missing = {args.id, args.account, args.target, args.score_col} - set(frame.columns)
    if missing:
        raise ValueError(f"predictions: missing columns {sorted(missing)}; "
                         f"the composite join needs {args.id} and {args.account}")
    preds = frame[[args.id, args.account, args.target, args.score_col]]

    # Timestamps by composite id from the raw files (id, account and order_col only).
    # History counts are per file because both sequence builders build history per file.
    files = build_file_list(args.raw_base, args.file_start, args.file_end)
    times = []
    for path in files:
        raw = _read(path, fs, columns=[args.id, args.account, args.order_col])
        if args.min_history is not None:
            raw = _history_counts(raw, args.id, args.account, args.order_col)
        times.append(raw)
    times = pd.concat(times, ignore_index=True)

    extra = [HISTORY_COL] if args.min_history is not None else []
    df = _prepare_predictions(preds, times, args.id, args.target, args.score_col, args.order_col,
                              account_col=args.account, extra_cols=extra)
    rows = _period_metrics(df, args.period, args.order_col, args.target, args.score_col)
    log.info("Prediction coverage: %d/%d; raw rows supplied: %d", len(df), len(preds), len(times))

    print(f"\n=== Descriptive prediction metrics by {args.period} ===")
    print("This report groups supplied predictions; held-out validation requires training/split provenance.")
    hdr = ["bucket", "n", "positives", "fraud_rate", "pr_auc", "roc_auc", "status"]
    print("  ".join(f"{h:>12}" if h != "bucket" else f"{h:<10}" for h in hdr))
    for r in rows:
        cells = {h: "undefined" if r[h] is None else str(r[h]) for h in hdr}
        print("  ".join(f"{cells[h]:>12}" if h != "bucket" else f"{cells[h]:<10}" for h in hdr))

    print("\n--- Descriptive calendar-period trends ---")
    print(f"buckets:        {len(rows)}")
    for metric, label in [("pr_auc", "PR-AUC"), ("roc_auc", "ROC-AUC")]:
        trend = _trend(rows, metric)
        if trend is None:
            print(f"{label} trend: undefined (fewer than two periods with both classes)")
        else:
            print(f"{label} {trend['first_bucket']} → {trend['last_bucket']}: "
                  f"{trend['first']:.4f} → {trend['last']:.4f} "
                  f"(Δ={trend['delta']:+.4f}, slope/calendar-period={trend['slope']:+.5f})")

    lines = _slice_summary(df, args.order_col, args.target, args.score_col, args.account,
                           args.min_history)
    fields = SUMMARY_FIELDS + (HISTORY_FIELDS if args.min_history is not None else [])
    print("\n=== Overall and month slices of the same predictions ===")
    print("overall = AP/AUROC over every supplied prediction at once (not an average of the month lines); "
          "month lines slice the same predictions by target time.")
    print("Compare models within one line; do not read one model's change between months as drift.")
    if args.min_history is not None:
        print(f"history>={args.min_history} = targets with at least {args.min_history} strictly-earlier rows "
              "of the same account in the same raw file (same-second rows are not earlier).")
        print("This is the per-file history used by A and default B; all-position B sees only its chunk "
              "(0 to 5 strictly earlier rows), so this line is not its available context.")
    print("  ".join(f"{h:<14}" if h == "slice" else f"{h:>12}" for h in fields))
    for line in lines:
        print("  ".join(f"{_cell(line[h]):<14}" if h == "slice" else f"{_cell(line[h]):>12}" for h in fields))

    with open(args.out, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=hdr)
        writer.writeheader()
        writer.writerows(rows)
    log.info("Wrote temporal metrics -> %s", args.out)
    if args.summary_out:
        with open(args.summary_out, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            writer.writerows(lines)
        log.info("Wrote slice summary -> %s", args.summary_out)


if __name__ == "__main__":
    main()
