"""Calibrate fraud scores + report cost-sensitive operating metrics (Idea E).

Takes prediction parquet (id, target, score) from any scorer (baseline,
streaming, sequential, GBM, ensemble), fits a calibrator on the validation set,
applies it to the test set, and reports what a fraud-ops team actually uses:

- average precision / ROC-AUC for both raw and calibrated scores,
- Brier score before/after (probability quality),
- precision @ top-k% and recall at a fixed **alert budget** (e.g. review top 0.1%).

Isotonic calibration can introduce ties and change ranking metrics; sigmoid
fitting can also change ordering. Report both rankings and assess probability
quality on held-out data. Alert budgets below use the original raw-score ranking.
The fitted estimator and its column metadata are saved for reuse.
Raw inputs must be finite probabilities in [0, 1]; invalid values are rejected
instead of silently clipped for Brier scoring. Both splits need binary labels,
both classes, and unique non-null transaction IDs, with no overlap between splits.
Prediction paths use s3:// or s3a:// for S3 and scheme-less paths for local I/O.
Use --legacy-s3-paths only for old commands using bare bucket/key notation.
An existing calibrated prediction file or explicit calibrator artifact is never
overwritten; choose a new output directory/path for a new report.

Usage:
    python YOUR_PACKAGE/scoring/calibrate_and_report.py \
        --val s3://.../predictions/seq/part_4950.parquet \
        --test s3://.../predictions/seq --method isotonic \
        --budgets 0.001 0.005 0.01
"""

import argparse
import os
import sys
from uuid import uuid4

import joblib
import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import sklearn
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from fraud.data.s3_utils import make_s3_filesystem, strip_scheme
from fraud.log_utils import setup_logging
from YOUR_PACKAGE.scoring._prediction_utils import (
    add_path_argument,
    at_budget,
    id_kind,
    prediction_path,
    read_predictions,
    validate_budget,
    validate_ids,
)

log = setup_logging()


def _prediction_path(path, legacy_s3=False):
    return prediction_path(path, legacy_s3=legacy_s3)


def _read(path, fs):
    return read_predictions(path, fs)


def _validate_predictions(df, name, target_col, score_col, id_col):
    missing = [c for c in (target_col, score_col, id_col) if c not in df.columns]
    if missing:
        raise ValueError(f"{name}: missing required columns: {', '.join(missing)}")
    if df.empty:
        raise ValueError(f"{name}: prediction data must not be empty")
    ids = df[id_col]
    if ids.isna().any() or ids.duplicated().any():
        raise ValueError(f"{name}: {id_col} must contain non-null, unique transaction IDs")
    try:
        df[id_col] = validate_ids(ids, f"{name}: {id_col}")
    except ValueError as exc:
        raise ValueError(f"{name}: invalid {id_col} transaction IDs: {exc}") from exc
    y = df[target_col].to_numpy()
    if not df[target_col].isin([0, 1]).all():
        raise ValueError(f"{name}: {target_col} must contain binary labels 0 and 1")
    if len(np.unique(y)) != 2:
        raise ValueError(f"{name}: both label classes are required for calibration and ROC-AUC reporting")
    try:
        s = df[score_col].to_numpy(float)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name}: {score_col} must contain finite probabilities in [0, 1]") from exc
    if not np.isfinite(s).all() or ((s < 0) | (s > 1)).any():
        raise ValueError(f"{name}: {score_col} must contain finite probabilities in [0, 1]")
    return s, y.astype(np.int64)


def _validate_budget(frac):
    validate_budget(frac)


def _fit_calibrator(method, s, y):
    if method == "isotonic":
        iso = IsotonicRegression(out_of_bounds="clip", y_min=0.0, y_max=1.0)
        iso.fit(s, y)
        return iso
    lr = LogisticRegression(max_iter=1000)  # Platt scaling on the raw score
    lr.fit(s.reshape(-1, 1), y)
    return lr


def _calibrate(estimator, method, scores):
    if method == "isotonic":
        return estimator.transform(scores)
    return estimator.predict_proba(scores.reshape(-1, 1))[:, 1]


def _save_calibrator(path, artifact, fs):
    # Only serialization is exposed: callers must trust an artifact before loading it.
    if path.startswith("s3://"):
        with fs.open(strip_scheme(path), "xb") as stream:
            joblib.dump(artifact, stream)
    else:
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "xb") as stream:
            joblib.dump(artifact, stream)


def _at_budget(y, s, frac):
    return at_budget(y, s, frac)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--val", required=True, help="validation predictions (file or dir)")
    parser.add_argument("--test", required=True, help="test predictions (file or dir)")
    parser.add_argument("--target", default="frd_tag")
    parser.add_argument("--score-col", default="score")
    parser.add_argument("--id-col", default="fi_transaction_id")
    parser.add_argument("--method", choices=["isotonic", "sigmoid"], default="isotonic")
    parser.add_argument("--budgets", nargs="*", type=float, default=[0.001, 0.005, 0.01])
    parser.add_argument("--cred", default="/home/jovyan/your_id/tabular_fraud/test.yaml")
    parser.add_argument("--pred-out", default=None, help="optional local/S3 directory for calibrated test preds")
    parser.add_argument("--calibrator-out", default=None,
                        help="new local file or S3 URI (default: unique file in pred-out/_calibrators or cwd)")
    add_path_argument(parser)
    args = parser.parse_args()

    try:
        for frac in args.budgets:
            _validate_budget(frac)
    except ValueError as exc:
        parser.error(str(exc))

    args.val, args.test = [_prediction_path(p, args.legacy_s3_paths) for p in (args.val, args.test)]
    if args.pred_out:
        args.pred_out = _prediction_path(args.pred_out, args.legacy_s3_paths)
    artifact_name = f"calibrator_{uuid4().hex}.joblib"
    if args.calibrator_out:
        calibrator_out = (f"s3://{strip_scheme(args.calibrator_out)}"
                          if args.calibrator_out.startswith(("s3://", "s3a://"))
                          else os.path.abspath(os.path.expanduser(args.calibrator_out)))
    else:
        calibrator_out = (f"{args.pred_out.rstrip('/')}/_calibrators/{artifact_name}"
                          if args.pred_out else os.path.abspath(artifact_name))
    paths = [args.val, args.test, args.pred_out or "", calibrator_out]
    fs = make_s3_filesystem(args.cred) if any(p.startswith("s3://") for p in paths) else None
    artifact_exists = (fs.exists(strip_scheme(calibrator_out)) if calibrator_out.startswith("s3://")
                       else os.path.exists(calibrator_out))
    if artifact_exists:
        parser.error(f"calibrator artifact already exists: {calibrator_out}; choose a new path")
    prediction_out = f"{args.pred_out.rstrip('/')}/calibrated_preds.parquet" if args.pred_out else None
    if prediction_out:
        prediction_exists = (fs.exists(strip_scheme(prediction_out)) if prediction_out.startswith("s3://")
                             else os.path.exists(prediction_out))
        if prediction_exists:
            parser.error(f"calibrated predictions already exist: {prediction_out}; choose a new --pred-out directory")
    val = _read(args.val, fs)
    test = _read(args.test, fs)
    try:
        sv, yv = _validate_predictions(val, "validation", args.target, args.score_col, args.id_col)
        st, yt = _validate_predictions(test, "test", args.target, args.score_col, args.id_col)
        if id_kind(val[args.id_col]) != id_kind(test[args.id_col]):
            raise ValueError("validation/test transaction IDs must use compatible identifier types")
        if val[args.id_col].isin(test[args.id_col]).any():
            raise ValueError("validation and test transaction IDs overlap; use disjoint prediction sets")
    except ValueError as exc:
        parser.error(str(exc))

    calibrator = _fit_calibrator(args.method, sv, yv)
    st_cal = np.asarray(_calibrate(calibrator, args.method, st), dtype=float)
    if st_cal.shape != st.shape or not np.isfinite(st_cal).all() or ((st_cal < 0) | (st_cal > 1)).any():
        raise ValueError("calibrator returned invalid probabilities")

    print("\n=== Ranking (raw and calibrated; ties/order may differ) ===")
    print(f"raw        AP={average_precision_score(yt, st):.6f} ROC-AUC={roc_auc_score(yt, st):.6f}")
    print(f"{args.method:<10} AP={average_precision_score(yt, st_cal):.6f} ROC-AUC={roc_auc_score(yt, st_cal):.6f}")
    print("\n=== Probability quality (Brier, lower is better) ===")
    print(f"raw:       {brier_score_loss(yt, st):.6f}")
    print(f"{args.method:<10} {brier_score_loss(yt, st_cal):.6f}")

    print("\n=== Alert budgets (raw-score ranking; expected metrics under uniform cutoff-tie selection) ===")
    print("Alerts = max(round(rows * budget), 1); tied cutoff scores share expected alert slots.\n"
          "These are capacity metrics, not monetary costs or a realized alert list.")
    print(f"{'budget':>8} {'alerts':>8} {'precision':>10} {'recall':>8}")
    for frac in args.budgets:
        n, prec, rec = _at_budget(yt, st, frac)
        print(f"{frac:>8.3%} {n:>8d} {prec:>10.4f} {rec:>8.4f}")

    _save_calibrator(calibrator_out, {
        "format_version": 1,
        "method": args.method,
        "score_col": args.score_col,
        "target_col": args.target,
        "id_col": args.id_col,
        "predictions_path": prediction_out,
        "sklearn_version": sklearn.__version__,
        "fit_rows": len(val),
        "fit_positives": int(yv.sum()),
        "estimator": calibrator,
    }, fs)
    print(f"\nFitted calibrator: {calibrator_out}")
    log.info("Wrote fitted calibrator -> %s", calibrator_out)

    if args.pred_out:
        out = {args.target: yt, "score": st, "score_calibrated": st_cal}
        for idc in dict.fromkeys((args.id_col, "fi_transaction_id", "Nmap_account_reference_xid")):
            if idc in test.columns:
                out[idc] = test[idc].to_numpy()
        out_path = strip_scheme(prediction_out)
        output_fs = fs if args.pred_out.startswith("s3://") else None
        if output_fs is None:
            os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
        with (open(out_path, "xb") if output_fs is None else output_fs.open(out_path, "xb")) as stream:
            pq.write_table(pa.table(out), stream)
        print(f"Calibrated predictions: {prediction_out}")
        log.info("Wrote calibrated predictions -> %s", out_path)


if __name__ == "__main__":
    main()
