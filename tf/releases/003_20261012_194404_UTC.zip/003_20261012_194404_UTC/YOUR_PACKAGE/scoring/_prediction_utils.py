"""Shared I/O and alert-budget contracts for offline prediction analysis.

Remote paths use s3:// or s3a://. Scheme-less paths are always local, including
new output directories; their interpretation never depends on file existence.
The explicit legacy option interprets bare relative paths as old bucket/key
paths. In that mode, local relative paths must start with ./ or ../.
"""

import os

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

from fraud.data.s3_utils import strip_scheme


def prediction_path(path, legacy_s3=False):
    path = os.fspath(path)
    if not path or not path.strip():
        raise ValueError("Prediction paths must not be empty")
    if path.startswith(("s3://", "s3a://")):
        bare = strip_scheme(path)
        if not bare or bare.startswith("/"):
            raise ValueError("S3 prediction paths must name a bucket")
        return f"s3://{bare}"
    if "://" in path:
        raise ValueError("Prediction paths support local paths, s3:// and s3a:// only")
    path = os.path.expanduser(path)
    if legacy_s3 and not os.path.isabs(path) and not path.startswith(("./", "../")):
        return f"s3://{path}"
    return os.path.abspath(path)


def add_path_argument(parser):
    parser.add_argument(
        "--legacy-s3-paths", action="store_true",
        help="interpret bare relative prediction paths as S3 bucket/key; default: local paths; "
             "prefer explicit s3:// URIs",
    )


def read_predictions(path, fs, columns=None):
    path = prediction_path(path)
    filesystem = fs if path.startswith("s3://") else None
    if path.startswith("s3://") and filesystem is None:
        raise ValueError("An S3 filesystem is required for an S3 prediction path")
    return pq.ParquetDataset(strip_scheme(path), filesystem=filesystem).read(columns=columns).to_pandas()


def validate_ids(values, label, unique=True):
    """Return lossless object keys for ID comparison, grouping and joins.

    Strings (including leading zeros) and bytes stay unchanged. Integer IDs
    retain arbitrary integer precision; safe small floating IDs remain floats.
    Floats at or beyond their dtype's consecutive-integer boundary are refused:
    a neighbouring integer might already have rounded onto the supplied value.
    Booleans are valid binary labels, but are not supported as identifiers.
    Exact object keys also prevent int64/uint64 comparison from using float64.
    """
    values = pd.Series(values, copy=False)
    if values.isna().any():
        suffix = "non-null and unique" if unique else "non-null"
        raise ValueError(f"{label} must be {suffix}")
    float_dtype = None
    if pd.api.types.is_float_dtype(values.dtype):
        float_dtype = getattr(values.dtype, "numpy_dtype", values.dtype)
    keys, kinds = [], set()
    for value in values.array:
        if isinstance(value, (bool, np.bool_)):
            raise ValueError(f"{label} must not contain boolean identifiers")  # noqa: TRY004 - invalid data value
        if isinstance(value, (int, np.integer)):
            key, kind = int(value), "numeric"
        elif isinstance(value, (float, np.floating)):
            if not np.isfinite(value):
                raise ValueError(f"{label} must be finite")
            dtype = float_dtype if float_dtype is not None else np.asarray(value).dtype
            if np.dtype(dtype).itemsize > 8:
                raise ValueError(f"{label}: extended-precision floating IDs must be supplied as strings or integers")
            boundary = 2 ** (np.finfo(dtype).nmant + 1)
            if abs(value) >= boundary:
                raise ValueError(f"{label}: unsafe floating identifier at or beyond {boundary}; "
                                 "reload original IDs as strings or integers")
            key, kind = float(value), "numeric"
        elif isinstance(value, str):
            key, kind = str(value), "str"
        elif isinstance(value, bytes):
            key, kind = bytes(value), "bytes"
        else:
            raise ValueError(f"{label} must contain strings, bytes or real numeric identifiers")  # noqa: TRY004
        keys.append(key)
        kinds.add(kind)
    if len(kinds) > 1:
        raise ValueError(f"{label} must use one identifier representation (strings, bytes or numeric)")
    result = pd.Series(keys, dtype=object, index=values.index, name=values.name)
    if unique and result.duplicated().any():
        raise ValueError(f"{label} must be non-null and unique")
    return result


def id_kind(values):
    """Classify a nonempty column that has already passed validate_ids."""
    first = values.iloc[0]
    return type(first).__name__ if isinstance(first, (str, bytes)) else "numeric"


def validate_budget(frac):
    if not np.isfinite(frac) or not 0 < frac <= 1:
        raise ValueError("each alert budget must be finite and in (0, 1]")


def at_budget(y, scores, frac):
    """Expected precision/recall under uniform selection within a cutoff tie.

    Exactly k = max(round(n * budget), 1) alerts are selected. Transactions
    strictly above the cutoff count fully; the remaining slots are distributed
    uniformly over equal-scoring transactions. Linearity of expectation gives
    expected true positives = positives_above + slots * mean(labels_in_tie).
    This is independent of row order and never uses labels to break a tie. It
    describes expected capacity metrics, not a realized operational alert list.
    """
    validate_budget(frac)
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if y.ndim != 1 or scores.ndim != 1 or not len(y) or len(y) != len(scores):
        raise ValueError("Alert-budget targets and scores must be aligned nonempty vectors")
    if not np.isin(y, [0, 1]).all() or not np.isfinite(scores).all():
        raise ValueError("Alert-budget labels must be binary and scores finite")
    n_alerts = max(round(len(scores) * frac), 1)
    cutoff = np.partition(scores, len(scores) - n_alerts)[len(scores) - n_alerts]
    above, tied = scores > cutoff, scores == cutoff
    remaining = n_alerts - int(above.sum())
    true_positives = float(y[above].sum()) + remaining * float(y[tied].mean())
    positives = int(y.sum())
    return n_alerts, true_positives / n_alerts, true_positives / positives if positives else float("nan")
