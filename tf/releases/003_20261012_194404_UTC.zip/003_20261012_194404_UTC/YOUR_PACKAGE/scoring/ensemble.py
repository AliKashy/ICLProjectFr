"""Blend multiple model predictions into an ensemble (Idea F).

Reads prediction parquet (id, target, score) from several models, checks that each
split has the same unique IDs and labels, aligns by ID, then optimizes convex blend
weights on the **validation** set (rank-averaged scores,
maximizing PR-AUC), then reports and writes the blended **test** predictions.
Tied scores receive average ranks, preserving ties regardless of input row order.
Individual model metrics use their original scores; rank scores are used for the blend.
Validation and test IDs must be disjoint. Ranks are cohort-relative: this is an
offline batch comparison, not a fitted per-transaction probability calibrator.
Use explicit s3:// URIs for remote paths; scheme-less paths are local by default.
Standard account IDs are retained when present in every model of a split. Use
--group for a required custom account column. Account mappings must agree, so
the emitted predictions can participate in the account-bootstrap leaderboard.

The legacy pr_auc / PR-AUC label denotes sklearn average precision (AP), not
trapezoidal integration of a precision-recall curve.

Usage:
    python YOUR_PACKAGE/scoring/ensemble.py \
        --names seq gbm streaming \
        --val  s3://.../seq/val  s3://.../gbm/val  s3://.../streaming/val \
        --test s3://.../seq/test s3://.../gbm/test s3://.../streaming/test \
        --pred-out s3://.../predictions/ensemble
"""

import argparse
import os
import sys

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
from scipy.stats import rankdata
from sklearn.metrics import average_precision_score, roc_auc_score

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from fraud.data.s3_utils import make_s3_filesystem, strip_scheme
from fraud.log_utils import setup_logging
from YOUR_PACKAGE.scoring._prediction_utils import (
    add_path_argument,
    id_kind,
    prediction_path,
    read_predictions,
    validate_ids,
)

log = setup_logging()


def _read(path, fs):
    return read_predictions(path, fs)


def _rankpct(s):
    """Percentile ranks with equal scores kept equal, independent of row order."""
    return (rankdata(s, method="average") - 1) / max(len(s) - 1, 1)


def _align(dirs, names, id_col, target_col, score_col, fs, group_col=None):
    """Align IDs, labels and optional account mappings without dropping metadata.

    An explicit group_col is required in every model. Otherwise the standard
    account column is retained if present, and must agree across all models in
    this split. Mixed presence is rejected rather than silently dropping it.
    """
    if not dirs or len(dirs) != len(names) or len(set(names)) != len(names) or not all(names):
        raise ValueError("Prediction paths and unique model names must align")
    account_col = group_col or "Nmap_account_reference_xid"
    if account_col in (target_col, score_col):
        raise ValueError("The group column must be distinct from target and score columns")

    def read_model(path, name):
        frame = _read(path, fs)
        required = [id_col, target_col, score_col] + ([group_col] if group_col else [])
        missing = set(required) - set(frame.columns)
        if missing:
            raise ValueError(f"{name}: missing prediction columns {sorted(missing)}")
        columns = [id_col, target_col, score_col] + ([account_col] if account_col in frame else [])
        frame = frame[list(dict.fromkeys(columns))].copy()
        if frame.empty:
            raise ValueError(f"{name}: prediction cohort is empty")
        if frame[id_col].isna().any() or frame[id_col].duplicated().any():
            raise ValueError(f"{name}: prediction IDs must be non-null and unique")
        frame[id_col] = validate_ids(frame[id_col], f"{name}: prediction IDs")
        if account_col in frame and account_col != id_col:
            frame[account_col] = validate_ids(frame[account_col], f"{name}: account IDs", unique=False)
        if not frame[target_col].isin([0, 1]).all():
            raise ValueError(f"{name}: target labels must be non-null binary values")
        if not np.isfinite(frame[score_col].to_numpy(float)).all():
            raise ValueError(f"{name}: prediction scores must be finite")
        return frame.rename(columns={score_col: f"s_{name}"})

    base = read_model(dirs[0], names[0])
    has_groups = account_col in base
    for i, (d, name) in enumerate(zip(dirs[1:], names[1:]), start=1):
        label_col = f"_model_target_{i}"
        extra = read_model(d, name).rename(columns={target_col: label_col})
        if (account_col in extra) != has_groups:
            raise ValueError(f"{name}: account/group column {account_col} must be present in every model "
                             "or absent from every model in the split")
        extra_group = f"_model_group_{i}"
        if has_groups and account_col != id_col:
            extra = extra.rename(columns={account_col: extra_group})
        if len(extra) != len(base):
            raise ValueError(f"{name}: prediction cohort IDs differ from {names[0]}")
        base = base.merge(extra, on=id_col, how="left", sort=False,
                          validate="one_to_one", indicator="_cohort_match")
        if not base["_cohort_match"].eq("both").all():
            raise ValueError(f"{name}: prediction cohort IDs differ from {names[0]}")
        if not base[target_col].eq(base[label_col]).all():
            raise ValueError(f"{name}: target labels disagree with {names[0]}")
        if has_groups and account_col != id_col:
            if not base[account_col].eq(base[extra_group]).all():
                raise ValueError(f"{name}: account/group mappings disagree with {names[0]}")
            base = base.drop(columns=extra_group)
        base = base.drop(columns=[label_col, "_cohort_match"])
    base = base.sort_values(id_col, kind="stable").reset_index(drop=True)
    y = base[target_col].to_numpy(int)
    mat = np.column_stack([_rankpct(base[f"s_{n}"].to_numpy(float)) for n in names])
    return base, mat, y


def _optimize_weights(mat, y, n_samples=4000, seed=42):
    mat, y = np.asarray(mat, dtype=float), np.asarray(y)
    if y.ndim != 1 or mat.ndim != 2 or mat.shape[0] != len(y) or mat.shape[1] == 0 or not len(y):
        raise ValueError("Blend scores must contain aligned nonempty model columns")
    if not np.isfinite(mat).all() or not np.isin(y, [0, 1]).all() or len(np.unique(y)) != 2:
        raise ValueError("Blend fitting needs finite scores and both binary target classes")
    if n_samples < 0:
        raise ValueError("n_samples must be non-negative")
    rng = np.random.default_rng(seed)
    m = mat.shape[1]
    best_w, best_ap = np.ones(m) / m, average_precision_score(y, mat.mean(1))
    # Dirichlet draws never reach an exact single-model endpoint. Include those
    # candidates so validation selection cannot do worse than the best single.
    for j in range(m):
        w = np.eye(1, m, j).ravel()
        ap = average_precision_score(y, mat[:, j])
        if ap > best_ap:
            best_ap, best_w = ap, w
    for _ in range(n_samples):
        w = rng.dirichlet(np.ones(m))
        ap = average_precision_score(y, mat @ w)
        if ap > best_ap:
            best_ap, best_w = ap, w
    return best_w, best_ap


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--names", nargs="+", required=True)
    parser.add_argument("--val", nargs="+", required=True)
    parser.add_argument("--test", nargs="+", required=True)
    parser.add_argument("--id", default="fi_transaction_id")
    parser.add_argument("--target", default="frd_tag")
    parser.add_argument("--score-col", default="score")
    parser.add_argument("--group", default=None,
                        help="required account/group column to validate and preserve; by default preserve "
                             "Nmap_account_reference_xid when present consistently across the models")
    parser.add_argument("--cred", default="/home/jovyan/your_id/tabular_fraud/test.yaml")
    parser.add_argument("--pred-out", default=None)
    add_path_argument(parser)
    args = parser.parse_args()

    if len(args.names) != len(args.val) or len(args.names) != len(args.test):
        parser.error("names/val/test must align")
    args.val = [prediction_path(p, args.legacy_s3_paths) for p in args.val]
    args.test = [prediction_path(p, args.legacy_s3_paths) for p in args.test]
    if args.pred_out:
        args.pred_out = prediction_path(args.pred_out, args.legacy_s3_paths)
    fs = make_s3_filesystem(args.cred) if any(
        p.startswith("s3://") for p in args.val + args.test + [args.pred_out or ""]
    ) else None
    prediction_out = f"{args.pred_out.rstrip('/')}/ensemble_preds.parquet" if args.pred_out else None
    if prediction_out:
        exists = (fs.exists(strip_scheme(prediction_out)) if prediction_out.startswith("s3://")
                  else os.path.exists(prediction_out))
        if exists:
            parser.error("ensemble predictions already exist; choose a new --pred-out directory")

    base_v, mat_v, yv = _align(args.val, args.names, args.id, args.target, args.score_col, fs, args.group)
    base_t, mat_t, yt = _align(args.test, args.names, args.id, args.target, args.score_col, fs, args.group)
    if id_kind(base_v[args.id]) != id_kind(base_t[args.id]):
        raise ValueError("Validation/test transaction IDs must use compatible identifier types")
    if base_v[args.id].isin(base_t[args.id]).any():
        raise ValueError("Validation and test transaction IDs overlap; use disjoint prediction sets")
    if np.unique(yt).size != 2:
        raise ValueError("Test ranking metrics require both target classes")
    w, val_ap = _optimize_weights(mat_v, yv)
    log.info("Best val PR-AUC=%.4f | weights: %s", val_ap,
             {n: float(wi) for n, wi in zip(args.names, w)})

    blended = mat_t @ w

    print("\n=== Ensemble vs singles (test) ===")
    print("Offline cohort-relative rank blend; scores are not calibrated fraud probabilities.")
    print(f"{'model':<16} {'PR-AUC':>8} {'ROC-AUC':>8}")
    for n in args.names:
        raw_scores = base_t[f"s_{n}"].to_numpy(float)
        print(f"{n:<16} {average_precision_score(yt, raw_scores):>8.4f} "
              f"{roc_auc_score(yt, raw_scores):>8.4f}")
    print(f"{'ENSEMBLE':<16} {average_precision_score(yt, blended):>8.4f} "
          f"{roc_auc_score(yt, blended):>8.4f}")

    if args.pred_out:
        out = {args.id: base_t[args.id].to_numpy(), args.target: yt, "score": blended}
        account_col = args.group or "Nmap_account_reference_xid"
        if account_col in base_t:
            out[account_col] = base_t[account_col].to_numpy()
        out_path = strip_scheme(prediction_out)
        remote = prediction_out.startswith("s3://")
        if not remote:
            os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
        with (fs.open(out_path, "xb") if remote else open(out_path, "xb")) as stream:
            pq.write_table(pa.table(out), stream)
        log.info("Wrote ensemble predictions -> %s", out_path)


if __name__ == "__main__":
    main()
