"""TEST-ONLY: reproduces the ORIGINAL (buggy) multi-worker file-sharding behavior,
for a controlled side-by-side comparison against the fixed SequenceBuilder.

Subclasses the real (fixed) YOUR_PACKAGE.phase4a.sequence_builder.SequenceBuilder and
overrides ONLY _get_worker_files with the pre-fix logic (unseeded, per-worker-
independent np.random.shuffle) -- everything else (windowing, encoding, the
window-buffer shuffle in _emit_batches) is inherited unchanged from the real,
validated implementation. This is deliberately a subclass, not a full duplicate,
so there is no risk of the two versions drifting apart on anything except the
one variable under test.

NOT used by any production config. Only for YOUR_PACKAGE/future_experiments/bug_repro/.
"""

from YOUR_PACKAGE.phase4a.sequence_builder import SequenceBuilder
import torch


class BuggySequenceBuilder(SequenceBuilder):
    def _get_worker_files(self):
        # ORIGINAL (pre-fix) logic, restored verbatim for this comparison only:
        # each worker shuffles with whatever global np.random state its own
        # process has (PL's seed_everything(workers=True) seeds each worker
        # DIFFERENTLY), so the per-worker stride slice is NOT a clean partition.
        worker_info = torch.utils.data.get_worker_info()
        files = list(self.file_list)
        if self.shuffle:
            import numpy as np
            np.random.shuffle(files)
        if worker_info is not None:
            files = files[worker_info.id :: worker_info.num_workers]
        return files
