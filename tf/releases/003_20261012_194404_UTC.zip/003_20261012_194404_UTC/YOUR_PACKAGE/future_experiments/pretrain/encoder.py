"""Shared tabular transaction encoder (used by SSL pretraining + embedding export).

Reuses the validated per-feature tokenizer (``TransactionEmbedding``) from the
flat sequential model: each continuous/categorical feature becomes one token, a
``CLS`` token is prepended, and a transformer encodes the set. The pooled ``CLS``
output is a dense **transaction embedding** that any downstream model (GBM, kNN,
the sequential model) can consume.
"""

from typing import List

import torch
import torch.nn as nn

from YOUR_PACKAGE.future_experiments.pretrain.tokenizer import FeatureTokenizer


class TabularEncoder(nn.Module):
    def __init__(
        self,
        continuous_dim: int,
        categorical_cardinality: List[int],
        embed_dim: int = 64,
        num_heads: int = 8,
        num_blocks: int = 4,
        ff_multiplier: int = 4,
        attn_dropout: float = 0.1,
        ff_dropout: float = 0.1,
        continuous_embedding: str = "linear",
        num_frequencies: int = 16,
    ):
        super().__init__()
        self.embed_dim = embed_dim
        self.n_continuous = continuous_dim
        self.n_categorical = len(categorical_cardinality)
        self.tokens_per = continuous_dim + self.n_categorical

        self.embedding = FeatureTokenizer(continuous_dim, categorical_cardinality, embed_dim,
                                              continuous_embedding, num_frequencies)
        # Column identity survives value masking during SSL and is transferred
        # with the encoder into fine-tuning and embedding export.
        self.feature_identity = nn.Parameter(torch.empty(1, self.tokens_per, embed_dim))
        nn.init.normal_(self.feature_identity, std=0.02)
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        nn.init.normal_(self.cls_token, std=0.02)

        layer = nn.TransformerEncoderLayer(
            d_model=embed_dim,
            nhead=num_heads,
            dim_feedforward=embed_dim * ff_multiplier,
            dropout=ff_dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        layer.self_attn.dropout = attn_dropout
        self.encoder = nn.TransformerEncoder(layer, num_layers=num_blocks)

    def tokens(self, continuous, categorical):
        """Per-feature tokens (no CLS): [B, tokens_per, d]."""
        return self.embedding(continuous, categorical) + self.feature_identity

    def forward(self, continuous, categorical):
        """Full encoded sequence incl. CLS at position 0: [B, 1 + tokens_per, d]."""
        tok = self.tokens(continuous, categorical)
        B, _, d = tok.shape
        cls = self.cls_token.expand(B, 1, d)
        return self.encoder(torch.cat([cls, tok], dim=1))

    def encode(self, continuous, categorical):
        """Pooled CLS transaction embedding: [B, d]."""
        return self.forward(continuous, categorical)[:, 0]
