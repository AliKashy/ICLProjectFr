"""Self-supervised masked autoencoder for tabular transactions (Idea A).

Pretrains ``TabularEncoder`` on UNLABELED transactions by masking a fraction of
feature tokens and reconstructing them (continuous -> MSE, categorical -> CE).
The learned encoder produces transferable transaction embeddings; fine-tune a
small head for fraud, or export embeddings for a GBM / the sequential model.

Batch dict (from ``ParquetStreamingDataset``, target ignored):
    continuous  [B, C]  float
    categorical [B, K]  long
"""

from typing import List

import pytorch_lightning as pl
import torch
import torch.nn as nn
import torch.nn.functional as F

from YOUR_PACKAGE.future_experiments.pretrain.encoder import TabularEncoder


class MaskedTabularAutoencoder(pl.LightningModule):
    def __init__(
        self,
        continuous_dim: int,
        categorical_cardinality: List[int],
        embed_dim: int = 64,
        num_heads: int = 8,
        num_blocks: int = 4,
        attn_dropout: float = 0.1,
        ff_dropout: float = 0.1,
        mask_ratio: float = 0.3,
        learning_rate: float = 3e-4,
        weight_decay: float = 1e-5,
        continuous_embedding: str = "linear",
        num_frequencies: int = 16,
    ):
        super().__init__()
        if not 0.0 < mask_ratio <= 1.0:
            raise ValueError("mask_ratio must be in (0, 1]")
        if continuous_dim + len(categorical_cardinality) < 1:
            raise ValueError("masked pretraining requires at least one feature")
        self.save_hyperparameters()
        self.encoder = TabularEncoder(
            continuous_dim, categorical_cardinality, embed_dim,
            num_heads, num_blocks, attn_dropout=attn_dropout, ff_dropout=ff_dropout,
            continuous_embedding=continuous_embedding, num_frequencies=num_frequencies,
        )
        self.n_cont = continuous_dim
        self.card = list(categorical_cardinality)
        self.mask_ratio = mask_ratio

        self.mask_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        nn.init.normal_(self.mask_token, std=0.02)
        self.cont_head = nn.Linear(embed_dim, 1)
        self.cat_heads = nn.ModuleList([nn.Linear(embed_dim, c) for c in self.card])

    def encode(self, continuous, categorical):
        return self.encoder.encode(continuous, categorical)

    def _reconstruct(self, batch):
        continuous, categorical = batch["continuous"], batch["categorical"]
        B = continuous.shape[0]
        d = self.hparams.embed_dim
        tok = self.encoder.tokens(continuous, categorical)  # [B, tokens_per, d]
        tokens_per = tok.shape[1]

        # Random per-token mask (same scheme for continuous + categorical tokens).
        m = (torch.rand(B, tokens_per, device=tok.device) < self.mask_ratio)
        # Each row has a reconstruction target, including small final batches.
        empty = ~m.any(dim=1)
        if empty.any():
            rows = empty.nonzero(as_tuple=True)[0]
            cols = torch.randint(tokens_per, (len(rows),), device=tok.device)
            m[rows, cols] = True
        masked = self.mask_token + self.encoder.feature_identity
        tok = torch.where(m.unsqueeze(-1), masked.expand(B, tokens_per, d), tok)

        cls = self.encoder.cls_token.expand(B, 1, d)
        enc = self.encoder.encoder(torch.cat([cls, tok], dim=1))[:, 1:]  # drop CLS -> [B, tokens_per, d]

        loss = tok.new_zeros(())
        # Continuous tokens occupy the first n_cont slots.
        if self.n_cont:
            m_cont = m[:, : self.n_cont]
            if m_cont.any():
                pred = self.cont_head(enc[:, : self.n_cont]).squeeze(-1)  # [B, n_cont]
                loss = loss + F.mse_loss(pred[m_cont], continuous[m_cont])
        # Categorical tokens follow.
        for i, head in enumerate(self.cat_heads):
            col = self.n_cont + i
            m_i = m[:, col]
            if m_i.any():
                logits = head(enc[:, col])  # [B, card_i]
                loss = loss + F.cross_entropy(logits[m_i], categorical[:, i][m_i])
        return loss

    def training_step(self, batch, batch_idx):
        loss = self._reconstruct(batch)
        self.log("train_loss", loss, on_epoch=True, on_step=True, prog_bar=True, sync_dist=True)
        return loss

    def validation_step(self, batch, batch_idx):
        loss = self._reconstruct(batch)
        self.log("valid_loss", loss, on_epoch=True, prog_bar=True, sync_dist=True)
        return loss

    def configure_optimizers(self):
        opt = torch.optim.AdamW(
            self.parameters(), lr=self.hparams.learning_rate,
            weight_decay=self.hparams.weight_decay,
        )
        sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, patience=3, factor=0.5)
        return {"optimizer": opt, "lr_scheduler": {"scheduler": sched, "monitor": "valid_loss"}}
