"""End-to-end fine-tuned classifier on the SSL encoder (Idea A, stronger variant).

Loads the pretrained ``TabularEncoder`` (from ``MaskedTabularAutoencoder``) and
trains a classification head on the labeled fraud task. Fine-tuning the whole
encoder typically beats a GBM on frozen embeddings, and adds a diverse NN to the
ensemble. Set ``freeze_encoder=True`` for a cheap linear-probe baseline.

Batch dict (from ``ParquetStreamingDataset``):
    continuous  [B, C]  float
    categorical [B, K]  long
    target      [B, 1]  long
"""

from pathlib import Path
from typing import List

import pytorch_lightning as pl
import torch
import torch.nn as nn

from YOUR_PACKAGE.future_experiments.pretrain.encoder import TabularEncoder


class SSLFinetuneClassifier(pl.LightningModule):
    def __init__(
        self,
        continuous_dim: int,
        categorical_cardinality: List[int],
        embed_dim: int = 64,
        num_heads: int = 8,
        num_blocks: int = 4,
        attn_dropout: float = 0.1,
        ff_dropout: float = 0.1,
        freeze_encoder: bool = False,
        learning_rate: float = 1e-4,
        weight_decay: float = 1e-5,
        pos_weight: float = 1.0,
        continuous_embedding: str = "linear",
        num_frequencies: int = 16,
    ):
        super().__init__()
        self.save_hyperparameters()
        self.encoder = TabularEncoder(
            continuous_dim, categorical_cardinality, embed_dim,
            num_heads, num_blocks, attn_dropout=attn_dropout, ff_dropout=ff_dropout,
            continuous_embedding=continuous_embedding, num_frequencies=num_frequencies,
        )
        self.head = nn.Linear(embed_dim, 2)
        self.freeze_encoder = freeze_encoder
        if freeze_encoder:
            self.encoder.requires_grad_(False)
            self.encoder.eval()

        weight = None
        if pos_weight and pos_weight != 1.0:
            weight = torch.tensor([1.0, float(pos_weight)])
        self.loss_fn = nn.CrossEntropyLoss(weight=weight)

    def load_pretrained(self, state_dict: dict):
        """Require a complete compatible encoder; decoder/head weights are ignored.

        The corrected encoder has explicit feature identities. Old Phase 5
        checkpoints without these parameters must be retrained, not silently
        accepted as complete pretraining.
        """
        enc = {k.removeprefix("encoder."): v for k, v in state_dict.items()
               if k.startswith("encoder.")}
        self.encoder.load_state_dict(enc, strict=True)
        # Preserve the existing return contract for callers that report the
        # intentionally untransferred classifier/loss keys.
        missing = [k for k in self.state_dict() if not k.startswith("encoder.")]
        return missing, []

    def load_pretrained_checkpoint(self, path, *, allow_scratch=False):
        if not path or not Path(path).is_file():
            if allow_scratch:
                return None
            raise FileNotFoundError(
                f"Required pretrained checkpoint not found: {path!r}. "
                "Use finetune.allow_scratch=true only for an explicitly named scratch control."
            )
        checkpoint = torch.load(path, map_location="cpu", weights_only=False)
        return self.load_pretrained(checkpoint["state_dict"])

    @classmethod
    def from_checkpoint_state(cls, checkpoint, **config_hparams):
        """Recreate scoring weights including checkpoint class-weight buffers.

        Check the config's architectural contract before loading: matching tensor
        shapes alone cannot detect a changed head count or feature cardinalities.
        Older checkpoints without hyperparameters use the explicit config values.
        """
        saved = dict(checkpoint.get("hyper_parameters", {}))
        for key in ("continuous_dim", "categorical_cardinality", "embed_dim", "num_heads",
                    "num_blocks", "continuous_embedding", "num_frequencies"):
            if key in saved and key in config_hparams and saved[key] != config_hparams[key]:
                raise ValueError(f"Checkpoint/config mismatch for {key}: {saved[key]!r} != {config_hparams[key]!r}")
        model = cls(**{**config_hparams, **saved})
        model.load_state_dict(checkpoint["state_dict"], strict=True)
        return model

    def train(self, mode: bool = True):
        super().train(mode)
        if self.freeze_encoder:
            self.encoder.eval()  # a linear probe uses a fixed representation
        return self

    def forward(self, batch):
        if self.freeze_encoder:
            with torch.no_grad():
                emb = self.encoder.encode(batch["continuous"], batch["categorical"])
        else:
            emb = self.encoder.encode(batch["continuous"], batch["categorical"])
        return self.head(emb)

    def _step(self, batch, tag):
        logits = self(batch)
        y = batch["target"].reshape(-1)
        loss = self.loss_fn(logits, y)
        self.log(f"{tag}_loss", loss, on_epoch=True, on_step=(tag == "train"),
                 prog_bar=True, sync_dist=True)
        return logits, y, loss

    def training_step(self, batch, batch_idx):
        _, _, loss = self._step(batch, "train")
        return loss

    def validation_step(self, batch, batch_idx):
        logits, y, _ = self._step(batch, "valid")
        return logits, y  # consumed by StreamingBinaryMetrics

    def configure_optimizers(self):
        params = self.head.parameters() if self.freeze_encoder else self.parameters()
        opt = torch.optim.AdamW(params, lr=self.hparams.learning_rate,
                                weight_decay=self.hparams.weight_decay)
        sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, patience=3, factor=0.5)
        return {"optimizer": opt, "lr_scheduler": {"scheduler": sched, "monitor": "valid_loss"}}
