"""Supervised contrastive pretraining for imbalanced tabular fraud (TabConFraud).

Pretrains the shared ``TabularEncoder`` with a supervised contrastive loss
(Khosla et al. 2020): two feature-corrupted views of each transaction are
embedded, and the loss pulls views of same-class transactions together while
pushing different-class apart. Because positives are defined by the fraud label,
the representation is shaped directly around the rare class — the motivation of
TabConFraud (ICMML 2025) for highly imbalanced data. Fine-tune a head afterwards
(``SSLFinetuneClassifier``) for classification.

Batch dict (from ``ParquetStreamingDataset``):
    continuous  [B, C]  float
    categorical [B, K]  long
    target      [B, 1]  long   (defines contrastive positives)
"""

from typing import List

import pytorch_lightning as pl
import torch
import torch.nn as nn
import torch.nn.functional as F

from YOUR_PACKAGE.future_experiments.pretrain.encoder import TabularEncoder


class SupConLoss(nn.Module):
    """Supervised contrastive loss for ``[B, V, d]`` features with labels ``[B]``."""

    def __init__(self, temperature: float = 0.07):
        super().__init__()
        if not temperature > 0:
            raise ValueError("temperature must be positive")
        self.temperature = temperature

    def forward(self, features: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        if features.ndim != 3 or min(features.shape) < 1:
            raise ValueError("features must have nonempty shape [batch, views, dimensions]")
        B, V, _ = features.shape
        if labels.numel() != B:
            raise ValueError("labels must contain one label per transaction")
        # reshape flattens sample-major: tx0/view0, tx0/view1, tx1/view0, ...
        expanded = labels.reshape(-1).to(features.device).repeat_interleave(V)
        diagonal = torch.eye(B * V, dtype=torch.bool, device=features.device)
        positives = expanded[:, None].eq(expanded[None, :]) & ~diagonal
        counts = positives.sum(1)
        valid = counts > 0
        if not valid.any():
            return features.sum() * 0.0
        # Pairwise log probabilities need float32 under mixed precision. Logsumexp
        # avoids the exp/sum underflow of the previous implementation.
        with torch.autocast(device_type=features.device.type, enabled=False):
            values = features.float() if features.dtype in (torch.float16, torch.bfloat16) else features
            feats = F.normalize(values, dim=-1).reshape(B * V, -1)
            logits = feats @ feats.T / self.temperature
            denominator = logits.masked_fill(diagonal, -torch.inf).logsumexp(1, keepdim=True)
            log_prob = logits - denominator
            mean_positive = log_prob.masked_fill(~positives, 0.0).sum(1) / counts.clamp_min(1)
            return -mean_positive[valid].mean()


class SupConPretrainer(pl.LightningModule):
    def __init__(
        self,
        continuous_dim: int,
        categorical_cardinality: List[int],
        embed_dim: int = 64,
        num_heads: int = 8,
        num_blocks: int = 4,
        attn_dropout: float = 0.1,
        ff_dropout: float = 0.1,
        proj_dim: int = 128,
        temperature: float = 0.07,
        corruption_rate: float = 0.3,
        learning_rate: float = 3e-4,
        weight_decay: float = 1e-5,
        continuous_embedding: str = "linear",
        num_frequencies: int = 16,
    ):
        super().__init__()
        self.save_hyperparameters()
        self.encoder = TabularEncoder(
            continuous_dim, categorical_cardinality, embed_dim,
            num_heads, num_blocks, attn_dropout=attn_dropout, ff_dropout=ff_dropout,
            continuous_embedding=continuous_embedding, num_frequencies=num_frequencies,
        )
        self.projection = nn.Sequential(
            nn.Linear(embed_dim, embed_dim), nn.ReLU(inplace=True), nn.Linear(embed_dim, proj_dim)
        )
        self.loss_fn = SupConLoss(temperature)
        self.corruption_rate = corruption_rate

    def _corrupt(self, continuous, categorical):
        """SCARF-style corruption: replace a fraction of features with another row's values."""
        B = continuous.shape[0]
        perm = torch.randint(0, B, (B,), device=continuous.device)
        m_cont = torch.rand_like(continuous) < self.corruption_rate
        cont = torch.where(m_cont, continuous[perm], continuous)
        m_cat = torch.rand(categorical.shape, device=categorical.device) < self.corruption_rate
        cat = torch.where(m_cat, categorical[perm], categorical)
        return cont, cat

    def _embed(self, continuous, categorical):
        return self.projection(self.encoder.encode(continuous, categorical))

    def _views(self, batch):
        c1, k1 = self._corrupt(batch["continuous"], batch["categorical"])
        c2, k2 = self._corrupt(batch["continuous"], batch["categorical"])
        return torch.stack([self._embed(c1, k1), self._embed(c2, k2)], dim=1)  # [B, 2, proj]

    def _step(self, batch, tag):
        feats = self._views(batch)
        loss = self.loss_fn(feats, batch["target"].reshape(-1))
        self.log(f"{tag}_loss", loss, on_epoch=True, on_step=(tag == "train"),
                 prog_bar=True, sync_dist=True)
        return loss

    def training_step(self, batch, batch_idx):
        return self._step(batch, "train")

    def validation_step(self, batch, batch_idx):
        return self._step(batch, "valid")

    def configure_optimizers(self):
        opt = torch.optim.AdamW(self.parameters(), lr=self.hparams.learning_rate,
                                weight_decay=self.hparams.weight_decay)
        sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, patience=3, factor=0.5)
        return {"optimizer": opt, "lr_scheduler": {"scheduler": sched, "monitor": "valid_loss"}}
