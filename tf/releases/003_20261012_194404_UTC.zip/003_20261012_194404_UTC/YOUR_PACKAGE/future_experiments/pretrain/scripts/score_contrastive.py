"""Score the contrastive fine-tuned classifier over a parquet range (Idea P3).

Streams the range with frozen-artifact preprocessing, scores on GPU, and writes
per-file predictions (ids + frd tag + score) for the ensemble/leaderboard.

Usage:
    python YOUR_PACKAGE/future_experiments/pretrain/scripts/score_contrastive.py \
        --config YOUR_PACKAGE/future_experiments/pretrain/configs/contrastive.yaml \
        eval.base=s3://.../tfm_EVAL_raw_data eval.file_start=8000 eval.file_end=8010
"""

import argparse
import os
import sys

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import torch
from omegaconf import OmegaConf
from sklearn.metrics import average_precision_score, roc_auc_score

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", ".."))

from fraud.data.datetime_features import DatetimeConfig
from fraud.data.feature_list import load_feature_list
from YOUR_PACKAGE.base.data.parquet_loader import (
    ParquetStreamingDataset,
    streaming_categorical_cardinality,
)
from fraud.data.preprocessing import PreprocessingArtifacts
from fraud.data.s3_utils import build_file_list, make_s3_filesystem, strip_scheme
from fraud.log_utils import setup_logging
from YOUR_PACKAGE.future_experiments.pretrain.ssl_finetune import SSLFinetuneClassifier

log = setup_logging()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("overrides", nargs="*")
    args = parser.parse_args()

    cfg = OmegaConf.load(args.config)
    if args.overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(args.overrides))
    ft = cfg.finetune

    fs = make_s3_filesystem(cfg.s3.cred_path)
    features = load_feature_list(cfg.predictors.csv_path, version=cfg.predictors.version, filesystem=fs)
    artifacts = PreprocessingArtifacts.load(
        f"{cfg.artifacts.base.rstrip('/')}/{cfg.artifacts.version}", filesystem=fs
    )
    dt_config = DatetimeConfig(order_col=cfg.data.order_col, fields=list(cfg.datetime.fields),
                               encoding=cfg.datetime.encoding, is_weekend=cfg.datetime.is_weekend)
    add_flag = cfg.preprocess.add_missing_flag
    cardinalities = streaming_categorical_cardinality(artifacts, features, add_flag)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    ckpt = ft.get("checkpoint", os.path.join(ft.checkpoint_dir, "best.ckpt"))
    state = torch.load(ckpt, map_location="cpu", weights_only=False)
    model = SSLFinetuneClassifier.from_checkpoint_state(
        state,
        continuous_dim=len(features.continuous), categorical_cardinality=cardinalities,
        embed_dim=int(cfg.model.input_embed_dim), num_heads=int(cfg.model.num_heads),
        num_blocks=int(cfg.model.num_attn_blocks),
        pos_weight=float(ft.get("pos_weight", 1.0)),
        continuous_embedding=cfg.model.get("continuous_embedding", "linear"),
        num_frequencies=int(cfg.model.get("num_frequencies", 16)),
    )
    model.eval().to(device)
    log.info("Loaded contrastive classifier %s on %s", ckpt, device)

    encoder = ParquetStreamingDataset(
        file_list=[], artifacts=artifacts, features=features, datetime_config=dt_config,
        target_col=cfg.data.target_col, positive_label=cfg.data.get("positive_label", 1),
        add_missing_flag=add_flag,
    )
    target_col = cfg.data.target_col
    id_cols = list(cfg.data.get("id_cols", []))
    read_cols = list(encoder._read_cols)
    for extra in id_cols:
        if extra and extra not in read_cols:
            read_cols.append(extra)

    out_base = ft.predictions_base.rstrip("/")
    files = build_file_list(cfg.eval.base, cfg.eval.file_start, cfg.eval.file_end)
    all_true, all_score = [], []
    log.info("Scoring %d file(s) -> %s", len(files), out_base)

    for path in files:
        part = os.path.basename(path)
        pf = pq.ParquetFile(strip_scheme(path), filesystem=fs)
        scores, targets, ids = [], [], {c: [] for c in id_cols}
        for rb in pf.iter_batches(batch_size=int(cfg.training.batch_size), columns=read_cols):
            df = rb.to_pandas()
            cont, cat, tgt = encoder._encode_batch(df)
            with torch.no_grad():
                logits = model({"continuous": torch.from_numpy(cont).to(device),
                                "categorical": torch.from_numpy(cat).to(device)})
                prob = torch.softmax(logits, dim=-1)[:, 1].cpu().numpy()
            scores.append(prob)
            targets.append(tgt.ravel())
            for c in id_cols:
                ids[c].append(df[c].to_numpy())

        score = np.concatenate(scores)
        y_true = np.concatenate(targets)
        out = {c: np.concatenate(ids[c]) for c in id_cols}
        out[target_col] = y_true
        out["score"] = score
        out_path = strip_scheme(f"{out_base}/{part}")
        pq.write_table(pa.table(out), out_path, filesystem=fs)
        log.info("%s: %d rows, positives=%d -> %s", part, len(score), int(y_true.sum()), out_path)
        all_true.append(y_true)
        all_score.append(score)

    if all_true:
        y_true = np.concatenate(all_true)
        y_score = np.concatenate(all_score)
        log.info("Range metrics: average_precision=%.4f  auroc=%.4f  (n=%d, positives=%d)",
                 average_precision_score(y_true, y_score), roc_auc_score(y_true, y_score),
                 len(y_true), int(y_true.sum()))


if __name__ == "__main__":
    main()
