"""Export per-transaction embeddings from the pretrained SSL encoder (Idea A).

Loads the SSL checkpoint, streams an S3 parquet range with the frozen-artifact
preprocessing, and writes per-file parquet with ids + ``frd_tag`` + ``emb_0..emb_{d-1}``.
Possible downstream uses include separate GBM or kNN experiments and feature
concatenation; those downstream training pipelines are not implemented here.

Usage:
    python YOUR_PACKAGE/future_experiments/pretrain/scripts/export_embeddings.py --config YOUR_PACKAGE/future_experiments/pretrain/configs/ssl.yaml \
        export.file_start=8000 export.file_end=8010
"""

import argparse
import os
import sys

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import torch
from omegaconf import OmegaConf

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", ".."))

from fraud.data.datetime_features import DatetimeConfig
from fraud.data.feature_list import load_feature_list
from YOUR_PACKAGE.base.data.parquet_loader import (
    ParquetStreamingDataset,
    streaming_categorical_cardinality,
)
from fraud.data.preprocessing import PreprocessingArtifacts
from fraud.data.s3_utils import build_file_list, make_s3_filesystem, strip_scheme
from fraud.log_utils import setup_logging
from YOUR_PACKAGE.future_experiments.pretrain.ssl_pretrain import MaskedTabularAutoencoder

log = setup_logging()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("overrides", nargs="*")
    args = parser.parse_args()

    cfg = OmegaConf.load(args.config)
    if args.overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(args.overrides))

    fs = make_s3_filesystem(cfg.s3.cred_path)
    features = load_feature_list(cfg.predictors.csv_path, version=cfg.predictors.version, filesystem=fs)
    artifacts = PreprocessingArtifacts.load(
        f"{cfg.artifacts.base.rstrip('/')}/{cfg.artifacts.version}", filesystem=fs
    )
    dt_config = DatetimeConfig(order_col=cfg.data.order_col, fields=list(cfg.datetime.fields),
                              encoding=cfg.datetime.encoding, is_weekend=cfg.datetime.is_weekend)
    add_flag = cfg.preprocess.add_missing_flag
    cardinalities = streaming_categorical_cardinality(artifacts, features, add_flag)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = MaskedTabularAutoencoder(
        continuous_dim=len(features.continuous), categorical_cardinality=cardinalities,
        embed_dim=int(cfg.model.input_embed_dim), num_heads=int(cfg.model.num_heads),
        num_blocks=int(cfg.model.num_attn_blocks),
        continuous_embedding=cfg.model.get("continuous_embedding", "linear"),
        num_frequencies=int(cfg.model.get("num_frequencies", 16)),
    )
    ckpt_path = cfg.export.get("checkpoint", os.path.join(cfg.output.checkpoint_dir, "best.ckpt"))
    state = torch.load(ckpt_path, map_location=device, weights_only=False)
    model.load_state_dict(state["state_dict"])
    model.eval().to(device)
    log.info("Loaded SSL encoder %s on %s (embed_dim=%d)", ckpt_path, device, cfg.model.input_embed_dim)

    encoder = ParquetStreamingDataset(
        file_list=[], artifacts=artifacts, features=features, datetime_config=dt_config,
        target_col=cfg.data.target_col, positive_label=cfg.data.get("positive_label", 1),
        add_missing_flag=add_flag,
    )
    id_cols = list(cfg.data.get("id_cols", []))
    read_cols = list(encoder._read_cols)
    for extra in id_cols:
        if extra and extra not in read_cols:
            read_cols.append(extra)

    out_base = cfg.export.out_base.rstrip("/")
    files = build_file_list(cfg.export.base, cfg.export.file_start, cfg.export.file_end)
    log.info("Exporting embeddings for %d file(s) -> %s", len(files), out_base)

    for path in files:
        part = os.path.basename(path)
        pf = pq.ParquetFile(strip_scheme(path), filesystem=fs)
        embs, targets, ids = [], [], {c: [] for c in id_cols}
        for rb in pf.iter_batches(batch_size=int(cfg.training.batch_size), columns=read_cols):
            df = rb.to_pandas()
            cont, cat, tgt = encoder._encode_batch(df)
            with torch.no_grad():
                emb = model.encode(torch.from_numpy(cont).to(device),
                                   torch.from_numpy(cat).to(device)).cpu().numpy()
            embs.append(emb)
            targets.append(tgt.ravel())
            for c in id_cols:
                ids[c].append(df[c].to_numpy())

        emb = np.concatenate(embs)
        out = {c: np.concatenate(ids[c]) for c in id_cols}
        out[cfg.data.target_col] = np.concatenate(targets)
        for j in range(emb.shape[1]):
            out[f"emb_{j}"] = emb[:, j]
        out_path = strip_scheme(f"{out_base}/{part}")
        pq.write_table(pa.table(out), out_path, filesystem=fs)
        log.info("%s: %d rows x %d dims -> %s", part, emb.shape[0], emb.shape[1], out_path)


if __name__ == "__main__":
    main()
