"""Fine-tune a classifier on the SupCon-pretrained encoder (TabConFraud, Idea P3).

Loads the contrastive encoder, attaches a classification head (Phase 5
``SSLFinetuneClassifier``), and trains on the labeled streaming data with
full-stream ``valid_ap`` early stopping — identical harness to every other model,
so the checkpoint scores straight into the leaderboard.

Usage:
    python YOUR_PACKAGE/future_experiments/pretrain/scripts/train_contrastive.py \
        --config YOUR_PACKAGE/future_experiments/pretrain/configs/contrastive.yaml
"""

import argparse
import os
import sys

import pytorch_lightning as pl
import torch
from omegaconf import OmegaConf
from pytorch_lightning.callbacks import EarlyStopping, ModelCheckpoint
from torch.utils.data import DataLoader

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", ".."))

from fraud.callbacks import CSVMetricsCallback, StreamingBinaryMetrics
from fraud.data.datetime_features import DatetimeConfig
from fraud.data.feature_list import load_feature_list
from YOUR_PACKAGE.base.data.parquet_loader import (
    ParquetStreamingDataset,
    streaming_categorical_cardinality,
)
from fraud.data.preprocessing import PreprocessingArtifacts
from fraud.data.s3_utils import build_file_list, make_s3_filesystem
from fraud.log_utils import setup_logging
from YOUR_PACKAGE.future_experiments.pretrain.ssl_finetune import SSLFinetuneClassifier

log = setup_logging()


def _loader(cfg, files, artifacts, features, dt_config, shuffle_files):
    ds = ParquetStreamingDataset(
        file_list=files, artifacts=artifacts, features=features, datetime_config=dt_config,
        target_col=cfg.data.target_col, positive_label=cfg.data.get("positive_label", 1),
        add_missing_flag=cfg.preprocess.add_missing_flag,
        batch_size=int(cfg.training.batch_size), shuffle_files=shuffle_files,
        shuffle_rows=bool(cfg.training.get("shuffle_rows", True)),
        read_batch_size=int(cfg.training.get("read_batch_size", 65536)),
        s3_cred_path=cfg.s3.cred_path,
    )
    return DataLoader(ds, batch_size=None, num_workers=int(cfg.training.get("num_workers", 0)))


def main():
    if int(os.environ.get("WORLD_SIZE", "1")) > 1:
        raise RuntimeError(
            "Phase 5 currently supports one training device/process only; "
            "distributed data sharding and global validation metrics are not implemented."
        )
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("overrides", nargs="*")
    args = parser.parse_args()

    cfg = OmegaConf.load(args.config)
    if args.overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(args.overrides))
    ft = cfg.finetune
    if cfg.training.get("seed") is not None:
        pl.seed_everything(cfg.training.seed, workers=True)

    fs = make_s3_filesystem(cfg.s3.cred_path)
    features = load_feature_list(cfg.predictors.csv_path, version=cfg.predictors.version, filesystem=fs)
    artifacts = PreprocessingArtifacts.load(
        f"{cfg.artifacts.base.rstrip('/')}/{cfg.artifacts.version}", filesystem=fs
    )
    dt_config = DatetimeConfig(order_col=cfg.data.order_col, fields=list(cfg.datetime.fields),
                               encoding=cfg.datetime.encoding, is_weekend=cfg.datetime.is_weekend)
    add_flag = cfg.preprocess.add_missing_flag
    cardinalities = streaming_categorical_cardinality(artifacts, features, add_flag)

    train_files = build_file_list(cfg.data.train_base, cfg.data.train_start, cfg.data.train_end)
    val_files = build_file_list(cfg.data.val_base, cfg.data.val_start, cfg.data.val_end)
    train_loader = _loader(cfg, train_files, artifacts, features, dt_config, True)
    val_loader = _loader(cfg, val_files, artifacts, features, dt_config, False)

    model = SSLFinetuneClassifier(
        continuous_dim=len(features.continuous), categorical_cardinality=cardinalities,
        embed_dim=int(cfg.model.input_embed_dim), num_heads=int(cfg.model.num_heads),
        num_blocks=int(cfg.model.num_attn_blocks), attn_dropout=float(cfg.model.attn_dropout),
        ff_dropout=float(cfg.model.ff_dropout), freeze_encoder=bool(ft.get("freeze_encoder", False)),
        learning_rate=float(ft.get("learning_rate", 1e-4)),
        weight_decay=float(cfg.training.get("weight_decay", 1e-5)),
        pos_weight=float(ft.get("pos_weight", 1.0)),
        continuous_embedding=cfg.model.get("continuous_embedding", "linear"),
        num_frequencies=int(cfg.model.get("num_frequencies", 16)),
    )
    pre_path = ft.get("pretrained_ckpt", os.path.join(cfg.output.checkpoint_dir, "best.ckpt"))
    transfer = model.load_pretrained_checkpoint(
        pre_path, allow_scratch=bool(ft.get("allow_scratch", False))
    )
    if transfer is None:
        log.warning("Explicit scratch control: no pretrained encoder loaded from %s", pre_path)
    else:
        missing, unexpected = transfer
        log.info("Loaded complete pretrained encoder from %s (non-encoder missing=%d unexpected=%d)",
                 pre_path, len(missing), len(unexpected))

    save_path = ft.checkpoint_dir
    os.makedirs(save_path, exist_ok=True)
    monitor, mode = cfg.training.monitor, cfg.training.monitor_mode
    callbacks = [
        StreamingBinaryMetrics(pos_index=1),
        CSVMetricsCallback(os.path.join(save_path, "training_metrics.csv")),
        EarlyStopping(monitor=monitor, mode=mode, patience=int(ft.get("early_stopping_patience", 3))),
        ModelCheckpoint(dirpath=save_path, filename="best", monitor=monitor, mode=mode,
                        save_last=True, enable_version_counter=False),
    ]
    trainer = pl.Trainer(
        max_epochs=int(ft.get("max_epochs", 10)), accelerator=cfg.training.accelerator, devices=1,
        precision=cfg.training.get("precision", "bf16-mixed"), callbacks=callbacks, logger=False,
        accumulate_grad_batches=int(cfg.training.get("accumulate_grad_batches", 1)),
        log_every_n_steps=int(cfg.training.get("log_every_n_steps", 200)),
    )
    log.info("Contrastive fine-tune | GPU=%s | freeze_encoder=%s", torch.cuda.is_available(),
             ft.get("freeze_encoder", False))
    trainer.fit(model, train_loader, val_loader)
    log.info("Fine-tuning complete. Checkpoint in %s", save_path)


if __name__ == "__main__":
    main()
