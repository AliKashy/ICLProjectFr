"""Causal-mask regression test with two or more attention blocks (ported from PR #2, reviewer's 2026-10-06 proposal).

The original CLS rule let history tokens read the CLS token, which had already read the target in the first
block; the leak only shows from the second block on. A one-block model cannot catch it, so these models use two.
"""
import os
import sys

import pytest
import torch

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from YOUR_PACKAGE.phase4a.sequential import FTTransformerSeqModel  # noqa: E402
from YOUR_PACKAGE.phase4b.sequential_hier import FTTransformerHierModel  # noqa: E402


def _batch(T, C=3, K=2, B=4, seed=0):
    g = torch.Generator().manual_seed(seed)
    return {
        "continuous": torch.randn(B, T, C, generator=g),
        "categorical": torch.randint(0, 5, (B, T, K), generator=g),
        "mask": torch.ones(B, T, dtype=torch.bool),
        "target": torch.zeros(B, 1, dtype=torch.long),
    }


def _capture(module, attr, batch):
    captured = {}
    handle = getattr(module, attr).register_forward_hook(lambda m, i, o: captured.setdefault("out", o.detach().clone()))
    try:
        with torch.no_grad():
            module(batch)
    finally:
        handle.remove()
    return captured["out"]


@pytest.mark.parametrize("blocks", [2, 3])
def test_causal_a_history_tokens_ignore_the_target(blocks):
    """A (flat): perturbing only the target slot must not change any history token after the encoder."""
    T, C = 4, 3
    torch.manual_seed(0)
    model = FTTransformerSeqModel(continuous_dim=C, categorical_cardinality=[5, 5], history_len=T - 1,
                                  embed_dim=16, num_heads=2, num_attn_blocks=blocks,
                                  attention_mask="causal").eval()
    b1 = _batch(T, C)
    b2 = {k: v.clone() for k, v in b1.items()}
    b2["continuous"][:, -1, :] += 3.0
    o1, o2 = _capture(model, "encoder", b1), _capture(model, "encoder", b2)
    hist = slice(1, 1 + (T - 1) * model.tokens_per_txn)
    assert torch.allclose(o1[:, hist], o2[:, hist], atol=1e-6)
    assert not torch.allclose(o1[:, 0], o2[:, 0])  # CLS still reads the target


@pytest.mark.parametrize("blocks", [2, 3])
def test_causal_b_history_vectors_ignore_the_target(blocks):
    """B (hierarchical): perturbing only the target slot must not change any history transaction vector."""
    T, C = 4, 3
    torch.manual_seed(0)
    model = FTTransformerHierModel(continuous_dim=C, categorical_cardinality=[5, 5], history_len=T - 1,
                                   embed_dim=16, num_heads=2, num_txn_blocks=1, num_seq_blocks=blocks,
                                   attention_mask="causal").eval()
    b1 = _batch(T, C)
    b2 = {k: v.clone() for k, v in b1.items()}
    b2["continuous"][:, -1, :] += 3.0
    o1, o2 = _capture(model, "seq_encoder", b1), _capture(model, "seq_encoder", b2)
    assert torch.allclose(o1[:, 1:T], o2[:, 1:T], atol=1e-6)
    assert not torch.allclose(o1[:, 0], o2[:, 0])
