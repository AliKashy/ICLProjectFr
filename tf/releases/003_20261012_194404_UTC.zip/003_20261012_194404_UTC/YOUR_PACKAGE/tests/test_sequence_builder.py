"""Correctness tests for the Phase 4 sequence builder (no S3 required).

Validates the causal windowing contract the sequential model depends on:
- strict causality (history is always *prior* to the target; no future leakage),
- left-padding of short histories with a correct attention mask,
- account isolation (a window never mixes transactions from other accounts),
- fraud targets are never skipped by ``stride``,
- every transaction is scored exactly once at ``stride=1`` (eval contract),
- emitted tensor shapes match ``T = history_len + 1``.

Run: python -m pytest tests/test_sequence_builder.py -q
"""

import os
import sys

import numpy as np
import pandas as pd
import pytest
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from fraud.data.datetime_features import DatetimeConfig, derive_datetime_features
from fraud.data.feature_list import load_feature_list
from fraud.data.preprocessing import PreprocessingArtifacts
from fraud.data.sequence_builder import SequenceBuilder

CONTINUOUS = ["f1", "f2"]
CATEGORICAL = ["c1", "c2"]
DATETIME_FIELDS = ["month", "day", "hour", "day_of_week"]


def _write_predictors(tmp_path):
    rows = ["feature,type,source,version,description"]
    for c in CONTINUOUS:
        rows.append(f"{c},continuous,raw,1,{c}")
    for c in CATEGORICAL:
        rows.append(f"{c},categorical,raw,1,{c}")
    for f in DATETIME_FIELDS:
        rows.append(f"{f},categorical,derived:transaction_dttm,1,{f}")
    path = tmp_path / "predictors.csv"
    path.write_text("\n".join(rows) + "\n")
    return str(path)


def _synthetic_df():
    """Three accounts with distinct, strictly increasing timestamps.

    ``f1`` is set to the (numeric) account id so a correctly built window has an
    identical ``f1`` across all of its real slots -> proves account isolation.
    """
    rng = np.random.default_rng(0)
    rows = []
    # (account_id, n_transactions, n_fraud_at_tail)
    layout = [(10, 5, 1), (20, 2, 0), (30, 4, 2)]
    base = pd.Timestamp("2024-03-01 00:00:00")
    txn = 0
    for acct, n, n_fraud in layout:
        for i in range(n):
            txn += 1
            frd = 1 if i >= n - n_fraud else 0
            rows.append(
                {
                    "transaction_dttm": base + pd.Timedelta(hours=txn),
                    "Nmap_account_reference_xid": acct,
                    "fi_transaction_id": f"T{txn:04d}",
                    "f1": float(acct),  # constant per account
                    "f2": float(rng.normal()),
                    "c1": rng.choice(["A", "B", "C"]),
                    "c2": rng.choice(["X", "Y"]),
                    "frd_tag": frd,
                }
            )
    return pd.DataFrame(rows), layout


def _fit_artifacts(df, features, dt_config):
    derived, _, _ = derive_datetime_features(df, dt_config)
    arts = PreprocessingArtifacts(artifact_version=1, predictor_version=1)
    for c in features.continuous:
        arts.fit_feature(c, derived[c], "continuous")
    for c in features.categorical:
        arts.fit_feature(c, derived[c], "categorical")
    return arts


def _build(tmp_path, history_len=3, stride=1, shuffle=False):
    df, layout = _synthetic_df()
    csv_path = _write_predictors(tmp_path)
    features = load_feature_list(csv_path, version=1)
    dt_config = DatetimeConfig(
        order_col="transaction_dttm",
        fields=DATETIME_FIELDS,
        encoding="categorical",
        is_weekend=False,
    )
    arts = _fit_artifacts(df, features, dt_config)

    parquet_path = tmp_path / "part_1.parquet"
    df.to_parquet(parquet_path)

    ds = SequenceBuilder(
        file_list=[str(parquet_path)],
        artifacts=arts,
        features=features,
        datetime_config=dt_config,
        target_col="frd_tag",
        account_col="Nmap_account_reference_xid",
        order_col="transaction_dttm",
        history_len=history_len,
        stride=stride,
        positive_label=1,
        add_missing_flag=True,
        time_delta=True,
        batch_size=4,
        shuffle=shuffle,
        buffer_windows=4,
        tie_break_col="fi_transaction_id",
        s3_filesystem=None,
    )
    return ds, df, layout


def _collect(ds):
    """Concatenate all emitted batches into single tensors."""
    cont, cat, mask, tgt = [], [], [], []
    for b in ds:
        cont.append(b["continuous"])
        cat.append(b["categorical"])
        mask.append(b["mask"])
        tgt.append(b["target"])
    return (
        torch.cat(cont),
        torch.cat(cat),
        torch.cat(mask),
        torch.cat(tgt),
    )


# --------------------------------------------------------------------------- #
def test_shapes(tmp_path):
    history_len = 3
    ds, df, _ = _build(tmp_path, history_len=history_len)
    cont, cat, mask, tgt = _collect(ds)
    T = history_len + 1
    n_windows = len(df)  # stride=1 -> one window per transaction
    assert cont.shape == (n_windows, T, len(CONTINUOUS) + 1)  # +1 time-delta
    expected_k = len(CATEGORICAL) + len(DATETIME_FIELDS) + len(CONTINUOUS)  # + _isna flags
    assert cat.shape == (n_windows, T, expected_k)
    assert mask.shape == (n_windows, T)
    assert tgt.shape == (n_windows, 1)


def test_every_transaction_scored_once(tmp_path):
    ds, df, _ = _build(tmp_path, history_len=3, stride=1)
    _, _, _, tgt = _collect(ds)
    assert tgt.shape[0] == len(df)


def test_target_slot_is_last_and_present(tmp_path):
    history_len = 3
    ds, _, _ = _build(tmp_path, history_len=history_len)
    _, _, mask, _ = _collect(ds)
    # The target always occupies the final slot and is always a real transaction.
    assert bool(mask[:, -1].all())


def test_no_future_leakage_via_time_delta(tmp_path):
    """Every real history slot is strictly prior to the target.

    time_delta = log1p(target_time - slot_time), clamped at 0. With distinct,
    increasing timestamps a genuinely prior slot yields a strictly positive
    delta, while the target slot yields exactly 0. A future (leaked) slot would
    clamp to 0 -> detectable as a non-target real slot with delta == 0.
    """
    history_len = 3
    ds, _, _ = _build(tmp_path, history_len=history_len)
    cont, _, mask, _ = _collect(ds)
    time_delta = cont[..., -1]  # last continuous channel
    T = history_len + 1
    # target slot (last) elapsed == 0
    assert torch.allclose(time_delta[:, -1], torch.zeros(time_delta.shape[0]))
    # real history slots must have strictly positive elapsed time (prior only)
    for s in range(T - 1):
        real = mask[:, s]
        if real.any():
            assert bool((time_delta[real, s] > 0).all()), f"future leakage at slot {s}"


def test_left_padding_mask_is_contiguous(tmp_path):
    """Short histories are LEFT-padded: all real slots are contiguous at the right."""
    history_len = 3
    ds, _, _ = _build(tmp_path, history_len=history_len)
    _, _, mask, _ = _collect(ds)
    for row in mask:
        idx = torch.nonzero(row, as_tuple=False).flatten()
        # real slots form a contiguous block ending at the last position
        assert idx[-1].item() == mask.shape[1] - 1
        assert torch.equal(idx, torch.arange(idx[0].item(), mask.shape[1]))


def test_account_isolation(tmp_path):
    """No window mixes accounts: f1 (== account id) is constant across real slots."""
    ds, _, _ = _build(tmp_path, history_len=3)
    cont, _, mask, _ = _collect(ds)
    f1 = cont[..., 0]  # standardized, still constant within an account
    for w in range(f1.shape[0]):
        real = mask[w]
        vals = f1[w][real]
        assert torch.allclose(vals, vals[0]), "window mixed transactions across accounts"


def test_first_transaction_has_empty_history(tmp_path):
    """Each account's earliest target has only its own (target) slot real."""
    history_len = 3
    ds, df, _ = _build(tmp_path, history_len=history_len)
    _, _, mask, _ = _collect(ds)
    n_real = mask.sum(dim=1)
    # one window per account should have exactly 1 real slot (no prior history)
    n_accounts = df["Nmap_account_reference_xid"].nunique()
    assert int((n_real == 1).sum()) == n_accounts


def test_fraud_targets_never_skipped(tmp_path):
    """With stride>1 the count of fraud-target windows still equals all fraud rows."""
    stride = 3
    ds, df, _ = _build(tmp_path, history_len=3, stride=stride)
    _, _, _, tgt = _collect(ds)
    n_fraud_rows = int(df["frd_tag"].sum())
    assert int(tgt.sum()) == n_fraud_rows
    # stride still subsamples non-fraud targets -> fewer windows than rows
    assert tgt.shape[0] < len(df)


def test_eval_window_count_matches_rows_per_account(tmp_path):
    """At stride=1 the number of windows equals the number of transactions."""
    ds, df, layout = _build(tmp_path, history_len=2, stride=1)
    _, _, _, tgt = _collect(ds)
    assert tgt.shape[0] == sum(n for _, n, _ in layout) == len(df)
