"""RUN-02 (R-007): the equal-timestamp history rule of both owned sequence builders.

Two transactions of one account can carry the same ``transaction_dttm``. Until this
change both builders sorted by (account, time, tie-break id) and let the
same-time row that sorts first count as history for the one that sorts second. The
option ``history_time_order`` now names the rule:

- ``strict``: only rows whose parsed timestamp is strictly before the target's enter
  its history (reference's plan text, lines 38 and 213: strictly earlier); the default.
- ``tiebreak``: the behaviour before this change, kept byte-identical for a
  sensitivity run. The walkthrough decides between the two (OQ-13).

The ``tiebreak`` windows are compared against the windows the builders produced at
PR #5 head 7ae90ef, captured before the option existed
(``YOUR_PACKAGE/tests/data/history_time_order_tiebreak_7ae90ef.json``).

Run: PYTHONPATH=src:. python -m pytest -p no:cacheprovider YOUR_PACKAGE/tests/test_history_time_order.py -q
"""

import json
import os
import sys

import numpy as np
import pandas as pd
import pytest
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from fraud.data.datetime_features import DatetimeConfig  # noqa: E402
from fraud.data.feature_list import load_feature_list  # noqa: E402
from YOUR_PACKAGE.phase4a import sequence_builder as builder_a  # noqa: E402
from YOUR_PACKAGE.phase4b import sequence_builder as builder_b  # noqa: E402
from YOUR_PACKAGE.tests.test_sequence_builder import DATETIME_FIELDS, _fit_artifacts, _write_predictors  # noqa: E402

ACCOUNT = "Nmap_account_reference_xid"
ID = "fi_transaction_id"
TIME = "transaction_dttm"
HISTORY_LEN = 3
FIXTURE = os.path.join(os.path.dirname(__file__), "data", "history_time_order_tiebreak_7ae90ef.json")
BUILDERS = {"phase4a": builder_a, "phase4b": builder_b}


def tie_frame():
    """Accounts with two and three same-time rows; ids whose text order differs from their number order.

    Account 100: 0h, 1h, two rows at 2h (ids T10 and T9: as text "T10" sorts before "T9"), 3h.
    Account 200: 0h, three rows at 5h, 6h.
    Account 300: one row.  Account 400: two rows at the same time and nothing else.
    ``f1`` is the row's position in this frame, so a window's history rows can be read back from the tensor.
    """
    base = pd.Timestamp("2024-03-01 00:00:00")
    layout = [
        (100, "T0001", 0, 0), (100, "T0002", 1, 0), (100, "T10", 2, 1), (100, "T9", 2, 0), (100, "T0003", 3, 1),
        (200, "T0101", 0, 0), (200, "T0110", 5, 0), (200, "T0111", 5, 1), (200, "T0109", 5, 0), (200, "T0112", 6, 0),
        (300, "T0301", 7, 1),
        (400, "T0401", 4, 0), (400, "T0402", 4, 1),
    ]
    rng = np.random.default_rng(7)
    rows = []
    for i, (acct, txn, hours, frd) in enumerate(layout):
        rows.append({TIME: base + pd.Timedelta(hours=hours), ACCOUNT: acct, ID: txn, "f1": float(i),
                     "f2": float(rng.normal()), "c1": rng.choice(["A", "B", "C"]), "c2": rng.choice(["X", "Y"]),
                     "frd_tag": frd})
    return pd.DataFrame(rows)


def make_inputs(tmp_path, frame):
    """Predictors, fitted artifacts and a parquet file for ``frame``."""
    csv_path = _write_predictors(tmp_path)
    features = load_feature_list(csv_path, version=1)
    dt_config = DatetimeConfig(order_col=TIME, fields=DATETIME_FIELDS, encoding="categorical", is_weekend=False)
    arts = _fit_artifacts(frame, features, dt_config)
    parquet_path = tmp_path / "part_1.parquet"
    frame.to_parquet(parquet_path, index=False)
    return dict(file_list=[str(parquet_path)], artifacts=arts, features=features, datetime_config=dt_config)


def build(module, inputs, history_len=HISTORY_LEN, **options):
    kwargs = dict(
        target_col="frd_tag", account_col=ACCOUNT, order_col=TIME, history_len=history_len, stride=1,
        positive_label=1, add_missing_flag=True, time_delta=True, batch_size=1024, shuffle=False,
        buffer_windows=1024, tie_break_col=ID, id_cols=[ID], s3_filesystem=None,
    )
    kwargs.update(inputs)
    kwargs.update(options)
    return module.SequenceBuilder(**kwargs)


def one_batch(dataset):
    batches = list(dataset)
    assert len(batches) == 1
    return batches[0]


def decode_windows(batch, dataset, frame):
    """{target id: {"slots": [history ids..., target id], "time_delta": [...], "mask": [...], "label": int}}."""
    f1_std = dataset.artifacts.standardize_continuous("f1", frame["f1"])
    id_of_value = {float(v): str(t) for v, t in zip(f1_std, frame[ID])}
    assert len(id_of_value) == len(frame)
    out = {}
    for w in range(batch["continuous"].shape[0]):
        target_id = str(batch["meta"][ID][w])
        slots, deltas, mask = [], [], []
        for s in range(batch["continuous"].shape[1]):
            real = bool(batch["mask"][w, s])
            mask.append(real)
            slots.append(id_of_value[float(batch["continuous"][w, s, 0])] if real else None)
            deltas.append(round(float(batch["continuous"][w, s, -1]), 6))
        assert slots[-1] == target_id
        out[target_id] = {"slots": slots, "time_delta": deltas, "mask": mask, "label": int(batch["target"][w, 0])}
    return out


# --------------------------------------------------------------------------- #
@pytest.fixture(params=sorted(BUILDERS), ids=sorted(BUILDERS))
def built(request, tmp_path):
    module = BUILDERS[request.param]
    frame = tie_frame()
    inputs = make_inputs(tmp_path, frame)
    strict = build(module, inputs, history_time_order="strict")
    tiebreak = build(module, inputs, history_time_order="tiebreak")
    return dict(name=request.param, module=module, frame=frame, inputs=inputs,
                strict=decode_windows(one_batch(strict), strict, frame),
                tiebreak=decode_windows(one_batch(tiebreak), tiebreak, frame))


def test_default_is_strict_and_other_values_are_rejected(tmp_path):
    frame = tie_frame()
    inputs = make_inputs(tmp_path, frame)
    for module in BUILDERS.values():
        assert build(module, inputs).history_time_order == "strict"
        with pytest.raises(ValueError, match="history_time_order"):
            build(module, inputs, history_time_order="earliest")


def test_tiebreak_reproduces_the_windows_captured_at_7ae90ef(built):
    with open(FIXTURE) as f:
        captured = json.load(f)
    assert captured["_meta"]["history_len"] == HISTORY_LEN
    assert built["tiebreak"] == captured[built["name"]]


def test_strict_admits_no_same_time_row_and_keeps_the_strictly_earlier_rows(built):
    frame = built["frame"]
    time_of = dict(zip(frame[ID], frame[TIME]))
    for target, window in built["strict"].items():
        history = [h for h in window["slots"][:-1] if h is not None]
        assert all(time_of[h] < time_of[target] for h in history), (target, history)
        # the most recent strictly earlier rows of the account, up to history_len, in time then id order
        acct = frame.loc[frame[ID] == target, ACCOUNT].item()
        earlier = frame[(frame[ACCOUNT] == acct) & (frame[TIME] < time_of[target])].sort_values([TIME, ID])
        assert history == list(earlier[ID])[-HISTORY_LEN:], target
    # two same-time rows (account 400): neither sees the other; three same-time rows (account 200): all see only T0101
    assert built["strict"]["T0401"]["slots"] == [None, None, None, "T0401"]
    assert built["strict"]["T0402"]["slots"] == [None, None, None, "T0402"]
    for target in ("T0109", "T0110", "T0111"):
        assert built["strict"][target]["slots"] == [None, None, "T0101", target]
    assert built["strict"]["T9"]["slots"] == [None, "T0001", "T0002", "T9"]
    assert built["tiebreak"]["T9"]["slots"] == ["T0001", "T0002", "T10", "T9"]  # the difference the rule removes
    # a later time still sees the same-time pair in tie-break order
    assert built["strict"]["T0003"]["slots"] == built["tiebreak"]["T0003"]["slots"] == ["T0002", "T10", "T9", "T0003"]


def test_strict_and_tiebreak_agree_where_no_tie_precedes_the_target(built):
    frame = built["frame"]
    for target in frame[ID]:
        acct_rows = frame[frame[ACCOUNT] == frame.loc[frame[ID] == target, ACCOUNT].item()]
        t = frame.loc[frame[ID] == target, TIME].item()
        same_time_before = acct_rows[(acct_rows[TIME] == t) & (acct_rows[ID] < target)]
        if same_time_before.empty:
            assert built["strict"][target] == built["tiebreak"][target], target


def test_time_channel_is_unchanged_for_admitted_rows(built):
    """log1p(t_target minus row time) of a history row does not depend on the rule that admitted it."""
    frame = built["frame"]
    seconds = {t: int(ts.timestamp()) for t, ts in zip(frame[ID], frame[TIME])}
    for rule in ("strict", "tiebreak"):
        for target, window in built[rule].items():
            for slot, delta in zip(window["slots"], window["time_delta"]):
                if slot is not None:
                    expected = float(np.log1p(max(0, seconds[target] - seconds[slot])))
                    assert delta == pytest.approx(expected, abs=2e-6), (rule, target, slot)
    checked = 0
    for target, window in built["strict"].items():
        tiebreak = dict(zip(built["tiebreak"][target]["slots"], built["tiebreak"][target]["time_delta"]))
        for slot, delta in zip(window["slots"], window["time_delta"]):
            if slot is not None and slot in tiebreak:
                assert delta == tiebreak[slot]
                checked += 1
    assert checked > len(frame)


def test_strict_judges_equal_time_on_the_parsed_timestamp_not_on_whole_seconds(tmp_path):
    """Sub-second timestamps: 10.2 s is strictly before 10.7 s and is admitted; two rows at 10.7 s are not."""
    frame = tie_frame().iloc[:3].copy()
    frame[ACCOUNT] = 500
    frame[ID] = ["T0501", "T0502", "T0503"]
    base = pd.Timestamp("2024-03-01 00:00:10")
    frame[TIME] = [base + pd.Timedelta(milliseconds=200), base + pd.Timedelta(milliseconds=700),
                   base + pd.Timedelta(milliseconds=700)]
    inputs = make_inputs(tmp_path, frame)
    for module in BUILDERS.values():
        ds = build(module, inputs, history_time_order="strict")
        windows = decode_windows(one_batch(ds), ds, frame)
        assert windows["T0502"]["slots"] == [None, None, "T0501", "T0502"]
        assert windows["T0503"]["slots"] == [None, None, "T0501", "T0503"]
        assert windows["T0502"]["time_delta"][2] == 0.0  # the channel still works in whole seconds


def test_all_position_chunks_accept_strict_and_tiebreak(tmp_path):
    """B9: the B chunk builder implements both rules (strict by default and in the all-position config);
    an unknown rule is still rejected."""
    frame = tie_frame()
    inputs = make_inputs(tmp_path, frame)
    chunk_options = dict(emit_target_seq=True, all_position_layout="nonoverlapping_chunks",
                         time_delta_reference="previous_transaction")
    assert build(builder_b, inputs, **chunk_options).history_time_order == "strict"
    # tiebreak cuts every H+1 rows. strict (B9 amendment) cuts only between seconds, H+1 distinct seconds per
    # chunk: accounts 100 (4 seconds) and 200 (3 seconds) each form one 5-row chunk, so the batch is 5 wide.
    for rule, width in (("strict", 5), ("tiebreak", HISTORY_LEN + 1)):
        batch = one_batch(build(builder_b, inputs, history_time_order=rule, **chunk_options))
        assert batch["mask"].shape[1] == width and int(batch["mask"].sum()) == len(frame)
        assert batch["time_seq"].shape == batch["mask"].shape
    with pytest.raises(ValueError, match="history_time_order"):
        build(builder_b, inputs, history_time_order="earliest", **chunk_options)

    from omegaconf import OmegaConf
    from YOUR_PACKAGE.phase4b.factory import sequence_dataset_options
    cfg = OmegaConf.load(os.path.join(os.path.dirname(__file__), "..", "phase4b/configs/sequential_hier_allposition.yaml"))
    assert sequence_dataset_options(cfg)["history_time_order"] == "strict"
    cfg.sequence.history_time_order = "tiebreak"
    assert sequence_dataset_options(cfg)["history_time_order"] == "tiebreak"
    cfg.sequence.history_time_order = "earliest"
    with pytest.raises(ValueError, match="history_time_order"):
        sequence_dataset_options(cfg)


def test_configs_and_contract_carry_the_rule(tmp_path):
    from omegaconf import OmegaConf
    from YOUR_PACKAGE.base.data.contracts import build_input_contract
    from YOUR_PACKAGE.phase4b.factory import sequence_dataset_options
    root = os.path.join(os.path.dirname(__file__), "..")
    cfg_a = OmegaConf.load(os.path.join(root, "phase4a/configs/sequential.yaml"))
    cfg_b = OmegaConf.load(os.path.join(root, "phase4b/configs/sequential_hier.yaml"))
    assert cfg_a.sequence.history_time_order == "strict"
    assert cfg_b.sequence.history_time_order == "strict"
    assert sequence_dataset_options(cfg_b)["history_time_order"] == "strict"
    inputs = make_inputs(tmp_path, tie_frame())
    for module in BUILDERS.values():
        for rule in ("strict", "tiebreak"):
            assert build_input_contract(build(module, inputs, history_time_order=rule))["history_time_order"] == rule


def test_a_checkpoint_trained_under_one_rule_is_refused_under_the_other(tmp_path):
    """A checkpoint is scored under the rule it was trained with: the saved input contract names the rule, and a
    contract built under the other rule is refused (review F5)."""
    from YOUR_PACKAGE.base.data.checkpoint_contracts import INPUT_CONTRACT_KEY, validate_input_contract
    from YOUR_PACKAGE.base.data.contracts import build_input_contract
    inputs = make_inputs(tmp_path, tie_frame())
    for module in BUILDERS.values():
        strict = build_input_contract(build(module, inputs, history_time_order="strict"))
        tiebreak = build_input_contract(build(module, inputs, history_time_order="tiebreak"))
        validate_input_contract({INPUT_CONTRACT_KEY: strict}, strict)
        with pytest.raises(ValueError, match="input contract mismatch"):
            validate_input_contract({INPUT_CONTRACT_KEY: strict}, tiebreak)


def test_no_run_header_sends_the_owner_around_the_preflight():
    """ST14 (R-090; review F2): a '# Run:' header under the two config folders never names run_ablations.py or
    reference's fraud/scripts/, which skip the pre-flight and the ledger (tune.yaml: review F9)."""
    import glob
    root = os.path.join(os.path.dirname(__file__), "..")
    specs = sorted(glob.glob(os.path.join(root, "phase4a/configs/*.yaml")) +
                   glob.glob(os.path.join(root, "phase4b/configs/*.yaml")))
    assert len(specs) > 10
    stale = []
    for path in specs:
        with open(path, encoding="utf-8") as f:
            for number, line in enumerate(f, 1):
                if line.startswith("# Run:") and ("run_ablations.py" in line or "fraud/scripts/" in line):
                    stale.append(f"{os.path.basename(path)}:{number}")
    assert stale == []
