"""YOUR_PACKAGE/scripts/build_leaderboard.py (owner, 2026-10-08) on both results layouts: the older runner's single
results.csv per test folder, and attempt folders (<output_root>/<attempt>/results.csv, a latest-view copy at
<output_root>/results.csv and previous_results.csv). Failed runs are never ranked and each run is counted once
(reviewer's SRC-02, SRC-03, SRC-04). RUN-07: every successful run is ranked by best_valid_ap per study, eval_ap and
eval_auroc are shown but never ranked (R-011), and rows without a status (the older runner's) are listed in a
separate unranked history section (R-032)."""
import csv
import importlib.util
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("build_leaderboard", ROOT / "YOUR_PACKAGE/scripts/build_leaderboard.py")
lb = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lb)

OLD_COLS = ["run_name", "history", "train_rc", "best_valid_ap", "best_valid_auroc", "eval_ap", "eval_auroc"]
RUNNER_COLS = ["attempt", "run_dir", "score_rc", "status", "predictions_path", "n_predictions", "n_positives",
               "checkpoint_epoch", "checkpoint_step", "checkpoint_monitor", "checkpoint_monitor_score",
               "checkpoint_sha256", "resolved_train_sha256", "source_sha256", "manifest_path", "error"]
NEW_COLS = OLD_COLS + RUNNER_COLS


def _write(path, cols, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({c: r.get(c, "") for c in cols})


def _row(run, attempt="", status="ok", rc=0, valid=None, eval_ap=None, **kw):
    return {"run_name": run, "history": run, "train_rc": rc, "best_valid_ap": valid, "best_valid_auroc": valid,
            "eval_ap": eval_ap, "eval_auroc": eval_ap, "attempt": attempt, "status": status if attempt else "",
            "run_dir": f"/x/{attempt}/{run}", "error": "", **kw}


def _board(tmp_path):
    rows, axes = lb.load_all_rows(str(tmp_path / "ablations"))
    ranked, unranked = lb.write_leaderboard(rows, axes, str(tmp_path / "board.csv"))
    with (tmp_path / "board.csv").open(newline="") as f:
        written = list(csv.DictReader(f))
    return ranked, unranked, written


def test_attempt_layout_counts_each_run_once_and_keeps_legacy_rows(tmp_path):
    test = tmp_path / "ablations/arch_b_hier/history_h5_h10"
    legacy = [_row("history-h5", rc=0, valid=0.30), _row("history-h10", rc=0, valid=0.31)]
    a1 = [_row("history-h5", "A1", valid=0.40, eval_ap=0.08), _row("history-h10", "A1", valid=0.41, eval_ap=0.09)]
    a2 = [_row("history-h5", "A2", valid=0.42, eval_ap=0.10)]
    _write(test / "A1/previous_results.csv", OLD_COLS, legacy)   # what the first attempt's latest view replaced
    _write(test / "A1/results.csv", NEW_COLS, a1)
    _write(test / "A2/previous_results.csv", NEW_COLS, a1)       # the second attempt replaced the first's view
    _write(test / "A2/results.csv", NEW_COLS, a2)
    _write(test / "results.csv", NEW_COLS, a2)                   # latest view
    for attempt in ("A1", "A2"):
        (test / attempt / "ablation_spec.yaml").write_text("x: 1\n")
    ranked, unranked, written = _board(tmp_path)
    keys = sorted((r["attempt"], r["run_name"]) for r in written)
    assert keys == [("", "history-h10"), ("", "history-h5"), ("A1", "history-h10"), ("A1", "history-h5"),
                    ("A2", "history-h5")]
    assert {r["source_csv"].split("history_h5_h10/")[1] for r in written if r["attempt"]} == {"A1/results.csv",
                                                                                               "A2/results.csv"}
    assert not [c for c in written[0] if c in ("run_dir", "error", "status_x")]  # bookkeeping is not an axis
    # the legacy rows are kept but belong to the history section, never ranked with the attempt rows (R-032)
    section = {(r["attempt"], r["run_name"]): r["section"] for r in written}
    assert section[("", "history-h5")] == section[("", "history-h10")] == lb.SECTION_HISTORY
    assert {section[k] for k in section if k[0]} == {lb.SECTION_RANKED}
    assert [(r["attempt"], r["run_name"], r["rank"]) for r in written if r["rank"]] == [
        ("A2", "history-h5", "1"), ("A1", "history-h10", "2"), ("A1", "history-h5", "3")]  # by best_valid_ap
    assert sorted(r["run_name"] for r in unranked) == ["history-h10", "history-h5"]


def test_failed_and_rejected_runs_are_listed_but_never_ranked(tmp_path):
    test = tmp_path / "ablations/arch_a_flat/core"
    rows = [_row("h5", "A1", valid=0.50, eval_ap=0.20),
            _row("h10", "A1", status="score_failed", valid=0.90),            # trained, scoring failed
            _row("h15", "A1", status="source_changed", valid=0.95, eval_ap=0.99),
            _row("h20", "A1", status="train_failed", rc=7),
            _row("ok-nan", "A1", valid=float("nan"))]                         # status ok, validation AP not finite
    _write(test / "A1/results.csv", NEW_COLS, rows)
    (test / "A1/ablation_spec.yaml").write_text("x: 1\n")
    _write(tmp_path / "ablations/arch_a_flat/old/results.csv", OLD_COLS,
           [_row("crashed", rc=1, valid=0.99), _row("fine", rc=0, valid=0.10)])
    ranked, unranked, written = _board(tmp_path)
    assert [r["run_name"] for r in ranked] == ["h5"]  # "fine" has no status: history, not ranked (R-032)
    assert [r["run_name"] for r in unranked] == ["h10", "h15", "h20", "ok-nan", "crashed", "fine"]  # failed, history
    assert all(r["rank"] == "" for r in written if r["run_name"] != "h5")
    assert {r["section"] for r in written if r["run_name"] in {"h10", "h15", "h20", "ok-nan"}} == {lb.SECTION_NOT_RANKED}
    assert {r["section"] for r in written if r["run_name"] in {"crashed", "fine"}} == {lb.SECTION_HISTORY}


def test_runs_are_ranked_by_validation_ap_only_and_evaluation_ap_is_shown_unranked(tmp_path):
    """Formerly test_evaluation_and_validation_ap_are_ranked_separately, which pinned the eval_ap ranking that
    R-011 removes. Scored and validation-only studies are both ranked by best_valid_ap, per study; a run with the
    highest eval_ap but a lower best_valid_ap ranks lower; eval_ap and eval_auroc are written, never ranked."""
    scored = tmp_path / "ablations/arch_a_flat/scored"
    _write(scored / "A1/results.csv", NEW_COLS, [_row("s1", "A1", valid=0.30, eval_ap=0.09),
                                                 _row("s2", "A1", valid=0.31, eval_ap=0.05),
                                                 _row("s3", "A1", valid=0.20, eval_ap=0.20)])
    (scored / "A1/ablation_spec.yaml").write_text("x: 1\n")
    valid_only = tmp_path / "ablations/arch_b_hier/valid_only"
    _write(valid_only / "B1/results.csv", NEW_COLS, [_row("v1", "B1", valid=0.40), _row("v2", "B1", valid=0.45)])
    (valid_only / "B1/ablation_spec.yaml").write_text("x: 1\n")
    ranked, unranked, written = _board(tmp_path)
    assert unranked == []
    order = [(r["test"], r["rank_metric"], r["rank"], r["run_name"], r["eval_ap"]) for r in written]
    assert order == [("scored", "best_valid_ap", "1", "s2", "0.05"), ("scored", "best_valid_ap", "2", "s1", "0.09"),
                     ("scored", "best_valid_ap", "3", "s3", "0.2"),
                     ("valid_only", "best_valid_ap", "1", "v2", ""), ("valid_only", "best_valid_ap", "2", "v1", "")]
    assert {r["rank_metric"] for r in written} == {"best_valid_ap"} and {r["section"] for r in written} == {"ranked"}
    assert [r["rank_value"] for r in written] == ["0.31", "0.3", "0.2", "0.45", "0.4"]  # never an eval_ap
    assert "eval_auroc" in written[0] and written[0]["eval_auroc"] == "0.05"


def test_rank_restarts_per_study_and_studies_are_not_compared(tmp_path):
    for test, runs in (("h0", [("a", 0.10), ("b", 0.12)]), ("h10", [("c", 0.50)])):
        folder = tmp_path / f"ablations/arch_a_flat/{test}"
        _write(folder / "A1/results.csv", NEW_COLS, [_row(run, "A1", valid=valid) for run, valid in runs])
        (folder / "A1/ablation_spec.yaml").write_text("x: 1\n")
    ranked, _, written = _board(tmp_path)
    assert [(r["test"], r["rank"], r["run_name"]) for r in written] == [("h0", "1", "b"), ("h0", "2", "a"),
                                                                        ("h10", "1", "c")]


def test_rows_without_a_status_are_listed_in_the_history_section_and_never_ranked(tmp_path, capsys):
    """R-032: the older runner's rows (no status, no attempt) are kept, unranked, after the attempt rows, even when
    their train_rc is 0 and their best_valid_ap beats every ranked run; the summary prints them under their own title."""
    test = tmp_path / "ablations/arch_a_flat/core"
    _write(test / "results.csv", OLD_COLS, [_row("old-best", rc=0, valid=0.99, eval_ap=0.50),
                                            _row("old-crashed", rc=1, valid=0.98)])
    _write(test / "A1/results.csv", NEW_COLS, [_row("new-ok", "A1", valid=0.30, eval_ap=0.10),
                                               _row("new-failed", "A1", status="train_failed", rc=3)])
    (test / "A1/ablation_spec.yaml").write_text("x: 1\n")
    ranked, unranked, written = _board(tmp_path)
    assert [r["run_name"] for r in ranked] == ["new-ok"]
    assert [(r["run_name"], r["section"], r["rank"]) for r in written] == [
        ("new-ok", lb.SECTION_RANKED, "1"), ("new-failed", lb.SECTION_NOT_RANKED, ""),
        ("old-best", lb.SECTION_HISTORY, ""), ("old-crashed", lb.SECTION_HISTORY, "")]
    lb.print_summary(ranked, unranked)
    out = capsys.readouterr().out
    assert "1 ranked runs, 1 not ranked, 0 smoke, 2 earlier results" in out
    assert "ranked by best_valid_ap (validation files); eval_ap and eval_auroc shown, not ranked" in out
    assert "--- earlier results (history)" in out and out.index("old-best") > out.index("earlier results (history)")
    assert out.index("new-failed") > out.index("--- not ranked") and "eval_ap" not in out.split("---")[0].split("Rank:")[0]


def test_smoke_rows_are_listed_in_their_own_section_and_never_ranked(tmp_path, capsys):
    """Scope section 2, smoke row: the smoke run before batch 1 (ablations/<arch>/smoke_h5, run smoke-h5) is listed
    under "smoke (not ranked)", never ranked, and the real studies still rank from 1 (review F3)."""
    for arch in ("arch_a_flat", "arch_b_hier"):
        smoke = tmp_path / f"ablations/{arch}/smoke_h5"
        _write(smoke / "A1/results.csv", NEW_COLS, [_row("smoke-h5", "A1", valid=0.99, eval_ap=0.50)])
        (smoke / "A1/ablation_spec.yaml").write_text("x: 1\n")
    real = tmp_path / "ablations/arch_a_flat/history_h0_vs_h5"
    _write(real / "A1/results.csv", NEW_COLS, [_row("h0", "A1", valid=0.20), _row("h5", "A1", valid=0.30)])
    (real / "A1/ablation_spec.yaml").write_text("x: 1\n")
    ranked, unranked, written = _board(tmp_path)
    assert [(r["test"], r["run_name"], r["rank"]) for r in ranked] == [("history_h0_vs_h5", "h5", 1),
                                                                       ("history_h0_vs_h5", "h0", 2)]
    smoke_rows = [r for r in written if r["run_name"] == "smoke-h5"]
    assert len(smoke_rows) == 2 and {(r["rank"], r["section"]) for r in smoke_rows} == {("", lb.SECTION_SMOKE)}
    lb.print_summary(ranked, unranked)
    out = capsys.readouterr().out
    assert "2 ranked runs, 0 not ranked, 2 smoke, 0 earlier results" in out
    assert "--- smoke (not ranked)" in out and out.index("smoke-h5") > out.index("--- smoke (not ranked)")


@pytest.mark.parametrize("phase", ["phase4a", "phase4b"])
def test_real_runner_output_is_counted_once(tmp_path, phase):
    """Two runs of the actual runner (synthetic train/score stubs) into one output root, over a legacy results.csv."""
    from YOUR_PACKAGE.tests.test_ablation_artifacts import launch, make_app

    app = make_app(tmp_path, phase)
    root = app[0]
    latest = root / "ablations/grid/results.csv"
    latest.parent.mkdir(parents=True)
    latest.write_text("run_name,train_rc,best_valid_ap\nlegacy,0,0.9\n")
    attempts = set()
    for _ in range(2):
        proc, rows = launch(app)
        assert proc.returncode == 0, proc.stdout + proc.stderr
        attempts.add(rows[0]["attempt"])
    rows, _ = lb.load_all_rows(str(root / "ablations"))
    # legacy + one row per attempt; not 5 (the latest view and both previous_results.csv copies repeat them)
    assert sorted((r["attempt"], r["run_name"]) for r in rows) == sorted(
        [("", "legacy")] + [(a, "mask-bidir") for a in attempts])
    assert {(r["architecture"], r["test"]) for r in rows} == {("grid", "-")}
