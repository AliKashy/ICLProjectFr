"""ST12 (R-064): history rows' fraud labels (frd_tag) cannot change the model inputs.

The rule 'no earlier fraud label as model input' (OWNER_QA section D.5; validation matrix C1, C4) had only a
synthetic probe (E1). This names it as a regression test for both owned builders: windows built from the same
rows with every label flipped have identical continuous, categorical and mask tensors, so every history row's
label is flipped and nothing the model sees changes; only the target column changes. The A model and the
default (single-target) B model then give identical logits on the two batches.

Run: PYTHONPATH=src:. python -m pytest -p no:cacheprovider YOUR_PACKAGE/tests/test_history_labels_not_inputs.py -q
"""

import os
import sys

import pytest
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from YOUR_PACKAGE.phase4a.sequential import FTTransformerSeqModel  # noqa: E402
from YOUR_PACKAGE.phase4b.sequential_hier import FTTransformerHierModel  # noqa: E402
from YOUR_PACKAGE.tests.test_history_time_order import BUILDERS, HISTORY_LEN, build, make_inputs, one_batch, tie_frame  # noqa: E402

INPUT_KEYS = ("continuous", "categorical", "mask")


def _flipped_inputs(tmp_path, frame):
    flipped = frame.copy()
    flipped["frd_tag"] = 1 - flipped["frd_tag"]
    folder = tmp_path / "flipped"
    folder.mkdir(exist_ok=True)
    inputs = make_inputs(folder, frame)  # the SAME fitted artifacts: only the labels differ
    path = folder / "part_1.parquet"
    flipped.to_parquet(path, index=False)
    inputs["file_list"] = [str(path)]
    return inputs


@pytest.mark.parametrize("rule", ["strict", "tiebreak"])
@pytest.mark.parametrize("name", sorted(BUILDERS))
def test_flipping_every_history_label_leaves_the_model_inputs_identical(tmp_path, name, rule):
    module = BUILDERS[name]
    frame = tie_frame()
    assert set(frame["frd_tag"]) == {0, 1}
    original = one_batch(build(module, make_inputs(tmp_path, frame), history_time_order=rule))
    flipped = one_batch(build(module, _flipped_inputs(tmp_path, frame), history_time_order=rule))
    assert original["mask"].sum() > original["mask"].shape[0]  # windows really carry history rows
    for key in INPUT_KEYS:
        assert torch.equal(original[key], flipped[key]), key
    assert torch.equal(flipped["target"], 1 - original["target"])  # only the target's own label moved
    assert list(original["meta"]["fi_transaction_id"]) == list(flipped["meta"]["fi_transaction_id"])


@pytest.mark.parametrize("name", sorted(BUILDERS))
def test_a_and_default_b_logits_do_not_depend_on_history_labels(tmp_path, name):
    module = BUILDERS[name]
    frame = tie_frame()
    original = one_batch(build(module, make_inputs(tmp_path, frame)))
    flipped = one_batch(build(module, _flipped_inputs(tmp_path, frame)))
    C = original["continuous"].shape[-1]
    (tmp_path / "cards").mkdir()
    dataset = build(module, make_inputs(tmp_path / "cards", frame))
    cards = list(dataset.categorical_cardinality)
    torch.manual_seed(0)
    models = {
        "A": FTTransformerSeqModel(continuous_dim=C, categorical_cardinality=cards, history_len=HISTORY_LEN,
                                   embed_dim=16, num_heads=2, num_attn_blocks=2, attn_dropout=0.0, ff_dropout=0.0,
                                   attention_mask="bidirectional"),
        "B": FTTransformerHierModel(continuous_dim=C, categorical_cardinality=cards, history_len=HISTORY_LEN,
                                    embed_dim=16, num_heads=2, num_txn_blocks=1, num_seq_blocks=2,
                                    attn_dropout=0.0, ff_dropout=0.0, attention_mask="bidirectional"),
    }
    for arch, model in models.items():
        model.eval()
        with torch.no_grad():
            a, b = model(original), model(flipped)
        assert a.shape == (original["mask"].shape[0], 2)
        assert torch.equal(a, b), arch
