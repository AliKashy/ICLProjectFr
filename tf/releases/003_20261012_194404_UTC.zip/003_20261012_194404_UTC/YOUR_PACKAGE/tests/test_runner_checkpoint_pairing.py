"""The runner's metric pairing must match a real Lightning-produced checkpoint."""

import importlib

import pytest
import pytorch_lightning as pl
from pytorch_lightning.callbacks import ModelCheckpoint
import torch
from torch.utils.data import DataLoader, TensorDataset

from fraud.callbacks import CSVMetricsCallback


class SmallModel(pl.LightningModule):
    def __init__(self):
        super().__init__()
        self.layer = torch.nn.Linear(1, 1)

    def training_step(self, batch, batch_idx):
        return self.layer(batch[0]).square().mean()

    def validation_step(self, batch, batch_idx):
        # The AUROC peak deliberately occurs after the selected AP checkpoint.
        self.log("valid_ap", 0.42 if self.current_epoch == 0 else 0.4,
                 on_epoch=True, batch_size=2)
        self.log("valid_auroc", 0.73 if self.current_epoch == 0 else 0.88,
                 on_epoch=True, batch_size=2)

    def configure_optimizers(self):
        return torch.optim.SGD(self.parameters(), lr=0.01)


@pytest.mark.parametrize("phase", ["phase4a", "phase4b"])
def test_pairing_uses_actual_saved_lightning_epoch_and_step(tmp_path, phase):
    metrics_path = tmp_path / "training_metrics.csv"
    checkpoint = ModelCheckpoint(dirpath=tmp_path, filename="best", monitor="valid_ap",
                                 mode="max", enable_version_counter=False)
    trainer = pl.Trainer(max_epochs=2, accelerator="cpu", devices=1, logger=False,
                         enable_progress_bar=False, enable_model_summary=False,
                         num_sanity_val_steps=0,
                         callbacks=[CSVMetricsCallback(str(metrics_path)), checkpoint])
    batches = DataLoader(TensorDataset(torch.ones(2, 1)), batch_size=2)
    trainer.fit(SmallModel(), batches, batches)
    runner = importlib.import_module(f"YOUR_PACKAGE.{phase}.scripts.run_ablations")
    result = runner._checkpoint_metrics(str(tmp_path / "best.ckpt"), str(metrics_path), "valid_ap")
    assert result["best_valid_ap"] == pytest.approx(0.42)
    assert result["best_valid_auroc"] == pytest.approx(0.73)
    assert result["checkpoint_monitor_score"] == pytest.approx(0.42)
    assert result["checkpoint_epoch"] == 0
    assert result["checkpoint_step"] == 1
