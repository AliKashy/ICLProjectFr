"""Run owner's sequence-builder windowing tests (test_sequence_builder.py) against the corrected copy as well.

test_sequence_builder.py keeps testing reference's original fraud.data.sequence_builder, as it did on main. The corrected
copy in YOUR_PACKAGE/base/data/sequence_builder.py (used by the copied reference scripts) gets the same nine checks here:
shapes, every transaction scored once, target slot, no future leakage through the time gap, left padding, account
isolation, empty first history, fraud never skipped by stride, and the evaluation window count.
"""
import pytest

import YOUR_PACKAGE.tests.test_sequence_builder as original_tests
from YOUR_PACKAGE.base.data.sequence_builder import SequenceBuilder as CorrectedSequenceBuilder

TESTS = sorted((name, fn) for name, fn in vars(original_tests).items() if name.startswith("test_") and callable(fn))


def test_original_tests_still_target_reference_builder():
    assert original_tests.SequenceBuilder.__module__ == "fraud.data.sequence_builder"
    assert len(TESTS) == 9


@pytest.mark.parametrize("name,fn", TESTS, ids=[n for n, _ in TESTS])
def test_corrected_copy(name, fn, tmp_path, monkeypatch):
    monkeypatch.setattr(original_tests, "SequenceBuilder", CorrectedSequenceBuilder)
    fn(tmp_path)
