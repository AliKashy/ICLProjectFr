"""Cohort conservation and calendar gaps in descriptive period reporting."""

import sys

import numpy as np
import pandas as pd
import pytest

from YOUR_PACKAGE.scoring import temporal_eval


def _inputs():
    preds = pd.DataFrame({"id": [1, 2, 3, 4, 5], "acct": ["a", "a", "b", "b", "c"],
                          "target": [0, 1, 1, 0, 1], "score": [0.1, 0.9, 0.5, 0.9, 0.1]})
    times = pd.DataFrame({"id": [1, 2, 3, 4, 5], "acct": ["a", "a", "b", "b", "c"], "timestamp": [
        "2024-01-15", "2024-01-15", "2024-03-15", "2024-04-15", "2024-04-15"]})
    return preds, times


def _prepare(preds, times, extra_cols=()):
    return temporal_eval._prepare_predictions(preds, times, "id", "target", "score", "timestamp",
                                              account_col="acct", extra_cols=extra_cols)


def test_raw_superset_preserves_prediction_cohort_and_its_calendar_bounds():
    preds, times = _inputs()
    extra = pd.DataFrame({"id": [90, 91, 92], "acct": ["x", "y", "z"],
                          "timestamp": ["2023-01-01", "2025-01-01", "unused-invalid-time"]})
    raw = pd.concat([times, extra], ignore_index=True).sample(frac=1, random_state=3)
    shuffled = preds.sample(frac=1, random_state=7)
    prepared = _prepare(shuffled, raw)
    assert prepared.id.tolist() == shuffled.id.tolist()
    pd.testing.assert_frame_equal(prepared[preds.columns].reset_index(drop=True),
                                  shuffled.reset_index(drop=True))
    rows = temporal_eval._period_metrics(prepared, "month", "timestamp", "target", "score")
    assert [row["bucket"] for row in rows] == ["2024-01", "2024-02", "2024-03", "2024-04"]
    assert sum(row["n"] for row in rows) == len(preds)


def test_empty_and_single_class_months_remain_and_trend_uses_calendar_distance():
    preds, times = _inputs()
    rows = temporal_eval._period_metrics(_prepare(preds, times), "month", "timestamp", "target", "score")
    assert [row["n"] for row in rows] == [2, 0, 1, 2]
    assert [row["positives"] for row in rows] == [1, 0, 1, 1]
    assert [row["status"] for row in rows] == ["ok", "empty", "single_class", "ok"]
    assert rows[1]["fraud_rate"] is None
    assert rows[2]["fraud_rate"] == 1.0
    for row in rows[1:3]:
        assert row["pr_auc"] is None and row["roc_auc"] is None
    ap_trend = temporal_eval._trend(rows, "pr_auc")
    auc_trend = temporal_eval._trend(rows, "roc_auc")
    assert ap_trend["first_bucket"] == "2024-01"
    assert ap_trend["last_bucket"] == "2024-04"
    assert ap_trend["delta"] == pytest.approx(-0.5)
    assert ap_trend["slope"] == pytest.approx(-0.5 / 3)
    assert auc_trend["slope"] == pytest.approx(-1.0 / 3)


@pytest.mark.parametrize("period,dates,expected", [
    ("day", ["2024-02-28", "2024-03-01"], ["2024-02-28", "2024-02-29", "2024-03-01"]),
    ("week", ["2023-12-31", "2024-01-08"],
     ["2023-12-25/2023-12-31", "2024-01-01/2024-01-07", "2024-01-08/2024-01-14"]),
])
def test_actual_calendar_period_order_across_boundaries(period, dates, expected):
    preds = pd.DataFrame({"id": [1, 2], "acct": ["a", "b"], "target": [0, 1], "score": [0.2, 0.8]})
    times = pd.DataFrame({"id": [1, 2], "acct": ["a", "b"], "timestamp": dates})
    rows = temporal_eval._period_metrics(_prepare(preds.iloc[::-1], times), period,
                                         "timestamp", "target", "score")
    assert [row["bucket"] for row in rows] == expected
    assert [row["n"] for row in rows] == [1, 0, 1]
    assert temporal_eval._trend(rows, "pr_auc") is None


def test_supplied_timezone_calendar_is_preserved():
    preds = pd.DataFrame({"id": [1, 2], "acct": ["a", "b"], "target": [0, 1], "score": [0.2, 0.8]})
    times = pd.DataFrame({"id": [1, 2], "acct": ["a", "b"], "timestamp": pd.to_datetime([
        "2024-01-31T23:30:00-05:00", "2024-02-01T00:30:00-05:00"])})
    rows = temporal_eval._period_metrics(_prepare(preds, times), "month", "timestamp", "target", "score")
    assert [row["bucket"] for row in rows] == ["2024-01", "2024-02"]


@pytest.mark.parametrize("case,message", [
    ("duplicate_pred", "predictions: IDs"),
    ("duplicate_raw", "raw timestamps: IDs"),
    ("null_pred_id", "predictions: IDs"),
    ("null_raw_id", "raw timestamps: IDs"),
    ("null_pred_account", "predictions: account IDs \\(acct\\)"),
    ("null_raw_account", "raw timestamps: account IDs \\(acct\\)"),
    ("unmatched", "lack timestamps for 1 prediction IDs"),
    ("missing_timestamp", "Invalid or missing timestamps"),
    ("invalid_timestamp", "Invalid or missing timestamps"),
    ("numeric_timestamp", "explicit unit conversion"),
    ("mixed_numeric_timestamp", "explicit unit conversion"),
    ("nonbinary_target", "binary values"),
    ("null_target", "binary values"),
    ("nan_score", "finite numeric"),
    ("inf_score", "finite numeric"),
    ("nonnumeric_score", "finite numeric"),
    ("empty_predictions", "cohort is empty"),
])
def test_invalid_inputs_are_rejected_instead_of_dropped(case, message):
    preds, times = _inputs()
    if case == "duplicate_pred":
        preds.loc[1, "id"] = 1
        preds.loc[1, "acct"] = "a"
        preds.loc[0, "acct"] = "a"
    elif case == "duplicate_raw":
        times.loc[1, "id"] = 1
    elif case == "null_pred_account":
        preds.loc[1, "acct"] = None
    elif case == "null_raw_account":
        times.loc[1, "acct"] = None
    elif case == "null_pred_id":
        preds.loc[1, "id"] = np.nan
    elif case == "null_raw_id":
        times.loc[1, "id"] = np.nan
    elif case == "unmatched":
        times = times.iloc[1:]
    elif case == "missing_timestamp":
        times.loc[1, "timestamp"] = None
    elif case == "invalid_timestamp":
        times.loc[1, "timestamp"] = "not-a-time"
    elif case == "numeric_timestamp":
        times["timestamp"] = 1700000000
    elif case == "mixed_numeric_timestamp":
        times["timestamp"] = pd.Series([
            pd.Timestamp("2024-01-15"), 1700000000, pd.Timestamp("2024-03-15"),
            pd.Timestamp("2024-04-15"), pd.Timestamp("2024-04-15")], dtype=object)
    elif case == "nonbinary_target":
        preds["target"] = preds.target.astype(float)
        preds.loc[1, "target"] = 0.5
    elif case == "null_target":
        preds.loc[1, "target"] = np.nan
    elif case == "nan_score":
        preds.loc[1, "score"] = np.nan
    elif case == "inf_score":
        preds.loc[1, "score"] = np.inf
    elif case == "nonnumeric_score":
        preds["score"] = preds.score.astype(object)
        preds.loc[1, "score"] = "not-a-score"
    elif case == "empty_predictions":
        preds = preds.iloc[:0]
    with pytest.raises(ValueError, match=message):
        _prepare(preds, times)


@pytest.mark.parametrize("invalid", [False, True])
def test_cli_with_local_parquet_preserves_cohort_or_fails_explicitly(tmp_path, monkeypatch, capsys, invalid):
    preds, times = _inputs()
    if invalid:
        times = times.iloc[1:]
    raw = tmp_path / "raw"
    raw.mkdir()
    pred_path, out = tmp_path / "preds.parquet", tmp_path / "metrics.csv"
    preds.to_parquet(pred_path, index=False)
    times.to_parquet(raw / "part_8000.parquet", index=False)
    def no_remote(*args, **kwargs):
        raise AssertionError("Local temporal evaluation must not initialize S3")
    monkeypatch.setattr(temporal_eval, "make_s3_filesystem", no_remote)
    monkeypatch.setattr(sys, "argv", ["temporal_eval.py", "--pred", str(pred_path),
        "--raw-base", str(raw), "--file-start", "8000", "--file-end", "8000",
        "--id", "id", "--account", "acct", "--target", "target", "--order-col", "timestamp",
        "--out", str(out)])
    if invalid:
        with pytest.raises(ValueError, match="lack timestamps"):
            temporal_eval.main()
        assert not out.exists()
    else:
        temporal_eval.main()
        report = pd.read_csv(out)
        assert report.n.sum() == len(preds)
        assert report.bucket.tolist() == ["2024-01", "2024-02", "2024-03", "2024-04"]
        assert report.loc[1:2, ["pr_auc", "roc_auc"]].isna().all().all()
        output = capsys.readouterr().out
        assert "Descriptive prediction metrics" in output
        assert "slope/calendar-period=-0.16667" in output
        assert "evidence of drift" not in output and "retraining" not in output


def test_single_class_cohort_still_reports_all_counts_without_claiming_drift():
    preds, times = _inputs()
    preds["target"] = 0
    rows = temporal_eval._period_metrics(_prepare(preds, times), "month", "timestamp", "target", "score")
    assert sum(row["n"] for row in rows) == len(preds)
    assert all(row["pr_auc"] is None and row["roc_auc"] is None for row in rows)
    assert temporal_eval._trend(rows, "pr_auc") is None


def test_infinite_raw_identifiers_are_rejected_before_join():
    preds, times = _inputs()
    times["id"] = times.id.astype(float)
    times.loc[0, "id"] = float("inf")
    with pytest.raises(ValueError, match="IDs must be finite"):
        _prepare(preds, times)


def test_unsafe_float_timestamp_ids_cannot_join_distinct_large_integer_predictions():
    base = 2 ** 53
    preds = pd.DataFrame({"id": [base + 1, base + 3], "acct": ["a", "b"], "target": [0, 1],
                          "score": [0.1, 0.9]})
    times = pd.DataFrame({"id": [float(base), float(base + 4)], "acct": ["a", "b"],
                          "timestamp": ["2024-01-01", "2024-02-01"]})
    with pytest.raises(ValueError, match="unsafe floating identifier"):
        _prepare(preds, times)


@pytest.mark.parametrize("matching", [True, False])
def test_temporal_signed_unsigned_integer_join_is_exact(matching):
    base = 2 ** 63
    preds = pd.DataFrame({"id": np.array([base - 3, base - 1], dtype=np.int64), "acct": ["a", "b"],
                          "target": [0, 1], "score": [0.1, 0.9]})
    times = pd.DataFrame({"id": np.array([base - 3, base - 1] if matching else [base - 4, base - 2],
                                          dtype=np.uint64), "acct": ["a", "b"],
                          "timestamp": ["2024-01-01", "2024-02-01"]})
    if matching:
        aligned = _prepare(preds, times)
        assert aligned.id.tolist() == [base - 3, base - 1]
    else:
        with pytest.raises(ValueError, match="lack timestamps"):
            _prepare(preds, times)


# --- V1 reporting: composite identity, pooled overall plus month slices, history slice ---

def test_join_uses_composite_identity_when_transaction_ids_repeat_across_accounts():
    preds = pd.DataFrame({"id": [7, 7, 8], "acct": ["a", "b", "b"], "target": [1, 0, 1],
                          "score": [0.9, 0.2, 0.7]})
    times = pd.DataFrame({"id": [7, 8, 7], "acct": ["b", "b", "a"],
                          "timestamp": ["2025-06-02", "2025-06-03", "2025-05-20"]})
    prepared = _prepare(preds, times)
    assert prepared[["id", "acct"]].values.tolist() == [[7, "a"], [7, "b"], [8, "b"]]
    assert prepared.timestamp.dt.month.tolist() == [5, 6, 6]
    # The same transaction id under another account must not supply the time.
    with pytest.raises(ValueError, match="lack timestamps for 1 prediction IDs"):
        _prepare(preds, times[times.acct == "b"])


def test_duplicate_composite_raw_rows_are_rejected():
    preds, times = _inputs()
    times = pd.concat([times, times.iloc[[2]]], ignore_index=True)
    with pytest.raises(ValueError, match="unique as a composite key"):
        _prepare(preds, times)


def test_id_and_account_must_be_distinct_columns():
    preds, times = _inputs()
    with pytest.raises(ValueError, match="distinct transaction and account"):
        temporal_eval._prepare_predictions(preds, times, "id", "target", "score", "timestamp",
                                           account_col="id")


def test_old_positional_call_without_account_fails_with_missing_keyword():
    # EV-R4: the pre-composite positional form names the missing account keyword.
    preds, times = _inputs()
    with pytest.raises(TypeError, match="account_col"):
        temporal_eval._prepare_predictions(preds, times, "id", "target", "score", "timestamp")


def _may_june():
    rng = np.random.default_rng(5)
    n = 60
    preds = pd.DataFrame({
        "id": np.arange(n), "acct": [f"k{i % 9}" for i in range(n)],
        "target": (np.arange(n) % 5 == 0).astype(int),
        "score": rng.random(n),
    })
    days = np.where(np.arange(n) < 25, "2025-05-", "2025-06-")
    stamps = [f"{d}{(i % 27) + 1:02d} 10:00:{i % 60:02d}" for i, d in enumerate(days)]
    times = preds[["id", "acct"]].assign(timestamp=stamps)
    # Make June targets easier than May ones so pooled AP differs from the month mean.
    preds.loc[(np.arange(n) >= 25) & (preds.target == 1), "score"] += 0.8
    return preds, times


def test_overall_is_pooled_and_month_lines_slice_the_same_predictions():
    from sklearn.metrics import average_precision_score
    preds, times = _may_june()
    df = _prepare(preds, times)
    lines = temporal_eval._slice_summary(df, "timestamp", "target", "score", "acct")
    assert [line["slice"] for line in lines] == ["overall", "month:2025-05", "month:2025-06"]
    overall, may, june = lines
    assert overall["pr_auc"] == pytest.approx(average_precision_score(preds.target, preds.score))
    assert overall["pr_auc"] != pytest.approx(np.mean([may["pr_auc"], june["pr_auc"]]))
    for line, mask in [(may, df.timestamp.dt.month == 5), (june, df.timestamp.dt.month == 6)]:
        part = df[mask]
        assert line["n"] == len(part)
        assert line["positives"] == int(part.target.sum())
        assert line["fraud_rate"] == pytest.approx(part.target.mean())
        assert line["accounts"] == part.acct.nunique()
        assert line["fraud_accounts"] == part.loc[part.target == 1, "acct"].nunique()
        assert line["pr_auc"] == pytest.approx(average_precision_score(part.target, part.score))
    assert may["n"] + june["n"] == overall["n"] == len(preds)
    assert may["positives"] + june["positives"] == overall["positives"]
    assert "min_history" not in overall


def test_history_counts_are_strictly_earlier_same_account_rows():
    raw = pd.DataFrame({
        "id": [1, 2, 3, 4, 5, 6],
        "acct": ["a", "a", "a", "a", "b", "a"],
        "timestamp": ["2025-05-31 23:59:59", "2025-06-01 00:00:05", "2025-06-01 00:00:05",
                      "2025-06-01 00:00:09", "2025-06-01 00:00:05", "2025-05-31 23:59:59"],
    }).sample(frac=1, random_state=4)
    counts = temporal_eval._history_counts(raw, "id", "acct", "timestamp")
    by_id = dict(zip(counts.id, counts[temporal_eval.HISTORY_COL]))
    # Same-second rows (1 and 6; 2 and 3) are not each other's history; a June
    # target counts its May rows; account b sees none of account a.
    assert by_id == {1: 0, 6: 0, 2: 2, 3: 2, 4: 4, 5: 0}


def test_history_counts_order_tz_aware_rows_by_instant_across_dst_fall_back():
    # EV-R1: 05:30Z and 06:10Z on 2025-11-02 are 01:30 EDT then 01:10 EST in
    # New York. The builders order by instant, so id 1 is earlier than id 2
    # even though its local wall-clock time is later.
    instants = pd.to_datetime(["2025-11-02 05:30:00", "2025-11-02 06:10:00"], utc=True)
    local = pd.Series(instants.tz_convert("America/New_York"))
    raw = pd.DataFrame({"id": [1, 2], "acct": ["a", "a"], "timestamp": local})
    counts = temporal_eval._history_counts(raw, "id", "acct", "timestamp")
    assert dict(zip(counts.id, counts[temporal_eval.HISTORY_COL])) == {1: 0, 2: 1}
    # The calendar used for month slicing stays the supplied local one.
    wall = temporal_eval._parse_timestamps(raw["timestamp"], "rows")
    assert wall.dt.strftime("%H:%M").tolist() == ["01:30", "01:10"]


def test_history_counts_require_valid_times_on_every_raw_row():
    raw = pd.DataFrame({"id": [1, 2], "acct": ["a", "a"], "timestamp": ["2025-05-01", "not-a-time"]})
    with pytest.raises(ValueError, match="raw rows used for history counts"):
        temporal_eval._history_counts(raw, "id", "acct", "timestamp")


def test_full_history_slice_reads_only_targets_with_h_earlier_rows():
    from sklearn.metrics import average_precision_score
    preds, times = _may_june()
    counts = temporal_eval._history_counts(times, "id", "acct", "timestamp")
    df = _prepare(preds, counts, extra_cols=[temporal_eval.HISTORY_COL])
    lines = temporal_eval._slice_summary(df, "timestamp", "target", "score", "acct", min_history=3)
    assert [line["slice"] for line in lines][-1] == "history>=3"
    full = df[df[temporal_eval.HISTORY_COL] >= 3]
    assert 0 < len(full) < len(df)
    last = lines[-1]
    assert last["n"] == len(full) and last["positives"] == int(full.target.sum())
    assert last["pr_auc"] == pytest.approx(average_precision_score(full.target, full.score))
    for line in lines[:3]:
        assert line["min_history"] == 3
        assert line["full_history_share"] == pytest.approx(line["full_history_rows"] / line["n"])
    assert lines[1]["full_history_rows"] + lines[2]["full_history_rows"] == len(full)


def test_cli_prints_overall_month_and_history_lines_with_default_account(tmp_path, monkeypatch, capsys):
    preds, times = _may_june()
    preds = preds.rename(columns={"acct": "Nmap_account_reference_xid"})
    times = times.rename(columns={"acct": "Nmap_account_reference_xid"})
    raw = tmp_path / "raw"
    raw.mkdir()
    # Two files: history counts restart at each file, as in the sequence builders.
    times.iloc[:30].to_parquet(raw / "part_8000.parquet", index=False)
    times.iloc[30:].to_parquet(raw / "part_8001.parquet", index=False)
    pred_path, out, summary = tmp_path / "p.parquet", tmp_path / "m.csv", tmp_path / "s.csv"
    preds.to_parquet(pred_path, index=False)
    monkeypatch.setattr(temporal_eval, "make_s3_filesystem", lambda *_: (_ for _ in ()).throw(AssertionError))
    monkeypatch.setattr(sys, "argv", ["temporal_eval.py", "--pred", str(pred_path), "--raw-base", str(raw),
        "--file-start", "8000", "--file-end", "8001", "--id", "id", "--target", "target",
        "--order-col", "timestamp", "--out", str(out), "--min-history", "2", "--summary-out", str(summary)])
    temporal_eval.main()
    text = capsys.readouterr().out
    for label in ["overall", "month:2025-05", "month:2025-06", "history>=2"]:
        assert label in text
    assert "not an average of the month lines" in text
    assert ("all-position B sees only its chunk (0 to 5 strictly earlier rows), "
            "so this line is not its available context") in text
    report = pd.read_csv(out)
    assert list(report.columns) == ["bucket", "n", "positives", "fraud_rate", "pr_auc", "roc_auc", "status"]
    assert report.n.sum() == len(preds)
    lines = pd.read_csv(summary)
    assert lines.slice.tolist() == ["overall", "month:2025-05", "month:2025-06", "history>=2"]
    expected = sum(
        int((temporal_eval._history_counts(part, "id", "Nmap_account_reference_xid", "timestamp")
             [temporal_eval.HISTORY_COL] >= 2).sum())
        for part in (times.iloc[:30], times.iloc[30:]))
    assert lines.loc[3, "n"] == lines.loc[0, "full_history_rows"] == expected
    whole = temporal_eval._history_counts(times, "id", "Nmap_account_reference_xid", "timestamp")
    assert expected < int((whole[temporal_eval.HISTORY_COL] >= 2).sum())


def test_cli_names_missing_account_column_in_predictions(tmp_path, monkeypatch):
    # EV-R2: predictions without the account column (for example an ensemble of
    # models that lacked it) fail with a clear message, not a raw KeyError.
    preds, times = _inputs()
    raw = tmp_path / "raw"
    raw.mkdir()
    pred_path = tmp_path / "preds.parquet"
    preds.drop(columns="acct").to_parquet(pred_path, index=False)
    times.to_parquet(raw / "part_8000.parquet", index=False)
    monkeypatch.setattr(temporal_eval, "make_s3_filesystem", lambda *_: (_ for _ in ()).throw(AssertionError))
    monkeypatch.setattr(sys, "argv", ["temporal_eval.py", "--pred", str(pred_path),
        "--raw-base", str(raw), "--file-start", "8000", "--file-end", "8000",
        "--id", "id", "--account", "acct", "--target", "target", "--order-col", "timestamp",
        "--out", str(tmp_path / "m.csv")])
    with pytest.raises(ValueError, match=r"predictions: missing columns \['acct'\]; the composite join needs id and acct"):
        temporal_eval.main()


@pytest.mark.parametrize("extra", [["--account", "id"], ["--min-history", "-1"]])
def test_cli_rejects_single_key_join_and_negative_history(tmp_path, monkeypatch, extra):
    monkeypatch.setattr(sys, "argv", ["temporal_eval.py", "--pred", str(tmp_path), "--raw-base", str(tmp_path),
        "--file-start", "8000", "--file-end", "8000", "--id", "id", *extra])
    with pytest.raises(SystemExit) as exc:
        temporal_eval.main()
    assert exc.value.code == 2
