"""Calibration CLI checks using real local Parquet files and fitted estimators."""

import itertools
import re
import sys

import joblib
import numpy as np
import pandas as pd
import pyarrow.parquet as pq
import pytest
from fsspec.implementations.memory import MemoryFileSystem
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression

from YOUR_PACKAGE.scoring import calibrate_and_report as report


def _frames():
    val = pd.DataFrame({
        "fi_transaction_id": ["v0", "v1", "v2", "v3"],
        "Nmap_account_reference_xid": [1, 1, 2, 2],
        "frd_tag": [0, 1, 0, 1],
        "score": [0.1, 0.2, 0.8, 0.9],
    })
    # All test scores land in isotonic's learned plateau. Raw order is perfect,
    # while calibrated order ties; its first input row is deliberately non-fraud.
    test = pd.DataFrame({
        "fi_transaction_id": ["t0", "t1", "t2", "t3"],
        "Nmap_account_reference_xid": [3, 3, 4, 4],
        "frd_tag": [0, 1, 0, 1],
        "score": [0.2, 0.8, 0.3, 0.7],
    })
    return val, test


def _run(tmp_path, monkeypatch, val, test, *args):
    val_path, test_path = tmp_path / "val.parquet", tmp_path / "test.parquet"
    val.to_parquet(val_path, index=False)
    test.to_parquet(test_path, index=False)
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(sys, "argv", ["calibrate_and_report", "--val", str(val_path),
                                     "--test", str(test_path), *map(str, args)])

    def no_remote(*a, **k):
        raise AssertionError("local calibration must not initialize S3 or load credentials")

    monkeypatch.setattr(report, "make_s3_filesystem", no_remote)
    report.main()


def test_isotonic_ties_change_reported_ranking_but_budgets_use_raw_scores(tmp_path, monkeypatch, capsys):
    val, test = _frames()
    out = tmp_path / "outputs"
    _run(tmp_path, monkeypatch, val, test, "--pred-out", out, "--budgets", "0.25")
    text = capsys.readouterr().out
    assert re.search(r"raw\s+AP=1\.000000 ROC-AUC=1\.000000", text)
    assert re.search(r"isotonic\s+AP=0\.500000 ROC-AUC=0\.500000", text)
    assert "raw-score ranking" in text
    assert re.search(r"25\.000%\s+1\s+1\.0000\s+0\.5000", text)
    result = pd.read_parquet(out / "calibrated_preds.parquet")
    # The persisted binary estimator must not break the existing directory-read contract.
    assert len(list((out / "_calibrators").glob("calibrator_*.joblib"))) == 1
    pd.testing.assert_frame_equal(report._read(str(out), None), result)
    assert result["score_calibrated"].nunique() == 1
    assert np.allclose(result["score_calibrated"], 0.5)
    assert result["score"].tolist() == test["score"].tolist()
    for column in ("fi_transaction_id", "Nmap_account_reference_xid", "frd_tag"):
        assert result[column].tolist() == test[column].tolist()


@pytest.mark.parametrize("method,estimator_type", [
    ("isotonic", IsotonicRegression), ("sigmoid", LogisticRegression),
])
def test_persisted_estimator_round_trip_preserves_custom_columns_and_predictions(
    tmp_path, monkeypatch, capsys, method, estimator_type,
):
    val, test = _frames()
    columns = {"fi_transaction_id": "txn_key", "frd_tag": "label", "score": "probability"}
    val, test = val.rename(columns=columns), test.rename(columns=columns)
    artifact_path = tmp_path / "models" / "calibration.joblib"
    out = tmp_path / "predictions"
    _run(tmp_path, monkeypatch, val, test, "--method", method, "--target", "label",
         "--score-col", "probability", "--id-col", "txn_key", "--pred-out", out,
         "--calibrator-out", artifact_path)
    # This test loads only the artifact it just generated from its own synthetic data.
    artifact = joblib.load(artifact_path)
    assert isinstance(artifact["estimator"], estimator_type)
    assert artifact["method"] == method
    assert (artifact["score_col"], artifact["target_col"], artifact["id_col"]) == (
        "probability", "label", "txn_key",
    )
    assert artifact["format_version"] == 1
    assert artifact["predictions_path"] == str(out / "calibrated_preds.parquet")
    assert artifact["fit_rows"] == 4 and artifact["fit_positives"] == 2
    assert artifact["sklearn_version"]
    result = pd.read_parquet(out / "calibrated_preds.parquet")
    scores = test["probability"].to_numpy()
    if method == "isotonic":
        restored = artifact["estimator"].transform(scores)
    else:
        restored = artifact["estimator"].predict_proba(scores.reshape(-1, 1))[:, 1]
        expected = LogisticRegression(max_iter=1000).fit(
            val["probability"].to_numpy().reshape(-1, 1), val["label"].to_numpy(),
        )
        assert np.array_equal(artifact["estimator"].coef_, expected.coef_)
        assert np.array_equal(artifact["estimator"].intercept_, expected.intercept_)
    assert np.array_equal(restored, result["score_calibrated"].to_numpy())
    assert result["txn_key"].tolist() == test["txn_key"].tolist()
    assert result["Nmap_account_reference_xid"].tolist() == test["Nmap_account_reference_xid"].tolist()
    assert result["score"].tolist() == scores.tolist()
    assert str(artifact_path) in capsys.readouterr().out


def test_repeated_default_invocations_keep_distinct_estimators_and_refuse_explicit_overwrite(
    tmp_path, monkeypatch, capsys,
):
    val, test = _frames()
    _run(tmp_path, monkeypatch, val, test)
    first = list(tmp_path.glob("calibrator_*.joblib"))
    assert len(first) == 1
    original_bytes = first[0].read_bytes()
    _run(tmp_path, monkeypatch, val, test)
    assert len(list(tmp_path.glob("calibrator_*.joblib"))) == 2
    assert first[0].read_bytes() == original_bytes
    with pytest.raises(SystemExit) as exc:
        _run(tmp_path, monkeypatch, val, test, "--calibrator-out", first[0])
    assert exc.value.code == 2
    assert "artifact already exists" in capsys.readouterr().err
    assert first[0].read_bytes() == original_bytes


def test_reused_prediction_directory_preserves_existing_model_and_predictions(tmp_path, monkeypatch, capsys):
    val, test = _frames()
    out = tmp_path / "predictions"
    _run(tmp_path, monkeypatch, val, test, "--pred-out", out)
    pred_bytes = (out / "calibrated_preds.parquet").read_bytes()
    models = list((out / "_calibrators").glob("*.joblib"))
    assert len(models) == 1
    model_bytes = models[0].read_bytes()
    with pytest.raises(SystemExit) as exc:
        _run(tmp_path, monkeypatch, val, test, "--pred-out", out, "--method", "sigmoid")
    assert exc.value.code == 2
    assert "calibrated predictions already exist" in capsys.readouterr().err
    assert (out / "calibrated_preds.parquet").read_bytes() == pred_bytes
    assert models[0].read_bytes() == model_bytes
    assert list((out / "_calibrators").glob("*.joblib")) == models


@pytest.mark.parametrize("budget", ["0", "-0.1", "1.1", "nan", "inf"])
def test_invalid_alert_budgets_fail_before_outputs(tmp_path, monkeypatch, capsys, budget):
    with pytest.raises(SystemExit) as exc:
        _run(tmp_path, monkeypatch, *_frames(), "--budgets", budget)
    assert exc.value.code == 2
    assert "budget must be finite and in (0, 1]" in capsys.readouterr().err
    assert not list(tmp_path.glob("*.joblib"))


@pytest.mark.parametrize("case,split,message", [
    ("overlap", "test", "transaction IDs overlap"),
    ("duplicate_id", "validation", "non-null, unique transaction IDs"),
    ("duplicate_id", "test", "non-null, unique transaction IDs"),
    ("null_id", "test", "non-null, unique transaction IDs"),
    ("infinite_id", "validation", "must be finite"),
    ("missing_id", "test", "missing required columns"),
    ("missing_score", "validation", "missing required columns"),
    ("fractional_label", "validation", "binary labels"),
    ("null_label", "test", "binary labels"),
    ("one_class", "validation", "both label classes"),
    ("one_class", "test", "both label classes"),
    ("nan_score", "validation", "finite probabilities"),
    ("infinite_score", "test", "finite probabilities"),
    ("high_score", "validation", "finite probabilities"),
    ("negative_score", "test", "finite probabilities"),
    ("id_type_mismatch", "validation", "compatible identifier types"),
    ("empty", "validation", "must not be empty"),
    ("empty", "test", "must not be empty"),
])
def test_invalid_prediction_data_fails_before_outputs(tmp_path, monkeypatch, capsys, case, split, message):
    val, test = _frames()
    df = val if split == "validation" else test
    if case == "overlap":
        df.loc[0, "fi_transaction_id"] = val.loc[0, "fi_transaction_id"]
    elif case == "duplicate_id":
        df.loc[0, "fi_transaction_id"] = df.loc[1, "fi_transaction_id"]
    elif case == "null_id":
        df.loc[0, "fi_transaction_id"] = None
    elif case == "infinite_id":
        df["fi_transaction_id"] = [1.0, 2.0, np.inf, 4.0]
    elif case == "missing_id":
        df.drop(columns="fi_transaction_id", inplace=True)
    elif case == "missing_score":
        df.drop(columns="score", inplace=True)
    elif case == "fractional_label":
        df["frd_tag"] = [0.0, 0.5, 0.0, 1.0]
    elif case == "null_label":
        df["frd_tag"] = pd.Series([0, 1, pd.NA, 1], dtype="Int64")
    elif case == "one_class":
        df["frd_tag"] = 0
    elif case in ("nan_score", "infinite_score", "high_score", "negative_score"):
        df.loc[0, "score"] = {"nan_score": np.nan, "infinite_score": np.inf,
                              "high_score": 1.1, "negative_score": -0.1}[case]
    elif case == "empty":
        df.drop(index=df.index, inplace=True)
    elif case == "id_type_mismatch":
        val["fi_transaction_id"] = [1, 2, 3, 4]
        test["fi_transaction_id"] = ["1", "2", "3", "4"]
    with pytest.raises(SystemExit) as exc:
        _run(tmp_path, monkeypatch, val, test, "--pred-out", tmp_path / "out")
    assert exc.value.code == 2
    assert message in capsys.readouterr().err
    assert not (tmp_path / "out").exists()


def test_zero_or_full_probability_and_full_alert_budget_are_valid(tmp_path, monkeypatch, capsys):
    val, test = _frames()
    val["score"] = [0.0, 0.2, 0.8, 1.0]
    test["score"] = [0.0, 1.0, 0.3, 0.7]
    _run(tmp_path, monkeypatch, val, test, "--budgets", "1")
    assert re.search(r"100\.000%\s+4\s+0\.5000\s+1\.0000", capsys.readouterr().out)


def test_legacy_bare_s3_and_s3a_paths_work_through_main_without_network(tmp_path, monkeypatch):
    # Exercise the actual Arrow/filesystem I/O with an in-memory remote substitute.
    fs = MemoryFileSystem()
    bucket = f"calibration-{tmp_path.name}"
    val, test = _frames()
    for name, df in (("val", val), ("test", test)):
        with fs.open(f"{bucket}/{name}.parquet", "wb") as stream:
            df.to_parquet(stream, index=False)
    calls = []
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(report, "make_s3_filesystem", lambda cred: calls.append(cred) or fs)
    monkeypatch.setattr(sys, "argv", ["calibrate_and_report", "--val", f"{bucket}/val.parquet",
                                     "--test", f"s3a://{bucket}/test.parquet",
                                     "--pred-out", f"{bucket}/predictions", "--cred", "test-only",
                                     "--legacy-s3-paths"])
    report.main()
    assert calls == ["test-only"]
    result = pq.ParquetDataset(f"/{bucket}/predictions", filesystem=fs).read().to_pandas()
    assert result["fi_transaction_id"].tolist() == test["fi_transaction_id"].tolist()
    artifacts = fs.glob(f"{bucket}/predictions/_calibrators/calibrator_*.joblib")
    assert len(artifacts) == 1
    with fs.open(artifacts[0], "rb") as stream:
        artifact = joblib.load(stream)  # This test's own immediately generated artifact.
    assert isinstance(artifact["estimator"], IsotonicRegression)
    assert not (tmp_path / bucket).exists()


def test_new_relative_local_output_is_explicit(tmp_path, monkeypatch):
    val, test = _frames()
    _run(tmp_path, monkeypatch, val, test, "--pred-out", "./local-predictions")
    assert (tmp_path / "local-predictions/calibrated_preds.parquet").exists()


@pytest.mark.parametrize("relative", ["results", "results/", "nested/results"])
def test_new_relative_outputs_are_always_local_without_loading_credentials(tmp_path, monkeypatch, relative):
    _run(tmp_path, monkeypatch, *_frames(), "--pred-out", relative)
    assert (tmp_path / relative / "calibrated_preds.parquet").exists()
    # Creating the directory must never change subsequent path interpretation.
    assert report._prediction_path(relative) == str((tmp_path / relative).resolve())


def test_alert_budget_ties_match_exact_expected_metric_under_all_permutations():
    y, s = np.array([0, 1, 1, 0]), np.array([0.9, 0.9, 0.9, 0.1])
    for permutation in itertools.permutations(range(4)):
        idx = np.array(permutation)
        n, precision, recall = report._at_budget(y[idx], s[idx], 0.25)
        assert n == 1
        assert precision == pytest.approx(2 / 3)
        assert recall == pytest.approx(1 / 3)
    # A full-score tier above the cutoff is always selected; only its tied
    # boundary shares the remaining slots.
    y, s = np.array([1, 0, 1, 0, 0]), np.array([1, 0.8, 0.8, 0.8, 0.1])
    assert report._at_budget(y, s, 0.4) == pytest.approx((2, 2 / 3, 2 / 3))


def test_constant_score_expected_precision_is_prevalence_not_file_order():
    for y in (np.array([0, 0, 1, 1]), np.array([1, 1, 0, 0])):
        assert report._at_budget(y, np.ones(4), 0.25) == (1, 0.5, 0.25)


@pytest.mark.parametrize("scores,labels", [([], []), ([0.1], [0, 1]), ([np.nan], [1]), ([0.1], [0.3])])
def test_budget_helper_rejects_invalid_vectors(scores, labels):
    with pytest.raises(ValueError):
        report._at_budget(np.array(labels), np.array(scores), 0.5)


@pytest.mark.parametrize("path", ["https://example.test/result", "gs://bucket/result", "s3://", ""])
def test_path_helper_rejects_unsupported_or_empty_locations(path):
    with pytest.raises(ValueError):
        report._prediction_path(path)


def test_local_reads_ignore_remote_filesystem_when_other_inputs_are_remote(tmp_path):
    val, _ = _frames()
    path = tmp_path / "local.parquet"
    val.to_parquet(path, index=False)
    pd.testing.assert_frame_equal(report._read(str(path), MemoryFileSystem()), val)


def test_calibration_rejects_unsafe_floating_ids_before_artifacts(tmp_path, monkeypatch, capsys):
    val, test = _frames()
    val["fi_transaction_id"] = [float(2 ** 53 + n) for n in (0, 2, 4, 6)]
    with pytest.raises(SystemExit):
        _run(tmp_path, monkeypatch, val, test)
    assert "unsafe floating identifier" in capsys.readouterr().err
    assert not list(tmp_path.glob("*.joblib"))


def test_boolean_binary_labels_remain_valid_for_calibration(tmp_path, monkeypatch):
    val, test = _frames()
    val["frd_tag"], test["frd_tag"] = val.frd_tag.astype(bool), test.frd_tag.astype(bool)
    _run(tmp_path, monkeypatch, val, test)
    assert len(list(tmp_path.glob("*.joblib"))) == 1
