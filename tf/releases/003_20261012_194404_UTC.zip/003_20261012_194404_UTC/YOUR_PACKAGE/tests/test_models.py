"""Offline forward/backward tests for all models (synthetic, no S3/GPU).

Validates shapes, the periodic numerical embedding, both attention masks, the
hierarchical model, the SSL autoencoder + fine-tune classifier, TabM's member
averaging, the optimizer factory, and the EMA callback logic — all on tiny random
tensors so a regression is caught without a pod run.

Run: python -m pytest tests/test_models.py -q
"""

import os
import sys

import pytest
import torch
import torch.nn as nn

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from YOUR_PACKAGE.phase4a.callbacks import EMACallback
from YOUR_PACKAGE.future_experiments.pretrain.encoder import TabularEncoder
from YOUR_PACKAGE.phase4a.optim import build_optimizer
from YOUR_PACKAGE.phase4b.sequential_hier import FTTransformerHierModel
from YOUR_PACKAGE.phase4a.sequential import FTTransformerSeqModel
from YOUR_PACKAGE.future_experiments.pretrain.ssl_finetune import SSLFinetuneClassifier
from YOUR_PACKAGE.future_experiments.pretrain.ssl_pretrain import MaskedTabularAutoencoder

B, C, HIST = 6, 3, 2
CARDS = [5, 5, 2, 2]
K = len(CARDS)
EMBED, HEADS = 16, 4


def _seq_batch():
    T = HIST + 1
    return {
        "continuous": torch.randn(B, T, C),
        "categorical": torch.stack(
            [torch.randint(0, c, (B, T)) for c in CARDS], dim=-1
        ),
        "mask": torch.ones(B, T, dtype=torch.bool),
        "target": torch.randint(0, 2, (B, 1)),
    }


def _flat_batch():
    return {
        "continuous": torch.randn(B, C),
        "categorical": torch.stack([torch.randint(0, c, (B,)) for c in CARDS], dim=-1),
        "target": torch.randint(0, 2, (B, 1)),
    }


def _seq_model(continuous_embedding="linear", attention_mask="bidirectional"):
    return FTTransformerSeqModel(
        continuous_dim=C, categorical_cardinality=CARDS, history_len=HIST,
        embed_dim=EMBED, num_heads=HEADS, num_attn_blocks=1,
        attention_mask=attention_mask, continuous_embedding=continuous_embedding,
    )


def test_sequential_forward_backward_linear():
    model = _seq_model()
    batch = _seq_batch()
    logits = model(batch)
    assert logits.shape == (B, 2)
    loss = model.loss_fn(logits, batch["target"].reshape(-1))
    loss.backward()  # gradients flow


def test_sequential_periodic_embedding():
    logits = _seq_model(continuous_embedding="periodic")(_seq_batch())
    assert logits.shape == (B, 2)


def test_sequential_causal_mask():
    logits = _seq_model(attention_mask="causal")(_seq_batch())
    assert logits.shape == (B, 2)


def _padded_seq_batch():
    """A batch with heavily left-padded (short-history) accounts -- the exact
    scenario that can give a causal query row zero valid keys (fix: see
    sequential.py / sequential_hier.py `_build_causal_mask`)."""
    batch = _seq_batch()
    pad_mask = torch.zeros(B, HIST + 1, dtype=torch.bool)
    pad_mask[:, -1] = True  # only the target slot is real; all history is padding
    batch["mask"] = pad_mask
    return batch


def test_sequential_causal_mask_no_nan_with_padding():
    # Regression test (found via external audit review): causal mask + fully
    # padded history rows must not produce NaN logits/gradients.
    model = _seq_model(attention_mask="causal")
    batch = _padded_seq_batch()
    logits = model(batch)
    assert torch.isfinite(logits).all()
    loss = model.loss_fn(logits, batch["target"].reshape(-1))
    loss.backward()
    for p in model.parameters():
        if p.grad is not None:
            assert torch.isfinite(p.grad).all()


def test_hierarchical_causal_mask_no_nan_with_padding():
    model = FTTransformerHierModel(
        continuous_dim=C, categorical_cardinality=CARDS, history_len=HIST,
        embed_dim=EMBED, num_heads=HEADS, num_txn_blocks=1, num_seq_blocks=1,
        attention_mask="causal",
    )
    batch = _padded_seq_batch()
    logits = model(batch)
    assert torch.isfinite(logits).all()
    loss = model.loss_fn(logits, batch["target"].reshape(-1))
    loss.backward()
    for p in model.parameters():
        if p.grad is not None:
            assert torch.isfinite(p.grad).all()


def test_sequential_embed_shape():
    emb = _seq_model().embed(_seq_batch())
    assert emb.shape == (B, EMBED)


def test_hierarchical_forward():
    model = FTTransformerHierModel(
        continuous_dim=C, categorical_cardinality=CARDS, history_len=HIST,
        embed_dim=EMBED, num_heads=HEADS, num_txn_blocks=1, num_seq_blocks=1,
    )
    batch = _seq_batch()
    logits = model(batch)
    assert logits.shape == (B, 2)
    assert model.embed(batch).shape == (B, EMBED)


def test_hierarchical_predict_every_transaction_requires_causal():
    with pytest.raises(ValueError):
        FTTransformerHierModel(
            continuous_dim=C, categorical_cardinality=CARDS, history_len=HIST,
            embed_dim=EMBED, num_heads=HEADS, num_txn_blocks=1, num_seq_blocks=1,
            attention_mask="bidirectional", predict_every_transaction=True,
        )


def test_hierarchical_predict_every_transaction_forward_and_loss():
    T = HIST + 1
    model = FTTransformerHierModel(
        continuous_dim=C, categorical_cardinality=CARDS, history_len=HIST,
        embed_dim=EMBED, num_heads=HEADS, num_txn_blocks=1, num_seq_blocks=1,
        attention_mask="causal", predict_every_transaction=True,
        # Explicit leak-free contract, required since the all-position repair (YOUR_PACKAGE/phase4b/ALL_POSITION_CONTRACT.md):
        # disjoint chunks, and time gaps measured to the previous transaction instead of the final target.
        all_position_layout="nonoverlapping_chunks", time_delta_reference="previous_transaction",
        # B9: the equal-time rule is explicit; strict reads per-position timestamps (time_seq).
        history_time_order="strict",
    )
    batch = _seq_batch()
    batch["time_seq"] = torch.arange(T).repeat(B, 1) * 60
    logits = model(batch)
    assert logits.shape == (B, T, 2)  # one prediction per transaction, not just CLS

    # Per-position labels: real frd_tag per slot, -100 (ignore) for padded slots.
    batch["target_seq"] = torch.randint(0, 2, (B, T))
    # Simulate one padded slot per row. The chunk contract pads on the right and requires the padding mask and the
    # -100 labels to agree (YOUR_PACKAGE/phase4b/ALL_POSITION_CONTRACT.md).
    batch["target_seq"][:, -1] = -100
    batch["mask"][:, -1] = False
    logits_flat, y_flat, _ = model._step(batch, "train")
    assert logits_flat.shape[0] == y_flat.shape[0] == B * (T - 1)  # padded rows dropped
    assert torch.isfinite(logits_flat).all()
    loss = model.loss_fn(logits_flat, y_flat)
    loss.backward()
    for p in model.parameters():
        if p.grad is not None:
            assert torch.isfinite(p.grad).all()


def test_tabular_encoder_encode():
    enc = TabularEncoder(C, CARDS, embed_dim=EMBED, num_heads=HEADS, num_blocks=1)
    b = _flat_batch()
    assert enc.encode(b["continuous"], b["categorical"]).shape == (B, EMBED)


def test_ssl_autoencoder_reconstruct():
    ae = MaskedTabularAutoencoder(C, CARDS, embed_dim=EMBED, num_heads=HEADS, num_blocks=1)
    loss = ae._reconstruct(_flat_batch())
    assert loss.ndim == 0
    loss.backward()


def test_ssl_finetune_and_pretrained_load():
    ae = MaskedTabularAutoencoder(C, CARDS, embed_dim=EMBED, num_heads=HEADS, num_blocks=1)
    clf = SSLFinetuneClassifier(C, CARDS, embed_dim=EMBED, num_heads=HEADS, num_blocks=1)
    clf.load_pretrained(ae.state_dict())  # encoder.* keys load without error
    assert clf(_flat_batch()).shape == (B, 2)


def test_build_optimizer_torch_backends():
    model = _seq_model()
    for name in ["adamw", "adam", "sgd", "nadam", "radam", "rmsprop"]:
        opt = build_optimizer(name, model.parameters(), lr=1e-3, weight_decay=1e-5)
        assert len(opt.param_groups) >= 1


def test_ema_callback_updates_and_restores():
    m = nn.Linear(2, 1)
    cb = EMACallback(decay=0.5)
    cb.on_fit_start(None, m)
    before = {n: p.detach().clone() for n, p in m.named_parameters()}
    with torch.no_grad():
        for p in m.parameters():
            p.add_(1.0)
    cb.on_train_batch_end(None, m, None, None, 0)
    cb.on_validation_start(None, m)
    for n, p in m.named_parameters():
        assert torch.allclose(p, before[n] + 0.5)
    cb.on_validation_end(None, m)
    for n, p in m.named_parameters():
        assert torch.allclose(p, before[n] + 1.0)
    checkpoint = {"state_dict": m.state_dict()}
    cb.on_save_checkpoint(None, m, checkpoint)
    for n in before:
        assert torch.allclose(checkpoint["state_dict"][n], before[n] + 0.5)
        assert torch.allclose(checkpoint["ema_raw_params"][n], before[n] + 1.0)
