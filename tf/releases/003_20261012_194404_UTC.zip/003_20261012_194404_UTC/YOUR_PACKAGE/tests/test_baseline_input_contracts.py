"""Exercise legacy baseline entry points without model training or bank access."""

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from omegaconf import OmegaConf

from YOUR_PACKAGE.base.scripts import score_eval, train_baseline

ROOT = Path(__file__).resolve().parents[2]


class _Model:
    def __init__(self, records):
        self.records = records

    def fit(self, train, validation, callbacks):
        self.records['train'] = train.copy()
        self.records['validation'] = validation.copy()

    def predict(self, df, device=None):
        self.records.setdefault('predictions', []).append(df.copy())
        return pd.DataFrame({
            'frd_tag_fraud_probability': np.where(df.frd_tag.eq('fraud'), 0.8, 0.2),
            'frd_tag_prediction': df.frd_tag.to_numpy(),
        }, index=df.index)

    def save_model(self, path):
        Path(path).mkdir(parents=True, exist_ok=True)


def _setup(tmp_path, monkeypatch, derived=False):
    predictor_path = tmp_path / 'predictors.csv'
    predictor_path.write_text('feature,type,source,version\n'
                              'amount,continuous,raw,1\n'
                              'category,categorical,raw,1\n' + (
                                  'hour,categorical,derived:transaction_dttm,1\n' if derived else ''))
    frame = pd.DataFrame({'id': ['a', 'b', 'c'], 'amount': [1., np.nan, 3.],
                          'category': ['shop', None, 'shop'],
                          'frd_tag': ['legitimate', 'fraud', 'legitimate']})
    if derived:
        frame['transaction_dttm'] = pd.date_range('2024-01-01', periods=3, freq='h')
    train_cfg = OmegaConf.load(ROOT / 'fraud/configs/smoke_test.yaml')
    train_cfg.predictors.csv_path = str(predictor_path)
    train_cfg.data.positive_label = 'fraud'
    train_cfg.datetime.fields = ['hour']
    train_cfg.output.checkpoint_dir = str(tmp_path / 'model')
    train_cfg.training.accelerator = 'cpu'
    for split in ['train', 'val', 'test']:
        directory = tmp_path / split
        directory.mkdir()
        frame.to_parquet(directory / 'part_1.parquet', index=False)
        train_cfg.data[f'{split}_base'] = str(directory)
        train_cfg.data[f'{split}_start'] = 1
        train_cfg.data[f'{split}_end'] = 1
    train_path = tmp_path / 'train.yaml'
    OmegaConf.save(train_cfg, train_path)
    output = tmp_path / 'predictions'
    output.mkdir()
    score_cfg = OmegaConf.load(ROOT / 'fraud/configs/eval.yaml')
    score_cfg.predictors.csv_path = str(predictor_path)
    score_cfg.data.base = str(tmp_path / 'test')
    score_cfg.data.file_start = score_cfg.data.file_end = 1
    score_cfg.data.positive_label = 'fraud'
    score_cfg.data.id_cols = ['id']
    score_cfg.data.amount_col = 'amount'
    score_cfg.datetime.fields = ['hour']
    score_cfg.model.dir = str(tmp_path / 'model')
    score_cfg.preprocess.imputer_path = str(tmp_path / 'model/continuous_imputer.joblib')
    score_cfg.output.base = str(output)
    score_cfg.output.compute_metrics = False
    score_path = tmp_path / 'score.yaml'
    OmegaConf.save(score_cfg, score_path)
    records = {}
    model = _Model(records)
    monkeypatch.setattr(train_baseline, 'TabularModel', lambda **kwargs: model)
    monkeypatch.setattr(score_eval, 'TabularModel', type('SavedModel', (), {'load_model': staticmethod(lambda path: model)}))
    for module in [train_baseline, score_eval]:
        monkeypatch.setattr(module, 'make_s3_filesystem', lambda _: None)
        monkeypatch.setattr(module.torch.cuda, 'is_available', lambda: False)
    return train_path, score_path, frame, records


def _run(module, path, monkeypatch):
    monkeypatch.setattr(sys, 'argv', [module.__name__, '--config', str(path)])
    module.main()


@pytest.mark.parametrize('derived', [False, True])
def test_legacy_baseline_training_and_scoring_preserve_labels_and_feature_contract(
    tmp_path, monkeypatch, derived,
):
    train_path, score_path, frame, records = _setup(tmp_path, monkeypatch, derived)
    _run(train_baseline, train_path, monkeypatch)
    _run(score_eval, score_path, monkeypatch)
    assert records['train'].frd_tag.tolist() == frame.frd_tag.tolist()
    assert records['validation'].frd_tag.tolist() == frame.frd_tag.tolist()
    assert np.isfinite(records['train'].amount).all()
    assert ('hour' in records['train']) == derived
    pred = pd.read_parquet(tmp_path / 'predictions/part_1.parquet')
    assert pred.frd_tag.tolist() == [0, 1, 0]
    assert pred.id.tolist() == frame.id.tolist()
    assert np.isnan(pred.amount.iloc[1])  # Metadata retains raw amount, not imputed value.


@pytest.mark.parametrize('split', ['train', 'val', 'test'])
@pytest.mark.parametrize('case', ['missing_label', 'missing_time', 'bad_time'])
def test_training_rejects_bad_required_values_in_every_split_before_fit(
    tmp_path, monkeypatch, split, case,
):
    train_path, _, frame, records = _setup(tmp_path, monkeypatch, derived=True)
    if case == 'missing_label':
        frame.loc[1, 'frd_tag'] = None
    elif case == 'missing_time':
        frame.loc[1, 'transaction_dttm'] = pd.NaT
    else:
        frame['transaction_dttm'] = ['2024-01-01', 'unparseable', '2024-01-03']
    frame.to_parquet(tmp_path / split / 'part_1.parquet', index=False)
    with pytest.raises(ValueError, match='missing labels|Timestamp column'):
        _run(train_baseline, train_path, monkeypatch)
    assert 'train' not in records and 'predictions' not in records
    assert not (tmp_path / 'model').exists()


@pytest.mark.parametrize('case', ['missing_label', 'missing_time', 'bad_time', 'single_class'])
def test_standalone_scoring_guards_before_predict_but_accepts_single_class_files(
    tmp_path, monkeypatch, case,
):
    train_path, score_path, frame, records = _setup(tmp_path, monkeypatch, derived=True)
    _run(train_baseline, train_path, monkeypatch)
    records['predictions'] = []
    if case == 'missing_label':
        frame.loc[1, 'frd_tag'] = None
    elif case == 'missing_time':
        frame.loc[1, 'transaction_dttm'] = pd.NaT
    elif case == 'bad_time':
        frame['transaction_dttm'] = ['2024-01-01', 'unparseable', '2024-01-03']
    else:
        frame['frd_tag'] = 'legitimate'
    frame.to_parquet(tmp_path / 'test/part_1.parquet', index=False)
    if case == 'single_class':
        _run(score_eval, score_path, monkeypatch)
        assert pd.read_parquet(tmp_path / 'predictions/part_1.parquet').frd_tag.tolist() == [0, 0, 0]
    else:
        with pytest.raises(ValueError, match='missing labels|Timestamp column'):
            _run(score_eval, score_path, monkeypatch)
        assert not records['predictions']
        assert not list((tmp_path / 'predictions').iterdir())


def test_evaluate_split_checks_missing_targets_before_model_predict():
    records = {}
    frame = pd.DataFrame({'frd_tag': ['legitimate', None, 'fraud']})
    with pytest.raises(ValueError, match='missing labels'):
        train_baseline.evaluate_split(_Model(records), frame, 'frd_tag', 'fraud', 'validation')
    assert not records
    frame.loc[1, 'frd_tag'] = 'different-negative-code'
    assert train_baseline.evaluate_split(_Model(records), frame, 'frd_tag', 'fraud', 'validation') == {
        'average_precision': 1.0, 'auroc': 1.0,
    }
