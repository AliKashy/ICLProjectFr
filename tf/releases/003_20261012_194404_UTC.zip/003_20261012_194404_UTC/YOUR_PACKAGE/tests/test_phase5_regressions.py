"""Phase 5 semantic checks, using synthetic local data only."""

import pytest
import torch
import torch.nn.functional as F

from YOUR_PACKAGE.future_experiments.pretrain.ssl_finetune import SSLFinetuneClassifier
from YOUR_PACKAGE.future_experiments.pretrain.ssl_pretrain import MaskedTabularAutoencoder
from YOUR_PACKAGE.future_experiments.pretrain.supcon import SupConLoss, SupConPretrainer


KWARGS = dict(continuous_dim=2, categorical_cardinality=[3], embed_dim=8,
              num_heads=2, num_blocks=1, attn_dropout=0.0, ff_dropout=0.0)


def batch():
    return {"continuous": torch.tensor([[2.0, -2.0], [1.0, -1.0], [0.5, -0.5]]),
            "categorical": torch.tensor([[0], [1], [2]]), "target": torch.tensor([[0], [1], [0]])}


def reference_supcon(features, labels, temperature):
    # Independent explicit anchor/candidate enumeration; no replicated mask.
    vectors = F.normalize(features, dim=-1)
    losses = []
    for sample in range(len(labels)):
        for view in range(features.shape[1]):
            scores, positives = [], []
            for other in range(len(labels)):
                for other_view in range(features.shape[1]):
                    if sample == other and view == other_view:
                        continue
                    scores.append((vectors[sample, view] * vectors[other, other_view]).sum() / temperature)
                    positives.append(labels[sample] == labels[other])
            positives = torch.tensor(positives, dtype=torch.bool)
            if positives.any():
                scores = torch.stack(scores)
                losses.append(-(scores[positives] - scores.logsumexp(0)).mean())
    return torch.stack(losses).mean() if losses else features.sum() * 0


def test_supcon_pair_order_matches_independent_reference_and_gradient():
    torch.manual_seed(4)
    features = torch.randn(4, 3, 7, dtype=torch.float64, requires_grad=True)
    labels = torch.tensor([0, 1, 0, 1])
    actual = SupConLoss(0.2)(features, labels)
    expected = reference_supcon(features, labels, 0.2)
    torch.testing.assert_close(actual, expected, rtol=1e-12, atol=1e-12)
    actual_grad, = torch.autograd.grad(actual, features, retain_graph=True)
    expected_grad, = torch.autograd.grad(expected, features)
    torch.testing.assert_close(actual_grad, expected_grad, rtol=1e-11, atol=1e-12)
    permutation = torch.tensor([2, 0, 3, 1])
    torch.testing.assert_close(actual, SupConLoss(0.2)(features[permutation], labels[permutation]))


def test_supcon_rewards_correct_pairs_over_cross_class_pairs():
    correct = torch.tensor([[[1., 0.], [1., 0.]], [[0., 1.], [0., 1.]]])
    mixed = correct.clone()
    mixed[:, 1] = mixed.flip(0)[:, 1]
    labels = torch.tensor([0, 1])
    assert SupConLoss()(correct, labels) < 1e-4
    assert SupConLoss()(mixed, labels) > 10


def test_supcon_autocast_is_finite_and_uses_float32():
    features = torch.randn(8, 2, 16, dtype=torch.bfloat16, requires_grad=True)
    with torch.autocast(device_type="cpu", dtype=torch.bfloat16):
        loss = SupConLoss(0.01)(features, torch.arange(8) % 2)
    assert loss.dtype == torch.float32 and torch.isfinite(loss)
    loss.backward()
    assert torch.isfinite(features.grad).all()


def test_supcon_no_positive_returns_differentiable_zero():
    features = torch.randn(1, 1, 4, requires_grad=True)
    loss = SupConLoss()(features, torch.tensor([0]))
    loss.backward()
    assert loss == 0 and torch.equal(features.grad, torch.zeros_like(features))


@pytest.mark.parametrize("pretrainer", [MaskedTabularAutoencoder, SupConPretrainer])
def test_complete_encoder_transfer_and_missing_state_rejected(pretrainer):
    pre = pretrainer(**KWARGS)
    model = SSLFinetuneClassifier(**KWARGS)
    missing, unexpected = model.load_pretrained(pre.state_dict())
    assert set(missing) == {"head.weight", "head.bias"} and unexpected == []
    for key, value in pre.encoder.state_dict().items():
        assert torch.equal(model.encoder.state_dict()[key], value)
    with pytest.raises(RuntimeError, match="Missing key"):
        model.load_pretrained({})
    incomplete = dict(pre.state_dict())
    incomplete.pop("encoder.feature_identity")
    with pytest.raises(RuntimeError, match="feature_identity"):
        model.load_pretrained(incomplete)


def test_missing_pretrain_checkpoint_requires_explicit_scratch(tmp_path):
    model = SSLFinetuneClassifier(**KWARGS)
    with pytest.raises(FileNotFoundError, match="Required pretrained"):
        model.load_pretrained_checkpoint(tmp_path / "missing.ckpt")
    assert model.load_pretrained_checkpoint(None, allow_scratch=True) is None


def test_frozen_encoder_is_fixed_during_train_and_head_still_learns():
    model = SSLFinetuneClassifier(**{**KWARGS, "attn_dropout": 0.5, "ff_dropout": 0.5}, freeze_encoder=True)
    model.train()
    assert model.training and not model.encoder.training
    assert all(not p.requires_grad for p in model.encoder.parameters())
    a, b = model(batch()), model(batch())
    assert torch.equal(a, b)
    model.loss_fn(a, batch()["target"].ravel()).backward()
    assert model.head.weight.grad is not None
    assert all(p.grad is None for p in model.encoder.parameters())
    model.eval().train()
    assert not model.encoder.training


def test_weighted_checkpoint_reconstructs_scorer_and_rejects_architecture_drift(tmp_path):
    original = SSLFinetuneClassifier(**KWARGS, pos_weight=7).eval()
    checkpoint = {"state_dict": original.state_dict(), "hyper_parameters": dict(original.hparams)}
    path = tmp_path / "weighted.ckpt"
    torch.save(checkpoint, path)
    state = torch.load(path, map_location="cpu", weights_only=False)
    restored = SSLFinetuneClassifier.from_checkpoint_state(state, **KWARGS, pos_weight=1).eval()
    assert torch.equal(restored.loss_fn.weight, torch.tensor([1., 7.]))
    assert torch.equal(original(batch()), restored(batch()))
    with pytest.raises(ValueError, match="num_heads"):
        SSLFinetuneClassifier.from_checkpoint_state(state, **{**KWARGS, "num_heads": 4})


def test_masked_numeric_fields_can_learn_distinct_targets():
    previous_threads = torch.get_num_threads()
    torch.set_num_threads(1)
    try:
        torch.manual_seed(19)
        model = MaskedTabularAutoencoder(**{**KWARGS, "categorical_cardinality": []}, mask_ratio=1.0)
        data = {"continuous": torch.tensor([[2., -2.]]), "categorical": torch.empty(1, 0, dtype=torch.long)}
        model.eval()  # deterministic: both hidden fields see exactly the same visible context
        before = model._reconstruct(data).item()
        optimizer = torch.optim.AdamW(model.parameters(), lr=0.02)
        for _ in range(100):
            optimizer.zero_grad()
            loss = model._reconstruct(data)
            loss.backward()
            optimizer.step()
        assert before > 3
        assert model._reconstruct(data).item() < 0.01
    finally:
        torch.set_num_threads(previous_threads)


def test_tiny_mask_ratio_still_has_differentiable_target():
    model = MaskedTabularAutoencoder(**KWARGS, mask_ratio=1e-30)
    loss = model._reconstruct(batch())
    loss.backward()
    assert torch.isfinite(loss)
    assert model.mask_token.grad is not None


@pytest.mark.parametrize("ratio", [0, -0.1, 1.1])
def test_invalid_mask_ratio_rejected(ratio):
    with pytest.raises(ValueError, match="mask_ratio"):
        MaskedTabularAutoencoder(**KWARGS, mask_ratio=ratio)


@pytest.mark.parametrize("script", ["pretrain_ssl", "pretrain_contrastive", "train_ssl_finetune", "train_contrastive"])
def test_phase5_rejects_distributed_launch_before_reading_data(script, monkeypatch):
    import importlib

    module = importlib.import_module(f"YOUR_PACKAGE.future_experiments.pretrain.scripts.{script}")
    monkeypatch.setenv("WORLD_SIZE", "2")
    with pytest.raises(RuntimeError, match="one training device/process"):
        module.main()
