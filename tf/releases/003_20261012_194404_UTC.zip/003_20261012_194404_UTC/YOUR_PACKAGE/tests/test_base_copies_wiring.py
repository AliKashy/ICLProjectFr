"""owner's rule (2026-10-08): reference's original fraud/ is never edited; corrected copies live in YOUR_PACKAGE/base/.

These checks keep that true: A, B, Phase 5 and the copied reference scripts bind to the corrected copies, and the
original fraud/ package does not contain the copies' new modules.
"""
import ast
import importlib.util
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

CHANGED = {"fraud.data.input_contracts", "fraud.data.contracts", "fraud.data.checkpoint_contracts",
           "fraud.data.parquet_loader", "fraud.data.sequence_builder", "fraud.sequential_model",
           "fraud.streaming_model", "fraud.scripts"}
# A and B import only these unchanged helper functions from fraud.data.parquet_loader (identical in the copy).
UNCHANGED_HELPERS = {"streaming_categorical_cardinality", "streaming_categorical_columns", "missing_flag_columns"}


def _imports(path):
    """(module, imported names or None) for every import; `from fraud.data import x` also yields fraud.data.x."""
    tree = ast.parse(Path(path).read_text())
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module:
            names = {a.name for a in node.names}
            yield node.module, names
            if node.module in ("fraud", "fraud.data"):  # a submodule imported through its package
                for n in names:
                    yield f"{node.module}.{n}", None
        elif isinstance(node, ast.Import):
            for a in node.names:
                yield a.name, None  # a whole module, never only the unchanged helpers


# reference's packages re-export the original loader and builder (fraud/__init__.py, fraud/data/__init__.py).
REEXPORTS = {"ParquetStreamingDataset", "SequenceBuilder"}
# Tests that deliberately exercise reference's original modules, as a reference.
ORIGINAL_REFERENCE_TESTS = {"YOUR_PACKAGE/tests/test_sequence_builder.py"}


def test_original_fraud_has_no_copied_modules():
    for name in ("input_contracts", "contracts", "checkpoint_contracts"):
        assert not (ROOT / "fraud" / "data" / f"{name}.py").exists(), f"fraud/data/{name}.py must not exist"
        assert (ROOT / "YOUR_PACKAGE" / "base" / "data" / f"{name}.py").exists()


def _misbound(path):
    bad = []
    for module, names in _imports(path):
        if module == "fraud.data.parquet_loader" and names is not None and names <= UNCHANGED_HELPERS:
            continue
        if module in ("fraud", "fraud.data") and names and names & REEXPORTS:
            bad.append(f"{module} re-export {sorted(names & REEXPORTS)}")
        elif module in CHANGED or any(module.startswith(m + ".") for m in CHANGED):
            bad.append(f"{module} {sorted(names) if names else '(whole module)'}")
    return bad


def test_owned_code_imports_corrected_copies():
    owned = [p for d in ("YOUR_PACKAGE/phase4a", "YOUR_PACKAGE/phase4b", "YOUR_PACKAGE/future_experiments", "YOUR_PACKAGE/scoring", "YOUR_PACKAGE/base",
                         "YOUR_PACKAGE/tests") for p in (ROOT / d).rglob("*.py")]
    assert owned
    bad = [f"{p.relative_to(ROOT)}: {b}" for p in owned
           if str(p.relative_to(ROOT)) not in ORIGINAL_REFERENCE_TESTS | {"YOUR_PACKAGE/tests/test_base_copies_wiring.py"}
           for b in _misbound(p)]
    assert not bad, "owned code imports a changed original module:\n" + "\n".join(bad)


def test_guard_catches_every_import_form(tmp_path):
    forms = ["import fraud.data.parquet_loader", "import fraud.data.parquet_loader as pl",
             "from fraud.data import ParquetStreamingDataset", "from fraud import SequenceBuilder",
             "from fraud.data import sequence_builder", "from fraud import sequential_model, streaming_model",
             "from fraud.data.parquet_loader import ParquetStreamingDataset", "from fraud.scripts import train_streaming"]
    for i, line in enumerate(forms):
        f = tmp_path / f"probe_{i}.py"
        f.write_text(line + "\n")
        assert _misbound(f), line
    ok = tmp_path / "ok.py"
    ok.write_text("from fraud.data.parquet_loader import streaming_categorical_columns\nimport fraud.data.s3_utils\n")
    assert not _misbound(ok)


def test_a_b_bind_to_corrected_contracts():
    import YOUR_PACKAGE.phase4a.factory as fa
    import YOUR_PACKAGE.phase4a.sequence_builder as sa
    import YOUR_PACKAGE.phase4b.factory as fb
    import YOUR_PACKAGE.phase4b.sequence_builder as sb
    for mod in (fa, fb):
        assert mod.build_input_contract.__module__ == "YOUR_PACKAGE.base.data.contracts"
    for mod in (sa, sb):
        assert mod.parse_required_timestamps.__module__ == "YOUR_PACKAGE.base.data.input_contracts"
        assert mod.encode_binary_target.__module__ == "YOUR_PACKAGE.base.data.input_contracts"


def test_copied_reference_scripts_resolve_to_copies():
    for name in ("train_streaming", "score_streaming", "train_sequential", "score_sequential",
                 "train_baseline", "score_eval"):
        spec = importlib.util.find_spec(f"YOUR_PACKAGE.base.scripts.{name}")
        assert spec is not None and Path(spec.origin).resolve().parent == ROOT / "YOUR_PACKAGE" / "base" / "scripts"
        for module, _ in _imports(spec.origin):
            assert module not in CHANGED and not module.startswith("fraud.scripts"), (name, module)
