"""Offline subprocess regression checks for Phase 4 artifact identity and failure status.

Runner checks execute the real CLI with tiny test-owned train/score subprocesses.
Scorer checks execute the real main loop on two synthetic rows and local Parquet,
replacing only the remote data/checkpoint model fixtures. No S3 or bank data.
Set TF_RUNNER_TEST_ROOT to a separate source export for a negative control.
"""

import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

from omegaconf import OmegaConf
import pytest


SOURCE_ROOT = Path(os.environ.get(
    "TF_RUNNER_TEST_ROOT", Path(__file__).resolve().parents[2]
))

TRAIN_STUB = r'''
import argparse
from pathlib import Path
from omegaconf import OmegaConf
import torch

parser = argparse.ArgumentParser()
parser.add_argument("--config")
parser.add_argument("overrides", nargs="*")
args = parser.parse_args()
cfg = OmegaConf.merge(OmegaConf.load(args.config), OmegaConf.from_dotlist(args.overrides))
run = Path(cfg.output.checkpoint_dir)
run.mkdir(parents=True, exist_ok=True)
OmegaConf.save(cfg, run / "train_config.yaml")
mode = cfg.probe.get("train", "ok")
if mode != "missing_metrics":
    value = "nan" if mode == "nonfinite_metrics" else ("0.9999" if mode == "fail" else "0.42")
    (run / "training_metrics.csv").write_text(
        f"epoch,step,valid_ap,valid_auroc\n0,1,{value},0.73\n1,2,0.4,0.88\n"
    )
if mode != "missing_checkpoint":
    torch.save({"epoch": 5 if mode == "wrong_epoch" else 0, "global_step": 1, "state_dict": {}, "callbacks": {
        "ModelCheckpoint": {"monitor": "valid_ap", "best_model_score": 0.42}
    }}, run / "best.ckpt")
if mode == "mutate_source":
    source = Path(__file__)
    source.write_text(source.read_text() + "\n# altered while this run was training\n")
print("synthetic train", mode)
raise SystemExit(7 if mode == "fail" else 0)
'''

SCORE_STUB = r'''
import argparse
import hashlib
import json
from pathlib import Path
from omegaconf import OmegaConf

parser = argparse.ArgumentParser()
parser.add_argument("--config")
parser.add_argument("overrides", nargs="*")
args = parser.parse_args()
cfg = OmegaConf.merge(OmegaConf.load(args.config), OmegaConf.from_dotlist(args.overrides))
run = Path(cfg.output.checkpoint_dir)
OmegaConf.save(cfg, run / "score_config.yaml")
assert Path(cfg.eval.checkpoint).is_file()
print(f"Wrote 2 predictions -> synthetic/preds/{cfg.experiment.run_name}_preds.parquet (positives=1)")
mode = cfg.probe.get("score", "ok")
if cfg.eval.compute_metrics and mode != "missing_metrics":
    ap = "nan" if mode == "nonfinite_metrics" else "1.2e-1"
    print(f"Range metrics: average_precision={ap}  auroc=7.5e-1  (n=2, positives=1)")
if mode != "missing_metrics":
    payload = {
        "schema_version": 1,
        "predictions_path": f"synthetic/preds/{cfg.experiment.run_name}_preds.parquet",
        "checkpoint_path": str(Path(cfg.eval.checkpoint).resolve()),
        "checkpoint_sha256": hashlib.sha256(Path(cfg.eval.checkpoint).read_bytes()).hexdigest(),
        "n_predictions": 2, "n_positives": 1,
        "average_precision": (float("nan") if mode == "nonfinite_metrics" else 0.12) if cfg.eval.compute_metrics else None,
        "auroc": 0.75 if cfg.eval.compute_metrics else None,
    }
    if mode == "wrong_checkpoint":
        payload["checkpoint_sha256"] = "stale"
    Path(cfg.eval.metrics_output).write_text(json.dumps(payload))
raise SystemExit(9 if mode == "fail" else 0)
'''

SCORER_PROBE = r'''
import importlib.util
from pathlib import Path
import sys
from types import SimpleNamespace
import numpy as np
import pyarrow as pa
from pyarrow import fs
import pyarrow.parquet as pq
import torch

source, config = map(Path, sys.argv[1:3])
spec = importlib.util.spec_from_file_location("scorer_under_test", source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.make_s3_filesystem = lambda cred: fs.LocalFileSystem()
module.load_feature_list = lambda *args, **kwargs: []
module.PreprocessingArtifacts = SimpleNamespace(load=lambda *args, **kwargs: None)
module.DatetimeConfig = lambda **kwargs: None
module.build_file_list = lambda *args: []
batch = {
    "continuous": torch.tensor([[[2.0]], [[-2.0]]]),
    "categorical": torch.empty(2, 1, 0, dtype=torch.long),
    "mask": torch.ones(2, 1, dtype=torch.bool),
    "target": torch.tensor([0, 1]),
    "meta": {"transaction_id": np.array([101, 102])},
}
module.SequenceBuilder = lambda **kwargs: [batch]

class ToyModel(torch.nn.Module):
    sequence_contract = None
    def on_load_checkpoint(self, checkpoint):
        pass

    def forward(self, values):
        x = values["continuous"][:, 0, 0]
        return torch.stack([x, -x], dim=1)

module.build_sequential_model = lambda *args: ToyModel()
torch.save({"state_dict": {}}, config.parent / "best.ckpt")
output = config.parent / "predictions"
output.mkdir()
for attempt in range(2):
    before = {p.name: p.read_bytes() for p in output.glob("*.parquet")}
    sys.argv = [str(source), "--config", str(config)]
    module.main()
    after = {p.name: p.read_bytes() for p in output.glob("*.parquet")}
    assert len(after) == len(before) + 1, (before.keys(), after.keys())
    assert all(after[name] == data for name, data in before.items())
    latest = next(p for p in output.glob("*.parquet") if p.name not in before)
    table = pq.read_table(latest).to_pydict()
    assert table["transaction_id"] == [101, 102]
    assert table["fraud"] == [0, 1]
    assert 0 < table["score"][0] < table["score"][1] < 1
print("two distinct prediction files; earlier bytes preserved")
'''


@pytest.fixture(params=["phase4a", "phase4b"])
def app(tmp_path, request):
    return make_app(tmp_path, request.param)


def make_app(tmp_path, phase):
    """Isolate the real runner so every spawned training/scoring process is synthetic."""
    root = tmp_path / "repo"
    scripts = root / "YOUR_PACKAGE" / phase / "scripts"
    scripts.mkdir(parents=True)
    source = SOURCE_ROOT / "YOUR_PACKAGE" / phase / "scripts"
    shutil.copyfile(source / "run_ablations.py", scripts / "run_ablations.py")
    (scripts / "train_sequential.py").write_text(TRAIN_STUB)
    (scripts / "score_sequential.py").write_text(SCORE_STUB)
    (root / "fraud").mkdir()
    shutil.copyfile(SOURCE_ROOT / "fraud/log_utils.py", root / "fraud/log_utils.py")
    base = {
        "output": {"checkpoint_dir": "unused"},
        "eval": {"compute_metrics": True, "predictions_base": "s3://synthetic/preds"},
        "sequence": {"attention_mask": "causal"},
        "probe": {"train": "ok", "score": "ok"},
    }
    OmegaConf.save(OmegaConf.create(base), root / "base.yaml")
    spec = {
        "base_config": "base.yaml",
        "output_root": "ablations/grid",
        "results_csv": "ablations/grid/results.csv",
        "run_score": True,
        "common_overrides": ["sequence.attention_mask=causal"],
        "axes": {"mask": {"bidir": ["sequence.attention_mask=bidirectional"]}},
    }
    return root, scripts, spec, phase


def launch(app, **changes):
    root, scripts, spec, _ = app
    cfg = {**spec, **changes}
    OmegaConf.save(OmegaConf.create(cfg), root / "spec.yaml")
    # An outside cwd exercises the runner's repository-root-relative output contract.
    proc = subprocess.run(
        [sys.executable, str(scripts / "run_ablations.py"), "--config", str(root / "spec.yaml")],
        cwd=root.parent, capture_output=True, text=True, timeout=30,
    )
    rows = []
    result = root / "ablations/grid/results.csv"
    if result.exists():
        with result.open(newline="") as stream:
            rows = list(csv.DictReader(stream))
    return proc, rows


def test_repeated_cli_preserves_prior_artifacts_and_override_precedence(app):
    root, _, _, _ = app
    latest = root / "ablations/grid/results.csv"
    latest.parent.mkdir(parents=True)
    legacy = b"run_name,best_valid_ap\r\nlegacy,0.9\r\n"
    latest.write_bytes(legacy)

    first, rows = launch(app)
    assert first.returncode == 0, first.stdout + first.stderr
    first_row = rows[0]
    first_dir = Path(first_row["run_dir"])
    assert (first_dir.parent / "previous_results.csv").read_bytes() == legacy
    assert (first_dir.parent / "results.csv").read_bytes() == latest.read_bytes()
    assert first_row["eval_ap"] == "0.12"
    assert first_row["eval_auroc"] == "0.75"
    assert first_row["score_rc"] == "0"
    assert first_row["status"] == "ok"
    assert first_row["predictions_path"].startswith("synthetic/preds/")
    # AUROC belongs to the selected AP checkpoint, not its separate 0.88 peak.
    assert first_row["best_valid_ap"] == "0.42"
    assert first_row["best_valid_auroc"] == "0.73"
    assert first_row["checkpoint_epoch"] == "0"
    assert first_row["checkpoint_step"] == "1"
    manifest = json.loads((first_dir / "run_manifest.json").read_text())
    assert manifest["result"]["checkpoint_sha256"] == hashlib.sha256((first_dir / "best.ckpt").read_bytes()).hexdigest()
    assert manifest["resolved_train_sha256"] == hashlib.sha256((first_dir / "resolved_train.yaml").read_bytes()).hexdigest()
    assert manifest["source_before"]["files"]
    assert first_row["n_predictions"] == "2"
    summary = (first_dir / "run_summary.txt").read_text(encoding="utf-8")  # the owner's per-run summary (2026-10-08)
    assert f"Attempt:         {first_row['attempt']}" in summary
    assert "Train exit code: 0 (OK)" in summary and "Run status:      ok\n" in summary
    assert "best_valid_ap:    0.4200" in summary and "best_valid_auroc: 0.7300" in summary
    assert "eval_ap:          0.1200" in summary and "eval_auroc:       0.7500" in summary
    train = OmegaConf.load(first_dir / "train_config.yaml")
    score = OmegaConf.load(first_dir / "score_config.yaml")
    assert train.sequence.attention_mask == score.sequence.attention_mask == "bidirectional"
    assert train.output.checkpoint_dir == score.output.checkpoint_dir == str(first_dir)
    assert train.experiment.run_name == score.experiment.run_name
    assert score.eval.checkpoint == str(first_dir / "best.ckpt")
    before = {p.relative_to(first_dir.parent): p.read_bytes()
              for p in first_dir.parent.rglob("*") if p.is_file()}

    second, rows = launch(app)
    assert second.returncode == 0, second.stdout + second.stderr
    second_dir = Path(rows[0]["run_dir"])
    assert second_dir != first_dir
    assert rows[0]["attempt"] != first_row["attempt"]
    assert rows[0]["predictions_path"] != first_row["predictions_path"]
    assert all((first_dir.parent / name).read_bytes() == data for name, data in before.items())


def test_failed_training_never_reads_or_ranks_partial_or_stale_metrics(app):
    root, _, spec, _ = app
    first, prior = launch(app)
    assert first.returncode == 0
    legacy = root / "ablations/grid/mask-bidir"
    legacy.mkdir()
    (legacy / "training_metrics.csv").write_text("valid_ap,valid_auroc\n0.9999,0.9999\n")
    failed, rows = launch(app, common_overrides=spec["common_overrides"] + ["probe.train=fail"])
    assert failed.returncode != 0
    row = rows[0]
    assert row["train_rc"] == "7"
    assert row["status"] == "train_failed"
    assert row["best_valid_ap"] == row["best_valid_auroc"] == row["eval_ap"] == ""
    assert row["score_rc"] == ""
    run_dir = Path(row["run_dir"])
    assert not (run_dir / "score_config.yaml").exists()
    summary = (run_dir / "run_summary.txt").read_text(encoding="utf-8")
    assert "Train exit code: 7 (FAILED -- see train.log)" in summary
    assert "Run status:      train_failed -- not ranked" in summary
    assert "best_valid_ap:    -" in summary and "eval_ap:          -" in summary
    assert "0.9999" in (run_dir / "training_metrics.csv").read_text()
    assert (run_dir.parent / "results.csv").exists()
    assert Path(prior[0]["run_dir"]).exists()
    ranked = failed.stdout.split("=== Failed/incomplete")[0]
    assert "mask-bidir" not in ranked
    assert "0.9999" not in failed.stdout


def test_failed_score_is_recorded_excluded_and_propagated(app):
    _, _, spec, _ = app
    proc, rows = launch(app, common_overrides=spec["common_overrides"] + ["probe.score=fail"])
    assert proc.returncode != 0
    assert rows[0]["train_rc"] == "0"
    assert rows[0]["score_rc"] == "9"
    assert rows[0]["status"] == "score_failed"
    assert rows[0]["eval_ap"] == rows[0]["eval_auroc"] == ""
    assert "mask-bidir" not in proc.stdout.split("=== Failed/incomplete")[0]


@pytest.mark.parametrize("override,status", [
    ("probe.train=missing_metrics", "train_metrics_missing"),
    ("probe.train=nonfinite_metrics", "train_metrics_invalid"),
    ("probe.train=missing_checkpoint", "checkpoint_missing"),
    ("probe.train=wrong_epoch", "train_metrics_invalid"),
    ("probe.train=mutate_source", "source_changed"),
    ("probe.score=missing_metrics", "score_metrics_missing"),
    ("probe.score=nonfinite_metrics", "score_metrics_invalid"),
    ("probe.score=wrong_checkpoint", "score_metrics_invalid"),
])
def test_incomplete_success_is_not_reported_as_a_success(app, override, status):
    _, _, spec, _ = app
    proc, rows = launch(app, common_overrides=spec["common_overrides"] + [override])
    assert proc.returncode != 0
    assert rows[0]["status"] == status
    assert "mask-bidir" not in proc.stdout.split("=== Failed/incomplete")[0]


def test_remaining_cells_run_after_failure(app):
    axes = {"case": {
        "bad": ["probe.train=fail"],
        "good": ["probe.train=ok"],
    }}
    proc, rows = launch(app, axes=axes)
    assert proc.returncode != 0
    assert [r["status"] for r in rows] == ["train_failed", "ok"]
    assert rows[1]["eval_ap"] == "0.12"
    ranked = proc.stdout.split("=== Failed/incomplete")[0]
    assert "case-good" in ranked
    assert "case-bad" not in ranked


@pytest.mark.parametrize("changes", [
    {"run_score": False},
    {"common_overrides": ["eval.compute_metrics=false"]},
])
def test_intentionally_disabled_scoring_or_metrics_succeeds(app, changes):
    proc, rows = launch(app, **changes)
    assert proc.returncode == 0, proc.stdout + proc.stderr
    assert rows[0]["status"] == "ok"
    assert rows[0]["eval_ap"] == rows[0]["eval_auroc"] == ""
    if changes.get("run_score") is False:
        assert rows[0]["score_rc"] == ""
        assert not (Path(rows[0]["run_dir"]) / "score.log").exists()


def test_explicit_attempt_cannot_silently_overwrite(app):
    root, _, _, _ = app
    first, rows = launch(app, attempt_tag="review-attempt")
    assert first.returncode == 0
    latest = root / "ablations/grid/results.csv"
    before = latest.read_bytes()
    old_log = (Path(rows[0]["run_dir"]) / "train.log").read_bytes()
    second, _ = launch(app, attempt_tag="review-attempt")
    assert second.returncode != 0
    assert "already exists" in second.stderr
    assert latest.read_bytes() == before
    assert (Path(rows[0]["run_dir"]) / "train.log").read_bytes() == old_log


def test_dry_run_creates_no_artifacts(app):
    root, scripts, spec, _ = app
    OmegaConf.save(OmegaConf.create(spec), root / "spec.yaml")
    proc = subprocess.run(
        [sys.executable, str(scripts / "run_ablations.py"), "--config",
         str(root / "spec.yaml"), "--dry-run"],
        capture_output=True, text=True, timeout=30,
    )
    assert proc.returncode == 0, proc.stderr
    assert "mask-bidir" in proc.stdout
    assert not (root / "ablations").exists()


@pytest.mark.parametrize("experiment", [None, {}, {"run_name": "manual_same_label"}])
def test_real_scorer_retains_both_manual_attempts(app, tmp_path, experiment):
    _, _, _, phase = app
    work = tmp_path / "score_probe"
    work.mkdir()
    config = {
        "s3": {"cred_path": "unused"},
        "predictors": {"csv_path": "unused", "version": "synthetic"},
        "artifacts": {"base": "unused", "version": "synthetic"},
        "datetime": {"fields": [], "encoding": "categorical", "is_weekend": False},
        "model": {"type": "FTTransformerHier" if phase == "phase4b" else "FTTransformerSeq"},
        "data": {"order_col": "time", "target_col": "fraud", "account_col": "account",
                 "id_cols": ["transaction_id"]},
        "eval": {"base": "unused", "file_start": 1, "file_end": 1,
                 "checkpoint": str(work / "best.ckpt"),
                 "metrics_output": str(work / "score_metrics.json"),
                 "predictions_base": str(work / "predictions"), "compute_metrics": True},
        "sequence": {"history_len": 0},
        "preprocess": {"add_missing_flag": False},
        "training": {"batch_size": 2, "num_workers": 0},
        "experiment": experiment,
    }
    OmegaConf.save(OmegaConf.create(config), work / "config.yaml")
    (work / "probe.py").write_text(SCORER_PROBE)
    proc = subprocess.run(
        [sys.executable, str(work / "probe.py"),
         str(SOURCE_ROOT / "YOUR_PACKAGE" / phase / "scripts/score_sequential.py"),
         str(work / "config.yaml")],
        capture_output=True, text=True, timeout=60,
        env={**os.environ, "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"},
    )
    assert proc.returncode == 0, proc.stdout + proc.stderr
    assert "two distinct prediction files" in proc.stdout
    metrics = json.loads((work / "score_metrics.json").read_text())
    assert metrics["schema_version"] == 1
    assert metrics["average_precision"] == metrics["auroc"] == 1.0
    assert metrics["n_predictions"] == 2
    assert metrics["n_positives"] == 1
    assert metrics["checkpoint_sha256"] == hashlib.sha256((work / "best.ckpt").read_bytes()).hexdigest()
