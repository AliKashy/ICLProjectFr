"""Actual CPU train -> checkpoint -> score against local parquet/artifacts."""

import importlib
import json
from pathlib import Path
import sys

import fsspec
import numpy as np
import pandas as pd
import pytest
import torch
from omegaconf import OmegaConf

from fraud.data.preprocessing import PreprocessingArtifacts


ROOT = Path(__file__).resolve().parents[2]


def fixture_config(tmp_path, kind):
    data = tmp_path / "data"
    data.mkdir()
    for index in (1, 2, 3):
        pd.DataFrame({"amount": [1., 2., 3., 4.], "channel": ["x", "y", "x", "y"],
            "transaction_dttm": pd.date_range(f"2025-01-0{index}", periods=4, freq="h"),
            "frd_tag": [0, 1, 0, 1], "Nmap_account_reference_xid": ["account"] * 4,
            "fi_transaction_id": [f"{index}-{row}" for row in range(4)]}).to_parquet(data / f"part_{index}.parquet", index=False)
    predictors = tmp_path / "predictors.csv"
    predictors.write_text("feature,type,source,version\namount,continuous,raw,1\nchannel,categorical,raw,1\nhour,categorical,derived:transaction_dttm,1\n")
    artifacts = PreprocessingArtifacts(artifact_version=1, predictor_version=1, fit_files=[str(data / "part_1.parquet")])
    artifacts.fit_feature("amount", pd.Series([1., 2., 3., 4.]), "continuous")
    artifacts.fit_feature("channel", pd.Series(["x", "y"]), "categorical")
    artifacts.fit_feature("hour", pd.Series([0, 1, 2, 3]), "categorical")
    artifacts.save(str(tmp_path / "artifacts/1"))
    cfg = OmegaConf.load(ROOT / f"fraud/configs/{kind}.yaml")
    cfg = OmegaConf.merge(cfg, OmegaConf.create({
        "predictors": {"csv_path": str(predictors), "version": 1}, "artifacts": {"base": str(tmp_path / "artifacts")},
        "data": {"train_base": str(data), "train_start": 1, "train_end": 1,
                 "val_base": str(data), "val_start": 2, "val_end": 2, "amount_col": "amount"},
        "model": {"input_embed_dim": 8, "num_heads": 2, "num_attn_blocks": 2, "attn_dropout": 0., "ff_dropout": 0.},
        "training": {"max_epochs": 1, "batch_size": 4, "num_workers": 0, "accelerator": "cpu",
                     "precision": "32-true", "pos_weight": 3., "buffer_windows": 4, "seed": 42},
        "preprocess": {"add_missing_flag": False}, "datetime": {"fields": ["hour"]},
        "experiment": {"enabled": False}, "s3": {"cred_path": "unused-local-fixture"},
        "output": {"checkpoint_dir": str(tmp_path / "checkpoints")},
        "eval": {"base": str(data), "file_start": 3, "file_end": 3,
                 "checkpoint": str(tmp_path / "checkpoints/best.ckpt"),
                 "predictions_base": str(tmp_path / "predictions"), "compute_metrics": True}}))
    if kind == "sequential":
        cfg.sequence.history_len = 2
        cfg.sequence.attention_mask = "causal"
    Path(cfg.eval.predictions_base).mkdir()
    path = tmp_path / "config.yaml"
    OmegaConf.save(cfg, path)
    return cfg, path


@pytest.mark.parametrize("kind", ["streaming", "sequential"])
def test_actual_weighted_train_checkpoint_score_and_overwrite_protection(tmp_path, monkeypatch, kind):
    # One CPU device, one tiny epoch. No mocked model, training step or checkpoint.
    old_threads = torch.get_num_threads()
    torch.set_num_threads(1)
    try:
        cfg, config_path = fixture_config(tmp_path, kind)
        train = importlib.import_module(f"YOUR_PACKAGE.base.scripts.train_{kind}")
        score = importlib.import_module(f"YOUR_PACKAGE.base.scripts.score_{kind}")
        fs = fsspec.filesystem("file")
        for name in (f"YOUR_PACKAGE.base.scripts.train_{kind}", f"YOUR_PACKAGE.base.scripts.score_{kind}",
                     "YOUR_PACKAGE.base.data.sequence_builder", "YOUR_PACKAGE.base.data.parquet_loader"):
            monkeypatch.setattr(importlib.import_module(name), "make_s3_filesystem", lambda *a, **k: fs)
        real_trainer = train.pl.Trainer
        devices = []
        def trainer(**kwargs):
            devices.append(kwargs.get("devices"))
            kwargs.update(enable_progress_bar=False, enable_model_summary=False, num_sanity_val_steps=0)
            return real_trainer(**kwargs)
        monkeypatch.setattr(train.pl, "Trainer", trainer)
        monkeypatch.setattr(sys, "argv", ["train", "--config", str(config_path)])
        train.main()
        assert devices == [1]
        checkpoint = torch.load(cfg.eval.checkpoint, weights_only=False, map_location="cpu")
        assert checkpoint["fraud_input_contract"]["continuous_columns"]
        assert len(checkpoint["fraud_input_contract"]["artifacts_sha256"]) == 64
        weights = [value for name, value in checkpoint["state_dict"].items() if name in ("loss_fn.weight", "loss.weight")]
        assert len(weights) == 1
        assert weights[0].tolist() == [1., 3.]
        monkeypatch.setattr(sys, "argv", ["score", "--config", str(config_path)])
        score.main()
        filename = "part_3.parquet" if kind == "streaming" else "sequential_preds.parquet"
        output = Path(cfg.eval.predictions_base) / filename
        predictions = pd.read_parquet(output)
        assert len(predictions) == 4
        assert predictions["fi_transaction_id"].nunique() == 4
        assert predictions["frd_tag"].sum() == 2
        assert np.isfinite(predictions["score"]).all()
        assert predictions["score"].between(0, 1).all()
        before = output.read_bytes()
        with pytest.raises(FileExistsError, match="attempt root"):
            score.main()
        assert output.read_bytes() == before
        # Dropout leaves tensor shapes unchanged: loading must still reject it.
        for override in ("model.attn_dropout=0.2", "training.pos_weight=1.0"):
            monkeypatch.setattr(sys, "argv", ["score", "--config", str(config_path), override,
                f"eval.predictions_base={tmp_path / 'unused'}"])
            with pytest.raises(ValueError, match="mismatch"):
                score.main()
        assert not (tmp_path / "unused" / filename).exists()
        # Refitting numeric preprocessing keeps model tensor shapes unchanged.
        artifact_path = Path(cfg.artifacts.base) / "1/feature__amount.json"
        entry = json.loads(artifact_path.read_text())
        entry["mean"] += 0.5
        artifact_path.write_text(json.dumps(entry))
        monkeypatch.setattr(sys, "argv", ["score", "--config", str(config_path),
            f"eval.predictions_base={tmp_path / 'refitted'}"])
        with pytest.raises(ValueError, match="frozen input contract mismatch"):
            score.main()
        assert not (tmp_path / "refitted" / filename).exists()
    finally:
        torch.set_num_threads(old_threads)


@pytest.mark.parametrize("name", ["YOUR_PACKAGE.base.scripts.train_streaming", "YOUR_PACKAGE.base.scripts.train_sequential",
                                  "YOUR_PACKAGE.phase4a.scripts.train_sequential"])
def test_distributed_launch_rejected_before_config_or_data_access(monkeypatch, name):
    module = importlib.import_module(name)
    monkeypatch.setenv("WORLD_SIZE", "2")
    monkeypatch.setattr(sys, "argv", ["train", "--config", "does-not-exist.yaml"])
    with pytest.raises(RuntimeError, match="not rank-sharded"):
        module.main()


def test_legacy_checkpoint_reports_unbound_artifact_identity():
    from YOUR_PACKAGE.base.data.checkpoint_contracts import validate_input_contract
    with pytest.warns(RuntimeWarning, match="identity is unverified"):
        validate_input_contract({}, {"artifacts_sha256": "current"})
