"""B9 amendment (reviewer-model-data-1 B1, confirmed by reviewer-judge-1; DESIGN_V1_AFTER_RUN001.md 6.3 (a) to (c)).

Under ``history_time_order: strict`` all-position chunks are cut only between whole seconds and hold up to
H+1 distinct seconds, so where a row's chunk starts never depends on how many rows share any second. Chunks
can then hold more than T = H+1 rows; batches are padded to their widest chunk and the position index is the
strictly-earlier count clamped to H. These tests pin:

- sibling invariance: for random accounts with whole-second ties, adding, removing or reordering a
  same-second sibling of a target leaves the target's inputs (features seen, mask row, gap, position) and its
  score unchanged, at 2 and 4 sequence layers;
- strict chunk boundaries fall only between distinct seconds, with up to H+1 seconds per chunk, keyed on
  whole seconds rather than sub-second timestamps (review R3);
- an account whose single second holds more than H+1 rows;
- padding to the widest chunk, with one target, loss term and prediction per real row;
- the scorer and the trainer build the same chunks;
- tiebreak chunks (and so default B, which never pads) keep the row-count cut and fixed width.
- review R1: the optional max_chunk_rows cap raises (never truncates) in training and scoring, and the
  width measurement script matches the builder; review R2: a strict model refuses a batch narrower than T or
  a chunk holding more than H+1 distinct whole seconds.

Run: PYTHONPATH=src:. python3 -m pytest -q -p no:cacheprovider YOUR_PACKAGE/tests/test_b_allposition_sibling_invariance.py
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
import pytest
import torch
from omegaconf import OmegaConf

from YOUR_PACKAGE.phase4b.scripts import score_sequential as scorer
from YOUR_PACKAGE.phase4b.scripts import train_sequential as trainer
from YOUR_PACKAGE.tests.test_b_allposition_strict_time import (  # noqa: F401  (ties is a pytest fixture)
    ACCOUNT, HISTORY_LEN, ID, _batches, _dataset, _gaps_by_id, _model, _position_indices, _scores, ties,
)

T = HISTORY_LEN + 1
BASE = pd.Timestamp("2024-01-01")


def _frame(rows, base=BASE):
    """rows: dicts with account, second (whole or fractional), id and optional f1, f2, c1, c2, label."""
    return pd.DataFrame({
        "transaction_dttm": base + pd.to_timedelta([r["second"] for r in rows], unit="s"),
        ACCOUNT: [r["account"] for r in rows], ID: [r["id"] for r in rows],
        "f1": [r.get("f1", 0.5) for r in rows], "f2": [r.get("f2", -0.5) for r in rows],
        "c1": [r.get("c1", "A") for r in rows], "c2": [r.get("c2", "X") for r in rows],
        "frd_tag": [r.get("label", 0) for r in rows], "transaction_amt": [1.0] * len(rows),
    })


def _ident(account, second, rank):
    # The tie-break id sorts by rank inside a second; a lower rank sorts (and is placed) first.
    return f"{account}-{second:05d}-{rank:03d}"


def _random_rows(rng, accounts=3):
    rows = []
    for a in range(accounts):
        account = f"acct{a}"
        n = int(rng.integers(1, 22))
        # Whole seconds with many ties: increments of 0 make same-second groups.
        seconds = np.cumsum(rng.choice([0, 0, 1, 3, 40], size=n)) + int(rng.integers(0, 100))
        for second in np.unique(seconds):
            count = int((seconds == second).sum())
            for rank in rng.choice(np.arange(100, 900, 10), size=count, replace=False):
                rows.append(_row(rng, account, int(second), int(rank)))
    return rows


def _row(rng, account, second, rank):
    return dict(account=account, second=second, id=_ident(account, second, rank),
                f1=float(rng.normal()), f2=float(rng.normal()), c1=str(rng.choice(["A", "B"])),
                c2=str(rng.choice(["X", "Y"])), label=int(rng.integers(0, 2)))


def _target_view(model, batches, target):
    """Everything the model reads for one target row, keyed by row identity rather than chunk slot."""
    for batch in batches:
        ids, real = batch["meta_seq"][ID], batch["mask"].numpy()
        hits = np.argwhere((ids == target) & real)
        if not len(hits):
            continue
        assert len(hits) == 1  # one prediction per real row
        b, i = (int(v) for v in hits[0])
        key_padding = torch.cat([torch.zeros(len(real), 1, dtype=torch.bool), ~batch["mask"]], dim=1)
        heads = model.hparams.num_heads
        mask_row = ~torch.isinf(model._build_causal_mask("cpu", key_padding, batch["time_seq"])[b * heads, 1 + i])
        assert not mask_row[0]  # no transaction reads seq_CLS
        visible = np.flatnonzero(mask_row[1:].numpy())
        assert real[b, visible].all()  # no real row reads a padded slot
        seen = {ids[b, j]: (tuple(batch["continuous"][b, j].tolist()), tuple(batch["categorical"][b, j].tolist()),
                            int(batch["time_seq"][b, j])) for j in visible}
        with torch.no_grad():
            score = float(torch.softmax(model(batch)[b, i], dim=-1)[1])
        return dict(seen=seen, gap=float(batch["continuous"][b, i, -1]),
                    position=int(_position_indices(model, batch)[b, i]), score=score)
    raise AssertionError(f"{target} has no prediction")


def _variants(rng, rows, target):
    """Frames that differ from rows only by same-second siblings of target: added, removed or reordered."""
    t = next(r for r in rows if r["id"] == target)
    peers = [r for r in rows if r["account"] == t["account"] and r["second"] == t["second"] and r is not t]
    rank = int(t["id"].rsplit("-", 1)[1])
    used = {int(r["id"].rsplit("-", 1)[1]) for r in peers} | {rank}

    def fresh(low):
        pool = [k for k in (range(rank - 9, 0, -1) if low else range(rank + 1, 999)) if k not in used]
        used.add(pool[0])
        return _row(rng, t["account"], t["second"], pool[0])

    out = {"add_lower": rows + [fresh(True)], "add_higher": rows + [fresh(False)],
           "add_four": rows + [fresh(True), fresh(False), fresh(True), fresh(False)]}
    if peers:
        out["remove_one"] = [r for r in rows if r is not peers[0]]
        out["remove_all"] = [r for r in rows if r not in peers]
        swapped = []
        for r in rows:  # move every peer to the other side of the target in tie-break order
            if any(r is p for p in peers):
                low = int(r["id"].rsplit("-", 1)[1]) > rank
                r = dict(fresh(low), f1=r["f1"], f2=r["f2"], c1=r["c1"], c2=r["c2"], label=r["label"])
            swapped.append(r)
        out["reorder"] = swapped
    for name in list(out):
        out[name + "_shuffled"] = [out[name][k] for k in rng.permutation(len(out[name]))]
    return out


# --------------------------------------------------------------------------- the guarantee
@pytest.mark.parametrize("blocks", [2, 4])
def test_same_second_siblings_never_change_a_targets_inputs_or_score(ties, blocks):
    model, dataset = _model(ties, blocks=blocks)
    rng = np.random.default_rng(100 + blocks)
    checked = moved_width = 0
    for _ in range(6):
        rows = _random_rows(rng)
        base_batches = _batches(dataset, _frame(rows))
        for target in rng.choice([r["id"] for r in rows], size=min(4, len(rows)), replace=False):
            reference = _target_view(model, base_batches, target)
            for name, variant in _variants(rng, rows, target).items():
                batches = _batches(dataset, _frame(variant))
                same_shapes = [b["mask"].shape for b in batches] == [b["mask"].shape for b in base_batches]
                view = _target_view(model, batches, target)
                assert view["seen"] == reference["seen"], (target, name)
                assert view["gap"] == reference["gap"], (target, name)
                assert view["position"] == reference["position"], (target, name)
                if same_shapes:
                    assert view["score"] == reference["score"], (target, name)  # bit for bit
                else:
                    # A sibling can widen or narrow the padded batch; masked padding keys then only change the
                    # float32 summation order (observed: at most one ulp, 1.2e-7).
                    assert view["score"] == pytest.approx(reference["score"], abs=2e-7), (target, name)
                    moved_width += 1
                checked += 1
    assert checked > 100 and moved_width  # power: some variants changed the padded batch width


def test_the_sibling_test_detects_row_count_chunks(ties):
    """Power check: with tiebreak (row-count chunks, positional mask) a lower-id sibling does change what the
    target sees, so the guarantee above is not vacuous."""
    model, dataset = _model(ties, "tiebreak")
    earlier = [dict(account="a", second=s, id=_ident("a", s, 500), f1=0.1 * s) for s in (1, 2, 3, 4, 5)]
    target = dict(account="a", second=50, id=_ident("a", 50, 500), f1=0.3)
    sibling = dict(account="a", second=50, id=_ident("a", 50, 100), f1=0.2)
    alone = _scores(model, _batches(dataset, _frame(earlier + [target])))
    pushed = _scores(model, _batches(dataset, _frame(earlier + [sibling, target])))
    assert pushed[target["id"]] != pytest.approx(alone[target["id"]], abs=1e-6)


# --------------------------------------------------------------------------- chunk boundaries
def _chunks(batches):
    """Real rows of every chunk, in chunk order: lists of (account, id, ns time)."""
    out = []
    for batch in batches:
        for ids, accounts, times, real in zip(batch["meta_seq"][ID], batch["meta_seq"][ACCOUNT],
                                              batch["time_seq"].numpy(), batch["mask"].numpy()):
            out.append(list(zip(accounts[real], ids[real], times[real])))
    return out


@pytest.mark.parametrize("history_len", [0, 1, 5])
def test_strict_chunks_are_cut_only_between_seconds_with_up_to_h_plus_1_seconds(ties, history_len):
    rng = np.random.default_rng(7 + history_len)
    dataset = _dataset(ties, "strict", history_len=history_len)
    for _ in range(20):
        frame = _frame(_random_rows(rng, accounts=4))
        chunks = _chunks(_batches(dataset, frame))
        assert sorted(i for c in chunks for _, i, _ in c) == sorted(frame[ID])  # every row exactly once
        by_account = {}
        for chunk in chunks:
            assert len({a for a, _, _ in chunk}) == 1
            by_account.setdefault(chunk[0][0], []).append(chunk)
        for account_chunks in by_account.values():
            seconds = [[t for _, _, t in c] for c in account_chunks]
            for k, chunk_seconds in enumerate(seconds):
                assert chunk_seconds == sorted(chunk_seconds)
                distinct = len(set(chunk_seconds))
                # Full chunks hold exactly H+1 seconds; only the account's last chunk may hold fewer.
                assert distinct == history_len + 1 or (k == len(seconds) - 1 and distinct <= history_len + 1)
                if k:
                    assert max(seconds[k - 1]) < min(chunk_seconds)  # the boundary falls between two seconds


def test_chunk_spans_strict_by_distinct_seconds_and_tiebreak_by_rows(ties):
    seconds = np.array([1, 1, 1, 2, 3, 3, 4, 5, 6, 6, 6, 7, 8])
    strict, tiebreak = _dataset(ties, "strict"), _dataset(ties, "tiebreak")
    # Seconds 1..6 form chunk one (11 rows); 7, 8 the account's last chunk.
    assert strict._chunk_spans(seconds) == [(0, 11), (11, 13)]
    assert tiebreak._chunk_spans(seconds) == [(0, 6), (6, 12), (12, 13)]  # unchanged: every T rows
    assert strict._chunk_spans(np.array([9] * 20)) == [(0, 20)]
    assert _dataset(ties, "strict", history_len=0)._chunk_spans(seconds) == [
        (0, 3), (3, 4), (4, 6), (6, 7), (7, 8), (8, 11), (11, 12), (12, 13)]
    with pytest.raises(ValueError, match="chronological"):
        strict._chunk_spans(np.array([2, 1]))


def test_strict_chunks_are_keyed_on_whole_seconds_not_sub_second_timestamps(ties, monkeypatch):
    """Review R3: chunks are cut between whole seconds. 6.2 s and 6.7 s are one whole second, so they share a
    chunk; a builder keyed on the nanosecond timestamp would cut between them (first six rows, then 6.7 and 7.0)."""
    model, dataset = _model(ties)
    seconds = (1.0, 2.0, 3.0, 4.0, 5.0, 6.2, 6.7, 7.0)
    rows = [dict(account="s", second=s, id=_ident("s", int(s * 10), 100), f1=0.1 * k) for k, s in enumerate(seconds)]
    frame = _frame(rows)
    ids = [r["id"] for r in rows]

    passed = []
    original = type(dataset)._chunk_spans

    def recording(self, keys):
        passed.append(np.asarray(keys).copy())
        return original(self, keys)

    monkeypatch.setattr(type(dataset), "_chunk_spans", recording)
    batches = _batches(dataset, frame)
    monkeypatch.undo()
    # _chunk_spans receives the account's sorted whole seconds, never the nanosecond order key.
    whole = frame["transaction_dttm"].to_numpy(dtype="datetime64[s]").astype("int64")
    assert len(passed) == 1 and passed[0].dtype.kind == "i"
    assert np.array_equal(passed[0], whole) and passed[0][5] == passed[0][6]
    assert [[i for _, i, _ in chunk] for chunk in _chunks(batches)] == [ids[:7], ids[7:]]
    late = _target_view(model, batches, ids[6])  # 6.7 s
    assert ids[5] in late["seen"]  # 6.2 s is strictly earlier in nanoseconds, so it is visible
    assert set(late["seen"]) == set(ids[:7])
    assert late["gap"] == 0.0  # the latest strictly-earlier timestamp (6.2 s) is in the same whole second
    assert late["position"] == HISTORY_LEN  # six strictly earlier rows, clamped to H = 5
    early = _target_view(model, batches, ids[5])  # 6.2 s does not see 6.7 s
    assert ids[6] not in early["seen"] and early["gap"] == pytest.approx(np.log1p(1))
    assert dataset._chunk_spans(np.array([1, 2, 3, 4, 5, 6, 6, 7])) == [(0, 7), (7, 8)]
    assert dataset._chunk_spans(np.array([1, 2, 3, 4, 5, 6, 7, 7])) == [(0, 6), (6, 8)]
    assert dataset._chunk_spans(np.array([6, 6, 6, 6, 6, 6, 6, 7])) == [(0, 8)]


# --------------------------------------------------------------------------- wide chunks
def test_an_account_whose_single_second_holds_more_than_h_plus_1_rows(ties):
    model, dataset = _model(ties)
    one_second = [dict(account="m", second=5, id=_ident("m", 5, 100 + k), f1=0.1 * k) for k in range(9)]
    clamp = ([dict(account="z", second=1, id=_ident("z", 1, 100))]
             + [dict(account="z", second=2, id=_ident("z", 2, 100 + k), f1=0.2 * k) for k in range(8)]
             + [dict(account="z", second=3, id=_ident("z", 3, 100), f1=2.0)])
    batches = _batches(dataset, _frame(one_second + clamp))
    chunks = _chunks(batches)
    assert [len(c) for c in chunks] == [9, 10]  # one chunk per account: 1 and 3 distinct seconds
    assert batches[0]["mask"].shape == (2, 10)  # padded to the widest chunk in the batch, wider than T
    gaps = _gaps_by_id(batches)
    assert all(gaps[r["id"]] == 0.0 for r in one_second)  # nothing strictly earlier in the chunk
    assert gaps[clamp[1]["id"]] == pytest.approx(np.log1p(1)) and gaps[clamp[-1]["id"]] == pytest.approx(np.log1p(1))
    index = _position_indices(model, batches[0])
    assert index[0, :9].tolist() == [0] * 9
    # Strictly-earlier counts 0, 1 x 8, then 9 for the last row, clamped to H = 5.
    assert index[1].tolist() == [0] + [1] * 8 + [HISTORY_LEN]
    allowed = ~torch.isinf(model._build_causal_mask(
        "cpu", torch.cat([torch.zeros(2, 1, dtype=torch.bool), ~batches[0]["mask"]], dim=1),
        batches[0]["time_seq"]))[0, 1:, 1:]
    assert torch.equal(allowed[:9, :9], torch.eye(9, dtype=torch.bool))  # a same-second row sees only itself
    scores = _scores(model, batches)
    assert sorted(scores) == sorted(r["id"] for r in one_second + clamp)
    # Each of the nine same-second rows is scored from its own inputs only.
    alone = _scores(model, _batches(dataset, _frame([one_second[4]])))
    assert scores[one_second[4]["id"]] == pytest.approx(alone[one_second[4]["id"]], abs=2e-7)


def test_padding_to_the_widest_chunk_and_one_prediction_per_row(ties):
    model, dataset = _model(ties)
    rows = [dict(account="w", second=s, id=_ident("w", s, 100 + n), f1=0.1 * n, label=n % 2)
            for n, s in enumerate((1, 2, 2, 2, 3, 3, 4, 5, 6, 6))]  # 6 seconds, 10 rows: one chunk
    rows += [dict(account="x", second=s, id=_ident("x", s, 100), f1=-0.3, label=1) for s in (7, 8, 9)]
    batches = _batches(_dataset(ties, "strict", batch_size=2), _frame(rows))
    assert len(batches) == 1
    batch = batches[0]
    real = batch["mask"]
    assert real.shape == (2, 10) and real.sum(1).tolist() == [10, 3]
    pad = ~real
    assert (batch["target_seq"][pad] == -100).all() and (batch["time_seq"][pad] == 0).all()
    assert (batch["continuous"][pad] == 0).all() and (batch["categorical"][pad] == 0).all()
    assert all(v is None for v in batch["meta_seq"][ID][pad.numpy()])
    assert torch.equal(batch["target_seq"] != -100, real)
    # Padding isolation in a batch wider than T.
    with torch.no_grad():
        reference = model(batch)[real]
        altered = dict(batch, continuous=batch["continuous"].clone(), time_seq=batch["time_seq"].clone())
        altered["continuous"][pad] = 5000.0
        altered["time_seq"][pad] = -(10 ** 12)
        torch.testing.assert_close(model(altered)[real], reference)
    # One target and loss term per real row; finite gradients; no gradient reaches padding.
    model.train()
    model.log = lambda *args, **kwargs: None
    batch["continuous"].requires_grad_()
    logits, labels, loss = model._step(batch, "train")
    assert len(labels) == len(rows) == logits.shape[0]
    assert sorted(labels.tolist()) == sorted(r["label"] for r in rows)
    loss.backward()
    assert torch.isfinite(loss) and torch.count_nonzero(batch["continuous"].grad[pad]) == 0
    model.eval()
    assert sorted(_scores(model, batches)) == sorted(r["id"] for r in rows)


def test_uniform_width_batches_are_not_copied_and_tiebreak_keeps_width_t(ties):
    """Tiebreak chunks (and every strict batch without wide chunks) keep the fixed width T; the padding step
    returns the very same chunk tuples, so those batches are built exactly as before the amendment."""
    frame = ties["frame"]
    tiebreak = _dataset(ties, "tiebreak")
    windows = list(tiebreak._windows_for_file(*tiebreak._encode_file(frame)))
    assert all(w[2].shape == (T,) for w in windows)
    sample = windows[:2]
    assert tiebreak._pad_chunks(sample) is sample
    assert all(b["mask"].shape[1] == T for b in _batches(tiebreak, frame))
    strict = _dataset(ties, "strict")
    wide = list(strict._windows_for_file(*strict._encode_file(frame)))
    assert [w[2].shape[0] for w in wide] == [9, T, 9]  # a and c: 9 rows; b: 3 rows padded to T
    assert [int(w[2].sum()) for w in wide] == [9, 3, 9]


# --------------------------------------------------------------------------- scorer and trainer
def test_scorer_and_trainer_build_the_same_chunks(ties, tmp_path, monkeypatch):
    rng = np.random.default_rng(5)
    frame = _frame(_random_rows(rng, accounts=5) + [
        dict(account="big", second=3, id=_ident("big", 3, 100 + k), f1=0.1 * k) for k in range(8)])
    path = tmp_path / "ties" / "part_1.parquet"
    path.parent.mkdir()
    frame.to_parquet(path, index=False)
    cfg = ties["cfg"]
    cfg.eval.base = str(path.parent)
    model, _ = _model(ties)

    built = {}

    class Recording(scorer.SequenceBuilder):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            built["scorer"] = self

    monkeypatch.setattr(scorer, "SequenceBuilder", Recording)
    checkpoint_path = tmp_path / "strict.ckpt"
    checkpoint = {"state_dict": model.state_dict()}
    model.on_save_checkpoint(checkpoint)
    torch.save(checkpoint, checkpoint_path)
    cfg.eval.checkpoint = str(checkpoint_path)
    config_path = tmp_path / "score.yaml"
    OmegaConf.save(cfg, config_path)
    monkeypatch.setattr(scorer, "make_s3_filesystem", lambda *args: None)
    monkeypatch.setattr(scorer.torch.cuda, "is_available", lambda: False)
    monkeypatch.setattr("sys.argv", ["score_sequential", "--config", str(config_path)])
    scorer.main()

    files = [str(path)]
    train_loader = trainer._make_loader(cfg, files, ties["artifacts"], ties["features"], ties["dt"], True, 1, 0)
    eval_loader = trainer._make_loader(cfg, files, ties["artifacts"], ties["features"], ties["dt"], False, 1, 0)
    for loader in (train_loader, eval_loader):
        assert loader.dataset.history_time_order == built["scorer"].history_time_order == "strict"
    scorer_side, validation_side, training_side = list(built["scorer"]), list(eval_loader), list(train_loader)

    def signatures(batch):
        """Per real row: (time, inputs). The training loader carries no ids, so rows are matched by content."""
        return [[(int(t), tuple(c.tolist()), tuple(k.tolist()))
                 for t, c, k, r in zip(times, cont, cat, real) if r]
                for times, cont, cat, real in zip(batch["time_seq"], batch["continuous"], batch["categorical"],
                                                  batch["mask"].numpy())]

    def chunk_set(batches):
        return sorted(tuple(chunk) for batch in batches for chunk in signatures(batch))

    assert chunk_set(scorer_side) == chunk_set(validation_side) == chunk_set(training_side)
    assert len({row for chunk in chunk_set(scorer_side) for row in chunk}) == len(frame)
    assert max(b["mask"].shape[1] for b in scorer_side) >= 8 > T  # wide chunks, e.g. the "big" one-second account
    metrics = json.loads(Path(cfg.eval.metrics_output).read_text())
    assert metrics["sequence_contract"]["all_position_time_policy"]["chunking"] == "distinct_seconds"
    output = pq.read_table(metrics["predictions_path"]).to_pandas()
    assert len(output) == len(frame) and output[ID].is_unique
    # The scored output equals the model on the training-side batches (shuffled ones included), row by row.
    by_id = {i: sig for b in scorer_side for ids, sigs, real in zip(b["meta_seq"][ID], signatures(b), b["mask"].numpy())
             for i, sig in zip(ids[real], sigs)}
    for batches in (validation_side, training_side):
        expected = {}
        with torch.no_grad():
            for batch in batches:
                probabilities = torch.softmax(model(batch), dim=-1)[..., 1]
                for sigs, p, real in zip(signatures(batch), probabilities, batch["mask"]):
                    expected.update(zip(sigs, p[real].tolist()))
        for row in output.itertuples():
            assert row.score == pytest.approx(expected[by_id[getattr(row, ID)]], abs=1e-7)


# --------------------------------------------------------------------------- versioning
def test_a_strict_checkpoint_from_before_the_amendment_is_refused(ties):
    strict, _ = _model(ties, "strict")
    checkpoint = {"state_dict": strict.state_dict()}
    strict.on_save_checkpoint(checkpoint)
    policy = checkpoint["sequence_contract"]["all_position_time_policy"]
    assert checkpoint["sequence_contract"]["version"] == 2
    del policy["chunking"]  # the strict policy as written before the amendment (row-count chunks)
    policy["position_index"] = "count_of_strictly_earlier_real_rows_in_chunk"
    with pytest.raises(ValueError, match="sequence_contract mismatch"):
        strict.on_load_checkpoint(checkpoint)


# --------------------------------------------------------------------------- chunk width cap (review R1)
def _one_crowded_second(rows=9):
    return [dict(account="m", second=5, id=_ident("m", 5, 100 + k), f1=0.1 * k) for k in range(rows)] + [
        dict(account="n", second=s, id=_ident("n", s, 100)) for s in (1, 2, 3)]


def test_max_chunk_rows_raises_on_a_wider_chunk_and_never_truncates(ties):
    frame = _frame(_one_crowded_second())
    with pytest.raises(ValueError, match=r"'m' holds 9 rows > max_chunk_rows=8; no row is dropped"):
        _batches(_dataset(ties, "strict", max_chunk_rows=8), frame)
    capped = _chunks(_batches(_dataset(ties, "strict", max_chunk_rows=9), frame))
    assert capped == _chunks(_batches(_dataset(ties, "strict"), frame))  # a cap that admits the data changes nothing
    assert sorted(len(c) for c in capped) == [3, 9]


def test_max_chunk_rows_is_all_position_only_and_at_least_t(ties):
    with pytest.raises(ValueError, match="at least history_len"):
        _dataset(ties, "strict", max_chunk_rows=T - 1)
    with pytest.raises(ValueError, match="at least history_len"):
        _dataset(ties, "strict", max_chunk_rows=8.5)
    assert _dataset(ties, "strict", max_chunk_rows=T).max_chunk_rows == T
    single = dict(emit_target_seq=False, all_position_layout=None, time_delta_reference="target",
                  history_time_order="strict")
    assert _dataset(ties, **single).max_chunk_rows is None  # default B: no cap, unchanged
    with pytest.raises(ValueError, match="all-position chunks only"):
        _dataset(ties, max_chunk_rows=8, **single)


def test_training_and_scoring_loaders_read_max_chunk_rows_from_the_config(ties, tmp_path, monkeypatch):
    path = tmp_path / "crowded" / "part_1.parquet"
    path.parent.mkdir()
    _frame(_one_crowded_second()).to_parquet(path, index=False)
    cfg = ties["cfg"]
    model, _ = _model(ties)
    files = [str(path)]

    def loader():
        return trainer._make_loader(cfg, files, ties["artifacts"], ties["features"], ties["dt"], False, 1, 0)

    assert loader().dataset.max_chunk_rows is None  # the shipped config sets no cap
    cfg.sequence.max_chunk_rows = 9
    assert loader().dataset.max_chunk_rows == 9 and len(list(loader())) == 1
    cfg.sequence.max_chunk_rows = 8
    with pytest.raises(ValueError, match="max_chunk_rows=8"):
        list(loader())
    checkpoint = {"state_dict": model.state_dict()}
    model.on_save_checkpoint(checkpoint)
    torch.save(checkpoint, tmp_path / "strict.ckpt")
    cfg.eval.checkpoint = str(tmp_path / "strict.ckpt")
    cfg.eval.base = str(path.parent)
    OmegaConf.save(cfg, tmp_path / "score.yaml")
    monkeypatch.setattr(scorer, "make_s3_filesystem", lambda *args: None)
    monkeypatch.setattr(scorer.torch.cuda, "is_available", lambda: False)
    monkeypatch.setattr("sys.argv", ["score_sequential", "--config", str(tmp_path / "score.yaml")])
    with pytest.raises(ValueError, match="max_chunk_rows=8"):
        scorer.main()


def test_measure_chunk_widths_matches_the_builders_strict_chunks(ties):
    from YOUR_PACKAGE.phase4b.scripts.measure_chunk_widths import strict_chunk_widths, summarize

    rng = np.random.default_rng(31)
    for history_len in (0, 1, 5):
        dataset = _dataset(ties, "strict", history_len=history_len)
        for _ in range(10):
            frame = _frame(_random_rows(rng, accounts=4) + _one_crowded_second(int(rng.integers(1, 12))))
            built = sorted(len(c) for c in _chunks(_batches(dataset, frame)))
            widths, max_per_second = strict_chunk_widths(frame[ACCOUNT].to_numpy(), frame["transaction_dttm"],
                                                         history_len)
            assert sorted(widths.tolist()) == built
            assert max_per_second == int(frame.groupby([ACCOUNT, "transaction_dttm"]).size().max())
    # The review's example: batch 256, 8 heads and one 1000-row second give a mask of about 8.2 GB (7.6 GiB).
    summary = summarize([1000, 6, 3], 1000, 5, batch_size=256, num_heads=8)
    assert summary["max_chunk_rows"] == 1000 and summary["chunks_wider_than_T"] == 1
    assert summary["mask_gib_at_max_width"] * 2 ** 30 == 256 * 8 * 1001 ** 2 * 4


# --------------------------------------------------------------------------- model input checks (review R2)
def _narrow(batch, width):
    return {k: (v[:, :width] if isinstance(v, torch.Tensor) else v) for k, v in batch.items() if k != "meta_seq"}


def test_strict_model_refuses_narrow_batches_and_chunks_with_more_than_h_plus_1_seconds(ties):
    model, dataset = _model(ties)
    rows = [dict(account="s", second=s, id=_ident("s", s, 100)) for s in range(1, 8)]  # 7 distinct seconds
    batch = _batches(dataset, _frame(rows))[0]
    assert batch["mask"].shape[1] == T
    with torch.no_grad():
        model(batch)  # builder chunks of the model's own history_len are accepted
        with pytest.raises(ValueError, match="configured history_len"):
            model(_narrow(batch, T - 1))  # narrower than any builder chunk
    # A builder with a larger history_len puts H + 2 = 7 distinct seconds in one chunk of width 7.
    wider = _batches(_dataset(ties, "strict", history_len=HISTORY_LEN + 1), _frame(rows))[0]
    assert wider["mask"].shape[1] == T + 1 and int(wider["mask"][0].sum()) == T + 1
    with torch.no_grad(), pytest.raises(ValueError, match="more than history_len \\+ 1 distinct seconds"):
        model(wider)
    # The same width is accepted when its extra rows share a second (ties, not extra seconds).
    tied = _batches(dataset, _frame(rows[:6] + [dict(account="s", second=6, id=_ident("s", 6, 200))]))[0]
    assert tied["mask"].shape[1] == T + 1 and int(tied["mask"][0].sum()) == T + 1
    with torch.no_grad():
        model(tied)


def test_distinct_second_count_floors_pre_1970_times_like_the_builder(ties):
    """-1.0 s and -0.9 s are one whole second for numpy's datetime64[ns] -> [s] (floor); truncation would make
    them two and refuse a valid chunk of exactly H + 1 seconds."""
    model, dataset = _model(ties)
    seconds = (-1.0, -0.9, 1, 2, 3, 4, 5)
    rows = [dict(account="p", second=s, id=_ident("p", k, 100)) for k, s in enumerate(seconds)]
    batches = _batches(dataset, _frame(rows, base=pd.Timestamp("1970-01-01")))
    assert [len(c) for c in _chunks(batches)] == [7]  # one chunk: 6 distinct whole seconds
    times = batches[0]["time_seq"][0]
    assert len(set(torch.div(times, 10 ** 9, rounding_mode="trunc").tolist())) == T + 1
    with torch.no_grad():
        model(batches[0])
