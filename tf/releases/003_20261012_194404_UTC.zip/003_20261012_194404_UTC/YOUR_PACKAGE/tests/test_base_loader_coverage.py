"""Complete row coverage through Ya's actual streaming/sequential loader factories."""

import importlib
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import torch
from omegaconf import OmegaConf

from fraud.data.datetime_features import DatetimeConfig, derive_datetime_features
from fraud.data.feature_list import load_feature_list
from fraud.data.preprocessing import PreprocessingArtifacts


@pytest.mark.parametrize("kind", ["streaming", "sequential"])
@pytest.mark.parametrize("workers", [0, 2, 4])
@pytest.mark.parametrize("seed", [42, 2026])
@pytest.mark.parametrize("shuffle", [False, True], ids=["evaluation", "training"])
def test_base_training_factories_cover_every_target(tmp_path, kind, workers, seed, shuffle):
    """Unequal files, independent worker RNGs and fresh epochs retain every row once."""
    ids = np.arange(29)
    df = pd.DataFrame({
        "transaction_dttm": pd.date_range("2024-01-01", periods=len(ids), freq="h"),
        "Nmap_account_reference_xid": 0,
        "fi_transaction_id": ids.astype(str),
        "f1": ids.astype(float),  # Decode this to verify target identity after transform.
        "c1": np.where(ids % 2, "A", "B"),
        "frd_tag": ids % 2,
    })
    csv_path = tmp_path / "predictors.csv"
    csv_path.write_text(
        "feature,type,source,version\n"
        "f1,continuous,raw,1\n"
        "c1,categorical,raw,1\n"
        "hour,categorical,derived:transaction_dttm,1\n"
    )
    features = load_feature_list(str(csv_path), version=1)
    dt_config = DatetimeConfig(fields=["hour"])
    transformed, _, _ = derive_datetime_features(df, dt_config)
    artifacts = PreprocessingArtifacts()
    for col in features.continuous:
        artifacts.fit_feature(col, transformed[col], "continuous")
    for col in features.categorical:
        artifacts.fit_feature(col, transformed[col], "categorical")
    files = []
    for file_index, rows in enumerate(np.array_split(ids, 10)):
        path = tmp_path / f"part_{file_index}.parquet"
        frame = df.iloc[rows].copy()
        frame["Nmap_account_reference_xid"] = file_index  # Account stays in one file.
        frame.to_parquet(path, index=False)
        files.append(str(path))

    module = importlib.import_module(f"YOUR_PACKAGE.base.scripts.train_{kind}")
    cfg = OmegaConf.load(Path(__file__).resolve().parents[2] / "fraud" / "configs" / f"{kind}.yaml")
    cfg.s3.cred_path = None
    cfg.training.batch_size = 2
    cfg.training.read_batch_size = 4
    cfg.training.buffer_windows = 4
    if kind == "streaming":
        loader = module._make_loader(cfg, files, artifacts, features, dt_config,
                                     shuffle, shuffle, workers)
    else:
        cfg.sequence.history_len = 2
        loader = module._make_loader(cfg, files, artifacts, features, dt_config,
                                     shuffle, 1, workers)
    loader.generator = torch.Generator().manual_seed(seed)
    encoding = artifacts.features["f1"]
    for _ in range(2):
        seen = []
        for batch in loader:
            encoded = batch["continuous"][:, 0] if kind == "streaming" else batch["continuous"][:, -1, 0]
            recovered = np.rint(encoded.numpy() * encoding["std"] + encoding["mean"]).astype(int)
            assert batch["target"].reshape(-1).tolist() == (recovered % 2).tolist()
            seen.extend(recovered.tolist())
        assert sorted(seen) == ids.tolist()
