"""Score ties, row alignment and raw single-model reporting in the ensemble path."""

import itertools
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from sklearn.metrics import average_precision_score, roc_auc_score

from YOUR_PACKAGE.scoring import ensemble


def _frames():
    y = np.array([0, 0, 1, 1, 0, 1])
    first = pd.DataFrame({"id": np.arange(6), "target": y,
                          "score": [0.2, 0.2, 0.2, 0.8, 0.8, 0.8]})
    second = pd.DataFrame({"id": np.arange(6), "target": y,
                           "score": [0.1, 0.4, 0.4, 0.4, 0.7, 0.7]})
    return first, second


def test_constant_scores_stay_chance_under_every_row_permutation():
    """Arbitrary tie order must not turn a constant predictor into a perfect one."""
    y = np.array([0, 0, 1, 1])
    scores = np.full(4, 0.3)
    for permutation in itertools.permutations(range(4)):
        idx = np.array(permutation)
        ranks = ensemble._rankpct(scores[idx])
        assert np.unique(ranks).size == 1
        assert average_precision_score(y[idx], ranks) == pytest.approx(0.5)
        assert roc_auc_score(y[idx], ranks) == pytest.approx(0.5)


def test_average_ranks_preserve_ties_and_original_metric_ordering():
    np.testing.assert_array_equal(ensemble._rankpct(np.array([2, 2, 4, 1])),
                                  [0.5, 0.5, 1.0, 0.0])
    first, _ = _frames()
    ranks = ensemble._rankpct(first.score.to_numpy())
    assert average_precision_score(first.target, ranks) == pytest.approx(
        average_precision_score(first.target, first.score))
    assert roc_auc_score(first.target, ranks) == pytest.approx(
        roc_auc_score(first.target, first.score))


def test_blend_and_metrics_are_invariant_to_input_row_order(monkeypatch):
    first, second = _frames()
    stored = {"a": first, "b": second}
    monkeypatch.setattr(ensemble, "_read", lambda path, fs: stored[path])
    base, matrix, y = ensemble._align(["a", "b"], ["a", "b"], "id", "target", "score", None)
    weights, ap = ensemble._optimize_weights(matrix, y, n_samples=24, seed=7)
    expected = pd.Series(matrix @ weights, index=base.id).sort_index()
    expected_auc = roc_auc_score(y, matrix @ weights)
    for seed in range(6):
        stored["a"] = first.sample(frac=1, random_state=seed)
        stored["b"] = second.sample(frac=1, random_state=seed + 19)
        reordered, new_matrix, new_y = ensemble._align(
            ["a", "b"], ["a", "b"], "id", "target", "score", None)
        new_weights, new_ap = ensemble._optimize_weights(new_matrix, new_y, n_samples=24, seed=7)
        actual = pd.Series(new_matrix @ new_weights, index=reordered.id).sort_index()
        np.testing.assert_allclose(actual, expected, rtol=0, atol=1e-15)
        assert new_ap == pytest.approx(ap)
        assert roc_auc_score(new_y, new_matrix @ new_weights) == pytest.approx(expected_auc)


@pytest.mark.parametrize("bad_case,expected", [
    ("duplicate_first", "non-null and unique"),
    ("duplicate_second", "non-null and unique"),
    ("null_id", "non-null and unique"),
    ("missing_row", "cohort IDs differ"),
    ("different_id", "cohort IDs differ"),
    ("label_mismatch", "labels disagree"),
    ("nonbinary_label", "binary values"),
    ("null_label", "binary values"),
    ("nan_score", "scores must be finite"),
    ("inf_score", "scores must be finite"),
    ("empty", "cohort is empty"),
])
def test_alignment_rejects_invalid_comparisons(monkeypatch, bad_case, expected):
    first, second = _frames()
    if bad_case == "duplicate_first":
        first.loc[1, "id"] = first.loc[0, "id"]
    elif bad_case == "duplicate_second":
        second.loc[1, "id"] = second.loc[0, "id"]
    elif bad_case == "null_id":
        second.loc[1, "id"] = np.nan
    elif bad_case == "missing_row":
        second = second.iloc[:-1]
    elif bad_case == "different_id":
        second.loc[1, "id"] = 1000
    elif bad_case == "label_mismatch":
        second.loc[1, "target"] = 1
    elif bad_case == "nonbinary_label":
        second["target"] = second["target"].astype(float)
        second.loc[1, "target"] = 0.5
    elif bad_case == "null_label":
        second.loc[1, "target"] = np.nan
    elif bad_case == "nan_score":
        second.loc[1, "score"] = np.nan
    elif bad_case == "inf_score":
        second.loc[1, "score"] = np.inf
    elif bad_case == "empty":
        second = second.iloc[:0]
    stored = {"a": first, "b": second}
    monkeypatch.setattr(ensemble, "_read", lambda path, fs: stored[path])
    with pytest.raises(ValueError, match=expected):
        ensemble._align(["a", "b"], ["a", "b"], "id", "target", "score", None)


def test_singles_report_original_scores_even_if_blend_transform_changes(monkeypatch, capsys):
    """A transform defect must not silently rewrite individual model metrics."""
    signal = pd.DataFrame({"id": [0, 1, 2, 3], "target": [0, 0, 1, 1],
                           "score": [0.1, 0.1, 0.9, 0.9]})
    monkeypatch.setattr(ensemble, "_read", lambda path, fs: signal.assign(
        id=signal.id + (10 if Path(path).name == "test" else 0)))
    monkeypatch.setattr(ensemble, "make_s3_filesystem", lambda cred: None)
    monkeypatch.setattr(ensemble, "_rankpct", lambda scores: np.full(len(scores), 0.5))
    monkeypatch.setattr(ensemble, "_optimize_weights", lambda mat, y: (np.ones(1), 0.5))
    monkeypatch.setattr(sys, "argv", ["ensemble.py", "--names", "signal",
                                     "--val", "val", "--test", "test",
                                     "--id", "id", "--target", "target"])
    ensemble.main()
    lines = [line.split() for line in capsys.readouterr().out.splitlines()]
    assert ["signal", "1.0000", "1.0000"] in lines
    assert ["ENSEMBLE", "0.5000", "0.5000"] in lines


def test_optimizer_includes_exact_single_model_candidates():
    y = np.array([0, 0, 1, 1])
    mat = np.column_stack([[0, 0, 1, 1], [1, 1, 0, 0]])
    weights, ap = ensemble._optimize_weights(mat, y, n_samples=0)
    assert ap == 1.0
    np.testing.assert_array_equal(weights, [1.0, 0.0])


@pytest.mark.parametrize("overlap", [False, True])
def test_real_local_cli_is_disjoint_and_preserves_existing_output(tmp_path, monkeypatch, overlap):
    first, second = _frames()
    paths = []
    for split in ("val", "test"):
        for name, df in (("a", first), ("b", second)):
            frame = df.copy()
            if split == "test" and not overlap:
                frame["id"] += 10
            path = tmp_path / f"{split}_{name}.parquet"
            frame.to_parquet(path, index=False)
            paths.append(path)
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(sys, "argv", ["ensemble", "--names", "a", "b", "--val",
                                     str(paths[0]), str(paths[1]), "--test", str(paths[2]), str(paths[3]),
                                     "--id", "id", "--target", "target", "--pred-out", "new-results"])

    def no_remote(*args, **kwargs):
        raise AssertionError("Local CLI must not initialize S3")

    monkeypatch.setattr(ensemble, "make_s3_filesystem", no_remote)
    original_optimizer = ensemble._optimize_weights
    monkeypatch.setattr(ensemble, "_optimize_weights", lambda mat, y: original_optimizer(mat, y, n_samples=8))
    if overlap:
        with pytest.raises(ValueError, match="IDs overlap"):
            ensemble.main()
        assert not (tmp_path / "new-results").exists()
    else:
        ensemble.main()
        out = tmp_path / "new-results/ensemble_preds.parquet"
        result = pd.read_parquet(out)
        assert result.id.tolist() == list(range(10, 16))
        old = out.read_bytes()
        with pytest.raises(SystemExit):
            ensemble.main()
        assert out.read_bytes() == old


def test_alignment_rejects_infinite_ids_even_when_other_rows_are_strings(monkeypatch):
    first, second = _frames()
    first["id"] = first.id.astype(str)
    second["id"] = second.id.astype(str)
    first.loc[0, "id"] = float("inf")
    monkeypatch.setattr(ensemble, "_read", lambda path, fs: {"a": first, "b": second}[path])
    with pytest.raises(ValueError, match="IDs must be finite"):
        ensemble._align(["a", "b"], ["a", "b"], "id", "target", "score", None)


def test_split_id_type_mismatch_cannot_hide_validation_overlap(monkeypatch):
    first, _ = _frames()
    monkeypatch.setattr(ensemble, "_read", lambda path, fs: first.assign(
        id=first.id.astype(str) if Path(path).name == "test" else first.id))
    monkeypatch.setattr(sys, "argv", ["ensemble", "--names", "a", "--val", "val", "--test", "test",
                                     "--id", "id", "--target", "target"])
    with pytest.raises(ValueError, match="compatible identifier types"):
        ensemble.main()


def test_unsafe_float_ids_cannot_merge_with_distinct_large_integers(monkeypatch):
    base = 2 ** 53
    first = pd.DataFrame({"id": [base + 1, base + 3], "target": [0, 1], "score": [0.1, 0.9]})
    second = first.assign(id=[float(base), float(base + 4)])
    monkeypatch.setattr(ensemble, "_read", lambda path, fs: {"a": first, "b": second}[path])
    with pytest.raises(ValueError, match="unsafe floating identifier"):
        ensemble._align(["a", "b"], ["a", "b"], "id", "target", "score", None)


@pytest.mark.parametrize("match", [False, True])
def test_large_signed_unsigned_id_joins_are_exact(monkeypatch, match):
    base = 2 ** 63
    first = pd.DataFrame({"id": np.array([base - 3, base - 1], dtype=np.int64),
                          "target": [0, 1], "score": [0.1, 0.9]})
    second = first.assign(id=np.array([base - 3, base - 1] if match else [base - 4, base - 2], dtype=np.uint64))
    monkeypatch.setattr(ensemble, "_read", lambda path, fs: {"a": first, "b": second}[path])
    if not match:
        with pytest.raises(ValueError, match="cohort IDs differ"):
            ensemble._align(["a", "b"], ["a", "b"], "id", "target", "score", None)
    else:
        aligned, _, _ = ensemble._align(["a", "b"], ["a", "b"], "id", "target", "score", None)
        assert aligned.id.tolist() == [base - 3, base - 1]


@pytest.mark.parametrize("custom_group", [False, True])
def test_ensemble_parquet_can_join_grouped_leaderboard(tmp_path, monkeypatch, custom_group):
    from YOUR_PACKAGE.scoring import leaderboard

    group = "account" if custom_group else "Nmap_account_reference_xid"
    first, second = _frames()
    paths = []
    for split in ("val", "test"):
        for name, frame in (("a", first), ("b", second)):
            df = frame.assign(**{group: [37389549.0, 2.0, 37389549.0, 2.0, 3.0, 3.0]})
            if split == "test":
                df["id"] += 10
            path = tmp_path / f"{split}_{name}.parquet"
            df.sample(frac=1, random_state=3 if name == "a" else 5).to_parquet(path, index=False)
            paths.append(str(path))
    out = tmp_path / "ensemble"
    argv = ["ensemble", "--names", "a", "b", "--val", *paths[:2], "--test", *paths[2:],
            "--id", "id", "--target", "target", "--pred-out", str(out)]
    if custom_group:
        argv.extend(["--group", group])
    monkeypatch.setattr(sys, "argv", argv)
    optimizer = ensemble._optimize_weights
    monkeypatch.setattr(ensemble, "_optimize_weights", lambda mat, y: optimizer(mat, y, n_samples=8))
    ensemble.main()
    predictions = pd.read_parquet(out / "ensemble_preds.parquet")
    assert predictions[group].tolist() == [37389549.0, 2.0, 37389549.0, 2.0, 3.0, 3.0]
    leaderboard_csv = tmp_path / "leaderboard.csv"
    monkeypatch.setattr(sys, "argv", ["leaderboard", "--model", f"single={paths[2]}",
                                     "--model", f"blend={out}", "--id", "id", "--target", "target",
                                     "--group", group, "--bootstrap", "12", "--out", str(leaderboard_csv)])
    leaderboard.main()
    rows = pd.read_csv(leaderboard_csv)
    assert set(rows.model) == {"single", "blend"}
    assert (rows.bootstrap_unit == f"group:{group}").all()
    assert (rows.bootstrap_units == 3).all()


@pytest.mark.parametrize("case", ["different_group", "partial_group", "required_missing", "null_group"])
def test_ensemble_rejects_ambiguous_or_missing_group_mappings(monkeypatch, case):
    first, second = _frames()
    group = "Nmap_account_reference_xid"
    first[group] = ["a", "a", "b", "b", "c", "c"]
    second[group] = first[group].copy()
    required_group = None
    if case == "different_group":
        second.loc[0, group] = "wrong"
    elif case == "partial_group":
        second.drop(columns=group, inplace=True)
    elif case == "required_missing":
        required_group = "custom_account"
    else:
        second.loc[0, group] = None
    monkeypatch.setattr(ensemble, "_read", lambda path, fs: {"a": first, "b": second}[path])
    with pytest.raises(ValueError):
        ensemble._align(["a", "b"], ["a", "b"], "id", "target", "score", None, required_group)


def test_group_can_be_transaction_id_without_losing_join_key(monkeypatch):
    first, second = _frames()
    monkeypatch.setattr(ensemble, "_read", lambda path, fs: {"a": first, "b": second}[path])
    aligned, _, _ = ensemble._align(["a", "b"], ["a", "b"], "id", "target", "score", None, "id")
    assert aligned.id.tolist() == first.id.tolist()
