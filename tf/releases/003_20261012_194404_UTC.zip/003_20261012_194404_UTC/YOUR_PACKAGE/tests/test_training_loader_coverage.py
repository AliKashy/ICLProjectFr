"""Regression coverage through both real training loader factories, using local files."""

import importlib
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import torch
from omegaconf import OmegaConf

from fraud.data.datetime_features import DatetimeConfig
from fraud.data.feature_list import load_feature_list
from YOUR_PACKAGE.tests.test_sequence_builder import (
    DATETIME_FIELDS,
    _fit_artifacts,
    _write_predictors,
)

ROOT = Path(__file__).resolve().parents[2]


@pytest.mark.parametrize(
    "phase,config_name",
    [("phase4a", "sequential.yaml"), ("phase4b", "sequential_hier.yaml")],
)
@pytest.mark.parametrize("workers", [0, 2, 4], ids=["0workers", "2workers", "4workers"])
@pytest.mark.parametrize("seed", [42, 2026], ids=["seed42", "seed2026"])
def test_training_loader_preserves_all_targets(tmp_path, phase, config_name, workers, seed):
    """Unequal files and multiple epochs must never omit or duplicate a target."""
    target_ids = np.arange(17)
    df = pd.DataFrame({
        "transaction_dttm": pd.date_range("2024-01-01", periods=17, freq="h"),
        "Nmap_account_reference_xid": target_ids,
        "fi_transaction_id": target_ids.astype(str),
        "f1": target_ids.astype(float),  # Recover the target ID after preprocessing.
        "f2": target_ids.astype(float),
        "c1": "A",
        "c2": "X",
        "frd_tag": target_ids % 2,
    })
    features = load_feature_list(_write_predictors(tmp_path), version=1)
    dt_config = DatetimeConfig(fields=DATETIME_FIELDS, encoding="categorical", is_weekend=False)
    artifacts = _fit_artifacts(df, features, dt_config)
    files = []
    for i, rows in enumerate(np.array_split(target_ids, 10)):
        path = tmp_path / f"part_{i}.parquet"
        df.iloc[rows].to_parquet(path, index=False)
        files.append(str(path))

    cfg = OmegaConf.load(ROOT / "YOUR_PACKAGE" / phase / "configs" / config_name)
    cfg.s3.cred_path = None
    cfg.data.target_col = "frd_tag"
    cfg.data.account_col = "Nmap_account_reference_xid"
    cfg.data.order_col = "transaction_dttm"
    cfg.data.tie_break_col = "fi_transaction_id"
    cfg.training.batch_size = 3
    cfg.training.buffer_windows = 4
    trainer = importlib.import_module(f"YOUR_PACKAGE.{phase}.scripts.train_sequential")
    loader = trainer._make_loader(
        cfg, files, artifacts, features, dt_config,
        shuffle=True, stride=1, num_workers=workers,
    )
    loader.generator = torch.Generator().manual_seed(seed)
    encoding = artifacts.features["f1"]
    for _ in range(2):
        seen = []
        for batch in loader:
            raw = batch["continuous"][:, -1, 0].numpy() * encoding["std"] + encoding["mean"]
            ids = np.rint(raw).astype(int)
            assert batch["target"].reshape(-1).tolist() == (ids % 2).tolist()
            seen.extend(ids.tolist())
        assert sorted(seen) == target_ids.tolist()
