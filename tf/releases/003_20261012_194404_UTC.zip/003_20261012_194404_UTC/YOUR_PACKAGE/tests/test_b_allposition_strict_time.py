"""V1 build item B9: the strict timing contract of all-position B (disjoint causal chunks).

Agreed on issue #7 and in DESIGN_V1_AFTER_RUN001.md section 6.3:
- a real position attends to itself and only to positions of its chunk whose timestamp is
  strictly earlier (never a same-second neighbour, never a later row); CLS and padding stay isolated;
- the time gap is log1p(seconds since the latest strictly-earlier timestamp in the chunk), 0 when none
  (times [10, 20, 20] give 0, 10, 10; the earlier previous-row rule gave 0, 10, 0);
- the timestamps reach the mask in training and scoring alike;
- the policy is versioned in sequence_contract, so a checkpoint of one policy is refused under the other;
- amendment (reviewer-model-data-1 B1, DESIGN_V1 6.3 (a) to (c)): the position index is the strictly-earlier
  count (clamped to H), strict chunks are cut only between whole seconds (up to H+1 distinct seconds each,
  batches padded to the widest chunk), and a same-second sibling never changes a row's inputs or score.

Run: PYTHONPATH=src:. python3 -m pytest -q -p no:cacheprovider YOUR_PACKAGE/tests/test_b_allposition_strict_time.py
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
import pytest
import torch
from omegaconf import OmegaConf

from fraud.data.datetime_features import DatetimeConfig
from fraud.data.feature_list import load_feature_list
from YOUR_PACKAGE.phase4b.factory import build_sequential_model, sequence_dataset_options
from YOUR_PACKAGE.phase4b.scripts import score_sequential as scorer
from YOUR_PACKAGE.phase4b.sequence_builder import SequenceBuilder
from YOUR_PACKAGE.phase4b.sequential_hier import FTTransformerHierModel
from YOUR_PACKAGE.tests.test_sequence_builder import DATETIME_FIELDS, _fit_artifacts, _write_predictors

ROOT = Path(__file__).resolve().parents[2]
ID = "fi_transaction_id"
ACCOUNT = "Nmap_account_reference_xid"
HISTORY_LEN = 5  # chunk length T = 6

# (account, seconds after the base time). Rows are listed in (account, time, id) order, so the
# tie-break id order equals the frame order. Chunks are noted as (strict | tiebreak): strict cuts only
# between seconds, up to 6 distinct seconds per chunk; tiebreak cuts every T = 6 rows.
LAYOUT = (
    [("a", t) for t in (10, 20, 20, 30, 30, 30)]   # strict: a's only chunk (5 seconds, 9 rows) | tiebreak: chunk 1
    + [("a", t) for t in (45, 50, 50)]             # (same strict chunk) | tiebreak: chunk 2 (short, padded)
    + [("b", t) for t in (5, 5, 5)]                # three rows in one second, nothing earlier
    + [("c", t) for t in (0, 7, 7, 7, 7, 7)]       # strict: c's only chunk (3 seconds, 9 rows) | tiebreak: chunk 1
    + [("c", t) for t in (7, 7, 9)]                # (same strict chunk) | tiebreak: chunk 2 opens inside second 7
)
# Expected whole-second gaps under the strict rule (0 when nothing strictly earlier is in the chunk). Since the
# B9 amendment no strict chunk opens inside a second, so 45 s measures to 30 s and the 7 s rows all measure to 0 s.
STRICT_GAPS = [0, 10, 10, 10, 10, 10, 15, 5, 5, 0, 0, 0, 0, 7, 7, 7, 7, 7, 7, 7, 2]
# The earlier previous-row rule over row-count chunks, kept as 'tiebreak'.
TIEBREAK_GAPS = [0, 10, 0, 10, 0, 0, 0, 5, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 2]


@pytest.fixture
def ties(tmp_path):
    torch.set_num_threads(1)
    n = len(LAYOUT)
    rng = np.random.default_rng(3)
    frame = pd.DataFrame({
        "transaction_dttm": pd.Timestamp("2024-01-01") + pd.to_timedelta([t for _, t in LAYOUT], unit="s"),
        ACCOUNT: [a for a, _ in LAYOUT], ID: [f"t{i:03}" for i in range(n)],
        "f1": rng.normal(size=n), "f2": rng.normal(size=n),
        "c1": rng.choice(["A", "B"], size=n), "c2": rng.choice(["X", "Y"], size=n),
        "frd_tag": np.arange(n) % 2, "transaction_amt": np.arange(n, dtype=float) + 1,
    })
    predictors = _write_predictors(tmp_path)
    features = load_feature_list(predictors, version=1)
    dt = DatetimeConfig(order_col="transaction_dttm", fields=DATETIME_FIELDS, encoding="categorical", is_weekend=False)
    artifacts = _fit_artifacts(frame, features, dt)
    path = tmp_path / "part_1.parquet"
    frame.to_parquet(path, index=False)
    artifacts.save(str(tmp_path / "artifacts/1"))
    cfg = OmegaConf.load(ROOT / "YOUR_PACKAGE/phase4b/configs/sequential_hier_allposition.yaml")
    cfg.s3.cred_path = None
    cfg.sequence.history_len = HISTORY_LEN
    cfg.training.batch_size = 2
    cfg.training.buffer_windows = 2
    cfg.training.num_workers = 0
    cfg.training.precision = "32-true"
    cfg.model.input_embed_dim = 8
    cfg.model.num_heads = 2
    cfg.model.num_txn_blocks = 1
    cfg.model.num_seq_blocks = 2
    cfg.model.attn_dropout = cfg.model.ff_dropout = 0.0
    cfg.predictors.csv_path = predictors
    cfg.predictors.version = 1
    cfg.artifacts.base = str(tmp_path / "artifacts")
    cfg.artifacts.version = 1
    cfg.eval.base = str(tmp_path)
    cfg.eval.file_start = cfg.eval.file_end = 1
    cfg.eval.predictions_base = str(tmp_path)
    cfg.eval.metrics_output = str(tmp_path / "score_metrics.json")
    return dict(frame=frame, features=features, dt=dt, artifacts=artifacts, cfg=cfg, files=[str(path)])


def _dataset(ties, rule=None, **overrides):
    cfg = ties["cfg"]
    if rule is not None:
        cfg.sequence.history_time_order = rule
    options = dict(
        file_list=ties["files"], artifacts=ties["artifacts"], features=ties["features"],
        datetime_config=ties["dt"], target_col="frd_tag", account_col=ACCOUNT,
        order_col="transaction_dttm", history_len=int(cfg.sequence.history_len),
        stride=1, positive_label=1, add_missing_flag=True, time_delta=True,
        batch_size=2, shuffle=False, tie_break_col=ID, id_cols=[ID, ACCOUNT],
        amount_col="transaction_amt", **sequence_dataset_options(cfg),
    )
    options.update(overrides)
    return SequenceBuilder(**options)


def _batches(dataset, frame):
    values = dataset._encode_file(frame)
    return list(dataset._emit_batches(list(dataset._windows_for_file(*values))))


def _scores(model, batches):
    result = {}
    with torch.no_grad():
        for batch in batches:
            scores, _, metadata = scorer._select_predictions(model(batch), batch, True)
            for identity, score in zip(metadata[ID], scores):
                assert identity not in result  # one prediction per real row
                result[identity] = float(score)
    return result


def _gaps_by_id(batches):
    gaps = {}
    for batch in batches:
        mask = batch["mask"].numpy()
        ids = batch["meta_seq"][ID]
        for identity, gap in zip(ids[mask], batch["continuous"][..., -1].numpy()[mask]):
            gaps[identity] = float(gap)
    return gaps


# --------------------------------------------------------------------------- gaps
def test_reported_case_10_20_20_gives_0_10_10_and_tiebreak_keeps_0_10_0(ties):
    frame = ties["frame"].iloc[:3]  # account a: 10, 20, 20
    assert _gaps_by_id(_batches(_dataset(ties, "strict"), frame)) == pytest.approx(
        {"t000": 0.0, "t001": np.log1p(10), "t002": np.log1p(10)})
    assert _gaps_by_id(_batches(_dataset(ties, "tiebreak"), frame)) == pytest.approx(
        {"t000": 0.0, "t001": np.log1p(10), "t002": 0.0})


@pytest.mark.parametrize("rule,expected", [("strict", STRICT_GAPS), ("tiebreak", TIEBREAK_GAPS)])
def test_gap_rule_over_groups_chunk_starts_and_all_tied_accounts(ties, rule, expected):
    gaps = _gaps_by_id(_batches(_dataset(ties, rule), ties["frame"]))
    assert gaps == pytest.approx({f"t{i:03}": float(np.log1p(g)) for i, g in enumerate(expected)})


def _reference_strict_gaps(seconds, order_key):
    """The per-row loop _chunk_gaps used before N2, kept as the reference."""
    gaps = np.zeros(len(seconds) - 1, dtype=np.int64)
    latest_earlier = -1
    for pos in range(1, len(seconds)):
        if order_key[pos] != order_key[pos - 1]:
            latest_earlier = pos - 1
        if latest_earlier >= 0:
            gaps[pos - 1] = seconds[pos] - seconds[latest_earlier]
    return gaps


def test_vectorised_strict_chunk_gaps_match_the_per_row_rule(ties):
    """N2: the vectorised strict gap equals the per-row walk on the stated cases and on random tie-heavy chunks
    (including order keys that differ below one second inside a whole second)."""
    dataset = _dataset(ties, "strict")
    cases = {(10, 20, 20): [10, 10], (20, 20, 30): [0, 10], (5, 5, 5): [0, 0], (7, 7, 9): [0, 2],
             (45, 50, 50): [5, 5]}
    for seconds, expected in cases.items():
        seconds = np.array(seconds, dtype=np.int64)
        gaps = dataset._chunk_gaps(seconds, seconds * 10 ** 9)
        assert gaps.dtype == np.int64 and gaps.tolist() == expected
    rng = np.random.default_rng(0)
    for _ in range(500):
        n = int(rng.integers(2, HISTORY_LEN + 2))
        order_key = np.sort(rng.integers(0, 4, size=n)).cumsum() * 400_000_000 + rng.integers(0, 2) * 10 ** 9
        seconds = order_key // 10 ** 9
        assert dataset._chunk_gaps(seconds, order_key).tolist() == _reference_strict_gaps(seconds, order_key).tolist()

def test_time_seq_is_aligned_with_rows_and_padding_is_zero(ties):
    frame = ties["frame"]
    expected = dict(zip(frame[ID], frame.transaction_dttm.values.astype("datetime64[ns]").astype("int64")))
    for batch in _batches(_dataset(ties, "strict"), frame):
        mask = batch["mask"].numpy()
        times = batch["time_seq"].numpy()
        assert batch["time_seq"].dtype == torch.int64 and times.shape == mask.shape
        assert (times[~mask] == 0).all()
        for identity, value in zip(batch["meta_seq"][ID][mask], times[mask]):
            assert value == expected[identity]


# --------------------------------------------------------------------------- mask
def _model(ties, rule="strict", blocks=2, seed=11):
    cfg = ties["cfg"]
    cfg.model.num_seq_blocks = blocks
    dataset = _dataset(ties, rule)
    torch.manual_seed(seed)
    return build_sequential_model(cfg, dataset).eval(), dataset


def test_strict_mask_hides_same_second_peers_from_each_other_and_keeps_cls_and_padding_rules(ties):
    model, _ = _model(ties)
    T = HISTORY_LEN + 1
    times = torch.tensor([[10, 20, 20, 30, 0, 0]])           # 4 real rows, 2 padded slots
    real = torch.tensor([[True, True, True, True, False, False]])
    key_padding = torch.cat([torch.zeros(1, 1, dtype=torch.bool), ~real], dim=1)
    blocked = torch.isinf(model._build_causal_mask(times.device, key_padding, times))[0]  # head 0 of sample 0
    allowed = ~blocked
    # Transaction rows (index 1..T): itself plus strictly earlier timestamps only.
    real_block = allowed[1:, 1:]
    assert real_block[0, :4].tolist() == [True, False, False, False]
    assert real_block[1, :4].tolist() == [True, True, False, False]
    assert real_block[2, :4].tolist() == [True, False, True, False]   # never its same-second peer
    assert real_block[3, :4].tolist() == [True, True, True, True]
    assert not real_block[1, 2] and not real_block[2, 1]              # mutually invisible
    # Padding: no real row reads a padded key; a padded row reads only itself (finite softmax).
    assert not real_block[:4, 4:].any()
    assert real_block[4:, :].tolist() == [[i == j for j in range(T)] for i in (4, 5)]
    # CLS: no transaction reads seq_CLS; seq_CLS reads itself and the real rows.
    assert not allowed[1:, 0].any()
    assert allowed[0, :5].all() and not allowed[0, 5:].any()
    # The positional rule is untouched when no times are given (default B and tiebreak chunks).
    positional = torch.isinf(model._build_causal_mask(times.device, key_padding))[0]
    assert not positional[3, 2]  # position 2 (time 20) reads position 1 (time 20) under the positional rule


def test_padded_slot_reads_only_itself_with_pre_1970_timestamps(ties):
    """N1: padding carries time 0, which is later than a negative (pre-1970) real timestamp; a padded query must
    still read only itself, and real rows keep the strict rule."""
    model, _ = _model(ties)
    T = HISTORY_LEN + 1
    times = torch.tensor([[-30, -20, -20, -10, 0, 0]])
    real = torch.tensor([[True, True, True, True, False, False]])
    key_padding = torch.cat([torch.zeros(1, 1, dtype=torch.bool), ~real], dim=1)
    allowed = ~torch.isinf(model._build_causal_mask(times.device, key_padding, times))[0]
    real_block = allowed[1:, 1:]
    assert real_block[4:, :].tolist() == [[i == j for j in range(T)] for i in (4, 5)]
    assert real_block[:4, :4].tolist() == [[True, False, False, False], [True, True, False, False],
                                           [True, False, True, False], [True, True, True, True]]
    assert not real_block[:4, 4:].any() and not allowed[1:, 0].any()

def test_strict_model_refuses_missing_or_misaligned_times(ties):
    model, dataset = _model(ties)
    batch = _batches(dataset, ties["frame"])[0]
    no_times = {k: v for k, v in batch.items() if k != "time_seq"}
    with pytest.raises(ValueError, match="time_seq"):
        model(no_times)
    backwards = dict(batch, time_seq=batch["time_seq"].flip(-1))
    backwards["mask"] = torch.ones_like(batch["mask"])
    with pytest.raises(ValueError, match="chronological"):
        model(backwards)
    assert set(scorer._model_inputs(batch, "cpu")) == {"continuous", "categorical", "mask", "time_seq"}


# --------------------------------------------------------------------------- future perturbation
@pytest.mark.parametrize("blocks", [2, 4])
def test_changing_a_later_or_same_second_row_never_changes_an_earlier_or_same_second_score(ties, blocks):
    model, dataset = _model(ties, blocks=blocks)
    frame = ties["frame"]
    complete = _scores(model, _batches(dataset, frame))
    assert len(complete) == len(frame)
    seconds = dict(zip(frame[ID], frame.transaction_dttm))
    accounts = dict(zip(frame[ID], frame[ACCOUNT]))
    for k in frame.index:
        changed = frame.copy()
        changed.loc[k, ["f1", "f2"]] = 10000.0
        changed.loc[k, "c1"] = "unseen-category"
        changed.loc[k, "frd_tag"] = 1 - changed.loc[k, "frd_tag"]
        perturbed = _scores(model, _batches(dataset, changed))
        target = frame.loc[k, ID]
        assert perturbed[target] != pytest.approx(complete[target], abs=1e-6)  # the change reaches the model
        for identity in complete:
            if identity == target:
                continue
            if accounts[identity] != accounts[target] or seconds[identity] <= seconds[target]:
                assert perturbed[identity] == pytest.approx(complete[identity], abs=2e-7), (target, identity)


def test_the_perturbation_test_detects_the_positional_rule_leak(ties):
    """Power check: under the earlier positional rule ('tiebreak'), changing the first of two same-second rows
    does change the second one's score, so the strict test above would fail on a peer-visible mask."""
    strict, _ = _model(ties, "strict")
    tiebreak, dataset = _model(ties, "tiebreak")
    tiebreak.load_state_dict(strict.state_dict())
    frame = ties["frame"]
    changed = frame.copy()
    changed.loc[1, ["f1", "f2"]] = 10000.0  # t001 at 20 s; t002 shares the second
    before = _scores(tiebreak, _batches(dataset, frame))
    after = _scores(tiebreak, _batches(dataset, changed))
    assert after["t002"] != pytest.approx(before["t002"], abs=1e-6)


@pytest.mark.parametrize("arrival", ["id_order", "reverse_id_order_inside_a_second"])
def test_prefix_replay_with_ties_is_invariant(ties, arrival):
    """At any moment the file holds only the rows available then; an existing row's score never moves when
    later rows (including a later same-second row) arrive. Arrival order inside a second is unknown (OQ-13),
    so same-second rows also arrive in reverse id order: a lower-id peer then arrives after the row and sorts
    before it. Strict chunks are cut only between seconds, so no same-second group crosses a chunk boundary."""
    model, dataset = _model(ties)
    frame = ties["frame"].query(f"{ACCOUNT} == 'a'")
    if arrival == "reverse_id_order_inside_a_second":
        frame = frame.sort_values(["transaction_dttm", ID], ascending=[True, False], kind="stable")
        assert frame[ID].tolist()[1:3] == ["t002", "t001"]
    complete = _scores(model, _batches(dataset, frame))
    for end in range(1, len(frame) + 1):
        prefix = _scores(model, _batches(dataset, frame.iloc[:end]))
        for identity, score in prefix.items():
            assert score == pytest.approx(complete[identity], abs=2e-7), (end, identity)


def _named(rows):
    """rows: (account, second, id, f1); every other input is identical across rows."""
    n = len(rows)
    return pd.DataFrame({
        "transaction_dttm": pd.Timestamp("2024-01-01") + pd.to_timedelta([r[1] for r in rows], unit="s"),
        ACCOUNT: [r[0] for r in rows], ID: [r[2] for r in rows],
        "f1": [r[3] for r in rows], "f2": [0.5] * n, "c1": ["A"] * n, "c2": ["X"] * n,
        "frd_tag": [0] * n, "transaction_amt": [1.0] * n,
    })


@pytest.mark.parametrize("blocks", [2, 4])
def test_a_lower_id_same_second_peer_inside_the_chunk_never_changes_the_score(ties, blocks):
    """F1: a same-second peer with a lower tie-break id (which may have arrived later, OQ-13) is never visible,
    and its existence must not move the row's position embedding either. Chunk [10 s t0, 20 s t2] against
    [10 s t0, 20 s t1, 20 s t2] with identical t0 and t2 inputs: t2's score is the same."""
    model, dataset = _model(ties, blocks=blocks)
    without = _scores(model, _batches(dataset, _named([("a", 10, "t0", 0.1), ("a", 20, "t2", 0.3)])))
    with_peer = _scores(model, _batches(dataset, _named(
        [("a", 10, "t0", 0.1), ("a", 20, "t1", 0.2), ("a", 20, "t2", 0.3)])))
    assert with_peer["t2"] == pytest.approx(without["t2"], abs=2e-7)
    assert with_peer["t0"] == pytest.approx(without["t0"], abs=2e-7)
    # Two lower-id peers and a later row: still unchanged.
    crowded = _scores(model, _batches(dataset, _named(
        [("a", 10, "t0", 0.1), ("a", 20, "t1", 0.2), ("a", 20, "t1b", -0.7), ("a", 20, "t2", 0.3),
         ("a", 30, "t3", 0.9)])))
    assert crowded["t2"] == pytest.approx(without["t2"], abs=2e-7)


def test_a_lower_id_peer_no_longer_moves_a_row_into_the_next_chunk(ties):
    """The F2 case, closed by the B9 amendment (reviewer-model-data-1 B1 (b)). T=6, five earlier seconds, then t5b
    at 50 s. Under row-count chunks a same-second peer t5a with a lower id pushed t5b into the next chunk, where
    it saw nothing. Strict chunks hold 6 distinct seconds, so t5a and t5b share the chunk with e1..e5: t5b keeps
    its five strictly earlier rows, its 45 s gap and position 5, and its score; the chunk is 7 rows wide.
    tiebreak keeps the row-count cut (and so still moves t5b)."""
    model, dataset = _model(ties)
    earlier = [("a", s, f"e{s}", 0.1 * s) for s in (1, 2, 3, 4, 5)]
    alone = _batches(dataset, _named(earlier + [("a", 50, "t5b", 0.3)]))
    with_peer = _batches(dataset, _named(earlier + [("a", 50, "t5a", 0.2), ("a", 50, "t5b", 0.3)]))
    assert len(alone) == 1 and alone[0]["mask"].sum() == 6 and alone[0]["meta_seq"][ID][0][5] == "t5b"
    chunks = [list(ids[mask]) for b in with_peer for ids, mask in zip(b["meta_seq"][ID], b["mask"].numpy())]
    assert chunks == [["e1", "e2", "e3", "e4", "e5", "t5a", "t5b"]]
    assert with_peer[0]["mask"].shape == (1, 7)
    for batches in (alone, with_peer):
        assert _gaps_by_id(batches)["t5b"] == pytest.approx(np.log1p(45))
    assert _position_indices(model, with_peer[0])[0, 6] == 5
    assert _scores(model, with_peer)["t5b"] == pytest.approx(_scores(model, alone)["t5b"], abs=2e-7)
    tiebreak = _dataset(ties, "tiebreak")
    pushed = _batches(tiebreak, _named(earlier + [("a", 50, "t5a", 0.2), ("a", 50, "t5b", 0.3)]))
    assert [list(ids[mask]) for b in pushed for ids, mask in zip(b["meta_seq"][ID], b["mask"].numpy())] == [
        ["e1", "e2", "e3", "e4", "e5", "t5a"], ["t5b"]]


def _position_indices(model, batch):
    seen = []
    handle = model.txn_position.register_forward_hook(lambda module, args, output: seen.append(args[0]))
    try:
        with torch.no_grad():
            model(batch)
    finally:
        handle.remove()
    assert len(seen) == 1
    return seen[0]


def test_strict_position_index_counts_strictly_earlier_real_rows_and_tiebreak_keeps_the_slot(ties):
    strict, dataset = _model(ties, "strict")
    batches = _batches(dataset, ties["frame"].iloc[:9])  # account a: [10, 20, 20, 30, 30, 30, 45, 50, 50]
    assert len(batches) == 1 and batches[0]["mask"].shape == (1, 9)  # 5 distinct seconds: one strict chunk
    index = _position_indices(strict, batches[0])
    # Strictly-earlier counts 0, 1, 1, 3, 3, 3, 6, 7, 7; the last three are clamped to H = 5.
    assert index[0].tolist() == [0, 1, 1, 3, 3, 3, 5, 5, 5]
    policy = strict.sequence_contract["all_position_time_policy"]
    assert policy["position_index"] == "count_of_strictly_earlier_real_rows_in_chunk_clamped_to_history_len"
    assert policy["chunking"] == "distinct_seconds"
    tiebreak, tiebreak_data = _model(ties, "tiebreak")
    slots = _position_indices(tiebreak, _batches(tiebreak_data, ties["frame"].iloc[:9])[0])
    assert slots.tolist() == list(range(HISTORY_LEN + 1))
    assert tiebreak.sequence_contract["all_position_time_policy"]["position_index"] == "chunk_slot"
    assert "chunking" not in tiebreak.sequence_contract["all_position_time_policy"]  # tiebreak policy unchanged


# --------------------------------------------------------------------------- padding, CLS, ownership
def test_padding_and_cls_isolation_under_the_strict_mask(ties):
    model, dataset = _model(ties)
    batches = _batches(dataset, ties["frame"])
    padded = [b for b in batches if not b["mask"].all()]
    assert padded  # the fixture has short chunks
    with torch.no_grad():
        for batch in padded:
            real = batch["mask"]
            reference = model(batch)[real]
            altered = dict(batch, continuous=batch["continuous"].clone(), time_seq=batch["time_seq"].clone())
            altered["continuous"][~real] = 5000.0
            altered["time_seq"][~real] = -(10 ** 12)  # an "earlier" padded time is still never read
            torch.testing.assert_close(model(altered)[real], reference)
        saved = model.seq_cls.detach().clone()
        reference = [model(b)[b["mask"]] for b in batches]
        model.seq_cls.data += 3.0  # no transaction position reads seq_CLS
        for batch, expected in zip(batches, reference):
            torch.testing.assert_close(model(batch)[batch["mask"]], expected)
        model.seq_cls.data.copy_(saved)


def test_one_target_loss_term_and_prediction_per_real_row(ties):
    model, dataset = _model(ties)
    model.train()
    model.log = lambda *args, **kwargs: None
    batch = next(iter(_dataset(ties, "strict", batch_size=64)))
    batch["continuous"].requires_grad_()
    logits, labels, loss = model._step(batch, "train")
    frame = ties["frame"]
    assert len(labels) == len(frame) == int(batch["mask"].sum())
    assert sorted(labels.tolist()) == sorted(frame.frd_tag.tolist())
    loss.backward()
    assert torch.isfinite(loss)
    assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
    assert torch.count_nonzero(batch["continuous"].grad[~batch["mask"]]) == 0
    model.eval()
    scores = _scores(model, _batches(dataset, frame))
    assert sorted(scores) == sorted(frame[ID])


# --------------------------------------------------------------------------- versioning
def test_checkpoint_of_one_time_policy_is_refused_under_the_other(ties):
    strict, _ = _model(ties, "strict")
    tiebreak, _ = _model(ties, "tiebreak")
    assert strict.sequence_contract["all_position_time_policy"]["history_time_order"] == "strict"
    assert strict.sequence_contract["version"] == 2
    for trained, scored in ((strict, tiebreak), (tiebreak, strict)):
        checkpoint = {"state_dict": trained.state_dict()}
        trained.on_save_checkpoint(checkpoint)
        trained.on_load_checkpoint(checkpoint)
        with pytest.raises(ValueError, match="sequence_contract mismatch"):
            scored.on_load_checkpoint(checkpoint)
    # The policy entry alone refuses the other rule, even with an otherwise identical input contract.
    checkpoint = {"state_dict": strict.state_dict()}
    strict.on_save_checkpoint(checkpoint)
    checkpoint["sequence_contract"]["all_position_time_policy"] = dict(
        tiebreak.sequence_contract["all_position_time_policy"])
    with pytest.raises(ValueError, match="mismatch"):
        strict.on_load_checkpoint(checkpoint)
    # A pre-B9 all-position checkpoint (contract version 1, no time policy) is not equivalent.
    old = {"state_dict": strict.state_dict()}
    strict.on_save_checkpoint(old)
    old["sequence_contract"]["version"] = 1
    del old["sequence_contract"]["all_position_time_policy"]
    with pytest.raises(ValueError, match="mismatch"):
        strict.on_load_checkpoint(old)


def test_without_time_delta_the_policy_records_no_gap(ties):
    ties["cfg"].sequence.time_delta = False
    model = build_sequential_model(ties["cfg"], _dataset(ties, "strict", time_delta=False))
    assert model.sequence_contract["all_position_time_policy"]["time_gap"] == "none"
    assert model.sequence_contract["all_position_time_policy"]["attention"] == (
        "self_and_strictly_earlier_timestamp_in_chunk")


def test_model_requires_an_explicit_rule_in_all_position_mode_only():
    common = dict(continuous_dim=2, categorical_cardinality=[2], history_len=2, embed_dim=8, num_heads=2,
                  num_txn_blocks=1, num_seq_blocks=1)
    every = dict(attention_mask="causal", predict_every_transaction=True,
                 all_position_layout="nonoverlapping_chunks", time_delta_reference="previous_transaction")
    with pytest.raises(ValueError, match="history_time_order"):
        FTTransformerHierModel(**common, **every)
    with pytest.raises(ValueError, match="history_time_order"):
        FTTransformerHierModel(**common, **every, history_time_order="earliest")
    with pytest.raises(ValueError, match="all-position mode only"):
        FTTransformerHierModel(**common, history_time_order="strict")
    default = FTTransformerHierModel(**common)
    assert "all_position_time_policy" not in default.sequence_contract
    assert default.sequence_contract["version"] == 1  # single-target contracts are unchanged


def test_default_b_config_builds_the_unchanged_single_target_model(ties):
    cfg = OmegaConf.load(ROOT / "YOUR_PACKAGE/phase4b/configs/sequential_hier.yaml")
    options = sequence_dataset_options(cfg)
    assert options["emit_target_seq"] is False and options["history_time_order"] == "strict"
    cfg.model.input_embed_dim = 8
    cfg.model.num_heads = 2
    dataset = _dataset(ties, history_len=int(cfg.sequence.history_len), **options)
    model = build_sequential_model(cfg, dataset)
    assert model.hparams.history_time_order is None
    assert set(model.sequence_contract) == {"version", "predict_every_transaction", "layout", "history_len",
                                            "time_delta_reference", "attention_mask", "architecture",
                                            "input_contract"}
    batch = next(iter(dataset))
    assert "time_seq" not in batch and model(batch).shape == (len(batch["target"]), 2)


# --------------------------------------------------------------------------- scorer
def test_scorer_builds_the_same_mask_and_gaps_as_training(ties, tmp_path, monkeypatch):
    model, dataset = _model(ties)
    checkpoint_path = tmp_path / "strict.ckpt"
    checkpoint = {"state_dict": model.state_dict()}
    model.on_save_checkpoint(checkpoint)
    torch.save(checkpoint, checkpoint_path)
    cfg = ties["cfg"]
    cfg.eval.checkpoint = str(checkpoint_path)
    config_path = tmp_path / "score.yaml"
    OmegaConf.save(cfg, config_path)
    monkeypatch.setattr(scorer, "make_s3_filesystem", lambda *args: None)
    monkeypatch.setattr(scorer.torch.cuda, "is_available", lambda: False)
    monkeypatch.setattr("sys.argv", ["score_sequential", "--config", str(config_path)])
    scorer.main()
    metrics = json.loads(Path(cfg.eval.metrics_output).read_text())
    assert metrics["sequence_contract"]["all_position_time_policy"]["history_time_order"] == "strict"
    output = pq.read_table(metrics["predictions_path"]).to_pandas()
    assert len(output) == len(ties["frame"]) and output[ID].is_unique
    expected = _scores(model, list(dataset))  # the training-side batches, with their time_seq
    for row in output.itertuples():
        assert row.score == pytest.approx(expected[getattr(row, ID)], abs=1e-7)
    # The same checkpoint is refused when the scoring config names the other rule.
    cfg.sequence.history_time_order = "tiebreak"
    OmegaConf.save(cfg, config_path)
    with pytest.raises(ValueError, match="mismatch"):
        scorer.main()
