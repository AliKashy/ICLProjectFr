"""Loader-level checks prevent invented labels/account membership/chronology."""

import importlib

import numpy as np
import pandas as pd
import pytest

from fraud.data.datetime_features import DatetimeConfig, derive_datetime_features
from fraud.data.feature_list import load_feature_list
from YOUR_PACKAGE.base.data.input_contracts import parse_required_timestamps
from YOUR_PACKAGE.base.data.parquet_loader import ParquetStreamingDataset
from fraud.data.preprocessing import PreprocessingArtifacts


def _inputs(tmp_path, derived=True):
    df = pd.DataFrame({
        'transaction_dttm': pd.date_range('2024-01-01', periods=3, freq='h'),
        'account': ['a', 'a', 'a'], 'id': ['first', 'second', 'third'],
        'amount': [1.0, np.nan, 3.0], 'category': ['shop', None, 'shop'],
        'label': [0, 1, 0],
    })
    predictors = tmp_path / 'predictors.csv'
    predictors.write_text('feature,type,source,version\n'
                          'amount,continuous,raw,1\n'
                          'category,categorical,raw,1\n' + (
                              'hour,categorical,derived:transaction_dttm,1\n' if derived else ''))
    features = load_feature_list(str(predictors))
    dt = DatetimeConfig(fields=['hour'])
    encoded, _, _ = derive_datetime_features(df, dt)
    artifacts = PreprocessingArtifacts()
    for col in features.continuous:
        artifacts.fit_feature(col, encoded[col], 'continuous')
    for col in features.categorical:
        artifacts.fit_feature(col, encoded[col], 'categorical')
    return df, features, dt, artifacts


def _loader(tmp_path, kind, df, features, dt, artifacts, positive_label=1):
    path = tmp_path / 'part_1.parquet'
    df.to_parquet(path, index=False)
    kwargs = {'file_list': [str(path)], 'artifacts': artifacts, 'features': features,
              'datetime_config': dt, 'target_col': 'label', 'positive_label': positive_label,
              'batch_size': 8, 'add_missing_flag': True}
    if kind == 'streaming':
        return ParquetStreamingDataset(**kwargs, shuffle_files=False)
    module = importlib.import_module({
        'base': 'YOUR_PACKAGE.base.data.sequence_builder',
        'A': 'YOUR_PACKAGE.phase4a.sequence_builder',
    }[kind])
    return module.SequenceBuilder(**kwargs, account_col='account', order_col='transaction_dttm',
                                  history_len=2, tie_break_col='id', id_cols=['id'], shuffle=False)


@pytest.mark.parametrize('kind', ['streaming', 'base', 'A'])
@pytest.mark.parametrize('missing', [np.nan, None, pd.NA])
def test_missing_label_is_never_encoded_as_legitimate(tmp_path, kind, missing):
    df, features, dt, artifacts = _inputs(tmp_path)
    df['label'] = pd.Series([0, missing, 1], dtype='Float64')
    with pytest.raises(ValueError, match='missing labels'):
        list(_loader(tmp_path, kind, df, features, dt, artifacts))


@pytest.mark.parametrize('kind', ['streaming', 'base', 'A'])
@pytest.mark.parametrize('labels,positive,expected', [
    ([0, 0, 0], 1, [0, 0, 0]),
    ([1, 1, 1], 1, [1, 1, 1]),
    ([-1, 1, -1], 1, [0, 1, 0]),
    (['legitimate', 'fraud', 'reviewed-negative'], 'fraud', [0, 1, 0]),
])
def test_generic_negative_labels_and_single_class_files_remain_valid(
    tmp_path, kind, labels, positive, expected,
):
    df, features, dt, artifacts = _inputs(tmp_path)
    df['label'] = labels
    batches = list(_loader(tmp_path, kind, df, features, dt, artifacts, positive))
    assert len(batches) == 1
    assert batches[0]['target'].flatten().tolist() == expected
    # Missing predictor values still use the frozen preprocessing artifacts.
    assert np.isfinite(batches[0]['continuous'].numpy()).all()


@pytest.mark.parametrize('kind', ['streaming', 'base', 'A'])
@pytest.mark.parametrize('case', ['missing', 'unparseable', 'numeric_without_unit'])
def test_required_timestamp_cannot_silently_become_nat_or_guessed_units(tmp_path, kind, case):
    df, features, dt, artifacts = _inputs(tmp_path)
    if case == 'missing':
        df.loc[1, 'transaction_dttm'] = pd.NaT
    elif case == 'unparseable':
        df['transaction_dttm'] = ['2024-01-01', 'not-a-date', '2024-01-02']
    else:
        df['transaction_dttm'] = [1704067200, 1704070800, 1704074400]
    with pytest.raises(ValueError, match='Timestamp column'):
        list(_loader(tmp_path, kind, df, features, dt, artifacts))


@pytest.mark.parametrize('kind', ['base', 'A'])
def test_missing_account_never_becomes_a_pseudo_account(tmp_path, kind):
    df, features, dt, artifacts = _inputs(tmp_path)
    df.loc[1, 'account'] = None
    with pytest.raises(ValueError, match='missing identifiers'):
        list(_loader(tmp_path, kind, df, features, dt, artifacts))


def test_streaming_raw_only_predictors_need_no_unused_timestamp_or_account(tmp_path):
    df, features, dt, artifacts = _inputs(tmp_path, derived=False)
    df = df.drop(columns=['transaction_dttm', 'account'])
    loader = _loader(tmp_path, 'streaming', df, features, dt, artifacts)
    assert 'transaction_dttm' not in loader._read_cols
    batches = list(loader)
    assert batches[0]['target'].flatten().tolist() == [0, 1, 0]
    assert batches[0]['continuous'].shape == (3, 1)


@pytest.mark.parametrize('kind', ['base', 'A'])
def test_sequence_raw_only_features_still_require_chronology(tmp_path, kind):
    df, features, dt, artifacts = _inputs(tmp_path, derived=False)
    df.loc[1, 'transaction_dttm'] = pd.NaT
    with pytest.raises(ValueError, match='missing values'):
        list(_loader(tmp_path, kind, df, features, dt, artifacts))


@pytest.mark.parametrize('kind', ['base', 'A'])
def test_parseable_string_times_are_sorted_chronologically_not_lexically(tmp_path, kind):
    df, features, dt, artifacts = _inputs(tmp_path, derived=False)
    df['transaction_dttm'] = ['2024-01-01 9:00:00', '2024-01-01 10:00:00', '2024-01-01 11:00:00']
    batches = list(_loader(tmp_path, kind, df, features, dt, artifacts))
    batch = batches[0]
    assert batch['meta']['id'].tolist() == ['first', 'second', 'third']
    assert batch['mask'].sum(1).tolist() == [1, 2, 3]
    assert batch['continuous'][1, -2, -1].item() == pytest.approx(np.log1p(3600))


def test_timezone_preserved_and_mixed_numeric_objects_rejected():
    source = pd.Series(pd.date_range('2024-11-03 00:00', periods=4, freq='h', tz='America/New_York'))
    parsed = parse_required_timestamps(source, 'event_time')
    pd.testing.assert_series_equal(parsed, source)
    assert parsed.dt.hour.tolist() == [0, 1, 1, 2]
    seconds = parsed.to_numpy(dtype='datetime64[s]').astype('int64')
    assert np.diff(seconds).tolist() == [3600, 3600, 3600]
    with pytest.raises(ValueError, match='numeric units'):
        parse_required_timestamps(pd.Series([pd.Timestamp('2024-01-01'), 1704067200], dtype=object), 'event_time')
