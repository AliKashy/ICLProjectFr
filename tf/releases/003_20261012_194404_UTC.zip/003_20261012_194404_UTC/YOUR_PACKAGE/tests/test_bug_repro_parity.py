"""The owner's bug-vs-fix comparison (YOUR_PACKAGE/future_experiments/bug_repro, 2026-10-08) is valid only while the buggy
trainer is the real phase 4a trainer with one change: BuggySequenceBuilder in place of SequenceBuilder. Any later edit
to the real trainer must be mirrored there, or the comparison tests more than the sharding bug."""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REAL = ROOT / "YOUR_PACKAGE/phase4a/scripts/train_sequential.py"
BUGGY = ROOT / "YOUR_PACKAGE/future_experiments/bug_repro/train_sequential_buggy.py"


def _body(path):
    """Source without the module docstring, with CRLF normalised."""
    text = path.read_bytes().decode("utf-8").replace("\r\n", "\n")
    first = ast.parse(text).body[0]
    assert isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant) and isinstance(first.value.value, str)
    return "\n".join(text.split("\n")[first.end_lineno:])


def test_buggy_trainer_differs_from_the_real_trainer_only_in_the_sequence_builder():
    real = _body(REAL)
    expected = (real
                .replace('os.path.dirname(__file__), "..", "..", ".."))',
                         'os.path.dirname(__file__), "..", "..", "..", ".."))')
                .replace("from YOUR_PACKAGE.phase4a.sequence_builder import SequenceBuilder  # phase-owned fix for the worker "
                         "file-sharding bug (see YOUR_PACKAGE/phase4a/sequence_builder.py docstring)",
                         "from YOUR_PACKAGE.future_experiments.bug_repro.sequence_builder_buggy import BuggySequenceBuilder")
                .replace("dataset = SequenceBuilder(", "dataset = BuggySequenceBuilder(")
                .replace('log.info("Sequence: ', 'log.info("[BUGGY SHARDING TEST] Sequence: ')
                .replace('log.info("Training complete.', 'log.info("[BUGGY SHARDING TEST] Training complete.'))
    assert expected != real
    assert _body(BUGGY) == expected


def test_buggy_builder_overrides_only_the_worker_file_split():
    from YOUR_PACKAGE.future_experiments.bug_repro.sequence_builder_buggy import BuggySequenceBuilder
    from YOUR_PACKAGE.phase4a.sequence_builder import SequenceBuilder

    assert issubclass(BuggySequenceBuilder, SequenceBuilder)
    assert {k for k in vars(BuggySequenceBuilder) if not k.startswith(("__", "_abc_"))} == {"_get_worker_files"}
    assert "_get_worker_files" in vars(SequenceBuilder)
