"""Behavioral regression checks for the original flat model's causal semantics."""

import pytest
import torch

from YOUR_PACKAGE.base.sequential_model import FTTransformerSeqModel


def model(**overrides):
    kwargs = dict(continuous_dim=2, categorical_cardinality=[4], history_len=2,
                  embed_dim=8, num_heads=2, num_attn_blocks=2,
                  attn_dropout=0., ff_dropout=0., attention_mask="causal", pos_weight=3.)
    return FTTransformerSeqModel(**{**kwargs, **overrides})


def batch(mask=None):
    return {"continuous": torch.randn(2, 3, 2), "categorical": torch.randint(0, 4, (2, 3, 1)),
            "mask": torch.tensor(mask or [[False, False, True], [False, True, True]]),
            "target": torch.tensor([[0], [1]])}


def test_causal_padding_has_finite_backward_and_no_padded_value_effect():
    net = model().train()
    data = batch()
    original = net(data)
    net.loss_fn(original, data["target"].ravel()).backward()
    assert torch.isfinite(original).all()
    assert all(torch.isfinite(p.grad).all() for p in net.parameters() if p.grad is not None)
    changed = {key: value.clone() for key, value in data.items()}
    changed["continuous"][~data["mask"]] = 1000
    changed["categorical"][~data["mask"]] = 3
    torch.testing.assert_close(net(changed), original)


def test_causal_prefix_cannot_receive_future_through_cls_after_two_blocks():
    net = model().eval()
    data = batch([[True, True, True], [True, True, True]])
    activations = []
    hook = net.encoder.register_forward_hook(lambda module, args, output: activations.append(output.detach()))
    with torch.no_grad():
        net(data)
        changed = {key: value.clone() for key, value in data.items()}
        changed["continuous"][:, -1] += 100
        net(changed)
    hook.remove()
    # First transaction's representations exclude CLS and every future txn.
    torch.testing.assert_close(activations[0][:, 1:1 + net.tokens_per_txn],
                               activations[1][:, 1:1 + net.tokens_per_txn])
    assert not torch.allclose(activations[0][:, 0], activations[1][:, 0])


def test_checkpoint_rejects_same_shape_mask_and_head_changes_and_legacy_causal():
    net = model()
    checkpoint = {"state_dict": net.state_dict(), "hyper_parameters": dict(net.hparams)}
    with pytest.raises(ValueError, match="predates"):
        net.on_load_checkpoint(checkpoint)
    net.on_save_checkpoint(checkpoint)
    clone = model()
    clone.on_load_checkpoint(checkpoint)
    clone.load_state_dict(checkpoint["state_dict"])
    assert clone.loss_fn.weight.tolist() == [1., 3.]
    for mismatch in (dict(num_heads=1), dict(attention_mask="bidirectional"), dict(pos_weight=1.)):
        with pytest.raises(ValueError, match="mismatch"):
            model(**mismatch).on_load_checkpoint(checkpoint)
    del checkpoint["hyper_parameters"]
    with pytest.raises(ValueError, match="hyper_parameters"):
        clone.on_load_checkpoint(checkpoint)


def test_old_bidirectional_checkpoint_remains_loadable_when_architecture_matches():
    net = model(attention_mask="bidirectional")
    checkpoint = {"state_dict": net.state_dict(), "hyper_parameters": dict(net.hparams)}
    net.on_load_checkpoint(checkpoint)
