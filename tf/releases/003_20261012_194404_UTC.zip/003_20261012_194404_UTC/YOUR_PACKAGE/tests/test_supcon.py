"""Offline tests for SupCon contrastive pretraining (synthetic, no S3/GPU).

SupCon is a Lever-5 pretraining recipe for the FT encoder (YOUR_PACKAGE/future_experiments/pretrain),
not a separate model. Run: python -m pytest YOUR_PACKAGE/tests/test_supcon.py -q
"""

import os
import sys

import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from YOUR_PACKAGE.future_experiments.pretrain.supcon import SupConLoss, SupConPretrainer
from YOUR_PACKAGE.future_experiments.pretrain.ssl_finetune import SSLFinetuneClassifier

B, C = 8, 3
CARDS = [5, 5, 2, 2]
K = len(CARDS)
EMBED, HEADS = 16, 4


def _flat_batch():
    return {
        "continuous": torch.randn(B, C),
        "categorical": torch.stack([torch.randint(0, c, (B,)) for c in CARDS], dim=-1),
        "target": torch.randint(0, 2, (B, 1)),
    }


def test_supcon_loss_is_scalar_and_differentiable():
    feats = torch.randn(B, 2, EMBED, requires_grad=True)
    labels = torch.randint(0, 2, (B,))
    loss = SupConLoss(temperature=0.1)(feats, labels)
    assert loss.ndim == 0
    loss.backward()
    assert feats.grad is not None


def test_supcon_pretrainer_step_backward():
    model = SupConPretrainer(C, CARDS, embed_dim=EMBED, num_heads=HEADS, num_blocks=1, proj_dim=8)
    loss = model._step(_flat_batch(), "train")
    assert loss.ndim == 0
    loss.backward()


def test_supcon_encoder_keys_load_into_finetuner():
    pre = SupConPretrainer(C, CARDS, embed_dim=EMBED, num_heads=HEADS, num_blocks=1, proj_dim=8)
    clf = SSLFinetuneClassifier(C, CARDS, embed_dim=EMBED, num_heads=HEADS, num_blocks=1)
    missing, unexpected = clf.load_pretrained(pre.state_dict())  # encoder.* must transfer
    assert all("projection" not in k for k in missing)
    assert clf(_flat_batch()).shape == (B, 2)
