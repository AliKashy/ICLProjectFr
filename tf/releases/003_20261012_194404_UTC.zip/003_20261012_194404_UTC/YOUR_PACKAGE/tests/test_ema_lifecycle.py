"""EMA correctness under actual Lightning checkpoint, accumulation and resume hooks."""

import importlib

import pytest
import pytorch_lightning as pl
import torch
from pytorch_lightning.callbacks import ModelCheckpoint
from torch.utils.data import DataLoader, TensorDataset


@pytest.fixture(params=["phase4a", "phase4b"])
def ema_cls(request):
    return importlib.import_module(f"YOUR_PACKAGE.{request.param}.callbacks").EMACallback


class Toy(pl.LightningModule):
    def __init__(self):
        super().__init__()
        self.w = torch.nn.Parameter(torch.tensor(0.0))
        self.register_buffer("constant", torch.tensor(7))

    def training_step(self, batch, batch_idx):
        return (self.w - 1.0).square()

    def validation_step(self, batch, batch_idx):
        self.log("valid_ap", self.w.detach(), on_epoch=True)

    def configure_optimizers(self):
        return torch.optim.AdamW(self.parameters(), lr=0.1)


class SaveAroundRestore(pl.Callback):
    def __init__(self, path, label):
        self.path, self.label = path, label

    def on_validation_end(self, trainer, model):
        if not trainer.sanity_checking:
            trainer.save_checkpoint(self.path / f"{self.label}.ckpt")


def fit(ema_cls, path, *, batches=5, accumulation=2, epochs=1, interval=1.0, resume=None):
    class TraceEMA(ema_cls):
        def __init__(self):
            super().__init__(decay=0.5)
            self.events = []

        def on_train_start(self, trainer, model):
            super().on_train_start(trainer, model)
            self.reference = self.shadow["w"].clone()
            self.previous_step = trainer.global_step

        def on_train_batch_end(self, trainer, model, outputs, batch, batch_idx):
            before = self.shadow["w"].clone()
            super().on_train_batch_end(trainer, model, outputs, batch, batch_idx)
            if trainer.global_step != self.previous_step:
                self.reference = 0.5 * self.reference + 0.5 * model.w.detach()
            torch.testing.assert_close(self.shadow["w"], self.reference, rtol=0, atol=0)
            self.events.append((trainer.global_step, before, self.shadow["w"].clone()))
            self.previous_step = trainer.global_step

    path.mkdir(parents=True)
    ema, model = TraceEMA(), Toy()
    checkpoint = ModelCheckpoint(dirpath=path, filename="best", monitor="valid_ap", mode="max",
                                 save_last=True, enable_version_counter=False)
    trainer = pl.Trainer(accelerator="cpu", devices=1, max_epochs=epochs,
                         accumulate_grad_batches=accumulation, val_check_interval=interval,
                         num_sanity_val_steps=1, logger=False, enable_progress_bar=False,
                         enable_model_summary=False,
                         callbacks=[checkpoint, SaveAroundRestore(path, "before"), ema,
                                    SaveAroundRestore(path, "after")])
    trainer.fit(model, DataLoader(TensorDataset(torch.zeros(batches)), batch_size=1),
                DataLoader(TensorDataset(torch.zeros(1)), batch_size=1), ckpt_path=resume)
    for file in path.glob("*.ckpt"):
        state = torch.load(file, map_location="cpu", weights_only=False)
        torch.testing.assert_close(state["state_dict"]["w"], ema.shadow["w"], rtol=0, atol=0)
        torch.testing.assert_close(state["ema_shadow"]["w"], ema.shadow["w"], rtol=0, atol=0)
        torch.testing.assert_close(state["ema_raw_params"]["w"], model.w.detach(), rtol=0, atol=0)
        assert state["state_dict"]["constant"] == 7
    return model.w.detach(), ema.shadow["w"], torch.load(path / "last.ckpt", weights_only=False), ema.events


@pytest.mark.parametrize("batches,accumulation", [(4, 2), (3, 2), (3, 4), (5, 2)])
def test_updates_once_per_optimizer_step_and_partial_group(ema_cls, tmp_path, batches, accumulation):
    _, _, checkpoint, _ = fit(ema_cls, tmp_path / "fit", batches=batches, accumulation=accumulation)
    assert checkpoint["global_step"] == (batches + accumulation - 1) // accumulation


def test_within_epoch_validation_preserves_raw_training(ema_cls, tmp_path):
    standard = fit(ema_cls, tmp_path / "standard", batches=4)
    frequent = fit(ema_cls, tmp_path / "frequent", batches=4, interval=1)
    for left, right in zip(standard[:2], frequent[:2]):
        torch.testing.assert_close(left, right, rtol=0, atol=0)


def test_resume_matches_uninterrupted_adamw_and_ema(ema_cls, tmp_path):
    full = fit(ema_cls, tmp_path / "full", epochs=2)
    part = fit(ema_cls, tmp_path / "part")
    resumed = fit(ema_cls, tmp_path / "resumed", epochs=2, resume=str(tmp_path / "part/last.ckpt"))
    for left, right in zip(full[:2], resumed[:2]):
        torch.testing.assert_close(left, right, rtol=0, atol=0)
    first_step, before, after = resumed[3][0]
    assert first_step == part[2]["global_step"]  # first microbatch does not step
    torch.testing.assert_close(before, after, rtol=0, atol=0)
    left, right = full[2]["optimizer_states"][0], resumed[2]["optimizer_states"][0]
    assert left["param_groups"] == right["param_groups"]
    for key, value in left["state"][0].items():
        torch.testing.assert_close(value, right["state"][0][key], rtol=0, atol=0)


def test_restored_shadow_uses_current_parameter_dtype(ema_cls):
    callback = ema_cls(decay=0.5)
    callback.shadow = {"w": torch.tensor(0.23)}
    callback.on_fit_start(None, Toy().double())
    assert callback.shadow["w"].dtype == torch.float64
