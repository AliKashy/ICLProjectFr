"""Adversarial scorer-result types and no-side-effect spec validation."""

import hashlib
import importlib
import json

from omegaconf import OmegaConf
import pytest


@pytest.fixture(params=["phase4a", "phase4b"])
def runner(request):
    return importlib.import_module(f"YOUR_PACKAGE.{request.param}.scripts.run_ablations")


@pytest.fixture
def result_fixture(tmp_path):
    checkpoint = tmp_path / "best.ckpt"
    checkpoint.write_bytes(b"synthetic-checkpoint")
    digest = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
    return checkpoint, digest, dict(
        schema_version=1, checkpoint_path=str(checkpoint), checkpoint_sha256=digest,
        predictions_path="bucket/predictions.parquet", n_predictions=4, n_positives=1,
        average_precision=0.3, auroc=0.6,
    )


@pytest.mark.parametrize("changes,enabled", [
    ({"schema_version": True}, True),
    ({"n_predictions": True, "n_positives": False}, False),
    ({"n_positives": True}, True),
    ({"average_precision": True}, True),
    ({"auroc": False}, True),
    ({"average_precision": float("nan")}, True),
    ({"predictions_path": {"wrong": "type"}}, True),
    ({"predictions_path": "  "}, True),
    ({"average_precision": 42.0}, False),
    ({"auroc": 0.6}, False),
])
def test_invalid_result_schema_is_rejected(runner, result_fixture, tmp_path, changes, enabled):
    checkpoint, digest, payload = result_fixture
    if not enabled:
        payload.update(average_precision=None, auroc=None)
    payload.update(changes)
    path = tmp_path / "metrics.json"
    path.write_text(json.dumps(payload))
    with pytest.raises(ValueError):
        runner._score_metrics(path, str(checkpoint), digest, enabled)


@pytest.mark.parametrize("enabled", [True, False])
def test_valid_enabled_and_disabled_results(runner, result_fixture, tmp_path, enabled):
    checkpoint, digest, payload = result_fixture
    if not enabled:
        payload.update(average_precision=None, auroc=None)
    path = tmp_path / "metrics.json"
    path.write_text(json.dumps(payload))
    assert runner._score_metrics(path, str(checkpoint), digest, enabled) == payload


@pytest.mark.parametrize("changes,base_change", [
    ({"axes": {"history": {}}}, {}),
    ({"attempt_tag": "../escape"}, {}),
    ({"attempt_tag": 0}, {}),
    ({"attempt_tag": False}, {}),
    ({"attempt_tag": ""}, {}),
    ({}, {"required": "???"}),
    ({"axes": {"case": {"good": [], "bad": ["probe=${does_not_exist}"]}}}, {}),
])
def test_dry_run_rejects_invalid_spec_before_artifacts(runner, monkeypatch, tmp_path, changes, base_change):
    base = tmp_path / "base.yaml"
    OmegaConf.save(OmegaConf.create({"output": {"checkpoint_dir": "unused"}, **base_change}), base)
    spec = dict(base_config=str(base), output_root=str(tmp_path / "output"),
                attempt_tag="review", axes={"case": {"normal": []}})
    spec.update(changes)
    path = tmp_path / "spec.yaml"
    OmegaConf.save(OmegaConf.create(spec), path)
    monkeypatch.setattr(runner.sys, "argv", ["runner", "--config", str(path), "--dry-run"])
    monkeypatch.setattr(runner, "_run", lambda *a, **kw: pytest.fail("No subprocess should start"))
    with pytest.raises(SystemExit) as error:
        runner.main()
    assert error.value.code == 2
    assert not (tmp_path / "output").exists()


def test_string_zero_tag_and_run_path_interpolation_resolve_in_dry_run(runner, monkeypatch, tmp_path):
    base = tmp_path / "base.yaml"
    OmegaConf.save(OmegaConf.create({"output": {"checkpoint_dir": "unused"},
                                    "same_checkpoint_dir": "${output.checkpoint_dir}"}), base)
    path = tmp_path / "spec.yaml"
    OmegaConf.save(OmegaConf.create(dict(base_config=str(base), output_root=str(tmp_path / "output"),
                                        attempt_tag="0", axes={})), path)
    monkeypatch.setattr(runner.sys, "argv", ["runner", "--config", str(path), "--dry-run"])
    assert runner.main() == 0
    assert not (tmp_path / "output").exists()
    # Explicit tags have identical reuse semantics in validation and execution.
    (tmp_path / "output/0").mkdir(parents=True)
    with pytest.raises(SystemExit) as error:
        runner.main()
    assert error.value.code == 2
