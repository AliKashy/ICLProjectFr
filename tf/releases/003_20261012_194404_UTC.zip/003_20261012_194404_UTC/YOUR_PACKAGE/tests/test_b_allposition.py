"""Causal chunk ownership, prefix replay, and real train/reload/score integration."""
import json
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
import pytest
import pytorch_lightning as pl
import torch
from omegaconf import OmegaConf
from torch.utils.data import DataLoader

from fraud.data.datetime_features import DatetimeConfig
from fraud.data.feature_list import load_feature_list
from YOUR_PACKAGE.phase4b.factory import build_sequential_model, sequence_dataset_options
from YOUR_PACKAGE.phase4b.sequence_builder import SequenceBuilder
from YOUR_PACKAGE.phase4b.scripts import score_sequential as scorer
from YOUR_PACKAGE.phase4b.scripts.train_sequential import _make_loader
from YOUR_PACKAGE.phase4b.scripts import train_sequential as training
from YOUR_PACKAGE.phase4b.sequential_hier import FTTransformerHierModel
from YOUR_PACKAGE.tests.test_sequence_builder import DATETIME_FIELDS, _fit_artifacts, _write_predictors

ROOT = Path(__file__).resolve().parents[2]
ID = "fi_transaction_id"
ACCOUNT = "Nmap_account_reference_xid"


@pytest.fixture
def fixture(tmp_path):
    torch.set_num_threads(1)
    ids = np.arange(11)
    frame = pd.DataFrame({
        "transaction_dttm": pd.Timestamp("2024-01-01") + pd.to_timedelta(ids**2, unit="s"),
        ACCOUNT: ["a"] * 7 + ["b"] * 3 + ["c"], ID: [f"t{i:03}" for i in ids],
        "f1": ids.astype(float), "f2": ids / 10, "c1": "A", "c2": "X",
        "frd_tag": ids % 2, "transaction_amt": ids.astype(float) + 1,
    })
    predictors = _write_predictors(tmp_path)
    features = load_feature_list(predictors, version=1)
    dt = DatetimeConfig(order_col="transaction_dttm", fields=DATETIME_FIELDS, encoding="categorical", is_weekend=False)
    artifacts = _fit_artifacts(frame, features, dt)
    path = tmp_path / "part_1.parquet"
    frame.to_parquet(path, index=False)
    cfg = OmegaConf.load(ROOT / "YOUR_PACKAGE/phase4b/configs/sequential_hier_allposition.yaml")
    cfg.s3.cred_path = None
    cfg.sequence.history_len = 2
    cfg.training.batch_size = 2
    cfg.training.buffer_windows = 2
    cfg.training.num_workers = 0
    cfg.training.precision = "32-true"
    cfg.model.input_embed_dim = 8
    cfg.model.num_heads = 2
    cfg.model.num_txn_blocks = 1
    cfg.model.num_seq_blocks = 2
    cfg.model.attn_dropout = cfg.model.ff_dropout = 0.0
    cfg.predictors.csv_path = predictors
    cfg.predictors.version = 1
    cfg.eval.base = str(tmp_path)
    cfg.eval.file_start = cfg.eval.file_end = 1
    cfg.eval.predictions_base = str(tmp_path)
    cfg.eval.metrics_output = str(tmp_path / "score_metrics.json")
    cfg.artifacts.base = str(tmp_path / "artifacts")
    cfg.artifacts.version = 1
    artifacts.save(str(tmp_path / "artifacts/1"))
    return dict(frame=frame, features=features, dt=dt, artifacts=artifacts, cfg=cfg, files=[str(path)])


def _dataset(fixture, **overrides):
    cfg = fixture["cfg"]
    options = dict(
        file_list=fixture["files"], artifacts=fixture["artifacts"], features=fixture["features"],
        datetime_config=fixture["dt"], target_col="frd_tag", account_col=ACCOUNT,
        order_col="transaction_dttm", history_len=cfg.sequence.history_len,
        stride=1, positive_label=1, add_missing_flag=True, time_delta=True,
        batch_size=2, shuffle=False, tie_break_col=ID, id_cols=[ID, ACCOUNT],
        amount_col="transaction_amt", **sequence_dataset_options(cfg),
    )
    options.update(overrides)
    return SequenceBuilder(**options)


def _batches_for_frame(dataset, frame):
    values = dataset._encode_file(frame)
    return list(dataset._emit_batches(list(dataset._windows_for_file(*values))))


def _scores(model, batches):
    result = {}
    with torch.no_grad():
        for batch in batches:
            scores, labels, metadata = scorer._select_predictions(model(batch), batch, True)
            for identity, score in zip(metadata[ID], scores):
                assert identity not in result
                result[identity] = float(score)
    return result


@pytest.mark.parametrize("history_len", [0, 2, 5])
@pytest.mark.parametrize("workers", [0, 2])
def test_real_parquet_unique_ownership_padding_and_backward_gaps(fixture, history_len, workers):
    dataset = _dataset(fixture, history_len=history_len)
    observed = []
    actual_targets = []
    for batch in DataLoader(dataset, batch_size=None, num_workers=workers):
        assert "target" not in batch  # Cannot silently consume a final-target label.
        mask = batch["mask"].numpy()
        assert np.array_equal(batch["target_seq"].numpy() != -100, mask)
        observed.extend(batch["meta_seq"][ID][mask].tolist())
        actual_targets.extend(batch["target_seq"].numpy()[mask].tolist())
        for n, row in enumerate(mask):
            count = int(row.sum())
            assert row.tolist() == [True] * count + [False] * (history_len + 1 - count)
            assert batch["continuous"][n, 0, -1] == 0
            assert len(set(batch["meta_seq"][ACCOUNT][n, row])) == 1
            ids = batch["meta_seq"][ID][n, row]
            raw = fixture["frame"].set_index(ID).loc[ids]
            times = raw.transaction_dttm.values.astype("datetime64[s]").astype("int64")
            expected = np.r_[0, np.log1p(np.diff(times))]
            np.testing.assert_allclose(batch["continuous"][n, :count, -1], expected, rtol=1e-6)
    assert len(observed) == len(set(observed)) == len(fixture["frame"])
    expected_labels = fixture["frame"].set_index(ID).frd_tag.to_dict()
    assert dict(zip(observed, actual_targets)) == expected_labels


@pytest.mark.parametrize("blocks", [2, 4])
def test_raw_prefix_replay_is_invariant_to_appended_or_changed_future(fixture, blocks):
    dataset = _dataset(fixture)
    cfg = fixture["cfg"]
    cfg.model.num_seq_blocks = blocks
    torch.manual_seed(31)
    model = build_sequential_model(cfg, dataset).eval()
    frame = fixture["frame"].query(f"{ACCOUNT} == 'a'").copy()
    complete = _scores(model, _batches_for_frame(dataset, frame))
    # Real builder replay: at time j the file contains only rows available then.
    # Later appends may fill a previously padded chunk, but cannot alter its prefix.
    for end in range(1, len(frame) + 1):
        prefix = _scores(model, _batches_for_frame(dataset, frame.iloc[:end]))
        for identity in prefix:
            assert prefix[identity] == pytest.approx(complete[identity], abs=2e-7)
    changed = frame.copy()
    changed.loc[changed.index[2:], "transaction_dttm"] += pd.Timedelta(days=100)
    changed.loc[changed.index[2:], ["f1", "f2"]] = 10000
    changed.loc[changed.index[2:], "c1"] = "unseen-category"
    changed.loc[changed.index[2:], "frd_tag"] = 1 - changed.loc[changed.index[2:], "frd_tag"]
    perturbed = _scores(model, _batches_for_frame(dataset, changed))
    for identity in frame[ID].iloc[:2]:
        assert perturbed[identity] == pytest.approx(complete[identity], abs=2e-7)


def test_allposition_loss_uses_each_real_label_once_and_ignores_padding(fixture):
    dataset = _dataset(fixture, batch_size=10)
    fixture["cfg"].training.pos_weight = 2.5
    model = build_sequential_model(fixture["cfg"], dataset)
    model.log = lambda *args, **kwargs: None
    batch = next(iter(dataset))
    batch["continuous"].requires_grad_()
    logits, labels, loss = model._step(batch, "train")
    assert len(labels) == len(fixture["frame"])
    expected = torch.nn.functional.cross_entropy(logits, labels, weight=torch.tensor([1.0, 2.5]), reduction="sum") / len(labels)
    torch.testing.assert_close(loss, expected)
    loss.backward()
    assert torch.isfinite(loss)
    assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
    assert torch.count_nonzero(batch["continuous"].grad[~batch["mask"]]) == 0
    # Padded feature values are completely irrelevant to real transaction scores.
    model.eval()
    altered = {key: value for key, value in batch.items()}
    altered["continuous"] = batch["continuous"].detach().clone()
    altered["continuous"][~batch["mask"]] = 5000
    torch.testing.assert_close(model(batch)[batch["mask"]], model(altered)[batch["mask"]])
    invalid = dict(batch, target_seq=batch["target_seq"].clone())
    invalid["target_seq"][~batch["mask"]] = 0
    with pytest.raises(ValueError, match="own exactly one"):
        model._step(invalid, "valid")


@pytest.mark.parametrize("key,value", [
    ("all_position_layout", None), ("time_delta_reference", "target"),
    ("attention_mask", "bidirectional"), ("train_stride", 2), ("eval_stride", 2),
])
def test_unsafe_allposition_configs_fail_explicitly(fixture, key, value):
    fixture["cfg"].sequence[key] = value
    with pytest.raises(ValueError):
        sequence_dataset_options(fixture["cfg"])


def test_checkpoint_contract_rejects_old_or_relabelled_allposition_models(fixture):
    dataset = _dataset(fixture)
    model = build_sequential_model(fixture["cfg"], dataset)
    checkpoint = {"state_dict": model.state_dict()}
    with pytest.raises(ValueError, match="missing"):
        model.on_load_checkpoint(checkpoint)
    model.on_save_checkpoint(checkpoint)
    model.on_load_checkpoint(checkpoint)
    checkpoint["sequence_contract"]["time_delta_reference"] = "target"
    with pytest.raises(ValueError, match="mismatch"):
        model.on_load_checkpoint(checkpoint)
    default = FTTransformerHierModel(2, [2], 2, embed_dim=8, num_heads=2, num_txn_blocks=1, num_seq_blocks=1)
    default.on_load_checkpoint({"state_dict": default.state_dict()})
    with pytest.raises(ValueError, match="num_heads"):
        default.on_load_checkpoint({"hyper_parameters": {"num_heads": 4}})
    with pytest.raises(ValueError, match="missing"):
        default.on_load_checkpoint({"hyper_parameters": {"predict_every_transaction": True}})


def test_default_single_target_windows_and_checkpoint_behavior_are_preserved(fixture):
    original = OmegaConf.load(ROOT / "YOUR_PACKAGE/phase4b/configs/sequential_hier.yaml")
    original.s3.cred_path = None
    original.training.batch_size = 3
    original.training.buffer_windows = 3
    loader = _make_loader(original, fixture["files"], fixture["artifacts"], fixture["features"], fixture["dt"], False, 1, 0)
    assert loader.dataset.emit_target_seq is False
    batches = list(loader)
    assert sum(len(batch["target"]) for batch in batches) == len(fixture["frame"])
    assert all("target_seq" not in batch for batch in batches)
    assert all(torch.all(batch["mask"][:, -1]) for batch in batches)
    assert all(torch.all(batch["continuous"][:, -1, -1] == 0) for batch in batches)
    original.model.input_embed_dim = 8
    original.model.num_heads = 2
    original.model.num_txn_blocks = original.model.num_seq_blocks = 1
    model = build_sequential_model(original, loader.dataset)
    assert model(batches[0]).shape == (3, 2)
    scores, targets, metadata = scorer._select_predictions(model(batches[0]), batches[0], False)
    assert scores.shape == targets.shape == (3,)


def test_real_cpu_train_checkpoint_reload_and_score_cli(fixture, tmp_path, monkeypatch):
    cfg = fixture["cfg"]
    train = _make_loader(cfg, fixture["files"], fixture["artifacts"], fixture["features"], fixture["dt"], True, 1, 0)
    val = _make_loader(cfg, fixture["files"], fixture["artifacts"], fixture["features"], fixture["dt"], False, 1, 0)
    model = build_sequential_model(cfg, train.dataset)
    trainer = pl.Trainer(max_epochs=1, accelerator="cpu", devices=1, logger=False,
                         enable_checkpointing=False, enable_progress_bar=False, enable_model_summary=False,
                         num_sanity_val_steps=0, default_root_dir=str(tmp_path))
    trainer.fit(model, train, val)
    checkpoint_path = tmp_path / "trained.ckpt"
    trainer.save_checkpoint(checkpoint_path)
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    assert checkpoint["sequence_contract"] == model.sequence_contract
    restored = FTTransformerHierModel.load_from_checkpoint(checkpoint_path).eval()
    model.eval()
    batch = next(iter(val))
    torch.testing.assert_close(model(batch), restored(batch))
    cfg.eval.checkpoint = str(checkpoint_path)
    config_path = tmp_path / "score.yaml"
    OmegaConf.save(cfg, config_path)
    monkeypatch.setattr(scorer, "make_s3_filesystem", lambda *args: None)
    monkeypatch.setattr(scorer.torch.cuda, "is_available", lambda: False)
    monkeypatch.setattr("sys.argv", ["score_sequential", "--config", str(config_path)])
    scorer.main()
    first = json.loads(Path(cfg.eval.metrics_output).read_text())
    output = pq.read_table(first["predictions_path"]).to_pandas()
    assert len(output) == first["n_predictions"] == len(fixture["frame"])
    assert output[ID].is_unique
    assert first["n_positives"] == int(fixture["frame"].frd_tag.sum())
    assert first["checkpoint_sha256"] == scorer._checkpoint_sha256(checkpoint_path)
    assert first["sequence_contract"] == model.sequence_contract
    assert first["checkpoint_contract_verified"] is True
    expected = _scores(restored, list(_dataset(fixture)))
    for row in output.itertuples():
        assert row.score == pytest.approx(expected[getattr(row, ID)], abs=1e-7)
    scorer.main()
    second = json.loads(Path(cfg.eval.metrics_output).read_text())
    assert first["predictions_path"] != second["predictions_path"]
    assert Path(first["predictions_path"]).exists()
    assert second["average_precision"] == first["average_precision"]


def test_duplicate_evaluation_ids_and_invalid_order_are_rejected(fixture):
    with pytest.raises(ValueError, match="unique"):
        scorer._validate_predictions(np.array([0.1, 0.2]), np.array([0, 1]), {ID: np.array(["same", "same"])}, [ID])
    dataset = _dataset(fixture)
    repeated = pd.concat([fixture["frame"], fixture["frame"].iloc[:1]], ignore_index=True)
    with pytest.raises(ValueError, match="Duplicate"):
        dataset._encode_file(repeated)
    invalid = fixture["frame"].copy()
    invalid.loc[0, "transaction_dttm"] = pd.NaT
    with pytest.raises(ValueError, match="missing"):
        dataset._encode_file(invalid)


def test_distributed_launch_is_rejected_before_reading_data(monkeypatch):
    monkeypatch.setenv("WORLD_SIZE", "2")
    with pytest.raises(RuntimeError, match="one device only"):
        training.main()


def test_wrong_architecture_config_is_rejected(fixture):
    fixture["cfg"].model.type = "FTTransformerSeq"
    with pytest.raises(ValueError, match="model.type"):
        sequence_dataset_options(fixture["cfg"])


@pytest.mark.parametrize("drift", ["attention_heads", "feature_order", "artifact_values", "label_mapping"])
def test_same_shape_checkpoint_semantic_drift_is_rejected(fixture, drift):
    dataset = _dataset(fixture)
    original = build_sequential_model(fixture["cfg"], dataset)
    checkpoint = {"state_dict": original.state_dict(), "hyper_parameters": dict(original.hparams)}
    original.on_save_checkpoint(checkpoint)
    if drift == "attention_heads":
        fixture["cfg"].model.num_heads = 4
    elif drift == "feature_order":
        dataset.continuous_cols = list(reversed(dataset.continuous_cols))
    elif drift == "artifact_values":
        dataset.artifacts.features["f1"]["mean"] += 1
    else:
        dataset.positive_label = 0
    changed = build_sequential_model(fixture["cfg"], dataset)
    # All of these incompatible predictors fit the exact same state tensor shapes.
    changed.load_state_dict(checkpoint["state_dict"], strict=True)
    with pytest.raises(ValueError, match="mismatch"):
        changed.on_load_checkpoint(checkpoint)


def test_allposition_without_time_delta_remains_supported(fixture):
    fixture["cfg"].sequence.time_delta = False
    dataset = _dataset(fixture, time_delta=False)
    model = build_sequential_model(fixture["cfg"], dataset).eval()
    assert model.sequence_contract["time_delta_reference"] == "none"
    batch = next(iter(dataset))
    assert batch["continuous"].shape[-1] == len(fixture["features"].continuous)
    probabilities, labels, _ = scorer._select_predictions(model(batch), batch, True)
    assert len(probabilities) == len(labels) == int(batch["mask"].sum())


@pytest.mark.parametrize("every", [False, True])
@pytest.mark.parametrize("column,value,pattern", [
    ("frd_tag", None, "missing labels"),
    (ACCOUNT, None, "missing identifiers"),
    ("transaction_dttm", None, "missing values"),
    ("transaction_dttm", "not-a-date", "unparseable"),
    ("transaction_dttm", 1704067200, "numeric units"),
])
def test_required_row_values_fail_before_encoding(fixture, every, column, value, pattern):
    options = {} if every else dict(emit_target_seq=False, all_position_layout=None, time_delta_reference="target")
    dataset = _dataset(fixture, **options)
    frame = fixture["frame"].copy()
    frame[column] = frame[column].astype(object)
    frame.loc[0, column] = value
    with pytest.raises(ValueError, match=pattern):
        dataset._encode_file(frame)


@pytest.mark.parametrize("every", [False, True])
def test_raw_only_features_do_not_require_unused_datetime_source(fixture, every):
    features = fixture["features"]
    features.categorical = ["c1", "c2"]
    features.derived = []
    features.frame = features.frame.loc[~features.frame.source.str.startswith("derived:")].copy()
    options = {} if every else dict(emit_target_seq=False, all_position_layout=None, time_delta_reference="target")
    dataset = _dataset(fixture, datetime_config=DatetimeConfig(order_col="not_projected"), **options)
    batches = list(dataset)
    assert batches
    labels = torch.cat([b["target_seq"][b["mask"]] if every else b["target"].reshape(-1) for b in batches])
    assert len(labels) == len(fixture["frame"])


@pytest.mark.parametrize("every", [False, True])
def test_timestamp_strings_are_ordered_chronologically_and_generic_labels_preserved(fixture, every):
    options = {} if every else dict(emit_target_seq=False, all_position_layout=None, time_delta_reference="target")
    dataset = _dataset(fixture, positive_label="fraud", **options)
    frame = fixture["frame"].iloc[:3].copy()
    frame["transaction_dttm"] = ["2024-01-01 2:00:00", "2024-01-01 10:00:00", "2024-01-01 1:00:00"]
    frame["frd_tag"] = ["normal", "fraud", "legitimate"]
    continuous, categorical, labels, times, parsed, metadata = dataset._encode_file(frame)
    assert labels.tolist() == [0, 1, 0]
    assert list(dataset._account_groups(parsed).values()) == [[2, 0, 1]]
