"""Reject invalid scoring cohorts before publishing metrics or prediction files."""

import importlib
from types import SimpleNamespace

import numpy as np
from omegaconf import OmegaConf
import pyarrow.fs as pafs
import pytest
import torch


class ProbeModel(torch.nn.Module):
    sequence_contract = None

    def on_load_checkpoint(self, checkpoint):
        pass

    def forward(self, values):
        x = values["continuous"][:, 0, 0]
        return torch.stack([x, -x], dim=1)


@pytest.mark.parametrize("phase", ["phase4a", "phase4b"])
@pytest.mark.parametrize("case", ["empty", "nonfinite", "one_class", "duplicate_ids", "null_ids"])
def test_bad_cohort_has_no_published_outputs(monkeypatch, tmp_path, phase, case):
    scorer = importlib.import_module(f"YOUR_PACKAGE.{phase}.scripts.score_sequential")
    batch = {
        "continuous": torch.tensor([[[2.0]], [[-2.0]]]),
        "categorical": torch.empty(2, 1, 0, dtype=torch.long),
        "mask": torch.ones(2, 1, dtype=torch.bool),
        "target": torch.tensor([0, 1]),
        "meta": {"transaction_id": np.array([101, 102])},
    }
    if case == "nonfinite":
        batch["continuous"][0, 0, 0] = float("nan")
    elif case == "one_class":
        batch["target"] = torch.zeros(2, dtype=torch.long)
    elif case == "duplicate_ids":
        batch["meta"]["transaction_id"] = np.array([101, 101])
    elif case == "null_ids":
        batch["meta"]["transaction_id"] = np.array([101, None], dtype=object)
    checkpoint = tmp_path / "best.ckpt"
    torch.save({"state_dict": {}}, checkpoint)
    predictions = tmp_path / "predictions"
    predictions.mkdir()
    metrics = tmp_path / "score_metrics.json"
    config = {
        "s3": {"cred_path": "unused"},
        "predictors": {"csv_path": "unused", "version": "synthetic"},
        "artifacts": {"base": "unused", "version": "synthetic"},
        "datetime": {"fields": [], "encoding": "categorical", "is_weekend": False},
        "model": {"type": "FTTransformerHier" if phase == "phase4b" else "FTTransformerSeq"},
        "data": {"order_col": "time", "target_col": "fraud", "account_col": "account",
                 "id_cols": ["transaction_id"]},
        "eval": {"base": "unused", "file_start": 1, "file_end": 1,
                 "checkpoint": str(checkpoint), "metrics_output": str(metrics),
                 "predictions_base": str(predictions), "compute_metrics": True},
        "sequence": {"history_len": 0},
        "preprocess": {"add_missing_flag": False},
        "training": {"batch_size": 2, "num_workers": 0},
    }
    path = tmp_path / "config.yaml"
    OmegaConf.save(OmegaConf.create(config), path)
    monkeypatch.setattr(scorer, "make_s3_filesystem", lambda cred: pafs.LocalFileSystem())
    monkeypatch.setattr(scorer, "load_feature_list", lambda *args, **kwargs: [])
    monkeypatch.setattr(scorer, "PreprocessingArtifacts", SimpleNamespace(load=lambda *a, **kw: None))
    monkeypatch.setattr(scorer, "DatetimeConfig", lambda **kwargs: None)
    monkeypatch.setattr(scorer, "build_file_list", lambda *args: [])
    monkeypatch.setattr(scorer, "SequenceBuilder", lambda **kwargs: [] if case == "empty" else [batch])
    monkeypatch.setattr(scorer, "build_sequential_model", lambda *args: ProbeModel())
    monkeypatch.setattr(scorer.sys, "argv", ["score_sequential.py", "--config", str(path)])
    expected = {
        "empty": "no.*transactions",
        "nonfinite": "finite|invalid probabilities",
        "one_class": "both.*classes",
        "duplicate_ids": "non-null and unique",
        "null_ids": "non-null and unique",
    }
    with pytest.raises(ValueError, match=expected[case]):
        scorer.main()
    assert not metrics.exists()
    assert not list(predictions.iterdir())
