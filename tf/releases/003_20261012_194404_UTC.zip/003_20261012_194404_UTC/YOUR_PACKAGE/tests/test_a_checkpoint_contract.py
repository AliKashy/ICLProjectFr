"""Reject shape-preserving model/input drift and exercise real A checkpoint scoring."""

import json
from pathlib import Path

import numpy as np
from omegaconf import OmegaConf
import pyarrow.fs as pafs
import pyarrow.parquet as pq
import pytest
import pytorch_lightning as pl
import torch
from torch.utils.data import DataLoader

from YOUR_PACKAGE.base.data.contracts import build_input_contract
from YOUR_PACKAGE.phase4a.factory import build_sequential_model
from YOUR_PACKAGE.phase4a.sequential import FTTransformerSeqModel
from YOUR_PACKAGE.phase4a.scripts import score_sequential as scorer
from YOUR_PACKAGE.tests.test_sequence_builder import _build, DATETIME_FIELDS

ROOT = Path(__file__).resolve().parents[2]


@pytest.fixture
def fixture(tmp_path, monkeypatch):
    torch.set_num_threads(1)
    # The checkpoint is scored by the owned A scorer, whose builder records the equal-time history rule in the
    # input contract (RUN-02, R-007), so the training dataset is built by the same owned builder.
    import YOUR_PACKAGE.tests.test_sequence_builder as reference_tests
    from YOUR_PACKAGE.phase4a.sequence_builder import SequenceBuilder as OwnedSequenceBuilder
    monkeypatch.setattr(reference_tests, "SequenceBuilder", OwnedSequenceBuilder)
    dataset, frame, _ = _build(tmp_path, history_len=3)
    assert dataset.history_time_order == "strict"
    cfg = OmegaConf.load(ROOT / "YOUR_PACKAGE/phase4a/configs/sequential.yaml")
    cfg.s3.cred_path = None
    cfg.sequence.history_len = 3
    cfg.sequence.attention_mask = "causal"
    cfg.model.input_embed_dim = 8
    cfg.model.num_heads = 2
    cfg.model.num_attn_blocks = 2
    cfg.model.attn_dropout = cfg.model.ff_dropout = 0.0
    cfg.training.batch_size = 4
    cfg.training.num_workers = 0
    cfg.training.pos_weight = 3.0
    cfg.predictors.csv_path = str(tmp_path / "predictors.csv")
    cfg.predictors.version = 1
    cfg.datetime.fields = DATETIME_FIELDS
    cfg.datetime.encoding = "categorical"
    cfg.datetime.is_weekend = False
    cfg.data.id_cols = ["fi_transaction_id"]
    cfg.data.amount_col = None
    cfg.eval.base = str(tmp_path)
    cfg.eval.file_start = cfg.eval.file_end = 1
    cfg.eval.predictions_base = str(tmp_path)
    cfg.eval.metrics_output = str(tmp_path / "metrics.json")
    cfg.eval.compute_metrics = True
    cfg.artifacts.base = str(tmp_path / "artifacts")
    cfg.artifacts.version = 1
    dataset.artifacts.save(str(tmp_path / "artifacts/1"))
    return dataset, frame, cfg


@pytest.mark.parametrize("drift", ["mask", "heads", "feature_order", "artifacts", "positive_label", "datetime"])
def test_shape_preserving_checkpoint_drift_is_rejected(fixture, drift):
    dataset, _, cfg = fixture
    original = build_sequential_model(cfg, dataset)
    checkpoint = {"state_dict": original.state_dict(), "hyper_parameters": dict(original.hparams)}
    original.on_save_checkpoint(checkpoint)
    if drift == "mask":
        cfg.sequence.attention_mask = "bidirectional"
    elif drift == "heads":
        cfg.model.num_heads = 4
    elif drift == "feature_order":
        dataset.continuous_cols[:2] = reversed(dataset.continuous_cols[:2])
    elif drift == "artifacts":
        dataset.artifacts.features["f1"]["mean"] += 1
    elif drift == "positive_label":
        dataset.positive_label = 0
    elif drift == "datetime":
        dataset.datetime_config.is_weekend = True
    changed = build_sequential_model(cfg, dataset)
    # Demonstrate why state_dict loading alone does not prove semantic identity.
    changed.load_state_dict(checkpoint["state_dict"], strict=True)
    with pytest.raises(ValueError, match="sequence_contract mismatch"):
        changed.on_load_checkpoint(checkpoint)


def test_legacy_checkpoint_compares_recorded_semantics_and_discloses_gap(fixture):
    dataset, _, cfg = fixture
    model = build_sequential_model(cfg, dataset)
    historical = {"state_dict": model.state_dict(), "hyper_parameters": dict(model.hparams)}
    with pytest.warns(UserWarning, match="artifact identity cannot be verified"):
        model.on_load_checkpoint(historical)
    historical["hyper_parameters"]["attention_mask"] = "bidirectional"
    with pytest.raises(ValueError, match="attention_mask"):
        model.on_load_checkpoint(historical)


def test_input_contract_uses_contents_and_is_independent_of_artifact_dict_order(fixture):
    dataset, _, _ = fixture
    expected = build_input_contract(dataset)
    dataset.artifacts.features = dict(reversed(list(dataset.artifacts.features.items())))
    assert build_input_contract(dataset) == expected
    dataset.artifacts.features["f1"]["mean"] += 1
    assert build_input_contract(dataset)["artifacts_sha256"] != expected["artifacts_sha256"]


def test_checkpoint_contract_is_an_independent_snapshot(fixture):
    dataset, _, cfg = fixture
    model = build_sequential_model(cfg, dataset)
    checkpoint = {}
    model.on_save_checkpoint(checkpoint)
    checkpoint["sequence_contract"]["input_contract"]["continuous_columns"].reverse()
    with pytest.raises(ValueError, match="sequence_contract mismatch"):
        model.on_load_checkpoint(checkpoint)


def test_real_train_reload_score_and_manual_mask_rejection(fixture, tmp_path, monkeypatch):
    dataset, frame, cfg = fixture
    model = build_sequential_model(cfg, dataset)
    loader = DataLoader(dataset, batch_size=None, num_workers=0)
    trainer = pl.Trainer(max_epochs=1, accelerator="cpu", devices=1, logger=False,
                         enable_checkpointing=False, enable_progress_bar=False,
                         enable_model_summary=False, num_sanity_val_steps=0,
                         limit_train_batches=2, limit_val_batches=2)
    trainer.fit(model, loader, loader)
    checkpoint = tmp_path / "trained.ckpt"
    trainer.save_checkpoint(checkpoint)
    restored = FTTransformerSeqModel.load_from_checkpoint(checkpoint).eval()
    model.eval()
    batch = next(iter(loader))
    with torch.no_grad():
        torch.testing.assert_close(model(batch), restored(batch), rtol=0, atol=0)
    cfg.eval.checkpoint = str(checkpoint)
    path = tmp_path / "score.yaml"
    OmegaConf.save(cfg, path)
    monkeypatch.setattr(scorer, "make_s3_filesystem", lambda _: pafs.LocalFileSystem())
    monkeypatch.setattr(scorer.sys, "argv", ["score", "--config", str(path)])
    scorer.main()
    metrics = json.loads(Path(cfg.eval.metrics_output).read_text())
    predictions = pq.read_table(metrics["predictions_path"]).to_pandas()
    assert metrics["n_predictions"] == len(frame) == len(predictions)
    assert metrics["n_positives"] == int(frame.frd_tag.sum())
    assert metrics["checkpoint_contract_verified"] is True
    assert metrics["sequence_contract"] == model.sequence_contract
    assert sorted(predictions.fi_transaction_id) == sorted(frame.fi_transaction_id)
    assert np.isfinite(predictions.score).all()
    before = {p.name for p in tmp_path.glob("*_preds.parquet")}
    old_metrics = Path(cfg.eval.metrics_output).read_bytes()
    cfg.sequence.attention_mask = "bidirectional"
    OmegaConf.save(cfg, path)
    with pytest.raises(ValueError, match="sequence_contract mismatch"):
        scorer.main()
    assert {p.name for p in tmp_path.glob("*_preds.parquet")} == before
    assert Path(cfg.eval.metrics_output).read_bytes() == old_metrics
