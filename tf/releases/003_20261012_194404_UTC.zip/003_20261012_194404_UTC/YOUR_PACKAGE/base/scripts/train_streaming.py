"""Train the streaming FT-Transformer (Phase 3).

Streams parquet files from S3 (never materializes the full dataset in memory),
applies the FROZEN preprocessing artifacts per batch, and trains with a
Lightning Trainer fed with IterableDataset DataLoaders. Ranking metrics are
computed over the full validation stream each epoch.

Usage:
    python YOUR_PACKAGE/base/scripts/train_streaming.py --config YOUR_PACKAGE/base/configs/streaming.yaml
    python YOUR_PACKAGE/base/scripts/train_streaming.py --config YOUR_PACKAGE/base/configs/streaming.yaml \
        training.max_epochs=2 training.batch_size=4096
"""

import argparse
import os
import sys

import pytorch_lightning as pl
import torch
from omegaconf import OmegaConf
from pytorch_lightning.callbacks import EarlyStopping, ModelCheckpoint
from torch.utils.data import DataLoader

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", ".."))

from fraud.callbacks import CSVMetricsCallback, StreamingBinaryMetrics
from fraud.data.datetime_features import DatetimeConfig
from YOUR_PACKAGE.base.data.contracts import build_input_contract
from YOUR_PACKAGE.base.data.checkpoint_contracts import FrozenInputContractCallback
from fraud.data.feature_list import load_feature_list
from YOUR_PACKAGE.base.data.parquet_loader import (
    ParquetStreamingDataset,
    streaming_categorical_cardinality,
    streaming_categorical_columns,
)
from fraud.data.preprocessing import PreprocessingArtifacts
from fraud.data.s3_utils import build_file_list, make_s3_filesystem
from fraud.log_utils import setup_logging
from YOUR_PACKAGE.base.streaming_model import build_streaming_model

log = setup_logging()


def _make_loader(cfg, files, artifacts, features, dt_config, shuffle_files, shuffle_rows, num_workers):
    dataset = ParquetStreamingDataset(
        file_list=files,
        artifacts=artifacts,
        features=features,
        datetime_config=dt_config,
        target_col=cfg.data.target_col,
        positive_label=cfg.data.get("positive_label", 1),
        add_missing_flag=cfg.preprocess.add_missing_flag,
        batch_size=cfg.training.batch_size,
        shuffle_files=shuffle_files,
        shuffle_rows=shuffle_rows,
        read_batch_size=int(cfg.training.get("read_batch_size", 65536)),
        s3_cred_path=cfg.s3.cred_path,
    )
    # batch_size=None: the dataset already yields whole batches.
    return DataLoader(dataset, batch_size=None, num_workers=num_workers)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("overrides", nargs="*")
    args = parser.parse_args()

    if int(os.environ.get("WORLD_SIZE", "1")) > 1:
        raise RuntimeError("Distributed training is unsupported: iterable datasets are not rank-sharded; launch one process/device")

    cfg = OmegaConf.load(args.config)
    if args.overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(args.overrides))

    if cfg.training.get("seed") is not None:
        pl.seed_everything(cfg.training.seed, workers=True)

    fs = make_s3_filesystem(cfg.s3.cred_path)

    features = load_feature_list(
        cfg.predictors.csv_path, version=cfg.predictors.version, filesystem=fs
    )

    artifacts_path = f"{cfg.artifacts.base.rstrip('/')}/{cfg.artifacts.version}"
    artifacts = PreprocessingArtifacts.load(artifacts_path, filesystem=fs)
    log.info("Loaded artifacts v%s (%d features) from %s",
             cfg.artifacts.version, len(artifacts.features), artifacts_path)

    dt_config = DatetimeConfig(
        order_col=cfg.data.order_col,
        fields=list(cfg.datetime.fields),
        encoding=cfg.datetime.encoding,
        is_weekend=cfg.datetime.is_weekend,
    )

    add_flag = cfg.preprocess.add_missing_flag
    categorical_cols = streaming_categorical_columns(features, add_flag)
    cardinalities = streaming_categorical_cardinality(artifacts, features, add_flag)
    log.info("Features: %d continuous, %d categorical (incl. %d _isna flags)",
             len(features.continuous), len(categorical_cols),
             len(features.continuous) if add_flag else 0)

    train_files = build_file_list(cfg.data.train_base, cfg.data.train_start, cfg.data.train_end)
    val_files = build_file_list(cfg.data.val_base, cfg.data.val_start, cfg.data.val_end)
    log.info("Streaming %d train file(s), %d val file(s)", len(train_files), len(val_files))

    num_workers = int(cfg.training.get("num_workers", 0))
    train_loader = _make_loader(cfg, train_files, artifacts, features, dt_config,
                                cfg.training.get("shuffle_files", True),
                                cfg.training.get("shuffle_rows", True), num_workers)
    val_loader = _make_loader(cfg, val_files, artifacts, features, dt_config, False, False, num_workers)

    model = build_streaming_model(
        model_cfg=cfg.model,
        cardinalities=cardinalities,
        continuous_cols=list(features.continuous),
        categorical_cols=categorical_cols,
        target_col=cfg.data.target_col,
        pos_weight=float(cfg.training.get("pos_weight", 1.0)),
        weight_decay=float(cfg.training.get("weight_decay", 1e-5)),
        learning_rate=float(cfg.training.get("learning_rate", 1e-3)),
        seed=int(cfg.training.get("seed", 42)),
    )

    save_path = cfg.output.checkpoint_dir
    os.makedirs(save_path, exist_ok=True)
    monitor, mode = cfg.training.monitor, cfg.training.monitor_mode
    callbacks = [
        FrozenInputContractCallback(build_input_contract(train_loader.dataset, categorical_cardinality=cardinalities)),
        # Compute valid_ap/valid_auroc first so the CSV row captures them.
        StreamingBinaryMetrics(pos_index=1),
        CSVMetricsCallback(os.path.join(save_path, "training_metrics.csv")),
        EarlyStopping(monitor=monitor, mode=mode,
                      patience=int(cfg.training.early_stopping_patience)),
        ModelCheckpoint(dirpath=save_path, filename="best", monitor=monitor, mode=mode,
                        save_last=True, enable_version_counter=False),
    ]

    logger = False
    exp_cfg = cfg.get("experiment", None)
    if exp_cfg is not None and exp_cfg.get("enabled", False):
        from pytorch_lightning.loggers import TensorBoardLogger
        logger = TensorBoardLogger(save_dir=exp_cfg.get("project_name", "tb_logs"),
                                   name=exp_cfg.get("run_name", "streaming"))
        log.info("TensorBoard logging enabled -> %s/", exp_cfg.get("project_name", "tb_logs"))

    trainer = pl.Trainer(
        max_epochs=int(cfg.training.max_epochs),
        accelerator=cfg.training.accelerator,
        devices=1,
        callbacks=callbacks,
        logger=logger,
        log_every_n_steps=int(cfg.training.get("log_every_n_steps", 50)),
        enable_progress_bar=True,
    )
    log.info("GPU available: %s", torch.cuda.is_available())
    trainer.fit(model, train_loader, val_loader)

    best = trainer.checkpoint_callback.best_model_path
    log.info("Best checkpoint: %s (%s=%s)", best, monitor,
             trainer.checkpoint_callback.best_model_score)
    log.info("Streaming training complete. Checkpoints in %s", save_path)


if __name__ == "__main__":
    main()
