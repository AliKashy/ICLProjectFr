"""Train the sequential (history-aware) FT-Transformer (Phase 4).

Streams account-grouped causal windows from S3 (frozen-artifact preprocessing),
and trains a flat SEP-token transformer via a Lightning Trainer. Ranking metrics
(valid_ap / valid_auroc) are computed over the full validation stream for early
stopping / checkpointing.

Usage:
    python YOUR_PACKAGE/base/scripts/train_sequential.py --config fraud/configs/sequential.yaml
    python YOUR_PACKAGE/base/scripts/train_sequential.py --config fraud/configs/sequential.yaml \
        sequence.history_len=5 training.batch_size=4096
"""

import argparse
import os
import sys

import pytorch_lightning as pl
import torch
from omegaconf import OmegaConf
from pytorch_lightning.callbacks import EarlyStopping, ModelCheckpoint
from torch.utils.data import DataLoader

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", ".."))

from fraud.callbacks import CSVMetricsCallback, StreamingBinaryMetrics
from fraud.data.datetime_features import DatetimeConfig
from YOUR_PACKAGE.base.data.contracts import build_input_contract
from fraud.data.feature_list import load_feature_list
from fraud.data.preprocessing import PreprocessingArtifacts
from fraud.data.s3_utils import build_file_list, make_s3_filesystem
from YOUR_PACKAGE.base.data.sequence_builder import SequenceBuilder
from fraud.log_utils import setup_logging
from YOUR_PACKAGE.base.sequential_model import FTTransformerSeqModel

log = setup_logging()


def _make_loader(cfg, files, artifacts, features, dt_config, shuffle, stride, num_workers):
    dataset = SequenceBuilder(
        file_list=files,
        artifacts=artifacts,
        features=features,
        datetime_config=dt_config,
        target_col=cfg.data.target_col,
        account_col=cfg.data.account_col,
        order_col=cfg.data.order_col,
        history_len=int(cfg.sequence.history_len),
        stride=int(stride),
        positive_label=cfg.data.get("positive_label", 1),
        add_missing_flag=cfg.preprocess.add_missing_flag,
        time_delta=bool(cfg.sequence.get("time_delta", True)),
        batch_size=int(cfg.training.batch_size),
        shuffle=shuffle,
        buffer_windows=int(cfg.training.get("buffer_windows", 65536)),
        tie_break_col=cfg.data.get("tie_break_col", None),
        s3_cred_path=cfg.s3.cred_path,
    )
    return DataLoader(dataset, batch_size=None, num_workers=num_workers)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("overrides", nargs="*")
    args = parser.parse_args()

    if int(os.environ.get("WORLD_SIZE", "1")) > 1:
        raise RuntimeError("Distributed training is unsupported: iterable datasets are not rank-sharded; launch one process/device")

    cfg = OmegaConf.load(args.config)
    if args.overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(args.overrides))

    if cfg.training.get("seed") is not None:
        pl.seed_everything(cfg.training.seed, workers=True)

    fs = make_s3_filesystem(cfg.s3.cred_path)
    features = load_feature_list(
        cfg.predictors.csv_path, version=cfg.predictors.version, filesystem=fs
    )
    artifacts_path = f"{cfg.artifacts.base.rstrip('/')}/{cfg.artifacts.version}"
    artifacts = PreprocessingArtifacts.load(artifacts_path, filesystem=fs)
    log.info("Loaded artifacts v%s (%d features) from %s",
             cfg.artifacts.version, len(artifacts.features), artifacts_path)

    dt_config = DatetimeConfig(
        order_col=cfg.data.order_col,
        fields=list(cfg.datetime.fields),
        encoding=cfg.datetime.encoding,
        is_weekend=cfg.datetime.is_weekend,
    )

    train_files = build_file_list(cfg.data.train_base, cfg.data.train_start, cfg.data.train_end)
    val_files = build_file_list(cfg.data.val_base, cfg.data.val_start, cfg.data.val_end)
    num_workers = int(cfg.training.get("num_workers", 0))
    train_loader = _make_loader(cfg, train_files, artifacts, features, dt_config,
                                True, cfg.sequence.get("train_stride", 1), num_workers)
    val_loader = _make_loader(cfg, val_files, artifacts, features, dt_config,
                              False, cfg.sequence.get("eval_stride", 1), num_workers)

    # Dimensions come from the builder (continuous incl. time-delta, cats + flags).
    probe = train_loader.dataset
    log.info("Sequence: history_len=%d, T=%d, continuous=%d, categorical=%d",
             probe.history_len, probe.T, len(probe.continuous_cols), len(probe.categorical_cols))

    model = FTTransformerSeqModel(
        continuous_dim=len(probe.continuous_cols),
        categorical_cardinality=probe.categorical_cardinality,
        history_len=int(cfg.sequence.history_len),
        embed_dim=int(cfg.model.input_embed_dim),
        num_heads=int(cfg.model.num_heads),
        num_attn_blocks=int(cfg.model.num_attn_blocks),
        attn_dropout=float(cfg.model.attn_dropout),
        ff_dropout=float(cfg.model.ff_dropout),
        attention_mask=cfg.sequence.get("attention_mask", "bidirectional"),
        learning_rate=float(cfg.training.get("learning_rate", 3e-4)),
        weight_decay=float(cfg.training.get("weight_decay", 1e-5)),
        pos_weight=float(cfg.training.get("pos_weight", 1.0)),
        input_contract=build_input_contract(probe),
    )

    save_path = cfg.output.checkpoint_dir
    os.makedirs(save_path, exist_ok=True)
    monitor, mode = cfg.training.monitor, cfg.training.monitor_mode
    callbacks = [
        StreamingBinaryMetrics(pos_index=1),
        CSVMetricsCallback(os.path.join(save_path, "training_metrics.csv")),
        EarlyStopping(monitor=monitor, mode=mode,
                      patience=int(cfg.training.early_stopping_patience)),
        ModelCheckpoint(dirpath=save_path, filename="best", monitor=monitor, mode=mode,
                        save_last=True, enable_version_counter=False),
    ]

    logger = False
    exp_cfg = cfg.get("experiment", None)
    if exp_cfg is not None and exp_cfg.get("enabled", False):
        from pytorch_lightning.loggers import TensorBoardLogger
        logger = TensorBoardLogger(save_dir=exp_cfg.get("project_name", "tb_logs"),
                                   name=exp_cfg.get("run_name", "sequential"))
        log.info("TensorBoard logging enabled -> %s/", exp_cfg.get("project_name", "tb_logs"))

    trainer = pl.Trainer(
        max_epochs=int(cfg.training.max_epochs),
        accelerator=cfg.training.accelerator,
        devices=1,
        precision=cfg.training.get("precision", "bf16-mixed"),
        accumulate_grad_batches=int(cfg.training.get("accumulate_grad_batches", 1)),
        callbacks=callbacks,
        logger=logger,
        log_every_n_steps=int(cfg.training.get("log_every_n_steps", 50)),
        enable_progress_bar=True,
    )
    log.info("GPU available: %s | precision=%s", torch.cuda.is_available(),
             cfg.training.get("precision", "bf16-mixed"))
    trainer.fit(model, train_loader, val_loader)

    best = trainer.checkpoint_callback.best_model_path
    log.info("Best checkpoint: %s (%s=%s)", best, monitor,
             trainer.checkpoint_callback.best_model_score)
    log.info("Sequential training complete. Checkpoints in %s", save_path)


if __name__ == "__main__":
    main()
