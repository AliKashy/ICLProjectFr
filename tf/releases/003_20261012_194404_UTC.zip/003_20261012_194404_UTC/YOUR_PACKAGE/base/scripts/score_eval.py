"""Score a trained baseline model over an S3 parquet range and write predictions.

Streams parquet files one at a time (memory-safe), applies the SAME preprocessing
as training (datetime derivation + the saved continuous imputer + the model's own
fitted scalers/encoders/label-encoder), scores on GPU when available, and writes
per-file prediction parquet files containing the id column(s), true label, fraud
score, raw amount, and predicted class.

Global ranking metrics (PR-AUC / ROC-AUC) can then be computed cheaply from these
outputs -- with sklearn if the scored range fits in memory, or with Spark on the
CPU platform for the full-scale eval (hundreds of millions of rows).

Usage:
    python YOUR_PACKAGE/base/scripts/score_eval.py --config fraud/configs/eval.yaml
    python YOUR_PACKAGE/base/scripts/score_eval.py --config fraud/configs/eval.yaml \
        data.file_start=8000 data.file_end=8010
"""

import argparse
import os
import sys

import joblib
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import torch
from omegaconf import OmegaConf
from sklearn.metrics import average_precision_score, roc_auc_score

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", ".."))

from pytorch_tabular import TabularModel

from fraud.data.datetime_features import DatetimeConfig, derive_datetime_features
from fraud.data.feature_list import load_feature_list
from YOUR_PACKAGE.base.data.input_contracts import encode_binary_target, parse_required_timestamps
from fraud.data.s3_utils import build_file_list, make_s3_filesystem, strip_scheme
from fraud.log_utils import setup_logging

log = setup_logging()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("overrides", nargs="*")
    args = parser.parse_args()

    cfg = OmegaConf.load(args.config)
    if args.overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(args.overrides))

    fs = make_s3_filesystem(cfg.s3.cred_path)

    # Feature list + datetime config (must match training).
    features = load_feature_list(
        cfg.predictors.csv_path, version=cfg.predictors.version, filesystem=fs
    )
    dt_config = DatetimeConfig(
        order_col=cfg.data.order_col,
        fields=list(cfg.datetime.fields),
        encoding=cfg.datetime.encoding,
        is_weekend=cfg.datetime.is_weekend,
    )

    target_col = cfg.data.target_col
    pos_label = cfg.data.get("positive_label", 1)
    id_cols = list(cfg.data.get("id_cols", []))
    amount_col = cfg.data.get("amount_col", None)

    # Load the trained model + the fitted continuous imputer.
    model = TabularModel.load_model(cfg.model.dir)
    imputer = joblib.load(cfg.preprocess.imputer_path)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    if device == "cuda":
        log.info("Scoring device: cuda | GPU: %s", torch.cuda.get_device_name(0))
    else:
        log.warning("Scoring device: cpu | CUDA not available, inference will be slow")
    prob_col = f"{target_col}_{pos_label}_probability"
    pred_col = f"{target_col}_prediction"

    # Raw parquet columns: feature sources + target + ids + amount.
    read_cols = features.raw_source_columns()
    if features.derived and dt_config.order_col not in read_cols:
        read_cols.append(dt_config.order_col)
    for extra in [target_col, amount_col, *id_cols]:
        if extra and extra not in read_cols:
            read_cols.append(extra)

    # Categorical columns the model expects as strings (raw cats + missing flags).
    categorical_cols = list(features.categorical) + list(imputer.flag_cols_)

    out_base = cfg.output.base.rstrip("/")
    compute_metrics = bool(cfg.output.get("compute_metrics", False))
    all_true, all_score = [], []

    files = build_file_list(cfg.data.base, cfg.data.file_start, cfg.data.file_end)
    log.info("Scoring %d file(s) on %s -> %s", len(files), device, out_base)
    gpu_confirmed = False

    for path in files:
        part = os.path.basename(path)
        df = pq.ParquetDataset(strip_scheme(path), filesystem=fs).read(
            columns=read_cols
        ).to_pandas()

        # Capture raw outputs before any transform.
        y_true = encode_binary_target(df[target_col], pos_label, target_col)
        amount = df[amount_col].to_numpy() if amount_col else None
        ids = {c: df[c].to_numpy() for c in id_cols}

        # Same preprocessing as training.
        if features.derived:
            df[dt_config.order_col] = parse_required_timestamps(
                df[dt_config.order_col], dt_config.order_col,
            )
            df, _, _ = derive_datetime_features(df, dt_config)
        df = imputer.transform(df)
        for col in categorical_cols:
            df[col] = df[col].astype(str)

        pred_df = model.predict(df, device=device)
        score = pred_df[prob_col].to_numpy()

        if device == "cuda" and not gpu_confirmed:
            log.info("GPU confirmed: model on %s, %.1f MB allocated",
                     model.model.device, torch.cuda.memory_allocated(0) / 1e6)
            gpu_confirmed = True

        out = pd.DataFrame({**ids,
                            target_col: y_true,
                            "score": score,
                            "prediction": pred_df[pred_col].to_numpy()})
        if amount_col:
            out[amount_col] = amount

        out_path = strip_scheme(f"{out_base}/{part}")
        pq.write_table(pa.Table.from_pandas(out, preserve_index=False),
                       out_path, filesystem=fs)
        log.info("%s: %d rows, positives=%d -> %s", part, len(out), int(y_true.sum()), out_path)

        if compute_metrics:
            all_true.append(y_true)
            all_score.append(score)

    if compute_metrics and all_true:
        y_true = np.concatenate(all_true)
        y_score = np.concatenate(all_score)
        ap = average_precision_score(y_true, y_score)
        auc = roc_auc_score(y_true, y_score)
        log.info("Range metrics (fraud = positive): average_precision=%.4f  auroc=%.4f  "
                 "(n=%d, positives=%d)", ap, auc, len(y_true), int(y_true.sum()))


if __name__ == "__main__":
    main()
