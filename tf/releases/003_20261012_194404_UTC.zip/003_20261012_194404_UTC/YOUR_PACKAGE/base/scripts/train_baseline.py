"""Train baseline FT-Transformer on individual transactions (smoke test).

Reads the versioned predictor list, streams the configured parquet files from
S3, derives datetime features, imputes continuous NaNs (median + missing flag),
and trains an FT-Transformer reporting PR-AUC + ROC-AUC.

Usage:
    python YOUR_PACKAGE/base/scripts/train_baseline.py --config fraud/configs/smoke_test.yaml
    python YOUR_PACKAGE/base/scripts/train_baseline.py --config fraud/configs/smoke_test.yaml \
        training.max_epochs=3 data.train_end=5
"""

import argparse
import os
import sys

import joblib
import pandas as pd
import pyarrow.parquet as pq
import torch
from omegaconf import OmegaConf
from sklearn.metrics import average_precision_score, roc_auc_score

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", ".."))

from pytorch_tabular import TabularModel
from pytorch_tabular.config import DataConfig, TrainerConfig, OptimizerConfig, ExperimentConfig
from pytorch_tabular.models import FTTransformerConfig

from fraud.callbacks import CSVMetricsCallback
from fraud.data.datetime_features import DatetimeConfig, derive_datetime_features
from fraud.data.feature_list import load_feature_list
from YOUR_PACKAGE.base.data.input_contracts import encode_binary_target, parse_required_timestamps
from fraud.data.preprocessing import ContinuousImputer
from fraud.data.s3_utils import build_file_list, make_s3_filesystem, strip_scheme
from fraud.log_utils import setup_logging

log = setup_logging()


# --- Full-split binary evaluation ----------------------------------------------
# Ranking metrics (PR-AUC / ROC-AUC) are NOT computable per mini-batch on rare
# events: at ~0.16% fraud most 256-row batches contain zero positives, so
# torchmetrics returns 0 and PyTorch Tabular's per-batch averaging collapses the
# score. We therefore monitor `valid_loss` during training (which averages
# correctly) and compute the authoritative AP/AUROC over the FULL split from
# predict(), whose output includes a `{target}_{class}_probability` column.
def evaluate_split(model, df, target_col, pos_label, split_name, device=None):
    y_true = encode_binary_target(df[target_col], pos_label, target_col)
    pred_df = model.predict(df, device=device)
    prob_col = f"{target_col}_{pos_label}_probability"
    y_score = pred_df[prob_col].to_numpy()
    ap = average_precision_score(y_true, y_score)
    auc = roc_auc_score(y_true, y_score)
    log.info("%s: average_precision=%.4f  auroc=%.4f  (n=%d, positives=%d)",
             split_name, ap, auc, len(y_true), int(y_true.sum()))
    return {"average_precision": float(ap), "auroc": float(auc)}


def _read_split(base, start, end, columns, filesystem):
    """Read `columns` from an inclusive range of part files and concatenate."""
    files = build_file_list(base, start, end)
    frames = []
    for path in files:
        p = strip_scheme(path) if filesystem is not None else path
        df = pq.ParquetDataset(p, filesystem=filesystem).read(columns=columns).to_pandas()
        frames.append(df)
        log.info("Loaded %s: %d rows", os.path.basename(path), len(df))
    return pd.concat(frames, ignore_index=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("overrides", nargs="*")
    args = parser.parse_args()

    cfg = OmegaConf.load(args.config)
    if args.overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(args.overrides))

    fs = make_s3_filesystem(cfg.s3.cred_path)

    # Feature list (source of truth), typed + version-filtered.
    features = load_feature_list(
        cfg.predictors.csv_path, version=cfg.predictors.version, filesystem=fs
    )
    target_col = cfg.data.target_col
    pos_label = cfg.data.get("positive_label", 1)
    dt_config = DatetimeConfig(
        order_col=cfg.data.order_col,
        fields=list(cfg.datetime.fields),
        encoding=cfg.datetime.encoding,
        is_weekend=cfg.datetime.is_weekend,
    )

    # Raw parquet columns to read = source columns for all features + target.
    read_cols = features.raw_source_columns()
    if features.derived and dt_config.order_col not in read_cols:
        read_cols.append(dt_config.order_col)
    if target_col not in read_cols:
        read_cols = read_cols + [target_col]

    log.info("Loading train...")
    train_df = _read_split(cfg.data.train_base, cfg.data.train_start,
                           cfg.data.train_end, read_cols, fs)
    log.info("Loading validation...")
    val_df = _read_split(cfg.data.val_base, cfg.data.val_start,
                         cfg.data.val_end, read_cols, fs)
    log.info("Loading test...")
    test_df = _read_split(cfg.data.test_base, cfg.data.test_start,
                          cfg.data.test_end, read_cols, fs)
    log.info("Train: %d, Val: %d, Test: %d", len(train_df), len(val_df), len(test_df))

    # Labels must be known before any fitting. Keep original class values for
    # the model's label encoder; evaluation maps positive versus the rest.
    for frame in (train_df, val_df, test_df):
        encode_binary_target(frame[target_col], pos_label, target_col)
        if features.derived:
            frame[dt_config.order_col] = parse_required_timestamps(
                frame[dt_config.order_col], dt_config.order_col,
            )
    # A raw-only predictor schema does not require an unused datetime column.
    if features.derived:
        train_df, _, _ = derive_datetime_features(train_df, dt_config)
        val_df, _, _ = derive_datetime_features(val_df, dt_config)
        test_df, _, _ = derive_datetime_features(test_df, dt_config)

    # Continuous imputation (fit on train) + optional missing-indicator flags.
    imputer = ContinuousImputer(
        strategy=cfg.preprocess.impute_strategy,
        add_flag=cfg.preprocess.add_missing_flag,
    )
    imputer.fit(train_df, features.continuous)
    train_df = imputer.transform(train_df)
    val_df = imputer.transform(val_df)
    test_df = imputer.transform(test_df)

    continuous_cols = list(features.continuous)
    # Missing-indicator flags are binary -> treat as categorical.
    categorical_cols = list(features.categorical) + list(imputer.flag_cols_)

    # Categorical columns must be object/str for the fork's encoder.
    for col in categorical_cols:
        for d in (train_df, val_df, test_df):
            d[col] = d[col].astype(str)

    n_features = len(continuous_cols) + len(features.categorical)
    log.info("Continuous: %d, Categorical: %d, missing-flags: %d | base feature count: %d",
             len(continuous_cols), len(features.categorical), len(imputer.flag_cols_), n_features)

    # Configure
    data_config = DataConfig(
        target=[target_col],
        continuous_cols=continuous_cols,
        categorical_cols=categorical_cols,
        handle_missing_values=True,
        handle_unknown_categories=True,
        normalize_continuous_features=True,
    )

    model_config = FTTransformerConfig(
        task=cfg.training.task,
        input_embed_dim=cfg.model.input_embed_dim,
        num_heads=cfg.model.num_heads,
        num_attn_blocks=cfg.model.num_attn_blocks,
        attn_dropout=cfg.model.attn_dropout,
        ff_dropout=cfg.model.ff_dropout,
    )

    trainer_config = TrainerConfig(
        max_epochs=cfg.training.max_epochs,
        accelerator=cfg.training.accelerator,
        batch_size=cfg.training.batch_size,
        early_stopping=cfg.training.monitor,
        early_stopping_mode=cfg.training.monitor_mode,
        early_stopping_patience=cfg.training.early_stopping_patience,
        checkpoints=cfg.training.monitor,
        checkpoints_mode=cfg.training.monitor_mode,
        load_best=True,
        # Lightning's step-cadence for scalar logging (default 50). This is
        # separate from ExperimentConfig.exp_log_freq (gradient/param watch).
        trainer_kwargs={"log_every_n_steps": int(cfg.training.get("log_every_n_steps", 50))},
    )

    optimizer_config = OptimizerConfig(
        optimizer=cfg.training.optimizer,
        optimizer_params={"weight_decay": cfg.training.weight_decay},
        lr_scheduler="ReduceLROnPlateau",
        lr_scheduler_params={"patience": 3, "factor": 0.5},
    )

    # Optional TensorBoard experiment tracking (config-gated). Writes event files
    # under experiment.project_name/; view with `tensorboard --logdir <name>`.
    experiment_config = None
    exp_cfg = cfg.get("experiment", None)
    if exp_cfg is not None and exp_cfg.get("enabled", False):
        experiment_config = ExperimentConfig(
            project_name=exp_cfg.get("project_name", "tb_logs"),
            run_name=exp_cfg.get("run_name", None),
            log_target=exp_cfg.get("log_target", "tensorboard"),
            exp_log_freq=exp_cfg.get("log_freq", 100),
        )
        log.info("TensorBoard logging enabled -> %s/ (view: tensorboard --logdir %s)",
                 experiment_config.project_name, experiment_config.project_name)

    # Train. Early stopping / checkpointing monitor `valid_loss` (see config);
    # ranking metrics are computed post-hoc over the full splits below.
    tabular_model = TabularModel(
        data_config=data_config,
        model_config=model_config,
        optimizer_config=optimizer_config,
        trainer_config=trainer_config,
        experiment_config=experiment_config,
    )

    # Per-epoch training metrics -> CSV for terminal progress viewing.
    save_path = cfg.output.checkpoint_dir
    metrics_csv = os.path.join(save_path, "training_metrics.csv")
    tabular_model.fit(train=train_df, validation=val_df,
                      callbacks=[CSVMetricsCallback(metrics_csv)])
    log.info("Per-epoch metrics logged to %s", metrics_csv)

    # Evaluate: authoritative binary AP/AUROC over the FULL validation and test
    # splits (correct for rare-event ranking, unlike per-batch metrics).
    # Score on GPU when available -- predict() defaults to CPU otherwise.
    device = "cuda" if torch.cuda.is_available() else "cpu"
    if device == "cuda":
        log.info("Scoring device: cuda | GPU: %s", torch.cuda.get_device_name(0))
    else:
        log.warning("Scoring device: cpu | CUDA not available, inference will be slow")
    log.info("Full-split metrics (fraud = positive class):")
    evaluate_split(tabular_model, val_df, target_col, pos_label, "valid", device)
    test_metrics = evaluate_split(tabular_model, test_df, target_col, pos_label, "test", device)
    if device == "cuda":
        log.info("GPU confirmed: model on %s, %.1f MB allocated",
                 tabular_model.model.device, torch.cuda.memory_allocated(0) / 1e6)
    for k, v in test_metrics.items():
        log.info("test_%s: %.4f", k, v)

    # Save model + the fitted continuous imputer (needed for standalone scoring
    # so evaluation preprocessing matches training exactly).
    tabular_model.save_model(save_path)
    joblib.dump(imputer, os.path.join(save_path, "continuous_imputer.joblib"))
    log.info("Model saved to %s", save_path)


if __name__ == "__main__":
    main()
