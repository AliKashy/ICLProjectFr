"""Score the streaming FT-Transformer checkpoint over an S3 parquet range.

Rebuilds the model architecture from the frozen artifacts, loads the trained
Lightning checkpoint's weights, streams the eval range one batch at a time with
identical artifact preprocessing, scores on GPU, and writes per-file prediction
parquet files. This validates the frozen-artifact path end-to-end.

Each invocation requires unused per-file destinations. Set
``eval.predictions_base=<unique attempt root>``; existing predictions are refused.

Usage:
    python YOUR_PACKAGE/base/scripts/score_streaming.py --config YOUR_PACKAGE/base/configs/streaming.yaml
    python YOUR_PACKAGE/base/scripts/score_streaming.py --config YOUR_PACKAGE/base/configs/streaming.yaml \
        eval.file_start=8000 eval.file_end=8010
"""

import argparse
import os
import sys

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import torch
from omegaconf import OmegaConf
from sklearn.metrics import average_precision_score, roc_auc_score

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", ".."))

from fraud.data.datetime_features import DatetimeConfig
from YOUR_PACKAGE.base.data.contracts import build_input_contract
from YOUR_PACKAGE.base.data.checkpoint_contracts import validate_input_contract
from fraud.data.feature_list import load_feature_list
from YOUR_PACKAGE.base.data.parquet_loader import (
    ParquetStreamingDataset,
    streaming_categorical_cardinality,
    streaming_categorical_columns,
)
from fraud.data.preprocessing import PreprocessingArtifacts
from fraud.data.s3_utils import build_file_list, make_s3_filesystem, strip_scheme
from fraud.log_utils import setup_logging
from YOUR_PACKAGE.base.streaming_model import build_streaming_model

log = setup_logging()


def _load_model_checkpoint(model, checkpoint):
    """Validate shape-preserving settings and feature order before strict reload."""
    saved = checkpoint.get("hyper_parameters")
    if saved is None:
        raise ValueError("Streaming checkpoint lacks architecture hyper_parameters")
    keys = ("_model_name", "task", "target", "continuous_cols", "categorical_cols",
            "continuous_dim", "categorical_dim", "categorical_cardinality", "output_dim",
            "input_embed_dim", "num_heads", "num_attn_blocks", "attn_dropout", "ff_dropout",
            "ff_hidden_multiplier", "transformer_head_dim", "transformer_activation",
            "head", "head_config", "embedding_bias", "share_embedding", "share_embedding_strategy",
            "shared_embedding_fraction", "batch_norm_continuous_input", "normalize_continuous_features")
    for key in keys:
        if key not in saved or saved[key] != model.hparams[key]:
            raise ValueError(f"Streaming checkpoint/config mismatch: {key}")
    # CE weights are buffers, not architecture hparams in the vendored model.
    current = model.state_dict()
    for key in ("custom_loss.weight", "loss.weight"):
        trained, configured = checkpoint["state_dict"].get(key), current.get(key)
        if (trained is None) != (configured is None) or (trained is not None and
                not torch.equal(trained.cpu(), configured.cpu())):
            raise ValueError("Streaming checkpoint/config mismatch: training.pos_weight")
    model.load_state_dict(checkpoint["state_dict"], strict=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("overrides", nargs="*")
    args = parser.parse_args()

    cfg = OmegaConf.load(args.config)
    if args.overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(args.overrides))

    fs = make_s3_filesystem(cfg.s3.cred_path)
    files = build_file_list(cfg.eval.base, cfg.eval.file_start, cfg.eval.file_end)
    if not files:
        raise ValueError("Evaluation file range is empty or reversed")
    out_base = cfg.eval.predictions_base.rstrip("/")
    # Preserve the per-file output layout, but require a fresh destination for
    # each invocation. Owners select an attempt via eval.predictions_base.
    for path in files:
        destination = strip_scheme(f"{out_base}/{os.path.basename(path)}")
        if fs.exists(destination):
            raise FileExistsError("Prediction destination already exists; choose a new eval.predictions_base attempt root")
    features = load_feature_list(
        cfg.predictors.csv_path, version=cfg.predictors.version, filesystem=fs
    )
    artifacts_path = f"{cfg.artifacts.base.rstrip('/')}/{cfg.artifacts.version}"
    artifacts = PreprocessingArtifacts.load(artifacts_path, filesystem=fs)
    dt_config = DatetimeConfig(
        order_col=cfg.data.order_col,
        fields=list(cfg.datetime.fields),
        encoding=cfg.datetime.encoding,
        is_weekend=cfg.datetime.is_weekend,
    )

    add_flag = cfg.preprocess.add_missing_flag
    categorical_cols = streaming_categorical_columns(features, add_flag)
    cardinalities = streaming_categorical_cardinality(artifacts, features, add_flag)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = build_streaming_model(
        model_cfg=cfg.model,
        cardinalities=cardinalities,
        continuous_cols=list(features.continuous),
        categorical_cols=categorical_cols,
        target_col=cfg.data.target_col,
        pos_weight=float(cfg.training.get("pos_weight", 1.0)),
    )
    # Our own checkpoint stores an OmegaConf DictConfig -> weights_only=False.
    ckpt = torch.load(cfg.eval.checkpoint, map_location=device, weights_only=False)
    _load_model_checkpoint(model, ckpt)
    model.eval().to(device)
    log.info("Loaded checkpoint %s on %s", cfg.eval.checkpoint, device)

    # An encoder instance reused per batch (shares artifact preprocessing).
    encoder = ParquetStreamingDataset(
        file_list=[], artifacts=artifacts, features=features, datetime_config=dt_config,
        target_col=cfg.data.target_col, positive_label=cfg.data.get("positive_label", 1),
        add_missing_flag=add_flag,
    )
    validate_input_contract(ckpt, build_input_contract(encoder, categorical_cardinality=cardinalities))

    target_col = cfg.data.target_col
    pos_label = cfg.data.get("positive_label", 1)
    id_cols = list(cfg.data.get("id_cols", []))
    amount_col = cfg.data.get("amount_col", None)
    read_cols = list(encoder._read_cols)
    for extra in [amount_col, *id_cols]:
        if extra and extra not in read_cols:
            read_cols.append(extra)

    compute_metrics = bool(cfg.eval.get("compute_metrics", False))
    all_true, all_score = [], []

    log.info("Scoring %d file(s) on %s -> %s", len(files), device, out_base)

    for path in files:
        part = os.path.basename(path)
        pf = pq.ParquetFile(strip_scheme(path), filesystem=fs)
        scores, ids, amounts, targets = [], {c: [] for c in id_cols}, [], []
        for rb in pf.iter_batches(batch_size=cfg.training.batch_size, columns=read_cols):
            df = rb.to_pandas()
            cont, cat, tgt = encoder._encode_batch(df)
            with torch.no_grad():
                logits = model({"continuous": torch.from_numpy(cont).to(device),
                                "categorical": torch.from_numpy(cat).to(device)})["logits"]
                prob = torch.softmax(logits, dim=-1)[:, 1].cpu().numpy()
            scores.append(prob)
            targets.append(tgt.ravel())
            for c in id_cols:
                ids[c].append(df[c].to_numpy())
            if amount_col:
                amounts.append(df[amount_col].to_numpy())

        if not scores:
            raise ValueError(f"Evaluation file contains no transactions: {part}")
        score = np.concatenate(scores)
        y_true = np.concatenate(targets)
        if not np.isfinite(score).all() or np.any((score < 0) | (score > 1)):
            raise ValueError("Evaluation scores must be finite probabilities in [0, 1]")
        out = {c: np.concatenate(ids[c]) for c in id_cols}
        out[target_col] = y_true
        out["score"] = score
        if amount_col:
            out[amount_col] = np.concatenate(amounts)

        out_path = strip_scheme(f"{out_base}/{part}")
        if fs.exists(out_path):
            raise FileExistsError("Prediction destination appeared during scoring; choose a fresh attempt root")
        pq.write_table(pa.table(out), out_path, filesystem=fs)
        log.info("%s: %d rows, positives=%d -> %s", part, len(score), int(y_true.sum()), out_path)

        if compute_metrics:
            all_true.append(y_true)
            all_score.append(score)

    if compute_metrics and all_true:
        y_true = np.concatenate(all_true)
        y_score = np.concatenate(all_score)
        if len(np.unique(y_true)) != 2:
            raise ValueError("Evaluation AP/AUROC reporting requires both target classes")
        ap = average_precision_score(y_true, y_score)
        auc = roc_auc_score(y_true, y_score)
        log.info("Range metrics (fraud = positive): average_precision=%.4f  auroc=%.4f  "
                 "(n=%d, positives=%d)", ap, auc, len(y_true), int(y_true.sum()))


if __name__ == "__main__":
    main()
