"""Build an FT-Transformer for the streaming path (hand-built InferredConfig).

The in-memory baseline lets PyTorch Tabular infer data dimensions from the
training DataFrame. The streaming path has no such DataFrame, so we build the
``InferredConfig`` directly from the frozen artifacts: categorical cardinalities
come from the artifact vocabs (``n_categories + 2`` plus 2 per ``isna`` flag.
The model is instantiated directly (no ``prepare_model``) and fed pre-encoded
batch dicts by the streaming DataLoader.
"""

import dataclasses
import inspect
from typing import List, Optional

import torch
from omegaconf import OmegaConf

from pytorch_tabular import TabularModel
from pytorch_tabular.config import (
    DataConfig,
    InferredConfig,
    OptimizerConfig,
    TrainerConfig,
)
from pytorch_tabular.models import FTTransformerConfig
from pytorch_tabular.models.ft_transformer.ft_transformer import FTTransformerModel


def _inferred_config_fields() -> set:
    """Field names InferredConfig accepts in the installed pytorch_tabular."""
    if dataclasses.is_dataclass(InferredConfig):
        return {f.name for f in dataclasses.fields(InferredConfig)}
    return set(inspect.signature(InferredConfig).parameters)


def build_inferred_config(cardinalities: List[int], n_continuous: int,
                          n_categorical: int) -> InferredConfig:
    embedding_dims = [(c, min(50, (c + 1) // 2)) for c in cardinalities]
    kwargs = dict(
        categorical_dim=n_categorical,
        continuous_dim=n_continuous,
        output_dim=2,
        categorical_cardinality=list(cardinalities),
        embedding_dims=embedding_dims,
    )
    # pytorch_tabular 1.1.1 and later require output_cardinality (one entry per
    # target: a binary target has 2 classes); the bundled 1.1.0 rejects it. Pass
    # it exactly when the installed version declares the field.
    if "output_cardinality" in _inferred_config_fields():
        kwargs["output_cardinality"] = [2]
    return InferredConfig(**kwargs)


def build_streaming_model(
    model_cfg,
    cardinalities: List[int],
    continuous_cols: List[str],
    categorical_cols: List[str],
    target_col: str,
    pos_weight: float = 1.0,
    weight_decay: float = 1e-5,
    learning_rate: float = 1e-3,
    seed: int = 42,
) -> FTTransformerModel:
    """Construct an FTTransformerModel for streaming training.

    ``model_cfg`` is the OmegaConf ``model`` node (input_embed_dim, num_heads,
    num_attn_blocks, attn_dropout, ff_dropout). ``pos_weight`` > 1 applies a
    weighted CrossEntropyLoss on the positive (fraud) class. Optimizer matches
    the baseline: AdamW(weight_decay) + ReduceLROnPlateau.
    """
    data_config = DataConfig(
        target=[target_col],
        continuous_cols=list(continuous_cols),
        categorical_cols=list(categorical_cols),
        # Continuous are already standardized by the frozen artifacts.
        normalize_continuous_features=False,
    )
    model_config = FTTransformerConfig(
        task="classification",
        input_embed_dim=model_cfg.input_embed_dim,
        num_heads=model_cfg.num_heads,
        num_attn_blocks=model_cfg.num_attn_blocks,
        attn_dropout=model_cfg.attn_dropout,
        ff_dropout=model_cfg.ff_dropout,
        learning_rate=learning_rate,
    )
    optimizer_config = OptimizerConfig(
        optimizer="AdamW",
        optimizer_params={"weight_decay": weight_decay},
        lr_scheduler="ReduceLROnPlateau",
        lr_scheduler_params={"patience": 3, "factor": 0.5},
    )
    trainer_config = TrainerConfig(seed=seed)

    # TabularModel merges the configs into one DictConfig without touching data.
    tm = TabularModel(
        data_config=data_config,
        model_config=model_config,
        optimizer_config=optimizer_config,
        trainer_config=trainer_config,
    )

    inferred = build_inferred_config(cardinalities, len(continuous_cols), len(categorical_cols))

    loss: Optional[torch.nn.Module] = None
    if pos_weight and pos_weight != 1.0:
        loss = torch.nn.CrossEntropyLoss(weight=torch.tensor([1.0, float(pos_weight)]))

    model = FTTransformerModel(
        tm.config,
        # safe_merge_config expects an OmegaConf object, not the raw dataclass.
        inferred_config=OmegaConf.structured(inferred),
        custom_loss=loss,
    )
    return model
