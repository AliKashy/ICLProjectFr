"""Streaming Parquet dataset for large-scale tabular fraud data in S3.

Reads parquet files lazily via pyarrow and yields **whole-batch** tensor dicts
(use ``DataLoader(batch_size=None)``) without loading the full dataset into
memory. Preprocessing is applied per batch from the FROZEN preprocessing
artifacts so training/eval/inference are identical:

- continuous: median-impute + z-score (``standardize_continuous``)
- categorical: vocab index with reserved ``0=UNK`` / ``1=MISSING``
  (``encode_categorical``)
- ``<col>_isna`` flags: derived from the raw continuous (pre-impute) as
  deterministic binaries ``{False: 0, True: 1}`` (no UNK/MISSING needed)

Each yielded batch is ``{"continuous": FloatTensor[B, n],
"categorical": LongTensor[B, m], "target": LongTensor[B, 1]}`` — the dict the
FT-Transformer's ``forward``/``training_step`` expect.
"""

from typing import List, Optional

import numpy as np
import pyarrow.parquet as pq
import torch
from torch.utils.data import IterableDataset

from fraud.data.datetime_features import DatetimeConfig, derive_datetime_features
from fraud.data.feature_list import FeatureList
from YOUR_PACKAGE.base.data.input_contracts import encode_binary_target, parse_required_timestamps
from fraud.data.preprocessing import PreprocessingArtifacts
from fraud.data.s3_utils import make_s3_filesystem, strip_scheme


def missing_flag_columns(continuous_cols: List[str]) -> List[str]:
    """``<col>_isna`` flag column names, one per continuous feature."""
    return [f"{c}_isna" for c in continuous_cols]


def streaming_categorical_columns(features: FeatureList, add_missing_flag: bool) -> List[str]:
    """Categorical column order the model sees: artifact cats + ``_isna`` flags."""
    cols = list(features.categorical)
    if add_missing_flag:
        cols += missing_flag_columns(features.continuous)
    return cols


def streaming_categorical_cardinality(
    artifacts: PreprocessingArtifacts, features: FeatureList, add_missing_flag: bool
) -> List[int]:
    """Per-categorical vocab sizes: artifact ``cardinality``, then 2 per flag."""
    cards = [artifacts.features[c]["cardinality"] for c in features.categorical]
    if add_missing_flag:
        cards += [2] * len(features.continuous)  # {False:0, True:1}
    return cards


class ParquetStreamingDataset(IterableDataset):
    """Stream fraud transactions from parquet, applying frozen artifacts.

    Args:
        file_list: Parquet file paths (with or without ``s3://`` scheme).
        artifacts: Loaded ``PreprocessingArtifacts`` for encode/standardize.
        features: ``FeatureList`` (continuous/categorical order + order_col).
        datetime_config: Config for deriving datetime features per batch.
        target_col: Raw target column name.
        positive_label: Raw value of the positive (fraud) class.
        add_missing_flag: Append ``<col>_isna`` categorical flags.
        batch_size: Rows per yielded (mini-)batch.
        shuffle_files: Shuffle file order each epoch.
        shuffle_rows: Shuffle rows within each read block before batching, so
            consecutive (account/time-clustered) rows don't correlate a batch.
        read_batch_size: Rows read per block from parquet; the shuffle pool.
            Clamped to at least ``batch_size``.
        s3_filesystem: Optional s3fs filesystem for S3 access.
        s3_cred_path: If given (and no filesystem), each worker builds its own
            s3fs from this credentials file (s3fs is not fork-safe to share).
    """

    def __init__(
        self,
        file_list: List[str],
        artifacts: PreprocessingArtifacts,
        features: FeatureList,
        datetime_config: DatetimeConfig,
        target_col: str,
        positive_label=1,
        add_missing_flag: bool = True,
        batch_size: int = 8192,
        shuffle_files: bool = True,
        shuffle_rows: bool = False,
        read_batch_size: int = 65536,
        s3_filesystem=None,
        s3_cred_path: Optional[str] = None,
    ):
        self.file_list = file_list
        self.artifacts = artifacts
        self.features = features
        self.datetime_config = datetime_config
        self.target_col = target_col
        self.positive_label = positive_label
        self.add_missing_flag = add_missing_flag
        self.batch_size = batch_size
        self.shuffle_files = shuffle_files
        self.shuffle_rows = shuffle_rows
        # Read large blocks, then shuffle rows within a block before batching, so
        # consecutive (account/time-clustered) rows don't correlate a mini-batch.
        self.read_batch_size = max(read_batch_size, batch_size)
        self.s3_filesystem = s3_filesystem
        self.s3_cred_path = s3_cred_path

        self.continuous_cols = list(features.continuous)
        self.categorical_cols = streaming_categorical_columns(features, add_missing_flag)
        self.flag_cols = missing_flag_columns(self.continuous_cols) if add_missing_flag else []
        self._derive_datetime = bool(features.derived)
        read_cols = list(features.raw_source_columns())
        if self._derive_datetime and datetime_config.order_col not in read_cols:
            read_cols.append(datetime_config.order_col)
        if target_col not in read_cols:
            read_cols.append(target_col)
        self._read_cols = read_cols

    def _ensure_fs(self):
        # Built lazily so each DataLoader worker gets its own (non-shared) s3fs.
        if self.s3_filesystem is None and self.s3_cred_path is not None:
            self.s3_filesystem = make_s3_filesystem(self.s3_cred_path)
        return self.s3_filesystem

    def _get_worker_files(self):
        worker_info = torch.utils.data.get_worker_info()
        files = list(self.file_list)
        if worker_info is not None:
            files = files[worker_info.id :: worker_info.num_workers]
        # Workers have independent RNG states. Assign disjoint shards before
        # shuffling so independent permutations cannot omit or duplicate files.
        if self.shuffle_files:
            np.random.shuffle(files)
        return files

    def _encode_batch(self, df):
        target = encode_binary_target(
            df[self.target_col], self.positive_label, self.target_col,
        )
        # Raw-only predictor lists need no timestamp. When datetime predictors
        # are selected, chronology must be valid before feature derivation.
        if self._derive_datetime:
            df = df.copy()
            df[self.datetime_config.order_col] = parse_required_timestamps(
                df[self.datetime_config.order_col], self.datetime_config.order_col,
            )
            df, _, _ = derive_datetime_features(df, self.datetime_config)

        # ``_isna`` flags come from the RAW continuous, before imputation.
        flags = {c: df[c].isna().to_numpy().astype(np.int64) for c in self.continuous_cols} \
            if self.add_missing_flag else {}

        cont = np.stack(
            [self.artifacts.standardize_continuous(c, df[c]) for c in self.continuous_cols],
            axis=1,
        ).astype(np.float32)

        cat_arrays = [self.artifacts.encode_categorical(c, df[c]) for c in self.features.categorical]
        if self.add_missing_flag:
            cat_arrays += [flags[c] for c in self.continuous_cols]
        cat = np.stack(cat_arrays, axis=1).astype(np.int64)

        # PyTorch Tabular indexes the target as y[:, i] -> keep it 2-D [B, 1].
        return cont, cat, target.reshape(-1, 1)

    def __iter__(self):
        fs = self._ensure_fs()
        for filepath in self._get_worker_files():
            path = strip_scheme(filepath) if fs is not None else filepath
            pf = pq.ParquetFile(path, filesystem=fs)
            for record_batch in pf.iter_batches(batch_size=self.read_batch_size, columns=self._read_cols):
                df = record_batch.to_pandas()
                cont, cat, target = self._encode_batch(df)
                n = len(target)
                order = np.random.permutation(n) if self.shuffle_rows else np.arange(n)
                for start in range(0, n, self.batch_size):
                    idx = order[start:start + self.batch_size]
                    yield {
                        "continuous": torch.from_numpy(cont[idx]),
                        "categorical": torch.from_numpy(cat[idx]),
                        "target": torch.from_numpy(target[idx]),
                    }
