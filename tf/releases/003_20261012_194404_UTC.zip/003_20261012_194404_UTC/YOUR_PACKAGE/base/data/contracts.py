"""Checkpoint identity for the actual model inputs and loaded preprocessing."""

import hashlib
import json
from dataclasses import asdict


def build_input_contract(dataset, *, categorical_cardinality=None):
    """Bind ordered inputs and artifact contents, independent of storage location.

    Sequence loaders expose categorical_cardinality directly; streaming callers
    may pass their computed cardinalities. This records active fitted artifacts,
    not credentials, source transactions, or mutable URI/version labels.
    """
    active_features = list(dataset.features.all_features)
    artifact_payload = {name: dataset.artifacts.features[name] for name in active_features}
    digest = hashlib.sha256()
    encoder = json.JSONEncoder(sort_keys=True, separators=(",", ":"), allow_nan=False)
    for part in encoder.iterencode(artifact_payload):
        digest.update(part.encode("utf-8"))
    cards = dataset.categorical_cardinality if categorical_cardinality is None else categorical_cardinality
    contract = {
        "continuous_columns": list(dataset.continuous_cols),
        "categorical_columns": list(dataset.categorical_cols),
        "categorical_cardinality": list(cards),
        "artifacts_sha256": digest.hexdigest(),
        "datetime": asdict(dataset.datetime_config),
        "account_col": getattr(dataset, "account_col", None),
        "order_col": getattr(dataset, "order_col", None),
        "tie_break_col": getattr(dataset, "tie_break_col", None),
        "target_col": dataset.target_col,
        "positive_label": dataset.positive_label,
    }
    if hasattr(dataset, "history_time_order"):
        # RUN-02 (R-007): a checkpoint trained under one equal-time history rule is
        # scored under the same rule; streaming loaders have no history window.
        contract["history_time_order"] = dataset.history_time_order
    return contract
