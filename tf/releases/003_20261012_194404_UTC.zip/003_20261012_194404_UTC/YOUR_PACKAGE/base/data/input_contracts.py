"""Required row identity, label and event-time contracts for dataset loaders.

Feature imputation handles missing predictor values; it must not invent labels,
account membership, or chronology. These checks run before encoding/windowing.
"""

from numbers import Number

import numpy as np
import pandas as pd


def encode_binary_target(values, positive_label, column):
    """Encode a declared positive class versus other observed, nonmissing labels.

    Negative labels need not be numeric zero (for example ``legitimate`` or -1).
    A batch/file with one class is valid; a missing label is not a negative label.
    """
    values = pd.Series(values, copy=False)
    if not np.isscalar(positive_label) or pd.isna(positive_label):
        raise ValueError("positive_label must be a nonmissing scalar")
    missing = int(values.isna().sum())
    if missing:
        raise ValueError(f"Target column {column!r} contains {missing} missing labels")
    return values.eq(positive_label).to_numpy(dtype=np.int64)


def require_account_ids(values, column):
    """Fail rather than invent or silently omit an account for an input row."""
    missing = int(pd.Series(values, copy=False).isna().sum())
    if missing:
        raise ValueError(f"Account column {column!r} contains {missing} missing identifiers")


def parse_required_timestamps(values, column):
    """Parse complete event times without guessing numeric units or timezones.

    Preserve a consistent supplied timezone for calendar feature derivation.
    Numeric timestamps require explicit conversion with the known source unit
    before ingestion; pandas otherwise silently interprets them as nanoseconds.
    """
    values = pd.Series(values, copy=False)
    missing = int(values.isna().sum())
    if missing:
        raise ValueError(f"Timestamp column {column!r} contains {missing} missing values")
    numeric = pd.api.types.is_numeric_dtype(values.dtype)
    if pd.api.types.is_object_dtype(values.dtype):
        numeric = numeric or values.map(lambda value: isinstance(value, Number)).any()
    if numeric:
        raise ValueError(f"Timestamp column {column!r} requires explicit conversion of numeric units")
    try:
        timestamps = pd.to_datetime(values, errors="coerce")
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Timestamp column {column!r} must use parseable times with one timezone") from exc
    invalid = int(timestamps.isna().sum())
    if invalid:
        raise ValueError(f"Timestamp column {column!r} contains {invalid} unparseable values")
    if not pd.api.types.is_datetime64_any_dtype(timestamps.dtype):
        raise ValueError(f"Timestamp column {column!r} must use one timezone or all naive values")
    return timestamps
