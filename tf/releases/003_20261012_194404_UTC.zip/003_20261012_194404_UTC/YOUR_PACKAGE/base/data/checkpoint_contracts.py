"""Persist and validate baseline frozen preprocessing identity at checkpoints."""

import warnings

from pytorch_lightning import Callback


INPUT_CONTRACT_KEY = "fraud_input_contract"


def validate_input_contract(checkpoint, current):
    saved = checkpoint.get(INPUT_CONTRACT_KEY)
    if saved is None:
        if current is not None:
            warnings.warn("Legacy checkpoint has no frozen input contract: feature/artifact identity is unverified; "
                          "use the original frozen artifacts and do not treat this as a fully bound comparison", RuntimeWarning)
    elif saved != current:
        raise ValueError("Checkpoint frozen input contract mismatch: features, artifacts or preprocessing semantics changed")


class FrozenInputContractCallback(Callback):
    """Bind the vendored streaming model without changing third-party model code."""

    def __init__(self, contract):
        super().__init__()
        self.contract = contract

    def on_save_checkpoint(self, trainer, pl_module, checkpoint):
        checkpoint[INPUT_CONTRACT_KEY] = self.contract

    def on_load_checkpoint(self, trainer, pl_module, checkpoint):
        validate_input_contract(checkpoint, self.contract)
