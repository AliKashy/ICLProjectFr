"""Periodic (Fourier-feature) embeddings for continuous features.

Per Gorishniy et al., "On Embeddings for Numerical Features" (NeurIPS 2022,
arXiv:2203.05556). Phase-local copy — does not touch the fraud/ base.
"""

import math

import torch
import torch.nn as nn


class PeriodicNumericalEmbedding(nn.Module):
    """Each x_j -> [sin(2π c_jk x_j), cos(2π c_jk x_j)]_k -> Linear -> token."""

    def __init__(self, n_features: int, embed_dim: int, n_frequencies: int = 16, sigma: float = 1.0):
        super().__init__()
        self.n_features = n_features
        self.coeffs = nn.Parameter(torch.randn(n_features, n_frequencies) * sigma)
        self.proj = nn.Linear(2 * n_frequencies, embed_dim)

    def forward(self, x):  # x [N, C] -> [N, C, d]
        v = 2.0 * math.pi * x.unsqueeze(-1) * self.coeffs  # [N, C, F]
        feats = torch.cat([torch.sin(v), torch.cos(v)], dim=-1)  # [N, C, 2F]
        return self.proj(feats)
