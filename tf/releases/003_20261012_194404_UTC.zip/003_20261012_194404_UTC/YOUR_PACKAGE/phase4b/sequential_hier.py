"""Hierarchical (two-stage) sequential FT-Transformer — Phase 4 Architecture B.

Encodes **each transaction independently** with a shared token-level
FT-Transformer into one vector per transaction, then runs a small **sequence
transformer** over the N+1 transaction vectors (+ transaction-position) whose
CLS output predicts the target's fraud probability.

Cheaper attention than the flat SEP-token model: O((N+1)^2) over transaction
vectors instead of O(((N+1) * tokens_per_txn)^2) over all feature tokens — scales
to longer histories. Reuses the validated per-transaction tokenizer
(``TransactionEmbedding``) from the flat model as its stage-1 component.

Batch dict (from ``SequenceBuilder``) is identical to the flat model:
    continuous  [B, T, C] float   (C incl. time-delta)
    categorical [B, T, K] long
    mask        [B, T]    bool    (True = real transaction)
    target      [B, 1]    long

The optional all-position head instead requires the explicit disjoint-chunk
builder contract. It returns [B,T,2], consumes target_seq[B,T] only at real
slots and uses backward interarrival gaps. Context resets at chunk/file
boundaries and ranges from 0..H; it is not equivalent to H-history sliding
windows. See YOUR_PACKAGE/phase4b/ALL_POSITION_CONTRACT.md.

All-position time policy (V1 build item B9): with ``history_time_order='strict'``
the batch also carries ``time_seq[B,T]`` (int64 parsed timestamps, ns) and each
real position attends only to itself and to positions of its chunk whose
timestamp is strictly earlier than its own; a same-time neighbour is never
visible, in either direction. Its position embedding is indexed by the number of
real rows of its chunk with a strictly earlier timestamp (not by its chunk slot),
so a same-time neighbour cannot reveal its existence by shifting the row's slot.
Strict chunks are cut only between whole seconds and hold up to H+1 distinct seconds
(B9 amendment, DESIGN_V1 section 6.3 (b)), so they can hold more than T = H+1 rows:
a strict batch may be wider than T (padded to its widest chunk), and the position
index is clamped to T-1 = H, the last row of the position table. The clamp reads
only the strictly-earlier count, so it reveals nothing about same-time rows.
A strict model refuses a batch narrower than T or a chunk holding more than H+1 distinct
whole seconds (review R2), so a builder/model history_len mismatch fails loudly.
``'tiebreak'`` keeps the earlier positional rule (position j sees positions 0..j,
position embedding = chunk slot) and the fixed width T. The policy is part of
``sequence_contract``.
"""

from typing import List
import warnings

import pytorch_lightning as pl
import torch
import torch.nn as nn

from YOUR_PACKAGE.phase4b.tokenizer import FeatureTokenizer
from YOUR_PACKAGE.phase4b.optim import build_optimizer


# All-position time policies (V1 build item B9). Versioned in sequence_contract so a
# checkpoint trained under one policy is refused when scored under the other. The gap
# entry is replaced by "none" when the model has no time-gap input.
ALL_POSITION_TIME_POLICIES = {
    "strict": {
        "history_time_order": "strict",
        "attention": "self_and_strictly_earlier_timestamp_in_chunk",
        "time_gap": "log1p_seconds_since_latest_strictly_earlier_timestamp_in_chunk_else_0",
        "timestamp_input": "time_seq",
        "position_index": "count_of_strictly_earlier_real_rows_in_chunk_clamped_to_history_len",
        # B9 amendment (reviewer-model-data-1 B1): chunks are cut only between whole seconds, up to
        # history_len + 1 distinct seconds each, so a same-second sibling cannot move a row to another chunk.
        "chunking": "distinct_seconds",
    },
    "tiebreak": {
        "history_time_order": "tiebreak",
        "attention": "self_and_earlier_positions_in_chunk",
        "time_gap": "log1p_seconds_since_previous_row_in_chunk_else_0",
        "timestamp_input": "none",
        "position_index": "chunk_slot",
    },
}
ALL_POSITION_CONTRACT_VERSION = 2  # 1: positional mask and previous-row gap, no time policy entry
# The strict entry gained "chunking" and the clamped position index in the B9 amendment; a strict checkpoint
# written before it (row-count chunks) has a different policy dict and is refused. tiebreak is unchanged.


def _encoder(embed_dim, num_heads, num_layers, ff_multiplier, attn_dropout, ff_dropout):
    layer = nn.TransformerEncoderLayer(
        d_model=embed_dim,
        nhead=num_heads,
        dim_feedforward=embed_dim * ff_multiplier,
        dropout=ff_dropout,
        activation="gelu",
        batch_first=True,
        norm_first=True,
    )
    layer.self_attn.dropout = attn_dropout
    return nn.TransformerEncoder(layer, num_layers=num_layers)


class FTTransformerHierModel(pl.LightningModule):
    def __init__(
        self,
        continuous_dim: int,
        categorical_cardinality: List[int],
        history_len: int,
        embed_dim: int = 48,
        num_heads: int = 8,
        num_txn_blocks: int = 2,
        num_seq_blocks: int = 4,
        ff_multiplier: int = 4,
        attn_dropout: float = 0.1,
        ff_dropout: float = 0.1,
        attention_mask: str = "bidirectional",
        learning_rate: float = 3e-4,
        weight_decay: float = 1e-5,
        pos_weight: float = 1.0,
        continuous_embedding: str = "linear",
        num_frequencies: int = 16,
        optimizer: str = "adamw",
        predict_every_transaction: bool = False,
        all_position_layout: str = None,
        time_delta_reference: str = "target",
        input_contract: dict = None,
        history_time_order: str = None,
    ):
        super().__init__()
        if attention_mask not in ("bidirectional", "causal"):
            raise ValueError("attention_mask must be 'bidirectional' or 'causal'")
        if predict_every_transaction and attention_mask != "causal":
            # Bidirectional would let every transaction-vector see the future
            # (including the target), so "this transaction's own prediction"
            # would be leaking -- causal is a hard requirement for this mode.
            raise ValueError(
                "predict_every_transaction=True requires attention_mask='causal'"
            )
        if predict_every_transaction and (
            all_position_layout != "nonoverlapping_chunks"
            or time_delta_reference not in ("previous_transaction", "none")
        ):
            raise ValueError("All-position mode requires the explicit nonoverlapping_chunks / backward-time contract")
        if predict_every_transaction and history_time_order not in ALL_POSITION_TIME_POLICIES:
            raise ValueError(
                "All-position mode requires an explicit history_time_order in "
                f"{sorted(ALL_POSITION_TIME_POLICIES)} (ALL_POSITION_CONTRACT.md), got {history_time_order!r}"
            )
        if not predict_every_transaction and history_time_order is not None:
            raise ValueError("history_time_order is a model setting of all-position mode only; "
                             "single-target windows carry the rule in the builder's input contract")
        self.save_hyperparameters()
        self.T = history_len + 1
        self.tokens_per_txn = continuous_dim + len(categorical_cardinality)
        self.attention_mask = attention_mask

        self.embedding = FeatureTokenizer(continuous_dim, categorical_cardinality, embed_dim,
                                              continuous_embedding, num_frequencies)
        # Stage 1: per-transaction CLS pools feature tokens -> one vector per txn.
        self.txn_cls = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.token_encoder = _encoder(
            embed_dim, num_heads, num_txn_blocks, ff_multiplier, attn_dropout, ff_dropout
        )
        # Stage 2: sequence CLS over transaction vectors predicts the target.
        self.txn_position = nn.Embedding(self.T, embed_dim)
        self.seq_cls = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.seq_encoder = _encoder(
            embed_dim, num_heads, num_seq_blocks, ff_multiplier, attn_dropout, ff_dropout
        )
        self.head = nn.Linear(embed_dim, 2)
        nn.init.normal_(self.txn_cls, std=0.02)
        nn.init.normal_(self.seq_cls, std=0.02)

        weight = None
        if pos_weight and pos_weight != 1.0:
            weight = torch.tensor([1.0, float(pos_weight)])
        self.loss_fn = nn.CrossEntropyLoss(weight=weight)

    @property
    def _strict_time_mask(self):
        return bool(self.hparams.predict_every_transaction) and self.hparams.get("history_time_order") == "strict"

    @property
    def sequence_contract(self):
        """Persist semantic compatibility: tensor shapes alone cannot prove it."""
        contract = {
            "version": 1,
            "predict_every_transaction": bool(self.hparams.predict_every_transaction),
            "layout": self.hparams.all_position_layout or "sliding_target",
            "history_len": int(self.hparams.history_len),
            "time_delta_reference": self.hparams.time_delta_reference,
            "attention_mask": self.hparams.attention_mask,
            "architecture": {key: self.hparams[key] for key in (
                "continuous_dim", "categorical_cardinality", "embed_dim", "num_heads",
                "num_txn_blocks", "num_seq_blocks", "ff_multiplier", "attn_dropout",
                "ff_dropout", "continuous_embedding", "num_frequencies",
            )},
            "input_contract": self.hparams.input_contract,
        }
        if self.hparams.predict_every_transaction:
            # B9: the timestamp mask and gap rule are semantics a same-shape checkpoint
            # cannot reveal. Single-target contracts are left exactly as before.
            policy = dict(ALL_POSITION_TIME_POLICIES[self.hparams.history_time_order])
            if self.hparams.time_delta_reference == "none":
                policy["time_gap"] = "none"
            contract["version"] = ALL_POSITION_CONTRACT_VERSION
            contract["all_position_time_policy"] = policy
        return contract

    def on_save_checkpoint(self, checkpoint):
        checkpoint["sequence_contract"] = self.sequence_contract

    def on_load_checkpoint(self, checkpoint):
        saved = checkpoint.get("sequence_contract")
        if saved is None:
            # Existing single-target checkpoints keep working. Old all-position
            # checkpoints used overlapping labels and future-relative gaps, so
            # they cannot be relabeled as this experiment merely by loading them.
            historical = checkpoint.get("hyper_parameters", {})
            old_every = historical.get("predict_every_transaction", False)
            if self.hparams.predict_every_transaction or old_every:
                raise ValueError("All-position checkpoint is missing the required sequence_contract; retrain this mode")
            for key in (*self.sequence_contract["architecture"], "history_len", "attention_mask"):
                if key in historical and historical[key] != self.hparams[key]:
                    raise ValueError(f"Checkpoint model hyperparameter mismatch: {key}")
            warnings.warn(
                "Legacy single-target checkpoint has no sequence_contract; feature/artifact identity cannot be verified",
                UserWarning,
            )
        elif saved != self.sequence_contract:
            raise ValueError(f"Checkpoint sequence_contract mismatch: {saved} != {self.sequence_contract}")

    def _build_causal_mask(self, device, key_padding=None, times=None):
        # FIX (bug #2, same CLS causal-mask leak as Architecture A -- see
        # YOUR_PACKAGE/phase4a/sequential.py for the full writeup): give seq_CLS txn_of =
        # self.T (one slot after every real transaction-vector) instead of the
        # original -1 + `tj<0 | ti<0` special case, which let any transaction-vector
        # attend back to seq_CLS (which legitimately saw the whole sequence,
        # including the target, as a query) -- leaking future-relative information
        # back into "earlier" transaction representations from layer 2 onward.
        # Single rule `tj <= ti` now covers everything correctly (see phase4a for
        # the exact case-by-case derivation).
        # Strict chunks can be wider than self.T (B9 amendment); every other path keeps width self.T.
        T = self.T if times is None else times.shape[1]
        L = 1 + T
        txn_of = torch.full((L,), T, dtype=torch.long, device=device)  # seq_CLS slot defaults to T
        txn_of[1:] = torch.arange(T, device=device)
        ti = txn_of.unsqueeze(1)
        tj = txn_of.unsqueeze(0)
        disallowed = ~(tj <= ti)  # True = disallowed
        if times is not None:
            # B9 strict time rule (all-position, history_time_order='strict'): a transaction
            # query i may read key j only when j == i or time_j < time_i. Same-time
            # neighbours are mutually invisible and later rows stay invisible. The CLS
            # rules above are kept: seq_CLS reads everything, no transaction reads seq_CLS.
            # Padding is removed below through key_padding, as in the positional rule.
            if key_padding is None:
                raise ValueError("The strict time mask needs the padding mask")
            B = times.shape[0]
            # Only real rows take part: padding carries time 0, which is later than a pre-1970 (negative)
            # real timestamp, so a padded query would otherwise read real keys.
            real = ~key_padding[:, 1:]  # [B, T]
            earlier = (times.unsqueeze(1) < times.unsqueeze(2)) & real.unsqueeze(1) & real.unsqueeze(2)
            # [B, T, T]: [b, i, j] = rows i and j are real and time_j < time_i
            allowed = disallowed.logical_not().unsqueeze(0).repeat(B, 1, 1)  # [B, L, L]
            allowed[:, 1:, 1:] = earlier | torch.eye(T, dtype=torch.bool, device=device).unsqueeze(0)
            disallowed = ~allowed
        if key_padding is None:
            return disallowed
        # FIX (NaN / corrupt-gradient guard, found via external audit review -- see
        # YOUR_PACKAGE/phase4a/sequential.py for the full writeup): merge per-sample padding
        # into the causal mask and force the diagonal open so a padded transaction
        # slot's query row never ends up with every key disallowed.
        if disallowed.dim() == 2:
            disallowed = disallowed.unsqueeze(0)
        merged = disallowed | key_padding.unsqueeze(1)  # [B, L, L]
        diag = torch.eye(L, dtype=torch.bool, device=device).unsqueeze(0)
        merged = merged & ~diag
        float_mask = torch.zeros(merged.shape, dtype=torch.float32, device=device)
        float_mask.masked_fill_(merged, float("-inf"))
        return float_mask.repeat_interleave(self.hparams.num_heads, dim=0)  # [B*num_heads, L, L]

    def forward(self, batch):
        continuous, categorical, mask = batch["continuous"], batch["categorical"], batch["mask"]
        B, T, C = continuous.shape
        # Strict all-position chunks hold up to T distinct seconds, so a batch can be wider than T
        # (B9 amendment) but never narrower (builder chunks are at least T wide); every other mode keeps the
        # fixed width T. A builder/model history_len mismatch is also caught in _checked_times (review R2).
        if (T < self.T if self._strict_time_mask else T != self.T) or mask.shape != (B, T):
            raise ValueError("Input sequence dimensions do not match the configured history_len")
        K = categorical.shape[-1]
        d = self.hparams.embed_dim

        # -- stage 1: encode each transaction independently (shared weights) --
        tokens = self.embedding(
            continuous.reshape(B * T, C), categorical.reshape(B * T, K)
        )  # [B*T, tokens_per_txn, d]
        cls = self.txn_cls.expand(B * T, 1, d)
        tok_seq = torch.cat([cls, tokens], dim=1)  # [B*T, 1+tokens_per_txn, d]
        txn_vec = self.token_encoder(tok_seq)[:, 0]  # CLS -> [B*T, d]
        txn_vec = txn_vec.reshape(B, T, d)

        # -- stage 2: sequence transformer over transaction vectors --
        times = self._checked_times(batch, mask) if self._strict_time_mask else None
        if times is None:
            pos = self.txn_position(torch.arange(T, device=continuous.device))[None, :, :]  # [1, T, d]
        else:
            # Strict: a row's slot index is the number of real strictly-earlier rows of its chunk, so a
            # same-second peer that sorts before it (by tie-break id) cannot move its position embedding.
            earlier = (times.unsqueeze(1) < times.unsqueeze(2)) & mask.unsqueeze(1)  # [b, i, j]
            # A chunk of up to T distinct seconds can hold more than T-1 strictly-earlier rows when earlier
            # seconds hold ties; clamp to the last table row (a function of the strictly-earlier count only).
            pos = self.txn_position(earlier.sum(-1).clamp(max=self.T - 1))  # [B, T, d]
        txn_vec = txn_vec + pos
        seq_cls = self.seq_cls.expand(B, 1, d)
        seq = torch.cat([seq_cls, txn_vec], dim=1)  # [B, 1+T, d]

        key_padding = torch.cat(
            [torch.zeros(B, 1, dtype=torch.bool, device=mask.device), ~mask], dim=1
        )  # True = ignore padded transactions (seq_CLS always valid)
        if self.attention_mask == "causal":
            # Padding is merged into the mask itself (see _build_causal_mask), so
            # src_key_padding_mask is NOT also passed here -- avoids double-masking.
            attn_mask = self._build_causal_mask(seq.device, key_padding, times)
            out = self.seq_encoder(seq, mask=attn_mask)
        else:
            out = self.seq_encoder(seq, src_key_padding_mask=key_padding)
        self._cls = out[:, 0]  # cached seq-CLS for embed()
        if self.hparams.predict_every_transaction:
            # One prediction per transaction-vector (out[:,0] is seq_CLS, skip it).
            return self.head(out[:, 1:])  # [B, T, 2]
        return self.head(self._cls)  # seq_CLS -> [B, 2]

    def _checked_times(self, batch, mask):
        """Per-position timestamps for the strict all-position mask (training and scoring alike)."""
        times = batch.get("time_seq")
        if times is None:
            raise ValueError("Strict all-position mode needs batch['time_seq'] (per-position timestamps) "
                             "in training and scoring alike")
        if times.shape != mask.shape:
            raise ValueError("time_seq must have the same [batch, time] shape as mask")
        times = times.to(device=mask.device, dtype=torch.long)
        # Real slots are left aligned and sorted by time; a decrease means the mask would be built on misaligned times.
        both_real = mask[:, 1:] & mask[:, :-1]
        if bool((both_real & (times[:, 1:] < times[:, :-1])).any()):
            raise ValueError("time_seq is not chronological over the real positions of a chunk")
        # Review R2: a strict chunk holds at most T = history_len + 1 distinct whole seconds. More means the
        # builder used another history_len or cut chunks by rows; the width check alone cannot see that.
        # floor matches numpy's datetime64[ns] -> [s] conversion, which floors negative times too.
        sec = torch.div(times, 10**9, rounding_mode="floor")
        seconds_per_chunk = mask[:, 0].long() + ((sec[:, 1:] != sec[:, :-1]) & both_real).sum(1)
        if bool((seconds_per_chunk > self.T).any()):
            raise ValueError("A strict chunk holds more than history_len + 1 distinct seconds "
                             "(builder/model history_len mismatch or row-count chunks)")
        return times

    @torch.no_grad()
    def embed(self, batch):
        """Sequence-CLS embedding [B, embed_dim], available at the sequence end.

        In chunk mode this summarizes the entire chunk, so it must not be used
        as an earlier transaction's decision-time embedding.
        """
        self(batch)
        return self._cls

    def _step(self, batch, tag):
        logits = self(batch)
        if self.hparams.predict_every_transaction:
            labels = batch["target_seq"]
            valid = batch["mask"]
            if labels.shape != valid.shape or not torch.equal(labels != -100, valid):
                raise ValueError("Every real transaction must own exactly one target; padding must use -100")
            logits, y = logits[valid], labels[valid]
            if not y.numel():
                raise ValueError("An all-padding chunk cannot contribute a training/evaluation batch")
            # Average weighted terms over actual transactions, not padded slots
            # or chunks. Logging with the same denominator preserves the exact
            # epoch mean even when the final chunk/batch is short.
            loss = nn.functional.cross_entropy(logits, y, weight=self.loss_fn.weight, reduction="sum") / y.numel()
        else:
            y = batch["target"].reshape(-1)
            loss = self.loss_fn(logits, y)
        self.log(f"{tag}_loss", loss, on_epoch=True, on_step=(tag == "train"),
                 prog_bar=True, sync_dist=True, batch_size=int(y.numel()))
        return logits, y, loss

    def training_step(self, batch, batch_idx):
        _, _, loss = self._step(batch, "train")
        return loss

    def validation_step(self, batch, batch_idx):
        logits, y, _ = self._step(batch, "valid")
        return logits, y  # consumed by StreamingBinaryMetrics

    def configure_optimizers(self):
        opt = build_optimizer(
            getattr(self.hparams, "optimizer", "adamw"), self.parameters(),
            lr=self.hparams.learning_rate, weight_decay=self.hparams.weight_decay,
        )
        sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, patience=3, factor=0.5)
        return {"optimizer": opt, "lr_scheduler": {"scheduler": sched, "monitor": "valid_loss"}}
