"""Config-selectable optimizers for tabular DL (arXiv:2604.15297).

AdamW default; Muon/Lion/SOAP/Adan via ``pip install pytorch-optimizer``.
Phase-local copy — does not touch the fraud/ base.
"""

import torch

_TORCH = {
    "adamw": torch.optim.AdamW,
    "adam": torch.optim.Adam,
    "nadam": torch.optim.NAdam,
    "radam": torch.optim.RAdam,
    "rmsprop": torch.optim.RMSprop,
}
_EXTERNAL = {"muon": "Muon", "lion": "Lion", "soap": "SOAP", "adan": "Adan"}


def build_optimizer(name, params, lr, weight_decay=0.0, momentum=0.9):
    name = (name or "adamw").lower()
    if name == "sgd":
        return torch.optim.SGD(params, lr=lr, weight_decay=weight_decay,
                               momentum=momentum, nesterov=True)
    if name in _TORCH:
        return _TORCH[name](params, lr=lr, weight_decay=weight_decay)
    if name in _EXTERNAL:
        try:
            import pytorch_optimizer as po
        except ImportError as exc:  # pragma: no cover
            raise ImportError(
                f"Optimizer {name!r} needs `pip install pytorch-optimizer`"
            ) from exc
        return getattr(po, _EXTERNAL[name])(params, lr=lr, weight_decay=weight_decay)
    raise ValueError(f"Unknown optimizer {name!r}")
