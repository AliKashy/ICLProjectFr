"""Measure strict all-position chunk widths before setting ``sequence.max_chunk_rows`` (review R1).

Under ``history_time_order: strict`` a chunk holds up to ``history_len + 1`` distinct whole seconds of
one account in one file, so a crowded second makes the chunk (and its whole batch) wider than T. This
reads only the account and time columns of every file in the chosen splits and reports, per split and
overall:

- ``max_rows_per_account_second``: the largest same-account same-second row count;
- the strict chunk widths (rows per chunk): max, quantiles, how many chunks exceed T, the widest chunks;
- ``mask_gib_at_max_width``: the float32 stage-2 attention mask of one batch at the widest chunk,
  ``batch_size * num_heads * (W + 1)^2 * 4`` bytes, before activations.

Chunks are file-local, as in the builder (``SequenceBuilder._chunk_spans``). The width of a strict chunk
depends only on the account's sorted whole seconds, so no tie-break column is read. No row is dropped.

Usage (bank side, before the all-position run):
    python -m YOUR_PACKAGE.phase4b.scripts.measure_chunk_widths \
        --config YOUR_PACKAGE/phase4b/configs/sequential_hier_allposition.yaml --splits train val eval

Set ``sequence.max_chunk_rows`` to at least the reported overall ``max_chunk_rows`` (the builder raises,
never truncates, on a wider chunk).
"""

import argparse
import json
import os
import sys

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from omegaconf import OmegaConf

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", ".."))

from fraud.data.s3_utils import build_file_list, make_s3_filesystem, strip_scheme
from YOUR_PACKAGE.base.data.input_contracts import parse_required_timestamps, require_account_ids

QUANTILES = (0.5, 0.9, 0.99, 0.999, 0.9999)


def strict_chunk_widths(accounts, timestamps, history_len):
    """Rows per strict chunk of one file, and the largest same-account same-second row count.

    ``timestamps`` are parsed timestamps; seconds are whole seconds (floor), as in the builder.
    """
    T = int(history_len) + 1
    frame = pd.DataFrame({
        "account": np.asarray(accounts),
        "second": pd.Series(timestamps).to_numpy(dtype="datetime64[s]").astype("int64"),
    })
    if frame.empty:
        return np.zeros(0, dtype=np.int64), 0
    per_second = frame.groupby(["account", "second"], sort=True).size()
    # Ordinal of each distinct second inside its account; T consecutive seconds form one chunk.
    ordinal = per_second.groupby(level="account").cumcount().to_numpy()
    chunk = pd.Series(per_second.to_numpy(), index=pd.MultiIndex.from_arrays(
        [per_second.index.get_level_values("account"), ordinal // T]))
    widths = chunk.groupby(level=[0, 1]).sum().to_numpy().astype(np.int64)
    return widths, int(per_second.max())


def summarize(widths, max_per_second, history_len, batch_size, num_heads):
    T = int(history_len) + 1
    widths = np.asarray(widths, dtype=np.int64)
    if not len(widths):
        return {"chunks": 0, "rows": 0}
    widest = int(widths.max())
    batch_width = max(T, widest)
    values, counts = np.unique(widths, return_counts=True)
    return {
        "chunks": int(len(widths)),
        "rows": int(widths.sum()),
        "T": T,
        "max_rows_per_account_second": int(max_per_second),
        "max_chunk_rows": widest,
        "chunks_wider_than_T": int((widths > T).sum()),
        "rows_in_chunks_wider_than_T": int(widths[widths > T].sum()),
        "quantiles": {str(q): float(np.quantile(widths, q)) for q in QUANTILES},
        "largest_widths": {str(int(v)): int(c) for v, c in list(zip(values, counts))[-10:]},
        "mask_gib_at_max_width": batch_size * num_heads * (batch_width + 1) ** 2 * 4 / 2 ** 30,
    }


def _split_files(cfg, split):
    if split == "train":
        return build_file_list(cfg.data.train_base, cfg.data.train_start, cfg.data.train_end)
    if split == "val":
        return build_file_list(cfg.data.val_base, cfg.data.val_start, cfg.data.val_end)
    if split == "eval":
        return build_file_list(cfg.eval.base, cfg.eval.file_start, cfg.eval.file_end)
    raise ValueError(f"unknown split {split!r}")


def measure(cfg, splits, filesystem=None):
    account_col, order_col = cfg.data.account_col, cfg.data.order_col
    history_len = int(cfg.sequence.history_len)
    batch_size, num_heads = int(cfg.training.batch_size), int(cfg.model.num_heads)
    report, all_widths, all_max = {}, [], 0
    for split in splits:
        widths, split_max = [], 0
        for filepath in _split_files(cfg, split):
            path = strip_scheme(filepath) if filesystem is not None else filepath
            df = pq.ParquetDataset(path, filesystem=filesystem).read(columns=[account_col, order_col]).to_pandas()
            require_account_ids(df[account_col], account_col)
            times = parse_required_timestamps(df[order_col], order_col)
            file_widths, file_max = strict_chunk_widths(df[account_col].to_numpy(), times, history_len)
            widths.append(file_widths)
            split_max = max(split_max, file_max)
        widths = np.concatenate(widths) if widths else np.zeros(0, dtype=np.int64)
        report[split] = summarize(widths, split_max, history_len, batch_size, num_heads)
        all_widths.append(widths)
        all_max = max(all_max, split_max)
    report["overall"] = summarize(np.concatenate(all_widths) if all_widths else [], all_max,
                                  history_len, batch_size, num_heads)
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("--splits", nargs="+", default=["train", "val", "eval"], choices=["train", "val", "eval"])
    parser.add_argument("overrides", nargs="*")
    args = parser.parse_args()
    cfg = OmegaConf.load(args.config)
    if args.overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(args.overrides))
    fs = make_s3_filesystem(cfg.s3.cred_path) if cfg.s3.get("cred_path") else None
    print(json.dumps(measure(cfg, args.splits, fs), indent=2))


if __name__ == "__main__":
    main()
