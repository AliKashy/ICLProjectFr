"""Scoring script for the sequential model (flat or hierarchical).

Factory-driven variant of reference's score_sequential (his stays untouched).

Usage:
    python YOUR_PACKAGE/phase4b/scripts/score_sequential.py \
        --config YOUR_PACKAGE/phase4b/configs/sequential_hier.yaml
"""

import argparse
import hashlib
import json
import os
import sys
import uuid

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import torch
from omegaconf import OmegaConf
from sklearn.metrics import average_precision_score, roc_auc_score
from torch.utils.data import DataLoader

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", ".."))

from fraud.data.datetime_features import DatetimeConfig
from fraud.data.feature_list import load_feature_list
from fraud.data.preprocessing import PreprocessingArtifacts
from fraud.data.s3_utils import build_file_list, make_s3_filesystem, strip_scheme
from YOUR_PACKAGE.phase4b.sequence_builder import SequenceBuilder  # phase-owned fix for the worker file-sharding bug (see YOUR_PACKAGE/phase4b/sequence_builder.py docstring)
from fraud.log_utils import setup_logging
from YOUR_PACKAGE.phase4b.factory import build_sequential_model, sequence_dataset_options

log = setup_logging()


def _prediction_path(cfg):
    """Every score invocation owns a distinct output object, even named reruns."""
    experiment = cfg.get("experiment") or {}
    name = experiment.get("run_name") or "sequential_hier"
    return strip_scheme(f"{cfg.eval.predictions_base.rstrip('/')}/{name}__{uuid.uuid4().hex}_preds.parquet")


def _model_inputs(batch, device):
    """The tensors the model reads. All-position chunks also carry time_seq, which the
    strict mask needs, so scoring builds the same mask and gaps as training (B9)."""
    inputs = {key: batch[key].to(device) for key in ("continuous", "categorical", "mask")}
    if "time_seq" in batch:
        inputs["time_seq"] = batch["time_seq"].to(device)
    return inputs


def _select_predictions(logits, batch, predict_every_transaction):
    """Select positive-class probabilities, labels and metadata in one order."""
    if predict_every_transaction:
        valid = batch["mask"].cpu().numpy()
        if tuple(logits.shape) != (*valid.shape, 2):
            raise ValueError("All-position logits must have shape [batch, time, 2]")
        labels = batch["target_seq"].cpu().numpy()
        if labels.shape != valid.shape or not np.array_equal(labels != -100, valid):
            raise ValueError("All-position targets must correspond exactly to real transaction slots")
        probabilities = torch.softmax(logits, dim=-1)[..., 1].detach().cpu().numpy()[valid]
        metadata = {}
        for key, values in batch.get("meta_seq", {}).items():
            values = np.asarray(values)
            if values.shape != valid.shape:
                raise ValueError(f"Per-position metadata shape mismatch: {key}")
            metadata[key] = values[valid]
        return probabilities, labels[valid], metadata
    labels = batch["target"].cpu().numpy().reshape(-1)
    if tuple(logits.shape) != (len(labels), 2):
        raise ValueError("Single-target logits must have shape [batch, 2]")
    probabilities = torch.softmax(logits, dim=-1)[:, 1].detach().cpu().numpy()
    return probabilities, labels, batch.get("meta", {})


def _validate_predictions(score, labels, metadata, id_cols):
    if score.ndim != 1 or labels.ndim != 1 or not len(score) or len(score) != len(labels):
        raise ValueError("Scoring must produce nonempty aligned probability/label vectors")
    if not np.isfinite(score).all() or ((score < 0) | (score > 1)).any():
        raise ValueError("Scoring produced invalid probabilities")
    if not np.isin(labels, [0, 1]).all():
        raise ValueError("Scoring labels must be binary")
    if any(len(values) != len(score) for values in metadata.values()):
        raise ValueError("Prediction metadata is not aligned with scores")
    if id_cols:
        ids = pd.DataFrame({key: metadata[key] for key in id_cols})
        if ids.isna().any().any() or ids.duplicated().any():
            raise ValueError("Prediction IDs must be non-null and unique across the entire evaluation cohort")


def _checkpoint_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _write_metrics(path, payload):
    """Publish machine-readable results only after predictions were written."""
    if path is None:
        return
    path = os.path.abspath(path)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    temporary = f"{path}.{uuid.uuid4().hex}.tmp"
    try:
        with open(temporary, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, allow_nan=False)
            handle.write("\n")
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("overrides", nargs="*")
    args = parser.parse_args()

    cfg = OmegaConf.load(args.config)
    if args.overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(args.overrides))
    options = sequence_dataset_options(cfg)

    fs = make_s3_filesystem(cfg.s3.cred_path)
    features = load_feature_list(cfg.predictors.csv_path, version=cfg.predictors.version, filesystem=fs)
    artifacts_path = f"{cfg.artifacts.base.rstrip('/')}/{cfg.artifacts.version}"
    artifacts = PreprocessingArtifacts.load(artifacts_path, filesystem=fs)
    dt_config = DatetimeConfig(order_col=cfg.data.order_col, fields=list(cfg.datetime.fields),
                               encoding=cfg.datetime.encoding, is_weekend=cfg.datetime.is_weekend)

    target_col = cfg.data.target_col
    id_cols = list(cfg.data.get("id_cols", []))
    amount_col = cfg.data.get("amount_col", None)
    if options["emit_target_seq"] and not id_cols:
        raise ValueError("All-position scoring requires data.id_cols to verify unique transaction ownership")

    eval_files = build_file_list(cfg.eval.base, cfg.eval.file_start, cfg.eval.file_end)
    dataset = SequenceBuilder(
        file_list=eval_files, artifacts=artifacts, features=features, datetime_config=dt_config,
        target_col=target_col, account_col=cfg.data.account_col, order_col=cfg.data.order_col,
        history_len=int(cfg.sequence.history_len), stride=int(cfg.sequence.get("eval_stride", 1)),
        positive_label=cfg.data.get("positive_label", 1), add_missing_flag=cfg.preprocess.add_missing_flag,
        time_delta=bool(cfg.sequence.get("time_delta", True)), batch_size=int(cfg.training.batch_size),
        shuffle=False, tie_break_col=cfg.data.get("tie_break_col", None),
        id_cols=id_cols, amount_col=amount_col, s3_cred_path=cfg.s3.cred_path,
        max_chunk_rows=cfg.sequence.get("max_chunk_rows", None),  # review R1: raise, never truncate
        **options,
    )
    loader = DataLoader(dataset, batch_size=None, num_workers=int(cfg.training.get("num_workers", 0)))

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = build_sequential_model(cfg, dataset)
    checkpoint_hash = _checkpoint_sha256(cfg.eval.checkpoint)
    ckpt = torch.load(cfg.eval.checkpoint, map_location=device, weights_only=False)
    model.on_load_checkpoint(ckpt)
    model.load_state_dict(ckpt["state_dict"])
    model.eval().to(device)
    log.info("Loaded checkpoint %s on %s", cfg.eval.checkpoint, device)

    scores, labels, meta_cols = [], [], {c: [] for c in id_cols}
    if amount_col:
        meta_cols[amount_col] = []
    for batch in loader:
        with torch.no_grad():
            logits = model(_model_inputs(batch, device))
            prob, targets, metadata = _select_predictions(logits, batch, options["emit_target_seq"])
        scores.append(prob)
        labels.append(targets)
        for c in meta_cols:
            meta_cols[c].append(metadata[c])

    if not scores:
        raise ValueError("Evaluation cohort produced no transactions")
    if _checkpoint_sha256(cfg.eval.checkpoint) != checkpoint_hash:
        raise ValueError("Checkpoint changed during scoring; refusing to attribute these predictions")
    score = np.concatenate(scores)
    y_true = np.concatenate(labels)
    out = {c: np.concatenate(v) for c, v in meta_cols.items()}
    _validate_predictions(score, y_true, out, id_cols)
    out[target_col] = y_true
    out["score"] = score

    ap = auroc = None
    if bool(cfg.eval.get("compute_metrics", False)):
        if np.unique(y_true).size != 2:
            raise ValueError("AP/AUROC reporting requires both classes in the evaluation cohort")
        ap = float(average_precision_score(y_true, score))
        auroc = float(roc_auc_score(y_true, score))
    out_path = _prediction_path(cfg)
    pq.write_table(pa.table(out), out_path, filesystem=fs)
    log.info("Wrote %d predictions -> %s (positives=%d)", len(score), out_path, int(y_true.sum()))

    if ap is not None:
        log.info("Range metrics: average_precision=%.12g  auroc=%.12g  (n=%d, positives=%d)",
                 ap, auroc,
                 len(y_true), int(y_true.sum()))
    _write_metrics(cfg.eval.get("metrics_output", None), {
        "schema_version": 1,
        "predictions_path": out_path,
        "checkpoint_path": os.path.abspath(cfg.eval.checkpoint),
        "checkpoint_sha256": checkpoint_hash,
        "n_predictions": int(len(score)),
        "n_positives": int(y_true.sum()),
        "average_precision": ap,
        "auroc": auroc,
        "sequence_contract": model.sequence_contract,
        "checkpoint_contract_verified": ckpt.get("sequence_contract") is not None,
    })


if __name__ == "__main__":
    main()
