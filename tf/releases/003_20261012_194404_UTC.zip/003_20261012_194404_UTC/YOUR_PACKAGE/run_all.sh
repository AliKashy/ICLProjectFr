#!/usr/bin/env bash
# Full FT-Transformer sweep FROM SCRATCH (reproduces every run). Run on the pod:
#   bash YOUR_PACKAGE/run_all.sh
set -euo pipefail
cd "$(dirname "$0")/.."   # repo root

# --- Phase 4a (flat) ---
# 1) decision finder at h5: embedding x mask x optimizer
python YOUR_PACKAGE/phase4a/scripts/run_ablations.py \
    --config YOUR_PACKAGE/phase4a/configs/ft_decisions.yaml
# 2) long history at the winning knobs: h10, h16
python YOUR_PACKAGE/phase4a/scripts/run_ablations.py \
    --config YOUR_PACKAGE/phase4a/configs/ft_decisions_flat_long.yaml

# --- Phase 4b (hierarchical) ---
# 3) history h5 / h10 / h16 at the winning knobs
python YOUR_PACKAGE/phase4b/scripts/run_ablations.py \
    --config YOUR_PACKAGE/phase4b/configs/ft_decisions_hier.yaml
