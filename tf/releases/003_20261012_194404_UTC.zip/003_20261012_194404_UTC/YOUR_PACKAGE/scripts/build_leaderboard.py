"""Aggregate every ablation results.csv under ablations/ into one leaderboard ranked by validation AP.

Walks ablations/ recursively, reads each results.csv it finds, tags each row with the
architecture + test it came from (parsed from the folder path), and writes one combined
CSV plus a console summary. Every successful run is ranked by best_valid_ap (the
validation files), per study (one architecture/test folder; runs in different studies
are not compared with each other). eval_ap and eval_auroc (the evaluation files) are
shown next to each run but never ranked: the run protocol keeps evaluation numbers for
reporting only, never for choosing between runs (RUN-07, register R-011).

Only rows written by the attempt-folder runner are ranked: a row with status "ok". A
row with another status (train_failed, score_failed, source_changed, ...) is listed
after the ranked rows with an empty rank. Rows without any status or attempt (the
older runner's results.csv, written before attempt folders and before the fixes) are
listed in a separate unranked "earlier results (history)" section and never ranked
with the new rows (register R-032). The smoke run before batch 1 (a "smoke" study or run
name, e.g. ablations/arch_a_flat/smoke_h5, run smoke-h5) is listed in its own
"smoke (not ranked)" section and never ranked. The section column names the four groups.

With attempt folders (<output_root>/<attempt>/results.csv), the configured results.csv
is a copy of the latest attempt and previous_results.csv a copy of what it replaced;
each run is counted once, by its folder, attempt and run name. A rank compares runs
fairly only when their train/validation/evaluation file ranges match (see the configs).

Usage:
    python YOUR_PACKAGE/scripts/build_leaderboard.py
    python YOUR_PACKAGE/scripts/build_leaderboard.py --ablations-root ablations --out ablations/leaderboard.csv
"""

import argparse
import csv
import math
import os

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

# Columns every run_ablations.py results.csv always has, regardless of axes swept.
_FIXED_COLS = ["run_name", "train_rc", "best_valid_ap", "best_valid_auroc", "eval_ap", "eval_auroc"]
# Bookkeeping columns of runners that write attempt folders; they are not axes.
_RUNNER_COLS = ["attempt", "run_dir", "score_rc", "status", "predictions_path", "n_predictions", "n_positives",
                "checkpoint_epoch", "checkpoint_step", "checkpoint_monitor", "checkpoint_monitor_score",
                "checkpoint_sha256", "resolved_train_sha256", "source_sha256", "manifest_path", "error"]
# The one ranking metric: validation AP. Evaluation AP is shown, never ranked (RUN-07, R-011).
RANK_METRIC = "best_valid_ap"
SECTION_RANKED = "ranked"
SECTION_NOT_RANKED = "not ranked"
SECTION_HISTORY = "earlier results (history)"
SECTION_SMOKE = "smoke (not ranked)"


def _find_results_csvs(ablations_root):
    """Every results.csv and previous_results.csv, most authoritative first: an attempt's own results.csv
    (written once per attempt), then a test folder's results.csv (a latest view, or an older runner's only
    copy), then previous_results.csv (a copy of what a latest view replaced)."""
    found = []
    for dirpath, dirnames, filenames in os.walk(ablations_root):
        dirnames[:] = [d for d in dirnames if d != ".ipynb_checkpoints"]
        for name in ("results.csv", "previous_results.csv"):
            if name in filenames:
                found.append(os.path.join(dirpath, name))

    def priority(path):
        if os.path.basename(path) == "previous_results.csv":
            return 2
        return 0 if os.path.isfile(os.path.join(os.path.dirname(path), "ablation_spec.yaml")) else 1
    return sorted(found, key=lambda p: (priority(p), p))


def _test_folder(results_csv):
    """The folder a config's output_root names: the parent of an attempt folder (one holding ablation_spec.yaml),
    otherwise the CSV's own folder."""
    folder = os.path.dirname(results_csv)
    if os.path.isfile(os.path.join(folder, "ablation_spec.yaml")):
        return os.path.dirname(folder)
    return folder


def _tag_from_path(results_csv, ablations_root):
    """ablations/<architecture>/<test>/results.csv -> (architecture, test)."""
    rel = os.path.relpath(results_csv, ablations_root)
    parts = rel.split(os.sep)
    if len(parts) >= 3:
        return parts[0], parts[1]
    if len(parts) == 2:
        return parts[0], "-"
    return "-", "-"


def _to_float(val):
    """The number, or None when it is missing, not a number, or not finite (a "nan" validation AP is not a
    validation AP, so such a row is listed as not ranked)."""
    try:
        value = float(val)
    except (TypeError, ValueError):
        return None
    return value if math.isfinite(value) else None


def _from_attempt_runner(row):
    """True for a row the attempt-folder runner wrote (it always fills status and attempt); False for the older
    runner's rows, which have neither and go to the history section (R-032)."""
    return bool((row.get("status") or "").strip() or (row.get("attempt") or "").strip())


def _eligible(row):
    """A run may be ranked only if the attempt-folder runner recorded it as a success: status ok. A row without
    a status is never ranked (no fallback to train_rc: the older runner's rows are history)."""
    return (row.get("status") or "").strip() == "ok"


def load_all_rows(ablations_root):
    rows = []
    axis_cols_seen = []
    seen = {}
    for results_csv in _find_results_csvs(ablations_root):
        test_folder = _test_folder(results_csv)
        architecture, test = _tag_from_path(os.path.join(test_folder, "results.csv"), ablations_root)
        with open(results_csv, newline="") as f:
            reader = csv.DictReader(f)
            axis_cols = [c for c in (reader.fieldnames or []) if c not in _FIXED_COLS + _RUNNER_COLS]
            for c in axis_cols:
                if c not in axis_cols_seen:
                    axis_cols_seen.append(c)
            for row in reader:
                key = (test_folder, row.get("attempt") or "", row.get("run_name"))
                if key in seen:  # the same run seen through a latest view or a previous_results.csv copy
                    kept = seen[key]
                    if any(_to_float(row.get(c)) != kept[c] for c in _FIXED_COLS[2:]):
                        print(f"WARNING: {row.get('run_name')} in {architecture}/{test} has different numbers in "
                              f"{os.path.relpath(results_csv, ROOT)}; kept {kept['source_csv']}")
                    continue
                valid_ap = _to_float(row.get("best_valid_ap"))
                entry = {
                    "architecture": architecture,
                    "test": test,
                    "source_csv": os.path.relpath(results_csv, ROOT),
                    "run_name": row.get("run_name"),
                    **{c: row.get(c, "") for c in axis_cols},
                    "train_rc": row.get("train_rc"),
                    "best_valid_ap": valid_ap,
                    "best_valid_auroc": _to_float(row.get("best_valid_auroc")),
                    "eval_ap": _to_float(row.get("eval_ap")),
                    "eval_auroc": _to_float(row.get("eval_auroc")),
                    "rank_metric": RANK_METRIC,
                    "rank": None,
                    "rank_value": valid_ap,
                    "attempt": row.get("attempt", ""),
                    "status": row.get("status", ""),
                    "section": None,
                }
                seen[key] = entry
                rows.append(entry)
    return rows, axis_cols_seen


def _study(row):
    return (row["architecture"], row["test"])


def write_leaderboard(rows, axis_cols_seen, out_path):
    """Rank per study by best_valid_ap; return (ranked rows, unranked rows) with the section set on every row.

    The unranked rows are the attempt-folder runner's failed or metric-less rows first, then the smoke rows, then
    the history rows."""
    for r in rows:
        if "smoke" in (r["test"] or "").lower() or "smoke" in (r["run_name"] or "").lower():
            r["section"] = SECTION_SMOKE
        elif not _from_attempt_runner(r):
            r["section"] = SECTION_HISTORY
        elif _eligible(r) and r["rank_value"] is not None:
            r["section"] = SECTION_RANKED
        else:
            r["section"] = SECTION_NOT_RANKED
    ranked = sorted((r for r in rows if r["section"] == SECTION_RANKED),
                    key=lambda r: (_study(r), -r["rank_value"]))
    position = {}
    for r in ranked:
        position[_study(r)] = position.get(_study(r), 0) + 1
        r["rank"] = position[_study(r)]
    unranked = ([r for r in rows if r["section"] == SECTION_NOT_RANKED] +
                [r for r in rows if r["section"] == SECTION_SMOKE] +
                [r for r in rows if r["section"] == SECTION_HISTORY])
    fieldnames = (["architecture", "test", "source_csv", "run_name"] + axis_cols_seen +
                  ["train_rc", "best_valid_ap", "best_valid_auroc", "eval_ap", "eval_auroc",
                   "rank_metric", "rank", "rank_value", "attempt", "status", "section"])
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    with open(out_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(ranked + unranked)
    return ranked, unranked


def _fmt(value):
    return "-" if value is None else f"{value:.4f}"


def print_summary(ranked, unranked):
    history = [r for r in unranked if r["section"] == SECTION_HISTORY]
    failed = [r for r in unranked if r["section"] == SECTION_NOT_RANKED]
    smoke = [r for r in unranked if r["section"] == SECTION_SMOKE]
    print(f"\n=== Combined ablation leaderboard ({len(ranked)} ranked runs, {len(failed)} not ranked, "
          f"{len(smoke)} smoke, {len(history)} earlier results) ===")
    print("Rank: best_valid_ap (validation files), per study. eval_ap and eval_auroc (evaluation files) are shown, "
          "never ranked.")
    header = (f"{'rank':>4} {'run_name':<34} {'best_valid_ap':>13} {'best_valid_auroc':>16} "
              f"{'eval_ap':>9} {'eval_auroc':>10} {'attempt':<12}")
    for study in sorted({_study(r) for r in ranked}):
        architecture, test = study
        print(f"\n--- {architecture}/{test}: ranked by best_valid_ap (validation files); "
              f"eval_ap and eval_auroc shown, not ranked ---")
        print(header)
        print("-" * len(header))
        for r in (r for r in ranked if _study(r) == study):
            print(f"{r['rank']:>4} {r['run_name']:<34} {_fmt(r['best_valid_ap']):>13} {_fmt(r['best_valid_auroc']):>16} "
                  f"{_fmt(r['eval_ap']):>9} {_fmt(r['eval_auroc']):>10} {r['attempt'] or '-':<12}")
    if failed:
        print("\n--- not ranked (failed, incomplete or no validation AP) ---")
        for r in failed:
            print(f"     {r['architecture']:<14} {r['test']:<28} {r['run_name']:<34} "
                  f"status={r['status'] or '-'} train_rc={r['train_rc']}")
    if smoke:
        print("\n--- smoke (not ranked): the smoke run before batch 1; listed, never ranked ---")
        for r in smoke:
            print(f"     {r['architecture']:<14} {r['test']:<28} {r['run_name']:<34} "
                  f"status={r['status'] or '-'} best_valid_ap={_fmt(r['best_valid_ap'])}")
    if history:
        print("\n--- earlier results (history): rows without a run status, written before attempt folders; "
              "listed, never ranked ---")
        for r in history:
            print(f"     {r['architecture']:<14} {r['test']:<28} {r['run_name']:<34} "
                  f"best_valid_ap={_fmt(r['best_valid_ap'])} eval_ap={_fmt(r['eval_ap'])} train_rc={r['train_rc']}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ablations-root", default=os.path.join(ROOT, "ablations"))
    parser.add_argument("--out", default=os.path.join(ROOT, "ablations", "leaderboard.csv"))
    args = parser.parse_args()

    rows, axis_cols_seen = load_all_rows(args.ablations_root)
    if not rows:
        print(f"No results.csv files found under {args.ablations_root}")
        return
    ranked, unranked = write_leaderboard(rows, axis_cols_seen, args.out)
    print_summary(ranked, unranked)
    print(f"\nWrote {len(ranked) + len(unranked)} rows -> {os.path.relpath(args.out, ROOT)}")


if __name__ == "__main__":
    main()
