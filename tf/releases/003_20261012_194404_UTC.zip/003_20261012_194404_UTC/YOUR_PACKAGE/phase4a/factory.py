"""Builds the flat FT-Transformer (Architecture A) from config — phase4a-local.

Dimensions come from the dataset contract (`continuous_cols` /
`categorical_cardinality`) so nothing is hardcoded.
"""

from YOUR_PACKAGE.base.data.contracts import build_input_contract

from YOUR_PACKAGE.phase4a.sequential import FTTransformerSeqModel


def build_sequential_model(cfg, dataset):
    if cfg.model.get("type", "FTTransformerSeq") != "FTTransformerSeq":
        raise ValueError("The Phase 4A entrypoint requires model.type='FTTransformerSeq'")
    if cfg.sequence.get("predict_every_transaction", False):
        raise ValueError("Architecture A predicts one target per window")
    if bool(cfg.sequence.get("time_delta", True)) and cfg.sequence.get("time_delta_reference", "target") != "target":
        raise ValueError("Architecture A uses target-relative time deltas")
    input_contract = build_input_contract(dataset)
    return FTTransformerSeqModel(
        continuous_dim=len(dataset.continuous_cols),
        categorical_cardinality=dataset.categorical_cardinality,
        history_len=int(cfg.sequence.history_len),
        embed_dim=int(cfg.model.input_embed_dim),
        num_heads=int(cfg.model.num_heads),
        num_attn_blocks=int(cfg.model.num_attn_blocks),
        attn_dropout=float(cfg.model.attn_dropout),
        ff_dropout=float(cfg.model.ff_dropout),
        attention_mask=cfg.sequence.get("attention_mask", "bidirectional"),
        learning_rate=float(cfg.training.get("learning_rate", 3e-4)),
        weight_decay=float(cfg.training.get("weight_decay", 1e-5)),
        pos_weight=float(cfg.training.get("pos_weight", 1.0)),
        continuous_embedding=cfg.model.get("continuous_embedding", "linear"),
        num_frequencies=int(cfg.model.get("num_frequencies", 16)),
        optimizer=cfg.training.get("optimizer", "adamw"),
        time_delta_reference="target" if dataset.time_delta else "none",
        input_contract=input_contract,
    )
