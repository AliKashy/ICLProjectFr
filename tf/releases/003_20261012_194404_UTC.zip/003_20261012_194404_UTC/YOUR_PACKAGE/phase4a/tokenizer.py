"""Phase-local feature tokenizer (linear or periodic continuous embedding).

Same token layout as reference's ``TransactionEmbedding``; phase-owned so the fraud/
base is never edited.
"""

from typing import List

import torch
import torch.nn as nn

from YOUR_PACKAGE.phase4a.numerical_embeddings import PeriodicNumericalEmbedding


class FeatureTokenizer(nn.Module):
    def __init__(self, continuous_dim: int, categorical_cardinality: List[int], embed_dim: int,
                 continuous_embedding: str = "linear", num_frequencies: int = 16):
        super().__init__()
        self.continuous_dim = continuous_dim
        self.embed_dim = embed_dim
        self.continuous_embedding = continuous_embedding
        if continuous_embedding == "periodic":
            self.periodic = PeriodicNumericalEmbedding(continuous_dim, embed_dim, num_frequencies)
        else:
            self.cont_weight = nn.Parameter(torch.empty(continuous_dim, embed_dim))
            self.cont_bias = nn.Parameter(torch.zeros(continuous_dim, embed_dim))
            nn.init.normal_(self.cont_weight, std=0.02)
        self.cat_embeddings = nn.ModuleList(
            [nn.Embedding(card, embed_dim) for card in categorical_cardinality]
        )

    def forward(self, continuous, categorical):  # [N, C], [N, K] -> [N, C+K, d]
        if self.continuous_embedding == "periodic":
            cont_tok = self.periodic(continuous)
        else:
            cont_tok = continuous.unsqueeze(-1) * self.cont_weight + self.cont_bias
        cat_tok = torch.stack(
            [emb(categorical[:, i]) for i, emb in enumerate(self.cat_embeddings)], dim=1
        ) if self.cat_embeddings else continuous.new_zeros(continuous.size(0), 0, self.embed_dim)
        return torch.cat([cont_tok, cat_tok], dim=1)
