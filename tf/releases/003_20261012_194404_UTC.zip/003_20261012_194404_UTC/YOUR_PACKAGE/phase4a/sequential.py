"""Architecture A: flat SEP/CLS sequential model.

Self-contained copy of reference's ``FTTransformerSeqModel`` design, phase-owned so
the fraud/ base is never edited, extended with: periodic numerical embeddings
(via ``FeatureTokenizer``), config-selectable optimizer, and an ``embed()`` method
for exporting the account-at-target CLS vector.
"""

from copy import deepcopy
from typing import List
import warnings

import pytorch_lightning as pl
import torch
import torch.nn as nn

from YOUR_PACKAGE.phase4a.optim import build_optimizer
from YOUR_PACKAGE.phase4a.tokenizer import FeatureTokenizer


class FTTransformerSeqModel(pl.LightningModule):
    def __init__(
        self,
        continuous_dim: int,
        categorical_cardinality: List[int],
        history_len: int,
        embed_dim: int = 48,
        num_heads: int = 8,
        num_attn_blocks: int = 4,
        ff_multiplier: int = 4,
        attn_dropout: float = 0.1,
        ff_dropout: float = 0.1,
        attention_mask: str = "bidirectional",
        learning_rate: float = 3e-4,
        weight_decay: float = 1e-5,
        pos_weight: float = 1.0,
        continuous_embedding: str = "linear",
        num_frequencies: int = 16,
        optimizer: str = "adamw",
        time_delta_reference: str = "target",
        input_contract=None,
    ):
        super().__init__()
        if attention_mask not in {"causal", "bidirectional"}:
            raise ValueError("attention_mask must be causal or bidirectional")
        self.save_hyperparameters()
        self.T = history_len + 1
        self.tokens_per_txn = continuous_dim + len(categorical_cardinality)
        self.attention_mask = attention_mask

        self.embedding = FeatureTokenizer(continuous_dim, categorical_cardinality, embed_dim,
                                          continuous_embedding, num_frequencies)
        self.txn_position = nn.Embedding(self.T, embed_dim)
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        nn.init.normal_(self.cls_token, std=0.02)

        layer = nn.TransformerEncoderLayer(
            d_model=embed_dim, nhead=num_heads, dim_feedforward=embed_dim * ff_multiplier,
            dropout=ff_dropout, activation="gelu", batch_first=True, norm_first=True,
        )
        layer.self_attn.dropout = attn_dropout
        self.encoder = nn.TransformerEncoder(layer, num_layers=num_attn_blocks)
        self.head = nn.Linear(embed_dim, 2)

        weight = None
        if pos_weight and pos_weight != 1.0:
            weight = torch.tensor([1.0, float(pos_weight)])
        self.loss_fn = nn.CrossEntropyLoss(weight=weight)

    @property
    def sequence_contract(self):
        """Persist semantics that tensor shapes cannot identify."""
        return deepcopy({
            "version": 1,
            "architecture_name": "FTTransformerSeq",
            "layout": "sliding_target",
            "history_len": int(self.hparams.history_len),
            "time_delta_reference": self.hparams.time_delta_reference,
            "attention_mask": self.hparams.attention_mask,
            "architecture": {key: self.hparams[key] for key in (
                "continuous_dim", "categorical_cardinality", "embed_dim", "num_heads",
                "num_attn_blocks", "ff_multiplier", "attn_dropout", "ff_dropout",
                "continuous_embedding", "num_frequencies",
            )},
            "input_contract": self.hparams.input_contract,
        })

    def on_save_checkpoint(self, checkpoint):
        checkpoint["sequence_contract"] = self.sequence_contract

    def on_load_checkpoint(self, checkpoint):
        saved = checkpoint.get("sequence_contract")
        if saved is not None:
            if saved != self.sequence_contract:
                raise ValueError(f"Checkpoint sequence_contract mismatch: {saved} != {self.sequence_contract}")
            return
        # Existing checkpoints predate input/artifact attestation. Check every
        # semantic field they did record, and disclose the remaining limitation.
        historical = checkpoint.get("hyper_parameters", {})
        for key in (*self.sequence_contract["architecture"], "history_len", "attention_mask", "time_delta_reference"):
            if key in historical and historical[key] != self.hparams[key]:
                raise ValueError(f"Checkpoint model hyperparameter mismatch: {key}")
        warnings.warn("Legacy A checkpoint has no sequence_contract; feature order and preprocessing artifact identity cannot be verified", UserWarning)

    def _build_causal_mask(self, device, key_padding=None):
        # FIX (bug #2, CLS causal-mask leak): the original version gave CLS txn_of=-1
        # and special-cased `tj<0 | ti<0` to mean "always allowed" -- that let ANY
        # history token attend back to the CLS key (tj<0 true for CLS-as-key regardless
        # of the query), and since CLS (as query) legitimately saw the whole sequence
        # including the target in layer 1, that future-relative information leaked
        # back into "earlier" token representations via CLS from layer 2 onward, so
        # causal masking wasn't fully causal once there was more than one layer.
        #
        # Fix: give CLS txn_of = self.T (one slot AFTER every real transaction) instead
        # of -1, and drop the special cases entirely -- a single rule `tj <= ti` now
        # covers everything correctly:
        #   CLS (ti=T) attends to any real tj (<= T-1 <= T)         -> allowed  (correct: CLS sees all)
        #   any real token (ti<=T-1) attends to CLS (tj=T)          -> T<=ti is False -> BLOCKED (fixes the leak)
        #   real-to-real                                            -> unchanged (tj<=ti, same as before)
        L = 1 + self.T * self.tokens_per_txn
        txn_of = torch.full((L,), self.T, dtype=torch.long, device=device)  # CLS slot defaults to T
        for t in range(self.T):
            start = 1 + t * self.tokens_per_txn
            txn_of[start:start + self.tokens_per_txn] = t
        ti, tj = txn_of.unsqueeze(1), txn_of.unsqueeze(0)
        disallowed = ~(tj <= ti)
        if key_padding is None:
            return disallowed
        # FIX (NaN / corrupt-gradient guard, found via external audit review): a query
        # that is itself a padded (left-padded, short-history) transaction slot can end
        # up with EVERY key disallowed once causal + padding are combined -- its only
        # causal-reachable key is its own, fully-padded, transaction slot. Softmax over
        # an all -inf row produces NaN, which then taints the shared encoder weights'
        # gradients for the WHOLE batch during backprop (shared layers see every
        # position), not just that one row. Merge per-sample padding into the causal
        # mask and force the diagonal open so every row keeps at least its own (unused)
        # key -- this never changes behavior for real (non-padded) rows, since the
        # diagonal is already always allowed for them by the causal rule alone.
        merged = disallowed.unsqueeze(0) | key_padding.unsqueeze(1)  # [B, L, L]
        diag = torch.eye(L, dtype=torch.bool, device=device).unsqueeze(0)
        merged = merged & ~diag
        float_mask = torch.zeros(merged.shape, dtype=torch.float32, device=device)
        float_mask.masked_fill_(merged, float("-inf"))
        return float_mask.repeat_interleave(self.hparams.num_heads, dim=0)  # [B*num_heads, L, L]

    def forward(self, batch):
        continuous, categorical, mask = batch["continuous"], batch["categorical"], batch["mask"]
        B, T, C = continuous.shape
        K = categorical.shape[-1]
        d = self.hparams.embed_dim

        tokens = self.embedding(continuous.reshape(B * T, C), categorical.reshape(B * T, K))
        tokens = tokens.reshape(B, T, self.tokens_per_txn, d)
        pos = self.txn_position(torch.arange(T, device=continuous.device))
        tokens = tokens + pos[None, :, None, :]
        tokens = tokens.reshape(B, T * self.tokens_per_txn, d)

        cls = self.cls_token.expand(B, 1, d)
        seq = torch.cat([cls, tokens], dim=1)

        token_valid = mask.unsqueeze(-1).expand(B, T, self.tokens_per_txn).reshape(B, -1)
        key_padding = torch.cat(
            [torch.zeros(B, 1, dtype=torch.bool, device=mask.device), ~token_valid], dim=1
        )
        if self.attention_mask == "causal":
            # Padding is merged into the mask itself (see _build_causal_mask), so
            # src_key_padding_mask is NOT also passed here -- avoids double-masking.
            attn_mask = self._build_causal_mask(seq.device, key_padding)
            out = self.encoder(seq, mask=attn_mask)
        else:
            out = self.encoder(seq, src_key_padding_mask=key_padding)
        self._cls = out[:, 0]
        return self.head(self._cls)

    @torch.no_grad()
    def embed(self, batch):
        """Account-at-target CLS embedding (pre-head): [B, embed_dim]."""
        self(batch)
        return self._cls

    def _step(self, batch, tag):
        logits = self(batch)
        y = batch["target"].reshape(-1)
        loss = self.loss_fn(logits, y)
        self.log(f"{tag}_loss", loss, on_epoch=True, on_step=(tag == "train"),
                 prog_bar=True, sync_dist=True)
        return logits, y, loss

    def training_step(self, batch, batch_idx):
        _, _, loss = self._step(batch, "train")
        return loss

    def validation_step(self, batch, batch_idx):
        logits, y, _ = self._step(batch, "valid")
        return logits, y

    def configure_optimizers(self):
        opt = build_optimizer(getattr(self.hparams, "optimizer", "adamw"), self.parameters(),
                              lr=self.hparams.learning_rate, weight_decay=self.hparams.weight_decay)
        sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, patience=3, factor=0.5)
        return {"optimizer": opt, "lr_scheduler": {"scheduler": sched, "monitor": "valid_loss"}}
