"""Weight-EMA callback for Phase 4.

Phase-local copy — does not touch the fraud/ base.
"""

import pytorch_lightning as pl
import torch


class EMACallback(pl.Callback):
    """Exponential moving average of weights; swaps EMA in for validation.

    Checkpoints store EMA inference weights plus raw and shadow parameters
    for resume, regardless of callback order. Training keeps raw weights.
    """

    def __init__(self, decay: float = 0.999):
        if not 0.0 <= decay < 1.0:
            raise ValueError("EMA decay must be in [0, 1).")
        self.decay = decay
        self.shadow = {}
        self.backup = {}
        self._last_global_step = None

    def on_fit_start(self, trainer, pl_module):
        params = dict(pl_module.named_parameters())
        self._last_global_step = self._global_step(trainer)
        if self.shadow:  # restored by on_load_checkpoint: keep it, align device/dtype
            self.shadow = {n: v.to(params[n].device, params[n].dtype)
                           for n, v in self.shadow.items() if n in params}
            return
        self.shadow = {n: p.detach().clone() for n, p in params.items() if p.requires_grad}

    @staticmethod
    def _global_step(trainer):
        step = getattr(trainer, "global_step", None) if trainer is not None else None
        return int(step) if isinstance(step, int) else None

    def _optimizer_stepped(self, trainer, batch_idx):
        # Update once per *completed optimizer step*, not once per accumulation
        # micro-batch. Lightning increments trainer.global_step when it steps, which
        # also covers the final partial accumulation group of an epoch (Lightning
        # steps there too), so track that counter rather than batch_idx divisibility.
        step = self._global_step(trainer)
        if step is None:  # no Lightning trainer (unit tests): fall back to the batch rule
            accum = int(getattr(trainer, "accumulate_grad_batches", 1) or 1) if trainer is not None else 1
            return (batch_idx + 1) % accum == 0 or bool(getattr(trainer, "is_last_batch", False))
        last = getattr(self, "_last_global_step", None)
        self._last_global_step = step
        return last is None or step != last

    def on_train_start(self, trainer, pl_module):
        # Lightning restores trainer.global_step from a checkpoint AFTER on_fit_start; re-sync the
        # step marker here so the first resumed micro-batch is not mistaken for a completed step.
        self._last_global_step = self._global_step(trainer)

    def on_train_batch_end(self, trainer, pl_module, outputs, batch, batch_idx):
        if not self._optimizer_stepped(trainer, batch_idx):
            return
        for n, p in pl_module.named_parameters():
            if p.requires_grad and n in self.shadow:
                self.shadow[n].mul_(self.decay).add_(p.detach(), alpha=1.0 - self.decay)

    def on_validation_start(self, trainer, pl_module):
        if not self.shadow:
            return
        self.backup = {n: p.detach().clone()
                       for n, p in pl_module.named_parameters() if n in self.shadow}
        for n, p in pl_module.named_parameters():
            if n in self.shadow:
                p.data.copy_(self.shadow[n])

    def on_validation_end(self, trainer, pl_module):
        for n, p in pl_module.named_parameters():
            if n in self.backup:
                p.data.copy_(self.backup[n])
        self.backup = {}

    def on_save_checkpoint(self, trainer, pl_module, checkpoint):
        # Saving may occur before or after raw weights are restored. Always
        # write EMA inference weights to state_dict and preserve raw weights
        # plus the shadow separately for exact training resume.
        if not self.shadow:
            return
        sd = checkpoint.get("state_dict", {})
        raw = {}
        for n, v in self.shadow.items():
            if n in sd:
                # If a checkpoint is written while validation still has the EMA weights swapped in
                # (ModelCheckpoint listed before this callback), the raw weights live in self.backup.
                src = self.backup[n] if n in self.backup else sd[n]
                raw[n] = src.detach().clone()
                sd[n] = v.detach().clone()
        checkpoint["ema_raw_params"] = raw
        checkpoint["ema_shadow"] = {n: v.detach().clone() for n, v in self.shadow.items()}

    def on_load_checkpoint(self, trainer, pl_module, checkpoint):
        shadow = checkpoint.get("ema_shadow")
        raw = checkpoint.get("ema_raw_params")
        if shadow:
            self.shadow = {n: v.clone() for n, v in shadow.items()}
        self._last_global_step = self._global_step(trainer)  # resume: steps before this are done
        if raw:  # resume training from the RAW weights, not the EMA copy
            with torch.no_grad():
                for n, p in pl_module.named_parameters():
                    if n in raw:
                        p.copy_(raw[n].to(p.device))
