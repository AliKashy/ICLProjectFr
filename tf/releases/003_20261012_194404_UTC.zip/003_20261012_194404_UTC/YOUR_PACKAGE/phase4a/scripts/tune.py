"""Optuna hyperparameter search over the training scripts (SOTA lever).

TabZilla (arXiv:2305.02997) found light HPO often matters more than the choice of
architecture. This tuner runs a TPE search: each trial launches the configured
training script (sequential / streaming / ssl-finetune) with sampled dotlist
overrides, reads the best `valid_ap` from that trial's `training_metrics.csv`
and returns it as the objective. Keep trials cheap (few files/epochs via
`common_overrides`), then retrain the best config at full scale.

Usage:
    pip install optuna
    python fraud/scripts/tune.py --config fraud/configs/tune.yaml
    python fraud/scripts/tune.py --config fraud/configs/tune.yaml --n-trials 50
"""

import argparse
import csv
import os
import subprocess
import sys

from omegaconf import OmegaConf

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
sys.path.insert(0, ROOT)

from fraud.log_utils import setup_logging

log = setup_logging()


def _best_metric(csv_path, column, direction):
    if not os.path.exists(csv_path):
        return None
    best = None
    with open(csv_path, newline="") as f:
        for row in csv.DictReader(f):
            try:
                v = float(row.get(column, ""))
            except (TypeError, ValueError):
                continue
            if best is None:
                best = v
            else:
                best = max(best, v) if direction == "maximize" else min(best, v)
    return best


def _suggest(trial, spec):
    name, t = spec["override"], spec["type"]
    if t == "categorical":
        return trial.suggest_categorical(name, list(spec["choices"]))
    if t == "int":
        return trial.suggest_int(name, int(spec["low"]), int(spec["high"]),
                                 step=int(spec.get("step", 1)))
    if t == "float":
        return trial.suggest_float(name, float(spec["low"]), float(spec["high"]))
    if t == "loguniform":
        return trial.suggest_float(name, float(spec["low"]), float(spec["high"]), log=True)
    raise ValueError(f"Unknown space type {t!r} for {name}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--n-trials", type=int, default=None)
    args = parser.parse_args()

    try:
        import optuna
    except ImportError as exc:  # pragma: no cover
        raise SystemExit("tune.py requires optuna: pip install optuna") from exc

    spec = OmegaConf.load(args.config)
    base_config = os.path.join(ROOT, str(spec.base_config))
    train_script = os.path.join(ROOT, str(spec.train_script))
    objective_col = str(spec.get("objective", "valid_ap"))
    direction = str(spec.get("direction", "maximize"))
    output_root = str(spec.get("output_root", "tuning"))
    common = [str(o) for o in spec.get("common_overrides", [])]
    space = list(spec.space)
    n_trials = args.n_trials or int(spec.get("n_trials", 30))

    os.makedirs(os.path.join(ROOT, output_root), exist_ok=True)

    def objective(trial):
        params = {s["override"]: _suggest(trial, s) for s in space}
        d, heads = params.get("model.input_embed_dim"), params.get("model.num_heads")
        if d and heads and d % heads != 0:
            raise optuna.TrialPruned()

        run_dir = os.path.join(output_root, f"trial_{trial.number}")
        overrides = common + [f"{k}={v}" for k, v in params.items()] + [
            f"output.checkpoint_dir={run_dir}",
            f"experiment.run_name=trial_{trial.number}",
        ]
        cmd = [sys.executable, train_script, "--config", base_config, *overrides]
        log.info("trial %d: %s", trial.number, " ".join(f"{k}={v}" for k, v in params.items()))
        proc = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
        if proc.returncode != 0:
            log.error("trial %d failed (rc=%d)", trial.number, proc.returncode)
            raise optuna.TrialPruned()
        value = _best_metric(
            os.path.join(ROOT, run_dir, spec.get("metrics_csv", "training_metrics.csv")),
            objective_col, direction
        )
        if value is None:
            raise optuna.TrialPruned()
        return value

    study = optuna.create_study(
        study_name=str(spec.get("study_name", "tune")),
        storage=spec.get("storage", None),
        direction=direction,
        sampler=optuna.samplers.TPESampler(seed=42),
        load_if_exists=True,
    )
    study.optimize(objective, n_trials=n_trials)

    log.info("Best %s = %.4f", objective_col, study.best_value)
    log.info("Best params: %s", study.best_params)
    out_csv = os.path.join(ROOT, output_root, "trials.csv")
    study.trials_dataframe().to_csv(out_csv, index=False)
    best_yaml = os.path.join(ROOT, output_root, "best_params.yaml")
    OmegaConf.save(OmegaConf.create(dict(study.best_params)), best_yaml)
    log.info("Wrote %s and %s", out_csv, best_yaml)
    print("\nRetrain the best config at full scale, e.g.:")
    print(f"  python {spec.train_script} --config {spec.base_config} \\")
    print("  " + " ".join(f"{k}={v}" for k, v in study.best_params.items()))


if __name__ == "__main__":
    main()
