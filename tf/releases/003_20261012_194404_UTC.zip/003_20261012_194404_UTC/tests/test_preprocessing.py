"""Unit tests for the fraud preprocessing pipeline (no S3 required).

Run: python -m pytest tests/test_preprocessing.py -q
"""

import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from fraud.data.datetime_features import DatetimeConfig, derive_datetime_features
from fraud.data.feature_list import load_feature_list
from fraud.data.preprocessing import (
    MISSING_INDEX,
    UNK_INDEX,
    ContinuousImputer,
    PreprocessingArtifacts,
)

PREDICTORS_CSV = os.path.join(
    os.path.dirname(__file__), "..", "fraud", "configs", "predictors.csv"
)


def _synthetic_df(n=200, seed=0):
    rng = np.random.default_rng(seed)
    ts = pd.date_range("2024-01-01", periods=n, freq="7h")
    df = pd.DataFrame(
        {
            "transaction_dttm": ts,
            "transaction_amt": rng.normal(50, 20, n),
            "external_1_scr": rng.integers(0, 100, n).astype(float),
            "transaction_type_xcd": rng.choice(["A", "B", "C"], n),
            "segment": rng.choice(["SIG_CHP", "SIG_CNP_K"], n),
            "frd_tag": rng.integers(0, 2, n),
        }
    )
    # Inject some missing values.
    df.loc[df.index[:10], "transaction_amt"] = np.nan
    df.loc[df.index[5:15], "transaction_type_xcd"] = None
    return df


def test_load_feature_list():
    fl = load_feature_list(PREDICTORS_CSV)
    assert "transaction_amt" in fl.continuous
    assert "transaction_type_xcd" in fl.categorical
    # Datetime-derived features present + typed categorical.
    for f in ("month", "day", "hour", "day_of_week"):
        assert f in fl.categorical
        assert f in fl.derived
    assert fl.order_col == "transaction_dttm"
    # 6 continuous + 17 categorical (13 raw + 4 datetime) = 23.
    assert len(fl.continuous) == 6
    assert len(fl.categorical) == 17
    # Raw source columns should include transaction_dttm (for derived) once.
    raw = fl.raw_source_columns()
    assert raw.count("transaction_dttm") == 1
    assert "month" not in raw


def test_version_filter():
    fl_all = load_feature_list(PREDICTORS_CSV, version=1)
    assert len(fl_all.all_features) == 23
    fl_none = load_feature_list(PREDICTORS_CSV, version=0)
    assert len(fl_none.all_features) == 0


def test_datetime_categorical():
    df = _synthetic_df()
    cfg = DatetimeConfig(fields=["month", "day", "hour", "day_of_week"])
    out, new_cont, new_cat = derive_datetime_features(df, cfg)
    assert new_cont == []
    assert set(new_cat) == {"month", "day", "hour", "day_of_week"}
    assert out["month"].between(1, 12).all()
    assert out["day_of_week"].between(0, 6).all()
    assert out["hour"].between(0, 23).all()


def test_datetime_cyclical():
    df = _synthetic_df()
    cfg = DatetimeConfig(fields=["hour"], encoding="cyclical")
    out, new_cont, new_cat = derive_datetime_features(df, cfg)
    assert set(new_cont) == {"hour_sin", "hour_cos"}
    assert new_cat == []
    assert out["hour_sin"].between(-1, 1).all()


def test_continuous_imputer_median_and_flag():
    df = _synthetic_df()
    imp = ContinuousImputer(strategy="median", add_flag=True)
    out = imp.fit_transform(df, ["transaction_amt"])
    assert out["transaction_amt"].isna().sum() == 0
    assert "transaction_amt_isna" in out.columns
    assert out["transaction_amt_isna"].iloc[:10].sum() == 10
    assert imp.flag_cols_ == ["transaction_amt_isna"]


def test_artifacts_fit_apply_roundtrip(tmp_path):
    df = _synthetic_df()
    art = PreprocessingArtifacts(artifact_version=1, predictor_version=1)
    art.fit_feature("transaction_amt", df["transaction_amt"], "continuous")
    art.fit_feature("transaction_type_xcd", df["transaction_type_xcd"], "categorical")

    # Categorical encoding: known -> >=2, missing -> MISSING, unseen -> UNK.
    enc = art.encode_categorical(
        "transaction_type_xcd", pd.Series(["A", None, "ZZZ"])
    )
    assert enc[0] >= 2
    assert enc[1] == MISSING_INDEX
    assert enc[2] == UNK_INDEX

    # Continuous standardize returns finite values, NaN imputed to median.
    std = art.standardize_continuous("transaction_amt", pd.Series([np.nan, 50.0]))
    assert np.isfinite(std).all()

    # Save + load roundtrip (local disk).
    base = os.path.join(tmp_path, "artifacts", "1")
    art.save(base)
    loaded = PreprocessingArtifacts.load(base)
    assert loaded.artifact_version == 1
    assert set(loaded.features) == {"transaction_amt", "transaction_type_xcd"}
    enc2 = loaded.encode_categorical("transaction_type_xcd", pd.Series(["A"]))
    assert enc2[0] == enc[0]
