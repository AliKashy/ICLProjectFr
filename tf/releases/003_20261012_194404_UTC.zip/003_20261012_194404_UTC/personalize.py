#!/usr/bin/env python3
"""Restore the documented package/path placeholders in this extracted copy."""
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--package', required=True)
parser.add_argument('--id', required=True)
parser.add_argument('--reference-id', required=True)
parser.add_argument('--data-bucket', required=True)
parser.add_argument('--artifact-bucket', required=True)
args = parser.parse_args()
if not args.package.isidentifier() or args.package == 'YOUR_PACKAGE':
    parser.error('--package must be the original Python package directory name')
for value in (args.id, args.reference_id):
    if not re.fullmatch(r'[Kk][0-9]{6}', value):
        parser.error('each ID must be k followed by six digits')
for value in (args.data_bucket, args.artifact_bucket):
    if not re.fullmatch(r'[a-z0-9][a-z0-9.-]+', value):
        parser.error('bucket arguments are bucket names, without s3:// or a path')
if (ROOT / 'PERSONALIZATION.json').exists():
    parser.error('this copy is already configured; run the smoke stage, or extract a new copy to change settings')
if (ROOT / args.package).exists():
    parser.error('the destination package directory already exists; use a fresh extracted copy')
meta = json.loads((ROOT / 'PACKAGE.json').read_text())
# Validate the distributed copy before deriving its personalized manifest.
for rel, expected in meta['files_sha256'].items():
    p = ROOT / rel
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest() != expected:
        parser.error('package file changed or missing before setup: ' + rel)
replacements = {
    'YOUR_PACKAGE': args.package,
    'YOUR_ID': args.id.upper(), 'your_id': args.id.lower(),
    'REFERENCE_ID': args.reference_id.upper(), 'reference_id': args.reference_id.lower(),
    'DATA_BUCKET': args.data_bucket, 'ARTIFACT_BUCKET': args.artifact_bucket,
}
manifest = 'runbook/2026-10-07/github_source_manifest.csv'
changed = []
# Only the known exported source/config files are personalized; instructions and this helper stay intact.
for rel in meta['personalize_files']:
    p = ROOT / rel
    old = p.read_bytes()
    new = old.decode('utf-8')
    for before, after in replacements.items():
        new = new.replace(before, after)
    new = new.encode('utf-8')
    if new != old:
        p.write_bytes(new)
        changed.append(rel.replace('YOUR_PACKAGE', args.package))
(ROOT / 'YOUR_PACKAGE').rename(ROOT / args.package)
# Preserve the fixed reviewed file list. This is not a rescan accepting arbitrary local edits.
p = ROOT / manifest
rows = list(csv.DictReader(io.StringIO(p.read_text())))
for row in rows:
    row['path'] = row['path'].replace('YOUR_PACKAGE', args.package)
    row['sha256_lf'] = hashlib.sha256((ROOT / row['path']).read_bytes().replace(b'\r\n', b'\n')).hexdigest()
with p.open('w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=['path', 'sha256_lf', 'class'], lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
record = {'package': meta['package'], 'source_commit': meta['source_commit'],
          'replacements': replacements, 'changed_files': changed,
          'personalized_source_manifest_sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
(ROOT / 'PERSONALIZATION.json').write_text(json.dumps(record, indent=2) + '\n')
print('Configured:', meta['package'])
print('Next: bash runbook/2026-10-07/smoke.sh')
