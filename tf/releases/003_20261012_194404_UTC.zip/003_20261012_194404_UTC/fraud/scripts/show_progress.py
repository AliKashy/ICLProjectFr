"""Show training progress (per-epoch metrics) in the terminal -- text only.

Two sources:
  * csv (default): reads the CSV written by train_baseline.py's CSVMetricsCallback.
  * tensorboard: reads scalar values straight from the newest TensorBoard run
    (event files under --logdir), so no CSV is needed.

With --follow it keeps polling and prints new rows as they arrive.

Usage:
    python fraud/scripts/show_progress.py
    python fraud/scripts/show_progress.py --file checkpoints/baseline/training_metrics.csv
    python fraud/scripts/show_progress.py --source tensorboard --granularity step --follow
    python fraud/scripts/show_progress.py --source tensorboard --granularity epoch --follow
"""

import argparse
import csv
import os
import time


def _read_rows(path):
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        return reader.fieldnames or [], list(reader)


def _newest_event_dir(logdir):
    """Return the directory of the most recent tfevents file under ``logdir``."""
    newest, newest_mtime = None, -1.0
    for root, _dirs, filenames in os.walk(logdir):
        for name in filenames:
            if name.startswith("events.out.tfevents"):
                mtime = os.path.getmtime(os.path.join(root, name))
                if mtime > newest_mtime:
                    newest, newest_mtime = root, mtime
    return newest


def _read_tb_step_rows(logdir):
    """Read per-STEP scalars from the newest TB run -> (fields, rows).

    One row per logged global step, with every scalar tag as a column
    (train_loss at step cadence, epoch, etc.). This is the fine-grained view.
    """
    from tensorboard.backend.event_processing.event_accumulator import EventAccumulator

    run_dir = _newest_event_dir(logdir)
    if run_dir is None:
        return [], []

    ea = EventAccumulator(run_dir, size_guidance={"scalars": 0})
    ea.Reload()
    tags = ea.Tags().get("scalars", [])

    by_step = {}
    for tag in tags:
        for ev in ea.Scalars(tag):
            by_step.setdefault(ev.step, {})[tag] = round(float(ev.value), 6)

    labels = sorted({lab for vals in by_step.values() for lab in vals})
    fields = ["step"] + labels
    rows = [{"step": step, **{lab: vals.get(lab, "") for lab in labels}}
            for step, vals in sorted(by_step.items())]
    return fields, rows


def _read_tb_epoch_rows(logdir):
    """Read per-EPOCH scalars from the newest TB run -> (fields, rows).

    Uses the ``epoch`` scalar to map each step to its epoch, then emits one row
    per epoch holding the LAST value of every metric within that epoch
    (end-of-epoch train_loss + that epoch's valid_*). Coarse-grained view.
    """
    from tensorboard.backend.event_processing.event_accumulator import EventAccumulator

    run_dir = _newest_event_dir(logdir)
    if run_dir is None:
        return [], []

    ea = EventAccumulator(run_dir, size_guidance={"scalars": 0})
    ea.Reload()
    tags = ea.Tags().get("scalars", [])
    if "epoch" not in tags:
        return [], []

    epoch_points = sorted((ev.step, int(round(ev.value))) for ev in ea.Scalars("epoch"))

    def epoch_of(step):
        e = epoch_points[0][1]
        for s, ep in epoch_points:
            if s <= step:
                e = ep
            else:
                break
        return e

    metric_tags = [t for t in tags if t not in ("epoch", "hp_metric")]
    per_epoch = {}
    for tag in metric_tags:
        for ev in ea.Scalars(tag):
            ep = epoch_of(ev.step)
            slot = per_epoch.setdefault(ep, {})
            prev = slot.get(tag)
            if prev is None or ev.step >= prev[0]:
                slot[tag] = (ev.step, round(float(ev.value), 6))

    labels = sorted({t for vals in per_epoch.values() for t in vals})
    fields = ["epoch"] + labels
    rows = [{"epoch": ep, **{t: vals.get(t, ("", ""))[1] for t in labels}}
            for ep, vals in sorted(per_epoch.items())]
    return fields, rows


def _fmt_row(fields, row, widths):
    return "  ".join(str(row.get(c, "")).ljust(widths[c]) for c in fields)


def _print_table(fields, rows):
    if not fields:
        print("No metrics available yet.")
        return
    widths = {c: max(len(c), *(len(str(r.get(c, ""))) for r in rows)) if rows else len(c)
              for c in fields}
    print(_fmt_row(fields, {c: c for c in fields}, widths))
    print("  ".join("-" * widths[c] for c in fields))
    for r in rows:
        print(_fmt_row(fields, r, widths))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", choices=["csv", "tensorboard"], default="csv",
                        help="Where to read metrics from.")
    parser.add_argument("--file", default="checkpoints/baseline/training_metrics.csv",
                        help="Path to training_metrics.csv (source=csv).")
    parser.add_argument("--logdir", default="tb_logs",
                        help="TensorBoard log directory (source=tensorboard).")
    parser.add_argument("--granularity", choices=["step", "epoch"], default="step",
                        help="TensorBoard row cadence: per-step (fine) or per-epoch (coarse).")
    parser.add_argument("--follow", action="store_true",
                        help="Keep polling and print new rows as they appear.")
    parser.add_argument("--interval", type=float, default=5.0,
                        help="Polling interval in seconds when --follow is set.")
    parser.add_argument("--stop-when-idle", type=float, default=0.0,
                        help="In --follow, auto-exit after this many seconds with no "
                             "new rows (0 = never; use Ctrl+C).")
    args = parser.parse_args()

    def read():
        if args.source == "csv":
            if not os.path.exists(args.file):
                return [], []
            return _read_rows(args.file)
        if args.granularity == "epoch":
            return _read_tb_epoch_rows(args.logdir)
        return _read_tb_step_rows(args.logdir)

    target = args.file if args.source == "csv" else args.logdir

    # Wait for the source to appear (training may not have started writing yet).
    if not os.path.exists(target):
        if not args.follow:
            print(f"No metrics at {target} yet.")
            return
        print(f"Waiting for {target} ...")
        while not os.path.exists(target):
            time.sleep(args.interval)

    fields, rows = read()
    _print_table(fields, rows)

    if not args.follow:
        return

    seen = len(rows)
    last_change = time.monotonic()
    while True:
        time.sleep(args.interval)
        fields, rows = read()
        if len(rows) > seen:
            widths = {c: max(len(c), *(len(str(r.get(c, ""))) for r in rows)) for c in fields}
            for r in rows[seen:]:
                print(_fmt_row(fields, r, widths))
            seen = len(rows)
            last_change = time.monotonic()
        elif args.stop_when_idle > 0 and (time.monotonic() - last_change) >= args.stop_when_idle:
            print(f"\nNo new rows for {args.stop_when_idle:g}s -- exiting.")
            return


if __name__ == "__main__":
    main()
