#!/usr/bin/env bash
# Fix SSH permissions after a fresh OCP pod start (fixes "UNPROTECTED PRIVATE KEY FILE" on git fetch/pull).
# Usage: ./fix_ssh_permissions.sh

set -euo pipefail

ssh_dir="${HOME}/.ssh"

if [[ ! -d "${ssh_dir}" ]]; then
    echo "No ${ssh_dir} directory found, nothing to fix." >&2
    exit 1
fi

chmod 700 "${ssh_dir}"

# Private keys must not be readable/writable by group or others.
find "${ssh_dir}" -maxdepth 1 -type f \( -name 'id_*' ! -name '*.pub' \) -print -exec chmod 600 {} \;

# Public keys, known_hosts, and config are safe to be group/other readable.
for f in known_hosts config; do
    [[ -f "${ssh_dir}/${f}" ]] && chmod 644 "${ssh_dir}/${f}"
done
find "${ssh_dir}" -maxdepth 1 -type f -name '*.pub' -exec chmod 644 {} \;

echo "SSH permissions fixed under ${ssh_dir}:"
ls -la "${ssh_dir}"
