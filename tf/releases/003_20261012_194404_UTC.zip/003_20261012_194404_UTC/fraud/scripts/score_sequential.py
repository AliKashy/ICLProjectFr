"""Score the sequential FT-Transformer checkpoint over an S3 parquet range (Phase 4).

Rebuilds the model from the frozen artifacts, loads the trained Lightning
checkpoint's weights, streams causal windows (eval_stride=1 -> every transaction
scored once), scores on GPU, writes predictions to S3, and reports AP / AUROC.

Usage:
    python fraud/scripts/score_sequential.py --config fraud/configs/sequential.yaml
    python fraud/scripts/score_sequential.py --config fraud/configs/sequential.yaml \
        eval.file_end=8010
"""

import argparse
import os
import sys

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import torch
from omegaconf import OmegaConf
from sklearn.metrics import average_precision_score, roc_auc_score
from torch.utils.data import DataLoader

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from fraud.data.datetime_features import DatetimeConfig
from fraud.data.feature_list import load_feature_list
from fraud.data.preprocessing import PreprocessingArtifacts
from fraud.data.s3_utils import build_file_list, make_s3_filesystem, strip_scheme
from fraud.data.sequence_builder import SequenceBuilder
from fraud.log_utils import setup_logging
from fraud.sequential_model import FTTransformerSeqModel

log = setup_logging()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("overrides", nargs="*")
    args = parser.parse_args()

    cfg = OmegaConf.load(args.config)
    if args.overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(args.overrides))

    fs = make_s3_filesystem(cfg.s3.cred_path)
    features = load_feature_list(
        cfg.predictors.csv_path, version=cfg.predictors.version, filesystem=fs
    )
    artifacts_path = f"{cfg.artifacts.base.rstrip('/')}/{cfg.artifacts.version}"
    artifacts = PreprocessingArtifacts.load(artifacts_path, filesystem=fs)
    dt_config = DatetimeConfig(
        order_col=cfg.data.order_col,
        fields=list(cfg.datetime.fields),
        encoding=cfg.datetime.encoding,
        is_weekend=cfg.datetime.is_weekend,
    )

    target_col = cfg.data.target_col
    id_cols = list(cfg.data.get("id_cols", []))
    amount_col = cfg.data.get("amount_col", None)

    eval_files = build_file_list(cfg.eval.base, cfg.eval.file_start, cfg.eval.file_end)
    dataset = SequenceBuilder(
        file_list=eval_files,
        artifacts=artifacts,
        features=features,
        datetime_config=dt_config,
        target_col=target_col,
        account_col=cfg.data.account_col,
        order_col=cfg.data.order_col,
        history_len=int(cfg.sequence.history_len),
        stride=int(cfg.sequence.get("eval_stride", 1)),
        positive_label=cfg.data.get("positive_label", 1),
        add_missing_flag=cfg.preprocess.add_missing_flag,
        time_delta=bool(cfg.sequence.get("time_delta", True)),
        batch_size=int(cfg.training.batch_size),
        shuffle=False,
        tie_break_col=cfg.data.get("tie_break_col", None),
        id_cols=id_cols,
        amount_col=amount_col,
        s3_cred_path=cfg.s3.cred_path,
    )
    loader = DataLoader(dataset, batch_size=None, num_workers=int(cfg.training.get("num_workers", 0)))

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = FTTransformerSeqModel(
        continuous_dim=len(dataset.continuous_cols),
        categorical_cardinality=dataset.categorical_cardinality,
        history_len=int(cfg.sequence.history_len),
        embed_dim=int(cfg.model.input_embed_dim),
        num_heads=int(cfg.model.num_heads),
        num_attn_blocks=int(cfg.model.num_attn_blocks),
        attn_dropout=float(cfg.model.attn_dropout),
        ff_dropout=float(cfg.model.ff_dropout),
        attention_mask=cfg.sequence.get("attention_mask", "bidirectional"),
    )
    ckpt = torch.load(cfg.eval.checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(ckpt["state_dict"])
    model.eval().to(device)
    log.info("Loaded checkpoint %s on %s", cfg.eval.checkpoint, device)

    scores, labels, meta_cols = [], [], {c: [] for c in id_cols}
    if amount_col:
        meta_cols[amount_col] = []
    gpu_confirmed = False
    for batch in loader:
        with torch.no_grad():
            logits = model({
                "continuous": batch["continuous"].to(device),
                "categorical": batch["categorical"].to(device),
                "mask": batch["mask"].to(device),
            })
            prob = torch.softmax(logits, dim=-1)[:, 1].cpu().numpy()
        if device == "cuda" and not gpu_confirmed:
            log.info("GPU confirmed: model on %s, %.1f MB allocated",
                     next(model.parameters()).device, torch.cuda.memory_allocated(0) / 1e6)
            gpu_confirmed = True
        scores.append(prob)
        labels.append(batch["target"].numpy().reshape(-1))
        for c in meta_cols:
            meta_cols[c].append(batch["meta"][c])

    score = np.concatenate(scores)
    y_true = np.concatenate(labels)
    out = {c: np.concatenate(v) for c, v in meta_cols.items()}
    out[target_col] = y_true
    out["score"] = score

    out_path = strip_scheme(f"{cfg.eval.predictions_base.rstrip('/')}/sequential_preds.parquet")
    pq.write_table(pa.table(out), out_path, filesystem=fs)
    log.info("Wrote %d predictions -> %s (positives=%d)", len(score), out_path, int(y_true.sum()))

    if bool(cfg.eval.get("compute_metrics", False)):
        ap = average_precision_score(y_true, score)
        auc = roc_auc_score(y_true, score)
        log.info("Range metrics (fraud = positive): average_precision=%.4f  auroc=%.4f "
                 "(n=%d, positives=%d)", ap, auc, len(y_true), int(y_true.sum()))


if __name__ == "__main__":
    main()
