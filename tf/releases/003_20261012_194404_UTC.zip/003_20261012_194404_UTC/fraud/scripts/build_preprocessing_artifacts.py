"""Build versioned preprocessing artifacts for the streaming training path.

Fits per-feature statistics (continuous mean/std/median; categorical vocab with
reserved UNK/MISSING indices) over a configurable set of parquet files used in
full (no row sampling), processing a configurable number of features at a time
to bound memory. Writes ``manifest.json`` + per-feature JSON to S3 (or local).

Usage:
    python fraud/scripts/build_preprocessing_artifacts.py \
        --config fraud/configs/preprocessing.yaml
    python fraud/scripts/build_preprocessing_artifacts.py \
        --config fraud/configs/preprocessing.yaml build.features_per_batch=3
"""

import argparse
import os
import sys

import pandas as pd
import pyarrow.parquet as pq
from omegaconf import OmegaConf

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from fraud.data.datetime_features import DatetimeConfig, derive_datetime_features
from fraud.data.feature_list import load_feature_list
from fraud.data.preprocessing import PreprocessingArtifacts
from fraud.data.s3_utils import build_file_list, make_s3_filesystem, strip_scheme
from fraud.log_utils import setup_logging

log = setup_logging()


def _read_columns(files, columns, filesystem):
    """Read only ``columns`` across ``files`` and concatenate."""
    frames = []
    for path in files:
        p = strip_scheme(path) if filesystem is not None else path
        df = pq.ParquetDataset(p, filesystem=filesystem).read(columns=columns).to_pandas()
        frames.append(df)
    return pd.concat(frames, ignore_index=True)


def _batches(items, size):
    for i in range(0, len(items), size):
        yield items[i:i + size]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("overrides", nargs="*")
    args = parser.parse_args()

    cfg = OmegaConf.load(args.config)
    if args.overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(args.overrides))

    fs = make_s3_filesystem(cfg.s3.cred_path)

    # Feature list (source of truth), typed + version-filtered.
    features = load_feature_list(
        cfg.predictors.csv_path,
        version=cfg.predictors.version,
        filesystem=fs,
    )
    order_col = cfg.data.order_col
    dt_config = DatetimeConfig(
        order_col=order_col,
        fields=list(cfg.datetime.fields),
        encoding=cfg.datetime.encoding,
        is_weekend=cfg.datetime.is_weekend,
    )
    derived_set = set(features.derived)

    files = build_file_list(cfg.data.base, cfg.data.file_start, cfg.data.file_end)
    log.info("Fitting artifacts on %d files (in full): %s..%s",
             len(files), cfg.data.file_start, cfg.data.file_end)

    artifacts = PreprocessingArtifacts(
        artifact_version=cfg.build.artifact_version,
        predictor_version=cfg.predictors.version,
        fit_files=[os.path.basename(f) for f in files],
    )

    # Rows of the feature table drive type + source; batch them for memory.
    feature_rows = list(features.frame.itertuples(index=False))
    per_batch = int(cfg.build.features_per_batch)

    for batch in _batches(feature_rows, per_batch):
        names = [r.feature for r in batch]
        needs_datetime = any(r.feature in derived_set for r in batch)

        # Raw parquet columns needed for this batch.
        raw_cols = []
        for r in batch:
            src = str(r.source)
            col = src.split(":", 1)[1] if src.startswith("derived:") else str(r.feature)
            if col not in raw_cols:
                raw_cols.append(col)
        if needs_datetime and order_col not in raw_cols:
            raw_cols.append(order_col)

        log.info("batch: %s  (reading cols: %s)", names, raw_cols)
        df = _read_columns(files, raw_cols, fs)

        if needs_datetime:
            df, _, _ = derive_datetime_features(df, dt_config)

        for r in batch:
            artifacts.fit_feature(r.feature, df[r.feature], r.type)

        del df  # free memory before next batch

    out_base = f"{cfg.build.output_base.rstrip('/')}/{cfg.build.artifact_version}"
    artifacts.save(out_base, filesystem=fs)
    log.info("Saved %d feature artifacts to %s", len(artifacts.features), out_base)
    log.info("Manifest: %s", artifacts.manifest())


if __name__ == "__main__":
    main()
