#!/usr/bin/env bash
# Reconstructed file: original screenshot evidence begins at source line 4.
# Original lines 1-3 were not present in the supplied images; body below is screenshot-proven.
set -euo pipefail

if [[ $# -ne 1 ]]; then
    echo "Usage: $0 <pid>" >&2
    exit 1
fi

pid="$1"

if [[ ! -d "/proc/${pid}" ]]; then
    echo "No such process: PID ${pid}" >&2
    exit 1
fi

echo "============================================"
echo "  PID ${pid} details"
echo "============================================"

echo
echo "--- ps (owner, cpu/mem, elapsed) ---"
ps -o pid,ppid,user,etime,%cpu,%mem,cmd -p "${pid}" || true

echo
echo "--- Full command line ---"
tr '\0' ' ' < "/proc/${pid}/cmdline" 2>/dev/null; echo

echo
echo "--- Working directory (reveals real owner's home dir) ---"
readlink "/proc/${pid}/cwd" 2>/dev/null || echo "(permission denied or process gone)"

echo
echo "--- Status (memory, threads, state) ---"
grep -E 'VmRSS|VmSize|State|Threads' "/proc/${pid}/status" 2>/dev/null || true

echo
echo "--- Open files (first 20) ---"
ls -l "/proc/${pid}/fd" 2>/dev/null | head -20 || echo "(permission denied)"

echo
echo "--- GPU usage (if any) ---"
if command -v nvidia-smi >/dev/null 2>&1; then
    nvidia-smi --query-compute-apps=pid,used_memory,process_name --format=csv 2>/dev/null | \
        awk -F',' -v p="${pid}" 'NR==1 || $1+0==p'
else
    echo "nvidia-smi not available"
fi
