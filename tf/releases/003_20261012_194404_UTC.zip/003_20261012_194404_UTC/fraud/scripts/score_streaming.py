"""Score the streaming FT-Transformer checkpoint over an S3 parquet range.

Rebuilds the model architecture from the frozen artifacts, loads the trained
Lightning checkpoint's weights, streams the eval range one batch at a time with
identical artifact preprocessing, scores on GPU, and writes per-file prediction
parquet files. This validates the frozen-artifact path end-to-end.

Usage:
    python fraud/scripts/score_streaming.py --config fraud/configs/streaming.yaml
    python fraud/scripts/score_streaming.py --config fraud/configs/streaming.yaml \
        eval.file_start=8000 eval.file_end=8010
"""

import argparse
import os
import sys

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import torch
from omegaconf import OmegaConf
from sklearn.metrics import average_precision_score, roc_auc_score

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from fraud.data.datetime_features import DatetimeConfig
from fraud.data.feature_list import load_feature_list
from fraud.data.parquet_loader import (
    ParquetStreamingDataset,
    streaming_categorical_cardinality,
    streaming_categorical_columns,
)
from fraud.data.preprocessing import PreprocessingArtifacts
from fraud.data.s3_utils import build_file_list, make_s3_filesystem, strip_scheme
from fraud.log_utils import setup_logging
from fraud.streaming_model import build_streaming_model

log = setup_logging()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("overrides", nargs="*")
    args = parser.parse_args()

    cfg = OmegaConf.load(args.config)
    if args.overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(args.overrides))

    fs = make_s3_filesystem(cfg.s3.cred_path)
    features = load_feature_list(
        cfg.predictors.csv_path, version=cfg.predictors.version, filesystem=fs
    )
    artifacts_path = f"{cfg.artifacts.base.rstrip('/')}/{cfg.artifacts.version}"
    artifacts = PreprocessingArtifacts.load(artifacts_path, filesystem=fs)
    dt_config = DatetimeConfig(
        order_col=cfg.data.order_col,
        fields=list(cfg.datetime.fields),
        encoding=cfg.datetime.encoding,
        is_weekend=cfg.datetime.is_weekend,
    )

    add_flag = cfg.preprocess.add_missing_flag
    categorical_cols = streaming_categorical_columns(features, add_flag)
    cardinalities = streaming_categorical_cardinality(artifacts, features, add_flag)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = build_streaming_model(
        model_cfg=cfg.model,
        cardinalities=cardinalities,
        continuous_cols=list(features.continuous),
        categorical_cols=categorical_cols,
        target_col=cfg.data.target_col,
    )
    # Our own checkpoint stores an OmegaConf DictConfig -> weights_only=False.
    ckpt = torch.load(cfg.eval.checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(ckpt["state_dict"])
    model.eval().to(device)
    log.info("Loaded checkpoint %s on %s", cfg.eval.checkpoint, device)

    # An encoder instance reused per batch (shares artifact preprocessing).
    encoder = ParquetStreamingDataset(
        file_list=[], artifacts=artifacts, features=features, datetime_config=dt_config,
        target_col=cfg.data.target_col, positive_label=cfg.data.get("positive_label", 1),
        add_missing_flag=add_flag,
    )

    target_col = cfg.data.target_col
    pos_label = cfg.data.get("positive_label", 1)
    id_cols = list(cfg.data.get("id_cols", []))
    amount_col = cfg.data.get("amount_col", None)
    read_cols = list(encoder._read_cols)
    for extra in [amount_col, *id_cols]:
        if extra and extra not in read_cols:
            read_cols.append(extra)

    out_base = cfg.eval.predictions_base.rstrip("/")
    compute_metrics = bool(cfg.eval.get("compute_metrics", False))
    all_true, all_score = [], []

    files = build_file_list(cfg.eval.base, cfg.eval.file_start, cfg.eval.file_end)
    log.info("Scoring %d file(s) on %s -> %s", len(files), device, out_base)

    for path in files:
        part = os.path.basename(path)
        pf = pq.ParquetFile(strip_scheme(path), filesystem=fs)
        scores, ids, amounts, targets = [], {c: [] for c in id_cols}, [], []
        for rb in pf.iter_batches(batch_size=cfg.training.batch_size, columns=read_cols):
            df = rb.to_pandas()
            cont, cat, tgt = encoder._encode_batch(df)
            with torch.no_grad():
                logits = model({"continuous": torch.from_numpy(cont).to(device),
                                "categorical": torch.from_numpy(cat).to(device)})["logits"]
                prob = torch.softmax(logits, dim=-1)[:, 1].cpu().numpy()
            scores.append(prob)
            targets.append(tgt.ravel())
            for c in id_cols:
                ids[c].append(df[c].to_numpy())
            if amount_col:
                amounts.append(df[amount_col].to_numpy())

        score = np.concatenate(scores)
        y_true = np.concatenate(targets)
        out = {c: np.concatenate(ids[c]) for c in id_cols}
        out[target_col] = y_true
        out["score"] = score
        if amount_col:
            out[amount_col] = np.concatenate(amounts)

        out_path = strip_scheme(f"{out_base}/{part}")
        pq.write_table(pa.table(out), out_path, filesystem=fs)
        log.info("%s: %d rows, positives=%d -> %s", part, len(score), int(y_true.sum()), out_path)

        if compute_metrics:
            all_true.append(y_true)
            all_score.append(score)

    if compute_metrics and all_true:
        y_true = np.concatenate(all_true)
        y_score = np.concatenate(all_score)
        ap = average_precision_score(y_true, y_score)
        auc = roc_auc_score(y_true, y_score)
        log.info("Range metrics (fraud = positive): average_precision=%.4f  auroc=%.4f  "
                 "(n=%d, positives=%d)", ap, auc, len(y_true), int(y_true.sum()))


if __name__ == "__main__":
    main()
