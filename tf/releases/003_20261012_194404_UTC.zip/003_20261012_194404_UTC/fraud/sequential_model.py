"""Flat SEP-token sequential FT-Transformer (Phase 4).

Each transaction's features are tokenized (one token per feature); a learned
transaction-position embedding is added, a CLS token is prepended, and the flat
token sequence is passed through a TransformerEncoder. Padded (missing-history)
transactions are masked at the token level. Attention is bidirectional by
default, with an optional causal mask at the transaction level for future use.

Input: batch dict from ``SequenceBuilder``:
  continuous  [B, T, C] float (C incl. time-delta)
  categorical [B, T, K] long
  mask        [B, T] bool (True = real transaction)
  target      [B, 1] long
"""

from typing import List

import pytorch_lightning as pl
import torch
import torch.nn as nn


class TransactionEmbedding(nn.Module):
    """Tokenize one transaction: per-feature continuous + categorical -> tokens."""

    def __init__(self, continuous_dim: int, categorical_cardinality: List[int], embed_dim: int):
        super().__init__()
        self.continuous_dim = continuous_dim
        self.embed_dim = embed_dim
        # Per-continuous-feature linear tokenizer: value * w + b -> [d].
        self.cont_weight = nn.Parameter(torch.empty(continuous_dim, embed_dim))
        self.cont_bias = nn.Parameter(torch.zeros(continuous_dim, embed_dim))
        nn.init.normal_(self.cont_weight, std=0.02)
        self.cat_embeddings = nn.ModuleList(
            [nn.Embedding(card, embed_dim) for card in categorical_cardinality]
        )

    def forward(self, continuous, categorical):
        # continuous [N, C], categorical [N, K] -> [N, C+K, d]
        cont_tok = continuous.unsqueeze(-1) * self.cont_weight + self.cont_bias  # [N, C, d]
        cat_tok = torch.stack(
            [emb(categorical[:, i]) for i, emb in enumerate(self.cat_embeddings)], dim=1
        ) if self.cat_embeddings else continuous.new_zeros(continuous.size(0), 0, self.embed_dim)
        return torch.cat([cont_tok, cat_tok], dim=1)  # [N, C+K, d]


class FTTransformerSeqModel(pl.LightningModule):
    def __init__(
        self,
        continuous_dim: int,
        categorical_cardinality: List[int],
        history_len: int,
        embed_dim: int = 48,
        num_heads: int = 8,
        num_attn_blocks: int = 4,
        ff_multiplier: int = 4,
        attn_dropout: float = 0.1,
        ff_dropout: float = 0.1,
        attention_mask: str = "bidirectional",
        learning_rate: float = 3e-4,
        weight_decay: float = 1e-5,
        pos_weight: float = 1.0,
    ):
        super().__init__()
        self.save_hyperparameters()
        self.T = history_len + 1
        self.tokens_per_txn = continuous_dim + len(categorical_cardinality)
        self.attention_mask = attention_mask

        self.embedding = TransactionEmbedding(continuous_dim, categorical_cardinality, embed_dim)
        self.txn_position = nn.Embedding(self.T, embed_dim)
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        nn.init.normal_(self.cls_token, std=0.02)

        layer = nn.TransformerEncoderLayer(
            d_model=embed_dim,
            nhead=num_heads,
            dim_feedforward=embed_dim * ff_multiplier,
            dropout=ff_dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        # attn_dropout is applied inside MHA; align it with the layer's self-attn.
        layer.self_attn.dropout = attn_dropout
        self.encoder = nn.TransformerEncoder(layer, num_layers=num_attn_blocks)
        self.head = nn.Linear(embed_dim, 2)

        weight = None
        if pos_weight and pos_weight != 1.0:
            weight = torch.tensor([1.0, float(pos_weight)])
        self.loss_fn = nn.CrossEntropyLoss(weight=weight)

    def _build_causal_mask(self, device):
        # Block-causal at the transaction level over the token sequence (+CLS at 0).
        L = 1 + self.T * self.tokens_per_txn
        # transaction index per token position (CLS -> -1 so it sees nothing extra restricted)
        txn_of = torch.full((L,), -1, dtype=torch.long, device=device)
        for t in range(self.T):
            start = 1 + t * self.tokens_per_txn
            txn_of[start:start + self.tokens_per_txn] = t
        ti = txn_of.unsqueeze(1)
        tj = txn_of.unsqueeze(0)
        # allowed if key is CLS, query is CLS, or key-txn <= query-txn
        allowed = (tj < 0) | (ti < 0) | (tj <= ti)
        return ~allowed  # True = disallowed (nn.Transformer additive/bool mask)

    def forward(self, batch):
        continuous, categorical, mask = batch["continuous"], batch["categorical"], batch["mask"]
        B, T, C = continuous.shape
        K = categorical.shape[-1]
        d = self.hparams.embed_dim

        tokens = self.embedding(
            continuous.reshape(B * T, C), categorical.reshape(B * T, K)
        )  # [B*T, C+K, d]
        tokens = tokens.reshape(B, T, self.tokens_per_txn, d)
        pos = self.txn_position(torch.arange(T, device=continuous.device))  # [T, d]
        tokens = tokens + pos[None, :, None, :]
        tokens = tokens.reshape(B, T * self.tokens_per_txn, d)

        cls = self.cls_token.expand(B, 1, d)
        seq = torch.cat([cls, tokens], dim=1)  # [B, 1 + T*(C+K), d]

        token_valid = mask.unsqueeze(-1).expand(B, T, self.tokens_per_txn).reshape(B, -1)
        key_padding = torch.cat(
            [torch.zeros(B, 1, dtype=torch.bool, device=mask.device), ~token_valid], dim=1
        )  # True = ignore
        attn_mask = self._build_causal_mask(seq.device) if self.attention_mask == "causal" else None

        out = self.encoder(seq, mask=attn_mask, src_key_padding_mask=key_padding)
        return self.head(out[:, 0])  # CLS -> [B, 2]

    def _step(self, batch, tag):
        logits = self(batch)
        y = batch["target"].reshape(-1)
        loss = self.loss_fn(logits, y)
        self.log(f"{tag}_loss", loss, on_epoch=True, on_step=(tag == "train"),
                 prog_bar=True, sync_dist=True)
        return logits, y, loss

    def training_step(self, batch, batch_idx):
        _, _, loss = self._step(batch, "train")
        return loss

    def validation_step(self, batch, batch_idx):
        logits, y, _ = self._step(batch, "valid")
        return logits, y  # consumed by StreamingBinaryMetrics

    def configure_optimizers(self):
        opt = torch.optim.AdamW(
            self.parameters(), lr=self.hparams.learning_rate,
            weight_decay=self.hparams.weight_decay,
        )
        sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, patience=3, factor=0.5)
        return {"optimizer": opt, "lr_scheduler": {"scheduler": sched, "monitor": "valid_loss"}}
