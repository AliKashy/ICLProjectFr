"""S3 filesystem helpers shared across fraud scripts.

Loads credentials from a YAML file (same pattern as the EDA notebook) and
constructs an ``s3fs.S3FileSystem``. Paths may be given with or without the
``s3://`` scheme; :func:`strip_scheme` normalizes them for pyarrow + s3fs.
"""

import os
from typing import List, Optional

import yaml

DEFAULT_CRED_PATH = "/home/jovyan/S3_credentials.yml"


def make_s3_filesystem(cred_path: str = DEFAULT_CRED_PATH):
    """Create an s3fs filesystem from a YAML credentials file.

    The YAML file must contain ``AWS_ACCESS_KEY_ID``, ``AWS_SECRET_ACCESS_KEY``
    and ``AWS_ENDPOINT_URL`` keys.
    """
    from s3fs import S3FileSystem

    with open(cred_path, "r") as f:
        config_data = yaml.safe_load(f)

    os.environ["AWS_ACCESS_KEY_ID"] = config_data["AWS_ACCESS_KEY_ID"]
    os.environ["AWS_SECRET_ACCESS_KEY"] = config_data["AWS_SECRET_ACCESS_KEY"]
    os.environ["AWS_ENDPOINT_URL"] = config_data["AWS_ENDPOINT_URL"]

    return S3FileSystem(
        key=os.environ["AWS_ACCESS_KEY_ID"],
        secret=os.environ["AWS_SECRET_ACCESS_KEY"],
        client_kwargs={"endpoint_url": os.environ["AWS_ENDPOINT_URL"], "verify": False},
        skip_instance_cache=True,
    )


def strip_scheme(path: str) -> str:
    """Remove an ``s3://`` / ``s3a://`` scheme prefix for pyarrow + s3fs."""
    for scheme in ("s3://", "s3a://"):
        if path.startswith(scheme):
            return path[len(scheme):]
    return path


def build_file_list(base: str, start: int, end: int, prefix: str = "part_",
                    suffix: str = ".parquet") -> List[str]:
    """Build an inclusive list of ``<base>/<prefix><n><suffix>`` paths."""
    base = base.rstrip("/")
    return [f"{base}/{prefix}{i}{suffix}" for i in range(start, end + 1)]
