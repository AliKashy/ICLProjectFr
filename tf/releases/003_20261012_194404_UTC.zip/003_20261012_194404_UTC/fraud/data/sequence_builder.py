"""Streaming sequence builder for the history-aware (Phase 4) fraud model.

For each target transaction it builds a fixed-length window of the target plus
its ``history_len`` most recent PRIOR transactions from the same account
(strictly causal), left-padded when there is not enough history. Preprocessing
reuses the FROZEN artifacts per transaction; a per-transaction time-delta
(log seconds to the target) is appended as an extra continuous feature.

Yields whole-batch tensor dicts (use ``DataLoader(batch_size=None)``):
    {
      "continuous": FloatTensor[B, T, C],  # C = n_continuous + 1 (time-delta)
      "categorical": LongTensor[B, T, K],  # K = artifact cats + _isna flags
      "mask": BoolTensor[B, T],             # True = real transaction, False = pad
      "target": LongTensor[B, 1],           # target transaction's frd_tag
    }
with ``T = history_len + 1`` (target at slot T-1).

Correlation note: with ``stride=1`` an account's windows overlap heavily, so a
window-level shuffle buffer spanning many accounts is used for training.
"""

from typing import List, Optional

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
import torch
from torch.utils.data import IterableDataset

from fraud.data.datetime_features import DatetimeConfig, derive_datetime_features
from fraud.data.feature_list import FeatureList
from fraud.data.parquet_loader import (
    streaming_categorical_cardinality,
    streaming_categorical_columns,
)
from fraud.data.preprocessing import PreprocessingArtifacts
from fraud.data.s3_utils import make_s3_filesystem, strip_scheme


def sequence_continuous_columns(features: FeatureList, time_delta: bool) -> List[str]:
    """Continuous columns the model sees per transaction (+ time_delta last)."""
    cols = list(features.continuous)
    if time_delta:
        cols = cols + ["time_delta"]
    return cols


class SequenceBuilder(IterableDataset):
    """Stream account-grouped causal windows, encoded via frozen artifacts.

    Args:
        file_list: Parquet file paths (with or without ``s3://`` scheme).
        artifacts: Loaded ``PreprocessingArtifacts`` for encode/standardize.
        features: ``FeatureList`` (continuous/categorical order + order_col).
        datetime_config: Config for deriving datetime features per file.
        target_col: Raw target column name.
        account_col: Account/customer id column (groups transactions).
        order_col: Timestamp column for causal ordering.
        history_len: N prior transactions (window length T = N + 1).
        stride: Target subsampling step; fraud targets are never skipped.
        positive_label: Raw value of the positive (fraud) class.
        add_missing_flag: Append ``<col>_isna`` categorical flags.
        time_delta: Append log-seconds-to-target as an extra continuous feature.
        batch_size: Windows per yielded batch.
        shuffle: Shuffle files + window buffer (training) vs deterministic (eval).
        buffer_windows: Window shuffle-pool size (spans many accounts).
        tie_break_col: Secondary sort key for equal timestamps (e.g. txn id).
        s3_filesystem / s3_cred_path: S3 access (per-worker lazy build if cred).
    """

    def __init__(
        self,
        file_list: List[str],
        artifacts: PreprocessingArtifacts,
        features: FeatureList,
        datetime_config: DatetimeConfig,
        target_col: str,
        account_col: str,
        order_col: str,
        history_len: int = 5,
        stride: int = 1,
        positive_label=1,
        add_missing_flag: bool = True,
        time_delta: bool = True,
        batch_size: int = 4096,
        shuffle: bool = False,
        buffer_windows: int = 65536,
        tie_break_col: Optional[str] = None,
        id_cols: Optional[List[str]] = None,
        amount_col: Optional[str] = None,
        s3_filesystem=None,
        s3_cred_path: Optional[str] = None,
    ):
        self.file_list = file_list
        self.artifacts = artifacts
        self.features = features
        self.datetime_config = datetime_config
        self.target_col = target_col
        self.account_col = account_col
        self.order_col = order_col
        self.history_len = history_len
        self.stride = max(1, stride)
        self.positive_label = positive_label
        self.add_missing_flag = add_missing_flag
        self.time_delta = time_delta
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.buffer_windows = max(buffer_windows, batch_size)
        self.tie_break_col = tie_break_col
        self.id_cols = list(id_cols) if id_cols else []
        self.amount_col = amount_col
        self._emit_meta = bool(self.id_cols or amount_col)
        self.s3_filesystem = s3_filesystem
        self.s3_cred_path = s3_cred_path

        self.continuous_cols = sequence_continuous_columns(features, time_delta)
        self.categorical_cols = streaming_categorical_columns(features, add_missing_flag)
        self.categorical_cardinality = streaming_categorical_cardinality(
            artifacts, features, add_missing_flag
        )
        self.T = history_len + 1

        read_cols = list(features.raw_source_columns())
        for extra in [target_col, account_col, order_col, tie_break_col,
                      amount_col, *self.id_cols]:
            if extra and extra not in read_cols:
                read_cols.append(extra)
        self._read_cols = read_cols

    # -- setup --------------------------------------------------------------
    def _ensure_fs(self):
        if self.s3_filesystem is None and self.s3_cred_path is not None:
            self.s3_filesystem = make_s3_filesystem(self.s3_cred_path)
        return self.s3_filesystem

    def _get_worker_files(self):
        worker_info = torch.utils.data.get_worker_info()
        files = list(self.file_list)
        if self.shuffle:
            np.random.shuffle(files)
        if worker_info is not None:
            files = files[worker_info.id :: worker_info.num_workers]
        return files

    # -- per-file encoding --------------------------------------------------
    def _encode_file(self, df):
        """Encode a whole file once -> per-row arrays reused by all windows."""
        df, _, _ = derive_datetime_features(df, self.datetime_config)

        cont = np.stack(
            [self.artifacts.standardize_continuous(c, df[c]) for c in self.features.continuous],
            axis=1,
        ).astype(np.float32)  # [rows, n_cont]

        cat_arrays = [self.artifacts.encode_categorical(c, df[c]) for c in self.features.categorical]
        if self.add_missing_flag:
            cat_arrays += [df[c].isna().to_numpy().astype(np.int64) for c in self.features.continuous]
        cat = np.stack(cat_arrays, axis=1).astype(np.int64)  # [rows, K]

        target = (df[self.target_col].to_numpy() == self.positive_label).astype(np.int64)
        times = (pd.to_datetime(df[self.order_col], errors="coerce")
                 .values.astype("datetime64[s]").astype("int64"))
        meta = None
        if self._emit_meta:
            meta = {c: df[c].to_numpy() for c in self.id_cols}
            if self.amount_col:
                meta[self.amount_col] = df[self.amount_col].to_numpy()
        return cont, cat, target, times, df, meta

    # -- windowing ----------------------------------------------------------
    def _account_groups(self, df):
        """Row-position lists per account, sorted by time (+ tie-break)."""
        sort_cols = [self.account_col, self.order_col]
        if self.tie_break_col:
            sort_cols.append(self.tie_break_col)
        sorted_pos = (
            df.reset_index(drop=True)
            .sort_values(sort_cols, kind="stable")
            .index.to_numpy()
        )
        acct = df[self.account_col].to_numpy()
        groups = {}
        for p in sorted_pos:
            groups.setdefault(acct[p], []).append(int(p))
        return groups

    def _windows_for_file(self, cont, cat, target, times, df, meta):
        n_cont = cont.shape[1]
        C = n_cont + (1 if self.time_delta else 0)
        K = cat.shape[1]
        T = self.T

        for acct, rows in self._account_groups(df).items():
            for pos in range(len(rows)):
                target_row = rows[pos]
                is_fraud = target[target_row] == 1
                if (pos % self.stride != 0) and not is_fraud:
                    continue

                hist = rows[max(0, pos - self.history_len):pos]
                pad = self.history_len - len(hist)
                slot_rows = ([-1] * pad) + list(hist) + [target_row]

                w_cont = np.zeros((T, C), dtype=np.float32)
                w_cat = np.zeros((T, K), dtype=np.int64)
                w_mask = np.zeros((T,), dtype=bool)
                t_target = times[target_row]
                for s, r in enumerate(slot_rows):
                    if r < 0:
                        continue
                    w_cont[s, :n_cont] = cont[r]
                    if self.time_delta:
                        w_cont[s, n_cont] = np.log1p(max(0, int(t_target - times[r])))
                    w_cat[s] = cat[r]
                    w_mask[s] = True

                row_meta = (
                    {c: meta[c][target_row] for c in meta} if meta is not None else None
                )
                yield w_cont, w_cat, w_mask, np.int64(target[target_row]), row_meta

    # -- iteration ----------------------------------------------------------
    def _emit_batches(self, buffer):
        if self.shuffle:
            np.random.shuffle(buffer)
        for start in range(0, len(buffer), self.batch_size):
            chunk = buffer[start:start + self.batch_size]
            out = {
                "continuous": torch.from_numpy(np.stack([w[0] for w in chunk])),
                "categorical": torch.from_numpy(np.stack([w[1] for w in chunk])),
                "mask": torch.from_numpy(np.stack([w[2] for w in chunk])),
                "target": torch.from_numpy(
                    np.array([w[3] for w in chunk], dtype=np.int64).reshape(-1, 1)
                ),
            }
            if self._emit_meta:
                keys = list(chunk[0][4].keys())
                out["meta"] = {k: np.array([w[4][k] for w in chunk]) for k in keys}
            yield out

    def __iter__(self):
        fs = self._ensure_fs()
        buffer: list = []

        for filepath in self._get_worker_files():
            path = strip_scheme(filepath) if fs is not None else filepath
            df = pq.ParquetDataset(path, filesystem=fs).read(columns=self._read_cols).to_pandas()
            cont, cat, target, times, df, meta = self._encode_file(df)
            for window in self._windows_for_file(cont, cat, target, times, df, meta):
                buffer.append(window)
                if len(buffer) >= self.buffer_windows:
                    yield from self._emit_batches(buffer)
                    buffer = []

        if buffer:
            yield from self._emit_batches(buffer)
