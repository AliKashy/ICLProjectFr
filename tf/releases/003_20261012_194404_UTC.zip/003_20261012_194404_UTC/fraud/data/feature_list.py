"""Load the versioned predictor list (source of truth) into typed column lists.

The predictor list is a CSV with columns:
``feature, type, source, version, description``

- ``type``   : ``continuous`` or ``categorical``
- ``source`` : ``raw`` or ``derived:<col>`` (e.g. ``derived:transaction_dttm``)
- ``version``: integer; rows are additive across versions

The CSV can live locally or in S3. Reading is done with pandas (which supports
an ``s3fs`` filesystem via ``storage_options``) or an explicit filesystem handle.
"""

from dataclasses import dataclass, field
from typing import List, Optional

import pandas as pd

from fraud.data.s3_utils import strip_scheme

CONTINUOUS = "continuous"
CATEGORICAL = "categorical"


@dataclass
class FeatureList:
    """Typed view of the predictor list, filtered to a max version."""

    continuous: List[str] = field(default_factory=list)
    categorical: List[str] = field(default_factory=list)
    derived: List[str] = field(default_factory=list)  # features with source derived:*
    order_col: Optional[str] = None
    frame: Optional[pd.DataFrame] = None

    @property
    def all_features(self) -> List[str]:
        return self.continuous + self.categorical

    def raw_source_columns(self) -> List[str]:
        """Raw parquet columns needed to build every feature.

        Non-derived features map to themselves; derived features map to their
        source column (e.g. ``transaction_dttm``).
        """
        cols: List[str] = []
        for _, row in self.frame.iterrows():
            src = str(row["source"])
            if src.startswith("derived:"):
                col = src.split(":", 1)[1]
            else:
                col = str(row["feature"])
            if col not in cols:
                cols.append(col)
        return cols


def load_feature_list(
    csv_path: str,
    version: Optional[int] = None,
    filesystem=None,
) -> FeatureList:
    """Load and type-split the predictor CSV.

    Args:
        csv_path: Local path or S3 URI to the predictor CSV.
        version: If given, keep only rows with ``version <= version``.
        filesystem: Optional s3fs filesystem for reading an S3 path.
    """
    if filesystem is not None and (csv_path.startswith("s3://") or csv_path.startswith("s3a://")):
        with filesystem.open(strip_scheme(csv_path), "r") as f:
            df = pd.read_csv(f)
    else:
        df = pd.read_csv(csv_path)

    required = {"feature", "type", "source", "version"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Predictor CSV missing required columns: {sorted(missing)}")

    if version is not None:
        df = df[df["version"] <= version].reset_index(drop=True)

    df["type"] = df["type"].str.strip().str.lower()
    bad_types = set(df["type"]) - {CONTINUOUS, CATEGORICAL}
    if bad_types:
        raise ValueError(f"Unknown feature types in CSV: {sorted(bad_types)}")

    continuous = df.loc[df["type"] == CONTINUOUS, "feature"].tolist()
    categorical = df.loc[df["type"] == CATEGORICAL, "feature"].tolist()
    derived = df.loc[df["source"].str.startswith("derived:"), "feature"].tolist()

    order_col = None
    for src in df["source"]:
        if str(src).startswith("derived:"):
            order_col = str(src).split(":", 1)[1]
            break

    return FeatureList(
        continuous=continuous,
        categorical=categorical,
        derived=derived,
        order_col=order_col,
        frame=df,
    )
