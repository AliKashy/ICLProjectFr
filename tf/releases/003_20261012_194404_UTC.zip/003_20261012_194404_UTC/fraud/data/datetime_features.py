"""Derive datetime features from a timestamp column.

Parses the order/timestamp column (default ``transaction_dttm``) and produces
calendar features. Two encoding modes:

- ``categorical`` (default): integer-valued columns (month, day, hour,
  day_of_week, optional is_weekend) meant to be embedded as categories.
- ``cyclical``: sin/cos pairs for each periodic field, as continuous features.

The set of fields and the encoding mode are configurable so the behavior can be
driven from ``smoke_test.yaml``.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

# Period of each field, used for cyclical encoding.
_FIELD_PERIODS: Dict[str, int] = {
    "month": 12,
    "day": 31,
    "hour": 24,
    "day_of_week": 7,
}

DEFAULT_FIELDS = ["month", "day", "hour", "day_of_week"]


@dataclass
class DatetimeConfig:
    """Configuration for datetime feature derivation."""

    order_col: str = "transaction_dttm"
    fields: List[str] = field(default_factory=lambda: list(DEFAULT_FIELDS))
    encoding: str = "categorical"  # "categorical" | "cyclical"
    is_weekend: bool = False

    def __post_init__(self):
        if self.encoding not in ("categorical", "cyclical"):
            raise ValueError(f"Unknown datetime encoding: {self.encoding!r}")
        unknown = set(self.fields) - set(_FIELD_PERIODS)
        if unknown:
            raise ValueError(f"Unknown datetime fields: {sorted(unknown)}")


def _extract_field(dt: pd.Series, field_name: str) -> pd.Series:
    if field_name == "month":
        return dt.dt.month
    if field_name == "day":
        return dt.dt.day
    if field_name == "hour":
        return dt.dt.hour
    if field_name == "day_of_week":
        return dt.dt.dayofweek
    raise ValueError(f"Unknown datetime field: {field_name}")


def derive_datetime_features(
    df: pd.DataFrame, config: DatetimeConfig
) -> Tuple[pd.DataFrame, List[str], List[str]]:
    """Add datetime features to ``df``.

    Returns:
        (df, new_continuous, new_categorical) — the mutated frame and the names
        of features added to each type bucket.
    """
    df = df.copy()
    dt = pd.to_datetime(df[config.order_col], errors="coerce")

    new_continuous: List[str] = []
    new_categorical: List[str] = []

    for field_name in config.fields:
        values = _extract_field(dt, field_name)
        if config.encoding == "categorical":
            # -1 marks missing/unparseable timestamps; kept as its own category.
            df[field_name] = values.fillna(-1).astype(int)
            new_categorical.append(field_name)
        else:
            period = _FIELD_PERIODS[field_name]
            radians = 2.0 * np.pi * values.fillna(0).astype(float) / period
            sin_col, cos_col = f"{field_name}_sin", f"{field_name}_cos"
            df[sin_col] = np.sin(radians)
            df[cos_col] = np.cos(radians)
            new_continuous.extend([sin_col, cos_col])

    if config.is_weekend:
        weekend = (dt.dt.dayofweek >= 5)
        df["is_weekend"] = weekend.fillna(False).astype(int)
        new_categorical.append("is_weekend")

    return df, new_continuous, new_categorical
