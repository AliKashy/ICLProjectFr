"""Lightning callbacks shared across training scripts."""

import csv
import os

import pytorch_lightning as pl
import torch
from sklearn.metrics import average_precision_score, roc_auc_score


class CSVMetricsCallback(pl.Callback):
    """Append per-epoch training metrics to a CSV for terminal progress viewing.

    Writes one row per validation-epoch end with epoch, step, and every scalar in
    ``trainer.callback_metrics``. View it with ``fraud/scripts/show_progress.py``.
    """

    def __init__(self, path):
        self.path = path
        self.fieldnames = None
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)

    def on_validation_epoch_end(self, trainer, pl_module):
        if trainer.sanity_checking:
            return
        metrics = {}
        for k, v in trainer.callback_metrics.items():
            try:
                metrics[k] = round(float(v), 6)
            except (TypeError, ValueError):
                continue
        row = {"epoch": int(trainer.current_epoch),
               "step": int(trainer.global_step), **metrics}
        if self.fieldnames is None:
            self.fieldnames = list(row.keys())
            with open(self.path, "w", newline="") as f:
                csv.DictWriter(f, fieldnames=self.fieldnames).writeheader()
        with open(self.path, "a", newline="") as f:
            csv.DictWriter(f, fieldnames=self.fieldnames,
                           extrasaction="ignore").writerow(row)


class StreamingBinaryMetrics(pl.Callback):
    """Compute PR-AUC / ROC-AUC over the FULL validation stream each epoch.

    Per-batch ranking metrics are meaningless at low fraud prevalence (most
    batches have no positives). This callback accumulates the positive-class
    probability and target across every validation batch and computes the
    metrics once at epoch end, logging ``valid_ap`` / ``valid_auroc`` so they can
    drive early stopping / checkpointing.
    """

    def __init__(self, pos_index: int = 1):
        self.pos_index = pos_index
        self._scores = []
        self._targets = []

    def on_validation_epoch_start(self, trainer, pl_module):
        self._scores.clear()
        self._targets.clear()

    def on_validation_batch_end(self, trainer, pl_module, outputs, batch, batch_idx, dataloader_idx=0):
        if outputs is None:
            return
        y_hat, y = outputs
        prob = torch.softmax(y_hat, dim=-1)[:, self.pos_index]
        self._scores.append(prob.detach().float().cpu())
        self._targets.append(y.detach().reshape(-1).cpu())

    def on_validation_epoch_end(self, trainer, pl_module):
        if trainer.sanity_checking or not self._scores:
            return
        scores = torch.cat(self._scores).numpy()
        targets = torch.cat(self._targets).numpy()
        if targets.min() == targets.max():
            return  # no positives (or no negatives) -> metrics undefined

        pl_module.log("valid_ap", float(average_precision_score(targets, scores)), prog_bar=True)
        pl_module.log("valid_auroc", float(roc_auc_score(targets, scores)), prog_bar=True)
