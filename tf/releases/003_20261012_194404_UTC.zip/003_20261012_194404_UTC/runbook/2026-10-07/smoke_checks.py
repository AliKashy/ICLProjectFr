#!/usr/bin/env python3
# reviewer, 2026-10-11 (first release; reference's docs/phase4_sequential_plan.md section 9 item 1; FIRST_RELEASE_SCOPE
# v2.8 section 2, smoke row). Read-only on the attempt folders it inspects and on the data it reads; writes only into
# its own return folder. Exports counts, digests and metrics: never a transaction, an account or an error message.
"""Judge the two smoke cells and write one return folder.

    python runbook/2026-10-07/smoke_checks.py --out runs/returns/smoke_<time> \
        --cell phase4a ft_decisions_smoke.yaml <attempt folder or -> \
        --cell phase4b ft_decisions_hier_smoke.yaml <attempt folder or -> \
        [--preflight <pre-flight folder>] [--preflight-result PASS|FAIL|...] [--interpreter <path>]

smoke.sh calls this after the two cells ran (or stopped). The folder gets SMOKE_RETURN.txt and, per cell that has them,
<spec name>/training_metrics.csv and <spec name>/run_summary.txt (the trainer's per-epoch numbers and the runner's own
summary, both aggregates). SMOKE_RETURN.txt reports, per cell:
  - the validation loss per epoch (valid_loss, the mean over the whole validation file), and whether epoch 2 is below
    epoch 1 (PASS/FAIL); train_loss is the loss of the last training batch before each validation, shown for information;
  - valid_ap and valid_auroc at the saved checkpoint and per epoch; "sane" means finite, strictly inside (0, 1), and
    valid_ap above the positive rate of the validation file (from the pre-flight's data_contract.json when it holds
    that file, else counted from the validation file read for the window check; the line says which);
  - peak host RSS (from the ST13 samples host_rss_sweep.csv when present) and peak GPU memory (gpu_sweep.csv, the
    nvidia-smi samples); a missing record is UNKNOWN, never a number;
  - the causal-window spot check: 20 sampled validation targets (up to half of them rows that share their account and
    time with another row, the rows the strict rule is about; the line says how many) rebuilt with the owned builder of
    that architecture (its own encoding, grouping and windowing) under the configured history_time_order; every history
    row's time must be strictly before (strict) or at most equal to (tiebreak) the target's time, no history row may be
    the target itself, and all must belong to the target's account; counts only;
  - interpreter paths, the spec, base config and resolved config digests. Runtime: not measured.
It ends with one plain-words line per failed check and then RESULT: PASS or RESULT: FAIL (the last line). UNKNOWN items
are listed and do not fail the result. Exit 0 only for RESULT: PASS. The folder is written whenever smoke.sh reaches its
end, including when the pre-flight or a cell fails; if the run is interrupted, SMOKE_STATUS.txt shows the last step. A
cell without an attempt folder, without a results row or with a failed runner status is a FAIL with what exists
reported.
"""
import argparse
import csv
import hashlib
import importlib
import inspect
import json
import math
import os
import shutil
import sys
import time
import traceback

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

SAMPLES = 20
SEED = 20261011
LETTER = {"phase4a": "A", "phase4b": "B"}
RULES = ("strict", "tiebreak")


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def fnum(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return v if math.isfinite(v) else None


def f4(x):
    v = fnum(x)
    return f"{v:.4f}" if v is not None else ("not finite" if x not in (None, "") else "-")


# -- the trainer's per-epoch record --------------------------------------------------------------------------------
def read_metrics(run_dir):
    """Rows of training_metrics.csv sorted by epoch, or None when the file is absent."""
    p = os.path.join(run_dir, "training_metrics.csv")
    if not os.path.isfile(p):
        return None
    with open(p, newline="") as f:
        rows = list(csv.DictReader(f))
    return sorted(rows, key=lambda r: int(fnum(r.get("epoch")) or 0))


def loss_column(rows):
    cols = list(rows[0].keys()) if rows else []
    if "valid_loss" in cols:  # an epoch mean; train_loss is logged per step (the last batch before each validation)
        return "valid_loss"
    if "train_loss" in cols:
        return "train_loss"
    for c in cols:
        if c.startswith("train") and c.endswith("loss") and not c.endswith("_step"):
            return c
    return None


def loss_check(rows):
    """Validation loss per epoch (valid_loss when logged, else a training loss column) and whether epoch 2 is below
    epoch 1.
    Returns {"status", "column", "losses", "reason"}; losses are floats or None per recorded epoch."""
    if not rows:
        return {"status": "FAIL", "column": None, "losses": [], "reason": "no epoch was recorded (training_metrics.csv missing or empty)"}
    col = loss_column(rows)
    if col is None:
        return {"status": "FAIL", "column": None, "losses": [], "reason": "training_metrics.csv has no loss column"}
    losses = [fnum(r.get(col)) for r in rows]
    if len(losses) < 2:
        return {"status": "FAIL", "column": col, "losses": losses, "reason": "only one epoch was recorded; the check needs two"}
    if losses[0] is None or losses[1] is None:
        return {"status": "FAIL", "column": col, "losses": losses, "reason": f"the loss ({col}) of epoch 1 or 2 is not a finite number"}
    if not losses[1] < losses[0]:
        return {"status": "FAIL", "column": col, "losses": losses,
                "reason": f"the loss ({col}) did not fall: epoch 1 {losses[0]:.6f}, epoch 2 {losses[1]:.6f}"}
    return {"status": "PASS", "column": col, "losses": losses, "reason": ""}


def metric_sanity(ap, auroc, pos_rate):
    """'sane': finite, strictly inside (0, 1), and valid_ap above the validation file's positive rate.
    Returns (status, reasons); status is UNKNOWN only when the metrics are fine but no positive rate is known."""
    reasons = []
    for name, v in (("valid_ap", ap), ("valid_auroc", auroc)):
        x = fnum(v)
        if x is None:
            reasons.append(f"{name} is missing or not a finite number")
        elif not 0.0 < x < 1.0:
            reasons.append(f"{name} {x:.6f} is not strictly between 0 and 1")
    if reasons:
        return "FAIL", reasons
    if pos_rate is None:
        return "UNKNOWN", ["the positive rate of the validation file is unknown, so valid_ap could not be compared with it"]
    if not fnum(ap) > pos_rate:
        return "FAIL", [f"valid_ap {fnum(ap):.6f} is not above the validation file's positive rate {pos_rate:.6f}"]
    return "PASS", []


# -- memory records (ST13 samples and the GPU sampler; read, never recomputed) ---------------------------------------
def host_peak(attempt_dir):
    """(peak MiB or None, sample count, source) from the ST13 host samples copied into the attempt folder."""
    p = os.path.join(attempt_dir, "host_rss_sweep.csv")
    if not os.path.isfile(p):
        return None, 0, "no host memory record in the attempt folder (host_rss_sweep.csv absent)"
    peak, n = None, 0
    with open(p, newline="") as f:
        for r in csv.DictReader(f):
            v = fnum(r.get("rss_mib_process_tree"))
            if v is not None:
                n += 1
                peak = max(peak or 0.0, v)
    if peak is None:
        return None, 0, "host_rss_sweep.csv holds no sample"
    return peak, n, f"ST13 host samples host_rss_sweep.csv ({n} sample(s), runner process tree)"


def gpu_peak(attempt_dir):
    """(peak MiB or None, sample count, source) from the nvidia-smi samples copied into the attempt folder."""
    p = os.path.join(attempt_dir, "gpu_sweep.csv")
    if not os.path.isfile(p):
        return None, 0, "no GPU memory record in the attempt folder (gpu_sweep.csv absent: no nvidia-smi samples)"
    peak, n = None, 0
    with open(p, errors="replace") as f:
        for line in f:
            parts = [x.strip() for x in line.split(",")]
            if len(parts) >= 2 and parts[1].endswith("MiB"):
                v = fnum(parts[1][:-3])
                if v is not None:
                    n += 1
                    peak = max(peak or 0.0, v)
    if peak is None:
        return None, 0, "gpu_sweep.csv holds no sample"
    return peak, n, (f"gpu_sweep.csv, nvidia-smi: {n} readings over all GPUs (one line per GPU every 30 s); "
                     "the largest memory.used of any one GPU, other processes included")


# -- positive rate of the validation file ---------------------------------------------------------------------------
def positive_rate_from_preflight(preflight_dir, cfg):
    """(rate, source) from the pre-flight's data_contract.json when its validation split lists the cell's file(s)."""
    if not preflight_dir:
        return None, None
    p = os.path.join(preflight_dir, "data_contract.json")
    try:
        with open(p) as f:
            contract = json.load(f)
    except Exception:
        return None, None
    wanted = {f"part_{i}.parquet" for i in range(int(cfg.data.val_start), int(cfg.data.val_end) + 1)}
    for split, v in contract.items():
        if not (split.startswith("valid_") and isinstance(v, dict)):
            continue
        hits = [x for x in v.get("files", []) if x.get("file") in wanted]
        if {x["file"] for x in hits} == wanted:
            rows = sum(int(x["rows"]) for x in hits)
            pos = sum(int(x["positives"]) for x in hits)
            if rows > 0:
                return pos / rows, (f"pre-flight {os.path.basename(os.path.normpath(preflight_dir))} data_contract.json, "
                                    f"split {split}, {', '.join(sorted(wanted))}: {pos:,} positives in {rows:,} rows")
    return None, None


# -- the causal-window spot check -----------------------------------------------------------------------------------
def effective_rule(cfg, builder_cls):
    """(rule, how it was determined, problem or None). The configured sequence.history_time_order when the builder
    takes that option (else the option's default); a builder without the option uses the tie-break order and can only
    honour 'tiebreak'."""
    configured = cfg.sequence.get("history_time_order", None)
    params = inspect.signature(builder_cls.__init__).parameters
    if "history_time_order" in params:
        if configured is not None:
            return str(configured), "configured sequence.history_time_order", None
        default = params["history_time_order"].default
        return str(default), "the builder's default (sequence.history_time_order not set)", None
    if configured is not None and str(configured) != "tiebreak":
        return str(configured), "configured sequence.history_time_order", (
            f"the configured rule {configured} is not implemented by the builder in this folder (it has no "
            "history_time_order option and uses the tie-break order)")
    return "tiebreak", "the builder in this folder has no history_time_order option (tie-break order)", None


def load_builder(cfg, phase, fs):
    """The owned builder of the architecture, built as its trainer builds the validation loader (no shuffle,
    eval stride), with the files it will read. Returns (builder, rule, rule source, problem or None)."""
    from fraud.data.datetime_features import DatetimeConfig
    from fraud.data.feature_list import load_feature_list
    from fraud.data.preprocessing import PreprocessingArtifacts
    from fraud.data.s3_utils import build_file_list
    module = importlib.import_module(f"YOUR_PACKAGE.{phase}.sequence_builder")
    builder_cls = module.SequenceBuilder
    features = load_feature_list(cfg.predictors.csv_path, version=cfg.predictors.version, filesystem=fs)
    artifacts = PreprocessingArtifacts.load(f"{cfg.artifacts.base.rstrip('/')}/{cfg.artifacts.version}", filesystem=fs)
    dt_config = DatetimeConfig(order_col=cfg.data.order_col, fields=list(cfg.datetime.fields),
                               encoding=cfg.datetime.encoding, is_weekend=cfg.datetime.is_weekend)
    files = build_file_list(cfg.data.val_base, cfg.data.val_start, cfg.data.val_end)
    rule, source, problem = effective_rule(cfg, builder_cls)
    kwargs = dict(
        file_list=files, artifacts=artifacts, features=features, datetime_config=dt_config,
        target_col=cfg.data.target_col, account_col=cfg.data.account_col, order_col=cfg.data.order_col,
        history_len=int(cfg.sequence.history_len), stride=int(cfg.sequence.get("eval_stride", 1)),
        positive_label=cfg.data.get("positive_label", 1), add_missing_flag=cfg.preprocess.add_missing_flag,
        time_delta=bool(cfg.sequence.get("time_delta", True)), batch_size=int(cfg.training.batch_size),
        shuffle=False, buffer_windows=int(cfg.training.get("buffer_windows", 65536)),
        tie_break_col=cfg.data.get("tie_break_col", None), s3_filesystem=fs,
    )
    if "history_time_order" in inspect.signature(builder_cls.__init__).parameters and problem is None:
        kwargs["history_time_order"] = rule
    return builder_cls(**kwargs), rule, source, problem


def rebuild_windows(builder, df, positions):
    """Windows of the sampled targets (row positions in df), built by the builder's own encoding, account grouping and
    windowing. Only the accounts of the sampled targets are passed in: a window depends only on its account's rows of
    the same file. The categorical codes are replaced by the row position so every slot names its row.
    Returns (windows {target position: [history positions]}, times_ns, accounts, positions not windowed)."""
    import numpy as np
    acct = builder.account_col
    accounts = set(df[acct].iloc[list(positions)].tolist())
    keep = df[acct].isin(accounts).to_numpy()
    sub = df[keep].reset_index(drop=True)
    orig = np.flatnonzero(keep)
    cont, cat, target, times, sub, meta = builder._encode_file(sub)
    index_as_codes = np.arange(len(sub), dtype=np.int64).reshape(-1, 1)
    wanted = {int(np.searchsorted(orig, p)) for p in positions}
    windows = {}
    for w in builder._windows_for_file(cont, index_as_codes, target, times, sub, meta):
        w_cat, w_mask = w[1], w[2]
        if not w_mask[-1]:
            continue
        t = int(w_cat[-1, 0])
        if t in wanted:
            windows[int(orig[t])] = [int(orig[int(w_cat[s, 0])]) for s in range(len(w_mask) - 1) if w_mask[s]]
    times_ns = {int(orig[i]): int(v) for i, v in
                enumerate(sub[builder.order_col].to_numpy(dtype="datetime64[ns]").astype("int64"))}
    accts = {int(orig[i]): v for i, v in enumerate(sub[acct].to_numpy())}
    missing = sorted(set(int(p) for p in positions) - set(windows))
    return windows, times_ns, accts, missing


def judge_windows(windows, times_ns, accts, rule):
    """Counts over rebuilt windows under the rule: history rows whose time is not before the target's (strict) or
    after it (tiebreak), history rows that are the target itself, history rows of another account."""
    if rule not in RULES:
        raise ValueError(f"unknown history rule {rule!r}")
    c = {"windows": len(windows), "history_rows": 0, "time_violations": 0, "target_in_history": 0, "other_account": 0}
    for t, hist in windows.items():
        for r in hist:
            c["history_rows"] += 1
            if r == t:
                c["target_in_history"] += 1
            if accts[r] != accts[t]:
                c["other_account"] += 1
            ok = times_ns[r] < times_ns[t] if rule == "strict" else times_ns[r] <= times_ns[t]
            if not ok:
                c["time_violations"] += 1
    c["status"] = "PASS" if (c["windows"] > 0 and not (c["time_violations"] or c["target_in_history"] or c["other_account"])) else "FAIL"
    return c


def window_check(cfg, phase, samples=SAMPLES, seed=SEED):
    """Read the cell's validation file(s) as the builder does, sample targets, rebuild their windows with the owned
    builder and judge them. Returns counts and the file's rows and positives (for the positive rate)."""
    import numpy as np
    import pyarrow.parquet as pq
    import fraud.data.s3_utils as s3_utils
    from YOUR_PACKAGE.base.data.input_contracts import encode_binary_target
    fs = s3_utils.make_s3_filesystem(cfg.s3.cred_path)
    builder, rule, rule_source, problem = load_builder(cfg, phase, fs)
    out = {"rule": rule, "rule_source": rule_source, "requested": samples, "seed": seed, "files": len(builder.file_list),
           "rows": 0, "positives": 0, "sampled": 0, "not_windowed": 0, "tied_rows": 0, "tied_sampled": 0,
           "windows": 0, "history_rows": 0, "time_violations": 0, "target_in_history": 0, "other_account": 0}
    if problem:
        out.update(status="FAIL", reason=problem)
        return out
    per_file = max(1, -(-samples // len(builder.file_list)))
    rng = np.random.default_rng(seed)
    for path in builder.file_list:
        df = pq.ParquetDataset(s3_utils.strip_scheme(path) if fs is not None else path,
                               filesystem=fs).read(columns=builder._read_cols).to_pandas()
        out["rows"] += len(df)
        out["positives"] += int(encode_binary_target(df[builder.target_col], builder.positive_label,
                                                     builder.target_col).sum())
        n = min(per_file, len(df))
        # Up to half the targets from the same-account equal-time rows (about 2% of rows in run-001), so the strict
        # rule (RUN-02) is always exercised; the rest uniformly from the other rows.
        tied = np.flatnonzero(df.duplicated([builder.account_col, builder.order_col], keep=False).to_numpy())
        k = min(len(tied), n // 2)
        pick = list(rng.choice(tied, size=k, replace=False)) if k else []
        rest = np.setdiff1d(np.arange(len(df)), pick)
        pick += list(rng.choice(rest, size=n - k, replace=False)) if n - k else []
        positions = sorted(int(p) for p in pick)
        out["tied_rows"] += len(tied)
        out["tied_sampled"] += k
        out["sampled"] += len(positions)
        if not positions:
            continue
        windows, times_ns, accts, missing = rebuild_windows(builder, df, positions)
        out["not_windowed"] += len(missing)
        counts = judge_windows(windows, times_ns, accts, rule)
        for k in ("windows", "history_rows", "time_violations", "target_in_history", "other_account"):
            out[k] += counts[k]
    bad = out["time_violations"] or out["target_in_history"] or out["other_account"]
    if out["windows"] == 0:
        out.update(status="FAIL", reason="no sampled target could be rebuilt into a window")
    elif bad:
        out.update(status="FAIL", reason=(f"{out['time_violations']} history row(s) not {'strictly before' if rule == 'strict' else 'at or before'} "
                                         f"the target's time, {out['target_in_history']} history row(s) equal to the target, "
                                         f"{out['other_account']} from another account"))
    else:
        out.update(status="PASS", reason="")
    return out


# -- one cell -------------------------------------------------------------------------------------------------------
def results_row(attempt_dir):
    p = os.path.join(attempt_dir, "results.csv")
    if not os.path.isfile(p):
        return None, []
    with open(p, newline="") as f:
        rows = list(csv.DictReader(f))
    return (rows[0] if len(rows) == 1 else None), rows


def check_cell(phase, spec, attempt_dir, args, checks):
    """Lines for the cell; appends (status, text) entries to checks."""
    from omegaconf import OmegaConf
    tag = f"cell {LETTER.get(phase, phase)} ({phase}/{spec})"
    stem = os.path.splitext(spec)[0]
    lines = [f"== {tag}"]

    def check(status, text):
        checks.append((status, f"{tag}: {text}"))
        return status

    spec_path = os.path.join(ROOT, "YOUR_PACKAGE", phase, "configs", spec)
    if os.path.isfile(spec_path):
        lines.append(f"spec sha256: {sha256(spec_path)} ({os.path.relpath(spec_path, ROOT)})")
        try:
            base_rel = str(OmegaConf.load(spec_path).base_config)
            lines.append(f"base config sha256: {sha256(os.path.join(ROOT, base_rel))} ({base_rel})")
        except Exception as exc:
            lines.append(f"base config sha256: unreadable ({type(exc).__name__})")
    else:
        lines.append(f"spec sha256: the spec file {os.path.relpath(spec_path, ROOT)} is missing")
        check("FAIL", "the spec file is missing from this folder")
    lines.append("runtime: not measured")

    if not attempt_dir or attempt_dir == "-" or not os.path.isdir(attempt_dir):
        lines.append("attempt: none (the runner created no attempt folder; nothing to read)")
        check("FAIL", "no attempt folder was created: the runner stopped before training")
        return lines
    lines.append(f"attempt: {os.path.basename(os.path.normpath(attempt_dir))}")
    att_spec = os.path.join(attempt_dir, "ablation_spec.yaml")
    if os.path.isfile(att_spec):
        lines.append(f"attempt spec sha256: {sha256(att_spec)} (ablation_spec.yaml as the runner saved it)")
    row, rows = results_row(attempt_dir)
    run_dirs = sorted(d for d in os.listdir(attempt_dir)
                      if os.path.isfile(os.path.join(attempt_dir, d, "resolved_train.yaml")))
    if row is None:
        if not rows:
            lines.append("results row: none (results.csv missing or empty: the run did not finish)")
            check("FAIL", "the run has no results row (training did not finish)")
        else:
            lines.append(f"results rows: {len(rows)} (a smoke spec has one cell; the attempt is not usable)")
            check("FAIL", f"results.csv has {len(rows)} rows for a one-cell spec")
        run_name = run_dirs[0] if len(run_dirs) == 1 else None
    else:
        run_name = row.get("run_name")
        status = (row.get("status") or "").strip() or "unknown"
        lines.append(f"run: {run_name}; runner status: {status}; train exit code: {row.get('train_rc', '-')}")
        if status != "ok":
            check("FAIL", f"the runner reported status {status} (train exit code {row.get('train_rc', '-')})")
    run_dir = os.path.join(attempt_dir, run_name) if run_name else None
    cfg = None
    if run_dir and os.path.isfile(os.path.join(run_dir, "resolved_train.yaml")):
        lines.append(f"resolved config sha256: {sha256(os.path.join(run_dir, 'resolved_train.yaml'))} (resolved_train.yaml)")
        try:
            cfg = OmegaConf.load(os.path.join(run_dir, "resolved_train.yaml"))
        except Exception as exc:
            lines.append(f"resolved config: unreadable ({type(exc).__name__})")
    if cfg is not None:
        lines.append(f"settings: train files {cfg.data.train_start}-{cfg.data.train_end}, validation files "
                     f"{cfg.data.val_start}-{cfg.data.val_end}, history {cfg.sequence.history_len}, epochs "
                     f"{cfg.training.max_epochs}, batch {cfg.training.batch_size}, mask {cfg.sequence.attention_mask}, "
                     f"time gap {cfg.sequence.get('time_delta', True)}, history_time_order "
                     f"{cfg.sequence.get('history_time_order', 'not set')}")

    # Per-epoch record and the loss check.
    metrics = read_metrics(run_dir) if run_dir else None
    lc = loss_check(metrics or [])
    if metrics:
        lines.append(f"epochs recorded: {len(metrics)} (training_metrics.csv; the trainer counts epochs from 0)")
        label = ("validation loss per epoch (valid_loss, the mean over the whole validation file)"
                 if lc["column"] == "valid_loss" else f"training loss per epoch ({lc['column'] or 'no loss column'}, as logged)")
        lines.append(label + ": " + ", ".join(f"epoch {i + 1} {f4(v)}" for i, v in enumerate(lc["losses"])))
        if lc["column"] == "valid_loss" and "train_loss" in metrics[0]:
            lines.append("training loss of the last batch before each validation (train_loss, one batch, for information): "
                         + ", ".join(f"epoch {i + 1} {f4(r.get('train_loss'))}" for i, r in enumerate(metrics)))
        lines.append("valid_ap per epoch: " + ", ".join(f"epoch {i + 1} {f4(r.get('valid_ap'))}" for i, r in enumerate(metrics)))
        lines.append("valid_auroc per epoch: " + ", ".join(f"epoch {i + 1} {f4(r.get('valid_auroc'))}" for i, r in enumerate(metrics)))
    else:
        lines.append("epochs recorded: none (training_metrics.csv missing)")
    lines.append(f"loss falls from epoch 1 to epoch 2: {'yes' if lc['status'] == 'PASS' else 'no'} -> {lc['status']}")
    check(lc["status"], lc["reason"] or f"the loss ({lc['column']}) falls from epoch 1 to epoch 2")

    # Window check first: it also counts the validation file (the fallback positive rate).
    wc = None
    if cfg is not None:
        try:
            wc = args.window_check(cfg, phase, args.samples, args.seed)
        except Exception as exc:
            traceback.print_exc(file=sys.stderr)
            wc = {"status": "FAIL", "reason": f"the window check could not run ({type(exc).__name__}; details in the console only)",
                  "rule": str(cfg.sequence.get("history_time_order", "not set")), "rule_source": "configured or not set",
                  "requested": args.samples, "sampled": 0, "windows": 0, "history_rows": 0, "time_violations": 0,
                  "target_in_history": 0, "other_account": 0, "not_windowed": 0, "rows": 0, "positives": 0, "seed": args.seed, "files": 0,
                  "tied_rows": 0, "tied_sampled": 0}
    else:
        wc = {"status": "FAIL", "reason": "no resolved configuration to rebuild windows from", "rule": "-",
              "rule_source": "-", "requested": args.samples, "sampled": 0, "windows": 0, "history_rows": 0,
              "time_violations": 0, "target_in_history": 0, "other_account": 0, "not_windowed": 0, "rows": 0,
              "positives": 0, "seed": args.seed, "files": 0, "tied_rows": 0, "tied_sampled": 0}

    # Checkpoint-paired validation metrics and their sanity.
    ap = row.get("best_valid_ap") if row else None
    auroc = row.get("best_valid_auroc") if row else None
    rate, rate_source = positive_rate_from_preflight(args.preflight, cfg) if cfg is not None else (None, None)
    if rate is None and wc.get("rows"):
        rate = wc["positives"] / wc["rows"]
        rate_source = (f"counted from the validation file(s) read for the window check: {wc['positives']:,} positives in "
                       f"{wc['rows']:,} rows")
    lines.append(f"checkpoint (epoch {row.get('checkpoint_epoch', '-') if row else '-'}, the trainer's count): "
                 f"valid_ap {f4(ap)}, valid_auroc {f4(auroc)}")
    lines.append(f"positive rate of the validation file: {f'{rate:.6f}' if rate is not None else 'unknown'}"
                 + (f" (source: {rate_source})" if rate_source else " (not in the pre-flight folder and the file could not be counted)"))
    ms, reasons = metric_sanity(ap, auroc, rate)
    lines.append(f"valid_ap and valid_auroc sane (finite, inside (0, 1), valid_ap above the positive rate): {ms}")
    check(ms, "; ".join(reasons) if reasons else "valid_ap and valid_auroc are sane")

    # Memory.
    hp, hn, hsrc = host_peak(attempt_dir)
    gp, gn, gsrc = gpu_peak(attempt_dir)
    lines.append(f"peak host RSS: {f'{hp:,.0f} MiB' if hp is not None else 'unknown'} (source: {hsrc})")
    lines.append(f"peak GPU memory: {f'{gp:,.0f} MiB' if gp is not None else 'unknown'} (source: {gsrc})")
    if hp is None:
        check("UNKNOWN", f"peak host RSS unknown: {hsrc}")
    elif hn < 2:  # a cell that ends inside one sampling interval leaves only the launch sample
        check("UNKNOWN", f"peak host RSS unknown: only the launch sample ({hp:,.0f} MiB) was recorded")
    else:
        check("PASS", f"peak host RSS {hp:,.0f} MiB recorded")
    check("PASS" if gp is not None else "UNKNOWN", f"peak GPU memory {gp:,.0f} MiB recorded" if gp is not None else f"peak GPU memory unknown: {gsrc}")

    # Causal windows.
    lines.append(f"causal windows: rule {wc['rule']} ({wc['rule_source']}); {wc['sampled']} of {wc['requested']} targets sampled "
                 f"(seed {wc['seed']}, {wc['files']} validation file(s)); {wc['tied_sampled']} of them share their account and time "
                 f"with another row (the file has {wc['tied_rows']:,} such rows); {wc['windows']} window(s) rebuilt, {wc['not_windowed']} target(s) "
                 f"without a window; {wc['history_rows']} history row(s) checked; time violations {wc['time_violations']}; "
                 f"target in its own history {wc['target_in_history']}; other account {wc['other_account']} -> {wc['status']}")
    check(wc["status"], wc.get("reason") or f"causal windows correct under rule {wc['rule']} ({wc['windows']} windows, {wc['history_rows']} history rows)")

    # Copies of the aggregate files.
    if run_dir:
        dest = os.path.join(args.out, stem)
        copied = []
        for name in ("training_metrics.csv", "run_summary.txt"):
            src = os.path.join(run_dir, name)
            if os.path.isfile(src):
                os.makedirs(dest, exist_ok=True)
                shutil.copyfile(src, os.path.join(dest, name))
                copied.append(name)
        lines.append(f"copied into {stem}/: {', '.join(copied) if copied else 'nothing (files absent)'}")
    return lines


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True, help="the smoke return folder (created if needed)")
    ap.add_argument("--cell", nargs=3, action="append", metavar=("PHASE", "SPEC", "ATTEMPT_DIR"), default=[],
                    help="a cell: phase4a|phase4b, the spec file name, its attempt folder or - when none was created")
    ap.add_argument("--preflight", default=None, help="the pre-flight folder of this smoke (positive rate source)")
    ap.add_argument("--preflight-result", default="not stated", help="what smoke.sh read: PASS, FAIL, exit N, not run")
    ap.add_argument("--interpreter", default=None, help="the interpreter smoke.sh used for the pre-flight and the runner")
    ap.add_argument("--samples", type=int, default=SAMPLES)
    ap.add_argument("--seed", type=int, default=SEED)
    args = ap.parse_args(argv)
    args.window_check = window_check
    stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    os.makedirs(args.out, exist_ok=True)
    checks = []
    lines = [f"SMOKE RETURN {stamp} | runbook/2026-10-07/smoke_checks.py | {len(args.cell)} cell(s) | counts, digests and metrics only",
             "reference's section 9 item 1: loss decreases, valid_ap and valid_auroc sane, RSS bounded, causal windows correct",
             f"pre-flight: {os.path.basename(os.path.normpath(args.preflight)) if args.preflight else 'none'}; result read by smoke.sh: {args.preflight_result}",
             f"interpreter (smoke.sh): {args.interpreter or 'not stated'}; interpreter (this script): {sys.executable}",
             "runtime: not measured"]
    if args.preflight_result != "PASS":
        checks.append(("FAIL", f"the pre-flight did not pass (result {args.preflight_result}); nothing was trained"))
    if not args.cell:
        checks.append(("FAIL", "no cell was given: nothing was trained or checked"))
    for phase, spec, attempt in args.cell:
        lines.append("")
        lines += check_cell(phase, spec, attempt, args, checks)
    lines += ["", "== checks"]
    lines += [f"{status:<7} {text}" for status, text in checks]
    failed = [t for s, t in checks if s == "FAIL"]
    unknown = [t for s, t in checks if s == "UNKNOWN"]
    lines.append("")
    lines.append(f"{len(checks)} check(s): {sum(s == 'PASS' for s, _ in checks)} PASS, {len(failed)} FAIL, {len(unknown)} UNKNOWN"
                 + (" (unknown items are recorded, not judged)" if unknown else ""))
    for t in failed:
        lines.append(f"FAILED: {t}")
    lines.append(f"RESULT: {'FAIL' if failed else 'PASS'}")
    text = "\n".join(lines) + "\n"
    with open(os.path.join(args.out, "SMOKE_RETURN.txt"), "w") as f:
        f.write(text)
    print(text, end="")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
