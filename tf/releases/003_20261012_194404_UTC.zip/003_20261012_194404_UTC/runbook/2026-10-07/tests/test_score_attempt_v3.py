# reviewer, 2026-10-07. Regression tests for score_attempt.py v3 and synthetic/positive_control.sh v2, built from review's
# counterexamples (bridge/reviews/review/2026-10-07-PR3-a987168/: latest_delta_review.md D1-D3, README.md positive-control
# false success). The scorer child and the training commands are mocked; synthetic only, runs in seconds.
#     python3 -m pytest -q runbook/2026-10-07/tests
import csv
import hashlib
import importlib.util
import json
import math
import os
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest
from omegaconf import OmegaConf

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[1]
V2, V3 = "tf-runbook-ledger-v2", "tf-runbook-ledger-v3"


def load(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return m


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@pytest.fixture
def sa(monkeypatch):
    """A fresh score_attempt module whose child environment probe is stubbed."""
    m = load(f"score_attempt_{os.urandom(4).hex()}", HERE / "score_attempt.py")
    monkeypatch.setattr(m, "child_env", lambda: {})
    return m


FROZEN = """eval:
  base: s3://bucket/eval
  file_start: 8000
  file_end: 8010
  checkpoint: checkpoints/sequential/best.ckpt
  predictions_base: s3://bucket/predictions
  compute_metrics: true
experiment:
  run_name: original
"""


def make_attempt(tmp, runs=("seed-s1__history-h0",), name="20261007T000000Z-abc", manifest_sha=None):
    att = tmp / "ablations" / "ft_decisions_h0_seeds" / name
    att.mkdir(parents=True)
    OmegaConf.save(OmegaConf.create({"base_config": "YOUR_PACKAGE/phase4a/configs/sequential.yaml", "run_score": False}),
                   att / "ablation_spec.yaml")
    rows = []
    for i, run in enumerate(runs):
        d = att / run
        d.mkdir()
        (d / "best.ckpt").write_bytes(f"checkpoint {run}".encode())
        (d / "resolved_train.yaml").write_text(FROZEN)
        ck_sha, cfg_sha = sha(d / "best.ckpt"), sha(d / "resolved_train.yaml")
        (d / "run_manifest.json").write_text(json.dumps({
            "schema_version": 1, "resolved_train_sha256": manifest_sha or cfg_sha,
            "result": {"status": "ok", "checkpoint_sha256": ck_sha}}))
        rows.append({"run_name": run, "status": "ok", "best_valid_ap": 0.4 + i / 100, "checkpoint_sha256": ck_sha,
                     "resolved_train_sha256": cfg_sha, "source_sha256": "TRAINING_SOURCE"})
    with open(att / "results.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    return att


class Child:
    """Stands in for score_sequential.py: reads --config plus dotlist overrides exactly like the real scorer."""

    def __init__(self, edit=None, rc=0):
        self.edit, self.rc, self.calls = edit, rc, []

    def __call__(self, cmd, **kwargs):
        i = cmd.index("--config")
        cfg = OmegaConf.merge(OmegaConf.load(cmd[i + 1]), OmegaConf.from_dotlist(cmd[i + 2:]))
        self.calls.append({"cmd": cmd, "config_file": cmd[i + 1], "config": OmegaConf.to_container(cfg)})
        ck = str(cfg.eval.checkpoint)
        payload = {"schema_version": 1, "checkpoint_path": os.path.abspath(ck), "checkpoint_sha256": sha(ck),
                   "predictions_path": "bucket/predictions/x_preds.parquet", "n_predictions": 100,
                   "n_positives": 7, "average_precision": 0.31, "auroc": 0.82}
        if self.edit:
            payload = self.edit(payload, ck)
        if payload is not None:
            Path(str(cfg.eval.metrics_output)).write_text(json.dumps(payload))
        return SimpleNamespace(returncode=self.rc)


def run(sa, monkeypatch, capsys, argv, child):
    monkeypatch.setattr(sa.subprocess, "run", child)
    with pytest.raises(SystemExit) as e:
        sa.main([str(a) for a in argv])
    return e.value.code, capsys.readouterr().out


def post_dirs(run_dir):
    p = Path(run_dir) / "post_score"
    return sorted(p.iterdir()) if p.is_dir() else []


def snapshot(folder):
    return {p.name: p.read_bytes() for p in Path(folder).iterdir()}


# ---------------------------------------------------------------- D1-D3 reviewer cases (mocked child)

def test_valid_control_scores_once_with_full_provenance(sa, monkeypatch, capsys, tmp_path):
    att = make_attempt(tmp_path)
    run_dir = att / "seed-s1__history-h0"
    child = Child()
    rc, out = run(sa, monkeypatch, capsys, [att], child)
    assert rc == 0 and len(child.calls) == 1 and " ok " in out
    [folder] = post_dirs(run_dir)
    man = json.loads((folder / "post_score_manifest.json").read_text())
    ck = str(run_dir / "best.ckpt")
    assert man["status"] == "ok" and man["returncode"] == 0
    assert man["checkpoint_path"] == ck and man["checkpoint_sha256"] == sha(ck)
    assert man["resolved_train_sha256_recorded"] == man["resolved_train_sha256_recomputed"] \
        == man["resolved_train_sha256_run_manifest"] == sha(run_dir / "resolved_train.yaml")
    assert man["command"] == child.calls[0]["cmd"] and man["started_utc"] and man["finished_utc"]
    assert set(man["environment"]["packages"]) >= {"torch", "pandas", "omegaconf"} and man["environment"]["python"]
    assert len(man["source_before"]["source_sha256"]) == 64 and "convention" in man["source_before"]
    assert man["source_matches_training_run"] is False  # recorded and flagged, not silently inherited
    assert man["eval_range"] == {"base": "s3://bucket/eval", "file_start": 8000, "file_end": 8010,
                                 "source": "frozen_config"} and man["eval_range_override"] is None
    # The effective config the child received is the saved one, and it differs from the frozen one only by overrides.
    assert child.calls[0]["config_file"] == str(folder / "resolved_score.yaml")
    eff = OmegaConf.to_container(OmegaConf.load(folder / "resolved_score.yaml"))
    assert eff == child.calls[0]["config"] and man["resolved_score_sha256"] == sha(folder / "resolved_score.yaml")
    assert eff["eval"]["checkpoint"] == ck and eff["eval"]["metrics_output"] == str(folder / "post_score_metrics.json")
    assert (eff["eval"]["file_start"], eff["eval"]["file_end"]) == (8000, 8010)
    assert man["metrics"]["average_precision"] == 0.31 and man["metrics_sha256"] == sha(folder / "post_score_metrics.json")
    assert not (run_dir / "post_score_metrics.json").exists()  # nothing at the old fixed path


def test_invalid_then_retry_stays_nonzero_and_keeps_both_attempts(sa, monkeypatch, capsys, tmp_path):
    att = make_attempt(tmp_path)
    child = Child(edit=lambda p, ck: {**p, "average_precision": float("nan")})
    rc1, out1 = run(sa, monkeypatch, capsys, [att], child)
    [first] = post_dirs(att / "seed-s1__history-h0")
    before = snapshot(first)
    rc2, out2 = run(sa, monkeypatch, capsys, [att], child)
    assert (rc1, rc2) == (1, 1) and len(child.calls) == 2
    assert "invalid_output" in out1 and "invalid_output" in out2 and "skipped" not in out2
    assert f"prior_invalid post_score/{first.name}" in out2
    assert len(post_dirs(att / "seed-s1__history-h0")) == 2 and snapshot(first) == before


@pytest.mark.parametrize("where", ["config_file", "run_manifest", "manifest_missing", "config_missing"])
def test_changed_frozen_config_is_reported_and_child_not_launched(sa, monkeypatch, capsys, tmp_path, where):
    att = make_attempt(tmp_path, manifest_sha="0" * 64 if where == "run_manifest" else None)
    run_dir = att / "seed-s1__history-h0"
    if where == "config_file":  # review's counterexample: same keys, evaluation cohort 1-1 instead of 8000-8010
        (run_dir / "resolved_train.yaml").write_text(FROZEN.replace("8000", "1").replace("8010", "1"))
    elif where == "manifest_missing":
        (run_dir / "run_manifest.json").unlink()
    elif where == "config_missing":
        (run_dir / "resolved_train.yaml").unlink()
    child = Child()
    rc, out = run(sa, monkeypatch, capsys, [att], child)
    assert rc == 1 and "config_changed" in out and child.calls == [] and post_dirs(run_dir) == []


@pytest.mark.parametrize("drop", [("schema_version",), ("checkpoint_path",), ("predictions_path",),
                                  ("schema_version", "checkpoint_path", "predictions_path")])
def test_missing_schema_or_identity_fields_rejected(sa, monkeypatch, capsys, tmp_path, drop):
    att = make_attempt(tmp_path)
    child = Child(edit=lambda p, ck: {k: v for k, v in p.items() if k not in drop})
    rc, out = run(sa, monkeypatch, capsys, [att], child)
    assert rc == 1 and "invalid_output" in out and len(child.calls) == 1


@pytest.mark.parametrize("change", [{"average_precision": True}, {"auroc": False}, {"n_positives": True},
                                    {"average_precision": True, "auroc": False, "n_positives": True,
                                     "n_predictions": 2}])
def test_boolean_metrics_rejected(sa, monkeypatch, capsys, tmp_path, change):
    att = make_attempt(tmp_path)
    rc, out = run(sa, monkeypatch, capsys, [att], Child(edit=lambda p, ck: {**p, **change}))
    assert rc == 1 and "invalid_output" in out


@pytest.mark.parametrize("change", [
    {"checkpoint_path": "best.ckpt"}, {"checkpoint_sha256": "0" * 64}, {"schema_version": 2},
    {"schema_version": 1.0}, {"n_positives": 0}, {"n_positives": 100}, {"n_predictions": 0},
    {"n_predictions": 100.0}, {"predictions_path": "  "}, {"auroc": 1.5}, {"average_precision": float("inf")},
    {"average_precision": None}])
def test_other_contract_violations_rejected(sa, monkeypatch, capsys, tmp_path, change):
    att = make_attempt(tmp_path)
    rc, out = run(sa, monkeypatch, capsys, [att], Child(edit=lambda p, ck: {**p, **change}))
    assert rc == 1 and "invalid_output" in out


def test_checkpoint_changed_during_scoring_rejected(sa, monkeypatch, capsys, tmp_path):
    def edit(payload, ck):
        Path(ck).write_bytes(b"overwritten while scoring")  # reported hash is the old one
        return payload
    att = make_attempt(tmp_path)
    rc, out = run(sa, monkeypatch, capsys, [att], Child(edit=edit))
    assert rc == 1 and "invalid_output" in out and "checkpoint hash" in out


def test_child_failure_and_missing_output_are_failures(sa, monkeypatch, capsys, tmp_path):
    att = make_attempt(tmp_path, runs=("a", "b"))
    calls = []

    def child(cmd, **kwargs):
        calls.append(cmd)
        if "experiment.run_name=" in " ".join(cmd) and "__a__post" in " ".join(cmd):
            return SimpleNamespace(returncode=3)
        return SimpleNamespace(returncode=0)  # b: exit 0 but no metrics file
    rc, out = run(sa, monkeypatch, capsys, [att], child)
    assert rc == 1 and "score_failed" in out and "invalid_output" in out and len(calls) == 2


# ---------------------------------------------------------------- isolation and prior attempts (D1)

def test_two_scorings_make_two_folders_and_overwrite_nothing(sa, monkeypatch, capsys, tmp_path):
    att = make_attempt(tmp_path)
    run_dir = att / "seed-s1__history-h0"
    rc1, _ = run(sa, monkeypatch, capsys, [att], Child(edit=lambda p, ck: {**p, "auroc": False}))
    [first] = post_dirs(run_dir)
    before = snapshot(first)
    rc2, out2 = run(sa, monkeypatch, capsys, [att], Child())
    assert (rc1, rc2) == (1, 0) and " ok " in out2
    folders = post_dirs(run_dir)
    assert len(folders) == 2 and snapshot(first) == before
    statuses = [json.loads((f / "post_score_manifest.json").read_text())["status"] for f in folders]
    assert sorted(statuses) == ["invalid_output", "ok"]


def test_eval_range_override_is_explicit_recorded_and_isolated(sa, monkeypatch, capsys, tmp_path):
    att = make_attempt(tmp_path)
    run_dir = att / "seed-s1__history-h0"
    child = Child()
    assert run(sa, monkeypatch, capsys, [att], child)[0] == 0
    [first] = post_dirs(run_dir)
    before = snapshot(first)
    rc, out = run(sa, monkeypatch, capsys, [att, "--override-eval-files", "8000-8005"], child)
    assert rc == 0 and "EVAL RANGE OVERRIDE" in out and len(child.calls) == 2
    second = [f for f in post_dirs(run_dir) if f != first][0]
    man = json.loads((second / "post_score_manifest.json").read_text())
    assert man["eval_range_override"] == {"file_start": 8000, "file_end": 8005}
    assert man["eval_range"]["source"] == "override" and man["frozen_eval_range"]["file_end"] == 8010
    assert child.calls[1]["config"]["eval"]["file_end"] == 8005 and "eval.file_end=8005" in man["command"]
    assert child.calls[0]["config"]["eval"]["file_end"] == 8010 and snapshot(first) == before
    # A later frozen-range request is still satisfied by the frozen-range folder, not by the override one.
    rc, out = run(sa, monkeypatch, capsys, [att], child)
    assert rc == 0 and "skipped:valid_exists" in out and f"post_score/{first.name}" in out and len(child.calls) == 2


def test_prior_valid_attempt_is_skipped(sa, monkeypatch, capsys, tmp_path):
    att = make_attempt(tmp_path)
    child = Child()
    rc1, _ = run(sa, monkeypatch, capsys, [att], child)
    rc2, out2 = run(sa, monkeypatch, capsys, [att], child)
    assert (rc1, rc2) == (0, 0) and len(child.calls) == 1 and "skipped:valid_exists" in out2
    assert "0.3100" in out2 and len(post_dirs(att / "seed-s1__history-h0")) == 1


@pytest.mark.parametrize("tamper", ["metrics", "manifest_status", "score_config", "checkpoint_identity"])
def test_prior_attempt_is_revalidated_not_trusted(sa, monkeypatch, capsys, tmp_path, tamper):
    att = make_attempt(tmp_path)
    child = Child()
    assert run(sa, monkeypatch, capsys, [att], child)[0] == 0
    [first] = post_dirs(att / "seed-s1__history-h0")
    man_path = first / "post_score_manifest.json"
    man = json.loads(man_path.read_text())
    if tamper == "metrics":
        m = json.loads((first / "post_score_metrics.json").read_text())
        (first / "post_score_metrics.json").write_text(json.dumps({**m, "average_precision": float("nan")}))
    elif tamper == "manifest_status":
        man_path.write_text(json.dumps({**man, "status": "running"}))
    elif tamper == "score_config":
        (first / "resolved_score.yaml").write_text(FROZEN.replace("8010", "8011"))
    else:
        man_path.write_text(json.dumps({**man, "checkpoint_sha256": "0" * 64}))
    rc, out = run(sa, monkeypatch, capsys, [att], child)
    assert rc == 0 and len(child.calls) == 2 and f"prior_invalid post_score/{first.name}" in out
    assert "skipped:valid_exists" not in out and len(post_dirs(att / "seed-s1__history-h0")) == 2


def test_legacy_fixed_path_output_is_neither_trusted_nor_overwritten(sa, monkeypatch, capsys, tmp_path):
    att = make_attempt(tmp_path)
    legacy = att / "seed-s1__history-h0" / "post_score_metrics.json"
    legacy.write_text('{"average_precision": NaN}')  # review's D1 case: v2 skipped on this file and exited 0
    child = Child()
    rc, out = run(sa, monkeypatch, capsys, [att], child)
    assert rc == 0 and len(child.calls) == 1 and "legacy fixed-path" in out and "skipped" not in out
    assert legacy.read_text() == '{"average_precision": NaN}'


def test_changed_checkpoint_is_not_scored_even_with_a_valid_prior(sa, monkeypatch, capsys, tmp_path):
    att = make_attempt(tmp_path)
    child = Child()
    assert run(sa, monkeypatch, capsys, [att], child)[0] == 0
    (att / "seed-s1__history-h0" / "best.ckpt").write_bytes(b"replaced")
    rc, out = run(sa, monkeypatch, capsys, [att], child)
    assert rc == 1 and "ckpt_changed" in out and len(child.calls) == 1


# ---------------------------------------------------------------- validator and source identity agree with the runner

def _runner():
    return load(f"runner_4a_{os.urandom(4).hex()}", ROOT / "YOUR_PACKAGE/phase4a/scripts/run_ablations.py")


def test_validator_agrees_with_runner_contract(sa, tmp_path):
    runner = _runner()
    ck = tmp_path / "best.ckpt"
    ck.write_bytes(b"checkpoint")
    good = {"schema_version": 1, "checkpoint_path": str(ck), "checkpoint_sha256": sha(ck),
            "predictions_path": "synthetic/preds.parquet", "n_predictions": 2, "n_positives": 1,
            "average_precision": 0.6, "auroc": 0.7}
    cases = [good, {**good, "average_precision": float("nan")},
             {k: v for k, v in good.items() if k not in ("schema_version", "checkpoint_path", "predictions_path")},
             {**good, "average_precision": True, "auroc": False, "n_positives": True},
             {**good, "n_positives": 0}, {**good, "n_positives": 2}, {**good, "schema_version": True},
             {**good, "checkpoint_path": "best.ckpt"}, {**good, "auroc": None}, {**good, "average_precision": 1},
             {k: v for k, v in good.items() if k != "n_predictions"}, [good]]
    for i, case in enumerate(cases):
        p = tmp_path / f"case{i}.json"
        p.write_text(json.dumps(case))
        for require in (True, False):
            outcome = []
            for fn in (runner._score_metrics, sa.score_metrics):
                try:
                    outcome.append(("ok", fn(str(p), str(ck), sha(ck), require)))
                except Exception as exc:
                    outcome.append(("error", type(exc).__name__, str(exc)))
            assert outcome[0] == outcome[1], (i, require, outcome)
    assert sa.score_metrics(str(tmp_path / "case0.json"), str(ck), sha(ck))["average_precision"] == 0.6


def test_source_identity_uses_the_runner_convention(sa):
    assert sa.source_provenance()["source_sha256"] == _runner()._source_provenance()["source_sha256"]


# ---------------------------------------------------------------- --from-ledger: v2 and v3 selection

V2_COLS = ["ledger_schema", "collected_utc", "attempt_dir", "attempt", "run_name", "status", "run_score"]
V3_COLS = V2_COLS + ["revision", "transition", "evidence_sha256"]


def write_ledger(path, cols, rows):
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({c: r.get(c, "") for c in cols})
    return path


def test_v2_ledger_takes_last_row_per_key(sa, tmp_path):
    a, b = tmp_path / "x" / "attA", tmp_path / "x" / "attB"
    rows = [
        {"ledger_schema": V2, "attempt_dir": a, "run_name": "r1", "status": "ok", "run_score": "False"},
        {"ledger_schema": V2, "attempt_dir": f"{a}/", "run_name": "r1", "status": "invalid:checkpoint_hash_changed",
         "run_score": "False"},  # same key after canonicalization; later row wins
        {"ledger_schema": V2, "attempt_dir": a, "run_name": "r2", "status": "not_run", "run_score": "False"},
        {"ledger_schema": V2, "attempt_dir": tmp_path / "x" / ".." / "x" / "attA", "run_name": "r2", "status": "ok",
         "run_score": "False"},
        {"ledger_schema": V2, "attempt_dir": b, "run_name": "r1", "status": "ok", "run_score": "True"},  # scored
        {"ledger_schema": V2, "attempt_dir": b, "run_name": "r2", "status": "ok", "run_score": "false"},
    ]
    chosen = sa.ledger_selection(write_ledger(tmp_path / "v2.csv", V2_COLS, rows))
    assert chosen == {os.path.realpath(a): {"r2"}, os.path.realpath(b): {"r2"}}


def test_v3_ledger_takes_highest_revision_per_key(sa, tmp_path):
    a = tmp_path / "attA"
    rows = [
        {"ledger_schema": V3, "attempt_dir": a, "run_name": "r1", "status": "ok", "run_score": "False", "revision": 2,
         "transition": "revalidated", "evidence_sha256": "e2"},
        {"ledger_schema": V3, "attempt_dir": a, "run_name": "r1", "status": "not_run", "run_score": "False",
         "revision": 1, "transition": "new", "evidence_sha256": "e1"},  # older revision written later: ignored
        {"ledger_schema": V3, "attempt_dir": a, "run_name": "r2", "status": "ok", "run_score": "False", "revision": 1,
         "transition": "new", "evidence_sha256": "e3"},
        {"ledger_schema": V3, "attempt_dir": a, "run_name": "r2", "status": "invalid:manifest_disagrees",
         "run_score": "False", "revision": 2, "transition": "status_changed", "evidence_sha256": "e4"},
        {"ledger_schema": V3, "attempt_dir": a, "run_name": "r3", "status": "ok", "run_score": "True", "revision": 1},
        {"ledger_schema": V2, "attempt_dir": a, "run_name": "r4", "status": "ok", "run_score": "False"},  # legacy row
        {"ledger_schema": V3, "attempt_dir": a, "run_name": "r5", "status": "ok", "run_score": "False", "revision": 0},
        {"ledger_schema": V2, "attempt_dir": a, "run_name": "r5", "status": "not_run", "run_score": "False"},
    ]
    chosen = sa.ledger_selection(write_ledger(tmp_path / "v3.csv", V3_COLS, rows))
    assert chosen == {os.path.realpath(a): {"r1", "r4", "r5"}}


@pytest.mark.parametrize("bad", ["v3_without_revision", "unknown_schema", "missing_columns"])
def test_unusable_ledger_is_refused(sa, monkeypatch, capsys, tmp_path, bad):
    a = tmp_path / "attA"
    if bad == "missing_columns":
        path = tmp_path / "bad.csv"
        path.write_text("a,b\n1,2\n")
    else:
        row = {"ledger_schema": V3 if bad == "v3_without_revision" else "other-v9", "attempt_dir": a,
               "run_name": "r1", "status": "ok", "run_score": "False", "revision": ""}
        path = write_ledger(tmp_path / "bad.csv", V3_COLS, [row])
    child = Child()
    rc, _ = run(sa, monkeypatch, capsys, ["--from-ledger", path], child)
    assert rc == 2 and child.calls == []


@pytest.mark.parametrize("schema", [V2, V3])
def test_from_ledger_scores_only_selected_runs(sa, monkeypatch, capsys, tmp_path, schema):
    att = make_attempt(tmp_path, runs=("r1", "r2", "r3"))
    rows = [{"ledger_schema": schema, "attempt_dir": att, "run_name": n, "status": "ok", "run_score": "False",
             "revision": 1} for n in ("r1", "r2", "r3")]
    rows.append({"ledger_schema": schema, "attempt_dir": att, "run_name": "r2", "status": "invalid:x",
                 "run_score": "False", "revision": 2})
    ledger = write_ledger(tmp_path / "ledger.csv", V3_COLS if schema == V3 else V2_COLS, rows)
    child = Child()
    rc, out = run(sa, monkeypatch, capsys, ["--from-ledger", ledger], child)
    assert rc == 0 and len(child.calls) == 2 and "/r2" not in out
    assert [c["config"]["experiment"]["run_name"].split("__")[-2] for c in child.calls] == ["r1", "r3"]


def test_ledger_run_missing_from_results_is_a_failure(sa, monkeypatch, capsys, tmp_path):
    att = make_attempt(tmp_path, runs=("r1",))
    ledger = write_ledger(tmp_path / "ledger.csv", V2_COLS, [
        {"ledger_schema": V2, "attempt_dir": att, "run_name": n, "status": "ok", "run_score": "False"}
        for n in ("r1", "ghost")])
    rc, out = run(sa, monkeypatch, capsys, ["--from-ledger", ledger], Child())
    assert rc == 1 and "not_in_results" in out


# ---------------------------------------------------------------- synthetic/positive_control.sh stage exits

FAKE_PY = r"""#!/bin/sh
# Fake python3 (no training): only the metric-extraction one-liner reaches the real interpreter, isolated (-I) so the
# synthetic sitecustomize on PYTHONPATH is not imported; the one-liner needs the standard library only.
case "$*" in
  *_fake_make_s3_filesystem*) [ -n "$FAIL_SHIM" ] && exit 3; exit 0 ;;  # the harness's fake-S3 guard
  *make_synthetic_data.py*) [ -n "$FAIL_GEN" ] && { echo 'generator broke' >&2; exit 9; }
                            mkdir -p "$FAKE_S3_ROOT"; echo 'rows 10'; exit 0 ;;
  *build_preprocessing_artifacts.py*) [ -n "$FAIL_BUILD" ] && { echo 'injected synthetic command failure'; exit 23; }
                                      exit 0 ;;
  *train_sequential.py*)
    dir=""; h=""
    for a in "$@"; do
      case "$a" in output.checkpoint_dir=*) dir="${a#output.checkpoint_dir=}" ;;
                   sequence.history_len=*) h="${a#sequence.history_len=}" ;; esac
    done
    if [ -n "$FAIL_TRAIN" ] && [ "${dir%"$FAIL_TRAIN"}" != "$dir" ]; then echo 'train broke'; exit 23; fi
    [ -n "$NO_METRICS" ] && exit 0
    mkdir -p "$dir"
    # Deliberately reversed ordering: h0 above h5 in both modes.
    if [ "$h" = 5 ]; then ap=0.05; else ap=0.20; fi
    printf 'epoch,valid_ap,valid_auroc\n0,%s,0.61\n1,0.01,0.50\n' "$ap" > "$dir/training_metrics.csv"; exit 0 ;;
  *) exec REAL_PY -I "$@" ;;
esac
"""


def positive_control(tmp_path, **flags):
    fake = tmp_path / "bin"
    fake.mkdir()
    (fake / "python3").write_text(FAKE_PY.replace("REAL_PY", sys.executable))
    (fake / "python3").chmod(0o755)
    env = {k: v for k, v in os.environ.items()
           if k not in ("FAIL_GEN", "FAIL_BUILD", "FAIL_TRAIN", "NO_METRICS", "FAIL_SHIM")}
    env.update({k: str(v) for k, v in flags.items()}, PATH=f"{fake}{os.pathsep}{os.environ['PATH']}")
    return subprocess.run(["bash", str(HERE / "synthetic" / "positive_control.sh"), str(tmp_path / "sb"), "2", "1"],
                          cwd=ROOT, env=env, capture_output=True, text=True, timeout=60)


def _no_summary(p):
    return "DIAGNOSTIC" not in p.stdout and "Expectations" not in p.stdout and "DONE" not in p.stdout


def test_positive_control_failed_artifact_build_exits_nonzero(tmp_path):
    # review's negative control: only data generation succeeds; the artifact build exits 23 (training is never reached).
    p = positive_control(tmp_path, FAIL_BUILD=1)
    assert p.returncode == 1 and "POSITIVE CONTROL FAILED: [history] artifact build (exit 23)" in p.stdout
    assert _no_summary(p) and "best valid_ap" not in p.stdout


def test_positive_control_failed_data_generation_exits_nonzero(tmp_path):
    p = positive_control(tmp_path, FAIL_GEN=1)
    assert p.returncode == 1 and "POSITIVE CONTROL FAILED: [history] data generation (exit 9)" in p.stdout
    assert _no_summary(p)


def test_positive_control_later_training_failure_exits_nonzero(tmp_path):
    p = positive_control(tmp_path, FAIL_TRAIN="current/h5_s2")
    assert p.returncode == 1 and "POSITIVE CONTROL FAILED: [current] training seed 2 h5 (exit 23)" in p.stdout
    assert p.stdout.count("best valid_ap") == 7 and _no_summary(p)


def test_positive_control_failed_metric_extraction_exits_nonzero(tmp_path):
    p = positive_control(tmp_path, NO_METRICS=1)
    assert p.returncode == 1 and "POSITIVE CONTROL FAILED: [history] metric extraction seed 1 h0" in p.stdout
    assert _no_summary(p)


def test_positive_control_reports_diagnostics_and_exits_zero_whatever_the_ordering(tmp_path):
    p = positive_control(tmp_path)
    assert p.returncode == 0, p.stdout + p.stderr
    assert "FAILED" not in p.stdout and p.stdout.count("best valid_ap") == 8
    assert "POSITIVE CONTROL DIAGNOSTIC: all stages ran" in p.stdout
    assert "history  h0 0.2000 / 0.2000   h5 0.0500 / 0.0500   h5-h0 -0.1500 / -0.1500" in p.stdout
    assert "not pass/fail" in p.stdout and "neither is a leakage test" in p.stdout
    assert "must beat" not in p.stdout and "should not beat" not in p.stdout


# ---------------------------------------------------------------- review-013 R1: the owner's return copy (batch 2)

def _rows(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def test_return_dir_holds_post_hoc_scores_and_safe_evidence(sa, monkeypatch, capsys, tmp_path):
    """The folder the owner is asked to send must contain the post-hoc evaluation results with run identity."""
    att = make_attempt(tmp_path, runs=("seed-s1__history-h0", "seed-s1__history-h5"))
    out = tmp_path / "runs" / "returns" / "batch2_X"
    rc, printed = run(sa, monkeypatch, capsys, [att, "--return-dir", out], Child())
    assert rc == 0
    assert "0.3100" in (out / "POST_SCORE.txt").read_text() and "0.3100" in printed
    rows = _rows(out / "post_score_results.csv")
    assert [r["run_name"] for r in rows] == ["seed-s1__history-h0", "seed-s1__history-h5"]
    for r in rows:
        run_dir = att / r["run_name"]
        [folder] = post_dirs(run_dir)
        assert r["status"] == "ok" and r["post_score_id"] == folder.name and r["attempt"] == att.name
        assert float(r["eval_ap"]) == 0.31 and r["n_predictions"] == "100" and r["n_positives"] == "7"
        assert (r["eval_file_start"], r["eval_file_end"]) == ("8000", "8010")
        assert r["checkpoint_sha256"] == sha(run_dir / "best.ckpt") and r["cohort_verdict"] == ""
        copy = out / "post_score" / att.name / r["run_name"] / folder.name
        assert sorted(p.name for p in copy.iterdir()) == ["post_score_manifest.json", "post_score_metrics.json",
                                                          "resolved_score.yaml"]
        for name in ("post_score_manifest.json", "post_score_metrics.json", "resolved_score.yaml"):
            assert (copy / name).read_bytes() == (folder / name).read_bytes()
    assert not list(out.rglob("score.log")) and not list(out.rglob("*.parquet"))


@pytest.mark.parametrize("failed", [[], ["cohort_counts"]])
def test_return_dir_carries_the_cohort_verdict_and_acceptance_record(sa, monkeypatch, capsys, tmp_path, failed):
    att = make_attempt(tmp_path)
    pre = tmp_path / "runs" / "preflight" / "20261008T000000Z"
    pre.mkdir(parents=True)
    (pre / "data_contract.json").write_text(json.dumps({"eval_8000_8010": {"rows": 100, "positives": 7}}))
    monkeypatch.setattr(sa, "check_cohort", lambda contract, m: list(failed))
    out = tmp_path / "ret"
    rc, _ = run(sa, monkeypatch, capsys, [att, "--preflight", pre, "--return-dir", out], Child())
    assert rc == (1 if failed else 0)
    [r] = _rows(out / "post_score_results.csv")
    assert r["cohort_preflight"] == pre.name and r["cohort_verdict"] == ("failed" if failed else "ok")
    assert r["cohort_failed_checks"] == "+".join(failed) and r["status"] == ("cohort_mismatch" if failed else "ok")
    [folder] = post_dirs(att / "seed-s1__history-h0")
    copy = out / "post_score" / att.name / "seed-s1__history-h0" / folder.name
    [acc] = [p for p in copy.iterdir() if p.name.startswith("cohort_acceptance_")]
    assert acc.name == r["cohort_acceptance_record"]
    assert json.loads(acc.read_text())["verdict"] == ("failed" if failed else "ok")


def test_return_dir_lists_failed_scoring_without_its_log(sa, monkeypatch, capsys, tmp_path):
    att = make_attempt(tmp_path)
    out = tmp_path / "ret"
    rc, _ = run(sa, monkeypatch, capsys, [att, "--return-dir", out], Child(rc=3))
    assert rc == 1
    [r] = _rows(out / "post_score_results.csv")
    assert r["status"] == "score_failed" and r["eval_ap"] == "" and r["post_score_id"]
    copy = out / "post_score" / att.name / "seed-s1__history-h0" / r["post_score_id"]
    names = sorted(p.name for p in copy.iterdir())
    assert "post_score_manifest.json" in names and "score.log" not in names  # the log can quote data; stays local
    assert json.loads((copy / "post_score_manifest.json").read_text())["status"] == "score_failed"


def test_return_dir_never_overwrites_earlier_returns(sa, monkeypatch, capsys, tmp_path):
    att = make_attempt(tmp_path)
    out = tmp_path / "ret"
    out.mkdir()
    (out / "POST_SCORE.txt").write_text("earlier")
    child = Child()
    rc, _ = run(sa, monkeypatch, capsys, [att, "--return-dir", out], child)
    assert rc == 2 and not child.calls  # refused before any scoring
    assert (out / "POST_SCORE.txt").read_text() == "earlier" and not post_dirs(att / "seed-s1__history-h0")


def test_batch2_passes_its_return_folder_to_the_post_hoc_scorer():
    text = (HERE / "batch2.sh").read_text()
    scorer = next(l for l in text.splitlines() if "score_attempt.py" in l and "--from-ledger" in l)
    collect = next(l for l in text.splitlines() if "collect_returns.py" in l)
    assert '--return-dir "$OUT"' in scorer and '--out "$OUT"' in collect
    assert text.index("OUT=runs/returns/batch2_") < text.index("score_attempt.py")


def test_return_dir_from_ledger_lists_every_ledger_run_including_missing_ones(sa, monkeypatch, capsys, tmp_path):
    """batch2.sh's real path: --from-ledger with --return-dir; a run missing from results.csv still gets a row."""
    att = make_attempt(tmp_path, runs=("r1",))
    ledger = write_ledger(tmp_path / "ledger.csv", V2_COLS, [
        {"ledger_schema": V2, "attempt_dir": att, "run_name": n, "status": "ok", "run_score": "False"}
        for n in ("r1", "ghost")])
    out = tmp_path / "ret"
    rc, _ = run(sa, monkeypatch, capsys, ["--from-ledger", ledger, "--return-dir", out], Child())
    assert rc == 1
    rows = {r["run_name"]: r for r in _rows(out / "post_score_results.csv")}
    assert rows["r1"]["status"] == "ok" and float(rows["r1"]["eval_ap"]) == 0.31
    assert rows["ghost"]["status"] == "not_in_results" and rows["ghost"]["post_score_id"] == ""


def test_return_dir_after_revalidating_an_existing_post_score(sa, monkeypatch, capsys, tmp_path):
    att = make_attempt(tmp_path)
    run(sa, monkeypatch, capsys, [att], Child())
    [folder] = post_dirs(att / "seed-s1__history-h0")
    out = tmp_path / "ret"
    child = Child()
    rc, _ = run(sa, monkeypatch, capsys, [att, "--return-dir", out], child)
    assert rc == 0 and not child.calls
    [r] = _rows(out / "post_score_results.csv")
    assert r["status"] == "skipped:valid_exists" and r["post_score_id"] == folder.name and float(r["eval_ap"]) == 0.31
    assert (out / "post_score" / att.name / "seed-s1__history-h0" / folder.name / "post_score_metrics.json").is_file()


def test_return_dir_lists_an_unreadable_attempt(sa, monkeypatch, capsys, tmp_path):
    missing = tmp_path / "ablations" / "nowhere" / "20261008T000000Z-x"
    out = tmp_path / "ret"
    rc, _ = run(sa, monkeypatch, capsys, [missing, "--return-dir", out], Child())
    assert rc == 1
    [r] = _rows(out / "post_score_results.csv")
    assert r["status"] == "attempt_unreadable" and r["attempt"] == missing.name


def test_positive_control_refuses_without_the_fake_s3_redirect(tmp_path):
    p = positive_control(tmp_path, FAIL_SHIM=1)
    assert p.returncode == 1 and "fake-S3 redirect not active" in p.stdout and "rows 10" not in p.stdout

