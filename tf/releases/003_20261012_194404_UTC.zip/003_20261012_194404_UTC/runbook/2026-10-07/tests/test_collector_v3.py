# reviewer, 2026-10-07. Regression tests for collect_returns.py v3, built from review's collector review of a987168
# (bridge/reviews/review/2026-10-07-PR3-a987168/collector_review_a987168.md, R1-R3). Each case was accepted or mis-recorded
# by a987168. Synthetic only: make_attempt() writes what run_ablations.py writes for a finished two-run attempt (one
# row dict saved both to results.csv and as run_manifest.json's "result", top-level config hashes, score files).
# Optionally also run every `attempt` case on a copy of a real completed attempt folder (never modified):
#     RUNBOOK_REAL_ATTEMPT=<output_root>/<attempt> python -m pytest -q runbook/2026-10-07/tests/test_collector_v3.py
import csv
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import uuid
from pathlib import Path

import pytest
from omegaconf import OmegaConf

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[1]
SCRIPT = HERE / "collect_returns.py"
_s = importlib.util.spec_from_file_location("collector_v3", SCRIPT)
c = importlib.util.module_from_spec(_s)
_s.loader.exec_module(c)

BASE = "YOUR_PACKAGE/phase4a/configs/sequential.yaml"
AXES = {"mask": {"bidir": ["sequence.attention_mask=bidirectional"], "causal": ["sequence.attention_mask=causal"]}}
ATTEMPT = "20261007T063242Z-fe46cc3015cc4590be47e38e8cd563a7"
SOURCE = "7f4b5ac176629cd9e66c168b20b5bef7005557dd548bf7c230a0f621a692a11c"
V3_COLUMNS = ["ledger_schema", "collected_utc", "attempt_dir", "attempt", "run_name", "status", "runner_status",
              "train_rc", "score_rc", "checkpoint_epoch", "checkpoint_step", "valid_ap", "valid_auroc",
              "checkpoint_monitor_score", "eval_ap", "eval_auroc", "eval_rows", "eval_positives", "run_score",
              "history_len", "seed", "batch_x_accum", "train_files", "val_files", "eval_files", "embedding", "mask",
              "optimizer", "time_delta", "model", "artifacts", "checkpoint_sha256", "source_sha256",
              "resolved_train_sha256", "started_utc", "finished_utc", "sweep_peak_gpu_mib", "predictions_path",
              "cohort_check", "revision", "transition", "evidence_sha256",
              "manifest_sha256", "active_configs_sha256", "spec_sha256"]  # v4 added cohort_check; v5 the identity columns


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def make_attempt(tmp, run_score=True):
    """A finished two-run attempt exactly as run_ablations.py lays it out (synthetic checkpoints and metrics)."""
    output_root = tmp / "ablations" / "ft_decisions"
    att = output_root / ATTEMPT
    att.mkdir(parents=True)
    OmegaConf.save(OmegaConf.create({"base_config": BASE, "output_root": str(output_root), "run_score": run_score,
                                     "common_overrides": ["training.seed=42"], "axes": AXES}), att / "ablation_spec.yaml")
    base = OmegaConf.load(ROOT / BASE)
    results = []
    for option, overrides in AXES["mask"].items():
        name = f"mask-{option}"
        run = att / name
        run.mkdir()
        effective = OmegaConf.merge(base, OmegaConf.from_dotlist(
            ["training.seed=42", *overrides, f"output.checkpoint_dir={run}",
             f"experiment.run_name=ft_decisions__{ATTEMPT}__{name}"]))
        OmegaConf.save(effective, run / "resolved_train.yaml", resolve=True)
        ckpt = run / "best.ckpt"
        ckpt.write_bytes(f"synthetic checkpoint {name}".encode())
        manifest = {"schema_version": 1, "attempt": ATTEMPT, "run_name": name, "environment": {},
                    "source_before": {"source_sha256": SOURCE}, "resolved_train_sha256": sha(run / "resolved_train.yaml"),
                    "train_command": ["python", "train_sequential.py"], "score_command": None,
                    "started_utc": "2026-10-07T06:32:42Z"}
        row = {"run_name": name, "mask": option, "train_rc": 0, "best_valid_ap": 0.232967, "best_valid_auroc": 0.483969,
               "eval_ap": None, "eval_auroc": None, "attempt": ATTEMPT, "run_dir": str(run), "score_rc": None,
               "status": "ok", "predictions_path": None, "n_predictions": None, "n_positives": None,
               "checkpoint_epoch": 0, "checkpoint_step": 4, "checkpoint_monitor": "valid_ap",
               "checkpoint_monitor_score": 0.23296712338924408, "checkpoint_sha256": sha(ckpt),
               "resolved_train_sha256": manifest["resolved_train_sha256"], "source_sha256": SOURCE,
               "manifest_path": str(run / "run_manifest.json"), "error": None}
        if run_score:
            score_metrics = run / "score_metrics.json"
            OmegaConf.save(OmegaConf.merge(effective, {"eval": {"checkpoint": str(ckpt), "metrics_output": str(score_metrics)}}),
                           run / "resolved_score.yaml", resolve=True)
            manifest.update(resolved_score_sha256=sha(run / "resolved_score.yaml"),
                            score_command=["python", "score_sequential.py"])
            sm = {"schema_version": 1, "predictions_path": f"bucket/predictions/{name}_preds.parquet",
                  "checkpoint_path": str(ckpt), "checkpoint_sha256": row["checkpoint_sha256"], "n_predictions": 8535,
                  "n_positives": 347, "average_precision": 0.04187125483892516, "auroc": 0.5068672577709138}
            write_json(score_metrics, sm)
            row.update(score_rc=0, predictions_path=sm["predictions_path"], n_predictions=sm["n_predictions"],
                       n_positives=sm["n_positives"], eval_ap=sm["average_precision"], eval_auroc=sm["auroc"])
        manifest.update(result=row, finished_utc="2026-10-07T06:40:00Z")
        write_json(run / "run_manifest.json", manifest)
        results.append(row)
    save_rows(att, results)
    return att


@pytest.fixture(params=["synthetic", "real_copy"])
def attempt(request, tmp_path):
    if request.param == "synthetic":
        return make_attempt(tmp_path)
    src = os.environ.get("RUNBOOK_REAL_ATTEMPT")
    if not src:
        pytest.skip("RUNBOOK_REAL_ATTEMPT not set (optional copy of a real completed attempt)")
    dst = tmp_path / "ablations" / Path(src).parent.name / Path(src).name
    shutil.copytree(src, dst)
    return dst


def read_rows(att):
    with open(att / "results.csv", newline="") as f:
        return list(csv.DictReader(f))


def save_rows(att, rows):
    with open(att / "results.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def edit_manifest(att, name, **result):
    p = att / name / "run_manifest.json"
    m = json.loads(p.read_text())
    m["result"].update(result)
    write_json(p, m)


def statuses(att):
    return {r["run_name"]: r["status"] for r in c.collect_attempt(str(att))}


def cli(tmp, *args):
    return subprocess.run([sys.executable, str(SCRIPT), *map(str, args), "--out", str(tmp / "out" / uuid.uuid4().hex)],
                          capture_output=True, text=True)


def ledger_rows(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


# ---- R1: evidence binding ------------------------------------------------------------------------------------------

def test_genuine_attempts_are_ok(attempt, tmp_path):
    assert set(statuses(attempt).values()) == {"ok"}
    assert set(statuses(make_attempt(tmp_path / "vo", run_score=False)).values()) == {"ok"}


def test_changed_resolved_train_history_is_mismatch(attempt):
    first, second = (r["run_name"] for r in read_rows(attempt))
    p = attempt / first / "resolved_train.yaml"
    cfg = OmegaConf.load(p)
    cfg.sequence.history_len = 999
    OmegaConf.save(cfg, p)
    assert statuses(attempt) == {first: "evidence_mismatch:resolved_train_sha256", second: "ok"}


def test_deleted_resolved_train_is_not_ok(attempt):
    first = read_rows(attempt)[0]["run_name"]
    (attempt / first / "resolved_train.yaml").unlink()
    assert statuses(attempt)[first] == "invalid:resolved_train_missing"


@pytest.mark.parametrize("changes", [{"best_valid_ap": "0.999"}, {"best_valid_auroc": "0.999"},
                                     {"checkpoint_epoch": "77"}, {"checkpoint_step": "8888"},
                                     {"best_valid_ap": "0.999", "best_valid_auroc": "0.999", "checkpoint_epoch": "77",
                                      "checkpoint_step": "8888"}])
def test_changed_csv_metrics_epoch_step_are_mismatch(attempt, changes):
    rows = read_rows(attempt)
    rows[0].update(changes)
    save_rows(attempt, rows)
    assert statuses(attempt)[rows[0]["run_name"]] == "evidence_mismatch:" + "+".join(sorted(changes))


def test_nonzero_return_codes_with_ok_status(attempt):
    rows = read_rows(attempt)
    rows[0].update(train_rc="23", score_rc="23")
    save_rows(attempt, rows)
    assert statuses(attempt)[rows[0]["run_name"]] == "evidence_mismatch:score_rc+train_rc;invalid:train_rc+score_rc"
    edit_manifest(attempt, rows[0]["run_name"], train_rc=23, score_rc=23)  # both sources now agree on the failure
    assert statuses(attempt)[rows[0]["run_name"]] == "invalid:train_rc+score_rc"


def test_manifest_contradictions_are_mismatch(attempt):
    first, second = (r["run_name"] for r in read_rows(attempt))
    edit_manifest(attempt, first, source_sha256="0" * 64)
    p = attempt / second / "run_manifest.json"
    m = json.loads(p.read_text())
    m["resolved_train_sha256"] = "0" * 64
    write_json(p, m)
    assert statuses(attempt) == {first: "evidence_mismatch:source_sha256",
                                 second: "evidence_mismatch:resolved_train_sha256"}


def test_attempt_identity_is_checked(attempt):
    renamed = attempt.with_name("20261007T000000Z-00000000000000000000000000000000")
    attempt.rename(renamed)
    for status in statuses(renamed).values():
        assert status == "evidence_mismatch:attempt+manifest_path+run_dir"


def test_scored_run_needs_matching_score_config_and_metrics(tmp_path):
    att = make_attempt(tmp_path)
    (att / "mask-bidir" / "resolved_score.yaml").write_text("eval: {}\n")
    p = att / "mask-causal" / "score_metrics.json"
    write_json(p, {**json.loads(p.read_text()), "average_precision": 0.5})
    assert statuses(att) == {"mask-bidir": "evidence_mismatch:resolved_score_sha256",
                             "mask-causal": "evidence_mismatch:eval_ap"}
    (att / "mask-bidir" / "resolved_score.yaml").unlink()
    assert statuses(att)["mask-bidir"] == "invalid:resolved_score_missing"


def test_cell_comparison_is_typed_and_tight():
    assert c.same("0.232967", 0.232967) and c.same("0", 0) and c.same("", None) and c.same("ok", "ok")
    assert c.same("True", True) and c.same("0.04187125483892516", 0.04187125483892516)
    assert not c.same("0.2329671", 0.232967) and not c.same("0.0", 0) and not c.same("0", None)
    assert not c.same("", 0) and not c.same("4", 4.5) and not c.same("true", True)


# ---- R2: ledger revisions ------------------------------------------------------------------------------------------

def test_not_run_then_ok_lifecycle(attempt, tmp_path):
    ledger = tmp_path / "run_log.csv"
    names = [r["run_name"] for r in read_rows(attempt)]
    original = (attempt / "results.csv").read_bytes()
    (attempt / "results.csv").unlink()  # the runner has created the attempt; no run has finished yet
    hidden = attempt / names[0] / "resolved_train.yaml"
    hidden_bytes = hidden.read_bytes()
    hidden.unlink()  # ... and has not started the first run either
    assert cli(tmp_path, attempt, "--ledger", ledger).returncode == 1
    hidden.write_bytes(hidden_bytes)  # first run started: same provisional status, more evidence
    assert cli(tmp_path, attempt, "--ledger", ledger).returncode == 1
    (attempt / "results.csv").write_bytes(original)  # the exact completed results
    assert cli(tmp_path, attempt, "--ledger", ledger).returncode == 0
    rows = ledger_rows(ledger)
    assert [(r["run_name"], r["revision"], r["transition"], r["status"]) for r in rows] == [
        (names[0], "1", "new", "not_run"), (names[1], "1", "new", "not_run"),
        (names[0], "2", "provisional_update", "not_run"),
        (names[0], "3", "provisional_to_final", "ok"), (names[1], "2", "provisional_to_final", "ok")]
    current = c.current_rows(ledger)
    assert {k[1]: (r["status"], r["revision"]) for k, r in current.items()} == {names[0]: ("ok", "3"), names[1]: ("ok", "2")}
    assert all(k[0] == os.path.realpath(attempt) for k in current)
    before = ledger.read_bytes()
    p = cli(tmp_path, attempt, "--ledger", ledger)
    assert p.returncode == 0 and "+0 appended, 2 unchanged, 0 conflict(s)" in p.stdout and ledger.read_bytes() == before


def test_final_state_conflict_is_reported_not_appended(attempt, tmp_path):
    ledger = tmp_path / "run_log.csv"
    assert cli(tmp_path, attempt, "--ledger", ledger).returncode == 0
    before = ledger.read_bytes()
    rows = read_rows(attempt)
    rows[0]["best_valid_ap"] = "0.999"
    save_rows(attempt, rows)
    p = cli(tmp_path, attempt, "--ledger", ledger)
    conflict = [line for line in p.stdout.splitlines() if line.startswith("CONFLICT")]
    assert p.returncode == 1 and len(conflict) == 1 and ledger.read_bytes() == before
    assert f"{os.path.realpath(attempt)} {rows[0]['run_name']}:" in conflict[0]
    assert conflict[0].endswith("differs in status+valid_ap; not appended") and "0.999" not in conflict[0]
    assert c.current_rows(ledger)[(os.path.realpath(attempt), rows[0]["run_name"])]["status"] == "ok"


def test_identical_recollection_is_idempotent(attempt, tmp_path):
    ledger = tmp_path / "run_log.csv"
    rows = c.collect_attempt(str(attempt))
    assert c.append_ledger(str(ledger), rows, "20261007T010000Z") == (2, 0, [])
    before = ledger.read_bytes()
    assert c.append_ledger(str(ledger), c.collect_attempt(str(attempt)), "20261007T020000Z") == (0, 2, [])
    assert ledger.read_bytes() == before
    stored = ledger_rows(ledger)
    assert list(stored[0]) == V3_COLUMNS == c.LEDGER_COLS
    assert {r["ledger_schema"] for r in stored} == {"tf-runbook-ledger-v5"}
    assert all(r["evidence_sha256"] == c.evidence_sha256(r) for r in stored)  # timestamps are not evidence


def test_other_ledger_schema_is_rejected(attempt, tmp_path):
    v2 = tmp_path / "v2.csv"
    v2.write_text(",".join(col for col in V3_COLUMNS if col not in ("revision", "transition", "evidence_sha256")) + "\n")
    before = v2.read_bytes()
    p = cli(tmp_path, attempt, "--ledger", v2)
    assert p.returncode != 0 and "LEDGER SCHEMA MISMATCH" in p.stderr and v2.read_bytes() == before


# ---- R3: duplicates ------------------------------------------------------------------------------------------------

def test_same_attempt_twice_in_one_call(attempt, tmp_path):
    ledger = tmp_path / "run_log.csv"
    link = tmp_path / "link"
    link.symlink_to(attempt)
    p = cli(tmp_path, attempt, f"{attempt}/", link, "--ledger", ledger)
    rows = ledger_rows(ledger)
    assert p.returncode == 0 and len(rows) == 2 and len({(r["attempt_dir"], r["run_name"]) for r in rows}) == 2
    assert "2 of 2 ok" in p.stdout
    rows = c.collect_attempt(str(attempt))
    assert c.append_ledger(str(tmp_path / "direct.csv"), rows + rows, "s") == (2, 2, [])


@pytest.mark.parametrize("failed_first", [True, False])
def test_duplicate_run_name_is_invalid(attempt, tmp_path, failed_first):
    rows = read_rows(attempt)
    failed = dict(rows[0], status="score_failed", score_rc="23")
    save_rows(attempt, [failed, *rows] if failed_first else [*rows, failed])
    assert statuses(attempt) == {rows[0]["run_name"]: "invalid_results:duplicate_run_name", rows[1]["run_name"]: "ok"}
    assert cli(tmp_path, attempt, "--no-ledger").returncode == 1
