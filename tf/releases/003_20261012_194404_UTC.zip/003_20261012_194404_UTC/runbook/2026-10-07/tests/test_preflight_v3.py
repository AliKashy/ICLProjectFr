# reviewer, 2026-10-07. Regression tests for preflight_pod.py from reviewer's review of PR #3 at a987168 / e8832fd
# (bridge/reviews/review/2026-10-07-PR3-a987168: preflight_review.md C1-C5, latest_delta_review.md D4, review-004 item 5),
# plus the dependency-range and digest-version items. Synthetic local Parquet and local fsspec filesystems only.
#     PYTHONPATH=src:. python -m pytest -q runbook/2026-10-07/tests
import contextlib
import hashlib
import importlib.metadata
import importlib.util
import io
import json
import os
import re
import sys
from pathlib import Path
from unittest.mock import patch

import fsspec
import pandas as pd
import pytest
from fsspec.implementations.dirfs import DirFileSystem
from fsspec.implementations.local import LocalFileSystem
from omegaconf import OmegaConf

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[1]
SENTINEL = "SENTINEL_PRIVATE_VALUE"


def fresh():
    s = importlib.util.spec_from_file_location(f"pf_v3_{os.urandom(4).hex()}", HERE / "preflight_pod.py")
    m = importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return m


def quiet(fn, *a):
    with contextlib.redirect_stdout(io.StringIO()):
        return fn(*a)


# ---------------------------------------------------------------- C1 / C2: data contract
def frame(**changes):
    df = pd.DataFrame({"account": ["A", "B"], "id": ["id1", "id2"],
                       "time": pd.to_datetime(["2025-01-01", "2025-01-02"]), "label": [0, 1]})
    for k, v in changes.items():
        df[k] = v
    return df


def run_data(tmp_path, df, positive_label=1):
    out = tmp_path / "out"
    out.mkdir()
    path = out / "part_1.parquet"
    df.to_parquet(path, index=False)
    cfg = OmegaConf.create({"data": {"account_col": "account", "order_col": "time", "target_col": "label",
                                     "tie_break_col": "id", "positive_label": positive_label}})
    pf = fresh()
    quiet(pf.check_data, str(out), fsspec.filesystem("file"), cfg, {"train": [str(path)]})
    exported = "\n".join(pf.LINES) + (out / "data_contract.json").read_text()
    return pf, json.loads((out / "data_contract.json").read_text())["train"], exported, out


def test_valid_file_passes_and_digest_is_versioned(tmp_path):
    pf, r, _, _ = run_data(tmp_path, frame())
    assert pf.FAILS == [] and pf.WARNS == []
    assert r["label_counts"] == {"positive": 1, "other": 1, "missing": 0}
    assert r["composite_id_digest_version"] == 1 and "64-bit" in r["composite_id_digest_note"]


@pytest.mark.parametrize("changes,check", [
    ({"id": [None, None]}, "missing transaction ids"),
    ({"id": [float(2 ** 53), float(2 ** 53 + 2)]}, "inexact float transaction ids"),
    ({"id": [1.0, 2.5]}, "inexact float transaction ids"),
    ({"label": [None, 1]}, "missing labels"),
    ({"account": [None, "B"]}, "missing account ids"),
    ({"time": [1735689600, 1735776000]}, "event times"),          # epoch seconds without a unit
    ({"time": ["bad-time", "2025-01-02"]}, "event times"),
    ({"time": [None, "2025-01-02"]}, "event times"),
])
def test_inputs_the_runtime_rejects_fail(tmp_path, changes, check):
    pf, r, _, _ = run_data(tmp_path, frame(**changes))
    assert len(pf.FAILS) == 1 and check in pf.FAILS[0]
    assert any(check in k for k in r["input_contract_rejections"])


def test_exact_float_ids_are_accepted(tmp_path):
    pf, _, _, _ = run_data(tmp_path, frame(id=[1.0, float(2 ** 53 - 1)]))
    assert pf.FAILS == []


@pytest.mark.parametrize("labels,positive,positives", [
    (["legitimate", "fraud"], "fraud", 1),   # nonnumeric negative class is a valid negative
    ([-1, 1], 1, 1),
    ([0, 0], 1, 0),                          # one-class file: valid, only a warning
    (["legitimate", "legitimate"], "fraud", 0),
])
def test_binary_target_semantics_follow_the_runtime(tmp_path, labels, positive, positives):
    pf, r, _, _ = run_data(tmp_path, frame(label=labels), positive_label=positive)
    assert pf.FAILS == []
    assert r["label_counts"] == {"positive": positives, "other": 2 - positives, "missing": 0}
    assert bool(pf.WARNS) == (positives == 0)


@pytest.mark.parametrize("changes", [{"label": [SENTINEL, "1"]}, {"label": [SENTINEL, None]},
                                     {"time": [SENTINEL, "2025-01-02"]}, {"id": [SENTINEL, None]}])
def test_raw_values_never_reach_summary_or_export(tmp_path, changes):
    pf, r, exported, out = run_data(tmp_path, frame(**changes))
    assert SENTINEL not in exported
    assert set(r["label_counts"]) == {"positive", "other", "missing"} and "label_values" not in r
    if "label" in changes:   # observed label values are kept, but only in label_values.txt
        assert SENTINEL in (out / "label_values.txt").read_text()


# ---------------------------------------------------------------- C3 / C4: active artifacts
def run_artifacts(tmp_path, fit_files=("part_1.parquet",), feature=None, manifest_extra=None, predictors="f1,continuous,raw,1\n"):
    s3 = tmp_path / "s3"
    art = s3 / "bucket/YOUR_ID/artifacts/1"
    art.mkdir(parents=True)
    manifest = {"artifact_version": 1, "features": ["f1"], "fit_files": list(fit_files), **(manifest_extra or {})}
    (art / "manifest.json").write_text(json.dumps(manifest))
    entry = feature if feature is not None else {"type": "continuous", "mean": 0.0, "std": 1.0, "median": 0.0}
    (art / "feature__f1.json").write_text(entry if isinstance(entry, str) else json.dumps(entry))
    (tmp_path / "predictors.csv").write_text("feature,type,source,version\n" + predictors)
    cfg = OmegaConf.create({"artifacts": {"base": "s3://bucket/YOUR_ID/artifacts", "version": 1},
                            "predictors": {"csv_path": str(tmp_path / "predictors.csv"), "version": 1},
                            "data": {"val_base": "s3://bucket/raw", "val_start": 4950, "val_end": 4954},
                            "eval": {"base": "s3://bucket/eval", "file_start": 8000, "file_end": 8010}})
    pf = fresh()
    out = tmp_path / "out"
    out.mkdir()
    quiet(pf.check_artifacts, str(out), DirFileSystem(path=str(s3), fs=LocalFileSystem()), cfg)
    return pf, out


def test_valid_artifacts_and_fit_provenance_pass(tmp_path):
    pf, out = run_artifacts(tmp_path)
    assert pf.FAILS == [] and pf.WARNS == []
    assert "loaded by the runtime loader" in "\n".join(pf.LINES)
    assert "content sha256" in (out / "artifacts.txt").read_text()


@pytest.mark.parametrize("feature,predictors", [
    ("INVALID_JSON", "f1,continuous,raw,1\n"),                                      # not loadable
    (None, "f1,continuous,raw,1\nf2,continuous,raw,1\n"),                          # predictor missing
    (None, "f1,categorical,raw,1\n"),                                               # wrong type
    ({"type": "continuous", "mean": 0.0, "std": 0.0, "median": 0.0}, "f1,continuous,raw,1\n"),
    ({"type": "categorical", "vocab": {"a": 2, "b": 5}, "unk_index": 0, "missing_index": 1, "cardinality": 4},
     "f1,categorical,raw,1\n"),                                                     # index beyond cardinality
])
def test_active_artifacts_must_load_and_serve_every_predictor(tmp_path, feature, predictors):
    pf, _ = run_artifacts(tmp_path, feature=feature, predictors=predictors)
    assert any(f.startswith("active artifacts") for f in pf.FAILS)


def test_fit_on_a_validation_file_fails(tmp_path):
    pf, _ = run_artifacts(tmp_path, fit_files=["s3://bucket/raw/part_4950.parquet"])
    assert any("fit on 1 of this cohort's validation/evaluation files" in f for f in pf.FAILS)


@pytest.mark.parametrize("fit_files,manifest_extra", [
    ([], None), (None, None), (["part_4950.parquet"], None), (["eval/part_8000.parquet"], None)])
def test_unresolved_fit_provenance_warns_never_passes(tmp_path, fit_files, manifest_extra):
    if fit_files is None:
        manifest_extra = {"fit_files": None}
    pf, _ = run_artifacts(tmp_path, fit_files=fit_files or [], manifest_extra=manifest_extra)
    assert pf.FAILS == []
    assert any("unresolved fit provenance" in w for w in pf.WARNS)
    assert not any(line.startswith("PASS") and "fit on" in line for line in pf.LINES)


def test_part_numbers_on_another_prefix_are_not_an_overlap(tmp_path):
    pf, _ = run_artifacts(tmp_path, fit_files=["s3://bucket/other/part_4950.parquet", "part_1.parquet"])
    assert pf.FAILS == [] and pf.WARNS == []


# ---------------------------------------------------------------- C5: source gate
@pytest.mark.parametrize("extra,accept,tag", [
    ("YOUR_PACKAGE/phase4a/unreviewed.py", False, "FAIL"), ("fraud/data/shadow.py", False, "FAIL"),
    ("YOUR_PACKAGE/phase4a/unreviewed.py", True, "WARN"), ("YOUR_PACKAGE/notes/helper.py", False, "WARN"),
    ("YOUR_PACKAGE/phase4a/configs/new.yaml", False, "WARN")])
def test_pod_only_runtime_modules_fail_unless_accepted(tmp_path, extra, accept, tag):
    root, ref = tmp_path / "root", tmp_path / "ref"
    (root / "YOUR_PACKAGE/phase4a").mkdir(parents=True)
    ref.mkdir()
    (root / "YOUR_PACKAGE/phase4a/known.py").write_text("known = 1\n")
    (root / extra).parent.mkdir(parents=True, exist_ok=True)
    (root / extra).write_text("x = 1\n")
    (ref / "github_source_manifest.csv").write_text(
        f"path,sha256_lf\nYOUR_PACKAGE/phase4a/known.py,{hashlib.sha256(b'known = 1' + bytes([10])).hexdigest()}\n")
    pf = fresh()
    pf.ROOT, pf.HERE, pf.ACCEPT_SOURCE_DIFF = str(root), str(ref), accept
    quiet(pf.check_source, str(tmp_path))
    assert pf.LINES[0].startswith(tag)


# ---------------------------------------------------------------- launch cohort binding
@pytest.mark.parametrize("override,key", [
    (["data.train_start=101", "data.train_end=110"], "data.train_start"),   # the reviewer's spec_cohort_probe case
    (["eval.base=s3://bucket/other"], "eval.base"),
    (["artifacts.version=2"], "artifacts.version")])
def test_spec_cell_off_the_probed_cohort_fails(tmp_path, override, key):
    pf = fresh()
    original = OmegaConf.load

    def changed(path, *a, **k):
        cfg = original(path, *a, **k)
        if str(path).endswith("/configs/ft_decisions_h0.yaml"):
            cfg.common_overrides = list(cfg.common_overrides) + override
        return cfg
    with patch.object(OmegaConf, "load", side_effect=changed):
        quiet(pf.check_specs, str(tmp_path))
    assert len(pf.FAILS) == 1
    assert pf.FAILS[0].startswith("phase4a/ft_decisions_h0.yaml") and f"history-h0: {key}" in pf.FAILS[0]


def test_committed_specs_bind_to_the_probed_cohort_and_cover_the_batches(tmp_path):
    pf = fresh()
    quiet(pf.check_specs, str(tmp_path))
    assert pf.FAILS == []
    listed = {(phase, name) for phase, names in pf.SPECS.items() for name in names}
    for script in ("batch1.sh", "batch2.sh"):
        steps = re.findall(r'"(phase4[ab]) (ft_decisions[\w]*\.yaml)"', (HERE / script).read_text())
        assert steps and set(steps) <= listed, script


# ---------------------------------------------------------------- D4: raw-only feature coverage
@pytest.mark.parametrize("predictors,columns", [
    ("f1,continuous,raw,1\n", {"f1": [1.0, 2.0]}),                                   # no time column needed
    ("f1,continuous,raw,1\nhour,categorical,derived:time,1\n",
     {"f1": [1.0, 2.0], "time": pd.to_datetime(["2025-01-01 03:00", "2025-01-02 04:00"])})])
def test_calendar_fields_only_when_selected(tmp_path, predictors, columns):
    (tmp_path / "predictors.csv").write_text("feature,type,source,version\n" + predictors)
    art = tmp_path / "artifacts/1"
    art.mkdir(parents=True)
    feats = {"f1": {"type": "continuous", "mean": 1.5, "std": 0.5, "median": 1.5},
             "hour": {"type": "categorical", "vocab": {"3": 2}, "unk_index": 0, "missing_index": 1, "cardinality": 3}}
    names = [line.split(",")[0] for line in predictors.splitlines()]
    (art / "manifest.json").write_text(json.dumps({"artifact_version": 1, "features": names, "fit_files": ["part_1.parquet"]}))
    for n in names:
        (art / f"feature__{n}.json").write_text(json.dumps(feats[n]))
    data = tmp_path / "part_1.parquet"
    pd.DataFrame(columns).to_parquet(data, index=False)
    cfg = OmegaConf.create({"predictors": {"csv_path": str(tmp_path / "predictors.csv"), "version": 1},
                            "artifacts": {"base": str(tmp_path / "artifacts"), "version": 1}, "data": {"order_col": "time"},
                            "datetime": {"fields": ["hour"], "encoding": "categorical", "is_weekend": False}})
    pf = fresh()
    quiet(pf.check_feature_coverage, str(tmp_path), fsspec.filesystem("file"), cfg, {"train": [str(data)]})
    assert pf.FAILS == []
    rates = json.loads((tmp_path / "feature_coverage.json").read_text())["train"]["unknown_category_rate"]
    assert rates == ({"hour": 0.5} if "hour" in names else {})


# ---------------------------------------------------------------- declared dependency ranges
@pytest.mark.parametrize("no_packaging", [False, True])
def test_in_declared_range(monkeypatch, no_packaging):
    if no_packaging:
        monkeypatch.setitem(sys.modules, "packaging.specifiers", None)
    pf = fresh()
    assert pf.in_declared_range("2.3.3", ">=1.1.5,<3.0.0")
    assert not pf.in_declared_range("3.0.6", ">=1.1.5,<3.0.0")
    assert pf.in_declared_range("2.14.1+cpu", ">=2.0.0")
    assert pf.in_declared_range("3.0.0", "<=3.0.0") and not pf.in_declared_range("0.9.2", ">=0.10.0")


@pytest.mark.parametrize("no_tomllib", [False, True])
def test_dependency_outside_declared_range_fails(tmp_path, monkeypatch, no_tomllib):
    if no_tomllib:
        monkeypatch.setitem(sys.modules, "tomllib", None)
    (tmp_path / "pyproject.toml").write_text('[project]\nname = "x"\ndependencies = [\n    "pandas>=1.1.5,<3.0.0",\n'
                                             '    "numpy<=3.0.0",\n    "absent-package>=1.0",\n]\n')
    installed = {"pandas": "3.0.6", "numpy": "2.4.6"}

    def version(name):
        if name not in installed:
            raise importlib.metadata.PackageNotFoundError(name)
        return installed[name]
    monkeypatch.setattr(importlib.metadata, "version", version)
    pf = fresh()
    pf.ROOT = str(tmp_path)
    quiet(pf.check_dependencies, str(tmp_path))
    assert pf.FAILS == ["dependency pandas 3.0.6 is outside the declared range >=1.1.5,<3.0.0 (pyproject.toml)"]
    assert pf.WARNS == ["dependency absent-package not installed (declared >=1.0)"]


def test_duplicate_eval_pairs_fail_but_train_duplicates_only_warn(tmp_path):
    """The scorers reject duplicate (transaction id, account) pairs, so the evaluation split must FAIL on them."""
    import contextlib, io
    import fsspec
    import pandas as pd
    from omegaconf import OmegaConf
    pf = _load_preflight_for_duplicates()
    df = pd.DataFrame(dict(account=["A", "A", "B"], id=["t1", "t1", "t2"],
                           time=pd.to_datetime(["2025-01-01", "2025-01-02", "2025-01-03"]), label=[0, 1, 0]))
    path = tmp_path / "part_1.parquet"
    df.to_parquet(path, index=False)
    cfg = OmegaConf.create({"data": {"account_col": "account", "order_col": "time", "target_col": "label",
                                     "tie_break_col": "id", "positive_label": 1}})
    results = {}
    for split in ("train_1_1", "eval_1_1"):
        out = tmp_path / split
        out.mkdir()
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            pf.check_data(str(out), fsspec.filesystem("file"), cfg, {split: [str(path)]})
        results[split] = buf.getvalue()
    assert "FAIL" in results["eval_1_1"] and "duplicate (account, transaction id)" in results["eval_1_1"]
    assert "duplicate (account, transaction id)" not in results["train_1_1"]
    assert "duplicate ids 1" in results["train_1_1"]


def _load_preflight_for_duplicates():
    import importlib.util
    from pathlib import Path
    path = Path(__file__).resolve().parents[1] / "preflight_pod.py"
    spec = importlib.util.spec_from_file_location("preflight_dup_test", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod
