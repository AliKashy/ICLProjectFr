# reviewer, 2026-10-11 (first release, FIRST_RELEASE_SCOPE v2.8 section 2, smoke row; reference's section 9 item 1).
# Tests for the two smoke specs, smoke_checks.py and smoke.sh. Synthetic only: the S3 helper is replaced by a local
# folder, the pre-flight and the runner by stubs where the shell contract is under test.
#     PYTHONPATH=src:. python -m pytest -q -p no:cacheprovider runbook/2026-10-07/tests/test_smoke.py
import csv
import importlib.util
import inspect
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from fsspec.implementations.dirfs import DirFileSystem
from fsspec.implementations.local import LocalFileSystem
from omegaconf import OmegaConf

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import fraud.data.s3_utils as s3_utils  # noqa: E402
from fraud.data.feature_list import load_feature_list  # noqa: E402
from fraud.data.preprocessing import PreprocessingArtifacts  # noqa: E402


def load(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return m


sc = load("cl_smoke_checks", HERE / "smoke_checks.py")
synth = load("cl_make_synthetic", HERE / "synthetic" / "make_synthetic_data.py")
SPECS = {"phase4a": ("ft_decisions_smoke.yaml", "YOUR_PACKAGE/phase4a/configs/sequential.yaml"),
         "phase4b": ("ft_decisions_hier_smoke.yaml", "YOUR_PACKAGE/phase4b/configs/sequential_hier.yaml")}
# The only effective differences from the base configs: two training files and two epochs.
INTENDED = {"data.train_end": (10, 2), "training.max_epochs": (10, 2)}


def flat(d, prefix=""):
    out = {}
    for k, v in d.items():
        if isinstance(v, dict):
            out.update(flat(v, f"{prefix}{k}."))
        else:
            out[f"{prefix}{k}"] = v
    return out


def resolved_cells(phase):
    spec_name, _ = SPECS[phase]
    runner = load(f"runner_{phase}_smoke_test", ROOT / "YOUR_PACKAGE" / phase / "scripts" / "run_ablations.py")
    spec = OmegaConf.load(ROOT / "YOUR_PACKAGE" / phase / "configs" / spec_name)
    base = OmegaConf.load(ROOT / str(spec.base_config))
    common = [str(o) for o in spec.get("common_overrides", [])]
    _, runs = runner._expand_runs(spec)
    cells = []
    for run_name, ov, _ in runs:
        eff = OmegaConf.merge(base, OmegaConf.from_dotlist(common + ov))
        cells.append((run_name, ov, flat(OmegaConf.to_container(base, resolve=True)),
                      flat(OmegaConf.to_container(eff, resolve=True)), spec))
    return cells


# -- the two specs ---------------------------------------------------------------------------------------------------
@pytest.mark.parametrize("phase", sorted(SPECS))
def test_smoke_spec_is_one_cell_and_changes_only_the_intended_keys(phase):
    cells = resolved_cells(phase)
    assert len(cells) == 1
    run_name, ov, base, eff, spec = cells[0]
    assert str(spec.base_config) == SPECS[phase][1]
    diff = {k: (base.get(k), eff.get(k)) for k in sorted(set(base) | set(eff)) if base.get(k) != eff.get(k)}
    assert diff == INTENDED
    # The modelled cell: files 1 to 2, validation file 4950 only, history 5, time gap on, bidirectional, two epochs.
    assert (eff["data.train_start"], eff["data.train_end"]) == (1, 2)
    assert (eff["data.val_start"], eff["data.val_end"]) == (4950, 4950)
    assert eff["sequence.history_len"] == 5 and eff["sequence.time_delta"] is True
    assert eff["sequence.attention_mask"] == "bidirectional" and eff["training.max_epochs"] == 2
    assert eff["model.continuous_embedding"] == "linear" and eff["training.optimizer"] == "adamw"
    assert eff["training.seed"] == 42
    assert bool(spec.get("run_score", True)) is False  # validation only; no scoring of the evaluation files
    # Two epochs survive the CPU harness's one-epoch reduction, which is appended to common_overrides: the cell's own
    # override comes after common_overrides in the runner's merge.
    assert "training.max_epochs=2" in [str(o) for o in ov]


@pytest.mark.parametrize("phase", sorted(SPECS))
def test_smoke_rows_carry_smoke_in_every_name(phase):
    run_name, _, _, _, spec = resolved_cells(phase)[0]
    assert "smoke" in run_name
    assert "smoke" in os.path.basename(str(spec.output_root))
    assert "smoke" in SPECS[phase][0]
    assert str(spec.results_csv).startswith(str(spec.output_root))


def test_smoke_spec_names_are_the_ones_the_preflight_exempts():
    # Fixed by the pre-flight (SMOKE_SPECS): these two names, under these two folders.
    assert (ROOT / "YOUR_PACKAGE/phase4a/configs/ft_decisions_smoke.yaml").is_file()
    assert (ROOT / "YOUR_PACKAGE/phase4b/configs/ft_decisions_hier_smoke.yaml").is_file()


@pytest.mark.parametrize("phase", sorted(SPECS))
def test_smoke_spec_keeps_the_batch_cohort_outside_the_file_ranges(phase):
    """Every probed key except the six range keys equals the base (the pre-flight compares them with the cohort)."""
    _, _, base, eff, _ = resolved_cells(phase)[0]
    for key in ("data.train_base", "data.val_base", "eval.base", "data.account_col", "data.order_col", "data.target_col",
                "data.tie_break_col", "data.positive_label", "artifacts.base", "artifacts.version", "predictors.csv_path",
                "predictors.version"):
        assert eff[key] == base[key], key
    assert eff.get("training.ema", False) is False


# -- smoke_checks.py units ---------------------------------------------------------------------------------------------
def rows(*losses, ap=0.05, auroc=0.8):
    """valid_loss as given; train_loss (one batch) moves the other way, so the check is seen to read valid_loss."""
    return [{"epoch": str(i), "step": str(10 * (i + 1)), "train_loss": str(1.0 - v), "valid_loss": str(v), "valid_ap": str(ap),
             "valid_auroc": str(auroc)} for i, v in enumerate(losses)]


def test_loss_check_passes_when_epoch_two_is_below_epoch_one():
    r = sc.loss_check(rows(0.6, 0.4))  # train_loss rises 0.4 -> 0.6: last-batch noise, not judged
    assert r["status"] == "PASS" and r["losses"] == [0.6, 0.4] and r["column"] == "valid_loss"


def test_loss_check_fails_when_the_loss_rises_or_is_flat():
    assert sc.loss_check(rows(0.4, 0.6))["status"] == "FAIL"
    assert "did not fall" in sc.loss_check(rows(0.4, 0.6))["reason"]
    assert sc.loss_check(rows(0.4, 0.4))["status"] == "FAIL"


def test_loss_check_fails_on_one_epoch_missing_file_or_non_finite_loss():
    assert "only one epoch" in sc.loss_check(rows(0.4))["reason"]
    assert sc.loss_check([])["status"] == "FAIL"
    assert sc.loss_check(rows(float("nan"), 0.3))["status"] == "FAIL"
    assert sc.loss_check(rows(0.5, float("inf")))["status"] == "FAIL"


def test_loss_check_prefers_valid_loss_then_train_loss_then_another_training_loss_column():
    assert sc.loss_check(rows(0.6, 0.4))["column"] == "valid_loss"
    r = sc.loss_check([{"epoch": "0", "train_loss": "0.6"}, {"epoch": "1", "train_loss": "0.4"}])
    assert r["column"] == "train_loss" and r["status"] == "PASS"
    r = sc.loss_check([{"epoch": "0", "train_bce_loss": "0.6"}, {"epoch": "1", "train_bce_loss": "0.4"}])
    assert r["column"] == "train_bce_loss" and r["status"] == "PASS"
    assert sc.loss_check([{"epoch": "0", "valid_ap": "0.1"}, {"epoch": "1", "valid_ap": "0.2"}])["status"] == "FAIL"


def test_metric_sanity_definition():
    assert sc.metric_sanity(0.05, 0.8, 0.01) == ("PASS", [])
    assert sc.metric_sanity(float("nan"), 0.8, 0.01)[0] == "FAIL"
    assert sc.metric_sanity(None, 0.8, 0.01)[0] == "FAIL"
    assert sc.metric_sanity(0.0, 0.8, 0.01)[0] == "FAIL"  # not strictly inside (0, 1)
    assert sc.metric_sanity(0.5, 1.0, 0.01)[0] == "FAIL"
    assert sc.metric_sanity(0.005, 0.8, 0.01)[0] == "FAIL"  # not above the positive rate
    assert sc.metric_sanity(0.01, 0.8, 0.01)[0] == "FAIL"  # equal is not above
    assert sc.metric_sanity(0.05, 0.8, None)[0] == "UNKNOWN"


def judge(windows, times, accts=None, rule="strict"):
    accts = accts or {k: "a" for k in times}
    return sc.judge_windows(windows, times, accts, rule)


def test_window_with_an_equal_time_row_fails_strict_and_passes_tiebreak():
    times = {0: 100, 1: 200, 2: 200}  # rows 1 and 2 share a time; 2 is the target
    windows = {2: [0, 1]}
    strict = judge(windows, times, rule="strict")
    assert (strict["status"], strict["time_violations"], strict["history_rows"]) == ("FAIL", 1, 2)
    tiebreak = judge(windows, times, rule="tiebreak")
    assert (tiebreak["status"], tiebreak["time_violations"]) == ("PASS", 0)


def test_window_with_a_future_row_fails_under_both_rules():
    times = {0: 100, 1: 300, 2: 200}
    for rule in ("strict", "tiebreak"):
        assert judge({2: [0, 1]}, times, rule=rule)["time_violations"] == 1


def test_window_containing_the_target_fails():
    times = {0: 100, 1: 150, 2: 200}
    r = judge({2: [0, 2]}, times, rule="tiebreak")
    assert r["status"] == "FAIL" and r["target_in_history"] == 1 and r["time_violations"] == 0


def test_window_with_a_row_of_another_account_fails_and_no_window_fails():
    times = {0: 100, 1: 150, 2: 200}
    r = judge({2: [0, 1]}, times, accts={0: "a", 1: "b", 2: "a"})
    assert r["status"] == "FAIL" and r["other_account"] == 1
    assert judge({}, times)["status"] == "FAIL"
    with pytest.raises(ValueError):
        judge({2: [0]}, times, rule="latest")


def test_clean_windows_pass():
    times = {0: 100, 1: 150, 2: 200, 3: 50}
    r = judge({2: [0, 1], 1: [3, 0]}, times)
    assert r == {"windows": 2, "history_rows": 4, "time_violations": 0, "target_in_history": 0, "other_account": 0, "status": "PASS"}


def test_memory_records_are_read_not_recomputed(tmp_path):
    assert sc.host_peak(str(tmp_path))[0] is None and sc.gpu_peak(str(tmp_path))[0] is None
    (tmp_path / "host_rss_sweep.csv").write_text("timestamp_utc,rss_mib_process_tree,processes\n"
                                                 "2026-10-11T00:00:00Z,1200.5,3\n2026-10-11T00:00:30Z,,\n2026-10-11T00:01:00Z,1800.0,4\n")
    peak, n, src = sc.host_peak(str(tmp_path))
    assert (peak, n) == (1800.0, 2) and "ST13" in src and "(2 sample(s), runner process tree)" in src
    (tmp_path / "gpu_sweep.csv").write_text("timestamp, memory.used [MiB], utilization.gpu [%]\n"
                                            "2026/10/11 00:00:00.000, 5000 MiB, 90 %\n2026/10/11 00:00:30.000, 7000 MiB, 95 %\n")
    peak, n, src = sc.gpu_peak(str(tmp_path))
    assert (peak, n) == (7000.0, 2) and "2 readings over all GPUs (one line per GPU every 30 s)" in src


def test_positive_rate_from_preflight_matches_the_cells_file(tmp_path):
    cfg = OmegaConf.create({"data": {"val_start": 4950, "val_end": 4950}})
    contract = {"train_1_10": {"files": [{"file": "part_1.parquet", "rows": 10, "positives": 1}]},
                "valid_4950_4954": {"files": [{"file": "part_4950.parquet", "rows": 2000, "positives": 6},
                                              {"file": "part_4951.parquet", "rows": 1000, "positives": 100}]}}
    (tmp_path / "data_contract.json").write_text(json.dumps(contract))
    rate, src = sc.positive_rate_from_preflight(str(tmp_path), cfg)
    assert rate == pytest.approx(0.003) and "part_4950.parquet" in src and "6 positives" in src
    cfg2 = OmegaConf.create({"data": {"val_start": 4952, "val_end": 4952}})  # not in the contract
    assert sc.positive_rate_from_preflight(str(tmp_path), cfg2) == (None, None)
    assert sc.positive_rate_from_preflight(None, cfg) == (None, None)
    assert sc.positive_rate_from_preflight(str(tmp_path / "missing"), cfg) == (None, None)


# -- synthetic attempt folders and main() ----------------------------------------------------------------------------
PHASE_SPEC = {"phase4a": "ft_decisions_smoke.yaml", "phase4b": "ft_decisions_hier_smoke.yaml"}


def make_attempt(tmp, phase, losses=(0.6, 0.4), ap=0.05, auroc=0.8, status="ok", results="one", metrics=True,
                 host=False, gpu=False, history_time_order=None):
    """An attempt folder as run_ablations.py and run_step.py leave it, for the smoke spec of the phase."""
    spec_path = ROOT / "YOUR_PACKAGE" / phase / "configs" / PHASE_SPEC[phase]
    att = tmp / phase / "ablations" / "smoke_h5" / "20261011T000000Z-abc"
    run = att / "smoke-h5"
    run.mkdir(parents=True)
    spec = OmegaConf.load(spec_path)
    spec.output_root = str(att.parent)
    OmegaConf.save(spec, att / "ablation_spec.yaml")
    base = OmegaConf.load(ROOT / str(spec.base_config))
    eff = OmegaConf.merge(base, OmegaConf.from_dotlist([str(o) for o in spec.common_overrides] + ["training.max_epochs=2"]))
    if history_time_order is not None:
        eff.sequence.history_time_order = history_time_order
    OmegaConf.save(eff, run / "resolved_train.yaml")
    (run / "run_summary.txt").write_text("RUN SUMMARY -- smoke-h5\n")
    if metrics:
        with open(run / "training_metrics.csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["epoch", "step", "train_loss", "train_loss_step", "valid_loss", "valid_ap", "valid_auroc"])
            w.writeheader()
            for i, v in enumerate(losses):
                w.writerow({"epoch": i, "step": 10 * (i + 1), "train_loss": 2 * v, "train_loss_step": 2 * v, "valid_loss": v,
                            "valid_ap": ap if i == len(losses) - 1 else 0.02, "valid_auroc": auroc if i == len(losses) - 1 else 0.6})
    cols = ["run_name", "smoke", "train_rc", "best_valid_ap", "best_valid_auroc", "eval_ap", "eval_auroc", "attempt",
            "run_dir", "score_rc", "status", "checkpoint_epoch", "checkpoint_step", "error"]
    row = {"run_name": "smoke-h5", "smoke": "h5", "train_rc": 0 if status == "ok" else 1, "best_valid_ap": ap,
           "best_valid_auroc": auroc, "eval_ap": "", "eval_auroc": "", "attempt": att.name, "run_dir": str(run),
           "score_rc": "", "status": status, "checkpoint_epoch": len(losses) - 1, "checkpoint_step": 10 * len(losses), "error": ""}
    if results != "missing":
        with open(att / "results.csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=cols)
            w.writeheader()
            if results in ("one", "two"):
                w.writerow(row)
            if results == "two":
                w.writerow(row)
    if host:
        (att / "host_rss_sweep.csv").write_text("timestamp_utc,rss_mib_process_tree,processes\n2026-10-11T00:00:00Z,1024.0,3\n"
                                                 "2026-10-11T00:00:01Z,2048.0,3\n")
    if gpu:
        (att / "gpu_sweep.csv").write_text("timestamp, memory.used [MiB], utilization.gpu [%]\n2026/10/11 00:00:00.000, 9000 MiB, 90 %\n")
    return att


def clean_windows(cfg, phase, samples, seed):
    return {"status": "PASS", "reason": "", "rule": str(cfg.sequence.get("history_time_order", "tiebreak")), "rule_source": "stub",
            "requested": samples, "sampled": samples, "windows": samples, "history_rows": 4 * samples, "time_violations": 0,
            "target_in_history": 0, "other_account": 0, "not_windowed": 0, "rows": 5000, "positives": 10, "seed": seed, "files": 1,
            "tied_rows": 100, "tied_sampled": samples // 2}


def run_main(tmp, attempts, monkeypatch, windows=clean_windows, preflight=None, result="PASS"):
    monkeypatch.setattr(sc, "window_check", windows)
    out = tmp / "return"
    argv = ["--out", str(out), "--preflight-result", result, "--interpreter", "/opt/env/bin/python3"]
    if preflight:
        argv += ["--preflight", str(preflight)]
    for phase, att in attempts:
        argv += ["--cell", phase, PHASE_SPEC[phase], str(att) if att is not None else "-"]
    rc = sc.main(argv)
    text = (out / "SMOKE_RETURN.txt").read_text()
    return rc, text, out


def test_passing_pair_gives_result_pass_and_copies_the_aggregates(tmp_path, monkeypatch):
    a = make_attempt(tmp_path, "phase4a", host=True, gpu=True)
    b = make_attempt(tmp_path, "phase4b", losses=(0.7, 0.5), host=True, gpu=True)
    rc, text, out = run_main(tmp_path, [("phase4a", a), ("phase4b", b)], monkeypatch)
    assert rc == 0
    assert text.rstrip().splitlines()[-1] == "RESULT: PASS"
    assert not [l for l in text.splitlines() if l.startswith(("FAILED:", "UNKNOWN", "FAIL "))]
    assert ("validation loss per epoch (valid_loss, the mean over the whole validation file): epoch 1 0.6000, epoch 2 0.4000"
            in text)
    assert ("training loss of the last batch before each validation (train_loss, one batch, for information): "
            "epoch 1 1.2000, epoch 2 0.8000") in text
    assert "loss falls from epoch 1 to epoch 2: yes -> PASS" in text
    assert "peak host RSS: 2,048 MiB (source: ST13 host samples" in text
    assert "peak GPU memory: 9,000 MiB (source: gpu_sweep.csv" in text
    assert "counted from the validation file(s) read for the window check: 10 positives in 5,000 rows" in text
    assert "runtime: not measured" in text and "interpreter (smoke.sh): /opt/env/bin/python3" in text
    assert "10 of them share their account and time with another row (the file has 100 such rows)" in text
    for stem in ("ft_decisions_smoke", "ft_decisions_hier_smoke"):
        assert (out / stem / "training_metrics.csv").is_file() and (out / stem / "run_summary.txt").is_file()
    assert "spec sha256: " in text and "base config sha256: " in text and "resolved config sha256: " in text
    # Nothing raw: no account id, no transaction id, no data value beyond metrics and counts.
    assert "A000" not in text and "fi_transaction_id" not in text


def test_rising_loss_fails_with_a_plain_line(tmp_path, monkeypatch):
    a = make_attempt(tmp_path, "phase4a", losses=(0.4, 0.6))
    b = make_attempt(tmp_path, "phase4b")
    rc, text, _ = run_main(tmp_path, [("phase4a", a), ("phase4b", b)], monkeypatch)
    assert rc == 1 and text.rstrip().splitlines()[-1] == "RESULT: FAIL"
    assert "FAILED: cell A (phase4a/ft_decisions_smoke.yaml): the loss (valid_loss) did not fall: epoch 1 0.400000, epoch 2 0.600000" in text
    assert text.count("FAILED:") == 1


def test_non_finite_ap_fails(tmp_path, monkeypatch):
    a = make_attempt(tmp_path, "phase4a", ap="nan")
    rc, text, _ = run_main(tmp_path, [("phase4a", a)], monkeypatch)
    assert rc == 1 and "FAILED: cell A (phase4a/ft_decisions_smoke.yaml): valid_ap is missing or not a finite number" in text


def test_ap_at_or_below_the_positive_rate_fails(tmp_path, monkeypatch):
    a = make_attempt(tmp_path, "phase4a", ap=0.002)  # the stub window check counts 10 positives in 5000 rows
    rc, text, _ = run_main(tmp_path, [("phase4a", a)], monkeypatch)
    assert rc == 1 and "is not above the validation file's positive rate 0.002000" in text


def test_positive_rate_comes_from_the_preflight_when_it_holds_the_file(tmp_path, monkeypatch):
    pf = tmp_path / "preflight" / "20261011T000000Z"
    pf.mkdir(parents=True)
    (pf / "data_contract.json").write_text(json.dumps({"valid_4950_4954": {"files": [
        {"file": "part_4950.parquet", "rows": 10000, "positives": 30}]}}))
    a = make_attempt(tmp_path, "phase4a")
    rc, text, _ = run_main(tmp_path, [("phase4a", a)], monkeypatch, preflight=pf)
    assert rc == 0 and "positive rate of the validation file: 0.003000 (source: pre-flight 20261011T000000Z data_contract.json" in text


def test_missing_attempt_and_preflight_failure_are_recorded_and_fail(tmp_path, monkeypatch):
    rc, text, out = run_main(tmp_path, [("phase4a", None), ("phase4b", None)], monkeypatch, result="FAIL (pre-flight exit 1)")
    assert rc == 1 and (out / "SMOKE_RETURN.txt").is_file()
    assert "FAILED: the pre-flight did not pass (result FAIL (pre-flight exit 1)); nothing was trained" in text
    assert sum(l.startswith("FAILED: cell") and "no attempt folder was created" in l for l in text.splitlines()) == 2
    assert text.rstrip().splitlines()[-1] == "RESULT: FAIL"


def test_runner_failure_status_missing_results_and_missing_metrics_fail_but_report_what_exists(tmp_path, monkeypatch):
    a = make_attempt(tmp_path, "phase4a", status="train_failed")
    rc, text, _ = run_main(tmp_path, [("phase4a", a)], monkeypatch)
    assert rc == 1 and "the runner reported status train_failed" in text
    b = make_attempt(tmp_path / "b", "phase4b", results="missing")
    rc, text, _ = run_main(tmp_path / "b", [("phase4b", b)], monkeypatch)
    assert rc == 1 and "the run has no results row (training did not finish)" in text
    assert "resolved config sha256" in text  # what exists is still reported
    c = make_attempt(tmp_path / "c", "phase4a", metrics=False)
    rc, text, _ = run_main(tmp_path / "c", [("phase4a", c)], monkeypatch)
    assert rc == 1 and "no epoch was recorded" in text
    d = make_attempt(tmp_path / "d", "phase4a", results="two")
    rc, text, _ = run_main(tmp_path / "d", [("phase4a", d)], monkeypatch)
    assert rc == 1 and "results.csv has 2 rows for a one-cell spec" in text


def test_window_check_failure_and_crash_are_fail_lines(tmp_path, monkeypatch):
    a = make_attempt(tmp_path, "phase4a")

    def leaking(cfg, phase, samples, seed):
        r = clean_windows(cfg, phase, samples, seed)
        r.update(status="FAIL", time_violations=3, reason="3 history row(s) not strictly before the target's time, 0 history row(s) equal to the target, 0 from another account")
        return r
    rc, text, _ = run_main(tmp_path, [("phase4a", a)], monkeypatch, windows=leaking)
    assert rc == 1 and "FAILED: cell A (phase4a/ft_decisions_smoke.yaml): 3 history row(s) not strictly before" in text

    def crashing(cfg, phase, samples, seed):
        raise RuntimeError("account A0000001 at 2025-01-01")  # never reaches the return
    rc, text, _ = run_main(tmp_path / "x", [("phase4a", make_attempt(tmp_path / "x", "phase4a"))], monkeypatch, windows=crashing)
    assert rc == 1 and "the window check could not run (RuntimeError; details in the console only)" in text
    assert "A0000001" not in text


def test_memory_unknown_is_recorded_and_does_not_fail(tmp_path, monkeypatch):
    a = make_attempt(tmp_path, "phase4a")  # no host or GPU record
    rc, text, _ = run_main(tmp_path, [("phase4a", a)], monkeypatch)
    assert rc == 0 and "RESULT: PASS" in text
    assert "UNKNOWN cell A (phase4a/ft_decisions_smoke.yaml): peak host RSS unknown" in text
    assert "UNKNOWN cell A (phase4a/ft_decisions_smoke.yaml): peak GPU memory unknown" in text
    assert "2 UNKNOWN (unknown items are recorded, not judged)" in text
    # F4: a cell that ends inside one sampling interval leaves only its launch sample: UNKNOWN, not PASS.
    b = make_attempt(tmp_path / "one", "phase4a", gpu=True)
    (b / "host_rss_sweep.csv").write_text("timestamp_utc,rss_mib_process_tree,processes\n2026-10-11T00:00:00Z,4.7,1\n,,\n")
    rc, text, _ = run_main(tmp_path / "one", [("phase4a", b)], monkeypatch)
    assert rc == 0 and "UNKNOWN cell A (phase4a/ft_decisions_smoke.yaml): peak host RSS unknown: only the launch sample (5 MiB)" in text
    assert "peak host RSS 5 MiB recorded" not in text


# -- the real window rebuild with the owned builders on synthetic data -------------------------------------------------
ARTIFACT_BASE = "s3://ARTIFACT_BUCKET/YOUR_ID/tabular_fraud/artifacts"
RAW_BASE = "s3://DATA_BUCKET/tfm_raw_data"


def synthetic_cell(tmp_path, monkeypatch, phase, accounts=60, seed=3):
    """A synthetic validation file (the real raw schema) with same-time rows, artifacts fitted on it, and the smoke
    cell's resolved config pointing at them through the fake S3 folder."""
    root = tmp_path / "s3"
    root.mkdir()
    fs = DirFileSystem(path=str(root), fs=LocalFileSystem(auto_mkdir=True))
    monkeypatch.setattr(s3_utils, "make_s3_filesystem", lambda *a, **k: fs)
    rng = np.random.default_rng(seed)
    df = synth.make_file(rng, accounts, 1_735_689_600, "valid4950", 0, 25.0)
    # Same-time rows: duplicate the time of each account's second row onto its third row where there is one.
    acct_col, t_col = "Nmap_account_reference_xid", "transaction_dttm"
    df = df.sort_values([acct_col, t_col, "fi_transaction_id"], kind="stable").reset_index(drop=True)
    third = df.groupby(acct_col).cumcount() == 2
    second = df.groupby(acct_col).cumcount() == 1
    t_second = df.loc[second, [acct_col, t_col]].set_index(acct_col)[t_col]
    df.loc[third, t_col] = df.loc[third, acct_col].map(t_second).values
    assert df.duplicated([acct_col, t_col], keep=False).sum() > 0
    raw = root / "DATA_BUCKET" / "tfm_raw_data"
    raw.mkdir(parents=True)
    df.to_parquet(raw / "part_4950.parquet", index=False)
    features = load_feature_list(str(ROOT / "fraud/configs/predictors.csv"))
    art = PreprocessingArtifacts(artifact_version=1)
    for c in features.continuous:
        art.fit_feature(c, df[c], "continuous")
    for c in features.categorical:
        if c in df.columns:
            art.fit_feature(c, df[c], "categorical")
        else:  # derived datetime fields: fit on the derived values
            from fraud.data.datetime_features import DatetimeConfig, derive_datetime_features
            d2, _, _ = derive_datetime_features(df.assign(**{t_col: pd.to_datetime(df[t_col])}),
                                                DatetimeConfig(order_col=t_col, fields=["month", "day", "hour", "day_of_week"],
                                                               encoding="categorical", is_weekend=False))
            art.fit_feature(c, d2[c], "categorical")
    art.save(f"{ARTIFACT_BASE}/1", filesystem=fs)
    spec = OmegaConf.load(ROOT / "YOUR_PACKAGE" / phase / "configs" / PHASE_SPEC[phase])
    base = OmegaConf.load(ROOT / str(spec.base_config))
    cfg = OmegaConf.merge(base, OmegaConf.from_dotlist([str(o) for o in spec.common_overrides] + ["training.max_epochs=2"]))
    cfg.predictors.csv_path = str(ROOT / "fraud/configs/predictors.csv")
    return cfg, df


def builder_has_rule(phase):
    mod = importlib.import_module(f"YOUR_PACKAGE.{phase}.sequence_builder")
    return "history_time_order" in inspect.signature(mod.SequenceBuilder.__init__).parameters


@pytest.mark.parametrize("phase", sorted(SPECS))
def test_window_check_rebuilds_twenty_targets_with_the_owned_builder(tmp_path, monkeypatch, phase):
    cfg, df = synthetic_cell(tmp_path, monkeypatch, phase)
    if builder_has_rule(phase):
        rules = ("strict", "tiebreak")
    else:
        rules = ("tiebreak",)
        cfg.sequence.pop("history_time_order", None)
    for rule in rules:
        if builder_has_rule(phase):
            cfg.sequence.history_time_order = rule
        r = sc.window_check(cfg, phase, samples=20, seed=7)
        assert r["status"] == "PASS", r
        assert r["rule"] == rule and r["windows"] == 20 and r["sampled"] == 20 and r["not_windowed"] == 0
        assert r["rows"] == len(df) and r["positives"] == int(df["frd_tag"].sum()) and r["files"] == 1
        assert r["history_rows"] > 0 and r["time_violations"] == 0 and r["target_in_history"] == 0


@pytest.mark.parametrize("phase", sorted(SPECS))
def test_window_check_detects_a_builder_that_leaks_the_future(tmp_path, monkeypatch, phase):
    """If the owned builder ordered an account's rows backwards, every history row would be in the target's future and
    the check must say so (the check reads the builder's windows, so a wrong builder cannot pass)."""
    cfg, _ = synthetic_cell(tmp_path, monkeypatch, phase)
    if not builder_has_rule(phase):
        cfg.sequence.pop("history_time_order", None)
    mod = importlib.import_module(f"YOUR_PACKAGE.{phase}.sequence_builder")
    original = mod.SequenceBuilder._account_groups

    def reversed_groups(self, df):
        return {a: list(reversed(rows)) for a, rows in original(self, df).items()}
    monkeypatch.setattr(mod.SequenceBuilder, "_account_groups", reversed_groups)
    r = sc.window_check(cfg, phase, samples=20, seed=7)
    assert r["status"] == "FAIL" and r["time_violations"] > 0 and "not" in r["reason"]


@pytest.mark.parametrize("phase", sorted(SPECS))
def test_window_check_detects_the_target_in_its_own_history(tmp_path, monkeypatch, phase):
    cfg, _ = synthetic_cell(tmp_path, monkeypatch, phase)
    if not builder_has_rule(phase):
        cfg.sequence.pop("history_time_order", None)
    mod = importlib.import_module(f"YOUR_PACKAGE.{phase}.sequence_builder")
    original = mod.SequenceBuilder._windows_for_file

    def target_in_history(self, cont, cat, target, times, df, meta):
        for w in original(self, cont, cat, target, times, df, meta):
            w_cat, w_mask = w[1], w[2]
            if w_mask[-1] and self.history_len > 0:
                w_cat[-2] = w_cat[-1]
                w_mask[-2] = True
            yield w
    monkeypatch.setattr(mod.SequenceBuilder, "_windows_for_file", target_in_history)
    r = sc.window_check(cfg, phase, samples=20, seed=7)
    assert r["status"] == "FAIL" and r["target_in_history"] == 20


@pytest.mark.parametrize("phase", sorted(SPECS))
def test_window_check_always_samples_same_time_targets_and_catches_a_tiebreak_builder(tmp_path, monkeypatch, phase):
    """F2: half the targets are same-account equal-time rows, so a builder configured strict that behaves like
    tie-break fails at the production seed (a uniform sample of 20 can miss every such row)."""
    cfg, df = synthetic_cell(tmp_path, monkeypatch, phase)
    tied = int(df.duplicated(["Nmap_account_reference_xid", "transaction_dttm"], keep=False).sum())
    if not builder_has_rule(phase):  # this folder's builder knows only the tie-break order
        cfg.sequence.pop("history_time_order", None)
    else:
        cfg.sequence.history_time_order = "strict"
    r = sc.window_check(cfg, phase, samples=20, seed=sc.SEED)
    assert r["status"] == "PASS" and r["tied_sampled"] == 10 and r["tied_rows"] == tied, r
    if not builder_has_rule(phase):
        return
    mod = importlib.import_module(f"YOUR_PACKAGE.{phase}.sequence_builder")
    original = mod.SequenceBuilder._windows_for_file

    def tiebreak_windows(self, cont, cat, target, times, df, meta):
        self.history_time_order = "tiebreak"
        yield from original(self, cont, cat, target, times, df, meta)
    monkeypatch.setattr(mod.SequenceBuilder, "_windows_for_file", tiebreak_windows)
    r = sc.window_check(cfg, phase, samples=20, seed=sc.SEED)
    assert r["status"] == "FAIL" and r["time_violations"] > 0 and r["tied_sampled"] == 10, r


def test_effective_rule_follows_the_builder_option():
    class WithOption:
        def __init__(self, history_time_order="strict"):
            pass

    class Without:
        def __init__(self):
            pass
    assert sc.effective_rule(OmegaConf.create({"sequence": {"history_time_order": "tiebreak"}}), WithOption)[0] == "tiebreak"
    rule, source, problem = sc.effective_rule(OmegaConf.create({"sequence": {}}), WithOption)
    assert rule == "strict" and "default" in source and problem is None
    rule, source, problem = sc.effective_rule(OmegaConf.create({"sequence": {}}), Without)
    assert rule == "tiebreak" and problem is None
    rule, source, problem = sc.effective_rule(OmegaConf.create({"sequence": {"history_time_order": "strict"}}), Without)
    assert rule == "strict" and "not implemented" in problem


@pytest.mark.parametrize("phase", sorted(SPECS))
def test_strict_rule_without_a_strict_builder_is_a_fail_not_a_silent_tiebreak(tmp_path, monkeypatch, phase):
    if builder_has_rule(phase):
        pytest.skip("the builder in this folder implements history_time_order")
    cfg, _ = synthetic_cell(tmp_path, monkeypatch, phase)
    cfg.sequence.history_time_order = "strict"
    r = sc.window_check(cfg, phase, samples=20, seed=7)
    assert r["status"] == "FAIL" and "not implemented" in r["reason"]


# -- smoke.sh: the shell contract with a stub pre-flight and a stub runner ----------------------------------------------
STUB_PREFLIGHT = r'''#!/usr/bin/env python3
import os, sys, json, time
root = sys.argv[sys.argv.index("--out-root") + 1]
mode = os.environ.get("STUB_PREFLIGHT", "pass")
if mode == "nodir": sys.exit(2)  # crashed before its folder and its PREFLIGHT_DIR line
out = os.path.join(root, "20261011T000000Z"); os.makedirs(out, exist_ok=True)
lines = ["INFO  pre-flight stub", "PASS  something"]
if mode in ("pass", "nocontract"): lines.append("RESULT PASS | 0 FAIL, 1 WARN | overrides: none | exit 0")
elif mode == "fail": lines.append("RESULT FAIL | 1 FAIL, 0 WARN | overrides: none | exit 1")
open(os.path.join(out, "SUMMARY.txt"), "w").write("\n".join(lines) + "\n")
open(os.path.join(out, "errors.txt"), "w").write("error text\n")
if mode != "nocontract":
    json.dump({"valid_4950_4954": {"files": [{"file": "part_4950.parquet", "rows": 10000, "positives": 30}]}}, open(os.path.join(out, "data_contract.json"), "w"))
print("PREFLIGHT_DIR=" + out)
sys.exit({"pass": 0, "fail": 1, "nocontract": 0, "noline": 0, "crash": 2}[mode])
'''
STUB_RUN_STEP = r'''#!/usr/bin/env python3
import os, sys, shutil
phase = sys.argv[sys.argv.index("--phase") + 1]; spec = sys.argv[sys.argv.index("--spec") + 1]
src = os.environ["STUB_ATTEMPTS"]
att = os.path.join(src, phase, "ablations", "smoke_h5", "20261011T000000Z-abc")
open(os.environ["STUB_CALLS"], "a").write(f"{phase} {spec} {' '.join(sys.argv[1:])}\n")
ret = os.path.join(os.environ["STUB_RETURNS"], spec + "_x"); os.makedirs(ret, exist_ok=True)
open(os.path.join(ret, "RETURN.txt"), "w").write("RETURN stub\nACCEPTED: every run ok\n")
open(os.path.join(ret, "best.ckpt"), "w").write("a checkpoint stays on the pod (OQ-24)\n")
open(os.path.join(ret, "big.csv"), "w").write("x" * (2 << 20))  # 2 MiB: copied, there is no size cap (OWNER_QA twenty-sixth)
open(os.path.join(ret, "notes.log"), "w").write("any other file of the step return is copied\n")
runs = os.path.dirname(os.path.dirname(ret)); name = os.path.basename(ret)
os.makedirs(os.path.join(runs, "logs"), exist_ok=True); os.makedirs(os.path.join(runs, "gpu"), exist_ok=True)
open(os.path.join(runs, "logs", name + ".runner.log"), "w").write("Traceback: the trainer's own output\n")
open(os.path.join(runs, "gpu", name + ".host_rss.csv"), "w").write("utc,rss_mib\n")
if os.environ.get("STUB_NO_ATTEMPT"):  # the trainer stopped before creating an attempt folder (run_step.py's own path)
    print("RETURN_DIR=" + ret); print("ATTEMPT_DIR="); sys.exit(2)
print("RETURN_DIR=" + ret); print("ATTEMPT_DIR=" + att)
'''
STUB_CHECKS = '''#!/usr/bin/env python3
import importlib.util, sys
s = importlib.util.spec_from_file_location("real_checks", {real!r}); m = importlib.util.module_from_spec(s); s.loader.exec_module(m)
def clean(cfg, phase, samples, seed):
    return {{"status": "PASS", "reason": "", "rule": "tiebreak", "rule_source": "stub", "requested": samples, "sampled": samples,
            "windows": samples, "history_rows": 80, "time_violations": 0, "target_in_history": 0, "other_account": 0,
            "not_windowed": 0, "rows": 5000, "positives": 10, "seed": seed, "files": 1, "tied_rows": 100, "tied_sampled": samples // 2}}
m.window_check = clean
sys.exit(m.main())
'''


def shell_layout(tmp_path):
    """A repository layout with smoke.sh, the real smoke_checks.py (window check stubbed), a stub pre-flight, a stub
    runner and the spec and base config files (for the digests)."""
    repo = tmp_path / "repo"
    rb = repo / "runbook" / "2026-10-07"
    rb.mkdir(parents=True)
    shutil.copyfile(HERE / "smoke.sh", rb / "smoke.sh")
    (rb / "smoke_checks.py").write_text(STUB_CHECKS.format(real=str(HERE / "smoke_checks.py")))
    (rb / "preflight_pod.py").write_text(STUB_PREFLIGHT)
    (rb / "run_step.py").write_text(STUB_RUN_STEP)
    for phase, (spec, base) in SPECS.items():
        (repo / "YOUR_PACKAGE" / phase / "configs").mkdir(parents=True)
        shutil.copyfile(ROOT / "YOUR_PACKAGE" / phase / "configs" / spec, repo / "YOUR_PACKAGE" / phase / "configs" / spec)
        shutil.copyfile(ROOT / base, repo / base)
    attempts = tmp_path / "attempts"
    for phase in SPECS:
        make_attempt(attempts, phase, host=True, gpu=True)
    for phase in SPECS:  # a checkpoint and a prediction file in the attempt: both stay on the pod (OQ-24)
        run = attempts / phase / "ablations" / "smoke_h5" / "20261011T000000Z-abc" / "smoke-h5"
        (run / "best.ckpt").write_text("checkpoint\n")
        (run / "predictions").mkdir()
        (run / "predictions" / "part_4950.parquet").write_text("rows\n")
        (run / "train.log").write_text("trainer log\n")
    returns = tmp_path / "runs" / "returns"
    returns.mkdir(parents=True)
    return repo


def run_smoke(repo, tmp_path, env_extra=None, cwd=None):
    env = {k: v for k, v in os.environ.items() if k not in ("RUNBOOK_SANDBOX", "BATCH1_SKIP", "PREFLIGHT_ARGS",
                                                           "A_H10_COMPARATOR", "RUNBOOK_BANK_OVERRIDES")}
    env.update({"PYTHON": sys.executable, "STUB_ATTEMPTS": str(tmp_path / "attempts"), "STUB_CALLS": str(tmp_path / "calls.txt"),
                "STUB_RETURNS": str(tmp_path / "runs" / "returns"), "PYTHONPATH": os.pathsep.join([str(ROOT / "src"), str(ROOT)])})
    env.update(env_extra or {})
    p = subprocess.run(["bash", str(repo / "runbook" / "2026-10-07" / "smoke.sh")], cwd=cwd or str(tmp_path),
                       env=env, capture_output=True, text=True)
    calls = (tmp_path / "calls.txt").read_text() if (tmp_path / "calls.txt").exists() else ""
    folders = sorted((repo / "runs" / "returns").glob("smoke_*")) if (repo / "runs" / "returns").is_dir() else []
    return p, calls, folders


def test_smoke_sh_runs_both_cells_after_result_pass_and_writes_the_return(tmp_path):
    repo = shell_layout(tmp_path)
    p, calls, folders = run_smoke(repo, tmp_path)
    assert p.returncode == 0, p.stdout + p.stderr
    assert calls.splitlines() == [
        "phase4a ft_decisions_smoke.yaml --phase phase4a --spec ft_decisions_smoke.yaml --preflight runs/preflight/20261011T000000Z",
        "phase4b ft_decisions_hier_smoke.yaml --phase phase4b --spec ft_decisions_hier_smoke.yaml --preflight runs/preflight/20261011T000000Z"]
    assert len(folders) == 1
    out = folders[0]
    text = (out / "SMOKE_RETURN.txt").read_text()
    assert text.rstrip().splitlines()[-1] == "RESULT: PASS"
    assert "result read by smoke.sh: PASS" in text and f"interpreter (smoke.sh): {sys.executable}" in text
    assert "positive rate of the validation file: 0.003000 (source: pre-flight 20261011T000000Z" in text
    assert (out / "preflight_20261011T000000Z" / "SUMMARY.txt").is_file()
    assert (out / "preflight_20261011T000000Z" / "errors.txt").is_file()  # OWNER_QA twenty-sixth: every file is sent
    assert (out / "steps" / "ft_decisions_smoke.yaml_x" / "RETURN.txt").is_file()
    step = out / "steps" / "ft_decisions_smoke.yaml_x"  # OWNER_QA twenty-sixth: every file of the step is sent
    assert (step / "big.csv").stat().st_size == 2 << 20 and (step / "notes.log").is_file()
    assert (step / "ft_decisions_smoke.yaml_x.runner.log").read_text().startswith("Traceback")
    assert (step / "ft_decisions_smoke.yaml_x.host_rss.csv").is_file()
    att = out / "attempts" / "20261011T000000Z-abc"
    assert (att / "results.csv").is_file() and (att / "smoke-h5" / "train.log").is_file()
    assert (att / "smoke-h5" / "resolved_train.yaml").is_file()
    assert not list(out.rglob("*.ckpt")) and not list(out.rglob("*.parquet"))  # stay on the pod (OQ-24)
    assert (out / "ft_decisions_smoke" / "training_metrics.csv").is_file()
    status = (out / "SMOKE_STATUS.txt").read_text()
    assert "smoke started" in status and "finished ft_decisions_hier_smoke.yaml" in status and "smoke_checks exit 0" in status
    assert "Smoke finished: RESULT: PASS" in p.stdout


def test_smoke_sh_sends_the_runner_log_when_the_trainer_stops_before_an_attempt(tmp_path):
    """reviewer 6130441861: run_step.py tells the owner to see the runner log when no attempt folder exists, so the smoke
    return must carry that log (OWNER_QA twenty-sixth: every file is sent)."""
    repo = shell_layout(tmp_path)
    p, calls, folders = run_smoke(repo, tmp_path, {"STUB_NO_ATTEMPT": "1"})
    assert p.returncode == 1 and len(calls.splitlines()) == 2
    out = folders[0]
    for spec in ("ft_decisions_smoke.yaml", "ft_decisions_hier_smoke.yaml"):
        step = out / "steps" / f"{spec}_x"
        assert (step / f"{spec}_x.runner.log").read_text().startswith("Traceback")
        assert (step / "RETURN.txt").is_file() and (step / "notes.log").is_file()
    assert not (out / "attempts").exists()
    assert "RESULT: FAIL" in (out / "SMOKE_RETURN.txt").read_text()


@pytest.mark.parametrize("mode", ["fail", "noline", "nocontract", "crash", "nodir"])
def test_smoke_sh_refuses_without_result_pass_and_still_writes_the_return(tmp_path, mode):
    repo = shell_layout(tmp_path)
    if mode == "nodir":  # an older passing pre-flight folder must not stand in for this one (F4)
        old = repo / "runs" / "preflight" / "20261001T000000Z"
        old.mkdir(parents=True)
        (old / "SUMMARY.txt").write_text("RESULT PASS | 0 FAIL, 0 WARN | overrides: none | exit 0\n")
        (old / "data_contract.json").write_text("{}")
    p, calls, folders = run_smoke(repo, tmp_path, {"STUB_PREFLIGHT": mode})
    assert p.returncode == 1
    assert calls == ""  # the runner was never called
    assert "PRE-FLIGHT FAILED" in p.stdout and "nothing was trained" in p.stdout
    assert len(folders) == 1
    text = (folders[0] / "SMOKE_RETURN.txt").read_text()
    assert text.rstrip().splitlines()[-1] == "RESULT: FAIL"
    assert "FAILED: the pre-flight did not pass" in text
    assert sum(l.startswith("FAILED: cell") and "no attempt folder was created" in l for l in text.splitlines()) == 2
    if mode == "nodir":
        assert not list(folders[0].glob("preflight_*"))
        assert "exit 2, RESULT line missing" in text
    else:
        assert (folders[0] / "preflight_20261011T000000Z" / "SUMMARY.txt").is_file()
    assert "stopped at the pre-flight" in (folders[0] / "SMOKE_STATUS.txt").read_text()


@pytest.mark.parametrize("var", ["RUNBOOK_SANDBOX", "BATCH1_SKIP", "PREFLIGHT_ARGS", "A_H10_COMPARATOR"])
def test_smoke_sh_stops_on_inherited_harness_state_unless_the_bank_flag_is_set(tmp_path, var):
    repo = shell_layout(tmp_path)
    p, calls, folders = run_smoke(repo, tmp_path, {var: "x"})
    assert p.returncode == 1 and calls == "" and folders == []
    assert f"STOPPED BEFORE START: {var} is set" in p.stdout and "Nothing was run" in p.stdout
    # With the flag, the same variable is allowed (the sandbox variable then moves the folders into the sandbox).
    sb = tmp_path / "sb"
    p, calls, folders = run_smoke(repo, tmp_path, {var: str(sb) if var == "RUNBOOK_SANDBOX" else "x", "RUNBOOK_BANK_OVERRIDES": "1"})
    assert p.returncode == 0, p.stdout + p.stderr
    if var == "RUNBOOK_SANDBOX":
        assert folders == [] and list((sb / "returns").glob("smoke_*"))
    else:
        assert len(folders) == 1


def test_smoke_sh_runs_from_any_folder_and_uses_the_python_variable(tmp_path):
    repo = shell_layout(tmp_path)
    p, calls, folders = run_smoke(repo, tmp_path, {"PYTHON": "/nonexistent/python-for-smoke"}, cwd="/")
    assert p.returncode != 0 and calls == ""  # the named interpreter is used, not the default
    p, calls, folders = run_smoke(repo, tmp_path, cwd="/")
    assert p.returncode == 0 and len(calls.splitlines()) == 2
