#!/usr/bin/env python3
# reviewer, 2026-10-11 (first release). Small helpers for batch1.sh and batch2.sh: the comparator validation (RUN-05,
# R-033), the batch's ledger rows for its return folder (RG-F02), and the resume state of a step (R-063).
"""Helpers for the batch scripts. Read-only on attempts and the ledger; writes only into the batch return folder.

  comparator   validate an A-H10 attempt before it is used as the shared comparator, and record it:
      python batch_tools.py comparator --attempt DIR --phase phase4a --spec ft_decisions_flat_h10.yaml
             --ledger runs/run_log.csv --record OUT/SHARED_COMPARATOR.txt --files-out OUT/comparator_source_files.csv
             [--origin own|override|batch1_return] [--batch-preflight DIR] [--used-by TEXT] [--spec-file PATH]
      --spec-file names the spec file to check against (default YOUR_PACKAGE/<phase>/configs/<spec>; the sandbox passes the
      reduced copy it trained on).
      Exit 0 only when every check holds: the attempt folder exists and is an attempt of that spec (same base config,
      run names and scoring), every expected run has a run_log row with status ok, the run's source digest equals the
      digest of this checkout's runtime files, per .py file the run's hash equals this checkout's and this checkout's
      LF-normalized hash equals the release manifest (github_source_manifest.csv), the run's data range, artifacts version and other
      comparison-critical settings equal those of the spec in this checkout, the run's whole resolved_train.yaml equals
      the spec's resolved configuration (output and experiment keys aside), and a scored run was checked against a
      pre-flight cohort. The record names the checks that failed in plain words; the per-file hash set is written to
      --files-out so the batch 2 release can compare a named file set instead (RG-F01).
  ledger-rows  copy the batch's own rows out of the ledger:
      python batch_tools.py ledger-rows --ledger runs/run_log.csv --out OUT/run_log_batch.csv ATTEMPT [ATTEMPT ...]
  resume-state what a batch return folder already holds for one spec:
      python batch_tools.py resume-state --batch-dir OUT --spec ft_decisions_h0.yaml
      prints "finished_ok <step folder>" for a step whose RETURN.txt says ACCEPTED, "interrupted <attempt dir> <step
      folder>" for a step that started, recorded its attempt folder and never finished (and was not yet collected),
      else nothing.
"""
import argparse
import csv
import hashlib
import importlib.util
import json
import os
import sys
import tempfile

from omegaconf import OmegaConf

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
IDENTITY_COLS = ["history_len", "seed", "batch_x_accum", "train_files", "val_files", "eval_files", "embedding",
                 "mask", "optimizer", "time_delta", "model", "artifacts"]


def load_module(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return m


def collector():
    return load_module("batch_tools_collector", os.path.join(HERE, "collect_returns.py"))


def runner(phase):
    return load_module(f"batch_tools_runner_{phase}", os.path.join(ROOT, "YOUR_PACKAGE", phase, "scripts", "run_ablations.py"))


def release_manifest():
    """{path: sha256 of LF-normalized content} from the reviewed manifest, and the manifest file's own digest."""
    path = os.path.join(HERE, "github_source_manifest.csv")
    with open(path, "rb") as f:
        raw = f.read()
    rows = list(csv.DictReader(raw.decode().splitlines()))
    return {r["path"]: r["sha256_lf"] for r in rows}, hashlib.sha256(raw).hexdigest()


def spec_effective(phase, spec_name, run_name, spec_file=None):
    """The resolved training configuration of one run of a spec in this checkout, built as the runner builds it."""
    r = runner(phase)
    spec = OmegaConf.load(spec_file or os.path.join(ROOT, "YOUR_PACKAGE", phase, "configs", spec_name))
    base = OmegaConf.load(os.path.join(ROOT, str(spec.base_config)))
    common = [str(o) for o in spec.get("common_overrides", [])]
    for name, overrides, _ in r._expand_runs(spec)[1]:
        if name == run_name:
            effective = OmegaConf.merge(base, OmegaConf.from_dotlist(common + overrides + [
                "output.checkpoint_dir=/identity/attempt/run", "experiment.run_name=identity"]))
            return OmegaConf.create(OmegaConf.to_container(effective, resolve=True))
    return None


def spec_identity(phase, spec_name, run_name, spec_file=None):
    """The comparison-critical settings of one run of a spec in this checkout, as the ledger records them."""
    effective = spec_effective(phase, spec_name, run_name, spec_file)
    if effective is None:
        return None
    with tempfile.TemporaryDirectory() as tmp:
        OmegaConf.save(effective, os.path.join(tmp, "resolved_train.yaml"))
        st = collector().settings(tmp, phase)
    return {k: "" if st.get(k) is None else str(st[k]) for k in IDENTITY_COLS}


def flat_config(cfg):
    """{dotted key: value} of a resolved configuration without its per-run output and experiment keys."""
    out = {}

    def walk(prefix, v):
        if isinstance(v, dict) and v:
            for k, x in v.items():
                walk(f"{prefix}.{k}", x)
        else:
            out[prefix] = v
    data = OmegaConf.to_container(OmegaConf.create(OmegaConf.to_yaml(cfg)), resolve=True)
    for k, v in data.items():
        if k not in ("output", "experiment"):
            walk(str(k), v)
    return out


def identity_digest(ident):
    return hashlib.sha256(json.dumps(ident, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def check_comparator(attempt, phase, spec_name, ledger, files_out=None, spec_file=None):
    """(ok, failed check texts, facts) for an attempt offered as the comparator of <phase>/<spec_name>; spec_file names
    the spec file to check against (default: YOUR_PACKAGE/<phase>/configs/<spec_name> of this checkout)."""
    c = collector()
    failed, facts = [], {"attempt": attempt, "spec": f"{phase}/{spec_name}"}
    attempt = os.path.realpath(attempt)
    if not os.path.isdir(attempt) or not os.path.isfile(os.path.join(attempt, "ablation_spec.yaml")):
        return False, ["the attempt folder does not exist or has no ablation_spec.yaml"], facts
    try:
        names, run_score, att_phase = c.expected_runs(attempt)
    except Exception as exc:
        return False, [f"the attempt's ablation_spec.yaml cannot be read ({type(exc).__name__})"], facts
    r = runner(phase)
    spec_path = spec_file or os.path.join(ROOT, "YOUR_PACKAGE", phase, "configs", spec_name)
    if not os.path.isfile(spec_path):
        where = f"the spec file {spec_file} does not exist" if spec_file else \
            f"{spec_name} is not in YOUR_PACKAGE/{phase}/configs of this checkout"
        return False, [where], facts
    spec = OmegaConf.load(spec_path)
    want_names = [n for n, _, _ in r._expand_runs(spec)[1]]
    att_spec = OmegaConf.load(os.path.join(attempt, "ablation_spec.yaml"))
    if (att_phase != phase or names != want_names or bool(att_spec.get("run_score", True)) != bool(spec.get("run_score", True))
            or str(att_spec.get("base_config")) != str(spec.get("base_config"))):
        failed.append(f"the attempt is not a {spec_name} attempt (runs {names}, expected {want_names})")
        return False, failed, facts
    facts["runs"] = ",".join(names)
    facts["run_score"] = run_score
    latest = c.current_rows(ledger) if os.path.isfile(ledger) else {}
    rows = {}
    for name in names:
        row = latest.get((attempt, name))
        if row is None:
            failed.append(f"run {name} has no row in {os.path.basename(ledger)}")
        elif row["status"] != "ok":
            failed.append(f"run {name}: run_log status is {row['status']}, not ok")
        else:
            rows[name] = row
    if failed:
        return False, failed, facts
    # Source: the run's digest against this checkout's runtime files, and its per-file hashes against the release manifest.
    current = r._source_provenance()
    release, release_sha = release_manifest()
    facts["release_manifest_sha256"] = release_sha
    facts["checkout_source_sha256"] = current["source_sha256"]
    digests = {row["source_sha256"] for row in rows.values()}
    facts["source_sha256"] = ",".join(sorted(digests))
    if digests != {current["source_sha256"]}:
        failed.append("the run's source digest differs from this checkout's runtime files (fraud/ and YOUR_PACKAGE/ .py, "
                      "pyproject.toml, requirements.txt)")
    # Per-file hashes (RG-F01): the run recorded raw-byte hashes (run_manifest.json source_before.files); the release
    # manifest holds LF-normalized hashes. So: run file == this checkout's file (raw), and this checkout's file == the
    # release manifest (LF-normalized). Both are recorded per file in --files-out.
    compared = []
    checkout_lf = {}
    for path in sorted(set(current["files"]) | set(release)):
        full = os.path.join(ROOT, path)
        if path.endswith(".py") and os.path.isfile(full):
            with open(full, "rb") as f:
                checkout_lf[path] = hashlib.sha256(f.read().replace(b"\r\n", b"\n")).hexdigest()
    for name, row in rows.items():
        man = c.load_json(os.path.join(attempt, name, "run_manifest.json")) or {}
        before = man.get("source_before") if isinstance(man.get("source_before"), dict) else {}
        if before.get("source_sha256") != row["source_sha256"]:
            failed.append(f"run {name}: run_manifest.json source digest differs from its run_log row")
        files = before.get("files") if isinstance(before.get("files"), dict) else {}
        run_vs_checkout, run_only, checkout_vs_release, checkout_only = [], [], [], []
        for path in sorted(set(files) | set(current["files"]) | set(release)):
            if not path.endswith(".py") or path.split("/")[0] not in ("fraud", "YOUR_PACKAGE"):
                continue
            got, here, rel = files.get(path), current["files"].get(path), release.get(path)
            a = "yes" if got is not None and got == here else ("not_in_run" if got is None else "not_in_checkout" if here is None else "no")
            b = ("yes" if here is not None and checkout_lf.get(path) == rel
                 else "not_in_checkout" if here is None else "not_in_release" if rel is None else "no")
            compared.append((name, path, got or "", here or "", rel or "", a, b))
            if a == "no" or a == "not_in_run":
                run_vs_checkout.append(path)
            elif a == "not_in_checkout":
                run_only.append(path)
            if b == "no":
                checkout_vs_release.append(path)
            elif b == "not_in_release":
                checkout_only.append(path)
        if run_vs_checkout or run_only:
            failed.append(f"run {name}: {len(run_vs_checkout)} .py file(s) differ between the run and this checkout, "
                          f"{len(run_only)} recorded by the run are not in this checkout (see comparator_source_files.csv)")
        if checkout_vs_release or checkout_only:
            failed.append(f"this checkout: {len(checkout_vs_release)} .py file(s) differ from the release manifest, "
                          f"{len(checkout_only)} are not in it (see comparator_source_files.csv)")
    facts["source_files_compared"] = len(compared)
    if files_out:
        os.makedirs(os.path.dirname(os.path.abspath(files_out)), exist_ok=True)
        with open(files_out, "w", newline="") as f:
            w = csv.writer(f, lineterminator="\n")
            w.writerow(["run_name", "path", "run_sha256", "checkout_sha256", "release_sha256_lf", "run_matches_checkout",
                        "checkout_matches_release_lf"])
            w.writerows(compared)
    # Configuration identity: data range, artifacts version and the other comparison-critical settings of the spec
    # (the ledger columns), then the whole resolved training configuration of the run against the spec's.
    for name, row in rows.items():
        want = spec_identity(phase, spec_name, name, spec_file)
        got = {k: row.get(k, "") for k in IDENTITY_COLS}
        facts["config_identity_sha256"] = identity_digest(want) if want else "unknown"
        diff = [k for k in IDENTITY_COLS if want is None or want[k] != got[k]]
        spec_eff = spec_effective(phase, spec_name, name, spec_file)
        run_yaml = os.path.join(attempt, name, "resolved_train.yaml")
        if not os.path.isfile(run_yaml):
            diff.append("resolved_train.yaml (missing)")
        elif spec_eff is not None:
            ran, wanted = flat_config(OmegaConf.load(run_yaml)), flat_config(spec_eff)
            absent = object()
            diff += sorted(k for k in set(ran) | set(wanted) if ran.get(k, absent) != wanted.get(k, absent))
        if diff:
            failed.append(f"run {name}: differs from this checkout's {spec_name} in {', '.join(diff)}")
        cohort = row.get("cohort_check", "")
        if run_score:
            if cohort.startswith("ok:"):
                facts["comparator_preflight"] = cohort[3:]
            else:
                failed.append(f"run {name}: not checked against a pre-flight cohort (cohort_check={cohort or 'empty'})")
        else:
            facts["comparator_preflight"] = cohort or "not_scored"
        facts["train_files"], facts["artifacts"] = got["train_files"], got["artifacts"]
    return not failed, failed, facts


def write_record(path, attempt, ok, failed, facts, origin, batch_preflight, used_by):
    lines = [f"A_H10_COMPARATOR={os.path.realpath(attempt)}", f"run={facts.get('runs', '-')}",
             f"spec={facts.get('spec', '-')}", f"origin={origin}", f"valid={'yes' if ok else 'no'}",
             f"checks_failed={'none' if not failed else ' | '.join(failed)}",
             f"comparator_preflight={facts.get('comparator_preflight', 'unknown')}",
             f"preflight={batch_preflight or 'unknown'}", f"source_sha256={facts.get('source_sha256', 'unknown')}",
             f"release_manifest_sha256={facts.get('release_manifest_sha256', 'unknown')}",
             f"source_files_compared={facts.get('source_files_compared', 0)} (per-file hashes in comparator_source_files.csv)",
             f"config_identity_sha256={facts.get('config_identity_sha256', 'unknown')}",
             f"train_files={facts.get('train_files', 'unknown')}", f"artifacts={facts.get('artifacts', 'unknown')}",
             f"used_by={used_by}"]
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w") as f:
        f.write("\n".join(lines) + "\n")


def cmd_comparator(args):
    ok, failed, facts = check_comparator(args.attempt, args.phase, args.spec, args.ledger, args.files_out,
                                         args.spec_file)
    if args.record:
        write_record(args.record, args.attempt, ok, failed, facts, args.origin, args.batch_preflight, args.used_by)
    if ok:
        print(f"COMPARATOR OK: {os.path.realpath(args.attempt)} ({args.spec}, {facts.get('runs')}; its pre-flight "
              f"{facts.get('comparator_preflight')}; source and settings match this checkout)")
        return 0
    print(f"COMPARATOR REJECTED: {args.attempt} cannot be the shared A-H10 comparator:")
    for t in failed:
        print(f"   - {t}")
    return 1


def step_attempts(batch_dir):
    """Every attempt folder recorded in <batch dir>/steps/*/STEP.txt (finished or interrupted steps alike)."""
    steps = os.path.join(batch_dir or "", "steps")
    found = set()
    if batch_dir and os.path.isdir(steps):
        for folder in os.listdir(steps):
            p = os.path.join(steps, folder, "STEP.txt")
            if os.path.isfile(p):
                att = read_step(p).get("attempt_dir", "")
                if att and os.path.isabs(att):
                    found.add(os.path.realpath(att))
    return found


def cmd_ledger_rows(args):
    wanted = {os.path.realpath(a) for a in args.attempts} | step_attempts(args.batch_dir)
    rows, header = [], None
    if os.path.isfile(args.ledger):
        with open(args.ledger, newline="") as f:
            reader = csv.reader(f)
            header = next(reader, None)
            if header and "attempt_dir" in header:
                i = header.index("attempt_dir")
                rows = [r for r in reader if len(r) > i and os.path.realpath(r[i]) in wanted]
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with open(args.out, "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        if header:
            w.writerow(header)
        w.writerows(rows)
    print(f"ledger rows of this batch: {len(rows)} row(s) for {len(wanted)} attempt folder(s) -> {args.out}")
    return 0


def read_step(path):
    fields = {}
    with open(path) as f:
        for line in f:
            if ": " in line:
                k, v = line.rstrip("\n").split(": ", 1)
                fields[k] = v
    return fields


def cmd_resume_state(args):
    steps = os.path.join(args.batch_dir, "steps")
    if not os.path.isdir(steps):
        return 0
    for folder in sorted(os.listdir(steps)):
        step_file = os.path.join(steps, folder, "STEP.txt")
        if not os.path.isfile(step_file):
            continue
        st = read_step(step_file)
        if not st.get("spec", "").endswith("/" + args.spec):
            continue
        ret = os.path.join(steps, folder, "RETURN.txt")
        if "finished_utc" in st:
            if os.path.isfile(ret) and "ACCEPTED: every run ok" in open(ret).read():
                print(f"finished_ok {os.path.join(steps, folder)}")
            continue
        if "interrupted_collected" in st:
            continue
        att = st.get("attempt_dir", "pending")
        if att not in ("pending", "none") and not att.startswith("ambiguous") and os.path.isdir(att):
            print(f"interrupted {att} {os.path.join(steps, folder)}")
    return 0


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("comparator")
    p.add_argument("--attempt", required=True)
    p.add_argument("--phase", required=True, choices=["phase4a", "phase4b"])
    p.add_argument("--spec", required=True)
    p.add_argument("--ledger", required=True)
    p.add_argument("--record", default=None)
    p.add_argument("--files-out", default=None)
    p.add_argument("--origin", default="override")
    p.add_argument("--batch-preflight", default=None)
    p.add_argument("--used-by", default="A-GAP10-OFF (batch 1), A-CAP10-SMALL and A-CAP10-LARGE (batch 2)")
    p.add_argument("--spec-file", default=None,
                   help="spec file to check against (default YOUR_PACKAGE/<phase>/configs/<spec>; the sandbox's reduced copy)")
    p.set_defaults(func=cmd_comparator)
    p = sub.add_parser("ledger-rows")
    p.add_argument("--ledger", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--batch-dir", default=None, help="also the attempts recorded in its steps/*/STEP.txt")
    p.add_argument("attempts", nargs="*")
    p.set_defaults(func=cmd_ledger_rows)
    p = sub.add_parser("resume-state")
    p.add_argument("--batch-dir", required=True)
    p.add_argument("--spec", required=True)
    p.set_defaults(func=cmd_resume_state)
    args = ap.parse_args()
    sys.exit(args.func(args))


if __name__ == "__main__":
    main()
