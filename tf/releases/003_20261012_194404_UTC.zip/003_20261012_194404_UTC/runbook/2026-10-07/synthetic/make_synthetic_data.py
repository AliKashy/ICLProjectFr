#!/usr/bin/env python3
# reviewer, 2026-10-07. Synthetic parquet with the real raw schema of fraud/configs/predictors.csv, for the
# end-to-end harness only. No real data. Writes train part_1..10, validation part_4950..4954 and eval
# part_8000..8010 under $FAKE_S3_ROOT with the bucket layout the configs expect.
# The fraud label depends on the current transaction AND on the account's recent history (a burst of
# fast transactions or a jump in amount), so a model that uses history should beat one that does not.
import argparse
import os

import numpy as np
import pandas as pd

CONT = ["transaction_amt", "external_1_scr", "avlble_merch_day_cash_lmt_amt", "available_daily_cash_limit_amt",
        "remain_day_merchandise_lmt_amt", "total_available_balance_amt"]
CAT = ["transaction_type_xcd", "segment", "transaction_category_xcd", "transaction_pos_condition_xcd", "avs_request_xcd",
       "pos_security_xflg", "transaction_pin_verify_xcd", "cardholder_present_xflg", "pos_card_capture_xflg",
       "cvv_verify_xcd", "authzn_rqst_crypto_valid_xflg", "pos_off_premises_xflg", "pos_terminal_attend_xflg"]


def make_file(rng, n_accounts, start_ts, file_tag, acct_offset, fraud_scale, mode="mixed"):
    rows = []
    for a in range(n_accounts):
        acct = f"A{acct_offset + a:07d}"
        n = int(rng.integers(1, 40))
        t = start_ts + int(rng.integers(0, 86400 * 20))
        base_amt = float(rng.lognormal(3.5, 1.0))
        prev_t, prev_amt, burst = None, base_amt, 0
        for k in range(n):
            gap = int(rng.choice([0, 5, 30, 300, 3600, 86400], p=[0.03, 0.07, 0.1, 0.2, 0.3, 0.3]))
            t += gap
            amt = float(base_amt * rng.lognormal(0, 0.6)) * (8.0 if rng.random() < 0.03 else 1.0)
            burst = burst + 1 if (prev_t is not None and t - prev_t <= 300) else 0
            ext = float(rng.normal(500, 150))
            # risk: current fields plus history (burst length, jump vs previous amount)
            if mode == "history":   # positive control: risk lives almost entirely in the account's recent past
                logit = -6.5 + 3.0 * (burst >= 2) + 2.5 * (amt > 4 * prev_amt) * (k > 0) + np.log(fraud_scale)
            elif mode == "current":  # negative control: risk depends on the current transaction only
                logit = -6.5 + 0.012 * (ext - 500) + np.log(fraud_scale)
            else:
                logit = (-7.0 + 0.004 * (ext - 500) + 1.2 * (burst >= 2) + 1.3 * (amt > 4 * prev_amt)
                         + 0.6 * (k == 0) + np.log(fraud_scale))
            fraud = int(rng.random() < 1 / (1 + np.exp(-logit)))
            row = {
                "fi_transaction_id": f"{file_tag}-{acct}-{k:04d}",
                "Nmap_account_reference_xid": acct,
                "transaction_dttm": pd.Timestamp(t, unit="s"),
                "frd_tag": fraud,
                "transaction_amt": amt,
                "external_1_scr": ext if rng.random() > 0.05 else np.nan,
                "avlble_merch_day_cash_lmt_amt": float(rng.uniform(0, 5000)) if rng.random() > 0.1 else np.nan,
                "available_daily_cash_limit_amt": float(rng.uniform(0, 1000)),
                "remain_day_merchandise_lmt_amt": float(rng.uniform(0, 5000)) if rng.random() > 0.2 else np.nan,
                "total_available_balance_amt": float(rng.normal(3000, 2000)),
            }
            for j, c in enumerate(CAT):
                card = [5, 7, 4, 9, 3, 2, 3, 2, 2, 4, 3, 2, 2][j]
                v = int(rng.integers(0, card))
                row[c] = None if rng.random() < 0.02 else f"{c[:3].upper()}{v}"
            rows.append(row)
            prev_t, prev_amt = t, amt
    return pd.DataFrame(rows)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--root", default=os.environ.get("FAKE_S3_ROOT"))
    p.add_argument("--accounts", type=int, default=120)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--fraud-scale", type=float, default=25.0, help="raises prevalence so small files have positives")
    p.add_argument("--mode", choices=["mixed", "history", "current"], default="mixed",
                   help="mixed (default), history (positive control) or current (negative control)")
    a = p.parse_args()
    rng = np.random.default_rng(a.seed)
    raw = os.path.join(a.root, "DATA_BUCKET", "tfm_raw_data")
    ev = os.path.join(a.root, "DATA_BUCKET", "tfm_EVAL_raw_data")
    os.makedirs(raw, exist_ok=True); os.makedirs(ev, exist_ok=True)
    t0 = int(pd.Timestamp("2025-01-01").timestamp())
    summary = []
    for split, ids, folder, day0 in (("train", range(1, 11), raw, 0), ("valid", range(4950, 4955), raw, 200),
                                     ("eval", range(8000, 8011), ev, 300)):
        for i in ids:
            df = make_file(rng, a.accounts, t0 + 86400 * (day0 + 2 * (i % 50)), f"{split}{i}", i * 100000, a.fraud_scale,
                           a.mode)
            df.to_parquet(os.path.join(folder, f"part_{i}.parquet"), index=False)
            summary.append((split, i, len(df), int(df.frd_tag.sum())))
    for s in ("train", "valid", "eval"):
        rows = [x for x in summary if x[0] == s]
        print(f"{s}: {len(rows)} files, {sum(x[2] for x in rows)} rows, {sum(x[3] for x in rows)} positives")


if __name__ == "__main__":
    main()
