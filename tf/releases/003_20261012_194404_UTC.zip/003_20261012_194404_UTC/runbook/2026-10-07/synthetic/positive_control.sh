#!/usr/bin/env bash
# reviewer's CPU harness (2026-10-07, v2 after review's review of a987168), never for the pod. Signal-recovery diagnostics
# for the history pipeline, run with the real trainer. In "history" data the label depends partly on the account's
# recent past, so h5 is expected to tend to score above h0; in "current" data it depends on the current transaction
# only, so h5 is not expected to show a material advantage over h0. These are expected tendencies, not pass/fail
# inequalities: two seeds, a small synthetic fixture and a short optimisation budget guarantee no numerical ordering
# or margin, and neither mode is a proof that the pipeline is right or a leakage test.
# Every stage's exit status is checked (data generation, artifact build, each training command, each metric
# extraction). Any failure prints "POSITIVE CONTROL FAILED: <stage>" and exits 1 with no summary. When all stages ran,
# the observed numbers and the expectations are printed and the exit status is 0 whatever the numeric ordering.
#     bash runbook/2026-10-07/synthetic/positive_control.sh <empty sandbox folder> [accounts] [epochs]
set -uo pipefail
SB="$(realpath -m "${1:?sandbox folder}")"; ACC="${2:-150}"; EP="${3:-4}"
REPO="$(cd "$(dirname "$0")/../../.." && pwd)"
[ -e "$SB" ] && { echo "sandbox $SB exists"; exit 2; }
mkdir -p "$SB" || { echo "POSITIVE CONTROL FAILED: cannot create sandbox $SB"; exit 1; }
export TF_REPO_ROOT="$REPO" PYTHONPATH="$REPO/runbook/2026-10-07/synthetic:$REPO/src:$REPO" OMP_NUM_THREADS="${OMP_NUM_THREADS:-2}"
cd "$REPO" || { echo "POSITIVE CONTROL FAILED: cannot enter $REPO"; exit 1; }

fail() {  # stage, exit status, log to point at (optional)
  echo "POSITIVE CONTROL FAILED: $1 (exit $2)${3:+; see $3}"
  [ -n "${3:-}" ] && [ -f "$3" ] && tail -5 "$3" | sed 's/^/    /'
  echo "No diagnostic summary: not every stage ran."
  exit 1
}

declare -A AP
for mode in history current; do
  export FAKE_S3_ROOT="$SB/$mode/fake_s3"
  mkdir -p "$SB/$mode" || fail "[$mode] sandbox folder" $?
  python3 -c "import sys, fraud.data.s3_utils as s; sys.exit(0 if getattr(s.make_s3_filesystem, '__name__', '') == '_fake_make_s3_filesystem' else 3)" \
    || fail "[$mode] fake-S3 redirect not active (nothing was run)" $?
  python3 runbook/2026-10-07/synthetic/make_synthetic_data.py --accounts "$ACC" --mode "$mode" --fraud-scale 10 \
    | sed "s/^/[$mode] /"
  rc=${PIPESTATUS[0]}; [ "$rc" -eq 0 ] || fail "[$mode] data generation" "$rc"
  python3 fraud/scripts/build_preprocessing_artifacts.py --config fraud/configs/preprocessing.yaml \
    build.output_base=s3://ARTIFACT_BUCKET/YOUR_ID/tabular_fraud/artifacts > "$SB/$mode.build.log" 2>&1
  rc=$?; [ "$rc" -eq 0 ] || fail "[$mode] artifact build" "$rc" "$SB/$mode.build.log"
  for seed in 1 2; do
    for h in 0 5; do
      out="$SB/$mode/h${h}_s${seed}"
      python3 YOUR_PACKAGE/phase4a/scripts/train_sequential.py --config YOUR_PACKAGE/phase4a/configs/sequential.yaml \
        data.val_end=4954 sequence.history_len=$h training.seed=$seed training.max_epochs=$EP training.num_workers=0 \
        training.batch_size=128 training.learning_rate=1e-3 training.precision=32-true training.accelerator=cpu \
        model.input_embed_dim=16 model.num_attn_blocks=2 output.checkpoint_dir="$out" > "$out.log" 2>&1
      rc=$?; [ "$rc" -eq 0 ] || fail "[$mode] training seed $seed h$h" "$rc" "$out.log"
      # Best epoch by validation AP; prints "<ap> <epoch> <auroc>" and fails on a missing, empty or non-finite table.
      best=$(python3 -c "
import csv, math, sys
rows = list(csv.DictReader(open(sys.argv[1])))
if not rows: sys.exit('no rows in training_metrics.csv')
b = max(rows, key=lambda x: float(x['valid_ap']))
ap, auc = float(b['valid_ap']), float(b['valid_auroc'])
if not all(math.isfinite(v) and 0 <= v <= 1 for v in (ap, auc)): sys.exit('non-finite or out-of-range metric')
print(f'{ap:.4f} {b[\"epoch\"]} {auc:.4f}')" "$out/training_metrics.csv" 2>"$out.extract.log")
      rc=$?
      [[ "$rc" -eq 0 && "$best" =~ ^[0-9.]+\ [0-9]+\ [0-9.]+$ ]] \
        || fail "[$mode] metric extraction seed $seed h$h" "$rc" "$out.extract.log"
      read -r ap epoch auc <<< "$best"
      AP[$mode,$seed,$h]=$ap
      echo "[$mode] seed $seed h$h: best valid_ap $ap (epoch $epoch), auroc $auc"
    done
  done
done

echo
echo "===== POSITIVE CONTROL DIAGNOSTIC: all stages ran ($ACC accounts, $EP epochs, seeds 1-2) ====="
echo "Observed best validation AP (h5 - h0 per seed):"
for mode in history current; do
  awk -v m="$mode" -v a="${AP[$mode,1,0]}" -v b="${AP[$mode,1,5]}" -v c="${AP[$mode,2,0]}" -v d="${AP[$mode,2,5]}" \
    'BEGIN { printf "  %-8s h0 %.4f / %.4f   h5 %.4f / %.4f   h5-h0 %+.4f / %+.4f   (mean %+.4f)\n",
             m, a, c, b, d, b - a, d - c, ((b - a) + (d - c)) / 2 }'
done
echo "Expectations (diagnostic tendencies, not pass/fail tests):"
echo "  history: h5 is expected to score above h0 (signal-recovery tendency; the label depends partly on the recent past)."
echo "  current: h5 is not expected to show a material advantage over h0 (the label uses the current transaction only)."
echo "  Neither ordering is a proof that the history pipeline is correct, and neither is a leakage test. Two seeds,"
echo "  a small synthetic fixture and a short optimisation budget guarantee no ordering or margin; a surprising"
echo "  ordering is a reason to look closer (logs in $SB), not a verdict."
echo "POSITIVE CONTROL DONE: exit 0 because every stage ran, whatever the numeric ordering."
exit 0
