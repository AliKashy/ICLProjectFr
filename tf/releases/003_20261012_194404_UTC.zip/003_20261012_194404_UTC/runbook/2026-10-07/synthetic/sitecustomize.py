# Synthetic-harness shim (reviewer, 2026-10-07). Loaded automatically by Python when this folder is on
# PYTHONPATH. If FAKE_S3_ROOT is set, every S3 filesystem the project creates is replaced by a local
# folder: s3://bucket/key -> $FAKE_S3_ROOT/bucket/key. Application code is not modified. Never used on the pod.
# Fail closed: the harness writes artifacts and predictions to the real YOUR_ID paths inside the fake folder, so if
# the redirect cannot be installed the process stops instead of reaching real storage.
import os
import sys

_root = os.environ.get("FAKE_S3_ROOT")
_repo = os.environ.get("TF_REPO_ROOT")
if _root and not _repo:
    sys.stderr.write("[synthetic shim] FAKE_S3_ROOT is set but TF_REPO_ROOT is not; stopping so nothing reaches real "
                     "storage\n")
    sys.stderr.flush()
    os._exit(70)
if _root and _repo:
    if _repo not in sys.path:
        sys.path.insert(0, _repo)
    try:
        from fsspec.implementations.dirfs import DirFileSystem
        from fsspec.implementations.local import LocalFileSystem
        import fraud.data.s3_utils as _s3

        def _fake_make_s3_filesystem(cred_path=None):
            os.makedirs(_root, exist_ok=True)
            return DirFileSystem(path=_root, fs=LocalFileSystem(auto_mkdir=True))

        _s3.make_s3_filesystem = _fake_make_s3_filesystem
    except Exception as exc:
        sys.stderr.write(f"[synthetic shim] NOT INSTALLED, stopping so nothing reaches real storage: {exc}\n")
        sys.stderr.flush()
        os._exit(70)
