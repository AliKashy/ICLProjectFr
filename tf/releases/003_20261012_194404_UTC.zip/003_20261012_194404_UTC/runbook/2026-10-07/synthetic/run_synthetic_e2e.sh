#!/usr/bin/env bash
# reviewer's CPU harness (2026-10-07, v2), never for the pod. Generates synthetic parquet with the real schema in a fake
# S3 folder, builds artifacts with the real build script, runs batch1.sh and then batch2.sh unchanged except for the
# sandbox flag (tiny model, 1 epoch, batch / 32, no workers). Exit 0 only if every stage passed.
#     bash runbook/2026-10-07/synthetic/run_synthetic_e2e.sh <new sandbox folder> [accounts_per_file]
set -uo pipefail
SB="$(realpath -m "${1:?sandbox folder}")"; ACC="${2:-40}"
REPO="$(cd "$(dirname "$0")/../../.." && pwd)"
[ -e "$SB" ] && { echo "sandbox $SB exists; give a new folder"; exit 2; }
mkdir -p "$SB"
# RUNBOOK_BANK_OVERRIDES=1 is the explicit flag the batch scripts and the pre-flight require before they accept the
# harness variable RUNBOOK_SANDBOX (first release, inherited harness state); the pre-flight records it as an override.
export FAKE_S3_ROOT="$SB/fake_s3" TF_REPO_ROOT="$REPO" RUNBOOK_SANDBOX="$SB" RUNBOOK_BANK_OVERRIDES=1
# EXTRA_PYTHONPATH (optional) goes first, e.g. a folder with pandas 2.x to test the supported dependency range.
export PYTHONPATH="${EXTRA_PYTHONPATH:+$EXTRA_PYTHONPATH:}$REPO/runbook/2026-10-07/synthetic:$REPO/src:$REPO"
python3 -c "import pandas, torch, pytorch_lightning as pl; print('harness env: pandas', pandas.__version__, '| torch', torch.__version__, '| lightning', pl.__version__)"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-2}"
cd "$REPO"
# Refuse to run unless the fake-S3 redirect is active: every later step writes to the real YOUR_ID paths, and only
# the redirect keeps them inside the sandbox.
python3 -c "import sys, fraud.data.s3_utils as s; sys.exit(0 if getattr(s.make_s3_filesystem, '__name__', '') == '_fake_make_s3_filesystem' else 3)" \
  || { echo "HARNESS REFUSED: the fake-S3 redirect is not active; nothing was run"; exit 1; }
python3 runbook/2026-10-07/synthetic/make_synthetic_data.py --accounts "$ACC" > "$SB/data_summary.txt" \
  || { echo "HARNESS FAILED: data generation"; exit 1; }
cat "$SB/data_summary.txt"
python3 fraud/scripts/build_preprocessing_artifacts.py --config fraud/configs/preprocessing.yaml \
  build.output_base=s3://ARTIFACT_BUCKET/YOUR_ID/tabular_fraud/artifacts > "$SB/build_artifacts.log" 2>&1 \
  || { echo "HARNESS FAILED: artifact build"; tail -20 "$SB/build_artifacts.log"; exit 1; }
echo "== batch1.sh (sandbox)"
bash runbook/2026-10-07/batch1.sh; b1=$?
if [ $b1 -ne 0 ]; then echo "HARNESS FAILED: batch1 exit $b1 (remaining specs not run)"; exit 1; fi
echo "== batch2.sh (sandbox): post-hoc scoring of batch 1 into the return folder, then the batch 2 specs"
bash runbook/2026-10-07/batch2.sh; b2=$?
RET="$SB/returns/batch2_summary"
for f in POST_SCORE.txt post_score_results.csv; do
  [ -s "$RET/$f" ] || { echo "HARNESS FAILED: batch 2 return copy is missing $f"; b2=1; }
done
echo "HARNESS DONE: batch1 exit $b1, batch2 exit $b2; ledger $SB/runs/run_log.csv; batch 2 return $RET"
exit $b2
