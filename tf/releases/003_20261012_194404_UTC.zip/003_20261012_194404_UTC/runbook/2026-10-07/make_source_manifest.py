#!/usr/bin/env python3
# reviewer, 2026-10-07; RUN-10 (R-043) 2026-10-11. Regenerates github_source_manifest.csv from the tracked files of this
# checkout (content hashed with CRLF normalized to LF). Run on GitHub's side after any source change, never on the
# pod: the pod compares its own files against this list in preflight_pod.py (check_source).
"""Columns: path, sha256_lf, class.

class is the file class preflight_pod.source_class assigns by path (the one rule both scripts read):
    python   .py under fraud/ or YOUR_PACKAGE/ (runtime code; drift under the runtime prefixes is FAIL unless accepted)
    shell    .sh under fraud/ or YOUR_PACKAGE/
    data     .csv under fraud/ or YOUR_PACKAGE/ (the predictor list)
    spec     ft_decisions*.yaml under YOUR_PACKAGE/phase4a/configs or YOUR_PACKAGE/phase4b/configs: sweep specs and smoke specs
    config   every other .yaml/.yml under fraud/ or YOUR_PACKAGE/ (base configs, tuner, preprocessing)
    runbook  .py and .sh in runbook/2026-10-07 (the launch harness and its tests); this manifest itself is excluded
             so the file never hashes itself
The pre-flight FAILs drift in the batch's own files (the specs the batch scripts name, their base configs, the predictor
list they name, batch1.sh and batch2.sh themselves, and the runbook's own scripts preflight_pod.py, run_step.py,
collect_returns.py, score_attempt.py, batch_tools.py, smoke.sh and smoke_checks.py) under the required config check,
with --allow-warn-only config as the override; drift in other YAML and in the other runbook files (the tests) is WARN.
collect_returns.py copies the manifest digest and the active-config digest from the pre-flight folder into the ledger.
"""
import csv
import hashlib
import importlib.util
import os
import subprocess

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
_spec = importlib.util.spec_from_file_location("preflight_pod_for_manifest", os.path.join(HERE, "preflight_pod.py"))
_pf = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_pf)
source_class = _pf.source_class

files = subprocess.run(["git", "-C", ROOT, "ls-files", "fraud", "YOUR_PACKAGE", _pf.RUNBOOK_DIR], capture_output=True,
                       text=True, check=True).stdout.split()
rows = []
for rel in sorted(files):
    cls = source_class(rel)
    if cls is not None:
        with open(os.path.join(ROOT, rel), "rb") as f:
            rows.append((rel, hashlib.sha256(f.read().replace(b"\r\n", b"\n")).hexdigest(), cls))
commit = subprocess.run(["git", "-C", ROOT, "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip()
out = os.path.join(HERE, _pf.MANIFEST_NAME)
with open(out, "w", newline="") as f:
    w = csv.writer(f, lineterminator="\n")  # LF, so sha256sum of the file equals the digest the pre-flight prints
    w.writerow(["path", "sha256_lf", "class"])
    w.writerows(rows)
counts = {}
for _, _, cls in rows:
    counts[cls] = counts.get(cls, 0) + 1
print(f"{len(rows)} files ({', '.join(f'{k} {v}' for k, v in sorted(counts.items()))}); generated from the working "
      f"tree of {commit[:12]} (commit the result with the source)")
