#!/usr/bin/env bash
# Batch 2 DRAFT (reviewer, 2026-10-07; first-release changes 2026-10-11: return folder from the start, pre-flight gate,
# comparator read from batch 1's return folder and validated, inherited harness state, PYTHON). Do not start until
# reviewers have read batch 1's results: its order and contents may change with them (RUN-06, the batch 2
# continuity work, is not done here; only what the comparator check needs). Requires the runners of PR #5.
#     bash runbook/2026-10-07/batch2.sh                     (PYTHON=<interpreter> to name it; default python3)
#     BATCH1_RETURN=runs/returns/batch1_<time>  names batch 1's return folder; default: the newest runs/returns/batch1_*/
# reviewer's test harness only (stops the launch unless RUNBOOK_BANK_OVERRIDES=1 is set):
#     RUNBOOK_SANDBOX=<folder>, BATCH2_SKIP="<spec names>", PREFLIGHT_ARGS="<pre-flight flags>".
#   0. pre-flight (RESULT PASS required; anything else stops the batch before training)
#   1. post-hoc scoring of batch 1's validation-only checkpoints on 8000-8010 (minutes; reads runs/run_log.csv);
#      its table, per-run CSV and safe evidence files go into the batch 2 return folder
#   2. ft_decisions.yaml             A at h5, bidirectional / causal mask, scored   about 2 x the h5 cost
#      (causal is plan row A-MASK05-C; bidirectional repeats A-H05 at seed 42 and measures same-seed GPU noise)
#   3. ft_decisions_flat_h15.yaml    A at h15 (256 x 16), scored                about 9.7 h (2026-10-06 run)
#   4. ft_decisions_hier_long.yaml   B at h15 and h20 (2048 x 2), scored        cost not yet measured
#   5. ft_decisions_flat_h20.yaml    A at h20 (128 x 32), scored                roughly 15 h or more
#   6. ft_decisions_capacity.yaml    A at h10, small and large, validation only (the current size is A-H10 from
#      batch 1, run once; skipped unless batch 1's comparator passes the same validation as in batch 1)   roughly 10 h
# Cheapest first, so results arrive early; skip any step with BATCH2_SKIP.
# The batch return folder runs/returns/batch2_<time>/ exists from the start and holds BATCH_STATUS.txt, the pre-flight
# copy (every file), POST_SCORE.txt, post_score_results.csv, post_score/, steps/<spec>_<time>/ (each
# step's STEP.txt and RETURN.txt), SHARED_COMPARATOR.txt (batch 1's comparator revalidated) and, at the end,
# RETURN.txt and run_log_batch2.csv. Send that folder and runs/run_log.csv.
set -uo pipefail
cd "$(dirname "$0")/../.."
HERE=runbook/2026-10-07
PY="${PYTHON:-python3}"

if [ "${RUNBOOK_BANK_OVERRIDES:-}" != "1" ]; then
  present=""
  for v in RUNBOOK_SANDBOX BATCH2_SKIP PREFLIGHT_ARGS; do [ -n "${!v:-}" ] && present="$present $v"; done
  if [ -n "$present" ]; then
    echo "STOPPED BEFORE START: set in this shell:$present. These belong to reviewer's test harness, not to a bank run (the sandbox"
    echo "setting shrinks every run to a one-epoch CPU model). Unset them and start again. Only on reviewer's or reviewer's"
    echo "advice, set RUNBOOK_BANK_OVERRIDES=1 to keep them; the pre-flight records that as an override. Nothing was run."
    exit 1
  fi
fi
SB="${RUNBOOK_SANDBOX:-}"
PF=runs/preflight; LEDGER=runs/run_log.csv; RET=runs/returns
[ -n "$SB" ] && { PF="$SB/preflight"; LEDGER="$SB/runs/run_log.csv"; RET="$SB/returns"; }
SKIP=" ${BATCH2_SKIP:-} "

OUT=runs/returns/batch2_$(date -u +%Y%m%dT%H%M%SZ); [ -n "$SB" ] && OUT="$SB/returns/batch2_summary"
mkdir -p "$OUT/steps" || { echo "cannot create the return folder $OUT; nothing was run"; exit 1; }
status() { echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) $*" >> "$OUT/BATCH_STATUS.txt"; }
status "batch 2 started: interpreter $PY; BATCH2_SKIP '${BATCH2_SKIP:-}'"
echo "batch return folder: $OUT (send this folder and $LEDGER when the batch ends or stops)"

pfout=$("$PY" "$HERE/preflight_pod.py" --out-root "$PF" ${PREFLIGHT_ARGS:-} | tee >(cat >&2)); pfrc=$?
PFDIR=$(printf '%s\n' "$pfout" | sed -n 's/^PREFLIGHT_DIR=//p' | tail -1)
RESULT=""
if [ -n "$PFDIR" ] && [ -d "$PFDIR" ]; then
  PFCOPY="$OUT/preflight_$(basename "$PFDIR")"; mkdir -p "$PFCOPY"
  find "$PFDIR" -maxdepth 1 -type f -exec cp -p {} "$PFCOPY/" \;
  echo "pre-flight folder for this batch: $PFDIR (copied into $PFCOPY)"
  [ -f "$PFDIR/SUMMARY.txt" ] && RESULT=$(grep -E '^RESULT:? (PASS|FAIL)' "$PFDIR/SUMMARY.txt" | tail -1 | sed -E 's/^RESULT:? (PASS|FAIL).*/\1/')
fi
if [ $pfrc -ne 0 ] || [ "$RESULT" != "PASS" ] || [ ! -f "$PFDIR/data_contract.json" ]; then
  status "stopped at the pre-flight: exit $pfrc, RESULT ${RESULT:-line missing}, folder ${PFDIR:-not found}"
  echo "PRE-FLIGHT FAILED (exit $pfrc, RESULT ${RESULT:-line missing}): nothing was run. Send the folder $OUT/ (it holds the complete pre-flight copy)."
  exit 1
fi
echo "pre-flight RESULT PASS: scored runs are checked against its evaluation cohort"

failed=0; ATTEMPTS=()
echo "== post-hoc scoring of validation-only attempts in $LEDGER (return copy: $OUT)"
"$PY" "$HERE/score_attempt.py" --from-ledger "$LEDGER" --preflight "$PFDIR" --return-dir "$OUT" \
  || { echo "post-hoc scoring reported a problem; continuing"; failed=1; }

# The shared A-H10 comparator of the capacity runs: read from batch 1's return folder and validated like in batch 1
# (in the sandbox against run_step.py's reduced copy of the spec, which the sandbox runs trained on).
B1="${BATCH1_RETURN:-}"
if [ -z "$B1" ]; then
  if [ -n "$SB" ]; then B1="$SB/returns/batch1_summary"; else B1=$(ls -td "$RET"/batch1_*/ 2>/dev/null | head -1); B1="${B1%/}"; fi
fi
H10_DIR=""
CAND=$([ -f "$B1/SHARED_COMPARATOR.txt" ] && sed -n 's/^A_H10_COMPARATOR=//p' "$B1/SHARED_COMPARATOR.txt" | head -1)
if [ -z "$CAND" ]; then
  echo "== no A-H10 comparator: ${B1:-no batch 1 return folder} has no SHARED_COMPARATOR.txt; the capacity step will be skipped"
  status "comparator: none found in ${B1:-no batch 1 return folder}"
elif "$PY" "$HERE/batch_tools.py" comparator --attempt "$CAND" --phase phase4a --spec ft_decisions_flat_h10.yaml \
       ${SB:+--spec-file "$SB/specs/phase4a_ft_decisions_flat_h10.yaml"} --ledger "$LEDGER" \
       --record "$OUT/SHARED_COMPARATOR.txt" --files-out "$OUT/comparator_source_files.csv" \
       --origin batch1_return --batch-preflight "$PFDIR" --used-by "A-CAP10-SMALL and A-CAP10-LARGE (this batch)"; then
  H10_DIR="$CAND"; status "comparator $CAND accepted (from $B1)"
else
  echo "== the A-H10 comparator named in $B1/SHARED_COMPARATOR.txt failed validation; the capacity step will be skipped"
  status "comparator $CAND rejected (from $B1); see SHARED_COMPARATOR.txt"
fi

for step in "phase4a ft_decisions.yaml" "phase4a ft_decisions_flat_h15.yaml" \
            "phase4b ft_decisions_hier_long.yaml" \
            "phase4a ft_decisions_flat_h20.yaml" "phase4a ft_decisions_capacity.yaml"; do
  set -- $step
  if [[ "$SKIP" == *" $2 "* ]]; then echo "== skipped $2 (BATCH2_SKIP)"; status "skipped $2 (BATCH2_SKIP)"; continue; fi
  if [ "$2" = "ft_decisions_capacity.yaml" ] && [ -z "$H10_DIR" ]; then
    echo "== skipped $2: no validated A-H10 comparator from batch 1 (see above); its small and large cells have nothing to compare with"
    status "skipped $2: no validated A-H10 comparator"; failed=1; continue
  fi
  status "started $2"
  # Echo the step's output through the inherited stderr descriptor. `tee /dev/stderr` would reopen the console log and
  # truncate it on Linux, erasing everything printed before this step.
  out=$("$PY" "$HERE/run_step.py" --phase "$1" --spec "$2" --preflight "$PFDIR" --batch-dir "$OUT" | tee >(cat >&2)); rc=$?
  dir=$(printf '%s\n' "$out" | sed -n 's/^ATTEMPT_DIR=//p' | tail -1)
  ret=$(printf '%s\n' "$out" | sed -n 's/^RETURN_DIR=//p' | tail -1)
  [ -n "$dir" ] && ATTEMPTS+=("$dir")
  if [ -n "$ret" ] && [ -d "$ret" ]; then
    dest="$OUT/steps/$(basename "$ret")"; mkdir -p "$dest"
    find "$ret" -maxdepth 1 -type f \( -name '*.txt' -o -name '*.csv' -o -name '*.json' \) -size -1024k -exec cp -p {} "$dest/" \;
  fi
  status "finished $2: run_step exit $rc; attempt ${dir:-none}; return ${ret:-none}"
  [ $rc -ne 0 ] && { echo "STEP $2: not all runs are ok; continuing"; failed=1; }
done

echo; echo "===== BATCH 2 SUMMARY (send $OUT/ and $LEDGER) ====="
if [ ${#ATTEMPTS[@]} -gt 0 ]; then
  "$PY" "$HERE/collect_returns.py" --no-ledger --preflight "$PFDIR" --out "$OUT" "${ATTEMPTS[@]}" || failed=1
fi
"$PY" "$HERE/batch_tools.py" ledger-rows --ledger "$LEDGER" --out "$OUT/run_log_batch2.csv" --batch-dir "$OUT" ${ATTEMPTS[@]+"${ATTEMPTS[@]}"}
verdict=$([ $failed -eq 0 ] && echo 'all runs ok' || echo 'SOME RUNS NEED ATTENTION')
status "batch 2 finished: $verdict"
echo "Batch 2 finished: $verdict"
exit $failed
