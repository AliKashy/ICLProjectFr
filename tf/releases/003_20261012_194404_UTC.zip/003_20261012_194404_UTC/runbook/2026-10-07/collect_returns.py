#!/usr/bin/env python3
# Written by reviewer (2026-10-07), version 3 after review's collector review of a987168 (R1-R3 in
# bridge/reviews/review/2026-10-07-PR3-a987168/collector_review_a987168.md). Read-only on the attempts it inspects.
# Requires the attempt-isolated runners of PR #4 (review/overnight-buildout-2026-10-07): it reads their immutable
# artifacts (ablation_spec.yaml, results.csv, run_manifest.json, resolved_train.yaml, resolved_score.yaml,
# score_metrics.json, best.ckpt) and never re-derives a metric, a status or a setting.
"""Collect and validate finished sweep attempts; record them in the revisioned ledger.

    python runbook/2026-10-07/collect_returns.py <attempt dir> [<attempt dir> ...] [--no-ledger]

An attempt dir is <output_root>/<attempt>/ as written by run_ablations.py; arguments naming the same real folder are
collected once. A run is reported "ok" only when the runner said ok AND all its evidence agrees; otherwise the
runner's own failure status is kept, or the status names what failed (names only, never values):
  invalid_results:duplicate_run_name  results.csv has more than one row for the run; no row is chosen.
  evidence_mismatch:<fields>  sources disagree: the results row versus run_manifest.json's result (every shared
      field), the row's and manifest's attempt/run identity versus this folder, the recomputed SHA-256 of
      resolved_train.yaml (and resolved_score.yaml when the spec scores) versus the recorded ones, and, when scored,
      the row's eval fields versus score_metrics.json.
  invalid:<checks>  a required file is missing or a recorded value is unusable: return codes (train 0; score 0 when
      the spec scores, empty when validation-only), AP/AUROC finite in [0, 1], checkpoint epoch/step present,
      checkpoint bytes unchanged, score file schema, counts and metrics (unless disabled in the resolved config).
RETURN.txt carries status codes, field names and numbers only, never error text (error text can contain data values).

Ledger tf-runbook-ledger-v5: one row per revision of the key (canonical attempt folder, run_name);
evidence_sha256 covers every column except ledger_schema, collected_utc, revision, transition and evidence_sha256.
v5 (RUN-10, R-043) appends three configuration-identity columns after the v4 columns, which keep their order:
manifest_sha256 (the reviewed source manifest the pre-flight compared against, from the pre-flight folder's
config_identity.json, else the manifest file beside this script), active_configs_sha256 (the pre-flight's digest over
the batch's own spec, base config and predictor-list files; empty without a pre-flight folder) and spec_sha256 (the
attempt's own ablation_spec.yaml as launched).
Identical evidence is skipped. A provisional latest revision (not_run) gains the next revision (transition
provisional_to_final or provisional_update). Different evidence for a final latest revision is a CONFLICT: not
appended, printed with the key and the differing field names, exit nonzero. current_rows() gives the latest
revision per key.
Exit 0 only if at least one run was expected, every expected run is ok, and no ledger conflict occurred.
"""
import argparse
import csv
import datetime as _dt
import fcntl
import hashlib
import importlib.util
import json
import math
import os
import sys

from omegaconf import OmegaConf

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
LEDGER_SCHEMA = "tf-runbook-ledger-v5"
LEDGER_META = ["ledger_schema", "collected_utc", "revision", "transition", "evidence_sha256"]
LEDGER_COLS = ["ledger_schema", "collected_utc", "attempt_dir", "attempt", "run_name", "status", "runner_status",
               "train_rc", "score_rc", "checkpoint_epoch", "checkpoint_step", "valid_ap", "valid_auroc",
               "checkpoint_monitor_score", "eval_ap", "eval_auroc", "eval_rows", "eval_positives", "run_score",
               "history_len", "seed", "batch_x_accum", "train_files", "val_files", "eval_files", "embedding",
               "mask", "optimizer", "time_delta", "model", "artifacts", "checkpoint_sha256", "source_sha256",
               "resolved_train_sha256", "started_utc", "finished_utc", "sweep_peak_gpu_mib", "predictions_path",
               "cohort_check", "revision", "transition", "evidence_sha256",
               "manifest_sha256", "active_configs_sha256", "spec_sha256"]  # v5: appended, earlier columns unchanged
EVIDENCE_COLS = [c for c in LEDGER_COLS if c not in LEDGER_META]
PROVISIONAL = "not_run"
# The runner writes the results row and run_manifest.json's "result" from one dict: these fields must be in both and
# agree; every other shared column (axis choices, checkpoint monitor, error) must agree too.
SHARED_REQUIRED = ["run_name", "attempt", "run_dir", "manifest_path", "status", "train_rc", "score_rc",
                   "checkpoint_epoch", "checkpoint_step", "best_valid_ap", "best_valid_auroc", "eval_ap", "eval_auroc",
                   "n_predictions", "n_positives", "predictions_path", "checkpoint_sha256", "resolved_train_sha256",
                   "source_sha256"]
SCORE_FIELDS = {"eval_ap": "average_precision", "eval_auroc": "auroc", "n_predictions": "n_predictions",
                "n_positives": "n_positives", "predictions_path": "predictions_path"}  # results column -> score key


def fnum(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except (TypeError, ValueError):
        return None


def in01(x):
    v = fnum(x)
    return v is not None and 0.0 <= v <= 1.0


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def config_identity(preflight_dir=None):
    """{manifest_sha256, active_configs_sha256, source} for the ledger: from the pre-flight folder's
    config_identity.json when it has one, else the manifest file beside this script (CRLF normalized to LF, as the
    pre-flight hashes it) with no active-config digest."""
    if preflight_dir:
        rec = load_json(os.path.join(preflight_dir, "config_identity.json"))
        if rec and isinstance(rec.get("manifest_sha256"), str):
            return {"manifest_sha256": rec["manifest_sha256"],
                    "active_configs_sha256": rec.get("active_configs_sha256") or "",
                    "source": f"pre-flight {os.path.basename(os.path.normpath(preflight_dir))}"}
    manifest = os.path.join(os.path.dirname(os.path.abspath(__file__)), "github_source_manifest.csv")
    if os.path.isfile(manifest):
        with open(manifest, "rb") as f:
            digest = hashlib.sha256(f.read().replace(b"\r\n", b"\n")).hexdigest()
    else:
        digest = ""
    return {"manifest_sha256": digest, "active_configs_sha256": "", "source": "manifest file (no pre-flight identity)"}


def load_json(path):
    try:
        with open(path) as f:
            v = json.load(f)
        return v if isinstance(v, dict) else None
    except Exception:
        return None


def same(cell, value):
    """Does a results.csv cell record this typed JSON value? None <-> empty cell, integers exactly, floats to 1e-9
    relative (the runner writes full-precision floats to both files), everything else as text."""
    cell = "" if cell is None else cell
    if value is None or isinstance(value, (bool, str)):
        return cell == ("" if value is None else str(value))
    try:
        if isinstance(value, int):
            return int(cell) == value
        if isinstance(value, float):
            x = float(cell)
            return math.isclose(x, value, rel_tol=1e-9, abs_tol=1e-12) or (math.isnan(x) and math.isnan(value))
    except ValueError:
        pass
    return False


def tail(path, n):
    """The last n components of a recorded path: the attempt folder may have been moved or copied since."""
    return tuple(os.path.normpath(path).split(os.sep)[-n:]) if path else ()


def expected_runs(attempt_dir):
    spec = OmegaConf.load(os.path.join(attempt_dir, "ablation_spec.yaml"))
    phase = "phase4b" if "phase4b" in str(spec.base_config) else "phase4a"
    path = os.path.join(ROOT, "YOUR_PACKAGE", phase, "scripts", "run_ablations.py")
    s = importlib.util.spec_from_file_location(f"runner_{phase}", path)
    m = importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return [r[0] for r in m._expand_runs(spec)[1]], bool(spec.get("run_score", True)), phase


def settings(run_dir, phase):
    p = os.path.join(run_dir, "resolved_train.yaml")
    if not os.path.isfile(p):
        return {}
    e = OmegaConf.load(p)
    blocks = (f"{e.model.get('num_txn_blocks')}+{e.model.get('num_seq_blocks')}" if phase == "phase4b"
              else str(e.model.get("num_attn_blocks")))
    return {"history_len": e.sequence.history_len, "seed": e.training.get("seed"),
            "batch_x_accum": f"{e.training.batch_size}x{e.training.get('accumulate_grad_batches', 1)}",
            "train_files": f"{e.data.train_start}-{e.data.train_end}", "val_files": f"{e.data.val_start}-{e.data.val_end}",
            "eval_files": f"{e.eval.file_start}-{e.eval.file_end}", "embedding": e.model.continuous_embedding,
            "mask": e.sequence.attention_mask, "optimizer": e.training.optimizer,
            "time_delta": e.sequence.get("time_delta", True),
            "model": f"{phase[-2:]} d{e.model.input_embed_dim} blocks {blocks} heads {e.model.num_heads}",
            "artifacts": f"{e.artifacts.base}/{e.artifacts.version}",
            "_compute_metrics": bool(e.eval.get("compute_metrics", False))}


def sweep_peak(attempt_dir):
    p = os.path.join(attempt_dir, "gpu_sweep.csv")
    if not os.path.isfile(p):
        return None
    peak = None
    with open(p, errors="replace") as f:
        for line in f:
            parts = [x.strip() for x in line.split(",")]
            if len(parts) >= 2 and parts[1].endswith("MiB"):
                v = fnum(parts[1][:-3])
                if v is not None:
                    peak = max(peak or 0, int(v))
    return peak


def check_ok_row(r, run_dir, run_score, st, man, sm):
    """(failed checks, contradicted fields) for a row the runner marked ok. Names only, never values."""
    bad, diff = [], set()
    attempt, name = tail(run_dir, 2)
    if r.get("train_rc") != "0":
        bad.append("train_rc")
    if (r.get("score_rc") or "") != ("0" if run_score else ""):
        bad.append("score_rc")
    if not (in01(r.get("best_valid_ap")) and in01(r.get("best_valid_auroc"))):
        bad.append("valid_metrics")
    if fnum(r.get("checkpoint_epoch")) is None or fnum(r.get("checkpoint_step")) is None:
        bad.append("checkpoint_epoch_step")
    ck, rec = os.path.join(run_dir, "best.ckpt"), (r.get("checkpoint_sha256") or "").strip()
    if len(rec) != 64 or not os.path.isfile(ck):
        bad.append("checkpoint_missing")
    elif sha256(ck) != rec:
        bad.append("checkpoint_hash_changed")
    res = (man or {}).get("result")
    readable = isinstance(res, dict)
    if not readable:
        bad.append("manifest_unreadable")
    else:
        for f in sorted(set(SHARED_REQUIRED) | (set(r) & set(res))):
            if f not in r or f not in res or not same(r[f], res[f]):
                diff.add(f)
        for f, want in (("attempt", attempt), ("run_name", name)):
            if r.get(f) != want or man.get(f) != want:
                diff.add(f)
        if tail(r.get("run_dir"), 2) != (attempt, name):
            diff.add("run_dir")
        if tail(r.get("manifest_path"), 3) != (attempt, name, "run_manifest.json"):
            diff.add("manifest_path")
    train_yaml = os.path.join(run_dir, "resolved_train.yaml")
    if not os.path.isfile(train_yaml):
        bad.append("resolved_train_missing")
    else:
        h = sha256(train_yaml)
        if h != r.get("resolved_train_sha256") or (readable and h != man.get("resolved_train_sha256")):
            diff.add("resolved_train_sha256")
    if not run_score:
        if any(r.get(f) for f in SCORE_FIELDS):
            bad.append("eval_without_scoring")
        return bad, diff
    score_yaml = os.path.join(run_dir, "resolved_score.yaml")
    if not os.path.isfile(score_yaml):
        bad.append("resolved_score_missing")
    elif readable and sha256(score_yaml) != man.get("resolved_score_sha256"):
        diff.add("resolved_score_sha256")
    if sm is None:
        bad.append("score_metrics_unreadable")
        return bad, diff
    n, pos = sm.get("n_predictions"), sm.get("n_positives")
    n, pos = (n if type(n) is int else None), (pos if type(pos) is int else None)  # bool and float rejected
    need = st.get("_compute_metrics", True)
    if sm.get("schema_version") != 1:
        bad.append("score_schema")
    if (sm.get("checkpoint_sha256") or "") != rec:
        bad.append("score_checkpoint_mismatch")
    if n is None or pos is None or n <= 0 or pos < 0 or pos > n or (need and not 0 < pos < n):
        bad.append("eval_counts")
    if need and not (in01(sm.get("average_precision")) and in01(sm.get("auroc"))):
        bad.append("eval_metrics")
    if not sm.get("predictions_path"):
        bad.append("predictions_path")
    diff.update(f for f, k in SCORE_FIELDS.items() if not same(r.get(f), sm.get(k)))
    return bad, diff


def prediction_digest(sm, score_yaml):
    """The pre-flight's composite-id digest (version 1) recomputed over a scored run's prediction file: SHA-256 of
    the sorted multiset of 64-bit pandas row hashes of (account, transaction id) as strings, with the same framing.
    Reads the file where the scorer wrote it, through the scorer's own filesystem helper."""
    import numpy as np
    import pandas as pd
    import pyarrow.parquet as pq
    if ROOT not in sys.path:  # scripts run from the runbook folder; the scorer's helpers live in the repo
        sys.path.insert(0, ROOT)
    from fraud.data.s3_utils import make_s3_filesystem, strip_scheme
    cfg = OmegaConf.load(score_yaml)
    acct, idcol = str(cfg.data.account_col), str(cfg.data.tie_break_col)
    fs = make_s3_filesystem(cfg.s3.cred_path)
    df = pq.read_table(strip_scheme(str(sm["predictions_path"])), filesystem=fs, columns=[acct, idcol]).to_pandas()
    h = np.sort(pd.util.hash_pandas_object(df[[acct, idcol]].astype(str), index=False).to_numpy())
    return hashlib.sha256(b"composite-id-uint64-multiset-v1" + len(h).to_bytes(8, "big")
                          + h.astype(">u8").tobytes()).hexdigest()


def check_cohort(contract, run_dir, sm):
    """Failed checks (names only) comparing a scored run with the pre-flight's evaluation split of the same range:
    equal row and positive counts, and an equal composite-id digest over the run's own prediction file."""
    score_yaml = os.path.join(run_dir, "resolved_score.yaml")
    try:
        e = OmegaConf.load(score_yaml).eval
        split = contract.get(f"eval_{e.file_start}_{e.file_end}")
    except Exception:
        return ["cohort_score_config_unreadable"]
    if not isinstance(split, dict):
        return ["cohort_not_in_preflight"]
    bad = []
    if sm.get("n_predictions") != split.get("rows") or sm.get("n_positives") != split.get("positives"):
        bad.append("cohort_counts")
    if split.get("composite_id_digest_version") != 1:
        return bad + ["cohort_digest_version"]
    try:
        if prediction_digest(sm, score_yaml) != split.get("composite_id_multiset_sha256"):
            bad.append("cohort_ids")
    except Exception:
        bad.append("cohort_predictions_unreadable")
    return bad


def verdict(bad, diff):
    parts = ([f"evidence_mismatch:{'+'.join(sorted(diff))}"] if diff else []) + ([f"invalid:{'+'.join(bad)}"] if bad else [])
    return ";".join(parts) or "ok"


def collect_attempt(attempt_dir, contract=None, contract_name="", identity=None):
    """Rows for every expected run. With a pre-flight contract, ok scored runs are also checked against the
    pre-flight's evaluation cohort; cohort_check records ok:<pre-flight folder>, failed, not_scored or not_requested.
    `identity` (config_identity()) fills manifest_sha256 and active_configs_sha256; spec_sha256 is the attempt's own
    ablation_spec.yaml."""
    attempt_dir = os.path.realpath(attempt_dir)
    rows, attempt = [], os.path.basename(attempt_dir)
    identity = identity or {}
    spec_path = os.path.join(attempt_dir, "ablation_spec.yaml")
    ident = {"manifest_sha256": identity.get("manifest_sha256", ""),
             "active_configs_sha256": identity.get("active_configs_sha256", ""),
             "spec_sha256": sha256(spec_path) if os.path.isfile(spec_path) else ""}
    try:
        names, run_score, phase = expected_runs(attempt_dir)
    except Exception as exc:
        return [{"attempt_dir": attempt_dir, "attempt": attempt, "run_name": "-",
                 "status": f"spec_unreadable:{type(exc).__name__}"}]
    if not names:
        return [{"attempt_dir": attempt_dir, "attempt": attempt, "run_name": "-", "status": "spec_expands_to_zero_runs"}]
    res_path = os.path.join(attempt_dir, "results.csv")
    found, duplicated = {}, set()
    if os.path.isfile(res_path):
        with open(res_path, newline="") as f:
            for r in csv.DictReader(f):
                if r.get("run_name") in found:
                    duplicated.add(r.get("run_name"))
                found[r.get("run_name")] = r
    peak = sweep_peak(attempt_dir)
    for name in names:
        r = found.get(name)
        run_dir = os.path.join(attempt_dir, name)
        st = settings(run_dir, phase)
        base = {"attempt_dir": attempt_dir, "attempt": attempt, "run_name": name, "run_score": run_score,
                "sweep_peak_gpu_mib": peak, **ident, **{k: v for k, v in st.items() if not k.startswith("_")}}
        if name in duplicated:
            rows.append({**base, "status": "invalid_results:duplicate_run_name", "runner_status": ""})
            continue
        if r is None:
            rows.append({**base, "status": PROVISIONAL, "runner_status": ""})
            continue
        man = load_json(os.path.join(run_dir, "run_manifest.json"))
        sm = load_json(os.path.join(run_dir, "score_metrics.json"))
        runner_status = (r.get("status") or "").strip() or "unknown"
        status, cohort = runner_status, ""
        if runner_status == "ok":
            bad, diff = check_ok_row(r, run_dir, run_score, st, man, sm)
            if not run_score:
                cohort = "not_scored"
            elif contract is None:
                cohort = "not_requested"
            elif not bad and not diff:
                cbad = check_cohort(contract, run_dir, sm or {})
                bad += cbad
                cohort = "failed" if cbad else f"ok:{contract_name}"
            status = verdict(bad, diff)
        man, sm = man or {}, sm or {}
        rows.append({**base, "status": status, "runner_status": runner_status, "train_rc": r.get("train_rc"),
                     "score_rc": r.get("score_rc"), "checkpoint_epoch": r.get("checkpoint_epoch"),
                     "checkpoint_step": r.get("checkpoint_step"), "valid_ap": r.get("best_valid_ap"),
                     "valid_auroc": r.get("best_valid_auroc"), "checkpoint_monitor_score": r.get("checkpoint_monitor_score"),
                     "eval_ap": sm.get("average_precision"), "eval_auroc": sm.get("auroc"),
                     "eval_rows": sm.get("n_predictions"), "eval_positives": sm.get("n_positives"),
                     "predictions_path": sm.get("predictions_path"), "checkpoint_sha256": r.get("checkpoint_sha256"),
                     "source_sha256": r.get("source_sha256"), "resolved_train_sha256": r.get("resolved_train_sha256"),
                     "started_utc": man.get("started_utc"), "finished_utc": man.get("finished_utc"),
                     "cohort_check": cohort})
    for extra in sorted(set(found) - set(names), key=str):
        rows.append({"attempt_dir": attempt_dir, "attempt": attempt, "run_name": extra, "status": "unexpected_row"})
    return rows


def hours(r):
    try:
        a = _dt.datetime.strptime(r["started_utc"], "%Y-%m-%dT%H:%M:%SZ")
        b = _dt.datetime.strptime(r["finished_utc"], "%Y-%m-%dT%H:%M:%SZ")
        return f"{(b - a).total_seconds() / 3600:.1f}"
    except Exception:
        return "-"


def f4(v):
    x = fnum(v)
    return f"{x:.4f}" if x is not None else "-"


def evidence_sha256(rec):
    """SHA-256 of the canonical JSON of a ledger record's evidence columns, as the ledger stores them (text)."""
    blob = json.dumps({c: rec[c] for c in EVIDENCE_COLS}, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(blob.encode()).hexdigest()


def current_rows(ledger):
    """{(attempt_dir, run_name): latest revision's row} of a v3 ledger. `ledger` is a path (read under a shared lock;
    a missing file has no rows) or an open ledger file its caller has locked."""
    if isinstance(ledger, (str, os.PathLike)):
        if not os.path.isfile(ledger):
            return {}
        with open(ledger, newline="") as f:
            fcntl.flock(f, fcntl.LOCK_SH)
            return current_rows(f)
    ledger.seek(0)
    lines = list(csv.reader(ledger))
    if lines and lines[0] != LEDGER_COLS:
        raise SystemExit(f"LEDGER SCHEMA MISMATCH in {ledger.name}: its header is not {LEDGER_SCHEMA}'s; nothing was "
                         f"appended. Older ledgers are never rewritten: pass a new --ledger file.")
    latest = {}
    for i, vals in enumerate(lines[1:], 2):
        r = dict(zip(LEDGER_COLS, vals))
        if len(vals) != len(LEDGER_COLS) or r["ledger_schema"] != LEDGER_SCHEMA or not r["revision"].isdigit():
            raise SystemExit(f"LEDGER ROW {i} MALFORMED in {ledger.name}: nothing was appended.")
        key = (r["attempt_dir"], r["run_name"])
        if key not in latest or int(r["revision"]) > int(latest[key]["revision"]):
            latest[key] = r
    return latest


def append_ledger(path, rows, stamp):
    """Record collected rows under an exclusive lock by the revision rules in the module docstring.
    Returns (appended, unchanged, conflicts); a conflict is (key, latest revision, its status, differing fields)."""
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    added, unchanged, conflicts = 0, 0, []
    with open(path, "a+", newline="") as f:
        fcntl.flock(f, fcntl.LOCK_EX)
        latest = current_rows(f)
        w = csv.DictWriter(f, fieldnames=LEDGER_COLS, extrasaction="raise")
        f.seek(0, os.SEEK_END)
        if f.tell() == 0:
            w.writeheader()
        for r in rows:
            rec = {c: "" if r.get(c) is None else str(r[c]) for c in EVIDENCE_COLS}
            rec["attempt_dir"] = os.path.realpath(rec["attempt_dir"])
            rec.update(ledger_schema=LEDGER_SCHEMA, collected_utc=stamp, evidence_sha256=evidence_sha256(rec))
            key = (rec["attempt_dir"], rec["run_name"])
            prev = latest.get(key)
            if prev is None:
                rec.update(revision="1", transition="new")
            elif prev["evidence_sha256"] == rec["evidence_sha256"]:
                unchanged += 1
                continue
            elif prev["status"] == PROVISIONAL:
                rec.update(revision=str(int(prev["revision"]) + 1),
                           transition="provisional_update" if rec["status"] == PROVISIONAL else "provisional_to_final")
            else:
                fields = [c for c in EVIDENCE_COLS if prev[c] != rec[c]] or ["evidence_sha256"]
                conflicts.append((key, prev["revision"], prev["status"], fields))
                continue
            w.writerow(rec)
            latest[key] = rec
            added += 1
        f.flush()
        os.fsync(f.fileno())
    return added, unchanged, conflicts


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("attempts", nargs="+", help="attempt directories <output_root>/<attempt>/")
    ap.add_argument("--ledger", default=os.path.join(ROOT, "runs", "run_log.csv"))
    ap.add_argument("--no-ledger", action="store_true")
    ap.add_argument("--out", default=None, help="folder for RETURN.txt (default runs/returns/<UTC time>)")
    ap.add_argument("--preflight", default=None,
                    help="a pre-flight output folder: scored runs must match its evaluation cohort (counts and ids)")
    args = ap.parse_args()
    contract, contract_name = None, ""
    if args.preflight:
        contract_name = os.path.basename(os.path.normpath(args.preflight))
        contract = load_json(os.path.join(args.preflight, "data_contract.json"))
        if contract is None:
            sys.exit(f"--preflight {args.preflight}: data_contract.json missing or unreadable; nothing was collected")
    identity = config_identity(args.preflight)
    stamp = _dt.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    rows, seen = [], set()
    for a in args.attempts:
        real = os.path.realpath(a)
        if real in seen:
            print(f"collected once: {a} names an attempt folder already given")
            continue
        seen.add(real)
        if not os.path.isfile(os.path.join(real, "ablation_spec.yaml")):
            rows.append({"attempt_dir": real, "attempt": os.path.basename(real), "run_name": "-",
                         "status": "not_an_attempt_dir"})
            continue
        rows += collect_attempt(real, contract, contract_name, identity)
    lines = [f"RETURN {stamp} | {len(rows)} run(s) | valid = checkpoint-paired (PR #4 contract) | GPU = sweep peak",
             (f"evaluation cohort of scored runs checked against pre-flight {contract_name} (counts and id digest)"
              if contract is not None else "evaluation cohort NOT checked against a pre-flight (no --preflight)"),
             f"configuration identity: manifest {identity['manifest_sha256'][:12] or '-'}, active configs "
             f"{identity['active_configs_sha256'][:12] or '-'} ({identity['source']})",
             f"{'attempt/run':<44} {'status':<10} {'ep':>3} {'vAP':>7} {'vAUC':>7} {'eAP':>7} {'eAUC':>7} "
             f"{'rows':>9} {'pos':>5} {'hrs':>5} {'GiB':>4}"]
    for r in rows:
        tag = f"{r.get('attempt', '')[:16]}/{r.get('run_name', '')}"[-44:]
        gib = f"{r['sweep_peak_gpu_mib'] / 1024:.0f}" if r.get("sweep_peak_gpu_mib") else "-"
        lines.append(f"{tag:<44} {str(r['status'])[:10]:<10} {str(r.get('checkpoint_epoch') or '-'):>3} "
                     f"{f4(r.get('valid_ap')):>7} {f4(r.get('valid_auroc')):>7} {f4(r.get('eval_ap')):>7} "
                     f"{f4(r.get('eval_auroc')):>7} {str(r.get('eval_rows') or '-'):>9} {str(r.get('eval_positives') or '-'):>5} "
                     f"{hours(r):>5} {gib:>4}")
        if str(r["status"]) != "ok" and len(str(r["status"])) > 10:
            lines.append(f"   status: {r['status']}")
    n_ok = sum(r["status"] == "ok" for r in rows)
    lines.append(f"{n_ok} of {len(rows)} ok")
    conflicts = []
    if not args.no_ledger:
        added, unchanged, conflicts = append_ledger(args.ledger, [r for r in rows if r.get("run_name") != "-"], stamp)
        for (att, name), rev, status, fields in conflicts:
            lines.append(f"CONFLICT {att} {name}: ledger revision {rev} is final ({status}); the new evidence "
                         f"differs in {'+'.join(fields)}; not appended")
        lines.append(f"ledger {os.path.basename(args.ledger)}: +{added} appended, {unchanged} unchanged, "
                     f"{len(conflicts)} conflict(s)")
    else:
        lines.append("ledger: not written (--no-ledger)")
    accepted = bool(rows) and n_ok == len(rows) and not conflicts
    lines.append("ACCEPTED: every run ok" + ("" if args.no_ledger else " and recorded") if accepted
                 else "NOT ACCEPTED: see the status column" + (" and the CONFLICT lines" if conflicts else ""))
    text = "\n".join(lines) + "\n"
    out = args.out or os.path.join(ROOT, "runs", "returns", stamp)
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "RETURN.txt"), "w") as f:
        f.write(text)
    print(text, end="")
    sys.exit(0 if accepted else 1)


if __name__ == "__main__":
    main()
