#!/usr/bin/env python3
# Written by reviewer (2026-10-07), version 2 after reviewer's review of 5d053e4; version 3 (2026-10-11, first release:
# inherited harness state, ST13 host memory, RG-F02 step return folder, RG-F12 interpreter, smoke hooks). Requires
# PR #4's attempt-isolated runners. Runs ONE committed sweep spec with the project's own run_ablations.py (which
# creates a new <output_root>/<attempt>/ and never overwrites), samples GPU memory and host memory for the whole
# sweep, then validates and records the attempt with collect_returns.py. On the pod the spec runs unchanged.
"""Run one sweep step.

    python runbook/2026-10-07/run_step.py --phase phase4a --spec ft_decisions_h0_seeds.yaml

Prints RETURN_DIR=<this step's return folder> and ATTEMPT_DIR=<path> as its last lines. Exit code: 0 only if the
runner and the collector both succeed; 3 when it stopped before starting (inherited harness state, below).
--sandbox DIR (reviewer's CPU harness only) runs a derived copy of the spec with documented size reductions.

Inherited harness state: RUNBOOK_SANDBOX, BATCH1_SKIP or PREFLIGHT_ARGS set in the environment (or --sandbox given)
stop this script with a plain message unless RUNBOOK_BANK_OVERRIDES=1 is also set; the pre-flight reports the same
as FAIL. The synthetic harness sets both.

The step's return folder runs/returns/<spec>_<stamp>/ is created when the step starts and holds:
  STEP.txt     spec, interpreter, start time; the attempt folder as soon as the runner creates it; exit and peaks
               at the end. With --batch-dir it is mirrored into <batch dir>/steps/<spec>_<stamp>/ at every update,
               so an interrupted step leaves its attempt folder on record.
  RETURN.txt   the collector's return (ledger line, CONFLICT lines, ACCEPTED or NOT ACCEPTED), then the step lines:
               interpreter, runner exit and hours, host peak RSS and GPU peak; for a spec whose name contains
               "smoke", every run's per-epoch training loss and validation metrics from training_metrics.csv.
Host memory (ST13): the resident set of the runner process and all its descendants, summed, sampled every
--sample-seconds (default 30, the GPU cadence) into runs/gpu/<spec>_<stamp>.host_rss.csv and copied into the attempt
folder as host_rss_sweep.csv. The collector does not read it, so it never changes ledger evidence.
"""
import argparse
import csv
import os
import re
import shutil
import subprocess
import sys
import threading
import time

from omegaconf import OmegaConf

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
HERE = os.path.dirname(os.path.abspath(__file__))
SANDBOX_OVERRIDES = [
    "training.num_workers=0", "training.max_epochs=1", "training.accelerator=cpu", "training.precision=32-true",
    "model.input_embed_dim=16", "model.num_attn_blocks=1", "model.num_txn_blocks=1", "model.num_seq_blocks=1",
]
HARNESS_VARS = ("RUNBOOK_SANDBOX", "BATCH1_SKIP", "PREFLIGHT_ARGS")
STOP_INHERITED = 3
SMOKE_COLUMNS = ("train_loss", "valid_ap", "valid_auroc")


def shrink_batch(ov, scale):
    m = re.fullmatch(r"training\.batch_size=(\d+)", ov.strip())
    return f"training.batch_size={max(8, int(m.group(1)) // scale)}" if m else ov


def inherited_state_message(env=None, sandbox_arg=None):
    """The plain message when harness state is inherited without the bank-side flag, else None."""
    env = os.environ if env is None else env
    if env.get("RUNBOOK_BANK_OVERRIDES") == "1":
        return None
    present = [v for v in HARNESS_VARS if env.get(v)]
    if sandbox_arg and "RUNBOOK_SANDBOX" not in present:
        present.append("--sandbox")
    if not present:
        return None
    return (f"STOPPED BEFORE START: {', '.join(present)} is set. These belong to reviewer's test harness, not to a bank "
            "run: the sandbox setting shrinks every run to a one-epoch CPU model. Unset them and start again. Only on "
            "review advice, set RUNBOOK_BANK_OVERRIDES=1 to keep them; the pre-flight records that as "
            "an override. Nothing was run.")


def child_env():
    """The project's scripts add the repository root to sys.path but not src/ (vendored pytorch_tabular).
    Add src/ only when this interpreter cannot already import pytorch_tabular, so an installed copy is never shadowed."""
    env = dict(os.environ)
    probe = subprocess.run([sys.executable, "-c", "import pytorch_tabular"], cwd=ROOT, env=env,
                           capture_output=True)
    if probe.returncode != 0 and os.path.isdir(os.path.join(ROOT, "src", "pytorch_tabular")):
        env["PYTHONPATH"] = os.pathsep.join([os.path.join(ROOT, "src"), ROOT] +
                                            ([env["PYTHONPATH"]] if env.get("PYTHONPATH") else []))
    return env


def attempts_in(root):
    if not os.path.isdir(root):
        return set()
    return {d for d in os.listdir(root) if os.path.isdir(os.path.join(root, d))}


def runner_path(phase):
    return os.path.join(ROOT, "YOUR_PACKAGE", phase, "scripts", "run_ablations.py")


def process_tree_rss_kib(pid):
    """(summed resident KiB, process count) of pid and all its descendants, read from /proc (no external command).
    None if /proc cannot be listed or pid is not there."""
    try:
        entries = [e for e in os.listdir("/proc") if e.isdigit()]
    except OSError:
        return None
    children, rss = {}, {}
    for e in entries:
        try:
            with open(f"/proc/{e}/stat") as f:
                pp = int(f.read().rsplit(")", 1)[1].split()[1])
            r = 0
            with open(f"/proc/{e}/status") as f:
                for line in f:
                    if line.startswith("VmRSS:"):
                        r = int(line.split()[1])
                        break
        except (OSError, ValueError, IndexError):  # the process ended while being read
            continue
        p = int(e)
        children.setdefault(pp, []).append(p)
        rss[p] = r
    if pid not in rss:
        return None
    total, count, stack = 0, 0, [pid]
    while stack:
        p = stack.pop()
        total += rss.get(p, 0)
        count += 1
        stack.extend(children.get(p, []))
    return total, count


class HostSampler(threading.Thread):
    """Samples the runner's process-tree RSS every `seconds` into a CSV (ST13); also notices the new attempt folder."""

    def __init__(self, pid, path, seconds, on_tick=None):
        super().__init__(daemon=True)
        self.pid, self.path, self.seconds, self.on_tick = pid, path, seconds, on_tick
        self.stop_event = threading.Event()
        self.samples, self.peak_mib = 0, None

    def sample(self):
        got = process_tree_rss_kib(self.pid)
        stamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        with open(self.path, "a") as f:
            if got is None:
                f.write(f"{stamp},,\n")
            else:
                kib, count = got
                mib = kib / 1024
                f.write(f"{stamp},{mib:.1f},{count}\n")
                self.samples += 1
                self.peak_mib = max(self.peak_mib or 0.0, mib)
        if self.on_tick:
            self.on_tick()

    def run(self):
        with open(self.path, "w") as f:
            f.write("timestamp_utc,rss_mib_process_tree,processes\n")
        while True:
            self.sample()
            if self.stop_event.wait(self.seconds):
                break
        self.sample()

    def stop(self):
        self.stop_event.set()
        self.join(timeout=60)


def gpu_peak_mib(path):
    """Peak memory.used in MiB from an nvidia-smi CSV, or None when there are no samples."""
    if not os.path.isfile(path):
        return None
    peak = None
    with open(path, errors="replace") as f:
        for line in f:
            parts = [x.strip() for x in line.split(",")]
            if len(parts) >= 2 and parts[1].endswith("MiB"):
                try:
                    peak = max(peak or 0, int(float(parts[1][:-3])))
                except ValueError:
                    pass
    return peak


def smoke_lines(attempt_dir):
    """Per-epoch training loss and validation metrics of every run, as the trainer logged them (training_metrics.csv).
    Numbers only; nothing is recomputed."""
    lines = []
    for run in sorted(d for d in attempts_in(attempt_dir)):
        p = os.path.join(attempt_dir, run, "training_metrics.csv")
        if not os.path.isfile(p):
            lines.append(f"smoke {run}: training_metrics.csv missing")
            continue
        with open(p, newline="") as f:
            rows = list(csv.DictReader(f))
        cols = [c for c in (rows[0].keys() if rows else []) if c in SMOKE_COLUMNS or c.endswith("loss")]
        lines.append(f"smoke {run}: {len(rows)} epoch row(s); columns epoch step {' '.join(cols)}")
        for r in rows:
            vals = " ".join(f"{c}={r.get(c, '')}" for c in cols)
            lines.append(f"smoke {run} epoch {r.get('epoch', '-')} step {r.get('step', '-')} {vals}")
    return lines


class StepRecord:
    """STEP.txt in the step's return folder, mirrored into the batch folder's steps/ at every update."""

    def __init__(self, out, batch_dir):
        self.out = out
        self.mirror = os.path.join(batch_dir, "steps", os.path.basename(out)) if batch_dir else None
        self.fields = []

    def set(self, key, value):
        self.fields = [(k, v) for k, v in self.fields if k != key] + [(key, value)]
        text = "".join(f"{k}: {v}\n" for k, v in self.fields)
        for folder in filter(None, (self.out, self.mirror)):
            os.makedirs(folder, exist_ok=True)
            tmp = os.path.join(folder, "STEP.txt.tmp")
            with open(tmp, "w") as f:
                f.write(text)
            os.replace(tmp, os.path.join(folder, "STEP.txt"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase", required=True, choices=["phase4a", "phase4b"])
    ap.add_argument("--spec", required=True, help="file name under YOUR_PACKAGE/<phase>/configs/")
    ap.add_argument("--sandbox", default=os.environ.get("RUNBOOK_SANDBOX"), help="sandbox folder (CPU harness only)")
    ap.add_argument("--batch-scale", type=int, default=32)
    ap.add_argument("--preflight", default=None,
                    help="this batch's pre-flight output folder; scored runs are checked against its evaluation cohort")
    ap.add_argument("--batch-dir", default=None, help="the batch return folder; STEP.txt is mirrored into its steps/")
    ap.add_argument("--sample-seconds", type=int, default=30, help="GPU and host memory sampling interval")
    ap.add_argument("--ledger", default=None, help="ledger file for the collector (default: the collector's own, "
                    "runs/run_log.csv; the sandbox uses its own ledger)")
    args = ap.parse_args()

    stop = inherited_state_message(sandbox_arg=args.sandbox)
    if stop:
        print(stop, flush=True)
        sys.exit(STOP_INHERITED)

    spec_path = os.path.join(ROOT, "YOUR_PACKAGE", args.phase, "configs", args.spec)
    spec = OmegaConf.load(spec_path)
    root = str(spec.output_root)
    ledger_args = ["--ledger", args.ledger] if args.ledger else []
    if args.sandbox:
        sb = os.path.abspath(args.sandbox)
        root = os.path.join(sb, "ablations", os.path.basename(root.rstrip("/")))
        spec.output_root = root
        spec.results_csv = os.path.join(root, "results.csv")
        base_bs = int(OmegaConf.load(os.path.join(ROOT, str(spec.base_config))).training.batch_size)
        common = [shrink_batch(str(o), args.batch_scale) for o in spec.get("common_overrides", [])]
        if not any(str(o).startswith("training.batch_size=") for o in common):
            common.append(f"training.batch_size={max(8, base_bs // args.batch_scale)}")
        spec.common_overrides = common + SANDBOX_OVERRIDES
        for axis in spec.get("axes", {}):
            for opt in spec.axes[axis]:
                spec.axes[axis][opt] = [shrink_batch(str(o), args.batch_scale) for o in spec.axes[axis][opt]]
        os.makedirs(os.path.join(sb, "specs"), exist_ok=True)
        spec_path = os.path.join(sb, "specs", f"{args.phase}_{args.spec}")
        OmegaConf.save(spec, spec_path)
        ledger_args = ["--ledger", os.path.join(sb, "runs", "run_log.csv")]
    abs_root = root if os.path.isabs(root) else os.path.join(ROOT, root)
    before = attempts_in(abs_root)
    stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    name = f"{os.path.splitext(args.spec)[0]}_{stamp}"
    base = args.sandbox or ROOT
    gpu_tmp = os.path.join(base, "runs", "gpu", f"{name}.csv")
    host_tmp = os.path.join(base, "runs", "gpu", f"{name}.host_rss.csv")
    os.makedirs(os.path.dirname(gpu_tmp), exist_ok=True)
    out = os.path.join(base, "runs", "returns", name)
    os.makedirs(out, exist_ok=True)
    rec = StepRecord(out, args.batch_dir)
    rec.set("spec", f"{args.phase}/{args.spec}")
    rec.set("interpreter", sys.executable)
    rec.set("started_utc", time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
    rec.set("attempt_dir", "pending")
    print(f"== {args.phase}/{args.spec} (output root {os.path.relpath(abs_root, ROOT)}; interpreter {sys.executable})",
          flush=True)
    sampler = None
    if shutil.which("nvidia-smi") and not args.sandbox:
        sampler = subprocess.Popen(["nvidia-smi", "--query-gpu=timestamp,memory.used,utilization.gpu",
                                    "--format=csv", "-l", str(args.sample_seconds)],
                                   stdout=open(gpu_tmp, "w"), stderr=subprocess.DEVNULL)
    t0 = time.time()
    log_path = os.path.join(base, "runs", "logs", f"{name}.runner.log")
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    seen = {"attempt": None}

    def notice_attempt():
        if seen["attempt"] is None:
            new = sorted(attempts_in(abs_root) - before)
            if new:
                seen["attempt"] = new[0]
                rec.set("attempt_dir", os.path.join(abs_root, new[0]))

    with open(log_path, "w") as log:
        proc = subprocess.Popen([sys.executable, runner_path(args.phase), "--config", spec_path], cwd=ROOT,
                                stdout=log, stderr=subprocess.STDOUT, env=child_env())
        host = HostSampler(proc.pid, host_tmp, args.sample_seconds, on_tick=notice_attempt)
        host.start()
        rc = proc.wait()
        host.stop()
    if sampler:
        sampler.terminate()
        sampler.wait(timeout=30)
    hours = (time.time() - t0) / 3600
    new = sorted(attempts_in(abs_root) - before)
    rec.set("runner_exit", rc)
    rec.set("hours", f"{hours:.2f}")
    print(f"   runner exit {rc} after {hours:.2f} h; runner log {os.path.relpath(log_path, ROOT)}", flush=True)
    peak_host = host.peak_mib
    peak_gpu = gpu_peak_mib(gpu_tmp)
    host_line = (f"step host peak RSS: {peak_host:.0f} MiB summed over the runner process tree (shared pages counted "
                 f"once per process, so an upper bound); {host.samples} sample(s) every {args.sample_seconds} s"
                 if peak_host is not None else "step host peak RSS: no samples (/proc unreadable)")
    gpu_line = f"step GPU peak: {peak_gpu} MiB (nvidia-smi samples)" if peak_gpu is not None else "step GPU peak: no samples"
    rec.set("host_peak_rss_mib", f"{peak_host:.0f}" if peak_host is not None else "unknown")
    rec.set("gpu_peak_mib", peak_gpu if peak_gpu is not None else "unknown")
    if len(new) != 1:
        print(f"   NO SINGLE NEW ATTEMPT FOLDER under {os.path.relpath(abs_root, ROOT)} (found {len(new)}); "
              f"the runner refused or failed before starting. See the runner log.", flush=True)
        rec.set("attempt_dir", "none" if not new else f"ambiguous ({len(new)} new folders)")
        rec.set("finished_utc", time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
        with open(os.path.join(out, "RETURN.txt"), "w") as f:
            f.write(f"RETURN {stamp} | no attempt folder: the runner exited {rc} without creating one\n"
                    f"step interpreter: {sys.executable}\n{host_line}\n{gpu_line}\nNOT ACCEPTED: no attempt\n")
        print(f"RETURN_DIR={out}")
        print("ATTEMPT_DIR=")
        sys.exit(rc or 2)
    attempt_dir = os.path.join(abs_root, new[0])
    rec.set("attempt_dir", attempt_dir)
    if os.path.isfile(gpu_tmp) and os.path.getsize(gpu_tmp) > 0:
        shutil.copyfile(gpu_tmp, os.path.join(attempt_dir, "gpu_sweep.csv"))
    if os.path.isfile(host_tmp):
        shutil.copyfile(host_tmp, os.path.join(attempt_dir, "host_rss_sweep.csv"))
    pf_args = ["--preflight", args.preflight] if args.preflight else []
    col = subprocess.run([sys.executable, os.path.join(HERE, "collect_returns.py"), attempt_dir, "--out", out,
                          *ledger_args, *pf_args], cwd=ROOT, env=child_env())
    lines = [f"step interpreter: {sys.executable}", f"step attempt: {attempt_dir}",
             f"step runner exit {rc} after {hours:.2f} h", host_line, gpu_line]
    if "smoke" in args.spec.lower():
        lines += smoke_lines(attempt_dir)
    with open(os.path.join(out, "RETURN.txt"), "a") as f:
        f.write("\n".join(lines) + "\n")
    print("\n".join(lines), flush=True)
    rec.set("collector_exit", col.returncode)
    rec.set("finished_utc", time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
    print(f"RETURN_DIR={out}")
    print(f"ATTEMPT_DIR={attempt_dir}", flush=True)
    sys.exit(rc or col.returncode)


if __name__ == "__main__":
    main()
