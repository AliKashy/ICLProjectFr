#!/usr/bin/env bash
# Smoke run before batch 1 (reviewer, 2026-10-11, first release). reference's docs/phase4_sequential_plan.md section 9 item 1:
# "Smoke: a few files, N=5, 1 to 2 epochs: loss decreases, valid_ap and valid_auroc sane, RSS bounded, causal windows
# correct (no future leakage; spot-check a few samples)". reviewer (PR #6 comment 6103393559): a bank-side smoke, not the
# CPU harness. Run from the new code folder, in the activated Python environment the pre-flight ran in:
#     bash runbook/2026-10-07/smoke.sh                     (PYTHON=<interpreter> to name it; default python3)
# Order: pre-flight (RESULT PASS required; anything else stops before training), then two one-cell specs through
# run_step.py, the same runner batch 1 uses (a NEW attempt folder each time, never overwritten):
#   A  YOUR_PACKAGE/phase4a/configs/ft_decisions_smoke.yaml       training files 1 to 2, validation file 4950, history 5,
#                                                          2 epochs, the base settings otherwise (validation only)
#   B  YOUR_PACKAGE/phase4b/configs/ft_decisions_hier_smoke.yaml  the same for Architecture B
# then smoke_checks.py judges both attempts. The return folder runs/returns/smoke_<time>/ exists from the start and
# holds SMOKE_RETURN.txt (per cell: loss per epoch and whether it fell, valid_ap and valid_auroc with "sane" defined,
# peak host RSS and GPU memory, the causal-window spot check, digests; one plain line per failed check, then
# RESULT: PASS or RESULT: FAIL as the last line), SMOKE_STATUS.txt (one line per event), the complete pre-flight
# copy, each step's whole return under steps/ with its runner log and memory samples, each cell's attempt folder under
# attempts/, and per cell training_metrics.csv and run_summary.txt. Send that folder. Only model checkpoints (*.ckpt)
# and prediction files (*.parquet) stay on the pod (the owner's answer to OQ-24). Runtime: not measured.
# Smoke rows are never ranked by the leaderboard (their spec, folder and run names carry "smoke").
# reviewer's test harness only (stops the launch unless RUNBOOK_BANK_OVERRIDES=1 is set; the pre-flight records that):
#     RUNBOOK_SANDBOX=<folder>, BATCH1_SKIP="<spec names>", PREFLIGHT_ARGS="<pre-flight flags>", A_H10_COMPARATOR=<folder>.
set -uo pipefail
cd "$(dirname "$0")/../.."
HERE=runbook/2026-10-07
PY="${PYTHON:-python3}"

# Inherited harness state: these variables shrink or skip runs; in a bank shell they are a mistake unless said otherwise.
if [ "${RUNBOOK_BANK_OVERRIDES:-}" != "1" ]; then
  present=""
  for v in RUNBOOK_SANDBOX BATCH1_SKIP PREFLIGHT_ARGS A_H10_COMPARATOR; do [ -n "${!v:-}" ] && present="$present $v"; done
  if [ -n "$present" ]; then
    echo "STOPPED BEFORE START:$present is set. These belong to reviewer's test harness, not to a bank run (the sandbox"
    echo "setting shrinks every run to a small CPU model). Unset them and start again. Only on reviewer's or reviewer's"
    echo "advice, set RUNBOOK_BANK_OVERRIDES=1 to keep them; the pre-flight records that as an override. Nothing was run."
    exit 1
  fi
fi
SB="${RUNBOOK_SANDBOX:-}"
PF=runs/preflight; RET=runs/returns
[ -n "$SB" ] && { PF="$SB/preflight"; RET="$SB/returns"; }
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
OUT="$RET/smoke_$STAMP"
mkdir -p "$OUT/steps" || { echo "cannot create the return folder $OUT; nothing was run"; exit 1; }
status() { echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) $*" >> "$OUT/SMOKE_STATUS.txt"; }
# Every file a step makes goes into the return, except model checkpoints (*.ckpt) and prediction files (*.parquet),
# which stay on the pod (the owner's answer to OQ-24, OWNER_QA thirtieth message).
copy_tree() {  # copy_tree <source folder> <destination folder>
  [ -d "$1" ] || return 0
  mkdir -p "$2"
  (cd "$1" && find . -type f ! -name '*.ckpt' ! -name '*.parquet' -print0) | while IFS= read -r -d '' f; do
    mkdir -p "$2/$(dirname "$f")" && cp -p "$1/$f" "$2/$f"
  done
}
copy_step_files() {  # copy_step_files <step return dir> <attempt dir or empty> <return folder>
  local ret="$1" dir="$2" out="$3" name runs
  [ -n "$ret" ] && [ -d "$ret" ] || return 0
  name=$(basename "$ret"); runs=$(dirname "$(dirname "$ret")")
  copy_tree "$ret" "$out/steps/$name"
  for f in "$runs/logs/$name.runner.log" "$runs/gpu/$name.csv" "$runs/gpu/$name.host_rss.csv"; do
    [ -f "$f" ] && cp -p "$f" "$out/steps/$name/"
  done
  [ -n "$dir" ] && copy_tree "$dir" "$out/attempts/$(basename "$dir")"
}
PYPATH=$(command -v "$PY" 2>/dev/null || echo "$PY")
status "smoke started: interpreter $PYPATH"
echo "smoke return folder: $OUT (send this folder when the smoke ends or stops)"

CELLS=("phase4a ft_decisions_smoke.yaml" "phase4b ft_decisions_hier_smoke.yaml")
finish() {  # $1 = the pre-flight result as read; the return is written whatever happened, then the exit code follows it
  pfres="$1"; args=()
  [ -n "$PFDIR" ] && args+=(--preflight "$PFDIR")
  for step in "${CELLS[@]}"; do
    set -- $step
    args+=(--cell "$1" "$2" "${ATTEMPT[$2]:--}")
  done
  "$PY" "$HERE/smoke_checks.py" --out "$OUT" --preflight-result "$pfres" --interpreter "$PYPATH" "${args[@]}"; rc=$?
  status "smoke finished: smoke_checks exit $rc (0 = RESULT: PASS)"
  echo "Smoke finished: $([ $rc -eq 0 ] && echo 'RESULT: PASS' || echo 'RESULT: FAIL (see the FAILED lines above)'); send $OUT/"
  exit $rc
}
declare -A ATTEMPT=()
PFDIR=""

# Pre-flight: exit 0 and a RESULT PASS line in SUMMARY.txt, or nothing is trained (the same gate as batch1.sh).
pfout=$("$PY" "$HERE/preflight_pod.py" --out-root "$PF" ${PREFLIGHT_ARGS:-} | tee >(cat >&2)); pfrc=$?
PFDIR=$(printf '%s\n' "$pfout" | sed -n 's/^PREFLIGHT_DIR=//p' | tail -1)
RESULT=""
if [ -n "$PFDIR" ] && [ -d "$PFDIR" ]; then
  PFCOPY="$OUT/preflight_$(basename "$PFDIR")"; mkdir -p "$PFCOPY"
  cp -rp "$PFDIR/." "$PFCOPY/"
  echo "pre-flight folder for this smoke: $PFDIR (copied into $PFCOPY)"
  [ -f "$PFDIR/SUMMARY.txt" ] && RESULT=$(grep -E '^RESULT:? (PASS|FAIL)' "$PFDIR/SUMMARY.txt" | tail -1 | sed -E 's/^RESULT:? (PASS|FAIL).*/\1/')
else
  PFDIR=""
fi
if [ $pfrc -ne 0 ] || [ "$RESULT" != "PASS" ] || [ ! -f "$PFDIR/data_contract.json" ]; then
  status "stopped at the pre-flight: exit $pfrc, RESULT ${RESULT:-line missing}, folder ${PFDIR:-not found}"
  echo "PRE-FLIGHT FAILED (exit $pfrc, RESULT ${RESULT:-line missing}): nothing was trained. Send the folder $OUT/ (it holds the complete pre-flight copy)."
  finish "exit $pfrc, RESULT ${RESULT:-line missing}"
fi
echo "pre-flight RESULT PASS: the two smoke cells run now"

for step in "${CELLS[@]}"; do
  set -- $step
  status "started $2"
  # Echo the step's output through the inherited stderr descriptor (`tee /dev/stderr` would truncate a console log).
  out=$("$PY" "$HERE/run_step.py" --phase "$1" --spec "$2" --preflight "$PFDIR" | tee >(cat >&2)); rc=$?
  dir=$(printf '%s\n' "$out" | sed -n 's/^ATTEMPT_DIR=//p' | tail -1)
  ret=$(printf '%s\n' "$out" | sed -n 's/^RETURN_DIR=//p' | tail -1)
  [ -n "$dir" ] && ATTEMPT[$2]="$dir"
  copy_step_files "$ret" "$dir" "$OUT"
  status "finished $2: run_step exit $rc; attempt ${dir:-none}; return ${ret:-none}"
  [ $rc -ne 0 ] && echo "CELL $2: the runner or the collector did not succeed (exit $rc); the checks below say what exists"
done
finish PASS
