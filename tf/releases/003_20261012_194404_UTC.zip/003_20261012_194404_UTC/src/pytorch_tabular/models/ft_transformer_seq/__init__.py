"""Placeholder for sequential FT-Transformer Model (Phase 2)."""
# TODO: Implement FTTransformerSeqBackbone
# - Accepts sequence of tokenized transactions
# - Inserts SEP tokens between transactions
# - Appends CLS token
# - Supports optional causal attention masking
# - Outputs CLS representation for classification
