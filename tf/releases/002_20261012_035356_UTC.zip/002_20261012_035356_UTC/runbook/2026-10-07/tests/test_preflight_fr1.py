# reviewer, 2026-10-11. First-release regression tests for preflight_pod.py, make_source_manifest.py and
# collect_returns.py (FIRST_RELEASE_SCOPE v2.2 section 2: ST01 R-031, RUN-03 R-029, RUN-10 R-043, RG-F11, RG-F12,
# the inherited harness state, the first-return diagnostics). Every new FAIL path is simulated here (missing module,
# missing spec, fake nvidia-smi with a foreign process, no GPU, YAML drift, harness variable set, credential path
# missing, pytest missing, a required test file that cannot be collected) and one clean configuration passes.
# Synthetic files and fake commands only; no network, no GPU, no bank data.
#     PYTHONPATH=src:. python -m pytest -q -p no:cacheprovider runbook/2026-10-07/tests/test_preflight_fr1.py
import ast
import contextlib
import hashlib
import importlib.util
import io
import json
import os
import re
import subprocess
import sys
import types
from pathlib import Path
from unittest.mock import patch

import fsspec
import pandas as pd
import pytest
import torch
from omegaconf import OmegaConf

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[1]
SENTINEL = "SENTINEL_CREDENTIAL_VALUE"


def fresh():
    s = importlib.util.spec_from_file_location(f"pf_fr1_{os.urandom(4).hex()}", HERE / "preflight_pod.py")
    m = importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return m


def quiet(fn, *a, **k):
    with contextlib.redirect_stdout(io.StringIO()):
        return fn(*a, **k)


def fake_smi(tmp_path, body):
    """A stand-in nvidia-smi: prints `body` for the compute-apps query."""
    p = tmp_path / "nvidia-smi"
    p.write_text("#!/bin/sh\n" + body + "\n")
    p.chmod(0o755)
    return str(p)


def requirements(tmp_path, text="torch>=2.0\npytorch-lightning>=2.0,<3\nfakepkg-missing>=1.0  # a comment\n"
                                "lazy-missing-pkg\npytest\nrequests\npytorch-tabnet\n"):
    p = tmp_path / "requirements-pod.txt"
    p.write_text(text)
    return str(p)


def no_harness_vars(monkeypatch, pf):
    for v in pf.HARNESS_VARS + ("RUNBOOK_BANK_OVERRIDES",):
        monkeypatch.delenv(v, raising=False)


def no_optional_warns(pf):
    """The clean paths must not depend on which optional packages (pytorch_tabular, requests, pytorch_tabnet) or
    pyproject dependencies this machine has: on a pod without one of them those are WARNs by design, and the
    pre-flight runs this file as a required suite, so a test that counts them would turn that WARN into a FAIL (F1)."""
    pf.optional_missing = lambda pkg: None
    pf.check_dependencies = pf.guarded("dependency ranges")(lambda out: pf.say("PASS", "dependency ranges (stubbed in this test)"))


def result_line(summary, fails, overrides):
    """True when SUMMARY.txt's last line carries this FAIL count and overrides field (the WARN count is not compared)."""
    verdict = "PASS" if fails == 0 else "FAIL"
    return re.fullmatch(rf"RESULT {verdict} \| {fails} FAIL, \d+ WARN \| overrides: {re.escape(overrides)} \| exit \d", summary[-1]) is not None


def gpu(monkeypatch, visible, name="FakeGPU"):
    monkeypatch.setattr(torch.cuda, "is_available", lambda: visible)
    monkeypatch.setattr(torch.cuda, "get_device_name", lambda i=0: name)
    monkeypatch.setattr(torch.cuda, "get_device_properties", lambda i=0: types.SimpleNamespace(name=name))
    monkeypatch.setattr(torch.cuda, "mem_get_info", lambda i=0: (1 << 30, 2 << 30))


# ---------------------------------------------------------------- ST01: the batch specs come from the scripts
def test_batch_specs_are_read_from_the_batch_scripts(tmp_path):
    pf = fresh()
    named = set()
    for script in pf.BATCH_SCRIPTS:
        named |= set(re.findall(r'"(phase4[ab]) (ft_decisions\w*\.yaml)"', (HERE / script).read_text()))
    assert named and {(ph, n) for ph, names in pf.SPECS.items() for n in names} == named
    (tmp_path / "batch1.sh").write_text('for step in "phase4a ft_decisions_x.yaml" "phase4b ft_decisions_y.yaml"; do\n')
    assert pf.specs_in_batch_scripts(str(tmp_path)) == {"phase4a": ["ft_decisions_x.yaml"], "phase4b": ["ft_decisions_y.yaml"]}


@pytest.mark.parametrize("override", [False, True])
def test_missing_batch_spec_fails_unless_overridden(tmp_path, override):
    pf = fresh()
    pf.SPECS = {"phase4a": ["ft_decisions_h0.yaml", "ft_decisions_not_there.yaml"], "phase4b": []}
    pf.SMOKE_SPECS = {"phase4a": [], "phase4b": []}
    if override:
        pf.ALLOW_WARN_ONLY.add("spec")
    quiet(pf.check_specs, str(tmp_path))
    msg = "phase4a/ft_decisions_not_there.yaml: a spec named by batch1.sh or batch2.sh is missing"
    if override:
        assert pf.FAILS == [] and pf.WARNS == [f"OVERRIDE --allow-warn-only spec: {msg}"] and pf.OVERRIDES_USED == ["spec"]
    else:
        assert pf.FAILS == [msg] and pf.OVERRIDES_USED == []
    assert any(line.startswith("PASS") and "ft_decisions_h0.yaml" in line for line in pf.LINES)


@pytest.mark.parametrize("override,fails", [
    (["data.train_start=101", "data.train_end=102", "data.val_start=4951", "eval.file_end=8001"], False),  # ranges exempt
    (["artifacts.version=2"], True),                                                                         # not a range
])
def test_smoke_specs_record_their_ranges_but_still_bind_the_other_keys(tmp_path, override, fails):
    """The two smoke specs are exempt from the range comparison by name; every other probed key is still compared."""
    pf = fresh()
    pf.SPECS = {"phase4a": [], "phase4b": []}
    pf.SMOKE_SPECS = {"phase4a": ["ft_decisions_h0.yaml"], "phase4b": []}  # a present spec stands in for the smoke file
    original = OmegaConf.load

    def changed(path, *a, **k):
        cfg = original(path, *a, **k)
        if str(path).endswith("/configs/ft_decisions_h0.yaml"):
            cfg.common_overrides = list(cfg.common_overrides) + override
        return cfg
    with patch.object(OmegaConf, "load", side_effect=changed):
        quiet(pf.check_specs, str(tmp_path))
    assert bool(pf.FAILS) == fails
    line = next(l for l in pf.LINES if "ft_decisions_h0.yaml" in l)
    assert "smoke spec: ranges recorded, not compared" in line
    assert "train 101-102" in (tmp_path / "specs.txt").read_text() or fails


def test_absent_smoke_specs_are_only_info(tmp_path):
    pf = fresh()
    pf.SPECS = {"phase4a": [], "phase4b": []}
    quiet(pf.check_specs, str(tmp_path))
    assert pf.FAILS == [] and pf.WARNS == []
    assert sum("smoke spec not present" in l for l in pf.LINES) == 2


# ---------------------------------------------------------------- ST01 / RG-F11: GPU
def test_foreign_gpu_process_fails_but_own_context_does_not(tmp_path, monkeypatch):
    pf = fresh()
    no_harness_vars(monkeypatch, pf)
    gpu(monkeypatch, True)
    pf.NVIDIA_SMI = fake_smi(tmp_path, f'echo "{os.getpid()}, python, 300 MiB"\necho "4242, /usr/bin/python3, 20000 MiB"')
    quiet(pf.check_gpu, str(tmp_path))
    assert len(pf.FAILS) == 1 and pf.FAILS[0].startswith("1 other compute process(es) on the GPU (pid 4242)")
    assert "/usr/bin/python3" not in "\n".join(pf.LINES)  # names stay in environment.txt
    pf2 = fresh()
    pf2.NVIDIA_SMI = fake_smi(tmp_path, f'echo "{os.getpid()}, python, 300 MiB"')
    quiet(pf2.check_gpu, str(tmp_path))
    assert pf2.FAILS == [] and any(l.startswith("PASS  GPU: FakeGPU; no other compute process") for l in pf2.LINES)
    pf3 = fresh()
    pf3.NVIDIA_SMI = fake_smi(tmp_path, f'echo "{os.getpid()}, python, 300 MiB"\necho ""\necho "[N/A], [N/A], 2 MiB"')
    assert pf3.nvidia_smi_compute_apps()[:2] == ([os.getpid()], 1)  # an empty line is not a process; [N/A] is one
    quiet(pf3.check_gpu, str(tmp_path))
    assert pf3.FAILS == ["1 compute process(es) on the GPU whose pid nvidia-smi cannot show: cannot tell whether another "
                         "job is using the GPU (table in environment.txt)"]
    assert not any(l.startswith("PASS  GPU") for l in pf3.LINES)


@pytest.mark.parametrize("smi,visible,expect", [
    ("/nonexistent/nvidia-smi", True, "nvidia-smi not found"),
    ("exit 9", True, "nvidia-smi did not answer"),
    ("", False, "no GPU visible to torch"),
    ("echo '[N/A], [N/A], 20000 MiB'", True, "1 compute process(es) on the GPU whose pid nvidia-smi cannot show"),  # F2
    ("echo '[Not Supported], python, 1 MiB'\necho '[Insufficient Permissions], python, 1 MiB'", True,
     "2 compute process(es) on the GPU whose pid nvidia-smi cannot show"),
])
def test_gpu_required_checks_fail_and_the_override_is_recorded(tmp_path, monkeypatch, smi, visible, expect):
    pf = fresh()
    no_harness_vars(monkeypatch, pf)
    gpu(monkeypatch, visible)
    pf.NVIDIA_SMI = smi if smi.startswith("/") else fake_smi(tmp_path, smi)
    quiet(pf.check_gpu, str(tmp_path))
    assert any(f.startswith(expect) for f in pf.FAILS)
    pf2 = fresh()
    pf2.NVIDIA_SMI = pf.NVIDIA_SMI
    pf2.ALLOW_WARN_ONLY.add("gpu")
    quiet(pf2.check_gpu, str(tmp_path))
    assert pf2.FAILS == [] and any(w.startswith(f"OVERRIDE --allow-warn-only gpu: {expect}") for w in pf2.WARNS)
    assert "gpu" in pf2.OVERRIDES_USED


def test_synthetic_harness_profile_needs_no_gpu(tmp_path, monkeypatch):
    pf = fresh()
    gpu(monkeypatch, False)
    pf.NVIDIA_SMI = "/nonexistent/nvidia-smi"
    monkeypatch.setenv("RUNBOOK_SANDBOX", str(tmp_path))
    monkeypatch.setenv("RUNBOOK_BANK_OVERRIDES", "1")
    quiet(pf.check_gpu, str(tmp_path))
    assert pf.FAILS == [] and pf.WARNS == [] and any("synthetic harness profile" in l for l in pf.LINES)
    monkeypatch.delenv("RUNBOOK_BANK_OVERRIDES")  # RUNBOOK_SANDBOX alone is not the harness profile
    pf2 = fresh()
    quiet(pf2.check_gpu, str(tmp_path))
    assert any(f.startswith("no GPU visible") for f in pf2.FAILS)


def test_nvidia_smi_is_asked_before_any_cuda_context_exists(tmp_path, monkeypatch):
    """F3: inside a container without the host pid namespace this process's own CUDA context would show under a
    foreign pid, so the compute-apps query must come before the first torch.cuda call that creates a context."""
    pf = fresh()
    _clean_main_setup(tmp_path, monkeypatch, pf)
    marker = tmp_path / "smi_asked"
    # Lists a foreign process only once a context may exist (that is, on any call after the first): a PASS proves
    # the table was read once, before the context calls below.
    pf.NVIDIA_SMI = fake_smi(tmp_path, f'if [ -e "{marker}" ]; then echo "999999, python, 300 MiB"; fi\ntouch "{marker}"')
    seen = []
    monkeypatch.setattr(torch.cuda, "get_device_name", lambda i=0: seen.append(("name", marker.exists())) or "FakeGPU")
    monkeypatch.setattr(torch.cuda, "get_device_properties",
                        lambda i=0: seen.append(("properties", marker.exists())) or types.SimpleNamespace(name="FakeGPU"))
    monkeypatch.setattr(torch.cuda, "mem_get_info", lambda i=0: seen.append(("mem", marker.exists())) or (1 << 30, 2 << 30))
    code, summary, _ = _run_main(pf, ["--skip-data", "--skip-tests", "--out-root", str(tmp_path / "pf")])
    assert code == 0 and result_line(summary, 0, "none") and pf.FAILS == []
    assert seen and seen[0][0] == "name" and all(asked for _, asked in seen)  # nvidia-smi answered before every context call
    assert any(l.startswith("PASS  GPU: FakeGPU; no other compute process") for l in summary)
    assert summary.index(next(l for l in summary if l.startswith("PASS  GPU"))) < \
        summary.index(next(l for l in summary if l.startswith("INFO  python ")))  # gpu check before environment


# ---------------------------------------------------------------- inherited harness state
@pytest.mark.parametrize("var", ["RUNBOOK_SANDBOX", "BATCH1_SKIP", "BATCH2_SKIP", "A_H10_COMPARATOR", "PREFLIGHT_ARGS"])
def test_harness_variable_set_in_the_bank_profile_fails_unless_the_bank_flag_is_set(tmp_path, monkeypatch, var):
    pf = fresh()
    no_harness_vars(monkeypatch, pf)
    monkeypatch.setenv(var, "something")
    quiet(pf.check_profile, str(tmp_path))
    assert pf.FAILS == [f"harness variable(s) set in the bank profile: {var}; unset them, or set RUNBOOK_BANK_OVERRIDES=1 "
                        "only on review advice"]
    monkeypatch.setenv("RUNBOOK_BANK_OVERRIDES", "1")
    pf2 = fresh()
    quiet(pf2.check_profile, str(tmp_path))
    assert pf2.FAILS == [] and pf2.OVERRIDES_USED == ["RUNBOOK_BANK_OVERRIDES"]
    assert pf2.WARNS[0].startswith(f"OVERRIDE RUNBOOK_BANK_OVERRIDES=1: harness variable(s) set: {var}")


def test_clean_bank_profile_passes(tmp_path, monkeypatch):
    pf = fresh()
    no_harness_vars(monkeypatch, pf)
    quiet(pf.check_profile, str(tmp_path))
    assert pf.FAILS == [] and pf.WARNS == [] and pf.LINES[0].startswith("PASS  profile bank: none of")


# ---------------------------------------------------------------- credential file
def test_credential_file_missing_fails_present_passes_and_is_never_read_into_the_report(tmp_path, monkeypatch):
    pf = fresh()
    no_harness_vars(monkeypatch, pf)
    missing = str(tmp_path / "absent.yaml")
    pf.credential_paths = lambda: {missing: ["YOUR_PACKAGE/phase4a/configs/sequential.yaml"]}
    quiet(pf.check_credentials, str(tmp_path))
    assert pf.FAILS == [f"credential file {missing} (s3.cred_path in YOUR_PACKAGE/phase4a/configs/sequential.yaml) does not "
                        "exist or is not readable by this user: the batch cannot reach S3"]
    present = tmp_path / "test.yaml"
    present.write_text(f"AWS_SECRET_ACCESS_KEY: {SENTINEL}\n")
    pf2 = fresh()
    pf2.credential_paths = lambda: {str(present): ["a.yaml", "b.yaml"]}
    quiet(pf2.check_credentials, str(tmp_path))
    assert pf2.FAILS == [] and pf2.LINES[0].startswith(f"PASS  credential file {present} (s3.cred_path in a.yaml, b.yaml) exists")
    assert SENTINEL not in "\n".join(pf2.LINES) and not list(tmp_path.glob("*.txt"))


def test_credential_paths_come_from_the_batch_base_configs():
    pf = fresh()
    paths = pf.credential_paths()
    assert list(paths) == ["/home/jovyan/your_id/tabular_fraud/test.yaml"]
    assert set(paths["/home/jovyan/your_id/tabular_fraud/test.yaml"]) == {"YOUR_PACKAGE/phase4a/configs/sequential.yaml",
                                                                          "YOUR_PACKAGE/phase4b/configs/sequential_hier.yaml"}


def test_credentials_not_required_in_the_synthetic_profile(tmp_path, monkeypatch):
    pf = fresh()
    monkeypatch.setenv("RUNBOOK_SANDBOX", str(tmp_path))
    monkeypatch.setenv("RUNBOOK_BANK_OVERRIDES", "1")
    pf.credential_paths = lambda: {str(tmp_path / "absent.yaml"): ["a.yaml"]}
    quiet(pf.check_credentials, str(tmp_path))
    assert pf.FAILS == [] and "not required in the synthetic harness profile" in pf.LINES[0]


# ---------------------------------------------------------------- RUN-03: import probe
def test_requirements_file_missing_is_fail(tmp_path):
    pf = fresh()
    pf.REQUIREMENTS_POD = str(tmp_path / "YOUR_PACKAGE" / "requirements-pod.txt")
    quiet(pf.check_imports, str(tmp_path))
    assert any("requirements-pod.txt is missing" in f for f in pf.FAILS)
    assert pf.pip_line("torch").startswith("pip line unknown:")


def test_clean_runtime_closure_passes_and_records_interpreter_and_versions(tmp_path):
    pf = fresh()
    pf.REQUIREMENTS_POD = requirements(tmp_path)
    no_optional_warns(pf)
    quiet(pf.check_imports, str(tmp_path))
    assert pf.FAILS == [] and pf.WARNS == []
    owned, third = pf.runtime_closure([str(ROOT / "YOUR_PACKAGE/phase4a/scripts/train_sequential.py"),
                                       str(ROOT / "YOUR_PACKAGE/phase4b/scripts/train_sequential.py")])
    assert {"torch", "pytorch_lightning", "pandas", "numpy", "pyarrow", "s3fs", "yaml", "omegaconf"} <= set(third)
    assert "pytorch_tabular" not in third and "requests" not in third  # batch 1 does not use the reference path
    names = {os.path.relpath(p, ROOT) for p in owned}
    assert {"fraud/callbacks.py", "fraud/log_utils.py", "YOUR_PACKAGE/base/data/input_contracts.py",
            "YOUR_PACKAGE/phase4a/sequence_builder.py", "YOUR_PACKAGE/phase4b/sequence_builder.py"} <= names
    assert all(n.startswith(("fraud/", "YOUR_PACKAGE/")) for n in names)
    text = (tmp_path / "runtime_modules.txt").read_text()
    assert text.startswith(f"interpreter {sys.executable} python ") and "  s3fs: s3fs " in text
    assert any(l.startswith("PASS  runtime closure:") and sys.executable in l for l in pf.LINES)
    assert any(l.startswith("INFO  runtime packages: ") and "torch " in l and "s3fs " in l for l in pf.LINES)


def test_missing_runtime_module_fails_with_the_exact_pip_line(tmp_path):
    pf = fresh()
    pf.REQUIREMENTS_POD = requirements(tmp_path)
    real = pf.load_module

    def broken(name, path):
        if path.endswith("phase4a/scripts/train_sequential.py"):
            raise ModuleNotFoundError("No module named 'fakepkg_missing'", name="fakepkg_missing")
        return real(name, path)
    pf.load_module = broken
    quiet(pf.check_imports, str(tmp_path))
    assert pf.FAILS == ['runtime module fakepkg_missing is missing (needed by phase4a/train_sequential.py); '
                        'pip install "fakepkg-missing>=1.0"']
    assert any(l.startswith("PASS  phase4b trainer uses builder") for l in pf.LINES)


def test_missing_lazy_import_fails_and_the_override_is_recorded(tmp_path):
    for override in (False, True):
        pf = fresh()
        pf.REQUIREMENTS_POD = requirements(tmp_path)
        pf.runtime_closure = lambda starts: (["x.py"], ["torch", "lazy_missing_pkg", "unlisted_pkg"])
        pf.optional_missing = lambda pkg: None  # F1: the WARN list below must not depend on this machine's packages
        if override:
            pf.ALLOW_WARN_ONLY.add("module")
        quiet(pf.check_imports, str(tmp_path))
        rel = os.path.relpath(pf.REQUIREMENTS_POD, ROOT)
        msgs = ['runtime module lazy_missing_pkg is missing (needed by import statement in the owned modules); pip install '
                '"lazy-missing-pkg"',
                f'runtime module unlisted_pkg is missing (needed by import statement in the owned modules); no line in {rel} '
                'names unlisted_pkg: add one']
        if override:
            assert pf.FAILS == [] and pf.WARNS == [f"OVERRIDE --allow-warn-only module: {m}" for m in msgs]
            assert pf.OVERRIDES_USED == ["module", "module"]
        else:
            assert pf.FAILS == msgs
        assert "  lazy_missing_pkg: MISSING" in (tmp_path / "runtime_modules.txt").read_text()


def test_missing_optional_package_is_warn_with_pip_line(tmp_path):
    pf = fresh()
    pf.REQUIREMENTS_POD = requirements(tmp_path)
    pf.optional_missing = lambda pkg: "requests" if pkg in ("pytorch_tabular", "requests") else None
    quiet(pf.check_imports, str(tmp_path))
    assert pf.FAILS == []
    assert pf.WARNS == ['optional package pytorch_tabular (test suite and reference path only, not batch 1) cannot import: '
                        'missing requests; pip install "requests"',
                        'optional package requests (test suite and reference path only, not batch 1) cannot import: '
                        'missing requests; pip install "requests"']
    assert pf.OPTIONAL_MISSING == {"requests": 'pip install "requests"'}


def test_pip_line_matches_names_case_and_separator_insensitively(tmp_path):
    pf = fresh()
    pf.REQUIREMENTS_POD = requirements(tmp_path, "PyYAML>=6\nscikit_learn==1.5.0\nPytorch-Lightning>=2\n")
    assert pf.pip_line("yaml") == 'pip install "PyYAML>=6"'
    assert pf.pip_line("sklearn") == 'pip install "scikit_learn==1.5.0"'
    assert pf.pip_line("pytorch_lightning") == 'pip install "Pytorch-Lightning>=2"'
    assert pf.pip_line("torch").startswith("no line in ") and pf.pip_line("torch").endswith("names torch: add one")
    # the bundled pytorch_tabular never has a pip line: the message says what to do in plain words
    assert pf.pip_line("pytorch_tabular") == ("the bundled copy under src/pytorch_tabular is missing from this folder; "
                                             "unzip the release again")


def test_missing_bundled_pytorch_tabular_is_warn_that_says_unzip_again(tmp_path):
    pf = fresh()
    pf.REQUIREMENTS_POD = requirements(tmp_path)
    pf.optional_missing = lambda pkg: "pytorch_tabular" if pkg == "pytorch_tabular" else None
    quiet(pf.check_imports, str(tmp_path))
    assert pf.FAILS == []
    assert pf.WARNS == ['optional package pytorch_tabular (test suite and reference path only, not batch 1) cannot import: '
                        'missing pytorch_tabular; the bundled copy under src/pytorch_tabular is missing from this folder; '
                        'unzip the release again']
    assert pf.OPTIONAL_MISSING == {"pytorch_tabular": "the bundled copy under src/pytorch_tabular is missing from this "
                                                      "folder; unzip the release again"}


def test_guarded_imports_are_not_part_of_the_closure(tmp_path):
    pf = fresh()
    p = tmp_path / "m.py"
    p.write_text("import os\nimport numpy\ntry:\n    import tomllib\nexcept ImportError:\n    tomllib = None\n"
                 "def f():\n    from s3fs import S3FileSystem\n    import pandas.api\n")
    assert pf.imported_top_levels(str(p)) == {"os", "numpy", "s3fs", "pandas"}


# ---------------------------------------------------------------- RUN-03 / ST01: the test step
def _suite(tmp_path, required_missing):
    suite = tmp_path / "suite"
    suite.mkdir()
    (suite / "test_ok.py").write_text("def test_ok():\n    assert True\n")
    (suite / "test_needs_optional.py").write_text("import fake_optional_pkg\n")
    if required_missing:
        (suite / "test_needs_required.py").write_text("import fake_required_pkg\n")
    return suite


@pytest.mark.parametrize("required_missing", [True, False])
def test_uncollectable_files_are_named_optional_is_warn_required_is_fail(tmp_path, required_missing):
    pf = fresh()
    pf.REQUIREMENTS_POD = requirements(tmp_path, "fake-optional-pkg>=1\n")
    pf.TEST_SUITES = ((str(_suite(tmp_path, required_missing)), "required"),)
    pf.OPTIONAL_PACKAGES = ("fake_optional_pkg",)
    (tmp_path / "out").mkdir()
    quiet(pf.check_tests, str(tmp_path / "out"))
    # pytest names the file relative to its rootdir, which depends on where the checkout and the temp folder sit
    assert len(pf.WARNS) == 1 and re.fullmatch(r'not collected: \S*test_needs_optional\.py, needs fake_optional_pkg \(pip install '
                                               r'"fake-optional-pkg>=1"\); its tests are not counted as passed', pf.WARNS[0])
    summary = next(l for l in pf.LINES if "repository tests (" in l)
    if required_missing:
        assert re.fullmatch(r"not collected: \S*test_needs_required\.py, missing module fake_required_pkg", pf.FAILS[0])
        assert summary.startswith("FAIL") and "1 passed" in summary and "2 errors" in summary
    else:
        assert pf.FAILS == []
        assert summary.startswith("PASS") and "1 passed, 1 error" in summary
        assert "1 file(s) not collected for a missing optional package (WARN above), not counted as passed" in summary
    assert (tmp_path / "out" / "pytest.txt").exists()


def test_failing_test_is_fail(tmp_path):
    pf = fresh()
    suite = tmp_path / "suite"
    suite.mkdir()
    (suite / "test_bad.py").write_text("def test_bad():\n    assert False\n")
    pf.TEST_SUITES = ((str(suite), "required"),)
    quiet(pf.check_tests, str(tmp_path))
    assert len(pf.FAILS) == 1 and pf.FAILS[0].startswith("repository tests (") and "1 failed" in pf.FAILS[0]


def test_missing_required_test_folder_is_fail_optional_is_warn(tmp_path):
    pf = fresh()
    pf.TEST_SUITES = ((str(tmp_path / "absent_required"), "required"), (str(tmp_path / "absent_optional"), "optional"))
    quiet(pf.check_tests, str(tmp_path))
    assert pf.FAILS == [f"test folder {tmp_path / 'absent_required'} is missing"]
    assert pf.WARNS == [f"test folder {tmp_path / 'absent_optional'} is missing"]


@pytest.mark.parametrize("override", [False, True])
def test_pytest_missing_is_fail_unless_overridden(tmp_path, monkeypatch, override):
    pf = fresh()
    pf.REQUIREMENTS_POD = requirements(tmp_path)
    real = importlib.util.find_spec
    monkeypatch.setattr(pf.importlib.util, "find_spec", lambda name, *a: None if name == "pytest" else real(name, *a))
    if override:
        pf.ALLOW_WARN_ONLY.add("pytest")
    quiet(pf.check_tests, str(tmp_path))
    msg = 'pytest is not installed: the repository tests cannot run; pip install "pytest"'
    if override:
        assert pf.FAILS == [] and pf.WARNS == [f"OVERRIDE --allow-warn-only pytest: {msg}"] and pf.OVERRIDES_USED == ["pytest"]
    else:
        assert pf.FAILS == [msg]


def test_collection_error_parser():
    pf = fresh()
    out = ("x.py .\n==== ERRORS ====\n____ ERROR collecting a/test_one.py ____\nTraceback\nE   ModuleNotFoundError: No module "
           "named 'pkg_a.sub'\n____ ERROR collecting b/test_two.py ____\nE   SyntaxError: bad\n==== short test summary ====\n"
           "1 passed, 2 errors in 0.1s\n")
    assert pf.collection_errors(out) == {"a/test_one.py": "pkg_a.sub", "b/test_two.py": None}
    # at the default 80 columns pytest prints one underscore each side when the path is long
    long_path = "pytest-of-root/pytest-0/test_uncollectable_files_are_n1/suite/test_needs_optional.py"
    out_long = (f"==== ERRORS ====\n_ ERROR collecting {long_path} _\nE   ModuleNotFoundError: No module named "
                "'fake_optional_pkg'\n==== short test summary ====\n1 error in 0.1s\n")
    assert pf.collection_errors(out_long) == {long_path: "fake_optional_pkg"}
    assert pf.collection_errors("3 passed in 1s\n") == {}


# ---------------------------------------------------------------- J-S1-F06: pip_freeze.txt is never silently empty
@pytest.mark.parametrize("how", ["not importable", "exit 1", "exception", "works"])
def test_pip_freeze_unavailable_is_said_in_the_file_and_the_environment_line(tmp_path, monkeypatch, how):
    """pip absent from the interpreter (a uv environment), `python -m pip freeze` exiting non-zero, or the command not
    running: pip_freeze.txt holds one line saying why, environment.txt carries it, and the environment INFO line
    mentions it. When it works the file is the freeze output with URL credentials redacted and no line says pip."""
    pf = fresh()
    real_find_spec, real_run = pf.importlib.util.find_spec, pf.subprocess.run

    def find_spec(name, *a):
        if name != "pip":
            return real_find_spec(name, *a)
        return None if how == "not importable" else real_find_spec("re")  # any spec stands for an importable pip
    monkeypatch.setattr(pf.importlib.util, "find_spec", find_spec)

    def run(cmd, *a, **k):
        if not (isinstance(cmd, list) and cmd[1:3] == ["-m", "pip"]):
            return real_run(cmd, *a, **k)  # nvidia-smi and the pytorch_tabular probe run as usual
        if how == "exception":
            raise OSError("cannot start the interpreter")
        if how == "exit 1":
            return subprocess.CompletedProcess(cmd, 1, stdout="", stderr=f"{sys.executable}: No module named pip\n")
        return subprocess.CompletedProcess(cmd, 0, stdout="pkg==1.0\n-e git+https://user:tok@host/x.git#egg=y\n",
                                           stderr="")
    monkeypatch.setattr(pf.subprocess, "run", run)
    quiet(pf.check_environment, str(tmp_path))
    assert pf.FAILS == [] and pf.WARNS == []
    text = (tmp_path / "pip_freeze.txt").read_text()
    env_line = next(l for l in pf.LINES if l.startswith("INFO  pytorch_lightning"))
    environment = (tmp_path / "environment.txt").read_text()
    if how == "works":
        assert text == "pkg==1.0\n-e git+https://<redacted>@host/x.git#egg=y\n"
        assert "pip freeze" not in env_line and "pip freeze" not in environment
        return
    expect = {"not importable": f"pip is not importable in {sys.executable}",
              "exit 1": "python -m pip freeze exited 1: <path> No module named pip",
              "exception": "python -m pip freeze did not run (OSError)"}[how]
    assert text == f"pip freeze unavailable: {expect}\n"
    assert env_line.endswith(f" | pip freeze unavailable: {expect}")
    assert text.strip() in environment.splitlines()


# ---------------------------------------------------------------- RUN-10: configuration identity and drift
def _source_root(tmp_path):
    root, ref = tmp_path / "root", tmp_path / "ref"
    files = {"YOUR_PACKAGE/phase4a/configs/ft_decisions_h0.yaml": "base_config: YOUR_PACKAGE/phase4a/configs/sequential.yaml\n",
             "YOUR_PACKAGE/phase4a/configs/sequential.yaml": "predictors:\n  csv_path: fraud/configs/predictors.csv\ns3:\n  cred_path: /x\n",
             "fraud/configs/predictors.csv": "feature,type\n",
             "YOUR_PACKAGE/phase4a/configs/other.yaml": "a: 1\n",
             "YOUR_PACKAGE/phase4a/known.py": "known = 1\n",
             "runbook/2026-10-07/batch1.sh": "echo hi\n",
             "runbook/2026-10-07/collect_returns.py": "collect = 1\n"}
    for rel, text in files.items():
        (root / rel).parent.mkdir(parents=True, exist_ok=True)
        (root / rel).write_text(text)
    ref.mkdir()
    rows = ["path,sha256_lf,class"] + [f"{rel},{hashlib.sha256(text.encode()).hexdigest()},x" for rel, text in files.items()]
    (ref / "github_source_manifest.csv").write_text("\n".join(rows) + "\n")
    return root, ref


def _source_pf(tmp_path):
    pf = fresh()
    root, ref = _source_root(tmp_path)
    pf.ROOT, pf.HERE = str(root), str(ref)
    pf.SPECS = {"phase4a": ["ft_decisions_h0.yaml"], "phase4b": []}
    pf.SMOKE_SPECS = {"phase4a": [], "phase4b": []}
    return pf, root


def test_batch_config_files_are_derived_from_the_specs(tmp_path):
    pf, root = _source_pf(tmp_path)
    assert pf.batch_config_files() == ["fraud/configs/predictors.csv", "YOUR_PACKAGE/phase4a/configs/ft_decisions_h0.yaml",
                                       "YOUR_PACKAGE/phase4a/configs/sequential.yaml"]


def test_clean_source_passes_and_writes_the_configuration_identity(tmp_path):
    pf, root = _source_pf(tmp_path)
    out = tmp_path / "out"
    out.mkdir()
    quiet(pf.check_source, str(out))
    assert pf.FAILS == [] and pf.WARNS == []
    assert pf.LINES[0].startswith("PASS  source vs reviewed manifest") and "7 same, 0 differ" in pf.LINES[0]
    assert ("PASS  the batch's own 9 files (specs, base configs, predictor list, batch scripts, runbook scripts) match the "
            "manifest") in pf.LINES
    ident = json.loads((out / "config_identity.json").read_text())
    assert ident["manifest_sha256"] == pf.norm_sha(os.path.join(pf.HERE, "github_source_manifest.csv"))
    assert set(ident["batch_config_files"]) == set(pf.batch_config_files()) and ident["config_drift"] == []
    expected = hashlib.sha256("".join(f"{p},{ident['batch_config_files'][p]}\n" for p in sorted(ident["batch_config_files"])).encode())
    assert ident["active_configs_sha256"] == expected.hexdigest()


@pytest.mark.parametrize("changed,how", [
    ("YOUR_PACKAGE/phase4a/configs/ft_decisions_h0.yaml", "edit"),    # a batch spec
    ("YOUR_PACKAGE/phase4a/configs/sequential.yaml", "edit"),         # its base config (for example the learning rate)
    ("fraud/configs/predictors.csv", "edit"),                  # the predictor list the base config names
    ("YOUR_PACKAGE/phase4a/configs/ft_decisions_h0.yaml", "delete"),  # the spec is missing on the pod
])
def test_drift_in_the_batch_own_config_files_fails(tmp_path, changed, how):
    pf, root = _source_pf(tmp_path)
    if how == "edit":
        (root / changed).write_text((root / changed).read_text() + "# changed\n")
    else:
        (root / changed).unlink()
    quiet(pf.check_source, str(tmp_path))
    kind = "differs" if how == "edit" else "only on GitHub"
    assert pf.FAILS == [f"configuration drift in 1 of the batch's own 9 files (specs, base configs, predictor list, batch "
                        f"scripts, runbook scripts): {kind}: {changed}"]
    ident = json.loads((tmp_path / "config_identity.json").read_text())
    assert ident["config_drift"] == [changed]
    pf2, root2 = _source_pf(tmp_path / "again")
    (root2 / changed).write_text("x: 2\n")
    pf2.ALLOW_WARN_ONLY.add("config")
    quiet(pf2.check_source, str(tmp_path / "again"))
    assert pf2.FAILS == [] and pf2.OVERRIDES_USED == ["config"] and any(w.startswith("OVERRIDE --allow-warn-only config:") for w in pf2.WARNS)


def test_other_yaml_and_runbook_test_drift_stay_warn(tmp_path):
    """YAML outside the batch's own files and the runbook's tests are not watched: WARN only."""
    pf, root = _source_pf(tmp_path)
    (root / "YOUR_PACKAGE/phase4a/configs/other.yaml").write_text("a: 2\n")
    (root / "runbook/2026-10-07/tests").mkdir()
    (root / "runbook/2026-10-07/tests/test_extra.py").write_text("def test_x():\n    pass\n")
    quiet(pf.check_source, str(tmp_path))
    assert pf.FAILS == [] and pf.LINES[0].startswith("WARN") and "1 differ, 1 only on pod" in pf.LINES[0]
    ident = json.loads((tmp_path / "config_identity.json").read_text())
    assert ident["config_drift"] == [] and ident["runbook_drift"] == ["runbook/2026-10-07/tests/test_extra.py"]


@pytest.mark.parametrize("script", ["preflight_pod.py", "run_step.py", "collect_returns.py", "score_attempt.py"])
@pytest.mark.parametrize("override", [False, True])
def test_drift_in_the_runbook_own_scripts_fails_unless_overridden(tmp_path, script, override):
    """S1-F04: the runbook's own scripts decide what runs and what is ACCEPTED, so their drift is a required check
    like the batch scripts (F6). collect_returns.py is in the synthetic manifest and is edited; the other three are
    absent from it, so writing them is drift of the kind 'only on pod'."""
    pf, root = _source_pf(tmp_path)
    rel = f"runbook/2026-10-07/{script}"
    (root / rel).write_text((root / rel).read_text() + "# changed\n" if (root / rel).exists() else "x = 1\n")
    kind = "differs" if script == "collect_returns.py" else "only on pod"
    if override:
        pf.ALLOW_WARN_ONLY.add("config")
    quiet(pf.check_source, str(tmp_path))
    msg = (f"configuration drift in 1 of the batch's own 9 files (specs, base configs, predictor list, batch scripts, "
           f"runbook scripts): {kind}: {rel}")
    if override:
        assert pf.FAILS == [] and f"OVERRIDE --allow-warn-only config: {msg}" in pf.WARNS and pf.OVERRIDES_USED == ["config"]
    else:
        assert pf.FAILS == [msg]
    assert pf.LINES[0].startswith("WARN  source vs reviewed manifest")
    ident = json.loads((tmp_path / "config_identity.json").read_text())
    assert ident["config_drift"] == [rel] and ident["runbook_drift"] == [rel]
    assert set(ident["batch_config_files"]) == set(pf.batch_config_files())  # the identity digest stays over the config files


@pytest.mark.parametrize("override", [False, True])
def test_edited_batch_script_fails_unless_overridden(tmp_path, override):
    """F6: the spec list is read from batch1.sh and batch2.sh, so an edited script is drift in the batch's own files."""
    pf, root = _source_pf(tmp_path)
    (root / "runbook/2026-10-07/batch1.sh").write_text('for step in "phase4a ft_decisions_extra.yaml"; do\n')
    if override:
        pf.ALLOW_WARN_ONLY.add("config")
    quiet(pf.check_source, str(tmp_path))
    msg = ("configuration drift in 1 of the batch's own 9 files (specs, base configs, predictor list, batch scripts, runbook "
           "scripts): differs: runbook/2026-10-07/batch1.sh")
    if override:  # the source-vs-manifest line is a WARN too whenever anything differs
        assert pf.FAILS == [] and f"OVERRIDE --allow-warn-only config: {msg}" in pf.WARNS and pf.OVERRIDES_USED == ["config"]
    else:
        assert pf.FAILS == [msg]
    assert pf.LINES[0].startswith("WARN  source vs reviewed manifest") and "1 differ" in pf.LINES[0]
    ident = json.loads((tmp_path / "config_identity.json").read_text())
    assert ident["config_drift"] == ["runbook/2026-10-07/batch1.sh"] and ident["runbook_drift"] == ["runbook/2026-10-07/batch1.sh"]
    assert set(ident["batch_config_files"]) == set(pf.batch_config_files())  # the identity digest stays over the config files


def test_accepted_runtime_drift_is_a_recorded_override(tmp_path):
    """J-S1-F02: --accept-source-diff is an override like --allow-warn-only, not a plain WARN: the source line says
    OVERRIDE and names the flag, accept-source-diff is in OVERRIDES_USED, and so the RESULT line's overrides field
    carries it. Without the flag the same drift is FAIL with the advice line and no override."""
    pf, root = _source_pf(tmp_path)
    (root / "YOUR_PACKAGE/phase4a/known.py").write_text("known = 2\n")
    quiet(pf.check_source, str(tmp_path))
    assert pf.OVERRIDES_USED == [] and len(pf.FAILS) == 1 and pf.FAILS[0].startswith("source vs reviewed manifest")
    assert "1 differ, 0 only on pod, 0 only on GitHub; runtime .py differences 1" in pf.FAILS[0]
    assert any(l.startswith("    ") and "rerun with --accept-source-diff only after" in l for l in pf.LINES)
    pf2, root2 = _source_pf(tmp_path / "again")
    (root2 / "YOUR_PACKAGE/phase4a/known.py").write_text("known = 2\n")
    pf2.ACCEPT_SOURCE_DIFF = True
    out = tmp_path / "again" / "out"
    out.mkdir()
    quiet(pf2.check_source, str(out))
    assert pf2.FAILS == [] and pf2.OVERRIDES_USED == ["accept-source-diff"]
    assert pf2.LINES[0] == f"WARN  OVERRIDE --accept-source-diff: {pf.FAILS[0]}"  # same manifest, same counts
    assert any(l.strip() == "differs: YOUR_PACKAGE/phase4a/known.py" for l in pf2.LINES)
    assert not any("rerun with --accept-source-diff" in l for l in pf2.LINES)
    quiet(pf2.write_summary, str(out), 0)
    summary = (out / "SUMMARY.txt").read_text().splitlines()
    assert result_line(summary, 0, "accept-source-diff")


def test_older_manifest_without_the_class_column_is_still_read(tmp_path):
    pf, root = _source_pf(tmp_path)
    text = (Path(pf.HERE) / "github_source_manifest.csv").read_text().splitlines()
    (Path(pf.HERE) / "github_source_manifest.csv").write_text("\n".join(",".join(l.split(",")[:2]) for l in text) + "\n")
    quiet(pf.check_source, str(tmp_path))
    assert pf.FAILS == [] and "7 same, 0 differ" in pf.LINES[0]


@pytest.mark.parametrize("rel,cls", [
    ("fraud/callbacks.py", "python"), ("YOUR_PACKAGE/phase4a/sequence_builder.py", "python"), ("YOUR_PACKAGE/run_all.sh", "shell"),
    ("fraud/configs/predictors.csv", "data"), ("fraud/configs/eval.yaml", "config"),
    ("YOUR_PACKAGE/phase4a/configs/sequential.yaml", "config"), ("YOUR_PACKAGE/base/configs/streaming.yaml", "config"),
    ("YOUR_PACKAGE/phase4a/configs/tune.yaml", "config"),
    ("YOUR_PACKAGE/phase4a/configs/ft_decisions_h0.yaml", "spec"), ("YOUR_PACKAGE/phase4b/configs/ft_decisions_hier.yaml", "spec"),
    ("YOUR_PACKAGE/phase4a/configs/ft_decisions_smoke.yaml", "spec"), ("YOUR_PACKAGE/phase4b/configs/ft_decisions_hier_smoke.yaml", "spec"),
    ("runbook/2026-10-07/preflight_pod.py", "runbook"), ("runbook/2026-10-07/batch1.sh", "runbook"),
    ("runbook/2026-10-07/tests/test_preflight_fr1.py", "runbook"),
    ("runbook/2026-10-07/github_source_manifest.csv", None), ("runbook/2026-10-07/MORNING.md", None),
    ("fraud/__pycache__/x.py", None), ("docs/plan.md", None), ("pyproject.toml", None), ("YOUR_PACKAGE/README.md", None),
])
def test_source_class_rules(rel, cls):
    assert fresh().source_class(rel) == cls


def test_committed_manifest_has_the_class_column_and_covers_the_runbook_scripts():
    rows = list(__import__("csv").DictReader(open(HERE / "github_source_manifest.csv")))
    pf = fresh()
    assert set(rows[0]) == {"path", "sha256_lf", "class"}
    assert all(r["class"] == pf.source_class(r["path"]) for r in rows)
    paths = {r["path"] for r in rows}
    assert {"runbook/2026-10-07/preflight_pod.py", "runbook/2026-10-07/batch1.sh", "runbook/2026-10-07/collect_returns.py",
            "YOUR_PACKAGE/phase4a/configs/sequential.yaml", "YOUR_PACKAGE/phase4a/configs/ft_decisions_h0.yaml"} <= paths
    assert "runbook/2026-10-07/github_source_manifest.csv" not in paths


def test_manifest_script_docstring_says_runbook_script_drift_is_fail():
    """S1-F04 leftover: make_source_manifest.py's docstring agrees with check_source: drift in the four runbook
    scripts is FAIL under the required config check (--allow-warn-only config is the override), the other runbook
    files WARN."""
    doc = ast.get_docstring(ast.parse((HERE / "make_source_manifest.py").read_text()))
    for needed in ("preflight_pod.py", "run_step.py", "collect_returns.py", "score_attempt.py", "required config check",
                   "--allow-warn-only config", "other runbook files (the tests) is WARN"):
        assert needed in doc, needed
    assert "WARNs other YAML and runbook drift" not in doc


# ---------------------------------------------------------------- first-return diagnostics
def _contract(tmp_path, splits_frames, hist_lens=(1, 2)):
    cfg = OmegaConf.create({"data": {"account_col": "account", "order_col": "time", "target_col": "label",
                                     "tie_break_col": "id", "positive_label": 1}})
    splits = {}
    for split, df in splits_frames.items():
        p = tmp_path / f"{split}.parquet"
        df.to_parquet(p, index=False)
        splits[split] = [str(p)]
    pf = fresh()
    quiet(pf.check_data, str(tmp_path), fsspec.filesystem("file"), cfg, splits, hist_lens)
    return pf, json.loads((tmp_path / "data_contract.json").read_text())


def test_strictly_earlier_history_depth_is_reported_beside_preceding_rows(tmp_path):
    t = pd.to_datetime(["2025-01-01 10:00", "2025-01-01 10:00", "2025-01-02 10:00", "2025-01-01 10:00"])
    df = pd.DataFrame({"account": ["A", "A", "A", "B"], "id": ["a", "b", "c", "d"], "time": t, "label": [0, 1, 0, 0]})
    pf, r = _contract(tmp_path, {"train_1_1": df})
    assert r["train_1_1"]["rows_with_at_least_h_prior_rows_in_same_file"] == {"1": 2, "2": 1}
    # b shares a's timestamp: 1 preceding row but 0 strictly earlier; c at t2 has 2 of each
    assert r["train_1_1"]["rows_with_at_least_h_strictly_earlier_rows_in_same_file"] == {"1": 1, "2": 1}
    assert "strictly before" in r["train_1_1"]["history_depth_note"]
    line = next(l for l in pf.LINES if "full history" in l)
    assert "full history h5/h10/h15/h20: 50.0%/25.0% (preceding rows, may include equal timestamps); strictly earlier: " \
           "25.0%/25.0% (what the strict rule admits)" in line
    assert pf.FAILS == []


def test_timestamp_precision_counts_and_whole_second_ties_are_reported(tmp_path):
    """S1-01: the observed granularity of the stored times (OQ-13 part 2) is read from the data as counts, and ties are counted at
    whole seconds (the builders' gap resolution) beside the exact-timestamp ties."""
    t = pd.to_datetime(pd.Series(["2025-01-01 10:00:00.600", "2025-01-01 10:00:00.000", "2025-01-01 10:01:00.000",
                                  "2025-01-01 10:00:30.000", "2025-01-01 10:00:30.000"]))
    df = pd.DataFrame({"account": ["A", "A", "A", "B", "B"], "id": list("abcde"), "time": t, "label": [0, 0, 0, 1, 0]})
    pf, r = _contract(tmp_path, {"train_1_1": df})
    s = r["train_1_1"]
    assert s["timestamp_precision"] == {"rows_with_time": 5, "rows_with_nonzero_sub_second": 1,
                                        "rows_with_nonzero_seconds": 2, "rows_with_nonzero_minutes": 1}
    assert s["rows_in_equal_time_groups_within_account"] == 2          # B's pair only
    assert s["rows_in_equal_whole_second_groups_within_account"] == 4  # plus A's 10:00:00.600 and 10:00:00
    assert all(x in s["timestamp_precision_note"] for x in ("whole seconds", "whole minutes", "not the source clock and not arrival order"))
    assert any("equal-time rows 2 (exact; 1 of them positive), 4 at whole seconds" in l for l in pf.LINES)
    line = next(l for l in pf.LINES if "timestamp precision (OQ-13 part 2)" in l)
    assert "of 5 timed rows: nonzero sub-second part 1, nonzero seconds part 2, nonzero minutes part 1" in line
    assert "whole seconds" in line and "whole minutes" in line and "not the source clock and not arrival order" in line and pf.FAILS == []
    # a whole-second clock: no sub-second part anywhere, and the two tie counts agree
    whole = pd.DataFrame({"account": ["A", "A", "A"], "id": list("abc"), "label": [0, 0, 0],
                          "time": pd.to_datetime(pd.Series(["2025-01-01 10:00:01", "2025-01-01 10:00:01", "2025-01-01 10:00:02"]))})
    (tmp_path / "whole").mkdir()
    pf2, r2 = _contract(tmp_path / "whole", {"eval_8000_8000": whole})
    s2 = r2["eval_8000_8000"]
    assert s2["timestamp_precision"]["rows_with_nonzero_sub_second"] == 0 and s2["timestamp_precision"]["rows_with_time"] == 3
    assert s2["rows_in_equal_time_groups_within_account"] == s2["rows_in_equal_whole_second_groups_within_account"] == 2


def test_positives_inside_equal_time_groups_are_counted(tmp_path):
    """S1-02: frauds that sit in a same-account equal-time group are counted beside the tie count, so the tie rate
    alone does not have to settle R-007. A positive outside every tie group is not counted."""
    t = pd.to_datetime(["2025-01-01 10:00", "2025-01-01 10:00", "2025-01-01 10:00", "2025-01-02 10:00", "2025-01-01 10:00"])
    df = pd.DataFrame({"account": ["A", "A", "A", "A", "B"], "id": list("abcde"), "time": t, "label": [1, 1, 0, 1, 1]})
    pf, r = _contract(tmp_path, {"train_1_1": df})
    s = r["train_1_1"]
    assert s["rows_in_equal_time_groups_within_account"] == 3 and s["positives_in_equal_time_groups_within_account"] == 2
    assert s["positives"] == 4
    assert any("equal-time rows 3 (exact; 2 of them positive)" in l for l in pf.LINES) and pf.FAILS == []


def test_composite_identity_overlap_between_splits_is_counted_separately_from_accounts(tmp_path):
    t = pd.Timestamp("2025-01-01")
    train = pd.DataFrame({"account": ["A", "A"], "id": ["a", "b"], "time": [t, t], "label": [0, 1]})
    ev = pd.DataFrame({"account": ["A", "B"], "id": ["b", "d"], "time": [t, t], "label": [1, 0]})
    pf, r = _contract(tmp_path, {"train_1_1": train, "eval_8000_8000": ev})
    assert r["account_overlap"] == {"train_1_1&eval_8000_8000": 1}
    assert r["composite_id_overlap"] == {"train_1_1&eval_8000_8000": 1} and "account overlap is a different" in r["composite_id_overlap_note"]
    assert "differing stored id types undercount the overlap" in r["composite_id_overlap_note"]  # S1-06
    assert "schema.txt" in r["composite_id_overlap_note"]
    assert any("composite transaction identities (account, transaction id) in both: 1" in l for l in pf.LINES)
    exported = "\n".join(pf.LINES) + (tmp_path / "data_contract.json").read_text()
    assert '"b"' not in exported and "'b'" not in exported  # no raw identity leaves the pod, only counts and digests


def test_artifacts_txt_lists_a_digest_per_file_including_the_manifest(tmp_path):
    """S1-03: one sha256 line per file the runtime loader reads (manifest.json and every feature file the manifest
    names) beside the combined content digest; digests and byte counts only, no vocabulary value."""
    from fraud.data.preprocessing import PreprocessingArtifacts
    arts = PreprocessingArtifacts(artifact_version=1, predictor_version=1, fit_files=["s3://b/train/part_1.parquet"])
    arts.fit_feature("amount", pd.Series([1.0, 2.0, 3.0, 4.0]), "continuous")
    arts.fit_feature("channel", pd.Series(["SENTINEL_CATEGORY_WEB", "SENTINEL_CATEGORY_APP"]), "categorical")
    base = tmp_path / "arts"
    arts.save(str(base / "1"))
    cfg = OmegaConf.create({"artifacts": {"base": str(base), "version": "1"},
                            "data": {"val_base": "s3://b/valid", "val_start": 1, "val_end": 1},
                            "eval": {"base": "s3://b/eval", "file_start": 1, "file_end": 1}})
    pf = fresh()
    pf.predictor_list = lambda cfg, fs: types.SimpleNamespace(continuous=["amount"], categorical=["channel"])
    out = tmp_path / "out"
    out.mkdir()
    quiet(pf.check_artifacts, str(out), fsspec.filesystem("file"), cfg)
    assert pf.FAILS == [] and pf.WARNS == []
    text = (out / "artifacts.txt").read_text()
    h = hashlib.sha256()
    for fn in ("manifest.json", "feature_amount.json", "feature_channel.json"):
        data = (base / "1" / fn).read_bytes()
        assert f"  {fn} sha256 {hashlib.sha256(data).hexdigest()} ({len(data)} bytes)\n" in text
        if fn != "manifest.json":  # the combined digest is over the feature files only, as the header says
            name = fn[len("feature_"):-len(".json")]
            h.update(len(name).to_bytes(4, "big") + name.encode() + len(data).to_bytes(8, "big") + data)
    assert f"content sha256 {h.hexdigest()}\n" in text and text.startswith("per-file sha256 with CRLF normalized to LF")
    assert "SENTINEL_CATEGORY" not in text and "SENTINEL_CATEGORY" not in "\n".join(pf.LINES)
    assert any(l.startswith("PASS  active artifacts") and f"sha256 {h.hexdigest()[:12]}" in l for l in pf.LINES)


# ---------------------------------------------------------------- main: RESULT line, exit codes, overrides
def _clean_main_setup(tmp_path, monkeypatch, pf):
    no_harness_vars(monkeypatch, pf)
    gpu(monkeypatch, True)
    pf.NVIDIA_SMI = fake_smi(tmp_path, f'echo "{os.getpid()}, python, 300 MiB"')
    cred = tmp_path / "cred.yaml"
    cred.write_text(f"k: {SENTINEL}\n")
    pf.credential_paths = lambda: {str(cred): ["YOUR_PACKAGE/phase4a/configs/sequential.yaml"]}
    pf.REQUIREMENTS_POD = requirements(tmp_path)
    pf.check_source = pf.guarded("source identity")(lambda out: pf.say("PASS", "source identity (stubbed in this test)"))
    no_optional_warns(pf)


def _run_main(pf, args):
    with pytest.raises(SystemExit) as e:
        quiet(pf.main, args)
    out = sorted(Path(args[args.index("--out-root") + 1]).iterdir())[-1]
    return e.value.code, (out / "SUMMARY.txt").read_text().splitlines(), out


def closing_lines_precede_result(pf, summary):
    """S1-04: the three fixed closing lines are the last lines before RESULT, and RESULT stays the last line."""
    return summary[-1].startswith("RESULT ") and summary[-4:-1] == [f"INFO  {l}" for l in pf.CLOSING_LINES]


def test_clean_configuration_passes_with_result_pass_and_exit_0(tmp_path, monkeypatch):
    pf = fresh()
    _clean_main_setup(tmp_path, monkeypatch, pf)
    code, summary, _ = _run_main(pf, ["--skip-data", "--skip-tests", "--out-root", str(tmp_path / "pf")])
    assert code == 0 and pf.FAILS == [] and pf.WARNS == []
    assert result_line(summary, 0, "none") and summary[-1].endswith("exit 0")
    assert any(l.startswith("INFO  python ") and sys.executable in l for l in summary)  # RG-F12: interpreter path
    assert any(l.startswith("INFO  runtime packages: ") for l in summary)
    assert SENTINEL not in "\n".join(summary)
    assert all(l.startswith(("PASS", "INFO", "WARN", "FAIL", "    ", "RESULT")) for l in summary)
    assert closing_lines_precede_result(pf, summary)


def test_three_closing_lines_name_the_open_questions_and_sit_right_before_result():
    pf = fresh()
    assert len(pf.CLOSING_LINES) == 3
    measured, owner, comparisons = pf.CLOSING_LINES
    assert measured.startswith("Measured in this return:")
    assert all(x in measured for x in ("cohort counts and rates", "frauds in ties", "timestamp granularity", "strict depth", "overlap",
                                       "environment and packages", "source and config and artifact identity", "only where its step ran"))
    assert owner.startswith("Needs a definition from the data owner, never a PASS from code:")
    assert all(x in owner for x in ("OQ-13 part 1", "OQ-14", "OQ-15", "OQ-20"))
    assert comparisons.startswith("Established only by the comparisons themselves, not by any check here:")
    assert all(x in comparisons for x in ("whether history and the other settings help", "matched reference and cohorts",
                                         "protected final evaluation"))
    assert "\n" not in "".join(pf.CLOSING_LINES)  # one SUMMARY line each


def test_fail_gives_result_fail_exit_1_and_the_folder_is_still_complete(tmp_path, monkeypatch):
    pf = fresh()
    _clean_main_setup(tmp_path, monkeypatch, pf)
    gpu(monkeypatch, False)
    pf.NVIDIA_SMI = "/nonexistent/nvidia-smi"
    buf = io.StringIO()
    monkeypatch.chdir(tmp_path)  # batch1.sh and smoke.sh pass a relative --out-root
    with pytest.raises(SystemExit) as e, contextlib.redirect_stdout(buf):
        pf.main(["--skip-data", "--skip-tests", "--out-root", "pf_rel"])
    assert e.value.code == 1
    printed = buf.getvalue().strip().splitlines()[-1].split("PREFLIGHT_DIR=", 1)[1]
    assert os.path.isabs(printed) and Path(printed).parent == (tmp_path / "pf_rel").resolve()  # F4
    out = Path(printed)
    summary = (out / "SUMMARY.txt").read_text().splitlines()
    assert result_line(summary, 2, "none") and summary[-1].endswith("exit 1")
    assert closing_lines_precede_result(pf, summary)
    assert {"runtime_modules.txt", "specs.txt", "environment.txt"} <= {p.name for p in out.iterdir()}


def test_override_turns_the_gpu_check_into_a_recorded_warn_and_result_pass(tmp_path, monkeypatch):
    pf = fresh()
    _clean_main_setup(tmp_path, monkeypatch, pf)
    gpu(monkeypatch, False)
    code, summary, _ = _run_main(pf, ["--skip-data", "--skip-tests", "--allow-warn-only", "gpu", "--out-root", str(tmp_path / "pf")])
    assert code == 0
    assert result_line(summary, 0, "gpu") and summary[-1].endswith("exit 0")
    assert sum(l.startswith("WARN  OVERRIDE") for l in summary) == 1
    assert any(l.startswith("WARN  overrides requested: --allow-warn-only gpu") for l in summary)
    assert any(l.startswith("WARN  OVERRIDE --allow-warn-only gpu: no GPU visible") for l in summary)


@pytest.mark.parametrize("accept", [False, True])
def test_accept_source_diff_flag_is_recorded_in_the_result_line(tmp_path, monkeypatch, accept):
    """J-S1-F02 through main(): one runtime file edited. Without the flag: RESULT FAIL, overrides none, no OVERRIDE
    word. With --accept-source-diff: RESULT PASS, the flag in the 'overrides requested' line, the source line reads
    OVERRIDE --accept-source-diff, and the overrides field names accept-source-diff like the other overrides."""
    pf = fresh()
    real_check_source = pf.check_source
    _clean_main_setup(tmp_path, monkeypatch, pf)  # stubs check_source; put the real one back against a synthetic tree
    root, ref = _source_root(tmp_path / "src")
    (root / "YOUR_PACKAGE/phase4a/known.py").write_text("known = 2\n")
    synthetic = {"ROOT": str(root), "HERE": str(ref), "SPECS": {"phase4a": ["ft_decisions_h0.yaml"], "phase4b": []},
                 "SMOKE_SPECS": {"phase4a": [], "phase4b": []}}

    def source_against_the_synthetic_tree(out):
        saved = {k: getattr(pf, k) for k in synthetic}
        for k, v in synthetic.items():
            setattr(pf, k, v)
        try:
            real_check_source(out)
        finally:  # the checks after this one read the real tree again
            for k, v in saved.items():
                setattr(pf, k, v)
    pf.check_source = source_against_the_synthetic_tree
    flags = (["--skip-data", "--skip-tests"] + (["--accept-source-diff"] if accept else [])
             + ["--out-root", str(tmp_path / "pf")])
    code, summary, _ = _run_main(pf, flags)
    if accept:
        assert code == 0 and pf.FAILS == [] and result_line(summary, 0, "accept-source-diff")
        requested = "WARN  overrides requested: --accept-source-diff (each use is listed below as OVERRIDE)"
        assert any(l.startswith(requested) for l in summary)
        assert any(l.startswith("WARN  OVERRIDE --accept-source-diff: source vs reviewed manifest") for l in summary)
    else:
        assert code == 1 and len(pf.FAILS) == 1 and result_line(summary, 1, "none")
        assert any(l.startswith("FAIL  source vs reviewed manifest") for l in summary)
        assert "OVERRIDE" not in "\n".join(summary)
    assert closing_lines_precede_result(pf, summary)


def test_missing_optional_package_is_one_warn_and_result_pass(tmp_path, monkeypatch):
    """F1: a pod without pytorch_tabnet (RUN-03, A3: WARN only) must still get RESULT PASS from the clean path."""
    pf = fresh()
    _clean_main_setup(tmp_path, monkeypatch, pf)
    real = fresh().optional_missing
    pf.optional_missing = lambda pkg: real(pkg) if pkg == "pytorch_tabnet" else None  # the other two stay stubbed
    monkeypatch.setitem(sys.modules, "pytorch_tabnet", None)  # importlib.util.find_spec then reports it missing
    code, summary, _ = _run_main(pf, ["--skip-data", "--skip-tests", "--out-root", str(tmp_path / "pf")])
    assert code == 0 and pf.FAILS == [] and result_line(summary, 0, "none")
    assert len(pf.WARNS) == 1 and pf.WARNS[0].startswith("optional package pytorch_tabnet (test suite and reference path only, not batch 1) cannot import: missing pytorch_tabnet; pip install \"pytorch-tabnet\"")
    assert pf.OPTIONAL_MISSING == {"pytorch_tabnet": 'pip install "pytorch-tabnet"'}


def test_header_names_the_user_without_the_user_variable(tmp_path, monkeypatch):
    """F9: getpass.getuser() falls back to the password database when USER is unset."""
    pf = fresh()
    _clean_main_setup(tmp_path, monkeypatch, pf)
    for v in ("USER", "LOGNAME", "USERNAME", "LNAME"):
        monkeypatch.delenv(v, raising=False)
    import pwd
    code, summary, _ = _run_main(pf, ["--skip-data", "--skip-tests", "--out-root", str(tmp_path / "pf")])
    assert code == 0 and f" | user {pwd.getpwuid(os.getuid()).pw_name} | " in summary[0]


def test_unknown_override_name_is_rejected_before_anything_runs(tmp_path, capsys):
    pf = fresh()
    with pytest.raises(SystemExit) as e:
        pf.main(["--allow-warn-only", "everything", "--out-root", str(tmp_path / "pf")])
    assert e.value.code == 2 and not (tmp_path / "pf").exists()


def test_output_folder_that_cannot_be_created_exits_2_without_a_result_line(tmp_path, monkeypatch, capsys):
    """F10: an --out-root nothing can be created under (here a plain file; a read-only folder behaves the same for a
    user who is not root) is "the pre-flight could not run": exit 2, no RESULT line, no PREFLIGHT_DIR line."""
    pf = fresh()
    _clean_main_setup(tmp_path, monkeypatch, pf)
    blocker = tmp_path / "not_a_folder"
    blocker.write_text("x")
    with pytest.raises(SystemExit) as e:
        pf.main(["--skip-data", "--skip-tests", "--out-root", str(blocker)])
    captured = capsys.readouterr()
    assert e.value.code == 2 and "RESULT" not in captured.out and "PREFLIGHT_DIR=" not in captured.out
    assert captured.err.startswith("FAIL  cannot create the output folder") and pf.LINES == []


def test_a_crash_outside_the_checks_still_writes_result_fail_and_exits_2(tmp_path, monkeypatch):
    pf = fresh()
    _clean_main_setup(tmp_path, monkeypatch, pf)

    def boom(out):
        raise RuntimeError("SENTINEL_CRASH_DETAIL")
    pf.check_specs = boom  # unguarded on purpose
    code, summary, _ = _run_main(pf, ["--skip-data", "--skip-tests", "--out-root", str(tmp_path / "pf")])
    assert code == 2 and summary[-1].startswith("RESULT FAIL |") and summary[-1].endswith("exit 2")
    assert any(l.startswith("FAIL  pre-flight crashed: RuntimeError") for l in summary)
    assert "SENTINEL_CRASH_DETAIL" not in "\n".join(summary)
    assert closing_lines_precede_result(pf, summary)  # the closing lines are written even after a crash


def test_masked_first_line_removes_paths_urls_key_shaped_runs_and_long_numbers():
    pf = fresh()
    exc = FileNotFoundError("[Errno 2] No such file or directory: '/home/jovyan/your_id/tabular_fraud/test.yaml'\nsecond line")
    assert pf.masked_first_line(exc) == "[Errno 2] No such file or directory: <path>"
    exc2 = RuntimeError("endpoint https://s3.bank.example:9000/bucket refused key AKIA1234567890ABCDEF for user u42")
    assert pf.masked_first_line(exc2) == "endpoint <path> refused key <redacted> for user u42"
    assert pf.masked_first_line(ValueError("")) == "" and pf.masked_first_line(ValueError("x" * 300)) == "<redacted>"
    assert len(pf.masked_first_line(ValueError("a " * 300))) == 200
    assert pf.masked_first_line(ValueError("HTTP 403 for account 12345678")) == "HTTP 403 for account ########"


def test_s3_setup_failure_leaves_the_class_and_a_masked_first_line_in_the_errors_file(tmp_path, monkeypatch):
    """S1-F03: an S3 setup failure is no longer 'message withheld' with no record anywhere; the class and the first
    line of the message, paths and long numbers masked, go to errors.txt and SUMMARY says so."""
    pf = fresh()
    _clean_main_setup(tmp_path, monkeypatch, pf)

    def no_s3():
        raise FileNotFoundError("[Errno 2] No such file or directory: '/home/jovyan/your_id/tabular_fraud/test.yaml'")
    pf.s3_and_files = no_s3
    code, summary, out = _run_main(pf, ["--skip-tests", "--out-root", str(tmp_path / "pf")])
    assert code == 1 and pf.FAILS == ["S3 setup: FileNotFoundError (the exception class and the first line of its message, "
                                      "with paths and long numbers masked, are in errors.txt)"]
    errors = (out / "errors.txt").read_text()
    assert errors == "== S3 setup\nFileNotFoundError: [Errno 2] No such file or directory: <path>\n"
    everything = errors + "\n".join(summary)  # the SUMMARY header names the repository path, so only the message's parts are checked there
    assert "jovyan" not in everything and "your_id" not in everything and "test.yaml" not in everything
    assert "/home" not in errors and "/home" not in pf.FAILS[0]
    assert result_line(summary, 1, "none") and closing_lines_precede_result(pf, summary)


# ---------------------------------------------------------------- collector: configuration identity in the ledger
def _collector():
    s = importlib.util.spec_from_file_location(f"collector_fr1_{os.urandom(4).hex()}", HERE / "collect_returns.py")
    m = importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return m


def test_ledger_v5_appends_the_identity_columns_after_the_v4_columns():
    c = _collector()
    assert c.LEDGER_SCHEMA == "tf-runbook-ledger-v5"
    assert c.LEDGER_COLS[-3:] == ["manifest_sha256", "active_configs_sha256", "spec_sha256"]
    assert c.LEDGER_COLS[:-3][-3:] == ["revision", "transition", "evidence_sha256"]
    assert set(c.LEDGER_COLS[-3:]) <= set(c.EVIDENCE_COLS)
    import importlib.util as iu
    s = iu.spec_from_file_location("score_attempt_fr1", HERE / "score_attempt.py")
    sa = iu.module_from_spec(s)
    s.loader.exec_module(sa)
    assert "tf-runbook-ledger-v5" in sa.REVISIONED


def test_identity_comes_from_the_preflight_folder_else_the_manifest_file(tmp_path):
    c = _collector()
    pf_dir = tmp_path / "pf"
    pf_dir.mkdir()
    (pf_dir / "config_identity.json").write_text(json.dumps({"manifest_sha256": "a" * 64, "active_configs_sha256": "b" * 64}))
    ident = c.config_identity(str(pf_dir))
    assert ident == {"manifest_sha256": "a" * 64, "active_configs_sha256": "b" * 64, "source": "pre-flight pf"}
    live = c.config_identity(None)
    manifest = (HERE / "github_source_manifest.csv").read_bytes().replace(b"\r\n", b"\n")
    assert live["manifest_sha256"] == hashlib.sha256(manifest).hexdigest() and live["active_configs_sha256"] == ""
    assert c.config_identity(str(tmp_path / "no_such_preflight"))["source"] == "manifest file (no pre-flight identity)"


def test_rows_carry_manifest_active_config_and_spec_digests(tmp_path):
    c = _collector()
    att = tmp_path / "ablations" / "20261011T000000Z-attempt"
    att.mkdir(parents=True)
    OmegaConf.save(OmegaConf.create({"base_config": "YOUR_PACKAGE/phase4a/configs/sequential.yaml", "output_root": str(att.parent),
                                     "run_score": False, "common_overrides": ["training.seed=42"],
                                     "axes": {"history": {"h0": ["sequence.history_len=0"]}}}), att / "ablation_spec.yaml")
    ident = {"manifest_sha256": "a" * 64, "active_configs_sha256": "b" * 64, "source": "pre-flight x"}
    rows = c.collect_attempt(str(att), None, "", ident)
    assert [r["status"] for r in rows] == ["not_run"]
    assert rows[0]["manifest_sha256"] == "a" * 64 and rows[0]["active_configs_sha256"] == "b" * 64
    assert rows[0]["spec_sha256"] == hashlib.sha256((att / "ablation_spec.yaml").read_bytes()).hexdigest()
    plain = c.collect_attempt(str(att))  # no identity given: columns present and empty, spec digest still recorded
    assert plain[0]["manifest_sha256"] == "" and plain[0]["spec_sha256"] == rows[0]["spec_sha256"]
    ledger = tmp_path / "run_log.csv"
    assert c.append_ledger(str(ledger), rows, "20261011T010000Z") == (1, 0, [])
    stored = list(__import__("csv").DictReader(open(ledger)))
    assert list(stored[0]) == c.LEDGER_COLS and stored[0]["manifest_sha256"] == "a" * 64
    assert stored[0]["evidence_sha256"] == c.evidence_sha256(stored[0])
