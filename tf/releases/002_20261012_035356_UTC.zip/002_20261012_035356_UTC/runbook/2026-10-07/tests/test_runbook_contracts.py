# reviewer, 2026-10-07. Regression tests for the runbook scripts, built from reviewer's counterexamples against PR #3 at
# 5d053e4 (bridge/reviews/review/2026-10-07-review-PR3/). Each test failed on 5d053e4 and must pass now. Synthetic only.
#     PYTHONPATH=src:. python -m pytest -q runbook/2026-10-07/tests
import csv
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pandas as pd
import pytest
from omegaconf import OmegaConf

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[1]


def load(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return m


collector = load("cl_collector", HERE / "collect_returns.py")
RESULT_COLS = ["run_name", "mask", "train_rc", "best_valid_ap", "best_valid_auroc", "eval_ap", "eval_auroc", "attempt",
               "run_dir", "score_rc", "status", "predictions_path", "n_predictions", "n_positives", "checkpoint_epoch",
               "checkpoint_step", "checkpoint_monitor", "checkpoint_monitor_score", "checkpoint_sha256",
               "resolved_train_sha256", "source_sha256", "manifest_path", "error"]


def make_attempt(tmp, status="ok", run_score=True, score=None, rows="one", ckpt_bytes=b"CKPT"):
    att = tmp / "root" / "20261007T000000Z-abc"
    run = att / "mask-bidir"
    run.mkdir(parents=True)
    spec = {"base_config": "YOUR_PACKAGE/phase4a/configs/sequential.yaml", "output_root": str(tmp / "root"),
            "run_score": run_score, "common_overrides": [], "axes": {"mask": {"bidir": ["sequence.attention_mask=bidirectional"]}}}
    OmegaConf.save(OmegaConf.create(spec), att / "ablation_spec.yaml")
    shutil.copyfile(ROOT / "YOUR_PACKAGE/phase4a/configs/sequential.yaml", run / "resolved_train.yaml")
    (run / "best.ckpt").write_bytes(ckpt_bytes)
    sha = hashlib.sha256(ckpt_bytes).hexdigest()
    train_sha = hashlib.sha256((run / "resolved_train.yaml").read_bytes()).hexdigest()
    row = {c: "" for c in RESULT_COLS}
    row.update({"run_name": "mask-bidir", "mask": "bidir", "train_rc": 0, "best_valid_ap": 0.2, "best_valid_auroc": 0.9,
                "attempt": att.name, "run_dir": str(run), "status": status, "checkpoint_epoch": 3, "checkpoint_step": 40,
                "checkpoint_sha256": sha, "score_rc": 0 if run_score else "", "resolved_train_sha256": train_sha,
                "manifest_path": str(run / "run_manifest.json")})
    # v3 collector: the manifest mirrors the runner's (top-level config hashes; "result" is the results row itself).
    manifest = {"attempt": att.name, "run_name": "mask-bidir", "resolved_train_sha256": train_sha,
                "started_utc": "2026-10-07T00:00:00Z", "finished_utc": "2026-10-07T01:30:00Z", "result": row}
    if run_score:
        sm = {"schema_version": 1, "predictions_path": "bucket/p.parquet", "checkpoint_path": str(run / "best.ckpt"),
              "checkpoint_sha256": sha, "n_predictions": 1000, "n_positives": 10, "average_precision": 0.1, "auroc": 0.9}
        if score is not None:
            sm.update(score)
        (run / "score_metrics.json").write_text(json.dumps(sm))
        shutil.copyfile(run / "resolved_train.yaml", run / "resolved_score.yaml")
        manifest["resolved_score_sha256"] = hashlib.sha256((run / "resolved_score.yaml").read_bytes()).hexdigest()
        row.update({"eval_ap": sm["average_precision"], "eval_auroc": sm["auroc"], "n_predictions": sm["n_predictions"],
                    "n_positives": sm["n_positives"], "predictions_path": sm["predictions_path"]})
    (run / "run_manifest.json").write_text(json.dumps(manifest))
    with open(att / "results.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=RESULT_COLS)
        w.writeheader()
        if rows == "one":
            w.writerow(row)
    return att


def statuses(att):
    return [r["status"] for r in collector.collect_attempt(str(att))]


def test_valid_attempt_is_ok(tmp_path):
    assert statuses(make_attempt(tmp_path)) == ["ok"]


@pytest.mark.parametrize("runner_status", ["score_failed", "source_changed", "train_failed", "checkpoint_missing"])
def test_runner_failure_status_is_preserved(tmp_path, runner_status):
    assert statuses(make_attempt(tmp_path, status=runner_status)) == [runner_status]


def test_nan_or_empty_scores_are_invalid(tmp_path):
    att = make_attempt(tmp_path, score={"average_precision": float("nan"), "n_predictions": 0, "n_positives": 0})
    assert statuses(att)[0].startswith("invalid:")


def test_header_only_results_is_not_success(tmp_path):
    att = make_attempt(tmp_path, rows="none")
    assert statuses(att) == ["not_run"]
    p = subprocess.run([sys.executable, str(HERE / "collect_returns.py"), str(att), "--no-ledger", "--out", str(tmp_path / "o")],
                       capture_output=True, text=True)
    assert p.returncode == 1


def test_changed_checkpoint_is_invalid(tmp_path):
    att = make_attempt(tmp_path)
    (att / "mask-bidir" / "best.ckpt").write_bytes(b"DIFFERENT")
    assert "checkpoint_hash_changed" in statuses(att)[0]


def test_checkpoint_paired_values_pass_through(tmp_path):
    row = collector.collect_attempt(str(make_attempt(tmp_path)))[0]
    assert (row["valid_ap"], row["valid_auroc"], row["checkpoint_epoch"]) == ("0.2", "0.9", "3")


def test_validation_only_attempt_needs_no_score(tmp_path):
    assert statuses(make_attempt(tmp_path, run_score=False)) == ["ok"]


def test_ledger_is_idempotent_and_schema_checked(tmp_path):
    att = make_attempt(tmp_path)
    ledger = tmp_path / "ledger.csv"
    for k in (1, 2):
        subprocess.run([sys.executable, str(HERE / "collect_returns.py"), str(att), "--ledger", str(ledger),
                        "--out", str(tmp_path / f"o{k}")], check=True, capture_output=True)
    with open(ledger) as f:
        assert len(list(csv.DictReader(f))) == 1
    bad = tmp_path / "bad.csv"
    bad.write_text("a,b\n1,2\n")
    p = subprocess.run([sys.executable, str(HERE / "collect_returns.py"), str(att), "--ledger", str(bad),
                        "--out", str(tmp_path / "o3")], capture_output=True, text=True)
    assert p.returncode != 0 and bad.read_text() == "a,b\n1,2\n"


def fresh_preflight():
    return load(f"cl_preflight_{os.urandom(4).hex()}", HERE / "preflight_pod.py")


def test_missing_active_artifacts_fail(tmp_path):
    pf = fresh_preflight()

    class MissingFS:
        def open(self, *a, **k):
            raise FileNotFoundError("synthetic missing")
    cfg = OmegaConf.load(ROOT / "YOUR_PACKAGE/phase4a/configs/sequential.yaml")
    pf.check_artifacts(str(tmp_path), MissingFS(), cfg)
    assert any("active artifacts" in f for f in pf.FAILS)


def test_error_text_never_reaches_summary(tmp_path):
    pf = fresh_preflight()

    @pf.guarded("synthetic data read")
    def failing(out):
        raise ValueError("SENTINEL_ACCOUNT SENTINEL_SECRET")
    failing(str(tmp_path))
    assert not any("SENTINEL" in line for line in pf.LINES)
    assert "SENTINEL_ACCOUNT" in (tmp_path / "errors.txt").read_text()


def _cohort(tmp_path, case, ids, accounts=None):
    import fsspec
    out = tmp_path / case
    out.mkdir()
    files = []
    for i, ident in enumerate(ids):
        p = out / f"part_{i}.parquet"
        pd.DataFrame({"account": [accounts[i] if accounts else "accountA"],
                      "time": [pd.Timestamp("2025-01-01") + pd.Timedelta(days=i)], "label": [1], "id": [ident]}).to_parquet(p, index=False)
        files.append(str(p))
    cfg = OmegaConf.create({"data": {"account_col": "account", "order_col": "time", "target_col": "label",
                                     "tie_break_col": "id", "positive_label": 1}})
    pf = fresh_preflight()
    pf.check_data(str(out), fsspec.filesystem("file"), cfg, {"train": files})
    return json.loads((out / "data_contract.json").read_text())["train"]


def test_digest_has_no_framing_collision_and_ignores_file_order(tmp_path):
    a = _cohort(tmp_path, "one", ["1", "23"])
    b = _cohort(tmp_path, "two", ["12", "3"])
    c = _cohort(tmp_path, "three", ["23", "1"])
    assert a["composite_id_multiset_sha256"] != b["composite_id_multiset_sha256"]
    assert a["composite_id_multiset_sha256"] == c["composite_id_multiset_sha256"]


def test_account_in_three_files_counts_once(tmp_path):
    r = _cohort(tmp_path, "three_files", ["1", "2", "3"])
    assert r["accounts_in_more_than_one_file"] == 1


def _schema_run(tmp_path, eval_amount):
    import fsspec
    cfg = OmegaConf.create({"data": {"account_col": "account", "order_col": "time", "target_col": "label",
                                     "tie_break_col": "id", "positive_label": 1}})
    splits = {}
    for split, amount in (("train", [1.5]), ("eval_8000_8000", eval_amount)):
        p = tmp_path / f"{split}.parquet"
        pd.DataFrame({"account": ["a"], "time": [pd.Timestamp("2025-01-01")], "label": [1], "id": ["1"],
                      "amount": amount}).to_parquet(p, index=False)
        splits[split] = [str(p)]
    pf = fresh_preflight()
    pf.check_data(str(tmp_path), fsspec.filesystem("file"), cfg, splits)
    return pf, (tmp_path / "schema.txt").read_text(), json.loads((tmp_path / "data_contract.json").read_text())


def test_schema_recorded_per_split_and_differences_warn(tmp_path):
    (tmp_path / "same").mkdir()
    pf, text, contract = _schema_run(tmp_path / "same", [2.5])
    assert "[train] train.parquet: 5 columns" in text and "[eval_8000_8000] eval_8000_8000.parquet" in text
    assert contract["schema"]["differing_columns"] == [] and not pf.WARNS
    (tmp_path / "differ").mkdir()
    pf, text, contract = _schema_run(tmp_path / "differ", ["2.5"])  # stored as text in the evaluation file only
    assert contract["schema"]["differing_columns"] == ["amount"]
    line = next(x for x in text.splitlines() if x.startswith("  amount: train="))
    assert line.startswith("  amount: train=double, eval_8000_8000=") and line.endswith("string")  # or large_string
    assert any("1 column(s) differ" in w for w in pf.WARNS)
    assert contract["eval_8000_8000"]["rows"] == 1  # cohort entries are unchanged by the schema entry


def test_harness_and_batch_stop_on_preflight_failure(tmp_path):
    fake = tmp_path / "bin"
    fake.mkdir()
    real = sys.executable
    (fake / "python").write_text(f"#!/bin/sh\ncase \"$1\" in *preflight_pod.py) exit 1;; esac\nexec {real} \"$@\"\n")
    (fake / "python").chmod(0o755)
    env = dict(os.environ, PATH=f"{fake}:{os.environ['PATH']}", RUNBOOK_SANDBOX=str(tmp_path / "sb"))
    p = subprocess.run(["bash", str(HERE / "batch1.sh")], capture_output=True, text=True, env=env, timeout=120)
    assert p.returncode == 1 and "PRE-FLIGHT FAILED" in p.stdout and "== phase4" not in p.stdout


# ---------------------------------------------------------------- the synthetic harness must never reach real storage

SYN = HERE / "synthetic"


def _python_with_shim(env_extra, code="print('ran')"):
    env = {k: v for k, v in os.environ.items() if k not in ("FAKE_S3_ROOT", "TF_REPO_ROOT")}
    env.update(env_extra, PYTHONPATH=os.pathsep.join([str(SYN), str(ROOT / "src"), str(ROOT)]))
    return subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, env=env, timeout=120)


def test_shim_redirects_s3_when_active(tmp_path):
    p = _python_with_shim({"FAKE_S3_ROOT": str(tmp_path / "fs"), "TF_REPO_ROOT": str(ROOT)},
                          "import fraud.data.s3_utils as s; print(s.make_s3_filesystem.__name__)")
    assert p.returncode == 0 and p.stdout.strip() == "_fake_make_s3_filesystem"


@pytest.mark.parametrize("repo", ["missing", "unset"])
def test_shim_fails_closed_when_it_cannot_install(tmp_path, repo):
    extra = {"FAKE_S3_ROOT": str(tmp_path / "fs")}
    if repo == "missing":
        (tmp_path / "empty").mkdir()
        extra["TF_REPO_ROOT"] = str(tmp_path / "empty")  # 'fraud' cannot be imported from here
        p = subprocess.run([sys.executable, "-c", "print('ran')"], capture_output=True, text=True, timeout=120,
                           env={**{k: v for k, v in os.environ.items() if k not in ("FAKE_S3_ROOT", "TF_REPO_ROOT")},
                                **extra, "PYTHONPATH": str(SYN)})
    else:
        p = _python_with_shim(extra)
    assert p.returncode == 70 and "ran" not in p.stdout and "stopping" in p.stderr


@pytest.mark.parametrize("script,first_write", [("run_synthetic_e2e.sh", "make_synthetic_data.py"),
                                                ("positive_control.sh", "make_synthetic_data.py")])
def test_harness_scripts_refuse_without_the_redirect_before_any_write(script, first_write):
    text = (SYN / script).read_text()
    guard = text.index("_fake_make_s3_filesystem")
    assert guard < text.index(first_write) < text.index("build_preprocessing_artifacts.py")


# ---------------------------------------------------------------- A at h10 runs once: the controls stay paired with it

def _resolved_cells(spec_name):
    import itertools
    spec = OmegaConf.load(ROOT / "YOUR_PACKAGE/phase4a/configs" / spec_name)
    base = OmegaConf.load(ROOT / str(spec.base_config))
    axes = spec.get("axes", {})
    names = list(axes.keys())
    cells = {}
    for combo in itertools.product(*[list(axes[n].keys()) for n in names]):
        overrides = list(spec.get("common_overrides", []))
        for n, o in zip(names, combo):
            overrides += list(axes[n][o])
        cfg = OmegaConf.merge(base, OmegaConf.from_dotlist(overrides))
        cells["__".join(f"{n}-{o}" for n, o in zip(names, combo))] = OmegaConf.to_container(cfg, resolve=True)
    return cells


def _without(cfg, *dotted):
    import copy
    cfg = copy.deepcopy(cfg)
    for key in dotted:
        node = cfg
        *parents, leaf = key.split(".")
        for p in parents:
            node = node[p]
        node.pop(leaf)
    return cfg


def test_h10_controls_stay_paired_with_a_h10():
    [a_h10] = _resolved_cells("ft_decisions_flat_h10.yaml").values()
    gap = _resolved_cells("ft_decisions_timedelta.yaml")
    cap = _resolved_cells("ft_decisions_capacity.yaml")
    assert sorted(gap) == ["time_delta-False"]  # YAML reads the key `off` as False and sorted(cap) == ["capacity-large", "capacity-small"]
    # A-H10 is exactly the removed "time gap on" and "capacity current" cells.
    assert a_h10["sequence"]["time_delta"] is True
    assert (a_h10["model"]["input_embed_dim"], a_h10["model"]["num_attn_blocks"]) == (48, 4)
    assert gap["time_delta-False"]["sequence"]["time_delta"] is False
    assert _without(gap["time_delta-False"], "sequence.time_delta") == _without(a_h10, "sequence.time_delta")
    for cell in cap.values():
        assert _without(cell, "model.input_embed_dim", "model.num_attn_blocks") == \
            _without(a_h10, "model.input_embed_dim", "model.num_attn_blocks")


def test_batch1_records_the_shared_comparator_and_holds_the_control_without_it():
    text = (HERE / "batch1.sh").read_text()
    assert text.index('"phase4a ft_decisions_flat_h10.yaml"') < text.index('"phase4a ft_decisions_timedelta.yaml"')
    assert 'H10_DIR="$dir"' in text and "SHARED_COMPARATOR.txt" in text
    assert '[ "$2" = "ft_decisions_timedelta.yaml" ] && [ -z "$H10_DIR" ]' in text


# ---------------------------------------------------------------- the console log keeps every line (no reopen of stderr)

FAKE_BATCH_PY = r"""#!/bin/sh
# Stand-in for python in batch1.sh/batch2.sh: no training, just recognisable lines and the folders the scripts expect.
case "$1" in
  *preflight_pod.py) shift; while [ $# -gt 0 ]; do [ "$1" = --out-root ] && root="$2"; shift; done
                     mkdir -p "$root/20261008T000000Z"; echo '{}' > "$root/20261008T000000Z/data_contract.json"
                     echo "MARK pre-flight"; exit 0 ;;
  *run_step.py) for a in "$@"; do case "$a" in *.yaml) spec="$a" ;; esac; done
                echo "MARK step $spec"; echo "ATTEMPT_DIR=$RUNBOOK_SANDBOX/att_$spec"; exit 0 ;;
  *score_attempt.py) echo "MARK post-hoc scoring"; exit 0 ;;
  *collect_returns.py) echo "MARK collect"; exit 0 ;;
esac
exit 0
"""


@pytest.mark.parametrize("script,steps", [("batch1.sh", 5), ("batch2.sh", 5)])
def test_batch_console_log_keeps_every_line(tmp_path, script, steps):
    fake = tmp_path / "bin"
    fake.mkdir()
    (fake / "python").write_text(FAKE_BATCH_PY)
    (fake / "python").chmod(0o755)
    log = tmp_path / "console.log"
    env = dict(os.environ, PATH=f"{fake}:{os.environ['PATH']}", RUNBOOK_SANDBOX=str(tmp_path / "sb"))
    with open(log, "w") as f:  # exactly how MORNING.md runs a batch: nohup bash batchN.sh > log 2>&1
        subprocess.run(["bash", str(HERE / script)], stdout=f, stderr=subprocess.STDOUT, env=env, timeout=120)
    data = log.read_bytes()
    assert b"\x00" not in data, "the console log was truncated while a step ran"
    text = data.decode()
    assert "MARK pre-flight" in text and text.count("MARK step ") == steps
    assert text.index("MARK pre-flight") < text.index("MARK step ")
