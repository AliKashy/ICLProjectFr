# reviewer, 2026-10-07. Regression tests for reviewer's review of PR #3 at 2d6b1cc (review-005,
# bridge/reviews/review/2026-10-07-PR3-2d6b1cc/): the saved RETURN.txt carries ledger conflicts and the final acceptance;
# score counts must be integers; scored runs are tied to a named pre-flight's evaluation cohort (counts and the
# composite-id digest over the run's own prediction file); the already-scored shortcut cannot bypass the frozen-config
# check or an explicit override; blank, "." and folder fit entries stay unresolved; coverage samples training files
# outside the artifacts' fit subset. Synthetic only; the S3 helper is replaced by a local folder.
import csv
import importlib.util
import json
import os
import subprocess
import sys
import uuid
from pathlib import Path

import fsspec
import pandas as pd
import pytest
from fsspec.implementations.dirfs import DirFileSystem
from fsspec.implementations.local import LocalFileSystem
from omegaconf import OmegaConf

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import fraud.data.s3_utils as s3_utils  # noqa: E402


def load(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return m


c = load("collector_r3", HERE / "collect_returns.py")
tc = load("collector_v3_helpers_r3", HERE / "tests" / "test_collector_v3.py")
ts = load("score_attempt_v3_helpers_r3", HERE / "tests" / "test_score_attempt_v3.py")
BASE = OmegaConf.load(ROOT / "YOUR_PACKAGE/phase4a/configs/sequential.yaml")
ACCT, IDC = str(BASE.data.account_col), str(BASE.data.tie_break_col)
EVAL_KEY = f"eval_{BASE.eval.file_start}_{BASE.eval.file_end}"


@pytest.fixture
def fake_s3(tmp_path, monkeypatch):
    root = tmp_path / "s3"
    root.mkdir()
    monkeypatch.setattr(s3_utils, "make_s3_filesystem",
                        lambda *a, **k: DirFileSystem(path=str(root), fs=LocalFileSystem(auto_mkdir=True)))
    return root


def cohort_frame(n=8535, positives=347, seed=0):
    ids = [f"t{i:06d}" for i in range(n)]
    return pd.DataFrame({ACCT: [f"a{i % 400:04d}" for i in range(n)], IDC: ids,
                         str(BASE.data.order_col): pd.date_range("2025-10-28", periods=n, freq="min"),
                         str(BASE.data.target_col): [1 if i < positives else 0 for i in range(n)]})


def preflight_contract(tmp_path, df):
    """A real pre-flight data contract for one evaluation split, written by preflight_pod.check_data."""
    pf = load(f"preflight_r3_{uuid.uuid4().hex[:6]}", HERE / "preflight_pod.py")
    raw = tmp_path / "raw"
    raw.mkdir(exist_ok=True)
    path = raw / "part_8000.parquet"
    df.to_parquet(path, index=False)
    out = tmp_path / f"preflight_{uuid.uuid4().hex[:6]}"
    out.mkdir()
    import contextlib
    import io
    with contextlib.redirect_stdout(io.StringIO()):
        pf.check_data(str(out), fsspec.filesystem("file"), BASE, {EVAL_KEY: [str(path)]})
    assert (out / "data_contract.json").is_file()
    return out


def write_predictions(fake_s3, rel, df):
    p = fake_s3 / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    df.sample(frac=1, random_state=1)[[IDC, ACCT]].to_parquet(p, index=False)  # other order, other column order


# ---------------------------------------------------------------- collector: return contract and counts
def test_saved_return_reports_ledger_conflict_and_final_acceptance(tmp_path):
    att = tc.make_attempt(tmp_path)
    ledger = tmp_path / "run_log.csv"

    def collect():
        out = tmp_path / "out" / uuid.uuid4().hex
        p = subprocess.run([sys.executable, str(HERE / "collect_returns.py"), str(att), "--ledger", str(ledger),
                            "--out", str(out)], capture_output=True, text=True)
        return p.returncode, (out / "RETURN.txt").read_text()

    rc, text = collect()
    assert rc == 0 and "ACCEPTED: every run ok and recorded" in text and "NOT checked against a pre-flight" in text
    (att / "gpu_sweep.csv").write_text("2026-10-07T06:35:00Z, 40960 MiB\n")  # late GPU summary changes evidence
    rc, text = collect()
    assert rc == 1
    assert "CONFLICT" in text and "sweep_peak_gpu_mib" in text and "NOT ACCEPTED" in text
    assert "2 conflict(s)" in text  # the sweep summary belongs to the attempt, so both runs' evidence changed


def test_fractional_score_counts_are_rejected(tmp_path):
    att = tc.make_attempt(tmp_path)
    rows = tc.read_rows(att)
    for r in rows:
        r.update(n_predictions="375.5", n_positives="10.5")
        tc.edit_manifest(att, r["run_name"], n_predictions=375.5, n_positives=10.5)
        p = att / r["run_name"] / "score_metrics.json"
        sm = json.loads(p.read_text())
        sm.update(n_predictions=375.5, n_positives=10.5)
        p.write_text(json.dumps(sm))
    tc.save_rows(att, rows)
    assert set(tc.statuses(att).values()) == {"invalid:eval_counts"}


# ---------------------------------------------------------------- collector: pre-flight cohort linkage
def test_scored_runs_match_the_preflight_cohort(tmp_path, fake_s3):
    df = cohort_frame()
    contract_dir = preflight_contract(tmp_path, df)
    contract = json.loads((contract_dir / "data_contract.json").read_text())
    att = tc.make_attempt(tmp_path)
    for name in ("mask-bidir", "mask-causal"):
        write_predictions(fake_s3, f"bucket/predictions/{name}_preds.parquet", df)
    rows = c.collect_attempt(str(att), contract, contract_dir.name)
    assert {r["status"] for r in rows} == {"ok"}
    assert {r["cohort_check"] for r in rows} == {f"ok:{contract_dir.name}"}
    # One transaction id differs in one run's predictions: same counts, different cohort.
    changed = df.copy()
    changed.loc[5, IDC] = "other"
    write_predictions(fake_s3, "bucket/predictions/mask-causal_preds.parquet", changed)
    got = {r["run_name"]: (r["status"], r["cohort_check"]) for r in c.collect_attempt(str(att), contract, "pf")}
    assert got == {"mask-bidir": ("ok", "ok:pf"), "mask-causal": ("invalid:cohort_ids", "failed")}


def test_cohort_counts_missing_split_and_unreadable_predictions(tmp_path, fake_s3):
    df = cohort_frame()
    att = tc.make_attempt(tmp_path)
    smaller = json.loads((preflight_contract(tmp_path, df.iloc[:-1]) / "data_contract.json").read_text())
    for name in ("mask-bidir", "mask-causal"):
        write_predictions(fake_s3, f"bucket/predictions/{name}_preds.parquet", df)
    assert {r["status"] for r in c.collect_attempt(str(att), smaller, "pf")} == {"invalid:cohort_counts+cohort_ids"}
    assert {r["status"] for r in c.collect_attempt(str(att), {"eval_1_1": {}}, "pf")} == {"invalid:cohort_not_in_preflight"}
    for name in ("mask-bidir", "mask-causal"):
        (fake_s3 / f"bucket/predictions/{name}_preds.parquet").unlink()
    full = json.loads((preflight_contract(tmp_path, df) / "data_contract.json").read_text())
    assert {r["status"] for r in c.collect_attempt(str(att), full, "pf")} == {"invalid:cohort_predictions_unreadable"}


def test_validation_only_runs_are_not_cohort_checked(tmp_path):
    att = tc.make_attempt(tmp_path, run_score=False)
    rows = c.collect_attempt(str(att), {EVAL_KEY: {}}, "pf")
    assert {(r["status"], r["cohort_check"]) for r in rows} == {("ok", "not_scored")}
    scored = tc.make_attempt(tmp_path / "s")
    assert {r["cohort_check"] for r in c.collect_attempt(str(scored))} == {"not_requested"}


def test_digests_agree_across_preflight_collector_and_post_scorer(tmp_path, fake_s3):
    df = cohort_frame(n=500, positives=20)
    contract = json.loads((preflight_contract(tmp_path, df) / "data_contract.json").read_text())
    write_predictions(fake_s3, "bucket/p.parquet", df)
    score_yaml = tmp_path / "resolved_score.yaml"
    OmegaConf.save(BASE, score_yaml)
    sa = load("score_attempt_r3_digest", HERE / "score_attempt.py")
    want = contract[EVAL_KEY]["composite_id_multiset_sha256"]
    assert c.prediction_digest({"predictions_path": "bucket/p.parquet"}, str(score_yaml)) == want
    assert sa.prediction_digest("bucket/p.parquet", str(score_yaml)) == want


# ---------------------------------------------------------------- post-hoc scorer
FROZEN_WITH_DATA = ts.FROZEN + f"""data:
  account_col: {ACCT}
  tie_break_col: {IDC}
s3:
  cred_path: unused-by-the-fake
"""


def scored_attempt(tmp_path, monkeypatch, sa):
    att = ts.make_attempt(tmp_path)
    run_dir = att / "seed-s1__history-h0"
    ck = run_dir / "best.ckpt"
    (run_dir / "score_metrics.json").write_text(json.dumps({
        "schema_version": 1, "checkpoint_path": os.path.abspath(ck), "checkpoint_sha256": ts.sha(ck),
        "predictions_path": "bucket/runner_preds.parquet", "n_predictions": 100, "n_positives": 7,
        "average_precision": 0.3, "auroc": 0.8}))
    return att, run_dir


def test_already_scored_run_still_checks_the_frozen_config(tmp_path, monkeypatch, capsys, sa):
    att, run_dir = scored_attempt(tmp_path, monkeypatch, sa)
    (run_dir / "resolved_train.yaml").write_text(ts.FROZEN.replace("file_end: 8010", "file_end: 8005"))
    child = ts.Child()
    rc, out = ts.run(sa, monkeypatch, capsys, [att], child)
    assert rc == 1 and "config_changed" in out and "skipped:scored" not in out and child.calls == []


def test_override_on_an_already_scored_run_scores_afresh(tmp_path, monkeypatch, capsys, sa):
    att, run_dir = scored_attempt(tmp_path, monkeypatch, sa)
    child = ts.Child()
    rc, out = ts.run(sa, monkeypatch, capsys, [att, "--override-eval-files", "8000-8005"], child)
    assert rc == 0 and "skipped:scored" not in out and len(child.calls) == 1
    [post] = ts.post_dirs(run_dir)
    man = json.loads((post / "post_score_manifest.json").read_text())
    assert man["eval_range_override"] == {"file_start": 8000, "file_end": 8005} and man["status"] == "ok"
    rc, out = ts.run(sa, monkeypatch, capsys, [att], child)  # no override: the runner's own result stands
    assert rc == 0 and "skipped:scored" in out and len(child.calls) == 1


@pytest.fixture
def sa(monkeypatch):
    m = load(f"score_attempt_r3_{uuid.uuid4().hex[:6]}", HERE / "score_attempt.py")
    monkeypatch.setattr(m, "child_env", lambda: {})
    return m


def test_post_score_cohort_check(tmp_path, monkeypatch, capsys, sa, fake_s3):
    monkeypatch.setattr(ts, "FROZEN", FROZEN_WITH_DATA)
    df = cohort_frame(n=100, positives=7)
    contract_dir = preflight_contract(tmp_path, df)
    contract = json.loads((contract_dir / "data_contract.json").read_text())
    att = ts.make_attempt(tmp_path)
    tamper = {"on": False}

    def edit(payload, ck):
        frame = df.copy()
        if tamper["on"]:
            frame.loc[3, IDC] = "other"
        write_predictions(fake_s3, "bucket/predictions/x_preds.parquet", frame)
        return payload  # 100 predictions, 7 positives, as the contract says

    # The frozen config's evaluation range must name the split the pre-flight checked.
    assert EVAL_KEY in contract
    rc, out = ts.run(sa, monkeypatch, capsys, [att, "--preflight", contract_dir], ts.Child(edit=edit))
    assert rc == 0 and f"checked against pre-flight {contract_dir.name}" in out and "cohort_mismatch" not in out
    tamper["on"] = True
    att2 = ts.make_attempt(tmp_path / "second")
    rc, out = ts.run(sa, monkeypatch, capsys, [att2, "--preflight", contract_dir], ts.Child(edit=edit))
    assert rc == 1 and "cohort_mismatch" in out and "cohort_ids" in out


def test_v4_ledger_uses_revisions(sa, tmp_path):
    a = str(tmp_path / "att")
    cols = ts.V3_COLS
    rows = [{"ledger_schema": "tf-runbook-ledger-v4", "attempt_dir": a, "run_name": "r1", "status": "not_run",
             "run_score": "False", "revision": 1},
            {"ledger_schema": "tf-runbook-ledger-v4", "attempt_dir": a, "run_name": "r1", "status": "ok",
             "run_score": "False", "revision": 2}]
    path = ts.write_ledger(tmp_path / "ledger.csv", cols, rows)
    assert sa.ledger_selection(str(path)) == {os.path.realpath(a): {"r1"}}


# ---------------------------------------------------------------- pre-flight
@pytest.mark.parametrize("entry", ["", " ", ".", "s3://bucket/val/", "s3://bucket/val"])
def test_blank_dot_and_folder_fit_entries_are_unresolved(entry):
    pf = load(f"preflight_r3_fit_{uuid.uuid4().hex[:6]}", HERE / "preflight_pod.py")
    held = ["s3://bucket/val/part_4950.parquet", "s3://bucket/eval/part_8000.parquet"]
    overlap, unresolved = pf.fit_provenance([entry], held)
    assert overlap == [] and len(unresolved) == 1
    assert pf.fit_provenance(["part_1.parquet"], held) == ([], [])
    assert pf.fit_provenance(["s3://bucket/val/part_4950.parquet"], held)[0] == ["bucket/val/part_4950.parquet"]


def test_coverage_samples_training_files_outside_the_fit_subset(tmp_path):
    pf = load(f"preflight_r3_cov_{uuid.uuid4().hex[:6]}", HERE / "preflight_pod.py")
    (tmp_path / "predictors.csv").write_text("feature,type,source,version\nhour,categorical,derived:time,1\n")
    art = tmp_path / "artifacts/1"
    art.mkdir(parents=True)
    fit = [f"part_{i}.parquet" for i in (1, 2, 3, 4, 5)]
    (art / "manifest.json").write_text(json.dumps({"artifact_version": 1, "features": ["hour"], "fit_files": fit}))
    (art / "feature_hour.json").write_text(json.dumps({"type": "categorical", "vocab": {"3": 2}, "unk_index": 0,
                                                       "missing_index": 1, "cardinality": 3}))
    files = []
    for i in range(1, 11):
        p = tmp_path / f"part_{i}.parquet"
        hour = 3 if i <= 5 else 7  # files 6-10 hold an hour the vocabulary never saw
        pd.DataFrame({"time": pd.to_datetime([f"2025-01-0{1 + i % 9} {hour:02d}:00"] * 4)}).to_parquet(p, index=False)
        files.append(str(p))
    cfg = OmegaConf.create({"predictors": {"csv_path": str(tmp_path / "predictors.csv"), "version": 1},
                            "artifacts": {"base": str(tmp_path / "artifacts"), "version": 1}, "data": {"order_col": "time"},
                            "datetime": {"fields": ["hour"], "encoding": "categorical", "is_weekend": False}})
    import contextlib
    import io
    with contextlib.redirect_stdout(io.StringIO()):
        pf.check_feature_coverage(str(tmp_path), fsspec.filesystem("file"), cfg, {"train_1_10": files})
    rep = json.loads((tmp_path / "feature_coverage.json").read_text())
    assert rep["train_1_10"]["files_checked"] == 3 and rep["train_1_10"]["unknown_category_rate"]["hour"] == 0.0
    assert rep["train_1_10_outside_fit"]["files_checked"] == 3
    assert rep["train_1_10_outside_fit"]["unknown_category_rate"]["hour"] == 1.0


# ---------------------------------------------------------------- review-008: acceptance relative to the pre-flight
def test_rejected_post_score_is_kept_and_a_retry_scores_afresh(tmp_path, monkeypatch, capsys, sa, fake_s3):
    monkeypatch.setattr(ts, "FROZEN", FROZEN_WITH_DATA)
    df = cohort_frame(n=100, positives=7)
    contract_dir = preflight_contract(tmp_path, df)
    att = ts.make_attempt(tmp_path)
    run_dir = att / "seed-s1__history-h0"
    tamper = {"on": True}

    def edit(payload, ck):
        frame = df.copy()
        if tamper["on"]:
            frame.loc[3, IDC] = "other"
        write_predictions(fake_s3, "bucket/predictions/x_preds.parquet", frame)
        return payload

    child = ts.Child(edit=edit)
    rc, out = ts.run(sa, monkeypatch, capsys, [att, "--preflight", contract_dir], child)
    assert rc == 1 and "cohort_mismatch" in out and len(child.calls) == 1
    [first] = ts.post_dirs(run_dir)
    [rec_path] = list(first.glob("cohort_acceptance_*.json"))
    rec = json.loads(rec_path.read_text())
    assert rec["verdict"] == "failed" and rec["failed_checks"] == ["cohort_ids"] and rec["preflight_name"] == contract_dir.name
    evidence = ts.snapshot(first)
    # Same pre-flight, data repaired: the rejected folder is not reused; a fresh scoring runs in a new folder.
    tamper["on"] = False
    rc, out = ts.run(sa, monkeypatch, capsys, [att, "--preflight", contract_dir], child)
    assert rc == 0 and len(child.calls) == 2 and f"prior_invalid post_score/{first.name}: rejected for pre-flight" in out
    second = [f for f in ts.post_dirs(run_dir) if f != first][0]
    assert json.loads(next(second.glob("cohort_acceptance_*.json")).read_text())["verdict"] == "ok"
    assert ts.snapshot(first) == evidence  # the rejected evidence is untouched
    # A further retry reuses the accepted folder.
    rc, out = ts.run(sa, monkeypatch, capsys, [att, "--preflight", contract_dir], child)
    assert rc == 0 and len(child.calls) == 2 and f"post_score/{second.name} (existing, revalidated)" in out


def test_acceptance_is_relative_to_the_requested_preflight(tmp_path, monkeypatch, capsys, sa, fake_s3):
    monkeypatch.setattr(ts, "FROZEN", FROZEN_WITH_DATA)
    df = cohort_frame(n=100, positives=7)
    good = preflight_contract(tmp_path, df)
    other = df.copy()
    other.loc[3, IDC] = "other"
    bad = preflight_contract(tmp_path, other)  # a contract the predictions do not match
    att = ts.make_attempt(tmp_path)
    run_dir = att / "seed-s1__history-h0"

    def edit(payload, ck):
        write_predictions(fake_s3, "bucket/predictions/x_preds.parquet", df)
        return payload

    child = ts.Child(edit=edit)
    assert ts.run(sa, monkeypatch, capsys, [att, "--preflight", bad], child)[0] == 1
    # Under a different, matching pre-flight the old folder was never judged: it is checked, accepted and reused.
    rc, out = ts.run(sa, monkeypatch, capsys, [att, "--preflight", good], child)
    assert rc == 0 and len(child.calls) == 1 and "skipped:valid_exists" in out
    [folder] = ts.post_dirs(run_dir)
    verdicts = sorted(json.loads(p.read_text())["verdict"] for p in folder.glob("cohort_acceptance_*.json"))
    assert verdicts == ["failed", "ok"]
    # Without --preflight nothing is judged and the banner says so.
    rc, out = ts.run(sa, monkeypatch, capsys, [att], child)
    assert rc == 0 and "NOT checked against a pre-flight" in out and len(child.calls) == 1


def test_later_failed_check_is_appended_and_allows_a_fresh_score(tmp_path, monkeypatch, capsys, sa, fake_s3):
    """review-009 Q-review-09A: an accepted result whose prediction file later disappears is re-judged, the failure is
    appended after the historical acceptance, and the next checked call scores afresh."""
    monkeypatch.setattr(ts, "FROZEN", FROZEN_WITH_DATA)
    df = cohort_frame(n=100, positives=7)
    contract_dir = preflight_contract(tmp_path, df)
    att = ts.make_attempt(tmp_path)
    run_dir = att / "seed-s1__history-h0"

    def edit(payload, ck):
        write_predictions(fake_s3, "bucket/predictions/x_preds.parquet", df)
        return payload

    child = ts.Child(edit=edit)
    assert ts.run(sa, monkeypatch, capsys, [att, "--preflight", contract_dir], child)[0] == 0
    [first] = ts.post_dirs(run_dir)
    [ok_record] = sorted(first.glob("cohort_acceptance_*.json"))
    accepted = ok_record.read_bytes()
    (fake_s3 / "bucket/predictions/x_preds.parquet").unlink()
    rc, out = ts.run(sa, monkeypatch, capsys, [att, "--preflight", contract_dir], child)
    assert rc == 1 and "cohort_predictions_unreadable" in out and len(child.calls) == 1
    records = sorted(first.glob("cohort_acceptance_*.json"))
    assert len(records) == 2 and records[0].read_bytes() == accepted
    assert json.loads(records[1].read_text())["verdict"] == "failed"
    rc, out = ts.run(sa, monkeypatch, capsys, [att, "--preflight", contract_dir], child)
    assert rc == 0 and len(child.calls) == 2 and len(ts.post_dirs(run_dir)) == 2
    assert sorted(first.glob("cohort_acceptance_*.json")) == records  # the old folder's history is untouched
