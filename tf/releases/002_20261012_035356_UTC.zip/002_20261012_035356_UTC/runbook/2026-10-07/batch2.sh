#!/usr/bin/env bash
# Batch 2 DRAFT (reviewer, 2026-10-07). Do not start until reviewers have read batch 1's results: its order
# and contents may change with them. Requires the runners of PR #5. Run from anywhere:
#     bash runbook/2026-10-07/batch2.sh
# Skip steps:  BATCH2_SKIP="ft_decisions_capacity.yaml" bash runbook/2026-10-07/batch2.sh
#   0. pre-flight (any FAIL stops the batch before training)
#   1. post-hoc scoring of batch 1's validation-only checkpoints on 8000-8010 (minutes; reads runs/run_log.csv);
#      its table, per-run CSV and safe evidence files go into the batch 2 return folder
#   2. ft_decisions.yaml             A at h5, bidirectional / causal mask, scored   about 2 x the h5 cost
#      (causal is plan row A-MASK05-C; bidirectional repeats A-H05 at seed 42 and measures same-seed GPU noise)
#   3. ft_decisions_flat_h15.yaml    A at h15 (256 x 16), scored                about 9.7 h (2026-10-06 run)
#   4. ft_decisions_hier_long.yaml   B at h15 and h20 (2048 x 2), scored        cost not yet measured
#   5. ft_decisions_flat_h20.yaml    A at h20 (128 x 32), scored                roughly 15 h or more
#   6. ft_decisions_capacity.yaml    A at h10, small and large, validation only (the current size is A-H10 from
#      batch 1, run once)                                                       roughly 10 h
# Cheapest first, so results arrive early; skip any step with BATCH2_SKIP.
# Send: the pre-flight folder, runs/returns/batch2_<time>/ (RETURN.txt, POST_SCORE.txt,
# post_score_results.csv, post_score/) and runs/run_log.csv.
set -uo pipefail
cd "$(dirname "$0")/../.."
HERE=runbook/2026-10-07
SB="${RUNBOOK_SANDBOX:-}"
PF=runs/preflight; LEDGER=runs/run_log.csv
[ -n "$SB" ] && { PF="$SB/preflight"; LEDGER="$SB/runs/run_log.csv"; }
SKIP=" ${BATCH2_SKIP:-} "

python "$HERE/preflight_pod.py" --out-root "$PF" ${PREFLIGHT_ARGS:-} || { echo "PRE-FLIGHT FAILED: nothing was run."; exit 1; }
PFDIR=$(ls -td "$PF"/*/ 2>/dev/null | head -1); PFDIR="${PFDIR%/}"
[ -f "$PFDIR/data_contract.json" ] || { echo "PRE-FLIGHT FOLDER NOT FOUND under $PF: nothing was run."; exit 1; }
echo "pre-flight folder for this batch: $PFDIR (scored runs are checked against its evaluation cohort)"

failed=0; ATTEMPTS=()
OUT=runs/returns/batch2_$(date -u +%Y%m%dT%H%M%SZ); [ -n "$SB" ] && OUT="$SB/returns/batch2_summary"
echo "== post-hoc scoring of validation-only attempts in $LEDGER (return copy: $OUT)"
python "$HERE/score_attempt.py" --from-ledger "$LEDGER" --preflight "$PFDIR" --return-dir "$OUT" \
  || { echo "post-hoc scoring reported a problem; continuing"; failed=1; }

for step in "phase4a ft_decisions.yaml" "phase4a ft_decisions_flat_h15.yaml" \
            "phase4b ft_decisions_hier_long.yaml" \
            "phase4a ft_decisions_flat_h20.yaml" "phase4a ft_decisions_capacity.yaml"; do
  set -- $step
  if [[ "$SKIP" == *" $2 "* ]]; then echo "== skipped $2 (BATCH2_SKIP)"; continue; fi
  # Echo the step's output through the inherited stderr descriptor. `tee /dev/stderr` would reopen the console log and
  # truncate it on Linux, erasing everything printed before this step.
  out=$(python "$HERE/run_step.py" --phase "$1" --spec "$2" --preflight "$PFDIR" | tee >(cat >&2)); rc=$?
  dir=$(printf '%s\n' "$out" | sed -n 's/^ATTEMPT_DIR=//p' | tail -1)
  [ -n "$dir" ] && ATTEMPTS+=("$dir")
  [ $rc -ne 0 ] && { echo "STEP $2: not all runs are ok; continuing"; failed=1; }
done

echo; echo "===== BATCH 2 SUMMARY (send $OUT/ and runs/run_log.csv) ====="
if [ ${#ATTEMPTS[@]} -gt 0 ]; then
  python "$HERE/collect_returns.py" --no-ledger --preflight "$PFDIR" --out "$OUT" "${ATTEMPTS[@]}" || failed=1
fi
echo "Batch 2 finished: $([ $failed -eq 0 ] && echo 'all runs ok' || echo 'SOME RUNS NEED ATTENTION')"
exit $failed
