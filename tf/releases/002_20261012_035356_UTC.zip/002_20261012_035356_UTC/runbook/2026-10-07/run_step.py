#!/usr/bin/env python3
# Written by reviewer (2026-10-07), version 2 after reviewer's review of 5d053e4. Requires PR #4's attempt-isolated
# runners. Runs ONE committed sweep spec with the project's own run_ablations.py (which creates a new
# <output_root>/<attempt>/ and never overwrites), samples GPU memory for the whole sweep, then validates and
# records the attempt with collect_returns.py. On the pod the spec runs unchanged.
"""Run one sweep step.

    python runbook/2026-10-07/run_step.py --phase phase4a --spec ft_decisions_h0_seeds.yaml

Prints ATTEMPT_DIR=<path> as its last line. Exit code: 0 only if the runner and the collector both succeed.
--sandbox DIR (reviewer's CPU harness only) runs a derived copy of the spec with documented size reductions.
"""
import argparse
import os
import re
import shutil
import subprocess
import sys
import time

from omegaconf import OmegaConf

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
HERE = os.path.dirname(os.path.abspath(__file__))
SANDBOX_OVERRIDES = [
    "training.num_workers=0", "training.max_epochs=1", "training.accelerator=cpu", "training.precision=32-true",
    "model.input_embed_dim=16", "model.num_attn_blocks=1", "model.num_txn_blocks=1", "model.num_seq_blocks=1",
]


def shrink_batch(ov, scale):
    m = re.fullmatch(r"training\.batch_size=(\d+)", ov.strip())
    return f"training.batch_size={max(8, int(m.group(1)) // scale)}" if m else ov


def child_env():
    """The project's scripts add the repository root to sys.path but not src/ (vendored pytorch_tabular).
    Add src/ only when this interpreter cannot already import pytorch_tabular, so an installed copy is never shadowed."""
    env = dict(os.environ)
    probe = subprocess.run([sys.executable, "-c", "import pytorch_tabular"], cwd=ROOT, env=env,
                           capture_output=True)
    if probe.returncode != 0 and os.path.isdir(os.path.join(ROOT, "src", "pytorch_tabular")):
        env["PYTHONPATH"] = os.pathsep.join([os.path.join(ROOT, "src"), ROOT] +
                                            ([env["PYTHONPATH"]] if env.get("PYTHONPATH") else []))
    return env


def attempts_in(root):
    if not os.path.isdir(root):
        return set()
    return {d for d in os.listdir(root) if os.path.isdir(os.path.join(root, d))}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase", required=True, choices=["phase4a", "phase4b"])
    ap.add_argument("--spec", required=True, help="file name under YOUR_PACKAGE/<phase>/configs/")
    ap.add_argument("--sandbox", default=os.environ.get("RUNBOOK_SANDBOX"), help="sandbox folder (CPU harness only)")
    ap.add_argument("--batch-scale", type=int, default=32)
    ap.add_argument("--preflight", default=None,
                    help="this batch's pre-flight output folder; scored runs are checked against its evaluation cohort")
    args = ap.parse_args()

    spec_path = os.path.join(ROOT, "YOUR_PACKAGE", args.phase, "configs", args.spec)
    spec = OmegaConf.load(spec_path)
    root = str(spec.output_root)
    ledger_args = []
    if args.sandbox:
        sb = os.path.abspath(args.sandbox)
        root = os.path.join(sb, "ablations", os.path.basename(root.rstrip("/")))
        spec.output_root = root
        spec.results_csv = os.path.join(root, "results.csv")
        base_bs = int(OmegaConf.load(os.path.join(ROOT, str(spec.base_config))).training.batch_size)
        common = [shrink_batch(str(o), args.batch_scale) for o in spec.get("common_overrides", [])]
        if not any(str(o).startswith("training.batch_size=") for o in common):
            common.append(f"training.batch_size={max(8, base_bs // args.batch_scale)}")
        spec.common_overrides = common + SANDBOX_OVERRIDES
        for axis in spec.get("axes", {}):
            for opt in spec.axes[axis]:
                spec.axes[axis][opt] = [shrink_batch(str(o), args.batch_scale) for o in spec.axes[axis][opt]]
        os.makedirs(os.path.join(sb, "specs"), exist_ok=True)
        spec_path = os.path.join(sb, "specs", f"{args.phase}_{args.spec}")
        OmegaConf.save(spec, spec_path)
        ledger_args = ["--ledger", os.path.join(sb, "runs", "run_log.csv")]
    abs_root = root if os.path.isabs(root) else os.path.join(ROOT, root)
    before = attempts_in(abs_root)
    stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    gpu_tmp = os.path.join(args.sandbox or ROOT, "runs", "gpu", f"{os.path.splitext(args.spec)[0]}_{stamp}.csv")
    os.makedirs(os.path.dirname(gpu_tmp), exist_ok=True)
    runner = os.path.join(ROOT, "YOUR_PACKAGE", args.phase, "scripts", "run_ablations.py")
    print(f"== {args.phase}/{args.spec} (output root {os.path.relpath(abs_root, ROOT)})", flush=True)
    sampler = None
    if shutil.which("nvidia-smi") and not args.sandbox:
        sampler = subprocess.Popen(["nvidia-smi", "--query-gpu=timestamp,memory.used,utilization.gpu",
                                    "--format=csv", "-l", "30"], stdout=open(gpu_tmp, "w"), stderr=subprocess.DEVNULL)
    t0 = time.time()
    log_path = os.path.join(args.sandbox or ROOT, "runs", "logs", f"{os.path.splitext(args.spec)[0]}_{stamp}.runner.log")
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    with open(log_path, "w") as log:
        rc = subprocess.run([sys.executable, runner, "--config", spec_path], cwd=ROOT, stdout=log,
                            stderr=subprocess.STDOUT, env=child_env()).returncode
    if sampler:
        sampler.terminate()
        sampler.wait(timeout=30)
    new = sorted(attempts_in(abs_root) - before)
    print(f"   runner exit {rc} after {(time.time() - t0) / 3600:.2f} h; runner log {os.path.relpath(log_path, ROOT)}", flush=True)
    if len(new) != 1:
        print(f"   NO SINGLE NEW ATTEMPT FOLDER under {os.path.relpath(abs_root, ROOT)} (found {len(new)}); "
              f"the runner refused or failed before starting. See the runner log.", flush=True)
        print("ATTEMPT_DIR=")
        sys.exit(rc or 2)
    attempt_dir = os.path.join(abs_root, new[0])
    if os.path.isfile(gpu_tmp) and os.path.getsize(gpu_tmp) > 0:
        shutil.copyfile(gpu_tmp, os.path.join(attempt_dir, "gpu_sweep.csv"))
    out = os.path.join(args.sandbox or ROOT, "runs", "returns", f"{os.path.splitext(args.spec)[0]}_{stamp}")
    pf_args = ["--preflight", args.preflight] if args.preflight else []
    col = subprocess.run([sys.executable, os.path.join(HERE, "collect_returns.py"), attempt_dir, "--out", out,
                          *ledger_args, *pf_args], cwd=ROOT, env=child_env())
    print(f"ATTEMPT_DIR={attempt_dir}", flush=True)
    sys.exit(rc or col.returncode)


if __name__ == "__main__":
    main()
