#!/usr/bin/env bash
# Batch 1 of the bare-minimum study (reviewer, 2026-10-07, v2). Requires the runners of PR #5 (attempt folders).
# Run from anywhere:   bash runbook/2026-10-07/batch1.sh
# Skip a step that already ran:   BATCH1_SKIP="ft_decisions_h0.yaml" bash runbook/2026-10-07/batch1.sh
# Extra pre-flight flags (only on review advice):   PREFLIGHT_ARGS="--skip-tests" bash ...
# Order: pre-flight (any FAIL stops the batch before training), then five sweeps. Every sweep writes a NEW attempt
# folder <output_root>/<UTC>-<id>/ and never overwrites. Expected GPU time on the H200: roughly 25 to 30 hours,
# from the 2026-10-06 h10 (4.9 h) and h15 (9.7 h) runs; h0 is minutes, h5 and B are not yet measured.
#   1. ft_decisions_h0.yaml        2 runs: history 0 and 5, seed 42 (your file)
#   2. ft_decisions_h0_seeds.yaml  4 runs: the same at seeds 43 and 44
#   3. ft_decisions_hier.yaml      2 runs: Architecture B at h5 and h10 (matched to A's h5 and h10)
#   4. ft_decisions_flat_h10.yaml  1 run: A at h10 (1024 x 4), scored: plan row A-H10, also the shared partner of
#      the time-gap and capacity controls (owner, 2026-10-08: A at h10 runs once)      about 4.9 h (2026-10-06 run)
#   5. ft_decisions_timedelta.yaml 1 run: h10 with the time-gap field off (its "on" partner is step 4)
# Steps 1, 2 and 5 are validation-only by design; steps 3 and 4 also score 8000-8010.
# A-H10 (step 4) is the shared comparator; its attempt folder is written to runs/returns/batch1_<time>/SHARED_COMPARATOR.txt,
# and step 5 is skipped if A-H10 has no ok attempt (or A_H10_COMPARATOR=<attempt folder> names an earlier one).
# Send: the pre-flight folder, runs/returns/batch1_<time>/ and runs/run_log.csv.
set -uo pipefail
cd "$(dirname "$0")/../.."
HERE=runbook/2026-10-07
SB="${RUNBOOK_SANDBOX:-}"
PF=runs/preflight; [ -n "$SB" ] && PF="$SB/preflight"
SKIP=" ${BATCH1_SKIP:-} "

python "$HERE/preflight_pod.py" --out-root "$PF" ${PREFLIGHT_ARGS:-} || { echo "PRE-FLIGHT FAILED: nothing was trained. Send the folder $PF/<time>/."; exit 1; }
PFDIR=$(ls -td "$PF"/*/ 2>/dev/null | head -1); PFDIR="${PFDIR%/}"
[ -f "$PFDIR/data_contract.json" ] || { echo "PRE-FLIGHT FOLDER NOT FOUND under $PF: nothing was run."; exit 1; }
echo "pre-flight folder for this batch: $PFDIR (scored runs are checked against its evaluation cohort)"

failed=0; ATTEMPTS=()
# The shared A-H10 comparator (RUN_PROTOCOL v2.2 Section 3): the ok ft_decisions_flat_h10.yaml attempt of this batch,
# or, when that step is skipped with BATCH1_SKIP, an earlier ok attempt named in A_H10_COMPARATOR=<attempt folder>.
H10_DIR="${A_H10_COMPARATOR:-}"
for step in "phase4a ft_decisions_h0.yaml" "phase4a ft_decisions_h0_seeds.yaml" "phase4b ft_decisions_hier.yaml" \
            "phase4a ft_decisions_flat_h10.yaml" "phase4a ft_decisions_timedelta.yaml"; do
  set -- $step
  if [[ "$SKIP" == *" $2 "* ]]; then echo "== skipped $2 (BATCH1_SKIP)"; continue; fi
  if [ "$2" = "ft_decisions_timedelta.yaml" ] && [ -z "$H10_DIR" ]; then
    echo "== skipped $2: its partner A-H10 (ft_decisions_flat_h10.yaml) has no ok attempt in this batch; rerun A-H10"
    echo "   first, or name an earlier ok attempt with A_H10_COMPARATOR=<attempt folder>"; failed=1; continue
  fi
  # Echo the step's output through the inherited stderr descriptor. `tee /dev/stderr` would reopen the console log and
  # truncate it on Linux, erasing everything printed before this step.
  out=$(python "$HERE/run_step.py" --phase "$1" --spec "$2" --preflight "$PFDIR" | tee >(cat >&2)); rc=$?
  dir=$(printf '%s\n' "$out" | sed -n 's/^ATTEMPT_DIR=//p' | tail -1)
  [ -n "$dir" ] && ATTEMPTS+=("$dir")
  [ "$2" = "ft_decisions_flat_h10.yaml" ] && [ $rc -eq 0 ] && [ -n "$dir" ] && H10_DIR="$dir"
  [ $rc -ne 0 ] && { echo "STEP $2: not all runs are ok (see its RETURN block above); continuing"; failed=1; }
done

echo; echo "===== BATCH 1 SUMMARY (send runs/returns/batch1_<time>/, runs/run_log.csv and the pre-flight folder) ====="
if [ ${#ATTEMPTS[@]} -gt 0 ]; then
  OUT=runs/returns/batch1_$(date -u +%Y%m%dT%H%M%SZ); [ -n "$SB" ] && OUT="$SB/returns/batch1_summary"
  python "$HERE/collect_returns.py" --no-ledger --preflight "$PFDIR" --out "$OUT" "${ATTEMPTS[@]}" || failed=1
  if [ -n "$H10_DIR" ]; then
    printf 'A_H10_COMPARATOR=%s\nrun=history-h10\npreflight=%s\nused_by=A-GAP10-OFF (this batch), A-CAP10-SMALL and A-CAP10-LARGE (batch 2)\n' \
      "$H10_DIR" "$PFDIR" > "$OUT/SHARED_COMPARATOR.txt"
    echo "shared A-H10 comparator: $H10_DIR (recorded in $OUT/SHARED_COMPARATOR.txt)"
  else
    echo "no shared A-H10 comparator in this batch"
  fi
else
  echo "no attempt folders were created"; failed=1
fi
echo "Batch 1 finished: $([ $failed -eq 0 ] && echo 'all runs ok' || echo 'SOME RUNS NEED ATTENTION')"
exit $failed
