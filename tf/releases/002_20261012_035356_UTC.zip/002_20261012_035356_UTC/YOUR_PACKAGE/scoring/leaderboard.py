"""Benchmark leaderboard across all models (Idea F).

Given named prediction parquet sets (id, target, score) on a common test range,
computes PR-AUC / ROC-AUC + precision@budget for each and prints a ranked table,
also writing a leaderboard CSV. Seed means use identical transaction cohorts.
Intervals resample that cohort jointly across the supplied, fixed seed models;
they quantify evaluation-sampling uncertainty, not training-seed uncertainty.
Use --group for account-block resampling when observations share an account.

The legacy pr_auc / PR-AUC label denotes sklearn average precision (AP), not
trapezoidal integration of a precision-recall curve.

Usage:
    python YOUR_PACKAGE/scoring/leaderboard.py \
        --model baseline=s3://.../predictions/baseline \
        --model streaming=s3://.../predictions/streaming \
        --model sequential=s3://.../predictions/sequential \
        --model gbm=s3://.../predictions/gbm \
        --model ensemble=s3://.../predictions/ensemble \
        --out leaderboard.csv
"""

import argparse
import csv
import os
import sys

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from fraud.data.s3_utils import make_s3_filesystem
from fraud.log_utils import setup_logging
from YOUR_PACKAGE.scoring._prediction_utils import (
    add_path_argument,
    at_budget,
    prediction_path,
    read_predictions,
    validate_ids,
)

log = setup_logging()


def _read(path, fs):
    return read_predictions(path, fs)


def _precision_at(y, s, frac):
    return at_budget(y, s, frac)[1]


def _bootstrap_ci(y, s, metric_fn, n_boot, seed=0, groups=None, return_details=False):
    """Percentile CI for mean metric across fixed seed models on paired resamples.

    ``s`` is [rows] or [rows, seeds]. With groups, an account is sampled as a
    whole block; otherwise rows are sampled independently. No training seeds
    are resampled, so this interval must not be called training uncertainty.
    Single-class resamples are omitted and counted. This interval is conditional
    on both classes being represented. Fewer than two groups yields no CI.
    Resampling the same IDs with the same RNG seed pairs evaluation cohorts
    across models; separate model intervals are not an interval on a difference.
    """
    y, scores = np.asarray(y), np.asarray(s, dtype=float)
    if y.ndim != 1 or not len(y) or not np.isin(y, [0, 1]).all():
        raise ValueError("Bootstrap targets must be a nonempty binary vector")
    if scores.ndim == 1:
        scores = scores[:, None]
    if scores.ndim != 2 or scores.shape[0] != len(y) or scores.shape[1] == 0:
        raise ValueError("scores must contain one aligned column per seed")
    if not np.isfinite(scores).all():
        raise ValueError("Bootstrap scores must be finite")
    if not isinstance(n_boot, (int, np.integer)) or n_boot < 0:
        raise ValueError("n_boot must be a non-negative integer")
    blocks = None
    if groups is not None:
        groups = np.asarray(groups)
        if groups.ndim != 1 or len(groups) != len(y):
            raise ValueError("bootstrap groups must align with targets")
        groups = validate_ids(groups, "Bootstrap group IDs", unique=False).to_numpy()
        inverse, _ = pd.factorize(groups, sort=False)
        order = np.argsort(inverse, kind="stable")
        blocks = np.split(order, np.flatnonzero(np.diff(inverse[order])) + 1)
    details = {
        "requested": n_boot, "attempted": 0, "valid": 0, "single_class": 0,
        "n_units": len(blocks) if blocks is not None else len(y),
        "status": "disabled" if n_boot == 0 else "ok",
        "ci": (float("nan"), float("nan")),
    }
    if blocks is not None and len(blocks) < 2 and n_boot:
        details["status"] = "insufficient_groups"
    if n_boot == 0 or details["status"] == "insufficient_groups":
        return details if return_details else details["ci"]
    rng = np.random.default_rng(seed)
    n, vals = len(y), []
    for _ in range(n_boot):
        if blocks is None:
            idx = rng.integers(0, n, n)
        else:
            chosen = rng.integers(0, len(blocks), len(blocks))
            idx = np.concatenate([blocks[i] for i in chosen])
        details["attempted"] += 1
        yi = y[idx]
        if yi.min() == yi.max():
            details["single_class"] += 1
            continue
        value = float(np.mean([metric_fn(yi, scores[idx, j]) for j in range(scores.shape[1])]))
        if not np.isfinite(value):
            raise ValueError("Bootstrap metric returned a non-finite value for a two-class resample")
        vals.append(value)
    details["valid"] = len(vals)
    # One retained draw cannot estimate sampling dispersion.
    if len(vals) >= 2:
        details["ci"] = (float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5)))
    else:
        details["status"] = "insufficient_valid_resamples"
    return details if return_details else details["ci"]


def _fmt_ci(lo, hi):
    return "-" if np.isnan(lo) else f"[{lo:.4f},{hi:.4f}]"


def _validate_predictions(df, id_col, target_col, score_col, group_col=None):
    """Reject ambiguous rows before aligning seed runs and model cohorts."""
    required = [id_col, target_col, score_col] + ([group_col] if group_col else [])
    missing = set(required) - set(df.columns)
    if missing:
        raise ValueError(f"Missing prediction columns: {sorted(missing)}")
    if df.empty:
        raise ValueError("Prediction cohort is empty")
    df = df.copy()
    df[id_col] = validate_ids(df[id_col], "Transaction IDs")
    if not df[target_col].isin([0, 1]).all():
        raise ValueError("Targets must be binary 0/1 without missing values")
    if not np.isfinite(df[score_col].to_numpy(float)).all():
        raise ValueError("Scores must be finite")
    if group_col:
        df[group_col] = validate_ids(df[group_col], "Bootstrap group IDs", unique=False)
    return df.sort_values(id_col, kind="stable").reset_index(drop=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", action="append", required=True,
                        help="name=path[,path2,...] (comma-separated paths = seed runs)")
    parser.add_argument("--target", default="frd_tag")
    parser.add_argument("--score-col", default="score")
    parser.add_argument("--id", default="fi_transaction_id", help="unique transaction ID for cohort alignment")
    parser.add_argument("--group", default=None, help="account ID column for block bootstrap; default: transaction resampling")
    parser.add_argument("--budget", type=float, default=0.001)
    parser.add_argument("--bootstrap", type=int, default=500, help="resamples for 95%% CI (0 = off)")
    parser.add_argument("--cred", default="/home/jovyan/your_id/tabular_fraud/test.yaml")
    parser.add_argument("--out", default="leaderboard.csv")
    add_path_argument(parser)
    args = parser.parse_args()
    if not np.isfinite(args.budget) or not 0 < args.budget <= 1:
        parser.error("--budget must be a finite fraction in (0, 1]")
    if args.bootstrap < 0:
        parser.error("--bootstrap must be non-negative")

    model_specs = []
    names = set()
    for spec in args.model:
        if "=" not in spec:
            parser.error("--model must be name=path[,path2,...]")
        name, paths = spec.split("=", 1)
        seed_paths = paths.split(",")
        if not name or name in names or not all(seed_paths):
            parser.error("model names must be nonempty and unique, with at least one nonempty seed path")
        names.add(name)
        model_specs.append((name, [prediction_path(p, args.legacy_s3_paths) for p in seed_paths]))
    fs = make_s3_filesystem(args.cred) if any(
        p.startswith("s3://") for _, paths in model_specs for p in paths
    ) else None
    rows = []
    reference = None
    cohort_cols = list(dict.fromkeys([args.id, args.target] + ([args.group] if args.group else [])))
    for name, seed_paths in model_specs:
        aps, aucs, precs = [], [], []
        seed_scores = []
        for p in seed_paths:
            df = _validate_predictions(_read(p, fs), args.id, args.target, args.score_col, args.group)
            if reference is None:
                reference = df[cohort_cols].copy()
            elif len(df) != len(reference) or any(
                not np.array_equal(df[c].to_numpy(), reference[c].to_numpy()) for c in cohort_cols
            ):
                raise ValueError("Every model and seed must have identical transaction IDs, labels and bootstrap groups")
            y = df[args.target].to_numpy(int)
            s = df[args.score_col].to_numpy(float)
            if np.unique(y).size != 2:
                raise ValueError("Leaderboard ranking intervals require both target classes")
            aps.append(average_precision_score(y, s))
            aucs.append(roc_auc_score(y, s))
            precs.append(_precision_at(y, s, args.budget))
            seed_scores.append(s)

        scores = np.column_stack(seed_scores)
        groups = reference[args.group].to_numpy() if args.group else None
        ap_boot = _bootstrap_ci(y, scores, average_precision_score, args.bootstrap,
                                groups=groups, return_details=True)
        au_boot = _bootstrap_ci(y, scores, roc_auc_score, args.bootstrap,
                                groups=groups, return_details=True)
        ap_lo, ap_hi = ap_boot["ci"]
        au_lo, au_hi = au_boot["ci"]
        rows.append({
            "model": name,
            "n_seeds": len(seed_paths),
            "n": len(y),
            "positives": int(y.sum()),
            "bootstrap_unit": f"group:{args.group}" if args.group else "transaction",
            "ci_estimand": "mean_metric_across_fixed_seed_models",
            "ci_conditioning": "resamples_with_both_target_classes",
            "bootstrap_units": ap_boot["n_units"],
            "bootstrap_requested": ap_boot["requested"],
            "bootstrap_attempted": ap_boot["attempted"],
            "bootstrap_valid": ap_boot["valid"],
            "bootstrap_single_class": ap_boot["single_class"],
            "bootstrap_status": ap_boot["status"],
            "budget_tie_policy": "expected_uniform_selection_within_cutoff_tie",
            "seed_std_scope": "descriptive_population_std_across_supplied_seeds",
            "pr_auc": float(np.mean(aps)),
            "pr_auc_std": float(np.std(aps)) if len(aps) > 1 else 0.0,
            "pr_auc_ci95": _fmt_ci(ap_lo, ap_hi),
            "roc_auc": float(np.mean(aucs)),
            "roc_auc_std": float(np.std(aucs)) if len(aucs) > 1 else 0.0,
            "roc_auc_ci95": _fmt_ci(au_lo, au_hi),
            f"precision@{args.budget:.3%}": float(np.mean(precs)),
        })

    rows.sort(key=lambda r: r["pr_auc"], reverse=True)

    print("\n=== Benchmark leaderboard (ranked by PR-AUC) ===")
    print("CI: evaluation-sampling uncertainty in the mean metric across fixed seed models; "
          "seed standard deviation is reported separately.")
    print("Intervals condition on resamples containing both classes; retained and omitted draws "
          "are recorded in the CSV. Separate model intervals do not test their difference.")
    print("Budget precision is expected precision under uniform selection within cutoff ties.")
    print(f"Bootstrap unit: {rows[0]['bootstrap_unit']}. "
          "Use --group with the account ID for account-correlated transactions.")
    cols = ["model", "pr_auc", "pr_auc_ci95", "roc_auc", "roc_auc_ci95",
            f"precision@{args.budget:.3%}", "n_seeds", "positives"]
    print("  ".join(f"{c:<20}" if c == "model" else f"{c:>18}" for c in cols))
    for r in rows:
        print("  ".join(f"{r[c]!s:<20}" if c == "model" else f"{r[c]!s:>18}" for c in cols))

    with open(args.out, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    log.info("Wrote leaderboard -> %s", args.out)


if __name__ == "__main__":
    main()
