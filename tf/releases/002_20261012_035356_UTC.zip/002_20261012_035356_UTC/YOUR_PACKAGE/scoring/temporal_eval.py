"""Descriptive calendar-period metrics for an existing prediction cohort.

Reads predictions (id, target, score), requires one raw timestamp per prediction
ID, and reports every month/week/day between the cohort's first and last periods.
Raw files may contain extra IDs; requested predictions are never silently dropped.
Empty and single-class periods retain counts, with discrimination metrics left
undefined by this reporting policy. Buckets use the supplied consistent calendar
timezone (or naive timestamps); numeric units and mixed timezones are not guessed.

Regrouping predictions does not create a temporal holdout or establish drift.
Actual held-out validation additionally needs training/split provenance and cutoffs.

The legacy pr_auc / PR-AUC label denotes sklearn average precision (AP), not
trapezoidal integration of a precision-recall curve.

Usage:
    python YOUR_PACKAGE/scoring/temporal_eval.py \
        --pred s3://.../predictions/sequential \
        --raw-base s3://.../tfm_EVAL_raw_data --file-start 8000 --file-end 8010 \
        --period month --out temporal_metrics.csv
"""

import argparse
import csv
import os
import sys
from numbers import Number

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from fraud.data.s3_utils import build_file_list, make_s3_filesystem
from fraud.log_utils import setup_logging
from YOUR_PACKAGE.scoring._prediction_utils import (
    add_path_argument,
    prediction_path,
    read_predictions,
    validate_ids,
)

log = setup_logging()


def _read(path, fs, columns=None):
    return read_predictions(path, fs, columns=columns)


def _prepare_predictions(preds, times, id_col, target_col, score_col, order_col):
    """Require full prediction coverage and a one-to-one ID/timestamp join."""
    original_ids = preds[id_col].to_numpy() if id_col in preds else None
    preds, times = preds.copy(), times.copy()
    for name, frame, columns in [
        ("predictions", preds, [id_col, target_col, score_col]),
        ("raw timestamps", times, [id_col, order_col]),
    ]:
        missing = set(columns) - set(frame.columns)
        if missing:
            raise ValueError(f"{name}: missing columns {sorted(missing)}")
        frame[id_col] = validate_ids(frame[id_col], f"{name}: IDs")
    if preds.empty:
        raise ValueError("Prediction cohort is empty; its calendar range is undefined")
    if not preds[target_col].isin([0, 1]).all():
        raise ValueError("Prediction targets must be non-null binary values")
    try:
        scores = preds[score_col].to_numpy(float)
    except (TypeError, ValueError) as exc:
        raise ValueError("Prediction scores must be finite numeric values") from exc
    if not np.isfinite(scores).all():
        raise ValueError("Prediction scores must be finite numeric values")

    df = preds[[id_col, target_col, score_col]].merge(
        times[[id_col, order_col]], on=id_col, how="left", sort=False,
        validate="one_to_one", indicator="_timestamp_match",
    )
    unmatched = int(df["_timestamp_match"].ne("both").sum())
    if unmatched:
        raise ValueError(f"Raw files lack timestamps for {unmatched} prediction IDs")
    numeric_time = pd.api.types.is_numeric_dtype(df[order_col].dtype)
    if pd.api.types.is_object_dtype(df[order_col].dtype):
        # Concatenated files can mix Timestamp and numeric scalars in an object
        # column; pandas would otherwise silently interpret those numbers as ns.
        numeric_time = numeric_time or df[order_col].map(lambda value: isinstance(value, Number)).any()
    if numeric_time:
        raise ValueError("Numeric timestamps require an explicit unit conversion before reporting")
    try:
        timestamps = pd.to_datetime(df[order_col], errors="coerce")
    except (TypeError, ValueError) as exc:
        raise ValueError("Timestamps must be parseable with one consistent timezone or all naive") from exc
    invalid = int(timestamps.isna().sum())
    if invalid:
        raise ValueError(f"Invalid or missing timestamps for {invalid} requested predictions")
    if not pd.api.types.is_datetime64_any_dtype(timestamps.dtype):
        raise ValueError("Timestamps must use one consistent timezone or all be naive")
    if timestamps.dt.tz is not None:
        # Preserve the supplied local calendar; do not silently convert it to UTC.
        timestamps = timestamps.dt.tz_localize(None)
    df[order_col] = timestamps
    df[id_col] = original_ids
    return df.drop(columns="_timestamp_match")


def _period_metrics(df, period, order_col, target_col, score_col):
    """Retain all calendar periods spanned by the requested prediction timestamps."""
    freq = {"month": "M", "week": "W", "day": "D"}[period]
    buckets = df[order_col].dt.to_period(freq)
    grouped = df.groupby(buckets, sort=True)
    rows = []
    for bucket in pd.period_range(buckets.min(), buckets.max(), freq=freq):
        g = grouped.get_group(bucket) if bucket in grouped.groups else df.iloc[:0]
        y = g[target_col].to_numpy(int)
        n, positives = len(y), int(y.sum())
        status = "empty" if n == 0 else "single_class" if positives in (0, n) else "ok"
        row = {
            "bucket": str(bucket), "n": n, "positives": positives,
            "fraud_rate": float(positives / n) if n else None,
            "pr_auc": None, "roc_auc": None, "status": status,
        }
        if status == "ok":
            s = g[score_col].to_numpy(float)
            row["pr_auc"] = float(average_precision_score(y, s))
            row["roc_auc"] = float(roc_auc_score(y, s))
        rows.append(row)
    return rows


def _trend(rows, metric):
    """Fit defined metrics against actual calendar-period offsets, including gaps."""
    points = [(i, row[metric]) for i, row in enumerate(rows) if row[metric] is not None]
    if len(points) < 2:
        return None
    x, y = np.asarray(points, dtype=float).T
    return {
        "first_bucket": rows[int(x[0])]["bucket"],
        "last_bucket": rows[int(x[-1])]["bucket"],
        "first": float(y[0]), "last": float(y[-1]),
        "delta": float(y[-1] - y[0]),
        "slope": float(np.polyfit(x, y, 1)[0]),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pred", required=True, help="predictions parquet (file or dir)")
    parser.add_argument("--raw-base", required=True, help="raw parquet base for timestamps")
    parser.add_argument("--file-start", type=int, required=True)
    parser.add_argument("--file-end", type=int, required=True)
    parser.add_argument("--order-col", default="transaction_dttm")
    parser.add_argument("--id", default="fi_transaction_id")
    parser.add_argument("--target", default="frd_tag")
    parser.add_argument("--score-col", default="score")
    parser.add_argument("--period", choices=["month", "week", "day"], default="month")
    parser.add_argument("--cred", default="/home/jovyan/your_id/tabular_fraud/test.yaml")
    parser.add_argument("--out", default="temporal_metrics.csv")
    add_path_argument(parser)
    args = parser.parse_args()
    if args.file_end < args.file_start:
        parser.error("file-end must be at least file-start")

    args.pred = prediction_path(args.pred, args.legacy_s3_paths)
    args.raw_base = prediction_path(args.raw_base, args.legacy_s3_paths)
    fs = make_s3_filesystem(args.cred) if any(
        p.startswith("s3://") for p in (args.pred, args.raw_base)
    ) else None
    preds = _read(args.pred, fs)[[args.id, args.target, args.score_col]]

    # Timestamps by id from the raw files (only id + order_col to stay light).
    files = build_file_list(args.raw_base, args.file_start, args.file_end)
    times = []
    for path in files:
        times.append(_read(path, fs, columns=[args.id, args.order_col]))
    times = pd.concat(times, ignore_index=True)

    df = _prepare_predictions(preds, times, args.id, args.target, args.score_col, args.order_col)
    rows = _period_metrics(df, args.period, args.order_col, args.target, args.score_col)
    log.info("Prediction coverage: %d/%d; raw rows supplied: %d", len(df), len(preds), len(times))

    print(f"\n=== Descriptive prediction metrics by {args.period} ===")
    print("This report groups supplied predictions; held-out validation requires training/split provenance.")
    hdr = ["bucket", "n", "positives", "fraud_rate", "pr_auc", "roc_auc", "status"]
    print("  ".join(f"{h:>12}" if h != "bucket" else f"{h:<10}" for h in hdr))
    for r in rows:
        cells = {h: "undefined" if r[h] is None else str(r[h]) for h in hdr}
        print("  ".join(f"{cells[h]:>12}" if h != "bucket" else f"{cells[h]:<10}" for h in hdr))

    print("\n--- Descriptive calendar-period trends ---")
    print(f"buckets:        {len(rows)}")
    for metric, label in [("pr_auc", "PR-AUC"), ("roc_auc", "ROC-AUC")]:
        trend = _trend(rows, metric)
        if trend is None:
            print(f"{label} trend: undefined (fewer than two periods with both classes)")
        else:
            print(f"{label} {trend['first_bucket']} → {trend['last_bucket']}: "
                  f"{trend['first']:.4f} → {trend['last']:.4f} "
                  f"(Δ={trend['delta']:+.4f}, slope/calendar-period={trend['slope']:+.5f})")

    with open(args.out, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=hdr)
        writer.writeheader()
        writer.writerows(rows)
    log.info("Wrote temporal metrics -> %s", args.out)


if __name__ == "__main__":
    main()
