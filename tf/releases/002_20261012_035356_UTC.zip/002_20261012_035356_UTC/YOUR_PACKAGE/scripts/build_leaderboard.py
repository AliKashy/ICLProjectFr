"""Aggregate every ablation results.csv under ablations/ into one ranked leaderboard.

Walks ablations/ recursively, reads each results.csv it finds, tags each row with
the architecture + test it came from (parsed from the folder path), and writes one
combined, ranked CSV plus a console summary. Ranks by eval_ap when a run has it
(run_score: true configs); falls back to best_valid_ap for smoke-stage configs
(run_score: false) that never scored on the eval set -- the rank_metric column
always says which one was used, so the two are never silently conflated.

The two metrics come from different files, so they are ranked separately: the rank
column restarts at 1 for each rank_metric (eval_ap first). Only successful runs are
ranked: a row whose status is not "ok" (runners that write attempt folders), or whose
train_rc is not 0 (older runners), is listed after the ranked rows with an empty rank.
With attempt folders (<output_root>/<attempt>/results.csv), the configured results.csv
is a copy of the latest attempt and previous_results.csv a copy of what it replaced;
each run is counted once, by its folder, attempt and run name. A rank compares runs
fairly only when their train/validation/evaluation file ranges match (see the configs).

Usage:
    python YOUR_PACKAGE/scripts/build_leaderboard.py
    python YOUR_PACKAGE/scripts/build_leaderboard.py --ablations-root ablations --out ablations/leaderboard.csv
"""

import argparse
import csv
import os

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

# Columns every run_ablations.py results.csv always has, regardless of axes swept.
_FIXED_COLS = ["run_name", "train_rc", "best_valid_ap", "best_valid_auroc", "eval_ap", "eval_auroc"]
# Bookkeeping columns of runners that write attempt folders; they are not axes.
_RUNNER_COLS = ["attempt", "run_dir", "score_rc", "status", "predictions_path", "n_predictions", "n_positives",
                "checkpoint_epoch", "checkpoint_step", "checkpoint_monitor", "checkpoint_monitor_score",
                "checkpoint_sha256", "resolved_train_sha256", "source_sha256", "manifest_path", "error"]
_METRIC_ORDER = {"eval_ap": 0, "best_valid_ap": 1}


def _find_results_csvs(ablations_root):
    """Every results.csv and previous_results.csv, most authoritative first: an attempt's own results.csv
    (written once per attempt), then a test folder's results.csv (a latest view, or an older runner's only
    copy), then previous_results.csv (a copy of what a latest view replaced)."""
    found = []
    for dirpath, dirnames, filenames in os.walk(ablations_root):
        dirnames[:] = [d for d in dirnames if d != ".ipynb_checkpoints"]
        for name in ("results.csv", "previous_results.csv"):
            if name in filenames:
                found.append(os.path.join(dirpath, name))

    def priority(path):
        if os.path.basename(path) == "previous_results.csv":
            return 2
        return 0 if os.path.isfile(os.path.join(os.path.dirname(path), "ablation_spec.yaml")) else 1
    return sorted(found, key=lambda p: (priority(p), p))


def _test_folder(results_csv):
    """The folder a config's output_root names: the parent of an attempt folder (one holding ablation_spec.yaml),
    otherwise the CSV's own folder."""
    folder = os.path.dirname(results_csv)
    if os.path.isfile(os.path.join(folder, "ablation_spec.yaml")):
        return os.path.dirname(folder)
    return folder


def _tag_from_path(results_csv, ablations_root):
    """ablations/<architecture>/<test>/results.csv -> (architecture, test)."""
    rel = os.path.relpath(results_csv, ablations_root)
    parts = rel.split(os.sep)
    if len(parts) >= 3:
        return parts[0], parts[1]
    if len(parts) == 2:
        return parts[0], "-"
    return "-", "-"


def _to_float(val):
    try:
        return float(val)
    except (TypeError, ValueError):
        return None


def _eligible(row):
    """A run may be ranked only if it succeeded: status ok, or train_rc 0 for runners without a status."""
    status = (row.get("status") or "").strip()
    if status:
        return status == "ok"
    return str(row.get("train_rc", "")).strip() == "0"


def load_all_rows(ablations_root):
    rows = []
    axis_cols_seen = []
    seen = {}
    for results_csv in _find_results_csvs(ablations_root):
        test_folder = _test_folder(results_csv)
        architecture, test = _tag_from_path(os.path.join(test_folder, "results.csv"), ablations_root)
        with open(results_csv, newline="") as f:
            reader = csv.DictReader(f)
            axis_cols = [c for c in (reader.fieldnames or []) if c not in _FIXED_COLS + _RUNNER_COLS]
            for c in axis_cols:
                if c not in axis_cols_seen:
                    axis_cols_seen.append(c)
            for row in reader:
                key = (test_folder, row.get("attempt") or "", row.get("run_name"))
                if key in seen:  # the same run seen through a latest view or a previous_results.csv copy
                    kept = seen[key]
                    if any(_to_float(row.get(c)) != kept[c] for c in _FIXED_COLS[2:]):
                        print(f"WARNING: {row.get('run_name')} in {architecture}/{test} has different numbers in "
                              f"{os.path.relpath(results_csv, ROOT)}; kept {kept['source_csv']}")
                    continue
                eval_ap = _to_float(row.get("eval_ap"))
                valid_ap = _to_float(row.get("best_valid_ap"))
                if eval_ap is not None:
                    rank_metric, rank_value = "eval_ap", eval_ap
                else:
                    rank_metric, rank_value = "best_valid_ap", valid_ap
                entry = {
                    "architecture": architecture,
                    "test": test,
                    "source_csv": os.path.relpath(results_csv, ROOT),
                    "run_name": row.get("run_name"),
                    **{c: row.get(c, "") for c in axis_cols},
                    "train_rc": row.get("train_rc"),
                    "best_valid_ap": valid_ap,
                    "best_valid_auroc": _to_float(row.get("best_valid_auroc")),
                    "eval_ap": eval_ap,
                    "eval_auroc": _to_float(row.get("eval_auroc")),
                    "rank_metric": rank_metric,
                    "rank": None,
                    "rank_value": rank_value,
                    "attempt": row.get("attempt", ""),
                    "status": row.get("status", ""),
                }
                seen[key] = entry
                rows.append(entry)
    return rows, axis_cols_seen


def write_leaderboard(rows, axis_cols_seen, out_path):
    ranked = sorted((r for r in rows if _eligible(r) and r["rank_value"] is not None),
                    key=lambda r: (_METRIC_ORDER[r["rank_metric"]], -r["rank_value"]))
    for metric in _METRIC_ORDER:
        for position, r in enumerate((r for r in ranked if r["rank_metric"] == metric), 1):
            r["rank"] = position
    unranked = [r for r in rows if r["rank"] is None]
    fieldnames = (["architecture", "test", "source_csv", "run_name"] + axis_cols_seen +
                  ["train_rc", "best_valid_ap", "best_valid_auroc", "eval_ap", "eval_auroc",
                   "rank_metric", "rank", "rank_value", "attempt", "status"])
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    with open(out_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(ranked + unranked)
    return ranked, unranked


def print_summary(ranked, unranked):
    print(f"\n=== Combined ablation leaderboard ({len(ranked)} ranked runs, {len(unranked)} not ranked) ===")
    header = f"{'rank':>4} {'architecture':<14} {'test':<28} {'run_name':<34} {'rank_metric':<13} {'rank_value':>10}"
    for metric, title in (("eval_ap", "ranked by eval_ap (evaluation files)"),
                          ("best_valid_ap", "ranked by best_valid_ap (validation files; not comparable with eval_ap)")):
        group = [r for r in ranked if r["rank_metric"] == metric]
        if not group:
            continue
        print(f"\n--- {title} ---")
        print(header)
        print("-" * len(header))
        for r in group:
            print(f"{r['rank']:>4} {r['architecture']:<14} {r['test']:<28} {r['run_name']:<34} "
                  f"{r['rank_metric']:<13} {r['rank_value']:>10.4f}")
    if unranked:
        print("\n--- not ranked (failed, incomplete or no metric) ---")
        for r in unranked:
            print(f"     {r['architecture']:<14} {r['test']:<28} {r['run_name']:<34} "
                  f"status={r['status'] or '-'} train_rc={r['train_rc']}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ablations-root", default=os.path.join(ROOT, "ablations"))
    parser.add_argument("--out", default=os.path.join(ROOT, "ablations", "leaderboard.csv"))
    args = parser.parse_args()

    rows, axis_cols_seen = load_all_rows(args.ablations_root)
    if not rows:
        print(f"No results.csv files found under {args.ablations_root}")
        return
    ranked, unranked = write_leaderboard(rows, axis_cols_seen, args.out)
    print_summary(ranked, unranked)
    print(f"\nWrote {len(ranked) + len(unranked)} rows -> {os.path.relpath(args.out, ROOT)}")


if __name__ == "__main__":
    main()
