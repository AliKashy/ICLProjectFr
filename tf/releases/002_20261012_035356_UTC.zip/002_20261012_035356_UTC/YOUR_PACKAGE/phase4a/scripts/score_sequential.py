"""Scoring script for the sequential model (flat or hierarchical).

Factory-driven variant of reference's score_sequential (his stays untouched).

Usage:
    python YOUR_PACKAGE/phase4a/scripts/score_sequential.py \
        --config YOUR_PACKAGE/phase4a/configs/sequential.yaml
"""

import argparse
import hashlib
import json
import os
import sys
import uuid

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import torch
from omegaconf import OmegaConf
from sklearn.metrics import average_precision_score, roc_auc_score
from torch.utils.data import DataLoader

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", ".."))

from fraud.data.datetime_features import DatetimeConfig
from fraud.data.feature_list import load_feature_list
from fraud.data.preprocessing import PreprocessingArtifacts
from fraud.data.s3_utils import build_file_list, make_s3_filesystem, strip_scheme
from YOUR_PACKAGE.phase4a.sequence_builder import SequenceBuilder
from fraud.log_utils import setup_logging
from YOUR_PACKAGE.phase4a.factory import build_sequential_model

log = setup_logging()


def _prediction_path(cfg):
    """A fresh object for each score invocation, including manual reruns."""
    experiment = cfg.get("experiment") or {}
    run_name = experiment.get("run_name") or "sequential"
    name = f"{run_name}__{uuid.uuid4().hex}_preds.parquet"
    return strip_scheme(f"{cfg.eval.predictions_base.rstrip('/')}/{name}")


def _sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _write_metrics(path, payload):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    temp = f"{path}.{uuid.uuid4().hex}.tmp"
    try:
        with open(temp, "x", encoding="utf-8") as stream:
            json.dump(payload, stream, indent=2, sort_keys=True, allow_nan=False)
            stream.write("\n")
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("overrides", nargs="*")
    args = parser.parse_args()

    cfg = OmegaConf.load(args.config)
    if args.overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(args.overrides))

    fs = make_s3_filesystem(cfg.s3.cred_path)
    features = load_feature_list(cfg.predictors.csv_path, version=cfg.predictors.version, filesystem=fs)
    artifacts_path = f"{cfg.artifacts.base.rstrip('/')}/{cfg.artifacts.version}"
    artifacts = PreprocessingArtifacts.load(artifacts_path, filesystem=fs)
    dt_config = DatetimeConfig(order_col=cfg.data.order_col, fields=list(cfg.datetime.fields),
                               encoding=cfg.datetime.encoding, is_weekend=cfg.datetime.is_weekend)

    target_col = cfg.data.target_col
    id_cols = list(cfg.data.get("id_cols", []))
    amount_col = cfg.data.get("amount_col", None)

    eval_files = build_file_list(cfg.eval.base, cfg.eval.file_start, cfg.eval.file_end)
    dataset = SequenceBuilder(
        file_list=eval_files, artifacts=artifacts, features=features, datetime_config=dt_config,
        target_col=target_col, account_col=cfg.data.account_col, order_col=cfg.data.order_col,
        history_len=int(cfg.sequence.history_len), stride=int(cfg.sequence.get("eval_stride", 1)),
        positive_label=cfg.data.get("positive_label", 1), add_missing_flag=cfg.preprocess.add_missing_flag,
        time_delta=bool(cfg.sequence.get("time_delta", True)), batch_size=int(cfg.training.batch_size),
        shuffle=False, tie_break_col=cfg.data.get("tie_break_col", None),
        id_cols=id_cols, amount_col=amount_col, s3_cred_path=cfg.s3.cred_path,
    )
    loader = DataLoader(dataset, batch_size=None, num_workers=int(cfg.training.get("num_workers", 0)))

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = build_sequential_model(cfg, dataset)
    checkpoint_sha256 = _sha256(cfg.eval.checkpoint)
    ckpt = torch.load(cfg.eval.checkpoint, map_location=device, weights_only=False)
    model.on_load_checkpoint(ckpt)
    model.load_state_dict(ckpt["state_dict"])
    model.eval().to(device)
    log.info("Loaded checkpoint %s on %s", cfg.eval.checkpoint, device)

    scores, labels, meta_cols = [], [], {c: [] for c in id_cols}
    if amount_col:
        meta_cols[amount_col] = []
    for batch in loader:
        with torch.no_grad():
            logits = model({
                "continuous": batch["continuous"].to(device),
                "categorical": batch["categorical"].to(device),
                "mask": batch["mask"].to(device),
            })
            if logits.ndim != 2 or logits.shape[1] != 2:
                raise ValueError(f"Single-target scorer requires [batch, 2] logits, got {tuple(logits.shape)}")
            prob = torch.softmax(logits, dim=-1)[:, 1].cpu().numpy()
        scores.append(prob)
        labels.append(batch["target"].numpy().reshape(-1))
        for c in meta_cols:
            meta_cols[c].append(batch["meta"][c])

    if not scores:
        raise ValueError("Evaluation produced no target transactions; check the file range and data")
    score = np.concatenate(scores)
    y_true = np.concatenate(labels)
    out = {c: np.concatenate(v) for c, v in meta_cols.items()}
    if len(score) != len(y_true) or any(len(v) != len(score) for v in out.values()):
        raise ValueError("Evaluation scores, targets and transaction metadata are not aligned")
    if not np.isfinite(score).all() or np.any((score < 0) | (score > 1)):
        raise ValueError("Evaluation scores must be finite probabilities in [0, 1]")
    if not np.isin(y_true, [0, 1]).all():
        raise ValueError("Evaluation targets must be binary labels 0 or 1")
    if id_cols:
        ids = pd.DataFrame({key: out[key] for key in id_cols})
        if ids.isna().any().any() or ids.duplicated().any():
            raise ValueError("Prediction IDs must be non-null and unique across the evaluation cohort")
    compute_metrics = bool(cfg.eval.get("compute_metrics", False))
    if compute_metrics and len(np.unique(y_true)) != 2:
        raise ValueError("Evaluation AP/AUROC reporting requires both target classes")
    ap = float(average_precision_score(y_true, score)) if compute_metrics else None
    auroc = float(roc_auc_score(y_true, score)) if compute_metrics else None
    if _sha256(cfg.eval.checkpoint) != checkpoint_sha256:
        raise ValueError("Checkpoint changed during scoring; rerun against an immutable checkpoint")
    out[target_col] = y_true
    out["score"] = score

    out_path = _prediction_path(cfg)
    pq.write_table(pa.table(out), out_path, filesystem=fs)
    log.info("Wrote %d predictions -> %s (positives=%d)", len(score), out_path, int(y_true.sum()))

    if compute_metrics:
        log.info("Range metrics: average_precision=%.12g  auroc=%.12g  (n=%d, positives=%d)",
                 ap, auroc, len(y_true), int(y_true.sum()))
    if cfg.eval.get("metrics_output"):
        _write_metrics(str(cfg.eval.metrics_output), {
            "schema_version": 1, "predictions_path": out_path,
            "checkpoint_path": os.path.abspath(cfg.eval.checkpoint),
            "checkpoint_sha256": checkpoint_sha256,
            "n_predictions": int(len(score)), "n_positives": int(y_true.sum()),
            "average_precision": ap, "auroc": auroc,
            "sequence_contract": model.sequence_contract,
            "checkpoint_contract_verified": ckpt.get("sequence_contract") is not None,
        })


if __name__ == "__main__":
    main()
