"""Training script for the sequential model (flat or hierarchical).

Factory-driven variant of reference's train_sequential (his stays untouched): selects
Architecture A/B via ``model.type`` and supports periodic embeddings, optimizer
selection, and optional weight-EMA. Reuses his streaming base from ``fraud.data``.

Usage:
    python YOUR_PACKAGE/phase4b/scripts/train_sequential.py \
        --config YOUR_PACKAGE/phase4b/configs/sequential_hier.yaml
"""

import argparse
import os
import sys

import pytorch_lightning as pl
import torch
from omegaconf import OmegaConf
from pytorch_lightning.callbacks import EarlyStopping, ModelCheckpoint
from torch.utils.data import DataLoader

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", ".."))

from fraud.callbacks import CSVMetricsCallback, StreamingBinaryMetrics
from fraud.data.datetime_features import DatetimeConfig
from fraud.data.feature_list import load_feature_list
from fraud.data.preprocessing import PreprocessingArtifacts
from fraud.data.s3_utils import build_file_list, make_s3_filesystem
from YOUR_PACKAGE.phase4b.sequence_builder import SequenceBuilder  # phase-owned fix for the worker file-sharding bug (see YOUR_PACKAGE/phase4b/sequence_builder.py docstring)
from fraud.log_utils import setup_logging
from YOUR_PACKAGE.phase4b.callbacks import EMACallback
from YOUR_PACKAGE.phase4b.factory import build_sequential_model, sequence_dataset_options

log = setup_logging()


def _make_loader(cfg, files, artifacts, features, dt_config, shuffle, stride, num_workers):
    dataset = SequenceBuilder(
        file_list=files, artifacts=artifacts, features=features, datetime_config=dt_config,
        target_col=cfg.data.target_col, account_col=cfg.data.account_col,
        order_col=cfg.data.order_col, history_len=int(cfg.sequence.history_len),
        stride=int(stride), positive_label=cfg.data.get("positive_label", 1),
        add_missing_flag=cfg.preprocess.add_missing_flag,
        time_delta=bool(cfg.sequence.get("time_delta", True)),
        batch_size=int(cfg.training.batch_size), shuffle=shuffle,
        buffer_windows=int(cfg.training.get("buffer_windows", 65536)),
        tie_break_col=cfg.data.get("tie_break_col", None), s3_cred_path=cfg.s3.cred_path,
        **sequence_dataset_options(cfg),
    )
    return DataLoader(dataset, batch_size=None, num_workers=num_workers)


def main():
    if int(os.environ.get("WORLD_SIZE", "1")) > 1:
        raise RuntimeError("Phase 4B supports one device only; distributed training needs rank-aware sharding and metric gathering")
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("overrides", nargs="*")
    args = parser.parse_args()

    cfg = OmegaConf.load(args.config)
    if args.overrides:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_dotlist(args.overrides))
    sequence_dataset_options(cfg)  # Validate prediction ownership before any data access.
    if cfg.training.get("seed") is not None:
        pl.seed_everything(cfg.training.seed, workers=True)

    fs = make_s3_filesystem(cfg.s3.cred_path)
    features = load_feature_list(cfg.predictors.csv_path, version=cfg.predictors.version, filesystem=fs)
    artifacts_path = f"{cfg.artifacts.base.rstrip('/')}/{cfg.artifacts.version}"
    artifacts = PreprocessingArtifacts.load(artifacts_path, filesystem=fs)
    dt_config = DatetimeConfig(order_col=cfg.data.order_col, fields=list(cfg.datetime.fields),
                               encoding=cfg.datetime.encoding, is_weekend=cfg.datetime.is_weekend)

    train_files = build_file_list(cfg.data.train_base, cfg.data.train_start, cfg.data.train_end)
    val_files = build_file_list(cfg.data.val_base, cfg.data.val_start, cfg.data.val_end)
    num_workers = int(cfg.training.get("num_workers", 0))
    train_loader = _make_loader(cfg, train_files, artifacts, features, dt_config,
                                True, cfg.sequence.get("train_stride", 1), num_workers)
    val_loader = _make_loader(cfg, val_files, artifacts, features, dt_config,
                              False, cfg.sequence.get("eval_stride", 1), num_workers)

    probe = train_loader.dataset
    log.info("Sequence: history_len=%d, T=%d, continuous=%d, categorical=%d",
             probe.history_len, probe.T, len(probe.continuous_cols), len(probe.categorical_cols))
    model = build_sequential_model(cfg, probe)
    log.info("Model: %s", cfg.model.get("type", "FTTransformerSeq"))

    save_path = cfg.output.checkpoint_dir
    os.makedirs(save_path, exist_ok=True)
    monitor, mode = cfg.training.monitor, cfg.training.monitor_mode
    callbacks = [
        StreamingBinaryMetrics(pos_index=1),
        CSVMetricsCallback(os.path.join(save_path, "training_metrics.csv")),
    ]
    if bool(cfg.training.get("ema", False)):
        callbacks.append(EMACallback(decay=float(cfg.training.get("ema_decay", 0.999))))
    callbacks += [
        EarlyStopping(monitor=monitor, mode=mode, patience=int(cfg.training.early_stopping_patience)),
        ModelCheckpoint(dirpath=save_path, filename="best", monitor=monitor, mode=mode,
                        save_last=True, enable_version_counter=False),
    ]

    trainer = pl.Trainer(
        max_epochs=int(cfg.training.max_epochs), accelerator=cfg.training.accelerator,
        devices=1,
        precision=cfg.training.get("precision", "bf16-mixed"),
        accumulate_grad_batches=int(cfg.training.get("accumulate_grad_batches", 1)),
        callbacks=callbacks, logger=False,
        log_every_n_steps=int(cfg.training.get("log_every_n_steps", 50)),
        enable_progress_bar=True,
    )
    log.info("GPU available: %s", torch.cuda.is_available())
    trainer.fit(model, train_loader, val_loader)
    log.info("Training complete. Checkpoints in %s", save_path)


if __name__ == "__main__":
    main()
