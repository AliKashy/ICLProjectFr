"""Builds the hierarchical FT-Transformer (Architecture B) from config — phase4b-local.

Stage 1 encodes each transaction to a vector; stage 2 attends over the
transaction-vectors. Dimensions come from the dataset contract.
"""

from YOUR_PACKAGE.base.data.contracts import build_input_contract
from YOUR_PACKAGE.phase4b.sequential_hier import FTTransformerHierModel


def sequence_dataset_options(cfg):
    """Resolve the explicitly different single-target and causal chunk contracts."""
    if cfg.model.get("type", "FTTransformerHier") != "FTTransformerHier":
        raise ValueError("The Phase 4B entrypoint requires model.type='FTTransformerHier'")
    sequence = cfg.sequence
    every = bool(sequence.get("predict_every_transaction", False))
    layout = sequence.get("all_position_layout", None)
    reference = sequence.get("time_delta_reference", "target")
    if every:
        if sequence.get("attention_mask", "bidirectional") != "causal":
            raise ValueError("All-position prediction requires attention_mask='causal'")
        if layout != "nonoverlapping_chunks":
            raise ValueError("Set all_position_layout='nonoverlapping_chunks' explicitly; chunk context differs from sliding windows")
        if any(int(sequence.get(key, 1)) != 1 for key in ("train_stride", "eval_stride")):
            raise ValueError("All-position train_stride and eval_stride must both be 1")
        if bool(sequence.get("time_delta", True)) and reference != "previous_transaction":
            raise ValueError("All-position time_delta_reference must be 'previous_transaction'")
    elif layout is not None or (bool(sequence.get("time_delta", True)) and reference != "target"):
        raise ValueError("Single-target mode requires the original target-relative window contract")
    return dict(emit_target_seq=every, all_position_layout=layout, time_delta_reference=reference)


def build_sequential_model(cfg, dataset):
    options = sequence_dataset_options(cfg)
    if bool(getattr(dataset, "emit_target_seq", False)) != options["emit_target_seq"]:
        raise ValueError("Dataset target ownership does not match model prediction mode")
    # Model tensor shapes cannot distinguish permuted columns or refitted vocab/
    # scaling artifacts. Hash the actual in-memory artifacts used by this loader,
    # not merely an S3 prefix/version string.
    input_contract = build_input_contract(dataset)
    return FTTransformerHierModel(
        continuous_dim=len(dataset.continuous_cols),
        categorical_cardinality=dataset.categorical_cardinality,
        history_len=int(cfg.sequence.history_len),
        embed_dim=int(cfg.model.input_embed_dim),
        num_heads=int(cfg.model.num_heads),
        num_txn_blocks=int(cfg.model.get("num_txn_blocks", 2)),
        num_seq_blocks=int(cfg.model.get("num_seq_blocks", cfg.model.get("num_attn_blocks", 4))),
        attn_dropout=float(cfg.model.attn_dropout),
        ff_dropout=float(cfg.model.ff_dropout),
        attention_mask=cfg.sequence.get("attention_mask", "bidirectional"),
        learning_rate=float(cfg.training.get("learning_rate", 3e-4)),
        weight_decay=float(cfg.training.get("weight_decay", 1e-5)),
        pos_weight=float(cfg.training.get("pos_weight", 1.0)),
        continuous_embedding=cfg.model.get("continuous_embedding", "linear"),
        num_frequencies=int(cfg.model.get("num_frequencies", 16)),
        optimizer=cfg.training.get("optimizer", "adamw"),
        predict_every_transaction=bool(cfg.sequence.get("predict_every_transaction", False)),
        all_position_layout=options["all_position_layout"],
        time_delta_reference=options["time_delta_reference"] if bool(cfg.sequence.get("time_delta", True)) else "none",
        input_contract=input_contract,
    )
