"""Hierarchical (two-stage) sequential FT-Transformer — Phase 4 Architecture B.

Encodes **each transaction independently** with a shared token-level
FT-Transformer into one vector per transaction, then runs a small **sequence
transformer** over the N+1 transaction vectors (+ transaction-position) whose
CLS output predicts the target's fraud probability.

Cheaper attention than the flat SEP-token model: O((N+1)^2) over transaction
vectors instead of O(((N+1) * tokens_per_txn)^2) over all feature tokens — scales
to longer histories. Reuses the validated per-transaction tokenizer
(``TransactionEmbedding``) from the flat model as its stage-1 component.

Batch dict (from ``SequenceBuilder``) is identical to the flat model:
    continuous  [B, T, C] float   (C incl. time-delta)
    categorical [B, T, K] long
    mask        [B, T]    bool    (True = real transaction)
    target      [B, 1]    long

The optional all-position head instead requires the explicit disjoint-chunk
builder contract. It returns [B,T,2], consumes target_seq[B,T] only at real
slots and uses backward interarrival gaps. Context resets at chunk/file
boundaries and ranges from 0..H; it is not equivalent to H-history sliding
windows. See YOUR_PACKAGE/phase4b/ALL_POSITION_CONTRACT.md.
"""

from typing import List
import warnings

import pytorch_lightning as pl
import torch
import torch.nn as nn

from YOUR_PACKAGE.phase4b.tokenizer import FeatureTokenizer
from YOUR_PACKAGE.phase4b.optim import build_optimizer


def _encoder(embed_dim, num_heads, num_layers, ff_multiplier, attn_dropout, ff_dropout):
    layer = nn.TransformerEncoderLayer(
        d_model=embed_dim,
        nhead=num_heads,
        dim_feedforward=embed_dim * ff_multiplier,
        dropout=ff_dropout,
        activation="gelu",
        batch_first=True,
        norm_first=True,
    )
    layer.self_attn.dropout = attn_dropout
    return nn.TransformerEncoder(layer, num_layers=num_layers)


class FTTransformerHierModel(pl.LightningModule):
    def __init__(
        self,
        continuous_dim: int,
        categorical_cardinality: List[int],
        history_len: int,
        embed_dim: int = 48,
        num_heads: int = 8,
        num_txn_blocks: int = 2,
        num_seq_blocks: int = 4,
        ff_multiplier: int = 4,
        attn_dropout: float = 0.1,
        ff_dropout: float = 0.1,
        attention_mask: str = "bidirectional",
        learning_rate: float = 3e-4,
        weight_decay: float = 1e-5,
        pos_weight: float = 1.0,
        continuous_embedding: str = "linear",
        num_frequencies: int = 16,
        optimizer: str = "adamw",
        predict_every_transaction: bool = False,
        all_position_layout: str = None,
        time_delta_reference: str = "target",
        input_contract: dict = None,
    ):
        super().__init__()
        if attention_mask not in ("bidirectional", "causal"):
            raise ValueError("attention_mask must be 'bidirectional' or 'causal'")
        if predict_every_transaction and attention_mask != "causal":
            # Bidirectional would let every transaction-vector see the future
            # (including the target), so "this transaction's own prediction"
            # would be leaking -- causal is a hard requirement for this mode.
            raise ValueError(
                "predict_every_transaction=True requires attention_mask='causal'"
            )
        if predict_every_transaction and (
            all_position_layout != "nonoverlapping_chunks"
            or time_delta_reference not in ("previous_transaction", "none")
        ):
            raise ValueError("All-position mode requires the explicit nonoverlapping_chunks / backward-time contract")
        self.save_hyperparameters()
        self.T = history_len + 1
        self.tokens_per_txn = continuous_dim + len(categorical_cardinality)
        self.attention_mask = attention_mask

        self.embedding = FeatureTokenizer(continuous_dim, categorical_cardinality, embed_dim,
                                              continuous_embedding, num_frequencies)
        # Stage 1: per-transaction CLS pools feature tokens -> one vector per txn.
        self.txn_cls = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.token_encoder = _encoder(
            embed_dim, num_heads, num_txn_blocks, ff_multiplier, attn_dropout, ff_dropout
        )
        # Stage 2: sequence CLS over transaction vectors predicts the target.
        self.txn_position = nn.Embedding(self.T, embed_dim)
        self.seq_cls = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.seq_encoder = _encoder(
            embed_dim, num_heads, num_seq_blocks, ff_multiplier, attn_dropout, ff_dropout
        )
        self.head = nn.Linear(embed_dim, 2)
        nn.init.normal_(self.txn_cls, std=0.02)
        nn.init.normal_(self.seq_cls, std=0.02)

        weight = None
        if pos_weight and pos_weight != 1.0:
            weight = torch.tensor([1.0, float(pos_weight)])
        self.loss_fn = nn.CrossEntropyLoss(weight=weight)

    @property
    def sequence_contract(self):
        """Persist semantic compatibility: tensor shapes alone cannot prove it."""
        return {
            "version": 1,
            "predict_every_transaction": bool(self.hparams.predict_every_transaction),
            "layout": self.hparams.all_position_layout or "sliding_target",
            "history_len": int(self.hparams.history_len),
            "time_delta_reference": self.hparams.time_delta_reference,
            "attention_mask": self.hparams.attention_mask,
            "architecture": {key: self.hparams[key] for key in (
                "continuous_dim", "categorical_cardinality", "embed_dim", "num_heads",
                "num_txn_blocks", "num_seq_blocks", "ff_multiplier", "attn_dropout",
                "ff_dropout", "continuous_embedding", "num_frequencies",
            )},
            "input_contract": self.hparams.input_contract,
        }

    def on_save_checkpoint(self, checkpoint):
        checkpoint["sequence_contract"] = self.sequence_contract

    def on_load_checkpoint(self, checkpoint):
        saved = checkpoint.get("sequence_contract")
        if saved is None:
            # Existing single-target checkpoints keep working. Old all-position
            # checkpoints used overlapping labels and future-relative gaps, so
            # they cannot be relabeled as this experiment merely by loading them.
            historical = checkpoint.get("hyper_parameters", {})
            old_every = historical.get("predict_every_transaction", False)
            if self.hparams.predict_every_transaction or old_every:
                raise ValueError("All-position checkpoint is missing the required sequence_contract; retrain this mode")
            for key in (*self.sequence_contract["architecture"], "history_len", "attention_mask"):
                if key in historical and historical[key] != self.hparams[key]:
                    raise ValueError(f"Checkpoint model hyperparameter mismatch: {key}")
            warnings.warn(
                "Legacy single-target checkpoint has no sequence_contract; feature/artifact identity cannot be verified",
                UserWarning,
            )
        elif saved != self.sequence_contract:
            raise ValueError(f"Checkpoint sequence_contract mismatch: {saved} != {self.sequence_contract}")

    def _build_causal_mask(self, device, key_padding=None):
        # FIX (bug #2, same CLS causal-mask leak as Architecture A -- see
        # YOUR_PACKAGE/phase4a/sequential.py for the full writeup): give seq_CLS txn_of =
        # self.T (one slot after every real transaction-vector) instead of the
        # original -1 + `tj<0 | ti<0` special case, which let any transaction-vector
        # attend back to seq_CLS (which legitimately saw the whole sequence,
        # including the target, as a query) -- leaking future-relative information
        # back into "earlier" transaction representations from layer 2 onward.
        # Single rule `tj <= ti` now covers everything correctly (see phase4a for
        # the exact case-by-case derivation).
        L = 1 + self.T
        txn_of = torch.full((L,), self.T, dtype=torch.long, device=device)  # seq_CLS slot defaults to T
        txn_of[1:] = torch.arange(self.T, device=device)
        ti = txn_of.unsqueeze(1)
        tj = txn_of.unsqueeze(0)
        disallowed = ~(tj <= ti)  # True = disallowed
        if key_padding is None:
            return disallowed
        # FIX (NaN / corrupt-gradient guard, found via external audit review -- see
        # YOUR_PACKAGE/phase4a/sequential.py for the full writeup): merge per-sample padding
        # into the causal mask and force the diagonal open so a padded transaction
        # slot's query row never ends up with every key disallowed.
        merged = disallowed.unsqueeze(0) | key_padding.unsqueeze(1)  # [B, L, L]
        diag = torch.eye(L, dtype=torch.bool, device=device).unsqueeze(0)
        merged = merged & ~diag
        float_mask = torch.zeros(merged.shape, dtype=torch.float32, device=device)
        float_mask.masked_fill_(merged, float("-inf"))
        return float_mask.repeat_interleave(self.hparams.num_heads, dim=0)  # [B*num_heads, L, L]

    def forward(self, batch):
        continuous, categorical, mask = batch["continuous"], batch["categorical"], batch["mask"]
        B, T, C = continuous.shape
        if T != self.T or mask.shape != (B, T):
            raise ValueError("Input sequence dimensions do not match the configured history_len")
        K = categorical.shape[-1]
        d = self.hparams.embed_dim

        # -- stage 1: encode each transaction independently (shared weights) --
        tokens = self.embedding(
            continuous.reshape(B * T, C), categorical.reshape(B * T, K)
        )  # [B*T, tokens_per_txn, d]
        cls = self.txn_cls.expand(B * T, 1, d)
        tok_seq = torch.cat([cls, tokens], dim=1)  # [B*T, 1+tokens_per_txn, d]
        txn_vec = self.token_encoder(tok_seq)[:, 0]  # CLS -> [B*T, d]
        txn_vec = txn_vec.reshape(B, T, d)

        # -- stage 2: sequence transformer over transaction vectors --
        pos = self.txn_position(torch.arange(T, device=continuous.device))  # [T, d]
        txn_vec = txn_vec + pos[None, :, :]
        seq_cls = self.seq_cls.expand(B, 1, d)
        seq = torch.cat([seq_cls, txn_vec], dim=1)  # [B, 1+T, d]

        key_padding = torch.cat(
            [torch.zeros(B, 1, dtype=torch.bool, device=mask.device), ~mask], dim=1
        )  # True = ignore padded transactions (seq_CLS always valid)
        if self.attention_mask == "causal":
            # Padding is merged into the mask itself (see _build_causal_mask), so
            # src_key_padding_mask is NOT also passed here -- avoids double-masking.
            attn_mask = self._build_causal_mask(seq.device, key_padding)
            out = self.seq_encoder(seq, mask=attn_mask)
        else:
            out = self.seq_encoder(seq, src_key_padding_mask=key_padding)
        self._cls = out[:, 0]  # cached seq-CLS for embed()
        if self.hparams.predict_every_transaction:
            # One prediction per transaction-vector (out[:,0] is seq_CLS, skip it).
            return self.head(out[:, 1:])  # [B, T, 2]
        return self.head(self._cls)  # seq_CLS -> [B, 2]

    @torch.no_grad()
    def embed(self, batch):
        """Sequence-CLS embedding [B, embed_dim], available at the sequence end.

        In chunk mode this summarizes the entire chunk, so it must not be used
        as an earlier transaction's decision-time embedding.
        """
        self(batch)
        return self._cls

    def _step(self, batch, tag):
        logits = self(batch)
        if self.hparams.predict_every_transaction:
            labels = batch["target_seq"]
            valid = batch["mask"]
            if labels.shape != valid.shape or not torch.equal(labels != -100, valid):
                raise ValueError("Every real transaction must own exactly one target; padding must use -100")
            logits, y = logits[valid], labels[valid]
            if not y.numel():
                raise ValueError("An all-padding chunk cannot contribute a training/evaluation batch")
            # Average weighted terms over actual transactions, not padded slots
            # or chunks. Logging with the same denominator preserves the exact
            # epoch mean even when the final chunk/batch is short.
            loss = nn.functional.cross_entropy(logits, y, weight=self.loss_fn.weight, reduction="sum") / y.numel()
        else:
            y = batch["target"].reshape(-1)
            loss = self.loss_fn(logits, y)
        self.log(f"{tag}_loss", loss, on_epoch=True, on_step=(tag == "train"),
                 prog_bar=True, sync_dist=True, batch_size=int(y.numel()))
        return logits, y, loss

    def training_step(self, batch, batch_idx):
        _, _, loss = self._step(batch, "train")
        return loss

    def validation_step(self, batch, batch_idx):
        logits, y, _ = self._step(batch, "valid")
        return logits, y  # consumed by StreamingBinaryMetrics

    def configure_optimizers(self):
        opt = build_optimizer(
            getattr(self.hparams, "optimizer", "adamw"), self.parameters(),
            lr=self.hparams.learning_rate, weight_decay=self.hparams.weight_decay,
        )
        sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, patience=3, factor=0.5)
        return {"optimizer": opt, "lr_scheduler": {"scheduler": sched, "monitor": "valid_loss"}}
