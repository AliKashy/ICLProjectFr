"""Regression checks for aligned, fixed-seed leaderboard estimates."""
import csv
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from sklearn.metrics import average_precision_score, roc_auc_score

from YOUR_PACKAGE.scoring import leaderboard


def _frame(scores=(0.1, 0.2, 0.8, 0.9)):
    return pd.DataFrame({
        "fi_transaction_id": [10, 20, 30, 40],
        "Nmap_account_reference_xid": ["a", "b", "a", "b"],
        "frd_tag": [0, 0, 1, 1],
        "score": scores,
    })


def _run(monkeypatch, tmp_path, frames, models, extra=()):
    out = tmp_path / "leaderboard.csv"
    argv = ["leaderboard", "--out", str(out), "--bootstrap", "32"]
    for spec in models:
        argv.extend(["--model", spec])
    argv.extend(extra)
    monkeypatch.setattr(sys, "argv", argv)
    monkeypatch.setattr(leaderboard, "make_s3_filesystem", lambda _: None)
    monkeypatch.setattr(leaderboard, "_read", lambda path, fs: frames[Path(path).name].copy())
    leaderboard.main()
    with out.open() as stream:
        return list(csv.DictReader(stream))


def test_opposite_seed_auc_interval_describes_mean_not_last_seed(monkeypatch, tmp_path):
    frames = {"good": _frame(), "bad": _frame((0.9, 0.8, 0.2, 0.1)).iloc[::-1]}
    row = _run(monkeypatch, tmp_path, frames, ["model=good,bad"])[0]
    assert float(row["roc_auc"]) == 0.5
    assert row["roc_auc_ci95"] == "[0.5000,0.5000]"
    assert float(row["roc_auc_std"]) == 0.5
    assert row["ci_estimand"] == "mean_metric_across_fixed_seed_models"
    expected_ap = np.mean([average_precision_score(df.frd_tag, df.score) for df in frames.values()])
    assert float(row["pr_auc"]) == pytest.approx(expected_ap, abs=5e-5)
    reversed_row = _run(monkeypatch, tmp_path, frames, ["model=bad,good"])[0]
    assert reversed_row == row


def test_bootstrap_with_groups_resamples_complete_accounts():
    y = np.array([0, 1, 0, 1])
    scores = np.arange(4, dtype=float)
    groups = np.array(["a", "a", "b", "b"])
    observed = []

    def metric(targets, sample_scores):
        counts = np.bincount(sample_scores.astype(int), minlength=4)
        assert counts[0] == counts[1]
        assert counts[2] == counts[3]
        observed.append(counts)
        return float(sample_scores.mean())

    lo, hi = leaderboard._bootstrap_ci(y, scores, metric, 20, groups=groups)
    assert len(observed) == 20
    assert np.isfinite([lo, hi]).all()


def test_account_bootstrap_is_labelled_and_aligned(monkeypatch, tmp_path):
    frames = {"a": _frame(), "b": _frame().iloc[[2, 0, 3, 1]]}
    row = _run(monkeypatch, tmp_path, frames, ["model=a,b"],
               ["--group", "Nmap_account_reference_xid"])[0]
    assert row["bootstrap_unit"] == "group:Nmap_account_reference_xid"
    assert row["roc_auc_ci95"] == "[1.0000,1.0000]"


def test_group_may_equal_unique_transaction_id(monkeypatch, tmp_path):
    frames = {"a": _frame(), "b": _frame().iloc[::-1]}
    row = _run(monkeypatch, tmp_path, frames, ["model=a,b"],
               ["--group", "fi_transaction_id"])[0]
    assert row["bootstrap_unit"] == "group:fi_transaction_id"
    assert row["roc_auc_ci95"] == "[1.0000,1.0000]"


def test_single_account_has_no_sampling_interval(monkeypatch, tmp_path):
    frame = _frame()
    frame["Nmap_account_reference_xid"] = "one_account"
    row = _run(monkeypatch, tmp_path, {"a": frame}, ["model=a"],
               ["--group", "Nmap_account_reference_xid"])[0]
    assert row["roc_auc_ci95"] == "-"
    assert row["pr_auc_ci95"] == "-"
    assert float(row["roc_auc"]) == 1.0


@pytest.mark.parametrize("change", ["missing_row", "different_label", "different_account"])
def test_mismatched_seed_cohorts_are_rejected(monkeypatch, tmp_path, change):
    other = _frame()
    if change == "missing_row":
        other = other.iloc[1:]
    elif change == "different_label":
        other.loc[0, "frd_tag"] = 1
    else:
        other.loc[0, "Nmap_account_reference_xid"] = "different"
    with pytest.raises(ValueError, match="identical transaction IDs"):
        _run(monkeypatch, tmp_path, {"a": _frame(), "b": other}, ["model=a,b"],
             ["--group", "Nmap_account_reference_xid"])


def test_different_models_also_require_same_cohort(monkeypatch, tmp_path):
    with pytest.raises(ValueError, match="identical transaction IDs"):
        _run(monkeypatch, tmp_path, {"a": _frame(), "b": _frame().iloc[:3]},
             ["A=a", "B=b"])


@pytest.mark.parametrize("column,value", [
    ("fi_transaction_id", 20), ("frd_tag", 0.25), ("score", float("nan")),
])
def test_invalid_rows_fail_before_metrics(monkeypatch, tmp_path, column, value):
    frame = _frame()
    if column == "frd_tag":
        frame[column] = frame[column].astype(float)
    frame.loc[0, column] = value
    with pytest.raises(ValueError):
        _run(monkeypatch, tmp_path, {"bad": frame}, ["model=bad"])


@pytest.mark.parametrize("budget", ["0", "-0.1", "1.5", "nan"])
def test_invalid_budget_is_rejected(monkeypatch, tmp_path, budget):
    with pytest.raises(SystemExit) as exc:
        _run(monkeypatch, tmp_path, {"a": _frame()}, ["model=a"], ["--budget", budget])
    assert exc.value.code == 2


def test_one_seed_bootstrap_retains_metric_definition():
    frame = _frame()
    y, score = frame.frd_tag.to_numpy(), frame.score.to_numpy()
    assert leaderboard._bootstrap_ci(y, score, roc_auc_score, 20) == (1.0, 1.0)


@pytest.mark.parametrize("groups", [
    ["a", "a", None, "b"], [1, 1, np.inf, 2], ["a", "a", np.inf, "b"],
    [["a"], ["a"], ["b"], ["b"]], ["a"],
])
def test_bootstrap_rejects_invalid_groups_even_when_resampling_disabled(groups):
    frame = _frame()
    with pytest.raises(ValueError):
        leaderboard._bootstrap_ci(frame.frd_tag.to_numpy(), frame.score.to_numpy(),
                                  roc_auc_score, 0, groups=np.array(groups, dtype=object))


def test_bootstrap_rejects_misaligned_seed_columns_before_resampling():
    frame = _frame()
    with pytest.raises(ValueError, match="aligned column"):
        leaderboard._bootstrap_ci(frame.frd_tag.to_numpy(), np.zeros((3, 2)), roc_auc_score, 10)


def test_bootstrap_reports_single_class_draws_and_valid_replicate_count():
    y, scores = np.array([0, 0, 1, 1]), np.array([0.1, 0.2, 0.8, 0.9])
    groups = np.array(["negative", "negative", "positive", "positive"])
    details = leaderboard._bootstrap_ci(y, scores, roc_auc_score, 200,
                                        groups=groups, return_details=True)
    assert details["n_units"] == 2
    assert details["attempted"] == details["requested"] == 200
    assert 0 < details["valid"] < 200
    assert details["valid"] + details["single_class"] == 200
    assert details["ci"] == (1.0, 1.0)
    one_draw = leaderboard._bootstrap_ci(y, scores, roc_auc_score, 1, return_details=True)
    assert one_draw["status"] == "insufficient_valid_resamples"
    assert np.isnan(one_draw["ci"]).all()


def test_alert_precision_ties_are_expected_uniform_metrics():
    labels, scores = np.array([0, 1, 1, 0]), np.array([0.9, 0.9, 0.9, 0.1])
    for order in (np.arange(4), np.array([1, 0, 2, 3])):
        assert leaderboard._precision_at(labels[order], scores[order], 0.25) == pytest.approx(2 / 3)


def test_local_cli_needs_no_credentials_and_keeps_sampling_metadata(tmp_path, monkeypatch):
    frame = _frame()
    pred = tmp_path / "predictions.parquet"
    frame.to_parquet(pred, index=False)
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(sys, "argv", ["leaderboard", "--model", "model=predictions.parquet",
                                     "--group", "Nmap_account_reference_xid", "--bootstrap", "20"])

    def no_remote(*args, **kwargs):
        raise AssertionError("Local analysis must not initialize S3")

    monkeypatch.setattr(leaderboard, "make_s3_filesystem", no_remote)
    leaderboard.main()
    row = pd.read_csv(tmp_path / "leaderboard.csv").iloc[0]
    assert row.bootstrap_units == 2
    assert row.bootstrap_attempted == row.bootstrap_valid == 20
    assert row.bootstrap_single_class == 0
    assert row.budget_tie_policy == "expected_uniform_selection_within_cutoff_tie"


@pytest.mark.parametrize("dtype,power", [(np.float16, 11), (np.float32, 24), (np.float64, 53)])
@pytest.mark.parametrize("column", ["fi_transaction_id", "Nmap_account_reference_xid"])
def test_float_identifier_precision_boundaries_are_rejected(dtype, power, column):
    frame = _frame()
    frame[column] = np.array([2 ** power, 2 ** power + 2, 2 ** power + 4, 2 ** power + 6], dtype=dtype)
    with pytest.raises(ValueError, match="unsafe floating identifier"):
        leaderboard._validate_predictions(frame, "fi_transaction_id", "frd_tag", "score",
                                            "Nmap_account_reference_xid")


def test_object_float32_identifier_keeps_its_own_precision_guard():
    frame = _frame()
    frame["fi_transaction_id"] = pd.Series([np.float32(2 ** 24), 2, 3, 4], dtype=object)
    with pytest.raises(ValueError, match="unsafe floating identifier"):
        leaderboard._validate_predictions(frame, "fi_transaction_id", "frd_tag", "score")


def test_large_signed_unsigned_integer_cohorts_cannot_align_through_float(monkeypatch, tmp_path):
    first, second = _frame(), _frame()
    first["fi_transaction_id"] = np.array([2 ** 63 - n for n in [9, 7, 5, 3]], dtype=np.int64)
    second["fi_transaction_id"] = np.array([2 ** 63 - n for n in [10, 8, 6, 4]], dtype=np.uint64)
    with pytest.raises(ValueError, match="identical transaction IDs"):
        _run(monkeypatch, tmp_path, {"a": first, "b": second}, ["model=a,b"])


def test_small_float_account_ids_are_preserved_and_bool_labels_are_valid():
    frame = _frame()
    frame["fi_transaction_id"] = ["001", "1", "002", "2"]
    frame["frd_tag"] = frame.frd_tag.astype(bool)
    frame["Nmap_account_reference_xid"] = [37389549.0, 12.0, 37389549.0, 12.0]
    validated = leaderboard._validate_predictions(frame, "fi_transaction_id", "frd_tag", "score",
                                                   "Nmap_account_reference_xid")
    assert set(validated.fi_transaction_id) == {"001", "1", "002", "2"}
    assert set(validated.Nmap_account_reference_xid) == {37389549.0, 12.0}
    assert validated.frd_tag.dtype == bool


def test_boolean_account_identifiers_are_rejected_without_rejecting_boolean_labels():
    frame = _frame()
    frame["frd_tag"] = frame.frd_tag.astype(bool)
    frame["Nmap_account_reference_xid"] = [False, False, True, True]
    with pytest.raises(ValueError, match="boolean identifiers"):
        leaderboard._validate_predictions(frame, "fi_transaction_id", "frd_tag", "score",
                                            "Nmap_account_reference_xid")


def test_float32_bootstrap_groups_are_checked_before_factorization():
    frame = _frame()
    groups = np.array([2 ** 24, 2 ** 24, 2 ** 24 + 2, 2 ** 24 + 2], dtype=np.float32)
    with pytest.raises(ValueError, match="unsafe floating identifier"):
        leaderboard._bootstrap_ci(frame.frd_tag.to_numpy(), frame.score.to_numpy(),
                                  roc_auc_score, 20, groups=groups)
