"""Cohort conservation and calendar gaps in descriptive period reporting."""

import sys

import numpy as np
import pandas as pd
import pytest

from YOUR_PACKAGE.scoring import temporal_eval


def _inputs():
    preds = pd.DataFrame({"id": [1, 2, 3, 4, 5], "target": [0, 1, 1, 0, 1],
                          "score": [0.1, 0.9, 0.5, 0.9, 0.1]})
    times = pd.DataFrame({"id": [1, 2, 3, 4, 5], "timestamp": [
        "2024-01-15", "2024-01-15", "2024-03-15", "2024-04-15", "2024-04-15"]})
    return preds, times


def _prepare(preds, times):
    return temporal_eval._prepare_predictions(preds, times, "id", "target", "score", "timestamp")


def test_raw_superset_preserves_prediction_cohort_and_its_calendar_bounds():
    preds, times = _inputs()
    extra = pd.DataFrame({"id": [90, 91, 92],
                          "timestamp": ["2023-01-01", "2025-01-01", "unused-invalid-time"]})
    raw = pd.concat([times, extra], ignore_index=True).sample(frac=1, random_state=3)
    shuffled = preds.sample(frac=1, random_state=7)
    prepared = _prepare(shuffled, raw)
    assert prepared.id.tolist() == shuffled.id.tolist()
    pd.testing.assert_frame_equal(prepared[preds.columns].reset_index(drop=True),
                                  shuffled.reset_index(drop=True))
    rows = temporal_eval._period_metrics(prepared, "month", "timestamp", "target", "score")
    assert [row["bucket"] for row in rows] == ["2024-01", "2024-02", "2024-03", "2024-04"]
    assert sum(row["n"] for row in rows) == len(preds)


def test_empty_and_single_class_months_remain_and_trend_uses_calendar_distance():
    preds, times = _inputs()
    rows = temporal_eval._period_metrics(_prepare(preds, times), "month", "timestamp", "target", "score")
    assert [row["n"] for row in rows] == [2, 0, 1, 2]
    assert [row["positives"] for row in rows] == [1, 0, 1, 1]
    assert [row["status"] for row in rows] == ["ok", "empty", "single_class", "ok"]
    assert rows[1]["fraud_rate"] is None
    assert rows[2]["fraud_rate"] == 1.0
    for row in rows[1:3]:
        assert row["pr_auc"] is None and row["roc_auc"] is None
    ap_trend = temporal_eval._trend(rows, "pr_auc")
    auc_trend = temporal_eval._trend(rows, "roc_auc")
    assert ap_trend["first_bucket"] == "2024-01"
    assert ap_trend["last_bucket"] == "2024-04"
    assert ap_trend["delta"] == pytest.approx(-0.5)
    assert ap_trend["slope"] == pytest.approx(-0.5 / 3)
    assert auc_trend["slope"] == pytest.approx(-1.0 / 3)


@pytest.mark.parametrize("period,dates,expected", [
    ("day", ["2024-02-28", "2024-03-01"], ["2024-02-28", "2024-02-29", "2024-03-01"]),
    ("week", ["2023-12-31", "2024-01-08"],
     ["2023-12-25/2023-12-31", "2024-01-01/2024-01-07", "2024-01-08/2024-01-14"]),
])
def test_actual_calendar_period_order_across_boundaries(period, dates, expected):
    preds = pd.DataFrame({"id": [1, 2], "target": [0, 1], "score": [0.2, 0.8]})
    times = pd.DataFrame({"id": [1, 2], "timestamp": dates})
    rows = temporal_eval._period_metrics(_prepare(preds.iloc[::-1], times), period,
                                         "timestamp", "target", "score")
    assert [row["bucket"] for row in rows] == expected
    assert [row["n"] for row in rows] == [1, 0, 1]
    assert temporal_eval._trend(rows, "pr_auc") is None


def test_supplied_timezone_calendar_is_preserved():
    preds = pd.DataFrame({"id": [1, 2], "target": [0, 1], "score": [0.2, 0.8]})
    times = pd.DataFrame({"id": [1, 2], "timestamp": pd.to_datetime([
        "2024-01-31T23:30:00-05:00", "2024-02-01T00:30:00-05:00"])})
    rows = temporal_eval._period_metrics(_prepare(preds, times), "month", "timestamp", "target", "score")
    assert [row["bucket"] for row in rows] == ["2024-01", "2024-02"]


@pytest.mark.parametrize("case,message", [
    ("duplicate_pred", "predictions: IDs"),
    ("duplicate_raw", "raw timestamps: IDs"),
    ("null_pred_id", "predictions: IDs"),
    ("null_raw_id", "raw timestamps: IDs"),
    ("unmatched", "lack timestamps for 1 prediction IDs"),
    ("missing_timestamp", "Invalid or missing timestamps"),
    ("invalid_timestamp", "Invalid or missing timestamps"),
    ("numeric_timestamp", "explicit unit conversion"),
    ("mixed_numeric_timestamp", "explicit unit conversion"),
    ("nonbinary_target", "binary values"),
    ("null_target", "binary values"),
    ("nan_score", "finite numeric"),
    ("inf_score", "finite numeric"),
    ("nonnumeric_score", "finite numeric"),
    ("empty_predictions", "cohort is empty"),
])
def test_invalid_inputs_are_rejected_instead_of_dropped(case, message):
    preds, times = _inputs()
    if case == "duplicate_pred":
        preds.loc[1, "id"] = 1
    elif case == "duplicate_raw":
        times.loc[1, "id"] = 1
    elif case == "null_pred_id":
        preds.loc[1, "id"] = np.nan
    elif case == "null_raw_id":
        times.loc[1, "id"] = np.nan
    elif case == "unmatched":
        times = times.iloc[1:]
    elif case == "missing_timestamp":
        times.loc[1, "timestamp"] = None
    elif case == "invalid_timestamp":
        times.loc[1, "timestamp"] = "not-a-time"
    elif case == "numeric_timestamp":
        times["timestamp"] = 1700000000
    elif case == "mixed_numeric_timestamp":
        times["timestamp"] = pd.Series([
            pd.Timestamp("2024-01-15"), 1700000000, pd.Timestamp("2024-03-15"),
            pd.Timestamp("2024-04-15"), pd.Timestamp("2024-04-15")], dtype=object)
    elif case == "nonbinary_target":
        preds["target"] = preds.target.astype(float)
        preds.loc[1, "target"] = 0.5
    elif case == "null_target":
        preds.loc[1, "target"] = np.nan
    elif case == "nan_score":
        preds.loc[1, "score"] = np.nan
    elif case == "inf_score":
        preds.loc[1, "score"] = np.inf
    elif case == "nonnumeric_score":
        preds["score"] = preds.score.astype(object)
        preds.loc[1, "score"] = "not-a-score"
    elif case == "empty_predictions":
        preds = preds.iloc[:0]
    with pytest.raises(ValueError, match=message):
        _prepare(preds, times)


@pytest.mark.parametrize("invalid", [False, True])
def test_cli_with_local_parquet_preserves_cohort_or_fails_explicitly(tmp_path, monkeypatch, capsys, invalid):
    preds, times = _inputs()
    if invalid:
        times = times.iloc[1:]
    raw = tmp_path / "raw"
    raw.mkdir()
    pred_path, out = tmp_path / "preds.parquet", tmp_path / "metrics.csv"
    preds.to_parquet(pred_path, index=False)
    times.to_parquet(raw / "part_8000.parquet", index=False)
    def no_remote(*args, **kwargs):
        raise AssertionError("Local temporal evaluation must not initialize S3")
    monkeypatch.setattr(temporal_eval, "make_s3_filesystem", no_remote)
    monkeypatch.setattr(sys, "argv", ["temporal_eval.py", "--pred", str(pred_path),
        "--raw-base", str(raw), "--file-start", "8000", "--file-end", "8000",
        "--id", "id", "--target", "target", "--order-col", "timestamp", "--out", str(out)])
    if invalid:
        with pytest.raises(ValueError, match="lack timestamps"):
            temporal_eval.main()
        assert not out.exists()
    else:
        temporal_eval.main()
        report = pd.read_csv(out)
        assert report.n.sum() == len(preds)
        assert report.bucket.tolist() == ["2024-01", "2024-02", "2024-03", "2024-04"]
        assert report.loc[1:2, ["pr_auc", "roc_auc"]].isna().all().all()
        output = capsys.readouterr().out
        assert "Descriptive prediction metrics" in output
        assert "slope/calendar-period=-0.16667" in output
        assert "evidence of drift" not in output and "retraining" not in output


def test_single_class_cohort_still_reports_all_counts_without_claiming_drift():
    preds, times = _inputs()
    preds["target"] = 0
    rows = temporal_eval._period_metrics(_prepare(preds, times), "month", "timestamp", "target", "score")
    assert sum(row["n"] for row in rows) == len(preds)
    assert all(row["pr_auc"] is None and row["roc_auc"] is None for row in rows)
    assert temporal_eval._trend(rows, "pr_auc") is None


def test_infinite_raw_identifiers_are_rejected_before_join():
    preds, times = _inputs()
    times["id"] = times.id.astype(float)
    times.loc[0, "id"] = float("inf")
    with pytest.raises(ValueError, match="IDs must be finite"):
        _prepare(preds, times)


def test_unsafe_float_timestamp_ids_cannot_join_distinct_large_integer_predictions():
    base = 2 ** 53
    preds = pd.DataFrame({"id": [base + 1, base + 3], "target": [0, 1], "score": [0.1, 0.9]})
    times = pd.DataFrame({"id": [float(base), float(base + 4)],
                          "timestamp": ["2024-01-01", "2024-02-01"]})
    with pytest.raises(ValueError, match="unsafe floating identifier"):
        _prepare(preds, times)


@pytest.mark.parametrize("matching", [True, False])
def test_temporal_signed_unsigned_integer_join_is_exact(matching):
    base = 2 ** 63
    preds = pd.DataFrame({"id": np.array([base - 3, base - 1], dtype=np.int64),
                          "target": [0, 1], "score": [0.1, 0.9]})
    times = pd.DataFrame({"id": np.array([base - 3, base - 1] if matching else [base - 4, base - 2],
                                          dtype=np.uint64),
                          "timestamp": ["2024-01-01", "2024-02-01"]})
    if matching:
        aligned = _prepare(preds, times)
        assert aligned.id.tolist() == [base - 3, base - 1]
    else:
        with pytest.raises(ValueError, match="lack timestamps"):
            _prepare(preds, times)
