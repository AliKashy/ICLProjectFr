"""YOUR_PACKAGE/scripts/build_leaderboard.py (owner, 2026-10-08) on both results layouts: the older runner's single
results.csv per test folder, and attempt folders (<output_root>/<attempt>/results.csv, a latest-view copy at
<output_root>/results.csv and previous_results.csv). Failed runs are never ranked, evaluation and validation AP are
ranked separately, and each run is counted once (reviewer's SRC-02, SRC-03, SRC-04)."""
import csv
import importlib.util
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("build_leaderboard", ROOT / "YOUR_PACKAGE/scripts/build_leaderboard.py")
lb = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lb)

OLD_COLS = ["run_name", "history", "train_rc", "best_valid_ap", "best_valid_auroc", "eval_ap", "eval_auroc"]
RUNNER_COLS = ["attempt", "run_dir", "score_rc", "status", "predictions_path", "n_predictions", "n_positives",
               "checkpoint_epoch", "checkpoint_step", "checkpoint_monitor", "checkpoint_monitor_score",
               "checkpoint_sha256", "resolved_train_sha256", "source_sha256", "manifest_path", "error"]
NEW_COLS = OLD_COLS + RUNNER_COLS


def _write(path, cols, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({c: r.get(c, "") for c in cols})


def _row(run, attempt="", status="ok", rc=0, valid=None, eval_ap=None, **kw):
    return {"run_name": run, "history": run, "train_rc": rc, "best_valid_ap": valid, "best_valid_auroc": valid,
            "eval_ap": eval_ap, "eval_auroc": eval_ap, "attempt": attempt, "status": status if attempt else "",
            "run_dir": f"/x/{attempt}/{run}", "error": "", **kw}


def _board(tmp_path):
    rows, axes = lb.load_all_rows(str(tmp_path / "ablations"))
    ranked, unranked = lb.write_leaderboard(rows, axes, str(tmp_path / "board.csv"))
    with (tmp_path / "board.csv").open(newline="") as f:
        written = list(csv.DictReader(f))
    return ranked, unranked, written


def test_attempt_layout_counts_each_run_once_and_keeps_legacy_rows(tmp_path):
    test = tmp_path / "ablations/arch_b_hier/history_h5_h10"
    legacy = [_row("history-h5", rc=0, valid=0.30), _row("history-h10", rc=0, valid=0.31)]
    a1 = [_row("history-h5", "A1", valid=0.40, eval_ap=0.08), _row("history-h10", "A1", valid=0.41, eval_ap=0.09)]
    a2 = [_row("history-h5", "A2", valid=0.42, eval_ap=0.10)]
    _write(test / "A1/previous_results.csv", OLD_COLS, legacy)   # what the first attempt's latest view replaced
    _write(test / "A1/results.csv", NEW_COLS, a1)
    _write(test / "A2/previous_results.csv", NEW_COLS, a1)       # the second attempt replaced the first's view
    _write(test / "A2/results.csv", NEW_COLS, a2)
    _write(test / "results.csv", NEW_COLS, a2)                   # latest view
    for attempt in ("A1", "A2"):
        (test / attempt / "ablation_spec.yaml").write_text("x: 1\n")
    ranked, unranked, written = _board(tmp_path)
    keys = sorted((r["attempt"], r["run_name"]) for r in written)
    assert keys == [("", "history-h10"), ("", "history-h5"), ("A1", "history-h10"), ("A1", "history-h5"),
                    ("A2", "history-h5")]
    assert {r["source_csv"].split("history_h5_h10/")[1] for r in written if r["attempt"]} == {"A1/results.csv",
                                                                                               "A2/results.csv"}
    assert not [c for c in written[0] if c in ("run_dir", "error", "status_x")]  # bookkeeping is not an axis


def test_failed_and_rejected_runs_are_listed_but_never_ranked(tmp_path):
    test = tmp_path / "ablations/arch_a_flat/core"
    rows = [_row("h5", "A1", valid=0.50, eval_ap=0.20),
            _row("h10", "A1", status="score_failed", valid=0.90),            # trained, scoring failed
            _row("h15", "A1", status="source_changed", valid=0.95, eval_ap=0.99),
            _row("h20", "A1", status="train_failed", rc=7)]
    _write(test / "A1/results.csv", NEW_COLS, rows)
    (test / "A1/ablation_spec.yaml").write_text("x: 1\n")
    _write(tmp_path / "ablations/arch_a_flat/old/results.csv", OLD_COLS,
           [_row("crashed", rc=1, valid=0.99), _row("fine", rc=0, valid=0.10)])
    ranked, unranked, written = _board(tmp_path)
    assert [r["run_name"] for r in ranked] == ["h5", "fine"]
    assert {r["run_name"] for r in unranked} == {"h10", "h15", "h20", "crashed"}
    assert all(r["rank"] == "" for r in written if r["run_name"] in {"h10", "h15", "h20", "crashed"})


def test_evaluation_and_validation_ap_are_ranked_separately(tmp_path):
    _write(tmp_path / "ablations/arch_a_flat/scored/results.csv", OLD_COLS,
           [_row("s1", valid=0.30, eval_ap=0.05), _row("s2", valid=0.31, eval_ap=0.07)])
    _write(tmp_path / "ablations/arch_a_flat/valid_only/results.csv", OLD_COLS,
           [_row("v1", valid=0.40), _row("v2", valid=0.45)])
    ranked, _, written = _board(tmp_path)
    order = [(r["rank_metric"], r["rank"], r["run_name"]) for r in written]
    assert order == [("eval_ap", "1", "s2"), ("eval_ap", "2", "s1"),
                     ("best_valid_ap", "1", "v2"), ("best_valid_ap", "2", "v1")]


@pytest.mark.parametrize("phase", ["phase4a", "phase4b"])
def test_real_runner_output_is_counted_once(tmp_path, phase):
    """Two runs of the actual runner (synthetic train/score stubs) into one output root, over a legacy results.csv."""
    from YOUR_PACKAGE.tests.test_ablation_artifacts import launch, make_app

    app = make_app(tmp_path, phase)
    root = app[0]
    latest = root / "ablations/grid/results.csv"
    latest.parent.mkdir(parents=True)
    latest.write_text("run_name,train_rc,best_valid_ap\nlegacy,0,0.9\n")
    attempts = set()
    for _ in range(2):
        proc, rows = launch(app)
        assert proc.returncode == 0, proc.stdout + proc.stderr
        attempts.add(rows[0]["attempt"])
    rows, _ = lb.load_all_rows(str(root / "ablations"))
    # legacy + one row per attempt; not 5 (the latest view and both previous_results.csv copies repeat them)
    assert sorted((r["attempt"], r["run_name"]) for r in rows) == sorted(
        [("", "legacy")] + [(a, "mask-bidir") for a in attempts])
    assert {(r["architecture"], r["test"]) for r in rows} == {("grid", "-")}
