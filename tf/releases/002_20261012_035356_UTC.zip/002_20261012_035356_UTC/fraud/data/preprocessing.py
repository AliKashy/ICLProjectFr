"""Preprocessing: continuous imputation and a versioned artifact store.

Two pieces:

**ContinuousImputer**
    Median (or mean/zero) imputation with an optional ``<col>_isna`` missing
    indicator flag. Fit on train, apply to train/val/test. Used by the pandas
    smoke-test path.

**PreprocessingArtifacts**
    Frozen, versioned per-feature statistics for the streaming path:
    - continuous: mean, std, median (impute), missing fraction
    - categorical: a vocabulary mapping category -> index, with reserved
      indices ``0 = UNK/OOV`` and ``1 = MISSING`` (known categories start at 2)

Serialized as ``manifest.json`` + one JSON per feature so new features can be
appended without recomputing existing ones. Readable/writable on local disk
or S3 (via an s3fs filesystem).
"""

from __future__ import annotations

import datetime as _dt
import json
import posixpath
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from fraud.data.s3_utils import strip_scheme

UNK_INDEX = 0
MISSING_INDEX = 1
FIRST_CATEGORY_INDEX = 2

_VALID_STRATEGIES = ("median", "mean", "zero")


# ---------------------------------------------------------------------------
# Continuous imputation (pandas smoke-test path)
# ---------------------------------------------------------------------------
@dataclass
class ContinuousImputer:
    """Impute continuous columns and optionally add missing-indicator flags."""

    strategy: str = "median"
    add_flag: bool = True
    fill_values_: Dict[str, float] = field(default_factory=dict)
    flag_cols_: List[str] = field(default_factory=list)

    def fit(self, df: pd.DataFrame, columns: List[str]) -> "ContinuousImputer":
        if self.strategy not in _VALID_STRATEGIES:
            raise ValueError(f"Unknown impute strategy: {self.strategy!r}")
        self.fill_values_ = {}
        for col in columns:
            s = pd.to_numeric(df[col], errors="coerce")
            if self.strategy == "median":
                fill = float(s.median())
            elif self.strategy == "mean":
                fill = float(s.mean())
            else:
                fill = 0.0
            if np.isnan(fill):
                fill = 0.0
            self.fill_values_[col] = fill
        return self

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        self.flag_cols_ = []
        for col, fill in self.fill_values_.items():
            numeric = pd.to_numeric(df[col], errors="coerce")
            if self.add_flag:
                flag_col = f"{col}_isna"
                df[flag_col] = numeric.isna().astype(int)
                self.flag_cols_.append(flag_col)
            df[col] = numeric.fillna(fill)
        return df

    def fit_transform(self, df: pd.DataFrame, columns: List[str]) -> pd.DataFrame:
        return self.fit(df, columns).transform(df)


# ---------------------------------------------------------------------------
# Versioned artifact store (streaming path)
# ---------------------------------------------------------------------------
def fit_continuous_stats(series: pd.Series) -> Dict:
    s = pd.to_numeric(series, errors="coerce")
    median = float(s.median())
    mean = float(s.mean())
    std = float(s.std(ddof=0))
    if np.isnan(median):
        median = 0.0
    if np.isnan(mean):
        mean = 0.0
    if np.isnan(std) or std == 0.0:
        std = 1.0
    return {
        "type": "continuous",
        "encoder": "standardize",
        "impute": "median",
        "mean": mean,
        "std": std,
        "median": median,
        "missing_frac": float(s.isna().mean()),
    }


def fit_categorical_stats(series: pd.Series, method: str = "vocab") -> Dict:
    """Build a categorical vocab with reserved UNK/MISSING indices.

    ``method`` is stored for forward-compatibility; only ``vocab`` is
    implemented here. High-cardinality encoders (hashing, frequency, target)
    are wired in later.
    """
    if method != "vocab":
        raise NotImplementedError(f"Encoder method not implemented yet: {method!r}")
    counts = series.dropna().astype(str).value_counts()
    vocab = {
        cat: idx
        for idx, cat in enumerate(counts.index.tolist(), start=FIRST_CATEGORY_INDEX)
    }
    return {
        "type": "categorical",
        "method": method,
        "unk_index": UNK_INDEX,
        "missing_index": MISSING_INDEX,
        "vocab": vocab,
        "n_categories": len(vocab),
        "cardinality": len(vocab) + FIRST_CATEGORY_INDEX,  # incl. UNK + MISSING
        "missing_frac": float(series.isna().mean()),
    }


class PreprocessingArtifacts:
    """Versioned, expandable per-feature preprocessing statistics."""

    def __init__(
        self,
        artifact_version: int = 1,
        predictor_version: Optional[int] = None,
        features: Optional[Dict[str, Dict]] = None,
        fit_files: Optional[List[str]] = None,
        created: Optional[str] = None,
    ):
        self.artifact_version = artifact_version
        self.predictor_version = predictor_version
        self.features: Dict[str, Dict] = features or {}
        self.fit_files: List[str] = fit_files or []
        self.created = created or _dt.date.today().isoformat()

    # -- fitting ------------------------------------------------------------
    def fit_feature(self, name: str, series: pd.Series, ftype: str,
                    method: str = "vocab") -> None:
        if ftype == "continuous":
            self.features[name] = fit_continuous_stats(series)
        elif ftype == "categorical":
            self.features[name] = fit_categorical_stats(series, method=method)
        else:
            raise ValueError(f"Unknown feature type: {ftype!r}")

    # -- applying -----------------------------------------------------------
    def encode_categorical(self, name: str, series: pd.Series) -> np.ndarray:
        entry = self.features[name]
        vocab = entry["vocab"]
        out = np.full(len(series), entry["unk_index"], dtype=np.int64)
        values = series.astype("object")
        for i, v in enumerate(values):
            if v is None or (isinstance(v, float) and np.isnan(v)) or pd.isna(v):
                out[i] = entry["missing_index"]
            else:
                out[i] = vocab.get(str(v), entry["unk_index"])
        return out

    def standardize_continuous(self, name: str, series: pd.Series) -> np.ndarray:
        entry = self.features[name]
        s = pd.to_numeric(series, errors="coerce").fillna(entry["median"])
        return ((s - entry["mean"]) / entry["std"]).to_numpy(dtype=np.float32)

    # -- serialization ------------------------------------------------------
    def manifest(self) -> Dict:
        return {
            "artifact_version": self.artifact_version,
            "predictor_version": self.predictor_version,
            "created": self.created,
            "fit_files": self.fit_files,
            "features": sorted(self.features.keys()),
        }

    def save(self, base_path: str, filesystem=None) -> str:
        """Write ``manifest.json`` + one JSON per feature under ``base_path``.

        ``base_path`` should point at the artifact-version directory, e.g.
        ``s3://.../artifacts/1``. Returns the resolved base path.
        """
        opener, join = _resolve_io(base_path, filesystem)
        root = strip_scheme(base_path) if filesystem is not None else base_path
        with opener(join(root, "manifest.json"), "w") as f:
            json.dump(self.manifest(), f, indent=2)
        for name, entry in self.features.items():
            with opener(join(root, f"feature_{name}.json"), "w") as f:
                json.dump(entry, f, indent=2)
        return base_path

    @classmethod
    def load(cls, base_path: str, filesystem=None) -> "PreprocessingArtifacts":
        opener, join = _resolve_io(base_path, filesystem)
        root = strip_scheme(base_path) if filesystem is not None else base_path
        with opener(join(root, "manifest.json"), "r") as f:
            manifest = json.load(f)
        features: Dict[str, Dict] = {}
        for name in manifest["features"]:
            with opener(join(root, f"feature_{name}.json"), "r") as f:
                features[name] = json.load(f)
        return cls(
            artifact_version=manifest["artifact_version"],
            predictor_version=manifest.get("predictor_version"),
            features=features,
            fit_files=manifest.get("fit_files", []),
            created=manifest.get("created"),
        )


def _resolve_io(base_path: str, filesystem):
    """Return (open_fn, join_fn) for local or S3 IO."""
    if filesystem is not None and (base_path.startswith("s3://") or base_path.startswith("s3a://")):
        return filesystem.open, posixpath.join
    import os
    os.makedirs(base_path, exist_ok=True)
    return open, os.path.join
