# Paste into the new Copilot chat with `tab_fraud_reorg` open

This is my tabular fraud project: an FT-Transformer card-fraud model, trained on a GPU pod. I lost most of my local work files. While reorganizing the pod, I also moved, renamed and deleted many files there.

Your job is to work through everything in `tab_fraud_reorg`, reconcile it with ChatGPT and Claude's last known state, and write a complete current-state handoff. The handoff must tell them:
- exactly what is on the pod;
- where the code is and what each file does;
- what has been run and what results exist;
- what changed.

There are two parts. Part 1 is this reconciliation and its short report (`SEND.md`, section 5). Part 2 is the reorganization in `REORGANIZATION.md` (section 8): you apply it to my branch and make everything run. New experiments are separate later work. ChatGPT and Claude cannot see these files and will see only what you write, so the one file that goes out (`SEND.md`, section 5) must carry the essentials of the directory, runtime and code, and the detail files must hold the rest for their follow-up requests.

Do the work and write the files. Do not stop at a plan. Ask me questions whenever the files cannot answer something that matters: group the questions, say why each one matters, and keep working on everything else while I answer.

## 1. What is in `tab_fraud_reorg`

Find the real folder names and nesting. They may differ slightly from this list.

- `REORGANIZATION.md`: the final organization of the project, agreed with me: every move, rename, import, config and path change, plus the background you need. `RESULTS.md` and `EXPERIMENTS.md` go into `docs/` as part of it.
- `EXPECTED_STATE.md`: what ChatGPT and Claude think the pod looks like, item by item. Your report lists only the differences from it (section 5).
- `background/`: what the project is, who is involved, what the Confluence page says, and every communication with managers and the team, with what each one changed in our work. The original source texts are in `background/sources/`. Read this folder first.
- `changes_tracker/`: the record of every change made since Yaqun's handoff, plus a full project rundown. It is the map of what ChatGPT and Claude already know (see section 3).
- `pod_files/`: a complete copy of the pod, zipped and/or extracted. It includes `pod_reorg_20261027_v3.zip`.
- `prev_plan/`: files recovered from an earlier zip that got corrupted: my earlier notes, plans and chats. They show where I left off.
- `yaqun_handoff/`: Yaqun's original code. His `main` branch and his `yw_seq` branch are kept as separate copies.

Record when each snapshot was captured. Distinguish the laptop's current files, the pod snapshot and any later live-pod observations; record the time and source of each observation.

Extract every archive into its own folder under `tab_fraud_reorg/_work/`.

For the corrupted zip in `prev_plan`, recover every member you can: read it member by member with Python's `zipfile`, and use any repair tool on this laptop. List which members are damaged or missing.

Record duplicate member names, symbolic links, and case differences that matter between Windows and Linux paths. Keep a record of anything you recover, edit, move or rename, with the before and after paths.

## 2. The pod as we last knew it

The pod project root was `/home/jovyan/k194855/tabular_fraud`. Find the matching folder inside `pod_files` by its contents.

At our last record, before my deletions, the root held the following.

**Code**
- `waqas/`: my corrected copies:
  - `waqas/base/`: single-transaction model;
  - `waqas/phase4a/`: Arch A;
  - `waqas/phase4b/`: Arch B;
  - `waqas/v2/`: V2, installed by package 009 (including `waqas/v2/models.py`, `waqas/v2/scripts/train_v2.py`, `score_v2.py`, `select_splits.py`);
  - `waqas/source_identity.py`.
- `fraud/` and `src/`: Yaqun's code.
- `runbook/`, `tests/`, `docs/`.

**Install records and packages**
- `runs/install/009_20261021_180056_UTC_5ctj616u/INSTALLATION.json`: every file package 009 installed, with its SHA-256, and the hashes it observed for existing files.
- `.tf_install`, `tf_package` / `tf_packages`.
- `reviewer_packages/`: package zips and folders, including `reviewer_packages/10_21_2026_009/`.

**Pod patches**

The three training patch scripts were at the root:
- `patch_train_v2_sliding.py` changes `waqas/v2/scripts/train_v2.py`;
- `patch_target_ending_training.py` changes `waqas/v2/models.py`;
- `patch_chunk_training_route.py` also changes `waqas/v2/models.py`.

The split patch is `patches/patch_select_splits_ds_train.py`, which changes `waqas/v2/scripts/select_splits.py`. Patch receipts are under `runs/v2/patches/`.

**V1 results**
- the 15 V1 attempt folders under `ablations/`, plus retries and failed attempts;
- each run's `manual_score/`, `post_score/` and `results.csv`;
- `runs/run_log.csv`, `runs/returns/`, `runs/paired_report*`, `v1_analysis_outputs`.

**V2 results**
- `runs/v2/L3/`: `ALLPOS_H20_CHUNK`, `ALLPOS_H20_SLIDE`, `ALLPOS_H5_SLIDE`, their `allpos_*.yaml` configs, `scores_slide/`, `measure/`, `logs/`, `paired_*_followup`;
- `runs/v2/seed_robustness/`: `ALLPOS_H20_CHUNK_seed43`, `ALLPOS_H20_CHUNK_seed44`, `B_H20_seed43`, `B_H20_seed44`;
- `runs/v2/arch_a_scores_retry3/`, plus earlier `arch_a_scores` attempts;
- `runs/v2/step1/L2_selected`, `runs/v2/L2_inventory`, `runs/v2/data_look`, `runs/v2/step0`, `runs/v2/step0_logs`;
- `runs/v2/env.sh`;
- `runs/returns/quick_checks_<UTC>`;
- `waqas/scoring/allpos_sliding_h5/`.

**Hand-run scripts and other root files**
- hand-run scripts, at the root or under `runbook/`: `13_h20_sliding.py`, `seed_robustness.py`, `cpu_reads.sh`, `quick_checks.py`, `analysis_runs.py`, `h5_diagnostics.py`, `scale_runs.py`;
- `.out` and `.log` files at the root and under `runs/`;
- `test.yaml`.

**The reorganization tool**

`organize_pod.py` comes from `pod_reorg_20261027_v3.zip`. Unzipping that file at the root creates `tools/organize_pod.py`. The tool has three steps:
- `plan` writes `shared/reorg/PLAN.csv`, `HASHES.csv` and `REPORT.txt`;
- `apply` writes `shared/reorg/MOVES.csv` and creates `models/<model>/seed<NN>/`, `shared/`, `tools/` and `archive/`;
- `verify` checks the moves.

From those files and from the folders that exist, work out which steps ran.

**Two things to check**
- **Yaqun's files:** the package 009 install comparison reported that the pod's `fraud/` and `src/` match Yaqun's `main` and `yw_seq`, and that 10 `fraud/` and 48 `src/` files differ from the GitHub repository snapshot. Check this against `yaqun_handoff`.
- **Preprocessing artifacts:** every V1 and V2 run read preprocessing artifacts version 1 from my storage folder, while Yaqun's config names a different location. Record the artifact identifiers, and any comparison between my copy and his.

**What to report**

For every item above, report one of:
- still there at the same path;
- moved: say where to, and whether the bytes are the same;
- not found in the inspected collection; record confirmed deletion separately when evidence establishes it.

Then list everything in the snapshot that is not on this list.

## 3. What ChatGPT and Claude already know

`changes_tracker/` describes what ChatGPT and Claude already know: Yaqun's code, my corrected copies, package 009, the four pod patches, and every run up to the seed study. Read `CHANGES_FROM_HANDOFF.md` and `CHANGE_REGISTER.csv` first if they are there: they list every substantive change since Yaqun's handoff, with the source path and version of each. Use the tracker two ways:
- **Check it.** For each change and result it lists, confirm it against the files or correct it, giving the file and line.
- **Spend your detail on what it does not cover:** files, code, runs and results that are new or different.

## 4. What to find out

### 4.1 Every file

Walk the whole pod snapshot, including hidden files. For each file record:
- path;
- size;
- modified time;
- SHA-256 (in full in `detail/FILES.md`);
- a one-line role.

For folders with many similar files (score shards, prediction parts, logs), give the folder, the file count, the total size and the naming pattern. Then list individually the files that matter: configs, manifests, receipts, metrics, `best.ckpt`, `last.ckpt`.

Find identical copies by hash, even when their names differ.

### 4.2 Code

This covers every code or config file: `.py`, `.sh`, `.yaml`, `.yml`, `.json` configs, `.toml`, `.cfg`, requirements files and notebooks.

1. **Compare it with every known version:**
   - Yaqun's `main` and `yw_seq` copies in `yaqun_handoff`;
   - the hashes in package 009's `INSTALLATION.json`;
   - the package zips and folders in `reviewer_packages/`;
   - the patch scripts and their receipts.
2. **Say which case it is:**
   - identical to a known version (name it);
   - a known version plus a pod patch (name the patch);
   - different from every known version: write the unified diff against the closest one into `detail/CODE.md`;
   - new: write the full file into `detail/CODE.md`.
3. **Say whether it is used:** what imports or launches each copy, which config it reads, and what outputs it writes. Identify the active copy from observed launch/runtime evidence; otherwise mark the choice inferred or unresolved.

Check two copies in particular, and say which entry points use them:
- `waqas/base/data/sequence_builder.py`, which lacks the strict same-second rule;
- `waqas/base/scripts/score_eval.py`, which can overwrite predictions.

For notebooks, put every code cell in full into `detail/CODE.md` and summarize the outputs.

### 4.3 How things run

Trace each chain: command, then working directory and environment, imports, config, preprocessing artifacts, checkpoint, scoring, analysis and downstream outputs.

For each entry point (training, scoring, analysis, export, the hand-run scripts, the patches), give:
- the command that was actually used, from logs, receipts, launch configs, shell history (`.bash_history`) or `nohup.out`;
- the working directory;
- the Python environment;
- the config it reads;
- what it writes, and where.

Mark each command as observed (seen in a file) or reconstructed. Separate commands that actually ran from commands merely written in a plan. Connect each observed launch to its resolved code paths, config, artifacts and outputs.

For anything reported as currently running, give the observation time, process or job identifier, command, working directory, resolved script/environment and output/log location. Where current process evidence is unavailable, say that its live status is unknown and collect it through section 6.

List every hardcoded path or path-like reference in code, configs, `env.sh`, manifests and receipts, with file and line. Search for `/home/jovyan`, `k194855`, `s3://`, `runs/`, `ablations/`, `models/`, `shared/`, `.ckpt` and `.parquet`. For each reference, say whether it still points at something in the snapshot.

Record the Python version and the installed packages with their versions. Sources: dated `pip freeze` output, environment files and install receipts; distinguish packages observed installed from dependencies merely declared in `requirements*.txt`.

### 4.4 Models and runs

Give one block per model and seed, using our names (see the glossary in section 7). Each block covers:
- where its folder is now;
- `best.ckpt` and `last.ckpt`, with size and hash;
- the as-run config, resolved config, run manifest, training metrics and logs;
- every score receipt and prediction file: the population (Test 1/DEV_OOT, SELECT, holdout, FINAL), the checkpoint it names (path and hash inside the receipt), and the AP and AUROC it reports;
- its status: complete, failed, killed or partial.

Expected models:
- **V1, seed 42:**
  - REF-SINGLE;
  - Arch A H0, H5, H10, H15, H20;
  - A-H5 and A-H10 without the time gap;
  - A-H5 causal;
  - Arch B H0, H5, H10, H15, H20 (sliding);
  - the first chunk model, ALLPOS-H5, with its later sliding rescore in `waqas/scoring/allpos_sliding_h5/`.
- **V2 L3, seed 42:**
  - ALLPOS-H20-CHUNK, which is Arch B H20 chunk, the chosen model;
  - ALLPOS-H20-SLIDE;
  - ALLPOS-H5-SLIDE.
- **Seed study:** Arch B H20 chunk and B-H20, at seeds 43 and 44.

Report any other runs you find. Also cover feature screens, optimizer or capacity runs, embedding export, downstream models and the vector store, at whatever stage each reached.

B-H15 and B-H20 were scored by hand. Their receipts are under each run's `manual_score/`; B-H20's presented 0.0955 is `manual_score/20261013T142910Z/`. For each, say whether the receipt's `checkpoint_sha256` matches that run folder's `best.ckpt`.

Also list the shared results:
- population files (the L2 selected splits and the file inventory);
- window and chunk measurements;
- paired comparisons;
- the Arch A rescore table;
- data looks;
- quick checks;
- logs.

### 4.5 What changed during my reorganization

Use `shared/reorg/` if it exists, the expected items in section 2, and any other evidence. For each old path, give one of:
- its new path, with same bytes or different bytes;
- a likely match, with your confidence;
- not found in the inspected collection; record confirmed deletion separately when evidence establishes it.

Follow chains of moves. For anything not found at its expected path, say whether a copy exists anywhere else in `tab_fraud_reorg`: another snapshot, a package zip, `prev_plan` or `changes_tracker`.

### 4.6 Where I left off

From `prev_plan`, find:
- what I was doing;
- what my last plan was;
- which of its steps were done.

Put the full text of the latest plan documents in `detail/PLAN.md`, and a short summary in `SEND.md`.

## 5. The handoff

I copy the handoff to ChatGPT and Claude by hand, page by page, from this laptop. So **only one short file goes out**, and everything else stays here so that they can ask for specific parts later.

### What goes out: `handoff/SEND.md`

`EXPECTED_STATE.md` in `tab_fraud_reorg` is what ChatGPT and Claude think the pod looks like, with an ID on every item. Compare everything you found with it, and write `SEND.md` as **differences only**, following the "How to answer" section at the end of `EXPECTED_STATE.md`:

1. **Changed items:** one line per ID that is not as expected (moved to where, not found, different and how, or partly there). Matching items get no line. Then one line counting how many matched exactly.
2. **New items:** anything not on the list, at folder level, with size, file count and a one-line role. Name individual files only for code, configs and receipts.
3. **Code differences:** path, closest known version, which functions changed. A diff only if 10 lines or fewer.
4. **Moves:** old path to new path at folder level, same or different bytes.
5. **Questions,** each with why it matters.

**Limits:** at most 300 lines, each at most 90 characters, with a line `--- page N of T ---` every 40 lines. Tables at most 4 columns. No hashes and no full source code in `SEND.md`.

### What stays on this laptop: `handoff/detail/`

These are for answering later requests. They are not sent, so they can be as long as they need to be:
- `detail/FILES.md`: every file, with path, size, date, hash, role and ID;
- `detail/CODE.md`: for every C item, the full text of new files and complete unified diffs for changed files, with the baseline (collection, branch or package, path) and line endings. Use code fences longer than any run of backticks inside the file;
- `detail/MODELS.md`: the full model and run blocks from 4.4;
- `detail/PLAN.md`: the full text of the latest plans from `prev_plan`;
- `detail/NOTES.md`: everything else you found that did not fit in `SEND.md`.

When I later paste a request from ChatGPT or Claude, such as "show C07" or "show M12", answer with just that item from the detail files, kept as short as the request allows.

### Format for everything

- one fact per line;
- each fact marked as seen in a file (name the file) or inferred.

## 6. Anything the snapshot cannot answer

Some things the handoff needs may not be in `pod_files`, for example files newer than the snapshot, or the pod's installed package list. In that case:
1. Write me one current-state collection script I can run on the pod that writes the missing directory/runtime/environment evidence and observation time to one text file.
2. Give me the exact commands.
3. Tell me which file to send back.

When I return it, reconcile those dated live observations with the snapshot and fold the differences into the same handoff.

## 7. Glossary (use these names)

- **Yaqun:** the original author. His code is `fraud/` and `src/`.
- **REF-SINGLE:** the single-transaction reference model.
- **Arch A** is the flat history model (`waqas/phase4a`). **Arch B** is the hierarchical history model (`waqas/phase4b`). **H<n>** means a history of n earlier time points.
- **All-position B (ALLPOS):** every transaction in a chunk is a target.
  - **CHUNK:** trained on non-overlapping chunks.
  - **SLIDE:** trained on one window per transaction, ending at that transaction.
- **Arch B H20 chunk:** the chosen model (ALLPOS-H20-CHUNK).
- **Arch B H20 sliding:** the V1 reference model, B-H20.
- **V1:** the 15-run architecture study.
- **V2:** the package 009 code and its runs: L2 populations, L3 fits and the seed study.
- **Populations:**
  - training: files 1-10;
  - validation: files 4950-4954;
  - Test 1: evaluation files 8000-8010, also called DEV_OOT;
  - SELECT: June, files 8206-8216;
  - FINAL: files 8260-8277, kept unscored;
  - DS_TRAIN (files 4001-4010) and DS_SELECT: populations for the downstream models;
  - Test 2: the TFM V22B evaluation transactions.
- **Package 009:** the V2 install. **Package 010:** the next package, not built yet.

Where the files use a name differently, say so and give its actual meaning.

## 8. Part 2: apply `REORGANIZATION.md`

After `SEND.md` is written, apply `REORGANIZATION.md` to my branch exactly as it says: move and rename the files, update every import, config, input and output path and entry point, put the results into `models/`, move superseded material to `archive/`, and make every kept entry point run. Keep model, training and scoring behaviour exactly as trained. Where the file you find differs from what `REORGANIZATION.md` expects, follow the actual working file and note it. When done, write `handoff/REORG_REPORT.md` in the format `REORGANIZATION.md` gives (at most 60 lines, paged).

## 9. Finish

Keep `SEND.md` and the detail files up to date as you go, so the work survives if this chat runs out of context, and pick up from the files.

Before you finish, check four things:
- every file in the snapshot is in `detail/FILES.md`;
- every expected item has a status;
- every model and seed has a line;
- `SEND.md` is 300 lines or fewer, with lines of at most 90 characters.

Then tell me, in plain language:
- what you found;
- what is uncertain;
- the questions you need answered;
- how many pages `SEND.md` has.

Start now: open `tab_fraud_reorg`, list the collections, and go.
