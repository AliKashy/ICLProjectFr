# COPILOT_UPLOAD: what this is and where it goes

This folder is everything the new Copilot chat needs from GitHub. Unzip it into `tab_fraud_reorg` on the work laptop.

## Steps

1. Download `11_01_2026/COPILOT_UPLOAD.zip` from GitHub repo `AliKashy/tabular_fraud`, branch `main`: open the file and click "Download raw file".
2. Right-click the zip, choose "Extract All", and set the destination to your `tab_fraud_reorg` folder itself (delete the `COPILOT_UPLOAD` folder name Windows adds to the path). The result should look like this:

```
tab_fraud_reorg/
  COPILOT_PROMPT.md          paste its full text into Copilot chat as the first message
  README.md                  this file
  background/
    BACKGROUND.md            the project, people, data, Yaqun's handoff, timeline, Confluence
    COMMUNICATIONS.md        every work communication with managers, colleagues and other teams, and what each changed
    sources/                 the original texts behind both files
  changes_tracker/
    CHANGES_FROM_HANDOFF.md  every substantive change since Yaqun's handoff (C01 to C26)
    CHANGE_REGISTER.csv      source path and version for each change
    CL_CORRECTIONS.md        evidence for the later additions to the change list
    PROJECT_RUNDOWN.md       models, experiments, results, features, research and downstream work
  pod_files/                 add yourself: the full pod zip and pod_reorg_20261027_v3.zip
  prev_plan/                 add yourself: the corrupted zip and anything recovered from it
  yaqun_handoff/
    main/                    add yourself: Yaqun's main branch, untouched
    yw_seq/                  add yourself: Yaqun's yw_seq branch, untouched
```

3. Open `tab_fraud_reorg` in VS Code, switch Copilot chat to Agent mode, and paste the full text of `COPILOT_PROMPT.md`.
4. Copilot writes `handoff/HANDOFF.md`, `handoff/HANDOFF_FILES.md` and `handoff/HANDOFF_CODE.md` (split into numbered parts if long). Send those to ChatGPT and Claude.

## What is in `background/sources/`

Every file that `BACKGROUND.md` and `COMMUNICATIONS.md` cite is copied here at its original path, so a reference such as `bridge/OWNER_QA.md:1840` opens `background/sources/tabular_fraud/bridge/OWNER_QA.md` at line 1840. A reference that starts with `MRM_1/` opens under `background/sources/MRM_1/`.

What kind of text each source is:
- **Original records:** the Confluence page (`MRM_1/confluence/Foundation Model for Fraud`), Sumegha's raw-data email thread, and Xiaoming's 12 October feature-engineering email. The Xiaoming file also contains later Copilot discussions, which are not Xiaoming's words, and Jie Chen's reply as relayed by the owner.
- **Owner record:** `bridge/OWNER_QA.md`, the owner's recorded answers and directions, cited for facts and for what the owner relayed from managers and colleagues.
- **Notes and summaries written at the time:** the 5 and 6 October meeting notes, the 14 and 15 October updates (which summarize the raw-data, replication, decision-model, feature and Nengfeng discussions where the originals were not supplied), and the partial TFM V22B communication register.
- **Project records and plans:** the decision record (`bridge/DECISIONS.md`), the weekly update of 26 October, roadmaps, explainer chapters and guides. They are the assistants' records, not messages from managers.
- **Yaqun's design documents** (`docs/*.md`) and the configs cited from `fraud/`: the same files are in `yaqun_handoff/main/` and `yaqun_handoff/yw_seq/`. The copies here exist only so the references open.
