# Experiments

Every study run since the handoff: why it was run, what it contained, what it showed and what was decided. Scores are average precision (AP) on Test 1 (files 8000 to 8010) unless marked. `docs/RESULTS.md` has the short score summary.

Each run is trained with a base config from `fraud/configs/` plus command-line overrides, the way the original scripts work. The "Command" column gives the exact overrides; the full settings each run used are in `models/<name>/seed<NN>/config.yaml`.

Base configs: `streaming.yaml`, `sequential.yaml`, `sequential_hier.yaml`, `sequential_hier_allpos.yaml`.

## 1. History length and architecture

**Why:** to test whether reading the account's earlier transactions beats scoring one transaction alone, how much history helps, and whether the hierarchical model beats the flat one.

**Setup:** training files 1 to 10, validation 4950 to 4954, Test 1, seed 42, one run per model. The epoch is chosen on validation AP.

| Run (models/...) | What differs | AP | Command |
|---|---|---:|---|
| streaming | single transaction | 0.0925 | (to fill) |
| sequential_h0 | flat, no history | 0.0816 | (to fill) |
| sequential_h5 | flat, history 5 | 0.0728 | (to fill) |
| sequential_h10 | flat, history 10 | 0.0824 | (to fill) |
| sequential_h15 | flat, history 15 | 0.0928 | (to fill) |
| sequential_h20 | flat, history 20 | 0.0817 | (to fill) |
| sequential_h5_no_time_gap | flat, history 5, no time-gap input | 0.0767 | (to fill) |
| sequential_h10_no_time_gap | flat, history 10, no time-gap input | 0.0808 | (to fill) |
| sequential_h5_causal | flat, history 5, causal attention | 0.0779 | (to fill) |
| sequential_hier_h0 | hierarchical, no history | 0.0822 | (to fill) |
| sequential_hier_h5 | hierarchical, history 5 | 0.0674 | (to fill) |
| sequential_hier_h10 | hierarchical, history 10 | 0.0904 | (to fill) |
| sequential_hier_h15 | hierarchical, history 15 | 0.0955 | (to fill) |
| sequential_hier_h20 | hierarchical, history 20 | 0.0955 | (to fill) |
| sequential_hier_allpos_h5_chunk | all-position, history 5, trained and scored on chunks | 0.0927 | (to fill) |

**Showed:** from history 5 up, more history helped: the flat model was best at 15 and dropped again at 20; the hierarchical model was best at 15 and 20. The best history models beat the single-transaction model, but by less than the account-level uncertainty, and one seed per model. History 5 did worst in both families. sequential_hier_h15 and sequential_hier_h20 were scored by hand after training.

**Decided:** keep the hierarchical model and study how it is trained.

## 2. Chunk against sliding training

**Why:** the all-position model can train on non-overlapping chunks (every transaction in a chunk is a target) or on one window per transaction (sliding). The first chunk model was scored on chunks; this study trained both ways and scored both the same way, on one window per transaction.

**Setup:** as study 1, seed 42. Scored on Test 1 and on SELECT (files 8206 to 8216, June targets only, 1,215,218 rows, 2,081 frauds). Window cap 32 rows at history 20 and 8 at history 5.

| Run (models/...) | What differs | Test 1 | SELECT | Command |
|---|---|---:|---:|---|
| sequential_hier_allpos_h20_chunk | history 20, chunk training | 0.1020 | 0.1103 | (to fill) |
| sequential_hier_allpos_h20_sliding | history 20, sliding training | 0.0743 | 0.0615 | (to fill) |
| sequential_hier_allpos_h5_sliding | history 5, sliding training | 0.0866 | 0.0923 | (to fill) |

**Showed:** at history 20, chunk training beat sliding training by +0.0277 on Test 1 (95% interval +0.0170 to +0.0384) and +0.0488 on SELECT, on the same transactions. Against sequential_hier_h20 the chunk model was +0.0065 on Test 1, inside the uncertainty, and its AUROC was lower (0.9431 against 0.9520).

**Decided:** sequential_hier_allpos_h20_chunk is the chosen model; sequential_hier_h20 is the reference.

## 3. Seed check

**Why:** to see whether the chosen model's lead over the reference holds with other random seeds.

| Run (models/...) | Seed | Test 1 | Command |
|---|---|---:|---|
| sequential_hier_allpos_h20_chunk | 43 | 0.0912 | (to fill) |
| sequential_hier_allpos_h20_chunk | 44 | 0.1013 | (to fill) |
| sequential_hier_h20 | 43 | 0.0743 | (to fill) |
| sequential_hier_h20 | 44 | 0.0753 | (to fill) |

With seed 42: chosen model mean 0.0982 (standard deviation 0.0061), reference mean 0.0817 (0.0120). The chosen model is ahead at all three seeds. Seeds 43 and 44 were scored on full SELECT files, seed 42 on June targets only, so SELECT is compared within a seed only.

**Decided:** the study is closed; the chosen model stands.

## 4. Rescoring the flat models

**Why:** to put all eight flat models on the same footing as the later runs, with no new training.

**What:** each sequential_* checkpoint from study 1 scored on validation, Test 1 and full SELECT files: 8 models x 3 populations = 24 rows, in `comparisons/sequential_rescore.csv`. Test 1 matches study 1. On SELECT (full files) sequential_h15 is best at 0.0968.

## 5. Not run yet

| Work | Code, after the reorganization | Status |
|---|---|---|
| Hyperparameter tuning of the chosen model | `fraud/experiments/tuning/` | never run; recipe so far fixed |
| New features (TFM V32B, 15298 model, month removed) | `fraud/experiments/features/` | feature code and screen built, not run |
| Training on 100 files | `fraud/experiments/scale/` | configs built, not run |
| Embedding export, check, 15298 offset model, TFM comparison | `fraud/experiments/embedding/` | export and checks built, offset model and TFM comparison not built |

Order set by Waqas: reproduce the chosen model from the organized code, tune, new features, 100 files, then the embedding work.
