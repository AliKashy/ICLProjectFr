# Changes from Yaqun's handoff — context for recovering the working project

Prepared 1 November 2026. Put this document and `CHANGE_REGISTER.csv` in the changes-tracker collection inside `tab_fraud_reorg`, and use them with the recovery prompt. The register supplies exact source paths, versions and evidence links for the changes below.

**Purpose:** explain the substantive changes to data handling, model behavior, training, scoring and analysis so Copilot can identify and preserve the right implementation. This is the reviewed project history, not proof that the current pod still contains every listed file. Copilot must reconcile it with the available pod snapshot and the separately supplied untouched `main` and `yw_seq` handoffs.

## What remains the foundation

Yaqun supplied the original fraud task, feature definitions, preprocessing, single-transaction FT-Transformer, flat history-model starting point and research guide. His starting workflow already included validation. We should not describe validation as something entirely absent that we subsequently introduced.

The reported V1 and later architecture/seed fits retained the original **23 predictors: six continuous and seventeen categorical**, with preprocessing-derived missingness indicators and the separately configured history time gap. Those are different categories of input and should not be combined into an unexplained feature count. The version-1 preprocessing artifacts used by the retained fits remain part of their identity. Their equality with Yaqun's artifact contents has not been established in the reviewed evidence.

The corrected implementation is mainly under `waqas/`, with orchestration/analysis support under `runbook/`. It still imports shared components from `fraud/` and `src/`. An old-looking shared folder is therefore not automatically unused. A model extension or a correction to our added code must not be attributed indiscriminately to a defect in Yaqun's original work.

## 1. Corrections affecting what the model learns

**C01 — File coverage across data-loader workers.** The earlier shuffle-before-partition implementation could assign the same file to multiple workers and omit another. The reference loader now partitions first and shuffles within each worker's portion; the A/B loaders use one shared shuffled order before partitioning. This fixes data coverage, not a measured amount of model improvement. The often-quoted approximately 32% omission is an expectation under independent worker shuffles, not an observed percentage for every historical run.

**C02 — Strict chronological history.** History is ordered by parsed timestamps and restricted to the same account's strictly earlier transactions. A row with the same timestamp cannot enter history just because its ID sorts earlier. The `tiebreak` alternative is a different explicit policy. Keep the distinction between exact timestamp comparison and whole-second grouping used for strict all-position chunk boundaries: a strictly earlier subsecond timestamp is not universally forbidden just because it falls in the same second.

**C03 — Invalid targets and identity/time inputs.** Missing labels no longer silently become non-fraud. Missing account IDs, missing/unparseable timestamps and ambiguous numeric time units are checked; timezone consistency is addressed explicitly. This does not validate every possible label value: nonmissing labels still map to the configured positive label versus other values. Missing predictor handling remains part of preprocessing.

**C04 — Calendar-feature construction and missing-value flags.** The earlier loader built missing-value flags before deriving time features. With cyclical continuous predictors and flags enabled, this produced `KeyError('hour_sin')`. The corrected base loader derives time columns first, then builds their flags. History builders also derive the time fields requested by the feature definitions. These are concrete ordering/feature-construction fixes.

**C05 — Causal attention through the summary token.** In causal mode, an earlier transaction representation can no longer read the sequence summary/CLS token, which can already contain later information from a preceding layer. That closes a route around the causal mask from the second layer onward. It is not evidence of label leakage or that every final-target prediction saw transactions after its target.

**C06 — Padding after the causal-mask correction.** Mask handling leaves a finite attention route for padded query positions while excluding padding from useful context and targets. This prevents invalid numeric outputs in short padded histories. It does not turn padding into real observations.

## 2. Model capabilities and learning behavior we added or made explicit

**C07 — Hierarchical Architecture B.** Architecture A processes feature tokens across the transaction window in a flat structure. B first encodes the features within each transaction, then models relationships between transaction summaries. Default B produces one target score per window. This is a model extension, not merely a repaired copy of the original flat model.

**C08 — All-position B and its information contract.** This added a causal score for every real transaction in a disjoint training chunk. Each real transaction contributes one target within that layout; padding contributes none. The time gap uses the latest strictly earlier timestamp in the chunk, rather than a later transaction. Position encoding respects the strict-time policy. Default B's history is up to H prior rows; strict all-position chunks group up to H+1 distinct whole seconds and can contain more rows. Context resets at chunk boundaries. These are materially different learning setups.

**C09 — Loss and target accounting.** All-position loss sums weighted cross-entropy over real targets and divides by their count; epoch aggregation also accounts for real targets. At fraud weight 1 this is ordinary transaction-average cross-entropy. At other weights its normalization differs from default B's class-weight-normalized mean. Do not call the two losses identical solely because their configured fraud weight matches.

**C10 — One-device training, microbatching, accumulation and width limits.** Each corrected training job pins `devices=1` and rejects a distributed launch with `WORLD_SIZE > 1`, because the iterable data is not partitioned across training ranks. This applies to base streaming/history and A/B trainers; it does not reject a machine merely because other devices are available. Actual batch size and gradient accumulation became explicit recipe settings. A nominal batch of 4096 obtained as 1024×4 or 2048×2 does not prove identical optimization. Record loss normalization and actual target counts too. The chunk-width cap rejects oversized chunks; the V2 target-window cap deliberately trims context. They must not be conflated. The batch-times-width check is a separate execution constraint.

**C11 — Model construction when scoring weighted models.** The scorer reconstructs the configured fraud weight when loading the model. This prevents training/scoring construction mismatches; it does not demonstrate that weighting improves fraud ranking.

**C12 — Checkpoint/input identity.** New checkpoints record feature order, preprocessing identity, prediction mode and history semantics. A shape-compatible but semantically incompatible scoring setup can then be detected. Legacy single-target A/B checkpoints have warning-based paths with reduced identity verification; incompatible/uncontracted all-position checkpoints are refused. The base **sequential/history** copy, `waqas/base/sequential_model.py`, separately refuses causal checkpoints lacking the corrected `transaction_causal_cls_sink_padding_v1` mask contract. This is distinct from the single-transaction model and from the A/B legacy-loading paths.

**C13 — Optional averaged weights.** The EMA lifecycle was corrected so averaging follows optimizer updates, validation/scoring use the intended weights, and raw/shadow state is retained for supported resume paths. EMA was off in the documented V1 configurations, and the V2 trainer excludes it. This is implemented optional functionality, not an explanation for the reported V1 gains.

## 3. Changes making experiments and results interpretable

**C14 — Metrics from the same saved model.** AP and AUROC are paired from the selected checkpoint's epoch/step instead of independently taking each metric's best value from different epochs. The V1 selection leaderboard uses validation AP. Later descriptive evaluation tables are separate from checkpoint selection.

**C15 — Prediction destinations, checkpoint hashes and failure records.** Sweeps previously reused prediction destinations; corrected sweep runs have separate prediction paths. A/B scorers generate run-specific objects. The corrected base streaming and sequential scorers refuse an existing destination and stop on empty, non-finite or out-of-range scores. The separate base `score_eval.py` still has the older overwrite behavior, as noted below. Successfully scored sweep runs write a metrics sidecar carrying `checkpoint_sha256`; standalone scoring calls that omit the optional metrics destination and failed fits are not covered by a claim that every invocation writes it. Attempts have distinct outputs and source/config/checkpoint identities. Scoring and export record the population, policy and attempt status, including failure paths. Returned diagnostics include the logs/settings needed to diagnose a failed attempt. A failed attempt must not be counted as a completed fitted model, and rescoring is not retraining.

**C16 — Matched reference and declared populations.** The single-transaction reference was made constructible against the bundled library and rerun through the corrected owner code. It is a new comparison run, not automatically Yaqun's historical result. Yaqun's streaming/reference config already validated on 4950–4954, but his history-model config used **4950 only**. The actual V1 A/B experiment specifications expanded history-model validation to **4950–4954**; some generic A/B default configs still specify 4950 only. V1 evaluation expanded to 8000–8010. A comparison must use matching target populations, and more files do not by themselves mean a later time period.

**C17 — Target-ending validation and scoring.** V2 gives each target its own window ending at that transaction. A chunk-trained model can therefore be validated and scored with target-ending history, instead of getting less context near a disjoint chunk's beginning. The checkpoint records the validation policy and cap. This is the studied hybrid: chunk training with target-ending validation/scoring. It is not a feedback loop using earlier predicted fraud scores. V1 exploratory rescoring and a V2 checkpoint selected under this validation policy are distinct experiments.

**C18 — Resume under a compatible recipe.** V2 adds continuation from the last completed epoch with model, optimizer, scheduler, loop and random state, including handling of the deferred plateau-scheduler step. Configuration/source/input compatibility is checked. This is not arbitrary recovery from any point inside a batch or a guarantee of identical results across all environments.

**C19 — Sliding training added on the pod.** A later reported patch to `waqas/v2/scripts/train_v2.py` chooses `TargetEndingBuilder` during training when `sequence.train_target_ending=true`, retaining the original builder for chunk training. This is separate from the target-ending validation/scoring capability already shipped in package 009.

**C20 — Loss routing for the two training layouts.** Two reported patches to `waqas/v2/models.py` add loss at the single labelled target of each target-ending training window and then ensure fully labelled chunk batches still use the original all-position chunk training step. Keeping both changes is essential; the target-only addition by itself is not the final working behavior.

**C21 — Inventory-backed data roles and the downstream split correction.** Data inventory and split tools make the train/validation/selection/downstream/final roles explicit and preserve eligible history before filtering target dates. The pod's reported split-tool change uses an available downstream training range; the delivered selection was 4001–4010 because the originally proposed 5001–7999 range was unavailable. Do not turn that selected range into a claim that the tool permits only that block. FINAL inventory counts are not FINAL model results.

**C22 — Comparable and qualified statistical analysis.** Comparisons align transaction/account keys and labels, reject mismatched populations, and use paired account resampling to preserve within-account dependence. History-depth/time slices and business metrics were added. A conditional account interval does not include all training-seed uncertainty; mean AP across seeds is not an ensemble model. Full-file and June-only AP must remain separately labeled.

## 4. Feature and downstream work beyond the original model

**C23 — Separate preprocessing versions for changed features.** A no-month artifact wrapper/checker was implemented to create a new artifact version without overwriting the existing one. That protection belongs to this wrapper, not every original preprocessing command. The planned standalone no-month experiment was later declined. The current direction is to remove month in the next expanded-feature version while retaining time gap, hour, day of week and day of month. Existing reported fits still used the original month-in inputs; an implemented builder is not evidence that those fits used it.

**C24 — Feature engineering and screening.** Added strictly prior per-account feature primitives and candidate groups for velocity, spend/limits, familiarity, recency and geography, plus screening tools and source-feature mappings. These are implemented/proposed components with different completion states. The broader pool of 166 proposed additions is not a completed expanded-feature model or a measured lift. Imported feature importance does not establish incremental value. Preserve complete eligible histories when sampling accounts or targets.

**C25 — Embedding export and downstream comparison.** V2 can export the vector immediately before the fraud head, together with the score and identity/window metadata, without requiring labels. Head reconstruction checks connect the vector to the reported score. Downstream tools compare raw inputs, raw+score, raw+vector and raw+score+vector, with train-fitted transforms, and align incumbent benchmarks on matching targets. These capabilities shipped in 009; reviewed records do not establish completed downstream gains.

**C26 — Versioned vector-store candidate.** A separate implementation supports immutable snapshots, earlier-time lookup, refresh/backfill checks and rollback. It was tested as a private candidate, not established as installed by package 009. Its old next-14-day account consumer was withdrawn. Current downstream directions are transaction-level vector usefulness, a 15298-score offset consumer, and comparison with TFM representations/scores. Those directions must not be mistaken for completed results or fully implemented replacement consumers.

## 5. What actually ran

The reviewed retained studies contain **15 V1 fits, three later seed-42 architecture/window fits, and four additional seed-43/44 fits: 22 retained fits in that documented set**. Earlier exploratory runs and failed attempts are separate; this is not a lifetime count or 22 distinct architectures. Existing checkpoints were also rescored on additional policies/populations.

Those studies cover the single-transaction reference, A/default-B histories 0/5/10/15/20, time-gap/attention controls, all-position B, chunk-versus-sliding training, and repeated seeds. The owner selected **all-position H20 chunk training with target-ending validation/scoring**, retaining default B-H20 as a comparator. The repeat-seed study is closed.

Feature expansion and recipe research—including optimization, capacity, numerical encoding, loss and sampling alternatives—produced plans and some implementation. They are not a completed exhaustive sweep. Larger-data fits, demonstrated downstream improvement and final production evidence remain separate unfinished work. Phase 5 remains parked. The broader [Request 1 rundown](PROJECT_RUNDOWN.md) retains the detailed results/research inventory; this companion focuses on the changes needed to interpret and recover the implementation.

## 6. The versions Copilot must keep separate

| Evidence layer | How to use it |
|---|---|
| Supplied untouched `main` and `yw_seq` | The returned installation comparison reports equality with the original dependencies on the pod. Reconcile the recovered files against the appropriate branch and recorded comparison. |
| Repository source at `d711d92` | The inspected reference for this documentary comparison. It is not a byte-identical substitute for the native original dependencies: the returned comparison lists 10 `fraud/` and 48 `src/` differences. |
| Package 009 source `60232e9`; inspected V2 integration `dda4d4a` | Reconstruct the shipped V2 starting behavior; these are different source identities even where files match. |
| Reported pod changes after 009 | Recover the modified `train_v2.py`, `models.py`, `select_splits.py`, helper/config-generating scripts and patch receipts. They are not silently included in the unpatched package source. |
| Current pod snapshot and renamed locations | Establish which bytes and paths actually survived. A historical path in this document is a lookup lead, not proof the file is still there. |
| Private candidate branches | Identify useful code separately from what was shipped or installed. |

The returned patch records contain conflicting hash strings for `train_v2.py` and an intermediate `models.py` version. The native file bytes and receipts must settle that; copying one reported hash into a new manifest would not verify it. The reported final `models.py` identity beginning `6134ccc3` is also a lookup lead until checked against the recovered file.

For all-position windows, retain the configured cap and policy from each run. The reported H5 sliding cap was 8; H20 sliding used 32. Neither is a universal cap for every model. Record source/checkpoint/config/artifact relationships when locating renamed files.

## 7. Which copies remain different, and what is still unresolved

### Two owner copies that lag behind the active implementations

- `waqas/base/data/sequence_builder.py` sorts parsed timestamps but constructs history by preceding row positions. It lacks the strict timestamp-exclusion rule in the phase4a/phase4b builders, so an equal-time peer can enter its history.
- `waqas/base/scripts/score_eval.py` still writes directly to its configured destination and can overwrite predictions. The existence/score checks described in C15 belong to the corrected streaming/sequential scorer paths, not this file.

Copilot should trace actual entry points and imports so these differences appear in the recovered execution map.

### Remaining findings in the inspected source

These findings remain in the inspected repository files. The native dependencies differ in places, so their status in the recovered original/pod copies must be established from those files.

| Finding | What the evidence establishes | File |
|---|---|---|
| Training-loss logging | The shared metrics callback records training loss at validation-epoch end before the training-epoch reduction. An existing reproduction obtained the last minibatch loss rather than the epoch mean. This concerns the logged training-loss column, not proof that validation AP/AUROC or checkpoint selection are invalid. Inspected A/B/reference trainers still use the callback; V2's subclass adds resume handling. | `fraud/callbacks.py`; `waqas/v2/scripts/train_v2.py` |
| Baseline save removes metrics | In the inspected baseline path, the metrics CSV sits inside the model-save directory; the library's `save_model` clears that directory before serialization. This does not describe every trainer. | `fraud/scripts/train_baseline.py`; `src/pytorch_tabular/tabular_model.py` |
| TLS verification disabled | The shared S3 helper passes `verify=False`. | `fraud/data/s3_utils.py` |
| Checkpoint-loading compatibility | The vendored baseline loader omits an explicit `weights_only` argument and has a reproduced compatibility failure with modern PyTorch for its configuration-bearing checkpoints. The custom streaming/history scorers already specify `weights_only=False`. | `src/pytorch_tabular/utils/python_utils.py` |
| Slow categorical encoding | Encoding loops over each value of each categorical column in Python. This is a performance bottleneck/opportunity, not evidence that the encoded values are incorrect or a measured current slowdown. | `fraud/data/preprocessing.py` |

### Native original files and artifact identity

The returned installation comparison reports that the pod's original dependencies matched the local mirror and Yaqun's supplied `main`/`yw_seq` copies, while **10 `fraud/` and 48 `src/` files differed from the repository snapshot**. The ten `fraud/` paths are `callbacks.py`, `data/parquet_loader.py`, `data/preprocessing.py`, `data/sequence_builder.py`, `scripts/check_pid.sh`, `scripts/score_sequential.py`, `scripts/train_baseline.py`, `scripts/train_streaming.py`, `sequential_model.py` and `streaming_model.py`. This is a recorded comparison from that installation, not a fresh check of the files after subsequent moves or deletions.

The reported fits read **artifact version 1 from the owner's storage folder**. The original configuration names a different original-author storage location. The reviewed evidence does not establish equal artifact contents; identical version numbers do not establish identical vocabularies, category mappings or scaling statistics. Copilot should record the actual artifact identifiers and any comparison receipts it finds.

Exact supporting paths and line references for these additions are in [additional evidence](CL_CORRECTIONS.md).

## 8. How Copilot should use this companion

1. Match every relevant register entry to the original handoff and recovered/current implementation. Record confirmed, absent, different or unresolved status with file hashes and exact paths.
2. Distinguish unchanged shared dependencies, corrected runtime copies, new capabilities, reported pod-only patches and unrun proposals.
3. Preserve results with their actual config, checkpoint, preprocessing and scoring policy.
4. Add meaningful changes not covered here, with evidence. If a claim conflicts with the native source, record the correction and its consequences instead of forcing the file to match this narrative.
5. Put the reconciled answer and source evidence into the handoff described by Request 2. The resulting old-to-current path map will support the concrete cleanup proposal.

The accompanying [change register](CHANGE_REGISTER.csv) is the compact evidence index. Paths and versions are historical source anchors, not a claim of a completed live-pod audit.
