# Additional source evidence for the corrected companion

This records the source-backed dispositions of the ten additions supplied in the owner's relay of Claude's review on 1 November 2026. It accompanies the revised [answer](CHANGES_FROM_HANDOFF.md). Runtime source at `d711d92b61dec0c3e452dbedec544d071bf6d111` and V2 source at `dda4d4a07b371e0c980d65ec5caf016077d1acb9` were inspected; no new runtime execution was needed for these documentary corrections.

| Item | Incorporated result | Evidence |
|---|---|---|
| 1. One-device training | C10 now states that corrected trainers pin one device and reject distributed launches with WORLD_SIZE greater than one. Other available devices alone do not cause refusal. | [Base streaming][one-device], [base history][base-history-device], [A][a-device], [B][b-device] |
| 2. Prediction overwrites | C15 describes run-specific prediction locations and the base streaming/history scorers' destination and score checks. The separate lagging score_eval path is explicit. | [Unique predictions][unique-predictions], [destination][base-predictions], [values][base-score-values], [history scorer][history-predictions] |
| 3. Validation ranges | C16 distinguishes original history4950-only from original streaming4950–4954. Actual V1 A/B experiment specs expanded history validation; generic configs are not all changed. | [Original history][original-history-validation], [original streaming][original-stream-validation], [actual override][actual-ab-validation], [generic A][generic-a-default] |
| 4. Pre-fix causal checkpoints | C12 names the base sequential/history model's required mask-contract marker. The relayed phrase “single-transaction copy” was corrected to the source's actual model. | [Checkpoint hook][base-mask-contract] |
| 5. Checkpoint hash | C15 states that successful scored sweep runs receive checkpoint-hash metric sidecars. Optional standalone invocations and failed fits prevent the universal “every run” wording. | [Sidecar writer][checkpoint-sidecar], [sweep wiring][sweep-metrics] |
| 6. Time-feature crash | C04 describes the missing-flag-before-derived-time ordering and the reproduced hour_sin failure, then the corrected ordering. | [Corrected order][time-before-flags], [existing reproduction][time-crash-repro] |
| 7. Lagging copies | New section7 identifies base history's row-position context and base score_eval's unprotected destination write. | [History selection][lagging-history], [score write][lagging-scorer] |
| 8. Remaining findings | New section7 lists logging, baseline-save, TLS, baseline-loading and encoding findings with their specific scope. They are findings in inspected repository source; native dependency differences require separate attribution. | Sources below |
| 9. Native originals | Section6/7 records the returned comparison: original dependencies matched the supplied native copies, with10 fraud and48src differences from the repository snapshot. This is reported historical comparison evidence, not a fresh current-pod hash pass. | [Returned comparison][native-comparison] |
| 10. Artifact identity | Foundation/section7 identifies owner-location version1 artifacts and the unresolved equality with Yaqun's contents. | [Actual run location][actual-artifacts], [original configured location][original-artifact-path], [recorded unresolved question][artifact-question] |

## Evidence for remaining findings

- **Training-loss log:** [callback source][loss-log] and [existing reproduction][loss-repro]. The logged value can be the final minibatch loss at validation-epoch end rather than the reduced training-epoch mean. [V2's callback subclass][v2-callback] adds resume-file behavior. This finding does not establish invalid validation AP or AUROC.
- **Baseline-save deletion:** [baseline metrics path][baseline-output] and [library save behavior][save-clears]. Applies to that model-save path.
- **TLS:** [shared helper][tls] passes verify=False.
- **Checkpoint-loading compatibility:** [vendored loader][loading-default] omits an explicit weights_only argument; [existing reproduction][loading-repro] records the failure. The custom streaming/history scorer paths are separate.
- **Encoding performance:** [per-value categorical loop][encoding]. This is a performance opportunity, not a claim of wrong encodings or a newly measured regression.

The requested review-status paragraph and final REQUEST sentence were removed. C25's wording, section5's title and the three specified prescriptive sentences were edited. The recovery prompt now asks for HANDOFF.md, HANDOFF_FILES.md and HANDOFF_CODE.md. The broader rundown's incidental execution wording was also removed.

[one-device]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/base/scripts/train_streaming.py#L69
[base-history-device]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/base/scripts/train_sequential.py#L68
[a-device]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/phase4a/scripts/train_sequential.py#L59
[b-device]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/phase4b/scripts/train_sequential.py#L55
[base-predictions]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/base/scripts/score_streaming.py#L118
[base-score-values]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/base/scripts/score_streaming.py#L193
[history-predictions]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/base/scripts/score_sequential.py#L136
[unique-predictions]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/phase4b/scripts/score_sequential.py#L39
[original-history-validation]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/fraud/configs/sequential.yaml#L26
[original-stream-validation]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/fraud/configs/streaming.yaml#L24
[actual-ab-validation]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/phase4b/configs/ft_decisions_hier.yaml#L27
[generic-a-default]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/phase4a/configs/sequential.yaml#L27
[base-mask-contract]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/base/sequential_model.py#L99
[checkpoint-sidecar]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/phase4b/scripts/score_sequential.py#L203
[sweep-metrics]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/phase4b/scripts/run_ablations.py#L378
[time-before-flags]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/base/data/parquet_loader.py#L138
[time-crash-repro]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/bridge/evidence/claude/2026-10-05/chatgpt_checks_rerun/data_pipeline_checks.stdout#L3
[lagging-history]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/base/data/sequence_builder.py#L210
[lagging-scorer]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/base/scripts/score_eval.py#L140
[loss-log]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/fraud/callbacks.py#L23
[loss-repro]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/chatgpt/reviews/independent_verification.md#L5
[v2-callback]: https://github.com/AliKashy/tabular_fraud/blob/dda4d4a07b371e0c980d65ec5caf016077d1acb9/waqas/v2/scripts/train_v2.py#L160
[baseline-output]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/fraud/scripts/train_baseline.py#L208
[save-clears]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/src/pytorch_tabular/tabular_model.py#L1532
[tls]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/fraud/data/s3_utils.py#L31
[loading-default]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/src/pytorch_tabular/utils/python_utils.py#L74
[loading-repro]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/chatgpt/reviews/original_project.md#L32
[encoding]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/fraud/data/preprocessing.py#L165
[native-comparison]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/updates_10_23_2026/M01_V2_results__through_l3.part_1.md#L46
[actual-artifacts]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/updates_10_23_2026/M01_V2_results__through_l3.part_2_and_3.md#L626
[original-artifact-path]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/fraud/configs/preprocessing.yaml#L23
[artifact-question]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/bridge/OWNER_QA.md#L1926
