# Reorganization of the tabular fraud project

Written by Claude (CL) on 2 November 2026, with ChatGPT's (CH) contribution merged in. You (Copilot) apply it to the owner's branch on the work laptop and make everything run. This is Part 2 of `COPILOT_PROMPT.md`: start it after `handoff/SEND.md` is written, and use your Part 1 findings (`handoff/detail/FILES.md`, `CODE.md`, `MODELS.md`) to find every file named here.

How to read the tables: a path in backticks is exact. In a "New path" cell, `archive/code/=` means `archive/code/` followed by the exact current path (the same for `archive/results/=`, `archive/records/=`, `archive/diagnostics/=` and `archive/packages/=`). "same" means the file stays where it is.

## 1. Goal and the owner's rules

### 1.1 Goal

1. Turn the project into one clean tree in Yaqun's format: one package `fraud/`, plus `src/`, `docs/`, `notebooks/`, `tests/` at the root.
2. The `waqas/` folder disappears. Its corrected copies replace Yaqun's same-named files; every other kept module moves into `fraud/` under a functional name.
3. Put the 22 retained runs into `models/<name>/seed<NN>/`, shared population files into `splits/`, cross-model results into `comparisons/`.
4. Move everything superseded into `archive/`, a plain local folder that git ignores.
5. Every kept entry point imports, compiles and has an exact command in the README. Model, training and scoring behaviour stay exactly as trained.

### 1.2 The owner's rules

- **Only the reorganization.** Move, rename and group files. Update imports, path strings, config values that hold paths, and entry points so everything runs. Do not rewrite model, training or scoring logic.
- **Duplicates.** Identical copies become one file. Where one copy is a strict superset of another and every caller works with it unchanged, keep the superset. Otherwise keep both as separate modules with clear functional names. Never merge the code of two different implementations into one file.
- **Edits that are allowed:** one copy of each identical file, consistent config handling, consistent naming, the path and import updates in sections 5 and 6, the packaging fixes in section 9, and the test adjustments in section 4.11. Behaviour must stay exactly as trained, so every result reproduces.
- **Names.** Functional names only. No V1, V2, L1, L2, L3, stage, phase4a, phase4b, package, attempt, retry, run-id or date labels in any path, module, script, config or folder name. Follow Yaqun: "streaming" is the single-transaction model, "sequential" the history models. Yaqun's own file names stay as he wrote them (for example `docs/phase4_design_decisions.md`).
- **Very clean.** No caches, no generated hash or SHA-256 inventories, manifests, receipts, install records or review files in the organized tree. They go to `archive/`. The code may keep writing its own small run records (for example `run_manifest_v2.json`) into a training output folder; that is fine and is not changed.
- **Runnable.** Every kept entry point has an exact command in `README.md`.
- **Configs.** One base config per model type in `fraud/configs/`, plus command-line overrides, as in Yaqun's scripts. No sweep, ablation, seed-grid, smoke or per-run config files in `fraud/configs/`. The exact as-run config of every retained run sits with its results as `models/<name>/seed<NN>/config.yaml`.
- **Branch.** Work on a new local branch made from the owner's `waqas` branch, so `waqas` stays untouched until the owner decides. The owner pushes.

### 1.3 What stays exactly as it is

- Class names, function names, variable names, config key names and stored values. Stored values include strings saved in checkpoints and receipts, such as `target_ending_v1` and `transaction_causal_cls_sink_padding_v1`, even though they contain a version label.
- The file names the code writes at run time (`resolved_train_v2.yaml`, `run_manifest_v2.json`, `score_metrics.json`, receipts), because resume and scoring read them.
- The checkpoint input checks (`input_contract`, `sequence_contract`, `validation_policy`), because existing checkpoints are checked against them.
- The trainers, scorers, factories and builders listed here as separate modules stay separate.
- The fitted preprocessing artifacts on S3, including their `manifest.json`, which the loader reads at run time. This reorganization needs no training, scoring or S3 access.
- `test.yaml` at the pod project root stays where it is; the configs point to it.
- The numbers in `RESULTS.md` and `EXPERIMENTS.md` come from the recorded runs. If a score file disagrees, report it.
- The handoff files (`background/`, `changes_tracker/`, `EXPECTED_STATE.md`, `COPILOT_PROMPT.md`) stay in `tab_fraud_reorg` as they are, with their attribution of original messages, notes, summaries and owner relays. They are not copied into the project.

## 2. Background you do not have

### 2.1 The model and the decisions

- **Project:** card-fraud scoring with FT-Transformer models on bank transaction data. Yaqun wrote the original `fraud/`, `src/`, `docs/`, `notebooks/`, `tests/`, `README.md`, `pyproject.toml` and `requirements.txt`. Waqas (the owner) and two assistants (CH, CL) added the history models.
- **Chosen model:** `sequential_hier_allpos_h20_chunk` ("Arch B H20 chunk", was ALLPOS-H20-CHUNK). Test 1 AP 0.1020 at seed 42; mean 0.0982 over seeds 42, 43 and 44. It was trained on non-overlapping chunks, and validated and scored on one window per transaction ending at it, with the window capped at 32 rows (8 rows for the h5 models).
- **Reference model:** `sequential_hier_h20` ("Arch B H20 sliding", was B-H20). Test 1 AP 0.0955 at seed 42; mean 0.0817 over the three seeds.
- **Keep these three distinct:** the chosen `sequential_hier_allpos_h20_chunk`, the reference `sequential_hier_h20` (one target per window, bidirectional), and `sequential_hier_allpos_h20_sliding` (the chosen design trained on one window per transaction; it scored much worse).
- **Closed studies:** the architecture comparison, chunk against sliding training, and the seed check. Their results are kept; their sweep tools are archived.
- **Decided by the owner and the managers:** the 14-day account consumer and the embedding store that carried it are dropped entirely; this is transaction fraud scoring. Yaqun receives only a Markdown summary of scores (`docs/RESULTS.md`). The manager asked for the model's embedding to be used downstream: a 15298 offset model and a comparison with the TFM embeddings. Neither is built yet.
- **Next work, in this order (not part of this reorganization):** reproduce the chosen model from the organized code; bounded hyperparameter tuning (never done; the tuning script never ran); new features from TFM V32B and the 15298 model with month removed (feature-group code, feature screen and no-month preprocessing builder exist, never run); training on 100 files (scale scripts exist); then embedding export, its check, embedding diagnostics, downstream XGBoost and the benchmark (exist, never run). These tools go to `fraud/experiments/`, away from the active training path.
- **Feature inputs:** TFM V32B is the next feature input. Older TFM V22B plans and the V22/V17 feature-importance tables are history.
- **Keep status words distinct:** completed, proposed, withdrawn and unanswered are different. Code that exists is not a completed experiment.

### 2.2 The pod and the data

- Pod project root `/home/jovyan/k194855/tabular_fraud`. Python environment `/home/jovyan/k194855/tabular_fraud_s3_venv_FAIfNI` (outside the root; leave it). One H200 GPU.
- Training and validation data: `s3://mrmcd-analytics-mrm-mmr-dsai/tfm_raw_data/` (`part_<n>.parquet`). Evaluation data: `s3://mrmcd-analytics-mrm-mmr-dsai/tfm_EVAL_raw_data/`.
- Preprocessing artifacts version 1 at `s3://mrmcd-analytics-mrm-users/K194855/tabular_fraud/artifacts` (version key `1`). Yaqun's `fraud/configs/preprocessing.yaml` names his own K016730 location; leave his file unchanged.
- Predictions were written under `s3://mrmcd-analytics-mrm-users/K194855/tabular_fraud/predictions/` (Arch A rescores under `predictions/sequential/` with UUID names; seed runs under `predictions/seed_robustness/`) or to local parquet files in the run folders.
- The configs name `s3.cred_path: /home/jovyan/k194855/tabular_fraud/test.yaml`. Keep that value.

### 2.3 Code facts that must survive the move

- The pod's `waqas/v2/scripts/train_v2.py`, `waqas/v2/models.py` and `waqas/v2/scripts/select_splits.py` are patched after package 009. The patched pod files are the live code. Package 009 (`git show 60232e9:<path>` in the assistants' repository) predates them. Check each file for its patch marker (section 4.6) and take the pod copy if the branch copy lacks it.
- `train_v2.py` patch: `sequence.train_target_ending: true` trains on target-ending windows (`TargetEndingBuilder`); otherwise chunks. `models.py` patches: a target-slot `training_step`, routed so that a fully labelled chunk batch still uses the original all-position step. Keep both.
- `waqas/base/data/sequence_builder.py` is an older builder without the strict same-second rule. It is not interchangeable with the history builder and is archived.
- `waqas/base/scripts/score_eval.py` still overwrites existing predictions (an older behaviour). It still replaces Yaqun's file, unchanged.
- Preserve exactly: `sequence.train_target_ending`, the chunk loss routing, the validation and scoring policy, feature order, history settings (`history_len`, `history_time_order`, `time_delta`, `time_delta_reference`, `attention_mask`, `predict_every_transaction`), the window cap `max_window_rows`, `max_chunk_rows`, batch size and accumulation.
- Moving module paths can break loading of pickled checkpoints and every `sys.path` or `Path(__file__).parents[...]` depth assumption. Check with the real checkpoints (step 12).

## 3. The final tree

One line per file or folder. Files not listed under a folder do not belong there.

```
README.md                         install, test, and the exact command for every entry point
pyproject.toml                    package, dependencies and pytest settings
requirements.txt                  Python dependencies
.gitignore                        what git ignores (section 9)
docs/
  fraud_detection_plan_overall.md Yaqun: project plan (unchanged)
  fraud_detection_plan_detailed.md Yaqun: detailed plan and baseline record (unchanged)
  phase3_streaming_plan.md        Yaqun: streaming model plan (unchanged)
  phase4_sequential_plan.md       Yaqun: history model plan (unchanged)
  phase4_design_decisions.md      Yaqun: design decisions (unchanged)
  monitoring_and_eval.md          Yaqun: monitoring how-to (unchanged)
  tabular_transformer_models.md   Yaqun: model survey (unchanged)
  RESULTS.md                      score summary for Yaqun plus the 22-run reproduction table
  EXPERIMENTS.md                  every study: purpose, runs, command, result, decision
  CHANGES.md                      code changes since Yaqun's handoff and the old-to-new file map
  all_position_model.md           rules of the all-position model (was ALL_POSITION_CONTRACT.md)
  populations.md                  how the file inventory and the populations were made
  model_comparison.md             how compare_models.py pairs two models on the same rows
  business_metrics.md             alert-level and value metrics used by compare_models.py
notebooks/
  eda.ipynb                       Yaqun: data exploration (unchanged)
  sequence_smoke.ipynb            Yaqun: sequence builder smoke check (unchanged)
  smoke_test.ipynb                Yaqun: baseline preprocessing smoke check (unchanged)
src/pytorch_tabular/              vendored library, Yaqun's fork (unchanged)
fraud/
  __init__.py                     package exports (unchanged)
  callbacks.py                    CSV metrics, streaming AP/AUROC, and the EMA weight callback
  log_utils.py                    logging setup (unchanged)
  streaming_model.py              single-transaction FT-Transformer builder (corrected copy)
  sequential_model.py             flat history model, FTTransformerSeqModel (Arch A)
  sequential_hier_model.py        hierarchical model, one target or all positions (Arch B)
  sequential_hier_target_ending_model.py  Arch B subclass validated and trained on target-ending windows
  sequential_factory.py           builds the flat model from a config
  sequential_hier_factory.py      builds the hierarchical model and its dataset options
  tokenizer.py                    per-feature tokens, linear or periodic
  numerical_embeddings.py         periodic continuous embedding
  optim.py                        optimizer chosen by name
  source_files.py                 list of runtime source files the hierarchical trainer records
  configs/
    .gitkeep                      Yaqun's placeholder
    streaming.yaml                base config: single-transaction model (default run models/streaming/seed42)
    sequential.yaml               base config: flat model (default history 15)
    sequential_hier.yaml          base config: hierarchical model (default history 20, the reference)
    sequential_hier_allpos.yaml   base config: all-position model (history 20, chunk training, the chosen model)
    preprocessing.yaml            Yaqun: preprocessing artifact build (unchanged)
    predictors.csv                Yaqun: the 23 predictors (unchanged)
    eval.yaml                     Yaqun: baseline scorer config (unchanged)
    smoke_test.yaml               Yaqun: baseline trainer config (unchanged; train_baseline.py reads it)
  data/
    __init__.py                   (unchanged, empty)
    .gitkeep                      Yaqun's placeholder
    preprocessing.py              fitted artifacts: imputation, scaling, encoding (unchanged)
    datetime_features.py          calendar features from the timestamp (unchanged)
    feature_list.py               predictor list loader (unchanged)
    s3_utils.py                   S3 filesystem and file lists, plus thin_read_filesystem
    parquet_loader.py             single-transaction streaming dataset (corrected copy)
    sequence_builder.py           history windows and all-position chunks (the history builder)
    target_ending.py              one window per transaction, ending at it, with a row cap
    input_checks.py               label, account and timestamp checks
    input_contract.py             record of ordered inputs and artifact identity saved in checkpoints
    checkpoint_contract.py        saves and checks that record in streaming checkpoints
    prediction_files.py           prediction file paths, id checks and parquet reading
  scripts/
    .gitkeep                      Yaqun's placeholder
    build_preprocessing_artifacts.py  fit and write the preprocessing artifacts (unchanged)
    train_baseline.py             Yaqun's baseline training, corrected copy
    score_eval.py                 Yaqun's baseline scoring, corrected copy
    show_progress.py              print training metrics (unchanged)
    check_pid.sh                  check a training process (unchanged)
    fix_ssh_permissions.sh        fix SSH key permissions on a new pod (unchanged)
    train_streaming.py            train the single-transaction model
    score_streaming.py            score the single-transaction model
    train_sequential.py           train the flat model
    score_sequential.py           score the flat model
    train_sequential_hier.py      train the hierarchical and all-position models (chunk or sliding training, window validation)
    score_sequential_hier.py      score them; all-position checkpoints on capped windows
    train_sequential_hier_chunk_eval.py  hierarchical trainer that validates all-position models on chunks
    score_sequential_hier_chunk_eval.py  hierarchical scorer that scores all-position models on chunks
    data_inventory.py             count rows, frauds, accounts and months per data file
    select_splits.py              choose account-disjoint populations from the inventory
    measure_window_rows.py        measure window sizes and the window cap
    measure_chunk_widths.py       measure the widest strict chunk (max_chunk_rows)
    compare_models.py             paired comparison of models on the same rows, account bootstrap
    paired_bootstrap.py           bootstrap engine used by compare_models.py; also compares a run table
    business_metrics.py           alert-level and value metrics; fits amount bins
    temporal_eval.py              per-month report of one prediction file; history counts
    leaderboard.py                ranks prediction files by AP and AUROC
  experiments/
    tuning/                       hyperparameter tuning (built, not run yet)
    features/                     new features, feature screen, no-month preprocessing (built, not run yet)
    scale/                        training on 100 files (built, not run yet)
    embedding/                    embedding export, check, diagnostics, downstream XGBoost, benchmark (built, not run yet)
splits/                           frozen populations and measured window sizes
models/
  <name>/seed<NN>/                one folder per retained run (section 7)
comparisons/                      paired comparisons, the seed table and the flat-model rescore table
tests/                            pytest suite (section 4.11), with tests/data/ and tests/experiments/
archive/                          local only, ignored by git (section 8)
```

The full content of `fraud/experiments/`, `splits/`, `models/`, `comparisons/` and `tests/` is in sections 4, 7 and 4.11.

## 4. Move map

Do the moves with `git mv` for files that stay in the tree, so history follows them. Moves into `archive/` use plain `mv` (archive is ignored by git, so git records them as deletions; the untouched `waqas` branch keeps the originals). When a corrected copy replaces Yaqun's file, first move Yaqun's file to `archive/code/=`, then `git mv` the copy onto his path.

Before each replacement, diff Yaqun's file (as on the pod) against the replacing copy. The pod's `fraud/` matches Yaqun's native branches and differs from the assistants' repository copy in 10 files (`callbacks.py`, `data/parquet_loader.py`, `data/preprocessing.py`, `data/sequence_builder.py`, `scripts/check_pid.sh`, `scripts/score_sequential.py`, `scripts/train_baseline.py`, `scripts/train_streaming.py`, `sequential_model.py`, `streaming_model.py`). Report in group D every hunk that is not one of the fixes named in the note. The replacing copy still wins, because it produced the retained runs.

Convert every moved Python and YAML file to LF line endings (several phase4b files are CRLF or mixed). Change nothing else in them beyond sections 5 and 6.

### 4.1 Yaqun's files at the root and in `fraud/`

| Current path | New path | Note |
|---|---|---|
| `fraud/__init__.py` | same | unchanged |
| `fraud/callbacks.py` | same | append `EMACallback` (row in 4.3) |
| `fraud/log_utils.py` | same | unchanged |
| `fraud/streaming_model.py` | `archive/code/=` | replaced by `waqas/base/streaming_model.py` |
| `fraud/sequential_model.py` | `archive/code/=` | replaced by `waqas/phase4a/sequential.py` |
| `fraud/data/__init__.py` | same | unchanged |
| `fraud/data/.gitkeep` | same | unchanged |
| `fraud/data/datetime_features.py` | same | unchanged |
| `fraud/data/feature_list.py` | same | unchanged |
| `fraud/data/preprocessing.py` | same | unchanged |
| `fraud/data/s3_utils.py` | same | append `THIN_READ_BLOCK_SIZE` and `thin_read_filesystem` from `waqas/v2/storage.py`, unchanged |
| `fraud/data/parquet_loader.py` | `archive/code/=` | replaced by `waqas/base/data/parquet_loader.py` |
| `fraud/data/sequence_builder.py` | `archive/code/=` | replaced by `waqas/phase4b/sequence_builder.py` |
| `fraud/configs/.gitkeep` | same | unchanged |
| `fraud/configs/eval.yaml` | same | unchanged |
| `fraud/configs/predictors.csv` | same | unchanged |
| `fraud/configs/preprocessing.yaml` | same | unchanged |
| `fraud/configs/smoke_test.yaml` | same | unchanged; `train_baseline.py` reads it |
| `fraud/configs/streaming.yaml` | `archive/code/=` | replaced by the new base config (section 6.2) |
| `fraud/configs/sequential.yaml` | `archive/code/=` | replaced by the new base config (section 6.2) |
| `fraud/scripts/.gitkeep` | same | unchanged |
| `fraud/scripts/build_preprocessing_artifacts.py` | same | unchanged |
| `fraud/scripts/check_pid.sh` | same | unchanged |
| `fraud/scripts/fix_ssh_permissions.sh` | same | unchanged |
| `fraud/scripts/show_progress.py` | same | unchanged |
| `fraud/scripts/train_baseline.py` | `archive/code/=` | replaced by `waqas/base/scripts/train_baseline.py` |
| `fraud/scripts/score_eval.py` | `archive/code/=` | replaced by `waqas/base/scripts/score_eval.py` |
| `fraud/scripts/train_streaming.py` | `archive/code/=` | replaced by `waqas/base/scripts/train_streaming.py` |
| `fraud/scripts/score_streaming.py` | `archive/code/=` | replaced by `waqas/base/scripts/score_streaming.py` |
| `fraud/scripts/train_sequential.py` | `archive/code/=` | replaced by `waqas/phase4a/scripts/train_sequential.py` |
| `fraud/scripts/score_sequential.py` | `archive/code/=` | replaced by `waqas/phase4a/scripts/score_sequential.py` |
| `src/pytorch_tabular/` (whole folder) | same | unchanged |
| `tests/test_preprocessing.py` | same | unchanged |
| `docs/fraud_detection_plan_overall.md` | same | unchanged |
| `docs/fraud_detection_plan_detailed.md` | same | unchanged |
| `docs/phase3_streaming_plan.md` | same | unchanged |
| `docs/phase4_sequential_plan.md` | same | unchanged |
| `docs/phase4_design_decisions.md` | same | unchanged |
| `docs/monitoring_and_eval.md` | same | unchanged |
| `docs/tabular_transformer_models.md` | same | unchanged |
| `notebooks/eda.ipynb` | same | unchanged; do not commit outputs |
| `notebooks/sequence_smoke.ipynb` | same | unchanged; it calls `fraud.data.sequence_builder.SequenceBuilder`; check that its constructor call is accepted by the history builder and report it in group D if not |
| `notebooks/smoke_test.ipynb` | same | unchanged |
| `README.md` | same | update as in step 10 |
| `pyproject.toml` | same | section 9.2 |
| `requirements.txt` | same | section 9.2 |
| `.gitignore` | same | replace with section 9.1 |

Why Yaqun's four sequence files are archived and not replaced by their `waqas/base` copies: the Arch A versions are his same files carried further. `waqas/phase4a/sequential.py` is his `FTTransformerSeqModel` with the causal fixes, the same state-dict keys and the same outputs as the `waqas/base` copy in both masks. The phase4a and phase4b trainers and scorers are his scripts plus the factory, the strict history rule and a one-device guard. The history builder is his builder plus the sharding fix, input checks, the strict rule and chunks; his own builder tests pass on it unchanged (CL checked). No retained run used his sequence path.

### 4.2 `waqas/base/` (corrected copies of Yaqun's files)

| Current path | New path | Note |
|---|---|---|
| `waqas/base/data/parquet_loader.py` | `fraud/data/parquet_loader.py` | replaces Yaqun's: shard-then-shuffle, input checks, datetime features before missing flags |
| `waqas/base/data/input_contracts.py` | `fraud/data/input_checks.py` | `encode_binary_target`, `require_account_ids`, `parse_required_timestamps` |
| `waqas/base/data/contracts.py` | `fraud/data/input_contract.py` | `build_input_contract` |
| `waqas/base/data/checkpoint_contracts.py` | `fraud/data/checkpoint_contract.py` | `INPUT_CONTRACT_KEY`, `validate_input_contract`, `FrozenInputContractCallback` |
| `waqas/base/data/sequence_builder.py` | `archive/code/=` | older builder without the strict rule; superseded by `fraud/data/sequence_builder.py` |
| `waqas/base/data/__init__.py` | `archive/code/=` | marker of a removed package |
| `waqas/base/streaming_model.py` | `fraud/streaming_model.py` | replaces Yaqun's: `output_cardinality` only when the library declares it |
| `waqas/base/sequential_model.py` | `archive/code/=` | superseded by `fraud/sequential_model.py` (Arch A) |
| `waqas/base/scripts/train_streaming.py` | `fraud/scripts/train_streaming.py` | replaces Yaqun's; trained `streaming` |
| `waqas/base/scripts/score_streaming.py` | `fraud/scripts/score_streaming.py` | replaces Yaqun's; scored `streaming` |
| `waqas/base/scripts/train_baseline.py` | `fraud/scripts/train_baseline.py` | replaces Yaqun's: input checks before fit |
| `waqas/base/scripts/score_eval.py` | `fraud/scripts/score_eval.py` | replaces Yaqun's; still overwrites predictions, as before |
| `waqas/base/scripts/train_sequential.py` | `archive/code/=` | superseded by `fraud/scripts/train_sequential.py` |
| `waqas/base/scripts/score_sequential.py` | `archive/code/=` | superseded by `fraud/scripts/score_sequential.py` |
| `waqas/base/scripts/run_ablations.py` | `archive/code/=` | sweep runner |
| `waqas/base/scripts/__init__.py` | `archive/code/=` | package marker |
| `waqas/base/configs/streaming.yaml` | `archive/code/=` | the streaming run's base; values reach `fraud/configs/streaming.yaml` through the as-run config |
| `waqas/base/configs/ref_single.yaml` | `archive/code/=` | sweep spec of the streaming run |
| `waqas/base/README.md` | `archive/code/=` | describes the old copy rule |
| `waqas/base/__init__.py` | `archive/code/=` | package marker |

### 4.3 `waqas/phase4a/` (flat model, Arch A)

| Current path | New path | Note |
|---|---|---|
| `waqas/phase4a/sequential.py` | `fraud/sequential_model.py` | Arch A, `FTTransformerSeqModel` |
| `waqas/phase4a/factory.py` | `fraud/sequential_factory.py` | builds the flat model |
| `waqas/phase4a/tokenizer.py` | `fraud/tokenizer.py` | one copy; phase4b copy differs only in its import line |
| `waqas/phase4a/numerical_embeddings.py` | `fraud/numerical_embeddings.py` | one copy; phase4b copy is the same text in CRLF |
| `waqas/phase4a/optim.py` | `fraud/optim.py` | one copy; phase4b copy differs only in one capital letter of an error message |
| `waqas/phase4a/callbacks.py` | append its `EMACallback` class to `fraud/callbacks.py` | byte-identical to the phase4b copy; add its imports (`pytorch_lightning as pl`, `torch`) only if missing; then move the file to `archive/code/=` |
| `waqas/phase4a/sequence_builder.py` | `archive/code/=` | the phase4b builder is a strict superset (same single-target batches in every setting tested; extra arguments default off) |
| `waqas/phase4a/scripts/train_sequential.py` | `fraud/scripts/train_sequential.py` | trained the eight `sequential_*` runs |
| `waqas/phase4a/scripts/score_sequential.py` | `fraud/scripts/score_sequential.py` | scored them |
| `waqas/phase4a/scripts/tune.py` | `fraud/experiments/tuning/tune.py` | never run |
| `waqas/phase4a/scripts/run_ablations.py` | `archive/code/=` | sweep runner |
| `waqas/phase4a/scripts/__init__.py` | `archive/code/=` | package marker |
| `waqas/phase4a/__init__.py` | `archive/code/=` | package marker |
| `waqas/phase4a/configs/sequential.yaml` | `tests/data/configs/sequential.yaml` | test fixture: the generic flat config the tests were written against |
| `waqas/phase4a/configs/tune.yaml` | `fraud/experiments/tuning/tune.yaml` | search space; never run |
| `waqas/phase4a/configs/sequential_smoke.yaml` | `archive/code/=` | smoke config |
| `waqas/phase4a/configs/ft_decisions.yaml` | `archive/code/=` | sweep spec, never ran |
| `waqas/phase4a/configs/ft_decisions_capacity.yaml` | `archive/code/=` | sweep spec, never ran |
| `waqas/phase4a/configs/ft_decisions_core_resweep.yaml` | `archive/code/=` | sweep spec, never ran |
| `waqas/phase4a/configs/ft_decisions_flat_h10.yaml` | `archive/code/=` | spec of `sequential_h10` |
| `waqas/phase4a/configs/ft_decisions_flat_h15.yaml` | `archive/code/=` | spec of `sequential_h15` (shipped 256 x 16; ran 1024 x 4) |
| `waqas/phase4a/configs/ft_decisions_flat_h20.yaml` | `archive/code/=` | spec of `sequential_h20` (shipped 128 x 32; ran 512 x 8) |
| `waqas/phase4a/configs/ft_decisions_flat_long.yaml` | `archive/code/=` | sweep spec, never ran |
| `waqas/phase4a/configs/ft_decisions_gap05_off.yaml` | `archive/code/=` | spec of `sequential_h5_no_time_gap` |
| `waqas/phase4a/configs/ft_decisions_h0.yaml` | `archive/code/=` | spec of `sequential_h0` and `sequential_h5` |
| `waqas/phase4a/configs/ft_decisions_h0_seeds.yaml` | `archive/code/=` | seed grid, never ran |
| `waqas/phase4a/configs/ft_decisions_h10_seeds.yaml` | `archive/code/=` | seed grid, never ran |
| `waqas/phase4a/configs/ft_decisions_h10_seeds_off.yaml` | `archive/code/=` | seed grid, never ran |
| `waqas/phase4a/configs/ft_decisions_mask_causal.yaml` | `archive/code/=` | spec of `sequential_h5_causal` |
| `waqas/phase4a/configs/ft_decisions_smoke.yaml` | `archive/code/=` | smoke spec |
| `waqas/phase4a/configs/ft_decisions_timedelta.yaml` | `archive/code/=` | spec of `sequential_h10_no_time_gap` (ran standalone at 2048 x 2) |

### 4.4 `waqas/phase4b/` (hierarchical model, Arch B)

| Current path | New path | Note |
|---|---|---|
| `waqas/phase4b/sequential_hier.py` | `fraud/sequential_hier_model.py` | `FTTransformerHierModel`; keep every attribute name so state dicts load |
| `waqas/phase4b/factory.py` | `fraud/sequential_hier_factory.py` | `build_sequential_model`, `sequence_dataset_options`; differs from the flat factory, so it stays separate |
| `waqas/phase4b/sequence_builder.py` | `fraud/data/sequence_builder.py` | the history builder; replaces Yaqun's builder |
| `waqas/phase4b/ALL_POSITION_CONTRACT.md` | `docs/all_position_model.md` | text unchanged |
| `waqas/phase4b/tokenizer.py` | `archive/code/=` | duplicate of the phase4a copy |
| `waqas/phase4b/numerical_embeddings.py` | `archive/code/=` | duplicate of the phase4a copy |
| `waqas/phase4b/optim.py` | `archive/code/=` | duplicate of the phase4a copy |
| `waqas/phase4b/callbacks.py` | `archive/code/=` | byte-identical to the phase4a copy |
| `waqas/phase4b/scripts/train_sequential.py` | `fraud/scripts/train_sequential_hier_chunk_eval.py` | trained `sequential_hier_h0` to `h20` seed 42 and `sequential_hier_allpos_h5_chunk`; validates all-position models on chunks |
| `waqas/phase4b/scripts/score_sequential.py` | `fraud/scripts/score_sequential_hier_chunk_eval.py` | scored them; `score_sequential_hier.py` imports three helpers from it |
| `waqas/phase4b/scripts/measure_chunk_widths.py` | `fraud/scripts/measure_chunk_widths.py` | sizing tool; ran for the h20 chunk width |
| `waqas/phase4b/scripts/allpos_sliding_experiment.py` (pod only) | `archive/code/=` | closed diagnostic: window rescore of the h5 chunk model |
| `waqas/phase4b/scripts/run_ablations.py` | `archive/code/=` | sweep runner |
| `waqas/phase4b/scripts/__init__.py` | `archive/code/=` | package marker |
| `waqas/phase4b/__init__.py` | `archive/code/=` | package marker |
| `waqas/phase4b/configs/sequential_hier.yaml` | `tests/data/configs/sequential_hier.yaml` | test fixture |
| `waqas/phase4b/configs/sequential_hier_allposition.yaml` | `tests/data/configs/sequential_hier_allpos.yaml` | test fixture |
| `waqas/phase4b/configs/ft_decisions_hier.yaml` | `archive/code/=` | spec of `sequential_hier_h5` and `h10` |
| `waqas/phase4b/configs/ft_decisions_hier_allpos.yaml` | `archive/code/=` | spec of `sequential_hier_allpos_h5_chunk` |
| `waqas/phase4b/configs/ft_decisions_hier_h0.yaml` | `archive/code/=` | sweep spec, never ran |
| `waqas/phase4b/configs/ft_decisions_hier_h0_scored.yaml` | `archive/code/=` | spec of `sequential_hier_h0` |
| `waqas/phase4b/configs/ft_decisions_hier_h16.yaml` | `archive/code/=` | duplicate of the long spec, never ran |
| `waqas/phase4b/configs/ft_decisions_hier_long.yaml` | `archive/code/=` | spec of `sequential_hier_h15` and `h20` |
| `waqas/phase4b/configs/ft_decisions_hier_seeds.yaml` | `archive/code/=` | seed grid, never ran |
| `waqas/phase4b/configs/ft_decisions_hier_smoke.yaml` | `archive/code/=` | smoke spec |

Why two hierarchical trainers: `train_v2.py` (now `train_sequential_hier.py`) validates every all-position model on target-ending windows, defaults to `training.deterministic: true`, refuses EMA and adds resume. So it is not a strict superset of the phase4b trainer: it cannot reproduce `sequential_hier_allpos_h5_chunk`, which was validated on chunks. Both stay, with distinct names.

### 4.5 `waqas/v2/` code

| Current path | New path | Note |
|---|---|---|
| `waqas/v2/scripts/train_v2.py` (pod-patched) | `fraud/scripts/train_sequential_hier.py` | trained the three all-position seed-42 runs and the four seed 43/44 runs |
| `waqas/v2/scripts/score_v2.py` | `fraud/scripts/score_sequential_hier.py` | scored them and rescored `sequential_hier_h15` and `h20` |
| `waqas/v2/models.py` (pod-patched) | `fraud/sequential_hier_target_ending_model.py` | `FTTransformerHierTargetEnding`, `TARGET_ENDING_POLICY`, `target_slot_outputs` |
| `waqas/v2/target_ending.py` | `fraud/data/target_ending.py` | `TargetEndingBuilder` and the label-free builders, unchanged |
| `waqas/v2/storage.py` | `archive/code/=` | its function moved into `fraud/data/s3_utils.py` (row in 4.1) |
| `waqas/v2/scripts/select_splits.py` (pod-patched) | `fraud/scripts/select_splits.py` | DS_TRAIN rule as patched on the pod |
| `waqas/v2/scripts/data_inventory.py` | `fraud/scripts/data_inventory.py` | `select_splits.py` imports it |
| `waqas/v2/scripts/measure_window_rows.py` | `fraud/scripts/measure_window_rows.py` | measured the caps 32 and 8 |
| `waqas/v2/analysis/paired_v2.py` | `fraud/scripts/compare_models.py` | produced the chunk against sliding comparisons |
| `waqas/v2/analysis/business_metrics.py` | `fraud/scripts/business_metrics.py` | `compare_models.py` imports it |
| `waqas/v2/analysis/ANALYSIS.md` | `docs/model_comparison.md` | update its commands to the new paths |
| `waqas/v2/analysis/BUSINESS_METRICS.md` | `docs/business_metrics.md` | text unchanged |
| `waqas/v2/INVENTORY.md` | `docs/populations.md` | update its commands to the new paths |
| `waqas/v2/USAGE_CONSUMERS.md` | `fraud/experiments/embedding/USAGE.md` | text unchanged |
| `waqas/v2/export_v2.py` | `fraud/experiments/embedding/export_embeddings.py` | never run |
| `waqas/v2/scripts/l4_check.py` | `fraud/experiments/embedding/check_export.py` | never run |
| `waqas/v2/analysis/embedding_diagnostics.py` | `fraud/experiments/embedding/embedding_diagnostics.py` | never run |
| `waqas/v2/downstream_xgb.py` | `fraud/experiments/embedding/downstream_xgb.py` | never run |
| `waqas/v2/benchmark_v2.py` | `fraud/experiments/embedding/benchmark.py` | never run; its `read_table` moves to `fraud/data/prediction_files.py` (section 5.4) |
| `waqas/v2/scripts/make_v2_contracts.py` | `fraud/experiments/embedding/export_records.py` | `check_export.py` and `checkpoint_facts.py` import it |
| `waqas/v2/scripts/checkpoint_facts.py` | `fraud/experiments/embedding/checkpoint_facts.py` | export pin diagnostic |
| `waqas/v2/scripts/check_v1_source.py` | `fraud/experiments/embedding/source_check.py` | `export_records.py` imports it |
| `waqas/v2/features/groups.py` | `fraud/experiments/features/groups.py` | candidate feature families |
| `waqas/v2/features/strict_window.py` | `fraud/experiments/features/strict_window.py` | strictly earlier per-account windows |
| `waqas/v2/features/README.md` | `fraud/experiments/features/candidate_features.md` | text unchanged |
| `waqas/v2/features/__init__.py` | `archive/code/=` | package marker; the namespace import works without it |
| `waqas/v2/screen/features_new.py` | `fraud/experiments/features/screen/features_new.py` | feature screen |
| `waqas/v2/screen/power.py` | `fraud/experiments/features/screen/power.py` | feature screen |
| `waqas/v2/screen/probes.py` | `fraud/experiments/features/screen/probes.py` | feature screen |
| `waqas/v2/screen/run_power.py` | `fraud/experiments/features/screen/run_power.py` | feature screen |
| `waqas/v2/screen/run_screen.py` | `fraud/experiments/features/screen/run_screen.py` | feature screen runner, never run |
| `waqas/v2/screen/stability.py` | `fraud/experiments/features/screen/stability.py` | feature screen |
| `waqas/v2/screen/state_test.py` | `fraud/experiments/features/screen/state_test.py` | feature screen |
| `waqas/v2/screen/synth.py` | `fraud/experiments/features/screen/synth.py` | feature screen |
| `waqas/v2/screen/usefulness.py` | `fraud/experiments/features/screen/usefulness.py` | feature screen |
| `waqas/v2/screen/README.md` | `fraud/experiments/features/screen/README.md` | text unchanged |
| `waqas/v2/screen/POD.md` | `fraud/experiments/features/screen/POD.md` | update its commands to the new paths |
| `waqas/v2/screen/SOURCE.md` | `archive/records/=` | provenance and hashes |
| `waqas/v2/scripts/build_nomonth_artifact.py` | `fraud/experiments/features/build_nomonth_artifact.py` | never run |
| `waqas/v2/scripts/check_nomonth_artifact.py` | `fraud/experiments/features/check_nomonth_artifact.py` | never run |
| `waqas/v2/configs/predictors_nomonth.csv` | `fraud/experiments/features/predictors_nomonth.csv` | `predictors.csv` minus month |
| `waqas/v2/configs/preprocessing_nomonth.yaml` | `fraud/experiments/features/preprocessing_nomonth.yaml` | set `predictors.csv_path: fraud/experiments/features/predictors_nomonth.csv` |
| `waqas/v2/scale_runs.py` | `fraud/experiments/scale/scale_runs.py` | never run; drives archived runners (README note) |
| `waqas/v2/data_size_specs.py` | `fraud/experiments/scale/data_size_specs.py` | never run |
| `waqas/v2/scripts/data_look.py` | `archive/code/=` | one-off data look, finished |
| `waqas/v2/h5_diagnostics.py` | `archive/code/=` | one-off diagnostic |
| `waqas/v2/configs/make_run_configs.py` | `archive/code/=` | grid generator |
| `waqas/v2/configs/b05.yaml` | `archive/code/=` | grid config, never ran |
| `waqas/v2/configs/b05r.yaml` | `archive/code/=` | grid config, never ran |
| `waqas/v2/configs/b20.yaml` | `archive/code/=` | grid config, never ran; not the reference's config |
| `waqas/v2/configs/c05.yaml` | `archive/code/=` | grid config, never ran |
| `waqas/v2/configs/c20.yaml` | `archive/code/=` | grid config, never ran; not the chosen model's as-run config |
| `waqas/v2/configs/__init__.py` | `archive/code/=` | package marker |
| `waqas/v2/scripts/__init__.py` | `archive/code/=` | package marker |
| `waqas/v2/analysis/__init__.py` | `archive/code/=` | package marker |
| `waqas/v2/__init__.py` | `archive/code/=` | package marker |

### 4.6 Patched pod files: how to recognise the live copy

| File | The live copy contains | If the branch copy lacks it |
|---|---|---|
| `waqas/v2/scripts/train_v2.py` | `train_target_ending = bool(cfg.sequence.get("train_target_ending", False))` and `builder_cls": TargetEndingBuilder` in the training-set call | take the pod snapshot copy |
| `waqas/v2/models.py` | a `training_step` whose first line tests `not self.hparams.predict_every_transaction or torch.equal(batch["target_seq"] != -100, batch["mask"])` | take the pod snapshot copy |
| `waqas/v2/scripts/select_splits.py` | `reserved = set(range(1, 101)) \| set(range(4950, 4955))` in the DS_TRAIN check | take the pod snapshot copy |

The patch scripts and their receipts are not needed after this: `patch_train_v2_sliding.py`, `patch_target_ending_training.py`, `patch_chunk_training_route.py`, `patches/patch_select_splits_ds_train.py` go to `archive/code/=`, and `runs/v2/patches/` to `archive/records/=`.

### 4.7 `waqas/scoring/`, `waqas/scripts/` and the rest of `waqas/`

| Current path | New path | Note |
|---|---|---|
| `waqas/scoring/_prediction_utils.py` | `fraud/data/prediction_files.py` | plus `read_table` (section 5.4) |
| `waqas/scoring/temporal_eval.py` | `fraud/scripts/temporal_eval.py` | `paired_bootstrap.py` and `compare_models.py` import it |
| `waqas/scoring/leaderboard.py` | `fraud/scripts/leaderboard.py` | `paired_bootstrap.py` imports `_bootstrap_blocks` from it |
| `waqas/scoring/ensemble.py` | `archive/code/=` | no kept caller |
| `waqas/scoring/calibrate_and_report.py` | `archive/code/=` | no kept caller |
| `waqas/scoring/__init__.py` | `archive/code/=` | package marker |
| `waqas/scoring/allpos_sliding_h5/` (pod results) | section 7.3 | score file to the h5 chunk model; the rest to `archive/diagnostics/=` |
| `waqas/scripts/build_leaderboard.py` | `archive/code/=` | combines sweep results |
| `waqas/source_identity.py` | `fraud/source_files.py` | section 5.4 |
| `waqas/requirements-pod.txt` | `archive/code/=` | after adding `requests` and `pytorch-tabnet` to the root files |
| `waqas/run_all.sh` | `archive/code/=` | sweep launcher |
| `waqas/CHANGES_TO_UPLOAD.txt` | `archive/records/=` | day log |
| `waqas/docs/meeting_notes.md` | `archive/records/=` | planning record |
| `waqas/docs/waqas_current_standing.md` | `archive/records/=` | planning record |
| `waqas/docs/waqas_phase4a_guide.md` | `archive/records/=` | planning record |
| `waqas/docs/waqas_phase4b_guide.md` | `archive/records/=` | planning record |
| `waqas/docs/waqas_phase5_guide.md` | `archive/records/=` | planning record |
| `waqas/docs/waqas_roadmap.md` | `archive/records/=` | planning record |
| `waqas/additional_info/README.md` | `archive/records/=` | email index |
| `waqas/additional_info/data_path_information_email/README.md` | `archive/records/=` | email index |
| `waqas/additional_info/data_path_information_email/data_path_information_email.md` | `archive/records/=` | data paths email (paths are in the configs) |
| `waqas/additional_info/email_from_xiaoming_for_feature_information/README.md` | `archive/records/=` | email index |
| `waqas/additional_info/email_from_xiaoming_for_feature_information/2026-10-12_best_practice_in_feature_engineering.md` | `archive/records/=` | feature guidance email (also in the handoff background) |
| `waqas/results_from_pod/` (whole folder: `v1_results_2026-10-13/README.md`, `V1_COMPLETE_REPORT.md`, `screenshot_inventory.json`, `reviewer_update_v1/README.md`, `RECONSTRUCTION_NOTES.md`, `analysis_outputs/RUNS.md`, `paired_args.txt`, `paired_report.md`, `paired_report_finalist.md`, `run_log.csv`, `run_table.csv`, `runbook/2026-10-07/add_finalist_contrasts.py`, `audit_v1.py`, `build_run_table_v1.py`, `make_review_bundle.py`) | `archive/records/=` | result records; `docs/RESULTS.md` and `EXPERIMENTS.md` replace them |
| `waqas/future_experiments/` (whole folder: `__init__.py`, `bug_repro/__init__.py`, `bug_repro/sequence_builder_buggy.py`, `bug_repro/train_sequential_buggy.py`, `optimizer_test/ft_decisions_embedding_optimizer.yaml`, `pretrain/__init__.py`, `pretrain/configs/contrastive.yaml`, `pretrain/configs/ssl.yaml`, `pretrain/encoder.py`, `pretrain/numerical_embeddings.py`, `pretrain/tokenizer.py`, `pretrain/ssl_finetune.py`, `pretrain/ssl_pretrain.py`, `pretrain/supcon.py`, `pretrain/scripts/__init__.py`, `pretrain/scripts/export_embeddings.py`, `pretrain/scripts/pretrain_contrastive.py`, `pretrain/scripts/pretrain_ssl.py`, `pretrain/scripts/score_contrastive.py`, `pretrain/scripts/score_ssl_finetune.py`, `pretrain/scripts/train_contrastive.py`, `pretrain/scripts/train_ssl_finetune.py`, `variance_test/ft_decisions_seed_sweep.yaml`) | `archive/code/=` | closed bug study, parked pretraining, sweep grids |
| `waqas/feature_work/all_features_master.csv` | `fraud/experiments/features/reference/all_features_master.csv` | master feature index |
| `waqas/feature_work/all_possible_features_workbook.xlsx` | `fraud/experiments/features/reference/all_possible_features_workbook.xlsx` | same index as a workbook |
| `waqas/feature_work/README.md` | `archive/records/=` | rebuild notes with a hash |
| `waqas/feature_related/part_124_248/feature_metadata_rows_124_248.csv` | `fraud/experiments/features/reference/feature_metadata_rows_124_248.csv` | bank feature dictionary, rows 124 to 248 |
| `waqas/feature_related/part_124_248/feature_metadata_rows_124_248.xlsx` | `fraud/experiments/features/reference/feature_metadata_rows_124_248.xlsx` | same as a workbook |
| `waqas/feature_related/part_249_600/feature_metadata_rows_249_600.csv` | `fraud/experiments/features/reference/feature_metadata_rows_249_600.csv` | bank feature dictionary, rows 249 to 600 |
| `waqas/feature_related/part_249_600/feature_metadata_rows_249_600.xlsx` | `fraud/experiments/features/reference/feature_metadata_rows_249_600.xlsx` | same as a workbook |
| `waqas/feature_related/part_124_248/README.md`, `SHA256SUMS.txt`, `row_sources.csv`, `source_photographs.csv`, `unresolved_cells.csv` | `archive/records/=` (each file) | transcription provenance |
| `waqas/feature_related/part_249_600/README.md`, `SHA256SUMS.txt`, `cell_sources.csv`, `row_sources.csv`, `source_photographs.csv`, `unresolved_cells.csv`, `transcription_checkpoint.json`, `validation.json` | `archive/records/=` (each file) | transcription provenance |
| `waqas/feature_related/part_249_600/chunks/rows_249_424/feature_metadata_rows_249_424.csv`, `feature_metadata_rows_249_424.xlsx`, `validation.json` and `waqas/feature_related/part_249_600/chunks/rows_425_600/feature_metadata_rows_425_600.csv`, `feature_metadata_rows_425_600.xlsx`, `validation.json` | `archive/records/=` (each file) | parts of the 249 to 600 table |
| `waqas/features/feature_importance_v22_v17_highlighted/README.md`, `feature_importance.csv`, `feature_importance.md`, `feature_importance_v22_v17_highlighted.xlsx` | `archive/records/=` (each file) | TFM V22B era importance; history |
| `waqas/phase5_pretrain/__pycache__/` | delete | stale cache |

### 4.8 `waqas/tests/`

Tests import shared helpers from each other. `from waqas.tests.test_sequence_builder import X` becomes `from test_sequence_builder import X` (pytest puts the test folder on `sys.path`; `tests/` has no `__init__.py`). The same rule applies to every `from waqas.tests.<module>` and `from waqas.v2.tests.<module>` import: use the new bare module name from these tables.

| Current path | New path | Note |
|---|---|---|
| `waqas/tests/test_sequence_builder.py` | `tests/test_sequence_builder.py` | Yaqun's builder tests; `sys.path` insert `("..", "..")` becomes `("..",)` |
| `waqas/tests/test_a_checkpoint_contract.py` | `tests/test_sequential_checkpoint.py` | config path to `tests/data/configs/sequential.yaml` |
| `waqas/tests/test_b_allposition.py` | `tests/test_sequential_hier_allpos.py` | configs to `tests/data/configs/` |
| `waqas/tests/test_b_allposition_strict_time.py` | `tests/test_sequential_hier_allpos_strict_time.py` | configs to `tests/data/configs/` |
| `waqas/tests/test_b_allposition_sibling_invariance.py` | `tests/test_sequential_hier_allpos_siblings.py` | imports `ties` from `test_sequential_hier_allpos_strict_time` |
| `waqas/tests/test_base_loader_coverage.py` | `tests/test_loader_worker_sharding.py` | retarget rule 4.11 |
| `waqas/tests/test_base_model_contract.py` | `tests/test_sequential_model_mask.py` | retarget to `fraud.sequential_model`; rule 4.11 |
| `waqas/tests/test_base_score_contract.py` | `tests/test_streaming_train_score.py` | retarget rule 4.11 |
| `waqas/tests/test_baseline_input_contracts.py` | `tests/test_baseline_input_checks.py` | imports `fraud.scripts.train_baseline`, `score_eval` |
| `waqas/tests/test_causal_leak.py` | `tests/test_causal_leak.py` | |
| `waqas/tests/test_ema_lifecycle.py` | `tests/test_ema_callback.py` | both phase parameters point at `fraud.callbacks` |
| `waqas/tests/test_history_labels_not_inputs.py` | `tests/test_history_labels_not_inputs.py` | imports from `test_history_time_order` |
| `waqas/tests/test_history_time_order.py` | `tests/test_history_time_order.py` | both builder entries point at `fraud.data.sequence_builder`; golden file path below |
| `waqas/tests/data/history_time_order_tiebreak_7ae90ef.json` | `tests/data/history_time_order_tiebreak.json` | update the path string in the test |
| `waqas/tests/test_leaderboard.py` | `tests/test_leaderboard.py` | |
| `waqas/tests/test_loader_input_contracts.py` | `tests/test_input_checks.py` | the base builder entry points at `fraud.data.sequence_builder` |
| `waqas/tests/test_models.py` | `tests/test_models.py` | remove the three pretraining tests and their imports (rule 4.11); contract doc path to `docs/all_position_model.md` |
| `waqas/tests/test_runner_score_validation.py` | `tests/test_score_validation.py` | phase4a parameter: `fraud.scripts.score_sequential`; phase4b parameter: `fraud.scripts.score_sequential_hier_chunk_eval` |
| `waqas/tests/test_temporal_eval.py` | `tests/test_temporal_eval.py` | |
| `waqas/tests/test_training_loader_coverage.py` | `tests/test_history_worker_sharding.py` | phase4a: `fraud.scripts.train_sequential`; phase4b: `fraud.scripts.train_sequential_hier_chunk_eval`; configs to `tests/data/configs/` |
| `waqas/tests/test_v2_features.py` | `tests/experiments/features/test_strict_window_features.py` | |
| `waqas/tests/test_ablation_artifacts.py` | `archive/code/=` | tests the sweep runner |
| `waqas/tests/test_base_copies_wiring.py` | `archive/code/=` | guards the old copy layout |
| `waqas/tests/test_base_sequence_builder.py` | `archive/code/=` | tests the archived builder |
| `waqas/tests/test_bug_repro_parity.py` | `archive/code/=` | closed bug study |
| `waqas/tests/test_build_leaderboard.py` | `archive/code/=` | archived tool |
| `waqas/tests/test_calibrate_and_report.py` | `archive/code/=` | archived tool |
| `waqas/tests/test_ensemble.py` | `archive/code/=` | archived tool |
| `waqas/tests/test_phase5_regressions.py` | `archive/code/=` | parked pretraining |
| `waqas/tests/test_supcon.py` | `archive/code/=` | parked pretraining |
| `waqas/tests/test_runner_checkpoint_pairing.py` | `archive/code/=` | sweep runner |
| `waqas/tests/test_runner_contracts.py` | `archive/code/=` | sweep runner |
| `waqas/tests/test_v2_data_size_specs.py` | `archive/code/=` | needs the archived sweep runner |
| `waqas/tests/test_v2_scale_runs.py` | `archive/code/=` | needs the archived sweep runner |
| `waqas/tests/test_v2_h5_diagnostics.py` | `archive/code/=` | archived diagnostic |
| `waqas/tests/__init__.py` | `archive/code/=` | package marker |

### 4.9 `waqas/v2/tests/` and `waqas/v2/screen/tests/`

| Current path | New path | Note |
|---|---|---|
| `waqas/v2/tests/conftest.py` | `tests/conftest.py` | base configs to `tests/data/configs/sequential_hier.yaml` and `sequential_hier_allpos.yaml`; `parents[3]` to `parents[1]` |
| `waqas/v2/tests/test_train_v2.py` | `tests/test_train_sequential_hier.py` | |
| `waqas/v2/tests/test_score_v2.py` | `tests/test_score_sequential_hier.py` | |
| `waqas/v2/tests/test_scoring_attempt.py` | `tests/test_score_sequential_hier_records.py` | imports from `test_score_sequential_hier` |
| `waqas/v2/tests/test_run_lock_and_storage.py` | `tests/test_train_sequential_hier_lock.py` | monkeypatch target to `fraud.data.s3_utils` |
| `waqas/v2/tests/test_target_ending.py` | `tests/test_target_ending.py` | config path to `tests/data/configs/sequential_hier_allpos.yaml` |
| `waqas/v2/tests/test_measure_window_rows.py` | `tests/test_measure_window_rows.py` | |
| `waqas/v2/tests/test_data_inventory.py` | `tests/test_data_inventory.py` | CLI calls become `python -m fraud.scripts.data_inventory` |
| `waqas/v2/tests/test_review_tie_boundary.py` | `tests/test_data_inventory_ties.py` | |
| `waqas/v2/tests/test_select_splits.py` | `tests/test_select_splits.py` | rule 4.11 for the patched DS_TRAIN range |
| `waqas/v2/tests/test_paired_v2.py` | `tests/test_compare_models.py` | |
| `waqas/v2/tests/test_review_june_direct.py` | `tests/test_compare_models_june.py` | imports from `test_compare_models` |
| `waqas/v2/tests/test_review_arch_values.py` | `tests/test_compare_models_architecture_rule.py` | imports from `test_compare_models` |
| `waqas/v2/tests/test_analysis_integration_v2.py` | `tests/test_compare_models_integration.py` | |
| `waqas/v2/tests/test_business_metrics.py` | `tests/test_business_metrics.py` | |
| `runbook/2026-10-07/tests/test_paired_report.py` | `tests/test_paired_bootstrap.py` | load paths to `fraud/scripts/paired_bootstrap.py` and `fraud/scripts/leaderboard.py` |
| `waqas/v2/tests/test_benchmark_v2.py` | `tests/experiments/embedding/test_benchmark.py` | |
| `waqas/v2/tests/test_downstream_xgb.py` | `tests/experiments/embedding/test_downstream_xgb.py` | |
| `waqas/v2/tests/test_downstream_decision.py` | `tests/experiments/embedding/test_downstream_decision.py` | |
| `waqas/v2/tests/test_embedding_diagnostics.py` | `tests/experiments/embedding/test_embedding_diagnostics.py` | |
| `waqas/v2/tests/test_export_v2.py` | `tests/experiments/embedding/test_export_embeddings.py` | |
| `waqas/v2/tests/test_export_attempt.py` | `tests/experiments/embedding/test_export_attempt.py` | |
| `waqas/v2/tests/test_legacy_attempts.py` | `tests/experiments/embedding/test_export_legacy_checkpoints.py` | |
| `waqas/v2/tests/test_contracts_and_facts.py` | `tests/experiments/embedding/test_export_records.py` | |
| `waqas/v2/tests/test_delivery_contract_wiring.py` | `tests/experiments/embedding/test_export_records_settings.py` | |
| `waqas/v2/tests/test_check_v1_source.py` | `tests/experiments/embedding/test_source_check.py` | |
| `waqas/v2/tests/test_review_arm_contrast.py` | `tests/experiments/embedding/test_downstream_arm_contrast.py` | |
| `waqas/v2/tests/test_review_compare_refusals.py` | `tests/experiments/embedding/test_benchmark_refusals.py` | |
| `waqas/v2/tests/test_review_final_guards.py` | `tests/experiments/embedding/test_downstream_final_guards.py` | |
| `waqas/v2/tests/test_review_june_window_downstream.py` | `tests/experiments/embedding/test_downstream_june_window.py` | |
| `waqas/v2/tests/test_review_fixes.py` | `tests/experiments/embedding/test_benchmark_and_downstream_rules.py` | |
| `waqas/v2/tests/test_nomonth_artifact.py` | `tests/experiments/features/test_nomonth_artifact.py` | config path to `fraud/experiments/features/preprocessing_nomonth.yaml` |
| `waqas/v2/screen/tests/conftest.py` | `tests/experiments/features/screen/conftest.py` | screen folder path to `fraud/experiments/features/screen` |
| `waqas/v2/screen/tests/test_input_types.py` | `tests/experiments/features/screen/test_input_types.py` | |
| `waqas/v2/screen/tests/test_location.py` | `tests/experiments/features/screen/test_location.py` | |
| `waqas/v2/screen/tests/test_pod_reading.py` | `tests/experiments/features/screen/test_pod_reading.py` | |
| `waqas/v2/screen/tests/test_power.py` | `tests/experiments/features/screen/test_power.py` | |
| `waqas/v2/screen/tests/test_screen.py` | `tests/experiments/features/screen/test_screen.py` | |
| `waqas/v2/screen/tests/test_stability.py` | `tests/experiments/features/screen/test_stability.py` | |
| `waqas/v2/tests/test_data_look.py` | `archive/code/=` | archived tool |
| `waqas/v2/tests/test_run_configs.py` | `archive/code/=` | archived grid generator |
| `waqas/v2/tests/test_step1_commands.py` | `archive/code/=` | parses archived runbooks |
| `waqas/v2/tests/__init__.py` | `archive/code/=` | package marker |
| `tests/test_allpos_sliding_experiment.py` (pod only) | `archive/code/=` | archived diagnostic |

### 4.10 `runbook/`, `scripts/` and pod-only code

| Current path | New path | Note |
|---|---|---|
| `runbook/2026-10-07/paired_report.py` | `fraud/scripts/paired_bootstrap.py` | `compare_models.py` loads it |
| `runbook/2026-10-07/MORNING.md`, `RELEASE.md`, `STAGE1_PREFLIGHT.md`, `STAGE2_SMOKE.md`, `STAGE3_BATCH1.md`, `STAGE3_V1_PARALLEL.md`, `STAGE4_BATCH2.md`, `STAGE5_ANALYSIS.md` | `archive/code/=` (each file) | launch pages |
| `runbook/2026-10-07/analysis.sh`, `batch1.sh`, `batch2.sh`, `smoke.sh` | `archive/code/=` (each file) | launch scripts |
| `runbook/2026-10-07/analysis_runs.py`, `batch_tools.py`, `collect_returns.py`, `make_source_manifest.py`, `parallel_v1.py`, `preflight_pod.py`, `run_step.py`, `score_attempt.py`, `smoke_checks.py` | `archive/code/=` (each file) | sweep and ledger tools |
| `runbook/2026-10-07/github_source_manifest.csv` | `archive/records/=` | hash manifest |
| `runbook/2026-10-07/v1_contrasts.csv` | `archive/records/=` | planned contrasts of the closed study |
| `runbook/2026-10-07/synthetic/make_synthetic_data.py`, `positive_control.sh`, `run_synthetic_e2e.sh`, `sitecustomize.py` | `archive/code/=` (each file) | fake-S3 harness; never ship `sitecustomize.py` |
| `runbook/2026-10-07/tests/test_analysis_stage.py`, `test_batch_fr1.py`, `test_batch_return_resume.py`, `test_collector_v3.py`, `test_parallel_v1.py`, `test_preflight_fr1.py`, `test_preflight_v3.py`, `test_ref_single_b8.py`, `test_release_guide.py`, `test_round3.py`, `test_runbook_contracts.py`, `test_score_attempt_v3.py`, `test_smoke.py`, `test_source_scope.py`, `test_v1_matrix.py` | `archive/code/=` (each file) | runbook tests |
| `runbook/2026-10-14/ALLPOS_H5_SLIDING_RUNBOOK.md` (pod only) | `archive/code/=` | archived diagnostic |
| `runbook/2026-10-19/QUICK_CHECKS.md`, `quick_checks.py`, `tests/test_quick_checks_f.py`, `tests/test_quick_checks_g.py` | `archive/code/=` (each file) | one-off checks |
| `runbook/v2/DECISIONS.md`, `RUNBOOK.md`, `STEP1.md` | `archive/records/=` (each file) | run records |
| `scripts/sync_pytorch_tabular.py` | `archive/code/=` | re-downloads the vendored library; do not run it |
| `13_h20_sliding.py`, `13_followup.py`, `l3_followup.py` (pod root, if present) | `archive/code/=` (each file) | config builders of the closed study |
| `seed_robustness.py`, `seed_fits_block.sh`, `cpu_reads.sh`, `verify_remaining.py` (pod root, if present) | `archive/code/=` (each file) | seed check and read-only helpers |
| `patch_train_v2_sliding.py`, `patch_target_ending_training.py`, `patch_chunk_training_route.py`, `patches/patch_select_splits_ds_train.py` (pod) | `archive/code/=` (each file) | patches already applied |
| `score_arch_a_manifest.py`, `arch_a_holdout.yaml`, `merge_model_score_tables.py` (pod root) | `archive/code/=` (each file) | flat-model rescore tools |
| `tools/organize_pod.py` (pod, if present) | `archive/code/=` | earlier reorganization tool |
| `PACKAGE.json`, `PERSONALIZATION.json`, `install.py`, `personalize.py` (pod root, if present) | `archive/packages/=` (each file) | package install files |
| `test.yaml` (pod root) | same | stays at the root; configs point to it |

### 4.11 Rules for tests

1. **Imports and paths.** Apply section 5 to every kept test, including `importlib.import_module("waqas...")` strings and `monkeypatch.setattr("waqas....", ...)` targets.
2. **Retarget rule.** A test that imported an archived module is first pointed at the module that superseded it: `waqas.base.sequential_model` to `fraud.sequential_model`; `waqas.base.data.sequence_builder` to `fraud.data.sequence_builder`; `waqas.base.scripts.train_sequential` and `score_sequential` to `fraud.scripts.train_sequential` and `score_sequential`. Keep every test function that then passes unchanged. Delete a test function, or a parameter value, only when it fails because it checks behaviour that only the archived module had. Never change an assertion to make a test pass. List each deletion in group D.
3. **Archived dependencies.** In `tests/test_models.py`, remove the test functions that import `waqas.future_experiments.pretrain` and those imports. Move its EMA test unchanged with the file.
4. **Patched behaviour.** When a kept test fails only because it expects the unpatched package-009 behaviour that a pod patch changed (the DS_TRAIN range in `select_splits.py`; sliding training in `train_v2.py`; chunk routing in `models.py`), change only the expected values to the patched behaviour, and list it.
5. **Config fixtures.** Tests that loaded `waqas/phase4a/configs/sequential.yaml`, `waqas/phase4b/configs/sequential_hier.yaml` or `waqas/phase4b/configs/sequential_hier_allposition.yaml` load the fixture copies in `tests/data/configs/`, never the new base configs.
6. **Experiment tests** live in `tests/experiments/<purpose>/`. Run them, report their result separately, and fix only failures caused by the move.
7. If pytest reports an import file mismatch for a folder, add an empty `__init__.py` to that test folder only.

## 5. Imports

### 5.1 Old module to new module (find and replace, in this order)

| Old module | New module |
|---|---|
| `waqas.base.data.input_contracts` | `fraud.data.input_checks` |
| `waqas.base.data.contracts` | `fraud.data.input_contract` |
| `waqas.base.data.checkpoint_contracts` | `fraud.data.checkpoint_contract` |
| `waqas.base.data.parquet_loader` | `fraud.data.parquet_loader` |
| `waqas.base.data.sequence_builder` | `fraud.data.sequence_builder` (tests only; rule 4.11) |
| `waqas.base.streaming_model` | `fraud.streaming_model` |
| `waqas.base.sequential_model` | `fraud.sequential_model` (tests only; rule 4.11) |
| `waqas.base.scripts.train_streaming` | `fraud.scripts.train_streaming` |
| `waqas.base.scripts.score_streaming` | `fraud.scripts.score_streaming` |
| `waqas.base.scripts.train_baseline` | `fraud.scripts.train_baseline` |
| `waqas.base.scripts.score_eval` | `fraud.scripts.score_eval` |
| `waqas.phase4a.sequential` | `fraud.sequential_model` |
| `waqas.phase4a.factory` | `fraud.sequential_factory` |
| `waqas.phase4a.sequence_builder` | `fraud.data.sequence_builder` |
| `waqas.phase4a.callbacks` | `fraud.callbacks` |
| `waqas.phase4a.tokenizer` | `fraud.tokenizer` |
| `waqas.phase4a.numerical_embeddings` | `fraud.numerical_embeddings` |
| `waqas.phase4a.optim` | `fraud.optim` |
| `waqas.phase4a.scripts.train_sequential` | `fraud.scripts.train_sequential` |
| `waqas.phase4a.scripts.score_sequential` | `fraud.scripts.score_sequential` |
| `waqas.phase4b.sequential_hier` | `fraud.sequential_hier_model` |
| `waqas.phase4b.factory` | `fraud.sequential_hier_factory` |
| `waqas.phase4b.sequence_builder` | `fraud.data.sequence_builder` |
| `waqas.phase4b.callbacks` | `fraud.callbacks` |
| `waqas.phase4b.tokenizer` | `fraud.tokenizer` |
| `waqas.phase4b.numerical_embeddings` | `fraud.numerical_embeddings` |
| `waqas.phase4b.optim` | `fraud.optim` |
| `waqas.phase4b.scripts.train_sequential` | `fraud.scripts.train_sequential_hier_chunk_eval` |
| `waqas.phase4b.scripts.score_sequential` | `fraud.scripts.score_sequential_hier_chunk_eval` |
| `waqas.phase4b.scripts.measure_chunk_widths` | `fraud.scripts.measure_chunk_widths` |
| `waqas.v2.models` | `fraud.sequential_hier_target_ending_model` |
| `waqas.v2.target_ending` | `fraud.data.target_ending` |
| `waqas.v2.storage` | `fraud.data.s3_utils` |
| `waqas.v2.scripts.train_v2` | `fraud.scripts.train_sequential_hier` |
| `waqas.v2.scripts.score_v2` | `fraud.scripts.score_sequential_hier` |
| `waqas.v2.scripts.select_splits` | `fraud.scripts.select_splits` |
| `waqas.v2.scripts.data_inventory` | `fraud.scripts.data_inventory` |
| `waqas.v2.scripts.measure_window_rows` | `fraud.scripts.measure_window_rows` |
| `waqas.v2.analysis.paired_v2` | `fraud.scripts.compare_models` |
| `waqas.v2.analysis.business_metrics` | `fraud.scripts.business_metrics` |
| `waqas.v2.analysis.embedding_diagnostics` | `fraud.experiments.embedding.embedding_diagnostics` |
| `waqas.v2.benchmark_v2` | `fraud.experiments.embedding.benchmark` |
| `waqas.v2.downstream_xgb` | `fraud.experiments.embedding.downstream_xgb` |
| `waqas.v2.export_v2` | `fraud.experiments.embedding.export_embeddings` |
| `waqas.v2.scripts.l4_check` | `fraud.experiments.embedding.check_export` |
| `waqas.v2.scripts.make_v2_contracts` | `fraud.experiments.embedding.export_records` |
| `waqas.v2.scripts.checkpoint_facts` | `fraud.experiments.embedding.checkpoint_facts` |
| `waqas.v2.scripts.check_v1_source` | `fraud.experiments.embedding.source_check` |
| `waqas.v2.features.groups` | `fraud.experiments.features.groups` |
| `waqas.v2.features.strict_window` | `fraud.experiments.features.strict_window` |
| `waqas.v2.screen.<module>` | `fraud.experiments.features.screen.<module>` |
| `waqas.v2.scripts.build_nomonth_artifact` | `fraud.experiments.features.build_nomonth_artifact` |
| `waqas.v2.scripts.check_nomonth_artifact` | `fraud.experiments.features.check_nomonth_artifact` |
| `waqas.v2.scale_runs` | `fraud.experiments.scale.scale_runs` |
| `waqas.v2.data_size_specs` | `fraud.experiments.scale.data_size_specs` |
| `waqas.phase4a.scripts.tune` | `fraud.experiments.tuning.tune` |
| `waqas.scoring._prediction_utils` | `fraud.data.prediction_files` |
| `waqas.scoring.temporal_eval` | `fraud.scripts.temporal_eval` |
| `waqas.scoring.leaderboard` | `fraud.scripts.leaderboard` |
| `waqas.scoring` (as in `from waqas.scoring import temporal_eval`) | `fraud.scripts` |
| `waqas.source_identity` | `fraud.source_files` |
| `waqas.tests.<module>`, `waqas.v2.tests.<module>` | the bare new test module name (section 4.8) |

The same mapping applies to `python -m waqas....` strings in docstrings, usage lines, shell scripts, README files and docs.

### 5.2 Rule for anything not listed

1. A `waqas.*` import of a moved module takes that module's new name from section 4.
2. A `waqas.*` import of an archived module: the importing file goes to `archive/code/=` too, unless it is a kept entry point. In that case stop, leave the import, and report it in group X.
3. After the moves, `grep -rn "waqas" --include=*.py --include=*.yaml --include=*.sh --include=*.toml fraud tests pyproject.toml` must find nothing. Mentions of the person Waqas in Markdown are fine.

### 5.3 References that must move together (CH's checklist)

Check every item below in every kept file:

- Python imports `waqas.base.*`, `waqas.phase4a.*`, `waqas.phase4b.*`, `waqas.v2.*`, `waqas.scoring.*`, `waqas.source_identity`; `python -m` names; `importlib.import_module` and `spec_from_file_location` strings.
- Shell and `subprocess` callers that name script paths (for example `tune.py` and `scale_runs.py` launch scripts by path).
- `sys.path.insert(...)` and `Path(__file__).resolve().parents[N]` depth assumptions (table 5.5).
- README commands and usage lines.
- YAML: `base_config`, `predictors.csv_path`, `artifacts.base`, `artifacts.version`, `output.checkpoint_dir`, `eval.checkpoint` and its `${output.checkpoint_dir}` interpolation, `eval.predictions_base`, `eval.metrics_output`, `output_root`, `results_csv`, `common_overrides`, `train_script`.
- CLI arguments `--config`, `--checkpoint`, `--out`, `--metrics`, `--inventory`, `--runs`, and resume lookup of `last.ckpt` inside `output.checkpoint_dir`.
- Run tables with `prediction_path` and `receipt_path` columns (section 7.4).
- Feature order and artifact loading: `fraud/configs/predictors.csv` and the artifact `manifest.json` stay as they are.
- Package discovery in `pyproject.toml` (`where = ["src", "."]`, `include = ["pytorch_tabular*", "fraud*"]`) and the working directory the tests assume.

### 5.4 Small relocations inside files (no logic change)

| What | From | To |
|---|---|---|
| `THIN_READ_BLOCK_SIZE`, `thin_read_filesystem` | `waqas/v2/storage.py` | end of `fraud/data/s3_utils.py`; drop its `from fraud.data.s3_utils import make_s3_filesystem` line |
| `EMACallback` | `waqas/phase4a/callbacks.py` | end of `fraud/callbacks.py` |
| `read_table` | `fraud/experiments/embedding/benchmark.py` | end of `fraud/data/prediction_files.py`, with the imports it needs (`fsspec`, `pandas`, `pyarrow.parquet`); in `benchmark.py` replace the definition with `from fraud.data.prediction_files import read_table`; the lazy imports in `compare_models.py` and `business_metrics.py` import it from `fraud.data.prediction_files` |
| V1 engine load | `compare_models.py`: `ROOT / "runbook/2026-10-07/paired_report.py"` | `ROOT / "fraud/scripts/paired_bootstrap.py"` (keep the `importlib` loading) |
| Runtime source list | `fraud/source_files.py`: folders `("fraud", "waqas")`, prefixes `("fraud/", "waqas/")` | `("fraud",)` and `("fraud/",)`; `EXCLUDED_SOURCE_PREFIXES` becomes `("tests/", "fraud/experiments/")` |
| Tuning targets | `fraud/experiments/tuning/tune.yaml`: `train_script`, `base_config` | `fraud/scripts/train_sequential.py`, `fraud/configs/sequential.yaml` (what they pointed at before; pointing it at the chosen model is later work) |
| Path constants | `MODEL_PATH_FILES` in `source_check.py`, and every string that names a moved file | the new paths; report any constant compared with paths stored in old records |

### 5.5 Script depth after the move

| Folder | `sys.path.insert` | `Path(__file__).resolve().parents[N]` for the project root |
|---|---|---|
| `fraud/scripts/` | `os.path.join(os.path.dirname(__file__), "..", "..")` | `parents[2]` |
| `fraud/experiments/<purpose>/` | `"..", "..", ".."` | `parents[3]` |
| `fraud/experiments/features/screen/` | `"..", "..", "..", ".."` | `parents[4]` |
| `tests/` | `".."` | `parents[1]` |
| `tests/experiments/<purpose>/` | `"..", "..", ".."` | `parents[3]` |
| `tests/experiments/features/screen/` | `"..", "..", "..", ".."` | `parents[4]` |

Old depths for reference: `waqas/base/scripts/`, `waqas/phase4a/scripts/`, `waqas/phase4b/scripts/` used three `".."`; `waqas/v2/scripts/` and `waqas/v2/analysis/` used `parents[3]`; `runbook/2026-10-07/` used two `".."` (the same depth as `fraud/scripts/`); `waqas/scoring/` used two `".."`; `waqas/tests/` used `parents[2]`.

## 6. Configs and paths

### 6.1 Kept configs

| Config | Default run | Inputs | Outputs |
|---|---|---|---|
| `streaming.yaml` | `models/streaming/seed42` | train `tfm_raw_data` 1 to 10, validation 4950 to 4954, evaluation `tfm_EVAL_raw_data` 8000 to 8010; artifacts K194855 version 1; `fraud/configs/predictors.csv`; credentials path as run | `checkpoints/streaming/` (best.ckpt, training_metrics.csv); predictions under the `eval.predictions_base` you pass |
| `sequential.yaml` | `models/sequential_h15/seed42` | the same data, artifacts, predictors and credentials | `checkpoints/sequential/`; predictions under `predictions/sequential` (UUID names); metrics JSON at `eval.metrics_output` |
| `sequential_hier.yaml` | `models/sequential_hier_h20/seed42` | the same | `checkpoints/sequential_hier/`; predictions under `predictions/sequential_hier`; metrics JSON at `eval.metrics_output` |
| `sequential_hier_allpos.yaml` | `models/sequential_hier_allpos_h20_chunk/seed42` | the same | `checkpoints/sequential_hier_allpos/` (best.ckpt, last.ckpt, training_metrics.csv and the trainer's own run records); predictions to the local `--out` parquet |
| `preprocessing.yaml` | Yaqun's artifact build | training files as he set | his artifact location (unchanged) |
| `predictors.csv` | the 23 predictors | read by every config | none |
| `eval.yaml` | Yaqun's baseline scorer | his paths (unchanged) | his paths |
| `smoke_test.yaml` | Yaqun's baseline trainer | his paths (unchanged) | his paths |

New training always writes under `checkpoints/` (ignored by git), never into `models/`. A run the owner decides to keep is copied into `models/<name>/seed<NN>/` by hand later.

### 6.2 How to build the four base configs

Each base config is the as-run resolved config of its default run, copied unchanged except for the output keys below and a short header comment. This carries the actual settings: validation files 4950 to 4954 (not the generic 4950-only default), batch size, accumulation, window cap and max chunk rows.

| Base config | Copy from (pod, before the move) | Settings to confirm in the copy |
|---|---|---|
| `streaming.yaml` | `ablations/ref_single/ref_single_seeds/REF-SINGLE-53e82983c61845d7b0544e83d5c3768f/seed-s42/resolved_train.yaml` | train 1 to 10, validation 4950 to 4954, 10 epochs, batch 8192, seed 42, eval 8000 to 8010 |
| `sequential.yaml` | `ablations/arch_a_flat/history_h15/20261013T044303Z-4bcdf2ddbdf940dfa8638239d2c791ab/history-h15/resolved_train.yaml` | `model.type: FTTransformerSeq`, history 15, batch 1024 x 4 (as rerun, not the shipped 256 x 16), validation 4950 to 4954, seed 42 |
| `sequential_hier.yaml` | `ablations/arch_b_hier/history_h15_h20/B-H20-1dfa4d00fd924637950e7c6f02c3f887/history-h20/resolved_train.yaml` | `model.type: FTTransformerHier`, history 20, batch 2048 x 2, bidirectional, validation 4950 to 4954, seed 42 |
| `sequential_hier_allpos.yaml` | `runs/v2/L3/ALLPOS_H20_CHUNK/resolved_train_v2.yaml` (compare with `runs/v2/L3/allpos_h20_chunk.yaml`) | history 20, causal, `predict_every_transaction: true`, chunk training (`train_target_ending` absent or false), `max_window_rows: 32`, `max_chunk_rows`, `eval_batch_size: 1024`, `deterministic: false`, batch and accumulation as run, month kept, artifacts version 1 |

If the pod was already reorganized by `organize_pod.py`, the same files are under `models/<old name>/seed42/` (section 7.2); the V2 launch config is then `launch_config.yaml`.

Keys you change in each base config (these are the only differences allowed):

- `output.checkpoint_dir`: `checkpoints/streaming`, `checkpoints/sequential`, `checkpoints/sequential_hier`, `checkpoints/sequential_hier_allpos`.
- `eval.checkpoint`: `${output.checkpoint_dir}/best.ckpt`.
- `eval.metrics_output`: remove it if present; scoring commands pass it.
- `experiment.run_name`, if present: the base config's name without `.yaml`.

Input paths stay exactly as run: `data.train_base`, `data.val_base`, `eval.base`, `artifacts.base`, `artifacts.version`, `predictors.csv_path`, `s3.cred_path`. `eval.predictions_base` keeps its as-run S3 prefix.

Header comment for each base config (four lines, plain):

```
# <model in words>. Default run: models/<name>/seed42; settings are that run's as-run settings.
# Other retained runs: this file plus the overrides in docs/RESULTS.md ("Reproducing each run").
# Train: python -m <trainer module> --config fraud/configs/<file> output.checkpoint_dir=checkpoints/<name>/seed42
# Score: see README.md.
```

### 6.3 The 22 retained runs as base config plus overrides

Every command also gets `output.checkpoint_dir=checkpoints/<name>/seed<NN>` (not repeated below). The overrides are what CL expects from the recorded specs and reports. Your check (step 11) diffs base plus overrides against each run's `config.yaml`. Where the diff differs from this column, the diff is right: use it in the docs and list the difference in group D.

Entry points: `T` = `fraud.scripts.train_streaming`; `A` = `fraud.scripts.train_sequential`; `HC` = `fraud.scripts.train_sequential_hier_chunk_eval`; `H` = `fraud.scripts.train_sequential_hier`.

| Run | Entry point and config | Expected overrides | Seed |
|---|---|---|---|
| `streaming/seed42` | T, `streaming.yaml` | none | 42 |
| `sequential_h0/seed42` | A, `sequential.yaml` | `sequence.history_len=0 training.batch_size=4096 training.accumulate_grad_batches=1` | 42 |
| `sequential_h5/seed42` | A, `sequential.yaml` | `sequence.history_len=5 training.batch_size=4096 training.accumulate_grad_batches=1` | 42 |
| `sequential_h10/seed42` | A, `sequential.yaml` | `sequence.history_len=10` | 42 |
| `sequential_h15/seed42` | A, `sequential.yaml` | none | 42 |
| `sequential_h20/seed42` | A, `sequential.yaml` | `sequence.history_len=20 training.batch_size=512 training.accumulate_grad_batches=8` | 42 |
| `sequential_h5_no_time_gap/seed42` | A, `sequential.yaml` | `sequence.history_len=5 sequence.time_delta=false training.batch_size=4096 training.accumulate_grad_batches=1` | 42 |
| `sequential_h10_no_time_gap/seed42` | A, `sequential.yaml` | `sequence.history_len=10 sequence.time_delta=false training.batch_size=2048 training.accumulate_grad_batches=2` | 42 |
| `sequential_h5_causal/seed42` | A, `sequential.yaml` | `sequence.history_len=5 sequence.attention_mask=causal training.batch_size=4096 training.accumulate_grad_batches=1` | 42 |
| `sequential_hier_h0/seed42` | HC, `sequential_hier.yaml` | `sequence.history_len=0 training.batch_size=4096 training.accumulate_grad_batches=1` | 42 |
| `sequential_hier_h5/seed42` | HC, `sequential_hier.yaml` | `sequence.history_len=5 training.batch_size=4096 training.accumulate_grad_batches=1` | 42 |
| `sequential_hier_h10/seed42` | HC, `sequential_hier.yaml` | `sequence.history_len=10 training.batch_size=4096 training.accumulate_grad_batches=1` | 42 |
| `sequential_hier_h15/seed42` | HC, `sequential_hier.yaml` | `sequence.history_len=15` | 42 |
| `sequential_hier_h20/seed42` | HC, `sequential_hier.yaml` | none | 42 |
| `sequential_hier_h20/seed43` | H, `sequential_hier.yaml` (HC if the run folder has no `run_manifest_v2.json`) | `training.seed=43`, plus `training.deterministic=false` if the as-run config has it | 43 |
| `sequential_hier_h20/seed44` | as seed 43 | `training.seed=44`, plus `training.deterministic=false` if present | 44 |
| `sequential_hier_allpos_h5_chunk/seed42` | HC, `sequential_hier_allpos.yaml` | `sequence.history_len=5 training.batch_size=256 training.accumulate_grad_batches=1 sequence.max_chunk_rows=null` (HC ignores `max_window_rows`, `eval_batch_size`, `deterministic`) | 42 |
| `sequential_hier_allpos_h20_chunk/seed42` | H, `sequential_hier_allpos.yaml` | none | 42 |
| `sequential_hier_allpos_h20_chunk/seed43` | H, `sequential_hier_allpos.yaml` | `training.seed=43` | 43 |
| `sequential_hier_allpos_h20_chunk/seed44` | H, `sequential_hier_allpos.yaml` | `training.seed=44` | 44 |
| `sequential_hier_allpos_h20_sliding/seed42` | H, `sequential_hier_allpos.yaml` | `sequence.train_target_ending=true training.batch_size=1024 training.accumulate_grad_batches=4` | 42 |
| `sequential_hier_allpos_h5_sliding/seed42` | H, `sequential_hier_allpos.yaml` | `sequence.history_len=5 sequence.train_target_ending=true sequence.max_window_rows=8 training.batch_size=1024 training.accumulate_grad_batches=4` (and `sequence.max_chunk_rows=8` if the as-run config has it) | 42 |

Put this table, with each run's Test 1 AP and the confirmed overrides, into `docs/RESULTS.md` as a new section "Reproducing each run", columns `Run | Test 1 AP | Entry point and config | Overrides` (the seed is in the run name). Fill the "Command" column of `docs/EXPERIMENTS.md` from the same rows in the form `<entry point> <config> <overrides> training.seed=<NN>`.

### 6.4 Scoring commands per family

| Family | Scorer | Arguments |
|---|---|---|
| streaming | `python -m fraud.scripts.score_streaming --config fraud/configs/streaming.yaml` | `eval.checkpoint=models/streaming/seed42/best.ckpt eval.predictions_base=<a new S3 prefix> eval.metrics_output=checkpoints/streaming/seed42/test1.json` (the scorer refuses an existing prefix) |
| flat | `python -m fraud.scripts.score_sequential --config fraud/configs/sequential.yaml <run overrides>` | `eval.checkpoint=models/<name>/seed42/best.ckpt eval.metrics_output=checkpoints/<name>/seed42/test1.json` |
| hierarchical, chunk-evaluated | `python -m fraud.scripts.score_sequential_hier_chunk_eval --config fraud/configs/<config> <run overrides>` | the same two keys |
| hierarchical and all-position | `python -m fraud.scripts.score_sequential_hier --config fraud/configs/<config> <run overrides>` | `--checkpoint models/<name>/seed<NN>/best.ckpt --out checkpoints/<name>/seed<NN>/test1.parquet --population DEV_OOT --purpose <label> eval.file_start=8000 eval.file_end=8010` (SELECT: `--population SELECT eval.file_start=8206 eval.file_end=8216`; take the `--purpose` label the original receipts used) |

## 7. Results layout

### 7.1 What each run folder holds

```
models/<name>/seed<NN>/
  best.ckpt                 the scored checkpoint, committed to git
  config.yaml               the exact as-run resolved config, bytes unchanged
  training_metrics.csv      per-epoch metrics written by the trainer
  scores/
    <population>.json       AP, AUROC, rows, frauds and where the predictions are
    <population>.parquet    local prediction file, pod only, ignored by git
```

Copy (do not move) the first three files out of the original run folder, then move the whole original folder to `archive/results/=`. Nothing else from a run folder enters `models/`: `last.ckpt`, logs, manifests, receipts, exposure records and `resolved_score.yaml` stay with the folder in the archive.

Sources inside a run folder:

- V1 trainers (all `sequential_*`, `sequential_hier_h*` seed 42, `sequential_hier_allpos_h5_chunk`, `streaming`): the run subfolder holds `best.ckpt`, `resolved_train.yaml` (becomes `config.yaml`) and `training_metrics.csv`.
- `train_sequential_hier` runs (`sequential_hier_allpos_*` seed 42, both chunk seeds, and probably both reference seeds): the run folder holds `best.ckpt`, `resolved_train_v2.yaml` (becomes `config.yaml`) and `training_metrics.csv`.

Population names, recognised by file range and row count:

| Population | Files | Rows | Frauds |
|---|---|---|---|
| `validation` | training 4950 to 4954 | 4,292,059 | 7,285 |
| `test1` | evaluation 8000 to 8010, all months (DEV_OOT) | 2,466,461 | 3,818 |
| `test1_june` | evaluation 8000 to 8010, June targets | 1,196,737 | 1,703 |
| `select_full` | evaluation 8206 to 8216, May and June | 2,504,003 | 4,187 |
| `select_june` | evaluation 8206 to 8216, June targets | 1,215,218 | 2,081 |

Add the suffix `_windows` when a chunk-validated all-position checkpoint was rescored on one window per transaction (only `sequential_hier_allpos_h5_chunk`). Seed-42 SELECT numbers in the results came from June targets; seed 43 and 44 receipts cover full files. Never merge the two.

Content of `scores/<population>.json` (write it from the receipt or report; no hash fields):

```
{"run": "<name>", "seed": <NN>, "population": "<population>",
 "files": "<base> part_<start> to part_<end>", "targets": "all months" or "June 2025",
 "rows": <n>, "frauds": <n>, "ap": <float>, "auroc": <float>,
 "scored_by": "<new scorer module>", "policy": "<one target per window | chunks | windows capped at N>",
 "predictions": "<models/... parquet path or s3 URI>", "source": "<archive path of the receipt or report>"}
```

When two sources give the same run and population, keep the one the results record used (for V1 runs, the scores named below; otherwise the newest completed one). If they differ by more than 0.00005 in AP, keep the recorded one and report both in group D. Before writing, compare the `checkpoint_sha256` in each receipt with the hash of `best.ckpt` (a check only; no hash goes into the file). If a receipt names a checkpoint other than `best.ckpt`, keep that file next to `best.ckpt` under its own name and report it.

### 7.2 Current folder to new folder for the 22 runs

V1 attempt folders keep a run subfolder (`seed-s42/`, `history-h<N>/`, `time_delta-False/`, `mask-causal/`). If `organize_pod.py apply` already ran, the run is in the third column instead (V1 runs keep their subfolder inside it; V2 runs are flat with `launch_config.yaml`).

| ID | Current pod folder | If organize_pod.py ran | New folder |
|---|---|---|---|
| M01 | `ablations/ref_single/ref_single_seeds/REF-SINGLE-53e82983c61845d7b0544e83d5c3768f/seed-s42/` | `models/ref_single/seed42/` | `models/streaming/seed42/` |
| M02 | `ablations/arch_a_flat/history_h0_vs_h5/A-H00-985f76d541644b5fbc5e9267a03f03b9/history-h0/` | `models/arch_a_h0/seed42/` | `models/sequential_h0/seed42/` |
| M03 | `ablations/arch_a_flat/history_h0_vs_h5/A-H05-d836626fbe0a4d77b0e6f577c5effc49/history-h5/` | `models/arch_a_h5/seed42/` | `models/sequential_h5/seed42/` |
| M04 | `ablations/arch_a_flat/history_h10/A-H10-33a2d72e1b174d09bcb7465f73a976eb/history-h10/` | `models/arch_a_h10/seed42/` | `models/sequential_h10/seed42/` |
| M05 | `ablations/arch_a_flat/history_h15/20261013T044303Z-4bcdf2ddbdf940dfa8638239d2c791ab/history-h15/` | `models/arch_a_h15/seed42/` | `models/sequential_h15/seed42/` |
| M06 | `ablations/arch_a_flat/history_h20/20261013T044636Z-57c3b2c82fc04518b4a1cf4815c40ce3/history-h20/` | `models/arch_a_h20/seed42/` | `models/sequential_h20/seed42/` |
| M07 | `ablations/arch_a_flat/time_delta_off_h5/A-GAP05-OFF-2f38276bb039427394da7f423626008a/time_delta-False/` | `models/arch_a_h5_no_time_gap/seed42/` | `models/sequential_h5_no_time_gap/seed42/` |
| M08 | `ablations/arch_a_flat/time_delta_on_vs_off_h10/20261013T050127Z-0416d54e27ce4212a9dbbbc4fef46e17/time_delta-False/` | `models/arch_a_h10_no_time_gap/seed42/` | `models/sequential_h10_no_time_gap/seed42/` |
| M09 | `ablations/arch_a_flat/mask_causal_h5/A-MASK05-C-b398041fd010460782382cde19821a17/mask-causal/` | `models/arch_a_h5_causal/seed42/` | `models/sequential_h5_causal/seed42/` |
| M10 | `ablations/arch_b_hier/history_h0_scored/B-H00-7815ffe1c5164981a37aa0482353ee46/history-h0/` | `models/arch_b_h0_sliding/seed42/` | `models/sequential_hier_h0/seed42/` |
| M11 | `ablations/arch_b_hier/history_h5_h10/B-H05-e5ea866430004b9c90161d3a48ddc87e/history-h5/` | `models/arch_b_h5_sliding/seed42/` | `models/sequential_hier_h5/seed42/` |
| M12 | `ablations/arch_b_hier/history_h5_h10/B-H10-8a5832ccf8834b5c96c3bdb600063d47/history-h10/` | `models/arch_b_h10_sliding/seed42/` | `models/sequential_hier_h10/seed42/` |
| M13 | `ablations/arch_b_hier/history_h15_h20/B-H15-4d71f33d0e9644b4be7211290b2fb50f/history-h15/` | `models/arch_b_h15_sliding/seed42/` | `models/sequential_hier_h15/seed42/` |
| M14 | `ablations/arch_b_hier/history_h15_h20/B-H20-1dfa4d00fd924637950e7c6f02c3f887/history-h20/` | `models/arch_b_h20_sliding/seed42/` | `models/sequential_hier_h20/seed42/` |
| M15 | `ablations/arch_b_hier/allposition_strict_h5/B-ALLPOS-H5-8e61fcd6c0c842a3b8e3e9925e995118/history-h5/` | `models/arch_b_h5_chunk/seed42/` | `models/sequential_hier_allpos_h5_chunk/seed42/` |
| M16 | `runs/v2/L3/ALLPOS_H20_CHUNK/` | `models/arch_b_h20_chunk/seed42/` | `models/sequential_hier_allpos_h20_chunk/seed42/` |
| M17 | `runs/v2/L3/ALLPOS_H20_SLIDE/` | `models/arch_b_h20_chunk_design_trained_sliding/seed42/` | `models/sequential_hier_allpos_h20_sliding/seed42/` |
| M18 | `runs/v2/L3/ALLPOS_H5_SLIDE/` | `models/arch_b_h5_chunk_design_trained_sliding/seed42/` | `models/sequential_hier_allpos_h5_sliding/seed42/` |
| M19 | `runs/v2/seed_robustness/ALLPOS_H20_CHUNK_seed43/` | `models/arch_b_h20_chunk/seed43/` | `models/sequential_hier_allpos_h20_chunk/seed43/` |
| M20 | `runs/v2/seed_robustness/ALLPOS_H20_CHUNK_seed44/` | `models/arch_b_h20_chunk/seed44/` | `models/sequential_hier_allpos_h20_chunk/seed44/` |
| M21 | `runs/v2/seed_robustness/B_H20_seed43/` | `models/arch_b_h20_sliding/seed43/` | `models/sequential_hier_h20/seed43/` |
| M22 | `runs/v2/seed_robustness/B_H20_seed44/` | `models/arch_b_h20_sliding/seed44/` | `models/sequential_hier_h20/seed44/` |

### 7.3 Where each run's scores are

| Runs | Population | Source | Note |
|---|---|---|---|
| M01, M04, M05, M07, M09 to M12, M15 | `test1` | `score_metrics.json` in the run subfolder | written by the sweep runner |
| M06 | `test1` | `score_metrics.json` in the run subfolder if present, else the `runs/v2/arch_a_scores_retry3/` receipt | it was still training when the architecture report was written; 0.0817 is recorded |
| M02 | `test1` | `post_score/20261013T142729Z-3e623b2737ec4a8788c658cc128b7330/post_score_metrics.json` in the run subfolder | post-hoc score; other `post_score/` folders are tries the record did not use |
| M03 | `test1` | `post_score/20261013T142809Z-2632432f71714f19b96c2146a7c6de55/post_score_metrics.json` | as M02 |
| M08 | `test1` | `post_score/20261013T142924Z-e83716f0a7904462a90654f888ba642c/post_score_metrics.json` | as M02 |
| M13 | `test1` | `manual_score/20261013T142741Z/score_metrics.json` (in the attempt folder or the run subfolder) | scored by hand; check its checkpoint hash against `best.ckpt` |
| M14 | `test1` | `manual_score/20261013T142910Z/score_metrics.json` | the presented 0.0955; check its checkpoint hash against `best.ckpt` |
| M02 to M09 | `validation`, `test1`, `select_full`, `select_june` | `runs/v2/arch_a_scores_retry3/` receipts and `individual_scores.csv` rows | sort by row count; `runs/v2/arch_a_scores/` and other retries are failed tries |
| M13, M14, M16, M17, M18 | `test1`, `select_full` (and `validation` if present) | `runs/v2/L3/scores_slide/` receipts and parquet files | each receipt names its checkpoint |
| M13, M14, M16, M17, M18 | `select_june` (and `test1_june` if reported) | the paired reports in `runs/v2/L3/paired_SELECT_followup/` (and `paired_DEV_OOT_followup/`) | AP and AUROC of that model on the June rows |
| M15 | `test1_windows` | newest complete run in `waqas/scoring/allpos_sliding_h5/<run id>/` | AP 0.0934 was reported |
| M19, M20 | `test1`, `select_full` | `score_DEV_OOT.parquet.json`, `score_SELECT.parquet.json` in the seed folder | |
| M21, M22 | `test1`, `select_full` | `score_DEV_OOT.json`, `score_SELECT.json` in the seed folder | |

### 7.4 Shared results: `splits/` and `comparisons/`

| Current pod path | New path | Note |
|---|---|---|
| `runs/v2/step1/L2_selected/split_v2.yaml` (or the one split file the folder holds) | `splits/populations.yaml` | the frozen populations |
| `runs/v2/step1/L2_selected/selection_report.json` | `splits/selection_report.json` | how they were chosen |
| `runs/v2/step1/L2_selected/population_roles_v2.yaml` | `splits/population_roles.yaml` | allowed use of each population |
| `runs/v2/L2_inventory/inventory.json` | `splits/file_inventory.json` | per-file counts; input of `select_splits.py` |
| `runs/v2/L3/measure/window_rows_h20.json` | `splits/window_rows_h20.json` | gave the cap 32 |
| `runs/v2/L3/measure/window_rows_h5.json` | `splits/window_rows_h5.json` | gave the cap 8 |
| `runs/v2/L3/measure/chunk_widths_h20.json` | `splits/chunk_widths_h20.json` | widest strict chunk |
| every other file in those three folders (`*.sha256`, manifests, logs) | `archive/records/=` | |
| `runs/v2/L3/paired_DEV_OOT_followup/` | `comparisons/chunk_vs_sliding_test1/` | report files only; exposure, receipt, manifest and hash files to `archive/records/=` |
| `runs/v2/L3/paired_SELECT_followup/` | `comparisons/chunk_vs_sliding_select_june/` | the same split |
| `runs/v2/L3/paired_inputs_followup/` | `comparisons/chunk_vs_sliding_inputs/` | path-updated copies of the run tables: `prediction_path` to `models/<name>/seed<NN>/scores/<population>.parquet`, `receipt_path` to the receipt's archive path (`compare_models.py` checks receipts); originals to `archive/results/=` |
| `runs/v2/arch_a_scores_retry3/individual_scores.csv` | `comparisons/sequential_rescore.csv` | 24 rows, 8 flat models x 3 populations |
| `v1_analysis_outputs/run_table.csv` | `comparisons/architecture_run_table.csv` | the architecture study's run table |
| newest complete paired report among `runs/paired_report/`, `runs/paired_report_v1/` | `comparisons/architecture_paired/` | report files only; name the one you kept in group D |
| `runs/paired_report_finalist/` | `comparisons/architecture_paired_finalists/` | report files only |
| (new file) | `comparisons/seed_check.csv` | you write it: `run,seed,test1_ap,test1_auroc` for the six H20 runs, from their `scores/test1.json` |

If `organize_pod.py` ran, the same content is under `shared/populations/selected/`, `shared/populations/inventory/`, `shared/measurements/`, `shared/comparisons/v2_paired_test1/`, `v2_paired_holdout/`, `v2_paired_inputs/`, `arch_a_rescore/`, `v1/`; map it the same way.

### 7.5 Items not in this map (unknown items rule)

The pod may hold runs, results, scripts or configs that neither CH nor CL know about. Decide each one by this rule and list every one in group U:

- **(a)** A folder with a trained checkpoint is a run. Name it with the model naming scheme from its resolved config: `streaming`, `sequential_h<N>` (flat; add `_no_time_gap` when `sequence.time_delta` is false, `_causal` when `sequence.attention_mask` is causal), `sequential_hier_h<N>` (hierarchical, one target), `sequential_hier_allpos_h<N>_chunk` or `_sliding` (all-position; `_sliding` when `sequence.train_target_ending` is true). Place it in `models/<name>/seed<NN>/` from `training.seed`. If that folder already holds a retained run, or the name cannot be worked out (for example a feature change or a capacity change), put it in `models/unsorted/<original folder name>/`.
- **(b)** Score files belong to the run whose checkpoint they name.
- **(c)** Diagnostics, quick checks, data looks, logs of finished work, temporary and extraction folders go to `archive/diagnostics/=` or `archive/results/=`.
- **(d)** Code or configs not in the map go to `archive/code/=`, unless a kept entry point imports them. Then they move with that entry point into the same folder and you report it.
- **(e)** Anything that looks like the 14-day account consumer or the embedding store (a vector store with snapshots, earlier-time lookup or a next-14-day consumer) goes to `archive/code/=`; it is dropped.
- **(f)** S3 objects are never moved or deleted; record their URIs only.

## 8. Archive

`archive/` is a plain folder on the pod and on the laptop, listed in `.gitignore` and never pushed. Every item keeps its original path relative to the project root under its group. If `organize_pod.py` already made an `archive/`, move its content into `archive/results/` unchanged.

| Group | What goes there |
|---|---|
| `archive/code/` | Yaqun's replaced files; superseded `waqas/` code, configs, specs, sweep runners, smoke and seed grids, package markers; runbooks; patch scripts; pod hand-run tools; archived tests; `runs/v2/env.sh`; the launch configs `runs/v2/L3/allpos_h20_chunk.yaml`, `allpos_h20_slide.yaml`, `allpos_h5_slide.yaml` (after step 8 has used them); seed launch scripts `runs/v2/seed_robustness/run_seed43.sh`, `run_seed44.sh` and the generated per-seed configs |
| `archive/results/` | every original run and attempt folder under `ablations/` and `runs/` after the kept files are copied out; retries and failed attempts (`runs/v2/arch_a_scores/` and any `arch_a_scores_retry*` other than `retry3`; the stopped attempts `ablations/arch_a_flat/history_h15/A-H15-84ce...`, `ablations/arch_a_flat/history_h20/A-H20-285e...`, `ablations/arch_a_flat/history_h20/20261013T044303Z-5338...` and `ablations/arch_a_flat/time_delta_on_vs_off_h10/A-GAP10-OFF-e220...`; `ablations/arch_b_hier/history_h5_h10/old/`); unused `post_score/` and `manual_score/` folders; `last.ckpt` files; old score and prediction folders; `runs/run_log.csv`, `runs/returns/` (except quick checks); training and scoring logs, `nohup.out`, `*.out`, `*.log`; never-run proposal folders if present (`ablations/stage2_seeds_20261022/`, `runs/stage2_seeds_20261022/`, `ablations/v2/data_size/scale100_v006/`, `runs/v2/step2/` and similar) |
| `archive/records/` | install records (`runs/install/`), patch receipts (`runs/v2/patches/`), hash and manifest files, the reorganization records (`shared/reorg/`), result reports and review files (`waqas/results_from_pod/`), planning docs, transcription provenance, emails |
| `archive/packages/` | package zips and extraction folders, `reviewer_packages/`, `.tf_install/`, `tf_package/`, `tf_packages/`, `*_UTC.zip`, `*_personalized.zip`, `L3F_return_*.zip`, `send_reviewer/`, `v1_full_review_*.zip`, `pod_reorg_20261027_v3.zip`, package install files at the root |
| `archive/diagnostics/` | data looks (`runs/v2/data_look/`, `runs/v2/step0/`), quick checks (`runs/returns/quick_checks_20261021T232641Z/`, `quick_checks_20261021T235529Z/`), the window rescore of the h5 chunk model (`waqas/scoring/allpos_sliding_h5/` except its kept score), `runs/v2/step0_logs/`, other closed-study diagnostics |

Assistant collaboration folders, if the branch holds them (`bridge/`, `chatgpt/`, `claude/`, `guide/`, `explainer/`, `code_tour/`, `business_guides/`, `reconstruction/`, `Update Overview/`, `updates*`, `11_01_2026/`, `AGENTS.md`, `CLAUDE.md`), go to `archive/records/=`.

Delete, not archive, only caches: every `__pycache__/`, `*.pyc`, `.pytest_cache/`, `.ruff_cache/`, `.mypy_cache/`, `.ipynb_checkpoints/`, and `waqas/phase5_pretrain/__pycache__/`.

## 9. Repository files

### 9.1 `.gitignore` (replace the whole file)

```
# Python and tool caches
__pycache__/
*.pyc
*.egg-info/
build/
dist/
.ipynb_checkpoints/
.pytest_cache/
.mypy_cache/
.ruff_cache/
.cache/
.pt_tmp/
.DS_Store

# Training outputs and logs (kept results live in models/)
checkpoints/
lightning_logs/
logs/
tb_logs/
saved_models/
outputs/
*.log
*.out
*.ckpt
!models/*/seed*/best.ckpt
*.parquet

# Local only
archive/
handoff/
*.sha256

# Local or pod-specific config
*.local.yaml
*.local.yml
local_*.yaml

# Local files that stay out of git
/test.yaml
S3_credentials.yml
.gradle
.npmrc
pip.conf
NuGet.Config
*.pem
*.key
.env
```

Check with `git check-ignore -v` that every `models/*/seed*/best.ckpt` is not ignored and every `*.parquet` and `archive/` file is. Check each `best.ckpt` is under 50 MB and report the largest size.

### 9.2 `pyproject.toml` and `requirements.txt`

- `pyproject.toml`: set `build-backend = "setuptools.build_meta"` (the current `setuptools.backends._legacy:_Backend` does not exist, so `pip install -e .` fails). Add `"pyyaml>=5.1.0"`, `"requests"` and `"pytorch-tabnet"` to `dependencies` (the vendored `pytorch_tabular` imports the last two). Keep the existing dependencies, including `xgboost`, which the feature screen and downstream XGBoost use. Keep `[tool.setuptools.packages.find]` as it is. Add:

```
[tool.pytest.ini_options]
testpaths = ["tests"]
pythonpath = ["src", "."]
```

- `requirements.txt`: add `requests` and `pytorch-tabnet`.

## 10. Steps for Copilot

1. Read this whole document, then `background/BACKGROUND.md` and `changes_tracker/CHANGES_FROM_HANDOFF.md`. Use your Part 1 detail files to locate every path.
2. In the working project: `git status` must be clean on `waqas`. Create the work branch: `git checkout -b waqas-organized waqas`. Do not push.
3. Make sure the three patched pod files are the live copies (table 4.6). If the branch holds unpatched copies, copy the pod snapshot files over them first and commit that alone ("Take the patched pod copies of train_v2.py, models.py, select_splits.py").
4. Delete the caches (section 8, last paragraph).
5. Do the code moves of sections 4.1 to 4.10 in this order: data modules, model modules and factories, scripts, experiments, docs, then tests (4.8, 4.9), then archive moves. Create `fraud/experiments/tuning/`, `features/`, `features/screen/`, `features/reference/`, `scale/`, `embedding/`, and `tests/data/configs/`, `tests/experiments/embedding/`, `tests/experiments/features/screen/`. Do not add `__init__.py` to `fraud/scripts/` or `fraud/experiments/` (namespace imports work, as in Yaqun's tree).
6. Write the four two-line READMEs exactly:
   - `fraud/experiments/tuning/README.md`: "Hyperparameter tuning: tune.py runs an Optuna search over the trainer; tune.yaml holds the search space." / "Built, not run yet. No tuning has been done; point tune.yaml at the chosen model's trainer and config before the first run."
   - `fraud/experiments/features/README.md`: "New features (TFM V32B, the 15298 model, month removed): feature groups, strict-window helpers, the feature screen, the no-month preprocessing builder and reference tables in reference/." / "Built, not run yet. No expanded-feature model has been trained."
   - `fraud/experiments/scale/README.md`: "Training on 100 files: scale_runs.py prepares and collects the 100-file runs; data_size_specs.py prints data-size configs from existing run configs." / "Built, not run yet. scale_runs.py drives the archived sweep runner; a trainer command with data.train_end=100 does the same job."
   - `fraud/experiments/embedding/README.md`: "Embedding work: export of the vector before the fraud head (export_embeddings.py), its check (check_export.py), diagnostics, downstream XGBoost and the benchmark. The 15298 offset model and the TFM comparison are not built." / "Built, not run yet. The 14-day account consumer and the embedding store are dropped."
7. Apply sections 5.1 to 5.5 to every kept file.
8. Build the four base configs (section 6.2).
9. Build `models/`, `splits/` and `comparisons/` from the pod snapshot (section 7), and place unknown items (section 7.5). On the laptop, put the archived pod content in the laptop's `archive/` the same way.
10. Docs:
    - copy `tab_fraud_reorg/RESULTS.md` to `docs/RESULTS.md` and `tab_fraud_reorg/EXPERIMENTS.md` to `docs/EXPERIMENTS.md`; add the reproduction section (6.3) and fill the command column; change no number;
    - write `docs/CHANGES.md`: a heading "Changes to the code since Yaqun's handoff", then sections 1 to 3 of `changes_tracker/CHANGES_FROM_HANDOFF.md` (C01 to C20) unchanged with one line saying their paths are the paths before the reorganization, then the old-to-new table of every kept file from section 4;
    - update `README.md`: keep Yaqun's introduction; replace the structure block with the tree of section 3 (folders and main files); replace "Phase 2 ... Coming Soon" with the commands below; fix the link `../saint/docs/fraud_detection_plan.md` to `docs/fraud_detection_plan_overall.md`; add install (`pip install -e ".[dev]"`) and test (`pytest`) lines; point to `docs/RESULTS.md`, `docs/EXPERIMENTS.md`, `models/` and `fraud/experiments/`.
    - README commands, all run from the project root: one block per entry point of the list in step 12, using `python -m fraud.scripts.<name>`. Use the training and scoring commands of section 6.3 and 6.4 with the default run of each base config. For the data and comparison tools use the command that actually ran (from the logs and receipts you found in Part 1) with paths changed to the new tree; where no command was recorded, give the `--help` form and the required arguments.
11. Write `handoff/check_configs.py` (outside the project tree) that, for each of the 22 runs, merges the base config with the overrides of section 6.3 and `training.seed`, resolves both configs, flattens them to dotted keys, and lists every key whose value differs from `models/<name>/seed<NN>/config.yaml`, ignoring only `output.*`, `eval.checkpoint`, `eval.predictions_base`, `eval.metrics_output` and `experiment.run_name`. A key present only in the base config is allowed when that run's trainer does not read it (for example `training.deterministic`, `training.eval_batch_size` and `sequence.max_window_rows` for the V1 trainers); list such keys. Fix the overrides until every run shows no other difference, then update 6.3's rows in `docs/RESULTS.md` and `docs/EXPERIMENTS.md`.
12. Run the checks, in a fresh shell, from the project root, with no `waqas` folder present:
    - import check of every kept entry point: `python -c "import importlib; importlib.import_module('fraud.scripts.<name>')"` and `python -m fraud.scripts.<name> --help` for `build_preprocessing_artifacts`, `train_baseline`, `score_eval`, `show_progress`, `train_streaming`, `score_streaming`, `train_sequential`, `score_sequential`, `train_sequential_hier`, `score_sequential_hier`, `train_sequential_hier_chunk_eval`, `score_sequential_hier_chunk_eval`, `data_inventory`, `select_splits`, `measure_window_rows`, `measure_chunk_widths`, `compare_models`, `paired_bootstrap`, `business_metrics`, `temporal_eval`, `leaderboard`; `bash -n` for `check_pid.sh` and `fix_ssh_permissions.sh`; the import part only for every module in `fraud/experiments/`;
    - `python -m compileall -q fraud tests`;
    - `pytest` (kept tests) and `pytest tests/experiments` reported separately;
    - dry config load of each kept config: `OmegaConf.load` and `OmegaConf.to_container(resolve=True)` for all eight files in `fraud/configs/`; `fraud.data.feature_list.load_feature_list` on `predictors.csv`; `fraud.sequential_hier_factory.sequence_dataset_options` on `sequential_hier.yaml` and `sequential_hier_allpos.yaml`; `handoff/check_configs.py` for the 22 runs;
    - checkpoint load of the 22 `best.ckpt`: `torch.load(path, map_location="cpu", weights_only=False)` must not raise (a `waqas` module named inside a checkpoint shows here); for the history models also `<model class>.load_from_checkpoint(path, map_location="cpu")` with `FTTransformerSeqModel` (flat) or `FTTransformerHierModel` (hierarchical and all-position); and check that the checkpoint's epoch has the highest `valid_ap` in that run's `training_metrics.csv`. Report failures; do not edit a checkpoint;
    - name check: no folder or file name in the tree (outside `archive/`, `src/`, `.git/`, and Yaqun's own file names) matches `v[0-9]`, `l[0-9]`, `stage`, `phase4a`, `phase4b`, `package`, `attempt`, `retry`, an 8-digit date or a long hex id;
    - `git status` shows no cache, parquet, archive, test.yaml or hash file staged.
13. Write `handoff/POD_MOVES.sh` and `handoff/POD_STEPS.md` (at most 20 lines) for the pod. `POD_MOVES.sh` lists one `mkdir -p` and `mv -n` line per pod-only move of sections 7 and 8 (prediction parquet files into `models/<name>/seed<NN>/scores/`, everything archived into `archive/`), stops if `pgrep -f "fraud.scripts|waqas|train_v2|score_v2"` finds a job, and stops if a target already exists. `POD_STEPS.md` says how to bring the organized branch onto the pod (if the pod root is a git checkout, check out the branch; if not, say what to copy), then run `POD_MOVES.sh`, then the import check of step 12. The owner runs it; you do not.
14. Commit on `waqas-organized` in a few plain commits (code moves; imports and paths; configs; models, splits and comparisons; docs; checks). Do not push.
15. Write `handoff/REORG_REPORT.md` (section 11) and put the full detail in `handoff/detail/REORG.md` under the same IDs.

## 11. Copilot's report: `handoff/REORG_REPORT.md`

The owner copies it by hand, so it must be at most 60 lines, each at most 90 characters. Line 1 is `--- page 1 of 2 ---`; line 41 is `--- page 2 of 2 ---` (use `1 of 1` if it fits in 40 lines). Group items; every line starts with its ID. Full detail goes to `handoff/detail/REORG.md` under the same IDs, for later requests such as "show D3".

```
--- page 1 of 2 ---
R0 branch waqas-organized at <short commit>; <date and time UTC>; <N> files moved
T1 fraud/: configs, data, scripts, experiments/{tuning,features,scale,embedding}
T2 models/: <the folder names, comma separated, wrapped over 2 or 3 lines>
T3 root: docs, notebooks, src, splits, comparisons, tests, archive (local)
M01 streaming/42 T1 0.0925/0.9487 SJ - SF - V <ap or ->
M02 sequential_h0/42 T1 <ap>/<auroc> SJ <ap> SF <ap> V <ap>
... one line per run, M01 to M22, in the order of table 7.2; read every value from
    the scores files; T1 = test1 AP/AUROC, SJ = select_june AP, SF = select_full AP,
    V = validation AP, W = test1_windows AP for M15; "-" when there is no file
U1 <old path> -> <new path> (<rule a to f>, one line each, most important first)
D1 <what differed from this plan> -> <what you did>
--- page 2 of 2 ---
E1 entry points: import <n>/21 OK, --help <n>/21 OK, shell <n>/2 OK; failures: ...
C1 compileall OK|fail; pytest <passed>/<failed>/<skipped>; experiments <p>/<f>/<s>
C2 checkpoints: torch.load <n>/22, load_from_checkpoint <n>/21, best epoch <n>/22
C3 configs: <n>/22 equal to config.yaml; allowed extra keys: ...
C4 scores matched to their checkpoint by hash: <n>/<n>; largest best.ckpt <MB>
X1 <anything that could not be made to run, with the error in a few words>
Q1 <question for the owner or CL, with why it matters>
```

What CL needs from this report: the final folder tree; one line per run with Test 1 AP and AUROC (this is how CL learns of results it did not know about); every item placed by the unknown-items rule; every place where the actual file differed from this plan and what you did; every entry point and whether it ran; anything that could not be made to run. If there are more U or D items than fit, give the count and the most important ones, and keep the rest in the detail file.
