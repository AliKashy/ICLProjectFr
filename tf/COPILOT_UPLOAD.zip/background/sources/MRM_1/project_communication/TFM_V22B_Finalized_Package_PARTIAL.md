# TFM V22B Finalized Package

> **RECONSTRUCTION STATUS: PARTIAL / BLOCKED.** The Dropbox screenshots omit source content inside COM-011, do not fully expose the COM-013 Evidence gap row, and do not prove EOF after Appendix A. Bracketed BLOCKED markers below are reconstruction notes and are not part of the source document.

## 1. Package purpose and governing rules

This package is the finalized handoff for the controlled TFM v22b reconstruction. It consolidates the authoritative communication record recovered to date, the current run configuration, the required artifact inventory, and the validation gates that remain open.

In derivative narrative, “Developer” refers to Sumegha, Shubham, and the code-producing or artifact-supplying team. Primary source references remain traceable through source titles and reference IDs.

The controlled objective is source-faithful execution and independent validation. Reproducing the Developer script does not, by itself, resolve leakage, chronology, duplication, train/eval separation, or historical provenance questions.

## 2. Controlled run snapshot

| Field | Resolved value |
|---|---|
| Active project | TFM V22B controlled fraud fine-tuning reconstruction |
| Full-run script | /home/jovyan/k194855/TFM/Validation/V22B/Reproduction/accum_4/scripts/distributed_finetune_accum4_full.py |
| Run directory | /home/jovyan/k194855/TFM/Validation/V22B/Reproduction/accum_4/runs/controlled_10000step_accum4 |
| Starting checkpoint | /home/jovyan/k194855/TFM/Validation/V22B/Reproduction/runtime_assets/checkpoint-intermediate-step-6500 |
| Tokenizer | /home/jovyan/k194855/TFM/Validation/V22B/Reproduction/accum_4/runtime_assets/tokenizer_runtime |
| Train data | s3://mrmcd-analytics-mrm-mmr-dsai/tfm_v22b_dropcpr_falcondecline/train/ |
| Eval data | s3://mrmcd-analytics-mrm-mmr-dsai/tfm_v22b_dropcpr_falcondecline/eval/ |
| Train files discovered | 5,000 Parquets |
| Eval files discovered | 10 Parquets |
| Optimizer | muon_adamw |
| Max steps | 10,000 |
| Batch size | 32 |
| Gradient accumulation | 4 |
| Effective batch size | 128 on one GPU |
| Learning rates | base=1e-4; head=1e-4 |
| Weight decay | 0.2 |
| Warmup | 300 steps |
| Pool strategy | last |
| Composite loss | enabled: BCE=1.0, pairwise=0.5, approx outsort=0.0, top-k UDR=2.0 |
| Amount weighting | enabled |
| Precision | BF16 |
| Checkpoint interval | 500 optimizer steps |
| Training-time eval | every 500 steps; one eval file; 20% stratified subsample |
| Resume | None |

## 3. Current run evidence

The long run was launched under nohup using the controlled full-run script and protected output directory. The trainer uses the H200 GPU and writes checkpoints every 500 optimizer steps.

Confirmed log evidence in the working conversation showed the run reached step 4,000 and entered the scheduled step-4,000 evaluation. The most recently confirmed completed checkpoint at that point was step 3,500.

Training-time evaluations are not a fixed-population curve: each call loads one eval file and uses a deterministic 20% stratified subsample. Final claims must come from standalone scoring on the complete selected OOT population.

## 4. Final communication register

The register below captures every project-related communication recovered for this package, including small operational messages. “Supported” means the statement is directly present in the cited source; it does not mean the underlying model-risk question is resolved.

### COM-001 | 2026-07-28 | Internal TFM introduction

| Field | Value |
|---|---|
| Type | Meeting / project record |
| Source role | Internal project record |
| Classification | Meeting record; no transcript |
| Communication | Internal introduction to the Transaction Foundation Model. Project record says the repository was being organized and access would follow; presentation materials were referenced. |
| Decision / interpretation | Use presentation and repository artifacts as context, but do not treat reconstructed notes as transcript evidence. |
| Artifacts / paths | 2026-05-15 FrontierAI Transaction Foundation Model presentation |
| Effect on controlled run | Established the review scope: data, representation, architecture, pretraining, fine-tuning, evaluation, and reuse. |
| Primary source | Confluence notification; turn238search17; 28 Jul entry |
| Status | Supported |
| Evidence gap | Meeting transcript unavailable. |

### COM-002 | 2026-08-05 09:00-11:00 | Foundation model code walkthrough

| Field | Value |
|---|---|
| Type | Meeting |
| Source role | Internal organizer |
| Classification | Calendar event; not transcribed |
| Communication | A two-hour code walkthrough was scheduled in Microsoft Teams. |
| Decision / interpretation | Use source files, screen-derived notes, and related messages for implementation evidence. |
| Artifacts / paths | Related email: RE: Internal foundation model introduction |
| Effect on controlled run | Supports that code walkthrough activity occurred, but provides no transcript content. |
| Primary source | Meeting event; turn238search54 |
| Status | Supported |
| Evidence gap | No transcript; invite list does not prove attendance. |

### COM-003 | 2026-08-17 09:13 | TFM Debit Card raw data copy

| Field | Value |
|---|---|
| Type | Email |
| Source role | Developer |
| Classification | Direct Developer communication |
| Communication | Developer stated that raw data used to pretrain and fine-tune TFM was copied to the shared S3 bucket. Training data ranges from 102024 to 052025. Testing data is 062025 with 052025 histories. Data is partitioned by account into 10,000 buckets; at most 5,000 files were used for training and 2,000 for testing. |
| Decision / interpretation | Treat the supplied S3 package and account-partition statement as authoritative communication, subject to direct artifact verification. |
| Artifacts / paths | s3://mrmcd-analytics-mrm-mmr-dsai/tfm_raw_data/; s3://mrmcd-analytics-mrm-mmr-dsai/tfm_EVAL_raw_data/ |
| Effect on controlled run | Explains the historical raw-data scope and why the controlled replication targets a subset of account-partitioned files. |
| Primary source | Email conversation TFM Debit Card raw data copy; turn238search14 lines 127-146 |
| Status | Supported |
| Evidence gap | Historical raw-data paths differ from the later prepared v22b train/eval package. |

### COM-004 | 2026-08-17 11:25-11:36 | Internal foundation model introduction

| Field | Value |
|---|---|
| Type | Teams meeting chat |
| Source role | Developer |
| Classification | Direct Developer communication |
| Communication | Developer identified transaction_dttm as the transaction-time column. Developer said the data has more features than the data sheet; tokenizer configuration contains concise feature summary statistics, while feature descriptions should be obtained from metadata tables. |
| Decision / interpretation | Use transaction_dttm for time lineage and pair tokenizer configuration with metadata tables. |
| Artifacts / paths | Tokenizer configuration; feature metadata tables |
| Effect on controlled run | Defines the field and documentation sources required for chronology and feature-lineage validation. |
| Primary source | Teams chat; turn238search37 |
| Status | Supported |
| Evidence gap | Exact metadata files still need to be retained with the final evidence package. |

### COM-005 | 2026-08-18 21:42 | TFM Debit Card raw data copy

| Field | Value |
|---|---|
| Type | Email |
| Source role | Developer |
| Classification | Direct Developer communication |
| Communication | Developer stated that the best-performing v22b version used the last 17 transactions, had no maximum time-based lookback, was limited by fixed sequence length, and could pad sequences shorter than max sequence length 2048. |
| Decision / interpretation | Retain as a historical v22b design statement. Do not silently override the controlled script setting window_size=None without direct implementation evidence. |
| Artifacts / paths | Historical v22b design; max_seq_len 2048 |
| Effect on controlled run | Creates a specific validation question: reconcile the historical last-17 statement with the prepared Parquets and executable configuration. |
| Primary source | Email conversation; turn238search14 lines 78-94 |
| Status | Supported |
| Evidence gap | Historical exact run configuration not attached. |

### COM-006 | 2026-08-19 21:35 | TFM Debit Card raw data copy

| Field | Value |
|---|---|
| Type | Email |
| Source role | Developer |
| Classification | Direct Developer communication |
| Communication | Developer clarified that operational use would require retaining the last 17 transaction token IDs per account regardless of a time-period lookback, and that reducing the number of retained transactions would improve operational efficiency more directly. |
| Decision / interpretation | Separate transaction-count history from calendar-time lookback. |
| Artifacts / paths | Last-17 token history statement |
| Effect on controlled run | Supports chronology and production-feasibility analysis. |
| Primary source | Email conversation; turn238search14 lines 42-58 |
| Status | Supported |
| Evidence gap | No production implementation supplied. |

### COM-007 | 2026-08-24 08:56-09:14 | GPU pod handoff and ground rules

| Field | Value |
|---|---|
| Type | Teams chat |
| Source role | Developer |
| Classification | Direct Developer communication; operational |
| Communication | Developer authorized use of LEW-extrasmall-6, asked that the usage list be updated, described the pod as a shared computer, instructed use of a personal subfolder, warned against overwriting others’ work, and required usage-note updates. |
| Decision / interpretation | Use isolated k194855 project paths and avoid touching other users’ processes or artifacts. |
| Artifacts / paths | LEW-extrasmall-6 shared pod |
| Effect on controlled run | Directly governs workspace isolation, resource checks, and output-path protection. |
| Primary source | Teams chat; turn238search39 |
| Status | Supported |
| Evidence gap | None. |

### COM-008 | 2026-08-31 15:46-15:51 | TFM Debit Card raw data copy

| Field | Value |
|---|---|
| Type | Email |
| Source role | Developer |
| Classification | Direct Developer communication |
| Communication | Internal reviewer asked whether files 5001-7999 were omitted and whether an account appears in only one Parquet. Developer answered “Yes” to both and added that TFM often converges earlier and does not require the full training data. |
| Decision / interpretation | Follow the 5,000-file training scope; treat account partitioning as a communicated property that must still be validated from artifacts when possible. |
| Artifacts / paths | 5,000 training Parquets; account partitioning |
| Effect on controlled run | Resolves the intended file scope for the controlled replication. |
| Primary source | Email conversation; turn238search14 lines 0-40 |
| Status | Supported |
| Evidence gap | The short “Yes” answers depend on question order; retained together with the preceding questions. |

### COM-009 | 2026-08-31 15:47-16:53 | Missing-file scope, repository, and implementation files

| Field | Value |
|---|---|
| Type | Teams chat |
| Source role | Internal project participant |
| Classification | Relayed Developer confirmation plus internal discussion |
| Communication | Internal participant reported Developer confirmation that Parquets 5001-7999 were not used and recommended following that scope. Discussion identified the develop-branch repository plus a separate Implementation_Files_TFM folder containing checkpoints, PKL files, epoch data, and possibly version-misaligned code. |
| Decision / interpretation | Keep GitHub source, shared implementation artifacts, and controlled outputs separate; verify provenance before using copied implementation files as proof. |
| Artifacts / paths | k102157/txn-foundation-model develop branch; Implementation_Files_TFM |
| Effect on controlled run | Explains why controlled scripts were derived from supplied source rather than copied historical artifacts. |
| Primary source | Teams chat; turn238search36 line 3 |
| Status | Supported |
| Evidence gap | Exact version mapping of Implementation_Files_TFM remains uncertain. |

### COM-010 | 2026-09-01 09:30 | No training notebook

| Field | Value |
|---|---|
| Type | Teams chat |
| Source role | Internal project participant relaying Developer |
| Classification | Relayed Developer communication |
| Communication | Internal participant reported that Developer said there was no training notebook; training and evaluation were run directly as scripts, with README files and specific documentation guiding which scripts matter and how to run them. |
| Decision / interpretation | Treat distributed_finetune.py, fraud_eval.py, configs, README files, and runtime outputs as the implementation path. |
| Artifacts / paths | Source scripts and README documentation |
| Effect on controlled run | Prevents inventing or searching for a nonexistent official notebook. |
| Primary source | Teams chat; turn238search41 line 2 |
| Status | Supported |
| Evidence gap | Direct Developer message not recovered. |

### COM-011 | 2026-09-02 11:23 to 2026-09-03 12:11 | Shared-storage cleanup

| Field | Value |
|---|---|
| Type | Teams channel |
| Source role | Developer and training group |
| Classification | Direct Developer communication; operational |
| Communication | Developer relayed a request to reduce MAN41 PVC usage, recommended moving large checkpoints to S3, and the group discussed deleting or moving old checkpoints and data folders. A Developer representative later stated that **[BLOCKED: SCREENSHOT EVIDENCE ENDS HERE]** |

**[BLOCKED SOURCE GAP: the Dropbox sequence jumps from 12:04:33 PM to 12:04:56 PM. The remainder of COM-011, including its subsequent table rows, is not visible in any supplied screenshot.]**

### COM-012 | 2026-09-04 11:08-11:11 | Model Replication Data

| Field | Value |
|---|---|
| Type | Email |
| Source role | Developer / internal participant |
| Classification | Direct Developer and project handoff |
| Communication | Developer stated that datasets and pretrained-model paths would be shared. Internal participant added Waqas to the thread because he was working on the foundation model. |
| Decision / interpretation | Use the subsequent Developer message as the authoritative package handoff. |
| Artifacts / paths | Replication data and pretrained-model paths |
| Effect on controlled run | Formally connects Waqas to the replication handoff. |
| Primary source | Email conversation; turn238search13 lines 38-55 |
| Status | Supported |
| Evidence gap | None. |

### COM-013 | 2026-09-08 09:36 | RE: Model Replication Data

| Field | Value |
|---|---|
| Type | Email |
| Source role | Developer |
| Classification | Direct Developer communication |
| Communication | Developer supplied v30 and v22b S3 package roots. Developer described v30 as newer, production-oriented CSCA data with LoB engineered features and features unavailable in production removed. Developer described v22b as older BMG data containing fraud proxies including status date, which should not be used in current form because of potential leakage from card inactive date. |
| Decision / interpretation | Run v22b as a separate controlled reconstruction and retain the leakage warning as an unresolved model-risk issue. |
| Artifacts / paths | s3://mrmcd-analytics-mrm-mmr-dsai/tfm_v30/; s3://mrmcd-analytics-mrm-mmr-dsai/tfm_v22b_dropcpr_falcondecline/ |
| Effect on controlled run | Defines the official v22b package root used for current train/eval inputs. |
| Primary source | Email conversation; turn238search13 lines 15-32 |
| Status | Supported |
| Evidence gap | **[BLOCKED: only the tail “command not included.” is visible in the next screenshot; the beginning of this cell is not screenshot-proven.]** |

### COM-014 | 2026-09-08 09:41-09:48 | Begin replication and prioritize v22b

| Field | Value |
|---|---|
| Type | Teams chat |
| Source role | Internal project participant |
| Classification | Internal direction |
| Communication | Internal participant asked Waqas to start replication from the Developer-supplied paths. Waqas stated that v30 and v22b would remain separate workstreams; internal participant requested v22b first. |
| Decision / interpretation | Active workstream is v22b only. Do not mix v30 artifacts or conclusions. |
| Artifacts / paths | Developer-supplied v22b and v30 paths |
| Effect on controlled run | Establishes active project identity and priority. |
| Primary source | Teams chat; turn238search35 line 1 |
| Status | Supported |
| Evidence gap | None. |

### COM-015 | 2026-09-09 11:08-11:11 | Workflow summary access

| Field | Value |
|---|---|
| Type | Teams chat |
| Source role | Internal project participant |
| Classification | Operational document handoff |
| Communication | Waqas reported access denied to Fraud_Finetuning_Workflow_Summary.docx from Confluence and Teams links. Internal participant resent the file directly; Waqas confirmed access worked. |
| Decision / interpretation | Retain the directly accessible copy with its source and modification history. |
| Artifacts / paths | Fraud_Finetuning_Workflow_Summary.docx |
| Effect on controlled run | Ensures the workflow summary is available, but it remains secondary evidence unless linked to primary code or Developer communication. |
| Primary source | Teams chat; turn238search35 line 0 |
| Status | Supported |
| Evidence gap | Document authorship and later edits must be distinguished from primary Developer statements. |

## 5. Final artifact manifest

The following files form the minimum defensible handoff. “If present” means the package should include the file when it exists in the repository; do not create a substitute.

| Group | Relative path / item | Requirement |
|---|---|---|
| Developer source | src/scripts/distributed_finetune.py | Required |
| Developer source | src/configs/finetune.py | Required |
| Developer source | src/configs/fraud_eval.py | Required |
| Developer source | src/training/finetune.py | Required |
| Developer source | src/evaluation/fraud_eval.py | Required |
| Developer source | src/data/fraud_streaming_loader.py | Required |
| Developer source | src/data/fraud_dataset.py | Required |
| Developer source | src/data/s3_utils.py | Required |
| Developer source | src/modelling/model.py | Required |
| Developer source | src/modelling/fraud_cls_model.py | Required |
| Developer source | src/utils/losses.py | Required |
| Developer source | src/utils/fraud_metrics.py | Required |
| Developer source | src/utils/combined_muon_adamw.py | Required |
| Developer source | src/utils/training_utils.py | Required |
| Data generation | src/data_pipeline/utility_lib/generate_fraud_data.py | Required |
| Documentation | FINETUNING_GUIDE.md | Required if present |
| Documentation | README.md | Required if present |
| Controlled execution | Validation/V22B/Reproduction/accum_4/scripts/distributed_finetune_accum4_smoke.py | Required |
| Controlled execution | Validation/V22B/Reproduction/accum_4/scripts/distributed_finetune_accum4_full.py | Required |
| Runtime evidence | controlled_10000step_accum4/full_finetune.log | Required |
| Runtime evidence | controlled_10000step_accum4/logs/train_steps.jsonl | Required when present |
| Runtime evidence | controlled_10000step_accum4/logs/eval_steps.jsonl | Required when present |
| Runtime evidence | latest checkpoint finetune_config.json | Required |
| Runtime evidence | latest checkpoint training_state.json | Required |
| Validation notebooks | EDA/03_Eval_Parquet_Audit.ipynb | Required |
| Validation notebooks | EDA/04_Data_Representation_Classification.ipynb | Required |
| Validation notebooks | EDA/05_Distributed_Finetune_Have_Missing_Audit.ipynb | Required |
| Validation notebooks | EDA/11_05_Sequence_Chronology_Leakage.ipynb | Required |
| Communication | Model Replication Data email thread | Required |
| Communication | TFM Debit Card raw data copy email thread | Required |
| Communication | Internal foundation model introduction chat/materials | Required |
| Communication | PFM Training group storage/pod messages | Required |

## 6. Open validation gates

| Issue | Status | Required evidence / action |
|---|---|---|
| Train duplicate target IDs | Unresolved | Run/recover exact scalar fi_transaction_id uniqueness result across all 5,000 train Parquets. |
| Eval duplicate target IDs | Unresolved | Run/recover exact scalar fi_transaction_id uniqueness result across all 10 eval Parquets. |
| Train/eval target overlap | Unresolved | Test intersection of scalar fi_transaction_id across frozen train and eval populations. |
| Label conflicts for repeated IDs | Unresolved | For repeated IDs, compare frd_tag within and across splits. |
| Historical exact command/config | Missing | Developer communication confirms scripts but exact historical resolved command/config is not in current evidence. |
| Historical selected checkpoint | Missing | Need direct evidence of which checkpoint produced the reported historical metrics. |
| Last-17 vs current window=None | Needs reconciliation | Compare prepared sequence lengths and generation logic with the historical communication. |
| Status-date prediction-time leakage | Open model-risk issue | Source-faithful execution does not resolve this Developer-identified leakage concern. |
| Training-time eval comparability | Controlled limitation | Each 500-step eval uses a different file and deterministic 20% stratified sample; do not read as a fixed-population curve. |

## 7. Final acceptance criteria

- Full training reaches step 10,000 without an unhandled exception.
- Checkpoint-final-step-10000 and scheduled checkpoint artifacts are structurally complete.
- Saved finetune_config.json matches the intended controlled configuration.
- Complete train/eval target-ID audit establishes the status of duplicates, label conflicts, and overlap.
- Standalone evaluator scores the complete selected OOT population and saves metric and row-level outputs.
- Final comparison reports total population, valid score count, coverage, and common-valid population where applicable.
- All leakage and chronology findings are separated from source-faithful execution results.
- No Developer communication, repository claim, runtime output, or reviewer interpretation is mislabeled as another evidence class.

## Appendix A. Copy/paste context for a new chat

ACTIVE PROJECT: TFM v22b controlled fraud fine-tuning reconstruction.

Use Developer as the collective label for Sumegha, Shubham, and the code-producing or artifact-supplying team in derivative text. Keep original source identity only in primary evidence metadata.

**[BLOCKED EOF: the final supplied screenshot ends at the first page of Appendix A. It does not show a subsequent page or otherwise prove that the document ends here.]**
