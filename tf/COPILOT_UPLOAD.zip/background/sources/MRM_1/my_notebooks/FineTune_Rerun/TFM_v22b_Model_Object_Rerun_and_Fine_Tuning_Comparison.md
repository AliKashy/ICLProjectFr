> **Conversion note (not part of the source document):** Reconstructed from the 52 supplied photos of the Word document. All 21 source tables remain tables. All five native-pixel figure crops are linked below, followed by text transcriptions of their labels, displayed values, and arrow order for AI readers. The companion Word file embeds the native-pixel figure crops. No additional research, inferred results, or silently corrected wording has been added. Original Word filename, underlying figure data, and exact original pagination were not available.

# TFM v22b Model-Object Rerun and Fine-Tuning Comparison

## Executive Summary

This validation addressed two objectives for TFM v22b: rerunning the delivered final step-10,000 Developer model object and comparing the reproduced results with both the Development team’s supplied outputs and the separately trained Fine-Tuned Model.

### Key Results

| Validation result | Finding |
| --- | --- |
| Evaluation population | 952,905 unique transactions |
| Population and metadata alignment | Exact |
| Exact Supplied Results vs Model Rerun probability matches | 803,195, or 84.2891% |
| Mean absolute same-checkpoint probability difference | 0.00013460 |
| Maximum absolute same-checkpoint probability difference | 0.01409278 |
| Mean absolute Model Rerun vs Fine-Tuned Model difference | 0.06633727 |
| Maximum Model Rerun vs Fine-Tuned Model difference | 0.99541745 |
| Supplied Results vs Model Rerun, maximum absolute logit difference | 0.07031250 |
| Supplied output duplicates | 3 non-fraud occurrences |

### Performance Comparison

| Metric | Supplied Results | Model Rerun | Fine-Tuned Model |
| --- | ---: | ---: | ---: |
| ROC AUC | 0.9684955047 | 0.96849262 | 0.96619768 |
| KS | 0.8214189678 | 0.82124737 | 0.80633894 |
| PR-AUC | 0.2768044244 | 0.27672673 | 0.25114480 |
| Log loss | 0.2770421477 | 0.27704246 | 0.14536295 |

### Conclusion

The delivered TFM v22b model object was successfully executed and closely reproduced on all 952,905 unique evaluation transactions. Population and metadata alignment were exact, aggregate performance was nearly unchanged, and 84.2891% of supplied probabilities matched exactly. The remaining same-checkpoint differences were generally small.

The Fine-Tuned Model also completed training and scoring successfully, but it produced distinct transaction probabilities, lower ranking and fraud-capture results, and a different operational review queue

## Overview

This work evaluates two related validation objectives for TFM v22b. First, the delivered final step-10,000 Developer model object was rerun on the exact supplied evaluation Parquet, and the newly generated scores were compared with the Development team’s supplied transaction-level and aggregate results. Second, the independently fine-tuned step-10,000 model was scored on the same evaluation population and compared with the Model Rerun.

The Development team supplied the repository snapshot, final checkpoint, checkpoint tokenizer, evaluation Parquet, and supplied row-level and aggregate scoring outputs. The analysis therefore compares three result sets: Supplied Results, Model Rerun, and Fine-Tuned Model.

## Developer Package

Sumegha provided the Developer-delivered repository snapshot, final checkpoint, tokenizer package, evaluation Parquet, and supplied scoring outputs used in this validation.

### Repository Overview

| File | Role in Scoring |
| --- | --- |
| src/evaluation/fraud_eval.py | Main scoring entry point. Loads the tokenizer, checkpoint, and evaluation data; runs inference; gathers outputs; calculates metrics; and saves the completed scoring artifacts. |
| src/configs/fraud_eval.py | Defines the evaluation paths, input columns, batch settings, precision, seed, and metric options. |
| tokenizer.tokenizer | Runtime-imported tokenizer module used by fraud_eval.py. Loads the saved tokenizer configuration and vocabulary and provides the BOS, PAD, and GAP token IDs required during evaluation. |
| src/data/fraud_streaming_loader.py | Reads the evaluation Parquet and creates evaluation examples from the existing token sequences and associated metadata. |
| src/data/fraud_dataset.py | Defines FraudDataset and fraud_collate_fn(). Applies sequence-length rules, pads shorter sequences, and builds model-ready batches. |
| src/modelling/model.py | Defines the Payment Foundation Model backbone. |
| src/modelling/fraud_cls_model.py | Constructs the fraud classifier around the foundation-model backbone and produces one fraud logit per evaluation sequence. |
| src/utils/fraud_metrics.py | Converts logits to probabilities and calculates ranking, loss, and review-cutoff metrics. |

### Checkpoint Overview

**Model object:** The delivered final step-10,000 checkpoint contains the model parameters and saved configuration artifacts required to reconstruct and score the fraud classifier.

| Artifact | What it contains | How it is used |
| --- | --- | --- |
| model.bin | Final step-10,000 model parameters for the foundation-model backbone and fraud-classification components | Loaded into the reconstructed classifier using strict state-dictionary matching. |
| config.json | Payment Foundation Model architecture configuration | Used to construct PaymentFoundationModel before loading the saved parameters. |
| finetune_config.json | Fraud-classifier construction settings | Used to reconstruct the configured pooling strategy, fraud head, dropout, and optional auxiliary inputs. |
| tokenizer/config.json | Saved tokenizer metadata, special-token names, feature configuration, and tokenizer behavior | Read by Tokenizer.load() when reconstructing the checkpoint tokenizer. |
| tokenizer/vocab.json | 5,378 token-to-ID mappings | Restores the vocabulary associated with the checkpoint and provides the token IDs used to interpret the prepared evaluation sequences. |
| eval_logits.npz | Supplied row-level logits and associated evaluation metadata | Used as the historical transaction-level benchmark for the Model Rerun. |
| eval_metrics.json | Supplied aggregate and review-cutoff metrics | Used as the historical aggregate performance benchmark. |

### Tokenizer, Vocabulary, and Token IDs

*Tokenization and Scoring Workflow*

The PFM scores tokenized transaction sequences rather than raw transaction fields. During upstream data preparation, transactions are ordered by account, converted into standardized tokens, and mapped to integer IDs using the 5,378-entry vocabulary in tokenizer/vocab.json. Historical and current transactions are combined into an ordered sequence and stored in the evaluation Parquet’s token_ids column.

The supplied evaluation Parquet already contained the completed token_ids. The Model Rerun therefore scored these frozen sequences without repeating or modifying upstream tokenization, preserving the model inputs used for the controlled comparison.

During scoring, the evaluation workflow applied the maximum sequence length of 2,048, padded shorter sequences into batches of 64, and passed the resulting input_ids through the PFM and fraud-classification head to produce one fraud probability per transaction.

Detailed tokenization and model-input construction are provided in Appendix B.

### Evaluation Data and Supplied Results

*Evaluation Parquet*

The Development team supplied the exact evaluation file used for the model-object comparison: cross-file-8000-8200-seed-42_1.parquet.

The file contains 952,905 rows representing 952,905 unique transactions. Each row represents one target transaction together with its prepared account-history sequence and the content required for evaluation.

| Field or content | Purpose |
| --- | --- |
| token_ids | Integer token sequence containing the transaction history and target transaction |
| fi_transaction_id | Unique identifier used to align supplied and rerun outputs |
| frd_tag | Binary fraud label |
| Transaction-amount content | Transaction amount used for value-based metrics; exact runtime column name is governed by the evaluation configuration. |
| Timestamp content | Target-transaction time; exact runtime column name is governed by the evaluation configuration. |
| Sequence-related content | Information used by the evaluation loader to prepare the model input. |

***Development-Team Row-Level Output***

The Development team supplied eval_logits.npz as the row-level scoring benchmark.

| Array | Rows | Purpose |
| --- | ---: | --- |
| fi_transaction_ids | 952,908 | Transaction identifiers |
| logits | 952,908 | Raw model outputs |
| labels | 952,908 | Fraud labels |
| amounts | 952,908 | Transaction amounts |
| timestamps | 952,908 | Transaction timestamps |
| source_files | 952,908 | Source evaluation file |

The supplied eval_logits.npz contains 952,908 physical output rows representing 952,905 unique transaction IDs. The three-row difference is attributable to three non-fraud transactions that each appear twice.

| Duplicated transaction ID | Positions in supplied output |
| --- | --- |
| 2f683a25a70c5d5d | 0 and 476,453 |
| 4b683a255f1d286c | 238,227 and 714,680 |
| 6e685d29810125c8 | 476,454 and 952,907 |

Each duplicate pair contains identical labels, amounts, timestamps, source-file values, logits, and probabilities. Detailed duplicate-consistency checks and the isolated aggregate-metric sensitivity analysis are provided in Appendix A.

*Supplied Aggregate Performance Metrics*

The Development team also supplied eval_metrics.json. The file reports aggregate performance calculated from all 952,908 supplied output occurrences, including the three duplicate occurrences identified above. These values provide the historical performance benchmark for the Model Rerun.

| Metric | Supplied value |
| --- | ---: |
| ROC AUC | 0.9684955047 |
| KS | 0.8214189678 |
| Average Precision | 0.2736735573 |
| PR-AUC | 0.2768044244 |
| Log loss | 0.2770421477 |

The reported evaluation count of 952,908 confirms that the original calculations included the three duplicate occurrences. Appendix A separately recalculates these metrics using one occurrence per unique transaction ID and shows that deduplication had negligible aggregate impact.

## Model Rerun

The delivered final step-10,000 Developer model object was reconstructed and scored on the same evaluation Parquet used for the supplied results. This rerun evaluated scoring reproducibility only. It did not retrain the model, regenerate the tokenized population, or modify the model parameters.

### Objective and Controlled Inputs

The objective was to isolate the scoring workflow by holding the following inputs constant:

- Final step-10,000 Developer checkpoint
- Model architecture and fraud-head configuration
- Checkpoint tokenizer and 5,378-entry vocabulary
- Evaluation Parquet
- Transaction labels, amounts, timestamps, and token sequences
- Repository scoring implementation

### Tokenizer Compatibility Adjustment

The checkpoint tokenizer configuration did not contain *mask_token* or *fill_missing*, but the runtime implementation of *Tokenizer.load()* required both fields to be present. The following values were added to load the historical tokenizer package:

```text
mask_token="<MASK>"
fill_missing=False
add_mask_token=False
```

Use of a mask token remained disabled because *add_mask_token=False*. Therefore, `<MASK>` was not added to the vocabulary and no mask-token ID was created.

This was treated as a loader-compatibility adjustment rather than a change to the scoring inputs:

- The vocabulary remained at 5,378 entries.
- Existing token-to-ID mappings remained unchanged.
- BOS, PAD, and GAP token IDs remained unchanged.
- The evaluation Parquet’s existing token_ids were not regenerated or altered.

### Rerun Configuration and Execution

| Setting | Rerun value |
| --- | --- |
| Checkpoint | Final step-10,000 Developer checkpoint |
| Evaluation file | cross-file-8000-8200-seed-42_1.parquet |
| Evaluation rows | 952,905 |
| Compute | One GPU and one scoring process |
| Precision | BF16 |
| Batch size | 64 |
| Maximum sequence length | 2,048 |
| Files per batch | 1 |
| Seed | 42 |
| DataLoader shuffle | Disabled |
| Row-level logits | Stored |

The scoring workflow reconstructed the Payment Foundation Model backbone and fraud-classification head from the checkpoint configuration. It then loaded model.bin using strict state-dictionary matching, moved the complete classifier to the GPU, set evaluation mode, and disabled gradient calculation.

The workflow read the existing token_ids, prepared the evaluation batches, generated one fraud logit per row, converted the logits to probabilities, calculated the evaluation metrics, and saved the row-level and aggregate outputs. Detailed reconstruction, code lineage, and execution evidence are provided in Appendix A.

### Completion and Population Validation

The run completed successfully with a recorded exit code of 0 and required approximately two hours on one GPU. It produced:

- 952,905 physical output rows
- 952,905 unique transaction IDs
- No duplicate transaction IDs

Alignment by fi_transaction_id showed complete population coverage:

- 952,905 common unique transaction IDs
- No Developer-supplied-only transaction IDs
- No Model-Rerun-only transaction IDs
- No label mismatches
- No amount mismatches
- No timestamp mismatches
- No source-file mismatches

The original Developer-supplied artifact remained unchanged. Because that artifact contained three identical duplicate occurrences, the controlled comparison used a separate one-row-per-fi_transaction_id view. This ensured that each unique transaction received equal weight and that each supplied score was compared with exactly one newly generated score from the same delivered Developer model object.

## Fine-Tuned Model

The Fine-Tuned Model was trained separately using the Developer repository’s fraud fine-tuning implementation. It started from the local step-6500 pretrained checkpoint, used the TFM v22b tokenizer with 5,378 vocabulary entries, and trained on 5,000 fraud-training Parquet files.

| Setting | Fine-Tuned Model run |
| --- | --- |
| Starting model | Local step-6500 pretrained checkpoint |
| Training implementation | *distributed_finetune.py* |
| Training files | 5,000 Parquet files |
| GPU | One H200 |
| Batch size | 32 |
| Gradient accumulation | 8 |
| Examples per optimizer update | 256 |
| Optimizer | Muon + AdamW |
| Loss | Composite and amount-weighted fraud loss |
| Training length | 10,000 optimizer updates |
| Checkpoint interval | Every 500 steps |
| Final model | Independent step-10,000 fraud model |
| Evaluation file | *cross-file-8000-8200-seed-42_1.parquet* |
| Evaluation output | 952,905 unique transaction scores |

![Developer Code Path Used for Fraud Fine-Tuning and Scoring](figures/figure_1.png)

<!-- Figure 1: label/value transcription for the text-only companion. -->

**Developer Code Path Used for Fraud Fine-Tuning and Scoring**

**Developer Fine-Tuning**

```text
TFM v22b
pretrained checkpoint
Model initialization
    ↓
TFM v22b tokenizer
Transaction tokens → model token IDs
    ↓
Developer fraud
training population
Historical file exposure not fully established
    ↓
distributed_finetune.py
Developer training implementation
    ↓
Batch 32 per GPU
Accumulation 8
Historical world size not established
    ↓
Muon + AdamW
Composite fraud loss
10,000 optimizer updates
    ↓
Final step-10,000
Developer checkpoint
Developer-trained fraud model
    ↓
fraud_eval.py
Official evaluation file
Saved logits and metrics
```

**Independent Validation**

```text
Local step-6500
pretrained checkpoint
Model initialization
    ↓
TFM v22b tokenizer
Vocabulary = 5,378
Transaction tokens → model token IDs
    ↓
5,000 training
Parquet files
Controlled fraud fine-tuning population
    ↓
distributed_finetune.py
Same Developer training implementation
    ↓
Batch 32 × accumulation 8
× 1 GPU = 256
Record presentations per optimizer update
    ↓
Muon + AdamW
Composite + amount-weighted loss
10,000 optimizer updates
    ↓
Checkpoint every 500 steps
Final step 10,000
Independent fraud model
    ↓
fraud_eval.py
Official evaluation file
Saved logits and metrics
```

**Figure 1. Developer Code Path Used for Fraud Fine-Tuning and Scoring.**

The diagram distinguishes the delivered Developer model path from the completed Fine-Tuned Model path. The Fine-Tuned Model run used the local step-6500 pretrained checkpoint, 5,000 training Parquet files, one H200 GPU, batch size 32, gradient accumulation 8, Muon plus AdamW, composite amount-weighted fraud loss, and a final step-10,000 checkpoint.

### Run Configuration Differences

| Result set | Governing model | Execution purpose |
| --- | --- | --- |
| Supplied Results | Delivered final step-10,000 Developer checkpoint | Historical transaction-level and aggregate benchmark supplied by the Development team |
| Model Rerun | Same delivered final step-10,000 Developer checkpoint | Fresh scoring execution of the delivered model object on the same evaluation population |
| Fine-Tuned Model | Separately trained step-10,000 checkpoint initialized from the local step-6500 pretrained checkpoint | Independent reconstruction of the fraud fine-tuning workflow |

The Model Rerun preserved the delivered checkpoint, architecture, tokenizer vocabulary, evaluation Parquet, prepared token sequences, labels, amounts, timestamps, and scoring implementation. The Fine-Tuned Model used the same evaluation population but was produced through a separate fine-tuning execution. Differences between the Model Rerun and Fine-Tuned Model therefore reflect two separately trained model objects rather than repeated scoring of the same checkpoint.

## Results and Comparison

![Three Result Sets and Their Governing Lineage](figures/figure_2.png)

<!-- Figure 2: label/value transcription for the text-only companion. -->

```text
Three Result Sets and Their Governing Lineage

Original Developer supplied
Developer checkpoint
    ↓
Developer tokenizer
    ↓
Official evaluation file
    ↓
Historical scoring execution
    ↓
952,908 score rows
952,905 unique IDs

Fresh Developer rerun
Developer checkpoint
    ↓
Compatibility runtime
same model weights
    ↓
Official evaluation file
    ↓
fraud_eval.py
    ↓
952,905 unique scores

Independent Validation
Independent fine-tuning
    ↓
Step-10,000 checkpoint
    ↓
Official evaluation file
    ↓
fraud_eval.py
    ↓
952,905 unique scores
```

**Figure 2. Three Result Sets and Their Governing Lineage.**

*Supplied Results, Model Rerun, and Fine-Tuned Model contain the same 952,905 unique evaluation transactions after alignment.*

### Population Alignment

| Validation item | Supplied Results | Model Rerun | Fine-Tuned Model |
| --- | --- | --- | --- |
| Physical score rows | 952,908 | 952,905 | 952,905 |
| Unique transaction IDs | 952,905 | 952,905 | 952,905 |
| Common evaluation population | 952,905 | 952,905 | 952,905 |
| Fraud transactions | 1,418 | 1,418 | 1,418 |
| Non-fraud transactions | 951,487 | 951,487 | 951,487 |
| Duplicate excess rows | 3 | 0 | 0 |

The three additional supplied rows are duplicate occurrences rather than additional transactions. Full label, amount, timestamp, and source-file identity was directly verified for the Supplied Results versus Model Rerun comparison.

### Probability Reproduction

| Measure | Supplied Results vs Model Rerun | Model Rerun vs Fine-Tuned Model |
| --- | --- | --- |
| Transactions compared | 952,905 | 952,905 |
| Exact probability matches | 803,195 (84.2891%) | 5,086 (0.53%) |
| Mean absolute probability difference | 0.00013460 | 0.06633727 |
| Median absolute probability difference | 0.00000000 | 0.01673810 |
| 95th-percentile absolute probability difference | 0.00097276 | 0.31413324 |
| Maximum absolute probability difference | 0.01409278 | 0.99541745 |

![Developer Score Reproduction](figures/figure_3.png)

<!-- Figure 3: label/value transcription for the text-only companion. -->

```text
Developer Score Reproduction

Vertical axis: Transactions
Ticks: 0, 200000, 400000, 600000, 800000

Exact matches:     803,195   84.29%
Non-exact scores:  149,710   15.71%
```

**Figure 3. Developer Score Reproduction.**

The Model Rerun closely reproduced the supplied transaction probabilities. Of the 952,905 aligned transactions, 803,195 probabilities, or 84.2891%, matched exactly. The mean absolute difference was 0.00013460, the median was zero, the 95th percentile was 0.00097276, and the maximum was 0.01409278.

The Fine-Tuned Model produced materially different transaction probabilities from the Model Rerun. The mean absolute difference was 0.06633727, the median was 0.01673810, the 95th percentile was 0.31413324, and the maximum was 0.99541745.

### Overall Metric Comparison

| Metric | Supplied Results | Model Rerun | Fine-Tuned Model |
| --- | --- | --- | --- |
| ROC AUC | 0.9684955047 | 0.96849262 | 0.96619768 |
| KS | 0.8214189678 | 0.82124737 | 0.80633894 |
| Average Precision | 0.2736735573 | 0.27361014 | 0.24806854 |
| PR-AUC | 0.2768044244 | 0.27672673 | 0.25114480 |
| Log loss | 0.2770421477 | 0.27704246 | 0.14536295 |

The Model Rerun closely reproduced the supplied aggregate metrics. Compared with the Fine-Tuned Model, it produced higher ROC AUC, KS, Average Precision, and PR-AUC, while the Fine-Tuned Model produced lower log loss.

### Rank-Based Analysis

The recalculation selects the same number of highest-ranked transactions from each model at each review capacity. It is presented separately because its exact equal-capacity cutoff implementation differs from the reported outsort calculation.

| Cutoff | Model | Selected | True positives | UDR | VDR | FP/TP | Selection overlap |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0.6% | Model Rerun | 5,718 | 802 | 56.56% | 68.37% | 6.13 | 87.67% |
| 0.6% | Fine-Tuned Model | 5,718 | 782 | 55.15% | 66.42% | 6.31 | 87.67% |
| 1% | Model Rerun | 9,530 | 922 | 65.02% | 77.03% | 9.34 | 86.19% |
| 1% | Fine-Tuned Model | 9,530 | 906 | 63.89% | 75.44% | 9.52 | 86.19% |
| 5% | Model Rerun | 47,646 | 1,207 | 85.12% | 92.60% | 38.47 | 80.78% |
| 5% | Fine-Tuned Model | 47,646 | 1,189 | 83.85% | 91.49% | 39.07 | 80.78% |

![Performance at Fixed Review-Population Sizes](figures/figure_4.png)

<!-- Figure 4: label/value transcription for the text-only companion. -->

```text
Performance at Fixed Review-Population Sizes

Legend: Fresh Developer rerun; Independent Validation
Each pair below is Fresh Developer rerun / Independent Validation.

Fraud Transaction Capture
Vertical axis: UDR
Ticks: 0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8
0.6%: 56.56% / 55.15%
1%:   65.02% / 63.89%
5%:   85.12% / 83.85%

Fraud Value Capture
Vertical axis: VDR
Ticks: 0.0, 0.2, 0.4, 0.6, 0.8
0.6%: 68.37% / 66.42%
1%:   77.03% / 75.44%
5%:   92.60% / 91.49%

Review Burden
Vertical axis: False positives per true positive
Ticks: 0, 5, 10, 15, 20, 25, 30, 35, 40
0.6%: 6.13 / 6.31
1%:   9.34 / 9.52
5%:   38.47 / 39.07
```

**Figure 4. Performance at Fixed Review-Population Sizes.**

The Model Rerun produced higher UDR and VDR and lower FP/TP at all three equal-capacity cutoffs.

![Do the Models Select the Same Transactions?](figures/figure_5.png)

<!-- Figure 5: label/value transcription for the text-only companion. -->

```text
Do the Models Select the Same Transactions?

Horizontal axis: Top-ranked population
Vertical axis: Selection overlap rate
Ticks: 0.0, 0.2, 0.4, 0.6, 0.8, 1.0

0.6%
87.67%
5,013 common
705 Developer only
705 validation only

1%
86.19%
8,214 common
1,316 Developer only
1,316 validation only

5%
80.78%
38,489 common
9,157 Developer only
9,157 validation only
```

**Figure 5. Model Selection Overlap by Review Population.**

At every equal review capacity, the Model Rerun captured more known fraud transactions and fraud value while producing a lower FP/TP ratio.

### Findings

1. **The delivered model object was successfully executed and closely reproduced.** The Model Rerun scored the complete evaluation population and closely reproduced the supplied aggregate performance.
2. **Population and metadata alignment were exact.** All unique transaction IDs aligned, with no supplied-only or rerun-only IDs and no mismatches in labels, amounts, timestamps, or source files.
3. **Same-checkpoint transaction probabilities reproduced closely.** Most probabilities matched exactly, and the remaining differences were generally small.
4. **The three supplied duplicate occurrences had negligible aggregate impact.** Removing them changed every tested aggregate metric by less than 0.0000006.
5. **The Fine-Tuned Model produced a distinct scoring result.** Its transaction-level probabilities differed materially from those generated by the Model Rerun.
6. **The Model Rerun produced stronger ranking and fraud-capture results.** The Fine-Tuned Model produced lower log loss.
7. **The two trained checkpoints produced different operational review queues.** The Model Rerun captured more fraud and fraud value with a lower FP/TP ratio at each equal review capacity.

## Conclusion and Next Steps

The delivered final step-10,000 Developer model object was successfully reconstructed and scored on all 952,905 unique evaluation transactions. Population and metadata alignment were exact, aggregate metrics reproduced closely, and 84.2891% of supplied probabilities matched exactly. The remaining same-checkpoint differences were small.

The Fine-Tuned Model completed training and scoring on the same evaluation population but produced different transaction probabilities, ranking metrics, fraud-capture results, and review queues. It is therefore a separate reconstructed model rather than another execution of the delivered checkpoint.

### Next Steps

1. Repeat the Model Rerun after the LEW41 change window ends on September 20, 2026, using the same f configuration to confirm scoring stability.
2. Review the completed findings with Sumegha next week, including the historical runtime configuration, tokenizer adjustment, duplicate supplied rows, and remaining same-checkpoint score differences.
3. Update the final validation conclusion with the repeated-run stability results and any historical execution details confirmed by the Development team.
4. Benchmark TFM against established fraud-model baselines using consistent populations and evaluation metrics.
5. Test whether frozen TFM embeddings improve an established fraud-model baseline under a controlled comparison.
6. Quantify key fine-tuning choices through controlled ablations, including history length, pooling, downsampling, and auxiliary signals.
7. Validate prediction-time availability and leakage controls for all fine-tuning inputs.

## Appendix A: Model-Object Rerun Implementation and Evidence

### Detailed Input Inventory

- *model.bin*: final step-10,000 model parameters.
- *config.json*: Payment Foundation Model architecture.
- *finetune_config.json*: fraud-classification head and related settings.
- *tokenizer/config.json* and *tokenizer/vocab.json*: tokenizer metadata and 5,378 token-to-ID mappings.
- *cross-file-8000-8200-seed-42_1.parquet*: fixed evaluation population and existing *token_ids*.
- *src/evaluation/fraud_eval.py*: checkpoint-scoring workflow.
- *src/utils/fraud_metrics.py*: probability conversion and performance metrics.

### Model Reconstruction and Code Lineage

1. Read *finetune_config.json* to recover fraud-classifier settings.
2. Load the checkpoint tokenizer and vocabulary.
3. Read *config.json* and construct *PaymentFoundationModel* (*src/modelling/model.py*).
4. Construct *FraudClassifier* (*src/modelling/fraud_cls_model.py*).
5. Load *model.bin* with *classifier.load_state_dict(state_dict, strict=True)*.
6. Move the complete model to the GPU, call *model.eval()*, and disable gradients.

The evaluation entry point is *run_fraud_evaluation()*, and checkpoint reconstruction is performed by *_load_classifier_from_checkpoint()* (*src/evaluation/fraud_eval.py*). Strict loading verifies that delivered parameter names and tensor shapes match the reconstructed model.

### Detailed Scoring Sequence

1. Load the checkpoint tokenizer and recover BOS, PAD, and GAP token IDs.
2. Load the exact evaluation Parquet and read *token_ids*, labels, amounts, transaction IDs, timestamps, and source-file information.
3. Enforce the maximum sequence length of 2,048 and pad shorter sequences into batches of 64.
4. Move each batch to the GPU and run the forward pass under BF16 mixed precision.
5. Produce one raw fraud logit per row, convert logits to probabilities, calculate metrics, and save row-level and aggregate outputs.

The model received prepared *input_ids* and any auxiliary inputs enabled by the checkpoint configuration. Labels and amounts were retained for metric calculation and did not determine inference outputs.

### Saved Outputs and Evidence

| Artifact | Evidence retained |
| --- | --- |
| *eval_logits.npz* | 952,905 rows for each of *fi_transaction_ids*, logits, labels, amounts, timestamps, and source files. |
| *eval_metrics.json* | Overall and review-cutoff metrics. |
| *exact_command.json* | Preserved scoring command and arguments. |
| *developer_fraud_eval.log* | Execution progress and completion messages. |
| *developer_fraud_eval.exit_code* | Recorded process exit code of 0. |

### Same-Checkpoint Logit Reproduction

| Comparison measure | Supplied Results vs Model Rerun |
| --- | --- |
| Median absolute logit difference | 0.00000000 |
| Mean absolute logit difference | 0.00187448 |
| 95th-percentile absolute logit difference | 0.01562500 |
| Maximum absolute logit difference | 0.07031250 |

The logit differences confirm that the non-exact same-checkpoint probabilities originated in the model forward output rather than in the sigmoid conversion.

### Supplied-Result Duplicate Audit

#### *Duplicate-Pair Consistency*

| Transaction ID | Positions | Label | Metadata identical | Logit identical | Probability identical |
| --- | --- | --- | --- | --- | --- |
| 2f683a25a70c5d5d | 0, 476,453 | 0 | Yes | Yes | Yes |
| 4b683a255f1d286c | 238,227, 714,680 | 0 | Yes | Yes | Yes |
| 6e685d29810125c8 | 476,454, 952,907 | 0 | Yes | Yes | Yes |

#### *Isolated Aggregate Metric Impact*

| Metric | All 952,908 occurrences | 952,905 unique transactions | Raw minus unique |
| --- | --- | --- | --- |
| ROC AUC | 0.9684955047 | 0.9684954520 | +5.2638357673e-08 |
| KS | 0.8214189678 | 0.8214186849 | +2.8289452092e-07 |
| Average precision | 0.2736735573 | 0.2736735580 | -7.8106598966e-10 |
| PR-AUC | 0.2768044244 | 0.2768044252 | -7.8461881436e-10 |
| Log loss | 0.2770421477 | 0.2770427428 | -5.9511037243e-07 |

Removing the three duplicate supplied occurrences changed every tested aggregate metric by less than 0.0000006. The duplicates explain the supplied row-count difference but do not explain the broader same-checkpoint probability differences.

### Population-Alignment Evidence

| Validation check | Result |
| --- | --- |
| Supplied unique IDs / rerun unique IDs / common IDs | 952,905 / 952,905 / 952,905 |
| Supplied-only IDs / rerun-only IDs | 0 / 0 |
| Label / amount / timestamp / source-file mismatches | 0 / 0 / 0 / 0 |

## Appendix B: Detailed Tokenization, Vocabulary, and Model-Input Construction

### Handlers Supported by the Reviewed Utility Implementation

| Handler | Code location | Function |
| --- | --- | --- |
| bin_ranges | *Tokenizer._handle_feature()* and *Tokenizer._bin_into_ranges()* | Places a numeric value into a configured range. |
| float | *Tokenizer._handle_feature()* and *Tokenizer._bin_symmetric_amount()* | Converts a continuous value into a fixed numerical bin. |
| category | *Tokenizer._handle_feature()* | Matches a value to a known category or uses an OTHER fallback. |
| category_group | *Tokenizer._handle_feature()* | Maps related values into one configured group. |
| temporal | *Tokenizer._handle_feature()* | Produces hour-of-day and day-of-week tokens. |
| hash_bin | *Tokenizer._handle_feature()* and *Tokenizer._hash_to_bucket()* | Maps a high-cardinality value into a fixed hash bucket. |
| ip_address | *Tokenizer._handle_feature()* | Maps an IP value to an IPv4, IPv6, or fallback token. |
| days_since | *Tokenizer._handle_feature()* and *Tokenizer._days_since()* | Represents the difference between a feature date and the transaction date. |
| zip_geohash_handle | *Tokenizer._handle_feature()* | Maps postal and country information to a geohash-related token. |

### Configuration, Token, and Vocabulary Examples

**Implementation scope:** The evaluation workflow loaded the saved checkpoint tokenizer through the runtime-imported *tokenizer.tokenizer* module. The upstream data-pipeline implementation in *src/data_pipeline/utility_lib/tokenizer.py* documents how raw transaction attributes are transformed into token strings and stable integer token IDs before evaluation. During the completed rerun, scoring consumed the existing Parquet *token_ids*; upstream token construction was not repeated.

**Illustrative example:** The following example demonstrates the *bin_ranges* handler. The delivered v22b fields, prefixes, and boundaries are defined in *tokenizer/config.json*.

**Configuration example:** A *transaction_amount* definition may specify the *bin_ranges* handler, an *AMOUNT* prefix, and boundaries such as 10, 50, 100, and 500 (*tokenizer/config.json*; *src/data_pipeline/utility_lib/tokenizer.py*, class *TokenizerConfig*). The tokenizer then reads the amount, compares it with the configured boundaries, and produces the corresponding range token.

**Token examples:** *Δt_PAD*, *Δt_BIN_03*, *HOD_14*, *DOW_3*, *AMOUNT_RANGE_3*, and *CATEGORY_OTHER* are symbolic outputs from *Tokenizer._handle_feature()* and *Tokenizer._tokenize_transaction()* (*src/data_pipeline/utility_lib/tokenizer.py*). Special sequence tokens include &lt;BOS&gt;, &lt;EOS&gt;, &lt;PAD&gt;, &lt;UNK&gt;, and &lt;GAP&gt;.

**Vocabulary lookup:** *Tokenizer.tokenize_sequence()* and *Tokenizer.tokenize_and_join()* retrieve the unknown-token ID from *self.vocab[self.config.unk_token]* and resolve each token with *self.vocab.get(token, unk_id)* (*src/data_pipeline/utility_lib/tokenizer.py*). Recognized tokens receive their saved vocabulary IDs; unrecognized tokens receive the &lt;UNK&gt; ID.

### Sequence Construction and Saved Data

The ordered sequence is constructed as &lt;BOS&gt; → historical transaction tokens → &lt;GAP&gt; → subsequent historical transaction tokens → &lt;GAP&gt; → current transaction tokens → &lt;EOS&gt; (*src/data_pipeline/utility_lib/tokenizer.py*, *Tokenizer.tokenize_sequence()* and *Tokenizer.tokenize_and_join()*). The account-level supporting workflow is *generate_tokenizer_and_join()* (*src/data_pipeline/tokenizer_lib.py*).

The generated Parquet contains the completed *token_ids* sequence and may also include *fi_transaction_id*, *frd_tag*, amount, timestamps, account information, sequence metadata, and configured history labels (*src/data_pipeline/tokenizer_lib.py*, *_write_tokenized_dataframe()*, *generate_tokenizer()*, *generate_tokenizer_from_tabular()*, and *generate_tokenizer_and_join()*). S3-compatible wrappers are located in *src/data_pipeline/tokenizer_lib_s3.py*. The completed model-object rerun used *cross-file-8000-8200-seed-42_1.parquet*.

### Evaluation-Time Loading and Batch Preparation

The evaluation entry point loads the tokenizer with *Tokenizer.load(config.tokenizer_path)* and retrieves the padding, gap, and beginning-of-sequence IDs (*src/evaluation/fraud_eval.py*, *run_fraud_evaluation()*). When a bundled *tokenizer/* directory exists, *_load_classifier_from_checkpoint()* also loads the checkpoint tokenizer. Evaluation reads existing *token_ids*; it does not tokenize raw transaction attributes again.

*FraudStreamingLoader* reads the tokenized Parquet (*src/data/fraud_streaming_loader.py*). *FraudDataset* and *fraud_collate_fn()* read each sequence, apply the maximum sequence length, pad shorter sequences using the &lt;PAD&gt; ID, combine examples into batches, and produce the *input_ids* tensor (*src/data/fraud_dataset.py*). The scoring configuration used a maximum sequence length of 2,048 and a batch size of 64.

### Evaluation Population and Row-Level Scoring

The evaluation Parquet did not contain duplicate *fi_transaction_id* values. Therefore, the expected scoring population was one output for each of the 952,905 unique transactions.

#### *How One Parquet Row Is Scored*

1. Read the existing *token_ids* sequence (*src/data/fraud_streaming_loader.py*, class *FraudStreamingLoader*).
2. Prepare the sequence and its associated label, amount, timestamp, and transaction ID (*src/data/fraud_dataset.py*, class *FraudDataset*).
3. Enforce the maximum sequence length of 2,048 and pad shorter sequences so multiple rows can form one batch (*src/data/fraud_dataset.py*, function *fraud_collate_fn()*).
4. Combine 64 prepared examples into an evaluation batch (*src/evaluation/fraud_eval.py*, function *run_fraud_evaluation()*).
5. Pass the *input_ids* tensor through the Payment Foundation Model (*src/modelling/model.py*, class *PaymentFoundationModel*).
6. Pass the resulting hidden states through the fraud-classification logic (*src/modelling/fraud_cls_model.py*, class *FraudClassifier*).
7. Produce one raw fraud logit for each transaction.
8. Convert the logits into probabilities and calculate aggregate fraud metrics (*src/utils/fraud_metrics.py*, function *compute_all_fraud_metrics()*).

### Model Embedding Compatibility

The prepared *input_ids* tensor is passed to *FraudClassifier* (*src/modelling/fraud_cls_model.py*), which sends the IDs to *PaymentFoundationModel* (*src/modelling/model.py*). Each ID selects the corresponding row from the learned embedding matrix before Transformer processing and fraud classification.

The IDs must remain stable because assigning a token to a different ID would select a different learned embedding row. *FraudFinetuneTrainer* checks that *tokenizer.vocab_size* equals *base_model.config.vocab_size* (*src/training/finetune.py*), protecting structural compatibility between the tokenizer and model.
