# FineTune Rerun

## Document

[TFM v22b Model-Object Rerun and Fine-Tuning Comparison — Markdown](TFM_v22b_Model_Object_Rerun_and_Fine_Tuning_Comparison.md)

[TFM v22b Model-Object Rerun and Fine-Tuning Comparison — Word](TFM_v22b_Model_Object_Rerun_and_Fine_Tuning_Comparison.docx)

The document was reconstructed from all 52 photographs in the supplied Dropbox folder `/notebooks/1_WordDoc_FineTune_Rerun_Results`.

- All 21 source tables are preserved as editable tables.
- All five figures are preserved as native-pixel crops in `figures/` and embedded in the Word document.
- The Markdown document links to the five image files and also transcribes their labels, displayed values, and arrow order for AI readers.
- Both appendices are included, through the final Model Embedding Compatibility paragraph.

The Word reconstruction was rendered and checked across 18 pages. Its prose and tables were compared with the transcription; the five image files in GitHub match the local figure crops byte-for-byte. Layout and pagination are recreated; this is not a byte-identical copy of the unavailable original Word file. Results are transcribed from the supplied document, not independently recomputed. The original Word filename was not fully visible; the export names are descriptive.

The completed Word file and the image assets are already committed. No build step is needed to access them. The temporary one-time import workflow was removed after successful completion. The supporting source hashes, crop coordinates, and manual reconstruction scripts remain in `.reconstruction/`.

## Existing Metrics notebook and saved outputs

The existing notebook and its saved output bundle were moved together, without changing their contents:

```text
Visuals/
├── Metrics.ipynb
├── Metrics_outputs_manifest.json
└── Metrics_outputs/
    ├── manifest.json
    ├── reassemble_full_notebook.py
    └── existing output chunk files
```

The complete `Visuals` subtree retains Git tree hash `b8a2a86b32d9a8171a3d68b996bd0d2a4ef8df0f`.

To reassemble that previously split Metrics notebook, run from the repository root:

```bash
python my_notebooks/FineTune_Rerun/Visuals/Metrics_outputs/reassemble_full_notebook.py
```

This existing script restores its saved output objects; it does not rerun model training or scoring.
