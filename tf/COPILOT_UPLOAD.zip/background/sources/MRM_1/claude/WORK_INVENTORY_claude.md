# Work inventory — everything that could be done, and what actually should be

Three workstreams. **Validation** is the mandate. **Experiment** is the leverage
question. **Operational** is what makes either usable.

Timeline is to **January** — roughly 15 weeks, ~13 effective after holidays. The
mid-performance review at week 4 is a checkpoint, not the deadline. Nothing in this
inventory is cut for feasibility; §5 phases all of it.

Each item: what it answers, what you produce, effort, and what it needs first.

---

## 1. VALIDATION — the mandate

### V1 · Inference replication ✅ in progress

| | |
|---|---|
| **Question** | Does the delivered checkpoint reproduce the reported scores? |
| **Outcome** | Replicated, with the reproducibility finding quantified |
| **Effort** | Done; memo pending |
| **Needs** | — |

Already yields one finding (no determinism controls, bf16 default).

### V2 · Fine-tune replication

| | |
|---|---|
| **Question** | Does their fine-tuning procedure, re-run, produce an equivalent model? |
| **Outcome** | Matched-effective-batch run + a precise statement of why exact match is impossible on 1 GPU |
| **Effort** | 1 long GPU run (~4× their wall-clock at `grad_accum=32`) |
| **Needs** | V1 |

Deliverable is the *explanation plus the attempt*, not a matching number.
Second finding available here: the documentation gap on effective batch scaling.

### V3 · Pretraining replication ⚠ scope honestly

| | |
|---|---|
| **Question** | Is the foundation model itself reproducible? |
| **Outcome** | **Not fully reproducible by a validation team** — weeks of multi-GPU compute. Say so explicitly rather than leaving it open |
| **Effort** | Full: infeasible. Spot-check: 1 short run |
| **Needs** | Pretraining data access |

**Three tiers, in increasing cost:**

1. **Config audit** (hours) — confirm the checkpoint's `config.json` matches the
   documented architecture, and that the parameter count matches the claimed size.
2. **Short-run sanity check** (1 day) — run 200–500 pretraining steps and confirm loss
   decreases sensibly. Establishes the training code functions, without claiming to
   reproduce the artifact.
3. **Scaled-down replication** (1–2 weeks) — train a deliberately small model (e.g.
   4 layers, `d_model=256`) on a data subset, to convergence. This does **not** reproduce
   their checkpoint, but it validates that the training procedure produces a working
   model from this data — which is the part a validator actually needs to attest to.

Tier 3 is worth doing with a longer runway and is a genuinely strong deliverable. Most
validation teams stop at tier 1.

### V4 · Data pipeline validation

| | |
|---|---|
| **Question** | Does the tokenized data faithfully represent the raw transactions? |
| **Outcome** | Confirmation that the model's inputs are what they are claimed to be |
| **Effort** | CPU only, several short tasks |
| **Needs** | Raw + tokenized data access |

Underrated. **The model can only be as correct as its tokenization.** Sub-checks:

- Token count per transaction is constant (confirms `fill_missing=True` was used)
- Vocabulary in `vocab.json` matches the tokenizer config's declared features
- Decode a sample of sequences back to tokens and eyeball them against raw rows
- Confirm the claimed **17-transaction window** by counting `<GAP>` tokens per sequence
  — this reconciles COM-005 against `window_size=None` in the controlled script
- Confirm `<GAP>` = ID 4 and the special-token block is as expected

- **Establish the actual `downsample` used for the v22b build.** The function default
  is `100` (`generate_fraud_data.py:197`), but **every `gen-frd` config under
  `end_2_end/` and `pkl_restructing/` sets `downsample: 1`** — keep all non-fraud. The
  `100`s are only in `other_testing/` and one scenario fixture; the v22 end-to-end
  config specifically sets `1`. The developer's own v22b config is not in the package,
  so this is **unresolved**, and it gates V11's calibration argument and the entire
  `calibrated_fpr` narrative. Settle it in one line: `labels.mean()` on the
  `eval_logits.npz`.

The repo's own `validation_check/` scripts do much of this already.

### V5 · Leakage ablations ⭐ highest value

| | |
|---|---|
| **Question** | Does performance depend on information unavailable at scoring time? |
| **Outcome** | Quantified dependence on each suspect signal |
| **Effort** | 3–4 fine-tune runs |
| **Needs** | V2 |

| Run | Change | Tests |
|---|---|---|
| A | Baseline as delivered | Reference |
| B | `mask_all_txn_labels=True` | Historical fraud labels |
| C | `INACTV_DT` / `days_since_status_dt` removed | The status-date leak |
| D | Falcon / pre-decline indicators masked | Upstream fraud systems |

Report UDR/VDR @ 0.6% for each. A large drop in B, C or D **is the headline finding of
the entire validation** — and C is the developer's own stated concern (COM-013).

### ⚠ Read before scheduling V5 — the ablation switches may be inert

`fraud_cls_model.py:396-399`:

```python
self.use_txn_labels = (use_txn_labels or self.use_phats) and pool_strategy in _SEGMENTED_STRATEGIES
self.mask_all_txn_labels = mask_all_txn_labels and self.use_txn_labels
```

**Every auxiliary-signal switch is silently forced off unless `pool_strategy` is
`enhanced_mlp` or `dcnv2`** — same for `use_vendor_score` (`:405`) and
`use_claim_labels` (`:414`). The project record says the controlled run used
`pool_strategy: last` (`TFM_V22B_Finalized_Package_PARTIAL.md:34`).

So under `last` pooling, run B returns a number identical to baseline, and the natural
reading — *"performance does not depend on historical fraud labels"* — **would be
wrong**. The flag did nothing. That is precisely the credibility-damaging false finding
this exercise exists to avoid.

**Three actions:**

1. **Read `pool_strategy` from the checkpoint's `finetune_config.json` before designing
   V5.** It gates the whole experiment.
2. If it is `last`, historical-label leakage enters through the **token stream**, not
   the injection path — so the controls are `excl_past_frd`, the placeholder remapping,
   and `apply_label_delay` in `generate_fraud_data.py`, and run B must be redesigned.
3. **Add a positive control to every ablation** — confirm the switch changed *something*
   before reading a null as evidence. Single most valuable process change in the plan.

### V6 · Chronology / point-in-time integrity

| | |
|---|---|
| **Question** | Does any feature contain information from after the target transaction? |
| **Outcome** | Confirmation (or not) that inputs are point-in-time correct |
| **Effort** | CPU only |
| **Needs** | Tokenized data |

Distinct from V5 — this inspects the **data construction**, not the model's dependence.

- For a sample of sequences, confirm every history transaction predates the target
- Confirm the 90-day `days_offset` cutoff was actually applied
- Check `days_since_status_dt` values for positive diffs (status date after transaction
  date) — the direct signature of the leak
- Confirm `apply_label_delay` settings used, if any

### V7 · Train/eval separation

| | |
|---|---|
| **Question** | Is the evaluation set genuinely held out? |
| **Outcome** | Confirmation of no account or time overlap |
| **Effort** | CPU only, half a day |
| **Needs** | Both datasets |

- No `account_id` appears in both train and eval (COM-008 claims partitioning — verify
  from the artifacts, don't take the email's word)
- Eval period is genuinely *after* the training period (true OOT)
- No duplicate transactions across the split

**Cheap, and a failure here invalidates everything else.** Do it early.

### V8 · Stability and sensitivity

| | |
|---|---|
| **Question** | How much does reported performance move under benign changes? |
| **Outcome** | An error bar for the headline metric |
| **Effort** | 3 fine-tune runs |
| **Needs** | V2 |

Same config, seeds 42 / 43 / 44. Report the spread in UDR/VDR.

**If seed variance exceeds the margin by which TFM beats the incumbent, the comparison
is not meaningful.** Nobody has established this, and it is a standard MRM expectation.

### V9 · Benchmark vs the incumbent

| | |
|---|---|
| **Question** | Does TFM outperform the existing XGBoost on the same data? |
| **Outcome** | Like-for-like comparison at the operating cutoff |
| **Effort** | Moderate — needs XGBoost scored on the same eval set |
| **Needs** | V5 (don't benchmark a leaky model) |

### V10 · Code and documentation review ✅ largely done

| | |
|---|---|
| **Outcome** | The Group A/B findings, config-vs-docs drift, the single-GPU documentation gap |
| **Effort** | Done; needs source-repo confirmation |
| **Needs** | Source access |

### V11 · Calibration analysis

| | |
|---|---|
| **Question** | Are the output probabilities meaningful, or only the ranking? |
| **Outcome** | A calibration curve, and a statement on whether probabilities are safe to consume downstream |
| **Effort** | Low — offline from saved logits |
| **Needs** | V1 |

**A finding is very likely waiting here**, and the argument is stronger than ranking
losses alone.

`pos_class_weight: float = 3.0` (`configs/finetune.py:61`) feeds
`BCEWithLogitsLoss(pos_weight=...)`. **A positive-class weight above 1 mathematically
guarantees the outputs are not calibrated probabilities** — it inflates them
systematically, regardless of anything else in the loss.

On top of that, the delivered run weighted the loss **BCE=1.0, pairwise=0.5,
approx-outsort=0.0, top-k UDR=2.0** (`TFM_V22B_Finalized_Package_PARTIAL.md:35`) —
ranking outweighs calibration 2.5:1. Note approx-outsort was configured but **weighted
zero**, so it is not an active driver. And see **V17**: the top-k UDR term, the
heaviest-weighted of all, does not do what its name says.

⚠ Do **not** cite "100:1 downsampling" — see V4. The training prevalence is unresolved
and the repo's configs point the other way.

If anything downstream consumes a probability rather than a rank — a threshold rule, an
expected-loss calculation, a blended score — it is consuming a number that does not mean
what it appears to mean. Plot predicted probability against observed fraud rate by
decile and see.

### V12 · Cold-start and edge-case behaviour

| | |
|---|---|
| **Question** | What does the model do with a new account, or a single transaction? |
| **Outcome** | Documented behaviour at the boundaries |
| **Effort** | Low |
| **Needs** | V1 |

**Verified in the code, and it matters.** `TransactionFeatureExtractor` guards every
history-derived feature behind `has_history`. With a single-transaction sequence:

| Feature block | Value with no history |
|---|---|
| `last_txn` | real |
| `context_vector` | **zeros** |
| `contrast` (`last − context`) | duplicates `last_txn` |
| `z_score` | **zeros** |
| `robust_z_score` | **zeros** |
| `window_vectors` (×3) | **zeros** |
| `decay_pooled` | **zeros** |

Of nine `d_model` blocks, **seven are zero and one duplicates another.** Two-ninths of
the vector is non-zero but carries only **one-ninth** of the information, since
`contrast` reproduces `last_txn` exactly.

⚠ **Two conditions.** This describes a sequence scored *in isolation* (`batch_size=1`).
In a mixed batch `K_max` is the batch's largest segment count, so a one-transaction
sample has `has_history=True` and the blocks populate — differently, and see **V16**,
which is more serious. It also applies **only** to `pool_strategy ∈ {enhanced_mlp,
dcnv2}`; under `last` pooling `TransactionFeatureExtractor` is never instantiated.
**Read `pool_strategy` from the checkpoint before scheduling this.**

That may be acceptable — or the model may be systematically mis-scoring exactly the
population most exposed to account-takeover and application fraud. Test: score sequences
truncated to 1, 2, 3, 5, 10, 17 transactions and plot performance against history
length. *(GPU work, not CPU — it re-runs the model.)*

### V13 · Temporal stability / backtesting

| | |
|---|---|
| **Question** | Does performance hold month over month, or decay? |
| **Outcome** | A performance-over-time curve and an implied retraining cadence |
| **Effort** | Moderate — needs several months of scored data |
| **Needs** | V1 |

Fraud adapts. A model trained on 10/2024–05/2025 and tested on 06/2025 gives one point.
Scoring several consecutive months gives the *slope*, which is what sets monitoring
thresholds and retraining frequency. `fraud_eval.py` already reports per-file metrics,
and the files are time-partitioned.

### V14 · Missing-data sensitivity

| | |
|---|---|
| **Question** | How does the model behave when fields are absent? |
| **Outcome** | Degradation profile per field |
| **Effort** | Moderate |
| **Needs** | V4 |

`fill_missing=True` means absence is an explicit `_MISSING` token — the model *learns*
from absence. So a field missing at a different rate in production than in training is a
silent distribution shift. Mask each field in turn at eval time and measure the drop.

### V15 · Evasion / gaming analysis

| | |
|---|---|
| **Question** | Can a fraudster manipulate inputs to suppress their score? |
| **Outcome** | An adversarial robustness statement |
| **Effort** | Moderate |
| **Needs** | V5, V14 |

Fraud models face an adversary; credit models mostly do not. Concretely: does splitting
one large transaction into several small ones evade detection? Does establishing a few
benign transactions first suppress the score on a subsequent fraud? Both are things
fraudsters actually do, and both are directly testable by constructing the sequences.

### V16 · The `last_txn` padding defect ⭐ likely the most serious code finding

| | |
|---|---|
| **Question** | Does the segmented pooling path score the wrong transaction? |
| **Outcome** | Either a cleared concern or a demonstrated train/serve skew in the default architecture |
| **Effort** | **Half a day, no training** |
| **Needs** | V1 |

`TransactionFeatureExtractor` identifies the transaction being scored as
`txn_vectors[:, -1:, :]` (`fraud_cls_model.py:156`) — the **last slot of the padded `K`
dimension**. But `segment_transactions` left-aligns segments and zero-pads at the end
(`transaction_utils.py:89-97`). So for every sample with fewer transactions than the
batch's longest sample, **that slot is a zero pad, and the real target transaction sits
in the history block.**

Two independent signs this is a defect, not a convention:

1. **The same file does it correctly elsewhere.** `_inject_txn_labels` uses
   `last_real_idx = txn_mask.long().sum(dim=1).clamp(min=1) - 1` (`:655`), as does
   `_inject_claim_labels` (`:706`). So the target-transaction marker is placed on the
   *true* last segment, which the feature extractor then reads as history. **One forward
   pass, two contradictory definitions of "the transaction being scored."**
2. **The legacy pooling paths do it correctly** — `_last_valid_index` (`:722-729`).

**Compounding it:** `attention_mask` is never passed to the model — `finetune.py:1082`
and `fraud_eval.py:250` pass only `input_ids` plus auxiliaries. The docstring says the
model derives masks from `input_ids != pad_id`, which is true for the legacy paths but
**false for the segmented path**: `_pool_segmented` passes `attention_mask=None`
through (`:579`), and `segment_transactions` then fills it with all-ones
(`transaction_utils.py:49-50`), treating every PAD as real. The final segment runs to
`end_pos = L`, so the target transaction is **mean-pooled together with the entire
padding region**.

**Why this outranks V12:** it is a **train/serve skew**. In batched training and
evaluation most samples get a zeroed or padding-diluted target block; at serving,
transactions are scored one at a time, `K_max` equals that sample's own segment count,
and there is no padding — a regime the model barely saw during fine-tuning. It also
means a transaction's score **depends on which other transactions share its batch.**

**The decisive test, and it is cheap:** score one eval file at `--batch_size 1` and at
`--batch_size 64`, same checkpoint, same data, and compare the score vectors. Identical
⇒ not material. Divergent ⇒ demonstrated train/serve skew in the default architecture.

⚠ Applies only to `pool_strategy ∈ {enhanced_mlp, dcnv2}`. **Confirm `pool_strategy`
first.**

### V17 · The top-k UDR loss does not do what it claims

| | |
|---|---|
| **Question** | Was the model optimised against the operating point it is measured at? |
| **Outcome** | A model-design finding |
| **Effort** | Minutes to demonstrate |
| **Needs** | — |

`utils/losses.py:417-420`:

```python
min_k = max(1, n_nonfraud // 2)
k = max(min_k, int(n_nonfraud * topk_udr_percentile))
```

Since `0.006·n < n/2` for **every** `n`, the floor always wins. Verified for every batch
size from 2 to 1,000,000: the percentile branch is reachable **zero** times. At
`batch_size=32`, `k = 15` — the loss pushes each fraud above the top **half** of
in-batch non-fraud, not the top 0.6%.

The docstring claims it *"mirrors the percentile cut used at evaluation time"*
(`losses.py:276-278`). It cannot. **`topk_udr_percentile` is dead configuration.**

**This is the heaviest-weighted term in the delivered run (2.0).** The model was
optimised against a *median-separation* objective while the documentation and config say
it was optimised against the 0.6% operating point. It also feeds V11 — a loss shaping
the middle of the distribution has very different calibration consequences from one
shaping the extreme tail.

Demonstrate with a five-line script printing `k` against `n_nonfraud`. No GPU, no data.

### V18 · Architecture-level leakage review

| | |
|---|---|
| **Question** | Does the model code contain structural information flow that leaks? |
| **Outcome** | Code-level leakage findings |
| **Effort** | CPU only, week 1 |
| **Needs** | — |

Your own Confluence record (31 Aug) lists *"Review the NN architecture for potential
data leakage issues"* as a distinct scope item. V5 covers feature/label *dependence* and
V6 covers data *construction*, but nothing audits the model code for information flow.
**V16 and V17 both came out of exactly this review.** No data needed.

### V19 · Validate `true_fraud_rate = 0.0016`

| | |
|---|---|
| **Question** | Is the assumed production fraud prevalence correct? |
| **Outcome** | Confirmed or corrected `calibrated_fpr` figures |
| **Effort** | One conversation |
| **Needs** | — |

Hard-coded at `configs/fraud_eval.py:49` and **linearly scales every `calibrated_fpr`
the model reports** (`fraud_metrics.py:369-377`). It is a developer-supplied assumption
that nothing checks against actual portfolio data. In a formal validation, an
unvalidated assumption scaling a headline operational metric is a finding in itself.

### V20 · Score stability under benign perturbation

| | |
|---|---|
| **Question** | Does the same transaction get the same score under harmless changes? |
| **Outcome** | An uncertainty figure for a single model's output |
| **Effort** | Low |
| **Needs** | V1 |

V8 covers seed variance across *training* runs. Nothing covers whether one trained model
scores consistently under batch composition (V16), batch size, precision (bf16 vs fp32),
or padding. This is the direct answer to the Confluence ask *"Quantify it by how much
uncertainty it introduced to model output"*, and it is the natural home for the
`batch_size=1` vs `64` test.

### V21 · Population stability / input drift

| | |
|---|---|
| **Question** | Are the model's inputs drifting? |
| **Outcome** | The monitoring you would actually run monthly |
| **Effort** | CPU only |
| **Needs** | V4 |

V13 covers *performance* over time; nothing covers *input* drift — token-frequency
distributions, `_MISSING` rates per field, transactions per sequence. V14 notes that a
field missing at a different rate in production is a silent shift, but nothing measures
the rates.

### V22 · Override / fallback behaviour

| | |
|---|---|
| **Question** | What happens when the model cannot score? |
| **Outcome** | An operational-risk note |
| **Effort** | One page |
| **Needs** | — |

`fraud_dataset.py:504-506` substitutes `[pad_id]` for an empty sequence and **scores it
anyway** rather than failing. That produces a number, which is worse than an error.

---

## 2. EXPERIMENT — the leverage question

### E1 · TFM score as an XGBoost feature ⭐ the business case

| | |
|---|---|
| **Question** | Does the TFM add anything the existing model doesn't already capture? |
| **Outcome** | One number: Δ UDR/VDR at the operating cutoff |
| **Effort** | Moderate |
| **Needs** | **V5** — never build on a signal you haven't cleared for leakage |

Two XGBoost models, identical data, one with `tfm_score`. The delta is the answer.
`fraud_eval.py` already dumps logits with `fi_transaction_ids` for exactly this.

### E2 · TFM embeddings as features

| | |
|---|---|
| **Question** | Is there more signal in the representation than in the single score? |
| **Outcome** | Upper bound on achievable lift |
| **Effort** | Moderate — needs an embedding dump written |
| **Needs** | E1 |

Research step to size the ceiling. Not a production candidate — "PCA component 7 of a
Transformer embedding" is not explainable to a regulator.

### E3 · Segment analysis

| | |
|---|---|
| **Question** | *Where* does TFM beat the incumbent — amount band, channel, tenure, card-present? |
| **Outcome** | Either a targeted deployment case or evidence the lift is diffuse |
| **Effort** | Low once E1 exists |
| **Needs** | E1 |

Often more actionable than the aggregate. A model that only wins on new accounts is
still deployable — on new accounts.

### E4 · Pool strategy ablation

| | |
|---|---|
| **Question** | Does the sophisticated pooling earn its complexity? |
| **Outcome** | Justification for `dcnv2` over `last`, or evidence it doesn't matter |
| **Effort** | 2–3 fine-tune runs |
| **Needs** | V2 |

**Genuinely open.** The default is `dcnv2`; the controlled run used `last`. If `last`
performs comparably, a large part of the architecture is unjustified complexity — a
legitimate finding either way.

### E5 · Window size sensitivity

| | |
|---|---|
| **Question** | Is 17 transactions right? |
| **Outcome** | Performance vs history length curve |
| **Effort** | 3–4 runs |
| **Needs** | V2 |

Directly operational: COM-006 notes fewer retained transactions improves production
efficiency. If 8 performs like 17, that halves the serving cost.

### E6 · Feature ablation

| | |
|---|---|
| **Question** | Which of the 19 components actually drive performance? |
| **Outcome** | Feature importance for a model that has no native feature importance |
| **Effort** | High — many runs |
| **Needs** | V5 |

Also a partial answer to the interpretability gap.

---

## 3. OPERATIONAL

| # | Item | Outcome | Effort |
|---|---|---|---|
| **O1** | Add determinism controls to the eval path | Scores regenerable on demand | Low — direct output of V1 |
| **O2** | Scoring latency measurement | Can it meet authorisation latency at all? | Low |
| **O3** | Interpretability tooling | Per-decision attribution | High — nothing exists today |
| **O4** | Runbook | Anyone on the team can re-run the validation | Low, accumulates from V1–V5 |

O2 is worth doing early and cheaply. If a single transaction takes 50ms on a GPU, that
is a deployment constraint the business should know about now, not after a year of
modelling work.

---

## 4. Sequencing

```
  V1 ──→ V2 ──→ V5 ──→ E1 ──→ E3        ← the critical path
              │     ╲
              │      ╲──→ V9
              ├──→ V8
              ├──→ E4
              └──→ E5

  V4 ─┐
  V6 ─┼─ all CPU-only, run in parallel with GPU jobs
  V7 ─┘

  V10 ── needs only source access
  O2  ── needs only a working checkpoint
```

**The GPU is the bottleneck, not you.** V2, V5, V8, E4, E5 are all long GPU jobs that
run one at a time. Everything CPU-only — V4, V6, V7, plus all writing — should be
scheduled *during* those runs, not instead of them.

Practical rhythm: **start a GPU job, then do CPU work while it runs.** Never sit waiting
on a job.

### Hard dependencies worth respecting

- **E1 after V5.** Feeding an unvalidated score into the champion model injects any
  leakage straight into production. The backtest would improve and live performance
  would not.
- **V9 after V5.** Benchmarking a leaky model against a clean one is meaningless.
- **V7 early.** It is cheap, and a failure invalidates every other result.

---

## 5. Phasing to January

**~15 weeks** from 21 September. December loses time to holidays, so plan on roughly
**13 effective weeks**. The mid-performance review at ~week 4 is a checkpoint to show
momentum, not the finish line — the two need different framing.

Nothing below is cut for feasibility. Everything in the inventory is in the plan.

### Phase 1 · Weeks 1–4 — Replication and first findings
**Ends at the mid-review. Optimised for demonstrable momentum plus one headline.**

| Week | Items | Deliverable |
|---|---|---|
| 1 | V1 inference replication · V7 train/eval separation | Memo 01 |
| 2 | V2 fine-tune replication · V6 chronology (CPU, during the V2 run) | Memo 02 |
| 3 | V5 ablations A–C · V11 calibration (CPU, during runs) | Memo 03 ⭐ |
| 4 | V12 cold-start · consolidate | **Mid-review packet** |

**At the review you can say:** replicated their inference and fine-tuning, produced four
memos, found N findings including the leakage ablation result, and scoped the full
programme to January.

V11 and V12 are deliberately placed here — both are **cheap, CPU-only, and likely to
produce findings**. High evidence-per-hour right when you need visible output.

### Phase 2 · Weeks 5–8 — Complete the validation core

| Week | Items |
|---|---|
| 5 | V5 run D (Falcon/predecline) · V4 data pipeline validation |
| 6 | V8 seed stability (3 runs) · V3 tiers 1–2 |
| 7 | V13 temporal backtesting · V14 missing-data sensitivity |
| 8 | V10 source confirmation · consolidate findings register |

**Output:** the validation findings register, complete. Every claim tagged
Supported / Not verified / Contradicted.

### Phase 3 · Weeks 9–12 — Experiments and the leverage case

| Week | Items |
|---|---|
| 9 | E4 pool strategy ablation · E5 window size |
| 10 | E1 ensemble test ⭐ · V9 benchmark vs incumbent |
| 11 | E3 segment analysis · V15 evasion |
| 12 | E2 embeddings · E6 feature ablation (start) |

**Output:** the business case. Does the TFM add anything over the XGBoost champion, and
where.

E1 lands here rather than earlier because it must follow V5 — the leakage clearance is
the prerequisite, not a nicety.

### Phase 4 · Weeks 13–15 — The hard part, and synthesis

| Week | Items |
|---|---|
| 13 | V3 tier 3 scaled-down pretraining replication |
| 14 | O3 interpretability tooling |
| 15 | Final report · runbook · handover |

**This phase is what separates a good validation from a memorable one.**

**V3 tier 3** — training a small model end to end from their data and pipeline. Most
validation teams never attempt pretraining at all.

**O3 interpretability** — nothing exists today, and it is an explicit open item in your
own Confluence record (31 Aug: *"Explore possible ways to explain the contribution of
each feature on the score"*). Three tractable approaches, in rising order of effort:

1. **Occlusion attribution** — mask one transaction or one field at a time, measure the
   score change. Crude, model-agnostic, immediately interpretable, and you can build it
   in a day on top of the ablation tooling you will already have.
2. **Attention attribution** — which history transactions does the cross-attention
   actually weight? `TransactionFeatureExtractor.cross_attn` returns weights; they are
   currently discarded (`ctx, _ = self.cross_attn(...)`). Capturing them is a one-line
   change to a copy of the module.
3. **Integrated gradients** — gradient-based attribution over the embedding inputs.
   Standard technique, more work, most defensible.

Delivering even (1) closes a gap the developing team left open. Delivering (1) and (2)
makes you the person who solved the model's explainability problem.

### Running throughout

- **O1** determinism controls — a direct output of V1, do it in week 1
- **O2** latency measurement — an hour, do it early; it may be a deployment blocker
- **O4** runbook — accumulates memo by memo, don't write it separately
- The **architecture walkthrough** to the team — pitch for week 3 or 4

### Slack

Weeks 8 and 12 have room. Use it — GPU jobs fail, data access takes longer than
expected, and December will eat more time than you plan for. A schedule with no slack
is a schedule that slips visibly.

---

## 5b. Two things to decide early

**GPU throughput is the binding constraint on the whole plan.** Phase 1 alone has ~6
long runs, and Phase 3 has ~8. On one GPU that is the entire timeline. Ask in week 1 —
you have a dependency graph to justify it, which makes it a resourcing conversation
rather than a complaint.

**Data access for V13 and V3.** Temporal backtesting needs several months of scored
data; scaled-down pretraining needs the pretraining corpus. Both have lead times. Request
in Phase 1, use in Phases 2 and 4.

Requesting things you will not need for two months is not premature — it is the
difference between a plan that runs and one that stalls waiting on access.

---

## 6. How to use this tomorrow

Bring the inventory. Not to present in full — to answer "what's the plan?" with
something that shows command of the problem.

The line to have ready:

> "I've scoped the full programme into three workstreams — validation, leverage
> experiments, and operational. Fifteen validation items, six experiments, four
> operational, phased to January.
>
> Phase 1 through to the mid-review is replication and the leakage ablations, because
> the ablations answer the risk the developer themselves flagged. Phase 2 completes the
> validation core. Phase 3 is the ensemble test against the XGBoost champion — that has
> to follow the leakage clearance, not precede it. Phase 4 is a scaled-down pretraining
> replication and interpretability tooling, which doesn't exist for this model today.
>
> The binding constraint is GPU throughput — the plan has around fifteen long runs and
> we have one GPU."

That reads as someone who has scoped the problem rather than someone working through a
task list — and it is accurate.

**Ask for one thing in the meeting:** whether more GPU time is available. The entire
plan is throughput-limited by one GPU, and that is a concrete, reasonable ask backed by
a dependency graph.
