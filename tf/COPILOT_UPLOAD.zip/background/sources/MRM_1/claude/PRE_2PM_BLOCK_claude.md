# No-compute work block

The goal for this block: **when the workbench comes back at 2, nothing is left on the
critical path except running the script and pasting in numbers.** Everything below can
be done without compute.

Order matters — 1 and 2 are the ones that actually buy you something.

---

## 1. Draft the memo, all of it except the numbers  ·  60–90 min

Open `WEEK1_MEMO_TEMPLATE_claude.md` and write every section that isn't a `___`.

Sections you can complete right now, with no compute:

- **§2 What was run** — checkpoint path, tokenizer path, eval data path, file count,
  hardware, precision. You know all of this.
- **§2 Configuration deviations** — the mask/fill_missing paragraph is already written.
  Adjust it to name the exact keys you actually had to set.
- **§3 Root cause** — written. Read it, make sure you can defend every sentence, and
  change anything you wouldn't say in your own words. **This matters.** If someone asks
  "why bf16?" in the meeting you need to answer without reading off the page.
- **§5 Recommendations** — written.
- **§6 Open items** — written.

That leaves only §1's two percentages, §3's three numbers, and §4's table. At 2pm the
script fills those in ~10 minutes.

**Why this is the highest-value thing in the block:** the failure mode tonight is
running the script at 2, getting numbers, and then discovering you still have two hours
of writing before it's shippable. Do the writing now while you can't run anything anyway.

---

## 2. Send the developer questions  ·  20 min

These block *future* weeks, and answers take days to come back. Getting them out today
means they may land before you need them. Drafted below — edit the tone to match how
your team writes.

> Subject: TFM v22b replication — a few questions
>
> Hi — I've been working through the v22b replication and have a few questions that
> would help me line my runs up with yours.
>
> **1. Run configuration.** Could you confirm the exact configuration used to produce
> the fine-tuned checkpoint? Specifically `pool_strategy`, `window_size`,
> `gradient_accumulation_steps`, the number of GPUs, and whether `use_hybrid_attention`
> was enabled. I want to make sure I'm comparing like for like.
>
> **2. Single-GPU reference.** I have one GPU available, so effective batch size differs
> from a 4-GPU run by 4×. Is there a single-GPU run I could compare against? I saw the
> controlled reconstruction was run on one GPU, so there may be a precedent.
>
> **3. Reproducibility.** When you re-run scoring on the same checkpoint and data, do you
> get bitwise identical scores? I'm seeing small differences (max ~0.007) and want to
> know whether that matches your experience or points at something in my setup.
>
> **4. Repo access.** Some files appear to have been altered when the codebase was
> transferred across. Could I get read access to the source repo so I can verify against
> the original rather than flagging transfer artifacts as findings?
>
> **5. Tokenizer config.** The supplied tokenizer `config.json` is missing some keys the
> loader requires (`mask_token`, `fill_missing`, `add_mask_token`). I set them to `False`
> to load it — could you confirm what they were when the tokenizer was saved?
>
> Thanks —

Question 3 is doing quiet work: it either confirms your finding or reveals a setup
difference, and either answer is useful. Asking it as "does this match your experience"
rather than "is this a bug" gets a more useful reply.

Question 5 is the one most likely to surface something — a config missing required keys
means the tokenizer was saved by a different code version than the one you were given.

---

## 3. Group 1 artifact checks — if you can see the files  ·  15 min

From `SCREENSHOT_REQUESTS_claude.md`. These need no compute, just the ability to open a
JSON file:

- [ ] Tokenizer `config.json` — is `fill_missing` present? Which keys are actually there?
- [ ] Model `config.json` — `vocab_size`, `d_model`, `n_layers`, `n_heads`, and the flags
      `use_rope`, `use_hybrid_attention`, `use_shared_position_ids`, `attention_type`
- [ ] `vocab.json` — count the entries, compare to `vocab_size` above

**The third one is a genuine check, not busywork.** If those two numbers disagree you
have a mismatched checkpoint/tokenizer pair and every score you've produced is
meaningless. Five minutes to rule out a week of wasted work.

The model `config.json` also tells us which architecture flags were actually used, which
closes finding B4 without needing the source repo at all.

---

## 4. Stage the 2pm commands  ·  10 min

Write out the exact commands with real paths filled in, so at 2pm you paste rather than
think. Something like:

```bash
# 1. Confirm both .npz files exist and have the keys we need
python -c "
import numpy as np
for f in ['THEIRS.npz','MINE.npz']:
    z = np.load(f, allow_pickle=True)
    print(f, '->', z.files, '| rows:', len(z['logits']))
"

# 2. Run the comparison
python compare_runs_claude.py \
  --run-a THEIRS.npz \
  --run-b MINE.npz \
  --src /path/to/supplied_files/src \
  --out memo01_comparison.md

# 3. (stretch) fp32 control run — turns the root cause from inferred to demonstrated
torchrun --nproc_per_node=1 -m evaluation.fraud_eval \
  --checkpoint_dir  /path/to/checkpoint \
  --data_dir        /path/to/eval_data \
  --tokenizer_path  /path/to/tokenizer \
  --output_dir      ./eval_fp32 \
  --store_logits
  # note: no --bf16 flag
```

**If you don't have their `.npz`** — only your own — run the script in single-run mode
(`--run-a MINE.npz` alone) and compare to their reported figures by hand in §4's table.
Still a complete memo.

---

## 5. Rehearse the meeting update  ·  20 min

You will likely get 60 seconds. Have this ready:

> "I replicated their inference — same checkpoint, same eval data, same config. It
> reproduces, but not bitwise: about 85% of scores match exactly, the rest differ by up
> to 0.007. I traced the cause: the codebase sets no determinism controls anywhere and
> defaults to bf16 inference, so run-to-run variation is expected by construction. The
> differences are symmetric around zero, which rules out a configuration mismatch.
>
> I'm quantifying whether it actually moves UDR/VDR at the 0.6% outsort — if it doesn't,
> it's an observation; if it does, the reported metrics need an error bar they don't
> currently have. Memo goes out this week.
>
> Separately: the fine-tune can't be reproduced on one GPU, because effective batch size
> scales with GPU count — their 4-GPU config gives 1024, mine gives 256. I'm running a
> matched-batch version this week and I've asked whether a single-GPU reference exists."

Then be quiet and let them ask.

**Things worth being able to answer without notes:**

- *What's UDR?* — Of all the fraud that existed, the fraction caught in the top 0.6% of
  scores. VDR is the same thing weighted by pound value.
- *Why does bf16 matter?* — It carries about 2–3 significant digits. Differences at the
  third decimal place are inside its normal accumulation error.
- *Is 0.007 a problem?* — Depends entirely on whether it moves transactions across the
  outsort cutoff. That's exactly what I'm measuring.
- *Why can't you just use 4 GPUs?* — I have one. And that's a real finding in itself:
  the result as reported isn't reproducible on the hardware available to validation.

That last answer reframes a limitation as a finding, which is both accurate and the
right framing.

---

## What not to do with this block

**Don't read the guide front to back.** It's a lookup table. If §3 of the memo has a
sentence you couldn't defend out loud, go read that specific part. Otherwise leave it.

**Don't start week 2 or 3 work.** Ship Memo 01 first. Finishing one thing beats starting
three.
