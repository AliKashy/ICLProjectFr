# The Transaction Foundation Model — A Complete Guide From Zero

**Repository:** `AliKashy/MRM_1`
**Subject:** The Payment / Transaction Foundation Model (TFM) contained in `supplied_files/`
**Audience:** Someone with **no background** in data science, machine learning, artificial intelligence, statistics, or distributed computing.

---

## How to read this document

This guide is written on one assumption: **you know nothing about machine learning, and that is fine.** Every technical term is defined the first time it appears. Nothing is assumed. If a concept is needed to understand a file in this repository, the concept is taught here first, even if the repository itself never explains it.

The guide is built in layers. Each layer only uses ideas from the layers before it:

| Part | What it teaches | Why you need it |
|---|---|---|
| **Part 1** | The business problem: card fraud, and how a bank measures a fraud detector | Without this, none of the design decisions make sense |
| **Part 2** | Machine learning from absolute zero | The foundation for everything |
| **Part 3** | Neural networks and how they learn | The machinery |
| **Part 4** | Language models and Transformers | The specific machine this project uses |
| **Part 5** | The core idea: treating payments as a language | The conceptual leap this project makes |
| **Part 6** | The tokenizer — turning transactions into words | The most important single component |
| **Part 7** | The data pipeline — every stage, every script | How raw bank data becomes training data |
| **Part 8** | The model code — every file in `modelling/` | The architecture |
| **Part 9** | Pretraining — teaching the model "normal" | Stage one of training |
| **Part 10** | Fine-tuning — teaching the model "fraud" | Stage two of training |
| **Part 11** | Evaluation — how we know if it works | Measurement |
| **Part 12** | Infrastructure — GPUs, Spark, S3, distributed training | How it runs at scale |
| **Part 13** | Complete file-by-file index | Reference — every file in the repo |
| **Part 14** | Risks, open questions, and things I found in the code | Honest assessment |
| **Part 15** | XGBoost, and how to leverage this model alongside it | The "what do we do with this?" question |
| **Part 16** | Glossary | Lookup |

**If you read this front to back, you will be able to explain this entire system to someone else.** That is the goal.

A note on the source material: this guide is built from the code and documentation in `supplied_files/`, plus the project record in `confluence/` and `project_communication/`. The PowerPoint in the repository root (`Transaction_Foundation_Model_Exact_Match_v4(1).pptx`) was, per your instruction, **not** relied upon; everything here traces to the supplied code and text files.

---
---

# PART 1 — THE BUSINESS PROBLEM

## 1.1 What is being solved

A bank issues debit and credit cards. Millions of times a day, someone swipes, taps, or types in a card number. Each of those events is a **transaction**. Most are legitimate. A tiny fraction — roughly **0.16%**, a number that appears as a hard-coded default in this codebase (`true_fraud_rate: Optional[float] = 0.0016` in `supplied_files/src/configs/fraud_eval.py`) — are **fraud**: someone using a card they are not entitled to use.

The bank wants to catch fraud *as it happens*, in the fraction of a second between the card being swiped and the authorisation decision being returned. This is the problem: **given everything we know about a transaction and about the account's history, how likely is it that this specific transaction is fraudulent?**

## 1.2 Why this is genuinely hard

Four properties make fraud detection much harder than it first appears.

**Extreme class imbalance.** If 0.16% of transactions are fraud, then a model that simply says "not fraud" to every single transaction is correct 99.84% of the time. Accuracy is therefore a useless measurement. This single fact drives an enormous number of the design choices in this codebase — the focal loss, the positive class weighting, the composite ranking loss, and the entire evaluation metric suite exist because of it.

**Fraud is contextual, not absolute.** A £2,000 electronics purchase in Tokyo is unremarkable for a frequent business traveller and highly suspicious for a pensioner who has never left their postcode. There is no threshold on any single field that separates fraud from non-fraud. **The account's history is the signal.** This is why the model reads sequences of transactions rather than single rows.

**Fraud adapts.** Fraudsters change tactics in response to detection. A model trained on last year's patterns degrades.

**Labels arrive late.** When a card is used fraudulently, nobody knows immediately. The customer notices the charge days or weeks later and disputes it. The bank investigates. Only then is the transaction *labelled* as fraud. This delay — called **label maturity** — is a central and unresolved risk in this project, and it appears repeatedly in the project record. It also creates the single biggest correctness trap in the codebase, which we will cover in detail (Part 14).

## 1.3 How a bank measures a fraud detector

This is critical vocabulary, and it is *not* standard machine learning vocabulary. It is fraud-industry vocabulary, and it is baked into this codebase's metric functions in `supplied_files/src/utils/fraud_metrics.py`.

### The "outsort" concept

A bank cannot investigate every transaction. It has a fixed capacity — say, enough analysts and automated blocks to handle **0.6% of all transactions**. So the model does not output "fraud" or "not fraud". It outputs a **score**, every transaction is ranked by that score from most to least suspicious, and the bank takes action on the **top 0.6%**.

That top slice is called the **outsort**. The percentage is the **outsort percentile**. In this repository the default percentiles are `[0.006, 0.01, 0.05]` — that is, 0.6%, 1%, and 5% (`supplied_files/src/configs/fraud_eval.py`).

This reframes the problem completely. **The model's job is not to classify. It is to rank.** All that matters is whether the real fraud floats to the top of the list. This is why the fine-tuning loss in this codebase includes explicit *ranking* terms (Part 10.7) — the training objective was deliberately reshaped to match the way the model is actually used.

### UDR — Unit Detection Rate

> Of all the fraudulent transactions that existed, what fraction landed in the outsort?

If there were 1,000 frauds and the top 0.6% of scores captured 400 of them, **UDR = 40%**. Every fraud counts equally — a £5 fraud and a £5,000 fraud each count as one "unit". This is what a statistician would call *recall at a fixed budget*.

### VDR — Value Detection Rate

> Of all the fraudulent *money* at risk, what fraction landed in the outsort?

Same calculation, but each fraud is weighted by its pound amount. If the 400 caught frauds were the large ones, VDR might be 70% even though UDR is only 40%. **VDR is usually what the business actually cares about**, because the bank's loss is measured in money, not in incident counts.

This is why the codebase carries a per-transaction `amount` column all the way through the data pipeline into the loss function, and why `amount_weighted_loss` exists as a configuration flag. The model is being pushed to care more about expensive fraud.

### FPR — False Positive Ratio (**note: not the textbook definition**)

This is a genuine trap for anyone with a statistics background. In standard machine learning, "FPR" (false positive rate) means `FP / (FP + TN)` — false alarms as a fraction of all legitimate transactions. **This codebase does not use that definition.** The source comment is explicit:

```python
# FPR here is FP/TP (not the usual FP/(FP+TN)).
```
> — `supplied_files/src/utils/fraud_metrics.py`

Here, **FPR = false positives ÷ true positives**. It answers the operational question: *"for every real fraud my analysts catch, how many innocent customers do they have to bother?"* An FPR of 20 means 20 legitimate customers are inconvenienced for every genuine fraud caught. That is a customer-experience and staffing number, and it is exactly what an operations manager wants to know.

### Calibrated FPR

There is a subtlety. During development, models are evaluated on data where fraud has been artificially over-represented (a process called **downsampling**, which we cover in Part 7.6). If your test set is 5% fraud but production is 0.16% fraud, the FPR you measure will be wildly optimistic.

The codebase corrects for this. From the source:

```
#   TP_rate = UDR * r          (fraction of total population correctly flagged fraud)
#   Flagged_rate = p           (fraction of total population flagged)
#   FP_rate = p - UDR * r      (fraction falsely flagged)
#   calibrated_fpr = FP / TP = (p - UDR * r) / (UDR * r)
```

where `r` is the true production fraud rate (0.0016) and `p` is the outsort percentile. This rescales the measured number to what the bank would actually see in production. It is a thoughtful piece of engineering and it is the kind of detail that separates a research demo from something a bank can act on.

### The supporting metrics

| Metric | Plain English | Where implemented |
|---|---|---|
| **AUC-ROC** | Pick one random fraud and one random non-fraud. What is the probability the model scores the fraud higher? 0.5 = coin flip, 1.0 = perfect. | `utils/fraud_metrics.py` |
| **KS statistic** | The biggest gap between the score distribution of frauds and the score distribution of non-frauds. Higher = better separated. A traditional credit-risk industry favourite. | `utils/metrics.py::ks_statistic` |
| **AP / AUC-PR** | Area under the precision-recall curve. More honest than AUC-ROC when positives are rare. | `utils/fraud_metrics.py` |
| **Log loss** | How well-calibrated the probabilities are, not just how well ranked. | `utils/fraud_metrics.py` |
| **Best F1 / F2** | Best achievable balance of precision and recall over all thresholds. F2 weights recall more heavily (catching fraud matters more than false alarms). | `utils/fraud_metrics.py` |

## 1.4 What this project actually built

The project record (`confluence/Foundation Model for Fraud` and `project_communication/TFM_V22B_Finalized_Package_PARTIAL.md`) shows a team that tried several approaches — off-the-shelf time-series foundation models (Chronos, TimesFM, TTM, Moirai), tabular transformers (SAINT, FT-Transformer), and even prompting a large language model with transactions converted to English sentences.

What is in `supplied_files/` is different and more ambitious: **a foundation model built from scratch, in-house, specifically for payment transactions.** Not a general-purpose model adapted to fraud — a model whose entire vocabulary, architecture, and training objective were designed around card transactions.

That is the thing this guide explains.

---
---

# PART 2 — MACHINE LEARNING FROM ABSOLUTE ZERO

If you already know what a loss function and gradient descent are, skip to Part 4. Otherwise, read this — everything later depends on it.

## 2.1 What "machine learning" actually means

Normal programming: **you write the rules.**

```
if amount > 1000 and country != home_country:
    flag_as_fraud()
```

This fails immediately. Some people travel. Some fraud is small. The rules multiply into thousands, conflict with each other, and become unmaintainable. Fraudsters learn them and route around them.

Machine learning inverts this: **you supply examples, and the computer derives the rules.**

You provide a large collection of transactions, each labelled "fraud" or "not fraud". A procedure automatically finds a mathematical function that maps transaction → score, such that the function gets the labelled examples right. Then you apply that function to new, unlabelled transactions.

The crucial word is **automatically**. Nobody writes the rules. Nobody even knows exactly what the rules are once they exist — this is the well-known interpretability problem, and the project record shows the team is explicitly worried about it (the 31 Aug 2026 Confluence entry lists "Model explainability approach" as a review item).

## 2.2 The three ingredients

**1. A model.** A mathematical function with adjustable dials. Feed it an input, it produces an output. The dials are called **parameters** or **weights**.

The simplest possible model:

```
score = w₁ × amount + w₂ × hour_of_day + b
```

Three dials: `w₁`, `w₂`, `b`. Turn them and the function behaves differently. The model in this repository has roughly **one billion** such dials (the fine-tuning script defaults point at a directory called `.../1B/decoder/...`). Same idea, vastly more dials.

**2. A loss function.** A single number measuring how wrong the model currently is. Low loss = good. High loss = bad. The loss function is how you *define* what "good" means; choosing it is a design decision with real consequences, and this codebase has an unusually rich set of them (Parts 9.5 and 10.7).

**3. An optimiser.** A procedure that adjusts the dials to make the loss go down.

Training = repeat {show examples → compute loss → adjust dials} millions of times.

## 2.3 Gradient descent — how the dials get turned

This is the single most important mechanism in all of machine learning. It is worth understanding properly.

**The mountain analogy.** You are on a foggy mountainside and want to reach the valley. You cannot see the valley. But you can feel the slope under your feet. So: feel which direction goes downhill, take a step that way, repeat. Eventually you reach the bottom.

In machine learning:
- **Your position on the mountain** = the current values of all the parameters
- **Your altitude** = the loss (how wrong the model is)
- **The slope** = the **gradient**
- **The valley** = parameter values that make the loss small
- **Step size** = the **learning rate**

The gradient is a mathematical object that tells you, for *every single one* of your billion parameters simultaneously, "if you nudge this parameter up slightly, does the loss go up or down, and by how much?" Computing it is done by an algorithm called **backpropagation**, which is just the chain rule from calculus applied systematically backwards through the network. You do not need to be able to do it by hand — PyTorch does it for you when you call `.backward()`. You need to know what it does.

**The learning rate** is how big a step you take. This is the most consequential single hyperparameter in training:
- Too large → you overshoot the valley, bounce around, and the loss may explode to infinity or `NaN` ("not a number"). The pretraining guide's troubleshooting table lists exactly this: *"Loss NaN → Lower learning_rate."*
- Too small → training takes forever.

In this repository the pretraining learning rate defaults to `3e-3` (0.003) and fine-tuning uses `1e-5` for the pretrained layers and `1e-4` for the new layers — a hundred-fold difference between the two, which is deliberate and explained in Part 10.8.

## 2.4 The vocabulary you now need

| Term | Meaning |
|---|---|
| **Feature** | One piece of input information (amount, merchant country, hour of day) |
| **Label** | The correct answer you are training toward (fraud = 1, legitimate = 0) |
| **Training set** | Examples the model learns from |
| **Validation set** | Held-out examples used to check progress during training |
| **Test / OOT set** | Held-out examples used for the final honest measurement. **OOT = "out of time"** — data from a *later* period than training, which is the only fair test for a fraud model because it simulates deployment |
| **Epoch** | One full pass through the training data |
| **Batch** | A group of examples processed together (this codebase: 32 at a time by default) |
| **Step / iteration** | One update of the parameters |
| **Overfitting** | The model memorised the training data instead of learning generalisable patterns. Performs brilliantly on training data, badly on new data. The central failure mode of machine learning |
| **Underfitting** | The model is too simple to capture the pattern |
| **Hyperparameter** | A setting *you* choose before training (learning rate, model size), as opposed to a parameter the model *learns* |
| **Inference** | Using a trained model to make predictions. Sometimes called "scoring" |

## 2.5 Overfitting and regularisation

Overfitting deserves its own section because so much of this codebase's configuration exists to prevent it.

A model with a billion parameters can, in principle, memorise its training data exactly. Every training example gets its answer stored somewhere in those parameters. Training loss goes to zero. And the model is completely useless, because it learned *these specific transactions* rather than *what fraud looks like*.

Defences used in this codebase:

**Dropout.** During training, randomly switch off a percentage of the model's internal signals on every pass. This forces the model to spread its knowledge redundantly rather than relying on any single pathway. Configured as `dropout: 0.2` (20%), `attention_dropout: 0.1`, `residual_dropout: 0.0` in `ModelConfig`. Dropout is *only* active during training; at inference time everything is switched back on.

**Weight decay.** Add a penalty to the loss proportional to the size of the parameters, pushing them toward zero unless the data gives a strong reason to be large. `weight_decay: 0.01` in pretraining, a much more aggressive `0.2` in fine-tuning (fine-tuning has far less data and is far more prone to overfitting).

**Held-out evaluation.** Never measure final performance on data you trained on. The fine-tuning configuration reserves the last 5 parquet files for evaluation by default (`eval_files: int = 5`), or lets you point at a completely separate directory (`eval_data_dir`).

**Early stopping in spirit.** Checkpoints are saved every N steps so you can pick the one that performed best on held-out data rather than the final one.

---
---

# PART 3 — NEURAL NETWORKS

## 3.1 The neuron

The basic unit. It does three things:

1. Take several numbers as input
2. Multiply each by a weight and add them up, plus a constant called a **bias**
3. Pass the result through a **activation function**

```
output = activation(w₁x₁ + w₂x₂ + ... + wₙxₙ + b)
```

Step 2 alone is just a weighted average — linear. Step 3 is what makes neural networks powerful.

## 3.2 Why activation functions matter

Without an activation function, stacking layers is pointless. A linear function of a linear function is still just a linear function. You could stack a thousand layers and mathematically collapse them into one. The network would only ever be able to draw straight lines.

The activation function is a simple non-linear bend. It breaks that collapse. With non-linearity, stacked layers can represent arbitrarily complex shapes — this is the **universal approximation** property, and it is why deep networks work at all.

Activations available in this codebase (`supplied_files/src/modelling/feed_forward.py`):

| Name | Formula | Behaviour |
|---|---|---|
| **ReLU** | `max(0, x)` | Negative inputs → 0, positive pass through. Simple, fast, the historical workhorse |
| **GELU** | smooth approximation of ReLU | Softer transition around zero, standard in Transformers |
| **SiLU / Swish** | `x · sigmoid(x)` | Smooth, self-gating |
| **SwiGLU** | `(SiLU(xW₁) ⊙ xW₃)W₂` | **The default here.** A *gated* variant: one branch computes values, another computes a gate that multiplies them element-wise. Used in Llama, PaLM, and most modern large models. Consistently outperforms plain activations |

A detail worth understanding in the SwiGLU implementation. Because SwiGLU needs *two* input projections instead of one, using the configured `d_ff` directly would make the layer 50% larger than intended. The code compensates:

```python
d_ff = int(2 * d_ff / 3)
d_ff = multiple_of * ((d_ff + multiple_of - 1) // multiple_of)
```

It scales `d_ff` down by 2/3 to keep the parameter count matched, then rounds up to a multiple of 256 because GPU matrix multiplication is dramatically faster on nicely-aligned dimensions. This `2/3` convention comes directly from the Llama papers. It is a small thing, but it tells you the implementation is following current best practice rather than improvising.

## 3.3 Layers, depth, and width

A **layer** is a group of neurons operating in parallel on the same input. A **network** is layers stacked so that each layer's output is the next layer's input.

Two size dimensions:
- **Width** (`d_model` = 2048 here): how many numbers flow through at each position. More width = more information carried per position
- **Depth** (`n_layers` = 16 here): how many layers. More depth = more stages of refinement

Rough intuition for what depth buys you: early layers learn simple local patterns, later layers combine them into abstractions. In a vision model, early layers detect edges and late layers detect faces. In this transaction model, early layers might learn "this token is an amount bin", and late layers might learn "this pattern of amount, merchant, and timing is anomalous relative to this account's history".

## 3.4 Two structural inventions that make deep networks trainable

Stacking 16 layers naively does not work. Two techniques from the deep learning literature make it work, and both are in this codebase.

### Residual connections (skip connections)

Instead of `output = layer(input)`, do:

```
output = input + layer(input)
```

The layer learns a *correction* to its input rather than a complete replacement. Two enormous benefits:

1. **Gradients flow.** During backpropagation, gradients have a direct path backwards through the `+` operation. Without this, gradients shrink multiplicatively as they pass back through layers and become effectively zero in the early layers — the **vanishing gradient problem**. This is precisely what stopped deep networks from working before 2015.
2. **Layers can do nothing.** If a layer isn't helpful, it can learn to output approximately zero and the input passes through unchanged. Depth becomes safe to add.

You can see this in `supplied_files/src/modelling/transformer.py`:

```python
residual = x
x = self.norm1(x)
attn_output = self.attention(x, ...)
x = residual + attn_output      # ← the residual connection
```

### Normalisation

As data flows through layers, the scale of the numbers drifts — growing or shrinking until the network becomes numerically unstable. Normalisation rescales the numbers back to a standard range at each layer.

Two variants implemented here:

**LayerNorm** — subtract the mean, divide by the standard deviation, then apply a learned scale and shift.

**RMSNorm** — **the default in this model.** Skips the mean-subtraction entirely, just divides by the root-mean-square:

```python
rms = torch.sqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)
return self.weight * x / rms
```

RMSNorm is cheaper (no mean computation, no shift parameter) and empirically performs just as well. Llama uses it. This codebase defaults to it (`norm_type: "rmsnorm"`).

**Pre-norm vs post-norm** (`norm_position`, default `"pre"`): whether normalisation happens *before* the layer's computation or *after* the residual addition. Pre-norm is more stable for deep networks and is what essentially all modern large models use. The code supports both; the default is correct.

The `eps` (epsilon, `1e-5`) is a tiny number added before dividing, so that if a vector happens to be all zeros you divide by `0.00001` instead of by zero and crash.

---
---

# PART 4 — LANGUAGE MODELS AND TRANSFORMERS

## 4.1 What a language model does

A language model does one thing: **given a sequence so far, predict what comes next.**

```
"The cat sat on the ___"
                      ↓
          mat: 40%, floor: 15%, chair: 10%, ...
```

That is genuinely all it does. Every impressive behaviour of ChatGPT and its relatives emerges from doing this one thing extremely well at enormous scale.

Why is this such a powerful training objective? Because **the training labels are free**. You do not need humans to annotate anything. Take any text, hide the next word, ask the model to predict it, compare to the actual word. Unlimited training data at zero labelling cost. This is called **self-supervised learning**, and it is the reason foundation models exist.

To predict the next word well, a model is forced to learn grammar, facts, reasoning patterns, and style — because all of those are needed to predict accurately. The prediction task is a *proxy* that forces genuine understanding.

**The leap this project makes:** replace "words" with "transaction attributes". Then:

```
[Δt: 2 hours] [10am] [Tuesday] [online] [£47] [grocery] [UK] ... → ???
```

The model learns to predict the next attribute. To do that well it must learn spending rhythms, merchant preferences, typical amounts, geographic patterns — an internal model of *how this account normally behaves*. And a transaction that the model finds deeply surprising is, by construction, an anomaly. That is the bridge from language modelling to fraud detection.

## 4.2 Tokenization

Computers process numbers, not text. **Tokenization** is the conversion from raw input to a sequence of integers.

The pieces:
- A **token** is the atomic unit — roughly a word, or part of a word
- The **vocabulary** is the complete list of possible tokens
- Each token gets an integer **token ID** — its index in the vocabulary
- **Encoding** = text → IDs. **Decoding** = IDs → text

```
"the cat sat"  →  ["the", "cat", "sat"]  →  [1523, 8891, 2244]
```

The model never sees text. It sees `[1523, 8891, 2244]`.

Crucially: **the ID numbers are arbitrary labels, not quantities.** Token 8891 is not "more" than token 1523. They are just names. The model learns meaning through embeddings (next section), not through the numeric value of the ID.

Every vocabulary needs **special tokens** for structural purposes. This codebase has five (from `supplied_files/src/data_pipeline/utility_lib/tokenizer.py`):

| Token | ID | Purpose |
|---|---|---|
| `<BOS>` | 0 | Beginning of sequence |
| `<EOS>` | 1 | End of sequence |
| `<PAD>` | 2 | Filler, to make all sequences in a batch the same length |
| `<UNK>` | 3 | Unknown — a value not in the vocabulary |
| `<GAP>` | 4 | **The transaction separator.** This project's key structural innovation |

Those IDs are fixed by the order in which `_build_vocabulary()` adds them, and **the entire codebase depends on `<GAP>` being ID 4.** It appears as a default in `ModelConfig.gap_token_id: int = 4`, in `create_hybrid_attention_mask(gap_token_id: int = 4)`, in the segmentation functions, in the YAML pipeline configs (`gap_token: 4`), and in the test file. It is a load-bearing constant.

## 4.3 Embeddings — the most important concept in the whole system

You have a token ID: `8891`. What do you do with an arbitrary integer?

**Naive approach (one-hot encoding).** Represent token 8891 as a vector of 300,000 numbers, all zero except position 8891 which is 1. This is mathematically clean but disastrous in practice: the vectors are enormous, almost entirely zeros, and — fatally — *every token is equidistant from every other token*. "MERCHANT_CATEGORY_5411" (grocery) and "MERCHANT_CATEGORY_5412" (also food retail) would be exactly as unrelated as grocery and gambling. All semantic structure is destroyed.

**The embedding solution.** Give each token a **dense vector** — a list of, here, 2,048 real numbers. Those numbers are **learned during training**.

```
MERCHANT_CATEGORY_5411 → [ 0.23, -1.04,  0.87, ...,  0.12]   (2048 numbers)
MERCHANT_CATEGORY_5412 → [ 0.21, -0.99,  0.91, ...,  0.15]   (2048 numbers)
MERCHANT_CATEGORY_7995 → [-1.55,  0.42, -0.33, ...,  0.88]   (2048 numbers)
```

Because the vectors are learned, **tokens that behave similarly end up with similar vectors.** Two grocery merchant categories that appear in the same contexts will drift toward each other in this 2,048-dimensional space. A gambling category will end up far away. The model discovers this structure itself — nobody tells it that 5411 and 5412 are related.

This space is called the **embedding space** or **latent space**, and the individual dimensions have no human-interpretable meaning. Direction and distance in that space carry the meaning.

In code (`supplied_files/src/modelling/embedding.py`):

```python
self.embedding = nn.Embedding(config.vocab_size, config.d_model)
```

This is literally a lookup table with 300,000 rows and 2,048 columns — **614 million parameters in the embedding layer alone**, all learned. `nn.Embedding` is mathematically identical to one-hot-times-matrix, but implemented as a table lookup, which is vastly faster.

**The `√d` scaling.** Note this line:

```python
if scale:
    embeddings = embeddings * (self.d_model ** 0.5)
```

Embeddings are initialised as small random numbers (standard deviation 0.02). Positional embeddings, which get added next, range from −1 to +1. Without scaling, the positional signal would completely drown the token signal. Multiplying by `√2048 ≈ 45.25` puts them on comparable footing. This comes straight from the original "Attention Is All You Need" paper and is controlled by `scale_embeddings: bool = True`.

## 4.4 Attention — the core mechanism

This is the idea that made Transformers work and it deserves careful explanation.

**The problem it solves.** Consider: *"The account holder, who had been travelling in Spain for two weeks, made a purchase in Madrid."* To judge whether "Madrid" is normal, you must connect it to "Spain" — **eleven words earlier**. Older architectures (recurrent networks) processed sequences one step at a time, carrying a fixed-size memory forward. By word eleven, the memory of "Spain" had degraded. Long-range dependencies were lost.

Attention solves this directly: **every position can look at every other position, in one operation, with no distance penalty.**

### The mechanism

Each position produces three vectors from its own embedding, via three learned weight matrices:

| Vector | Intuition | Code |
|---|---|---|
| **Query (Q)** | "What am I looking for?" | `self.q_proj` |
| **Key (K)** | "What do I contain?" | `self.k_proj` |
| **Value (V)** | "What do I contribute if you attend to me?" | `self.v_proj` |

The library analogy: your **query** is what you want to know. Each book's **key** is its title and index. You compare your query against every key to find relevance. Then you read the **value** — the actual content — of the relevant books, weighted by how relevant each was.

The computation:

1. **Score every pair.** Take a dot product between each query and every key. A high dot product means the vectors point in similar directions — "this key is relevant to this query". Result: a `seq_len × seq_len` matrix of relevance scores.
2. **Scale.** Divide by `√head_dim`. Without this, dot products of high-dimensional vectors grow large, softmax becomes extremely peaked, and gradients vanish. In code: `self.scale = 1.0 / math.sqrt(self.head_dim)`.
3. **Mask.** Set forbidden positions to negative infinity so they get zero weight (Part 4.6).
4. **Softmax.** Convert the scores into weights that are all positive and sum to 1 — a probability distribution over "where to look".
5. **Weighted sum.** Combine the value vectors using those weights.

The output at each position is a blend of information from everywhere in the sequence, weighted by learned relevance.

### Multi-head attention

One attention operation can only focus on one kind of relationship at a time. So the model runs several in parallel — **heads**. This model has `n_heads: 32` with `d_model: 2048`, so each head works in a `2048 / 32 = 64`-dimensional subspace.

Different heads specialise. One might track "same merchant as before", another "unusual amount", another "geographic jump". Their outputs are concatenated and passed through one more projection (`out_proj`) to mix them back together.

### The implementation

```python
with torch.backends.cuda.sdp_kernel(enable_flash=True, enable_mem_efficient=True, enable_math=False):
    attn_output = F.scaled_dot_product_attention(q, k, v, attn_mask=attn_mask_add, ...)
```

Rather than writing out the matrix operations, the code calls PyTorch's fused implementation and explicitly requests **FlashAttention**. FlashAttention is an algorithm that computes exactly the same result but never materialises the full `seq_len × seq_len` attention matrix in GPU memory. For a 2,048-token sequence with 32 heads, that matrix would be over 4 million entries *per head per layer*. FlashAttention restructures the computation to work in small tiles inside fast on-chip memory. It is the difference between this model being trainable and not being trainable.

## 4.5 Positional information

Attention has a hidden flaw: it is **permutation-invariant**. The weighted sum in step 5 does not care about order. Shuffle the input sequence and the output is shuffled identically — no information about position is used at all.

For transactions, order is everything. Three transactions in five minutes is a different story from three transactions over three weeks. So position must be injected explicitly. This codebase implements **three** mechanisms.

### (a) Sinusoidal positional embeddings

Add a fixed pattern of sine and cosine waves at different frequencies to each position's embedding:

```python
pe[:, 0::2] = torch.sin(position * div_term)
pe[:, 1::2] = torch.cos(position * div_term)
```

Each position gets a unique signature. Because sines and cosines have useful shift properties, the model can learn to compute relative offsets from these. Fixed, not learned — so it extrapolates to lengths never seen in training. Controlled by `use_positional_embeddings: bool = True`.

### (b) RoPE — Rotary Position Embedding

The modern approach, and the one enabled by default in the pretraining configuration (`ModelConfig(use_rope=True)`).

Instead of *adding* a position signal to the embedding, RoPE **rotates** the query and key vectors by an angle proportional to their position. Pairs of dimensions are treated as points on a plane and spun.

The elegance is in what happens next. When you take the dot product of two rotated vectors, the rotation angles subtract. The result depends only on the *difference* in positions — the relative distance — not on the absolute positions. **RoPE makes attention naturally relative.** A transaction three steps back is treated the same way whether it is at positions 5→8 or 500→503.

Implementation notes from `supplied_files/src/modelling/rope.py`:
- `rope_theta: 10000.0` sets the base frequency — how fast different dimension pairs rotate. Low dimensions rotate fast (fine positional detail), high dimensions rotate slowly (coarse long-range position)
- `rope_scaling_factor` compresses positions, a standard trick to extend a model's usable context beyond its trained length
- The implementation precomputes and caches the sine/cosine tables, and the comments explain why: *"This keeps the RoPE path sync-free and shape-stable (important for throughput and torch.compile)"*. Recomputing trigonometry per batch, or reading a tensor value back to the CPU, would force the GPU to stall

### (c) Shared per-transaction positions + field-type embeddings

This is bespoke to this project and it is genuinely clever. Two config flags: `use_shared_position_ids` and `use_field_type_embedding`.

Here is the problem it solves. A transaction is tokenized into a fixed sequence of fields — delta-time, hour, day, channel, amount, merchant, country, and so on, always in the same order. But those fields are **not sequential in any meaningful sense**. The hour of day does not come "before" the merchant category in any real way; they are simultaneous attributes of one event. Yet RoPE would assign them positions 0, 1, 2, 3... and impose a spurious ordering.

The fix:

**`build_shared_position_ids`** gives every token inside one transaction the *same* position index:

```python
is_gap = (input_ids == gap_token_id).long()
return torch.cumsum(is_gap, dim=1) - is_gap
```

A running count of `<GAP>` tokens. Every token in transaction 0 gets position 0, every token in transaction 1 gets position 1. Since RoPE is relative, tokens within a transaction now have **zero relative rotation** — no positional signal between them at all. Transactions still get distinct positions relative to each other. The `- is_gap` term is a careful detail: it keeps each `<GAP>` grouped with the transaction it *closes* rather than the one it opens.

**`build_field_type_ids`** then restores the lost per-field identity, but as *type* rather than *order*:

```python
marker = torch.where(is_gap, idx, torch.full_like(idx, -1)).clone()
marker[:, 0] = 0
last_boundary = torch.cummax(marker, dim=1).values
field_ids = idx - last_boundary - 1
```

This computes each token's offset from the start of its transaction. Because the schema is fixed, **offset = column index**. Token at offset 3 is always the same field. A learned `nn.Embedding(max_fields, d_model)` then gives each column its own identity vector, added to the token embedding.

The net effect: the model knows *which field* a token is, and *which transaction* it belongs to, but not a fake ordering *within* the transaction. This is exactly the right inductive bias for tabular-sequential data, and the dedicated unit test (`test/test_shared_position_field_ids.py`) shows the team took it seriously.

### (d) Delta-temporal attention bias

A fourth, optional mechanism (`attention_type: "delta_temporal"`). `DeltaTemporalBias` in `attention.py` adds a learned bias to attention scores based on the difference in *time-gap bins* between two positions. It lets the model learn things like "transactions with similar inter-arrival times should attend to each other". It is off by default (`attention_type: "standard"`) — likely because it forces the code off the FlashAttention fast path (the bias must be added before softmax, so `DeltaTemporalAttention` computes attention manually, which is substantially slower).

There is also a `HybridTransformerBlock` that runs *both* standard and delta-temporal attention and blends them with learnable weights initialised to `[0.7, 0.3]`. Present in the codebase but not wired into the default `PaymentFoundationModel`, which builds plain `TransformerBlock`s.

## 4.6 Attention masks — and this project's custom one

A mask tells attention which positions are forbidden. Set a position's score to negative infinity before softmax and it receives exactly zero weight.

**Padding mask.** Sequences in a batch have different lengths, so short ones are filled with `<PAD>`. The padding mask makes sure real tokens never attend to padding.

**Causal mask.** For next-token prediction, position `i` must not see positions after `i` — otherwise the model could simply read the answer. A lower-triangular matrix of ones enforces this:

```python
causal_mask = torch.tril(torch.ones(seq_len, seq_len, ...))
```

### The hybrid mask — this project's design decision

Standard causal masking is right for text, where words genuinely arrive one at a time. But within a single transaction, all the fields exist **simultaneously**. Forcing the merchant field to be blind to the amount field is an artificial handicap.

`create_hybrid_attention_mask()` in `supplied_files/src/modelling/model.py` implements the fix:

```python
causal_mask = torch.tril(torch.ones(seq_len, seq_len, ...))
attention_mask = causal_mask.unsqueeze(0).expand(batch_size, -1, -1).clone()

is_gap = (input_ids == gap_token_id)
transaction_ids = torch.cumsum(is_gap, dim=1)
same_transaction = (transaction_ids.unsqueeze(2) == transaction_ids.unsqueeze(1))

upper_tri = torch.triu(torch.ones(seq_len, seq_len, ...), diagonal=1)...
attention_mask = torch.clamp(attention_mask + same_transaction.to(dtype) * upper_tri, 0, 1)
```

Read it as: start causal; then, wherever two positions belong to the *same* transaction, also allow the forward direction.

The result:
- **Within a transaction: bidirectional.** Every field sees every other field. Like BERT
- **Across transactions: strictly causal.** Transaction 5 can see transactions 1–4 but never 6–10. Like GPT

This is listed under "Key Design Decisions" in the README as *"bidirectional within transactions, causal across transactions (GAP-delimited)"* and it is arguably the single best architectural idea in the project. It matches the actual causal structure of the data: transactions are ordered in time; fields within one transaction are not.

**Important operational note:** this mask is **not on by default**. `PaymentFoundationModel.forward` takes `use_hybrid_attention: bool = False`, and the trainer's `_forward_loss` calls the model without setting it. Whether it was enabled in any particular training run is a configuration question, not an architecture question. This matters for anyone reproducing results.

## 4.7 Putting a Transformer block together

Each of the 16 layers, in pre-norm configuration:

```
input
  │
  ├──────────────────────────┐  (save for residual)
  ↓                          │
RMSNorm                      │
  ↓                          │
Multi-Head Attention         │
  ↓                          │
Dropout                      │
  ↓                          │
  +  ←──────────────────────┘  (residual add)
  │
  ├──────────────────────────┐  (save for residual)
  ↓                          │
RMSNorm                      │
  ↓                          │
Feed-Forward (SwiGLU)        │
  ↓                          │
Dropout                      │
  ↓                          │
  +  ←──────────────────────┘  (residual add)
  │
output → next layer
```

Attention moves information *between* positions. The feed-forward network processes each position *independently* and more deeply. Attention gathers context; the FFN thinks about it. Stack 16 of these and you have the backbone of the model.

## 4.8 The output head and weight tying

After the final layer and a final normalisation, the model has a 2,048-number vector per position. To predict the next token it needs a score for each of 300,000 vocabulary entries. That is the **LM head** — a single linear layer projecting 2,048 → 300,000.

**Weight tying** (`tie_word_embeddings: bool = True`):

```python
if config.tie_word_embeddings:
    self.lm_head.weight = self.token_embedding.embedding.weight
```

The output projection matrix is *the same tensor* as the input embedding matrix. This saves 614 million parameters and is grounded in a real symmetry: the input embedding maps token→vector, the output head maps vector→token score. Making them share weights forces a consistent representation and is known to improve results.

**Softmax and logits.** The raw 300,000 numbers are called **logits** — unbounded scores. Softmax converts them to probabilities (all positive, summing to 1). For a binary output like the fraud classifier, the equivalent is the **sigmoid**, which squashes a single number to the range 0–1.

A practical note you will see throughout the code: loss functions are computed **from logits, not from probabilities** (`BCEWithLogitsLoss`, `binary_cross_entropy_with_logits`). Combining the sigmoid and the loss into one operation is mathematically identical but numerically far more stable — it avoids computing `log(0)`.

---
---

# PART 5 — THE CORE IDEA: PAYMENTS AS A LANGUAGE

## 5.1 What a "foundation model" is

A **foundation model** is trained once, on a huge amount of unlabelled data, with a self-supervised objective (like next-token prediction). It learns general structure about its domain. Then it is **adapted** to many specific tasks with comparatively tiny amounts of labelled data.

The economics are the entire point:

| | Traditional approach | Foundation model approach |
|---|---|---|
| Fraud detection | Train a model on labelled fraud | Fine-tune the foundation model |
| Credit risk | Train a *separate* model | Fine-tune the same foundation model |
| Customer churn | Train *another* separate model | Fine-tune the same foundation model |
| Marketing propensity | Another one | Fine-tune the same foundation model |

Each traditional model needs its own feature engineering, its own labelled dataset, its own validation. The foundation model learns "how payment behaviour works" once — from *billions* of unlabelled transactions, which the bank already has — and each downstream task inherits that understanding.

The README states the ambition plainly: *"A transformer-based foundation model for payment-transaction sequences."* Fraud is the first application, not the only intended one.

## 5.2 The representation problem

A transaction naturally looks like a spreadsheet row:

| account | timestamp | amount | merchant_cat | country | channel | ... |
|---|---|---|---|---|---|---|
| A-1234 | 2025-03-14 10:23 | 47.82 | 5411 | GB | online | ... |

Standard approaches to tabular data (gradient-boosted trees such as XGBoost, and the FT-Transformer / SAINT models the team benchmarked per the Confluence record) treat each column as a typed feature with its own encoder.

This project does something different. **Every field becomes a token, and a transaction becomes a sentence.**

```
Transaction  →  [Δt_BIN_03] [HOD_10] [DOW_4] [CHANNEL_ONLINE] [TRANSACTION_RANGE_12]
                [MERCHANT_CATEGORY_5411] [MERCHANT_COUNTRY_826] ... 
```

And an account's history becomes a paragraph:

```
<BOS> txn₁_tokens <GAP> txn₂_tokens <GAP> ... <GAP> txnₙ_tokens <EOS>
```

## 5.3 Why this representation is the right call

**It unifies every data type.** Amounts, categories, countries, timestamps, IP addresses, postal codes — all become tokens. One mechanism handles everything. No separate embedding strategy per column type.

**It makes the full Transformer toolkit available.** Attention, next-token prediction, all of the pretraining machinery developed for language — they apply directly.

**It handles variable-length history naturally.** Some accounts have 3 transactions, some have 3,000. A sequence model handles this without padding tricks or hand-built aggregate features ("average spend last 30 days", "count of transactions last 7 days", etc.). Those aggregates are exactly the manual feature engineering that dominates traditional fraud modelling, and the sequence representation makes them unnecessary — the model learns whatever temporal aggregates it finds useful.

**It makes anomaly detection intrinsic.** A well-trained model assigns a probability to every token. A transaction composed of tokens the model finds improbable *given this account's history* is, by definition, unusual. The fraud signal falls out of the language modelling objective.

**Missing values are just tokens.** `fill_missing` mode emits explicit `_MISSING` tokens. Absence becomes a first-class signal the model can learn from, rather than something to impute or drop.

## 5.4 The cost of this representation

Be honest about the trade-offs.

**Numbers lose their arithmetic.** `TRANSACTION_RANGE_12` and `TRANSACTION_RANGE_13` are adjacent bins, but as tokens they are unrelated symbols. The model must *learn* that they are close from co-occurrence patterns. This is genuinely a loss of information relative to feeding a raw number. The codebase fights back with **ordinal loss functions** (CORAL, CORN, EMD — Part 9.5) that explicitly reintroduce the notion that bins are ordered. The existence of four different ordinal loss implementations tells you how much effort went into this problem.

**Binning discards precision.** £47.82 and £49.99 may land in the same bin and become indistinguishable. Bin boundaries are a design choice with real consequences.

**Sequences get long.** Roughly 20 fields per transaction × 17 transactions ≈ 340+ tokens per example, and attention cost grows quadratically with length. The 2,048 token limit caps history depth.

**Vocabulary is large.** 300,000 entries × 2,048 dimensions = 614M parameters in the embedding table alone. Most of that is high-cardinality hashed fields.

## 5.5 The 19 transaction components

The README documents 19 semantic components, and `supplied_files/src/utils/component_patterns.py` is the authoritative machine-readable definition. This file is the bridge between the tokenizer and the evaluation code: it holds regular expressions that map any token string back to its component name, so evaluation can report accuracy *per field* rather than only in aggregate.

| # | Component | Token pattern | Type | What it tells the model |
|---|---|---|---|---|
| 1 | Delta time | `Δt_BIN_XX` | Numerical | Time since previous transaction — the rhythm signal |
| 2 | Hour of day | `HOD_XX` | Numerical | 0–23. Captures "this account never transacts at 3am" |
| 3 | Day of week | `DOW_X` | Categorical | 0–6. Weekday vs weekend behaviour |
| 4 | Channel | `CHANNEL_XXX` | Categorical | Online, in-store, ATM, phone |
| 5 | Terminal type | `TERMINAL_TYPE_X` | Categorical | POS terminal, ATM, e-commerce gateway |
| 6 | Cardholder present | `CARDHOLDER_PRESENT_X` | Categorical | Physically present or card-not-present. A major fraud discriminator |
| 7 | Transaction category | `TRANSACTION_CATEGORY_X` | Categorical | Purchase, cash advance, refund |
| 8 | Transaction type | `TRANSACTION_TYPE_X` | Categorical | Debit/credit/reversal |
| 9 | **Transaction amount** | `TRANSACTION_RANGE_XX` | Numerical | The binned amount. The single most-modelled field |
| 10 | Available daily cash limit | `AVAILABLE_DAILY_CASH_LIMIT_RANGE_XX` | Numerical | Remaining headroom — fraudsters often test limits |
| 11 | Balance | `TOTAL_AVAILABLE_BALANCE_RANGE_XX` | Numerical | Account balance bucket |
| 12 | Merchant category code | `MERCHANT_CATEGORY_XXX` | Categorical | Industry-standard MCC. Gambling, crypto, electronics carry elevated risk |
| 13 | Merchant country | `MERCHANT_COUNTRY_XXX` | Categorical | Where the merchant is |
| 14 | Merchant postal code | `MERCHANT_POSTAL_XXX` | Hashed | Fine-grained geography |
| 15 | Cardholder country | `CPRSRVC__PISINFO_CARDHOLDER_COUNTRY_XXX` | Categorical | Where the customer lives |
| 16 | Travel country | `CPRSRVC__DBT_TRAVEL_..._COUNTRY_XXX` | Categorical | Declared travel — explains foreign transactions legitimately |
| 17 | Cardholder postal code | `CPRSRVC__PISINFO_CARDHOLDER_POSTAL_XXX` | Hashed | Home location |
| 18 | PIS status | `CPRSRVC__PISINFO2_STATUS_XXX` | Categorical | Card/account status |
| 19 | IP address | `USER_DATA_5_STRG_DEVICE_IP_ADDRESS_DBC3DS_XXX` | Hashed | Device network origin for online transactions |

The `CPRSRVC__` prefix indicates fields sourced from an internal card-processing service. The exact meanings sit in the bank's metadata tables — the Confluence record (COM-004) notes the Developer's guidance to pair tokenizer configuration with metadata tables for field descriptions.

Note the *combinatorial* power here. Cardholder country (15) + merchant country (13) + travel country (16) together let the model reason: "transaction in Spain, customer lives in UK, no declared travel" — a pattern no single field expresses.

---
---

# PART 6 — THE TOKENIZER, IN FULL DETAIL

**File:** `supplied_files/src/data_pipeline/utility_lib/tokenizer.py` (~1,100 lines)

This is the most important component in the system. It defines what the model can and cannot perceive. Everything downstream is constrained by it.

## 6.1 Configuration-driven design

The tokenizer is not hard-coded. It is driven by a JSON configuration listing every field and how to handle it:

```json
{
  "transaction_amt": {
    "handler_type": "bin_ranges",
    "token_prefix": "TRANSACTION",
    "ranges": [0, 10, 25, 50, 100, 250, 500, 1000, 5000]
  },
  "merchant_category_cd": {
    "handler_type": "category",
    "token_prefix": "MERCHANT_CATEGORY",
    "categories": ["5411", "5412", "7995", ...]
  }
}
```

This matters enormously in a regulated environment: **the tokenizer configuration is the model's feature specification, versioned as a file.** The project record references `tokenizer_config_v22.json`, `tokenizer_config_v1.json`, `exp22/vocab_to_id.json`, and so on. Changing a feature means a new config version, a new vocabulary, and a new model. That is auditable in a way that scattered preprocessing code is not.

## 6.2 Every handler type

The `handler_type` field determines how a raw value becomes tokens. Thirteen handlers exist.

### `category` — for low-cardinality discrete fields

Matches the value against an explicit list. Anything not on the list becomes `_OTHER`.

```python
v = str(value).strip()
if v in categories:
    tokens.append(f"{prefix}_{v}")
else:
    tokens.append(f"{prefix}_OTHER")
```

Vocabulary cost: `len(categories) + 1`. The `_OTHER` bucket is essential — it guarantees the tokenizer never fails on an unseen value, and it means the model has a representation for "unusual value" which is itself informative.

### `hash_bin` — for high-cardinality fields

You cannot enumerate every postal code or IP address. So hash the value into a fixed number of buckets:

```python
digest = hashlib.md5(str(value).encode('utf-8')).digest()
hash_int = int.from_bytes(digest, 'big')
return hash_int % num_buckets
```

MD5 is used purely as a **deterministic scattering function**, not for security. The same input always maps to the same bucket, across machines and across runs — which is exactly what you need for reproducibility.

The trade-off is **hash collisions**: unrelated values sharing a bucket. With 100 buckets and 10,000 postal codes, about 100 codes share each bucket. The model cannot distinguish them. This is an accepted, deliberate loss of resolution in exchange for a bounded vocabulary.

A performance detail worth noting: the comment explains `int.from_bytes(digest, 'big')` *"equals `int(hexdigest(), 16)` but avoids building/parsing the 32-char hex string."* When you hash 20 fields across billions of transactions, that matters.

### `float` — logarithmic symmetric binning

For signed amounts spanning many orders of magnitude:

```python
def _bin_symmetric_amount(self, amount, num_bins):
    if amount == 0:
        return num_bins // 2
    sign = 1 if amount > 0 else -1
    log_val = np.log10(abs(amount) + 1)
    max_log = 6
    bin_idx = int((log_val / max_log) * (num_bins // 2))
    bin_idx = min(bin_idx, num_bins // 2 - 1)
    return num_bins // 2 + bin_idx if sign > 0 else num_bins // 2 - 1 - bin_idx
```

Zero sits in the middle. Positives go up, negatives go down. The **logarithm** is the key idea: the difference between £10 and £20 is behaviourally significant; the difference between £10,000 and £10,010 is not. Log scaling gives fine resolution at small values and coarse resolution at large ones, which matches how spending actually varies. `max_log = 6` caps the range at £1,000,000.

### `bin_ranges` — explicit threshold binning

You supply the boundaries; the value is placed between them:

```python
def _bin_into_ranges(self, value, ranges):
    return bisect_right(ranges, value)
```

`bisect_right` is a binary search — O(log n) instead of O(n). The comment notes this replaced a linear scan and that *"NaN values compare False against every threshold and fall through to len(ranges), matching the original linear-scan behavior"* — a careful note that the optimisation preserved the exact previous behaviour including the edge case. That kind of comment is a good sign about the engineering discipline.

### `temporal` — the timestamp handler

Special, because it does two jobs.

**Job 1:** emit calendar tokens.
```python
timestamp = self._to_timestamp(value)
if feature_config.get('add_hour_of_day', False):
    tokens.append(f"HOD_{timestamp.hour:02d}")
if feature_config.get('add_day_of_week', False):
    tokens.append(f"DOW_{timestamp.weekday()}")
```

**Job 2:** supply the timestamp that drives the delta-time calculation for the *next* transaction. The temporal field is deliberately processed first in `_tokenize_transaction`.

### `days_since` — elapsed-time features

For fields stored as "days since 1990-01-01". Computes the gap to the transaction date and bins it. Special case: value 0 emits a distinct `_NO_CHANGE` token rather than a numeric bin — an event that never happened is qualitatively different from one that happened a long time ago.

### `days_since_status_dt` — and the leakage story

This handler exists for fields like **account inactivation date** (`INACTV_DT`). It computes `status_date − transaction_date` and bins it.

Look carefully at the source:

```python
diff = (feat_ts - txn_ts).days
# if diff >= 0:
#     if self.fill_missing:
#         tokens.append(f"{prefix}_MISSING")
# else:
ranges = feature_config.get('ranges', [])
bin_idx = self._bin_into_ranges(diff, ranges)
tokens.append(f"{prefix}_RANGE_{bin_idx}")
```

**Those commented-out lines are a disabled leakage guard.** The docstring at the top of the class states the intended behaviour explicitly:

> *"days_since_status_dt: Bin raw date/datetime values against transaction_dttm. Positive or same-day diffs are treated as missing to avoid future-status leakage."*

The code no longer does that. A positive `diff` means the status date is **in the future relative to the transaction** — the account was closed *after* this transaction. That is information from the future. If cards are frequently closed shortly after fraud is discovered, then a "status date is 3 days in the future" token is close to a direct fraud label.

This is not a speculative concern. The project record names it (COM-013, 08 Sep 2026):

> *"Developer described v22b as older BMG data containing fraud proxies including status date, which should not be used in current form because of potential leakage from card inactive date."*

And the downstream code contains a **compensating correction** in `generate_fraud_data.py`:

```python
# Leakage correction (gen-frd only): the "leakage version" INACTV_DT feature
# binned diff = status_date - transaction_date >= 0 (account already inactive
# at txn time) into positive-value RANGE tokens. Swap those back to the
# MISSING token across the WHOLE sequence to match the corrected handler.
if inactv_positive_ids and inactv_missing_id is not None:
    token_ids = [inactv_missing_id if t in inactv_positive_ids else t for t in token_ids]
```

So the leakage is real, it was identified, and there is a post-hoc patch that rewrites the offending tokens *after* tokenization — but it only runs during `gen-frd` and only when explicitly configured. This is the most important single risk in the codebase and it is revisited in Part 14.

### `category_group` — grouped categories

Maps many raw values into fewer named groups (e.g. dozens of merchant codes → "TRAVEL"). Builds a reverse lookup once and caches it. Reduces vocabulary and helps generalisation for rare values.

### `ip_address` — structured network handling

```python
ip_norm = self._normalize_ip(value)
if ip_norm == "NNNNN":       tokens.append(f"{prefix}_OTHER")
elif ":" in ip_norm:          tokens.append(f"{prefix}_IPV6")
else:
    first2 = self._ipv4_first2_octets(ip_norm)
    tokens.append(f"{prefix}_IPV4_{first2}" if first2 in top_ipv4_first2 else f"{prefix}_IPV4_OTHER")
```

Uses the **first two octets** (e.g. `192.168`) rather than the full address. Those identify the network block — roughly the ISP or region — which is stable and meaningful, whereas a full IP is nearly unique and therefore useless as a learnable feature. Only the most common blocks get their own token; the rest fall into `_IPV4_OTHER`. IPv6 gets a single catch-all token.

### `zip_geohash_handle` — geographic encoding

Maps `(postal_code, country_code)` to a **geohash** via a lookup table. A geohash is a short string encoding a geographic cell, with the property that **nearby places share prefixes**. That gives the model a genuine notion of geographic proximity that raw postal codes cannot provide. The handler supports precomputed geohash columns to avoid the lookup at tokenization time, and special-cases US ZIP+4 (country code `840`) by truncating to 5 digits.

### `exp_mantissa` — scientific-notation amount encoding

An alternative amount representation that emits **two** tokens: an exponent (order of magnitude) and a mantissa (the leading digits).

```python
e = int(math.floor(math.log10(amt)))
e_clip = max(-1, min(5, e))
mantissa = amt / (10 ** e_clip)
mantissa = max(1.0, min(9.999, mantissa))
b = int((mantissa - 1.0) / (9.0 / M))
```

£47.82 → exponent 1, mantissa ≈ 4.78. This gives much finer amount resolution than single-token binning, at the cost of one extra token per transaction. Special values are handled: below `eps` → `_EXP_NZERO`, infinite/NaN → a designated bucket.

### `placeholder` — reserved vocabulary slots

Emits **no tokens at all**. It reserves IDs in the vocabulary for fields that do not exist yet.

This is a genuinely shrewd piece of forward planning. Because `vocab_size` must match between the pretrained model and the fine-tuning tokenizer (`FraudFinetuneTrainer.__init__` raises a `ValueError` if they differ), you cannot add a new feature after pretraining without invalidating a very expensive pretrained model. Placeholders reserve space in advance. The fine-tuning tokenizer can then give those reserved IDs real meaning, and the embedding matrix still lines up. The fine-tuning guide's validation error message confirms this is the intended workflow:

> *"The finetuning tokenizer may redefine token meanings but must have the same vocab_size as the pretrained model."*

This directly answers the review question raised in the Confluence record (31 Aug 2026): *"Investigate in detail how the model adapts to new features not in pretraining, like how the token is created."* The answer is: placeholder slots.

## 6.3 Building the vocabulary

`_build_vocabulary()` assigns IDs in a strictly deterministic order:

1. **Special tokens** — `<BOS>`=0, `<EOS>`=1, `<PAD>`=2, `<UNK>`=3, `<GAP>`=4, optionally `<MASK>`=5
2. **Delta-time tokens** — `Δt_PAD`, then `Δt_BIN_00` … `Δt_BIN_NN`
3. **Per-feature tokens** — in config order, each handler contributing its token set
4. **Fraud tag tokens** — if `fraud_flag=True`, `frd_tag_0` and `frd_tag_1` appended at the end

Determinism is essential: the same config must produce the same vocabulary on every machine, or a pretrained model's embeddings would point at the wrong tokens.

There is a genuine oddity in the fraud-tag assignment:

```python
self.vocab[self.config.non_frd_token] = vid + 1
self.vocab[self.config.frd_token] = vid + 2
```

It skips `vid` and starts at `vid + 1`, leaving an unused gap. Downstream code compensates by computing the IDs the same way (`frd_tag_0_id = vocab_size - 1`, `frd_tag_1_id = vocab_size`). It is consistent, so it works, but it is a fragile convention — an off-by-one waiting to be tripped over by anyone who "fixes" it.

## 6.4 Tokenizing one transaction

`_tokenize_transaction()` produces the field sequence:

```
1. Delta-time token first      → Δt_BIN_XX, or Δt_PAD if no previous transaction
2. Every configured feature    → in config order
3. Fraud tag (optional)        → frd_tag_0 / frd_tag_1
```

The delta-time token comes first and is computed from the *previous* transaction's timestamp:

```python
def _bin_delta_time(self, prev_ts, curr_ts):
    delta_minutes = (curr_ts - prev_ts).total_seconds() / 60
    for i, threshold in enumerate(self.config.delta_time_bins[:-1]):
        if delta_minutes < self.config.delta_time_bins[i + 1]:
            return f"Δt_BIN_{i:02d}"
    return f"Δt_BIN_{len(self.config.delta_time_bins)-2:02d}"
```

Default bins: `[0, 1, 5, 15, 60, 240, 1440, 10080]` minutes — under a minute, 1–5 min, 5–15 min, 15–60 min, 1–4 hours, 4–24 hours, 1–7 days, over a week. Logarithmically spaced, because rapid-fire transactions are a classic fraud signature ("card testing") and deserve fine resolution, while the difference between 30 days and 31 days is irrelevant.

### The `fill_missing` behaviour

Two modes, and the difference is significant:

```python
if self.fill_missing:
    for field_name, feature_config in self.config.features.items():
        value = txn.get(field_name, None)
        if self._is_missing(value):
            tokens.append(f"{prefix}_MISSING")
        else:
            tokens.extend(self._handle_feature(...))
else:
    for field_name, feature_config in self.config.features.items():
        if field_name in txn:
            tokens.extend(self._handle_feature(...))
```

- **`fill_missing=True`**: **every transaction produces the same number of tokens, in the same order.** Missing values get explicit `_MISSING` tokens
- **`fill_missing=False`**: missing fields are silently skipped, so transactions have variable token counts

`fill_missing=True` is strictly better and is what the v22 pipeline configs use (`fill_missing: true`). It is what makes the **field-type embedding** work at all — `build_field_type_ids` assumes a fixed schema where offset equals column index. With variable-length transactions that assumption collapses and field IDs become meaningless. The two features are coupled, and anyone changing one must consider the other.

## 6.5 Building a sequence

```python
def tokenize_sequence(self, transactions, max_length=None):
    all_tokens = [self.config.bos_token]
    for idx, txn in enumerate(transactions):
        txn_tokens, current_timestamp = self._tokenize_transaction(txn, prev_timestamp)
        all_tokens.extend(txn_tokens)
        prev_timestamp = current_timestamp
        if idx < len(transactions) - 1:
            all_tokens.append(self.config.gap_token)
    all_tokens.append(self.config.eos_token)
    ...
    token_ids = [self.vocab.get(token, unk_id) for token in all_tokens]
```

Structure: `<BOS> txn₁ <GAP> txn₂ <GAP> ... txnₙ <EOS>`. `<GAP>` goes *between* transactions, not after the last one. Any token not in the vocabulary falls back to `<UNK>` — the tokenizer never crashes on unexpected input.

## 6.6 `tokenize_and_join` — building historical context

This method handles a specific and important scenario: you have a *current* transaction and a *pre-tokenized history* for that account, and you want to combine them without re-tokenizing everything.

The critical piece is the **time cutoff**:

```python
curr_ts = self._to_timestamp(curr_transaction['transaction_dttm'])
cutoff_ts = curr_ts - pd.Timedelta(days=days_offset)

insert_idx = None
for i in range(len(timestamps) - 1, -1, -1):
    if timestamps[i] is not None and timestamps[i] <= cutoff_ts:
        insert_idx = i
        break
```

It scans backwards for the most recent history transaction at least `days_offset` (default 90) days before the current one, and **discards everything after it.**

Why deliberately throw away the most recent history? **Label maturity.** Transactions from the last 90 days may not yet have confirmed fraud labels. Including them would mean using labels that would not exist at real scoring time. The 90-day gap is a conservative guarantee that historical labels have matured.

This is a well-reasoned design, and it is the direct engineering answer to the concern raised in the project record on 30 Jul 2026:

> *"Data leakage issue exists since a target transaction cannot see a finalized fraud label at the un-maturated time point. We need a better design of how to input the fraud label."*

It is also why an alternative mechanism exists — `apply_label_delay` in `generate_fraud_data.py`, which *probabilistically flips* historical fraud labels back to non-fraud based on how recently they occurred, simulating the reporting delay rather than eliminating the window entirely (Part 7.6).

## 6.7 Save and load

```python
def save(self, filepath):
    json.dump(self.vocab, open(path / "vocab.json", 'w'), indent=2)
    config_dict = { ..., 'fill_missing': self.fill_missing, 'add_mask_token': self.add_mask_token }
    json.dump(config_dict, open(path / "config.json", 'w'), indent=2)
```

Two files: `vocab.json` (token → ID) and `config.json` (feature definitions and flags). Both must travel with the model checkpoint. A model and a mismatched tokenizer produce silent garbage — the IDs would map to different meanings.

The loader is notably strict:

```python
if 'fill_missing' not in config_dict:
    raise KeyError("\"fill_missing\" not found in config.json. "
                   "Please re-save the tokenizer with the current version.")
```

Refusing to guess at a missing flag rather than defaulting it is the right call — a wrong default here would silently change tokenization.

---
---

# PART 7 — THE DATA PIPELINE

**Directory:** `supplied_files/src/data_pipeline/`

This is the largest part of the repository by file count, and it does the unglamorous work: turning raw monthly bank parquet files into model-ready tokenized data at a scale of billions of transactions.

## 7.1 The five stages

| Step | Mode | Input | Output |
|---|---|---|---|
| 1 | `acc-trans` | Raw monthly parquet shards | Per-account transaction dictionaries |
| 2 | `gen-token` | acc-trans output | Tokenized parquets (token IDs per account) |
| 3 | `gen-frd` | gen-token output + vocab | **Supervised fraud fine-tuning data** |
| 4 | `frd-join-past` | acc-trans (current month) + gen-token (prior month) | Fine-tuning data with longer history |
| 5 | `gen-seq` | gen-token output + vocab | **Flat sequences for pretraining** |

Two branches diverge after step 2: **`gen-seq` feeds pretraining**, **`gen-frd` feeds fine-tuning**. They are different shapes of data for different training objectives.

## 7.2 Why "parquet"

**Parquet** is a columnar file format. Row-based formats (CSV) store record-by-record; columnar formats store column-by-column. Three advantages that matter here:

- **Selective reading** — you can read only the columns you need without touching the rest of the file
- **Better compression** — values in a column are similar, so they compress far better (the configs specify `compression: snappy`)
- **Typed schema** — data types are stored in the file, so no parsing ambiguity

Standard for large-scale analytics, and used throughout this pipeline.

## 7.3 Stage 1 — `acc-trans`

Raw transaction data arrives as monthly shards partitioned arbitrarily. The model needs data grouped **by account, ordered by time**. This stage performs that regrouping.

From `supplied_files/src/data_pipeline/tokenizer_lib.py`:

```python
def build_account_transactions(pandas_df, selected_cols, l_fix_in_df, l_fix1_in_df, type_dict, config_dict=None):
def extract_account_transaction(pandas_df, selected_cols, ..., out_name, ...):
```

Output: a dictionary `{account_id: [transaction_dict, transaction_dict, ...]}`, written as either a pickle file or — in the newer "tabular" path — a parquet. The codebase contains an explicit migration away from pickles (`README-TABULAR-PKL-REMOVAL-E2E.md`, `pkl_to_tabular.py`, `pkl_s3_to_tabular.py`, `combine_pkl_par.py`). Pickles are Python-specific, not compressible column-wise, and a security concern since unpickling executes code. Moving to tabular parquet is a clear improvement.

**Account partitioning.** The project record (COM-003, COM-008) states the data is *"partitioned by account into 10,000 buckets"* with *"at most 5,000 files used for training and 2,000 for testing"*, and confirms that an account appears in only one parquet. That property is essential: it guarantees no account's transactions are split across the train/test boundary, which would leak information.

## 7.4 Stage 2 — `gen-token`

Applies the tokenizer to every account's transaction list.

```python
def generate_tokenizer(trans_path, out_name, config_dict, fraud_flag=False,
                       timestamps_store=False, vocab_dict=None, fill_missing=False):
```

Output parquet columns include `account_id`, `token_ids` (the full tokenized history), `amounts`, and — when `timestamps_store=True` — `timestamps` (needed later for label-delay simulation).

The `vocab_dict` parameter allows passing a **fixed, externally-supplied vocabulary** rather than rebuilding it. This is how vocabulary consistency is maintained across months of data and across pipeline runs: the vocabulary is built once, saved as `vocab_to_id.json`, and reused everywhere. The YAML configs reference e.g. `.../vocab_files/exp22/vocab_to_id.json`.

`fraud_flag=True` appends `frd_tag_0` / `frd_tag_1` tokens to each transaction. Note carefully: those tokens are *in the token sequence at this stage*. Stage 5 strips them for pretraining; stage 3 uses them to derive labels and then strips or remaps them.

## 7.5 Stage 5 — `gen-seq` (pretraining data)

**File:** `supplied_files/src/data_pipeline/utility_lib/tokens_to_seqs.py`

Takes long per-account token sequences and repacks them into fixed-maximum-length sequences suitable for pretraining.

**Step 1 — strip the labels.**
```python
tokens = [t for t in tokens if t not in fraud_tags]
```
Pretraining is self-supervised and must never see fraud labels. This is a hard, non-negotiable boundary and the code enforces it by filtering the tag token IDs out entirely.

**Step 2 — split into transactions** on `<GAP>` boundaries.

**Step 3 — pack into sequences.**
```python
while idx < n:
    seq = [start_token]
    while idx < n:
        tx = transactions[idx]
        prospective_len = len(seq) + len(tx) + 1
        if prospective_len <= max_len and (max_trans is None or trans_count + 1 <= max_trans):
            seq.extend(tx if len(seq) > 1 else tx[1:])
            ...
        else:
            break
    seq.append(end_token)
    sequences.append(seq)
    if idx < n:
        idx = added_indices[-1]   # ← overlap by one transaction
```

Two things to notice:

- **Transactions are never split.** A sequence ends at a transaction boundary. A half-transaction would be meaningless input
- **Consecutive sequences overlap by one transaction** (`idx = added_indices[-1]`). This ensures the model always has at least some context for the first prediction in each sequence, rather than a cold start. A small detail with a real effect on training signal quality

Output: a flat list of sequences, each `<BOS> ... <EOS>`, each at most `max_len` (2048 in the v22 config) tokens, written to parquet with a `sequence` column.

## 7.6 Stage 3 — `gen-frd` (fine-tuning data)

**File:** `supplied_files/src/data_pipeline/utility_lib/generate_fraud_data.py`, function `create_fraud_data`

This is the most consequential and most subtle stage in the pipeline. Its job is to convert "an account's full tokenized history" into **individual labelled training examples**, where each example is: *a target transaction plus the history that preceded it, labelled fraud or not-fraud.*

### The construction

For each account:
1. Locate every transaction that carries a `frd_tag_1` (fraud) or `frd_tag_0` (non-fraud) token
2. Each becomes a candidate **target transaction**
3. Walk back up to `window` transactions to build the history
4. Strip or remap the fraud tag tokens from the history
5. Emit: `[account_id, token_ids, frd_tag, seq_len, amount, truncated, labels_history]`

### The knobs that shape the training distribution

**`downsample` (function default 100, but ⚠ see below)** — keep only 1 in `downsample` non-fraud transactions; keep **all** fraud. Downsampling is the reason calibrated FPR exists: it distorts every rate-based metric relative to production.

⚠ **Do not assume 100 was used.** `100` is the *function* default, but **every `gen-frd` config under `yaml_configs/end_2_end/` and `yaml_configs/pkl_restructing/` sets `downsample: 1`** — keep all non-fraud. The `100`s appear only in `other_testing/` and one scenario fixture. The v22 end-to-end config specifically sets `1`. The developer's own v22b config is not in the supplied package, so the training prevalence is **unresolved** and must be established before interpreting any calibration or `calibrated_fpr` figure. Without this the model would see thousands of legitimate transactions for every fraud and learn almost nothing. But it also means **every rate-based metric computed on this data is distorted** relative to production, which is exactly what `calibrated_fpr` corrects.

**`window` (default 18)** — maximum transactions per example, including the target. The project record (COM-005) states the best-performing v22b variant used the **last 17 transactions**, which is consistent with a window of 18 (17 history + 1 target). Note that `window` (the data-build parameter, set to 18 in the v22 config) and `window_size` (a `FraudEvalConfig` field that re-trims *already-built* sequences at load time) are different parameters — `window_size=None` is the **correct** setting for parquets built with `window: 18`, not a contradiction.

**`excl_past_frd` (default 1.0)** — probability of truncating the history at the most recent *previous* fraud. At 1.0 it always truncates. Rationale: once fraud has occurred on an account, everything after it is contaminated — the card may have been blocked, reissued, or behaviourally disrupted. Cutting at the previous fraud keeps the history clean.

**`apply_label_delay` + `label_delay_strategy`** — the label-maturity simulator. Historical fraud tags are *probabilistically flipped back to non-fraud* based on how recently the historical transaction occurred:

```python
def _get_delay_flip_prob(gap_days): ...         # 'step'  — flat per 30-day bucket
def _get_delay_flip_prob_linear(gap_days): ...  # 'linear' — smooth interpolation
```

The docstring gives the linear anchors: *"day 0 → 50% flip, day 30 → 18.48% flip, ..., day 180 → 0.91% flip"*. Read that as: a fraud that occurred *today* has only a 50% chance of already being reported, so half the time the model should see it as "not yet known to be fraud". A fraud from 180 days ago is almost certainly reported, so it is flipped less than 1% of the time.

**Non-fraud tags are never flipped** — because a transaction not currently labelled fraud might still become fraud later, but one already labelled fraud will not become non-fraud.

This is a thoughtful, honest attempt to make training-time information match scoring-time information. It is a much better answer than ignoring the problem. It is still an *approximation*, based on assumed reporting-delay curves.

**`placeholder_nonfrd` / `placeholder_frd`** — instead of stripping historical fraud tags, remap them to reserved placeholder token IDs. This lets the model *know* a historical transaction was flagged, without reusing a token the pretrained model associates with a different meaning.

### The indicator-token handling

```python
predecline_pos_id = vocab.get('PREDECLINE_INDICATOR_1')
segment_other_id = vocab.get('SEGMENT_13. All Other')
falcon_missing_id = vocab.get('FALCONDECLINE_INDICATOR_MISSING')
falcon_actual_ids = {tid for name, tid in vocab.items() if name.startswith('FALCONDECLINE_INDICATOR_RANGE')}
```

These reference upstream fraud systems. **Falcon** is a widely-used commercial fraud-scoring product; `PREDECLINE` indicates a transaction already declined by another control. The pipeline includes `exclude_predecline.py` as a dedicated script, and the controlled run in the project record uses a data package named `tfm_v22b_dropcpr_falcondecline` — "drop CPR, [drop] falcon decline".

The reasoning is sound: if a transaction was already declined by Falcon, including that fact is circular — you are using a fraud model's output as an input to a fraud model, and at scoring time in production you may not have it. Masking these to `_MISSING` removes the circularity.

## 7.7 Stage 4 — `frd-join-past`

**Function:** `generate_tokenizer_and_join` in `tokenizer_lib.py`

A variant that pulls history from the *previous month's* tokenized output, enabling much deeper history than a single month provides. It uses `tokenize_and_join` with its 90-day cutoff (Part 6.6). Also supports `downsample` and `excl_past_frd` with the same semantics.

## 7.8 Validation infrastructure

The `validation_check/` directory is a strong signal about how this project was run:

| Script | Purpose |
|---|---|
| `validate_pkl_restructuring_step.py` | Verify the pickle→tabular migration preserved data exactly |
| `validate_tabular_token_ids.py` | Confirm token IDs are correct after conversion |
| `validate_days_since_handlers_e2e.py` | End-to-end check of the days-since handlers — the leakage-sensitive ones |
| `compare_combined_vs_intermediate_outputs.py` | Verify a combined pipeline run matches step-by-step runs |
| `inspect_raw_parquet_schema.py` | Inspect input schemas |
| `inspect_pkl_checkpoint_features.py` | Inspect features in intermediate checkpoints |
| `inspect_pkl_part_sizes.py` | Check partition sizes |
| `scan_tokenizer_config_handlers.py` | Audit which handlers a config uses |

Building dedicated validators for a data pipeline — particularly one that specifically validates the leakage-prone handlers end to end — is the behaviour of a team operating under model-risk-management scrutiny. Which, given the repository is named `MRM_1` and the project record is full of validation language, is exactly what is happening.

## 7.9 The YAML configuration system

Pipeline runs are specified declaratively:

```yaml
run1:
  mode: acc-trans
  input_path: "s3://.../trans_0525_0725_byacct/"
  output_path: "s3://.../end-2-end-days-since-status-dt-v22/"
  month: "052025"
  range: "8000-8019"
  executors: 20
  config-file: "s3://.../tokenizer_config_v22.json"
  transaction_output_format: tabular

run2:
  mode: gen-token
  vocab_file: "s3://.../vocab_files/exp22/vocab_to_id.json"
  fraud_flag: true
  timestamps_store: true
  fill_missing: true
...
```

Key fields: `range` selects a subset of the 10,000 account partitions (allowing restart from a failure — `9.2` in the pipeline README covers exactly this); `executors` controls Spark parallelism; `config-file` and `vocab_file` pin the tokenizer version.

The configs are organised by purpose: `end_2_end/` (full runs), `pkl_restructing/` (the migration), `spark_scenario_test/` (per-stage tests), `optimize/` (performance experiments), `other_testing/`, `raw_extended/`. The naming carries real history — `end_to_end_acc_trans_gen_token_gen_seq_gen_frd_s3_days_since_status_dt_v22.yml` tells you exactly which stages, which storage, which feature, which version.

---
---

# PART 8 — THE MODEL CODE

**Directory:** `supplied_files/src/modelling/`

## 8.1 `model.py` — `ModelConfig` and `PaymentFoundationModel`

### `ModelConfig`

A dataclass holding every architectural decision. It is the single source of truth — the same `ModelConfig` is used for pretraining, fine-tuning, and evaluation, and it is serialised to `config.json` alongside every checkpoint.

**Size parameters:**

| Field | Default | Meaning |
|---|---|---|
| `vocab_size` | 300,000 | Number of distinct tokens |
| `d_model` | 2,048 | Width — numbers per position |
| `n_layers` | 16 | Depth — transformer blocks |
| `n_heads` | 32 | Attention heads (64 dims each) |
| `d_ff` | 8,192 | Feed-forward width (4× `d_model`, the standard ratio) |
| `max_seq_len` | 2,048 | Longest input |

Rough parameter count: embeddings ≈ 614M (300k × 2048); each layer ≈ 4×2048² (attention) + 3×2048×5461 (SwiGLU) ≈ 50M; sixteen layers ≈ 800M. Total on the order of **1.4 billion**, or ~800M excluding the tied embedding — consistent with the `1B` in the default checkpoint path.

**Regularisation:** `dropout: 0.2`, `attention_dropout: 0.1`, `residual_dropout: 0.0`.

**Normalisation:** `norm_type: "rmsnorm"`, `norm_position: "pre"`, `layer_norm_eps: 1e-5`.

**Position:** `use_rope`, `rope_theta`, `rope_scaling_factor`, `rope_type`, plus the bespoke `use_shared_position_ids`, `use_field_type_embedding`, `max_fields: 128`, `gap_token_id: 4`.

**Optional heads:** `enable_amount_head`, `enable_time_head`, `enable_classification_head`, `enable_amount_ordinal_head`, `txn_num_bins: 20`.

**Fine-tuning:** `skip_lm_head`, `freeze_base`.

**Serialisation:** `from_json` / `to_json`. And in `load_from_dir`, a forward-compatibility guard:

```python
valid_keys = set(ModelConfig.__dataclass_fields__.keys())
filtered = {k: v for k, v in raw_config.items() if k in valid_keys}
```

Unknown keys in an old checkpoint's config are dropped rather than causing a crash. Necessary when checkpoints outlive code versions — which they always do.

### `PaymentFoundationModel.forward`

The full path:

```python
x = self.token_embedding(input_ids, scale_embeddings=self.config.scale_embeddings)

if position_ids is None and self.config.use_shared_position_ids:
    position_ids = build_shared_position_ids(input_ids, self.config.gap_token_id)

if self.field_type_embedding is not None:
    field_ids = build_field_type_ids(input_ids, self.config.gap_token_id, self.config.max_fields)
    x = x + self.field_type_embedding(field_ids)

if self.pos_embedding is not None:
    x = self.pos_embedding(x, position_ids)

# build mask (hybrid or causal, combined with padding)
# run 16 transformer layers
# final norm

outputs = {'hidden_states': x}
if not skip_lm_head:
    outputs['logits'] = self.lm_head(x)
    ...
```

### `skip_lm_head` — a real optimisation

The LM head is a `[batch, seq_len, 2048] × [2048, 300000]` matrix multiply. For batch 32 and length 2048 that is ~40 billion multiply-accumulate operations *per forward pass*, and it produces a tensor of 20 billion elements' worth of logits.

During fine-tuning, none of that is used — the classifier consumes `hidden_states` only. So:

```python
self.model(..., skip_lm_head=True)
```

skips it entirely. This is probably the single largest speed win in the fine-tuning path.

### Freezing

```python
def _freeze_base_params(self):
    for param in self.parameters():
        param.requires_grad = False
    for attr in ["amount_head", "time_head", "classification_head", "amount_ordinal_head"]:
        head = getattr(self, attr, None)
        if head is not None:
            for param in head.parameters():
                param.requires_grad = True
```

`requires_grad = False` tells PyTorch not to compute or store gradients for those parameters — they stay fixed. Useful when labelled data is scarce, since only the small head is trained and there is far less to overfit. Controlled by `freeze_base`.

## 8.2 `embedding.py`

- **`TokenEmbedding`** — the `nn.Embedding` lookup table with optional `√d` scaling
- **`SinusoidalPositionalEmbedding`** — fixed sine/cosine position pattern, registered as a `buffer` (saved with the model but not trained)
- **`LearnedPositionalEmbedding`** — learnable alternative, defined but not used by default
- **`EmbeddingConfig`** — the configuration dataclass. It carries several fields (`hour_embedding_size`, `day_of_week_embedding_size`, `use_transaction_time_embedding`) that are **not consumed** by any of the three classes — evidence of an earlier design where time was embedded separately rather than tokenized. Harmless, but it is dead configuration

## 8.3 `attention.py`

- **`AttentionConfig`** — attention hyperparameters
- **`MultiHeadAttention`** — the standard path, using FlashAttention via `F.scaled_dot_product_attention`, with KV-cache support for generation
- **`DeltaTemporalBias`** — learnable bias indexed by the difference in delta-time bins between positions
- **`DeltaTemporalAttention`** — subclass that adds the bias; must compute attention manually since the bias goes in before softmax
- **`create_attention_layer`** — factory

**KV caching** deserves a note. When generating tokens one at a time, positions 1..n−1 are recomputed identically at every step. Caching their keys and values turns an O(n²) generation loop into O(n). Used by `pretrain_eval.py` for the generation samples.

The mask builder handles the type conversion carefully:

```python
add_mask = torch.where(attention_mask == 0, torch.finfo(q.dtype).min, torch.zeros(...))
```

`torch.finfo(q.dtype).min` is the most negative representable number for the current precision. Using `-inf` directly can produce `NaN` in mixed precision when an entire row is masked; this avoids that.

## 8.4 `transformer.py`

- **`RMSNorm`** / **`LayerNorm`** / **`create_norm`** factory
- **`TransformerConfig`**
- **`TransformerBlock`** — the standard block described in Part 4.7
- **`HybridTransformerBlock`** — runs standard *and* delta-temporal attention, blending via `F.softmax(self.attention_weights)` over a learnable `[0.7, 0.3]` parameter. Available but not used by the default model

One genuine bug worth flagging: in `TransformerConfig`,

```python
use_checkpoint = True
```

is written **without a type annotation**. In a Python dataclass, a field without an annotation is a **plain class attribute, not a dataclass field**. So it is never populated from `ModelConfig`, and `get_transformer_config()` — which filters on `TransformerConfig.__annotations__` — will never pass it through. The effect: `ModelConfig.use_checkpoint = False` is silently ignored and gradient checkpointing is **always on** in the feed-forward layers. Gradient checkpointing trades compute for memory (it recomputes activations during the backward pass instead of storing them), so the consequence is slower training than intended rather than incorrect results. Still a real defect. See Part 14.

## 8.5 `feed_forward.py`

`FeedForward` with the four activations, the SwiGLU 2/3 dimension adjustment, and optional gradient checkpointing via `torch.utils.checkpoint`.

## 8.6 `rope.py`

`RotaryPositionalEmbedding` with:
- Precomputed frequency table
- Cached cos/sin tables that grow on demand (`_ensure_cache`)
- **Interleaved** rotation layout (`_rotate_half` operating on adjacent pairs, `repeat_interleave(2)`), as opposed to the "split-half" layout used in some implementations. These are **not interchangeable** — a checkpoint trained with one layout will produce nonsense with the other. Worth knowing if weights are ever ported
- Automatic layout detection between `[batch, heads, seq, dim]` and `[batch, seq, heads, dim]`

## 8.7 `dcn.py` — Deep & Cross Network v2

Implements the cross network from Wang et al., *"DCN V2"*, 2021:

```python
cross = x0 * (self.W[i](x) + self.b[i])
x = cross + x
x = self.norm[i](x); x = self.dropout[i](x)
```

The key is `x0 *` — **the original input multiplied in at every layer**. Element-wise multiplication of features is what creates an explicit **feature interaction**. After `L` layers you have interactions up to order `L+1`, with parameter count only linear in the feature dimension.

Why this matters for fraud: fraud signals are conjunctive. Not "foreign country" and not "high amount" but "foreign country **AND** high amount **AND** card-not-present **AND** unusual hour". A plain MLP can approximate such interactions but must learn them from scratch; DCNv2 builds them in structurally. This is why `dcnv2` is the **default** `pool_strategy`.

## 8.8 `coral_ordinal.py` and `corn_loss.py` — ordinal regression

The problem: amount bins are **ordered**. Predicting bin 11 when the truth is bin 12 is a near-miss; predicting bin 2 is a disaster. Plain cross-entropy treats both as equally wrong. Ordinal methods fix this.

**CORAL** (`CORALOrdinalHead`) predicts, for each threshold `k`, the probability `P(y > k)`:

```python
inc = F.softplus(self.delta)           # guaranteed > 0
c = self.c0 + torch.cumsum(inc, dim=0) # strictly increasing cutpoints
logits = c - s                          # s = a single learned score per token
```

One scalar score per token, compared against a set of **strictly increasing cutpoints**. The `softplus` + `cumsum` construction makes monotonicity *structurally impossible to violate* — the model cannot output the inconsistent prediction `P(y>3) > P(y>2)`. That is a strong guarantee obtained by construction rather than by penalty.

There is also a clever initialisation:

```python
def init_cutpoints_from_marginals(self, p_gt):
    cp_target = torch.logit(p)
    ...
    self.delta.copy_(torch.log(torch.expm1(increments)))   # inverse softplus
```

Start the cutpoints where the empirical distribution of amounts says they should be, so training begins from a sensible staircase rather than from nothing. The model initialises this from uniform quantiles by default.

**CORN** (`corn_loss.py`) is a related conditional formulation, with masked BCE across the `K−1` binary tasks, optional label smoothing, and `pos_weight` support. `corn_predict_class` recovers the bin by counting how many thresholds were exceeded.

## 8.9 `binary_focal_loss.py`

```
FL(p_t) = -α(1 − p_t)^γ · log(p_t)
```

Two mechanisms:
- **α (0.25)** — class balancing. Weight positives and negatives differently
- **γ (2.0)** — the focusing term. If an example is already classified with 99% confidence, `(1 − 0.99)² = 0.0001` — its contribution to the loss nearly vanishes. Training effort automatically concentrates on hard examples

Without this, in a dataset that is 99.84% negative, the loss is dominated by millions of trivially-correct negatives and the rare positives are drowned out. Focal loss was invented for dense object detection (Lin et al., ICCV 2017), where the imbalance problem is structurally identical.

## 8.10 `fraud_cls_model.py` — the fraud classifier

The largest modelling file. Three components.

### `TransactionFeatureExtractor`

Takes per-transaction vectors `[B, K, D]` (K transactions, D dimensions) and produces a rich feature vector. Its output dimension is `(6 + len(num_windows)) * d_model` — with the default three windows, that is **9 × 2048 = 18,432 features**.

The six base features plus windows:

**(a) Cross-attention context.** The last (target) transaction is the query; the history is keys and values. Answers: *"what in this account's history is relevant to judging this transaction?"*

**(b) The last transaction itself.**

**(c) Contrast:** `last_txn − context`. How the target deviates from what its own history predicts. This is the anomaly signal, made explicit.

**(d) Z-score:** `(last − history_mean) / history_std`, clamped to ±10. A classical statistical outlier measure, computed in embedding space. "How many standard deviations from this account's normal is this transaction?"

**(e) Robust z-score:** the same idea using **median** and **MAD** (median absolute deviation, scaled by 1.4826 to match the standard deviation for normal data). Robust statistics are not thrown off by a single extreme historical value, which the ordinary z-score is.

**(f) Multi-scale windowed means:** averages over the last 1, 3, and 5 transactions (`feature_num_windows: [1, 3, 5]`). Different time-scales of "recent normal".

**(g) Temporal decay pooling:** exponentially recency-weighted average with a **learnable** decay rate `alpha`:

```python
weights = torch.exp(-self.alpha * positions)
weights = weights / weights.sum().clamp(min=_EPS)
```

The model learns how fast history should fade.

This is a deliberate fusion of deep learning with classical anomaly-detection features. The hand-designed statistical features (z-score, MAD, decay) give the classifier a strong starting structure rather than requiring it to learn "compare to the historical mean" from scratch.

**A performance caution.** Features (e), (f), and (g) use Python `for b_idx in range(B)` loops over the batch. That is per-example Python iteration inside a GPU training loop — the GPU idles while Python runs. These are vectorisable. The code does correctly handle the precision concern around them (`txn_vectors.float()` upcasting, `autocast(enabled=False)` around cross-attention, epsilon guards), so the numerics are sound; the issue is purely speed.

### Classification heads

**`MLPClassificationHead`** — `Linear(F, 512) → GELU → Dropout → Linear(512, 256) → GELU → Dropout → Linear(256, 1)`.

**`DCNv2ClassificationHead`** — runs the cross network and a deep MLP **in parallel** on the same features, concatenates both outputs, and projects to a single logit. Cross network captures explicit interactions; deep network captures implicit ones. The parallel structure is the "DCNv2 parallel" variant from the paper.

### `FraudClassifier` and the nine pool strategies

The base model returns a hidden vector for **every token**. The classifier needs **one** score for the whole sequence. Pooling is that reduction, and the choice matters a great deal.

| Strategy | Mechanism | Group |
|---|---|---|
| `first` | Logit at position 0 | Legacy |
| `last` | Logit at last non-padding position | Legacy |
| `average` | Mean of logits over valid positions | Legacy |
| `last_txn_mean` | Mean of logits in the final transaction segment | Legacy |
| `last_txn_mean_diff` | History-mean minus last-txn-mean | Legacy |
| `max_masked` | Max logit over valid positions | Legacy |
| `none` | Learnable attention query → softmax weights → MLP | Attention-weighted |
| `enhanced_mlp` | Segment → FeatureExtractor → MLP head | Segmented |
| `dcnv2` | Segment → FeatureExtractor → DCNv2 head | **Segmented (default)** |

The legacy strategies apply a single `Linear(d_model, 1)` to every token and then pool the *logits*. The segmented strategies pool *hidden states* into transaction vectors first and then extract rich features — a much more expressive path.

`last_txn_mean_diff` is conceptually interesting: it outputs `history_mean − last_txn_mean`, an explicit contrast rather than an absolute score.

**Worth noting:** the controlled reproduction run recorded in `project_communication/TFM_V22B_Finalized_Package_PARTIAL.md` used `pool_strategy: last` — the simplest legacy strategy — not the `dcnv2` default. Configuration and default are not the same thing, and anyone reconciling results needs to check which was actually used.

### Auxiliary signal injection

For segmented strategies only, extra per-transaction signals can be added directly into the transaction vectors:

**Transaction labels** (`use_txn_labels`) — a 3-value embedding: 0 = non-fraud, 1 = fraud, **2 = masked**. The target transaction is *always* forced to index 2:

```python
tl[torch.arange(B, device=device), last_real_idx] = 2
```

This is the critical guard. The target's own label is masked out so the model cannot read the answer. History labels can be visible; the target's cannot. Two ablation switches exist: `mask_all_txn_labels` (mask everything) and `set_all_history_txn_labels_zero` (zero the history). Those flags exist precisely so the leakage question can be tested empirically.

**Phats** (`use_phats`) — soft probabilities instead of hard labels, blended:
```python
label_emb = phat_probs * emb_fraud + (1.0 - phat_probs) * emb_legit
```
Then the target position is overwritten with the masked embedding. This carries uncertainty rather than a hard binary, which is a more honest representation of an unmatured label.

**Vendor scores** (`use_vendor_score`) — a scalar risk score projected up to `d_model` via a small MLP, with absent scores (≤ 0) zeroed out.

**Claim labels** (`use_claim_labels`) — chargeback/claim indicators, same 3-value pattern with the target masked.

---
---

# PART 9 — PRETRAINING

**Files:** `configs/pretrain.py`, `training/pretrain.py`, `scripts/distributed_pretrain.py`, `data/pretokenized_dataset.py`, `data/pretrain_dataloader.py`

## 9.1 The objective

Show the model hundreds of millions of transaction sequences with **no fraud labels** and ask it to predict the next token. It learns the statistical structure of payment behaviour.

What it learns, without ever being told:
- Typical inter-transaction timing for different account types
- Which merchant categories co-occur
- Normal amount ranges given context
- Geographic consistency patterns
- Hour-of-day and day-of-week rhythms
- Balance dynamics

All of this becomes reusable knowledge for any downstream task.

## 9.2 The data path

`BatchedFileDataLoader` (`data/pretrain_dataloader.py`) streams parquet files in batches rather than loading everything:

```python
self.all_files = list(list_parquet_uris(self.data_dir))
random.shuffle(self.all_files)
...
def load_next_file_batch(self):
    end_idx = min(self.current_file_idx + self.files_per_batch, len(self.all_files))
    files_to_load = self.all_files[self.current_file_idx:end_idx]
```

With `files_per_batch: 50` it holds 50 files' worth of sequences in memory at a time. It accepts both local paths and `s3://` URIs, tracks processed files, supports `state_dict()`/`load_state_dict()` for resumption without replaying data, and wraps around with a reshuffle when it reaches the end.

`PreTokenizedDataset` then prepares each training example:

**Causal labels** — the input shifted by one:
```python
causal_labels = input_ids[1:] + [pad_id]
```
Position `i` predicts token `i+1`. Simple, and the reason the training data needs no annotation.

**MLM masking** (if enabled) — the BERT recipe: select 15% of non-special tokens; of those, 80% become `<UNK>`, 10% become a random token, 10% stay unchanged. Non-selected positions get label `-100`, PyTorch's "ignore this" index. The 80/10/10 split exists so the model cannot simply learn "only predict at `<UNK>` positions".

**Delta-t positions** — extracts the delta-time bin index at each position for the optional temporal-bias attention.

**Transaction bins** — extracts amount-bin labels wherever a `TRANSACTION_RANGE_*` token appears, plus a mask marking those positions, for the regression objective.

`collate_fn` then pads everything to a uniform length, using `-100` for label keys, `0` for mask keys, and the pad token ID for everything else — and asserts `input_ids` is `long` dtype and non-negative, catching data corruption immediately rather than deep inside a GPU kernel.

## 9.3 `TrainingConfig`

All hyperparameters in one dataclass, with architecture nested as `model: ModelConfig`. `__post_init__` asserts positivity and range constraints — failing at configuration time rather than three hours into a run.

Defaults: `batch_size: 32`, `gradient_accumulation_steps: 4`, `max_steps: 10000`, `learning_rate: 3e-3`, `warmup_steps: 500`, `grad_clip: 1.0`, `bf16: True`.

## 9.4 Gradient accumulation

With `batch_size=32` and `gradient_accumulation_steps=4`, the **effective batch size is 128**. The mechanism:

```python
loss = losses['total'] / self.config.gradient_accumulation_steps
loss.backward()                    # accumulate gradients
if is_final_accum_step:
    clip_grad_norm_(...); optimizer.step(); scheduler.step(); optimizer.zero_grad()
```

Gradients accumulate across four micro-batches; only then is a parameter update taken. Mathematically near-identical to one batch of 128, but only 32 examples' activations occupy GPU memory at a time. This is how you train large-batch models on limited hardware.

The division by `gradient_accumulation_steps` is essential — without it, the effective learning rate would scale with the accumulation count.

## 9.5 The loss objectives

The total loss is a weighted sum:

```
L = w_clm·L_clm + w_mlm·L_mlm + w_reg·L_reg + w_z·L_z
```

**Causal LM loss** (`causal_lm_weight: 1.0`) — cross-entropy on next-token prediction. The primary objective.

```python
causal_loss = F.cross_entropy(
    causal_outputs['logits'][:, :-1].contiguous().view(-1, vocab_size),
    batch['causal_labels'][:, :-1].contiguous().view(-1),
    ignore_index=-100)
```

**Masked LM loss** (`masked_lm_weight: 0.0`) — BERT-style. Off by default. Note the efficiency detail: when the weight is zero, the code **skips the entire second forward pass**, not just the loss term. A naive implementation would run the model twice and multiply by zero.

**Z-loss** (`use_z_loss`, `z_loss_weight`) — the PaLM stabilisation trick. Penalises `mean(logsumexp(logits)²)`, keeping the log-partition function near zero so logits do not drift to extreme magnitudes. Helps numerical stability in long, large-scale runs.

**Transaction amount regression** (`txn_regression_weight`) — this is where the design effort concentrated. Six mutually-exclusive variants, dispatched in `_compute_txn_amount_loss`:

| Variant | Flag | Idea |
|---|---|---|
| CORN head | `use_corn_head` | Conditional ordinal regression via a dedicated head |
| Ordinal BCE | `use_ordinal_loss` | CDF-based ordinal loss over aggregated bin probabilities |
| Gaussian label smoothing | `use_gls` | Spread the target across neighbouring bins with a Gaussian of width `txn_gls_sigma` — neighbouring bins get partial credit |
| EMD / Wasserstein | `use_emd` | Earth Mover's Distance: the cost of moving predicted probability mass to the true bin. Inherently distance-aware |
| Huber | `use_huber_loss` | Smooth L1 — quadratic near zero, linear far away, so outliers do not dominate |
| MSE | *(default)* | Plain squared error on the expected bin index |

All of these exist to solve **one problem**: getting the model to understand that amount bins are ordered. That six separate approaches were implemented and made configurable tells you the team treated it as an open empirical question rather than guessing.

Note the mechanism that makes several of these work — `build_vocab_to_bin_matrix` creates a `[vocab_size, num_bins]` matrix so that vocabulary-level probabilities can be aggregated into bin-level probabilities:

```python
bin_probs = torch.matmul(probs_vocab, self._v2b_fp32())
```

The model predicts over the full 300,000-token vocabulary; this projects that distribution down onto the 20 amount bins so an ordinal loss can be applied. The matrix is kept in fp32 explicitly for numerical stability.

**Dynamic loss weighting** (`use_dynamic_weights`) automatically rebalances the causal and regression weights based on their relative magnitudes each step, so neither dominates.

## 9.6 The optimiser — Muon + AdamW

This is one of the more distinctive choices in the codebase.

**AdamW** is the standard. It maintains a running average of each parameter's gradient (momentum) and of its squared gradient (adaptive per-parameter scaling), with weight decay applied separately from the gradient.

**Muon** (`utils/muon.py`) is newer — from Keller Jordan's work, with the source citing the exact GitHub permalink. Its central idea: for a 2D weight *matrix*, do not treat the gradient as a bag of independent numbers. **Orthogonalise it** first.

```python
def _zeropower_via_newtonschulz(grad, ns_coefficients, ns_steps, eps):
    ortho_grad = grad.bfloat16()
    if grad.size(0) > grad.size(1): ortho_grad = ortho_grad.T
    ortho_grad.div_(ortho_grad.norm().clamp(min=eps))
    for _ in range(ns_steps):
        gram_matrix = ortho_grad @ ortho_grad.T
        gram_update = torch.addmm(gram_matrix, gram_matrix, gram_matrix, beta=b, alpha=c)
        ortho_grad = torch.addmm(ortho_grad, gram_update, ortho_grad, beta=a)
```

A **Newton-Schulz iteration** — five steps of a quintic polynomial that approximately computes the "zeroth power" of the matrix, equalising its singular values. The effect is that the update pushes in all directions of the weight matrix at comparable strength, rather than being dominated by whichever direction happened to have the largest gradient. In practice this converges faster.

The comment is refreshingly candid about the approximation:

> *"This iteration therefore does not produce UV^T but rather something like US'V^T where S' is diagonal with S_{ii}' ~ Uniform(0.5, 1.5), which turns out not to hurt model performance at all relative to UV^T."*

`CombinedMuonAdamW` (`utils/combined_muon_adamw.py`) routes parameters to the right optimiser:

- **Muon** → 2D+ weight matrices (attention projections, FFN weights)
- **AdamW** → 1D parameters (biases, norm weights) and embeddings

Matrices have structure worth orthogonalising; vectors do not. Embeddings are excluded because they are sparse in practice — each step only touches the rows for tokens actually present.

The wrapper exposes a unified `param_groups` so a single learning-rate scheduler drives both. Four groups total: `{matrix, vector} × {decay, no_decay}`, where `no_decay` covers biases, norms, and embeddings — applying weight decay to those is known to hurt.

## 9.7 Learning rate schedule

```python
def lr_lambda(step):
    if step < warmup_steps:
        return step / max(1, warmup_steps)
    progress = (step - warmup_steps) / max(1, max_steps - warmup_steps)
    return min_lr_ratio + (1.0 - min_lr_ratio) * 0.5 * (1.0 + math.cos(math.pi * progress))
```

**Linear warmup then cosine decay.**

Warmup exists because at step 0 the parameters are random and the gradients are large and noisy. A full-size step would throw the model somewhere terrible. Ramping from 0 to the peak over 500 steps lets it settle first.

Cosine decay then lowers the rate smoothly to `min_lr_ratio × peak` (10%). Large early steps explore; small late steps refine. This schedule is essentially universal in modern large-model training.

## 9.8 Mixed precision

Standard floating point is 32-bit (`fp32`). Training in 16-bit halves memory and roughly doubles throughput on modern GPUs.

- **`bf16`** (bfloat16, the default) — same exponent range as fp32, fewer mantissa bits. Wide range means overflow is rare, so no loss scaling is needed. Requires A100/H100-class hardware
- **`fp16`** — more mantissa precision but a much narrower range, so gradients can underflow to zero. Requires a `GradScaler` that multiplies the loss by a large factor before backprop and divides it out afterwards

`setup_mixed_precision` in `utils/training_utils.py` picks the right configuration, and the trainer wraps the forward pass in `torch.cuda.amp.autocast`. Precision-sensitive operations (loss aggregation, z-scores, ordinal losses) are explicitly forced back to fp32 with `autocast(False)` or `.float()`.

## 9.9 Checkpointing and resumption

Every `save_steps` (500 by default), rank 0 writes:

```
output/checkpoint-intermediate-step-5000/
├── model.bin              # model state_dict
├── config.json            # serialised ModelConfig
├── optimizer.bin
├── scheduler.bin
├── scaler.bin             # fp16 only
├── rng_states.bin
└── training_state.json
```

The directory name is `checkpoint-{tag}-step-{step}` — which is why the project record's
starting checkpoint reads `checkpoint-intermediate-step-6500`. Note the extensions are
`.bin`, not `.pt`; `PRETRAINING_GUIDE.md` shows `.pt` and a bare `checkpoint-5000/` layout,
but `PaymentTrainer._save_checkpoint` writes the above and
`PaymentFoundationModel.load_from_dir` reads `config.json` + `model.bin` from it. The code
is authoritative.

Resumption restores model weights, optimiser state (the momentum buffers — losing these causes a visible loss spike), scheduler position, step counter, RNG state, and the data loader position (so already-seen files are not replayed).

Two distinct restart modes:
- **`resume_from_checkpoint`** — full continuation
- **`saved_model_dir`** — weights only, fresh optimiser and schedule. For starting a new run from pretrained weights

## 9.10 Evaluation during pretraining

`evaluation/pretrain_eval.py` computes:

- **Perplexity** — `exp(average cross-entropy)`. Intuitively: "on average, how many tokens is the model choosing between?" Perplexity 10 means it is as uncertain as if picking uniformly from 10 options. Lower is better
- **Top-1 accuracy** — how often the highest-scored token is correct
- **Per-component metrics** — accuracy and loss broken out by each of the 19 components, via `ComponentStatsAccumulator` and the regex map in `component_patterns.py`. This is the diagnostic that actually tells you something actionable: "the model predicts hour-of-day well but merchant country poorly"
- **Numerical bin analysis** — predicted vs actual bin distributions, including accuracy-within-*d*-bins for the ordered fields
- **Generation samples** — free-form sequences the model produces, useful for eyeballing whether it has learned coherent transaction structure

---
---

# PART 10 — FINE-TUNING

**Files:** `configs/finetune.py`, `training/finetune.py`, `scripts/distributed_finetune.py`, `data/fraud_dataset.py`, `data/fraud_streaming_loader.py`

## 10.1 What changes

| | Pretraining | Fine-tuning |
|---|---|---|
| **Data** | Unlabelled sequences | Labelled (fraud / not fraud) |
| **Objective** | Predict next token | Predict one binary label per sequence |
| **Supervision** | Self-supervised | Supervised |
| **Data volume** | Enormous | Comparatively small |
| **Learning rate** | 3e-3 | 1e-5 (backbone) / 1e-4 (head) |
| **Output** | 300,000 logits per position | One logit per sequence |
| **Steps** | 100,000+ | ~10,000 |

## 10.2 Loading and validating the pretrained model

```python
base_model = PaymentFoundationModel.load_from_dir(config.pretrained_model_dir, device=self.device, eval_mode=False)

if self.tokenizer.vocab_size != base_model.config.vocab_size:
    raise ValueError(...)
```

The vocabulary-size check is a hard gate. Embedding matrices are fixed-size; a mismatch would mean token IDs pointing at the wrong rows. The error message explains the permitted variation (redefining meanings via placeholder slots) and the hard constraint (same size).

## 10.3 The data

Parquet with at minimum:
- `token_ids` — the tokenized sequence (`token_col`)
- `frd_tag` — 0 or 1 (`label_col`)

Optional:
- `amount` — per-example amount, used as the VDR value weight and by amount-weighted BCE
- `txn_labels`, `phat_probs`, `vendor_risk_score`, `claim_labels` — auxiliary signals

`FraudStreamingLoader` handles file-batched loading with S3 support. `FraudDataset.__getitem__` converts a row to tensors, with the crucial truncation step:

```python
def truncate_to_max_seq_len(token_ids, max_seq_len, bos_id, gap_id):
    gap_positions = [i for i, tok in enumerate(ids) if tok == gap_id]
    for gap_pos in gap_positions:
        remaining = ids[gap_pos + 1:]
        if len(remaining) <= max_seq_len - 1:
            return [bos_id] + remaining
```

**Truncation drops whole transactions from the front, never cuts one in half**, and always preserves `<BOS>` at position 0. The most recent transactions — the ones that matter for judging the target — are always kept. This is correct and non-obvious; naive truncation would corrupt the transaction structure the whole architecture depends on.

`slice_by_window` similarly keeps the last `window` transactions by cutting at a `<GAP>`.

## 10.4 Stratified interleaving — handling imbalance at the batch level

```python
train_examples, file_batch_pos = _stratified_interleave(
    train_examples, label_key="label", rng=random.Random(cfg.seed + step))
```

The comment explains the purpose:

> *"Reorder so positives are spread evenly across the sequence, then take a contiguous per-rank slice. Both the per-rank shard and each mini-batch drawn from it will have a positive fraction that closely tracks the file batch's overall positive fraction."*

Why this matters: with rare positives and random shuffling, some batches contain zero fraud examples. A batch with no positives produces no useful gradient for the positive class, and it breaks the pairwise ranking loss entirely (which needs both classes present in the same batch). Interleaving guarantees each batch has a representative mix.

This is a real engineering insight. It is the kind of thing that does not appear in papers but determines whether training works.

## 10.5 DDP sharding

```python
if self.distributed:
    per_rank = len(train_examples) // self.world_size
    start = self.rank * per_rank
    train_examples = train_examples[start:start + per_rank]
```

A **contiguous** slice per GPU, preserving the stratified ordering. Integer division deliberately drops up to `world_size − 1` tail examples so every rank iterates the same number of mini-batches — if they differed, the ranks would desynchronise at the gradient all-reduce and the job would hang.

## 10.6 Nine pooling strategies

Covered in Part 8.10. Practical guidance from the fine-tuning guide:
- `dcnv2` — default, best for explicit feature interactions
- `enhanced_mlp` — simpler, for limited data
- `last_txn_mean` — lightweight baseline
- `first` / `last` / `average` — classical baselines for comparison

The presence of all nine is what makes proper ablation possible: you can hold everything else constant and measure what the sophisticated pooling actually buys over `last`.

## 10.7 The composite fraud loss

**File:** `supplied_files/src/utils/losses.py::compute_composite_fraud_loss`

This is the most interesting single piece of modelling in the repository. It is a loss function **reverse-engineered from the evaluation metrics**.

The insight: the evaluation metric is UDR/VDR at a 0.6% outsort cutoff. That is a *ranking* metric at a *fixed budget*. But standard BCE optimises calibrated probability, which is a different thing. A model can have excellent BCE and mediocre UDR. So — build a loss that targets the actual metric.

Four terms, each independently weighted (set a weight to 0 to disable):

### Term 1 — Amount-weighted BCE (`loss_weight_bce`)

```python
amounts_safe = torch.where(torch.isfinite(amounts), amounts, torch.zeros_like(amounts)).clamp(min=0.0)
denom = amounts_safe.mean() + 1e-8
amt_norm = (amounts_safe / denom).clamp(min=0.1, max=20.0)
sample_weights = torch.where(fraud_mask, amt_norm, torch.ones_like(amt_norm))
bce_loss = (bce_per_sample * sample_weights).mean()
```

Fraud examples are weighted by their transaction amount, normalised by the batch mean and clamped to `[0.1, 20]`. **This is a direct VDR proxy** — getting a £5,000 fraud right matters up to 20× more than getting a £50 fraud right, which mirrors how the business measures success.

The NaN and negative-amount handling is explicitly documented and matters: a single NaN amount would poison `amounts.mean()` and silently corrupt every gradient in the batch.

### Term 2 — Pairwise RankNet loss (`loss_weight_pairwise`)

```python
diff = fraud_logits.unsqueeze(1) - nonfraud_logits.unsqueeze(0)   # [F, N]
pairwise_loss = F.softplus(-diff).mean()
```

For every (fraud, non-fraud) pair in the batch, penalise the fraud scoring lower. `softplus(-diff)` is a smooth hinge: near-zero when the fraud scores well above the non-fraud, growing linearly when it does not.

**This optimises ranking directly** — precisely what the outsort mechanism requires. It is the RankNet formulation from learning-to-rank.

Two practical refinements:
- **Pair capping at 512** with random sampling above it, to bound memory
- **Hard-negative mining** — after `hard_negative_start_step` (1000), restrict comparison to the top-scoring 20% of non-fraud. Those are the ones actually crowding the outsort boundary. Early in training this would be counterproductive (the ranking is random), hence the warmup gate

### Term 3 — Approximate outsort loss (`loss_weight_approx_outsort`)

```python
higher_frac = torch.sigmoid((all_scores - fraud_scores) / sigma).mean(dim=1)
approx_outsort_loss = higher_frac.mean()
```

A **differentiable approximation of rank**. For each fraud example, compute the soft fraction of the population scoring higher than it. Minimising this pushes frauds toward the top of the ranking. It is a smooth surrogate for `1 − UDR`, which is itself non-differentiable (ranking involves sorting, which has no useful gradient).

### Term 4 — Top-k UDR boundary loss (`loss_weight_topk_udr`)

```python
min_k = max(1, n_nonfraud // 2)
k = max(min_k, int(n_nonfraud * topk_udr_percentile))
topk_vals, _ = nonfraud_logits_udr.topk(k)
margins = topk_vals.unsqueeze(0) - fraud_logits_udr.unsqueeze(1)
topk_udr_loss = F.softplus(margins).mean()
```

Establishes an **in-batch approximation of the outsort cutoff** — the top-k non-fraud logits — and pushes every fraud above it. `topk_udr_percentile: 0.006` deliberately matches the 0.6% evaluation cutoff.

**The `min_k` floor is not the safety net it appears to be — it is a permanent override.** The source presents it as a fix for small batches (`int(12 × 0.006) = 0`), but since `0.006·n < n/2` for *every* `n`, the floor **always** wins. The percentile branch is unreachable at any batch size. At `batch_size=32`, `k = 15`: the loss pushes each fraud above the top **half** of in-batch non-fraud, not the top 0.6%. `topk_udr_percentile` is dead configuration, and the docstring's claim that it *"mirrors the percentile cut used at evaluation time"* is false. See V17 in the work inventory — this was the heaviest-weighted loss term in the delivered run.

### Assessment

Four complementary pressures — calibration (BCE), pairwise ordering (RankNet), global rank position (approx outsort), and the decision boundary specifically (top-k UDR). Together they shape the score distribution in exactly the way the outsort evaluation rewards.

The controlled run in the project record used: `BCE=1.0, pairwise=0.5, approx_outsort=0.0, topk_udr=2.0` with amount weighting on. Note the heaviest weight on the boundary term — the run was tuned to push frauds over the outsort line specifically.

The function also returns a `components` dictionary with per-term values, batch composition (`n_fraud_in_batch`, `n_nonfraud_in_batch`), pairwise accuracy, and amount statistics, all merged into the step log. When a composite loss stops improving, you can see *which term* is responsible.

## 10.8 Dual learning rates

```python
base_learning_rate: float = 1e-5    # pretrained transformer layers
head_learning_rate: float = 1e-4    # classification head and new layers
```

A 10× difference, implemented via separate optimiser parameter groups (`_build_param_groups`, `_is_base_model_param`).

The reasoning is sound and important. The pretrained backbone contains knowledge accumulated over an enormous, expensive training run. Large updates would destroy it — a failure mode called **catastrophic forgetting**. So it gets gentle nudges. The classification head, by contrast, is freshly random and needs to learn quickly.

The identification is by parameter name:
```python
clean = name.removeprefix("module.")
return clean.startswith("model.")
```
(`module.` is the DDP wrapper prefix; `model.` is the `FraudClassifier`'s attribute for the base model.)

## 10.9 Training diagnostics

The fine-tuning trainer has an unusually thorough diagnostic suite, on by default:

| Check | Threshold | What it catches |
|---|---|---|
| Head gradient norm | `< 1e-8` | The classification head is not learning |
| Backbone gradient norm | `< 1e-8` | Gradients are not reaching the base model |
| Logit standard deviation | `< 0.05` | The model outputs nearly the same score for everything |
| Logit range | `< 0.5` | No discrimination between examples |
| Logit saturation | `> 80%` near 0/1 | Sigmoid saturated; gradients vanish |
| Loss delta | `< 1e-4` | Training has stalled |
| Activation stats before head | — | Mean, std, min, max, % zeros |

These catch the specific, common failure modes of fine-tuning a large pretrained model on imbalanced data. With a 99.84%-negative dataset, a model collapsing to "always predict non-fraud" produces a low loss and looks fine on a loss curve — but its logit standard deviation goes to nearly zero, which these diagnostics detect immediately.

The `early_saturation_steps: 200` guard prevents false alarms during warmup, when saturation is normal.

## 10.10 Dynamic evaluation subsampling

```python
eval_files_per_run: Optional[int] = 1
eval_sample_fraction: float = 0.2
eval_stratified_subsample: bool = True
```

Evaluating on the full held-out set every 200 steps would dominate the runtime. Instead: load one eval file, keep 20%, stratified so the fraud rate is preserved.

The trade-off is stated honestly in the project record:

> *"Training-time evaluations are not a fixed-population curve: each call loads one eval file and uses a deterministic 20% stratified subsample. Final claims must come from standalone scoring on the complete selected OOT population."*

That is the right posture. Training-time eval is for *monitoring*; final numbers come from `evaluation/fraud_eval.py` on the full population.

---
---

# PART 11 — EVALUATION

## 11.1 `evaluation/fraud_eval.py`

Loads a fine-tuned checkpoint and scores a held-out dataset, distributed across GPUs.

The checkpoint loading is more careful than it first appears. `utils/checkpoint_manager.py` provides:

```python
def detect_pool_strategy(state_dict, default="last") -> str:
```

which **infers the pooling strategy from the shapes and names of the saved tensors**. If the checkpoint contains `cls_head.cross_network.*` it was DCNv2; if it contains only `score.weight` it was a legacy strategy. This means evaluation reconstructs the right architecture even without the original config, which is exactly the robustness you want when a checkpoint has to be scored months later.

`_hydrate_eval_config_from_ft` similarly reads the fine-tuning config saved alongside the checkpoint and fills in evaluation settings the user did not specify.

Distributed evaluation uses `gather_tensors` to collect predictions from all ranks onto rank 0 before computing metrics — you cannot compute AUC on a shard, since it is a global ranking statistic.

**Per-file metrics.** When the loader retains a `source_file` column, metrics are reported per source parquet as well as in aggregate. Since files are partitioned by account and typically by time period, this reveals whether performance is uniform or concentrated — e.g. degradation in later months, which is the early warning of model drift.

## 11.2 The metric implementations

All metrics are **pure functions on NumPy arrays** with no model or I/O dependency (`utils/fraud_metrics.py`, `utils/metrics.py`). That is a deliberate and good design decision: it means they are unit-testable (and `test/test_metrics.py` exists), reusable by both the trainer and the standalone script, and impossible to accidentally couple to a particular model version.

The outsort computation is worth reading closely:

```python
order = np.argsort(-scores, kind="mergesort")
```

`mergesort` is specified because it is **stable** — ties are broken by original order deterministically, so the same data always produces the same result. With `quicksort` (the NumPy default), tied scores could be ordered differently between runs and produce slightly different UDR. In a model-validation context where reproducibility is a requirement, that detail matters.

The `partials=True` option handles the boundary row fractionally — if the 0.6% cutoff falls in the middle of a weighted example, it includes the appropriate fraction rather than rounding. More precise, particularly with small evaluation sets.

## 11.3 `evaluation/pretrain_eval.py`

Evaluates the foundation model itself:
- Perplexity, top-1 accuracy
- Per-component accuracy and loss across all 19 fields
- Numerical bin analysis, including accuracy-within-*d*-bins for the ordered fields
- Generation samples
- Optional training-loss plot embedding

Distributed, with `_gather_scalar`, `_gather_dict_of_scalars`, and `_gather_dataframes` handling the cross-rank aggregation.

## 11.4 Reading results

**Pretraining is going well if:** perplexity decreases steadily; per-component accuracy is high on predictable fields (hour of day, day of week) and reasonable on harder ones (merchant category); generated sequences have valid structure.

**Fine-tuning is going well if:** AUC is meaningfully above 0.5; UDR at 0.6% is substantially better than the 0.6% you would get by random selection; VDR exceeds UDR (the model is catching the expensive fraud); calibrated FPR is operationally acceptable; and — critically — held-out performance tracks training performance.

**Warning signs:** AUC above ~0.99 on OOT data is far more likely to indicate leakage than excellence. The project record contains exactly this case, on 30 Jul 2026:

> *"Obtain 99% AUC in OOT data. Data leakage issue exists since a target transaction cannot see a finalized fraud label at the un-maturated time point."*

That is the correct diagnostic reflex: an implausibly good number triggered a leakage investigation rather than a celebration.

---
---

# PART 12 — INFRASTRUCTURE

## 12.1 GPUs

A GPU has thousands of simple cores optimised for doing the same arithmetic on many numbers at once. Neural network training is almost entirely matrix multiplication, which is exactly that pattern. A GPU is roughly 10–100× faster than a CPU for this work.

The constraint is **GPU memory**. The model's parameters, the optimiser state (Adam keeps two extra copies per parameter), the activations for the backward pass, and the gradients all live there simultaneously. For a 1B-parameter model in bf16 that is roughly: 2GB weights + 8GB optimiser state (fp32 momentum and variance) + gradients + activations. This is why `batch_size`, `gradient_accumulation_steps`, `bf16`, and gradient checkpointing all exist as knobs. The pretraining guide's first troubleshooting entry is *"OOM → Reduce batch_size, increase gradient_accumulation_steps, enable bf16."*

The project record mentions an **H200** for the controlled run — a current-generation data-centre GPU with 141GB of memory.

## 12.2 Distributed Data Parallel (DDP)

```bash
torchrun --nproc_per_node=4 --nnodes=1 src/scripts/distributed_pretrain.py ...
```

How it works:
1. Every GPU holds a **complete copy** of the model
2. Each gets a **different slice** of the batch
3. Each computes its own gradients
4. **All-reduce**: gradients are averaged across all GPUs
5. Every GPU applies the identical averaged update, so the copies stay in lockstep

Vocabulary: **rank** = GPU index globally; **local_rank** = GPU index on this machine; **world_size** = total GPU count.

Two important implementation details:

**`no_sync` during accumulation:**
```python
if self.distributed and not is_final_accum_step:
    with self.model.no_sync():
        loss.backward()
```
All-reduce is network-bound and expensive. During gradient accumulation there is no need to synchronise on every micro-batch — only before the optimiser step. This suppresses the intermediate all-reduces and is a substantial throughput win.

**Rank-0-only I/O.** Only rank 0 writes checkpoints and logs. Without this guard, four GPUs would write the same file simultaneously and corrupt it.

## 12.3 Spark on Kubernetes

The data pipeline cannot run on one machine — the raw data is far too large. It runs as Spark jobs on Kubernetes.

From the architecture diagram in `S3_Spark_Datapipeline_README.md`:

```
Driver pod (JupyterHub)
  → run_s3_spark_tokenizer.py (reads YAML → builds ctx)
  → spark_runner.py
      1. zip the data_pipeline/ tree
      2. upload zip → s3://bucket/spark-code/pipeline_code.zip
      3. start SparkSession (master = k8s://...)
  → spark-submit: sc.parallelize(parts).map(worker)
      ↓
Executor pods (N of them, each: download zip → unzip → sys.path
               → read S3 input → process in pandas → write S3 output)
      ↓
per-part results collected on the driver
```

The **driver** coordinates; **executors** do the work in parallel; each handles one account partition independently. Because accounts are independent, the problem is embarrassingly parallel.

The code-distribution mechanism is unusual and the README explains exactly why:

> *"Why we don't use Hadoop S3A for code transport: the Wells Fargo S3 endpoint returns 403 on `getFileStatus` to S3A's JVM signing path. boto3/s3fs work fine, so we ship the zip to S3 and have each executor pull it via Python."*

A pragmatic workaround for a real environment constraint, documented so the next engineer does not have to rediscover it.

Scaling knobs: `executors` (parallelism), `cores_per_executor`, `executor_memory` / `executor_memory_overhead` / `executor_pod_memory_limit`. The troubleshooting section covers exit code 137 (out-of-memory kill), resource starvation, the S3 403, missing vocab files, and driver hangs — each with a specific remedy. Documentation written by someone who hit all of them.

## 12.4 S3 and credentials

Object storage. Accessed via `s3://bucket/prefix/...` URIs. Both `data/s3_utils.py` and `data_pipeline/s3_utils.py` make local paths and S3 URIs interchangeable throughout the codebase:

```python
list_parquet_uris(path)   # works for both
read_parquet(uri)         # works for both
```

Credentials come from a `.env` file at the repo root, loaded by `utils/dotenv.py` — a **standard-library-only** implementation, deliberately avoiding a `python-dotenv` dependency in an environment where adding packages requires approval. Relevant variables: `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_ENDPOINT_URL` (for S3-compatible storage rather than real AWS), `AWS_S3_VERIFY_SSL`. Otherwise it falls through to the standard boto3 credential chain.

## 12.5 Reproducibility

```python
set_reproducibility_seed(self.config.seed + self.rank)
```

Seeds are per-rank (`seed + rank`) so different GPUs shuffle differently — otherwise every GPU would apply identical augmentation and dropout, defeating the purpose. RNG state is saved and restored with checkpoints (`get_rng_state_for_json`, `save_torch_rng_states`), so a resumed run continues the same random stream rather than starting a fresh one.

Reproducibility is a hard requirement in model validation, and the project record lists *"Review the hyper-parameters, random seed settings"* as an explicit review item.

---
---

# PART 13 — COMPLETE FILE INDEX

Every file in `supplied_files/`, with its role.

## 13.1 Top level

| File | Role |
|---|---|
| `README` | Architecture overview, component table, project structure, evaluation summary |
| `PRETRAINING_GUIDE.md` | Data format, all config fields, distributed launch, losses, optimiser, checkpointing, troubleshooting |
| `FINETUNING_GUIDE.md` | Fraud fine-tuning, pool strategies, heads, auxiliary signals, focal and composite loss, dual LRs, streaming, diagnostics, evaluation, CLI |

## 13.2 `src/configs/`

| File | Contents |
|---|---|
| `pretrain.py` | `TrainingConfig` — all pretraining hyperparameters, nested `ModelConfig`, validating `__post_init__` |
| `finetune.py` | `FinetuneConfig` — pool strategy, heads, aux signals, focal/composite loss, dual LRs, streaming, columns, diagnostics |
| `fraud_eval.py` | `FraudEvalConfig` — checkpoint, data, outsort percentiles, `true_fraud_rate` |
| `pretrain_eval.py` | `PretrainEvalConfig` — checkpoint, validation data, batch size, precision |
| `tokenizer.py` | `TokenizerConfig` — special tokens, delta-time bins, feature dictionary. *(Note: the pipeline uses its own `TokenizerConfig` defined inside `data_pipeline/utility_lib/tokenizer.py`, which additionally carries fraud-tag and mask tokens. Two similar classes exist; the pipeline one is authoritative for tokenization)* |

## 13.3 `src/modelling/`

| File | Contents |
|---|---|
| `model.py` | `ModelConfig`, `PaymentFoundationModel`, `create_hybrid_attention_mask`, `build_shared_position_ids`, `build_field_type_ids`, config converters, `load_from_dir` / `from_pretrained` / `save_pretrained` |
| `attention.py` | `AttentionConfig`, `MultiHeadAttention`, `DeltaTemporalBias`, `DeltaTemporalAttention`, `create_attention_layer` |
| `transformer.py` | `RMSNorm`, `LayerNorm`, `create_norm`, `TransformerConfig`, `TransformerBlock`, `HybridTransformerBlock` |
| `feed_forward.py` | `FeedForward` — SwiGLU / GELU / ReLU / SiLU, optional gradient checkpointing |
| `embedding.py` | `EmbeddingConfig`, `TokenEmbedding`, `LearnedPositionalEmbedding`, `SinusoidalPositionalEmbedding` |
| `rope.py` | `RotaryPositionalEmbedding` — interleaved layout, cached cos/sin, layout auto-detection |
| `dcn.py` | `CrossNetworkV2` |
| `coral_ordinal.py` | `CORALOrdinalHead` — monotone cutpoints, marginal initialisation |
| `corn_loss.py` | CORN targets, masked BCE loss, prediction and expected-value helpers, `coral_bce_loss` |
| `binary_focal_loss.py` | `BinaryFocalLoss` |
| `fraud_cls_model.py` | `FraudClassifierOutput`, `TransactionFeatureExtractor`, `MLPClassificationHead`, `DCNv2ClassificationHead`, `FraudClassifier` with all nine pooling paths and all injection helpers |

## 13.4 `src/data/`

| File | Contents |
|---|---|
| `pretokenized_dataset.py` | `PreTokenizedDataset` — MLM masking, delta-t extraction, amount-bin extraction, causal label shift |
| `pretrain_dataloader.py` | `collate_fn`, `BatchedFileDataLoader` (streaming, resumable, S3-aware) |
| `fraud_dataset.py` | `discover_parquet_files`, `ensure_bos`, `truncate_to_max_seq_len`, `slice_by_window`, `split_sequence_by_gap`, `build_subsequence`, `_row_to_example`, `load_fraud_examples`, `FraudDataset`, `fraud_collate_fn`, `create_fraud_dataloader` |
| `fraud_streaming_loader.py` | `FraudStreamingLoader` — file-batch iteration with aux-column handling and S3 support |
| `s3_utils.py` | `list_parquet_uris`, `read_parquet` — path-agnostic local/S3 I/O |

## 13.5 `src/training/`

| File | Contents |
|---|---|
| `pretrain.py` | `PaymentTrainer` — Muon/AdamW setup, LR schedule, all six amount-loss variants, `_forward_loss`, evaluation, checkpointing, resumption, training loop |
| `finetune.py` | `FraudFinetuneTrainer` — `_stratified_interleave`, dual-LR param groups, composite loss, diagnostics, streaming file-batch loop, dynamic eval, checkpointing |

## 13.6 `src/evaluation/`

| File | Contents |
|---|---|
| `fraud_eval.py` | `run_fraud_evaluation`, `gather_tensors`, `_load_classifier_from_checkpoint`, `_hydrate_eval_config_from_ft`, CLI |
| `pretrain_eval.py` | `run_pretrain_evaluation`, `EvaluationDataset`, distributed gather helpers, per-component reporting, generation, loss plotting, CLI |

## 13.7 `src/utils/`

| File | Contents |
|---|---|
| `component_patterns.py` | `COMPONENT_PATTERNS` (19 regexes), numerical subsets, `extract_bin_number`, `map_token_to_component`, `build_token_id_component_map` |
| `transaction_utils.py` | `segment_transactions` — GAP-delimited mean-pooling into transaction vectors |
| `losses.py` | `compute_z_loss`, `compute_huber_loss`, `build_vocab_to_bin_matrix`, `gaussian_label_smoothing_targets`, `ordinal_bce_loss_from_bin_probs`, `make_class_weights_from_counts`, `emd_loss_from_bin_probs`, `compute_composite_fraud_loss` |
| `metrics.py` | `compute_token_loss`, `compute_accuracy`, `compute_perplexity`, `ks_statistic` |
| `fraud_metrics.py` | `sigmoid`, confusion helpers, `ThresholdResult`, `evaluate_at_threshold`, `evaluate_fraud_metrics`, `udr_vdr_fpr_at_outsort`, `compute_all_fraud_metrics` |
| `eval_stats.py` | `ComponentStatsAccumulator` |
| `muon.py` | `Muon` optimizer, `_zeropower_via_newtonschulz`, `_adjust_lr` |
| `combined_muon_adamw.py` | `CombinedMuonAdamW` |
| `training_utils.py` | `init_distributed`, `set_training_device`, `set_reproducibility_seed`, `setup_mixed_precision`, `move_batch_to_device`, `compute_grad_l2_norm`, `append_jsonl`, RNG state save/restore |
| `checkpoint_manager.py` | `CheckpointManager`, `LossLogger`, `extract_state_dict`, `detect_pool_strategy`, `load_pretrained_for_finetuning` |
| `dotenv.py` | Stdlib-only `.env` loader |
| `debug.py` | Tensor diagnostics — shape, NaN/Inf checks |

## 13.8 `src/scripts/`

| File | Contents |
|---|---|
| `distributed_pretrain.py` | `torchrun` entry point for pretraining; every `TrainingConfig` field as a CLI flag |
| `distributed_finetune.py` | `torchrun` entry point for fine-tuning; every `FinetuneConfig` field as a CLI flag |

## 13.9 `src/test/`

| File | Contents |
|---|---|
| `test_component_patterns.py` | Regex mapping correctness |
| `test_metrics.py` | Metric function correctness |
| `test_shared_position_field_ids.py` | `build_shared_position_ids` and `build_field_type_ids` — shared indices within transactions, GAP grouping, column alignment, clamping |

## 13.10 `src/data_pipeline/`

**Documentation**

| File | Contents |
|---|---|
| `README-DATA-PIPELINE.md` | Shell-script usage, all five modes, range/restart semantics, examples |
| `S3_Spark_Datapipeline_README.md` | Spark-on-K8s architecture, prerequisites, quick start, mode reference, YAML reference, verification, scaling, troubleshooting, deep-dive |
| `README-TABULAR-PKL-REMOVAL-E2E.md` | The pickle → tabular parquet migration |
| `ReadMe_Fraud_FT.md` | Fraud fine-tuning data generation |
| `utility_lib/Tokenizer Documentation.md` | Tokenizer reference |
| `s3_config_template.txt` | Credential file template |

**Core libraries**

| File | Contents |
|---|---|
| `utility_lib/tokenizer.py` | `TokenizerConfig`, `Tokenizer` — all 13 handlers, vocabulary build, sequence tokenization, `tokenize_and_join`, save/load |
| `utility_lib/tokens_to_seqs.py` | `remove_fraud_tags`, `split_into_transactions`, `build_sequences`, `process_parquet`, `process_directory` |
| `utility_lib/generate_fraud_data.py` | `create_fraud_data`, `combine_fraud_data`, label-delay probability functions, indicator-token resolution, amount/txn-id extraction |
| `utility_lib/preprocess.py` | Preprocessing helpers |
| `tokenizer_lib.py` | `build_account_transactions`, `extract_account_transaction`, `generate_tokenizer`, `generate_tokenizer_from_tabular`, `generate_tokenizer_and_join` |
| `tokenizer_lib_s3.py` | S3 variants of the above |

**Drivers and infrastructure**

| File | Contents |
|---|---|
| `spark_runner.py` | Spark-on-K8s session builder, code-zip upload, executor bootstrap |
| `run_s3_spark_tokenizer.py` | Main Spark driver (largest file in the repo at ~117KB) |
| `run_s3_spark_combined_tokenizer.py` | Combined end-to-end driver |
| `run_wrapped_tokenizer.py` | Local/wrapped runner |
| `s3_utils.py` | Path-agnostic I/O plus `.env` credential loading |
| `spark_test/spark_executor_test.py` | Executor environment test |

**Format migration**

| File | Contents |
|---|---|
| `pkl_to_tabular.py` | Pickle → tabular parquet |
| `pkl_s3_to_tabular.py` | S3 variant |
| `combine_pkl_par.py` | Combine pickle partitions |
| `comb_files_by_segment.py` | Combine by segment |
| `comb_files_oot.py` / `comb_s3_files_oot.py` | Combine out-of-time files |
| `exclude_predecline.py` | Remove pre-declined transactions |
| `inspect_s3_outputs.py` | Inspect S3 outputs |

**Validation** — `validate_pkl_restructuring_step.py`, `validate_tabular_token_ids.py`, and the eight scripts in `validation_check/` (see Part 7.8).

**Configuration** — `yaml_configs/` with subdirectories `end_2_end/`, `pkl_restructing/`, `spark_scenario_test/`, `optimize/`, `other_testing/`, `raw_extended/`, plus `RUNBOOK_20_FILES.md` and `assets/Feature_list_for_Xian.xlsx`.

## 13.11 Repository root (outside `supplied_files/`)

| File | Contents |
|---|---|
| `confluence/Foundation Model for Fraud` | Project wiki reconstruction — weekly updates Jul–Sep 2026, objectives, model candidates, environment, fine-tuning strategy, validation considerations |
| `project_communication/TFM_V22B_Finalized_Package_PARTIAL.md` | The controlled-validation handoff package: run snapshot, communication register (COM-001 through COM-014+), evidence gaps. Explicitly marked partial |
| `Transaction_Foundation_Model_Exact_Match_v4(1).pptx` | Presentation deck (not relied on for this guide, per instruction) |

---
---

# PART 14 — END-TO-END WALKTHROUGH, RISKS, AND FINDINGS

## 14.1 The whole system in one pass

Let us follow one transaction from the bank's database to a fraud score.

**Step 1 — Raw data.** A row lands in a monthly parquet shard: account `A-1234`, `transaction_dttm` 2025-03-14 10:23, amount £47.82, merchant category 5411, country GB, channel online, plus ~15 more fields.

**Step 2 — `acc-trans`.** Spark regroups every monthly shard by account. Account `A-1234` now has all its transactions in one place, time-ordered, in one of 10,000 account partitions.

**Step 3 — `gen-token`.** The tokenizer, driven by `tokenizer_config_v22.json`, converts each transaction to tokens. Delta-time first (computed from the previous transaction's timestamp), then every configured feature in order, with `_MISSING` tokens where values are absent. Token strings become IDs via `vocab_to_id.json`. The account's whole history becomes one long integer list: `[0, 1547, 892, 331, ..., 4, 1203, ...]` where `4` is `<GAP>`.

**Step 4a — `gen-seq` (the pretraining branch).** Fraud tags are stripped. The long sequence is split at `<GAP>` boundaries and repacked into 2,048-token chunks, never cutting a transaction, overlapping by one transaction at each boundary. Written as parquet with a `sequence` column.

**Step 5a — Pretraining.** `BatchedFileDataLoader` streams 50 parquets at a time. `PreTokenizedDataset` builds shifted causal labels. 32 sequences per micro-batch, 4 micro-batches accumulated → effective batch 128. Each sequence flows through: embedding lookup (×√2048) → optional field-type embedding → positional embedding → 16 transformer blocks (RMSNorm → 32-head attention with RoPE → residual → RMSNorm → SwiGLU → residual) → final norm → LM head → 300,000 logits per position. Cross-entropy against the next token. Backpropagation. Muon orthogonalises the matrix gradients, AdamW handles the rest, cosine schedule sets the step size. Repeat 100,000+ times. Checkpoint every 500 steps.

*The result: a model that has learned what normal payment behaviour looks like, without ever being shown a fraud label.*

**Step 4b — `gen-frd` (the fine-tuning branch).** For each account, every labelled transaction becomes a candidate target. Non-fraud targets are downsampled 100:1; all fraud is kept. Up to 18 transactions of history are attached, truncated at any previous fraud. Historical fraud tags are stripped, remapped to placeholders, or probabilistically flipped to simulate reporting delay. Falcon-decline and pre-decline indicators are masked. Emitted as parquet: `token_ids`, `frd_tag`, `amount`, `seq_len`, `truncated`, `labels_history`.

**Step 5b — Fine-tuning.** The pretrained checkpoint loads; the tokenizer vocab size is verified to match. A `FraudClassifier` wraps it. `FraudStreamingLoader` pulls a file-batch; `_stratified_interleave` spreads the positives evenly; each rank takes a contiguous slice. Sequences are truncated at transaction boundaries to 2,048 tokens.

Forward pass: the base model runs with `skip_lm_head=True`, producing hidden states only. `segment_transactions` mean-pools each `<GAP>`-delimited segment into one vector per transaction. Auxiliary signals are injected (with the target's own label forced to the masked index). `TransactionFeatureExtractor` produces 18,432 features — cross-attention context, contrast, z-score, robust z-score, windowed means, decay pooling. The DCNv2 head runs explicit crosses and a deep MLP in parallel and projects to a single logit.

Loss: composite. Amount-weighted BCE (VDR proxy) + pairwise RankNet + approximate outsort + top-k UDR boundary. Diagnostics check gradient norms, logit spread, and saturation. Backward pass. Dual learning rates — 1e-5 for the backbone, 1e-4 for the head. Every 200 steps, a quick 20% stratified eval. Every 500 steps, a checkpoint.

**Step 6 — Evaluation.** `fraud_eval.py` loads the checkpoint, infers the pool strategy from the state dict, scores the full out-of-time population across all GPUs, gathers to rank 0, and reports AUC, KS, AP, log loss, and — the ones the business reads — UDR, VDR, FPR, and calibrated FPR at 0.6%, 1%, and 5% outsort, in aggregate and per source file.

**Step 7 — Production (intended).** The transaction arrives. The account's last 17 transactions are retrieved and tokenized. The sequence is scored. If the score lands in the top 0.6%, the transaction is outsorted for review or decline.

## 14.2 Why the design holds together

Reading the codebase as a whole, the design decisions are coherent and mutually reinforcing:

- **Everything is a token** → one uniform mechanism for wildly heterogeneous fields
- **`<GAP>` delimits transactions** → and then enables the hybrid mask, transaction segmentation, shared position IDs, field-type IDs, window slicing, and safe truncation. One structural choice pays for itself six times over
- **The hybrid mask** matches the real causal structure: transactions are ordered, fields within a transaction are not
- **Shared positions + field types** remove a spurious ordering while preserving field identity
- **Ordinal losses** reintroduce the numeric ordering that tokenization destroyed
- **The composite loss** is built backwards from the evaluation metric rather than borrowed from a textbook
- **Calibrated FPR** corrects for downsampling so development numbers mean something operationally
- **Stratified interleaving** makes the ranking losses viable under extreme imbalance
- **Placeholder tokens** allow new features after pretraining without invalidating the checkpoint
- **Streaming loaders with state** make billion-scale training resumable

This is not a research prototype. It is a system built by people who expected it to be validated.

## 14.3 Risks and open questions

Stated plainly, because a guide that only says what works is not useful.

### Risk 1 — The `days_since_status_dt` leakage (highest severity)

The tokenizer's own docstring says positive date differences *"are treated as missing to avoid future-status leakage"*. **The code that did that is commented out.** A positive difference means the account's status date is in the future relative to the transaction — if cards are closed after fraud is found, that token is close to a direct label.

Mitigations that exist: a post-hoc token-rewriting patch in `generate_fraud_data.py` (`inactv_positive_ids` → `inactv_missing_id`), applied only during `gen-frd` and only when configured.

The project record names this explicitly (COM-013): v22b *"should not be used in current form because of potential leakage from card inactive date."*

**What to verify:** for any given trained model, whether the correction was configured and applied, and whether performance changes materially when the feature is removed entirely.

### Risk 2 — Label maturity

The core problem. Historical fraud labels in the input may not have existed at real scoring time.

Mitigations that exist, and they are serious: the 90-day `days_offset` cutoff in `tokenize_and_join`; `apply_label_delay` with two probability curves; the forced masking of the target transaction's own label; and three explicit ablation flags (`mask_all_txn_labels`, `set_all_history_txn_labels_zero`, `use_phats`).

**What to verify:** run the ablations. The flags exist precisely so the question can be answered empirically. If performance is similar with all transaction labels masked, the model is genuinely learning behaviour. If it collapses, it was leaning on labels.

### Risk 3 — Upstream fraud-system indicators

`FALCONDECLINE_INDICATOR`, `PREDECLINE_INDICATOR`, and `SEGMENT` reference other fraud controls. Using another fraud model's output as an input is circular, and in production those signals may be unavailable, differently timed, or themselves changing. The pipeline has masking logic and a dedicated `exclude_predecline.py`, and the controlled data package name (`tfm_v22b_dropcpr_falcondecline`) suggests these were dropped for the validation run. Worth confirming per run.

### Risk 4 — Downsampling distortion

100:1 non-fraud downsampling changes the score distribution the model learns. `calibrated_fpr` corrects the FPR metric, but the model's *probability outputs* remain uncalibrated to production prevalence. If downstream systems consume probabilities rather than ranks, a recalibration step is needed.

### Risk 5 — Interpretability

A 1B-parameter Transformer over token sequences is opaque. Regulatory expectations around adverse-action explanation and model risk management usually require the ability to attribute a score to inputs. The Confluence record lists this as an open item (31 Aug 2026: *"Explore possible ways to explain the contribution of each feature on the score or embedding results"*). No attribution tooling exists in this repository.

### Risk 6 — Configuration surface

`FinetuneConfig` has well over 80 fields. Nine pool strategies, six amount-loss variants, four composite-loss terms, multiple injection switches. This flexibility is what enables proper ablation, but it also means **the configuration is as much a part of the model as the weights are.** Reproducing a result requires the exact config, not just the checkpoint. The project record's own run snapshot exists for exactly this reason — and note that it records `pool_strategy: last`, not the `dcnv2` default, and `window_size=None` against a historical statement of 17 transactions.

### Risk 7 — Documentation drift

The guides describe `window_size`, `max_files`, `pool_strategy`, and other fields with defaults that do not always match the dataclasses, and the README's project structure lists a `src/tokenizer/` package that is not present in `supplied_files/` (see A2). Treat the dataclasses in `src/configs/` as authoritative over prose.

## 14.4 Code findings — and an important caveat about this repository

**Read this before using anything in this section.**

The contents of `supplied_files/` were transferred into this GitHub repository by hand, and some files were mangled in transit and patched up afterwards. That means **a discrepancy visible here is not automatically a defect in the other team's actual codebase.** Anything mechanical — a renamed identifier, a missing file, a broken import — has to be checked against the source repository (`k102157/txn-foundation-model`, develop branch, per COM-009 in the project record) before it goes anywhere near a validation write-up.

So the findings are split into two groups. **Group A is almost certainly transfer damage** and should be confirmed, not reported. **Group B would survive a clean transfer** — these are properties of the design, not of the file copy — and are the ones worth actually looking at.

### Group A — likely transfer artifacts. Verify against the source repo; do not report as findings.

**A1 — Package markers are named `_init_.py`, not `__init__.py`.**
Every package directory contains a zero-byte `_init_.py` with single underscores. Python only recognises `__init__.py`. A working repository could not import itself with these names, so the original must have had them correct. This is file-name mangling, nothing more.

**A2 — `src/tokenizer/` is absent.**
Five modules import `from tokenizer.tokenizer import Tokenizer` (`training/pretrain.py`, `training/finetune.py`, `evaluation/fraud_eval.py`, `evaluation/pretrain_eval.py`, `data/pretokenized_dataset.py`), and the README's project structure lists `src/tokenizer/tokenizer.py`. The directory is not in `supplied_files/`. The tokenizer implementation itself *is* present at `src/data_pipeline/utility_lib/tokenizer.py`. A missing directory is a copy omission, not a code defect.

**A3 — `training/pretrain.py:266` reads `config.training_data_dir`; `TrainingConfig` defines `train_data_dir`.**
A single-identifier mismatch. Could be transfer damage or a hand-patch, could be genuine rename drift in the original. **Check this one against the source** — if it is real, `PaymentTrainer` cannot be constructed, which would be obvious to anyone who ran it, which in turn suggests it is not real.

**A4 — `corn_bce_loss_from_logits` is called with `logits_btkm1=`; the signature is `logits_btk1`.**
Same category as A3. This path only executes when `use_corn_head=True`, so it could plausibly sit unnoticed in a real repo if the CORN head was never enabled in production runs. **Worth checking**, but a low-stakes one either way.

Together A1 and A2 mean **the package as supplied cannot be imported**. That is a statement about this GitHub copy, not about the model.

### Group B — substantive. These describe the design and would survive a clean transfer.

These are the ones to actually examine. None of them is a formatting artifact: they are default values, missing type annotations, algorithm choices, and commented-out logic — the kind of thing a copy does not invent.

**B1 — `TransformerConfig.use_checkpoint` is not a dataclass field.**

```python
@dataclass
class TransformerConfig:
    ffn_bias: bool = False
    use_checkpoint = True          # ← no type annotation
```

Without an annotation, this is a plain class attribute, not a dataclass field. `get_transformer_config()` filters on `TransformerConfig.__annotations__`, so `ModelConfig.use_checkpoint = False` is never propagated. The effect: gradient checkpointing is **always enabled** in the feed-forward layers regardless of configuration. Gradient checkpointing trades compute for memory (it recomputes activations in the backward pass), so this costs training speed rather than correctness.

**B2 — Per-example Python loops in `TransactionFeatureExtractor`.**

Robust z-score, multi-scale windows, and temporal decay pooling each iterate `for b_idx in range(B)` over the batch. That is Python-level iteration inside a GPU training loop; the GPU idles while the interpreter runs. All three are vectorisable. The numerics are handled correctly (fp32 upcasting, `autocast(False)` around cross-attention, epsilon guards) — this is purely a throughput observation.

**B3 — Deprecated PyTorch APIs.**

`torch.cuda.amp.autocast` and `torch.backends.cuda.sdp_kernel` are both deprecated in current PyTorch in favour of `torch.amp.autocast("cuda", ...)` and `torch.nn.attention.sdpa_kernel`. They still work but emit warnings and will eventually be removed. Worth noting for anyone upgrading the environment.

**B4 — The hybrid attention mask is not enabled by default.**

`use_hybrid_attention` appears **twice in the entire tree**, both inside `model.py` (`:330` as a forward-argument default of `False`, `:358` as the branch). No config field, no CLI flag, no caller. It **cannot** have been enabled without a code change — this is closed, not open.

The same applies to two more: `use_shared_position_ids` (`model.py:48`) is exposed only in the *pretrain* CLI and nowhere in fine-tuning; `use_field_type_embedding` (`model.py:49`) has no CLI flag anywhere. Both default `False`. `use_rope` also defaults `False` (`model.py:36`) but `TrainingConfig` overrides it to `True`, so RoPE is genuinely active.

The README presents the hybrid mask under "Key Design Decisions", and Part 4.5 of this guide describes shared positions and field-type embeddings at length as active design. **All three are off unless a checkpoint's `config.json` says otherwise.** Read those four flags off the delivered `config.json` — a five-minute check that closes four open items.

**B5 — Unused configuration in `EmbeddingConfig`.**

`time_embedding_dim`, `use_transaction_time_embedding`, `hour_embedding_size`, `day_of_week_embedding_size`, `day_of_month_embedding_size`, and `month_embedding_size` are defined but consumed by none of the three embedding classes. Vestigial from an earlier design where time was embedded separately rather than tokenized. Harmless, but potentially misleading to a reader.

**B6 — The fraud-tag vocabulary offset.**

```python
self.vocab[self.config.non_frd_token] = vid + 1
self.vocab[self.config.frd_token] = vid + 2
```

Starts at `vid + 1`, leaving ID `vid` unassigned. Downstream code compensates consistently (`frd_tag_0_id = vocab_size - 1`, `frd_tag_1_id = vocab_size`), so it functions correctly — but it is an undocumented convention that would break if anyone "corrected" it in isolation.

## 14.5 What I would verify first

If the goal is to validate this model, in priority order:

1. **Ablate the `INACTV_DT` / `days_since_status_dt` feature entirely.** If performance barely moves, the leakage concern is moot for this model. If it collapses, you have your answer.
2. **Run the transaction-label ablations** (`mask_all_txn_labels=True`, then `set_all_history_txn_labels_zero=True`). Measure the delta. This directly quantifies label-maturity dependence.
3. **Drop the Falcon and pre-decline indicators** and re-measure. Quantifies dependence on upstream fraud systems.
4. **Confirm the exact run configuration** for any result being validated — particularly `pool_strategy`, `window_size`, `use_hybrid_attention`, and which loss variant was active. The defaults in the dataclasses are not necessarily what was run.
5. **Reconcile the "last 17 transactions" statement with the prepared parquets** — count actual `<GAP>` tokens per sequence in the training data rather than relying on either the configuration or the email.
6. **Score on a genuinely out-of-time population** with the full standalone evaluation script, not training-time subsampled eval.
7. **Get a clean copy of the source repository** and re-check Group A against it. Establish which version of the code actually produced the checkpoints being validated. Nothing in Group A should appear in a validation write-up until it has been confirmed against the original.

---
---

# PART 15 — XGBOOST, AND HOW TO LEVERAGE THIS MODEL ALONGSIDE IT

This part exists because the realistic question is not "is the foundation model good?" but "**does it add anything on top of the gradient-boosted model already doing the job?**" Answering that requires understanding both.

## 15.1 What XGBoost is

**XGBoost** stands for e**X**treme **G**radient **Boost**ing. It is the workhorse of fraud, credit, and pricing modelling across essentially every bank, and it is a completely different kind of machine from a Transformer. Three ideas stack up to make it.

### Idea 1 — the decision tree

A decision tree is a flowchart of yes/no questions:

```
                  amount > £500?
                 /              \
               no                yes
               /                   \
    merchant is known?        country = home country?
      /         \                  /            \
    yes         no                yes            no
  score .01   score .08        score .04      score .61
```

You follow the branches based on the transaction's features and read a score off the leaf. The tree is built automatically: at each split the algorithm tries every feature and every threshold and picks whichever separates fraud from non-fraud best.

A single tree is weak. It is too coarse, and if you grow it deep enough to be accurate it just memorises the training data.

### Idea 2 — boosting

Instead of one big tree, build **hundreds of small ones, in sequence, where each new tree is trained to correct the mistakes of all the trees before it.**

- Tree 1 makes a rough prediction. It gets plenty wrong.
- Tree 2 is trained specifically on tree 1's *errors*.
- Tree 3 is trained on what trees 1 and 2 together still get wrong.
- …and so on, for several hundred trees.

The final score is the sum of all the trees' contributions. Each tree is deliberately weak — typically only 4 to 8 levels deep — so no single one can memorise anything. Accuracy comes from accumulating hundreds of small corrections.

This is the "boosting" part, and it is a form of gradient descent (Part 2.3) — each tree steps in the direction that reduces the loss, just like each parameter update does in a neural network. The mechanism is the same; the thing being adjusted is different.

### Idea 3 — the engineering

"XGBoost" specifically is one very well-optimised implementation of that idea: regularisation to stop overfitting, native handling of missing values, efficient use of multiple CPU cores, and sensible defaults. It is fast enough to train on hundreds of millions of rows on ordinary hardware, which is why it took over.

### What XGBoost needs from you

**This is the crucial difference.** XGBoost sees **one row at a time**. It has no concept of sequence, history, or time. If you want it to know that this account normally spends £40 and this transaction is £900, you must compute that and hand it over as a column.

So a production fraud XGBoost is fed not the raw transaction but a hand-built **feature vector**, typically dozens to hundreds of columns:

```
amount, amount_over_account_30d_mean, txn_count_last_1h, txn_count_last_24h,
distinct_merchants_last_7d, days_since_last_foreign_txn, is_new_merchant_for_account,
amount_percentile_within_mcc, hours_since_last_txn, balance_ratio, ...
```

Building and maintaining those columns is the job. It is where the modelling expertise sits, where most of the performance comes from, and where most of the ongoing cost is. The Confluence record shows this directly — the team's existing internal feature set is described as **"94 engineered features"** (24 Aug 2026 entry), and a separate effort identified *"19 transaction-level raw variables"* plus four derived from transaction time.

### Why banks like it

| Property | Why it matters |
|---|---|
| **Fast** | Trains in minutes to hours, scores in microseconds |
| **Tabular-native** | Works directly on the row-and-column data banks already have |
| **Handles missing values** | No imputation step required |
| **Interpretable enough** | Feature importance and SHAP values give a defensible per-decision explanation — which matters for adverse-action notices and model risk management |
| **Well-understood by validators** | Decades of institutional familiarity. A validation team knows what questions to ask |
| **Cheap** | CPU only. No GPU cluster |

That last column is the real reason it is the incumbent. It is not just accurate — it is *defensible*.

## 15.2 XGBoost vs the Transaction Foundation Model

| | **XGBoost (your champion)** | **TFM (this repository)** |
|---|---|---|
| **Input** | One row: a hand-built feature vector | A token sequence: the account's transaction history |
| **Who finds the patterns** | You do, via feature engineering. XGBoost finds interactions *among the features you supply* | The model does, from raw sequences. No feature engineering |
| **Sequence awareness** | None. Must be baked into features | Native. This is the entire point |
| **Training cost** | Hours on CPU | Weeks on a GPU cluster (pretraining), then hours per fine-tune |
| **Scoring cost** | Microseconds | Milliseconds, on a GPU, over a ~2,048-token sequence |
| **Reuse across tasks** | None. New task = new model, new features | The pretrained backbone is reusable — that is the "foundation" claim |
| **Interpretability** | SHAP, feature importance. Mature tooling | Attention weights at best. No attribution tooling exists in this repo |
| **Failure mode** | Misses what you did not think to engineer | Opaque; harder to detect leakage or drift |
| **Validation maturity** | Decades of precedent | Essentially none for this model class in fraud |

Read that table honestly and the position is: **XGBoost is better on every operational axis except one.** The one is that it cannot see anything you did not hand it.

That is the whole bet. The TFM's value is entirely in whether it finds sequential structure that your 94 engineered features do not already capture. If your feature set is mature — and a production fraud model's usually is — a lot of what the TFM learns will be things you are already computing. The honest question is not "is the TFM good" but **"what is the incremental lift over the existing champion, and is it worth the operational cost?"**

## 15.3 Three ways to leverage it, in increasing order of ambition

### Path A — TFM score as a feature in XGBoost *(recommended starting point)*

Run the TFM over your transactions, take the single fraud logit it produces per transaction, and add it to your existing XGBoost as **one more column**.

```
existing 94 features  +  tfm_score  →  XGBoost  →  final score
```

Why this is the right first move:

- **It cannot make things worse.** If the TFM score carries no new information, XGBoost's feature selection will simply down-weight it, and performance is unchanged. You get a clean, quantified answer to "does this add anything" with almost no downside risk.
- **Your champion stays the decision-maker.** No change to the model that is currently defending the bank. The governance burden is far lighter than a replacement.
- **The measurement is unambiguous.** Train two XGBoost models on identical data, one with the column and one without. The difference in UDR/VDR at your operating outsort *is* the TFM's incremental value. One number, and it is the number the business cares about.
- **Interpretability is mostly preserved.** SHAP still works. The TFM score becomes one feature whose contribution you can quantify, even if you cannot explain what is inside it.

**The codebase already supports this, and it looks deliberate.** `evaluation/fraud_eval.py` writes an `eval_logits.npz` containing the per-transaction logits, labels, amounts, timestamps, and — critically — `fi_transaction_ids`. Those are join keys. The source comment says so outright:

```python
# Also persist amounts (when available) so downstream ensembling
# scripts can compute value-weighted VDR without re-loading the
# parquet source.
```

The other team anticipated ensembling. Set `--store_logits`, join the `.npz` to your feature table on `fi_transaction_id`, and you have your extra column.

### Path B — TFM embeddings as features in XGBoost

Instead of the single score, take the model's **hidden state** — the 2,048-number vector representing the account's state at the target transaction — reduce it (PCA down to 20–50 dimensions, say), and feed those as features.

Richer than a single score, because it carries the full learned representation rather than one projection of it. `FraudClassifier` already returns `hidden_states` in its output (`FraudClassifierOutput.hidden_states`), so the extraction point exists; you would need to write the dump, as only logits are persisted today.

Trade-offs: more signal, but you lose the clean interpretability story — "PCA component 7 of a Transformer embedding" is not a feature you can explain to a regulator. Realistically a research step to size the ceiling, not a production candidate.

### Path C — TFM as the primary model

Replace or challenge XGBoost outright. This is what the other team built toward.

It requires everything in Part 14 to be resolved — the leakage questions, the label-maturity ablations, interpretability tooling that does not currently exist, GPU serving infrastructure at authorisation latency, and a validation precedent your institution does not yet have. **This is a multi-quarter programme, not an experiment.**

**My honest read:** run Path A first. It is cheap, it is low-risk, and it answers the only question that determines whether B or C is worth funding. If Path A produces a meaningful UDR/VDR lift at your operating cutoff, you have a real business case for the larger investment. If it produces nothing, you have saved yourself the larger investment, and that is a genuinely valuable result too.

## 15.4 What Path A actually takes

A concrete sequence, assuming you have a fine-tuned checkpoint from the other team:

1. **Get the checkpoint and its tokenizer together.** They are inseparable — a model with a mismatched tokenizer produces silent garbage (Part 6.7). You need the checkpoint directory, `vocab.json`, and `config.json`.
2. **Reproduce their reported number first.** Before doing anything new, score their evaluation set with `evaluation/fraud_eval.py` and confirm you get the metrics they claim. If you cannot reproduce their result, nothing downstream means anything. This is also step one of the validation mandate, so it is not extra work.
3. **Score your own population.** Run the data pipeline over the same transactions your XGBoost is trained and tested on, then score them with `--store_logits`.
4. **Join on `fi_transaction_id`.** The `.npz` gives you `logits`, `labels`, `amounts`, `timestamps`, `fi_transaction_ids`. Join to your feature table.
5. **Check the join is honest.** Confirm the TFM score for a transaction was computed using only information available before that transaction. This is where Path A can quietly go wrong — if the TFM's history window overlaps the period your XGBoost features were computed from, or if the label-maturity issues in Part 14 are unresolved, you will measure a lift that does not exist in production.
6. **Train two XGBoosts.** Identical data, identical hyperparameters, one with `tfm_score` and one without.
7. **Compare at your operating point.** Not AUC — **UDR and VDR at your actual outsort percentile**, on out-of-time data. AUC can move without the operating point moving at all.
8. **Check the SHAP.** If `tfm_score` ranks as a top feature, understand *when* it fires. If it only adds value on a narrow segment, that is still useful — it may mean a targeted champion/challenger rather than a global one.

Step 5 is the one that gets skipped and the one that invalidates results. The TFM's leakage questions do not go away just because you are using it as a feature — they propagate straight into your XGBoost, and they will look like a performance gain.

## 15.5 How the two workstreams relate

You have two jobs — validate their work, and evaluate whether to leverage it — and they share most of their evidence:

| Activity | Serves validation | Serves leverage |
|---|---|---|
| Reproduce their reported metrics | ✔ core requirement | ✔ prerequisite for everything |
| Leakage ablations (Part 14.5) | ✔ core requirement | ✔ decides whether any lift is real |
| Confirm the run configuration | ✔ core requirement | ✔ you need it to score anything |
| Score your own OOT population | ✔ independent evidence | ✔ the input to Path A |
| Path A ensemble test | — | ✔ the business case |

Only the last row is leverage-specific. **Roughly 80% of the work is the same work**, which means you can run both mandates off one pipeline rather than two. Do the validation properly and the leverage evidence falls out of it almost for free.

One thing worth being firm about: **the ablations in Part 14.5 are not optional for the leverage question either.** If the TFM's performance depends on label leakage, then a `tfm_score` column will inject that leakage into your XGBoost, and you will ship a champion that looks better in backtest and is worse in production. Establish that the signal is real before you build anything on top of it.

---
---

# PART 16 — GLOSSARY

**Activation function** — A non-linear function applied to a neuron's output. Without it, stacked layers collapse into a single linear function.

**AdamW** — The standard optimiser. Adaptive per-parameter learning rates with momentum and decoupled weight decay.

**Attention** — The mechanism letting every position in a sequence look at every other position, weighted by learned relevance.

**AUC-ROC** — Probability that a randomly chosen positive scores above a randomly chosen negative. 0.5 = random, 1.0 = perfect.

**Backpropagation** — The algorithm that computes gradients by applying the chain rule backwards through a network.

**Batch** — A group of examples processed together.

**bf16 / bfloat16** — 16-bit floating point with fp32's exponent range. The default precision here.

**BCE (binary cross-entropy)** — The standard loss for binary classification.

**`<BOS>` / `<EOS>` / `<PAD>` / `<UNK>` / `<GAP>`** — Special tokens: begin, end, padding, unknown, and this project's transaction separator (ID 4).

**Calibrated FPR** — FPR rescaled from the downsampled evaluation population to the true production fraud rate.

**Causal mask** — Prevents a position from attending to future positions.

**Checkpoint** — A saved snapshot of model weights, optimiser state, and training position.

**CORAL / CORN** — Ordinal regression methods that respect the ordering of bins.

**Cross-entropy** — The standard loss for predicting a category from a probability distribution.

**DCNv2** — Deep & Cross Network v2. Builds explicit bounded-order feature interactions via element-wise products with the original input.

**DDP (Distributed Data Parallel)** — Multi-GPU training where each GPU holds a full model copy and gradients are averaged across GPUs.

**Delta time (Δt)** — Elapsed time since the previous transaction, binned into tokens.

**Downsampling** — Keeping only a fraction of the majority class to balance training data.

**Dropout** — Randomly disabling signals during training to prevent overfitting.

**Embedding** — A learned dense vector representing a token. Similar tokens end up with similar vectors.

**EMD (Earth Mover's Distance)** — Distance between distributions measured as the cost of moving probability mass. Distance-aware, so it respects ordering.

**Epoch** — One full pass through the training data.

**FlashAttention** — An algorithm computing attention without materialising the full attention matrix in memory.

**Focal loss** — A loss that down-weights easy examples so training focuses on hard ones. Designed for extreme class imbalance.

**Foundation model** — A large model pretrained on broad unlabelled data, then adapted to many specific tasks.

**FPR (in this codebase)** — False positives ÷ true positives. **Not** the textbook `FP/(FP+TN)`.

**Gradient** — The direction and magnitude of steepest increase in the loss with respect to each parameter.

**Gradient accumulation** — Summing gradients over several micro-batches before one parameter update, to simulate a larger batch.

**Gradient checkpointing** — Recomputing activations during the backward pass instead of storing them. Saves memory, costs compute.

**Hash bucketing** — Mapping high-cardinality values into a fixed number of buckets via a hash function.

**Hidden state** — The vector representation at each position after passing through the transformer layers.

**Hybrid attention mask** — This project's mask: bidirectional within a transaction, causal across transactions.

**Hyperparameter** — A setting chosen before training, as opposed to a parameter learned during it.

**KS statistic** — Maximum gap between the score CDFs of positives and negatives.

**Label maturity** — The delay between a fraud occurring and being confirmed and labelled.

**Layer normalisation / RMSNorm** — Rescaling activations for numerical stability. RMSNorm skips mean subtraction.

**Leakage** — Information in the training inputs that would not be available at real prediction time. Inflates measured performance and destroys real-world performance.

**Learning rate** — Step size for parameter updates. The most consequential hyperparameter.

**Logit** — A raw, unbounded model output before sigmoid or softmax.

**Loss function** — A single number quantifying how wrong the model is.

**Masked language modelling (MLM)** — Hiding tokens and asking the model to reconstruct them. BERT-style.

**Mixed precision** — Using 16-bit arithmetic for speed and memory, with 32-bit where precision matters.

**Muon** — An optimiser that orthogonalises matrix gradients via Newton-Schulz iteration before applying updates.

**Newton-Schulz iteration** — An iterative matrix procedure used by Muon to approximately equalise singular values.

**OOT (out of time)** — Test data from a later period than training data. The only honest evaluation for a temporal model.

**Optimiser** — The procedure that adjusts parameters to reduce the loss.

**Ordinal regression** — Prediction where the categories have a meaningful order.

**Outsort** — The fixed top percentage of ranked transactions that a bank takes action on.

**Overfitting** — Memorising the training data rather than learning generalisable patterns.

**Parameter / weight** — A number the model learns during training.

**Parquet** — A columnar file format for large analytical datasets.

**Perplexity** — `exp(average cross-entropy)`. Intuitively, the effective number of options the model is choosing between.

**Phat (p̂)** — A predicted probability, used here as a soft alternative to a hard historical label.

**Pooling** — Reducing a variable-length sequence of vectors to a single fixed-size vector.

**Pretraining** — Stage one: self-supervised learning of general structure from unlabelled data.

**RankNet** — A pairwise learning-to-rank loss penalising incorrectly ordered pairs.

**Residual connection** — `output = input + layer(input)`. Lets gradients flow through deep networks.

**RoPE (Rotary Position Embedding)** — Encoding position by rotating query and key vectors, making attention naturally relative.

**Self-supervised learning** — Learning from data without human labels, by predicting part of the input from the rest.

**Sigmoid** — Squashes a number to the range 0–1. The binary equivalent of softmax.

**Softmax** — Converts a vector of scores into a probability distribution.

**SwiGLU** — A gated activation function. The default here.

**Token / token ID / vocabulary** — The atomic unit, its integer index, and the full list of possible units.

**Tokenizer** — The component converting raw input into token IDs.

**Transformer** — The neural architecture built from attention and feed-forward layers with residual connections and normalisation.

**UDR (Unit Detection Rate)** — Fraction of all fraud *incidents* captured in the outsort.

**VDR (Value Detection Rate)** — Fraction of all fraud *value* captured in the outsort.

**Weight decay** — A penalty on large parameter values, used as regularisation.

**XGBoost** — Extreme Gradient Boosting. Hundreds of small decision trees built in sequence, each correcting the previous ones' errors. The incumbent model class for tabular fraud and credit problems. Sees one row at a time and therefore needs hand-engineered features to know anything about history.

**Boosting** — Building many weak models in sequence, each trained on what the previous ones got wrong, and summing their contributions.

**Decision tree** — A flowchart of automatically-chosen yes/no questions on features, ending in a score.

**Feature engineering** — Hand-computing the columns a tabular model needs (rolling averages, counts, ratios). The main cost and the main source of performance in a traditional fraud model, and the thing a sequence model is meant to replace.

**SHAP** — A method for attributing a model's prediction to its individual input features. Standard interpretability tooling for XGBoost; nothing equivalent exists in this repository for the TFM.

**Ensembling** — Combining several models' outputs. Here, specifically: feeding the TFM's score into XGBoost as an extra feature (Part 15.3, Path A).

**Weight tying** — Sharing the input embedding matrix with the output projection matrix.

**Z-loss** — A stabilisation penalty on the log-partition function, keeping logits from drifting to extremes.

**Z-score** — `(value − mean) / standard deviation`. How many standard deviations from normal.

---
---

# CLOSING

If you have read this far, you should now be able to answer, for this system:

- **What it is** — a from-scratch Transformer foundation model over payment-transaction sequences, pretrained self-supervised on unlabelled transaction history and fine-tuned supervised for binary fraud classification
- **Why the representation works** — every field becomes a token, every transaction a sentence, every account history a paragraph, with `<GAP>` as the structural delimiter that the mask, the segmentation, the positional scheme, and the truncation logic all build on
- **How each file contributes** — Part 13 indexes every file in the repository
- **How the machinery works** — from gradient descent through attention, RoPE, SwiGLU, and Muon
- **What makes it domain-specific** — the hybrid mask, the shared per-transaction positions with field-type embeddings, the ordinal amount losses, the composite ranking loss built backwards from UDR/VDR, and the calibrated FPR
- **Where the risks are** — label maturity, the disabled leakage guard on `days_since_status_dt`, upstream fraud-system indicators, downsampling distortion, and interpretability
- **What to verify first** — the ablations in Part 14.5

The system is well-engineered. The domain-specific design choices are genuinely thoughtful rather than generic deep learning applied to a new dataset. The risks are real, and — importantly — **the codebase contains the switches needed to test them.** That combination is what makes it validatable.

---

*Guide written from the code and documentation in `supplied_files/`, plus the project record in `confluence/` and `project_communication/`. All code references cite file paths within the repository. Findings in Part 14.4 were verified directly against the source.*
