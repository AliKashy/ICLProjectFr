# Deck intake — what the PowerPoint says, and where it contradicts the code

Source: `Transaction_Foundation_Model_Exact_Match_v4(1).pptx`, 34 slides. Every slide's
speaker notes read *"Reconstructed as editable PowerPoint objects from user-supplied
photographs"* — so this is itself a reconstruction, and its numbers should be treated as
reported rather than verified.

> ## ⚠ Version — read this before using anything below
>
> **The deck describes v17. The work in progress is v22b.** Confirmed by the user.
>
> That single fact reframes this whole intake. What first looked like deck-vs-code
> *contradictions* are mostly **version differences**, which is a much less alarming and
> much more useful thing to know. Specifically:
>
> - **The results table in §1 is v17's, not v22b's.** It is the right benchmark to
>   understand and the wrong one to validate against. Ask for the v22b numbers.
> - The tokenization scheme, vocabulary, pooling findings and hyper-parameter
>   conclusions all describe v17's configuration.
> - Five versions separate them. Expect real differences, and do not read one as
>   evidence about the other.
>
> What the deck is still authoritative for: **the shape of the claim** (TFM beats the
> XGBoost champion on UDR/VDR/FPR at a 0.6% outsort), the metric definitions, the scale
> of the pretraining effort, and the developing team's own stated next steps.

---

## 1. The claim you are validating

Slide 31. This is the table your entire validation exists to test.

| Model | Period | UDR | VDR | FPR |
|---|---|---:|---:|---:|
| XGBoost LoB v1.2 *(engineered features + VAA score)* | Jun 25 | 0.548 | 0.580 | 5.79 |
| XGBoost ours *(no engineered features)* | Apr 24 | 0.225 | 0.173 | 14.995 |
| FT-TFM (H=5, **first** pooling) | Apr 24 | **0.024** | **0.014** | **151.54** |
| FT-TFM (H=5, **last** pooling) | Apr 24 | 0.703 | 0.604 | 4.297 |
| FT-TFM (H=5, **avg** pooling) | Apr 24 | 0.689 | 0.597 | 4.402 |
| FT-TFM (H=5, fraud weight 14.6) | Apr 24 | 0.666 | 0.589 | 4.590 |
| **FT-TFM best (H=12, last pooling)** | Apr 24 | **0.731** | **0.638** | **4.093** |
| **FT-TFM best (H=12, last pooling)** | **Jun 25** | **0.684** | **0.637** | **4.980** |

**The headline claim:** on the same Jun-25 period, TFM beats the production XGBoost
champion on all three — UDR 0.684 vs 0.548, VDR 0.637 vs 0.580, FPR 4.98 vs 5.79.

Two things worth noticing immediately:

- **The slide's own footnote confirms the FPR definition:** *"FPR = non-fraud/fraud in
  0.6% outsort."* That is `FP/TP`, exactly as the code computes it. Good — deck, code and
  guide agree.
- **The LoB champion uses the VAA vendor score; the TFM does not.** *"LoB model uses 94
  features with vendor model VAA score; we use 98 tokenized features excluding VAA
  score."* So the comparison is not like-for-like in the champion's favour — which, if
  anything, strengthens the TFM's result. Worth confirming.

### The pooling result is enormous, and it matters for V16

`first` pooling scores **UDR 0.024** — worse than random selection. `last` scores 0.703.
A **29× difference** from one configuration change.

That tells you two things:

1. **Pooling choice dominates everything else in this model.** It is not a tuning detail.
2. It explains why `last` was used, and it corroborates the project record. **Which means
   V16 and V12 probably do not apply to the delivered model at all** — both are specific
   to the segmented (`dcnv2` / `enhanced_mlp`) path.

They remain worth verifying from the checkpoint config, but the deck is now a second
independent source pointing at `last`.

---

## 2. Scale, and what was actually built

| | |
|---|---|
| Dataset | 18.8B transactions · 38.8M accounts · 16.8M merchants · 17 months (Mar 24 – Jul 25) |
| Average | 1.1B transactions/month · 485 transactions/account |
| Pretraining compute | 8 × H200, 2.6B transactions, ~3.5 days, **576 GPU-hours** |
| Architecture | 1B decoder-only · 16 blocks · 32 heads · 64 head dim · emb 2048 · MLP 8192 |
| Context | 1024 / 2048 tokens |
| Parallelism | DDP and **FSDP**, on 4/8 GPU pods, for 1B and 3B versions |
| Objective | Weighted CLM + MLM: `L = w₁·L_CLM + w₂·L_MLM` |

Architecture matches `ModelConfig` exactly. **Note FSDP** — the supplied code implements
DDP only, so the sharded-training path described in the deck is not in what you were
given.

### Pretraining progression (slide 25)

| Model | Tokens | Perplexity ↓ | Accuracy ↑ |
|---|---|---:|---:|
| Initial (5% Oct data) | 5B | 4.59 | 72.1% |
| Best params | 11B | 1.39 | 92.4% |
| 1 month | 101B | 1.26 | 92.6% |
| 6 months | 220B | 1.245 | 93.1% |
| Latest (reordered tokens) | 330B | **1.167** | **95.25%** |

---

## 3. Where the deck and the code disagree

**This is the most important output of this intake.** Five discrepancies, each of which
suggests the deck and the supplied code describe **different versions of the model**.

### 3.1 Vocabulary size — not a discrepancy. I overstated this.

Slide 12: *"97 raw features produce 5,164 tokens."* The user reports the v22b vocabulary
is around 5,300 — consistent, with five versions of drift.

`ModelConfig.vocab_size: int = 300000` sits at `modelling/model.py:18`, but it is
**overwritten at runtime** from the loaded tokenizer:

```python
# training/pretrain.py:78
self.config.model.vocab_size = self.tokenizer.vocab_size
```

So the 300,000 never reaches a real model. It is a **misleading placeholder in the
dataclass**, not a conflict with the deck. Worth a one-line note — anyone reasoning from
the default will misjudge the model's size by ~58× — but it is not a finding, and I
should not have listed it as one.

### 3.2 Downsampling — RESOLVED, by the user's own data

Slide 28: *"Keep all fraudulent transactions and **down-sample to 1%** of non-fraud
transactions of interest for each account."*

The user observes the delivered v22b parquets are **~12% fraud in train, ~0.1% in eval**.
That settles it arithmetically. Keeping all fraud and 1/D of non-fraud from a 0.16% base
rate gives:

| `downsample` | Resulting fraud rate |
|---:|---:|
| 1 | 0.16% |
| 10 | 1.58% |
| 50 | 7.42% |
| **85** | **11.99%** |
| **100** | **13.81%** |

**~12% train means D ≈ 85–100 was used** — matching the deck's "1%" statement. And
**~0.1% eval means evaluation data was not downsampled at all**, which is correct
practice: train on a rebalanced set, evaluate on the natural distribution.

So the `downsample: 1` in the supplied YAML configs simply **is not the config that built
this data**. My earlier "every config says 1" observation was true about the repo and
irrelevant to the delivered parquets.

**Two consequences that matter:**

1. **`calibrated_fpr` is close to a no-op for the eval set.** Calibration corrects for
   over-represented fraud; at ~0.1% the eval population is already at production
   prevalence, so calibrated and raw FPR should nearly coincide. Confirm rather than
   assume, but do not expect a large correction.
2. **V11's calibration argument survives, and gets sharper.** The model was *trained* on
   ~12% fraud and is *scored* on ~0.1%. A model trained at a 75× inflated base rate will
   output probabilities badly miscalibrated to the scoring population — before you even
   reach `pos_class_weight=3.0` or the ranking losses. The output is a good ranker and
   almost certainly not a probability.

**A coherence check that passes.** If eval is at natural rate, the deck's FPR should be
derivable from its UDR:

```
TP_rate = UDR × 0.0016 ;  FP_rate = 0.006 − TP_rate ;  FPR = FP_rate / TP_rate
UDR 0.684  ->  FPR 4.48   (deck reports 4.98)
UDR 0.731  ->  FPR 4.13   (deck reports 4.09)
```

Close enough to confirm the deck's numbers were computed on a natural-rate population
with the FP/TP definition. **That is a genuine internal-consistency check on their
reported results, and it passes** — worth saying, because it is evidence the reported
figures are coherent rather than assembled.

### 3.3 The classifier head — "shallow is sufficient" vs a DCNv2 default

Slide 30, hyper-parameter findings: *"**A shallow classifier head is sufficient.**"*
Slide 33, key learnings: *"**Complex classifier head yields little to no boost.**"*
Slide 29 lists exactly three pooling strategies: first, last, average.

The supplied code's default is `dcnv2` — a cross network plus deep MLP on top of an
18,432-dimensional feature vector built from cross-attention, contrast, z-scores, robust
z-scores, multi-scale windows and temporal decay pooling.

**The deck describes a much simpler model than the code implements** — which is exactly
what five versions of drift would produce. The segmented `dcnv2` path is very likely
post-v17 work that the deck's results do not cover.

> ### ⚠ This question is about YOUR run too, not only theirs
>
> The user ran `distributed_finetune.py` as supplied, adjusting only what the fine-tuning
> guide specified. **If `pool_strategy` was left at its default, that run used `dcnv2`.**
> The deck used `last`; the controlled run in the project record used `last`.
>
> On v17 data, `first` pooling scored UDR 0.024 against `last` pooling's 0.703 — a 29×
> gap from one setting. Pooling dominates this model.
>
> **So a pooling mismatch may explain more of the fine-tune divergence than the GPU count
> does.** Check `pool_strategy` in the run's own output config before attributing the
> difference to effective batch size. This is now the first thing to verify, ahead of
> everything else.

### 3.4 Training and validation periods — three different stories

| Source | Training | Validation / test |
|---|---|---|
| **Deck** (slide 28) | Jul 2024 – Dec 2024 | **Apr 2024** |
| **Project record** (COM-003) | 10/2024 – 05/2025 | 06/2025 |
| **Controlled run** | `tfm_v22b_dropcpr_falcondecline/train/` | `.../eval/` |

Three artifacts, three configurations. But note the first one specifically:

> The deck's validation period (April 2024) appears to precede its training period
> (July–December 2024).

**Downgraded to a question, not a finding.** Three reasons to be cautious: the deck is a
photograph reconstruction and could carry a transcription error; it describes v17, not
the version being validated; and COM-003's v22b periods (train 10/2024–05/2025, test
06/2025) are properly forward-looking.

Still worth one line in the developer questions — validating on a period that precedes
training would not test generalisation forward in time, which is the only direction that
matters for deployment. But do not carry it as a v22b finding.

### 3.5 FSDP is described but not supplied

Slides 16, 18 and 21 describe FSDP as used to train the 1B and 3B models, with a table
showing FSDP + Flash Attention + `torch.compile` at 2.22× DDP throughput. The supplied
code has no FSDP path — `init_distributed()` builds plain DDP only.

**What DDP and FSDP are**, since both appear throughout the deck:

| | **DDP** — Distributed Data Parallel | **FSDP** — Fully Sharded Data Parallel |
|---|---|---|
| Model copies | **Every GPU holds the whole model** | **The model is split across GPUs** |
| Each GPU gets | A different slice of the batch | A different slice of the batch *and* only its shard of the weights |
| Communication | Average the gradients after each step | Gather the weights each layer needs, then scatter results back |
| Memory per GPU | Full model + gradients + optimiser state | Roughly all of that ÷ number of GPUs |
| Use when | The model fits comfortably on one GPU | Memory is the binding constraint |

The deck's own summary: *"DDP replicates model state and communicates gradients; FSDP
shards model state and communicates parameters/gradients around each layer."*

For a 1B model, DDP works. FSDP exists for when it doesn't — and their table shows it was
also 2.22× faster in their setup once combined with Flash Attention and `torch.compile`.
Its absence from the supplied code is worth one question, not a finding.

---

## 4. Things in the deck that strengthen your position

### 4.1 They already named your Path A

Slide 34, Next Steps:

> *"**Foundation model as feature extractor for downstream models** — Extract embeddings
> and feed them as features into models for downstream applications."*
> *"Consider **XGBoost + Transformer embeddings**."*

The ensemble test (E1) is not your idea imposed on their work — **it is the developing
team's own stated next step.** That makes it far easier to propose, and it means the
`store_logits` plumbing in `fraud_eval.py` was built deliberately for it.

### 4.2 They also named the interpretability gap

> *"**Feature Importance Analysis** — Identify features driving fraud identification on
> transactions and their histories for the fine-tuned model."*

Listed as a next step, not as done. Consistent with your Confluence record. O3 is an
acknowledged gap, not a criticism you are inventing.

### 4.3 A training-stability finding you can use

Slide 33: *"**Checkpoints peak mid-training, then degrade.** → Select by validation
metrics, not step count."*

That is an admission of instability, and it raises a direct question: **which checkpoint
was selected for the delivered model, and on what basis?** If selection was by validation
metric on a small eval slice, the selection itself can overfit. Worth a question.

### 4.4 Muon's justification

Slide 19 shows Muon converging faster than AdamW with ~10% lower final loss. So the
unusual optimiser choice was measured, not assumed.

---

## 5. On "the payment foundation model thing is big now, so ours shouldn't deviate"

Half right, and the half that is wrong is the half that matters for validation.

**Right:** the overall pattern is now an established approach — tokenize transactions,
decoder-only transformer, next-token pretraining, fine-tune with a classification head.
The deck's own framing (slide 7: language FM vs transaction FM) is the standard framing.

**Wrong as a validation stance**, for three reasons:

1. **"It matches the industry pattern" is the assumption to test, not to accept.** Your
   job is to establish what *this* model does. An industry pattern is context, not
   evidence.

2. **This model genuinely deviates in several places**, and the deviations are where the
   risk concentrates: the hybrid attention mask, shared per-transaction position IDs with
   field-type embeddings, the four-term composite ranking loss, Muon, and the DCNv2
   segmented head. None of those are standard. Several are good ideas. All of them are
   unvalidated.

3. **The real deviation is not from the industry — it is between your own artifacts.**
   The deck, the code, the project record and the YAML configs describe at least three
   different configurations. That is the concrete problem in front of you, and no amount
   of industry convergence resolves it.

**The reframe:** stop asking "does this match what everyone else does?" and start asking
**"do the artifacts I was given describe the same model?"** Right now the answer is no,
and establishing which one produced the delivered checkpoint is the highest-value thing
you can do.

---

## 6. Questions this intake adds

Fold into the developer question list:

1. **Which model version does the deck describe?** Its vocabulary (5,164), downsampling
   (1%), pooling options (first/last/average only) and "shallow head is sufficient"
   finding do not match the supplied code's defaults.
2. **The deck's validation period (Apr 2024) precedes its training period (Jul–Dec
   2024).** Was that intentional? Which results in the table are forward out-of-time?
3. **Which checkpoint was selected for the delivered model, and on what basis?** Slide 33
   notes checkpoints peak mid-training then degrade.
4. **Was the VAA score excluded from the TFM but present in the XGBoost baseline?** If so
   the comparison understates the TFM — worth confirming rather than assuming.
5. **Is FSDP used anywhere in the delivered pipeline?** It is described in the deck but
   absent from the supplied code.
6. **`downsample`: 1 or 100?** The deck says 1%; every supplied config says keep-all.
