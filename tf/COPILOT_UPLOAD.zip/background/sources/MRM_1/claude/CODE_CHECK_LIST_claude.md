# Code check list — supplied copy vs. the real source

**Purpose.** `supplied_files/` was hand-transferred into this repository and some files were
mangled on the way in. This list is every place where the supplied copy looks wrong, so each
one can be checked against the team's actual source repo and either dismissed as transfer
damage or confirmed as a real finding.

**Nothing on this list should appear in a validation write-up until it has been confirmed
against the original.**

## How to capture each one

For each item below: open the file in the source repo, go to the line, and capture **the line
itself plus about 10 lines either side**. Context matters more than you'd think — several of
these turn on what the surrounding block is doing.

Line numbers are from the supplied copy and will drift in the real source. Each item gives a
**search string** — use that to find the spot rather than jumping to the line number.

Pasting code as text is more reliable than a screenshot (no OCR guesswork on indentation,
underscores, or `l` vs `1`). Either works.

---

## Priority 1 — confirm these first

### L1. The disabled leakage guard  ⚠ highest value on this list

| | |
|---|---|
| **File** | `src/data_pipeline/utility_lib/tokenizer.py` |
| **Line** | ~452–465 (the `days_since_status_dt` handler) |
| **Search for** | `elif handler_type == 'days_since_status_dt':` |

**What the supplied copy shows** — a guard commented out:

```python
elif handler_type == 'days_since_status_dt':
    feat_ts = self._to_timestamp(value).normalize()
    ...
    diff = (feat_ts - txn_ts).days
    # if diff >= 0:
    #     if self.fill_missing:
    #         tokens.append(f"{prefix}_MISSING")
    # else:
    ranges = feature_config.get('ranges', [])
    bin_idx = self._bin_into_ranges(diff, ranges)
    tokens.append(f"{prefix}_RANGE_{bin_idx}")
```

**Why it matters.** The class docstring (~line 81) says these diffs *"are treated as missing to
avoid future-status leakage."* With the guard commented out, a status date **in the future
relative to the transaction** gets encoded as a real value token. If cards are closed shortly
after fraud is found, that token approximates a fraud label.

**What to capture.** This block, *and* the docstring at ~line 81, *and* whether the commented
lines are commented in the source too.

**Note.** This one is different from everything else on the list — it is corroborated two other
ways that have nothing to do with the file transfer: compensating patch code in
`generate_fraud_data.py` (`inactv_positive_ids` → `inactv_missing_id`), and the project record
(COM-013, 08 Sep 2026: v22b *"should not be used in current form because of potential leakage
from card inactive date"*). So it is unlikely to be transfer damage. Confirming it is still
worth doing, because if the source has the guard **active**, that changes the risk assessment
substantially.

### A1. Package init files

| | |
|---|---|
| **Files** | `src/data/`, `src/modelling/`, `src/training/`, `src/utils/`, `src/evaluation/`, `src/scripts/`, `src/test/`, `src/logger/`, `src/inference/` |
| **Search for** | just list the directory |

Supplied copy has **`_init_.py`** (single underscores). Python requires **`__init__.py`**.

**What to capture.** A directory listing of any one of those folders showing the filenames.
One screenshot settles all nine.

**Expected outcome:** the source has `__init__.py`. A repo could not import itself otherwise.
Almost certainly transfer damage — but it needs confirming because it is the reason the
supplied package cannot run at all.

### A2. The missing tokenizer package

| | |
|---|---|
| **Expected path** | `src/tokenizer/tokenizer.py` |
| **Search for** | `from tokenizer.tokenizer import Tokenizer` |

Five modules import it (`training/pretrain.py`, `training/finetune.py`,
`evaluation/fraud_eval.py`, `evaluation/pretrain_eval.py`, `data/pretokenized_dataset.py`)
and the README's project structure lists it — but the directory is absent from `supplied_files/`.

**What to capture.** A listing of `src/` showing whether a `tokenizer/` folder exists, and if so,
what is in it.

**Worth knowing:** is `src/tokenizer/tokenizer.py` the same file as
`src/data_pipeline/utility_lib/tokenizer.py`, or a different one? If they differ, which one the
training code actually uses matters for validation.

#### Important: you do not need to *build* a tokenizer

The `vocab.json` and `config.json` you were handed **are** the tokenizer. There is nothing to
construct. `Tokenizer.save()` writes exactly those two files, and `Tokenizer.load()` reads them
back — that pair *is* the saved tokenizer state.

What is missing is only the **class definition** that reads them. And a working copy of that
class is already in the repository, at `src/data_pipeline/utility_lib/tokenizer.py`.

I checked what the training and evaluation code actually asks of a tokenizer object. It is a
very small surface:

| Used | Count |
|---|---|
| `tokenizer.vocab` | 21 |
| `tokenizer.config` (only `.bos_token`, `.eos_token`, `.pad_token`, `.unk_token`, `.gap_token`, `.features`) | 18 |
| `tokenizer.vocab_size` | 7 |
| `Tokenizer.load(path)` | every entry point |
| `tokenizer.save(path)` | 1 |

`utility_lib/tokenizer.py` provides **all** of it. So A2 is very likely just a **path problem**,
not missing work — the class exists, it is only in a different place than the imports expect.

**This downgrades A2 from "blocker" to "import path to resolve."** Still confirm what is in the
source `src/tokenizer/`, because if it is a *different* implementation from the utility_lib one,
the difference matters for validation. But you are not missing a component.

---

## The two `config.json` files — read this before wiring anything up

There are **two different files called `config.json`** in this system, and they are not
interchangeable. Mixing them up will cost you an afternoon.

### Tokenizer directory — what `tokenizer_path` points at

```
tokenizer/
├── vocab.json      # {token string: integer id}
└── config.json     # TOKENIZER config — feature definitions, special tokens
```

Read by `Tokenizer.load()`. Its `config.json` **must** contain all of these keys, or loading
fails:

`bos_token`, `eos_token`, `pad_token`, `unk_token`, `gap_token`, `mask_token`,
`delta_time_bins`, `delta_time_pad_token`, `features`, `fill_missing`

(`add_mask_token` is optional and defaults to `False`.)

⚠ **`fill_missing` is a hard failure, not a default.** The loader raises explicitly:

```python
if 'fill_missing' not in config_dict:
    raise KeyError('"fill_missing" not found in config.json. '
                   'Please re-save the tokenizer with the current version.')
```

If the `config.json` you were given is from an older save, this is the first error you will hit.
It is also the right behaviour — guessing that flag would silently change how every transaction
is tokenized (Part 6.4 of the guide).

### Model checkpoint directory — what `pretrained_model_dir` points at

```
checkpoint-intermediate-step-6500/
├── model.bin           # the weights — this is your "model.bin"
├── config.json         # MODEL config — vocab_size, d_model, n_layers, n_heads, ...
├── optimizer.bin       # only needed to resume training, not to score
├── scheduler.bin
├── rng_states.bin
└── training_state.json
```

Read by `PaymentFoundationModel.load_from_dir()`, which requires **`config.json` + `model.bin`**
and raises `FileNotFoundError` if either is absent.

### How to tell them apart in two seconds

Open the file. If you see `"features"`, `"delta_time_bins"`, `"bos_token"` → **tokenizer**.
If you see `"vocab_size"`, `"d_model"`, `"n_layers"` → **model**.

They belong in separate directories. Do not put them side by side.

### One consistency check worth doing immediately

`FraudFinetuneTrainer` hard-fails if the tokenizer and the model disagree on vocabulary size:

```python
if self.tokenizer.vocab_size != base_model.config.vocab_size:
    raise ValueError(...)
```

So before anything else: open the tokenizer `config.json`/`vocab.json` and count the entries,
open the model `config.json` and read `vocab_size`, and confirm they match. If they do not, you
have been given a mismatched pair and **nothing downstream will be meaningful** — the token IDs
would index the wrong rows of the embedding matrix and the model would produce confident
nonsense rather than an error.

This is a five-minute check that can save a week.

---

## Priority 2 — would break a run if real

### A3. Config field name mismatch

| | |
|---|---|
| **File** | `src/training/pretrain.py` |
| **Line** | 266, inside `_setup_data()` |
| **Search for** | `BatchedFileDataLoader(` |

Supplied copy reads `self.config.training_data_dir`, but `TrainingConfig` (in
`src/configs/pretrain.py`, line 46) defines **`train_data_dir`**. No other file in the repo
references `training_data_dir`.

```python
self.train_file_loader = BatchedFileDataLoader(
    self.config.training_data_dir,        # ← expected: train_data_dir
    files_per_batch=self.config.files_per_batch
)
```

**Capture both:** this block in `training/pretrain.py`, and the field list in
`configs/pretrain.py` around line 46.

**If it is real,** `PaymentTrainer` raises `AttributeError` on construction and pretraining
cannot start — which would be immediately obvious to anyone who ran it, which is itself
evidence it is probably not real.

### B4. Hybrid attention mask default

| | |
|---|---|
| **File** | `src/modelling/model.py` |
| **Lines** | 330 (the parameter) and 358 (where it is used) |
| **Search for** | `use_hybrid_attention` |

Supplied copy defaults it to `False` in `PaymentFoundationModel.forward`, and
`PaymentTrainer._forward_loss` never sets it — so the causal mask is used, not the hybrid one.

The README lists the hybrid mask under **"Key Design Decisions"**, so either the default differs
in the source, or the trainer passes it, or it genuinely was not used in the runs.

**Capture:** the `forward` signature in `model.py`, and `_forward_loss` in `training/pretrain.py`
(~line 409) to see whether the trainer passes it.

**This is not a bug either way** — it is a question about what the trained checkpoints actually
used, and you need the answer to describe the architecture correctly in a validation report.

### B1. `use_checkpoint` missing its type annotation

| | |
|---|---|
| **File** | `src/modelling/transformer.py` |
| **Line** | 41, inside the `TransformerConfig` dataclass |
| **Search for** | `use_checkpoint = True` |

```python
@dataclass
class TransformerConfig:
    ...
    ffn_bias: bool = False
    use_checkpoint = True          # ← no ": bool" annotation
```

Without the annotation this is a plain class attribute, **not a dataclass field**. So
`get_transformer_config()` (which filters on `__annotations__`) never passes it through, and
`ModelConfig.use_checkpoint = False` is silently ignored — gradient checkpointing stays on
always.

**Effect is speed, not correctness** — gradient checkpointing recomputes activations instead of
storing them, so training is slower than intended but produces the same results.

**Capture:** the whole `TransformerConfig` dataclass, so I can see whether the annotation is
present in the source.

---

## Priority 3 — low stakes, check if convenient

### A4. Keyword argument mismatch

| | |
|---|---|
| **Files** | `src/training/pretrain.py` line 342, and `src/modelling/corn_loss.py` line 21 |
| **Search for** | `corn_bce_loss_from_logits` |

Called with `logits_btkm1=`, but the function signature declares `logits_btk1`. Only executes
when `use_corn_head=True`, so it could sit unnoticed in a working repo if the CORN head was
never enabled.

**Capture:** both the call site and the function signature.

### B6. Fraud-tag vocabulary offset

| | |
|---|---|
| **File** | `src/data_pipeline/utility_lib/tokenizer.py` |
| **Lines** | 190–198, end of `_build_vocabulary()` |
| **Search for** | `assert vid == len(self.vocab)` |

```python
assert vid == len(self.vocab)
...
if self.fraud_flag == True:
    self.vocab[self.config.non_frd_token] = vid + 1    # ← skips vid
    self.vocab[self.config.frd_token]     = vid + 2
```

Starts at `vid + 1`, leaving ID `vid` unassigned. Downstream code compensates consistently
(`frd_tag_0_id = vocab_size - 1`, `frd_tag_1_id = vocab_size`), so it **works** — but it is an
undocumented convention that would break if anyone "corrected" it in isolation.

**Probably intentional. Worth a look to confirm the source matches.**

### B2, B3, B5 — no check needed

These three do not need verification against the source; they are visible properties of code
that is clearly intact:

- **B2** — per-example Python `for b_idx in range(B)` loops in `TransactionFeatureExtractor`
  (`src/modelling/fraud_cls_model.py`, lines 198, 217, 229). A throughput observation, not a
  defect. The numerics are handled correctly.
- **B3** — deprecated PyTorch APIs (`torch.cuda.amp.autocast`,
  `torch.backends.cuda.sdp_kernel`). Still work; will eventually be removed.
- **B5** — unused fields in `EmbeddingConfig` (`src/modelling/embedding.py`, lines 29–38).
  Vestigial from an earlier design. Harmless.

---

## Summary table

| # | File | Line | Search string | Priority |
|---|---|---|---|---|
| L1 | `data_pipeline/utility_lib/tokenizer.py` | ~452 | `elif handler_type == 'days_since_status_dt':` | **1** |
| A1 | all package dirs | — | list the directory | **1** |
| A2 | `src/tokenizer/` | — | `from tokenizer.tokenizer import` | **1** |
| A3 | `training/pretrain.py` | 266 | `BatchedFileDataLoader(` | 2 |
| B4 | `modelling/model.py` | 330, 358 | `use_hybrid_attention` | 2 |
| B1 | `modelling/transformer.py` | 41 | `use_checkpoint = True` | 2 |
| A4 | `training/pretrain.py` + `modelling/corn_loss.py` | 342, 21 | `corn_bce_loss_from_logits` | 3 |
| B6 | `data_pipeline/utility_lib/tokenizer.py` | 190–198 | `assert vid == len(self.vocab)` | 3 |

---

## What happens after

Once the source is confirmed, each item resolves one of three ways:

- **Transfer damage** → fix the supplied copy so it matches the source, and strike the item from
  the findings. It never was a finding.
- **Real, and a defect** → it stays a finding and goes in the validation write-up. Whether to
  *fix* it here is a separate decision — the supplied tree is the other team's delivered code
  and there is a good argument for leaving it untouched as a clean reference.
- **Real, and intentional** → document the reasoning and move on.

**A fix to the supplied copy is only worth making if the goal is to run the code.** If the goal
is to describe what the other team shipped, the supplied tree should stay exactly as delivered.
That decision is worth making deliberately before anything gets edited.
