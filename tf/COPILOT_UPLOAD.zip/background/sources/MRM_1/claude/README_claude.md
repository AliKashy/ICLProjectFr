# Claude workspace

Everything in this folder was produced by **Claude**. It is kept separate because
multiple AI assistants are working on this repository in parallel, and work from
different tools should not get mixed up or overwritten.

## Conventions

- **All Claude-authored files live in `claude/`.** Nothing is written outside this
  folder without being asked for explicitly.
- **Every file carries a `_claude` suffix** before its extension
  (`COMPLETE_SYSTEM_GUIDE_claude.md`), so a file still identifies itself if it
  gets copied, emailed, or moved out of this folder.
- **Branches are prefixed `claude/`** (e.g. `claude/mrm-one-documentation-v11muz`).
- Claude does not modify files outside `claude/` — in particular, nothing under
  `supplied_files/`, which is the other team's delivered code and is treated as
  read-only source material.

## Contents

| File | What it is |
|---|---|
| `COMPLETE_SYSTEM_GUIDE_claude.md` | Full ground-up guide to the Transaction Foundation Model in `supplied_files/`. Written for a reader with no machine-learning background: teaches the prerequisites from zero, then covers the tokenizer, data pipeline, model architecture, pretraining, fine-tuning, and evaluation file by file. Ends with a risk assessment, a findings triage, and a section on XGBoost and how the TFM could be leveraged alongside it. |
